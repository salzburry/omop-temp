#!/usr/bin/env python3
"""The approval-event ledger: append-only, hash-chained, one event per governed act.

    python platform/tools/event_ledger.py --check          # validate every chain (CHECK-ONLY)
    python platform/tools/event_ledger.py --retire <object uuid> --deleted-in <commit>
                                                           # close a chain whose subject was deleted

The ledger owns lifecycle transitions; the YAML records people read are projections held to
the newest event's payload digest. Design and the twelve ratified safeguards:
docs/EVENT_LEDGER.md. Owning tools append through `append_event()` — ONE library, so
canonicalization and chaining cannot diverge per tool; this CLI validates, and writes exactly
one kind of event of its own: the `retired` closing act over a chain whose record was deleted
on purpose (2026-09-07). A chain can never be removed, so a deleted record left its chain
ORPHANED forever and `--check` red at HEAD with nothing a person could do about it. The
retirement records the deletion commit on the chain itself; it types no name, date or reason.

There is no signature field in an event. A signature is a separate `attested` event
referencing the target's event_sha256 — filling a reserved slot later would mutate an
immutable event.

stdlib + PyYAML.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import re
import sys
import threading
import uuid
from contextlib import contextmanager
from contextvars import ContextVar
from copy import deepcopy

TOOLS = os.path.dirname(os.path.abspath(__file__))
from rwd_services import workspace_root
REPO = str(workspace_root(__file__))

from rwd_tools import product_gates as pg # noqa: E402

EVENTS_DIR = os.path.join("governance", "events")
CHECKPOINTS = os.path.join(EVENTS_DIR, "HEAD_CHECKPOINTS.yaml")

SCHEMA_VERSION = 1
CANONICALIZATION_VERSION = "c1"
HASH_ALGORITHM = "sha256"
PAYLOAD_CAP_BYTES = 64 * 1024

OBJECT_KINDS = ("protocol", "specification_material", "request", "decision",
                "equivalence_ruling", "template_release", "template_ruling",
                # THE FOUR APPROVAL FORMS AS LEDGER OBJECTS (programme item 5): an approval is an
                # act, and an act that is only a YAML file is a form. approval_record.py seals each.
                "release_approval", "configuration_approval", "contract_approval", "semantic_approval")
ACTIONS = ("registered", "amended", "closed", "answered", "withdrawn", "superseded",
           "revised", "attested", "legacy_imported", "retired")
# THE ACTS EVERY KIND ADMITS on top of its own lifecycle. `attested` signs, `legacy_imported`
# opens an inherited history, and `retired` (2026-09-07) closes a chain whose record was
# deleted from the tree on purpose: the chain stays, append-only, and the retirement names
# the commit that deleted its subject. Kept OUT of KIND_ACTIONS so each kind's own vocabulary
# (which other suites pin exactly) does not change.
UNIVERSAL_ACTIONS = ("attested", "legacy_imported", "retired")
# WHICH ACTS EACH KIND MAY RECORD (earlier review: one object drifted from protocol
# to request with the wrong verbs and nothing said so). `attested` and `legacy_imported`
# are universal; the rest are the kind's own lifecycle.
KIND_ACTIONS = {
    "protocol": ("registered", "amended", "closed"),
    "specification_material": ("registered", "revised"),
    "request": ("answered", "withdrawn", "superseded"),
    "decision": ("answered", "withdrawn", "superseded"),
    "equivalence_ruling": ("registered", "revised", "superseded"),
    "template_release": ("registered", "superseded"),
    "template_ruling": ("registered", "revised", "superseded"),
    "release_approval": ("registered", "revised", "superseded"),
    "configuration_approval": ("registered", "revised", "superseded"),
    "contract_approval": ("registered", "revised", "superseded"),
    "semantic_approval": ("registered", "revised", "superseded"),
}
# WHICH ORDER THE ACTS MAY ARRIVE IN (earlier review: registered -> closed -> amended
# passed, registration repeated, and legacy_imported arrived mid-chain — a kind restricted
# its verbs but never their order). Terminal states admit attestation only.
TERMINAL_ACTIONS = ("closed", "withdrawn", "superseded", "retired")
# WHICH ACT MAY OPEN A CHAIN (a follow-up review: a protocol beginning with `amended`
# validated — an object cannot begin mid-life). `legacy_imported` is a universal genesis;
# a request's genesis is whichever settled state the person transcribed.
GENESIS_ACTIONS = {
    "protocol": ("registered",),
    "specification_material": ("registered",),
    "request": ("answered", "withdrawn", "superseded"),
    "decision": ("answered", "withdrawn", "superseded"),
    "equivalence_ruling": ("registered",),
    "template_release": ("registered",),
    "template_ruling": ("registered",),
    "release_approval": ("registered",),
    "configuration_approval": ("registered",),
    "contract_approval": ("registered",),
    "semantic_approval": ("registered",),
}


def lifecycle_error(kind, prior_actions, action):
    """Why `action` may not follow `prior_actions` (this object's non-attested acts, in seq
    order) for an object of `kind`, or None. One definition, enforced at the door AND by
    the validator."""
    if action == "attested":
        return None
    la = [a for a in prior_actions if a != "attested"]
    if action == "retired":
        # a retirement closes a HISTORY, whatever state it reached (a closed protocol whose file
        # was deleted is as abandoned as a live one); it happens once, and never opens a chain
        if not la:
            return "retired closes a chain that has a history; an object cannot begin retired"
        if "retired" in la:
            return "already retired; a chain is retired once, and its retirement names the deletion"
        return None
    if not la and action != "legacy_imported":
        allowed = GENESIS_ACTIONS.get(kind, ())
        if allowed and action not in allowed:
            return (f"a {kind} chain opens with {'/'.join(allowed)} or legacy_imported, "
                    f"never {action!r} — an object cannot begin mid-life")
    if la and la[-1] in TERMINAL_ACTIONS:
        return (f"the object is {la[-1]}, a terminal state — it admits attestation only, "
                f"never another lifecycle act")
    if action == "legacy_imported" and la:
        return ("legacy_imported is a genesis-only act — an import arriving mid-chain "
                "rewrites a live history as an inherited one")
    if action == "registered" and la and la != ["legacy_imported"]:
        return ("already registered — registration happens once, at genesis or as the "
                "adoption re-seal directly after a legacy import")
    return None


TRUST_LEVELS = ("typed", "authenticated", "unauthenticated_legacy")
# `authenticated` is FORBIDDEN until signature verification exists (earlier review: a
# caller claimed it with no signature and nothing could check one) — the word stays in the
# vocabulary so the verifier can admit it later without a schema change.
ALLOWED_TRUST = ("typed", "unauthenticated_legacy")
# the fields an `attested` payload must state; a signature over nothing signs nothing
ATTESTATION_FIELDS = ("target_event_sha256", "signer_key_id", "algorithm", "signature")
# THE SIGNING-KEY REGISTER (programme item 5): a person's public key, registered by a person.
# `authenticated` is DERIVED by verifying an attested event's signature against a registered,
# active key — never claimed on an actor, never read off a name.
SIGNING_KEYS = os.path.join("governance", "SIGNING_KEYS.yaml")
KEY_FIELDS = ("key_id", "person", "algorithm", "public_key", "registered_by", "registration_date", "status")
KEY_STATUSES = ("active", "revoked")
SIGNATURE_ALGORITHM = "ed25519"
ACTOR_FIELDS = ("subject_id", "identity_provider", "display_name", "role", "trust_level")
# every event field, in the one order the file is written in; event_sha256 is excluded from
# its own digest by construction
EVENT_FIELDS = ("schema_version", "canonicalization_version", "hash_algorithm", "event_id",
                "object_uuid", "object_kind", "seq", "action", "actor", "occurred_at",
                "idempotency_key", "payload", "payload_sha256", "previous_event_sha256",
                "event_sha256")

RFC3339_INSTANT = re.compile(r"^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(\.\d+)?(?:Z|[+-](?:[01]\d|2[0-3]):[0-5]\d)$")
HEX64 = re.compile(r"^[0-9a-f]{64}$")
UUID4 = re.compile(r"^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$")


class LedgerError(Exception):
    """A refusal with its reason — the append API's only failure mode."""


def canonical_json(x):
    """Canonicalization c1: keys sorted, compact separators, ensure_ascii=False, UTF-8,
    and NO NaN/Infinity — a non-Python signer must reproduce these bytes exactly, and
    IEEE special values serialize differently per language.

    Values are hashed exactly as given — no whitespace collapsing, no case folding. The
    OWNING tool canonicalises its domain content before it becomes a payload; this layer's
    job is byte-determinism, not prose judgment."""
    try:
        return json.dumps(x, sort_keys=True, ensure_ascii=False, separators=(",", ":"),
                          allow_nan=False)
    except ValueError as e:
        raise LedgerError(f"payload is not canonicalizable ({e}) — NaN and Infinity have "
                          f"no portable canonical form") from e


def _parse_rfc3339(ts):
    """A real instant, normalized to naive UTC for existing ordering checks.

    Stored RFC 3339 offsets remain intact; normalization is only for comparison.
    """
    import datetime as _dt # noqa: PLC0415
    if not RFC3339_INSTANT.fullmatch(str(ts or "")) or str(ts).endswith("-00:00"):
        return None
    try:
        instant = _dt.datetime.fromisoformat(str(ts).replace("Z", "+00:00"))
        return instant.astimezone(_dt.timezone.utc).replace(tzinfo=None)
    except (ValueError, OverflowError):
        return None


def payload_digest(payload):
    return hashlib.sha256(canonical_json(payload).encode("utf-8")).hexdigest()


def event_digest(event):
    """SHA256 over the canonical event minus event_sha256 — an event can never digest itself."""
    body = {k: event[k] for k in event if k != "event_sha256"}
    return hashlib.sha256(canonical_json(body).encode("utf-8")).hexdigest()


def _object_dir(root, object_uuid):
    return os.path.join(root, EVENTS_DIR, object_uuid)


def _event_files(root, object_uuid):
    """[(seq, filename)] sorted by seq; refuses nothing — the validator names defects."""
    d = _object_dir(root, object_uuid)
    if not os.path.isdir(d):
        return []
    out = []
    for f in os.listdir(d):
        m = re.match(r"^(\d{4})-([0-9a-f-]{36})\.yaml$", f)
        if m:
            out.append((int(m.group(1)), f))
    return sorted(out)


def read_event(root, object_uuid, filename):
    doc, err = pg.read_yaml(os.path.join(_object_dir(root, object_uuid), filename))
    return doc, err


def head_of(root, object_uuid):
    """(seq, event_sha256) of the newest committed-or-working event, or (0, "")."""
    files = _event_files(root, object_uuid)
    if not files:
        return 0, ""
    seq, fname = files[-1]
    doc, err = read_event(root, object_uuid, fname)
    if err or not isinstance(doc, dict):
        raise LedgerError(f"{object_uuid}/{fname}: unreadable head event ({err})")
    return seq, str(doc.get("event_sha256") or "")


def _checkpoints(root):
    doc, err = pg.read_yaml(os.path.join(root, CHECKPOINTS))
    if err:
        raise LedgerError(f"{CHECKPOINTS}: {err}")
    return doc if isinstance(doc, dict) else {"heads": {}}


def _validate_actor(actor):
    if not isinstance(actor, dict):
        raise LedgerError("actor must be a structured identity, not a string — a typed name "
                          "alone is the assertion this ledger exists to outgrow")
    for f in ACTOR_FIELDS:
        if not str(actor.get(f) or "").strip():
            raise LedgerError(f"actor.{f} is unstated — an act with a partial identity is "
                              f"attributed to nobody in particular")
    if actor["trust_level"] not in TRUST_LEVELS:
        raise LedgerError(f"actor.trust_level {actor['trust_level']!r} is not one of "
                          f"{TRUST_LEVELS}")
    bad = pg.not_a_person(actor.get("display_name"))
    if bad and actor["trust_level"] != "unauthenticated_legacy":
        raise LedgerError(f"actor.display_name: {bad}")
    for f in ("subject_id", "display_name"):
        if pg.unstated(actor.get(f)):
            raise LedgerError(f"actor.{f} {actor.get(f)!r} is a placeholder — an act "
                              f"attributed to TBD is attributed to nobody")


def append_event(root, *, object_uuid, object_kind, action, actor, occurred_at, payload,
                 expected_previous_event_sha256, idempotency_key):
    """Append ONE event and update the head checkpoint. Returns the event dict.

    `object_uuid=None` mints a new object (expected_previous must be ""). Concurrency-safe
    by contract: a stale `expected_previous_event_sha256` refuses (someone appended first —
    re-read and decide again); an existing event with this `idempotency_key` on the object
    is RETURNED, never duplicated. The ledger file and the checkpoint move in one call so a
    commit carries both or neither."""
    if action not in ACTIONS:
        raise LedgerError(f"action {action!r} is not in the vocabulary {ACTIONS}")
    if object_kind not in OBJECT_KINDS:
        raise LedgerError(f"object_kind {object_kind!r} is not in {OBJECT_KINDS}")
    if action not in KIND_ACTIONS[object_kind] + UNIVERSAL_ACTIONS:
        raise LedgerError(f"a {object_kind} records {KIND_ACTIONS[object_kind]} (plus "
                          f"attested/legacy_imported/retired), never {action!r} — one kind, one "
                          f"lifecycle")
    if _parse_rfc3339(occurred_at) is None:
        raise LedgerError(f"occurred_at {occurred_at!r} is not a real RFC 3339 instant with a known offset "
                          f"(e.g. 2026-08-27T21:04:05Z or 2026-08-28T02:34:05+05:30)")
    if not str(idempotency_key or "").strip():
        raise LedgerError("idempotency_key is required — a retry must find its first attempt")
    _validate_actor(actor)
    if actor["trust_level"] not in ALLOWED_TRUST:
        raise LedgerError(f"trust_level {actor['trust_level']!r} cannot be CLAIMED — "
                          f"`authenticated` arrives only from signature verification, which "
                          f"does not exist yet; a claimed authentication is a forged one")
    if action == "attested":
        missing = [f for f in ATTESTATION_FIELDS
                   if not str((payload or {}).get(f) or "").strip()]
        if missing:
            raise LedgerError(f"an attested event states {ATTESTATION_FIELDS}; "
                              f"{', '.join(missing)} unstated — a signature over nothing "
                              f"signs nothing")
    if not isinstance(payload, dict):
        raise LedgerError("payload must be a mapping of bounded decision content")
    blob = canonical_json(payload).encode("utf-8")
    if len(blob) > PAYLOAD_CAP_BYTES:
        raise LedgerError(f"payload is {len(blob)} bytes canonical — over the "
                          f"{PAYLOAD_CAP_BYTES}-byte cap. Documents enter as references "
                          f"(path_or_link, media_type, sha256), never inline.")

    def _idem_match(doc):
        """The SAME act, or a refusal — a reused key on a DIFFERENT act is a collision
        wearing a retry."""
        if str(doc.get("object_kind")) != object_kind \
                or str(doc.get("action")) != action \
                or str(doc.get("payload_sha256")) != payload_digest(payload) \
                or doc.get("actor") != {f: str(actor[f]) for f in ACTOR_FIELDS}:
            raise LedgerError(f"idempotency_key {idempotency_key!r} was used by a DIFFERENT "
                              f"act ({doc.get('action')}, payload "
                              f"{str(doc.get('payload_sha256'))[:12]}…) — a key names one "
                              f"act exactly; choose a new key for a new act")
        return doc

    minted = object_uuid is None
    if minted:
        # GENESIS IDEMPOTENCY IS GLOBAL (earlier review: searching only the freshly
        # minted uuid meant every genesis retry minted a second logical object)
        base = os.path.join(root, EVENTS_DIR)
        if os.path.isdir(base):
            for entry in os.listdir(base):
                if not UUID4.match(entry):
                    continue
                for _seq, fname in _event_files(root, entry):
                    doc, err = read_event(root, entry, fname)
                    if not err and isinstance(doc, dict) \
                            and str(doc.get("idempotency_key")) == str(idempotency_key):
                        return _idem_match(doc)
        object_uuid = str(uuid.uuid4())
    elif not UUID4.match(str(object_uuid)):
        raise LedgerError(f"object_uuid {object_uuid!r} is not a uuid4")
    else:
        # idempotency before anything else: the retry path must not even check the head
        for _seq, fname in _event_files(root, object_uuid):
            doc, err = read_event(root, object_uuid, fname)
            if not err and isinstance(doc, dict) \
                    and str(doc.get("idempotency_key")) == str(idempotency_key):
                return _idem_match(doc)
        #...and the KIND is the genesis event's kind, forever
        g_files = _event_files(root, object_uuid)
        if g_files:
            g_doc, g_err = read_event(root, object_uuid, g_files[0][1])
            if not g_err and isinstance(g_doc, dict) \
                    and str(g_doc.get("object_kind")) != object_kind:
                raise LedgerError(f"object {object_uuid} is a "
                                  f"{g_doc.get('object_kind')} and stays one — a kind is "
                                  f"identity, not a field to drift")

    head_seq, head_sha = head_of(root, object_uuid)
    if str(expected_previous_event_sha256 or "") != head_sha:
        raise LedgerError(f"expected_previous_event_sha256 {str(expected_previous_event_sha256)[:12]!r}… "
                          f"does not match the head {head_sha[:12]!r}… — someone appended "
                          f"first; re-read the object and decide again")
    if minted and head_seq:
        raise LedgerError("a minted object already has events — impossible; refuse")
    prior = []
    for _seq, fname in _event_files(root, object_uuid):
        doc, err = read_event(root, object_uuid, fname)
        if not err and isinstance(doc, dict):
            prior.append(str(doc.get("action")))
    lerr = lifecycle_error(object_kind, prior, action)
    if lerr:
        raise LedgerError(lerr)
    if action == "retired":
        why = retirement_error(root, object_uuid, payload)
        if why:
            raise LedgerError(why)

    event = {
        "schema_version": SCHEMA_VERSION,
        "canonicalization_version": CANONICALIZATION_VERSION,
        "hash_algorithm": HASH_ALGORITHM,
        "event_id": str(uuid.uuid4()),
        "object_uuid": object_uuid,
        "object_kind": object_kind,
        "seq": head_seq + 1,
        "action": action,
        "actor": {f: str(actor[f]) for f in ACTOR_FIELDS},
        "occurred_at": str(occurred_at),
        "idempotency_key": str(idempotency_key),
        "payload": payload,
        "payload_sha256": payload_digest(payload),
        "previous_event_sha256": head_sha,
    }
    event["event_sha256"] = event_digest(event)

    d = _object_dir(root, object_uuid)
    os.makedirs(d, exist_ok=True)
    path = os.path.join(d, f"{event['seq']:04d}-{event['event_id']}.yaml")
    import yaml # noqa: PLC0415
    text = yaml.safe_dump(event, sort_keys=False, allow_unicode=True)
    # O_EXCL: the filename is the claim, created exclusively or not at all
    fd = os.open(path, os.O_CREAT | os.O_EXCL | os.O_WRONLY)
    with os.fdopen(fd, "w", encoding="utf-8", newline="\n") as fh:
        fh.write(text)
    # COMPARE-AND-CLAIM (earlier review: two truly concurrent appends both landed at
    # one seq and only the later validator saw the fork). The event_ids differ so both
    # files could exist; after writing, this event must be the SOLE holder of its seq —
    # the loser unlinks itself and refuses, and the checkpoint moves only after the claim.
    rivals = [f for s, f in _event_files(root, object_uuid)
              if s == event["seq"] and f != os.path.basename(path)]
    if rivals:
        os.unlink(path)
        raise LedgerError(f"seq {event['seq']} was claimed concurrently by {rivals[0]} — "
                          f"someone appended first; re-read the object and decide again")

    # THE CHECKPOINT MOVES UNDER A LOCK (earlier review: two concurrent appends on
    # DIFFERENT objects both succeeded, and the slower writer's unlocked read-modify-write
    # resurrected the file it had read before the faster one's head landed — one head stayed
    # behind its chain). The read, the merge and the atomic replace happen inside the lock;
    # if the checkpoint cannot move, the event claim is unwound, keeping "both or neither".
    try:
        cp_path = os.path.join(root, CHECKPOINTS)
        os.makedirs(os.path.dirname(cp_path), exist_ok=True)
        lock = cp_path + ".lock"
        import time # noqa: PLC0415
        deadline = time.monotonic() + 10.0
        while True:
            try:
                lfd = os.open(lock, os.O_CREAT | os.O_EXCL | os.O_WRONLY)
                break
            except FileExistsError:
                if time.monotonic() > deadline:
                    raise LedgerError(
                        f"{lock}: held for over 10s — a crashed appender left its lock "
                        f"behind; verify no append is running, remove the lock, retry")
                time.sleep(0.05)
        try:
            cp = _checkpoints(root) if os.path.exists(cp_path) else {"heads": {}}
            heads = cp.setdefault("heads", {})
            cur = heads.get(object_uuid) or {}
            if int(cur.get("seq") or 0) < event["seq"]: # heads only advance
                heads[object_uuid] = {
                    "seq": event["seq"], "event_sha256": event["event_sha256"],
                    "object_kind": object_kind}
            tmp = f"{cp_path}.tmp-{event['event_id']}"
            with open(tmp, "w", encoding="utf-8", newline="\n") as fh:
                fh.write(
                    "# GENERATED BY append_event() AND VERIFIED BY --check - the expected head\n"
                    "# of every object's chain, stored OUTSIDE the chain because a chain cannot\n"
                    "# see the removal of its own tail. Heads only ever advance; --check refuses\n"
                    "# a checkpoint whose git history ever showed a higher seq than the present.\n"
                    + yaml.safe_dump(cp, sort_keys=True, allow_unicode=True))
            os.replace(tmp, cp_path)
        finally:
            os.close(lfd)
            os.unlink(lock)
    except Exception:
        try:
            if not [f for s, f in _event_files(root, object_uuid) if s > event["seq"]]:
                os.unlink(path)
        except OSError:
            pass
        raise
    return event


def ever_carried_object_uuid(root, rel_file, scope_pattern=None, owned_only=False):
    """Whether git history ever recorded an `object_uuid:` in `rel_file` — "SHALLOW" when
    that cannot be determined.

    PARTICIPATION IS HISTORICALLY IRREVERSIBLE. `scope_pattern` narrows the search to one material's block in a
    multi-record file; None reads the whole file. `owned_only` counts only a uuid this record's own
    lineage introduced (see `owns_object_uuid`): a hand copy that carried another record's uuid in
    its first commit never participated — it copied a participant."""
    if not _is_git(root):
        return False
    if _is_shallow(root):
        return "SHALLOW"
    pat = re.compile(scope_pattern or r"^\s*object_uuid\s*:\s*[0-9a-f-]{36}", re.M)
    history = _history_of(root, rel_file)
    for sha, path in history:
        b = _git(root, "show", f"{sha}:{path}", "--")
        if b and b.returncode == 0:
            m = pat.search(b.stdout)
            if m:
                if not owned_only:
                    return True
                u = UUID_IN.search(m.group(0))
                if u and owns_object_uuid(root, rel_file, u.group(0), history) is not False:
                    return True
    return False


def _history_of(root, rel_file):
    """[(commit, path-at-that-commit)] oldest-first for `rel_file`, FOLLOWING renames — a
    record moved and re-pointed at a twin object in ONE commit evaded the pin, because the
    new path's history began at the move. --name-only supplies the
    file's name AT each commit, so the content is read from where it actually lived.
    git runs newest-first and the list is reversed HERE: `--follow` does not compose with
    `--reverse` — the combination silently stops at the rename, which is exactly the gap
    this function closes."""
    r = _git(root, "log", "--follow", "--format=%H", "--name-only", "--",
             rel_file.replace(os.sep, "/"))
    if not r or r.returncode != 0:
        return []
    out, sha = [], None
    for tok in r.stdout.splitlines():
        tok = tok.strip()
        if not tok:
            continue
        if re.fullmatch(r"[0-9a-f]{40}", tok):
            sha = tok
        elif sha is not None:
            out.append((sha, tok))
    # A COPY IS NOT A RENAME. `--follow` detects copies too, so a product pack copied by hand from
    # a fixture inherited the fixture's object_uuid and was told to 'restore' a uuid that two
    # records would then claim (thirteenth pass, J6). A path change is followed only when it is a
    # MOVE: the older path is gone from the tree at the commit that introduced the newer one. When
    # the older path is still there, the file was copied, and a copy's history begins with the copy.
    # (Decided from the trees, not from the path's shape: a rename-and-swap in one commit — the
    # evasion `--follow` was adopted against — moves the whole pack to a new slug, and a rule that
    # cut at the slug reopened it; the source-contract suite caught that.)
    kept = []
    for i, (sha_, path) in enumerate(out):                   # newest first
        if i and path != out[i - 1][1]:
            older_still_there = _git(root, "cat-file", "-e", f"{out[i - 1][0]}:{path}")
            if older_still_there is not None and older_still_there.returncode == 0:
                break
        kept.append((sha_, path))
    return list(reversed(kept))


def first_committed_object_uuid(root, rel_file, scope_pattern=None, owned_only=False):
    """The FIRST object_uuid git history records in `rel_file` — None when history never
    carried one, "SHALLOW" when that cannot be determined.

    IDENTITY IS PINNED AT FIRST COMMIT. `scope_pattern` must carry ONE capturing
    group around the uuid; None reads the file's first `object_uuid:` line. `owned_only` skips a
    uuid another record's lineage introduced (a hand copy's first commit carries the fixture's):
    the pin is the first uuid THIS record brought into the repository."""
    if not _is_git(root):
        return None
    if _is_shallow(root):
        return "SHALLOW"
    pat = re.compile(scope_pattern
                     or r"^\s*object_uuid\s*:\s*['\"]?([0-9a-f-]{36})", re.M)
    history = _history_of(root, rel_file)
    for sha, path in history:
        b = _git(root, "show", f"{sha}:{path}", "--")
        if b and b.returncode == 0:
            m = pat.search(b.stdout)
            if m:
                if owned_only and owns_object_uuid(root, rel_file, m.group(1), history) is False:
                    continue                         # a copied uuid pins nothing here
                return m.group(1)
    return None


UUID_IN = re.compile(r"[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}")
_READ_CHECK = ContextVar("rwd_ledger_read_check", default=None)


@contextmanager
def read_check(root):
    """Reuse mutable Git facts only inside this one read-only check/response.

    Direct calls outside a check always read again. Nested checks for another
    root have isolated state; no completed check retains repository/HEAD facts.
    """
    scope = os.path.realpath(root)
    current = _READ_CHECK.get()
    if current is not None and current["root"] == scope:
        yield
        return
    token = _READ_CHECK.set({"root": scope, "git": {}, "origins": {}})
    try:
        yield
    finally:
        _READ_CHECK.reset(token)


def _check_cache(root, name):
    current = _READ_CHECK.get()
    return current[name] if current is not None and current["root"] == os.path.realpath(root) else None


def uuid_origin(root, uuid):
    """(commit, [paths carrying it there]) where `uuid` FIRST entered the repository — None when
    it was never committed, "SHALLOW" when history cannot say.

    OWNERSHIP IS DECIDED HERE. The record whose lineage introduced a uuid owns it; every later
    first-commit of the same uuid at another path is a copy of that record — the natural hand copy
    (`cp -r` and commit, uuid and all), which used to loop between 'claimed by 2 records' and
    'restore it' with no exit but a history rewrite (thirteenth pass, J6, the verifiers' half)."""
    cache = _check_cache(root, "origins")
    key = (os.path.realpath(root), uuid)
    if cache is not None and key in cache:
        return deepcopy(cache[key])
    if not _is_git(root):
        return None
    if _is_shallow(root):
        return "SHALLOW"
    r = _git(root, "log", "--reverse", "--format=%H", "-S", uuid, "--", ".")
    first = next((ln.strip() for ln in (r.stdout if r and r.returncode == 0 else "").splitlines()
                  if ln.strip()), None)
    out = None
    if first:
        g = _git(root, "grep", "-l", "-F", uuid, first, "--", ".")
        paths = [ln.split(":", 1)[1] for ln in (g.stdout if g and g.returncode == 0 else "").splitlines()
                 if ":" in ln]
        out = (first, paths)
    if cache is not None:
        cache[key] = deepcopy(out)
    return out


def owns_object_uuid(root, rel_file, uuid, history=None):
    """True when `uuid` entered the repository through `rel_file`'s own lineage (the file, or a
    path it was moved from), False when it entered elsewhere — this record copied it — and None
    when that cannot be decided (never committed, or shallow history)."""
    origin = uuid_origin(root, uuid)
    if origin is None or origin == "SHALLOW":
        return None
    history = history if history is not None else _history_of(root, rel_file)
    if not history:
        # NO COMMITTED HISTORY: an uncommitted or out-of-tree copy (the drafting tools' temp copies
        # of a live pack, a working-tree cp -r not yet committed). The identity checks stand down
        # on such a copy everywhere else — the commit is the act that creates a record, and it is
        # judged then. Refusing here broke every spec_slice test that exercises a temp copy.
        return None
    lineage = {rel_file.replace(os.sep, "/")} | {p for _s, p in history}
    return any(p in lineage for p in origin[1])


# ------------------------------------------------------------------------------ validation

# Full-commit objects are immutable. Repository/shallow state and UUID origins
# are mutable and belong only to read_check, never to this process-wide cache.
# HEAD, index and current event-file reads are not cached.
_GIT_CACHE: dict = {}
_BINARY_GIT_CACHE: dict = {}
_BINARY_GIT_LOCK = threading.Lock()
_BINARY_CACHE_BYTES = 8 * 1024 * 1024
_BINARY_CACHE_ENTRIES = 256
_IMMUTABLE = ("show", "ls-tree")
_PER_RUN = (("rev-parse", "--is-inside-work-tree"), ("rev-parse", "--is-shallow-repository"))


def _cacheable(args):
    import re as _re                                                     # noqa: PLC0415
    if args[:1] and args[0] in _IMMUTABLE:
        # a trailing "--" marks the object as a revision (Windows: a deep checkout makes git's
        # filename check fail with 'Filename too long' before it reads the object)
        target = next((a for a in args[1:] if not a.startswith("-")), "")
        return bool(_re.match(r"^[0-9a-f]{40}(:|$)", target))
    return False


def _git(root, *args):
    import subprocess # noqa: PLC0415
    cache = (_GIT_CACHE if _cacheable(args) else _check_cache(root, "git")
             if tuple(args[:2]) in _PER_RUN else None)
    key = (os.path.realpath(root), args)
    if cache is not None and key in cache:
        return cache[key]
    try:
        result = subprocess.run(["git", "-C", root, *args], capture_output=True, text=True,
                                encoding="utf-8")
    except OSError:
        return None
    if cache is not None and result.returncode == 0:
        if len(cache) > 2048:
            cache.clear()
        cache[key] = result
    return result


def _committed_bytes(root, sha, path):
    """Read exact event bytes; cache only a successful full-commit lookup."""
    import subprocess
    key = (os.path.realpath(root), sha, path)
    immutable = bool(re.fullmatch(r"[0-9a-f]{40}", sha))
    if immutable:
        with _BINARY_GIT_LOCK:
            if key in _BINARY_GIT_CACHE:
                return _BINARY_GIT_CACHE[key]
    try:
        result = subprocess.run(["git", "-C", root, "show", f"{sha}:{path}", "--"], capture_output=True)
    except OSError:
        return None
    if result.returncode != 0:
        return None
    raw = result.stdout  # No text decoding/newline normalization.
    if immutable and len(raw) <= _BINARY_CACHE_BYTES:
        # Concurrent checks may read the same immutable object. Only bounded
        # dictionary work is serialized; Git I/O above never holds this lock.
        with _BINARY_GIT_LOCK:
            if key not in _BINARY_GIT_CACHE:
                while _BINARY_GIT_CACHE and (len(_BINARY_GIT_CACHE) >= _BINARY_CACHE_ENTRIES
                        or sum(map(len, _BINARY_GIT_CACHE.values())) + len(raw) > _BINARY_CACHE_BYTES):
                    _BINARY_GIT_CACHE.pop(next(iter(_BINARY_GIT_CACHE)))
                _BINARY_GIT_CACHE[key] = raw
    return raw


def _is_git(root):
    r = _git(root, "rev-parse", "--is-inside-work-tree")
    return bool(r and r.returncode == 0 and r.stdout.strip() == "true")


def _is_shallow(root):
    r = _git(root, "rev-parse", "--is-shallow-repository")
    return bool(r and r.returncode == 0 and r.stdout.strip() == "true")


def signing_keys(root=None):
    """({key_id: entry}, [problems]) — governance/SIGNING_KEYS.yaml validated. An absent file
    is an EMPTY register (nothing authenticates), never an error; a malformed entry is named and
    excluded, because a key nobody can read cannot stand behind anything."""
    import base64                                                        # noqa: PLC0415
    root = root or REPO
    path = os.path.join(root, SIGNING_KEYS)
    if not os.path.isfile(path):
        return {}, []
    doc, err = pg.read_yaml(path)
    if err:
        return {}, [f"{SIGNING_KEYS}: {err}"]
    out, problems, seen = {}, [], set()
    for i, k in enumerate((doc or {}).get("keys") or []):
        where = f"{SIGNING_KEYS}: keys[{i}]"
        if not isinstance(k, dict):
            problems.append(f"{where}: not a mapping")
            continue
        missing = [f for f in KEY_FIELDS if not str(k.get(f) or "").strip()]
        if missing:
            problems.append(f"{where}: leaves {', '.join(missing)} unstated")
            continue
        kid = str(k["key_id"])
        if kid in seen:
            problems.append(f"{where}: key_id {kid} registered twice — a key is registered once")
            continue
        if str(k["algorithm"]) != SIGNATURE_ALGORITHM:
            problems.append(f"{where}: algorithm {k['algorithm']!r} is not {SIGNATURE_ALGORITHM}")
            continue
        if str(k["status"]) not in KEY_STATUSES:
            problems.append(f"{where}: status {k['status']!r} is not one of {KEY_STATUSES}")
            continue
        for f in ("person", "registered_by"):
            why = pg.not_a_person(str(k[f]))
            if why:
                problems.append(f"{where}: {f}: {why}")
                break
        else:
            bad = pg.bad_date(str(k["registration_date"]))
            if bad:
                problems.append(f"{where}: registration_date: {bad}")
                continue
            try:
                raw = base64.b64decode(str(k["public_key"]), validate=True)
            except Exception:                                             # noqa: BLE001
                problems.append(f"{where}: public_key is not base64")
                continue
            if len(raw) != 32:
                problems.append(f"{where}: public_key decodes to {len(raw)} bytes, not the 32 of an "
                                f"{SIGNATURE_ALGORITHM} public key")
                continue
            seen.add(kid)
            out[kid] = dict(k, _raw=raw)
    return out, problems


def _private_key(private_key_bytes):
    """32 raw bytes, or their 64 hex characters (a text file a person keeps outside the checkout)."""
    if isinstance(private_key_bytes, str):
        private_key_bytes = private_key_bytes.encode("utf-8")
    b = private_key_bytes.strip()
    if len(b) == 64:
        try:
            return bytes.fromhex(b.decode("ascii"))
        except ValueError:
            pass
    if len(private_key_bytes) != 32:
        raise LedgerError(f"a private key is 32 raw bytes or their 64 hex characters; got {len(private_key_bytes)} bytes")
    return private_key_bytes


def public_key_b64(private_key_bytes):
    """The base64 public key a private key registers."""
    import base64                                                        # noqa: PLC0415
    from rwd_tools import ed25519_pure                                                  # noqa: PLC0415
    return base64.b64encode(ed25519_pure.secret_to_public(_private_key(private_key_bytes))).decode("ascii")


def sign_target(private_key_bytes, target_event_sha256):
    """base64(ed25519 signature over the target event digest's UTF-8 hex)."""
    import base64                                                        # noqa: PLC0415
    from rwd_tools import ed25519_pure                                                  # noqa: PLC0415
    return base64.b64encode(ed25519_pure.sign(_private_key(private_key_bytes),
                                              str(target_event_sha256).encode("utf-8"))).decode("ascii")


def attest(root, object_uuid, target_event_sha256, key_id, private_key_bytes, occurred_at, role="rwp"):
    """A PERSON'S signature over one event of one object, appended as an `attested` event.

    The key must be registered and active, the private key handed in must be the one the
    register names (a signature from another key under this id is refused before anything is
    written), and the target must be an event of this object. The actor is the key's person,
    still `typed`: authentication is what verify_attestation DERIVES from the signature, never a
    word written on an actor."""
    keys, problems = signing_keys(root)
    if problems:
        raise LedgerError("; ".join(problems))
    k = keys.get(str(key_id))
    if k is None:
        raise LedgerError(f"key_id {key_id!r} is not registered in {SIGNING_KEYS}")
    if k["status"] != "active":
        raise LedgerError(f"key_id {key_id} is {k['status']} — a revoked key signs nothing")
    if public_key_b64(private_key_bytes) != str(k["public_key"]):
        raise LedgerError(f"the private key handed in is not the key registered as {key_id} — "
                          f"sign with the registered key, or register this one")
    target = str(target_event_sha256)
    known = {}
    for _seq, fname in _event_files(root, object_uuid):
        doc, err = read_event(root, object_uuid, fname)
        if not err and isinstance(doc, dict):
            known[str(doc.get("event_sha256"))] = doc
    if target not in known:
        raise LedgerError(f"{target[:12]}… is not an event of {object_uuid} — a signature over nothing signs nothing")
    _seq, head = head_of(root, object_uuid)
    who = str(k["person"])
    actor = {"subject_id": who, "identity_provider": "signing_key", "display_name": who,
             "role": role, "trust_level": "typed"}
    payload = {"target_event_sha256": target, "signer_key_id": str(key_id),
               "algorithm": SIGNATURE_ALGORITHM, "signature": sign_target(private_key_bytes, target)}
    return append_event(root, object_uuid=object_uuid, object_kind=str(known[target].get("object_kind")),
                        action="attested", actor=actor, occurred_at=occurred_at, payload=payload,
                        expected_previous_event_sha256=head,
                        idempotency_key=f"attest:{key_id}:{target[:16]}")


def verify_attestation(root, object_uuid):
    """{authenticated: {target_event_sha256: [key_id]}, problems: [...]} — every `attested` event
    of one object, VERIFIED: the algorithm is ed25519, the key is registered and active, the target
    is an event of this object, and the signature verifies over the target digest (ed25519_pure,
    stdlib only, so the answer is the signature's and never the environment's). Anything short of
    that authenticates nothing and is named; a placeholder attestation is structurally a valid
    event (check() keeps it) and cryptographically nothing."""
    from rwd_tools import ed25519_pure                                                  # noqa: PLC0415
    keys, problems = signing_keys(root)
    out = {"authenticated": {}, "problems": list(problems)}
    events = {}
    attested = []
    for _seq, fname in _event_files(root, object_uuid):
        doc, err = read_event(root, object_uuid, fname)
        if err or not isinstance(doc, dict):
            continue
        events[str(doc.get("event_sha256"))] = doc
        if doc.get("action") == "attested":
            attested.append((fname, doc))
    import base64                                                        # noqa: PLC0415
    for fname, doc in attested:
        where = f"{EVENTS_DIR}/{object_uuid}/{fname}"
        pl = doc.get("payload") or {}
        target, kid, alg, sig = (str(pl.get(f) or "") for f in ATTESTATION_FIELDS)
        if alg != SIGNATURE_ALGORITHM:
            out["problems"].append(f"{where}: algorithm {alg!r} is not {SIGNATURE_ALGORITHM} — authenticates nothing")
            continue
        k = keys.get(kid)
        if k is None:
            out["problems"].append(f"{where}: signer_key_id {kid!r} is not a registered key — authenticates nothing")
            continue
        if k["status"] != "active":
            out["problems"].append(f"{where}: signer_key_id {kid} is {k['status']} — authenticates nothing")
            continue
        if target not in events or events[target].get("action") == "attested":
            out["problems"].append(f"{where}: attests {target[:12]}…, which is not a non-attestation event of this object")
            continue
        try:
            raw_sig = base64.b64decode(sig, validate=True)
        except Exception:                                                 # noqa: BLE001 — not base64 is not a signature
            raw_sig = b""
        if not ed25519_pure.verify(k["_raw"], target.encode("utf-8"), raw_sig):
            out["problems"].append(f"{where}: the signature does not verify under {kid} — authenticates nothing")
            continue
        out["authenticated"].setdefault(target, []).append(kid)
    return out


def trust_of(root, object_uuid, event_sha256=None):
    """The trust an event has EARNED: `authenticated` when a verified attestation stands behind
    it, else the actor's own level as written. Default: the newest non-attestation event."""
    target = event_sha256
    actor_trust = None
    for _seq, fname in _event_files(root, object_uuid):
        doc, err = read_event(root, object_uuid, fname)
        if err or not isinstance(doc, dict) or doc.get("action") == "attested":
            continue
        if event_sha256 is None or str(doc.get("event_sha256")) == str(event_sha256):
            target = str(doc.get("event_sha256"))
            actor_trust = str((doc.get("actor") or {}).get("trust_level") or "typed")
    if target is None or actor_trust is None:
        return None
    if target in verify_attestation(root, object_uuid)["authenticated"]:
        return "authenticated"
    return actor_trust


def check(root=None, require_claims=False):
    """Validate local evidence, and the protected external anchor when configured."""
    current_root = root or REPO
    with read_check(current_root):
        problems = _check_local(current_root, require_claims=require_claims)
        if not problems and os.environ.get("RWDP_AUDIT_ANCHOR_FILE"):
            try:
                from rwd_services.audit_anchor import verify
                problems.extend(verify(current_root))
            except Exception as error:
                problems.append("The configured external audit anchor could not be verified. Ask the audit operator to check its connection, locked retention and current head publication. " + type(error).__name__)
        return problems


def _check_local(root=None, require_claims=False):
    """[problems] over every chain, the checkpoints, and git history. Check-only, exact.

    `require_claims=True` (the CLI and release validation) additionally refuses an object
    NO tracked-or-working file references — the structural closure of the twin family: every swap, however the rename was disguised from history tracking,
    abandons the original object, and an abandoned chain is a record that shed its
    history. Off by default so a bare ledger exercised without records stays testable."""
    root = root or REPO
    out = []
    base = os.path.join(root, EVENTS_DIR)
    if not os.path.isdir(base):
        # No ledger YET is a true, clean state — but no ledger ANY MORE is a deletion. Git
        # decides which this is: history that ever touched the ledger and a tree without it
        # is the whole-ledger removal the per-object sweeps cannot see from inside.
        if _is_git(root):
            if _is_shallow(root):
                return [f"{EVENTS_DIR}: absent, and this checkout's git history is SHALLOW "
                        f"— whether a ledger ever existed cannot be determined; fetch full "
                        f"history (fetch-depth: 0)"]
            r = _git(root, "log", "-1", "--format=%H", "--",
                     EVENTS_DIR.replace(os.sep, "/"))
            if r and r.returncode == 0 and r.stdout.strip():
                return [f"{EVENTS_DIR}: git recorded a ledger here and the tree no longer "
                        f"holds it — append-only means the ledger, once begun, stays whole"]
        return out

    in_git = _is_git(root)
    if in_git and _is_shallow(root):
        return [f"{EVENTS_DIR}: this checkout's git history is SHALLOW — the ledger's "
                f"append-only guarantees cannot be verified, and an unverifiable ledger is "
                f"refused, never assumed. Fetch full history (fetch-depth: 0)."]

    cp = {}
    if os.path.exists(os.path.join(root, CHECKPOINTS)):
        try:
            cp = _checkpoints(root).get("heads") or {}
        except LedgerError as e:
            out.append(str(e))

    seen_objects = set()
    for entry in sorted(os.listdir(base)):
        d = os.path.join(base, entry)
        if not os.path.isdir(d):
            continue
        if not UUID4.match(entry):
            out.append(f"{EVENTS_DIR}/{entry}: not an object uuid — nothing else may live "
                       f"under the ledger root")
            continue
        seen_objects.add(entry)
        out += _check_object(root, entry, cp.get(entry))

    for obj, head in sorted(cp.items()):
        if obj not in seen_objects:
            out.append(f"{CHECKPOINTS}: records a head for {obj} and the object's events "
                       f"are gone — a chain was removed whole, which append-only forbids")

    if require_claims:
        # A CLAIM IS A PROVEN RELATIONSHIP, NEVER A SIGHTING (ratified design): each
        # owning record tool validates its records against their chains, and the claims
        # module composes them - every kind covered or named, every object claimed by
        # exactly one validating record. The old text search is gone: prose, comments,
        # block scalars and decoy files satisfied it and none of them is a record.
        from rwd_tools import claims as _claims                                         # noqa: PLC0415
        _composed, cp = _claims.compose(root)
        out += settle_abandoned(root, cp, in_git and not _is_shallow(root))

    if in_git:
        out += _check_git_immutability(root)
    return out


# --------------------------------------------------------------------------- retirement
# A DELETED RECORD LEAVES AN ORPHAN NOTHING COULD SETTLE (2026-09-07). products/oncology/
# gist_program/202606 was deleted on purpose, its material's chain stayed (append-only), and
# `--check` exited 1 at HEAD saying the record "was deleted, re-pointed, or has diverged" with
# no governed way out: the chain cannot be removed, and re-creating the pack to satisfy a
# checker would be a fiction. So a chain whose subject git records as DELETED is named as
# ORPHANED with that commit, and a person settles it by recording the retirement.

ABANDONED_MARK = "VALIDATES against this object"


def deleted_subject(root, object_uuid):
    """(deletion commit, [paths]) for the absent owning record's recorded deletion;
    None when the record remains or ownership/deletion cannot be verified,
    "SHALLOW" when history cannot say.

    Kind-agnostic on purpose: each owning tool writes the object_uuid back into its own record
    (source_refs.yaml, an approval form, a decision register), so the file that carried the uuid
    owns its lineage. Later reports and copies may mention the same uuid without becoming its
    subject. Deleting those must not change an immutable retirement's evidence."""
    if not _is_git(root):
        return None
    if _is_shallow(root):
        return "SHALLOW"
    r = _git(root, "log", "--diff-filter=D", "--format=%H", "--name-only", f"-S{object_uuid}",
             "--", ".", f":(exclude){EVENTS_DIR.replace(os.sep, '/')}")
    if not r or r.returncode != 0:
        return None
    sha, deletions = None, {}
    for tok in r.stdout.splitlines():                       # newest first
        tok = tok.strip()
        if not tok:
            continue
        if re.fullmatch(r"[0-9a-f]{40}", tok):
            sha = tok
        elif sha is not None:
            deletions.setdefault(sha, []).append(tok)
    for sha, paths in deletions.items():
        ownership = {path: owns_object_uuid(root, path, object_uuid) for path in paths}
        if any(value is None for value in ownership.values()):
            return None                                      # unverifiable is never permission to retire
        owned = sorted(path for path, value in ownership.items() if value)
        if not owned:
            continue                                         # deleted diagnostics/copies are not the subject
        if any(os.path.exists(os.path.join(root, p.replace("/", os.sep))) for p in owned):
            return None                                      # the record is back: not a deletion orphan
        return sha, owned
    return None


def head_action(root, object_uuid):
    """The newest non-attestation act on the chain, or ""."""
    act = ""
    for _seq, fname in _event_files(root, object_uuid):
        doc, err = read_event(root, object_uuid, fname)
        if not err and isinstance(doc, dict) and doc.get("action") != "attested":
            act = str(doc.get("action") or "")
    return act


def retirement_error(root, object_uuid, payload):
    """A retirement closes the subject's recorded deletion, not merely its label."""
    if not isinstance(payload, dict):
        return "retirement payload must record subject_paths and deleted_in_commit"
    paths, commit = payload.get("subject_paths"), payload.get("deleted_in_commit")
    if not isinstance(paths, list) or not paths or any(
            not isinstance(p, str) or not p or p.startswith(("/", "\\"))
            or "\\" in p or ":" in p or any(v in ("", ".", "..") for v in p.split("/"))
            for p in paths):
        return "retirement subject_paths must name nonempty repository-relative deleted records"
    if len(set(paths)) != len(paths) or not re.fullmatch(r"[0-9a-f]{40}", str(commit or "")):
        return "retirement needs unique subject_paths and the full deleted_in_commit"
    gone = deleted_subject(root, object_uuid)
    if not isinstance(gone, tuple):
        return "retirement deletion cannot be verified against complete Git history and the absent subject"
    if gone != (commit, sorted(paths)):
        return "retirement evidence does not match the subject paths and deletion commit in Git"
    return None


def settle_abandoned(root, problems, history_available):
    """The claims problems, with a RETIRED chain's abandonment dropped (it is settled) and a
    chain whose subject git records as deleted renamed ORPHANED, naming the deletion commit
    and the one governed way to settle it. Every other problem passes through verbatim."""
    out = []
    for p in problems:
        m = re.match(rf"^{re.escape(EVENTS_DIR)}[\\/]([0-9a-f-]{{36}}): ", p)
        if not m or ABANDONED_MARK not in p:
            out.append(p)
            continue
        obj = m.group(1)
        if head_action(root, obj) == "retired":
            continue
        gone = deleted_subject(root, obj) if history_available else None
        if isinstance(gone, tuple):
            sha, paths = gone
            out.append(f"{EVENTS_DIR}/{obj}: ORPHANED chain. Its record ({', '.join(paths)}) "
                       f"was deleted in commit {sha[:12]} and nothing in the tree claims it "
                       f"now. The chain stays, because the ledger is append-only; a person "
                       f"settles it by recording its retirement, naming that deletion: "
                       f"python platform/tools/event_ledger.py --retire {obj} "
                       f"--deleted-in {sha[:12]}")
        else:
            out.append(p)
    return out


def _git_identity(root):
    """(name, email) git will attribute the next commit in this checkout to, or (None, why)."""
    name = _git(root, "config", "user.name")
    email = _git(root, "config", "user.email")
    name = (name.stdout.strip() if name and name.returncode == 0 else "")
    email = (email.stdout.strip() if email and email.returncode == 0 else "")
    if not name:
        return None, ("git has no name configured for this checkout, so the person who will "
                      "commit the retirement cannot be transcribed; configure your git name "
                      "and email, then retry")
    bad = pg.not_a_person(name)
    if bad:
        return None, f"the configured git name {name!r} is not a person's name: {bad}"
    return (name, email or name), None


def retire(root, object_uuid, deleted_in, now_utc=None):
    """Append the closing `retired` event to one chain whose record was deleted. Returns
    (event, None), or (None, why) with nothing written. The event's payload is the subject
    path(s) and the FULL deletion commit; the actor is transcribed from the git identity that
    will commit the retirement, never typed. A second retirement with the same commit returns
    the first event."""
    import datetime as _dt                                                # noqa: PLC0415
    object_uuid = str(object_uuid or "").strip()
    if not UUID4.match(object_uuid):
        return None, f"{object_uuid!r} is not an object uuid"
    if not _event_files(root, object_uuid):
        return None, f"{EVENTS_DIR}/{object_uuid}: no such chain in this checkout's ledger"
    if not _is_git(root):
        return None, ("a retirement names the commit that deleted the record, and this folder "
                      "is not a git checkout")
    if _is_shallow(root):
        return None, ("this checkout's git history is shallow, so the deletion cannot be "
                      "verified; fetch full history and retry")
    if not str(deleted_in or "").strip():
        return None, "--deleted-in must name the commit that deleted the record"
    rv = _git(root, "rev-parse", "--verify", "--quiet", f"{str(deleted_in).strip()}^{{commit}}")
    if not rv or rv.returncode != 0 or not re.fullmatch(r"[0-9a-f]{40}", rv.stdout.strip()):
        return None, f"commit {deleted_in!r} is not in this checkout's history"
    full = rv.stdout.strip()
    try:
        cps = _checkpoints(root).get("heads") or {}
    except LedgerError as e:
        return None, str(e)
    defects = _check_object(root, object_uuid, cps.get(object_uuid))
    if defects:
        return None, (f"{EVENTS_DIR}/{object_uuid}: the chain does not validate, and a "
                      f"retirement seals only a valid chain:\n  - " + "\n  - ".join(defects))
    prior = []
    for _seq, fname in _event_files(root, object_uuid):
        doc, err = read_event(root, object_uuid, fname)
        if not err and isinstance(doc, dict):
            prior.append(doc)
    already = next((d for d in prior if d.get("action") == "retired"), None)
    if already is not None:
        return already, None
    gone = deleted_subject(root, object_uuid)
    if gone == "SHALLOW":
        return None, "git history is shallow; fetch full history and retry"
    if not isinstance(gone, tuple):
        return None, (f"{EVENTS_DIR}/{object_uuid}: the tree still holds a record carrying "
                      f"this object, or git recorded no deletion of one; a chain is retired "
                      f"only when its record is gone and the deletion is committed")
    sha, paths = gone
    if sha != full:
        return None, (f"commit {deleted_in} did not delete the record for this chain; git "
                      f"records the deletion of {', '.join(paths)} in commit {sha[:12]}. "
                      f"Name that commit.")
    ident, why = _git_identity(root)
    if why:
        return None, why
    name, email = ident
    actor = {"subject_id": email, "identity_provider": "git", "display_name": name,
             "role": "retirement-committer", "trust_level": "typed"}
    now = now_utc or _dt.datetime.now(_dt.timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
    try:
        _seq, head = head_of(root, object_uuid)
        event = append_event(root, object_uuid=object_uuid,
                             object_kind=str(prior[0].get("object_kind")), action="retired",
                             actor=actor, occurred_at=now,
                             payload={"subject_paths": paths, "deleted_in_commit": full},
                             expected_previous_event_sha256=head,
                             idempotency_key=f"retire:{object_uuid}:{full[:16]}")
    except LedgerError as e:
        return None, str(e)
    except OSError as e:
        return None, (f"the event could not be written ({e}); nothing was appended. Check "
                      f"that governance/events is writable, then retry")
    return event, None


def _check_object(root, object_uuid, checkpoint):
    out = []
    rel = f"{EVENTS_DIR}/{object_uuid}"
    files = _event_files(root, object_uuid)
    seqs = [s for s, _f in files]
    dupes = sorted({s for s in seqs if seqs.count(s) > 1})
    for s in dupes:
        out.append(f"{rel}: {seqs.count(s)} files claim seq {s} — a concurrent fork is "
                   f"rejected, never merged; one of them was appended against a stale head")
    expect_prev, keys, all_shas = "", {}, {}
    genesis_kind, prev_ts, acts = None, None, []
    for i, (seq, fname) in enumerate(files):
        where = f"{rel}/{fname}"
        doc, err = read_event(root, object_uuid, fname)
        if err or not isinstance(doc, dict):
            out.append(f"{where}: unreadable ({err or 'not a mapping'})")
            expect_prev = None
            continue
        if doc.get("schema_version") != SCHEMA_VERSION \
                or doc.get("canonicalization_version") != CANONICALIZATION_VERSION \
                or doc.get("hash_algorithm") != HASH_ALGORITHM:
            out.append(f"{where}: unknown schema/canonicalization/hash version — refused, "
                       f"never best-effort")
            expect_prev = None
            continue
        # EXACT KEYS, both directions (earlier review: a forged extra `signature`
        # field was EXCLUDED when the digest was rebuilt from the known list, so the
        # forgery neither broke the hash nor was named)
        missing = [f for f in EVENT_FIELDS if f not in doc]
        extra = sorted(set(doc) - set(EVENT_FIELDS))
        if missing:
            out.append(f"{where}: missing {', '.join(missing)}")
            expect_prev = None
            continue
        if extra:
            out.append(f"{where}: carries fields outside the schema: {', '.join(extra)} — "
                       f"an event is exactly its schema; anything else is a forgery vector")
        m = re.match(r"^(\d{4})-([0-9a-f-]{36})\.yaml$", fname)
        if m and (int(m.group(1)) != int(doc.get("seq") or -1)
                  or m.group(2) != str(doc.get("event_id"))):
            out.append(f"{where}: filename does not agree with the event's own seq/event_id "
                       f"— a renamed or transplanted event")
        if not UUID4.match(str(doc.get("event_id") or "")):
            out.append(f"{where}: event_id is not a uuid4")
        if seq != i + 1 and seq not in dupes:
            out.append(f"{rel}: seq jumps to {seq} where {i + 1} was expected — a gap is a "
                       f"removed event")
        if str(doc.get("object_uuid")) != object_uuid:
            out.append(f"{where}: object_uuid disagrees with its directory")
        kind = str(doc.get("object_kind") or "")
        if kind not in OBJECT_KINDS:
            out.append(f"{where}: object_kind {kind!r} is not in the vocabulary")
        if i == 0:
            genesis_kind = kind
        elif kind != genesis_kind:
            out.append(f"{where}: object_kind {kind!r} differs from the genesis "
                       f"{genesis_kind!r} — a kind is identity, not a field to drift")
        act = doc.get("action")
        if act not in ACTIONS:
            out.append(f"{where}: action {act!r} is not in the vocabulary")
        elif kind in KIND_ACTIONS and act not in KIND_ACTIONS[kind] + UNIVERSAL_ACTIONS:
            out.append(f"{where}: a {kind} records {KIND_ACTIONS[kind]} (plus "
                       f"attested/legacy_imported/retired), never {act!r}")
        else:
            lerr = lifecycle_error(kind, acts, act)
            if lerr:
                out.append(f"{where}: {lerr}")
            acts.append(act)
        ts = _parse_rfc3339(doc.get("occurred_at"))
        if ts is None:
            out.append(f"{where}: occurred_at {doc.get('occurred_at')!r} is not a real "
                       f"RFC 3339 instant with a known offset")
        elif prev_ts is not None and ts < prev_ts:
            out.append(f"{where}: occurred_at precedes the previous event's — a chain runs "
                       f"forward in time or it describes a different history")
        prev_ts = ts if ts is not None else prev_ts
        actor = doc.get("actor")
        if not isinstance(actor, dict) or any(not str(actor.get(f) or "").strip()
                                              for f in ACTOR_FIELDS):
            out.append(f"{where}: actor is not a complete structured identity "
                       f"({', '.join(ACTOR_FIELDS)})")
        elif actor.get("trust_level") not in ALLOWED_TRUST:
            out.append(f"{where}: actor.trust_level {actor.get('trust_level')!r} — "
                       f"`authenticated` arrives only from signature verification, which "
                       f"does not exist yet; anything else is unknown")
        elif actor.get("trust_level") != "unauthenticated_legacy" \
                and pg.not_a_person(actor.get("display_name")):
            out.append(f"{where}: actor.display_name "
                       f"{pg.not_a_person(actor.get('display_name'))}")
        elif any(pg.unstated(actor.get(f)) for f in ("subject_id", "display_name")):
            out.append(f"{where}: the actor is a placeholder — an act attributed to TBD "
                       f"is attributed to nobody")
        key = str(doc.get("idempotency_key") or "")
        if not key.strip():
            out.append(f"{where}: idempotency_key is blank — a retry could never find this")
        if key in keys:
            out.append(f"{where}: idempotency_key duplicates {keys[key]} — a retry returned "
                       f"as a second event")
        keys[key] = fname
        # a stored value the canonical form cannot carry (NaN, Infinity) is a NAMED finding,
        # never a crash — a follow-up review: the validator RAISED on it, so the worst
        # possible event was the one that stopped validation instead of failing it
        if not isinstance(doc.get("payload"), dict):
            out.append(f"{where}: payload is not a mapping")
        else:
            try:
                blob = canonical_json(doc["payload"]).encode("utf-8")
            except LedgerError as e:
                blob = None
                out.append(f"{where}: payload cannot be canonicalized ({e})")
            if blob is not None:
                if len(blob) > PAYLOAD_CAP_BYTES:
                    out.append(f"{where}: payload is {len(blob)} bytes canonical — over "
                               f"the {PAYLOAD_CAP_BYTES}-byte cap the door enforces; a "
                               f"stored over-cap payload was written around the library")
                if hashlib.sha256(blob).hexdigest() != str(doc.get("payload_sha256")):
                    out.append(f"{where}: payload_sha256 does not recompute — the payload "
                               f"changed after the event was written, which immutable "
                               f"forbids")
        if act == "retired":
            why = retirement_error(root, object_uuid, doc.get("payload"))
            if why:
                out.append(f"{where}: {why}")
        # the digest is over the STORED document minus event_sha256, so an injected field
        # breaks the hash instead of being quietly excluded
        try:
            ed = event_digest(doc)
        except LedgerError:
            ed = None
            out.append(f"{where}: the stored document cannot be canonicalized, so "
                       f"event_sha256 cannot be verified — refused, never assumed intact")
        if ed is not None and ed != str(doc.get("event_sha256")):
            out.append(f"{where}: event_sha256 does not recompute — the event was edited")
        if doc.get("action") == "attested":
            for f in ATTESTATION_FIELDS:
                if not str((doc.get("payload") or {}).get(f) or "").strip():
                    out.append(f"{where}: attested event leaves {f} unstated — a signature "
                               f"over nothing signs nothing")
        if expect_prev is not None and seq not in dupes \
                and str(doc.get("previous_event_sha256")) != expect_prev:
            out.append(f"{where}: previous_event_sha256 does not consume the prior event — "
                       f"the chain is broken or an event between them was replaced")
        expect_prev = str(doc.get("event_sha256")) if expect_prev is not None else None
        all_shas[str(doc.get("event_sha256"))] = fname
        # an attestation must point at an event that exists in this object
        if doc.get("action") == "attested":
            tgt = str((doc.get("payload") or {}).get("target_event_sha256") or "")
            if tgt and tgt not in all_shas:
                out.append(f"{where}: attests {tgt[:12]}… which is not an earlier event of "
                           f"this object — a signature over nothing signs nothing")
    if files and checkpoint is None:
        out.append(f"{CHECKPOINTS}: no head recorded for {object_uuid} — the checkpoint is "
                   f"part of the append, not an afterthought")
    elif files and expect_prev is not None:
        seq, sha = seqs[-1], expect_prev
        if int(checkpoint.get("seq") or 0) != seq or str(checkpoint.get("event_sha256")) != sha:
            out.append(f"{CHECKPOINTS}: head for {object_uuid} says seq "
                       f"{checkpoint.get('seq')} ({str(checkpoint.get('event_sha256'))[:12]}…) "
                       f"but the chain ends at seq {seq} ({sha[:12]}…) — a tail was removed "
                       f"or the checkpoint was hand-edited")
    return out


def _check_git_immutability(root):
    """Every event path git ever recorded still exists with its FIRST committed bytes, and
    the checkpoint's history never showed a higher seq than the present — the two questions
    the working tree cannot answer about itself."""
    out = []
    r = _git(root, "log", "--reverse", "--format=%H", "--", EVENTS_DIR.replace(os.sep, "/"))
    if not r or r.returncode != 0:
        return out
    commits = r.stdout.split()
    first_bytes = {}
    for sha in commits:
        lst = _git(root, "ls-tree", "-r", "--name-only", sha,
                   EVENTS_DIR.replace(os.sep, "/"))
        if not lst or lst.returncode != 0:
            continue
        for p in lst.stdout.split("\n"):
            p = p.strip()
            if not p or not re.search(r"/\d{4}-[0-9a-f-]{36}\.yaml$", p):
                continue
            if p not in first_bytes:
                raw = _committed_bytes(root, sha, p)
                if raw is not None:
                    first_bytes[p] = raw
    for p, want in sorted(first_bytes.items()):
        ap = os.path.join(root, p.replace("/", os.sep))
        if not os.path.exists(ap):
            out.append(f"{p}: git recorded this event and the tree no longer holds it — "
                       f"append-only means every event ever committed stays")
            continue
        with open(ap, "rb") as fh:
            got = fh.read()
        if got != want:
            out.append(f"{p}: bytes differ from the first committed version — an immutable "
                       f"event was edited in place (line endings included: a non-Python "
                       f"signer reproduces bytes, not conventions)")
    # the checkpoint's own history: heads only advance
    cp_rel = CHECKPOINTS.replace(os.sep, "/")
    highest = {}
    for sha in commits:
        b = _git(root, "show", f"{sha}:{cp_rel}", "--")
        if not b or b.returncode != 0:
            continue
        try:
            import yaml # noqa: PLC0415
            doc = yaml.safe_load(b.stdout) or {}
        except Exception: # noqa: BLE001
            continue
        for obj, head in (doc.get("heads") or {}).items():
            s = int((head or {}).get("seq") or 0)
            highest[obj] = max(highest.get(obj, 0), s)
    if os.path.exists(os.path.join(root, CHECKPOINTS)):
        try:
            now = _checkpoints(root).get("heads") or {}
        except LedgerError:
            now = {}
        for obj, hi in sorted(highest.items()):
            cur = int((now.get(obj) or {}).get("seq") or 0)
            if cur < hi:
                out.append(f"{cp_rel}: head for {obj} moved BACKWARD (history recorded seq "
                           f"{hi}, now {cur}) — heads only ever advance; a lower head is a "
                           f"deleted tail wearing a checkpoint")
    return out


def main(argv):
    ap = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    ap.add_argument("--check", action="store_true", help="exit non-zero on any defect")
    ap.add_argument("--retire", metavar="OBJECT_UUID",
                    help="record the retirement of a chain --check names ORPHANED: its record was "
                         "deleted on purpose and nothing in the tree claims it. Appends one closing "
                         "`retired` event naming the record and the deletion commit; the actor is "
                         "the git identity that commits it. Types no name, date or reason.")
    ap.add_argument("--deleted-in", metavar="COMMIT",
                    help="with --retire: the commit that deleted the record (--check prints it). "
                         "A commit that did not delete it is refused.")
    a = ap.parse_args(argv)
    if a.retire:
        if not a.deleted_in:
            print("REFUSED - --retire needs --deleted-in <commit>, the commit that deleted the "
                  "record; event_ledger.py --check prints it beside the ORPHANED chain",
                  file=sys.stderr)
            return 1
        import datetime as _dt                                            # noqa: PLC0415
        now = _dt.datetime.now(_dt.timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
        event, why = retire(REPO, a.retire, a.deleted_in, now)
        if why:
            print(f"REFUSED - {why}", file=sys.stderr)
            return 1
        pl = event.get("payload") or {}
        if str(event.get("occurred_at")) != now:             # a replay: the first retirement stands
            print(f"already retired {a.retire} seq {event['seq']} on {event.get('occurred_at')} "
                  f"(commit {str(pl.get('deleted_in_commit'))[:12]}); nothing new recorded")
            return 0
        print(f"retired {a.retire} seq {event['seq']}: record {', '.join(pl.get('subject_paths') or [])} "
              f"deleted in commit {str(pl.get('deleted_in_commit'))[:12]}; event "
              f"{str(event.get('event_sha256'))[:16]}. Commit governance/events/ to complete "
              f"the act; the commit's author is the actor.")
        return 0
    if a.deleted_in:
        print("REFUSED - --deleted-in goes with --retire <object uuid>", file=sys.stderr)
        return 1
    problems = check(require_claims=True)
    base = os.path.join(REPO, EVENTS_DIR)
    n_obj = len([e for e in os.listdir(base)
                 if os.path.isdir(os.path.join(base, e))]) if os.path.isdir(base) else 0
    if not problems:
        print(f"{n_obj} object(s); every chain validates, every committed event is "
              f"byte-identical to its first commit, and every head matches its checkpoint")
        return 0
    print(f"{len(problems)} ledger defect(s) -")
    for p in problems:
        print(f"  - {p}")
    return 1 if a.check else 0


if __name__ == "__main__":
    from rwd_tools.console import use_utf8
    use_utf8()
    sys.exit(main(sys.argv[1:]))
