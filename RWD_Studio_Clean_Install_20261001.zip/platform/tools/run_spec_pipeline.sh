#!/usr/bin/env bash
# Thin wrapper. The pipeline itself is run_spec_pipeline.py — one definition, so a machine without
# bash (a Windows checkout doing UAT) can run Gate 2 and the --check drift verification directly:
#
#     python3 platform/tools/run_spec_pipeline.py <product-dir> [--check] [--strict]
#
# This file stays because CI, the docs and muscle memory all call it.
set -euo pipefail
# UTF-8 DETERMINISTICALLY: under the Windows default cp1252 console the pipeline
# crashed on its own '∪' - the encoding must not depend on which terminal launched it. Set on
# the exec line itself so the script stays a single delegating statement.
exec env PYTHONUTF8=1 PYTHONIOENCODING=utf-8 python3 "$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)/run_spec_pipeline.py" "$@"
