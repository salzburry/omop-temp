#!/usr/bin/env python3
"""Render one page per open decision, for the person who has to answer it.

    python platform/tools/decision_packet.py <pack> --out packet.html
    python platform/tools/decision_packet.py <pack> --text        # same content, terminal

Each page assembles everything an answerer needs: the question, the evidence the register
holds, how many contract records it blocks, and what other tumours decided on the same
question. It composes from the tools that own each fact (contract_lint, decision_report,
the precedents store); it computes nothing of its own.

It writes nothing to the pack and it is not an approval — recording an answer is
`decision_record.py`'s job, and the page says so on itself.

stdlib only (plus PyYAML through the tools it calls).
"""
import argparse
import html
import os
import re
import sys

TOOLS = os.path.dirname(os.path.abspath(__file__))
from rwd_services import workspace_root
ROOT = str(workspace_root(__file__))
from rwd_tools.spec_extract import repo_relative                                  # noqa: E402

from rwd_tools import contract_lint      # noqa: E402
from rwd_tools import decision_report    # noqa: E402
from rwd_tools import precedents         # noqa: E402

DECISIONS = os.path.join("handoff", "DECISIONS.md")

# HOW AN ANSWER GETS RECORDED, stated on the page — because this page cannot do it.
#
# Building this page is what forced the gap into the open: three fields a stakeholder's answer needs
# — who, when, bound to which question — that the decisions table originally had nowhere to put.
# The registers now carry `Approved by` / `Approval date`, and `decision_record.py` is the write
# side: a hand-typed, committed answer form per decision, transcribed fail-closed, with the form's
# `question_sha256` binding the answer to the question as issued. This page still WRITES NOTHING —
# it shows the question and says where the answer goes, because a page that quietly offered a
# signature box with no recording path would be collecting attestations into a void.
RECORDING = (
    ("who answered and when", "typed BY HAND into the form's `answered_by` / `answer_date` — "
     "there is no flag or box that can supply a person"),
    ("what exactly was answered", "the form's `question_sha256` — an answer to a question that "
     "has since changed is refused, not transcribed"),
    ("the answer itself", "`handoff/decision_answers/<ID>.yaml`, committed; the register row is "
     "the index, the form is the attestation"),
)


def _blocks(pack, root):
    """{decision id: [blocked variable ids]} — from the tool that owns it."""
    blocking, _table, _idle, _status = decision_report.blast_radius(os.path.join(root, pack))
    return blocking


def _elsewhere(pack, root):
    """{decision id: [(other pack, other decision, status, answer)]} from the advisory store.

    Keyed off the store's own `seen_in` pairs, not by matching question text: two registers phrase
    one question differently on purpose, and a matcher good enough to pair them is good enough to
    pair two that merely sound alike.
    """
    entries, bad = precedents.load(root)
    if bad:
        # A packet with the cross-product context silently removed reads as "no precedent exists" —
        # a false statement shown to the person about to answer. Same fail-closed rule as the store's
        # own --check.
        raise SystemExit("governance/precedents.yaml is unreadable — the packet will not render "
                         "without its precedent context:\n  " + "\n  ".join(bad))
    out = {}
    for entry in entries:
        seen = entry.get("seen_in") or []
        mine = [s for s in seen if s.get("pack") == pack]
        if not mine:
            continue
        for s in mine:
            for other in seen:
                if other.get("pack") == pack:
                    continue
                opack, odid = other.get("pack"), other.get("decision")
                # PRODUCTS ONLY. The store also indexes parked test fixtures (its own comments
                # say which) — an external review found a fixture pack's register rendered under
                # "What other products decided", which no product ever decided.
                if not str(opack or "").startswith("products/"):
                    continue
                path = os.path.join(root, opack or "", DECISIONS)
                if not os.path.exists(path):
                    continue
                text = contract_lint.read(path)
                rows, status = contract_lint.decision_rows(text), contract_lint.decision_status(text)
                if odid not in rows:
                    continue
                # ...and DECIDED only. The heading says "decided"; an OPEN row elsewhere is a
                # question nobody has answered, and showing it as evidence invites the answerer
                # to treat another register's guess as a ruling.
                if status.get(odid) != "RESOLVED":
                    continue
                out.setdefault(s.get("decision"), []).append(
                    (opack, odid, status.get(odid, ""),
                     contract_lint.decision_answer(rows[odid]) or ""))
    return out


SPEC_QC = os.path.join("handoff", "SPEC_QC_FINDINGS.md")


def findings(pack, root=ROOT):
    """(for Science, capture defects, note) — the pack's OPEN specification-QC findings, split.

    The register keeps two tables with one header (its own comment explains why): defects in Science's
    document, then defects introduced by the delivery FORMAT, which resolve by re-extracting and are
    not Science's to correct. Shown apart because handing someone a defect list where a third of the
    rows are not theirs teaches them the list is not for them. The split is the file's own physical
    structure — rows above the second header are Science's — not a guess from prose.
    """
    path = os.path.join(root, pack, SPEC_QC)
    if not os.path.exists(path):
        return [], [], f"{pack} keeps no {SPEC_QC} — no findings were assembled."
    text = contract_lint.read(path)
    headers = [i for i, l in enumerate(text.splitlines())
               if l.startswith("|") and re.search(contract_lint.id_column_re(), l)]
    first_part = text if len(headers) < 2 else "\n".join(text.splitlines()[:headers[1]])
    rwb_ids = set(contract_lint.decision_rows(first_part))

    out_rwb, out_capture = [], []
    for fid, row in sorted(contract_lint.decision_rows(text).items()):
        if contract_lint._status_text(contract_lint.cell(row, "Status")) != "OPEN":
            continue
        item = {"id": fid,
                "ref": contract_lint.cell(row, "Spec ref").strip(),
                "defect": contract_lint.cell(row, "Defect").strip(),
                "impact": contract_lint.cell(row, "Impact").strip(),
                "disposition": contract_lint.cell(row, "Disposition").strip()}
        (out_rwb if fid in rwb_ids else out_capture).append(item)
    return out_rwb, out_capture, None


def _proposal(elsewhere):
    """A labelled starting answer, or None — assembled ONLY from a ruling a person already made.

    THE RULE THAT KEEPS THIS FROM BEING A RULING. The packet carries pre-drafted
    answers so a blank form stops being a research task; the line this must not cross is the one
    every tool here holds — the tool never decides. So a proposal exists in exactly one case:
    EXACTLY ONE other product has a RESOLVED ruling paired to this question through the precedents
    store. Then the proposal is that answer VERBATIM, with its source named — adopting a recorded
    ruling is a review, not a fresh judgment.

    ZERO rulings: no proposal — nothing recorded points a direction, and drafting one from the
    evidence prose would be this tool interpreting a specification, which is Science's act.

    TWO OR MORE rulings: no proposal, and the refusal is SAID — choosing which product's ruling
    transfers is precisely the judgment the page exists to route to a person. Comparing the answer
    texts for "agreement" would be prose interpretation wearing a helpful face: two registers
    phrase one ruling differently on purpose (the same reason `_elsewhere` refuses text matching).
    """
    decided = [(opack, odid, ans) for opack, odid, st, ans in elsewhere
               if st == "RESOLVED" and str(ans or "").strip()]
    if len(decided) == 1:
        opack, odid, ans = decided[0]
        return {"answer": ans.strip(), "source": f"{opack} · {odid}"}
    if len(decided) > 1:
        return {"conflict": [f"{opack} · {odid}" for opack, odid, _a in decided]}
    return None


ANSWER_FORMS = os.path.join("handoff", "decision_answers")


def _form_state(pack, did, root):
    """Where THIS decision's answer form is, or how to get one — per card, because "whoever sent
    you this page can hand you the forms" made the reader ask exactly that question."""
    rel = os.path.join(pack, ANSWER_FORMS, f"{did}.yaml").replace(os.sep, "/")
    if os.path.exists(os.path.join(root, pack, ANSWER_FORMS, f"{did}.yaml")):
        return {"path": rel, "exists": True}
    return {"path": rel, "exists": False}


def packet(pack, root=ROOT):
    """(decisions, note) — every OPEN decision, ranked by how many records it blocks.

    `note` is not None when nothing could be assembled, and it is a REFUSAL rather than an empty
    list: "no open decisions" and "this pack keeps no register" are opposite answers, and a page
    that renders the second as the first tells a stakeholder there is nothing to do.
    """
    path = os.path.join(root, pack, DECISIONS)
    if not os.path.exists(path):
        return [], f"{pack} keeps no handoff/DECISIONS.md — there is no register to read, so nothing was assembled."

    text = contract_lint.read(path)
    rows = contract_lint.decision_rows(text)
    status = contract_lint.decision_status(text)
    if not rows:
        return [], f"{pack}'s decisions register holds no readable rows — nothing was assembled."

    blocks, elsewhere = _blocks(pack, root), _elsewhere(pack, root)
    out = []
    for did, row in rows.items():
        if str(status.get(did, "OPEN")).strip().upper() != "OPEN":
            continue
        out.append({
            "id": did,
            "question": (contract_lint.decision_question(row) or "").strip(),
            "evidence": (contract_lint.decision_evidence(row) or "").strip(),
            "owner": (contract_lint.decision_owner(row) or "").strip(),
            "blocks": sorted(blocks.get(did, [])),
            "elsewhere": elsewhere.get(did, []),
            "proposal": _proposal(elsewhere.get(did, [])),
            "form": _form_state(pack, did, root),
        })
    out.sort(key=lambda d: (-len(d["blocks"]), d["id"]))
    return out, None


# --------------------------------------------------------------------------- rendering
def _h(s):
    return html.escape(str(s or ""))


def render_html(pack, root=ROOT):
    items, note = packet(pack, root)
    head = [
        "<!doctype html><meta charset='utf-8'>",
        f"<title>Decisions to answer — {_h(pack)}</title>",
        "<style>",
        "body{font:16px/1.55 system-ui,-apple-system,Segoe UI,Roboto,sans-serif;color:#16191c;",
        "background:#f4f5f6;margin:0;padding:32px 20px;}",
        ".w{max-width:820px;margin:0 auto;}",
        "h1{font:600 26px/1.2 Georgia,serif;margin:0 0 6px;}",
        ".sub{color:#5a6169;margin:0 0 26px;}",
        ".d{background:#fff;border:1px solid #d3d7db;border-radius:3px;margin:0 0 22px;",
        "padding:22px 24px;}",
        ".id{font:11px/1 ui-monospace,Menlo,monospace;letter-spacing:.1em;color:#7a838c;}",
        ".q{font:600 19px/1.35 Georgia,serif;margin:8px 0 14px;}",
        "h4{font:11px/1 ui-monospace,Menlo,monospace;letter-spacing:.1em;text-transform:uppercase;",
        "color:#7a838c;margin:18px 0 7px;}",
        ".ev{color:#3d444b;}",
        ".blocks{font:13px/1.6 ui-monospace,Menlo,monospace;color:#3d444b;overflow-wrap:anywhere;}",
        ".n{display:inline-block;background:#fbeceb;color:#b4231a;border:1px solid #b4231a;",
        "border-radius:2px;padding:3px 9px;font:11px/1 ui-monospace,monospace;letter-spacing:.08em;}",
        ".other{border-left:3px solid #d3d7db;padding:2px 0 2px 14px;margin:9px 0;color:#3d444b;}",
        ".other .p{font:11px/1.5 ui-monospace,Menlo,monospace;color:#7a838c;}",
        ".prop{background:#eef4ee;border:1px solid #9db89d;border-left:4px solid #2e6b34;",
        "padding:14px 18px;margin:16px 0 0;}",
        ".prop .tag{font:11px/1 ui-monospace,Menlo,monospace;letter-spacing:.1em;",
        "color:#2e6b34;text-transform:uppercase;}",
        ".prop .src{font:12px/1.5 ui-monospace,Menlo,monospace;color:#5a6169;margin-top:8px;}",
        ".form{font:12px/1.6 ui-monospace,Menlo,monospace;color:#5a6169;margin-top:10px;",
        "overflow-wrap:anywhere;}",
        ".ans{margin-top:26px;border-top:1px dashed #c8ccd0;padding-top:16px;}",
        ".ans .line{border-bottom:1px solid #c8ccd0;height:26px;margin:9px 0;}",
        ".warn{background:#fff8e6;border:1px solid #e0cd8f;border-left:4px solid #b98900;",
        "padding:16px 20px;margin:0 0 26px;color:#4a3c11;}",
        ".warn b{color:#7a6224;}",
        "footer{color:#7a838c;font-size:13px;margin-top:30px;}",
        "@media print{body{background:#fff;padding:0;}.d{break-inside:avoid;}}",
        "</style>", "<div class='w'>",
    ]
    if note:
        return "\n".join(head + [f"<h1>Nothing to answer</h1><p class='sub'>{_h(note)}</p>",
                                 "</div>"])

    L = head + [
        f"<h1>Decisions to answer — {_h(pack)}</h1>",
        f"<p class='sub'>{len(items)} open question(s), ordered by how much each one unblocks. "
        "You are being asked to decide, not to edit anything.</p>",
        "<div class='warn'><b>Before you answer.</b> This page shows the question and records "
        "nothing. Your answer is recorded through a form you type and commit — one per decision, "
        "written by <code>decision_record.py --forms</code> — covering " +
        _h("; ".join(w for w, _why in RECORDING)) +
        ". Whoever sent you this page can hand you the forms.</div>",
    ]
    for d in items:
        L.append("<div class='d'>")
        L.append(f"<div class='id'>{_h(d['id'])}"
                 + (f" &nbsp;·&nbsp; owner: {_h(d['owner'])}" if d["owner"] else "") + "</div>")
        L.append(f"<div class='q'>{_h(d['question'])}</div>")
        if d["evidence"]:
            L.append("<h4>What the specification says</h4>")
            L.append(f"<div class='ev'>{_h(d['evidence'])}</div>")
        L.append("<h4>What this blocks</h4>")
        if d["blocks"]:
            L.append(f"<p><span class='n'>{len(d['blocks'])} variable(s)</span></p>")
            L.append(f"<div class='blocks'>{_h(', '.join(d['blocks']))}</div>")
        else:
            L.append("<p class='ev'>No contract record is waiting on this one today. It is open, "
                     "and not on the critical path.</p>")
        if d["elsewhere"]:
            L.append("<h4>What other products decided</h4>")
            for opack, odid, ostatus, oans in d["elsewhere"]:
                L.append("<div class='other'>")
                L.append(f"<div class='p'>{_h(opack)} · {_h(odid)} · {_h(ostatus or 'OPEN')}</div>")
                L.append(f"<div>{_h(oans) if oans.strip() else '<em>still open there too</em>'}</div>"
                         if oans.strip() else "<div><em>still open there too</em></div>")
                L.append("</div>")
        prop = d.get("proposal")
        if prop and "answer" in prop:
            # VISIBLY A PROPOSAL, NEVER AN ANSWER. Accepting it is a decision the owner signs;
            # the tool only carried a ruling another person already made.
            L.append("<div class='prop'><span class='tag'>Proposed — for you to accept or "
                     "edit</span>")
            L.append(f"<div>{_h(prop['answer'])}</div>")
            L.append(f"<div class='src'>adopted verbatim from {_h(prop['source'])} — writing it "
                     "on your form makes it YOUR ruling; your name goes on it either way</div>")
            L.append("</div>")
        elif prop and "conflict" in prop:
            L.append("<div class='prop'><span class='tag'>No proposal — more than one product "
                     "has ruled</span>")
            L.append(f"<div class='src'>{_h('; '.join(prop['conflict']))} — choosing which "
                     "ruling transfers is exactly the judgment this page routes to you</div>")
            L.append("</div>")
        form = d.get("form") or {}
        if form:
            L.append("<div class='form'>your form: " + _h(form.get("path", ""))
                     + ("" if form.get("exists") else
                        " — not scaffolded yet; decision_record.py --forms writes it") + "</div>")
        L.append("<div class='ans'><h4>Your answer</h4>"
                 "<div class='line'></div><div class='line'></div>"
                 "<h4>Name and date</h4><div class='line'></div></div>")
        L.append("</div>")
    rwb, capture, fnote = findings(pack, root)
    if rwb or capture or not fnote:
        L.append("<h1 style='margin-top:40px'>Defects in the specification itself</h1>")
        L.append(f"<p class='sub'>{len(rwb)} open finding(s) that need a corrected workbook. These "
                 "are not questions — each one is a place your document contradicts itself or "
                 "states the impossible, found while tracing it requirement by requirement. "
                 "<b>Each needs exactly one act from you, once:</b> correct the cited cell in the "
                 "next revision, or waive it — confirm the current reading stands. Either closes "
                 "the finding permanently; this list only ever shrinks. <b>While a finding is "
                 "open it blocks the contract approval (Gate 2)</b> unless it has been "
                 "dispositioned — the interim reading below is how the work continues meanwhile, "
                 "not a statement that nothing waits.</p>")
        if not rwb:
            L.append("<p class='sub'>None open — every reported defect has been corrected or "
                     "waived.</p>")
        for f in rwb:
            L.append("<div class='d'>")
            L.append(f"<div class='id'>{_h(f['id'])} &nbsp;·&nbsp; {_h(f['ref'])}</div>")
            L.append(f"<div class='q'>{_h(f['defect'])}</div>")
            if f["impact"]:
                L.append("<h4>What it affects</h4>")
                L.append(f"<div class='ev'>{_h(f['impact'])}</div>")
            if f["disposition"]:
                L.append("<h4>How it is being read meanwhile</h4>")
                L.append(f"<div class='ev'>{_h(f['disposition'])}</div>")
            L.append("</div>")
        if capture:
            L.append(f"<p class='sub'>{len(capture)} further finding(s) are capture defects in the "
                     "delivery format — resolved on our side by re-extracting the workbook, not "
                     "yours to correct.</p>")
        L.append("<p class='sub'>When a corrected workbook is issued, the round-trip is verified "
                 "mechanically: <code>spec_diff.py</code> reports, per finding, whether the cited "
                 "text actually changed.</p>")
    L.append("<footer>Generated from the pack's own registers. Nothing here is an approval, and "
             "nothing was written to the pack.</footer></div>")
    return "\n".join(L)


def render_text(pack, root=ROOT):
    items, note = packet(pack, root)
    if note:
        return f"\n{note}\n"
    W = 92
    L = ["", "=" * W, f"  DECISIONS TO ANSWER — {pack}", "=" * W,
         f"  {len(items)} open question(s), ordered by how much each unblocks.", ""]
    for d in items:
        L += ["-" * W, f"  {d['id']}" + (f"   (owner: {d['owner']})" if d["owner"] else ""), "-" * W]
        L += _wrap(d["question"], 2)
        if d["evidence"]:
            L += ["", "   WHAT THE SPECIFICATION SAYS"] + _wrap(d["evidence"], 5)
        L += ["", f"   BLOCKS {len(d['blocks'])} variable(s)"]
        if d["blocks"]:
            L += _wrap(", ".join(d["blocks"]), 5)
        for opack, odid, ostatus, oans in d["elsewhere"]:
            L += ["", f"   ELSEWHERE  {opack} · {odid} · {ostatus or 'OPEN'}"]
            L += _wrap(oans or "still open there too", 5)
        prop = d.get("proposal")
        if prop and "answer" in prop:
            L += ["", "   PROPOSED — FOR YOU TO ACCEPT OR EDIT"]
            L += _wrap(prop["answer"], 5)
            L += _wrap(f"adopted verbatim from {prop['source']} — writing it on your form makes "
                       f"it YOUR ruling; your name goes on it either way", 5)
        elif prop and "conflict" in prop:
            L += ["", "   NO PROPOSAL — more than one product has ruled: "
                  + "; ".join(prop["conflict"])]
            L += _wrap("choosing which ruling transfers is exactly the judgment this page "
                       "routes to you", 5)
        form = d.get("form") or {}
        if form:
            L += ["", f"   YOUR FORM  {form.get('path', '')}"
                  + ("" if form.get("exists") else "   (not scaffolded yet — "
                     "decision_record.py --forms writes it)")]
        L.append("")
    rwb, capture, _fnote = findings(pack, root)
    if rwb:
        L += ["=" * W, f"  DEFECTS IN THE SPECIFICATION ITSELF — {len(rwb)} awaiting a corrected "
              "workbook", "=" * W,
              "  Each needs exactly ONE act, once: correct the cited cell in the next revision, or",
              "  waive it (confirm the current reading stands). Either closes it permanently — this",
              "  list only shrinks. While open, a finding BLOCKS the contract approval (Gate 2)",
              "  unless dispositioned; the interim reading is how work continues, not a pass."]
        for f in rwb:
            L += ["", f"  {f['id']}   {f['ref']}"] + _wrap(f["defect"], 5)
            if f["impact"]:
                L += _wrap("affects: " + f["impact"], 5)
        if capture:
            L += ["", f"  (+{len(capture)} capture defect(s) in the delivery format — resolved by "
                  "re-extracting, not Science's)"]
        L += ["", "  When the corrected workbook arrives, spec_diff.py verifies per finding whether",
              "  the cited text actually changed.", ""]
    L += ["=" * W,
          "  This page shows the question and records nothing. Answers are recorded through a",
          "  hand-typed, committed form per decision (decision_record.py --forms), which carries:"]
    for what, why in RECORDING:
        L.append(f"     · {what} — {why}")
    L.append("")
    return "\n".join(L)


def _wrap(text, indent):
    import textwrap
    body = " ".join(str(text or "").split())
    if not body:
        return []
    return textwrap.wrap(body, width=92 - indent,
                         initial_indent=" " * indent, subsequent_indent=" " * indent)


def main(argv):
    ap = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    ap.add_argument("pack", help="the pack directory (repo-root-relative)")
    ap.add_argument("--out", help="write the HTML page here")
    ap.add_argument("--text", action="store_true", help="print the same content as text instead")
    a = ap.parse_args(argv)

    pack = repo_relative(os.path.abspath(a.pack), ROOT)
    if not os.path.isdir(os.path.join(ROOT, pack)):
        sys.exit(f"{a.pack}: not a directory")
    if a.text or not a.out:
        print(render_text(pack))
        if not a.out:
            return 0
    # Same refusal render_html carries, for the same reason: a saved page is the shape stray HTML
    # gets committed in, and this tool was the one generator without the guard.
    if os.path.realpath(os.path.abspath(a.out)).startswith(os.path.realpath(ROOT) + os.sep):
        sys.exit(f"{a.out}: inside the checkout — write the page outside the repository "
                 f"(repo_hygiene never commits *.html, and a stray page is a finding)")
    with open(a.out, "w", encoding="utf-8", newline="\n") as fh:
        fh.write(render_html(pack))
    print(f"wrote {a.out}")
    return 0


if __name__ == "__main__":
    from rwd_tools.console import use_utf8
    use_utf8()
    sys.exit(main(sys.argv[1:]))
