#!/usr/bin/env python3
"""Build or verify a portable source ZIP; this does not approve a product.

Build uses current Git-selected working bytes, including uncommitted source. Git
history and local runtime data are omitted. CURRENT_STATE.md is regenerated
by its existing owner in a disposable fresh Git index. Complete verified retired
objects and only their checkpoint heads are omitted. ZIP order, timestamps,
permissions and the manifest are deterministic for the same inputs/runtime.
"""
from __future__ import annotations

import argparse
import hashlib
import io
import json
import os
from pathlib import Path, PurePosixPath
import re
import subprocess
import sys
import tempfile
import zipfile

from rwd_services import workspace_root
ROOT = workspace_root(__file__)
MANIFEST = "SOURCE_MANIFEST.json"
SNAPSHOT = "governance/CURRENT_STATE.md"
CHECKPOINTS = "governance/events/HEAD_CHECKPOINTS.yaml"
SIGNERS = "governance/allowed_signers.yaml"
DENIED_PARTS = {".git", ".history", ".venv", ".venv313", "venv", "__pycache__", ".pytest_cache",
                "node_modules", ".portal-uploads", ".portal-drafts", ".rwd-portal",
                ".hypothesis", "spark-warehouse", "metastore_db"}
DENIED_PREFIXES = ("experiments/agent/runs/", "experiments/agent/candidates/",
                   "experiments/agent/requests/", "experiments/vscode-model-bridge/dist/",
                   "platform/test-results/", "build/", "dist/", "tmp/", "_rehearsal/", "work/")
DENIED_NAMES = {MANIFEST, "settings.local.json", "secrets.toml", "vscode-model-bridge.json", ".source_refs.portal-edit.lock"}
DENIED_EXACT = {"experiments/portal/users.json", "experiments/agent/ml/embed_index.jsonl",
                "experiments/agent/ml/training_ledger.jsonl", "experiments/agent/ml/calibration.json",
                "experiments/agent/ml/router.json", "experiments/agent/ml/escalation.json",
                "experiments/agent/bench/results.jsonl", "uat.json"}
# Workbook inputs are compressed containers. Bound their inspection so a ZIP
# bomb or an encrypted member cannot turn an unexamined file into a clean scan.
ARCHIVE_MAX_MEMBERS = 10000
ARCHIVE_MAX_MEMBER_BYTES = 32 * 1024 * 1024
ARCHIVE_MAX_BYTES = 128 * 1024 * 1024
ARCHIVE_MAX_DEPTH = 2
OFFICE_SUFFIXES = {".xlsx", ".xlsm", ".docx", ".pptx", ".xltx", ".xltm"}
SENSITIVE_PATTERNS = {
    "provider credential": re.compile(r"(?:sk-ant-api\d{2}-|sk-proj-)[A-Za-z0-9_-]{50,}"),
    "Git credential": re.compile(r"(?:gh[pousr]_[A-Za-z0-9]{36,}|github_pat_[A-Za-z0-9_]{60,})"),
    "private key": re.compile(r"-----BEGIN (?:RSA |EC |OPENSSH |ENCRYPTED )?PRIVATE KEY-----"),
    "personal absolute path": re.compile(
        # Character classes express path separators without embedding a literal
        # workstation path in this scanner's own source (checked by repo_hygiene).
        r"(?i)(?:[a-z]:[\\/]+Users[\\/]+[A-Za-z0-9._ -]+[\\/]|[/]Users/[A-Za-z0-9._ -]+/|[/]home/"
        r"oai/|[/]mnt/data/)"),
}


def _git(root, *args):
    return subprocess.check_output(["git", *args], cwd=root, stderr=subprocess.PIPE)


def _safe_name(name):
    rel = PurePosixPath(name)
    if (not name or rel.is_absolute() or ".." in rel.parts or "\\" in name
            or ":" in name or str(rel) != name):
        raise ValueError("Unsafe transfer member name.")
    return rel


def excluded(name):
    rel = _safe_name(name)
    folded, basename = name.casefold(), rel.name.casefold()
    return bool({part.casefold() for part in rel.parts} & DENIED_PARTS or folded.startswith(DENIED_PREFIXES)
        or folded in DENIED_EXACT
        or basename in {value.casefold() for value in DENIED_NAMES} or rel.suffix.casefold() in {".pyc", ".pyo", ".log", ".zip", ".whl", ".vsix", ".pfx", ".p12"}
        or basename == ".env" or basename.startswith(".env.") and not basename.endswith((".example", ".sample")))


def selected(root):
    """Closed file list; never copy an entire checkout or an old staging folder."""
    modes = {}
    for entry in _git(root, "ls-files", "-s", "-z").decode("utf-8").split("\0"):
        if entry:
            metadata, name = entry.split("\t", 1)
            mode, _oid, stage = metadata.split()
            if stage != "0":
                raise ValueError("Resolve Git index conflicts before exporting source.")
            modes[name] = int(mode, 8)
    names = set(_git(root, "ls-files", "-z", "--cached", "--others", "--exclude-standard").decode("utf-8").split("\0")) - {""}
    result = []
    for name in sorted(names):
        if excluded(name):
            continue
        path = root / name
        if not path.exists() and not path.is_symlink():
            continue  # A working-tree deletion is part of the exported change.
        mode = modes.get(name, 0o100644)
        if (mode not in {0o100644, 0o100755} or path.is_symlink()
                or path.resolve() != path.absolute() or not path.is_file()):
            raise ValueError("Nonregular transfer source: " + name)
        result.append((name, mode))
    if not result:
        raise ValueError("No application source was selected by Git.")
    return result


def _digest(data):
    return hashlib.sha256(data).hexdigest()


def _scan_text(name, data, markers=()):
    # A private key does not become safe because its filename is .pem, .key or
    # extensionless. Inspect recognizable bytes in every selected file.
    encodings = ["utf-8-sig"]
    if b"\x00" in data[:256]:
        encodings.extend(("utf-16-le", "utf-16-be", "utf-32-le", "utf-32-be"))
    for encoding in encodings:
        text = data.decode(encoding, errors="replace")
        if any(marker in text.casefold() or marker in name.casefold() for marker in markers):
            raise ValueError("Transfer scan requires review (personal marker; value withheld).")
        for kind, pattern in SENSITIVE_PATTERNS.items():
            if pattern.search(text):
                # Report file and category only, never the matching value.
                raise ValueError(f"Transfer scan requires review: {name} ({kind}).")


def _scan_decoded_text(name, data, markers):
    """Inspect text values after JSON/XML decoding, without executing documents."""
    if not markers:
        return
    encoding = ("utf-32" if data.startswith((b"\xff\xfe\x00\x00", b"\x00\x00\xfe\xff"))
                else "utf-16" if data.startswith((b"\xff\xfe", b"\xfe\xff")) else "utf-8-sig")
    text = data.decode(encoding, errors="replace").lstrip()
    values = []
    if text.startswith(("{", "[")):
        try:
            document = json.loads(data)
        except (ValueError, UnicodeError):
            return  # Source code and other non-JSON text retain the byte scan.
        pending = [document]
        while pending:
            value = pending.pop()
            if isinstance(value, str):
                values.append(value)
            elif isinstance(value, dict):
                pending.extend(value.keys())
                pending.extend(value.values())
            elif isinstance(value, list):
                pending.extend(value)
    elif text.startswith("<") and PurePosixPath(name).suffix.casefold() not in {".html", ".htm"}:
        from xml.etree import ElementTree
        # No DTD/entity expansion is needed for workbook metadata.
        if re.search(r"(?i)<!DOCTYPE|<!ENTITY", text):
            raise ValueError("Transfer XML inspection requires review (document declarations).")
        try:
            document = ElementTree.fromstring(data)
        except (ElementTree.ParseError, ValueError):
            return  # HTML is checked by its dedicated parser.
        values.append("".join(document.itertext()))
        values.extend(value for element in document.iter() for value in element.attrib.values())
    for value in values:
        _scan_text(name, value.encode("utf-8"), markers)


def _scan(name, data, *, _depth=0, _budget=None, markers=()):
    """Inspect original bytes and compressed members without rewriting evidence."""
    _scan_text(name, data, markers)
    _scan_decoded_text(name, data, markers)
    is_container = data.startswith((b"PK\x03\x04", b"PK\x05\x06", b"PK\x07\x08"))
    if not is_container and (_depth or PurePosixPath(name).suffix.casefold() not in OFFICE_SUFFIXES):
        return
    if _depth >= ARCHIVE_MAX_DEPTH:
        raise ValueError(f"Transfer archive inspection requires review: {name} (nested archive limit).")
    budget = _budget if _budget is not None else {"bytes": 0, "members": 0}
    try:
        with zipfile.ZipFile(io.BytesIO(data)) as archive:
            members = archive.infolist()
            budget["members"] += len(members)
            budget["bytes"] += sum(info.file_size for info in members)
            if (budget["members"] > ARCHIVE_MAX_MEMBERS or budget["bytes"] > ARCHIVE_MAX_BYTES
                    or any(info.file_size > ARCHIVE_MAX_MEMBER_BYTES for info in members)):
                raise ValueError(f"Transfer archive inspection requires review: {name} (inspection size limit).")
            seen = set()
            for info in members:
                member = info.filename.removesuffix("/") if info.is_dir() else info.filename
                _safe_name(member)
                _scan_text(name, member.encode("utf-8"), markers)
                if member.casefold() in seen or info.flag_bits & 1:
                    raise ValueError(f"Transfer archive inspection requires review: {name} (duplicate or encrypted member).")
                seen.add(member.casefold())
                if not info.is_dir():
                    # Keep the outer source filename in diagnostics. An inner
                    # filename may itself contain private workstation details.
                    _scan(name, archive.read(info), _depth=_depth + 1, _budget=budget, markers=markers)
    except (zipfile.BadZipFile, RuntimeError, NotImplementedError) as error:
        raise ValueError(f"Transfer archive inspection requires review: {name} (unreadable container).") from error


def _fresh_snapshot(stage):
    if not (stage / SNAPSHOT).exists():
        return
    _git(stage, "init", "-q", "-b", "source-transfer")
    _git(stage, "-c", "core.autocrlf=false", "add", "--all")
    subprocess.run([sys.executable, "platform/tools/current_state.py"], cwd=stage,
                   check=True, capture_output=True, timeout=180)


def _retired_deleted_objects(root):
    """Omit a complete retired, deleted subject only after its owner verifies it."""
    if not (root / CHECKPOINTS).exists():
        return []
    from rwd_tools import event_ledger
    heads = event_ledger._checkpoints(str(root)).get("heads", {})
    omitted = []
    for object_id, checkpoint in sorted(heads.items()):
        if event_ledger.head_action(str(root), object_id) != "retired":
            continue
        if not isinstance(event_ledger.deleted_subject(str(root), object_id), tuple):
            continue
        if event_ledger._check_object(str(root), object_id, checkpoint):
            raise ValueError("Retired ledger object requires integrity review before export: " + object_id)
        omitted.append(object_id)
    if omitted:
        # Structural hashes alone cannot detect a rewritten historical chain.
        if event_ledger.check(root=str(root), require_claims=True):
            raise ValueError("Ledger integrity and ownership require review before retired objects can be omitted.")
        for name, _mode in selected(root):
            if name.startswith("governance/events/"):
                continue
            data = (root / name).read_bytes()
            if any(object_id.encode("ascii") in data for object_id in omitted):
                raise ValueError("Retired ledger object is still referenced by selected source: " + name)
    return omitted


def _omit_checkpoint_heads(stage, omitted):
    if not omitted:
        return
    import yaml
    path = stage / CHECKPOINTS
    content = yaml.safe_load(path.read_text(encoding="utf-8"))
    for object_id in omitted:
        del content["heads"][object_id]
    path.write_text("# Fresh source import: complete retired/deleted objects omitted; see SOURCE_MANIFEST.json.\n"
                    + yaml.safe_dump(content, sort_keys=True), encoding="utf-8", newline="\n")


def _signer_registry(data):
    import yaml
    try:
        content = yaml.safe_load(data)
    except yaml.YAMLError as error:
        raise ValueError("Signer registry requires review before source transfer.") from error
    if not isinstance(content, dict) or not isinstance(content.get("signers"), list):
        raise ValueError("Signer registry requires an explicit signers list before source transfer.")
    return content


def _reset_signer_trust(stage):
    """A source import cannot inherit another checkout's registered signing keys."""
    path = stage / SIGNERS
    if not path.exists():
        return False
    import yaml
    content = _signer_registry(path.read_bytes())
    if content["signers"]:
        content["signers"] = []
        path.write_text("# Fresh source import: no inherited signer trust; see SOURCE_MANIFEST.json.\n"
                        + yaml.safe_dump(content, sort_keys=False, allow_unicode=True),
                        encoding="utf-8", newline="\n")
    return True


CLEAN_PROFILE = "clean-install-v1"
KIT_MANIFEST = "demo-kit/DEMO_KIT.json"
GUIDE = "guides/workflow.html"
EXTRA_MAX_FILES = 64
EXTRA_MAX_BYTES = 32 * 1024 * 1024
EXTRA_MAX_FILE = 8 * 1024 * 1024
CLEAN_MAX_FILES = 4096
CLEAN_MAX_BYTES = 256 * 1024 * 1024


def _clean_private(name):
    parts = PurePosixPath(name.casefold()).parts
    return bool(set(parts) & {"profiles", "profile", "state", "uploads", "outputs", ".aws", ".ssh", ".azure"}
        or parts[-1] in {"credentials.json", "credentials.yaml", "token.json", "users.json", "snapshot.json"}
        or PurePosixPath(name).suffix.casefold() in {".pem", ".key", ".parquet"}
        or re.fullmatch(r"(?i)(profile_.*|inventory(?:_.*)?|catalogue(?:_.*)?|data_characterization.*|snapshot_comparison.*)\.(tsv|csv|txt|html)", parts[-1]))


def _regular(path):
    path = Path(path).absolute()
    if path.is_symlink() or path.resolve() != path or not path.is_file():
        raise ValueError("Choose an ordinary file without redirected paths.")
    return path


def _marker_policy(path):
    if path is None:
        return None, (), None
    path = _regular(path)
    if path.stat().st_size > 65536:
        raise ValueError("The personal-marker policy is too large.")
    raw = path.read_bytes()
    values = json.loads(raw)
    if (not isinstance(values, list) or not 1 <= len(values) <= 128
            or any(not isinstance(value, str) or not 3 <= len(value.strip()) <= 256
                   or value != value.strip() or any(ord(char) < 32 for char in value) for value in values)):
        raise ValueError("Use a JSON list of 1–128 explicit personal markers, each 3–256 characters.")
    return _digest(raw), tuple(dict.fromkeys(value.casefold() for value in values)), path


def _guide_check(raw, markers=()):
    """Offline static HTML only; visual review of embedded screenshots is separate."""
    from html.parser import HTMLParser
    import base64
    def css(value):
        value = re.sub(r"/\*.*?\*/", "", value, flags=re.S)
        if re.search(r"(?i)@|\\|url\s*\(", value):
            raise ValueError("The guide must not load external styles or CSS resources.")
    class Guide(HTMLParser):
        styling = False
        blocks = {"p", "div", "section", "article", "header", "footer", "li", "tr", "td", "th",
                  "h1", "h2", "h3", "h4", "h5", "h6", "br", "hr", "blockquote", "pre"}
        def __init__(self):
            super().__init__(convert_charrefs=True)
            self.visible = []
            self.text_nodes = []
        def handle_starttag(self, tag, attrs):
            if tag in self.blocks:
                self.visible.append(" ")
            if tag not in {"html", "head", "title", "meta", "style", "body", "main", "header", "footer",
                           "nav", "section", "article", "aside", "div", "span", "p", "h1", "h2", "h3",
                           "h4", "h5", "h6", "ul", "ol", "li", "a", "img", "figure", "figcaption",
                           "table", "thead", "tbody", "tfoot", "tr", "td", "th", "caption", "colgroup",
                           "col", "strong", "em", "b", "i", "small", "br", "hr", "pre", "code",
                           "blockquote", "details", "summary", "dl", "dt", "dd", "kbd", "samp"}:
                raise ValueError("The guide must be static HTML without executable or embedded documents.")
            if tag == "style":
                self.styling = True
            for key, value in attrs:
                value = value or ""
                _scan_text(GUIDE, value.encode("utf-8"), markers)
                if key.startswith("on") or key in {"srcdoc", "srcset", "http-equiv", "background"}:
                    raise ValueError("The guide contains active content.")
                if key == "href" and not (value.startswith("#") or value.startswith(("https://", "http://"))):
                    raise ValueError("Guide links must be document anchors or explicit web citations.")
                if key == "style":
                    css(value)
                if key == "src":
                    match = re.fullmatch(r"data:image/(png|jpeg|webp);base64,([A-Za-z0-9+/=\s]+)", value)
                    if tag != "img" or not match:
                        raise ValueError("Guide images must be embedded PNG, JPEG or WebP images.")
                    data = base64.b64decode(re.sub(r"\s", "", match[2]), validate=True)
                    if len(data) > EXTRA_MAX_FILE:
                        raise ValueError("A guide image exceeds the size limit.")
                    _scan("embedded guide image", data, markers=markers)
        def handle_data(self, data):
            if self.styling:
                css(data)
            else:
                self.visible.append(data)
                self.text_nodes.append(data)
        def handle_endtag(self, tag):
            if tag in self.blocks:
                self.visible.append(" ")
            if tag == "style":
                self.styling = False
        handle_startendtag = handle_starttag
    text = raw.decode("utf-8-sig")
    if len(raw) > EXTRA_MAX_FILE or re.search(r"(?i)@import|url\s*\(|file\s*:", text):
        raise ValueError("The guide must be bounded and contain no external styles or local-file references.")
    _scan_text(GUIDE, raw, markers)
    parser = Guide()
    parser.feed(text)
    parser.close()
    visible = "".join(parser.visible)
    # CSS can display block elements inline. Scan original adjacent text nodes
    # as well as the ordinary block-spaced view without interpreting CSS.
    for value in (visible, re.sub(r"\s+", " ", visible), "".join(parser.text_nodes)):
        _scan_text(GUIDE, value.encode("utf-8"), markers)


def _kit_check(files):
    """Validate a closed, inert input kit; it never registers or approves a product."""
    if KIT_MANIFEST not in files:
        if any(name.startswith("demo-kit/") for name in files):
            raise ValueError("Synthetic demo inputs require DEMO_KIT.json.")
        return
    doc = json.loads(files[KIT_MANIFEST])
    if (not isinstance(doc, dict) or set(doc) != {"version", "synthetic", "notice", "files"}
            or type(doc["version"]) is not int or doc["version"] != 1 or doc["synthetic"] is not True
            or doc["notice"] != "Synthetic demonstration inputs only; no scientific approval or release."
            or not isinstance(doc["files"], list) or not 1 <= len(doc["files"]) <= EXTRA_MAX_FILES):
        raise ValueError("Invalid synthetic demo manifest or missing explicit synthetic notice.")
    expected, roles, size = {KIT_MANIFEST}, set(), len(files[KIT_MANIFEST])
    allowed = {"workbook": {".xlsx"}, "source": {".tsv"}, "oracle": {".json", ".csv", ".tsv"}, "readme": {".md", ".txt"}}
    for row in doc["files"]:
        if not isinstance(row, dict) or set(row) != {"path", "role", "sha256"}:
            raise ValueError("Invalid synthetic demo file declaration.")
        relative = _safe_name(row["path"])
        name, role = "demo-kit/" + str(relative), row["role"]
        if (role not in allowed or relative.suffix.casefold() not in allowed[role] or name in expected
                or re.search(r"(?i)(approval|attest|maturity|source_refs|registry|receipt|decision|config|credential|token)", str(relative))):
            raise ValueError("The demo kit may contain only workbook, TSV source, oracle and readme inputs.")
        expected.add(name)
        roles.add(role)
        raw = files.get(name)
        if raw is None or len(raw) > EXTRA_MAX_FILE or _digest(raw) != row["sha256"]:
            raise ValueError("Synthetic demo content does not match its bounded manifest.")
        size += len(raw)
        if role == "workbook":
            _scan(name, raw)  # enforce decompression budgets before inspecting worksheet XML
            with zipfile.ZipFile(io.BytesIO(raw)) as workbook:
                from xml.etree import ElementTree
                def xml_part(part):
                    payload = workbook.read(part)
                    if re.search(rb"(?i)<!DOCTYPE|<!ENTITY", payload):
                        raise ValueError("Demo workbook parts cannot declare external entities.")
                    try:
                        return ElementTree.fromstring(payload)
                    except ElementTree.ParseError as error:
                        raise ValueError("Demo workbook parts require valid XML.") from error
                def active_type(value):
                    value = value.casefold()
                    return any(token in value for token in (
                        "connections", "querytable", "externallink", "vbaproject", "macroenabled", "oleobject"))
                names = workbook.namelist()
                if "xl/workbook.xml" not in names or "[Content_Types].xml" not in names or any(
                        part in name.casefold() for name in names for part in (
                            "vbaproject", "externallinks/", "embeddings/", "connections.xml", "querytables/")):
                    raise ValueError("Demo workbooks must be XLSX inputs without macros or external data connections.")
                if any(active_type(element.attrib.get("ContentType", ""))
                       for element in xml_part("[Content_Types].xml").iter()):
                    raise ValueError("Demo workbooks cannot declare macros or external data connection types.")
                for name in names:
                    if name.casefold().endswith(".rels"):
                        relationships = xml_part(name)
                        if any(element.attrib.get("TargetMode", "").casefold() == "external"
                               or active_type(element.attrib.get("Type", ""))
                               or re.match(r"(?i)(?:[a-z][a-z0-9+.-]*:|//|\\\\)", element.attrib.get("Target", ""))
                               for element in relationships.iter()):
                            raise ValueError("Demo workbooks cannot contain external relationship targets.")
                    if name.startswith("xl/worksheets/") and re.search(rb"<(?:(?:\w+):)?f(?:\s|>)", workbook.read(name)):
                        raise ValueError("Demo workbook cells must contain values, not executable formulas.")
    actual = {name for name in files if name.startswith("demo-kit/")}
    if actual != expected or len({name.casefold() for name in expected}) != len(expected) or size > EXTRA_MAX_BYTES:
        raise ValueError("The demo kit contains undeclared, duplicate or oversized files.")
    if not {"workbook", "source", "oracle", "readme"} <= roles:
        raise ValueError("A demo kit requires workbook, source, oracle and readme inputs.")


def _clean_members(files, manifest, *, markers=()):
    """Re-derive the install closure and state invariants from archive bytes."""
    from engine.strict_yaml import strict_load
    from rwd_services import package_source_files
    from rwd_tools import clean_install_smoke as clean, clean_evaluation_assets
    inventory = manifest.get("package_files")
    if not isinstance(inventory, dict) or not inventory:
        raise ValueError("The clean installation requires a declared package inventory.")
    required = {"pyproject.toml", "Start-RwdPortal.cmd", "requirements.txt", "docs/RESEARCHER_QUICK_START.md",
                "docs/CLEAN_INSTALL_EXPORT.md", "platform/TUMOR_TEMPLATE/NEW_TUMOUR.md",
                "platform/TUMOR_TEMPLATE/config/data_product.yaml",
                "governance/tumour_registry.yaml", "governance/reference/oncology_modules/CATALOGUE.yaml",
                "products/metadata/catalog.yaml", "resources/products.yml", SIGNERS}
    if not required <= set(files):
        raise ValueError("The clean installation is missing required startup/workspace assets: "
                         + ", ".join(sorted(required - set(files))))
    for name in files:
        if name.startswith("demo-kit/") or name == GUIDE:
            continue
        if _clean_private(name):
            raise ValueError("Private profile/state data is not an installation input.")
        if name in clean.EMPTY_DOCUMENTS or name in clean_evaluation_assets.initial_documents():
            continue
        if name == "README.md" and files[name] == files["docs/CLEAN_INSTALL_EXPORT.md"]:
            continue
        if not clean.release_selected(name) and name not in inventory:
            raise ValueError("Unexpected clean-install member: " + name)
        if name in inventory and (name.startswith(("products/", "fixtures/", "work/", "releases/", "intake/"))
                                  or name == clean.RETIRED_OVERLAY):
            raise ValueError("Package declarations cannot admit product data into a clean installation.")
    for name, expected in {**clean.EMPTY_DOCUMENTS, **clean_evaluation_assets.initial_documents()}.items():
        if name not in files or strict_load(files[name].decode("utf-8")) != expected:
            raise ValueError("Clean installation state is not empty: " + name)
    if _signer_registry(files[SIGNERS])["signers"]:
        raise ValueError("Clean installations must not inherit signer trust.")
    catalog = strict_load(files["products/metadata/catalog.yaml"].decode("utf-8"))
    bundle = strict_load(files["resources/products.yml"].decode("utf-8"))
    if catalog.get("tumor_codes") != [] or bundle != {"variables": {}, "resources": {"jobs": {}}}:
        raise ValueError("Clean product mirrors and generated jobs must be empty.")
    for name, field in [("governance/tumour_registry.yaml", "aliases"),
                        ("governance/reference/oncology_modules/CATALOGUE.yaml", "cancers")]:
        if "gist_202606" in strict_load(files[name].decode("utf-8")).get(field, {}):
            raise ValueError("The retired example product must not be inherited.")
    with tempfile.TemporaryDirectory(prefix="rwd-verify-clean-") as temporary:
        stage = Path(temporary)
        for name, raw in files.items():
            if name.startswith(("demo-kit/", "guides/")):
                continue
            target = stage / name
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes(raw)
        declared = {path.as_posix() for path in package_source_files(stage)}
        if declared != set(inventory) or any(_digest(files[name]) != digest for name, digest in inventory.items()):
            raise ValueError("The archive does not match its complete declared package closure.")
    transformations = manifest.get("transformations")
    if not isinstance(transformations, dict):
        raise ValueError("Clean installation transformations require provenance.")
    required_transforms = (set(clean.EMPTY_DOCUMENTS) | set(clean_evaluation_assets.initial_documents())
        | {SIGNERS, "products/metadata/catalog.yaml", "resources/products.yml", "README.md"}
        | {name for name in files if name.startswith("demo-kit/") or name == GUIDE})
    allowed_transforms = required_transforms | {"governance/tumour_registry.yaml",
        "governance/reference/oncology_modules/CATALOGUE.yaml", clean.RETIRED_OVERLAY}
    if not required_transforms <= set(transformations) <= allowed_transforms:
        raise ValueError("Missing or unexpected clean installation transformation provenance.")
    for name, row in transformations.items():
        if (not isinstance(row, dict) or set(row) != {"source_sha256", "sha256", "reason"}
                or not isinstance(row["reason"], str) or not row["reason"]
                or row["source_sha256"] is not None and not re.fullmatch(r"[a-f0-9]{64}", row["source_sha256"])
                or (None if name not in files else _digest(files[name])) != row["sha256"]):
            raise ValueError("Invalid clean installation transformation provenance.")
    preserved = manifest.get("preserved_resources")
    expected_preserved = {name for name in files if name not in transformations and (
        name.startswith(("governance/", "products/metadata/", "products/_reporting/")) or clean.license_notice(name))}
    if (not isinstance(preserved, dict) or not preserved or set(preserved) != expected_preserved
            or any(_digest(files[name]) != digest for name, digest in preserved.items())):
        raise ValueError("Preserved master/policy/licensing resources do not match their complete source inventory.")
    _kit_check(files)
    if GUIDE in files:
        _guide_check(files[GUIDE], markers)


def verify(archive_path, *, personal_markers=None):
    """Check names, CRCs, modes, size and every member hash without extracting."""
    archive_path = Path(archive_path)
    policy_hash, markers, _policy_path = _marker_policy(personal_markers)
    with zipfile.ZipFile(archive_path) as archive:
        names = archive.namelist()
        if len(names) != len({name.casefold() for name in names}):
            raise ValueError("Duplicate ZIP members or failed ZIP integrity check.")
        for name in names:
            _safe_name(name)
        if archive.getinfo(MANIFEST).file_size > 8 * 1024 * 1024:
            raise ValueError("The source manifest exceeds its inspection limit.")
        if archive.getinfo(MANIFEST).external_attr >> 16 != 0o100644:
            raise ValueError("The source manifest must be a regular file.")
        manifest_bytes = archive.read(MANIFEST)
        _scan(MANIFEST, manifest_bytes, markers=markers)
        manifest = json.loads(manifest_bytes)
        if manifest.get("profile") == CLEAN_PROFILE and (
                len(names) > CLEAN_MAX_FILES or sum(info.file_size for info in archive.infolist()) > CLEAN_MAX_BYTES
                or any(info.file_size > ARCHIVE_MAX_MEMBER_BYTES or info.flag_bits & 1 for info in archive.infolist())):
            raise ValueError("The clean archive exceeds its bounded inspection limits.")
        if archive.testzip() is not None:
            raise ValueError("Failed ZIP integrity check.")
        if manifest.get("schema_version") != 1 or not isinstance(manifest.get("files"), list):
            raise ValueError("Unsupported source manifest.")
        rows = manifest["files"]
        if not rows or len(rows) != len({row["path"] for row in rows}):
            raise ValueError("Source manifest is empty or contains duplicate files.")
        if set(names) != {row["path"] for row in rows} | {MANIFEST}:
            raise ValueError("ZIP members do not match the source manifest.")
        if manifest.get("reset_signer_trust") and SIGNERS not in names:
            raise ValueError("The reset signer registry must remain present in the source transfer.")
        if SIGNERS in names and _signer_registry(archive.read(SIGNERS))["signers"]:
            raise ValueError("Source transfers must not inherit registered signer trust.")
        clean_profile = manifest.get("profile") == CLEAN_PROFILE
        if manifest.get("profile") not in (None, CLEAN_PROFILE):
            raise ValueError("Unsupported transfer profile.")
        if clean_profile and (not re.fullmatch(r"[a-f0-9]{64}", str(manifest.get("personal_marker_policy_sha256", "")))
                              or policy_hash and policy_hash != manifest["personal_marker_policy_sha256"]):
            raise ValueError("The explicit personal-marker policy does not match the clean archive.")
        files = {}
        for row in rows:
            name = row["path"]
            if excluded(name):
                raise ValueError("Excluded runtime/private member in transfer: " + name)
            mode = archive.getinfo(name).external_attr >> 16
            if mode not in {0o100644, 0o100755} or mode != row["mode"]:
                raise ValueError("Invalid transfer file mode: " + name)
            data = archive.read(name)
            if len(data) != row["bytes"] or _digest(data) != row["sha256"]:
                raise ValueError("Transfer file does not match its manifest: " + name)
            _scan(name, data, markers=markers)
            if clean_profile:
                files[name] = data
        if clean_profile:
            _clean_members(files, manifest, markers=markers)
    digest = _digest(archive_path.read_bytes())
    checksum = archive_path.with_suffix(archive_path.suffix + ".sha256")
    if checksum.exists() and checksum.read_text(encoding="ascii").split()[0] != digest:
        raise ValueError("ZIP checksum does not match.")
    result = {"files": len(rows), "sha256": digest, "zip_bytes": archive_path.stat().st_size}
    if clean_profile:
        result.update(profile=CLEAN_PROFILE, personal_markers_rechecked=bool(markers))
    return result


def _clean_selection(root):
    from rwd_services import package_source_files
    from rwd_tools import clean_install_smoke as clean
    declared = {path.as_posix() for path in package_source_files(root)}
    modes = {name: mode for name, mode in selected(root) if clean.release_selected(name) and not _clean_private(name)}
    for name in declared:
        if excluded(name) or _clean_private(name):
            raise ValueError("Private/runtime data cannot be declared as an installation package input.")
        _regular(root / _safe_name(name))
        modes.setdefault(name, 0o100644)
    return sorted(modes.items())


def _extra_inputs(demo_kit, guide):
    """A closed snapshot of optional inputs; no ambient files or executable kit hooks."""
    files, sources = {}, {}
    if demo_kit is not None:
        directory = Path(demo_kit).absolute()
        if directory.resolve() != directory or directory.is_symlink() or not directory.is_dir():
            raise ValueError("Choose a canonical synthetic demo-kit directory.")
        paths = sorted(directory.rglob("*"))
        if len(paths) > EXTRA_MAX_FILES * 3:
            raise ValueError("The synthetic demo kit has too many entries.")
        for path in paths:
            if path.is_symlink() or path.resolve() != path:
                raise ValueError("Synthetic demo paths cannot redirect elsewhere.")
            if path.is_dir():
                continue
            path = _regular(path)
            if path.stat().st_size > EXTRA_MAX_FILE:
                raise ValueError("A synthetic demo input exceeds the size limit.")
            name = "demo-kit/" + path.relative_to(directory).as_posix()
            files[name] = path.read_bytes()
            sources[name] = path
        if KIT_MANIFEST not in files:
            raise ValueError("A supplied synthetic demo kit requires DEMO_KIT.json.")
        _kit_check(files)
    if guide is not None:
        path = _regular(guide)
        if path.stat().st_size > EXTRA_MAX_FILE:
            raise ValueError("The static workflow guide exceeds the size limit.")
        files[GUIDE] = path.read_bytes()
        sources[GUIDE] = path
        _guide_check(files[GUIDE])
    return files, sources


def _write_archive(stage, output, rows, manifest, *, personal_markers=None):
    """Shared deterministic writer, independently verified before publication."""
    payload = json.dumps(manifest, indent=2, ensure_ascii=False).encode("utf-8") + b"\n"
    handle, pending = tempfile.mkstemp(prefix=".rwd-source-", suffix=".tmp", dir=output.parent)
    os.close(handle)
    try:
        with zipfile.ZipFile(pending, "w", zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
            for row in [*rows, {"path": MANIFEST, "mode": 0o100644}]:
                name = row["path"]
                info = zipfile.ZipInfo(name, (1980, 1, 1, 0, 0, 0))
                info.create_system = 3
                info.external_attr = row["mode"] << 16
                info.compress_type = zipfile.ZIP_DEFLATED
                archive.writestr(info, payload if name == MANIFEST else (stage / name).read_bytes())
        result = verify(pending, personal_markers=personal_markers)
        os.link(pending, output)
    finally:
        Path(pending).unlink(missing_ok=True)
    return result


def _build_clean(root, output, *, demo_kit=None, guide=None, personal_markers=None):
    from rwd_services import package_source_files
    from rwd_tools import clean_install_smoke as clean, bundle_products
    policy_hash, markers, policy_path = _marker_policy(personal_markers)
    if not markers:
        raise ValueError("Clean installation export requires an explicit personal-marker JSON file.")
    if policy_path.is_relative_to(root):
        raise ValueError("Keep the personal-marker policy outside the exported source checkout.")
    selection = _clean_selection(root)
    initial = {name: _digest((root / name).read_bytes()) for name, _mode in selection}
    extras, extra_paths = _extra_inputs(demo_kit, guide)
    for name, raw in extras.items():
        _scan(name, raw, markers=markers)
    with tempfile.TemporaryDirectory(prefix="rwd-clean-transfer-") as temporary:
        stage = Path(temporary)
        modes = dict(selection)
        for name, _mode in selection:
            raw = (root / name).read_bytes()
            if _digest(raw) != initial[name]:
                raise ValueError("Source changed during packaging; retry after edits finish.")
            _scan(name, raw)  # credentials are refused even in state that will be reset
            target = stage / name
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes(raw)
        transformations = clean.initialize(stage)
        generated = {
            "resources/products.yml": bundle_products.render(str(stage), rows=[]).encode("utf-8"),
            "README.md": (stage / "docs/CLEAN_INSTALL_EXPORT.md").read_bytes(),
        }
        for name, raw in generated.items():
            before = (stage / name).read_bytes() if (stage / name).exists() else None
            (stage / name).parent.mkdir(parents=True, exist_ok=True)
            (stage / name).write_bytes(raw)
            transformations[name] = {"source_sha256": _digest(before) if before is not None else None,
                "sha256": _digest(raw), "reason": "Generate empty installation jobs or portable installation instructions"}
        for name, row in transformations.items():
            # Also account for source state deliberately excluded from the copy.
            original = root / name
            if name not in initial and original.exists():
                original = _regular(original)
                initial[name] = _digest(original.read_bytes())
                row["source_sha256"] = initial[name]
            if row["sha256"] is None:
                modes.pop(name, None)
            else:
                modes.setdefault(name, 0o100644)
        for name, raw in extras.items():
            target = stage / name
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes(raw)
            modes[name] = 0o100644
            transformations[name] = {"source_sha256": _digest(raw), "sha256": _digest(raw),
                "reason": "Copy explicit inert synthetic demo input or static guide; grants no approval"}
        rows = []
        for name, mode in sorted(modes.items()):
            raw = (stage / name).read_bytes()
            _scan(name, raw, markers=markers)
            rows.append({"path": name, "bytes": len(raw), "sha256": _digest(raw), "mode": mode})
        packaged = {path.as_posix(): _digest((stage / path).read_bytes()) for path in package_source_files(stage)}
        preserved = {name: digest for name, digest in initial.items() if name in modes and name not in transformations
            and (name.startswith(("governance/", "products/metadata/", "products/_reporting/")) or clean.license_notice(name))}
        manifest = {"schema_version": 1, "profile": CLEAN_PROFILE,
            "scope": "Empty installation source and optional inert synthetic inputs. No inherited products, approvals, signer trust or runtime state. Destination dependencies and actual workflow verification are separate requirements.",
            "reset_signer_trust": True, "omitted_retired_objects": [], "files": rows,
            "package_files": packaged, "preserved_resources": preserved, "transformations": transformations,
            "personal_marker_policy_sha256": policy_hash,
            "guide_images": "Embedded screenshots require independent visual privacy review; byte scans do not inspect pixels."}
        if (_clean_selection(root) != selection or any(_digest((root / name).read_bytes()) != digest for name, digest in initial.items())
                or _marker_policy(policy_path)[0] != policy_hash
                or _extra_inputs(demo_kit, guide)[0] != extras):
            raise ValueError("Source or optional inputs changed during packaging; retry after edits finish.")
        return _write_archive(stage, output, rows, manifest, personal_markers=policy_path)


def build(root, output, *, clean_install=False, demo_kit=None, guide=None, personal_markers=None):
    root, output = Path(root).resolve(strict=True), Path(output).absolute()
    if output.resolve() != output or output.is_relative_to(root):
        raise ValueError("Write the ZIP outside the checkout, using a nonredirected path.")
    checksum = output.with_suffix(output.suffix + ".sha256")
    if output.exists() or checksum.exists():
        raise ValueError("Transfer output already exists; choose a new filename.")
    if not clean_install and any(value is not None for value in (demo_kit, guide, personal_markers)):
        raise ValueError("Optional demo, guide and personal-marker inputs require --clean-install.")
    output.parent.mkdir(parents=True, exist_ok=True)
    if clean_install:
        result = _build_clean(root, output, demo_kit=demo_kit, guide=guide, personal_markers=personal_markers)
        with checksum.open("x", encoding="ascii", newline="\n") as stream:
            stream.write(result["sha256"] + "  " + output.name + "\n")
        return result
    original_selection = selected(root)
    initial_hashes = {name: _digest((root / name).read_bytes()) for name, _mode in original_selection}
    omitted = _retired_deleted_objects(root)
    prefixes = tuple(f"governance/events/{object_id}/" for object_id in omitted)
    selection = [(name, mode) for name, mode in original_selection if not name.startswith(prefixes)]
    with tempfile.TemporaryDirectory(prefix="rwd-transfer-") as temporary:
        stage = Path(temporary) / "source"
        stage.mkdir()
        source_hashes = {}
        for name, _mode in selection:
            data = (root / name).read_bytes()
            _scan(name, data)
            source_hashes[name] = _digest(data)
            target = stage / name
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes(data)
        _omit_checkpoint_heads(stage, omitted)
        reset_signer_trust = _reset_signer_trust(stage)
        reset_signer_hash = _digest((stage / SIGNERS).read_bytes()) if reset_signer_trust else None
        _fresh_snapshot(stage)
        rows = []
        for name, mode in selection:
            data = (stage / name).read_bytes()
            _scan(name, data)
            row = {"path": name, "bytes": len(data), "sha256": _digest(data), "mode": mode}
            if row["sha256"] != source_hashes[name]:
                if (name not in {SNAPSHOT, CHECKPOINTS, SIGNERS}
                        or name == SIGNERS and row["sha256"] != reset_signer_hash):
                    raise ValueError("Unexpected staging transformation: " + name)
                row.update(source_sha256=source_hashes[name], generated_for=(
                    "Fresh Git import without original history" if name == SNAPSHOT else
                    "Fresh source import with no inherited signer trust; other registry fields preserved" if name == SIGNERS else
                    "Remove only heads for the complete retired/deleted objects listed in this manifest"))
            rows.append(row)
        if (selected(root) != original_selection
                or any(_digest((root / name).read_bytes()) != initial_hashes[name] for name, _mode in original_selection)
                or any(source_hashes[name] != initial_hashes[name] for name, _mode in selection)):
            raise ValueError("Source changed during packaging; retry after edits finish.")
        manifest = {"schema_version": 1,
            "scope": "Current application source. Git history and configured private/runtime paths are excluded; recognizable credential and personal-path patterns are scanned in source bytes and bounded compressed members, including UTF-16/32 text. This scan is not a general sensitive-data classification. CURRENT_STATE.md is regenerated, complete retired/deleted ledger objects and only their checkpoint heads are omitted, and the transferred signer registry starts with an empty signers list. Other signer registry fields and original checkout evidence are unchanged. No approval is conferred.",
            "omitted_retired_objects": omitted,
            "reset_signer_trust": reset_signer_trust,
            "files": rows}
        payload = json.dumps(manifest, indent=2, ensure_ascii=False).encode("utf-8") + b"\n"
        # Publish on the destination filesystem without overwriting another run.
        handle, pending = tempfile.mkstemp(prefix=".rwd-source-", suffix=".tmp", dir=output.parent)
        os.close(handle)
        try:
            with zipfile.ZipFile(pending, "w", zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
                for name, mode in selection + [(MANIFEST, 0o100644)]:
                    info = zipfile.ZipInfo(name, (1980, 1, 1, 0, 0, 0))
                    info.create_system = 3
                    info.external_attr = mode << 16
                    info.compress_type = zipfile.ZIP_DEFLATED
                    archive.writestr(info, payload if name == MANIFEST else (stage / name).read_bytes())
            result = verify(pending)
            os.link(pending, output)
        finally:
            Path(pending).unlink(missing_ok=True)
    with checksum.open("x", encoding="ascii", newline="\n") as stream:
        stream.write(result["sha256"] + "  " + output.name + "\n")
    return result


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    action = parser.add_mutually_exclusive_group(required=True)
    action.add_argument("--out", type=Path, help="new ZIP path outside the source checkout")
    action.add_argument("--verify", type=Path, help="verify an existing source ZIP and its optional checksum")
    parser.add_argument("--root", type=Path, default=ROOT, help="source checkout; defaults to this repository")
    parser.add_argument("--clean-install", action="store_true", help="export an empty installation with explicit transformation provenance")
    parser.add_argument("--demo-kit", type=Path, help="closed synthetic input directory containing DEMO_KIT.json; clean installs only")
    parser.add_argument("--guide", type=Path, help="bounded static HTML guide; clean installs only")
    parser.add_argument("--personal-markers", type=Path, help="external JSON list of personal/repository markers; required for clean export, optional for re-verification")
    args = parser.parse_args(argv)
    try:
        if args.verify and (args.clean_install or args.demo_kit or args.guide):
            raise ValueError("Verification reads the archive's own profile; do not supply export options.")
        result = verify(args.verify, personal_markers=args.personal_markers) if args.verify else build(args.root, args.out,
            clean_install=args.clean_install, demo_kit=args.demo_kit, guide=args.guide, personal_markers=args.personal_markers)
    except (OSError, ValueError, KeyError, TypeError, subprocess.SubprocessError, zipfile.BadZipFile) as error:
        print("Source transfer refused: " + str(error), file=sys.stderr)
        return 1
    print(json.dumps(result, indent=2))
    return 0


if __name__ == "__main__":
    from rwd_tools.console import use_utf8
    use_utf8()
    raise SystemExit(main())
