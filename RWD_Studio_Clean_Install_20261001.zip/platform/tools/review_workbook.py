#!/usr/bin/env python3
"""The reviewer's one Excel artifact — built from the extraction, read back by stable item id.

    python3 platform/tools/review_workbook.py build <pack> --out ~/reviews/prostate_review.xlsx
    python3 platform/tools/review_workbook.py read ~/reviews/prostate_review_filled.xlsx <pack>

WHY THIS EXISTS. The human reviewer's native artifact is Excel, and today their choices scatter
across YAML forms a specialist locates for them. This tool builds ONE workbook: a tab per
domain carrying every extracted requirement row (with its Excel coordinates, content hash and
lint severity), a findings tab, a read-only snapshot of the open decisions, and a provenance
tab that pins the whole file to the extraction it was built from. The reviewer fills exactly
four columns — reviewer_decision, reviewer_comment, reviewed_by, reviewed_date — and `read`
verifies the round trip and prints their decisions as structured output.

WHAT `read` REFUSES, because a round trip is only as good as its binding: a workbook whose
provenance fingerprint no longer matches the pack's current extraction (the spec moved under
the review), duplicated or unknown item_ids (rows added or reshuffled), and a decision with no
reviewer name or date (an unowned choice is not a review).

WHAT THIS TOOL NEVER DOES: write into the repository. `read` PRINTS the reviewer's decisions;
carrying them into the governed files (dispositions, decision answers, contract records) stays
a person's act through the tools that own those files — this is transport, not approval.
"""
import argparse
import json
import os
import sys

TOOLS = os.path.dirname(os.path.abspath(__file__))

from rwd_tools import pack_run                                                             # noqa: E402
from rwd_tools import spec_lint as sl                                                      # noqa: E402
from rwd_tools.spec_extract import repo_relative                                      # noqa: E402

REVIEW_COLS = ("reviewer_decision", "reviewer_comment", "reviewed_by", "reviewed_date")
# VERBATIM, not truncated: a reviewer approving a rule they saw a prefix of approved a prefix
# `raw_text` carries the extraction's own joined row so nothing
# the field map missed is invisible to the person.
MACHINE_COLS = ("item_id", "tab", "row", "variable", "time_period", "label", "values",
                "definition", "notes", "raw_text", "lint_severity", "lint_kinds",
                "content_hash")
DECISION_WORDS = ("ACCEPT", "REVISE", "QUESTION")


def _extraction(pack):
    path = os.path.join(pack, "spec_pipeline", "out", "extracted.json")
    if not os.path.exists(path):
        sys.exit(f"no extraction at {repo_relative(path)} — run the spec pipeline first; a "
                 f"review workbook not built from the extraction would be a second spec")
    with open(path, encoding="utf-8") as fh:
        return json.load(fh)


def _lint_cells(data):
    """{item_id: (severity cell, kinds cell)} — ONE computation for build and read. `read`
    recomputes these instead of trusting the file: the severity beside a row is part of what
    the reviewer SAW, so a blanked HIGH is tampering, and a lint upgrade since build means the
    review predates findings the reviewer never considered — stale either way, refused."""
    findings = sl.scan(data) + sl.scan_across(data) + sl.scan_structure(data)
    by_item = {}
    for f in findings:
        by_item.setdefault(f.get("item_id"), []).append(f)
    out = {}
    for iid, mine in by_item.items():
        sev = ("HIGH" if any((x.get("severity") or sl.SEVERITY.get(x.get("kind"), "INFO"))
                             == "HIGH" for x in mine) else "INFO")
        out[iid] = (sev, "; ".join(sorted({x.get("kind") or "" for x in mine})))
    return out


def _machine_values(r, lint):
    """The 13 machine-column values for one extraction row, in MACHINE_COLS order — what build
    WRITES and what read VERIFIES, from one definition so they cannot drift apart."""
    f = r.get("fields") or {}
    sev, kinds = lint.get(r.get("item_id")) or ("", "")
    return [r.get("item_id"), r.get("tab"), r.get("row"), r.get("variable"),
            str(f.get("time_period") or ""), str(f.get("label") or ""),
            str(f.get("values") or ""), str(f.get("definition") or ""),
            str(f.get("notes") or ""), str(r.get("text") or ""), sev, kinds,
            r.get("content_hash")]


def build(pack, out_path):
    """The review workbook, from the pack's own generated artifacts. Deterministic content;
    openpyxl required."""
    from openpyxl import Workbook
    from openpyxl.styles import Font

    data = _extraction(pack)
    findings = sl.scan(data) + sl.scan_across(data) + sl.scan_structure(data)
    lint = _lint_cells(data)

    wb = Workbook()
    bold = Font(bold=True)

    prov = wb.active
    prov.title = "Provenance"
    prov_rows = (
        ("pack", repo_relative(pack)),
        ("extraction_fingerprint", str((data.get("extraction") or {}).get("fingerprint") or "")),
        ("rows", len(data.get("rows") or [])),
        ("findings", len(findings)),
        ("rule", "Fill ONLY the reviewer_* columns. Do not edit machine columns — `read` "
                 "verifies item_ids and this fingerprint, and refuses a drifted file."),
        ("decisions", "reviewer_decision is one of: " + " / ".join(DECISION_WORDS) +
                      ". A decision without reviewed_by AND reviewed_date does not count."),
        ("boundary", "This file transports a review; it approves nothing. The governed files "
                     "are updated by a person through the tools that own them."),
    )
    for r in prov_rows:
        prov.append(list(r))
    for c in prov["A1":f"A{len(prov_rows)}"]:
        c[0].font = bold

    domains = {}
    for row in data.get("rows") or []:
        domains.setdefault(row.get("domain") or "unclassified", []).append(row)
    for domain, rows in sorted(domains.items()):
        ws = wb.create_sheet(domain[:28])
        ws.append(list(MACHINE_COLS) + list(REVIEW_COLS))
        for c in ws[1]:
            c.font = bold
        for r in rows:
            ws.append(_machine_values(r, lint) + ["", "", "", ""])

    ws = wb.create_sheet("Findings")
    ws.append(["item_id", "kind", "severity", "variable", "detail"])
    for c in ws[1]:
        c.font = bold
    for f in findings:
        ws.append([f.get("item_id"), f.get("kind"),
                   f.get("severity") or sl.SEVERITY.get(f.get("kind"), "INFO"),
                   f.get("variable"), str(f.get("detail") or "")])

    # the OPEN DECISIONS snapshot the docstring promises — read-only context so a reviewer sees
    # which questions already have owners before dispositioning a row that hangs on one
    reg = os.path.join(pack, "handoff", "DECISIONS.md")
    ws = wb.create_sheet("Decisions")
    ws.append(["decision_id", "status", "question", "owner"])
    for c in ws[1]:
        c.font = bold
    if os.path.exists(reg):
        from rwd_tools import contract_lint as cl                                          # noqa: PLC0415
        text = cl.read(reg)
        status = cl.decision_status(text)
        for did, row in sorted(cl.decision_rows(text).items()):
            ws.append([did, status.get(did, "OPEN"), cl.decision_question(row),
                       cl.cell(row, *cl.OWNER_COLUMNS)])
    else:
        ws.append(["(no register)", "", "this pack has no decisions register yet", ""])

    wb.save(out_path)
    return {"rows": len(data.get("rows") or []), "domains": sorted(domains),
            "findings": len(findings)}


def read(filled_path, pack):
    """The round trip: verify the binding, then return the reviewer's decisions. Problems are
    returned beside the decisions — a partially valid review is reported, never silently
    truncated to its valid half."""
    from openpyxl import load_workbook

    import hashlib                                                          # noqa: PLC0415
    from rwd_tools import product_gates as pgt                                             # noqa: PLC0415
    data = _extraction(pack)
    want_fp = str((data.get("extraction") or {}).get("fingerprint") or "")
    known = {r.get("item_id"): r for r in data.get("rows") or []}
    with open(filled_path, "rb") as fh:
        filled_sha = hashlib.sha256(fh.read()).hexdigest()
    wb = load_workbook(filled_path, data_only=True)
    if "Provenance" not in wb.sheetnames:
        sys.exit("ROUND TRIP REFUSED — no Provenance tab; this is not a review workbook this "
                 "tool built")
    prov = {str(r[0].value): str(r[1].value) for r in wb["Provenance"].iter_rows(max_col=2)
            if r[0].value}
    if prov.get("extraction_fingerprint") != want_fp:
        sys.exit(f"ROUND TRIP REFUSED — the workbook was built from extraction "
                 f"{prov.get('extraction_fingerprint')!r} but the pack's current extraction is "
                 f"{want_fp!r}. The specification moved under the review; rebuild the workbook "
                 f"and re-review what changed.")
    decisions, problems, seen = [], [], set()
    # A REVIEW THE REVIEWER COULD NOT SEE IS NOT A REVIEW. iter_rows reads hidden rows exactly
    # like visible ones, so a hidden row's ACCEPT used to count while the person never saw it —
    # and the tabs this tool built must all still exist, because deleting Findings deletes the
    # detail the reviewer was supposed to weigh.
    for want_tab in ("Findings", "Decisions"):
        if want_tab not in wb.sheetnames:
            problems.append(f"the {want_tab} tab is missing — this tool built it, so its "
                            f"absence means the file was altered beyond the reviewer columns")
    lint = _lint_cells(data)
    for name in wb.sheetnames:
        ws = wb[name]
        if ws.sheet_state != "visible":
            problems.append(f"sheet {name!r} is {ws.sheet_state} — content the reviewer could "
                            f"not see cannot carry a review")
        if name in ("Provenance", "Findings"):
            continue
        hdr = [str(c.value or "") for c in ws[1]]
        if not hdr or hdr[0] != "item_id":
            continue
        hidden_rows = sorted(i for i, d in ws.row_dimensions.items() if d.hidden)
        if hidden_rows:
            problems.append(f"sheet {name!r} carries hidden row(s) {hidden_rows[:8]} — rows "
                            f"the reviewer never saw would still round-trip as reviewed")
        hidden_cols = sorted(c for c, d in ws.column_dimensions.items() if d.hidden)
        if hidden_cols:
            problems.append(f"sheet {name!r} carries hidden column(s) {hidden_cols[:8]} — a "
                            f"hidden machine column hides what the decision was about")
        idx = {h: i for i, h in enumerate(hdr)}
        absent_cols = [c for c in MACHINE_COLS + REVIEW_COLS if c not in idx]
        if absent_cols:
            problems.append(f"sheet {name!r} lost column(s) {absent_cols} — not a workbook "
                            f"this tool built")
            continue
        for row in ws.iter_rows(min_row=2):
            vals = [c.value for c in row]
            item = str(vals[idx["item_id"]] or "").strip()
            if not item:
                continue
            if item in seen:
                problems.append(f"{item}: appears twice — duplicated ids cannot round-trip")
                continue
            seen.add(item)
            if item not in known:
                problems.append(f"{item}: not in the pack's extraction — a row was added or "
                                f"an id edited; this review cannot bind to it")
                continue
            # EVERY MACHINE CELL VERIFIED, not trusted. Verifying only content_hash and
            # variable left the VISIBLE text cells free to edit: a definition flipped to its
            # opposite still hash-bound to the real extraction, so the reviewer accepted
            # words that were not the specification's. The lint cells are recomputed too —
            # what severity the reviewer saw beside a row is part of what they reviewed.
            wants = _machine_values(known[item], lint)
            for col, want in zip(MACHINE_COLS, wants):
                have = str(vals[idx[col]] if vals[idx[col]] is not None else "")
                if have != str(want if want is not None else ""):
                    problems.append(f"{item}: machine cell `{col}` was edited "
                                    f"({have!r} != {str(want)!r}) — the decision cannot bind")
                    break
            else:
                decision = str(vals[idx["reviewer_decision"]] or "").strip().upper()
                if not decision:
                    continue
                entry = {"item_id": item, "decision": decision,
                         "comment": str(vals[idx["reviewer_comment"]] or "").strip(),
                         "reviewed_by": str(vals[idx["reviewed_by"]] or "").strip(),
                         "reviewed_date": str(vals[idx["reviewed_date"]] or "").strip()}
                if decision not in DECISION_WORDS:
                    problems.append(f"{item}: decision {decision!r} is not one of "
                                    f"{'/'.join(DECISION_WORDS)}")
                    continue
                why = (pgt.not_a_person(entry["reviewed_by"])
                       if entry["reviewed_by"] else "is not set")
                why = why or (pgt.bad_date(entry["reviewed_date"])
                              if entry["reviewed_date"] else "is not set")
                if why:
                    problems.append(f"{item}: {decision} but the reviewer identity/date: "
                                    f"{why} — an unowned choice is not a review")
                    continue
                decisions.append(entry)
    absent = sorted(set(known) - seen)
    if absent:
        problems.append(f"{len(absent)} extracted item(s) missing from the workbook (a domain "
                        f"sheet deleted or rows removed) — e.g. {absent[:5]}; a review that "
                        f"cannot see every item is a review of a subset wearing the whole "
                        f"file's fingerprint")
    return {"pack": repo_relative(pack), "extraction_fingerprint": want_fp,
            "filled_sha256": filled_sha,
            "counts": {"items_total": len(known), "items_in_workbook": len(seen),
                       "decided": len(decisions)},
            "decisions": decisions, "problems": problems,
            "note": "transport only — a person applies these through the governed tools"}



# --- THE SEMANTIC TEMPLATE, AS A REVIEWABLE WORKBOOK ---------------------------------------
#
# JSON-LD is the right INTERNAL form and the wrong REVIEW form. The people who know whether an
# age band is 18-45 or 18-40, or whether baseline ECOG looks back 30 days or 180, do not read
# `@graph` arrays — and a semantic layer nobody clinical can check is one whose values were
# guessed. Same round trip as the extraction review above: stable ids, a fingerprint that
# refuses a drifted file, four reviewer columns, and nothing written into the repository.
# `definition` and `also_known_as` are what make a row REVIEWABLE: a clinician asked whether
# `ECOG_PS` is right cannot answer from the name, and asked whether a spec row means it cannot
# answer without the spellings the programme already maps to it.
# THREE COLUMNS FOR TWO CLAIMS. `domain` is this programme's own analytic domain and stays what it
# always was; `mcode_profile` and `mcode_iri` are the MAPPING to the standard, which is a separate
# question with a separate answer — eighteen masters have a domain and no profile, and merging the
# two columns is what lost their domain entirely in an earlier cut. A reviewer needs the profile
# name to judge the mapping and the IRI to check it against HL7, and neither substitutes for the
# other.
CONCEPT_COLS = ("concept_id", "concept", "domain", "mcode_profile", "mcode_iri", "state",
                "definition", "also_known_as", "slots_required", "engine_coverage", "citations")
SLOT_COLS = ("slot_id", "concept", "slot", "what_it_parameterises", "current_value")
# The reviewer's OWN column, separate from a decision: `proposed_value` is where a band list or
# a window actually gets written. A decision alone cannot carry "18-45, 45-65, 65+".
SLOT_INPUT = ("proposed_value",) + REVIEW_COLS


def _mcode_cells(node):
    """(readable, iri) for a concept's mCODE MAPPING — the three states a reviewer must tell apart.

    MAPPED carries the profile title, its confidence, and the canonical HL7 URL. NOT TYPED says so
    with the recorded reason, because a blank cell reads as "nobody looked" and the whole point of
    that state is that somebody did. FAN-OUT is the one a reviewer most needs: the family has no
    single mapping, so the cell names each member with its own profile and confidence rather than
    leaving the row looking unmapped.

    EVERY RETURN IS A STRING. The field this reads became `{"@id": ...}` once and openpyxl refused
    the whole workbook; the invariant is enforced here rather than hoped for at the cell.
    """
    prof = node.get("rwdp:mcodeProfile")
    if isinstance(prof, dict):
        iri = str(prof.get("@id") or "")
        label = str(node.get("rwdp:mcodeProfileLabel") or "") or iri.rsplit("/", 1)[-1]
        conf = str(node.get("rwdp:mcodeConfidence") or "")
        cav = str(node.get("rwdp:mcodeCaveat") or "")
        cell = f"{label} ({conf})" if conf else label
        # THE CAVEAT TRAVELS. It is the sentence naming what the profile does not cover, and a
        # reviewer checking a `partial` mapping cannot judge it from the profile name alone.
        return (f"{cell} — {cav}" if cav else cell), iri

    state = str(node.get("rwdp:mcodeState") or "")
    if state == "fanout":
        parts = []
        for r in (node.get("rwdp:mcodeByVariable") or []):
            var = str(r.get("rwdp:variable") or "")
            lab = str(r.get("rwdp:mcodeProfileLabel") or "")
            if lab:
                conf = str(r.get("rwdp:mcodeConfidence") or "")
                parts.append(f"{var}: {lab} ({conf})" if conf else f"{var}: {lab}")
            else:
                parts.append(f"{var}: not typed by mCODE")
        return ("ruled per variable — " + "; ".join(parts)) if parts else "ruled per variable", ""
    if state:
        note = str(node.get("rwdp:mcodeNote") or "")
        return (f"not typed by mCODE — {note}" if note else "not typed by mCODE"), ""
    return "", ""


def _template_doc(tumour):
    from rwd_tools import semantic_export as se                                            # noqa: PLC0415
    import hashlib                                                          # noqa: PLC0415
    base = "https://purl.invalid/rwd"          # review is about MEANING, not about namespaces
    doc, report = se.template(tumour, base)
    fp = hashlib.sha256(se.serialize(doc).encode("utf-8")).hexdigest()[:16]
    layers = {g["@id"].rsplit("/", 1)[-1]: g["@graph"] for g in doc["@graph"]}
    return doc, report, fp, layers


def build_concepts(tumour, out_path):
    """The per-tumour semantic template as one workbook a person can actually read and fill."""
    from openpyxl import Workbook                                           # noqa: PLC0415
    from openpyxl.styles import Font                                        # noqa: PLC0415

    _doc, report, fp, layers = _template_doc(tumour)
    bold = Font(bold=True)
    wb = Workbook()

    prov = wb.active
    prov.title = "Provenance"
    for row in (("tumour", tumour),
                ("template_fingerprint", fp),
                ("concepts", report["concepts"]),
                ("instantiated", report["definitions"]),
                ("available_unused", report["available"]),
                ("generated_by", "review_workbook.py concepts"),
                ("how_to_use",
                 "Fill only the unshaded reviewer columns. `read-concepts` verifies the ids and "
                 "this fingerprint and refuses a file whose template has moved underneath it. "
                 "Nothing here is approved by filling it in — this is transport, not approval."),
                ("what_state_means",
                 "instantiated = this tumour's cut defines it. available = the programme defines "
                 "it and this cut does not use it YET — it is not a statement that it never "
                 "applies, and reusing the name later is the point of listing it.")):
        prov.append(row)
    prov["A1"].font = bold

    cs = wb.create_sheet("Concepts")
    cs.append(list(CONCEPT_COLS) + list(REVIEW_COLS))
    for c in cs[1]:
        c.font = bold
    by_concept = {n["@id"]: n for n in layers.get("concepts", [])}
    inst = {n["rwdp:implementsConcept"]["@id"] for n in layers.get("definitions", [])}
    cov_by_concept = {d["rwdp:implementsConcept"]["@id"]:
                      {"class": d.get("rwdp:coverageClass"), "via": d.get("rwdp:coverageVia")}
                      for d in layers.get("definitions", [])}
    rows = 0
    for cid, node in sorted(by_concept.items()):
        cov = cov_by_concept.get(cid, {})
        mc_label, mc_iri = _mcode_cells(node)
        cs.append([cid.rsplit("/", 1)[-1], node.get("skos:prefLabel", ""),
                   str(node.get("rwdp:domain") or ""), mc_label, mc_iri,
                   "instantiated" if cid in inst else "available",
                   node.get("skos:definition", ""),
                   ", ".join(node.get("skos:altLabel") or []),
                   ", ".join(node.get("rwdp:requiresSlot") or []) or "(none)",
                   # CAN THE ENGINE BUILD IT — an `engine_gap` on a variable a study needs is a
                   # schedule fact the reviewer should see before they debate its definition.
                   " · ".join(x for x in (cov.get("class"), cov.get("via")) if x),
                   "; ".join(node.get("dct:source") or [])])
        rows += 1

    ss = wb.create_sheet("Slots")
    ss.append(list(SLOT_COLS) + list(SLOT_INPUT))
    for c in ss[1]:
        c.font = bold
    slots = 0
    for d in sorted(layers.get("definitions", []), key=lambda n: n["@id"]):
        cid = d["rwdp:implementsConcept"]["@id"]
        label = by_concept.get(cid, {}).get("skos:prefLabel", cid.rsplit("/", 1)[-1])
        for slot in d.get("rwdp:slotUnstated") or []:
            ss.append([f"{cid.rsplit('/', 1)[-1]}::{slot}", label, slot,
                       _slot_help(cid, slot), "(unstated)"])
            slots += 1
    for sheet in (cs, ss):
        for col, width in zip("ABCDEFGHIJKLM",
                              (22, 20, 18, 13, 60, 30, 26, 30, 40, 18, 30, 16, 14)):
            sheet.column_dimensions[col].width = width

    wb.save(out_path)
    return {"tumour": tumour, "fingerprint": fp, "concepts": rows, "slots": slots,
            "available": report["available"]}


def _slot_help(concept_iri, slot):
    """The slot's own description from the inventory — the reviewer should not have to guess what
    `anchor` or `bands` means, and a workbook that made them guess would collect guesses."""
    from rwd_tools import semantic_export as se                                            # noqa: PLC0415
    name = concept_iri.rsplit("/", 1)[-1]
    for m in (se._inventory().get("master") or []):
        if se._slug(str(m.get("name"))) == name:
            return str(((m.get("parameter_slots") or {}).get(slot) or {}).get("description") or "")
    return ""


def read_concepts(filled_path, tumour):
    """Verify a filled concept workbook and PRINT what the reviewer said. Writes nothing."""
    from openpyxl import load_workbook                                      # noqa: PLC0415

    _doc, _report, want_fp, layers = _template_doc(tumour)
    wb = load_workbook(filled_path, data_only=True)
    problems, decisions, values = [], [], []
    prov = {str(r[0]): str(r[1]) for r in wb["Provenance"].iter_rows(values_only=True)
            if r and r[0] is not None}
    if prov.get("template_fingerprint") != want_fp:
        problems.append(
            f"this workbook was built from template {prov.get('template_fingerprint')!r} and the "
            f"current {tumour} template is {want_fp!r} — the concept space moved under the "
            f"review, so the ids in this file may no longer mean what they meant. Rebuild.")
    known_c = {n["@id"].rsplit("/", 1)[-1] for n in layers.get("concepts", [])}
    seen = set()
    for row in wb["Concepts"].iter_rows(min_row=2, values_only=True):
        rec = dict(zip(list(CONCEPT_COLS) + list(REVIEW_COLS), row))
        cid = str(rec.get("concept_id") or "").strip()
        if not cid:
            continue
        if cid not in known_c:
            problems.append(f"Concepts: unknown concept_id {cid!r} — rows were added or reshuffled")
        if cid in seen:
            problems.append(f"Concepts: duplicated concept_id {cid!r}")
        seen.add(cid)
        if any(rec.get(k) for k in REVIEW_COLS) or rec.get("domain"):
            if not rec.get("reviewed_by") or not rec.get("reviewed_date"):
                problems.append(f"Concepts:{cid}: an input with no reviewer name or date is not a review")
            decisions.append({k: (str(v).strip() if v is not None else "")
                              for k, v in rec.items() if k in CONCEPT_COLS + REVIEW_COLS})
    for row in wb["Slots"].iter_rows(min_row=2, values_only=True):
        rec = dict(zip(list(SLOT_COLS) + list(SLOT_INPUT), row))
        sid = str(rec.get("slot_id") or "").strip()
        if not sid or not (rec.get("proposed_value") or any(rec.get(k) for k in REVIEW_COLS)):
            continue
        if not rec.get("reviewed_by") or not rec.get("reviewed_date"):
            problems.append(f"Slots:{sid}: a proposed value with no reviewer name or date is not a review")
        values.append({k: (str(v).strip() if v is not None else "")
                       for k, v in rec.items() if k in SLOT_COLS + SLOT_INPUT})
    return {"tumour": tumour, "fingerprint": want_fp, "problems": problems,
            "concept_inputs": decisions, "slot_values": values,
            "note": "PRINTED, never written. Carrying these into the governed files stays a "
                    "person's act through the tools that own them."}


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    sub = ap.add_subparsers(dest="cmd", required=True)
    b = sub.add_parser("build", help="build the review workbook from the pack's extraction")
    b.add_argument("pack")
    b.add_argument("--out", required=True, help="xlsx path — refused inside the checkout")
    r = sub.add_parser("read", help="verify a filled workbook and print its decisions")
    r.add_argument("filled")
    r.add_argument("pack")
    c = sub.add_parser("concepts", help="build the semantic-template review workbook for a tumour")
    c.add_argument("tumour")
    c.add_argument("--out", required=True, help="xlsx path — refused inside the checkout")
    rc = sub.add_parser("read-concepts", help="verify a filled concept workbook and print it")
    rc.add_argument("filled")
    rc.add_argument("tumour")
    a = ap.parse_args(argv)
    if a.cmd == "concepts":
        out_dir = pack_run.restricted_dir(os.path.dirname(os.path.abspath(
            os.path.expanduser(a.out))), what="the concept review workbook")
        os.makedirs(out_dir, exist_ok=True)
        out = os.path.join(out_dir, os.path.basename(a.out))
        info = build_concepts(a.tumour, out)
        print(f"OK — {info['concepts']} concept(s) ({info['available']} available/unused), "
              f"{info['slots']} slot(s) to fill; wrote {out}")
        return 0
    if a.cmd == "read-concepts":
        res = read_concepts(a.filled, a.tumour)
        print(json.dumps(res, indent=2, sort_keys=True))
        return 1 if res.get("problems") else 0
    if a.cmd == "build":
        out_dir = pack_run.restricted_dir(os.path.dirname(os.path.abspath(
            os.path.expanduser(a.out))), what="the review workbook")
        os.makedirs(out_dir, exist_ok=True)
        out = os.path.join(out_dir, os.path.basename(a.out))
        info = build(a.pack, out)
        print(f"OK — {info['rows']} row(s) across {len(info['domains'])} domain tab(s), "
              f"{info['findings']} finding(s); wrote {out}")
        return 0
    res = read(a.filled, a.pack)
    print(json.dumps(res, indent=2, sort_keys=True))
    # NONZERO ON PROBLEMS: the JSON names them, but a caller checking only the exit code used
    # to see success on a workbook whose bindings had failed — printed-but-passed is fail-open.
    return 1 if res.get("problems") else 0


if __name__ == "__main__":
    from rwd_tools.console import use_utf8
    use_utf8()
    sys.exit(main())
