#!/usr/bin/env python3
"""The master-family lifecycle, held to its own states.

    python3 platform/tools/master_family.py            # the register
    python3 platform/tools/master_family.py --check    # exit non-zero on a state that is not earned

WHAT THIS EXISTS FOR. `docs/MASTER_FAMILY_PROPOSAL.md` grouped 31 unclassified `engine_gap` rows
into families and then argued against applying itself, for a reason it PROVED: a family assembled
from engine_gap rows is a whole-family gap, and `test_no_engine_gap_family_is_ever_scaffolded`
refuses one — because a skeleton for a family no engine reads yields a config that lints clean,
satisfies every gate and produces no variable. So RECOGNISING a reusable shape and DELIVERING its
implementation were forced into one act. Planning could not advance without claiming support that
did not exist, and the proposal named the missing mechanism exactly:

    "There is no field to mark a grouping as proposed, and no field for its reason."

`governance/reference/master_families.yaml` is that field. This is what stops it being decorative.

THE ONE RULE, IN BOTH DIRECTIONS. A family's state and the capability registry must agree:

    proposed / reviewed   -> MUST NOT appear in platform/capabilities.yaml
    implemented / released -> MUST appear in it

Held both ways on purpose. Forward, it stops a family gaining support it never earned — a
`proposed` grouping that quietly acquires a capability is exactly the "unimplemented standard in a
registry reads to a reviewer as support for that standard" failure this repository removed an OMOP
profile over. Backward, it stops a family LOSING the record of support it has: a capability whose
family is not declared here at all is a capability nobody planned, and a family dropped from this
file while its capability remains would silently reopen the same gap.

A STATE IS EVIDENCE, NOT A WORD. `reviewed` names a person and a date, because a grouping somebody
accepted and one nobody read are different objects and the difference cannot live in a label.
`implemented` names its capabilities, so the claim points at the thing that substantiates it.

WHAT IT DELIBERATELY DOES NOT DO. It does not add `master:` to any inventory row. A row keeps no
master until its family reaches `implemented`, which is the order the proposal proved is forced,
and the opposite of the one that looks natural: the engine family lands first, the inventory
assignment follows.
"""
from __future__ import annotations

import argparse
import os
import sys

TOOLS = os.path.dirname(os.path.abspath(__file__))
from rwd_services import workspace_root
ROOT = str(workspace_root(__file__))
REGISTER = os.path.join(ROOT, "governance", "reference", "master_families.yaml")

# THE CLOSED VOCABULARY. A state outside it is reported, never treated as "not implemented" —
# an unrecognised state silently counting as the weakest one is the defect closed in
# source_adapter's REVIEW_STATUSES, and it would land here the same way.
LIFECYCLE = ("proposed", "reviewed", "implemented", "released")
NEEDS_CAPABILITY = ("implemented", "released")
NO_CAPABILITY = ("proposed", "reviewed")


def load():
    from rwd_tools.product_gates import read_yaml                                   # noqa: PLC0415
    doc, err = read_yaml(REGISTER)
    return (doc or {}), err


def capability_masters():
    """{master -> [capability id]} from the capability registry, which is the evidence for the two
    implemented states. Read rather than restated, so this cannot drift from it."""
    from rwd_tools import capability_registry as cr                                      # noqa: PLC0415
    out = {}
    for c in (cr.load().get("capabilities") or []):
        m = str(c.get("master") or "").strip()
        if m:
            out.setdefault(m, []).append(str(c.get("id")))
    return out


def errors():
    """[why the register does not hold], or []."""
    doc, err = load()
    if err:
        return [f"{REGISTER}: cannot be read ({err})"]
    fams = doc.get("families")
    if not isinstance(fams, list) or not fams:
        return [f"{REGISTER}: declares no families — an empty register is not a starting state, "
                f"it is a register that has lost its contents"]
    from rwd_tools import person_rules                                                   # noqa: PLC0415
    from rwd_tools.product_gates import bad_date, unstated                          # noqa: PLC0415

    caps = capability_masters()
    out, seen = [], set()
    for i, f in enumerate(fams):
        tag = f"families[{i}]"
        if not isinstance(f, dict):
            out.append(f"{tag}: must be a mapping")
            continue
        name = str(f.get("master") or "").strip()
        if not name:
            out.append(f"{tag}: names no master")
            continue
        tag = f"{name}"
        if name in seen:
            out.append(f"{tag}: declared twice — which entry governs would depend on file order")
        seen.add(name)
        state = str(f.get("lifecycle") or "").strip()
        if state not in LIFECYCLE:
            out.append(f"{tag}: lifecycle {state or '(unstated)'!r} is not one of {LIFECYCLE} — an "
                       f"unrecognised state would otherwise count as the weakest one silently")
            continue
        # THE RULE, FORWARD: a family that has not been built must not hold a capability.
        if state in NO_CAPABILITY and name in caps:
            out.append(f"{tag}: lifecycle is `{state}` but platform/capabilities.yaml declares "
                       f"{caps[name]} for it — a grouping nobody has implemented is holding the "
                       f"registry entry that says somebody did")
        # ...AND BACKWARD: a family that HAS been built must say so.
        if state in NEEDS_CAPABILITY and name not in caps:
            out.append(f"{tag}: lifecycle is `{state}` and no capability in "
                       f"platform/capabilities.yaml names this master — the state claims code that "
                       f"nothing points at")
        if state == "reviewed":
            for field, check in (("reviewed_by", person_rules.not_a_person),
                                 ("reviewed_on", bad_date)):
                v = f.get(field)
                why = "is not set" if unstated(v) else check(v)
                if why:
                    out.append(f"{tag}: lifecycle is `reviewed` but {field} {why} — a grouping "
                               f"somebody accepted and one nobody read are different objects, and "
                               f"the difference cannot live in a label")
        if state == "proposed" and unstated(f.get("rationale")):
            out.append(f"{tag}: lifecycle is `proposed` and states no rationale — a grouping "
                       f"without its reasoning is a name, and the whole content of a proposal is "
                       f"why somebody drew the line where they did")
    # ...AND NO CAPABILITY MAY EXIST FOR A FAMILY THIS REGISTER HAS NEVER HEARD OF.
    for m in sorted(set(caps) - seen):
        out.append(f"{m}: platform/capabilities.yaml declares {caps[m]} for a master this register "
                   f"does not carry — a capability nobody planned, and the register cannot report "
                   f"a lifecycle it was never told about")
    return out


def render():
    doc, err = load()
    if err:
        return f"cannot read {REGISTER}: {err}"
    fams = doc.get("families") or []
    caps = capability_masters()
    L = ["", "=" * 88, "  MASTER FAMILIES — what is planned, and what is actually built", "=" * 88,
         "  proposed/reviewed carry NO capability and are NOT scaffolded. Only implemented and",
         "  released point at code.", ""]
    for state in LIFECYCLE:
        rows = [f for f in fams if isinstance(f, dict) and f.get("lifecycle") == state]
        if not rows:
            continue
        L.append(f"  {state.upper()} — {len(rows)}")
        for f in sorted(rows, key=lambda r: str(r.get("master"))):
            n = str(f.get("master"))
            extra = (f"  {len(caps.get(n, []))} capability(ies)" if state in NEEDS_CAPABILITY
                     else (f"  {f.get('rows')} row(s)" if f.get("rows") else ""))
            L.append(f"      {n:<34}{extra}")
            if f.get("contested"):
                L.append(f"          contested: {str(f['contested'])[:70]}")
        L.append("")
    bad = errors()
    L += [f"  {len(bad)} problem(s)", ""]
    for b in bad:
        L.append(f"    ! {b}")
    return "\n".join(L)


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__.strip().splitlines()[0])
    ap.add_argument("--check", action="store_true", help="exit non-zero on any problem")
    a = ap.parse_args(argv)
    bad = errors()
    if a.check:
        for b in bad:
            print(f"  ! {b}", file=sys.stderr)
        print(f"{len(bad)} master-family lifecycle problem(s)")
        return 1 if bad else 0
    print(render())
    return 0


if __name__ == "__main__":
    # EVERY TOOL SETS ITS OWN CONSOLE ENCODING. Without it an em dash in any message this
    # prints raises UnicodeEncodeError under a Windows code page — and every message here has
    # one. `test_every_tool_entry_point_sets_its_own_console_encoding` caught both of these.
    from rwd_tools.console import use_utf8
    use_utf8()
    sys.exit(main())
