#!/usr/bin/env python3
"""Assemble a cancer's variable template from composable modules — a PROTOTYPE, on two cancers.

    python3 platform/tools/oncology_registry.py --list
    python3 platform/tools/oncology_registry.py prostate            # the assembled template
    python3 platform/tools/oncology_registry.py prostate --coverage # against the existing overlay
    python3 platform/tools/oncology_registry.py --check             # GATE: exit 1 on a broken registry

WHAT THIS IS TESTING. `governance/reference/variable_inventory/INVENTORY.yaml` holds 13 tumour
overlays, 509 variables and 37 recurring shapes, each overlay written whole. The proposal under
test is that an overlay is not the unit — that it decomposes into

    core  +  axis(broad)  +  axis(narrow)  +  indication

and that a new cancer therefore starts from a large body of reviewed content rather than a blank
sheet. This assembles two of them, prostate and CLL, and nothing else.

WHAT `--check` ENFORCES, stated because an earlier cut of this file claimed more than it did. It
refuses: an orphan in any catalogue cancer, a variable claimed by two concepts, a concept defined in
two tiers, a realisation naming a variable the overlay lacks, a module the catalogue implies and
disk lacks, a module whose YAML will not parse, and a maturity past `candidate_template` with no
named reviewer. It does NOT check that a tier assignment is clinically right, that a definition
round-trips, or that a shape matches the inventory's — those are review, and the map is unreviewed.

THE EXPERIMENT IS FALSIFIABLE, WHICH IS THE POINT. `--coverage` re-derives each overlay from the
modules and compares against the overlay as written. Every existing variable must be claimed by
exactly one module entry. An ORPHAN (nothing claims it) means the decomposition is incomplete; a
DUPLICATE (two modules claim it) means the tiers overlap. Either is the proposal failing on real
data, and both are more useful than a table that was made to add up.

CALLED AN AXIS, NOT A FAMILY, AND THAT IS DELIBERATE. This repository already uses `family` for the
products directory — `products/<family>/<slug>/<YYYYMM>`, where a product carrying `family: heme`
lands under `products/heme/` — and `heme` is separately a value of `tumor_class`, closed to
{solid, heme} at `platform/engine/validate.py:47`. A fifth live meaning of one word is how a
clinical grouping ends up deciding a directory. `axis` cannot be confused with either, and this
registry stays under `governance/` so nothing it declares can reach `platform/engine`.

TWO AXES, NOT ONE. An earlier form of this proposal had nine families — solid,
haematological, thoracic, gynaecological, GU, lymphoid, myeloid, sarcoma, head-and-neck. Measured
against the 13 tumours already here, ELEVEN land in two of them at once: CLL is haematological and
lymphoid, NSCLC is solid and thoracic. One tier could not partition them. Two can, and every cancer
takes exactly one value on each:

    broad   solid | haematological
    narrow  thoracic | gynaecological | genitourinary | lymphoid | myeloid | plasma_cell |
            gastrointestinal | sarcoma | head_and_neck

That measurement also found two of this repository's own tumours unhoused by the original nine:
multiple myeloma is neither lymphoid nor myeloid, and mCRC needed a gastrointestinal family that
was on the "later" list. Both are in the narrow axis above.

TIERS ARE DECIDED BY REUSE, NOT BY FREQUENCY, and this is the trap the design most had to avoid.
The obvious way to build the core is to count: a variable in all 13 overlays is core, one in a
single overlay is indication. That is wrong here, because the counts measure who drafted which
overlay. Ten of the thirteen declare overall survival and no death date — and overall survival
cannot be computed without one. Frequency would have promoted OS to core and left DEATH_DATE an
indication quirk, encoding a drafting gap as clinical structure. So each entry states WHY its tier
is right, and `realises` names the existing variable it accounts for rather than being derived
from it. Some absences are genuine: prostate omits SEX correctly.

THREE LAYERS: SLOT, CONCEPT, VARIABLE. A SLOT is a reusable position in a template — "the
baseline prognostic marker", "the comorbidity burden score". A CONCEPT is what that position means
in ONE cancer — baseline PSA in prostate, baseline beta-2 microglobulin in CLL. A VARIABLE is what
the product publishes — `PSA_BASE`, `BETA2_MICROGLOBULIN`. The slot is what is reused; the concept
is what is reviewed; the variable is what is built.

An earlier cut collapsed slot and concept and carried an `instrument_varies` flag to paper over the
difference. On 14 entries that flag was hiding materially different concepts, not different
instruments: STEM_CELL_TRANSPLANT covered AUTOLOGOUS transplant in DLBCL and ALLOGENEIC in MDS —
different procedures, different eligibility, different intent. Now each cancer names its own
concept and "do they mean the same thing" is DERIVED by comparing those names, so it cannot drift.

SHAPE IS NOT MEANING. The 37 masters are structural shapes, and this repository has already been
bitten by treating them as shared meanings — pooling by master let prostate's BRCA12 resolve
through myelofibrosis's JAK2, which is why `semantic_binding.fanout_masters()` exists.
GENE_VARIANT_STATUS alone holds 33 variables across 10 tumours, including TP53_MUTATION_STATUS in
CLL, TP53_ALLELIC_STATE in MDS and P53 in endometrial: one shape, three clinical questions. Every
entry here therefore carries `clinical_role` and `applicability`, which is what tells two
same-shaped concepts apart, and `shape` is recorded as the representation it happens to use.

WHAT A CONCEPT SAYS ABOUT ITSELF, and where it comes from. A concept carries a definition, the
sources it requires, its evidence, the engine surface that builds it, and the values it pins for
the parameters its SLOT declares. None of that is authored here — `INVENTORY.yaml` already holds a
definition sketch, `common_sources`, `citations` and a `coverage` class for all 509 variables, and
`parameter_slots` on each master. The registry re-keys what exists onto the concept that owns it.

WHAT IS STILL MISSING IS COUNTED RATHER THAN HIDDEN. Measurement detail — the canonical vocabulary
is `registry_schema.MEASUREMENT` — is unstated on EVERY concept, not merely on most. So is every
parameter: 50 slots declare 132 parameter keys, the concepts open 169 slots to answer them, and
NOT ONE carries a value. `--coverage` prints the fill rate per field and both read 0. A concept
with a definition and no measurement window is honestly half-specified; refusing it would delete
the half that exists, and pretending it is complete is worse. The contract side is where those
answers come from, which is what a confirmed reconciliation is FOR.

AND IT IS A PROTOTYPE. Two cancers of thirteen, decomposed from content that was itself never
clinically approved — `INVENTORY.yaml` says `status: reference_only` and calls itself a drafting
aid. Nothing here is a clinical template, no entry is approved, and `--check` refuses any module
that claims otherwise. What it can tell you is whether the SHAPE of the proposal survives contact
with two structurally different cancers, which is the only question worth answering before
building the other eleven.
"""
from __future__ import annotations

import argparse
import os
import sys
from rwd_tools.spec_extract import repo_relative  # noqa: E402

TOOLS = os.path.dirname(os.path.abspath(__file__))
from rwd_services import workspace_root
ROOT = str(workspace_root(__file__))

MODULES = os.path.join(ROOT, "governance", "reference", "oncology_modules")
CATALOGUE = os.path.join(MODULES, "CATALOGUE.yaml")
INVENTORY = os.path.join(ROOT, "governance", "reference", "variable_inventory", "INVENTORY.yaml")

# The two axes. Every cancer takes exactly one value on each; see the module docstring for why one
# tier could not do it.
BROAD = ("solid", "haematological")
NARROW = ("thoracic", "gynaecological", "genitourinary", "lymphoid", "myeloid", "plasma_cell",
          "gastrointestinal", "sarcoma", "head_and_neck")

# WHERE A CONCEPT IS REUSABLE. Ordered widest first, because that is the order the assembly applies
# them and the order a reviewer reads them.
TIERS = ("core", "axis:broad", "axis:narrow", "indication")

# HOW COMPLETE THE TEMPLATE FOR A CANCER IS — a property of the CANCER, and deliberately not the
# same ladder as a pack's gate status. `product_gates` already tracks contract and configuration
# levels per PACK, and one cancer can have several packs across refreshes and specifications.
# Collapsing the two would make "this cancer has reviewed content" and "this pack passed Gate 2"
# the same statement, and they are not.
MATURITY = ("registered", "axis_supported", "candidate_template", "clinically_reviewed",
            "source_implementable", "production_approved")

# What a machine-drafted module may claim. Nothing here may be `clinically_reviewed` or better
# without a named person, the same bar every other ruling in this repository carries.
MACHINE_MAX = "candidate_template"

APPLICABILITY = ("diagnosis", "watch_and_wait", "pre_line", "on_treatment", "end_of_treatment",
                 "followup", "any")


def _yaml(path):
    """(doc, error) through the one governed reader.

    THE PATHS BELOW GO THROUGH repo_relative, and CI is why. An audit judged this helper safe to
    leave on `os.path.relpath` because "its callers are all in-checkout"; the Windows lane
    disproved that with a traceback — `test_a_module_that_will_not_parse_is_fatal_rather_than
    _skipped` hands it a module written to a TEMP directory, and a GitHub runner checks out to D:
    with temp on C:. Both lines raised `ValueError: path is on mount 'C:', start on mount 'D:'`
    while trying to BUILD AN ERROR MESSAGE, so a helper whose job is to report a bad file failed
    to report it. Both uses are display-only, so the separator does not matter here.
    """
    from rwd_tools import product_gates as pg                                            # noqa: PLC0415
    if not os.path.exists(path):
        return {}, f"{repo_relative(path, ROOT)} does not exist"
    doc, err = pg.read_yaml(path)
    if err:
        return {}, f"{repo_relative(path, ROOT)}: {err}"
    return doc or {}, None


def catalogue():
    """{slug: {broad, narrow, maturity, ...}} — the cancers this registry knows.

    IDENTIFYING A CANCER IS NOT DESCRIBING IT. The catalogue says which axes a cancer sits
    on and how mature its template is; it says nothing about which variables it needs. Keeping
    those apart is what lets the catalogue eventually cover every cancer while the template content
    grows in reviewed waves.
    """
    doc, err = _yaml(CATALOGUE)
    if err:
        return {}
    return {str(k): (v or {}) for k, v in (doc.get("cancers") or {}).items()}


def module_files():
    """[(tier, path)] for every module on disk, widest tier first."""
    out = []
    for name in ("core.yaml",):
        p = os.path.join(MODULES, name)
        if os.path.exists(p):
            out.append(("core", p))
    for tier, sub in (("axis:broad", "axis"), ("axis:narrow", "axis"),
                      ("indication", "indication")):
        d = os.path.join(MODULES, sub)
        if not os.path.isdir(d):
            continue
        for name in sorted(os.listdir(d)):
            if not name.endswith(".yaml"):
                continue
            p = os.path.join(d, name)
            stem = name[:-5]
            got = "axis:broad" if stem in BROAD else \
                  "axis:narrow" if stem in NARROW else "indication"
            if got == tier and (tier, p) not in out:
                out.append((tier, p))
    return out


def load_modules():
    """({module name: {...}}, [problem]) — every module, read once, and what would not read.

    A READ ERROR IS FATAL, NOT A SKIP. This swallowed the error and carried on, so a module whose
    YAML would not parse simply vanished from the registry — and because the completeness check
    was also missing, the whole tier disappeared and `--check` still passed. Two silences
    compounding is how a gate ends up proving nothing.
    """
    out, problems = {}, []
    for tier, path in module_files():
        doc, err = _yaml(path)
        if err:
            problems.append(f"{err} — a module that will not parse is not an absent module")
            continue
        name = os.path.basename(path)[:-5]
        key = "core" if tier == "core" else f"{tier.split(':')[0]}:{name}" \
            if tier.startswith("axis") else f"indication:{name}"
        # THE MATURITY IS DECLARED IN EVERY MODULE AND WAS DISCARDED HERE. Each file states
        # `status: candidate  # machine-drafted; no clinician has reviewed this` with
        # `reviewed_by: null`, and this kept only `entries` at the top level — so `modules()`
        # reported `status: None` for all seven and NOTHING DOWNSTREAM COULD BE MATURITY-SENSITIVE.
        # A new cancer was therefore offered machine-drafted concepts through the same surface,
        # with the same shape, as reviewed ones. Surfaced, not invented: `doc` carried it all along.
        out[key] = {"tier": tier, "path": path, "doc": doc,
                    "status": doc.get("status"),
                    "reviewed_by": doc.get("reviewed_by"),
                    "reviewed_on": doc.get("reviewed_on"),
                    "entries": list(doc.get("entries") or [])}
    return out, problems


REVIEWED = "reviewed"          # a person has read this module and put their name to it


def module_reviewed(m):
    """True only when a NAMED PERSON reviewed the module ON A DATE.

    A FIRST VERSION ACCEPTED ANY NON-BLANK STRING, which is the bar this repository refuses
    everywhere else: `DataExpert`, `x` and `(your name)` all passed, and no review date was required at
    all. A review attributed to a function is one nobody can be asked about, and a review with no
    date cannot be checked against the thing it reviewed.

    HELD TO `product_gates.not_a_person`, which is the repository's ONE answer to "is this a
    person's name" @D@ it already refuses declared team markers and bare ALL-CAPS acronyms while
    admitting initials, and a second private notion of a name here would drift from it. Imported
    inside the function because `product_gates` imports this module.
    """
    from rwd_tools.product_gates import not_a_person, unstated                      # noqa: PLC0415
    if str(m.get("status") or "").strip().lower() != REVIEWED:
        return False
    who = str(m.get("reviewed_by") or "").strip()
    if not who or unstated(who) or not_a_person(who):
        return False
    when = str(m.get("reviewed_on") or "").strip()
    return bool(when) and not unstated(when)


def review_state(slug, cat=None, mods=None):
    """What a cancer is actually being offered, split by whether a person has signed for it.

    ONBOARDING'S CENTRAL CLAIM IS THAT A NEW CANCER STARTS FROM REVIEWED CONTENT RATHER THAN A
    BLANK SHEET, and nothing measured it. Today the honest answer is that every module is
    `candidate` with `reviewed_by: null`, so the count is zero — which does not make the seed
    useless, it makes it a drafting aid, which is what its own header calls it. The difference
    only becomes visible if something reports it.
    """
    mods = mods if mods is not None else modules()
    names = modules_for(slug, cat, mods)
    reviewed = [n for n in names if module_reviewed(mods[n])]
    slots = {n: len(mods[n]["entries"]) for n in names}

    # A SLOT IS NOT A CONCEPT, and calling every assembled slot a "concept" overstated what a
    # cancer has by the size of its own worklist. CLL assembles 60 slots; 35 of them name a CLL
    # concept and the other 25 are PROMPTS — reviewed questions with no answer for this cancer
    # yet. Reporting 60 concepts counted the questions as answers.
    filled = [e for e in assemble(slug, cat, mods) if concepts_of(e).get(slug)]
    return {"modules": names, "reviewed_modules": reviewed,
            "unreviewed_modules": [n for n in names if n not in reviewed],
            "slots": sum(slots.values()),
            "concepts": len(filled),          # slots that name a concept FOR THIS CANCER
            "prompts": sum(slots.values()) - len(filled),
            "concepts_reviewed": sum(1 for e in filled
                                     if module_reviewed(mods[e["module"]])),
            "by_module": slots}


def modules(*a, **k):
    """Just the modules, for callers that do not gate. `load_modules` carries the problems."""
    return load_modules(*a, **k)[0]


def module_names(slug, entry):
    """Declared reference dependencies, including absent modules for digest/check callers."""
    if entry.get("condition_class", "oncology") == "non_oncology":
        # The pan-oncology core is not a general clinical library. Independent
        # conditions start with their own reference; reuse remains explicit.
        return [f"indication:{slug}"]
    return [name for name in ("core",
            f"axis:{entry.get('broad')}" if entry.get("broad") else None,
            f"axis:{entry.get('narrow')}" if entry.get("narrow") else None,
            f"indication:{slug}") if name]


def modules_for(slug, cat=None, mods=None):
    """The existing reference modules applicable to one condition."""
    cat = cat if cat is not None else catalogue()
    mods = mods if mods is not None else modules()
    e = cat.get(slug) or {}
    return [w for w in module_names(slug, e) if w in mods]


def assemble(slug, cat=None, mods=None):
    """[entry] — the template for one cancer, composed widest tier first.

    EACH ENTRY CARRIES THE MODULE IT CAME FROM, because "this concept is core" and "this concept is
    prostate-specific" are the difference between something reusable and something that is not, and
    a flattened list loses exactly that.
    """
    mods = mods if mods is not None else modules()
    out = []
    for name in modules_for(slug, cat, mods):
        m = mods[name]
        for e in m["entries"]:
            row = dict(e)
            row["module"] = name
            row["tier"] = m["tier"]
            # ...AND WHETHER ANYBODY HAS SIGNED FOR IT. A row that reached a study team looked the
            # same whether a clinician had reviewed the module or a script had drafted it.
            row["module_status"] = m.get("status")
            row["module_reviewed"] = module_reviewed(m)
            out.append(row)
    return out


_INV_CACHE = {}


def _inventory():
    """The inventory document, read once per process and keyed on mtime.

    CACHED BECAUSE THE GATE NOW READS IT PER REALISATION. Checking all 107 realisations against
    their overlays meant parsing a 350 KB YAML 107 times and the suite stopped finishing. Same
    reason `semantic_binding._inventory` and `mcode_domains.family_variables` are cached; an edit
    during a long-lived process is still picked up.
    """
    try:
        stamp = os.path.getmtime(INVENTORY)
    except OSError:
        return {}
    if _INV_CACHE.get("stamp") != stamp:
        doc, err = _yaml(INVENTORY)
        _INV_CACHE.update({"stamp": stamp, "doc": {} if err else (doc or {})})
    return _INV_CACHE["doc"]


def _overlay_slugs():
    """{slug} — every tumour INVENTORY.yaml carries, catalogued here or not.

    THE CATALOGUE IS TWO CANCERS; THE INVENTORY IS THIRTEEN. A module may legitimately record that
    a concept is realised in a cancer this prototype has not decomposed — that is what makes the
    reuse claim more than an assertion — but the variable still has to exist.
    """
    return set((_inventory().get("tumours") or {}))


def overlay_slug(slug, cat=None):
    """The INVENTORY OVERLAY name for a cancer, which is not always its product slug.

    THEY MATCH FOR PROSTATE AND CLL AND THAT IS A COINCIDENCE. Ovarian ships as the product `oc`
    and its overlay is `ovarian`; every function here indexed the inventory by the product slug
    directly, so the registry worked for exactly the two cancers whose two names happen to be the
    same word. Adding ovarian would have produced an empty overlay, no orphans, no phantoms and a
    clean coverage report over nothing.

    THREE SOURCES, IN ORDER, AND NO NEW MAPPING INVENTED HERE. The catalogue entry's
    `inventory_overlay` is the governed statement and wins. `variables_scaffold.SLUG_TO_OVERLAY` is
    the mapping this repository already had — `semantic_binding` and `definition_signature` both
    read it — and adding a second one beside it is the two-lists failure this codebase keeps
    paying for. Failing those, the slug is its own overlay, which is what the code assumed
    unconditionally.
    """
    entry = (cat or catalogue()).get(slug) or {}
    declared = str(entry.get("inventory_overlay") or "").strip()
    if declared:
        return declared
    # the registry's tumour_key is the second rung (slug is the PRODUCT, and
    # dlbcl_optum_claims must index the dlbcl overlay) - one resolver, product_gates owns it
    try:
        from rwd_tools import product_gates as pg                                        # noqa: PLC0415
        tk = pg.tumour_key_for(ROOT, slug)
        if tk:
            return tk
    except Exception:                                                     # noqa: BLE001
        pass
    try:
        from rwd_tools import variables_scaffold as vs                                   # noqa: PLC0415
        return vs.SLUG_TO_OVERLAY.get(slug, slug)
    except Exception:                                                     # noqa: BLE001
        return slug


def overlay_variables(slug):
    """{variable name} — what the existing inventory overlay declares for this cancer.

    THE THING THE ASSEMBLY IS TESTED AGAINST. Read from INVENTORY.yaml rather than restated here,
    so the comparison cannot drift from what it compares to.
    """
    body = (_inventory().get("tumours") or {}).get(overlay_slug(slug)) or {}
    return {str(v.get("name")) for v in (body.get("variables") or []) if v.get("name")}


# WHAT A CONCEPT MAY STATE ABOUT ITSELF, beyond its name and the variable it publishes. Every one
# of these is pulled from `INVENTORY.yaml`, which already carries a definition sketch, the sources
# a variable needs, its citations and the engine surface that builds it for all 509 variables. The
# registry does not invent clinical content; it re-keys what the inventory holds onto the concept
# that owns it, and reports what is still missing.
CONCEPT_DETAIL = ("definition", "source_requirements", "evidence", "implementation",
                  "parameter_values", "derivation")

# WHAT MUST BE PINNED BEFORE A CONCEPT IS BUILDABLE. A definition says what it means; these say how
# it is measured, and a template that omits them is reusable only in the sense that a blank form is.
#
# IMPORTED, NOT REDECLARED. This was a tuple defined here and read by nothing — six words that
# looked like a schema and were not, while the reconciler used seven different words for the same
# ideas and nothing mapped between them. The canonical vocabulary and both dialects now live in
# `registry_schema`, so there is one list and one transformation rather than two lists and a hope.
def _measurement_keys():
    from rwd_tools import registry_schema as rs                                          # noqa: PLC0415
    return rs.MEASUREMENT


def shape_audit(mods=None):
    """What can and cannot be checked about the shape each concept claims.

    THE HONEST FORM OF "ONE DISAGREEMENT". The gate compares a concept's `shape` to the master the
    inventory gives its variable, and reports a difference unless `shape_change_reason` explains
    it. That check only runs when BOTH are present — so on a variable the inventory carries with no
    master, ANY shape may be asserted and nothing objects. Reporting the single disagreement
    without saying how many assignments were checkable makes a partial audit read as a complete
    one, which is the more misleading of the two numbers.
    """
    have = {}
    for t, b in (_inventory().get("tumours") or {}).items():
        for v in ((b or {}).get("variables") or []):
            have[(str(t), str(v.get("name")))] = str(v.get("master") or "")
    out = {"checkable": 0, "unverifiable": 0, "disagreements": []}
    for _n, m in (mods or modules()).items():
        for e in m["entries"]:
            for slug, rec in concepts_of(e).items():
                for v in realised(e, slug):
                    was, now = have.get((slug, v)), str(rec.get("shape") or "")
                    if was is None:
                        continue
                    if was and now:
                        out["checkable"] += 1
                        if was != now:
                            out["disagreements"].append(
                                {"cancer": slug, "variable": v, "inventory": was, "registry": now,
                                 "explained": bool(str(rec.get("shape_change_reason") or "").strip())})
                    else:
                        out["unverifiable"] += 1
    return out


def parameters_of(entry):
    """{name: description} — what this slot leaves open for each cancer to pin.

    THE SLOT DECLARES THE PARAMETERS; THE CONCEPT FILLS THEM. This is the clearest evidence the
    three-layer split was the right shape: the inventory already carries `parameter_slots` on the
    MASTER, not on the variable — COMORBIDITY_INDEX declares `algorithm` (Quan Charlson, NCI
    Klabunde, Elixhauser) and `lookback` (commonly 12 months), and prostate's CCI and CLL's CIRS
    answer them differently. Parameters were always a property of the reusable position, and the
    collapsed schema had nowhere to put them.
    """
    return {str(k): v for k, v in (entry.get("parameters") or {}).items()}


def detail_completeness(entry):
    """{field: filled count} across a slot's concepts — what is stated and what is still open.

    REPORTED, NOT REFUSED. Most of these fields are unfilled and saying so is the useful answer: a
    concept with a definition and no measurement window is honestly half-specified, and refusing it
    would delete the half that exists. `--check` enforces well-formedness where a field IS filled;
    the report counts what is not.
    """
    cs = concepts_of(entry)
    out = {f: 0 for f in CONCEPT_DETAIL}
    for rec in cs.values():
        for f in CONCEPT_DETAIL:
            v = rec.get(f)
            if isinstance(v, dict):
                if any(x not in (None, "", []) for x in v.values()):
                    out[f] += 1
            elif v not in (None, "", []):
                out[f] += 1
    out["_concepts"] = len(cs)
    return out


def concepts_of(entry):
    """{cancer: {concept, shape, realises, note}} — the cancer-specific meanings filling a slot.

    THREE LAYERS, NOT ONE. A SLOT is a reusable position in a template ("the baseline prognostic
    marker"). A CONCEPT is what that position MEANS in one cancer ("baseline PSA" / "baseline
    beta-2 microglobulin"). A VARIABLE is what the product publishes (`PSA_BASE`,
    `BETA2_MICROGLOBULIN`). Collapsing them is how a registry ends up asserting that two different
    measurements are one thing.

    THE FLAG THIS REPLACES WAS HAND-MAINTAINED AND WRONG. `instrument_varies: true` claimed one
    concept measured by different instruments, and on 14 entries it was hiding materially different
    concepts — STEM_CELL_TRANSPLANT covered autologous transplant in DLBCL and ALLOGENEIC in MDS,
    which is a different procedure with different eligibility, toxicity and intent, not a different
    instrument. Now the concept names are written per cancer and "does the meaning vary" is
    DERIVED from whether they differ, so it cannot drift from the data it describes.
    """
    out = {}
    for slug, rec in (entry.get("concepts") or {}).items():
        if isinstance(rec, dict):
            out[str(slug)] = dict(rec)
    return out


def slot_is_shared(entry):
    """True when every cancer filling this slot means the SAME concept by it.

    DERIVED, NEVER DECLARED. This is the property `instrument_varies` used to assert by hand.
    """
    names = {str(r.get("concept") or "") for r in concepts_of(entry).values()}
    return len(names) == 1


def slot_name(entry):
    """The slot's identifier, tolerating a pre-split entry that still says `concept`."""
    return str(entry.get("slot") or entry.get("concept") or "")


def realisation_slugs(entry):
    """Every cancer slug this slot realises a variable in, nested form or pre-split.

    WHY IT IS A FUNCTION AND NOT `entry["realises"]`. It was the latter, in three places, and the
    slot/concept split moved the map one level down without moving the readers with it. The visible
    damage was cosmetic — `core  None  -`. The invisible damage was not: the external-realisation
    check iterated a key that no longer existed, so the 22 cross-cancer realisations for DLBCL, MDS,
    myeloma and myelofibrosis — the whole evidence base for the claim that the core is reused — went
    unverified, and an invented cancer with an invented variable passed the gate.
    """
    return set(concepts_of(entry)) | set(entry.get("realises") or {})


def realised(entry, slug):
    """[variable] one concept accounts for in one cancer — often one, sometimes more.

    A LIST, BECAUSE ONE CONCEPT CAN BE TWO VARIABLES — though nothing here uses it yet, and that
    distinction was overstated once already. CLL declares RAI_STAGE and BINET_STAGE, one concept in
    two regional conventions, both under CANCER_STAGE_GROUP and both citing the same paper. Typed
    as a single name, `DISEASE_STAGE_AT_DIAGNOSIS` can claim only one and the other must be held
    somewhere. As committed, core claims RAI_STAGE and the CLL indication overlay holds BINET_STAGE
    as its own concept — so the list form is CAPABILITY, available for a reviewer who decides the
    two belong together, and not a change the data has made.

    The other direction stays forbidden. A VARIABLE may still be claimed only once, which is what
    `coverage` checks: two concepts claiming one variable means the tiers overlap and a consumer
    would get the concept twice. So the relation is one-concept-to-many-variables, never the
    reverse. A single string is accepted and read as a list of one.
    """
    rec = concepts_of(entry).get(slug)
    if rec is not None:
        v = rec.get("realises")
    else:
        v = (entry.get("realises") or {}).get(slug)     # pre-split entry, read unchanged
    if not v:
        return []
    return [str(x) for x in (v if isinstance(v, list) else [v]) if x]


def coverage(slug, cat=None, mods=None):
    """Does the assembly account for the existing overlay, exactly once each?

    THE FALSIFIABLE TEST. `orphans` are variables the modules do not claim — the decomposition is
    incomplete. `duplicates` are variables claimed by more than one module — the tiers overlap and
    a consumer would get the concept twice. `phantom` names a variable a module claims that the
    overlay does not have, which means the module is describing something that is not there.

    A clean result is not proof the tiers are RIGHT — a single module claiming everything would
    also come back clean. It is proof the decomposition is complete and disjoint, which is the
    precondition for asking whether the tiers are right.
    """
    entries = assemble(slug, cat, mods)
    have = overlay_variables(slug)
    claimed = {}
    for e in entries:
        for v in realised(e, slug):
            # THE SLOT IS THE CLAIMANT. Read through `slot_name`, not `entry["concept"]`: after the
            # slot/concept split that key is gone, so this reported `None` for every claimant and a
            # duplicate came back as {VAR: [None, None]} — true, and unreadable.
            claimed.setdefault(v, []).append(slot_name(e))
    return {
        "cancer": slug,
        "overlay_variables": len(have),
        "module_entries": len(entries),
        "entries_realising_here": sum(1 for e in entries if realised(e, slug)),
        "by_tier": {t: sum(1 for e in entries if e.get("tier") == t) for t in TIERS},
        "orphans": sorted(have - set(claimed)),
        "duplicates": {k: v for k, v in sorted(claimed.items()) if len(v) > 1},
        "phantom": sorted(set(claimed) - have),
        "accounted": len(have) - len(have - set(claimed)),
    }


# THE MATURITY AT WHICH A CANCER STOPS BEING ALLOWED TO HAVE UNDECOMPOSED VARIABLES.
# `registered` and `axis_supported` both mean "declared, not yet decomposed"; `candidate_template`
# is the first level that asserts drafted indication content exists.
ORPHANS_FATAL_FROM = "candidate_template"


def _orphans_are_fatal(entry):
    """Whether this cancer's undecomposed variables are an ERROR or its WORKLIST."""
    m = str((entry or {}).get("maturity") or "")
    if m not in MATURITY:
        return True                 # an unreadable maturity is held to the strictest reading
    return MATURITY.index(m) >= MATURITY.index(ORPHANS_FATAL_FROM)


def registry_work(cat=None, mods=None):
    """{slug: [variable]} — what each cancer still has to decompose. NOT errors.

    The orphan list of a `registered` cancer is the single most useful thing this registry can
    tell a study team: these are the variables their overlay declares that no reusable position
    claims yet. It was being emitted as a gate failure, which made it invisible as work and made
    onboarding impossible; it is reported here so `--check` can print it WITHOUT failing on it.
    """
    cat = cat if cat is not None else catalogue()
    mods = mods if mods is not None else modules()
    out = {}
    for slug in sorted(cat):
        if _orphans_are_fatal(cat.get(slug) or {}):
            continue                # at this maturity it is an error, and registry_errors has it
        orphans = coverage(slug, cat, mods)["orphans"]
        if orphans:
            out[slug] = orphans
    return out


def _registered_tumours():
    """{slug} from products/registry.yaml, or an empty set when it cannot be read.

    READ DEFENSIVELY. This registry is about CONCEPTS and the product registry is about PRODUCTS;
    one may be present without the other (a rehearsal tree, a docs build). An unreadable product
    registry must not turn into a concept-registry failure.
    """
    out = set()
    # BOTH registries: the concept layer's question is "which tumours exist here at all", and a
    # fixture tumour's concepts are as real as a product's.
    for base in ("products", "fixtures"):
        path = os.path.join(ROOT, base, "registry.yaml")
        if not os.path.exists(path):
            continue
        doc, err = _yaml(path)
        if err or not isinstance(doc, dict):
            continue
        out |= {str(t.get("slug")).strip() for t in (doc.get("tumors") or [])
                if isinstance(t, dict) and str(t.get("slug") or "").strip()}
    return out


def registry_errors(cat=None, mods=None):
    """Problems with the registry. [] is a pass, and `--check` exits on it."""
    cat = cat if cat is not None else catalogue()
    if mods is None:
        mods, read_problems = load_modules()
    else:
        read_problems = []
    out = list(read_problems)
    if not cat:
        return [f"{repo_relative(CATALOGUE, ROOT)}: no cancers — the registry is empty"]
    if not mods:
        return [f"{repo_relative(MODULES, ROOT)}: no modules"]

    for slug, e in sorted(cat.items()):
        condition = e.get("condition_class", "oncology")
        if condition not in ("oncology", "non_oncology"):
            out.append(f"{slug}: condition_class {condition!r} is not oncology or non_oncology")
        if condition == "non_oncology":
            if e.get("broad") != "general" or e.get("narrow") != "general":
                out.append(f"{slug}: an independent condition uses general axes, not oncology classifications")
        elif e.get("broad") not in BROAD:
            out.append(f"{slug}: broad axis {e.get('broad')!r} is not one of {BROAD}")
        if condition != "non_oncology" and e.get("narrow") not in NARROW:
            out.append(f"{slug}: narrow axis {e.get('narrow')!r} is not one of {NARROW}")
        # AN OVERLAY THAT NAMES NOTHING MAKES A CANCER LOOK PERFECTLY DECOMPOSED. `coverage`
        # measures a cancer against the inventory overlay its catalogue row points at, and a row
        # pointing at a name INVENTORY.yaml does not carry resolves to an EMPTY overlay — so the
        # cancer reports 0 variables, 0 accounted and 0 ORPHANS, which is indistinguishable from
        # a complete decomposition and is the exact opposite of one.
        #
        # Measured: mistyping ovarian's overlay as `ovarain` turns 47 declared variables into 0
        # and produces no error at all. This was not hypothetical — the ovarian row was written
        # `inventory_overlay: oc` (the registry SLUG) when the overlay is named `ovarian`, and it
        # silently zeroed that cancer until the numbers were read by hand.
        ov = str(e.get("inventory_overlay") or "").strip()
        if not ov:
            out.append(f"{slug}: no inventory_overlay — the catalogue must say which overlay "
                       f"this cancer is measured against")
        elif ov not in _overlay_slugs():
            out.append(f"{slug}: inventory_overlay {ov!r} is not an overlay INVENTORY.yaml "
                       f"carries (have: {sorted(_overlay_slugs())}). A name that resolves to "
                       f"nothing gives this cancer an EMPTY overlay, so it reports zero "
                       f"variables and zero orphans — which reads as fully decomposed")
        m = str(e.get("maturity") or "")
        if m not in MATURITY:
            out.append(f"{slug}: maturity {m!r} is not one of {MATURITY}")
        elif MATURITY.index(m) > MATURITY.index(MACHINE_MAX) and not str(
                e.get("reviewed_by") or "").strip():
            # A MACHINE MAY NOT CLAIM REVIEW. The same bar DOMAIN_MAP.yaml and
            # EQUIVALENCE_RULINGS.yaml set: past `candidate_template` a person is named or the
            # claim is not made.
            out.append(f"{slug}: maturity {m!r} is past {MACHINE_MAX!r} and names no reviewer — "
                       f"a template nobody reviewed cannot say it was reviewed")

    # EVERY REGISTERED TUMOUR MUST BE IN THE CATALOGUE, and this is the direction that costs
    # something. A tumour in products/registry.yaml with no catalogue row assembles NO modules —
    # `modules_for` returns [] — so its packs are offered nothing, `seed()` refuses them for
    # having no slots, and the registry reports no problem at all, because from its side the
    # cancer does not exist. Ten of the twelve registered tumours were in exactly that state.
    #
    # The reverse is NOT an error: a cancer may be catalogued with no product yet, which is how
    # multiple myeloma and myelofibrosis sit today — both have inventory overlays and no pack.
    # A concept layer is allowed to precede a product; a product is not allowed to precede its
    # concepts silently.
    for slug in sorted(_registered_tumours()):
        if slug not in cat:
            out.append(f"{slug}: is a tumour in products/registry.yaml and has no row in "
                       f"CATALOGUE.yaml, so it assembles NO modules and its packs are offered "
                       f"nothing. Add it at maturity: registered, which claims nothing")

    seen_concepts = {}
    for name, m in sorted(mods.items()):
        for e in m["entries"]:
            c = slot_name(e)
            tag = f"{name}.{c or '?'}"
            if not c:
                out.append(f"{name}: an entry with no slot name")
                continue
            cs = concepts_of(e)
            if not cs and not str(e.get("predicted_gap") or "").strip():
                # A SLOT WITH NO CONCEPTS IS EITHER A PREDICTION OR A MISTAKE, and only one of
                # those is worth keeping. Composing the tiers predicts variables a pack SHOULD
                # declare and does not - neither prostate nor CLL declares a death date though both
                # compute overall survival - and those predictions are the most useful thing this
                # exercise produced. They stay, provided they say what is missing and why. An
                # unexplained empty slot is a reusable position nobody uses.
                out.append(f"{tag}: no `concepts` and no `predicted_gap` — a slot nothing fills "
                           f"is either a prediction, and says so, or an error")
            params = parameters_of(e)
            for slug, rec in sorted(cs.items()):
                if not str(rec.get("concept") or "").strip():
                    out.append(f"{tag}.{slug}: a concept with no name")
                # A FILLED FIELD MUST BE WELL FORMED; an unfilled one is reported, not refused.
                for f in ("definition", "source_requirements"):
                    v = rec.get(f)
                    if v is not None and not str(v).strip():
                        out.append(f"{tag}.{slug}: {f} is present and empty — state it or omit it")
                ev = rec.get("evidence")
                if ev is not None and not isinstance(ev, list):
                    out.append(f"{tag}.{slug}: evidence must be a list of citations, got "
                               f"{type(ev).__name__}")
                impl = rec.get("implementation")
                if impl is not None:
                    if not isinstance(impl, dict) or not impl.get("class"):
                        out.append(f"{tag}.{slug}: implementation must name a coverage `class`")
                # ...and a parameter value may only answer a parameter the SLOT declares, or the
                # concept is pinning something nothing asked for.
                # ...and the SHAPE a concept claims must be the one the inventory gives its
                # variable, or the registry is silently reclassifying it. Seven do disagree, and
                # they are proposals a reviewer must see rather than facts.
                for v in realised(e, slug):
                    src = ((_inventory().get("tumours") or {}).get(overlay_slug(slug)) or {})
                    got = next((x for x in (src.get("variables") or [])
                                if str(x.get("name")) == v), None)
                    if not got:
                        continue
                    was, now = str(got.get("master") or ""), str(rec.get("shape") or "")
                    if (was and now and was != now
                            and not str(rec.get("shape_change_reason") or "").strip()):
                        out.append(f"{tag}.{slug}: types {v!r} as {now!r}; the inventory types it "
                                   f"as {was!r} — a reclassification is a proposal, and needs "
                                   f"`shape_change_reason` before anyone reads it as agreed")
                for k in (rec.get("parameter_values") or {}):
                    if k not in params:
                        out.append(f"{tag}.{slug}: pins parameter {k!r}, which the slot does not "
                                   f"declare — parameters belong to the reusable position")
                if not rec.get("realises"):
                    out.append(f"{tag}.{slug}: names a concept and no product variable — the "
                               f"concept is what the slot MEANS here; the variable is what is "
                               f"published, and a concept publishing nothing is unreachable")
            # A SLOT WHOSE CONCEPTS ALL DIFFER is the interesting case and must be visible, not a
            # hidden boolean. A slot filled by ONE cancer cannot tell you either way.
            if len(cs) > 1 and not slot_is_shared(e) and not str(e.get("why_concepts_differ")
                                                                 or "").strip():
                out.append(f"{tag}: its cancers mean different concepts by it and it does not say "
                           f"why — that difference is the reason the slot layer exists, so it is "
                           f"the one thing a reviewer must be able to read")
            if c in seen_concepts and seen_concepts[c] != name:
                # ONE CONCEPT, ONE HOME. Two tiers defining the same concept is the overlap the
                # two-axis design exists to prevent, and it would silently double on assembly.
                out.append(f"{c}: defined in both {seen_concepts[c]} and {name} — a concept "
                           f"belongs to exactly one tier")
            seen_concepts.setdefault(c, name)
            if not str(e.get("clinical_role") or "").strip():
                out.append(f"{tag}: no clinical_role — without it two same-shaped concepts are "
                           f"indistinguishable, which is the defect this registry exists to fix")
            if not str(e.get("basis") or "").strip():
                out.append(f"{tag}: no basis — a tier assignment with no stated reason cannot be "
                           f"reviewed")
            app = e.get("applicability") or []
            if not app:
                out.append(f"{tag}: no applicability")
            for a in app:
                if a not in APPLICABILITY:
                    out.append(f"{tag}: applicability {a!r} is not one of {APPLICABILITY}")

    # ...and EVERY realisation is checked, including the ones naming a cancer the catalogue does
    # not yet carry. The modules realise 22 variables across myelofibrosis, MDS, DLBCL and myeloma
    # — genuine evidence that a concept is reused beyond the two prototype cancers, and until now
    # entirely unchecked: nothing confirmed those variables exist. An unverified claim of reuse is
    # exactly the kind that makes a core look larger than it is.
    known_overlays = _overlay_slugs()
    for name, m in sorted(mods.items()):
        for e in m["entries"]:
            for slug in sorted(realisation_slugs(e)):
                if slug not in known_overlays:
                    out.append(f"{name}.{slot_name(e)}: realises in {slug!r}, which has no "
                               f"overlay in INVENTORY.yaml — a realisation naming no real cancer "
                               f"cannot be evidence of anything")
                    continue
                have = overlay_variables(slug)
                for v in realised(e, slug):
                    if v not in have:
                        out.append(f"{name}.{e.get('concept')}: realises {v!r} in {slug}, which "
                                   f"that overlay does not declare")

    # ...and every module the catalogue implies must exist. A cancer whose axis module is missing
    # assembles from fewer tiers and says nothing about it.
    for slug, e in sorted(cat.items()):
        for want in module_names(slug, e):
            if want in mods:
                continue
            out.append(f"{slug}: the catalogue implies module {want!r} and it is not on disk — "
                       f"declare it, even empty, so an intentional gap is not a missing file")

    # ...and every realisation must name a variable the overlay actually has, AND every variable
    # the overlay declares must be claimed.
    #
    # THE ORPHAN CHECK WAS MISSING, and it is the one this gate exists for. The docstring said an
    # orphan means the decomposition is incomplete; nothing enforced it. Measured: deleting the
    # ENTIRE core module produced 42 orphans across the two cancers and `registry_errors` returned
    # zero. The gate passed on a registry that had lost half its content.
    for slug in sorted(cat):
        cov = coverage(slug, cat, mods)
        # AN ORPHAN IS FATAL ONLY ONCE THE CANCER CLAIMS TO BE DECOMPOSED, and treating it as
        # fatal from the moment of registration made onboarding CIRCULAR:
        #
        #   1. a cancer must be in the catalogue before `seed()` will offer it anything;
        #   2. the moment it is catalogued, every variable of its overlay is an orphan;
        #   3. `seed()` refuses to run against a registry with errors;
        #   4. so the tool cannot produce the prompts whose whole purpose is to RESOLVE the
        #      orphans, and the only way to add a cancer is to decompose it by hand first.
        #
        # Measured: registering the nine remaining cancers took this gate from clean to 289
        # problems, ALL of them this one kind — no missing module, no bad axis, no duplicate, no
        # phantom. 289 statements of "you have not done the work yet" about work that had just
        # been declared as not done. `registered` MEANS undecomposed; the orphan list is that
        # cancer's worklist and is reported by `registry_work` instead.
        #
        # Fatal from `candidate_template` up, because that level asserts machine-drafted
        # indication content EXISTS — and a cancer claiming a template while its own overlay
        # names variables no module claims is making a false claim about itself.
        if _orphans_are_fatal(cat.get(slug) or {}):
            for v in cov["orphans"]:
                out.append(f"{slug}: {v!r} is declared by the inventory overlay and claimed by no "
                           f"module — the decomposition is incomplete")
        # ...PHANTOMS AND DUPLICATES STAY FATAL AT EVERY MATURITY. Neither is undone work: a
        # phantom realises a variable the overlay does not declare, and a duplicate means two
        # tiers claim one variable. Both are WRONG rather than unfinished, and a newly registered
        # cancer is no more entitled to them than a reviewed one.
        for p in cov["phantom"]:
            out.append(f"{slug}: a module realises {p!r}, which the inventory overlay does not "
                       f"declare")
        for var, concepts in cov["duplicates"].items():
            # The join is computed BEFORE the f-string: a multi-line expression inside a
            # replacement field previously broke the former Python 3.11 CI runtime.
            # Keep the intermediate value readable even though current Python supports it.
            claimed = ", ".join(str(c) for c in concepts)
            out.append(f"{slug}: {var!r} is claimed by {len(concepts)} concepts "
                       f"({claimed}) — the tiers overlap")
    return out


def report(slug=None, cat=None, mods=None):
    """The registry as a person reads it."""
    cat = cat if cat is not None else catalogue()
    mods = mods if mods is not None else modules()
    lines = []
    if slug is None:
        lines.append(f"ONCOLOGY MODULE REGISTRY — {len(cat)} cancer(s), {len(mods)} module(s), "
                     f"{sum(len(m['entries']) for m in mods.values())} concept(s)")
        lines.append("")
        for name, m in sorted(mods.items()):
            lines.append(f"  {name:<32} {len(m['entries']):3} concept(s)")
        lines.append("")
        lines.append(f"  {'CANCER':<14} {'BROAD':<16} {'NARROW':<16} MATURITY")
        for s, e in sorted(cat.items()):
            lines.append(f"  {s:<14} {str(e.get('broad')):<16} {str(e.get('narrow')):<16} "
                         f"{e.get('maturity')}")
        return "\n".join(lines)

    cov = coverage(slug, cat, mods)
    lines.append(f"{slug.upper()} — assembled from {', '.join(modules_for(slug, cat, mods))}")
    lines.append("")
    for t in TIERS:
        n = cov["by_tier"].get(t, 0)
        if n:
            lines.append(f"  {t:<16} {n:3} concept(s)")
    lines.append("")
    lines.append(f"  overlay declares      {cov['overlay_variables']:3}")
    lines.append(f"  accounted for         {cov['accounted']:3}")
    if cov["orphans"]:
        lines.append(f"  ORPHANS               {len(cov['orphans']):3}  the decomposition does "
                     f"not claim these:")
        for v in cov["orphans"]:
            lines.append(f"      {v}")
    if cov["duplicates"]:
        lines.append(f"  DUPLICATES            {len(cov['duplicates']):3}  claimed by more than "
                     f"one tier:")
        for v, cs in cov["duplicates"].items():
            lines.append(f"      {v}: {', '.join(str(c) for c in cs)}")
    if cov["phantom"]:
        lines.append(f"  PHANTOM               {len(cov['phantom']):3}  claimed but not in the "
                     f"overlay:")
        for v in cov["phantom"]:
            lines.append(f"      {v}")
    # HOW SPECIFIED THE TEMPLATE ACTUALLY IS, which the variable count alone will not tell you.
    tally = {f: 0 for f in CONCEPT_DETAIL}
    total = 0
    for e in assemble(slug, cat, mods):
        d = detail_completeness(e)
        total += d["_concepts"]
        for f in CONCEPT_DETAIL:
            tally[f] += d[f]
    if total:
        lines.append("")
        lines.append(f"  concept detail, across {total} concept(s):")
        for f in CONCEPT_DETAIL:
            bar = "#" * int(round(20 * tally[f] / total))
            lines.append(f"      {f:<20} {tally[f]:3}/{total:<3} {bar}")
        lines.append("")
        lines.append("  canonical measurement vocabulary (registry_schema.MEASUREMENT):")
        lines.append("      " + ", ".join(_measurement_keys()))
        lines.append("      NONE of these is filled on any concept. A concept with a definition")
        lines.append("      and no window is honestly half-specified; the contract side supplies")
        lines.append("      them, which is what a confirmed reconciliation is FOR.")

    # HOW MUCH OF THE SHAPE AUDIT IS ACTUALLY AN AUDIT. Reporting the one disagreement without
    # this line makes a partial check read as a complete one.
    sa = shape_audit(mods)
    lines.append("")
    lines.append(f"  shape assignments checkable against an inventory master  {sa['checkable']:4}")
    lines.append(f"      of which disagree                                    {len(sa['disagreements']):4}")
    lines.append(f"  shape assignments the inventory gives no master           {sa['unverifiable']:4}"
                 "   NOT VERIFIABLE")

    if not (cov["orphans"] or cov["duplicates"] or cov["phantom"]):
        lines.append("  COMPLETE AND DISJOINT — every overlay variable is claimed exactly once.")
        lines.append("  That is not proof the tiers are right; one module claiming everything")
        lines.append("  would also read clean. It is the precondition for asking whether they are.")
    return "\n".join(lines)


def main(argv=None):
    from rwd_tools.console import use_utf8                                          # noqa: PLC0415
    use_utf8()
    ap = argparse.ArgumentParser(description=__doc__.strip().splitlines()[0])
    ap.add_argument("cancer", nargs="?", help="a slug from the catalogue")
    ap.add_argument("--list", action="store_true", help="the registry and its cancers")
    ap.add_argument("--coverage", action="store_true",
                    help="test the assembly against the existing inventory overlay")
    ap.add_argument("--check", action="store_true",
                    help="GATE: exit non-zero on a broken registry or an overlapping tier")
    a = ap.parse_args(argv)

    cat = catalogue()
    mods, read_problems = load_modules()
    errs = read_problems + registry_errors(cat, mods)

    if a.list or (not a.cancer and not a.check):
        print(report(None, cat, mods))
    elif a.cancer:
        if a.cancer not in cat:
            print(f"{a.cancer}: not in the catalogue ({', '.join(sorted(cat)) or 'empty'})",
                  file=sys.stderr)
            return 2
        if a.coverage:
            print(report(a.cancer, cat, mods))
        else:
            for e in assemble(a.cancer, cat, mods):
                rec = concepts_of(e).get(a.cancer) or {}
                here = ", ".join(realised(e, a.cancer)) or "-"
                print(f"  {str(e.get('module')):<20} {slot_name(e):<34} "
                      f"{str(rec.get('concept') or '-'):<34} {here}")

    if errs:
        print("", file=sys.stderr)
        print(f"REFUSED — {len(errs)} problem(s) with the registry:", file=sys.stderr)
        for e in errs[:20]:
            print(f"  {e}", file=sys.stderr)
        return 1 if a.check else 0
    if a.check:
        print("")
        print("ok — every concept has one tier, every realisation names a real variable")

    # ...AND WHAT IS STILL TO DO, WHICH IS NOT AN ERROR AND MUST NOT BE SILENT. A cancer at
    # `registered` has by definition decomposed nothing, so its overlay variables are its
    # WORKLIST rather than a gate failure — but a worklist nothing prints is a worklist nobody
    # works. This is the single most useful thing the registry can tell a study team: these are
    # the variables your overlay declares that no reusable position claims yet.
    work = registry_work(cat, mods)
    if work:
        total = sum(len(v) for v in work.values())
        print("")
        print(f"{total} variable(s) still to decompose, across {len(work)} cancer(s). "
              f"NOT errors — this is the work:")
        for slug in sorted(work, key=lambda k: (-len(work[k]), k)):
            names = work[slug]
            shown = ", ".join(names[:6]) + (" ..." if len(names) > 6 else "")
            print(f"  {slug:<18} {len(names):>3}  {shown}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
