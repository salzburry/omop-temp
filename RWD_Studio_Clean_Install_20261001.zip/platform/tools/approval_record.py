"""Approvals as ledger events — the ONE recorder for the four approval forms (programme item 5).

An approval that exists only as a YAML file is a form. This seals each of the four —
handoff/RELEASE_APPROVAL.yaml, CONFIGURATION_APPROVAL.yaml, CONTRACT_APPROVAL.yaml and
SEMANTIC_APPROVAL.yaml — as an object in the event ledger, the way decision_record seals an
answer: the form must first STAND under the gate that owns it (the same function the gate runs,
never a shorter copy), its declared fields become the sealed payload, the approver is the actor
(typed, until a registered key attests the event), and the form carries the `object_uuid` back
so the claims composition can prove the relationship. A form edited after sealing is a record
that shed its act: `sealed_errors` names it, and `--record-event` seals the new bytes as a
`revised` event rather than a fresh object.

    python3 platform/tools/approval_record.py --record-event <pack> --form release
    python3 platform/tools/approval_record.py --check
    python3 platform/tools/approval_record.py --trust <pack> --form release
    python3 platform/tools/approval_record.py --public-key <private key file>
    python3 platform/tools/approval_record.py --countersign <pack> --form release --key-id <id> --private-key <file>
"""
import argparse
import datetime as _dt
import glob
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
from rwd_services import workspace_root
ROOT = str(workspace_root(__file__))
from rwd_tools import event_ledger as el                                                   # noqa: E402
from rwd_tools import product_gates as pg                                                  # noqa: E402
from rwd_tools.spec_extract import repo_relative                                      # noqa: E402

# form name -> (pack-relative path, ledger object kind, the declared fields, the actor's role)
FORMS = {
    "release": (pg.RELEASE_APPROVAL, "release_approval", pg.RELEASE_APPROVAL_FIELDS, "releaser"),
    "configuration": (pg.CONFIGURATION_APPROVAL, "configuration_approval", pg.CONFIGURATION_APPROVAL_FIELDS, "DataExpert"),
    "contract": (pg.CONTRACT_APPROVAL, "contract_approval", pg.CONTRACT_APPROVAL_FIELDS, "Science"),
    "semantic": (pg.SEMANTIC_APPROVAL, "semantic_approval", pg.SEMANTIC_APPROVAL_FIELDS, "Science"),
}
FORM_OF_KIND = {v[1]: k for k, v in FORMS.items()}
APPROVER = "approved_by"


def form_path(root, pack, form):
    return os.path.join(root, pack, *FORMS[form][0].split("/"))


def event_payload(form, pack_rel, doc):
    """The COMPLETE approval content as the ledger seals it: which form, which pack, and every
    declared field verbatim (digests included — the bytes the approver saw are the act)."""
    return {"form": form, "pack": pack_rel.replace("\\", "/"),
            **{f: str(doc.get(f) or "") for f in FORMS[form][2]}}


def form_errors(root, pack, form):
    """Why the form does not STAND under the gate that owns it — the gate's own function, at the
    level that demands the form, so a seal never records an approval the gate would refuse."""
    from rwd_tools import source_manifest as sm                                            # noqa: PLC0415
    p = os.path.join(root, pack)
    rel = pack.replace("\\", "/")
    if not os.path.isfile(form_path(root, pack, form)):
        return [f"{rel}: no {FORMS[form][0]} — nothing to record"]
    m = pg.maturity(p)
    if form == "release":
        return [e for e in sm.publish_approval_errors(root, rel, None, None, require_sealed=False)
                if "the runner supplied no value" not in e]
    if form == "configuration":
        return pg.configuration_approval_errors(p, rel, dict(m, configuration="approved"))
    if form == "contract":
        return pg.contract_approval_errors(p, rel, dict(m, contract="approved"))
    return pg.semantic_approval_errors(p, rel)


def _head(root, obj):
    """(newest non-attestation event, [all events]) of an object, or (None, [])."""
    newest, events = None, []
    for _seq, fname in el._event_files(root, obj):
        ev, err = el.read_event(root, obj, fname)
        if not err and isinstance(ev, dict):
            events.append(ev)
            if ev.get("action") != "attested":
                newest = ev
    return newest, events


def sealed_errors(root, pack, form):
    """Why this approval is not a RECORDED act, or []: no object_uuid, a uuid nothing sealed, a
    chain of another kind, a superseded head, or a form edited after it was sealed."""
    rel = pack.replace("\\", "/")
    from rwd_services import finding
    def problem(message, *, transition=False):
        # A transition records reviewed bytes; it cannot fix another object's
        # identity, malformed history or a superseded approval.
        return [finding("release_ledger_required" if transition else "release_ledger_invalid",
                        message, gate=6)] if form == "release" else [message]
    path = form_path(root, pack, form)
    where = f"{rel}/{FORMS[form][0]}"
    if not os.path.isfile(path):
        return problem(f"{where}: absent")
    doc, err = pg.read_yaml(path)
    if err or not isinstance(doc, dict):
        return problem(f"{where}: not readable ({err})")
    obj = str(doc.get("object_uuid") or "")
    remedy = f"python3 platform/tools/approval_record.py --record-event {rel} --form {form}"
    if not obj:
        return problem(f"{where}: not recorded in the ledger — an approval that is only a form is not an act; "
                f"record it: {remedy}", transition=True)
    if not el.UUID4.match(obj):
        return problem(f"{where}: object_uuid {obj!r} is not a uuid4")
    newest, _events = _head(root, obj)
    if newest is None:
        return problem(f"{where}: object_uuid {obj} holds no sealed event — record it: {remedy}", transition=True)
    if str(newest.get("object_kind")) != FORMS[form][1]:
        return problem(f"{where}: {obj} is a {newest.get('object_kind')}, not a {FORMS[form][1]}")
    if str(newest.get("action")) == "superseded":
        return problem(f"{where}: the sealed approval is SUPERSEDED — a superseded approval authorises nothing")
    if str(newest.get("payload_sha256")) != el.payload_digest(event_payload(form, rel, doc)):
        return problem(f"{where}: edited after it was sealed (head {str(newest.get('event_sha256'))[:12]}… sealed "
                f"other bytes) — a form that no longer says what its act said is a record that shed its act; "
                f"re-record the new approval ({remedy}) or restore the form", transition=True)
    return []


def record_event(root, pack, form, now_utc=None):
    """Seal ONE approval form: (event, None) or (None, why). Idempotent on the sealed bytes; a
    changed form on a sealed object appends `revised`; a new form mints the object and writes
    `object_uuid` back into the form (the only line this tool ever adds to a governed file)."""
    rel = pack.replace("\\", "/")
    bad = form_errors(root, pack, form)
    if bad:
        return None, (f"{rel}: the {form} approval does not stand under its gate, and an approval the gate "
                      f"refuses is not an act to record:\n  - " + "\n  - ".join(bad))
    path = form_path(root, pack, form)
    doc, err = pg.read_yaml(path)
    if err or not isinstance(doc, dict):
        return None, f"{rel}: {FORMS[form][0]} is not readable ({err})"
    who = str(doc.get(APPROVER) or "").strip()
    payload = event_payload(form, rel, doc)
    obj = str(doc.get("object_uuid") or "") or None
    prev, action = "", "registered"
    if obj:
        if not el.UUID4.match(obj):
            return None, f"{rel}: object_uuid {obj!r} is not a uuid4"
        newest, _events = _head(root, obj)
        if newest is not None:
            if str(newest.get("object_kind")) != FORMS[form][1]:
                return None, f"{rel}: {obj} is a {newest.get('object_kind')}, not a {FORMS[form][1]}"
            if str(newest.get("payload_sha256")) == el.payload_digest(payload):
                return newest, None                       # already sealed: the act is recorded
            action = "revised"
        try:
            _seq, prev = el.head_of(root, obj)
        except el.LedgerError as e:
            return None, str(e)
    actor = {"subject_id": who, "identity_provider": "typed", "display_name": who,
             "role": FORMS[form][3], "trust_level": "typed"}
    now = now_utc or _dt.datetime.now(_dt.timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
    try:
        event = el.append_event(root, object_uuid=obj, object_kind=FORMS[form][1], action=action,
                                actor=actor, occurred_at=now, payload=payload,
                                expected_previous_event_sha256=prev,
                                idempotency_key=f"approval:{form}:{rel}:{el.payload_digest(payload)[:16]}")
    except el.LedgerError as e:
        return None, str(e)
    if obj is None:
        with open(path, encoding="utf-8") as fh:
            text = fh.read()
        with open(path, "w", encoding="utf-8", newline="\n") as fh:
            fh.write(text + ("" if text.endswith("\n") else "\n") + f"object_uuid: {event['object_uuid']}\n")
    return event, None


def _forms(root, form):
    out = []
    for base in ("products", "fixtures"):
        out += sorted(glob.glob(os.path.join(root, base, "*", "*", "*", *FORMS[form][0].split("/"))))
    return out


def claimed_objects(root, form):
    """{object_uuid: form rel path} for every form of this kind whose content VALIDATES against
    its chain head — a form that merely carries a uuid claims nothing."""
    out = {}
    for f in _forms(root, form):
        doc, err = pg.read_yaml(f)
        if err or not isinstance(doc, dict):
            continue
        obj = str(doc.get("object_uuid") or "")
        if not el.UUID4.match(obj):
            continue
        newest, _events = _head(root, obj)
        if newest is None or str(newest.get("object_kind")) != FORMS[form][1]:
            continue
        pack_rel = repo_relative(os.path.dirname(os.path.dirname(f)), root)
        if str(newest.get("payload_sha256")) == el.payload_digest(event_payload(form, pack_rel, doc)):
            out[obj] = repo_relative(f, root)
    return out


def check(root=None):
    """Every approval form carrying an object_uuid, held to its chain."""
    root = root or ROOT
    out = []
    for form in FORMS:
        for f in _forms(root, form):
            doc, err = pg.read_yaml(f)
            if err or not isinstance(doc, dict) or not str(doc.get("object_uuid") or ""):
                continue
            pack_rel = repo_relative(os.path.dirname(os.path.dirname(f)), root)
            out += sealed_errors(root, pack_rel, form)
    return out


def trust(root, pack, form):
    """The trust the sealed approval has EARNED — `authenticated` only behind a verified
    attestation — or None when it is not sealed."""
    doc, err = pg.read_yaml(form_path(root, pack, form))
    obj = str((doc or {}).get("object_uuid") or "") if not err and isinstance(doc, dict) else ""
    if not el.UUID4.match(obj):
        return None
    return el.trust_of(root, obj)


def attest(root, pack, form, key_id, private_key_bytes, now_utc=None):
    """A person signs the sealed approval's head event with a registered key: (event, None) or
    (None, why). The form must be sealed and stand — nobody signs a form that shed its act."""
    bad = sealed_errors(root, pack, form)
    if bad:
        return None, bad[0]
    doc, _err = pg.read_yaml(form_path(root, pack, form))
    obj = str(doc.get("object_uuid"))
    newest, _events = _head(root, obj)
    now = now_utc or _dt.datetime.now(_dt.timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
    try:
        return el.attest(root, obj, str(newest.get("event_sha256")), key_id, private_key_bytes, now,
                         role=FORMS[form][3]), None
    except el.LedgerError as e:
        return None, str(e)


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    ap.add_argument("--record-event", metavar="PACK")
    ap.add_argument("--countersign", metavar="PACK", help="sign the sealed approval's head event with a registered key")
    ap.add_argument("--trust", metavar="PACK")
    ap.add_argument("--form", choices=sorted(FORMS))
    ap.add_argument("--key-id")
    ap.add_argument("--private-key", metavar="FILE", help="a path OUTSIDE the checkout; never committed")
    ap.add_argument("--public-key", metavar="FILE", help="print the base64 public key a private key file registers")
    ap.add_argument("--check", action="store_true")
    ap.add_argument("--now", help="RFC 3339 UTC instant (tests); default: now")
    ap.add_argument("--root", default=ROOT)
    a = ap.parse_args(argv)
    if a.public_key:
        with open(a.public_key, "rb") as fh:
            print(el.public_key_b64(fh.read()))
        return 0
    if a.check:
        errs = check(a.root)
        for e in errs:
            print(e)
        sealed = sum(len(claimed_objects(a.root, form)) for form in FORMS)
        print(f"{sealed} sealed approval form(s); {len(errs)} approval record problem(s)")
        return 1 if errs else 0
    if (a.record_event or a.countersign or a.trust) and not a.form:
        ap.error("--form is required")
    if a.record_event:
        event, why = record_event(a.root, a.record_event, a.form, a.now)
        if why:
            print(why, file=sys.stderr)
            return 1
        print(f"{a.form} approval of {a.record_event}: {event['action']} as {event['object_kind']} "
              f"{event['object_uuid']} seq {event['seq']} ({event['event_sha256'][:12]}…)")
        return 0
    if a.countersign:
        if not (a.key_id and a.private_key):
            ap.error("--countersign needs --key-id and --private-key")
        with open(a.private_key, "rb") as fh:
            key = fh.read()
        event, why = attest(a.root, a.countersign, a.form, a.key_id, key, a.now)
        if why:
            print(why, file=sys.stderr)
            return 1
        print(f"attested seq {event['seq']} of {event['object_uuid']} with {a.key_id}")
        return 0
    if a.trust:
        t = trust(a.root, a.trust, a.form)
        print(t or "not sealed")
        return 0 if t else 1
    ap.print_help()
    return 2


if __name__ == "__main__":
    from rwd_tools.console import use_utf8
    use_utf8()
    sys.exit(main())
