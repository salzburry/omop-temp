#!/usr/bin/env python3
"""What has another tumour already defined for this concept — and where do two packs disagree?

    python3 platform/tools/concept_reuse.py                 # every pack: shared names, divergences
    python3 platform/tools/concept_reuse.py <pack>          # what this pack could inherit
    python3 platform/tools/concept_reuse.py <pack> --variable <ID>
    python3 platform/tools/concept_reuse.py --json

THE COMPOUNDING QUESTION, AND THE COLLISION QUESTION. Both are about one concept seen from two
packs, and neither is visible anywhere else in this repository:

  * REUSE — tumour nine's specification produces a progression-free-survival row. Prostate and
    mCRC each approved a derivation for the same thing months ago. Nothing today puts those in
    front of the person drafting the ninth, so the ninth is reasoned from scratch and the
    platform does not compound. `knowledge_graph` answers this for DECISIONS; contract records
    are the other half, and this is it.

  * DIVERGENCE — two packs already use one name (`OS`) and derive it differently: censor at last
    activity here, at data cutoff there. That is either ONE concept implemented two ways, which
    is legitimate and should be ruled and recorded, or TWO concepts sharing a name, which is a
    collision that must be renamed before anything pools them. The registry sees the shared name
    and says nothing about the meaning; an adversarial fixture plants exactly this shape because
    it is the one a reader cannot catch — each pack is internally consistent.

EVERY OUTPUT IS A QUESTION. This tool ranks nothing, rules nothing, and marks nothing answered.
Whether two derivations are one concept is DataExpert/Science's call, recorded where those calls live:
`governance/NAMING_RULINGS.yaml` for distinct spellings, registered implementations and sealed
`governance/EQUIVALENCE_RULINGS.yaml` decisions for scientific equivalence, and the pack's decision
register for which derivation a new pack adopts. A tool that decided would be the approval hole the whole design exists to
close, and a tool that inherited silently would be worse — a definition nobody re-read.

INHERITANCE FROM A DRAFT IS INHERITANCE OF A GUESS. Each candidate carries the other pack's
`requirement` status, and an unapproved source is labelled as one. Copying a draft derivation and
believing it settled is how one team's open question becomes another team's fact.

stdlib + the repo's own readers. No Spark. AI drafts from this; a person rules.
"""
from __future__ import annotations

import argparse
import glob
import hashlib
import json
import os
import re
import sys

TOOLS = os.path.dirname(os.path.abspath(__file__))
PLATFORM = os.path.dirname(TOOLS)
from rwd_services import workspace_root
ROOT = str(workspace_root(__file__))

from rwd_tools import contract_lint as cl # noqa: E402
from rwd_tools import naming_registry as nr # noqa: E402
from rwd_tools import precedent_metric as pm # noqa: E402
from rwd_tools import rule_review # noqa: E402
from rwd_tools.spec_extract import repo_relative # noqa: E402

# Words that carry no concept. Two derivations sharing only these share nothing — without the
# stop list, every date rule on earth "overlaps" through `the`, `of`, `date` and `index`.
_STOP = {"the", "a", "an", "of", "to", "from", "in", "on", "at", "for", "and", "or", "is", "as",
         "by", "with", "per", "if", "then", "else", "not", "no", "any", "all", "each", "this",
         "that", "value", "values", "date", "dates", "column", "field", "row", "rows", "patient",
         "patients", "use", "used", "using", "set", "based", "where", "when", "first", "last"}
# The same floor `precedent_metric` uses, for the same reason: a candidate is a question, and a
# question that fires on every pair teaches people to ignore the whole surface.
_MIN_OVERLAP = 0.4


def _overlap(a, b):
    """Jaccard over content words — arithmetic a reviewer can recheck, never a probability.

    The MECHANISM is `precedent_metric`'s, so the two surfaces that report closeness cannot come
    to different numbers for one pair; only the stop list differs, because a derivation and a
    decision question are not made of the same filler.
    """
    return pm.jaccard(pm.tokens(a, _STOP), pm.tokens(b, _STOP))


_NUM = re.compile(r"\d+(?:\.\d+)?")


def _constants(text):
    """Numeric literals for retrieval hints. Shared numbers do not establish shared rules."""
    return {n for n in _NUM.findall(str(text or "")) if len(n) > 1 or "." in n}


def _agrees(a, b):
    """Legacy retrieval score: (wording/numbers look similar, why), never equivalence.

    Scientific naming review uses physical_name_reviews and exact canonical cells.
    Similar 30-day and 90-day sentences can share this score and still need review.
    """
    w = _overlap(a, b)
    if w >= _MIN_OVERLAP:
        return True, f"wording overlap {w:.2f}"
    ca, cb = _constants(a), _constants(b)
    if ca and ca == cb:
        return True, f"wording overlap {w:.2f} but identical constants {sorted(ca)}"
    return False, f"wording overlap {w:.2f}"


def _status(entry):
    return cl.requirement(entry["status"]) or "(unstated)"


def _scientific_fields(record):
    """Compare the canonical scientific cells, never a lexical similarity score."""
    return {key: " ".join(str(record.cells.get(key) or "").split())
            for key in sorted(cl.REQUIREMENT_FIELDS)}


def _physical_names(record):
    value = str(record.output.get("physical_name") or "").strip().strip("\"'").lower()
    if value in {"", "n/a", "none", "tbd", "todo"}:
        return set()
    return {name for name in record.physical_names() if re.fullmatch(r"[a-z][a-z0-9_]*", name)}


def _local_naming_path(root, path):
    base, path = os.path.abspath(root), os.path.abspath(path)
    if (os.path.commonpath([base, path]) != base
            or os.path.normcase(os.path.realpath(path)) != os.path.normcase(path)):
        raise ValueError("A naming input redirects to another location. Repair its local path before reviewing names.")
    return path


def _review_inputs_local(root, pack):
    """Bound indirect canonical readers to this pack's review/configuration metadata."""
    from rwd_tools import product_gates as gates  # noqa: PLC0415
    product = os.path.join(root, pack)
    paths = {"handoff/FUNCTIONAL_CONTRACT.md", "config/data_product.yaml", "config/implementations.yaml"}
    for (axis, _level), required in gates.MATURITY_REQUIRES.items():
        if axis == "contract":
            paths.update(required)
    for relative in paths:
        _local_naming_path(root, os.path.join(product, relative))
    variables = _local_naming_path(root, os.path.join(product, "variables"))
    for path in glob.glob(os.path.join(variables, "*.yaml")):
        _local_naming_path(root, path)
    _local_naming_path(root, os.path.join(root, "governance", "DEFINITIONS.yaml"))


def _reviewed_implementation(root, pack, record, saved):
    """Resolve an existing reviewed mapping to the configuration's actual signature.

    A draft preview cannot borrow the review of different scientific cells. No
    approval of the configuration is required here: that is the gate consuming
    this result, so requiring it would make a circular approval dependency.
    """
    from rwd_tools import definition_registry as definitions  # noqa: PLC0415
    from rwd_tools import product_gates as gates  # noqa: PLC0415
    if (saved is None or saved.requirement() != "approved"
            or record.requirement() != "approved"
            or any(record.cells.get(k) != saved.cells.get(k) for k in cl.REQUIREMENT_FIELDS)
            or record.physical_names() != saved.physical_names()):
        return None
    product = os.path.join(root, pack)
    _review_inputs_local(root, pack)
    maturity = {"contract": "approved"}
    if (gates.required_evidence_errors(product, pack, maturity, axis="contract")
            or gates.contract_approval_errors(product, pack, maturity)):
        return None
    if definitions.register_errors(root) or definitions.implementation_errors(pack, root):
        return None
    doc, problems = definitions.implementations(pack, root)
    if problems:
        return None
    matches = [item for item in doc.get("implements", [])
               if item.get("variable") == record.variable_id]
    if len(matches) != 1 or not doc.get("dataset"):
        return None
    did = str(matches[0].get("definition") or "")
    parts = did.split(":")
    if len(parts) != 3 or definitions.resolve(pack, root).get(parts[1]) != did:
        return None  # absent/unregistered signatures never substantiate a claim
    return {"definition_id": did, "dataset": str(doc["dataset"]).strip().lower()}


def _definition_equivalence(root, name, left, right, pack_scope):
    """Reuse the sealed equivalence path, including same-vendor definition pairs."""
    if left["definition_id"] == right["definition_id"]:
        return {"basis": "same registered implementation", "definition_ids": [left["definition_id"]]}
    from rwd_tools import semantic_view as semantic  # noqa: PLC0415
    from rwd_tools import event_ledger as ledger  # noqa: PLC0415
    path = os.path.join(root, "governance", "EQUIVALENCE_RULINGS.yaml")
    _local_naming_path(root, path)
    if not os.path.isfile(path):
        return None
    _local_naming_path(root, os.path.join(root, ledger.CHECKPOINTS))
    registers = ([os.path.join(root, p, "handoff", "DECISIONS.md") for p in pack_scope]
                 if pack_scope is not None else
                 [path for base in ("products", "fixtures") for path in
                  glob.glob(os.path.join(root, base, "*", "*", "*", "handoff", "DECISIONS.md"))])
    for register in registers:
        _local_naming_path(root, register)
    # Validate redirection before semantic_view follows any permitted ruling's
    # event reference; do not walk patient data or whole product directories.
    doc, error = semantic.pg.read_yaml(path)
    if error:
        return None
    for ruling in (doc or {}).get("rulings", []) or []:
        if pack_scope is not None and ruling.get("decision_pack") not in pack_scope:
            continue
        object_id = str(ruling.get("decision_object_uuid") or "")
        if not ledger.UUID4.fullmatch(object_id):
            continue
        directory = _local_naming_path(root, os.path.join(root, ledger.EVENTS_DIR, object_id))
        for event_path in glob.glob(os.path.join(directory, "*.yaml")):
            _local_naming_path(root, event_path)
    ruled, _problems = semantic.rulings(path, root=root, pack_scope=pack_scope)
    wanted = {left["definition_id"], right["definition_id"]}
    sources = {left["dataset"], right["dataset"]}
    for ruling in ruled:
        if (ruling.get("ruling") != "same_construct"
                or str(ruling.get("variable") or "").lower() != name
                or {str(ruling.get("source_a") or "").lower(),
                    str(ruling.get("source_b") or "").lower()} != sources
                or {ruling.get("definition_a"), ruling.get("definition_b")} != wanted):
            continue
        checkpoint = ledger._checkpoints(root).get("heads", {}).get(ruling["decision_object_uuid"])
        if ledger._check_object(root, ruling["decision_object_uuid"], checkpoint):
            continue
        # Legacy accepted rulings may add definition IDs beside an older event
        # that named none. That event did not compare this pair of definitions.
        for _seq, filename in ledger._event_files(root, ruling["decision_object_uuid"]):
            event, error = ledger.read_event(root, ruling["decision_object_uuid"], filename)
            if error or event.get("event_sha256") != ruling["decision_event_sha256"]:
                continue
            equivalence = (event.get("payload") or {}).get("equivalence") or {}
            if {equivalence.get("definition_a"), equivalence.get("definition_b")} == wanted:
                return {"basis": "recorded same_construct decision", "definition_ids": sorted(wanted),
                        "decision_id": ruling["decision_id"],
                        "decision_event_sha256": ruling["decision_event_sha256"]}
    return None


def physical_name_reviews(pack, root=ROOT, *, contract_text=None, pack_scope=None):
    """Scientific differences behind the same physical name, within permitted packs.

    Returns one local/peer record pair per differing name. ``review_required``
    remains a question; ``resolved`` cites current registered implementations
    and, when needed, the existing sealed equivalence decision. Identical cells
    produce no difference finding and make no claim of clinical equivalence.
    Pass ``contract_text`` for a row-preview's complete proposed contract.
    ``pack_scope`` filters peers BEFORE their contracts or reviews are read.
    """
    pack = repo_relative(os.path.join(root, pack), root)
    scope = None if pack_scope is None else {str(p).replace("\\", "/").strip("/") for p in pack_scope}
    if scope is not None and pack not in scope:
        raise ValueError("The current product is outside the naming review scope.")
    packs = [p for _slug, p in _packs(root, scope)]
    if pack not in packs:
        packs.append(pack)
    by_pack, saved_by_pack = {}, {}
    for candidate in sorted(packs):
        path = os.path.join(root, candidate, "handoff", "FUNCTIONAL_CONTRACT.md")
        _local_naming_path(root, path)
        saved = list(cl.typed_records(cl.read(path))) if os.path.isfile(path) else []
        saved_by_pack[candidate] = saved
        by_pack[candidate] = (list(cl.typed_records(contract_text))
                              if candidate == pack and contract_text is not None else saved)
    cache = {}

    def implementation(owner, record):
        key = (owner, record.variable_id, record.raw)
        if key not in cache:
            saved = [r for r in saved_by_pack[owner] if r.variable_id == record.variable_id]
            try:
                cache[key] = _reviewed_implementation(root, owner, record, saved[0] if len(saved) == 1 else None)
            except (OSError, ValueError, TypeError, KeyError, AttributeError, RecursionError):
                cache[key] = None  # damaged evidence cannot clear a scientific question
        return cache[key]

    reviews = []
    for mine in by_pack[pack]:
        fields = _scientific_fields(mine)
        for other, records in by_pack.items():
            if other == pack:
                continue
            for peer in records:
                names = sorted(_physical_names(mine) & _physical_names(peer))
                if not names:
                    continue
                prior = _scientific_fields(peer)
                differing = [key for key in fields if fields[key] != prior[key]]
                if not differing:
                    continue
                left, right = implementation(pack, mine), implementation(other, peer)
                for name in names:
                    resolution = None
                    if left and right:
                        try:
                            resolution = _definition_equivalence(root, name, left, right, scope)
                        except (OSError, ValueError, TypeError, KeyError, AttributeError, RecursionError):
                            pass
                    question = (f"`{name}` has different scientific fields ({', '.join(differing)}) in another current product. "
                                "Review whether the definitions represent the same construct. Keep the naming choice undecided "
                                "while drafting; use distinct output names for different constructs, or record reviewed registered "
                                "implementations and an exact-definition equivalence decision before configuration approval. "
                                "Matching wording, constants or an aligned naming label do not settle this question.")
                    basis = json.dumps({"local": mine.raw, "peer": peer.raw, "resolution": resolution},
                                       sort_keys=True, ensure_ascii=False)
                    reviews.append({"physical_name": name, "variable_id": mine.variable_id,
                                    "state": "resolved" if resolution else "review_required",
                                    "resolved": bool(resolution), "differing_fields": differing,
                                    "question": question, "resolution": resolution,
                                    "basis_sha256": hashlib.sha256(basis.encode("utf-8")).hexdigest(),
                                    "peer": {"pack": other, "variable_id": peer.variable_id},
                                    "differences": [{"field": key, "current": fields[key], "peer": prior[key]}
                                                    for key in differing]})
    return reviews


def physical_name_errors(pack, root=ROOT):
    """Gate-facing wording reveals only local output names and scientific fields."""
    return sorted({f"{pack}: unresolved scientific naming review: {item['question']}"
                   for item in physical_name_reviews(pack, root) if not item["resolved"]})


def _records(root=ROOT):
    """{pack: {variable_id: entry}} over every versioned pack that carries a contract."""
    out = {}
    for _slug, pack in _packs(root):
        entries = rule_review.chain(os.path.join(root, pack))
        if entries:
            out[pack] = {e["variable_id"]: e for e in entries}
    return out


def _packs(root=ROOT, pack_scope=None):
    """One pack per slug: the REGISTERED CURRENT version, products shadowing fixtures.

    The walk used to take every historical version from both roots, so an obsolete fixture
    definition could read as a settled concept — the same precedence
    semantic export already applies, applied here."""
    import glob # noqa: PLC0415
    from rwd_tools import product_gates as _pg # noqa: PLC0415
    current = {}
    for base in ("products", "fixtures"):
        _local_naming_path(root, os.path.join(root, base, "registry.yaml"))
        reg, err = _pg.read_yaml(os.path.join(root, base, "registry.yaml"))
        if not err:
            for t_ in (reg or {}).get("tumors") or []:
                if isinstance(t_, dict) and t_.get("slug"):
                    current.setdefault(str(t_["slug"]),
                                       str(t_.get("current_spec_version") or ""))
    found, seen = [], set()
    for base in ("products", "fixtures"):
        candidates = (glob.glob(os.path.join(root, base, "*", "*", "*", "handoff", "FUNCTIONAL_CONTRACT.md"))
                      if pack_scope is None else
                      [os.path.join(root, pack, "handoff", "FUNCTIONAL_CONTRACT.md") for pack in pack_scope
                       if re.fullmatch(base + r"/[A-Za-z0-9_-]+/[A-Za-z0-9_-]+/[A-Za-z0-9_-]+", pack)
                       and os.path.isfile(os.path.join(root, pack, "handoff", "FUNCTIONAL_CONTRACT.md"))])
        for p in sorted(candidates):
            pack = repo_relative(os.path.dirname(os.path.dirname(p)), root)
            parts = pack.split("/")
            slug, version = parts[2], parts[3]
            if slug in seen:
                continue # products shadow fixtures
            want = current.get(slug, "")
            if want and version != want:
                continue # only the registered current version
            found.append((slug, pack))
            seen.add(slug)
    return found


def shared_names(by_pack):
    """Concepts two or more packs both name — with whether their derivations agree.

    Agreement is measured, not asserted: the overlap is printed so a reader can disagree with the
    threshold. What the tool never does is call a divergence right or wrong.
    """
    where = {}
    for pack, entries in by_pack.items():
        for vid, e in entries.items():
            where.setdefault(vid, {})[pack] = e
    out = []
    for vid, packs in sorted(where.items()):
        if len(packs) < 2:
            continue
        items = sorted(packs.items())
        pairs = [(a, b) for i, a in enumerate(items) for b in items[i + 1:]]
        verdicts = [_agrees(a[1]["derivation"], b[1]["derivation"]) for a, b in pairs]
        divergent = any(not ok for ok, _why in verdicts)
        worst = min((_overlap(a[1]["derivation"], b[1]["derivation"]) for a, b in pairs),
                    default=1.0)
        out.append({
            "variable_id": vid,
            "packs": [p for p, _e in items],
            "derivations": {p: (e["derivation"] or "").strip()[:300] for p, e in items},
            "statuses": {p: _status(e) for p, e in items},
            "lowest_overlap": round(worst, 2),
            "evidence": [why for _ok, why in verdicts],
            "divergent": divergent,
            "question": (
                f"`{vid}` is defined in {len(items)} packs and their derivations share little "
                f"wording (overlap {worst:.2f}) and no common constants. Is this ONE concept "
                f"implemented differently per tumour — record the ruling and the reason — or TWO "
                f"concepts sharing a name, which must be renamed before anything reads them as one?"
                if divergent else
                f"`{vid}` is defined in {len(items)} packs and the wording does not disagree "
                f"({verdicts[0][1]}) — but matching words are not a shared meaning. Are these "
                f"one concept? Confirming it is what lets a later pack inherit rather than "
                f"re-reason it.")})
    return out


def inheritable(pack, by_pack, variable=None):
    """For each of this pack's records, what OTHER packs already approved for the same concept.

    Two ways a prior record is a candidate: the same variable_id, or a name the registry's own
    near-miss grammar relates (`agegrp` ~ `age_group`). Wording similarity is reported for both,
    and decides neither — a concept can be written two ways and still be one concept, which is
    exactly the judgment this tool refuses to make.
    """
    mine = by_pack.get(pack) or {}
    out = []
    for vid, e in sorted(mine.items()):
        if variable and vid != variable:
            continue
        cands = []
        for other, entries in sorted(by_pack.items()):
            if other == pack:
                continue
            for ovid, oe in sorted(entries.items()):
                same = ovid.lower() == vid.lower()
                near = (not same) and nr._near(ovid.lower(), vid.lower())
                if not (same or near):
                    continue
                st = _status(oe)
                cands.append({
                    "pack": other, "variable_id": ovid,
                    "match": "same name" if same else "near-miss name",
                    "status": st,
                    "settled": st == "approved",
                    "derivation": (oe["derivation"] or "").strip()[:300],
                    "spec_refs": oe["spec"]["refs"] or [],
                    "decisions": oe["decisions"] or [],
                    "wording_overlap": round(_overlap(e["derivation"], oe["derivation"]), 2),
                    "caveat": None if st == "approved" else
                              f"the source record is `{st}`, not approved — inheriting it "
                              f"inherits an open question, not a settled definition",
                })
        if cands:
            out.append({
                "variable_id": vid, "status": _status(e),
                "derivation": (e["derivation"] or "").strip()[:300],
                "candidates": cands,
                "question": f"{len(cands)} other pack record(s) define `{vid}` or a near-miss of "
                            f"it. Inherit one, adapt it, or diverge — and record which, with the "
                            f"reason, in this pack's decision register."})
    return out


def report(pack=None, variable=None, root=ROOT):
    by_pack = _records(root)
    out = {"packs": sorted(by_pack), "records": {p: len(v) for p, v in sorted(by_pack.items())}}
    if pack:
        rel = repo_relative(os.path.join(root, pack), root) if not pack.startswith("products") \
            else pack
        if rel not in by_pack:
            raise KeyError(f"{rel}: no contract records — nothing to inherit into "
                           f"({len(by_pack)} pack(s) carry contracts: {sorted(by_pack)})")
        out["pack"] = rel
        # A NAME THIS PACK DOES NOT DECLARE IS REFUSED, not filtered to nothing. Without this the
        # tool answered a question about `NOPE` by silently narrowing to an empty set and then
        # printing a confident cross-pack conclusion - "every concept here is new to the
        # platform" - as though the question had been asked and answered. This tool exists to say
        # whether a prior pack already defined something, so a typo or a stale name getting back
        # an authoritative "no" is precisely the wrong answer. `receipt.py` and `rule_review.py`
        # both refuse the same input on the same contract; this was the outlier.
        if variable and variable not in by_pack[rel]:
            known = sorted(by_pack[rel])
            raise KeyError(f"`{variable}` is not a variable_id in {rel}'s contract "
                           f"({len(known)} record(s): {', '.join(known)})")
        out["inheritable"] = inheritable(rel, by_pack, variable)
    else:
        shared = shared_names(by_pack)
        out["shared"] = shared
        out["divergent"] = [s for s in shared if s["divergent"]]
    return out


def render(r):
    if "inheritable" in r:
        L = [f"CONCEPT REUSE — {r['pack']}",
             f"{len(r['inheritable'])} record(s) another pack has already defined", ""]
        for item in r["inheritable"]:
            L.append(f"{item['variable_id']}  [{item['status']}]")
            for c in item["candidates"]:
                mark = "approved" if c["settled"] else f"NOT SETTLED ({c['status']})"
                L.append(f"      {c['pack']} · {c['variable_id']} · {c['match']} · {mark} · "
                         f"wording {c['wording_overlap']}")
                if c["derivation"]:
                    L.append(f"        {c['derivation'][:160]}")
                if c["caveat"]:
                    L.append(f"        ! {c['caveat']}")
            L.append(f"      ? {item['question']}")
            L.append("")
        if not r["inheritable"]:
            L.append("  Nothing another pack defines matches this pack's records — every "
                     "concept here is new to the platform, which is itself worth knowing.")
        L.append("Inherit, adapt or diverge is a person's call, recorded in the decision "
                 "register. This tool asks; it never answers.")
        return "\n".join(L)

    L = [f"CONCEPT REUSE — {len(r['packs'])} pack(s), "
         f"{sum(r['records'].values())} contract record(s)",
         f"{len(r['shared'])} concept name(s) shared across packs, "
         f"{len(r['divergent'])} with different wording or constants", ""]
    for s in r["shared"]:
        head = "different wording" if s["divergent"] else "similar wording"
        L.append(f"{s['variable_id']:<22} {head:<11} overlap {s['lowest_overlap']:<5} "
                 f"{', '.join(p.split('/')[2] for p in s['packs'])}")
        if s["divergent"]:
            for p, d in sorted(s["derivations"].items()):
                L.append(f"      {p.split('/')[2]:<12} {d[:120]}")
            L.append(f"      ? {s['question']}")
    L += ["", "A shared name is not a shared concept, and a divergence is not a defect — both "
              "are QUESTIONS for DataExpert/Science. Distinct spellings are ruled in governance/NAMING_RULINGS.yaml; "
              "same-name scientific differences need reviewed registered implementations and exact-definition equivalence evidence."]
    return "\n".join(L)


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__.strip().splitlines()[0])
    ap.add_argument("product", nargs="?", help="a pack; omitted, reports across every pack")
    ap.add_argument("--variable", help="one variable_id in that pack")
    ap.add_argument("--json", action="store_true", help="machine-readable, to STDOUT")
    a = ap.parse_args(argv)
    pack = None
    if a.product:
        # `os.path.relpath` RETURNS BACKSLASHES ON WINDOWS, and every pack id this tool compares
        # against is written with forward slashes — so the id built here could never match one
        # of them, and the tool reported nothing for a pack that exists. `repo_relative` is the
        # repository's one answer to this question; it also does not raise when the path is on
        # another drive, which `relpath` does.
        from rwd_tools import spec_extract # noqa: PLC0415
        pack = spec_extract.repo_relative(os.path.abspath(a.product), ROOT)
        if not os.path.isdir(os.path.join(ROOT, *pack.split("/"))):
            sys.exit(f"{a.product}: not a product pack directory")
    try:
        r = report(pack, a.variable)
    except KeyError as e:
        sys.exit(str(e).strip('"'))
    print(json.dumps(r, indent=1, sort_keys=True) if a.json else render(r))
    return 0


if __name__ == "__main__":
    from rwd_tools.console import use_utf8
    use_utf8()
    sys.exit(main())
