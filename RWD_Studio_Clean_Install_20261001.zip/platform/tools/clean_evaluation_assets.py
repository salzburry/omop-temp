"""Explicit evaluation assets for a clean install, without reference-product history."""
PREFIX = "experiments/agent/evals/"
RETAIN = frozenset(PREFIX + name for name in (
    "run.py", "history.py", "cases_conversations.yaml", "critic_cases.yaml", "ADJUDICATION.md"))
POLICY = "Clean installation: no inherited reference-product cases or evaluation results. Register destination cases with their actual source context; do not rewrite prior evidence to another product."


def initial_documents():
    """Keep known runnable synthetic corpora; initialize product-bound lists empty."""
    return {"experiments/agent/knowledge/lessons.yaml": [], **{PREFIX + name: [] for name in ("cases.yaml", "cases_generated.yaml",
        "specialist_cases.yaml", "cases_science_regressions.yaml")},
        PREFIX + "science_regression_split.json": {"schema_version": 1, "policy": POLICY,
                                                    "development": [], "heldout": []},
        PREFIX + "INSTALLATION_CORPUS.yaml": {"version": 1, "policy": POLICY,
            "inherited_product_cases": False, "inherited_evaluation_results": False,
            "retained_assets": ["cases_conversations.yaml", "critic_cases.yaml"],
            "notice": "Retained authored synthetic inputs are not clinical facts, approved algorithms or measured results."}}
