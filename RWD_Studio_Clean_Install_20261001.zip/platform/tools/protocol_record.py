#!/usr/bin/env python3
"""Manage protocol records: an analysis plan, frozen before the analysis runs.

    python platform/tools/protocol_record.py --new prot-2026-001     # scaffold
    python platform/tools/protocol_record.py --digest prot-2026-001  # the freeze digest
    python platform/tools/protocol_record.py --check                 # lint every protocol

A protocol answers one question: was this analysis specified before the results were seen?

How the freeze works:
  * `prespecified:` holds the plan that must not move: objectives, design, population,
    endpoints, analyses, and the scope (which releases the plan reads). Every section
    must be stated before the record can register.
  * At registration a person records `prespecification_sha256` over the WHOLE
    `prespecified:` subtree — every key it holds, named or not, so a section added
    later cannot hide outside the freeze. `--check` recomputes it; a mismatch refuses.
  * A registered protocol may change only through an AMENDMENT: a person
    (`amended_by`), a date, what changed, and the new digest it covers. Changes are
    visible, never silent, and the newest amendment must cover the plan as it now
    stands.

The digest covers the canonical form (sorted keys, normalised text), so reflowing a
paragraph is not an amendment and changing an endpoint is.

A protocol owes two gates: `contract` (this record) and `provenance` (the releases it
reads, cited on its registry entry). Work executed under it may not read a release the
protocol never named.

Human fields (`registered_by`, dates, any status past `draft`) are typed by a person.
`--new` writes placeholder markers; `--check` refuses a registered record still carrying
one.
"""
from __future__ import annotations

import argparse
import contextlib
import hashlib
import json
import os
from pathlib import Path
import re
import sys
import tempfile

TOOLS = os.path.dirname(os.path.abspath(__file__))
from rwd_services import workspace_root
REPO = str(workspace_root(__file__))

from rwd_tools import product_gates as pg # noqa: E402
from rwd_tools import request_record as rr # noqa: E402
from rwd_tools import source_manifest as sm # noqa: E402
from rwd_tools.spec_extract import repo_relative # noqa: E402

RECORD = "PROTOCOL.yaml"
MARK = "REPLACE_ME"
STATUSES = ("draft", "registered", "amended", "closed")
FROZEN = ("registered", "amended", "closed") # the states a freeze digest must hold in
HUMAN_FIELDS = ("registered_by", "registered_date")
# The sections a frozen plan must STATE. The digest is wider: it covers every key under
# `prespecified:` whether named here or not, so an extra section (a subgroup list, a sensitivity
# analysis) is inside the freeze the moment it exists — it can be added only by amendment, and it
# can never sit beside a signed plan unsigned.
PRESPECIFIED = ("objectives", "design", "population", "endpoints", "analyses")
# The releases the plan reads, stated INSIDE the freeze. The registry's `cites_release` is the
# operational scope; this is the signed one, and `--check` requires them to agree — so re-pointing
# a protocol at different data is an amendment, never a registry edit.
SCOPE_KEY = "scope"


def draft_product(root, product):
    """Validate planning context; this never asserts a release or creates a study pin."""
    if not isinstance(product, str) or not re.fullmatch(r"products/[A-Za-z0-9_-]+/[A-Za-z0-9_-]+/\d{6}", product):
        raise ValueError("Choose a registered product pack for the study draft.")
    base = Path(root).resolve()
    path = base / product
    if path.resolve() != path or not (path / "config/data_product.yaml").is_file():
        raise ValueError("The draft product is unavailable or redirects to another location.")
    entry = pg.registry_entry(str(base), product)
    if not entry or pg.pack_role(entry) != ("product", None):
        raise ValueError("A study draft needs a registered product, never a reference fixture.")
    return product


def _draft_path(root, study):
    ok, error = pg.safe_work_id(study)
    if not ok:
        raise ValueError(error)
    path = Path(root).resolve() / rr.WORK / study / RECORD
    if path.resolve() != path:
        raise ValueError("The study record redirects to another location.")
    return path


def draft_association(root, study, product):
    """Preview an explicit association for an existing, still-unbound draft only."""
    product = draft_product(root, product)
    path = _draft_path(root, study)
    if not path.is_file() or path.stat().st_size > 4 * 1024 * 1024:
        raise ValueError("Choose an existing study draft within the 4 MB editor limit.")
    raw = path.read_bytes()
    doc, error = pg.read_yaml(str(path))
    if error or not isinstance(doc, dict) or doc.get("protocol_id") != study or doc.get("status") != "draft":
        raise ValueError("Only an identified draft protocol can acquire planning context.")
    if "draft_product" in doc or path.with_name("PINS.yaml").exists():
        raise ValueError("This study already has product context or pins; its association cannot be overwritten.")
    entry = next((w for w in pg.work_entries(root) if w.get("id") == study), {})
    pre = doc.get("prespecified")
    scope = pre.get("scope", []) if isinstance(pre, dict) else None
    placeholder = {"product": MARK, "spec_version": MARK}
    if entry.get("cites_release") or not isinstance(scope, list) or any(row != placeholder for row in scope):
        raise ValueError("This study already declares product scope; use its existing scope instead of attaching it elsewhere.")
    before = raw.decode("utf-8")
    newline = "\r\n" if "\r\n" in before else "\n"
    after = before + ("" if before.endswith("\n") else newline) + (
        "# Planning context only; no released product or study pin is claimed." + newline
        + "draft_product: " + product + newline)
    import yaml  # noqa: PLC0415
    if yaml.safe_load(after) != {**doc, "draft_product": product}:
        raise ValueError("The study's YAML structure cannot be preserved.")
    return {"study": study, "product": product, "before": before, "after": after,
            "sha256": hashlib.sha256(raw).hexdigest()}


@contextlib.contextmanager
def _draft_writer(path):
    """Share the portal protocol lock; publish complete bytes, never overwrite another creation."""
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.resolve() != path:
        raise ValueError("The study record redirects to another location.")
    lock = path.with_name(".portal-protocol.lock")
    try:
        fd = os.open(lock, os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o600)
    except FileExistsError:
        raise ValueError("Another protocol save is in progress. Retry after it finishes.") from None
    os.close(fd)
    try:
        yield
    finally:
        lock.unlink()


def _publish_draft(path, raw, *, previous=None):
    fd, pending = tempfile.mkstemp(prefix=".protocol-", suffix=".tmp", dir=path.parent)
    try:
        with os.fdopen(fd, "wb") as stream:
            stream.write(raw)
            stream.flush()
            os.fsync(stream.fileno())
        if previous is None:
            os.link(pending, path)
        else:
            if path.read_bytes() != previous:
                raise ValueError("The study draft changed. Preview the association again.")
            os.replace(pending, path)
    finally:
        Path(pending).unlink(missing_ok=True)

TEMPLATE = f"""\
# A PROTOCOL — the plan, frozen before the analysis. It owes `contract` (this record) and
# `provenance` (the releases it reads, on its registry entry). See governance/WORKFLOW.md.
#
# Everything under `prespecified:` is covered by `prespecification_sha256`. Once this protocol is
# registered, changing any of it requires an AMENDMENT — a date, a person, what changed and why.
# That is not friction for its own sake: an endpoint swapped after the fact is invisible in the
# finished document, and this is the only place it can be made visible.
#
# Every {MARK} is a person's to fill. `--check` refuses a registered protocol still carrying one.
protocol_id: {{pid}}
title: "{MARK}"

status: draft                   # draft -> registered -> amended -> closed; only `draft` is a tool's
registered_by: {MARK}           # a NAMED person, not a team
registered_date: {MARK}         # YYYY-MM-DD

# Recorded at registration: `--digest {{pid}}` prints it. It covers EVERY key under `prespecified:`
# below — the named sections and anything added beside them — so an edit to the title or a note is
# not an amendment, and an edit to any part of the plan is.
#
# `registration_digest` is the plan AS REGISTERED and never moves; `prespecification_sha256` is the
# plan AS IT NOW STANDS and moves only by amendment. With no amendments the two are equal, and every
# amendment must chain from one toward the other (previous_digest -> covers_digest).
registration_digest: {MARK}
prespecification_sha256: {MARK}

prespecified:
  objectives:
    - {MARK}
  design: >
    {MARK}
  population: >
    {MARK}
  endpoints:
    primary:
      - {MARK}
    secondary: []
  analyses:
    - {MARK}
  # The releases this plan reads, inside the freeze. Must agree with the registry entry's
  # `cites_release` — one mapping per citation, same product and spec_version. Empty ([]) only
  # for a plan that reads no governed release.
  scope:
    - product: {MARK}
      spec_version: {MARK}

# Append one entry per amendment. `previous_digest` is the digest BEFORE the change and
# `covers_digest` the digest after — the chain must run registration_digest -> ... -> the digest
# `prespecified:` now hashes to, each link consuming the last.
amendments: []
# - date: YYYY-MM-DD
#   amended_by: "a NAMED person"
#   what_changed: "the secondary endpoint list"
#   why: "…"
#   previous_digest: "…"
#   covers_digest: "…"

# Set by a person when the study ends. A closed protocol accepts no new work.
# closed_by: "a NAMED person"
# closed_date: YYYY-MM-DD
"""


def record_path(pid, root=None):
    return os.path.join(root or REPO, rr.WORK, str(pid), RECORD)


def _protocols(root):
    return [w for w in pg.work_entries(root) if str(w.get("kind") or "") == "protocol"]


def _canonical(node):
    """The comparable form of a pre-specified value.

    Digesting the FILE would make a reflowed paragraph or two swapped keys read as an amendment, and
    a record that cries amendment over whitespace teaches people to re-stamp the digest without
    reading — which is exactly the habit the freeze exists to prevent. So: mappings sorted, scalars
    stringified and whitespace-collapsed, lists left in order because the order of endpoints is part
    of what was specified.
    """
    if isinstance(node, dict):
        return {str(k): _canonical(node[k]) for k in sorted(node, key=str)}
    if isinstance(node, (list, tuple)):
        return [_canonical(v) for v in node]
    return " ".join(str(node).split())


def prespecification_digest(doc):
    """sha256 over the WHOLE `prespecified:` subtree in canonical form, or None when absent.

    Every key the subtree holds is digested, and every key in PRESPECIFIED is folded in BY NAME
    even when missing — so a protocol that drops an endpoint list cannot hash equal to one that
    never had it, and a section ADDED beside the named ones (a subgroup list, say) moves the
    digest the moment it appears. A digest over a fixed key list let anything outside the list
    change under an apparently unchanged signed plan.
    """
    pre = (doc or {}).get("prespecified")
    if not isinstance(pre, dict):
        return None
    keys = sorted(set(map(str, pre)) | set(PRESPECIFIED))
    payload = {k: _canonical(pre.get(k)) for k in keys}
    blob = json.dumps(payload, sort_keys=True, ensure_ascii=False, separators=(",", ":"))
    return hashlib.sha256(blob.encode("utf-8")).hexdigest()


def _first_committed_registration_digest(root, rel):
    """The first registration_digest git ever recorded for `rel`, or None.

    THE ANCHOR OUTSIDE THE FILE: editing the plan and recomputing BOTH
    digests in one motion kept the record internally consistent, because every value the
    validator compared lived in the same mutable file. The registration is the one act that
    never re-happens, so its digest's FIRST committed value is its only value — recovered
    from history the same way the run validator recovers a record's first-added bytes.
    None when the file has no committed history (a new protocol not yet committed, or no
    git): unanchored, not violated — the in-file chain still holds, and committing is what
    creates the anchor."""
    import subprocess # noqa: PLC0415
    rel = rel.replace(os.sep, "/")
    try:
        # SHALLOW HISTORY CANNOT ANCHOR: a depth-1 checkout sees only
        # the current value, so the anchor comparison degenerates to comparing a thing with
        # itself and every re-stamp passes. "Could not verify" must never read as verified.
        s = subprocess.run(["git", "-C", root, "rev-parse", "--is-shallow-repository"],
                           capture_output=True, text=True, encoding="utf-8")
        if s.returncode == 0 and s.stdout.strip() == "true":
            return "SHALLOW"
        r = subprocess.run(["git", "-C", root, "log", "--reverse", "--format=%H", "--", rel],
                           capture_output=True, text=True, encoding="utf-8")
    except OSError:
        return None
    if r.returncode != 0:
        return None
    for sha in r.stdout.split():
        b = subprocess.run(["git", "-C", root, "show", f"{sha}:{rel}"],
                          capture_output=True, text=True, encoding="utf-8")
        if b.returncode != 0:
            continue
        m = re.search(r"^registration_digest:\s*['\"]?([0-9a-f]{64})", b.stdout, re.M)
        if m:
            return m.group(1)
    return None


def record_errors(root, entry):
    """[why this protocol's record is not usable], or [].

    The registry entry is re-resolved by id from the registry itself: the scope check below
    compares the SIGNED scope against the REGISTERED citations, and a caller passing a
    synthetic `{"id": ...}` stub (the run validator does) must not make the registered
    citations look empty."""
    pid = str(entry.get("id") or "")
    canon = next((w for w in pg.work_entries(root)
                  if str(w.get("id") or "") == pid), None)
    if canon is not None:
        entry = canon
    path = record_path(pid, root)
    rel = os.path.relpath(path, root)
    if not os.path.exists(path):
        return [f"{pid}: no record at {rel} — scaffold it with --new {pid}"]
    doc, err = pg.read_yaml(path)
    if err:
        return [f"{rel}: {err}"]
    out = []
    if str(doc.get("protocol_id") or "") != pid:
        out.append(f"{rel}: protocol_id {doc.get('protocol_id')!r} does not match the registry id "
                   f"{pid!r} — the record and its registration must name the same object")
    status = str(doc.get("status") or "")
    if status not in STATUSES:
        out.append(f"{rel}: status {status!r} is not one of {list(STATUSES)}")
    # A FROZEN PLAN IS A WHOLE PLAN (probe wave: a registered protocol carrying only
    # `objectives` passed - half a plan frozen is half an analysis prespecified). Every
    # prespecified key must be STATED before the freeze; a draft may hold blanks, that is
    # what draft is for. ALL frozen states, `closed` included - a closed record is still
    # the record of what was prespecified, and closing it must not relax what registering
    # it required.
    if status in FROZEN:
        pre = doc.get("prespecified") if isinstance(doc.get("prespecified"), dict) else {}
        for k in PRESPECIFIED:
            v = pre.get(k)
            # STRUCTURAL, not stringly: `endpoints: []` stringified to "[]",
            # which is a non-empty string wearing an empty plan - a section is stated when
            # it HOLDS something, and nothing it holds is a placeholder marker
            # RECURSIVELY meaningful (probe wave: `endpoints: [""]` and `[null]` held shape
            # and no content): stated means some LEAF carries real text - not empty, not
            # None's name, not a placeholder marker anywhere in the flattened form
            def _leaves(node):
                if isinstance(node, dict):
                    for vv in node.values():
                        yield from _leaves(vv)
                elif isinstance(node, (list, tuple)):
                    for vv in node:
                        yield from _leaves(vv)
                else:
                    yield "" if node is None else " ".join(str(node).split())
            leaves = list(_leaves(v))
            flat = " ".join(leaves)
            # placeholder LEAVES are not content (probe wave: TBD/UNKNOWN/false/0 counted as
            # meaningful) - syntax can go no further than this; whether stated content is
            # clinically adequate stays a human approval, said in the tool's own docstring
            hollow = {"none", "null", "tbd", "todo", "tbc", "unknown", "n/a", "na",
                      "replace_me", "pending", "false", "true", "0", "?", "-"}
            populated = [leaf.strip() for leaf in leaves if leaf.strip()]
            real = [x for x in populated
                    if re.search(r"[A-Za-z0-9]", x) and x.lower() not in hollow]
            # An explicit TODO:/TBD: prefix still promises unfinished work; prose mentioning
            # those words elsewhere is not a marker or an automated scientific judgment.
            hollow_hits = [x for x in populated if x.lower() in hollow
                           or re.match(r"^(?:todo|tbd)\s*:", x, re.IGNORECASE)]
            # a BLANK leaf is a hole too: '' or null INSIDE a section that also holds real
            # text was silently filtered before being counted, so 'Overall survival' beside
            # an empty string froze a slot nobody filled. A section's every leaf carries
            # content, or the section is not stated.
            blank_hits = len(leaves) - len(populated)
            # a MIXED section is unstated too (probe wave: 'Overall survival' beside 'TBD'
            # passed on any() - a placeholder INSIDE a frozen section is a promise to fill
            # it later, which is exactly what frozen forbids)
            if not real or hollow_hits or blank_hits or MARK in flat:
                detail = (f" (placeholder leaf {hollow_hits[0]!r})" if hollow_hits
                          else f" ({blank_hits} blank leaf/leaves)" if (blank_hits and real)
                          else "")
                out.append(f"{rel}: prespecified.{k} is unstated{detail} - a frozen plan "
                           f"with a blank or placeholder {k} froze half a plan; state it "
                           f"whole or keep status: draft")

        # THE SCOPE IS PART OF THE PLAN. The registry's `cites_release` is operational - it
        # is what the scope checks read - and it sits outside the digest, so re-pointing a
        # protocol at different data was a registry edit under an apparently unchanged
        # signed plan. `prespecified.scope` states the same citations INSIDE the freeze,
        # and the two must agree: changing what the plan reads is an amendment.
        scope = pre.get(SCOPE_KEY)
        if not isinstance(scope, list):
            out.append(f"{rel}: prespecified.{SCOPE_KEY} is missing or not a list - the "
                       f"releases a frozen plan reads are part of the plan; state them "
                       f"inside the freeze ([] only for a plan reading no governed release)")
        else:
            def _pins(cites):
                pins = {}
                for c in cites:
                    if isinstance(c, dict):
                        pins.setdefault(_pack_key(c), set()).add(_build_pin(c))
                return pins
            bad_shape = [i for i, c in enumerate(scope)
                         if not (isinstance(c, dict) and str(c.get("product") or "").strip()
                                 and str(c.get("spec_version") or "").strip())]
            if bad_shape:
                out.append(f"{rel}: prespecified.{SCOPE_KEY}[{bad_shape[0]}] does not name "
                           f"a product and spec_version - a scope entry that names neither "
                           f"scopes nothing")
            elif _pins(scope) != _pins(entry.get("cites_release") or []):
                out.append(f"{rel}: prespecified.{SCOPE_KEY} disagrees with the registry "
                           f"entry's cites_release - the signed plan and the operational "
                           f"scope must name the same releases and the same build pins; "
                           f"amend the protocol, or fix the registration to what was signed")

    live = prespecification_digest(doc)
    if live is None:
        out.append(f"{rel}: no `prespecified:` block — a protocol with nothing pre-specified has "
                   f"nothing to freeze, and nothing to be held to afterwards")

    if status in FROZEN:
        # The module header claims `--check` refuses a registered protocol still carrying a marker.
        # It checked two fields, so a registered protocol could carry `title: REPLACE_ME` and a
        # scaffold objective while reporting clean — the header was describing a check that did not
        # exist. One sweep of the loaded record, with no list to fall behind the template.
        for where in pg.marker_paths(doc, MARK):
            out.append(f"{rel}: status is {status!r} and `{where}` still holds {MARK}. A frozen plan "
                       f"is what somebody committed to; a marker in it is the scaffold speaking in "
                       f"their place.")
        for f in HUMAN_FIELDS:
            v = doc.get(f)
            if pg.unstated(v) or MARK in str(v):
                out.append(f"{rel}: status is {status!r} but {f} is still {str(v)!r} — a protocol "
                           f"cannot be registered by a marker")
            #...and `registered_by` has to be a person. A prespecification is the record that
            # somebody committed to an analysis BEFORE seeing the result; attributing that
            # commitment to a team is attributing it to nobody, which is the state the freeze
            # exists to rule out.
            elif f.endswith("_by"):
                bad = pg.not_a_person(v)
                if bad:
                    out.append(f"{rel}: `{f}`: {bad}")
        if not pg.unstated(doc.get("registered_date")) and pg.bad_date(doc.get("registered_date")):
            out.append(f"{rel}: registered_date {doc.get('registered_date')!r} is not YYYY-MM-DD")

        recorded = str(doc.get("prespecification_sha256") or "")
        if pg.unstated(recorded) or MARK in recorded:
            out.append(f"{rel}: status is {status!r} with no prespecification_sha256 — the freeze "
                       f"is the digest; without it the record claims a plan nobody can prove was "
                       f"the plan. Record `--digest {pid}`.")
        elif live and recorded != live:
            amend = [a for a in (doc.get("amendments") or []) if isinstance(a, dict)]
            newest = str((amend[-1].get("covers_digest") if amend else "") or "")
            if newest == live:
                # An amendment covers the change; the top-level digest simply has not been moved
                # forward with it. Say exactly that rather than reporting an unexplained mismatch.
                out.append(f"{rel}: prespecification_sha256 is {recorded[:12]}… but the newest "
                           f"amendment covers {live[:12]}… — move the top-level digest to the one "
                           f"the amendment records, so the record names its CURRENT plan")
            else:
                out.append(f"{rel}: `prespecified:` hashes to {live[:12]}… but the record was "
                           f"registered against {recorded[:12]}… and no amendment covers the "
                           f"change. A registered protocol may be amended, never edited: append an "
                           f"amendment (date, by, what_changed, why, covers_digest) or restore the "
                           f"plan that was registered.")

    # THE CHAIN IS OPT-IN, AND OPTING IN IS STICKY. Protocol records can arrive from an
    # external spec builder another team owns, and refusing theirs for fields our template
    # writes would alarm a system that never promised them — a record that NEVER carried
    # registration_digest keeps every earlier guarantee and gains no new absence errors.
    # But the flag lives in the same mutable file as everything else, so deleting the anchor
    # and recomputing the digest walked out the opt-out door (the operator's own probe).
    # History decides: a record that EVER carried the anchor is chained forever.
    reg_dig = str(doc.get("registration_digest") or "")
    stated = bool(reg_dig) and not pg.unstated(reg_dig) and MARK not in reg_dig
    historical = _first_committed_registration_digest(root, rel) if status in FROZEN else None
    if historical == "SHALLOW":
        #...for EVERY frozen record, anchored or not (earlier review: refusing only
        # when the anchor was still present let a depth-1 checkout shed the anchor, rewrite
        # the plan and validate — shallow history cannot even tell an external record from
        # one whose chain was just deleted).
        historical = None
        out.append(f"{rel}: this checkout's git history is SHALLOW, so whether this record "
                   f"was ever anchored cannot be determined — fetch full history "
                   f"(fetch-depth: 0); an unverifiable chain is refused, never assumed")
    chained = stated or bool(historical)
    if status in FROZEN and historical and not stated:
        out.append(f"{rel}: history records registration_digest {historical[:12]}… and the "
                   f"record no longer carries one — the anchor, once recorded, never leaves; "
                   f"deleting it is the re-stamp wearing the opt-out's clothes. Restore it.")
        reg_dig = historical # the chain still runs from the true anchor

    amendments = doc.get("amendments") if doc.get("amendments") is not None else []
    if not isinstance(amendments, list):
        # a mapping here used to CRASH the newest-entry check below - a malformed record must
        # be a refusal, never a traceback
        out.append(f"{rel}: `amendments` is not a list - one entry per amendment, in the order "
                   f"they were made")
        amendments = []
    if amendments and status not in ("amended", "closed"):
        out.append(f"{rel}: {len(amendments)} amendment(s) recorded but status is {status!r} — a "
                   f"protocol that has been amended says so; any other status hides the amendment")
    if chained and status == "amended" and not amendments:
        out.append(f"{rel}: status is 'amended' with no amendment recorded — the status claims a "
                   f"change nobody wrote down, which is the silent edit wearing the amendment's "
                   f"name")
    # CLOSURE IS AN ACT WITH AN ACTOR. A protocol nobody closed is not closed; without these,
    # `status: closed` was a free edit no person or date stood behind.
    if status == "closed":
        if chained:
            if pg.unstated(doc.get("closed_by")) or MARK in str(doc.get("closed_by")):
                out.append(f"{rel}: status is 'closed' but closed_by is unstated — closing a "
                           f"study is a person's act, and this record does not name the person")
            else:
                bad = pg.not_a_person(doc.get("closed_by"))
                if bad:
                    out.append(f"{rel}: `closed_by`: {bad}")
            if pg.unstated(doc.get("closed_date")) or pg.bad_date(doc.get("closed_date")):
                out.append(f"{rel}: status is 'closed' but closed_date "
                           f"{doc.get('closed_date')!r} is not a YYYY-MM-DD date")
        # CLOSURE HAS A CHRONOLOGY: a study closed before it was
        # registered, or amended after it closed, validated clean — dates that describe an
        # impossible history are not dates, and closed means nothing changes after. Holds
        # over whatever dates are PRESENT, anchored record or not.
        cd_ = str(doc.get("closed_date") or "")
        if cd_ and not pg.unstated(cd_) and not pg.bad_date(cd_):
            rd_ = str(doc.get("registered_date") or "")
            if rd_ and not pg.bad_date(rd_) and cd_ < rd_:
                out.append(f"{rel}: closed_date {cd_} precedes registered_date {rd_} — a study "
                           f"cannot end before it began")
            for i, a in enumerate(doc.get("amendments") or []
                                  if isinstance(doc.get("amendments"), list) else []):
                ad = str((a or {}).get("date") or "") if isinstance(a, dict) else ""
                if ad and not pg.bad_date(ad) and ad > cd_:
                    out.append(f"{rel} amendments[{i}]: dated {ad}, after closed_date {cd_} — "
                               f"closed means the plan stopped moving; an amendment after "
                               f"closure amends a study that no longer exists")
    # THE ANCHOR OF THE CHAIN. `registration_digest` is the plan AS REGISTERED and never moves;
    # every amendment chains from it (sticky opt-in — see `chained` above).
    if status in FROZEN and chained:
        if not re.fullmatch(r"[0-9a-f]{64}", reg_dig):
            out.append(f"{rel}: registration_digest {reg_dig[:20]!r} is not a sha256")
            reg_dig = ""
        elif historical and historical != reg_dig:
            #...it must still BE the first value git ever recorded for it. The in-file
            # chain alone could not see the plan and both digests moved in one edit.
            out.append(f"{rel}: registration_digest is {reg_dig[:12]}… but history first "
                       f"recorded {historical[:12]}… — a registration happens once; moving "
                       f"its digest re-registers a plan nobody registered. Restore it, "
                       f"and record the change as the amendment it is.")
    expect_prev = reg_dig or None
    prev_date = str(doc.get("registered_date") or "")
    for i, a in enumerate(amendments):
        where = f"{rel} amendments[{i}]"
        if not isinstance(a, dict):
            out.append(f"{where}: not a mapping")
            continue
        # `amended_by`, matching every other attribution field, so the identity audit's `*_by`
        # walk sees it — the bare `by` it replaced was the one accountable act the walk missed.
        # `previous_digest` is the chain's link and required only of records that opted in.
        for f in ("date", "amended_by", "what_changed", "why", "covers_digest") \
                + (("previous_digest",) if chained else ()):
            v = a.get(f)
            if pg.unstated(v) or MARK in str(v):
                out.append(f"{where}: {f} is unstated — an amendment that does not say who changed "
                           f"what, when and why, from which state to which, is the silent edit it "
                           f"exists to replace")
        if not pg.unstated(a.get("date")) and pg.bad_date(a.get("date")):
            out.append(f"{where}: date {a.get('date')!r} is not YYYY-MM-DD")
        elif not pg.unstated(a.get("date")) and prev_date and not pg.bad_date(prev_date) \
                and str(a.get("date")) < prev_date:
            out.append(f"{where}: date {a.get('date')!r} precedes {prev_date} — amendments are "
                       f"appended in the order they were made, and one dated before the state it "
                       f"amends describes a different history")
        if not pg.unstated(a.get("date")) and not pg.bad_date(a.get("date")):
            prev_date = str(a.get("date"))
        # `amended_by` is the amendment's whole accountability: the record exists so that a change
        # to a frozen plan names somebody rather than appearing. A team there names nobody.
        if not pg.unstated(a.get("amended_by")):
            bad = pg.not_a_person(a.get("amended_by"))
            if bad:
                out.append(f"{where}: `amended_by`: {bad}")
        pd, cd = str(a.get("previous_digest") or ""), str(a.get("covers_digest") or "")
        for fname, val in (("previous_digest", pd), ("covers_digest", cd)):
            if val and not pg.unstated(val) and not re.fullmatch(r"[0-9a-f]{64}", val):
                out.append(f"{where}: {fname} {val[:20]!r} is not a sha256 — a digest that can "
                           f"never match anything covers nothing")
                val = ""
            if fname == "previous_digest":
                pd = val
            else:
                cd = val
        if pd and cd and pd == cd:
            out.append(f"{where}: previous_digest equals covers_digest — an amendment that "
                       f"leaves the plan hashing the same changed nothing the freeze can see")
        # EACH LINK CONSUMES THE LAST. previous_digest must be the state the record was in:
        # the registration for the first amendment, the prior amendment's covers_digest after.
        # A fabricated intermediate digest breaks the chain here instead of passing unread.
        if pd and expect_prev and pd != expect_prev:
            out.append(f"{where}: previous_digest {pd[:12]}… does not consume the preceding "
                       f"state {expect_prev[:12]}… — the chain must run registration_digest "
                       f"through every amendment to the current plan, each link from the last")
        if cd:
            expect_prev = cd
    # THE CHAIN ENDS AT THE PLAN. On a frozen record the newest amendment must cover the digest
    # the record now carries — and with NO amendments the current digest must BE the registered
    # one: a moved digest with no amendment is the silent re-stamp itself.
    if status in FROZEN:
        recorded = str(doc.get("prespecification_sha256") or "")
        if amendments:
            newest = str((amendments[-1].get("covers_digest")
                          if isinstance(amendments[-1], dict) else "") or "")
            if newest and recorded and not pg.unstated(recorded) and newest != recorded:
                out.append(f"{rel}: the newest amendment covers {newest[:12]}… but the record's "
                           f"prespecification_sha256 is {recorded[:12]}… — the last amendment must "
                           f"cover the plan as it now stands")
        elif reg_dig and recorded and not pg.unstated(recorded) and recorded != reg_dig:
            out.append(f"{rel}: prespecification_sha256 is {recorded[:12]}… but the plan was "
                       f"registered as {reg_dig[:12]}… and no amendment records the change — a "
                       f"re-stamped digest with no amendment is exactly the edit the freeze "
                       f"exists to make visible")
    return out


def _pack_key(c):
    """The PACK a citation names — (product, spec_version)."""
    return (str(c.get("product") or ""), str(c.get("spec_version") or ""))


def _build_pin(c):
    """The BUILD a citation pins, or None when it names the pack only.

    `source_manifest.citation_errors` already distinguishes the two strengths — a pack-level
    citation buys Gates 1-4 on the pack, a build-level one adds Gate 6 for that build. Scope was
    blind to the difference: it compared pack keys, so a request under a protocol pinned to one
    build could read a DIFFERENT cut of the same spec version and pass.
    """
    bid, man = str(c.get("build_id") or "").strip(), str(c.get("manifest_sha256") or "").strip()
    return (bid, man) if (bid or man) else None


def request_scope_errors(root):
    """[why a request reads outside the protocol it runs under] — the study-drift check.

    A request may declare `under_protocol:`. When it does, every release it cites must be one the
    PROTOCOL cites: a study that acquires a new data source one analysis at a time has changed its
    own scope without anyone deciding to, and each individual step looks reasonable.

    SCOPE IS THE BUILD, NOT ONLY THE PACK, wherever the protocol says so. A protocol registered
    against a pack it has not yet read pins nothing — that is the normal order, because
    pre-specification comes BEFORE the cut — and its requests may pin whichever build they ran on. A
    protocol written against an EXISTING release pins that build, and then a request reading another
    cut of the same spec version is reading different data under a plan that named specific data.
    Comparing spec versions alone could not tell those apart.

    The third case is the one no single record can see: two requests under one protocol reading two
    DIFFERENT builds of the same pack. Neither request is outside scope, and the study's numbers came
    from two cuts. `scope_report` is where that surfaces.
    """
    out = []
    by_id = {str(w.get("id") or ""): w for w in pg.work_entries(root)}
    for w in pg.work_entries(root):
        pid = str(w.get("under_protocol") or "").strip()
        if not pid:
            continue
        wid = str(w.get("id") or "?")
        prot = by_id.get(pid)
        if prot is None or str(prot.get("kind") or "") != "protocol":
            out.append(f"{wid}: under_protocol {pid!r} is not a registered protocol")
            continue
        doc, err = pg.read_yaml(record_path(pid, root))
        if err is None and str((doc or {}).get("status") or "") == "draft":
            out.append(f"{wid}: runs under {pid}, which is still `draft` — work executed under an "
                       f"unregistered plan is not pre-specified, which is the only thing running "
                       f"under a protocol buys")
        #...and a CLOSED protocol accepts no work either. The project-run validator already
        # refused it; this boundary silently accepted it, so the same protocol was invalid for
        # one kind of work and fine for another. A closed plan is a finished study — work
        # arriving after it closed was not pre-specified by it.
        elif err is None and str((doc or {}).get("status") or "") == "closed":
            out.append(f"{wid}: runs under {pid}, which is `closed` — a closed protocol is a "
                       f"finished study; new work under it is work its plan never pre-specified. "
                       f"Register a new protocol, or run this request outside one.")
        pinned = {}
        for c in (prot.get("cites_release") or []):
            if isinstance(c, dict):
                pinned.setdefault(_pack_key(c), []).append(_build_pin(c))
        for c in (w.get("cites_release") or []):
            if not isinstance(c, dict):
                continue
            key = _pack_key(c)
            if key not in pinned:
                out.append(f"{wid}: reads {key[0]} {key[1]}, which {pid} does not cite. A study "
                           f"does not acquire a data source one analysis at a time — amend the "
                           f"protocol to name it, or run this request outside the protocol.")
                continue
            pins = [p for p in pinned[key] if p]
            if not pins:
                continue # the protocol named the pack, not a cut: any build
            mine = _build_pin(c)
            if mine is None:
                names = ", ".join(sorted(b or m for b, m in pins))
                out.append(f"{wid}: reads {key[0]} {key[1]} without naming a build, but {pid} is "
                           f"pre-specified against {names}. A plan written against specific data "
                           f"is not a plan for whatever that pack becomes — pin the build this "
                           f"request read, or amend the protocol to the pack level.")
            elif mine not in pins:
                names = ", ".join(sorted(b or m for b, m in pins))
                out.append(f"{wid}: reads {key[0]} {key[1]} build {mine[0] or mine[1]}, and {pid} "
                           f"is pre-specified against {names}. A different cut of the same "
                           f"specification is different data — amend the protocol, or run this "
                           f"request outside it.")
    return out


def scope_report(root=None):
    """{protocol_id: {pack_key: {"pinned": [...], "read": [...]}}} — what each study ACTUALLY read.

    The question no individual record answers: "which data did this study use?" A protocol names
    packs; each request under it names a build; nothing joined the two, so recovering a study's data
    provenance meant opening every request.

    It also exposes the failure `request_scope_errors` structurally cannot see. Two requests under
    one protocol, each citing a build the protocol permits, each perfectly in scope, reading two
    DIFFERENT cuts of the same pack — the study's numbers then come from two deliveries and no
    record says so. That is a finding about the SET, so it has to be computed over the set.
    """
    root = root or REPO
    entries = pg.work_entries(root)
    report = {}
    for w in entries:
        if str(w.get("kind") or "") != "protocol":
            continue
        pid = str(w.get("id") or "")
        packs = {}
        for c in (w.get("cites_release") or []):
            if isinstance(c, dict):
                packs.setdefault(_pack_key(c), {"pinned": [], "read": []})
                pin = _build_pin(c)
                if pin:
                    packs[_pack_key(c)]["pinned"].append(pin)
        report[pid] = packs
    for w in entries:
        pid = str(w.get("under_protocol") or "").strip()
        if pid not in report:
            continue
        for c in (w.get("cites_release") or []):
            if not isinstance(c, dict):
                continue
            slot = report[pid].setdefault(_pack_key(c), {"pinned": [], "read": []})
            pin = _build_pin(c)
            if pin and pin not in slot["read"]:
                slot["read"].append(pin)
    return report


def split_build_findings(report):
    """[sentences] naming every protocol whose requests read more than one build of one pack."""
    out = []
    for pid, packs in sorted(report.items()):
        for (slug, ver), slot in sorted(packs.items()):
            if len(slot["read"]) > 1:
                builds = ", ".join(sorted(b or m for b, m in slot["read"]))
                out.append(f"{pid}: requests under this protocol read {len(slot['read'])} different "
                           f"builds of {slug} {ver} ({builds}). Each request is individually in "
                           f"scope and the study's numbers came from more than one cut — state "
                           f"which build each result is from, or re-run them onto one.")
    return out


def event_payload(doc):
    """The COMPLETE decision content of a protocol record, as the ledger seals it.

    Everything a coordinated edit could move: the identity, the status, both digests, the
    whole canonical plan, every amendment, and the closure. Bounded by construction — a
    protocol is prose sections, never a document blob."""
    return {
        "protocol_id": str(doc.get("protocol_id") or ""),
        "title": str(doc.get("title") or ""),
        "status": str(doc.get("status") or ""),
        "registered_by": str(doc.get("registered_by") or ""),
        "registered_date": str(doc.get("registered_date") or ""),
        "registration_digest": str(doc.get("registration_digest") or ""),
        "prespecification_sha256": str(doc.get("prespecification_sha256") or ""),
        "prespecified": _canonical(doc.get("prespecified") or {}),
        "amendments": _canonical(doc.get("amendments") or []),
        "closed_by": str(doc.get("closed_by") or ""),
        "closed_date": str(doc.get("closed_date") or ""),
    }


def record_event(root, pid, now_utc):
    """Append this protocol's current state to the event ledger — the person's act, recorded.

    SIDE BY SIDE with the per-surface anchors (the ledger contract): the record stays the
    page people edit; the ledger seals what it said when a person recorded the transition.
    The ACTOR IS TRANSCRIBED from the attribution the person already typed and committed
    into the record — registered_by for a registration, the newest amendment's amended_by
    for an amendment, closed_by for a closure — at `typed` trust, exactly as the decision
    wave transcribes committed forms. No flag names a person; no session invents one.
    Returns (event, None) or (None, why)."""
    from rwd_tools import event_ledger as el # noqa: PLC0415
    path = record_path(pid, root)
    if not os.path.exists(path):
        return None, f"{pid}: no record at {repo_relative(path, root)} — scaffold it with --new {pid}"
    doc, err = pg.read_yaml(path)
    if err:
        return None, f"{pid}: {err}"
    entry = next((w for w in pg.work_entries(root)
                  if str(w.get("id") or "") == pid), None)
    errs = record_errors(root, entry or {"id": pid})
    if errs:
        return None, (f"{pid}: the record does not validate, and the ledger seals only "
                      f"valid states - fix these first:\n  - " + "\n  - ".join(errs))
    status = str(doc.get("status") or "")
    if status == "draft":
        return None, f"{pid}: a draft is not a transition - nothing to record yet"
    amendments = doc.get("amendments") or []
    if status == "closed":
        action, who = "closed", doc.get("closed_by")
    elif amendments:
        action = "amended"
        who = (amendments[-1] or {}).get("amended_by") if isinstance(amendments[-1], dict) \
            else None
    else:
        action, who = "registered", doc.get("registered_by")
    trust = "typed"
    if pg.unstated(who):
        return None, (f"{pid}: the record names nobody for its {action} - the event's actor "
                      f"is transcribed from the record, never typed by a tool")
    payload = event_payload(doc)
    obj = str(doc.get("object_uuid") or "") or None
    prev = ""
    if obj:
        try:
            _seq, prev = el.head_of(root, obj)
        except el.LedgerError as e:
            return None, str(e)
    else:
        # a genesis over a record git already holds is an IMPORT, not a new act — the
        # committed attribution keeps its limited trust (safeguard 8, extended to
        # protocols by an earlier review)
        import subprocess # noqa: PLC0415
        rel_file = repo_relative(path, root)
        try:
            r = subprocess.run(["git", "-C", root, "log", "-1", "--format=%H", "--",
                                rel_file], capture_output=True, text=True, encoding="utf-8")
            if r.returncode == 0 and r.stdout.strip():
                action, trust = "legacy_imported", "unauthenticated_legacy"
        except OSError:
            pass
    actor = {"subject_id": str(who), "identity_provider": "typed",
             "display_name": str(who), "role": "recorded-in-protocol",
             "trust_level": trust}
    try:
        event = el.append_event(
            root, object_uuid=obj, object_kind="protocol", action=action, actor=actor,
            occurred_at=now_utc, payload=payload,
            expected_previous_event_sha256=prev,
            idempotency_key=f"{pid}:{action}:{el.payload_digest(payload)[:16]}")
    except el.LedgerError as e:
        return None, f"{pid}: {e}"
    if not obj:
        # the OBJECT IDENTITY is tool-owned plumbing (like a scaffold's ids), written once
        # and never moved - the stable name that survives renames and display-id changes
        doc["object_uuid"] = event["object_uuid"]
        # INSERTED, NOT DUMPED: a safe_dump rewrote the person's record and stripped every guidance
        # comment the scaffold wrote (thirteenth pass, J4); one line lands after the id line
        with open(path, encoding="utf-8") as fh:
            text = fh.read()
        line = f"object_uuid: {event['object_uuid']}   # the ledger object this record owns; tool-written, never moved\n"
        m = re.search(r"^protocol_id\s*:.*$", text, re.M)
        text = (text[:m.end() + 1] + line + text[m.end() + 1:]) if m else line + text
        with open(path, "w", encoding="utf-8", newline="\n") as fh:
            fh.write(text)
    return event, None


def ledger_parity_errors(root, entry):
    """[why this record disagrees with its ledger], or []. The side-by-side rule: a record
    that names an object_uuid is a PROJECTION - it must match the newest event's sealed
    payload, or the divergence is named until a person records the next transition."""
    from rwd_tools import event_ledger as el # noqa: PLC0415
    pid = str(entry.get("id") or "")
    doc, err = pg.read_yaml(record_path(pid, root))
    if err or not isinstance(doc, dict):
        return [] # record_errors already owns this
    obj = str(doc.get("object_uuid") or "")
    if not obj:
        # PARTICIPATION IS HISTORICALLY IRREVERSIBLE: a record whose
        # committed history ever carried an object_uuid cannot shed it to switch parity off
        ever = el.ever_carried_object_uuid(root, os.path.relpath(record_path(pid, root), root))
        if ever == "SHALLOW":
            return [f"{pid}: git history is SHALLOW, so whether this record was ever "
                    f"sealed cannot be determined - fetch full history (fetch-depth: 0)"]
        if ever:
            return [f"{pid}: history records an object_uuid this record no longer "
                    f"carries - ledger participation, once begun, never ends; restore it"]
        return []
    # IDENTITY IS PINNED AT FIRST COMMIT (earlier review: re-pointing a sealed record
    # at a freshly minted twin object with an identical payload kept parity green)
    pin = el.first_committed_object_uuid(root, repo_relative(record_path(pid, root), root))
    if pin == "SHALLOW":
        return [f"{pid}: git history is SHALLOW, so the pinned identity cannot be "
                f"verified - fetch full history (fetch-depth: 0)"]
    if pin and pin != obj:
        return [f"{pid}: carries object_uuid {obj} but history pinned {pin} at first "
                f"commit - identity never re-homes; a swapped uuid grafts the record onto "
                f"another object's history"]
    if not os.path.isdir(os.path.join(root, el.EVENTS_DIR)):
        # a checkout with NO ledger at all is an exercise copy of a sealed record - parity
        # stands down; deleting the ledger from a REAL root is the ledger check's own
        # refusal (git history decides which case this is, there)
        return [] # not yet on the ledger - side-by-side
    files = el._event_files(root, obj)
    sealed = None
    for _seq, fname in files:
        ev, everr = el.read_event(root, obj, fname)
        if not everr and isinstance(ev, dict) and ev.get("action") != "attested":
            sealed = ev
    if sealed is None:
        return [f"{pid}: names ledger object {obj} which holds no lifecycle event - a "
                f"projection of nothing projects nothing"]
    live = el.payload_digest(event_payload(doc))
    if str(sealed.get("payload_sha256")) != live:
        return [f"{pid}: the record has moved past its ledger (sealed "
                f"{str(sealed.get('payload_sha256'))[:12]}…, live {live[:12]}…) - edit, "
                f"then RECORD the transition: protocol_record --record-event {pid}"]
    return []


def check(root=None):
    """[(protocol_id, [errors])] for every registered protocol, plus the scope check."""
    root = root or REPO
    rows = [(str(w.get("id") or "?"), record_errors(root, w) + sm.citation_errors(root, w)
             + ledger_parity_errors(root, w))
            for w in _protocols(root)]
    scope = request_scope_errors(root) + split_build_findings(scope_report(root))
    if scope:
        rows.append(("(scope)", scope))
    return rows


def main(argv):
    ap = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    ap.add_argument("--new", metavar="ID", help="scaffold work/<ID>/PROTOCOL.yaml")
    ap.add_argument("--draft-product", metavar="PACK", help="planning context for a draft; never a released-product pin")
    ap.add_argument("--associate-draft", metavar="ID", help="explicitly attach an existing unbound draft to planning context")
    ap.add_argument("--expected-sha256", help="with --associate-draft: exact protocol bytes reviewed in the preview")
    ap.add_argument("--digest", metavar="ID",
                    help="print the sha256 of that protocol's `prespecified:` block — what a "
                         "registration or an amendment records")
    ap.add_argument("--record-event", metavar="ID",
                    help="seal this protocol's current state into the event ledger - the "
                         "actor is transcribed from the record's own signed attribution")
    ap.add_argument("--check", action="store_true", help="exit non-zero on any error")
    ap.add_argument("--scope", action="store_true",
                    help="per protocol: the packs it cites, the builds it PINS, and the builds its "
                         "requests actually read")
    a = ap.parse_args(argv)

    if ((a.draft_product is not None and a.new is None and a.associate_draft is None)
            or (a.expected_sha256 is not None and a.associate_draft is None)
            or (a.new is not None and a.associate_draft is not None)):
        print("REFUSED — draft context needs exactly one of --new or --associate-draft", file=sys.stderr)
        return 1
    if a.associate_draft is not None:
        try:
            if not a.expected_sha256 or not re.fullmatch(r"[0-9a-f]{64}", a.expected_sha256):
                raise ValueError("Preview the study draft and supply its exact --expected-sha256.")
            path = _draft_path(REPO, a.associate_draft)
            if not path.is_file():
                raise ValueError("Choose an existing study draft.")
            with _draft_writer(path):
                preview = draft_association(REPO, a.associate_draft, a.draft_product)
                if preview["sha256"] != a.expected_sha256:
                    raise ValueError("The study draft changed. Preview the association again.")
                _publish_draft(path, preview["after"].encode("utf-8"), previous=preview["before"].encode("utf-8"))
            print("Study draft associated for planning only; no pin, registration or release was created.")
            return 0
        except (OSError, ValueError) as error:
            print(f"REFUSED — {error}", file=sys.stderr)
            return 1

    if a.new is not None:
        pid = a.new.strip()
        # the CENTRAL grammar (probe wave: this check blocked '/' but not '..', and `--new..`
        # scaffolded ABOVE work/ - every work id goes through product_gates.safe_work_id now).
        # `pg` is the MODULE-LEVEL import: a local `import product_gates as pg` here made the
        # name local to all of main(), so `--digest` (an earlier branch) read it unbound and
        # crashed on the one command a person must run to register a protocol (thirteenth pass).
        ok, err = pg.safe_work_id(pid)
        if not ok:
            print(f"REFUSED — {err}", file=sys.stderr)
            return 1
        path = record_path(pid)
        if pg.kind_for(REPO, pid) == "product":
            print(f"REFUSED — {pid!r} is a product slug (products/registry.yaml): one name, one object; nothing written",
                  file=sys.stderr)
            return 1
        if os.path.exists(path):
            print(f"REFUSED — {os.path.relpath(path, REPO)} already exists; a registered plan is "
                  f"amended, never regenerated", file=sys.stderr)
            return 1
        try:
            path = _draft_path(REPO, pid)
            text = TEMPLATE.format(pid=pid)
            if a.draft_product is not None:
                product = draft_product(REPO, a.draft_product)
                text += ("\n# Planning context only; no released product or study pin is claimed.\n"
                         f"draft_product: {product}\n")
            with _draft_writer(path):
                _publish_draft(path, text.encode("utf-8"))
        except (OSError, ValueError) as error:
            print(f"REFUSED — {error}", file=sys.stderr)
            return 1
        print(f"wrote {os.path.relpath(path, REPO)}")
        # The portal shows a person these lines: the first is theirs, in plain words, and points at
        # the page that registers a plan (walk 2026-09-07, S-REG); the second keeps this tool's own
        # facts for someone working at a terminal.
        print("Open the study in Studies, complete the plan, then register it from the protocol page.")
        print(f"By hand instead: fill every {MARK}, add the study's `work:` entry to products/registry.yaml "
              f"with the releases it reads, record `--digest {pid}` as registration_digest and "
              f"prespecification_sha256, and set status: registered.")
        return 0

    if a.record_event is not None:
        import datetime as _dt # noqa: PLC0415
        now = _dt.datetime.now(_dt.timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
        event, why = record_event(REPO, a.record_event.strip(), now)
        if why:
            print(f"REFUSED - {why}", file=sys.stderr)
            return 1
        if str(event.get("occurred_at")) != now:           # an idempotent replay wrote nothing (thirteenth pass)
            print(f"already sealed {event['object_uuid']} seq {event['seq']} ({event['action']}) on "
                  f"{event.get('occurred_at')} - nothing new recorded")
            return 0
        print(f"sealed {event['object_uuid']} seq {event['seq']} ({event['action']}) - "
              f"event {event['event_sha256'][:16]}…  commit governance/events/ with the "
              f"record; the ledger and its projection travel together")
        return 0

    if a.digest is not None:
        if not os.path.exists(record_path(a.digest.strip())):
            print(f"REFUSED — {a.digest.strip()}: no record at work/{a.digest.strip()}/PROTOCOL.yaml — scaffold it "
                  f"with --new {a.digest.strip()}", file=sys.stderr)
            return 1
        doc, err = pg.read_yaml(record_path(a.digest.strip()))
        if err:
            print(f"REFUSED — {err}", file=sys.stderr)
            return 1
        d = prespecification_digest(doc)
        if d is None:
            print("REFUSED — no `prespecified:` block to digest", file=sys.stderr)
            return 1
        print(d)
        return 0

    if a.scope:
        report = scope_report()
        if not report:
            print("no protocols registered — nothing to scope")
            return 0
        for pid, packs in sorted(report.items()):
            print(pid)
            for (slug, ver), slot in sorted(packs.items()):
                pins = ", ".join(sorted(b or m for b, m in slot["pinned"])) or "the pack, any build"
                read = ", ".join(sorted(b or m for b, m in slot["read"])) or "nothing yet"
                print(f"    {slug} {ver}")
                print(f"        pre-specified against: {pins}")
                print(f"        builds actually read:  {read}")
        findings = split_build_findings(report)
        for f in findings:
            print(f"\n  ! {f}")
        return 1 if findings else 0

    rows = check()
    if not rows:
        print("0 protocol(s) registered — products/registry.yaml has no `work:` entry of kind "
              "protocol")
        return 0
    bad = 0
    for pid, errs in rows:
        bad += len(errs)
        print(f"{pid:<30} " + ("OK" if not errs else f"{len(errs)} error(s)"))
        for e in errs:
            print(f"    {e}")
    print(f"\n{len(rows)} protocol(s); {bad} error(s)")
    return 1 if (a.check and bad) else 0


if __name__ == "__main__":
    from rwd_tools.console import use_utf8
    use_utf8()
    sys.exit(main(sys.argv[1:]))
