"""Read protected administrator enrollment; Git alone is not an identity provider.

Trust root: the managed installation's state/admin-trust directory, protected by
server OS permissions. Repository edits and development profiles cannot enroll.
The server operator must restrict this directory to the application service and
trusted administrators, and include it in the installation's verified backups.
"""
from pathlib import Path
import hashlib
import json
import os
import re
import stat

NOTICE = "Open Reviewer identity enrollment on this review page. A different authenticated administrator must enroll the reviewer's existing signing key in the managed installation before verified signatures count."
REVIEW_ROLES = {"admin", "initiator", "reviewer", "qc_programmer"}


def location(root):
    root = Path(root).resolve()
    state_value = os.environ.get("RWDP_STATE_DIR", "")
    if not state_value or not Path(state_value).is_absolute():
        raise ValueError("Configure managed installation storage before enrolling reviewers. " + NOTICE)
    state = Path(state_value)
    if state.resolve() != state or state.name != "state" or state.is_relative_to(root):
        raise ValueError("Reviewer identity trust must use the managed state/admin-trust directory outside the Git workspace.")
    marker = state.parent / "installation.json"
    if marker.resolve() != marker or not marker.is_file() or marker.stat().st_size > 8192:
        raise ValueError("Initialize the managed installation before reviewer enrollment. " + NOTICE)
    value = json.loads(marker.read_bytes())
    if (value.get("version") != 1 or value.get("deployment") != "single_authoring_host"
            or value.get("layout") != {a: a for a in ("workspace", "state", "sources")}
            or not re.fullmatch(r"[a-f0-9]{32}", str(value.get("installation_id", "")))
            or state.parent / "workspace" != root):
        raise ValueError("Reviewer trust does not belong to this managed installation.")
    directory = state / "admin-trust"
    path = directory / "reviewer-enrollments.json"
    if directory.resolve() != directory or path.resolve() != path:
        raise ValueError("The reviewer enrollment store redirects outside its protected directory.")
    for target in (directory, path):
        if os.name != "nt" and target.exists() and target.stat().st_mode & (stat.S_IWGRP | stat.S_IWOTH):
            raise ValueError("The reviewer trust store is writable by other OS users. Restrict it to the application service and trusted administrators.")
    return path, value["installation_id"]


def read(root):
    path, installation = location(root)
    if not path.exists():
        return {"version": 1, "installation_id": installation, "events": []}, None
    if not path.is_file() or path.stat().st_size > 4 * 1024 * 1024:
        raise ValueError("Restore the bounded reviewer enrollment store from its verified backup.")
    raw = path.read_bytes()
    value = json.loads(raw)
    if (not isinstance(value, dict) or set(value) != {"version", "installation_id", "events"}
            or value["version"] != 1 or value["installation_id"] != installation
            or not isinstance(value["events"], list) or len(value["events"]) > 10000):
        raise ValueError("Restore the valid reviewer enrollment store from its verified backup.")
    for event in value["events"]:
        if (not isinstance(event, dict) or set(event) != {"id", "principal", "name", "key_id", "by", "at", "status", "reason"}
                or any(not isinstance(event[k], str) or not event[k] or len(event[k]) > 1000
                       or any(ord(c) < 32 for c in event[k]) for k in event)
                or event["status"] not in {"enrolled", "revoked"}
                or event["principal"].casefold() == event["by"].casefold()):
            raise ValueError("The enrollment store contains an invalid or self-enrolled identity; restore its reviewed history.")
    return value, hashlib.sha256(raw).hexdigest()


def principal(row):
    return str(row.get("principal") or row.get("email") or "").strip().casefold()


def current_roster(root):
    path, _ = location(root)
    roster_path = path.parent.parent / "users.json"
    if roster_path.resolve() != roster_path or not roster_path.is_file() or roster_path.stat().st_size > 4 * 1024 * 1024:
        raise ValueError("The managed reviewer roster is unavailable; an administrator must restore it.")
    users = json.loads(roster_path.read_bytes())
    if not isinstance(users, list) or any(not isinstance(row, dict) for row in users):
        raise ValueError("The managed reviewer roster is invalid.")
    return users


def verify(root, name, key_id):
    """Independent enrollment plus current roster, after the caller verifies Git."""
    if not os.environ.get("RWDP_STATE_DIR", ""):
        return {"ok": False, "code": "identity_scope_unavailable",
            "why": "Independent reviewer authentication is unavailable in this local checkout. "
                   "Run this check in the initialized installation with RWDP_STATE_DIR set to its state directory. "
                   "The signature can be checked locally; approval and release remain blocked until enrollment is verified."}
    try:
        store, _ = read(root)
        latest = next((e for e in reversed(store["events"]) if e["key_id"] == key_id), None)
        if not latest or latest["status"] != "enrolled" or latest["name"] != name:
            return {"ok": False, "why": NOTICE}
        matches = [u for u in current_roster(root) if principal(u) == latest["principal"]]
        if (len(matches) != 1 or matches[0].get("name") != name or matches[0].get("role") not in REVIEW_ROLES):
            return {"ok": False, "why": "The enrolled reviewer is absent, renamed or no longer has reviewer access. Restore the correct roster entry or revoke and review enrollment."}
        return {"ok": True, "principal": latest["principal"], "enrollment_id": latest["id"],
            "why": "Verified personal Git signature and independent administrator enrollment match the current reviewer principal."}
    except (OSError, ValueError, TypeError, KeyError) as error:
        return {"ok": False, "why": str(error)}
