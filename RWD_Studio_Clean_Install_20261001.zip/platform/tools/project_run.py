#!/usr/bin/env python3
"""Record and validate project runs.

    python platform/tools/project_run.py <project-id> --check
    python platform/tools/project_run.py <project-id> --record \\
        --parameters k=v ... --environment "<declared runtime>" \\
        --output name=/path/outside/the/checkout ...
    python platform/tools/project_run.py --validate-records [--verify-outputs] [--verify-citations]

A run record is to a project what a refresh manifest is to a product: the durable claim of
exactly what was consumed and produced. This tool records runs; it schedules nothing and
executes nothing.

Recording requires, in order:
  1. A registered project (`work:` entry, `kind: project`) with a safe id.
  2. A registered, frozen, complete protocol named on the project entry. The run may only
     cite releases inside the protocol's prespecified scope, matching exact build pins
     where the protocol pins them.
  3. Fully pinned citations (`build_id` + 64-hex `manifest_sha256`) that pass
     `source_manifest.citation_errors` — the cited build must be publishable.
  4. A clean tree (the code digest must be a commit) and at least one output file outside
     the checkout (the record stores path, size and sha256; never the bytes).

Records land at `work/<id>/runs/<utc>Z-<commit7>.yaml`, are never overwritten, and are
committed. Validation (`--validate-records`, also run by the test suite) holds each record
against history: the registry and protocol as of the recorded commit, the commit's lineage,
the filename's embedded sha, and the first-committed blob — an in-place edit is named.
`--verify-outputs` re-hashes reachable output files; `--verify-citations` re-asks whether
the cited releases are still citable today.
"""
from __future__ import annotations

import argparse
import datetime
import hashlib
import json
import os
import re
import subprocess
import sys

TOOLS = os.path.dirname(os.path.abspath(__file__))
from rwd_services import workspace_root
ROOT = str(workspace_root(__file__))

from rwd_tools import product_gates as pg # noqa: E402
from rwd_tools import source_manifest as sm # noqa: E402


def _git(root, *args):
    return subprocess.run(["git", "-C", root, *args], capture_output=True,
                          text=True, encoding="utf-8", check=True).stdout.strip()


def _git_raw(root, *args):
    """Like _git but without stripping - for blob content, where whitespace is content."""
    return subprocess.run(["git", "-C", root, *args], capture_output=True,
                          text=True, encoding="utf-8", check=True).stdout


def _strict_yaml(text, what):
    """Parse YAML refusing duplicate keys - permissive loading lets the second of two
    duplicate keys win silently, which in a governed register is a hidden override."""
    import yaml # noqa: PLC0415

    class _Strict(yaml.SafeLoader):
        pass

    def _mapping(loader, node, deep=False):
        seen = set()
        for k_node, _v in node.value:
            k = loader.construct_object(k_node, deep=deep)
            if k in seen:
                raise ValueError(f"{what}: duplicate key {k!r}")
            seen.add(k)
        return yaml.SafeLoader.construct_mapping(loader, node, deep)

    _Strict.add_constructor(yaml.resolver.BaseResolver.DEFAULT_MAPPING_TAG, _mapping)
    return yaml.load(text, Loader=_Strict) # noqa: S506


def git_commit(root):
    return _git(root, "rev-parse", "HEAD")


def dirty(root):
    return _git(root, "status", "--porcelain")


def project_entry(root, project_id):
    """The registered work entry for `project_id`, or a refusal string. Fail-closed on every
    identity question: unregistered, a product slug, or a non-project kind each name their
    own reason, because 'unknown id' three different ways is three different fixes."""
    # the CENTRAL safe-handle grammar before anything else: the id becomes a
    # path segment under work/<id>/runs, and every work tool now shares ONE rule for it
    ok, id_err = pg.safe_work_id(project_id)
    if not ok:
        return None, (f"not a safe project handle - {id_err}")
    if pg.kind_for(root, project_id) == "product":
        return None, (f"{project_id!r} is a PRODUCT - its runs are builds, and refreshes/ "
                      f"records those through the release path; this tool records PROJECT runs")
    for w in pg.work_entries(root):
        if isinstance(w, dict) and str(w.get("id") or "") == project_id:
            kind = str(w.get("kind") or "")
            if kind != "project":
                return None, (f"{project_id!r} is registered as kind {kind!r}, not project - "
                              f"a {kind or 'kindless entry'} owes its own obligations, not runs")
            return w, None
    return None, (f"{project_id!r} is not registered - add a `work:` entry with kind: project "
                  f"(products/registry.yaml documents the shape) before recording runs on it")


def run_errors(root, project_id, entry=None):
    """Everything standing between this project and a recordable run, in one list.

    `entry` may be passed by a caller that already resolved it - record() does, so the entry
    it validates and the entry it writes are ONE read."""
    if entry is None:
        entry, err = project_entry(root, project_id)
        if err:
            return [err]
    # ALL work-block errors, not a text-filtered subset (probe wave: filtering by id text let
    # an entry's own defect slip past when the message spelled it differently) - a registry
    # that does not validate blocks every run on it
    errors = list(pg.work_errors(root))
    cites = entry.get("cites_release") or []
    if not cites:
        errors.append("cites_release is empty - a run consumes an immutable release, and a "
                      "project citing nothing has no input to run over")
    for c in cites:
        if not (isinstance(c, dict) and c.get("build_id") and c.get("manifest_sha256")):
            errors.append(f"citation {c!r} does not pin build_id + manifest_sha256 - a run "
                          f"consumes an IMMUTABLE release, and an unpinned citation floats "
                          f"to whatever the pack publishes next")
    errors += sm.citation_errors(root, {"id": project_id, "cites_release": cites})
    # A RUN NEEDS ITS ANALYSIS PLAN: projects owe the
    # contract gate, and the protocol record IS that contract - registered, prespecified,
    # digest-bound. The project entry names it; the run refuses without it and the record
    # carries the prespecification digest, so a run cannot outlive the plan it claims.
    proto = str(entry.get("protocol") or "").strip()
    if not proto:
        errors.append("the project entry names no `protocol:` - a run without its registered "
                      "analysis plan is the contract gate unpaid; scaffold one "
                      "(protocol_record --new <id>) and declare it on the project entry")
    elif pg.kind_for(root, proto) != "protocol":
        errors.append(f"protocol {proto!r} is not a registered `kind: protocol` work entry")
    else:
        # THE PROTOCOL TOOL'S OWN VALIDATOR, wholesale (probe wave: requiring a file to exist
        # let a malformed or draft plan qualify a run). record_errors holds the record
        # complete, internally consistent, and FROZEN against its digest with amendments
        # accounted for; on top of that, a run consumes only a registered/amended plan -
        # never a draft nobody has frozen, never a closed protocol taking new runs.
        from rwd_tools import protocol_record as prot # noqa: PLC0415
        perrs = prot.record_errors(root, {"id": proto})
        errors += [f"protocol {proto}: {e}" for e in perrs]
        if not perrs:
            pdoc, _perr = pg.read_yaml(os.path.join(root, "work", proto, "PROTOCOL.yaml"))
            status = str((pdoc or {}).get("status") or "")
            if status not in ("registered", "amended"):
                errors.append(f"protocol {proto}: status is {status!r} - a run consumes a "
                              f"FROZEN plan (registered/amended), never a draft and never a "
                              f"closed protocol taking new runs")
            else:
                # PROTOCOL-AUTHORISED SCOPE: the plan's registry entry cites the
                # releases it reads; a run citing a (product, spec_version) the plan never
                # named is an analysis over data nobody prespecified.
                pentry = next((w for w in pg.work_entries(root)
                               if isinstance(w, dict)
                               and str(w.get("id") or "") == proto), {})
                scope, pinned = set(), {}
                for c in (pentry.get("cites_release") or []):
                    if not isinstance(c, dict):
                        continue
                    pair = (str(c.get("product") or ""), str(c.get("spec_version") or ""))
                    # HALF OR MALFORMED IS A DEFECT, NOT A BROAD GRANT: a
                    # pin is judged by PRESENCE and FORMAT, never truthiness - `build_id: 0`
                    # and `manifest_sha256: false` are malformed pins someone wrote, and
                    # reading them as "absent" widened scope through a type. Either both
                    # keys are absent (pack-level scope) or both hold a non-empty string
                    # build id and a 64-hex manifest digest.
                    has_b, has_m = "build_id" in c, "manifest_sha256" in c
                    if has_b or has_m:
                        b, mdig = c.get("build_id"), c.get("manifest_sha256")
                        if not (has_b and has_m and isinstance(b, str) and b.strip()
                                and isinstance(mdig, str)
                                and re.match(r"^[0-9a-f]{64}$", mdig)):
                            errors.append(f"protocol {proto} citation {pair} carries a "
                                          f"HALF or malformed pin (build_id={b!r}, "
                                          f"manifest_sha256={str(mdig)[:12]!r}) - both "
                                          f"fields as a non-empty id and a 64-hex digest, "
                                          f"or neither; a malformed pin must never read as "
                                          f"broad authorisation")
                            continue
                        scope.add(pair)
                        pinned.setdefault(pair, set()).add((b, mdig))
                    else:
                        scope.add(pair)
                for c in cites:
                    if not isinstance(c, dict):
                        continue
                    pair = (str(c.get("product") or ""), str(c.get("spec_version") or ""))
                    if pair not in scope:
                        errors.append(f"citation {pair} is outside protocol {proto}'s "
                                      f"prespecified scope {sorted(scope)} - a run may only "
                                      f"read the releases its frozen plan authorised")
                    elif pair in pinned and (str(c.get("build_id") or ""),
                                             str(c.get("manifest_sha256") or "")) \
                            not in pinned[pair]:
                        # EXACT PINS WHEN THE PLAN PINS: a protocol that named a
                        # build named THOSE bytes - another build of the same version is a
                        # different dataset wearing the authorised name
                        errors.append(f"citation {pair} pins build "
                                      f"{c.get('build_id')!r}, but protocol {proto} "
                                      f"prespecified exact build(s) "
                                      f"{sorted(b for b, _ in pinned[pair])} - the plan "
                                      f"authorised those bytes, not this build")
    return errors


def _protocol_evidence(root, proto):
    """{id, prespecification_sha256} for the run record - the digest through the protocol
    tool's OWN function, so this record and --digest can never disagree."""
    from rwd_tools import protocol_record as prot # noqa: PLC0415
    doc, err = pg.read_yaml(os.path.join(root, "work", proto, "PROTOCOL.yaml"))
    digest = prot.prespecification_digest(doc) if not err else None
    return {"id": proto, "prespecification_sha256": digest}


def _sha_file(path):
    h = hashlib.sha256()
    with open(path, "rb") as fh:
        for chunk in iter(lambda: fh.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def record(root, project_id, parameters, environment, outputs):
    """Validate everything, then write the run record. Returns the repo-relative path."""
    entry, err = project_entry(root, project_id) # resolved ONCE; validated and written as one
    if err:
        raise SystemExit(f"{project_id}: not recordable -\n  - {err}")
    errors = run_errors(root, project_id, entry=entry)
    if errors:
        raise SystemExit(f"{project_id}: not recordable -\n  - " + "\n  - ".join(errors))
    if not str(environment or "").strip():
        raise SystemExit(f"{project_id}: an undeclared runtime is a run nobody can reason "
                         f"about - state --environment")
    # argument validation before state validation: a bad --output is the CALLER's mistake and
    # should be named even when the tree also happens to be dirty
    if not outputs:
        raise SystemExit(f"{project_id}: a run with no recorded outputs is not evidence - "
                         f"pass at least one --output name=path (zero-output "
                         f"records were acceptable, and an evidence record proving nothing "
                         f"is worse than no record)")
    out_evidence = {}
    root_real = os.path.realpath(root)
    for name, path in outputs.items():
        if (os.path.realpath(path) + os.sep).startswith(root_real + os.sep):
            raise SystemExit(f"--output {name}={path} is inside the checkout - run outputs "
                             f"are data; the record carries their digests, never their bytes")
        if not os.path.isfile(path):
            raise SystemExit(f"--output {name}={path}: no such file - a digest of nothing "
                             f"is not evidence")
        out_evidence[name] = {"file": os.path.basename(path),
                              "path": os.path.realpath(path), # retrievable, not just a name
                              "sha256": _sha_file(path),
                              "bytes": os.path.getsize(path)}
    if dirty(root):
        raise SystemExit(f"{project_id}: the working tree is dirty - a run whose code digest "
                         f"points at uncommitted bytes is unreproducible by construction; "
                         f"commit first (the release path holds the same rule)")
    commit = git_commit(root)
    now = datetime.datetime.now(datetime.timezone.utc)
    rel = os.path.join("work", project_id, "runs",
                       f"{now.strftime('%Y%m%dT%H%M%S')}Z-{commit[:7]}.yaml")
    dest = os.path.join(root, rel)
    with open(os.path.join(root, "platform", "VERSION"), encoding="utf-8") as fh:
        platform_version = fh.read().strip()
    # THE AUTHORISED SET, EMBEDDED AND DIGESTED (probe wave: a hand-edit could substitute
    # another fully-pinned, currently-citable build and pass shape validation). The record
    # carries the citation set the registry authorised AT RECORD TIME plus its digest; the
    # validator holds cites_release equal to it, so a substitution must rewrite the
    # authorization block too - a two-place edit the committed record's git history shows.
    auth_cites = [dict(c) for c in (entry.get("cites_release") or []) if isinstance(c, dict)]
    auth_blob = json.dumps(auth_cites, sort_keys=True, separators=(",", ":"), default=str)
    rec = {"project": project_id,
           "recorded_at": now.strftime("%Y-%m-%dT%H:%M:%SZ"),
           "git_commit": commit,
           "platform_version": platform_version,
           "protocol": _protocol_evidence(root, str(entry.get("protocol") or "").strip()),
           "authorization": {
               "citations": auth_cites,
               "citations_sha256": hashlib.sha256(auth_blob.encode("utf-8")).hexdigest()},
           "cites_release": entry.get("cites_release"),
           "parameters": parameters,
           "environment": {"declared": environment,
                           "note": "a caller's declaration, not a capture - environment "
                                   "capture lands as the run layer matures"},
           "outputs": out_evidence}
    os.makedirs(os.path.dirname(dest), exist_ok=True)
    import yaml # noqa: PLC0415
    text = yaml.safe_dump(rec, sort_keys=False, allow_unicode=True) # serialize FIRST, so
    try: # the exclusive create
        fh = open(dest, "x", encoding="utf-8", newline="\n") # writes one finished
    except FileExistsError: # string, not a dump
        raise SystemExit(f"{rel} already exists - a run record is never overwritten; a "
                         f"re-run is a new record") from None
    with fh:
        fh.write(text)
    return rel


REQUIRED_RECORD_KEYS = ("project", "recorded_at", "git_commit", "platform_version",
                        "protocol", "authorization", "cites_release", "parameters",
                        "environment", "outputs")


def record_errors(root, verify_outputs=False, verify_citations=False):
    """Every committed run record's defects - the validator the layer was missing: a record is evidence only while its shape can be checked, and an edited or
    truncated one must be named, not trusted. With `verify_outputs`, every
    recorded output whose path is REACHABLE from this machine is re-hashed against its
    recorded digest - an artifact that moved on is named; an unreachable path is skipped,
    because outputs legitimately live on other machines and absence is not evidence of
    tampering."""
    import glob as _glob # noqa: PLC0415
    errors = []
    for path in sorted(_glob.glob(os.path.join(root, "work", "*", "runs", "*.yaml"))):
        rel = os.path.relpath(path, root)
        # THE ONE READER (governance's own catch on this very function): a parse failure or
        # a non-mapping root becomes a reported error, never a traceback out of a validator
        rec, err = pg.read_yaml(path)
        if err:
            errors.append(f"{rel}: {err}")
            continue
        if not isinstance(rec, dict):
            errors.append(f"{rel}: not a mapping")
            continue
        for k in REQUIRED_RECORD_KEYS:
            if k not in rec:
                errors.append(f"{rel}: missing {k!r}")
        if not re.match(r"^[0-9a-f]{40}$", str(rec.get("git_commit") or "")):
            errors.append(f"{rel}: git_commit is not a 40-hex commit")
        else:
            #...and it must be a commit THIS repository actually knows (probe wave: 40 hex
            # characters are a shape, not a history) - AND on the current branch's lineage
            # (probe wave: an existing commit on a side branch is a different history wearing
            # this repository's name)
            try:
                _git(root, "cat-file", "-e", str(rec["git_commit"]) + "^{commit}")
            except Exception: # noqa: BLE001 - the answer is no
                errors.append(f"{rel}: git_commit {str(rec['git_commit'])[:12]}... names no "
                              f"commit in this repository - the run's code digest points at "
                              f"history that does not exist here")
            else:
                try:
                    _git(root, "merge-base", "--is-ancestor", str(rec["git_commit"]), "HEAD")
                except Exception: # noqa: BLE001 - the answer is no
                    errors.append(f"{rel}: git_commit {str(rec['git_commit'])[:12]}... is "
                                  f"not an ancestor of the current HEAD - the run's code "
                                  f"is not on this branch's lineage")
                # THE FILENAME PINS THE COMMIT (probe wave: git_commit was record-controlled
                # - any compatible ancestor could replace the execution commit while the
                # filename carried the original seven characters unchecked)
                m_name = re.search(r"-([0-9a-f]{7})\.yaml$", os.path.basename(rel))
                if not m_name or m_name.group(1) != str(rec["git_commit"])[:7]:
                    errors.append(f"{rel}: the filename pins commit "
                                  f"{m_name.group(1) if m_name else '(none)'} but "
                                  f"git_commit says {str(rec['git_commit'])[:7]} - a "
                                  f"substituted execution commit, or a renamed record")
        # THE FIRST-ADDED BLOB IS THE RECORD: a run record is never overwritten
        # by design, so a committed record must still be byte-identical to the version git
        # first saw - any in-place edit, whatever it recomputed, is named here
        rel_posix = rel.replace(os.sep, "/")
        try:
            adds = _git(root, "log", "--diff-filter=A", "--format=%H", "--",
                        rel_posix).splitlines()
        except Exception: # noqa: BLE001 - no history, no anchor
            adds = []
        if adds:
            try:
                original = _git_raw(root, "show", f"{adds[-1]}:{rel_posix}")
            except Exception as e: # noqa: BLE001 - named, not trusted
                errors.append(f"{rel}: the first-committed form cannot be read ({e})")
            else:
                with open(path, encoding="utf-8", newline="") as fh:
                    current_text = fh.read().replace("\r\n", "\n")
                if current_text != original.replace("\r\n", "\n"):
                    errors.append(f"{rel}: the record differs from the version git FIRST "
                                  f"committed - a run record is never overwritten, so an "
                                  f"in-place edit is a forgery whatever it recomputed")
        # THE AUTHORISATION BINDING: cites_release must EQUAL the embedded
        # authorised set, and the set must hash to its own digest - a substituted build must
        # rewrite both places, which the committed record's git history shows
        auth = rec.get("authorization") if isinstance(rec.get("authorization"), dict) else {}
        auth_cites = auth.get("citations") if isinstance(auth.get("citations"), list) else None
        if auth_cites is None:
            errors.append(f"{rel}: authorization.citations is missing - the record does not "
                          f"carry the set it was authorised against")
        else:
            blob = json.dumps(auth_cites, sort_keys=True, separators=(",", ":"),
                              default=str)
            if hashlib.sha256(blob.encode("utf-8")).hexdigest() \
                    != str(auth.get("citations_sha256") or ""):
                errors.append(f"{rel}: authorization.citations does not hash to its own "
                              f"citations_sha256 - the authorised set was edited")
            if rec.get("cites_release") != auth_cites:
                errors.append(f"{rel}: cites_release does not match the authorization block "
                              f"- a substituted citation set, or a half-edited record")
        # THE INDEPENDENT ANCHOR (probe wave: the embedded digest was self-authenticated - an
        # editor could rewrite cites, the authorization block AND the checksum together).
        # The registry AS OF THE RECORDED COMMIT is history an editor cannot rewrite in
        # place: the record's citations must be what that commit's registry authorised.
        if re.match(r"^[0-9a-f]{40}$", str(rec.get("git_commit") or "")):
            try:
                hist_text = _git(root, "show",
                                 f"{rec['git_commit']}:products/registry.yaml")
                hreg = _strict_yaml(hist_text, f"{rel}: registry at recorded commit") or {}
            except Exception as e: # noqa: BLE001 - named, not trusted
                errors.append(f"{rel}: the registry at the recorded commit cannot be read "
                              f"({e}) - the authorisation has no independent anchor")
            else:
                if not isinstance(hreg, dict):
                    errors.append(f"{rel}: the registry at the recorded commit is not a "
                                  f"mapping - not a governed registry")
                    hreg = {}
                hentry = next((w for w in (hreg.get("work") or [])
                               if isinstance(w, dict)
                               and str(w.get("id") or "") == str(rec.get("project") or "")),
                              None)
                if hentry is None:
                    errors.append(f"{rel}: at the recorded commit, no work entry "
                                  f"{rec.get('project')!r} exists - the run claims an "
                                  f"authorisation that commit's registry does not hold")
                elif str(hentry.get("kind") or "") != "project":
                    # probe wave: a later conversion (request -> project) must not
                    # retro-qualify a run - the entry must have been a PROJECT at run time
                    errors.append(f"{rel}: at the recorded commit, {rec.get('project')!r} "
                                  f"was kind {hentry.get('kind')!r}, not a project - a "
                                  f"later conversion cannot retro-qualify a run")
                else:
                    if list(hentry.get("cites_release") or []) != rec.get("cites_release"):
                        errors.append(f"{rel}: cites_release does not match the registry "
                                      f"AT THE RECORDED COMMIT - authorisation is bound to "
                                      f"git history, never to the record's own checksum")
                    #...and the project-protocol ASSOCIATION at that commit too (audit
                    # 27): the plan the run pinned must be the plan the registry declared
                    # for this project when it ran
                    hproto = str(hentry.get("protocol") or "")
                    rproto = str((rec.get("protocol") or {}).get("id") or "") \
                        if isinstance(rec.get("protocol"), dict) else ""
                    if hproto != rproto:
                        errors.append(f"{rel}: at the recorded commit the project declared "
                                      f"protocol {hproto!r}, but the run pinned {rproto!r} "
                                      f"- the association is bound to history too")
        # the citations a record carries must at least be PINNED-SHAPED (probe wave: only
        # --verify-citations caught a hand-edited cites_release; the recorder never writes
        # an unpinned one, so meeting one is an edit, default-refused)
        rcites = rec.get("cites_release")
        if not isinstance(rcites, list) or not rcites:
            errors.append(f"{rel}: cites_release is empty or not a list - a run without a "
                          f"pinned input is not a run record")
        else:
            for i, c in enumerate(rcites):
                if not (isinstance(c, dict) and str(c.get("product") or "").strip()
                        and str(c.get("spec_version") or "").strip()
                        and str(c.get("build_id") or "").strip()
                        and re.match(r"^[0-9a-f]{64}$",
                                     str(c.get("manifest_sha256") or ""))):
                    errors.append(f"{rel}: cites_release[{i}] is not a fully pinned "
                                  f"citation (product, spec_version, build_id, 64-hex "
                                  f"manifest_sha256) - the recorder never writes less, so "
                                  f"less is an edit")
        outs = rec.get("outputs")
        if not isinstance(outs, dict) or not outs:
            errors.append(f"{rel}: outputs empty - a record proving nothing is not evidence")
        else:
            for name, o in outs.items():
                o_path = str((o or {}).get("path") or "")
                o_file = str((o or {}).get("file") or "")
                if not re.match(r"^[0-9a-f]{64}$", str((o or {}).get("sha256") or "")):
                    errors.append(f"{rel}: output {name!r} sha256 is not 64-hex")
                elif not isinstance((o or {}).get("bytes"), int) or o["bytes"] < 0:
                    # a clean validation error, never a conversion crash mid-verify
                    errors.append(f"{rel}: output {name!r} bytes is "
                                  f"{(o or {}).get('bytes')!r}, not a non-negative integer")
                elif not os.path.isabs(o_path) or o_file != os.path.basename(o_path):
                    # shape always: a relative path or a file/path disagreement
                    # is a record that cannot be retrieved by its own claim
                    errors.append(f"{rel}: output {name!r} path/file shape is malformed "
                                  f"(path={o_path!r}, file={o_file!r})")
                elif verify_outputs and os.path.isfile(o_path):
                    if os.path.getsize(o_path) != int((o or {}).get("bytes") or -1):
                        errors.append(f"{rel}: output {name!r} at {o_path} is "
                                      f"{os.path.getsize(o_path)} bytes, recorded "
                                      f"{o.get('bytes')} - the artifact moved on")
                    elif _sha_file(o_path) != str(o["sha256"]):
                        errors.append(f"{rel}: output {name!r} at {o_path} no longer "
                                      f"hashes to its recorded digest - the artifact moved "
                                      f"on after the run, and the record now describes "
                                      f"bytes that no longer exist there")
        # the pinned plan must be a REGISTERED FORM of its protocol: a null
        # digest is a run that never named its plan, and a digest outside the protocol's
        # ledger (registration + every amendment's covers_digest) is a plan the protocol
        # never was - an edited record, or an edited protocol hiding an amendment
        pr_block = rec.get("protocol") if isinstance(rec.get("protocol"), dict) else {}
        run_digest = str(pr_block.get("prespecification_sha256") or "")
        commit_ok = bool(re.match(r"^[0-9a-f]{40}$", str(rec.get("git_commit") or "")))
        if not re.match(r"^[0-9a-f]{64}$", run_digest):
            errors.append(f"{rel}: protocol.prespecification_sha256 is not 64-hex - the run "
                          f"does not pin the plan it claims")
        elif commit_ok:
            # THE LEDGER AS OF THE RECORDED COMMIT (probe wave: reading the CURRENT protocol
            # let a record reference an amendment that did not exist when it ran). The plan
            # the run pinned must have been a registered form of the protocol AT THAT TIME.
            pid = str(pr_block.get("id") or "")
            try:
                pdoc = _strict_yaml(
                    _git(root, "show", f"{rec['git_commit']}:work/{pid}/PROTOCOL.yaml"),
                    f"{rel}: protocol at recorded commit")
            except Exception as e: # noqa: BLE001 - named, not trusted
                errors.append(f"{rel}: protocol {pid!r} cannot be read AT THE RECORDED "
                              f"COMMIT ({e}) - the plan the run claims has no history there")
            else:
                if not isinstance(pdoc, dict):
                    errors.append(f"{rel}: protocol {pid!r} at the recorded commit is not "
                                  f"a mapping - not a governed record")
                elif str(pdoc.get("status") or "") not in ("registered", "amended"):
                    # probe wave: the ledger alone qualified a draft or closed plan - the
                    # protocol must have been FROZEN at run time, not merely hash-listed
                    errors.append(f"{rel}: protocol {pid!r} at the recorded commit had "
                                  f"status {pdoc.get('status')!r} - a run consumes a plan "
                                  f"that was registered/amended WHEN IT RAN")
                elif str(pdoc.get("protocol_id") or "") != pid:
                    errors.append(f"{rel}: protocol {pid!r} at the recorded commit names "
                                  f"protocol_id {pdoc.get('protocol_id')!r} - the record "
                                  f"and its registration disagree about identity")
                else:
                    ledger = {str(pdoc.get("prespecification_sha256") or "")}
                    ledger |= {str((a or {}).get("covers_digest") or "")
                               for a in (pdoc.get("amendments") or [])
                               if isinstance(a, dict)}
                    if run_digest not in ledger:
                        errors.append(f"{rel}: the run pins plan digest "
                                      f"{run_digest[:12]}... which was not the protocol's "
                                      f"registration nor any amendment AS OF the recorded "
                                      f"commit - the plan this run claims never was a "
                                      f"registered form of {pid!r} at run time")
        # the record and the registry must still AGREE: the project must remain
        # a registered kind:project, and its declared protocol must be the one this run
        # pinned - a swap in either direction is named, never silently absorbed
        run_proj = str(rec.get("project") or "")
        if pg.kind_for(root, run_proj) != "project":
            errors.append(f"{rel}: project {run_proj!r} is no longer a registered "
                          f"kind: project entry - the run's owner left the registry")
        else:
            wentry = next((w for w in pg.work_entries(root)
                           if isinstance(w, dict)
                           and str(w.get("id") or "") == run_proj), {})
            if str(wentry.get("protocol") or "") != str(pr_block.get("id") or ""):
                errors.append(f"{rel}: the run pinned protocol {pr_block.get('id')!r} but "
                              f"the project now declares "
                              f"{wentry.get('protocol')!r} - the record and the registry "
                              f"disagree about which plan governs this project")
        if verify_citations:
            # OPT-IN re-audit: re-ask whether every cited release is STILL
            # citable today. Opt-in deliberately - a historical record's citation was
            # valid at run time, and a pack that later moved does not falsify the run; it
            # falsifies re-USING it, which is what this flag answers.
            errors += [f"{rel}: (re-audit) {e}" for e in sm.citation_errors(
                root, {"id": str(rec.get("project") or ""),
                       "cites_release": rec.get("cites_release") or []})]
        proj = os.path.basename(os.path.dirname(os.path.dirname(path)))
        if rec.get("project") != proj:
            errors.append(f"{rel}: claims project {rec.get('project')!r} but lives under "
                          f"{proj!r} - a record must not wear another project's directory")
    # Run history is append-only: every record path git ever added must still exist.
    # Deleting or renaming a committed record is named here, never silently absorbed.
    # (Tamper-proof custody beyond git - signed CI receipts, object versioning - is a
    # production-side control and is documented as such, not half-built here.)
    try:
        added_ever = {ln.strip() for ln in _git(root, "log", "--diff-filter=A",
                                                "--name-only", "--format=", "--",
                                                "work/*/runs/*.yaml").splitlines()
                      if ln.strip()}
    except Exception: # noqa: BLE001 - no history, no sweep
        added_ever = set()
    for rp in sorted(added_ever):
        if not os.path.isfile(os.path.join(root, rp)):
            errors.append(f"{rp}: was committed as a run record and no longer exists - "
                          f"run history is append-only; a deleted or renamed record is "
                          f"named, never forgotten")
    return errors


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    ap.add_argument("project", nargs="?", default=None,
                    help="the registered work id (kind: project)")
    ap.add_argument("--check", action="store_true",
                    help="report whether a run could be recorded, and every reason it cannot")
    ap.add_argument("--validate-records", action="store_true",
                    help="validate every committed run record's shape and ledger")
    ap.add_argument("--verify-outputs", action="store_true",
                    help="with --validate-records: re-hash every recorded output whose path "
                         "is reachable from this machine")
    ap.add_argument("--verify-citations", action="store_true",
                    help="with --validate-records: re-ask whether every cited release is "
                         "STILL citable today - the re-use question, not the historical one")
    ap.add_argument("--record", action="store_true", help="validate and write the run record")
    ap.add_argument("--parameters", nargs="*", default=[], metavar="K=V",
                    help="the run's parameters, recorded verbatim")
    ap.add_argument("--environment", default="",
                    help="the declared runtime (cluster, DBR, package set) - recorded as a "
                         "declaration, honestly labelled as such")
    ap.add_argument("--output", action="append", default=[], metavar="NAME=PATH",
                    help="a produced file OUTSIDE the checkout; its sha256 + size enter the "
                         "record, its bytes never do")
    a = ap.parse_args(argv)
    if a.validate_records:
        import glob as _glob # noqa: PLC0415
        n = len(_glob.glob(os.path.join(ROOT, "work", "*", "runs", "*.yaml")))
        errs = record_errors(ROOT, verify_outputs=a.verify_outputs,
                             verify_citations=a.verify_citations)
        if errs:
            print(f"{len(errs)} run record defect(s) -")
            for e in errs:
                print(f"  - {e}")
            return 1
        # THE COUNT IS STATED: "every record validates" over an empty
        # ledger read as a pass; a scoped reader (uat.py) turns 0 record(s) into not_run.
        print(f"{n} record(s); every committed run record validates"
              + (" (reachable outputs re-hashed)" if a.verify_outputs else ""))
        return 0
    if not a.project:
        sys.exit("give a project id (or --validate-records)")
    if a.check:
        errors = run_errors(ROOT, a.project)
        # --check answers the same question --record asks (probe wave: it said 'recordable'
        # while recording would have refused on the dirty tree)
        if dirty(ROOT):                      # every reason, the dirty tree included (thirteenth pass, J6)
            errors = list(errors) + ["the working tree is dirty - recording will refuse until it is "
                                     "committed"]
        if errors:
            print(f"{a.project}: NOT recordable -")
            for e in errors:
                print(f"  - {e}")
            return 1
        print(f"{a.project}: recordable - the citation pins a publishable build and the "
              f"tree is clean (still needed at record time: --environment and >=1 --output)")
        return 0
    if a.record:
        if not a.environment.strip():
            sys.exit("--environment is required for --record: an undeclared runtime is a "
                     "run nobody can reason about")
        params = {}
        for kv in a.parameters:
            k, sep, v = kv.partition("=")
            if not sep or not k:
                sys.exit(f"--parameters {kv!r} is not K=V")
            params[k] = v
        outs = {}
        for kv in a.output:
            k, sep, v = kv.partition("=")
            if not sep or not k:
                sys.exit(f"--output {kv!r} is not NAME=PATH")
            outs[k] = v
        rel = record(ROOT, a.project, params, a.environment.strip(), outs)
        print(f"recorded {rel} - commit it; the run history is this directory's diff")
        return 0
    sys.exit("give --check or --record")


if __name__ == "__main__":
    from rwd_tools.console import use_utf8
    use_utf8()
    sys.exit(main())
