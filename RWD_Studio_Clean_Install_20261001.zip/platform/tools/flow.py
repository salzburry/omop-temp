#!/usr/bin/env python3
"""One product, one page, one button: the six gates in order, the current gate's blockers each with
its owner and its fix options, and what "proceed" means — assembled from `status.gates()` and
re-deriving nothing.

    python3 platform/tools/flow.py <pack>            the page, as text
    python3 platform/tools/flow.py <pack> --json     the same, as one object a portal renders

A person stood a product up in the portal, drafted a contract, and then had nowhere to go: the
sections were islands, the gates were words on a status page, and nothing said "this is blocked,
here is who owns it, here is what fixes it, then move on" (2026-09-05). This module is that spine.

WHAT IT IS NOT. It computes no gate state — every state and every blocker is `status.gates()`'s,
which is `releasable()`'s and the per-gate error functions' (status.py: "nothing re-derives"). It
performs no act: it names them. The act catalogue below classifies each governed act the way
governance/ACTIONS.yaml and the portal's write boundary do:

  read     a bounded check or report — runs anywhere a person may run checks
  write    a bounded tool write of a scaffold or a derived artefact (a form issued, a digest
           recorded, records scaffolded): a person's act at a page in a local demo, a command
           to run in a checkout otherwise; never an approval, an answer or a promotion
  person   an approval, an answer, a mapping confirmation, a promotion: typed and committed by
           the accountable person, named here with the file and the command that transcribes it,
           and offered by no button anywhere

stdlib + the tools it names.
"""
from __future__ import annotations

import argparse
from copy import deepcopy
import json
import os
import re
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
from rwd_services import workspace_root
from rwd_services import WorkflowIssue, WorkflowFinding, issue_of
ROOT = str(workspace_root(__file__))
from rwd_tools import product_gates as pg
from rwd_tools import status  # noqa: E402

READ, WRITE, PERSON = "read", "write", "person"
TOOLS = "platform/tools"
# The registers Gate 2 rests on, as contract_lint reads them: a missing one is named as missing.
REGISTERS = ("DECISIONS.md", "SPEC_QC_FINDINGS.md", "ENGINE_GAPS.md")


def production_pack(pack: str) -> bool:
    """Whether `pack` is a products/<family>/<slug>/<cut> path, the only kind with a receipt
    location (check_receipts refuses every other), so an act that reads receipts is offered only
    where one could exist."""
    parts = str(pack).replace("\\", "/").strip("/").split("/")
    return len(parts) == 4 and parts[0] == "products"


def _act(aid, label, kind, argv=None, path=None, note="", row=None):
    return {"id": aid, "label": label, "kind": kind, "argv": list(argv or []), "path": path or "",
            "note": note, "actions_row": row or ""}


def registration_state(pack_abs: str) -> dict:
    """What Gate 1's registration record says right now — read from the file, never assumed.

    A stood-up pack ALREADY carries source_refs.yaml (new_product.py writes it with the person's
    classification, the workbook path `TBD` and status pending), so "write the first
    source_refs.yaml" is not an act it can take: source_refs_init refuses to regenerate a
    registration a person has edited. The person who ran that act from the page was refused with
    nothing else offered (2026-09-05). The acts a stood-up pack CAN take, in order: supply the
    workbook and its path, record its digest, review it, register the extraction, seal.

    `exists` is whether a REGISTRATION exists, not whether a file does (2026-09-07): an empty
    source_refs.yaml, or one whose top level is not a mapping, was reported 'unregistered' by
    Gate 1 while the first write was withheld because the file was there, so the page named an act
    it did not offer. A file with no registration in it is no registration (`present` says the
    file is on disk, so the first write replaces it deliberately); a file with content that will
    not parse is `unreadable`, a repair act and nothing else, because nothing in it can be read.

    `unclassified_materials` carries each material's type beside its id, the workbook first, so
    the page can open the form that edits THAT material: the extraction's TODOs opened the
    workbook's access form, which reported the workbook already classified, forever."""
    from rwd_tools import source_manifest as sm                                            # noqa: PLC0415
    path = os.path.join(pack_abs, "source_refs.yaml")
    none = {"exists": False, "present": False, "unreadable": "", "material_id": "", "path_stated": False,
            "sha_stated": False, "reviewed": False, "unclassified": [], "unclassified_materials": []}
    if not os.path.isfile(path):
        return dict(none)
    try:
        with open(path, "rb") as fh:
            raw = fh.read()
    except OSError as e:
        return dict(none, present=True, unreadable=str(e))
    if not raw.strip():
        return dict(none, present=True)
    try:
        from engine.strict_yaml import strict_load                         # noqa: PLC0415 — the one governed loader
        doc = strict_load(raw.decode("utf-8"))
    except Exception as e:                                                  # noqa: BLE001 — every parse failure is the same answer
        said = " ".join(ln.strip() for ln in str(e).splitlines() if ln.strip())
        return dict(none, present=True, unreadable=said[:200] or type(e).__name__)
    if not isinstance(doc, dict):
        return dict(none, present=True)
    try:
        spec = sm.authoritative(pack_abs)
    except Exception:                                                       # noqa: BLE001 — unreadable reads as unstated
        spec = None
    if not spec:
        return dict(none, exists=True, present=True)
    link = str(spec.get("path_or_link") or "").strip()
    try:
        mats = sm.materials(pack_abs) or []
    except Exception:                                                       # noqa: BLE001
        mats = []
    todo = [m for m in mats if isinstance(m, dict)
            and any(pg.unstated(str(m.get(f) or "")) or str(m.get(f) or "").upper().startswith("TODO")
                    for f in ("ai_classification", "classified_by", "classified_date"))]
    todo.sort(key=lambda m: 0 if m.get("material_type") == sm.PROGRAM_SPEC else 1)
    unclassified = [str(m.get("material_id") or "?") for m in todo]
    return {"exists": True, "present": True, "unreadable": "", "material_id": str(spec.get("material_id") or ""),
            "unclassified": unclassified,
            "unclassified_materials": [{"material_id": str(m.get("material_id") or "?"), "material_type": str(m.get("material_type") or "")}
                                       for m in todo],
            "path_stated": bool(link) and not pg.unstated(link) and not link.upper().startswith("TBD"),
            "sha_stated": bool(str(spec.get("sha256") or "").strip()) and not pg.unstated(str(spec.get("sha256") or "")),
            "reviewed": str(spec.get("status") or "") == sm.REVIEWED,
            "review_complete": (str(spec.get("status") or "") == sm.REVIEWED
                                and not any(sm.field_unstated(spec, field) for field in sm.APPROVAL_FIELDS + sm.POLICY_FIELDS)
                                and not sm.bad_date(spec.get("approval_date"))
                                and not sm.not_a_person(spec.get("approved_by")))}


def gate_state(pack_abs: str) -> dict:
    """What the pack's files say about the acts Gates 2-4 offer — read, never assumed, so an act the
    files show done is not offered again: the registers present, the maturity claims as they
    stand, the ehr tolerances ruled, the Gate 3 report present."""
    handoff = os.path.join(pack_abs, "handoff")
    m = pg.maturity(pack_abs) if os.path.isdir(pack_abs) else {"contract": "not_started", "configuration": "not_started"}
    cfg, _err = pg.read_yaml(os.path.join(pack_abs, "config", "data_product.yaml"))
    qc = cfg.get("qc") if isinstance(cfg, dict) else {}
    thr = qc.get("source_thresholds") if isinstance(qc, dict) else {}
    thr = thr if isinstance(thr, dict) else {}
    link = thr.get("linkage") or {}
    settled = False
    try:
        from rwd_tools import contract_lint as cl                                          # noqa: PLC0415
        with open(os.path.join(handoff, "FUNCTIONAL_CONTRACT.md"), encoding="utf-8") as fh:
            settled = any(cl._kv(cl._inline(b, "status"), "requirement") == "approved" for b in cl.records(fh.read()))
    except Exception:                                                       # noqa: BLE001 — no contract, nothing settled
        settled = False
    # THE THREE REGISTERS THE LINT READS (2026-09-07): the demo pack's Gate 2 next step was a lint
    # that failed on a missing handoff/ENGINE_GAPS.md, and no act named that register, so the
    # register-creation form could not offer it. contract_lint's floor check names all three.
    return {"registers_missing": [r for r in REGISTERS if not os.path.isfile(os.path.join(handoff, r))],
            "settled": settled,
            "contract": str(m.get("contract") or "not_started"), "configuration": str(m.get("configuration") or "not_started"),
            "tolerances_ruled": thr.get("max_parse_loss_rate") is not None and isinstance(link, dict) and any(v is not None for v in link.values()),
            "report": os.path.isfile(os.path.join(handoff, "SOURCE_VERDICTS.md"))}


def deployment_commands(root, pack):
    """Name only generated jobs belonging to this production product; never invent a job."""
    parts = pack.replace("\\", "/").strip("/").split("/")
    empty = {"build": [], "publish": [], "note": "This fixture or draft has no production job. Follow products/OPERATIONS.md with your data expert when standing up a governed production product."}
    if len(parts) != 4 or parts[0] != "products":
        return empty
    _, family, slug, cut = parts
    doc, _error = pg.read_yaml(os.path.join(root, "resources", "products.yml"))
    resources = doc.get("resources") if isinstance(doc, dict) else None
    jobs = resources.get("jobs") if isinstance(resources, dict) else None
    if not isinstance(jobs, dict):
        return dict(empty, note="No readable generated product jobs exist. Your data expert must complete product registration and regenerate resources/products.yml with platform/tools/bundle_products.py.")
    out = {"build": [], "publish": [], "note": f"Before running, your data expert must deploy the governed tree with spec_version={cut} and the reviewed delivery settings for {slug}. The run command uses those deployed parameters; follow products/OPERATIONS.md."}
    for mode in ("build", "publish"):
        name = f"rwdp_{mode}_{slug}"
        job = jobs.get(name)
        tags = job.get("tags") if isinstance(job, dict) else None
        if isinstance(tags, dict) and tags.get("product") == slug and tags.get("family", "oncology") == family:
            out[mode] = ["databricks", "bundle", "run", name, "-t", "prod"]
            if mode == "publish":
                out[mode] += ["--notebook-params", "promote_build_id=<build_id>"]
    if not out["build"] or not out["publish"]:
        out["note"] += " A required generated job is missing; have your data expert regenerate the bundle before running it."
    return out


def acts(pack: str, root: str | None = None, *, signed: bool | None = None) -> dict:
    """{gate: [act, ...]} — the governed acts that move each gate, in the order a person takes them.
    `argv` is relative to the checkout root and starts with the tool path; `actions_row` names the
    governance/ACTIONS.yaml row a write or a person's act is declared under. Gate 1's list is
    built from the registration as it stands (registration_state): an act the pack cannot take
    is not offered.

    `signed` is whether the registration record's approvals are authenticated, as status.gates()
    reports it (flow() passes it; nothing here re-derives it, and asking approval_identity from
    every page that lists the acts cost two seconds a call). A recorded review is offered for
    correction while the record is unsigned (walk UC1-05, 2026-09-07): once a wrong reviewer name
    was saved the person saw only the commit step, because the review act was withheld the moment
    the review was complete. `None` (unknown) keeps the correction reachable; a signed record
    withholds it, and the tools' own refusals stand after the signature."""
    sm, dr, cr, cs, cl = (f"{TOOLS}/source_manifest.py", f"{TOOLS}/decision_record.py", f"{TOOLS}/contract_record.py",
                          f"{TOOLS}/contract_scaffold.py", f"{TOOLS}/contract_lint.py")
    reg = registration_state(os.path.join(root or ROOT, pack))
    mid = reg["material_id"] or "<material_id>"
    gate1 = [_act("g1_check", "Check the registration (Gate 1)", READ, [sm, pack, "--check"])]
    if reg["unreadable"]:
        # A file with content that will not parse: nothing in it can be read, so nothing else is
        # offered. Regenerating it would discard whatever a person wrote there.
        gate1.append(_act("g1_repair", "Repair source_refs.yaml: the file has content but cannot be read as YAML", PERSON,
                          path=f"{pack}/source_refs.yaml",
                          note="the file is not regenerated because it may carry a person's registration; open it and correct the "
                               "line the parser names, then check again. The parser said: " + reg["unreadable"],
                          row="register_or_revise_material"))
    elif not reg["exists"]:
        gate1.append(_act("g1_init", "Write the first source_refs.yaml from your classification", WRITE,
                          [f"{TOOLS}/source_refs_init.py", pack, "--ai-classification", "<class>", "--classified-by", "<you>", "--classified-date", "<YYYY-MM-DD>"],
                          note=("the three values are yours to supply" if not reg["present"] else
                                "the three values are yours to supply; the existing source_refs.yaml holds no registration "
                                "(it is empty or not a mapping) and is replaced by this write"),
                          row="register_or_revise_material"))
    elif not reg["material_id"]:
        # A mapping with content but no program_spec material: a registration a person started and
        # nothing here can act on until it names the specification; the other acts would carry a
        # placeholder material id.
        gate1.append(_act("g1_repair", "Repair source_refs.yaml: it names no program_spec material", PERSON,
                          path=f"{pack}/source_refs.yaml",
                          note="add the source_materials entry for the program specification (material_type: program_spec) "
                               "with your AI classification, name and date; see platform/TUMOR_TEMPLATE/source_refs.yaml",
                          row="register_or_revise_material"))
    else:
        if not reg["path_stated"]:
            gate1.append(_act("g1_workbook", "Supply the approved workbook: put it in prog_spec/ and set its path_or_link on the program_spec material", PERSON,
                              path=f"{pack}/source_refs.yaml",
                              note="the stand-up wrote the registration with the path TBD; source_refs_init does not regenerate a registration a person has edited",
                              row="register_or_revise_material"))
        if not reg["sha_stated"]:
            gate1.append(_act("g1_digest", "Record the material's digest (fills an unstated sha256 only)", WRITE,
                              [sm, pack, "--record-digest", mid], row="register_or_revise_material"))
        if reg["unclassified"]:
            # THE ACT NAMES ITS MATERIAL (2026-09-07): the page opens the form that edits it, the
            # workbook's access form or the extraction's review form, so answering the extraction's
            # TODOs no longer reopens a workbook form that has nothing left to record.
            first = reg["unclassified_materials"][0]
            classify = _act("g1_classify", f"Answer the TODOs a registration left on {', '.join(reg['unclassified'])}: ai_classification, "
                                           f"classified_by, classified_date, then approved_by, approval_date and status: reviewed", PERSON,
                            path=f"{pack}/source_refs.yaml",
                            note="the classification is one person's judgment about what AI may read; no tool fills it",
                            row="register_or_revise_material")
            classify["material_id"], classify["material_type"] = first["material_id"], first["material_type"]
            gate1.append(classify)
        if not reg["reviewed"] or not reg.get("review_complete", reg["reviewed"]):
            gate1.append(_act("g1_review", "Approve the material: status reviewed, document id, revision, approver, date", PERSON,
                              path=f"{pack}/source_refs.yaml", note="the approver types these; no tool fills them", row="register_or_revise_material"))
        elif signed is not True:
            # A RECORDED REVIEW CAN STILL BE CORRECTED UNTIL IT IS SIGNED (walk UC1-05, 2026-09-07):
            # the review act was withheld as soon as the review was complete, so a wrong reviewer
            # name saved from the form could not be corrected from the page. The same act, offered
            # as a correction; the signature binds the record as it stands, and after it the tools'
            # own refusals apply.
            correction = _act("g1_review", "Correct the recorded review: reviewer, review date, document id, revision, data refresh, QC reference",
                              PERSON, path=f"{pack}/source_refs.yaml",
                              note="the review is recorded and can still be corrected until it is signed; after the signature a "
                                   "correction is a new review over the changed record. The reviewer types these; no tool fills them",
                              row="register_or_revise_material")
            correction["recorded"] = True
            gate1.append(correction)
        if os.path.isfile(os.path.join(root or ROOT, pack, "spec_pipeline", "pipeline.conf")):
            gate1.append(_act("g1_extract", "Prepare the specification extraction and review outline", WRITE,
                              [f"{TOOLS}/run_spec_pipeline.py", pack],
                              path=f"{pack}/spec_pipeline/out/",
                              note="regenerates deterministic extraction, findings, coverage and draft artifacts; it does not approve the source or replace the authored contract",
                              row="regenerate_derived_artifact"))
        gate1.append(_act("g1_register_extraction", "Register the AI extraction (derived fields computed; five fields left for you)", WRITE,
                          [sm, "--register-ai-extraction", pack, "--write"], row="register_or_revise_material"))
        gate1.append(_act("g1_commit", "Verify the review signature and enrolled reviewer identity", PERSON,
                          path=f"{pack}/source_refs.yaml",
                          note="If the exact review already has a verified personal Git signature, open Reviewer identity enrollment "
                               "for a different authenticated administrator to complete its principal/key binding, then Check again. "
                               "Only unsigned or changed reviews need another personal signature. A plain history commit cannot repair missing enrollment.",
                          row="register_or_revise_material"))
        gate1.append(_act("g1_seal", "Seal the registration in the ledger", WRITE, [sm, pack, "--record-event", mid],
                          note="the actor is transcribed from the record's own committed attribution", row="register_or_revise_material"))
    # Gate 3's apply act exists only once there is a report to apply — "apply what?" otherwise —
    # and Gate 2's, 4's and 6's menus each carry the commit that binds a typed approval to its
    # author, the raise of the maturity claim, and the person's acts the walkthrough found
    # unnamed (2026-09-05): the two registers, the settled requirement, the two Gate 3
    # judgments, the ehr tolerances, the recorded validation.
    pack_abs = os.path.join(root or ROOT, pack)
    st = gate_state(pack_abs)
    ma = f"{pack}/handoff/MATURITY.yaml"
    fc = f"{pack}/handoff/FUNCTIONAL_CONTRACT.md"
    deployed = deployment_commands(root or ROOT, pack)
    namespace = pack.replace("\\", "/").split("/", 1)[0]
    registry = f"{namespace if namespace in ('products', 'fixtures') else 'products'}/registry.yaml"
    has_extraction = os.path.isfile(os.path.join(pack_abs, "spec_pipeline", "out", "extracted.json"))
    extract_action = dict(_act("g2_refresh_extraction" if has_extraction else "g2_extract",
                              "Regenerate the extraction and review outline" if has_extraction else "Prepare the specification extraction first",
                              WRITE, [f"{TOOLS}/run_spec_pipeline.py", pack],
                              path=f"{pack}/spec_pipeline/out/", row="regenerate_derived_artifact",
                              note="updates generated artifacts for the registered source; a changed extraction reopens any review bound to its previous bytes"),
                          copy_id="g1_extract")

    def _commit(n, what, path):
        return _act(f"g{n}_commit", f"Commit {what}: an approval binds to the commit whose diff wrote it", PERSON, path=path,
                    note="git add the file and commit it as yourself; sign the commit with the review key registered in "
                         "governance/allowed_signers.yaml. New approvals cannot be added to the historical baseline; "
                         "approval_identity.py --check reports any missing authentication",
                    row="register_or_revise_material" if n == 1 else None)

    gate3 = [
        _act("g3_structure", "Check the contract's source declarations", READ, [f"{TOOLS}/source_check.py", pack, "--structure-only", "--check"]),
        _act("g3_registry", f"Name the vendor: register the pack ({registry}) so its evidence route is known", PERSON,
             path=registry, row="stand_up_product"),
    ]
    try:
        reports = pg.verdict_paths(pack_abs)
    except (TypeError, ValueError, AttributeError):
        reports = [(None, pg.VERDICTS)]  # malformed configuration is reported by Gate 4
    for index, (member, report_path) in enumerate(reports):
        suffix = f"_{index + 1}" if index else ""
        member_args = ["--union-member", member] if member else []
        label_suffix = f" for {member}" if member else ""
        actions = [
            _act("g3_run" + suffix, "Prepare the delivered source report" + label_suffix, PERSON,
                 argv=[f"{TOOLS}/source_check.py", pack, "--profile", "<profile.tsv>", "--complete",
                       *member_args, "--schema-validation", "<SCHEMA_VALIDATION.json>",
                       "--preflight", "<source_qc.json>", "--out", f"{pack}/{report_path}"],
                 path=f"{pack}/{report_path}",
                 note="Engineering runs this in the approved data environment using this delivery's complete profile, schema-validation report and source-QC evidence. "
                      "The --complete declaration is valid only for a complete profile. Re-run after the mappings or delivery configuration change."),
            _act("g3_confirm" + suffix, "Confirm mappings and review the source report" + label_suffix, PERSON,
                 path=f"{pack}/{report_path}", row="apply_source_verdicts"),
        ]
        if os.path.isfile(os.path.join(pack_abs, report_path)):
            actions.append(_act("g3_apply" + suffix, "Apply the committed source findings" + label_suffix, WRITE,
                                [cr, "--apply-verdicts", "--product", pack, *member_args],
                                path=f"{pack}/{report_path}", row="apply_source_verdicts"))
        for action in actions:
            action["copy_id"] = action["id"].removesuffix(suffix) if suffix else action["id"]
            action["member"] = member
        gate3 += actions
    gate3 += [
        _act("g3_judge", "Judge what no tool can: on each record set dictionary_check (passed, or not_available when the feed "
                         "ships no dictionary) and data_profile_check: accepted", PERSON, path=fc,
             note="the profile is accepted by the person who read it; a record left not_run has no Gate 3 evidence"),
        _commit(3, "the report(s) and the judgments", f"{pack}/{reports[0][1]}"),
    ]
    return {
        1: gate1,
        2: [
            *([extract_action] if not has_extraction else []),
            _act("g2_scaffold", "Scaffold one record per specification row (the spec's own words, judgment fields TODO)", WRITE,
                 [cs, f"{pack}/spec_pipeline/out/extracted.json", "--product", pack, "--records", f"{pack}/spec_pipeline/out/SCAFFOLDED_RECORDS.md"],
                 path=f"{pack}/spec_pipeline/out/SCAFFOLDED_RECORDS.md",
                 note="writes a generated review outline; existing handoff/FUNCTIONAL_CONTRACT.md is preserved. Use the record drafting workflow to apply reviewed interpretations",
                 row="scaffold_records"),
            *([extract_action] if has_extraction else []),
            _act("g2_draft", "Draft or revise one record from its specification row", PERSON,
                 argv=[cr, "<judgment.yaml>", "--product", pack, "--item", "<domain:row>", "--apply"],
                 note="the judgment is the drafter's; the spec fields are supplied from the row", row="draft_or_revise_contract_record"),
            _act("g2_lint", "Lint the contract (every invariant)", READ, [cl, pack]),
            _act("g2_questions", "Rank the open decisions by what each unblocks (rewrites SCIENCE_QUESTIONS.md)", WRITE,
                 [f"{TOOLS}/decision_report.py", pack], row="regenerate_derived_artifact"),
            _act("g2_packet", "Read the packet for the person who must answer", READ, [f"{TOOLS}/decision_packet.py", pack, "--text"]),
            _act("g2_forms", "Issue one answer form per open decision", WRITE, [dr, pack, "--forms"], row="issue_decision_forms"),
            _act("g2_answer", "Enter the scientific decision, decision maker and date in its issued form", PERSON,
                 path=f"{pack}/handoff/decision_answers/", note="Questions to answer can capture the person's literal entries locally; the resulting decision register still requires authenticated review", row="record_decision_answer"),
            _act("g2_apply", "Validate and transcribe the completed answers into the register", PERSON,
                 argv=[dr, pack, "--apply"], note="Questions to answer saves validated forms and register updates together locally. The technical command does not itself authenticate an answer; record the resulting register through the named review process", row="record_decision_answer"),
            *([_act("g2_registers", "Write the register(s) Gate 2 rests on: " + ", ".join("handoff/" + r for r in st["registers_missing"]), PERSON,
                    path=f"{pack}/handoff/{st['registers_missing'][0]}",
                    note="copy the canonical header from platform/TUMOR_TEMPLATE/handoff/; a header with no rows beneath it says "
                         "nothing is open — a missing file says nothing at all, and the gate refuses it")]
              if st["registers_missing"] else []),
            *([_act("g2_settle", "Settle each record's requirement: requirement: approved on the records the approval will cover", PERSON,
                    path=fc, note="the requirement axis is the scientific owner's word that the record asks for the right thing; "
                                  "Gate 5 validates only settled requirements")]
              if not st["settled"] else []),
            _act("g2_approve", "Approve the contract: CONTRACT_APPROVAL.yaml with the five digests, typed and committed", PERSON,
                 path=f"{pack}/handoff/CONTRACT_APPROVAL.yaml", row="approve_contract",
                 note="approved_extraction_sha256, approved_contract_sha256 (the requirement content: product_gates.requirements_sha256), "
                      "approved_coverage_sha256, approved_decisions_sha256, approved_spec_qc_sha256; approved_by, approval_date, "
                      "spec_qc_reviewed_by, spec_qc_review_date. Re-sign it whenever a digest moved after the approval"),
            *([_act("g2_maturity", "Raise the claim: contract: approved in MATURITY.yaml, once the form is committed and the lint is clean", PERSON,
                    path=ma, note="a claim, not evidence: the gate reads the form and the registers beside it")]
              if st["contract"] != "approved" else []),
            _commit(2, "the registers and the approval", f"{pack}/handoff/CONTRACT_APPROVAL.yaml"),
        ],
        3: gate3,
        4: [
            _act("g4_validate", "Check the configuration while drafting (placeholders allowed)", READ, ["platform/engine/validate.py", pack]),
            _act("g4_validate_strict", "Check configuration structure (strict)", READ, ["platform/engine/validate.py", pack, "--strict"]),
            _act("g4_review", "Review each rule: spec words, contract interpretation, the YAML that runs", READ, [f"{TOOLS}/rule_review.py", pack]),
            _act("g4_binding", "Check the contract ↔ configuration binding", READ, [f"{TOOLS}/contract_binding.py", pack, "--check", "--complete"]),
            _act("g4_author", "Author config/, variables/ and codelists/; set each graph file status from scaffold to active", PERSON,
                 path=f"{pack}/config/data_product.yaml", note="every REPLACE_ME is a scientific value only a scientist supplies; "
                                                                "then claim configuration: draft in MATURITY.yaml"),
            _act("g4_publication", "Review which columns the product delivers", PERSON,
                 path=f"{pack}/config/data_product.yaml",
                 note="Review publication.columns using the delivered-column selector against the contract's published outputs. "
                      "Keep patientid, index_date and the engine provenance stamps; exclude internal helpers explicitly. "
                      "A promised output must be implemented and included, or its requirement must be reviewed and approved again. "
                      "Run the complete binding check, re-take source evidence over the changed configuration, and review approval again."),
            *([_act("g4_tolerances", "Rule the ehr pack's tolerances: qc.source_thresholds.max_parse_loss_rate and "
                                     "qc.source_thresholds.linkage.max_orphan_rate in config/data_product.yaml", PERSON,
                    path=f"{pack}/config/data_product.yaml",
                    note="the numbers are the pack's own ruling; an approved configuration must state the loss and the orphaning it "
                         "stands behind. A root-config edit moves the delivery digest: re-take the Gate 3 report over it")]
              if not st["tolerances_ruled"] else []),
            _act("g4_definitions", "Name the analytical definitions this configuration signs: the register entries to complete", READ,
                 [f"{TOOLS}/definition_registry.py", "--propose", pack],
                 note="prints the governance/DEFINITIONS.yaml entries whose signature the pack signs; writes nothing"),
            _act("g4_register", "Register each definition: id, UMLS concept, your name and date over the printed signature", PERSON,
                 path="governance/DEFINITIONS.yaml", note="minted once; a changed rule is a new version naming what it supersedes",
                 row="register_definition"),
            _act("g4_implementations", "Draft this dataset's implementation claims from what the configuration signs", READ,
                 [f"{TOOLS}/definition_registry.py", "--propose-implementations", pack],
                 note="prints a config/implementations.yaml draft; the dataset label, roles and review are yours"),
            _act("g4_claim", "Claim, per variable, the registered definition this dataset implements, and sign the review", PERSON,
                 path=f"{pack}/config/implementations.yaml", note="a claim the register or the contract refuses binds nothing",
                 row="claim_implementation"),
            _act("g4_approve", "Approve the configuration: CONFIGURATION_APPROVAL.yaml over the active bundle's digest", PERSON,
                 path=f"{pack}/handoff/CONFIGURATION_APPROVAL.yaml",
                 note="approved_by and technically_reviewed_by are two people; approved_configuration_bundle_sha256 "
                      "(product_gates.config_bundle_sha256) and approved_against_contract_sha256 (the requirement content). "
                      "Re-sign it whenever the bundle or the contract moved after the approval"),
            *([_act("g4_maturity", "Raise the claim in MATURITY.yaml: configuration: draft once authored, approved once the form is committed",
                    PERSON, path=ma, note="a claim, not evidence: the gate reads the form, the tolerances and the binding beside it")]
              if st["configuration"] != "approved" else []),
            _commit(4, "the configuration and its approval", f"{pack}/handoff/CONFIGURATION_APPROVAL.yaml"),
        ],
        5: [
            _act("g5_smoke", "Build on synthetic sources (local Spark): proves the configuration assembles, nothing about the feed", READ,
                 [f"{TOOLS}/local_smoke.py", pack], note="a bounded local run that writes nothing into the pack; where doctor has verified Spark"),
            _act("g5_readiness", "Pilot readiness", READ, [f"{TOOLS}/pilot_readiness.py", pack]),
            _act("g5_build", "Stage a candidate on Databricks: the build job (stages and stops; publishes nothing)", PERSON,
                 argv=deployed["build"], path="products/OPERATIONS.md",
                 note=deployed["note"] + " The build's own refresh receipt is recorded after the governed run."),
            _act("g5_record", "Record the validation on each approved record: implementation: implemented and validation: passed_live "
                              "(FUNCTIONAL_CONTRACT.md status axes), from the build's own evidence", PERSON, path=fc,
                 note="passed_live is the person's word over a live build's evidence; a synthetic build reaches passed_test at most"),
            _act("g5_validate", "Validate the candidate: validated_by and validation_date in RELEASE_APPROVAL.yaml", PERSON,
                 path=f"{pack}/handoff/RELEASE_APPROVAL.yaml"),
        ],
        6: [
            _act("g6_approve", "Approve the release: RELEASE_APPROVAL.yaml naming one build id and one manifest digest", PERSON,
                 path=f"{pack}/handoff/RELEASE_APPROVAL.yaml", row="publish_release",
                 note="approved_by, approval_date, validated_by, validation_date, approved_build_id, approved_manifest_sha256"),
            _act("g6_promote", "Promote exactly those staged bytes: the publish job with promote_build_id", PERSON,
                 argv=deployed["publish"], path="products/OPERATIONS.md", note=deployed["note"], row="publish_release"),
            _act("g6_seal", "Record the release approval as a ledger event (the form gains its object_uuid)", WRITE,
                 [f"{TOOLS}/approval_record.py", "--record-event", pack, "--form", "release"], row="record_approval_event",
                 note="runs the Gate 6 check first; a form the gate refuses is not an act to record"),
            _act("g6_countersign", "Countersign the sealed approval with your registered key (governance/SIGNING_KEYS.yaml)", PERSON,
                 argv=[f"{TOOLS}/approval_record.py", "--countersign", pack, "--form", "release", "--key-id", "<key id>", "--private-key", "<file outside the checkout>"],
                 row="attest_approval", note="authenticated is derived from the verified signature, never typed"),
            _commit(6, "the approval, its seal and the countersignature", f"{pack}/handoff/RELEASE_APPROVAL.yaml"),
            # ONLY WHERE A RECEIPT COULD EXIST (2026-09-07): check_receipts refuses every pack that is
            # not products/<family>/<slug>/<cut>, so on a fixture or a sandbox pack this read was
            # offered as ready and always failed. An act the pack cannot take is not offered.
            *([_act("g6_receipt", "Check this product's committed receipts", READ, [f"{TOOLS}/flow.py", pack, "--check-receipts"])]
              if production_pack(pack) else []),
        ],
    }


# Text-only compatibility for pre-protocol callers. Current status findings are
# always typed and use _issue_actions; diagnostic wording cannot choose a route.
_LEGACY_FIRST = (
    # Gate 1 routes by what the registration still lacks: with no file, the first write; with the
    # path TBD, supplying the workbook; then the digest, then the review — each offered only when
    # the file says it is the next thing (registration_state), so the menu's order IS the route
    ("source is unregistered", ("g1_init", "g1_repair")), ("source is provisional", ("g1_workbook",)),
    ("is not readable YAML", ("g1_repair",)), ("lists no source_materials", ("g1_repair",)),
    ("requires `ai_classification`", ("g1_classify",)), ("requires `classified_by`", ("g1_classify",)),
    ("requires `classified_date`", ("g1_classify",)),
    ("status:reviewed requires", ("g1_review",)), ("unsupported status", ("g1_review",)),
    ("moved past its ledger", ("g1_seal",)), ("holds no lifecycle event", ("g1_seal",)),
    # a typed approval that no commit's diff wrote: the commit, at whichever gate the form belongs to
    ("is not authenticated", ("g1_commit", "g2_commit", "g3_commit", "g4_commit", "g6_commit")),
    # Gate 2 — the walkthrough's route: lint, the registers, the settled requirement, the form, the claim
    ("requires handoff/DECISIONS.md", ("g2_registers", "g2_commit")), ("requires handoff/SPEC_QC_FINDINGS.md", ("g2_registers", "g2_commit")),
    ("has no findings table", ("g2_registers",)), ("handoff/DECISIONS.md is missing", ("g2_registers",)),
    ("handoff/ENGINE_GAPS.md is missing", ("g2_registers",)), ("requires handoff/ENGINE_GAPS.md", ("g2_registers", "g2_commit")),
    ("in handoff/CONTRACT_APPROVAL.yaml", ("g2_approve", "g2_commit")),
    ("the spec was re-extracted after the approval", ("g2_approve",)), ("the contract's requirements were edited after the approval", ("g2_approve",)),
    ("the coverage report changed after the approval", ("g2_approve",)), ("the decision register changed after the approval", ("g2_approve",)),
    ("the specification-QC register changed after the approval", ("g2_approve",)),
    ("no record has an approved requirement", ("g2_settle", "g2_approve")),
    ("contract is not_started", ("g2_extract", "g2_scaffold")),
    ("contract is draft", ("g2_lint", "g2_registers", "g2_settle", "g2_approve", "g2_maturity", "g2_commit")),
    ("contract is coverage_complete", ("g2_forms", "g2_settle", "g2_approve", "g2_maturity", "g2_commit")),
    ("answer the open decisions", ("g2_forms",)), ("open decision", ("g2_forms",)),
    # Gate 3 — the two judgments before the coarse line that quotes them; apply before run once a report exists
    ("dictionary_check:not_run", ("g3_judge", "g3_commit")), ("data_profile_check:not_run", ("g3_judge", "g3_commit")),
    ("evidence route undecided", ("g3_registry",)),
    ("status.source:unverified", ("g3_apply",)),                       # withheld with no report: the next needle names the run
    ("have no Gate 3 evidence", ("g3_run", "g3_confirm")), ("no handoff/SOURCE_VERDICTS.md", ("g3_run",)),
    ("moved since the verdict", ("g3_run",)), ("Re-run source_check", ("g3_run",)),
    # Gate 4
    ("configuration is not_started", ("g4_author", "g4_maturity")),
    ("configuration is draft", ("g4_validate", "g4_author", "g4_tolerances", "g4_approve", "g4_maturity", "g4_commit")),
    ("qc.source_thresholds", ("g4_tolerances", "g4_approve")),
    ("in handoff/CONFIGURATION_APPROVAL.yaml", ("g4_approve", "g4_commit")),
    ("the configuration was edited after the approval", ("g4_approve",)), ("the contract moved after the approval", ("g4_approve",)),
    ("the pack's binding changed after it was approved", ("g4_approve",)), ("the layers the binding resolves against changed", ("g4_approve",)),
    ("signed definition(s) not in governance/DEFINITIONS.yaml", ("g4_definitions",)), ("still signs", ("g4_author",)),
    ("config/implementations.yaml", ("g4_claim",)),
    # Gate 5 — the build, then the person's record of what it validated
    ("report validation:passed_live", ("g5_build", "g5_record")), ("no committed refresh receipt", ("g5_build",)),
    ("candidate verdict FAILED", ("g5_build",)), ("Gate 5 is not started", ("g5_smoke", "g5_build")), ("Gate 5 is in progress", ("g5_build", "g5_record")),
    # Gate 6
    ("not recorded in the ledger", ("g6_seal", "g6_commit")), ("edited after it was sealed", ("g6_seal",)),
    ("no contract yet", ("g2_scaffold",)),
    ("no handoff/RELEASE_APPROVAL.yaml", ("g6_approve", "g6_commit")), ("in handoff/RELEASE_APPROVAL.yaml", ("g6_approve", "g6_commit")),
    ("stand against this pack's claims", ("g2_lint",)),
)

# The acts a clear product still owes its people, named on the page that says every gate is done.
# The receipt check is in the menu only for a products/ pack (production_pack), so a clear fixture
# closes with the countersignature and the commit.
CLOSING = ("g6_countersign", "g6_commit", "g6_receipt")


def _first_for(text: str, menu: list, menus: dict | None = None) -> list:
    """The acts for one blocker, in order (see _route)."""
    return _route(text, menu, menus)[0]


def _route(text: str, menu: list, menus: dict | None = None) -> tuple[list, int | None]:
    """Route current findings by producer code; old text snapshots remain readable."""
    if isinstance(text, (WorkflowIssue, WorkflowFinding)):
        issue = issue_of(text)
        if issue.code == "reviewer_setup_required":
            # Installation setup is independent of a product review. Do not offer
            # material registration or another signature as a repair for it.
            return [_act("g1_reviewer_setup", "Set up reviewer identity", PERSON,
                         path="governance/allowed_signers.yaml",
                         note="An authenticated administrator registers a different reviewer's public key and independently enrolls its identity. Then Check again.")], None
        candidates = [_issue_actions(issue)]
    else:
        # Compatibility for callers holding a pre-protocol text-only snapshot.
        # status.gates wraps every current result, including unclassified ones,
        # so new checks never enter this adapter.
        candidates = [ids for needle, ids in _LEGACY_FIRST if needle in text]
    by_id = {a["id"]: a for a in menu}
    for ids in candidates:
        here = [by_id[i] for i in ids if i in by_id]
        if here:
            return here + [a for a in menu if a["id"] not in {x["id"] for x in here}], None
        for n, other in sorted((menus or {}).items()):
            there = {a["id"]: a for a in other}
            named = [there[i] for i in ids if i in there]
            if named:
                return named + list(menu), n
    return list(menu), None


def _issue_actions(issue):
    """Known findings name actions; unknown codes keep the current gate menu."""
    details = dict(issue.details)
    fixed = {
        "workspace_file_unreadable": ("g1_repair",),
        "source_registration_unreadable": ("g1_repair",),
        "source_registration_empty": ("g1_repair", "g1_init"),
        "source_classification_required": ("g1_classify",),
        "source_review_required": ("g1_review",),
        "source_ledger_invalid": ("g1_repair",),
        "source_ledger_transition_required": ("g1_seal",),
        "review_identity_required": tuple(f"g{n}_commit" for n in (1, 2, 3, 4, 6)),
        "contract_review_required": ("g2_approve", "g2_commit"),
        "specification_qc_required": ("g2_lint", "g2_registers"),
        "specification_coverage_incomplete": ("g2_draft", "g2_scaffold", "g2_lint"),
        "requirement_review_required": ("g2_settle", "g2_approve"),
        "requirement_decision_required": ("g2_forms",),
        "source_route_required": ("g3_registry",),
        "source_evidence_required": ("g3_run", "g3_confirm"),
        "source_judgment_required": ("g3_judge", "g3_commit"),
        "source_status_application_required": ("g3_apply", "g3_run"),
        "source_mapping_required": ("g3_confirm", "g3_registry"),
        "source_verdict_required": ("g3_run", "g3_apply"),
        "source_tolerances_required": ("g4_tolerances", "g4_approve"),
        "configuration_review_required": ("g4_approve", "g4_commit"),
        "configuration_execution_incomplete": ("g4_binding", "g4_author"),
        "publication_surface_inconsistent": ("g4_publication", "g4_binding", "g4_author"),
        "definition_registration_required": ("g4_definitions",),
        "configuration_definition_superseded": ("g4_author",),
        "configuration_scaffold_remaining": ("g4_author",),
        "implementation_claim_required": ("g4_claim",),
        "contract_configuration_inconsistent": ("g2_lint", "g4_author"),
        "output_decision_required": ("g4_author",),
        "validation_required": ("g5_build", "g5_record"),
        "validation_not_started": ("g5_smoke", "g5_build"),
        "release_review_required": ("g6_approve", "g6_commit"),
        "release_ledger_required": ("g6_seal", "g6_commit"),
        "contract_missing": ("g2_scaffold",),
    }
    if issue.code == "source_state":
        return {"unregistered": ("g1_init", "g1_repair"),
                "provisional": ("g1_workbook",)}.get(details.get("state"), ())
    if issue.code == "contract_state":
        return {"not_started": ("g2_extract", "g2_scaffold"),
                "draft": ("g2_lint", "g2_registers", "g2_settle", "g2_approve", "g2_maturity", "g2_commit"),
                "coverage_complete": ("g2_forms", "g2_settle", "g2_approve", "g2_maturity", "g2_commit")}.get(details.get("state"), ())
    if issue.code == "configuration_state":
        return {"not_started": ("g4_author", "g4_maturity"),
                "draft": ("g4_validate", "g4_author", "g4_tolerances", "g4_approve", "g4_maturity", "g4_commit")}.get(details.get("state"), ())
    if issue.code == "required_evidence_missing":
        path = details.get("path")
        if path == "handoff/CONTRACT_APPROVAL.yaml":
            return ("g2_approve", "g2_commit")
        if path == "handoff/CONFIGURATION_APPROVAL.yaml":
            return ("g4_approve", "g4_commit")
        return ("g2_registers", "g2_commit") if issue.gate == 2 else ("g4_author",)
    return fixed.get(issue.code, ())


def _identity_required(value):
    return (issue_of(value).code == "review_identity_required" if isinstance(value, (WorkflowIssue, WorkflowFinding))
            else "is not authenticated" in str(value))


def development_review_request(text):
    """Presentation for an exact identity finding after its production route is chosen."""
    if isinstance(text, (WorkflowIssue, WorkflowFinding)):
        issue = issue_of(text)
        reviewer = dict(issue.details).get("reviewer", "").strip()
        if issue.code != "review_identity_required" or not reviewer:
            return None
        title = f"Confirm {reviewer.replace('_', ' ')}'s review with name and email"
        return {"reviewer": reviewer, "title": title, "text": title + "."}
    match = re.fullmatch(
        r"(?:Gate [1-6]|evidence): .+: ([A-Za-z_]+(?::[A-Za-z0-9_.-]+)?)=(.+?) is not authenticated(?: — .*)?",
        str(text or ""))
    if not match:
        return None
    reviewer = match.group(2).strip()
    title = f"Confirm {reviewer.replace('_', ' ')}'s review with name and email"
    return {"reviewer": reviewer, "title": title, "text": title + "."}


def _development_cards(cards):
    """Copy presentation only; action identifiers and original evidence stay intact."""
    result = []
    for card in cards:
        request = development_review_request(WorkflowIssue.from_dict(card["issue"]) if card.get("issue") else card.get("text"))
        if request is None:
            result.append(card)
            continue
        displayed = deepcopy(card)
        displayed["reported_text"] = card["text"]
        displayed["text"] = request["text"]
        for action in displayed.get("fixes", []):
            if action.get("id") in {"g1_commit", "g2_commit", "g3_commit", "g4_commit", "g6_commit"}:
                action.update(development_review=True, reviewer=request["reviewer"], label=request["title"],
                              note="Confirm the current review using the reviewer's name and email. No signing key is required in development.")
        result.append(displayed)
    return result


def flow(root: str, pack: str, *, development=False) -> dict:
    """The page as one object: gates (state, owner, blockers), the current gate, whether it is
    clear, its blockers each with owner and ordered fix options, and the proceed line."""
    gates = []
    verdict = status.gates(root, pack, development=True) if development else status.gates(root, pack)
    for n, title, state, blockers in verdict:
        gates.append({"gate": n, "title": title, "state": state, "owner": status.OWNER[n], "blockers": list(blockers),
                      "issues": [issue_of(item).to_dict() for item in blockers]})
    # WHETHER THE REGISTRATION IS SIGNED is Gate 1's own verdict (an approval no signature stands
    # behind reads "is not authenticated"); the act catalogue keeps the recorded review correctable
    # while it is not (acts, `signed`)
    gate1_lines = next((g["blockers"] for g in gates if g["gate"] == 1), [])
    menu = acts(pack, root, signed=not any(_identity_required(b) for b in gate1_lines))
    current = next((g for g in gates if g["state"] != "done"), None)
    if current is None:
        by_id = {a["id"]: a for a in menu[6]}
        return {"pack": pack, "development": bool(development), "gates": gates, "current": None, "clear": True, "blockers": [],
                "proceed": "every gate is done; the release is receipted", "next": None,
                "closing": [by_id[i] for i in CLOSING if i in by_id]}
    n = current["gate"]
    cards = []
    for text in current["blockers"]:
        if issue_of(text).code == "explanatory_note" or (not isinstance(text, WorkflowFinding) and text.endswith(":")):
            # a PREFACE to the lines after it ("the checks below are what Gate 4 will require OF
            # Gate 3, quoted as Gate 4 states them:"), not a finding: a card for it named acts a
            # reviewer took to no effect (the walkthrough, 2026-09-05); the findings it prefaces carry their own
            continue
        fixes, held_by = _route(text, menu[n], menu)
        card = {"text": text, "owner": status.OWNER[held_by] if held_by else current["owner"], "fixes": fixes}
        if isinstance(text, WorkflowFinding):
            card["issue"] = text.issue.to_dict()
            if text.issue.code == "reviewer_setup_required":
                card["owner"] = "Administrator"
        if held_by:
            card["held_by"] = held_by
        cards.append(card)
    # THE COMMIT COMES LAST AT GATE 1 (2026-09-07): a freshly stood-up product's first card demanded
    # a signed commit before the person had reviewed anything; the content a person still owes is
    # shown first, the authentication of what they typed after it. Later gates keep the tools' own
    # order (the typed form's commit before the claim raised over it: test_lifecycle's spine).
    cards.sort(key=lambda c: n == 1 and _identity_required(c["text"]))
    if n == 2:
        # ONE SIGNATURE AT GATE 2, NOT TWO (walk RW1-09, 2026-09-07): with the answers saved and the
        # approval still to make, the first card asked for a signed commit over the answers, and the
        # approval then needed a second one. While an approval card stands, the signature cards
        # follow it (and only it: the maturity claim after the commit keeps test_lifecycle's spine).
        waiting = [c for c in cards if _identity_required(c["text"])]
        rest = [c for c in cards if not _identity_required(c["text"])]
        approve = next((i for i, c in enumerate(rest) if any(a["id"] == "g2_approve" for a in c["fixes"][:1])), None)
        if waiting and approve is not None:
            cards = rest[:approve + 1] + waiting + rest[approve + 1:]
        elif waiting and not any((dict(issue_of(c["text"]).details).get("file", "").endswith("/CONTRACT_APPROVAL.yaml")
                                  if isinstance(c["text"], WorkflowFinding) else "CONTRACT_APPROVAL.yaml" in c["text"])
                                 for c in waiting):
            # A draft maturity claim offers the approval later in its action list, without an
            # approval-specific finding yet. Finish that content before signing the decision
            # register; once the approval itself awaits authentication, signing leads again.
            drafting = next((i for i, c in enumerate(rest)
                             if any(a["id"] == "g2_approve" for a in c["fixes"])
                             and c["fixes"][0]["id"] in {"g2_lint", "g2_forms", "g2_settle"}), None)
            if drafting is not None:
                cards = rest[:drafting + 1] + waiting + rest[drafting + 1:]
    if not cards:
        # A GATE THAT IS NOT DONE AND LISTS NO BLOCKER is held by the evidence findings no per-gate
        # check accounted for — status.py applies them to every approval gate and prints the note
        # under Gates 2 and 4 only. The page shows them here, filed under the gate their text names,
        # so "in progress, nothing to fix" never appears (the demo pack, 2026-09-05).
        for g in gates:
            for text in g["blockers"]:
                if (issue_of(text).code == "unattributed_evidence" or
                        not isinstance(text, WorkflowFinding) and "stand against this pack's claims" in text):
                    gate_named = (issue_of(text).gate or g["gate"] if isinstance(text, WorkflowFinding)
                                  else 2 if "contract:" in text else 4 if "configuration:" in text else g["gate"])
                    cards.append({"text": text, "owner": status.OWNER[gate_named], "fixes": _first_for(text, menu[gate_named]),
                                  "held_by": gate_named})
            if cards:
                break
    clear = not cards and current["state"] == "done"
    nxt = next((g["gate"] for g in gates if g["gate"] > n), None)
    # plain sentences: the page shows this line as it stands (no dash, no arrow; 2026-09-07)
    proceed = (f"Gate {n} is clear; proceed to Gate {nxt}" if clear and nxt else
               f"Gate {n} ({current['title']}) is {current['state']}: {len(cards)} blocker(s); "
               f"owner: {current['owner']}")
    return {"pack": pack, "development": bool(development), "gates": gates, "current": n, "clear": clear,
            "blockers": _development_cards(cards) if development else cards,
            "proceed": proceed, "next": nxt, "closing": []}


def render(fl: dict) -> str:
    title = "DEVELOPMENT FLOW" if fl.get("development") else "FLOW"
    L = [f"{title} — {fl['pack']}", ""]
    for g in fl["gates"]:
        mark = "●" if g["gate"] == fl.get("current") else ("✓" if g["state"] == "done" else "○")
        L.append(f"  {mark} Gate {g['gate']} {g['title']:34s} {g['state']}")
    L += ["", f"  {fl['proceed']}", ""]
    for c in fl["blockers"]:
        L.append(f"  BLOCKER  {c['text'][:200]}")
        L.append(f"           owner: {c['owner']}")
        for a in c["fixes"][:4]:
            how = " ".join(a["argv"]) if a["argv"] else a["path"]
            L.append(f"           [{a['kind']:6s}] {a['label']}" + (f"\n                    {how}" if how else ""))
        L.append("")
    return "\n".join(L)


def check_receipts(root, pack):
    """Check only the selected product and specification cut, never another pack's receipts."""
    from pathlib import Path
    from rwd_tools import source_manifest as sm
    base = Path(root).resolve()
    product = (base / pack).resolve()
    try:
        relative = product.relative_to(base)
    except ValueError:
        print("The product is outside this workspace; no receipts were checked.")
        return 1
    if len(relative.parts) != 4 or relative.parts[0] != "products":
        print("This draft has no registered refresh-receipt location; no receipts were checked.")
        return 1
    _, family, slug, cut = relative.parts
    directory = base / "refreshes" / family / slug / cut
    files = sorted(directory.glob("*.yaml"))
    if not files:
        print(f"No committed refresh receipt is available for {relative.as_posix()}. "
              "A data expert must record the build's own receipt after the governed run.")
        return 1
    bad = 0
    for path in files:
        if path.resolve().parent != directory.absolute():
            print("A receipt points outside this product's receipt directory; it was not read.")
            bad += 1
            continue
        bad += sm._check_one_receipt(str(path))
    print(f"{len(files)} receipt(s) for {relative.as_posix()}; {bad} refused")
    return 1 if bad else 0


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    ap.add_argument("pack", help="repo-relative pack path")
    ap.add_argument("--json", action="store_true", help="print the page as one JSON object")
    ap.add_argument("--check-receipts", action="store_true", help="check only this product and specification cut's refresh receipts")
    ap.add_argument("--root", default=None, help="checkout root; by default the working directory when the pack is under it, else this checkout")
    a = ap.parse_args(argv)
    # THE SAME PACK FROM ANY WORKING DIRECTORY (the rule the gates keep): a scratch checkout runs this
    # tool from its own root without naming it, exactly as it runs status.py
    root = a.root or (os.getcwd() if os.path.isdir(os.path.join(os.getcwd(), a.pack)) else ROOT)
    if not os.path.isdir(os.path.join(root, a.pack)):
        sys.exit(f"not a pack: {a.pack}")
    if a.check_receipts:
        return check_receipts(root, a.pack)
    fl = flow(root, a.pack)
    print(json.dumps(fl, indent=1) if a.json else render(fl))
    return 0


if __name__ == "__main__":
    from rwd_tools.console import use_utf8
    use_utf8()
    sys.exit(main())
