"""Ed25519 (RFC 8032), stdlib only — the ledger's ONE signature primitive.

Why pure Python: the ledger must verify a person's signature on every checkout that can read
the ledger — CI runners, a reviewer's laptop, the deployed tree — and a compiled dependency that
is present on one machine and broken on the next (a missing cffi backend, a mismatched wheel)
would make authentication a property of the environment rather than of the signature. One
signature over a 64-character digest costs milliseconds here, and the arithmetic is the RFC's
own reference construction, held to its test vectors in the suite.

    secret_to_public(sk) -> pk       32 raw bytes -> 32 raw bytes
    sign(sk, msg) -> sig             64 raw bytes
    verify(pk, msg, sig) -> bool
"""
import hashlib

_P = 2 ** 255 - 19
_Q = 2 ** 252 + 27742317777372353535851937790883648493
_D = (-121665 * pow(121666, _P - 2, _P)) % _P
_I = pow(2, (_P - 1) // 4, _P)


def _h(m):
    return hashlib.sha512(m).digest()


def _inv(x):
    return pow(x, _P - 2, _P)


def _recover_x(y, sign):
    xx = (y * y - 1) * _inv(_D * y * y + 1)
    x = pow(xx, (_P + 3) // 8, _P)
    if (x * x - xx) % _P != 0:
        x = (x * _I) % _P
    if (x * x - xx) % _P != 0:
        raise ValueError("not a point on the curve")
    if (x & 1) != sign:
        x = _P - x
    return x


_BY = (4 * _inv(5)) % _P
_BX = _recover_x(_BY, 0)
_B = (_BX, _BY, 1, (_BX * _BY) % _P)          # extended coordinates (X, Y, Z, T)
_IDENT = (0, 1, 1, 0)


def _add(p, q):
    x1, y1, z1, t1 = p
    x2, y2, z2, t2 = q
    a = ((y1 - x1) * (y2 - x2)) % _P
    b = ((y1 + x1) * (y2 + x2)) % _P
    c = (t1 * 2 * _D * t2) % _P
    d = (z1 * 2 * z2) % _P
    e, f, g, h = b - a, d - c, d + c, b + a
    return ((e * f) % _P, (g * h) % _P, (f * g) % _P, (e * h) % _P)


def _mul(p, s):
    r = _IDENT
    while s:
        if s & 1:
            r = _add(r, p)
        p = _add(p, p)
        s >>= 1
    return r


def _compress(p):
    x, y, z, _t = p
    zi = _inv(z)
    x, y = (x * zi) % _P, (y * zi) % _P
    return (y | ((x & 1) << 255)).to_bytes(32, "little")


def _decompress(b):
    if len(b) != 32:
        raise ValueError("a public key is 32 bytes")
    yb = int.from_bytes(b, "little")
    sign = yb >> 255
    y = yb & ((1 << 255) - 1)
    if y >= _P:
        raise ValueError("not a point on the curve")
    x = _recover_x(y, sign)
    return (x, y, 1, (x * y) % _P)


def _equal(p, q):
    x1, y1, z1, _ = p
    x2, y2, z2, _ = q
    return (x1 * z2 - x2 * z1) % _P == 0 and (y1 * z2 - y2 * z1) % _P == 0


def _clamp(h):
    a = int.from_bytes(h[:32], "little")
    a &= (1 << 254) - 8
    a |= 1 << 254
    return a


def secret_to_public(sk):
    if len(sk) != 32:
        raise ValueError("a secret key is 32 raw bytes")
    return _compress(_mul(_B, _clamp(_h(sk))))


def sign(sk, msg):
    if len(sk) != 32:
        raise ValueError("a secret key is 32 raw bytes")
    h = _h(sk)
    a = _clamp(h)
    pk = _compress(_mul(_B, a))
    r = int.from_bytes(_h(h[32:] + msg), "little") % _Q
    rb = _compress(_mul(_B, r))
    k = int.from_bytes(_h(rb + pk + msg), "little") % _Q
    s = (r + k * a) % _Q
    return rb + s.to_bytes(32, "little")


def verify(pk, msg, sig):
    """True only for a signature this key made over exactly this message; every malformed
    input is False, never an exception the caller could mistake for a verdict."""
    try:
        if len(sig) != 64 or len(pk) != 32:
            return False
        a = _decompress(pk)
        r = _decompress(sig[:32])
        s = int.from_bytes(sig[32:], "little")
        if s >= _Q:
            return False
        k = int.from_bytes(_h(sig[:32] + pk + msg), "little") % _Q
        return _equal(_mul(_B, s), _add(r, _mul(a, k)))
    except (ValueError, ArithmeticError):
        return False
