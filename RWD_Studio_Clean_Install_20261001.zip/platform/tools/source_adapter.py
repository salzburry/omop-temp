#!/usr/bin/env python3
"""The typed source-adapter contract — one versioned artifact per role, per dataset.

    python3 platform/tools/source_adapter.py skeleton <pack>     # print the TODO skeleton
    python3 platform/tools/source_adapter.py check <pack>        # validate a committed file

WHY THIS EXISTS. The knowledge of how a logical role binds to a physical delivery is scattered:
stage reads know the columns, the config knows the stems, source_grain knows the keys, mapping
evidence knows the kinds, and none of it states types, parsers, join cardinality, vocabulary or
units anywhere a tool can hold a build to. The adapter file (`config/source_adapters.yaml`) is
that one artifact — the versioned source-adapter contract — and it is the
prerequisite for the second dataset: two adapter sets under one contract IS the semantic view's
implementation axis (semantic_view reads the `dataset:` labels). DECLARED here, not yet run: the runtime
binds one active adapter set per pack today, so a second source is a sibling product with a comparability
ruling until the runtime accepts a union.

DIVISION OF AUTHORITY, unchanged by this file: `skeleton` derives every MACHINE-KNOWABLE field
from the engine's own declarations and leaves the judgment fields TODO — a person fills types,
parsers, cardinality, vocabulary, units, and signs the review block. `check` is fail-closed the
way this repository is: a committed file must cover EVERY required role (partial coverage reads
as complete), cover every stage-read required column, agree with any declared source_grain, and
carry a named person's dated review when it claims one. NO adapter file is a stated absence —
"no claim" — never an error and never a pass.
"""
import argparse
import json
import os
import sys

TOOLS = os.path.dirname(os.path.abspath(__file__))
PLATFORM = os.path.dirname(TOOLS)

from rwd_tools import product_gates as pg                                                  # noqa: E402
from rwd_tools.spec_extract import repo_relative                                      # noqa: E402

ADAPTERS = os.path.join("config", "source_adapters.yaml")
CARDINALITIES = ("one_to_one", "many_to_one")
# The CLOSED vocabulary of review states. `pending` is what `skeleton()` writes; `reviewed` is
# what a signature says. Nothing else is a status, and the set is closed so that a word outside
# it is REPORTED rather than silently meaning "not reviewed" (see the check in `check()`).
REVIEW_STATUSES = ("pending", "reviewed")

# THE CANONICAL TYPES A BOUND COLUMN MAY BECOME. Closed, because a free-text type is a type
# nobody can execute: the loader turns each of these into one Spark cast, and a value outside the
# set would have to be guessed at or ignored, which are the two failure modes this binding exists
# to remove.
LOGICAL_TYPES = ("string", "integer", "long", "double", "boolean", "date", "timestamp")

# THE PARSERS live in the ENGINE (`engine/source_contract.py`) and are re-exported here.
# `stages/sources.py` executes them and `validate.py` states outright that the engine must not
# import `platform/tools` — but `sources.py` did exactly that to reach this table, so the loader
# only worked when a caller happened to have `tools/` on sys.path, and the layering rule the
# repository wrote down was false in the one place it mattered most. One definition, owned by the
# side that executes it, imported by the side that validates it.
from engine.source_parsers import PARSERS                                        # noqa: E402,F401

# STANDARD PROFILES — REGISTERED: NONE, DELIBERATELY.
#
# The idea a profile encodes is "define once, run on many datasets": a pack names a standard, and
# inherits that standard's role->table bindings instead of hand-writing them. OMOP CDM was
# registered here as `omop_cdm_5.4` and has been REMOVED, because it was never executed.
#
# WHAT WAS WRONG WITH IT. The entry declared role->table bindings and a set of roles the standard
# cannot define, and nothing in the run ever applied either one. `compiled()` did not resolve a
# role through the profile, no table was bound from it, and no referential or key rule was
# checked against it. A pack naming the profile therefore inherited nothing while the registry
# implied it inherited a standard — a capability claim the code did not honour, which is the one
# thing this file exists to refuse. An unimplemented standard in a registry reads to a reviewer
# as support for that standard.
#
# WHY IT IS NOT SIMPLY BEING FINISHED. OMOP is a PLUMBING answer, and the reasoning is worth
# keeping even with the entry gone. It is strong where every therapy area looks alike — person,
# visit, drug_exposure, measurement, death — and absent exactly where oncology earns its money.
# Staging, histology, response assessment and progression have no first-class home in the CDM;
# they land in `measurement` or `observation` as concept ids and lose the structure that made
# them worth abstracting. `lot` maps to 5.4's `episode`, added by the OHDSI Oncology working
# group, but that extension is thinly adopted and CONSTRUCTING episodes from drug_exposure is
# itself a derivation the standard does not specify. And a vendor's curated `enhanced` table —
# advanced diagnosis abstracted from charts, ECOG read out of notes — is precisely what a buyer
# pays for and precisely what OMOP cannot represent without throwing it away. Forcing an oncology
# delivery through OMOP to gain portability trades the abstraction for the plumbing, which is the
# wrong way round.
#
# WHAT RE-ADDING WOULD REQUIRE. A profile earns its entry when a delivery actually arrives in that
# shape and the run EXECUTES it: roles resolved to the profile's tables, its keys and referential
# rules checked, its undefined roles refused rather than described, and a test that binds a pack
# through the profile end to end. Until then the mechanism stays and the registry stays empty, so
# `profile:` fail-closes: naming any profile is refused by `check` rather than silently inheriting
# nothing.
PROFILES = {}


def _engine(pack):
    from engine.config import load_config                                          # noqa: PLC0415
    from engine import validate as ev                                                   # noqa: PLC0415
    cfg = load_config(os.path.join(pack, "config", "data_product.yaml"))
    return cfg, ev


def skeleton(pack):
    """The per-role skeleton, machine fields filled, judgment fields TODO. Prints, never
    writes — committing and signing it is a person's act, like every registration here."""
    cfg, ev = _engine(pack)
    required = ev.required_columns(cfg)
    optional = ev.optional_columns(cfg)
    grain_declared = dict(ev.source_grain(cfg)[0] or {})
    stems = {}
    try:
        for role, entry in (cfg.raw.get("sources") or {}).items():
            stems[role] = entry if isinstance(entry, str) else (entry or {}).get("table", "")
    except Exception:                                 # noqa: BLE001 — a slim config names none
        pass
    L = ["# source_adapters.yaml — the typed binding of each logical role to ONE dataset's",
         "# physical delivery. Machine-derived fields are filled; every TODO is a person's",
         "# judgment. Sign the review block only after checking the physical table itself.",
         "dataset: TODO            # e.g. flatiron | optum_mc — the semantic view's axis",
         "adapters:"]
    for role in sorted(set(required) | set(optional)):
        cols = sorted(set(required.get(role, ())))
        opt = sorted(set(optional.get(role, ())))
        L.append(f"  - logical_role: {role}")
        L.append(f"    physical_table: {stems.get(role) or 'TODO'}")
        L.append("    required_columns:")
        for c in cols:
            L.append(f"      {c}: {{physical: {c}, logical_type: TODO, "
                     f"accepted_physical_types: [TODO], parser: null}}")
        L.append(f"    grain: {json.dumps(grain_declared.get(role, ['TODO']))}")
        L.append("    join: {to: index, keys: [patientid], cardinality: TODO}")
        # `optional_columns`, `vocabulary` and `units` are NOT emitted, and their absence is the
        # point. `compiled()` reads logical_role, physical_table, required_columns, grain and join
        # — nothing else — so those three were fields a reviewer signed and no code executed,
        # while `mapping_digest` hashed them and made them part of what the signature covered.
        # This file already set the standard when it deleted the OMOP profile: "a capability claim
        # the code did not honour, which is the one thing this file exists to refuse." A skeleton
        # that invites a reviewer to fill them is that claim, printed.
        L.append("    review: {status: pending, approved_by: TODO, approval_date: TODO,")
        L.append("             approved_digest: TODO}   # `source_adapter.py digest <pack>`")
    return "\n".join(L)


def mapping_digest(doc):
    """The sha256 of WHAT WAS REVIEWED — the mapping, without the review blocks that sign it.

    A review block that only says `status: reviewed` binds a person to a status, not to bytes: the
    physical table, the column bindings, the types and the parsers can all be edited afterwards and
    the signature reads exactly the same. The whole adapter file cannot be the digest either, since
    writing the digest into the file would change it. So the digest covers the mapping and excludes
    every `review` key, which makes it stable under signing and unstable under any change to what
    the signature is about — the one property that makes an approval mean something.
    """
    import hashlib                                                          # noqa: PLC0415
    body = {
        "dataset": str((doc or {}).get("dataset") or ""),
        "profile": str((doc or {}).get("profile") or ""),
        "schema": str((doc or {}).get("schema") or ""),
        "cut": str((doc or {}).get("cut") or ""),
        "adapters": [{k: v for k, v in sorted((a or {}).items()) if k != "review"}
                     for a in ((doc or {}).get("adapters") or [])],
    }
    canonical = json.dumps(body, sort_keys=True, separators=(",", ":"), default=str)
    return hashlib.sha256(canonical.encode("utf-8")).hexdigest()


def _column_problems(where, columns):
    """Why a role's column bindings are not executable, or [].

    Each check answers "could the loader run this?" — an untyped or unknown type has no cast, an
    unrecognised parser name would be ignored, and a date with NO parser is the one that bites
    silently: `01JAN2016` cast to date nulls every row where ANSI is off and raises where it is
    on, so one reviewed adapter behaves two ways on two clusters.
    """
    out = []
    for c, spec in sorted(columns.items()):
        spec = spec or {}
        lt = str(spec.get("logical_type") or "TODO")
        if lt == "TODO":
            out.append(f"{where}: {c}.logical_type is TODO — an untyped binding is the "
                       f"presence-only mapping this file exists to replace")
        elif lt not in LOGICAL_TYPES:
            out.append(f"{where}: {c}.logical_type {lt!r} is not one of {list(LOGICAL_TYPES)}")
        p = spec.get("parser")
        if str(p or "") == "TODO":
            out.append(f"{where}: {c}.parser is TODO — state a parser or null; a placeholder "
                       f"is not a reviewed binding")
        elif p not in (None, "") and str(p) not in PARSERS:
            out.append(f"{where}: {c}.parser {p!r} is not a known parser "
                       f"({', '.join(sorted(PARSERS))}) — an unrecognised name would be "
                       f"ignored, and a date left unparsed reads as every row null")
        elif p in (None, "") and lt in ("date", "timestamp"):
            out.append(f"{where}: {c} is bound as {lt} with no parser — state the delivered "
                       f"shape ({', '.join(sorted(PARSERS))}); a date cast without one yields "
                       f"null for every row it cannot guess")
        if any(str(t) == "TODO" for t in (spec.get("accepted_physical_types") or [])):
            out.append(f"{where}: {c}.accepted_physical_types carries TODO — the skeleton's "
                       f"placeholder was signed instead of filled")
        if str(spec.get("physical") or "TODO") in ("", "TODO"):
            out.append(f"{where}: {c}.physical is unstated — nothing says which delivered "
                       f"column becomes `{c}`")
    return out


def check(pack):
    """Problems with a committed adapter file, or the stated absence. Fail-closed grammar:
    partial coverage, an unknown role, a thin column set, a grain disagreement, an invented
    cardinality, and an unowned review each surface by name."""
    path = os.path.join(pack, ADAPTERS)
    if not os.path.exists(path):
        return {"state": "no_claim", "problems": [],
                "note": f"no {ADAPTERS} — the pack makes no adapter claim; skeleton prints one"}
    doc, err = pg.read_yaml(path)
    if err:
        return {"state": "unreadable", "problems": [f"{repo_relative(path)}: {err}"]}
    cfg, ev = _engine(pack)
    required = ev.required_columns(cfg)
    grain_declared = dict(ev.source_grain(cfg)[0] or {})
    problems = []
    dataset = str((doc or {}).get("dataset") or "").strip()
    if not dataset or dataset == "TODO":
        problems.append("dataset is unstated — the adapter set binds ONE dataset's delivery, "
                        "and the semantic view's implementation axis reads this label")
    # A NAMED PROFILE IS A CLAIM ABOUT WHICH STANDARD THIS DELIVERY FOLLOWS, and it is checked
    # against what the standard actually defines — a profile that silently covered a role it has
    # no table for would be the invented mapping this file exists to prevent.
    profile = str((doc or {}).get("profile") or "").strip()
    if profile and profile not in PROFILES:
        problems.append(
            f"profile {profile!r} is not a registered standard profile "
            + (f"({', '.join(sorted(PROFILES))})" if PROFILES else
               "— NO profile is registered, because none is executed: a registry entry that "
               "binds no table is a capability claim the run does not honour. Bind the roles "
               "explicitly in `adapters:`."))
        profile = ""
    # SCHEMA AND CUT ARE THE DELIVERY IDENTITY. Without them the runtime's adapter-vs-run
    # comparison has nothing to compare, so an adapter set could claim any delivery at all.
    for fld in ("schema", "cut"):
        if str((doc or {}).get(fld) or "").strip() in ("", "TODO"):
            problems.append(f"{fld} is unstated — an adapter set binds ONE delivery; without "
                            f"its {fld} the runtime cannot refuse a mismatched run")
    want = mapping_digest(doc)
    seen = {}
    for i, a in enumerate((doc or {}).get("adapters") or []):
        role = str(a.get("logical_role") or "")
        where = f"adapter[{i}] ({role or 'role unstated'})"
        if not role:
            problems.append(f"{where}: logical_role is unstated")
            continue
        if role in seen:
            problems.append(f"{where}: duplicated — one adapter per role per dataset")
            continue
        seen[role] = a
        if role not in required and role not in ev.optional_columns(cfg):
            problems.append(f"{where}: no stage read declares this role — an adapter for a "
                            f"role nothing reads binds nothing")
            continue
        # UNEXECUTED FIELDS ARE REFUSED, NOT IGNORED. `compiled()` reads five keys; anything
        # else here is signed by a reviewer, hashed into `mapping_digest`, and then dropped. The
        # sharpest case is `vocabulary`: `engine/vocabularies.py` names it as the authority for a
        # live question — whether NDC codes arrive 10- or 11-digit — while `config.py` reads only
        # `raw["vocabularies"]`, so a reviewer could answer that question here and change nothing.
        for _dead in ("vocabulary", "units", "optional_columns"):
            if a.get(_dead) not in (None, {}, []):
                problems.append(
                    f"{where}: declares `{_dead}`, which no code executes — `compiled()` reads "
                    f"logical_role, physical_table, required_columns, grain and join only. A "
                    f"reviewer signing this signs a field the run drops; state it where the "
                    f"engine reads it, or remove it.")
        if str(a.get("physical_table") or "TODO").strip() in ("", "TODO"):
            problems.append(f"{where}: physical_table is TODO — an adapter that names no "
                            f"table binds a role to nothing")
        else:
            # THE COMPARISON THE RUNTIME ALREADY MAKES, made here too. `run_rwdp` refuses a run
            # where the adapter and `cfg.sources` resolve one role to different physical tables —
            # one truth, fix whichever is wrong — and this function never looked. So an adapter
            # set redirecting every role elsewhere passed with zero problems, compiled clean, was
            # reported as an implementation by `semantic_view` and answered a competency question,
            # and only then refused at runtime for nineteen roles.
            #
            # OFFLINE EVIDENCE THAT ASSERTS AN IMPLEMENTATION WHICH CAN NEVER RUN is worse than no
            # evidence: everything downstream reads `check()` as the offline verdict, and a
            # verdict that disagrees with the runtime is a verdict nobody can act on.
            _phys = str(a.get("physical_table")).strip()
            try:
                _cfg_table = str(cfg.table(role)) if role in cfg.sources else None
            except Exception:                                            # noqa: BLE001
                _cfg_table = None
            # BOTH SIDES CONCRETE, or there is nothing to compare. A pack whose schema or cut is
            # still `REPLACE_ME` resolves every role to a placeholder, and the skeleton this tool
            # prints carries bare stems for a reviewer to complete — comparing a draft against a
            # placeholder would flag all nineteen roles of an unconfigured pack and bury the one
            # real divergence in noise. Both states are already reported by their own checks.
            _draft = any("REPLACE_ME" in v or "TODO" in v
                         for v in (_phys, _cfg_table or "") if v)
            if _cfg_table and not _draft and _phys != _cfg_table:
                problems.append(
                    f"{where}: binds {_phys!r} and cfg.sources resolves this role to "
                    f"{_cfg_table!r} — the runtime refuses that disagreement, so this set cannot "
                    f"run. One truth: fix whichever is wrong.")
        j = a.get("join") or {}
        if not j.get("to") or not j.get("keys"):
            problems.append(f"{where}: join.to / join.keys unstated — an unjoined source is "
                            f"a frame, not an implementation")
        cols = {str(c).lower() for c in (a.get("required_columns") or {})}
        missing = sorted(set(required.get(role, ())) - cols)
        if missing:
            problems.append(f"{where}: required_columns omit stage-read column(s) "
                            f"{missing} — the engine will read what the adapter never bound")
        problems += _column_problems(where, a.get("required_columns") or {})
        g = [str(k) for k in (a.get("grain") or [])]
        if role in grain_declared and g and g != [str(k) for k in grain_declared[role]]:
            problems.append(f"{where}: grain {g} disagrees with the pack's declared "
                            f"source_grain {grain_declared[role]} — one of the two is wrong")
        card = str(((a.get("join") or {}).get("cardinality")) or "")
        if card not in CARDINALITIES:
            problems.append(f"{where}: join.cardinality {card!r} is not one of "
                            f"{CARDINALITIES} — TODO is not a cardinality")
        rev = a.get("review") or {}
        status = str(rev.get("status") or "").strip()
        # A STATUS NOBODY RECOGNISES IS SILENTLY NOT REVIEWED. Every check below — the reviewer,
        # the date, and the digest that binds a signature to bytes — hangs off `== "reviewed"`, so
        # an adapter set whose every block read `status: approved` came back from this function
        # with ZERO problems and exit 0 while nothing in it had been signed or digest-checked.
        # `compiled()` refused the same file, so the two disagreed about it in opposite
        # directions: the tool a person RUNS said clean, the loader said no. `approved`, `signed`,
        # `complete` and `ok` are all words a reviewer reaches for, and each one used to read as
        # approval and count as nothing.
        if status not in REVIEW_STATUSES:
            problems.append(
                f"{where}: review.status {status or '(unstated)'} is not one of "
                f"{REVIEW_STATUSES} — an unrecognised status counts as NOT reviewed, so the "
                f"reviewer, the approval date and the approved_digest went unchecked entirely")
        if status == "reviewed":
            for field, checkfn in (("approved_by", pg.not_a_person),
                                   ("approval_date", pg.bad_date)):
                v = rev.get(field)
                # `pg.unstated` OWNS the placeholder verdict, and `not_a_person` defers to it by
                # design (it returns None for a placeholder so the two do not report one defect
                # twice). A hand-written `(None, "", "TODO")` literal here caught exactly one of
                # them, so `approved_by: TBD` — or N/A, PENDING, XXX, REPLACE_ME — satisfied
                # `status: reviewed` and a live run bound delivered data on it. Every other caller
                # in this repository pairs the two; this one now does too.
                why = "is not set" if pg.unstated(v) else checkfn(v)
                if why:
                    problems.append(f"{where}: review claims reviewed but {field}: {why}")
            # ...AND THE REVIEW MUST NAME WHAT IT REVIEWED. Without this the signature binds to a
            # status, not to bytes: the physical table, the bindings, the types and the parsers can
            # all be edited after the review and `status: reviewed` reads exactly the same. The
            # digest covers the mapping and excludes the review blocks (see `mapping_digest`), so
            # it is stable under signing and changes the moment the mapping does.
            got = str(rev.get("approved_digest") or "").strip()
            if got in ("", "TODO"):
                problems.append(
                    f"{where}: review claims reviewed but approved_digest is unstated — the "
                    f"approval would bind to a status rather than to the mapping it approved. "
                    f"Record it with `source_adapter.py digest <pack>` (current: {want[:16]})")
            elif got != want:
                problems.append(
                    f"{where}: review approved digest {got[:16]} but the mapping now hashes to "
                    f"{want[:16]} — the mapping changed after it was reviewed, so this signature "
                    f"is about a file that no longer exists. Re-review, then re-record the digest")
    uncovered = sorted(set(required) - set(seen))
    if uncovered:
        # ...and where a profile is claimed, say WHY each uncovered role is uncovered. "The
        # standard has no table for this" and "somebody forgot" need different actions, and
        # reporting them as one list sends a person looking for the wrong fix.
        undefined = (PROFILES.get(profile) or {}).get("undefined_roles") or {}
        named = [f"{r} — {undefined[r]}" for r in uncovered if r in undefined]
        rest = [r for r in uncovered if r not in undefined]
        if rest:
            problems.append(f"required role(s) with no adapter: {rest} — partial coverage "
                            f"reads as complete, so a committed file covers every required role")
        for line in named:
            problems.append(f"required role the {profile} profile does not define: {line}. Bind "
                            f"it by hand or declare the pack cannot use this profile")
    all_reviewed = bool(seen) and all(
        str((a.get("review") or {}).get("status") or "") == "reviewed"
        for a in seen.values())
    return {"state": "checked", "dataset": dataset or None, "profile": profile or None,
            "adapters": sorted(seen), "all_reviewed": all_reviewed, "mapping_digest": want,
            "schema": str((doc or {}).get("schema") or "") or None,
            "cut": str((doc or {}).get("cut") or "") or None,
            "problems": problems}


def compiled(pack):
    """The checked adapter set as an EXECUTABLE PLAN — the whole point of the file.

    `bindings` names each role's physical table. `roles` carries the part that makes a definition
    PORTABLE: per role, which delivered column becomes each canonical column, what type it
    becomes, and which parser reads its delivered shape. The loader executes that, so the same
    pack config reads a delivery whose columns are named and typed differently without a line of
    the contract changing — which is the difference between a semantic layer and a description of
    one.

    Compiles nothing unless the set is clean AND fully reviewed: the loader must never consume
    half an adapter set, so a partial or unsigned claim comes back as problems with an empty plan.
    """
    r = check(pack)
    if r.get("state") != "checked" or r.get("problems") or not r.get("all_reviewed"):
        problems = list(r.get("problems") or [])
        if r.get("state") == "checked" and not r.get("all_reviewed"):
            problems.append("not every adapter carries review.status: reviewed")
        return {"state": r.get("state"), "problems": problems, "bindings": {}, "roles": {},
                "digest": None, "dataset": r.get("dataset"), "profile": r.get("profile")}
    import hashlib                                                          # noqa: PLC0415
    path = os.path.join(pack, ADAPTERS)
    with open(path, "rb") as fh:
        digest = hashlib.sha256(fh.read()).hexdigest()
    doc, _err = pg.read_yaml(path)
    bindings, roles = {}, {}
    for a in (doc or {}).get("adapters") or []:
        role = str(a.get("logical_role"))
        bindings[role] = str(a.get("physical_table"))
        cols = {}
        for canonical, spec in (a.get("required_columns") or {}).items():
            spec = spec or {}
            cols[str(canonical).lower()] = {
                "physical": str(spec.get("physical") or canonical).lower(),
                "logical_type": str(spec.get("logical_type") or "string"),
                "parser": (str(spec["parser"]) if spec.get("parser") else None),
                "accepted_physical_types": [str(t).lower()
                                            for t in (spec.get("accepted_physical_types") or [])],
            }
        roles[role] = {"table": bindings[role], "columns": cols,
                       "grain": [str(k) for k in (a.get("grain") or [])],
                       "join": dict(a.get("join") or {})}
    return {"state": "compiled", "problems": [], "bindings": bindings, "roles": roles,
            "digest": digest, "mapping_digest": r.get("mapping_digest"),
            "dataset": r.get("dataset"), "profile": r.get("profile"),
            "schema": r.get("schema"), "cut": r.get("cut")}


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    ap.add_argument("cmd", choices=("skeleton", "check", "digest"))
    ap.add_argument("pack")
    a = ap.parse_args(argv)
    if a.cmd == "skeleton":
        print(skeleton(a.pack))
        return 0
    if a.cmd == "digest":
        # PRINTS, never writes. Recording the digest in the file is the reviewer's act, the same
        # way every other approval here is typed by the person making it.
        path = os.path.join(a.pack, ADAPTERS)
        if not os.path.exists(path):
            print(f"no {ADAPTERS} — nothing to digest")
            return 1
        doc, err = pg.read_yaml(path)
        if err:
            print(f"{repo_relative(path)}: {err}")
            return 1
        print(mapping_digest(doc))
        return 0
    r = check(a.pack)
    print(json.dumps(r, indent=2, sort_keys=True))
    return 1 if r["problems"] else 0


if __name__ == "__main__":
    from rwd_tools.console import use_utf8
    use_utf8()
    sys.exit(main())
