"""Resolve review adapters against the same registry as native engine capability claims.

This validates wiring and declared evidence, not scientific correctness or that a
particular product has finished its source, output or approval reviews.
"""
import ast
from pathlib import Path
import yaml

from rwd_services import workspace_root
ROOT = workspace_root(__file__)
from rwd_services import package_asset
REGISTRY = ROOT / "platform/capabilities.yaml"
if not REGISTRY.exists():
    REGISTRY = package_asset("platform/capabilities.yaml")


def load():
    return yaml.safe_load(REGISTRY.read_text(encoding="utf-8"))


def _symbol(reference, root):
    file, symbol = reference.split("::", 1)
    path = root / file
    if path.is_symlink() or not path.is_file() or not path.resolve().is_relative_to(root):
        return False
    tree = ast.parse(path.read_text(encoding="utf-8-sig"))
    return any(isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)) and node.name == symbol for node in ast.walk(tree))


def errors(document, *, root=None):
    root = Path(root if root is not None else ROOT).resolve()
    result, seen = [], set()
    native = {item["id"] for item in document.get("capabilities", [])}
    for stage in document.get("execution_stages", []):
        try:
            valid = _symbol(stage["engine"], root) and bool(stage.get("limits"))
        except (KeyError, ValueError, OSError, SyntaxError):
            valid = False
        if not valid:
            result.append("Execution stage has no existing engine symbol or explicit scope.")
        else:
            native.add(stage["id"])
    adapters = document.get("review_adapters")
    if not isinstance(adapters, list) or not adapters:
        return ["The capability registry has no review adapters."]
    for item in adapters:
        key = (item.get("operator"), item.get("family"))
        if key in seen:
            result.append("Duplicate review adapter: " + str(key))
        seen.add(key)
        if item.get("capability") not in native:
            result.append(str(key) + " has no declared native capability.")
        for field in ("editor", "compiler", "source_requirements", "engine", "validator", "test"):
            try:
                found = _symbol(item.get(field, ""), root)
            except (ValueError, OSError, SyntaxError):
                found = False
            if not found:
                result.append(str(key) + " has no existing " + field + " symbol.")
    page = root / "experiments/portal/variable_clinical_rule_page.py"
    tree = ast.parse(page.read_text(encoding="utf-8-sig"))
    templates = next(ast.literal_eval(node.value) for node in tree.body if isinstance(node, ast.Assign)
                     and any(isinstance(target, ast.Name) and target.id == "TEMPLATES" for target in node.targets))
    offered = {(operator, family) for operator, family, _ in templates.values() if operator not in {"", "custom"}}
    for missing in sorted(offered - seen):
        result.append("Clinical editor has no execution adapter: " + str(missing))
    for hidden in sorted(seen - offered):
        result.append("Execution adapter has no clinical editor: " + str(hidden))
    return result


def status(operator, family, document=None):
    doc = document if document is not None else load()
    entry = next((item for item in doc.get("review_adapters", [])
                  if (item.get("operator"), item.get("family")) == (operator, family)), None)
    return {"supported": bool(entry), "capability": entry.get("capability") if entry else None,
            "message": ("Supported calculation. Its source, selection rules and output still need review."
                        if entry else "Needs implementation: this calculation cannot yet generate executable settings."),
            "evidence": dict(entry) if entry else {}}
