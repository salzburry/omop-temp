#!/usr/bin/env python3
"""Analytical definition ids — programme item 2 (and, through config/implementations.yaml, item 3).

    python3 platform/tools/definition_registry.py --check                    the register and every pack
    python3 platform/tools/definition_registry.py --propose <pack>           entries a pack's signed definitions would add
    python3 platform/tools/definition_registry.py --resolve <pack>           which registered definition each signed family is
    python3 platform/tools/definition_registry.py --supports <definition_id> the packs and datasets that implement it
    python3 platform/tools/definition_registry.py --propose-implementations <pack>

THE CHAIN THIS CLOSES:   concept  ->  analytical definition  ->  implementation in a dataset.

A concept (a UMLS CUI, an mCODE profile) says what a thing IS; the analytical definition says how it
is measured here — index, window, selection, tie-break, censoring — and `definition_signature`
already derives that from the approved configuration with every physical binding stripped. What was
missing was the NAME: an id minted once, bound to the concept above it and to the signature below
it, so two products can be asked "do you carry the same definition?" and a source can be asked "do
you implement RWDP:ECOG_PS:v1?" rather than "do you happen to have a column called ECOG?".

  governance/DEFINITIONS.yaml         the register (a person mints; this tool proposes and checks)
  <pack>/config/implementations.yaml  what THIS dataset implements: variable -> definition id, the
                                      config roles it reads, and who reviewed the claim

Every refusal is about resolution — an id that is not registered, a signature that no pack signs, a
concept the terminology does not carry, a variable the contract does not define. Whether a
definition is RIGHT is a person's judgment and nothing here has one. stdlib + PyYAML.
"""
from __future__ import annotations

import argparse
import os
import re
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
from rwd_services import workspace_root
ROOT = str(workspace_root(__file__))
from rwd_tools import product_gates as pg                                                  # noqa: E402
from rwd_tools import registry_schema as rs                                                # noqa: E402

REGISTRY = os.path.join("governance", "DEFINITIONS.yaml")
IMPLEMENTATIONS = os.path.join("config", "implementations.yaml")
ID_RE = re.compile(r"^[A-Z][A-Z0-9]*:[A-Z][A-Z0-9_]*:v[1-9][0-9]*$")
CUI_RE = re.compile(r"^C[0-9]{7}$")
NONE = "none"

_DEFINITION = {
    "definition_id": rs.F("str", required=True, note="<namespace>:<master family>:v<n>, minted once"),
    "master": rs.F("str", required=True, note="a master family in the variable inventory"),
    "concept": rs.F("str", required=True, note="the UMLS CUI this definition realises"),
    "signature_sha256": rs.F("str", required=True, note="definition_signature.digest over the approved config"),
    "registered_by": rs.F("str", required=True),
    "registration_date": rs.F("str", required=True),
    "supersedes": rs.F("str", required=True, note="an earlier version of the same master, or none"),
    "note": rs.F("str", nullable=True),
}
REGISTRY_SCHEMA = {"definitions": rs.F("list", required=True, item=_DEFINITION, nullable=True)}

_IMPLEMENTATION = {
    "variable": rs.F("str", required=True, note="a variable_id in this pack's contract"),
    "definition": rs.F("str", required=True, note="a registered definition id"),
    "roles": rs.F("list", required=True, item=rs.F("str"), note="the config source roles this implementation reads"),
    "reviewed_by": rs.F("str", required=True),
    "review_date": rs.F("str", required=True),
    "note": rs.F("str", nullable=True),
}
IMPLEMENTATIONS_SCHEMA = {
    "dataset": rs.F("str", required=True, note="the dataset label the semantic view uses (flatiron, cota, optum_mc)"),
    "implements": rs.F("list", required=True, item=_IMPLEMENTATION, nullable=True),
}


# ------------------------------------------------------------------------------ the register

def read(root=ROOT):
    """(entries, problems) — the register validated against its schema; a file that does not
    validate is returned EMPTY with the reason, never half-read."""
    path = os.path.join(root, REGISTRY)
    if not os.path.isfile(path):
        return [], [f"{REGISTRY}: absent — the register is a governed file; restore it"]
    doc, err = pg.read_yaml(path)
    if err:
        return [], [f"{REGISTRY}: {err}"]
    problems = rs.validate(REGISTRY_SCHEMA, doc or {}, REGISTRY)
    if problems:
        return [], problems
    return list((doc or {}).get("definitions") or []), []


def _masters(root):
    from rwd_tools import semantic_binding as sb                                           # noqa: PLC0415
    inv = sb._inventory()                       # the inventory is the framework's, not the checkout's
    return {str(m.get("name")) for m in (inv.get("master") or []) if m.get("name")}


def checkout_root(pack):
    """The checkout a pack lives in — the nearest ancestor holding governance/DEFINITIONS.yaml — so
    the register is read beside the pack (a temp copy carries its own), never from this module's
    install root. Falls back to the install root when no ancestor carries a register."""
    here = os.path.abspath(pack)
    while True:
        if os.path.isfile(os.path.join(here, REGISTRY)):
            return here
        parent = os.path.dirname(here)
        if parent == here:
            return ROOT
        here = parent


def register_errors(root=ROOT):
    """Why the register does not stand on its own, or []."""
    entries, problems = read(root)
    if problems:
        return problems
    out, seen = [], {}
    masters = _masters(root)
    by_id = {str(e.get("definition_id")): e for e in entries}
    for i, e in enumerate(entries):
        where = f"{REGISTRY}: definitions[{i}]"
        did = str(e.get("definition_id") or "")
        if not ID_RE.match(did):
            out.append(f"{where}: definition_id {did!r} is not <NAMESPACE>:<MASTER>:v<n>")
            continue
        if did in seen:
            out.append(f"{where}: definition_id {did} is minted twice (first at definitions[{seen[did]}]) — mint once, never reuse")
        seen.setdefault(did, i)
        ns, master, ver = did.split(":")
        if str(e.get("master")) != master:
            out.append(f"{where}: master {e.get('master')!r} disagrees with the id's family {master!r}")
        if master not in masters:
            out.append(f"{where}: master {master!r} is not a master family in the variable inventory")
        cui = str(e.get("concept") or "")
        if not CUI_RE.match(cui):
            out.append(f"{where}: concept {cui!r} is not a UMLS CUI (C + seven digits)")
        else:
            try:
                from rwd_tools import semantic_binding as sb                               # noqa: PLC0415
                if sb.umls_enabled() and cui not in (sb.concept_names() or {}):
                    out.append(f"{where}: concept {cui} is not carried by the terminology layer")
            except Exception as exc:                                        # noqa: BLE001
                out.append(f"{where}: the terminology layer could not be consulted ({exc})")
        sig = str(e.get("signature_sha256") or "")
        if not re.fullmatch(r"[0-9a-f]{64}", sig):
            out.append(f"{where}: signature_sha256 is not 64 hex — read it from definition_signature.py, never type it")
        why = pg.not_a_person(str(e.get("registered_by") or ""))
        if why:
            out.append(f"{where}: registered_by: {why}")
        bad = pg.bad_date(str(e.get("registration_date") or ""))
        if bad:
            out.append(f"{where}: registration_date: {bad}")
        sup = str(e.get("supersedes") or "")
        if sup != NONE:
            if sup not in by_id:
                out.append(f"{where}: supersedes {sup!r}, which is not registered")
            else:
                s_ns, s_master, s_ver = sup.split(":") if ID_RE.match(sup) else ("", "", "v0")
                if s_master != master:
                    out.append(f"{where}: supersedes {sup}, a definition of another family — a new family is a new id, not a version")
                elif int(s_ver[1:]) >= int(ver[1:]):
                    out.append(f"{where}: supersedes {sup}, which is not an earlier version")
                if str(by_id[sup].get("signature_sha256")) == sig:
                    out.append(f"{where}: signs the same signature as {sup} — a restatement is not a new version")
    return out


def current(entries):
    """The ids no other entry supersedes — the definitions a pack may implement today."""
    superseded = {str(e.get("supersedes")) for e in entries if str(e.get("supersedes") or NONE) != NONE}
    return [e for e in entries if str(e.get("definition_id")) not in superseded]


# ------------------------------------------------------------------------------ packs

def signed(pack, root=ROOT):
    """[(master, digest)] — the pack's signed definitions, from definition_signature."""
    from rwd_tools import definition_signature as ds                                       # noqa: PLC0415
    rows = ds.signatures(os.path.join(root, pack) if not os.path.isabs(pack) else pack)
    return [(str(r.get("master")), str(r.get("digest"))) for r in rows if r.get("signed") and r.get("master")]


def resolve(pack, root=ROOT):
    """{master: definition_id | None} for every signed definition — by SIGNATURE, never by name.
    A superseded definition still resolves (it IS registered; `superseded_signed` names it);
    None is 'signed, unregistered', which `--propose` turns into the entry a person registers."""
    entries, problems = read(root)
    live = {str(e.get("definition_id")) for e in current(entries)}
    by_sig = {}
    for e in entries:                                   # a current id wins over a superseded twin
        sig, did = str(e.get("signature_sha256")), str(e.get("definition_id"))
        if sig not in by_sig or (did in live and by_sig[sig] not in live):
            by_sig[sig] = did
    out = {}
    for master, digest in signed(pack, root):
        out[master] = by_sig.get(digest)
    return out


def unregistered(pack, root=ROOT):
    return sorted(m for m, did in resolve(pack, root).items() if did is None)


def superseded_signed(pack, root=ROOT):
    """[(master, definition_id, superseded_by)] — the pack's configuration still signs a
    definition the register has moved past."""
    entries, _p = read(root)
    by_id = {str(e.get("definition_id")): e for e in entries}
    newer = {str(e.get("supersedes")): str(e.get("definition_id")) for e in entries
             if str(e.get("supersedes") or NONE) != NONE}
    return [(m, did, newer[did]) for m, did in sorted(resolve(pack, root).items()) if did in newer]


def propose(pack, root=ROOT):
    """The register entries a pack's unregistered signed definitions would add — judgment fields
    left for the person, the version the next free one for that family."""
    entries, _p = read(root)
    versions = {}
    for e in entries:
        did = str(e.get("definition_id") or "")
        if ID_RE.match(did):
            ns, master, ver = did.split(":")
            versions[master] = max(versions.get(master, 0), int(ver[1:]))
    digests = dict(signed(pack, root))
    lines = []
    for master in unregistered(pack, root):
        n = versions.get(master, 0) + 1
        lines += [f"  - definition_id: RWDP:{master}:v{n}", f"    master: {master}", "    concept: TODO  # the UMLS CUI",
                  f"    signature_sha256: {digests[master]}", "    registered_by: TODO", "    registration_date: TODO",
                  f"    supersedes: {('RWDP:' + master + ':v' + str(n - 1)) if n > 1 else NONE}",
                  "    note: TODO  # what this definition measures, and what changed from the version it supersedes"]
    return "\n".join(lines)


def pack_errors(pack, root=ROOT, rel=None):
    """A pack whose signed definitions are not registered — advisory until the pack claims
    Gate 4 approval, refused there by product_gates.configuration_approval_errors (a released
    definition nobody named cannot be reused). `rel` labels the lines when `pack` is absolute."""
    from rwd_services import finding
    out = []
    shown = rel or pack
    missing = unregistered(pack, root)
    if missing:
        out.append(finding("definition_registration_required", f"{shown}: signed definition(s) not in {REGISTRY}: {', '.join(missing)} — "
                   f"python3 platform/tools/definition_registry.py --propose {shown}", gate=4))
    for master, did, by in superseded_signed(pack, root):
        out.append(finding("configuration_definition_superseded", f"{shown}: still signs {did} for {master}, superseded by {by} — move the configuration to the "
                   f"current definition, or register why this cut keeps the old one", gate=4))
    return out


# ------------------------------------------------------------------------------ implementations

def implementations(pack, root=ROOT):
    """(doc, problems) — the pack's config/implementations.yaml, validated; absent is an EMPTY
    statement, not an error."""
    path = os.path.join(root, pack, IMPLEMENTATIONS)
    if not os.path.isfile(path):
        return {}, []
    doc, err = pg.read_yaml(path)
    if err:
        return {}, [f"{pack}/{IMPLEMENTATIONS}: {err}"]
    problems = rs.validate(IMPLEMENTATIONS_SCHEMA, doc or {}, f"{pack}/{IMPLEMENTATIONS}")
    if problems:
        return {}, problems
    return doc or {}, []


def implementation_errors(pack, root=ROOT):
    """Why a pack's implementation claims do not resolve, or []."""
    from rwd_services import finding
    doc, problems = implementations(pack, root)
    if problems or not doc:
        return [finding("implementation_claim_required", problem, gate=4) for problem in problems]
    entries, reg_problems = read(root)
    if reg_problems:
        return [finding("definition_registration_required", problem, gate=4) for problem in reg_problems]
    ids = {str(e.get("definition_id")): e for e in entries}
    live = {str(e.get("definition_id")) for e in current(entries)}
    from rwd_tools import contract_lint as cl                                              # noqa: PLC0415
    cpath = os.path.join(root, pack, "handoff", "FUNCTIONAL_CONTRACT.md")
    variables = {r.variable_id for r in cl.typed_records(cl._read_if(cpath) or "")} if os.path.isfile(cpath) else set()
    cfg_path = os.path.join(root, pack, "config", "data_product.yaml")
    cfg, cerr = pg.read_yaml(cfg_path) if os.path.isfile(cfg_path) else ({}, None)
    roles = set((cfg or {}).get("sources") or {}) if isinstance((cfg or {}).get("sources"), dict) else set()
    resolved = resolve(pack, root)
    out = []
    where0 = f"{pack}/{IMPLEMENTATIONS}"
    for i, imp in enumerate(doc.get("implements") or []):
        where = f"{where0}: implements[{i}]"
        var, did = str(imp.get("variable") or ""), str(imp.get("definition") or "")
        if variables and var not in variables:
            out.append(f"{where}: variable {var!r} is not a record in this pack's contract")
        if did not in ids:
            out.append(f"{where}: definition {did!r} is not registered in {REGISTRY}")
        elif did not in live:
            out.append(f"{where}: definition {did} is superseded — implement the current version or say why in note")
        else:
            master = did.split(":")[1]
            got = resolved.get(master)
            if got is not None and got != did:
                out.append(f"{where}: claims {did} but this pack's configuration signs {got} for {master} — the claim and the config disagree")
        for r in imp.get("roles") or []:
            if roles and str(r) not in roles:
                out.append(f"{where}: role {r!r} is not declared under sources: in config/data_product.yaml")
        why = pg.not_a_person(str(imp.get("reviewed_by") or ""))
        if why:
            out.append(f"{where}: reviewed_by: {why}")
        bad = pg.bad_date(str(imp.get("review_date") or ""))
        if bad:
            out.append(f"{where}: review_date: {bad}")
    return [finding("implementation_claim_required", problem, gate=4) for problem in out]


def propose_implementations(pack, root=ROOT):
    """A config/implementations.yaml draft from what the pack's configuration signs — the person
    supplies the dataset label, the roles read and the review."""
    res = resolve(pack, root)
    lines = ["dataset: TODO  # flatiron | cota | optum_mc — the label the semantic view uses", "implements:"]
    for master, did in sorted(res.items()):
        lines += [f"  - variable: TODO  # the contract variable_id implementing {master}",
                  f"    definition: {did or ('TODO  # not registered yet — --propose ' + pack)}",
                  "    roles: [TODO]  # the sources: roles this implementation reads",
                  "    reviewed_by: TODO", "    review_date: TODO"]
    return "\n".join(lines)


def supports(definition_id, root=ROOT):
    """{packs: [...], datasets: [...]} — who implements this definition: the packs whose
    configuration signs its signature, and the datasets whose implementations file claims it."""
    entries, _p = read(root)
    by_id = {str(e.get("definition_id")): e for e in entries}
    if definition_id not in by_id:
        return None
    sig = str(by_id[definition_id].get("signature_sha256"))
    packs, datasets = [], []
    for pack in sorted(pg.all_packs(root)):
        try:
            if any(d == sig for _m, d in signed(pack, root)):
                packs.append(pack)
        except Exception:                                                   # noqa: BLE001 — an unsignable pack supports nothing
            continue
        doc, problems = implementations(pack, root)
        if doc and not problems:
            for imp in doc.get("implements") or []:
                if str(imp.get("definition")) == definition_id:
                    datasets.append(f"{doc.get('dataset')} ({pack}: {imp.get('variable')})")
    return {"packs": packs, "datasets": datasets}


def check(root=ROOT):
    out = register_errors(root)
    for pack in sorted(pg.all_packs(root)):
        out += implementation_errors(pack, root)
    return out


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    ap.add_argument("--check", action="store_true")
    ap.add_argument("--propose", metavar="PACK")
    ap.add_argument("--propose-implementations", metavar="PACK")
    ap.add_argument("--resolve", metavar="PACK")
    ap.add_argument("--supports", metavar="DEFINITION_ID")
    ap.add_argument("--list", action="store_true")
    ap.add_argument("--root", default=ROOT)
    a = ap.parse_args(argv)
    if a.check:
        errs = check(a.root)
        for e in errs:
            print(e)
        entries, _p = read(a.root)
        packs = [pk for pk in pg.all_packs(a.root) if signed(pk, a.root)]
        # the subject count first, so a reader (and the UAT) can tell "examined and sound" from
        # "nothing registered yet" — an empty register passing is not a pass over anything
        print(f"{len(current(entries))} current definition(s) registered over {len(packs)} signing pack(s); "
              f"{len(errs)} definition register problem(s)")
        return 1 if errs else 0
    if a.propose:
        text = propose(a.propose, a.root)
        print(text or f"{a.propose}: every signed definition is registered")
        return 0
    if a.propose_implementations:
        print(propose_implementations(a.propose_implementations, a.root))
        return 0
    if a.resolve:
        for master, did in sorted(resolve(a.resolve, a.root).items()):
            print(f"{master:28s} {did or 'UNREGISTERED'}")
        return 0
    if a.supports:
        who = supports(a.supports, a.root)
        if who is None:
            print(f"{a.supports} is not a registered definition")
            return 1
        print(f"{a.supports}\n  packs signing it: {', '.join(who['packs']) or 'none'}\n  datasets claiming it: {', '.join(who['datasets']) or 'none'}")
        return 0
    if a.list:
        entries, problems = read(a.root)
        for p in problems:
            print(p)
        for e in current(entries):
            print(f"{e.get('definition_id'):28s} {e.get('master'):22s} {e.get('concept')}  {str(e.get('signature_sha256'))[:12]}")
        print(f"{len(current(entries))} current definition(s), {len(entries) - len(current(entries))} superseded")
        return 1 if problems else 0
    ap.print_help()
    return 2


if __name__ == "__main__":
    from rwd_tools.console import use_utf8
    use_utf8()
    sys.exit(main())
