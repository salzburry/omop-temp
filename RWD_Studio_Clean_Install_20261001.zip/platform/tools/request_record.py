#!/usr/bin/env python3
"""Manage request records: what was asked, what was answered, and when it goes stale.

    python platform/tools/request_record.py --new req-2026-001   # scaffold the record
    python platform/tools/request_record.py --check              # lint every request

A request's output is a number, a table or a slide. Months later someone asks: which
release did this come from, and was it approved at the time? The record answers that:
the question in the requester's words, how the answer was derived, who asked, who
answered, and — through the registry — exactly which release it read.

`--check` also detects staleness: if the cited spec_version has been superseded, a record
still claiming `status: answered` is presenting an old answer as current. The fix is a
person's act — mark it `superseded`, or re-answer against the current cut. The tool never
declares an old answer wrong; it refuses only the claim that it is still current.

Human fields (`requested_by`, `analyst`, dates, any status beyond `open`) are typed by a
person. `--new` writes placeholder markers; `--check` refuses a record that claims to be
answered while a marker still stands in for the person.
"""
from __future__ import annotations

import argparse
import os
import re
import sys

TOOLS = os.path.dirname(os.path.abspath(__file__))
from rwd_services import workspace_root
REPO = str(workspace_root(__file__))

from rwd_tools import product_gates as pg # noqa: E402
from rwd_tools import source_manifest as sm # noqa: E402
from rwd_tools.spec_extract import repo_relative # noqa: E402

WORK = "work"
RECORD = "REQUEST.yaml"
MARK = "REPLACE_ME"
# `open` is the only status a tool may write. Everything past it records that a person did something.
STATUSES = ("open", "answered", "superseded", "withdrawn")
ANSWERED = ("answered", "superseded")
# Fields a person fills. Refused as placeholders on any record claiming to be answered.
# `answered_by` beside `analyst`, distinct on purpose: the analyst derived the answer, the
# answerer stands behind it — and `answered_by` is the field the identity audit watches on this
# surface, which until it existed here could never authenticate anything.
HUMAN_FIELDS = ("requested_by", "requested_date", "analyst", "answered_by", "answered_date")

TEMPLATE = f"""\
# A REQUEST — work that reads an already-released product and creates no new governed table.
#
# It owes `provenance` instead of Gates 1-6 (governance/WORKFLOW.md, "Which gates apply"). The
# citation itself lives in products/registry.yaml under `work:`, not here: one fact, one place.
# This record carries what the citation cannot — the question, the derivation and the answer.
#
# Every {MARK} below is a person's to fill. `--check` refuses a record claiming `answered` while any
# of them is still standing in for the person who answered it.
request_id: {{rid}}
title: "{MARK}"

# The ask, in the REQUESTER's words rather than the analyst's restatement of it. The two drift, and
# when they do it is the restatement that turns out to have answered a different question.
question: >
  {MARK}

requested_by: {MARK}          # a NAMED person, not a team
requested_date: {MARK}        # YYYY-MM-DD
analyst: {MARK}               # who derived the answer, BY NAME
answered_by: {MARK}           # who stands behind the answer, BY NAME (may be the analyst)
answered_date: {MARK}         # YYYY-MM-DD
answer_sha256: {MARK}         # `--digest <id>` prints it - binds the answer to its words

# open -> answered by a person, and later -> superseded when the cited release is replaced.
status: open

# HOW the answer was computed, in enough detail to re-run: a notebook, a query file, a tool
# invocation. A description of the method is not a derivation; a path or a link is.
derivation:
  method: {MARK}              # e.g. notebook | sql | tool
  reference: {MARK}           # path or link to the thing that was actually executed

# WHAT was concluded. `summary` is the sentence that will be quoted; write it as it should be
# quoted, because it will be.
#
# `kind` decides how tightly the answer must be pinned to the data it came from, and it is stated
# rather than guessed: no parser can tell "1234 patients" from a sentence that merely contains a
# number, and a heuristic that tried would be wrong in the direction that matters.
#   quantitative  the answer IS a number, or a set of them. It is only true of one build.
#   descriptive   the answer describes the specification or the method and does not report a count.
result:
  kind: {MARK}                # quantitative | descriptive
  summary: >
    {MARK}

# Does the answer leave the group? An external answer is the one most likely to outlive its cut.
disclosure: {MARK}            # internal | external
"""

# An answer that reports a NUMBER, or that leaves the group, is only true of the exact build it was
# computed on. `cites_release` must then pin that build — `build_id` and/or `manifest_sha256` — and
# not merely the pack, because "prostate 202606" names a specification, and two cuts of it give two
# different counts. A descriptive, internal answer may cite the pack: it describes what the
# specification SAYS, which does not move with the data.
RESULT_KINDS = ("quantitative", "descriptive")


def record_path(rid, root=None):
    return os.path.join(root or REPO, WORK, str(rid), RECORD)


def _requests(root):
    """Registered work objects of kind `request`. The registry is the index; the folder is not."""
    return [w for w in pg.work_entries(root) if str(w.get("kind") or "") == "request"]


def superseded_citations(root, entry):
    """[(product, spec_version, why)] for every citation whose release a later cut replaced.

    Read off the product's own `lineage:` in the registry, which already records `status:
    superseded` and `supersedes:` — the fact exists, nothing new is stored to answer this.
    """
    reg, err = pg.read_yaml(os.path.join(root, "products", "registry.yaml"))
    if err:
        return []
    out = []
    for c in (entry.get("cites_release") or []):
        if not isinstance(c, dict):
            continue
        slug, ver = str(c.get("product") or ""), str(c.get("spec_version") or "")
        for t_ in (reg.get("tumors") or []):
            if not isinstance(t_, dict) or str(t_.get("slug") or "") != slug:
                continue
            for lin in (t_.get("lineage") or []):
                if not isinstance(lin, dict) or str(lin.get("spec_version") or "") != ver:
                    continue
                if str(lin.get("status") or "") == "superseded":
                    later = [str(l.get("spec_version")) for l in (t_.get("lineage") or [])
                             if isinstance(l, dict) and str(l.get("supersedes") or "") == ver]
                    out.append((slug, ver, "replaced by " + (", ".join(later) or "a later cut")))
    return out


def _canonical(node):
    """Mappings sorted, scalars whitespace-collapsed, lists in order — reflow is not change."""
    if isinstance(node, dict):
        return {str(k): _canonical(node[k]) for k in sorted(node, key=str)}
    if isinstance(node, (list, tuple)):
        return [_canonical(v) for v in node]
    return " ".join(str(node).split())


def answer_digest(doc, cites=None):
    """sha256 over the ANSWER CONTENT: question, derivation, result, disclosure — and the
    citations the answer stood on, when the caller passes them.

    `answered_by` binds a person to the answer; this binds the answer to its words and to its data (thirty-second: the registry citations were outside the digest,
    so the release an answer claimed to have read could be re-pointed under the sealed
    words). The citations live in the registry, so validation folds them in from the entry
    and `--digest` resolves the entry itself."""
    import hashlib # noqa: PLC0415
    import json # noqa: PLC0415
    payload = {k: _canonical((doc or {}).get(k))
               for k in ("question", "derivation", "result", "disclosure")}
    if cites is not None:
        payload["cites_release"] = _canonical(sorted(
            (json.dumps(_canonical(c), sort_keys=True) for c in cites if isinstance(c, dict))))
    blob = json.dumps(payload, sort_keys=True, ensure_ascii=False, separators=(",", ":"))
    return hashlib.sha256(blob.encode("utf-8")).hexdigest()


def event_payload(doc, cites):
    """The COMPLETE decision content of a request, as the ledger seals it — the question,
    the answer, its digest, every lifecycle field, and the citations the answer stood on."""
    keep = ("request_id", "title", "question", "status", "requested_by", "requested_date",
            "analyst", "answered_by", "answered_date", "answer_sha256", "disclosure",
            "withdrawn_by", "withdrawn_date", "withdraw_reason",
            "superseded_marked_by", "superseded_date", "superseded_by")
    out = {k: str(doc.get(k) or "") for k in keep}
    out["derivation"] = _canonical(doc.get("derivation") or {})
    out["result"] = _canonical(doc.get("result") or {})
    out["cites_release"] = _canonical(sorted(
        (str(sorted((c or {}).items())) for c in (cites or []) if isinstance(c, dict))))
    return out


def record_event(root, rid, now_utc, require_citable=True):
    """Seal this request's current state into the event ledger — the person's act, recorded.

    SIDE BY SIDE with the record checks. The ACTOR IS TRANSCRIBED from the attribution the
    person already committed — answered_by, withdrawn_by, or superseded_marked_by by
    status — never a flag. Returns (event, None) or (None, why).

    `require_citable` is the provenance gate governance/ACTIONS.yaml declares for this act ('the
    request cites a releasable release'); a unit test of the ledger mechanics on a fixture pack that
    can never be releasable passes False and says so."""
    from rwd_tools import event_ledger as el # noqa: PLC0415
    path = record_path(rid, root)
    if not os.path.exists(path):
        return None, f"{rid}: no record at {repo_relative(path, root)} — scaffold it with --new {rid}"
    doc, err = pg.read_yaml(path)
    if err:
        return None, f"{rid}: {err}"
    entry = next((w for w in pg.work_entries(root)
                  if str(w.get("id") or "") == rid), None) or {"id": rid}
    errs = [e for e in record_errors(root, entry)
            if "moved past its ledger" not in e and "holds no lifecycle event" not in e]
    # PROVENANCE IS THE REQUEST'S ONE OBLIGATION, and the seal used to skip it: `--check`
    # refused the citation (the pack is not releasable) and `--record-event` sealed the answer
    # anyway, an immutable event over a request that inherits no approval (thirteenth pass).
    if require_citable:
        errs += [f"cites_release: {e}" for e in sm.citation_errors(root, entry)]
    if errs:
        return None, (f"{rid}: the record does not validate, and the ledger seals only "
                      f"valid states - fix these first:\n  - " + "\n  - ".join(errs))
    status = str(doc.get("status") or "")
    who_by_status = {"answered": doc.get("answered_by"),
                     "withdrawn": doc.get("withdrawn_by"),
                     "superseded": doc.get("superseded_marked_by")}
    if status not in who_by_status:
        return None, f"{rid}: status {status!r} is not a recordable transition"
    who = who_by_status[status]
    if pg.unstated(who):
        return None, (f"{rid}: the record names nobody for its {status} - the event's actor "
                      f"is transcribed from the record, never typed by a tool")
    payload = event_payload(doc, entry.get("cites_release") or [])
    obj = str(doc.get("object_uuid") or "") or None
    prev, action, trust = "", status, "typed"
    if obj:
        try:
            _seq, prev = el.head_of(root, obj)
        except el.LedgerError as e:
            return None, str(e)
    else:
        # a genesis over a record git already holds is an IMPORT, not a new act — the
        # committed attribution keeps its limited trust (safeguard 8, extended by the
        # earlier review)
        import subprocess # noqa: PLC0415
        rel_file = repo_relative(path, root)
        try:
            r = subprocess.run(["git", "-C", root, "log", "-1", "--format=%H", "--",
                                rel_file], capture_output=True, text=True, encoding="utf-8")
            if r.returncode == 0 and r.stdout.strip():
                action, trust = "legacy_imported", "unauthenticated_legacy"
        except OSError:
            pass
    actor = {"subject_id": str(who), "identity_provider": "typed",
             "display_name": str(who), "role": "recorded-in-request",
             "trust_level": trust}
    try:
        event = el.append_event(
            root, object_uuid=obj, object_kind="request", action=action, actor=actor,
            occurred_at=now_utc, payload=payload,
            expected_previous_event_sha256=prev,
            idempotency_key=f"{rid}:{status}:{el.payload_digest(payload)[:16]}")
    except el.LedgerError as e:
        return None, f"{rid}: {e}"
    if not obj:
        doc["object_uuid"] = event["object_uuid"]
        # INSERTED, NOT DUMPED: a safe_dump rewrote the person's record and stripped every guidance
        # comment the scaffold wrote (thirteenth pass, J4); one line lands after the id line
        with open(path, encoding="utf-8") as fh:
            text = fh.read()
        line = f"object_uuid: {event['object_uuid']}   # the ledger object this record owns; tool-written, never moved\n"
        m = re.search(r"^request_id\s*:.*$", text, re.M)
        text = (text[:m.end() + 1] + line + text[m.end() + 1:]) if m else line + text
        with open(path, "w", encoding="utf-8", newline="\n") as fh:
            fh.write(text)
    return event, None


def ledger_parity_errors(root, entry):
    """[why this record disagrees with its ledger], or []. The side-by-side rule."""
    from rwd_tools import event_ledger as el # noqa: PLC0415
    rid = str(entry.get("id") or "")
    doc, err = pg.read_yaml(record_path(rid, root))
    if err or not isinstance(doc, dict):
        return []
    obj = str(doc.get("object_uuid") or "")
    if not obj:
        # PARTICIPATION IS HISTORICALLY IRREVERSIBLE: a record whose
        # committed history ever carried an object_uuid cannot shed it to switch parity off
        ever = el.ever_carried_object_uuid(root, os.path.relpath(record_path(rid, root), root))
        if ever == "SHALLOW":
            return [f"{rid}: git history is SHALLOW, so whether this record was ever "
                    f"sealed cannot be determined - fetch full history (fetch-depth: 0)"]
        if ever:
            return [f"{rid}: history records an object_uuid this record no longer "
                    f"carries - ledger participation, once begun, never ends; restore it"]
        return []
    # IDENTITY IS PINNED AT FIRST COMMIT (earlier review: re-pointing a sealed record
    # at a freshly minted twin object with an identical payload kept parity green)
    pin = el.first_committed_object_uuid(root, repo_relative(record_path(rid, root), root))
    if pin == "SHALLOW":
        return [f"{rid}: git history is SHALLOW, so the pinned identity cannot be "
                f"verified - fetch full history (fetch-depth: 0)"]
    if pin and pin != obj:
        return [f"{rid}: carries object_uuid {obj} but history pinned {pin} at first "
                f"commit - identity never re-homes; a swapped uuid grafts the record onto "
                f"another object's history"]
    if not os.path.isdir(os.path.join(root, el.EVENTS_DIR)):
        # a checkout with NO ledger at all is an exercise copy of a sealed record - parity
        # stands down; deleting the ledger from a REAL root is the ledger check's own
        # refusal (git history decides which case this is, there)
        return []
    sealed = None
    for _seq, fname in el._event_files(root, obj):
        ev, everr = el.read_event(root, obj, fname)
        if not everr and isinstance(ev, dict) and ev.get("action") != "attested":
            sealed = ev
    if sealed is None:
        return [f"{rid}: names ledger object {obj} which holds no lifecycle event"]
    live = el.payload_digest(event_payload(doc, entry.get("cites_release") or []))
    if str(sealed.get("payload_sha256")) != live:
        return [f"{rid}: the record has moved past its ledger (sealed "
                f"{str(sealed.get('payload_sha256'))[:12]}…, live {live[:12]}…) - edit, "
                f"then RECORD the transition: request_record --record-event {rid}"]
    return []


def record_errors(root, entry):
    """[why this request's record is not usable], or []."""
    rid = str(entry.get("id") or "")
    path = record_path(rid, root)
    rel = os.path.relpath(path, root)
    if not os.path.exists(path):
        return [f"{rid}: no record at {rel} — a registered request with no record is a citation "
                f"nobody can read; scaffold it with --new {rid}"]
    doc, err = pg.read_yaml(path)
    if err:
        return [f"{rel}: {err}"]
    out = []
    if str(doc.get("request_id") or "") != rid:
        out.append(f"{rel}: request_id {doc.get('request_id')!r} does not match the registry id "
                   f"{rid!r} — the record and its registration must name the same object")
    status = str(doc.get("status") or "")
    if status not in STATUSES:
        out.append(f"{rel}: status {status!r} is not one of {list(STATUSES)}")

    if status in ANSWERED:
        # EVERY marker, not a remembered list of fields. The header has always said a record cannot
        # claim to be answered while carrying one; the check read four human fields plus two nested
        # ones, so `title: REPLACE_ME` and a scaffold `question:` — the two things a reader
        # QUOTES — passed as answered. A field list is a copy of the template that ages on its own.
        for where in pg.marker_paths(doc, MARK):
            out.append(f"{rel}: status is {status!r} and `{where}` still holds {MARK}. Every field "
                       f"in an answered record is somebody's answer; a marker there is the scaffold "
                       f"speaking in their place.")
        # Only now do the human fields have to be answers. An `open` request legitimately has an
        # analyst and an answer date it does not yet know.
        for f in HUMAN_FIELDS:
            v = doc.get(f)
            if pg.unstated(v) or MARK in str(v):
                out.append(f"{rel}: status is {status!r} but {f} is still {str(v)!r} — a record "
                           f"cannot claim to be answered while a marker stands in for the person "
                           f"who answered it")
            #...and the two that name PEOPLE have to name one. The scaffold's own comment says "a
            # NAMED person, not a team" beside `requested_by`, and nothing enforced it, so
            # `analyst: DataExpert` answered "who is accountable for this result" with a function. Same
            # `not_a_person` every gate uses; the dates fall through it untouched.
            elif f.endswith("_by") or f == "analyst":
                bad = pg.not_a_person(v)
                if bad:
                    out.append(f"{rel}: `{f}`: {bad}")
        for f in ("requested_date", "answered_date"):
            if not pg.unstated(doc.get(f)) and pg.bad_date(doc.get(f)):
                out.append(f"{rel}: {f} {doc.get(f)!r} is not a YYYY-MM-DD date")
        for path_ in (("derivation", "reference"), ("result", "summary")):
            node = doc
            for k in path_:
                node = (node or {}).get(k) if isinstance(node, dict) else None
            if pg.unstated(node) or MARK in str(node):
                out.append(f"{rel}: status is {status!r} but {'.'.join(path_)} is unfilled — an "
                           f"answer with no derivation cannot be re-run, and one with no summary "
                           f"is not an answer")
        if str(doc.get("disclosure") or "") not in ("internal", "external"):
            out.append(f"{rel}: disclosure {doc.get('disclosure')!r} must be internal or external")

        # THE DERIVATION'S METHOD, which was never checked. `reference` was required and `method`
        # was not, so an answered record could carry a path with nothing saying what was run over
        # it — and a record with no `derivation` key at all passed, because the walk below returned
        # None and only `reference` was inspected.
        deriv = doc.get("derivation")
        if not isinstance(deriv, dict):
            out.append(f"{rel}: status is {status!r} with no `derivation:` block — an answer whose "
                       f"computation is unrecorded cannot be re-run or checked")
        elif pg.unstated(deriv.get("method")) or MARK in str(deriv.get("method")):
            out.append(f"{rel}: status is {status!r} but derivation.method is "
                       f"{deriv.get('method')!r} — a reference without a method says where the "
                       f"work lives, not what was run")

        # BUILD IDENTITY, for the answers that are only true of one build.
        kind = str((doc.get("result") or {}).get("kind") or "") if \
            isinstance(doc.get("result"), dict) else ""
        if kind not in RESULT_KINDS:
            out.append(f"{rel}: result.kind {kind or '(unstated)'!r} must be one of "
                       f"{list(RESULT_KINDS)} — whether the answer is a NUMBER decides how tightly "
                       f"it must be pinned, and it is stated rather than guessed")
        external = str(doc.get("disclosure") or "") == "external"
        if kind == "quantitative" or external:
            why = ("reports a number" if kind == "quantitative" else "leaves the group")
            cites = [c for c in (entry.get("cites_release") or []) if isinstance(c, dict)]
            unpinned = [c for c in cites
                        if not (str(c.get("build_id") or "").strip()
                                or str(c.get("manifest_sha256") or "").strip())]
            if not cites:
                out.append(f"{rel}: status is {status!r} and the answer {why}, but the registry "
                           f"entry cites no release at all — there is nothing to say which data "
                           f"produced it")
            for c in unpinned:
                out.append(f"{rel}: the answer {why}, and it cites {c.get('product')} "
                           f"{c.get('spec_version')} at PACK level. A specification is not a cut: "
                           f"two builds of it give two different answers. Pin `build_id` and/or "
                           f"`manifest_sha256` on the citation in products/registry.yaml.")

    if status in ANSWERED:
        # THE ANSWER IS BOUND TO ITS WORDS: `answered_by` authenticated
        # the person while the summary stayed editable under the unmoved attribution. The
        # digest covers question, derivation, result and disclosure; `--digest <id>` prints it.
        recorded = str(doc.get("answer_sha256") or "")
        live = answer_digest(doc, entry.get("cites_release") or [])
        if pg.unstated(recorded) or MARK in recorded:
            out.append(f"{rel}: status is {status!r} with no answer_sha256 — an answer nothing "
                       f"digests can be edited under its author's name; record `--digest {rid}`")
        elif not re.fullmatch(r"[0-9a-f]{64}", recorded):
            out.append(f"{rel}: answer_sha256 {recorded[:20]!r} is not a sha256")
        elif recorded != live:
            out.append(f"{rel}: the answer hashes to {live[:12]}… but answer_sha256 records "
                       f"{recorded[:12]}… — the answer changed after it was recorded. If the "
                       f"change is real, it is a NEW answer: re-record the digest and the "
                       f"person; if it is not, restore the answer as given.")
        #...and it cannot precede its own question.
        rq, ad = str(doc.get("requested_date") or ""), str(doc.get("answered_date") or "")
        if rq and ad and not pg.bad_date(rq) and not pg.bad_date(ad) and ad < rq:
            out.append(f"{rel}: answered_date {ad} precedes requested_date {rq} — an answer "
                       f"dated before its question describes a different history")

    # SUPERSESSION IS A TRANSITION WITH A RECORD (earlier review: `status: superseded`
    # required no actor, date, reason or replacement — the one status the staleness rule
    # itself tells people to set was the one nobody had to stand behind).
    if status == "superseded":
        if pg.unstated(doc.get("superseded_marked_by")) \
                or MARK in str(doc.get("superseded_marked_by")):
            out.append(f"{rel}: status is 'superseded' but superseded_marked_by is unstated — "
                       f"recording that an answer aged out is a person's act")
        else:
            bad = pg.not_a_person(doc.get("superseded_marked_by"))
            if bad:
                out.append(f"{rel}: `superseded_marked_by`: {bad}")
        if pg.unstated(doc.get("superseded_date")) or pg.bad_date(doc.get("superseded_date")):
            out.append(f"{rel}: status is 'superseded' but superseded_date "
                       f"{doc.get('superseded_date')!r} is not a YYYY-MM-DD date")
        if pg.unstated(doc.get("superseded_by")):
            out.append(f"{rel}: status is 'superseded' with no superseded_by — name what "
                       f"replaces this answer (the re-answered request id, or the current "
                       f"cut), or the reader cannot find the number that IS current")

    # A WITHDRAWAL IS AN ACT WITH AN ACTOR (earlier review: a record holding only an id
    # and `status: withdrawn` validated clean — a status nobody stands behind is a free edit).
    if status == "withdrawn":
        if pg.unstated(doc.get("withdrawn_by")) or MARK in str(doc.get("withdrawn_by")):
            out.append(f"{rel}: status is 'withdrawn' but withdrawn_by is unstated — "
                       f"withdrawing a request is a person's act")
        else:
            bad = pg.not_a_person(doc.get("withdrawn_by"))
            if bad:
                out.append(f"{rel}: `withdrawn_by`: {bad}")
        if pg.unstated(doc.get("withdrawn_date")) or pg.bad_date(doc.get("withdrawn_date")):
            out.append(f"{rel}: status is 'withdrawn' but withdrawn_date "
                       f"{doc.get('withdrawn_date')!r} is not a YYYY-MM-DD date")
        if pg.unstated(doc.get("withdraw_reason")) or MARK in str(doc.get("withdraw_reason")):
            out.append(f"{rel}: status is 'withdrawn' with no withdraw_reason — a question "
                       f"retired without a reason looks identical to one suppressed")
        # THE QUESTION SURVIVES ITS WITHDRAWAL (earlier review: withdrawing could erase
        # the record down to an id and a status — retiring a question is an act ABOUT the
        # question, and an act about nothing is unreviewable).
        for f in ("title", "question", "requested_by", "requested_date"):
            if pg.unstated(doc.get(f)):
                out.append(f"{rel}: status is 'withdrawn' but {f} is unstated — the record of "
                           f"what was withdrawn, by whom it was asked and when, stays; a "
                           f"withdrawal that erases its question is a deletion wearing a status")
        wd, rq = str(doc.get("withdrawn_date") or ""), str(doc.get("requested_date") or "")
        if wd and rq and not pg.bad_date(wd) and not pg.bad_date(rq) and wd < rq:
            out.append(f"{rel}: withdrawn_date {wd} precedes requested_date {rq} — a question "
                       f"cannot be withdrawn before it was asked")

    # THE STALENESS RULE. Not "the old answer was wrong" — "this record still presents it as
    # current". `superseded` and `withdrawn` already say a person knows.
    stale = superseded_citations(root, entry)
    if stale and status == "answered":
        for slug, ver, why in stale:
            out.append(f"{rel}: answers against {slug} {ver}, which is superseded ({why}). Set "
                       f"status: superseded to record that this is known, or re-answer against the "
                       f"current cut — an answered record asserts the answer is still current.")
    return out


def check(root=None):
    """[(request_id, [errors])] for every registered request."""
    root = root or REPO
    return [(str(w.get("id") or "?"), record_errors(root, w) + sm.citation_errors(root, w)
             + ledger_parity_errors(root, w) + _scope_errors(root, str(w.get("id") or "?")))
            for w in _requests(root)]


def _scope_errors(root, rid):
    """The protocol-scope errors about THIS request (a request under a draft or closed protocol,
    or one citing outside its protocol) — reported here too, because the person who owns the
    request runs this tool, not protocol_record (thirteenth pass, J6)."""
    try:
        from rwd_tools import protocol_record as _pr                                        # noqa: PLC0415
        return [e for e in _pr.request_scope_errors(root) if f"{rid}:" in e or f" {rid} " in e]
    except Exception:                                                        # noqa: BLE001 - the other tool's failure is its own
        return []


def main(argv):
    ap = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    ap.add_argument("--new", metavar="ID", help="scaffold work/<ID>/REQUEST.yaml")
    ap.add_argument("--record-event", metavar="ID",
                    help="seal this request's current state into the event ledger - the "
                         "actor is transcribed from the record's own signed attribution")
    ap.add_argument("--digest", metavar="ID",
                    help="print the sha256 of that request's answer content (question, "
                         "derivation, result, disclosure) — what answer_sha256 records")
    ap.add_argument("--check", action="store_true", help="exit non-zero on any error")
    a = ap.parse_args(argv)

    if a.record_event is not None:
        import datetime as _dt # noqa: PLC0415
        now = _dt.datetime.now(_dt.timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
        event, why = record_event(REPO, a.record_event.strip(), now)
        if why:
            print(f"REFUSED - {why}", file=sys.stderr)
            return 1
        if str(event.get("occurred_at")) != now:           # an idempotent replay wrote nothing (thirteenth pass)
            print(f"already sealed {event['object_uuid']} seq {event['seq']} ({event['action']}) on "
                  f"{event.get('occurred_at')} - nothing new recorded")
            return 0
        print(f"sealed {event['object_uuid']} seq {event['seq']} ({event['action']}) - "
              f"event {event['event_sha256'][:16]}…  commit governance/events/ with the "
              f"record")
        return 0

    # ONE import for the whole function: a later branch-local `import product_gates as pg` made
    # `pg` local to main(), so this earlier branch raised UnboundLocalError on every call — the
    # documented `--digest` CLI never worked (external audit, 2026-09-02; the function it wraps
    # was tested, the path to it was not).
    from rwd_tools import product_gates as pg  # noqa: PLC0415
    if a.digest is not None:
        rid = a.digest.strip()
        if not os.path.exists(record_path(rid)):
            print(f"REFUSED — {rid}: no record at work/{rid}/REQUEST.yaml — scaffold it with --new {rid}", file=sys.stderr)
            return 1
        doc, err = pg.read_yaml(record_path(rid))
        if err:
            print(f"REFUSED — {err}", file=sys.stderr)
            return 1
        entry = next((w for w in pg.work_entries(REPO)
                      if str(w.get("id") or "") == rid), {})
        print(answer_digest(doc, entry.get("cites_release") or []))
        return 0

    # `is not None`, not truthiness: `--new ""` is a request to scaffold that must be REFUSED, and
    # under a truthiness test it fell through and silently ran the checker instead — a flag quietly
    # becoming a different command is how a script reports success for work it never did.
    if a.new is not None:
        rid = a.new.strip()
        # the CENTRAL grammar (probe wave: this check blocked '/' but not '..', and `--new..`
        # scaffolded ABOVE work/ - every work id goes through product_gates.safe_work_id now)
        ok, err = pg.safe_work_id(rid)
        if not ok:
            print(f"REFUSED — {err}", file=sys.stderr)
            return 1
        path = record_path(rid)
        if pg.kind_for(REPO, rid) == "product":
            print(f"REFUSED — {rid!r} is a product slug (products/registry.yaml): one name, one object; nothing written",
                  file=sys.stderr)
            return 1
        if os.path.exists(path):
            print(f"REFUSED — {os.path.relpath(path, REPO)} already exists; a record is not "
                  f"regenerated, it is edited", file=sys.stderr)
            return 1
        os.makedirs(os.path.dirname(path), exist_ok=True)
        with open(path, "w", encoding="utf-8", newline="") as fh:
            fh.write(TEMPLATE.format(rid=rid))
        print(f"wrote {os.path.relpath(path, REPO)}")
        print(f"Now: answer every {MARK}, and register the request in products/registry.yaml under "
              f"`work:` with the release it reads — the citation lives there, not in the record.")
        return 0

    rows = check()
    if not rows:
        print("0 request(s) registered — products/registry.yaml has no `work:` entry of kind "
              "request")
        return 0
    bad = 0
    for rid, errs in rows:
        bad += len(errs)
        print(f"{rid:<30} " + ("OK" if not errs else f"{len(errs)} error(s)"))
        for e in errs:
            print(f"    {e}")
    print(f"\n{len(rows)} request(s); {bad} error(s)")
    return 1 if (a.check and bad) else 0


if __name__ == "__main__":
    from rwd_tools.console import use_utf8
    use_utf8()
    sys.exit(main(sys.argv[1:]))
