#!/usr/bin/env python3
"""Project the governed pack into standards-based RDF — JSON-LD with SKOS, PROV-O and light OWL.

    python3 platform/tools/semantic_export.py <pack> --base-iri https://... --out X.jsonld
    python3 platform/tools/semantic_export.py <pack> --base-iri https://... --check X.jsonld

WHAT THIS IS FOR. An enterprise knowledge graph wants concepts with stable identifiers, labels
and synonyms (SKOS), a little formal structure about how things relate (OWL), and lineage
naming what was derived from what, by whom (PROV-O). This repository already holds all of that,
in the artifacts the gates read. This tool RE-EXPRESSES it in those vocabularies so the meaning
travels — and it does so by generation, never by hand.

THE CANONICAL RULE REMAINS THE AUTHORITY. Git and the governed YAML remain the
authoring surface and the executable authority: they are what diffs, what a person approves,
what CI verifies and what the engine runs. This export is a READ-ONLY PROJECTION of that, the
way a published view is a projection of a table. The optional semantic execution service can
resolve an exact saved graph's rule digests back to current approved canonical payloads and
prepare the normal configuration proposal. It cannot import a different rule or approval.
No graph is required at build time. A second hand-maintained knowledge base is precisely
the failure this avoids: two places to state one fact is two places to state it differently.

APPROVED CONTENT ONLY, AND THE EXCLUSIONS ARE COUNTED. A record whose `requirement` status is
anything but `approved` is a draft — someone's work in progress, not a statement this
organisation makes. Publishing drafts into a graph other teams query is how a proposal becomes a
fact by being read. So drafts are withheld, and the run REPORTS how many and in which state,
because an empty export and a filtered one must never look alike. A pack with nothing approved
yet exports an empty graph and says so.

THE NAMESPACE IS NOT INVENTED HERE. `--base-iri` is required and has no default: minting an
identifier namespace is an act of whoever owns identifiers in the organisation, and a tool that
quietly chose `https://example.org/...` would put unowned identifiers into an enterprise graph.
Where `governance/NAME_LIFECYCLE.yaml` records an IRI already minted for a name, THAT identifier
is used instead of one composed here — which is what the lifecycle file's `iri:` column is for.

TWO LEVELS OF IDENTITY, NEVER COLLAPSED. A CONCEPT (`.../concept/rwpfs`) is the durable idea. An
IMPLEMENTATION (`.../implementation/prostate-202606-RWPFS`) is one product's exact definition of
it, bound to a spec digest and a config block. They are different subjects: two products may
implement one concept and compute it differently, and saying so is the honest shape. This export
therefore never asserts `owl:sameAs` or `skos:exactMatch` between implementations — equivalence
across datasets is a recorded human ruling in `governance/EQUIVALENCE_RULINGS.yaml`, and only a
ruled pair is exported as a stated equivalence, carrying its decision id and ruler.

DETERMINISTIC. Sorted keys, stable node order, and no clock unless `--as-of` supplies one, so
`--check` means "is this current" rather than "was this regenerated on the same machine".

stdlib + the repo's own readers. No RDF library: JSON-LD is JSON, and a dependency here would be
a dependency in every environment that regenerates it.
"""
from __future__ import annotations

import argparse
import json
import os
import re
import sys

TOOLS = os.path.dirname(os.path.abspath(__file__))
PLATFORM = os.path.dirname(TOOLS)
from rwd_services import workspace_root
ROOT = str(workspace_root(__file__))

from rwd_tools import contract_lint as cl # noqa: E402
from rwd_tools import naming_registry as nr # noqa: E402
from rwd_tools import receipt as rc # noqa: E402
from rwd_tools import rule_review # noqa: E402
from rwd_tools import semantic_view as sv # noqa: E402
from rwd_tools.spec_extract import repo_relative # noqa: E402

# The W3C vocabularies this projection speaks, at their published namespaces. `rwdp:` is the only
# local one — the terms this platform has that no standard vocabulary carries (a source role, a
# spec digest, an adapter binding), kept in one namespace so a consumer can tell instantly which
# terms are standard and which are ours.
CONTEXT = {
    "skos": "http://www.w3.org/2004/02/skos/core#",
    "prov": "http://www.w3.org/ns/prov#",
    "owl": "http://www.w3.org/2002/07/owl#",
    "rdfs": "http://www.w3.org/2000/01/rdf-schema#",
    "dct": "http://purl.org/dc/terms/",
    "xsd": "http://www.w3.org/2001/XMLSchema#",
}

APPROVED = "approved"

# A BOUND CONCEPT IS UMLS'S OWN, NOT ONE MINTED HERE. `C0600139` already has a resolvable
# identifier; composing a second under our namespace is the duplicate identity the mint-once rule
# exists to prevent, and `_concept_iri` refuses it one layer up for the same reason.
UMLS_CONCEPT_IRI = "https://uts.nlm.nih.gov/uts/umls/concept/"


def _iri(base, *parts):
    return "/".join([base.rstrip("/")] + [str(p).strip("/") for p in parts])


def _slug(text):
    """A stable, url-safe segment for a name this repository did not mint an identifier for."""
    keep = [c.lower() if (c.isalnum() or c == "-") else "-" for c in str(text or "").strip()]
    return re.sub(r"-+", "-", "".join(keep)).strip("-") or "unnamed"


def _dataset_iri(base, name):
    return _iri(base, "dataset", _slug(name))


def _dataset_node(base, name):
    """A delivery as a RESOURCE. Named datasets were literals, so one delivery spelled two ways
    was two things and nothing could be said about either."""
    if not name:
        return None
    return {"@id": _dataset_iri(base, name), "@type": "rwdp:Dataset",
            "rdfs:label": str(name)}


def _agent_node(base, name):
    """A ruler as a prov:Agent. PROV-O attributes to a resource, never to a person's name as text.

    THE IDENTIFIER IS LOCAL AND SAYS SO. This mints `.../agent/<slug>` from a name because that is
    all the register holds — it is NOT an enterprise person identifier, and where one exists it
    should replace this. A local identifier that a reader can see is local beats a literal that
    silently pretends two different people with one name are the same."""
    if not name:
        return None
    return {"@id": _iri(base, "agent", _slug(name)), "@type": "prov:Person",
            "rdfs:label": str(name)}


def _lifecycle_index():
    """{name: entry} from the governed lifecycle file — the minted IRIs and the retirements."""
    entries, _problems = nr.lifecycle()
    return {str(e["name"]).strip().lower(): e for e in entries}


def _concept_iri(base, name, life):
    """The concept's identifier: the one a person recorded if there is one, else composed here.

    Using the recorded IRI is the point of the lifecycle file's `iri:` column — an identifier
    minted in the enterprise vocabulary is the SAME concept, and composing a second one here
    would create exactly the duplicate identity the mint-once rule exists to prevent.
    """
    e = life.get(str(name).lower()) or {}
    # ONE SLUG, shared with `template()`. The two paths spelled the same concept differently —
    # `str(name).lower()` here and `_slug(name)` there — so `concept/ecog_ps` and
    # `concept/ecog-ps` were minted for one idea, both declaring `skos:inScheme` the SAME scheme,
    # for 29 of the 37 master families. A graph that asserts two identifiers for one concept and
    # files them under one scheme is worse than one that asserts neither.
    #
    # `_slug` wins because hyphens are the conventional IRI form and nothing is pinned to the
    # other: `NAME_LIFECYCLE.yaml` records no minted `iri:` yet, and no product has passed a gate,
    # so no published identifier moves. A recorded IRI still takes precedence — that column is the
    # whole point of the lifecycle file.
    return str(e.get("iri") or _iri(base, "concept", _slug(name)))


def _status_of(entry):
    return cl.requirement(entry["status"])


def _product_node(base, pack, cfg_roles, tumor, spec_version):
    return {
        "@id": _iri(base, "product", f"{tumor}-{spec_version}"),
        "@type": ["prov:Entity", "rwdp:DataProduct"],
        "skos:prefLabel": f"{tumor} {spec_version}",
        "rwdp:tumour": tumor,
        "rwdp:specVersion": spec_version,
        "rwdp:pack": repo_relative(pack),
        "rwdp:usesSourceRole": sorted(cfg_roles),
    }


def _build_activity(base, tumor, spec_version, build):
    """PROV-O's Activity for the run that produced the data — omitted entirely when no governed
    build is recorded, because an activity node with empty fields asserts that something ran."""
    if not build.get("recorded"):
        return None
    node = {
        "@id": _iri(base, "build", f"{tumor}-{spec_version}-{build.get('refresh')}"),
        "@type": "prov:Activity",
        "rwdp:engineVersion": build.get("engine_version"),
        "rwdp:gitCommit": build.get("git_commit"),
        "rwdp:outputTable": build.get("output_table"),
        "rwdp:runStatus": build.get("status"),
    }
    if build.get("built_at"):
        node["prov:endedAtTime"] = {"@value": build["built_at"], "@type": "xsd:dateTime"}
    return {k: v for k, v in node.items() if v not in (None, "")}


def _concept_node(base, vid, concept, scheme, life):
    """The durable idea, as SKOS — and a retirement in the vocabulary that has terms for it."""
    node = {"@id": concept, "@type": "skos:Concept",
            "skos:prefLabel": vid, "skos:inScheme": {"@id": scheme}}
    lc = life.get(vid.lower()) or {}
    if str(lc.get("status") or "") == "deprecated":
        node["owl:deprecated"] = True
        if lc.get("replaced_by") and str(lc["replaced_by"]).lower() != "none":
            node["dct:isReplacedBy"] = {"@id": _concept_iri(base, lc["replaced_by"], life)}
    return node


def _record_nodes(base, e, concept, product, activity, tumor, spec_version):
    """One approved record as [implementation, spec-item...]: what this product does with the
    concept, and the rows it was written from.

    `skos:definition` carries the CONTRACT's interpretation, never the specification's verbatim
    words — the requirement text is the sponsor's document and stays in the governed pack, cited
    by row id. A projection that carried it would widen who reads authored material without
    anyone deciding to.
    """
    vid = e["variable_id"]
    refs = sorted(e["spec"]["refs"] or [])
    impl = {
        "@id": _iri(base, "implementation", f"{tumor}-{spec_version}-{vid}"),
        "@type": ["prov:Entity", "rwdp:Implementation"],
        "rwdp:implements": {"@id": concept},
        "rwdp:forProduct": {"@id": product["@id"]},
        "skos:prefLabel": f"{vid} in {tumor} {spec_version}",
        "skos:definition": (e["derivation"] or "").strip() or None,
        "rwdp:specDigest": e["spec"]["digest"],
        "rwdp:configRef": sorted(r for r, _f in e["executable"]),
        "prov:wasDerivedFrom": [{"@id": _iri(base, "spec-item", tumor, spec_version, s)}
                                for s in refs],
    }
    if activity:
        impl["prov:wasGeneratedBy"] = {"@id": activity["@id"]}
    if e["decisions"]:
        impl["rwdp:dependsOnDecision"] = sorted(e["decisions"])
    if e.get("reviewed_rule"):
        from rwd_tools import reviewed_variable_record as reviewed
        projection = reviewed.semantic_projection(e["reviewed_rule"])
        impl["rwdp:scientificRuleDigest"] = projection["rule_digest"]
        impl["rwdp:scientificRule"] = reviewed.encode(projection).decode("utf-8")
    out = [{k: v for k, v in impl.items() if v not in (None, [], "")}]
    out += [{"@id": _iri(base, "spec-item", tumor, spec_version, s),
             "@type": "prov:Entity", "rwdp:specRow": s,
             "rwdp:inProduct": {"@id": product["@id"]}} for s in refs]
    return out


def _equivalences(base, pack, life, exported_concepts, decision_pack_scope=None):
    """Ruled pairs as stated equivalences. ONLY recorded rulings, and only `same_construct`
    becomes a semantic equivalence — an accepted proxy is a different relation and is exported as
    one, so a consumer cannot read "close enough for this use" as "the same thing"."""
    ruled, _problems = (sv.rulings() if decision_pack_scope is None else sv.rulings(pack_scope=decision_pack_scope))
    out, seen = [], set()
    for r in ruled:
        concept = _concept_iri(base, r["variable"], life)
        if concept not in exported_concepts:
            continue
        rel = {"same_construct": "skos:exactMatch",
               "accepted_proxy": "skos:closeMatch"}.get(str(r.get("ruling")))
        if not rel:
            continue # not_comparable states no equivalence to export
        # THREE THINGS THAT MUST BE IDENTIFIERS, NOT TEXT. A graph whose values are strings where
        # a consumer expects resources is not interoperable — it round-trips as prose and nothing
        # can be joined on it.
        #
        # `rwdp:relation` named the SKOS predicate as the LITERAL "skos:exactMatch". A reader
        # sees a node carrying a string, not a mapping; nothing resolves, nothing follows it.
        # It is now an IRI reference to the real predicate.
        #
        # `prov:wasAttributedTo` carried a person's NAME. PROV-O attributes to an AGENT, which
        # is a resource: two rulings by one person were two unrelated strings, and a name that
        # is also a string somewhere else collided silently. The agent is now minted as a
        # resource carrying the name as its label.
        #
        # `rwdp:sourceA/B` named datasets as bare text, so the same delivery under two spellings
        # was two things and under one spelling in two packs was accidentally one.
        #
        # THE DIRECT TRIPLE IS STILL NOT ASSERTED, deliberately: this reifies "a person ruled
        # these equivalent, on this date, under this decision", which is a weaker and truer claim
        # than "these are the same". Equivalence across datasets stays a recorded human act.
        agent = _agent_node(base, r.get("ruled_by"))
        for extra in (agent, _dataset_node(base, r["source_a"]),
                      _dataset_node(base, r["source_b"])):
            if extra and extra["@id"] not in seen:
                seen.add(extra["@id"])
                out.append(extra)
        out.append({
            "@id": _iri(base, "equivalence", f'{r["variable"]}-{r["source_a"]}-{r["source_b"]}'),
            "@type": "rwdp:EquivalenceRuling",
            "rwdp:aboutConcept": {"@id": concept},
            "rwdp:sourceA": {"@id": _dataset_iri(base, r["source_a"])},
            "rwdp:sourceB": {"@id": _dataset_iri(base, r["source_b"])},
            "rwdp:ruling": r["ruling"],
            "rwdp:relation": {"@id": rel},
            "rwdp:decisionId": r.get("decision_id"),
            "prov:wasAttributedTo": ({"@id": agent["@id"]} if agent else None),
            "dct:date": r.get("ruling_date"),
        })
    return out


def _attach_bindings(pack, concepts, by_variable, base_iri):
    """Put this pack's APPROVED bindings on the concept nodes the product export publishes.

    THE GRAPH DID NOT CARRY WHAT THE PACK HAD APPROVED. `export` built its concepts from the
    contract and never read `config/semantic.yaml`; only the per-tumour `template` path did. So a
    reviewer could confirm a ruling, bind it, have a clinician sign it, watch it enter release
    identity — and the published product graph still said nothing about what any variable MEANT.
    The approved meaning existed everywhere except the artefact whose entire purpose is to state it.

    A SHARED CONCEPT NODE WITH TWO DIFFERENT BINDINGS IS A CONFLICT, NOT A LAST-WRITE. Several
    contract variables can resolve to one concept IRI through the name lifecycle; if they bind
    differently, silently keeping one would publish a meaning nobody chose. It is marked and both
    are named, which is the same discipline `bindingState: fanout` already applies.

    AND AN UNSIGNED BINDING IS NOT ONE. This docstring said "APPROVED bindings" and nothing here
    checked: `sb.read` returns whatever `config/semantic.yaml` currently says, so a binding a
    reviewer had pasted in that morning — and one a clinician had approved and pinned by digest
    — published identically. The export is the artefact whose whole purpose is to state what a
    variable means; publishing an unsigned claim of meaning through it is the exact act
    SEMANTIC_APPROVAL.yaml exists to prevent, and it was the one path that skipped it. Withheld,
    not raised: the record layer has its own approval and is governed above, so an unsigned
    binding suppresses the MEANING and leaves the rest of the graph intact.

    Returns ({concept_iri: [variable_id]}, [why withheld]) for the report, so "bound" is a number
    a reader can check and "0" always says which of the two zeroes it is.
    """
    # ONE RULE, ASKED ONCE. This checked approval and schema and stopped there, while the
    # release path also required every axis to RESOLVE — so a signed binding naming a CUI
    # nothing carries, or a LOINC code mCODE does not bind, or a registry slot this cancer does
    # not assemble, was published here and refused there. `sb.publishable` is the one operation:
    # approved + current + schema-valid + resolvable.
    from rwd_tools import semantic_binding as sb # noqa: PLC0415
    bindings, unpublishable = sb.publishable(pack)
    if unpublishable:
        return {}, unpublishable
    # A BINDING FILE THAT DOES NOT VALIDATE IS WITHHELD WITH ITS REASON, not silently read as
    # "this pack binds nothing" — which is what dropping `_problems` on the floor here meant for
    # every misspelled key the schema now catches.
    if not bindings:
        return {}, []

    bound = {}
    for cid, variables in sorted(by_variable.items()):
        here = {v: bindings[v] for v in sorted(variables) if v in bindings}
        if not here:
            continue
        node = concepts.get(cid)
        if node is None:
            continue
        stated = {}
        for axis, key in (("concept", "rwdp:boundConcept"), ("lab", "rwdp:boundLab"),
                          ("registry_concept", "rwdp:boundRegistryConcept")):
            values = {str(r.get(axis) or "").strip() for r in here.values()}
            values = {v for v in values if v and not v.upper().startswith("TODO")}
            if len(values) > 1:
                node["rwdp:bindingState"] = "conflict"
                node["rwdp:bindingConflict"] = sorted(f"{v}={r.get(axis)}" for v, r in here.items()
                                                      if str(r.get(axis) or "").strip())
                stated = {}
                break
            if values:
                stated[key] = values.pop()
        if not stated:
            if node.get("rwdp:bindingState") != "conflict":
                node["rwdp:bindingState"] = "unbound"
            continue
        status = {str(r.get("status") or "active") for r in here.values()}
        state = status.pop() if len(status) == 1 else "conflict"
        # A PARKED BINDING IS NOT A CURRENT MEANING and must not read as one in a published graph.
        node["rwdp:bindingState"] = "bound" if state == "active" else state
        node["rwdp:boundVariables"] = sorted(here)
        if "rwdp:boundConcept" in stated:
            node["rwdp:boundConcept"] = {"@id": UMLS_CONCEPT_IRI + stated["rwdp:boundConcept"]}
        for key in ("rwdp:boundLab", "rwdp:boundRegistryConcept"):
            if key in stated:
                node[key] = stated[key]
        # ACTIVE ONLY, and this dict is why it matters: `export()` derives `concepts_bound` and
        # `variables_bound` from it, so adding a parked binding here made the report contradict
        # the `rwdp:bindingState` the line above had just written into the same graph — the node
        # said "not a current meaning" and the count beside it said "bound".
        # `semantic_binding.report()` splits the same way, NAMED not subtracted, and the two
        # numbers now describe the same pack identically.
        if state == "active":
            bound[cid] = sorted(here)
    return bound, []


def _adopted_nodes(pack, base_iri, root=None):
    """(nodes, note) — the concepts this pack INHERITED from the template library.

    THIS IS THE STEP THAT MAKES AN ADOPTION CAUSE SOMETHING. An external audit put it exactly:
    `TEMPLATE_ADOPTION.yaml` was read by nothing — not reconciliation, not binding, not this
    exporter, not the build, not deployment — so adoption "records intent but does not cause
    semantic reuse". A pin that changes no output is a note in a file, and the whole point of a
    template library is that a second pack does not have to re-derive a meaning somebody already
    reviewed.

    WHAT IS EMITTED, AND WHAT IS DELIBERATELY NOT. Each inherited concept becomes a node carrying
    the released definition and `prov:wasDerivedFrom` the release it came from, so a reader can see
    both the meaning and that it was INHERITED rather than authored here. It does NOT become an
    approved record of this pack, and it does not touch `_attach_bindings`: adopting a concept is
    not the same act as binding a variable to it, and collapsing the two would let a pin stand in
    for this product's own approval — which is precisely the substitution every gate here refuses.

    ONLY SOUND ADOPTIONS. `adoption_errors` owns the question of whether a pin holds; anything it
    refuses is withheld here and counted in the note, so a broken pin cannot publish meaning under
    this product's name. `adoption_notices` — source drift — does NOT withhold: the payload is
    frozen and self-verifying, which is the whole reason drift stopped being an error.
    """
    from rwd_tools import template_promote as tp # noqa: PLC0415
    from rwd_tools import product_gates as pg # noqa: PLC0415

    # `root` IS INJECTABLE so this can be tested against a fixture library. Hard-coding the
    # checkout root made the only reachable test an AST one - it could prove `export` calls
    # this and keeps the result, and nothing about what it actually emits. An audit said so.
    root = root or pg.checkout_root(__file__)
    path = os.path.join(pack, *tp.ADOPTION.split("/"))
    if not os.path.exists(path):
        return [], ""
    if tp.adoption_errors(root, pack):
        return [], ("template adoptions withheld: the recorded adoption does not hold "
                    "(run template_promote.py --check-adoptions)")
    doc, err = pg.read_yaml(path)
    if err or not isinstance(doc, dict):
        return [], "template adoptions withheld: TEMPLATE_ADOPTION.yaml is unreadable"

    known, _problems = tp.releases(root)
    nodes, seen, deferred_n = [], 0, 0
    for a in (doc.get("adopts") or []):
        if not isinstance(a, dict):
            continue
        hit = known.get((str(a.get("template_id") or ""), str(a.get("version") or "")))
        if hit is None:
            continue # unresolvable is an error, already withheld above
        rpath, rdoc = hit
        disp = str(a.get("disposition") or "")
        release_iri = _iri(base_iri, "template", _slug(str(rdoc.get("template_id") or "")),
                           str(rdoc.get("version") or ""))
        for c in (rdoc.get("concepts") or []):
            if not isinstance(c, dict) or not str(c.get("slot") or "").strip():
                continue
            node = {
                "@id": _iri(base_iri, "inherited", _slug(str(rdoc.get("template_id") or "")),
                            _slug(str(c.get("slot")))),
                "@type": "skos:Concept",
                "skos:prefLabel": str(c.get("slot")),
                "skos:inScheme": {"@id": _iri(base_iri, "scheme", "template")},
                # PROVENANCE IS THE POINT. Without this the graph would assert an inherited meaning
                # as though this product had authored it, which is the misattribution a template
                # library makes easy and must therefore be explicit about.
                "prov:wasDerivedFrom": {"@id": release_iri},
                "rwdp:adoptionDisposition": str(a.get("disposition") or ""),
                "rwdp:releasePath": rpath,
            }
            # ONLY `inherited` PUBLISHES THE RELEASED DEFINITION, and an audit was right that
            # emitting it for all four dispositions was wrong in three different ways:
            #
            # deferred — the pack has explicitly NOT taken this meaning yet. Publishing it
            # anyway turns a recorded non-decision into a stated meaning, which
            # is the loudest possible misreading of the one disposition that
            # exists to say "not yet".
            # adapted / diverged — the pack said this concept means something DIFFERENT
            # here. Emitting the source definition plus a free-text note
            # published the meaning it had just declared it does not hold, and
            # a reader taking `skos:definition` at face value would get the
            # opposite of what the pack decided.
            #
            # An adapted or diverged concept needs a locally governed payload before it can
            # publish a definition at all. Until this repository has one, the honest graph
            # states the inheritance and the difference and withholds the meaning - an
            # absence a reader can see, rather than a definition that is wrong.
            if disp == "deferred":
                deferred_n += 1
                continue
            if disp == "inherited" and str(c.get("definition") or "").strip():
                node["skos:definition"] = str(c.get("definition"))
            elif str(c.get("definition") or "").strip():
                node["rwdp:definitionWithheld"] = (
                    f"this pack recorded `{disp}`, so the released definition is NOT this "
                    f"product's meaning; no locally governed definition has been stated")
            if str(c.get("concept_sha256") or "").strip():
                node["rwdp:conceptDigest"] = str(c.get("concept_sha256"))
            # ADAPTED AND DIVERGED CARRY WHAT CHANGED. `adoption_errors` already refuses either
            # disposition with no `differences`, so this is never an empty promise.
            if str(a.get("differences") or "").strip():
                node["rwdp:adoptionDifferences"] = str(a.get("differences"))
            nodes.append(node)
            seen += 1
    note = ""
    if seen or deferred_n:
        note = (f"{seen} concept(s) from the template library; {deferred_n} deferred "
                f"adoption(s) published nothing, which is what `deferred` means")
    return nodes, note


def export(pack, base_iri, as_of=None, *, decision_pack_scope=None):
    """(json-ld document, report). The document holds only approved content; the report says what
    was withheld and why, so an empty graph is never mistaken for a complete one."""
    from engine.config import load_config # noqa: PLC0415
    # IDENTITY COMES FROM THE PACK'S OWN DECLARATIONS, NOT FROM WHERE IT SITS ON DISK. Reading
    # the tumour and version out of the path minted `.../implementation/unknown-unknown-AGEGR1`
    # for any pack outside the products tree — an identifier that says nothing, in a graph whose
    # whole value is that identifiers say something. The config states both; a pack that states
    # neither is refused rather than published under a composed name.
    roles, declared_id, spec_version = set(), "", ""
    cfg_path = os.path.join(pack, "config", "data_product.yaml")
    if os.path.exists(cfg_path):
        try:
            cfg = load_config(cfg_path)
            roles = set(cfg.sources)
            # `data_product_id` is the STABLE id audit and release consumers key on — it survives
            # a contract broadening that the folder name does not — and `spec_version` is the
            # CalVer the config resolves, both read through the properties that own them.
            declared_id = str(cfg.raw.get("data_product_id") or "").strip()
            try:
                spec_version = str(cfg.spec_version or "").strip()
            except Exception: # noqa: BLE001 — an unstated version is handled below
                spec_version = ""
        except Exception: # noqa: BLE001 — a broken config owns its own lint
            roles = set()
    rel = repo_relative(pack).split("/")
    in_tree = len(rel) > 3 and rel[0] == "products"
    tumor = declared_id or (rel[2] if in_tree else "")
    spec_version = spec_version or (rel[3] if in_tree else "")
    if not tumor or not spec_version:
        raise ValueError(
            f"{repo_relative(pack)}: the pack states no data_product_id and/or spec_version, and "
            f"its path does not supply them — every exported identifier would carry a name this "
            f"tool composed. State them in config/data_product.yaml before exporting.")

    life = _lifecycle_index()
    entries = rule_review.chain(pack)
    from rwd_tools import reviewed_variable_record as reviewed
    from rwd_tools import contract_lint as contract
    contract_path = os.path.join(pack, "handoff", "FUNCTIONAL_CONTRACT.md")
    blocks = list(contract.records(contract.read(contract_path))) if os.path.isfile(contract_path) else []
    rule_errors = reviewed.contract_errors(pack, blocks)
    if rule_errors:
        raise ValueError("; ".join(rule_errors))
    by_variable = {contract._scalar(block, "variable_id"): reviewed.load(pack, contract._scalar(block, "notes") or "") for block in blocks}
    for entry in entries:
        if by_variable.get(entry["variable_id"]) is not None:
            entry["reviewed_rule"] = by_variable[entry["variable_id"]]
    approved = [e for e in entries if _status_of(e) == APPROVED]
    withheld = {}
    for e in entries:
        st = _status_of(e) or "(unstated)"
        if st != APPROVED:
            withheld[st] = withheld.get(st, 0) + 1

    scheme = _iri(base_iri, "scheme", "rwd-variables")
    nodes = [{"@id": scheme, "@type": "skos:ConceptScheme",
              "skos:prefLabel": "RWD governed variables",
              "dct:description": "Concepts this platform's approved contract records define. "
                                 "Generated from the governed pack; not authored here."}]
    product = _product_node(base_iri, pack, roles, tumor, spec_version)
    nodes.append(product)
    activity = _build_activity(base_iri, tumor, spec_version, rc._build(pack))
    if activity:
        nodes.append(activity)

    concepts = {}
    by_variable = {}
    for e in approved:
        concept = _concept_iri(base_iri, e["variable_id"], life)
        concepts.setdefault(concept, _concept_node(base_iri, e["variable_id"], concept,
                                                   scheme, life))
        by_variable.setdefault(concept, set()).add(e["variable_id"])
        nodes.extend(_record_nodes(base_iri, e, concept, product, activity,
                                   tumor, spec_version))
    #...AND WHAT THIS PACK HAS APPROVED THEM TO MEAN. Read from `config/semantic.yaml`, which is
    # the one governed statement of it and which this function did not read at all.
    _bound, _binding_withheld = _attach_bindings(pack, concepts, by_variable, base_iri)
    nodes.extend(concepts.values())
    nodes.extend(_equivalences(base_iri, pack, life, set(concepts), decision_pack_scope))
    #...AND WHAT THIS PACK INHERITED RATHER THAN AUTHORED. See `_adopted_nodes`: until this
    # line, `TEMPLATE_ADOPTION.yaml` was read by nothing in the repository, so an adoption
    # changed no output anywhere and "semantic reuse" was a pin in a file.
    _inherited, _inherited_note = _adopted_nodes(pack, base_iri)
    nodes.extend(_inherited)

    doc = {"@context": dict(CONTEXT, rwdp=_iri(base_iri, "vocab") + "#"),
           "@graph": sorted(nodes, key=lambda n: (str(n.get("@id")),))}
    if as_of:
        doc["dct:issued"] = str(as_of)

    report = {
        "pack": repo_relative(pack), "base_iri": base_iri,
        "records": len(entries), "exported": len(approved),
        "withheld": withheld, "concepts": len(concepts), "nodes": len(doc["@graph"]),
        # PRECISE ABOUT WHAT IS EMPTY. The document is never empty — it always carries the
        # concept scheme and the product, and a build activity when one is recorded. What is
        # empty is the CONCEPT LAYER, and saying "the graph is empty" invited a reader to check,
        # find two nodes, and trust the next sentence less.
        "structural_nodes": len(doc["@graph"]) - len(concepts),
        # THE BINDING COUNT WAS COMPUTED AND DROPPED. `_attach_bindings` returned it and the
        # variable was never read again, so the report the docstring promised did not exist and
        # nobody could tell a pack that binds nothing from one whose bindings were suppressed.
        # INHERITED IS COUNTED SEPARATELY FROM AUTHORED, always. Folding them into `concepts`
        # would let a pack that adopted its whole meaning read as one that established it.
        "concepts_inherited": len(_inherited),
        "inherited_note": _inherited_note,
        "concepts_bound": len(_bound),
        "variables_bound": sum(len(v) for v in _bound.values()),
        "binding_withheld": list(_binding_withheld),
        "note": ("no record in this pack is approved, so the graph carries its structural nodes "
                 "(concept scheme, product" + (", build activity" if activity else "") + ") and "
                 "NO concepts — an empty concept layer and a filtered one are different states "
                 "and this says which"
                 if not approved else
                 "approved records only; drafts are withheld by state above"),
    }
    return doc, report


def serialize(doc):
    """ONE serialization — sorted, newline-terminated — so `--check` compares content."""
    return json.dumps(doc, indent=1, sort_keys=True, ensure_ascii=False) + "\n"


# --- SHACL ---------------------------------------------------------------------------------
#
# EVERY SHAPE RESTATES A RULE THIS REPOSITORY ALREADY ENFORCES, and names where. That is the
# whole discipline: a shape with no enforcer here would be a SECOND RULEBOOK — a constraint the
# graph applies that Git does not, so an artifact could be valid in one place and invalid in the
# other with nobody able to say which is right. `enforced_by` is the pointer that keeps the two
# from drifting, and a test refuses a shape that names none.
#
# What is deliberately NOT here: anything clinical. No shape says a window must be 90 days or a
# cohort must be non-empty. Those live in the contract and the QC gates, where a person approves
# them; expressing them here would move a clinical rule into a projection nobody signs.
SHAPES = (
    # A MAPPING WITHOUT A STATUS IS AN UNMARKED DRAFT. The mCODE domain ruling is `proposed` and
    # unsigned; emitting its mappings as bare assertions let a partial association read as settled
    # meaning. The four shapes here validated structure and said nothing about lifecycle, which is
    # how a draft becomes indistinguishable from an approval once the graph is loaded somewhere
    # else. This is the cheapest constraint that closes it: whatever carries a profile must also
    # carry the status the ruling was in when it was emitted.
    {"name": "McodeMapping", "target": "skos:Concept",
     "properties": [
         {"path": "rwdp:mcodeMappingStatus", "min": 0, "max": 1,
          "message": "a concept states at most one mCODE mapping status — two would make it "
                     "unclear whether the mapping is approved",
          "enforced_by": "semantic_export.template (one status per node, from the ruling)"},
     ],
     "sparql": {
         "message": "this concept asserts an mCODE profile with no mapping status — a proposed "
                    "ruling and an approved one are then indistinguishable to anything that "
                    "loads this graph",
         "select": ("SELECT $this WHERE {{ "
                    "$this <{v}mcodeProfile> ?p . "
                    "FILTER NOT EXISTS {{ $this <{v}mcodeMappingStatus> ?s }} }}"),
         # THE POINTER EVERY OTHER CONSTRAINT CARRIES, and this one did not — `shapes()` reads
         # `q["enforced_by"]` unconditionally, so its absence was not a missing annotation but a
         # KeyError that took the whole shapes graph down with it, and three tests with it.
         #
         # TWO ENFORCERS, because the constraint has two halves. The predicate is emitted on every
         # branch that emits a profile, which is what makes the shape hold structurally; and the
         # VALUE is held to a vocabulary where the ruling is read, which is what stops it holding
         # vacuously with a status of anything at all.
         "enforced_by": ("semantic_export.template (mcodeMappingStatus is set on every branch that "
                         "sets mcodeProfile) -- mcode_domains.map_errors (status must be one of "
                         "STATUSES, and `approved` requires approved_by and approved_on)"),
     }},
    {"name": "Definition", "target": "rwdp:Definition",
     "properties": [
         {"path": "rwdp:implementsConcept", "min": 1, "max": 1, "nodeKind": "sh:IRI",
          "message": "a definition parameterises exactly one concept — two would make it "
                     "ambiguous which meaning its slot values belong to",
          "enforced_by": "semantic_export.template (one concept per definition)"},
     ],
     # THE CHECK THE PARTITION EXISTS FOR, and it cannot be written as a property constraint
     # because it spans two nodes: whether a definition is complete depends on what its CONCEPT
     # declares. `AGEGR1` requires `bands`; a definition that states no bands is not a rule anyone
     # can reuse, and a consumer pooling it with another `AGEGR1` column would be pooling two
     # different bandings that both look like "age group". Stating a slot as UNSTATED satisfies
     # this — the requirement is that the parameterisation be VISIBLE, not that it be filled,
     # because a template is legitimately unfilled and a silent gap is not.
     "sparql": {
         "message": "this definition's concept requires a slot it neither values nor marks "
                    "unstated — its parameterisation is invisible, so nothing can tell whether "
                    "pooling it with another definition of the same concept is safe",
         "select": ("SELECT $this ?slot WHERE {{ "
                    "$this <{v}implementsConcept> ?c . ?c <{v}requiresSlot> ?slot . "
                    "FILTER NOT EXISTS {{ $this <{v}slotValue> ?slot }} "
                    "FILTER NOT EXISTS {{ $this <{v}slotUnstated> ?slot }} }}"),
         "enforced_by": "variables_scaffold (REPLACE_ME marker) · engine/validate.py strict mode",
     }},
    {"name": "Implementation", "target": "rwdp:Implementation",
     "properties": [
         {"path": "rwdp:implements", "min": 1, "max": 1,
          "message": "an implementation realises exactly one concept — a second would make one "
                     "product's definition the concept's definition",
          "enforced_by": "semantic_export.export (one concept per contract record)"},
         {"path": "rwdp:forProduct", "min": 1, "max": 1,
          "message": "an implementation belongs to exactly one product and spec version",
          "enforced_by": "engine/config.py spec_version + data_product_id"},
         {"path": "rwdp:specDigest", "min": 1, "max": 1, "datatype": "xsd:string",
          "message": "the digest binds this implementation to the specification text it was "
                     "written from; without it the citation cannot be checked",
          "enforced_by": "contract_lint I15 (spec_digest binds the record to the cited text)"},
         {"path": "prov:wasDerivedFrom", "min": 1,
          "message": "every implementation cites at least one specification row",
          "enforced_by": "contract_lint (spec_refs required) · competency CQ01"},
     ]},
    {"name": "Concept", "target": "skos:Concept",
     "properties": [
         {"path": "skos:prefLabel", "min": 1, "max": 1,
          "message": "one preferred label per concept — two is two concepts or one unresolved "
                     "naming question",
          "enforced_by": "naming_registry (near-miss docket; rulings in NAMING_RULINGS.yaml)"},
         {"path": "skos:inScheme", "min": 1, "max": 1,
          "message": "a concept outside the scheme is unreachable from the vocabulary",
          "enforced_by": "semantic_export.export (every concept is minted into the scheme)"},
         {"path": "dct:isReplacedBy", "max": 1, "nodeKind": "sh:IRI",
          "message": "a replaced concept points at ONE successor — deprecate, don't delete",
          "enforced_by": "naming_registry.lifecycle (replaced_by required on a retirement)"},
     ]},
    {"name": "EquivalenceRuling", "target": "rwdp:EquivalenceRuling",
     "properties": [
         {"path": "rwdp:decisionId", "min": 1, "max": 1,
          "message": "an equivalence carries the decision that reasoned it",
          "enforced_by": "semantic_view.rulings (decision_id required)"},
         {"path": "prov:wasAttributedTo", "min": 1, "max": 1,
          "message": "a ruling is a named person's act, or it is not a ruling",
          "enforced_by": "semantic_view.rulings (ruled_by must be a person)"},
         {"path": "dct:date", "min": 1, "max": 1,
          "message": "a ruling is dated, so it can be superseded",
          "enforced_by": "semantic_view.rulings (ruling_date must be a real date)"},
     ]},
)


def shapes(base_iri):
    """The SHACL shapes for the graph `export` produces, as JSON-LD.

    Generated, never authored: the constraints come from SHAPES above, each naming the check in
    this repository that already enforces it. A consumer validating the projection therefore
    applies the same rules Git applies — the point being interoperability, not a new authority.

    EMITTING SHAPES IS NOT VALIDATING RDF, which is why `--validate` exists: it parses both
    graphs as real RDF and runs these shapes through a conformant processor (pyshacl), reporting
    `unchecked` rather than success where the libraries are absent. Generating a shapes graph and
    never executing it is a description of a check, not a check — and the artifact looks identical
    either way, which is what makes that failure worth naming.
    """
    nodes = []
    for s in SHAPES:
        props = []
        for p in s["properties"]:
            node = {"sh:path": {"@id": p["path"]}, "sh:message": p["message"],
                    "rwdp:enforcedBy": p["enforced_by"]}
            if "min" in p:
                node["sh:minCount"] = p["min"]
            if "max" in p:
                node["sh:maxCount"] = p["max"]
            if "datatype" in p:
                node["sh:datatype"] = {"@id": p["datatype"]}
            if "nodeKind" in p:
                node["sh:nodeKind"] = {"@id": p["nodeKind"]}
            props.append(node)
        extra = {}
        if s.get("sparql"):
            # Full IRIs rather than prefixed names: a SPARQL constraint carrying `rwdp:` would
            # need its own sh:prefixes block to resolve, and the namespace is only known here.
            q = s["sparql"]
            extra = {"sh:sparql": {
                "@type": "sh:SPARQLConstraint",
                "sh:message": q["message"],
                "rwdp:enforcedBy": q["enforced_by"],
                "sh:select": q["select"].format(v=_iri(base_iri, "vocab") + "#"),
            }}
        nodes.append({"@id": _iri(base_iri, "shape", s["name"]),
                      "@type": "sh:NodeShape",
                      "sh:targetClass": {"@id": s["target"]},
                      "sh:closed": False, # the graph may carry more than we constrain
                      "sh:property": props, **extra})
    ctx = dict(CONTEXT, rwdp=_iri(base_iri, "vocab") + "#",
               sh="http://www.w3.org/ns/shacl#")
    return {"@context": ctx, "@graph": sorted(nodes, key=lambda n: n["@id"])}


# --- NAMED GRAPHS -------------------------------------------------------------------------
#
# WHY THE GRAPH IS PARTITIONED, AND WHY NOT BY PRODUCT. Five subgraphs, each holding one KIND of
# statement, because each kind is governed differently and carries different shapes. A flat graph
# can hold all of it, but it cannot express "this half is reviewed enterprise meaning and that
# half is one product's binding of it", which is the distinction the whole layer exists to make.
#
# THE OBVIOUS BOUNDARY IS THE WRONG ONE. Partitioning by tumour or by product is the first
# instinct and it defeats the purpose: "does prostate's rwPFS mean what mCRC's does" is THE
# question a cross-product graph is for, and putting the two in different graphs makes it the
# hardest query rather than the easiest. Tumour and product are PROPERTIES on an implementation,
# never graph boundaries — which is also what lets a project, a therapeutic area, or any other
# grouping arrive later as one more property instead of a re-partition.
GRAPHS = {
    "concepts": "durable meaning, one node per concept — what is being measured, never how. The "
                "layer an enterprise terminology owns and mints identifiers for",
    "definitions": "a concept with its parameter slots FILLED — the exact rule. Two packs share a "
                   "definition only where every slot value matches",
    "implementations": "one product's binding of one definition to a spec digest and a config "
                       "block. Carries tumour and product as properties",
    "availability": "concepts the programme defines that THIS tumour does not instantiate — "
                    "recorded so the next cut reuses the name instead of re-deriving it",
    "rulings": "human equivalence acts — who ruled what, when, under which decision",
    "provenance": "how the graph was produced: activities, agents, source identities",
}


def _graph_iri(base, name):
    return _iri(base, "graph", name)


def as_named_graphs(base, buckets):
    """Wrap {graph name: [node]} as JSON-LD named graphs, dropping the empty ones.

    An empty named graph and an absent one say the same thing and one of them invites a reader to
    wonder which, so only non-empty subgraphs are emitted and the report counts what was dropped.
    """
    out = []
    for name in sorted(buckets):
        nodes = buckets[name]
        if not nodes:
            continue
        out.append({"@id": _graph_iri(base, name),
                    "@graph": sorted(nodes, key=lambda n: str(n.get("@id")))})
    return out


def concept_slots(master_name, inventory=None):
    """{slot: description} a master concept DECLARES — the parameters any definition must state.

    THIS IS WHAT MAKES POOLING DECIDABLE. `AGEGR1` declares `bands`; `ECOG_PS` declares `window`.
    Two products both reporting "age band" are the same CONCEPT and are not necessarily the same
    DEFINITION: 18-45/45-65/65+ and 18-40/40-65/65+ put a 42-year-old in different categories, and
    a -30/+7 ECOG window and a -180/+7 one disagree about whether a patient has a value at all.
    Comparing the prose of two derivations cannot see that difference; comparing filled slot
    values decides it exactly, with no threshold and no heuristic.
    """
    doc = inventory if inventory is not None else _inventory()
    for m in doc.get("master") or []:
        if str(m.get("name")) == str(master_name):
            return {k: str((v or {}).get("description") or "")
                    for k, v in (m.get("parameter_slots") or {}).items()}
    return {}


def _inventory():
    """The master inventory, through the ONE guarded reader — a parse failure is a result here,
    never a traceback out of whatever gate happens to be calling."""
    from rwd_tools import product_gates as pg # noqa: PLC0415
    path = os.path.join(ROOT, "governance", "reference", "variable_inventory", "INVENTORY.yaml")
    doc, err = pg.read_yaml(path)
    if err:
        raise SystemExit(f"{path}: {err}")
    return doc or {}


def _overlay_key(tumour):
    """The inventory's overlay name for a pack slug — registry `tumour_key` first, then
    the one shared mapping (`oc` is filed as `ovarian`), then the slug itself."""
    from rwd_tools import product_gates as _pg # noqa: PLC0415
    from rwd_tools import variables_scaffold as vs # noqa: PLC0415
    return _pg.tumour_key_for(ROOT, tumour) or vs.SLUG_TO_OVERLAY.get(tumour, tumour)


def _inventory_facets(doc=None):
    """Everything the inventory knows about each master, gathered ONCE.

    THE MATCHING HANDLES WERE ALREADY THERE. A concept's `prefLabel` is its master name —
    `ECOG_PS`, `INDEX_DATE` — which is a name no workbook uses. What a workbook writes is `ECOG`,
    `DXDATE`, `ADV_DX_DATE`, and those are exactly the 86 tumour-variable names the inventory
    already maps to a master through `master:`. Emitting only the master name threw away the one
    field that lets a spec row find its concept, which is why the concept layer matched 13 of 353
    workbook variables while the pack itself matched 327.

    Also gathered: the definition prose (a concept with no definition cannot be reviewed by the
    person who knows whether it is right), the master's `category` (a domain assignment that
    already exists and was being ignored while the question was treated as open), the citations
    (a concept's provenance is the literature it came from), and each tumour variable's
    `coverage` — whether this platform can BUILD it and through which config surface, which is
    the difference between a concept someone can use and one they cannot.
    """
    doc = doc if doc is not None else _inventory()
    alt, cov, srcs = {}, {}, {}
    for tumour, body in (doc.get("tumours") or {}).items():
        for v in ((body or {}).get("variables") or []):
            m = v.get("master")
            if not m:
                continue
            # KEYED BY (tumour, master), NOT master. Pooling made every tumour assert every other
            # tumour's spellings as alternative labels for one concept — INDEX_DATE carried 23,
            # among them DXDATE, METDATE, CRPC_DATE and RESECTION_DATE. In SKOS an altLabel is an
            # alternative lexical label for the SAME concept, and a diagnosis date is not a
            # metastasis date. The concept layer is shared; the SPELLINGS are per-tumour.
            alt.setdefault((tumour, m), set()).add(str(v.get("name")))
            if v.get("coverage"):
                cov.setdefault((tumour, m), dict(v["coverage"]))
            if v.get("common_sources"):
                srcs.setdefault((tumour, m), str(v["common_sources"]))
    return {"alt": {k: sorted(v) for k, v in alt.items()}, "coverage": cov, "sources": srcs}


_PACKS_MEMO = {}


def _packs_for(tumour):
    """[(slug, newest pack dir)] for every registered product that answers to `tumour`.

    A product answers BY SLUG or BY TUMOUR_KEY — `dlbcl_cota_ehr` and `dlbcl_optum_claims`
    both answer to `dlbcl` — resolved through `product_gates.tumour_key_for`, the same rung
    every tumour-meaning consumer uses. The folder-name glob this replaces knew only the
    slug-equals-tumour case, so a qualified slug was invisible to `template("dlbcl")`. NEWEST BY SPEC VERSION per slug, sorted, so the answer does not depend on
    directory order.
    """
    from rwd_tools import product_gates as pgt # noqa: PLC0415
    t = str(tumour or "").strip().lower()
    memo_key = (ROOT, t)
    if memo_key in _PACKS_MEMO:
        return _PACKS_MEMO[memo_key]

    # THE REGISTRY'S CURRENT VERSION WINS, then real YYYYMM versions, then anything else.
    # Raw string comparison chose `YYYYMM` over `202608` — the template placeholder sorts
    # above every real date, so the tumour's meaning was
    # read from a scaffold nobody filled.
    current = {}
    for base in ("products", "fixtures"):
        reg, err = pgt.read_yaml(os.path.join(ROOT, base, "registry.yaml"))
        if not err:
            for t_ in (reg or {}).get("tumors") or []:
                if isinstance(t_, dict) and t_.get("slug"):
                    # products first, and a fixture NAMESAKE never overwrites the real
                    # product's current version (earlier review: it did, and the
                    # probe exported a stale product version)
                    current.setdefault(str(t_["slug"]),
                                       str(t_.get("current_spec_version") or ""))

    def _rank(slug, version):
        # a placeholder `current_spec_version` (YYYYMM) names nothing — the registry saying
        # a scaffold is current does not make the scaffold outrank a real version
        if version and version == current.get(slug) and re.fullmatch(r"\d{6}", version):
            return (2, version)
        return (1, int(version)) if version.isdigit() else (0, version)

    def _collect(rels):
        found = {}
        for rel in rels:
            parts = str(rel).replace("\\", "/").rstrip("/").split("/")
            if len(parts) < 2:
                continue
            slug, version = parts[-2], parts[-1]
            key = str(pgt.tumour_key_for(ROOT, slug) or slug).lower()
            if t not in (slug.lower(), key):
                continue
            # A PACK IS A DIRECTORY WITH A `config/`, not whatever sorts beside one. An earlier
            # cut globbed `*` and picked a script sitting next to the packs, then reported the
            # tumour as declaring nothing — a wrong path with a plausible answer.
            p = os.path.join(ROOT, str(rel).replace("/", os.sep))
            if not os.path.isdir(os.path.join(p, "config")):
                continue
            prev = found.get(slug)
            if prev is None or _rank(slug, version) > _rank(slug, prev[0]):
                found[slug] = (version, p)
        return [(s, v[1]) for s, v in sorted(found.items())]

    # PRODUCTS SHADOW FIXTURES: the moment a real product answers to a
    # tumour, its fixture namesake stops being a candidate — a template must never refuse as
    # "ambiguous" between a governed product and its own exercise material, and must never
    # export the exercise material as the product's meaning.
    out = _collect(pgt.products(ROOT)) or _collect(pgt.fixture_packs(ROOT))
    _PACKS_MEMO[memo_key] = out
    return out


def _pack_for(tumour):
    """The one pack for `tumour`, None when nothing answers — and a REFUSAL naming every
    candidate when several products share the tumour. Two modality products per tumour is the
    designed state, and silently exporting one of them as "the" tumour's meaning was the
    false green: the caller believed it saw dlbcl and saw one vendor's dlbcl."""
    cands = _packs_for(tumour)
    if not cands:
        return None
    if len(cands) > 1:
        names = ", ".join(s for s, _ in cands)
        raise SystemExit(f"{tumour!r} names {len(cands)} products ({names}) — say which "
                         f"product slug you mean; a tumour with several implementations has "
                         f"no single pack to speak for it")
    return cands[0][1]


def _declared_binding(tumour):
    """The binding DOCUMENT a tumour's newest pack declares, or {}. Never a publication.

    SEPARATE FROM `binding_for` ON PURPOSE, and the separation is the point. `binding_for`
    answers "what may be PUBLISHED" and withholds everything unless the binding is approved,
    current, schema-valid and resolvable. This answers "what does the pack SAY", which is a
    different question and the one the absent/declared distinction rests on:

        absent     the pack has no config/semantic.yaml at all
        declared   it has one, and states nothing bindable yet
        bound      it states a meaning that may be published

    Tying `declared` to publishable bindings collapsed the first two, so a pack carrying a
    binding file with `variables: {}` reported as never having had one. Nothing here is emitted
    into a graph; it is used to say which of the three states a pack is in.
    """
    pack = _pack_for(tumour)
    if not pack:
        return {}
    from rwd_tools import semantic_binding as sb # noqa: PLC0415
    doc, _probs = sb.read(pack)
    return doc or {}


def binding_for(tumour):
    """({variable: binding}, [problem]) for a tumour's newest pack. Absent is empty, never an error.

    THE TEMPLATE PATH APPLIED A WEAKER RULE THAN THE PRODUCT PATH, which is the same divergence
    this file already closed once. `export` asks `sb.publishable` — approved + current +
    schema-valid + resolvable — and withholds everything if any of the four fails. This asked
    `sb.read` and returned the RAW document alongside the problems, so a caller could emit a
    binding that is unsigned, stale, malformed or unresolvable while merely REPORTING that it was
    any of those. The template is the artefact a study team reads first.

    Returns the VARIABLE MAP rather than the whole document, because that is all the caller ever
    used and returning the document invited exactly the mistake above: the reasons were beside
    the payload instead of in place of it.
    """
    pack = _pack_for(tumour)
    if not pack:
        return {}, []
    from rwd_tools import semantic_binding as sb # noqa: PLC0415
    return sb.publishable(pack)


def _binding_member(variable, decl):
    """One fan-out member's OWN binding, attached to the variable rather than to the family.

    THE FAMILY IS NOT THE MEANING. `GENOMIC_SIGNATURE` holds BRCA12 beside AR_ALT; `TUMOR_MARKER_
    VALUE` holds CA125 beside CTDNA and SERUM_EPO. Where several of a pack's variables share one
    master the family node correctly refuses to carry a single meaning — but it then dropped the
    members' bindings entirely, so a pack that had bound BRCA12 to a concept published nothing
    about it at all. One bound member would otherwise annotate the generic family, which is worse:
    it asserts that every member means what one of them means.

    So the mapping hangs off the MEMBER. Three levels, which is what the model needed: the reusable
    master, the local product variable, and the terminology attached to that variable.
    """
    out = {"rwdp:variable": variable}
    cui = str((decl or {}).get("concept") or "").strip()
    lab = str((decl or {}).get("lab") or "").strip()
    slot = str((decl or {}).get("registry_concept") or "").strip()
    status = str((decl or {}).get("status") or "active")
    stated = [v for v in (cui, lab, slot) if v and not v.upper().startswith("TODO")]
    # A PARKED BINDING IS NOT A CURRENT MEANING, and must not read as one here either.
    out["rwdp:bindingState"] = ("bound" if stated and status == "active"
                                else status if stated else "unbound")
    if cui and not cui.upper().startswith("TODO"):
        out["rwdp:boundConcept"] = {"@id": UMLS_CONCEPT_IRI + cui}
    if lab and not lab.upper().startswith("TODO"):
        out["rwdp:boundLab"] = lab
    if slot and not slot.upper().startswith("TODO"):
        out["rwdp:boundRegistryConcept"] = slot
    return out


def _member_node(variable, ruling, dmap, master):
    """One member of a fan-out family, carrying the evidence its ruling was made on.

    A MAPPED member keeps its confidence and, where the profile covers only part of it, the caveat
    naming the uncovered part. An ABSTAINING member keeps the recorded reason — without it,
    "mCODE does not type this one" and "nobody ruled on this one" render identically, and the
    second is the state the family-level gate exists to prevent.
    """
    rec = (((dmap or {}).get("masters") or {}).get(master) or {})
    raw = (rec.get("variables") or {}).get(variable) or {}
    if ruling:
        out = {"rwdp:variable": variable,
               "rwdp:mcodeProfile": {"@id": ruling["url"]},
               "rwdp:mcodeProfileLabel": ruling["profile"],
               "rwdp:mcodeConfidence": ruling["confidence"]}
        if ruling.get("caveat"):
            out["rwdp:mcodeCaveat"] = ruling["caveat"]
        return out
    out = {"rwdp:variable": variable, "rwdp:mcodeState": "not_typed_by_mcode"}
    why = str(raw.get("why_none") or "").strip()
    if why:
        out["rwdp:mcodeNote"] = why
    return out


def template(tumour, base):
    """The per-tumour SEMANTIC TEMPLATE: the WHOLE concept space, with this tumour's relationship
    to each one stated.

    WHAT IT IS FOR. A new tumour starts from the governed skeleton the others already agreed
    rather than a blank page, and a reviewer sees what this tumour is expected to define before a
    record is drafted.

    THE CONCEPT LAYER IS SHARED AND TUMOUR-AGNOSTIC — every tumour emits the same concept nodes,
    because thirteen private copies of "age band" is thirteen things that drift. What varies per
    tumour is not WHICH CONCEPTS EXIST but which ones this tumour instantiates.

    UNUSED IS NOT ABSENT, and emitting only the instantiated ones threw that away. DLBCL
    instantiates 12 of 22 masters; the other 10 — `RWPFS` and `RWTTD` among them — are not
    meaningless for DLBCL, they are simply not in its current cut. A template that omitted them
    would say "this tumour has no such concept" where the truth is "this tumour does not use it
    YET", and the next cut that needs one would re-derive it under a new name, which is how the
    naming docket filled up in the first place. So an uninstantiated concept is emitted as an
    explicit availability statement — a DIFFERENT class from a definition, so the slot-
    completeness rule does not fire on something nobody has claimed to define.
    """
    from rwd_tools import variables_scaffold as vs # noqa: PLC0415
    doc = _inventory()
    # WHAT THE PACK DECLARES IT MEANS, rather than what this function can infer from which config
    # blocks happen to exist. Inference could not tell "never bound" from "nothing to bind to";
    # reading the declaration makes both countable and neither silent.
    bound_vars, binding_problems = binding_for(tumour)
    bound_vars = {k: v for k, v in bound_vars.items() if isinstance(v, dict)}
    _declared = _declared_binding(tumour) # what the pack SAYS; see the state block below
    # A BINDING IS PER LOCAL VARIABLE; A CONCEPT NODE IS A MASTER FAMILY. Looking `bound_vars` up
    # by the master name meant a valid binding on prostate's `ECOG` was validated, accepted, and
    # then silently ignored here because this asked for `ECOG_PS`. Worse, a master can FAN OUT:
    # prostate declares BRCA12 and AR_ALT both under GENE_VARIANT_STATUS, so no single binding
    # belongs on that node and choosing one would put a pack-specific claim on a shared concept.
    # So the local variables are grouped under their master, and a family carrying more than one is
    # reported as `fanout` rather than resolved to whichever came first.
    _pack = _pack_for(tumour)
    _by_master = {}
    if _pack:
        from rwd_tools import semantic_binding as _sb # noqa: PLC0415
        for _var, _m in _sb.pack_masters(_pack).items():
            if _m and _var in bound_vars:
                _by_master.setdefault(_m, []).append((_var, bound_vars[_var]))
    every = sorted({str(m.get("name")) for m in (doc.get("master") or []) if m.get("name")})
    used = set(vs.instantiated_masters(tumour))
    concepts, definitions, available = [], [], []
    facets = _inventory_facets(doc)
    by_name = {str(m.get("name")): m for m in (doc.get("master") or [])}
    # THE RECORDED IDENTIFIER WINS HERE TOO. This path composed its IRI directly and never opened
    # the lifecycle register, so the moment anyone recorded an enterprise IRI for a name — the
    # exact act `NAME_LIFECYCLE.yaml` exists for — `export()` would honour it and `template()`
    # would mint a second one for the same concept, under the same scheme. That is the duplicate
    # identity `_concept_iri`'s own docstring says the register exists to prevent, reappearing on
    # the one path that emits `rwdp:Definition` nodes. The register is empty today, which is
    # precisely why this was invisible.
    life = _lifecycle_index()
    # THE DOMAIN VOCABULARY, read once. See `mcode_domains` for why it is not `master["category"]`.
    from rwd_tools import mcode_domains as _md # noqa: PLC0415
    _dmap, _dmap_problems = _md.load()
    _dprof = _md.profiles()
    # FAIL CLOSED. This read the problems and dropped them on the floor, so a corrupt DOMAIN_MAP or
    # a missing DICTIONARY.json removed every domain from the graph and the export still SUCCEEDED
    # — the one failure mode where a silently smaller answer looks exactly like a correct one.
    # A ruling that cannot be read is not an absence of rulings.
    _dmap_problems = list(_dmap_problems) + _md.map_errors(_dmap, _dprof)
    if not _dprof:
        _dmap_problems.append("DICTIONARY.json carries no profiles — no domain can be resolved")
    for name in every:
        slots = concept_slots(name, doc)
        master = by_name.get(name) or {}
        cid = _concept_iri(base, name, life)
        node = {
            "@id": cid, "@type": "skos:Concept",
            "skos:prefLabel": name,
            "skos:inScheme": {"@id": _iri(base, "scheme", "rwd-variables")},
            # Declared ON the concept so a definition can be CHECKED against them: a definition
            # missing a slot its concept requires is not reusable, and that is a shape a validator
            # enforces rather than a convention a reader must remember.
            "rwdp:requiresSlot": sorted(slots),
        }
        if master.get("definition_sketch"):
            # A concept with no definition cannot be reviewed by the person who knows whether it
            # is right, and an unreviewable concept layer is one whose meaning was assumed.
            node["skos:definition"] = str(master["definition_sketch"]).strip()
        # THE HANDLES A SPEC ROW ACTUALLY CARRIES, for THIS tumour. `ECOG_PS` is what the
        # programme calls it; `ECOG` is what a workbook writes. Keyed by (tumour, master) —
        # pooling across tumours made every pack assert every other pack's spellings as
        # alternative labels for one concept, which is not what skos:altLabel means.
        _alt = facets["alt"].get((_overlay_key(tumour), name))
        if _alt:
            node["skos:altLabel"] = _alt
        # TWO FIELDS, BECAUSE THEY ANSWER TWO QUESTIONS.
        #
        # `rwdp:domain` is this programme's own ANALYTIC domain and stays authoritative. An earlier
        # cut replaced it with the mCODE profile, and that was the wrong model: mCODE profiles
        # describe how oncology clinical information is represented in FHIR, and they are not a
        # taxonomy for analytical data-product domains. A third of this programme's masters are
        # derived endpoints, study-design constructs or administrative attributes, which is why
        # eighteen of them map to no profile at all — under the merged model those concepts simply
        # lost their domain, which is worse than the private vocabulary it replaced.
        #
        # `rwdp:mcodeProfile` is the MAPPING to the standard, carried beside it and never instead
        # of it. A consumer that wants HL7's definition follows the IRI; one that wants to group
        # this programme's variables reads the domain; neither has to pretend to be the other.
        if master.get("category"):
            node["rwdp:domain"] = str(master["category"])

        _dom = _md.domain_for(name, _dmap, _dprof)
        _dvars = _md.variable_domains(name, _dmap, _dprof)
        # THE MAPPING SAYS WHETHER IT IS APPROVED. DOMAIN_MAP.yaml is `status: proposed` with no
        # approver and no date, and this emitted its mappings as bare assertions — so a weak or
        # partial association read as authoritative, and a consumer loading the graph lost the
        # draft/approved distinction entirely. The status travels on the node instead of only in
        # the run report, because the report is not what gets loaded.
        _mstatus = str((_dmap or {}).get("status") or "unstated")
        if _dvars:
            # THE FAMILY SPLITS, SO THE NODE DOES NOT PRETEND OTHERWISE. BIOMARKER_TEST_CONTEXT
            # holds PSMA_PET (nuclear imaging, which mCODE does not type at all) beside
            # NGS_PANEL_TESTING (Genomic Region Studied) and PD_L1_TESTING_RESULT (a tumour-marker
            # IHC read); TUMOR_MARKER_VALUE holds CA125 beside CTDNA and SERUM_EPO. Asserting one
            # profile on the family would put a false mapping on most of its members.
            #
            # EACH MEMBER KEEPS ITS OWN EVIDENCE. This carried only the variable, the IRI and the
            # label, dropping the confidence and caveat for a mapped member and the recorded reason
            # for an abstaining one. That is exactly the wrong place to lose it: a mixed family is
            # where the mapping is least uniform and a reviewer most needs to see how each member
            # was decided, and the caveats are where this map is most likely to be wrong.
            node["rwdp:mcodeState"] = "fanout"
            node["rwdp:mcodeMappingStatus"] = _mstatus
            node["rwdp:mcodeByVariable"] = [
                _member_node(v, r, _dmap, name) for v, r in sorted(_dvars.items())]
        elif _dom:
            node["rwdp:mcodeProfile"] = {"@id": _dom["url"]}
            node["rwdp:mcodeProfileLabel"] = _dom["profile"]
            node["rwdp:mcodeConfidence"] = _dom["confidence"]
            node["rwdp:mcodeMappingStatus"] = _mstatus
            if _dom["caveat"]:
                # WHAT THE PROFILE DOES NOT COVER, on the node. A reviewer checking this graph must
                # see which mappings are approximate without opening the ruling file.
                node["rwdp:mcodeCaveat"] = _dom["caveat"]
        else:
            _why = dict(_md.unmapped(_dmap)).get(name)
            if _why:
                # ABSTENTION IS A RESULT. Emitting nothing would make "mCODE does not type this"
                # look like "nobody looked", and that distinction is the most useful thing the
                # ruling carries.
                node["rwdp:mcodeState"] = "not_typed_by_mcode"
                node["rwdp:mcodeMappingStatus"] = _mstatus
                node["rwdp:mcodeNote"] = _why
        if master.get("citations"):
            # Provenance for the MEANING, distinct from provenance for the build: this is the
            # literature the concept was drawn from, and it is what a reviewer checks it against.
            node["dct:source"] = [str(c) for c in master["citations"]]
        if slots:
            # The slot's own description travels with it, so the graph is self-describing and a
            # consumer does not have to open a spreadsheet to learn what `anchor` means.
            node["rwdp:slotDescription"] = [f"{k}: {v}" for k, v in sorted(slots.items()) if v]
        # WHAT THIS PACK DECLARES THE CONCEPT MEANS, and — as loudly — that it declares nothing.
        # An unbound concept was previously indistinguishable from one nobody had looked at.
        here = _by_master.get(name) or ([(name, bound_vars[name])] if name in bound_vars else [])
        if len(here) > 1:
            # NOT RESOLVED AT THE FAMILY LEVEL, AND SAYING SO. Several of this pack's variables
            # share this master and each may mean a different thing; one node cannot carry them.
            node["rwdp:bindingState"] = "fanout"
            node["rwdp:boundVariables"] = sorted(v for v, _r in here)
            #...BUT EACH MEMBER KEEPS ITS OWN. This dropped every individual binding, so a pack
            # that had bound BRCA12 published nothing about it — and the alternative it avoided,
            # letting one bound member annotate the family, is worse still: it asserts that every
            # member means what one of them means. Same shape `rwdp:mcodeByVariable` already uses
            # for a mixed mCODE family, and for the same reason.
            node["rwdp:boundByVariable"] = [_binding_member(v, r) for v, r in sorted(here)]
            concepts.append(node)
            continue
        decl = (here[0][1] if here else {})
        cui = str(decl.get("concept") or "").strip()
        lab = str(decl.get("lab") or "").strip()
        # THE THIRD AXIS. A person confirms in `TEMPLATE_RULINGS.yaml` which oncology-registry
        # concept a variable realises, and that confirmation reaches `config/semantic.yaml` as
        # `registry_concept`. Without it here, confirming a ruling changed neither the ADS nor the
        # exported graph — the pack's semantic review and its template review were reviewing two
        # different models of the same product, and only one of them was published.
        reg_slot = str(decl.get("registry_concept") or "").strip()
        status = str(decl.get("status") or "active")
        stated = [v for v in (cui, lab, reg_slot) if v and not v.upper().startswith("TODO")]
        # A PARKED BINDING IS NOT A CURRENT MEANING, and must not read as one in a published graph.
        node["rwdp:bindingState"] = ("bound" if stated and status == "active"
                                     else status if stated else "unbound")
        if here:
            node["rwdp:boundVariables"] = [here[0][0]]
        if cui and not cui.upper().startswith("TODO"):
            node["rwdp:boundConcept"] = {"@id": UMLS_CONCEPT_IRI + cui}
        if lab and not lab.upper().startswith("TODO"):
            node["rwdp:boundLab"] = lab
        if reg_slot and not reg_slot.upper().startswith("TODO"):
            # A PLAIN STRING, like `boundLab` and unlike `boundConcept`. A LOINC code and a registry
            # slot are identifiers in vocabularies this repository owns or vendors; a CUI resolves
            # to a public IRI. Minting an IRI for a slot would assert a published identity the
            # registry does not have — it carries `reviewed_by: null` on every module.
            node["rwdp:boundRegistryConcept"] = reg_slot
        concepts.append(node)
        if name in used:
            dnode = {
                "@id": _iri(base, "definition", tumour, _slug(name)),
                "@type": "rwdp:Definition",
                "rwdp:implementsConcept": {"@id": cid},
                "rwdp:tumour": tumour,
                # UNSTATED, not absent: a template is the shape a person fills from the approved
                # workbook, and a silently missing slot would read as one that does not apply.
                "rwdp:slotUnstated": sorted(slots),
            }
            covr = facets["coverage"].get((_overlay_key(tumour), name))
            if covr:
                # CAN THIS PLATFORM BUILD IT, and through which config surface. The difference
                # between a concept someone can use and one that needs engine work before anyone
                # can — `engine_gap` on a variable a study needs is a schedule fact, not a detail.
                dnode["rwdp:coverageClass"] = str(covr.get("class") or "")
                dnode["rwdp:coverageVia"] = str(covr.get("via") or "")
            src = facets["sources"].get((_overlay_key(tumour), name))
            if src:
                dnode["rwdp:commonSources"] = src
            definitions.append(dnode)
        else:
            available.append({
                "@id": _iri(base, "availability", tumour, _slug(name)),
                "@type": "rwdp:ConceptAvailability",
                "rwdp:aboutConcept": {"@id": cid},
                "rwdp:tumour": tumour,
                "rwdp:state": "available",
                "rdfs:comment": f"{name} is defined for the programme and this cut of {tumour} "
                                f"does not instantiate it. Available without re-deriving it, and "
                                f"NOT a statement that it does not apply",
            })
    buckets = {"concepts": concepts, "definitions": definitions, "availability": available,
               "provenance": [], "implementations": [], "rulings": []}
    report = {"tumour": tumour, "concepts": len(concepts), "definitions": len(definitions),
              "available": len(available),
              # DECLARED, NOT INFERRED. `pack` names which pack was read, so a reader can tell an
              # unbound pack from one this could not find.
              "binding": {"pack": (repo_relative(_pack_for(tumour), ROOT)
                                   if _pack_for(tumour) else None),
                          # THREE STATES, AND CONFLATING THEM IS THE DEFECT THIS LAYER EXISTS TO
                          # FIX. `absent` is a pack that has never bound anything; `declared` is a
                          # binding file that resolves but states nothing yet; `bound` is a pack
                          # that says what it means. Reported as one word because "concept_set:
                          # None" and "concept_set: TODO" do not read as different things.
                          "state": ("bound" if any(
                              c.get("rwdp:bindingState") == "bound" for c in concepts)
                              else "declared" if _declared else "absent"),
                          # THE SCOPE IS METADATA, NOT A BINDING, and `declared` is about what
                          # the pack SAYS rather than what it may publish. Both come from the
                          # declaration; only the bindings come from `binding_for`. Tying either
                          # to publishable bindings reported a pack with a binding file as never
                          # having had one.
                          "concept_set": _declared.get("concept_set"),
                          "bound": sum(1 for c in concepts
                                       if c.get("rwdp:bindingState") == "bound"),
                          "unbound": sum(1 for c in concepts
                                         if c.get("rwdp:bindingState") == "unbound"),
                          "problems": binding_problems},
              "slots_declared": sum(len(concept_slots(n, doc)) for n in sorted(used)),
              # THE DOMAIN LAYER'S OWN STATE, reported like the binding's rather than assumed.
              # A graph whose domains all vanished because a file would not parse must not be
              # indistinguishable from one where mCODE simply types nothing.
              "domain": {"source": "governance/reference/mcode_stu4/DOMAIN_MAP.yaml",
                         # PROPOSED, NOT APPROVED, and the report says so rather than leaving a
                         # reader to assume a machine draft was reviewed.
                         "status": str((_dmap or {}).get("status") or "unstated"),
                         "typed": sum(1 for c in concepts if c.get("rwdp:mcodeProfile")),
                         "not_typed_by_mcode": sum(
                             1 for c in concepts
                             if c.get("rwdp:mcodeState") == "not_typed_by_mcode"),
                         "fanout": sum(1 for c in concepts
                                       if c.get("rwdp:mcodeState") == "fanout"),
                         # The LOCAL domain is a separate count, because it is a separate claim.
                         "analytic_domain": sum(1 for c in concepts if c.get("rwdp:domain")),
                         "problems": _dmap_problems},
              "note": f"template for {tumour}: {len(definitions)} concept(s) instantiated and "
                      f"{len(available)} available but unused in this cut. Nothing is approved "
                      f"and no slot is filled — a person fills each from the approved workbook"}
    return ({"@context": dict(CONTEXT, rwdp=_iri(base, "vocab") + "#"),
             "@graph": as_named_graphs(base, buckets)}, report)


def conformance(doc, shapes_doc):
    """Run the shapes against the graph with a CONFORMANT SHACL processor, or say it was not run.

    THE GAP THIS CLOSES. `shapes()` emitted well-formed SHACL and nothing ever executed it, so
    the repository generated a validation artifact and then asserted conformance by never
    checking. SHACL is defined as a processor taking a data graph and a shapes graph and
    returning a validation report; shapes that no processor reads are a description of a check,
    not a check. Both graphs are parsed as real RDF here — which also catches the failure one
    layer down, a document that is valid JSON and not valid RDF.

    FAIL-CLOSED, LIKE EVERY OTHER VERDICT HERE. Without `rdflib` and `pyshacl` the answer is
    `unchecked` with the reason, NEVER `conforms`. An unrun validator reporting success is the
    absence-reads-as-clean failure this grammar exists to prevent, and it is the more dangerous
    form because the artifact looks the same either way.
    """
    try:
        from rdflib import Graph # noqa: PLC0415
        import pyshacl # noqa: PLC0415
    except ImportError as e:
        return {"state": "unchecked",
                "why": f"{e.name} is not installed — the shapes were generated but no conformant "
                       f"SHACL processor ran them, so this is 'not checked', never 'conforms'. "
                       f"Install rdflib and pyshacl (platform/requirements.txt)."}
    from rdflib import Dataset # noqa: PLC0415
    try:
        ds = Dataset()
        ds.parse(data=json.dumps(doc), format="json-ld")
        shapes_g = Graph().parse(data=json.dumps(shapes_doc), format="json-ld")
    except Exception as e: # noqa: BLE001
        return {"state": "not_rdf", "why": f"{type(e).__name__}: {e}"}
    # VALIDATED AS THE UNION, NOT SUBGRAPH BY SUBGRAPH, and the reason is the check that matters
    # most: whether a definition states every slot its concept requires spans TWO subgraphs — the
    # definition lives in `definitions` and the concept that declares the slot lives in
    # `concepts`. Validating each partition alone would silently pass every cross-graph
    # constraint by never seeing the other half. The partition is for governance and for
    # scoping a query; it is not a validation boundary.
    per_graph, data = {}, Graph()
    for quad in ds.quads((None, None, None, None)):
        data.add(quad[:3])
        name = str(quad[3].identifier if hasattr(quad[3], "identifier") else quad[3])
        per_graph[name.rsplit("/", 1)[-1]] = per_graph.get(name.rsplit("/", 1)[-1], 0) + 1
    # `advanced=True` because the slot-completeness rule is a sh:SPARQLConstraint, and pyshacl
    # silently ignores those without it — a validator quietly skipping its sharpest check.
    conforms, _graph, text = pyshacl.validate(data, shacl_graph=shapes_g, inference="none",
                                              advanced=True, abort_on_first=False)
    return {"state": "conforms" if conforms else "violates",
            "triples": len(data), "shape_triples": len(shapes_g),
            "subgraphs": {k: v for k, v in sorted(per_graph.items()) if k != "urn:x-rdflib:default"},
            "report": None if conforms else text}


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__.strip().splitlines()[0])
    ap.add_argument("product", nargs="?", default=None,
                    help="path to a product pack (not needed with --template)")
    ap.add_argument("--base-iri", required=True,
                    help="the identifier namespace, e.g. https://<host>/rwd — REQUIRED and never "
                         "defaulted: minting a namespace is a person's act, not a tool's")
    ap.add_argument("--out", help="write the JSON-LD here")
    ap.add_argument("--check", metavar="FILE",
                    help="compare against an existing export; nonzero if it is stale")
    ap.add_argument("--as-of", help="stamp dct:issued; omitted, the export carries no clock")
    ap.add_argument("--template", metavar="TUMOUR",
                    help="emit the per-tumour SEMANTIC TEMPLATE — the concepts this tumour "
                         "instantiates and the slots each definition must state — as named "
                         "graphs, before any pack approves anything. `product` is ignored")
    ap.add_argument("--validate", action="store_true",
                    help="export, generate the shapes, and RUN them with a conformant SHACL "
                         "processor; reports 'unchecked' rather than success when rdflib/pyshacl "
                         "are absent")
    ap.add_argument("--shapes", action="store_true",
                    help="emit the SHACL shapes for this graph instead of the graph — every "
                         "shape restates a rule this repository already enforces")
    a = ap.parse_args(argv)

    base = a.base_iri.strip()
    if not base.lower().startswith(("http://", "https://")):
        sys.exit(f"--base-iri {base!r} is not an absolute http(s) namespace — an identifier that "
                 f"resolves differently per reader is not an identifier")
    if not a.product and not a.template:
        sys.exit("name a product pack, or use --template <tumour>")
    # ABSOLUTE, BECAUSE THE PATH IS RESOLVED AGAINST THE PROCESS CWD AND WAS COMPUTED AGAINST ROOT.
    # `os.path.relpath(..., ROOT)` produced a path that only resolves when the two coincide; run
    # from `platform/`, which is where CI runs, every `os.path.exists` inside `export` missed, the
    # pack's own `data_product.yaml` read as absent, and the export died claiming the pack states
    # no identity — about a pack that states one. `export` renders its own display path through
    # `repo_relative`, so it has never needed a relative argument.
    pack = os.path.abspath(a.product) if a.product else None
    if pack and not os.path.isdir(pack):
        sys.exit(f"{a.product}: not a product pack directory")

    if a.template:
        doc, report = template(a.template, base)
        # REFUSE BEFORE WRITING. A domain ruling that cannot be read is a defect in the export, not
        # a quieter export — without this the graph loses every `rwdp:domain` and still exits 0.
        # Checked here rather than after the write, because a refusal that has already left the
        # artifact on disk is a warning with extra steps: the next reader finds a file.
        _dp = (report.get("domain") or {}).get("problems") or []
        if _dp:
            print(f"REFUSED — the mCODE domain ruling is not usable, so no domain would be "
                  f"emitted ({len(_dp)} problem(s)). Nothing was written:", file=sys.stderr)
            for _p in _dp:
                print(f"  {_p}", file=sys.stderr)
            return 1
        body = serialize(doc)
        if a.out:
            from rwd_tools import pack_run # noqa: PLC0415
            out_dir = pack_run.restricted_dir(os.path.dirname(os.path.abspath(
                os.path.expanduser(a.out))), what="the semantic template")
            os.makedirs(out_dir, exist_ok=True)
            path = os.path.join(out_dir, os.path.basename(a.out))
            with open(path, "w", encoding="utf-8", newline="\n") as fh:
                fh.write(body)
            print(f"wrote {path}")
        else:
            print(body, end="")
        print(f"# {report['concepts']} concept(s), {report['definitions']} definition(s), "
              f"{report['slots_declared']} slot(s) declared — {report['note']}", file=sys.stderr)
        if a.validate:
            # THE TEMPLATE IS THE ONLY THING THAT CARRIES DEFINITIONS, so this is the only path on
            # which the `Definition` shape and its slot-completeness constraint can ever fire.
            # This branch used to `return 0` above, silently ignoring --validate: stdout was
            # byte-identical with and without the flag, and the check the file's own comments call
            # the sharpest one had never run from any CLI path. `export()` emits no
            # rwdp:Definition, so validating it could not reach the shape either.
            verdict = conformance(doc, shapes(base))
            print(json.dumps(verdict, indent=2, sort_keys=True))
            # THREE OUTCOMES, THREE EXIT CODES. `unchecked` means no SHACL processor ran, and
            # collapsing it into 0 is exactly how automation reads "not run" as "passed" — the
            # thing this tool refuses to do everywhere else. 2 is neither pass nor fail: it says
            # install rdflib and pyshacl, then ask again.
            state = verdict.get("state")
            return 0 if state == "conforms" else (2 if state == "unchecked" else 1)
        return 0

    if a.validate:
        # EXPORT AND SHAPES FROM THE SAME RUN, so the thing validated is the thing generated —
        # validating a file on disk would check whatever was last written, not what this pack says.
        doc, report = export(pack, base, a.as_of)
        verdict = conformance(doc, shapes(base))
        print(json.dumps(verdict, indent=2, sort_keys=True))
        print(f"# {report['exported']} of {report['records']} record(s) exported; "
              f"withheld {report['withheld'] or '{}'}", file=sys.stderr)
        if report.get("binding_withheld"):
            # SAID OUT LOUD. A graph with no bindings and a graph whose bindings were
            # SUPPRESSED are different documents, and stderr was silent about which.
            print(f"# BINDINGS WITHHELD ({len(report['binding_withheld'])}):",
                  file=sys.stderr)
            for _w in report["binding_withheld"][:5]:
                print(f"#   {_w}", file=sys.stderr)
        if verdict["state"] == "conforms":
            return 0
        if verdict["state"] == "unchecked":
            print(f"# NOT CHECKED: {verdict['why']}", file=sys.stderr)
            # 2, NOT 0, AND THE COMMENT HERE USED TO SAY WHY WHILE DOING THE OPPOSITE: "absence of
            # the validator is not a violation; it is also not a pass" — returning 0. To every
            # caller 0 IS a pass, so in CI, where pyshacl is the library likeliest to be missing,
            # the product validation reported success without running. The template path fifteen
            # lines above already returned 2 for the same state and for the stated reason;
            # this is the same rule, applied to the path that skipped it.
            return 2
        return 1

    if a.shapes:
        doc, report = shapes(base), {"nodes": len(SHAPES), "exported": len(SHAPES),
                                     "records": len(SHAPES), "withheld": {},
                                     "note": "SHACL shapes; each names the check here that "
                                             "already enforces it"}
    else:
        doc, report = export(pack, base, a.as_of)
    body = serialize(doc)
    if a.check:
        current = open(a.check, encoding="utf-8").read() if os.path.exists(a.check) else None
        if current != body:
            sys.exit(f"{a.check} is STALE — regenerate it; the governed pack has moved since it "
                     f"was written")
        print(f"{a.check} is current ({report['nodes']} node(s))")
        return 0
    if a.out:
        from rwd_tools import pack_run # noqa: PLC0415
        out_dir = pack_run.restricted_dir(os.path.dirname(os.path.abspath(
            os.path.expanduser(a.out))), what="the semantic export")
        os.makedirs(out_dir, exist_ok=True)
        path = os.path.join(out_dir, os.path.basename(a.out))
        with open(path, "w", encoding="utf-8", newline="\n") as fh:
            fh.write(body)
        print(f"wrote {path}")
    else:
        print(body, end="")
    print(f"# {report['exported']} of {report['records']} record(s) exported; "
          f"withheld {report['withheld'] or '{}'} — {report['note']}", file=sys.stderr)
    return 0


if __name__ == "__main__":
    from rwd_tools.console import use_utf8
    use_utf8()
    sys.exit(main())
