#!/usr/bin/env python3
"""Propose mCODE STU4 candidates for this programme's variables — with evidence, never a ruling.

    python3 platform/tools/mcode_crosswalk.py                      # every tumour, summary
    python3 platform/tools/mcode_crosswalk.py --tumour prostate    # one tumour, full candidates
    python3 platform/tools/mcode_crosswalk.py --json OUT.json      # machine-readable

WHAT THIS IS FOR. A semantic layer is only as good as the concept alignment underneath it, and
aligning 509 inventory variables against 417 mCODE elements by hand is both enormous and exactly
the kind of work that goes stale. This computes the MECHANICAL part — which mCODE elements could
plausibly denote this variable, and on what evidence — so the human part is reduced to ruling on
ranked candidates rather than searching a 417-row spreadsheet 509 times.

IT PROPOSES; IT DOES NOT DECIDE, and the distinction is the whole design. Deciding that a
variable and an mCODE element denote ONE concept is a person's dated act — the same act
`governance/EQUIVALENCE_RULINGS.yaml` records for cross-pack pairs, and the same reason
`NAME_LIFECYCLE.yaml` says no tool writes there. This writes no governed file and mints no
identifier. Its output is a worklist.

EVERY MATCH EXPLAINS ITSELF, which is why the scorer is weighted token overlap and not a model.
`knowledge_graph.py --suggest` already settled this for decision pairing: "a suggester that cannot
explain its match ('these eleven words') is one nobody can review." The same holds here, more
strongly — a reviewer confirming a clinical concept mapping must see WHY it was proposed, and
"the model said so" is not reviewable. Every candidate carries the terms that earned it.

RARE WORDS CARRY THE SIGNAL. Scoring is IDF-weighted over the mCODE element corpus, so "cancer",
"patient" and "the" — present in almost every definition — contribute nearly nothing, while
"castration", "ejection", "Gleason" or "orchiectomy" dominate. Unweighted overlap ranks by
verbosity instead of by meaning, which is the failure mode that makes naive crosswalks useless.

WHAT THIS IS NOT, MEASURED RATHER THAN CLAIMED. Hand-labelling prostate's top-1 candidates above
the floor gives roughly two-thirds correct, one-sixth in the right neighbourhood but on the wrong
profile (GLEASON lands on Primary Cancer Condition where Histologic Grade is better), and one-sixth
plainly wrong (drug names drift onto Cancer Patient because a drug name carries almost no text to
match on). That is a TRIAGE tool — it saves a reviewer from scanning 38 profiles for each of 509
variables — and it is NOT good enough to populate a semantic layer unattended. Anyone reading its
output as an answer rather than a worklist will publish wrong mappings.

THE CEILING IS THE CORPORA, NOT THE THRESHOLD. mCODE writes FHIR-implementer prose and the
inventory writes RWD-study prose; at this corpus size single-word collisions dominate the tail,
and successive attempts to tune it traded one error class for another ("Address > Line" stealing
line-of-therapy, then excluding that text and losing GLEASON and AGE_INDEX).

TWO CHANNELS, AND THE SECOND ONE IS NOW BUILT — SMALLER THAN THIS DOCSTRING ONCE HOPED. The
paragraph above used to end by predicting that the honest next signal was CODES, and that the
join was unavailable because this programme's codelists match drug NAMES rather than bound
terminology. `umls_subset.py` supplies the missing bridge and the prediction was half right.

  TOKEN — IDF-weighted prose overlap, the original channel. Unchanged, and still the one that
  produces most candidates: 120 of 509 variables.

  ANCHOR — a variable whose UMLS label appears inside the description of a code an mCODE value
  set BINDS. `CA125` -> C0006610 -> "Cancer Ag 125" -> LOINC 10334-1. What it yields is a CODE,
  which is a different KIND of evidence: a reviewer can check it against a terminology server
  rather than judge whether six shared words mean the same thing.

  What the anchor channel is NOT is a fix for the 386 abstentions. Six handles anchor, of which
  FIVE are inventory variables and one is a master concept name that no tumour instantiates; they
  produce seven candidate rows, six of them profiles the prose missed and one cross-channel
  agreement. It is a precision instrument with a narrow field of view, and reporting it as a
  coverage improvement would be a straightforward misreading of these numbers. All six were
  hand-checked and are correct; the guards below exist because the ones that were NOT correct had
  to be excluded by name.

  The direct form of the join — intersecting a variable's UMLS concepts with the concepts a value
  set binds — was built first and MEASURED AT FOUR variables out of 509, because mCODE binds
  LOINC *test* codes while a variable names an *analyte*, and UMLS gives those different CUIs.
  That is why the channel matches labels against descriptions instead. Codelist-to-value-set
  overlap, the thing originally predicted, is still unavailable: no pack declares `vocabularies:`
  and no pack uses a code operator, so there is still nothing coded on this side to join.

ABSTENTION IS A RESULT, NOT A GAP. Where nothing clears the floor, the variable is reported as
NO CANDIDATE, and that verdict is as important as any match: it is how the domain-IP boundary
becomes visible. Line-of-therapy category, rwPFS, TTNT and cohort assignment SHOULD abstain —
mCODE models exchanged clinical facts and has no profile for a study-defined derivation. A
crosswalk that forced a match for them would be actively harmful, because it would present
programme IP as a standards claim.
"""
from __future__ import annotations

import argparse
import json
import math
import re
import sys
from collections import Counter, defaultdict
from pathlib import Path

from rwd_services import workspace_root
ROOT = workspace_root(__file__)
INVENTORY = ROOT / "governance/reference/variable_inventory/INVENTORY.yaml"
DICTIONARY = ROOT / "governance/reference/mcode_stu4/DICTIONARY.json"
VALUE_SET_CODES = ROOT / "governance/reference/mcode_stu4/VALUE_SET_CODES.json"
TERMINOLOGY = ROOT / "governance/reference/umls/TERMINOLOGY.json"

_NORMALISE = None          # resolved once by _handle(); see the note there

# Words that appear across most clinical definitions and therefore separate nothing. IDF already
# suppresses them; listing them explicitly keeps a short definition from being carried entirely by
# filler when its two content words happen to be rare.
STOP = {
    "the", "a", "an", "of", "and", "or", "to", "in", "for", "on", "at", "by", "with", "from",
    "is", "are", "was", "were", "be", "been", "this", "that", "these", "those", "it", "its",
    "as", "if", "not", "no", "any", "all", "each", "which", "who", "whom", "whose", "when",
    "used", "using", "use", "may", "can", "should", "must", "will", "would", "e.g", "eg", "i.e",
    "value", "values", "code", "codes", "coded", "date", "dates", "type", "types", "name",
    "names", "status", "reported", "record", "recorded", "data", "element", "elements",
}

# Repo category -> mCODE profile-title fragments that category plausibly lands in. A PRIOR, applied
# as a multiplier and never as a filter: a filter would hide a correct cross-category match (a
# biomarker that is really a Human Specimen property), and hiding a true match to raise apparent
# precision is the wrong trade for a worklist a person reviews anyway.
CATEGORY_PRIOR = {
    "demographics":      ("cancer patient", "body surface area", "patient"),
    "staging_histology": ("stage", "tnm", "histologic", "tumor", "primary cancer condition",
                          "secondary cancer condition", "morphology"),
    "biomarkers":        ("tumor marker", "genomic", "genomics", "human specimen", "variant"),
    "treatment":         ("medication", "surgical procedure", "radiotherapy"),
    # DELIBERATELY EMPTY, for the same reason `eligibility_index` is. This category legitimately
    # mixes two kinds of thing: clinical facts (progression, response), which do belong near
    # Cancer Disease Status, and study-defined time-to-event endpoints (rwPFS, TTNT, TTP, rwTTD),
    # which MCODE_ALIGNMENT_PROPOSAL 3c rules mCODE has no box for and which must abstain.
    #
    # A category-wide prior cannot tell them apart, and MEASURED, this one bought almost nothing
    # else: of the twelve candidate rows it alone was responsible for, eleven were time-to-event
    # endpoints 3c says must abstain and one (`RW_RESPONSE`) was arguable. The 1.6x bonus was the
    # sole reason six 3c rows cleared the floor — remove it and they score 0.36 against a floor of
    # 0.40. The clinical-fact matches in this category clear the floor on their text alone.
    "outcomes":          (),
    "comorbidity_labs":  ("comorbidities", "ecog", "karnofsky", "lansky", "performance status",
                          "deauville"),
    "eligibility_index": (),          # deliberately empty — index conventions are study constructs
}
PRIOR_BONUS = 1.6          # a category-consistent profile scores 60% higher than the same overlap
                           # in an unrelated profile. Enough to order candidates, too small to
                           # manufacture one where the text agrees on nothing.
FLOOR = 0.40               # below this, report NO CANDIDATE rather than the best of a bad field.
MIN_SHARED = 2             # one shared word is a coincidence, not a mapping.

# FHIR PLUMBING, EXCLUDED AS THE CARRIER OF A CLINICAL VARIABLE. `Status`, `Subject`, `Code` and
# `Category` appear on nearly every profile because FHIR requires them, not because they carry
# meaning about the concept. The first cut of this tool scored all 417 elements equally and duly
# proposed `OS -> History of Metastatic Cancer :: Status` on the strength of one shared word. A
# variable denotes a PROFILE — "is this a Tumor Marker Test?" — and then some element within it
# carries the value. These are excluded from being named as that carrier; they still contribute
# their definition text to the profile's own bag, because they do describe the profile.
STRUCTURAL = {
    "status", "subject", "category", "category > us-core", "code", "performer", "encounter",
    "identifier", "focus", "reported", "requester", "reason reference", "data absent reason",
    "part of", "based on", "note", "extension", "identifier > system", "identifier > value",
    # Demographic plumbing, excluded for a sharper reason than the rest: it does not merely fail
    # to carry meaning, it actively STEALS matches. "Address > Line" collides with line of
    # therapy, "Address > State" with disease state, and the first cut duly proposed DOCETAXEL,
    # AGE_INDEX and TSST as properties of a patient's street address.
    "address", "address > line", "address > city", "address > state", "address > postal code",
    "address > country", "address > use", "address > period", "telecom", "telecom > system",
    "telecom > value", "telecom > use", "name", "name > family", "name > given", "name > use",
    "communication", "communication > language", "gender", "birthsex",
}


def _tokens(text) -> list:
    """Content words, lowercased, lightly singularised. Crude stemming ON PURPOSE: an aggressive
    stemmer collapses clinically distinct terms, and this corpus is small enough that the recall
    gained does not pay for a wrong merge a reviewer then has to catch."""
    if not text:
        return []
    out = []
    for w in re.split(r"[^a-z0-9]+", str(text).lower()):
        if len(w) < 3 or w in STOP:
            continue
        if len(w) > 4 and w.endswith("s") and not w.endswith("ss"):
            w = w[:-1]
        out.append(w)
    return out


def _name_tokens(name) -> list:
    """A variable name split into words, with known clinical stems expanded.

    Inventory names are SHOUTED and run together (`DXDATE`, `PSADT`, `LOT1START`), so splitting on
    case and underscore alone under-recovers badly: `DXDATE` shares nothing with mCODE's "date of
    diagnosis" until `dx` becomes `diagnosis`. The expansion list is deliberately short and
    oncology-specific — every entry is a stem a reviewer would read the same way."""
    s = str(name or "").lower()
    s = re.sub(r"[^a-z0-9]+", " ", s)
    for stem, words in (("dx", "diagnosis"), ("psa", "prostate specific antigen"),
                        ("ecog", "ecog performance"), ("bmi", "body mass index"),
                        ("bsa", "body surface area"), ("lot", "line therapy"),
                        ("os", "overall survival"), ("pfs", "progression free survival"),
                        ("ttnt", "time next treatment"), ("mets", "metastasis"),
                        ("dthdt", "death"), ("dth", "death"), ("fu", "follow up"),
                        ("hist", "histology"), ("grp", "group"), ("cat", "category")):
        s = re.sub(rf"\b{stem}\b", words, s)
        s = re.sub(rf"(?<=[a-z]){stem}\b", " " + words, s)
    return _tokens(s)


def load_mcode() -> tuple:
    """The dictionary as (raw, [(element, bag)], idf) — bags built once, IDF over the mCODE corpus.

    IDF is computed over mCODE elements rather than over the inventory because mCODE is the fixed
    side: it is what "rare" has to mean for a term to discriminate BETWEEN candidate profiles.
    """
    d = json.loads(DICTIONARY.read_text(encoding="utf-8"))
    prof_desc = {p["title"]: p.get("description") or "" for p in d["profiles"]}
    docs = []
    for e in d["elements"]:
        bag = Counter(_tokens(e.get("definition")) + _name_tokens(e.get("element"))
                      + _tokens(e["profile"]) + _tokens(prof_desc.get(e["profile"], "")))
        docs.append((e, bag))
    df = Counter()
    for _, bag in docs:
        df.update(bag.keys())
    n = len(docs)
    idf = {w: math.log(n / (1 + c)) + 1.0 for w, c in df.items()}
    return d, docs, idf


def score(var_bag: Counter, doc_bag: Counter, idf: dict, category, profile) -> tuple:
    """IDF-weighted coverage of the variable by the profile, times the category prior.

    -> (score, evidence). Score is the fraction of the variable's IDF mass that the profile
    explains, so 0.4 means "this profile accounts for about 40% of what this variable says".
    """
    shared = set(var_bag) & set(doc_bag)
    if not shared:
        return 0.0, []
    num = sum(idf.get(w, 1.0) for w in shared)
    # COVERAGE OF THE VARIABLE, not cosine similarity: "how much of what this variable means does
    # this profile account for?" Cosine divides by the profile bag too, and a profile bag is the
    # union of up to 41 element definitions — so the wordiest profiles were penalised into
    # abstention and demographics matched NOTHING. This denominator depends only on the variable,
    # so scores are comparable across profiles and readable as a fraction.
    s = num / (sum(idf.get(w, 1.0) for w in var_bag) or 1.0)
    pl = profile.lower()
    if any(frag in pl for frag in CATEGORY_PRIOR.get(category, ())):
        s *= PRIOR_BONUS
    # `shared` is a SET and many terms tie on IDF, so a key of -idf alone left the surviving
    # six to set iteration order — the evidence a reviewer reads, and the --json bytes,
    # changed with PYTHONHASHSEED. The word itself is the tie-break.
    ev = sorted(shared, key=lambda w: (-idf.get(w, 1.0), w))[:6]
    return s, ev


def _profile_bags(docs) -> dict:
    """One bag per PROFILE — its title, description and every element it declares.

    THE UNIT OF MATCH IS THE PROFILE, not the element, and this is the single largest correctness
    fix in the tool. 417 elements against 509 variables is mostly noise: the same handful of
    plumbing elements recur on every profile, so the top hit is decided by which profile happened
    to share one common word. 38 profiles is the question a reviewer is actually able to answer —
    "does this variable denote a Tumor Marker Test?" — and it is the level at which mCODE itself
    draws its boxes.
    """
    bags = defaultdict(Counter)
    for e, dbag in docs:
        # Structural elements stay IN the profile bag, though they can never be named as a
        # carrier. Excluding them from the bag as well was tried and reverted: it stripped the
        # demographic and staging signal that makes the right matches right, and GLEASON fell
        # from Primary Cancer Condition onto Karnofsky while REGION1 matched Genomic REGION
        # Studied. Their text describes the profile even when it cannot carry a clinical value.
        bags[e["profile"]].update(dbag)
    return dict(bags)


def _carrier(docs, profile: str, var_bag: Counter, idf: dict):
    """Within a matched profile, the element most likely to CARRY the value — plumbing excluded."""
    best = (0.0, None)
    for e, dbag in docs:
        if e["profile"] != profile or str(e["element"]).strip().lower() in STRUCTURAL:
            continue
        shared = set(var_bag) & set(dbag)
        if not shared:
            continue
        s = sum(idf.get(w, 1.0) for w in shared)
        if s > best[0]:
            best = (s, e)
    return best[1]


# ---- THE ANCHOR CHANNEL -------------------------------------------------------------------------
#
# The token channel matches this programme's prose against mCODE's prose, and this module's
# docstring records why that tops out: the corpora disagree, not the threshold. The anchor channel
# is the second signal it named — but it is NOT the "code overlap" that sentence imagined, and the
# difference is worth stating because it was measured rather than assumed.
#
# WHAT DOES NOT WORK, MEASURED. Intersecting a variable's UMLS concepts with the concepts mCODE's
# value sets bind fires for FOUR of 509 variables. mCODE binds LOINC *test* codes ("Prostate
# specific Ag [Mass/volume] in Serum or Plasma") while a variable names an *analyte* ("PSA"), and
# UMLS gives those different CUIs. A channel built that way would look principled and say nothing.
#
# WHAT DOES WORK. UMLS carries the analyte's own labels, and one of them is the LOINC part
# name that the test code's description is BUILT from: `CA125` -> C0006610 -> "Cancer Ag 125" ->
# "Cancer Ag 125 [Units/volume] in Serum or Plasma" -> LOINC 10334-1, bound by Tumor Marker Test.
# So the anchor is a label-to-description containment, and what it yields is a CODE — which is
# what makes it different in kind from the token channel. A candidate carrying a bound code is a
# claim a reviewer can check against a terminology server; a candidate carrying six shared words
# is a claim they can only judge.
#
# IT IS A PRECISION INSTRUMENT AND ITS YIELD IS SMALL, which the run reports rather than hides.
# mCODE enumerates codes for 74 of its 103 value sets and they reach a couple of dozen profiles,
# so the channel anchors six handles — five inventory variables — all of them well-coded
# biomarkers and staging systems. Anyone reading it as a fix for the 386 abstentions has misread
# it.
#
# THE THREE GUARDS ARE THE SAME DISCIPLINE THE TOKEN CHANNEL ALREADY USES, and each was added
# because a measured false positive demanded it, not on principle:
#
#   AMBIGUOUS HANDLES CANNOT ANCHOR. `OS` is overall survival here and an os (a bone) in UMLS, and
#   the unguarded channel duly anchored it to Human Specimen :: Bone. That is precisely the
#   domain-IP boundary MCODE_ALIGNMENT_PROPOSAL 3c says must abstain — a study-defined endpoint
#   presented as a standards claim is the most harmful output this tool can produce.
#
#   ONE TOKEN IS A COINCIDENCE. `region` matched "4q12 chromosome region rearrangements" and
#   `del 5q` matched "BRCA1 gene.c.185 del AG", each on a single common word.
#
#   A MATCH CARRIED ONLY BY GENERIC TOKENS IS NOT A MATCH. `CALR mutation` matched "FLT3 gene
#   targeted mutation analysis" on {gene, mutation} — two tokens, both meaningless here. The
#   matched set must contain a term that is RARE across the value-set corpus, which is the same
#   IDF median guard the token channel applies, over the corpus this channel actually reads.
ANCHOR_MIN_TOKENS = 2


def _content(text) -> set:
    """Tokens a containment test may be carried by. Same folding as the token channel."""
    return {w for w in _tokens(text)}


def load_anchors():
    """{normalised handle: [anchor, ...]} — every variable handle a bound mCODE code anchors.

    Returns an empty map, and says so to the caller, when either reference artifact is absent:
    the terminology subset is built from a licensed release that most checkouts do not hold, and
    a channel that silently contributed nothing would be indistinguishable from one that ran.
    """
    # THE SWITCH IS ASKED BEFORE THE FILE IS OPENED. `TERMINOLOGY.json` is a UMLS projection, so
    # a deployment that has the file and no licence to consult it must get the same answer as one
    # that lacks the file entirely — and this asked only whether the file EXISTED. The two
    # states are reported separately because they are different facts: "nobody built it" is work
    # to do, "the layer is off" is a policy that was decided.
    try:
        from rwd_tools import umls_subset as _us                                        # noqa: PLC0415
        if not _us.enabled():
            return {}, ("the UMLS layer is declared OFF in reference/umls/LAYER.yaml, so this "
                        "channel was NOT consulted. mCODE`s own VALUE_SET_CODES still resolve; "
                        "only the terminology anchors are withheld")
    except Exception as _e:                                               # noqa: BLE001
        # AND HERE TOO. Falling through to the file test meant a failed READ of the policy
        # behaved exactly like a policy that said yes, so long as the projections happened to be
        # on disk — which is precisely the deployment this switch exists to protect.
        return {}, (f"the UMLS layer policy could not be read ({type(_e).__name__}), so this "
                    f"channel was NOT consulted. Failing to ask is not permission")
    if not (VALUE_SET_CODES.exists() and TERMINOLOGY.exists()):
        return {}, "not built — run umls_subset.py --build against a UMLS release"
    codes = json.loads(VALUE_SET_CODES.read_text(encoding="utf-8"))
    terms = json.loads(TERMINOLOGY.read_text(encoding="utf-8"))
    dictionary = json.loads(DICTIONARY.read_text(encoding="utf-8"))

    # THE TWO ARTIFACTS MUST BE THE SAME PAIR, and nothing else checks it. The terminology layer
    # resolves mCODE's codes to concepts and records which workbook it did that against; the codes
    # artifact is that workbook's extract. Regenerating one without the other leaves a map from
    # codes that no longer exist to concepts nobody re-resolved, and the channel then produces
    # FEWER anchors and says nothing — measured at four instead of six when the pair was
    # deliberately mismatched. Silent degradation is the worst shape a mismatch can take, because
    # a smaller number still looks like an answer.
    built_from = next((i for i in (terms.get("inputs") or [])
                       if i.get("kind") == "fhir_ig_workbook"), None)
    if built_from is None:
        # NO WORKBOOK ENTRY AT ALL is the maximally stale pair, not an exemption: the layer was
        # built with no codes artifact present, so nothing in it resolved an mCODE code.
        return {}, ("stale pair — the terminology layer records no mCODE workbook, so it was "
                    "built without one; rebuild it with umls_subset.py --build")
    if built_from.get("sha256") != codes.get("source_file_sha256"):
        return {}, (f"stale pair — the terminology layer was built against workbook "
                    f"{str(built_from.get('sha256'))[:12]} and the codes artifact is "
                    f"{str(codes.get('source_file_sha256'))[:12]}; rebuild the layer with "
                    f"umls_subset.py --build")

    url_to_title = {v["url"]: v["title"] for v in dictionary["value_sets"]}
    members = defaultdict(list)
    for row in codes["codes"]:
        if row.get("description"):
            members[row["value_set"]].append(row)
    # DOCUMENT FREQUENCY OVER THE DESCRIPTIONS, not over mCODE's element prose: "gene" and
    # "mutation" are common in this corpus and rare in the other, and the guard has to know which
    # corpus it is guarding.
    #
    # A FREQUENCY THRESHOLD, NOT THE IDF MEDIAN THE TOKEN CHANNEL USES. That was the first
    # attempt and it was wrong for this corpus rather than merely strict: these descriptions are
    # short and mostly distinct, so the median IDF sits at a document frequency of two and
    # `Ann Arbor` and `microsatellite instability` were both rejected as generic while nothing
    # realistic survived — one anchor from the whole programme.
    #
    # HALF A PERCENT, WITH A FLOOR OF FIVE. A term carried by more than 0.5% of the descriptions
    # does not identify a specific concept within them. On the 2,626-description corpus that is
    # df <= 13, which separates braf(1), jak2(2), microsatellite(3), binet(5), ann/arbor(9) and
    # tnm(12) from gene(99), stage(125), tumor(115) and node(320).
    #
    # The boundary is where it is because of a measured failure, not taste. At 1% the threshold
    # was 26 and `mutation` sits at exactly 26, which let the label "RO Gene Mutation" anchor CALR
    # onto "BRCA1 gene mutations found" — two tokens, both scaffolding, the wrong gene entirely.
    # The floor of five keeps the rule meaningful if the corpus ever shrinks, where 0.5% would
    # otherwise round down to a threshold nothing can clear.
    df = Counter()
    for rows in members.values():
        for row in rows:
            df.update(_content(row["description"]))
    n = sum(len(v) for v in members.values()) or 1
    idf = {w: math.log(n / (1 + c)) + 1.0 for w, c in df.items()}
    generic_above = max(5, n // 200)

    binds = defaultdict(set)
    for e in dictionary["elements"]:
        title = url_to_title.get(str(e.get("value_set_uri") or "").strip())
        if title in members:
            binds[e["profile"]].add((title, e["element"]))

    out = defaultdict(list)
    for handle, meta in (terms.get("programme_handles") or {}).items():
        if meta.get("ambiguous"):
            continue                       # see the guards above — this one is not a tuning knob
        labels = {handle}
        for cui in meta.get("concepts") or []:
            for lab in (terms["concepts"].get(cui) or {}).get("labels") or []:
                labels.add(lab["str"])
        seen = {}
        for label in sorted(labels):
            lt = _content(label)
            if len(lt) < ANCHOR_MIN_TOKENS:
                continue
            if not any(0 < df.get(w, 0) <= generic_above for w in lt):
                continue          # carried only by terms this corpus uses everywhere
            # SORTED, BECAUSE SET ITERATION ORDER IS NOT AN ANSWER. `binds` holds sets and
            # `members` a dict, and iterating them raw made the output depend on PYTHONHASHSEED:
            # the same inputs serialised to six different digests across six seeds, and
            # `binding_element` flipped between two genuinely-correct answers on the same code.
            # `--json` has to be byte-stable for a `--check` to mean "is this current".
            for profile in sorted(binds):
                for title, element in sorted(binds[profile]):
                    for row in members[title]:
                        if not lt <= _content(row["description"]):
                            continue
                        key = (profile, row["code_system"], row["code"])
                        if key in seen:
                            # ANOTHER ELEMENT ON THE SAME PROFILE BINDS THE SAME CODE, which is
                            # ordinary in mCODE — Procedure Intent is bound by both `Extension`
                            # and `Treatment Intent`. Recording only whichever came first made the
                            # reviewable claim arbitrary, so every binding element is kept.
                            prior = seen[key]
                            if element not in prior["binding_elements"]:
                                prior["binding_elements"].append(element)
                                prior["binding_elements"].sort()
                            continue
                        anchor = {
                            # BINDING, NOT CARRIER, and they are different claims. `_carrier`
                            # answers "which element holds this variable's value", and refuses to
                            # name FHIR plumbing for it. This answers "which elements' value-set
                            # binding produced this code", and the answer is very often
                            # `Observation.code` — plumbing by the other question's standard, and
                            # a fact by this one. Overloading one field with both made the
                            # anchored rows read as though the token channel had named `Code` a
                            # carrier, which it never would.
                            "profile": profile, "binding_elements": [element],
                            "value_set": title, "code_system": row["code_system"],
                            "code": row["code"], "code_description": row["description"],
                            "matched_label": label,
                            "evidence_terms": sorted(lt, key=lambda w: (-idf.get(w, 1.0), w))[:6],
                        }
                        seen[key] = anchor
                        out[handle].append(anchor)
    return dict(out), None


def _handle(name):
    """A variable name as the terminology subset keys it. ONE definition, imported rather than
    re-implemented: a second copy that folded differently would look up handles that exist and
    find nothing, which reads exactly like a channel with no matches.

    The import is resolved ONCE. Inserting on sys.path per call took it from 8 entries to 519 in
    a single run — 512 copies of platform/tools, ahead of everything, permanent for any importer.
    """
    global _NORMALISE
    if _NORMALISE is None:
        here = str(Path(__file__).resolve().parent)
        from rwd_tools import umls_subset                                               # noqa: PLC0415
        _NORMALISE = umls_subset.normalise
    return _NORMALISE(str(name or "").replace("_", " "))


def crosswalk(tumour=None, top=3, channel="both") -> dict:
    import yaml
    inv = yaml.safe_load(INVENTORY.read_text(encoding="utf-8"))
    _, docs, idf = load_mcode()
    anchors, anchor_note = ({}, "disabled") if channel == "token" else load_anchors()
    # AN INVENTORY THAT YIELDS NOTHING IS A READ FAILURE, NOT AN EMPTY PROGRAMME. `inv.get(
    # "tumours") or {}` turned a misspelled top-level key into `509 variables` becoming
    # `0 variables, 0 with a candidate (0 abstained)` at exit 0 — a clean-looking run that had
    # looked at nothing. There is no state of this repository in which the answer is zero.
    if not (inv.get("tumours") or {}):
        raise ValueError(f"{INVENTORY} has no `tumours` mapping — the crosswalk would report "
                         f"zero variables and zero abstentions, which is a read failure wearing "
                         f"the shape of a result")
    pbags = _profile_bags(docs)
    # The IDF median over terms actually used: a match must share at least one term ABOVE it.
    # Without this guard, two structural words ("time", "patient") clear MIN_SHARED together and
    # the abstention the domain-IP boundary depends on never happens.
    med = sorted(idf.values())[len(idf) // 2] if idf else 1.0
    rows = []
    for tum, body in (inv.get("tumours") or {}).items():
        if tumour and tum != tumour:
            continue
        for v in ((body.get("variables") if isinstance(body, dict) else body) or []):
            if not isinstance(v, dict):
                continue
            # `common_sources` is DELIBERATELY EXCLUDED. It says where a value is typically
            # found ("Structured EHR fields", "Chart abstraction"), which is provenance, not
            # meaning — and including it made every variable sourced from structured EHR match
            # any mCODE element whose definition happened to say "structured". TESTOSTERONE,
            # RACE_ETH and CABAZITAXEL all landed on Surgical Procedure :: Body Site on that
            # one word.
            bag = Counter(_tokens(v.get("definition_sketch")) + _name_tokens(v.get("name")))
            cat = v.get("category")
            scored = []
            for profile, pbag in ([] if channel == "anchor" else pbags.items()):
                s_, ev = score(bag, pbag, idf, cat, profile)
                if s_ < FLOOR or len(ev) < MIN_SHARED:
                    continue
                if not any(idf.get(w, 1.0) > med for w in ev):
                    continue                      # carried only by structural words — abstain
                scored.append((s_, profile, ev))
            scored.sort(key=lambda x: -x[0])
            cands = []
            for s_, profile, ev in scored[:top]:
                car = _carrier(docs, profile, bag, idf)
                cands.append({"score": round(s_, 3), "profile": profile,
                              "channel": "token",
                              "carrier_element": car["element"] if car else None,
                              "data_type": (car or {}).get("data_type"),
                              "value_set_uri": (car or {}).get("value_set_uri"),
                              "evidence_terms": ev})
            # ANCHORS ARE MERGED, NEVER RANKED AGAINST TOKEN SCORES. The two channels measure
            # different things — one a fraction of shared meaning, the other the presence of a
            # bound code — and a single ordering over both would invent a comparison neither
            # supports. An anchored profile the token channel also found is marked `both`, which
            # is the strongest thing this tool can say; an anchored profile it missed is ADDED,
            # because a bound code is evidence whether or not the prose agreed.
            anchored = anchors.get(_handle(v.get("name"))) or []
            by_profile = {c["profile"]: c for c in cands}
            # SNAPSHOT BEFORE MERGING, AND FROM THE FULL SCORED SET. `both` means the two channels
            # independently agreed, which is a fact about what the token channel MEASURED — not
            # about what survived `--top`.
            #
            # Testing against the live map made a SECOND anchor on the same profile find the
            # candidate the FIRST one had just created and label it `both`: three Ann Arbor codes
            # on Cancer Stage Profile reported as cross-channel agreement that never happened.
            # Testing against the TRUNCATED list was the mirror of that bug — a profile the token
            # channel scored above the floor but ranked below `--top` was labelled `anchor` and
            # given `score: null`, so `--top 1` and `--top 3` disagreed about whether the channels
            # agreed, on identical evidence.
            token_scores = {p: (s_, ev) for s_, p, ev in scored}
            for a in anchored:
                c = by_profile.get(a["profile"])
                if c is None and a["profile"] in token_scores:
                    # SCORED, BUT RANKED OUT BY --top. It is still cross-channel agreement, and
                    # the token score is a measurement that exists — so the candidate is restored
                    # with it rather than fabricated as anchor-only. `--top` decides how much to
                    # SHOW; it must not decide what the tool claims to have found.
                    s_, ev = token_scores[a["profile"]]
                    car = _carrier(docs, a["profile"], bag, idf)
                    c = {"score": round(s_, 3), "profile": a["profile"], "channel": "both",
                         "carrier_element": car["element"] if car else None,
                         "data_type": (car or {}).get("data_type"),
                         "value_set_uri": (car or {}).get("value_set_uri"),
                         "evidence_terms": ev}
                    cands.append(c)
                    by_profile[a["profile"]] = c
                elif c is None:
                    # An anchor-only candidate has NO token score, and that field stays None
                    # rather than borrowing a number. A score of 0.0 would sort it below every
                    # token match; a score of 1.0 would claim a certainty the channel never
                    # measured. The absence is the honest value.
                    c = {"score": None, "profile": a["profile"], "channel": "anchor",
                         "carrier_element": None, "data_type": None,
                         "value_set_uri": None, "evidence_terms": []}
                    cands.append(c)
                    by_profile[a["profile"]] = c
                elif c["channel"] == "token":
                    c["channel"] = "both"
                c.setdefault("anchors", []).append(
                    {k: a[k] for k in ("binding_elements", "value_set", "code_system", "code",
                                       "code_description", "matched_label", "evidence_terms")})
            rows.append({
                "tumour": tum, "name": v.get("name"), "category": cat,
                "master": v.get("master"),
                "scope": "shared_concept" if v.get("master") else "tumour_specific",
                "coverage_class": (v.get("coverage") or {}).get("class"),
                "definition": v.get("definition_sketch"),
                "candidates": cands,
            })
    return {"floor": FLOOR, "prior_bonus": PRIOR_BONUS, "min_shared": MIN_SHARED,
            "channel": channel, "anchor_handles": len(anchors), "anchor_note": anchor_note,
            "rows": rows}


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    ap.add_argument("--tumour")
    ap.add_argument("--top", type=int, default=3)
    ap.add_argument("--json")
    ap.add_argument("--min-score", type=float, default=None)
    ap.add_argument("--channel", choices=("token", "anchor", "both"), default="both",
                    help="token: prose overlap only. anchor: bound codes only. both (default).")
    a = ap.parse_args()
    if not DICTIONARY.exists():
        print(f"missing {DICTIONARY} — extract the STU4 dictionary first", file=sys.stderr)
        return 2
    res = crosswalk(a.tumour, a.top, a.channel)
    rows = res["rows"]
    if a.min_score is not None:
        for r in rows:
            # AN ANCHOR-ONLY CANDIDATE HAS NO TOKEN SCORE, so it cannot be below a token
            # floor and is kept. Comparing `None >= float` raised TypeError, which made
            # --min-score unusable on the default channel: the flag worked only with
            # --channel token, exactly where it was least needed.
            r["candidates"] = [c for c in r["candidates"]
                               if c["score"] is None or c["score"] >= a.min_score]
    if a.json:
        # newline="" so the bytes are identical on every platform: Path.write_text opens in
        # text mode with newline=None, which translated 616 line endings to CRLF here.
        with open(a.json, "w", encoding="utf-8", newline="\n") as fh:
            json.dump(res, fh, indent=1, ensure_ascii=False)
        print(f"wrote {a.json}")
    matched = [r for r in rows if r["candidates"]]
    anchored = [r for r in rows if any(c.get("anchors") for c in r["candidates"])]
    print(f"CROSSWALK — {len(rows)} variables, {len(matched)} with a candidate "
          f"({len(rows) - len(matched)} abstained), floor={res['floor']}, "
          f"channel={res['channel']}")
    if res.get("anchor_note"):
        # A channel that contributed nothing and a channel that never ran must not print alike.
        print(f"  anchor channel: {res['anchor_note']}")
    else:
        print(f"  anchor channel: {len(anchored)} variable(s) carry a bound code, "
              f"from {res['anchor_handles']} anchorable handle(s)")
    by_cat = defaultdict(lambda: [0, 0])
    for r in rows:
        by_cat[r["category"]][0] += 1
        if r["candidates"]:
            by_cat[r["category"]][1] += 1
    print("\n  category            vars  with candidate")
    for c, (n, m) in sorted(by_cat.items(), key=lambda kv: -kv[1][0]):
        print(f"  {str(c):20}{n:5}{m:8}   {100*m//max(n,1):3d}%")
    if a.tumour:
        print(f"\n--- {a.tumour} ---")
        for r in rows:
            if not r["candidates"]:
                print(f"\n  {r['name']}  [{r['category']}]  -> NO CANDIDATE")
                continue
            print(f"\n  {r['name']}  [{r['category']}]")
            # THE TOP TOKEN CANDIDATE PLUS EVERY ANCHORED ONE. Printing `candidates[0]` alone
            # hid the anchor channel entirely: an anchor-only candidate is appended after the
            # token matches, so the one row carrying a bound code was the one row never shown.
            shown = [r["candidates"][0]] + [c for c in r["candidates"][1:] if c.get("anchors")]
            for c in shown:
                score = "anchor" if c["score"] is None else c["score"]
                print(f"    -> {c['profile']} :: {c.get('carrier_element')}  "
                      f"({score}, {c['channel']})")
                if c["evidence_terms"]:
                    print(f"       terms: {', '.join(c['evidence_terms'])}")
                for anc in c.get("anchors") or []:
                    print(f"       CODE {anc['code_system']} {anc['code']} bound by "
                          f"{', '.join(anc['binding_elements'])} via {anc['matched_label']!r}")
                    print(f"            {anc['code_description'][:72]}")
    return 0


if __name__ == "__main__":
    from rwd_tools.console import use_utf8
    use_utf8()
    raise SystemExit(main())
