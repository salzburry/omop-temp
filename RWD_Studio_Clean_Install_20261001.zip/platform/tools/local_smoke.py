#!/usr/bin/env python3
"""Build ANY configured product's ADS on a local Spark, on synthetic sources, and print it.

    python3 platform/tools/local_smoke.py fixtures/oncology/prostate/202606
    python3 platform/tools/local_smoke.py <pack> --evidence-out ~/rwdp-views/build.json

    pip install pyspark pyyaml     # a local in-process Spark; needs Java 17 or 21 on PATH

Proves the shared engine assembles that product end-to-end — sources → LOT → index → demographics →
clinical → treatment → outcomes → assemble → cohort union — with no cluster and no vendor data. The
real run is the SAME shared engine and the SAME SCIENTIFIC configuration pointed at delivered tables
through the Databricks bundle — with the real delivery bindings, not the synthetic ones below. The
run half is exactly the half Gate 3 governs, so "the same configuration" is true of the science and
false of the delivery.

TAKES A PACK. This was `tools/smoke_prostate.py` with `SLUG = "prostate"` written into it, at the
repository root, outside `platform/tools/` where every other tool lives. A tumour name in shared code
is a latent failure for the next product, and a demo that only ever runs one of them is a demo of one
of them.

AND IT IMPORTS ITS FIXTURES rather than carrying them. The old file said in its own docstring that
the synthetic-source builders were "copied verbatim" from the smoke suite; by the time anyone
compared, `_synth_src` was 37 lines here against 48 there. So the thing being shown on a screen was
built from a dataset CI does not test. One definition now lives in
`platform/tests/fixtures/synthetic_sources.py` and both callers read it.

SYNTHETIC IS A DEVELOPMENT AID, NOT EVIDENCE. Nothing this prints is Gate 3 or Gate 5 evidence: the
rows are fabricated here, and `--evidence-out` writes a build SUMMARY for the flow page, which
labels it synthetic on its face.
"""
import argparse
import json
import hashlib
import os
from pathlib import Path
import sys

TOOLS = os.path.dirname(os.path.abspath(__file__))
from rwd_services import workspace_root
ROOT = str(workspace_root(__file__))
from rwd_tools import console                                                    # noqa: E402
from rwd_tools.spec_extract import repo_relative                                  # noqa: E402

from rwd_tools import pack_run                                                      # noqa: E402 — ONE outside-the-checkout guard

# Enough of a delivery to resolve table names; nothing is read from them, since the frames are built
# in memory. Named here so the run does not depend on a pack having been pointed at a real cut.
SYNTHETIC_RUN = {"run.refresh": "synthetic", "run.source_schema": "synthetic",
                  "run.output_schema": "synthetic"}


def _digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(",", ":"),
                                     ensure_ascii=True).encode("utf-8")).hexdigest()


def input_manifest(pack, *, root=None):
    """Exact local source/config bytes and installed Python package identities.

    No Spark or Java process starts here. All native engine modules and schemas
    are discovered, including additions; no submitted receipt supplies read paths.
    This is local reproducibility evidence, not a signature or clinical approval.
    """
    import importlib.metadata
    import platform
    from engine.config import merged_raw
    base, product = Path(root or ROOT).resolve(), Path(pack).absolute()
    def product_input(relative):
        ref = Path(relative)
        if ref.is_absolute() or ".." in ref.parts or any(":" in part for part in ref.parts):
            raise ValueError("Local execution receipts require product-contained relative YAML references.")
        file = product / ref
        if file.is_symlink() or any(parent.is_symlink() for parent in file.parents):
            raise ValueError("Local execution receipts do not follow linked configuration inputs.")
        if not file.resolve().is_relative_to(product.resolve()):
            raise ValueError("An execution input is outside the selected product.")
        return file
    engine = base / "platform/engine"
    if not (engine / "config.py").is_file():
        raise ValueError("The local engine source is unavailable for an execution manifest.")
    paths = {"code/" + file.relative_to(base).as_posix(): file
             for file in engine.rglob("*") if file.suffix in {".py", ".json"} and file.is_file()}
    for name in ("local_smoke", "console", "pack_run", "spec_extract", "product_gates", "java_home"):
        paths[f"code/platform/tools/{name}.py"] = base / f"platform/tools/{name}.py"
    paths["code/platform/tests/fixtures/synthetic_sources.py"] = base / "platform/tests/fixtures/synthetic_sources.py"
    paths["code/platform/VERSION"] = base / "platform/VERSION"
    config_path = product_input("config/data_product.yaml")
    product_input("config/pipeline.yaml")
    raw = merged_raw(config_path)
    references = ["config/data_product.yaml", "config/pipeline.yaml"]
    references += [value for value in raw.get("variables", []) if isinstance(value, str)]
    codelists = raw.get("codelists") or {}
    references += [value for value in (codelists.values() if isinstance(codelists, dict) else codelists)
                   if isinstance(value, str)]
    # The engine loader, not the legacy approval graph's path normalization,
    # defines these names. Optional absence is hashed too, so adding pipeline.yaml
    # cannot silently retain a receipt made before it existed.
    for relative in references:
        paths["config/" + relative.replace("\\", "/")] = product_input(relative)
    if len(paths) > 2048:
        raise ValueError("Execution inputs exceed the local manifest file limit.")
    files = {}
    for name, file in sorted(paths.items()):
        if file.is_symlink() or any(parent.is_symlink() for parent in file.parents):
            raise ValueError("Execution manifests require ordinary source files, not linked paths.")
        if file.exists() and (not file.is_file() or file.stat().st_size > 16 * 1024 * 1024):
            raise ValueError("An execution input is not a bounded ordinary file.")
        files[name] = hashlib.sha256(file.read_bytes()).hexdigest() if file.is_file() else None
    packages = {}
    for name in ("pyspark", "py4j", "delta-spark", "PyYAML", "sqlglot", "jsonschema", "numpy", "pandas", "pyarrow"):
        try:
            packages[name] = importlib.metadata.version(name)
        except importlib.metadata.PackageNotFoundError:
            packages[name] = None
    body = {"version": 1, "files": files, "runtime": {"python": platform.python_version(),
            "implementation": platform.python_implementation(), "packages": packages}}
    return {**body, "sha256": _digest(body)}


def read_evidence(path):
    """Bounded explicit local artifact read; no automatic discovery or persistence."""
    file = Path(path)
    if not file.is_file() or file.stat().st_size > 2 * 1024 * 1024:
        raise ValueError("Choose a synthetic execution receipt smaller than 2 MiB.")
    with file.open("rb") as handle:
        data = handle.read(2 * 1024 * 1024 + 1)
    if len(data) > 2 * 1024 * 1024:
        raise ValueError("The synthetic execution receipt exceeds 2 MiB.")
    try:
        text = data.decode("utf-8-sig")
        depth, quoted, escaped = 0, False, False
        for char in text:
            if quoted:
                if escaped:
                    escaped = False
                elif char == "\\":
                    escaped = True
                elif char == '"':
                    quoted = False
            elif char == '"':
                quoted = True
            elif char in "[{":
                depth += 1
                if depth > 64:
                    raise ValueError("The execution receipt exceeds bounded JSON depth.")
            elif char in "]}":
                depth -= 1
        value = json.loads(text)
    except (UnicodeDecodeError, json.JSONDecodeError, RecursionError) as error:
        raise ValueError("The execution receipt is not readable, bounded JSON.") from error
    stack, count = [(value, 0)], 0
    while stack:
        item, depth = stack.pop()
        count += 1
        if depth > 64 or count > 100_000:
            raise ValueError("The execution receipt exceeds bounded JSON depth or item limits.")
        if isinstance(item, (dict, list)):
            stack.extend((child, depth + 1) for child in (item.values() if isinstance(item, dict) else item))
    return value


def evidence_state(document, pack, *, root=None):
    """Separate a recorded execution from a match to current local inputs."""
    from rwd_tools import product_gates as pg
    from engine.build_ads import LOCAL_COHORT_MODE
    base = str(root or ROOT)
    product = os.path.abspath(os.path.join(base, pack))
    relative = repo_relative(product, base)
    result = {"state": "invalid", "current": False, "recorded": False, "reasons": [],
              "scope": "Synthetic execution only; no per-record validation or approval is changed."}
    if not isinstance(document, dict) or not isinstance(document.get("gate5"), dict):
        result["reasons"] = ["No readable synthetic build summary is attached."]
        return result
    summary = document["gate5"]
    if (document.get("pack") != relative or document.get("source_mode") != "synthetic"
            or document.get("status", "built") != "built"
            or type(summary.get("rows")) is not int or summary["rows"] < 1
            or type(summary.get("columns")) is not int or summary["columns"] < 1):
        result["reasons"] = ["The receipt must identify this product, synthetic inputs and a successful non-empty build."]
        return result
    result.update(state="historical", recorded=True, rows=summary["rows"], columns=summary["columns"])
    try:
        current = input_manifest(product, root=base)
    except (OSError, ValueError, TypeError):
        result["reasons"].append("Current execution inputs could not be verified within the product boundary; retain this as historical evidence.")
        return result
    for key, expected in (("science_digest", pg.config_bundle_sha256(product)),
                          ("committed_delivery_digest", pg.delivery_sha256(product)),
                          ("effective_run_bindings", {k.split(".", 1)[1]: v for k, v in SYNTHETIC_RUN.items()})):
        if document.get(key) != expected:
            result["reasons"].append(f"{key} differs from the current requested configuration.")
    manifest = document.get("input_manifest")
    if manifest is None:
        result["reasons"].append("Legacy receipt: exact engine and synthetic input bytes were not recorded; current engine match is unverified.")
        return result
    body = {key: value for key, value in manifest.items() if key != "sha256"} if isinstance(manifest, dict) else {}
    if (not isinstance(manifest, dict) or set(manifest) != {"version", "files", "runtime", "sha256"}
            or type(manifest.get("version")) is not int or manifest.get("version") != 1 or not isinstance(manifest.get("files"), dict)
            or not isinstance(manifest.get("runtime"), dict) or manifest.get("sha256") != _digest(body)):
        result.update(state="invalid", recorded=False)
        result["reasons"].append("The execution input manifest is malformed or its digest does not match.")
        return result
    if document.get("execution_mode") != LOCAL_COHORT_MODE:
        result["reasons"].append("The recorded execution mode does not match this local cohort build.")
    if manifest["files"] != current["files"]:
        result["reasons"].append("Engine, synthetic-source or configuration input bytes changed since the recorded build.")
    if manifest["runtime"] != current["runtime"]:
        result["reasons"].append("The Python or installed dependency versions differ from the recorded build.")
    if not result["reasons"]:
        result.update(state="current", current=True)
        result["reasons"] = ["Recorded non-empty synthetic execution matches current source/config bytes and Python package identities. Java/managed-runtime equivalence is not asserted."]
    return result


def build(pack, telemetry=None):
    """(cfg, ads) on synthetic sources with explicit local cohort checkpoints.

    On success the caller owns ads.sparkSession and must stop it in finally after
    consumption. A build failure stops the session here, releasing local storage.
    """
    from rwd_synthetic import synthetic_sources
    from engine import build_ads, validate
    from engine.config import load_config
    cfg = load_config(os.path.join(pack, "config", "data_product.yaml"), overrides=SYNTHETIC_RUN)
    # THE SAME ADMISSION PRODUCTION RUNS, before any Spark starts: a smoke that succeeded
    # on a configuration the Databricks runner refuses proved the wrong thing (an external
    # review demonstrated it with four undeclared source roles that built here and would
    # have been refused there). One validator, both doors.
    validate.check(cfg, strict=True)
    spark = synthetic_sources.session("local-smoke")
    try:
        return cfg, build_ads.build_from_sources(synthetic_sources.sources(spark, cfg), cfg,
            telemetry=telemetry, local_cohort_checkpoints=True)
    except BaseException:
        spark.stop()
        raise


def summarise(cfg, ads):
    """The build, as plain data. ONE Spark action — `count()`, `distinct().collect()` and
    `limit().collect()` each re-ran the whole cohort-union plan, three times over."""
    cols = list(ads.columns)
    rows = ads.collect()
    show = [c for c in ("patientid", "index_date", "cohort", "cohortn", "cohortu", "stage",
                        "stagen", "data_product_id", "spec_version", "data_refresh") if c in cols]
    from pyspark.sql import SparkSession
    from engine.build_ads import LOCAL_COHORT_MODE
    runtime = {}
    try:
        jvm = ads.sparkSession.sparkContext._jvm
        runtime = {"java_version": jvm.java.lang.System.getProperty("java.version"),
                   "java_vendor": jvm.java.lang.System.getProperty("java.vendor")}
    except AttributeError:
        pass  # A summary reader or injected test frame may expose no live JVM.
    # These are the same synthetic rows already materialized above, not another
    # Spark action. Preserve JSON nulls and bound the client preview.
    from collections import Counter
    from datetime import date, datetime
    from decimal import Decimal
    import math
    def literal(value):
        if isinstance(value, (date, datetime)):
            return value.isoformat()
        if isinstance(value, Decimal):
            return str(value)  # retain publication precision
        if isinstance(value, float) and not math.isfinite(value):
            return None
        return value if value is None or isinstance(value, (str, int, float, bool)) else str(value)
    preview = [{c: literal(r[c]) for c in cols} for r in rows[:50]]
    cohort_counts = dict(sorted(Counter(str(r['cohort']) for r in rows if r['cohort']).items()))
    completeness = [{'column': c, 'present': sum(r[c] is not None for r in rows), 'total': len(rows)} for c in cols]
    return {"rows": len(rows), "columns": len(cols), "column_list": cols,
            "preview": preview, "preview_limit": 50, "cohort_counts": cohort_counts,
            "completeness": completeness,
            "execution_mode": LOCAL_COHORT_MODE,
            "cohorts_configured": [c["id"] for c in cfg.cohorts],
            "cohorts": sorted({r["cohort"] for r in rows if r["cohort"]}),
            "sample_cols": show, "sample": [[str(r[c]) for c in show] for r in rows[:8]],
            "spark": SparkSession.getActiveSession().version, "runtime_observed": runtime}


def binding(pack):
    """What this build WAS — so a page cannot describe someone else's build as this pack's.

    A summary alone says "4 rows, 187 columns" and nothing about whose. Attached to the wrong pack,
    an older commit, a changed configuration or — worst — a REAL-data run, the page would still
    caption it "the same configuration above, on SYNTHETIC sources". `render_html` refuses on any
    mismatch, so the caption is a checked claim rather than a sentence.

    `source_mode` is stated by the PRODUCER, and only this tool produces it: nothing else can write
    `synthetic` truthfully, and a page that accepted an unstated mode would accept a live build.
    """
    manifest = input_manifest(pack)  # Validate input paths before legacy digest readers.
    from rwd_tools import product_gates as pg
    from engine.build_ads import LOCAL_COHORT_MODE
    rel = repo_relative(pack, ROOT)
    git = console.run(["git", "-C", ROOT, "rev-parse", "HEAD"])
    dirty = console.run(["git", "-C", ROOT, "status", "--porcelain"])
    return {"pack": rel,
            "source_mode": "synthetic",
            "execution_mode": LOCAL_COHORT_MODE,
            "git_commit": (git.stdout.strip() if git.returncode == 0 else "unstated"),
            # A dirty tree means the digests below describe files nobody can retrieve by commit.
            "git_clean": bool(git.returncode == 0 and not dirty.stdout.strip()),
            "platform_version": open(os.path.join(ROOT, "platform", "VERSION"),
                                     encoding="utf-8").read().strip(),
            "science_digest": pg.config_bundle_sha256(pack),
            # THE COMMITTED DELIVERY, AND WHAT THE RUN ACTUALLY USED — two different things, and
            # calling one by the other's name is the whole problem this field had.
            #
            # `delivery_sha256(pack)` reads the pack as committed, where prostate still says
            # `refresh: REPLACE_ME`. The synthetic run does not use that: it overrides refresh,
            # source_schema and output_schema to `synthetic`. Recording only the committed digest
            # and letting the page caption the build "the same configuration above" made a true
            # statement about the SCIENCE stand in for a false one about the DELIVERY.
            #
            # Both are recorded. The renderer checks the committed one (that is what "this page is
            # drawn from the same checkout" means) and captions the effective one honestly.
            "committed_delivery_digest": pg.delivery_sha256(pack),
            "effective_run_bindings": {k.split(".", 1)[1]: v for k, v in SYNTHETIC_RUN.items()},
            "input_manifest": manifest}


def main(argv):
    ap = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    ap.add_argument("pack", help="the pack directory")
    ap.add_argument("--evidence-out", help="write the build summary here, for "
                                           "`render_html.py flow --evidence`. Refused inside the "
                                           "checkout, like every other generated report.")
    ap.add_argument("--stage-telemetry", action="store_true",
                    help="print per-stage join telemetry (engine.telemetry): index vs stage-output "
                         "patient counts and per-patient fan-out, per cohort. Evidence a person "
                         "reads, never a verdict; costs one extra Spark action. Synthetic rows, so "
                         "the NUMBERS mean nothing here — what this shows locally is the SHAPE of "
                         "what the same flag records in a governed run's manifest.")
    a = ap.parse_args(argv)
    pack = os.path.abspath(a.pack)
    if not os.path.exists(os.path.join(pack, "config", "data_product.yaml")):
        sys.exit(f"{a.pack}: no config/data_product.yaml — not a product pack")
    try:
        import pyspark                                              # noqa: F401
    except ImportError:
        sys.exit("pyspark not installed — run:  pip install pyspark pyyaml   "
                 "(needs Java 17 or 21 on PATH)")
    try:
        from rwd_tools import java_home                                            # noqa: PLC0415
        if not java_home.ensure() and not java_home.shutil.which("java"):
            sys.exit(java_home.words())
    except ImportError:
        pass

    collector = None
    if a.stage_telemetry:
        from engine.telemetry import StageTelemetry
        collector = StageTelemetry()
    before = binding(pack)
    cfg, ads = build(pack, telemetry=collector)
    try:
        s = summarise(cfg, ads)
        after = binding(pack)
        bound = ("pack", "source_mode", "execution_mode", "science_digest", "committed_delivery_digest",
                 "effective_run_bindings", "input_manifest")
        if any(before.get(key) != after.get(key) for key in bound):
            raise ValueError("Execution inputs changed during the synthetic build. No current-success receipt is recorded; rerun the unchanged configuration.")
        empty = s["rows"] == 0
        print("=" * 72)
        print(f"product : {cfg.raw.get('name')}   spec {cfg.spec_version}")
        print(f"vendor  : {cfg.raw.get('vendor')} / {cfg.raw.get('tumor_class')}")
        print(f"cohorts : {len(s['cohorts_configured'])} configured -> {s['cohorts_configured']}")
        print(f"sources : {sorted(cfg.sources)}")
        print("=" * 72)
        print("\n### NO MATCHING PATIENTS — synthetic build needs review ###" if empty else
              "\n### ADS BUILT — synthetic sources, local Spark, NO cluster ###")
        print(f"rows     : {s['rows']}")
        print(f"columns  : {s['columns']}")
        # CONFIGURED and POPULATED are different numbers and the difference is the point: a cohort with
        # no synthetic patient produces no row, and reporting only the first would overstate the build.
        print(f"cohorts  : {len(s['cohorts'])} populated of {len(s['cohorts_configured'])} configured "
              f"-> {s['cohorts']}")
        if s["sample"]:
            print("\n" + " | ".join(s["sample_cols"]))
            for row in s["sample"][:6]:
                print(" | ".join(row))
        print(f"\nfirst 30 columns:\n  {', '.join(s['column_list'][:30])}")
        if empty:
            print("No patients matched this synthetic example. Review cohort index dates, inclusion/exclusion "
                  "rules and source coverage, then retry. This is not a successful ADS build.", file=sys.stderr)
        else:
            print("\nSynthetic sources. This proves the configuration assembles and executes; it says "
                  "nothing about delivered data and is not evidence at any gate.")

        if collector is not None:
            rep = collector.report()
            print("\n### STAGE TELEMETRY — synthetic counts; the shape, not the facts ###")
            hdr = ("cohort", "stage", "idx_pts", "matched", "unmatched", "outside", "rows_out",
                   "max/pt")
            keys = ("cohort", "stage", "index_patients", "matched_patients",
                    "unmatched_index_patients", "patients_outside_index", "rows_out",
                    "max_rows_per_index_patient")
            widths = [max(len(h), *(len(str(r[k])) for r in rep["stages"])) if rep["stages"]
                      else len(h) for h, k in zip(hdr, keys)]
            print("  " + "  ".join(h.ljust(w) for h, w in zip(hdr, widths)))
            for r in rep["stages"]:
                print("  " + "  ".join(str(r[k]).ljust(w) for k, w in zip(keys, widths)))
            if rep["selections"]:
                print("\n  selections (closest-panel families; other pick families not yet measured):")
                shdr = ("cohort", "block", "item", "cand", "pts", "ties", "tie_rows", "non_null",
                        "rows")
                skeys = ("cohort", "block", "item", "candidate_rows", "patients_with_candidates",
                         "tied_same_date_keys", "tied_rows", "non_null_outputs", "output_rows")
                sw = [max(len(h), *(len(str(r.get(k, ""))) for r in rep["selections"]))
                      for h, k in zip(shdr, skeys)]
                print("  " + "  ".join(h.ljust(w) for h, w in zip(shdr, sw)))
                for r in rep["selections"]:
                    print("  " + "  ".join(str(r.get(k, "")).ljust(w) for k, w in zip(skeys, sw)))
            for line in rep["skipped"]:
                print(f"  SKIPPED: {line}")
            for line in rep["observations"]:
                print(f"  OBSERVATION: {line}")

        if a.evidence_out:
            out = os.path.join(
                pack_run.restricted_dir(os.path.dirname(os.path.abspath(a.evidence_out)),
                                        what="report"),
                os.path.basename(a.evidence_out))
            os.makedirs(os.path.dirname(out), exist_ok=True)
            with open(out, "w", encoding="utf-8", newline="\n") as fh:
                json.dump({**before, "status": "empty" if empty else "built", "gate5": s}, fh, indent=1)
            print(f"\nevidence -> {out}")
        return 1 if empty else 0
    finally:
        ads.sparkSession.stop()


if __name__ == "__main__":
    from rwd_tools.console import use_utf8
    use_utf8()
    sys.exit(main(sys.argv[1:]))
