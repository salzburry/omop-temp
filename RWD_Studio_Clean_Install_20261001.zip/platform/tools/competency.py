#!/usr/bin/env python3
"""Can this platform ANSWER the questions a governed data product must answer?

    python3 platform/tools/competency.py <pack> --variable <ID>
    python3 platform/tools/competency.py <pack>                 # coverage over every record
    python3 platform/tools/competency.py <pack> --json

WHY THIS EXISTS, AND WHY IT IS NOT A NEW SOURCE OF TRUTH. Ontology practice calls these
COMPETENCY QUESTIONS: before building a semantic asset you write down the questions it must be
able to answer, and afterwards you check that it can. The idea is sound and the usual execution
is not — a slide saying "the graph answers thirty questions" is a claim, not evidence.

So these questions are EXECUTABLE. Each one is answered by reading the pack's own committed
artifacts through the tools that own them: the contract record, the decisions register, the
config graph, the source adapter, the golden fixture, the refresh ledger, the equivalence
rulings. This module computes nothing of its own and stores nothing — remove it and the answers
are still all there, in the same files. What it adds is that "we can explain any variable end to
end" stops being something we say and becomes something CI runs.

THE QUESTIONS ARE ABOUT LINEAGE, NEVER ABOUT CLINICAL TRUTH. "Which spec row defines this?" is a
question about the document. "Is 90 days the right window?" is a question for Science, and nothing
here will ever answer it. That boundary is why this can be a test at all: every expected answer
is a fact about the repository, so no verdict has to be invented to check it.

FAIL-CLOSED GRAMMAR, as everywhere else. Each question comes back `answered` with its evidence,
or `absent` with the REASON it could not be answered — a golden fixture that does not exist, a
build that has not run, an equivalence nobody has ruled on. An unanswerable question is a true
and useful state; an unanswerable question reported as silence is the failure. Nothing here
reads a missing answer as a passing one, and no answer carries an approval word.

stdlib + the repo's own readers. No Spark.
"""
from __future__ import annotations

import argparse
import json
import os
import sys

from rwd_services import package_asset, workspace_root
ROOT = str(workspace_root(__file__))

from rwd_tools import product_gates as pg                                              # noqa: E402
from rwd_tools import receipt as rc                                                    # noqa: E402
from rwd_tools import rule_review                                                      # noqa: E402
from rwd_tools import semantic_view as sv                                              # noqa: E402
from rwd_tools import source_adapter as sa                                             # noqa: E402
from rwd_tools.spec_extract import repo_relative                                  # noqa: E402

# Words an answer may never carry. A competency answer REPORTS what the artifacts say; a reader
# who sees "verified" here would read a lineage fact as an approval nobody gave.
FORBIDDEN = ("approved by this tool", "verified", "validated", "passed", "signed off")


def _requirement(entry):
    """The record's own requirement status, reported beside a lineage answer so nothing here
    reads as an approval. Read through contract_lint, which owns the vocabulary."""
    from rwd_tools import contract_lint as _cl                                         # noqa: PLC0415
    return _cl.requirement(entry.get("status")) or "(unstated)"


def _answer(text, **evidence):
    return {"state": "answered", "answer": text, "evidence": evidence}


def _absent(reason, **evidence):
    return {"state": "absent", "answer": None, "reason": reason, "evidence": evidence}


# --- the questions ------------------------------------------------------------------------
#
# Each takes (pack, entry, ctx) and returns _answer or _absent. `entry` is the contract record
# from rule_review.chain; `ctx` carries the pack-wide reads so ten questions cost one pass.


def q_spec_item(pack, entry, ctx):
    """NAMED FOR WHAT IT PROVES. This question read "which APPROVED specification row defines
    this" and proved no such thing: it shows the row the record CITES and whether a digest binds
    the record to that row's text. Whether the specification itself is approved is Gate 1's
    attestation, and whether this record is approved is its own `requirement` status — both real,
    both elsewhere. A lineage answer that implies an approval nobody gave is the failure this
    whole surface exists to avoid, so the question now says citation and the answer carries the
    record's status beside it."""
    refs = [r for r in (entry["spec"]["refs"] or []) if r]
    if not refs:
        return _absent("the contract record cites no spec row — nothing ties this variable to "
                       "the specification")
    return _answer(", ".join(refs), digest=entry["spec"]["digest"] or None,
                   rule_present=bool(entry["spec"]["rule"]),
                   record_status=_requirement(entry))


def q_derivation(pack, entry, ctx):
    d = (entry["derivation"] or "").strip()
    if not d:
        return _absent("the record states no derivation — the rule was captured but not "
                       "interpreted into what the build must do")
    return _answer(d[:400], status=entry["status"] or None)


def q_config_blocks(pack, entry, ctx):
    refs = [r for r, _f in entry["executable"]]
    if not refs:
        return _absent("no implementation_refs — nothing in the config graph claims to run this")
    if entry["unresolved"]:
        return _answer(", ".join(refs), unresolved=list(entry["unresolved"]),
                       note="reference(s) that resolve to no config block are listed; each is a "
                            "record pointing at something that does not exist")
    return _answer(", ".join(refs))


def q_source_roles(pack, entry, ctx):
    roles = sorted(ctx["roles"])
    if not roles:
        return _absent("the pack's config declares no sources — nothing says which delivered "
                       "tables this product reads")
    return _answer(", ".join(roles), count=len(roles))


def q_adapter(pack, entry, ctx):
    ad = ctx["adapter"]
    if ad.get("state") == "no_claim":
        return _absent("no config/source_adapters.yaml — the pack makes no typed binding claim, "
                       "so the loader resolves tables from cfg.sources as it always has")
    if ad.get("problems"):
        return _answer(f"adapter set for dataset {ad.get('dataset')!r} with "
                       f"{len(ad['problems'])} problem(s)", problems=ad["problems"][:5],
                       reviewed=bool(ad.get("all_reviewed")))
    return _answer(f"{len(ad.get('adapters') or [])} adapter(s) for dataset "
                   f"{ad.get('dataset')!r}", schema=ad.get("schema"), cut=ad.get("cut"),
                   reviewed=bool(ad.get("all_reviewed")))


def q_decisions(pack, entry, ctx):
    cited = entry["decisions"] or []
    if not cited:
        return _absent("the record cites no decision — either nothing was in question, or a "
                       "question was settled without a register entry")
    rows = rc._decisions(pack, cited)
    open_ids = [r["decision"] for r in rows if r.get("status") != "RESOLVED"]
    missing = [r["decision"] for r in rows if not r.get("in_register")]
    return _answer(", ".join(cited), open=open_ids, not_in_register=missing)


def q_goldens(pack, entry, ctx):
    path, doc = ctx["goldens"]
    if doc is None:
        return _absent(f"no golden fixture at {path} — no boundary case is written down for "
                       f"this tumour, so nothing pins the rule's edges")
    vid = entry["variable_id"].lower()
    hits = [g for g in (doc.get("goldens") or [])
            if vid in json.dumps(g).lower()]
    if not hits:
        return _absent(f"{len(doc.get('goldens') or [])} golden case(s) exist for this tumour and "
                       f"none names this variable")
    unfilled = [g.get("id") for g in hits if str(g.get("expect")) in ("REPLACE_ME", "None", "")]
    return _answer(", ".join(str(g.get("id")) for g in hits),
                   cases=len(hits), awaiting_a_persons_value=unfilled)


def q_build(pack, entry, ctx):
    b = ctx["build"]
    if not b.get("recorded"):
        return _absent(b.get("note") or "no manifest in the refresh ledger")
    return _answer(f"{b.get('refresh')} ({b.get('status')})",
                   engine_version=b.get("engine_version"), git_commit=b.get("git_commit"),
                   output_table=b.get("output_table"))


def q_implementations(pack, entry, ctx):
    """A REGISTRY VENDOR IS A DECLARATION, NOT AN IMPLEMENTATION. This question read "which
    datasets implement this product" and counted the registry's `vendor:` field, which says which
    delivery a pack is INTENDED for — no adapter, no build, no row of data required. Only a
    CHECKED adapter set with a dataset label evidences an implementation, so the two are now
    reported apart and the difference is stated."""
    impls = sorted(ctx["implementations"])
    ad = ctx["adapter"]
    bound = ([ad.get("dataset")] if ad.get("state") == "checked" and ad.get("dataset")
             and not ad.get("problems") else [])
    declared = [i for i in impls if i not in bound]
    if not impls:
        return _absent("nothing names a dataset for this pack — the registry declares no vendor "
                       "and no checked adapter carries a dataset label")
    if not bound:
        # THE VENDOR IS NAMED, because this answer is ABOUT the vendor. `implementations()` keys by
        # SLUG now — one identity namespace, so an EHR/claims pair reads the same from either side
        # — which left `declared` holding `prostate` and this sentence saying "a registry vendor
        # states which delivery this pack is INTENDED for" without ever saying WHICH. A reader was
        # told a vendor decides it and not told the vendor.
        vendor = str(ctx.get("vendor") or "").strip()
        who = f" (registry vendor: {vendor})" if vendor else ""
        return _absent(f"declared for {', '.join(declared)}{who}, and nothing implements it yet — "
                       f"a registry vendor states which delivery this pack is INTENDED for; only "
                       f"a checked adapter set evidences one that was bound")
    return _answer(", ".join(bound), bound_by_adapter=bound, declared_only=declared)


def q_equivalence(pack, entry, ctx):
    impls = sorted(ctx["implementations"])
    if len(impls) < 2:
        return _absent(f"pooling needs two implementations and this pack has {len(impls)} — the "
                       f"question cannot arise until a second dataset delivers")
    a, b = impls[0], impls[1]
    p = sv.pooling(entry["variable_id"], a, b, ctx["rulings"])
    if p.get("ruling") in (None, "", "not_established"):
        return _absent(f"no recorded ruling for ({entry['variable_id']}, {a}, {b}) — NOT "
                       f"ESTABLISHED; the question routes to DataExpert/Science and no tool may answer it")
    return _answer(f"{p.get('ruling')} for {a} vs {b}", decision_id=p.get("decision_id"),
                   ruled_by=p.get("ruled_by"), ruling_date=p.get("ruling_date"))


QUESTIONS = (
    ("CQ01", "Which specification row does this record cite, and does a digest bind it?",
     q_spec_item),
    ("CQ02", "What does the contract say the build must do?", q_derivation),
    ("CQ03", "Which config block executes it?", q_config_blocks),
    ("CQ04", "Which delivered source roles does this product read?", q_source_roles),
    ("CQ05", "Which reviewed adapter binds those roles to physical tables?", q_adapter),
    ("CQ06", "Which decisions does this record depend on, and are they settled?", q_decisions),
    ("CQ07", "Which golden cases pin this variable's boundaries?", q_goldens),
    ("CQ08", "Which governed build produced it, with which engine?", q_build),
    ("CQ09", "Which dataset is bound by a checked adapter, as opposed to merely declared?",
     q_implementations),
    ("CQ10", "Is another dataset's implementation poolable with this one?", q_equivalence),
)


def _context(pack):
    """Everything the ten questions read, loaded ONCE. A per-question load would make the answers
    a function of when each ran."""
    from engine.config import load_config                                      # noqa: PLC0415
    roles = set()
    cfg_path = os.path.join(pack, "config", "data_product.yaml")
    if os.path.exists(cfg_path):
        try:
            roles = set(load_config(cfg_path).sources)
        except Exception:                     # noqa: BLE001 — a broken config owns its own lint
            roles = set()
    root = str(workspace_root(pack))
    rel = repo_relative(pack, root)
    tumor = rel.split("/")[2] if len(rel.split("/")) > 2 else ""
    golden_ref = f"platform/tests/fixtures/{tumor}_goldens.yaml"
    gpath = os.path.join(root, golden_ref)
    if not os.path.exists(gpath):
        try:
            gpath = str(package_asset(golden_ref))
        except FileNotFoundError:
            pass
    gdoc = None
    if os.path.exists(gpath):
        gdoc, _err = pg.read_yaml(gpath)
    rulings, _problems = sv.rulings()
    return {"roles": roles,
            "adapter": sa.check(pack),
            "goldens": (golden_ref, gdoc),
            "build": rc._build(pack),
            "implementations": sv.implementations(pack),
            # THE REGISTRY VENDOR, loaded here with everything else. CQ09's whole answer is that a
            # vendor DECLARES an intended delivery and only a checked adapter evidences one, and it
            # could not name the vendor: `implementations()` keys by SLUG now (one identity
            # namespace, so an EHR/claims pair reads the same from either side), and the `entry`
            # each question receives is the contract RECORD, not the registry row.
            "vendor": str((pg.registry_entry(root, rel) or {}).get("vendor") or ""),
            "rulings": rulings}


def ask(pack, variable, ctx=None):
    """The ten answers for one variable, in question order."""
    entries = rule_review.chain(pack, variable)
    if not entries:
        known = [e["variable_id"] for e in rule_review.chain(pack)]
        raise KeyError(f"`{variable}` is not a variable_id in this pack's contract "
                       f"({len(known)} record(s))")
    ctx = ctx or _context(pack)
    out = []
    for qid, text, fn in QUESTIONS:
        try:
            res = fn(pack, entries[0], ctx)
        except Exception as e:                # noqa: BLE001
            # A question that RAISES is unanswered, and says which and why. Letting it escape
            # would take the other nine answers down with it.
            res = _absent(f"the reader for this question failed: {type(e).__name__}: {e}")
        out.append({"id": qid, "question": text, **res})
    return {"pack": repo_relative(pack), "variable_id": entries[0]["variable_id"],
            "answers": out,
            "answered": sum(1 for a in out if a["state"] == "answered"),
            "of": len(out)}


def coverage(pack):
    """Per question, how many of the pack's records it can be answered for. The shape of what
    this product can and cannot explain about itself."""
    ctx = _context(pack)
    entries = rule_review.chain(pack)
    per = {qid: 0 for qid, _t, _f in QUESTIONS}
    reasons = {}
    for e in entries:
        for a in ask(pack, e["variable_id"], ctx)["answers"]:
            if a["state"] == "answered":
                per[a["id"]] += 1
            else:
                reasons.setdefault(a["id"], a.get("reason"))
    # A PACK WITH NO RECORDS ANSWERS 0 OF 0, and 0/0 renders like full coverage of nothing —
    # the vacuous pass this repository refuses everywhere else. `vacuous` says the questions
    # were not asked rather than asked and answered.
    return {"pack": repo_relative(pack), "records": len(entries), "answered": per,
            "vacuous": not entries,
            "note": ("this pack has NO contract records, so every count below is 0 of 0 — the "
                     "questions were never asked, which is not the same as answered"
                     if not entries else ""),
            "first_absence_reason": reasons,
            "questions": {qid: text for qid, text, _f in QUESTIONS}}


def render(r):
    L = [f"COMPETENCY — {r['pack']} · {r['variable_id']}",
         f"{r['answered']} of {r['of']} question(s) answerable from committed artifacts", ""]
    for a in r["answers"]:
        L.append(f"{a['id']}  {a['question']}")
        if a["state"] == "answered":
            L.append(f"      {a['answer']}")
            for k, v in sorted((a.get("evidence") or {}).items()):
                if v not in (None, [], {}, False):
                    L.append(f"        {k}: {v}")
        else:
            L.append(f"      — NOT ANSWERABLE: {a['reason']}")
        L.append("")
    L.append("Lineage answers only. What a rule SHOULD say is Science's; nothing here rules on it.")
    return "\n".join(L)


def render_coverage(r):
    L = [f"COMPETENCY COVERAGE — {r['pack']} · {r['records']} contract record(s)", ""]
    if r.get("vacuous"):
        return "\n".join(L + [f"  {r['note']}"])
    for qid, text in sorted(r["questions"].items()):
        n = r["answered"][qid]
        L.append(f"{qid}  {n:>4} / {r['records']}  {text}")
        if n < r["records"] and r["first_absence_reason"].get(qid):
            L.append(f"          why not: {r['first_absence_reason'][qid]}")
    L += ["", "A question nothing can answer is open work, not a failure — and it is named here "
              "rather than left as silence."]
    return "\n".join(L)


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__.strip().splitlines()[0])
    ap.add_argument("product", help="path to a product pack")
    ap.add_argument("--variable", help="a variable_id; omitted, reports coverage over all records")
    ap.add_argument("--json", action="store_true", help="machine-readable, to STDOUT")
    a = ap.parse_args(argv)
    pack = repo_relative(os.path.abspath(a.product), ROOT)
    if not os.path.isdir(os.path.join(ROOT, pack)):
        sys.exit(f"{a.product}: not a product pack directory")
    try:
        r = ask(pack, a.variable) if a.variable else coverage(pack)
    except KeyError as e:
        sys.exit(str(e).strip('"'))
    print(json.dumps(r, indent=1, sort_keys=True) if a.json
          else (render(r) if a.variable else render_coverage(r)))
    return 0


if __name__ == "__main__":
    from rwd_tools.console import use_utf8
    use_utf8()
    sys.exit(main())
