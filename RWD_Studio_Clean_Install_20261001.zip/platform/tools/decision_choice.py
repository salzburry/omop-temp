"""Pure question choices and versioned, evidence-bound human selections."""
from __future__ import annotations

import hashlib
import re

import json
from copy import deepcopy

CUSTOM = "Write my own answer"
UNSURE = "Not sure yet"
COMPLETE = "Build a complete answer"
PARTS = "Work through the question in parts"

FOLLOW_UP_SCOPE_QUESTION = (
    "For this product, should follow-up end (FUED) and imputed death date (DTHDT) use "
    "one shared pair per patient or a separate pair for each patient and index date?"
)
FOLLOW_UP_DEFINITION_QUESTION = "How is end-of-follow-up defined (which activity sources, death cap, study-end cap)?"
DEATH_FLAG_QUESTION = 'Which preliminary dates + subtraction direction implement "≥120 days after death"? (the 120 threshold + 1/0 output are known)'

# Match the full question, not a decision ID or a disease/name keyword. These
# choices quote alternatives the issued question itself states.
_ALTERNATIVES = {
    FOLLOW_UP_SCOPE_QUESTION: ["one shared pair per patient", "a separate pair for each patient and index date"],
    'For a nonexistent line, is the LOT category null or 17 "No treatment"?':
        ['null', '17 "No treatment"'],
    'Progression eligibility boundary `> index+14` vs `>= index+14`':
        ['> index+14', '>= index+14'],
    'Is struck `TTNTFL` published, internal-only, or removed? (cross-setting TTNT itself is a confirmed engine requirement — in ENGINE_GAPS)':
        ['published', 'internal-only', 'removed'],
    'Are ID_PD_mCRPC / ID_PD_mHSPC published ADS vars, internal gates, or replaced by cohort-row inclusion?':
        ['published ADS vars', 'internal gates', 'replaced by cohort-row inclusion'],
    'Is LOTN mCRPC-only, or cohort-setting-specific? (LOTN=0-for-untreated is a *requirement*, in ENGINE_GAPS)':
        ['mCRPC-only', 'cohort-setting-specific'],
    'Keep or drop TRTDIS / TTD / TSST (struck in the spec but still emitted)? If kept, TTD needs the `+1`':
        ['Keep', 'drop'],
}
_COMPOUND = {
    'Window (`[-30,+7]` vs any-time-before-index) and date basis (specimen-collected vs -received)': [
        'Window: TODO — compare [-30,+7] with any-time-before-index.',
        'Date basis: TODO — choose specimen-collected or specimen-received and explain the source implication.',
    ],
    'How is end-of-follow-up defined (which activity sources, death cap, study-end cap)?': [
        'Activity sources: TODO.', 'Death cap: TODO.', 'Study-end cap: TODO.',
    ],
    'What is the valid study-end, and does the 60-day delivery lag apply?': [
        'Valid study-end date: TODO — confirm a real calendar date against the source.',
        'Whether and how the 60-day delivery lag applies: TODO.',
    ],
}
_MATRIX = ('The per-cohort **C1–C7** applicability matrix for every FU outcome: applicable-or-null, line anchor, event + censor defs, '
           'ID3MOSFU + DTH_BEFORE_FUED gating, and the C7 next-treatment **source** + event definition + censoring when no qualifying next treatment '
           'is observed (the boundary is the next-treatment *source*, not ADS publication — a LOT5 source record may be usable even if LOT5 isn\'t '
           'a published column). RWP drafts the matrix, RWB approves')
_COMPOUND[_MATRIX] = [
    'For each C1–C7 cohort and each FU outcome: TODO — applicable or null.',
    'For each applicable combination: TODO — line anchor, event definition, censor definition and gating.',
    'C7 next-treatment source: TODO — identify the source separately from ADS publication.',
    'No qualifying next treatment observed: TODO — state the censoring rule.',
    'Detailed matrix location and review rationale: TODO — reference the reviewed artifact in the final ruling.',
]


def _normal(text):
    return re.sub(r"\s+", " ", str(text or "")).strip()


def follow_up_topic(question):
    """A guide for an exact question, never an inferred ruling from its identifier."""
    topics = {
        FOLLOW_UP_SCOPE_QUESTION: ("scope", "Patient or index-date scope",
            "Choose whether the dates are shared across a patient's cohorts. This does not settle the activity sources, death-flag formula or conflicting FUED definitions."),
        FOLLOW_UP_DEFINITION_QUESTION: ("definition", "Follow-up definition",
            "Confirm activity sources, death cap and study-end cap. If several specification rows define FUED differently, identify the rule for each row. This question does not itself decide whether dates are shared across index dates."),
        DEATH_FLAG_QUESTION: ("death_flag", "Death-flag calculation",
            "Confirm the preliminary date inputs and subtraction direction for the death flag. This is separate from whether FUED and DTHDT are shared across index dates."),
        _MATRIX: ("cohorts", "Outcome applicability by cohort",
            "Confirm applicable outcomes, anchors, event and censor rules by cohort. If a patient-level FUED precedes a cohort's index, explicitly decide how that row is handled."),
    }
    for wording, (kind, title, explanation) in topics.items():
        if _normal(question) == _normal(wording):
            return {"kind": kind, "title": title, "explanation": explanation}
    return None


def follow_up_scope_draft():
    """Unanswered question for the existing review flow; contains no owner or approval."""
    return {"question": FOLLOW_UP_SCOPE_QUESTION, "variable": "FUED / DTHDT",
        "source": "runtime_scientific_choice",
        "context": "The reference runtime check leaves date scope unresolved. Confirm that this question applies to this product before recording it.",
        "evidence": "clinical.follow_up_scope; compare this product's follow-up and mortality specification rows. Related questions cover activity sources/caps, death-flag subtraction and outcome cohort handling."}


# DERIVED FROM THE QUESTION ITSELF (2026-09-07, decision loop audit DL-11). The table above only
# knew the prostate fixture's wordings, so every other pack's question offered no choice at all.
# The patterns below quote alternatives the question states in its own words: 'A vs B', 'A or B',
# 'either A or B', 'keep or drop', and a yes/no question. The table stays as an override for the
# wordings whose alternatives a person has already checked. Nothing here selects an answer.
_STEM = re.compile(r"^(?:is|are|was|were|does|do|did|should|shall|can|could|will|would|has|have|may|must|keep)\b", re.I)
_YES_NO = re.compile(r"^(?:is|are|was|were|does|do|did|should|shall|can|could|will|would|has|have|may|must)\b", re.I)
_STOP = {"is", "are", "was", "were", "be", "the", "a", "an", "should", "does", "do", "as", "either", "and",
         "within", "in", "at", "for", "of", "to", "when", "if", "before", "after", "with", "on", "from", "by"}
_ARTICLES = ("the", "a", "an")


def _first_sentence(question):
    """The clause that asks; a trailing remark after the question mark is not part of the choice."""
    text = _normal(question)
    head = text.split("?", 1)[0]
    return head.strip(" .:;,")


def _side(words, limit):
    """Up to `limit` words of one alternative, read from the word nearest the 'or' or 'vs'."""
    words = list(words)
    while words and words[0].lower() in _ARTICLES:
        words = words[1:]
    kept = []
    for word in words:
        if word.lower() in _STOP or not word:
            break
        kept.append(word)
        if len(kept) >= limit:
            break
    return kept


def _unquote(phrase):
    phrase = phrase.strip(" `")
    if len(phrase) > 1 and phrase[0] == phrase[-1] and phrase[0] in "'\"":
        phrase = phrase[1:-1]
    words = phrase.split()
    while words and words[0].lower() in _ARTICLES:
        words = words[1:]
    return " ".join(words)


def _versus(sentence):
    quoted = re.search(r"`([^`]+)`\s+(?:vs\.?|versus)\s+`([^`]+)`", sentence, re.I)
    if quoted:
        return [quoted.group(1).strip(), quoted.group(2).strip()]
    match = re.search(r"\s+(?:vs\.?|versus)\s+", sentence, re.I)
    if not match:
        return []
    left = re.split(r"[,;:()]", sentence[:match.start()])[-1].split()
    right = re.split(r"[,;:()]", sentence[match.end():])[0].split()
    right_words = _side(right, 3)
    left_words = list(reversed(_side(list(reversed(left)), max(len(right_words), 1))))
    if left_words != left or right[len(right_words):] not in ([], ["within", "the", "window"]):
        return []
    if left_words and right_words:
        return [" ".join(left_words), " ".join(right_words)]
    return []


def _either_or(sentence):
    match = re.search(r"\beither\s+(.+?)\s+or\s+(.+)$", sentence, re.I)
    if not match:
        return []
    left, right = match.group(1).strip(" ,"), match.group(2).strip(" ,")
    return [left, right] if left and right else []


def _or_list(sentence):
    if not re.search(r"\bor\b", sentence, re.I):
        return []
    if re.search(r"\bkeep or drop\b", sentence, re.I):
        return ["Keep", "drop"]
    if re.search(r"[\[(][^\])]*,[^\])]*[\])]", sentence):
        return []
    parts = [part.strip() for part in re.split(r",\s*(?:or\s+)?|\s+or\s+", sentence) if part.strip()]
    if len(parts) < 2:
        return []
    # A stated predicate supplies the whole alternatives, including negation,
    # timing qualifiers and parenthesized boundaries. Word-count clipping turned
    # 'not excluded or imputed from the next visit' into 'excluded or imputed'.
    predicate = re.search(r"\bbe\s+(.+)$", parts[0], re.I)
    if predicate and _STEM.match(parts[0]):
        whole = [predicate.group(1), *parts[1:]]
        if all(len(phrase) <= 160 for phrase in whole):
            return whole
    # "censored at death, at the last recorded administration, or at the last visit" (walk UC3-P3-2):
    # a list whose items all open with the same short word names the alternatives after that word
    lead = re.match(r"(at|in|on|by|to|from|of|with|as|after|before|under)\s+", parts[1], re.I)
    if lead and all(re.match(lead.group(1) + r"\s+", part, re.I) for part in parts[1:]):
        word = lead.group(1).lower()
        anchor = parts[0].lower().rfind(" " + word + " ")
        if anchor >= 0:
            first = parts[0][anchor + len(word) + 2:].strip(" ?.;:")
            rest = [re.sub(r"^" + word + r"\s+", "", part, flags=re.I).strip(" ?.;:") for part in parts[1:]]
            if first and all(rest) and all(len(p.split()) <= 6 for p in [first, *rest]):
                return [first, *rest]
    starts = [index for index, part in enumerate(parts) if _STEM.match(part)]
    parts = parts[starts[-1]:] if starts else parts
    if len(parts) < 2:
        return []
    rest = [" ".join(_side(part.split(), 4)) for part in parts[1:]]
    if not all(rest):
        return []
    # Without an explicit predicate, do not silently discard a second option's
    # qualifiers. Ambiguous wording retains the complete-answer/manual routes.
    if any(_unquote(part) != phrase for part, phrase in zip(parts[1:], rest)):
        return []
    width = len(rest[0].split())
    first = list(reversed(_side(list(reversed(parts[0].split())), width)))
    if not first:
        return []
    prefix = parts[0][:-len(" ".join(first))].split()
    if prefix and prefix[-1].lower() in {"not", "never", "no", "without"}:
        return []
    return [" ".join(first), *rest]


def derived_alternatives(question):
    """Alternatives quoted from the question's own wording, or [] when it states none.

    Every phrase returned appears verbatim in the normalized question, so a choice can only ever
    repeat what the question already says. A wording the table knows wins over this derivation.
    """
    sentence = _first_sentence(question)
    if not sentence:
        return []
    normal = _normal(question)
    # One choice must not conceal a second scientific question. Checked compound
    # prompts use their explicit component guide above; other compound prompts
    # keep all their wording visible in the manual drafting route.
    if (re.search(r"\b(?:and|also|then)\s+(?:how|what|which|should|is|are|does|do)\b", normal, re.I)
            or re.search(r"\?\s*(?:how|what|which|should|is|are|does|do)\b", normal, re.I)
            or len(re.findall(r"\b(?:vs\.?|versus)\b", sentence, re.I)) > 1):
        return []
    # A parenthesized qualifier is part of an alternative, not disposable prose.
    # Only the explicit either/or or predicate form below can preserve it whole.
    if "(" in sentence and not re.search(r"\b(?:either|be)\b", sentence, re.I):
        return []
    for derive in (_versus, _either_or, _or_list):
        phrases = [_unquote(phrase) for phrase in derive(sentence)]
        phrases = [phrase for phrase in phrases if phrase and phrase in normal]
        if len(phrases) >= 2 and len(set(p.lower() for p in phrases)) == len(phrases):
            return phrases
    if _YES_NO.match(sentence) and not re.search(r"\b(?:or|vs\.?|versus|which|what|how)\b", sentence, re.I):
        return ["Yes", "No"]
    return []


def describe(question):
    question = _normal(question)
    alternatives = next((values for wording, values in _ALTERNATIVES.items() if _normal(wording) == question), [])
    components = next((values for wording, values in _COMPOUND.items() if _normal(wording) == question), [])
    if not alternatives and not components:
        alternatives = derived_alternatives(question)
    options = {}
    for phrase in alternatives:
        options["Consider: " + phrase] = phrase
    complete = "TODO: State the ruling for this question.\nScope or population: TODO.\nRationale and supporting evidence: TODO.\nRemaining questions: TODO."
    parts = "TODO: Work through every part before recording the decision.\n" + "\n".join(components or [
        "List each part of the issued question: TODO.",
        "For each part, state the answer, scope and supporting evidence: TODO.",
        "Confirm whether any part is still unresolved: TODO.",
    ])
    options.update({COMPLETE: complete, PARTS: parts})
    return {"options": options, "alternatives": alternatives, "components": components,
            "kind": "alternatives" if alternatives else "compound" if components else "open"}


def _sha(value):
    return hashlib.sha256(json.dumps(value, ensure_ascii=False, sort_keys=True,
        separators=(",", ":")).encode("utf-8")).hexdigest()


def option_catalog(question):
    """IDs bind the full question, ordinal and literal value, never a display label."""
    return [{"id": "option_" + _sha([question, i, value])[:24], "label": value, "value": value}
            for i, value in enumerate(describe(question)["alternatives"])]


def compose(question, value, explanation):
    return f"Question: {question}\nDecision: {value}\nScope, rationale and evidence: {explanation.strip()}"


def selection(form, option_id, explanation, answer):
    """Construct only a literal option from the current question's own alternatives."""
    if not isinstance(explanation, str) or not explanation.strip() or len(explanation) > 2500:
        raise ValueError("Explain the selected answer and its scope before saving.")
    question = str(form.get("question") or "")
    options = option_catalog(question)
    selected = next((item for item in options if item["id"] == option_id), None)
    if not selected:
        raise ValueError("The selected answer is not one of this question's current options. Choose again or write your own answer.")
    if answer != compose(question, selected["value"], explanation):
        raise ValueError("The selected option and answer text differ. Choose the option again, or save the edited text as your own answer.")
    return {"schema_version": 1, "kind": "single_choice",
        "question": {"text": question, "evidence": str(form.get("evidence") or ""),
            "question_sha256": str(form.get("question_sha256") or ""),
            "records_sha256": str(form.get("records_sha256") or "")},
        "options": options, "options_sha256": _sha(options),
        "selected_option_id": selected["id"], "selected_value": selected["value"],
        "explanation": explanation.strip(), "answer_sha256": _sha(answer)}


def validated(form):
    """Return a checked choice, or None for legacy/free-text forms; never parse prose."""
    if "answer_choice" not in form:
        return None
    value = form["answer_choice"]
    if not isinstance(value, dict) or type(value.get("schema_version")) is not int:
        raise ValueError("The structured answer choice is malformed; choose the answer again.")
    expected = selection(form, value.get("selected_option_id"), value.get("explanation"), form.get("answer"))
    if "field_binding" in value:
        expected["field_binding"] = field_binding(value["field_binding"], expected["selected_option_id"])
    if value != expected:
        raise ValueError("The structured answer choice no longer matches the exact question, options or evidence. Reload and choose again.")
    return deepcopy(expected)


BINDING_FIELDS = {"derivation": "Definition / logic / formula", "window": "Eligible window",
    "record_selection": "Record selection", "tie_break": "Tie break", "missing": "Missing values",
    "units": "Units", "clinical_rule.pick": "Clinical measurement selection"}


def field_binding(value, option_id):
    """A person's explicit option-to-literal mapping; no interpretation of prose."""
    if not isinstance(value, dict) or set(value) != {"schema_version", "selected_option_id", "item_id",
            "variable_id", "field", "value", "scope", "rationale"} or type(value.get("schema_version")) is not int or value.get("schema_version") != 1:
        raise ValueError("Choose a supported variable field and supply its explicit decision mapping.")
    if value["selected_option_id"] != option_id or value["field"] not in BINDING_FIELDS:
        raise ValueError("The field mapping belongs to another option or an unsupported field.")
    if not isinstance(value["item_id"], str) or not re.fullmatch(r"[A-Za-z][A-Za-z0-9_]*:\d+", value["item_id"]) or not isinstance(value["variable_id"], str) or not re.fullmatch(r"[A-Za-z][A-Za-z0-9_]*", value["variable_id"]):
        raise ValueError("Choose the linked variable from this question's current evidence.")
    for name, limit in (("value", 4000), ("scope", 1000), ("rationale", 1500)):
        text = value[name]
        if not isinstance(text, str) or not text.strip() or len(text) > limit or re.search(r"\b(?:TODO|TBD|FIXME|REPLACE_ME)\b", text, re.I):
            raise ValueError("Complete the mapped value, scope and rationale before recording this mapping.")
        if any(ord(c) < 32 and c not in "\n\r\t" or ord(c) == 127 for c in text):
            raise ValueError("Remove control characters from the field mapping.")
    if value["field"] == "clinical_rule.pick" and value["value"] not in {"nearest", "earliest", "latest"}:
        raise ValueError("Clinical measurement selection must be nearest, earliest or latest; the calculation also checks which policies it supports.")
    return deepcopy(value)

