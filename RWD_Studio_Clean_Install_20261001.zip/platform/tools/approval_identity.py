#!/usr/bin/env python3
"""Which approvals have verified signatures, and which still lack identity evidence?

    python3 platform/tools/approval_identity.py            # every governed approval, with its state
    python3 platform/tools/approval_identity.py --check     # exit 1 on what is enforceable TODAY
    python3 platform/tools/approval_identity.py --check-readiness  # also require enrolled reviewer setup

CURRENT TRUST BOUNDARY: local key registration and SSH/GPG verification prove
key possession. Authentication additionally requires independent administrator
enrollment in the managed installation protected state/admin-trust store, with
a current matching reviewer principal. Repository edits and demo profiles cannot
enroll identities. Missing enrollment keeps new approvals held by the gates.

WHAT WAS MISSING. Every human attribution here is a free-text string: `approved_by`,
`classified_by`, `attested_by`, `validated_by`, `answered_by`, `confirmed_by`. The only check that
touches identity is `person_rules.not_a_person`, whose own docstring says it "CANNOT VERIFY A PERSON
EXISTS and does not pretend to" — it refuses a declared team word and a bare ALL-CAPS acronym.
`approved_by: asdf` with `validated_by: root` satisfies every gate including separation of duties,
because the two strings differ. `governance/APPROVAL_IDENTITY.md` designs the full fix — approval
bound to an authenticated pull-request review — and that design is still not implemented, because
its first step is branch protection, which is a repository-admin act and not a code change.

WHAT `--check` FAILS ON: a malformed signer registry; a forge or automation key registered where
only a person's key belongs; a refresh manifest claiming `released` whose `sign_off.qc_by` /
`released_by` names a function rather than a person (`engine/refresh.py` requires those fields and
can only check them for PRESENCE — the engine may not import `platform/tools`, so the predicate is
applied here instead of copied there); and ANY APPROVAL WITHOUT INDEPENDENT IDENTITY EVIDENCE that is not recorded
in `governance/approval_baseline.yaml`.

THE BASELINE IS WHY THAT LAST ONE CAN EXIST. Every approval already in this repository predates the
mechanism, no check applied later turns an unsigned commit into a signed one, and a check that went
red on all of them from its first commit would be switched off the same day — after which nothing
would be enforced at all. The baseline records those, keyed on (file, field, who, COMMIT), so the
check is a live rule about new work rather than a verdict on history. Keying on the commit is what
stops it becoming a permanent exemption: re-make one of those approvals and its identity changes,
so it drops out of the baseline and back under the rule. The tool PRINTS the baseline and never
writes it — a judge that could write its own exemption list is a check that can green itself.

WHAT THIS DOES. It enumerates APPROVALS, not files. For each one it finds the commit whose diff
wrote that approval — `git log -G` over the line asserting it, so an unrelated edit elsewhere in
the document does not re-date it — and asks whether that commit carries a signature by a key
`governance/allowed_signers.yaml` registers as `person_review`, and whether the locally registered
identity string matches the approval's name. This is not an independent identity binding.

WHICH FIELD IS THE APPROVAL IS DECLARED PER SURFACE, and that is not cosmetic. A Gate 2 form
records `approved_by` and `spec_qc_reviewed_by`; a Gate 4 form records `approved_by` and
`technically_reviewed_by`. Those are different acts by different people. An earlier version walked
every `*_by` field and treated all of them as approvers, so the QC reviewer's signature
authenticated the approval — the same defect as signing for somebody else, with the two names one
line apart. The other actors are still read and reported, as people who acted and did not approve.

WHAT IT STILL CANNOT DO. A signature says "this key signed these commit bytes". It cannot establish
that the typed reviewer exists, enrolled the key, or approved the science. Per-approval
immutable events (the design in `governance/APPROVAL_IDENTITY.md`) would say more; `git log -G`
says this much, precisely.

An earlier version claimed the identity comparison in this docstring and never made it: it checked
only that the signing key was registered, so a signature by ANY registered person authenticated an
approval attributed to somebody else. That is the defect class this repository keeps finding — a
header describing a check that does not exist — committed in the tool written to catch it.

WHAT IT DELIBERATELY REFUSES TO COUNT. This repository's history holds 32 signed commits, all of
them GitHub MERGE commits on the forge's own key. They are exactly the shape that makes a wrong fix
tempting: register that key, and 32 signatures verify while authenticating nothing. A forge
signature attests that a merge happened, on a key available to anyone with write access, applied by
the same web-merge operation whether or not a human read the diff. `allowed_signers.yaml` therefore
records what each key ATTESTS, and only `person_review` may support an approval.

WHAT IT CANNOT DO, AND SAYS SO. It cannot authenticate approvals that already exist: every commit
touching `governance/**` and every `source_refs.yaml` is unsigned, and no check applied afterwards
changes that. Those approvals must be re-made under signature or stay unauthenticated. The report
prints the numbers apart — keys registered, signatures verified, approvals authenticated, approvals
baselined — because they need different actions and a single number would hide the blocker.

...and it names the surfaces holding NO FILE. Most of them do: no pack has reached Gate 2, 3, 4 or
6 and `work/` does not exist. Printing only the files that exist would report a coverage number
over surfaces that are not covered but simply absent — an absence read as a clean result, which is
the defect this repository has had to fix in five other tools.

READ-ONLY for review records, trust inputs and Git configuration. It signs and registers nothing;
public-only temporary verification files are removed after each Git invocation. This audit does not change `allowed_signers.yaml` or enrollment. Enrollment
is a separate authenticated administrator act; each approval still needs the
reviewer-owned Git signature on its exact content.
"""
from __future__ import annotations

import argparse
import base64
from contextlib import contextmanager
import hashlib
import os
import re
import shutil
import subprocess
import sys
import tempfile

TOOLS = os.path.dirname(os.path.abspath(__file__))
from rwd_services import workspace_root
REPO = str(workspace_root(__file__))

from rwd_tools.product_gates import not_a_person, read_yaml, unstated # noqa: E402
from rwd_tools.contract_lint import APPROVER_COLUMNS, cell, decision_rows # noqa: E402
from rwd_tools.spec_extract import repo_relative # noqa: E402

REGISTRY = "governance/allowed_signers.yaml"
# The one kind of key that may stand behind a person's approval.
PERSON_REVIEW = "person_review"
IDENTITY_EVIDENCE_REQUIRED = (
    "A verified Git signature also needs independent reviewer enrollment. Open Reviewer identity enrollment "
    "on this review page; a different authenticated administrator binds the existing signing key to the "
    "current reviewer principal in the managed installation's protected state/admin-trust store."
)

# THE FILES THAT CARRY A GOVERNED HUMAN ATTRIBUTION, AND WHICH FIELD ON EACH IS THE APPROVAL.
#
# Matched by SHAPE rather than by a hand list of packs: any pack that grows an approval form is
# covered the day it lands, which a remembered list would not be. Most of these patterns match
# nothing today — that is reported, not hidden.
#
# THE THIRD COLUMN IS THE FIX FOR THE DEFECT THIS TOOL WAS WRITTEN TO CATCH, ONE LEVEL DOWN. The
# first version walked EVERY `*_by` field in the document and called all of them approvers. But an
# approval form records several different acts by several different people: Gate 2's
# `spec_qc_reviewed_by` performed the specification QC, Gate 4's `technically_reviewed_by` reviewed
# the configuration, and neither of them APPROVED anything — `approved_by` did. Under the walk, a
# signature by the technical reviewer authenticated a file whose approver was somebody else, which
# is precisely "a signature by one registered person says nothing about a name somebody else typed"
# with the names one row apart. So the approving field is NAMED per surface, and only it is matched
# against the signer. The other actors are still read, and reported as present-but-not-authenticated
# rather than silently promoted or silently dropped.
#
# `()` means the surface is a MARKDOWN TABLE and the approving cell is `contract_lint`'s
# APPROVER_COLUMNS — one vocabulary for "who approved this row", shared with every gate that reads
# those registers.
APPROVAL_GLOBS = (
    ("products/*/*/*/source_refs.yaml", "Gate 1 registration and classification",
     ("classified_by", "approved_by", "revised_by")),
    ("products/*/*/*/handoff/CONTRACT_APPROVAL.yaml", "Gate 2 contract approval", ("approved_by",)),
    ("products/*/*/*/handoff/CONFIGURATION_APPROVAL.yaml", "Gate 4 configuration approval",
     ("approved_by",)),
    # WHAT THE VARIABLES MEAN, signed. `clinically_reviewed_by` is an APPROVING field and
    # not a supporting actor: whether a variable means a given concept is a clinical
    # judgement, and it is the one this form exists to record.
    ("products/*/*/*/handoff/SEMANTIC_APPROVAL.yaml", "a semantic binding approval",
     ("approved_by", "clinically_reviewed_by")),
    # `validated_by` IS an approval here and not a supporting actor: Gate 5's human exit is recorded
    # on this form, and it is a distinct accountable act from the release approval beside it.
    ("products/*/*/*/handoff/RELEASE_APPROVAL.yaml", "Gate 6 release approval",
     ("approved_by", "validated_by")),
    ("products/*/*/*/handoff/SOURCE_VERDICTS.md", "Gate 3 source verdicts", ()),
    # THE SOURCE ADAPTER'S REVIEW, watched like every other approval and for the same reason. Its
    # `review.status: reviewed` is what lets a live run bind delivered data through the mapping —
    # `run_rwdp` refuses an unreviewed set outright — so it decides which physical columns become
    # which canonical ones, and with what type. That is an approval by any definition this
    # repository uses. Until it was listed here `source_adapter.check` held it to `not_a_person`
    # and a well-formed date and nothing else, so a plausible typed name signed the binding the
    # whole portability claim rests on. `_walk_by_fields` finds the field nested under
    # `adapters[].review`, so no special reader is needed.
    ("products/*/*/*/config/source_adapters.yaml", "a source-adapter review", ("approved_by",)),
    ("products/*/*/*/handoff/DECISIONS.md", "the decision register", ()),
    ("work/*/REQUEST.yaml", "an answered request",
     ("answered_by", "withdrawn_by", "superseded_marked_by")),
    # `amended_by` sits nested under `amendments[]` and `_walk_by_fields` finds it there. An
    # amendment CHANGES a frozen plan — the exact act this audit exists to bind to a person —
    # and until it was named here, the one field on the protocol that alters signed content was
    # the one field the identity check never read.
    ("work/*/PROTOCOL.yaml", "a registered protocol",
     ("registered_by", "amended_by", "closed_by")),
    # A STUDY'S PIN AND ITS DEFINITION DECISIONS. `decided_by` sits under `pins[].definitions[]` and
    # says whose judgement it was to reuse, reconsider or exclude a product's definition for this
    # study; `reviewed_by` says who re-read the product after its contract moved. Attributions,
    # watched like every other typed name, and found nested by the same walk.
    ("work/*/PINS.yaml", "a study's pin and its definition decisions",
     ("pinned_by", "decided_by", "reviewed_by")),
    # A TEMPLATE RELEASE RECOMMENDS MEANING to every future pack; its reviews are approvals
    # by any definition this repository uses, and until this line they were held to
    # not_a_person and a date and nothing else.
    ("governance/reference/template_releases/*.yaml", "a template release review",
     ("reviewed_by",)),
    # INVENTORY.yaml, not CITATIONS.yaml. `provenance.basis: workbook_confirmed` — the claim that a
    # named person read the approved workbook — hangs off the INVENTORY variables; CITATIONS.yaml
    # holds verification ROUTES and carries no `confirmed_by`. Watching the wrong file meant the one
    # surface here that actually asserts a human act was not being watched at all.
    ("governance/reference/variable_inventory/INVENTORY.yaml", "a workbook confirmation",
     ("confirmed_by",)),
    # A POOLING AUTHORISATION IS AN APPROVAL. `same_construct` / `accepted_proxy` in the
    # equivalence rulings is what permits two sources' numbers to be pooled, and until this
    # line the `ruled_by` name behind it was held to `not_a_person` and nothing else — a
    # typed name authorising pooling that no identity check ever read.
    ("governance/EQUIVALENCE_RULINGS.yaml", "an equivalence ruling", ("ruled_by",)),
    # A TEMPLATE RULING confirms that a contract row and a registry concept are the same
    # measurement — nothing downstream re-checks it, which is exactly what makes it an
    # approval; and a WITHDRAWAL or REVISION is an act that alters what a record means, so
    # the actors join the same walk (earlier review: decided_by, withdrawn_by and
    # revised_by drove decisions no identity check ever read).
    ("products/*/*/*/handoff/TEMPLATE_RULINGS.yaml", "a template-slot ruling", ("decided_by",)),
    ("refreshes/*/*/*/*.yaml", "a refresh QC and release sign-off", ("qc_by", "released_by")),
)
# BOTH ROOTS, derived rather than doubled: an approval surface inside a fixture pack is still an
# attestation somebody must own, and the identity audit keeps watching it after the pack crosses
# the products/fixtures boundary.
APPROVAL_GLOBS = APPROVAL_GLOBS + tuple(
    (g.replace("products/", "fixtures/", 1), governs, fields)
    for g, governs, fields in APPROVAL_GLOBS if g.startswith("products/"))

# WHERE THE APPROVALS THAT PREDATE THE MECHANISM ARE RECORDED. Grandfathering is by the exact
# (file, field, who, commit) an approval was made in — never by file or by surface — so re-making an
# approval in a NEW commit takes it out of the baseline and back under the check. See `--baseline`.
BASELINE = os.path.join("governance", "approval_baseline.yaml")

# THE REFRESH SIGN-OFF, held to `not_a_person` HERE because it cannot be held to it where it is
# required. `engine/refresh.py` demands `sign_off.qc_by`, `sign_off.released_by` and their dates
# before a manifest may read `released`, and checks them for PRESENCE only — so `qc_by: DataExpert`
# releases a refresh on a function's authority. The engine cannot call `not_a_person`:
# `engine/validate.py` states outright that the engine must not import `platform/tools`, and
# copying the predicate in is the duplication this repository keeps paying for (two rules, one
# question, drifting apart). A tool reads the same manifests in CI, so the predicate stays in one
# place and the field still gets held to it.
SIGN_OFF_PEOPLE = ("qc_by", "released_by")


def registry(root=REPO):
    if not os.path.exists(os.path.join(root, REGISTRY)):
        # said as an absence, never as an errno with a machine path (thirteenth pass)
        return {}, [f"{REGISTRY} is absent — no signer registry, so no approval can be authenticated"]
    doc, err = read_yaml(os.path.join(root, REGISTRY))
    if err:
        return {}, [f"{REGISTRY}: {err}"]
    try:
        _ssh_signer_lines(doc or {})
    except ValueError as error:
        return {}, [f"{REGISTRY}: {error}"]
    return (doc or {}), []


def ssh_public_key(public):
    """Parse one public SSH key and derive the fingerprint; no registry or identity writes."""
    key_types = {"ssh-ed25519", "ssh-rsa", "ecdsa-sha2-nistp256", "ecdsa-sha2-nistp384",
                 "ecdsa-sha2-nistp521", "sk-ssh-ed25519@openssh.com", "sk-ecdsa-sha2-nistp256@openssh.com"}
    if (not isinstance(public, str) or len(public) > 32768
            or any(ord(c) < 32 or ord(c) == 127 for c in public)):
        raise ValueError("an SSH public key must be one bounded line of public key material")
    fields = public.split()
    if len(fields) < 2 or fields[0] not in key_types:
        raise ValueError("an SSH signer needs its complete supported public key")
    try:
        blob = base64.b64decode(fields[1], validate=True)
    except (ValueError, TypeError) as error:
        raise ValueError("an SSH public key has invalid base64 material") from error
    size = int.from_bytes(blob[:4], "big")
    if len(blob) < 8 or not 0 < size <= 128 or blob[4:4 + size] != fields[0].encode("ascii"):
        raise ValueError("the SSH public key type does not match its encoded material")
    fingerprint = "SHA256:" + base64.b64encode(hashlib.sha256(blob).digest()).decode("ascii").rstrip("=")
    return {"key_id": fingerprint, "public_key": f"{fields[0]} {fields[1]}", "algorithm": fields[0]}


def _ssh_signer_lines(doc):
    """Compile public verification material; approval purpose and enrollment are separate checks."""
    if not isinstance(doc, dict) or any(not isinstance(doc.get(name, []), list)
                                        for name in ("signers", "known_ineligible")):
        raise ValueError("signers and known_ineligible must be lists in a named registry")
    if len(doc.get("signers", [])) > 10000:
        raise ValueError("the signer registry exceeds its supported size")
    lines, seen = [], set()
    key_types = {"ssh-ed25519", "ssh-rsa", "ecdsa-sha2-nistp256", "ecdsa-sha2-nistp384",
                 "ecdsa-sha2-nistp521", "sk-ssh-ed25519@openssh.com", "sk-ecdsa-sha2-nistp256@openssh.com"}
    for row in doc.get("signers", []):
        if not isinstance(row, dict):
            raise ValueError("each signer must be a named entry")
        key_id = str(row.get("key_id") or "")
        if key_id in seen:
            raise ValueError("a signing key is registered more than once; resolve its identity and purpose")
        seen.add(key_id)
        public = row.get("public_key", "")
        if not key_id.startswith("SHA256:") and not (isinstance(public, str) and public.split()[:1] and public.split()[0] in key_types):
            continue  # Existing OpenPGP entries use Git's OpenPGP verifier.
        material = ssh_public_key(public)
        fingerprint = material["key_id"]
        if key_id != fingerprint:
            raise ValueError("the SSH public key does not match its registered SHA256 fingerprint")
        principal = "rwd-" + hashlib.sha256(key_id.encode("ascii")).hexdigest()
        # Never copy principal text, key comments, options or certificate authority declarations.
        lines.append(f'{principal} namespaces="git" {material["public_key"]}\n')
    return "".join(lines)


@contextmanager
def _signature_options(root, args):
    """Per-invocation SSH trust, portable across full clones; no Git configuration writes."""
    if not any(str(arg).startswith(("--pretty=", "--format=")) and "%G?" in str(arg) for arg in args):
        yield []
        return
    doc, errors = registry(root)
    if errors:
        raise ValueError("; ".join(errors))
    program = shutil.which("ssh-keygen") or "ssh-keygen"
    options = ["-c", f"gpg.ssh.program={program}"]
    with tempfile.TemporaryDirectory(prefix="rwd-git-verify-") as directory:
        path = os.path.join(directory, "allowed-signers")
        with open(path, "x", encoding="utf-8", newline="\n") as stream:
            stream.write(_ssh_signer_lines(doc))
        yield [*options, "-c", f"gpg.ssh.allowedSignersFile={path}"]


def ineligible_keys(doc):
    """{key_id: why} for every key the registry records as unable to support an approval."""
    return {str(k.get("key_id")): str(k.get("why") or k.get("attests") or "recorded ineligible")
            for k in (doc.get("known_ineligible") or []) if isinstance(k, dict)}


def person_keys(doc):
    """{key_id: identity} for every key registered as attesting a PERSON's own review.

    `known_ineligible` is ENFORCED here, not merely documented. It used to be prose that no code
    read: relabelling the forge key `person_review` in `signers:` made it a valid approval key, and
    a test of mine asserted exactly that as if it were the correct behaviour. A registry that
    records why a key cannot support an approval, and then accepts it when somebody types a
    different word next to it, documents the rule instead of applying it.
    """
    bad = ineligible_keys(doc)
    return {str(s.get("key_id")): str(s.get("identity") or "")
            for s in (doc.get("signers") or [])
            if isinstance(s, dict) and str(s.get("attests")) == PERSON_REVIEW
            and str(s.get("key_id")) not in bad}


def setup_readiness(root=REPO):
    """Identity setup status for authoring startup and production boundaries."""
    doc, errors = registry(root)
    if errors:
        return {"ready": False, "registered_keys": 0, "enrolled_reviewers": 0,
                "why": "Reviewer registry needs attention: " + "; ".join(errors)}
    return enrollment_readiness(doc, root)


def enrollment_readiness(doc, root=REPO):
    """Read-only setup readiness; this does not approve any product or release."""
    from rwd_tools import reviewer_identity_store
    keys = person_keys(doc)
    if not keys:
        return {"ready": False, "registered_keys": 0, "enrolled_reviewers": 0,
                "why": "No eligible reviewer keys are registered. The empty signer registry is a valid scaffold, "
                       "but reviewer identity setup is not ready. Register a reviewer's public key and have a "
                       "different authenticated administrator enroll its principal."}
    verified = [reviewer_identity_store.verify(root, name, key) for key, name in keys.items()]
    principals = {result["principal"] for result in verified if result.get("ok")}
    return {"ready": bool(principals), "registered_keys": len(keys), "enrolled_reviewers": len(principals),
            "why": ("At least one registered reviewer has current independent enrollment. Each approval still "
                    "requires its own verified signature and the product's required independent reviewers."
                    if principals else "No registered reviewer has current independent enrollment. "
                    + " ".join(dict.fromkeys(result["why"] for result in verified)))}


def _git(root, *args):
    # `git show <full sha>:<path>` cannot change; everything else here reads HEAD and is asked every time
    # (see event_ledger._git for the same rule and why).
    key = (os.path.realpath(root), args) if (args[:1] == ("show",) and len(args) in (2, 3)
                                              and re.match(r"^[0-9a-f]{40}:", args[1])
                                              and (len(args) == 2 or args[2] == "--")) else None
    if key is not None and key in _SHOW_CACHE:
        return _SHOW_CACHE[key]
    try:
        with _signature_options(root, args) as options:
            r = subprocess.run(["git", "-C", root, *options, *args], capture_output=True, text=True,
                               encoding="utf-8", errors="replace")
    except (OSError, ValueError):
        return ""  # A missing or invalid trust input can never produce a good signature verdict.
    out = r.stdout.strip() if r.returncode == 0 else ""
    if key is not None and r.returncode == 0:
        if len(_SHOW_CACHE) > 2048:
            _SHOW_CACHE.clear()
        _SHOW_CACHE[key] = out
    return out


_SHOW_CACHE: dict = {}


def approval_files(root=REPO):
    """[(path, what it governs, approving fields)] — every file on disk carrying an attribution."""
    return [(rel, what, fields) for _, what, fields, files in surfaces(root) for rel in files]


def surfaces(root=REPO):
    """[(pattern, what it governs, approving fields, [files])] — INCLUDING patterns matching nothing.

    A surface with no files on disk is the report's most misleading state, and it is the state most
    of these are in: no pack has reached Gate 2, 3, 4 or 6, and `work/` does not exist. Returning
    only the matches would print a coverage count over a repository whose Gate 6 release approval is
    not covered but simply ABSENT — an absence read as a clean result, which is the defect this
    repository has had to fix in five other tools. The caller gets the empty lists and has to say so.

    No count is written down here on purpose: a number in a comment is a claim that goes stale
    silently. `render` counts what it finds.
    """
    import glob
    return [(pattern, what, fields,
             [repo_relative(p, root) for p in sorted(glob.glob(os.path.join(root, pattern)))])
            for pattern, what, fields in APPROVAL_GLOBS]


def shallow(root=REPO):
    """Is this checkout missing its history? A SHALLOW clone cannot answer this tool's question.

    `git log -G` walks commits. On a `--depth 1` clone there is exactly one, and git treats it as a
    root — every line in the tree reads as an addition in that commit — so EVERY approval binds to
    HEAD and the answer looks perfectly ordinary. Two consequences, and the second is the serious
    one: the baseline stops matching (noisy but safe), and if HEAD happens to carry a `person_review`
    signature then every approval in the repository reports as AUTHENTICATED BY THAT SIGNER. A
    forgery of exactly the act this tool exists to prevent, reachable by cloning with `--depth 1`.

    So the depth is checked and the tool refuses rather than computing a confident wrong answer.
    This is not a portability nicety: CI's Windows job checks out at the default depth 1, and would
    have run the whole suite against that answer.
    """
    return _git(root, "rev-parse", "--is-shallow-repository").strip().lower() == "true"


SHALLOW_WHY = ("this checkout is a SHALLOW clone, so no commit can be identified as the one that "
               "wrote this approval — on a one-commit history every line reads as written by HEAD. "
               "Clone with full history (`git fetch --unshallow`) before trusting any answer here")


def approval_commit(root, rel, pattern):
    """(sha, signature status, key, signer) for the commit that last WROTE this approval, or None.

    THE UNIT IS THE APPROVAL, NOT THE FILE, and that distinction is the whole point of this
    function. `git log -1 -- <path>` finds the last commit that touched the file for ANY reason —
    so a typo fix in a note, signed by anyone, "authenticated" every approval in the document,
    including ones written years earlier by other people in unsigned commits. The signature that
    can stand behind `approved_by: X` is the one on the commit whose diff wrote `approved_by: X`.

    `-G` searches the DIFF TEXT with a regex, so this asks git the exact question: which commits
    touching this file changed a line asserting this approval? The most recent one is the commit
    that put the value in its current form — a later removal would mean the value is not in the
    file, and this is only ever called for values that are.

    It cannot separate an addition from a reformatting of the same line, and does not claim to: both
    are "the commit that last wrote this assertion", which is what a signature would be attesting.

    `%G?` is git's own verdict: G good, B bad, U good-with-unknown-trust, X expired, Y expired key,
    R revoked, E cannot check, N none. Anything other than G/U is not a signature this may rely on,
    and `E` — the state every signed commit in this repository is in — means git could not check it.
    """
    line = _git(root, "log", "-1", "--pretty=%H|%G?|%GK|%GS|%an", f"-G{pattern}", "--", rel)
    if not line:
        return None
    sha, status, key, signer, author = (line.split("|") + ["", "", "", ""])[:5]
    return {"sha": sha, "status": status, "key": key, "signer": signer, "author": author}


def subject_moved(root, rel, approval_sha):
    """[(field path, change)] for digest values that differ from the signed assertion's tree.

    A digest may predate the approval, and independent reviewers can sign the same
    unchanged subject in separate commits. Comparing the last-writing commit IDs
    rejected both legitimate cases. Compare values at each YAML path instead: a
    later changed, removed or added digest still invalidates that assertion, including
    uncommitted edits. Plain nested ``sha256`` source bindings are subjects too.
    Formatting and quoting alone do not change which bytes were approved.
    """
    path = os.path.join(root, rel)
    if not rel.endswith((".yaml", ".yml")):
        return []

    def unreadable():
        return [("approval_subject", {"sha": "UNREADABLE", "author": "unavailable or malformed subject"})]

    def digests(text):
        import yaml  # noqa: PLC0415
        # Duplicate keys and aliases make a path comparison ambiguous. The subject
        # must be explicit, even if an ordinary YAML reader would accept the file.
        if any(isinstance(token, (yaml.AliasToken, yaml.AnchorToken)) for token in yaml.scan(text)):
            raise ValueError("ambiguous approval YAML")
        tree = yaml.compose(text, Loader=yaml.SafeLoader)
        if not isinstance(tree, yaml.MappingNode):
            raise ValueError("approval YAML is not a mapping")
        result = {}

        def walk(node, parent=""):
            if isinstance(node, yaml.MappingNode):
                seen = set()
                for key, value in node.value:
                    if not isinstance(key, yaml.ScalarNode) or key.value in seen:
                        raise ValueError("ambiguous approval YAML key")
                    seen.add(key.value)
                    field = f"{parent}.{key.value}" if parent else key.value
                    if key.value == "sha256" or key.value.endswith("_sha256"):
                        if not isinstance(value, yaml.ScalarNode):
                            raise ValueError("approval digest is not scalar")
                        result[field] = value.value
                    else:
                        walk(value, field)
            elif isinstance(node, yaml.SequenceNode):
                for index, value in enumerate(node.value):
                    walk(value, f"{parent}[{index}]")

        walk(tree)
        return result

    try:
        import yaml  # noqa: PLC0415
        with open(path, encoding="utf-8") as stream:
            current = digests(stream.read())
        approved = digests(_git(root, "show", f"{approval_sha}:{rel}", "--"))
    except (OSError, ValueError, UnicodeError, RecursionError, yaml.YAMLError):
        return unreadable()
    out = []
    for field in sorted(set(current) | set(approved)):
        if field in current and field in approved and current[field] == approved[field]:
            continue
        key = field.rsplit(".", 1)[-1]
        c = approval_commit(root, rel, rf"^\s*{re.escape(key)}\s*:")
        if not c or c["sha"] == approval_sha:
            c = {"sha": "WORKTREE", "author": "uncommitted edit"}
        out.append((field, c))
    return out


def sign_off_errors(root=REPO):
    """Refresh manifests whose release sign-off names a function rather than a person.

    Only manifests that actually claim `released` are held to it: a manifest still building has an
    empty `sign_off` block by design, and refusing that would refuse the template.
    """
    import glob
    out = []
    for p in sorted(glob.glob(os.path.join(root, "refreshes", "*", "*", "*", "*.yaml"))):
        doc, err = read_yaml(p)
        rel = repo_relative(p, root)
        if err:
            out.append(f"{rel}: {err}")
            continue
        if not isinstance(doc, dict) or str(doc.get("status") or "") != "released":
            continue
        for f in SIGN_OFF_PEOPLE:
            v = ((doc.get("sign_off") or {}) if isinstance(doc.get("sign_off"), dict) else {}).get(f)
            why = not_a_person(v)
            if why:
                out.append(f"{rel}: `sign_off.{f}`: {why}")
    return out


def _walk_by_fields(node, out):
    """{field name: {values}} for every `*_by` field anywhere in a loaded YAML document.

    KEYED ON THE FIELD, because which field a name sits in is what says WHICH ACT it performed.
    The first version discarded the field and returned a flat set of names, which is how a
    specification QC reviewer and a contract approver became interchangeable.
    """
    if isinstance(node, dict):
        for k, v in node.items():
            if str(k).endswith("_by") and isinstance(v, (str, int, float)):
                got = str(v).strip()
                if got and not unstated(got):
                    out.setdefault(str(k), set()).add(got)
            else:
                _walk_by_fields(v, out)
    elif isinstance(node, (list, tuple)):
        for v in node:
            _walk_by_fields(v, out)


def actors_in(path):
    """({field: {people}}, ok) — everyone a governed file names, and WHICH ACT each performed.

    Without this the tool compared nothing: it checked that the signing key was registered and
    called the file authenticated, so a signature by ANY registered person authenticated an
    approval attributed to somebody else entirely. The docstring claimed the comparison; the code
    never made it. Reading the named actors is what makes "your signature authenticates YOUR typed
    name" true rather than merely stated.

    `ok` is False when the file could not be read at all — distinct from a file that reads cleanly
    and names nobody, because only the second is a finding about the approval.

    A markdown register comes back under the pseudo-field `decision:<id>`, so a decision row is an
    approval in its own right and binds to the commit that wrote THAT row.
    """
    if path.endswith((".yaml", ".yml")):
        doc, err = read_yaml(path)
        if err:
            return {}, False
        found = {}
        _walk_by_fields(doc, found)
        return found, True
    if path.endswith(".md"):
        import re
        try:
            text = open(path, encoding="utf-8", errors="replace").read()
        except OSError:
            return {}, False
        found = {}
        for did, row in decision_rows(text).items():
            got = re.sub(r"[*`_]", "", str(cell(row, *APPROVER_COLUMNS, default="") or "")).strip()
            if got and not unstated(got):
                found.setdefault(f"decision:{did}", set()).add(got)
        return found, True
    return {}, False


def _is_approving(field, declared):
    """Is this field the APPROVING act on its surface? `()` declares a markdown approver column."""
    return field.startswith("decision:") if not declared else field in declared


def _acts(root=REPO):
    """([approvals], [(file, field, who) that are NOT approvals]) — ONE walk of the surfaces.

    Both halves come out of the same read because they are the same reading, split by one predicate:
    which field on this surface carries the approval. Two loops over `approval_files` would open
    every governed file twice and, worse, could come to disagree about which field is which — the
    two callers would then report a person as an approver in one place and a supporting actor in
    the other, with nothing to say which was right.
    """
    import re
    approved, others = [], []
    for rel, what, fields in approval_files(root):
        found, ok = actors_in(os.path.join(root, rel))
        if not ok:
            approved.append({"file": rel, "governs": what, "field": None, "who": None,
                             "pattern": None, "unreadable": True})
            continue
        for field, people in sorted(found.items()):
            for who in sorted(people):
                if not _is_approving(field, fields):
                    others.append((rel, field, who))
                    continue
                # The assertion as it appears in the file, as a diff regex. YAML may quote the
                # value, so the quote is optional; a markdown row carries the decision id and the
                # approver on the SAME line, which is what makes a per-row bind possible at all.
                pattern = (rf"{re.escape(field.split(':', 1)[1])}.*{re.escape(who)}"
                           if field.startswith("decision:")
                           else rf"{re.escape(field)}:\s*[\"']?{re.escape(who)}")
                approved.append({"file": rel, "governs": what, "field": field, "who": who,
                                 "pattern": pattern, "unreadable": False})
    return approved, others


def approvals(root=REPO):
    """[{file, governs, field, who, pattern}] — ONE ENTRY PER APPROVAL, and a `pattern` that
    identifies the line asserting it so a signature can be bound to that line's commit.

    Only the fields each surface declares as APPROVING are here. The others are real acts by real
    people and come back from `other_actors`, never counted as approvals.
    """
    return _acts(root)[0]


def other_actors(root=REPO):
    """[(file, field, who)] — people a governed file names who did NOT approve it.

    Reported rather than dropped. `spec_qc_reviewed_by` performed the specification QC and
    `technically_reviewed_by` reviewed the configuration; both are accountable acts, neither is the
    approval, and a reader who sees only the approvers would think the file named one person. The
    previous version made the opposite error and treated them all as approvers.
    """
    return _acts(root)[1]


def audit(root=REPO, files=None):
    """[{file, governs, field, who, commit, authenticated, why}] — one row per APPROVAL.

    `files` narrows the walk to the surfaces a predicate accepts (a pack's own files, for the
    release verdict); None audits the whole repository, as `--check` does."""
    doc, errs = registry(root)
    keys = person_keys(doc)
    bad_keys = ineligible_keys(doc)
    is_shallow = shallow(root)
    rows = []
    for a in approvals(root):
        if files is not None and not files(a["file"]):
            continue
        row = dict(a)
        row["authenticated"] = False
        row["signature_verified"] = False
        if a["unreadable"]:
            row["commit"], row["why"] = None, "this file could not be read — nothing to bind"
            rows.append(row)
            continue
        # CHECKED ONCE, BEFORE ANY SIGNATURE IS BELIEVED. See `shallow`: on a depth-1 clone every
        # approval binds to HEAD, and a signed HEAD would authenticate all of them at once.
        if is_shallow:
            row["commit"], row["why"], row["shallow"] = None, SHALLOW_WHY, True
            rows.append(row)
            continue
        c = approval_commit(root, a["file"], a["pattern"])
        row["commit"] = c
        if c is None:
            row["why"] = ("no commit's diff wrote this approval — it is uncommitted, or the value "
                          "reached the file some way `git log -G` cannot see")
            rows.append(row)
            continue
        moved = subject_moved(root, a["file"], c["sha"])
        if moved:
            row["why"] = ("the subject of this approval moved after it was written: "
                          + "; ".join(f"`{f}` was last written in {m['sha'][:12]} by {m['author'] or '?'}"
                                      for f, m in moved)
                          + f", not in {c['sha'][:12]}, the commit that wrote `{a['field']}: {a['who']}` — an "
                            f"approval binds a name to the bytes it approved, so it is re-made over the new "
                            f"bytes or the bytes are put back")
            rows.append(row)
            continue
        if c["status"] not in ("G", "U"):
            row["why"] = {"N": "the commit that wrote it is UNSIGNED",
                          "E": "the commit carries a signature git cannot verify (no key "
                               "registered)",
                          "B": "the commit's signature is BAD",
                          "X": "the signing key had expired",
                          "Y": "the signature was made by an expired key",
                          "R": "the signing key was revoked"}.get(
                              c["status"], f"signature status {c['status']}")
            rows.append(row)
            continue
        if registry(root) != (doc, errs):
            row["why"] = "The reviewer key registry changed during verification. Reload the current registry and check again."
            rows.append(row)
            continue
        if c["key"] not in keys:
            row["why"] = (f"signed by key {c['key']}, which {REGISTRY} does not register as "
                          f"{PERSON_REVIEW}")
            if c["key"] in bad_keys:
                row["why"] = (f"signed by key {c['key']}, which {REGISTRY} records as INELIGIBLE "
                              f"to support an approval: {bad_keys[c['key']]}")
            rows.append(row)
            continue
        #...AND THE SIGNATURE MUST BE THIS APPROVER'S OWN. A signature by one registered person
        # says nothing about a name somebody else typed — including a name in the same file, one
        # field away, recording a different act.
        signer = keys[c["key"]]
        if signer != a["who"]:
            row["why"] = (f"signed by {signer}, but this approval is attributed to {a['who']} — a "
                          f"signature authenticates the signer's OWN typed name, never somebody "
                          f"else's")
            rows.append(row)
            continue
        row["signature_verified"] = True
        from rwd_tools import reviewer_identity_store
        enrolled = reviewer_identity_store.verify(root, a["who"], c["key"])
        row["authenticated"] = enrolled["ok"]
        row["why"] = enrolled["why"]
        if enrolled.get("code"):
            row["identity_code"] = enrolled["code"]
        if enrolled["ok"]:
            row["principal"] = enrolled["principal"]
            row["enrollment_id"] = enrolled["enrollment_id"]
        rows.append(row)
    return rows, errs


def audit_pack(root, rel):
    """`audit()` over ONE pack's approval surfaces — the rows the release verdict composes."""
    prefix = str(rel).replace("\\", "/").rstrip("/") + "/"
    return audit(root, files=lambda f: f.replace("\\", "/").startswith(prefix))


def unauthenticated(root, rel):
    """([approval rows nobody's signature stands behind], [errors]) for one pack.

    THE COMPOSED VERDICT (twelfth verdict, P0): `--check` reported an approval as unauthenticated
    while `source_manifest.releasable()` — and through it the status page, the portal and
    `--list-releasable` — showed the same pack's Gate 1 DONE, because the verdict never asked this
    module. A typed name in `approved_by` is a claim; the commit's `person_review` signature by that
    person is the evidence; the baseline is the recorded set that predate the mechanism. Everything
    else on a pack's own surfaces is an approval nobody has authenticated, and a gate that treats it
    as passed is the honour system with a green badge.
    """
    rows, errs = audit_pack(root, rel)
    base, berrs = baseline(root)
    return ([r for r in rows if not r.get("authenticated") and _key(r) not in base],
            list(errs) + list(berrs))


def gate_label(governs):
    """`Gate N` for a surface's `governs` text, or `evidence` when it names no gate — the prefix
    `status.py` files each reason under, so an unauthenticated approval lands on the gate it
    claims for."""
    m = re.match(r"^Gate (\d)", str(governs or ""))
    if m:
        return f"Gate {m.group(1)}"
    g = str(governs or "").lower()
    if "decision register" in g:
        return "Gate 2"
    if "semantic" in g:
        return "Gate 4"
    if "source-adapter" in g:
        return "Gate 3"
    return "evidence"


def _key(row):
    """The identity of ONE approval, as the baseline records it. Not the file — a file grows new
    approvals, and grandfathering a file would grandfather every one it ever gains."""
    return (row["file"], row.get("field") or "", row.get("who") or "",
            (row.get("commit") or {}).get("sha") or "")


def baseline(root=REPO):
    """({identity: why}, [errors]) — the approvals recorded as predating the mechanism.

    KEYED ON THE COMMIT as well as the name, and that is what keeps it from becoming a permanent
    exemption. Re-make an approval — edit the value, or write it again in a new commit — and its
    identity changes, so it drops out of the baseline and back under `--check`. A baseline keyed on
    the file would have exempted a Gate 6 release approval added tomorrow to a file whose Gate 1
    classification was grandfathered today.
    """
    path = os.path.join(root, BASELINE)
    if not os.path.exists(path):
        return {}, []
    doc, err = read_yaml(path)
    if err:
        return {}, [f"{BASELINE}: {err}"]
    return _baseline_from_doc(doc)


def _baseline_from_doc(doc):
    """({identity: why}, [errors]) from an already-parsed baseline document.

    SPLIT OUT SO THE GROWTH CHECK READS IT THE SAME WAY. A first version of `baseline_growth`
    parsed the base-branch copy itself and got both halves wrong — the key is `baselined`, not
    `approvals`, and the identity is built from four flat fields, not through `_key`, which expects
    a row from the approval SCAN and reads `commit.sha`. It therefore reported that a
    byte-identical file had grown by three entries. Two readers of one format is how that happens.
    """
    out, errs = {}, []
    for i, e in enumerate(((doc or {}).get("baselined") or [])):
        if not isinstance(e, dict):
            errs.append(f"{BASELINE}[{i}]: not a mapping")
            continue
        missing = [f for f in ("file", "field", "who", "commit") if not str(e.get(f) or "").strip()]
        if missing:
            errs.append(f"{BASELINE}[{i}]: no {', '.join(missing)} — an entry that does not name "
                        f"exactly one approval in exactly one commit exempts more than it should")
            continue
        out[(str(e["file"]), str(e["field"]), str(e["who"]), str(e["commit"]))] = \
            str(e.get("why") or "recorded as predating the mechanism")
    return out, errs


def render(rows, doc, errs, root=REPO):
    keys = person_keys(doc)
    known, base_errs = baseline(root)
    signed = [r for r in rows if r["authenticated"]]
    grandfathered = [r for r in rows if not r["authenticated"] and _key(r) in known]
    live = [r for r in rows if not r["authenticated"] and _key(r) not in known]
    L = ["APPROVAL IDENTITY — is any approval bound to something a person signed?", ""]
    for e in list(errs) + base_errs:
        L.append(f"  !! {e}")
    L += [f"  registered `{PERSON_REVIEW}` keys: {len(keys)}",
          f"  governed approvals:               {len(rows)}",
          f"  cryptographic signatures verified: {sum(r.get('signature_verified') is True for r in rows)}",
          f"  authenticated:                    {len(signed)}",
          f"  baselined (predate the mechanism):{len(grandfathered):>3}",
          f"  unauthenticated and NOT baselined:{len(live):>3}",
          ""]
    if any(r.get("shallow") for r in rows):
        L += ["  THIS CHECKOUT IS SHALLOW, and nothing below is an answer about signatures.",
              "  `git log -G` needs history: on a one-commit clone every approval binds to HEAD, so",
              "  a signed HEAD would report every approval in the repository as authenticated by",
              "  that signer. Run `git fetch --unshallow` and try again.", ""]
    if any(r.get("identity_code") == "identity_scope_unavailable" for r in rows):
        L += ["  NOT AUTHENTICATABLE IN LOCAL SCOPE: independent enrollment was not checked.",
              "  Verified signatures remain unauthenticated; approval and release gates remain blocked.", ""]
    if not keys:
        L += ["  NO KEY IS REGISTERED. The reviewer and responsible administrator must arrange",
              "  public-key enrolment. The signing helper cannot create or register a key.", ""]
    unsigned = [r for r in rows if r["commit"] and r["commit"]["status"] == "N"]
    if unsigned:
        L += [f"  {len(unsigned)} of {len(rows)} approval(s) were written by an UNSIGNED commit.",
              "  This cannot be fixed after the fact: no check applied later turns an unsigned",
              "  commit into a signed one. Those approvals are re-made under signature or they",
              "  stay what they are.", ""]
    for r in rows:
        mark = "ok  " if r["authenticated"] else ("base" if _key(r) in known else "    ")
        where = f"{r['field']}={r['who']}" if r.get("field") else "(unreadable)"
        sha = (r.get("commit") or {}).get("sha") or ""
        # A SPACE AFTER THE MARKER. "base" is 4 characters and "ok " is padded to 4, so the
        # baselined rows rendered as 'base' + 'products/oncology/...' with no gap — the marker glued
        # to the path, which reads as a directory nobody has and hides the marker it was meant to show.
        L.append(f"  {mark:<5}{r['file']}  {where}")
        L.append(f"      {r['governs']} @ {sha[:12] or '—'} — {r['why']}")
    # THE FILES THAT EXIST AND ASSERT NOTHING. The unit here is the APPROVAL, so a governed file
    # naming nobody contributes no row — and would simply vanish from a report that only counts
    # approvals, which is the same absence-reads-as-clean failure this tool was written around. An
    # empty approver column is a decision register nobody has signed off, not a surface that does
    # not exist, and the two are different things to do something about.
    silent = sorted({rel for rel, _w, _f in approval_files(root)} - {r["file"] for r in rows})
    if silent:
        L += ["", f"  {len(silent)} governed file(s) exist and assert NO approval at all — every",
              "  approver field or column in them is empty. Not covered above, and not evidence:"]
        for rel in silent:
            L.append(f"      {rel}")
    # THE OTHER PEOPLE THESE FILES NAME. They performed real acts — specification QC, technical
    # review — and none of them is the approval. Listed so a reader is not left thinking the file
    # names one person, and listed APART so nothing here reads as authenticated.
    others = other_actors(root)
    if others:
        L += ["", f"  {len(others)} other recorded actor(s) — real acts, none of them the approval,",
              "  and no signature above authenticates any of them:"]
        for rel, field, who in others:
            L.append(f"      {rel}  {field}={who}")
    # THE SURFACES THAT MATCHED NOTHING, said out loud. Without this the count above reads as the
    # whole governed surface when most of it is simply not built yet, and "0 unauthenticated Gate 6
    # release approvals" would mean "no pack has ever released" while looking like "all clear".
    empty = [(p, w) for p, w, _f, files in surfaces(root) if not files]
    if empty:
        L += ["", f"  {len(empty)} of {len(APPROVAL_GLOBS)} governed surface(s) hold NO FILE. Nothing",
              "  above covers them, and nothing above is evidence about them either:"]
        for pattern, what in empty:
            L.append(f"      {pattern}")
            L.append(f"          {what} — no pack or work item has reached it")
    L += ["", "  " + IDENTITY_EVIDENCE_REQUIRED,
          "  A verified local signature is not authenticated person identity, scientific approval or release."]
    return "\n".join(L)


def baseline_growth(root=REPO, base_ref=None):
    """([identity added since `base_ref`], why-not-checked) — the baseline may SHRINK, never grow.

    THE EXEMPTION LIST WAS ITSELF EDITABLE BY THE CHANGE IT EXEMPTS. Keying each entry on the
    COMMIT already stops it becoming a permanent pass — re-make an approval and it drops back
    under `--check`. What nothing stopped was ADDING a row: the same pull request that writes an
    unauthenticated approval could baseline it, and every check here would go green.

    And a new row can never be legitimate on its own terms. The baseline records approvals that
    PREDATE the mechanism; the mechanism exists now, so anything appearing after it does not
    predate it. Removing rows is always fine: that is approvals being re-made under signature,
    which is the outcome the whole file is for.

    REPORTED AS UNCHECKED WHEN THE BASE CANNOT BE READ, never as a pass. A shallow clone, a
    detached build or a missing ref means this control did not run, and saying "no growth" then
    would be the absence-wearing-a-pass this repository refuses everywhere else.
    """
    import subprocess # noqa: PLC0415
    # AN EXPLICIT BASE BEATS A GUESS. CI knows the PR base SHA and can pass it; falling back to
    # origin/main is a convenience for a local run, not a control. `RWDP_BASE_REF` is read here
    # so a workflow can set it once rather than threading a flag through every call.
    base_ref = base_ref or os.environ.get("RWDP_BASE_REF") or ""
    refs = [base_ref.strip()] if base_ref.strip() else ["origin/main", "main"]
    for ref in refs:
        try:
            # FORWARD SLASHES: is built with os.path.join, and
            # takes a repository path, not a platform one. On Windows the backslash form
            # simply fails to resolve, so this control reported UNCHECKED on every run here.
            p = subprocess.run(["git", "show", ref + ":" + BASELINE.replace(os.sep, "/")],
                               cwd=root,
                               capture_output=True, text=True, encoding="utf-8",
                               errors="replace", timeout=60)
        except Exception: # noqa: BLE001
            continue
        if p.returncode != 0:
            continue
        try:
            import yaml # noqa: PLC0415
            was = yaml.safe_load(p.stdout) or {}
        except Exception as e: # noqa: BLE001
            return [], f"{ref}:{BASELINE} does not parse ({e})"
        before, _berrs = _baseline_from_doc(was)
        now, _errs = baseline(root)
        return [k for k in sorted(now) if k not in before], None
    return [], (f"no readable {BASELINE} at any of {refs} — this control did NOT run. It needs "
                f"the base branch; a shallow clone or a missing ref is enough to prevent it.")


def baseline_text(rows):
    """The TEXT of a baseline recording every unauthenticated approval that exists RIGHT NOW.

    RETURNS IT; NEVER WRITES IT, and that is not fastidiousness. This tool is what CI runs to judge
    approvals, and a judge that can write its own exemption list is a check that can green itself:
    one `--write-baseline` step in a workflow file and every unauthenticated approval in the
    repository is grandfathered forever, silently, with the job still passing. `--print-baseline`
    sends this to stdout and a PERSON redirects it, which is a visible act in a diff.

    Written once, at the moment the mechanism lands — everything already in the repository predates
    it, and no check applied afterwards turns an unsigned commit into a signed one. Every approval
    made after that is new work and is held to the mechanism.

    THIS RECORDS NO APPROVAL AND GRANTS NONE. Each entry says "this approval is unauthenticated and
    was made before the mechanism existed", which is the opposite of an approval, and every field
    in it is read out of git rather than typed by anyone.
    """
    lines = [
        "# APPROVALS THAT PREDATE THE IDENTITY MECHANISM — grandfathered, and nothing more.",
        "#",
        "# Every entry here is an approval NOBODY'S SIGNATURE SUPPORTS. This file does not approve,",
        "# authenticate or excuse any of them; it records that they were made before there was a",
        "# mechanism to bind them, so `--check` can fail on NEW unsupported approvals without going",
        "# red on all of history from its first commit — a check that did that would be switched off",
        "# the same day, and then nothing would be enforced at all.",
        "#",
        "# KEYED ON THE COMMIT, not on the file. Re-make one of these approvals and its identity",
        "# changes: it drops out of this list and back under the check. A baseline keyed on the file",
        "# would exempt every approval that file ever gains.",
        "#",
        "# GENERATED, from git, by:",
        "#     python3 platform/tools/approval_identity.py --print-baseline > "
        "governance/approval_baseline.yaml",
        "#",
        "# The tool PRINTS this and never writes it. A judge that could write its own exemption list",
        "# is a check that can green itself — one generate step in a workflow and every",
        "# unauthenticated approval is grandfathered forever with the job still passing. Redirecting",
        "# it is a person's act and shows up in a diff.",
        "#",
        "# Adding an entry by hand exempts a NEW approval from the only check that binds it to a",
        "# person. If you are about to do that, the approval needs a signature instead.",
        "baselined:",
    ]
    for r in sorted(rows, key=_key):
        f, field, who, sha = _key(r)
        if not sha:
            continue
        lines.append(f"  - {{ file: {f}, field: {field!r}, who: {who!r}, commit: {sha},")
        lines.append(f"      why: {r['why']!r} }}")
    return "\n".join(lines) + "\n"


def main(argv):
    ap = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    ap.add_argument("--check", action="store_true",
                    help="exit 1 on any NEW approval no signature supports, on a malformed signer "
                         "registry, and on a released refresh signed off by a function")
    ap.add_argument("--check-readiness", action="store_true",
                    help="also require at least one eligible registered key with current independent reviewer "
                         "enrollment; implies --check. This checks identity setup, not product or release approval")
    ap.add_argument("--base-ref", default=None,
                    help="the commit or ref the baseline must not have grown against. CI should pass the PR base SHA; without it the tool tries origin/main then main, and FAILS if neither resolves. Also read from RWDP_BASE_REF")
    ap.add_argument("--print-baseline", action="store_true",
                    help=f"print a {BASELINE} recording every unauthenticated approval that exists "
                         f"now as predating the mechanism. Redirect it yourself — this tool writes "
                         f"nothing, because a judge that could write its own exemption list is a "
                         f"check that can green itself")
    a = ap.parse_args(argv)
    doc, errs = registry()
    rows, _ = audit()
    if a.print_baseline:
        sys.stdout.write(baseline_text(rows))
        return 0
    print(render(rows, doc, errs))
    if not person_keys(doc):
        print("  NOT READY: no eligible reviewer keys are registered. An empty registry is valid scaffold "
              "structure; --check alone does not establish reviewer readiness. Use --check-readiness for "
              "identity setup before governed use.")
    if not (a.check or a.check_readiness):
        return 0
    # WHAT `--check` HOLDS. The registry must be well-formed and no key may be registered under an
    # attestation that cannot support an approval; a released refresh may not be signed off by a
    # function; and — the part this gained — NO NEW APPROVAL may exist that no signature supports.
    #
    # "New" means not in `governance/approval_baseline.yaml`, which is keyed on (file, field, who,
    # commit). Everything already here predates the mechanism and no check applied later turns an
    # unsigned commit into a signed one, so failing on all of it from the first commit would get
    # the check switched off the same day and enforce nothing. Failing on what is added AFTER is a
    # live rule about new work rather than a verdict on history — and because the key includes the
    # commit, re-making a baselined approval brings it back under the rule.
    known, base_errs = baseline()

    #...AND THE EXEMPTION LIST MAY SHRINK, NEVER GROW. This file already warns, in the header it
    # prints, that "adding an entry by hand exempts a NEW approval from the only check that binds
    # it to a person" — and nothing enforced it, so the same pull request that wrote an
    # unauthenticated approval could baseline it and every check here would go green. A new row
    # can never be legitimate on its own terms either: the baseline records approvals that
    # PREDATE the mechanism, and the mechanism exists now.
    #
    # Removing rows stays free. That is approvals being re-made under signature, which is the
    # outcome this whole file is for.
    grew, growth_unchecked = baseline_growth(base_ref=a.base_ref)
    base_errs += [
        f"{BASELINE}: {k[0]} ({k[1]}={k[2]} @ {k[3][:12]}) was ADDED to the baseline. The "
        f"baseline grandfathers approvals that predate this mechanism; an entry appearing now "
        f"exempts a NEW approval from the only check that binds it to a person. Sign the "
        f"approval instead."
        for k in grew]
    if growth_unchecked:
        # FAILS, RATHER THAN NOTING IT. A first version printed this to stderr and carried on,
        # which is the absence-wearing-a-pass this repository refuses everywhere else: the one
        # control standing between a self-granted exemption and a green check reported that it
        # had not run, and the check went green anyway. A shallow clone is enough to reach that
        # state, and a shallow clone is what CI does by default.
        base_errs.append(
            f"{BASELINE}: the shrink-only comparison did NOT run — {growth_unchecked} Pass the "
            f"base explicitly (RWDP_BASE_REF=<sha>, or --base-ref) and fetch enough history for "
            f"it to resolve. An unrun control is not a passed one.")

    bad = list(errs) + base_errs + sign_off_errors()
    # A SHALLOW CHECKOUT IS ITS OWN FAILURE, reported once. Left to fall through, it would print one
    # "not in the baseline" line per approval — a page of wrong diagnoses for one cause, and a
    # reader would go looking for approvals nobody had made.
    if any(r.get("shallow") for r in rows):
        bad.append(f"{SHALLOW_WHY}. {len(rows)} approval(s) could not be checked at all.")
        rows = []
    scope_unavailable = []
    for r in rows:
        if r["authenticated"] or _key(r) in known:
            continue
        if r.get("signature_verified") and r.get("identity_code") == "identity_scope_unavailable":
            scope_unavailable.append(r)
            continue
        where = f"{r['field']}={r['who']}" if r.get("field") else "(unreadable)"
        bad.append(f"{r['file']}: {where} — {r['why']}. This approval is not in {BASELINE}, so it "
                   f"was made after the mechanism existed and requires both its own verified signature "
                   f"and independent reviewer identity evidence.")
    ineligible = ineligible_keys(doc)
    for s in (doc.get("signers") or []):
        if isinstance(s, dict) and str(s.get("key_id")) in ineligible:
            bad.append(f"{REGISTRY}: {s.get('key_id')!r} is in `known_ineligible:` "
                       f"({ineligible[str(s.get('key_id'))]}) and may not appear in `signers:` "
                       f"under ANY attestation — relabelling a key does not change what it proves")
        if not isinstance(s, dict):
            bad.append(f"{REGISTRY}: a signer entry is not a mapping")
            continue
        if str(s.get("attests")) != PERSON_REVIEW:
            bad.append(f"{REGISTRY}: {s.get('key_id')!r} is registered `{s.get('attests')}` — only "
                       f"`{PERSON_REVIEW}` belongs in `signers:`; a forge or automation key goes in "
                       f"`known_ineligible:` so nobody registers it by mistake")
        for f in ("key_id", "identity", "registered_date", "registered_by"):
            if not str(s.get(f) or "").strip():
                bad.append(f"{REGISTRY}: a signer entry has no {f}")
    for e in bad:
        print(f"  FAIL {e}", file=sys.stderr)
    if scope_unavailable:
        print(f"  NOT CHECKED: independent enrollment is unavailable for {len(scope_unavailable)} "
              "verified signature(s) in this local scope. Approval and release remain blocked.", file=sys.stderr)
    readiness_failed = False
    if a.check_readiness:
        readiness = enrollment_readiness(doc)
        readiness_failed = not readiness["ready"]
        print("  " + ("NOT READY: " if readiness_failed else "REVIEWER SETUP READY: ") + readiness["why"],
              file=sys.stderr if readiness_failed else sys.stdout)
    return 1 if bad or readiness_failed else 2 if scope_unavailable else 0


if __name__ == "__main__":
    from rwd_tools.console import use_utf8
    use_utf8()
    sys.exit(main(sys.argv[1:]))
