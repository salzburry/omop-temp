#!/usr/bin/env python3
"""Discover products and report which gates apply to each.

    python platform/tools/product_gates.py --report

Packs are found by walking `products/` and `fixtures/`, never from a hand-kept list — a
new tumour or spec year is covered the moment its folder exists. Gate applicability comes
from each pack's own `handoff/MATURITY.yaml` declaration.

Listings CI loops over:
  --list-pipelines        packs with spec_pipeline/pipeline.conf (the drift check)
  --list-strict           packs claiming contract >= coverage_complete (Gate 2)
  --list-decisions        packs with handoff/DECISIONS.md
  --list-config-declared  packs declaring configuration >= draft (the contract-YAML
                          binding check; declares nothing about buildability)
  --list-tests            every products/**/handoff/tests/test_*.py
  --check-maturity        declared levels must be consistent and evidenced

stdlib + PyYAML.
"""
import argparse
import datetime
import glob
import hashlib
import copy
import hashlib
import os
import re
import sys
import json
from pathlib import PurePosixPath
from rwd_services import WorkflowIssue, finding, issue_of, issue_results


from rwd_tools.spec_extract import repo_root as checkout_root, repo_relative # noqa: E402
from rwd_tools.contract_lint import APPROVAL_DATE_COLUMNS, APPROVER_COLUMNS, OUTPUT_DECISIONS, cell, decision_rows, decision_status, has_register, open_decisions, register_errors, spec_rows, unverified_sources # noqa: E402

# The pack-relative ENVIRONMENT file, taken from the engine that reads it — never spelled twice. A
# second literal here would drift from `engine.config.PIPELINE`, and Gate 4 would start approving
# the very bytes this exists to exclude, silently.
from engine.config import (PIPELINE as _PIPELINE, # noqa: E402
                           delivery_bindings as _delivery_bindings,
                           delivery_keys as _delivery_keys,
                           merged_raw as _merged_raw)
ENVIRONMENT_YAML = f"config/{_PIPELINE}"

# ---------------------------------------------------------------------------------------------
# WORK KINDS — what a governed object IS, and therefore which gates it owes.
#
# The framework was built around ONE object: a tumour's spec version, which creates a table other
# people trust. Six gates is the right weight for that, and the wrong weight for everything else
# the group does. A one-off analysis over an already-released product creates NO new authority — it
# reads a table someone already signed for — so holding it to Gate 1 (register a source) is asking
# it to re-register a source that is already registered, and the predictable result is that nobody
# runs it through governance at all.
#
# THE RULE THIS ENCODES: gate weight follows the AUTHORITY CREATED, not the work done.
#
# product creates a table others trust -> all six gates
# request creates nothing new; it reads a release -> provenance only: WHICH release, and
# the release must actually be citable
# protocol creates scientific authority ABOVE products -> its own requirements + decisions, and
# provenance for the products it governs
#
# `provenance` is a real obligation, not an exemption: `source_manifest.citation_errors` refuses a
# citation of a pack that is not releasable, so the light path is light because it INHERITS an
# approval, and it is only light while that approval exists.
#
# Entries in `products/registry.yaml` under `tumors:` are products, always — that list predates this
# and is not disturbed. Other kinds live under `work:`, where `kind:` is required, so there is
# exactly one place to look per kind and no entry whose kind depends on a default.
GATES = ("source", "contract", "delivery", "configuration", "validation", "release", "provenance")
KINDS = ("product", "request", "protocol", "project")
KIND_GATES = {
    "product": ("source", "contract", "delivery", "configuration", "validation", "release"),
    "request": ("provenance",),
    "protocol": ("contract", "provenance"),
    # A PROJECT is the standing study/analysis workspace over an immutable product release - the
    # object a protocol runs INSIDE (probe wave 14's future separation: tumor -> product -> release ->
    # project -> run). It owes its own requirement/decision trail (contract) and must name the
    # release it consumes (provenance) - and because provenance flows through `releasable()`, a
    # project over an unapproved pack is refused exactly like a request would be. The run layer
    # (DAG, environment + code digests, run manifests, ACLs, schedules) is DELIBERATELY not here
    # yet: this entry gives the identity a name so study work stops squatting inside product
    # packs; the machinery lands when the first real project does.
    "project": ("contract", "provenance"),
}

CONTRACT_LEVELS = ["not_started", "draft", "coverage_complete", "approved"]
# Gate 4, not Gate 2. `coverage_complete` says every spec item is traced; it says nothing about whether
# the executable YAML has been authored. Binding a pack to its config the moment coverage completes
# would hold a new tumour to a scaffold it has not written yet — so the binder follows this instead.
CONFIG_LEVELS = ["not_started", "draft", "approved"]


def repo_root():
    """Resolve authoring data without making module imports perform an operation."""
    from rwd_services import workspace_root
    return str(workspace_root(__file__))


def maturity(product):
    """The pack's declared maturity on both axes — `contract` (Gate 2) and `configuration` (Gate 4) —
    defaulting each to the LOWEST level when unstated.

    Defaulting down is the only safe direction: an absent file must not grant a gate. It means an
    un-maturity-ed pack is simply not held to Gate 2 rather than being assumed complete.

    STRICT-PARSED, like every other governed record. A regex used to pull each key out of the raw
    text, so `contract: approved` twice in one file resolved by line order — an external review
    showed the same file reading `approved` one way up and `not_started` the other. `read_yaml`
    goes through the strict loader: a duplicate key is a refusal, and a file that does not parse
    is a refusal, never a default.

    The source document's own status is NOT here: it is a property of the source, recorded once on the
    material in `source_refs.yaml` and reported by Gate 1 (`source_manifest.py`). Restating it in this
    file would be a second copy of a fact, and a second copy is a thing that goes stale.
    """
    path = os.path.join(product, "handoff", "MATURITY.yaml")
    if not os.path.exists(path):
        return {"contract": "not_started", "configuration": "not_started", "declared": False}
    # IT REFUSES, IT DOES NOT EXIT. This called `sys.exit` on an unreadable or out-of-vocabulary
    # file, which is a reasonable thing for a CLI to do and a destructive thing for a LIBRARY to
    # do: `releasable()` reads maturity for every pack, and `deploy_tree.build()` calls
    # `releasable()` in a loop — so ONE malformed MATURITY.yaml killed the whole packaging run
    # before RELEASE_EVIDENCE.yaml was written. The verdict that pack could not be released was
    # exactly the thing the process died instead of recording.
    #
    # THE LEVELS RETURNED ARE THE LOWEST, and that is forced rather than chosen. Several callers do
    # `CONTRACT_LEVELS.index(m["contract"])`, so a novel sentinel like "unreadable" would raise
    # ValueError and merely move the crash. `not_started` is the one value that makes every
    # ordering comparison in this module block.
    #
    # AND UNPARSEABLE STILL IS NOT A DEFAULT, which is the property the old exit was protecting.
    # The reason travels on `unreadable`, `maturity_errors` turns it into a blocker, and
    # `releasable` therefore refuses the pack and RECORDS why. A file that cannot be read now
    # blocks strictly more than a file that says `not_started`, because the plain one raises no
    # error at all.
    def _refuse(why):
        return {"contract": "not_started", "configuration": "not_started", "declared": True,
                "unreadable": why}

    doc, err = read_yaml(path)
    if err:
        return _refuse(f"does not parse as a governed record ({err}) — a maturity that cannot be "
                       f"read is not a default, it is a refusal")
    con = str((doc or {}).get("contract") or "not_started")
    cfg = str((doc or {}).get("configuration") or "not_started")
    if con not in CONTRACT_LEVELS:
        return _refuse(f"contract '{con}' not in {CONTRACT_LEVELS}")
    if cfg not in CONFIG_LEVELS:
        return _refuse(f"configuration '{cfg}' not in {CONFIG_LEVELS}")
    return {"contract": con, "configuration": cfg, "declared": True}


CONTRACT_APPROVAL = "handoff/CONTRACT_APPROVAL.yaml"
CONFIGURATION_APPROVAL = "handoff/CONFIGURATION_APPROVAL.yaml"

# WHO SIGNED FOR WHAT THE VARIABLES MEAN. A separate form from Gate 4, not an extension of it, and
# the repository had already made the argument: `config/semantic.yaml` sits OUTSIDE
# `config_bundle_sha256` because the build never reads it, and `semantic_sha256` exists precisely
# because "a pack rebinding a variable and a UMLS release bump are not the same event to anybody".
# Folding the approval into the configuration form would contradict the distinction the digests
# exist to draw, and would ask a configuration approver — a data engineer — to sign for clinical
# meaning. Two questions, two signatures.
SEMANTIC_APPROVAL = "handoff/SEMANTIC_APPROVAL.yaml"
RELEASE_APPROVAL = "handoff/RELEASE_APPROVAL.yaml"


def read_yaml(path):
    """`(doc, error)` — the ONE reader of a governed YAML file, where a parse failure is a GATE
    RESULT rather than a traceback out of a gate.

    `except Exception`, deliberately, and that is the whole reason this is shared rather than written
    per caller: PyYAML resolves an ISO-shaped scalar to a `datetime.date` and raises a plain
    **ValueError** on an impossible one, so `approval_date: 2026-13-45` does NOT arrive as a
    `yaml.YAMLError`. Gate 1 and Gate 2 each had their own try/except getting that right by hand. The
    obvious tidy-up — narrowing one of them to `except yaml.YAMLError` — looks like an improvement,
    passes every test, and makes an impossible date crash that gate and only that gate.
    """
    try:
        from engine.strict_yaml import strict_load
        with open(path, "rb") as fh:
            raw = fh.read()
        # ONE PARSE PER CONTENT (2026-09-07): a single Flow evaluation loaded source_refs.yaml eleven
        # times and MATURITY.yaml six, and parsing was a third of a 24-second page. The cache is keyed
        # by the bytes themselves (a digest, not a timestamp), so an edit is a new entry the moment it
        # lands and a stale read is impossible; the caller gets its own copy, never the cached one.
        key = (os.path.realpath(path), len(raw), hashlib.sha1(raw).hexdigest())
        hit = _READ_CACHE.get(key)
        if hit is not None:
            return copy.deepcopy(hit[0]), hit[1]
        # STRICT: two `approved_by:` lines in one approval loaded last-wins — who signed vs who
        # appears to have signed. DuplicateKey subclasses yaml.YAMLError, so it lands in this
        # same except and comes back as the gate result it is.
        doc = strict_load(raw.decode("utf-8"))
    except Exception as e: # noqa: BLE001 — every parse failure is the same answer
        return None, str(e)
    if doc is None:
        return {}, None # an empty file is an empty mapping, not a defect here
    # A file that PARSES is not a file the gate can read. Every governed YAML in this repo is a
    # mapping, and `- approved_by\n- approval_date` is a perfectly valid YAML *list* — so it came
    # back error-free and the caller's `doc.get(field)` died with AttributeError, which is the exact
    # traceback-instead-of-a-gate-result this reader was written to stop. Catching the parse and not
    # the shape left the hole half-closed.
    if not isinstance(doc, dict):
        return None, (f"top level is a {type(doc).__name__}, not a mapping of field: value")
    if len(_READ_CACHE) > 512:
        _READ_CACHE.clear()
    _READ_CACHE[key] = (copy.deepcopy(doc), None)
    return doc, None


_READ_CACHE: dict = {}

def pack_yaml(product):
    """The executable YAML this pack's ACTIVE configuration composes — the config graph, not a
    directory listing.

    `config/data_product.yaml` names its own inputs (`variables:` is a list of paths, `codelists:` a
    name->path map), and those are the only files the build reads. Listing the directories instead
    swept in whatever else happened to be sitting there — an archived pack, a draft someone is still
    writing, a candidate variant kept for comparison — and bound it as though the build executed it.
    That is wrong in both directions: the binder demanded a contract record for a block nothing runs,
    and a file the config genuinely composes from somewhere other than these two folders was missed.

    A referenced file that does not exist is still RETURNED, not filtered out here: check() turns it
    into an error, because a config claiming an input the pack does not have is a defect in exactly
    the traceability this tool exists to prove.
    """
    cfg_rel = "config/data_product.yaml"
    cfg_path = os.path.join(product, cfg_rel)
    if not os.path.exists(cfg_path):
        return []
    doc, unreadable = read_yaml(cfg_path)
    if unreadable:
        return [] # config_errors() reports an unreadable config by name

    out = []
    for ref in doc.get("variables") or []:
        if isinstance(ref, str):
            out.append(ref)
    codelists = doc.get("codelists") or {}
    if isinstance(codelists, dict):
        out += [v for v in codelists.values() if isinstance(v, str)]
    elif isinstance(codelists, list):
        out += [v for v in codelists if isinstance(v, str)]

    # Normalise and de-duplicate while keeping the config's own order, then the config itself last —
    # its own blocks are governed too.
    seen, files = set(), []
    for rel in out:
        rel = rel.replace("\\", "/").lstrip("./")
        if rel not in seen:
            seen.add(rel)
            files.append(rel)
    files += [cfg_rel]
    #...and the ENVIRONMENT half, when the pack has split it out. It is part of the graph the build
    # READS — so it must deploy, and the binder must see it — but NOT part of what Gate 4 approves;
    # `config_bundle_sha256` drops it by name. One list, two questions, the same shape as
    # `registered_workbooks` vs `production_eligible_workbooks` in repo_hygiene.
    if os.path.exists(os.path.join(product, *ENVIRONMENT_YAML.split("/"))):
        files.append(ENVIRONMENT_YAML)
    return files


def scientific_yaml(product):
    """The config graph MINUS the environment file — what Gate 4 approves.

    Derived from `pack_yaml` by subtracting one named file, never by a second traversal: the two
    answers must not be able to disagree about which variables pack a config composes. `pack_yaml`
    stays the whole graph because the build reads all of it and the deployment must carry all of it.
    """
    return [rel for rel in pack_yaml(product) if rel != ENVIRONMENT_YAML]


def delivery_sha256(product):
    """GATE 3's subject: the configuration that decides WHICH TABLES AND COLUMNS get resolved.

    The root config's bytes, plus the delivery bindings — cut, source schema, delivery format —
    read through the ONE merge, wherever the pack states them.

    Gate 3 pinned `sha256(config/data_product.yaml)` alone, on the stated grounds that those "resolve
    TABLES, which only the root decides". That was true until `run:` moved to `config/pipeline.yaml`.
    `data_format` selects a `formats:` overlay carrying its own `sources` map and column renames;
    `source_schema` picks the delivered database; `refresh` picks the cut. After the split all three
    could change with the root byte-identical, so evidence measured on one delivery went on matching
    a build reading another.

    NOT `config_bundle_sha256`: a progression window in `variables/outcomes.yaml` is the SCIENCE,
    approved at Gate 4, and it resolves no table. Folding it in here would invalidate live source
    evidence on an edit that cannot change what the source check looked at — the same false
    invalidation the split was made to remove, pointed at the other gate.

    AS STATED, not as overridden. A runner passing `--cut`/`--schema` records what it actually used
    in `data_cut` and `schema_validation_cut`, which this gate already cross-checks; hashing the
    overrides too would make the profile's digest and the verdict's disagree by construction.
    """
    path = os.path.join(product, "config", "data_product.yaml")
    if not os.path.exists(path):
        return "none"
    h = hashlib.sha256()
    h.update(sha256(path).encode("utf-8"))
    for key, value in sorted(_delivery_bindings(_merged_raw(path)).items()):
        h.update(f"\n{key}={value}".encode("utf-8"))
    return h.hexdigest()


# The pack's semantic binding, by the ONE name semantic_binding.py uses. Not imported from there:
# product_gates is the gate module every runner already loads, and making it depend on a tool that
# reads a 6 MB terminology layer to answer "what is this file called" would be the wrong direction.
SEMANTIC_YAML = "config/semantic.yaml"


# EVERYTHING THE EXPORTED MEANING DEPENDS ON. Relative to the checkout root, except the pack's own
# binding which is relative to the pack. Order is fixed because it is hashed in order.
SEMANTIC_INPUTS = (
    # THE SWITCH IS AN INPUT. Turning the UMLS layer off changes what the export can say, and a
    # manifest that pinned the artifacts but not whether they were consulted would call two
    # materially different exports identical.
    "governance/reference/umls/LAYER.yaml",
    "governance/reference/umls/TERMINOLOGY.json",
    "governance/reference/umls/RELATIONS.json",
    "governance/reference/umls/LOCAL_RELATIONS.yaml",
    "governance/reference/mcode_stu4/DICTIONARY.json",
    "governance/reference/mcode_stu4/VALUE_SET_CODES.json",
    "governance/reference/mcode_stu4/DOMAIN_MAP.yaml",
    "governance/NAME_LIFECYCLE.yaml",
    "governance/EQUIVALENCE_RULINGS.yaml",
    "governance/NAMING_RULINGS.yaml",
    # THE IMPLEMENTATION IS AN INPUT TOO. The same bindings exported by a different exporter are a
    # different graph — this file decides which fields are emitted, how a fan-out family is
    # represented and whether a mapping states its status. A manifest that pinned only data would
    # call two materially different exports identical.

    # THE ONCOLOGY MODULE REGISTRY, because `config/semantic.yaml` can now bind a variable to a
    # registry concept as well as to a UMLS concept and a LOINC code. That binding means whatever
    # the registry says the slot means, so the registry is part of the exported meaning exactly as
    # the terminology layer is.
    #
    # THE CATALOGUE IS NOT A BYSTANDER. Its `broad` and `narrow` axes decide WHICH MODULES assemble
    # for a cancer, so re-declaring one swaps whole tiers of the template a binding resolves
    # against — the same class of change as a UMLS release bump, and invisible for the same reason
    # if it is not pinned here.
    "governance/reference/oncology_modules/CATALOGUE.yaml",
    #...and every module, as a tree. A per-file list would let a NEW module join the meaning
    # without joining the manifest; a tree digest moves when one is added, removed or edited.
    "governance/reference/oncology_modules/**",
    # The assembler, on the same reasoning as `semantic_export.py`: it decides which tiers a cancer
    # gets, so the same modules assembled differently are a different template.

    # THE VARIABLE INVENTORY, which every concept's definition, sources, citations and engine
    # surface are re-keyed from. `registry_enrich --check` compares the modules against it byte
    # for byte, so a change here changes what the registry MEANS — and therefore what a binding
    # to one of its slots means. It was not in the manifest at all.
    "governance/reference/variable_inventory/INVENTORY.yaml",
)


# THE SEMANTIC COMPILER, DERIVED RATHER THAN LISTED. The implementation is an input — the same
# bindings through a different exporter are a different graph — but naming the files by hand was
# already wrong: the list held `semantic_export.py` and `oncology_registry.py` and omitted
# `semantic_binding.py`, `mcode_domains.py`, `registry_schema.py` and everything those import. A
# hand-maintained list of a CODE dependency drifts the first time somebody adds an import, and it
# drifts silently, because nothing compares it against the imports that actually exist.
#
# So these are SEEDS and the closure is walked with `ast` — the same technique
# `deploy_tree.runtime_tools` uses to decide which tools production may see, and for the same
# reason: the module deciding what counts as an input must not execute the code it is deciding
# about.
SEMANTIC_COMPILER_SEEDS = ("semantic_export", "semantic_binding", "mcode_domains",
                           "oncology_registry", "registry_schema")


def semantic_compiler_closure(root=None):
    """[repo-relative path] — every tool module the semantic compiler transitively imports.

    SORTED, so the manifest is stable. DERIVED, so adding an import adds an input, and a module
    that stops being imported drops out and moves the digest — correct, because the compiler is
    then a different program.

    EMPTY WHERE THE TOOLS ARE NOT PRESENT, which is a deployed tree. There the manifest is not
    computed at all: `semantic_identity` reads the packaging-recorded value instead.
    """
    import ast # noqa: PLC0415
    root = root or checkout_root(__file__)
    tools = os.path.join(root, "platform", "tools")
    if not os.path.isdir(tools):
        return []

    # BOTH DIRECTORIES, because the compiler imports from both and this walked only one.
    # `known` was built from `platform/tools` alone and every import was filtered through it, so
    # `semantic_export`'s `from config import load_config` — which is `platform/engine/config.py`,
    # the module that decides what a pack's identity and spec version ARE — resolved to nothing
    # and left the closure. 25 modules were covered and NONE of the engine. A change to
    # `engine/config` or `engine/strict_yaml` could therefore alter how a binding is interpreted
    # without moving the semantic manifest digest, so an approval signed against the old reading
    # went on covering the new one.
    #
    # `platform/tools` wins a name collision, because that is the import path the compiler runs
    # under: `sys.path` puts tools first in every entry point here.
    where = {}
    for sub in ("engine", "tools"):
        d = os.path.join(root, "platform", sub)
        if not os.path.isdir(d):
            continue
        for f in sorted(os.listdir(d)):
            if f.endswith(".py"):
                where[f[:-3]] = f"platform/{sub}/{f}"
    known = set(where)

    def imports(mod):
        try:
            with open(os.path.join(root, where[mod]), encoding="utf-8") as fh:
                tree = ast.parse(fh.read())
        except (OSError, SyntaxError, KeyError):
            return set()
        out = set()
        for node in ast.walk(tree):
            if isinstance(node, ast.Import):
                out |= {a.name.split(".")[0] for a in node.names}
            elif isinstance(node, ast.ImportFrom) and node.module:
                # `from engine.config import...` names the PACKAGE first; the module it wants is
                # the last segment, and `from config import...` names it directly. Both spellings
                # occur in this repository and both must resolve to the same file.
                parts = node.module.split(".")
                out.add(parts[0])
                out.add(parts[-1])
        return out & known

    seen, stack = set(), [m for m in SEMANTIC_COMPILER_SEEDS if m in known]
    while stack:
        mod = stack.pop()
        if mod in seen:
            continue
        seen.add(mod)
        stack += sorted(imports(mod) - seen)
    return sorted(where[m] for m in seen)


# THE PACK'S OWN FILES that carry meaning, by the names their tools use. `semantic.yaml` states
# what a variable MEANS; `TEMPLATE_RULINGS.yaml` states which registry concept a person confirmed
# it realises. Both are pack-local, both are a person's act, and a release that recorded one
# without the other could ship a confirmed binding it had never noticed.
TEMPLATE_RULINGS_YAML = "handoff/TEMPLATE_RULINGS.yaml"

#...AND THE ADOPTION, WHICH WAS MISSING AND CHANGES THE EXPORT. `semantic_export` reads
# `handoff/TEMPLATE_ADOPTION.yaml` and publishes an `rwdp:adoptionDisposition` node per adopted
# template, plus `rwdp:adoptionDifferences` where a pack adapted or diverged. So editing that
# file changes the meaning a pack publishes — and it sat outside this manifest, which meant a
# pack could adopt a template, or swap which template it adopted, with its semantic identity
# byte-identical. An external audit found it.
#
# THIS DIGEST AND NOT `config_bundle_sha256`, deliberately, and the distinction is the one this
# file already draws twice. An adoption computes no value: no build reads it, no number moves.
# Folding it into the configuration digest would invalidate a standing Gate 4 science approval
# over an edit that cannot change a result — the false invalidation the environment-file split
# and the per-cancer module scoping both exist to prevent. It belongs exactly here, with the
# other two pack files that state meaning rather than compute it.
TEMPLATE_ADOPTION_YAML = "handoff/TEMPLATE_ADOPTION.yaml"


# WHERE THE SHARED LAYERS ARE READ FROM, overridable. The test proving that a signature does not
# outlive the layers it resolves against had one way to move a layer: append to the governed
# governance/reference/oncology_modules/core.yaml and restore it in a `finally`. An interrupted
# run left the module tree carrying a stray edit. Pointing this at a COPIED governance tree keeps
# the real digest computation - same inputs, same scoping, same absent-by-name rule - while the
# checkout is never written to. None means this file's own repository.
_MANIFEST_ROOT = None


def semantic_inputs_present(root=None):
    """Are the shared layers the semantic manifest hashes actually on disk?

    THE QUESTION A DEPLOYED TREE HAS TO ASK. `deploy_tree` deliberately omits the UMLS projections,
    the mCODE extract, the oncology modules and the variable inventory — they are reference
    material the runtime does not read, and some of it is licensed. So `semantic_manifest` computed
    INSIDE a deployed tree hashes almost every input as "absent" and returns a digest that is
    perfectly stable, entirely wrong, and indistinguishable from a real one.

    A digest over absences is not a weaker answer, it is a different one. This is how a caller
    knows which it would be getting.
    """
    root = root or _MANIFEST_ROOT or checkout_root(__file__)
    missing = []
    for rel in tuple(SEMANTIC_INPUTS) + tuple(semantic_compiler_closure(root)):
        path = os.path.join(root, *rel[:-3].split("/")) if rel.endswith("/**") else \
            os.path.join(root, *rel.split("/"))
        if not os.path.exists(path):
            missing.append(rel)
    return (not missing), missing


# THE UMLS PROJECTIONS, which are the only inputs the licence switch governs. `LAYER.yaml` is
# deliberately NOT here: it is the switch itself and must always be hashed.
_UMLS_PROJECTIONS = ("governance/reference/umls/TERMINOLOGY.json",
                    "governance/reference/umls/RELATIONS.json")


def _umls_on(root):
    """Whether the UMLS layer may be consulted in THIS tree. Absent policy means off."""
    try:
        from rwd_tools import umls_subset as us # noqa: PLC0415
        return bool(us.enabled(os.path.join(root, "governance", "reference", "umls",
                                            "LAYER.yaml")))
    except Exception: # noqa: BLE001
        return False # no reader means no declared permission


def semantic_manifest(product, root=None):
    """{input: sha256 or "absent"} — every artifact that can change what the export MEANS.

    WHY `semantic_sha256` IS NOT ENOUGH. That digest covers `config/semantic.yaml`, which is the
    pack's own binding and nothing else. But the meaning a pack publishes is assembled from the
    UMLS projections, the mCODE extract, the domain ruling, the local assertions and the naming and
    equivalence registers — and none of those live in the pack. Rebuild the terminology layer from
    a new UMLS release and every exported concept can move while `semantic_sha256` stays
    byte-identical. The release would record a semantic identity that had not noticed.

    THE PACK'S OWN THREE. `config/semantic.yaml` states what a variable means,
    `handoff/TEMPLATE_RULINGS.yaml` which registry concept a person confirmed it realises, and
    `handoff/TEMPLATE_ADOPTION.yaml` which released template it inherited that meaning from —
    the exporter reads all three. The adoption was missing until an audit pointed out that a
    pack could change what it adopted without its semantic identity moving at all.

    ABSENT IS RECORDED BY NAME, never skipped. A register that does not exist is a different
    configuration from one that exists and is empty, and hashing only what happens to be present
    would make those two collide. Same discipline as `config_bundle_sha256`.
    """
    root = root or _MANIFEST_ROOT or checkout_root(__file__)
    out = {}
    for rel in tuple(SEMANTIC_INPUTS) + tuple(semantic_compiler_closure(root)):
        if rel == ONCOLOGY_MODULES_TREE:
            # SCOPED TO THE MODULES THIS CANCER ACTUALLY ASSEMBLES, not the whole tree.
            #
            # A TREE DIGEST OVER EVERY MODULE MADE EVERY CANCER SHARE ONE FATE: drafting CLL's
            # indication overlay moved PROSTATE's semantic identity and invalidated a clinical
            # approval that nothing about the change could possibly have affected. This repository
            # already refuses that elsewhere in as many words — a semantic rebinding must not
            # invalidate the Gate 4 science approval, "the same false invalidation the
            # environment-file split was made to remove" — and with thirteen cancers registered
            # instead of two it stops being theoretical: every cancer onboarded invalidates every
            # other cancer's approvals.
            #
            # THE ARGUMENT FOR THE TREE STILL HOLDS AND IS STILL SATISFIED. It was there so that a
            # NEW module could not join the meaning without joining the manifest. It cannot: which
            # modules a cancer assembles is decided by CATALOGUE.yaml, which is hashed here in its
            # own right, and a module that appears where the catalogue already pointed moves this
            # digest by going from `absent` to a content hash.
            #
            # FALLS BACK TO THE WHOLE TREE when the pack states no governed cancer identity. Then
            # nothing here knows which modules apply, and over-invalidating is the safe error.
            out.update(_module_inputs(root, product))
            continue
        path = os.path.join(root, *rel.split("/"))
        # A PROJECTION NOBODY CONSULTED CANNOT MOVE WHAT A RUN MEANT. With the layer declared
        # OFF, the UMLS artifacts are not read by anything — `semantic_binding` opens zero of
        # them on every path — so hashing their CONTENT made a UMLS release bump invalidate a
        # clinical approval for a deployment that never had a licence to look. Same false
        # invalidation as the cross-cancer module digest, on the layer the whole switch exists
        # for.
        #
        # `LAYER.yaml` itself is NEVER folded in this way: it is the switch, and turning it on or
        # off must move the identity. Recorded as `not_consulted`, which is a third state beside
        # a digest and `absent`, so a reader can tell "not read" from "not there".
        if rel in _UMLS_PROJECTIONS and not _umls_on(root):
            out[rel] = "not_consulted"
            continue
        out[rel] = sha256(path) if os.path.exists(path) else "absent"
    for pack_rel in (SEMANTIC_YAML, TEMPLATE_RULINGS_YAML, TEMPLATE_ADOPTION_YAML):
        pack_path = os.path.join(product, *pack_rel.split("/"))
        out[pack_rel] = sha256(pack_path) if os.path.exists(pack_path) else "absent"
    return out


# THE DECLARED NAME OF THE MODULE TREE, so the scoping branch above and the input list below
# cannot drift apart by a typo.
ONCOLOGY_MODULES_TREE = "governance/reference/oncology_modules/**"


def _module_inputs(root, product):
    """{input: digest} for the oncology modules THIS pack's cancer assembles.

    READ FROM `root`, NOT FROM THE REGISTRY MODULE'S OWN LOCATION. A first version asked
    `oncology_registry.modules_for`, which resolves its module directory from where the TOOL
    lives — so a manifest computed against a COPIED tree (a test, a packaging run, a deployed
    tree) scoped itself using the modules of whatever checkout the code was imported from. The
    symptom: pointing a copy's catalogue at a new axis moved the digest, and the new module never
    joined the manifest, because the real checkout had no such file to find. `semantic_manifest`
    takes a `root` precisely so it can answer about a tree that is not this one.

    Each module is named individually, so a reader can see which tiers this cancer's meaning was
    built from, and ABSENT IS RECORDED BY NAME — a module the catalogue implies and disk lacks
    is a different configuration from one that exists and is empty.
    """
    cat_rel = "governance/reference/oncology_modules/CATALOGUE.yaml"
    base = "governance/reference/oncology_modules"
    try:
        from rwd_tools import template_reconcile as tr # noqa: PLC0415
        slug, _why = tr.pack_cancer(product)
        assert slug
        doc, err = read_yaml(os.path.join(root, *cat_rel.split("/")))
        assert not err
        entry = ((doc or {}).get("cancers") or {}).get(slug)
        assert entry
    except Exception: # noqa: BLE001
        # NO IDENTITY, NO SCOPING. Over-invalidating is the safe error, so a pack whose cancer
        # cannot be resolved against THIS root keeps the whole-tree digest it always had.
        return {ONCOLOGY_MODULES_TREE: _tree_sha256(
            os.path.join(root, *ONCOLOGY_MODULES_TREE[:-3].split("/")))}

    from rwd_tools import oncology_registry as registry
    rels = [f"{base}/{name.replace(':', '/')}.yaml"
            for name in registry.module_names(slug, entry)]

    out = {}
    for rel in rels:
        path = os.path.join(root, *rel.split("/"))
        out[rel] = sha256(path) if os.path.exists(path) else "absent"
    return out

def _tree_sha256(directory):
    """One digest over every file under `directory`, by path and content.

    BY PATH AND CONTENT, so a rename moves it. Hashing only bodies would call a module renamed from
    `axis/solid.yaml` to `indication/solid.yaml` the same configuration, and the tier a module sits
    in is exactly what decides which cancers receive it.
    """
    if not os.path.isdir(directory):
        return "absent"
    # SLICED, NOT `os.path.relpath`. That call RAISES when the two paths are on different Windows
    # drives, which is the ordinary case on a runner that checks out to D: and puts temporary
    # directories on C: — the same trap `spec_extract.repo_relative` exists for. Here the base is
    # always a prefix of the walk, so the slice is exact and cannot raise.
    h = hashlib.sha256()
    stem = os.path.abspath(directory).replace("\\", "/").rstrip("/") + "/"
    for base, dirs, files in os.walk(directory):
        dirs[:] = sorted(d for d in dirs if d != "__pycache__")
        for name in sorted(files):
            full = os.path.join(base, name)
            norm = os.path.abspath(full).replace("\\", "/")
            rel = norm[len(stem):] if norm.startswith(stem) else name
            h.update(f"{rel}={sha256(full)}\n".encode("utf-8"))
    return h.hexdigest()


def semantic_manifest_sha256(product, root=None):
    """One digest over the whole semantic dependency graph. See `semantic_manifest`.

    RECORDED BESIDE `semantic_sha256`, NOT INSTEAD OF IT. Two digests answer two questions: which
    binding this pack stated, and which shared layer it was resolved against. Folding them into one
    would tell a reader that the semantics changed without telling them WHICH half moved — and a
    pack rebinding a variable and a UMLS release bump are not the same event to anybody.
    """
    return semantic_manifest_digest(semantic_manifest(product, root))


def semantic_manifest_digest(manifest):
    """The digest of a manifest MAP ALREADY IN HAND, so the arithmetic has exactly one definition.

    SPLIT OUT SO A RELEASE CAN BE CHECKED WITHOUT RE-DERIVING ITS INPUTS. A template release
    records both the map and this digest over it, so a verifier in 2030 — with no working tree, no
    git and no UMLS licence — can still confirm the two agree. That is a NARROWER claim than
    "these were the real inputs", and the two must never be confused: this is ARITHMETIC, always
    checkable, while provenance is the separate question `template_promote._issuance_errors` asks
    against the issuance commit.

    The lesson `sha256` already carries, one level up: two copies of one definition on either side
    of a comparison agree until somebody teaches one of them something."""
    h = hashlib.sha256()
    for rel, digest in sorted(manifest.items()):
        h.update(f"{rel}={digest}\n".encode("utf-8"))
    return h.hexdigest()


def semantic_sha256(product):
    """The pack's SEMANTIC binding, as a digest. What the release says its variables MEAN.

    A THIRD QUESTION, SO A THIRD DIGEST. `config/semantic.yaml` names the concept set a pack is
    scoped to and binds its variables to UMLS concepts. Nothing in `pack_yaml`'s graph references
    it — the build does not read it, `semantic_export` does — so it sat outside both existing
    digests, and the concept set a released pack claimed could be rewritten with `config_bundle_
    sha256` and `delivery_sha256` both byte-identical. The exported graph, the RDF and every
    downstream consumer of the meaning would change; the release identity would not move at all.

    That is the same hole `config/source_adapters.yaml` had, closed the same way: recorded into the
    run's identity rather than folded into a digest that answers a different question.

    NOT INSIDE `config_bundle_sha256`. That digest is "every file the build actually executes", and
    Gate 4 approves it as the science. A semantic rebinding changes no computed value — folding it
    in would invalidate a standing configuration approval over an edit that cannot move a number,
    the same false invalidation the environment-file split was made to remove.

    NAME AS WELL AS BYTES, so an absent binding and an empty one are different answers, and "none"
    is a stated value rather than a missing key.
    """
    path = os.path.join(product, *SEMANTIC_YAML.split("/"))
    if not os.path.exists(path):
        return "none"
    h = hashlib.sha256()
    h.update(SEMANTIC_YAML.encode("utf-8") + b"\0")
    with open(path, "rb") as fh:
        h.update(fh.read())
    return h.hexdigest()


def config_bundle_sha256(product):
    """One digest over the WHOLE active configuration — every file the build actually executes.

    Gate 4 approves "this configuration correctly expresses that contract", and it pinned only
    `config/data_product.yaml`. But the root file mostly NAMES its inputs: the windows, tie-breaks,
    cohort rules and codelists live in `variables/*.yaml` and `codelists/*.yaml`. So editing a
    progression window inside `variables/outcomes.yaml` left the root byte-identical, the approval
    hash matching, the block names unchanged and the binder passing — and a formal approval standing
    over a configuration nobody re-read. That is the same "approved over what, exactly?" hole
    `approved_contract_sha256` closed at Gate 2, one gate later.

    Over the config GRAPH, not a directory walk — `pack_yaml` above is the one resolver, so an
    archived pack or a draft variant sitting in `variables/` cannot change what an approval covers.
    Relative NAME as well as bytes: renaming a variables file while keeping its content is a
    different configuration, and hashing contents alone would not see it. A referenced file that is
    missing is folded in by name, so a config claiming an input the pack lacks cannot hash equal to
    one that has it.

    `approved_config_sha256` (the root file alone) stays what Gate 3 verdicts and schema reports
    pin — those resolve TABLES, which only the root decides. Two questions, two digests.

    AND IT EXCLUDES THE ENVIRONMENT FILE. `config/pipeline.yaml` carries `run:` and `deliverables:` —
    which cut, which schemas, which table, how to write. None of that is a statement about what the
    product MEANS, and all of it changes per environment and per refresh. While it lived in
    `data_product.yaml` it was inside this digest, so pointing the job at a different output schema
    moved the hash and INVALIDATED an DataExpert approval of the science. Verified before the split:
    editing only `run.output_schema` took the digest from e60b75cd… to f194958d….

    A pack that has not split them yet keeps `run:` in the root file and so keeps the old behaviour —
    that is a reason to migrate it, not a reason for this function to guess which keys inside a file
    are environmental.
    """
    h = hashlib.sha256()
    for rel in scientific_yaml(product):
        h.update(rel.encode("utf-8") + b"\0")
        path = os.path.join(product, *rel.split("/"))
        if os.path.exists(path):
            with open(path, "rb") as fh:
                h.update(fh.read())
        else:
            h.update(b"<missing>")
        h.update(b"\0")
    return h.hexdigest()



# What each declared level OBLIGES the pack to have. A status claim must ACTIVATE its evidence:
# without this, deleting the contract or the config silently drops the pack out of --list-buildable
# instead of failing, so the way to turn a gate off is to remove the thing it checks.
MATURITY_REQUIRES = {
    ("contract", "coverage_complete"): ["spec_pipeline/pipeline.conf", "spec_pipeline/out/extracted.json",
                                        "spec_pipeline/out/COVERAGE.md", "handoff/FUNCTIONAL_CONTRACT.md"],
    ("configuration", "draft"): ["config/data_product.yaml", "handoff/FUNCTIONAL_CONTRACT.md"],
    # `contract: approved` is the Gate 2 sign-off — the claim that the REQUIREMENTS are settled, not
    # merely that every spec item is traced (that is coverage_complete). It obliged nothing, so the
    # strongest claim in the register was the only one carrying no evidence. Nobody has made it yet,
    # which is exactly when to require the record rather than after the first approval.
    # SPEC_QC_FINDINGS.md is REQUIRED, not merely read when present. DataExpert's independent
    # specification QC is a named Gate 2 deliverable, and spec_qc_errors() returns clean for an
    # absent file — so silence would otherwise be indistinguishable from "QC was done and found
    # nothing". An empty register saying so is a statement; no register is not.
    ("contract", "approved"): [CONTRACT_APPROVAL, "handoff/SPEC_QC_FINDINGS.md",
                               # I11 catches a DELETED register indirectly (a decision_required
                               # record would then cite nothing open), but a pack with no blocked
                               # records could drop it entirely and leave no audit trail of the
                               # questions that were asked and answered.
                               "handoff/DECISIONS.md"],
    # Gate 4 is, in WORKFLOW.md's own words, "a formal approval gate, not a formality": a human
    # decides that the configuration correctly expresses the approved requirement, and the exit is
    # "configuration formally approved and version-recorded". The machine side of that gate was well
    # covered — Gate 3 verdict evidence, live-schema reports, open output decisions — and the HUMAN
    # side obliged nothing at all. `configuration: approved` was a word in MATURITY.yaml, the same
    # gap `contract: approved` had before CONTRACT_APPROVAL.yaml, one gate further down.
    ("configuration", "approved"): [CONFIGURATION_APPROVAL, "config/data_product.yaml"],
}

# What that record must say. `approved_extraction_sha256` pins the approval to the extraction it was
# made against, the same way a Gate 3 verdict pins to `contract_sha256`: re-running the spec pipeline
# after a workbook revision must not leave an approval standing for requirements nobody re-read.
CONTRACT_APPROVAL_FIELDS = ("approved_by", "approval_date", "approved_extraction_sha256",
                            "approved_contract_sha256", "approved_coverage_sha256",
                            # The two registers the approval RESTS on. Both gates read them LIVE, so
                            # a new open finding or a reopened decision blocks straight away — but the
                            # other direction was open: after approval, editing a finding's Status to
                            # `waived`, or a decision's to RESOLVED, silences a blocker with nothing
                            # recording that the approved state was different. Same argument as
                            # approved_coverage_sha256, same loop.
                            "approved_decisions_sha256", "approved_spec_qc_sha256",
                            # Who performed the specification QC, and when. spec_qc_errors treats a
                            # header-only register as the statement "QC found nothing" — which is
                            # only true if somebody looked. Without this, that register is
                            # indistinguishable from a template copied and never used, and the
                            # difference decides a Gate 2 exit deliverable.
                            "spec_qc_reviewed_by", "spec_qc_review_date")
# Gate 4's equivalent. TWO names, because WORKFLOW.md's Gate 4 Actors line is two roles doing
# different things — "DataExpert authors and approves · Engineering technically reviews" — and a record carrying one
# name cannot say the second review happened. The scientific owner is deliberately NOT a field: they
# approve only methodology-sensitive rules, and a required field for a conditional actor is one people
# fill in with "n/a", which is how a form stops meaning anything.
# TWO NAMES AND TWO DIGESTS. `clinically_reviewed_by` is a distinct accountable act from
# `approved_by`: whether ECOG means UMLS C1520224 is a clinical judgement, and the person who
# assembles a binding is not automatically the person qualified to affirm it — the same two-role
# shape Gate 4 uses for its technical review.
#
# AND BOTH DIGESTS, because approving the binding without pinning the layer it resolves against
# would let a UMLS release bump silently change what was approved while the signature still stood.
# That is the whole reason `semantic_manifest_sha256` was recorded beside `semantic_sha256`.
SEMANTIC_APPROVAL_FIELDS = ("approved_by", "approval_date", "clinically_reviewed_by",
                            "approved_semantic_sha256", "approved_semantic_manifest_sha256")

CONFIGURATION_APPROVAL_FIELDS = ("approved_by", "approval_date", "technically_reviewed_by",
                                 # The WHOLE active configuration, not just the root file. The root
                                 # mostly names its inputs; the windows, tie-breaks and codelists it
                                 # composes are what a reviewer actually reads, and they could all
                                 # change with the root byte-identical and this approval still
                                 # standing. See config_bundle_sha256.
                                 "approved_configuration_bundle_sha256",
                                 "approved_against_contract_sha256")
# GATE 6, and the only approval that is about a RUN rather than about the pack. Gates 1-4 approve
# things that sit still — a specification, a contract, a configuration graph — so their approvals bind
# to file bytes. This one approves a CUT: these patients, these counts, this QC result. The same
# configuration over next month's delivery is a different product and must be approved again, which is
# why `approved_build_id` is a field and why nothing here is derivable from the checkout.
#
# WORKFLOW.md Gate 6 said a named final approval was required and the runner never asked for one: it
# confirmed Gates 1-4 through `releasable()`, built, ran QC, and swapped the public views. Sign-off
# was promoted to the ledger AFTERWARDS. So a person with production credentials could move the
# public product on a technically clean run that no accountable person had looked at.
#
# `validated_by` is Gate 5 and is a SEPARATE name from `approved_by` on purpose — WORKFLOW.md assigns
# validation to DataExpert and final approval to DataExpert plus the scientific owner, and a form carrying one name
# cannot say two people acted.
RELEASE_APPROVAL_FIELDS = ("approved_by", "approval_date", "validated_by", "validation_date",
                           # WHICH RUN. Not the pack, not the config — the build. An approval that
                           # named only the product would keep authorising every later refresh,
                           # which is the failure this whole form exists to stop.
                           "approved_build_id",
                           #...and what that run PRODUCED. The manifest carries the row counts, the
                           # QC verdict and the golden comparison; without pinning it, the approval
                           # says a build id and not what the approver saw.
                           "approved_manifest_sha256")
# One definition of "a real date", for every approval and review field in every gate. Without it each
# gate invented its own emptiness test and `review_date: yesterday`, `approval_date: TBD-later` and
# `July` all satisfied "not blank and not TODO" — an undated approval wearing a date.
ISO_DATE = re.compile(r"^\d{4}-\d{2}-\d{2}$")
# The person/placeholder rules moved to `person_rules` — stdlib-only, because `contract_scaffold`
# (a documented stdlib-only tool) needs `not_a_person` and importing this module dragged PyYAML
# into the spec pipeline's bootstrap path. Re-exported here so every existing importer keeps its
# path; the definitions have ONE owner, over there.
from rwd_tools.person_rules import NOT_A_PERSON, PLACEHOLDERS_EXACT, PLACEHOLDERS_PREFIX, marker_paths, not_a_person, unstated


def bad_date(value, future_ok=False):
    """None if `value` is a real ISO date, else why it is not. Bare `date.fromisoformat` would accept
    the shape but not tell the caller what is wrong with it.

    A DATE IN THE FUTURE IS REFUSED BY DEFAULT: every date this repository validates is an
    attestation — the day a person classified, approved, answered, pinned or reviewed something —
    and 2027-01-01 was accepted as all of those and then hash-bound into the append-only ledger
    (thirteenth pass, J1/J7). One day of slack covers a person east of the runner's clock. The one
    date that may lie ahead, a waiver's expiry, says so with `future_ok=True`.
    """
    if unstated(value):
        return "is not set"
    v = str(value).strip()
    if not ISO_DATE.match(v):
        # the rule in the person's words (walks UC1-21 and UC1-DATE, 2026-09-07); a page shows this line as it is
        return f"{v!r} must be written as YYYY-MM-DD, for example 2026-09-07"
    try:
        import datetime
        d = datetime.date.fromisoformat(v)
    except ValueError:
        return f"{v!r} is not a real calendar date"
    if not future_ok and d > datetime.date.today() + datetime.timedelta(days=1):
        return (f"{v!r} is in the future (today is {datetime.date.today().isoformat()}) — an attestation "
                f"is dated the day it was made")
    return None


SPEC_VERSION_RE = re.compile(r"^(20[0-9]{2})(0[1-9]|1[0-2])$")


def bad_spec_version(value):
    """None if `value` is a real YYYYMM cut, else why not. `^[0-9]{6}$` let 202613 through as a pack
    folder, a registry cut and a lineage row (thirteenth pass, J1/J2): CalVer has twelve months."""
    v = str(value or "").strip()
    if not re.fullmatch(r"[0-9]{6}", v):
        return f"spec-version {v!r} is not YYYYMM — a registration records WHICH cut governs"
    if not SPEC_VERSION_RE.match(v):
        return f"spec-version {v!r} is not a real YYYYMM: month {v[4:]} is not 01 to 12"
    return None


LINEAGE_STATUSES = ("active", "superseded", "draft")


def lineage_errors(entry):
    """[why] the registry entry's `lineage:` rows are not the closed vocabulary. `status: released`
    (a word nobody defined) was accepted everywhere and turned an unreleased cut into one a study
    could pin (thirteenth pass, J2): a word outside active | superseded | draft is refused, never
    read as the nearest one."""
    out = []
    slug = str((entry or {}).get("slug") or "?")
    for i, row in enumerate((entry or {}).get("lineage") or []):
        if not isinstance(row, dict):
            out.append(f"registry: {slug} lineage[{i}] is not a mapping"); continue
        st = str(row.get("status") or "")
        if st not in LINEAGE_STATUSES:
            out.append(f"registry: {slug} lineage {row.get('spec_version')}: status {st!r} is not one of "
                       f"{' | '.join(LINEAGE_STATUSES)} (governance/VERSIONING.md) — an unknown word is refused, "
                       f"never read as the nearest one")
        bad = bad_spec_version(row.get("spec_version"))
        if bad:
            out.append(f"registry: {slug} lineage[{i}]: {bad}")
    return out


VERDICTS = "handoff/SOURCE_VERDICTS.md"


def verdict_rel(member=None):
    """The pack-relative verdict report for a member (or the single-schema report).

    ONE definition of this name. source_check.py must carry reviewed acceptances forward from the
    same file Gate 4 will later read, and when the two disagreed a member's acceptances were read
    from the wrong file — so both sides now ask here.
    """
    return VERDICTS if not member else f"handoff/SOURCE_VERDICTS.{member}.md"


def union_members(product):
    """The member schemas a pack's config declares, or [] when it declares no union.

    Parsed as YAML, never pattern-matched. A `schema:\\s*(\\S+)` regex read the real endometrial
    config -- which writes its members as inline maps:

        members:
          - { schema: clnprw_flatiron_endo_use,        flag: EDM }

    -- as `clnprw_flatiron_endo_use,` WITH the comma, because `\\S+` does not stop at one. That
    member name then became the expected evidence filename (`SOURCE_VERDICTS.<name>,.md`) and the
    name Gate 4 compared against, while source_check.py -- which goes through the real config
    loader -- saw the name without the comma. The two halves of the union path disagreed about what
    a member is called. Quoted names, trailing comments and commented-out lines break a regex the
    same way; only a parser gets this right.

    The shape (`source_union.members[].schema`) is the one config.py exposes. Returns [] rather
    than raising for a pack whose config is absent or not yet valid YAML: this is the discovery
    layer and it must survive a half-authored pack.
    """
    path = os.path.join(product, "config", "data_product.yaml")
    if not os.path.exists(path):
        return []
    # Through read_yaml, which is the reason it exists. This caught `(yaml.YAMLError, OSError)` —
    # the precise narrowing read_yaml's docstring warns about — so `refresh: 2026-13-45` crashed it
    # with a bare ValueError from inside PyYAML's date constructor, and a list-rooted config died on
    # `.get`. Reached by both live-evidence runners and pack_run.targets(), so the crash surfaced
    # wherever a member was resolved.
    raw, unreadable = read_yaml(path)
    if unreadable:
        return [] # an unreadable config is reported by config_errors/Gate 4
    union = (raw or {}).get("source_union")
    if not isinstance(union, dict):
        return []
    out = []
    for m in union.get("members") or []:
        schema = m.get("schema") if isinstance(m, dict) else None
        if schema:
            out.append(str(schema).strip())
    return out


def verdict_paths(product):
    """[(member, relative path)] — the evidence a pack must produce.

    A union product reads every source from EVERY member schema, so one report cannot cover it. The
    profiler is run once per member (`DC_SCHEMA` is a per-run variable), which already yields one TSV
    per member; each becomes its own verdict report, and Gate 4 requires the full declared set.

    Nothing has to be created after the profiler runs — that is the constraint this design is built
    around. Which member a file came from is not a bare HUMAN claim; the TSV stamps
    `profile_schema` and `--complete` checks it against the pack's config, so the claim is
    corroborated — but one report still covers ONE member, which is what this resolves
    (`--union-member`, attested by `reviewed_by`). What the tool CAN prove is the mechanical failure
    that claim is exposed to: submitting the same file twice under two member names. Two reports
    quoting one `profile_sha256` is exactly that, and it is caught below.
    """
    members = union_members(product)
    if not members:
        return [(None, verdict_rel())]
    return [(m, verdict_rel(m)) for m in members]


@issue_results("source_verdict_required", gate=3)
def verdict_evidence_errors(rel, product, contract_md):
    """Gate 4 must check the EVIDENCE, not the words claiming it.

    `source_mapping: human_confirmed` / `live_schema_check: passed` / `data_profile_check: accepted`
    are three strings in a text file. Nothing stopped someone typing them, and Gate 4 read only them —
    so the gate that approves an implementation trusted a claim with no artifact behind it.

    The artifact already exists: the sanitized verdict report `source_check.py --out` writes, which
    carries the contract sha256 it judged. Requiring it at `configuration: approved`, and requiring
    that hash to still match, is what makes the status words answer to something. No new axis, no
    second source-mapping file — the report a person already reads becomes the record.
    """
    errors, seen_profiles, seen_schema_reports = [], {}, {}
    for member, relpath in verdict_paths(product):
        errors += _one_verdict(rel, product, contract_md, member, relpath,
                               seen_profiles, seen_schema_reports)
    # The same artifact submitted under two member names is the one failure a command-line label is
    # exposed to and the producing tool cannot prevent. Two reports quoting one checksum is it — and
    # it is as true of the schema report as of the profile.
    for label, seen in (("profile", seen_profiles), ("live-schema report", seen_schema_reports)):
        for digest, who in seen.items():
            if len(who) > 1:
                errors.append(f"{rel}: members {', '.join(who)} quote the SAME {label} "
                              f"({digest[:12]}…) — one file cannot be evidence for two schemas. Run "
                              f"it per member.")
    return errors


def _one_verdict(rel, product, contract_md, member, relpath, seen_profiles,
                 seen_schema_reports):
    path = os.path.join(product, *relpath.split("/"))
    if not os.path.exists(path):
        forwhom = f" for union member '{member}'" if member else ""
        arg = f" --union-member {member}" if member else ""
        return [f"{rel}: configuration:approved but no {relpath}{forwhom} — the status axes claim "
                f"Gate 3 evidence that no report attests. Write it with "
                f"`source_check.py {rel} --profile <cut>.tsv{arg} --complete --out {relpath}`."]
    with open(path, encoding="utf-8") as fh:
        verdict = fh.read()
    fm = {}
    m = re.match(r"---\n(.*?)\n---\n", verdict, re.DOTALL)
    if m:
        for line in m.group(1).splitlines():
            if ":" in line:
                k, v = line.split(":", 1)
                fm[k.strip()] = v.split("#")[0].strip()
    if not fm:
        return [f"{rel}: {relpath} has no machine-readable front matter — it was written by an "
                f"older source_check and cannot be checked. Re-run it."]
    if fm.get("profile_sha256") not in (None, "", "none"):
        seen_profiles.setdefault(fm["profile_sha256"], []).append(member or "(single schema)")

    errors = []
    # Checking only "a file exists carrying the right contract hash" let a SHAPE-ONLY report — no
    # profile read at all — satisfy the evidence requirement, as could a partial profile run without
    # --complete. Each field below is a way that report could fail to be evidence for this approval.
    # RECOMPUTE from the counters rather than trust the summary field. The report is deliberately
    # hand-edited to add the reviewer, so `gate3_result` is a line a person can touch; the counters
    # beside it are what it was computed from, and a mistaken edit must not hide them.
    FATAL_FIELDS = ("bad_shape", "not_a_column", "not_a_table", "unknown_source",
                    "absent_column", "absent_table", "unchecked", "ambiguous_source",
                    "derived_input_candidate")
    # `(fm.get(f) or "0")` read an ABSENT counter as zero, so a hand-edited or truncated front matter
    # that simply lacked `bad_shape` or `absent_column` passed as though those were clean. In an
    # approval gate a field that is not there is not a zero — it is an unanswered question.
    absent = [f for f in FATAL_FIELDS if f not in fm]
    unreadable = [f for f in FATAL_FIELDS if f in fm and not fm[f].isdigit()]
    nonzero = [f for f in FATAL_FIELDS if f in fm and fm[f].isdigit() and int(fm[f]) != 0]
    if absent:
        errors.append(f"{rel}: {relpath} does not state {', '.join(absent)} — a counter that is "
                      f"not there is an unanswered question, not a zero. Re-run source_check.")
    if unreadable:
        errors.append(f"{rel}: {relpath} counters {', '.join(unreadable)} are not whole numbers.")
    checks = [
        ("gate3_result", fm.get("gate3_result") == "passed" and not nonzero,
         (f"non-zero fatal counters ({', '.join(nonzero)}) whatever gate3_result says" if nonzero
          else f"the report's own result is '{fm.get('gate3_result')}'")),
        ("contract_sha256", fm.get("contract_sha256") == mapping_sha256(contract_md),
         "it judged a different version of the contract"),
        ("complete", fm.get("complete") == "true",
         "it was not a completeness run, so absence proved nothing in it"),
        ("profile_sha256", fm.get("profile_sha256") not in (None, "", "none"),
         "no profile was read — a contract-shape report is not vendor evidence"),
        ("unchecked", fm.get("unchecked") == "0", "mappings were never looked up"),
        ("ambiguous_source", fm.get("ambiguous_source") == "0",
         "columns could not be attributed to one source"),
        ("derived_input_candidate", fm.get("derived_input_candidate") == "0",
         "vendor inputs naming a dependency were never resolved"),
        ("reviewed_by", not unstated(fm.get("reviewed_by")),
         "no accountable human is recorded as having read it"),
        ("review_date", not bad_date(fm.get("review_date")),
         f"the review date {bad_date(fm.get('review_date'))} — nobody can tell which delivery it "
         f"was made against"),
    ]
    # A union product reads every source from EVERY member schema, so evidence for one member is not
    # evidence for the product. One report cannot cover them; each needs its own run and its own
    # accepted record. Whether this pack declares a union is already settled by the caller — it is
    # what produced `member` — so re-deriving it here read and regexed the config for a value
    # nothing ever looked at.
    if member:
        checks.append(("union_member", fm.get("union_member") == member,
                       f"this report is the evidence for member '{member}' but names "
                       f"'{fm.get('union_member')}'"))
    cfg_path = os.path.join(product, "config", "data_product.yaml")
    if os.path.exists(cfg_path):
        checks.append(("config_sha256", fm.get("config_sha256") == delivery_sha256(product),
                       "the configuration or its delivery bindings "
                       f"({', '.join(_delivery_keys(_merged_raw(cfg_path)))}) moved since the "
                       "verdict — it resolved a different set of tables or columns. Re-run "
                       "source_check."))
    if fm.get("config_refresh") not in (None, "", "none"):
        checks.append(("data_cut", fm.get("data_cut") == fm.get("config_refresh"),
                       f"profile cut {fm.get('data_cut')} is not the configured refresh "
                       f"{fm.get('config_refresh')}"))
    # LIVE-SCHEMA evidence, checked exactly as hard as the profile evidence beside it. Before this,
    # `live_schema_check: passed` was a status axis a person could write with nothing behind it: this
    # gate validated the value profile down to its individual counters and never once looked at the
    # schema report. The three fields come from source_check --schema-validation, which reads the
    # artifact run_product_schema_check.py writes.
    # The pack's own identity, for comparing against what the schema report says it measured.
    product_id = ""
    _cfg = os.path.join(product, "config", "data_product.yaml")
    if os.path.exists(_cfg):
        product_id = str((read_yaml(_cfg)[0] or {}).get("data_product_id") or "")
    sv_absent = [f for f in ("schema_validation_sha256", "schema_validation_result",
                             "schema_validation_cut", "schema_validation_product_id",
                             "schema_validation_schema",
                             "schema_validation_config_sha256") if f not in fm]
    if sv_absent:
        errors.append(f"{rel}: {relpath} does not state {', '.join(sv_absent)} — it was written "
                      f"before live-schema evidence was bound into this gate. Re-run source_check "
                      f"with --schema-validation <SCHEMA_VALIDATION_<cut>.json>.")
    else:
        arg = f" --union-member {member}" if member else ""
        checks += [
            ("schema_validation_sha256", fm.get("schema_validation_sha256") not in ("", "none"),
             "no live-schema report was supplied, so `live_schema_check` rests on nothing — "
             f"produce it with run_product_schema_check.py and re-run source_check{arg} "
             "--schema-validation <that .json>"),
            ("schema_validation_result", fm.get("schema_validation_result") == "passed_live",
             f"the live-schema report's own result is '{fm.get('schema_validation_result')}', "
             f"not passed_live"),
            ("schema_validation_cut", fm.get("schema_validation_cut") == fm.get("data_cut"),
             f"the live-schema report covers cut {fm.get('schema_validation_cut')} but the profile "
             f"is cut {fm.get('data_cut')} — two deliveries evidencing one approval"),
            # Same delivery is not the same SUBJECT. Without these, a passed report for another
            # product or another union member satisfies every check above.
            # "not stated" must not equal "matched". These tolerated `none`/blank, so a report with
            # no identity at all satisfied the identity check it exists to be.
            ("schema_validation_product_id",
             fm.get("schema_validation_product_id") not in (None, "", "none")
             and (not product_id or fm.get("schema_validation_product_id") == product_id),
             f"the live-schema report states product "
             f"'{fm.get('schema_validation_product_id')}', expected '{product_id or 'a product'}'"),
            # Compared against the schema the PROFILE says it covered, so this fires for a
            # single-schema pack too. The previous form compared to `member or fm["profile_schema"]`
            # — a front-matter field source_check never wrote — and then let `member is None` pass
            # anyway, so it could only ever bite on a union: the case a reader would assume was the
            # guarded one, with the ordinary one silently unguarded.
            ("schema_validation_schema",
             fm.get("schema_validation_schema") not in (None, "", "none")
             and fm.get("profile_schema") not in (None, "", "none")
             and fm.get("schema_validation_schema") == fm.get("profile_schema"),
             f"the live-schema report covers schema '{fm.get('schema_validation_schema')}' but the "
             f"profile covered '{fm.get('profile_schema')}' — two schemas evidencing one approval "
             f"(or one of them not stating which)"),
            # FRESHNESS. Same product/schema/cut is not the same CONFIG: a report produced before a
            # config change resolves different tables while all three labels stay put. The verdict
            # already pins config_sha256; the schema report must pin the same one.
            # Conditional on the pack HAVING a config, like the config_sha256 check itself: a pack
            # with none has nothing to pin, and demanding a hash of a file that does not exist would
            # block it on the absence rather than on any staleness.
            ("schema_validation_config_sha256",
             fm.get("config_sha256") in (None, "", "none")
             or (fm.get("schema_validation_config_sha256") not in (None, "", "none")
                 and fm.get("schema_validation_config_sha256") == fm.get("config_sha256")),
             f"the live-schema report was produced against config "
             f"{str(fm.get('schema_validation_config_sha256'))[:12]}… but this verdict is against "
             f"{str(fm.get('config_sha256'))[:12]}… — it resolved a different set of tables"),
        ]
        # One schema report cannot evidence two members, exactly as one profile cannot.
        if fm.get("schema_validation_sha256") not in (None, "", "none"):
            seen_schema_reports.setdefault(fm["schema_validation_sha256"], []).append(
                member or "(single schema)")
    for field, ok, why in checks:
        if not ok:
            errors.append(f"{rel}: {relpath} {field} — {why}.")
    return errors


# What makes a pack a PRODUCT rather than a copied template. `engine.validate` refuses each of these
# as a placeholder, so a config still carrying them is not executable YAML by anyone's definition.
IDENTITY_FIELDS = ("data_product_id", "vendor", "tumor_class")


def is_template_scaffold(product):
    """True while a pack's config is still the copied template rather than authored YAML.

    Judged on the pack's IDENTITY fields only — `data_product_id`, `vendor`, `tumor_class`. Those are
    what the template leaves as REPLACE_ME and what `engine.validate` refuses; a pack cannot be a
    product without them.

    NOT "the file contains REPLACE_ME anywhere": every real config here legitimately carries it in
    the deployment block (`refresh`, `source_schema`, `output_schema` are filled at run time, not in
    the repo), so that reading called all three live products scaffolds and would have switched the
    lint off entirely.
    """
    path = os.path.join(product, "config", "data_product.yaml")
    if not os.path.exists(path):
        return False
    with open(path, encoding="utf-8") as fh:
        text = fh.read()
    return any(re.search(rf"(?m)^{f}:\s*REPLACE_ME", text) for f in IDENTITY_FIELDS)


VENDOR_POLICY = os.path.join("governance", "vendor_policy.yaml")
SCHEMA_EVIDENCE = ("data_profile", "vendor_documentation")
PENDING_SCHEMA_EVIDENCE = "pending_review"  # an unanswered policy review, never an evidence route
#...and the subset a product can actually COMPLETE Gate 4 through today. `vendor_documentation` is a
# real route and the right one for a vendor whose delivered dictionary the sponsor may keep — but no
# evidence report exists for it. Gate 4 wants a `SOURCE_VERDICTS.md` carrying a profile digest,
# `complete: true`, the profile schema and its counters; `source_check` refuses a profile when the
# declared route is documentation, then writes `profile_sha256: none`, which Gate 4 rejects for a
# reason that has nothing to do with the actual situation.
#
# So the route stays DECLARABLE — the decision is worth recording before the tooling exists, and a
# vendor policy that could not express it would push every product back onto the profiler — and it is
# refused at the point of selection, with the gap named. A route that can be chosen and never
# completed is worse than one that says so.
IMPLEMENTED_EVIDENCE = ("data_profile",)


# A pack's ROLE is identity, not lifecycle. `status` says where a product stands on its way to
# release; `role` says whether the entry is a product AT ALL. The reference packs carried from
# development exercise every suite and walkthrough, and probe wave 11's finding was that nothing said
# so where it counts: the prostate fixture was `status: active`, held a generated Databricks job,
# and only the release gates' evidence stood between it and the public views. `fixture` is
# DECLARED, never inferred - a fixture gets no job, cannot be scheduled, and is never releasable
# HOWEVER much evidence it accumulates, because the refusal is by identity and no accumulation of
# signatures reaches it. A separate product is created under products/ with its own evidence;
# source_manifest also enforces the physical fixtures/ release boundary. Absent means product
# for the registry role alone, and never moves a pack across that physical boundary.
ROLES = ("product", "fixture")


def pack_role(entry):
    """(role, error) for a registry entry - a closed vocabulary, misspellings refused.

    Fail-closed the same way the runner treats `env`: "product" is the side that deploys, so an
    unrecognised word must not resolve there - it is an error, never read as the nearest one.
    `entry` may be None (an unregistered pack): that answers "product", because fixture-ness is a
    declaration and the missing-registration failure belongs to the checks that own it.
    """
    raw = str((entry or {}).get("role") or "product").strip().lower()
    if raw not in ROLES:
        return None, (f"role {raw!r} is not one of {'/'.join(ROLES)} - an unrecognised role is "
                      f"refused rather than read as the nearest one, because 'product' is the "
                      f"side that deploys")
    return raw, None


# A pack's MODALITY is the execution path its data takes, and it is identity like `role`: `ehr`
# is the ADS engine (Spark/R, the six-gate build this platform runs); `claims` is the cohortly
# bridge (Optum/MarketScan, executed by the cohortly R package, exported never built here). The
# two paths share every governance surface - registers, decisions, definitions, the advisory
# prior-ruling store (deliberately not named here: the guard forbidding a GATE from reading that
# store is a blunt substring scan over this file and cannot tell a comment from a call, and a
# blunt guard on that boundary is worth more than this sentence naming every item) - and
# share NO execution: an EHR pack through the claims exporter has no engine behind the output,
# and a claims pack through the ADS build would be columns the spec never meant. Absent means
# `ehr`, because every pack registered before the field existed is one.
MODALITIES = ("ehr", "claims")


def pack_modality(entry):
    """(modality, error) for a registry entry - a closed vocabulary, misspellings refused.

    Fail-closed like `pack_role`: the ADS engine is the side that deploys, so an unrecognised
    word must not resolve to `ehr` by proximity - it is an error, never read as the nearest one.
    `entry` may be None (an unregistered pack): that answers `ehr`, the field's default, and the
    missing-registration failure belongs to the checks that own it."""
    raw = str((entry or {}).get("modality") or "ehr").strip().lower()
    if raw not in MODALITIES:
        return None, (f"modality {raw!r} is not one of {'/'.join(MODALITIES)} - an unrecognised "
                      f"modality is refused rather than read as the nearest one, because the two "
                      f"paths share no execution and 'ehr' is the side the ADS engine builds")
    return raw, None


# A pack's TUMOUR KEY separates product identity from tumour identity (probe waves 18/19, the
# identity refactor): `slug` IS the product - unique, the folder, the job name, the artifact
# namespace, exactly what the audit called product_slug - and `tumour_key` says which tumour
# the product studies, DEFAULTING to the slug so every existing entry is untouched. Two
# products may share a tumour_key (dlbcl_cota_ehr + dlbcl_optum_claims, both tumour_key:
# dlbcl); they may never share a slug. Tumour-meaning consumers (the variable inventory
# overlay, coverage, templates) resolve through the key; product-meaning consumers (paths,
# jobs, citations, gates) keep resolving through the slug, unchanged.
def pack_tumour_key(entry):
    """(tumour_key, error) - declared or defaulted to the slug, grammar-checked either way.

    Fail-closed like role and modality: a key that cannot name an inventory overlay refuses
    rather than resolving to the nearest word."""
    import re as _re # noqa: PLC0415
    raw = str((entry or {}).get("tumour_key") or (entry or {}).get("slug") or "").strip()
    if not _re.match(r"^[a-z][a-z0-9_]{0,63}$", raw):
        return None, (f"tumour_key {raw!r} is not a usable tumour name "
                      f"([a-z][a-z0-9_]*, max 64) - it indexes the variable inventory and "
                      f"the template surfaces, and a name that cannot is refused")
    return raw, None


def tumour_key_known(root, key):
    """True/False whether `key` names a tumour the variable inventory carries, or None when
    the inventory cannot answer (unreadable/absent - its own checks report that). Probe wave 20:
    a syntactically valid `tumour_key: banana` indexed nothing and nothing said so; an
    EXPLICITLY declared key must point at a tumour the governed inventory knows."""
    inv, err = read_yaml(os.path.join(root, "governance", "reference",
                                      "variable_inventory", "INVENTORY.yaml"))
    if err or not isinstance(inv, dict) or not isinstance(inv.get("tumours"), dict):
        return None
    return str(key) in inv["tumours"]


def tumour_key_for(root, slug):
    """The REGISTRY-declared tumour key for a product slug, or None when no entry declares
    one - the single resolver tumour-meaning consumers consult FIRST, before the shared
    SLUG_TO_OVERLAY mapping and the slug-is-its-own-overlay fallback. One rung, one place,
    so the two-lists failure cannot restart here."""
    for base in ("products", FIXTURES_BASE):
        reg, err = read_yaml(os.path.join(root, base, "registry.yaml"))
        if err:
            continue
        for t_ in (reg or {}).get("tumors") or []:
            if isinstance(t_, dict) and str(t_.get("slug") or "") == str(slug):
                declared = str(t_.get("tumour_key") or "").strip()
                return declared or None
    return None


# The six product gate NAMES are shared across modalities - what changes is the EVIDENCE each
# name requires. Declared as data so the branch point exists before the first claims
# pack does, and so the fail-closed refusal in maturity_errors can name what WILL be required
# instead of just saying no. The ehr column is the live system; the claims column is the
# declared profile whose checkers land with the first registered claims pack (punch row 15) -
# and until they land, a claims pack cannot claim the axes whose checkers are absent, because
# passing an EHR-shaped check vacuously is exactly how a gate stops meaning anything.
MODALITY_GATE_EVIDENCE = {
    "source": {"ehr": "the workbook registered via source_manifest (shared)",
                      "claims": "the workbook registered via source_manifest (shared)"},
    "contract": {"ehr": "the functional contract + the decision register (shared)",
                      "claims": "the functional contract + the decision register (shared)"},
    "delivery": {"ehr": "vendor schema evidence per governance/vendor_policy.yaml",
                      "claims": "the claims cut named and pinned (db + data_refresh are run "
                                "facts the manifest deliberately leaves to the caller)"},
    "configuration": {"ehr": "executable pack YAML bound to the approved contract (Gate 4)",
                      "claims": "a committed bindings file validated against the workbook - "
                                "events, criteria, ignore_tabs (cohortly_export --bindings)"},
    "validation": {"ehr": "ADS QC + golden compare on the built table",
                      "claims": "an EXECUTED attrition/cohort output ingested as evidence "
                                "(cohortly_manifest.R returns exactly that pair)"},
    "release": {"ehr": "Gate 6: a named approval of the build + the immutable receipt",
                      "claims": "Gate 6: a named approval of the executed cohort + its receipt"},
}


def registry_entry(root, rel):
    """The registry entry for the PRODUCT that owns pack `rel` (repo-relative), or None.

    Matched on family/slug, deliberately NOT on `current_spec_version`. The vendor is a property of
    the product — who delivers its data, under what terms — and does not change when a new spec
    version lands, so a pack at a superseded or draft version has the same one. Matching the full
    resolved path answered None for every pack that was not the current version, which turned
    "which evidence does this owe" into "is this the current release", two different questions.
    """
    parts = rel.replace(os.sep, "/").strip("/").split("/")
    if len(parts) < 3 or parts[0] not in ("products", FIXTURES_BASE):
        return None
    # THE PACK'S OWN ROOT, not always products/: a fixture pack's registry rides beside it at
    # fixtures/registry.yaml, same schema, so vendor/role/evidence-route questions keep their
    # answers when a pack crosses the boundary - and the two registries can never claim one slug
    # for both a product and a fixture without the paths saying which is which.
    reg, err = read_yaml(os.path.join(root, parts[0], "registry.yaml"))
    if err:
        return None
    family, slug = parts[1], parts[2]
    for t_ in (reg.get("tumors") or []):
        if not isinstance(t_, dict):
            continue
        if str(t_.get("slug") or "") == slug and str(t_.get("family") or "oncology") == family:
            return t_
    return None


def evidence_route(root, rel):
    """(route, why) — which SCHEMA EVIDENCE this pack owes, or (None, why not) when nothing states it.

    The ONE answer to "does this product use the data profiler". It was never asked: the profiler was
    the only route the framework had, because the vendor it was built against does not permit holding
    the delivered documentation, and that constraint was absorbed as if it were universal. A vendor
    whose dictionary the sponsor may keep answers the column question by reading it, and profiling
    patient-level data to learn what a document already states is work nobody should do.

    FAILS CLOSED, and this is the point of declaring it at all: an unknown vendor, a missing policy
    file or an unrecognised route returns None with a reason, so "no profile attached" cannot be read
    as "this product does not need one". Unstated is unanswered here as everywhere else.

    Per-vendor by default and overridable per product — `evidence_route:` on the registry entry — for
    the case the policy cannot know: one delivery under different terms from the rest of its vendor's.
    """
    entry = registry_entry(root, rel)
    if entry is None:
        return None, (f"{rel} matches no current registry entry, so its vendor is unknown and no "
                      f"evidence route can be derived. Register the pack, or point the entry's "
                      f"current_spec_version at it.")
    vendor = str(entry.get("vendor") or "").strip()
    doc, err = read_yaml(os.path.join(root, VENDOR_POLICY))
    pol = ((doc.get("vendors") or {}).get(vendor) or {}) if not err and isinstance(doc.get("vendors"), dict) else {}
    if isinstance(pol, dict) and str(pol.get("schema_evidence") or "").strip() == PENDING_SCHEMA_EVIDENCE:
        return None, (f"vendor {vendor!r} is registered for draft claims authoring only; schema evidence "
                      f"is pending review in {VENDOR_POLICY}. Ask the source owner to review the intended "
                      "delivery terms and record its supported evidence route; a product override cannot "
                      "clear this pending vendor review. No documentation access, AI eligibility or "
                      "permission to profile the delivery is established by registration.")
    override = str(entry.get("evidence_route") or "").strip()
    if override:
        if override not in SCHEMA_EVIDENCE:
            return None, (f"registry: {entry.get('slug')} sets evidence_route {override!r}, which is "
                          f"not one of {', '.join(SCHEMA_EVIDENCE)}")
        return override, f"registry override on {entry.get('slug')}"
    if err:
        return None, (f"{VENDOR_POLICY}: {err} — the evidence route is declared there, and a policy "
                      f"that cannot be read has not been satisfied")
    route = str(pol.get("schema_evidence") or "").strip()
    if not vendor:
        return None, f"registry: {entry.get('slug')} declares no vendor"
    if not route:
        return None, (f"{VENDOR_POLICY} declares no schema_evidence for vendor {vendor!r}. Add it "
                      f"with a reason — which evidence answers 'does this column exist' under that "
                      f"vendor's delivery terms — rather than letting the absence default to one.")
    if route not in SCHEMA_EVIDENCE:
        return None, (f"{VENDOR_POLICY}: vendor {vendor!r} declares schema_evidence {route!r}, "
                      f"which is not one of {', '.join(SCHEMA_EVIDENCE)}")
    return route, f"vendor {vendor} ({VENDOR_POLICY})"


def uses_data_profiler(root, rel):
    """True only when this pack's declared route IS the profiler. Unknown route -> False, with the
    reason available from `evidence_route`: a tool must not profile patient-level data because nobody
    said not to."""
    return evidence_route(root, rel)[0] == "data_profile"


def unimplemented_route(root, rel):
    """A sentence when this pack's declared route has no evidence report yet, else None.

    Named separately from `evidence_route` because they answer different things: WHICH evidence this
    product owes, and whether the tooling can produce it. A caller that conflated them would either
    refuse a legitimate declaration or let a product sit at a gate it cannot reach with no explanation.
    """
    route, _why = evidence_route(root, rel)
    if route and route not in IMPLEMENTED_EVIDENCE:
        return (f"{rel}: this product's declared schema evidence is {route}, and no evidence report "
                f"exists for that route yet — Gate 4 reads a SOURCE_VERDICTS.md built from a profile, "
                f"and nothing writes the documentation-route equivalent. The declaration is correct "
                f"and the tooling is missing; implemented routes are {', '.join(IMPLEMENTED_EVIDENCE)}. "
                f"Until one exists this product cannot complete Gate 4, and pretending otherwise by "
                f"running the profiler would read delivered data its terms may not require.")
    return None


def vendor_policy_errors(root=None):
    """The policy file is well-formed and every registered vendor appears in it."""
    root = root or repo_root()
    path = os.path.join(root, VENDOR_POLICY)
    doc, err = read_yaml(path)
    if err:
        return [f"{VENDOR_POLICY}: {err}"]
    vendors = doc.get("vendors")
    if not isinstance(vendors, dict) or not vendors:
        return [f"{VENDOR_POLICY}: declares no `vendors:` mapping"]
    errors = []
    for name, pol in sorted(vendors.items()):
        if not isinstance(pol, dict):
            errors.append(f"{VENDOR_POLICY}: vendor {name!r} is not a mapping")
            continue
        route = str(pol.get("schema_evidence") or "").strip()
        if route not in (*SCHEMA_EVIDENCE, PENDING_SCHEMA_EVIDENCE):
            errors.append(f"{VENDOR_POLICY}: vendor {name!r} schema_evidence {route or '(unstated)'!r}"
                          f" is not one of {', '.join(SCHEMA_EVIDENCE)}")
        if route == PENDING_SCHEMA_EVIDENCE and pol.get("vendor_documentation") != "unknown":
            errors.append(f"{VENDOR_POLICY}: vendor {name!r} with pending schema-evidence review must "
                          "keep vendor_documentation unknown; registration cannot state unchecked delivery terms")
        # `unknown` is a legal ANSWER and the honest one until somebody reads the delivery terms —
        # what is refused is the field being absent. Recording a guess as `available` is how a licence
        # nobody checked becomes a permission somebody relies on.
        if str(pol.get("vendor_documentation") or "").strip() not in ("available", "not_available",
                                                                      "unknown"):
            errors.append(f"{VENDOR_POLICY}: vendor {name!r} must state vendor_documentation as "
                          f"available, not_available or unknown")
        # A route with no reason is a value somebody pasted in. Every other governed judgment in this
        # repo carries its rationale where the next person will read it.
        if unstated(pol.get("why")):
            errors.append(f"{VENDOR_POLICY}: vendor {name!r} states no `why` — the route is a "
                          f"judgment about delivery terms, and one nobody can question is one nobody "
                          f"can correct")
    # BOTH registries: a fixture entry's vendor still decides which schema evidence its pack
    # owes, so an unpolicied vendor is a finding on either side of the boundary
    for _base in ("products", "fixtures"):
      reg, err = read_yaml(os.path.join(root, _base, "registry.yaml"))
      if not err:
        for t_ in (reg.get("tumors") or []):
            if not isinstance(t_, dict):
                continue
            vendor = str(t_.get("vendor") or "").strip()
            if vendor and vendor not in vendors:
                errors.append(f"registry: {t_.get('slug')} is on vendor {vendor!r}, which "
                              f"{VENDOR_POLICY} says nothing about — so nothing decides whether that "
                              f"product owes a profile")
            elif isinstance(vendors.get(vendor), dict) and vendors[vendor].get("schema_evidence") == PENDING_SCHEMA_EVIDENCE:
                if t_.get("evidence_route"):
                    errors.append(f"registry: {t_.get('slug')} cannot override vendor {vendor!r}'s pending "
                                  "schema-evidence review; the source owner must resolve the vendor policy first")
                modality, bad = pack_modality(t_)
                if bad or modality != "claims" or t_.get("status") not in {"planned", "scaffold"}:
                    errors.append(f"registry: {t_.get('slug')} uses vendor {vendor!r} whose schema evidence "
                                  "is pending review; only planned or scaffold claims authoring is supported")
    return errors


def registry_errors(root=None):
    """An ACTIVE registry entry must name a pack that can actually be built.

    `current_spec_version` is what `engine.config.product_dir()` resolves for every default lookup, so
    an entry naming a folder without `config/data_product.yaml` does not fail once — it fails in every
    suite that loads the default product, and each failure names the missing CONFIG file rather than
    the registry line that caused it. Deleting a pack while the registry still called it current took
    10 of 20 platform suites down and read as ten unrelated defects.

    Checked here, against the registry's own CLAIM, so the message names the cause:
    a pack that is not yet buildable is `status: scaffold`, not `active`.
    """
    root = root or repo_root()
    reg, err = read_yaml(os.path.join(root, "products", "registry.yaml"))
    if err:
        return [f"products/registry.yaml: {err}"]
    errors = []
    for t_ in reg.get("tumors") or []:
        if isinstance(t_, dict):
            errors += lineage_errors(t_)
        if not isinstance(t_, dict) or t_.get("status") != "active":
            continue
        slug, ver = t_.get("slug"), str(t_.get("current_spec_version") or "")
        pack = os.path.join("products", t_.get("family", "oncology"), str(slug), ver)
        if not os.path.isdir(os.path.join(root, pack)):
            errors.append(f"registry: {slug} is status:active with current_spec_version {ver!r}, "
                          f"but {pack} does not exist. An entry is `active` only once its pack is "
                          f"buildable; until then it is `scaffold`.")
            continue
        for need in ("config/data_product.yaml", "source_refs.yaml", "handoff/MATURITY.yaml"):
            if not os.path.exists(os.path.join(root, pack, *need.split("/"))):
                errors.append(f"registry: {slug} is status:active on {ver}, but {pack}/{need} is "
                              f"missing — every default product lookup resolves through this pack, "
                              f"so it must be complete or the entry must be `scaffold`.")
    return errors


def safe_work_id(wid):
    """(ok, error) - ONE grammar for every work id, enforced centrally. An id
    becomes a filesystem path segment under work/: lowercase alnum start, then
    alnum/_/-, max 64 - no separators, no dots, no drive letters, no empties."""
    import re as _re # noqa: PLC0415
    if _re.match(r"^[a-z0-9][a-z0-9_-]{0,63}$", str(wid or "")):
        return True, None
    return False, (f"{wid!r} is not a safe work id ([a-z0-9][a-z0-9_-]*, max 64) - ids "
                   f"become filesystem paths under work/, and a name that can traverse is "
                   f"refused before it is used anywhere")


def gates_for(kind) -> tuple:
    """The gates a work object of `kind` owes. Unknown kind owes EVERYTHING.

    Fail-closed on the one axis where a default decides how much scrutiny something gets: a typo in
    `kind:` must not be the cheapest way to skip five gates. `work_errors` refuses the typo outright;
    this is the second answer, for any caller that reaches here without validating first.
    """
    return KIND_GATES.get(str(kind), KIND_GATES["product"])


def work_entries(root=None) -> list:
    """Every non-product work object: `work:` in products/registry.yaml, or [].

    Products are NOT here. They are `tumors:`, the list that predates work kinds, and reading them
    through one merged view would mean every caller had to remember which half it was holding.
    """
    root = root or repo_root()
    reg, err = read_yaml(os.path.join(root, "products", "registry.yaml"))
    if err:
        return []
    return [w for w in (reg.get("work") or []) if isinstance(w, dict)]


def kind_for(root, name) -> str | None:
    """The kind of the work object or product called `name` (its id or slug), or None.

    Checked against `tumors:` first, because a slug that names a product IS a product regardless of
    anything a `work:` entry claims — one name, one object.
    """
    root = root or repo_root()
    reg, err = read_yaml(os.path.join(root, "products", "registry.yaml"))
    if err:
        return None
    for t_ in (reg.get("tumors") or []):
        if isinstance(t_, dict) and str(t_.get("slug") or "") == str(name):
            return "product"
    for w in work_entries(root):
        if str(w.get("id") or "") == str(name):
            return str(w.get("kind") or "")
    return None


def work_errors(root=None) -> list:
    """The `work:` block's own shape: an id, a declared kind, and no name a product already owns."""
    root = root or repo_root()
    reg, err = read_yaml(os.path.join(root, "products", "registry.yaml"))
    if err:
        return [f"products/registry.yaml: {err}"]
    slugs = {str(t_.get("slug") or "") for t_ in (reg.get("tumors") or []) if isinstance(t_, dict)}
    errors, seen = [], set()
    for i, w in enumerate(reg.get("work") or []):
        where = f"registry work[{i}]"
        if not isinstance(w, dict):
            errors.append(f"{where}: not a mapping")
            continue
        wid = str(w.get("id") or "").strip()
        kind = str(w.get("kind") or "").strip()
        if not wid:
            errors.append(f"{where}: no id")
        elif not safe_work_id(wid)[0]:
            errors.append(f"{where}: {safe_work_id(wid)[1]}")
        elif wid in seen:
            errors.append(f"{where}: id {wid!r} is declared twice")
        elif wid in slugs:
            errors.append(f"{where}: id {wid!r} is already a tumour slug — one name, one object")
        else:
            seen.add(wid)
        if not kind:
            errors.append(f"{where}: no kind; one of {list(KINDS)}")
        elif kind not in KINDS:
            errors.append(f"{where}: kind {kind!r} is not one of {list(KINDS)}")
        elif kind == "product":
            errors.append(f"{where}: a product belongs in `tumors:`, not `work:` — that list owns "
                          f"the pack path, the vendor and the spec version this one cannot state")
        # A kind that owes provenance must SAY what it reads. An empty citation list is the state
        # this whole path exists to prevent: work that inherits an approval it never named.
        if kind in KINDS and "provenance" in gates_for(kind) and not (w.get("cites_release") or []):
            errors.append(f"{where}: kind {kind!r} owes provenance but cites no release — a "
                          f"`cites_release:` entry naming the product and spec_version it reads is "
                          f"what makes the light path an inheritance rather than an exemption")
    return errors

def _template_expectation(pack, rel):
    """Which oncology-template artefact this pack SHOULD carry, from what it declares.

    THE OTHER QUESTION, and the one a gate has to ask. Discovery by presence answers "what is
    here", which fails open in both directions: delete a pack's reconciliation and it drops out of
    the check instead of failing it, and a pack that should have one but never got one never
    appears at all. Measured on this repository, `prostate/202603` is in the oncology catalogue,
    has no contract, no seed and no reconciliation — and was invisible to every check.

    THE DECLARATION IS THE CATALOGUE PLUS THE CONTRACT FILE. A cancer the registry has no modules
    for cannot be reconciled against anything, so it expects NOTHING and says so rather than being
    quietly skipped — `oc/202606` has a full contract and is not in the catalogue, which is a fact
    about the registry's scope and worth reading. Of the cancers the registry does carry: one with
    a contract expects a reconciliation, one without expects a seed.
    """
    # ANCHORED ON `products`, not on a position. `rel` is `products/<area>/<tumour>/<version>`, and
    # counting from the front made the AREA look like the tumour — so every pack came back
    # out_of_scope and the list the gate iterates was empty, which is a fail-open that reads
    # exactly like "nothing to check".
    parts = rel.replace(chr(92), "/").strip("/").split("/")
    try:
        tumour = parts[parts.index("products") + 2]
    except (ValueError, IndexError):
        tumour = parts[-2] if len(parts) > 1 else ""
    # ONLY THE TUMOUR'S CURRENT SPEC VERSION IS IN SCOPE. The registry template is about a cancer
    # and the contract it has NOW; an earlier spec version is history, and demanding a seed for it
    # would duplicate the current version's reconciliation as noise. `prostate/202603` is the
    # superseded v1 pack.
    #
    # NAMED, NOT SKIPPED — that is the whole point of this function. `--list-template-superseded`
    # lists them, so a pack leaves the gate by being categorised rather than by disappearing.
    # `YYYYMM` IS A PLACEHOLDER, NOT A VERSION. A copied template scaffold sits beside real
    # spec versions under the same tumour, and `"YYYYMM" > "202608"` in a string sort - so the
    # day gist/202608 landed next to gist/YYYYMM, the REAL pack silently became "superseded by
    # the scaffold" and left the seed check. The scaffold never supersedes anything and is
    # never superseded by anything: it keeps its own expectation (a seed - it ships with one),
    # and only real versions compete for "current".
    siblings = sorted(d for d in os.listdir(os.path.dirname(pack))
                      if os.path.isdir(os.path.join(os.path.dirname(pack), d))
                      and d != "YYYYMM")
    if (os.path.basename(pack) != "YYYYMM"
            and siblings and os.path.basename(pack) != siblings[-1]):
        return "superseded"
    try:
        from rwd_tools import oncology_registry as reg # noqa: PLC0415
        known = set(reg.catalogue())
    except Exception: # noqa: BLE001
        return "unknown"
    if tumour not in known:
        return "out_of_scope"
    return ("reconciliation" if os.path.exists(os.path.join(pack, "handoff",
                                                            "FUNCTIONAL_CONTRACT.md"))
            else "seed")



@issue_results("contract_configuration_inconsistent", gate=4)
def claim_consistency_errors(rel, m):
    """The configuration claim against the contract claim — Gate 4's, by construction: a
    configuration cannot be drafted against a contract whose coverage is not complete, nor
    approved before the contract is. One owner, so the status page attributes it to Gate 4
    instead of holding Gate 1 with a claim nobody accounted for (the acceptance case found the
    demo pack held at Gate 1 by exactly this line)."""
    out = []
    if CONFIG_LEVELS.index(m["configuration"]) >= 1 and CONTRACT_LEVELS.index(m["contract"]) < 2:
        out.append(f"{rel}: configuration:{m['configuration']} but contract:{m['contract']} — the "
                   f"binding compares config against a contract whose coverage is not complete")
    if m["configuration"] == "approved" and m["contract"] != "approved":
        out.append(f"{rel}: configuration:approved but contract:{m['contract']} — Gate 4 cannot "
                   f"close before Gate 2")
    return out


@issue_results("source_evidence_required", gate=3)
def gate3_evidence_errors(p, rel, m):
    """Gate 3's evidence, demanded AT `configuration: approved`: every vendor-sourced record carries
    the four finer source axes at their evidenced values, and the verdict report that attests them
    still judges this contract and this delivery. ONE owner — `maturity_errors` folds it in and the
    status page attributes it — so the finding is never an unattributed blocker holding Gate 1."""
    if m["configuration"] != "approved":
        return []
    errors = []
    contract_md = os.path.join(p, "handoff", "FUNCTIONAL_CONTRACT.md")
    if os.path.exists(contract_md):
        with open(contract_md, encoding="utf-8") as fh:
            open_sources = unverified_sources(fh.read())
        if open_sources:
            from rwd_tools.contract_lint import source_readiness_issue
            shown = ", ".join(f"{v} ({why})" for v, why in open_sources[:3])
            more = f" and {len(open_sources) - 3} more" if len(open_sources) > 3 else ""
            errors.append(source_readiness_issue(open_sources,
                          f"{rel}: configuration:approved but {len(open_sources)} vendor-sourced "
                          f"record(s) have no Gate 3 evidence — {shown}{more}"))
        errors += verdict_evidence_errors(rel, p, contract_md)
    return errors


@issue_results("source_tolerances_required", gate=4)
def approval_tolerance_errors(root, rel, m):
    """GATE 4's OWN: the tolerances an ehr pack must have ruled before its configuration is approved.

    Split out of `maturity_errors` so status.gates can ask the owner: while these lived inline, the
    findings were UNATTRIBUTED there and held Gate 1 — a reviewer who raised `configuration:
    approved` was sent back to the approved inputs (the walkthrough, 2026-09-05).
    """
    p = os.path.join(root, rel)
    errors = []
    _entry = registry_entry(root, rel)
    _modality, _bad_mod = pack_modality(_entry)
    if _bad_mod:
        return errors
    # LINKAGE TOLERANCES ARE A GATE-4 PRECONDITION for an ehr pack: every
    # threshold defaults to None and the linkage gate is report-only until the pack RULES -
    # so a configuration approved with no ruling could release despite severe orphaning.
    # Approval of the config is the moment the pack must have stated its tolerance; the
    # NUMBERS stay the pack's own ruling, this only refuses their absence.
    if _modality == "ehr" and m.get("configuration") == "approved":
        cfgy, _cfg_err = read_yaml(os.path.join(p, "config", "data_product.yaml"))
        if isinstance(cfgy, dict): # an unreadable/missing config is already reported
            _st = (cfgy.get("qc") or {}).get("source_thresholds") or {}
            _thr = _st.get("linkage") or {}
            if not any(v is not None for v in _thr.values()):
                errors.append(
                    f"{rel}: configuration:approved but qc.source_thresholds.linkage rules "
                    f"NOTHING - with every threshold None the linkage gate is report-only, "
                    f"and a release could pass despite severe orphaning; Gate 4 approval "
                    f"requires the pack to declare at least one linkage tolerance it stands "
                    f"behind")
            #...and PARSE LOSS is held to the same standard (earlier review: a synthetic
            # probe with ~99% parse loss passed under the None default). The NUMBER stays
            # the pack's own ruling; only its absence at approval is refused.
            if _st.get("max_parse_loss_rate") is None:
                errors.append(
                    f"{rel}: configuration:approved but qc.source_thresholds."
                    f"max_parse_loss_rate is undeclared - parse loss is report-only until "
                    f"the pack rules, and an approved configuration must state the loss it "
                    f"stands behind")
            #...and a DECLARED value must be one that can gate (earlier review: a
            # string raised, NaN waved everything through, and a rate of 2 permitted total
            # loss). The runtime gates screen these too; approval is where a person is
            # looking, so it refuses first.
            from engine.linkage import DEFAULT_THRESHOLDS as _LD # noqa: PLC0415
            from engine.linkage import RATE_THRESHOLDS as _LR # noqa: PLC0415
            from engine.linkage import bad_threshold as _bt # noqa: PLC0415
            # THE SAME CLOSED VOCABULARY THE RUNTIME HOLDS: Gate 4
            # validated values but not keys, so `max_orhpan_rate` was approvable and only
            # failed at runtime — an approval is where a person is looking, so the typo
            # refuses here first, with the runtime's own key list, never a second one.
            for _k in sorted(set(_thr) - set(_LD)):
                errors.append(f"{rel}: configuration:approved but qc.source_thresholds."
                              f"linkage.{_k} is not a recognised threshold "
                              f"({', '.join(sorted(_LD))}) - a typo'd tolerance gates "
                              f"nothing while looking declared")
            for _k, _v in sorted(_thr.items()):
                if _k not in _LD:
                    continue
                _why = _bt(f"qc.source_thresholds.linkage.{_k}", _v, rate=_k in _LR)
                if _why:
                    errors.append(f"{rel}: configuration:approved but {_why}")
            _why = _bt("qc.source_thresholds.max_parse_loss_rate",
                       _st.get("max_parse_loss_rate"), rate=True)
            if _why:
                errors.append(f"{rel}: configuration:approved but {_why}")
    return errors


def required_evidence_errors(p, rel, m, axis=None):
    """The files a maturity claim OBLIGES (MATURITY_REQUIRES), missing — for one axis when asked.

    `axis` lets status.gates file each finding under the gate that owns the claim (contract ->
    Gate 2, configuration -> Gate 4) by asking here, never by reading the message. Inline in
    `maturity_errors` these were unattributed and held Gate 1 (the walkthrough, 2026-09-05).
    """
    errors = []
    for (_axis, level), needs in MATURITY_REQUIRES.items():
        if axis is not None and _axis != axis:
            continue
        levels = CONTRACT_LEVELS if _axis == "contract" else CONFIG_LEVELS
        if levels.index(m[_axis]) < levels.index(level):
            continue
        for rel_path in needs:
            if not os.path.exists(os.path.join(p, rel_path)):
                errors.append(finding("required_evidence_missing",
                              f"{rel}: {_axis}:{m[_axis]} requires {rel_path}, which is missing — a "
                              f"claim must not be switched off by deleting its evidence",
                              gate=2 if _axis == "contract" else 4, path=rel_path, axis=_axis))
    return errors


def maturity_errors(root, rel):
    """Inconsistent or unevidenced maturity claims for one pack."""
    p = os.path.join(root, rel)
    m = maturity(p)
    errors = []
    if m.get("unreadable"):
        # THE REFUSAL THE EXIT USED TO BE. Reported rather than raised, so the caller can record it
        # against the pack instead of the process ending mid-loop.
        errors.append(f"{rel}: handoff/MATURITY.yaml {m['unreadable']}")
    # A CLAIMS PACK IS NOT HELD TO EHR-SHAPED EVIDENCE - AND CANNOT PASS ON IT EITHER (audit
    # 15): `configuration` and `validation` mean executable ADS YAML and ADS QC here, words
    # that describe nothing a cohortly-executed product produces, so a claims pack could have
    # claimed those axes and been checked vacuously against the wrong evidence. Until the
    # claims checkers land (MODALITY_GATE_EVIDENCE declares what they will require), claiming
    # the axis is refused outright: fail closed, never vacuously green.
    _entry = registry_entry(root, rel)
    _modality, _bad_mod = pack_modality(_entry)
    if _bad_mod:
        errors.append(f"{rel}: {_bad_mod}")
    elif _modality == "claims" and m["configuration"] != "not_started":
        errors.append(f"{rel}: modality:claims claims configuration:{m['configuration']} - the "
                      f"claims configuration gate is a committed, validated bindings file and "
                      f"its checker does not exist yet; this axis cannot be claimed until it "
                      f"lands (MODALITY_GATE_EVIDENCE names each gate's claims evidence)")
    errors += approval_tolerance_errors(root, rel, m)
    # The axes are not independent: authoring executable YAML against a contract whose coverage is not
    # complete binds it to a moving target, and Gate 4 approval cannot precede Gate 2 approval.
    errors += claim_consistency_errors(rel, m)
    # Gate 3 before Gate 4. Approving the configuration while the vendor mapping is unchecked
    # approves an implementation of a mapping nobody verified. Read the status AXES, not the file
    # text: counting `source: unverified` missed the four finer axes entirely, and relabelling a
    # record `dictionary_only` would have satisfied it without any evidence changing hands.
    errors += gate3_evidence_errors(p, rel, m)
    errors += required_evidence_errors(p, rel, m)
    errors += contract_approval_errors(p, rel, m, root=root)
    errors += configuration_approval_errors(p, rel, m)
    errors += output_decision_errors(p, rel, m, root=root)
    return errors


@issue_results("output_decision_required", gate=4)
def output_decision_errors(p, rel, m, root=None):
    """OUTPUT-only decisions must close before `configuration: approved`.

    NAME-ALIGN / CODE-ALIGN ask whether the DELIVERED physical names match the published targets.
    That is not a question about what the requirement means, which is why Gate 2 lets them stay open
    — but it IS a question about the configuration, and nothing required them to close at the gate
    that governs it. `contract: approved` + NAME-ALIGN open + `configuration: approved` was reachable,
    which puts the decision at no gate at all.
    """
    if CONFIG_LEVELS.index(m["configuration"]) < CONFIG_LEVELS.index("approved"):
        return []
    still_open = [d for d in open_decisions(p) if d in OUTPUT_DECISIONS]
    errors = [f"{rel}: configuration:approved with output decision(s) {', '.join(still_open)} still "
            f"OPEN — these ask whether delivered names match the published targets, which is exactly "
            f"what approving the configuration asserts. Gate 2 lets them stay open; Gate 4 does not."] if still_open else []
    # Same-spelled outputs with different scientific fields need concept review;
    # the distinct-name rulings cannot answer this question by changing a label.
    from rwd_tools import concept_reuse  # noqa: PLC0415
    if root is None:
        root = os.path.abspath(p)
        for _part in rel.replace("\\", "/").strip("/").split("/"):
            root = os.path.dirname(root)
    try:
        errors += concept_reuse.physical_name_errors(rel, root)
    except (OSError, ValueError, TypeError, KeyError, AttributeError, RecursionError):
        errors.append(f"{rel}: the scientific naming review could not be read. Repair its contract or review evidence before configuration approval.")
    return errors


@issue_results("configuration_execution_incomplete", gate=4)
def configuration_execution_errors(p, rel):
    """An approval needs complete executable requirements, not only valid file links."""
    from rwd_services import WorkflowFinding, finding_message
    try:
        from rwd_tools import contract_binding
        errors, _stats = contract_binding.check(p, pack_yaml(p), require_complete=True)
    except Exception as error:  # noqa: BLE001 — an unavailable check cannot permit approval
        return [f"{rel}: configuration completeness could not be checked ({type(error).__name__}). "
                "Open Check the contract ↔ configuration binding to repair the inputs and run the complete check again."]
    return [finding_message(error if isinstance(error, WorkflowFinding) else
                            finding("configuration_execution_incomplete", error, gate=4),
            f"{rel}: {error} Review the named variable or publication list, then run "
            "Check the contract ↔ configuration binding again before approving configuration.")
            for error in errors]


@issue_results("configuration_review_required", gate=4)
def configuration_approval_errors(p, rel, m):
    """Gate 4 sign-off: `configuration: approved` must name the humans, the date, and both subjects.

    TWO hashes, because Gate 4 is a statement about a RELATIONSHIP: this configuration correctly
    expresses that contract. Pinning only the config would let the contract be revised and re-approved
    at Gate 2 underneath a Gate 4 approval nobody redid — and Gate 2 re-approving the requirements is
    not the same act as someone re-checking that the YAML still implements them.

    And the configuration hash is over the whole ACTIVE GRAPH, not the root file. The root mostly
    NAMES its inputs; the windows, tie-breaks, cohort rules and codelists a reviewer actually reads
    live in variables/*.yaml and codelists/*.yaml. Pinning only the root meant a progression window
    could be rewritten with the root byte-identical, the hash matching, the block names unchanged and
    the binder passing — a formal approval standing over a configuration nobody re-read.

    `sha256(config/data_product.yaml)` is still what Gate 3 verdicts and schema reports pin, and it
    stays theirs: those resolve TABLES, which only the root decides. Two questions, two digests, one
    graph resolver (`pack_yaml`) behind both.

    AND NOTHING IN THE GRAPH MAY STILL SAY `status: scaffold`. Every file the template ships carries
    that word, and it is the pack's own statement that the values in it were copied rather than
    chosen. They are not blanks — the template seeds age bands, an ECOG window, a BMI method, stage
    groupings, a death-conflict policy, `max_lines`, follow-up and visit-recency day counts — because
    a config full of REPLACE_ME cannot be linted or executed, so the shape has to be real. That makes
    them the most dangerous kind of default: plausible, tumour-specific requirements wearing the
    appearance of framework constants. They recur across tumours; recurrence is not universality.

    The digest above cannot catch this. It binds WHICH bytes were approved, not whether anyone looked
    at them, and a scaffold value hashes exactly as well as a confirmed one. `contract_binding` cannot
    either: it asks whether the config BLOCK is claimed by a contract record, never whether the number
    inside it is the one that record asked for. So the check is the word itself — the one place the
    pack already says "not mine yet". Moving it off `scaffold` is a two-second edit, which is the
    point: it costs nothing except having to be someone's deliberate act.
    """
    from rwd_services import WorkflowFinding, finding_message
    if CONFIG_LEVELS.index(m["configuration"]) < CONFIG_LEVELS.index("approved"):
        # A FORM BELOW ITS LEVEL IS STILL A CLAIM. Lowering `configuration` from approved to draft
        # in the same change that edits the graph left a CONFIGURATION_APPROVAL.yaml on disk whose
        # digests no longer name what is there, and nothing examined it (eleventh verdict, second
        # pass). Below `approved` the two digests are still compared — a matching form staged
        # before the level flips is legitimate and stays silent; a mismatching one is VOID.
        path = os.path.join(p, *CONFIGURATION_APPROVAL.split("/"))
        if not os.path.exists(path):
            return []
        void = approval_record_errors(
            p, rel, CONFIGURATION_APPROVAL, f"configuration:{m['configuration']}", (),
            ((("approved_configuration_bundle_sha256"),
              ("the active configuration graph", lambda: config_bundle_sha256(p)),
              "the configuration was edited after the approval"),
             ("approved_against_contract_sha256",
          ("the requirement content of handoff/FUNCTIONAL_CONTRACT.md",
           lambda: requirements_sha256(os.path.join(p, "handoff", "FUNCTIONAL_CONTRACT.md"))),
              "the contract moved after the approval, so nobody has confirmed the configuration "
              "still expresses it")),
            ())
        return [finding_message(e if isinstance(e, WorkflowFinding) else finding("configuration_review_required", e, gate=4),
                    f"{e} — at configuration:{m['configuration']} that approval is VOID: delete the "
                    f"form or re-approve the graph as it now stands") for e in void]
    execution = configuration_execution_errors(p, rel)
    unconfirmed = []
    for rel_in_pack in pack_yaml(p):
        full = rel_in_pack if os.path.isabs(rel_in_pack) else os.path.join(p, rel_in_pack)
        doc, err = read_yaml(full)
        if err or not isinstance(doc, dict):
            continue # the graph's readability is validate.py's question, not this one
        if str(doc.get("status", "")).strip() == "scaffold":
            unconfirmed.append(repo_relative(full, p))
    if unconfirmed:
        return execution + [finding("configuration_scaffold_remaining", f"{rel}: configuration:approved, but {f} still says `status: scaffold` — the values "
                f"in it are the template's examples until a person confirms them against the "
                f"contract. Set `status: active` in the same change that approves it.", gate=4, path=f)
                for f in sorted(unconfirmed)]
    # THE DEFINITIONS THIS APPROVAL RELEASES ARE NAMED (programme item 2). An approved
    # configuration signs an analytical definition per family (definition_signature); a released
    # definition nobody registered cannot be cited by a ruling, a binding or a second dataset, and
    # one the register has moved past is a meaning the product no longer claims. Advisory below
    # this level, refused here — the register is read beside the pack, never from the install root.
    from rwd_tools import definition_registry as _dr                                       # noqa: PLC0415
    _root = _dr.checkout_root(p)
    named = [finding_message(e, f"{e} — at configuration:approved every signed definition is registered")
             for e in _dr.pack_errors(p, _root, rel=rel)]
    # ...AND THE IMPLEMENTATION CLAIMS RESOLVE (programme item 3): a dataset that says which
    # definition it implements for a variable is held to the register, the contract and the
    # configuration it approves here; a claim that resolves to nothing binds nothing.
    named += [finding_message(e, f"{e} — at configuration:approved every implementation claim resolves")
              for e in _dr.implementation_errors(repo_relative(p, _root), _root)]
    return execution + named + approval_record_errors(
        p, rel, CONFIGURATION_APPROVAL, "configuration:approved", CONFIGURATION_APPROVAL_FIELDS,
        ((("approved_configuration_bundle_sha256"),
          ("the active configuration graph", lambda: config_bundle_sha256(p)),
          "the configuration was edited after the approval"),
         ("approved_against_contract_sha256",
          ("the requirement content of handoff/FUNCTIONAL_CONTRACT.md",
           lambda: requirements_sha256(os.path.join(p, "handoff", "FUNCTIONAL_CONTRACT.md"))),
          "the contract moved after the approval, so nobody has confirmed the configuration still "
          "expresses it")),
        ("approval_date",))


def semantic_approval_errors(p, rel=None):
    """Why this pack's SEMANTIC binding is not properly approved, or [].

    REQUIRED ONLY WHEN SOMETHING IS STATED. A pack that binds nothing needs no signature — that is
    the ordinary state today and saying so is different from failing. The moment a variable is bound
    to a concept, a lab code or a registry slot, somebody has claimed what this product MEANS, and
    an unsigned claim of meaning is the thing this form exists to refuse.

    IT PINS BOTH DIGESTS. `approved_semantic_sha256` binds the signature to the pack's own binding
    file; `approved_semantic_manifest_sha256` binds it to the shared layers that binding resolves
    against. Without the second, a UMLS release bump or a re-declared catalogue axis changes what
    the approved binding MEANS while the signature stands untouched — which is exactly the hole
    `semantic_manifest_sha256` was introduced to close, left open at the approval layer.
    """
    rel = rel or repo_relative(p, checkout_root(__file__))
    doc, err = read_yaml(os.path.join(p, *SEMANTIC_YAML.split("/")))
    if err or not doc:
        return [] # reported by semantic_binding, not here
    stated = []
    if str(doc.get("concept_set") or "").strip() and \
            not str(doc.get("concept_set")).upper().startswith("TODO"):
        stated.append("concept_set")
    for var, rec in sorted((doc.get("variables") or {}).items()):
        if not isinstance(rec, dict):
            continue
        for axis in ("concept", "lab", "registry_concept"):
            v = str(rec.get(axis) or "").strip()
            if v and not v.upper().startswith("TODO"):
                stated.append(f"{var}.{axis}")
    if not stated:
        return []

    path = os.path.join(p, *SEMANTIC_APPROVAL.split("/"))
    if not os.path.exists(path):
        return [f"{rel}: {len(stated)} semantic binding(s) are stated ({', '.join(stated[:4])}"
                f"{'...' if len(stated) > 4 else ''}) and {SEMANTIC_APPROVAL} does not exist — "
                f"somebody has claimed what this product MEANS and nobody has signed for it"]
    return approval_record_errors(
        p, rel, SEMANTIC_APPROVAL, "a stated semantic binding", SEMANTIC_APPROVAL_FIELDS,
        [("approved_semantic_sha256", (SEMANTIC_YAML, lambda: semantic_sha256(p)),
          "the pack's binding changed after it was approved"),
         ("approved_semantic_manifest_sha256",
          ("the semantic dependency manifest", lambda: semantic_manifest_sha256(p)),
          "the layers the binding resolves against changed after it was approved, so the same "
          "binding may now mean something else")],
        ("approval_date",))


def approval_record_errors(p, rel, form, claim, fields, hashed, dates):
    """The shape shared by every formal approval record: who, when, and over WHICH BYTES.

    Gate 2 and Gate 4 ask the same four questions of different files. Written twice they would agree
    today and diverge at the first fix applied to one — a date accepted at one gate and refused at the
    other, a hash compared at one and merely required at the other. The gates differ in WHAT they
    pin, so that is the argument; the reasoning about a placeholder, a mismatched hash and a date
    that is not a date lives here once.

      form    the approval file, pack-relative       claim   the maturity claim that demands it
      fields  every field that must be stated        dates   the subset that must be real dates
      hashed  (field, subject, what a mismatch MEANS) — the binding to what was approved. A
              `subject` is an absolute FILE PATH, or a (label, callable) pair when the subject is
              computed rather than read — Gate 4 approves the whole config GRAPH, which is a
              digest over several files and cannot be named by one path.
    """
    path = os.path.join(p, *form.split("/"))
    if not os.path.exists(path):
        return [] # already reported by the MATURITY_REQUIRES loop
    name = os.path.basename(form)
    doc, unreadable = read_yaml(path)
    if unreadable:
        return [f"{rel}: {form} is not readable YAML ({unreadable})"]
    errors = [f"{rel}: {claim} requires `{field}` in {form} — an approval with no accountable human, "
              f"date, or stated subject is not an approval record"
              for field in fields if unstated(doc.get(field))]
    #...and the approver is a PERSON. Stated in the schema, enforced nowhere, so `DataExpert` sat in every
    # `classified_by` in the repository; a form is exactly where the same value would land next.
    errors += [f"{rel}: {form} `{field}`: {not_a_person(doc.get(field))}"
               for field in fields if field.endswith("_by") and not_a_person(doc.get(field))]
    for field, subject, what in hashed:
        got = str(doc.get(field) or "").strip()
        if unstated(got):
            continue # already reported as an unstated field above
        if isinstance(subject, tuple):
            label, want = subject[0], subject[1]()
        elif os.path.exists(subject):
            # `repo_relative`, not `os.path.relpath`: this is a LABEL for an error message, and
            # `relpath` RAISES across Windows drives. A pack on D: checked from a tool on C: would
            # replace "the contract moved after the approval" with a ValueError traceback — the gate
            # crashing instead of reporting, on the path where it has something to say.
            label, want = repo_relative(subject, p), sha256(subject)
        else:
            continue # nothing on disk to compare against
        if got != want:
            errors.append(f"{rel}: {name} {field} is {got[:12]}… but {label} hashes to "
                          f"{want[:12]}… — {what}, so what is approved is not what is on disk")
    for field in dates:
        bad = bad_date(doc.get(field))
        if bad and not unstated(doc.get(field)):
            errors.append(f"{rel}: {name} {field} {bad}")
    return errors


def requirements_sha256(contract_md):
    """The digest a Gate 2 approval pins: every record's variable_id and REQUIREMENT_FIELDS (the
    partition contract_lint owns — required_rule, grain, anchor, window, record_selection,
    tie_break, derivation, cohort_applicability, missing, units), in table order. The status axes,
    the implementation references and the prose around the table are not in it: those move by the
    evidence tools' hand after the requirements are settled, and moving them is not a change to
    what was approved. Absent or unreadable contract: the digest of nothing, which never matches."""
    from rwd_tools import contract_lint as _cl                                             # noqa: PLC0415
    if not os.path.isfile(contract_md):
        return sha256_text("")
    try:
        text = _cl.read(contract_md)
    except Exception:                                                       # noqa: BLE001 — unreadable never matches
        return sha256_text("")
    parts = []
    for block in _cl.records(text):
        vid = _cl._scalar(block, "variable_id") or ""
        fields = [f"{k}: {_cl._scalar(block, k) or ''}" for k in sorted(_cl.REQUIREMENT_FIELDS)]
        parts.append(vid + "\n" + "\n".join(fields))
    return sha256_text("\n\n".join(parts))


def mapping_sha256(contract_md):
    """The digest a Gate 3 verdict report pins: every record's variable_id, its `source` cell (kind,
    logical table, physical stem, columns or inputs) and its `depends_on` list, in table order —
    what the source check JUDGED against the delivery. The requirement fields and the status axes
    are not in it: a window edited at Gate 2, or the evidence tools writing the finer source axes
    and Gate 5's validation, changes nothing the delivery was checked against. A record whose
    source cell moves is a different mapping, and the report is stale by name."""
    from rwd_tools import contract_lint as _cl                                             # noqa: PLC0415
    if not os.path.isfile(contract_md):
        return sha256_text("")
    try:
        text = _cl.read(contract_md)
    except Exception:                                                       # noqa: BLE001 — unreadable never matches
        return sha256_text("")
    parts = []
    for block in _cl.records(text):
        vid = _cl._scalar(block, "variable_id") or ""
        parts.append(vid + "\nsource: " + (_cl._inline(block, "source") or "").strip()
                     + "\ndepends_on: " + ", ".join(_cl._list(block, "depends_on") or []))
    return sha256_text("\n\n".join(parts))


def sha256_text(text):
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


@issue_results("contract_review_required", gate=2)
def contract_approval_errors(p, rel, m, root=None):
    """Gate 2 sign-off: `contract: approved` must name a human, a date, and what they approved.

    A pack can legitimately be `coverage_complete` — every spec item traced — with decisions still
    outstanding; that is prostate's current position, 21 open blocking 29 records. `approved` is the
    stronger claim that the REQUIREMENTS are settled, which WORKFLOW.md line 173 defines as every
    requirement approved OR EXPLICITLY BLOCKED BY A NAMED DECISION. What this function owns is the
    approval RECORD — who, when, and over which bytes. Whether the records themselves qualify is
    contract_lint's I11/I14; see the NOTE at the end.
    """
    # A named RESOLVED ruling already claims a scientific answer even before the
    # contract is approved. Every gate reader must see the canonical form/register
    # binding check, including a hand-written resolution with no ledger object.
    from rwd_tools import decision_record
    if root is None:
        if os.path.isabs(rel):
            root = checkout_root(p) or os.path.dirname(os.path.abspath(p))
        else:
            root = os.path.abspath(p)
            for _part in rel.replace("\\", "/").strip("/").split("/"):
                root = os.path.dirname(root)
    bindings = [finding("requirement_decision_required", f"{rel}: decision binding: {error}", gate=2) for error in
                decision_record.check_bindings(repo_relative(os.path.abspath(p), root), root=root)]
    if CONTRACT_LEVELS.index(m["contract"]) < CONTRACT_LEVELS.index("approved"):
        return bindings
    # What the approval is bound TO. The extraction hash protects against the SOURCE moving under an
    # approval; it says nothing about the contract, so editing a derivation, window, tie-break or
    # missing rule inside FUNCTIONAL_CONTRACT.md left the approval standing over requirements nobody
    # re-read. Each target below is a file that can move while every other one stays byte-identical.
    # THE CONTRACT DIGEST IS OVER THE REQUIREMENT CONTENT, not the file. The whole-file digest voided
    # this approval the moment Gate 3 applied its verdicts or Gate 5 recorded validation — writes to
    # the STATUS axes by the evidence tools, not to any requirement — and the flow sent the person
    # back to re-sign requirements nobody had changed (the acceptance case found it). What the
    # approver signed is each record's requirement fields, in contract_lint's own partition; a
    # derivation, window, tie-break or missing rule edited after the approval still voids it.
    errors = approval_record_errors(
        p, rel, CONTRACT_APPROVAL, "contract:approved", CONTRACT_APPROVAL_FIELDS,
        (("approved_extraction_sha256", os.path.join(p, "spec_pipeline", "out", "extracted.json"),
          "the spec was re-extracted after the approval"),
         ("approved_contract_sha256",
          ("the requirement content of handoff/FUNCTIONAL_CONTRACT.md",
           lambda: requirements_sha256(os.path.join(p, "handoff", "FUNCTIONAL_CONTRACT.md"))),
          "the contract's requirements were edited after the approval"),
         # COVERAGE.md is the row-by-row traceability artifact. A disposition can change there while
         # the extraction and the contract both stay byte-identical.
         ("approved_coverage_sha256", os.path.join(p, "spec_pipeline", "out", "COVERAGE.md"),
          "the coverage report changed after the approval"),
         ("approved_decisions_sha256", os.path.join(p, "handoff", "DECISIONS.md"),
          "the decision register changed after the approval"),
         ("approved_spec_qc_sha256", os.path.join(p, *SPEC_QC.split("/")),
          "the specification-QC register changed after the approval")),
        ("approval_date", "spec_qc_review_date"))

    errors += bindings
    errors += spec_qc_errors(p, rel)
    errors += [finding("requirement_decision_required", error, gate=2)
               for error in unaccountable_resolutions(p, rel)]
    # NOTE: open requirement-level decisions are deliberately NOT blocked here. WORKFLOW.md's Gate 2
    # exit is "every requirement approved OR EXPLICITLY BLOCKED BY A NAMED DECISION", and contract_lint
    # implements exactly that: I11 makes a record `decision_required` if and only if it cites an OPEN
    # requirement-level decision, and I14 refuses `contract: approved` while any record is still being
    # written. Blocking every open decision here contradicted both — a pack with a legitimate blocked
    # record could never be approved — and duplicated a policy that already has an owner. One rule,
    # in the module that owns the records.
    return errors


def unaccountable_resolutions(p, rel, by_decision=False):
    """Why `contract: approved` is refused: a RESOLVED decision that names nobody, or no date.

    THE ONE APPROVAL IN THE FRAMEWORK THAT BOUND TO NOTHING. Gate 1 names a classifier and a date,
    Gate 2 and Gate 4 name an approver and a reviewer, Gate 6 names an approver and a validator — and
    a decision, which is where the SCIENTIFIC judgment actually happens, recorded an answer and a
    status and no person at all. `Owner` does not close that: it says who the question was put to
    while it was open, and it does not change when somebody replies.

    It is weakest exactly where the process is most human. A decision packet goes to a methodology
    owner; the answer comes back by mail or in a meeting; an analyst types it into the register.
    Nothing recorded which of several people in that thread actually decided, or when. The approval
    form hashes the whole register, so a LATER edit is caught — but a hash over an unattributed answer
    only freezes it.

    AT `approved`, NOT IN THE STRUCTURAL LINT. Three RESOLVED decisions exist across the repository
    and none names an approver, so linting this everywhere would turn three packs red over a field
    that cannot be filled in by anyone here — inventing an approver is the exact act this framework
    forbids a tool. `approved` is where the pack asserts the requirements are settled, and that is the
    claim an unattributed answer contradicts. `dry_run.py` surfaces it before anyone attempts the
    approval.

    ABSENT COLUMN AND BLANK CELL ARE REPORTED DIFFERENTLY, because they are different repairs: a
    register with no such column needs its header extended, a blank cell needs one answer filled in.
    `cell(..., default=None)` is what tells them apart, and calling both "missing" would send someone
    editing rows in a table with nowhere to put the value.

    WITHDRAWN and SUPERSEDED are out of scope. Neither asserts an answer — one says the question went
    away, the other that a different row now governs — so demanding an approver would be demanding a
    signature on a retraction.
    """
    path = os.path.join(p, "handoff", "DECISIONS.md")
    if not os.path.exists(path):
        return []
    with open(path, encoding="utf-8") as fh:
        text = fh.read()
    # GROUPED BY DECISION, flattened on the way out. One unattributed resolution produces up to
    # TWO findings - a missing approver AND a missing date are different repairs and both are
    # worth saying - so a caller counting the returned LIST was reporting twice as many
    # unattributed decisions as exist. `by_decision=True` gives {id: [finding]} for callers that
    # want the count of DECISIONS; the flat list is unchanged for everyone else.
    per = {}
    # the CANONICAL status, through the same normaliser every other status reader uses —
    # `**RESOLVED**` (registers bold their statuses) compared raw is != "RESOLVED", so a
    # markdown-decorated resolution silently escaped the attribution requirement entirely
    statuses = decision_status(text)
    for did, row in sorted(decision_rows(text).items()):
        if statuses.get(did) != "RESOLVED":
            continue
        for what, names in (("approver", APPROVER_COLUMNS), ("approval date", APPROVAL_DATE_COLUMNS)):
            got = cell(row, *names, default=None)
            # BOUND LAZILY: `per.setdefault(did, []).append` created the decision's entry before
            # any finding, so a fully signed row counted as "RESOLVED with nobody behind it"
            # (eleventh verdict, second pass — the count and the verdict contradicted each other)
            _add = lambda m, _did=did: per.setdefault(_did, []).append(m)   # noqa: E731
            if got is None:
                _add(f"{rel}: decision {did} is RESOLVED but the register has no `{names[0]}` "
                           f"column — an answered question with no recorded {what}. Add it to the "
                           f"header (accepted spellings: {', '.join(names)}).")
            elif not got.strip() or unstated(got):
                _add(f"{rel}: decision {did} is RESOLVED but `{names[0]}` is "
                           f"{'a placeholder' if got.strip() else 'blank'} — an answer nobody is "
                           f"recorded as having given.")
            elif names is APPROVAL_DATE_COLUMNS and bad_date(got):
                _add(f"{rel}: decision {did} `{names[0]}` is not a date: {got!r}")
            elif names is APPROVER_COLUMNS and not_a_person(re.sub(r"[*`_]", "", got).strip()):
                # `decision_record` holds the ANSWER FORM's `answered_by` to `not_a_person`, and the
                # register this check reads was held to presence alone — so a decision answered
                # through the form was attributed to a person and the same decision written
                # straight into the register was attributed to `Science`. The bold-stripping is the
                # same `re.sub` the status read needs: registers bold their cells, and `**Science**`
                # is the team name this rule exists to refuse.
                _add(f"{rel}: decision {did} `{names[0]}`: "
                           f"{not_a_person(re.sub(r'[*`_]', '', got).strip())}")
    return per if by_decision else [m for ms in per.values() for m in ms]


SPEC_QC = "handoff/SPEC_QC_FINDINGS.md"
# How an open finding stops blocking. Not "delete the row": the finding is a defect in Science's
# document, and the register is the record that it was found. It is accounted for when it is fixed
# at source, deliberately carried as a limitation, or waived by someone who may waive it.
# Taken from the register's OWN stated vocabulary ("open · corrected · waived"), not invented here.
# `corrected` was missing, and it is the register's primary resolved state — so a finding Science had
# actually fixed, marked exactly as the document instructs, would still have blocked approval.
# `waived` is named, not spelled twice: the branch below tests it BEFORE the QC_ACCOUNTED
# membership test and so shadows this entry entirely. Two literals — one deciding the branch,
# one advertised in the error message — would drift the moment either is renamed, and the
# message would then tell an author to write a word the code no longer accepts.
WAIVED = "waived"
QC_ACCOUNTED = ("corrected", "closed", "fixed", "accepted", WAIVED, "superseded", "withdrawn")
# The full vocabulary a QC row may carry — accounted, plus the one status that BLOCKS. Matching
# was by PREFIX, so `corrected pending Science` and `accepted-with-caveats` counted as accounted: a
# finding nobody had corrected stopped blocking Gate 2 because its status started with the right
# eight letters. A controlled register compares exactly, and register_errors refuses anything
# outside this set rather than letting it read as "not open".
QC_STATUSES = frozenset(x.upper() for x in QC_ACCOUNTED + ("open",))


SPEC_REF_RE = re.compile(r"`([A-Za-z0-9_. ]+:\d+)`")


def spec_qc_citation_errors(p, rel, text):
    """Every `Spec ref` in the QC register must name a row the extraction actually contains.

    The register is the ONE artifact whose citations nothing checked. `spec_refs` on a contract record
    is held to this by I8; a QC finding's `Spec ref` was free prose, and prostate/202606 carried six
    citations naming sheets that workbook does not have — `5B.ClinVars` and `5D.Outcomes`, where the
    tabs are `5B. ClinChars` and `6.Outcomes`. Those findings were attached to no row by anything: a
    reviewer walking the claim back reached nothing, and the drafting slice could not show the finding
    to the person drafting the row it was about, so the defect read as "nothing recorded here".

    Cited by canonical DOMAIN, like everything else — a tab label differs per product and per revision,
    which is the whole reason `governance/spec_sheet_map.yaml` exists.

    Resolved through `contract_lint.spec_rows`, the reader I8 already uses. A second reader of the
    extraction here is how one gate comes to believe a row exists while another does not.

    A pack with no extraction is NOT silently clean: the register belongs to a pack at
    `contract: coverage_complete` or beyond, and the extraction is required at that level — so its
    absence is already reported by MATURITY_REQUIRES, and re-reporting it here would name the same
    defect twice. Scanning the WHOLE file rather than the Spec ref column: a citation in the prose
    below the table is read by the same person and is wrong in the same way.
    """
    ext = os.path.join(p, "spec_pipeline", "out", "extracted.json")
    if not os.path.exists(ext):
        return []
    known = {f"{domain}:{row}" for domain, rows in spec_rows(p).items() for row in rows}
    if not known:
        return []
    bad = sorted({r for r in SPEC_REF_RE.findall(text) if r not in known})
    if not bad:
        return []
    domains = sorted({d for d in spec_rows(p)})
    return [f"{rel}: {SPEC_QC} cites {', '.join(bad[:6])}"
            + (f" and {len(bad) - 6} more" if len(bad) > 6 else "")
            + f" — no such row in this pack's extraction. Cite the canonical DOMAIN "
              f"({', '.join(domains)}), never the workbook's tab label: a finding whose Spec ref "
              f"resolves nowhere cannot be walked back to the specification and never reaches the "
              f"drafter of the row it is about."]


@issue_results("specification_qc_required", gate=2)
def spec_qc_errors(p, rel):
    """Unaccounted-for open specification-QC findings block `contract: approved`.

    WORKFLOW.md names "specification-QC findings returned to Science" as a Gate 2 EXIT deliverable,
    alongside the decisions register — the two catch different things, Science's own document defects
    versus questions the document does not answer. The gate blocked on open DECISIONS and never read
    the findings, so a pack could be approved with an impossible study-end date, a truncated rule, or
    a contradictory definition still open in its own defect register.

    Read with contract_lint.decision_rows, which is the ONE markdown-table-keyed-by-ID reader and
    locates columns by NAME. Both registers are that same shape, and a second parser here is how the
    two come to disagree about what a row says — the exact defect found in open_decisions last round.
    """
    path = os.path.join(p, *SPEC_QC.split("/"))
    if not os.path.exists(path):
        return []
    with open(path, encoding="utf-8") as fh:
        text = fh.read()
    # A zero-byte file, or prose with no table, parses to NO ROWS — and no rows is exactly what a
    # clean register looks like. So "DataExpert looked and found nothing" and "somebody committed an empty
    # file" were the same thing to the machine. The canonical HEADER is what separates them: the
    # template ships it, so a register that has been through the process has one, and a header with
    # no rows beneath it IS the statement that QC found nothing.
    if not has_register(text):
        return [f"{rel}: {SPEC_QC} has no findings table — an empty or headerless register cannot say "
                f"whether QC was performed. Keep the canonical header row from "
                f"TUMOR_TEMPLATE/handoff/SPEC_QC_FINDINGS.md."]
    # The register must be well FORMED before its contents mean anything — the same check the decision
    # register already had. A header-only file is read as "QC was performed and found nothing", so
    # `| ID | Note |` with no rows passed as clean: no rows meant nothing ever looked at the columns.
    # `Status` only. `Kind` is real guidance in the template — it separates a defect needing an Science
    # round-trip from a delivery-format one — but NO check reads it, and requiring a column nothing
    # consumes is the form-filling that makes a gate feel arbitrary. Status is what decides accounted
    # vs open, so it is what must exist.
    # CITATIONS FIRST, and NOT behind the structure early-return. Whether a `Spec ref` resolves is
    # independent of whether the table has a Status column, and putting it after the return made the
    # check inert on the one pack it was written for: prostate/202606 trips the structure rule on its
    # second table, so its six unresolvable citations would never have been reached.
    citations = spec_qc_citation_errors(p, rel, text)
    structure = register_errors(text, rel, "the QC register", ("Status",), QC_STATUSES)
    if structure:
        return citations + structure
    errors = citations
    rows = decision_rows(text)
    open_ids = []
    for fid, row in sorted(rows.items()):
        # Structure — absent Status column, blank cell, duplicate id, unknown status — is
        # register_errors' job above and is already reported. What is left here is the QC-specific
        # question: is a well-formed status ACCOUNTED for?
        st = re.sub(r"[*`_]", "", cell(row, "Status")).strip().lower()
        if not st:
            continue
        if st == WAIVED:
            errors += waiver_errors(rel, fid, row)
        elif st not in QC_ACCOUNTED:
            open_ids.append(fid)
    if open_ids:
        errors.append(
            f"{rel}: contract:approved with {len(open_ids)} unaccounted specification-QC "
            f"finding(s) ({', '.join(open_ids[:5])}{'…' if len(open_ids) > 5 else ''}) — "
            f"WORKFLOW.md makes returning these to Science a Gate 2 exit deliverable. Each needs a "
            f"Status of {' / '.join(QC_ACCOUNTED)} against a corrected source revision, or must "
            f"be carried as a named decision. A row with NO status is unanswered, not resolved.")
    return errors


# WORKFLOW.md §"Waivers": "A waiver names who approved it, the rationale, its scope, its expiry, and
# the evidence it rests on. A waiver without an expiry is a silent permanent exception and is not a
# waiver." `waived` sat in QC_ACCOUNTED and closed a finding with none of that — a status word that
# made a defect in Science's document stop blocking Gate 2, with no approver and no end date.
#
# Rationale, scope and evidence are the Defect / Impact / Disposition columns the register already
# carries; the two that had NO home are the approver and the expiry. They are required only of a
# WAIVED row, so a product that never waives anything never adds the columns — the cost falls on the
# exception rather than on everyone, which is what keeps a form from becoming a habit.
# WORKFLOW.md names five things: approver, rationale, scope, expiry, evidence. Two had nowhere to
# go and were added as columns; the other three were said in a COMMENT to be carried by Defect,
# Impact and Disposition — and nothing checked that those cells held anything. A waived row with
# three blank cells satisfied "the register already carries them". They are required only of a
# WAIVED row, so a product that never waives never fills them.
WAIVER_FIELDS = (("Waived by", "who approved this exception, by name"),
                 ("Waiver expires", "the date it lapses (YYYY-MM-DD) — without one it is a silent "
                                    "permanent exception, which WORKFLOW.md says is not a waiver"),
                 ("Defect", "the RATIONALE — what the finding actually is"),
                 ("Impact", "the SCOPE — what carrying it uncorrected affects"),
                 ("Disposition", "the EVIDENCE it rests on — why this reading is safe to keep"))


def waiver_errors(rel, fid, row):
    errors = []
    for col, why in WAIVER_FIELDS:
        got = re.sub(r"[*`_]", "", str(cell(row, col) or "")).strip()
        if unstated(got):
            errors.append(f"{rel}: {SPEC_QC} {fid} is `waived` but names no `{col}` — {why}")
        elif col == "Waived by":
            # "by name" was in the requirement text and in nothing that ran, so `Waived by: Science`
            # closed a finding on the authority of a function. A waiver is the one disposition that
            # carries a defect forward UNCORRECTED; if any attribution in this file has to be a
            # person who can be asked why, it is this one.
            bad = not_a_person(got)
            if bad:
                errors.append(f"{rel}: {SPEC_QC} {fid} `Waived by`: {bad}")
        elif col == "Waiver expires":
            bad = bad_date(got, future_ok=True)              # the one date that may lie ahead
            if bad:
                errors.append(f"{rel}: {SPEC_QC} {fid} Waiver expires {bad}")
            elif got < datetime.date.today().isoformat():
                errors.append(f"{rel}: {SPEC_QC} {fid} was waived until {got}, which has passed — an "
                              f"expired waiver is an OPEN finding again, not a closed one. Renew it "
                              f"with a new expiry, or return the finding to Science.")
    return errors



def sha256(path):
    """Digest of a file OR a directory, so a spec tab folder can be frozen like a workbook.

    THE definition, for every tool that binds evidence to a document. There were three: this one,
    a file-only copy in source_check, and a nested one here. source_check WROTE `contract_sha256`
    with its copy and this module VERIFIED it with another — two definitions on either side of one
    comparison. They agreed, but nothing made them agree: teach one to normalise line endings, or to
    digest a directory, and every verdict in the repo silently stops matching its own contract.

    A directory digest covers each file's RELATIVE NAME as well as its bytes: hashing contents alone
    would let a tab be renamed, or two tabs swapped, without the digest moving. Files are walked in
    sorted order so the result does not depend on the filesystem.
    """
    h = hashlib.sha256()

    def feed(fh):
        for chunk in iter(lambda: fh.read(1 << 16), b""):
            h.update(chunk)

    if os.path.isdir(path):
        for root, dirs, files in os.walk(path):
            dirs.sort()
            for name in sorted(files):
                full = os.path.join(root, name)
                h.update(repo_relative(full, path).encode("utf-8"))
                h.update(b"\0")
                with open(full, "rb") as fh:
                    feed(fh)
    else:
        with open(path, "rb") as fh:
            feed(fh)
    return h.hexdigest()

# A pack is identified by a FILE it must own, never by a directory name. Matching a directory called
# `config` meant a shared `products/oncology/gu/config/` made `gu` itself the pack — and the real
# packs beneath it vanished from discovery, silently, which is the exact failure the recursive walk
# was written to fix. A directory name is a coincidence; these files are a pack.
PACK_FILES = ("source_refs.yaml", "handoff/MATURITY.yaml", "handoff/FUNCTIONAL_CONTRACT.md",
              "handoff/TEMPLATE_RECONCILIATION.yaml", "handoff/TEMPLATE_SEED.yaml",
              "spec_pipeline/pipeline.conf", "config/data_product.yaml")


def products(root=None):
    """Every pack under products/, sorted, as repo-relative paths — found by SHAPE, not by depth.

    This globbed `products/*/*/*`, exactly three levels. Adding one grouping level — a disease group,
    say `products/oncology/gu/prostate/202606` — made every pack under it vanish from discovery, and
    vanish SILENTLY: `--report` simply listed fewer packs, every CI loop iterated over fewer, and the
    whole thing stayed green while protecting nothing. That is the same failure the discovery design
    exists to prevent, reintroduced by the glob that implements it.

    A pack is a directory carrying at least one governed subtree. Walk for that and stop descending
    once found, so a pack's own `handoff/tests` is never mistaken for another pack.
    """
    return _packs_under(root or repo_root(), "products")


# THE FIXTURE ROOT. `fixtures/` mirrors `products/` shape for shape (family/slug/version), so a
# pack moves between them without any of its internal relative paths changing depth - and it sits
# OUTSIDE `products/` because that boundary already means something everywhere else: a fixture
# path has no tumour (the sighting resolver answers ""), founds no sighting, and never enters the
# deployment surfaces. Probe wave 11's remediation 2: the reference packs are test and walkthrough
# material, and the production namespace must hold only products, so that standing up or wiping a
# REAL pack can never move a platform test.
FIXTURES_BASE = "fixtures"


def fixture_packs(root=None):
    """Every pack under fixtures/, discovered by the same shape as `products()`."""
    return _packs_under(root or repo_root(), FIXTURES_BASE)


def all_packs(root=None):
    """Products plus fixtures - the EXERCISE list, never the deployment list.

    Two audiences, one principle. Deployment and release authority (the bundle, activation, the
    portfolio board, `releasable` listings, sighting evidence, citations) reads `products()`
    alone: a fixture never deploys and is never evidence. Exercise, integrity and knowledge
    (contract lint loops, maturity errors, source-registration integrity, dry runs, the status
    listing) read this, so moving a pack across the boundary never removes it from a single
    invariant check - coverage is the one thing the move must not cost.
    """
    root = root or repo_root()
    return sorted(_packs_under(root, "products") + _packs_under(root, FIXTURES_BASE))


def _packs_under(root, base_name):
    base = os.path.join(root, base_name)
    out = []
    for dirpath, dirnames, _files in os.walk(base):
        if any(os.path.exists(os.path.join(dirpath, *f.split("/"))) for f in PACK_FILES):
            out.append(repo_relative(dirpath, root))
            dirnames[:] = [] # a pack contains no further packs
        else:
            dirnames[:] = [d for d in dirnames if not d.startswith(".")]
    return sorted(out)


def facts(root, rel):
    p = os.path.join(root, rel)
    m = maturity(p)
    return {"product": rel, **m,
            "pipeline": os.path.exists(os.path.join(p, "spec_pipeline", "pipeline.conf")),
            "contract_file": os.path.exists(os.path.join(p, "handoff", "FUNCTIONAL_CONTRACT.md")),
            # Generated oncology-template review artefacts. Keep discovery here, beside every
            # other per-pack surface, so CI never has to name prostate (or any future cancer) by
            # hand.
            #
            # PRESENCE IS NOT EXPECTATION, and conflating them made the gate fail open. Selecting
            # the check from what is ON DISK means deleting an artefact removes its pack from the
            # check rather than failing it, and a pack that should have one but never got one is
            # silently absent from the report. `template_expects` below answers the other question:
            # what SHOULD this pack have, given what it declares?
            "template_reconciliation": os.path.exists(
                os.path.join(p, "handoff", "TEMPLATE_RECONCILIATION.yaml")),
            "template_seed": os.path.exists(os.path.join(p, "handoff", "TEMPLATE_SEED.yaml")),
            "template_expects": _template_expectation(p, rel),
            "decisions": os.path.exists(os.path.join(p, "handoff", "DECISIONS.md")),
            # A copied `variables/` folder is not an executable product configuration; the build
            # entry point is. Requiring it stops a scaffold folder alone from looking buildable.
            "config": os.path.exists(os.path.join(p, "config", "data_product.yaml")),
            "tests": sorted(repo_relative(t, root) for t in
                            glob.glob(os.path.join(p, "handoff", "tests", "test_*.py")))}


def maturity_report(root):
    """Owned findings for transactional admission; a report grants no maturity.

    Shared claims always belong to the workspace. Pack findings retain their
    owner so creation can compare the same checker before and after its edits.
    The normal all-pack maturity gate remains independent of that comparison.
    """
    root = os.path.abspath(root)

    def stable(value):
        text = str(value)
        for prefix in {base + separator for base in (root, root.replace("\\", "/"), root.replace("/", "\\"))
                       for separator in ("/", "\\")}:
            text = text.replace(prefix, "<workspace>/")
        return text

    def owned(error, validator, *, pack=None):
        issue = issue_of(error)
        details = {key: stable(value) for key, value in issue.details}
        details.update(validator=validator, scope="pack" if pack else "workspace")
        if pack:
            details["pack"] = pack
        return WorkflowIssue(validator if issue.code == "unclassified_evidence" else issue.code,
                             stable(issue.message), issue.gate, tuple(details.items())).to_dict()

    workspace = []
    for name, check in (("registry_claim_invalid", registry_errors),
                        ("vendor_policy_invalid", vendor_policy_errors),
                        ("work_registry_invalid", work_errors)):
        workspace.extend(owned(error, name) for error in check(root))
    packs = {pack: [owned(error, "maturity_claim_invalid", pack=pack)
                    for error in maturity_errors(root, pack)] for pack in all_packs(root)}
    return {"version": 1, "workspace_findings": workspace, "pack_findings": packs}


def parse_maturity_report(value):
    """Validate the complete producer report, including ownership of each issue."""
    def unique(pairs):
        result = {}
        for key, item in pairs:
            if key in result:
                raise ValueError("Repeated maturity report field.")
            result[key] = item
        return result
    document = json.loads(value, object_pairs_hook=unique) if isinstance(value, str) else value
    if (not isinstance(document, dict)
            or set(document) != {"version", "workspace_findings", "pack_findings"}
            or type(document["version"]) is not int or document["version"] != 1
            or not isinstance(document["workspace_findings"], list)
            or not isinstance(document["pack_findings"], dict)):
        raise ValueError("Incomplete maturity report.")
    for pack, rows in [(None, document["workspace_findings"]), *document["pack_findings"].items()]:
        if pack is not None:
            if (not isinstance(pack, str) or "\\" in pack or ":" in pack
                    or any(part in {"", ".", ".."} for part in pack.split("/"))
                    or PurePosixPath(pack).is_absolute()
                    or pack.split("/")[0] not in {"products", "fixtures"}):
                raise ValueError("Invalid maturity report pack.")
        if not isinstance(rows, list):
            raise ValueError("Invalid maturity findings.")
        for row in rows:
            issue = WorkflowIssue.from_dict(row)
            details = dict(issue.details)
            if (not issue.message.strip() or not details.get("validator")
                    or details.get("scope") != ("pack" if pack else "workspace")
                    or (details.get("pack") != pack if pack else "pack" in details)):
                raise ValueError("Maturity finding has inconsistent ownership.")
    return document


def main(argv):
    ap = argparse.ArgumentParser(description="Discover products and the gates that apply to each.")
    for f in ("pipelines", "strict", "decisions", "tests", "contracts", "configs",
              "template-reconciliations", "template-seeds", "template-out-of-scope",
              "template-superseded"):
        ap.add_argument(f"--list-{f}", action="store_true")
    # THE SAME LIST UNDER AN HONEST NAME, with the old one kept working. Callers exist - CI, the
    # engineering runbook's shell loop, contract_binding's own docstring - so renaming outright
    # would break them for a wording problem. Both flags set `list_config_declared`; STDOUT is
    # unchanged and still bare paths, because that loop consumes it.
    ap.add_argument("--list-config-declared", "--list-buildable", dest="list_config_declared",
                    action="store_true",
                    help="packs DECLARING configuration >= draft - the scope of the "
                         "contract<->YAML binding check. Not a claim that any of them can be "
                         "built: a pack qualifies by declaring a configuration, not by having "
                         "approvals or resolved runtime bindings.")
    ap.add_argument("--report", action="store_true")
    ap.add_argument("--check-maturity", action="store_true",
                    help="exit non-zero when a declared level is inconsistent or unevidenced")
    ap.add_argument("--maturity-report-json", action="store_true",
                    help="report shared and pack-owned maturity findings as JSON; does not grant approval")
    a = ap.parse_args(argv)

    root = repo_root()
    if a.maturity_report_json:
        if any(value for key, value in vars(a).items() if key != "maturity_report_json"):
            ap.error("--maturity-report-json cannot be combined with a gate or listing action")
        try:
            document = parse_maturity_report(maturity_report(root))
        except (OSError, ValueError, TypeError, KeyError, AttributeError, RecursionError) as error:
            print(json.dumps({"error": "Maturity inspection could not complete", "error_type": type(error).__name__}))
            return 1
        print(json.dumps(document, ensure_ascii=False, allow_nan=False))
        return 0
    rows = [facts(root, r) for r in all_packs(root)]

    if a.check_maturity:
        # The registry's own claim first: an `active` entry naming a pack that cannot be built is the
        # cause of every downstream "missing config" failure, and it must be reported as itself.
        #...and the vendor policy, which is a registry claim by another name: every registered vendor
        # has to say which schema evidence its products owe, or "no profile attached" means nothing.
        # work_errors is the `work:` block's SHAPE — an id, a declared kind, a citation where the
        # kind owes one. Whether each citation is actually citable is `source_manifest` (Gate 1's
        # run), because answering it needs `releasable`, which this module may not import.
        errs = (registry_errors(root) + vendor_policy_errors(root) + work_errors(root) +
                [e for r in all_packs(root) for e in maturity_errors(root, r)])
        for e in errs:
            print(e)
        print(f"{len(errs)} maturity claim error(s)")
        return 1 if errs else 0

    if a.list_pipelines:
        print("\n".join(r["product"] for r in rows if r["pipeline"]))
    elif a.list_strict:
        # Gate 2 is claimed, so Gate 2 must hold. A pack still drafting is not held to it.
        print("\n".join(r["product"] for r in rows
                        if r["pipeline"] and CONTRACT_LEVELS.index(r["contract"]) >= 2))
    elif a.list_decisions:
        print("\n".join(r["product"] for r in rows if r["decisions"] and r["contract_file"]))
    elif a.list_config_declared:
        # Driven by CONFIGURATION maturity, not contract maturity: the binding is a statement about
        # YAML that has been authored. Declare configuration: draft and every governed block must
        # answer to a record.
        print("\n".join(r["product"] for r in rows if r["config"] and r["contract_file"]
                         and CONFIG_LEVELS.index(r["configuration"]) >= 1))
    elif a.list_contracts:
        # Every pack with a contract. Gate 3's structure check borrowed --list-decisions, which also
        # requires DECISIONS.md — so a new tumour that has written its contract but not yet raised
        # its first decision was skipped by the very step meant to protect new tumours.
        print("\n".join(r["product"] for r in rows if r["contract_file"]))
    elif a.list_configs:
        # Every pack whose config is AUTHORED — not every pack that has the file.
        #
        # TUMOR_TEMPLATE ships config/, variables/ and codelists/ full of REPLACE_ME, and
        # NEW_TUMOUR.md tells you to leave them until the contract exists. Selecting on file
        # existence meant the first act of starting a tumour — copying the template — produced lint
        # errors about placeholders you were told not to fill in yet, while `configuration:
        # not_started` ("no executable YAML authored yet") said the opposite.
        #
        # Keyed on the PLACEHOLDER, not on the maturity claim, deliberately. Claim-keying would have
        # been fail-OPEN: prostate 202603 carries a real config and no MATURITY.yaml at all, so it
        # defaults to `not_started` and would have silently stopped being linted. A scaffold is
        # identifiable from its own bytes; a missing claim is not.
        print("\n".join(r["product"] for r in rows
                        if r["config"] and not is_template_scaffold(os.path.join(root, r["product"]))))
    elif a.list_template_reconciliations:
        # EXPECTED, NOT PRESENT. A pack that should carry one and does not is listed here
        # so the check FAILS on it, rather than vanishing from the list it belongs on.
        print("\n".join(r["product"] for r in rows
                        if r["template_expects"] == "reconciliation"))
    elif a.list_template_seeds:
        print("\n".join(r["product"] for r in rows
                        if r["template_expects"] == "seed"))
    elif a.list_template_superseded:
        print("\n".join(r["product"] for r in rows
                        if r["template_expects"] == "superseded"))
    elif a.list_template_out_of_scope:
        # NAMED, NOT SKIPPED. A pack the registry has no modules for expects nothing, and
        # saying so is a fact about the registry's scope rather than an absence.
        print("\n".join(r["product"] for r in rows
                        if r["template_expects"] == "out_of_scope"))
    elif a.list_tests:
        print("\n".join(t for r in rows for t in r["tests"]))
    else:
        print(f"{'product':<40} {'contract':<18}{'config':<14} pipeline contract decisions tests")
        for r in rows:
            print(f"{r['product']:<40} {r['contract']:<18}{r['configuration']:<14}"
                  f"{'yes' if r['pipeline'] else '-':<8} {'yes' if r['contract_file'] else '-':<8} "
                  f"{'yes' if r['decisions'] else '-':<9} {len(r['tests'])}")
        undeclared = [r["product"] for r in rows if not r["declared"] and r["contract_file"]]
        if undeclared:
            print("\nno handoff/MATURITY.yaml (treated as contract: not_started, so NOT held to Gate 2): "
                  + ", ".join(undeclared))
    return 0


if __name__ == "__main__":
    from rwd_tools.console import use_utf8
    use_utf8()
    sys.exit(main(sys.argv[1:]))
