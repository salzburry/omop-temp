#!/usr/bin/env python3
"""The CI lane, on this machine: every check the hosted workflow runs that needs no Spark, R or cluster.

    python platform/tools/ci_local.py                      # the whole lane; a summary table at the end
    python platform/tools/ci_local.py --portal             # Streamlit journeys and shared form checks
    python platform/tools/ci_local.py --quick              # compile + governance gates, no test suites
    python platform/tools/ci_local.py --json lane.json     # machine-readable rows
    python platform/tools/ci_local.py --plan --lane spark --json selection.json  # select; execute nothing

This runs the local pure-Python checks with pytest, matching the repository workflow's
fixture and parameterized test execution. Each suite runs once in its own process,
and one row per step records its verdict and duration. Steps
assigned to the Spark or R lanes are excluded by policy, even if those runtimes
are installed locally. These exclusions are reported `skipped`, never `pass`.

WHAT A VERDICT MEANS. Pytest `pass` requires executed passing cases and no failures.
`fail` retains the last lines of output. `skipped` names a lane-policy exclusion
or missing prerequisite. The lane exits non-zero on any `fail`.

stdlib only.
"""
from __future__ import annotations

import argparse
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import time
import xml.etree.ElementTree as ET

TOOLS = os.path.dirname(os.path.abspath(__file__))
from rwd_services import workspace_root
ROOT = str(workspace_root(__file__))
PY = sys.executable
SPARK_SUITES = {"test_stages_spark.py", "test_non_oncology_spark.py", "test_smoke_spark.py", "test_r_parity.py", "test_delta_promotion_spark.py",
                "test_patient_goldens_spark.py", "test_source_portability_spark.py", "test_stage_conformance.py",
                "test_synthetic_spark_uat.py", "test_output_contract.py", "test_differential.py", "test_grain.py",
                "test_spark_actions.py", "test_telemetry.py", "test_eda_report.py", "test_mapping_benchmark.py",
                "test_source_portability_runner.py", "test_ecog_equidistant.py",
                "test_sql_expressions_spark.py", "test_synthetic_frame.py", "test_epi_source_provisioning.py",
                "test_epi_source_provisioning_restart.py", "test_epi_source_provisioning_ads.py",
                "test_oncology_paper_uat.py", "test_epi_native_instrument_end_to_end.py", "test_epi_final_researcher_journeys.py"}
EXTENDED_RUNTIME_SUITES = {
    "test_epi_source_provisioning_ads.py": {},
    "test_oncology_paper_uat.py": {},
    "test_epi_native_instrument_end_to_end.py": {"RWD_RUN_NATIVE_INSTRUMENT_SPARK": "1"},
    "test_epi_final_researcher_journeys.py": {"RWD_FINAL_JOURNEY_SPARK": "1"},
}
COMPATIBILITY_SUITES = {"test_stages_spark.py", "test_patient_goldens_spark.py",
                        "test_sql_expressions_spark.py", "test_ecog_equidistant.py"}


def runtime_lane(name):
    if name == "test_r_parity.py":
        return "r"
    if name in EXTENDED_RUNTIME_SUITES:
        return "extended"
    return "spark" if name in SPARK_SUITES else "pure"
PORTAL_PREFIXES = ("test_epi_", "test_portal_", "test_flow", "test_stage_model", "test_uat_journey", "test_contract_scaffold_guard",
                   "test_chat_prefill", "test_form_assistance", "test_next_cut_sheet_identity")


def _run(argv, cwd=ROOT, timeout=3600):
    from rwd_services import python_module_command
    argv = python_module_command(argv, root=cwd)
    t = time.time()
    try:
        r = subprocess.run(argv, cwd=cwd, capture_output=True, text=True, encoding="utf-8", errors="replace",
                           timeout=timeout, env=dict(os.environ, PYTHONUTF8="1", PYTHONIOENCODING="utf-8",
                                                     RWD_PORTAL_WORKSPACE_ROOT=str(cwd)))
        out = (r.stdout or "") + (r.stderr or "")
        return r.returncode, out, time.time() - t
    except subprocess.TimeoutExpired as exc:
        return 124, f"timed out after {timeout}s: {exc}", time.time() - t
    except OSError as exc:
        return 126, f"could not start: {exc}", time.time() - t


def _tail(out, n=6):
    lines = [l for l in out.strip().splitlines() if l.strip()]
    return "\n".join(lines[-n:])


def _have(module):
    return subprocess.run([PY, "-I", "-c", f"import {module}"], capture_output=True).returncode == 0


def steps(portal_only=False, quick=False):
    """[(name, argv or callable, skip reason)] in the workflow's order."""
    rows = []
    if not portal_only:
        rows += [
            # the workflow compiles engine/, tools/, tests/*.py and the template's test; the test
            # fixtures under platform/tests/fixtures are data other suites copy and delete while they
            # run, so they are excluded here as they are there
            ("every module compiles", "compile", ""),
            ("no invalid escape sequence", [PY, "-m", "pytest", "-q", "platform/tests/test_governance.py::test_no_python_file_carries_an_invalid_escape_sequence"], ""),
            ("repo hygiene", [PY, "platform/tools/repo_hygiene.py", "--check"], ""),
            ("naming registry", [PY, "platform/tools/naming_registry.py", "--check"], ""),
            ("registry schema", [PY, "platform/tools/registry_schema.py", "--check"], ""),
            ("oncology modules derived", [PY, "platform/tools/registry_enrich.py", "--check"], ""),
            ("oncology registry", [PY, "platform/tools/oncology_registry.py", "--check"], ""),
            ("definition register", [PY, "platform/tools/definition_registry.py", "--check"], ""),
            ("master-family lifecycle", [PY, "platform/tools/master_family.py", "--check"], ""),
            ("maturity claims", [PY, "platform/tools/product_gates.py", "--check-maturity"], ""),
            ("bundled products", [PY, "platform/tools/bundle_products.py", "--check"], ""),
            ("current state page", [PY, "platform/tools/current_state.py", "--check"], ""),
        ]
        # A wheel/ZIP installation intentionally has no Git index and omits
        # repository-only governance tests. Report those checks as scoped
        # skips instead of manufacturing failures on a clean application
        # install; the source checkout lane still executes them normally.
        if not (Path(ROOT) / "platform/tests/test_governance.py").is_file():
            rows[1] = (rows[1][0], None, "repository governance test is not shipped in the production bundle")
        if not (Path(ROOT) / ".git").exists():
            rows[2] = (rows[2][0], None, "repository hygiene needs a Git checkout; application bundles have no history")
            for index, (name, argv, reason) in enumerate(rows):
                if name == "current state page":
                    rows[index] = (name, None, "current-state comparison needs a repository history; regenerate it after importing the bundle")
    if quick:
        return rows
    if not portal_only:
        rows += [
            ("event ledger and claimed objects", [PY, "platform/tools/event_ledger.py", "--check"], ""),
            ("source manifest integrity", [PY, "platform/tools/source_manifest.py", "--all", "--check"], ""),
            ("approval identity", [PY, "platform/tools/approval_identity.py", "--check"], ""),
        ]
    tests = sorted(f for f in os.listdir(os.path.join(ROOT, "platform", "tests")) if f.startswith("test_") and f.endswith(".py"))
    have_streamlit = _have("streamlit")
    for name in tests:
        is_portal = name.startswith(PORTAL_PREFIXES)
        if portal_only and not is_portal:
            continue
        if name in SPARK_SUITES:
            lane = runtime_lane(name)
            requirement = "R" if lane == "r" else "pyspark and Java"
            rows.append((f"suite {name}", None, f"excluded by pure-lane policy; assigned to {lane} runtime lane ({requirement}). Runtime availability was not tested."))
            continue
        if is_portal and not have_streamlit:
            rows.append((f"suite {name}", None, "needs streamlit (experiments/portal/requirements.txt)"))
            continue
        # Run actual pytest collection even when a file retains a legacy standalone
        # entrypoint; a __main__ string cannot decide which assertions execute.
        rows.append((f"suite {name}", [PY, "-m", "pytest", "-q", "-p", "no:cacheprovider",
                     os.path.join("platform", "tests", name)], ""))
    if not portal_only:
        rows += [
            ("product tests (discovered)", "product_tests", ""),
            ("gate 3 structure over every contract", "gate3_structure", ""),
            ("UAT verdict table (never a gate)", [PY, "platform/tools/uat.py"], ""),
        ]
    return rows


def _compile_all():
    """Every module under the four roots compiles, without writing a .pyc into the tree.

    compileall writes beside the source, and on Windows that collides with any interpreter that has the
    module imported at that moment (a concurrent suite): 'Access is denied' on the .pyc rename read as a
    syntax error. Compiling to a throwaway file keeps the check and drops the race."""
    import py_compile                                                    # noqa: PLC0415
    import tempfile                                                      # noqa: PLC0415
    t, bad, count = time.time(), [], 0
    skip = ("fixtures", "__pycache__", ".history", "node_modules", ".venv", ".venv313", "venv")
    with tempfile.TemporaryDirectory(prefix="rwdp-compile-") as tmp:
        for root_rel in ("platform/engine", "platform/tools", "platform/tests", "experiments"):
            for dirpath, dirs, files in os.walk(os.path.join(ROOT, root_rel)):
                dirs[:] = [d for d in dirs if d not in skip]
                for name in files:
                    if not name.endswith(".py"):
                        continue
                    count += 1
                    try:
                        py_compile.compile(os.path.join(dirpath, name), cfile=os.path.join(tmp, f"{count}.pyc"), doraise=True)
                    except py_compile.PyCompileError as exc:
                        bad.append(str(exc).strip().splitlines()[-1])
    return (1 if bad else 0), (chr(10).join(bad) if bad else f"{count} modules compile"), time.time() - t


def _product_tests():
    code, out, _t = _run([PY, "platform/tools/product_gates.py", "--list-tests"])
    listed = [l.strip() for l in out.splitlines() if l.strip()] if code == 0 else []
    if not listed:
        return 1, "product_gates.py --list-tests returned nothing; this step would prove nothing", 0.0, None
    total, worst, t = "", 0, time.time()
    counts = {"passed": 0, "failed": 0, "errors": 0, "skipped": 0}
    for test in listed:
        verdict, out, _seconds, measured = _pytest_result([PY, "-m", "pytest", "-q", test])
        worst = max(worst, int(verdict != "pass"))
        if measured:
            counts = {key: counts[key] + measured[key] for key in counts}
        total += f"== {test} -> {verdict} {measured}\n{_tail(out, 3)}\n"
    return worst, total, time.time() - t, counts


def _gate3_structure():
    code, out, _t = _run([PY, "platform/tools/product_gates.py", "--list-contracts"])
    packs = [l.strip() for l in out.splitlines() if l.strip()] if code == 0 else []
    if not packs:
        return 1, "product_gates.py --list-contracts returned nothing; this step would prove nothing", 0.0
    total, worst, t = "", 0, time.time()
    for pack in packs:
        c, o, _ = _run([PY, "platform/tools/source_check.py", pack, "--structure-only", "--check"])
        worst = max(worst, c)
        total += f"== {pack} -> exit {c}\n{_tail(o, 2)}\n"
    return worst, total, time.time() - t


def _pytest_result(argv):
    """Measure executed pytest cases, including all-skipped and missing reports."""
    with tempfile.TemporaryDirectory(prefix="rwd-ci-result-") as directory:
        report = Path(directory) / "result.xml"
        code, out, seconds = _run([*argv, "--junitxml", str(report)])
        try:
            cases = ET.parse(report).getroot().findall(".//testcase")
            counts = {"passed": 0, "failed": 0, "errors": 0, "skipped": 0}
            for case in cases:
                outcome = ("errors" if case.find("error") is not None else
                           "failed" if case.find("failure") is not None else
                           "skipped" if case.find("skipped") is not None else "passed")
                counts[outcome] += 1
            if not cases:
                raise ValueError("the report contains no collected cases")
        except (OSError, ValueError, ET.ParseError) as error:
            return "fail", out + "\nNo usable counted pytest result: " + str(error), seconds, None
    verdict = ("fail" if code or counts["failed"] or counts["errors"] else
               "skipped" if counts["passed"] == 0 else "pass")
    return verdict, out, seconds, counts


def _write_progress(path, rows, *, complete=False):
    if path is None:
        return
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    tally = {v: sum(row["verdict"] == v for row in rows) for v in ("pass", "fail", "skipped")}
    content = json.dumps({"complete": complete, "rows": rows, "tally": tally}, indent=1) + "\n"
    # A stopped lane leaves the last complete row, not a truncated JSON file.
    handle, temporary = tempfile.mkstemp(prefix=".ci-progress-", dir=path.parent)
    try:
        with os.fdopen(handle, "w", encoding="utf-8", newline="\n") as output:
            output.write(content)
        os.replace(temporary, path)
    finally:
        Path(temporary).unlink(missing_ok=True)


def run_lane(portal_only=False, quick=False, only=None, report_path=None):
    rows = []
    _write_progress(report_path, rows)
    for name, argv, skip in steps(portal_only, quick):
        if only and only.lower() not in name.lower():
            continue
        if skip:
            rows.append({"step": name, "verdict": "skipped", "seconds": 0.0, "detail": skip})
            print(f"  {'skipped':8s} {name} ({skip})")
            _write_progress(report_path, rows)
            continue
        print(f"  running  {name} ...", flush=True)
        counts = None
        if name.startswith("suite "):
            verdict, out, seconds, counts = _pytest_result(argv)
            code = 1 if verdict == "fail" else 0
        elif argv == "compile":
            code, out, seconds = _compile_all()
        elif argv == "product_tests":
            code, out, seconds, counts = _product_tests()
        elif argv == "gate3_structure":
            code, out, seconds = _gate3_structure()
        else:
            code, out, seconds = _run(argv)
        if not name.startswith("suite "):
            verdict = "pass" if code == 0 else "fail"
            if name == "approval identity" and code == 2:
                verdict = "skipped"
        detail = _tail(out) if verdict in {"fail", "skipped"} else ""
        rows.append({"step": name, "verdict": verdict, "seconds": round(seconds, 1), "detail": detail,
                     **({"cases": counts} if counts is not None else {})})
        _write_progress(report_path, rows)
        print(f"  {verdict:8s} {name} ({seconds:.0f}s)" + (f"\n{_tail(out)}" if verdict == "fail" else ""), flush=True)
    _write_progress(report_path, rows, complete=True)
    return rows


def render(rows):
    tally = {v: sum(1 for r in rows if r["verdict"] == v) for v in ("pass", "fail", "skipped")}
    L = ["", "=" * 96, "  LOCAL CI LANE — the workflow's pure-Python steps, on this machine", "=" * 96,
         "  %-58s %-8s %8s" % ("STEP", "VERDICT", "SECONDS"), "  " + "-" * 92]
    for r in rows:
        L.append("  %-58s %-8s %8.1f" % (r["step"][:58], r["verdict"], r["seconds"]))
    L += ["", "  " + " · ".join(f"{n} {v}" for v, n in tally.items()), ""]
    if tally["skipped"]:
        L.append("  SKIPPED is not a pass: runtime-lane exclusions or missing prerequisites were not exercised here; see each reason.")
    return "\n".join(L), tally


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__.strip().splitlines()[0])
    ap.add_argument("--portal", action="store_true", help="Streamlit journey suites and shared form assistance checks")
    ap.add_argument("--quick", action="store_true", help="compile and governance gates only")
    ap.add_argument("--only", metavar="SUBSTR", help="run only steps whose name contains this")
    ap.add_argument("--json", metavar="PATH", help="write the rows as JSON")
    ap.add_argument("--plan", action="store_true", help="list selected commands and exclusions without executing tests or starting Spark")
    ap.add_argument("--lane", choices=("pure", "spark", "extended", "r", "compat"), default="pure", help="lane to inspect with --plan; extended full-ADS UAT is opt-in")
    a = ap.parse_args(argv)
    if a.plan:
        report = selection_plan(lane=a.lane, portal_only=a.portal, quick=a.quick, only=a.only)
        text = json.dumps(report, indent=2)
        if a.json:
            destination = Path(a.json)
            destination.parent.mkdir(parents=True, exist_ok=True)
            destination.write_text(text + "\n", encoding="utf-8", newline="\n")
        print(text)
        return 0
    if a.lane != "pure":
        ap.error("--lane selects a non-executing --plan. Run its reviewed commands explicitly or use the dedicated hosted job.")
    rows = run_lane(portal_only=a.portal, quick=a.quick, only=a.only, report_path=a.json)
    text, tally = render(rows)
    print(text)
    return 1 if tally["fail"] else 0


def selection_plan(*, lane="pure", portal_only=False, quick=False, only=None):
    """Count selection, never claim tests passed or infer runtime availability."""
    rows = []
    for name, argv, reason in steps(portal_only, quick):
        suite = name.removeprefix("suite ") if name.startswith("suite ") else None
        assigned = runtime_lane(suite) if suite else "pure"
        if only and only.lower() not in name.lower():
            continue
        if lane == "compat" and suite not in COMPATIBILITY_SUITES:
            continue
        if lane not in {"pure", "compat"} and assigned != lane:
            continue
        if lane != "pure":
            argv = [PY, "-m", "pytest", "-q", "-rs", "platform/tests/" + suite,
                    "--junitxml=platform/test-results/" + lane + "-" + suite[:-3] + ".xml"]
            reason = ""
        rows.append({"step": name, "lane": lane if lane == "compat" else assigned, "selected": not bool(reason), "argv": argv,
                     "reason": reason, "environment": EXTENDED_RUNTIME_SUITES.get(suite, {})})
    return {"executed": False, "lane": lane, "runtime_profile": "dbr154-oss-java8" if lane == "compat" else None,
            "selected_steps": sum(r["selected"] for r in rows),
            "excluded_steps": sum(not r["selected"] for r in rows), "rows": rows,
            "notice": "Selection only. No tests, Spark sessions or approvals were executed. The plan does not prove runtime readiness."}


if __name__ == "__main__":
    from rwd_tools.console import use_utf8
    use_utf8()
    sys.exit(main())
