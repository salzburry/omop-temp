#!/usr/bin/env python3
"""Parity-composed ledger claims — a claim is a PROVEN relationship, never a sighting.

The orphan question ("is every ledger object still claimed by a record?") used to be
answered by text search, and a review walked straight through it: a README mention, a
YAML comment, a block scalar, a decoy file — each carried a uuid and none was a record.
Text cannot tell a record from something shaped like one. Validation can.

So each OWNING record tool exports `claimed_objects(root)`: the uuids of records that
tool itself PROVES — schema-shaped, uuid-valid, and with the record's recomputed payload
digest equal to the chain's newest sealed payload. This module composes those providers
and enforces the ratified invariants:

  * every object kind the ledger speaks has a provider — a missing provider is a named
    problem, never a silently skipped kind;
  * every active object is claimed by exactly one validating record;
  * a kind whose integration cannot yet validate (the template kinds) claims nothing, so
    any object of that kind is named rather than assumed fine — fail closed.

Check-only. `python platform/tools/claims.py --check` prints the composition.
"""
from __future__ import annotations

import argparse
import os
import sys

TOOLS = os.path.dirname(os.path.abspath(__file__))
from rwd_services import workspace_root
REPO = str(workspace_root(__file__))

from rwd_tools import event_ledger as el                                                # noqa: E402
from rwd_tools import product_gates as pg                                               # noqa: E402
from rwd_tools.spec_extract import repo_relative                                   # noqa: E402


def _spec_claims(root):
    """specification_material: every registered material whose parity holds."""
    import glob as _glob                                                 # noqa: PLC0415
    from rwd_tools import source_manifest as sm                                         # noqa: PLC0415
    out = {}
    for base in ("products", "fixtures"):
        for f in _glob.glob(os.path.join(root, base, "*", "*", "*", "source_refs.yaml")):
            rel = repo_relative(os.path.dirname(f), root)
            try:
                mats = sm.materials(os.path.join(root, rel)) or []
            except Exception:                                            # noqa: BLE001
                continue
            for m in mats:
                obj = str(m.get("object_uuid") or "")
                if not el.UUID4.match(obj):
                    continue
                newest = _head_payload_sha(root, obj)
                if newest is not None and \
                        newest == el.payload_digest(sm.spec_event_payload(m)):
                    out.setdefault(obj, []).append(f"{rel}/source_refs.yaml")
    return out


def _record_claims(root, mod, payload_of, paths):
    import glob as _glob                                                 # noqa: PLC0415
    out = {}
    for pattern in paths:
        for f in _glob.glob(os.path.join(root, pattern)):
            doc, err = pg.read_yaml(f)
            if err or not isinstance(doc, dict):
                continue                     # a malformed record claims nothing
            obj = str((doc or {}).get("object_uuid") or "")
            if not el.UUID4.match(obj):
                continue
            newest = _head_payload_sha(root, obj)
            if newest is None:
                continue
            try:
                live = el.payload_digest(payload_of(mod, doc, root, f))
            except Exception:                                            # noqa: BLE001
                continue
            if newest == live:
                rel = repo_relative(f, root)
                out.setdefault(obj, []).append(rel)
    return out


def _head_payload_sha(root, obj):
    newest = None
    for _seq, fname in el._event_files(root, obj):
        ev, err = el.read_event(root, obj, fname)
        if not err and isinstance(ev, dict) and ev.get("action") != "attested":
            newest = ev
    return None if newest is None else str(newest.get("payload_sha256"))


def _protocol_claims(root):
    from rwd_tools import protocol_record
    return _record_claims(root, protocol_record,
                          lambda m, doc, r, f: m.event_payload(doc),
                          ["work/*/PROTOCOL.yaml"])


def request_payload(m, doc, r, f):
    """The request's LIVE payload, exactly as `request_record.record_event` sealed it: the
    record plus the citations on its REGISTRY entry. The first version asked the module for a
    `lineage_entry` it never had, so the citations were dropped, the live digest never matched
    the sealed one, and every sealed request read as ABANDONED — and through releasable() that
    one chain poisoned every product's release verdict (thirteenth pass, J6)."""
    rid = str(doc.get("request_id") or doc.get("id") or os.path.basename(os.path.dirname(f)))
    entry = next((w for w in pg.work_entries(r) if str(w.get("id") or "") == rid), None) or {}
    return m.event_payload(doc, entry.get("cites_release") or [])


def _request_claims(root):
    from rwd_tools import request_record
    return _record_claims(root, request_record, request_payload, ["work/*/REQUEST.yaml"])


def _decision_claims(root):
    from rwd_tools import decision_record as dr                                         # noqa: PLC0415
    return {k: [v] for k, v in dr.claimed_objects(root).items()}


def _ruling_claims(root):
    """equivalence_ruling: entries in the rulings file that validate AND carry a sealed
    object. Sealing rulings is the next integration; until an entry carries an
    object_uuid nothing here claims, so any equivalence_ruling OBJECT is named — closed."""
    from rwd_tools import semantic_view as sv                                           # noqa: PLC0415
    from rwd_tools import product_gates as pg                                           # noqa: PLC0415
    out = {}
    doc, err = pg.read_yaml(os.path.join(root, "governance", "EQUIVALENCE_RULINGS.yaml"))
    if err:
        return out
    for r in (doc or {}).get("rulings") or []:
        obj = str((r or {}).get("object_uuid") or "")
        if el.UUID4.match(obj):
            newest = _head_payload_sha(root, obj)
            if newest is not None:
                out.setdefault(obj, []).append("governance/EQUIVALENCE_RULINGS.yaml")
    return out


def _template_claims(root):
    """No validating integration yet: claims nothing, so an object of these kinds is
    NAMED as unclaimed instead of silently trusted — the fail-closed half of coverage."""
    return {}


def _approval_claims(form):
    """The four approval forms (programme item 5): a form claims its object only while its live
    payload equals the chain head — an edited form is a record that shed its act."""
    def provider(root):
        from rwd_tools import approval_record as ar                                     # noqa: PLC0415
        return {k: [v] for k, v in ar.claimed_objects(root, form).items()}
    return provider


PROVIDERS = {
    "release_approval": _approval_claims("release"),
    "configuration_approval": _approval_claims("configuration"),
    "contract_approval": _approval_claims("contract"),
    "semantic_approval": _approval_claims("semantic"),
    "specification_material": _spec_claims,
    "protocol": _protocol_claims,
    "request": _request_claims,
    "decision": _decision_claims,
    "equivalence_ruling": _ruling_claims,
    "template_release": _template_claims,
    "template_ruling": _template_claims,
}


def compose(root=None):
    """({object_uuid: [claiming records]}, [problems]) over every ledger object.

    Problems name: a kind with no provider (coverage is structural, never assumed), an
    object no validating record claims, and an object claimed by more than one record."""
    root = root or REPO
    problems = []
    for kind in el.OBJECT_KINDS:
        if kind not in PROVIDERS:
            problems.append(f"claims: no claim provider for kind {kind!r} — an orphan "
                            f"check that cannot see a kind silently never runs for it")
    claimed = {}
    for kind, provider in PROVIDERS.items():
        if kind not in el.OBJECT_KINDS:
            problems.append(f"claims: provider for unknown kind {kind!r}")
            continue
        try:
            for obj, files in provider(root).items():
                claimed.setdefault(obj, []).extend(files)
        except Exception as e:                                           # noqa: BLE001
            problems.append(f"claims: the {kind} provider failed ({e}) — refusing to "
                            f"treat its objects as covered")
    base = os.path.join(root, el.EVENTS_DIR)
    if os.path.isdir(base):
        for entry in sorted(os.listdir(base)):
            if not el.UUID4.match(entry):
                continue
            owners = claimed.get(entry, [])
            if not owners:
                problems.append(f"{el.EVENTS_DIR}/{entry}: no record in the tree "
                                f"VALIDATES against this object — its record was "
                                f"deleted, re-pointed, or has diverged; a chain no "
                                f"proven record owns is abandoned")
            elif len(set(owners)) > 1:
                # WHICH ONE IS THE COPY is decided by where the uuid entered the repository, and
                # the remedy names the copy: a message that told 'the other' to drop a uuid the
                # sticky rule then demanded back was a loop, not a remedy (thirteenth pass, J6)
                copies = sorted(f for f in set(owners)
                                if el.owns_object_uuid(root, f, entry) is False)
                origin = el.uuid_origin(root, entry)
                if copies and isinstance(origin, tuple):
                    problems.append(f"{el.EVENTS_DIR}/{entry}: claimed by "
                                    f"{len(set(owners))} records ({', '.join(sorted(set(owners)))}) "
                                    f"— {', '.join(copies)} carr{'y' if len(copies) > 1 else 'ies'} a copied "
                                    f"object_uuid (it entered the repository at commit {origin[0][:8]}, "
                                    f"through {', '.join(sorted(set(owners) - set(copies))) or 'its owner'}): "
                                    f"remove the copied object_uuid line from the copy, commit, then seal its "
                                    f"own genesis: source_manifest.py <pack> --record-event <material_id> "
                                    f"(docs/EVENT_LEDGER.md)")
                else:
                    problems.append(f"{el.EVENTS_DIR}/{entry}: claimed by "
                                    f"{len(set(owners))} records ({', '.join(sorted(set(owners)))}) "
                                    f"— exactly one record owns an object, and git history could not say "
                                    f"which lineage introduced this uuid (uncommitted, or shallow history): "
                                    f"commit, fetch full history, and re-check (docs/EVENT_LEDGER.md)")
    return claimed, problems


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    ap.add_argument("--check", action="store_true", help="exit 1 on any problem")
    a = ap.parse_args(argv)
    claimed, problems = compose()
    # Raw ownership composition still names absent subjects. The public check uses
    # the ledger's lifecycle and integrity rules, so a proven retirement is settled
    # and a forged or damaged retirement cannot conceal an abandoned object.
    problems = el.settle_abandoned(REPO, problems, el._is_git(REPO) and not el._is_shallow(REPO))
    problems += el.check(REPO, require_claims=False)
    problems = list(dict.fromkeys(problems))
    print(f"{len(claimed)} object(s) claimed by validating records")
    for obj, files in sorted(claimed.items()):
        print(f"  {obj}  <-  {', '.join(sorted(set(files)))}")
    if problems:
        print(f"{len(problems)} problem(s):")
        for p in problems:
            print(f"  - {p}")
    return 1 if (problems and a.check) else 0


if __name__ == "__main__":
    from rwd_tools.console import use_utf8
    use_utf8()
    sys.exit(main())
