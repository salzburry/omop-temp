#!/usr/bin/env python3
"""Does THIS pack account for every variable its tumour's inventory carries — and nothing else?

    python3 platform/tools/pack_coverage.py # every pack with a real version
    python3 platform/tools/pack_coverage.py fixtures/oncology/prostate/202606

WHAT THIS ANSWERS THAT NOTHING ELSE DID. The inventory's coverage classes are held REPO-WIDE:
`inventory_coverage` validates every classification's shape, and `capability_registry` resolves
every claim to the code, config key and test behind it. Neither asks the PACK-level question a
product owner actually has: for the product being cut, is every variable the tumour's inventory
promises either present as a contract record, or knowingly left out? And its mirror, which is the
new-joiner question this repository was asked directly: does the contract invent a variable name
the inventory has never heard of — the duplicate-name path the naming registry exists to prevent,
one file earlier than the registry can see it?

The two vocabularies COMPARED are the two that share a naming scheme: the tumour's overlay in
`governance/reference/variable_inventory/INVENTORY.yaml` and the pack's contract records
(`variable_id:` in handoff/FUNCTIONAL_CONTRACT.md). Config files name COLUMNS, which are a
different, lower-case vocabulary — mapping those is `capability_registry`'s job through
implementation refs, and guessing the correspondence here would make this report an opinion.

A REPORT, NOT A GATE, and deliberately:
"report-only first; gate later." A contract legitimately carries MORE records than the inventory
(per-cohort derivations, operational flags) and legitimately carries FEWER while it is being
drafted — so today every finding is news for the pack's owner, with the coverage class attached
so a missing `config_expressible` row (an omission somebody should own) reads differently from a
missing `engine_gap` row (expected — nothing can promise it yet). `--check` fails only when the
inputs cannot be read, never on the findings; the day the first contract reaches `approved` with
this report clean is the day a gate is worth discussing.
"""
from __future__ import annotations

import argparse
import os
import re
import sys

TOOLS = os.path.dirname(os.path.abspath(__file__))
from rwd_services import workspace_root
ROOT = str(workspace_root(__file__))

INVENTORY = os.path.join(ROOT, "governance", "reference", "variable_inventory", "INVENTORY.yaml")

# The template's placeholder spec version. A pack still carrying it is a copied template, not a
# product — `portfolio_status` reports the same fact, in the same words.
PLACEHOLDER_VERSION = "YYYYMM"


def _inventory_names(slug):
    """{VARIABLE_NAME -> coverage class} for one tumour's overlay, or None if the tumour has no
    overlay — which is a different answer from an overlay with no variables.

    RESOLVED registry-first, then through
    `variables_scaffold.SLUG_TO_OVERLAY`, the one shared mapping: the registry says `oc`
    where the inventory says `ovarian`, and a lookup by raw slug reported ovarian as having
    no overlay at all — this tool's own first run demonstrated it."""
    from rwd_tools import product_gates as pg # noqa: PLC0415
    from rwd_tools.variables_scaffold import SLUG_TO_OVERLAY # noqa: PLC0415
    doc, err = pg.read_yaml(INVENTORY)
    if err or not isinstance(doc, dict):
        raise ValueError(f"{INVENTORY}: cannot be read ({err})")
    key = pg.tumour_key_for(ROOT, slug) or SLUG_TO_OVERLAY.get(slug, slug)
    entry = (doc.get("tumours") or {}).get(key)
    if not isinstance(entry, dict):
        return None
    out = {}
    for v in (entry.get("variables") or []):
        name = str((v or {}).get("name") or "").strip()
        if name:
            out[name.upper()] = str(((v or {}).get("coverage") or {}).get("class") or "unclassified")
    return out


def _contract_names(pack):
    """{VARIABLE_ID} from the pack's contract records, or None when no contract exists yet —
    a pack before Gate 2 has nothing to compare, which is not the same as covering nothing."""
    from rwd_tools.contract_lint import read, records # noqa: PLC0415
    path = os.path.join(pack, "handoff", "FUNCTIONAL_CONTRACT.md")
    if not os.path.exists(path):
        return None
    out = set()
    for block in records(read(path)):
        m = re.search(r"(?m)^variable_id:\s*(\S+)", block)
        if m:
            out.add(m.group(1).strip().upper())
    return out


def _packs():
    """[(pack path, slug)] for every registered product whose spec version is real. Read from the
    registry — the filesystem also holds archived cuts (prostate/202603) that no gate governs."""
    from rwd_tools.product_gates import read_yaml # noqa: PLC0415
    # BOTH registries: coverage is an exercise lint, and a pack keeps owing its coverage answer
    # when it crosses the products/fixtures boundary - only the deployment surfaces narrow to
    # products/ (see product_gates.all_packs).
    out = []
    for base in ("products", "fixtures"):
        reg = os.path.join(ROOT, base, "registry.yaml")
        if not os.path.exists(reg):
            continue
        doc, err = read_yaml(reg)
        if err or not isinstance(doc, dict):
            raise ValueError(f"{base}/registry.yaml: cannot be read ({err})")
        for t in (doc.get("tumors") or doc.get("tumours") or []):
            slug = str((t or {}).get("slug") or "").strip()
            ver = str((t or {}).get("current_spec_version") or "").strip()
            if not slug or not ver or ver == PLACEHOLDER_VERSION:
                continue
            fam = str((t or {}).get("family") or "oncology").strip()
            pack = os.path.join(ROOT, base, fam, slug, ver)
            if os.path.isdir(pack):
                out.append((pack, slug))
    return out


def assess(pack, slug):
    """One pack's coverage picture, as data. Every key is present on every answer, so a caller
    never distinguishes 'clean' from 'did not look' by a missing field."""
    from rwd_tools.spec_extract import repo_relative # noqa: PLC0415
    rel = repo_relative(pack, ROOT)
    inv = _inventory_names(slug)
    con = _contract_names(pack)
    if inv is None:
        return {"pack": rel, "slug": slug, "comparable": False,
                "why": f"no overlay for {slug!r} in the variable inventory"}
    if con is None:
        return {"pack": rel, "slug": slug, "comparable": False,
                "why": "no handoff/FUNCTIONAL_CONTRACT.md yet — a pack before Gate 2 has "
                       "nothing to compare, which is not the same as covering nothing"}
    missing = {n: c for n, c in sorted(inv.items()) if n not in con}
    invented = sorted(con - set(inv))
    by_class = {}
    for n, c in missing.items():
        by_class.setdefault(c, []).append(n)
    return {"pack": rel, "slug": slug, "comparable": True,
            "inventory": len(inv), "contract": len(con),
            "missing": missing, "missing_by_class": by_class, "invented": invented}


def render(answers):
    L = ["", "=" * 92,
         "  PACK COVERAGE — the tumour's inventory vs the pack's contract records", "=" * 92,
         "  A REPORT, NOT A GATE (report-only first; a gate comes later). A missing",
         "  config_expressible row is an omission somebody should own; a missing engine_gap row",
         "  is expected — nothing can promise it yet. An INVENTED name never seen by the",
         "  inventory is the duplicate-variable path, caught one file before the naming registry.",
         ""]
    for a in answers:
        L.append(f"  {a['pack']}")
        if not a["comparable"]:
            L.append(f"      not comparable: {a['why']}")
            L.append("")
            continue
        shared = a["inventory"] - len(a["missing"])
        L.append(f"      inventory {a['inventory']} variable(s) · contract {a['contract']} "
                 f"record(s) · {shared} name(s) in BOTH · {len(a['missing'])} inventory row(s) "
                 f"with no record · {len(a['invented'])} record name(s) not in the inventory")
        if a["inventory"] and shared * 2 < a["inventory"]:
            # THE SYSTEMIC FINDING OUTRANKS THE ITEMISED ONE. Prostate's first run measured 9 of
            # 50 inventory names appearing among 202 contract records: the two vocabularies are
            # essentially UNLINKED - the contract speaks in ADS record ids (AGE, BONE_MET) and
            # the inventory in concept names (AGE_INDEX, PSA_PROG), and nothing maintained maps
            # one to the other. Read as 193 invented names that would be an alarm; read
            # correctly it is ONE fact: nobody can currently answer "which contract records
            # realise PSA_PROG?" from any file in the pack. That mapping is the improvement.
            L.append(f"      ~ the two vocabularies are largely UNLINKED ({shared} shared names) "
                     f"- the itemised lists below are one systemic fact, not "
                     f"{len(a['missing']) + len(a['invented'])} findings: no maintained mapping "
                     f"ties the pack's record ids to the inventory's concept names")
        for cls in sorted(a["missing_by_class"]):
            names = a["missing_by_class"][cls]
            L.append(f"        no contract record ({cls}, {len(names)}): "
                     + ", ".join(names[:10]) + ("" if len(names) <= 10 else " …"))
        if a["invented"]:
            L.append(f"        ! invented names ({len(a['invented'])}): "
                     + ", ".join(a["invented"][:10])
                     + ("" if len(a["invented"]) <= 10 else " …"))
            L.append("          a record name the inventory does not carry is either a new "
                     "variable nobody registered — the duplicate-name path — or a per-cohort "
                     "derivation, and the difference is a decision its owner should be able "
                     "to point at")
        L.append("")
    if not answers:
        L += ["  no pack has a real spec version — every registered product still carries the",
              "  template placeholder, so there is nothing to compare yet", ""]
    return "\n".join(L)


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__.strip().splitlines()[0])
    ap.add_argument("pack", nargs="?", help="one pack (default: every registered real-version pack)")
    ap.add_argument("--check", action="store_true",
                    help="exit non-zero only if the inputs cannot be read — findings are news, "
                         "not failures, by design (see the module docstring)")
    a = ap.parse_args(argv)
    try:
        if a.pack:
            pack = os.path.join(ROOT, *a.pack.replace("\\", "/").split("/")) \
                if not os.path.isabs(a.pack) else a.pack
            slug = os.path.basename(os.path.dirname(pack.rstrip("/\\")))
            answers = [assess(pack, slug)]
        else:
            answers = [assess(p, s) for p, s in _packs()]
    except ValueError as exc:
        print(f"  ! {exc}", file=sys.stderr)
        return 1
    print(render(answers))
    return 0


if __name__ == "__main__":
    # EVERY TOOL SETS ITS OWN CONSOLE ENCODING — an em dash under a Windows code page is
    # otherwise a UnicodeEncodeError, and this report is full of them.
    from rwd_tools.console import use_utf8
    use_utf8()
    sys.exit(main())
