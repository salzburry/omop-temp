#!/usr/bin/env python3
"""Column-level adapter EVIDENCE from a delivered profile — never an adapter decision.

    python3 platform/tools/propose_adapter.py <pack> --profile <profile.tsv>
    python3 platform/tools/propose_adapter.py <pack> --profile <p.tsv> --format json
    python3 platform/tools/propose_adapter.py <pack> --profile <p.tsv> --role baseline_ecog

WHAT THIS IS FOR. `source_adapter.py skeleton` already derives the SHAPE of the adapter from the
engine itself: which roles exist, and which columns each stage actually reads. What it cannot know
is what the vendor CALLS them, so it fills every `physical:` with the canonical name as a
placeholder. That placeholder is right for the delivery the engine grew up against and wrong for
every other one — which is the whole problem with a second dataset. `propose_source_mapping.py`
solves the same problem one level up, for TABLE names, from the same evidence. This is the column
half.

THE EVIDENCE IS THE PROFILE, NOTHING ELSE. A `data_profiler.R` TSV lists the delivered columns with
their kind, missingness, distinct count and top values. No vendor tables, no workbooks, no Spark,
no model. If the profile does not name a column, this says so and proposes nothing.

IT WRITES NOTHING. `--patch` prints a block; pasting it into `config/source_adapters.yaml` is a
person's reviewed edit, and `source_adapter.py check` then holds that file to the engine's required
roles and columns. The review block stays TODO here: proposing a name is not signing for it.

WHAT IT WILL NOT DO. It ranks on NAME and KIND and shows every count behind the ranking. It does
not decide that `deathdt` means the same event as `date_of_death`, and it does not choose between
two plausible candidates — a tie is reported as a tie, because picking one would be exactly the
judgment this file exists to route to a person. `logical_type` is proposed FROM THE DELIVERED KIND
and remains a proposal: the profiler says what the column looks like, not what it must be parsed as.

stdlib + the repo's own readers.
"""
import argparse
import json
import os
import re
import sys

TOOLS = os.path.dirname(os.path.abspath(__file__))
from rwd_services import workspace_root
ROOT = str(workspace_root(__file__))

from rwd_tools import profile_io                                                           # noqa: E402
from rwd_tools.spec_extract import repo_relative                                      # noqa: E402

# A canonical name whose tail says it carries a date. Used only to CHECK a candidate's delivered
# kind against the shape the engine expects — never to invent a column that is not in the profile.
DATEISH = re.compile(r"(date|dt|_on|_at)$")


def _norm(s):
    """Comparable form of a column name: lower, and separators removed.

    `ecog_value`, `ECOGValue` and `ecogvalue` are the same name written three ways, and a vendor
    that picks a different one is not making a different claim. Nothing here treats a normalised
    match as a decision — it is the strongest EVIDENCE this tool has, and still evidence.
    """
    return re.sub(r"[^a-z0-9]", "", str(s or "").lower())


def _tokens(s):
    """Word-ish tokens, for partial overlap: `ecogdate` -> {ecog, date} via the camel/underscore
    split the profiler's own names use. Deliberately crude: it ranks, it does not conclude."""
    s = re.sub(r"([a-z0-9])([A-Z])", r"\1_\2", str(s or ""))
    parts = [p for p in re.split(r"[^A-Za-z0-9]+", s.lower()) if p]
    out = set(parts)
    for p in parts:                       # split glued names on known tails
        m = re.match(r"^(.*?)(date|dt|value|val|code|id|num|name|type|flag|status)$", p)
        if m and m.group(1):
            out.update({m.group(1), m.group(2)})
    return out


def candidates(canonical, delivered):
    """[(physical, score, [why])] for one canonical column, best first.

    SCORE IS AN ORDERING, NOT A VERDICT, and every component is printed beside it. A reviewer who
    disagrees with the order can see exactly which signal produced it; a reviewer who cannot see the
    signals is being asked to trust a number.
    """
    want, wtok = _norm(canonical), _tokens(canonical)
    dateish = bool(DATEISH.search(str(canonical).lower()))
    out = []
    for phys, row in sorted(delivered.items()):
        why, score = [], 0.0
        if _norm(phys) == want:
            score += 10.0
            why.append("name matches exactly once normalised")
        else:
            shared = wtok & _tokens(phys)
            if shared:
                score += 3.0 * len(shared) / max(len(wtok | _tokens(phys)), 1)
                why.append(f"shares token(s) {', '.join(sorted(shared))}")
        kind = str(row.get("kind") or "").strip().lower()
        if dateish:
            if kind.startswith("date") or kind in ("timestamp", "datetime"):
                score += 2.0
                why.append(f"delivered kind {kind!r} suits a date column")
            elif kind:
                score -= 1.0
                why.append(f"delivered kind {kind!r} does NOT suit a date column")
        if score <= 0:
            continue
        # EVIDENCE A REVIEWER ACTUALLY USES, carried whether or not it moved the score. A column
        # that is 99% missing may still be the right name and the wrong column to build on.
        miss, dist = row.get("pct_missing"), row.get("distinct")
        if miss not in (None, ""):
            why.append(f"{miss}% missing")
        if dist not in (None, ""):
            why.append(f"{dist} distinct")
        # `top_values` IS DELIBERATELY NOT READ, and its absence is the point. It is the one
        # column in a delivered profile that carries observed vendor CONTENTS rather than a
        # statistic about them, and governance/WORKFLOW.md rule 5 draws the line exactly
        # there: "AI must not ingest vendor-originated or vendor-derived content. Verdicts
        # cross the boundary; contents do not." GSK R&D policy sec.9 classifies individual
        # human data as Sensitive Personal Information and states no IHD may be processed by
        # an LLM outside Cogito - and "even data that appears anonymised may still be
        # classified as IHD".
        #
        # This tool prints its evidence, and printed evidence is pasted into chat windows and
        # read by agents. `kind`, `pct_missing` and `distinct` are aggregates - shape, not
        # contents - and they cross. A list of the most frequent VALUES in a patient-level
        # column does not, however harmless a particular column looks. A reviewer who needs
        # to see values reads the profile itself, on the approved platform.
        out.append((phys, round(score, 2), why))
    return sorted(out, key=lambda x: (-x[1], x[0]))


def _logical_type(row):
    """The type to PROPOSE from the delivered kind. A proposal: the profiler reports what the
    column looks like in this cut, which is not the same as what the contract requires it to be."""
    kind = str((row or {}).get("kind") or "").strip().lower()
    if kind.startswith("date"):
        return "date"
    if kind in ("int", "integer", "bigint", "long"):
        return "integer"
    if kind in ("double", "float", "decimal", "numeric"):
        return "number"
    if kind in ("bool", "boolean"):
        return "boolean"
    return "string" if kind else None


def propose(pack, profile_path, only_role=None):
    """{role: {canonical: {...}}} — the evidence, per role, per column. Reads; writes nothing."""
    from rwd_tools import source_adapter as sa                                             # noqa: PLC0415
    cfg, ev = sa._engine(pack)
    required = ev.required_columns(cfg)
    tables, _cuts = profile_io.load(profile_path)

    out = {}
    for role in sorted(required):
        if only_role and role != only_role:
            continue
        # THE BARE SOURCE NAME, not the fully-qualified one. `cfg.table(role)` interpolates the
        # runtime schema and snapshot suffix, so on a pack whose bindings are still REPLACE_ME it
        # returns `REPLACE_ME.cota_baseline_ecog_REPLACE_ME` and matches nothing. A pack with
        # unresolved runtime bindings is EXACTLY when somebody writes an adapter, so keying on
        # the declared source name is what makes this usable at the moment it is needed.
        declared = (cfg.sources or {}).get(role)
        try:
            physical = cfg.table(role)
        except Exception:                        # noqa: BLE001 - unresolvable is not fatal here
            physical = declared
        # `profile_io.CUT` is the ONE definition of a snapshot suffix; three copies of that regex
        # had already drifted before it was made single.
        base = profile_io.CUT.sub("", str(declared or physical or "").rsplit(".", 1)[-1])
        delivered = tables.get(base) or tables.get(str(physical or "")) or {}
        entry = {"physical_table": physical, "profiled_table": base if delivered else None,
                 "columns": {}}
        if not delivered:
            # THE TABLE ITSELF IS ABSENT FROM THE EVIDENCE. Reported once, here, rather than as a
            # missing candidate on every column - which would read as "these columns are unmatched"
            # when the truth is that nothing about this table was measured.
            entry["note"] = (f"the profile carries no table {base!r} — nothing can be proposed for "
                             f"this role until the delivery is profiled, and every column below "
                             f"would otherwise report as unmatched for the wrong reason")
            out[role] = entry
            continue
        for canonical in sorted(required[role]):
            ranked = candidates(canonical, delivered)
            best = ranked[0] if ranked else None
            tie = bool(len(ranked) > 1 and ranked[1][1] == ranked[0][1])
            entry["columns"][canonical] = {
                "proposed": None if (best is None or tie) else best[0],
                "logical_type": None if (best is None or tie)
                else _logical_type(delivered.get(best[0])),
                "delivered_kind": None if best is None
                else str((delivered.get(best[0]) or {}).get("kind") or ""),
                "tie": tie,
                "candidates": [{"physical": p, "score": s, "why": w} for p, s, w in ranked[:4]],
            }
        out[role] = entry
    return out


def render(pack, found):
    L = [f"ADAPTER CANDIDATES — {repo_relative(pack, ROOT)}", "",
         "  Evidence from the delivered profile. Nothing here is a decision: paste what you accept",
         "  into config/source_adapters.yaml, then `source_adapter.py check <pack>`.", ""]
    for role, e in sorted(found.items()):
        L.append(f"  {role}  ->  {e.get('physical_table')}")
        if e.get("note"):
            L.append(f"      ! {e['note']}")
            L.append("")
            continue
        for canonical, c in sorted(e["columns"].items()):
            if c["proposed"]:
                L.append(f"      {canonical:<24} {c['proposed']}   "
                         f"[{c['delivered_kind']} -> {c['logical_type']}]")
            elif c["tie"]:
                names = ", ".join(x["physical"] for x in c["candidates"][:2])
                L.append(f"      {canonical:<24} TIE — {names}; this tool will not choose")
            else:
                L.append(f"      {canonical:<24} no candidate in the profile")
            for cand in c["candidates"][:2]:
                L.append(f"          {cand['physical']}  ({cand['score']})  "
                         + "; ".join(cand["why"])[:96])
        L.append("")
    unresolved = sum(1 for e in found.values() for c in e.get("columns", {}).values()
                     if not c["proposed"])
    L.append(f"  {len(found)} role(s); {unresolved} column(s) with no single candidate — each is a "
             f"person's call, not a gap in the profile.")
    return "\n".join(L)


def patch(found):
    """The `adapters:` block to paste, with every unresolved column left TODO."""
    L = ["# PROPOSED from the delivered profile — review every line, then paste into",
         "# config/source_adapters.yaml. `review:` stays TODO: proposing a name is not signing it.",
         "adapters:"]
    for role, e in sorted(found.items()):
        L.append(f"  - logical_role: {role}")
        L.append(f"    physical_table: {e.get('physical_table')}")
        L.append("    required_columns:")
        for canonical, c in sorted(e.get("columns", {}).items()):
            phys = c["proposed"] or "TODO"
            lt = c["logical_type"] or "TODO"
            L.append(f"      {canonical}: {{physical: {phys}, logical_type: {lt}, "
                     f"accepted_physical_types: [TODO], parser: null}}")
        L.append("    review: {status: pending, approved_by: TODO, approval_date: TODO}")
    return "\n".join(L)


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__.strip().splitlines()[0])
    ap.add_argument("pack")
    ap.add_argument("--profile", required=True, metavar="TSV",
                    help="a data_profiler.R profile of the delivery this pack reads")
    ap.add_argument("--role", default=None, help="one logical role only")
    ap.add_argument("--format", choices=("text", "json"), default="text")
    ap.add_argument("--patch", action="store_true",
                    help="print the adapters: block to paste; still writes nothing")
    a = ap.parse_args(argv)

    pack = a.pack if os.path.isabs(a.pack) else os.path.join(ROOT, a.pack)
    if not os.path.isdir(pack):
        sys.exit(f"{a.pack}: no such product directory. Nothing was proposed — this is a refusal, "
                 f"not an empty result.")
    found = propose(pack, a.profile, a.role)
    if a.format == "json":
        print(json.dumps(found, indent=1, ensure_ascii=False))
    elif a.patch:
        print(patch(found))
    else:
        print(render(pack, found))
    # ALWAYS 0. This is evidence, not a gate: `source_adapter.py check` is what holds a COMMITTED
    # adapter to the engine, and a second thing failing on the same facts would be a gate nobody
    # declared.
    return 0


if __name__ == "__main__":
    from rwd_tools.console import use_utf8
    use_utf8()
    raise SystemExit(main())
