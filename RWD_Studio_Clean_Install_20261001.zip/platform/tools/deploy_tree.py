#!/usr/bin/env python3
"""The production deployment tree — an ALLOWLIST, not the repository minus three globs.

`databricks.yml` syncs from the repo root and excludes only `*.pdf`, `*_rdap.R`, `*_rdap.py`. So a
production workspace receives spec stand-ins, reference material, pipeline outputs,
handoff drafting artifacts, sandbox experiments, every historical pack, and vendor documentation —
none of which the build reads. That is unnecessary exposure in the one environment where exposure
matters most, and it sits badly beside a framework whose whole source-governance model is about
controlling which material reaches whom.

    python3 platform/tools/deploy_tree.py --out build/deploy
    python3 platform/tools/deploy_tree.py --out build/deploy --git-commit $(git rev-parse HEAD)

THIS DOES NOT DEPLOY ANYTHING AND RUNS NOTHING. It copies files into a local directory. No workspace
is contacted, no bundle is deployed, no job is created or triggered; `databricks bundle deploy` is a
separate, human act against the tree this produces. Everything worth checking about the tree — what
is in it, what is not, and whether its recorded releasability matches a live evaluation — is checked
offline in `platform/tests/test_governance.py`, with no workspace and no Spark. That is deliberate:
the packaging has to be verifiable BEFORE anyone runs a pipeline end to end, because its whole point
is deciding what production is allowed to see.

WHAT GOES IN — the RUNTIME:

  platform/{engine,engine-r,databricks,VERSION}   the shared runtime
  platform/tools/<only what the entrypoints import>  via `runtime_tools`, derived with ast
  databricks.yml, resources/products.yml         the deployment definition
  engine.config.SHARED_ASSETS                    registry, catalog, audiences, dashboard, tfl
  <each deployed pack>'s ACTIVE config graph      via product_gates.pack_yaml
  RELEASE_EVIDENCE.yaml                          the release verdict, bound to a commit

...and each pack's AUDIT BUNDLE — source_refs, maturity, both approval records, the contract, the
decision and QC registers, engine gaps, dispositions, the Gate 3 verdicts. `--evidence-out DIR`
writes those OUTSIDE the runtime tree instead. They answer "what was approved" and the runtime reads
almost none of them; they also carry the source-provenance prose a runtime package has no business
holding. Two audiences, two permissions, and splitting them is the default worth choosing when the
tree is going to a workspace rather than an audit store. Wherever they land they are listed per pack
in RELEASE_EVIDENCE.yaml, and when they are IN the tree `tree_sha256` covers their bytes.

"almost none" is the exception, and it is `RUNTIME_EVIDENCE` below: the Gate 6 release approval is
read by the RUN, so it is deployed into the tree either way and archived either way. Gates 1-4 do not
need this — their evidence stays out and the tree carries `RELEASE_EVIDENCE.yaml`'s recorded verdict
instead — but Gate 6 names a BUILD, which does not exist when the tree is packaged, so nothing
recorded at build time can stand in for it.

WHAT STAYS OUT: `reference/`, `prog_spec/`, spec stand-ins, `spec_pipeline/`, `sandbox/`, `intake/`,
`platform/tests`, `TUMOR_TEMPLATE`, every development tool the runtime does not import, and every
pack that is not being deployed.

VALIDATE THE TREE BEFORE YOU SHIP IT:

    python3 platform/tools/deploy_tree.py --check-tree build/deploy

`repo_hygiene.py --check` cannot do this — it reads the git INDEX, and a generated tree has no `.git`;
run from the repository it skips `build/` as generated. So a file dropped into a built tree by hand
was caught by nothing until the runtime refused to publish, which is integrity, not containment.
`--check-tree` re-walks the tree, re-applies the refusals, and compares the inventory and digest
against what the build recorded. Run it immediately before packaging.

WHY RELEASABILITY IS EVALUATED HERE. `run_rwdp.py` calls `source_manifest.releasable()` at runtime,
and Gate 1 inside it requires that any material naming a repo path exists and — once reviewed — still
hashes to its recorded sha256. The materials that name repo paths are specification inputs, which this
tree exists to keep out. So the evaluation runs against the full repository and is written to
`RELEASE_EVIDENCE.yaml`, bound to a git commit: regenerated from the real evaluation every build,
recording WHY each pack is blocked, and refused by the runtime unless its commit matches the one the
job was given. Same shape as `spec_digest` and `config_bundle_sha256` — a derived value bound to what
it was derived from.
"""
import argparse
import ast
import hashlib
import os
import shutil
import subprocess
import sys

import yaml

from rwd_tools.spec_extract import repo_relative                                  # noqa: E402

from rwd_tools import product_gates as pg                                          # noqa: E402
from rwd_tools import repo_hygiene as rh                                           # noqa: E402
from rwd_tools import source_manifest as sm                                        # noqa: E402
from engine.config import SHARED_ASSETS                             # noqa: E402

MARKER = ".deploy_tree"    # written into every tree; see _prepare_out

# The evidence FILENAME is `source_manifest.RELEASE_EVIDENCE`, beside `releasable` and read back by
# `source_manifest.evidence_verdict`. Not re-spelled here even as an alias: this writes the file the
# runner reads, and two spellings of that name is a deployment that writes evidence nothing looks at.

# Runtime code. `tests` and `TUMOR_TEMPLATE` are development material — the template is a pack to COPY
# when onboarding, not something the build reads. `tools` is NOT here: only the modules the runner
# imports go, and `runtime_tools` derives which those are.
PLATFORM = ("engine", "engine-r", "databricks", "VERSION")

# Where the runtime's imports start. Everything under `platform/databricks/` is an entrypoint the job
# invokes; the engine imports no tool module (a test asserts it), so this is the whole seed.
ENTRYPOINTS = "databricks"
TOOLS = "tools"


# THE DEPLOYMENT-APPROVED ARTIFACT ROOT. `artifact_root` is a job parameter a run-now caller may
# override — Databricks says plainly that job parameters are not security controls — so the tree
# records the root the deployment approved and a prod run refuses any other (audit 7).
APPROVED_ARTIFACT_ROOT = ""

def runtime_module_files(root):
    """Derive installed runtime imports from the distribution's existing modules."""
    import importlib.util
    import json
    from pathlib import Path
    import tomllib
    from rwd_services import package_source_files
    root = Path(root).resolve()
    manifest = root / "RUNTIME_PACKAGE.json"
    if not (root / "pyproject.toml").is_file() and manifest.is_file():
        return {name: value["source"] for name, value in
                json.loads(manifest.read_text(encoding="utf-8"))["modules"].items()}
    project = tomllib.loads((root / "pyproject.toml").read_text(encoding="utf-8"))
    declared_files = {path.as_posix() for path in package_source_files(root)}
    modules = {}
    for package, directory in project["tool"]["setuptools"]["package-dir"].items():
        if package == "rwd_assets":
            continue
        for path in (root / directory).glob("*.py"):
            if path.relative_to(root).as_posix() not in declared_files:
                raise ValueError("Runtime module is outside the validated package manifest.")
            name = package if path.stem == "__init__" else package + "." + path.stem
            modules[name] = path
    dependencies = {}
    for name, path in modules.items():
        found = set()
        for node in ast.walk(ast.parse(path.read_text(encoding="utf-8-sig"))):
            if isinstance(node, ast.Import):
                found.update(alias.name for alias in node.names)
            elif isinstance(node, ast.ImportFrom):
                base = node.module or ""
                if node.level:
                    package = name if path.stem == "__init__" else name.rpartition(".")[0]
                    base = importlib.util.resolve_name("." * node.level + base, package)
                found.add(base)
                found.update(base + "." + alias.name for alias in node.names)
            elif isinstance(node, ast.Call) and ast.unparse(node.func) in {"importlib.import_module", "__import__"} and node.args:
                if isinstance(node.args[0], ast.Constant) and isinstance(node.args[0].value, str):
                    found.add(node.args[0].value)
        parents = {".".join(name.split(".")[:number]) for number in range(1, len(name.split(".")))}
        dependencies[name] = (found | parents) & modules.keys()
    pending = [name for name in modules if name in {"engine", "rwd_databricks"}
               or name.startswith(("engine.", "rwd_databricks."))]
    selected = set()
    while pending:
        name = pending.pop()
        if name not in selected:
            selected.add(name)
            pending.extend(dependencies[name] - selected)
    return {name: modules[name].relative_to(root).as_posix() for name in sorted(selected)}


def runtime_tools(root):
    """Canonical tool imports, including package initialization, in the runtime closure."""
    return sorted("__init__" if name == "rwd_tools" else name.removeprefix("rwd_tools.")
                  for name in runtime_module_files(root) if name == "rwd_tools" or name.startswith("rwd_tools."))


def build_runtime_package(root, out):
    """Build a reviewed runtime projection with the standard package backend."""
    import json
    from pathlib import Path
    import tempfile
    import tomllib
    import zipfile
    root, out = Path(root).resolve(), Path(out).resolve()
    project_bytes = (root / "pyproject.toml").read_bytes()
    project = tomllib.loads(project_bytes.decode("utf-8"))
    modules = runtime_module_files(root)
    declared = project["tool"]["setuptools"]["package-dir"]
    packages = {name: declared[name] for name in declared if name in modules}
    packages["rwd_assets"] = "."
    resources = ("platform/VERSION", "platform/requirements.txt", "platform/CAPABILITIES.md", "platform/capabilities.yaml", "GLOSSARY.md")
    source_hashes = {"pyproject.toml": hashlib.sha256(project_bytes).hexdigest()}
    with tempfile.TemporaryDirectory(prefix="rwd-runtime-wheel-") as temporary:
        stage = Path(temporary) / "source"
        stage.mkdir()
        if any(not (stage / directory).resolve().is_relative_to(stage) for directory in packages.values()):
            raise ValueError("Runtime package mapping would escape its private build source.")
        for relative in sorted(set(modules.values()) | set(resources) | {"platform/engine/config_schema.json"}):
            payload = (root / relative).read_bytes()
            source_hashes[relative] = hashlib.sha256(payload).hexdigest()
            target = stage / relative
            if not target.resolve().is_relative_to(stage):
                raise ValueError("Runtime package output would escape its private build source.")
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes(payload)
        asset_paths = [*resources, "pyproject.toml"]
        for path in sorted((root / "governance/schemas").glob("*")):
            if path.suffix in {".json", ".yaml"}:
                relative = path.relative_to(root).as_posix()
                payload = path.read_bytes()
                source_hashes[relative] = hashlib.sha256(payload).hexdigest()
                target = stage / relative
                target.parent.mkdir(parents=True, exist_ok=True)
                target.write_bytes(payload)
                asset_paths.append(relative)
        text = ("[build-system]\nrequires = " + json.dumps(project["build-system"]["requires"]) +
                '\nbuild-backend = "setuptools.build_meta"\n\n[project]\nname = "rwd-platform"\n' +
                'dynamic = ["version", "dependencies"]\nrequires-python = ' + json.dumps(project["project"]["requires-python"]) +
                '\n\n[tool.setuptools]\ninclude-package-data = false\npackages = ' + json.dumps(sorted(packages)) +
                '\n\n[tool.setuptools.package-dir]\n' + ''.join(json.dumps(name) + ' = ' + json.dumps(directory) + '\n' for name, directory in sorted(packages.items())) +
                '\n[tool.setuptools.package-data]\nengine = ["config_schema.json"]\nrwd_assets = ' + json.dumps(asset_paths) +
                '\n\n[tool.setuptools.dynamic]\nversion = {file="platform/VERSION"}\ndependencies = {file="platform/requirements.txt"}\n')
        (stage / "pyproject.toml").write_text(text, encoding="utf-8", newline="\n")
        wheels = out / "wheels"
        wheels.mkdir(exist_ok=True)
        if list(wheels.iterdir()):
            raise ValueError("Build the runtime wheel into a new empty artifact directory.")
        result = subprocess.run([sys.executable, "-I", "-m", "pip", "wheel", str(stage), "--no-deps", "--no-build-isolation", "--no-index",
                                 "--wheel-dir", str(wheels), "--disable-pip-version-check"],
                                cwd=temporary, capture_output=True, text=True, encoding="utf-8", timeout=180,
                                env=dict(os.environ, SOURCE_DATE_EPOCH="315532800", PIP_NO_INDEX="1"))
        if result.returncode:
            raise ValueError("Runtime wheel construction failed: " + (result.stderr or result.stdout)[-3000:])
    wheel, = wheels.glob("*.whl")
    with zipfile.ZipFile(wheel) as archive:
        members = {name: hashlib.sha256(archive.read(name)).hexdigest() for name in archive.namelist()
                   if not name.endswith("/RECORD")}
    module_records = {}
    for name, relative in modules.items():
        member = name.replace(".", "/") + ("/__init__.py" if Path(relative).name == "__init__.py" else ".py")
        if members.get(member) != source_hashes[relative]:
            raise ValueError("Runtime wheel differs from reviewed source: " + relative)
        module_records[name] = {"source": relative, "member": member, "sha256": source_hashes[relative]}
    for relative, digest in source_hashes.items():
        if hashlib.sha256((root / relative).read_bytes()).hexdigest() != digest:
            raise ValueError("Runtime source changed during package construction: " + relative)
    document = {"version": 1, "distribution": "rwd-platform", "wheel": wheel.relative_to(out).as_posix(),
                "wheel_sha256": hashlib.sha256(wheel.read_bytes()).hexdigest(),
                "modules": module_records, "members": members,
                "scope": "Reviewed runtime code projection; no product data, authoring templates, model history or evaluation corpora."}
    (out / "RUNTIME_PACKAGE.json").write_text(json.dumps(document, sort_keys=True, indent=2) + "\n", encoding="utf-8", newline="\n")
    return ["RUNTIME_PACKAGE.json", wheel.relative_to(out).as_posix()]


def check_runtime_package(out):
    """Check the constructed artifact and every member without importing its code."""
    import json
    from pathlib import Path, PurePosixPath
    import zipfile
    try:
        root = Path(out).resolve()
        doc = json.loads((root / "RUNTIME_PACKAGE.json").read_text(encoding="utf-8"))
        relative = PurePosixPath(doc["wheel"])
        if relative.is_absolute() or ".." in relative.parts or relative.parts[0] != "wheels":
            raise ValueError("Runtime wheel path is outside its artifact directory.")
        wheel = root / relative
        if wheel.is_symlink() or not wheel.resolve().is_relative_to(root) or hashlib.sha256(wheel.read_bytes()).hexdigest() != doc["wheel_sha256"]:
            raise ValueError("Runtime wheel bytes differ from the reviewed artifact.")
        with zipfile.ZipFile(wheel) as archive:
            members = {name: hashlib.sha256(archive.read(name)).hexdigest() for name in archive.namelist() if not name.endswith("/RECORD")}
        if members != doc["members"]:
            raise ValueError("Runtime wheel member inventory differs from its reviewed manifest.")
        for name, record in doc["modules"].items():
            if members.get(record["member"]) != record["sha256"]:
                raise ValueError("Runtime source/member mismatch: " + name)
        if any("TUMOR_TEMPLATE/" in name or "experiments/agent/" in name or "experiments/portal/" in name for name in members):
            raise ValueError("Authoring assets must not be included in a runtime artifact.")
        return []
    except (OSError, ValueError, KeyError, TypeError, AttributeError, zipfile.BadZipFile) as error:
        return [str(error)]


# Per-pack governance evidence. These are what `releasable()` and the runner read: sponsor-authored
# records ABOUT the source, never the source itself. `source_refs.yaml` is metadata — ids, statuses,
# checksums, classifications — and carries no specification text.
PACK_EVIDENCE = ("source_refs.yaml",
                 "handoff/MATURITY.yaml",
                 "handoff/CONTRACT_APPROVAL.yaml",
                 "handoff/CONFIGURATION_APPROVAL.yaml",
                 # Gate 6. Absent, the audit bundle recorded who approved the CONTRACT and the
                 # CONFIGURATION and not who approved the RELEASE — the one approval that is about
                 # the data anybody actually received.
                 "handoff/RELEASE_APPROVAL.yaml",
                 "handoff/FUNCTIONAL_CONTRACT.md",
                 "handoff/SPEC_QC_FINDINGS.md",
                 "handoff/DECISIONS.md",
                 # WHICH REGISTRY CONCEPT A PERSON CONFIRMED EACH VARIABLE REALISES. Sponsor-authored
                 # and about meaning rather than about source, so it belongs with the other
                 # governance evidence — and without it a deployed tree carries a `semantic.yaml`
                 # binding a registry concept with no record of who confirmed it or against what.
                 # `semantic_manifest` records the file's digest into release identity, so a tree
                 # missing it computes `absent` where the checkout computed a digest, exactly the
                 # failure `config/source_adapters.yaml` had.
                 "handoff/TEMPLATE_RULINGS.yaml",
                 # ...and who signed for what the variables MEAN. Release identity records
                 # the binding digest; this records the person, and an audit bundle with
                 # the one and not the other says a meaning was stated without saying it
                 # was agreed.
                 "handoff/SEMANTIC_APPROVAL.yaml",
                 "handoff/ENGINE_GAPS.md",
                 "handoff/spec_dispositions.yaml",
                 # THE TYPED SOURCE BINDING, and it is runtime input as much as evidence. It is
                 # NOT part of `pack_yaml`'s config graph — the graph is what data_product.yaml
                 # composes, and the adapter is read separately by `source_adapter.check` — so
                 # without naming it here the deployment tree simply did not have it. The runner
                 # then found no file, read that as `no_claim`, and bound sources the legacy way:
                 # a developer's full checkout enforced the reviewed adapter and the production
                 # tree silently did not. Same class of silent fallback the adapter exists to end.
                 "config/source_adapters.yaml")

# ...of which THIS SUBSET is also RUNTIME INPUT, and so is deployed into the tree even when the
# bundle goes elsewhere. A SUBSET of `PACK_EVIDENCE`, asserted as one in `test_governance`, so there
# is still one list of what evidence is and this only says which of it the run needs to read.
#
# Everything else in the bundle answers "what was approved" for an auditor, and the tree deliberately
# cannot re-derive Gates 1-4 from it — that is what `RELEASE_EVIDENCE.yaml` records instead. Gate 6
# is the one that cannot work that way: the approval names a BUILD, so it does not exist when the
# deployment is built, and no recorded verdict can stand in for it. `run_rwdp.py` opens it from
# `<runtime root>/<pack>/handoff/RELEASE_APPROVAL.yaml` at run time.
#
# Under `--evidence-out` it went to the bundle directory and never into the tree, so the runner
# looked for it where it was not. Not a publication hazard — Gate 6 fails closed, so the effect is a
# release that cannot complete — but a promotion path built on top of it would have been unreachable.
# It is safe HERE, unlike the rest of the bundle, because it holds no source-provenance prose: six
# fields, all of them a name, a date, a build id or a digest.
RUNTIME_EVIDENCE = ("handoff/RELEASE_APPROVAL.yaml",
                    # ...and the adapter, for the same reason: under `--evidence-out` the bundle
                    # leaves the tree entirely, so a binding the run must read has to be copied
                    # into the tree as well or the run loses it exactly when the deployment is
                    # most carefully separated.
                    "config/source_adapters.yaml")

# The bundle definition. The SHARED product assets are NOT listed here — they come from
# `engine.config.SHARED_ASSETS`, which is what the runner reads them through. Walking
# `products/_reporting` for `*.yaml` and naming `products/registry.yaml` separately would be a second
# description of one set, and would miss `metadata/catalog.yaml` — which every governed run requires
# for dictionary and dashboard generation.
ROOT_FILES = ("databricks.yml", os.path.join("resources", "products.yml"),
              # THE DEV-PUBLISH POLICY, because the RUNNER reads it from the tree it is running
              # out of. `engine.release.dev_publish_refusal` resolves it against the deployment
              # root, so a tree built without it refuses every non-release-ready publish - the
              # feature would have been inert in exactly the environment it was written for, and
              # fail-closed would have hidden that it was never deployed at all.
              os.path.join("governance", "publish_targets.yaml"))

# DIRECTORIES that must never appear in the tree. Asserted after the build rather than only relied on
# by construction: an allowlist that grows a wildcard is how one of these creeps back. The file KINDS
# that may not be here are not listed again — `forbidden_in` takes them from
# `repo_hygiene.NEVER_COMMITTED`, which is the stricter question of what may be committed at all.
FORBIDDEN = ("/reference/", "/prog_spec/", "/spec_pipeline/", "/sandbox/", "/intake/",
             "/TUMOR_TEMPLATE/", "/platform/tests/")


def _copy(src, dst):
    os.makedirs(os.path.dirname(dst), exist_ok=True)
    shutil.copy2(src, dst)


def _prepare_out(out):
    """Make `out` an empty directory — WITHOUT ever recursively deleting something this tool did not
    create.

    This was `if os.path.exists(out): shutil.rmtree(out)`, guarded only by the CLI's "inside the
    checkout" check, which tests `startswith(root + os.sep)` and is therefore FALSE for the checkout
    root itself, for any ancestor of it, and for the home directory. `--out .` from the repo root
    would have deleted the repository. Nothing about the tool's purpose requires deleting anything an
    operator happened to name.

    So a tree carries a MARKER file, and only a directory holding that marker may be replaced.
    Anything else that exists is refused, which costs an operator one `rm -rf` they chose themselves.
    """
    if os.path.lexists(out):
        if not os.path.isdir(out) or os.path.islink(out):
            raise SystemExit(f"--out {out} exists and is not a directory. Refusing.")
        if not os.path.exists(os.path.join(out, MARKER)):
            raise SystemExit(
                f"--out {out} already exists and was not created by deploy_tree.py (no {MARKER}). "
                f"Refusing to delete it — this tool replaces its OWN output and nothing else. "
                f"Remove it yourself, or choose an empty path.")
        shutil.rmtree(out)
    os.makedirs(out)
    with open(os.path.join(out, MARKER), "w", encoding="utf-8", newline="\n") as fh:
        fh.write("Written by platform/tools/deploy_tree.py. Its presence is what permits this "
                 "directory to be replaced by a later build.\n")


def deployed_files(out):
    """Every file in a deployment tree that the digest covers, repo-relative and sorted.

    It WALKS rather than trusting a recorded list, so a file ADDED to the tree after packaging changes
    the digest. A recorded inventory would only notice edits to files it already knew about, which is
    the weaker half of the property.

    Excluded, and each for a reason rather than convenience:
      * `RELEASE_EVIDENCE.yaml` and the marker — the record, not the subject;
      * `__pycache__` / `*.pyc` — CREATED BY RUNNING. The notebook imports the tools inside the tree,
        so including bytecode would make the first import invalidate the release, and the gate would
        be switched off within a day. Nothing the build reads is a `.pyc`;
      * dot-entries — deploy tooling writes its own metadata beside the files it syncs.
    """
    out_abs = os.path.abspath(out)
    found = []
    for dirpath, dirs, files in os.walk(out_abs):
        dirs[:] = [d for d in dirs if d != "__pycache__" and not d.startswith(".")]
        for f in files:
            if f.endswith(".pyc") or f.startswith(".") or f in (sm.RELEASE_EVIDENCE, MARKER):
                continue
            found.append(repo_relative(os.path.join(dirpath, f), out_abs))
    return sorted(found)


def tree_digest(out, files=None):
    """sha256 over the tree's CONTENT — every deployed path and its bytes, in sorted order.

    The commit binding alone proves nothing about the bytes: `--git-commit` was a free string, so a
    tree built from a dirty checkout and stamped with a clean approved SHA matched at runtime and
    published a configuration that commit does not identify. Editing the generated tree after the
    evidence was written had the same effect.

    Digesting the PATH as well as the bytes matters — content-only would be blind to a file moving,
    and a config read from a different path is a different deployment.

    `files` exists only so a caller that just enumerated the tree need not walk it twice. The build
    and the runtime both go through `deployed_files`, so there is one definition of what is covered:
    two enumerations agreeing today is exactly the shape that produces a digest which cannot be
    reproduced by the side that has to verify it.
    """
    out_abs = os.path.abspath(out)
    h = hashlib.sha256()
    for rel in (files if files is not None else deployed_files(out_abs)):
        h.update(rel.encode("utf-8") + b"\0")
        with open(os.path.join(out_abs, rel.replace("/", os.sep)), "rb") as fh:
            for chunk in iter(lambda fh=fh: fh.read(1 << 20), b""):
                h.update(chunk)
        h.update(b"\0")
    return h.hexdigest()


def git_state(root):
    """(HEAD sha, [dirty paths]) — or (None, []) outside a work tree. Never raises: a packaging tool
    that crashes on a missing `git` is worse than one that reports it cannot verify."""
    def run(*args):
        try:
            p = subprocess.run(("git", "-C", root) + args, capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=30)
        except (OSError, subprocess.SubprocessError):
            return None
        return p.stdout if p.returncode == 0 else None
    head = run("rev-parse", "HEAD")
    if head is None:
        return None, []
    status = run("status", "--porcelain") or ""
    return head.strip(), sorted(ln[3:].strip() for ln in status.splitlines() if ln.strip())


def build(root, out, products=None, git_commit="", evidence_out=None):
    """Write the tree; return the list of repo-relative files it contains.

    `evidence_out` sends each pack's AUDIT BUNDLE to a separate directory instead of into the tree —
    see the module docstring. The tree still records what the bundle is and that it was written.
    """
    # THE BUNDLE'S OWN GATE, BEFORE ANYTHING IS COPIED. This took packs from `bundle_products.entries`
    # and then copied the COMMITTED `resources/products.yml` without asking whether it still matches
    # the registry and the activation file — so a clean commit carrying a stale or hand-edited
    # generated resource packaged cleanly. CI catches that, and this repository merges before CI runs.
    #
    # Calling the existing authorities rather than writing a third one: `activation_errors` owns
    # `schedule_enabled ⇒ releasable`, and `render` owns what the generated file should contain.
    from rwd_tools import bundle_products as bp
    bad = bp.activation_errors(root)
    if bad:
        raise SystemExit("REFUSING to package: activation is not legal:\n"
                         + "\n".join(f"  {e}" for e in bad))
    generated = os.path.join(root, bp.OUT)
    if not os.path.exists(generated):
        raise SystemExit(f"REFUSING to package: {bp.OUT} has not been generated — "
                         f"run python3 platform/tools/bundle_products.py")
    with open(generated, encoding="utf-8") as fh:
        if fh.read() != bp.render(root):
            raise SystemExit(f"REFUSING to package: {bp.OUT} is STALE — it does not match the registry "
                             f"plus activation. The deployed job set would not be the governed one. "
                             f"Run python3 platform/tools/bundle_products.py")

    _prepare_out(out)
    if evidence_out:
        _prepare_out(evidence_out)
    packs = products if products is not None else [
        os.path.join("products", f, s, v).replace(os.sep, "/")
        for s, f, v, _c in bp.entries(root)]
    written = []

    for name in PLATFORM:
        src = os.path.join(root, "platform", name)
        if os.path.isdir(src):
            for dirpath, _dirs, files in os.walk(src):
                for f in files:
                    if f.endswith((".pyc",)) or "__pycache__" in dirpath:
                        continue
                    full = os.path.join(dirpath, f)
                    rel = repo_relative(full, root)
                    _copy(full, os.path.join(out, rel))
                    written.append(rel)
        elif os.path.isfile(src):
            rel = repo_relative(src, root)
            _copy(src, os.path.join(out, rel))
            written.append(rel)

    # ...and the tool modules the entrypoints import, and only those.
    for mod in runtime_tools(root):
        rel = f"platform/{TOOLS}/{mod}.py"
        _copy(os.path.join(root, rel), os.path.join(out, rel))
        written.append(rel)

    for rel in ROOT_FILES:
        src = os.path.join(root, rel)
        if os.path.exists(src):
            _copy(src, os.path.join(out, rel))
            written.append(rel.replace(os.sep, "/"))

    # The shared product assets, from the ONE definition the runner reads them through. A missing one
    # is FATAL rather than skipped: `engine.config.SHARED_ASSETS` names what the run requires, so a
    # tree that quietly ships without it is a product that builds its ADS and then cannot publish.
    for name, rel_in_products in SHARED_ASSETS.items():
        rel = f"products/{rel_in_products}"
        full = os.path.join(root, rel.replace("/", os.sep))
        if not os.path.exists(full):
            raise SystemExit(f"shared asset {name} ({rel}) does not exist — the run reads it, so a "
                             f"tree without it is not deployable.")
        _copy(full, os.path.join(out, rel.replace("/", os.sep)))
        written.append(rel)

    audit = {}          # pack -> the evidence files, kept apart from the config graph as they are copied
    for pack in packs:
        # The ACTIVE config graph, through the resolver the binder and Gate 4 already use — never a
        # directory listing, which would sweep in archived variants and drafts the build never reads.
        for rel_in_pack in pg.pack_yaml(os.path.join(root, pack)):
            full = os.path.join(root, pack, rel_in_pack) if not os.path.isabs(rel_in_pack) \
                else rel_in_pack
            if not os.path.exists(full):
                full = rel_in_pack
            rel = repo_relative(full, root)
            _copy(full, os.path.join(out, rel))
            written.append(rel)
        # ...AND THE SEMANTIC BINDING, which `pack_yaml` deliberately does not carry.
        #
        # The build never reads `config/semantic.yaml`, so it is correctly outside the config graph
        # and outside `config_bundle_sha256`. But the RUN records `semantic_sha256` into its
        # configuration identity, computed from the pack on disk — and a deployed tree missing the
        # file computes "none" where the checkout computed a digest. `candidate_binding_blockers`
        # compares every key in that identity, so a tree without this refuses to promote ANY
        # candidate, with a message about an unrecorded binding rather than a missing file. It is
        # also the pack's own statement of what its variables MEAN, which a deployment that
        # publishes those variables has no business dropping.
        sem = os.path.join(root, pack, *pg.SEMANTIC_YAML.split("/"))
        if os.path.exists(sem):
            rel = repo_relative(sem, root)
            _copy(sem, os.path.join(out, rel))
            written.append(rel)
        # ...and the AUDIT BUNDLE, collected as it is written rather than sieved back out of `written`
        # by path prefix afterwards. Guessing which deployed paths were config would be a second, worse
        # definition of the config graph, free to disagree with `pack_yaml` the moment a pack puts a
        # file somewhere new.
        bundle = []
        for rel_in_pack in PACK_EVIDENCE:
            full = os.path.join(root, pack, rel_in_pack)
            if os.path.exists(full):
                bundle.append(f"{pack}/{rel_in_pack}")
        for f in sorted(os.listdir(os.path.join(root, pack, "handoff"))
                        if os.path.isdir(os.path.join(root, pack, "handoff")) else []):
            if f.startswith("SOURCE_VERDICTS"):
                bundle.append(f"{pack}/handoff/{f}")
        # WHERE the bundle lands is the caller's choice. In the tree it is covered by `tree_sha256`
        # and answers "what was approved" without a checkout; in `--evidence-out` it stays out of a
        # runtime workspace that has no business holding source-provenance prose — pending workbook
        # locations, stand-in explanations, missing attestations, drafting decisions. Two audiences,
        # two permissions. It is LISTED in RELEASE_EVIDENCE.yaml either way, so the tree still states
        # what evidence exists and where it went.
        dest = evidence_out or out
        for rel in bundle:
            _copy(os.path.join(root, rel.replace("/", os.sep)), os.path.join(dest, rel))
        if not evidence_out:
            written += bundle
        else:
            # ...except the members the RUN reads, which go into the tree as well. Copied a second
            # time rather than sieved out of the bundle: the audit copy is what was approved and the
            # runtime copy is what the job opens, and an auditor should not have to know the
            # deployment happened to need one of them.
            for rel_in_pack in RUNTIME_EVIDENCE:
                full = os.path.join(root, pack, rel_in_pack)
                if os.path.exists(full):
                    rel = f"{pack}/{rel_in_pack}"
                    _copy(full, os.path.join(out, rel))
                    written.append(rel)
        audit[pack] = sorted(bundle)

    written.extend(build_runtime_package(root, out))

    # Releasability, evaluated HERE against the FULL repository — see the module docstring for why it
    # cannot be re-derived inside the tree — and bound to the BYTES as well as the commit. The digest
    # is taken over the tree AS IT NOW IS, through the same `deployed_files` walk the runtime uses,
    # rather than over `written`: what was copied and what is on disk are two different claims.
    evidence = {"git_commit": git_commit,
                "tree_sha256": tree_digest(out),
                "approved_artifact_root": APPROVED_ARTIFACT_ROOT or None,
                "generated_from": "products/registry.yaml + Gates 1-4 evidence",
                "products": {}}
    for pack in packs:
        ok, why = sm.releasable(root, pack)
        # THE AUDIT BUNDLE, named rather than left implicit. The tree carries each pack's approval
        # records, contract, registers and Gate 3 verdicts, and once RELEASE_EVIDENCE.yaml is present
        # the runtime reads almost none of them — so they sat in the deployment looking live beside a
        # stored verdict, with no statement of what they were for. They are the answer to "what was
        # approved", available in the workspace without a checkout. Listing them makes that a claim
        # the tree can be held to; `tree_sha256` already covers their bytes, so editing one
        # invalidates the release exactly like editing a config.
        # THE SEMANTIC IDENTITY, COMPUTED HERE AND CARRIED. The runtime recomputed it inside the
        # deployed tree, where the UMLS projections, the mCODE extract, the oncology modules and
        # the inventory are all deliberately absent — so every one of them hashed as "absent" and
        # the run recorded a digest that was stable, wrong, and shaped exactly like a right one.
        # Evaluated here against the FULL repository for the same reason releasability is, and
        # bound to the same commit and tree digest.
        sem, _source, _sp = sm.semantic_identity(root, pack)
        # Release evidence stores diagnostic text. Keep typed findings in the validators,
        # but convert their str subclasses before handing this record to YAML's safe dumper.
        evidence["products"][pack] = {"releasable": bool(ok), "blockers": [str(item) for item in why],
                                      "audit_bundle": audit.get(pack, []),
                                      "audit_bundle_in_tree": not evidence_out,
                                      **{k: v for k, v in sorted(sem.items())}}
    with open(os.path.join(out, sm.RELEASE_EVIDENCE), "w", encoding="utf-8", newline="\n") as fh:
        yaml.safe_dump(evidence, fh, sort_keys=False, width=100)
    return sorted(set(written) | {sm.RELEASE_EVIDENCE, MARKER})


def check_tree(out):
    """Errors for a GENERATED tree, re-derived from the tree itself. Empty means it is shippable.

    THE GAP THIS CLOSES. `repo_hygiene.py --check` reads the git INDEX, and a generated tree has no
    `.git`; run from the repository it skips `build/` as generated output. So nothing looked at the
    thing actually being packaged, and a file dropped into a built tree by hand — a PDF, a profile, a
    stray notebook — reached the workspace. The runtime would later refuse to publish because
    `tree_sha256` no longer matched, which is INTEGRITY: it tells you afterwards that something
    changed. Containment is refusing to ship it, and that is this.

    Everything here is re-derived from what is on disk NOW, never from what `build()` said it wrote:
    the two agreeing is the property being tested.
    """
    errors = []
    if not os.path.isfile(os.path.join(out, MARKER)):
        return [f"{out}: no {MARKER} — this was not built by deploy_tree, so there is nothing to "
                f"check it against. Build it, then check it."]
    files = deployed_files(out)
    if not files:
        return [f"{out}: the tree is empty"]

    bad = forbidden_in(files)
    errors += [f"{p}: must not be in a deployment tree" for p in bad]
    errors.extend(check_runtime_package(out))

    doc, err = pg.read_yaml(os.path.join(out, sm.RELEASE_EVIDENCE))
    if err:
        return errors + [f"{sm.RELEASE_EVIDENCE}: {err} — the tree cannot state what it is"]

    # THE INVENTORY, both directions. An ADDED file is the case this exists for; a MISSING one means
    # the tree was edited after the build and the runtime will fail on an import nobody sees until a
    # job runs in the workspace.
    recorded = doc.get("tree_sha256") or ""
    actual = tree_digest(out, files)
    if recorded != actual:
        errors.append(f"tree_sha256 MISMATCH — RELEASE_EVIDENCE.yaml records {recorded[:16]}… and the "
                      f"tree now digests to {actual[:16]}…. Something was added, removed or edited "
                      f"after the build. Rebuild rather than re-stamping.")

    # ...and the tools, re-derived. A tree whose tool set does not match the entrypoints' imports is
    # one that fails at `import` inside a workspace, or one carrying a development tool somebody
    # copied in.
    want = set(runtime_tools(out))
    got = {p.split("/")[-1][:-3] for p in files if p.startswith("platform/tools/") and p.endswith(".py")}
    for extra in sorted(got - want):
        errors.append(f"platform/tools/{extra}.py is in the tree and no entrypoint imports it")
    for missing in sorted(want - got):
        errors.append(f"platform/tools/{missing}.py is imported by an entrypoint and is NOT in the tree")

    if not doc.get("git_commit"):
        errors.append("RELEASE_EVIDENCE.yaml records no git_commit — this tree was built --allow-dirty "
                      "and CANNOT publish. Rebuild from a clean checkout before packaging.")
    return errors


def forbidden_in(paths):
    """Anything in the tree that must not have been deployed.

    Two questions, and the second is why this is not just `FORBIDDEN`. Those entries are DIRECTORIES
    the tree omits — `prog_spec/`, `sandbox/` — which is a judgment about this deployment. On top of
    them sits `repo_hygiene.NEVER_COMMITTED`: file kinds that may not be in the REPOSITORY, and so
    certainly may not be in a workspace. Deriving the second set rather than restating it means the
    tree guard cannot come to permit something the checkout guard refuses, whichever list grows.
    """
    return sorted({p for p in paths if any(bad in f"/{p}" for bad in FORBIDDEN)} |
                  {p for p, _why in rh.restricted_files(pg.repo_root(), list(paths),
                                                        production=True)})


def main(argv):
    ap = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    ap.add_argument("--out", help="directory to write the deployment tree into")
    ap.add_argument("--artifact-root", default="", help="the Unity Catalog Volume path every prod run must "
                    "write its evidence to; recorded as approved_artifact_root in RELEASE_EVIDENCE.yaml")
    ap.add_argument("--check-tree", metavar="DIR",
                    help="validate an ALREADY-BUILT tree and exit non-zero on any finding. Run this "
                         "immediately before packaging: repo_hygiene reads the git index and cannot "
                         "see a generated tree at all.")
    ap.add_argument("--evidence-out", metavar="DIR",
                    help="write each pack's AUDIT BUNDLE here instead of into the tree — the runtime "
                         "reads almost none of it, and it carries source-provenance prose a workspace "
                         "has no business holding.")
    ap.add_argument("--git-commit", default="",
                    help="SHA to bind RELEASE_EVIDENCE.yaml to. Must equal HEAD; omit to use HEAD.")
    ap.add_argument("--product", action="append", dest="products",
                    help="deploy only these packs (repo-relative); default is every materialized one")
    ap.add_argument("--allow-dirty", action="store_true",
                    help="package a modified checkout. The tree is then NOT release-bindable: it is "
                         "stamped with no commit, so the runtime refuses to publish off its evidence.")
    a = ap.parse_args(argv)
    globals()["APPROVED_ARTIFACT_ROOT"] = str(getattr(a, "artifact_root", "") or "").rstrip("/")

    root = pg.repo_root()
    if a.check_tree:
        found = check_tree(a.check_tree)
        for line in found:
            print(line)
        print(f"{a.check_tree}: {len(found) or 'no'} finding(s)"
              f"{'' if found else ' — safe to package'}")
        return 1 if found else 0
    if not a.out:
        ap.error("--out is required to build a tree (or pass --check-tree DIR to validate one)")
    if os.path.abspath(a.out).startswith(os.path.abspath(root) + os.sep) and \
            not os.path.abspath(a.out).startswith(os.path.join(os.path.abspath(root), "build")):
        sys.exit(f"--out {a.out} is inside the checkout outside build/ — a deployment tree written "
                 f"into the repo gets committed by accident. Use build/ or a path outside.")

    # THE COMMIT IS DERIVED, NOT ACCEPTED. `--git-commit` was a free string written straight into the
    # evidence, and the runtime compared it to the string the job was given. So packaging a dirty
    # checkout and stamping it with a clean approved SHA produced two matching strings over a
    # configuration that commit does not identify. HEAD is read here; a supplied SHA may only CONFIRM
    # it. A dirty checkout is refused for release packaging, and `--allow-dirty` deliberately produces
    # an UNBINDABLE tree — an empty commit is not a match on either side of `evidence_verdict`, so a
    # development tree cannot become a release by being copied somewhere.
    head, dirty = git_state(root)
    if head is None:
        if a.git_commit:
            sys.exit("--git-commit was given but this is not a git work tree, so the SHA cannot be "
                     "confirmed. A commit nobody verified is not a binding.")
        commit = ""
        print("(not a git work tree — building an UNBINDABLE tree with no commit)")
    elif dirty and not a.allow_dirty:
        sys.exit(f"REFUSING: {len(dirty)} uncommitted change(s) — a release tree must be packaged "
                 f"from a clean checkout, or the commit it is stamped with does not describe it:\n"
                 + "\n".join(f"  {p}" for p in dirty[:10])
                 + ("\n  ..." if len(dirty) > 10 else "")
                 + "\nCommit them, or pass --allow-dirty for a tree that cannot publish.")
    elif dirty:
        commit = ""
        print(f"(--allow-dirty: {len(dirty)} uncommitted change(s); this tree carries NO commit and "
              f"CANNOT publish)")
    elif a.git_commit and a.git_commit.strip() != head:
        sys.exit(f"--git-commit {a.git_commit.strip()[:12]} is not HEAD ({head[:12]}) — the tree is "
                 f"built from the working checkout, so stamping it with another commit would bind the "
                 f"evidence to bytes it was not built from.")
    else:
        commit = head

    files = build(root, a.out, a.products, commit, evidence_out=a.evidence_out)
    bad = forbidden_in(files)
    if bad:
        sys.exit("REFUSING: the tree contains material that must not be deployed:\n"
                 + "\n".join(f"  {p}" for p in bad[:10]))
    ev, err = pg.read_yaml(os.path.join(a.out, sm.RELEASE_EVIDENCE))
    if err:
        sys.exit(f"the evidence this build just wrote will not read back: {err}")
    rel = [p for p, e in ev["products"].items() if e["releasable"]]
    print(f"{a.out}: {len(files)} file(s), {len(ev['products'])} product(s), "
          f"{len(rel)} releasable{' — ' + ', '.join(rel) if rel else ''}")
    # THE EVIDENCE FILE'S OWN DIGEST, PRINTED AND NOT STORED. `tree_sha256` must exclude
    # RELEASE_EVIDENCE.yaml — a digest cannot cover the file it lives in — so the one file that GRANTS
    # permission was the one file nothing protected: flipping `releasable: false` to `true` and
    # emptying `blockers` changed no file the tree digest covers, and `evidence_verdict` accepted it.
    #
    # So the digest travels OUT OF BAND, as a job parameter the deploying pipeline sets from this
    # output. Editing the evidence then breaks the match, and repairing it means supplying the new
    # digest at run time.
    #
    # AND THAT IS ALL IT IS. An earlier version of this comment claimed the repair was "a hash fixed
    # point, not an edit" — that the parameter lived in `resources/products.yml`, inside the tree, and
    # so inside `tree_sha256`, whose value is in the evidence file, so all three had to be solved at
    # once. THAT IS WRONG, and worth writing down because it is the kind of wrong that reads as a
    # guarantee. `products.yml` holds `${var.release_evidence_sha256}` — a bundle VARIABLE, resolved at
    # `bundle run`. Its bytes do not change when the digest does. Whoever can edit the evidence file
    # can recompute its sha256 and pass the new value on the command line, touching nothing the tree
    # digest covers. There is no circularity to solve.
    #
    # What it actually buys: a run using a digest someone else printed — a scheduled job, a pipeline
    # parameter set at deploy, an operator following the documented sequence — fails closed the moment
    # the file is edited underneath it. That is real and worth having, and it is DEFENCE IN DEPTH, not
    # a trust anchor. It does not prove who built the tree and it does not stop the person holding the
    # deploy credentials. THAT needs the tree built in protected CI from the reviewed commit, published
    # as an attested artifact with a detached signature, and the signature verified at deploy against a
    # key the deploying operator does not hold. None of that can live inside this repository, which is
    # why it is named here rather than approximated.
    evidence_digest = pg.sha256(os.path.join(a.out, sm.RELEASE_EVIDENCE))
    print(f"  commit {ev['git_commit'][:12] or '(none — this tree cannot publish)'}  "
          f"tree {ev['tree_sha256'][:12]}  evidence {evidence_digest[:12]}")
    if a.evidence_out:
        print(f"  audit bundle written OUTSIDE the tree, to {a.evidence_out}")
    print(f"\n  Check before packaging:  python3 platform/tools/deploy_tree.py --check-tree {a.out}")
    print(f"  Deploy with:  --var release_evidence_sha256={evidence_digest}")
    print("  A prod run without it, or with a stale one, may build and stage and may NOT publish.")
    return 0


if __name__ == "__main__":
    from rwd_tools.console import use_utf8
    use_utf8()
    sys.exit(main(sys.argv[1:]))
