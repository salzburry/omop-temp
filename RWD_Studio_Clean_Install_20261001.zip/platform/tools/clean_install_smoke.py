"""Prepare fixture-independent installation evidence, never a production release.

The smoke copy excludes installed products, source fixtures, local state and media.
It retains runtime code, schemas, master vocabulary and synthetic test generators.
Run the generated package's dedicated tests in a fresh environment. This is a CI
installation check; the governed source-transfer tool owns release ZIP manifests.
"""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import tempfile

import yaml
from rwd_tools import clean_evaluation_assets

from rwd_services import package_source_files, prepare_snapshot_runtime, workspace_root
ROOT = str(workspace_root(__file__))

# Installation state is initialized only in a disposable copy. Policies, master
# definitions and the source checkout's evidence are never rewritten.
EMPTY_DOCUMENTS = {
    "products/registry.yaml": {"tumors": []},
    "fixtures/registry.yaml": {"tumors": []},
    "products/activation.yaml": {"products": {}},
    "governance/events/HEAD_CHECKPOINTS.yaml": {"heads": {}},
    "governance/approval_baseline.yaml": {"baselined": []},
    "governance/NAMING_BASELINE.yaml": {"pairs": []},
    "governance/SIGNING_KEYS.yaml": {"keys": []},
    "governance/NAMING_RULINGS.yaml": {"rulings": []},
    "governance/EQUIVALENCE_RULINGS.yaml": {"rulings": []},
    "governance/NAME_LIFECYCLE.yaml": {"names": []},
    "governance/precedents.yaml": {"precedents": []},
}
INSTALL_DOCS = frozenset({"docs/RESEARCHER_QUICK_START.md", "docs/CHAT_JOURNEY.md",
                        "docs/CLEAN_INSTALL_EXPORT.md"})
RETIRED_OVERLAY = "governance/reference/oncology_modules/indication/gist_202606.yaml"


def license_notice(name):
    """Retain source licensing/notice files, including component notices."""
    base = Path(name).name.upper()
    return any(base == word or base.startswith(word + ".") or base.startswith(word + "-")
               for word in ("LICENSE", "LICENCE", "NOTICE", "COPYING", "COPYRIGHT"))


def release_selected(name):
    """The empty installation shell; declared package inputs are added separately."""
    if Path(name).suffix.casefold() in {".pdf", ".png", ".jpg", ".jpeg", ".tif", ".tiff", ".docx",
                                      ".pptx", ".xlsx", ".parquet", ".log", ".csv", ".tsv"}:
        return False
    if name == RETIRED_OVERLAY:
        return False
    if name.startswith("products/"):
        return name in {"products/registry.yaml", "products/activation.yaml", "products/metadata/catalog.yaml",
                        "products/metadata/README.md"} or name.startswith("products/_reporting/")
    if name.startswith(("fixtures/", "intake/", "work/", "refreshes/", "releases/", "sandbox/",
                        "platform/tests/", "experiments/agent/knowledge/corrections/")):
        return False
    if name in {"governance/CURRENT_STATE.md", "experiments/portal/APPROVAL_CHECKPOINT_AUDIT.md"}:
        return False
    return name in INSTALL_DOCS or license_notice(name) or selected(name)


def initialize(destination):
    """Apply the shared clean-install state policy and return every transformation."""
    from engine.strict_yaml import strict_load
    destination = Path(destination)
    changes = {}

    def write(name, data, reason="Initialize destination-owned state; no inherited approvals"):
        target = destination / name
        target.parent.mkdir(parents=True, exist_ok=True)
        text = json.dumps(data, indent=2) + "\n" if name.endswith(".json") else yaml.safe_dump(data, sort_keys=False)
        raw = text.encode("utf-8")
        before = target.read_bytes() if target.exists() else None
        target.write_bytes(raw)
        changes[name] = {"source_sha256": hashlib.sha256(before).hexdigest() if before is not None else None,
                         "sha256": hashlib.sha256(raw).hexdigest(), "reason": reason}

    for name, document in {**clean_evaluation_assets.initial_documents(), **EMPTY_DOCUMENTS}.items():
        write(name, document)
    for name, field in [("governance/tumour_registry.yaml", "aliases"),
                        ("governance/reference/oncology_modules/CATALOGUE.yaml", "cancers")]:
        data = strict_load((destination / name).read_text(encoding="utf-8"))
        if not isinstance(data, dict) or not isinstance(data.get(field), dict):
            raise ValueError("Clean installation requires a readable master registry: " + name)
        if "gist_202606" in data[field]:
            del data[field]["gist_202606"]
            write(name, data, "Remove only the retired example product alias; preserve master definitions")
    name = "governance/allowed_signers.yaml"
    data = strict_load((destination / name).read_text(encoding="utf-8"))
    if not isinstance(data, dict) or not isinstance(data.get("signers"), list):
        raise ValueError("Clean installation requires an explicit signer list")
    data["signers"] = []
    write(name, data, "Reset signer trust; preserve ineligible-key guards and policy fields")
    name = "products/metadata/catalog.yaml"
    data = strict_load((destination / name).read_text(encoding="utf-8"))
    if not isinstance(data, dict) or not isinstance(data.get("tumor_codes"), list):
        raise ValueError("Clean installation requires an explicit catalogue code list")
    references = data.get("reference_tumor_codes", [])
    if not isinstance(references, list):
        raise ValueError("Clean installation requires a reference code list")
    data["reference_tumor_codes"] = list(dict.fromkeys(
        code for code in [*references, *data["tumor_codes"]] if code != "gist_202606"))
    data["tumor_codes"] = []
    write(name, data, "Keep master vocabulary reference codes; initialize the product-code mirror empty")
    excluded = destination / RETIRED_OVERLAY
    if excluded.exists():
        changes[RETIRED_OVERLAY] = {"source_sha256": hashlib.sha256(excluded.read_bytes()).hexdigest(),
                                    "sha256": None, "reason": "Omit the retired example product overlay"}
        excluded.unlink()
    return changes


def selected(name):
    if name in {"platform/tests/fixtures/synthetic_sources.py", "docs/CHAT_JOURNEY.md",
                "docs/RESEARCHER_QUICK_START.md"} or name in clean_evaluation_assets.RETAIN:
        return True  # runtime generator code; no adjacent fixture data
    parts = Path(name).parts
    if name.startswith(".claude/skills/"):
        return True
    if name.startswith(("fixtures/", "sandbox/", "products/oncology/", "intake/oncology/",
                        "platform/tests/fixtures/", "governance/events/", "experiments/agent/evals/", "experiments/agent/knowledge/corrections/")):
        return False
    if Path(name).suffix.lower() in {".pdf", ".png", ".jpg", ".jpeg", ".tif", ".tiff", ".docx", ".pptx", ".xlsx"}:
        return False
    return (parts[0] in {"platform", "experiments", "governance", "products", "resources", ".streamlit", "app", "rwd_services"}
            or name in {"pyproject.toml", "requirements.txt", "Start-RwdPortal.cmd", "app.yaml", "databricks.yml",
                        ".python-version", ".gitattributes", ".gitignore", "pytest.ini", "app.sh"})


def prepare(source, destination):
    from rwd_tools import source_transfer
    source, destination = Path(source).resolve(strict=True), Path(destination).absolute()
    if destination.exists() or destination.resolve() != destination or destination.is_relative_to(source):
        raise ValueError("Use a new canonical smoke directory outside the source checkout.")
    destination.mkdir(parents=True)
    # The distribution's explicit code/resource manifest is authoritative for
    # import closure; the transfer selection supplies the empty workspace shell.
    files = sorted({name for name, _mode in source_transfer.selected(source) if selected(name)}
                   | {path.as_posix() for path in package_source_files(source)})
    for name in files:
        target = destination / name
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes((source / name).read_bytes())
    changes = initialize(destination)
    files = sorted((set(files) | {name for name, row in changes.items() if row["sha256"] is not None})
                   - {name for name, row in changes.items() if row["sha256"] is None})
    # Execute the smoke copy's own installed bundler, never an editable package
    # pointing back at the author's checkout.
    with tempfile.TemporaryDirectory(prefix="rwd-clean-runtime-") as runtime_dir:
        runtime = prepare_snapshot_runtime(destination, Path(runtime_dir) / "environment")
        subprocess.run([str(runtime.python), "-I", "-m", "rwd_tools.bundle_products"],
                       cwd=destination, env=runtime.environ, capture_output=True,
                       text=True, encoding="utf-8", check=True, timeout=60)
    if "resources/products.yml" not in files:
        files.append("resources/products.yml")
    hashes = {name: hashlib.sha256((destination / name).read_bytes()).hexdigest() for name in sorted(files)}
    (destination / "CLEAN_INSTALL_FILES.json").write_text(json.dumps({"version": 1, "purpose": "synthetic CI smoke",
        "files": hashes, "initial_product_count": 0, "fixture_packs_included": False}, indent=2), encoding="utf-8", newline="\n")
    return destination


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--prepare", required=True)
    args = parser.parse_args(argv)
    print(prepare(ROOT, args.prepare))
    return 0


if __name__ == "__main__":
    from rwd_tools.console import use_utf8
    use_utf8()
    raise SystemExit(main())
