#!/usr/bin/env python3
"""Extract the mCODE STU4 data dictionary from its published workbook — reproducibly.

    python3 platform/tools/mcode_dictionary.py --workbook <STU4.xlsx> --check
    python3 platform/tools/mcode_dictionary.py --workbook <STU4.xlsx> --write
    python3 platform/tools/mcode_dictionary.py --check          # no workbook: reports UNCHECKED

WHY THIS EXISTS. `governance/reference/mcode_stu4/DICTIONARY.json` was committed as a reference
extract with a sha256 of the workbook it came from, and the code that produced it was not. So the
digest proved which FILE was read and nothing at all about what was DONE to it: a reviewer could
confirm the workbook and still not reproduce the extract, and a future STU5 would be re-extracted
by whatever a person wrote the second time. This is that missing half. `--check` regenerates from
the workbook and byte-compares, so the committed artifact is a claim the repository can re-verify
rather than one it has to trust.

IT REPRODUCES BEFORE IT EXTENDS. The committed DICTIONARY.json is not rewritten by this tool and
its bytes are the acceptance test: `indent=1`, `ensure_ascii=False`, no trailing newline,
insertion-ordered. The codes this programme actually needs land in a SEPARATE artifact
(`VALUE_SET_CODES.json`) for that reason — extending the dictionary in place would have churned a
file other work already reads and destroyed the one check that makes the extractor credible.

NO NORMALISATION, and it is deliberate rather than sloppy. Six element definitions end in a
trailing space and the extract preserves them; 211 rows hold the empty string where a reader
would expect null; four smart quotes survive unfolded. Every one of those is a place a
well-meaning `.strip()` would break byte-identity, and a normalising extractor cannot tell you
whether the workbook changed or its own cleanup did.

WHAT THE ORIGINAL GOT WRONG, RECORDED RATHER THAN SILENTLY FIXED. Two defects are reproduced
because reproduction is the point, and reported because a defect nobody names is one the next cut
inherits:

  * `reference_edges` is documented in `docs/MCODE_ALIGNMENT_PROPOSAL.md` as a Data Type
    BEGINNING `Reference:`. That rule yields 78 edges. The committed file has 87, which is
    SUBSTRING containment — it also catches the nine choice-typed elements written
    `CodeableConcept or Reference: Medication`. The documentation describes a stricter tool than
    the one that ran.
  * A multi-target reference keeps only its FIRST target and discards the rest without a word.
    `Reference: USCorePractitionerProfile, USCoreOrganizationProfile, ...` is six targets recorded
    as one. `--report` names every affected row; `reference_targets` in the codes artifact carries
    all of them, so the loss is recoverable without disturbing the reproduction.

BOTH ARTIFACTS ARE CHECKED, AND PROVENANCE IS A ONE-WAY RATCHET. `--check` byte-compares
DICTIONARY.json AND VALUE_SET_CODES.json; it used to compare only the first, so `current` was a
claim about half of what this tool writes. That mattered because the two artifacts do not depend on
the workbook the same way: the dictionary reproduces from the bytes alone, while the codes artifact
also records the IG PACKAGE, which `package_version()` reads from the workbook's ancestor
directories. Two byte-identical copies of the workbook exist on disk; read from the loose one, the
`package` block vanishes and nothing objected. `--write` now refuses to replace an artifact that
records a package with one that does not.

THE WORKBOOK IS NOT CARRIED. `--workbook` is required and has no default, because a licensed
terminology workbook inside the checkout is exactly what `repo_hygiene.py` refuses. The path is an
argument; the digest is what the repository keeps. With no workbook the run reports UNCHECKED and
exits 0 — an unavailable source is not a passing check, and the two must never print alike.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import sys

TOOLS = os.path.dirname(os.path.abspath(__file__))
from rwd_services import workspace_root
ROOT = str(workspace_root(__file__))

REFERENCE = os.path.join(ROOT, "governance", "reference", "mcode_stu4")
DICTIONARY = os.path.join(REFERENCE, "DICTIONARY.json")
CODES = os.path.join(REFERENCE, "VALUE_SET_CODES.json")

# Not read from the workbook: this string appears nowhere in it. It names the artifact for a
# reader, and it is part of the byte-identity contract.
SOURCE = "mCODE STU4 Data Dictionary (HL7 FHIR US mCODE Implementation Guide)"

# Sheet -> (0-based column index, output key), in output key order. Column A ("Group") is dropped
# from Profiles and Data elements; K and L (the two StructureDefinition URIs) are dropped from
# Data elements. Value sets has no Group column.
PROFILE_COLS = ((1, "title"), (2, "url"), (3, "description"))
ELEMENT_COLS = ((1, "profile"), (2, "element"), (3, "definition"), (4, "required"),
                (5, "occurrences"), (6, "data_type"), (7, "value_set_uri"), (8, "binding"),
                (9, "fhir_element"))
VALUE_SET_COLS = ((0, "title"), (1, "url"), (2, "description"))
CODE_COLS = ((0, "value_set"), (1, "code_system"), (2, "logical_definition"), (3, "code"),
             (4, "description"))

# HOW mCODE SPELLS A CODE SYSTEM -> the UMLS source abbreviation that carries it.
#
# THIS IS A JOIN KEY, NOT A LICENCE TABLE. mCODE's workbook writes "NCIT", "LOINC", "SNOMED CT";
# UMLS writes NCI, LNC, SNOMEDCT_US. Without this mapping no mCODE code resolves to a CUI and
# there is no bridge at all. An earlier cut of this file also carried each source's UMLS source
# restriction level and withheld descriptions above level 0; that gating was removed on request
# and only the mapping remains.
#
# `sab: None` means the code system is not a UMLS Metathesaurus source, so its codes cannot be
# resolved to a concept. UCUM is the case in point — a units-of-measure standard, not a
# vocabulary. Its rows still carry their code and description; they simply have no CUI to join to.
CODE_SYSTEMS = {
    "NCIT":               {"sab": "NCI"},
    "LOINC":              {"sab": "LNC"},
    "SNOMED CT":          {"sab": "SNOMEDCT_US"},
    "ICD-10 CM":          {"sab": "ICD10CM"},
    "SpecimenType (HL7)": {"sab": "HL7V3.0"},
    "http://terminology.hl7.org/CodeSystem/v3-NullFlavor": {"sab": "HL7V3.0"},
    "UCUM":               {"sab": None,
                           "note": "not a UMLS Metathesaurus source, so its codes resolve to no "
                                   "concept"},
}


def ig_information(wb):
    """The workbook's own self-description — IG name, version, URL, generation date.

    WHICH mCODE THIS IS, FROM THE WORKBOOK RATHER THAN FROM A FILENAME. The committed
    DICTIONARY.json identifies its source only by a hardcoded "STU4" string and a digest, so
    re-extracting from a newer ballot would produce a file that still called itself STU4. This
    sheet states `IG version` outright — 4.0.0-ballot for the workbook this was written against —
    and recording it is what lets a consumer tell two extracts apart without diffing them.

    Read as key/value pairs rather than by fixed cell address, because the sheet's row positions
    are a layout detail and a shifted row would silently return the wrong value.
    """
    out = {}
    for row in wb["IG information"].iter_rows(values_only=True):
        cells = [c for c in row if c is not None and str(c).strip()]
        # `>= 2`, not `== 2`. Requiring exactly two dropped any row carrying a third cell — a
        # note, a unit, an annotation — and since the whole sheet is read in one pass, ONE such
        # row anywhere reduced the result to a subset, or to nothing. The version then recorded
        # as "unstated" with no error, defeating the one thing this function exists for.
        if len(cells) >= 2:
            out.setdefault(str(cells[0]).strip(), str(cells[1]).strip())
    return out


def package_version(workbook):
    """The version of the IG PACKAGE the workbook ships inside, when it ships inside one.

    WHY THIS IS NOT THE WORKBOOK'S OWN LABEL. The STU4 data dictionary states `IG version:
    4.0.0-ballot` on its own information sheet, and that string is stale: the byte-identical file
    ships inside the PUBLISHED package, `status: active`, version 4.0.0, dated 2025-02-16. An
    external review read the label and called the extract obsolete ballot content. It is not, and
    the way to stop that recurring is to read the package's own ImplementationGuide resource rather
    than trust a cell inside a spreadsheet.

    Returns None when the workbook is a loose file — which is the honest answer, not a guess.
    """
    here = os.path.dirname(os.path.abspath(workbook))
    for _ in range(4):                       # the package root is a few levels up from the sheet
        for name in sorted(os.listdir(here) if os.path.isdir(here) else []):
            if name.startswith("ImplementationGuide-") and name.endswith(".json"):
                try:
                    with open(os.path.join(here, name), encoding="utf-8") as fh:
                        doc = json.load(fh)
                except (OSError, ValueError):
                    continue
                if doc.get("resourceType") == "ImplementationGuide" and doc.get("version"):
                    return {"version": str(doc["version"]), "status": doc.get("status"),
                            "date": doc.get("date"), "packageId": doc.get("packageId")}
        parent = os.path.dirname(here)
        if parent == here:
            break
        here = parent
    return None


def _rows(ws):
    """Data rows in sheet order, dropping only rows that are entirely empty.

    openpyxl counts a trailing all-None row in `max_row` — Data elements and Value set codes each
    carry one. Nothing else is filtered: `Default` is the VALUE of the Group column on every row,
    not a separator, and dropping it would silently lose all 38 profiles.
    """
    return [r for r in ws.iter_rows(min_row=2, values_only=True)
            if not all(c is None for c in r)]


def _pick(row, cols):
    return {key: (row[i] if i < len(row) else None) for i, key in cols}


def reference_edges(elements):
    """The typed references — mCODE's arrows — as the committed extract encodes them.

    Containment, not prefix: see the module docstring. Only the first target is kept, which is
    lossy; `reference_targets` records the full list without disturbing this.
    """
    out = []
    for e in elements:
        dt = e.get("data_type")
        if isinstance(dt, str) and "Reference:" in dt:
            tail = dt.split("Reference:", 1)[1]
            out.append({"from": e["profile"], "property": e["element"],
                        "to": tail.split(",")[0].strip()})
    return out


def reference_targets(elements):
    """Every target of every typed reference — the multi-target rows in full."""
    out = []
    for e in elements:
        dt = e.get("data_type")
        if not (isinstance(dt, str) and "Reference:" in dt):
            continue
        tail = dt.split("Reference:", 1)[1]
        targets = [t.strip() for part in tail.split(",") for t in part.split(" or ")]
        out.append({"from": e["profile"], "property": e["element"],
                    "to": [t for t in targets if t]})
    return out


def extract(workbook):
    """(dictionary, codes) from the workbook. Pure: reads the file, writes nothing."""
    import openpyxl                                                      # noqa: PLC0415
    with open(workbook, "rb") as fh:
        digest = hashlib.sha256(fh.read()).hexdigest()
    wb = openpyxl.load_workbook(workbook, data_only=True)
    profiles = [_pick(r, PROFILE_COLS) for r in _rows(wb["Profiles"])]
    elements = [_pick(r, ELEMENT_COLS) for r in _rows(wb["Data elements"])]
    value_sets = [_pick(r, VALUE_SET_COLS) for r in _rows(wb["Value sets"])]
    edges = reference_edges(elements)
    extensions = len(_rows(wb["Extensions"]))
    dictionary = {
        "source": SOURCE,
        "source_file_sha256": digest,
        "counts": {"profiles": len(profiles), "elements": len(elements),
                   "reference_edges": len(edges), "value_sets": len(value_sets),
                   "extensions": extensions},
        "profiles": profiles,
        "elements": elements,
        "reference_edges": edges,
        "value_sets": value_sets,
    }
    return dictionary, _codes(wb, digest, elements, package_version(workbook))


def _codes(wb, digest, elements, package=None):
    """The bound value set members — the half the first extract never took.

    Every row carries its code, its code system and its description as the workbook states them.
    A row whose code system this tool has no UMLS mapping for still carries all three; it simply
    has no `sab`, and so resolves to no concept downstream. That is recorded per row and counted
    in the envelope rather than left for a reader to infer from a join that quietly finds nothing.
    """
    rows, unmapped = [], {}
    for r in _rows(wb["Value set codes"]):
        rec = _pick(r, CODE_COLS)
        if not rec.get("code") or not rec.get("code_system"):
            continue                       # value-set header rows carry a title and nothing else
        cs = str(rec["code_system"])
        known = CODE_SYSTEMS.get(cs)
        if not known or not known.get("sab"):
            unmapped[cs] = unmapped.get(cs, 0) + 1
        rows.append({"value_set": rec["value_set"], "code_system": cs,
                     "sab": known["sab"] if known else None,
                     "code": str(rec["code"]).strip(),
                     "description": rec.get("description")})
    targets = reference_targets(elements)
    ig = ig_information(wb)
    return {
        "source": SOURCE,
        "source_file_sha256": digest,
        # The workbook's own version statement, so a re-extract from a newer ballot is
        # distinguishable from this one by something other than a digest.
        "implementation_guide": dict(
            {k: ig[k] for k in ("IG name", "IG title", "IG version", "IG URL",
                                "Base FHIR version", "Data dictionary generated date")
             if ig.get(k)},
            # The PACKAGE's own statement, read from its ImplementationGuide resource, when the
            # workbook ships inside one. Absent for a loose file, which is the honest answer.
            **({"package": package} if package else {})),
        "counts": {"codes": len(rows),
                   "with_description": sum(1 for r in rows if r.get("description")),
                   "resolvable_to_a_concept": sum(1 for r in rows if r["sab"]),
                   "unmapped_code_systems": dict(sorted(unmapped.items())),
                   "value_sets_enumerated": len({r["value_set"] for r in rows}),
                   "reference_targets": len(targets),
                   "multi_target_references": sum(1 for t in targets if len(t["to"]) > 1)},
        "codes": rows,
        "reference_targets": targets,
    }


def artifact_errors(doc):
    """Problems with a codes artifact. [] is a pass.

    THE ENVELOPE IS CHECKED AGAINST THE ROWS, never trusted. A run that dropped half its rows
    would still write a `counts` block, and a file that states its own completeness is not
    evidence of it. This is what CI and the tests both call, so the claim and the check can never
    be two different implementations.
    """
    problems = []
    rows = (doc or {}).get("codes")
    if not isinstance(rows, list) or not rows:
        problems.append("no codes")
        return problems
    for i, r in enumerate(rows):
        where = f"codes[{i}] {r.get('code_system')} {r.get('code')}"
        if not r.get("code"):
            problems.append(f"{where}: no code — the row cannot be joined on")
        if not str(r.get("code_system") or "").strip():
            problems.append(f"{where}: no code system — the code is not interpretable alone")
        sab = r.get("sab")
        if sab is not None and not str(sab).strip():
            problems.append(f"{where}: sab is empty rather than null — an unmapped code system "
                            f"must be null so the join can tell it apart from a mapped one")
    # EVERY count the envelope states. Four were previously unchecked —
    # `value_sets_enumerated`, `reference_targets`, `multi_target_references` and
    # `unmapped_code_systems` — so they could be set to anything on the live artifact and this
    # function still returned clean, while its own docstring said the envelope was checked
    # against the rows. All four are trivially re-derivable from the same document.
    counts = doc.get("counts") or {}
    targets = doc.get("reference_targets") or []
    unmapped = {}
    for r in rows:
        if not r.get("sab"):
            cs = str(r.get("code_system") or "")
            unmapped[cs] = unmapped.get(cs, 0) + 1
    actual = {"codes": len(rows),
              "with_description": sum(1 for r in rows if r.get("description")),
              "resolvable_to_a_concept": sum(1 for r in rows if r.get("sab")),
              "value_sets_enumerated": len({r.get("value_set") for r in rows}),
              "reference_targets": len(targets),
              "multi_target_references": sum(1 for t in targets if len(t.get("to") or []) > 1),
              "unmapped_code_systems": dict(sorted(unmapped.items()))}
    for key, value in actual.items():
        if counts.get(key) != value:
            problems.append(f"counts.{key} says {counts.get(key)!r}, the rows say {value}")
    return problems


def serialise(obj):
    """The committed encoding, and it is part of the contract — see the module docstring."""
    return json.dumps(obj, indent=1, ensure_ascii=False).encode("utf-8")


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    ap.add_argument("--workbook", help="path to mCODEDataDictionary-STU4.xlsx (never in-repo)")
    ap.add_argument("--check", action="store_true", help="regenerate and byte-compare")
    ap.add_argument("--write", action="store_true", help="write the codes artifact")
    ap.add_argument("--report", action="store_true", help="what the reproduction reveals")
    a = ap.parse_args(argv)

    if not a.workbook:
        # UNCHECKED IS NOT PASSED. The workbook is deliberately outside the checkout, so most
        # environments cannot run this — and a check that quietly succeeds when it did nothing is
        # worse than one that fails.
        print("UNCHECKED — no --workbook given, so the committed extract was not re-derived.")
        print("          to verify: --workbook <STU4.xlsx> --check")
        return 0
    if not os.path.exists(a.workbook):
        print(f"no such workbook: {a.workbook}", file=sys.stderr)
        return 2

    dictionary, codes = extract(a.workbook)
    got = serialise(dictionary)
    rc = 0

    if a.check:
        if not os.path.exists(DICTIONARY):
            print(f"missing {DICTIONARY}", file=sys.stderr)
            return 2
        with open(DICTIONARY, "rb") as fh:
            want = fh.read()
        if got == want:
            print(f"current — DICTIONARY.json reproduced exactly ({len(got)} bytes)")
        else:
            print(f"DRIFT — regenerated DICTIONARY.json differs from the committed file "
                  f"({len(got)} vs {len(want)} bytes)", file=sys.stderr)
            rc = 1
        recorded = json.loads(want.decode("utf-8")).get("source_file_sha256")
        if recorded != dictionary["source_file_sha256"]:
            print(f"DRIFT — workbook sha256 {dictionary['source_file_sha256']} is not the "
                  f"recorded {recorded}", file=sys.stderr)
            rc = 1

        # AND THE OTHER HALF OF THE EXTRACT. This checked DICTIONARY.json alone, so `current` was a
        # claim about half of what the tool writes: `--check` could pass and `--write` then
        # overwrite VALUE_SET_CODES.json with a different file. An external audit found the exact
        # path that does it — see the provenance guard below.
        if not os.path.exists(CODES):
            print(f"missing {CODES}", file=sys.stderr)
            return 2
        with open(CODES, "rb") as fh:
            want_codes = fh.read()
        got_codes = serialise(codes)
        if got_codes == want_codes:
            print(f"current — VALUE_SET_CODES.json reproduced exactly ({len(got_codes)} bytes)")
        else:
            print(f"DRIFT — regenerated VALUE_SET_CODES.json differs from the committed file "
                  f"({len(got_codes)} vs {len(want_codes)} bytes)", file=sys.stderr)
            # NAME THE LIKELY CAUSE, because this difference has one dominant explanation and it
            # is not a content change. `package_version()` walks the workbook's ANCESTOR
            # directories for the ImplementationGuide resource, so the same bytes read from a
            # loose copy produce an extract with no `package` block at all.
            had = (json.loads(want_codes.decode("utf-8")).get("implementation_guide")
                   or {}).get("package")
            now = (codes.get("implementation_guide") or {}).get("package")
            if had and not now:
                print(f"        the committed file records IG package "
                      f"{had.get('version')} ({had.get('status')}) and this extract records none. "
                      f"That is the loose-workbook path: point --workbook at the copy inside the "
                      f"published IG package, not at a standalone .xlsx", file=sys.stderr)
            rc = 1

    if a.write:
        # SELF-CHECKED BEFORE IT IS WRITTEN. The summary printed below comes from the same
        # in-memory counts that were just serialised, so it agrees with the file by construction
        # and proves nothing about it. This is the only thing that does.
        problems = artifact_errors(codes)
        if problems:
            print("REFUSING TO WRITE — the codes artifact fails its own checks:", file=sys.stderr)
            for p in problems[:10]:
                print(f"  {p}", file=sys.stderr)
            return 1

        # AND IT WILL NOT TRADE PROVENANCE DOWN. `artifact_errors` checks the codes against
        # themselves, which cannot see that the file about to be written knows LESS than the one it
        # replaces. Two byte-identical copies of the workbook exist; read from the loose one,
        # `package_version()` finds no ImplementationGuide resource above it and the `package`
        # block silently disappears — same codes, weaker claim, no error. The committed artifact is
        # the floor: provenance may be added by a re-extract, never removed by one.
        if os.path.exists(CODES):
            try:
                with open(CODES, encoding="utf-8") as fh:
                    prior = (json.load(fh).get("implementation_guide") or {}).get("package")
            except (OSError, ValueError):
                prior = None
            fresh = (codes.get("implementation_guide") or {}).get("package")
            if prior and not fresh:
                print(f"REFUSING TO WRITE — the committed artifact records IG package "
                      f"{prior.get('version')} ({prior.get('status')}, {prior.get('date')}) and "
                      f"this extract records none.", file=sys.stderr)
                print(f"  `package_version()` reads the ImplementationGuide resource from the "
                      f"workbook's ancestor directories, so a loose .xlsx cannot supply it.",
                      file=sys.stderr)
                print(f"  Point --workbook at the copy inside the published IG package.",
                      file=sys.stderr)
                return 1
        os.makedirs(REFERENCE, exist_ok=True)
        with open(CODES, "wb") as fh:
            fh.write(serialise(codes))
        print(f"wrote {os.path.relpath(CODES, ROOT)}")

    c = codes["counts"]
    ig = codes.get("implementation_guide") or {}
    if ig.get("IG version"):
        print(f"\n{ig.get('IG name') or 'mCODE'} version {ig['IG version']}, generated "
              f"{ig.get('Data dictionary generated date') or 'unstated'}")
    print(f"\nvalue set codes      {c['codes']:6}  across {c['value_sets_enumerated']} value sets")
    print(f"  with description   {c['with_description']:6}")
    print(f"  resolvable to CUI  {c['resolvable_to_a_concept']:6}  "
          f"(the rest have no UMLS source and join to nothing)")
    if c["unmapped_code_systems"]:
        print(f"  UNMAPPED           {c['unmapped_code_systems']}")

    if a.report:
        print(f"\nreference edges      {len(dictionary['reference_edges']):6}  as committed "
              f"(substring `Reference:`, not the prefix rule the docs state)")
        print(f"  multi-target       {c['multi_target_references']:6}  rows whose extra targets "
              f"the committed extract discards")
        for t in codes["reference_targets"]:
            if len(t["to"]) > 1:
                print(f"    {t['from']} :: {t['property']}")
                print(f"      kept {t['to'][0]!r}; dropped {t['to'][1:]}")
    return rc


if __name__ == "__main__":
    from rwd_tools.console import use_utf8
    use_utf8()
    raise SystemExit(main())
