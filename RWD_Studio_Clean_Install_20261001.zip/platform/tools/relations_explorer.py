#!/usr/bin/env python3
"""A browsable view of the relations layer — one HTML file, no server, no install.

    python3 platform/tools/relations_explorer.py --out <file outside the checkout>   # render the page
    (no --check: the page is never committed, so there is nothing to compare it against)

WHY A GENERATED PAGE AND NOT A DATABASE. The question this layer answers — "for this cancer, which
biomarkers?" — is a dictionary lookup, and a dictionary lookup does not need a triple store, a
server, or a port. A file you can double-click is the smallest thing that makes the layer usable by
a person, and it is the first rung of a ladder whose later rungs read the SAME artifact: a Streamlit
or Shiny app for ad-hoc queries, and a SPARQL endpoint if a second team ever needs one. Starting
here forecloses neither.

SELF-CONTAINED ON PURPOSE. The data is embedded rather than fetched, because a browser opening a
`file://` page refuses to fetch a sibling file — the page would work when served and be silently
empty when opened by hand, which is the worst of both. Embedding costs a compaction step and buys a
page that works from a USB stick.

NOT COMMITTED, AND `--out` HAS NO DEFAULT. `repo_hygiene` refuses a committed `*.html` outright:
a saved web page is the shape a vendor documentation portal is captured in, and the pattern has no
allowlist. This page WAS committed for one commit, which made it the only tracked .html in the
repository — the rule is right and the page was wrong. `executive_page.py` sets the convention
this now follows: the caller names a destination outside the checkout, the generator refuses one
inside it, and the page is one command away from anyone who wants it. The DATA is committed; the
rendering is not, which is the same split every other rendered view here uses.

DETERMINISTIC. Sorted throughout and no clock, so two runs of one layer produce one page.

IT SHOWS WHAT THE LAYER REFUSES TO SAY, NOT ONLY WHAT IT SAYS. Modality is a first-class control:
`possible` outnumbers `asserted` five to one in this release and there are explicit REFUTATIONS, so
a viewer that silently pooled them would overstate the evidence by a factor of five and invert
nearly two thousand claims. The page opens on `asserted`, and the other two are one click away and
labelled.
"""
from __future__ import annotations

import argparse
import json
import os
import sys

TOOLS = os.path.dirname(os.path.abspath(__file__))
from rwd_services import workspace_root
ROOT = str(workspace_root(__file__))

from rwd_tools import pack_run                                                            # noqa: E402
from rwd_tools import umls_relations as ur                                                 # noqa: E402

# NO DEFAULT DESTINATION. A default inside the checkout is what put this page in git.
DEFAULT_NAME = "RELATIONS.html"

AXES = ("gene", "molecular_abnormality", "cytogenetic_abnormality", "abnormal_cell")
AXIS_LABEL = {
    "gene": "Gene",
    "molecular_abnormality": "Molecular abnormality",
    "cytogenetic_abnormality": "Cytogenetic abnormality",
    "abnormal_cell": "Abnormal cell",
}
MODALITY_NOTE = {
    "asserted": "the source states the association",
    "possible": "the source allows it — 'may have', not 'has'",
    "refuted": "the source EXCLUDES it from this disease",
}


def compact(doc):
    """The layer as position-indexed arrays, so the page stays a fraction of the JSON's size.

    Every concept appears once in a name table and edges reference it by index. A cancer with 379
    partners would otherwise repeat each partner's CUI and name in full.
    """
    names, index = [], {}

    def idx(cui, name):
        if cui not in index:
            index[cui] = len(names)
            names.append([cui, name or ""])
        return index[cui]

    axes = list(AXES)
    mods = list(ur.MODALITIES)
    label = doc.get("concepts") or {}
    rows = []
    for cui in sorted(doc.get("diseases") or {}):
        d = idx(cui, label.get(cui))
        edges = []
        for row in doc["diseases"][cui] or []:
            p = ur.edge(doc, row)              # ONE decoder — see umls_relations.edge
            got = [m for m in (p.get("modalities") or [p.get("modality")]) if m in mods]
            if p.get("axis") not in axes or not got:
                continue
            # EVERY MODALITY, so the page's filter cannot hide what the release asserts. 139 edges
            # carry more than one and 58 are asserted AND refuted; emitting the summary word alone
            # meant a reader filtering to "asserted" never saw them, on a page whose whole purpose
            # is to show what the release says.
            edges.append([idx(p["cui"], label.get(p["cui"])), axes.index(p["axis"]),
                          mods.index(p["modality"]), sorted(mods.index(m) for m in got)])
        if edges:
            rows.append([d, sorted(edges)])

    # THE TAXONOMY TRAVELS TOO, or the page shows the number the roll-up exists to correct:
    # `Prostate Acinar Adenocarcinoma` reads as 2 partners against its parent's 57, and a reader
    # cannot tell a narrow concept from a poorly-covered one. Emitted as indices into the same
    # name table, and only for concepts the page can actually reach.
    up = {}
    for narrow, broads in (doc.get("broader") or {}).items():
        if narrow not in index:
            continue
        kept = [index[b] for b in broads if b in index]
        if kept:
            up[index[narrow]] = sorted(kept)

    # `KLK3 gene` and `KLK3 wt Allele` are two concepts and one gene. The stem index lets the page
    # count what a reader would count without pretending the two concepts are one.
    stems, stem_ix = [], {}
    for i, (_cui, nm) in enumerate(names):
        s = ur.stem(nm)
        if s not in stem_ix:
            stem_ix[s] = len(stems)
            stems.append(s)
    per_name = [stem_ix[ur.stem(nm)] for _cui, nm in names]
    return {"names": names, "axes": axes, "mods": mods, "rows": rows,
            "up": up, "stems": stems, "stemOf": per_name}


TEMPLATE = r"""<!doctype html>
<html lang="en"><head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Cancer Biomarker Relations</title>
<style>
:root{
  --ground:#F6F8F9;--surface:#FFFFFF;--alt:#EDF1F3;--ink:#101A21;--soft:#3C4C57;--faint:#6B7C87;
  --rule:#D6DEE3;--soft-rule:#E6ECEF;--accent:#0B6E77;--accent-soft:#D9EBED;
  --asserted:#1F6B4E;--asserted-bg:#DDEDE4;--possible:#8A5A06;--possible-bg:#F4E8D2;
  --refuted:#8C3A2E;--refuted-bg:#F3E0DC;
}
@media (prefers-color-scheme:dark){:root:not([data-theme="light"]){
  --ground:#0C1418;--surface:#121D23;--alt:#18262D;--ink:#E8EFF2;--soft:#B3C3CC;--faint:#7E9099;
  --rule:#26363E;--soft-rule:#1D2C33;--accent:#4FBCC4;--accent-soft:#163336;
  --asserted:#6FC79D;--asserted-bg:#143024;--possible:#D9A34A;--possible-bg:#33270F;
  --refuted:#DC8B7C;--refuted-bg:#331A16;
}}
:root[data-theme="dark"]{
  --ground:#0C1418;--surface:#121D23;--alt:#18262D;--ink:#E8EFF2;--soft:#B3C3CC;--faint:#7E9099;
  --rule:#26363E;--soft-rule:#1D2C33;--accent:#4FBCC4;--accent-soft:#163336;
  --asserted:#6FC79D;--asserted-bg:#143024;--possible:#D9A34A;--possible-bg:#33270F;
  --refuted:#DC8B7C;--refuted-bg:#331A16;
}
*{box-sizing:border-box}
body{margin:0;background:var(--ground);color:var(--ink);
  font-family:"IBM Plex Sans",ui-sans-serif,system-ui,-apple-system,Segoe UI,sans-serif;
  font-size:15px;line-height:1.55}
header{border-bottom:1px solid var(--rule);background:var(--surface);padding:1.15rem 1.5rem}
.hwrap{max-width:1240px;margin:0 auto;display:flex;flex-wrap:wrap;gap:1rem;align-items:baseline}
h1{font-size:1.12rem;font-weight:600;margin:0;letter-spacing:-.01em}
.prov{font-size:.78rem;color:var(--faint);font-family:ui-monospace,SFMono-Regular,Menlo,monospace}
main{max-width:1240px;margin:0 auto;padding:1.25rem 1.5rem 4rem;
  display:grid;grid-template-columns:minmax(260px,340px) 1fr;gap:1.5rem;align-items:start}
.panel{background:var(--surface);border:1px solid var(--rule);border-radius:6px}
.controls{padding:.9rem;border-bottom:1px solid var(--soft-rule);display:flex;flex-direction:column;gap:.7rem}
input[type=search]{width:100%;padding:.55rem .7rem;font:inherit;color:var(--ink);
  background:var(--ground);border:1px solid var(--rule);border-radius:4px}
input[type=search]:focus{outline:2px solid var(--accent);outline-offset:1px}
fieldset{border:0;margin:0;padding:0;display:flex;flex-wrap:wrap;gap:.35rem}
legend{font-size:.7rem;text-transform:uppercase;letter-spacing:.09em;color:var(--faint);
  padding:0;margin-bottom:.35rem}
.chip{font-size:.74rem;padding:.24em .6em;border-radius:3px;border:1px solid var(--rule);
  background:var(--ground);color:var(--soft);cursor:pointer;font-family:ui-monospace,monospace}
.chip[aria-pressed=true]{border-color:transparent;font-weight:600}
.chip.m-asserted[aria-pressed=true]{background:var(--asserted-bg);color:var(--asserted)}
.chip.m-possible[aria-pressed=true]{background:var(--possible-bg);color:var(--possible)}
.chip.m-refuted[aria-pressed=true]{background:var(--refuted-bg);color:var(--refuted)}
.chip.ax[aria-pressed=true]{background:var(--accent-soft);color:var(--accent)}
.chip:focus-visible{outline:2px solid var(--accent);outline-offset:1px}
#list{max-height:70vh;overflow-y:auto}
.item{display:block;width:100%;text-align:left;background:none;border:0;border-bottom:1px solid var(--soft-rule);
  padding:.6rem .9rem;font:inherit;color:var(--ink);cursor:pointer}
.item:hover{background:var(--alt)}
.item[aria-current=true]{background:var(--accent-soft)}
.item .n{display:block;font-size:.9rem;line-height:1.35}
.item .c{display:block;font-size:.72rem;color:var(--faint);font-family:ui-monospace,monospace;margin-top:.1rem}
#detail{padding:1.25rem 1.4rem;min-height:60vh}
#detail h2{margin:0 0 .2rem;font-size:1.3rem;letter-spacing:-.012em;text-wrap:balance}
.cui{font-family:ui-monospace,monospace;font-size:.78rem;color:var(--faint)}
.axgroup{margin-top:1.5rem}
.axgroup h3{font-size:.74rem;text-transform:uppercase;letter-spacing:.09em;color:var(--faint);
  margin:0 0 .6rem;display:flex;align-items:center;gap:.6rem}
.axgroup h3::after{content:"";flex:1;height:1px;background:var(--soft-rule)}
.plist{display:flex;flex-wrap:wrap;gap:.4rem}
.p{display:inline-flex;align-items:center;gap:.45rem;border:1px solid var(--soft-rule);
  border-radius:4px;padding:.3rem .55rem;background:var(--ground);font-size:.85rem;
  cursor:pointer;color:var(--ink);font-family:inherit}
.p:hover{border-color:var(--accent)}
.p.inh{border-style:dashed;color:var(--soft)}
.p:focus-visible{outline:2px solid var(--accent);outline-offset:1px}
.dot{width:7px;height:7px;border-radius:50%;flex:none}
.d-asserted{background:var(--asserted)}.d-possible{background:var(--possible)}.d-refuted{background:var(--refuted)}
/* A dot showing one word for evidence that says two. The ring says the colour is a
   summary, so a reader does not take it for the whole answer. */
.dot.conflict{box-shadow:0 0 0 2px var(--surface),0 0 0 3px var(--refuted)}
.confl{font-size:.72rem;color:var(--faint);font-variant:all-small-caps;letter-spacing:.04em}
.empty{color:var(--faint);font-size:.9rem;margin-top:2rem;max-width:56ch}
.counts{font-size:.8rem;color:var(--faint);margin-top:.5rem;font-family:ui-monospace,monospace}
.legend{margin-top:2.2rem;padding-top:1rem;border-top:1px solid var(--soft-rule);
  font-size:.8rem;color:var(--faint);max-width:70ch}
.legend b{color:var(--soft);font-weight:600}
.legend p{margin:.3rem 0}
@media(max-width:820px){main{grid-template-columns:1fr}#list{max-height:40vh}}
</style></head><body>
<header><div class="hwrap">
  <h1>Cancer biomarker relations</h1>
  <span class="prov">__PROV__</span>
</div></header>
<main>
  <div class="panel">
    <div class="controls">
      <label><span class="visually-hidden"></span>
        <input type="search" id="q" placeholder="Search a cancer…" autocomplete="off"
               aria-label="Search a cancer by name or CUI"></label>
      <fieldset><legend>Evidence</legend><div class="plist" id="mods"></div></fieldset>
      <fieldset><legend>Relation</legend><div class="plist" id="axes"></div></fieldset>
      <fieldset><legend>Scope</legend><div class="plist" id="scope"></div></fieldset>
    </div>
    <div id="list" role="listbox" aria-label="Cancers"></div>
  </div>
  <div class="panel" id="detail"></div>
</main>
<script id="data" type="application/json">__DATA__</script>
<script>
(function(){
  var D = JSON.parse(document.getElementById('data').textContent);
  var NAMES = D.names, AXES = D.axes, MODS = D.mods, ROWS = D.rows;
  var UP = D.up || {}, STEMS = D.stems || [], STEMOF = D.stemOf || [];
  var rollUp = false;
  var AXLABEL = __AXLABEL__, MODNOTE = __MODNOTE__;
  var onMods = {asserted:true, possible:false, refuted:false};
  var onAxes = {}; AXES.forEach(function(a){ onAxes[a] = true; });
  var current = ROWS.length ? ROWS[0][0] : null;

  var byDisease = {};
  ROWS.forEach(function(r){ byDisease[r[0]] = r[1]; });

  function nm(i){ return NAMES[i][1] || NAMES[i][0]; }
  function stemOf(i){ return STEMOF.length ? STEMS[STEMOF[i]] : nm(i); }
  // BOUNDED, because the top of an oncology taxonomy is "Neoplasm": inheriting from there hands
  // every cancer every edge in the release — complete, useless, and impossible to
  // tell apart from a good answer.
  function ancestors(d){
    var seen = {}, out = [], frontier = [d], depth = 0;
    seen[d] = 1;
    while (frontier.length && depth < 3){
      var next = [];
      for (var i = 0; i < frontier.length; i++){
        var ps = UP[frontier[i]] || [];
        for (var j = 0; j < ps.length; j++){
          if (!seen[ps[j]]){ seen[ps[j]] = 1; out.push(ps[j]); next.push(ps[j]); }
        }
      }
      frontier = next; depth++;
    }
    return out;
  }
  // Edges for a cancer, optionally including its parents'. Each says whether it was inherited,
  // because an edge about the PARENT must never read as one the source asserts of this concept.
  function edgesFor(d){
    var out = [], seen = {};
    var srcs = [d].concat(rollUp ? ancestors(d) : []);
    for (var s = 0; s < srcs.length; s++){
      var es = byDisease[srcs[s]] || [];
      for (var i = 0; i < es.length; i++){
        var e = es[i], k = e[0] + ':' + e[1];
        if (seen[k]) continue;
        seen[k] = 1;
        out.push([e[0], e[1], e[2], modsOf(e), srcs[s] !== d, srcs[s]]);
      }
    }
    return out;
  }
  function cui(i){ return NAMES[i][0]; }
  // e[3] is every modality the edge carries; e[2] is the summary word the dot is coloured by.
  // Filtering on e[2] alone hid the 58 asserted-and-refuted pairs from the "asserted" view.
  function modsOf(e){ return (e[3] && e[3].length ? e[3] : [e[2]]); }
  function keep(e){ return modsOf(e).some(function(m){ return onMods[MODS[m]]; }) && onAxes[AXES[e[1]]]; }

  function chip(box, cls, label, on, toggle){
    var b = document.createElement('button');
    b.className = 'chip ' + cls; b.type = 'button'; b.textContent = label;
    b.setAttribute('aria-pressed', on ? 'true' : 'false');
    b.addEventListener('click', function(){
      var next = b.getAttribute('aria-pressed') !== 'true';
      b.setAttribute('aria-pressed', next ? 'true' : 'false');
      toggle(next); render(); detail();
    });
    box.appendChild(b);
  }

  var modsBox = document.getElementById('mods'), axesBox = document.getElementById('axes');
  MODS.forEach(function(m){
    chip(modsBox, 'm-' + m, m, onMods[m], function(v){ onMods[m] = v; });
  });
  AXES.forEach(function(a){
    chip(axesBox, 'ax', AXLABEL[a] || a, true, function(v){ onAxes[a] = v; });
  });
  chip(document.getElementById('scope'), 'ax', 'include parent concepts', false,
       function(v){ rollUp = v; });

  var listEl = document.getElementById('list'), qEl = document.getElementById('q');

  function matches(){
    var q = qEl.value.trim().toLowerCase();
    var out = [];
    for (var i = 0; i < ROWS.length; i++){
      var d = ROWS[i][0];
      var edges = edgesFor(d), n = 0;
      for (var j = 0; j < edges.length; j++) if (keep(edges[j])) n++;
      if (!n) continue;
      if (q && nm(d).toLowerCase().indexOf(q) < 0 && cui(d).toLowerCase().indexOf(q) < 0) continue;
      out.push([d, n]);
    }
    out.sort(function(a,b){ return b[1] - a[1] || (nm(a[0]) < nm(b[0]) ? -1 : 1); });
    return out;
  }

  function render(){
    var rows = matches();
    listEl.textContent = '';
    if (!rows.length){
      var p = document.createElement('div');
      p.className = 'empty'; p.style.padding = '1rem';
      p.textContent = 'No cancer matches this search with the evidence levels selected. '
        + 'That is a result, not an error — try enabling "possible".';
      listEl.appendChild(p);
      return;
    }
    rows.slice(0, 400).forEach(function(r){
      var b = document.createElement('button');
      b.className = 'item'; b.type = 'button';
      b.setAttribute('aria-current', r[0] === current ? 'true' : 'false');
      var n = document.createElement('span'); n.className = 'n'; n.textContent = nm(r[0]);
      var c = document.createElement('span'); c.className = 'c';
      c.textContent = cui(r[0]) + ' · ' + r[1] + (r[1] === 1 ? ' partner' : ' partners');
      b.appendChild(n); b.appendChild(c);
      b.addEventListener('click', function(){ current = r[0]; render(); detail(); });
      listEl.appendChild(b);
    });
  }

  function detail(){
    var el = document.getElementById('detail');
    el.textContent = '';
    if (current === null || !byDisease[current]){
      var e = document.createElement('p'); e.className = 'empty';
      e.textContent = 'Select a cancer.'; el.appendChild(e); return;
    }
    var h = document.createElement('h2'); h.textContent = nm(current); el.appendChild(h);
    var c = document.createElement('div'); c.className = 'cui'; c.textContent = cui(current);
    el.appendChild(c);

    var edges = edgesFor(current).filter(keep);
    var tally = {asserted:0, possible:0, refuted:0}, gs = {}, inh = 0;
    edges.forEach(function(e){
      // TALLIED UNDER EVERY CLAIM IT CARRIES, matching the layer's own counts: the totals
      // exceed the edge count by exactly the number of conflicted edges, and that is the point.
      modsOf(e).forEach(function(m){ tally[MODS[m]]++; });
      gs[stemOf(e[0])] = 1; if (e[4]) inh++;
    });
    var cnt = document.createElement('div'); cnt.className = 'counts';
    // THE COUNT A READER WOULD GIVE. UMLS carries `KLK3 gene` and `KLK3 wt Allele` separately, so
    // an edge count is roughly double what a person would call the answer.
    cnt.textContent = Object.keys(gs).length + ' distinct — ' + edges.length
      + ' edges (' + MODS.map(function(m){ return tally[m] + ' ' + m; }).join(', ')
      + (inh ? '; ' + inh + ' inherited' : '') + ')';
    el.appendChild(cnt);

    if (!edges.length){
      var p = document.createElement('p'); p.className = 'empty';
      p.textContent = 'Nothing at the selected evidence levels. This cancer is typed as a '
        + 'neoplasm and the source relates it to nothing carried here — an answer, not a gap.';
      el.appendChild(p);
    }

    AXES.forEach(function(ax, ai){
      var mine = edges.filter(function(e){ return e[1] === ai; });
      if (!mine.length) return;
      var g = document.createElement('div'); g.className = 'axgroup';
      var t = document.createElement('h3');
      t.textContent = (AXLABEL[ax] || ax) + ' (' + mine.length + ')';
      g.appendChild(t);
      var list = document.createElement('div'); list.className = 'plist';
      mine.sort(function(a,b){ return nm(a[0]) < nm(b[0]) ? -1 : 1; });
      mine.forEach(function(e){
        var b = document.createElement('button'); b.className = 'p'; b.type = 'button';
        if (e[4]) b.classList.add('inh');
        var words = modsOf(e).map(function(m){ return MODS[m]; });
        var say = words.join(' AND ');
        var d = document.createElement('span');
        // COLOURED BY THE SUMMARY WORD, LABELLED WITH ALL OF THEM. A single dot cannot show two
        // claims, so the one it shows is the most cautious and the text says what was summarised.
        d.className = 'dot d-' + MODS[e[2]] + (words.length > 1 ? ' conflict' : '');
        d.title = say + ' — ' + (MODNOTE[MODS[e[2]]] || '');
        b.appendChild(d);
        b.appendChild(document.createTextNode(nm(e[0])));
        if (words.length > 1){
          var w = document.createElement('span');
          w.className = 'confl'; w.textContent = ' (' + say + ')';
          b.appendChild(w);
        }
        b.title = cui(e[0]) + ' · ' + say + ' — ' + (MODNOTE[MODS[e[2]]] || '');

        b.addEventListener('click', function(){
          qEl.value = nm(e[0]); render();
          if (byDisease[e[0]]){ current = e[0]; render(); detail(); }
        });
        list.appendChild(b);
      });
      g.appendChild(list); el.appendChild(g);
    });

    var lg = document.createElement('div'); lg.className = 'legend';
    MODS.forEach(function(m){
      var p = document.createElement('p');
      var b = document.createElement('b'); b.textContent = m + ': ';
      p.appendChild(b);
      p.appendChild(document.createTextNode(MODNOTE[m] || ''));
      lg.appendChild(p);
    });
    var p2 = document.createElement('p');
    p2.style.marginTop = '.7rem';
    p2.textContent = 'Machine-derived candidates projected from UMLS. Nothing here has been ruled '
      + 'by a person.';
    lg.appendChild(p2);
    el.appendChild(lg);
  }

  qEl.addEventListener('input', render);
  render(); detail();
})();
</script></body></html>
"""


def render(doc):
    """The page, as a string. Pure and deterministic."""
    c = doc.get("counts") or {}
    prov = (f"{doc.get('layer')} {doc.get('layer_version')} · UMLS {doc.get('release')} · "
            f"{c.get('diseases_with_partners', 0):,} cancers · {c.get('edges', 0):,} edges")
    data = json.dumps(compact(doc), separators=(",", ":"), sort_keys=True, ensure_ascii=False)
    # `</script>` inside embedded JSON would close the tag early. No UMLS string should contain it,
    # but a projection that could be broken by its own data is not one to ship on that assumption.
    data = data.replace("</", "<\\/")
    return (TEMPLATE
            .replace("__PROV__", prov)
            .replace("__AXLABEL__", json.dumps(AXIS_LABEL, sort_keys=True))
            .replace("__MODNOTE__", json.dumps(MODALITY_NOTE, sort_keys=True))
            .replace("__DATA__", data))


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    ap.add_argument("--out", help=f"where to write the page (default name {DEFAULT_NAME}); "
                                 f"required, and must be outside the checkout")
    a = ap.parse_args(argv)

    doc = ur.load()
    if not doc:
        print("UNCHECKED — no relations layer committed yet. Build one with:")
        print("  python3 platform/tools/umls_relations.py --release <UMLS release dir> --build")
        return 0

    if not a.out:
        sys.exit("--out is required (and must be outside the checkout — repo_hygiene refuses a "
                 "committed *.html)")
    # expanduser BEFORE abspath: an unexpanded '~/x.html' arriving via argv would otherwise become
    # '<cwd>/~/x.html', which no later expansion can repair.
    wanted = os.path.expanduser(a.out)
    out_dir = pack_run.restricted_dir(os.path.dirname(os.path.abspath(wanted)),
                                      what="the rendered page")
    os.makedirs(out_dir, exist_ok=True)
    out = os.path.join(out_dir, os.path.basename(wanted) or DEFAULT_NAME)
    body = render(doc)
    with open(out, "w", encoding="utf-8", newline="\n") as fh:
        fh.write(body)
    c = doc.get("counts") or {}
    print(f"wrote {out}  ({os.path.getsize(out) / 1048576:.2f} MB, "
          f"{c.get('diseases_with_partners', 0):,} cancers)")
    print("open it directly in a browser — no server needed")
    return 0


if __name__ == "__main__":
    from rwd_tools.console import use_utf8
    use_utf8()
    sys.exit(main())
