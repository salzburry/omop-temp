#!/usr/bin/env python3
"""Stand a new product pack up from the template — ONE command, previewed, validated, all or nothing.

    python platform/tools/new_product.py bladder_local --code bladder_local --name "Bladder local" \\
        --tumour-family bladder --condition-class oncology --modality ehr \\
        --vendor flatiron --tumor-class solid --spec-version 202609 --narrow genitourinary \\
        --ai-classification sponsor_ai_eligible --classified-by "A. Person" \\
        --classified-date 2026-09-04 [--workbook path/to/PROG_SPEC.xlsx]            # PREVIEW
    ...the same command with --apply                                                  # WRITE

WHY. The eleventh external verdict followed the runbook literally and found the create-a-product
journey spread over eleven files in four directories — the registry, the activation file, the
tumour registry, the oncology catalogue, its indication module, the inventory overlay, the
metadata catalogue, the source registration, the pipeline configuration, the config identity, the
bundle — each refused by a different gate, each discovered one CI failure at a time, and no
single operation that did all of it or none of it. This is that operation.

WHAT IT DOES, EXACTLY. It computes a PLAN — every file it would create or edit, from the template
and the values on the command line — and prints it. With `--apply` it stages that plan in a
disposable copy of the checkout, runs the repository's OWN validators there (the registry tests,
the oncology registry, the bundle render, Gate 1 over the new pack, the maturity claims, the
generated pages), and only when every one of them passes copies the resulting files into the
real checkout. A refused plan leaves the checkout byte-identical; the refusal names the validator
and its words.

WHAT IT DOES NOT DO. It types no judgement. The three Gate 1 fields no tool may infer —
`ai_classification`, `classified_by`, `classified_date` — are the person's, exactly as
`source_refs_init.py` demands them; every scientific value in the config stays `REPLACE_ME` for
the contract to fill; the catalogue row claims `maturity: registered`, which claims nothing; and
the commit that lands `classified_by` still needs that person's review signature
(`approval_identity.py --check` says so). The pack it leaves behind is at the START of Gate 1,
with nothing asserted that nobody decided.

stdlib plus PyYAML through the repository's own readers.
"""
from __future__ import annotations

import argparse
from collections import Counter
import datetime
import errno
import filecmp
import fnmatch
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import tempfile

TOOLS = os.path.dirname(os.path.abspath(__file__))
from rwd_services import workspace_root, prepare_snapshot_runtime, SnapshotRuntimeTimeout, python_module_command, package_asset, package_file_map
REPO = str(workspace_root(__file__))

from rwd_tools import person_rules as pr                                               # noqa: E402
from rwd_tools import product_gates as pg                                              # noqa: E402
from rwd_tools import source_manifest as sm                                            # noqa: E402
from rwd_tools import spec_lint                                                        # noqa: E402
from rwd_tools.product_gates import MODALITIES                                    # noqa: E402
from rwd_tools.spec_extract import repo_relative                                  # noqa: E402

TEMPLATE_REL = "platform/TUMOR_TEMPLATE"
SLUG_RE = re.compile(r"^[a-z][a-z0-9_]*$")
VERSION_RE = re.compile(r"^[0-9]{6}$")
TUMOR_CLASSES = ("solid", "heme", "not_applicable")
BROAD_BY_CLASS = {"solid": "solid", "heme": "haematological", "not_applicable": "general"}
# validators run INSIDE the staged copy, in this order; each is (label, argv relative to the copy)
VALIDATORS = (
    ("oncology modules regenerated for the new overlay", ["platform/tools/registry_enrich.py", "--write"]),
    ("oncology modules in step with the inventory", ["platform/tools/registry_enrich.py", "--check"]),
    ("oncology registry", ["platform/tools/oncology_registry.py", "--check"]),
    ("registry schema", ["platform/tools/registry_schema.py", "--check"]),
    ("product registry consistency", ["platform/tools/registry_schema.py", "--check-products"]),
    ("metadata catalogue mirrors the registry", ["platform/tools/registry_schema.py", "--check-catalog"]),
    ("product bundle rendered", ["platform/tools/bundle_products.py"]),
    ("product bundle and activation legal", ["platform/tools/bundle_products.py", "--check"]),
    ("inventory coverage page regenerated", ["platform/tools/inventory_coverage.py"]),
    ("inventory coverage page current", ["platform/tools/inventory_coverage.py", "--check"]),
    ("citation register page regenerated", ["platform/tools/citation_register.py"]),
    ("citation register page current", ["platform/tools/citation_register.py", "--check"]),
    ("new product maturity and existing-product regressions", ["platform/tools/product_gates.py", "--maturity-report-json"]),
    ("master-family register", ["platform/tools/master_family.py", "--check"]),
    ("current state regenerated", ["platform/tools/current_state.py"]),
    ("portfolio regenerated", ["platform/tools/portfolio_status.py"]),
)
# THE WRITE GOES THROUGH A TEMP SIBLING (install): every destination is measured WITH this suffix,
# because that is the name Windows sees first. MAX_PATH is 260 including the terminating NUL, so
# 259 characters is the longest name a checkout with long paths disabled can create; the limit on
# the destination itself is what the walk asked for (a destination over 250 is refused as such).
TMP_SUFFIX = ".new_product.tmp"
WINDOWS_MAX_PATH = 259
WINDOWS_PATH_LIMIT = 250
# what the staged run generates under the pack beyond the plan's own files — measured too, since
# they are installed with everything else
GENERATED_UNDER_PACK = ("source_refs.yaml", "spec_pipeline/out/extracted.json", "spec_pipeline/out/lint.json",
                        "spec_pipeline/out/SPEC_FINDINGS.txt", "spec_pipeline/out/COVERAGE.md",
                        "spec_pipeline/out/scaffold.json", "spec_pipeline/out/SCAFFOLDED_RECORDS.md",
                        "spec_pipeline/out/ENUMERATION_CANDIDATES.yaml")
SAME_ROWS = ("The two workbooks contain the same rows. A data refresh with no requirement change is not a "
             "new cut.")
TOO_LONG = ("This checkout's folder path is too long for Windows by {n} characters; move the checkout to a "
            "shorter folder such as C:\\rwd, or ask your data expert to enable long paths")


from rwd_services import WorkflowIssue, finding, issue_of, issue_results, run_workflow_command


def _os_name():
    """The platform, as one seam a test can replace without touching the os module."""
    return os.name


def _read(path):
    with open(path, encoding="utf-8") as fh:
        return fh.read()


def _sub_once(text, pattern, repl, what):
    """One anchored substitution that MUST match exactly once — the template moved otherwise."""
    n = len(re.findall(pattern, text, re.M))
    if n != 1:
        raise SystemExit(f"REFUSED — {what}: expected exactly one line matching {pattern!r} in the "
                         f"template, found {n}. The template changed under this tool; fix the tool "
                         f"before it writes anything.")
    # User wording is literal text. re.sub's string replacement language treats a
    # backslash as an escape/backreference, so an ordinary A\B label used to crash.
    return re.sub(pattern, lambda _match: repl, text, count=1, flags=re.M)


def _insert_after_line(text, line_pattern, block, what):
    """Insert `block` right after the first line matching `line_pattern` (a YAML key line)."""
    m = re.search(line_pattern, text, re.M)
    if not m:
        raise SystemExit(f"REFUSED — {what}: no line matches {line_pattern!r}; the governed file "
                         f"changed shape under this tool.")
    end = m.end()
    return text[:end] + "\n" + block.rstrip("\n") + text[end:]


def _registry_list_indent(text):
    """Read the existing block sequence's indent without rewriting its comments."""
    import yaml
    try:
        document = yaml.compose(text)
    except yaml.YAMLError as error:
        raise SystemExit("REFUSED — products/registry.yaml is not readable YAML") from error
    sequences = [value for key, value in document.value if key.value == "tumors"] \
        if isinstance(document, yaml.MappingNode) else []
    if (len(sequences) != 1 or not isinstance(sequences[0], yaml.SequenceNode)
            or sequences[0].flow_style):
        raise SystemExit("REFUSED — products/registry.yaml must declare one tumors block list")
    return sequences[0].start_mark.column


def _append_catalog_code(text, code):
    """Append to a YAML list without reserializing catalogue definitions/comments."""
    import yaml
    from engine.strict_yaml import strict_load

    refusal = "REFUSED — products/metadata/catalog.yaml"
    try:
        document = strict_load(text)
        node = yaml.compose(text)
    except (yaml.YAMLError, ValueError, TypeError) as error:
        raise SystemExit(refusal + " is not readable, unambiguous YAML") from error
    codes = document.get("tumor_codes") if isinstance(document, dict) else None
    if (not isinstance(codes, list)
            or any(not isinstance(value, str) or not SLUG_RE.fullmatch(value) for value in codes)
            or len(codes) != len(set(codes))):
        raise SystemExit(refusal + " must declare one tumor_codes list of distinct product-code strings")
    if not isinstance(code, str) or not SLUG_RE.fullmatch(code):
        raise SystemExit(refusal + ": the new product code is not a valid identifier")
    if code in codes:
        return text
    sequence = next(value for key, value in node.value if key.value == "tumor_codes")
    if any(not sequence.start_mark.index <= value.start_mark.index < value.end_mark.index <= sequence.end_mark.index
           for value in sequence.value):
        raise SystemExit(refusal + ": tumor_codes must contain directly stated codes, not aliases")
    quoted = json.dumps(code)
    if sequence.flow_style:
        position = sequence.value[-1].end_mark.index if codes else sequence.end_mark.index - 1
        insertion = (", " if codes else "") + quoted
    else:
        last = sequence.value[-1]
        position = last.end_mark.index
        newline = "\r\n" if "\r\n" in text else "\n"
        prefix = ""
        if last.end_mark.column:
            end = text.find("\n", position)
            position = end + 1 if end >= 0 else len(text)
            prefix = "" if end >= 0 else newline
        insertion = prefix + " " * sequence.start_mark.column + "- " + quoted + newline
    result = text[:position] + insertion + text[position:]
    try:
        unchanged_metadata = strict_load(result) == {**document, "tumor_codes": [*codes, code]}
    except (yaml.YAMLError, ValueError, TypeError):
        unchanged_metadata = False
    if not unchanged_metadata:
        raise SystemExit(refusal + ": appending the code would change other metadata; review YAML aliases or list layout")
    return result


def _families(root):
    spec_lint._REGISTRY_ROOT = root
    spec_lint._REGISTRY = None
    reg = spec_lint.tumour_registry()
    return reg, spec_lint._names_family


def _narrow_words():
    from rwd_tools import oncology_registry as onc                                      # noqa: PLC0415
    return [str(x) for x in onc.NARROW]


def catalogue_choices(root, tumour_family):
    """Existing catalogue classifications for a named tumour, without inventing defaults."""
    reg = spec_lint.load_tumour_registry(root)
    family = reg["aliases"].get(tumour_family, tumour_family)
    if reg.get("condition_classes", {}).get(family, "oncology") == "non_oncology":
        return {"condition_class": "non_oncology", "tumor_class": "not_applicable", "narrow": "general"}
    document, error = pg.read_yaml(os.path.join(root, "governance/reference/oncology_modules/CATALOGUE.yaml"))
    if error or not isinstance(document, dict) or not isinstance(document.get("cancers"), dict):
        raise ValueError("The oncology catalogue cannot supply current setup choices.")
    rows = [row for key, row in (document.get("cancers") or {}).items() if isinstance(row, dict)
            and (row.get("inventory_overlay") == family or reg["aliases"].get(key, key) == family)]
    choices = {}
    for field, values in (("tumor_class", {"solid": "solid", "haematological": "heme"}), ("narrow", None)):
        found = {values.get(row.get("broad")) if values else row.get("narrow") for row in rows}
        if len(found) == 1 and None not in found:
            choices[field] = found.pop()
    return choices


def workbook_population(source, root, *, domains=None):
    """Counts from the canonical population matcher; never return source cell text.

    ``source`` can be the local path or an already bounded in-memory workbook.
    This early check does not replace the canonical extraction/validation on apply.
    """
    from rwd_tools import spec_extract as se
    reg = spec_lint.load_tumour_registry(root)
    mapping = dict(se.shared_sheet_map(root)["sheets"])
    mapping.update(domains or {})
    sheets = {name for name, domain in mapping.items() if domain == "study_population"}
    population = se.read_xlsx(source, read_only=True, sheets=sheets)
    matches = {family: 0 for family in reg["families"]}
    non_oncology = set()
    for row in population:
        text = " | ".join(sm.redact_vendor_prose(cell, "setup population")[0] for cell in row["cells"])
        for family in matches:
            matches[family] += bool(spec_lint.names_disease(text, family, registry=reg))
        non_oncology.update(spec_lint.names_non_oncology(text, registry=reg))
    return {"families": [family for family, count in matches.items() if count],
            "population_rows": len(population), "non_oncology": sorted(non_oncology)}


def sheet_scope_options(names, root, previous_pack=None):
    """Classify workbook sheet labels through the existing extraction map, without reading cells.

    Only sheets without a requirement domain use IGNORE. Removing mapped scientific
    sections belongs to Plan changes, where their definitions and consumers are visible.
    """
    from rwd_tools import spec_extract as se
    from rwd_tools.run_spec_pipeline import read_conf
    previous = []
    overrides = {}
    explicit_tabs = set()
    if previous_pack:
        parts = str(previous_pack).replace("\\", "/").split("/")
        if len(parts) != 4 or parts[0] != "products" or any(p in {"", ".", ".."} for p in parts):
            raise ValueError("The previous product must be products/<family>/<slug>/<YYYYMM>.")
        conf = read_conf(os.path.join(root, *parts, "spec_pipeline", "pipeline.conf"))
        previous = [x.strip() for x in conf.get("IGNORE", "").split(",") if x.strip()]
        overrides = se.parse_domains(conf.get("DOMAINS", ""))
        explicit_tabs = se.parse_ignore(conf.get("TABS", ""))
    mapping = se.shared_sheet_map(root)
    domains = dict(mapping["sheets"], **overrides)
    previous_keys = se.parse_ignore(",".join(previous))
    labels = [str(name) for name in names]
    counts = {key: sum(se.sheet_key(name) == key for name in labels) for key in map(se.sheet_key, labels)}
    rows = []
    for name in labels:
        key = se.sheet_key(name)
        domain = domains.get(key, "")
        kind = "requirement" if domain or key in explicit_tabs else "ignored" if key in mapping["ignored"] else "unclassified"
        safe = bool(name.strip()) and not any(c in name for c in ",#\"'\r\n") and not any(ord(c) < 32 for c in name)
        rows.append({"name": name, "domain": domain, "kind": kind,
                     "selectable": kind != "requirement" and (kind == "unclassified" or key in previous_keys) and safe and counts[key] == 1,
                     "mapping_selectable": (kind == "unclassified" or (kind == "requirement" and bool(domain))) and safe
                         and not any(c in name for c in "=$`") and counts[key] == 1,
                     "ambiguous": counts[key] > 1})
    inherited = [name for name in labels if se.sheet_key(name) in previous_keys]
    return {"sheets": rows, "inherited": inherited,
            "mapping_domains": sorted({domain for domain in domains.values()
                if isinstance(domain, str) and re.fullmatch(r"[a-z][a-z0-9_]*", domain)}),
            "missing_inherited": [name for name in previous if se.sheet_key(name) not in counts]}


def workbook_sheet_scope(workbook, root, previous_pack=None):
    """Read workbook sheet names for the same scope controls used by the portal."""
    import openpyxl
    try:
        wb = openpyxl.load_workbook(workbook, read_only=True, data_only=False, keep_links=False)
        try:
            names = list(wb.sheetnames)
            from rwd_tools.spec_extract import validate_sheet_titles
            validate_sheet_titles(names)
        finally:
            wb.close()
        scope = sheet_scope_options(names, root, previous_pack)
        with open(workbook, "rb") as stream:
            scope["sha256"] = hashlib.sha256(stream.read()).hexdigest()
        return scope
    except (OSError, ValueError):
        raise
    except Exception as exc:
        raise ValueError("The workbook could not be read. Open it in your spreadsheet tool and save a valid XLSX copy.") from exc


def _sheet_domains(a):
    """Explicit overrides after sheet_domain_refusals validates their exact labels."""
    from rwd_tools.spec_extract import parse_domains
    return parse_domains(",".join(getattr(a, "sheet_domain", None) or []))


def _column_choices(a):
    from rwd_tools.spec_extract import parse_column_map
    return parse_column_map(getattr(a, "column_map", "") or "")


def _column_origin(a):
    """Bounded descriptive model provenance, never permission or scientific approval."""
    value = getattr(a, "column_map_origin", "") or ""
    if not value:
        return None
    if not isinstance(value, str) or len(value.encode("utf-8")) > 4096:
        raise ValueError("The workbook mapping origin must be a bounded JSON model descriptor.")
    def pairs(items):
        output = {}
        for key, item in items:
            if key in output:
                raise ValueError("The workbook mapping origin repeats a field.")
            output[key] = item
        return output
    try:
        origin = json.loads(value, object_pairs_hook=pairs)
    except (ValueError, TypeError) as error:
        raise ValueError("The workbook mapping origin must contain valid JSON without repeated fields.") from error
    keys = {"kind", "provider", "model", "model_info", "proposal_sha256"}
    if not isinstance(origin, dict) or set(origin) != keys or origin["kind"] != "model_proposal_and_user":
        raise ValueError("Use only model proposal metadata for the workbook mapping origin; approval and authority fields are not accepted.")
    def label(item, *, optional=False):
        return (isinstance(item, str) and len(item) <= 300 and (optional or bool(item.strip()))
                and all(char.isprintable() for char in item)
                and not re.search(r"^(?:[A-Za-z]:[\\/]|[\\/]|~[\\/])|\.\.[\\/]|[a-z]+://", item, re.I))
    info = origin["model_info"]
    if (not label(origin["provider"]) or not label(origin["model"])
            or not isinstance(info, dict) or set(info) - {"id", "name", "family", "vendor", "version"}
            or any(not label(item, optional=key == "version") for key, item in info.items())
            or not isinstance(origin["proposal_sha256"], str)
            or not re.fullmatch(r"[0-9a-f]{64}", origin["proposal_sha256"])):
        raise ValueError("Use provider/model names, supported model descriptor fields and the proposal SHA-256; paths and extra metadata are not accepted.")
    return origin


@issue_results("workbook_column_mapping_invalid")
def column_map_refusals(a, root):
    """A confirmed local mapping is checked against this workbook before staging."""
    value = getattr(a, "column_map", "") or ""
    reason = str(getattr(a, "column_map_reason", "") or "").strip()
    origin = getattr(a, "column_map_origin", "") or ""
    if not value and not reason and not origin:
        return []
    if not value:
        return ["A workbook column reason or origin requires --column-map."]
    errors = []
    if not reason or pr.unstated(reason) or len(reason) > 1000 or any(ord(c) < 32 for c in reason):
        errors.append("Explain the workbook column choices in one line with --column-map-reason.")
    try:
        from rwd_tools.spec_extract import inspect_columns
        _column_origin(a)
        choices = _column_choices(a)
        if not choices:
            errors.append("Choose at least one worksheet column mapping.")
        else:
            inspect_columns(a.workbook, choices)
    except (OSError, ValueError, TypeError) as error:
        errors.append("Review the workbook column mapping: " + str(error))
    return errors


@issue_results("workbook_sheet_mapping_invalid")
def sheet_domain_refusals(a, root):
    """Assign or correct exact requirement-sheet sections within this specification."""
    selected = list(getattr(a, "sheet_domain", None) or [])
    reason = str(getattr(a, "sheet_domain_reason", "") or "").strip()
    if not selected and not reason:
        return []
    if not selected:
        return ["--sheet-domain-reason requires at least one --sheet-domain."]
    errors = []
    if not reason or pr.unstated(reason):
        errors.append("Explain the intended section for these sheets with --sheet-domain-reason.")
    elif len(reason) > 1000 or any(ord(c) < 32 for c in reason):
        errors.append("The sheet-domain reason must be one line, at most 1,000 characters.")
    try:
        scope = workbook_sheet_scope(a.workbook, root, getattr(a, "next_cut_of", None))
    except (OSError, ValueError, TypeError):
        return errors + ["Attach a readable workbook before mapping its sheets."]
    sheets = {row["name"]: row for row in scope["sheets"]}
    seen = set()
    for value in selected:
        name, separator, domain = str(value).partition("=")
        row = sheets.get(name)
        if not separator or not row:
            errors.append(f"Sheet mapping {value!r} must name an exact sheet in this workbook followed by =domain.")
        elif not row["mapping_selectable"]:
            errors.append(f"{name!r} cannot be mapped here: choose a recognized requirement or unclassified sheet with an unambiguous label; reference/context sheets retain their scope.")
        elif domain not in scope["mapping_domains"]:
            errors.append(f"{domain!r} is not an existing specification domain. Choose from " + ", ".join(scope["mapping_domains"]) + ".")
        if name in seen:
            errors.append(f"Choose the section for {name!r} only once.")
        if name in (getattr(a, "exclude_sheet", None) or []):
            errors.append(f"{name!r} cannot be both mapped as requirements and excluded.")
        seen.add(name)
    return errors


@issue_results("workbook_scope_invalid")
def sheet_scope_refusals(a, root):
    """Validate an explicit per-product exclusion before staging; never change the workbook."""
    selected = list(getattr(a, "exclude_sheet", None) or [])
    reason = str(getattr(a, "exclude_sheet_reason", "") or "").strip()
    out = sheet_domain_refusals(a, root) + column_map_refusals(a, root)
    if not selected and not reason:
        return out
    if not selected:
        return ["--exclude-sheet-reason requires at least one --exclude-sheet."]
    if not a.workbook or not os.path.isfile(a.workbook):
        return ["Attach a workbook before choosing sheets to exclude."]
    if not reason or pr.unstated(reason):
        out.append("Explain why these sheets are outside this product's scope with --exclude-sheet-reason.")
    elif len(reason) > 1000 or any(ord(c) < 32 for c in reason):
        out.append("The sheet exclusion reason must be one line, at most 1,000 characters.")
    try:
        scope = workbook_sheet_scope(a.workbook, root, getattr(a, "next_cut_of", None))
    except (OSError, ValueError) as exc:
        return out + [f"Cannot check workbook sheet exclusions: {exc}"]
    by_name = {row["name"]: row for row in scope["sheets"]}
    if len(selected) != len(set(selected)):
        out.append("Choose each excluded sheet only once.")
    for name in selected:
        row = by_name.get(name)
        if row is None:
            out.append(f"Excluded sheet {name!r} is not in this workbook; choose its exact sheet name.")
        elif row["kind"] == "requirement":
            why = f"mapped {row['domain']} requirements" if row["domain"] else "requirements explicitly selected by the prior pipeline configuration"
            out.append(f"{name!r} contains {why}. Use Plan changes to remove scientific sections with their dependency impact; this control handles extra sheets.")
        elif row["kind"] == "ignored" and not row["selectable"] and not row["ambiguous"]:
            out.append(f"{name!r} is already excluded by the shared sheet map; no product-specific exclusion is needed.")
        elif not row["selectable"]:
            out.append(f"{name!r} has an ambiguous label or characters the pipeline configuration cannot represent. Rename the sheet in the workbook before excluding it.")
    if selected and set(selected) == set(by_name):
        out.append("Do not exclude every workbook sheet; retain the product's specification requirements.")
    if not out:
        from rwd_tools import spec_extract as se
        try:
            domains = {se.sheet_key(row["name"]): row["domain"] for row in scope["sheets"] if row["domain"]}
            domains.update(_sheet_domains(a))
            extracted = se.extract(a.workbook, domains, se.parse_ignore(",".join(selected)), _column_choices(a))
            if not any(row.get("domain") and row.get("variable") and not se.is_context(row)
                       for row in extracted["rows"]):
                out.append("The workbook must retain at least one named requirement on a mapped specification sheet. Extra sheets cannot stand in for the product's requirements.")
        except Exception as exc:
            out.append(f"Cannot read the included specification requirements ({type(exc).__name__}). Open the workbook and save a valid XLSX copy.")
    if not out:
        a._sheet_scope = {**scope, "selected": selected, "reason": reason}
    return out


def _scope_conf(text, a):
    """Write current-workbook exclusions; a next cut must reselect its scope."""
    selected = list(getattr(a, "exclude_sheet", None) or [])
    columns = _column_choices(a)
    origin = _column_origin(a)
    if origin is not None and not columns:
        raise ValueError("A workbook column origin requires --column-map.")
    if columns:
        from rwd_tools.spec_extract import EXTRACTOR_VERSION
        line = "COLUMN_MAP=" + json.dumps(columns, ensure_ascii=False, separators=(",", ":"))
        existing = re.search(r"^[ \t]*COLUMN_MAP[ \t]*=[^\n]*", text, re.M)
        text = text[:existing.start()] + line + text[existing.end():] if existing else text.rstrip("\n") + "\n" + line + "\n"
        with open(a.workbook, "rb") as stream:
            workbook_sha256 = hashlib.sha256(stream.read()).hexdigest()
        note = {"reason": str(getattr(a, "column_map_reason", "") or "").strip(),
                "recorded_by": getattr(a, "classified_by", ""), "recorded_on": getattr(a, "classified_date", ""),
                "workbook_sha256": workbook_sha256, "parser": "confirmed_column_map", "parser_version": EXTRACTOR_VERSION,
                "scope": "this specification only; no scientific approval"}
        if origin is not None:
            note["origin"] = origin
        text = re.sub(r"^# Workbook columns:[^\n]*\n?", "", text, flags=re.M)
        text = text.rstrip("\n") + "\n# Workbook columns: " + json.dumps(note, ensure_ascii=False) + "\n"
    mappings = _sheet_domains(a)
    if mappings:
        from rwd_tools.spec_extract import parse_domains
        match = re.search(r"^\s*DOMAINS\s*=\s*([^\n]*)$", text, re.M)
        old = match.group(1).split("#", 1)[0].strip().strip('"').strip("'") if match else ""
        combined = dict(parse_domains(old), **mappings)
        line = 'DOMAINS="' + ",".join(f"{name}={domain}" for name, domain in sorted(combined.items())) + '"'
        text = text[:match.start()] + line + text[match.end():] if match else text.rstrip("\n") + "\n" + line + "\n"
        # TABS, when explicit, must admit the newly mapped sections in this cut.
        tabs = re.search(r"^\s*TABS\s*=\s*([^\n]*)$", text, re.M)
        if tabs:
            value = tabs.group(1).split("#", 1)[0].strip().strip('"').strip("'")
            if value:
                names = list(dict.fromkeys([*value.split(","), *mappings]))
                text = text[:tabs.start()] + 'TABS="' + ",".join(names) + '"' + text[tabs.end():]
        note = {"mappings": mappings, "reason": str(a.sheet_domain_reason).strip(),
                "scope": "this specification only; no scientific approval"}
        text = re.sub(r"^# Sheet domains:[^\n]*\n?", "", text, flags=re.M)
        text = text.rstrip("\n") + "\n# Sheet domains: " + json.dumps(note, ensure_ascii=False) + "\n"
    if getattr(a, "next_cut_of", None):
        text = re.sub(r"^[ \t]*IGNORE[ \t]*=[^\n]*\n?", "", text, flags=re.M)
        text = re.sub(r"^# Sheet scope:[^\n]*\n?", "", text, flags=re.M)
    if not selected:
        return text
    from rwd_tools.spec_extract import sheet_key
    match = re.search(r"^\s*IGNORE\s*=\s*([^\n]*)$", text, re.M)
    previous = match.group(1).split("#", 1)[0].strip().strip('"').strip("'") if match else ""
    names = [name.strip() for name in previous.split(",") if name.strip()]
    for name in selected:
        if sheet_key(name) not in {sheet_key(item) for item in names}:
            names.append(name)
    line = 'IGNORE="' + ",".join(names) + '"'
    if match:
        text = text[:match.start()] + line + text[match.end():]
    else:
        text = text.rstrip("\n") + "\n\n" + line + "\n"
    note = {"sheets": selected, "reason": str(a.exclude_sheet_reason).strip(),
            "recorded_by": a.classified_by, "recorded_on": a.classified_date,
            "scope": "this product specification only; no scientific approval"}
    return text.rstrip("\n") + "\n# Sheet scope: " + json.dumps(note, ensure_ascii=False) + "\n"


def _registry_setup_issues(rows, *, existing=False):
    """Carry the registry producer's findings, never interpret its prose."""
    issues = []
    for row in rows:
        check, message = row["check"], row["message"]
        details = row.get("details", {})
        if (not isinstance(check, str) or not re.fullmatch(r"[a-z][a-z0-9_]{0,79}", check)
                or not isinstance(message, str) or not message.strip() or len(message) > 3500
                or not isinstance(details, dict) or any(not isinstance(value, str) for value in details.values())):
            raise ValueError("Invalid registry finding.")
        details = dict(details, validator=check, scope="workspace")
        conflict = check == "registry_status_matches_config_status" and "product" in details
        code = ("setup_existing_product_status_conflict" if conflict else
                "setup_existing_registry_invalid" if existing else "setup_registry_validation_failed")
        guidance = (" Ask the workspace owner to review this existing product's registry and configuration "
                    "status before creating another product. Keep the workbook unchanged; changing a status "
                    "does not approve or release a product." if conflict else
                    " Ask the workspace owner to correct this registry finding, then preview the setup again.")
        issues.append(finding(code, message + guidance, **details))
    return issues


def existing_product_status_issues(root):
    """A cheap read-only Preview check, also used to recheck a reported conflict."""
    from dataclasses import asdict
    from rwd_tools import registry_schema
    try:
        rows = registry_schema.product_registry_findings(
            root, selected_checks=("registry_status_matches_config_status",))
        return _registry_setup_issues([asdict(row) for row in rows], existing=True)
    except (OSError, ValueError, TypeError, KeyError) as error:
        return [finding("setup_existing_registry_invalid",
            "The existing product registry and configuration statuses could not be checked. "
            "Ask the workspace owner to restore readable product records, then preview the setup again.",
            validator="registry_status_matches_config_status", scope="workspace", error_type=type(error).__name__)]


@issue_results("setup_input_invalid")
def refusals(a, root):
    """Every reason the plan cannot be made — all of them, before a byte is staged."""
    if a.workbook and os.path.isfile(a.workbook) and a.workbook.lower().endswith((".xlsx", ".xlsm")):
        try:
            workbook_sheet_scope(a.workbook, root)
        except (OSError, ValueError) as error:
            return [f"--workbook: {error}"]
    existing = existing_product_status_issues(root)
    if a.next_cut_of:
        return existing + next_cut_refusals(a, root)
    out = []
    for flag in ("code", "name", "vendor", "tumor_class", "narrow", "condition_class", "modality"):
        if getattr(a, flag, None) in (None, ""):
            out.append(f"--{flag.replace('_', '-')} is required for a new product (a next cut derives it "
                       f"from the registry: --next-cut-of)")
    if out:
        return existing + out
    out.extend(existing)
    if not SLUG_RE.fullmatch(a.slug or ""):
        out.append(f"slug {a.slug!r} is not [a-z][a-z0-9_]* — the folder, the job name, the bundle "
                   f"variable prefix and the artifact namespace all spell it")
    if not SLUG_RE.fullmatch(a.family or ""):
        out.append(f"family {a.family!r} is not [a-z][a-z0-9_]* — use one folder name for the product grouping")
    if not SLUG_RE.fullmatch(a.code or ""):
        out.append(f"code {a.code!r} is not [a-z][a-z0-9_]*")
    bad_ver = pg.bad_spec_version(a.spec_version)
    if bad_ver:
        out.append(bad_ver)
    if a.tumor_class not in TUMOR_CLASSES:
        out.append(f"tumor-class {a.tumor_class!r} is not one of {TUMOR_CLASSES}")
    cond = str(a.condition_class or "").strip().lower()
    if cond == "non_oncology":
        if a.tumor_class != "not_applicable":
            out.append("--condition-class non_oncology requires --tumor-class not_applicable; no oncology class is inferred")
        if a.family != "conditions":
            out.append("--condition-class non_oncology requires --family conditions")
        if a.narrow != "general" or a.broad not in (None, "", "general"):
            out.append("--condition-class non_oncology requires catalogue axes general (--narrow general; --broad general when supplied)")
    elif cond == "oncology" and a.tumor_class == "not_applicable":
        out.append("--condition-class oncology requires --tumor-class solid or heme")
    if not str(a.name or "").strip() or "|" in str(a.name):
        out.append("name is blank or carries `|`")
    if any(ord(c) < 32 for c in str(a.name or "")):
        out.append("name must be one line without control characters — use spaces between the words")
    policy, err = pg.read_yaml(os.path.join(root, "governance", "vendor_policy.yaml"))
    vendors = sorted((policy or {}).get("vendors") or {}) if not err else []
    if a.vendor not in vendors:
        out.append(f"vendor {a.vendor!r} is not in governance/vendor_policy.yaml (have: {', '.join(vendors)}) — "
                   f"nothing would decide which schema evidence this product owes")
    elif ((policy or {}).get("vendors", {}).get(a.vendor) or {}).get("schema_evidence") == pg.PENDING_SCHEMA_EVIDENCE:
        if a.modality != "claims":
            out.append(f"vendor {a.vendor!r} has pending schema-evidence review and supports draft claims "
                       "registration only. Its EHR delivery route and source layout have not been established; "
                       "ask the source owner and Engineering to review them before registering an EHR product.")
    elif a.modality == "ehr":
        from engine.vendors import DEFAULT_LAYOUTS
        if a.vendor not in DEFAULT_LAYOUTS:
            out.append(f"vendor {a.vendor!r} has no EHR source-layout adapter for product registration. "
                       "Engineering must supply the supported layout before an EHR product can be created; "
                       "a vendor policy entry does not implement a data adapter.")
    # WHAT THE VENDOR DELIVERS, said at preview. A Cota solid product used to surface as the
    # staged registry test's traceback (`AssertionError: COTA tumor not heme: {...}`), after six
    # seconds of staging and never at preview; a claims product as `remove it, or add its pack`
    # from the activation check, about the pack this very command was adding (thirteenth pass).
    if a.vendor == "cota" and a.tumor_class == "solid":
        out.append("vendor 'cota' delivers haematological (heme) products only (platform/tests/test_registry.py "
                   "holds every Cota tumour to tumor_class heme) — a solid product of cota is refused; name the "
                   "vendor that delivers this tumour, or tumor-class heme if that is what it is")
    # Claims registration is useful before a production executor exists. Its
    # plan deliberately omits EHR activation; maturity remains not_started and
    # the canonical claims gates still refuse execution/release claims.
    if a.ai_classification not in sm.AI_CLASSES:
        out.append(f"ai-classification {a.ai_classification!r} is not one of {list(sm.AI_CLASSES)}")
    if pr.unstated(a.classified_by):
        out.append("classified-by is a placeholder, not a person")
    else:
        why = pr.not_a_person(a.classified_by)
        if why:
            out.append(f"classified-by {a.classified_by!r}: {why}")
    bad = pg.bad_date(a.classified_date)
    if bad:
        out.append(f"classified-date {bad}")
    from rwd_tools import oncology_registry as onc                                      # noqa: PLC0415
    broad = a.broad or (BROAD_BY_CLASS[a.tumor_class] if a.tumor_class in TUMOR_CLASSES else None)
    if cond != "non_oncology" and broad is not None and (broad not in onc.BROAD or broad == "general"):
        out.append(f"broad axis {broad!r} is not one of {' | '.join(onc.BROAD)}")
    if cond != "non_oncology" and (a.narrow not in onc.NARROW or a.narrow == "general"):
        out.append(f"narrow axis {a.narrow!r} is not one of {onc.NARROW} — the oncology catalogue "
                   f"files every cancer under one; pass --narrow")
    for reg_rel in ("products/registry.yaml", "fixtures/registry.yaml"):
        reg, err = pg.read_yaml(os.path.join(root, reg_rel))
        if err:
            continue
        for t in (reg or {}).get("tumors") or []:
            if isinstance(t, dict) and str(t.get("slug")) == a.slug and reg_rel.startswith("products"):
                out.append(f"slug {a.slug!r} is already registered in {reg_rel}")
            if isinstance(t, dict) and str(t.get("code")) == a.code and reg_rel.startswith("products"):
                out.append(f"code {a.code!r} is already registered in {reg_rel}")
    pack = f"products/{a.family}/{a.slug}/{a.spec_version}"
    if os.path.exists(os.path.join(root, pack)):
        out.append(f"{pack} already exists")
    cat, err = pg.read_yaml(os.path.join(root, "governance", "reference", "oncology_modules", "CATALOGUE.yaml"))
    if not err and a.slug in ((cat or {}).get("cancers") or {}):
        out.append(f"{a.slug} already has a row in the oncology catalogue")
    inv, err = pg.read_yaml(os.path.join(root, "governance", "reference", "variable_inventory", "INVENTORY.yaml"))
    if not err and a.slug in ((inv or {}).get("tumours") or {}):
        out.append(f"{a.slug} already has an inventory overlay")
    if os.path.exists(os.path.join(root, "governance", "reference", "oncology_modules", "indication",
                                   f"{a.slug}.yaml")):
        out.append(f"indication:{a.slug} module already exists")
    # the tumour registry: a NEW family must not share a token with an existing one, in either
    # direction — the matcher is the registry's own (spec_lint._names_family), not a second opinion
    try:
        reg, names_family = _families(root)
    except SystemExit as e:
        out.append(str(e))
        reg, names_family = None, None
    if reg is not None:
        fams = reg["families"]
        if a.tumour_family:
            if a.tumour_family not in fams:
                out.append(f"--tumour-family {a.tumour_family!r} is not a family in governance/tumour_registry.yaml "
                           f"(have: {', '.join(sorted(fams))})")
            elif reg.get("condition_classes", {}).get(a.tumour_family, "oncology") != cond:
                out.append(f"--tumour-family {a.tumour_family!r} has condition_class "
                           f"{reg.get('condition_classes', {}).get(a.tumour_family, 'oncology')}; "
                           f"a product of this family must keep that declared condition class")
            if a.slug in fams:
                out.append(finding("setup_family_collision", f"{a.slug} is the tumour family itself — choose a distinct product slug with --tumour-family {a.tumour_family}", family=a.slug))
            elif a.slug in reg["aliases"] and reg["aliases"][a.slug] != a.tumour_family:
                out.append(f"{a.slug} is already an alias of {reg['aliases'][a.slug]} in governance/tumour_registry.yaml; choose that tumour family or a different slug")
        else:
            if a.slug in fams:
                out.append(finding("setup_family_collision", f"{a.slug} is the tumour family itself (governance/tumour_registry.yaml) — a product OF the "
                           f"{a.slug} tumour needs its own slug (for example {a.slug}_flatiron) with --tumour-family {a.slug}", family=a.slug))
            elif a.slug in reg["aliases"]:
                out.append(f"{a.slug} is already in governance/tumour_registry.yaml (an alias of {reg['aliases'][a.slug]})")
            for fam, stems in fams.items():
                if a.slug == fam:
                    continue                                        # said once, above, with the remedy that works
                if names_family(f"t_{a.slug}_x", stems):
                    out.append(f"slug {a.slug!r} shares a token with tumour family {fam!r} ({', '.join(stems)}) — "
                               f"a second family claiming it would flag the other's tables everywhere. A "
                               f"product OF that tumour is an alias: pass --tumour-family {fam}")
                for s in stems:
                    if names_family(f"t_{s}_x", [a.slug]):
                        out.append(f"stem {a.slug!r} would claim family {fam!r}'s tables ({s}) — pass "
                                   f"--tumour-family {fam} if this is a product of that tumour")
    # Condition identity is explicit. Generic products select a separate engine path;
    # an oncology declaration must still refuse known non-oncology disease terms.
    if a.condition_class and str(a.condition_class).strip() != cond:
        out.append(f"--condition-class {a.condition_class!r} is spelt in the vocabulary's own case: {cond} — a "
                   f"declaration is typed exactly, as --tumor-class is")
    if cond not in {"oncology", "non_oncology"}:
        out.append(f"--condition-class {a.condition_class!r} is not one of oncology | non_oncology; "
                   "declare the condition explicitly, never relabel it solid or heme to pass")
    for what, text in (() if cond == "non_oncology" else
                       (("slug", a.slug), ("--name", a.name), ("--disease-terms", a.disease_terms))):
        hits = spec_lint.names_non_oncology(str(text or "").replace("_", " "))
        if hits:
            out.append(f"{what} {text!r} names {', '.join(hits)}, which governance/tumour_registry.yaml "
                       f"`non_oncology_terms` records as a non-oncology condition — declare "
                       f"non_oncology with tumor-class not_applicable, never relabel it solid or heme")
    # A PHRASE NAMES ONE TUMOUR. `--disease-terms 'prostate cancer'` on a product called hnc (a person
    # on the pushed branch, 2026-09-04) would have made every prostate workbook declare hnc too and
    # every hnc workbook prostate: the positive identification rests on the phrases being
    # discriminating, exactly as the stems are.
    if not a.tumour_family and reg is not None:
        for phrase in disease_terms(a):
            owner = next((fam for fam, terms in reg.get("disease_terms", {}).items() if phrase in terms), None) \
                or next((fam for fam, stems in fams.items() if phrase in stems), None)
            if owner and owner != a.slug:
                out.append(f"--disease-terms {phrase!r} already names the {owner} family in "
                           f"governance/tumour_registry.yaml — a phrase names ONE tumour, or the disease "
                           f"check cannot tell the two workbooks apart. If this product is OF {owner}, "
                           f"pass --tumour-family {owner}; otherwise name this disease in its own words")
    if not a.tumour_family and not str(a.disease_terms or "").strip():
        out.append("--disease-terms is required for a NEW tumour family: the phrases a specification "
                   "uses to name the disease in prose (e.g. \"renal cell carcinoma, kidney cancer\"), "
                   "so DECLARED_DISEASE can establish that a workbook registered to this pack is this "
                   "tumour's and not another's. `--name` alone is a display label")
    if a.workbook and not os.path.isfile(a.workbook):
        out.append(f"--workbook {a.workbook} is not a file")
    if a.workbook and not a.workbook.lower().endswith((".xlsx", ".xlsm")):
        out.append("--workbook must be an .xlsx / .xlsm program specification")
    out += sheet_scope_refusals(a, root)
    return out


def next_cut_context(a, root):
    """Fill the product's identity from the registry entry of the pack `--next-cut-of` names, and
    say every way the request is not a next cut of that product. [refusals]."""
    out = []
    old = str(a.next_cut_of or "").replace("\\", "/").strip("/")
    parts = old.split("/")
    if len(parts) != 4 or parts[0] != "products":
        return [f"--next-cut-of {a.next_cut_of!r} is not products/<family>/<slug>/<YYYYMM> — the previous cut "
                f"of a REGISTERED product; a fixture's next cut is a fixture question, and a folder "
                f"of documents is not a pack"]
    _p, family, slug, old_ver = parts
    if not os.path.isfile(os.path.join(root, old, "config", "data_product.yaml")):
        return [f"{old} is not a pack (no config/data_product.yaml)"]
    if a.slug != slug:
        out.append(f"slug {a.slug!r} is not the product {old} belongs to ({slug!r}) — a next cut is the SAME "
                   f"product at a later YYYYMM; another product is a new stand-up, or an alias of the tumour")
    if not VERSION_RE.match(old_ver):
        out.append(f"{old}: the version folder {old_ver!r} is not YYYYMM — a pack at the literal placeholder "
                   f"has no cut to succeed")
    elif VERSION_RE.match(a.spec_version or "") and int(a.spec_version) <= int(old_ver):
        out.append(f"spec-version {a.spec_version} is not later than {old_ver} — the next cut is a LATER YYYYMM; "
                   f"the order is the lineage")
    reg, err = pg.read_yaml(os.path.join(root, "products", "registry.yaml"))
    entry = None if err else next((t_ for t_ in ((reg or {}).get("tumors") or [])
                                   if isinstance(t_, dict) and str(t_.get("slug")) == slug), None)
    if entry is None:
        out.append(f"{slug} has no entry in products/registry.yaml — {old} is not a registered product")
        return out
    a.family = family
    for attr, key, default in (("code", "code", None), ("name", "name", None), ("vendor", "vendor", None),
                               ("tumor_class", "tumor_class", None), ("modality", "modality", "ehr"),
                               ("condition_class", "condition_class", "oncology")):
        want = entry.get(key) if entry.get(key) not in (None, "") else default
        have = getattr(a, attr, None)
        if have not in (None, "") and str(have) != str(want):
            out.append(f"--{attr.replace('_', '-')} {have!r} differs from the registry's {want!r} for {slug} — a "
                       f"next cut keeps the product's identity; change it in products/registry.yaml "
                       f"deliberately, never as a side effect of a new cut")
        setattr(a, attr, str(want))
    tk = str(entry.get("tumour_key") or "").strip()
    a.tumour_family = tk if tk and tk != slug else None
    cat, err = pg.read_yaml(os.path.join(root, "governance", "reference", "oncology_modules", "CATALOGUE.yaml"))
    row = None if err else ((cat or {}).get("cancers") or {}).get(slug)
    if isinstance(row, dict):
        a.broad = a.broad or row.get("broad")
        a.narrow = a.narrow or row.get("narrow")
    if not a.narrow:
        out.append(f"{slug} has no row in governance/reference/oncology_modules/CATALOGUE.yaml — the product "
                   f"was never fully stood up; finish that before cutting it again")
    if a.change_class not in ("breaking", "additive"):
        out.append("--change-class breaking|additive is required with --next-cut-of: the person classifies "
                   "what the revision does to existing values (governance/VERSIONING.md); `none` is not a "
                   "new cut")
    if not a.workbook:
        out.append("--workbook is required with --next-cut-of: a cut exists because the specification "
                   "changed, and the revised workbook is what the new pack registers and extracts")
    a._old, a._old_version, a._entry = old, old_ver, entry
    return out


@issue_results("setup_product_invalid")
def next_cut_refusals(a, root):
    """Every reason the next cut cannot be made, before a byte is staged. `--workbook` is checked
    to be a file BEFORE the byte-identical comparison runs: the comparison used to run on a path
    that did not exist and a mistyped path — the commonest error — gave a stack trace instead of
    the refusal composed a few lines earlier (thirteenth pass, J2)."""
    """The next-cut route's refusals: the context, the person's fields, the new folder."""
    out = next_cut_context(a, root)
    if pg.bad_spec_version(a.spec_version):
        out.append(pg.bad_spec_version(a.spec_version))
    if a.ai_classification not in sm.AI_CLASSES:
        out.append(f"ai-classification {a.ai_classification!r} is not one of {list(sm.AI_CLASSES)}")
    if pr.unstated(a.classified_by):
        out.append("classified-by is a placeholder, not a person")
    else:
        why = pr.not_a_person(a.classified_by)
        if why:
            out.append(f"classified-by {a.classified_by!r}: {why}")
    bad = pg.bad_date(a.classified_date)
    if bad:
        out.append(f"classified-date {bad}")
    if a.workbook and not os.path.isfile(a.workbook):
        out.append(f"--workbook {a.workbook} is not a file")
    if a.workbook and not a.workbook.lower().endswith((".xlsx", ".xlsm")):
        out.append("--workbook must be an .xlsx / .xlsm program specification")
    if a.change_note and pr.unstated(a.change_note):
        out.append(f"--change-note {a.change_note!r} is a placeholder, not a note — say what changed in one line, "
                   f"or leave it out")
    out += sheet_scope_refusals(a, root)
    if getattr(a, "_old", None):
        pack = f"products/{a.family}/{a.slug}/{a.spec_version}"
        if os.path.exists(os.path.join(root, pack)):
            out.append(f"{pack} already exists")
        same_bytes = False
        # every cut of the product, not only the one this cut follows (walk RW-04, 2026-09-07): a
        # revised workbook already registered as one cut must not become a second draft cut
        cuts = [a._old]
        for row in (getattr(a, "_entry", None) or {}).get("lineage") or []:
            version = str((row or {}).get("spec_version") or "") if isinstance(row, dict) else ""
            candidate = f"products/{a.family}/{a.slug}/{version}" if version else ""
            if candidate and candidate not in cuts and os.path.isdir(os.path.join(root, *candidate.split("/"))):
                cuts.append(candidate)
        for cut in cuts:
            old_wb = os.path.join(root, *cut.split("/"), "prog_spec")
            if a.workbook and os.path.isfile(a.workbook) and os.path.isdir(old_wb):
                for f in os.listdir(old_wb):
                    if f.lower().endswith((".xlsx", ".xlsm")) and filecmp.cmp(os.path.join(old_wb, f), a.workbook, shallow=False):
                        same_bytes = True
                        out.append(f"--workbook is byte-identical to {cut}/prog_spec/{f} — a next cut is a REVISED "
                                   f"specification; the same bytes are the same cut (a data refresh with no "
                                   f"requirement change is WORKFLOW.md §6.B, not a new spec_version)")
        # THE ROWS, NOT THE BYTES (walk NC-06 / NC-05, 2026-09-07): a workbook Excel re-saved has new
        # bytes and the same rows, and was accepted as a new cut; a revision that removed a variable
        # was accepted as `additive`. Both are read off the rows the extraction would produce, against
        # the rows the previous cut registered, before a byte is staged.
        if a.workbook and os.path.isfile(a.workbook) and a.workbook.lower().endswith((".xlsx", ".xlsm")) and not same_bytes:
            out += spec_change_refusals(a, root)
    return out


def _named_rows(data):
    """{(domain, VARIABLE): [rows]} over the requirement rows that name a variable, as the row editor
    reads them (requirement_rows, is_context): the rows a record can cite."""
    from rwd_tools.spec_extract import is_context, requirement_rows                    # noqa: PLC0415
    out = {}
    for r in requirement_rows(data):
        if is_context(r) or not r.get("variable") or not r.get("domain"):
            continue
        out.setdefault((r["domain"], str(r["variable"]).strip().upper()), []).append(r)
    return out


def _row_key(r):
    """Source cells/fields independent of sheet label and optional numeric Row coordinate."""
    from rwd_tools.spec_extract import coordinate_free_key
    return coordinate_free_key(r)


def _workbook_rows_digest(path):
    """One digest over every populated row of every sheet, values only, order-free: what two
    workbooks share when nothing but Excel's own bytes differ."""
    os.environ.setdefault("OPENPYXL_LXML", "False")
    import openpyxl                                                          # noqa: PLC0415
    wb = openpyxl.load_workbook(path, data_only=True, read_only=True)
    try:
        rows = []
        for ws in wb.worksheets:
            for row in ws.iter_rows(values_only=True):
                cells = ["" if c is None else str(c).strip() for c in row]
                if any(cells):
                    rows.append([ws.title.strip(), *cells])
    finally:
        wb.close()
    return hashlib.sha256(json.dumps(sorted(rows), ensure_ascii=False).encode("utf-8")).hexdigest()


def _dry_extraction(a, root):
    """The rows the pipeline WOULD produce from the revised workbook, computed in memory with the
    previous cut's own sheet map and overrides; nothing is written. (data, why-not)."""
    from rwd_tools.run_spec_pipeline import read_conf                                  # noqa: PLC0415
    from rwd_tools import spec_extract as se                                                # noqa: PLC0415
    conf_path = os.path.join(root, *a._old.split("/"), "spec_pipeline", "pipeline.conf")
    conf = read_conf(conf_path) if os.path.isfile(conf_path) else {"DOMAINS": "", "IGNORE": ""}
    try:
        domains = dict(se.shared_domains(root), **se.parse_domains(conf.get("DOMAINS") or ""))
        domains.update(_sheet_domains(a))
        # A different workbook needs a fresh scope choice; prior exclusions are
        # suggestions in the portal, never implicit current-workbook decisions.
        ignored = se.parse_ignore(",".join(getattr(a, "exclude_sheet", None) or []))
        # Reconfirm overrides for this cut when supplied; an unchanged sheet's
        # existing mapping remains reusable, with source provenance regenerated.
        columns = _column_choices(a)
        if not columns:
            columns = se.parse_column_map(conf.get("COLUMN_MAP") or "")
            if columns:
                old_path = os.path.join(root, *a._old.split("/"), "spec_pipeline", "out", "extracted.json")
                if not os.path.isfile(old_path):
                    return None, "Review the previous column mapping for this workbook; its prior extraction is unavailable."
                with open(old_path, encoding="utf-8") as stream:
                    previous = json.load(stream)
                current = {row["name"]: row for row in se.inspect_columns(a.workbook, columns)}
                for name, choice in columns.items():
                    prior_headers = {tuple(row.get("header") or []) for row in previous.get("rows", [])
                        if row.get("tab") == name and row.get("header") and (not choice.get("header_row")
                            or row.get("header_row") == choice["header_row"])}
                    latest = current.get(name) or {}
                    selected = choice.get("columns") or {}
                    by_letter = {column["letter"]: column["header"] for column in latest.get("columns", [])}
                    if not prior_headers or any(not any(se._column_number(letter) <= len(header)
                            and header[se._column_number(letter) - 1] == by_letter.get(letter)
                            for header in prior_headers) for letter in selected.values()):
                        return None, f"Review and confirm the column mapping for {name!r}; its header binding changed in this workbook."
        return se.extract(a.workbook, domains, ignored, columns), None
    except SystemExit as e:                                                  # the extractor refused the file
        return None, str(e).strip().splitlines()[0] if str(e).strip() else "the extractor refused it"
    except Exception as e:                                                   # noqa: BLE001 - a corrupt workbook is a fact to state, not a trace
        return None, f"{type(e).__name__}: {str(e)[:160]}"


def citing_records(root, old_pack, removed):
    """{VARIABLE: [record ids]} — the previous cut's contract records that cite a removed row
    (by spec_refs), carry its name, or depend on it."""
    from rwd_tools import contract_lint as cl                                               # noqa: PLC0415
    path = os.path.join(root, *old_pack.split("/"), "handoff", "FUNCTIONAL_CONTRACT.md")
    if not os.path.isfile(path) or not removed:
        return {}
    text = _read(path).replace("\r\n", "\n")
    out = {}
    for block in cl.records(text):
        vid = cl._scalar(block, "variable_id") or ""
        refs = set(cl._list(block, "spec_refs") or [])
        deps = {str(d).strip().upper() for d in (cl._list(block, "depends_on") or [])}
        for name, item_ids in removed.items():
            if vid.upper() == name or deps & {name} or refs & set(item_ids):
                out.setdefault(name, []).append(vid)
    return out


def spec_change(a, root):
    """What the revised workbook changes against the previous cut's REGISTERED extraction, by
    variable: {before, after, unchanged, moved, changed, definition_changed, removed, added, cited}.
    When the previous cut has no extraction the two workbooks are compared cell by cell instead
    ({same_rows}); when the revised workbook cannot be read, {failed}. Cached on `a`."""
    if getattr(a, "_delta", None) is not None:
        return a._delta
    from rwd_tools.spec_diff import sheet_mapping_review                              # noqa: PLC0415
    new, why = _dry_extraction(a, root)
    if new is None:
        a._delta = {"failed": why}
        return a._delta
    review = sheet_mapping_review(new)
    if review:
        a._delta = {"review_required": review}
        return a._delta
    old_path = os.path.join(root, *a._old.split("/"), "spec_pipeline", "out", "extracted.json")
    if not os.path.isfile(old_path):
        try:
            mine = _workbook_rows_digest(a.workbook)
            old_wb = os.path.join(root, *a._old.split("/"), "prog_spec")
            theirs = [_workbook_rows_digest(os.path.join(old_wb, f)) for f in sorted(os.listdir(old_wb))
                      if f.lower().endswith((".xlsx", ".xlsm"))] if os.path.isdir(old_wb) else []
            a._delta = {"same_rows": mine in theirs, "compared_workbooks": len(theirs)}
        except Exception as e:                                               # noqa: BLE001
            a._delta = {"failed": f"{type(e).__name__}: {str(e)[:160]}"}
        return a._delta
    with open(old_path, encoding="utf-8") as fh:
        old = json.load(fh)
    review = sheet_mapping_review(old, "previous cut's extraction")
    if review:
        a._delta = {"review_required": review}
        return a._delta
    before, after = _named_rows(old), _named_rows(new)
    d = {"before": len(before), "after": len(after), "unchanged": 0, "moved": [], "relabeled": [], "changed": [],
         "definition_changed": [], "removed": [], "added": []}
    removed_items = {}
    for key in sorted(before):
        name, rows = key[1], before[key]
        if key not in after:
            d["removed"].append(name)
            removed_items[name] = [str(r.get("item_id") or f"{r['domain']}:{r['row']}") for r in rows]
            continue
        theirs = after[key]
        if sorted(r.get("content_hash", "") for r in rows) == sorted(r.get("content_hash", "") for r in theirs):
            d["unchanged"] += 1
        elif all(_row_key(r) for r in rows) and sorted(_row_key(r) for r in rows) == sorted(_row_key(r) for r in theirs):
            kind = "relabeled" if sorted(r.get("tab", "") for r in rows) != sorted(r.get("tab", "") for r in theirs) else "moved"
            d[kind].append(name)
        else:
            d["changed"].append(name)
            old_def = sorted(str((r.get("fields") or {}).get("definition", "")) for r in rows)
            new_def = sorted(str((r.get("fields") or {}).get("definition", "")) for r in theirs)
            if old_def != new_def:
                d["definition_changed"].append(name)
    d["added"] = [key[1] for key in sorted(after) if key not in before]
    d["cited"] = citing_records(root, a._old, removed_items)
    a._delta = d
    return d


def _names(seq):
    return ", ".join(seq)


def spec_change_refusals(a, root):
    """The refusals the row comparison yields: the same rows are the same cut; a removal or a
    change is breaking, whatever the person typed."""
    d = spec_change(a, root)
    if d.get("review_required"):
        return [d["review_required"]]
    if "failed" in d:
        return ["The specification comparison could not be completed: " + str(d["failed"])
                + ". Review the workbook and previous extraction before previewing again."]
    if "same_rows" in d and not d["same_rows"]:
        return []
    if d.get("same_rows"):
        return [SAME_ROWS + f" (compared cell by cell with the previous cut's workbook, which has no extraction)"]
    if not (d["removed"] or d["changed"] or d["added"]):
        moved = f"; {len(d['moved'])} row(s) only renumbered" if d["moved"] else ""
        relabeled = f"; {len(d['relabeled'])} row(s) have a different worksheet label and unchanged fields" if d.get("relabeled") else ""
        return [SAME_ROWS + f" ({d['before']} requirement rows in both{moved}{relabeled})"]
    if a.change_class == "additive" and (d["removed"] or d["changed"]):
        parts = []
        if d["removed"]:
            parts.append(f"removes {len(d['removed'])} variable{'s' if len(d['removed']) != 1 else ''} ({_names(d['removed'])})")
        defs = d["definition_changed"]
        other = [x for x in d["changed"] if x not in defs]
        if defs:
            parts.append(f"changes {len(defs)} definition{'s' if len(defs) != 1 else ''} ({_names(defs)})")
        if other:
            parts.append(f"changes {len(other)} other row{'s' if len(other) != 1 else ''} ({_names(other)})")
        return [f"This revision {' and '.join(parts)}: that is breaking. Choose breaking, or keep additive and restore them."]
    return []


def delta_summary(d):
    """Render the retained comparison structure without parsing a CLI transcript."""
    if d.get("review_required"):
        return [d["review_required"]]
    if "failed" in d:
        return [f"not compared: the revised workbook could not be read ({d['failed']}); the staged extraction says more"]
    if "same_rows" in d:
        return ["the previous cut has no extraction, so the two workbooks were compared cell by cell: "
                + ("the same rows" if d["same_rows"] else "different rows")]
    parts = [f"{d['unchanged']} unchanged"]
    parts += [f"{n} moved (only its row number changed)" for n in d["moved"]]
    parts += [f"{n} is on a relabeled worksheet (its fields are unchanged)" for n in d.get("relabeled", [])]
    parts += [f"{n} changed" for n in d["changed"]]
    parts += [f"{n} removed" for n in d["removed"]]
    parts += [f"{n} added" for n in d["added"]]
    lines = [f"{d['before']} rows before, {d['after']} after: " + "; ".join(parts)]
    for name in d["removed"]:
        who = d["cited"].get(name) or []
        lines.append(f"{name} is cited by {len(who)} record{'s' if len(who) != 1 else ''} of the previous cut"
                     + (f": {_names(who)}" if who else "; nothing of that cut is written from it"))
    return lines


def destinations(root, pack, steps):
    """Every absolute path the install would create or replace, from the plan and from what the
    staged run generates under the pack."""
    rels = [rel for rel, _action, _payload in steps] + [f"{pack}/{g}" for g in GENERATED_UNDER_PACK]
    return [os.path.join(root, *rel.split("/")) for rel in rels]


def path_length_refusals(root, pack, steps, os_name=None):
    """On Windows, the longest destination measured against MAX_PATH with the temp sibling's suffix,
    before any validator runs (walk NC-02: a 300-character destination died in install())."""
    if (os_name or _os_name()) != "nt":
        return []
    longest = max(destinations(root, pack, steps), key=len)
    over = max(len(longest) + len(TMP_SUFFIX) - WINDOWS_MAX_PATH, len(longest) - WINDOWS_PATH_LIMIT)
    return [TOO_LONG.format(n=over)] if over > 0 else []


def install_failure_words(root, rels, exc):
    """A failed install as a sentence: the path-length problem when that is what it is, the
    operating system's own words otherwise; never a traceback, never a path."""
    longest = max((os.path.join(root, *r.split("/")) for r in rels), key=len, default=root)
    over = max(len(longest) + len(TMP_SUFFIX) - WINDOWS_MAX_PATH, len(longest) - WINDOWS_PATH_LIMIT)
    long_path = getattr(exc, "errno", None) == errno.ENAMETOOLONG or getattr(exc, "winerror", None) == 206 \
        or (_os_name() == "nt" and over > 0)
    if long_path:
        return TOO_LONG.format(n=max(over, 1)) + ". Every file this attempt had replaced was put back."
    return (f"The checkout could not be written ({getattr(exc, 'strerror', None) or type(exc).__name__}); "
            f"every file this attempt had replaced was put back.")


def _replace_entry(reg_text, slug, entry):
    """`products/registry.yaml` with the product's entry rewritten from `entry` — the one flow line
    or the block it occupies. Comments on that entry do not survive; the plan says so."""
    import yaml                                                              # noqa: PLC0415
    lines = reg_text.split("\n")
    hit = next((i for i, ln in enumerate(lines) if re.search(rf"\bslug:\s*{re.escape(slug)}\b", ln)), None)
    if hit is None:
        raise SystemExit(f"REFUSED — products/registry.yaml has no entry for {slug}")
    start = hit
    while start > 0 and not re.match(r"^  - ", lines[start]):
        start -= 1
    end = start + 1
    if not (lines[start].rstrip().endswith("}") and "{" in lines[start]):
        while end < len(lines) and not re.match(r"^  - |^\S", lines[end]):
            end += 1
    dumped = yaml.safe_dump([entry], sort_keys=False, default_flow_style=None, width=1000, allow_unicode=True)
    block = ["  " + ln if ln.strip() else ln for ln in dumped.rstrip("\n").split("\n")]
    return "\n".join(lines[:start] + block + lines[end:])


def plan_next_cut(a, root):
    """[(repo-relative path, action, text-or-None)] for the NEXT CUT of a registered product.

    What carries by COPY: the executable surface (config/, variables/, codelists/) and the
    pipeline's conf — the person revises them against the new specification. What does NOT carry:
    the contract records (spec_diff carries the ones whose text provably survived, through a plan a
    person runs), the decisions, the maturity claims (not_started), the source registration (the
    revised workbook is registered fresh, with its own digest). The registry keeps
    `current_spec_version` where it is: the new cut is a DRAFT beside the released one, and moves to
    current only when it is approved and released (.claude/skills/next-cut, WORKFLOW.md §6.C).
    """
    tpl = os.path.join(root, *TEMPLATE_REL.split("/"))
    if not os.path.isdir(tpl):
        tpl = str(package_asset(TEMPLATE_REL))
    pack = f"products/{a.family}/{a.slug}/{a.spec_version}"
    old, old_ver = a._old, a._old_version
    name = str(a.name).strip()
    carried = ("config/", "variables/", "codelists/")
    steps = []
    for dirpath, _dirs, files in os.walk(tpl):
        for f in sorted(files):
            src = os.path.join(dirpath, f)
            rel_in = repo_relative(src, tpl)
            if rel_in == "NEW_TUMOUR.md" or "__pycache__" in rel_in or rel_in.startswith(carried) \
                    or rel_in == "spec_pipeline/pipeline.conf":
                continue
            text = _read(src)
            if a.condition_class == "non_oncology":
                text = _non_oncology_template(a, rel_in, text)
                if text is None:
                    continue
            elif rel_in == "handoff/FUNCTIONAL_CONTRACT.md":
                text = _sub_once(text, r"^# Functional contract — <tumour> <YYYYMM>",
                                 f"# Functional contract — {name} {a.spec_version}", "contract title")
            steps.append((f"{pack}/{rel_in}", "create", text))
    old_abs = os.path.join(root, *old.split("/"))
    for dirpath, _dirs, files in os.walk(old_abs):
        for f in sorted(files):
            full = os.path.join(dirpath, f)
            rel_in = repo_relative(full, old_abs)
            if "__pycache__" in rel_in or not (rel_in.startswith(carried) or rel_in == "spec_pipeline/pipeline.conf"):
                continue
            text = _read(full)
            if rel_in == "config/data_product.yaml":
                text = _sub_once(text, rf'''^version:[ \t]*(?P<quote>["']?){old_ver}\.\{{snapshot\}}(?P=quote)(?=[ \t]*(?:#|$))''',
                                 f'version: "{a.spec_version}.{{snapshot}}"', "config version")
            elif rel_in == "spec_pipeline/pipeline.conf":
                text = _scope_conf(text, a)
            steps.append((f"{pack}/{rel_in}", "create", text))
    steps.append((f"{pack}/prog_spec/{os.path.basename(a.workbook)}", "copy", a.workbook))
    # the registry: lineage rows, current_spec_version untouched
    reg_path = os.path.join(root, "products", "registry.yaml")
    entry = dict(a._entry)
    lineage = [dict(x) for x in (entry.get("lineage") or []) if isinstance(x, dict)]
    if not any(str(x.get("spec_version")) == old_ver for x in lineage):
        row = {"spec_version": old_ver, "status": "active"}
        if entry.get("current_output_table") and str(entry.get("current_spec_version")) == old_ver:
            row["output_table"] = entry["current_output_table"]
        lineage.append(row)
    lineage.append({"spec_version": a.spec_version, "supersedes": old_ver, "status": "draft",
                    "label": (a.change_note or f"{a.change_class} revision, drafted from {old_ver}")[:120]})
    entry["lineage"] = lineage
    steps.append(("products/registry.yaml", "edit", _replace_entry(_read(reg_path), a.slug, entry)))
    # the CHANGELOG beside the version folders — the entry the versioning rule asks for, bound to the cut
    log_rel = f"products/{a.family}/{a.slug}/CHANGELOG.md"
    log_path = os.path.join(root, *log_rel.split("/"))
    log = _read(log_path) if os.path.exists(log_path) else (
        f"# Changelog — {a.slug}\n\nOne line per cut, classified (governance/VERSIONING.md): "
        f"`- <YYYY-MM-DD> <breaking|additive|none> <YYYYMM>: <what changed>, naming each changed file`.\n")
    line = (f"- {a.classified_date} {a.change_class} {a.spec_version}: next cut of {old_ver} from "
            f"{os.path.basename(a.workbook)}" + (f" — {a.change_note}" if a.change_note else "") +
            "; config/, variables/ and codelists/ carried by copy for revision; records carry through "
            "spec_diff.py; the registry lineage gains this cut as a draft")
    steps.append((log_rel, "edit" if os.path.exists(log_path) else "create", log.rstrip("\n") + "\n" + line + "\n"))
    return pack, steps


def disease_terms(a):
    """The prose phrases the registry gains for a new family: the person's `--disease-terms`, the
    display name, and the slug's words — lower-cased, de-duplicated, order kept."""
    raw = [x.strip() for x in str(a.disease_terms or "").split(",")] + \
          [str(a.name or "").strip(), str(a.slug or "").replace("_", " ")]
    out = []
    for x in raw:
        ph = spec_lint._phrase(x)
        if ph and ph not in out:
            out.append(ph)
    return out


def scaffold_metadata_changes(relative, document, *, slug, name):
    """Exact template identity holes only; never scientific values or lifecycle claims."""
    if not SLUG_RE.fullmatch(str(slug)) or not isinstance(name, str) or not name.strip() or any(ord(c) < 32 for c in name):
        raise ValueError("A declared product identifier and display name are required for scaffold metadata.")
    if not isinstance(document, dict):
        raise ValueError("Scaffold metadata requires a YAML mapping.")
    name = name.strip()
    changes = {}
    labels = {"demographics": "demographics parameters", "clinical": "clinical characteristics parameters",
              "treatment": "treatment parameters", "outcomes": "outcomes parameters"}
    if relative in {f"variables/{role}.yaml" for role in labels}:
        role = Path(relative).stem
        if document.get("pack_id") == f"REPLACE_ME_{role}":
            changes["pack_id"] = f"{slug}_{role}"
        if document.get("name") == f"REPLACE_ME — {labels[role]}":
            changes["name"] = f"{name} — {labels[role]}"
    elif relative == "config/data_product.yaml":
        if document.get("name") == "REPLACE_ME RWDP":
            changes["name"] = name + " RWDP"
        description = document.get("description")
        template_tail = "Config-driven port onto the shared engine (platform/engine). Fill in the tumor-specific pieces marked REPLACE_ME / TODO."
        expected = {f"Real-world data product for {value}. {template_tail}" for value in ("REPLACE_ME", name)}
        if isinstance(description, str) and " ".join(description.split()) in expected:
            changes["description"] = (f"Real-world data product for {name}. "
                "Scientific definitions and source bindings remain to be reviewed.")
    return changes


def scaffold_metadata_text(text, relative, *, slug, name):
    """Replace only known scalar metadata bytes, preserving every neighbouring field."""
    import yaml
    from engine.strict_yaml import strict_load
    if any(isinstance(token, (yaml.AliasToken, yaml.AnchorToken)) for token in yaml.scan(text)):
        raise ValueError("Scaffold metadata with YAML aliases requires manual review.")
    document = strict_load(text)
    changes = scaffold_metadata_changes(relative, document, slug=slug, name=name)
    if not changes:
        return text, changes
    tree = yaml.compose(text)
    replacements = []
    newline = "\r\n" if "\r\n" in text else "\n"
    for key, value in changes.items():
        node = next(child for field, child in tree.value if field.value == key)
        if not isinstance(node, yaml.ScalarNode):
            raise ValueError("Scaffold metadata must be scalar text.")
        encoded = json.dumps(value, ensure_ascii=False)
        if node.style in {"|", ">"} and text[node.start_mark.index:node.end_mark.index].endswith("\n"):
            encoded += newline
        replacements.append((node.start_mark.index, node.end_mark.index, encoded))
    result = text
    for start, end, value in sorted(replacements, reverse=True):
        result = result[:start] + value + result[end:]
    if strict_load(result) != {**document, **changes}:
        raise ValueError("Scaffold metadata would change another YAML field.")
    return result, changes


def _non_oncology_template(a, relative, text):
    """Neutral draft bytes, with no inferred disease rules or oncology variable packs."""
    import yaml
    roles = ("demographics", "clinical", "treatment", "outcomes")
    if relative == "config/data_product.yaml":
        document = {
            "schema_version": 1, "data_product_id": f"{a.slug}_rwdp", "name": f"{a.name.strip()} RWDP",
            "description": f"Standalone data product for {a.name.strip()}. Scientific definitions and source bindings remain to be supplied.",
            "owner": "DataExpert", "version": f"{a.spec_version}.{{snapshot}}", "status": "scaffold",
            "vendor": a.vendor, "tumor_class": "not_applicable", "condition_class": "non_oncology",
            "study": {"index_start": "REPLACE_ME", "index_end": "REPLACE_ME"},
            "index_dates": {}, "cohorts": [], "sources": {},
            "variables": [f"variables/{role}.yaml" for role in roles], "codelists": {}, "request_type": "new_product",
        }
        return "# No scientific defaults: author the product's own definitions before building.\n" + yaml.safe_dump(document, sort_keys=False, allow_unicode=True)
    if relative == "config/pipeline.yaml":
        return yaml.safe_dump({"run": {
            "refresh": "REPLACE_ME", "source_schema": "REPLACE_ME", "output_schema": "REPLACE_ME",
            "output_table": f"rwdp_{a.slug}_{a.spec_version}", "write_mode": "overwrite",
        }}, sort_keys=False)
    if relative == "config/semantic.yaml":
        return "# A person must define this product's concepts and rule on each binding.\nconcept_set: TODO\nvariables: {}\n"
    if relative.startswith("variables/"):
        return yaml.safe_dump({"pack_id": f"{a.slug}_{Path(relative).stem}", "version": "1.0"}, sort_keys=False)
    if relative.startswith("codelists/"):
        return None
    if relative == "spec_pipeline/pipeline.conf":
        return _scope_conf("# Condition identity and registered specification for the shared pipeline.\n"
                           f"TUMOR={a.slug}\nSPEC_SOURCE_ID=program_spec\n", a)
    if relative == "prog_spec/README.md":
        return ("# Product specification\n\nRegister this product's own specification through Source material. "
                "Its AI access classification and scientific approval are separate human decisions. "
                "Then extract it through the shared specification pipeline; generated rows do not approve the source or the science.\n")
    if relative == "handoff/FUNCTIONAL_CONTRACT.md":
        return _sub_once(text, r"^# Functional contract — <tumour> <YYYYMM>",
                         f"# Functional contract — {a.name.strip()} {a.spec_version}", "contract title")
    return text


def plan(a, root):
    """[(repo-relative path, action, text-or-None)] — every write, computed from the real files."""
    tpl = os.path.join(root, *TEMPLATE_REL.split("/"))
    if not os.path.isdir(tpl):
        tpl = str(package_asset(TEMPLATE_REL))
    pack = f"products/{a.family}/{a.slug}/{a.spec_version}"
    name = str(a.name).strip()
    steps = []
    for dirpath, _dirs, files in os.walk(tpl):
        for f in sorted(files):
            src = os.path.join(dirpath, f)
            rel_in = repo_relative(src, tpl)
            if rel_in == "NEW_TUMOUR.md" or "__pycache__" in rel_in:
                continue
            text = _read(src)
            if a.condition_class == "non_oncology":
                text = _non_oncology_template(a, rel_in, text)
                if text is None:
                    continue
            elif rel_in == "config/data_product.yaml":
                text = _sub_once(text, r"^data_product_id: REPLACE_ME_rwdp\b", f"data_product_id: {a.slug}_rwdp", "config identity")
                text = _sub_once(text, r'^name: "REPLACE_ME RWDP"',
                                 f'name: {json.dumps(name + " RWDP", ensure_ascii=False)}', "config name")
                text = _sub_once(text, r"Real-world data product for REPLACE_ME\.", f"Real-world data product for {name}.", "config description")
                text = _sub_once(text, r'^version: "YYYYMM\.\{snapshot\}"', f'version: "{a.spec_version}.{{snapshot}}"', "config version")
                text = _sub_once(text, r"^vendor: REPLACE_ME\b", f"vendor: {a.vendor}", "config vendor")
                text = _sub_once(text, r"^tumor_class: REPLACE_ME\b", f"tumor_class: {a.tumor_class}", "config tumor_class")
                if not re.search(r"^condition_class:\s*oncology\b", text, re.M):
                    raise SystemExit("REFUSED — the template config no longer declares `condition_class: oncology`; "
                                     "the stand-up writes only what the template states")
            elif rel_in == "spec_pipeline/pipeline.conf":
                text = _sub_once(text, r'^TUMOR="<slug>".*$', f"TUMOR={a.slug}", "pipeline.conf TUMOR")
                text = _scope_conf(text, a)
            elif rel_in == "config/pipeline.yaml" and a.modality == "ehr":
                text = _sub_once(text, r'rwdp_REPLACE_ME_pano_YYYYMM',
                                 f'rwdp_{a.slug}_pano_{a.spec_version}', "output table identity")
            elif rel_in == "handoff/FUNCTIONAL_CONTRACT.md":
                text = _sub_once(text, r"^# Functional contract — <tumour> <YYYYMM>",
                                 f"# Functional contract — {name} {a.spec_version}", "contract title")
            if rel_in == "config/data_product.yaml" or rel_in in {f"variables/{role}.yaml" for role in ("demographics", "clinical", "treatment", "outcomes")}:
                text, _metadata_changes = scaffold_metadata_text(text, rel_in, slug=a.slug, name=name)
            steps.append((f"{pack}/{rel_in}", "create", text))
    if a.workbook:
        steps.append((f"{pack}/prog_spec/{os.path.basename(a.workbook)}", "copy", a.workbook))

    # products/registry.yaml — the entry the tools resolve the pack through
    reg_path = os.path.join(root, "products", "registry.yaml")
    reg = _read(reg_path)
    fam = "" if a.family == "oncology" else f" family: {a.family},"
    # `tumour_key` names the TUMOUR (an alias's family; a new tumour's own slug) so that tumour-meaning
    # consumers — the inventory overlay, coverage, the portfolio grouping — resolve a second product
    # of the same tumour to the same shelf (twelfth verdict: the alias route never wrote it).
    entry = (f'  - {{ code: {a.code}, name: {json.dumps(name, ensure_ascii=False)}, slug: {a.slug},{fam} '
             f'tumour_key: {a.tumour_family or a.slug}, modality: {a.modality}, condition_class: {a.condition_class}, '
             f'vendor: {a.vendor}, tumor_class: {a.tumor_class}, status: scaffold, '
             f'current_spec_version: "{a.spec_version}" }}')
    if re.search(r"^tumors: \[\]\s*$", reg, re.M):
        reg = _sub_once(reg, r"^tumors: \[\]\s*$", "tumors:\n" + entry, "registry list")
    else:
        entry = " " * _registry_list_indent(reg) + entry.lstrip()
        reg = _insert_after_line(reg, r"^tumors:\s*$", entry, "registry list")
    steps.append(("products/registry.yaml", "edit", reg))

    # Only EHR products have a bundle job. A claims draft must not acquire an
    # activation block for an executor that does not materialise it.
    if a.modality == "ehr":
        act_path = os.path.join(root, "products", "activation.yaml")
        act = _read(act_path)
        block = (f"  {a.slug}: {{ schedule_enabled: false, run_as: REPLACE_ME, can_manage: [], can_view: [], "
                 f"cluster_policy_id: REPLACE_ME }}")
        if re.search(r"^products: \{\}\s*$", act, re.M):
            act = _sub_once(act, r"^products: \{\}\s*$", "products:\n" + block, "activation map")
        else:
            act = _insert_after_line(act, r"^products:\s*$", block, "activation map")
        steps.append(("products/activation.yaml", "edit", act))

    # governance/tumour_registry.yaml — a family, or an alias of one
    tr_path = os.path.join(root, "governance", "tumour_registry.yaml")
    tr = _read(tr_path)
    if a.tumour_family:
        existing_aliases = _families(root)[0]["aliases"]
        if a.slug not in existing_aliases:
            tr = _insert_after_line(tr, r"^aliases:\s*$", f"  {a.slug}: {a.tumour_family}", "tumour registry aliases")
    else:
        tr = _insert_after_line(tr, r"^families:\s*$", f"  {a.slug}: [{a.slug}]", "tumour registry families")
        terms = ", ".join(json.dumps(term, ensure_ascii=False) for term in disease_terms(a))
        tr = _insert_after_line(tr, r"^disease_terms:\s*$", f"  {a.slug}: [{terms}]", "tumour registry disease terms")
        if a.condition_class == "non_oncology":
            classification = f"  {a.slug}: non_oncology"
            if re.search(r"^condition_classes:\s*\{\}\s*$", tr, re.M):
                tr = _sub_once(tr, r"^condition_classes:\s*\{\}\s*$", "condition_classes:\n" + classification, "condition classes")
            elif re.search(r"^condition_classes:\s*$", tr, re.M):
                tr = _insert_after_line(tr, r"^condition_classes:\s*$", classification, "condition classes")
            else:
                tr = tr.rstrip("\n") + "\n\ncondition_classes:\n" + classification + "\n"
    steps.append(("governance/tumour_registry.yaml", "edit", tr))

    # the oncology catalogue row (claims nothing), its inventory overlay stub, its indication module
    broad = a.broad or BROAD_BY_CLASS[a.tumor_class]
    today = a.classified_date
    cat_path = os.path.join(root, "governance", "reference", "oncology_modules", "CATALOGUE.yaml")
    cat = _read(cat_path)
    # THE OVERLAY IS THE TUMOUR'S, NOT THE PRODUCT'S (twelfth verdict, "same tumour, new source"):
    # a second product of a tumour shares its family's shelf — `tumour_key` names the family, and
    # the inventory overlay and catalogue row point at that family's overlay, created as an empty
    # stub only when the family has none yet. Two products, one tumour, one set of definitions to
    # reuse; the product-specific part (config, sources, vendor) stays under the slug.
    overlay = a.tumour_family or a.slug
    generic = a.condition_class == "non_oncology"
    classification = "    condition_class: non_oncology\n" if generic else ""
    why = ("No clinical reference definitions are inherited; the inventory overlay is an empty stub until "
           "this condition's reference shelf is written." if generic else
           "The pan-oncology core applies and the inventory overlay is an empty stub until a reference shelf for this tumour is written.")
    row = (f"\n  {a.slug}:\n{classification}    broad: {broad}\n    narrow: {a.narrow}\n    maturity: registered\n"
           f"    inventory_overlay: {overlay}\n    reviewed_by: null\n    reviewed_on: null\n"
           f"    why: >-\n      Registered by new_product.py on {today}, which claims nothing.\n      {why}\n")
    cat = _insert_after_line(cat, r"^cancers:\s*$", row, "oncology catalogue")
    steps.append(("governance/reference/oncology_modules/CATALOGUE.yaml", "edit", cat))
    inv_path = os.path.join(root, "governance", "reference", "variable_inventory", "INVENTORY.yaml")
    inv = _read(inv_path)
    if not re.search(rf"^  {re.escape(overlay)}:\s*$", inv, re.M):
        stub = (f"  {overlay}:\n    tumour: {json.dumps((a.tumour_family or name).lower().replace('_', ' '), ensure_ascii=False)}\n"
                f"    stub: true   # registered by new_product.py; a reference shelf is written when one exists\n"
                f"    variables: []")
        inv = _insert_after_line(inv, r"^tumours:\s*$", stub, "inventory overlays")
        steps.append(("governance/reference/variable_inventory/INVENTORY.yaml", "edit", inv))
    module = (f"# indication:{a.slug} — GENERATED by platform/tools/registry_enrich.py from the inventory\n"
              f"# overlay; the stub new_product.py writes is regenerated in the same act.\n"
              f"module: indication:{a.slug}\nstatus: candidate\nreviewed_by: null\nreviewed_on: null\n\n"
              f"derived_from: governance/reference/variable_inventory/INVENTORY.yaml\n"
              f"derived_by: platform/tools/registry_enrich.py\nderived_digest: sha256:pending\n\nentries: []\n")
    steps.append((f"governance/reference/oncology_modules/indication/{a.slug}.yaml", "create", module))

    # products/metadata/catalog.yaml — the tumour-code mirror the catalogue tests hold both ways
    mc_path = os.path.join(root, "products", "metadata", "catalog.yaml")
    mc = _append_catalog_code(_read(mc_path), a.code)
    steps.append(("products/metadata/catalog.yaml", "edit", mc))
    return pack, steps


def copy_stage_tree(root, dst):
    """Copy current source and product bytes, excluding the checkout's private run state.

    Uncommitted implementation edits and registered product inputs must reach the
    validators. Caches, credentials and local transcripts from .gitignore must not.
    This also works in an unpacked source tree with no Git metadata.
    """
    private_names = {".git", ".history", ".venv", ".venv313", "venv", "__pycache__", "node_modules",
                     ".pytest_cache", ".hypothesis", ".mypy_cache", ".ruff_cache",
                     ".portal-drafts", ".portal-uploads", ".rwd-portal", ".ssh", ".aws", ".azure", ".gnupg",
                     "spark-warehouse", "metastore_db"}
    private_paths = {"build", "_rehearsal", "Data Dict", "platform/test-results",
                     "experiments/agent/runs", "experiments/agent/candidates", "experiments/agent/requests",
                     "experiments/vscode-model-bridge/dist", "experiments/portal/users.json",
                     "experiments/portal/snapshot.json", ".claude/settings.local.json", ".config/gcloud", "uat.json",
                     "experiments/agent/ml/embed_index.jsonl", "experiments/agent/ml/training_ledger.jsonl",
                     "experiments/agent/ml/calibration.json", "experiments/agent/ml/router.json",
                     "experiments/agent/ml/escalation.json", "experiments/agent/bench/results.jsonl",
                     "experiments/agent/bench/BENCHMARK.md"}
    profile_patterns = ("profile_*.tsv", "inventory.txt", "inventory_*.txt", "catalogue.txt", "catalogue_*.txt",
                        "profile_facts.md", "profile_facts_*.md", "data_characterization.*",
                        "data_characterization_*.*", "snapshot_comparison*.*", "*.parquet")
    def ignore(directory, names):
        relative = repo_relative(directory, root)
        relative = "" if relative == "." else relative + "/"
        expected = "expected_outputs" in relative.split("/")
        return {name for name in names
                if name in private_names or name.endswith(".egg-info") or relative + name in private_paths
                or name.lower() == ".env" or name.lower().endswith((".env", ".pyc", ".pyo", ".log", ".vsix", ".zip"))
                or (name.lower().startswith(".env.") and not name.lower().endswith(".example"))
                or name in {"vscode-model-bridge.json", "credentials.json", "credentials.yaml", "token.json"}
                or (name.startswith(".") and name.endswith(".portal-edit.lock"))
                or (relative == "experiments/agent/knowledge/corrections/" and name.endswith(".lock"))
                or ("/handoff/IMPLEMENTATION_REVIEWS/" in "/" + relative and name.startswith("runtime-") and name.endswith(".lock"))
                or (not expected and (name == "outputs" or any(fnmatch.fnmatchcase(name.lower(), pattern) for pattern in profile_patterns)))
                or (relative == ".claude/skills/" and name.endswith("-workspace"))}
    return shutil.copytree(root, dst, ignore=ignore, symlinks=True)


def stage(root, steps, a, pack):
    """A disposable copy of the checkout with the plan applied and Gate 1 registered in it."""
    tmp = Path(tempfile.mkdtemp(prefix="new_product_")).absolute()
    a._runtime_preparing = False
    try:
        if tmp.resolve() != tmp or tmp.is_symlink():
            raise ValueError("The temporary setup directory must not redirect elsewhere.")
        return _prepare_stage(root, steps, a, pack, str(tmp))
    except BaseException:
        # This directory came from this call's mkdtemp, never from a workbook,
        # failed command, or caller-supplied cleanup path. The caller cannot own
        # it until stage returns, so preparation failures must clean it here.
        a._stage_cleanup_complete = False
        try:
            if tmp.resolve() == tmp and not tmp.is_symlink():
                shutil.rmtree(tmp)
                a._stage_cleanup_complete = True
        except FileNotFoundError:
            a._stage_cleanup_complete = True
        except OSError:
            pass  # Retain the original failure; report that cleanup needs help.
        raise


def _prepare_stage(root, steps, a, pack, tmp):
    dst = os.path.join(tmp, "repo")
    copy_stage_tree(root, dst)
    a._package_inputs = {}
    for relative, source in package_file_map(root).items():
        if source.resolve() == (Path(root) / relative).resolve():
            continue
        target = Path(dst) / relative
        raw = source.read_bytes()
        if target.exists() and target.read_bytes() != raw:
            raise ValueError("A partial source file conflicts with the installed package: " + relative)
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(raw)
        a._package_inputs[relative] = (str(source), hashlib.sha256(raw).hexdigest())
    # The copied bytes are the inputs the validators will actually inspect.
    # Never infer our changes by comparing with a possibly changed live checkout.
    a._stage_baseline = _file_snapshot(dst)
    a._stage_sources = {path: digest for path, digest in a._package_inputs.values()}
    for _rel, action, payload in steps:
        if action == "copy":
            with open(payload, "rb") as handle:
                a._stage_sources[os.path.abspath(payload)] = hashlib.file_digest(handle, "sha256").hexdigest()
    a._runtime_preparing = True
    _progress("preparing the isolated setup runtime")
    runtime = prepare_snapshot_runtime(dst, os.path.join(tmp, "runtime"))
    a._runtime_preparing = False
    def run(argv, phase="validation"):
        a._failure_stage = phase
        return _run(dst, argv, runtime=runtime)

    # Inspect the copied workspace with the exact checker used after the plan.
    # Known pack-local defects remain visible; setup must not introduce any.
    _progress("recording existing maturity findings before setup")
    baseline = run([sys.executable, os.path.join(dst, "platform", "tools", "product_gates.py"),
                    "--maturity-report-json"])
    if baseline.returncode != 0:
        return dst, [("existing maturity inspection", baseline)]
    for rel, action, payload in steps:
        target = os.path.join(dst, *rel.split("/"))
        os.makedirs(os.path.dirname(target), exist_ok=True)
        if action == "copy":
            shutil.copyfile(payload, target)
            with open(target, "rb") as handle:
                copied_digest = hashlib.file_digest(handle, "sha256").hexdigest()
            if copied_digest != a._stage_sources[os.path.abspath(payload)]:
                a._failure_stage = "input_freshness"
                issue = finding("setup_inputs_changed",
                    "The selected workbook changed while the isolated setup checks were being prepared. "
                    "Preview the current workbook and try Create product again.")
                result = subprocess.CompletedProcess([], 1, str(issue), "")
                result.workflow_issues = [issue]
                return dst, [("selected workbook freshness", result)]
        else:
            with open(target, "w", encoding="utf-8", newline="\n") as fh:
                fh.write(payload)
    # Gate 1: the registration, composed by the repository's own initializer against the STAGED
    # registry (the person's three fields are passed through, never defaulted here)
    argv = [sys.executable, os.path.join(dst, "platform", "tools", "source_refs_init.py"), pack,
            "--ai-classification", a.ai_classification, "--classified-by", a.classified_by,
            "--classified-date", a.classified_date]
    r = run(argv, "registration")
    if r.returncode != 0:
        return dst, [("Gate 1 registration (source_refs_init.py)", r)]
    if a.workbook:
        # THE DIGEST IS MECHANICAL AND RECORDED HERE (twelfth verdict journey: the stand-up named the
        # workbook and the person's first Gate 1 check failed on the one field nobody should type).
        # It fills only an UNSTATED digest; the approval fields stay the person's.
        r = run([sys.executable, os.path.join(dst, "platform", "tools", "source_manifest.py"), pack,
                       "--record-digest", "program_spec"])
        if r.returncode != 0:
            return dst, [("Gate 1 digest of the registered workbook (source_manifest.py --record-digest)", r)]
    failures = []
    for label, cmd in VALIDATORS:
        _progress(label)
        r = run([sys.executable, os.path.join(dst, *cmd[0].split("/")), *cmd[1:]])
        if "--maturity-report-json" in cmd and r.returncode == 0:
            r = _setup_maturity_result(baseline, r, pack)
            for advisory in getattr(r, "workflow_advisories", ()):
                print("  existing product needs review: " + str(advisory), flush=True)
        if r.returncode != 0:
            failures.append((label, r))
            break
    if not failures:
        _progress(f"Gate 1 over {pack}")
        r = run([sys.executable, os.path.join(dst, "platform", "tools", "source_manifest.py"), pack, "--check"])
        if r.returncode != 0:
            failures.append(("Gate 1 over the new pack (source_manifest.py --check)", r))
    if not failures:
        _progress("the status page renders")
        r = run([sys.executable, os.path.join(dst, "platform", "tools", "status.py"), pack])
        if r.returncode != 0:
            failures.append(("status page of the new pack", r))
    if not failures and a.workbook:
        # the registered workbook goes through the pipeline HERE: a workbook that declares another
        # disease, or a tumour the registry cannot resolve, refuses the whole stand-up
        _progress("Gate 2 generation over the workbook")
        r = run([sys.executable, os.path.join(dst, "platform", "tools", "run_spec_pipeline.py"), pack], "extraction")
        if r.returncode != 0:
            failures.append(("Gate 2 generation over the registered workbook (run_spec_pipeline.py)", r))
        else:
            for cmd in (["platform/tools/current_state.py"], ["platform/tools/portfolio_status.py"]):
                run([sys.executable, os.path.join(dst, *cmd[0].split("/"))])
    if not failures and getattr(a, "next_cut_of", None) and getattr(a, "_old", None):
        # the two cuts compare, on the staged copy: the lineage is legal and the diff renders. Exit 2
        # (nothing compared — the previous cut has no extraction) is a fact the next steps state.
        _progress("the two cuts compare")
        r = run([sys.executable, os.path.join(dst, "platform", "tools", "spec_diff.py"), a._old, pack])
        if r.returncode not in (0, 2):
            failures.append(("the comparison of the two cuts (spec_diff.py)", r))
        a._nothing_compared = (r.returncode == 2)
    return dst, failures


def _progress(label):
    """One flushed line per validator as it starts, so a person watching the apply (a minute or
    more on a laptop) sees what is running rather than a silent prompt."""
    print(f"  running: {label}", flush=True)



def _run(cwd, argv, *, runtime=None):
    env = dict(runtime.environ if runtime else os.environ, PYTHONUTF8="1", PYTHONIOENCODING="utf-8", RWD_PORTAL_WORKSPACE_ROOT=str(cwd))
    command = python_module_command(argv, root=cwd)
    if runtime is not None:
        command[0] = str(runtime.python)
    options = dict(cwd=cwd, env=env, capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=900)
    name = Path(argv[1]).stem
    if name == "product_gates" and "--maturity-report-json" in argv:
        result = subprocess.run(command, **options)
        try:
            if result.returncode != 0:
                raise ValueError("Maturity inspection did not complete.")
            result.maturity_report = pg.parse_maturity_report(result.stdout)
            result.stdout = "Maturity findings inspected; this does not grant approval."
        except (ValueError, TypeError, KeyError):
            result.returncode = result.returncode or 1
            result.workflow_issues = [finding("setup_maturity_report_invalid",
                "The staged maturity inspection did not return a complete structured report. "
                "Ask the workspace owner to check the installed validation tools before retrying.")]
        return result
    if name == "registry_schema" and any(flag in argv for flag in ("--check-products", "--check-catalog")):
        result = subprocess.run([*command, "--json"], **options)
        try:
            payload = json.loads(result.stdout)
            if (not isinstance(payload, dict) or set(payload) != {"ok", "findings"}
                    or type(payload["ok"]) is not bool or not isinstance(payload["findings"], list)
                    or payload["ok"] != (not payload["findings"])
                    or result.returncode != (0 if payload["ok"] else 1)
                    or any(not isinstance(row, dict) or set(row) not in
                           ({"check", "message"}, {"check", "message", "details"}) for row in payload["findings"])):
                raise ValueError("Invalid registry check outcome.")
            result.workflow_issues = _registry_setup_issues(payload["findings"])
            result.stdout = "\n".join(f"{row['check']}: {row['message']}" for row in payload["findings"])
        except (ValueError, TypeError, KeyError):
            result.returncode = result.returncode or 1
            result.workflow_issues = [finding("setup_registry_result_invalid",
                "The staged registry check did not return a valid structured result. "
                "Ask the workspace owner to check the installed validation tools before retrying.")]
        return result
    if name in {"spec_extract", "run_spec_pipeline"}:
        result = run_workflow_command(command, issuer="rwd_tools." + name, runner=subprocess.run, **options)
        if not result.workflow_outcome_verified and result.returncode == 0:
            result.returncode = 1
        return result
    return subprocess.run(command, **options)


def _setup_maturity_result(baseline, current, pack):
    """Admit only an intact target without shared or newly introduced failures.

    An identical old pack finding is an advisory, never a passed maturity claim.
    Compare complete owned findings, including multiplicity, rather than counts.
    """
    issues, advisories = [], []
    try:
        before = pg.parse_maturity_report(baseline.maturity_report)
        after = pg.parse_maturity_report(current.maturity_report)
        if pack not in after["pack_findings"]:
            raise ValueError("The new product is absent from the maturity report.")
        missing = set(before["pack_findings"]) - set(after["pack_findings"])
        if missing:
            raise ValueError("Existing products disappeared from the maturity report: " + ", ".join(sorted(missing)))
    except (AttributeError, ValueError, TypeError, KeyError) as error:
        issues.append(finding("setup_maturity_report_invalid",
            "Setup could not compare complete maturity evidence: " + str(error) +
            " Ask the workspace owner to check the installed validation tools before retrying."))
    else:
        def wrap(row, code, direction):
            issue = WorkflowIssue.from_dict(row)
            details = dict(issue.details)
            owner = details.get("pack", "Workspace")
            message = issue.message if issue.message.startswith(owner + ":") else owner + ": " + issue.message
            if len(message) > 3600:
                message = message[:3600] + "… Inspect this product's full maturity findings for the remaining detail."
            return finding(code, message + " " + direction, gate=issue.gate,
                scope=details["scope"], pack=details.get("pack", ""),
                validator=details["validator"], source_code=issue.code)

        for row in after["workspace_findings"]:
            issues.append(wrap(row, "setup_shared_maturity_invalid",
                "The workspace owner must resolve this shared validation finding before setup can continue."))
        for owner, rows in after["pack_findings"].items():
            known = Counter(json.dumps(row, sort_keys=True) for row in before["pack_findings"].get(owner, []))
            for row in rows:
                key = json.dumps(row, sort_keys=True)
                if owner == pack:
                    issues.append(wrap(row, "setup_target_maturity_invalid",
                        "Review the new product's declared maturity, evidence and bindings before retrying setup."))
                elif known[key]:
                    known[key] -= 1
                    advisories.append(wrap(row, "setup_existing_maturity_advisory",
                        "This pre-existing finding remains unresolved; the product's approval and release eligibility are unchanged."))
                else:
                    issues.append(wrap(row, "setup_existing_maturity_regression",
                        "Setup introduced or changed this finding in an existing product; review the proposed shared changes before retrying."))
    current.workflow_issues = issues
    current.workflow_advisories = advisories
    current.returncode = int(bool(issues))
    current.stdout = "\n".join(map(str, issues)) or (
        "New product maturity and shared claims checked; no new findings in existing products. "
        f"{len(advisories)} pre-existing finding(s) remain unresolved.")
    return current


def _file_snapshot(root):
    """Hashes of source files copied to a stage, excluding Python/Git runtime state."""
    snapshot = {}
    for dirpath, dirs, files in os.walk(root):
        dirs[:] = [d for d in dirs if d not in ("__pycache__", ".git") and not d.endswith(".egg-info")]
        for name in files:
            if name.endswith(".pyc"):
                continue
            full = os.path.join(dirpath, name)
            with open(full, "rb") as handle:
                snapshot[repo_relative(full, root)] = hashlib.file_digest(handle, "sha256").hexdigest()
    return snapshot


def changed_files(root, staged, baseline=None):
    """Every file the staged copy holds that the checkout does not, or holds differently."""
    if baseline is not None:
        return sorted(rel for rel, digest in _file_snapshot(staged).items() if baseline.get(rel) != digest)
    out = []
    for dirpath, dirs, files in os.walk(staged):
        dirs[:] = [d for d in dirs if d not in ("__pycache__", ".git") and not d.endswith(".egg-info")]
        for f in files:
            if f.endswith((".pyc",)):
                continue
            full = os.path.join(dirpath, f)
            rel = repo_relative(full, staged)
            mine = os.path.join(root, *rel.split("/"))
            if not os.path.exists(mine) or not filecmp.cmp(full, mine, shallow=False):
                out.append(rel)
    return sorted(out)


def _changed_inputs(root, baseline, installing, sources=None):
    """Name changed inputs so a safe refusal points to the files needing review."""
    expected = {os.path.join(root, *rel.split("/")): baseline.get(rel) for rel in set(baseline) | set(installing)}
    expected.update(sources or {})
    selected = {os.path.normcase(os.path.abspath(path)) for path in (sources or {})}
    changes = []
    for path, digest in sorted(expected.items()):
        try:
            with open(path, "rb") as handle:
                actual = hashlib.file_digest(handle, "sha256").hexdigest()
        except FileNotFoundError:
            actual = None
        if actual != digest:
            change = "removed" if actual is None else "created" if digest is None else "changed"
            if os.path.normcase(os.path.abspath(path)) in selected:
                label, name = "selected workbook", os.path.basename(path)
            else:
                label, name = "checkout input", repo_relative(path, root)
            changes.append(f"{label} {change}: {json.dumps(name, ensure_ascii=False)}")
    return changes


def _unchanged_inputs(root, baseline, installing, sources=None):
    """An external editor must not be overwritten or invalidate a staged check."""
    return not _changed_inputs(root, baseline, installing, sources)


def _standup_locks():
    portal = os.path.join(REPO, "experiments", "portal")
    from experiments.portal import local_process_lock
    return local_process_lock


def _standup_directory(root):
    """Compute and validate the lock location without creating or editing it."""
    checkout = Path(root).resolve(strict=True)
    base = Path(os.environ.get("LOCALAPPDATA") or Path.home() / ".local/state")
    scope = hashlib.sha256(os.path.normcase(str(checkout)).encode()).hexdigest()[:16]
    directory = base / "RwdPortal" / "stand-ups" / scope
    if (not base.is_absolute() or directory.absolute() != directory.resolve()
            or directory.resolve().is_relative_to(checkout)):
        raise ValueError("The local stand-up lock folder is not a canonical location outside the checkout.")
    return directory


def _standup_guard(root):
    """One local-account operation per checkout, using the existing OS lock."""
    directory = _standup_directory(root)
    directory.mkdir(parents=True, exist_ok=True)
    return _standup_locks().locked(directory / "stand-up.lock", directory)


_STANDUP_LOCK_MESSAGES = {
    "busy": "Another product setup currently holds this checkout's lock. Check its progress before trying again.",
    "owner_unverifiable": "The previous setup lock owner cannot be verified. Preserve the lock and ask the workspace owner to inspect it; waiting alone may not resolve this.",
    "identity_unverifiable": "The current setup process identity could not be verified. Ask the workspace owner to inspect local process access before retrying.",
    "storage_unavailable": "The setup lock storage could not be accessed. Check local application-storage permissions before retrying.",
    "location_unverifiable": "The setup lock location could not be verified. Check this checkout and its local application-storage configuration before retrying.",
    "os_lock_unavailable": "The operating system could not acquire the setup lock safely. Ask the workspace owner to inspect local file-lock support before retrying.",
}


def _standup_lock_code(error):
    code = getattr(error, "code", None)
    return code if code in _STANDUP_LOCK_MESSAGES else "storage_unavailable" if isinstance(error, OSError) else "location_unverifiable"


def standup_status(root):
    """Inspect the current lock without making its directory or rewriting ownership."""
    try:
        directory = _standup_directory(root)
    except (OSError, ValueError):
        return {"state": "uncertain", "code": "location_unverifiable", "recovery_allowed": False,
                "reason": _STANDUP_LOCK_MESSAGES["location_unverifiable"]}
    try:
        directory.stat()
        state = _standup_locks().lock_status(directory / "stand-up.lock", directory)
    except FileNotFoundError:
        state = {"state": "absent", "recovery_allowed": False}
    except (OSError, ValueError):
        return {"state": "uncertain", "code": "storage_unavailable", "recovery_allowed": False,
                "reason": _STANDUP_LOCK_MESSAGES["storage_unavailable"]}
    kind = state.get("state", "uncertain")
    try:
        pending = _install_path(Path(root).resolve(strict=True), INSTALL_JOURNAL).exists()
    except (OSError, ValueError):
        pending = False
    if pending and kind in {"absent", "dead"}:
        return {"state": kind, "code": "interrupted_install", "installation_pending": True,
                "recovery_allowed": True,
                "reason": "An interrupted installation needs recovery before preview. Choose Recover interrupted installation, then preview again. "
                          "The command-line equivalent is new_product.py --recover-install --root <checkout>."}
    if kind == "absent":
        return {"state": kind, "code": "clear", "recovery_allowed": False,
                "reason": "No product setup currently holds this checkout's lock. Preview the current form again before writing."}
    if kind == "dead":
        return {"state": kind, "code": "ended_owner", "recovery_allowed": True,
                "reason": "The previous setup process has ended. A new explicit write can recover its lock; preview the current form first."}
    code = "busy" if kind == "active" else state.get("code", "owner_unverifiable")
    if code not in _STANDUP_LOCK_MESSAGES:
        code = "owner_unverifiable"
    return {"state": "active" if kind == "active" else "uncertain", "code": code,
            "recovery_allowed": False, "reason": _STANDUP_LOCK_MESSAGES[code]}


INSTALL_JOURNAL = ".rwd-portal/stand-up-install.json"


def _install_path(root, rel):
    from pathlib import PurePosixPath
    value = PurePosixPath(rel)
    if (not isinstance(rel, str) or not rel or str(value) != rel or value.is_absolute()
            or ".." in value.parts or "\\" in rel or ":" in rel):
        raise ValueError("The installation journal contains an unsafe relative path.")
    target = Path(root) / rel
    if target.resolve() != target.absolute() or target.is_symlink():
        raise ValueError("Installation paths must be canonical files inside the checkout.")
    return target


def _install_sync(directory):
    if os.name != "nt":
        handle = os.open(directory, os.O_RDONLY)
        try:
            os.fsync(handle)
        finally:
            os.close(handle)


def _install_atomic(path, data, replace=os.replace):
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(path.name + TMP_SUFFIX)
    with temporary.open("wb") as handle:
        handle.write(data)
        handle.flush()
        os.fsync(handle.fileno())
    replace(str(temporary), str(path))
    _install_sync(path.parent)


def _install_hash(path):
    try:
        return hashlib.sha256(path.read_bytes()).hexdigest()
    except FileNotFoundError:
        return None


def _install_journal(root, payload):
    _install_atomic(_install_path(root, INSTALL_JOURNAL),
                    json.dumps(payload, sort_keys=True, separators=(",", ":")).encode("utf-8"))


def _install_cleanup(root, payload):
    for entry in payload["files"]:
        target = _install_path(root, entry["path"])
        target.with_name(target.name + TMP_SUFFIX).unlink(missing_ok=True)
    for rel in sorted(payload["created_dirs"], key=len, reverse=True):
        try:
            _install_path(root, rel).rmdir()
        except OSError:
            pass  # Only directories still empty belong to this interrupted operation.
    journal = _install_path(root, INSTALL_JOURNAL)
    journal.unlink(missing_ok=True)
    _install_sync(journal.parent)
    try:
        journal.parent.rmdir()
    except OSError:
        pass


def recover_install(root, *, _guarded=False, _boundary=None):
    """Restore a prepared transaction, or retain a durably committed revision.

    Recovery never overwrites bytes differing from both journal revisions. The
    journal remains available for inspection when external changes conflict.
    """
    import base64
    if not _guarded:
        with _standup_guard(root):
            return recover_install(root, _guarded=True, _boundary=_boundary)
    root = Path(root).resolve(strict=True)
    journal = _install_path(root, INSTALL_JOURNAL)
    if not journal.exists():
        return "absent"
    if journal.stat().st_size > 512 * 1024 * 1024:
        raise ValueError("The installation recovery journal exceeds its supported size; preserve it for inspection.")
    try:
        payload = json.loads(journal.read_bytes())
        if (payload["version"] != 1 or payload["state"] not in {"prepared", "committed"}
                or payload["root"] != str(root) or not isinstance(payload["files"], list)
                or not isinstance(payload["created_dirs"], list)):
            raise ValueError("Invalid installation journal shape.")
        seen = set()
        for entry in payload["files"]:
            target = _install_path(root, entry["path"])
            if entry["path"] == INSTALL_JOURNAL or entry["path"] in seen:
                raise ValueError("Duplicate installation path.")
            seen.add(entry["path"])
            old = None if entry["before"] is None else base64.b64decode(entry["before"], validate=True)
            if (None if old is None else hashlib.sha256(old).hexdigest()) != entry["old_hash"]:
                raise ValueError("Invalid installation backup hash.")
            if not re.fullmatch(r"[a-f0-9]{64}", entry["new_hash"]):
                raise ValueError("Invalid installation target hash.")
            actual = _install_hash(target)
            allowed = {entry["new_hash"]} if payload["state"] == "committed" else {entry["old_hash"], entry["new_hash"]}
            if actual not in allowed:
                raise ValueError("Installation recovery conflicts with an external edit to " + entry["path"]
                                 + ". Preserve the recovery journal and reconcile that file before retrying recovery.")
        for rel in payload["created_dirs"]:
            _install_path(root, rel)
    except (KeyError, TypeError, UnicodeError) as error:
        raise ValueError("The installation recovery journal is invalid; preserve it for inspection.") from error
    if payload["state"] == "prepared":
        for entry in reversed(payload["files"]):
            target = _install_path(root, entry["path"])
            if entry["before"] is None:
                target.unlink(missing_ok=True)
                if target.parent.exists():
                    _install_sync(target.parent)
            else:
                _install_atomic(target, base64.b64decode(entry["before"], validate=True))
            if _boundary:
                _boundary("restored:" + entry["path"])
    outcome = "rolled_back" if payload["state"] == "prepared" else "committed"
    _install_cleanup(root, payload)
    return outcome


def install(root, staged, rels, _replace=os.replace, *, _guarded=False, _boundary=None, expected_before=None, _write_evidence=None):
    """Publish validated files with a durable undo journal and interruption recovery.

    Readers must not treat an active transaction as a completed setup. A killed
    installer is repaired under the same stand-up lock before the next apply.
    Ordinary failures still roll back immediately. No approval is manufactured.
    """
    import base64
    if not _guarded:
        with _standup_guard(root):
            return install(root, staged, rels, _replace, _guarded=True, _boundary=_boundary, expected_before=expected_before, _write_evidence=_write_evidence)
    root, staged = Path(root).resolve(strict=True), Path(staged).resolve(strict=True)
    recover_install(root, _guarded=True)
    files, created_dirs = [], set()
    if len(rels) != len(set(rels)):
        raise ValueError("An installation cannot contain duplicate paths.")
    if expected_before is not None and (not isinstance(expected_before, dict) or set(expected_before) != set(rels)):
        raise ValueError("Every reviewed installation target requires its expected prior digest.")
    for rel in rels:
        if rel == INSTALL_JOURNAL or rel.startswith(".rwd-portal/"):
            raise ValueError("Runtime recovery storage cannot be a product installation target.")
        target, source = _install_path(root, rel), _install_path(staged, rel)
        if target.with_name(target.name + TMP_SUFFIX).exists():
            raise ValueError("An installation temporary file already exists for " + rel + ". Inspect it before retrying.")
        before = target.read_bytes() if target.exists() else None
        if expected_before is not None and expected_before[rel] != (None if before is None else hashlib.sha256(before).hexdigest()):
            raise ValueError("The reviewed installation target changed: " + rel)
        new_hash = hashlib.sha256(source.read_bytes()).hexdigest()
        files.append({"path": rel, "before": None if before is None else base64.b64encode(before).decode("ascii"),
                      "old_hash": None if before is None else hashlib.sha256(before).hexdigest(), "new_hash": new_hash})
        parent = target.parent
        while not parent.exists():
            created_dirs.add(parent.relative_to(root).as_posix())
            parent = parent.parent
    payload = {"version": 1, "root": str(root), "state": "prepared", "files": files,
               "created_dirs": sorted(created_dirs)}
    if len(json.dumps(payload).encode("utf-8")) > 512 * 1024 * 1024:
        raise ValueError("The installation exceeds the supported recovery journal size.")
    _install_journal(root, payload)
    if _write_evidence is not None:
        _write_evidence["write_disposition"] = "unknown"
    try:
        if _boundary:
            _boundary("prepared")
        for entry in files:
            rel = entry["path"]
            target, source = _install_path(root, rel), _install_path(staged, rel)
            data = source.read_bytes()
            if hashlib.sha256(data).hexdigest() != entry["new_hash"] or _install_hash(target) != entry["old_hash"]:
                raise ValueError("Installation inputs changed after preparation: " + rel)
            _install_atomic(target, data, _replace)
            if _boundary:
                _boundary("replaced:" + rel)
        payload["state"] = "committed"
        _install_journal(root, payload)
        if _boundary:
            _boundary("committed")
    except BaseException:
        recovered = recover_install(root, _guarded=True)
        if _write_evidence is not None and recovered == "rolled_back":
            _write_evidence["write_disposition"] = "rolled_back"
        raise
    _install_cleanup(root, payload)
    return list(rels)


def remaining(a, pack):
    """What is a PERSON's to do next — printed after both the preview and the apply."""
    L = [f"1. Commit. The commit that lands {pack}/source_refs.yaml carries `classified_by: {a.classified_by}` "
         f"and must be signed with that person's review key (governance/allowed_signers.yaml), or "
         f"`approval_identity.py --check` stays red — a tool cannot sign for a person."]
    if a.modality == "claims":
        return L + [
            f"2. In Progress and next step, use Attach specification to register a claims-layout workbook for {pack}, then complete its source and scientific review.",
            f"3. Open Configure claims criteria in Progress and next step. Bind the workbook's code-list tabs to named events and its criteria to those events, validate the exact draft, then save {pack}/config/cohortly_bindings.yaml.",
            "Shared template files are draft scaffolding only. They are not a claims executor; a configuration syntax check does not validate claims execution.",
            "Source readiness remains separate: a vendor with pending schema-evidence review needs the source owner to review delivery terms and record the supported evidence route. Draft registration grants no documentation access, AI eligibility or profiling permission.",
            "4. Use the same claims workspace to review the generated R, integrity-sealed manifest and every remaining gap. Request Engineering runtime review with the exact input hashes and required evidence.",
            "5. No EHR activation block or production claims job was created. The existing cohortly loader permits explicitly authorized draft UAT only; governed claims execution, receipt attestation and release remain unavailable."]
    if getattr(a, "next_cut_of", None):
        old = a._old
        L += [f"2. Register the revised workbook as REVIEWED in {pack}/source_refs.yaml (revision, approval date, "
              f"approver; the sha256 is recorded) — the extraction already ran on the staged copy.",
              f"3. Register and review the sanitized extraction BEFORE any carry or drafting: "
              f"`source_manifest.py --register-ai-extraction {pack} --write`, then a person sets its "
              f"status: reviewed with their name and date (a carry into an unreviewed extraction is refused).",
              (f"4. Carry what provably survived: `spec_diff.py {old} {pack} --carry-plan <a directory outside "
               f"both packs>`, then run the commands in carry_commands.txt; every RE-DRAFT record is yours "
               f"to draft again against the new text."
               if not getattr(a, "_nothing_compared", False) else
               f"4. {old} carries no extraction, so nothing compared: every record of this cut is drafted "
               f"fresh (`run_spec_pipeline.py {old}` on the old cut first if its workbook is registered)."),
              f"5. Revise the carried config/, variables/ and codelists/ against the new specification; "
              f"`platform/engine/validate.py {pack} --strict` and `contract_binding.py {pack} --check` say what no record claims.",
              f"6. The registry keeps current_spec_version at {a._old_version}: this cut is a DRAFT beside the released "
              f"one (lineage status: draft). When it is approved and released, move current_spec_version and "
              f"current_output_table to {a.spec_version}, set its lineage row active and {a._old_version}'s superseded — "
              f"one deliberate change, never at the start."]
        return L
    if not a.workbook:
        L.append(f"2. Register the approved workbook: put it in {pack}/prog_spec/, set path_or_link on the "
                 f"program_spec material in source_refs.yaml (this registration is a person's record now — "
                 f"source_refs_init.py will not regenerate it), record its digest with "
                 f"`source_manifest.py {pack} --record-digest program_spec`, then `run_spec_pipeline.py {pack}`.")
    else:
        L.append(f"2. Read {pack}/spec_pipeline/out/SPEC_FINDINGS.txt and COVERAGE.md — the extraction is "
                 f"generated; the dispositions are yours. The workbook is registered with its sha256; "
                 f"its revision, approval date and approver, and `status: reviewed`, are a person's to "
                 f"write in {pack}/source_refs.yaml.")
    L += [f"3. Register and review the sanitized extraction before any drafting: "
          f"`source_manifest.py --register-ai-extraction {pack} --write`, then a person sets its "
          f"status: reviewed with their name and date.",
          f"4. Draft the contract through `contract_record.py` (`worksheet.py {pack}` says where you stand); "
          f"every scientific value in config/ is still REPLACE_ME on purpose.",
          f"5. When operations takes the product on: fill run_as / can_manage / can_view / "
          f"cluster_policy_id in products/activation.yaml (schedule_enabled stays false until Gate 6)."]
    return L


from dataclasses import asdict, dataclass, field


_REQUEST_INPUTS = (
    "governance/spec_sheet_map.yaml", "governance/tumour_registry.yaml", "governance/vendor_policy.yaml",
    "products/registry.yaml", "fixtures/registry.yaml", "platform/TUMOR_TEMPLATE/spec_pipeline/config.yaml",
    "governance/reference/oncology_modules/CATALOGUE.yaml", "governance/reference/variable_inventory/INVENTORY.yaml",
)
_FAILURE_STAGES = {"arguments", "setup_access", "recovery", "preflight", "planning", "registration", "validation", "extraction", "input_freshness", "installation", "internal"}


def request_inputs(argv):
    """Byte-based repair freshness over selected workbook and declared shared inputs.

    This is a bounded repair-context check, not the installer's full source manifest.
    Root and workbook paths are request arguments, never recovered from console text.
    """
    def option(name, default):
        if any(isinstance(value, str) and value.startswith(name + "=") for value in argv):
            raise ValueError("Use separate option and value arguments for setup binding: " + name)
        indexes = [i for i, value in enumerate(argv) if value == name]
        if len(indexes) > 1 or indexes and indexes[0] + 1 >= len(argv):
            raise ValueError("Repeated or incomplete setup binding option.")
        return argv[indexes[0] + 1] if indexes else default
    root = Path(option("--root", REPO)).resolve()
    paths = [(name, root / name) for name in _REQUEST_INPUTS]
    workbook = option("--workbook", None)
    if workbook:
        paths.append(("selected_workbook", Path(workbook).resolve()))
    paths.append(("installed_setup_code", Path(__file__).resolve()))
    result = {"workspace": str(root)}
    for label, path in paths:
        if label in _REQUEST_INPUTS and not path.exists():
            try:
                path = package_asset(label)
            except (FileNotFoundError, ValueError):
                pass
        if not path.exists():
            result[label] = None
            continue
        if path.is_symlink() or not path.is_file() or path.stat().st_size > 100 * 1024 * 1024:
            raise ValueError("The setup input cannot be bound for repair: " + label)
        with path.open("rb") as handle:
            result[label] = hashlib.file_digest(handle, "sha256").hexdigest()
    return hashlib.sha256(json.dumps(result, sort_keys=True, separators=(",", ":")).encode()).hexdigest()


def request_binding(argv, nonce):
    if (not isinstance(nonce, str) or not re.fullmatch(r"[a-f0-9]{32}", nonce)
            or not isinstance(argv, (list, tuple)) or any(not isinstance(value, str) for value in argv)):
        raise ValueError("Invalid setup invocation binding.")
    inputs = request_inputs(argv)
    return {"nonce": nonce, "request_sha256": hashlib.sha256(json.dumps(list(argv), separators=(",", ":")).encode()).hexdigest(), "inputs_sha256": inputs}


def _failure_record(stage, issues=(), *, write_disposition="not_started", prior_recovery="not_run"):
    rows = [issue_of(value).to_dict() for value in issues][:20]
    if not rows:
        rows = [finding("setup_operation_failed", "The setup did not complete. Inspect its recorded details before retrying.").issue.to_dict()]
    return {"stage": stage, "issues": rows, "write_disposition": write_disposition, "prior_recovery": prior_recovery}


def _set_failure(a, stage, issues=(), *, write_disposition="not_started"):
    report = getattr(a, "_outcome", {})
    report["failure"] = _failure_record(stage, issues, write_disposition=write_disposition,
        prior_recovery=getattr(a, "_prior_recovery", "not_run"))
    return report["failure"]


def _check_failure(value):
    if (not isinstance(value, dict) or set(value) != {"stage", "issues", "write_disposition", "prior_recovery"}
            or not isinstance(value["stage"], str) or value["stage"] not in _FAILURE_STAGES
            or not isinstance(value["write_disposition"], str) or value["write_disposition"] not in {"not_started", "rolled_back", "unknown"}
            or not isinstance(value["prior_recovery"], str) or value["prior_recovery"] not in {"not_run", "absent", "rolled_back", "committed", "unknown"}
            or not isinstance(value["issues"], list) or not 1 <= len(value["issues"]) <= 20):
        raise ValueError("Invalid setup recovery evidence.")
    for item in value["issues"]:
        issue = WorkflowIssue.from_dict(item)
        if not issue.message.strip() or len(issue.message) > 4000:
            raise ValueError("Invalid setup recovery finding.")
    if value["write_disposition"] == "rolled_back" and value["stage"] != "installation":
        raise ValueError("Rollback evidence belongs to the installation boundary.")


@dataclass(frozen=True)
class NewProductOutcome:
    """Operation-owned facts; log wording never determines writes or repairs."""
    version: int = 1
    state: str = "refused"
    returncode: int = 1
    pack: str | None = None
    written_paths: list[str] = field(default_factory=list)
    delta: dict | None = None
    stdout: str = ""
    stderr: str = ""
    binding: dict | None = None
    failure: dict | None = None

    def as_dict(self):
        value = asdict(self)
        if self.version == 1:
            value.pop("binding")
            value.pop("failure")
        return value



def run_request(argv):
    """Invoke the operation with a fresh request-bound result; retain human logs."""
    import contextlib
    import io
    import uuid
    argv = list(argv)
    nonce = uuid.uuid4().hex
    if "--request-nonce" in argv:
        index = argv.index("--request-nonce")
        if argv.count("--request-nonce") != 1 or index + 1 >= len(argv):
            raise ValueError("Invalid setup invocation nonce.")
        nonce = argv[index + 1]
        del argv[index:index + 2]
    binding = request_binding(argv, nonce)
    report = {"version": 2, "binding": binding, "failure": _failure_record("arguments")}
    output, errors = io.StringIO(), io.StringIO()
    with contextlib.redirect_stdout(output), contextlib.redirect_stderr(errors):
        try:
            code = main(argv, _report=report)
        except SystemExit as error:
            code = error.code if type(error.code) is int else 1
            if error.code is not None and not isinstance(error.code, int):
                print(str(error.code), file=sys.stderr)
    if code == 0:
        report["failure"] = None
    return NewProductOutcome(returncode=code, stdout=output.getvalue(), stderr=errors.getvalue(), **report)


def parse_outcome(value, returncode, *, expected_binding=None, request_argv=None):
    """Refuse incomplete or mismatched worker outcomes before a caller acts on them."""
    from pathlib import PurePosixPath
    if type(returncode) is not int:
        raise ValueError("Invalid setup process return code.")
    def unique(pairs):
        result = {}
        for key, item in pairs:
            if key in result:
                raise ValueError("Repeated setup outcome field.")
            result[key] = item
        return result
    document = json.loads(value, object_pairs_hook=unique) if isinstance(value, str) else value
    fields = {"version", "state", "returncode", "pack", "written_paths", "delta", "stdout", "stderr"}
    if isinstance(document, dict) and document.get("version") == 2:
        fields |= {"binding", "failure"}
    if not isinstance(document, dict) or set(document) != fields:
        raise ValueError("The product worker did not retain a complete structured outcome.")
    if (type(document["version"]) is not int or document["version"] not in {1, 2}
            or type(document["returncode"]) is not int or document["returncode"] != returncode
            or not isinstance(document["state"], str) or document["state"] not in {"refused", "preview", "written", "recovered"}
            or not isinstance(document["stdout"], str) or not isinstance(document["stderr"], str)
            or document["delta"] is not None and not isinstance(document["delta"], dict)):
        raise ValueError("The product worker outcome does not match its completed operation.")
    if document["version"] == 2:
        binding = document["binding"]
        if (not isinstance(binding, dict) or set(binding) != {"nonce", "request_sha256", "inputs_sha256"}
                or any(not isinstance(binding[key], str) or not re.fullmatch(r"[a-f0-9]{" + str(size) + "}", binding[key])
                       for key, size in (("nonce", 32), ("request_sha256", 64), ("inputs_sha256", 64)))):
            raise ValueError("Invalid setup invocation binding.")
        if returncode:
            _check_failure(document["failure"])
        elif document["failure"] is not None:
            raise ValueError("A completed setup cannot carry failed-operation evidence.")
    if expected_binding is not None and (document["version"] != 2 or document["binding"] != expected_binding):
        raise ValueError("The setup result belongs to different inputs or another invocation.")
    if request_argv is not None:
        if (not isinstance(request_argv, (list, tuple)) or any(not isinstance(value, str) for value in request_argv)
                or document["version"] != 2 or document["binding"]["request_sha256"] != hashlib.sha256(json.dumps(list(request_argv), separators=(",", ":")).encode()).hexdigest()):
            raise ValueError("The setup result belongs to another request scope.")
    pack = document["pack"]
    if pack is not None and (not isinstance(pack, str) or not re.fullmatch(r"products/[A-Za-z0-9_-]+/[A-Za-z0-9_-]+/[0-9]{6}", pack)):
        raise ValueError("The product worker returned an invalid product path.")
    paths = document["written_paths"]
    if (not isinstance(paths, list) or len(paths) > 10000 or any(not isinstance(path, str) for path in paths)
            or len(paths) != len(set(paths))):
        raise ValueError("The product worker returned an invalid written-file inventory.")
    for path in paths:
        parsed = PurePosixPath(path)
        if parsed.is_absolute() or ":" in path or "\\" in path or any(part in {"", ".", ".."} for part in path.split("/")):
            raise ValueError("The product worker returned a path outside its authoring workspace.")
    if document["state"] == "written":
        if not pack or pack + "/source_refs.yaml" not in paths:
            raise ValueError("The completed product has no declared registration in its written-file inventory.")
    elif paths:
        raise ValueError("A preview or refused request cannot claim written files.")
    if returncode != 0 and document["state"] != "refused":
        raise ValueError("An unsuccessful request cannot claim a completed operation.")
    if document["delta"] is not None:
        try:
            delta_summary(document["delta"])
        except (KeyError, TypeError, ValueError) as error:
            raise ValueError("The product worker comparison is incomplete.") from error
    if returncode == 0 and document["state"] == "refused":
        raise ValueError("A refused request cannot be reported as a successful setup.")
    if document["state"] == "preview" and not pack:
        raise ValueError("A successful preview must identify its product.")
    return NewProductOutcome(**document)


def main(argv, *, _report=None):
    if "--json" in argv:
        outcome = run_request([value for value in argv if value != "--json"])
        print(json.dumps(outcome.as_dict(), ensure_ascii=False, allow_nan=False))
        return outcome.returncode
    report = _report if _report is not None else {}
    if "--recover-install" in argv:
        recovery = argparse.ArgumentParser(description="Recover an interrupted product installation.", allow_abbrev=False)
        recovery.add_argument("--recover-install", action="store_true", required=True)
        recovery.add_argument("--root", default=REPO)
        options = recovery.parse_args(argv)
        report["failure"] = _failure_record("recovery", write_disposition="unknown", prior_recovery="unknown")
        try:
            result = recover_install(options.root)
        except (OSError, ValueError) as error:
            print(f"RECOVERY REFUSED: {error}", file=sys.stderr)
            return 1
        report["state"] = "recovered"
        print("Installation recovery: " + result + ". Preview the product setup again before applying.")
        return 0
    ap = argparse.ArgumentParser(description=__doc__.splitlines()[0], allow_abbrev=False)   # --disease-term is not --disease-terms
    ap.add_argument("slug", help="the product identity: folder, job name, bundle prefix ([a-z][a-z0-9_]*)")
    ap.add_argument("--next-cut-of", metavar="OLD_PACK", default=None,
                    help="the PREVIOUS cut of a registered product (products/<family>/<slug>/<YYYYMM>): stand "
                         "its next cut up beside it — the executable surface carried by copy, the revised "
                         "workbook registered fresh, the registry lineage gaining a draft row, the CHANGELOG "
                         "its classified entry; records carry through spec_diff.py afterwards. The product's "
                         "identity flags are derived from the registry and refused if they differ")
    ap.add_argument("--change-class", choices=["breaking", "additive"], default=None,
                    help="with --next-cut-of: what the revision does to existing values (governance/VERSIONING.md)")
    ap.add_argument("--change-note", default="", help="with --next-cut-of: one line for the CHANGELOG entry")
    ap.add_argument("--code", default=None, help="the short registry code (matches the master-spec sheet name); "
                                                 "required for a new product")
    ap.add_argument("--name", default=None, help='the display name, e.g. "Bladder"; required for a new product')
    ap.add_argument("--vendor", default=None, help="a vendor in governance/vendor_policy.yaml; required for a new product")
    ap.add_argument("--tumor-class", default=None, help="solid | heme for oncology; not_applicable for non_oncology")
    ap.add_argument("--spec-version", required=True, help="YYYYMM — the specification cut this pack governs")
    ap.add_argument("--family", default="oncology", help="the products/<family> grouping; use conditions for non_oncology")
    ap.add_argument("--broad", default=None, help="catalogue broad axis (default from tumor-class); general for non_oncology")
    ap.add_argument("--narrow", default=None, help="catalogue narrow axis; general for non_oncology; oncology uses: "
                                                   + ", ".join(_narrow_words()))
    ap.add_argument("--condition-class", default=None,
                    help="oncology | non_oncology; non_oncology creates a neutral scaffold with no inherited clinical rules")
    ap.add_argument("--modality", default=None, choices=list(MODALITIES),
                    help="the data modality the source delivers (products/registry.yaml `modality`)")
    ap.add_argument("--disease-terms", default="",
                    help="comma-separated phrases a specification uses to NAME this disease in prose "
                         "(e.g. \"renal cell carcinoma, kidney cancer\"); written to "
                         "governance/tumour_registry.yaml disease_terms, which DECLARED_DISEASE needs "
                         "to establish whose workbook it reads. Required for a NEW tumour family")
    ap.add_argument("--tumour-family", default=None,
                    help="an EXISTING family in governance/tumour_registry.yaml this product is of "
                         "(an alias) — omit for a new tumour, which becomes its own family")
    ap.add_argument("--ai-classification", required=True, choices=list(sm.AI_CLASSES),
                    help="what AI may read of the specification: the person's call")
    ap.add_argument("--classified-by", required=True, help="who made that call, BY NAME")
    ap.add_argument("--classified-date", required=True, help="YYYY-MM-DD")
    ap.add_argument("--workbook", default=None, help="the program specification (.xlsx) to register and extract; registration does not approve it")
    ap.add_argument("--exclude-sheet", action="append", default=[], metavar="EXACT_SHEET_NAME",
                    help="repeat for each extra workbook sheet outside this product's scope; mapped scientific sections use Plan changes")
    ap.add_argument("--exclude-sheet-reason", default="", help="why the selected extra sheets are outside this product's scope")
    ap.add_argument("--sheet-domain", action="append", default=[], metavar="EXACT_SHEET=DOMAIN",
                    help="assign or correct a requirement sheet's section for this specification; several sheets may share an existing section")
    ap.add_argument("--sheet-domain-reason", default="", help="why these workbook sheets belong to the selected sections")
    ap.add_argument("--column-map", default="", help="JSON mapping worksheet header rows and fields to Excel columns for this cut")
    ap.add_argument("--column-map-reason", default="", help="why these worksheet column choices describe this specification")
    ap.add_argument("--column-map-origin", default="", help="JSON provider/model metadata for a reviewed model-assisted workbook mapping; not approval")
    ap.add_argument("--apply", action="store_true", help="stage, validate, and WRITE (the default only previews)")
    ap.add_argument("--root", default=REPO, help=argparse.SUPPRESS)
    a = ap.parse_args(argv)
    a._outcome = report
    root = os.path.abspath(a.root)
    if a.workbook:
        a.workbook = os.path.abspath(a.workbook)

    if not a.apply:
        return _execute(a, root)
    try:
        guard = _standup_guard(root)
        guard.__enter__()
    except (OSError, ValueError) as error:
        code = _standup_lock_code(error)
        _set_failure(a, "setup_access", [finding("setup_lock_unavailable", _STANDUP_LOCK_MESSAGES[code], lock_code=code)])
        print(f"REFUSED — nothing was written. Setup lock [{code}]: {_STANDUP_LOCK_MESSAGES[code]}", file=sys.stderr)
        return 1
    try:
        try:
            a._prior_recovery = "unknown"
            _set_failure(a, "recovery", write_disposition="unknown")
            recovered = recover_install(root, _guarded=True)
            a._prior_recovery = recovered
        except (OSError, ValueError) as error:
            print(f"REFUSED: installation recovery requires attention. {error}", file=sys.stderr)
            return 1
        if recovered != "absent":
            print("Recovered previous installation: " + recovered + ". Checking this setup against the recovered revision.")
        return _execute(a, root)
    finally:
        guard.__exit__(*sys.exc_info())


def _execute(a, root):
    """Preflight through install; apply callers hold the checkout's stand-up lock."""
    _set_failure(a, "preflight")
    bad = refusals(a, root)
    if bad:
        _set_failure(a, "preflight", bad)
        print(f"REFUSED — nothing was written. {len(bad)} problem(s):", file=sys.stderr)
        for b in bad:
            print(f"  - {b}", file=sys.stderr)
        return 1
    _set_failure(a, "planning")
    pack, steps = (plan_next_cut if a.next_cut_of else plan)(a, root)
    outcome = getattr(a, "_outcome", {})
    outcome["pack"] = pack
    # THE FOLDER IS MEASURED BEFORE ANYTHING RUNS (walk NC-02): a destination Windows cannot create
    # used to surface as a traceback from install(), after every validator had passed.
    bad = path_length_refusals(root, pack, steps)
    if bad:
        _set_failure(a, "planning", [finding("setup_path_limit", value) for value in bad])
        print("REFUSED — nothing was written. 1 problem(s):", file=sys.stderr)
        for b in bad:
            print(f"  - {b}", file=sys.stderr)
        return 1
    if a.next_cut_of:
        outcome["delta"] = spec_change(a, root)
        # THE DELTA IN WORDS, ABOVE THE PLAN (walk NC-07): the plan names files; the person asked
        # which variables changed, and who of the previous cut cites a removed one.
        for line in [f"what the revised workbook changes, against the rows {a._old} registered:", *("  " + value for value in delta_summary(outcome["delta"]))]:
            print(line)
    print(f"PLAN for {pack} ({'apply' if a.apply else 'preview — nothing is written without --apply'})"
          + (f" — the next cut of {a._old}:" if a.next_cut_of else ":"))
    if a.sheet_domain:
        print("  workbook sheet sections: " + "; ".join(a.sheet_domain))
        print("  mapping reason: " + a.sheet_domain_reason.strip())
        print("  Previous cuts and the shared sheet map remain unchanged; this mapping grants no scientific approval.")
    if a.exclude_sheet:
        print("  sheet scope before: " + (", ".join(a._sheet_scope["inherited"]) or "no product-specific exclusions"))
        print("  sheet scope after: " + ", ".join(a.exclude_sheet))
        print("  reason: " + a.exclude_sheet_reason.strip())
        print("  The workbook stays intact. Excluded sheet rows remain traceable and do not become definition requirements.")
    elif a.next_cut_of:
        print("  sheet scope after: no product-specific exclusions; prior exclusions require a fresh choice for this workbook.")
    for rel, action, _payload in steps:
        print(f"  {action:<7} {rel}")
    print(f"  create  {pack}/source_refs.yaml  (source_refs_init.py, from the person's three fields)")
    print(f"  regen   resources/products.yml, governance/CURRENT_STATE.md, products/PORTFOLIO.md"
          + ("" if a.next_cut_of else f", governance/reference/oncology_modules/indication/{a.slug}.yaml"))
    if a.next_cut_of:
        print(f"  note    products/registry.yaml: {a.slug}'s entry is rewritten with its lineage rows; comments on "
              f"that entry do not survive, current_spec_version stays {a._old_version}")
    print("validators, in a staged copy, before any byte lands:")
    for label, _cmd in VALIDATORS:
        print(f"  - {label}")
    print(f"  - Gate 1 over {pack}; the status page renders" + ("; Gate 2 generation over the workbook" if a.workbook else "")
          + (f"; the two cuts compare (spec_diff.py {a._old} {pack})" if a.next_cut_of else ""))
    if not a.apply:
        outcome["state"] = "preview"
        print("\nthen, for a person:")
        for line in remaining(a, pack):
            print(f"  {line}")
        return 0

    _set_failure(a, "validation")
    try:
        staged, failures = stage(root, steps, a, pack)
    except (OSError, ValueError, subprocess.SubprocessError) as exc:
        cause = exc
        timed_out, seen = False, set()
        while cause is not None and id(cause) not in seen:
            seen.add(id(cause))
            timed_out |= isinstance(cause, (SnapshotRuntimeTimeout, subprocess.TimeoutExpired))
            cause = cause.__cause__
        if timed_out:
            code = "setup_runtime_timed_out" if getattr(a, "_runtime_preparing", False) else "setup_stage_timed_out"
            message = ("The isolated setup check timed out before installation. Close other heavy local jobs, "
                       "then preview and try Create product again. If it repeats, ask the workspace owner to "
                       "check the selected Python environment and available memory and disk space.")
        else:
            code = "setup_stage_unavailable"
            message = ("The isolated setup check could not be prepared or completed. Ask the workspace owner "
                       "to check the selected Python environment, workspace files, and temporary-folder access, "
                       "then preview and try Create product again.")
        if getattr(a, "_stage_cleanup_complete", None) is False:
            message += " Temporary setup files could not be removed; the workspace owner must check for an active setup process."
        _set_failure(a, "validation", [finding(code, message, error_type=type(exc).__name__)])
        print("\nREFUSED — nothing was written. " + message, file=sys.stderr)
        return 1
    try:
        if failures:
            label, r = failures[0]
            issues = getattr(r, "workflow_issues", ()) or [finding("setup_stage_failed", "The staged setup check did not complete; inspect the run details.")]
            _set_failure(a, getattr(a, "_failure_stage", "validation"), issues)
            print(f"\nREFUSED — nothing was written. The staged plan failed: {label}", file=sys.stderr)
            tail = ((r.stdout or "") + (r.stderr or "")).strip().splitlines()[-25:]
            for line in tail:
                print(f"    {line}", file=sys.stderr)
            return 1
        baseline = a._stage_baseline
        rels = changed_files(root, staged, baseline)
        package_inputs = getattr(a, "_package_inputs", {})
        if any(relative in package_inputs for relative in rels):
            raise ValueError("A staged check changed installed code or resources; no product changes were installed.")
        authored_baseline = {relative: digest for relative, digest in baseline.items() if relative not in package_inputs}
        try:
            input_changes = _changed_inputs(root, authored_baseline, rels, getattr(a, "_stage_sources", None))
            if input_changes:
                _set_failure(a, "input_freshness", [finding("setup_inputs_changed", "Checkout or workbook inputs changed during validation. Preview the current setup again.")])
                print("\nREFUSED — nothing was written. The checkout or selected workbook changed while the staged product was being "
                      "validated. Review the current files, then preview and write again.", file=sys.stderr)
                for change in input_changes[:10]:
                    print(f"  - {change}", file=sys.stderr)
                if len(input_changes) > 10:
                    print(f"  - and {len(input_changes) - 10} more changed input(s).", file=sys.stderr)
                return 1
            evidence = _set_failure(a, "installation")
            written = install(root, staged, rels, _guarded=True, _write_evidence=evidence)
            outcome.update(state="written", written_paths=list(written))
        except (OSError, ValueError) as exc:
            # install() has already put every file back; what is left to say is why, in words
            print(f"\nREFUSED — installation did not complete. {install_failure_words(root, rels, exc) if isinstance(exc, OSError) else str(exc)}", file=sys.stderr)
            return 1
    finally:
        shutil.rmtree(os.path.dirname(staged), ignore_errors=True)
    print(f"\nWROTE {len(written)} file(s) — every validator passed on the staged copy first:")
    for rel in written:
        print(f"  {rel}")
    print("\nthen, for a person:")
    for line in remaining(a, pack):
        print(f"  {line}")
    return 0


if __name__ == "__main__":
    from rwd_tools.console import use_utf8
    use_utf8()
    sys.exit(main(sys.argv[1:]))
