#!/usr/bin/env python3
"""Export a Program-Spec workbook as a draft cohortly script and manifest.

    python platform/tools/cohortly_export.py <workbook.xlsx> \\
        --out <file outside the checkout> [--manifest <yaml>] \\
        [--bindings <yaml>] [--pack <registered claims pack>]

`cohortly` (gsk-tech, R) selects claims cohorts on Optum/MarketScan. This tool lifts the
workbook's mechanically stated cohort rules — study/index periods, enrollment gap and
windows, the age floor, event-count indexing, code-list tabs — into a cohortly call chain.
Every lifted value carries the workbook row that states it. Anything the tool cannot lift
with certainty becomes a named gap, and all gaps feed one stop() guard the draft cannot run
past. The tool never guesses: ambiguous conjunctions, unstated window directions, formula
cells, compound rows and leftover text all block rather than default.

Outputs:
  --out       a draft R script (readable, reviewable).
  --manifest  the same extraction as versioned YAML, executed end to end by
              platform/engine-r/cohortly_manifest.R.
  --bindings  a small reviewed YAML a person commits. It ties code-list tabs to
              study_specs events, trace calls to events, and lists tabs reviewed as
              carrying no cohort rules. A fully bound spec exports with zero gaps.

Rules:
  * Claims only. With --pack, the pack's registry entry must say `modality: claims`.
  * Outputs are refused inside the checkout; a committed copy goes stale.
  * The draft is UNGOVERNED until the workbook passes Gate 1-2, and says so.
  * Code-list tabs are recognised by shape (a `code` header column), not by name.
  * Codes stored as numbers refuse: Excel numeric cells drop NDC leading zeros.
  * Exit 0 = written and gap-free. Exit 2 = written but blocked.

The workbook template is: sheets `datapreppage` and `studypoppage` with columns
Section | Variable Name | Label | Definition | Notes | Implementation. Headers are
verified, duplicate names refuse, and unknown shapes refuse rather than half-read.
"""
from __future__ import annotations

import argparse
import datetime
import hashlib
import io
import os
import re
import sys
from rwd_tools.spec_extract import repo_relative  # noqa: E402

TOOLS = os.path.dirname(os.path.abspath(__file__))
from rwd_services import workspace_root
ROOT = str(workspace_root(__file__))

# Sheets holding the cohort spine, by the template's own names. A workbook carrying neither
# refuses - half a spine rendered confidently is worse than no render.
SPINE_SHEETS = ("datapreppage", "studypoppage")
HEADERS = ("section", "variable name", "label", "definition", "notes", "implementation")

DATE_RE = re.compile(r"(\d{1,2})\s*([A-Za-z]{3,9})\s*(\d{4})")
_MONTH_NAMES = ("January", "February", "March", "April", "May", "June", "July",
                "August", "September", "October", "November", "December")
# EXACT month tokens only: the full
# name or the exact three-letter abbreviation - never a prefix of something else
MONTHS = {**{m.lower(): i for i, m in enumerate(_MONTH_NAMES, 1)},
          **{m.lower()[:3]: i for i, m in enumerate(_MONTH_NAMES, 1)}}
_WORDS = {w: i for i, w in enumerate(
    ("one", "two", "three", "four", "five", "six", "seven", "eight",
     "nine", "ten", "eleven", "twelve"), 1)}


def _c(text):
    """Workbook text bound for the R script: whitespace flattened, so a cell carrying a
    newline plus R syntax stays inside its comment instead of becoming code."""
    return re.sub(r"\s+", " ", str(text or "")).strip()


def _dates(text):
    """(valid_iso_dates, date_shaped_count) for a cell. Every DATE-SHAPED token is COUNTED
    even when it does not validate - the caller compares the
    two numbers and a mismatch is a gap, never a silent drop. The month token must be the
    full name or the exact three-letter abbreviation ('Junk' is not June)."""
    out, shaped = [], 0
    for d, mon, y in DATE_RE.findall(str(text or "")):
        shaped += 1
        m = MONTHS.get(mon.lower())
        if not m:
            continue
        try:
            out.append(datetime.date(int(y), m, int(d)).isoformat())
        except ValueError:
            continue
    return out, shaped


CODE_RE = re.compile(r"^[A-Za-z0-9 .\-*/]+$")


def _codelist_columns(header_cells):
    """Column indices for a code-list-shaped header, or None. Recognition is by SHAPE: a cell
    named `code` (or `codes`, or `... code`) makes the tab a code list whatever the TAB is
    called - MM says dx_codes, the next study will say something else."""
    cols = {"code": None, "type": None, "desc": None}
    for i, cell in enumerate(header_cells):
        h = str(cell or "").strip().lower()
        if cols["code"] is None and (h in ("code", "codes") or h.endswith(" code")):
            cols["code"] = i
        elif cols["type"] is None and h in ("code_type", "code type", "type", "system",
                                            "code system", "codesystem", "vocabulary"):
            cols["type"] = i
        elif cols["desc"] is None and (h.startswith("desc") or h == "label"):
            cols["desc"] = i
    return cols if cols["code"] is not None else None


def read_workbook(path):
    """({sheet: {variable_name: row}}, tabs, sha256hex) - tabs carries three views of the
    non-content sheets: `status` (every sheet's first cell, for the TO-BE-BUILT scan),
    `lists` (code-list tabs recognised by shape and lifted verbatim), and `unread` (sheets
    that are none of the above, NAMED with their headers - never silently skipped).

    The digest is computed from the SAME bytes that are parsed (one read, then BytesIO), so a
    concurrent replacement of the file cannot make the output describe one workbook while
    stamping another's hash. Header rows are verified against the template, duplicate
    variable names refuse, and a code stored as a NUMBER refuses - Excel numeric cells eat
    NDC leading zeros and trailing precision, and a truncated code selects the wrong claims."""
    from openpyxl import load_workbook # noqa: PLC0415
    with open(path, "rb") as fh:
        data = fh.read()
    digest = hashlib.sha256(data).hexdigest()
    # FORMULAS REFUSE OUTRIGHT (probe wave: a formula cell whose cached value was absent
    # vanished from the parse - and even a cached value can be stale against its formula).
    # A specification states values; a computation is not a statement. One pass over the
    # raw workbook, before any content is trusted.
    wb_raw = load_workbook(io.BytesIO(data), read_only=True, data_only=False)
    for _sheet in wb_raw.sheetnames:
        for _row in wb_raw[_sheet].iter_rows(values_only=True):
            for _cell in _row:
                if isinstance(_cell, str) and _cell.startswith("="):
                    raise SystemExit(
                        f"{path} sheet {_sheet!r}: cell contains a FORMULA ({_cell[:40]!r}) "
                        f"- a specification states values, and a formula's cached result "
                        f"can be absent or stale. Paste values in place of formulas; "
                        f"nothing was rendered.")
    wb_raw.close()
    wb = load_workbook(io.BytesIO(data), read_only=True, data_only=True)
    spine = {}
    tabs = {"status": {}, "lists": {}, "unread": {}}
    for sheet in wb.sheetnames:
        ws = wb[sheet]
        first = next(ws.iter_rows(max_row=1, values_only=True), ())
        tabs["status"][sheet] = str(first[0] or "") if first else ""
        if sheet not in SPINE_SHEETS:
            if "TO BE BUILT" in tabs["status"][sheet].upper():
                continue # the guard names it; nothing to lift
            cols = _codelist_columns(first)
            if cols is None:
                headers = [str(c) for c in first if c is not None]
                if headers: # a blank sheet is not worth naming
                    tabs["unread"][sheet] = headers
                continue
            codes, seen_codes = [], set()
            for r in ws.iter_rows(min_row=2, values_only=True):
                raw = r[cols["code"]] if len(r) > cols["code"] else None
                if raw is None or str(raw).strip() == "":
                    continue
                if str(raw).strip() in seen_codes:
                    raise SystemExit(
                        f"{path} tab {sheet!r}: code {str(raw).strip()!r} appears twice - a "
                        f"duplicate in a code list is an editing error, and every reader "
                        f"would silently deduplicate it differently. Fix the tab; nothing "
                        f"was rendered.")
                seen_codes.add(str(raw).strip())
                if isinstance(raw, (int, float)):
                    raise SystemExit(
                        f"{path} tab {sheet!r}: code {raw!r} is stored as a NUMBER - Excel "
                        f"numeric cells eat leading zeros and trailing precision (an NDC "
                        f"'00069...' becomes '69...'), and a truncated code selects the wrong "
                        f"claims. Format the code column as TEXT; nothing was rendered.")
                code = str(raw).strip()
                if not CODE_RE.match(code):
                    raise SystemExit(
                        f"{path} tab {sheet!r}: code {code!r} carries characters no claims "
                        f"code system uses - a corrupt cell, refused rather than exported.")
                entry = {"code": code}
                for k, field in (("type", "type"), ("desc", "description")):
                    i = cols[k]
                    if i is not None and len(r) > i and r[i] is not None:
                        entry[field] = _c(r[i])
                codes.append(entry)
            tabs["lists"][sheet] = {"columns": {k: v for k, v in cols.items() if v is not None},
                                    "codes": codes}
            continue
        got = tuple(str(c or "").strip().lower() for c in first[:len(HEADERS)])
        # per-position TOKEN containment, not equality: the house template decorates its
        # headers ("Definition (validated from protocol)", "Optum CDM Implementation") but a
        # reordered sheet still refuses, because the expected token is missing at its position
        if len(got) < len(HEADERS) or not all(h in g for h, g in zip(HEADERS, got)):
            raise SystemExit(
                f"{path} sheet {sheet!r}: header row is {got!r}, expected the tokens "
                f"{HEADERS!r} at those positions. Positions carry meaning in this template; "
                f"a reordered sheet would be confidently misread, so it refuses instead.")
        rows = {}
        for rownum, r in enumerate(ws.iter_rows(min_row=2, values_only=True), start=2):
            key = str(r[1] or "").strip() if len(r) > 1 else ""
            if not key:
                # a NAMELESS row with content is ungovernable content (probe wave: it was
                # silently discarded) - nothing can cite, gap, or bind what has no name
                stray = " ".join(str(c) for c in r if c is not None and str(c).strip())
                if stray:
                    raise SystemExit(
                        f"{path} sheet {sheet!r} row {rownum}: no Variable Name but the row "
                        f"carries text ({stray[:80]!r}) - unnamed content cannot be "
                        f"governed; name the row or clear it. Nothing was rendered.")
                continue
            if key in rows:
                raise SystemExit(
                    f"{path} sheet {sheet!r}: variable name {key!r} appears twice - two "
                    f"specification rows under one name, and any reader keeps only one. "
                    f"Fix the workbook; nothing was rendered.")
            rows[key] = {"label": str(r[2] or "") if len(r) > 2 else "",
                         "definition": str(r[3] or "") if len(r) > 3 else "",
                         "notes": str(r[4] or "") if len(r) > 4 else "",
                         "impl": str(r[5] or "") if len(r) > 5 else ""}
        spine[sheet] = rows
    wb.close()
    missing = [s for s in SPINE_SHEETS if s not in spine]
    if missing:
        raise SystemExit(f"{path}: missing spine sheets {missing} of {SPINE_SHEETS} - not the "
                         f"full house workbook template, refusing rather than half-reading "
                         f"(probe wave 15: one sheet alone renders half a cohort confidently)")
    return spine, tabs, digest


def _find(spine, *names):
    for sheet in SPINE_SHEETS:
        for n in names:
            if n in spine.get(sheet, {}):
                return sheet, n, spine[sheet][n]
    return None, None, None


def _first_int(text, pattern):
    m = re.search(pattern, str(text or ""))
    return int(m.group(1)) if m else None


def _blob(key, row):
    """A row's searchable CONTENT with word-numbers normalised ('At least one inpatient',
    'six months of Continuous Enrollment'). Deliberately excludes the key and label: they
    are the row's NAME, and residual accounting must judge only what the row STATES - the
    digit in 'Criterion 1' is not an unconsumed threshold."""
    text = " ".join([row["definition"], row["notes"], row["impl"]])
    return re.sub(r"\b(" + "|".join(_WORDS) + r")\b",
                  lambda m: str(_WORDS[m.group(1).lower()]), text, flags=re.I)


def _period(spine, what, *names):
    """A period row lifted only when it states EXACTLY two valid dates in order - a third
    date, an invalid one, or end-before-start each becomes the gap's own words."""
    sheet, key, row = _find(spine, *names)
    if not row:
        return None, f"{what}: no row named {names[0]} in the spine sheets"
    ds, shaped = _dates(row["definition"])
    prov = f"{sheet}:{key}"
    if shaped != len(ds):
        return None, (f"{what}: {prov} carries {shaped} date-shaped token(s) but only "
                      f"{len(ds)} validate - an invalid date beside valid ones must be "
                      f"fixed, never silently dropped")
    if len(ds) != 2:
        return None, (f"{what}: {prov} states {len(ds)} valid date(s), not exactly two - "
                      f"which two bound the period is not mechanically clear")
    if ds[0] >= ds[1]:
        return None, f"{what}: {prov} states {ds[0]} .. {ds[1]}, which is not chronological"
    return (ds[0], ds[1], prov), None


def _month_factor(spine):
    """(factor, provenance, problem) - the workbook's OWN days-per-month conversion row, read
    by an explicit unit grammar. The days-side number is the one ATTACHED to the word
    'day', divided by the months-side number when one is stated - so '12 months = 365 days'
    is 365/12 - and anything ambiguous (two day-numbers, two month-numbers, non-positive)
    is a named problem the CE criterion turns into its gap, never resolved by position."""
    for sheet in SPINE_SHEETS:
        for key, row in spine.get(sheet, {}).items():
            text = " ".join([key, row["label"], row["definition"], row["impl"]])
            if "month" not in text.lower() or "conver" not in text.lower():
                continue
            body = row["definition"] + " " + row["impl"]
            prov = f"{sheet}:{key}"
            days = re.findall(r"(\d+(?:\.\d+)?)\s*days?\b", body, re.I)
            months = re.findall(r"(\d+(?:\.\d+)?)\s*months?\b", body, re.I)
            if len(days) != 1 or len(months) > 1:
                return None, prov, (f"the conversion row {prov} is ambiguous - "
                                    f"{len(days)} day-number(s) and {len(months)} "
                                    f"month-number(s); state it as 'N months = M days'")
            # EXPLICIT GRAMMAR ONLY (probe wave: '12-month conversion uses 365 days' slipped a
            # positional read and became 365 days per month). The two recognised forms are
            # 'N months <=/is/equals/converts to> M days' and 'M days per month'; any other
            # phrasing refuses rather than guesses.
            m1 = re.search(r"(?i)(\d+(?:\.\d+)?)\s*months?\s*(?:=|is|equals?|converts?\s+to)"
                           r"\s*(\d+(?:\.\d+)?)\s*days?\b", body)
            m2 = re.search(r"(?i)(\d+(?:\.\d+)?)\s*days?\s*(?:per|/|to\s+(?:a|one))\s*month\b",
                           body)
            if m1:
                mo, d = float(m1.group(1)), float(m1.group(2))
            elif m2:
                mo, d = 1.0, float(m2.group(1))
            else:
                return None, prov, (f"the conversion row {prov} does not state the factor in "
                                    f"a recognised form - write 'N months = M days' or "
                                    f"'M days per month'; anything else would be guessed, "
                                    f"and this tool does not guess")
            if d <= 0 or mo <= 0:
                return None, prov, f"the conversion row {prov} states a non-positive value"
            return d / mo, prov, None
    return None, None, None


# The INERT vocabulary: the only words a lifted criterion's residual may contain. This is an
# ALLOWLIST, deliberately (probe wave: the audit-16 blocklist caught 'and no hospice' but not
# 'receiving hospice during baseline' - scanning for bad words fails open on every bad word
# nobody listed, so the grammar now names the harmless words and everything else blocks).
# Every entry is connective tissue or boilerplate that cannot state a condition on its own;
# a word not on this list - hospice, receiving, during, prior, whatever comes next - demotes
# the lift. Extending this list is a reviewed edit, never an inference.
_INERT_WORDS = frozenset("""
    a an the of at in on for to be is are was were with patients patient aged age
    index date dates period separate day days claim claims
    medical spans joined across gap gaps enrollment enrolment continuous study
    baseline inclusive
""".split())
# NO temporal-direction word is inert: 'after/following/post' AND
# 'before/prior/preceding' change what a criterion means relative to index, so an
# unconsumed direction word demotes any lift - the CE branch CONSUMES its stated
# before-index span, and every other row carrying a direction the call does not
# represent blocks instead of lifting without it.


def _residual(blob, spans):
    """The row's text with every CONSUMED span removed - what remains is what the lift did
    not carry. A lifted criterion stands only when every residual token is on the inert
    allowlist and no digit remains; anything else - an unconsumed threshold, a code, a
    condition word nobody listed - demotes the lift back to a gap. Fail closed on text
    nobody accounted for."""
    keep, last = [], 0
    for s, e in sorted(sp.span() if hasattr(sp, "span") else sp for sp in spans):
        keep.append(blob[last:s])
        last = max(last, e)
    keep.append(blob[last:])
    return " ".join("".join(keep).split())


def _residual_problem(resid):
    """The first token the inert grammar cannot account for, or None."""
    if re.search(r"\d", resid):
        return re.search(r"\S*\d\S*", resid).group(0)
    for token in re.findall(r"[A-Za-z]+", resid):
        if token.lower() not in _INERT_WORDS:
            return token
    return None


def extract(spine):
    """The mechanically-stated spine as data; everything unresolvable lands in gaps, and a
    criterion that cannot be lifted carries its own gap reason - the render turns every one
    of them into the stop() guard."""
    out = {"gaps": [], "criteria": []}

    for slot, what, names in (("study", "study period", ("STUDYPD", "STUDY_PD", "STUDYPERIOD")),
                              ("index", "identification period", ("ID_PD", "INDEXPD", "ID_PERIOD"))):
        val, gap = _period(spine, what, *names)
        if val:
            out[slot] = val
        else:
            out["gaps"].append(gap)

    # enrollment gap: "<=N day" lifted only from a row that is ABOUT enrollment - the same
    # phrase on a washout or spacing row must not become the enrollment allowance
    for sheet in SPINE_SHEETS:
        for key, row in spine.get(sheet, {}).items():
            blob = _blob(key, row)
            if "enrol" not in blob.lower():
                continue
            n = _first_int(blob, r"<=\s*(\d+)\s*day")
            if n is not None:
                out["enrl_gap"] = (n, f"{sheet}:{key}")
                break
        if "enrl_gap" in out:
            break
    if "enrl_gap" not in out:
        out["gaps"].append("enrollment gap: no enrollment row states an '<=N day' allowance")

    factor, factor_prov, factor_problem = _month_factor(spine)

    # criteria rows: "Criterion N (INCLUSION|EXCLUSION)" in the template's own spelling
    for sheet in SPINE_SHEETS:
        for key, row in spine.get(sheet, {}).items():
            m = re.match(r"Criterion\s+(\d+)\s*\((INCLUSION|EXCLUSION)\)", key, re.I)
            if not m:
                continue
            crit = {"key": f"{sheet}:{key}", "kind": m.group(2).upper(),
                    "definition": row["definition"], "call": None,
                    "gap": "not mechanically liftable - a person translates this row"}
            blob = _blob(key, row)
            spans = [] # every span a lift CONSUMES; the residual is judged
            ip_m = re.search(r"(?i)(?:>=|at least)\s*(\d+)\s+inpatient(?:\s+(?:medical\s+)?"
                             r"claims?)?", blob)
            op_m = re.search(r"(?i)(?:>=|at least)\s*(\d+)\s+outpatient(?:\s+(?:medical\s+)?"
                             r"claims?)?", blob)
            age_m = re.search(r"(?i)(?:>=|at least)\s*(\d+)\s*years(?:\s+of\s+age)?", blob)
            age = int(age_m.group(1)) if age_m else None
            ced_m = re.search(r"(?i)(\d+)\s*days?\s+(?:of\s+)?continuous\s+enrollment", blob)
            cem_m = re.search(r"(?i)(\d+)\s*months?\s+(?:of\s+)?continuous\s+enrollment", blob) \
                or re.search(r"(?i)>=?\s*(\d+)\s*months?\s+(?:of\s+)?CE\b", blob)
            ce_days = int(ced_m.group(1)) if ced_m else None
            ce_months = int(cem_m.group(1)) if cem_m else None
            # the spine-level phrases this row may legitimately carry are consumed too: the
            # enrollment-gap allowance and stated windows are lifted elsewhere or below
            spans += list(re.finditer(r"(?i)<=\s*\d+\s*day\w*(\s+gap\w*)?", blob))
            spans += list(re.finditer(r"(?i)within\s+\d+\s*days?", blob))
            # COMPLETE-OR-BLOCKING: one row can state several clause families, and
            # one cohortly call carries one. Lifting the first recognisable clause and clearing
            # the gap silently dropped the rest - so a row matching MORE than one family blocks
            # whole, and the person splits the row or translates it entire.
            fam_event = bool(ip_m or op_m)
            fam_age = age is not None and "age" in blob.lower()
            fam_ce = ce_days is not None or ce_months is not None
            if sum([fam_event, fam_age, fam_ce]) >= 2:
                crit["gap"] = ("compound criterion: more than one recognisable clause family "
                               "in one row (events / age / enrollment) - one call cannot "
                               "carry them all, and lifting only the first would silently "
                               "drop the rest; split the row or translate it whole")
            elif ip_m and op_m:
                # the conjunction is LIFTED from the text between the two phrases; one
                # distinct or/and lifts, anything else is a gap - a defaulted OR once changed
                # cohort membership on a workbook that said AND
                lo, hi = sorted([ip_m, op_m], key=lambda x: x.start())
                conj = {c.lower() for c in re.findall(r"(?i)\b(or|and)\b", blob[lo.end():hi.start()])}
                spans += [ip_m, op_m, (lo.end(), hi.start())]
                if re.search(r"(?i)within\s+\d+(?:\s*/\s*\d+)+", blob):
                    crit["gap"] = ("the outpatient window is stated as alternatives "
                                   "('within 30/60/90 days') - which one is primary is a "
                                   "protocol ruling, not a mechanical lift")
                elif len(conj) == 1:
                    kw = {"ip_min_count": int(ip_m.group(1)),
                          "op_min_count": int(op_m.group(1)),
                          "ip_op_condition": conj.pop(), "purpose": "index"}
                    w = _first_int(blob, r"(?i)within\s+(\d+)\s*days")
                    if w is not None:
                        kw["op_gap_window"] = [1, w]
                    crit["call"] = ("trace_event_count", kw)
                else:
                    crit["gap"] = ("inpatient and outpatient counts are both stated, but the "
                                   "OR/AND between them is not mechanically clear - a person "
                                   "rules the conjunction")
            elif fam_age:
                spans.append(age_m)
                crit["call"] = ("trace_age", {"min_age": age, "purpose": "select"})
            elif ce_days is not None or ce_months is not None:
                # DIRECTION IS PART OF THE WINDOW (probe wave: 'before index' and 'after
                # index' both produced the same pre-index window). Only an explicit
                # BEFORE-index statement lifts to [-N,-1]; 'after/following/post index' is a
                # different call shape a person translates, and an UNSTATED direction is a
                # gap, never a default sign.
                spans.append(ced_m if ce_days is not None else cem_m)
                direction_m = re.search(
                    r"(?i)\b(before|prior\s+to|preceding)\b[\s\w]{0,20}\bindex\b", blob)
                after_m = re.search(
                    r"(?i)\b(after|following|post)\b[\s\w]{0,20}\bindex\b", blob)
                if after_m or not direction_m:
                    crit["gap"] = ("the enrollment window's direction relative to index is "
                                   + ("stated as POST-index - a different call shape a "
                                      "person translates" if after_m else
                                      "unstated - a sign this tool must never default"))
                    out["criteria"].append(crit)
                    continue
                spans.append(direction_m)
                if ce_days is not None:
                    crit["call"] = ("trace_enrl", {"window": [-ce_days, -1],
                                                   "purpose": "select"})
                elif factor is not None:
                    crit["call"] = ("trace_enrl",
                                    {"window": [-round(ce_months * factor), -1],
                                     "purpose": "select"})
                    crit["conversion"] = f"{ce_months} months x {factor} days/month per {factor_prov}"
                elif factor_problem:
                    crit["gap"] = factor_problem
                else:
                    crit["gap"] = (f"continuous enrollment is stated as {ce_months} months and "
                                   f"the workbook states no days-per-month conversion row - "
                                   f"month-to-day is a methodology ruling, not arithmetic")
            if crit["call"]:
                # RESIDUAL ACCOUNTING: the lift stands only if the text it did NOT
                # consume carries no condition of its own - an unconsumed digit or a
                # no/not/without/except/unless/and/or outside the consumed spans means the row
                # states more than the call, and half a criterion selects the wrong people.
                resid = _residual(blob, [sp for sp in spans if sp is not None])
                problem = _residual_problem(resid)
                if problem:
                    crit["call"] = None
                    crit["gap"] = (f"the row states more than the lifted clause - the inert "
                                   f"grammar cannot account for {problem!r} in the residual "
                                   f"({_c(resid)[:90]!r}); split the row or translate it whole")
                else:
                    crit["gap"] = None
                    if crit["kind"] == "EXCLUSION":
                        crit["call"][1]["expectation"] = "absence"
            out["criteria"].append(crit)

    # A SUBSTANTIVE ROW THAT IS NOT A CRITERION ROW IS INVISIBLE, AND INVISIBLE IS THE DEFECT
    # (probe wave: a hospice exclusion written without the exact 'Criterion N (...)' spelling
    # vanished entirely). studypoppage is the population sheet: every row on it either IS a
    # criterion or blocks by name until a person renames or removes it.
    for key, row in spine.get("studypoppage", {}).items():
        if re.match(r"Criterion\s+\d+\s*\((INCLUSION|EXCLUSION)\)", key, re.I):
            continue
        # ALL four content cells (probe wave: Label/Notes content vanished when only
        # Definition and Implementation were inspected)
        text = _c(" ".join([row["label"], row["definition"], row["notes"], row["impl"]]))
        if text:
            out["gaps"].append(f"studypoppage row {key!r} is not a recognised criterion row "
                               f"and carries substantive text - it would be silently ignored; "
                               f"rename it 'Criterion N (INCLUSION|EXCLUSION)' or remove it")
    return out


BIND_ARGS = ("dx_cd", "ndc_cd", "cpt_hcpcs_cd", "px_cd")

# which code systems each cohortly argument accepts - EXACT controlled identifiers after
# normalisation (upper-case, separators stripped), never substrings (probe wave: 'icd' as a
# substring let ICD-10-PCS satisfy a diagnosis argument and 'NOT-NDC' satisfy NDC). A system
# not in the table refuses; adding one is a reviewed edit.
VOCAB_FOR_ARG = {"dx_cd": ("ICD9CM", "ICD10CM"),
                 "ndc_cd": ("NDC",),
                 "cpt_hcpcs_cd": ("CPT", "CPT4", "HCPCS"),
                 "px_cd": ("ICD9PCS", "ICD10PCS", "CPT", "CPT4", "HCPCS")}

# names an event may never take: R reserved words would render invalid code, and the runtime
# argument names of study_specs / the trace calls would collide with or overwrite real
# arguments
_FORBIDDEN_EVENT_NAMES = frozenset(
    "if else repeat while function for in next break true false null inf nan na "
    "db data_refresh study_period_start_dt study_period_end_dt index_period_start_dt "
    "index_period_end_dt max_enrl_gap annual_analysis keep_general_popl event window "
    "op_gap_window purpose expectation ip_min_count op_min_count ip_op_condition min_age "
    "trace_type period col_prefix".split())


def _norm_system(ty):
    return re.sub(r"[^A-Za-z0-9]", "", str(ty or "")).upper()


def load_bindings(path, tabs, ex):
    """The GOVERNED resolution of the EVENTS gap. A bindings
    file is a small reviewed YAML a PERSON authors and commits beside the study - this
    function only validates and consumes it:

        events:
          mm_therapy: {ndc_cd: mm_therapy_ndc, cpt_hcpcs_cd: mm_therapy_hcpcs}
        criteria:
          "Criterion 1 (INCLUSION)": mm_therapy # which event a trace call counts
        ignore_tabs: [glossary, change_log] # reviewed as carrying no cohort rules

    Every reference is validated against the workbook as read, and a defect in a reviewed
    file refuses outright - half-applied bindings are how a criterion loses its codes."""
    # THE STRICT READER, not yaml.safe_load: a duplicate key in a governed mapping was
    # last-wins, so `criteria:` stated twice silently dropped the first block - the reviewed
    # file said one thing and the export did another. The raw bytes are still
    # read for the bindings digest the manifest records.
    from rwd_tools import product_gates as pg # noqa: PLC0415
    with open(path, "rb") as fh:
        data = fh.read()
    b, err = pg.read_yaml(path)
    if err:
        raise SystemExit(f"{path}: {err}")
    b = b or {}
    unknown = set(b) - {"events", "criteria", "ignore_tabs"}
    if unknown:
        raise SystemExit(f"{path}: unknown bindings keys {sorted(unknown)} - a key this "
                         f"validator does not consume is a claim nothing enforces")
    events = b.get("events") or {}
    for event, argmap in events.items():
        # a safe identifier grammar, because the name lands verbatim in generated R (audit
        # 16: a crafted event name inserted executable syntax) - reviewed or not, no file
        # gets to smuggle code through a name
        if not re.match(r"^[a-z][a-z0-9_]{0,63}$", str(event)):
            raise SystemExit(f"{path}: event name {event!r} is not a safe identifier "
                             f"([a-z][a-z0-9_]*, max 64) - it lands verbatim in generated R")
        if str(event) in _FORBIDDEN_EVENT_NAMES:
            raise SystemExit(f"{path}: event name {event!r} is an R reserved word or a "
                             f"runtime argument name - it would render invalid R or collide "
                             f"with a real argument (probe wave 17)")
        if not isinstance(argmap, dict) or not argmap:
            raise SystemExit(f"{path}: event {event!r} binds nothing")
        for arg, tab in argmap.items():
            if arg not in BIND_ARGS:
                raise SystemExit(f"{path}: event {event!r} arg {arg!r} is not one of "
                                 f"{BIND_ARGS}")
            if tab not in tabs["lists"] or not tabs["lists"][tab]["codes"]:
                raise SystemExit(f"{path}: event {event!r} binds {arg} to tab {tab!r}, which "
                                 f"is not a lifted, non-empty code-list tab in this workbook")
            # VOCABULARY-TO-ARGUMENT COMPATIBILITY (probe wave: ICD-10 codes bound to ndc_cd
            # with zero blockers - a list that selects nothing, or the wrong claims). Every
            # bound code must carry a code-system, and the system must fit the argument.
            allowed = VOCAB_FOR_ARG[arg]
            for e in tabs["lists"][tab]["codes"]:
                ty = _norm_system(e.get("type"))
                if not ty:
                    raise SystemExit(f"{path}: event {event!r} binds {arg} to tab {tab!r}, "
                                     f"whose code {e['code']!r} carries no code-system - a "
                                     f"BOUND list must state its vocabulary on every row")
                if ty not in allowed:
                    raise SystemExit(f"{path}: event {event!r} binds {arg} to tab {tab!r}, "
                                     f"but code {e['code']} is {e.get('type')!r} "
                                     f"(normalised {ty}) and {arg} takes exactly "
                                     f"{'/'.join(allowed)} - a mismatched or unrecognised "
                                     f"vocabulary selects nothing or the wrong claims")
    # SHEET-QUALIFIED resolution (probe wave: a bare name appearing on both specification
    # sheets received one binding for two different rows). A bare key must be unique across
    # sheets or it refuses; the full 'sheet:Criterion N (...)' form always resolves exactly.
    full = {c["key"] for c in ex["criteria"]}
    bare_counts = {}
    for c in ex["criteria"]:
        bare_counts[c["key"].split(":", 1)[1]] = \
            bare_counts.get(c["key"].split(":", 1)[1], 0) + 1
    for row, event in (b.get("criteria") or {}).items():
        if ":" in row:
            if row not in full:
                raise SystemExit(f"{path}: criteria key {row!r} matches no criterion row "
                                 f"(have {sorted(full)})")
        elif row not in bare_counts:
            raise SystemExit(f"{path}: criteria key {row!r} matches no criterion row "
                             f"(have {sorted(bare_counts)})")
        elif bare_counts[row] > 1:
            raise SystemExit(f"{path}: criteria key {row!r} appears on more than one sheet "
                             f"- qualify it as '<sheet>:{row}' so the binding names exactly "
                             f"one row")
        if event not in events:
            raise SystemExit(f"{path}: criterion {row!r} names event {event!r}, which the "
                             f"events block does not declare")
    for t in b.get("ignore_tabs") or []:
        if t not in tabs["unread"]:
            raise SystemExit(f"{path}: ignore_tabs entry {t!r} is not an unread tab in this "
                             f"workbook (unread: {sorted(tabs['unread'])}) - an ignore that "
                             f"matches nothing is a typo waiting to hide a real tab")
    return {"events": events, "criteria": b.get("criteria") or {},
            "ignore_tabs": list(b.get("ignore_tabs") or []),
            "sha256": hashlib.sha256(data).hexdigest()}


def apply_bindings(ex, b):
    """Ties event-shaped calls to their declared events. With bindings present, an event call
    with NO named event becomes a gap - never an event-less call that counts nothing."""
    if not b:
        return
    for c in ex["criteria"]:
        if not c["call"] or c["call"][0] not in ("trace_event_count", "trace_events"):
            continue
        # the FULL key wins; a bare key applies only when load_bindings proved it unique
        bound = b["criteria"].get(c["key"], b["criteria"].get(c["key"].split(":", 1)[1]))
        if bound:
            fn, kw = c["call"]
            c["call"] = (fn, {"event": bound, **kw})
        else:
            c["call"], c["gap"] = None, ("its trace call needs an event, and the bindings "
                                         "file's criteria block does not name one for this row")


def _guards(tabs, ex, b=None):
    """Every reason the draft must refuse to run, in one list - the stop() below is fed by
    this and nothing else, so a new gap kind cannot silently become a mere comment."""
    todo = sorted(s for s, first in tabs["status"].items()
                  if "TO BE BUILT" in str(first).upper())
    g = [f"spine: {_c(x)}" for x in ex["gaps"]]
    g += [f"criterion {_c(c['key'])}: {_c(c['gap'])}" for c in ex["criteria"] if c["gap"]]
    # a cohort with no criteria is EVERYBODY, and one with no index criterion has no anchor
    # (probe wave: a workbook with zero Criterion rows exported an empty list with zero
    # blockers, and the loader finalized an unfiltered cohort)
    n_index = sum(1 for c in ex["criteria"]
                  if c["call"] and c["call"][1].get("purpose") == "index")
    if not ex["criteria"]:
        g.append("no 'Criterion N (INCLUSION|EXCLUSION)' rows found - a cohort with no "
                 "criteria selects everybody, and an empty criteria list must never load")
    elif n_index == 0:
        g.append("no lifted index criterion - a cohort without an index event has no anchor; "
                 "the index-defining row is missing, unrecognised, or blocked above")
    elif n_index > 1:
        g.append(f"{n_index} lifted index criteria - EXACTLY ONE row anchors a cohort "
                 f"(probe wave 18); which event indexes is a protocol ruling, not a race between "
                 f"rows")
    lifted = {s: v for s, v in tabs["lists"].items() if v["codes"]}
    bound_tabs = {t for argmap in (b["events"] if b else {}).values() for t in argmap.values()}
    g += [f"code-list tab {s!r} has no code-system column - which vocabulary these codes "
          f"belong to is unstated" for s in sorted(lifted) if "type" not in lifted[s]["columns"]]
    if b and b["events"]:
        g += [f"code-list tab {s!r} is lifted but bound to no event in the bindings file"
              for s in sorted(set(lifted) - bound_tabs)]
    elif lifted:
        g.append("EVENTS: code lists are lifted as vectors below, but no bindings file ties "
                 "them to study_specs events - author one (a reviewed YAML; see --bindings) "
                 "rather than retyping codes")
    else:
        g.append("EVENTS: no code-list tab is filled yet - index-event and therapy "
                 "definitions must be lifted from their governed tabs, never retyped")
    ignored = set(b["ignore_tabs"]) if b else set()
    g += [f"tab {s!r} is neither spine, nor code list, nor TO BE BUILT"
          + (", nor in the bindings file's ignore_tabs" if b else
             " (a bindings file's reviewed ignore_tabs can clear this)")
          + " - unread content may carry cohort rules"
          for s in sorted(set(tabs["unread"]) - ignored)]
    g += [f"code-list tab {s!r} carries a header and ZERO codes - an empty list would "
          f"select nobody, silently" for s, v in sorted(tabs["lists"].items())
          if not v["codes"]]
    g += [f"workbook tab {s!r} says TO BE BUILT - its list cannot be lifted yet" for s in todo]
    return g


def _r_args(kw):
    parts = []
    for k, v in kw.items():
        if k in ("window", "op_gap_window"):
            parts.append(f"{k} = {v[0]}:{v[1]}")
        elif isinstance(v, int):
            parts.append(f"{k} = {v}")
        else:
            parts.append(f"{k} = '{v}'")
    return ", ".join(parts)


def _rvar(sheet):
    """A tab name as a VALID R identifier, or a refusal - never a best effort."""
    var = re.sub(r"\W+", "_", str(sheet)).strip("_").lower()
    if not re.match(r"^[a-z][a-z0-9_]*$", var) or var in _FORBIDDEN_EVENT_NAMES:
        raise SystemExit(f"tab {sheet!r} cannot become a valid R identifier ({var!r}) - "
                         f"rename the tab; generated code never guesses a name")
    return var


def render(name, tabs, ex, digest, b=None):
    today = datetime.date.today().isoformat()
    guards = _guards(tabs, ex, b)
    lifted = {s: v for s, v in sorted(tabs["lists"].items()) if v["codes"]}
    vars_seen = {}
    for sheet in lifted: # two tabs one identifier = one vector lost
        var = _rvar(sheet)
        if var in vars_seen:
            raise SystemExit(f"tabs {vars_seen[var]!r} and {sheet!r} both become R "
                             f"identifier {var!r} - rename one tab; a collision here would "
                             f"silently overwrite a code list")
        vars_seen[var] = sheet

    L = [f"# GENERATED DRAFT - DO NOT EDIT, DO NOT RUN AS-IS.",
         f"# CLAIMS ONLY: cohortly executes on claims (Optum/MarketScan). This draft is for a",
         f"# claims study; the platform's EHR packs and their ADS engine neither feed nor read",
         f"# this bridge, and an EHR workbook exported here has no engine behind the output.",
         f"# workbook: {_c(name)}  sha256[:16]: {digest[:16]}  rendered: {today}",
         f"# UNGOVERNED: no signed decision stands behind any value below. The governed path",
         f"# intakes this workbook through Gate 1-2 and regenerates; every value here carries",
         f"# the workbook row that states it, and every GAP is a person's translation to make.",
         f"# cohortly interface: NOT pinned to a package version - verify study_specs() and",
         f"# trace_*() signatures against the installed cohortly before relying on this draft.",
         "library(cohortly)", ""]
    args = ["  db = '',              # GAP: the cohortly db identifier is not a workbook fact",
            "  data_refresh = '',    # GAP: pin the cut - 'latest available' is the anti-pattern"]
    if "study" in ex:
        s0, s1, prov = ex["study"]
        args += [f"  study_period_start_dt = '{s0}',   # {_c(prov)}",
                 f"  study_period_end_dt   = '{s1}',   # {_c(prov)}"]
    if "index" in ex:
        s0, s1, prov = ex["index"]
        args += [f"  index_period_start_dt = '{s0}',   # {_c(prov)}",
                 f"  index_period_end_dt   = '{s1}',   # {_c(prov)}"]
    if "enrl_gap" in ex:
        n, prov = ex["enrl_gap"]
        args.append(f"  max_enrl_gap = {n},   # {_c(prov)}")
    if b and b["events"]:
        for event, argmap in sorted(b["events"].items()):
            inner = ", ".join(f"{a} = {_rvar(t)}" for a, t in sorted(argmap.items()))
            args.append(f"  {event} = list({inner}),   # bindings file, sha[:16] "
                        f"{b['sha256'][:16]}")
    for i in range(len(args) - 1, -1, -1): # R refuses a trailing comma before ')'
        if "   #" in args[i]:
            code, _, comment = args[i].partition("   #")
            args[i] = code.rstrip().rstrip(",") + "    #" + comment
            break
    if lifted:
        L.append("# --- code lists, lifted verbatim from their tabs (recognised by SHAPE - a")
        L.append("# `code` column - never by tab name). The bindings file (a reviewed YAML)")
        L.append("# ties each vector to its study_specs event; unbound vectors are gaps.")
        for sheet, v in lifted.items():
            L.append(f"{_rvar(sheet)} <- c(   # tab {_c(sheet)!r}: {len(v['codes'])} code(s)")
            for e in v["codes"]:
                note = " / ".join(_c(e[k]) for k in ("type", "description") if e.get(k))
                L.append(f" '{e['code']}',{'   # ' + note if note else ''}")
            L[-1] = L[-1].replace("',", "'", 1) if L[-1].lstrip().startswith("'") else L[-1]
            L.append(")")
        L.append("")
    L += ["specs <- study_specs(", *args, ")", ""]
    for sheet, headers in sorted(tabs["unread"].items()):
        L.append(f"# tab {_c(sheet)!r}: not a recognised code-list shape (headers: "
                 f"{_c(', '.join(headers))[:100]}) - NOT read; if it is a code list, its "
                 f"header needs a 'code' column")
    for g in guards:
        L.append(f"# GAP: {_c(g)}")
    if guards:
        L += [f"stop('{len(guards)} GAP(S) ABOVE ARE UNRESOLVED - this draft refuses to run until ",
              "     each is lifted from a governed source or translated by a person.')", ""]
    else:
        L += ["# No blocking gaps: every value above carries its workbook row, every code list",
              "# is bound through the reviewed bindings file, and every criterion lifted whole.",
              "stop('UNGOVERNED DRAFT (probe wave 17): no signed decision stands behind these ",
              "     values. A PERSON deletes this line after review, or runs the manifest ",
              "     through cohortly_manifest.R with an explicit allow_ungoverned - a script ",
              "     with no governance stop must not roll toward a database by default.')", ""]
    L += ["df <- prepare_master_data(con = db_connect(), study_specs = specs,",
          "                          tbl_name = '', generate_summary = FALSE)", ""]
    for c in ex["criteria"]:
        L.append(f"# {_c(c['key'])} ({c['kind']}): {_c(c['definition'])[:140]}")
        if c["call"]:
            fn, kw = c["call"]
            if c.get("conversion"):
                L.append(f"# window derivation: {_c(c['conversion'])}")
            L.append(f"df <- df |> {fn}({_r_args(kw)})")
        else:
            L.append(f"# GAP (BLOCKING, counted in the stop above): {_c(c['gap'])}")
        L.append("")
    L += ["final <- df |> finalize_cohort()",
          "pull_attrition(final)   # ingested by the platform as release evidence",
          "pull_cohort(final)"]
    return "\n".join(L) + "\n"


# The manifest's first line digests its own body, and the R loader recomputes it before
# reading a single value. This is INTEGRITY, not authenticity - it proves the file executed is
# the file rendered, byte for byte; it cannot prove who rendered it (that needs signing keys,
# an organisation-side control). Before it, a hand-edited manifest - a code list trimmed, a
# window widened, a duplicate key injected for last-wins parsing - executed exactly as if the
# exporter had written it.
INTEGRITY_PREFIX = "# content_sha256: "


def seal_manifest(text):
    """(sealed_text, digest): the manifest body prefixed with the digest of its own bytes."""
    body = text if text.endswith("\n") else text + "\n"
    digest = hashlib.sha256(body.encode("utf-8")).hexdigest()
    return f"{INTEGRITY_PREFIX}{digest}\n{body}", digest


def manifest_integrity_errors(path):
    """[] when the first line digests the remaining bytes; the reasons otherwise.

    CRLF is normalised before hashing on both sides, so a checkout that rewrote line endings
    does not read as tampering - the content is what is sealed, not the newline convention."""
    with open(path, "rb") as fh:
        raw = fh.read()
    text = raw.decode("utf-8").replace("\r\n", "\n")
    first, _, body = text.partition("\n")
    if not first.startswith(INTEGRITY_PREFIX):
        return [f"{path}: no content_sha256 header - an unsealed manifest cannot show it is "
                f"the one the exporter rendered; regenerate it, never hand-write it"]
    want = first[len(INTEGRITY_PREFIX):].strip()
    got = hashlib.sha256(body.encode("utf-8")).hexdigest()
    if want != got:
        return [f"{path}: content_sha256 mismatch - the manifest changed after it was "
                f"rendered. Regenerate it from the workbook; a manifest is never edited."]
    return []


def manifest(name, tabs, ex, digest, b=None):
    """The extracted spine as neutral data, and the repository ships its own reader:
    platform/engine-r/cohortly_manifest.R loads this YAML and hands cohortly its
    study_specs() call - refusing FIRST while blocking_gaps stand, taking db/data_refresh
    from the caller, stripping the _provenance keys. The EXTRACTION bridge is complete in this
    repository; a governed claims validation and release path is NOT, so an emitted manifest is
    UNGOVERNED until one exists. Same extraction as the R script - values,
    provenance, gaps and blocking guards - one extraction, two renderings, so they cannot
    disagree about the workbook."""
    m = {"manifest_version": 1,
         "modality": "claims - cohortly executes on Optum/MarketScan; this is not an EHR "
                     "path and the platform's ADS engine never reads it",
         "workbook": os.path.basename(str(name)), "workbook_sha256": digest,
         "rendered": datetime.date.today().isoformat(),
         "governance": "UNGOVERNED - no signed decision stands behind any value; "
                       "regenerate from the pack once the workbook passes Gate 1-2",
         "loader": "platform/engine-r/cohortly_manifest.R (this repository) - "
                   "cohortly_specs_from_manifest(path, db, data_refresh) refuses while "
                   "blocking_gaps below are non-empty",
         "cohortly_version": "not pinned - verify the interface against the installed package",
         "study_specs": {}, "criteria": [],
         "code_lists": {s: {"count": len(v["codes"]), "codes": v["codes"]}
                        for s, v in sorted(tabs["lists"].items())},
         "events": {event: {arg: {"tab": t,
                                  "codes": [e["code"] for e in tabs["lists"][t]["codes"]]}
                            for arg, t in sorted(argmap.items())}
                    for event, argmap in sorted((b["events"] if b else {}).items())},
         "bindings_sha256": b["sha256"] if b else None,
         "unread_tabs": dict(sorted(tabs["unread"].items())),
         "blocking_gaps": _guards(tabs, ex, b)}
    if "study" in ex:
        m["study_specs"]["study_period_start_dt"], m["study_specs"]["study_period_end_dt"] = \
            ex["study"][0], ex["study"][1]
        m["study_specs"]["_provenance_study"] = ex["study"][2]
    if "index" in ex:
        m["study_specs"]["index_period_start_dt"], m["study_specs"]["index_period_end_dt"] = \
            ex["index"][0], ex["index"][1]
        m["study_specs"]["_provenance_index"] = ex["index"][2]
    if "enrl_gap" in ex:
        m["study_specs"]["max_enrl_gap"] = ex["enrl_gap"][0]
        m["study_specs"]["_provenance_gap"] = ex["enrl_gap"][1]
    for c in ex["criteria"]:
        fn, kw = c["call"] if c["call"] else (None, None)
        entry = {"row": c["key"], "kind": c["kind"], "definition": c["definition"],
                 "call": {"fn": fn, "args": dict(kw)} if fn else None, "gap": c["gap"]}
        if c.get("conversion"):
            entry["conversion"] = c["conversion"]
        m["criteria"].append(entry)
    return m


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    ap.add_argument("workbook", help="path to a Program Specification workbook (.xlsx)")
    ap.add_argument("--out", help="write the draft R script here - refused inside the checkout")
    ap.add_argument("--manifest", help="also write the spine as neutral YAML - loaded by this "
                                       "repository's own platform/engine-r/cohortly_manifest.R; "
                                       "refused inside the checkout for the same reason")
    ap.add_argument("--pack", help="a registered pack directory this workbook belongs to; its "
                                   "registry entry must declare modality: claims - the identity "
                                   "boundary, so an EHR pack cannot walk out through the claims "
                                   "door by mistake")
    ap.add_argument("--bindings", help="a reviewed YAML tying lifted code-list tabs to "
                                       "study_specs events, trace calls to their events, and "
                                       "naming the tabs reviewed as carrying no cohort rules - "
                                       "the GOVERNED way to clear the EVENTS and unread-tab "
                                       "gaps; a person authors and commits it, never a tool")
    a = ap.parse_args(argv)
    if not os.path.isfile(a.workbook):
        sys.exit(f"{a.workbook}: no such workbook. Nothing was rendered - a refusal, not a draft.")
    if a.pack:
        # identity refuses before evidence, same as role: the registry says what the pack IS,
        # and this door only opens for claims. A loose workbook (no --pack) stays exportable as
        # the UNGOVERNED draft path; naming a pack claims the registration, so it is checked.
        from rwd_tools import product_gates as pg # noqa: PLC0415
        rel = repo_relative(os.path.realpath(a.pack), os.path.realpath(ROOT))
        entry = pg.registry_entry(ROOT, rel)
        if entry is None:
            sys.exit(f"--pack {a.pack}: no registry entry owns this path - register the pack "
                     f"(with modality: claims) or export the workbook without --pack as the "
                     f"ungoverned draft it is.")
        modality, bad = pg.pack_modality(entry)
        if bad:
            sys.exit(f"--pack {a.pack}: {bad}")
        if modality != "claims":
            sys.exit(f"--pack {a.pack}: registered modality is {modality!r} - this pack's "
                     f"executor is the ADS engine, and a cohortly draft for it would be a "
                     f"claims script with no claims behind it. The registry declaration is "
                     f"the door; a person changes it, tools do not.")
    spine, tabs, digest = read_workbook(a.workbook)
    ex = extract(spine)
    b = None
    if a.bindings:
        if not os.path.isfile(a.bindings):
            sys.exit(f"--bindings {a.bindings}: no such file")
        b = load_bindings(a.bindings, tabs, ex)
    apply_bindings(ex, b)
    lifted = sum(1 for c in ex["criteria"] if c["call"])
    ncodes = sum(len(v["codes"]) for v in tabs["lists"].values())
    print(f"{os.path.basename(a.workbook)}: study={'study' in ex} index={'index' in ex} "
          f"gap={'enrl_gap' in ex} criteria={len(ex['criteria'])} (lifted {lifted}) "
          f"code lists={len(tabs['lists'])} ({ncodes} codes) unread tabs={len(tabs['unread'])} "
          f"events bound={len(b['events']) if b else 0} "
          f"blocking gaps={len(_guards(tabs, ex, b))}")
    if not a.out and not a.manifest:
        sys.exit("give --out <file outside the checkout> (and/or --manifest). The draft "
                 "belongs to the study repository, not to this one.")
    root_real = os.path.realpath(ROOT)
    for flag, target in (("--out", a.out), ("--manifest", a.manifest)):
        # realpath BOTH sides: an abspath check waves through a junction/symlink whose target
        # is the checkout, and confinement that can be aliased around is not confinement
        if target and (os.path.realpath(target) + os.sep).startswith(root_real + os.sep):
            sys.exit(f"{flag} {target} is inside the checkout - the generated material is "
                     f"another repository's, and a committed copy is free to go stale.")
    if a.out and a.manifest and os.path.realpath(a.out) == os.path.realpath(a.manifest):
        sys.exit("--out and --manifest name the same file - the second write would silently "
                 "destroy the first output (probe wave 16)")

    def _write(target, text):
        # atomic, staged through mkstemp (probe wave: even a PID suffix is PREDICTABLE, so a
        # caller could name one output as the other's staging file and watch it vanish under
        # os.replace - mkstemp's name is random AND created exclusively, so it can never be
        # a path anything else already owns or expects)
        import tempfile as _tempfile # noqa: PLC0415
        final = os.path.realpath(target)
        fd, tmp = _tempfile.mkstemp(dir=os.path.dirname(final),
                                    prefix=os.path.basename(final) + ".staging.")
        with os.fdopen(fd, "w", encoding="utf-8", newline="\n") as fh:
            fh.write(text)
        os.replace(tmp, final)
        print(f"wrote {final}")

    if a.out:
        _write(a.out, render(a.workbook, tabs, ex, digest, b))
    if a.manifest:
        import yaml # noqa: PLC0415
        sealed, _d = seal_manifest(yaml.safe_dump(manifest(a.workbook, tabs, ex, digest, b),
                                                  sort_keys=False, allow_unicode=True, width=100))
        _write(a.manifest, sealed)
    # the exit code is the machine-readable verdict (probe wave: a gapped draft exited 0 and
    # automation read success as runnable): 0 = written AND gap-free; 2 = written, BLOCKED.
    remaining = _guards(tabs, ex, b)
    if remaining:
        print(f"exit 2: {len(remaining)} blocking gap(s) - the draft is written and "
              f"UNRUNNABLE; automation must treat this as blocked, not as success")
        return 2
    return 0


if __name__ == "__main__":
    from rwd_tools.console import use_utf8
    use_utf8()
    sys.exit(main())
