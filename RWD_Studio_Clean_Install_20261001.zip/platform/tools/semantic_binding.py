#!/usr/bin/env python3
"""Which concepts a data product means — declared by the pack, imported from the base layers.

    python3 platform/tools/semantic_binding.py <pack>            # what this pack binds
    python3 platform/tools/semantic_binding.py <pack> --draft    # candidates for a person to rule
    python3 platform/tools/semantic_binding.py <pack> --check    # exit 1 on a binding that resolves
                                                                 # to nothing

WHAT WAS MISSING. Three concept layers exist and NOTHING joins them to a data product:
`TERMINOLOGY.json` (2,670 concepts), `RELATIONS.json` (167k edges) and `LOCAL_RELATIONS.yaml`
(what a person asserts). No pack config names a CUI, a concept set or a LOINC code — so
`semantic_export` derives a pack's concepts by INFERRING from which config blocks happen to exist.
Inference is not a declaration: "we never bound this variable" and "there is nothing to bind it to"
look identical, and neither is countable.

IMPORT, NEVER COPY. A binding names concepts that live in the base layers; it does not restate
them. So a UMLS release bump flows through instead of orphaning a snapshot, and thirteen tumours
cannot drift into thirteen private meanings of "biomarker". Anything genuinely new goes through
`governance/NAME_LIFECYCLE.yaml`, which is the mint-once register.

THE MACHINE PROPOSES AND IS WRONG OFTEN ENOUGH TO MATTER. Of prostate's 50 overlay variables, six
resolve to exactly one UMLS concept by name — and one of those six is `TSST`, which the terminology
layer matches to "Trier Social Stress Test". The pack's own inventory defines it as "Time to SECOND
subsequent therapy (to line N+2 start or death) ... the house PFS2-style durability proxy beside
TTNT": a time-to-event OUTCOME, matched to a psychology stress test. A one-in-six false-positive
rate is why `--draft` prints candidates for review and nothing here writes a binding. The same
reason `mcode_crosswalk` proposes and `EQUIVALENCE_RULINGS.yaml` rules.

UNBOUND IS COUNTED, NOT HIDDEN. A pack that binds four of fifty variables says so. The number is
the point: it is the distance between what this programme publishes and what it can say the meaning
of, and a binding layer that reported only its successes would hide exactly that.
"""
from __future__ import annotations

import argparse
import json
import os
import sys

TOOLS = os.path.dirname(os.path.abspath(__file__))
from rwd_services import workspace_root
ROOT = str(workspace_root(__file__))

from rwd_tools import registry_schema as rs                                                 # noqa: E402
from rwd_tools import umls_relations as ur                                                 # noqa: E402
from rwd_tools import variables_scaffold as vs                                             # noqa: E402

REFERENCE = os.path.join(ROOT, "governance", "reference")
TERMINOLOGY = os.path.join(REFERENCE, "umls", "TERMINOLOGY.json")
MCODE_CODES = os.path.join(REFERENCE, "mcode_stu4", "VALUE_SET_CODES.json")
INVENTORY = os.path.join(REFERENCE, "variable_inventory", "INVENTORY.yaml")

BINDING_NAME = os.path.join("config", "semantic.yaml")

# A BINDING IS MARKED, NEVER DELETED — the same rule concept-set members follow, and for the
# same reason. Deleting the line loses the fact that a meaning was once stated, so an analysis run
# against an earlier cut cannot be read back. The three states are `umls_relations.MEMBER_STATES`,
# imported rather than restated so they cannot drift apart:
#
#   active      this pack states this meaning. The default, so an unmarked binding still binds.
#   not_used    bound, and deliberately out of scope for this cut. Not a gap — somebody looked.
#   deprecated  was this pack's meaning and no longer is. Distinct from `not_used` because a reader
#               needs to know an earlier answer USED it.
#
# The counts keep them apart: a deprecated binding is neither `bound` (it does not state a current
# meaning) nor `uncovered` (something was stated, and a consumer of an older cut needs to see it).
BINDING_STATES = ur.MEMBER_STATES

# WHAT A VARIABLE CAN BE BOUND TO, and there are three axes rather than two. `concept` is a UMLS
# CUI and `lab` is a LOINC code mCODE binds; `registry_concept` names a slot in the oncology module
# registry, which is what a person confirms in TEMPLATE_RULINGS.yaml.
#
# ONE MANIFEST, THREE PROPOSERS. `semantic_binding --draft` proposes the first two by name match;
# `template_reconcile --propose-semantic` proposes the third from confirmed `realises` rulings. All
# three are confirmed by a person editing THIS file, all three are validated here, and all three
# ride the same release identity — which is what stops the oncology template lane from becoming a
# second semantic system that the release never hears about.
BINDING_AXES = ("concept", "lab", "registry_concept", "definition")


# WHAT A BINDING FILE MAY SAY. Nothing checked this, and the failure mode is the quiet one: a
# person writes `registry_concepts:` or `variabels:`, YAML parses it perfectly, every consumer
# reads the key it expects, finds nothing, and reports the pack as binding NOTHING. The file looks
# complete on screen and states nothing to the tools — the same defect the reconciliation schema
# was written for, on the one file whose whole content is a person's judgment.
#
# UNKNOWN KEYS ARE REFUSED rather than ignored, by `registry_schema.validate`, which is the one
# validator here; the states come from `umls_relations` so this cannot drift from the register that
# defines them.
_BINDING_RECORD = {
    "concept": rs.F("str", note="a UMLS CUI carried by TERMINOLOGY.json"),
    "lab": rs.F("str", note="a LOINC code from mCODE's VALUE_SET_CODES.json — the lab axis "
                            "exists because UMLS never relates a cancer to a lab TEST"),
    "registry_concept": rs.F("str", note="a slot in the oncology registry this variable realises"),
    "definition": rs.F("str", note="the registered analytical definition this variable carries "
                                    "(governance/DEFINITIONS.yaml) — what is measured, above where"),
    "status": rs.F("str", values=BINDING_STATES,
                   note="a binding is MARKED, never deleted; absent means active"),
}
# NEITHER KEY IS REQUIRED, DELIBERATELY. The defect this schema exists for is the UNKNOWN key —
# `registry_concepts`, `variabels` — which parses, reads as nothing, and looks complete. Whether a
# pack must STATE a concept set is a governance question with a different answer and a different
# owner, and `errors()` already rules on the set when one is named. Requiring it here would have
# turned a typo check into a policy change nobody asked for.
BINDING_SCHEMA = {
    "concept_set": rs.F("str", nullable=True,
                        note="the LOCAL_RELATIONS.yaml set this study is scoped to"),
    "variables": rs.F("map_of", nullable=True, item=_BINDING_RECORD,
                      note="variable id -> what it means"),
}


def binding_status(rec):
    """The state of one variable binding. Unmarked is `active`, so a plain mapping still binds."""
    if not isinstance(rec, dict):
        return "active"
    return str(rec.get("status") or "active")


def _json(path):
    try:
        with open(path, encoding="utf-8") as fh:
            return json.load(fh)
    except (OSError, ValueError):
        return None


def concept_names():
    """{cui: name} across BOTH base layers, so a binding may name either.

    EMPTY WHEN THE LAYER IS OFF. The callers inside this file already guard, but this is a
    PUBLIC function that opens both UMLS projections directly, so anything importing the module
    could read them whatever the licence says. A guard at each call site protects the call sites
    that were remembered.
    """
    if not umls_enabled():
        return {}
    out = {}
    rel = ur.load() or {}
    out.update(rel.get("concepts") or {})
    term = _json(TERMINOLOGY) or {}
    for cui, rec in (term.get("concepts") or {}).items():
        if cui not in out:
            labels = rec.get("labels") or []
            out[cui] = (labels[0] or {}).get("str") if labels else None
    return out


def lab_codes(path=None):
    """{LOINC code: description} for every lab test mCODE binds. The vocabulary a `lab:` names."""
    doc = _json(path or MCODE_CODES) or {}
    return {str(c.get("code")): c.get("description")
            for c in (doc.get("codes") or []) if c.get("code_system") == "LOINC"}


_INV_CACHE = {}


def _inventory():
    """The variable inventory, parsed once.

    CACHED BECAUSE THE ALIAS FIX MADE IT HOT. `pack_masters` and `aliases_by_master` both read it,
    and `errors`, `report` and `coverage` each call those — so one `--coverage` reparsed a
    350 KB YAML a dozen times and the test suite, which builds a throwaway pack per case, ran for
    minutes. Keyed on mtime so an edit during a long-lived process is still picked up.
    """
    try:
        stamp = os.path.getmtime(INVENTORY)
    except OSError:
        return {}
    if _INV_CACHE.get("stamp") != stamp:
        # THE ONE GOVERNED READER. `yaml.safe_load` here meant a duplicate key in the inventory
        # loaded last-wins and an impossible date came back as a bare ValueError — a parse
        # failure becoming a traceback out of a gate instead of a gate result.
        from rwd_tools import product_gates as _pg                                       # noqa: PLC0415
        doc, err = _pg.read_yaml(INVENTORY)
        if err:
            return {}
        _INV_CACHE["doc"] = doc or {}
        _INV_CACHE["stamp"] = stamp
    return _INV_CACHE.get("doc") or {}


def pack_variables(pack):
    """The variables this product PUBLISHES — its contract's variable_ids.

    THE POPULATION CAME FROM THE WRONG FILE, and every coverage number this tool printed described
    the wrong thing. It read the tumour overlay in `INVENTORY.yaml`, which states of itself:
    `status: reference_only` — "a drafting AID, never a specification. Nothing here authorises a
    variable into a product." For prostate that is 50 names against the contract's 202, overlapping
    on NINE. So "50 declared, 28 uncovered" was shelf coverage reported as product coverage, and
    the real uncovered number is an order of magnitude larger.

    THE CONTRACT IS THE GOVERNED POPULATION: a variable is in the product when the approved
    workbook put it there, which is what the functional contract records.
    """
    return _contract_variables(pack)[0]


def _contract_variables(pack):
    """(variable ids, problem) — the governed population, and why it is empty when it is.

    THE REASON IS RETURNED, NOT SWALLOWED. This caught every exception and returned an empty set,
    and `errors()` then validated a binding only `if known_vars` — so an absent or unparseable
    contract did not fail the pack, it DISABLED the check that says a binding names a real
    variable. An unreadable contract is the one state in which arbitrary bindings must not pass.

    An empty set with no problem is a legitimate answer: a pack whose contract parses and declares
    nothing. That is different from a contract nobody could read, and the two must not return alike.
    """
    path = os.path.join(pack, "handoff", "FUNCTIONAL_CONTRACT.md")
    if not os.path.exists(path):
        return set(), (f"{os.path.relpath(path, pack)} does not exist — the governed population "
                       f"is unknown, so a binding cannot be checked against it")
    try:
        from rwd_tools import contract_lint as cl                                        # noqa: PLC0415
        out = set()
        for block in cl.records(cl.read(path)):
            vid = cl._scalar(block, "variable_id")
            if vid:
                out.add(str(vid))
        return out, None
    except Exception as e:                                                # noqa: BLE001
        return set(), (f"{os.path.relpath(path, pack)} could not be read ({e.__class__.__name__}: "
                       f"{e}) — the governed population is unknown, so a binding cannot be checked "
                       f"against it")


def pack_masters(pack):
    """{variable name: master family} from the reference overlay, for the names it happens to name.

    THE OVERLAY IS A DRAFTING AID, not the population — see `pack_variables`. It is still the
    only place that says which master family a name belongs to, which is what the alias pooling
    needs, so it is read for THAT and never for who is in the product. For prostate it names 9 of
    the contract's 202.
    """
    slug = os.path.basename(os.path.dirname(os.path.abspath(pack)))
    # registry tumour_key first (slug is the PRODUCT - dlbcl_optum_claims
    # must index the dlbcl overlay), then the shared mapping
    from rwd_tools import product_gates as _pg                                          # noqa: PLC0415
    _tkey = _pg.tumour_key_for(ROOT, slug) or vs.SLUG_TO_OVERLAY.get(slug, slug)
    overlay = (_inventory().get("tumours") or {}).get(_tkey) or {}
    return {str(v["name"]): (str(v.get("master")) if v.get("master") else None)
            for v in (overlay.get("variables") or []) if v.get("name")}


def aliases_by_master():
    """{master family: {(tumour slug, variable name)}} across EVERY overlay.

    THIS IS NOT A SAFE POOL ON ITS OWN — see `fanout_masters`. A shared `master:` means the
    variables have one SHAPE, not necessarily one meaning.
    """
    out = {}
    for slug, body in (_inventory().get("tumours") or {}).items():
        for v in ((body.get("variables") if isinstance(body, dict) else body) or []):
            if isinstance(v, dict) and v.get("name") and v.get("master"):
                out.setdefault(str(v["master"]), set()).add((str(slug), str(v["name"])))
    return out


def fanout_masters():
    """Masters whose aliases are DIFFERENT constructs, not spellings of one.

    THE ERROR THIS EXISTS TO STOP, made and caught. Pooling every alias of a master looked
    obviously right for `ECOG_PS`, where prostate says `ECOG` and dlbcl says `ECOG_PS` and both
    mean one scale. It is obviously wrong for `GENE_VARIANT_STATUS`, which carries 33 aliases
    across 12 tumours — `KRAS_MUT`, `JAK2_V617F`, `DEL_17P`, `EGFR_MUT`, `BRCA12` — one variable
    SHAPE holding different genes. Pooling those makes prostate's BRCA12 resolvable through
    myelofibrosis's JAK2, which is the cross-product the relations layer already had to unlearn.

    THE TELL IS FAN-OUT WITHIN ONE TUMOUR. A construct appears at most once per tumour: a pack has
    one ECOG, one age, one death date. A shape appears many times: prostate declares BRCA12 AND
    AR_ALT, cll declares six. So a master with two aliases in any single tumour is a shape, and its
    aliases are never pooled — the same reasoning `definition_signature` uses when it resolves a
    panel entry to the ONE inventory variable it corresponds to rather than iterating the family.
    """
    per_tumour = {}
    for master, pairs in aliases_by_master().items():
        counts = {}
        for slug, _name in pairs:
            counts[slug] = counts.get(slug, 0) + 1
        if any(n > 1 for n in counts.values()):
            per_tumour[master] = max(counts.values())
    return per_tumour


def read(pack):
    """(binding, [problem]) for one pack. A missing file is an EMPTY binding, not an error.

    A pack that has never bound anything is the ordinary state today; saying so is different from
    failing, and different again from a binding that names things which do not resolve.
    """
    path = os.path.join(pack, BINDING_NAME)
    if not os.path.exists(path):
        return {}, []
    from rwd_tools.product_gates import read_yaml                                   # noqa: PLC0415
    doc, err = read_yaml(path)
    if err:
        return {}, [f"{BINDING_NAME}: {err}"]
    # A FILE THAT DOES NOT VALIDATE IS NOT A BINDING, and is returned as one — empty, with the
    # reason — rather than half-read. Every caller below iterates `variables`; handing them a
    # document whose shape was never checked is how a typo becomes "this pack binds nothing".
    problems = rs.validate(BINDING_SCHEMA, doc or {}, BINDING_NAME)
    if problems:
        return {}, problems
    return doc or {}, []


def errors(pack):
    """Why a pack's binding does not resolve into the base layers, or [].

    EVERY REFUSAL IS ABOUT RESOLUTION, never about judgment. Whether `PSA` should be bound to LOINC
    10508-0 is a person's call and nothing here has an opinion; whether 10508-0 IS a code mCODE
    binds is a fact, and a binding that names one it does not is unusable in every consumer.
    """
    doc, out = read(pack)

    # AN UNSIGNED CLAIM OF MEANING. Every check below asks whether a binding RESOLVES; this asks
    # whether anybody accountable said it was right. The file carried no approval record at all, so
    # its only teeth were the release digests - which record that a meaning was stated, not that it
    # was agreed.
    from rwd_tools.product_gates import semantic_approval_errors                    # noqa: PLC0415
    out += semantic_approval_errors(pack)

    if not doc:
        return out
    # THE UMLS FILES ARE NOT OPENED UNLESS SOMETHING ACTUALLY BINDS A CUI, AND NOT THEN IF THE
    # LAYER IS OFF. `concept_names()` was called unconditionally here, which made the switch a
    # reporting preference rather than a kill switch: a deployment WITHOUT the UMLS artifacts
    # (no licence, or a deliberate comparison isolating what mCODE alone can do) still had this
    # validator reach for TERMINOLOGY.json and RELATIONS.json on every call.
    #
    # The other two axes never needed UMLS and still do not: `lab` resolves against mCODE's
    # VALUE_SET_CODES.json and `registry_concept` against the oncology registry. Only the CUI
    # axis is UMLS's, which is what makes a genuine no-UMLS mode possible at all.
    consulted = umls_enabled()
    names = None                      # loaded on the first CUI, and only when the layer is on
    labs = lab_codes()
    known_vars, contract_problem = _contract_variables(pack)

    setname = str(doc.get("concept_set") or "").strip()
    if setname and not setname.upper().startswith("TODO"):
        sets, probs = ur.concept_sets()
        out += [f"{BINDING_NAME}: {p}" for p in probs]
        if not any(str(s.get("name")) == setname for s in sets):
            out.append(f"{BINDING_NAME}: concept_set {setname!r} is not recorded in "
                       f"LOCAL_RELATIONS.yaml — a set that names nothing scopes nothing")

    for var, rec in sorted((doc.get("variables") or {}).items()):
        if not isinstance(rec, dict):
            out.append(f"{BINDING_NAME}: {var} must be a mapping of what it binds")
            continue
        if contract_problem:
            # FAIL CLOSED. Without this the check simply switched itself off when the contract
            # could not be read, which is the moment it is load-bearing.
            out.append(f"{BINDING_NAME}: {var} cannot be checked — {contract_problem}")
        elif var not in known_vars:
            out.append(f"{BINDING_NAME}: {var} is not a variable this pack's contract declares — "
                       f"binding a name nothing publishes is a claim about nothing")
        st = binding_status(rec)
        if st not in BINDING_STATES:
            out.append(f"{BINDING_NAME}: {var} has status {st!r}, not one of {BINDING_STATES}")
        cui = str(rec.get("concept") or "").strip()
        if cui and not cui.upper().startswith("TODO"):
            # ASSERTED ONLY. `st` was read three lines up and then never consulted here, so the
            # refusal below fired for EVERY stated CUI — including one already parked, which is
            # the very thing its own diagnostic instructs the reader to do. Following the printed
            # remedy produced the identical error, leaving a pack bound for a UMLS-free
            # deployment no way to keep an existing binding on record: "mark, never delete" could
            # not be walked. `ur.IN_SCOPE` is the single definition of asserted, shared with the
            # concept-set lifecycle so the two cannot drift apart.
            if not consulted and st not in ur.IN_SCOPE:
                pass                    # on record, deliberately not asserted - nothing to resolve
            elif not consulted:
                # PARKED OR REFUSED, NEVER SILENTLY HONOURED. A CUI binding states a meaning
                # that only the UMLS layer can resolve, so in a deployment where that layer is
                # declared off it resolves to nothing — and reporting it as fine would publish a
                # meaning no consumer here can follow. `status: not_used` is the way to keep the
                # binding on record without asserting it.
                out.append(f"{BINDING_NAME}: {var} binds UMLS concept {cui} and the terminology "
                           f"layer is declared OFF in LAYER.yaml. Park it (status: not_used), "
                           f"bind it on an axis this deployment carries (lab / "
                           f"registry_concept), or enable the layer")
            else:
                if names is None:
                    names = concept_names()
                if cui not in names:
                    out.append(f"{BINDING_NAME}: {var} binds concept {cui} which neither base "
                               f"layer carries — it would resolve to nothing in every consumer")
        code = str(rec.get("lab") or "").strip()
        if code and not code.upper().startswith("TODO") and code not in labs:
            out.append(f"{BINDING_NAME}: {var} binds lab {code!r}, which is not a LOINC code mCODE "
                       f"binds. The vocabulary is VALUE_SET_CODES.json")
        # THE DEFINITION AXIS (programme item 2): the id must be registered and current, and
        # must be the one this pack's own configuration signs for that family — a binding that
        # says v2 over a configuration that signs v1 states a meaning the build does not carry.
        did = str(rec.get("definition") or "").strip()
        if did and not did.upper().startswith("TODO"):
            from rwd_tools import definition_registry as _dr                                # noqa: PLC0415
            _root = _dr.checkout_root(pack)
            entries, reg_problems = _dr.read(_root)
            if reg_problems:
                out.append(f"{BINDING_NAME}: {var} binds definition {did} and the register cannot be read — {reg_problems[0]}")
            else:
                ids = {str(e.get("definition_id")) for e in entries}
                live = {str(e.get("definition_id")) for e in _dr.current(entries)}
                if did not in ids:
                    out.append(f"{BINDING_NAME}: {var} binds definition {did!r}, which governance/DEFINITIONS.yaml "
                               f"does not register — register it first (definition_registry.py --propose)")
                elif did not in live:
                    out.append(f"{BINDING_NAME}: {var} binds definition {did}, which is superseded — bind the "
                               f"current version, or say in the register why this cut keeps the old one")
                else:
                    try:
                        from rwd_tools.spec_extract import repo_relative as _rr           # noqa: PLC0415
                        signed_here = _dr.resolve(_rr(pack, _root), _root)
                    except Exception as _e:                                 # noqa: BLE001
                        signed_here = {}
                        out.append(f"{BINDING_NAME}: {var} binds definition {did} and the pack's signatures could not be read ({_e})")
                    master = did.split(":")[1] if did.count(":") == 2 else ""
                    got = signed_here.get(master)
                    if got is not None and got != did:
                        out.append(f"{BINDING_NAME}: {var} binds definition {did} but this pack's configuration signs "
                                   f"{got} for {master} — the binding and the build disagree")
        slot = str(rec.get("registry_concept") or "").strip()
        if slot and not slot.upper().startswith("TODO"):
            # THE SAME RULE AS THE OTHER TWO AXES: whether this variable SHOULD be that concept is
            # a person's call and nothing here has an opinion; whether the registry assembles that
            # slot for this cancer at all is a fact, and a binding naming one it does not is
            # unusable in every consumer.
            known, why = registry_slots(pack)
            if why:
                out.append(f"{BINDING_NAME}: {var} binds registry_concept {slot!r} and it cannot "
                           f"be checked — {why}")
            elif slot not in known:
                out.append(f"{BINDING_NAME}: {var} binds registry_concept {slot!r}, which the "
                           f"registry does not assemble for this cancer. The template is what "
                           f"`template_reconcile.py <pack>` reports")
    return out


def publishable(pack):
    """({variable: record}, [why not]) — the bindings a consumer may PUBLISH, and one rule for it.

    THERE WERE TWO ANSWERS TO THE SAME QUESTION AND THEY DISAGREED. Release validation asked
    `errors()`, which checks approval, schema and RESOLUTION — does this CUI exist, is that a
    LOINC code mCODE binds, does the registry assemble that slot for this cancer. The exporter
    asked its own shorter list: approved, and schema-valid. So a SIGNED binding naming a concept
    nothing carries passed the exporter and was refused by the release path, and the standalone
    graph could publish a meaning that resolves nowhere.

    The four conditions are one operation, stated once:

        APPROVED   a named clinician signed it, pinning both digests
        CURRENT    the signature covers what the file says NOW
        VALID      the document matches BINDING_SCHEMA
        RESOLVABLE every axis names something a base layer actually carries

    Callers that publish (`semantic_export`), package, or report should ask THIS, so that adding
    a fifth condition adds it everywhere rather than in whichever caller is remembered.
    """
    problems = errors(pack)
    if problems:
        return {}, problems
    doc, read_problems = read(pack)
    if read_problems:                 # belt and braces: `errors` reads too, and may change
        return {}, read_problems
    return ({v: r for v, r in (doc.get("variables") or {}).items() if isinstance(r, dict)}, [])

def registry_slots(pack):
    """(set of slot names, why-not) — what the oncology registry assembles for this pack's cancer.

    LAZY AND FORGIVING OF ABSENCE, deliberately. Most packs have no registry_concept binding and
    should not pay to load the module tree; a pack outside the catalogue cannot be checked and says
    so rather than refusing, because "the registry does not cover this cancer" is a fact about the
    registry and not a defect in the pack's binding.
    """
    try:
        from rwd_tools import oncology_registry as reg                                   # noqa: PLC0415
        from rwd_tools import template_reconcile as tr                                   # noqa: PLC0415
    except Exception as exc:                                              # noqa: BLE001
        return set(), f"the registry could not be loaded ({exc.__class__.__name__})"
    slug, problems = tr.pack_cancer(pack)
    if not slug:
        return set(), (problems[0] if problems else "this pack declares no cancer")
    if slug not in reg.catalogue():
        return set(), f"{slug!r} is not in the registry catalogue"
    return {reg.slot_name(e) for e in reg.assemble(slug)}, None


def report(pack):
    """What this pack binds, and — the number that matters — what it does not."""
    doc, probs = read(pack)
    declared = pack_variables(pack)
    stated = {v: r for v, r in (doc.get("variables") or {}).items()
              if isinstance(r, dict) and any(
                  str(r.get(k) or "").strip() and not str(r.get(k)).upper().startswith("TODO")
                  for k in BINDING_AXES)}
    bound = {v: r for v, r in stated.items() if binding_status(r) == "active"}
    parked = {v: binding_status(r) for v, r in stated.items() if binding_status(r) != "active"}
    return {
        "pack": pack,
        # NAMED, NOT SUBTRACTED. A binding that is `deprecated` or `not_used` states neither a
        # current meaning nor an absent one, and folding it into either count loses which.
        "parked": parked,
        "concept_set": doc.get("concept_set"),
        "variables_declared": len(declared),
        "variables_bound": len(bound),
        "variables_bound_names": sorted(bound),
        # ABSTENTION IS THE RESULT. This is the distance between what the pack publishes and what
        # it can state the meaning of, and a report that showed only successes would hide it.
        "variables_unbound": max(len(declared) - len(bound), 0),
        # ...AGAINST WHICH POPULATION. `variables_declared` is the contract's governed row count
        # and the right denominator for "has this requirement been given a meaning". It is the
        # WRONG one for "how much of the ADS is described": 19 of prostate's 202 rows are on no
        # output surface at all and 15 more are internal. Reported per surface, and they overlap
        # by design.
        "by_surface": _surface_coverage(pack, bound, parked),
        "problems": probs + errors(pack),
    }


def umls_enabled():
    """Whether the UMLS layer may be consulted. Declared in reference/umls/LAYER.yaml.

    READ THROUGH `umls_subset`, which owns the layer, rather than re-reading the declaration here
    — two readers of one switch is how the answer starts depending on which command you ran, and
    this file has already had that bug once with the candidate lookup.
    """
    try:
        from rwd_tools import umls_subset as us                                          # noqa: PLC0415
        return us.enabled()
    except Exception:                                                     # noqa: BLE001
        # A READER THAT FAILED IS NOT A POLICY THAT SAID YES. This returned True, so an import
        # error, a permission error or a corrupt module — every way of FAILING TO ASK — granted
        # permission to consult a licensed layer. The switch was made fail-closed for exactly
        # this reason and then re-opened here, one frame above it.
        return False


def candidates(pack):
    """{variable: {candidate CUI}} for every variable this product publishes. ONE lookup.

    `coverage` and `draft` each had their own and disagreed about real variables, so the bucket a
    reviewer saw depended on which command they ran. Extracted so that cannot happen again.
    """
    if not umls_enabled():
        # THE LAYER IS OFF, so there are no candidates — which is not the same as there being none
        # to find. `coverage` turns this into `not_consulted` rather than `uncovered`; see there.
        return {}
    slug = os.path.basename(os.path.dirname(os.path.abspath(pack)))
    term = _json(TERMINOLOGY) or {}
    by_origin = {}
    for handle, e in (term.get("programme_handles") or {}).items():
        for origin in e.get("origins") or []:
            by_origin.setdefault(str(origin), (handle, e))
    masters = pack_masters(pack)
    by_master = aliases_by_master()
    fanout = fanout_masters()
    out = {}
    for var in pack_variables(pack):
        master = masters.get(var)
        keys = [f"{slug}:{var}"]
        # POOL ONLY WHERE THE ALIASES ARE ONE CONSTRUCT. A fan-out master is one variable SHAPE
        # holding different things — pooling `GENE_VARIANT_STATUS` would resolve prostate's BRCA12
        # through myelofibrosis's JAK2.
        if master:
            keys.append(f"master:{master}")
            if master not in fanout:
                keys += [f"{s2}:{v2}" for s2, v2 in sorted(by_master.get(master) or ())]
        cuis = set()
        for k in keys:
            hit = by_origin.get(k)
            if hit:
                cuis |= {str(c) for c in (hit[1].get("concepts") or [])}
        out[var] = cuis
    return out


def _surface_coverage(pack, bound, parked):
    """{surface: {declared, bound, parked, unbound}} for one pack, plus `no_surface`.

    A ROW IS ON SEVERAL SURFACES AT ONCE and the counts therefore do not sum to the contract
    total. That is the honest shape: `published` and `ads_configured` overlap heavily, and
    collapsing them into one number is what produced "0 of 202" as an ADS coverage figure.
    """
    try:
        from rwd_tools import registry_schema as _rs                                     # noqa: PLC0415
        from rwd_tools import template_reconcile as _tr                                  # noqa: PLC0415
        rows, _probs = _tr.contract_rows(pack)
    except Exception:                  # noqa: BLE001
        return {}                      # an unreadable contract is reported by `declared` already

    out = {}
    for surface in tuple(_rs.SURFACES) + ("no_surface",):
        if surface == "no_surface":
            here = [r for r in rows
                    if not _rs.row_surfaces(r.get("role"), r.get("ads"))]
        else:
            here = [r for r in rows
                    if surface in _rs.row_surfaces(r.get("role"), r.get("ads"))]
        ids = {str(r.get("variable_id") or "").strip() for r in here}
        ids.discard("")
        out[surface] = {
            "declared": len(ids),
            "bound": len(ids & set(bound)),
            "parked": len(ids & set(parked)),
            "unbound": len(ids - set(bound) - set(parked)),
        }
    return out


def coverage(pack):
    """Where a data product and the concept layers OVERLAP, and — the two that matter — where they
    do not, in each direction.

    THE RELATIONSHIP IS TWO-WAY AND PARTIAL, which is why one number cannot describe it. A study
    uses a SUBSET of what the layers carry, and needs things the layers have never heard of. Those
    are different facts with different owners, and collapsing them into "coverage: 12%" hides both.

      `bindable`  the pack declares it AND a layer offers a concept for it. Work for a reviewer.
      `available` the layer carries it and this pack does not use it. NOT a gap — it is the shelf
                  the next tumour starts from, and reporting it as a shortfall would push somebody
                  to bind variables their study does not have.
      `uncovered` the pack declares it and NOTHING in any layer offers a concept. THE REAL GAP:
                  either a person asserts it in LOCAL_RELATIONS.yaml, or it is genuinely new and
                  goes through NAME_LIFECYCLE.yaml. Until then this programme publishes a variable
                  whose meaning it cannot state.

    `available` is deliberately not called a gap. `semantic_export.template` already makes the same
    distinction for concepts a tumour does not instantiate, and says why: an uninstantiated concept
    is "available without re-deriving it, and NOT a statement that it does not apply".
    """
    slug = os.path.basename(os.path.dirname(os.path.abspath(pack)))
    declared = pack_variables(pack)
    # BOTH HALVES WERE DISCARDED HERE — `doc` was never read again and `_probs` was dropped on
    # the floor, so a `semantic.yaml` this tool REFUSES was counted as an empty one. Every bucket
    # below would then be derived from a file nobody could parse into a binding, and the coverage
    # report would look exactly like a pack that had simply bound nothing yet. Same defect as the
    # dropped semantic identity problems: silence and agreement are not the same result.
    _doc, problems = read(pack)
    # ONE DEFINITION OF "BOUND", shared with `report` — a `deprecated` or `not_used` binding states
    # no CURRENT meaning, and counting it here while `report` parks it made the two disagree about
    # the same file.
    r_ = report(pack)
    bound = set(r_["variables_bound_names"])
    parked = r_["parked"]

    # THE SHELF IS NOT READ WHEN THE LAYER IS OFF. `candidates` is already guarded and returns
    # nothing, but this section — what the terminology holds that this pack does not use — went
    # on opening TERMINOLOGY.json regardless. In a deployment WITHOUT the artifacts that is a
    # read of a file that is not there; in one with them but no licence it is a read nobody
    # declared a right to. Off means not consulted, and `available` is then genuinely unknown
    # rather than empty.
    consulted = umls_enabled()
    term = _json(TERMINOLOGY) or {} if consulted else {}
    by_origin = {}
    for handle, e in (term.get("programme_handles") or {}).items():
        for origin in e.get("origins") or []:
            by_origin.setdefault(str(origin), (handle, e))

    cands = candidates(pack)
    bindable, uncovered, ambiguous, not_consulted = [], [], [], []
    for var in sorted(declared):
        if var in bound:
            continue                      # a human binding settles it; see `candidates`
        if not consulted and var not in parked:
            # NOT ASKED IS NOT THE SAME AS NOTHING FOUND. With the layer off every variable would
            # otherwise land in `uncovered`, which reads as "the terminology offers nothing for
            # this" — a claim nobody made. The count that matters to a reviewer is how many were
            # actually looked up, so an unconsulted variable is named separately or not at all.
            not_consulted.append(var)
            continue
        if var in parked:
            # A PARKED BINDING IS ALSO SETTLED. `deprecated` and `not_used` state no CURRENT
            # meaning, but somebody ruled on them — and this skipped only `bound`, so a parked
            # variable was reported in `parked` AND counted again as bindable, ambiguous or
            # uncovered. The four buckets are meant to partition the declared population; they did
            # not, and the arithmetic silently over-counted by the number of parked bindings.
            continue
        cuis = cands.get(var) or set()
        (uncovered if not cuis else ambiguous if len(cuis) > 1 else bindable).append(var)

    # WHAT THE SHELF HOLDS THAT THIS PACK DOES NOT USE. Counted from the resolved handles, because
    # an unresolved one is not something the layer can offer anybody.
    used_handles = {by_origin[k][0] for k in by_origin
                    if k.startswith(f"{slug}:") or k.startswith("master:")}
    resolved = {h for h, e in (term.get("programme_handles") or {}).items()
                if not e.get("ambiguous") and len(e.get("concepts") or []) == 1}
    return {
        "pack": pack,
        # ...AND SAID SO, rather than reported as zero bindings. Empty when the file is fine.
        "unreadable": problems,
        "declared": len(declared),
        "bound": len(bound),
        "parked": parked,
        "bindable": bindable,
        "ambiguous": ambiguous,
        "uncovered": uncovered,
        # WHETHER THE LAYER WAS ASKED AT ALL, and who was not asked. Empty when it was.
        "umls_consulted": consulted,
        "not_consulted": not_consulted,
        # THE ARITHMETIC, STATED SO IT CAN BE CHECKED. bound + parked + bindable + ambiguous +
        # uncovered == declared, by construction. A reader who cannot add the buckets up cannot
        # trust any one of them, and this equality is what the `continue` above buys.
        "accounted": (len(bound) + len(parked) + len(bindable) + len(ambiguous)
                      + len(uncovered) + len(not_consulted)),
        # NAMED, so `bound + bindable + ambiguous + uncovered + parked` accounts for every declared
        # variable and none is counted twice.
        "bound_names": sorted(bound),
        # WHICH POPULATION, because "0 of 202 bound" answers a question nobody asked. The
        # contract's 202 rows are the GOVERNED population and the right denominator for "has
        # this requirement been given a meaning" — but 19 of them are on no output surface at
        # all (13 excluded, 6 metadata) and 15 more are internal, so a reader taking 202 as the
        # ADS column count is reading a number that describes something else. Each surface is
        # reported with its own denominator; they OVERLAP by design, and a row is on several at
        # once.
        "by_surface": _surface_coverage(pack, bound, parked),
        "available": sorted(resolved - used_handles),
        "unresolved_in_layer": len(term.get("programme_handles_unresolved") or []),
    }


def draft(pack):
    """Candidate bindings for a person to rule on. PRINTS — nothing here writes a binding.

    A CANDIDATE IS NOT A BINDING, and the rate matters: six of prostate's fifty variables resolve
    to exactly one concept, and one of those six is `TSST` matched to "Trier Social Stress Test"
    against a variable the pack derives from a line-of-therapy table. Every line below is marked
    TODO for that reason.
    """
    # ...AND NEITHER DOES THE DRAFTER. `candidates` returns nothing with the layer off, so these
    # names could only ever label an empty list — at the cost of opening both UMLS artifacts.
    names = concept_names() if umls_enabled() else {}
    cands = candidates(pack)
    single, ambiguous, none = [], [], []
    for var in sorted(cands):
        cuis = sorted(cands[var])
        (none if not cuis else ambiguous if len(cuis) > 1 else single).append((var, cuis))
    none = [v for v, _c in none]

    out = [f"# CANDIDATES for {pack} — none of this is a binding until a person rules on it.",
           f"# {len(single)} resolve to one concept, {len(ambiguous)} are ambiguous, "
           f"{len(none)} have no handle at all.",
           "#",
           "# CHECK EVERY LINE. These come from normalised NAME matching, which is wrong often "
           "enough to matter:",
           "# prostate's TSST matches 'Trier Social Stress Test' and the pack derives it from a",
           "# line-of-therapy table and a composite death date.",
           "variables:"]
    for var, cuis in single:
        out.append(f"  {var}:")
        out.append(f"    concept: TODO   # candidate {cuis[0]} = {names.get(cuis[0])!r}")
    for var, cuis in ambiguous:
        shown = ", ".join(f"{c} = {names.get(c)!r}" for c in cuis[:3])
        out.append(f"  # {var}: AMBIGUOUS — the terminology layer elected none of {shown}")
    if none:
        out.append(f"  # {len(none)} variable(s) resolve to no concept at all: "
                   f"{', '.join(none[:8])}{' ...' if len(none) > 8 else ''}")
    return "\n".join(out) + "\n"


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    ap.add_argument("pack")
    ap.add_argument("--draft", action="store_true",
                    help="print candidate bindings for a person to rule on")
    ap.add_argument("--check", action="store_true", help="exit 1 on a binding that resolves to "
                                                         "nothing")
    ap.add_argument("--coverage", action="store_true",
                    help="where this pack and the concept layers overlap, and where neither covers "
                         "the other")
    a = ap.parse_args(argv)
    if not os.path.isdir(a.pack):
        print(f"{a.pack} is not a pack directory")
        return 1
    if a.draft:
        print(draft(a.pack))
        return 0
    if a.coverage:
        c = coverage(a.pack)
        print(f"{c['pack']}")
        print(f"  declared by the pack : {c['declared']}")
        print(f"  bound today          : {c['bound']}")
        print(f"  bindable             : {len(c['bindable'])}  a layer offers one concept "
              f"— a reviewer rules")
        print(f"  ambiguous            : {len(c['ambiguous'])}  the layer offers several and "
              f"elects none")
        print(f"  UNCOVERED            : {len(c['uncovered'])}  nothing offers a concept "
              f"— assert it locally, or mint it")
        print(f"  available (not a gap): {len(c['available'])}  the layer carries it and this "
              f"pack does not use it")
        print(f"  unresolved in layer  : {c['unresolved_in_layer']}  handles UMLS matched nothing "
              f"for, across the programme")
        for label in ("bindable", "ambiguous", "uncovered"):
            if c[label]:
                shown = ", ".join(c[label][:12])
                more = f" ... and {len(c[label]) - 12} more" if len(c[label]) > 12 else ""
                print("")
                print(f"  {label}: {shown}{more}")
        return 0
    r = report(a.pack)
    print(f"{r['pack']}")
    print(f"  concept_set       : {r['concept_set'] or '(none declared)'}")
    # "YOU HAVE NOT CHOSEN YET" AND "THERE IS NOTHING TO CHOOSE FROM" ARE DIFFERENT STATES, and
    # the report showed only the first. A reviewer reading `concept_set: TODO` goes looking for
    # the set to name and finds `concept_sets: []` in LOCAL_RELATIONS.yaml — the register is
    # empty, and asserting one is itself a scoping decision that needs `asserted_by`. Saying so
    # here turns a dead end into a next step.
    _set = str(r.get("concept_set") or "").strip()
    if not _set or _set.upper().startswith("TODO"):
        try:
            _sets, _probs = ur.concept_sets()
        except Exception:                  # noqa: BLE001
            _sets, _probs = [], []
        if not _sets:
            print(f"                      └ and LOCAL_RELATIONS.yaml records NO concept set, so "
                  f"there is nothing to point at yet. Asserting one is a scoping decision "
                  f"that needs a named `asserted_by`.")
        else:
            print(f"                      └ {len(_sets)} set(s) available: "
                  f"{', '.join(str(x.get('name')) for x in _sets[:4])}")
    # NOTHING DECLARED IS NOT A CLEAN RESULT. A pack with no contract prints "0 bound of 0" down
    # every surface and exits 0, which reads exactly like a pack whose bindings were all checked
    # and found sound. On an onboarding scaffold - the state where somebody is most likely to be
    # running this for the first time - that is the wrong impression to leave, and it is the same
    # absence-reads-as-clean shape this module refuses everywhere else. Said once, plainly, before
    # the table of zeros rather than left for the reader to infer from it.
    if not r["variables_declared"]:
        print(f"  NOTHING TO CHECK    : this pack declares no governed variables, so no binding "
              f"was examined.")
        print(f"                      └ that is the ordinary state of a pack with no contract yet, "
              f"and it is different from a pack whose bindings were checked and found sound. The "
              f"zeros below are the absence of a population, not a verdict about one.")
    print(f"  variables declared: {r['variables_declared']}")
    print(f"  variables bound   : {r['variables_bound']}")
    print(f"  variables unbound : {r['variables_unbound']}")
    # ...AND AGAINST WHICH POPULATION. "0 of 202" answers a question nobody asked: 19 of those
    # rows are on no output surface at all and 15 more are internal, so a reader taking 202 as
    # the ADS column count is reading a number about something else. The surfaces OVERLAP by
    # design and deliberately do not sum.
    _by = (r.get("by_surface") or {})
    if _by:
        print("  by surface (these overlap; a row is on several at once):")
        for _s, _v in _by.items():
            _label = "on no output surface" if _s == "no_surface" else _s
            print(f"      {_label:<22} {_v['bound']:>4} bound of {_v['declared']:<4}"
                  + (f"  ({_v['parked']} parked)" if _v["parked"] else ""))
    for var, st in sorted((r.get("parked") or {}).items()):
        print(f"  {st:<11} {var}")
    for p in r["problems"]:
        print(f"  PROBLEM: {p}")
    if a.check:
        return 1 if r["problems"] else 0
    if not r["variables_bound"]:
        print("  nothing is bound yet. `--draft` prints candidates; a person rules on them.")
    return 0


if __name__ == "__main__":
    from rwd_tools.console import use_utf8
    use_utf8()
    sys.exit(main())
