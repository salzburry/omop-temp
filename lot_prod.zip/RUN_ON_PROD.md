# What to run, in order

Everything here is the code and the docs. **No code lists are included** —
the engine reads them from `CODELIST_DIR` (default `/mnt/code/codelist`), which
lives on the box, not in this package. Nothing here writes to the study's own
tables; the melphalan cells write only to their own `melp_*` prefixes.

Paths below are relative to the `Jul 28/` folder.

## 1. Rebuild the melphalan sensitivity cells

Required before any melphalan number. The current cells were built by older
engine code and the readers will refuse them.

```
DATABRICKS_PWD=... DOMINO_USER_NAME=usr00000 \
  INPUT_COHORT_TABLE=ndmm_NDMM_COHORT COHORT_PREFIX=ndmm_ OBJECT_PREFIX=ndmm_ \
  AUG1_EXECUTE=TRUE Rscript exploration/melphalan/run_aug1_melp.R
```

Drop `AUG1_EXECUTE` first to print the plan — it touches nothing and needs no
connection. Each prefix is emptied before it is rebuilt, so nothing an earlier
run left can survive into these numbers.

Three complete LOT builds. `APPLY_MELP_RULE` stays blank in `CONTRACT`, so the
study's own run is untouched by all of this.

## 2. Julia's three questions

```
DATABRICKS_PWD=... DOMINO_USER_NAME=usr00000 \
  Rscript exploration/melphalan/read_melp_asks.R
```

Writes three CSVs: line duration and its change, the regimen distribution at
each line with 2L melphalan monotherapy called out, and SCT inside a
melphalan-containing LOT by line.

## 3. What each decision was worth

```
DATABRICKS_PWD=... DOMINO_USER_NAME=usr00000 \
  Rscript exploration/melphalan/read_melp_decisions.R
```

Read block 2 first — melphalan doses in no line. It should be empty. Rows with
`PRIOR_LINE_TYPE` of `CART` or `SCT_ALLO` are the one gap still open. Anything
else there is a gap nobody has named.

## 4. Impact of the core LOT fixes, on real data

```
DATABRICKS_PWD=... DOMINO_USER_NAME=usr00000 OBJECT_PREFIX=ndmm_ \
  INPUT_COHORT_TABLE=ndmm_NDMM_COHORT \
  AUDIT_EXECUTE=TRUE Rscript exploration/lot/run_lot_audit_counts.R
```

Read-only. Run without `AUDIT_EXECUTE` first to see what it would count. The
three ids to look at are `transplant-belonging-to-no-line`,
`tandem-pair-whose-first-transplant-is-out-of-window` and
`runout-unconfirmed-by-a-tandem-no-line-held`. Each counts a patient SHAPE
rather than a verdict, so the same query run against an older build sizes what
the fix was costing.

## 5. Baseline-period question (1L/2L/3L)

```
DATABRICKS_PWD=... DOMINO_USER_NAME=usr00000 OBJECT_PREFIX=ndmm_ \
  INPUT_COHORT_TABLE=ndmm_NDMM_COHORT \
  Rscript analysis/questions/baseline_gap_qs.R
```

`BASELINE_DAYS` defaults to 365.

## 6. QC over a finished run

```
DATABRICKS_PWD=... DOMINO_USER_NAME=usr00000 OBJECT_PREFIX=ndmm_ \
  Rscript lot/qc/run_lot_qc.R
```

## Read these before quoting anything

- `lot/LOT_RULES.md` — the rules the build applies
- `KNOWN_ISSUES.md` — the open study-team questions
- `exploration/FILES.md` — the melphalan proposal and what is still unsettled

## Still open, so do not present these as settled

- `yield_to_sct` vs `as_asked` — what wins when a melphalan exposure and an
  AUTO code describe the same event. The request does not cover it; that is
  why both are built.
- A B.2 pair after a CAR-T-only or single-day ALLO line. Those lines end on
  their own start date before any run-out is consulted, so the hold cannot
  reach the doses. Block 2 of step 3 counts how many patients this costs.
- What "2L MELP mono" means: melphalan as the only induction-regimen agent
  (what is built), or the only therapy exposure anywhere in the line.
