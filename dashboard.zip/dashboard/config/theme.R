# THE LOOK, in one place: the RWD Studio design system (rwdplatform1,
# rwd_services/studio_web/style.css) - GSK orange on a warm off-white page,
# white hairline cards, a wordmark with the brand dot, a numbered journey bar.
# Every page element (www/dashboard.css reads these as CSS variables) and
# every figure (R/plots.R) takes its colours from here, so a brand change is
# this file. Check the hex values against the brand guide before a release.
#
# The two arm colours and the class palette were run through a colour-vision
# validator (adjacent pairs distinguishable under protan, deutan and tritan
# vision, enough contrast on white); keep that property if you change them.

THEME <- list(
  primary       = "#f36633",   # brand orange: primary button, journey step, treated arm
  primary_ink   = "#9f2f0b",   # brand ink: links, the current step's text, focus
  primary_hover = "#e75a26",
  pale          = "#fff1e8",   # the current step's background, notices
  ink           = "#292522",   # text
  muted         = "#625b56",   # secondary text, axis labels
  line          = "#e5ded8",   # hairlines, gridlines
  plane         = "#fcfaf8",   # page background
  surface       = "#ffffff",   # cards, tables, figures
  font          = "\"Segoe UI\", Arial, sans-serif",

  # figures
  arms          = c(treated = "#f36633", control = "#0e9aa7"),          # orange vs teal
  classes       = c("#f36633", "#2f6fd6", "#0e9aa7", "#a3178f", "#b88600", "#4a3aa7")
)

# The variables www/dashboard.css reads, for app.R to put in the page head.
theme_css_vars <- function(t = THEME) {
  sprintf(paste0(":root{--dash-primary:%s;--dash-primary-ink:%s;--dash-primary-hover:%s;--dash-pale:%s;",
                 "--dash-ink:%s;--dash-muted:%s;--dash-line:%s;--dash-plane:%s;--dash-surface:%s;--dash-font:%s}"),
          t$primary, t$primary_ink, t$primary_hover, t$pale, t$ink, t$muted, t$line, t$plane, t$surface, t$font)
}
