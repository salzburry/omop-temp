# Every knob this dashboard has, in one place, and every one env-overridable
# (the same pattern as the Julia LOT dashboards). Nothing here is a method or
# a cohort: methods live in R/methods.R, cohorts come from the data source
# (R/sources.R) and the optional cohorts.csv registry.
#
# Trimmed, because a Domino environment variable set through a form keeps the
# spaces around it, and untrimmed they become part of a path that matches nothing.
.env_chr <- function(k, d) { v <- trimws(Sys.getenv(k, unset = "")); if (nzchar(v)) v else d }
.env_num <- function(k, d) {
  v <- suppressWarnings(as.numeric(.env_chr(k, NA_character_)))
  if (is.na(v)) d else v
}
.env_lgl <- function(k, d) {
  v <- toupper(.env_chr(k, NA_character_))
  if (is.na(v)) d else v %in% c("TRUE", "T", "1", "YES")
}
# A variable that may be set EMPTY on purpose ("" = off): unset gives the
# default, set-but-empty gives "".
.env_chr_or_empty <- function(k, d) {
  v <- Sys.getenv(k, unset = NA_character_)
  if (is.na(v)) d else trimws(v)
}

dashboard_config <- function() list(
  # --- where the cohorts come from -------------------------------------------
  # synthetic  generated in-process (R/synthetic.R): no files, so the App can be
  #            deployed and clicked through before any data is attached.
  # files      every CSV matching `file_pattern` under `data_dir`, plus the rows
  #            of `cohorts_csv`. On Domino, point data_dir at the attached
  #            Dataset's mount (read it off the Data step of the publish dialog).
  source          = .env_chr("DASH_SOURCE", "synthetic"),
  data_dir        = .env_chr("DASH_DATA_DIR", ""),      # "" = this folder and its data/
  file_pattern    = .env_chr("DASH_FILE_PATTERN", "_feature_table\\.csv$"),
  cohorts_csv     = .env_chr("DASH_COHORTS_CSV", "cohorts.csv"),
  allow_upload    = .env_lgl("DASH_ALLOW_UPLOAD", TRUE),
  max_upload_mb   = .env_num("DASH_MAX_UPLOAD_MB", 200),

  # --- provenance --------------------------------------------------------------
  # FALSE makes an App configured for synthetic numbers refuse to start and say
  # why, so nobody quotes generated data because the default was left in place.
  allow_synthetic = .env_lgl("DASH_ALLOW_SYNTHETIC", TRUE),
  title           = .env_chr("DASH_TITLE", "DR time-to-event dashboard"),

  # --- results cache -----------------------------------------------------------
  # Every (cohort, method, settings) result is written here and read back
  # before anything is recomputed, so a restart or another viewer does not
  # pay for a slow method twice, and a Domino Job (jobs/precompute.R) can fill
  # it ahead of the App. Relative paths are taken from this folder; on Domino
  # point it at a writable Dataset the Job and the App both attach. "" = off.
  cache_dir       = .env_chr_or_empty("DASH_CACHE_DIR", "output/cache"),

  # --- analysis defaults (every one is also a control on the page) -------------
  # duration is divided by this: 30.4375 turns days into months
  time_divisor    = .env_num("DASH_TIME_DIVISOR", 30.4375),
  time_unit       = .env_chr("DASH_TIME_UNIT", "months"),     # label only
  report_times    = .env_chr("DASH_REPORT_TIMES", "6, 12, 18"),
  chr_time        = .env_num("DASH_CHR_TIME", 12),
  grid_points     = .env_num("DASH_GRID_POINTS", 61)
)
