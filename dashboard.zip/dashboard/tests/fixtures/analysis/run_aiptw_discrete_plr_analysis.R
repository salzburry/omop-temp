# Test fixture: the simulation's covariate names built in, so it fails on any other data.
run_aiptw_discrete_plr_analysis <- function(data, times) {
  ps <- stats::glm(A ~ L1 + L2 + W, data = data, family = stats::binomial())
  data.frame(time = times, surv1 = 1, surv0 = 1)
}
