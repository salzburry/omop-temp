# Test fixture: a script that cannot be loaded.
stop("this script needs a package that is not installed")
run_broken_analysis <- function(data, covariates, times) NULL
