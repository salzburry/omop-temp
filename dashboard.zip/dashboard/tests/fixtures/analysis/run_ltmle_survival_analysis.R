# Test fixture: a slow method by its name, so it is only asked for the report times.
run_ltmle_survival_analysis <- function(data, covariates, times) {
  fit <- survival::survfit(survival::Surv(time, event) ~ A, data = data)
  sm <- summary(fit, times = times, extend = TRUE)
  st <- as.character(sm$strata)
  list(curves = data.frame(time = times, S1 = sm$surv[st == "A=1"], S0 = sm$surv[st == "A=0"]), n_times = length(times))
}
