# Test fixture: arms coded 1 and 2 - which is treated is not for the dashboard to guess.
run_ambiguous_analysis <- function(data, covariates, times) {
  fit <- survival::survfit(survival::Surv(time, event) ~ A, data = data)
  sm <- summary(fit, times = times, extend = TRUE)
  data.frame(time = sm$time, arm = ifelse(as.character(sm$strata) == "A=1", 2, 1), surv = sm$surv)
}
