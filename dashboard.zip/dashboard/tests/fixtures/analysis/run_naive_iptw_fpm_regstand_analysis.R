# Test fixture: a function that relies on a helper defined in another file,
# which in turn expects the columns under names this script never mentions.
run_naive_iptw_fpm_regstand_analysis <- function(data, covariates, times) {
  km <- km_by_arm(data, times)
  data.frame(time = times, surv_1 = km$S1, surv_0 = km$S0)
}
