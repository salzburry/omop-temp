# Test fixture: model formulas as arguments, and one vector per arm in a list.
run_aiptw_cox_analysis <- function(dat, ps_formula, outcome_formula, tau) {
  stopifnot(inherits(ps_formula, "formula"), inherits(outcome_formula, "formula"))
  fit <- survival::survfit(survival::Surv(time, event) ~ A, data = dat)
  sm <- summary(fit, times = tau, extend = TRUE)
  st <- as.character(sm$strata)
  list(times = tau, S1 = sm$surv[st == "A=1"], S0 = sm$surv[st == "A=0"])
}
