# Test fixture: cumulative risks rather than survival.
run_fpm_regstand_analysis <- function(data, covariates, times) {
  fit <- survival::survfit(survival::Surv(time, event) ~ A, data = data)
  sm <- summary(fit, times = times, extend = TRUE)
  st <- as.character(sm$strata)
  data.frame(time = times, risk1 = 1 - sm$surv[st == "A=1"], risk0 = 1 - sm$surv[st == "A=0"])
}
