# Test fixture: a long table (one row per arm and time) returned directly, from
# a function that expects the columns to be called status and trt.
run_cox_regstand_analysis <- function(df, confounders, eval_times) {
  fit <- survival::survfit(survival::Surv(time, status) ~ trt, data = df)
  sm <- summary(fit, times = eval_times, extend = TRUE)
  data.frame(time = sm$time, trt = as.integer(sub(".*=", "", as.character(sm$strata))), surv = sm$surv)
}
