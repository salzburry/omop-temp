# Test fixture: a helper file with no run_*_analysis function - not listed as a
# method, but loaded, so the study functions can call what it defines. Its
# helper knows the columns by other names than the function that calls it.
km_by_arm <- function(data, times) {
  fit <- survival::survfit(survival::Surv(futime, delta) ~ treat, data = data)
  sm <- summary(fit, times = times, extend = TRUE)
  st <- as.character(sm$strata)
  list(S1 = sm$surv[st == "treat=1"], S0 = sm$surv[st == "treat=0"])
}
