# Test fixture, not a study method: a function shaped like the study's, giving
# its curves as a wide table inside a list (with an interval column beside them).
run_iptw_cox_analysis <- function(data, covariates, times, time_var = "time", event_var = "event", trt_var = "A") {
  fit <- survival::survfit(survival::Surv(data[[time_var]], data[[event_var]]) ~ data[[trt_var]])
  sm <- summary(fit, times = times, extend = TRUE)
  st <- as.character(sm$strata)
  lev <- sort(unique(st))                                   # "...=0" then "...=1"
  list(method = "IPTW Cox",
       survival = data.frame(time = times,
                             surv_treated = sm$surv[st == lev[2]],
                             surv_control = sm$surv[st == lev[1]],
                             surv_treated_lower = pmax(sm$surv[st == lev[2]] - 0.05, 0)),
       estimates = data.frame(estimand = "RD", time = max(times), estimate = 0.1))
}
