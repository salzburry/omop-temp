# Test fixture: estimates only, no curves - cannot be a dashboard method as it is.
run_dr_plr_logit_analysis <- function(data, covariates, times) {
  data.frame(estimand = c("RD", "RMST"), time = max(times), estimate = c(0.1, 1))
}
