#!/usr/bin/env Rscript
# Checks on the dashboard. No Shiny, no browser.
#
#   Rscript tests/run_tests.R          (from the dashboard folder, or by absolute path)
#
# Every number the app puts on a page comes from a function in R/ that runs
# without Shiny, which is what makes this possible. app.R is wiring, and the
# last section reads it as text to hold the wiring to the registries.

.suite <- local({
  a <- grep("^--file=", commandArgs(FALSE), value = TRUE)
  if (!length(a)) NA_character_
  else normalizePath(gsub("~+~", " ", sub("^--file=", "", a[1]), fixed = TRUE), winslash = "/", mustWork = FALSE)
})
here <- if (is.na(.suite)) getwd() else dirname(dirname(.suite))
setwd(here)
# a cache of its own, so the suite neither reads nor disturbs the real one
# (the precompute Job it launches inherits the variable)
Sys.setenv(DASH_SOURCE = "synthetic", DASH_ALLOW_SYNTHETIC = "TRUE",
           DASH_CACHE_DIR = file.path(tempdir(), "dash-test-cache"))
source("global.R")

pass <- 0L; fail <- 0L
check <- function(cond, what) {
  if (isTRUE(cond)) { pass <<- pass + 1L; cat("  ok     ", what, "\n") }
  else              { fail <<- fail + 1L; cat("  FAIL   ", what, "\n") }
}

cat("registry\n")
tab <- methods_table()
check(nrow(tab) >= 5, "at least five methods registered")
check(!anyDuplicated(tab$id), "method ids unique")
check(all(vapply(METHODS, function(m) is.function(m$fn), logical(1))), "every method has a function")
check(length(method_classes()) >= 4, "methods span at least four robustness classes")
check(all(fast_method_ids() %in% available_method_ids()), "fast methods are available")
check(identical(unname(method_labels()), tab$id) && identical(names(method_labels()), tab$label), "method_labels() is label -> id, as a Shiny choices vector")

cat("cohorts (synthetic source)\n")
check(nrow(COHORTS) == 8, "eight synthetic cohorts")
for (id in COHORTS$id) {
  df <- load_cohort(COHORTS, id); sp <- cohort_spec(COHORTS, id, df)
  check(identical(c(sp$time, sp$event, sp$trt), c("duration", "event", "treatment")), paste("mapping guessed for", id))
  check(!any(c("Unnamed: 0", "", "linename", "patientid", "weights") %in% sp$covariates), paste("junk, id, label, weight columns excluded for", id))
}
spec_fr <- cohort_spec(COHORTS, "Fully restricted")
d <- prep_data(load_cohort(COHORTS, "Fully restricted"), spec_fr, DEFAULT_SETTINGS$time_divisor)
check(attr(d, "n_dropped") > 0, "rows with a missing duration dropped and counted")
check(all(d$time > 0) && all(d$event %in% 0:1) && all(d$A %in% 0:1), "prepared data has the one shape")
check(all(c("age", "ecog", "sex", "linenumber") %in% attr(d, "xvars")), "covariates carried through")
check(!any(c("stage", "histology") %in% attr(d, "xvars")), "covariates constant within the restricted cohort are dropped")
check(identical(unname(attr(d, "arm_labels")), c("nivolumab", "docetaxel")), "arm labels read from linename")
check(all(is.finite(d$w)), "the cohort's own weights column carried through")

cat("config and settings\n")
Sys.setenv(DASH_TITLE = "  My title  "); check(dashboard_config()$title == "My title", "env override, trimmed"); Sys.unsetenv("DASH_TITLE")
check(identical(parse_times("6, 12; 18 bad"), c(6, 12, 18)), "report times parsed")
check(length(settings_problems(DEFAULT_SETTINGS)) == 0, "default settings are valid")
sx <- DEFAULT_SETTINGS; sx$extra_ps <- "I(age^2) +"
check(length(settings_problems(sx)) == 1, "a broken formula fragment is reported")
g <- make_grid(DEFAULT_SETTINGS)
check(g[1] == 0 && all(c(6, 12, 18) %in% g), "grid starts at 0 and holds every report time")

cat("every method on one cohort\n")
s <- DEFAULT_SETTINGS; s$tmle_width <- 3
res <- run_methods(available_method_ids(), d, s, use_cache = FALSE)
st <- results_status(res)
print(st[, c("method", "class", "status", "seconds")], row.names = FALSE)
for (r in res) {
  check(isTRUE(r$ok), sprintf("%s ran (%s)", r$label, r$message))
  if (!isTRUE(r$ok)) next
  cv <- r$curves
  check(cv$s1[1] == 1 && cv$s0[1] == 1, paste(r$label, "curves start at 1"))
  tol <- if (r$id %in% c("aiptw_cox", "tmle_disc")) 0.03 else 1e-6
  check(all(diff(cv$s1) <= tol) && all(diff(cv$s0) <= tol), paste(r$label, "curves non-increasing"))
  check(all(is.finite(r$estimates$est)), paste(r$label, "estimates finite"))
  check(nrow(r$estimates) == 2 * length(s$report_times) + 1, paste(r$label, "one RD and one RMST per report time, one CHR"))
}
est <- results_estimates(res)
rd12 <- est$est[est$estimand == "RD" & est$time == 12]
check(length(rd12) >= 5 && diff(range(rd12)) < 0.08, sprintf("methods agree on RD at 12 (range %.3f)", diff(range(rd12))))
check(all(rd12 > 0), "the simulated benefit is recovered by every method (RD at 12 > 0)")
for (tt in s$report_times) {
  rd <- est$est[est$estimand == "RD" & est$time == tt]
  check(all(rd > 0.03) && diff(range(rd)) < 0.08, sprintf("RD at %g positive and agreed across methods (%.3f to %.3f)", tt, min(rd), max(rd)))
}
long_chk <- person_period(d, attr(d, "xvars"), time_breaks(d, s, 18, "fixed", 3))
check(sum(long_chk$dC[long_chk$k == max(long_chk$k)]) < 0.2 * sum(long_chk$k == max(long_chk$k)),
      "follow-up beyond the grid is not coded as censoring in the last bin")
chr <- est$est[est$estimand == "CHR"]
check(all(chr > 0.5 & chr < 0.95), sprintf("CHR in a plausible band (%.2f to %.2f; conditional truth 0.70)", min(chr), max(chr)))
h <- results_hrt(res)
check(any(is.finite(h$hr)) && any(is.finite(h$chr)), "HR(t) and CHR(t) computed")

cat("analytic intervals from influence curves\n")
for (id in c("aiptw_cox", "tmle_disc")) {
  e <- res[[id]]$estimates
  check(all(e$ci_type == "influence curve"), paste(res[[id]]$label, "reports influence-curve intervals"))
  check(all(is.finite(e$se)) && all(e$se > 0) && all(e$se[e$estimand == "RD"] < 0.1),
        sprintf("%s standard errors finite and plausible (RD se %.3f to %.3f)", res[[id]]$label,
                min(e$se[e$estimand == "RD"]), max(e$se[e$estimand == "RD"])))
  check(all(e$lower < e$est & e$est < e$upper), paste(res[[id]]$label, "intervals bracket the estimates"))
  check(all(e$lower[e$estimand == "RD"] > 0), paste(res[[id]]$label, "RD intervals exclude the null on the simulated benefit"))
}
e_km <- res[["iptw_km"]]$estimates
check(all(is.na(e_km$ci_type)) && all(is.na(e_km$se)), "a method without influence curves reports no interval unless bootstrapped")
sb10 <- s; sb10$boot_B <- 10
rb10 <- run_method("aiptw_cox", d, sb10)
ic_se <- res[["aiptw_cox"]]$estimates$se[res[["aiptw_cox"]]$estimates$estimand == "RD" & res[["aiptw_cox"]]$estimates$time == 12]
bt_se <- rb10$estimates$se[rb10$estimates$estimand == "RD" & rb10$estimates$time == 12]
check(isTRUE(rb10$ok) && rb10$estimates$ci_type[1] == "bootstrap" && bt_se / ic_se > 0.4 && bt_se / ic_se < 2.5,
      sprintf("bootstrap se (%.4f) and influence-curve se (%.4f) agree in magnitude for AIPTW RD at 12", bt_se, ic_se))
add_method("bad_ic", "Bad IC", "Test class", function(d, xvars, s, grid) {
  cv <- data.frame(time = grid, s1 = 1, s0 = 1); attr(cv, "ic") <- list(s1 = matrix(0, 2, 2), s0 = matrix(0, 2, 2)); cv })
ric <- run_method("bad_ic", d, s)
check(!ric$ok && grepl("n x grid", ric$message), "a malformed influence curve is refused with the contract")
METHODS[["bad_ic"]] <- NULL

cat("agreement\n")
ag <- agreement_table(est)
check(nrow(ag) == 2 * length(s$report_times) + 1, "one agreement row per estimand and time")
check(all(ag$same_side_of_null), "every method on the same side of the null")
tol <- c(RD = 0.08, RMST = 0.5, CHR = 0.15)   # RMST is in analysis units (months here)
check(all(ag$range < tol[ag$estimand]), sprintf("spread across methods small (RD %.3f, RMST %.3f, CHR %.3f at most)",
      max(ag$range[ag$estimand == "RD"]), max(ag$range[ag$estimand == "RMST"]), max(ag$range[ag$estimand == "CHR"])))
check(all(ag$min_method %in% est$method) && all(ag$max_method %in% est$method), "extremes name real methods")

cat("results cache\n")
dc <- prep_cohort(COHORTS, "Fully restricted", spec_fr, s$time_divisor)
check(nzchar(attr(dc, "data_hash")) && identical(attr(dc, "cohort_id"), "Fully restricted"), "prep_cohort attaches the cache identity")
check(identical(attr(dc, "data_hash"), attr(prep_cohort(COHORTS, "Fully restricted", spec_fr, s$time_divisor), "data_hash")), "data hash is stable")
sp_alt <- spec_fr; sp_alt$covariates <- spec_fr$covariates[1:2]
check(!identical(attr(dc, "data_hash"), attr(prep_cohort(COHORTS, "Fully restricted", sp_alt, s$time_divisor), "data_hash")), "a different mapping is a different hash")
if (nzchar(cache_dir())) {
  n0 <- cache_clear()
  rc1 <- run_method_cached("iptw_km", dc, s)
  rc2 <- run_method_cached("iptw_km", dc, s)
  check(!rc1$from_cache && rc2$from_cache, "second call is served from the cache")
  check(identical(rc1$estimates$est, rc2$estimates$est), "the cached result is the computed one")
  s_alt <- s; s_alt$ps_bounds <- 0.02
  rc3 <- run_method_cached("iptw_km", dc, s_alt)
  check(!rc3$from_cache, "a changed setting is a cache miss")
  rc4 <- run_method_cached("iptw_km", dc, s)
  rc4b <- run_method_cached("iptw_km", dc, s); rc4b$time_unit <- NULL
  check(rc4$from_cache, "a label-only change does not touch the key")
  check(cache_count() == 2, sprintf("two results stored (%d)", cache_count()))
  rm1 <- run_methods("iptw_km", dc, s)
  check(isTRUE(rm1[["iptw_km"]]$from_cache), "run_methods goes through the cache by default")
  check(results_status(rm1)$cached[1], "status table says so")
} else cat("  SKIP    no writable cache directory\n")

cat("diagnostics extras\n")
cs <- censoring_summary(d)
check(nrow(cs) == 2 && all(cs$n > 0) && all(is.finite(cs$median_followup)), "censoring summary by arm")
rt <- risk_table(d, s$report_times)
check(nrow(rt) == 2 * length(s$report_times) && all(rt$at_risk >= 0), "risk table by arm and report time")
# called the way the App calls it: with no object named `d` in the workspace,
# so a fit that looks its data up by name (as cox.zph does) cannot get lucky
ph <- local({ dd <- d; rm(d, envir = globalenv()); on.exit(assign("d", dd, envir = globalenv()))
              ph_check(dd, attr(dd, "xvars"), s) })
check(nrow(ph) > 0 && "GLOBAL" %in% ph$term && all(ph$p >= 0 & ph$p <= 1), "Schoenfeld test table with a GLOBAL row, data not found by name")

cat("figures build without warnings\n")
fig_warn <- character()
figs <- withCallingHandlers({
  cv <- results_curves(res); hr <- results_hrt(res)
  e2 <- est; e2$cohort <- "one cohort"
  xv <- attr(d, "xvars"); al <- attr(d, "arm_labels")
  e3 <- est; e3$cohort <- rep(c("cohort A", "cohort B"), length.out = nrow(e3))
  list(plot_forest(est, "RD", unit = "months"), plot_forest(est, "CHR"), plot_curves(cv, attr(d, "arm_labels"), "months"),
       plot_hrt(hr, "hr", "months"), plot_runtime(st), plot_compare(e2, "RD", 12, "months"),
       plot_heatmap(e2, "RD", 12, "months"), plot_heatmap(e2, "CHR", 12),
       plot_ps_mirror(ps_overlap_bins(d, xv, s), al), plot_ecdf(ecdf_table(d, xv, s), al),
       plot_effect(results_effect(res), "rd", "months"), plot_effect(results_effect(res), "rmst", "months"),
       plot_spec_curve(spec_curve_data(e3, "RD", 12), "RD", "months"), plot_spec_strip(spec_curve_data(e3, "RD", 12)),
       plot_evalue(results_evalue(res)), plot_heterogeneity(heterogeneity_data(d, xv, s), al, "months"),
       plot_weights(weight_data(d, xv, s), weight_summary(d, xv, s), al),
       plot_cohort_sizes(data.frame(cohort = c("A", "B"), n = c(100, 80), events = c(50, 40), n_treated = c(40, 30))),
       plot_km(km_unadjusted(d), attr(d, "arm_labels")), plot_ps(ps_overlap(d, attr(d, "xvars"), s), attr(d, "arm_labels")),
       plot_love(balance_table(d, attr(d, "xvars"), s)))
}, warning = function(w) { fig_warn <<- c(fig_warn, conditionMessage(w)); invokeRestart("muffleWarning") })
check(all(vapply(figs, inherits, logical(1), "ggplot")), "every figure is a ggplot")
check(!length(fig_warn), paste("no warnings while building figures", if (length(fig_warn)) paste0("(", fig_warn[1], ")") else ""))
built <- withCallingHandlers(lapply(figs, ggplot2::ggplot_build), warning = function(w) { fig_warn <<- c(fig_warn, conditionMessage(w)); invokeRestart("muffleWarning") })
check(length(built) == length(figs) && !length(fig_warn), "every figure renders without warnings")

cat("provided weights, extra terms, event-driven TMLE grid\n")
s2 <- s; s2$use_provided_weights <- TRUE
r2 <- run_method("iptw_km", d, s2); check(isTRUE(r2$ok), "IPTW KM on the cohort's own weights column")
s3 <- s; s3$extra_ps <- "I(age^2)"; s3$extra_out <- "age:ecog"
r3 <- run_method("aiptw_cox", d, s3); check(isTRUE(r3$ok), sprintf("extra PS and outcome terms accepted (%s)", r3$message))
s4 <- s; s4$tmle_grid <- "event"; s4$max_bins <- 25
r4 <- run_method("tmle_disc", d, s4); check(isTRUE(r4$ok), sprintf("event-driven TMLE grid (%s, %.1fs)", r4$message, r4$seconds))

cat("bootstrap\n")
sb <- s; sb$boot_B <- 5
rb <- run_method("iptw_km", d, sb)
check(isTRUE(rb$ok) && all(is.finite(rb$estimates$lower)) && all(rb$estimates$lower <= rb$estimates$upper),
      "percentile intervals from 5 replicates")

cat("failure is reported, not thrown\n")
add_method("broken_test", "Broken", "Test class", function(d, xvars, s, grid) stop("boom"))
rr <- run_method("broken_test", d, s)
check(!rr$ok && grepl("boom", rr$message), "a failing method returns ok = FALSE with its message")
bad <- add_method("bad_shape", "Bad shape", "Test class", function(d, xvars, s, grid) data.frame(time = grid, s1 = 1))
rr2 <- run_method("bad_shape", d, s)
check(!rr2$ok && grepl("data.frame\\(time, s1, s0\\)", rr2$message), "a method returning the wrong shape is refused with the contract")
METHODS[["broken_test"]] <- NULL; METHODS[["bad_shape"]] <- NULL
check(inherits(try(add_method("iptw_km", "dup", "x", function(...) NULL), silent = TRUE), "try-error"), "duplicate method id refused")

cat("files source: discovery and cohorts.csv\n")
tmp <- tempfile("cohorts"); dir.create(tmp)
pop <- synthetic_cohorts()
utils::write.csv(pop[["ECOG"]], file.path(tmp, "x_EC_ECOG_feature_table.csv"), row.names = TRUE)
utils::write.csv(pop[["STAGE"]], file.path(tmp, "x_EC_STAGE_feature_table.csv"), row.names = TRUE)
writeLines(c("id,label,description,covariates", "x_EC_ECOG,ECOG only,from csv,age;ecog"), file.path(tmp, "cohorts.csv"))
cfg2 <- DASH_CFG; cfg2$source <- "files"; cfg2$data_dir <- tmp; cfg2$cohorts_csv <- file.path(tmp, "cohorts.csv")
reg2 <- discover_cohorts(cfg2, tmp)
check(nrow(reg2) == 2, "two files discovered")
check(reg2$label[reg2$id == "x_EC_ECOG"] == "ECOG only", "label from cohorts.csv applied")
check(reg2$label[reg2$id == "x_EC_STAGE"] == "x_EC_STAGE", "a file with no cohorts.csv row keeps its own name")
sp2 <- cohort_spec(reg2, "x_EC_ECOG")
check(identical(sp2$covariates, c("age", "ecog")), "covariates fixed by cohorts.csv")
d2 <- prep_data(load_cohort(reg2, "x_EC_ECOG"), sp2, 30.4375)
check(nrow(d2) > 1000 && identical(attr(d2, "xvars"), c("age", "ecog")), "cohort file loads through the same path")
st_a <- new_cohort_store()
reg3 <- upload_cohort(reg2, file.path(tmp, "x_EC_STAGE_feature_table.csv"), "x_EC_STAGE_feature_table.csv", st_a)
check(nrow(reg3) == 3 && "x_EC_STAGE (upload 1)" %in% reg3$id, "an upload of an existing id gets its own id")
cfg3 <- cfg2; cfg3$source <- "nowhere"
check(inherits(try(discover_cohorts(cfg3, tmp), silent = TRUE), "try-error"), "an unknown DASH_SOURCE is refused")

cat("data validation: nothing silent\n")
set.seed(1)
mk <- function(n = 300) data.frame(
  patientid = sprintf("P%04d", seq_len(n)), duration = round(runif(n, 30, 900)), event = rbinom(n, 1, 0.7),
  treatment = rbinom(n, 1, 0.5), age = round(rnorm(n, 60, 8)), score = rnorm(n), stringsAsFactors = FALSE)
sp0 <- auto_spec(mk())
check("score" %in% sp0$covariates, "a numeric covariate distinct on every row is kept")
check(!("patientid" %in% sp0$covariates), "a text column distinct on every row is not a covariate")
three <- mk(); three$treatment <- sample(0:2, nrow(three), TRUE)
check(any(grepl("exactly two values", spec_problems(three, auto_spec(three)))), "three treatment groups are refused, not collapsed")
fe <- mk(); fe$event <- factor(as.character(fe$event))
dfe <- prep_data(fe, auto_spec(fe), 1)
check(sum(dfe$event) == sum(fe$event == "1") && attr(dfe, "n_dropped") == 0, "a factor-coded 0/1 event is read through its labels, nothing dropped")
bad_ev <- mk(); bad_ev$event[1:3] <- 2
check(any(grepl("only 0 and 1", spec_problems(bad_ev, auto_spec(bad_ev)))), "an event column with other values is refused")
tc <- mk(); tc$time <- rnorm(nrow(tc)); tc$`my col` <- rnorm(nrow(tc))
spc <- auto_spec(tc); spc$covariates <- c("age", "time", "my col")
dtc <- prep_data(tc, spc, 30)
check(all(abs(dtc$time - tc$duration[match(dtc$id, tc$patientid)] / 30) < 1e-9), "a covariate named 'time' does not overwrite the survival time")
check(all(c("time_cov", "my.col") %in% attr(dtc, "xvars")) && identical(unname(attr(dtc, "xvar_labels")[c("time_cov", "my.col")]), c("time", "my col")),
      "clashing and non-syntactic covariate names are renamed and the renames reported")
rtc <- run_method("cox_rs", dtc, DEFAULT_SETTINGS)
check(isTRUE(rtc$ok), sprintf("a model fits on the renamed covariates (%s)", rtc$message))
t12 <- mk(); t12$treatment <- t12$treatment + 1L
sp12 <- auto_spec(t12); check(identical(sp12$treated_value, "1"), "a 1/2 coded treatment guesses '1' as treated and the page offers the choice")
sp12$treated_value <- "2"
d12 <- prep_data(t12, sp12, 1)
check(sum(d12$A) == sum(t12$treatment == 2) && sum(d12$A == 0) == sum(t12$treatment == 1), "the treated value is honoured, the other value is control")
sp_bad <- sp12; sp_bad$treated_value <- "9"
check(any(grepl("not one of the treatment column", spec_problems(t12, sp_bad))), "a treated value absent from the column is refused")
na_t <- mk(); na_t$treatment[1:7] <- NA; na_t$duration[8:9] <- 0
dna <- prep_data(na_t, auto_spec(na_t), 1)
check(attr(dna, "n_dropped") == 9 && attr(dna, "drop_reasons")[["missing treatment"]] == 7 && attr(dna, "drop_reasons")[["time <= 0"]] == 2,
      "exclusions are counted by reason")
ovl <- auto_spec(mk()); ovl$covariates <- c("age", "treatment")
check(any(grepl("also used as a role", spec_problems(mk(), ovl))), "a covariate that is also a role column is refused")

cat("upload isolation between sessions\n")
up_dir <- tempfile("uploads"); dir.create(up_dir)
a_path <- file.path(up_dir, "a"); b_path <- file.path(up_dir, "b"); dir.create(a_path); dir.create(b_path)
utils::write.csv(mk(200), file.path(a_path, "new_upload.csv"), row.names = FALSE)
utils::write.csv(mk(250), file.path(b_path, "new_upload.csv"), row.names = FALSE)
store_a <- new_cohort_store(); store_b <- new_cohort_store()
reg_a <- upload_cohort(.empty_registry(), file.path(a_path, "new_upload.csv"), "new_upload.csv", store_a)
reg_b <- upload_cohort(.empty_registry(), file.path(b_path, "new_upload.csv"), "new_upload.csv", store_b)
check(identical(reg_a$id, reg_b$id), "two sessions give the same file name the same id")
check(nrow(load_cohort(reg_a, reg_a$id, store_a)) == 200 && nrow(load_cohort(reg_b, reg_b$id, store_b)) == 250,
      "each session reads its own upload")
check(!identical(cohort_hash(reg_a, reg_a$id, store_a), cohort_hash(reg_b, reg_b$id, store_b)), "their data hashes differ")
check(!exists(paste0("c:", reg_a$id), envir = .cohort_cache), "nothing from an upload reaches the process-wide cache")
reg_a2 <- upload_cohort(reg_a, file.path(b_path, "new_upload.csv"), "new_upload.csv", store_a)
check(nrow(reg_a2) == 2 && !anyDuplicated(reg_a2$id) && nrow(load_cohort(reg_a2, reg_a2$id[2], store_a)) == 250,
      "a repeated upload of the same name gets a new id and its own data")
check(inherits(try(upload_cohort(reg_a, file.path(a_path, "new_upload.csv"), "new_upload.csv"), silent = TRUE), "try-error"),
      "an upload without a session store is refused")

cat("results of one analysis only\n")
d_an <- prep_cohort(COHORTS, "Fully restricted", spec_fr, s$time_divisor)
h_an <- attr(d_an, "data_hash")
r_an <- run_methods(c("iptw_km", "cox_rs"), d_an, s, use_cache = FALSE)
check(length(current_results(r_an, s, h_an)) == 2 && attr(current_results(r_an, s, h_an), "n_stale") == 0, "both results belong to the analysis they were run under")
s_new <- s; s_new$chr_time <- 6
cur <- current_results(r_an, s_new, h_an)
check(length(cur) == 0 && attr(cur, "n_stale") == 2, "a settings change hides every result not re-run")
r_an[["cox_rs"]] <- run_method("cox_rs", d_an, s_new)
cur <- current_results(r_an, s_new, h_an)
check(length(cur) == 1 && cur[[1]]$label == "Cox Reg Stand", "re-running one method shows that one only, never the other method's old numbers")
sp_m <- spec_fr; sp_m$covariates <- spec_fr$covariates[1:2]
h_m <- attr(prep_cohort(COHORTS, "Fully restricted", sp_m, s$time_divisor), "data_hash")
check(length(current_results(r_an, s_new, h_m)) == 0, "a mapping change hides results of the old mapping")
hash_of <- function(cid) h_an
pend <- pending_combinations(list("Fully restricted" = r_an), "Fully restricted", c("iptw_km", "cox_rs"), s_new, hash_of)
check(length(pend) == 1 && pend[[1]][2] == "iptw_km", "the comparison counts the method not re-run as pending")
r_fail <- r_an; r_fail[["cox_rs"]]$ok <- FALSE
pend2 <- pending_combinations(list("Fully restricted" = r_fail), "Fully restricted", c("iptw_km", "cox_rs"), s_new, hash_of)
check(length(pend2) == 2, "a failed method is pending, not complete")

cat("discovery edge cases\n")
empty_dir <- tempfile("empty"); dir.create(empty_dir)
cfg_e <- DASH_CFG; cfg_e$source <- "files"; cfg_e$data_dir <- empty_dir; cfg_e$cohorts_csv <- "cohorts.csv"
reg_e <- tryCatch(discover_cohorts(cfg_e, empty_dir), error = function(e) e)
check(is.data.frame(reg_e) && nrow(reg_e) == 0, "an empty data directory gives a registry with no rows, not an error")
writeLines(c("id,label,file,description", "x_EC_ECOG,From data dir,x_EC_ECOG_feature_table.csv,registry beside the data"), file.path(tmp, "cohorts.csv"))
cfg_d <- DASH_CFG; cfg_d$source <- "files"; cfg_d$data_dir <- tmp; cfg_d$cohorts_csv <- "cohorts.csv"
reg_d <- discover_cohorts(cfg_d, empty_dir)
check(reg_d$label[reg_d$id == "x_EC_ECOG"] == "From data dir", "cohorts.csv inside DASH_DATA_DIR is found")
writeLines(c("id,label,file,description", "ghost,Ghost cohort,does_not_exist.csv,registered but absent"), file.path(empty_dir, "cohorts.csv"))
reg_g <- discover_cohorts(cfg_e, empty_dir)
check(nrow(reg_g) == 1 && isTRUE(reg_g$missing_file[1]), "a registered file that is missing is listed and flagged, not fatal")
err_g <- tryCatch(load_cohort(reg_g, "ghost"), error = function(e) conditionMessage(e))
check(is.character(err_g) && grepl("not found", err_g), "loading it fails with a clear message that callers isolate")

cat("curve validation refuses wrong output\n")
g <- make_grid(s)
bad <- function(f) { add_method("bad_tmp", "Bad", "Test class", f); on.exit(METHODS[["bad_tmp"]] <<- NULL); run_method("bad_tmp", d, s) }
r1 <- bad(function(d, xvars, s, grid) data.frame(time = grid + 0.5, s1 = 1, s0 = 1))
check(!r1$ok && grepl("exactly the grid times", r1$message), "times off the grid are refused, not replaced")
r2 <- bad(function(d, xvars, s, grid) data.frame(time = grid, s1 = c(1, rep(1.2, length(grid) - 1)), s0 = 1))
check(!r2$ok && grepl("\\[0, 1\\]", r2$message), "probabilities outside [0, 1] are refused, not clipped")
r3 <- bad(function(d, xvars, s, grid) data.frame(time = grid, s1 = 0.9, s0 = 0.9))
check(!r3$ok && grepl("1 at time 0", r3$message), "a curve not starting at 1 is refused")
r4 <- bad(function(d, xvars, s, grid) data.frame(time = grid, s1 = as.character(1), s0 = 1))
check(!r4$ok && grepl("must be numeric", r4$message), "a non-numeric column is refused")
r5 <- bad(function(d, xvars, s, grid) data.frame(time = grid[-1], s1 = 1, s0 = 1))
check(!r5$ok && grepl("grid times; got", r5$message), "the wrong number of rows is refused")

cat("cache failures are visible\n")
if (nzchar(cache_dir())) {
  cache_clear()
  rc <- run_method_cached("iptw_km", dc, s)
  check(isTRUE(rc$stored) && !length(list.files(cache_dir(), pattern = "\\.tmp$")), "a stored result is on disk under its final name, no temporary file left")
  check(isTRUE(results_status(list(rc))$stored[1]), "the status table says stored")
}
old_dir <- DASH_CFG$cache_dir
blocker <- tempfile("blocker"); writeLines("x", blocker)
DASH_CFG$cache_dir <- blocker; cache_reset()
check(cache_dir() == "" && grepl("^off", cache_status()), "a cache path that cannot be a directory turns the cache off and says so")
rnc <- run_method_cached("iptw_km", dc, s)
check(isTRUE(rnc$ok) && is.na(rnc$stored) && !rnc$from_cache, "without a cache the result is computed and marked as not stored")
DASH_CFG$cache_dir <- old_dir; cache_reset()
check(nzchar(cache_dir()), "the cache comes back when the directory is writable again")

cat("balance after matching, overlap, ECDF, weights, heterogeneity\n")
xv <- attr(d, "xvars")
mt <- ps_match(d, xv, s)
check(mt$n_pairs > 0 && sum(mt$matched) == 2 * mt$n_pairs && mt$n_pairs <= min(mt$n_treated, mt$n_control),
      sprintf("1:1 matching pairs treated with distinct controls within the caliper (%d pairs)", mt$n_pairs))
bal <- balance_table(d, xv, s)
check("smd_matched" %in% names(bal) && all(is.finite(bal$smd_matched)), "balance table has a matched column")
check(median(abs(bal$smd_matched)) < median(abs(bal$smd_unweighted)) && median(abs(bal$smd_weighted)) < median(abs(bal$smd_unweighted)),
      "matching and weighting both reduce the typical imbalance")
check(identical(names(attr(bal, "matching")), c("n_pairs", "n_treated", "n_control", "n_unmatched", "caliper")), "matching summary rides on the table")
hb <- ps_overlap_bins(d, xv, s)
check(sum(hb$unweighted[hb$arm == "treated"]) == sum(d$A == 1) && -sum(hb$unweighted[hb$arm == "control"]) == sum(d$A == 0),
      "mirrored histogram counts every patient, treated up and control down")
check(abs(sum(hb$weighted[hb$arm == "treated"]) - sum(d$A == 1)) < 1e-6, "the weighted pseudo-population is scaled to the arm's size")
ec <- ecdf_table(d, xv, s)
check(nrow(ec) > 0 && "age" %in% ec$covariate && !("ecog" %in% ec$covariate), "ECDF for continuous covariates only")
ea <- ec[ec$covariate == "age" & ec$arm == "treated", ]
check(all(diff(ea$unweighted) >= 0) && all(diff(ea$weighted) >= 0) && all(ea$weighted >= 0 & ea$weighted <= 1), "ECDFs are monotone and in [0, 1]")
rs <- risk_strip(d, 18, arm_labels = attr(d, "arm_labels"))
check(nrow(rs) == 2 && ncol(rs) >= 4 && all(diff(as.numeric(rs[1, -1])) <= 0), "numbers at risk by arm, non-increasing over time")
wd <- weight_data(d, xv, s)
check(nrow(wd) == nrow(d) && all(wd$w > 0), "one weight per patient")
hd <- heterogeneity_data(d, xv, s)
check(!is.null(hd$smooth) && all(hd$points$y %in% c(0, 1)) && all(hd$smooth$fit >= 0 & hd$smooth$fit <= 1) && hd$n_unknown >= 0,
      "heterogeneity smooth by arm on alive-at-t status")

cat("effect over time, E-values, specification curve\n")
r_a <- res[["aiptw_cox"]]; eff_a <- r_a$effect
check(!is.null(eff_a) && identical(attr(eff_a, "ci_type"), "influence curve") && all(is.finite(eff_a$rd_lower[-1])) && all(eff_a$rd_lower[-1] < eff_a$rd[-1]),
      "RD curve has an influence-curve band")
for (tt in s$report_times) {
  j <- which(abs(eff_a$time - tt) < 1e-9)
  check(abs(eff_a$rd[j] - r_a$estimates$est[r_a$estimates$estimand == "RD" & r_a$estimates$time == tt]) < 1e-9 &&
        abs(eff_a$rmst[j] - r_a$estimates$est[r_a$estimates$estimand == "RMST" & r_a$estimates$time == tt]) < 1e-9,
        sprintf("effect curves agree with the estimates at %g", tt))
}
eff_k <- res[["iptw_km"]]$effect
check(all(is.na(eff_k$rd_lower)) && is.na(attr(eff_k, "ci_type")), "a method without influence curves has no band unless bootstrapped")
check(all(is.finite(rb$effect$rd_lower)) && identical(attr(rb$effect, "ci_type"), "bootstrap"), "bootstrap replicates give a band")
ev <- results_evalue(res)
check(nrow(ev) == length(res) && all(ev$rr < 1) && all(ev$evalue > 1), "E-values per method from the risk ratio at the CHR time (benefit: RR < 1)")
eva <- ev[ev$method == "AIPTW Cox", ]
check(is.finite(eva$evalue_ci) && eva$evalue_ci <= eva$evalue && eva$ci_type == "influence curve", "the confidence-limit E-value is smaller and typed")
check(is.na(ev$evalue_ci[ev$method == "IPTW KM"]), "no confidence-limit E-value without an interval")
check(evalue_rr(0.5) == evalue_rr(2) && abs(evalue_rr(2) - (2 + sqrt(2))) < 1e-12 && evalue_rr(1) == 1, "E-value formula")
check(is.finite(rb$evalue$evalue_ci) && rb$evalue$ci_type == "bootstrap", "a bootstrapped method gets a bootstrap E-value interval")
e_sc <- est; e_sc$cohort <- rep(c("A", "B"), length.out = nrow(e_sc))
sc <- spec_curve_data(e_sc, "RD", 12)
check(nrow(sc) == length(res) && all(diff(sc$est) >= 0) && identical(sc$rank, seq_len(nrow(sc))), "specification curve sorts the estimates and ranks them")

cat("methods from src/\n")
src_tmp <- tempfile("src"); dir.create(src_tmp)
writeLines(c('METHOD_LABEL <- "KM from a script"', 'METHOD_CLASS <- "Singly Robust (IPW)"', 'METHOD_NOTE <- "test"',
             'estimate_curves <- function(d, xvars, s, grid) km_curves(d, rep(1, nrow(d)), grid)'),
           file.path(src_tmp, "km_script.R"))
writeLines(c('x <- 1', 'helper <- function() 2'), file.path(src_tmp, "not_a_method.R"))
writeLines(c('estimate_curves <- function(d, xvars, s, grid) {', 'oops('), file.path(src_tmp, "broken.R"))
writeLines('stop("should never run")', file.path(src_tmp, "_ignored.R"))
scan <- register_src_methods(src_tmp)
check(nrow(scan) == 3 && !("_ignored.R" %in% scan$file), "every script is listed, underscore files are left alone")
check(scan$status[scan$file == "km_script.R"] == "registered" && "src:km_script" %in% names(METHODS), "a script that defines estimate_curves becomes a method")
check(grepl("^not a dashboard method", scan$status[scan$file == "not_a_method.R"]), "a script without one is listed, not run")
check(grepl("^error", scan$status[scan$file == "broken.R"]) && !("src:broken" %in% names(METHODS)), "a broken script is listed with its error")
tab2 <- methods_table()
check(tab2$label[tab2$id == "src:km_script"] == "KM from a script" && tab2$file[tab2$id == "src:km_script"] == "km_script.R" &&
      tab2$source[tab2$id == "src:km_script"] == "src/" && tab2$class[tab2$id == "src:km_script"] == "Singly Robust (IPW)",
      "the method carries its label, file name, origin and class")
r_src <- run_method("src:km_script", d, s)
check(isTRUE(r_src$ok) && abs(r_src$estimates$est[1] - res[["iptw_km"]]$estimates$est[1]) < 0.05,
      sprintf("the script's method runs through the same runner (%s)", r_src$message))
k1 <- cache_key("c", "h", "src:km_script", s, METHODS[["src:km_script"]]$code_hash)
cat('METHOD_NOTE <- "changed"\n', file = file.path(src_tmp, "km_script.R"), append = TRUE)
invisible(register_src_methods(src_tmp))
k2 <- cache_key("c", "h", "src:km_script", s, METHODS[["src:km_script"]]$code_hash)
check(k1 != k2, "editing the script changes its cache key")
unlink(file.path(src_tmp, "km_script.R"))
scan2 <- register_src_methods(src_tmp)
check(!("src:km_script" %in% names(METHODS)) && nrow(scan2) == 2, "removing the script removes the method")
check(nrow(register_src_methods(file.path(src_tmp, "does-not-exist"))) == 0, "a missing src/ folder is no scripts, not an error")

cat("precompute job\n")
rscript <- file.path(R.home("bin"), "Rscript")
job <- suppressWarnings(system2(rscript, c("jobs/precompute.R", "--cohorts", shQuote("Fully restricted"), "--methods", "iptw_km,cox_rs"),
                                stdout = TRUE, stderr = TRUE))
status <- attr(job, "status") %||% 0L
check(status == 0L, sprintf("job exits 0 (%s)", if (status == 0L) "ok" else paste(tail(job, 3), collapse = " | ")))
check(any(grepl("2 ok, 0 incomplete, 0 failed", job)), "job reports two results")
check(length(list.files("output", pattern = "^precompute_.*\\.csv$")) > 0, "job writes its summary CSV")
job2 <- suppressWarnings(system2(rscript, c("jobs/precompute.R", "--cohorts", shQuote("Fully restricted"), "--methods", "iptw_km,cox_rs"),
                                 stdout = TRUE, stderr = TRUE))
check(any(grepl("2 from the cache", job2)), "a second run is served from the cache")
unlink(list.files("output", pattern = "^precompute_.*\\.csv$", full.names = TRUE))

cat("second review: data, formulas, intervals, discovery\n")
fm <- tempfile("filesmode"); dir.create(fm)
writeLines(c("id,label,file,description", "ECOG,ECOG,,no file at all"), file.path(fm, "cohorts.csv"))
cfg_fm <- DASH_CFG; cfg_fm$source <- "files"; cfg_fm$data_dir <- fm; cfg_fm$cohorts_csv <- "cohorts.csv"
reg_fm <- discover_cohorts(cfg_fm, fm)
check(nrow(reg_fm) == 1 && isTRUE(reg_fm$missing_file[1]) && !isTRUE(reg_fm$synthetic[1]), "a files-mode row without a file is flagged, not synthetic")
e_fm <- tryCatch(load_cohort(reg_fm, "ECOG"), error = function(e) conditionMessage(e))
check(is.character(e_fm) && grepl("no file", e_fm), "loading it is refused, never served from the generator")
dd1 <- file.path(fm, "a"); dd2 <- file.path(fm, "b"); dir.create(dd1); dir.create(dd2)
utils::write.csv(pop[["ECOG"]], file.path(dd1, "x_feature_table.csv"), row.names = FALSE)
utils::write.csv(pop[["STAGE"]], file.path(dd2, "x_feature_table.csv"), row.names = FALSE)
cfg_dup <- cfg_fm; cfg_dup$cohorts_csv <- "none.csv"
reg_dup <- suppressMessages(discover_cohorts(cfg_dup, fm))
check(nrow(reg_dup) == 2 && !anyDuplicated(reg_dup$id) && all(grepl("\\((a|b)\\)", reg_dup$id)), "the same file name in two folders is two cohorts with distinct ids")
s_na <- s; s_na$extra_ps <- "log(age - 70)"
r_na <- run_method("iptw_km", d, s_na)
check(!r_na$ok && grepl("missing or non-finite value", r_na$message), "an extra term that yields missing values is refused before any model is fitted")
check(!length(check_formula_terms("I(age^2) + age:ecog + ns(age, df = 3)", c("age", "ecog"))), "allowed functions and covariates pass")
check(any(grepl("not allowed", check_formula_terms("system('echo hi')"))), "a function outside the allowlist is refused")
check(any(grepl("not allowed", check_formula_terms("I(ifelse(age > 60, age^2, NA_real_))", "age"))), "ifelse is refused")
check(any(grepl("not a covariate", check_formula_terms("I(bmi^2)", c("age", "ecog")))), "an unknown variable is refused when the covariates are known")
s_bad <- s; s_bad$extra_out <- "assign('pwned_marker', 1, envir = globalenv())"
r_bad <- run_method("cox_rs", d, s_bad)
check(!r_bad$ok && !exists("pwned_marker", envir = globalenv()), "a term that is code is refused and never evaluated")
s_in <- s; s_in$report_times <- c(1, 6, 12); s_in$tmle_width <- 2
r_in <- run_method("tmle_disc", d, s_in)
e_in <- r_in$estimates[r_in$estimates$estimand == "RD" & r_in$estimates$time == 1, ]
check(isTRUE(r_in$ok) && is.finite(e_in$se) && e_in$se > 0 && e_in$lower < e_in$est,
      sprintf("TMLE at a time inside a bin has a real interval (se %.4f)", e_in$se))
dk <- mk(); dk$k <- 100 + seq_len(nrow(dk)) %% 3; dk$dN <- rnorm(nrow(dk))
spk <- auto_spec(dk); spk$covariates <- c("age", "k", "dN")
pk <- prep_data(dk, spk, 1)
check(all(c("k_cov", "dN_cov") %in% attr(pk, "xvars")) && all(pk$k_cov == dk$k[match(pk$id, dk$patientid)]),
      "covariates named like person-period columns are renamed and keep their values")
rk <- run_method("plr_rs", pk, DEFAULT_SETTINGS)
check(isTRUE(rk$ok), sprintf("a discrete-time method runs on them (%s)", rk$message))
calls <- new.env(); calls$n <- 0L
add_method("flaky_test", "Flaky", "Test class", function(d, xvars, s, grid) {
  calls$n <- calls$n + 1L; if (calls$n > 1 && calls$n <= 5) stop("replicate failed"); km_curves(d, rep(1, nrow(d)), grid) })
sf5 <- s; sf5$boot_B <- 5
rf <- run_method("flaky_test", d, sf5)
check(isTRUE(rf$ok) && is.na(rf$estimates$ci_type[1]) && all(is.na(rf$estimates$lower)) && rf$estimates$boot_ok[1] == 1 && any(grepl("only 1 of 5", rf$notes)),
      "with most replicates failed there is no interval, and the count is reported")
METHODS[["flaky_test"]] <- NULL
mm2 <- mk(); names(mm2)[names(mm2) == "duration"] <- "followup_days"; names(mm2)[names(mm2) == "event"] <- "death_flag"
md <- tempfile("manifest"); dir.create(md)
utils::write.csv(mm2, file.path(md, "cohort_feature_table.csv"), row.names = FALSE)
writeLines(c("id,label,file,description,time_col,event_col", "cohort,Mapped,cohort_feature_table.csv,new names,followup_days,death_flag"), file.path(md, "cohorts.csv"))
cfg_md <- DASH_CFG; cfg_md$source <- "files"; cfg_md$data_dir <- md; cfg_md$cohorts_csv <- "cohorts.csv"
reg_md <- discover_cohorts(cfg_md, md); sp_md <- cohort_spec(reg_md, "cohort")
check(sp_md$time == "followup_days" && sp_md$event == "death_flag" && !any(c("followup_days", "death_flag") %in% sp_md$covariates),
      "role columns fixed by cohorts.csv leave the guessed covariates")
check(nrow(prep_cohort(reg_md, "cohort", sp_md, 1)) > 100, "and the cohort prepares")
check(identical(attr(balance_table(d, xv, s), "sd_denominator"), "unadjusted pooled"), "SMDs share the unadjusted pooled SD")
dh <- d[1:200, ]; attr(dh, "xvars") <- xv; dh$time[1] <- s$chr_time; dh$event[1] <- 1L
hdh <- heterogeneity_data(dh, xv, s)
check(hdh$points$y[1] == 0, "an event exactly at the time counts as not alive")
cm <- tempfile("srccm"); dir.create(cm)
writeLines(c("# estimate_curves <- function(d, xvars, s, grid) example in a comment", "stop('this must never run')"), file.path(cm, "runner.R"))
sc_cm <- register_src_methods(cm)
check(grepl("^not a dashboard method", sc_cm$status[1]), "a signature in a comment does not get a script sourced")
writeLines(c("estimate_curves <- function(d, xvars, s, grid) km_curves(d, rep(1, nrow(d)), grid)", "helper <- function() 1"), file.path(cm, "m.R"))
writeLines("helper2 <- function() 1", file.path(cm, "util.R"))
invisible(register_src_methods(cm)); h1 <- METHODS[["src:m"]]$code_hash
writeLines("helper2 <- function() 2", file.path(cm, "util.R"))
invisible(register_src_methods(cm)); h2 <- METHODS[["src:m"]]$code_hash
check(h1 != h2, "editing any file under src/ changes every src/ method's cache key")
invisible(register_src_methods(file.path(cm, "nothing")))
pm <- tempfile("pm"); dir.create(pm)
utils::write.csv(pop[["ECOG"]], file.path(pm, "good_feature_table.csv"), row.names = FALSE)
writeLines(c("id,label,file,description", "ghost,Ghost,missing.csv,absent"), file.path(pm, "cohorts.csv"))
Sys.setenv(DASH_SOURCE = "files", DASH_DATA_DIR = pm, DASH_ALLOW_SYNTHETIC = "FALSE")
job3 <- suppressWarnings(system2(rscript, c("jobs/precompute.R", "--methods", "iptw_km"), stdout = TRUE, stderr = TRUE))
Sys.setenv(DASH_SOURCE = "synthetic", DASH_ALLOW_SYNTHETIC = "TRUE"); Sys.unsetenv("DASH_DATA_DIR")
check(identical(attr(job3, "status") %||% 0L, 1L) && length(list.files("output", pattern = "^precompute_.*\\.csv$")) > 0,
      sprintf("a job with one good and one missing cohort fails but still writes its summary (%s)", paste(utils::tail(job3, 1), collapse = "")))
unlink(list.files("output", pattern = "^precompute_.*\\.csv$", full.names = TRUE))
dinf <- mk(); dinf$duration[1:3] <- Inf
pinf <- prep_data(dinf, auto_spec(dinf), 1)
check(attr(pinf, "n_dropped") == 3 && attr(pinf, "drop_reasons")[["missing or non-finite time"]] == 3, "infinite durations are dropped and counted")
dw <- d; dw$w[5] <- NA; attr(dw, "xvars") <- xv
sw <- s; sw$use_provided_weights <- TRUE
rw <- run_method("iptw_km", dw, sw)
check(!rw$ok && grepl("weights column", rw$message), "a missing provided weight refuses the run instead of switching to fitted weights")
add_method("dup_label_test", "IPTW KM", "Test class", est_iptw_km)
check(METHODS[["dup_label_test"]]$label == "IPTW KM (estimators.R)", "a repeated label carries its file")
METHODS[["dup_label_test"]] <- NULL
check(all(c("method_id", "method_file", "data_hash", "code_hash") %in% names(results_estimates(res))), "flattened results carry ids and hashes")
check(is.character(res[["tmle_disc"]]$notes), "methods carry their notes")
cache_clear()
rcp <- run_method_cached("iptw_km", dc, s)
dir_now <- cache_dir(); unlink(dir_now, recursive = TRUE)
rcp2 <- run_method_cached("cox_rs", dc, s)
check(isTRUE(rcp2$ok) && identical(rcp2$stored, FALSE), "a cache write that cannot land reports stored = FALSE")
cache_reset(); invisible(cache_dir())

cat("third review: the gate on every path, discovery, naming, incomplete results, markers\n")
s_gate <- s; s_gate$extra_ps <- "assign('pwned_marker_2', 1, envir = globalenv())"
e1 <- tryCatch(ps_overlap(d, xv, s_gate), error = function(e) conditionMessage(e))
check(is.character(e1) && grepl("not allowed", e1) && !exists("pwned_marker_2", envir = globalenv()), "a diagnostic refuses a code term before evaluating it")
s_gate2 <- s; s_gate2$extra_out <- "assign('pwned_marker_3', 1, envir = globalenv())"
e2 <- tryCatch(ph_check(d, xv, s_gate2), error = function(e) conditionMessage(e))
check(is.character(e2) && grepl("not allowed", e2) && !exists("pwned_marker_3", envir = globalenv()), "the Schoenfeld check refuses it too")
s_gate3 <- s; s_gate3$extra_ps <- "log(age - 70)"
e3 <- tryCatch(balance_table(d, xv, s_gate3), error = function(e) conditionMessage(e))
check(is.character(e3) && grepl("missing or non-finite", e3), "a diagnostic refuses a term that would drop patients")
ns <- tempfile("srcns"); dir.create(ns)
writeLines('stats::setNames(1, "one")', file.path(ns, "unrelated.R"))
writeLines("estimate_curves <- function(d, xvars, s, grid) km_curves(d, rep(1, nrow(d)), grid)", file.path(ns, "ok.R"))
sc_ns <- tryCatch(register_src_methods(ns), error = function(e) e)
check(is.data.frame(sc_ns) && grepl("^not a dashboard method", sc_ns$status[sc_ns$file == "unrelated.R"]) && "src:ok" %in% names(METHODS),
      "a namespaced call in an unrelated script is harmless and the method beside it registers")
invisible(register_src_methods(file.path(ns, "none")))
dn <- mk(); dn$`x a` <- rnorm(nrow(dn)); dn$`x-a` <- rnorm(nrow(dn)) * 5
spa <- auto_spec(dn); spa$covariates <- c("age", "x a", "x-a"); spb <- spa; spb$covariates <- c("x-a", "x a", "age")
pa <- prep_data(dn, spa, 1); pb <- prep_data(dn, spb, 1)
check(identical(attr(pa, "xvar_labels"), attr(pb, "xvar_labels")) && identical(pa$x.a, pb$x.a), "internal names do not depend on the order covariates were picked in")
check(identical(cohort_data_hash(COHORTS, "ECOG", spa), cohort_data_hash(COHORTS, "ECOG", spb)), "so the two orders are one analysis")
s_inc <- s; s_inc$tmle_max_iter <- 1; s_inc$tmle_tol <- 1e-12
r_inc <- run_method("tmle_disc", d, s_inc)
check(isTRUE(r_inc$ok) && !is.na(r_inc$incomplete) && all(is.na(r_inc$estimates$ci_type)) && all(is.na(r_inc$estimates$lower)),
      "unconverged targeting gives an incomplete result without intervals")
check(results_status(list(r_inc))$status[1] == "incomplete", "the status says incomplete")
cache_clear()
rci <- run_method_cached("tmle_disc", dc, s_inc)
check(!isTRUE(rci$stored) && cache_count() == 0, "an incomplete result is never cached")
check(length(pending_combinations(list("Fully restricted" = list(tmle_disc = r_inc)), "Fully restricted", "tmle_disc", s_inc, function(id) r_inc$data_hash)) == 1,
      "and the comparison still counts it as pending")
mk_dir <- tempfile("marked"); dir.create(mk_dir)
f1 <- file.path(mk_dir, "gen_feature_table.csv"); utils::write.csv(pop[["ECOG"]], f1, row.names = TRUE)
f2 <- file.path(mk_dir, "real_feature_table.csv"); r2 <- pop[["STAGE"]]; r2$age[1] <- r2$age[1] + 1; utils::write.csv(r2, f2, row.names = TRUE)
writeLines(paste(unname(tools::md5sum(f1)), basename(f1)), file.path(mk_dir, "SYNTHETIC.md5"))
cfg_mk <- DASH_CFG; cfg_mk$source <- "files"; cfg_mk$data_dir <- mk_dir; cfg_mk$cohorts_csv <- "none.csv"
reg_mk <- discover_cohorts(cfg_mk, mk_dir)
check(isTRUE(reg_mk$synthetic[reg_mk$id == "gen"]) && !isTRUE(reg_mk$synthetic[reg_mk$id == "real"]), "a file listed in SYNTHETIC.md5 is flagged synthetic, another file is not")
check(nrow(load_cohort(reg_mk, "gen")) == nrow(pop[["ECOG"]]), "a flagged file is still read from the file")
writeLines(c("id,label,file,synthetic", "real,Declared,real_feature_table.csv,TRUE"), file.path(mk_dir, "cohorts.csv"))
cfg_mk$cohorts_csv <- "cohorts.csv"
reg_mk2 <- discover_cohorts(cfg_mk, mk_dir)
check(isTRUE(reg_mk2$synthetic[reg_mk2$id == "real"]), "cohorts.csv can declare a file synthetic")
# the generated CSVs are not shipped (beside real files they would trip the production guard): the
# generator writes them, with their marker, into a folder of this run
syn_dir <- file.path(tempdir(), "dash-synth"); dir.create(syn_dir, showWarnings = FALSE)
Sys.setenv(DASH_SYNTH_DIR = syn_dir); invisible(capture.output(source(file.path(here, "data", "make_synthetic.R"), local = new.env()))); Sys.unsetenv("DASH_SYNTH_DIR")
check(file.exists(file.path(syn_dir, "SYNTHETIC.md5")) && length(list.files(syn_dir, pattern = "csv$")) == 8, "the generator writes the eight synthetic CSVs with their marker")
cfg_b <- DASH_CFG; cfg_b$source <- "files"; cfg_b$data_dir <- syn_dir; cfg_b$cohorts_csv <- "none.csv"
check(nrow(discover_cohorts(cfg_b, ".")) == 8 && all(discover_cohorts(cfg_b, ".")$synthetic), "the generated CSVs are recognised as generated in files mode")
check(all(c("method_hash", "status") %in% names(results_estimates(res))) && all(c("method_id", "method_hash", "data_hash") %in% names(results_curves(res))),
      "estimates and curves exports carry the method hash and status")
add_method("dup2_test", "IPTW KM", "Test class", est_iptw_km); add_method("dup3_test", "IPTW KM", "Test class", est_iptw_km)
check(!anyDuplicated(vapply(METHODS, `[[`, character(1), "label")), "three methods with one label and file get distinct labels")
METHODS[["dup2_test"]] <- NULL; METHODS[["dup3_test"]] <- NULL

cat("fourth review: replicates, manifest paths, cohort identity, status policy, uploads, settings\n")
calls2 <- new.env(); calls2$n <- 0L
add_method("inc_rep_test", "Incomplete replicates", "Test class", function(d, xvars, s, grid) {
  calls2$n <- calls2$n + 1L; cv <- km_curves(d, rep(1, nrow(d)), grid)
  if (calls2$n > 1) attr(cv, "incomplete") <- "replicate did not converge"; cv })
sr5 <- s; sr5$boot_B <- 5
rr5 <- run_method("inc_rep_test", d, sr5)
check(isTRUE(rr5$ok) && is.na(rr5$estimates$ci_type[1]) && rr5$estimates$boot_ok[1] == 0 && any(grepl("replicate incomplete", rr5$notes)),
      "incomplete replicates count as failed and leave no interval")
METHODS[["inc_rep_test"]] <- NULL
mp <- tempfile("manifest2"); dir.create(mp); wd <- tempfile("wd"); dir.create(wd)
a_df <- mk(); a_df$duration[1] <- 1; b_df <- mk(); b_df$duration[1] <- 100
utils::write.csv(a_df, file.path(mp, "trial.csv"), row.names = FALSE); utils::write.csv(b_df, file.path(wd, "trial.csv"), row.names = FALSE)
writeLines(c("id,label,file", "trial,Trial,trial.csv"), file.path(mp, "cohorts.csv"))
cfg_mp <- DASH_CFG; cfg_mp$source <- "files"; cfg_mp$data_dir <- mp; cfg_mp$cohorts_csv <- "cohorts.csv"
old_wd <- getwd(); setwd(wd)
reg_mp <- discover_cohorts(cfg_mp, mp); d_mp <- load_cohort(reg_mp, "trial")
setwd(old_wd)
check(d_mp$duration[1] == 1, "a relative manifest path resolves beside cohorts.csv, never in the working directory")
reg_same <- COHORTS; reg_same$label[reg_same$id %in% c("ECOG", "STAGE")] <- "Same label"
disp <- cohort_display(reg_same)
check(!anyDuplicated(disp) && grepl("\\[ECOG\\]", disp[["ECOG"]]), "two cohorts with one label get distinct display labels")
r_e <- run_methods("iptw_km", prep_cohort(COHORTS, "ECOG"), s, use_cache = FALSE)
r_s <- run_methods("iptw_km", prep_cohort(COHORTS, "STAGE"), s, use_cache = FALSE)
e_same <- rbind(results_estimates(r_e, "Same label"), results_estimates(r_s, "Same label"))
ct <- compare_table(e_same, "RD", 12)
check(nrow(ct) == 2 && all(ct$cohort == "Same label"), "the comparison table keeps both cohorts, keyed by id")
s_gate4 <- s; s_gate4$extra_out <- "log(age - 70)"; e_ph <- tryCatch(ph_check(d, xv, s_gate4), error = function(e) conditionMessage(e))
check(is.character(e_ph) && grepl("missing or non-finite", e_ph), "the Schoenfeld check refuses a term that would drop patients")
est_inc <- results_estimates(list(tmle_disc = r_inc))
check(all(est_inc$status == "incomplete") && all(grepl("\\(incomplete\\)", est_inc$method)), "an incomplete estimate is labelled wherever it appears")
ag_mix <- agreement_table(rbind(est, est_inc))
check(nrow(ag_mix) == nrow(agreement_table(est)) && !any(grepl("incomplete", c(ag_mix$min_method, ag_mix$max_method))), "agreement ignores incomplete estimates")
check(result_status(r_inc) == "incomplete" && result_status(res[["iptw_km"]]) == "ok" && result_status(rr) == "failed", "one status word for every consumer")
mm <- tempfile("srcmeta"); dir.create(mm)
writeLines(c('METHOD_REQUIRES <- function() "survival"', "estimate_curves <- function(d, xvars, s, grid) km_curves(d, rep(1, nrow(d)), grid)"), file.path(mm, "bad_meta.R"))
writeLines("estimate_curves <- function(d, xvars, s, grid) km_curves(d, rep(1, nrow(d)), grid)", file.path(mm, "good.R"))
sc_mm <- tryCatch(register_src_methods(mm), error = function(e) e)
check(is.data.frame(sc_mm) && grepl("^error", sc_mm$status[sc_mm$file == "bad_meta.R"]) && "src:good" %in% names(METHODS),
      "bad metadata is that script's error; the good script beside it registers")
invisible(register_src_methods(file.path(mm, "none")))
known <- known_synthetic_md5s(syn_dir)
check(length(known) == 8, "the bundled marker lists eight checksums")
up_syn <- tempfile(fileext = ".csv"); invisible(file.copy(file.path(syn_dir, "docetaxel_nivolumab_EC_ECOG_feature_table.csv"), up_syn))
st_u <- new_cohort_store()
reg_u <- upload_cohort(.empty_registry(), up_syn, "ecog_copy.csv", st_u, known, TRUE)
check(isTRUE(reg_u$synthetic[1]) && grepl("generated", reg_u$provenance[1]), "an upload of a generated file is recognised as generated")
e_u <- tryCatch(upload_cohort(.empty_registry(), up_syn, "ecog_copy.csv", st_u, known, FALSE), error = function(e) conditionMessage(e))
check(is.character(e_u) && grepl("generated data", e_u), "and refused under the production guard")
up_real <- tempfile(fileext = ".csv"); utils::write.csv(mk(), up_real, row.names = FALSE)
reg_u2 <- upload_cohort(.empty_registry(), up_real, "other.csv", st_u, known, FALSE)
check(!isTRUE(reg_u2$synthetic[1]) && grepl("not verified", reg_u2$provenance[1]), "an unknown upload is marked as not verified, never as real")
# a Windows process cannot hold an empty variable (setting "" unsets it), so the
# helper is checked with a getter that returns ""; the variable itself on other platforms
f_empty <- .env_chr_or_empty; environment(f_empty) <- list2env(list(Sys.getenv = function(k, unset = "") ""), parent = globalenv())
check(f_empty("DASH_CACHE_DIR", "output/cache") == "" && .env_chr_or_empty("DASH_NO_SUCH_VARIABLE_X", "d") == "d",
      "an empty DASH_CACHE_DIR turns the cache off; unset keeps the default")
if (.Platform$OS.type != "windows") { Sys.setenv(DASH_CACHE_DIR = ""); check(dashboard_config()$cache_dir == "", "and the config reads it so") }
Sys.setenv(DASH_CACHE_DIR = file.path(tempdir(), "dash-test-cache"))
Sys.setenv(DASH_BOOT_B = "3", DASH_TMLE_WIDTH = "4"); ds <- default_settings()
check(ds$boot_B == 3 && ds$tmle_width == 4, "every setting has an environment variable, so the Job can match any page")
Sys.unsetenv(c("DASH_BOOT_B", "DASH_TMLE_WIDTH"))

cat("fifth review: manifest misses, replicate counts, follow-up, metadata, RMST knots, headers, labels, markers\n")
mp2 <- tempfile("manifest3"); dir.create(mp2); wd2 <- tempfile("wd2"); dir.create(wd2)
utils::write.csv(mk(), file.path(wd2, "trial.csv"), row.names = FALSE)
writeLines(c("id,label,file", "trial,Trial,trial.csv"), file.path(mp2, "cohorts.csv"))
cfg_mp2 <- DASH_CFG; cfg_mp2$source <- "files"; cfg_mp2$data_dir <- mp2; cfg_mp2$cohorts_csv <- "cohorts.csv"
old_wd <- getwd(); setwd(wd2)
reg_mp2 <- discover_cohorts(cfg_mp2, mp2); e_mp2 <- tryCatch(load_cohort(reg_mp2, "trial"), error = function(e) e)
setwd(old_wd)
check(isTRUE(reg_mp2$missing_file[1]) && startsWith(normalizePath(reg_mp2$file[1], winslash = "/", mustWork = FALSE), normalizePath(mp2, winslash = "/")) && inherits(e_mp2, "error"),
      "a manifest file that is not beside the manifest is missing, never a same-named file in the working directory")
calls3 <- new.env(); calls3$n <- 0L
add_method("flat_ctrl_test", "Flat control in replicates", "Test class", function(d, xvars, s, grid) {
  calls3$n <- calls3$n + 1L; cv <- km_curves(d, rep(1, nrow(d)), grid)
  if (calls3$n > 1) cv$s0 <- rep(1, length(grid)); cv })
rf2 <- run_method("flat_ctrl_test", d, sr5)
e_rd <- rf2$estimates[rf2$estimates$estimand == "RD", ]; e_chr <- rf2$estimates[rf2$estimates$estimand == "CHR", ]
check(isTRUE(rf2$ok) && all(e_rd$boot_ok == 5) && all(e_rd$ci_type == "bootstrap") && e_chr$boot_ok == 0 && is.na(e_chr$ci_type) && is.na(e_chr$lower)
      && any(grepl("no interval for CHR", rf2$notes)) && is.na(rf2$evalue$ci_type),
      "an undefined CHR in the replicates leaves CHR without an interval while RD keeps its own")
METHODS[["flat_ctrl_test"]] <- NULL
d_short <- d; d_short$event[d_short$time > 3] <- 0L; d_short$time <- pmin(d_short$time, 3)
r_short <- run_method("iptw_km", d_short, s)
es <- r_short$estimates
check(isTRUE(r_short$ok) && !any(es$within_followup) && all(is.na(es$est)) && any(grepl("follow-up ends", r_short$notes)),
      "estimates past the end of follow-up are not reported, and the notes say why")
check(all(is.na(r_short$curves$s1[r_short$curves$time > 3])) && all(is.finite(r_short$curves$s1[r_short$curves$time <= 3])),
      "the curves stop where follow-up ends")
check(all(is.na(r_short$effect$rd[r_short$effect$time > 3])) && all(is.na(r_short$effect$rmst[r_short$effect$time > 3])) && is.na(r_short$evalue$rr)
      && all(is.na(r_short$hrt$hr[r_short$hrt$time > 3])) && all(is.finite(r_short$effect$rmst[r_short$effect$time <= 3])),
      "and so do the effect curves, the E-value and HR(t)")
ct_s <- compare_table(results_estimates(list(iptw_km = r_short), "Short"), "RD", 12)
check(nrow(ct_s) == 1 && ct_s[["IPTW KM"]] == "beyond follow-up", "the comparison cell says so")
d_mix <- d; one_arm <- d_mix$A == 1; d_mix$event[one_arm & d_mix$time > 10] <- 0L; d_mix$time[one_arm] <- pmin(d_mix$time[one_arm], 10)
r_mix <- run_method("cox_rs", d_mix, s); em <- r_mix$estimates
check(all(is.finite(em$est[em$time == 6])) && all(is.na(em$est[em$time >= 12])) && is.na(s_at(r_mix$curves, "s1", 12)) && is.finite(s_at(r_mix$curves, "s0", 12)),
      "one arm ending early ends the comparison, not the other arm's curve")
mm2 <- tempfile("srcmeta2"); dir.create(mm2)
writeLines(c("METHOD_CLASS <- NA_character_", "estimate_curves <- function(d, xvars, s, grid) km_curves(d, rep(1, nrow(d)), grid)"), file.path(mm2, "na_class.R"))
writeLines(c('METHOD_LABEL <- "  "', "estimate_curves <- function(d, xvars, s, grid) km_curves(d, rep(1, nrow(d)), grid)"), file.path(mm2, "blank_label.R"))
writeLines(c('METHOD_NOTE <- NA', 'METHOD_REQUIRES <- c("survival", NA, "")', "estimate_curves <- function(d, xvars, s, grid) km_curves(d, rep(1, nrow(d)), grid)"), file.path(mm2, "lenient.R"))
sc_mm2 <- register_src_methods(mm2)
check(all(grepl("^error", sc_mm2$status[sc_mm2$file %in% c("na_class.R", "blank_label.R")])) && "src:lenient" %in% names(METHODS)
      && identical(METHODS[["src:lenient"]]$requires, "survival") && identical(METHODS[["src:lenient"]]$note, ""),
      "an NA or blank label or class is that script's error; a blank note and blank list entries are dropped")
check(is.data.frame(methods_table()) && nrow(methods_table()) > 0, "and the registry still renders")
e_am <- tryCatch(add_method("na_test", NA_character_, "Test class", function(d, xvars, s, grid) NULL), error = function(e) conditionMessage(e))
check(is.character(e_am) && grepl("non-empty", e_am), "the registry itself refuses a missing label")
invisible(register_src_methods(file.path(mm2, "none")))
g_k <- make_grid(s, d)
check(length(g_k) > length(make_grid(s)) && all(make_grid(s) %in% g_k) && all(unique(d$time[d$event == 1 & d$time <= 18]) %in% g_k),
      "the grid carries the regular points and every distinct event time up to the horizon")
cv_k <- km_curves(d, rep(1, nrow(d)), g_k)
rm_k <- summary(survival::survfit(Surv(time, event) ~ A, data = d), rmean = 12)$table[, "rmean"]
check(abs(rmst_at(cv_k, "s0", 12) - rm_k[["A=0"]]) < 1e-8 && abs(rmst_at(cv_k, "s1", 12) - rm_k[["A=1"]]) < 1e-8,
      "the Kaplan-Meier RMST equals survival's restricted mean to 1e-8")
cv_c <- km_curves(d, rep(1, nrow(d)), make_grid(s))
check(abs(rmst_at(cv_c, "s1", 12) - rm_k[["A=1"]]) > 1e-6, "which the regular grid alone did not give")
s_big <- s; s_big$grid_knots <- 20
g_b <- make_grid(s_big, d)
check(length(g_b) <= length(make_grid(s)) + 20 && grepl("distinct event times", attr(g_b, "note")), "beyond the cap the knots are thinned and the grid says so")
r_kn <- run_method("iptw_km", d, s_big)
check(isTRUE(r_kn$ok) && any(grepl("distinct event times", r_kn$notes)), "and the result carries that note")
dup_csv <- tempfile(fileext = ".csv")
writeLines(c("patientid,duration,event,treatment,age,age", "p1,10,1,1,60,61", "p2,20,0,0,70,71"), dup_csv)
e_dup <- tryCatch(read_cohort_file(dup_csv), error = function(e) conditionMessage(e))
check(is.character(e_dup) && grepl("repeated column names", e_dup) && grepl("age", e_dup), "a file with two 'age' columns is refused and names the column")
e_dup2 <- tryCatch(upload_cohort(.empty_registry(), dup_csv, "dup.csv", new_cohort_store()), error = function(e) conditionMessage(e))
check(is.character(e_dup2) && grepl("repeated column names", e_dup2), "an upload too")
reg_t <- data.frame(id = c("a", "b", "c"), label = c("Trial", "Trial", "Trial [a]"), stringsAsFactors = FALSE)
disp_t <- cohort_display(reg_t)
check(!anyDuplicated(disp_t) && identical(names(disp_t), c("a", "b", "c")), "labels that collide after the id suffix are still told apart")
p_sz <- tryCatch(plot_cohort_sizes(data.frame(cohort = unname(disp_t), n = c(10, 20, 30), events = c(5, 6, 7), n_treated = c(4, 8, 12))), error = function(e) e)
check(!inherits(p_sz, "error"), "and the cohort-size plot draws")
add_method("bad_marker_test", "Bad marker", "Test class", function(d, xvars, s, grid) { cv <- km_curves(d, rep(1, nrow(d)), grid); attr(cv, "incomplete") <- NA_character_; cv })
r_bm <- run_method("bad_marker_test", d, s)
check(!isTRUE(r_bm$ok) && grepl("incomplete", r_bm$message) && result_status(r_bm) == "failed", "attr incomplete = NA is a failure with the reason")
cache_clear(); r_bmc <- run_method_cached("bad_marker_test", dc, s)
check(!isTRUE(r_bmc$stored) && cache_count() == 0, "and nothing is cached")
METHODS[["bad_marker_test"]] <- NULL

cat("sixth review: resample support, zero tails, knots, diagnostics, grid settings\n")
d_rep <- d; late <- d_rep$time > 6; d_rep$event[late] <- 0L; d_rep$time[late] <- 6
i1 <- which(d_rep$A == 1)[1]; i0 <- which(d_rep$A == 0)[1]; d_rep$time[c(i1, i0)] <- 18.5; d_rep$event[c(i1, i0)] <- 0L
s20 <- s; s20$boot_B <- 20
r_rep <- run_method("iptw_km", d_rep, s20); er <- r_rep$estimates
check(isTRUE(r_rep$ok) && all(er$within_followup) && all(er$ci_type[er$time == 6] == "bootstrap") && all(er$boot_ok[er$time == 6] == 20)
      && all(is.na(er$ci_type[er$time >= 12])) && all(er$boot_ok[er$time >= 12] < 16) && any(grepl("no interval for RD at 12", r_rep$notes)),
      "a resample is clipped at its own follow-up: intervals only where most resamples reach the time")
check(all(is.finite(r_rep$effect$rd_lower[r_rep$effect$time <= 6])) && all(is.na(r_rep$effect$rd_lower[r_rep$effect$time > 6.5])),
      "and the effect bands stop there too")
d_z <- d; d_z$event <- 1L; d_z$time <- pmin(d_z$time, 3)
r_z <- run_method("iptw_km", d_z, s); ez <- r_z$estimates
check(isTRUE(r_z$ok) && all(ez$within_followup) && all(is.finite(ez$est[ez$estimand != "CHR"])) && !any(grepl("follow-up ends", r_z$notes))
      && all(r_z$curves$s1[r_z$curves$time > 3] == 0),
      "with every patient dead by 3 the zero tail is kept and RMST at 6, 12 and 18 is reported")
g_z <- make_grid(s, d_z); cv_z <- km_curves(d_z, rep(1, nrow(d_z)), g_z)
rm_z <- summary(survival::survfit(Surv(time, event) ~ A, data = d_z), rmean = 12)$table[, "rmean"]
check(abs(rmst_at(cv_z, "s1", 12) - rm_z[["A=1"]]) < 1e-8, "and equals the restricted mean beyond the last event")
jumpy <- function(d, xvars, s, grid) {
  cv <- data.frame(time = grid, s1 = ifelse(grid < 2.5, 1, ifelse(grid < 7.5, 0.5, 0.25)), s0 = ifelse(grid < 7.5, 1, 0.5))
  attr(cv, "step") <- TRUE; cv }
add_method("jump_plain", "Jumps, undeclared", "Test class", jumpy)
add_method("jump_knots", "Jumps, declared", "Test class", jumpy, knots = function(d, s, tmax) c(2.5, 7.5))
r_jp <- run_method("jump_plain", d, s); r_jk <- run_method("jump_knots", d, s)
rm_at <- function(r, t) r$estimates$est[r$estimates$estimand == "RMST" & r$estimates$time == t]
check(isTRUE(r_jk$ok) && abs(rm_at(r_jk, 6) - (-1.75)) < 1e-9 && all(c(2.5, 7.5) %in% r_jk$curves$time), "declared knots go on the grid and the RMST is exact")
check(isTRUE(r_jp$ok) && abs(rm_at(r_jp, 6) - (-1.75)) > 1e-3, "without them the same curves integrate to something else")
e_kn <- tryCatch(add_method("jump_bad", "Bad knots", "Test class", jumpy, knots = 5), error = function(e) conditionMessage(e))
check(is.character(e_kn) && grepl("knots", e_kn), "knots must be a function")
METHODS[["jump_plain"]] <- NULL; METHODS[["jump_knots"]] <- NULL
mk3 <- tempfile("srcknots"); dir.create(mk3)
writeLines(c("METHOD_KNOTS <- function(d, s, tmax) c(2.5, 7.5)",
             "estimate_curves <- function(d, xvars, s, grid) { cv <- data.frame(time = grid, s1 = ifelse(grid < 2.5, 1, 0.5), s0 = rep(1, length(grid))); attr(cv, 'step') <- TRUE; cv }"),
           file.path(mk3, "knotted.R"))
writeLines(c("METHOD_KNOTS <- 5", "estimate_curves <- function(d, xvars, s, grid) km_curves(d, rep(1, nrow(d)), grid)"), file.path(mk3, "badknots.R"))
sc3 <- register_src_methods(mk3)
r_sk <- if ("src:knotted" %in% names(METHODS)) run_method("src:knotted", d, s) else NULL
check(!is.null(r_sk) && isTRUE(r_sk$ok) && abs(rm_at(r_sk, 6) - (-1.75)) < 1e-9 && grepl("^error", sc3$status[sc3$file == "badknots.R"]),
      "METHOD_KNOTS in a script works the same way, and a non-function is that script's error")
invisible(register_src_methods(file.path(mk3, "none")))
check(is.function(METHODS[["aiptw_cox"]]$knots) && is.function(METHODS[["plr_rs"]]$knots) && is.function(METHODS[["tmle_disc"]]$knots),
      "AIPTW declares every observed time, the discrete-time methods their bin ends")
cens_t <- setdiff(unique(d$time[d$event == 0 & d$time <= 18]), unique(d$time[d$event == 1]))[1]
r_ai <- run_method("aiptw_cox", d, s)
check(isTRUE(r_ai$ok) && is.finite(cens_t) && cens_t %in% r_ai$curves$time, "so an AIPTW run has a censoring time on its grid")
rt_s <- risk_table(d_short, c(2, 6, 12))
check(all(is.finite(rt_s$surv[rt_s$time == 2])) && all(is.na(rt_s$surv[rt_s$time >= 6])) && all(rt_s$at_risk[rt_s$time >= 6] == 0),
      "the risk table shows no survival value past follow-up, and the zero at risk stays")
rt_z <- risk_table(d_z, 6)
check(all(rt_z$surv == 0), "a zero tail is shown as zero")
s_inf <- s; s_inf$grid_knots <- Inf
check(any(grepl("grid knots", settings_problems(s_inf, xv))), "an infinite knot cap is refused before any run")
r_inf <- run_method("iptw_km", d, s_inf)
check(!isTRUE(r_inf$ok) && grepl("grid knots", r_inf$message), "and a run under it is a failure with the message, not a closed session")
s_gp <- s; s_gp$grid_points <- 5.5
check(any(grepl("grid points", settings_problems(s_gp, xv))), "grid points must be a whole number of at least 11")
g_na <- make_grid(local({ t <- s; t$grid_knots <- NA; t }), d)
check(is.numeric(g_na) && length(g_na) > 61, "make_grid itself survives a missing cap")

cat("seventh review: zero tails by the data, knots per resample, a caller's grid in the cache key\n")
d_c <- d; ctl <- d_c$A == 0; d_c$event[ctl & d_c$time > 3] <- 0L; d_c$time[ctl] <- pmin(d_c$time[ctl], 3)
r_ac <- run_method("aiptw_cox", d_c, s); ea <- r_ac$estimates
check(isTRUE(r_ac$ok) && all(is.na(ea$est)) && !any(ea$within_followup) && all(is.na(r_ac$curves$s0[r_ac$curves$time > 3])),
      "an AIPTW curve past a censored arm's follow-up is not an estimate, whatever value it was clipped to")
em_z <- risk_set_emptied(d_z); em_c <- risk_set_emptied(d_c)
check(all(em_z) && !em_c[["s0"]], "a zero tail is a fact of the data: the arm's risk set emptied with an event")
check(all(is.finite(run_method("iptw_km", d_z, s)$estimates$est)), "which still keeps the Kaplan-Meier zero tail")
q_jump <- function(d, xvars, s, grid) {
  q <- unname(stats::quantile(d$time, 0.25))
  cv <- data.frame(time = grid, s1 = ifelse(grid < q, 1, 0.5), s0 = rep(1, length(grid)))
  attr(cv, "step") <- TRUE; cv }
add_method("qjump_test", "Jump at the lower quartile", "Test class", q_jump, knots = function(d, s, tmax) unname(stats::quantile(d$time, 0.25)))
s10 <- s; s10$boot_B <- 10
r_q <- run_method("qjump_test", d, s10)
set.seed(s10$seed)
exact <- vapply(seq_len(10), function(b) { i <- sample.int(nrow(d), replace = TRUE); q <- unname(stats::quantile(d$time[i], 0.25)); -max(0, 6 - q) / 2 }, numeric(1))
rq <- r_q$estimates[r_q$estimates$estimand == "RMST" & r_q$estimates$time == 6, ]
check(isTRUE(r_q$ok) && abs(rq$lower - stats::quantile(exact, 0.025, names = FALSE)) < 1e-9 && abs(rq$upper - stats::quantile(exact, 0.975, names = FALSE)) < 1e-9
      && abs(rq$se - stats::sd(exact)) < 1e-9,
      "a knot that moves with the resample is recomputed for every replicate: the bootstrap matches the exact calculation")
check(all(is.finite(r_q$effect$rd_lower[r_q$effect$time <= 12])), "and the bands are the replicate curves aligned to the main grid")
METHODS[["qjump_test"]] <- NULL
cache_clear()
add_method("jump_knots2", "Jumps, declared again", "Test class", jumpy, knots = function(d, s, tmax) c(2.5, 7.5))
r_cg <- run_method_cached("jump_knots2", dc, s, grid = make_grid(s))
r_cd <- run_method_cached("jump_knots2", dc, s)
check(isTRUE(r_cg$stored) && !isTRUE(r_cd$from_cache) && abs(rm_at(r_cd, 6) - (-1.75)) < 1e-9 && abs(rm_at(r_cg, 6) - (-1.75)) > 1e-3,
      "a result computed on a caller's grid is not served to a default-grid request")
METHODS[["jump_knots2"]] <- NULL; cache_clear()

cat("production run: blank headers, the covariate guess on a real-shaped file\n")
set.seed(7)
wide <- mk(400)
wide$startdate <- format(as.Date("2019-01-01") + sample.int(900, 400, TRUE))
wide$sparse <- ifelse(stats::runif(400) < 0.8, NA_real_, stats::rnorm(400))
wide$notes <- paste("note", sample.int(400, 400, TRUE))
wide$const <- 1
wide$site <- sample(paste0("site", 1:60), 400, TRUE)
wide$flag <- sample(c(TRUE, FALSE), 400, TRUE)
wide$allna <- NA_real_
blank_csv <- tempfile(fileext = ".csv")
utils::write.csv(wide, blank_csv, row.names = TRUE)          # a blank first header, as pandas writes one
raw_b <- read_cohort_file(blank_csv)
check(identical(names(raw_b)[1], "unnamed_1") && all(nzchar(names(raw_b))), "a blank header gets a name")
mk_params <- function(df) { cols <- lapply(seq_along(names(df)) - 1L, function(i) list(data = as.character(i), name = names(df)[i + 1], searchable = "true", orderable = "true", search = list(value = "", regex = "false"))); names(cols) <- as.character(seq_along(cols) - 1L); list(draw = "1", start = "0", length = "8", search = list(value = "", regex = "false"), order = list(), columns = cols, escape = "true") }
r_dt <- tryCatch({ DT:::dataTablesFilter(utils::head(raw_b, 20), mk_params(utils::head(raw_b, 20))); "ok" }, error = function(e) conditionMessage(e))
check(identical(r_dt, "ok"), "the table code that broke on a blank header accepts the file now")
sp_w <- auto_spec(raw_b); left <- attr(sp_w, "left_out")
check(!any(c("unnamed_1", "startdate", "sparse", "notes", "const", "site", "allna") %in% sp_w$covariates) && all(c("age", "flag") %in% sp_w$covariates),
      "the guess leaves out the index, the start date, a mostly missing column, free text, a constant and many-level text")
check(all(c("sparse", "notes", "const", "site", "allna") %in% names(left)) && grepl("missing", left[["sparse"]]) && identical(sp_w$start_col, "startdate") && left[["site"]] == "60 distinct text values",
      "and says why")
d_w <- prep_data(raw_b, sp_w, 1)
check(nrow(d_w) > 300 && !length(attr(d_w, "covariate_missing")), "so the cohort is usable as guessed")
sp_s <- sp_w; sp_s$covariates <- c("age", "sparse")
d_s <- prep_data(raw_b, sp_s, 1); cm <- attr(d_s, "covariate_missing")
check(cm[["sparse"]] > 250 && !("age" %in% names(cm)) && identical(data_summary(d_s)$covariate_missing, cm), "dropped rows are counted by covariate")
sp_n <- sp_w; sp_n$covariates <- "allna"
e_n <- tryCatch(prep_data(raw_b, sp_n, 1), error = function(e) conditionMessage(e))
check(is.character(e_n) && grepl("missing by covariate: allna 400", e_n), "and an unusable mapping names the covariate responsible")

cat("blank text covariates as a category of their own\n")
set.seed(11)
bl <- mk(300)
bl$pdl1 <- sample(c("positive", "negative", NA), 300, TRUE, prob = c(0.4, 0.4, 0.2))
bl$lab <- ifelse(stats::runif(300) < 0.1, NA_real_, stats::rnorm(300))
bl$sparse_txt <- ifelse(stats::runif(300) < 0.6, NA, sample(c("x", "y"), 300, TRUE))
sp_bl <- auto_spec(bl); left_bl <- attr(sp_bl, "left_out")
check(isTRUE(sp_bl$missing_as_level) && all(c("pdl1", "lab") %in% sp_bl$covariates) && !("sparse_txt" %in% sp_bl$covariates) && grepl("blank", left_bl[["sparse_txt"]]),
      "the option is on by default; a text column with some blanks is guessed, a mostly blank one is not")
d_bl <- prep_data(bl, sp_bl, 1); ml <- attr(d_bl, "missing_as_level")
sp_off <- sp_bl; sp_off$missing_as_level <- FALSE
d_off <- prep_data(bl, sp_off, 1)
check("missing" %in% levels(d_bl$pdl1) && !anyNA(d_bl$pdl1) && ml[["pdl1"]] == nrow(d_bl) - nrow(d_off) && !("lab" %in% names(ml)),
      "a blank status is the level missing and the rows stay; a blank number still excludes the row")
check(!("missing" %in% levels(d_off$pdl1)) && nrow(d_off) < nrow(d_bl) && is.null(attr(d_off, "missing_as_level")) || length(attr(d_off, "missing_as_level")) == 0,
      "with the option off the rows are excluded as before")
check(identical(data_summary(d_bl)$missing_as_level, ml), "and the Data page gets the counts")
sp_csv <- apply_spec_overrides(sp_bl, data.frame(missing_as_level = "FALSE", stringsAsFactors = FALSE))
check(identical(sp_csv$missing_as_level, FALSE) && identical(apply_spec_overrides(sp_bl, data.frame(x = 1))$missing_as_level, TRUE), "cohorts.csv can turn it off per cohort; blank keeps the default")
sp_e1 <- cohort_spec(COHORTS, "ECOG"); sp_e2 <- sp_e1; sp_e2$missing_as_level <- FALSE
check(cohort_data_hash(COHORTS, "ECOG", sp_e1) != cohort_data_hash(COHORTS, "ECOG", sp_e2), "the choice is part of the analysis identity")
r_bl <- run_method("cox_rs", d_bl, s)
check(isTRUE(r_bl$ok), "a model runs with the extra level")

cat("adapters in the dashboard's own methods/ folder\n")
m1 <- tempfile("srcA"); dir.create(m1); m2 <- file.path(tempfile("dash"), "methods"); dir.create(m2, recursive = TRUE)
writeLines("estimate_curves <- function(d, xvars, s, grid) km_curves(d, rep(1, nrow(d)), grid)", file.path(m1, "study_one.R"))
writeLines(c('METHOD_LABEL <- "Adapter one"', "estimate_curves <- function(d, xvars, s, grid) km_curves(d, rep(1, nrow(d)), grid)"), file.path(m2, "adapter_one.R"))
writeLines("estimate_curves <- function(d, xvars, s, grid) km_curves(d, rep(1, nrow(d)), grid)", file.path(m2, "study_one.R"))
sc2 <- register_src_methods(c(m2, m1))
check(all(c("src:adapter_one", "src:study_one") %in% names(METHODS)) && nrow(sc2) == 3 && sum(grepl("^error: duplicate", sc2$status)) == 1 && "folder" %in% names(sc2),
      "scripts from both folders register; a name taken twice is the second script's error")
tab3 <- methods_table()
check(tab3$source[tab3$id == "src:adapter_one"] == "methods/" && tab3$source[tab3$id == "src:study_one"] == "methods/", "the table says which folder a method came from")
h_a <- METHODS[["src:adapter_one"]]$code_hash
writeLines("# a study file changed", file.path(m1, "helper.R"))
invisible(register_src_methods(c(m2, m1)))
check(METHODS[["src:adapter_one"]]$code_hash != h_a, "an adapter's cache key covers the study folder too")
check(nrow(register_src_methods(c(file.path(m1, "none"), file.path(m2, "none")))) == 0, "two missing folders are no scripts, not an error")

cat("describing the study functions without their code\n")
fr <- tempfile("fakerepo"); dir.create(file.path(fr, "src", "analysis"), recursive = TRUE)
writeLines(c("#' @param data the cohort", "#' @return list with surv",
             "run_a_analysis <- function(data, covariates, times = c(6, 12), time_var = \"time\", event_var = \"event\", trt_var = \"A\") {",
             "  secret_body_marker <- 1",
             "  list(surv = data.frame(time = times, surv_treated = 0.5, surv_control = 0.4), method = \"A\")",
             "}"), file.path(fr, "src", "analysis", "run_a_analysis.R"))
writeLines("run_b_analysis <- function(dat, special) stop(\"needs special\")", file.path(fr, "src", "analysis", "run_b_analysis.R"))
old_src <- Sys.getenv("DASH_SRC_DIR", unset = NA); Sys.setenv(DASH_SRC_DIR = file.path(fr, "src"))
dj <- suppressWarnings(system2(rscript, c("jobs/describe_src.R", "--try"), stdout = TRUE, stderr = TRUE))
if (is.na(old_src)) Sys.unsetenv("DASH_SRC_DIR") else Sys.setenv(DASH_SRC_DIR = old_src)
sig <- if (file.exists("output/src_signatures.txt")) readLines("output/src_signatures.txt") else character()
check(any(grepl("run_a_analysis(data, covariates, times = c(6, 12)", sig, fixed = TRUE)) && any(grepl("@return list with surv", sig, fixed = TRUE)),
      "the description lists each function with its arguments and documented return")
check(any(grepl("$surv_treated: numeric", sig, fixed = TRUE)) && any(grepl("FAILED: needs special", sig, fixed = TRUE)),
      "with --try it gives the shape of each result, or the reason a call failed")
check(!any(grepl("secret_body_marker", sig, fixed = TRUE)), "and no line of a function body")
unlink("output/src_signatures.txt")

source(file.path(here, "tests", "study_tests.R"))      # the study's functions as methods; patients without a duration

cat("app wiring\n")
app <- paste(readLines("app.R", warn = FALSE), collapse = "\n")
check(!any(vapply(tab$label, function(l) grepl(l, app, fixed = TRUE), logical(1))), "app.R names no method: the registry does")
check(!any(vapply(COHORTS$id, function(l) grepl(l, app, fixed = TRUE), logical(1))), "app.R names no cohort: the source does")
check(grepl("methods_table()", app, fixed = TRUE) && grepl("COHORTS", app, fixed = TRUE), "app.R reads both registries")
check(grepl("0.0.0.0", readLines("app.sh", warn = FALSE) |> paste(collapse = "\n"), fixed = TRUE), "app.sh binds 0.0.0.0:8888 for Domino")

cat("shiny session\n")
if (requireNamespace("shiny", quietly = TRUE)) {
  # loaded the way runApp() loads it (R/ autoload rules, global.R, app.R), not by source()
  app <- tryCatch(suppressPackageStartupMessages(shiny::shinyAppDir(".")), error = function(e) e)
  check(!inherits(app, "error"), paste("the app loads the way runApp loads it", if (inherits(app, "error")) conditionMessage(app) else ""))
  if (inherits(app, "error")) app <- suppressPackageStartupMessages(source("app.R", local = new.env())$value)
  check(getOption("shiny.maxRequestSize") == DASH_CFG$max_upload_mb * 1024^2, "the upload limit is applied to Shiny")
  session_ok <- tryCatch({
    shiny::testServer(app, {
      session$setInputs(cmp_estimand = "CHR")                  # once produced if (logical(0))
      session$setInputs(cmp_estimand = "RD", cohort = "ECOG", time_divisor = 30.4375, res_estimand = "RD")
      stopifnot(!session$isClosed())
      stopifnot(grepl("^[0-9,]+$", output$vb_n))               # the Data page summarises the cohort
      stopifnot(identical(output$vb_dropped, format(attr(prep_cohort(COHORTS, "ECOG"), "n_dropped"), big.mark = ",")))
    })
    "ok"
  }, error = function(e) conditionMessage(e))
  check(identical(session_ok, "ok"), paste("a new session initialises, takes inputs and renders the Data page", if (!identical(session_ok, "ok")) session_ok else ""))
} else cat("  SKIP    shiny not installed\n")

cat(sprintf("\n%d passed, %d failed\n", pass, fail))
if (fail > 0) quit(status = 1)
