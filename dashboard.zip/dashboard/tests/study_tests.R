# Sourced by tests/run_tests.R (it uses its check(), d, s, here): the study's
# run_*_analysis functions wrapped without adapters, and patients who have no
# event and no duration. The functions under tests/fixtures/analysis are
# stand-ins shaped like study code, not study methods.

cat("the study's run_*_analysis functions as methods, without adapters\n")
fx <- file.path(here, "tests", "fixtures", "analysis")
for (id in grep("^src:", names(METHODS), value = TRUE)) METHODS[[id]] <- NULL
au <- register_study_methods(fx, repo_root = here)
check(nrow(au) == 10 && sum(au$status == "registered (auto-adapted)") == 9 && sum(grepl("^error: the script could not be loaded", au$status)) == 1 &&
        !("helpers.R" %in% au$file),
      "every run_*_analysis function is found by name; a script that cannot be loaded is that script's error; helpers are left alone")
tabA <- methods_table(); rowA <- function(id) tabA[tabA$id == id, ]
check(startsWith(rowA("src:run_iptw_cox_analysis")$label, "IPTW Cox") && rowA("src:run_iptw_cox_analysis")$file == "run_iptw_cox_analysis.R" &&
        rowA("src:run_iptw_cox_analysis")$class == "Singly Robust (IPW)" && rowA("src:run_cox_regstand_analysis")$class == "Singly Robust (G-comp)" &&
        rowA("src:run_aiptw_cox_analysis")$class == "Doubly Robust (AIPTW)" && rowA("src:run_dr_plr_logit_analysis")$class == "Doubly Robust (DR Stand)" &&
        rowA("src:run_ltmle_survival_analysis")$class == "Doubly Robust (TMLE)" && rowA("src:run_ltmle_survival_analysis")$speed == "slow" &&
        rowA("src:run_aiptw_discrete_plr_analysis")$label == "AIPTW Discrete PLR" && rowA("src:run_naive_iptw_fpm_regstand_analysis")$class == "Naive DR",
      "label, class and speed come from the function's name, and the file is shown")
check(!anyDuplicated(tabA$label), "a study method that shares a reference method's name is told apart by its file")
four <- c("src:run_iptw_cox_analysis", "src:run_cox_regstand_analysis", "src:run_aiptw_cox_analysis", "src:run_fpm_regstand_analysis")
r_hp <- run_method("src:run_naive_iptw_fpm_regstand_analysis", d, s)
check(isTRUE(r_hp$ok), "a function that calls a helper from another file runs, and the helper is given the column names it asks for")
check(!is_definition_file(file.path(fx, "run_broken_analysis.R")) && is_definition_file(file.path(fx, "helpers.R")), "only files that define things are loaded as helpers; a runner is never executed")
ra <- run_methods(four, d, s, use_cache = FALSE)
km_d <- km_curves(d, rep(1, nrow(d)), make_grid(s))
rd_km <- s_at(km_d, "s1", 12) - s_at(km_d, "s0", 12)
rd_of <- function(r) r$estimates$est[r$estimates$estimand == "RD" & r$estimates$time == 12]
check(all(vapply(ra, function(r) isTRUE(r$ok), logical(1))) && all(abs(vapply(ra, rd_of, numeric(1)) - rd_km) < 1e-8),
      "a wide table, a long table, a pair of vectors and cumulative risks are all read as the same two curves")
check(all(vapply(ra, function(r) any(grepl("^auto-adapted: ", r$notes)), logical(1))) &&
        any(grepl("columns surv_treated and surv_control", ra[["src:run_iptw_cox_analysis"]]$notes)) &&
        any(grepl("turned into survival", ra[["src:run_fpm_regstand_analysis"]]$notes)),
      "each result says how the function was called and where its curves were read")
check(all(c("status", "trt") %in% names(study_data(d, attr(d, "xvars"), script_tokens(file.path(fx, "run_cox_regstand_analysis.R"))))) &&
        !any(c("status", "trt") %in% names(study_data(d, attr(d, "xvars"), script_tokens(file.path(fx, "run_iptw_cox_analysis.R"))))),
      "a script's own names for time, event and treatment are supplied, and only those it uses")
r_lt <- run_method("src:run_ltmle_survival_analysis", d, s)
check(isTRUE(r_lt$ok) && abs(rd_of(r_lt) - rd_km) < 1e-8 && any(grepl("read linearly", r_lt$notes)),
      "a slow method is asked only for the report times, and the result says its curve is coarse")
r_e <- run_method("src:run_dr_plr_logit_analysis", d, s); r_h <- run_method("src:run_aiptw_discrete_plr_analysis", d, s); r_a <- run_method("src:run_ambiguous_analysis", d, s)
check(!isTRUE(r_e$ok) && grepl("no pair of survival curves", r_e$message), "a function that returns estimates but no curves fails with that reason")
check(!isTRUE(r_h$ok) && grepl("L1", r_h$message), "a function with the simulation's covariate names built in fails with its own error")
check(!isTRUE(r_a$ok) && grepl("cannot be told apart", r_a$message), "arms coded 1 and 2 are refused, not guessed")
r_b <- { sb <- s; sb$boot_B <- 3; run_method("src:run_iptw_cox_analysis", d, sb) }
check(isTRUE(r_b$ok) && identical(r_b$estimates$ci_type[r_b$estimates$estimand == "RD" & r_b$estimates$time == 6], "bootstrap"),
      "a study function gets bootstrap intervals like any other method")
for (id in grep("^src:", names(METHODS), value = TRUE)) METHODS[[id]] <- NULL
au2 <- register_study_methods(fx, taken = "run_iptw_cox_analysis", repo_root = here)
check(au2$status[au2$file == "run_iptw_cox_analysis.R"] == "an adapter in methods/ stands for it" && !("src:run_iptw_cox_analysis" %in% names(METHODS)),
      "an adapter in methods/ takes the place of the automatic wrapper")
for (id in grep("^src:", names(METHODS), value = TRUE)) METHODS[[id]] <- NULL
check(nrow(register_study_methods(file.path(fx, "none"))) == 0, "no analysis folder is no study methods, not an error")

cat("patients without an event and without a duration\n")
set.seed(21); n_c <- 400
cz <- data.frame(patientid = sprintf("p%03d", seq_len(n_c)), treatment = rep(0:1, n_c / 2), age = stats::rnorm(n_c, 60, 8), stringsAsFactors = FALSE)
cz$startdate <- format(as.Date("2020-01-01") + sample.int(600, n_c, TRUE))
true_t <- stats::rexp(n_c, 1 / 400); died <- true_t < 500
cz$duration <- ifelse(died, round(true_t) + 1, NA)          # days to death; blank for the patients still alive
cz$event <- 1                                               # an event column that is 1 on every row
sp_c <- auto_spec(cz)
check(isTRUE(sp_c$event_from_time) && sp_c$start_col == "startdate" && !("startdate" %in% sp_c$covariates),
      "an all-1s event column is not used: the event is 'a duration is recorded', and the start date is found")
d_c2 <- prep_data(cz, sp_c, 1)
cut_d <- max(as.Date(cz$startdate) + cz$duration, na.rm = TRUE)
exp_t <- ifelse(died, cz$duration, as.numeric(cut_d - as.Date(cz$startdate)))
check(nrow(d_c2) == sum(exp_t > 0) && sum(d_c2$event) == sum(died) && all(abs(sort(d_c2$time) - sort(exp_t[exp_t > 0])) < 1e-9) &&
        grepl("data cut-off", attr(d_c2, "censor_note")) && isTRUE(data_summary(d_c2)$event_from_time),
      "patients without an event are followed to the data cut-off, so nobody is lost, and the page is told")
cz$fu_days <- ifelse(died, NA, 300); sp_fu <- sp_c; sp_fu$censor_col <- "fu_days"
d_fu <- prep_data(cz, sp_fu, 1)
check(all(d_fu$time[d_fu$event == 0] == 300) && grepl("fu_days", attr(d_fu, "censor_note")), "a mapped follow-up column is used first")
cz$lastvisit <- format(as.Date(cz$startdate) + 200); sp_ld <- sp_c; sp_ld$censor_col <- "lastvisit"
d_ld <- prep_data(cz, sp_ld, 1)
check(all(d_ld$time[d_ld$event == 0] == 200), "a follow-up date is read as that date minus the start date")
sp_fix <- sp_c; sp_fix$cutoff <- "2023-01-01"
d_fix <- prep_data(cz, sp_fix, 1)
check(grepl("2023-01-01", attr(d_fix, "censor_note")) && grepl("as given", attr(d_fix, "censor_note")), "a cut-off date that is given is used instead of the latest event date")
sp_no <- sp_c; sp_no$start_col <- ""
e_no <- tryCatch(prep_data(cz, sp_no, 1), error = function(e) conditionMessage(e))
check(is.character(e_no) && grepl("every remaining patient has the event", e_no), "with no way to follow them, a cohort left with events only is refused")
core <- c("patientid", "treatment", "age", "startdate", "duration", "event")
cz2 <- cz; cz2$event <- as.integer(died)                    # a 0/1 event column that says no more than "a duration is recorded"
check(isTRUE(auto_spec(cz2[, core])$event_from_time), "an event column that only repeats 'a duration is recorded' is read the same way")
cz3 <- cz2; cz3$duration <- ifelse(died, cz$duration, 365)   # an ordinary file: censored patients have a time
sp_o <- auto_spec(cz3[, core]); d_o <- prep_data(cz3, sp_o, 1)
check(!isTRUE(sp_o$event_from_time) && is.null(attr(d_o, "censor_note")) && sum(d_o$event == 0) == sum(!died), "an ordinary file is read as before")
check(cohort_data_hash(COHORTS, "ECOG", sp_c) != cohort_data_hash(COHORTS, "ECOG", sp_fix), "the cut-off is part of the analysis identity")
sp_ov <- apply_spec_overrides(sp_o, data.frame(event_from_time = "TRUE", start_col = "startdate", cutoff_date = "2022-06-30", stringsAsFactors = FALSE))
check(isTRUE(sp_ov$event_from_time) && sp_ov$start_col == "startdate" && sp_ov$cutoff == "2022-06-30", "cohorts.csv can set the rule per cohort")
e_sc <- spec_problems(cz, { z <- sp_c; z$start_col <- "nope"; z })
check(any(grepl("start date column 'nope' is not in the data", e_sc)), "a start-date column that is not in the file is a mapping problem")
r_cz <- run_method("iptw_km", d_c2, { z <- s; z$report_times <- c(180, 365); z$chr_time <- 365; z })
check(isTRUE(r_cz$ok) && all(is.finite(r_cz$estimates$est[r_cz$estimates$time == 180])), "and a method runs on the cohort so prepared")

cat("a production-shaped run, end to end\n")
pd <- tempfile("prod"); dir.create(file.path(pd, "src", "analysis"), recursive = TRUE); dir.create(file.path(pd, "data"))
invisible(file.copy(file.path(fx, c("run_iptw_cox_analysis.R", "run_cox_regstand_analysis.R")), file.path(pd, "src", "analysis")))
real <- cz[, c("patientid", "duration", "event", "treatment", "startdate", "age")]
real$PDL1 <- sample(c("positive", "negative", NA), n_c, TRUE, prob = c(0.4, 0.4, 0.2))
real$linename <- ifelse(real$treatment == 1, "nivolumab", "docetaxel")
utils::write.csv(real, file.path(pd, "data", "docetaxel_nivolumab_EC_TEST_feature_table.csv"), row.names = TRUE)   # a blank first header
cfg_p <- DASH_CFG; cfg_p$source <- "files"; cfg_p$data_dir <- file.path(pd, "data"); cfg_p$cohorts_csv <- "none.csv"
reg_p <- discover_cohorts(cfg_p, pd)
d_p <- prep_cohort(reg_p, reg_p$id[1], time_divisor = 1)
for (id in grep("^src:", names(METHODS), value = TRUE)) METHODS[[id]] <- NULL
au_p <- register_study_methods(file.path(pd, "src", "analysis"), repo_root = pd)
s_p <- s; s_p$report_times <- c(180, 365); s_p$chr_time <- 365; s_p$time_unit <- "days"
r_p <- run_methods(au_p$id, d_p, s_p, use_cache = FALSE)
check(nrow(reg_p) == 1 && nrow(d_p) > 380 && sum(d_p$event == 0) > 0 && "missing" %in% levels(d_p$PDL1) &&
        all(attr(d_p, "arm_labels") == c("nivolumab", "docetaxel")) && grepl("data cut-off", attr(d_p, "censor_note")),
      "a file shaped like the real ones is read whole: blank header, all-1s event column, blank durations, blank biomarker status")
check(length(r_p) == 2 && all(vapply(r_p, function(r) isTRUE(r$ok), logical(1))) &&
        all(is.finite(unlist(lapply(r_p, function(r) r$estimates$est[r$estimates$time == 180])))),
      "and the study's functions run on it as methods, with no adapter and no mapping by hand")
for (id in grep("^src:", names(METHODS), value = TRUE)) METHODS[[id]] <- NULL
