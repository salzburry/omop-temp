# THE FIGURES. ggplot2 objects; app.R hands them to plotly for hover. Colour
# follows an entity that stays small: the ARM (two colours) or the robustness
# CLASS (a handful), never the method, since a registry can hold many methods.
# The colours themselves come from config/theme.R.

PALETTE   <- THEME$classes
ARM_COLS  <- THEME$arms
INK_MUTED <- THEME$muted

class_colours <- function(classes) {
  classes <- unique(classes)
  stats::setNames(rep_len(PALETTE, length(classes)), classes)
}

arm_factor <- function(x, arm_labels = c(treated = "Treated", control = "Control"))
  factor(x, levels = c("treated", "control"), labels = unname(arm_labels[c("treated", "control")]))

# A ggplot on the page: plotly for hover, in the dashboard's font and ink on
# white. A bottom legend is laid out below the axis title (plotly otherwise
# draws the two on top of each other).
pl <- function(p, ...) {
  w <- plotly::layout(plotly::ggplotly(p, ...),
                      font = list(family = THEME$font, color = THEME$ink),
                      paper_bgcolor = THEME$surface, plot_bgcolor = THEME$surface)
  pos <- tryCatch(p$theme$legend.position, error = function(e) NULL)
  if (identical(pos, "bottom"))
    w <- plotly::layout(w, legend = list(orientation = "h", x = 0, y = -0.22, yanchor = "top"),
                        margin = list(b = 90))
  w
}

theme_dash <- function() {
  ggplot2::theme_minimal(base_size = 12) +
    ggplot2::theme(
      panel.grid.minor = ggplot2::element_blank(),
      panel.grid.major = ggplot2::element_line(colour = THEME$line, linewidth = 0.4),
      axis.line.x      = ggplot2::element_line(colour = THEME$line),
      axis.title       = ggplot2::element_text(colour = THEME$muted),
      axis.text        = ggplot2::element_text(colour = INK_MUTED),
      strip.text       = ggplot2::element_text(face = "bold", colour = THEME$ink),
      plot.title       = ggplot2::element_text(colour = THEME$ink, face = "bold"),
      legend.position  = "bottom",
      legend.title     = ggplot2::element_blank(),
      legend.text      = ggplot2::element_text(colour = THEME$ink),
      plot.background  = ggplot2::element_rect(fill = THEME$surface, colour = NA)
    )
}

# ---- results -------------------------------------------------------------------

# Forest plot of one estimand across methods (rows), one panel per report time.
plot_forest <- function(est, estimand, class_cols = class_colours(est$class), unit = "analysis units") {
  e <- est[est$estimand == estimand & is.finite(est$est), , drop = FALSE]   # nothing to draw beyond follow-up
  if (!nrow(e)) return(NULL)
  e$method <- factor(e$method, levels = rev(unique(e$method)))
  e$panel  <- paste0(ESTIMAND_LABELS[[estimand]], " at ", e$time, " ", unit)
  e$panel  <- factor(e$panel, levels = unique(e$panel[order(e$time)]))     # by time, not as text
  p <- ggplot2::ggplot(e, ggplot2::aes(x = est, y = method, colour = class,
                                       text = sprintf("%s<br>%.3f [%.3f, %.3f]", method, est, lower, upper))) +
    ggplot2::geom_vline(xintercept = ESTIMAND_NULL[[estimand]], colour = INK_MUTED, linetype = "dashed") +
    ggplot2::geom_errorbar(ggplot2::aes(xmin = lower, xmax = upper), orientation = "y", width = 0.25, na.rm = TRUE) +
    ggplot2::geom_point(size = 3) +
    ggplot2::scale_colour_manual(values = class_cols) +
    ggplot2::facet_wrap(~ panel, scales = "free_x") +
    ggplot2::labs(x = ESTIMAND_LABELS[[estimand]], y = NULL) +
    theme_dash()
  if (estimand == "CHR") p <- p + ggplot2::scale_x_log10()
  p
}

# Marginal survival curves, one panel per method, colour = arm.
plot_curves <- function(curves, arm_labels = c(treated = "Treated", control = "Control"), unit = "analysis units") {
  if (!nrow(curves)) return(NULL)
  long <- rbind(
    data.frame(method = curves$method, time = curves$time, surv = curves$s1, arm = "treated"),
    data.frame(method = curves$method, time = curves$time, surv = curves$s0, arm = "control"))
  long$method <- factor(long$method, levels = unique(curves$method))
  long$arm <- arm_factor(long$arm, arm_labels)
  ggplot2::ggplot(long, ggplot2::aes(time, surv, colour = arm)) +
    ggplot2::geom_line(linewidth = 0.8, na.rm = TRUE) +         # the curve stops where follow-up ends
    ggplot2::scale_colour_manual(values = unname(ARM_COLS)) +
    ggplot2::scale_y_continuous(limits = c(0, 1)) +
    ggplot2::facet_wrap(~ method) +
    ggplot2::labs(x = paste0("Time (", unit, ")"), y = "Marginal survival") +
    theme_dash()
}

# The effect over the whole follow-up: the survival difference, or the RMST
# difference by horizon, one panel per method, with its pointwise band where
# the method has one.
plot_effect <- function(eff, kind = c("rd", "rmst"), unit = "analysis units") {
  kind <- match.arg(kind)
  if (!nrow(eff)) return(NULL)
  df <- data.frame(method = factor(eff$method, levels = unique(eff$method)), time = eff$time,
                   y  = if (kind == "rd") eff$rd else eff$rmst,
                   lo = if (kind == "rd") eff$rd_lower else eff$rmst_lower,
                   hi = if (kind == "rd") eff$rd_upper else eff$rmst_upper)
  df$text <- sprintf("%s<br>t = %.1f: %.3f [%.3f, %.3f]", df$method, df$time, df$y, df$lo, df$hi)
  p <- ggplot2::ggplot(df, ggplot2::aes(time, y, group = method, text = text)) +
    ggplot2::geom_hline(yintercept = 0, colour = INK_MUTED, linetype = "dashed")
  if (any(is.finite(df$lo)))
    p <- p + ggplot2::geom_ribbon(ggplot2::aes(ymin = lo, ymax = hi), fill = ARM_COLS[["treated"]], alpha = 0.18, na.rm = TRUE)
  p + ggplot2::geom_line(colour = ARM_COLS[["treated"]], linewidth = 0.9, na.rm = TRUE) +
    ggplot2::facet_wrap(~ method) +
    ggplot2::labs(x = paste0("Time (", unit, ")"),
                  y = if (kind == "rd") "Survival difference, treated minus control"
                      else paste0("RMST difference (", unit, ") up to the horizon")) +
    theme_dash()
}

# HR(t) or cumulative HR(t), one panel per method.
plot_hrt <- function(hrt, kind = c("hr", "chr"), unit = "analysis units") {
  kind <- match.arg(kind)
  if (!nrow(hrt)) return(NULL)
  hrt$method <- factor(hrt$method, levels = unique(hrt$method))
  hrt$y <- hrt[[kind]]
  ggplot2::ggplot(hrt[is.finite(hrt$y), ], ggplot2::aes(time, y, group = method)) +
    ggplot2::geom_hline(yintercept = 1, colour = INK_MUTED, linetype = "dashed") +
    ggplot2::geom_line(colour = ARM_COLS[["treated"]], linewidth = 0.8) +
    ggplot2::scale_y_log10() +
    ggplot2::facet_wrap(~ method) +
    ggplot2::labs(x = paste0("Time (", unit, ")"),
                  y = if (kind == "hr") "Marginal hazard ratio HR(t)" else "Cumulative hazard ratio CHR(t)") +
    theme_dash()
}

# E-values per method: the point estimate's, and the confidence limit's.
plot_evalue <- function(ev, class_cols = class_colours(ev$class)) {
  ev <- ev[is.finite(ev$evalue), , drop = FALSE]
  if (!nrow(ev)) return(NULL)
  ev$method <- factor(ev$method, levels = rev(unique(ev$method)))
  long <- rbind(data.frame(method = ev$method, class = ev$class, value = ev$evalue, what = "Point estimate"),
                data.frame(method = ev$method, class = ev$class, value = ev$evalue_ci, what = "Confidence limit"))
  long <- long[is.finite(long$value), , drop = FALSE]
  long$what <- factor(long$what, levels = c("Point estimate", "Confidence limit"))
  ggplot2::ggplot(long, ggplot2::aes(value, method, colour = class, shape = what,
                                     text = sprintf("%s<br>%s: E-value %.2f", method, what, value))) +
    ggplot2::geom_vline(xintercept = 1, colour = INK_MUTED, linetype = "dashed") +
    ggplot2::geom_point(size = 3.2) +
    ggplot2::scale_shape_manual(values = c("Point estimate" = 16, "Confidence limit" = 1)) +
    ggplot2::scale_colour_manual(values = class_cols) +
    ggplot2::labs(x = "E-value (risk-ratio scale): confounder strength needed to explain the estimate away", y = NULL) +
    theme_dash()
}

plot_runtime <- function(status, class_cols = class_colours(status$class)) {
  if (!nrow(status)) return(NULL)
  status$method <- factor(status$method, levels = rev(unique(status$method)))
  ggplot2::ggplot(status, ggplot2::aes(x = seconds, y = method, fill = class,
                                       text = sprintf("%s: %.2f s (%s)", method, seconds, status))) +
    ggplot2::geom_col(width = 0.6) +
    ggplot2::scale_fill_manual(values = class_cols) +
    ggplot2::labs(x = "Run time (seconds)", y = NULL) +
    theme_dash()
}

# ---- compare cohorts ------------------------------------------------------------

# Cohorts x methods at one time, as a matrix of tiles with the values written
# in. Diverging colour around the null, and blue always means the treated arm
# did better: for CHR, where benefit is below 1, the fill is -log CHR.
plot_heatmap <- function(est, estimand, time, unit = "analysis units") {
  e <- est[est$estimand == estimand & abs(est$time - time) < 1e-9 & is.finite(est$est), , drop = FALSE]
  if (!nrow(e)) return(NULL)
  e$cohort <- factor(e$cohort, levels = rev(unique(e$cohort)))
  e$method <- factor(e$method, levels = unique(e$method))
  e$fill   <- if (estimand == "CHR") -log(e$est) else e$est
  e$label  <- sprintf("%.3f", e$est)
  lim <- max(abs(e$fill), 1e-9)
  ggplot2::ggplot(e, ggplot2::aes(method, cohort, fill = fill,
                                  text = sprintf("%s / %s<br>%s = %.3f", cohort, method, estimand, est))) +
    ggplot2::geom_tile(colour = THEME$surface, linewidth = 1.5) +
    ggplot2::geom_text(ggplot2::aes(label = label), size = 3.3, colour = THEME$ink) +
    ggplot2::scale_fill_gradient2(low = ARM_COLS[["control"]], mid = THEME$plane, high = ARM_COLS[["treated"]],
                                  midpoint = 0, limits = c(-lim, lim),
                                  name = if (estimand == "CHR") "-log CHR" else ESTIMAND_LABELS[[estimand]]) +
    ggplot2::labs(x = NULL, y = NULL, title = paste0(ESTIMAND_LABELS[[estimand]], " at ", time, " ", unit)) +
    theme_dash() +
    ggplot2::theme(panel.grid = ggplot2::element_blank(), legend.position = "right",
                   axis.text.x = ggplot2::element_text(angle = 25, hjust = 1))
}

# Cohort comparison: one panel per method, cohorts down the side.
plot_compare <- function(est, estimand, time, unit = "analysis units") {
  e <- est[est$estimand == estimand & abs(est$time - time) < 1e-9 & is.finite(est$est), , drop = FALSE]
  if (!nrow(e)) return(NULL)
  e$cohort <- factor(e$cohort, levels = rev(unique(e$cohort)))
  e$method <- factor(e$method, levels = unique(e$method))
  p <- ggplot2::ggplot(e, ggplot2::aes(x = est, y = cohort,
                                       text = sprintf("%s / %s<br>%.3f [%.3f, %.3f]", cohort, method, est, lower, upper))) +
    ggplot2::geom_vline(xintercept = ESTIMAND_NULL[[estimand]], colour = INK_MUTED, linetype = "dashed") +
    ggplot2::geom_errorbar(ggplot2::aes(xmin = lower, xmax = upper), orientation = "y", width = 0.25, na.rm = TRUE, colour = ARM_COLS[["treated"]]) +
    ggplot2::geom_point(size = 3, colour = ARM_COLS[["treated"]]) +
    ggplot2::facet_wrap(~ method) +
    ggplot2::labs(x = paste0(ESTIMAND_LABELS[[estimand]], " at ", time, " ", unit), y = NULL) +
    theme_dash()
  if (estimand == "CHR") p <- p + ggplot2::scale_x_log10()
  p
}

# Specification curve: every cohort x method estimate of one estimand at one
# time, sorted by size (the top), and the strip that says which method and
# which cohort each one is (the bottom). Two ggplots; app.R stacks them.
spec_curve_data <- function(est, estimand, time) {
  e <- est[est$estimand == estimand & abs(est$time - time) < 1e-9 & is.finite(est$est), , drop = FALSE]
  if (!nrow(e)) return(e)
  e <- e[order(e$est), , drop = FALSE]
  e$rank <- seq_len(nrow(e))
  rownames(e) <- NULL
  e
}

plot_spec_curve <- function(e, estimand, unit = "analysis units", class_cols = class_colours(e$class)) {
  if (!nrow(e)) return(NULL)
  p <- ggplot2::ggplot(e, ggplot2::aes(rank, est, colour = class,
                                       text = sprintf("#%d %s / %s<br>%.3f [%.3f, %.3f]", rank, cohort, method, est, lower, upper))) +
    ggplot2::geom_hline(yintercept = ESTIMAND_NULL[[estimand]], colour = INK_MUTED, linetype = "dashed") +
    ggplot2::geom_errorbar(ggplot2::aes(ymin = lower, ymax = upper), width = 0, na.rm = TRUE, alpha = 0.7) +
    ggplot2::geom_point(size = 2.6) +
    ggplot2::scale_colour_manual(values = class_cols) +
    ggplot2::labs(x = NULL, y = paste0(ESTIMAND_LABELS[[estimand]], " at ", e$time[1], " ", unit)) +
    theme_dash() + ggplot2::theme(legend.position = "top")
  if (estimand == "CHR") p <- p + ggplot2::scale_y_log10()
  p
}

plot_spec_strip <- function(e) {
  if (!nrow(e)) return(NULL)
  rows <- rbind(data.frame(rank = e$rank, row = paste0("Method: ", e$method)),
                data.frame(rank = e$rank, row = paste0("Cohort: ", e$cohort)))
  lv <- c(paste0("Method: ", unique(e$method)), paste0("Cohort: ", unique(e$cohort)))
  rows$row <- factor(rows$row, levels = rev(lv))
  ggplot2::ggplot(rows, ggplot2::aes(rank, row, text = sprintf("#%d %s", rank, row))) +
    ggplot2::geom_point(shape = 15, size = 2.4, colour = THEME$ink) +
    ggplot2::labs(x = "Specifications, sorted by estimate", y = NULL) +
    theme_dash() + ggplot2::theme(panel.grid.major.x = ggplot2::element_blank())
}

# The cohorts' sizes after exclusions, largest first: the eligibility funnel.
plot_cohort_sizes <- function(cs) {
  if (!nrow(cs)) return(NULL)
  cs <- cs[order(cs$n), , drop = FALSE]
  cs$cohort <- factor(cs$cohort, levels = cs$cohort)
  ggplot2::ggplot(cs, ggplot2::aes(n, cohort, text = sprintf("%s<br>%s patients, %s events, %s treated",
                                                            cohort, format(n, big.mark = ","), format(events, big.mark = ","), format(n_treated, big.mark = ",")))) +
    ggplot2::geom_col(fill = ARM_COLS[["treated"]], alpha = 0.85, width = 0.62) +
    ggplot2::geom_text(ggplot2::aes(label = format(n, big.mark = ",")), hjust = -0.15, size = 3.2, colour = THEME$ink) +
    ggplot2::scale_x_continuous(expand = ggplot2::expansion(mult = c(0, 0.15))) +
    ggplot2::labs(x = "Patients after exclusions", y = NULL) +
    theme_dash()
}

# ---- diagnostics ------------------------------------------------------------------

plot_km <- function(km, arm_labels, unit = "analysis units") {
  km$arm <- arm_factor(ifelse(km$A == 1, "treated", "control"), arm_labels)
  ggplot2::ggplot(km, ggplot2::aes(time, surv, colour = arm)) +
    ggplot2::geom_step(linewidth = 0.8) +
    ggplot2::scale_colour_manual(values = unname(ARM_COLS)) +
    ggplot2::scale_y_continuous(limits = c(0, 1)) +
    ggplot2::labs(x = paste0("Time (", unit, ")"), y = "Kaplan-Meier survival (unadjusted)") +
    theme_dash()
}

plot_ps <- function(ps, arm_labels) {
  ps$arm <- arm_factor(ifelse(ps$A == 1, "treated", "control"), arm_labels)
  ggplot2::ggplot(ps, ggplot2::aes(ps, fill = arm, colour = arm)) +
    ggplot2::geom_density(alpha = 0.3, linewidth = 0.6) +
    ggplot2::scale_fill_manual(values = unname(ARM_COLS)) +
    ggplot2::scale_colour_manual(values = unname(ARM_COLS)) +
    ggplot2::labs(x = "Propensity score", y = "Density") +
    theme_dash()
}

# Mirrored histogram: treated above the axis, control below; what was
# observed filled, the IPT-weighted pseudo-population outlined.
plot_ps_mirror <- function(h, arm_labels) {
  if (!nrow(h)) return(NULL)
  h$arm <- arm_factor(h$arm, arm_labels)
  width <- if (length(unique(h$ps)) > 1) min(diff(sort(unique(h$ps)))) * 0.95 else 0.03
  obs <- h; obs$text <- sprintf("%s, PS %.2f<br>observed: %d", obs$arm, obs$ps, abs(round(obs$unweighted)))
  wtd <- h; wtd$text <- sprintf("%s, PS %.2f<br>IPT-weighted: %.0f", wtd$arm, wtd$ps, abs(wtd$weighted))
  ggplot2::ggplot(mapping = ggplot2::aes(x = ps, text = text)) +
    ggplot2::geom_col(data = obs, ggplot2::aes(y = unweighted, fill = arm), width = width, alpha = 0.35) +
    ggplot2::geom_col(data = wtd, ggplot2::aes(y = weighted, colour = arm), width = width, fill = NA, linewidth = 0.6) +
    ggplot2::geom_hline(yintercept = 0, colour = THEME$line) +
    ggplot2::scale_fill_manual(values = unname(ARM_COLS)) +
    ggplot2::scale_colour_manual(values = unname(ARM_COLS)) +
    ggplot2::scale_y_continuous(labels = function(v) abs(v)) +
    ggplot2::labs(x = "Propensity score", y = "Patients: treated above, control below") +
    theme_dash()
}

# Balance: standardised mean differences, unweighted, IPT-weighted and matched.
plot_love <- function(bal) {
  if (!nrow(bal)) return(NULL)
  has_matched <- "smd_matched" %in% names(bal) && any(is.finite(bal$smd_matched))
  kinds <- c("Unweighted", "IPT weighted", if (has_matched) "Matched 1:1")
  long <- rbind(data.frame(term = bal$term, smd = bal$smd_unweighted, kind = "Unweighted"),
                data.frame(term = bal$term, smd = bal$smd_weighted,   kind = "IPT weighted"),
                if (has_matched) data.frame(term = bal$term, smd = bal$smd_matched, kind = "Matched 1:1"))
  long$term <- factor(long$term, levels = rev(bal$term[order(abs(bal$smd_unweighted))]))
  long$kind <- factor(long$kind, levels = kinds)
  cols   <- c("Unweighted" = INK_MUTED, "IPT weighted" = ARM_COLS[["treated"]], "Matched 1:1" = ARM_COLS[["control"]])
  shapes <- c("Unweighted" = 16, "IPT weighted" = 17, "Matched 1:1" = 15)
  ggplot2::ggplot(long, ggplot2::aes(x = smd, y = term, colour = kind, shape = kind,
                                     text = sprintf("%s<br>%s: %.3f", term, kind, smd))) +
    ggplot2::geom_vline(xintercept = c(-0.1, 0.1), colour = INK_MUTED, linetype = "dashed") +
    ggplot2::geom_vline(xintercept = 0, colour = THEME$line) +
    ggplot2::geom_point(size = 2.6, na.rm = TRUE) +
    ggplot2::scale_colour_manual(values = cols[kinds]) +
    ggplot2::scale_shape_manual(values = shapes[kinds]) +
    ggplot2::labs(x = "Standardised mean difference", y = NULL) +
    theme_dash()
}

# ECDF of each continuous covariate by arm, unweighted beside IPT-weighted.
plot_ecdf <- function(e, arm_labels) {
  if (!nrow(e)) return(NULL)
  long <- rbind(data.frame(e[, c("covariate", "x", "arm")], F = e$unweighted, weighting = "Unweighted"),
                data.frame(e[, c("covariate", "x", "arm")], F = e$weighted,   weighting = "IPT weighted"))
  long$arm <- arm_factor(long$arm, arm_labels)
  lv <- as.vector(t(outer(unique(e$covariate), c(" · Unweighted", " · IPT weighted"), paste0)))
  long$panel <- factor(paste0(long$covariate, " · ", long$weighting), levels = lv)
  ggplot2::ggplot(long, ggplot2::aes(x, F, colour = arm)) +
    ggplot2::geom_step(linewidth = 0.8) +
    ggplot2::scale_colour_manual(values = unname(ARM_COLS)) +
    ggplot2::facet_wrap(~ panel, scales = "free_x", ncol = 2) +
    ggplot2::labs(x = NULL, y = "Cumulative proportion") +
    theme_dash()
}

# Effect heterogeneity: alive at t against the propensity score, by arm.
plot_heterogeneity <- function(hd, arm_labels, unit = "analysis units") {
  pts <- hd$points; sm <- hd$smooth
  if (is.null(sm) || !nrow(pts)) return(NULL)
  pts$arm <- arm_factor(pts$arm, arm_labels); sm$arm <- arm_factor(sm$arm, arm_labels)
  set.seed(1)
  pts$yj <- pts$y + stats::runif(nrow(pts), -0.03, 0.03)
  pts$text <- sprintf("%s, PS %.2f: %s", pts$arm, pts$ps, ifelse(pts$y == 1, "alive", "event"))
  sm$text  <- sprintf("%s<br>PS %.2f: %.0f%% alive", sm$arm, sm$ps, 100 * sm$fit)
  ggplot2::ggplot(mapping = ggplot2::aes(text = text)) +
    ggplot2::geom_point(data = pts, ggplot2::aes(ps, yj, colour = arm), alpha = 0.12, size = 0.9) +
    ggplot2::geom_ribbon(data = sm, ggplot2::aes(ps, ymin = lower, ymax = upper, fill = arm), alpha = 0.15) +
    ggplot2::geom_line(data = sm, ggplot2::aes(ps, fit, colour = arm), linewidth = 1) +
    ggplot2::scale_colour_manual(values = unname(ARM_COLS)) +
    ggplot2::scale_fill_manual(values = unname(ARM_COLS)) +
    ggplot2::coord_cartesian(ylim = c(-0.05, 1.05)) +
    ggplot2::labs(x = "Propensity score", y = sprintf("Alive at %s %s", format(hd$t), unit)) +
    theme_dash()
}

# The IPT weights by arm, with the effective sample size written above each.
plot_weights <- function(wd, ws, arm_labels) {
  if (!nrow(wd)) return(NULL)
  wd$arm <- arm_factor(wd$arm, arm_labels)
  ws$arm <- arm_factor(ws$arm, arm_labels)
  ws$label <- sprintf("ESS %s of %s", format(round(ws$ess), big.mark = ","), format(ws$n, big.mark = ","))
  ws$y <- max(wd$w) * 1.08
  ggplot2::ggplot(wd, ggplot2::aes(arm, w, fill = arm)) +
    ggplot2::geom_violin(alpha = 0.35, colour = NA, width = 0.8) +
    ggplot2::geom_boxplot(width = 0.12, outlier.size = 0.6, fill = THEME$surface, colour = THEME$ink) +
    ggplot2::geom_text(data = ws, ggplot2::aes(arm, y, label = label), inherit.aes = FALSE, size = 3.3, colour = THEME$ink) +
    ggplot2::scale_fill_manual(values = unname(ARM_COLS)) +
    ggplot2::labs(x = NULL, y = "IPT weight") +
    theme_dash() + ggplot2::theme(legend.position = "none")
}
