# DIAGNOSTICS on a prepared cohort: what the data look like before any method
# is trusted. Unadjusted Kaplan-Meier by arm with numbers at risk; propensity
# overlap as a mirrored histogram (observed, and the IPT-weighted
# pseudo-population); covariate balance before adjustment, after IPT weighting
# and after 1:1 propensity matching; the full distribution of each continuous
# covariate by arm (ECDF) unweighted and weighted; follow-up and censoring;
# the Schoenfeld test.

km_unadjusted <- function(d) {
  sf <- survival::survfit(Surv(time, event) ~ A, data = d)
  st <- rep(names(sf$strata), sf$strata)
  out <- data.frame(time = sf$time, surv = sf$surv, lower = sf$lower, upper = sf$upper,
                    A = as.integer(sub("A=", "", st)))
  rbind(data.frame(time = 0, surv = 1, lower = 1, upper = 1, A = c(0L, 1L)), out)
}

ps_overlap <- function(d, xvars, s) data.frame(ps = fit_ps(d, xvars, s), A = d$A)

# Mirrored histogram data: counts per propensity bin, treated positive and
# control negative; `unweighted` is what was observed, `weighted` the
# IPT-weighted pseudo-population scaled to the arm's size, so the two
# outlines show what weighting did to the overlap.
ps_overlap_bins <- function(d, xvars, s, bins = 30) {
  ps <- fit_ps(d, xvars, s)
  w  <- ipt_weights(d, xvars, s)
  br <- seq(0, 1, length.out = bins + 1)
  b  <- cut(ps, br, include.lowest = TRUE, labels = FALSE)
  mid <- (br[-1] + br[-length(br)]) / 2
  one <- function(arm, sign) {
    i <- d$A == arm
    cnt <- tabulate(b[i], nbins = bins)
    wc  <- vapply(seq_len(bins), function(k) sum(w[i & b == k]), numeric(1))
    wc  <- if (sum(w[i]) > 0) wc * sum(i) / sum(w[i]) else wc
    data.frame(ps = mid, arm = if (arm == 1) "treated" else "control",
               unweighted = sign * cnt, weighted = sign * wc)
  }
  rbind(one(1, 1), one(0, -1))
}

# 1:1 nearest-neighbour matching on the logit propensity score, without
# replacement, treated units taken in descending propensity order (the hardest
# to match first), within a caliper of s$psm_caliper standard deviations of
# the logit score. A diagnostic, not an estimator: it shows what balance
# matching would reach on this cohort next to what weighting reaches.
ps_match <- function(d, xvars, s) {
  ps <- fit_ps(d, xvars, s)
  lp <- stats::qlogis(ps)
  cal <- s$psm_caliper * stats::sd(lp)
  ti <- which(d$A == 1); ci <- which(d$A == 0)
  ti <- ti[order(ps[ti], decreasing = TRUE)]
  lc <- lp[ci]; avail <- rep(TRUE, length(ci))
  pair_t <- integer(0); pair_c <- integer(0)
  for (i in ti) {
    dist <- abs(lc - lp[i]); dist[!avail] <- Inf
    j <- which.min(dist)
    if (length(j) && is.finite(dist[j]) && dist[j] <= cal) {
      avail[j] <- FALSE; pair_t <- c(pair_t, i); pair_c <- c(pair_c, ci[j])
    }
  }
  matched <- integer(nrow(d)); matched[c(pair_t, pair_c)] <- 1L
  list(matched = matched, n_pairs = length(pair_t), n_treated = length(ti), n_control = length(ci),
       n_unmatched = length(ti) - length(pair_t), caliper = cal, ps = ps)
}

# Standardised mean differences, one row per covariate term (factor levels
# expanded): unweighted, under the IPT weights the settings imply, and in the
# 1:1 matched sample. The denominator is the UNADJUSTED pooled standard
# deviation for all three, as cobalt does, so a change in dispersion under
# weighting or matching cannot pass for a change in balance. The matching
# summary rides along as an attribute.
balance_table <- function(d, xvars, s) {
  if (!length(xvars)) return(data.frame())
  X <- stats::model.matrix(stats::as.formula(paste("~", paste(xvars, collapse = " + "))), data = d)[, -1, drop = FALSE]
  w <- ipt_weights(d, xvars, s)
  m <- ps_match(d, xvars, s)
  i1 <- d$A == 1; i0 <- d$A == 0
  sd0 <- apply(X, 2, function(x) sqrt((stats::var(x[i1]) + stats::var(x[i0])) / 2))    # unadjusted pooled SD
  smd <- function(x, w, sd) {
    if (sum(w[i1]) <= 0 || sum(w[i0]) <= 0 || !is.finite(sd) || sd == 0) return(NA_real_)
    (sum(w[i1] * x[i1]) / sum(w[i1]) - sum(w[i0] * x[i0]) / sum(w[i0])) / sd
  }
  out <- data.frame(
    term = colnames(X),
    smd_unweighted = vapply(seq_len(ncol(X)), function(j) smd(X[, j], rep(1, nrow(d)), sd0[j]), numeric(1)),
    smd_weighted   = vapply(seq_len(ncol(X)), function(j) smd(X[, j], w, sd0[j]), numeric(1)),
    smd_matched    = if (m$n_pairs > 0) vapply(seq_len(ncol(X)), function(j) smd(X[, j], m$matched, sd0[j]), numeric(1)) else NA_real_,
    row.names = NULL
  )
  attr(out, "matching") <- m[c("n_pairs", "n_treated", "n_control", "n_unmatched", "caliper")]
  attr(out, "sd_denominator") <- "unadjusted pooled"
  out
}

# Empirical cumulative distribution of each continuous covariate (more than
# ten distinct values) by arm, unweighted and IPT-weighted, on up to
# `max_points` quantiles of the covariate. Balance across the whole
# distribution, not just the mean the SMD compares.
ecdf_table <- function(d, xvars, s, max_points = 200) {
  w <- ipt_weights(d, xvars, s)
  rows <- list()
  for (cn in xvars) {
    x <- d[[cn]]
    if (!is.numeric(x) || length(unique(x)) <= 10) next
    g <- sort(unique(x))
    if (length(g) > max_points) g <- unique(stats::quantile(x, seq(0, 1, length.out = max_points), names = FALSE))
    for (arm in c(1, 0)) {
      i <- d$A == arm; xi <- x[i]; wi <- w[i]
      rows[[length(rows) + 1]] <- data.frame(
        covariate = cn, x = g, arm = if (arm == 1) "treated" else "control",
        unweighted = vapply(g, function(v) mean(xi <= v), numeric(1)),
        weighted   = vapply(g, function(v) sum(wi[xi <= v]) / sum(wi), numeric(1)))
    }
  }
  if (!length(rows)) return(data.frame())
  out <- do.call(rbind, rows); rownames(out) <- NULL; out
}

# Numbers at risk by arm at a handful of evenly spaced times: the strip that
# sits under a survival curve. Wide: one row per arm, one column per time.
risk_strip <- function(d, tmax, n_times = 7, arm_labels = c(treated = "treated", control = "control")) {
  times <- pretty(c(0, tmax), n = n_times - 1)
  times <- times[times >= 0 & times <= tmax]
  sf <- survival::survfit(Surv(time, event) ~ A, data = d)
  sm <- summary(sf, times = times, extend = TRUE)
  arm <- ifelse(as.character(sm$strata) == "A=1", arm_labels[["treated"]], arm_labels[["control"]])
  wide <- stats::reshape(data.frame(arm = arm, time = sm$time, n = sm$n.risk), idvar = "arm", timevar = "time", direction = "wide")
  names(wide) <- sub("^n\\.", "", names(wide))
  rownames(wide) <- NULL
  names(wide)[1] <- "at risk"
  wide
}

# The IPT weights themselves, one row per patient, for their distribution by arm.
weight_data <- function(d, xvars, s)
  data.frame(w = ipt_weights(d, xvars, s), arm = ifelse(d$A == 1, "treated", "control"))

# Across the propensity score: whether a patient was alive AFTER time t (1;
# event at or before t: 0; censored before t: unknown, left out and counted)
# against the propensity score, by arm, with a local-regression smooth and
# its pointwise band. DESCRIPTIVE and complete-case: patients censored before
# t are not in it, so a gap between the arms can reflect censoring as well as
# effect; it is a look at where the arms differ across the covariate space,
# not an estimate.
heterogeneity_data <- function(d, xvars, s, t = s$chr_time, max_points = 2500) {
  ps <- fit_ps(d, xvars, s)
  y  <- ifelse(d$time > t, 1, ifelse(d$event == 1, 0, NA_real_))
  keep <- !is.na(y)
  pts <- data.frame(ps = ps[keep], y = y[keep], arm = ifelse(d$A[keep] == 1, "treated", "control"))
  sm <- list()
  for (arm in c("treated", "control")) {
    p <- pts[pts$arm == arm, , drop = FALSE]
    if (nrow(p) < 30 || length(unique(p$y)) < 2) next
    fit <- suppressWarnings(stats::loess(y ~ ps, data = p, degree = 1, span = 0.75))
    g <- seq(stats::quantile(p$ps, 0.02), stats::quantile(p$ps, 0.98), length.out = 60)
    pr <- suppressWarnings(stats::predict(fit, newdata = data.frame(ps = g), se = TRUE))
    sm[[arm]] <- data.frame(ps = g, fit = pmin(pmax(pr$fit, 0), 1),
                            lower = pmin(pmax(pr$fit - 1.96 * pr$se.fit, 0), 1),
                            upper = pmin(pmax(pr$fit + 1.96 * pr$se.fit, 0), 1), arm = arm)
  }
  if (nrow(pts) > max_points) { set.seed(s$seed); pts <- pts[sample.int(nrow(pts), max_points), ] }
  list(points = pts, smooth = if (length(sm)) do.call(rbind, sm) else NULL, n_unknown = sum(!keep), t = t)
}

# Follow-up and censoring by arm. Median follow-up by reverse Kaplan-Meier.
censoring_summary <- function(d) {
  one <- function(i, arm) {
    dd <- d[i, , drop = FALSE]
    rkm <- survival::survfit(Surv(time, 1 - event) ~ 1, data = dd)
    data.frame(arm = arm, n = nrow(dd), events = sum(dd$event), censored = sum(dd$event == 0),
               pct_censored = 100 * mean(dd$event == 0),
               median_followup = unname(summary(rkm)$table["median"]),
               max_time = max(dd$time))
  }
  rbind(one(d$A == 1, "treated"), one(d$A == 0, "control"))
}

# Numbers at risk, events in the interval since the previous time, and the
# unadjusted survival estimate, by arm at the given times.
risk_table <- function(d, times) {
  times <- sort(unique(times[is.finite(times) & times > 0]))
  if (!length(times)) return(data.frame())
  sf <- survival::survfit(Surv(time, event) ~ A, data = d)
  sm <- summary(sf, times = times, extend = TRUE)
  arm <- ifelse(as.character(sm$strata) == "A=1", "treated", "control")
  # survival past an arm's last observed time is the last value carried
  # forward: not shown (NA), unless the curve had reached zero, which is
  # known from there on; the zero at risk stays visible either way
  fu <- c(treated = max(d$time[d$A == 1]), control = max(d$time[d$A == 0]))
  surv <- sm$surv
  surv[sm$time > fu[arm] + 1e-9 & surv > 1e-12] <- NA_real_
  data.frame(arm = arm, time = sm$time, at_risk = sm$n.risk, events_in_interval = sm$n.event,
             surv = surv, row.names = NULL)
}

# Schoenfeld-residual test of proportional hazards on the Cox outcome model.
# A small p for the treatment term says one hazard ratio misdescribes the
# effect over time - the reason to look at HR(t) and the curves rather than
# at a single HR.
ph_check <- function(d, xvars, s) {
  # x, y and the model frame are kept on the fit: cox.zph otherwise looks the
  # data up by name in the formula's environment, which exists in a script
  # and not in the App
  fit <- survival::coxph(out_formula(xvars, s, d), data = d, x = TRUE, y = TRUE, model = TRUE)
  z <- tryCatch(survival::cox.zph(fit), error = function(e) NULL)
  if (is.null(z)) return(data.frame())
  tab <- as.data.frame(z$table)
  data.frame(term = rownames(tab), chisq = tab$chisq, df = tab$df, p = tab$p, row.names = NULL)
}

weight_summary <- function(d, xvars, s) {
  w <- ipt_weights(d, xvars, s)
  data.frame(arm = c("treated", "control"),
             n = c(sum(d$A == 1), sum(d$A == 0)),
             ess = c(sum(w[d$A == 1])^2 / sum(w[d$A == 1]^2), sum(w[d$A == 0])^2 / sum(w[d$A == 0]^2)),
             w_min = c(min(w[d$A == 1]), min(w[d$A == 0])),
             w_max = c(max(w[d$A == 1]), max(w[d$A == 0])))
}
