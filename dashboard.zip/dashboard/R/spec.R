# COLUMN MAPPING. Which column plays which role in a cohort file, guessed from
# the names and then confirmed or changed on the Data page. A cohorts.csv row
# can fix any of these for a file whose names the guess does not cover.
#
# A spec is a plain list:
#   id, time, event, trt, weights, label_col   column names ("" = none)
#   treated_value   the trt value that means "treated"; the column must hold
#                   exactly two values and the other one is control
#   covariates      character vector of column names, as in the file
#
# prep_data() turns (data, spec) into the ONE shape every method takes:
#   time (analysis units), event 0/1, A 0/1, w (provided weights or NA),
#   plus the covariate columns (numeric, or factor) under formula-safe
#   INTERNAL names, with attributes xvars, xvar_labels (internal -> original),
#   n_dropped, drop_reasons, constant_dropped, arm_labels.
#
# What it REFUSES, saying why: a missing role column; a time column with no
# numbers; an event column holding values other than 0 and 1; a treatment
# column with other than two values, or a treated value that is not one of
# them; a covariate that is also a role column. What it DROPS, counted by
# reason: rows with a missing or non-positive time, a missing event or
# treatment, or a missing covariate. Nothing is coerced silently: a factor is
# read through its labels, never its level codes, and a covariate named like
# a role column, or with a space in its name, is renamed for modelling and the
# rename is reported.

# every column name the dashboard or a method creates on the prepared data:
# the roles, the IP weight column, and the person-period columns
RESERVED  <- c("id", "time", "event", "A", "w", ".w", "k", "dN", "dC")
JUNK_COLS <- "^(|\\.\\.\\.[0-9]+|X|X\\.[0-9]+|Unnamed: ?[0-9]+|index|row|rownames)$"

.first_match <- function(cols, candidates) {
  hit <- cols[tolower(cols) %in% tolower(candidates)]
  if (length(hit)) hit[1] else ""
}

# A value read as a number: through the labels of a factor, never its codes.
.to_num <- function(x) {
  if (is.factor(x)) x <- as.character(x)
  if (is.logical(x)) return(as.numeric(x))
  suppressWarnings(as.numeric(x))
}

# The distinct non-missing values of a treatment column, as text.
treatment_values <- function(x) sort(unique(as.character(x[!is.na(x)])))

# The value of the treatment column that means "treated", as text: "1" where
# the column holds 0/1, otherwise the larger (numeric) or last (text) of its
# values. Always text, so a mapping confirmed on the page and one guessed for
# the precompute Job describe the same analysis.
guess_treated_value <- function(x) {
  if (is.null(x)) return("1")
  v <- treatment_values(x)
  if (!length(v)) return("1")
  if ("1" %in% v) return("1")
  if (is.numeric(x)) as.character(max(as.numeric(v))) else v[length(v)]
}

# Covariates are guessed as every column that is not junk, not used by a role
# and not constant. A TEXT column with a distinct value on every row is an
# identifier, not a covariate; a NUMERIC column with a distinct value on every
# row (a lab value, a score) is a covariate and is kept.
auto_spec <- function(df) {
  cols  <- names(df)
  junk  <- grepl(JUNK_COLS, cols)
  time  <- .first_match(cols, c("duration", "time", "futime", "os_days", "os_time", "tte", "survtime", "days"))
  event <- .first_match(cols, c("event", "status", "died", "death", "os_event", "delta"))
  trt   <- .first_match(cols, c("treatment", "trt", "arm", "exposure", "treat", "a"))
  id    <- .first_match(cols, c("patientid", "patient_id", "id", "pid", "subject", "usubjid"))
  w     <- .first_match(cols, c("weights", "weight", "ipw", "iptw"))
  label <- .first_match(cols, c("linename", "treatment_name", "arm_name", "drug", "regimen"))
  used  <- c(time, event, trt, id, w, label)
  covs  <- cols[!junk & !(cols %in% used)]
  covs  <- covs[vapply(covs, function(cn) {
    x <- df[[cn]]; u <- length(unique(x[!is.na(x)]))
    u > 1 && (is.numeric(x) || u < nrow(df))
  }, logical(1))]
  list(id = id, time = time, event = event, trt = trt, weights = w, label_col = label,
       treated_value = guess_treated_value(if (nzchar(trt)) df[[trt]] else NULL),
       covariates = covs)
}

# cohorts.csv may carry: time_col, event_col, trt_col, treated_value, weights_col,
# id_col, label_col, covariates (semicolon-separated). Blank = keep the guess.
# A column given a role here leaves the guessed covariates; covariates given
# here are taken as written, so a conflict with a role is still reported.
.row_value <- function(row, key) {
  v <- if (!is.null(row) && key %in% names(row)) trimws(as.character(row[[key]])) else ""
  if (length(v) && !is.na(v) && nzchar(v)) v[1] else ""
}

apply_spec_overrides <- function(spec, row) {
  take <- function(field, key) { v <- .row_value(row, key); if (nzchar(v)) spec[[field]] <<- v }
  take("time", "time_col"); take("event", "event_col"); take("trt", "trt_col")
  take("weights", "weights_col"); take("id", "id_col"); take("label_col", "label_col")
  take("treated_value", "treated_value")
  cv <- .row_value(row, "covariates")
  if (nzchar(cv)) {
    spec$covariates <- trimws(strsplit(cv, ";", fixed = TRUE)[[1]])
  } else {
    roles <- c(spec$time, spec$event, spec$trt, spec$id, spec$weights, spec$label_col)
    spec$covariates <- setdiff(spec$covariates, roles[nzchar(roles)])
  }
  spec
}

# Internal, formula-safe covariate names: syntactic, unique, and never one of
# the role columns. The originals are sorted first, so which original gets
# which internal name never depends on the order they were picked in.
# Returns a vector with names = internal, values = original.
internal_names <- function(covs) {
  if (!length(covs)) return(stats::setNames(character(0), character(0)))
  covs <- sort(unique(as.character(covs)))
  nm <- make.names(covs, unique = TRUE)
  clash <- nm %in% RESERVED
  nm[clash] <- paste0(nm[clash], "_cov")
  nm <- make.unique(nm)
  stats::setNames(covs, nm)
}

# Everything that stops a mapping from being used, in words.
spec_problems <- function(df, spec) {
  p <- character()
  for (f in c("time", "event", "trt")) {
    if (!nzchar(spec[[f]] %||% "")) p <- c(p, sprintf("no %s column chosen", f))
    else if (!(spec[[f]] %in% names(df))) p <- c(p, sprintf("%s column '%s' is not in the data", f, spec[[f]]))
  }
  if (length(p)) return(p)
  tm <- .to_num(df[[spec$time]])
  if (all(is.na(tm))) p <- c(p, sprintf("time column '%s' has no numeric values", spec$time))
  ev <- .to_num(df[[spec$event]])
  if (all(is.na(ev))) p <- c(p, sprintf("event column '%s' has no numeric values", spec$event))
  bad <- unique(ev[!is.na(ev) & !(ev %in% c(0, 1))])
  if (length(bad)) p <- c(p, sprintf("event column '%s' must hold only 0 and 1 (1 = event); found %s",
                                     spec$event, paste(utils::head(bad, 5), collapse = ", ")))
  tv <- treatment_values(df[[spec$trt]])
  if (length(tv) != 2)
    p <- c(p, sprintf("treatment column '%s' must have exactly two values (treated and control); it has %d%s",
                      spec$trt, length(tv), if (length(tv)) paste0(" (", paste(utils::head(tv, 5), collapse = ", "), ")") else ""))
  else if (!(as.character(spec$treated_value) %in% tv))
    p <- c(p, sprintf("treated value '%s' is not one of the treatment column's values (%s)",
                      spec$treated_value, paste(tv, collapse = ", ")))
  roles <- c(spec$time, spec$event, spec$trt, spec$id, spec$weights, spec$label_col)
  overlap <- intersect(spec$covariates, roles[nzchar(roles)])
  if (length(overlap)) p <- c(p, sprintf("covariate(s) also used as a role column: %s", paste(overlap, collapse = ", ")))
  missing_cov <- setdiff(spec$covariates, names(df))
  if (length(missing_cov)) p <- c(p, sprintf("covariate column(s) not in the data: %s", paste(missing_cov, collapse = ", ")))
  p
}

prep_data <- function(df, spec, time_divisor = 1) {
  pr <- spec_problems(df, spec)
  if (length(pr)) stop(paste(pr, collapse = "; "), call. = FALSE)
  if (!is.finite(time_divisor) || time_divisor <= 0) stop("time divisor must be a positive number", call. = FALSE)

  trt_chr <- as.character(df[[spec$trt]])
  A <- ifelse(is.na(trt_chr), NA_integer_, as.integer(trt_chr == as.character(spec$treated_value)))
  has <- function(f) nzchar(spec[[f]] %||% "") && spec[[f]] %in% names(df)
  d <- data.frame(
    id    = if (has("id")) as.character(df[[spec$id]]) else as.character(seq_len(nrow(df))),
    time  = .to_num(df[[spec$time]]) / time_divisor,
    event = as.integer(.to_num(df[[spec$event]])),
    A     = A,
    w     = if (has("weights")) .to_num(df[[spec$weights]]) else NA_real_,
    stringsAsFactors = FALSE
  )
  xmap <- internal_names(intersect(spec$covariates, names(df)))      # internal -> original
  for (i in seq_along(xmap)) {
    x <- df[[xmap[[i]]]]
    if (is.numeric(x) || is.logical(x)) { x <- as.numeric(x); x[!is.finite(x)] <- NA_real_ }   # Inf is missing
    else x <- factor(as.character(x))
    d[[names(xmap)[i]]] <- x
  }
  xv <- names(xmap)
  d$time[!is.finite(d$time)] <- NA_real_

  cov_ok <- if (length(xv)) stats::complete.cases(d[, xv, drop = FALSE]) else rep(TRUE, nrow(d))
  reasons <- c(
    "missing or non-finite time" = sum(is.na(d$time)),
    "time <= 0"         = sum(!is.na(d$time) & d$time <= 0),
    "missing event"     = sum(is.na(d$event)),
    "missing treatment" = sum(is.na(d$A)),
    "missing or non-finite covariate" = sum(!cov_ok)
  )
  ok <- !is.na(d$time) & d$time > 0 & !is.na(d$event) & !is.na(d$A) & cov_ok
  n_dropped <- sum(!ok)
  d <- d[ok, , drop = FALSE]
  rownames(d) <- NULL
  if (!nrow(d)) stop("no usable rows after exclusions (", paste(names(reasons)[reasons > 0], reasons[reasons > 0], sep = ": ", collapse = ", "), ")", call. = FALSE)
  if (length(unique(d$A)) < 2) stop("after exclusions only one treatment arm remains", call. = FALSE)
  for (cn in xv) if (is.factor(d[[cn]])) d[[cn]] <- droplevels(d[[cn]])
  keep <- vapply(xv, function(cn) length(unique(d[[cn]])) > 1, logical(1))
  constant <- xv[!keep]
  xv <- xv[keep]

  labels <- c(treated = "Treated", control = "Control")
  if (has("label_col")) {
    lab <- as.character(df[[spec$label_col]])[ok]
    m1 <- names(which.max(table(lab[d$A == 1]))); m0 <- names(which.max(table(lab[d$A == 0])))
    if (length(m1)) labels["treated"] <- m1
    if (length(m0)) labels["control"] <- m0
  }
  attr(d, "xvars")            <- xv
  attr(d, "xvar_labels")      <- xmap[xv]
  attr(d, "n_dropped")        <- n_dropped
  attr(d, "drop_reasons")     <- reasons[reasons > 0]
  attr(d, "constant_dropped") <- unname(xmap[constant])
  attr(d, "arm_labels")       <- labels
  d
}

data_summary <- function(d) {
  km <- survival::survfit(survival::Surv(time, 1 - event) ~ 1, data = d)   # reverse KM follow-up
  xmap <- attr(d, "xvar_labels")
  list(n = nrow(d), events = sum(d$event), n_treated = sum(d$A == 1), n_control = sum(d$A == 0),
       median_followup = unname(summary(km)$table["median"]),
       n_dropped = attr(d, "n_dropped"), drop_reasons = attr(d, "drop_reasons"),
       xvars = attr(d, "xvars"), xvar_labels = xmap,
       renamed = xmap[names(xmap) != unname(xmap)],
       constant_dropped = attr(d, "constant_dropped"),
       arm_labels = attr(d, "arm_labels"))
}
