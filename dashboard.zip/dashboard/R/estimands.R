# WHAT IS REPORTED FROM A PAIR OF MARGINAL CURVES - the same for every method.
#
#   RD(t)    S1(t) - S0(t)                       survival difference at t
#   RMST(t)  int_0^t S1 - int_0^t S0             restricted mean survival time difference
#   CHR(t)   log S1(t) / log S0(t)               cumulative hazard ratio at t
#   HR(t)    h1(t) / h0(t) from smoothed cumulative hazards, and CHR over time

ESTIMAND_LABELS <- c(RD = "Survival difference (RD)", RMST = "RMST difference", CHR = "Cumulative hazard ratio")
ESTIMAND_NULL   <- c(RD = 0, RMST = 0, CHR = 1)

# Survival at t from a curve on the grid: the value at the last grid time <= t.
# Past the last finite point the curve is not known (follow-up has ended):
# NA, never the last value carried forward.
s_at <- function(cv, arm, t) {
  v <- cv[[arm]]; ok <- which(is.finite(v))
  if (!length(ok) || t > max(cv$time[ok]) + 1e-9) return(NA_real_)
  j <- ok[cv$time[ok] <= t + 1e-9]
  if (!length(j)) return(NA_real_)
  v[max(j)]
}

# RMST to tau from a curve on the grid. A step curve (attr "step": Kaplan-
# Meier, Cox) is integrated as a step function, exact when its knots are on
# the grid; any other curve linearly between grid points (trapezoid). NA when
# follow-up ends before tau.
rmst_at <- function(cv, arm, tau, step = isTRUE(attr(cv, "step"))) {
  if (!is.finite(s_at(cv, arm, tau))) return(NA_real_)
  tt <- sort(unique(c(cv$time[cv$time <= tau + 1e-9], tau)))
  Sv <- stats::approx(cv$time, cv[[arm]], xout = tt, method = if (step) "constant" else "linear", f = 0, rule = 2)$y
  if (step) sum(diff(tt) * utils::head(Sv, -1))
  else sum(diff(tt) * (utils::head(Sv, -1) + utils::tail(Sv, -1)) / 2)
}

curve_estimands <- function(cv, s) {
  rows <- list()
  for (t in s$report_times) {
    rows[[length(rows) + 1]] <- data.frame(estimand = "RD",   time = t, est = s_at(cv, "s1", t) - s_at(cv, "s0", t))
    rows[[length(rows) + 1]] <- data.frame(estimand = "RMST", time = t, est = rmst_at(cv, "s1", t) - rmst_at(cv, "s0", t))
  }
  t  <- s$chr_time
  S1 <- s_at(cv, "s1", t); S0 <- s_at(cv, "s0", t)
  l1 <- -log(pmax(S1, 1e-10)); l0 <- -log(pmax(S0, 1e-10))
  rows[[length(rows) + 1]] <- data.frame(estimand = "CHR", time = t,
                                         est = if (is.finite(l1) && is.finite(l0) && l0 > 0) l1 / l0 else NA_real_)
  out <- do.call(rbind, rows)
  rownames(out) <- NULL
  out
}

# Analytic intervals from a method's influence curves.
#
# A method may attach attr(curves, "ic") = list(s1, s0): n x length(grid)
# matrices of each subject's centred influence-curve value for the survival
# probability under each arm at each grid time. Every estimand is then a
# known functional of the two curves, so its standard error follows from the
# same matrices (delta method), with the nuisance models taken as known:
#   RD(t)    ic1(t) - ic0(t)
#   RMST(t)  the trapezoid integral of that to t
#   CHR(t)   -ic1/(S1 L0) + L1 ic0/(S0 L0^2),  L = -log S  (interval on the log scale)
ic_intervals <- function(ic, cv, est, grid, level = 0.95) {
  n <- nrow(ic$s1)
  z <- stats::qnorm(1 - (1 - level) / 2)
  step <- isTRUE(attr(cv, "step"))
  trap_w <- function(tau) {
    j <- which(grid <= tau + 1e-9); w <- numeric(length(grid))
    if (length(j) > 1) { dt <- diff(grid[j]); w[j] <- if (step) c(dt, 0) else c(dt / 2, 0) + c(0, dt / 2) }
    w
  }
  out <- data.frame(se = rep(NA_real_, nrow(est)), lower = NA_real_, upper = NA_real_)
  for (r in seq_len(nrow(est))) {
    j <- which(abs(grid - est$time[r]) < 1e-9)[1]
    if (is.na(j) || !is.finite(est$est[r])) next
    icd <- switch(est$estimand[r],
      RD   = ic$s1[, j] - ic$s0[, j],
      RMST = { w <- trap_w(est$time[r]); as.vector(ic$s1 %*% w - ic$s0 %*% w) },
      CHR  = {
        S1 <- max(cv$s1[j], 1e-10); S0 <- max(cv$s0[j], 1e-10); L1 <- -log(S1); L0 <- -log(S0)
        if (L0 <= 0) NULL else -ic$s1[, j] / (S1 * L0) + L1 * ic$s0[, j] / (S0 * L0^2)
      })
    if (is.null(icd)) next
    se <- sqrt(sum(icd^2)) / n
    out$se[r] <- se
    if (est$estimand[r] == "CHR") {
      sl <- se / est$est[r]
      out$lower[r] <- est$est[r] * exp(-z * sl); out$upper[r] <- est$est[r] * exp(z * sl)
    } else {
      out$lower[r] <- est$est[r] - z * se; out$upper[r] <- est$est[r] + z * se
    }
  }
  out
}

# Cumulative integration weights: row j holds the weights that integrate a
# curve on `grid` from 0 to grid[j] - as a step function (step = TRUE, exact
# for a Kaplan-Meier or Cox curve with its knots on the grid) or by the
# trapezoid rule (linear between grid points).
trap_matrix <- function(grid, step = FALSE) {
  G <- length(grid); W <- matrix(0, G, G)
  for (j in seq_len(G)[-1]) {
    dt <- diff(grid[seq_len(j)]); w <- numeric(G)
    w[seq_len(j)] <- if (step) c(dt, 0) else c(dt / 2, 0) + c(0, dt / 2)
    W[j, ] <- w
  }
  W
}

# The effect over the WHOLE follow-up, from a pair of curves: the survival
# difference RD(t) at every grid time and the RMST difference as a function of
# the horizon, each with a pointwise band - percentile bands from bootstrap
# replicates of the RD curve when there are any, else from the influence
# curves (the RMST band through the same trapezoid weights), else none.
# bcurves: NULL, or list(s1, s0) of replicate-by-grid matrices from the bootstrap.
# Bootstrap replicates arrive as list(s1, s0): replicate-by-grid matrices, NA
# where a replicate failed or follow-up had ended, with attr "min_ok" (the
# runner's floor: 80% of B, at least 2). A limit is reported only where at
# least that many replicates gave a value - estimand by estimand, time by time.
.boot_min_ok <- function(bcurves) attr(bcurves, "min_ok") %||% max(2L, ceiling(0.8 * nrow(bcurves$s1)))
.boot_ok <- function(bcurves) {
  if (is.null(bcurves) || !is.list(bcurves) || is.null(bcurves$s1) || !nrow(bcurves$s1)) return(NULL)
  bcurves
}
.boot_limits <- function(m, min_ok, probs = c(0.025, 0.975)) {
  n_fin <- colSums(is.finite(m))
  lo <- hi <- rep(NA_real_, ncol(m))
  j <- which(n_fin >= min_ok)
  if (length(j)) {
    q <- apply(m[, j, drop = FALSE], 2, stats::quantile, probs = probs, na.rm = TRUE, names = FALSE)
    lo[j] <- q[1, ]; hi[j] <- q[2, ]
  }
  list(lower = lo, upper = hi, n = n_fin)
}

effect_curves <- function(cv, ic = NULL, bcurves = NULL, level = 0.95) {
  g <- cv$time
  step <- isTRUE(attr(cv, "step"))
  rd <- cv$s1 - cv$s0                                  # NA once either arm's follow-up has ended
  W  <- trap_matrix(g, step)
  known <- is.finite(rd)
  rmst <- as.vector(W %*% ifelse(known, rd, 0)); rmst[!known] <- NA_real_
  out <- data.frame(time = g, rd = rd, rd_lower = NA_real_, rd_upper = NA_real_,
                    rmst = rmst, rmst_lower = NA_real_, rmst_upper = NA_real_)
  z <- stats::qnorm(1 - (1 - level) / 2)
  ci_type <- NA_character_
  bc <- .boot_ok(bcurves)
  if (!is.null(bc)) {
    min_ok <- .boot_min_ok(bc)
    rdb <- bc$s1 - bc$s0                               # replicates x grid
    fin <- is.finite(rdb)
    brmst <- ifelse(fin, rdb, 0) %*% t(W); brmst[!fin] <- NA_real_
    lr <- .boot_limits(rdb, min_ok); lm <- .boot_limits(brmst, min_ok)
    out$rd_lower <- lr$lower;   out$rd_upper <- lr$upper
    out$rmst_lower <- lm$lower; out$rmst_upper <- lm$upper
    if (any(is.finite(out$rd_lower))) ci_type <- "bootstrap"
  } else if (!is.null(ic)) {
    icd <- ic$s1 - ic$s0                               # n x G, centred
    n <- nrow(icd)
    se_rd   <- sqrt(colSums(icd^2)) / n
    se_rmst <- sqrt(colSums((icd %*% t(W))^2)) / n
    out$rd_lower <- rd - z * se_rd;             out$rd_upper <- rd + z * se_rd
    out$rmst_lower <- out$rmst - z * se_rmst;   out$rmst_upper <- out$rmst + z * se_rmst
    ci_type <- "influence curve"
  }
  attr(out, "ci_type") <- ci_type
  out
}

# E-VALUE (VanderWeele & Ding 2017): the minimum strength of association, on
# the risk-ratio scale, that an unmeasured confounder would need with both
# treatment and outcome to explain away the estimate. Taken on the risk ratio
# of the event by the CHR time, read straight off the two marginal curves
# (risk = 1 - survival), so it needs no rare-outcome approximation. A second
# E-value is given for the confidence limit nearest the null (1 when the
# interval covers the null).
evalue_rr <- function(rr) {
  rr <- ifelse(is.finite(rr) & rr < 1, 1 / rr, rr)
  ifelse(is.finite(rr) & rr >= 1, rr + sqrt(rr * (rr - 1)), NA_real_)
}

evalue_table <- function(cv, s, ic = NULL, bcurves = NULL, level = 0.95) {
  t <- s$chr_time
  j <- which(abs(cv$time - t) < 1e-9)[1]
  r1 <- 1 - cv$s1[j]; r0 <- 1 - cv$s0[j]
  rr <- if (is.finite(r1) && is.finite(r0) && r0 > 0) r1 / r0 else NA_real_
  lower <- upper <- NA_real_; ci_type <- NA_character_
  z <- stats::qnorm(1 - (1 - level) / 2)
  bc <- .boot_ok(bcurves)
  if (!is.null(bc)) {
    rrb <- (1 - bc$s1[, j]) / (1 - bc$s0[, j])
    rrb <- rrb[is.finite(rrb)]
    if (length(rrb) >= .boot_min_ok(bc)) { lower <- stats::quantile(rrb, 0.025, names = FALSE); upper <- stats::quantile(rrb, 0.975, names = FALSE); ci_type <- "bootstrap" }
  } else if (!is.null(ic) && is.finite(rr) && r1 > 0 && r0 > 0) {
    icl <- -ic$s1[, j] / r1 + ic$s0[, j] / r0          # influence curve of log RR
    se <- sqrt(sum(icl^2)) / nrow(ic$s1)
    lower <- rr * exp(-z * se); upper <- rr * exp(z * se); ci_type <- "influence curve"
  }
  ev_ci <- if (is.finite(rr) && is.finite(lower) && is.finite(upper)) {
    if (lower <= 1 && upper >= 1) 1 else evalue_rr(if (rr >= 1) lower else upper)
  } else NA_real_
  data.frame(time = t, risk_treated = r1, risk_control = r0, rr = rr, rr_lower = lower, rr_upper = upper,
             evalue = evalue_rr(rr), evalue_ci = ev_ci, ci_type = ci_type, stringsAsFactors = FALSE)
}

# How far apart the methods are, estimand by estimand: the spread, which
# method sits at each end, and whether every method is on the same side of
# the null. The question a comparison dashboard exists to answer.
agreement_table <- function(est) {
  if ("status" %in% names(est)) est <- est[est$status == "ok", , drop = FALSE]   # an incomplete estimate is no evidence of agreement
  est <- est[is.finite(est$est), , drop = FALSE]
  if (!nrow(est)) return(data.frame())
  key <- unique(est[, c("estimand", "time")])
  rows <- lapply(seq_len(nrow(key)), function(i) {
    e <- est[est$estimand == key$estimand[i] & est$time == key$time[i], , drop = FALSE]
    null <- ESTIMAND_NULL[[key$estimand[i]]]
    data.frame(estimand = key$estimand[i], time = key$time[i], methods = nrow(e),
               median = stats::median(e$est), min = min(e$est), min_method = e$method[which.min(e$est)],
               max = max(e$est), max_method = e$method[which.max(e$est)], range = diff(range(e$est)),
               same_side_of_null = all(e$est > null) || all(e$est < null),
               stringsAsFactors = FALSE)
  })
  out <- do.call(rbind, rows); rownames(out) <- NULL; out
}

hr_over_time <- function(cv, df = 6) {
  L1 <- -log(pmax(cv$s1, 1e-6)); L0 <- -log(pmax(cv$s0, 1e-6))
  out <- data.frame(time = cv$time, chr = ifelse(L0 > 1e-8, L1 / L0, NA_real_), hr = NA_real_)
  ok <- is.finite(L1) & is.finite(L0)
  if (sum(ok) >= 5) {
    fit <- function(L) suppressWarnings(stats::smooth.spline(cv$time[ok], L[ok], df = min(df, sum(ok) - 1)))
    h1 <- stats::predict(fit(L1), cv$time, deriv = 1)$y
    h0 <- stats::predict(fit(L0), cv$time, deriv = 1)$y
    out$hr <- ifelse(h0 > 1e-4 & h1 > 0, h1 / h0, NA_real_)
    out$hr[!ok] <- NA_real_                            # nothing past the end of follow-up
  }
  out
}

# Follow-up ends at each arm's last observed time (event or censoring). A
# curve past it is the last value carried forward, or a model's extrapolation:
# not an estimate of anything observed. The runner blanks it, and everything
# derived from the curves is NA there, with the reason in the result's notes.
followup_ends <- function(d) c(s1 = max(d$time[d$A == 1]), s0 = max(d$time[d$A == 0]))

# Where each arm's curve is known: to the arm's last observed time, or for
# ever once it has reached zero within follow-up (survival cannot rise, so
# that tail is zero, not a guess).
# Whether each arm's risk set emptied with an event - everyone in the arm had
# the event - so that survival past the arm's last time is zero as a fact of
# the data, not as a value a method happened to estimate or clip to.
risk_set_emptied <- function(d) {
  one <- function(a) { t <- d$time[d$A == a]; e <- d$event[d$A == a]; length(t) > 0 && all(e[t >= max(t) - 1e-9] == 1) }
  c(s1 = one(1), s0 = one(0))
}

# Where each arm's curve is known: to the arm's last observed time, or for
# ever when the data emptied the arm's risk set with an event AND the curve
# is at zero there (survival cannot rise). A zero that a method estimated or
# clipped to, with patients still censored, is not that.
support_ends <- function(cv, fu, emptied = c(s1 = FALSE, s0 = FALSE)) {
  one <- function(arm) {
    v <- cv[[arm]]; j <- which(cv$time <= fu[[arm]] + 1e-9)
    if (isTRUE(emptied[[arm]]) && length(j) && is.finite(v[max(j)]) && v[max(j)] <= 1e-12) Inf else fu[[arm]]
  }
  c(s1 = one("s1"), s0 = one("s0"))
}

clip_to_followup <- function(cv, fu) {
  cv$s1[cv$time > fu[["s1"]] + 1e-9] <- NA_real_
  cv$s0[cv$time > fu[["s0"]] + 1e-9] <- NA_real_
  cv
}

followup_note <- function(fu, est, arm_labels = NULL) {
  lab <- function(a) if (!is.null(arm_labels) && !is.null(arm_labels[[a]])) arm_labels[[a]] else a
  bad <- est[!est$within_followup, , drop = FALSE]
  sprintf("follow-up ends at %s (%s) and %s (%s): %s beyond that %s not estimated",
          format(round(fu[["s1"]], 2)), lab("treated"), format(round(fu[["s0"]], 2)), lab("control"),
          paste(unique(sprintf("%s at %s", bad$estimand, format(bad$time))), collapse = ", "),
          if (nrow(bad) > 1) "are" else "is")
}

# A replicate's curves on the main grid, for the pointwise bands only (its
# estimands are taken on its own grid): a step curve by its value at the last
# of its own times <= t, any other curve linearly; NA past its own support.
align_curves <- function(cv, grid, step = isTRUE(attr(cv, "step"))) {
  one <- function(arm) {
    v <- cv[[arm]]; ok <- is.finite(v)
    if (sum(ok) < 2) return(rep(NA_real_, length(grid)))
    out <- stats::approx(cv$time[ok], v[ok], xout = grid, method = if (step) "constant" else "linear", f = 0, rule = 2)$y
    out[grid > max(cv$time[ok]) + 1e-9] <- NA_real_
    out
  }
  list(s1 = one("s1"), s0 = one("s0"))
}
