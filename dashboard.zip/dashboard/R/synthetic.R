# SYNTHETIC cohorts, generated in-process, with the same schema as the real
#   docetaxel_nivolumab_EC_<scenario>_feature_table.csv
# files (one per eligibility scenario) - including the pandas index junk they
# carry - so the loader, the column mapping and every method run on exactly
# the shape the real files have. Nothing here is derived from real patients,
# and a page showing these numbers says so in a banner.
#
# data/make_synthetic.R writes these to CSV for inspection or for DASH_SOURCE=files.

SYNTHETIC_SCENARIOS <- list(
  "Fully relaxed"    = function(p) rep(TRUE, nrow(p)),
  "ECOG"             = function(p) p$ecog <= 1,
  "STAGE"            = function(p) p$stage == "METASTATIC",
  "HISTOLOGY"        = function(p) p$histology == "NON-SQUAMOUS",
  "HISTOLOGY_ECOG"   = function(p) p$histology == "NON-SQUAMOUS" & p$ecog <= 1,
  "HISTOLOGY_STAGE"  = function(p) p$histology == "NON-SQUAMOUS" & p$stage == "METASTATIC",
  "STAGE_ECOG"       = function(p) p$stage == "METASTATIC" & p$ecog <= 1,
  "Fully restricted" = function(p) p$histology == "NON-SQUAMOUS" & p$stage == "METASTATIC" & p$ecog <= 1
)

# One population; the scenarios are restrictions of it, as the real cohorts are.
# True conditional HR for nivolumab vs docetaxel = exp(-0.36) ~ 0.70; durations in DAYS.
synthetic_population <- function(n = 4000, seed = 2026) {
  set.seed(seed)
  age        <- round(rnorm(n, 64, 9))
  sex        <- sample(c("F", "M"), n, TRUE, prob = c(0.4, 0.6))
  ecog       <- sample(0:2, n, TRUE, prob = c(0.35, 0.45, 0.20))
  histology  <- sample(c("NON-SQUAMOUS", "SQUAMOUS"), n, TRUE, prob = c(0.7, 0.3))
  stage      <- sample(c("ADVANCED", "METASTATIC"), n, TRUE, prob = c(0.35, 0.65))
  linenumber <- sample(1:5, n, TRUE, prob = c(0.50, 0.25, 0.12, 0.08, 0.05))

  lp_trt <- -0.2 - 0.03 * (age - 64) - 0.6 * (ecog == 2) + 0.4 * (linenumber >= 2) +
            0.3 * (histology == "SQUAMOUS")
  ps        <- plogis(lp_trt)
  treatment <- rbinom(n, 1, ps)

  lp_out <- 0.02 * (age - 64) + 0.5 * (ecog == 2) + 0.2 * (ecog == 1) +
            0.15 * (stage == "METASTATIC") + 0.1 * (histology == "SQUAMOUS") - 0.36 * treatment
  shape  <- 1.2
  Tt     <- rweibull(n, shape = shape, scale = 400 * exp(-lp_out / shape))
  Cc     <- runif(n, 180, 1100)
  duration <- round(pmin(Tt, Cc))
  event    <- as.numeric(Tt <= Cc)
  duration[sample(n, round(0.03 * n))] <- NA            # the real files have some

  data.frame(
    patientid  = sprintf("F%s", toupper(substr(sprintf("%012x", sample(.Machine$integer.max, n)), 1, 11))),
    duration, event,
    treatment  = as.numeric(treatment),
    weights    = 1 / ifelse(treatment == 1, ps, 1 - ps),
    `Unnamed: 0` = seq_len(n) - 1L,
    linename   = ifelse(treatment == 1, "nivolumab", "docetaxel"),
    linenumber, stage, histology, ecog, age, sex,
    check.names = FALSE, stringsAsFactors = FALSE
  )
}

synthetic_cohorts <- function(pop = synthetic_population()) {
  lapply(SYNTHETIC_SCENARIOS, function(keep) {
    sub <- pop[keep(pop), ]
    rownames(sub) <- NULL
    sub
  })
}

# The registry rows a synthetic source offers (see R/sources.R for the shape).
synthetic_cohort_registry <- function() {
  ids <- names(SYNTHETIC_SCENARIOS)
  data.frame(
    id = ids, label = ids,
    file = NA_character_,
    description = sprintf("Synthetic eligibility scenario '%s' (generated, not study data)", ids),
    synthetic = TRUE,
    provenance = "generated in-process",
    stringsAsFactors = FALSE
  )
}
