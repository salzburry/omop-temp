# THE SETTINGS every method may read. One list, built once per run from the
# page (app.R, settings_from_inputs) or from these defaults (tests, headless
# runs). A method declares in R/methods.R which of these it uses, and the
# Methods page shows that beside it.

parse_times <- function(x) {
  v <- suppressWarnings(as.numeric(trimws(strsplit(as.character(x), "[,;[:space:]]+")[[1]])))
  sort(unique(v[is.finite(v) & v > 0]))
}

# Every setting has an environment variable, so the precompute Job can be
# run under exactly the configuration a page would use, and a page starts
# from what the Job used.
default_settings <- function(cfg = dashboard_config()) list(
  report_times = parse_times(cfg$report_times),   # RD and RMST reported at each            (DASH_REPORT_TIMES)
  chr_time     = cfg$chr_time,                    # cumulative hazard ratio at this time    (DASH_CHR_TIME)
  time_divisor = cfg$time_divisor,                # duration / this = analysis units        (DASH_TIME_DIVISOR)
  time_unit    = cfg$time_unit,                   # label for axes and tables; no effect on numbers
  grid_points  = cfg$grid_points,                 # curve resolution                        (DASH_GRID_POINTS)
  grid_knots   = .env_num("DASH_GRID_KNOTS", 1000),   # distinct event times put on the grid, at most   (DASH_GRID_KNOTS)

  interval     = .env_num("DASH_INTERVAL", 1),         # bin width for discrete-time (pooled logistic) methods
  time_df      = .env_num("DASH_TIME_DF", 3),          # natural-spline df of the time term in pooled models
  tmle_grid    = .env_chr("DASH_TMLE_GRID", "fixed"),  # "fixed" width, or "event" (unique event times, thinned to max_bins)
  tmle_width   = .env_num("DASH_TMLE_WIDTH", 2),       # TMLE bin width when fixed
  max_bins     = .env_num("DASH_MAX_BINS", 100),       # cap on bins for an event-driven grid
  tmle_max_iter = .env_num("DASH_TMLE_MAX_ITER", 10),
  tmle_tol     = .env_num("DASH_TMLE_TOL", 1e-4),

  ps_bounds    = .env_num("DASH_PS_BOUNDS", 0.01),     # propensity (and censoring survival) floored at this, capped at 1 - this
  psm_caliper  = .env_num("DASH_PSM_CALIPER", 0.2),    # balance diagnostics: 1:1 matching caliper, in SDs of the logit propensity score
  stabilize    = .env_lgl("DASH_STABILIZE", TRUE),     # stabilised IPT weights
  use_provided_weights = .env_lgl("DASH_USE_PROVIDED_WEIGHTS", FALSE),  # the cohort's weights column instead of a fitted PS
  extra_ps     = .env_chr("DASH_EXTRA_PS", ""),        # extra terms appended to the PS model, e.g. "I(age^2) + age:ecog"
  extra_out    = .env_chr("DASH_EXTRA_OUT", ""),       # extra terms appended to the outcome model

  boot_B       = .env_num("DASH_BOOT_B", 0),           # bootstrap replicates for CIs; 0 = point estimates only
  seed         = .env_num("DASH_SEED", 2026)
)

# Curves run from 0 to the latest time anyone asked about; the report times and
# the CHR time are on the grid exactly, so nothing is interpolated at them.
# With the cohort given, its distinct event times up to that horizon are on
# the grid too, and so are any `extra` times a method says its curves jump
# at (bin ends, censoring times): a step curve is then represented at its
# knots and the RMST integral loses no jump. Beyond `grid_knots` such times
# they are thinned by rank, and the grid says so (attr "note").
make_grid <- function(s, d = NULL, extra = NULL) {
  tmax <- max(c(s$report_times, s$chr_time))
  np <- suppressWarnings(as.integer(s$grid_points)); if (is.na(np)) np <- 61L
  g <- seq(0, tmax, length.out = max(11L, np))
  g <- c(g, s$report_times, s$chr_time)
  knots <- numeric()
  if (is.data.frame(d) && !is.null(d$time) && !is.null(d$event))
    knots <- d$time[d$event == 1 & is.finite(d$time) & d$time > 0 & d$time <= tmax]
  if (length(extra)) knots <- c(knots, extra[is.finite(extra) & extra > 0 & extra <= tmax])
  knots <- sort(unique(knots)); knots <- knots[!(knots %in% g)]
  note <- NULL
  cap <- suppressWarnings(as.integer(s$grid_knots %||% 1000)); if (is.na(cap)) cap <- 1000L
  cap <- max(10L, cap)
  if (length(knots) > cap) {
    note <- sprintf("the cohort has %d distinct event times (with the method's own knots, if any) up to %s; the curves are evaluated at %d of them (DASH_GRID_KNOTS), so the RMST integral is approximate",
                    length(knots), format(tmax), cap)
    knots <- knots[unique(round(seq(1, length(knots), length.out = cap)))]
  }
  g <- sort(unique(c(g, knots)))
  attr(g, "note") <- note
  g
}

# A string that changes when any setting a run depends on changes, so a result
# can say which settings produced it. Labels are left out: they change nothing.
settings_key <- function(s) {
  s$time_unit <- NULL
  s <- s[sort(names(s))]
  paste(names(s), vapply(s, function(v) paste(format(v), collapse = ","), character(1)), sep = "=", collapse = ";")
}

# What an extra model term may contain: covariate names, numbers, and these
# functions. A term is parsed and walked before it goes anywhere near a model,
# so a viewer's text can shape a model but never run code.
FORMULA_FUNCTIONS <- c("+", "-", "*", ":", "^", "(", "I", "log", "log1p", "sqrt", "exp", "abs",
                       "poly", "ns", "bs", "factor", "as.factor", "as.numeric", "pmin", "pmax", "scale")

check_formula_terms <- function(text, allowed_vars = NULL) {
  text <- trimws(text %||% "")
  if (!nzchar(text)) return(character())
  ex <- tryCatch(parse(text = text, keep.source = FALSE), error = function(e) NULL)
  if (is.null(ex) || length(ex) != 1L) return(sprintf("'%s' is not one valid expression", text))
  bad <- character()
  walk <- function(e) {
    if (is.numeric(e) || is.logical(e)) return(invisible())
    if (is.symbol(e)) {
      nm <- as.character(e)
      if (!is.null(allowed_vars) && !(nm %in% allowed_vars))
        bad <<- c(bad, sprintf("'%s' is not a covariate of this cohort (use the modelling names shown on the Data page)", nm))
      return(invisible())
    }
    if (is.call(e)) {
      fn <- e[[1]]
      fname <- if (is.symbol(fn)) as.character(fn)
               else if (is.call(fn) && identical(as.character(fn[[1]]), "::") && identical(as.character(fn[[2]]), "splines")) as.character(fn[[3]])
               else paste(deparse(fn), collapse = "")
      if (!(fname %in% FORMULA_FUNCTIONS)) bad <<- c(bad, sprintf("'%s' is not allowed in a model term", fname))
      args <- as.list(e)[-1]
      for (a in args) if (!identical(a, quote(expr = ))) walk(a)
      return(invisible())
    }
    bad <<- c(bad, sprintf("'%s' is not allowed in a model term", paste(deparse(e), collapse = "")))
  }
  walk(ex[[1]])
  unique(bad)
}

settings_problems <- function(s, xvars = NULL) {
  p <- character()
  if (!length(s$report_times)) p <- c(p, "no report times given")
  if (!is.finite(s$chr_time) || s$chr_time <= 0) p <- c(p, "CHR time must be > 0")
  if (!is.finite(s$time_divisor) || s$time_divisor <= 0) p <- c(p, "time divisor must be > 0")
  if (!is.finite(s$interval) || s$interval <= 0) p <- c(p, "interval width must be > 0")
  if (!is.finite(s$tmle_width) || s$tmle_width <= 0) p <- c(p, "TMLE interval width must be > 0")
  if (!is.finite(s$time_df) || s$time_df < 1) p <- c(p, "time spline df must be at least 1")
  if (!is.finite(s$seed)) p <- c(p, "seed must be a number")
  if (!is.finite(s$ps_bounds) || s$ps_bounds < 0 || s$ps_bounds >= 0.5) p <- c(p, "PS bound must be in [0, 0.5)")
  whole <- function(v, lo) is.numeric(v) && length(v) == 1L && is.finite(v) && v == round(v) && v >= lo
  if (!whole(s$grid_points %||% NA_real_, 11)) p <- c(p, "grid points must be a whole number of at least 11")
  if (!whole(s$grid_knots %||% NA_real_, 10)) p <- c(p, "grid knots must be a whole number of at least 10")
  for (f in c("extra_ps", "extra_out")) if (nzchar(s[[f]] %||% "")) {
    bad <- check_formula_terms(s[[f]], xvars)
    if (length(bad)) p <- c(p, sprintf("%s: %s", f, paste(bad, collapse = "; ")))
  }
  p
}
