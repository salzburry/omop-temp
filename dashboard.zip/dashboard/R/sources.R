# WHERE THE COHORTS COME FROM. Two sources, one interface.
#
#   synthetic  generated in-process (R/synthetic.R). The default, so a first
#              deploy comes up and can be clicked through before any data is
#              attached. Every page says so.
#   files      every CSV matching DASH_FILE_PATTERN under DASH_DATA_DIR (or,
#              unset, this folder and its data/), plus the rows of cohorts.csv.
#              No files is a registry with no rows, not an error: the App
#              starts and says so.
#
# ADDING A COHORT in files mode is dropping a file in that folder - it is
# discovered by name - or adding a row to cohorts.csv, which can also give it
# a label, a description and a fixed column mapping. cohorts.csv is looked
# for, in this order: an absolute DASH_COHORTS_CSV as given; the data
# folder(s); this folder. The App reads the registry at startup; restart it
# after adding.
#
# The registry is a data.frame with one row per cohort:
#   id, label, file (NA for synthetic), description, missing_file, plus any
#   mapping columns from cohorts.csv (time_col, event_col, trt_col,
#   treated_value, weights_col, id_col, label_col, covariates).
#
# Registry cohorts are immutable and shared, so they are read once per process.
# UPLOADS belong to one session: they live in a store the session owns
# (new_cohort_store()), never in the process-wide cache, so two viewers who
# upload files of the same name never see each other's data, and a cohort's
# identity for the results cache is the checksum of what was actually read.

cohort_id_from_file <- function(files) {
  stem <- sub("\\.[^.]+$", "", basename(files))
  sub("_feature_table$", "", stem)
}

.read_cohorts_csv <- function(path) {
  csv <- utils::read.csv(path, stringsAsFactors = FALSE, check.names = FALSE, na.strings = c("", "NA"))
  names(csv) <- trimws(names(csv))
  if (!"id" %in% names(csv)) stop("cohorts.csv needs an 'id' column", call. = FALSE)
  csv$id <- trimws(as.character(csv$id))
  csv <- csv[nzchar(csv$id) & !is.na(csv$id), , drop = FALSE]
  if (anyDuplicated(csv$id)) stop("cohorts.csv has duplicate ids: ",
                                  paste(unique(csv$id[duplicated(csv$id)]), collapse = ", "), call. = FALSE)
  csv
}

# Where cohorts.csv is: an absolute DASH_COHORTS_CSV as given, else the first
# of the data folder(s) and this folder that holds one. Never the working
# directory: what the App finds must not depend on where it was started.
registry_path <- function(cfg, dirs, dash_dir) {
  p <- cfg$cohorts_csv %||% ""
  if (!nzchar(p)) return("")
  if (grepl("^(/|[A-Za-z]:)", p)) return(if (file.exists(p)) normalizePath(p, winslash = "/") else "")
  cands <- c(file.path(dirs, p), file.path(dash_dir, p))
  hit <- cands[file.exists(cands)]
  if (length(hit)) normalizePath(hit[1], winslash = "/") else ""
}

.empty_registry <- function()
  data.frame(id = character(), label = character(), file = character(), description = character(),
             stringsAsFactors = FALSE)

# Every registry row says whether its data are generated (`synthetic`). Only a
# row that says so may be served from the generator: in files mode a row
# without a file is an error, never a quiet fallback to synthetic numbers.
discover_cohorts <- function(cfg, dash_dir = getwd()) {
  if (identical(cfg$source, "synthetic")) {
    reg <- synthetic_cohort_registry(); reg$missing_file <- FALSE; reg$synthetic <- TRUE; return(reg)
  }
  if (!identical(cfg$source, "files"))
    stop("DASHBOARD ERROR: DASH_SOURCE='", cfg$source, "' is not one of synthetic, files.", call. = FALSE)

  dirs <- if (nzchar(cfg$data_dir)) cfg$data_dir else c(dash_dir, file.path(dash_dir, "data"))
  files <- unlist(lapply(dirs, function(dd) {
    if (dir.exists(dd)) list.files(dd, pattern = cfg$file_pattern, full.names = TRUE, recursive = TRUE)
    else character()
  }))
  files <- if (length(files)) unique(normalizePath(files, winslash = "/", mustWork = FALSE)) else character()
  reg <- if (length(files)) {
    data.frame(id = cohort_id_from_file(files), label = cohort_id_from_file(files),
               file = files, description = rep("", length(files)), stringsAsFactors = FALSE)
  } else .empty_registry()
  # the same file name in two folders is two cohorts, told apart by folder
  if (anyDuplicated(reg$id)) {
    dup <- reg$id %in% reg$id[duplicated(reg$id)]
    reg$id[dup] <- paste0(reg$id[dup], " (", basename(dirname(reg$file[dup])), ")")
    reg$id <- make.unique(reg$id, sep = " #")
    reg$label <- reg$id
    reg$description[dup] <- paste("from", reg$file[dup])
    message("DASHBOARD: cohort files with the same name in different folders were given distinct ids: ",
            paste(reg$id[dup], collapse = ", "))
  }

  csv_path <- registry_path(cfg, dirs, dash_dir)
  if (nzchar(csv_path)) {
    csv <- .read_cohorts_csv(csv_path)
    # a row's file: an absolute path as given; a relative one against the
    # folder holding cohorts.csv, then the data folder(s) - never the working
    # directory, which would let a same-named file elsewhere stand in
    if ("file" %in% names(csv)) {
      csv$file <- vapply(seq_len(nrow(csv)), function(i) {
        f <- csv$file[i]
        if (is.na(f) || !nzchar(f)) return(NA_character_)
        cands <- if (grepl("^(/|[A-Za-z]:)", f)) f else c(file.path(dirname(csv_path), f), file.path(dirs, f))
        hit <- cands[file.exists(cands)]
        if (length(hit)) normalizePath(hit[1], winslash = "/") else normalizePath(cands[1], winslash = "/", mustWork = FALSE)   # not found: its intended place, reported missing
      }, character(1))
    }
    for (i in seq_len(nrow(csv))) {
      row <- csv[i, , drop = FALSE]
      j <- match(row$id, reg$id)
      if (is.na(j)) {                                  # a row for a file discovery did not find
        reg <- merge(reg, row, all = TRUE, sort = FALSE)
      } else {
        for (k in setdiff(names(row), "id")) {
          v <- row[[k]]
          if (!(k %in% names(reg))) reg[[k]] <- NA
          if (length(v) && !is.na(v) && nzchar(as.character(v))) reg[[k]][j] <- v
        }
      }
    }
  }
  reg$label[is.na(reg$label) | !nzchar(reg$label)] <- reg$id[is.na(reg$label) | !nzchar(reg$label)]
  reg$description[is.na(reg$description)] <- ""
  reg$file <- as.character(reg$file)
  reg$missing_file <- is.na(reg$file) | !nzchar(reg$file) | !file.exists(reg$file)
  # provenance of a file-backed cohort: declared in cohorts.csv (synthetic =
  # TRUE), or found in a SYNTHETIC.md5 marker beside the file (which the
  # generator writes for every file it produces)
  declared <- if ("synthetic" %in% names(reg)) toupper(trimws(as.character(reg$synthetic))) %in% c("TRUE", "T", "1", "YES") else rep(FALSE, nrow(reg))
  marked <- vapply(seq_len(nrow(reg)), function(i) !reg$missing_file[i] && synthetic_marked(reg$file[i]), logical(1))
  reg$synthetic <- declared | marked
  reg$provenance <- ifelse(marked, "generated (SYNTHETIC.md5)", ifelse(declared, "declared synthetic in cohorts.csv", "file (not verified)"))
  rownames(reg) <- NULL
  reg
}

# Every checksum any SYNTHETIC.md5 under the given folders lists: what an
# upload is checked against, since an upload arrives without its marker.
known_synthetic_md5s <- function(dirs) {
  markers <- unlist(lapply(dirs[dir.exists(dirs)], function(dd)
    list.files(dd, pattern = "^SYNTHETIC\\.md5$", recursive = TRUE, full.names = TRUE)))
  unique(unlist(lapply(markers, function(m) vapply(strsplit(readLines(m, warn = FALSE), "\\s+"), `[`, character(1), 1))))
}

# Whether a file is listed, by checksum, in a SYNTHETIC.md5 marker in its folder.
synthetic_marked <- function(path) {
  marker <- file.path(dirname(path), "SYNTHETIC.md5")
  if (!file.exists(marker)) return(FALSE)
  listed <- vapply(strsplit(readLines(marker, warn = FALSE), "\\s+"), `[`, character(1), 1)
  unname(tools::md5sum(path)) %in% listed
}

read_cohort_file <- function(path) {
  ext <- tolower(tools::file_ext(path))
  df <- switch(ext,
    csv  = utils::read.csv(path, stringsAsFactors = FALSE, check.names = FALSE, na.strings = c("", "NA", "NaN", "null")),
    tsv  = utils::read.delim(path, stringsAsFactors = FALSE, check.names = FALSE, na.strings = c("", "NA")),
    rds  = readRDS(path),
    xlsx = , xls = {
      if (!requireNamespace("readxl", quietly = TRUE)) stop("readxl is needed for Excel files")
      as.data.frame(readxl::read_excel(path))
    },
    stop("Unsupported file type: .", ext, call. = FALSE)
  )
  if (!is.data.frame(df)) stop("the file does not hold a data frame", call. = FALSE)
  # a repeated header would be mapped by name and silently take the first column
  nm <- trimws(names(df)); dup <- unique(nm[duplicated(nm) & nzchar(nm)])
  if (length(dup)) stop("the file has repeated column names (", paste(dup, collapse = ", "),
                        "): rename them so each column can be mapped", call. = FALSE)
  as.data.frame(df, stringsAsFactors = FALSE)
}

# ---- stores -----------------------------------------------------------------------

# The process-wide cache: registry cohorts only, keyed by id AND file so a
# registry change never serves another file's rows under an old id.
.cohort_cache <- new.env(parent = emptyenv())

# A session's own store, for uploads.
new_cohort_store <- function() new.env(parent = emptyenv())

# A registry row that may be loaded, or an error. Checked BEFORE any cache is
# consulted, so a row without a file can never be answered from rows cached
# under the same id earlier (synthetic ones included).
# A row is GENERATED when it is synthetic and has no file (the in-process
# source); a synthetic row WITH a file is a generated file and is read like
# any other, only flagged.
.generated <- function(row) isTRUE(row$synthetic) && (is.na(row$file) || !nzchar(row$file))

.loadable_row <- function(reg, id) {
  row <- reg[match(id, reg$id), , drop = FALSE]
  if (!nrow(row) || is.na(row$id)) stop("Unknown cohort: ", id, call. = FALSE)
  if (.generated(row)) return(row)
  if (is.na(row$file) || !nzchar(row$file))
    stop("Cohort '", id, "' has no file in the registry; a cohort without a file is never served from generated data", call. = FALSE)
  if (!file.exists(row$file)) stop("Cohort file not found: ", row$file, call. = FALSE)
  row
}

.global_key <- function(prefix, row)
  paste0(prefix, row$id, "|", if (.generated(row)) "generated" else row$file)

load_cohort <- function(reg, id, store = NULL) {
  if (!is.null(store) && !is.null(store[[paste0("c:", id)]])) return(store[[paste0("c:", id)]])
  row <- .loadable_row(reg, id)
  gk <- .global_key("c:", row)
  if (!is.null(.cohort_cache[[gk]])) return(.cohort_cache[[gk]])
  df <- if (.generated(row)) {
    if (is.null(.cohort_cache$synthetic)) .cohort_cache$synthetic <- synthetic_cohorts()
    .cohort_cache$synthetic[[id]]
  } else read_cohort_file(row$file)
  if (is.null(df)) stop("Cohort '", id, "' has no data", call. = FALSE)
  .cohort_cache[[gk]] <- df
  df
}

# What a cohort's data IS, for the results cache: the checksum of the file as
# read, or of the generated rows for a synthetic cohort.
cohort_hash <- function(reg, id, store = NULL) {
  if (!is.null(store) && !is.null(store[[paste0("h:", id)]])) return(store[[paste0("h:", id)]])
  row <- .loadable_row(reg, id)
  gk <- .global_key("h:", row)
  if (!is.null(.cohort_cache[[gk]])) return(.cohort_cache[[gk]])
  h <- if (!.generated(row)) {
    unname(tools::md5sum(row$file))
  } else {
    f <- tempfile("cohort"); on.exit(unlink(f))
    saveRDS(load_cohort(reg, id, store), f, compress = FALSE)
    unname(tools::md5sum(f))
  }
  .cohort_cache[[gk]] <- h
  h
}

# The data under a mapping: what a result is keyed by. The mapping is
# normalised first (fields in a fixed order, covariates sorted, values as
# text) so the same mapping written two ways is one analysis, and the
# original-to-internal name mapping the models actually see is part of it.
cohort_data_hash <- function(reg, id, spec, store = NULL) {
  sp <- spec[order(names(spec))]
  sp$covariates <- sort(as.character(sp$covariates))
  sp$treated_value <- as.character(sp$treated_value)
  nm <- internal_names(sp$covariates)
  sp$internal <- paste(names(nm), nm, sep = "=")
  md5_string(c(cohort_hash(reg, id, store), deparse(sp)))
}

# The mapping a cohort starts with: the guess, then whatever cohorts.csv fixes.
# A treatment column fixed by the registry gets its treated value guessed
# afresh unless the registry fixes that too.
cohort_spec <- function(reg, id, df = NULL, store = NULL) {
  if (is.null(df)) df <- load_cohort(reg, id, store)
  row <- reg[match(id, reg$id), , drop = FALSE]
  spec <- apply_spec_overrides(auto_spec(df), row)
  if (nzchar(.row_value(row, "trt_col")) && !nzchar(.row_value(row, "treated_value")) && spec$trt %in% names(df))
    spec$treated_value <- guess_treated_value(df[[spec$trt]])
  spec
}

# The one call the App, the precompute Job and the tests all make: a cohort
# prepared under a mapping, carrying what the cache key needs.
prep_cohort <- function(reg, id, spec = cohort_spec(reg, id, store = store), time_divisor = 1, store = NULL) {
  d <- prep_data(load_cohort(reg, id, store), spec, time_divisor)
  attr(d, "cohort_id") <- id
  attr(d, "data_hash") <- cohort_data_hash(reg, id, spec, store)
  d
}

# An uploaded file becomes a cohort of this session only: its rows and the
# checksum of the uploaded file go into the session's store under an id no
# other cohort of this registry has, and the registry gains a row. Its
# provenance is "upload (not verified)" - an upload proves nothing about
# being real data - unless its checksum is one the generator's markers list,
# in which case it is generated data and the production guard applies.
upload_cohort <- function(reg, path, name, store, known_synthetic = character(), allow_synthetic = TRUE) {
  stopifnot(is.environment(store))
  md5 <- unname(tools::md5sum(path))
  synthetic <- md5 %in% known_synthetic
  if (synthetic && !isTRUE(allow_synthetic))
    stop("this upload is generated data (its checksum is in the dashboard's SYNTHETIC.md5 markers) and DASH_ALLOW_SYNTHETIC=FALSE", call. = FALSE)
  df <- read_cohort_file(path)
  base <- cohort_id_from_file(name)
  n <- 1L; id <- sprintf("%s (upload %d)", base, n)
  while (id %in% reg$id) { n <- n + 1L; id <- sprintf("%s (upload %d)", base, n) }
  store[[paste0("c:", id)]] <- df
  store[[paste0("h:", id)]] <- md5
  row <- data.frame(id = id, label = id, file = path,
                    description = sprintf("Uploaded this session from %s", name),
                    missing_file = FALSE, synthetic = synthetic,
                    provenance = if (synthetic) "upload: generated (matches SYNTHETIC.md5)" else "upload (not verified)",
                    stringsAsFactors = FALSE)
  out <- merge(reg, row, all = TRUE, sort = FALSE)
  out$missing_file[is.na(out$missing_file)] <- FALSE
  out$synthetic[is.na(out$synthetic)] <- FALSE
  out$provenance[is.na(out$provenance)] <- ""
  out
}

# Display labels for cohorts: unique, so two cohorts with one label never
# merge in a table or a figure; the id is appended where needed.
cohort_display <- function(reg) {
  lab <- as.character(reg$label)
  dup <- lab %in% lab[duplicated(lab)]
  lab[dup] <- paste0(lab[dup], " [", reg$id[dup], "]")
  if (anyDuplicated(lab)) lab <- make.unique(lab, sep = " #")   # a suffix can collide with a label that already looks like one
  stats::setNames(lab, reg$id)
}
