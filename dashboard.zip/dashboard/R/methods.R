# THE METHOD REGISTRY. One entry per estimator; the Methods page, the Results
# page and the cohort comparison are all generated from it, so ADDING A METHOD
# IS ONE add_method() CALL and nothing else changes.
#
#   id        stable key (results are stored and cached under it)
#   label     what the page shows
#   class     the robustness class it is grouped under (groups appear in the
#             order they are first used here)
#   fn        function(d, xvars, s, grid) -> data.frame(time, s1, s0)
#             - the contract in R/estimators.R; it may attach attr(., "ic")
#             (influence curves) and then gets analytic intervals
#   speed     "fast" or "slow": "Select fast methods" and a (slow) tag
#   requires  packages it needs; a method whose packages are missing is listed
#             as "Not available" rather than silently dropped
#   uses      which settings it reads (shown beside it)
#   note      one line on what it does
#   file      the script the method lives in, shown beside its name; its
#             checksum is part of the results-cache key, so an edited script
#             never serves an old number
#
# The study's own estimators are not registered here: they are DISCOVERED
# from src/ at startup (R/src_methods.R) - a script there that defines
# estimate_curves() is a method, and docs/src_method_template.R shows the
# shape. The entries below are the dashboard's reference implementations.

METHODS <- list()

# The versions that decide a number besides the code: part of every method's
# code hash, so a cache filled under another R or survival is not reused.
environment_hash <- function()
  paste(R.version.string, "survival", as.character(utils::packageVersion("survival")), sep = "|")

.one_string <- function(x) is.character(x) && length(x) == 1L && !is.na(x) && nzchar(trimws(x))

add_method <- function(id, label, class, fn, speed = c("fast", "slow"),
                       requires = character(), uses = character(), note = "", file = "R/estimators.R",
                       code_hash = NULL, knots = NULL) {
  speed <- match.arg(speed)
  if (!is.function(fn)) stop("add_method: fn must be a function", call. = FALSE)
  if (!.one_string(id) || !.one_string(label) || !.one_string(class))
    stop("add_method: id, label and class must each be one non-empty string (NA and blank are not)", call. = FALSE)
  requires <- as.character(requires); requires <- requires[!is.na(requires) & nzchar(trimws(requires))]
  uses <- as.character(uses); uses <- uses[!is.na(uses) & nzchar(trimws(uses))]
  if (!.one_string(note)) note <- ""
  if (!is.null(knots) && !is.function(knots)) stop("add_method: knots must be NULL or a function(d, s, tmax) giving the times the curves jump at", call. = FALSE)
  if (id %in% names(METHODS)) stop("duplicate method id: ", id, call. = FALSE)
  # two methods may not look the same on the page: a repeated label carries its
  # file, and a label repeated beyond that a number
  labels <- vapply(METHODS, `[[`, character(1), "label")
  if (label %in% labels) label <- paste0(label, " (", basename(file), ")")
  if (label %in% labels) label <- make.unique(c(labels, label), sep = " #")[length(labels) + 1L]
  if (is.null(code_hash)) {
    path <- if (file.exists(file)) file else if (exists(".dash_dir")) file.path(.dash_dir, file) else file
    code_hash <- md5_string(c(if (file.exists(path)) unname(tools::md5sum(path)) else "", environment_hash()))
  }
  METHODS[[id]] <<- list(id = id, label = label, class = class, fn = fn, speed = speed,
                         requires = requires, uses = uses, note = note,
                         file = file, code_hash = code_hash, knots = knots)
  invisible(id)
}

.W <- c("ps_bounds", "stabilize", "use_provided_weights", "extra_ps")   # settings every weighting step reads

add_method("iptw_km", "IPTW KM", "Singly Robust (IPW)", est_iptw_km,
           uses = .W, note = "IP-weighted Kaplan-Meier curves by arm.")
add_method("iptw_cox", "IPTW Cox", "Singly Robust (IPW)", est_iptw_cox,
           uses = .W, note = "IP-weighted marginal Cox model (treatment only); curves from its baseline hazard.")

add_method("cox_rs", "Cox Reg Stand", "Singly Robust (G-comp)", est_cox_rs,
           uses = "extra_out", note = "Cox outcome model standardised over the cohort under each arm.")
add_method("plr_rs", "Discrete Reg Stand logit", "Singly Robust (G-comp)", est_plr_rs,
           uses = c("interval", "time_df", "extra_out"),
           knots = function(d, s, tmax) time_breaks(d, s, tmax, "fixed", s$interval),        # its bin ends
           note = "Pooled logistic hazard model on person-period data, standardised.")

add_method("cox_dr_rs", "Cox DR Reg Stand", "Naive DR", est_cox_dr_rs,
           uses = c(.W, "extra_out"), note = "IP-weighted Cox outcome model, then standardisation.")

add_method("aiptw_cox", "AIPTW Cox", "Doubly Robust (AIPTW)", est_aiptw_cox,
           uses = c("ps_bounds", "extra_ps", "extra_out"),
           knots = function(d, s, tmax) sort(unique(d$time[is.finite(d$time) & d$time <= tmax])),   # it jumps at every observed time, censorings included
           note = "Cox outcome and censoring models; IPT/IPC-weighted correction of the outcome-model predictions. Supplies influence curves (analytic intervals).")

add_method("tmle_disc", "DR TMLE discrete", "Doubly Robust (TMLE)", est_tmle, speed = "slow",
           uses = c("tmle_grid", "tmle_width", "time_df", "ps_bounds", "extra_ps", "extra_out"),
           knots = function(d, s, tmax) time_breaks(d, s, tmax, s$tmle_grid, s$tmle_width),   # its bin ends
           note = "Discrete-time TMLE: pooled logistic hazards targeted at each grid time. Supplies influence curves. Cost grows with the number of intervals.")

# ---- registry helpers (what the pages read) ----------------------------------

method_available <- function(m)
  all(vapply(m$requires, function(p) requireNamespace(p, quietly = TRUE), logical(1)))

methods_table <- function() {
  if (!length(METHODS)) return(data.frame())
  data.frame(
    id        = vapply(METHODS, `[[`, character(1), "id"),
    label     = vapply(METHODS, `[[`, character(1), "label"),
    class     = vapply(METHODS, `[[`, character(1), "class"),
    speed     = vapply(METHODS, `[[`, character(1), "speed"),
    available = vapply(METHODS, method_available, logical(1)),
    requires  = vapply(METHODS, function(m) paste(m$requires, collapse = ", "), character(1)),
    uses      = vapply(METHODS, function(m) paste(m$uses, collapse = ", "), character(1)),
    note      = vapply(METHODS, `[[`, character(1), "note"),
    file      = vapply(METHODS, function(m) basename(m$file %||% ""), character(1)),
    source    = ifelse(grepl("^src:", names(METHODS)), "src/", "built in"),
    stringsAsFactors = FALSE, row.names = NULL
  )
}
method_classes   <- function() unique(methods_table()$class)
# label -> id, the shape a Shiny `choices` argument takes
method_labels    <- function() stats::setNames(methods_table()$id, methods_table()$label)
available_method_ids <- function() { t <- methods_table(); t$id[t$available] }
fast_method_ids  <- function() { t <- methods_table(); t$id[t$available & t$speed == "fast"] }

# ---- running ---------------------------------------------------------------------

# The contract, enforced: numeric columns, the curves evaluated at exactly the
# grid times, probabilities in [0, 1] (to rounding), 1 at time 0. Anything
# else is refused with what was found, never repaired.
validate_curves <- function(cv, grid, label) {
  if (!is.data.frame(cv) || !all(c("time", "s1", "s0") %in% names(cv)))
    stop(label, ": a method must return data.frame(time, s1, s0)", call. = FALSE)
  for (col in c("time", "s1", "s0"))
    if (!is.numeric(cv[[col]])) stop(label, ": column '", col, "' must be numeric", call. = FALSE)
  if (nrow(cv) != length(grid))
    stop(label, ": curves must be evaluated at the ", length(grid), " grid times; got ", nrow(cv), " rows", call. = FALSE)
  if (anyNA(cv$time) || any(abs(cv$time - grid) > 1e-8))
    stop(label, ": curves must be evaluated at exactly the grid times (the grid starts ",
         paste(signif(utils::head(grid, 3), 4), collapse = ", "), " ...)", call. = FALSE)
  for (col in c("s1", "s0")) {
    v <- cv[[col]]
    if (anyNA(v) || any(!is.finite(v)))
      stop(label, ": '", col, "' has missing or non-finite values", call. = FALSE)
    if (any(v < -1e-8 | v > 1 + 1e-8))
      stop(label, ": '", col, "' must be survival probabilities in [0, 1]; found ",
           signif(min(v), 4), " to ", signif(max(v), 4), call. = FALSE)
    if (abs(v[1] - 1) > 1e-6)
      stop(label, ": '", col, "' must be 1 at time 0; found ", signif(v[1], 4), call. = FALSE)
  }
  cv$s1 <- pmin(pmax(cv$s1, 0), 1)       # rounding noise only: anything beyond 1e-8 was refused above
  cv$s0 <- pmin(pmax(cv$s0, 0), 1)
  cv[, c("time", "s1", "s0")]
}

validate_ic <- function(ic, n, G, label) {
  if (!is.list(ic) || !all(c("s1", "s0") %in% names(ic)))
    stop(label, ": attr 'ic' must be list(s1, s0)", call. = FALSE)
  for (a in c("s1", "s0")) {
    m <- ic[[a]]
    if (!is.matrix(m) || nrow(m) != n || ncol(m) != G || anyNA(m) || any(!is.finite(m)))
      stop(label, ": influence curve '", a, "' must be an n x grid matrix of finite values", call. = FALSE)
  }
  ic
}

# A method's "incomplete" marker: absent, or one non-empty string with the
# reason. Anything else is the method's error, never a complete result.
.incomplete_marker <- function(raw, label) {
  inc <- attr(raw, "incomplete")
  if (is.null(inc)) return(NULL)
  if (!is.character(inc) || length(inc) != 1L || is.na(inc) || !nzchar(trimws(inc)))
    stop(label, ": attr 'incomplete' must be one non-empty string giving the reason", call. = FALSE)
  inc
}

# One method on one prepared cohort. Never throws: a failure is a result with
# ok = FALSE and the message, so one broken method does not stop the others.
# Intervals: bootstrap when boot_B > 0 (any method), else analytic from the
# influence curves when the method supplies them, else none.
run_method <- function(id, d, s, grid = NULL) {
  m <- METHODS[[id]]
  if (is.null(m)) stop("Unknown method: ", id, call. = FALSE)
  xvars <- attr(d, "xvars")
  t0 <- proc.time()[["elapsed"]]
  notes <- character()                                   # what the method said while running
  res <- tryCatch({
    if (!method_available(m)) stop("needs package(s): ", paste(m$requires, collapse = ", "), call. = FALSE)
    # the allowlist first: a term is only evaluated against the data once it is known to be a term
    pr <- settings_problems(s, xvars)
    if (!length(pr)) pr <- terms_problems(d, xvars, s)
    if (length(pr)) stop(paste(pr, collapse = "; "), call. = FALSE)
    # the grid: regular points, the report times, the event times, and the
    # times this method says its curves jump at - built in here so a bad grid
    # is this method's failure, never the session's
    tmax <- max(c(s$report_times, s$chr_time))
    knots_of <- function(dd) {                        # the method's knots for THIS data (a resample's differ)
      extra <- if (is.function(m$knots)) m$knots(dd, s, tmax) else NULL
      if (!is.null(extra) && (!is.numeric(extra) || anyNA(extra)))
        stop("the method's knots must be a numeric vector of times", call. = FALSE)
      extra
    }
    if (is.null(grid)) grid <- make_grid(s, d, knots_of(d))
    set.seed(s$seed)
    call_fn <- function(dd, g = grid) withCallingHandlers(m$fn(dd, xvars, s, g),
      warning = function(w) { notes <<- c(notes, conditionMessage(w)); invokeRestart("muffleWarning") })
    raw <- call_fn(d)
    notes <- c(attr(raw, "notes"), notes)
    incomplete <- .incomplete_marker(raw, m$label)      # NULL, or the method's reason: its estimate is not the full method
    ic  <- if (is.null(incomplete)) attr(raw, "ic") else NULL
    step <- isTRUE(attr(raw, "step"))                 # a step curve is integrated as one (R/estimands.R)
    cv  <- validate_curves(raw, grid, m$label)
    if (!is.null(ic)) ic <- validate_ic(ic, nrow(d), length(grid), m$label)
    # follow-up ends at each arm's last observed time; a curve past it is the
    # last value carried forward (or a model's extrapolation), so it is blanked -
    # unless the curve had reached zero, which is known from there on - and
    # every estimate derived from it is NA, with the reason in the notes
    fu  <- followup_ends(d)
    sup <- support_ends(cv, fu, risk_set_emptied(d))   # Inf for an arm everyone in died, whose curve is at zero there
    cv  <- clip_to_followup(cv, sup); attr(cv, "step") <- step
    est <- curve_estimands(cv, s)
    est$within_followup <- est$time <= min(sup) + 1e-9
    if (!all(est$within_followup)) notes <- c(notes, followup_note(fu, est, attr(d, "arm_labels")))
    if (!is.null(attr(grid, "note"))) notes <- c(notes, attr(grid, "note"))
    est$se <- NA_real_; est$lower <- NA_real_; est$upper <- NA_real_
    est$ci_type <- NA_character_; est$boot_ok <- NA_integer_
    B <- if (is.null(incomplete)) as.integer(s$boot_B %||% 0) else 0L   # no interval of any kind on an incomplete estimate
    bcurves <- NULL
    if (B > 0) {
      reps <- lapply(seq_len(B), function(b) {
        i  <- sample.int(nrow(d), replace = TRUE)
        db <- d[i, , drop = FALSE]
        tryCatch({
          # the resample's own grid: its event times and the knots the method
          # computes from it, so a jump that moves with the data moves here too
          grid_b <- make_grid(s, db, knots_of(db))
          raw_b <- call_fn(db, grid_b)
          # a replicate the method declares incomplete is a failed replicate, with its reason
          inc_b <- .incomplete_marker(raw_b, m$label)
          if (!is.null(inc_b)) stop("replicate incomplete: ", inc_b)
          cvb <- validate_curves(raw_b, grid_b, m$label)
          # this resample's own follow-up: a resample that did not draw the
          # longest-followed patients has no value at the later times
          cvb <- clip_to_followup(cvb, support_ends(cvb, followup_ends(db), risk_set_emptied(db))); attr(cvb, "step") <- step
          al <- align_curves(cvb, grid)                 # on the main grid, for the pointwise bands only
          list(est = curve_estimands(cvb, s)$est, s1 = al$s1, s0 = al$s0, err = NULL)
        }, error = function(e) list(est = rep(NA_real_, nrow(est)), s1 = rep(NA_real_, length(grid)),
                                     s0 = rep(NA_real_, length(grid)), err = conditionMessage(e)))
      })
      errs   <- unlist(lapply(reps, `[[`, "err"))
      n_ok   <- B - length(errs)
      min_ok <- max(2L, ceiling(0.8 * B))               # an interval needs most replicates
      bmat   <- do.call(cbind, lapply(reps, `[[`, "est"))             # estimands x replicates
      # usable replicates are counted estimand by estimand: a curve that fit
      # can still leave CHR or a risk ratio undefined (no control events)
      n_fin  <- rowSums(is.finite(bmat))
      est$boot_ok <- n_fin
      use <- n_fin >= min_ok & is.finite(est$est)
      if (any(use)) {
        bu <- bmat[use, , drop = FALSE]
        est$se[use]      <- apply(bu, 1, stats::sd, na.rm = TRUE)
        est$lower[use]   <- apply(bu, 1, stats::quantile, probs = 0.025, na.rm = TRUE, names = FALSE)
        est$upper[use]   <- apply(bu, 1, stats::quantile, probs = 0.975, na.rm = TRUE, names = FALSE)
        est$ci_type[use] <- "bootstrap"
      }
      bcurves <- list(s1 = do.call(rbind, lapply(reps, `[[`, "s1")),    # replicates x grid, NA where a
                      s0 = do.call(rbind, lapply(reps, `[[`, "s0")))    # replicate failed
      attr(bcurves, "min_ok") <- min_ok
      if (n_ok < min_ok) {
        notes <- c(notes, sprintf("bootstrap: only %d of %d replicates succeeded (%d needed), so no interval is reported (%s)",
                                  n_ok, B, min_ok, if (length(errs)) errs[1] else "no error message"))
      } else {
        if (length(errs)) notes <- c(notes, sprintf("bootstrap: %d of %d replicate(s) failed (%s)", length(errs), B, errs[1]))
        for (r in which(!use & is.finite(est$est)))
          notes <- c(notes, sprintf("bootstrap: no interval for %s at %s: %d of %d replicates gave a value (%d needed)",
                                    est$estimand[r], format(est$time[r]), n_fin[r], B, min_ok))
      }
    } else if (!is.null(ic)) {
      ci <- ic_intervals(ic, cv, est, grid)
      est$se <- ci$se; est$lower <- ci$lower; est$upper <- ci$upper
      est$ci_type <- ifelse(is.finite(ci$se), "influence curve", NA_character_)
    }
    ic_use <- if (B == 0) ic else NULL
    eff <- effect_curves(cv, ic = ic_use, bcurves = bcurves)
    ev  <- evalue_table(cv, s, ic = ic_use, bcurves = bcurves)
    list(ok = TRUE, incomplete = if (is.null(incomplete)) NA_character_ else as.character(incomplete)[1],
         curves = cv, estimates = est, effect = eff, evalue = ev, hrt = hr_over_time(cv),
         message = if (is.null(incomplete)) "ok" else paste("incomplete:", incomplete))
  }, error = function(e) list(ok = FALSE, incomplete = NA_character_, curves = NULL, estimates = NULL, hrt = NULL,
                               message = conditionMessage(e)))
  res$notes <- unique(notes)
  res$method_hash <- m$code_hash %||% ""
  res$id <- id; res$label <- m$label; res$class <- m$class
  res$seconds <- round(proc.time()[["elapsed"]] - t0, 2)
  res$n <- nrow(d); res$n_events <- sum(d$event); res$boot_B <- as.integer(s$boot_B %||% 0)
  # the analysis this result belongs to: these settings, this data under this mapping, this code
  res$settings_key <- settings_key(s)
  res$data_hash <- attr(d, "data_hash") %||% NA_character_
  res$cohort_id <- attr(d, "cohort_id") %||% NA_character_
  res$code_hash <- if (exists("CODE_HASH")) CODE_HASH else NA_character_
  res$from_cache <- FALSE
  res$stored <- NA                       # NA: no cache asked; TRUE/FALSE: the cache write's outcome
  res$computed_at <- format(Sys.time(), "%Y-%m-%d %H:%M:%S")
  res
}

# A result belongs to one analysis. Shown together are only results of the
# SAME analysis: same settings and same data under the same mapping.
result_matches <- function(r, s, data_hash)
  identical(r$settings_key, settings_key(s)) && identical(r$data_hash, data_hash)

# A complete result: the method ran and did not declare its estimate incomplete.
result_complete <- function(r) isTRUE(r$ok) && is.na(r$incomplete %||% NA_character_)

# One status word for a result, used by every page, export and job alike.
result_status <- function(r) if (!isTRUE(r$ok)) "failed" else if (result_complete(r)) "ok" else "incomplete"

# The name a result is shown under: an incomplete estimate says so wherever it appears.
result_label <- function(r) if (identical(result_status(r), "incomplete")) paste0(r$label, " (incomplete)") else r$label

current_results <- function(results, s, data_hash) {
  cur <- Filter(function(r) result_matches(r, s, data_hash), results)
  attr(cur, "n_stale") <- length(results) - length(cur)
  cur
}

# Which (cohort, method) pairs still need a run: every pair without an OK
# result of the current analysis. A failed run is not a result.
pending_combinations <- function(results_by_cohort, cohorts, methods, s, hash_of) {
  todo <- list()
  for (cid in cohorts) {
    h <- hash_of(cid)
    for (mid in methods) {
      r <- results_by_cohort[[cid]][[mid]]
      if (is.null(r) || !result_complete(r) || !result_matches(r, s, h)) todo[[length(todo) + 1]] <- c(cid, mid)
    }
  }
  todo
}

# The same, through the results cache (R/cache.R): a hit is returned as it was
# computed, marked from_cache; a miss is computed and stored, and `stored`
# says whether the write succeeded. The cohort id and data hash are what
# prep_cohort() attaches; without them, or without a cache directory, this is
# run_method().
run_method_cached <- function(id, d, s, cohort_id = attr(d, "cohort_id"),
                              data_hash = attr(d, "data_hash"), grid = NULL) {
  key <- if (nzchar(cache_dir()) && !is.null(cohort_id) && !is.null(data_hash))
    cache_key(cohort_id, data_hash, id, s, METHODS[[id]]$code_hash %||% "", grid = grid) else NULL
  if (!is.null(key)) {
    hit <- cache_get(key)
    if (!is.null(hit) && result_complete(hit) && identical(hit$data_hash, data_hash)) {
      hit$from_cache <- TRUE; hit$stored <- TRUE; return(hit)
    }
  }
  res <- run_method(id, d, s, grid)
  if (!is.null(key) && result_complete(res)) res$stored <- cache_put(key, res)   # an incomplete result is never cached
  res
}

# Several methods, in registry order, with an optional progress callback
# progress(i, n, label). Returns a list keyed by method id.
run_methods <- function(ids, d, s, progress = NULL, use_cache = TRUE) {
  ids  <- ids[ids %in% names(METHODS)]
  ids  <- names(METHODS)[names(METHODS) %in% ids]
  out  <- list()
  for (i in seq_along(ids)) {
    if (is.function(progress)) progress(i, length(ids), METHODS[[ids[i]]]$label)
    out[[ids[i]]] <- if (use_cache) run_method_cached(ids[i], d, s) else run_method(ids[i], d, s)
  }
  out
}

# Flat tables out of a results list (one cohort).
.bind <- function(rows) {
  rows <- Filter(function(x) !is.null(x) && nrow(x) > 0, rows)
  if (!length(rows)) return(data.frame())
  out <- do.call(rbind, rows); rownames(out) <- NULL; out
}
# The flattened estimates carry the method's stable id and script and the
# data and code hashes, so an export says exactly what produced each number.
.provenance <- function(r) data.frame(
  method_id = r$id, method_file = basename(METHODS[[r$id]]$file %||% ""), method_hash = r$method_hash %||% "",
  cohort_id = r$cohort_id %||% NA_character_, data_hash = r$data_hash %||% NA_character_,
  code_hash = r$code_hash %||% NA_character_, computed_at = r$computed_at %||% "",
  status = result_status(r),
  stringsAsFactors = FALSE)
results_estimates <- function(results, cohort = NA_character_)
  .bind(lapply(results, function(r) if (isTRUE(r$ok))
    cbind(cohort = cohort, method = result_label(r), class = r$class, n = r$n, n_events = r$n_events, r$estimates,
          .provenance(r), stringsAsFactors = FALSE)))
results_curves <- function(results, cohort = NA_character_)
  .bind(lapply(results, function(r) if (isTRUE(r$ok))
    cbind(cohort = cohort, method = result_label(r), r$curves, .provenance(r), stringsAsFactors = FALSE)))
results_hrt <- function(results, cohort = NA_character_)
  .bind(lapply(results, function(r) if (isTRUE(r$ok)) cbind(cohort = cohort, method = result_label(r), r$hrt, status = result_status(r), stringsAsFactors = FALSE)))
results_effect <- function(results, cohort = NA_character_)
  .bind(lapply(results, function(r) if (isTRUE(r$ok) && !is.null(r$effect))
    cbind(cohort = cohort, method = result_label(r), class = r$class, r$effect,
          ci_type = attr(r$effect, "ci_type") %||% NA_character_, status = result_status(r), stringsAsFactors = FALSE)))
results_evalue <- function(results, cohort = NA_character_)
  .bind(lapply(results, function(r) if (isTRUE(r$ok) && !is.null(r$evalue))
    cbind(cohort = cohort, method = result_label(r), class = r$class, r$evalue, status = result_status(r), stringsAsFactors = FALSE)))

# The comparison table: rows are cohorts (by id, never by label), columns are
# methods, cells the estimate with its interval; an estimate that is not a
# complete result says so in its cell.
compare_table <- function(e, estimand, time) {
  e <- e[e$estimand == estimand & abs(e$time - time) < 1e-9, , drop = FALSE]
  if (!nrow(e)) return(data.frame())
  within <- if ("within_followup" %in% names(e)) e$within_followup else rep(TRUE, nrow(e))
  e$cell <- ifelse(is.finite(e$lower), sprintf("%.3f [%.3f, %.3f]", e$est, e$lower, e$upper),
            ifelse(is.finite(e$est), sprintf("%.3f", e$est),
            ifelse(within, "not defined", "beyond follow-up")))
  flag <- e$status != "ok"
  e$cell[flag] <- paste0(e$cell[flag], " (", e$status[flag], ")")
  wide <- stats::reshape(e[, c("cohort_id", "method", "cell")], idvar = "cohort_id", timevar = "method", direction = "wide")
  names(wide) <- sub("^cell\\.", "", names(wide))
  info <- unique(e[, c("cohort_id", "cohort", "n", "n_events")])
  out <- merge(info, wide, by = "cohort_id", sort = FALSE)
  out <- out[match(unique(e$cohort_id), out$cohort_id), , drop = FALSE]
  names(out)[names(out) == "n_events"] <- "events"
  out$cohort_id <- NULL
  rownames(out) <- NULL
  out
}
results_status <- function(results, cohort = NA_character_) {
  if (!length(results)) return(data.frame())
  data.frame(
    cohort   = cohort,
    method   = vapply(results, `[[`, character(1), "label"),
    class    = vapply(results, `[[`, character(1), "class"),
    status   = vapply(results, result_status, character(1)),
    cached   = vapply(results, function(r) isTRUE(r$from_cache), logical(1)),
    stored   = vapply(results, function(r) as.logical(r$stored %||% NA), logical(1)),
    seconds  = vapply(results, `[[`, numeric(1), "seconds"),
    n        = vapply(results, `[[`, numeric(1), "n"),
    n_events = vapply(results, function(r) as.numeric(r$n_events %||% NA), numeric(1)),
    boot_B   = vapply(results, `[[`, numeric(1), "boot_B"),
    computed_at = vapply(results, function(r) r$computed_at %||% "", character(1)),
    message  = vapply(results, `[[`, character(1), "message"),
    notes    = vapply(results, function(r) paste(r$notes %||% character(), collapse = " | "), character(1)),
    stringsAsFactors = FALSE, row.names = NULL
  )
}
