# THE STUDY'S OWN FUNCTIONS AS METHODS, WITHOUT AN ADAPTER PER SCRIPT.
#
# The study's estimators are functions named run_<something>_analysis(), one
# per script in <src>/analysis. At startup every such function is found by
# name and wrapped into the dashboard's method contract automatically:
#
#   1. its ARGUMENTS are filled from their names (the cohort, the covariate
#      names, the evaluation times, the names of the time / event / treatment
#      columns, model formulas);
#   2. it is called on the prepared cohort;
#   3. the two marginal SURVIVAL CURVES are read out of whatever it returns: a
#      table with a time column and one column per arm, a long table with an
#      arm column, or a pair of vectors - searched for by name and checked to
#      be probabilities;
#   4. they are put on the dashboard's grid, and from there the method gets
#      what every method gets: the estimands, the follow-up rule, intervals
#      (bootstrap), the cache.
#
# This is inference from names, so every such method says "auto-adapted" on
# the page and in its notes says how it was called and where its curves were
# found. A function whose result holds no recognisable pair of curves, or
# whose arms cannot be told apart, FAILS with that reason; it never guesses
# between two readings. An adapter in methods/ named after the function (or
# its script) takes its place: that is how a wrong guess is corrected.

STUDY_PATTERN <- "^run_.*_analysis$"

# ---- finding the functions (parsing only: nothing is run) ---------------------

script_functions <- function(f) {
  ex <- tryCatch(parse(f, keep.source = FALSE), error = function(e) NULL)
  if (is.null(ex)) return(NULL)
  out <- character()
  for (e in ex)
    if (is.call(e) && length(e) == 3L && is.symbol(e[[1]]) && as.character(e[[1]]) %in% c("<-", "=") &&
        is.symbol(e[[2]]) && is.call(e[[3]]) && is.symbol(e[[3]][[1]]) && identical(as.character(e[[3]][[1]]), "function"))
      out <- c(out, as.character(e[[2]]))
  out
}

# every name and every text constant a script mentions: which column names it expects
script_tokens <- function(f) {
  ex <- tryCatch(parse(f, keep.source = FALSE), error = function(e) NULL)
  if (is.null(ex)) return(character())
  out <- character()
  walk <- function(e) {
    if (is.character(e)) { out <<- c(out, e); return(invisible()) }
    if (is.symbol(e)) { out <<- c(out, as.character(e)); return(invisible()) }
    if (is.call(e) || is.pairlist(e) || is.expression(e)) for (i in seq_along(e)) {
      if (identical(e[[i]], quote(expr = ))) next
      walk(e[[i]])
    }
  }
  walk(ex)
  unique(out)
}

# ---- names -> label, class, speed ---------------------------------------------

study_label <- function(fname) {
  tok <- strsplit(sub("_analysis$", "", sub("^run_", "", fname)), "_", fixed = TRUE)[[1]]
  up <- c(iptw = "IPTW", aiptw = "AIPTW", ipw = "IPW", aipw = "AIPW", fpm = "FPM", dr = "DR", tmle = "TMLE", ltmle = "LTMLE",
          survtmle = "survTMLE", plr = "PLR", km = "KM", ph = "PH", nph = "NPH", glm = "GLM", rmst = "RMST")
  nice <- c(regstand = "Reg Stand", cloglog = "cloglog", logit = "logit", concrete = "concrete", survival = "survival")
  out <- vapply(tok, function(t) if (t %in% names(up)) up[[t]] else if (t %in% names(nice)) nice[[t]]
                else paste0(toupper(substr(t, 1, 1)), substr(t, 2, nchar(t))), character(1))
  paste(out, collapse = " ")
}

study_class <- function(fname) {
  n <- tolower(fname)
  if (grepl("tmle|concrete", n)) "Doubly Robust (TMLE)"
  else if (grepl("aiptw|aipw", n)) "Doubly Robust (AIPTW)"
  else if (grepl("naive", n) || (grepl("(^|_)dr(_|$)", n) && grepl("stand", n))) "Naive DR"
  else if (grepl("(^|_)dr(_|$)|plr|blanche|doubly", n)) "Doubly Robust (DR Stand)"
  else if (grepl("iptw|ipw", n)) "Singly Robust (IPW)"
  else if (grepl("stand|gcomp|g_comp", n)) "Singly Robust (G-comp)"
  else "From src/analysis"
}

study_speed <- function(fname) if (grepl("tmle|concrete|boot", tolower(fname))) "slow" else "fast"

# ---- arguments, from their names ----------------------------------------------

guess_args <- function(fn, dd, xvars, times) {
  fm <- formals(fn); nm <- names(fm); given <- list(); notes <- character()
  for (i in seq_along(fm)) {
    n <- nm[i]; if (identical(n, "...")) next
    l <- tolower(n); val <- NULL; what <- ""
    if (grepl("^(data|df|dat|dataset|d|cohort|input|data_cox|analysis_data)$", l) || (i == 1L && identical(fm[[i]], quote(expr = )))) { val <- dd; what <- "the cohort" }
    else if (grepl("formula", l)) {
      if (grepl("ps|prop|treat|trt|weight|exposure", l)) { val <- stats::reformulate(xvars, "A"); what <- "A ~ covariates" }
      else if (grepl("cens", l)) { val <- stats::as.formula(paste("survival::Surv(time, 1 - event) ~ A +", paste(xvars, collapse = " + "))); what <- "Surv(time, 1 - event) ~ A + covariates" }
      else { val <- stats::as.formula(paste("survival::Surv(time, event) ~ A +", paste(xvars, collapse = " + "))); what <- "Surv(time, event) ~ A + covariates" }
    }
    else if (grepl("covar|confound|adjust|predictor|^x(vars)?$|^l$|^w$|^baseline", l)) { val <- xvars; what <- "the covariate names" }
    else if (grepl("time", l) && grepl("var|col|name", l)) { val <- "time"; what <- "\"time\"" }
    else if (grepl("event|status|delta", l) && grepl("var|col|name", l)) { val <- "event"; what <- "\"event\"" }
    else if (grepl("trt|treat|arm|expos", l) && grepl("var|col|name", l)) { val <- "A"; what <- "\"A\"" }
    else if (grepl("^times$|^time$|eval|tau|horizon|grid|time_?points|t_eval|^t$", l) && !grepl("var|col|name", l)) {
      val <- times; what <- sprintf("%d evaluation times up to %s", length(times), format(max(times)))
    }
    if (!is.null(val)) { given[[n]] <- val; notes <- c(notes, paste0(n, " = ", what)) }
  }
  list(args = given, notes = notes)
}

# The cohort as a study function sees it: time, event, A and the covariates,
# plus the other names its script uses for the same three columns. Only names
# the script actually mentions are added, so a function that takes "every
# other column" as a covariate is not handed copies of the treatment.
STUDY_ALIASES <- list(
  time  = c("duration", "futime", "Time", "obs_time", "time_to_event", "tte", "survtime"),
  event = c("status", "delta", "Event", "event_ind", "death", "died"),
  A     = c("trt", "treatment", "treat", "arm", "exposure", "Trt", "TRT", "Treatment"))

study_data <- function(d, xvars, tokens = character()) {
  dd <- d[, c("time", "event", "A", xvars), drop = FALSE]
  for (base in names(STUDY_ALIASES)) for (al in STUDY_ALIASES[[base]])
    if (al %in% tokens && !(al %in% names(dd))) dd[[al]] <- dd[[base]]
  if ("id" %in% tokens && !("id" %in% names(dd)) && !is.null(d$id)) dd$id <- d$id
  dd
}

# ---- the two survival curves, read out of a result ------------------------------

.is_prob <- function(v) is.numeric(v) && length(v) >= 2L && all(is.finite(v)) && all(v >= -1e-6 & v <= 1 + 1e-6)

# which arm a column or element name speaks of: "treated", "control", or NA
.arm_of <- function(n) {
  n <- tolower(n)
  if (grepl("lower|upper|lcl|ucl|lci|uci|(^|[._])se($|[._])|stderr|[._]sd$|[._]var$|[._]ci$|diff|ratio", n)) return(NA_character_)
  if (grepl("(control|ctrl|untreated|unexposed|comparator|reference|placebo|a0|[._]0|[a-z]0)$|^0$", n)) return("control")
  if (grepl("(treated|treat|trt|exposed|active|experimental|intervention|a1|[._]1|[a-z]1)$|^1$", n)) return("treated")
  NA_character_
}

.TIME_RX <- "^(time|times|t|tau|eval_?times?|time_?points?|timepoint|day|days|month|months|horizon|landmark)$"

.time_column <- function(x, times) {
  hit <- names(x)[grepl(.TIME_RX, tolower(names(x)))]
  hit <- hit[vapply(hit, function(n) is.numeric(x[[n]]), logical(1))]
  if (length(hit)) return(x[[hit[1]]])
  if (nrow(x) == length(times)) return(times)             # one row per time it was asked for
  NULL
}

# a survival curve falls; a cumulative risk rises from 0: the latter is turned round
.as_survival <- function(v1, v0) {
  rising <- function(v) v[1] < 0.5 && sum(diff(v) > 1e-8) > sum(diff(v) < -1e-8)
  if (rising(v1) && rising(v0)) list(s1 = 1 - v1, s0 = 1 - v0, risk = TRUE) else list(s1 = v1, s0 = v0, risk = FALSE)
}

# wide: a time column and one probability column per arm
.curves_wide <- function(x, times) {
  cand <- names(x)[vapply(names(x), function(n) .is_prob(x[[n]]) && !grepl(.TIME_RX, tolower(n)), logical(1))]
  arm <- vapply(cand, .arm_of, character(1))
  # with several columns per arm, the ones that say "surv" are the curves
  pick <- function(a) { h <- cand[!is.na(arm) & arm == a]; s <- h[grepl("surv|^s[._]?[01a]", tolower(h))]; if (length(s)) s else h }
  t1 <- pick("treated"); t0 <- pick("control")
  if (length(t1) != 1L || length(t0) != 1L) return(NULL)
  tt <- .time_column(x, times); if (is.null(tt)) return(NULL)
  cv <- .as_survival(x[[t1]], x[[t0]])
  list(time = tt, s1 = cv$s1, s0 = cv$s0, how = sprintf("columns %s and %s%s", t1, t0, if (cv$risk) " (cumulative risks, turned into survival)" else ""))
}

.map_arms <- function(vals, arm_labels = NULL) {
  u <- sort(unique(vals[!is.na(vals)])); if (length(u) != 2L) return(NULL)
  if (is.logical(u) || (is.numeric(u) && all(u %in% c(0, 1)))) return(list(treated = u[2], control = u[1]))
  if (is.numeric(u)) return(NULL)                                    # 1 and 2, say: which is which is not ours to guess
  uc <- tolower(as.character(u))
  c1 <- grepl("control|ctrl|untreated|unexposed|comparator|reference|placebo|=0$|0$", uc)
  t1 <- grepl("treated|treat$|trt|exposed|active|experimental|intervention|=1$|1$", uc) & !c1
  if (sum(t1) == 1L && sum(c1) == 1L) return(list(treated = u[t1], control = u[c1]))
  if (!is.null(arm_labels)) {
    m1 <- uc == tolower(arm_labels[["treated"]]); m0 <- uc == tolower(arm_labels[["control"]])
    if (sum(m1) == 1L && sum(m0) == 1L) return(list(treated = u[m1], control = u[m0]))
  }
  NULL
}

# long: a time column, an arm column with two values, one probability column
.curves_long <- function(x, times, arm_labels = NULL) {
  ln <- tolower(names(x))
  arm_col <- names(x)[ln %in% c("a", "arm", "trt", "treatment", "treat", "group", "strata", "stratum", "exposure", "tx", "z")]
  arm_col <- arm_col[vapply(arm_col, function(n) length(unique(x[[n]][!is.na(x[[n]])])) == 2L, logical(1))]
  if (!length(arm_col)) return(NULL)
  arm_col <- arm_col[1]
  val <- names(x)[vapply(names(x), function(n) n != arm_col && .is_prob(x[[n]]) && !grepl(.TIME_RX, tolower(n)), logical(1))]
  val <- val[is.na(vapply(val, .arm_of, character(1))) | grepl("surv|prob|est", tolower(val))]
  if (length(val) > 1L) { s <- val[grepl("surv", tolower(val))]; if (length(s)) val <- s }
  if (length(val) != 1L) return(NULL)
  tcol <- names(x)[grepl(.TIME_RX, ln)]; tcol <- tcol[vapply(tcol, function(n) is.numeric(x[[n]]), logical(1))]
  if (!length(tcol)) return(NULL)
  arms <- .map_arms(x[[arm_col]], arm_labels)
  if (is.null(arms)) return(structure(list(), ambiguous = sprintf("the arms in column '%s' (%s) cannot be told apart", arm_col,
                                                                  paste(utils::head(unique(as.character(x[[arm_col]])), 2), collapse = ", "))))
  a1 <- x[x[[arm_col]] == arms$treated, , drop = FALSE]; a0 <- x[x[[arm_col]] == arms$control, , drop = FALSE]
  a1 <- a1[order(a1[[tcol[1]]]), , drop = FALSE]; a0 <- a0[order(a0[[tcol[1]]]), , drop = FALSE]
  if (nrow(a1) != nrow(a0) || nrow(a1) < 2L || any(abs(a1[[tcol[1]]] - a0[[tcol[1]]]) > 1e-8)) return(NULL)
  cv <- .as_survival(a1[[val]], a0[[val]])
  list(time = a1[[tcol[1]]], s1 = cv$s1, s0 = cv$s0,
       how = sprintf("column %s by %s (%s = treated)%s", val, arm_col, as.character(arms$treated), if (cv$risk) ", cumulative risks turned into survival" else ""))
}

# a list holding one probability vector per arm
.curves_pair <- function(x, times) {
  if (is.data.frame(x) || is.null(names(x))) return(NULL)
  ok <- names(x)[vapply(seq_along(x), function(i) nzchar(names(x)[i]) && !is.list(x[[i]]) && .is_prob(x[[i]]), logical(1))]
  arm <- vapply(ok, .arm_of, character(1))
  pick <- function(a) { h <- ok[!is.na(arm) & arm == a]; s <- h[grepl("surv|^s[._]?[01a]", tolower(h))]; if (length(s)) s else h }
  t1 <- pick("treated"); t0 <- pick("control")
  if (length(t1) != 1L || length(t0) != 1L || length(x[[t1]]) != length(x[[t0]])) return(NULL)
  L <- length(x[[t1]])
  tn <- names(x)[grepl(.TIME_RX, tolower(names(x)))]
  tn <- tn[vapply(tn, function(n) is.numeric(x[[n]]) && length(x[[n]]) == L, logical(1))]
  tt <- if (length(tn)) x[[tn[1]]] else if (L == length(times)) times else NULL
  if (is.null(tt)) return(NULL)
  cv <- .as_survival(as.numeric(x[[t1]]), as.numeric(x[[t0]]))
  list(time = tt, s1 = cv$s1, s0 = cv$s0, how = sprintf("elements %s and %s%s", t1, t0, if (cv$risk) " (cumulative risks, turned into survival)" else ""))
}

# Searches a result (three levels deep) for the pair of curves. Returns
# list(time, s1, s0, where, how), or NULL with attr "why": what was looked at.
find_curves <- function(res, times, arm_labels = NULL) {
  seen <- character(); ambiguous <- NULL
  visit <- function(x, path, depth) {
    if (is.matrix(x) && !is.null(colnames(x))) x <- as.data.frame(x, stringsAsFactors = FALSE)
    if (is.data.frame(x)) {
      hit <- .curves_wide(x, times)
      if (is.null(hit)) {
        hit <- .curves_long(x, times, arm_labels)
        if (!is.null(hit) && !is.null(attr(hit, "ambiguous"))) { ambiguous <<- paste0(path, ": ", attr(hit, "ambiguous")); hit <- NULL }
      }
      if (!is.null(hit)) { hit$where <- path; return(hit) }
      seen <<- c(seen, sprintf("%s [%s]", path, paste(utils::head(names(x), 8), collapse = ", ")))
      return(NULL)
    }
    if (is.list(x)) {
      hit <- .curves_pair(x, times)
      if (!is.null(hit)) { hit$where <- path; return(hit) }
      if (!is.null(names(x))) seen <<- c(seen, sprintf("%s {%s}", path, paste(utils::head(names(x), 8), collapse = ", ")))
      if (depth < 3L) for (i in seq_along(x)) {
        nm <- if (is.null(names(x)) || !nzchar(names(x)[i])) sprintf("[[%d]]", i) else paste0("$", names(x)[i])
        hit <- visit(x[[i]], paste0(path, nm), depth + 1L)
        if (!is.null(hit)) return(hit)
      }
    }
    NULL
  }
  hit <- visit(res, "result", 0L)
  if (!is.null(hit)) return(hit)
  structure(list(), why = if (!is.null(ambiguous)) ambiguous
                          else paste0("no pair of survival curves found in what it returned; looked at ",
                                      if (length(seen)) paste(utils::head(seen, 6), collapse = "; ") else paste0("a ", paste(class(res), collapse = "/"))))
}

# The curves a function returned, on the dashboard's grid. They must reach the
# end of the grid; between the times they were given at they are read as a
# step function when there are many (the function's own event-time curve) and
# linearly when there are few (a curve sampled at evaluation times).
curves_on_grid <- function(hit, grid) {
  o <- order(hit$time); tt <- hit$time[o]; s1 <- hit$s1[o]; s0 <- hit$s0[o]
  keep <- !duplicated(tt); tt <- tt[keep]; s1 <- s1[keep]; s0 <- s0[keep]
  if (tt[1] > 1e-9) { tt <- c(0, tt); s1 <- c(1, s1); s0 <- c(1, s0) }
  if (max(tt) < max(grid) - 1e-6)
    stop(sprintf("the curves it returned stop at %s, before the last time asked for (%s)", format(signif(max(tt), 4)), format(max(grid))), call. = FALSE)
  method <- if (length(tt) >= 200L) "constant" else "linear"
  on <- function(v) pmin(pmax(stats::approx(tt, v, xout = grid, method = method, f = 0, rule = 2)$y, 0), 1)
  out <- data.frame(time = grid, s1 = on(s1), s0 = on(s0))
  if (abs(grid[1]) < 1e-9) { out$s1[1] <- 1; out$s0[1] <- 1 }
  attr(out, "n_times") <- length(tt)
  out
}

# ---- the wrapper, and registration ----------------------------------------------

# The evaluation times a function is asked for: the regular grid for a fast
# method; for a slow one (TMLE: its cost grows with the number of times) only
# the times the estimands are reported at.
study_times <- function(s, slow) {
  t <- if (slow) c(s$report_times, s$chr_time) else as.numeric(make_grid(s))
  sort(unique(t[is.finite(t) & t > 0]))
}

# Calls a study function on the cohort. When it stops for want of a column the
# study code knows the time, the event or the treatment by (a helper in another
# file asking for `status`, say), that name is supplied and the call repeated.
call_study <- function(fn, dd, xvars, times, repo_root) {
  old <- if (dir.exists(repo_root)) setwd(repo_root) else NULL            # study code is written to run from the repository root
  on.exit(if (!is.null(old)) setwd(old), add = TRUE)
  g <- guess_args(fn, dd, xvars, times)
  res <- tryCatch(do.call(fn, g$args), error = function(e) e)
  for (i in seq_len(6L)) {
    if (!inherits(res, "error")) break
    m <- regmatches(conditionMessage(res), regexec("object '([^']+)' not found", conditionMessage(res)))[[1]]
    al <- if (length(m) == 2L) m[2] else ""
    base <- names(STUDY_ALIASES)[vapply(STUDY_ALIASES, function(a) al %in% a, logical(1))]
    if (!length(base) || al %in% names(dd)) break
    dd[[al]] <- dd[[base[1]]]
    g <- guess_args(fn, dd, xvars, times)
    res <- tryCatch(do.call(fn, g$args), error = function(e) e)
  }
  if (inherits(res, "error")) stop(conditionMessage(res), call. = FALSE)
  list(result = res, notes = g$notes)
}

make_study_adapter <- function(fn, fname, tokens, slow, repo_root) {
  force(fn); force(fname); force(tokens); force(slow); force(repo_root)
  function(d, xvars, s, grid) {
    times <- study_times(s, slow)
    g <- call_study(fn, study_data(d, xvars, tokens), xvars, times, repo_root)
    res <- g$result
    hit <- find_curves(res, times, attr(d, "arm_labels"))
    if (is.null(hit$time)) stop(fname, "(): ", attr(hit, "why"), call. = FALSE)
    out <- curves_on_grid(hit, grid)
    n_t <- attr(out, "n_times")
    attr(out, "notes") <- c(
      sprintf("auto-adapted: %s(%s); curves read from %s, %s", fname, paste(g$notes, collapse = "; "), hit$where, hit$how),
      if (n_t < 200L) sprintf("the function gave its curves at %d times; between them they are read linearly, so RMST is approximate", n_t))
    out
  }
}

# Whether a script only DEFINES things (functions, constants) and loads
# packages: such a file is a library and safe to load; one with any other
# top-level call is a runner and is never executed here.
is_definition_file <- function(f) {
  ex <- tryCatch(parse(f, keep.source = FALSE), error = function(e) NULL)
  if (is.null(ex)) return(FALSE)
  ok_call <- c("library", "require", "requireNamespace", "suppressPackageStartupMessages", "suppressMessages", "suppressWarnings", "options")
  simple <- function(v) !is.call(v) || (is.symbol(v[[1]]) && as.character(v[[1]]) %in% c("function", "c", "list", "character", "numeric", "integer", "logical", "-", "+", "*", "/", ":", "paste", "paste0", "seq", "seq_len", "rep"))
  all(vapply(ex, function(e) {
    if (!is.call(e)) return(TRUE)
    head <- if (is.symbol(e[[1]])) as.character(e[[1]]) else ""
    if (head %in% c("<-", "=") && length(e) == 3L) return(simple(e[[3]]))
    head %in% ok_call
  }, logical(1)))
}

# Registers every run_*_analysis() function under `dir` as a method, except
# those an adapter in methods/ already stands for (`taken`: method ids and
# script names). The study's files are loaded into ONE environment, so its
# functions find each other's helpers: the scripts that hold a run_*_analysis
# function, and every other script under `lib_dir` that only defines things.
# Returns one row per function for the About page.
# The study's code, loaded: one environment holding the scripts under `dir`
# that define a run_*_analysis function (`files`, with the error of any that
# would not load) and every definition-only script under `lib_dir`.
load_study_env <- function(dir, pattern = STUDY_PATTERN, repo_root = dirname(dir), lib_dir = dir) {
  files <- sort(list.files(dir, pattern = "\\.[Rr]$", full.names = TRUE, recursive = TRUE))
  has_fn <- vapply(files, function(f) length(grep(pattern, script_functions(f) %||% character())) > 0L, logical(1))
  libs <- if (!is.null(lib_dir) && nzchar(lib_dir) && dir.exists(lib_dir)) sort(list.files(lib_dir, pattern = "\\.[Rr]$", full.names = TRUE, recursive = TRUE)) else character()
  libs <- setdiff(unique(c(files[!has_fn], libs)), files[has_fn])
  libs <- libs[vapply(libs, is_definition_file, logical(1))]
  env <- new.env(parent = globalenv())
  load <- function(f) {
    old <- if (dir.exists(repo_root)) setwd(repo_root) else NULL
    tryCatch({ setTimeLimit(elapsed = 60, transient = TRUE); sys.source(f, envir = env); NULL },
             error = function(e) conditionMessage(e), finally = { setTimeLimit(); if (!is.null(old)) setwd(old) })
  }
  for (f in libs) load(f)                       # helpers first; one that fails to load is found out when it is called
  errors <- list()
  for (f in files[has_fn]) errors[f] <- list(load(f))
  list(env = env, files = files[has_fn], errors = errors)
}

register_study_methods <- function(dir, pattern = STUDY_PATTERN, taken = character(), repo_root = dirname(dir), code_hash = "", lib_dir = dir) {
  empty <- data.frame(folder = character(), file = character(), status = character(), id = character(), stringsAsFactors = FALSE)
  if (is.null(dir) || !nzchar(dir) || !dir.exists(dir)) return(empty)
  st <- load_study_env(dir, pattern, repo_root, lib_dir); env <- st$env
  rows <- list()
  row <- function(f, status, id = NA_character_)
    rows[[length(rows) + 1L]] <<- data.frame(folder = basename(dirname(f)), file = basename(f), status = status, id = id, stringsAsFactors = FALSE)
  for (f in st$files) {
    todo <- grep(pattern, script_functions(f), value = TRUE)
    stem <- sub("\\.[Rr]$", "", basename(f))
    err <- st$errors[[f]]
    if (!is.null(err)) { row(f, paste("error: the script could not be loaded:", err)); next }
    tokens <- script_tokens(f)
    for (fname in todo) {
      id <- paste0("src:", fname)
      if (id %in% taken || fname %in% taken || stem %in% taken || id %in% names(METHODS)) { row(f, "an adapter in methods/ stands for it"); next }
      fn <- get0(fname, envir = env, inherits = FALSE)
      if (!is.function(fn)) { row(f, paste0("error: ", fname, " is not a function")); next }
      slow <- identical(study_speed(fname), "slow")
      ok <- tryCatch({
        add_method(id, study_label(fname), study_class(fname), make_study_adapter(fn, fname, tokens, slow, repo_root),
                   speed = if (slow) "slow" else "fast", file = f,
                   note = "Auto-adapted from the function's arguments and result: compare with the study's own output before relying on it.",
                   code_hash = md5_string(c(code_hash, unname(tools::md5sum(f)), environment_hash())))
        TRUE
      }, error = function(e) { row(f, paste("error:", conditionMessage(e))); FALSE })
      if (ok) row(f, "registered (auto-adapted)", id)
    }
  }
  if (length(rows)) do.call(rbind, rows) else empty
}
