# METHODS FROM src/. The study's estimators come and go as scripts in the
# repository's src/ folder (DASH_SRC_DIR, default ../src beside this folder).
# At startup every R script there that defines
#
#     estimate_curves <- function(d, xvars, s, grid)   # -> data.frame(time, s1, s0)
#
# becomes a method: adding a script adds a method, removing it removes the
# method, and nothing in the dashboard is edited. The method is shown with
# the script's file name beside its name, so anyone can see where a number
# comes from. docs/src_method_template.R is a script to copy.
#
# A script may also set, at its top level:
#   METHOD_LABEL     the name on the page (default: the file name without .R)
#   METHOD_CLASS     the robustness class it is grouped under (default "From src/")
#   METHOD_SPEED     "fast" or "slow"
#   METHOD_REQUIRES  packages it needs (listed as "Not available" when missing)
#   METHOD_USES      the settings it reads
#   METHOD_NOTE      one line on what it does
#   METHOD_KNOTS     function(d, s, tmax): the times the curves jump at when those
#                    are not event times (bin ends, every observed time); they go
#                    on the grid so the RMST integral loses no jump
#
# Only scripts whose text defines estimate_curves are sourced, so an
# unrelated script in src/ (a simulation runner, say) is never executed; it
# is listed on the About page as "not a dashboard method". A script that
# fails to source is listed with its error. Each script is sourced into its
# own environment, so two scripts may use the same helper names; the
# dashboard's own helpers (fit_ps, km_curves, ...) are visible to them.
# Sourcing is limited to 30 seconds per script.

src_scripts <- function(src_dir) {
  if (is.null(src_dir) || !nzchar(src_dir) || !dir.exists(src_dir)) return(character())
  f <- sort(list.files(src_dir, pattern = "\\.[Rr]$", full.names = TRUE))
  f[!grepl("^_", basename(f))]
}

# Whether a script DEFINES estimate_curves as a function, decided by parsing
# it (which runs nothing), never by matching its text: a mention in a comment
# is not a definition. NA when the script cannot be parsed.
defines_estimate_curves <- function(f) {
  ex <- tryCatch(parse(f, keep.source = FALSE), error = function(e) NULL)
  if (is.null(ex)) return(NA)
  is_sym <- function(x, what) is.symbol(x) && identical(as.character(x), what)
  any(vapply(ex, function(e) {
    is.call(e) && length(e) == 3L && is.symbol(e[[1]]) && as.character(e[[1]]) %in% c("<-", "=") &&
      is_sym(e[[2]], "estimate_curves") &&
      is.call(e[[3]]) && is_sym(e[[3]][[1]], "function")
  }, logical(1)))
}

# One checksum for everything under src/ (every file, any depth) plus the R
# and survival versions: the code hash of every src/ method. Coarse on
# purpose - a helper edited anywhere in src/ re-runs every src/ method rather
# than ever serving a number the old helper produced.
src_code_hash <- function(src_dir) {
  files <- if (nzchar(src_dir %||% "") && dir.exists(src_dir)) sort(list.files(src_dir, recursive = TRUE, full.names = TRUE)) else character()
  md5_string(c(unname(tools::md5sum(files)), environment_hash()))
}

# One script at a time, and whatever goes wrong with one script is that
# script's status: nothing in here can stop the dashboard from starting.
scan_src_methods <- function(src_dir) {
  files <- src_scripts(src_dir)
  lapply(files, function(f) {
    stem <- sub("\\.[Rr]$", "", basename(f))
    tryCatch({
      defines <- defines_estimate_curves(f)
      if (is.na(defines))
        return(list(file = f, stem = stem, env = NULL, fn = NULL, status = "error: the script cannot be parsed"))
      if (!defines)
        return(list(file = f, stem = stem, env = NULL, fn = NULL,
                    status = "not a dashboard method (no estimate_curves function)"))
      env <- new.env(parent = globalenv())
      err <- tryCatch({
        setTimeLimit(elapsed = 30, transient = TRUE); on.exit(setTimeLimit(), add = TRUE)
        sys.source(f, envir = env); NULL
      }, error = function(e) conditionMessage(e))
      fn <- if (is.null(err)) get0("estimate_curves", envir = env, inherits = FALSE) else NULL
      status <- if (!is.null(err)) paste("error:", err)
                else if (!is.function(fn)) "error: estimate_curves is not a function"
                else "registered"
      list(file = f, stem = stem, env = env, fn = fn, status = status)
    }, error = function(e) list(file = f, stem = stem, env = NULL, fn = NULL,
                                 status = paste("error:", conditionMessage(e))))
  })
}

# Registers every method script found, after dropping whatever src/ methods
# were registered before, so a rescan reflects the folder as it is now.
# Returns one row per script: file, status, id.
# The versions of the packages a method declares, for its code hash: a method
# that needs riskRegression is a different method under another riskRegression.
package_versions <- function(pkgs) {
  pkgs <- as.character(pkgs)
  if (!length(pkgs)) return(character())
  paste(pkgs, vapply(pkgs, function(p) if (requireNamespace(p, quietly = TRUE)) as.character(utils::packageVersion(p)) else "missing", character(1)), sep = "=")
}

register_src_methods <- function(src_dir) {
  for (id in grep("^src:", names(METHODS), value = TRUE)) METHODS[[id]] <<- NULL
  scan <- scan_src_methods(src_dir)
  hash <- src_code_hash(src_dir)
  rows <- lapply(scan, function(r) {
    id <- NA_character_
    if (identical(r$status, "registered")) {
      id <- paste0("src:", r$stem)
      # every metadata field is read and checked INSIDE the boundary: a bad
      # value is this script's error, never the dashboard's
      ok <- tryCatch({
        g <- function(k, default, n = NA, blank_ok = FALSE) {
          v <- get0(k, envir = r$env, inherits = FALSE)
          if (is.null(v)) return(default)
          if (!is.character(v) && !is.numeric(v) && !is.logical(v))
            stop(k, " must be a character vector, not ", class(v)[1], call. = FALSE)
          v <- as.character(v)
          if (is.na(n)) return(v[!is.na(v) & nzchar(trimws(v))])        # a list: blank entries dropped
          if (length(v) != n) stop(k, " must be a single value", call. = FALSE)
          if (anyNA(v) || !all(nzchar(trimws(v)))) {
            if (blank_ok) return(default)
            stop(k, " must be one non-empty value, not NA or blank", call. = FALSE)
          }
          v
        }
        requires <- g("METHOD_REQUIRES", character())
        speed <- g("METHOD_SPEED", "fast", 1)
        kn <- get0("METHOD_KNOTS", envir = r$env, inherits = FALSE)
        if (!is.null(kn) && !is.function(kn)) stop("METHOD_KNOTS must be a function(d, s, tmax)", call. = FALSE)
        if (!speed %in% c("fast", "slow")) stop("METHOD_SPEED must be 'fast' or 'slow'", call. = FALSE)
        add_method(id, g("METHOD_LABEL", r$stem, 1), g("METHOD_CLASS", "From src/", 1), r$fn,
                   speed = speed, requires = requires,
                   uses = g("METHOD_USES", character()), note = g("METHOD_NOTE", "", 1, blank_ok = TRUE),
                   file = r$file, code_hash = md5_string(c(hash, package_versions(requires))), knots = kn)
        TRUE
      }, error = function(e) { r$status <<- paste("error:", conditionMessage(e)); FALSE })
      if (!ok) id <- NA_character_
    }
    data.frame(file = basename(r$file), status = r$status, id = id, stringsAsFactors = FALSE)
  })
  out <- if (length(rows)) do.call(rbind, rows) else data.frame(file = character(), status = character(), id = character(), stringsAsFactors = FALSE)
  attr(out, "src_dir") <- src_dir
  out
}
