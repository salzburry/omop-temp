# RESULTS CACHE. One file per (cohort, data, mapping, method, settings, code)
# result, read before anything is recomputed and written after.
#
# Why: a slow method on a big cohort costs the same every time it is asked
# for, the App is one R process shared by every viewer, and a Domino App
# restart forgets everything it computed. With the cache, a Domino Job
# (jobs/precompute.R) can fill it before anyone opens the App, a second
# viewer gets the first viewer's results, and a restart loses nothing.
#
# The key covers everything a result depends on: the cohort's data (file
# checksum, or the generated data for a synthetic cohort), its column mapping,
# the method, every setting, and the code that decides results (CODE_HASH over
# the R/ files, so an edited estimator never serves a stale number). A setting
# changed on the page is a different key; nothing is ever served for the wrong
# settings.
#
# The directory is PROBED for writing once per process, not just for being
# there: a directory that cannot be written is reported and the dashboard
# runs without a cache. A write goes to a temporary file in the same
# directory and is renamed into place, so a Job and an App writing the same
# result at the same time never leave a half-written file for the other to
# read; and whether a result was stored is reported separately from whether
# it was computed (the `stored` field), never assumed.

.cache_state <- new.env(parent = emptyenv())

cache_reset <- function() rm(list = ls(.cache_state, all.names = TRUE), envir = .cache_state)

cache_dir <- function() {
  if (!is.null(.cache_state$dir)) return(.cache_state$dir)
  d <- DASH_CFG$cache_dir
  out <- ""; problem <- ""
  if (is.null(d) || !nzchar(d)) {
    problem <- "DASH_CACHE_DIR is empty"
  } else {
    if (!dir.exists(d)) dir.create(d, recursive = TRUE, showWarnings = FALSE)
    writable <- dir.exists(d) && tryCatch({
      f <- tempfile("probe", tmpdir = d); writeLines("ok", f); unlink(f); TRUE
    }, error = function(e) FALSE, warning = function(w) FALSE)
    if (isTRUE(writable)) out <- d
    else problem <- sprintf("cache directory '%s' cannot be created or written; running without a cache", d)
  }
  .cache_state$dir <- out
  .cache_state$problem <- problem
  if (nzchar(problem) && !identical(problem, "DASH_CACHE_DIR is empty")) message("DASHBOARD: ", problem)
  out
}

cache_status <- function() {
  d <- cache_dir()
  if (nzchar(d)) sprintf("%s (%d result(s) stored)", d, cache_count())
  else paste("off:", .cache_state$problem)
}

md5_string <- function(x) {
  f <- tempfile("md5")
  on.exit(unlink(f))
  writeLines(paste(x, collapse = "\n"), f)
  unname(tools::md5sum(f))
}

# method_hash: the checksum of the method's own script (METHODS[[id]]$code_hash),
# so a method discovered from src/ is re-run after its script changes.
# A grid a caller supplies is part of the identity: the default grid is built
# from the settings and the data, so a result on any other grid is another result.
cache_key <- function(cohort_id, data_hash, method_id, s, method_hash = "", grid = NULL)
  md5_string(paste(CODE_HASH, method_hash, cohort_id, data_hash, method_id, settings_key(s),
                   if (is.null(grid)) "grid=default" else paste0("grid=", md5_string(paste(signif(grid, 12), collapse = ","))),
                   sep = "|"))

cache_path <- function(key) file.path(cache_dir(), paste0(key, ".rds"))

cache_get <- function(key) {
  if (!nzchar(cache_dir())) return(NULL)
  p <- cache_path(key)
  if (!file.exists(p)) return(NULL)
  tryCatch(readRDS(p), error = function(e) NULL)
}

# TRUE only when THIS write landed under the final name, or another writer's
# readable result is already there (a Job and the App writing the same key).
cache_put <- function(key, res) {
  d <- cache_dir()
  if (!nzchar(d)) return(FALSE)
  final <- cache_path(key)
  tmp <- tempfile("put", tmpdir = d, fileext = ".tmp")
  ok <- tryCatch({ saveRDS(res, tmp); isTRUE(file.rename(tmp, final)) },
                 error = function(e) FALSE, warning = function(w) FALSE)
  if (file.exists(tmp)) unlink(tmp)
  if (isTRUE(ok)) return(file.exists(final))
  file.exists(final) && !is.null(tryCatch(readRDS(final), error = function(e) NULL))
}

cache_count <- function() {
  d <- cache_dir()
  if (!nzchar(d)) 0L else length(list.files(d, pattern = "\\.rds$"))
}

cache_clear <- function() {
  d <- cache_dir()
  if (!nzchar(d)) return(invisible(0L))
  f <- list.files(d, pattern = "\\.(rds|tmp)$", full.names = TRUE)
  unlink(f)
  invisible(length(f))
}
