# Shiny sources every file in R/ alphabetically before global.R unless this
# file exists. The load order matters here (config/theme.R before plots.R,
# estimators before the registry), and global.R is the one place that sets
# it, so Shiny's autoloading is switched off. Nothing else belongs in this file.
