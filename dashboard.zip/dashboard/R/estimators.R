# REFERENCE ESTIMATORS. One shape in, one shape out:
#
#   fn(d, xvars, s, grid) -> data.frame(time = grid, s1, s0)
#
#   d      what prep_data() returns: time (analysis units), event 0/1, A 0/1,
#          w (the cohort's own weights or NA), and the covariate columns
#   xvars  the covariate names to adjust for
#   s      the settings list (R/settings.R)
#   grid   evaluation times, starting at 0
#
# Everything a method reports - RD, RMST, CHR, HR(t) - is derived from its two
# marginal survival curves in R/estimands.R, identically for every method, so
# a comparison across methods is a comparison of curves and nothing else.
#
# These are standalone implementations on survival::coxph and glm so the
# dashboard runs anywhere. The study's own implementations in src/ plug in
# through R/methods.R with the same signature. `Surv` is used bare: global.R
# attaches survival.
#
# A method MAY also attach attr(result, "ic") = list(s1, s0): n x length(grid)
# matrices holding each subject's centred influence-curve value for the
# survival probability under each arm at each grid time. R/estimands.R turns
# those into analytic standard errors for every estimand; a method without
# them gets intervals from the bootstrap setting only. AIPTW and TMLE below
# supply theirs.

`%||%` <- function(a, b) if (is.null(a)) b else a

.rhs <- function(xvars, extra = "") {
  extra <- trimws(extra %||% "")
  terms <- c(if (length(xvars)) xvars else "1", if (nzchar(extra)) extra)
  paste(terms, collapse = " + ")
}

# THE ONE GATE for a user's extra model terms. Every formula a model is
# fitted on is built here, so the allowlist (R/settings.R) and the data check
# below apply on every path - the estimators, the diagnostics, a script in
# src/ that uses these helpers - not only on Run.
#   extra  the text from the settings
#   what   "extra_ps" or "extra_out", for the message
#   xvars  the covariate names the term may use
#   d      when given, the prepared data: every patient must get a finite value
check_extra <- function(extra, what, xvars, d = NULL) {
  extra <- trimws(extra %||% "")
  if (!nzchar(extra)) return(invisible(extra))
  bad <- check_formula_terms(extra, xvars)
  if (length(bad)) stop(what, ": ", paste(bad, collapse = "; "), call. = FALSE)
  if (!is.null(d)) {
    pr <- term_data_problems(d, extra, what)
    if (length(pr)) stop(pr, call. = FALSE)
  }
  invisible(extra)
}

ps_formula <- function(xvars, s, d = NULL) {
  check_extra(s$extra_ps, "extra_ps", xvars, d)
  stats::as.formula(paste("A ~", .rhs(xvars, s$extra_ps)))
}
out_formula <- function(xvars, s, d = NULL) {
  check_extra(s$extra_out, "extra_out", xvars, d)
  stats::as.formula(paste("Surv(time, event) ~ A +", .rhs(xvars, s$extra_out)))
}
cen_formula <- function(xvars) stats::as.formula(paste("Surv(time, 1 - event) ~ A +", .rhs(xvars)))

# Every patient must get a finite value from an extra model term: a term
# that yields NA would let glm or coxph drop rows and change the analysed
# population behind the method's back.
term_data_problems <- function(d, extra, what) {
  extra <- trimws(extra %||% "")
  if (!nzchar(extra)) return(character())
  f <- tryCatch(stats::as.formula(paste("~", extra)), error = function(e) NULL)
  if (is.null(f)) return(sprintf("%s '%s' is not a valid formula fragment", what, extra))
  mf <- tryCatch(suppressWarnings(stats::model.frame(f, data = d, na.action = stats::na.pass)), error = function(e) e)
  if (inherits(mf, "error")) return(sprintf("%s '%s': %s", what, extra, conditionMessage(mf)))
  bad <- rep(FALSE, nrow(d))
  for (col in mf) bad <- bad | (if (is.numeric(col)) rowSums(!is.finite(as.matrix(col))) > 0 else is.na(col))
  if (any(bad)) sprintf("%s '%s' gives a missing or non-finite value for %d patient(s); a model would drop them silently",
                        what, extra, sum(bad)) else character()
}

terms_problems <- function(d, xvars, s)
  c(term_data_problems(d, s$extra_ps, "extra_ps"), term_data_problems(d, s$extra_out, "extra_out"))

# Propensity score, bounded away from 0 and 1 by s$ps_bounds. One score per
# patient, or an error: a model that dropped rows would misalign everything after it.
fit_ps <- function(d, xvars, s) {
  fit <- stats::glm(ps_formula(xvars, s, d), family = stats::binomial(), data = d)
  ps <- stats::fitted(fit)
  if (length(ps) != nrow(d))
    stop("the propensity model fitted ", length(ps), " of ", nrow(d), " patients (rows with missing values in the model terms)", call. = FALSE)
  pmin(pmax(ps, s$ps_bounds), 1 - s$ps_bounds)
}

# ATE weights: the cohort's own weights column when asked for (every value
# must then be present and positive; nothing is swapped in silently),
# otherwise from the propensity model; stabilised when asked.
ipt_weights <- function(d, xvars, s) {
  if (isTRUE(s$use_provided_weights)) {
    bad <- sum(!is.finite(d$w) | d$w <= 0)
    if (bad > 0) stop("the cohort's weights column has ", bad, " missing, non-finite or non-positive value(s); ",
                      "map a complete weights column or untick 'use the cohort's own weights'", call. = FALSE)
    return(d$w)
  }
  ps <- fit_ps(d, xvars, s)
  w <- ifelse(d$A == 1, 1 / ps, 1 / (1 - ps))
  if (isTRUE(s$stabilize)) w <- w * ifelse(d$A == 1, mean(d$A == 1), mean(d$A == 0))
  w
}

# ---- curve helpers -----------------------------------------------------------

# (Weighted) Kaplan-Meier by arm on the grid.
km_curves <- function(d, w, grid) {
  dd <- d; dd$.w <- w
  sf <- survival::survfit(Surv(time, event) ~ A, data = dd, weights = .w)
  sm <- summary(sf, times = grid, extend = TRUE)
  st <- as.character(sm$strata)
  out <- data.frame(time = grid, s1 = sm$surv[st == "A=1"], s0 = sm$surv[st == "A=0"])
  attr(out, "step") <- TRUE                 # a step function: integrated as one (R/estimands.R)
  out
}

.surv_matrix <- function(fit, nd, grid) {
  m <- summary(survival::survfit(fit, newdata = nd, se.fit = FALSE), times = grid, extend = TRUE)$surv
  if (is.null(dim(m))) matrix(m, ncol = 1) else m          # grid x rows(nd)
}

# Standardise a Cox model: every subject's curve under A=1 and A=0, averaged.
standardize_cox <- function(fit, d, grid) {
  one <- function(a) { nd <- d; nd$A <- a; rowMeans(.surv_matrix(fit, nd, grid)) }
  out <- data.frame(time = grid, s1 = one(1), s0 = one(0))
  attr(out, "step") <- TRUE                 # the Breslow baseline is a step function
  out
}

row_cumprod <- function(m) { if (ncol(m) == 1L) return(m); t(apply(m, 1L, cumprod)) }

# Person-period data for discrete-time models. Bins are (breaks[k-1], breaks[k]];
# a subject has one row per bin at risk, dN = event in that bin, dC = censored
# in that bin. Convention: censoring in a bin precedes the event, so a row with
# dC = 1 is not at risk for the event in that bin (dropped from the event
# model), and survival of the censoring process THROUGH bin k is what the TMLE
# clever covariate divides by. A subject followed BEYOND the last break is known
# to be event-free through every bin: at risk in all K bins, no event, and NOT
# censored - coding them as censored in the last bin put a censoring hazard
# near 1 there and collapsed the targeted survival at the end of the grid.
person_period <- function(d, xvars, breaks) {
  K <- length(breaks) - 1L
  k_obs <- findInterval(d$time, breaks, left.open = TRUE)
  beyond <- k_obs > K
  k_obs[beyond] <- K
  k_obs[k_obs < 1L] <- 1L
  ev <- ifelse(beyond, 0L, d$event)
  idx <- rep.int(seq_len(nrow(d)), k_obs)
  k   <- sequence(k_obs)
  long <- d[idx, c("A", xvars), drop = FALSE]
  long$id <- idx; long$k <- k
  last <- k == k_obs[idx]
  long$dN <- as.integer(last & ev[idx] == 1L)
  long$dC <- as.integer(last & ev[idx] == 0L & !beyond[idx])
  rownames(long) <- NULL
  long
}

# Bin edges: fixed width to the end of the grid, or event-driven (the unique
# event times, thinned to s$max_bins quantiles so the long data stays tractable).
time_breaks <- function(d, s, tmax, kind = "fixed", width = s$interval) {
  if (identical(kind, "event")) {
    et <- sort(unique(d$time[d$event == 1 & d$time <= tmax]))
    if (length(et) > s$max_bins)
      et <- unique(stats::quantile(et, probs = seq(0, 1, length.out = s$max_bins), names = FALSE))
    br <- unique(c(0, et, tmax))
  } else {
    width <- max(as.numeric(width), tmax / 500)
    br <- seq(0, tmax, by = width)
    if (max(br) < tmax) br <- c(br, tmax)
  }
  br
}

# The time term of a pooled model: a natural spline on the bin index, or the
# bin as a factor when there are too few bins for one.
time_term <- function(K, df) {
  if (K <= 1L) return(NULL)
  if (K <= 3L) return("factor(k)")
  sprintf("splines::ns(k, df = %d)", max(1L, min(as.integer(df), K - 1L)))
}
pooled_formula <- function(lhs, K, df, xvars, extra = "", d = NULL) {
  check_extra(extra, "extra_out", xvars, d)
  stats::as.formula(paste(lhs, "~", paste(c(time_term(K, df), "A", .rhs(xvars, extra)), collapse = " + ")))
}

# A pooled logistic fit. Early bins with no events (or no censorings) make
# glm warn about fitted probabilities of 0 or 1; those bins contribute hazards
# of ~0, which is right, so the warning is noise in a Domino log.
pooled_glm <- function(formula, data)
  suppressWarnings(stats::glm(formula, family = stats::binomial(), data = data))

# Survival at the grid from per-bin survival. A discrete-time model gives
# survival at each bin END; between bin ends the curve is interpolated
# linearly rather than held flat, because a right-continuous step overstates
# survival inside every bin and biases RMST upward by half a bin for both arms
# - and by more for the arm with the steeper curve. Values at bin ends (the
# report times, on a grid that divides them) are untouched. Bins the model did
# not evaluate (NA) are skipped.
bins_to_grid <- function(S_bins, breaks, grid) {
  x <- c(0, breaks[-1]); y <- c(1, S_bins)
  stats::approx(x, y, xout = grid, rule = 2)$y
}

# The same linear interpolation as a matrix: W %*% values_at_knots gives the
# values at the grid, so a curve and its influence curves can be carried from
# bin ends to the grid by ONE transformation and stay consistent.
interp_weights <- function(knots, grid) {
  G <- length(grid); K <- length(knots); W <- matrix(0, G, K)
  for (g in seq_len(G)) {
    t <- grid[g]
    if (t <= knots[1]) { W[g, 1] <- 1; next }
    if (t >= knots[K]) { W[g, K] <- 1; next }
    j <- findInterval(t, knots)                   # knots[j] <= t < knots[j + 1]
    w <- (t - knots[j]) / (knots[j + 1] - knots[j])
    W[g, j] <- 1 - w; W[g, j + 1] <- w
  }
  W
}

# The subject x bin frame a pooled model predicts on, under arm a.
.full_frame <- function(d, xvars, K, a) {
  full <- d[rep(seq_len(nrow(d)), each = K), c("A", xvars), drop = FALSE]
  full$A <- a
  full$k <- rep(seq_len(K), times = nrow(d))
  full
}
.predict_matrix <- function(model, full, n, K)
  matrix(stats::predict(model, newdata = full, type = "response"), n, K, byrow = TRUE)

# ---- Singly robust: IPW ------------------------------------------------------

est_iptw_km <- function(d, xvars, s, grid) km_curves(d, ipt_weights(d, xvars, s), grid)

est_iptw_cox <- function(d, xvars, s, grid) {
  dd <- d; dd$.w <- ipt_weights(d, xvars, s)
  fit <- survival::coxph(Surv(time, event) ~ A, data = dd, weights = .w, model = TRUE)
  m <- .surv_matrix(fit, data.frame(A = c(0, 1)), grid)
  out <- data.frame(time = grid, s1 = m[, 2], s0 = m[, 1])
  attr(out, "step") <- TRUE
  out
}

# ---- Singly robust: G-computation --------------------------------------------

est_cox_rs <- function(d, xvars, s, grid) {
  fit <- survival::coxph(out_formula(xvars, s, d), data = d, model = TRUE)
  standardize_cox(fit, d, grid)
}

est_plr_rs <- function(d, xvars, s, grid) {
  br <- time_breaks(d, s, max(grid), "fixed", s$interval)
  K  <- length(br) - 1L
  long <- person_period(d, xvars, br)
  m_ev <- pooled_glm(pooled_formula("dN", K, s$time_df, xvars, s$extra_out, d), long[long$dC == 0, , drop = FALSE])
  one <- function(a) {
    h <- .predict_matrix(m_ev, .full_frame(d, xvars, K, a), nrow(d), K)
    bins_to_grid(colMeans(row_cumprod(1 - h)), br, grid)
  }
  data.frame(time = grid, s1 = one(1), s0 = one(0))
}

# ---- Naive DR: weighted outcome model, then standardisation ------------------

est_cox_dr_rs <- function(d, xvars, s, grid) {
  dd <- d; dd$.w <- ipt_weights(d, xvars, s)
  fit <- survival::coxph(out_formula(xvars, s, d), data = dd, weights = .w, model = TRUE)
  standardize_cox(fit, dd, grid)
}

# ---- Doubly robust: AIPTW ------------------------------------------------------
# psi_a(t) = mean[ S_a(t|X) + I(A=a)/pi_a(X) * ( I(T~ > t)/Gc(t|A,X) - S_a(t|X) ) ]
# with a Cox outcome model for S_a and a Cox censoring model for Gc (IPCW).
# This is the simple IPCW-augmented form WITHOUT the censoring-martingale
# augmentation term: it needs the censoring model to be right, and is then
# consistent if either the outcome model or the treatment model is right. A
# reference implementation, to be replaced by the study's own.
est_aiptw_cox <- function(d, xvars, s, grid) {
  ps <- fit_ps(d, xvars, s)
  fit_out <- survival::coxph(out_formula(xvars, s, d), data = d, model = TRUE)
  nd1 <- d; nd1$A <- 1; nd0 <- d; nd0$A <- 0
  S1 <- .surv_matrix(fit_out, nd1, grid)
  S0 <- .surv_matrix(fit_out, nd0, grid)
  Gc <- if (any(d$event == 0)) {
    fit_cen <- survival::coxph(cen_formula(xvars), data = d, model = TRUE)
    pmax(.surv_matrix(fit_cen, d, grid), s$ps_bounds)
  } else matrix(1, length(grid), nrow(d))
  Y  <- outer(grid, d$time, function(t, x) as.numeric(x > t))
  w1 <- d$A / ps
  w0 <- (1 - d$A) / (1 - ps)
  # per-subject terms (grid x n): their mean is the estimate, their centred
  # values its influence curve (nuisance models taken as known)
  term <- function(S, w) sweep(Y / Gc, 2, w, "*") - sweep(S, 2, w - 1, "*")
  T1 <- term(S1, w1); T0 <- term(S0, w0)
  psi1 <- rowMeans(T1); psi0 <- rowMeans(T0)
  cv <- data.frame(time = grid, s1 = pmin(pmax(psi1, 0), 1), s0 = pmin(pmax(psi0, 0), 1))
  attr(cv, "ic") <- list(s1 = t(T1 - psi1), s0 = t(T0 - psi0))
  attr(cv, "step") <- TRUE                  # indicators and Cox curves: a step function
  cv
}

# ---- Doubly robust: TMLE (discrete time) ---------------------------------------
# Moore & van der Laan (2009) style: pooled logistic hazards on person-period
# data, a logistic censoring hazard and a propensity model; for each grid time
# the hazard is fluctuated along the clever covariate
#   H_a(k, X) = - I(A = a) / ( g_a(X) * Gc_a(k | X) ) * S_a(t* | X) / S_a(k | X)
# until the fluctuation coefficient is ~0, and the targeted survival is averaged.
# Cost grows with the number of bins; the time grid is a setting.
est_tmle <- function(d, xvars, s, grid) {
  n  <- nrow(d)
  br <- time_breaks(d, s, max(grid), s$tmle_grid, s$tmle_width)
  K  <- length(br) - 1L
  long <- person_period(d, xvars, br)
  m_ev <- pooled_glm(pooled_formula("dN", K, s$time_df, xvars, s$extra_out, d), long[long$dC == 0, , drop = FALSE])
  has_cens <- any(long$dC == 1L)
  m_cen <- if (has_cens) pooled_glm(pooled_formula("dC", K, s$time_df, xvars), long) else NULL
  g1 <- fit_ps(d, xvars, s)
  targets <- unique(findInterval(grid, br[-1]))
  targets <- sort(targets[targets >= 1L])

  one <- function(a) {
    full <- .full_frame(d, xvars, K, a)
    h  <- .predict_matrix(m_ev, full, n, K)
    Gc <- if (has_cens) row_cumprod(1 - .predict_matrix(m_cen, full, n, K)) else matrix(1, n, K)
    Gc <- pmax(Gc, s$ps_bounds)
    ga <- if (a == 1) g1 else 1 - g1
    lh0 <- stats::qlogis(pmin(pmax(h, 1e-6), 1 - 1e-6))
    obs <- long[long$A == a & long$dC == 0L, c("id", "k", "dN"), drop = FALSE]
    S_t  <- rep(NA_real_, K)
    IC_t <- matrix(0, n, K)
    failed <- 0L; unconverged <- 0L
    for (kt in targets) {
      lh <- lh0
      rows <- obs[obs$k <= kt, , drop = FALSE]
      ij <- cbind(rows$id, rows$k)
      clever <- function(S) -(S[, kt] / S[, seq_len(kt), drop = FALSE]) / (ga * Gc[, seq_len(kt), drop = FALSE])
      converged <- FALSE
      for (it in seq_len(s$tmle_max_iter)) {
        S <- pmax(row_cumprod(1 - stats::plogis(lh)), 1e-8)
        H <- clever(S)
        eps <- tryCatch(
          stats::glm.fit(x = matrix(H[ij], ncol = 1), y = rows$dN, offset = lh[ij],
                         family = stats::binomial(), intercept = FALSE)$coefficients[1],
          error = function(e) NA_real_)
        if (!is.finite(eps)) { failed <- failed + 1L; break }       # the step is skipped, and said so
        lh[, seq_len(kt)] <- lh[, seq_len(kt)] + eps * H
        if (abs(eps) < s$tmle_tol) { converged <- TRUE; break }
      }
      if (!converged && is.finite(eps)) unconverged <- unconverged + 1L
      hstar <- stats::plogis(lh)
      S <- pmax(row_cumprod(1 - hstar), 1e-8)
      S_t[kt] <- mean(S[, kt])
      # efficient influence curve: over the subject's observed at-risk bins,
      # H * (dN - h*), plus S*(kt | X) - psi
      H <- clever(S)
      contrib <- H[ij] * (rows$dN - hstar[ij])
      agg <- rowsum(contrib, rows$id)
      v <- numeric(n); v[as.integer(rownames(agg))] <- agg[, 1]
      IC_t[, kt] <- v + S[, kt] - S_t[kt]
    }
    # from bin ends to the grid by ONE interpolation, for the curve and its
    # influence curves alike (time 0: survival 1, influence 0)
    W <- interp_weights(c(0, br[-1][targets]), grid)
    list(curve = as.vector(W %*% c(1, S_t[targets])),
         ic = cbind(0, IC_t[, targets, drop = FALSE]) %*% t(W),
         failed = failed, unconverged = unconverged)
  }
  r1 <- one(1); r0 <- one(0)
  cv <- data.frame(time = grid, s1 = r1$curve, s0 = r0$curve)
  notes <- character()
  if (r1$failed + r0$failed > 0)
    notes <- c(notes, sprintf("TMLE: the targeting step could not be fitted at %d bin(s); those bins are untargeted", r1$failed + r0$failed))
  if (r1$unconverged + r0$unconverged > 0)
    notes <- c(notes, sprintf("TMLE: the targeting step did not converge within %d iterations at %d bin(s)", s$tmle_max_iter, r1$unconverged + r0$unconverged))
  if (length(notes)) {
    # an incomplete targeting is not a TMLE: the estimate is shown as what it
    # is, with no analytic interval, and the result is marked incomplete
    attr(cv, "incomplete") <- paste(notes, collapse = "; ")
  } else {
    attr(cv, "ic") <- list(s1 = r1$ic, s0 = r0$ic)
  }
  attr(cv, "notes") <- notes
  cv
}
