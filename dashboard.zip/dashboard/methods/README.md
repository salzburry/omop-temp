# methods/

Adapters that wrap the study's `src/analysis` functions into the dashboard's
method contract, one script per method, written where the study's scripts are
and following `docs/INTEGRATION_HANDOVER.md`. The folder is scanned at startup
exactly like `src/`: a script here that defines `estimate_curves(d, xvars, s,
grid)` is a method, shown on the Methods page with its file name. It ships
empty.
