#!/usr/bin/env Rscript
# Fill the results cache ahead of the App: every cohort x method under the
# default settings (the ones a session starts with, so the App finds them).
# The Domino pattern: a Job computes, the App serves.
#
#   Rscript jobs/precompute.R                         # every cohort, the fast methods
#   Rscript jobs/precompute.R --methods all           # ...including the slow ones
#   Rscript jobs/precompute.R --methods tmle_disc,aiptw_cox --cohorts "ECOG,STAGE"
#
# Reads the same DASH_* environment as the App. On Domino run it with
# DASH_SOURCE=files, DASH_DATA_DIR and DASH_CACHE_DIR pointing at the Dataset
# the App attaches. Writes a summary CSV into output/ and exits non-zero if
# any combination failed, so a scheduled Job reports it.

args <- commandArgs(trailingOnly = TRUE)
opt <- function(flag, default) {
  i <- match(flag, args)
  if (is.na(i) || i == length(args)) default else args[i + 1]
}
.here <- local({
  a <- grep("^--file=", commandArgs(FALSE), value = TRUE)
  if (!length(a)) getwd()
  else dirname(dirname(normalizePath(gsub("~+~", " ", sub("^--file=", "", a[1]), fixed = TRUE), winslash = "/")))
})
setwd(.here)
source("global.R")

m_opt <- opt("--methods", "fast")
c_opt <- opt("--cohorts", "all")
ids <- switch(m_opt, fast = fast_method_ids(), all = available_method_ids(),
              trimws(strsplit(m_opt, ",")[[1]]))
cohorts <- if (identical(c_opt, "all")) COHORTS$id else trimws(strsplit(c_opt, ",")[[1]])

bad <- setdiff(ids, available_method_ids())
if (length(bad)) stop("Unknown or unavailable method id(s): ", paste(bad, collapse = ", "), call. = FALSE)
bad <- setdiff(cohorts, COHORTS$id)
if (length(bad)) stop("Unknown cohort id(s): ", paste(bad, collapse = ", "), call. = FALSE)
if (!nzchar(cache_dir())) stop("No writable cache directory: set DASH_CACHE_DIR.", call. = FALSE)

s <- DEFAULT_SETTINGS
cat(sprintf("Cache: %s (%d result(s) before)\nSource: %s\nSettings: %s\n\n",
            cache_dir(), cache_count(), PROVENANCE$origin, settings_key(s)))

rows <- list()
for (cid in cohorts) {
  d <- tryCatch(prep_cohort(COHORTS, cid, cohort_spec(COHORTS, cid), s$time_divisor), error = function(e) e)
  if (inherits(d, "error")) {
    cat(sprintf("%-28s %-26s %s\n", cid, "(prepare)", conditionMessage(d)))
    rows[[length(rows) + 1]] <- data.frame(cohort = cid, method = "(prepare)", status = "failed",
                                           cached = FALSE, stored = FALSE, seconds = NA_real_, message = conditionMessage(d))
    next
  }
  for (mid in ids) {
    r <- run_method_cached(mid, d, s)
    status <- result_status(r)                       # the same word as every page: ok, incomplete, failed
    stored <- isTRUE(r$stored)
    cat(sprintf("%-28s %-26s %-10s %6.1fs %s%s\n", cid, r$label, toupper(status),
                r$seconds, if (r$from_cache) "(cached)" else "", if (status == "ok" && !stored) " NOT STORED" else ""))
    rows[[length(rows) + 1]] <- data.frame(cohort = cid, method = r$label, status = status,
                                           cached = r$from_cache, stored = stored, seconds = r$seconds, message = r$message)
  }
}
summary <- do.call(rbind, rows)
dir.create("output", showWarnings = FALSE)
out <- file.path("output", sprintf("precompute_%s.csv", format(Sys.time(), "%Y%m%d_%H%M%S")))
utils::write.csv(summary, out, row.names = FALSE)
not_stored <- sum(summary$status == "ok" & !summary$stored)
cat(sprintf("\n%d ok, %d incomplete, %d failed, %d from the cache, %d computed but NOT stored. Summary: %s. Cache now holds %d result(s).\n",
            sum(summary$status == "ok"), sum(summary$status == "incomplete"), sum(summary$status == "failed"),
            sum(summary$cached), not_stored, out, cache_count()))
# the Job exists to fill the cache with complete results: anything else is a failure of the Job
if (any(summary$status != "ok") || not_stored > 0) quit(status = 1)
