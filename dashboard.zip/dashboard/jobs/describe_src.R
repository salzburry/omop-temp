#!/usr/bin/env Rscript
# A self-check of how the dashboard reads the study's analysis functions,
# WITHOUT copying their code. For every R script in the study's analysis folder
# it lists the functions defined, with their arguments and defaults, and the
# @param / @return lines of their documentation. With --try it also calls each
# run_*_analysis() function on a SYNTHETIC cohort (never the real files),
# exactly as the dashboard's automatic wrapper would, and prints how it was
# called, the SHAPE of what came back (names, classes, sizes, numeric ranges)
# and whether the two survival curves were found in it. No function body is
# printed and no patient value can appear. The result is one text file to
# read, photograph or paste.
#
#   Rscript jobs/describe_src.R                       # signatures and documentation only; runs nothing
#   Rscript jobs/describe_src.R --try                 # ...and the check of each run_*_analysis() function
#   Rscript jobs/describe_src.R --dir ../src/analysis # another folder
#   Rscript jobs/describe_src.R --functions "^run_"   # which functions --try calls (a regular expression)
#
# Writes output/src_signatures.txt in the dashboard folder.

args <- commandArgs(trailingOnly = TRUE)
opt <- function(flag, default) { i <- match(flag, args); if (is.na(i) || i == length(args)) default else args[i + 1] }
.here <- local({
  a <- grep("^--file=", commandArgs(FALSE), value = TRUE)
  if (!length(a)) getwd()
  else dirname(dirname(normalizePath(gsub("~+~", " ", sub("^--file=", "", a[1]), fixed = TRUE), winslash = "/")))
})
setwd(.here)
source("global.R")

src_dir <- opt("--dir", if (dir.exists(ANALYSIS_DIR)) ANALYSIS_DIR else SRC_DIR)
try_run <- "--try" %in% args
fn_pattern <- opt("--functions", STUDY_PATTERN)
repo_root <- dirname(SRC_DIR)

out <- character()
say <- function(...) out <<- c(out, paste0(...))
short <- function(x, n = 70) { x <- paste(trimws(x), collapse = " "); if (nchar(x) > n) paste0(substr(x, 1, n), " ...") else x }
is_fun_def <- function(e) is.call(e) && length(e) == 3L && is.symbol(e[[1]]) && as.character(e[[1]]) %in% c("<-", "=") &&
  is.symbol(e[[2]]) && is.call(e[[3]]) && is.symbol(e[[3]][[1]]) && identical(as.character(e[[3]][[1]]), "function")

# ---- what a result looks like: names, classes, sizes, ranges - never its values ----
rng <- function(v) { v <- suppressWarnings(as.numeric(v)); v <- v[is.finite(v)]; if (!length(v)) "all NA" else sprintf("range %s to %s", signif(min(v), 3), signif(max(v), 3)) }
col_desc <- function(v) {
  if (is.numeric(v)) sprintf("numeric(%d), %s", length(v), rng(v))
  else if (is.logical(v)) sprintf("logical(%d)", length(v))
  else if (is.character(v) || is.factor(v)) {
    u <- unique(as.character(v))
    sprintf("%s(%d), %d distinct: %s%s", class(v)[1], length(v), length(u), paste(utils::head(u, 4), collapse = " | "), if (length(u) > 4) " | ..." else "")
  } else sprintf("%s(%d)", class(v)[1], length(v))
}
shape <- function(x, name, depth = 0L, max_depth = 3L) {
  pad <- strrep("  ", depth + 3L)
  if (is.data.frame(x)) {
    say(pad, name, ": data.frame [", nrow(x), " x ", ncol(x), "]")
    for (cn in names(x)) say(pad, "  $", cn, ": ", col_desc(x[[cn]]))
  } else if (is.matrix(x)) {
    say(pad, name, ": matrix [", nrow(x), " x ", ncol(x), "], ", rng(x),
        if (!is.null(colnames(x))) paste0(", columns: ", short(paste(colnames(x), collapse = ", "))) else "")
  } else if (is.list(x)) {
    say(pad, name, ": ", paste(class(x), collapse = "/"), " of ", length(x))
    if (depth < max_depth) for (i in seq_along(x))
      shape(x[[i]], if (is.null(names(x)) || !nzchar(names(x)[i])) sprintf("[[%d]]", i) else names(x)[i], depth + 1L, max_depth)
  } else if (is.function(x)) say(pad, name, ": function")
  else say(pad, name, ": ", col_desc(x), if (!is.null(names(x))) paste0(", names: ", short(paste(names(x), collapse = ", "))) else "")
}

say("STUDY FUNCTIONS, DESCRIBED WITHOUT THEIR CODE")
say("folder: ", src_dir)
say("written by dashboard/jobs/describe_src.R on ", format(Sys.time(), "%Y-%m-%d %H:%M"),
    if (try_run) "; --try: results are from a SYNTHETIC cohort, shapes only" else "; signatures only, nothing was run")
say("")
files <- if (dir.exists(src_dir)) sort(list.files(src_dir, pattern = "\\.[Rr]$", full.names = TRUE, recursive = TRUE)) else character()
if (!length(files)) say("no R scripts found in ", src_dir)

if (try_run) {
  syn <- synthetic_cohorts()[[1]]
  d <- prep_data(syn, auto_spec(syn), DEFAULT_SETTINGS$time_divisor)
  xv <- attr(d, "xvars")
  say("the cohort each function is called on: time (", DEFAULT_SETTINGS$time_unit, "), event 0/1, A 0/1 with 1 = treated, covariates ",
      paste(xv, collapse = ", "), "; other names a script uses for time, event or treatment are added as copies")
  say("")
}

n_ok <- 0L; n_bad <- 0L
# the study's code is loaded once, into one environment, exactly as the dashboard loads it
st <- if (try_run && dir.exists(src_dir)) load_study_env(src_dir, fn_pattern, repo_root, lib_dir = SRC_DIR) else NULL
if (!is.null(st) && length(st$errors)) names(st$errors) <- normalizePath(names(st$errors), winslash = "/", mustWork = FALSE)
for (f in normalizePath(files, winslash = "/", mustWork = FALSE)) {
  say("== ", substring(normalizePath(f, winslash = "/"), nchar(normalizePath(src_dir, winslash = "/")) + 2L))
  ex <- tryCatch(parse(f, keep.source = FALSE), error = function(e) NULL)
  if (is.null(ex)) { say("  (cannot be parsed)"); say(""); next }
  fns <- character()
  for (e in ex) if (is_fun_def(e)) {
    fm <- e[[3]][[2]]; nm <- names(fm)
    a <- vapply(seq_along(fm), function(i) if (identical(fm[[i]], quote(expr = ))) nm[i] else paste0(nm[i], " = ", short(deparse(fm[[i]]), 50)), character(1))
    say("  ", as.character(e[[2]]), "(", paste(a, collapse = ", "), ")")
    fns <- c(fns, as.character(e[[2]]))
  }
  if (!length(fns)) say("  (defines no function at top level)")
  doc <- grep("^#'\\s*@(param|return)", readLines(f, warn = FALSE), value = TRUE)
  for (ln in doc) say("    ", short(sub("^#'\\s*", "", ln), 110))

  todo <- grep(fn_pattern, fns, value = TRUE)
  if (try_run && length(todo)) {
    err <- st$errors[[f]]
    if (!is.null(err)) { say("  --try: the script could not be loaded: ", short(err, 160)); n_bad <- n_bad + length(todo) }
    else for (fname in todo) {
      fn <- get0(fname, envir = st$env, inherits = FALSE)
      if (!is.function(fn)) next
      slow <- identical(study_speed(fname), "slow")
      times <- study_times(DEFAULT_SETTINGS, slow)
      say("  --try ", fname, " -> \"", study_label(fname), "\", ", study_class(fname), if (slow) ", slow" else "")
      t0 <- proc.time()[["elapsed"]]
      g <- tryCatch({ setTimeLimit(elapsed = 300, transient = TRUE)
                      suppressWarnings(suppressMessages(call_study(fn, study_data(d, xv, script_tokens(f)), xv, times, repo_root))) },
                    error = function(e) e, finally = setTimeLimit())
      if (inherits(g, "error")) { say("      FAILED: ", short(conditionMessage(g), 200)); n_bad <- n_bad + 1L; next }
      say("      called with ", if (length(g$notes)) paste(g$notes, collapse = "; ") else "no arguments")
      res <- g$result
      say("      returned in ", round(proc.time()[["elapsed"]] - t0, 1), " s:")
      shape(res, "result")
      hit <- find_curves(res, times, attr(d, "arm_labels"))
      if (is.null(hit$time)) { say("      CURVES NOT FOUND: ", attr(hit, "why")); n_bad <- n_bad + 1L }
      else {
        cov <- tryCatch({ curves_on_grid(hit, make_grid(DEFAULT_SETTINGS, d)); NULL }, error = function(e) conditionMessage(e))
        if (is.null(cov)) { say("      CURVES FOUND in ", hit$where, ": ", hit$how, " (", length(hit$time), " times)"); n_ok <- n_ok + 1L }
        else { say("      CURVES FOUND but not usable: ", cov); n_bad <- n_bad + 1L }
      }
    }
  }
  say("")
}
if (try_run) say("SUMMARY: ", n_ok, " function(s) the dashboard can run as they are, ", n_bad, " it cannot (see FAILED / NOT FOUND above).")

dir.create("output", showWarnings = FALSE)
path <- file.path("output", "src_signatures.txt")
writeLines(out, path)
cat(out, sep = "\n")
cat("\nWritten to ", normalizePath(path, winslash = "/"), "\n", sep = "")
