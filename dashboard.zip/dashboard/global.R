# Loaded once at startup, by app.R and by tests/run_tests.R. No Shiny here:
# every number a page shows comes from a function in R/ that runs without it,
# which is what makes the headless tests possible.
#
# Order: config, then the registries (R/), then the cohort source. The two
# registries are the whole point of the layout:
#   R/methods.R   one add_method() per estimator      -> the Methods page
#   R/sources.R   files under DASH_DATA_DIR + cohorts.csv -> the Cohort list
# app.R reads both and names neither a method nor a cohort.

suppressPackageStartupMessages({
  library(survival)
  library(ggplot2)
})

.dash_dir <- local({
  f <- tryCatch(sys.frame(1)$ofile, error = function(e) NULL)
  if (is.null(f) || !nzchar(f)) getwd() else dirname(normalizePath(f, winslash = "/"))
})

source(file.path(.dash_dir, "config", "dashboard_config.R"))
source(file.path(.dash_dir, "config", "theme.R"))
DASH_CFG <- dashboard_config()

for (f in c("synthetic.R", "spec.R", "sources.R", "settings.R", "estimands.R",
            "estimators.R", "cache.R", "methods.R", "src_methods.R", "study_methods.R", "diagnostics.R", "plots.R"))
  source(file.path(.dash_dir, "R", f))

# A relative cache directory is taken from this folder. On Domino, set
# DASH_CACHE_DIR to a Dataset the precompute Job and the App both attach.
if (nzchar(DASH_CFG$cache_dir) && !grepl("^(/|[A-Za-z]:)", DASH_CFG$cache_dir))
  DASH_CFG$cache_dir <- file.path(.dash_dir, DASH_CFG$cache_dir)

# The code that decides a result, as one checksum: part of every cache key, so
# an edited estimator can never be served a number the old one produced.
CODE_HASH <- md5_string(unname(tools::md5sum(
  file.path(.dash_dir, "R", c("spec.R", "settings.R", "estimands.R", "estimators.R", "methods.R")))))

# The study's own estimator scripts: beside this folder as src/ in the
# repository (movable with DASH_SRC_DIR), and this folder's methods/, where
# adapters that wrap the study's functions live without touching the study's
# files. Every script in either that defines estimate_curves() is registered
# as a method now; the scan is kept for the About page.
SRC_DIR     <- .env_chr("DASH_SRC_DIR", file.path(dirname(.dash_dir), "src"))
METHOD_DIRS <- unique(c(file.path(.dash_dir, "methods"), SRC_DIR))
SRC_SCAN    <- register_src_methods(METHOD_DIRS)
if (nrow(SRC_SCAN)) {
  message("methods (", paste(METHOD_DIRS, collapse = ", "), "): ", sum(SRC_SCAN$status == "registered"),
          " method(s) registered from ", nrow(SRC_SCAN), " script(s)")
  for (i in which(SRC_SCAN$status != "registered")) message("  ", SRC_SCAN$folder[i], "/", SRC_SCAN$file[i], ": ", SRC_SCAN$status[i])
} else message("methods (", paste(METHOD_DIRS, collapse = ", "), "): no scripts found; the reference methods only")

# The study's own run_*_analysis() functions (<src>/analysis), wrapped into
# methods automatically (R/study_methods.R) unless an adapter in methods/
# already stands for one. DASH_AUTO_ADAPT=FALSE turns this off.
ANALYSIS_DIR <- .env_chr("DASH_ANALYSIS_DIR", file.path(SRC_DIR, "analysis"))
if (.env_lgl("DASH_AUTO_ADAPT", TRUE)) {
  .taken <- c(SRC_SCAN$id[!is.na(SRC_SCAN$id)], tools::file_path_sans_ext(SRC_SCAN$file[SRC_SCAN$folder == "methods"]))
  AUTO_SCAN <- register_study_methods(
    ANALYSIS_DIR, .env_chr("DASH_ANALYSIS_PATTERN", STUDY_PATTERN), .taken, repo_root = dirname(SRC_DIR), lib_dir = SRC_DIR,
    code_hash = md5_string(c(src_code_hash(unique(c(METHOD_DIRS, ANALYSIS_DIR))),
                             unname(tools::md5sum(file.path(.dash_dir, "R", "study_methods.R"))))))
  if (nrow(AUTO_SCAN)) {
    message("study functions (", ANALYSIS_DIR, "): ", sum(AUTO_SCAN$status == "registered (auto-adapted)"), " of ", nrow(AUTO_SCAN), " wrapped as methods")
    for (i in which(AUTO_SCAN$status != "registered (auto-adapted)")) message("  ", AUTO_SCAN$file[i], ": ", AUTO_SCAN$status[i])
    SRC_SCAN <- rbind(SRC_SCAN, AUTO_SCAN)
  }
}

if (identical(DASH_CFG$source, "synthetic") && !isTRUE(DASH_CFG$allow_synthetic))
  stop("DASHBOARD ERROR: DASH_SOURCE is 'synthetic' but DASH_ALLOW_SYNTHETIC=FALSE. ",
       "Set DASH_SOURCE=files and DASH_DATA_DIR to the attached Dataset's mount.", call. = FALSE)

COHORTS <- discover_cohorts(DASH_CFG, .dash_dir)

# every checksum the generator's markers list, in the data folder(s) and this
# folder: what an upload is checked against, since it arrives without a marker
SYNTHETIC_MD5S <- known_synthetic_md5s(unique(c(if (nzchar(DASH_CFG$data_dir)) DASH_CFG$data_dir,
                                                .dash_dir, file.path(.dash_dir, "data"))))

# Provenance is per cohort: a files-mode cohort whose file the generator
# marked (SYNTHETIC.md5 beside it), or that cohorts.csv declares synthetic,
# is generated data however it arrived, and the production guard applies.
if (!isTRUE(DASH_CFG$allow_synthetic) && any(COHORTS$synthetic))
  stop("DASHBOARD ERROR: DASH_ALLOW_SYNTHETIC=FALSE but these cohort files are generated data: ",
       paste(basename(COHORTS$file[COHORTS$synthetic]), collapse = ", "),
       ". Point DASH_DATA_DIR at the real cohort files.", call. = FALSE)

PROVENANCE <- list(
  synthetic = identical(DASH_CFG$source, "synthetic") || any(COHORTS$synthetic),
  n_synthetic = sum(COHORTS$synthetic),
  source    = DASH_CFG$source,
  origin    = if (identical(DASH_CFG$source, "synthetic")) "generated in-process (R/synthetic.R)"
              else paste(unique(dirname(COHORTS$file[!is.na(COHORTS$file)])), collapse = ", "),
  n_cohorts = nrow(COHORTS)
)
if (!nrow(COHORTS))
  message("No cohort found from source '", DASH_CFG$source, "' (", PROVENANCE$origin,
          "). The dashboard will start and say so.")

DEFAULT_SETTINGS <- default_settings(DASH_CFG)
