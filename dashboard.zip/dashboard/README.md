# DR time-to-event dashboard

R Shiny app comparing estimators of a marginal treatment effect on a
time-to-event outcome - singly robust (IPW, G-computation), naive DR, AIPTW
and TMLE - on the same cohort, and comparing them across the eligibility
scenarios. Built as a Domino App with a precompute Job and a results cache.

- `DASHBOARD.md` - what is on the pages, how a cohort or a method is added, the method contract, intervals, the cache.
- `DEPLOY_DOMINO.md` - compute environment, Dataset, App publish, the precompute Job, environment variables.

```
Rscript -e "shiny::runApp('.', launch.browser = TRUE)"   # local
Rscript tests/run_tests.R                                # headless checks
Rscript jobs/precompute.R                                # fill the results cache
bash app.sh                                              # what Domino runs
```

This folder is the repository's `dashboard/`; it runs on synthetic cohorts
(banner on every page) until `DASH_SOURCE=files` points it at the real ones.
