#!/usr/bin/env bash
# Domino App launcher.
#
# Domino runs the App command from the project root and expects the process
# on 0.0.0.0:8888. This file changes to the folder above wherever it sits and
# runs that folder as the app, so the dashboard can live anywhere in the
# project: set the App command to `bash <path>/dashboard/app.sh`.
#
# Data source. Default is SYNTHETIC, so a first deploy comes up and can be
# clicked through before any data is attached. To show real cohorts, attach a
# Domino Dataset holding the *_feature_table.csv files (and optionally a
# cohorts.csv) and point at its mount - read the path off the Data step of the
# publish dialog rather than assuming it:
#
#   export DASH_SOURCE=files
#   export DASH_DATA_DIR=/mnt/data/<dataset-name>
#
# Set DASH_ALLOW_SYNTHETIC=FALSE on any deployment that must never show
# generated numbers - it then refuses to start rather than falling back.
set -euo pipefail

APP_DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$APP_DIR/.."

export DASH_SOURCE="${DASH_SOURCE:-synthetic}"

R -e "shiny::runApp('$(basename "$APP_DIR")', host = '0.0.0.0', port = 8888, launch.browser = FALSE)"
