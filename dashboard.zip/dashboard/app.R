# DR time-to-event dashboard - app.R is WIRING ONLY.
#
# The five pages are generated from two registries and never name a method or
# a cohort themselves:
#   R/methods.R   add_method(...) once per estimator   -> Methods page, Results, Compare
#   R/sources.R   files under DASH_DATA_DIR + cohorts.csv -> the cohort list
# Everything computed lives in R/ and runs without Shiny (tests/run_tests.R).
# Results go through the cache in R/cache.R: what a Domino Job precomputed
# (jobs/precompute.R) is loaded when a session opens, and nothing is computed
# twice.
#
# Session rules: uploads live in the session's own store and never leak to
# another viewer; a page shows only results of the CURRENT analysis (these
# settings, this cohort under this mapping) and says how many it is hiding;
# an error in loading or preparing any one cohort is reported in place and
# never closes the session.
#
# Run locally:  shiny::runApp(".")        On Domino: app.sh (0.0.0.0:8888).

suppressPackageStartupMessages({
  library(shiny)
  library(bslib)
  library(DT)
  library(plotly)
})
source("global.R")
options(shiny.maxRequestSize = DASH_CFG$max_upload_mb * 1024^2)

CLASS_INPUT <- stats::setNames(make.unique(paste0("m_", make.names(method_classes())), sep = "_"), method_classes())
ESTIMAND_CHOICES <- stats::setNames(names(ESTIMAND_LABELS), ESTIMAND_LABELS)
DEFAULT_ARMS <- c(treated = "Treated", control = "Control")

banner <- function() {
  if (!PROVENANCE$synthetic) return(NULL)
  div(class = "alert dash-banner py-2 px-3 mb-3 small",
      if (identical(PROVENANCE$source, "synthetic"))
        HTML("<b>SYNTHETIC DATA</b> &mdash; these cohorts are generated in-process, not study numbers. ",
             "Set <code>DASH_SOURCE=files</code> to read real cohort files.")
      else HTML(sprintf("<b>SYNTHETIC DATA</b> &mdash; %d of the %d cohort files are generated data (listed in a SYNTHETIC.md5 marker or declared in cohorts.csv), not study numbers.",
                        PROVENANCE$n_synthetic, PROVENANCE$n_cohorts)))
}

# the look: colours from config/theme.R as CSS variables, the stylesheet from www/
look <- function() tags$head(
  tags$style(HTML(theme_css_vars())),
  tags$link(rel = "stylesheet", href = "dashboard.css")
)

cohort_choices <- function(reg) if (nrow(reg)) stats::setNames(reg$id, cohort_display(reg)) else character(0)

# one checkbox per method, grouped by class, the method's script named beside it
method_checkboxes <- function() {
  tab <- methods_table()
  lapply(method_classes(), function(cl) {
    rows  <- tab[tab$class == cl, , drop = FALSE]
    avail <- rows[rows$available, , drop = FALSE]
    miss  <- rows[!rows$available, , drop = FALSE]
    names_html <- lapply(seq_len(nrow(avail)), function(i)
      tagList(if (avail$speed[i] == "slow") paste0(avail$label[i], " (slow)") else avail$label[i],
              tags$small(class = "text-muted ms-2", avail$file[i])))
    tagList(
      h6(cl, class = "mt-3 mb-1"),
      if (nrow(avail)) checkboxGroupInput(CLASS_INPUT[[cl]], NULL,
                                          choiceNames = names_html, choiceValues = avail$id,
                                          selected = avail$id[avail$speed == "fast"]),
      if (nrow(miss)) p(class = "text-muted small mb-1",
                        sprintf("Not available: %s (needs %s)", paste(miss$label, collapse = ", "),
                                paste(unique(unlist(strsplit(miss$requires, ", "))), collapse = ", ")))
    )
  })
}

# ---- UI ------------------------------------------------------------------------

ui <- page_navbar(
  id = "nav",
  title = DASH_CFG$title,
  theme = bs_theme(version = 5, primary = THEME$primary, bg = THEME$surface, fg = THEME$ink),
  navbar_options = navbar_options(bg = THEME$surface, theme = "light", collapsible = FALSE),
  fillable = FALSE,
  header = tagList(look(), banner()),

  nav_panel(title = tagList(tags$b("1"), "Data"), value = "1 · Data",
    layout_sidebar(
      sidebar = sidebar(width = 360,
        selectInput("cohort", "Cohort", choices = cohort_choices(COHORTS)),
        if (isTRUE(DASH_CFG$allow_upload))
          fileInput("upload", sprintf("Add a cohort file for this session (up to %s MB)", format(DASH_CFG$max_upload_mb)),
                    accept = c(".csv", ".tsv", ".rds", ".xlsx", ".xls")),
        hr(),
        h6("Column mapping"),
        selectInput("map_time",  "Time / duration", choices = NULL),
        selectInput("map_event", "Event (1 = event, 0 = censored)", choices = NULL),
        checkboxInput("map_event_from_time", "The event is 'a duration is recorded' (the file's event column is not used)", FALSE),
        selectInput("map_trt",   "Treatment (a column with exactly two values)", choices = NULL),
        uiOutput("map_treated_ui"),
        selectInput("map_id",      "Patient id (optional)", choices = NULL),
        selectInput("map_weights", "Weights column (optional)", choices = NULL),
        selectInput("map_label",   "Arm label column (optional)", choices = NULL),
        selectInput("map_start",  "Start date (optional): follows patients without an event to the data cut-off", choices = NULL),
        selectInput("map_censor", "Follow-up of patients without an event (optional): days, or a date", choices = NULL),
        selectizeInput("map_covs", "Covariates to adjust for", choices = NULL, multiple = TRUE),
        p(class = "text-muted small", textOutput("cov_note", inline = TRUE)),
        checkboxInput("map_missing_level", "A blank in a text covariate is a category of its own ('missing')", TRUE),
        numericInput("time_divisor", "Divide duration by (30.4375: days to months)",
                     value = DASH_CFG$time_divisor, min = 1e-6),
        textInput("time_unit", "Time unit label (axes and tables)", DASH_CFG$time_unit),
        actionButton("apply_map", "Apply mapping", class = "btn-primary w-100")
      ),
      uiOutput("cohort_desc"),
      uiOutput("data_check"),
      layout_column_wrap(
        width = "170px", fill = FALSE, class = "mb-3",
        value_box("Patients",         textOutput("vb_n")),
        value_box("Events",           textOutput("vb_events")),
        value_box("Treated",          textOutput("vb_treated"), p(class = "text-muted small mb-0", textOutput("vb_treated_arm", inline = TRUE))),
        value_box("Control",          textOutput("vb_control"), p(class = "text-muted small mb-0", textOutput("vb_control_arm", inline = TRUE))),
        value_box("Median follow-up", textOutput("vb_fu")),
        value_box("Rows dropped",     textOutput("vb_dropped"))
      ),
      card(card_header("Preview (first 200 rows of the file)"), DTOutput("preview"))
    )
  ),

  nav_panel(title = tagList(tags$b("2"), "Diagnostics"), value = "2 · Diagnostics",
    layout_columns(col_widths = c(6, 6),
      card(card_header("Kaplan-Meier by arm (unadjusted)"), plotlyOutput("km_plot", height = "360px"),
           tableOutput("km_risk"), p(class = "text-muted small", "Numbers at risk by arm.")),
      card(card_header("Propensity-score overlap: observed filled, IPT-weighted outlined; treated above, control below"),
           plotlyOutput("ps_plot", height = "420px"))),
    layout_columns(col_widths = c(7, 5),
      card(card_header("Covariate balance: standardised mean differences unweighted, IPT-weighted and 1:1 matched"),
           plotlyOutput("love_plot", height = "480px"),
           p(class = "text-muted small", textOutput("match_note", inline = TRUE))),
      card(card_header("Weights"), plotlyOutput("weights_plot", height = "300px"), tableOutput("weight_tab"),
           p(class = "text-muted small", "ESS = effective sample size under the weights. PS model and weighting follow the settings on the Methods page."),
           DTOutput("balance_tab"))),
    layout_columns(col_widths = c(7, 5),
      card(card_header("Covariate distributions by arm: ECDF, unweighted beside IPT-weighted"),
           plotlyOutput("ecdf_plot", height = "auto"),
           p(class = "text-muted small", "Continuous covariates only. Lines that meet after weighting are balanced across the whole distribution, not just in the mean.")),
      card(card_header("Alive after the CHR time across the propensity score, by arm (descriptive)"),
           plotlyOutput("het_plot", height = "420px"),
           p(class = "text-muted small", textOutput("het_note", inline = TRUE)))),
    layout_columns(col_widths = c(4, 4, 4),
      card(card_header("Follow-up and censoring by arm"), tableOutput("cens_tab"),
           p(class = "text-muted small", "Median follow-up by reverse Kaplan-Meier.")),
      card(card_header("Numbers at risk at the report times"), tableOutput("risk_tab")),
      card(card_header("Proportional hazards: Schoenfeld test on the Cox outcome model"), tableOutput("ph_tab"),
           p(class = "text-muted small",
             "A small p for the treatment term or GLOBAL means one hazard ratio misdescribes the effect over time; see HR(t) on the Results page.")))
  ),

  nav_panel(title = tagList(tags$b("3"), "Methods & run"), value = "3 · Methods & run",
    layout_columns(col_widths = c(7, 5),
      card(
        card_header("Estimators (grouped by robustness class)"),
        method_checkboxes(),
        div(class = "d-flex gap-2 mt-3",
            actionButton("sel_fast", "Select fast methods"),
            actionButton("sel_all",  "Select all"),
            actionButton("sel_none", "Clear")),
        p(class = "text-muted small mt-2",
          "Discrete-time methods bin time; their cost grows with the number of intervals. ",
          "A result already in the cache for these settings is returned at once."),
        hr(),
        actionButton("run", "Run on current cohort", class = "btn-primary"),
        uiOutput("run_note"),
        DTOutput("registry_tab")
      ),
      card(
        card_header("Settings"),
        textInput("report_times", "Report RD / RMST at times (analysis units)", DASH_CFG$report_times),
        numericInput("chr_time", "Cumulative hazard ratio at time", DASH_CFG$chr_time, min = 0),
        numericInput("interval", "Interval width for discrete-time methods", DEFAULT_SETTINGS$interval, min = 0),
        numericInput("time_df", "Time spline df (pooled models)", DEFAULT_SETTINGS$time_df, min = 1, step = 1),
        radioButtons("tmle_grid", "TMLE time grid",
                     c("Fixed width" = "fixed", "Event-driven (can be very fine; capped at 100 bins)" = "event"),
                     selected = DEFAULT_SETTINGS$tmle_grid),
        numericInput("tmle_width", "TMLE interval width (fixed grid)", DEFAULT_SETTINGS$tmle_width, min = 0),
        sliderInput("ps_bounds", "PS trimming bound b (scores kept within [b, 1 - b])",
                    min = 0, max = 0.2, value = DEFAULT_SETTINGS$ps_bounds, step = 0.005),
        checkboxInput("stabilize", "Stabilised IPT weights", DEFAULT_SETTINGS$stabilize),
        checkboxInput("use_w", "Use the cohort's own weights column (when mapped) instead of a fitted PS", DEFAULT_SETTINGS$use_provided_weights),
        textInput("extra_ps",  "Extra PS terms (optional)", value = DEFAULT_SETTINGS$extra_ps, placeholder = "e.g. I(age^2) + age:ecog"),
        textInput("extra_out", "Extra outcome-model terms (optional)", value = DEFAULT_SETTINGS$extra_out),
        numericInput("boot_B", "Bootstrap replicates for CIs (0 = off)", DEFAULT_SETTINGS$boot_B, min = 0, step = 10),
        p(class = "text-muted small",
          "Intervals: analytic (influence curve) where a method supplies its influence curve; ",
          "bootstrap for every method when B > 0, at (B + 1) times the run time."),
        numericInput("seed", "Seed", DEFAULT_SETTINGS$seed, step = 1)
      )
    )
  ),

  nav_panel(title = tagList(tags$b("4"), "Results"), value = "4 · Results",
    layout_columns(col_widths = c(4, 5, 3),
      div(selectInput("res_cohort", "Data set", choices = NULL), p(class = "text-muted small", textOutput("res_note", inline = TRUE))),
      radioButtons("res_estimand", "Estimand", choices = ESTIMAND_CHOICES, inline = TRUE),
      div(class = "pt-4", downloadButton("dl_est", "Estimates CSV"), downloadButton("dl_curves", "Curves CSV"))),
    card(card_header("Forest plot"), plotlyOutput("forest", height = "auto")),
    navset_card_tab(
      nav_panel("Estimates table", DTOutput("est_tab")),
      nav_panel("Marginal survival curves", plotlyOutput("curves_plot", height = "520px"),
                tableOutput("res_risk"), p(class = "text-muted small", "Numbers at risk by arm (unadjusted).")),
      nav_panel("Effect over time",
                radioButtons("eff_kind", NULL, c("Survival difference S1 - S0" = "rd", "RMST difference by horizon" = "rmst"), inline = TRUE),
                plotlyOutput("effect_plot", height = "520px"),
                p(class = "text-muted small", textOutput("effect_note", inline = TRUE))),
      nav_panel("Marginal HR(t)",
                radioButtons("hrt_kind", NULL, c("HR(t)" = "hr", "Cumulative HR(t)" = "chr"), inline = TRUE),
                plotlyOutput("hrt_plot", height = "520px")),
      nav_panel("Agreement across methods", DTOutput("agree_tab"),
                p(class = "text-muted small mt-2",
                  "Spread of the point estimates across the methods that ran, which method sits at each end, ",
                  "and whether every method is on the same side of the null.")),
      nav_panel("Robustness: E-values", plotlyOutput("evalue_plot", height = "auto"), DTOutput("evalue_tab"),
                p(class = "text-muted small mt-2",
                  "The E-value is the minimum strength of association, on the risk-ratio scale, that an unmeasured confounder ",
                  "would need with both treatment and outcome to explain the estimate away; the open point is the same for the ",
                  "confidence limit nearest the null (1 when the interval covers the null). Risk ratio of the event by the CHR time, ",
                  "read off the marginal curves.")),
      nav_panel("Run time & status", plotlyOutput("runtime_plot", height = "auto"), DTOutput("status_tab"))
    )
  ),

  nav_panel(title = tagList(tags$b("5"), "Compare cohorts"), value = "5 · Compare cohorts",
    layout_columns(col_widths = c(3, 2, 4, 3),
      radioButtons("cmp_estimand", "Estimand", choices = ESTIMAND_CHOICES),
      selectInput("cmp_time", "Time", choices = DEFAULT_SETTINGS$report_times),
      selectizeInput("cmp_methods", "Methods", choices = NULL, multiple = TRUE),
      selectizeInput("cmp_cohorts", "Cohorts", choices = NULL, multiple = TRUE)),
    div(class = "mb-3", actionButton("cmp_run", "Run missing cohort x method combinations", class = "btn-primary"),
        span(class = "ms-3 text-muted small", textOutput("cmp_note", inline = TRUE))),
    card(card_header("Estimate by cohort, one panel per method"), plotlyOutput("cmp_plot", height = "auto")),
    navset_card_tab(
      nav_panel("Specification curve", plotlyOutput("spec_plot", height = "auto"),
                p(class = "text-muted small mt-2",
                  "Every cohort x method estimate sorted by size, with the strip underneath marking which method and which cohort ",
                  "each one is. A flat curve on one side of the null is a robust finding; a step says where the choice matters.")),
      nav_panel("Heatmap (cohorts x methods)", plotlyOutput("cmp_heat", height = "auto")),
      nav_panel("Table (rows = cohorts, columns = methods)", DTOutput("cmp_tab")),
      nav_panel("Cohort sizes", plotlyOutput("sizes_plot", height = "auto"),
                p(class = "text-muted small mt-2", "Patients after exclusions in each selected cohort, largest first."))
    )
  ),

  nav_panel("About",
    card(card_header("What this is"),
      p("Marginal treatment effects on a time-to-event outcome, estimated by several methods on the same cohort and compared. ",
        "Every method returns two marginal survival curves; the survival difference (RD), the RMST difference, the cumulative ",
        "hazard ratio (CHR) and HR(t) are derived from those curves identically for every method."),
      p(strong("Data source: "), textOutput("about_source", inline = TRUE)),
      p(strong("Results cache: "), textOutput("about_cache", inline = TRUE)),
      p(strong("Intervals: "), "analytic from a method's influence curves where it supplies them (the doubly robust methods do); ",
        "percentile bootstrap for any method when replicates are requested."),
      p(strong("Adding a cohort: "), "drop a file matching ", code(DASH_CFG$file_pattern), " into the data folder, or add a row to ",
        code("cohorts.csv"), " (label, description and a fixed column mapping). Restart the App."),
      p(strong("Adding a method: "), "put a script in ", code("methods/"), " (an adapter) or ", code("src/"), " (", textOutput("about_srcdir", inline = TRUE), ") that defines ",
        code("estimate_curves(d, xvars, settings, grid)"), " returning data.frame(time, s1, s0); it is picked up at startup and shown ",
        "with its file name. Remove the script and the method is gone. ", code("docs/src_method_template.R"), " is a script to copy.")),
    card(card_header("Registered methods"), DTOutput("about_methods")),
    card(card_header("Scripts found in methods/ and src/"), tableOutput("about_src"),
         p(class = "text-muted small", "Every R script in the folder and what became of it: registered as a method, not a dashboard method (no estimate_curves function, so it was not run), or the error it raised.")),
    card(card_header("Cohorts found"), DTOutput("about_cohorts")),
    card(card_header("Environment"), tableOutput("about_env"))
  )
)

# ---- server ------------------------------------------------------------------------

server <- function(input, output, session) {

  STORE <- new_cohort_store()          # this session's uploads; never shared
  REG   <- reactiveVal(COHORTS)        # cohort registry (uploads add rows for this session)
  SPECS <- reactiveValues()            # cohort id -> column mapping in force
  RES   <- reactiveVal(list())         # cohort id -> list(method id -> result)

  pick <- function(x) if (is.null(x) || !nzchar(x)) "" else x
  unit <- reactive({ u <- trimws(input$time_unit %||% ""); if (nzchar(u)) u else "analysis units" })
  notify_error <- function(e, prefix = "") showNotification(paste0(prefix, conditionMessage(e)), type = "error", duration = 10)

  # ---- cohorts and mapping ---------------------------------------------------------
  observeEvent(input$upload, {
    req(input$upload)
    reg <- tryCatch(upload_cohort(REG(), input$upload$datapath, input$upload$name, STORE,
                                  known_synthetic = SYNTHETIC_MD5S, allow_synthetic = DASH_CFG$allow_synthetic),
                    error = function(e) { notify_error(e, "Upload not usable: "); NULL })
    req(reg)
    REG(reg)
    updateSelectInput(session, "cohort", choices = cohort_choices(reg), selected = reg$id[nrow(reg)])
  })

  raw <- reactive({
    req(input$cohort)
    tryCatch(load_cohort(REG(), input$cohort, STORE), error = function(e) { notify_error(e); NULL })
  })

  spec <- reactive({
    req(input$cohort); df <- raw(); req(df)
    if (is.null(SPECS[[input$cohort]])) {
      sp <- tryCatch(cohort_spec(REG(), input$cohort, df, STORE), error = function(e) { notify_error(e); NULL })
      req(sp)
      SPECS[[input$cohort]] <- sp
    }
    SPECS[[input$cohort]]
  })

  # the mapping controls follow the cohort; they only take effect on Apply
  observeEvent(list(input$cohort, raw()), {
    df <- raw(); req(df); sp <- spec()
    cols <- names(df); opt <- c("(none)" = "", cols)
    updateSelectInput(session, "map_time",    choices = cols, selected = sp$time)
    updateSelectInput(session, "map_event",   choices = cols, selected = sp$event)
    updateSelectInput(session, "map_trt",     choices = cols, selected = sp$trt)
    updateSelectInput(session, "map_id",      choices = opt,  selected = sp$id)
    updateSelectInput(session, "map_weights", choices = opt,  selected = sp$weights)
    updateSelectInput(session, "map_label",   choices = opt,  selected = sp$label_col)
    updateSelectInput(session, "map_start",   choices = opt,  selected = sp$start_col %||% "")
    updateSelectInput(session, "map_censor",  choices = opt,  selected = sp$censor_col %||% "")
    updateCheckboxInput(session, "map_event_from_time", value = isTRUE(sp$event_from_time))
    updateSelectizeInput(session, "map_covs", choices = cols, selected = sp$covariates)
    updateCheckboxInput(session, "map_missing_level", value = isTRUE(sp$missing_as_level))
  })

  output$cov_note <- renderText({
    left <- attr(spec(), "left_out")
    if (!length(left)) "" else paste0("Not guessed, pick by hand if wanted: ", paste(sprintf("%s (%s)", names(left), left), collapse = ", "))
  })

  output$map_treated_ui <- renderUI({
    df <- raw(); req(df, input$map_trt, input$map_trt %in% names(df))
    tv <- treatment_values(df[[input$map_trt]])
    if (length(tv) != 2)
      return(p(class = "text-danger small", sprintf("'%s' has %d distinct value(s); the treatment column must have exactly two.",
                                                   input$map_trt, length(tv))))
    cur <- as.character(spec()$treated_value)
    selectInput("map_treated", "Value meaning treated (the other value is control)", choices = tv,
                selected = if (cur %in% tv) cur else guess_treated_value(df[[input$map_trt]]))
  })

  observeEvent(input$apply_map, {
    df <- raw(); req(df)
    sp <- spec()
    sp$time <- pick(input$map_time); sp$event <- pick(input$map_event); sp$trt <- pick(input$map_trt)
    sp$id <- pick(input$map_id); sp$weights <- pick(input$map_weights); sp$label_col <- pick(input$map_label)
    sp$start_col <- pick(input$map_start); sp$censor_col <- pick(input$map_censor)
    sp$event_from_time <- isTRUE(input$map_event_from_time)
    sp$covariates <- setdiff(input$map_covs %||% character(), spec_roles(sp))
    sp$missing_as_level <- isTRUE(input$map_missing_level)
    sp$treated_value <- if (!is.null(input$map_treated) && nzchar(input$map_treated)) input$map_treated
                        else if (nzchar(sp$trt) && sp$trt %in% names(df)) guess_treated_value(df[[sp$trt]]) else "1"
    pr <- spec_problems(df, sp)
    if (length(pr)) { showNotification(paste(pr, collapse = "; "), type = "error", duration = 10); return() }
    SPECS[[input$cohort]] <- sp
    showNotification("Mapping applied.", type = "message", duration = 3)
  })

  prep_for <- function(id) {
    reg <- REG(); sp <- SPECS[[id]]
    if (is.null(sp)) { sp <- cohort_spec(reg, id, store = STORE); SPECS[[id]] <- sp }
    prep_cohort(reg, id, sp, input$time_divisor %||% DASH_CFG$time_divisor, STORE)
  }

  # the mapping's identity for a cohort, as the results cache keys it; NA when the cohort cannot be read
  current_hash <- function(id) tryCatch({
    sp <- SPECS[[id]] %||% cohort_spec(REG(), id, store = STORE)
    cohort_data_hash(REG(), id, sp, STORE)
  }, error = function(e) NA_character_)

  prep_result <- reactive({
    req(input$cohort); sp <- spec(); req(sp)
    div <- input$time_divisor
    if (is.null(div) || !is.finite(div) || div <= 0) return(list(error = "Time divisor must be a positive number."))
    tryCatch(list(d = prep_for(input$cohort)), error = function(e) list(error = conditionMessage(e)))
  })
  prepped <- reactive({ pr <- prep_result(); validate(need(is.null(pr$error), pr$error)); pr$d })
  summ <- reactive({ pr <- prep_result(); if (is.null(pr$error)) data_summary(pr$d) else NULL })

  output$cohort_desc <- renderUI({
    reg <- REG()
    if (!nrow(reg))
      return(div(class = "alert alert-warning",
                 sprintf("No cohort found from source '%s' (%s). Add files matching %s to the data folder, or rows to cohorts.csv, and restart.",
                         PROVENANCE$source, PROVENANCE$origin, DASH_CFG$file_pattern)))
    req(input$cohort); row <- reg[match(input$cohort, reg$id), ]
    if (isTRUE(row$missing_file))
      return(div(class = "alert alert-danger", sprintf("The file registered for '%s' is missing: %s", row$label, row$file)))
    sm <- summ()
    div(class = "mb-2",
        h5(cohort_display(reg)[[input$cohort]]),
        if (nzchar(row$description)) p(class = "text-muted", row$description),
        p(class = "text-muted small",
          if (is.na(row$file)) "Source: synthetic (in-process)" else paste("File:", row$file),
          " · provenance: ", row$provenance %||% "",
          " · adjusting for: ", if (is.null(sm)) "(see the mapping problem below)" else paste(unname(sm$xvar_labels), collapse = ", ")))
  })

  output$data_check <- renderUI({
    req(input$cohort); pr <- prep_result()
    if (!is.null(pr$error))
      return(div(class = "alert alert-danger py-2 small", strong("This cohort cannot be used as mapped: "), pr$error))
    sm <- data_summary(pr$d); items <- list()
    if (length(sm$drop_reasons))
      items <- c(items, list(tags$li(sprintf("Rows dropped: %d (%s).", sm$n_dropped,
                                             paste(names(sm$drop_reasons), sm$drop_reasons, collapse = ", ")),
                                     if (length(sm$covariate_missing))
                                       sprintf(" Missing by covariate: %s.", paste(names(sm$covariate_missing), sm$covariate_missing, collapse = ", ")))))
    if (isTRUE(sm$event_from_time))
      items <- c(items, list(tags$li("The event is read as 'a duration is recorded'; the file's event column is not used.")))
    if (length(sm$censor_note))
      items <- c(items, list(tags$li(sm$censor_note)))
    if (length(sm$missing_as_level))
      items <- c(items, list(tags$li("Blank kept as the category 'missing' (rows): ",
                                     paste(sprintf("%s %d", names(sm$missing_as_level), sm$missing_as_level), collapse = ", "))))
    if (length(sm$renamed))
      items <- c(items, list(tags$li("Renamed for modelling (use these names in extra terms): ",
                                     paste(sprintf("'%s' as %s", unname(sm$renamed), names(sm$renamed)), collapse = ", "))))
    if (length(sm$constant_dropped))
      items <- c(items, list(tags$li("Constant in this cohort, so not adjusted for: ", paste(sm$constant_dropped, collapse = ", "))))
    if (!length(items)) return(NULL)
    div(class = "alert alert-light border py-2 small", tags$ul(class = "mb-0", items))
  })
  vb <- function(f) renderText({ sm <- summ(); if (is.null(sm)) "–" else f(sm) })
  output$vb_n       <- vb(function(sm) format(sm$n, big.mark = ","))
  output$vb_events  <- vb(function(sm) format(sm$events, big.mark = ","))
  output$vb_treated <- vb(function(sm) format(sm$n_treated, big.mark = ","))
  output$vb_control <- vb(function(sm) format(sm$n_control, big.mark = ","))
  output$vb_treated_arm <- vb(function(sm) sm$arm_labels[["treated"]])
  output$vb_control_arm <- vb(function(sm) sm$arm_labels[["control"]])
  output$vb_fu      <- vb(function(sm) sprintf("%.1f %s", sm$median_followup, unit()))
  output$vb_dropped <- vb(function(sm) format(sm$n_dropped, big.mark = ","))

  # client-side: the first 200 rows travel with the page, so no server-side
  # request can trip over an odd header
  output$preview <- renderDT({
    df <- raw(); req(df)
    datatable(utils::head(df, 200), rownames = FALSE, options = list(scrollX = TRUE, pageLength = 8, dom = "tip"))
  }, server = FALSE)

  # ---- settings ---------------------------------------------------------------------
  num_or <- function(x, default) { v <- suppressWarnings(as.numeric(x %||% NA)); if (length(v) == 1 && is.finite(v)) v else default }
  settings <- reactive({
    s <- DEFAULT_SETTINGS
    s$report_times <- parse_times(input$report_times %||% DASH_CFG$report_times)
    s$chr_time     <- num_or(input$chr_time, NA_real_)
    s$time_divisor <- num_or(input$time_divisor, NA_real_)
    s$time_unit    <- unit()
    s$interval     <- num_or(input$interval, NA_real_)
    s$time_df      <- num_or(input$time_df, NA_real_)
    s$tmle_grid    <- input$tmle_grid %||% s$tmle_grid
    s$tmle_width   <- num_or(input$tmle_width, NA_real_)
    s$ps_bounds    <- num_or(input$ps_bounds, s$ps_bounds)
    s$stabilize    <- isTRUE(input$stabilize)
    s$use_provided_weights <- isTRUE(input$use_w)
    s$extra_ps     <- trimws(input$extra_ps %||% "")
    s$extra_out    <- trimws(input$extra_out %||% "")
    s$boot_B       <- max(0, as.integer(num_or(input$boot_B, 0)))
    s$seed         <- as.integer(num_or(input$seed, s$seed))
    s
  })

  selected_methods <- reactive(unlist(lapply(unname(CLASS_INPUT), function(id) input[[id]])))

  set_selection <- function(ids) {
    tab <- methods_table()
    for (cl in method_classes())
      updateCheckboxGroupInput(session, CLASS_INPUT[[cl]], selected = intersect(ids, tab$id[tab$class == cl]))
  }
  observeEvent(input$sel_fast, set_selection(fast_method_ids()))
  observeEvent(input$sel_all,  set_selection(available_method_ids()))
  observeEvent(input$sel_none, set_selection(character(0)))

  output$registry_tab <- renderDT({
    t <- methods_table()[, c("label", "file", "class", "speed", "uses", "note")]
    datatable(t, rownames = FALSE, options = list(dom = "t", pageLength = 50),
              caption = "Each method, the script it lives in, and the settings it reads")
  })

  # ---- diagnostics ------------------------------------------------------------------
  output$km_plot <- renderPlotly({
    d <- prepped(); pl(plot_km(km_unadjusted(d), attr(d, "arm_labels"), unit()))
  })
  output$km_risk <- renderTable({ d <- prepped(); risk_strip(d, max(d$time), arm_labels = attr(d, "arm_labels")) }, digits = 0)
  with_covs <- function() { d <- prepped(); validate(need(length(attr(d, "xvars")) > 0, "No covariates mapped.")); d }
  output$ps_plot <- renderPlotly({
    d <- with_covs()
    pl(plot_ps_mirror(ps_overlap_bins(d, attr(d, "xvars"), settings()), attr(d, "arm_labels")), tooltip = "text")
  })
  balance <- reactive({ d <- with_covs(); balance_table(d, attr(d, "xvars"), settings()) })
  output$love_plot   <- renderPlotly(pl(plot_love(balance()), tooltip = "text"))
  output$match_note  <- renderText({
    m <- attr(balance(), "matching")
    sprintf("Matched 1:1 on the logit propensity score, nearest neighbour without replacement, caliper %.3f: %d pairs from %d treated (%d unmatched) and %d control.",
            m$caliper, m$n_pairs, m$n_treated, m$n_unmatched, m$n_control)
  })
  output$balance_tab <- renderDT(datatable(balance(), rownames = FALSE, options = list(dom = "t", pageLength = 50)) |>
                                   formatRound(c("smd_unweighted", "smd_weighted", "smd_matched"), 3))
  output$weight_tab  <- renderTable({ d <- prepped(); weight_summary(d, attr(d, "xvars"), settings()) }, digits = 2)
  output$weights_plot <- renderPlotly({
    d <- with_covs(); s <- settings()
    pl(plot_weights(weight_data(d, attr(d, "xvars"), s), weight_summary(d, attr(d, "xvars"), s), attr(d, "arm_labels")))
  })
  output$ecdf_plot <- renderPlotly({
    d <- with_covs(); e <- ecdf_table(d, attr(d, "xvars"), settings())
    validate(need(nrow(e) > 0, "No continuous covariate (more than ten distinct values) among the covariates."))
    pl(plot_ecdf(e, attr(d, "arm_labels")), height = 140 + 230 * length(unique(e$covariate)))
  })
  het <- reactive({ d <- with_covs(); heterogeneity_data(d, attr(d, "xvars"), settings()) })
  output$het_plot <- renderPlotly({
    hd <- het(); validate(need(!is.null(hd$smooth), "Too few patients with a known status at the CHR time to smooth."))
    pl(plot_heterogeneity(hd, attr(prepped(), "arm_labels"), unit()), tooltip = "text")
  })
  output$het_note <- renderText({
    hd <- het()
    sprintf(paste("Descriptive, complete-case: alive after %s %s against the propensity score, by arm, with a local-regression smooth and its band.",
                  "%s patient(s) censored before that time are left out, so a gap between the arms can reflect censoring as well as effect;",
                  "read it as where the arms differ across the covariate space, not as an estimate."),
            format(hd$t), unit(), format(hd$n_unknown, big.mark = ","))
  })
  output$cens_tab    <- renderTable(censoring_summary(prepped()), digits = 1)
  output$risk_tab    <- renderTable({
    r <- risk_table(prepped(), settings()$report_times)
    validate(need(nrow(r) > 0, "No report times."))
    data.frame(arm = r$arm, time = paste(r$time, unit()), at_risk = as.integer(r$at_risk),
               events_in_interval = as.integer(r$events_in_interval), surv = sprintf("%.3f", r$surv))
  })
  output$ph_tab <- renderTable({
    d <- prepped(); validate(need(length(attr(d, "xvars")) > 0, "No covariates mapped."))
    p <- ph_check(d, attr(d, "xvars"), settings()); validate(need(nrow(p) > 0, "Test not available."))
    p$df <- as.integer(round(p$df)); p
  }, digits = 3)

  # ---- results store and the cache ----------------------------------------------------
  store_results <- function(id, res) {
    all <- RES(); cur <- all[[id]] %||% list()
    for (k in names(res)) cur[[k]] <- res[[k]]
    all[[id]] <- cur; RES(all)
  }
  refresh_result_cohorts <- function(selected = NULL) {
    reg <- REG(); have <- reg[reg$id %in% names(RES()), , drop = FALSE]
    cur <- isolate(input$res_cohort)
    updateSelectInput(session, "res_cohort", choices = cohort_choices(have),
                      selected = if (!is.null(selected) && selected %in% have$id) selected
                                 else if (!is.null(cur) && cur %in% have$id) cur else have$id[1])
  }

  # what a precompute Job (or an earlier session) left in the cache for the
  # settings this session starts with, loaded once so the pages are not empty.
  # A cohort that cannot be read is skipped, never fatal.
  observeEvent(TRUE, {
    if (!nzchar(cache_dir())) return()
    s <- settings(); reg <- REG(); all <- list(); n_hit <- 0L
    for (cid in reg$id) {
      hash <- tryCatch({
        sp <- SPECS[[cid]]
        if (is.null(sp)) { sp <- cohort_spec(reg, cid, store = STORE); SPECS[[cid]] <- sp }
        cohort_data_hash(reg, cid, sp, STORE)
      }, error = function(e) NULL)
      if (is.null(hash)) next
      for (mid in available_method_ids()) {
        r <- tryCatch(cache_get(cache_key(cid, hash, mid, s, METHODS[[mid]]$code_hash %||% "")), error = function(e) NULL)
        if (!is.null(r) && isTRUE(r$ok)) {
          r$from_cache <- TRUE; r$stored <- TRUE
          if (is.null(all[[cid]])) all[[cid]] <- list()
          all[[cid]][[mid]] <- r; n_hit <- n_hit + 1L
        }
      }
    }
    if (n_hit > 0L) {
      RES(all); refresh_result_cohorts(names(all)[1])
      showNotification(sprintf("%d cached result(s) loaded for the current settings.", n_hit), type = "message", duration = 6)
    }
  }, once = TRUE)

  # ---- run ------------------------------------------------------------------------------
  run_note <- reactiveVal("")
  output$run_note <- renderUI(p(class = "text-muted small mt-2", run_note()))

  observeEvent(input$run, {
    ids <- selected_methods()
    if (!length(ids)) { showNotification("Select at least one method.", type = "warning"); return() }
    s <- settings()
    d <- tryCatch(prep_for(input$cohort), error = function(e) { notify_error(e, "Cannot prepare this cohort: "); NULL })
    req(d)
    pr <- settings_problems(s, attr(d, "xvars"))
    if (!length(pr)) pr <- terms_problems(d, attr(d, "xvars"), s)
    if (length(pr)) { showNotification(paste(pr, collapse = "; "), type = "error", duration = 12); return() }
    res <- withProgress(message = "Running", value = 0, {
      run_methods(ids, d, s, progress = function(i, n, lab) incProgress(1 / n, detail = lab))
    })
    store_results(input$cohort, res)
    st <- results_status(res)
    for (i in which(st$status == "failed"))
      showNotification(sprintf("%s failed: %s", st$method[i], st$message[i]), type = "error", duration = NULL)
    for (i in which(st$status == "incomplete"))
      showNotification(sprintf("%s is incomplete and shown without intervals: %s", st$method[i], st$message[i]), type = "warning", duration = NULL)
    if (any(st$status == "ok" & st$stored %in% FALSE))
      showNotification("The results cache could not be written; results are kept for this session only.", type = "warning", duration = 10)
    run_note(sprintf("Last run: %d method(s) on '%s', %.1f s computing, %d from the cache, %d failed.",
                     nrow(st), input$cohort, sum(st$seconds[!st$cached]), sum(st$cached), sum(st$status == "failed")))
    refresh_result_cohorts(input$cohort)
    nav_select("nav", "4 · Results")
  })

  # ---- results: only the CURRENT analysis is shown -------------------------------------
  current_all <- reactive({
    all <- RES(); s <- settings()
    stats::setNames(lapply(names(all), function(cid) current_results(all[[cid]], s, current_hash(cid))), names(all))
  })
  res_all <- reactive({ req(input$res_cohort); RES()[[input$res_cohort]] })
  res_cur <- reactive({
    all <- res_all()
    validate(need(length(all) > 0, "No results yet for this cohort. Run methods on the Methods & run page."))
    cur <- current_all()[[input$res_cohort]]
    validate(need(length(cur) > 0,
                  sprintf("%d result(s) exist for this cohort, but under other settings or another column mapping. Re-run on the Methods & run page to see them under the current ones.", length(all))))
    cur
  })
  output$res_note <- renderText({
    all <- res_all(); if (!length(all)) return("")
    n_stale <- length(all) - length(current_all()[[input$res_cohort]])
    if (n_stale > 0) sprintf("%d result(s) computed under other settings or another mapping are not shown.", n_stale)
    else "Results of the current settings and mapping."
  })
  est_cur    <- reactive(results_estimates(res_cur(), input$res_cohort))
  status_cur <- reactive(results_status(res_cur(), input$res_cohort))
  arm_labels_cur <- reactive(tryCatch(attr(prep_for(input$res_cohort), "arm_labels"), error = function(e) DEFAULT_ARMS))

  output$forest <- renderPlotly({
    e <- est_cur(); validate(need(nrow(e) > 0, "Every method failed; see Run time & status."))
    p <- plot_forest(e, input$res_estimand, unit = unit()); req(p)
    pl(p, tooltip = "text", height = 160 + 36 * length(unique(e$method)))
  })
  output$est_tab <- renderDT({
    e <- est_cur(); validate(need(nrow(e) > 0, "No estimates."))
    e$estimand <- unname(ESTIMAND_LABELS[e$estimand])
    datatable(e[, c("method", "class", "status", "estimand", "time", "within_followup", "est", "se", "lower", "upper", "ci_type", "boot_ok")],
              rownames = FALSE, options = list(pageLength = 25, dom = "tip")) |>
      formatRound(c("est", "se", "lower", "upper"), 4)
  })
  output$curves_plot <- renderPlotly({
    cv <- results_curves(res_cur(), input$res_cohort); validate(need(nrow(cv) > 0, "No curves."))
    pl(plot_curves(cv, arm_labels_cur(), unit()))
  })
  output$res_risk <- renderTable({
    cv <- results_curves(res_cur(), input$res_cohort); validate(need(nrow(cv) > 0, ""))
    d <- tryCatch(prep_for(input$res_cohort), error = function(e) NULL); validate(need(!is.null(d), "Cohort not available."))
    risk_strip(d, max(cv$time), arm_labels = attr(d, "arm_labels"))
  }, digits = 0)
  output$effect_plot <- renderPlotly({
    eff <- results_effect(res_cur(), input$res_cohort); validate(need(nrow(eff) > 0, "No curves."))
    pl(plot_effect(eff, input$eff_kind, unit()), tooltip = "text")
  })
  output$effect_note <- renderText({
    eff <- results_effect(res_cur(), input$res_cohort); if (!nrow(eff)) return("")
    types <- unique(stats::na.omit(eff$ci_type))
    if (length(types)) sprintf("Shaded: pointwise 95%% band (%s). A method without one shows its curve alone.", paste(types, collapse = ", "))
    else "No bands: no method supplied influence curves and no bootstrap was requested."
  })
  output$evalue_plot <- renderPlotly({
    ev <- results_evalue(res_cur(), input$res_cohort); validate(need(nrow(ev) > 0 && any(is.finite(ev$evalue)), "No E-values."))
    pl(plot_evalue(ev), tooltip = "text", height = 140 + 36 * length(unique(ev$method)))
  })
  output$evalue_tab <- renderDT({
    ev <- results_evalue(res_cur(), input$res_cohort); validate(need(nrow(ev) > 0, "No E-values."))
    datatable(ev[, c("method", "class", "time", "risk_treated", "risk_control", "rr", "rr_lower", "rr_upper", "evalue", "evalue_ci", "ci_type")],
              rownames = FALSE, options = list(dom = "t", pageLength = 50, scrollX = TRUE)) |>
      formatRound(c("risk_treated", "risk_control", "rr", "rr_lower", "rr_upper", "evalue", "evalue_ci"), 3)
  })
  output$hrt_plot <- renderPlotly({
    h <- results_hrt(res_cur(), input$res_cohort); validate(need(nrow(h) > 0, "No curves."))
    p <- plot_hrt(h, input$hrt_kind, unit()); req(p); pl(p)
  })
  output$agree_tab <- renderDT({
    a <- agreement_table(est_cur()); validate(need(nrow(a) > 0, "No estimates."))
    a$estimand <- unname(ESTIMAND_LABELS[a$estimand])
    datatable(a, rownames = FALSE, options = list(dom = "t", pageLength = 50)) |>
      formatRound(c("median", "min", "max", "range"), 4)
  })
  output$runtime_plot <- renderPlotly({
    st <- status_cur(); p <- plot_runtime(st); req(p)
    pl(p, tooltip = "text", height = 120 + 36 * nrow(st))
  })
  output$status_tab <- renderDT(datatable(
    status_cur()[, c("method", "class", "status", "cached", "stored", "seconds", "n", "n_events", "boot_B", "computed_at", "message", "notes")],
    rownames = FALSE, options = list(dom = "t", pageLength = 50, scrollX = TRUE)))

  # exports carry what reproduces them: cohort id and data hash, mapping, unit,
  # method id and script, code hash, settings, status
  all_estimates <- reactive({
    reg <- REG(); ca <- current_all(); s <- settings()
    .bind(lapply(names(ca), function(id) {
      e <- results_estimates(ca[[id]], cohort_display(reg)[[id]])
      if (nrow(e)) {
        e$mapping   <- paste(deparse(SPECS[[id]] %||% list()), collapse = "")
        e$time_unit <- s$time_unit
        e$settings  <- settings_key(s)
      }
      e
    }))
  })
  output$dl_est <- downloadHandler(
    filename = function() sprintf("estimates_%s.csv", format(Sys.time(), "%Y%m%d_%H%M")),
    content  = function(f) utils::write.csv(all_estimates(), f, row.names = FALSE))
  output$dl_curves <- downloadHandler(
    filename = function() sprintf("curves_%s.csv", format(Sys.time(), "%Y%m%d_%H%M")),
    content  = function(f) {
      reg <- REG(); ca <- current_all(); s <- settings()
      utils::write.csv(.bind(lapply(names(ca), function(id) {
        e <- results_curves(ca[[id]], cohort_display(reg)[[id]])
        if (nrow(e)) {
          e$mapping   <- paste(deparse(SPECS[[id]] %||% list()), collapse = "")
          e$time_unit <- s$time_unit
          e$settings  <- settings_key(s)
        }
        e
      })), f, row.names = FALSE)
    })

  # ---- compare cohorts ------------------------------------------------------------------
  observe({
    updateSelectizeInput(session, "cmp_methods", choices = method_labels(), selected = isolate(input$cmp_methods) %||% fast_method_ids())
    updateSelectizeInput(session, "cmp_cohorts", choices = cohort_choices(REG()), selected = isolate(input$cmp_cohorts) %||% REG()$id)
  })
  observe({
    s <- settings()
    times <- if (identical(input$cmp_estimand, "CHR")) s$chr_time else s$report_times
    times <- times[is.finite(times)]
    cur <- isolate(input$cmp_time)
    keep <- !is.null(cur) && length(cur) == 1 && nzchar(cur) && suppressWarnings(as.numeric(cur)) %in% times
    updateSelectInput(session, "cmp_time", choices = times,
                      selected = if (isTRUE(keep)) cur else if (length(times)) times[1] else character(0))
  })

  # a combination is pending unless it has an OK result of the current analysis
  cmp_pending <- reactive(pending_combinations(RES(), input$cmp_cohorts %||% character(),
                                               input$cmp_methods %||% character(), settings(), current_hash))
  output$cmp_note <- renderText({
    n <- length(cmp_pending())
    if (n == 0) "Every selected combination has a result under the current settings and mapping."
    else sprintf("%d combination(s) still to run under the current settings and mapping (cached ones return at once).", n)
  })

  observeEvent(input$cmp_run, {
    todo <- cmp_pending()
    if (!length(todo)) { showNotification("Nothing to run.", type = "message"); return() }
    s <- settings(); pr <- settings_problems(s)
    if (length(pr)) { showNotification(paste(pr, collapse = "; "), type = "error", duration = 10); return() }
    withProgress(message = "Running cohorts", value = 0, {
      cohorts <- unique(vapply(todo, `[[`, character(1), 1))
      for (cid in cohorts) {
        mids <- vapply(Filter(function(x) x[1] == cid, todo), `[[`, character(1), 2)
        d <- tryCatch(prep_for(cid), error = function(e) { notify_error(e, paste0(cid, ": ")); NULL })
        if (is.null(d)) next
        res <- run_methods(mids, d, s, progress = function(i, n, lab) incProgress(1 / length(todo), detail = paste(cid, "-", lab)))
        store_results(cid, res)
        st <- results_status(res, cid)
        for (i in which(st$status == "failed"))
          showNotification(sprintf("%s / %s failed: %s", cid, st$method[i], st$message[i]), type = "error", duration = NULL)
        for (i in which(st$status == "incomplete"))
          showNotification(sprintf("%s / %s is incomplete and shown without intervals: %s", cid, st$method[i], st$message[i]), type = "warning", duration = NULL)
      }
    })
    refresh_result_cohorts()
  })

  cmp_est <- reactive({
    reg <- REG(); ca <- current_all()
    .bind(lapply(input$cmp_cohorts %||% character(), function(cid) {
      r <- ca[[cid]]; r <- r[names(r) %in% (input$cmp_methods %||% character())]
      results_estimates(r, cohort_display(reg)[[cid]])
    }))
  })
  cmp_time_num <- reactive(suppressWarnings(as.numeric(input$cmp_time %||% NA)))
  output$cmp_plot <- renderPlotly({
    e <- cmp_est(); t <- cmp_time_num()
    validate(need(nrow(e) > 0, "No results for the selected cohorts and methods under the current settings yet. Run them above."),
             need(length(t) == 1 && is.finite(t), "Pick a time."))
    p <- plot_compare(e, input$cmp_estimand, t, unit()); req(p)
    pl(p, tooltip = "text", height = 180 + 30 * length(unique(e$cohort)) * ceiling(length(unique(e$method)) / 3))
  })
  output$spec_plot <- renderPlotly({
    e <- cmp_est(); t <- cmp_time_num()
    validate(need(nrow(e) > 0, "No results yet."), need(length(t) == 1 && is.finite(t), "Pick a time."))
    sc <- spec_curve_data(e, input$cmp_estimand, t)
    validate(need(nrow(sc) > 0, "No estimate at this time under the current settings; re-run."))
    top   <- pl(plot_spec_curve(sc, input$cmp_estimand, unit()), tooltip = "text")
    strip <- pl(plot_spec_strip(sc), tooltip = "text")
    n_rows <- length(unique(sc$method)) + length(unique(sc$cohort))
    plotly::layout(plotly::subplot(top, strip, nrows = 2, shareX = TRUE, heights = c(0.55, 0.45), titleY = TRUE, titleX = TRUE),
                   height = 340 + 22 * n_rows)
  })
  cohort_sizes <- function(ids) {
    reg <- REG()
    .bind(lapply(ids, function(cid) tryCatch({
      d <- prep_for(cid)
      data.frame(cohort = cohort_display(reg)[[cid]], n = nrow(d), events = sum(d$event), n_treated = sum(d$A == 1))
    }, error = function(e) NULL)))
  }
  output$sizes_plot <- renderPlotly({
    ids <- input$cmp_cohorts %||% character(); validate(need(length(ids) > 0, "Pick cohorts."))
    cs <- cohort_sizes(ids); validate(need(nrow(cs) > 0, "None of the selected cohorts can be prepared."))
    pl(plot_cohort_sizes(cs), tooltip = "text", height = 140 + 32 * nrow(cs))
  })
  output$cmp_heat <- renderPlotly({
    e <- cmp_est(); t <- cmp_time_num()
    validate(need(nrow(e) > 0, "No results yet."), need(length(t) == 1 && is.finite(t), "Pick a time."))
    p <- plot_heatmap(e, input$cmp_estimand, t, unit()); req(p)
    pl(p, tooltip = "text", height = 160 + 34 * length(unique(e$cohort)))
  })
  output$cmp_tab <- renderDT({
    e <- cmp_est(); t <- cmp_time_num()
    validate(need(nrow(e) > 0, "No results yet."), need(length(t) == 1 && is.finite(t), "Pick a time."))
    wide <- compare_table(e, input$cmp_estimand, t)
    validate(need(nrow(wide) > 0, "No estimate at this time under the current settings; re-run."))
    datatable(wide, rownames = FALSE, options = list(dom = "t", scrollX = TRUE, pageLength = 50))
  })

  # ---- about -----------------------------------------------------------------------------------
  output$about_source  <- renderText(sprintf("%s (%s), %d cohort(s)", PROVENANCE$source, PROVENANCE$origin, PROVENANCE$n_cohorts))
  output$about_cache   <- renderText(cache_status())
  output$about_methods <- renderDT(datatable(methods_table()[, c("label", "file", "source", "class", "speed", "available", "requires", "uses", "note")],
                                             rownames = FALSE, options = list(dom = "t", pageLength = 50, scrollX = TRUE)))
  output$about_srcdir  <- renderText(paste(METHOD_DIRS, collapse = " and "))
  output$about_src     <- renderTable({
    if (!nrow(SRC_SCAN)) data.frame(folder = "", file = "(none)", status = sprintf("no scripts found in %s", paste(METHOD_DIRS, collapse = " or ")))
    else SRC_SCAN[, c("folder", "file", "status")]
  })
  output$about_cohorts <- renderDT(datatable(REG()[, intersect(c("id", "label", "file", "provenance", "synthetic", "missing_file", "description"), names(REG()))],
                                             rownames = FALSE, options = list(dom = "t", pageLength = 50)))
  output$about_env <- renderTable(data.frame(
    item  = c("R", "shiny", "survival", "ggplot2", "code checksum", "cache", "data"),
    value = c(R.version.string, as.character(packageVersion("shiny")), as.character(packageVersion("survival")),
              as.character(packageVersion("ggplot2")), CODE_HASH, cache_status(), PROVENANCE$origin)))
}

shinyApp(ui, server)
