# DR time-to-event dashboard

An R Shiny app that runs several estimators of a marginal treatment effect on a
time-to-event outcome against the same cohort and compares them, and compares
one estimator across cohorts (the eligibility scenarios). It **reads**: it
creates, replaces and drops nothing except its own results cache.

Two things are meant to change often, and each is one file:

| to add | edit | what happens |
|---|---|---|
| **a cohort** | drop a `*_feature_table.csv` into the data folder, or add a row to `cohorts.csv` | it is discovered at startup; the row can give a label, a description and a fixed column mapping |
| **a method** | put a script that defines `estimate_curves()` in `src/` (copy `docs/src_method_template.R`) | it is discovered at startup, appears under its robustness class with its file name beside it, in the Results, the cohort comparison, the precompute Job and the tests; remove the script and it is gone |

`app.R` names no method and no cohort; `tests/run_tests.R` checks that it never does.

A `file` in `cohorts.csv` is taken as given when absolute, and otherwise
looked for beside `cohorts.csv` and then in the data folder(s), never in the
working directory. Cohorts are identified by id throughout; two cohorts with
one label are shown as `label [id]`. Every cohort carries its provenance
(generated in-process, generated file found in a `SYNTHETIC.md5` marker,
declared synthetic, file not verified, or upload not verified); an upload
whose checksum a marker lists is generated data and is refused under the
production guard. Every result has one status, `ok`, `incomplete` or
`failed`, used by the pages, the exports and the precompute Job alike.

---

## Layout

| file | purpose |
|---|---|
| `app.R` | the five pages, generated from the registries; wiring only |
| `app.sh` | Domino App launcher (0.0.0.0:8888) |
| `global.R` | loads config, the `R/` files and the cohort source once at startup; no Shiny |
| `config/dashboard_config.R` | every knob, each env-overridable (`DASH_*`) |
| `cohorts.csv` | optional cohort registry: labels, descriptions, column mappings |
| `R/methods.R` | **the method registry** and the runner (`run_method`, intervals, cache, status) |
| `methods/` | adapters that wrap the study's `src/` functions into the method contract, written where the study's files are (`docs/INTEGRATION_HANDOVER.md`); scanned like `src/` |
| `R/study_methods.R` | wraps the study's `run_*_analysis()` functions into methods automatically: arguments from their names, the two curves read from the result |
| `R/estimators.R` | reference implementations: IPTW KM / Cox, Cox and pooled-logistic standardisation, IP-weighted Cox standardisation, AIPTW, discrete-time TMLE |
| `R/estimands.R` | RD, RMST, CHR and HR(t) from a pair of marginal curves; analytic intervals from influence curves; the agreement table |
| `R/cache.R` | the results cache: one file per (cohort, data, mapping, method, settings, code) |
| `R/settings.R` | the settings list, its defaults and validation, the time grid |
| `R/sources.R` | cohort discovery (synthetic or files + `cohorts.csv`), loading, uploads, `prep_cohort()` |
| `R/spec.R` | column-mapping guess, overrides, `prep_data()` into the one shape every method takes |
| `R/synthetic.R` | the synthetic cohorts (same schema as the real files) |
| `R/diagnostics.R` | unadjusted KM, PS overlap, balance, weights, censoring, numbers at risk, Schoenfeld test |
| `R/plots.R` | the figures (ggplot2; plotly on the page) |
| `jobs/precompute.R` | the Domino Job that fills the cache for every cohort x method ahead of the App |
| `jobs/describe_src.R` | describes the study's analysis functions without copying their code (arguments, documented returns, result shapes on a synthetic cohort), for writing the adapters when the scripts cannot leave the repository |
| `tests/run_tests.R` | headless checks, no Shiny: `Rscript tests/run_tests.R` |
| `data/make_synthetic.R` | writes the synthetic cohorts to CSV (for `DASH_SOURCE=files` runs) |
| `install.R` | the packages, for the Domino compute environment |

## The pages

A banner on every page says when the cohorts are synthetic.

| page | what is on it |
|---|---|
| **1 · Data** | pick a cohort (or upload one for the session; uploads are never visible to another viewer); the column mapping - guessed from the names, confirmed with *Apply mapping*; the time divisor and unit label; what the mapping refuses and what it drops, by reason; counts, median follow-up (reverse KM); a preview |
| **2 · Diagnostics** | unadjusted Kaplan-Meier by arm with numbers at risk; propensity-score overlap as a mirrored histogram (observed filled, IPT-weighted outlined); covariate balance as standardised mean differences unweighted, IPT-weighted and after 1:1 nearest-neighbour matching on the logit propensity score (caliper 0.2 SD); the IPT weight distribution by arm with effective sample sizes; ECDF of each continuous covariate by arm, unweighted beside weighted; treatment-effect heterogeneity (alive at the CHR time against the propensity score, smoothed by arm); follow-up and censoring; numbers at risk at the report times; the Schoenfeld test |
| **3 · Methods & run** | the estimators grouped by robustness class, with *Select fast / Select all / Clear*; the settings; *Run on current cohort* |
| **4 · Results** | forest plot of the chosen estimand across methods (one panel per report time, intervals where there are any); the estimates table with standard errors and the interval type; marginal survival curves per method with numbers at risk; **effect over time** (the survival difference at every time, and the RMST difference by horizon, with pointwise bands from influence curves or the bootstrap); HR(t) and cumulative HR(t); **agreement across methods** (spread, which method sits at each end, same side of the null); **E-values** per method (risk ratio of the event by the CHR time from the curves; the point estimate's and the confidence limit's); run time and status, with what came from the cache and what was stored; CSV downloads. Only results of the **current analysis** are shown - these settings, this cohort under this mapping - and the page says how many older ones it is hiding |
| **5 · Compare cohorts** | one estimand at one time, methods x cohorts: a panel per method with cohorts down the side; the **specification curve** (every cohort x method estimate sorted by size, with a strip marking which method and cohort each is); a **heatmap** of the matrix; the table (rows = cohorts with n and events, columns = methods); the cohorts' sizes after exclusions. *Run missing combinations* computes every pair without an OK result of the current analysis (a failed run, a changed setting or a changed mapping all count as missing); cached combinations return at once |
| **About** | provenance, the cache, the registered methods, the cohorts found, the environment and code checksum |

## What a method is

```r
fn(d, xvars, s, grid) -> data.frame(time = grid, s1, s0)
```

`d` is what `prep_data()` returns: `time` (analysis units), `event` 0/1, `A` 0/1,
`w` (the cohort's own weights column, or NA) and the covariate columns. `xvars`
are the covariates to adjust for, `s` the settings, `grid` the evaluation times
starting at 0. The function returns the two **marginal survival curves**.

Everything reported - RD(t) = S1 - S0, RMST difference (trapezoid integral of
the curves), CHR(t) = log S1 / log S0, HR(t) from smoothed cumulative hazards -
is derived from those curves in `R/estimands.R`, identically for every method.
A method that throws is reported on the status tab with its message; it does
not stop the others, and any warning it raises while running is kept as a
note on the same tab. A method may declare its estimate **incomplete**
(`attr(result, "incomplete") <- "why"`; the TMLE does when a targeting step
fails or does not converge): the estimate is shown with status
"incomplete", without any interval, it is never cached, and the cohort
comparison still counts it as pending. The contract is enforced, never repaired: numeric columns, the
curves at exactly the grid times, probabilities in [0, 1], 1 at time 0;
anything else is refused with what was found.

Follow-up ends at each arm's last observed time. A curve past that is the
last value carried forward, or a model's extrapolation, so the runner
blanks it: an estimate at a later report time is NA with
`within_followup = FALSE`, the comparison cell says "beyond follow-up", and
the notes on the status tab say where follow-up ends. A method whose
curves are step functions (Kaplan-Meier, Cox) may say so with
`attr(result, "step") <- TRUE`: the RMST then integrates them as step
functions, and since the grid carries every distinct event time up to the
horizon (at most `DASH_GRID_KNOTS`, then thinned with a note) that integral
is exact. Any other curve is integrated linearly between grid points. A
method whose curves jump at other times (bin ends, or every observed time
as the AIPTW does) declares them, with `knots = function(d, s, tmax)` in
the registry or `METHOD_KNOTS` in its script, and those times go on its
grid too; the grid is built per method, inside the method's own error
boundary. A zero tail is kept only when the data say so: everyone in the
arm had the event and the curve is at zero there. A zero a method merely
estimated or clipped to, with patients still censored, is blanked like any
other tail. Each bootstrap resample is run on its own grid (its event times
and the knots the method computes from it) and clipped at its own
follow-up, so a time that most resamples do not reach gets no interval; its
curves are aligned to the main grid for the pointwise bands only. A grid a
caller supplies is part of the cache identity.

### What `prep_data()` guarantees

The columns a method sees are `time`, `event`, `A`, `w` and the covariates
under formula-safe internal names (a covariate called `time`, or `my col`,
is renamed and the rename shown on the Data page). It refuses, with the
reason: a missing role column, a time column with no numbers, an event
column with values other than 0/1, a treatment column with other than two
values or a treated value that is not one of them, a covariate that is also
a role column. It drops, counted by reason and shown on the Data page: rows
with a missing or non-positive time, a missing event or treatment, or a
missing covariate. A factor is read through its labels. A numeric covariate
that differs on every row is a covariate; a text column that does is an id.
The guess also leaves out a blank-named column (it is named `unnamed_<n>`),
a constant, a column missing in more than a fifth of rows, a date, and text
with more than thirty distinct values; the Data page says which and why,
any of them can be picked by hand, and `cohorts.csv` can fix the covariates
per cohort. When rows are dropped for a missing covariate the page says
which covariates, and how many rows each.
A blank in a text covariate is a category of its own, `missing`, so a
patient whose biomarker status was not recorded stays in and the models
adjust for the status being unrecorded; the Data page option (or
`missing_as_level` in `cohorts.csv`) turns that off per cohort, and the page
counts the rows carrying that level for each covariate. A blank in a
numeric covariate still excludes the row.

A patient without an event still needs a time. Where the file gives none
(the duration is blank for everyone who had no event), the time is taken
from the mapped follow-up column if there is one, a number or a date; else
the patient is followed to the data cut-off, which is `DASH_DATA_CUTOFF`
or the `cutoff_date` in `cohorts.csv` if given and otherwise the latest
event date in the file, and is censored at the cut-off minus the start
date. The Data page says which rule was used, for how many patients, and
the cut-off date. An event column that is 1 on every row, or that says no
more than "a duration is recorded", is not used: the event is read as
exactly that. With no start date and no follow-up column those patients
have no time, and a cohort left with events only is refused rather than
analysed.

### Intervals

A method may attach `attr(result, "ic") = list(s1, s0)`: `n x length(grid)`
matrices of each subject's centred influence-curve value for survival under
each arm. Every estimand is a known functional of the two curves, so its
standard error follows from those matrices by the delta method (nuisance
models taken as known): RD directly, RMST by the trapezoid integral, CHR on
the log scale. AIPTW and TMLE supply theirs; the estimates table says
`influence curve`. With bootstrap replicates requested, every method gets
percentile intervals instead (`bootstrap`), at (B + 1) times the run time.
A method with neither reports point estimates only.

### Methods from `src/`

The study's estimators live as scripts in the repository's `src/` folder
(`DASH_SRC_DIR`, default `../src` beside this folder), and they come and go.
At startup every R script there whose text defines

```r
estimate_curves <- function(d, xvars, s, grid)   # -> data.frame(time = grid, s1, s0)
```

is sourced into its own environment and registered as a method, shown on the
Methods page with the script's file name beside its name. A script may also
set `METHOD_LABEL`, `METHOD_CLASS`, `METHOD_SPEED`, `METHOD_REQUIRES`,
`METHOD_USES`, `METHOD_NOTE` and `METHOD_KNOTS`; `docs/src_method_template.R` is a script to
copy. Scripts without that function are listed on the About page as "not a
dashboard method" and are never run, so an unrelated runner in `src/` costs
nothing; a script that fails to source is listed with its error. The
script's checksum is part of its results-cache key, so an edited script is
re-run, never served old numbers. The reference implementations in
`R/estimators.R` are registered in `R/methods.R` the same way, with
`add_method()`, and show `R/estimators.R` as their file.

The dashboard's own `methods/` folder is scanned the same way, before `src/`.
It is where adapters live when the study's scripts cannot be edited or
copied out: a short script that sources a study file from `SRC_DIR`, calls
its function and returns the curves (`docs/INTEGRATION_HANDOVER.md` has the
steps and a skeleton). An adapter's cache key covers every file in both
folders, so an edited study file re-runs the adapters that use it. A name
taken in both folders is the second script's error.

### The study's functions, wrapped automatically

With `src/analysis` beside the dashboard, every function named
`run_<something>_analysis()` in it becomes a method at startup with no
adapter written (`R/study_methods.R`). Its arguments are filled from their
names (the cohort, the covariate names, the evaluation times, the names of
the time, event and treatment columns, model formulas), it is called on the
prepared cohort, and the two survival curves are read out of what it
returns: a table with a time column and a column per arm, a long table
with an arm column, or one vector per arm; cumulative risks are turned
into survival. Label, class and speed come from the function's name, and
the script's file name is shown beside it. A slow method (TMLE by its
name) is asked only for the report times. The study's files are loaded
into one environment, so its functions find each other's helpers: the
scripts that hold a `run_*_analysis` function, and every other script under
`src/` that only defines things. A script that runs code at its top level
and holds no such function is never executed. When a call stops for want
of a column the study code knows the time, the event or the treatment by
(`status`, `trt` and the like), that name is supplied and the call repeated.

This is inference from names, so such a method says "auto-adapted", its
notes say how it was called and where its curves were read, and it never
chooses between two readings: a result with no recognisable pair of
curves, or arms that cannot be told apart, is that method's failure with
the reason. `Rscript jobs/describe_src.R --try` runs the same reading on a
synthetic cohort and reports, function by function, what works. An adapter
in `methods/` named after the function or its script takes the wrapper's
place, which is how a wrong reading is corrected. `DASH_AUTO_ADAPT=FALSE`
turns the wrapping off.

## Settings

| setting | read by |
|---|---|
| report times | RD and RMST are reported at each |
| CHR time | the cumulative hazard ratio |
| time divisor, time unit | `prep_data`: duration / divisor = analysis units (30.4375: days to months); the unit is a label only |
| interval width, time spline df | the pooled-logistic (discrete-time) methods |
| TMLE grid (fixed width / event-driven, capped at 100 bins), TMLE width | TMLE |
| PS bound b | every propensity model (scores kept in [b, 1-b]) and the censoring survival floor |
| stabilised weights, use the cohort's weights column | every weighting step |
| extra PS terms, extra outcome terms | appended to the model formulas, e.g. `I(age^2) + age:ecog`. A term may use covariate names, numbers and these functions only: `+ - * : ^ ( I log log1p sqrt exp abs poly ns bs factor as.factor as.numeric pmin pmax scale`; anything else is refused before it reaches a model, and so is a term that gives any patient a missing or non-finite value |
| bootstrap B, seed | percentile CIs from B resamples of the cohort (run time x (B+1)). An interval is reported only where at least 80% of replicates (and at least two) gave a value for that estimand at that time - a resample with no control events leaves CHR and the risk ratio undefined while RD keeps its interval; the status tab says how many replicates failed, or gave no value, and why |

Discrete-time methods give survival at each bin end; between bin ends the
curve is interpolated linearly (a flat step would bias RMST upward).

## The results cache

Every result is written to `DASH_CACHE_DIR` (default `output/cache` beside
this file) under a key covering the cohort's data (file checksum), its column
mapping, the method, every setting, and a checksum of the code that decides
results. Before anything is computed the cache is consulted, so a second
viewer, a restarted App, or a cohort comparison asked twice costs nothing;
and a changed setting or an edited estimator is a different key, so a stale
number is never served. The directory is probed for writing at startup; one
that cannot be written turns the cache off and the About page says so.
Writes are atomic (temporary file, then rename), and whether a result was
stored is reported on the status tab separately from whether it was
computed. A session loads what the cache holds for its starting settings,
which is how a precompute Job's results appear without a click:

```
Rscript jobs/precompute.R                     # every cohort, the fast methods
Rscript jobs/precompute.R --methods all       # including the slow ones
```

## Running locally

```
Rscript -e "shiny::runApp('.', launch.browser = TRUE)"     # from this folder
Rscript tests/run_tests.R
Rscript jobs/precompute.R
Rscript data/make_synthetic.R                             # CSVs into data/, then DASH_SOURCE=files works locally
```

Deploying on Domino: `DEPLOY_DOMINO.md`.
