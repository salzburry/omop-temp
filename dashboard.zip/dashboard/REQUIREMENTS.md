# DR time-to-event dashboard - requirements and reference screenshots

One place for everything the dashboard has to be, as it was asked for on
2 October 2026: the user's own statements, the requirements drawn from them,
from the nine screenshots of the work laptop and from the seven external
reviews the user had fixed, and the screenshots and chart renders themselves
(kept under `docs/screenshots/`).

---

## 1. The ask, in the user's words

| # | statement |
|---|---|
| S1 | "So I have been asked to create a dashboard in R shiny Its comparing different methods based on dataset inputs" |
| S2 | What the methods are: "Will share ss". Where the datasets come from: "app will be n domino". Spec: "I will describe it later" |
| S3 | "Folder structure and files details that are there" (screenshots 1-5) |
| S4 | "R shiny dashboard someone else created the pomt is there should be flexibility to add in cohort or a new methods as needed" (screenshots 6-9) |
| S5 | "Yes please this need to be a domino app so look through all repos especially Julia lot to see how it works" |
| S6 | "dont invent anything new. The point is to just what is asked." |
| S7 | "Keep it as is and only do what you ask next.." |
| S8 | "please add the screenshots and all the requirements ino the a single md file" |
| S9 | "Also this layout is very generic and this does not at all look like a modern sleek dashboard. Can we have GSK color of orange and white . Also dont like this . It feels like dashboard from age of 1990s" |
| S10 | "The layout is still bad. Look at the RWD jurney that you created in html file in other repo. Is that not possible ihere" |
| S11 | "Also we have SMD chart before and after IPW and PSM to. Can we have any other charts or graphics to make it more modernize. Think a bit more. Explore outside and come back" |
| S12 | "build 1, 2 and 3" then "also build 4,5,6 after that" (the six chart proposals) |
| S13 | "update the requirements md and screenshots with the new charts. Also the methods in the src folder can come and go. In the method name over here it should automaticall pick if a new script is added and show the file name associated so its to understand" |
| S14 | "we do not have to generate the stats models but reuse the codes already present in the folder ss shared" |
| S15 | "fix 1, I'll share the src folder later" |
| S16 | "I need to move this dashboard code to other prod where the src folder" and "so for now fix the bugs here and make it as good so i can it move it there" |
| S17 | "so if I just move this dashboard product to the prod it should automatically pick the src folder ?" |
| S18 | Seven external reviews of the code were pasted on 2 October 2026, each followed by the instruction to fix the findings ("fix the bugs", "fix", "fix it", "fix them", "fx all", "Fix all"); the design recommendations in those reviews were not asked for |
| S19 | "so src will be scripts right all the methods one ?" |
| S20 | "update the requirements md and screenshots" |
| S21 | "The question is src has diff scripts would it stil be a problem ?" |

---

## 2. Requirements

### 2.1 Purpose and scope

| id | requirement | source |
|---|---|---|
| R1 | An R Shiny dashboard that compares different methods on a given dataset input. | S1 |
| R2 | The methods are the causal survival estimators of the `sim-doublyrobust-tte` repository (section 3): singly robust (IPW, G-computation), naive DR, doubly robust (AIPTW, DR standardisation, TMLE). | S3, S4, screenshots 3, 9 |
| R3 | The dataset inputs are the eligibility-scenario cohorts (section 2.4), one file per scenario; the dashboard also compares results across those cohorts. | S3, screenshot 2, plan item 5 |
| R4 | It builds on the dashboard someone else already created (the "DR time-to-event dashboard", screenshots 6-9): same pages, controls and outputs. | S4 |
| R5 | Scope is exactly what is asked. Nothing is added beyond these requirements without being asked. | S6, S7 |

### 2.2 Platform: Domino

| id | requirement | source |
|---|---|---|
| R6 | The dashboard runs as a Domino App. | S2, S5 |
| R7 | It follows the way the group's other dashboards work on Domino, taken from the `julialot` repository (cohort_explorer, Sep 10 and Sep 16 dashboards): an `app.sh` launcher that Domino runs from the project root, the process listening on `0.0.0.0:8888`; packages baked into the compute environment; every setting an environment variable; a synthetic data source as the default so a first deploy can be clicked through, said so in a banner, with a switch to refuse synthetic data in production; real data in a Domino Dataset whose mount path is read off the publish dialog; a Job that computes and an App that serves; access for project collaborators only. | S5 |

### 2.3 Extensibility - the point of the work

| id | requirement | source |
|---|---|---|
| R8 | A new cohort can be added as needed, without changing the application code. | S4 |
| R9 | A new method can be added as needed, without changing the application code. | S4 |

### 2.4 Inputs: the cohort files

| id | requirement | source |
|---|---|---|
| R10 | Eight cohort files, one per eligibility scenario, named `docetaxel_nivolumab_EC_<scenario>_feature_table.csv` with scenarios: `ECOG`, `Fully relaxed`, `Fully restricted`, `HISTOLOGY_ECOG`, `HISTOLOGY`, `HISTOLOGY_STAGE`, `STAGE_ECOG`, `STAGE`. They sit in the repository's `dashboard/` folder. | screenshot 2 |
| R11 | File layout (screenshot 1): a leading unnamed index column, then `patientid`, `duration`, `event`, `treatment`, `weights`, `Unnamed: 0`, `linename`, followed by further columns (a line number, a stage text beginning "ADVANCED", and more cut off in the screenshot). `treatment` is numeric (`1.0` / `0.0`); `linename` is the drug (`nivolumab` / `docetaxel`); `duration` is in days and is missing on some rows; `weights` is a precomputed weight; `event` is `1.0` / `0.0`. | screenshot 1 |
| R12 | The Data page lets the user pick sample cohorts or upload files, then map the columns. | plan item 1 (screenshot 5) |

### 2.5 Pages (as in the existing dashboard)

The navigation bar: **1 · Data**, **2 · Diagnostics**, **3 · Methods & run**, **4 · Results**, **5 · Compare cohorts**, **About** (screenshots 6, 7, 9).

| id | page | requirement | source |
|---|---|---|---|
| R13 | 1 · Data | Pick sample cohorts or upload files, then map the columns. | plan item 1 |
| R14 | 2 · Diagnostics | Kaplan-Meier curves, propensity-score overlap, balance. | plan item 2 |
| R15 | 3 · Methods & run | Choose methods and settings (sections 2.6 and 2.7) and run. | plan item 3, screenshots 8, 9 |
| R16 | 4 · Results | Forest plots of CHR, survival difference and RMST in the same style as the simulation report, plus marginal survival curves, HR(t) over time and runtimes. Controls: **Data set** selector; **Estimand** radio with *Survival difference (RD)*, *RMST difference*, *Cumulative hazard ratio*; download buttons **Estimates CSV** and **Curves CSV**; tabs **Estimates table**, **Marginal survival curves**, **Marginal HR(t)**, **Run time & status**. | plan item 4, screenshot 7 |
| R17 | 5 · Compare cohorts | Results side by side across the eight eligibility scenarios. Controls: **Estimand** (RD / RMST / CHR), **Time**, **Methods**; a panel "Estimate by cohort, one panel per method" and a table "Estimates (rows = cohorts, columns = methods)". | plan item 5, screenshot 6 |
| R18 | About | Present in the navigation. | screenshots 6, 7, 9 |

### 2.6 Methods on the Methods & run page

Grouped by robustness class, "as in the May 2026 simulation" (screenshot 9), with buttons **Select fast methods**, **Select all**, **Clear** (screenshot 8). Methods whose package is missing are listed, not hidden ("Not installed: DR concrete").

| class | methods |
|---|---|
| Singly Robust (IPW) | IPTW Cox; IPTW Discrete cloglog; IPTW Discrete logit; IPTW FPM NPH |
| Singly Robust (G-comp) | Cox Reg Stand; Discrete Reg Stand cloglog; Discrete Reg Stand logit; FPM Reg Stand |
| Naive DR | Cox DR Reg Stand; FPM DR Reg Stand; Naive IPTW+Stand cloglog |
| Doubly Robust (AIPTW) | AIPTW Cox; AIPTW Discrete PLR |
| Doubly Robust (DR Stand) | DR PLR Logit; DR Blanche Binomial |
| Doubly Robust (TMLE) | DR survTMLE GLM (slow); DR ltmle (slow); DR concrete (not installed) |

| id | requirement | source |
|---|---|---|
| R19 | The method list above, grouped as above, selectable per method; the slow TMLE methods are unselected by default. | screenshots 8, 9 |
| R20 | "Select fast methods", "Select all" and "Clear" buttons. | screenshot 8 |
| R21 | Notes shown on the page: "TMLE methods discretise time; ltmle cost grows ~quadratically with the number of intervals." and "Bootstrap multiplies run time by (B + 1). Only AIPTW methods repo[rt ...]" (cut off in the screenshot). | screenshot 8 |

### 2.7 Settings (Methods & run page)

| id | setting | default shown | source |
|---|---|---|---|
| R22 | Report RD / RMST at times (analysis units) | `6, 12, 18` | screenshot 9 |
| R23 | Cumulative hazard ratio at time | `12` | screenshot 9 |
| R24 | Interval width for discrete-time methods | `1` | screenshot 9 |
| R25 | TMLE time grid: *Fixed width* or *Event-driven (simulation default; can be very fine)* | Fixed width | screenshots 8, 9 |
| R26 | TMLE interval width (fixed grid) | `2` | screenshots 8, 9 |
| R27 | PS trimming bounds (AIPTW): a slider on 0 to 0.2 | `0.01` to `0.2` | screenshot 8 |
| R28 | FPM spline df (k) | `3` | screenshot 8 |
| R29 | Extra PS terms (optional), free text, e.g. `I(age^2) + age:BirthSex_M` | empty | screenshot 8 |
| R30 | Extra outcome-model terms (optional), free text | empty | screenshot 8 |
| R31 | Bootstrap replicates for CIs (0 = off) | `0` | screenshot 8 |

### 2.8 Outputs

| id | requirement | source |
|---|---|---|
| R32 | Estimands: survival difference (RD), RMST difference, cumulative hazard ratio (CHR), reported at the times set in R22 and R23. | screenshots 6, 7, 9 |
| R33 | Per method: marginal survival curves, HR(t) over time, run time and status. | plan item 4, screenshot 7 |
| R34 | Forest plots of CHR, survival difference and RMST in the same style as the simulation report. | plan item 4 |
| R35 | Estimates and curves downloadable as CSV. | screenshot 7 |

### 2.9 Look and additional charts (asked for after the first build)

| id | requirement | source |
|---|---|---|
| R39 | A modern look in GSK orange and white, following the RWD Studio design system of the `rwdplatform1` repository (`rwd_services/studio_web/style.css`): wordmark with the brand dot, numbered journey row for the five pages, warm off-white page, white hairline cards. | S9, S10 |
| R40 | Balance diagnostics: standardised mean differences before adjustment, after IPW and after propensity-score matching; a mirrored propensity histogram; ECDF plots per continuous covariate, unweighted and weighted. | S11, S12 (1) |
| R41 | Effect over time: the survival-difference curve with a confidence band, the RMST difference as a function of the horizon, numbers at risk under the curves. | S12 (2) |
| R42 | A specification curve on the Compare page: every cohort x method estimate sorted, with a strip marking method and cohort. | S12 (3) |
| R43 | An E-value per method (the point estimate's and the confidence limit's). | S12 (4) |
| R44 | A treatment-effect heterogeneity plot (outcome against the propensity score by arm, smoothed). | S12 (5) |
| R45 | Weight diagnostics (IPT weight distribution by arm with effective sample sizes) and the cohorts' sizes on the Compare page. | S12 (6) |
| R46 | Methods are discovered from the repository's `src/` folder at startup: a script that defines `estimate_curves()` is a method; adding a script adds the method, removing it removes the method, with no edit to the dashboard. | S13 |
| R47 | Each method is shown with the name of the script it comes from, so it is clear which file produced which numbers. | S13 |

### 2.11 Methods from the study's `src/` folder (asked for after the first build)

| id | requirement | source |
|---|---|---|
| R48 | The statistical methods are not re-implemented by the dashboard: the study's own code in the repository's `src/` folder is what runs. The seven built-in estimators are reference implementations that stand in until `src/` is wired in, and are labelled as such. | S14, S15 |
| R49 | The dashboard folder moves as a unit into the production repository beside `src/`. With nothing configured it looks for `../src` (`DASH_SRC_DIR` overrides it) and registers what it finds at startup. | S16, S17 |
| R50 | One script is one method: a script in `src/` that defines `estimate_curves(d, xvars, s, grid)` is a method, with optional `METHOD_LABEL`, `METHOD_CLASS`, `METHOD_SPEED`, `METHOD_REQUIRES`, `METHOD_USES`, `METHOD_NOTE` and `METHOD_KNOTS`. A study file that holds several functions is reused through one thin adapter script per method, without editing the study file; files whose name starts with `_` are left alone by the scanner, so shared helpers can live there. | S19, S21 |

### 2.12 Correctness and robustness, from the external reviews

Each row was a reproduced finding in one of the seven reviews and was fixed on the user's instruction (S18). The headless suite checks every one.

| id | requirement | source |
|---|---|---|
| R51 | Every result has one status, `ok`, `incomplete` or `failed`, shown in the tables, carried by the exports, counted as pending by the Compare page, and used by the precompute Job, which exits non-zero unless every result is ok and stored. A method may declare its estimate incomplete; the marker must be one non-empty reason, anything else is the method's failure. | reviews 3, 4, 5 |
| R52 | A result belongs to one analysis: settings, cohort id, data checksum, column mapping, code checksum and method checksum. Only results of the current analysis are shown; the cache is keyed the same way, plus any grid a caller supplies. | reviews 1, 2, 7 |
| R53 | Cohorts are keyed by id everywhere; display labels are made unique; the same file name in two folders is two cohorts. | reviews 4, 5 |
| R54 | Each cohort carries its provenance. Generated files are recognised by the `SYNTHETIC.md5` marker the generator writes, uploads included, and `DASH_ALLOW_SYNTHETIC=FALSE` refuses them; the banner says when any cohort is generated. | reviews 3, 4 |
| R55 | A `file` in `cohorts.csv` resolves beside the manifest, then in the data folder(s), never in the working directory; a file that is not there stays missing. | reviews 4, 5 |
| R56 | Data preparation refuses repeated column names, bad event or treatment coding and a role column used as a covariate; it drops rows by stated reason; covariates get formula-safe internal names, sorted so the order they were picked in changes nothing. | reviews 2, 3, 5 |
| R57 | Extra model terms are parsed against an allowlist and checked against the data before any model on any path, the diagnostics included. | reviews 2, 3, 4 |
| R58 | Each `src/` script is sourced in its own environment with a time limit; its metadata is validated inside that boundary, so a bad value is that script's error and the scripts beside it still register; the About page lists every script and what became of it; the folder's checksum and the declared packages' versions are part of the cache key. | reviews 2, 3, 4, 5 |
| R59 | Curves are blanked past each arm's last observed time: estimates there are NA with `within_followup = FALSE`, the Compare cell says "beyond follow-up", the diagnostics risk table shows NA. A zero tail is kept only when everyone in the arm had the event and the curve is at zero there. | reviews 5, 6, 7 |
| R60 | The grid holds the regular points, the report times, the cohort's event times and the knots a method declares (`knots` in the registry, `METHOD_KNOTS` in a script), capped by `DASH_GRID_KNOTS` with a note when thinned. A method may declare step-function curves (`attr(result, "step")`) and is then integrated as such, exact for Kaplan-Meier and Cox (checked against the survival package's restricted mean). | reviews 5, 6 |
| R61 | Each bootstrap resample runs on its own grid and is clipped at its own follow-up; usable replicates are counted per estimand and time; an interval needs at least 80% of them and at least two; an incomplete replicate counts as failed; the notes say why an interval is missing. | reviews 2, 4, 5, 6, 7 |
| R62 | Every setting has a `DASH_*` variable so the Job can match any page; grid settings are validated before a run; an empty `DASH_CACHE_DIR` turns the cache off; the cache directory is probed for writing, writes are atomic, and whether a result was stored is reported. | reviews 1, 4, 6 |
| R63 | Nothing a method does can close the session: grid construction, the method's code, its metadata and its bootstrap replicates fail as that method's failure, reported on the status tab. | reviews 3, 6 |
| R64 | The headless suite (`tests/run_tests.R`, 305 checks on 2 October 2026) covers every item above and checks that `app.R` names no method and no cohort. | R36 |

### 2.13 Raised by the reviews, deliberately not done

Design recommendations that would go beyond what was asked (S6, S7): a schema that generates controls, defaults and validation for method-specific settings; per-dataset time units; an explicitly empty adjustment set in the manifest (a blank field means the guessed covariates); background execution of long runs; pinned package versions; statistical equivalence of the reference implementations against the study code (the study's `src/` replaces them, R48).

### 2.10 Supporting deliverables

| id | requirement | source |
|---|---|---|
| R36 | A headless test of the app. | plan, screenshot 5 ("After that come a headless test of the app and a README.") |
| R37 | A README. | plan, screenshot 5 |
| R38 | A `run_headless.R` in the dashboard folder, as the repository already has. | screenshot 2 |

---

## 3. Repository context: `sim-doublyrobust-tte`

The work repository on the user's work laptop (not available on this machine).

**Root** (screenshot 5): `application/`, `dashboard/`, `debug/`, `May2026_Simulation/`, `plans/`,
`presentations/`, `src/`, `src_legacy/`, `tmle-surv-paper-tom-main/`, `.gitignore`,
`CHANGES_vs_original.md`, `README.md`, `sim-doublyrobust-tte.Rproj`.

**`dashboard/`** (screenshot 2): `output/`, `R/`, the eight cohort CSVs (R10), `run_headless.R`.

**README** (screenshots 3, 4): *Doubly Robust Estimators for Survival Outcomes: Point Exposures and
Time-fixed Confounders* (Thomas Debray). The repository "contains source code for implementing and
evaluating doubly robust estimators for causal effect estimation with survival outcomes", for
"observational and real-world data settings, where treatment assignment is not randomized and
confounding must be addressed through statistical adjustment". It "provides implementations of
several commonly used approaches ranging from singly robust methods to more advanced doubly robust
estimators, allowing users to compare their behavior and explore the trade-offs between simplicity,
robustness to model misspecification, and statistical efficiency." The methods implemented:

- Inverse Probability of Treatment Weighting (IPTW)
- Regression Standardization (G-computation)
- Doubly Robust Standardization (IPTW-RA)
- Augmented Inverse Probability Treatment Weighting (AIPTW)
- Targeted Maximum Likelihood Estimation (TMLE)

**The plan the earlier session was working to** (screenshot 5, "Shiny dashboard for src scripts"):

1. Data: pick sample cohorts or upload files, then map the columns.
2. Diagnostics: KM curves, propensity-score overlap, balance.
3. Methods and run: choose methods and settings.
4. Results: forest plots of CHR, survival difference and RMST in the same style as the simulation report, plus marginal survival curves, HR(t) over time and runtimes.
5. Compare cohorts: results side by side across the eight eligibility scenarios.

After that come a headless test of the app and a README.

---

## 4. Screenshots

### Screenshot 1 - the dashboard folder and a cohort CSV open in VS Code

The eight `*_feature_table.csv` files, `run_headless.R`, and the first rows of
`docetaxel_nivolumab_EC_ECOG_feature_table.csv` (columns: index, patientid, duration, event,
treatment, weights, Unnamed: 0, linename, ...). The plan text is in the right-hand pane.

![Dashboard folder and cohort CSV](docs/screenshots/01_repo_dashboard_folder_and_cohort_csv.jpg)

### Screenshot 2 - the `dashboard/` folder tree

`output/`, `R/`, the eight cohort CSVs and `run_headless.R`, inside the repository root.

![Dashboard folder tree](docs/screenshots/02_repo_dashboard_folder_tree.jpg)

### Screenshot 3 - README, the methods implemented

![README methods](docs/screenshots/03_repo_readme_methods.jpg)

### Screenshot 4 - README, introduction

![README introduction](docs/screenshots/04_repo_readme_intro.jpg)

### Screenshot 5 - repository root and the five-page plan

![Repository root and plan](docs/screenshots/05_repo_root_and_dashboard_plan.jpg)

### Screenshot 6 - existing app, page 5 · Compare cohorts

Estimand (RD / RMST / CHR), Time, Methods; "Estimate by cohort, one panel per method";
"Estimates (rows = cohorts, columns = methods)".

![Existing app: Compare cohorts](docs/screenshots/06_existing_app_compare_cohorts.jpg)

### Screenshot 7 - existing app, page 4 · Results

Data set; Estimand (Survival difference (RD) / RMST difference / Cumulative hazard ratio);
Estimates CSV and Curves CSV; tabs Estimates table, Marginal survival curves, Marginal HR(t),
Run time & status.

![Existing app: Results](docs/screenshots/07_existing_app_results.jpg)

### Screenshot 8 - existing app, page 3 · Methods & run (lower part and settings)

Naive DR methods; Select fast methods / Select all / Clear; TMLE time grid, TMLE interval width,
PS trimming bounds (AIPTW), FPM spline df (k), extra PS terms, extra outcome-model terms,
bootstrap replicates; the two notes on run time.

![Existing app: Methods lower and settings](docs/screenshots/08_existing_app_methods_lower_and_settings.jpg)

### Screenshot 9 - existing app, page 3 · Methods & run (estimators by class and settings)

Estimators grouped by robustness class, as in the May 2026 simulation; report times, CHR time,
interval width for discrete-time methods, TMLE time grid and width.

![Existing app: Methods top and settings](docs/screenshots/09_existing_app_methods_top_and_settings.jpg)

---

## 5. The charts as built (synthetic cohorts, 2 October 2026)

Static renders of the dashboard's figures on the synthetic cohorts, one per requirement R40
to R45, the earlier result figures, and two renders of the follow-up and bootstrap rules
(R59, R61). Re-rendered on the final code after the seventh review. The numbers are generated,
not study data.

### Chart 10 - covariate balance: unweighted, IPT-weighted, matched 1:1 (R40)

![Balance](docs/screenshots/10_chart_balance_unweighted_ipw_matched.png)

### Chart 11 - propensity overlap as a mirrored histogram, observed filled and IPT-weighted outlined (R40)

![Mirrored histogram](docs/screenshots/11_chart_propensity_mirrored_histogram.png)

### Chart 12 - ECDF of each continuous covariate by arm, unweighted beside weighted (R40)

![ECDF](docs/screenshots/12_chart_ecdf_by_arm.png)

### Chart 13 - survival difference over time with pointwise bands (R41)

![Survival difference over time](docs/screenshots/13_chart_survival_difference_over_time.png)

### Chart 14 - RMST difference by horizon (R41)

![RMST difference by horizon](docs/screenshots/14_chart_rmst_difference_by_horizon.png)

### Chart 15 - specification curve, estimates sorted by size (R42)

![Specification curve](docs/screenshots/15_chart_specification_curve.png)

### Chart 16 - specification curve, the strip naming method and cohort for each point (R42)

![Specification strip](docs/screenshots/16_chart_specification_strip.png)

### Chart 17 - E-values per method, point estimate and confidence limit (R43)

![E-values](docs/screenshots/17_chart_evalues.png)

### Chart 18 - treatment-effect heterogeneity across the propensity score (R44)

![Heterogeneity](docs/screenshots/18_chart_heterogeneity.png)

### Chart 19 - IPT weights by arm with effective sample sizes (R45)

![Weights](docs/screenshots/19_chart_weights.png)

### Chart 20 - cohort sizes after exclusions (R45)

![Cohort sizes](docs/screenshots/20_chart_cohort_sizes.png)

### Chart 21 - forest plot of the survival difference across methods, one panel per report time (R16, R34)

![Forest plot](docs/screenshots/21_chart_forest.png)

### Chart 22 - marginal survival curves per method (R16, R33)

![Marginal curves](docs/screenshots/22_chart_marginal_curves.png)

### Chart 23 - cohorts by methods heatmap (R17)

![Heatmap](docs/screenshots/23_chart_heatmap.png)

### Chart 24 - estimate by cohort, one panel per method (R17)

![Compare cohorts](docs/screenshots/24_chart_compare_cohorts.png)

### Chart 25 - curves stop where an arm's follow-up ends (R59)

The control arm censored at 3 months: every method's control curve stops there, and RD, RMST
and CHR at 6, 12 and 18 months are reported as beyond follow-up rather than as numbers. Five methods are shown; the reference AIPTW is left out of this render because its censoring model does not fit an arm censored en bloc (the study implementation replaces it, R48).

![Curves stop at the end of follow-up](docs/screenshots/25_chart_curves_stop_at_end_of_followup.png)

### Chart 26 - a bootstrap band only where most resamples reach the time (R61)

Follow-up past 6 months carried by two patients: resamples that miss them have no value there,
so the band (B = 20) stops at 6 months while the estimate itself continues.

![Bootstrap band only where resamples reach](docs/screenshots/26_chart_bootstrap_band_only_where_resamples_reach.png)

---

## 6. The pages as built (synthetic cohorts, 2 October 2026, after the seventh review)

Captured from the running App at 800 px width. Generated numbers, not study data.

### Page 27 - 1 · Data (R12, R13, R54, R56)

Cohort picker and session upload; the cohort's description, source and provenance; what the
mapping drops and why; counts, median follow-up and the preview; the column mapping with
*Apply mapping* in the sidebar.

![Data page](docs/screenshots/27_page_data.jpg)

### Page 28 - 2 · Diagnostics (R14, R40, R45)

Unadjusted Kaplan-Meier by arm with numbers at risk, the mirrored propensity histogram, the
balance plot and the weights below.

![Diagnostics page](docs/screenshots/28_page_diagnostics.jpg)

### Page 29 - 3 · Methods & run (R15, R19, R20, R46, R47)

Estimators grouped by robustness class, each with the file it comes from (the template method
from `src/` beside the built-in ones); *Select fast methods*, *Select all*, *Clear*; the settings.

![Methods and run page](docs/screenshots/29_page_methods_and_run.jpg)

### Page 30 - 4 · Results (R16, R32-R35, R51, R59)

The forest plot of the survival difference at 6, 12 and 18 months across the seven methods
(intervals where a method supplies them), the CSV downloads, and the tabs: estimates table
(with status and `within_followup`), curves, effect over time, HR(t), agreement, E-values,
run time and status.

![Results page](docs/screenshots/30_page_results.jpg)

### Page 31 - 5 · Compare cohorts (R17, R42, R45, R51)

Estimand, time, methods and cohorts; *Run missing cohort x method combinations* with the count
still pending under the current analysis; one panel per method; the specification curve,
heatmap, table and cohort sizes below.

![Compare cohorts page](docs/screenshots/31_page_compare_cohorts.jpg)

### Page 32 - About (R18, R54, R58)

What the dashboard is, the data source and its provenance, the cache, how to add a cohort or a
method, the registered methods with their files, the scripts found in `src/`, the cohorts
with provenance, and the environment with the code checksum.

![About page](docs/screenshots/32_page_about.jpg)
