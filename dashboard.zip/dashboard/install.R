# Packages the app needs. Bake them into the Domino compute environment's
# Dockerfile (RUN Rscript install.R) so the App starts fast, or run once locally.
# survival and splines ship with R.
pk <- c("shiny", "bslib", "DT", "plotly", "ggplot2", "readxl")
new <- pk[!vapply(pk, requireNamespace, logical(1), quietly = TRUE)]
if (length(new)) install.packages(new, repos = "https://cloud.r-project.org")
