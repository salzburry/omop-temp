# Running the dashboard on Domino

Same pattern as the other Domino Apps in this group: a compute environment with
the packages baked in, a first deploy on synthetic data to prove the launcher
and the port, a Domino **Dataset** holding the cohort files attached to the
App, and a **Job** that precomputes results into the same Dataset so the App
never makes a viewer wait for a slow method.

## 0. Compute environment (once)

R 4.x plus the packages in `install.R`:

```r
install.packages(c("shiny", "bslib", "DT", "plotly", "ggplot2", "readxl"))
```

Bake them into the environment's Dockerfile (`RUN Rscript dashboard/install.R`,
or the line above) so the App starts fast rather than installing at launch.
`survival` and `splines` ship with R. A method added to `R/methods.R` that
needs another package lists it in `requires`; add that package here too, or the
method shows as "Not available" on the page.

## 1. Smoke test with no data

Publish the App with nothing set. It comes up on the eight synthetic
eligibility scenarios and says so in a banner on every page. This proves the
environment, the launcher and the port before any data question is involved.

- Domino launches the App command from the **project root** and expects the
  process on `0.0.0.0:8888`. Set the App command to
  `bash <path>/dashboard/app.sh` - the path from the project root to this
  folder. `app.sh` changes to the folder above itself, so nothing depends on
  where that is.
- Publish: Domino UI -> **App** -> **Publish**. Open the App URL once it is running.

## 2. Real cohorts and the cache - a Domino Dataset

Put the cohort files (`*_feature_table.csv`, and optionally a `cohorts.csv`
with labels, descriptions and column mappings) in a Domino **Dataset** of the
project, and attach it to the App on the Data step of the publish dialog. Read
the mount path off that step rather than assuming it - a local Dataset mounts
under `/mnt/data/<name>`, one imported from another project somewhere else -
and set the App's environment variables:

```
DASH_SOURCE=files
DASH_DATA_DIR=/mnt/data/<dataset-name>
DASH_CACHE_DIR=/mnt/data/<dataset-name>/cache
DASH_ALLOW_SYNTHETIC=FALSE
```

`DASH_ALLOW_SYNTHETIC=FALSE` makes an App configured for synthetic numbers
refuse to start and say why, so nobody quotes generated data because the
default was left in place. A files source whose directory is missing or empty
lists no cohorts; it never falls back to synthetic data. Generated cohort
files are recognised too: the generator writes a `SYNTHETIC.md5` marker
beside every file it produces, a cohort file listed there (by checksum) is
flagged synthetic however it arrived, the banner says so, and with the
guard set the App refuses to start and names the files. A `synthetic`
column in `cohorts.csv` declares the same for any file.

The cache directory must be writable by both the Job and the App; a Dataset
of this project is. If the App cannot write there it says so on the About page
and runs without a cache.

The App reads the Dataset at startup. To add a cohort, add the file (and a
`cohorts.csv` row if it needs a label or a mapping) and restart the App.

## 3. Precompute - a Domino Job

With the same Dataset attached and the same variables set, run

```
Rscript dashboard/jobs/precompute.R --methods all
```

as a Job (and on a schedule after each data refresh). It computes every cohort
x method under the App's starting settings and writes each result into the
cache; the App loads them when a session opens, so the Results and Compare
pages are full before anyone clicks Run. A combination already in the cache is
not recomputed, so re-running the Job after adding a cohort costs only the
new cohort. The Job exits non-zero unless every combination is `ok` AND stored in
the cache (a failed or incomplete result, or a result it could not write, is the
Job's failure), with the message in its summary CSV under `output/`.

Results cached under one version of the code are not served by another: the
key carries a checksum of the estimator code, so after a code change the Job
simply recomputes.

Other variables, all optional (`config/dashboard_config.R` has every one):

| variable | default | what it does |
|---|---|---|
| `DASH_FILE_PATTERN` | `_feature_table\.csv$` | which files in the folder are cohorts |
| `DASH_COHORTS_CSV` | `cohorts.csv` | the registry file, relative to the data folder or this folder |
| `DASH_ALLOW_UPLOAD` | `TRUE` | the session upload control on the Data page |
| `DASH_TIME_DIVISOR`, `DASH_TIME_UNIT` | `30.4375`, `months` | duration / divisor = analysis units; the unit is a label |
| `DASH_REPORT_TIMES`, `DASH_CHR_TIME` | `6, 12, 18`, `12` | the settings' starting values (also the Job's) |
| `DASH_GRID_POINTS`, `DASH_GRID_KNOTS` | `61`, `1000` | the curve grid: evenly spaced points up to the last report time, plus the cohort's distinct event times and the method's own knots (at most this many, else thinned with a note) so a step curve's RMST is exact |
| `DASH_INTERVAL`, `DASH_TIME_DF`, `DASH_TMLE_GRID`, `DASH_TMLE_WIDTH`, `DASH_MAX_BINS`, `DASH_TMLE_MAX_ITER`, `DASH_TMLE_TOL`, `DASH_PS_BOUNDS`, `DASH_PSM_CALIPER`, `DASH_STABILIZE`, `DASH_USE_PROVIDED_WEIGHTS`, `DASH_EXTRA_PS`, `DASH_EXTRA_OUT`, `DASH_BOOT_B`, `DASH_SEED` | the page defaults | every other setting, so the Job can be run under exactly the configuration a page uses |
| `DASH_CACHE_DIR` | `output/cache` | the results cache; set it EMPTY to run without one (a Windows shell cannot hold an empty variable: there, leave it unset and the default applies) |
| `DASH_SRC_DIR` | `../src` | where the study's own estimator scripts are, for methods wired in from them |
| `DASH_TITLE` | `DR time-to-event dashboard` | the title |

## Access

Project collaborators only. The cohorts carry patient-level rows; never
"anyone with the link".

## Troubleshooting

- **App refuses to start, log says `DASH_ALLOW_SYNTHETIC=FALSE`** - expected:
  `DASH_SOURCE` is still `synthetic`. Set `DASH_SOURCE=files` and `DASH_DATA_DIR`.
- **Starts, lists no cohorts** - `DASH_DATA_DIR` is not the Dataset's mount, or
  the files do not match `DASH_FILE_PATTERN`. The About page shows the source
  and the folder it looked in.
- **The Job's results do not show in the App** - the two see different
  caches (check `DASH_CACHE_DIR` on both), or the App's starting settings
  differ from the Job's (`DASH_REPORT_TIMES`, `DASH_CHR_TIME`,
  `DASH_TIME_DIVISOR` must match), or the code changed since the Job ran. The
  About page shows the cache directory and the code checksum.
- **A method shows "Not available"** - its `requires` package is not in the
  compute environment.
- **Blank / "cannot connect"** - the process is not on `0.0.0.0:8888`; confirm
  `app.sh` is the App command and was not overridden.
- **A method fails on a cohort** - it is reported on *Run time & status* with
  its message; the others still run. Column mapping problems are reported on
  the Data page when the mapping is applied.
