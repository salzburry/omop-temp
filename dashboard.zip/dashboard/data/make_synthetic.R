# Writes the synthetic cohorts (R/synthetic.R) to CSV, one per eligibility
# scenario, with the real files' naming and schema - for inspection, or to run
# the dashboard with DASH_SOURCE=files against them.
#
#   Rscript data/make_synthetic.R        (from the dashboard folder; writes into data/)
#   DASH_SYNTH_DIR=<folder> Rscript data/make_synthetic.R      (writes there instead)
#
# The deployed folder ships without these files: a generated cohort beside the
# real ones would trip the production guard (DASH_ALLOW_SYNTHETIC=FALSE).

here <- local({
  a <- grep("^--file=", commandArgs(FALSE), value = TRUE)
  if (!length(a)) getwd() else dirname(dirname(normalizePath(gsub("~+~", " ", sub("^--file=", "", a[1]), fixed = TRUE), winslash = "/")))
})
source(file.path(here, "R", "synthetic.R"))

out_dir <- trimws(Sys.getenv("DASH_SYNTH_DIR", ""))
if (!nzchar(out_dir)) out_dir <- file.path(here, "data")
dir.create(out_dir, showWarnings = FALSE)
cohorts <- synthetic_cohorts()
written <- character()
for (nm in names(cohorts)) {
  f <- file.path(out_dir, sprintf("docetaxel_nivolumab_EC_%s_feature_table.csv", nm))
  sub <- cohorts[[nm]]
  rownames(sub) <- seq_len(nrow(sub)) - 1L
  utils::write.csv(sub, f, row.names = TRUE)
  written <- c(written, f)
  cat(sprintf("%-58s n=%5d  events=%4d\n", basename(f), nrow(sub), sum(sub$event, na.rm = TRUE)))
}
# The provenance marker: the checksum of every file written here. A files-mode
# dashboard that finds a cohort file listed in SYNTHETIC.md5 beside it treats
# that cohort as synthetic - banner on, production guard tripped - whatever
# folder the file was copied to along with its marker.
writeLines(paste(unname(tools::md5sum(written)), basename(written)), file.path(out_dir, "SYNTHETIC.md5"))
cat("SYNTHETIC.md5 written: these files are marked as generated data\n")
