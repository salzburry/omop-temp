# Wiring the study's analysis scripts into the dashboard

For whoever, or whichever Claude Code session, has the repository with
`src/analysis/` at hand. The study's scripts cannot leave the repository, so
the adapters are written there, next to the scripts, and only the adapters
travel back. Nothing in `src/` is edited.

## What an adapter is

One short R script per study method, in the dashboard's own `methods/`
folder, named after the study script: `methods/iptw_cox.R` for
`src/analysis/run_iptw_cox_analysis.R`. The dashboard scans `methods/` at
startup exactly as it scans `src/`, shows the method with its file name,
groups it under its class, and gives it the same intervals, follow-up rule,
cache and tests as every other method. `docs/src_method_template.R` is the
contract in full; the short form:

- it defines `estimate_curves(d, xvars, s, grid)` and returns
  `data.frame(time = grid, s1, s0)`: the marginal survival curves if everyone
  were treated and if everyone were control, at exactly the grid times, 1 at
  time 0;
- `d` is the prepared cohort: `time` (analysis units), `event` 0/1, `A` 0/1
  with 1 = treated, `w` (the file's weights column or NA) and the covariates
  under formula-safe names; `xvars` are the covariate names; `s` the settings;
- it sources the study file from `SRC_DIR`, a global the dashboard sets
  (default `../src` beside the dashboard folder);
- it sets `METHOD_LABEL` (use the old dashboard's labels), `METHOD_CLASS`
  (one of: Singly Robust (IPW), Singly Robust (G-comp), Naive DR, Doubly
  Robust (AIPTW), Doubly Robust (DR Stand), Doubly Robust (TMLE)),
  `METHOD_SPEED` ("fast" or "slow"), `METHOD_REQUIRES` (packages) and
  `METHOD_NOTE`;
- `attr(result, "step") <- TRUE` when the curves are step functions
  (Kaplan-Meier, Cox); `attr(result, "incomplete") <- "reason"` when a fit did
  not converge; `attr(result, "ic") <- list(s1, s0)` when the function gives
  influence curves; `METHOD_KNOTS <- function(d, s, tmax)` when the curves
  jump at times that are not event times (bin ends).

## Steps

1. **Report before writing.** For every `src/analysis/run_*_analysis.R`, one
   row in `methods/ADAPTERS.md`: file, function name, its arguments, what it
   needs the data to look like (column names, coding of treatment and event),
   what it returns, and whether the two survival curves can be had at
   arbitrary times. That table is what the dashboard side needs to see.
2. **Write an adapter for every function that can return the two curves at
   the grid times.** A function that only returns estimates at fixed times,
   or returns no curves, gets no adapter; list it in `ADAPTERS.md` as "cannot
   run here" with the reason, as the old dashboard did.
3. **The event rule stays out of the adapters.** The old dashboard found that
   these files code the event as "duration not missing" and refuse an all-1s
   event column. Write the exact rule and the column names it uses into
   `ADAPTERS.md`; it belongs in the dashboard's data preparation and will be
   added there, so that every method sees the same data.
4. **Check.** `Rscript tests/run_tests.R` passes; the App starts; the Methods
   page shows each adapter with its file name; running all of them on one
   cohort gives `ok` on the Run time & status tab; with
   `DASH_TIME_DIVISOR=1`, `DASH_TIME_UNIT=days`, `DASH_REPORT_TIMES="365, 730"`
   and `DASH_CHR_TIME=730` the IPTW Cox cumulative hazard ratio at 730 days
   matches the old dashboard's value for the same scenario.
5. **Send back** the `methods/` folder (the adapters and `ADAPTERS.md`) and
   any diff to files under `dashboard/`. Nothing from `src/` is needed.

## Skeleton

```r
METHOD_LABEL    <- "IPTW Cox"
METHOD_CLASS    <- "Singly Robust (IPW)"
METHOD_SPEED    <- "fast"
METHOD_REQUIRES <- c("survival")
METHOD_NOTE     <- "Calls run_iptw_cox_analysis() from src/analysis."
source(file.path(SRC_DIR, "analysis", "run_iptw_cox_analysis.R"), local = TRUE)

estimate_curves <- function(d, xvars, s, grid) {
  dat <- d                                  # rename columns to what the study function expects
  fit <- run_iptw_cox_analysis(dat, covariates = xvars, times = grid)   # adjust to the real signature
  out <- data.frame(time = grid, s1 = fit$surv_treated, s0 = fit$surv_control)
  attr(out, "step") <- TRUE                 # if the curves are step functions
  out
}
```

## If nothing can be copied out at all

`jobs/describe_src.R` describes the study functions without their code: each
script's functions with their arguments and defaults, the `@param` and
`@return` lines of their documentation and, with `--try`, the shape of what
each `run_*_analysis()` returns when called on a synthetic cohort (names,
classes, sizes and numeric ranges; never a function body, never a value from
the real files).

```
Rscript dashboard/jobs/describe_src.R --try
```

It writes `dashboard/output/src_signatures.txt`. A photo or a paste of that
one file is enough for the adapters to be written on the dashboard side and
sent back in `methods/`.

## What happens with no adapter at all

The dashboard wraps every `run_*_analysis()` function in `src/analysis` by
itself at startup (`R/study_methods.R`): arguments from their names, curves
read from the result. `Rscript dashboard/jobs/describe_src.R --try` says,
function by function, whether that reading works. An adapter is only needed
for a function it reports as FAILED or CURVES NOT FOUND, or one whose
automatic reading is wrong; name the adapter after the function and it
takes the wrapper's place.
