# A dashboard method, discovered from src/ at startup. Copy this file into
# src/ under the method's own name (the file name is shown beside the method
# on the page), fill in the fields and the function, restart the App.
# Delete the file and the method is gone. Nothing in the dashboard changes.

METHOD_LABEL    <- "My method"                   # the name on the page
METHOD_CLASS    <- "Doubly Robust (DR Stand)"    # the robustness class it is grouped under
METHOD_SPEED    <- "fast"                        # "fast" or "slow" (slow: left out of "Select fast methods")
METHOD_REQUIRES <- c()                           # packages it needs, e.g. c("riskRegression")
METHOD_USES     <- c("extra_out")                # the settings it reads (shown on the page)
METHOD_NOTE     <- "One line on what it does."
# METHOD_KNOTS  <- function(d, s, tmax) ...   # optional: the times the curves jump at when those are
#                                             # not event times (bin ends, every observed time)

# d      the prepared cohort: time (analysis units), event 0/1, A 0/1 (1 = treated),
#        w (the cohort's own weights column, or NA), plus the covariate columns
#        under their internal (formula-safe) names
# xvars  the covariate names to adjust for
# s      the settings list (s$ps_bounds, s$extra_ps, s$extra_out, s$interval, s$seed, ...)
# grid   the evaluation times, starting at 0
#
# Return data.frame(time = grid, s1 = <marginal survival if everyone treated>,
#                   s0 = <marginal survival if everyone control>), one row per
# grid time, probabilities in [0, 1], both 1 at time 0. Optionally attach
# attr(result, "ic") <- list(s1 = <n x length(grid)>, s0 = <n x length(grid)>)
# with each patient's centred influence-curve values to get analytic intervals.
# If the curves are step functions (Kaplan-Meier, Cox: constant between event
# times) attach attr(result, "step") <- TRUE, and the RMST integrates them as
# such; a curve that is linear between grid points needs nothing.
#
# The dashboard's own helpers are available: fit_ps(d, xvars, s), ipt_weights(d, xvars, s),
# km_curves(d, w, grid), out_formula(xvars, s), standardize_cox(fit, d, grid), ...

estimate_curves <- function(d, xvars, s, grid) {
  # example: a Cox outcome model standardised over the cohort
  fit <- survival::coxph(out_formula(xvars, s), data = d, model = TRUE)
  standardize_cox(fit, d, grid)
}
