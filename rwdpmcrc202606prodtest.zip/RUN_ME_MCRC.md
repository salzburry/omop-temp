# mCRC — test run on prod

The `deploy/` directory in this zip was produced by `platform/tools/deploy_tree.py`, which is an **allowlist**: the runtime,
the bundle, the shared product assets and mCRC's active config graph. It is not the repository minus
a few globs, and it deliberately carries none of the governance prose, specification stand-ins or
pipeline outputs. 67 files, one product.

Built from commit `3eea38e05db8` · tree `e623f7d45ca9` · evidence `868c08359e58`
`deploy_tree.py --check-tree` on this tree: **no findings — safe to package**.

---

## Read this before you run it

**mCRC is a SCAFFOLD, and this run will not publish anything.** That is the design, not a fault to
work around. `deploy_tree.py` reported `1 product(s), 0 releasable`. Concretely:

- No approved RWB workbook is registered for this pack. The pack has no `source_refs.yaml` and no
  `handoff/FUNCTIONAL_CONTRACT.md`, so Gate 1 has not started.
- `config/data_product.yaml` says `status: scaffold`, and its own header says every value marked
  `verify-vs-source` is **inferred from published RWD practice**, not reconstructed from an approved
  specification. The four `variables/*.yaml` and the codelist say `status: scaffold` too.
- `run_rwdp.py` will therefore build and stage a candidate and **stop**. It cannot reach the public
  views: publication requires `handoff/RELEASE_APPROVAL.yaml` naming a build id and manifest digest,
  which is a named person's act and does not exist for this pack.

So what a test run gives you is real and worth having: does the engine execute end to end against
your delivery, do the source tables resolve, does the ADS come out at the expected grain, and what
do the QC and output-contract checks say. It does **not** tell you whether the numbers are right —
nothing has yet checked this configuration against a specification.

---

## 1. Fill in the three placeholders

`products/oncology/mcrc/202606/config/pipeline.yaml` ships with:

```yaml
run:
  refresh: "REPLACE_ME"
  source_schema: "REPLACE_ME"
  output_schema: "REPLACE_ME"
  output_table: "rwdp_mcrc_pano_202606"
  write_mode: overwrite
```

**You do not have to edit this file.** These three are overridden per run from the job, which is why
they sit outside `config_bundle_sha256` — changing where the product runs must not invalidate an
approval of what it means. Pass them as bundle variables instead (step 3).

The bundle's own defaults are also `REPLACE_ME`, plus `mcrc_artifact_root`
(`/Volumes/REPLACE_ME/rwdp/artifacts`) and `mcrc_alert_email`. Supply the first three at minimum;
`env=prod` **hard-fails a placeholder `artifact_root`**, so supply that one too.

## 2. Confirm the source tables exist

The engine reads these from `source_schema`, under your vendor's naming (`vendor: flatiron`):

| role | table | role | table |
|---|---|---|---|
| enhanced | `t_enh_advcrc` | drug_episode | `t_drugepisode` |
| lot | `t_lineoftherapy` | mortality | `t_enh_mortality_v2` |
| diagnosis | `t_diagnosis` | orals | `t_enh_advcrc_orals` |
| demographics | `t_demographics` | baseline_ecog | `t_baseline_ecog` |
| ses | `t_socdetofhealth` | ecog | `t_ecog` |
| practice | `t_practice` | vitals | `t_vitals` |
| visit | `t_visit` | telemed | `t_telemedicine` |

A missing table fails the run loudly rather than producing a smaller cohort — that is deliberate.

## 3. Deploy and run

Deploy **from this tree**, never from a checkout. Deploying a checkout syncs the repository root
minus three globs, which pushes specification stand-ins and reference material into the workspace.

```bash
cd deploy          # NOT the repo checkout, and not this zip’s root
databricks bundle validate -t prod
databricks bundle deploy   -t prod

databricks bundle run rwdp_build_mcrc -t prod \
    --var mcrc_refresh=<your cut, e.g. 202606> \
    --var mcrc_source_schema=<catalog.schema holding the tables above> \
    --var mcrc_output_schema=<catalog.schema to write the ADS to> \
    --var mcrc_artifact_root=/Volumes/<your volume>/rwdp/artifacts \
    --var git_commit=3eea38e05db8 \
    --var release_evidence_sha256=868c08359e5851d82d171af812c2deaa8a80bb4007868522a0689211f6383b76
```

`git_commit` must match what this tree was stamped with, and the evidence digest is recomputed at
run time over the deployed bytes. A prod run without them can build and stage and can never publish.

Run `rwdp_build_mcrc`, **not** `rwdp_publish_mcrc`. The publish job sets `require_published=true`,
which turns every legitimate stop-short into a job failure — correct for a publication run, and
noise for this one, where stopping short is the job doing its job.

### If it refuses on a governance gate

`env=prod` requires `git_commit` and, when the pack is active, a `reference_table`. For a smoke test
you may pass `--var allow_governed_waiver=true`. Use it knowingly: it waives the checks that tie a
run to a commit and to a known-good comparison, so the output is a smoke-test artifact and not
evidence of anything.

## 4. What to read afterwards

Under `<artifact_root>/mcrc/<refresh>/`:

- the **build manifest** — the composite candidate verdict across source QC, ADS QC, the output
  contract, the golden comparison and the patient differential, each recorded as evaluated or not
  evaluated. A check that did not run is reported as not run, never as a pass.
- the **QC report** and the **output-contract** result. The contract checks the ADS key
  `(patientid, cohortn, index_date)`, cohort membership, and codelist vocabularies unconditionally;
  the declared checks (null limits, flag/date pairs, date order, non-negativity) run only where the
  pack configures a `qc:` block, and anything unconfigured is reported as `unconfigured` rather than
  counted as passed.

Expect the golden comparison and the patient differential to be **not evaluated**: mCRC has no
filled golden matrix (`platform/tests/fixtures/mcrc_goldens.yaml` holds ten hand-shaped patients
whose every `expect:` is still `REPLACE_ME`, awaiting RWP/RWB), and no reference ADS to diff against.

---

## What is deliberately not in this zip

- `handoff/` — the contract, decision register, QC findings and Gate 3 verdicts. `--evidence-out`
  sends those to a separate audit bundle; the runtime reads almost none of it, and it carries
  source-provenance prose a workspace has no business holding. mCRC has none of it yet regardless.
- `spec_pipeline/out/` — mCRC has never generated an extraction.
- Everything under `governance/`, `docs/`, `sandbox/` and the platform test suites.

If you want the audit bundle alongside this, it is one flag:
`deploy_tree.py --out DIR --evidence-out DIR --product products/oncology/mcrc/202606`.

---

## Verifying this zip before you deploy it

The tree carries its own digest. Re-check it after unzipping, with the copy of the tool inside it:

```bash
python3 deploy/platform/tools/deploy_tree.py --check-tree deploy
# expect: no finding(s) — safe to package
```

Adding, removing or editing **any** file under `deploy/` breaks `tree_sha256` and that check will
say so. This document is therefore kept outside `deploy/` on purpose — putting it inside was the
first thing I tried, and the check caught it.
