# NDMM cohort - recorded decisions

Choices that change who is in the cohort. Each says what was decided, what the
code does, and what still needs confirming.

A decision here is only as good as the person who made it. Pending sign-off
means the code is written and the number is reported, but nobody has signed the
record.

---

## 1. Follow-up enrolment - one day, this cohort only

Decided: the enrolment span must cover the 1L index date itself. One day,
not the three months used elsewhere.

Scope: this cohort only. Others keep three months unless changed separately.

Code: `NDMM_FU_CE_DAYS = 0`, pinned in `CONTRACT`, so changing it is a
deliberate edit rather than a setting anyone can pass. The flag is `CE_lot1_fu`
in `R/steps/06_flags.R`, built over no-gap spans and bounded by death and the
study end.

Effect: a larger cohort than three months would give. Every patient it adds
was enrolled on their index date but not for three months after. The difference
lands on attrition step 5.

Measured: `<prefix>NDMM_FU_CE_COUNTS` gives the cohort size at 0, 30, 60 and
90 days and at three calendar months, with the applied row marked.

Status: signed off. The one-day rule is the study team's decision for this
cohort. Three months is written elsewhere and anyone checking will find the
difference, so `NDMM_FU_CE_COUNTS` reports both numbers on every run and the
applied row is marked - the divergence is visible rather than argued about.

---

## 2. Belantamab - split across two packages

Decided: the exclusion runs in two halves, because no one package can see
all of it.

| half | where | why |
|---|---|---|
| before the 1L index | here, criterion 9 (`NO_BELANTAMAB_PRE_LOT1`) | `lot` cannot see it: `map_stacked` starts at the cohort's `INDEX_DATE` |
| index onward | `lot`, criterion `no_belantamab` | this package has no lines yet |

Neither half is a proxy. A belantamab claim before the index is belantamab
before the index; a belantamab treatment episode after it is belantamab in a
line.

Why the split. Lines do not exist when this cohort is built - the LOT
algorithm runs over it. A rule here standing in for LOT membership could only
approximate, and its mistakes would be unauditable: a patient wrongly removed
never gets lines, so nobody could check. Asking about a date has no such
problem, which is why the pre-index half stays here.

Bounded to the study period. The rule names no period, which read literally
means all of history. The CDM reaches back well before the study start, so an
unbounded scan would act on claims outside the window every other criterion is
bounded to - and `lot`, which settles the other half, cannot see outside it
either. The scan runs `NDMM_STUDY_START` to `study_end`. For the literal
reading, remove the lower bound in `build_ndmm_belantamab_tx()`.

What it catches: belantamab more than 365 days before the index. Such a
patient cannot be indexed on it, passes the 12-month prior-therapy criterion,
and reaches `lot` with the claim invisible. Criterion 9 overlaps
`NO_PRIOR_MM_TX` deliberately, so its incremental drop is exactly that group.

Both packages spell it the same way. One whole `CL_MED_ABBR`, matched
exactly - `BELA` by default in each. `build_ndmm_belantamab_codes()` stops if
the code list carries another `BEL*` abbreviation it does not name, because
those rows would fall outside the exclusion while the two packages still agreed
with each other. It also stops if the configured abbreviation matches nothing:
"no patient had belantamab" and "the abbreviation is wrong" give the same empty
result. `check_belantamab_abbr()` in `lot` does the same on its side, when
`APPLY_NO_BELANTAMAB` is on.

In `lot`: criterion `no_belantamab` in `R/line_criteria.R`. Patient-level -
false on every line of an affected patient - so `first_failed_lot` lands on
their earliest line and `truncate` leaves them with none. It matches a whole
`MED_ABBR` on treatment episodes in `map_stacked`, not the built lines, which
is what keeps "any LOT" literal: reading `LOT_BASE_MEDS` would bound the
question by `MAX_LOT` and by position within a line.

Downstream, and this matters:

- `<prefix>NDMM_COHORT` is the cohort pending half of one exclusion, not the
  final study population. Reading its count as the final N is wrong.
- The attrition has nine steps and its last row is still not the study's N.
- `NO_BELANTAMAB` ships on the cohort table as an advisory flag over the whole
  study period. Nothing filters on it.
- `<prefix>NDMM_BELANTAMAB_RECONCILE` lists every cohort member with a
  belantamab claim and its date. That is the handover list.
- Belantamab cannot set the 1L index. Different rule, and it stays here,
  because the index is what LOT1 anchors on.

Status: decided and implemented.

---

## 3. Eligible 1L agents - the code list is the list

Decided: `cl_mma_codelist.csv` is the study's definition of MM therapy, so
it is also the eligible-1L set. There is no separate eligibility file.

Code: any agent on that list may set the index, less steroids (dropped where
`NDMM_MMA_CODELIST` is built) and less belantamab. The earliest such claim on or
after the MM diagnosis and on or after `LOT1_FROM` is the index.

On the production file: 26 agents, so 25 can set an index. The steroid drop
removes nothing - none of `DEX`, `DEXA`, `DEXAMETHASONE`, `PRED`, `PREDNISONE`
is in `CL_MED_ABBR` - and stays as a guard against a later list that carries
them.

To bar an agent: `NDMM_INDEX_EXCLUDED_ABBRS`, empty by default. Every entry
is checked against the code list, so a name matching nothing stops the run.

What it gives up: narrowing the set now needs code rather than a file. That
is the point - the code list is authoritative.

Status: decided and implemented.

---

## 4. Other malignancy - grouping and bone metastasis

Two questions, both decided. What remains is data-dependent: the review tables
say how much each moved, and those are read after the first run.

### Grain - pair on the ICD category

Two outpatient claims confirm another cancer only if they are the same cancer.
`other_malig.csv` has 1,643 code rows and 1,618 distinct `tumor_group` values,
so the label is one per code, not a grouping - pairing on it reduces to needing
the same diagnosis code twice, and the criterion under-detects.

Code: claims pair on the first three characters of the ICD code, which
is the primary tumour type: every `C50.x` is breast, `C34.x` lung, `C79.x` a
secondary neoplasm. The cohort gets smaller, because claims that never
paired now do.

`C44` (skin), `C76` and `C80` (ill-defined sites) are broad categories, but in
each the two claims are still the same broad cancer type, which is the unit the
rule asks for.

Measured: `<prefix>NDMM_OTHER_MALIG_GROUPS` lists every category with its
code and label counts; `<prefix>NDMM_OTHER_MALIG_GRAIN` prices the change
against the per-label grain.

### Bone metastasis excludes

The rule excludes on the same primary tumour type or metastatic cancer, and
`C79.51`, `C79.52` and `198.5` are metastatic cancers. All three exclude.

Code: `NDMM_MM_ADJACENT_OVERRIDE` is four labels - monoclonal gammopathy and
the three plasma-cell disorders. Those stay because they are the index disease
or its precursor, not another cancer. Secondary neoplasm of bone is not among
them, so `C79.51` now reaches the other-cancer scan and pairs under `C79` with
the rest of the secondary-neoplasm block.

What it costs: myeloma bone disease is commonly coded `C79.51`, so some
patients removed by this will be MM patients whose lesions were coded as
metastases. That concern is real; the decision is that the stated rule governs.
`<prefix>NDMM_MM_ADJACENT_CODES` lists what the four labels still keep, and
attrition step 7 is where the change lands.

### Metastatic codes group together

The category rule works for primaries - every `C34.x` is lung - but not for
metastases. `C78.7` (liver) and `C79.51` (bone) are different categories, so two
outpatient claims documenting metastases at two sites never confirmed each
other, and the patient stayed in the cohort.

That is the wrong question to ask of them. The rule excludes on the same primary
tumour type or metastatic cancer, and metastatic cancer qualifies in its own
right - pairing two mets on site asks for the same metastasis twice.

Code: `NDMM_METASTATIC_PREFIXES` in `standalone_constants.R`. Codes matching
any prefix collapse to one group `MET`; everything else keeps the ICD category.

| in the group | | |
|---|---|---|
| `C77` | secondary and unspecified neoplasm of lymph nodes | `196` |
| `C78` | secondary neoplasm of respiratory and digestive organs | `197` |
| `C79` | secondary neoplasm of other and unspecified sites | `198` |
| `C7B` | secondary neuroendocrine tumours | - |
| `C800` | disseminated malignant neoplasm, unspecified | `1990` |

`C800` and `1990`, not `C80` and `199`: `C80.1` is a primary of unknown site and
`C80.2` a transplant case, and neither is secondary. They keep the category
rule.

What it does not do: add anything to the exclusion. This regroups codes
already on `other_malig.csv` - a code not on that file was never in scope.
`report_metastatic_group()` logs how many codes the group actually claimed and
warns if that is zero, so a prefix matching nothing is visible.

Two things to watch on the first run.

`C79.51` and `C79.52` are in this group, per the decision above, so a myeloma
patient whose bone lesions are coded that way now pairs with any metastatic
code rather than only another `C79`. Myeloma does not usually produce nodal or
visceral secondaries, so this should be small - but it is not zero and it falls
on patients the study wants to keep.

`C77` is "secondary and unspecified" neoplasm of lymph nodes, and `C800` is
used when nothing is localised. Both are weaker evidence than a sited
metastasis. If the numbers below show either doing real work, they are the two
to reconsider.

Measured: `<prefix>NDMM_OTHER_MALIG_GRAIN` has a row where metastatic codes
are kept apart by the prefix each matched instead of collapsed. The gap between
that row and the configured one is exactly what this decision costs.

It is not plain `substr(dx, 1, 3)` for that row, which would be the obvious
thing to write and would be wrong: `C800` would fall back to `C80` and rejoin
`C80.1` and `C80.2`, which are deliberately outside the group. The difference
would then net a pair the collapse adds against one it removes and
report the two as a single number.

`report_metastatic_group()` logs the code count per prefix, which says whether
a tier is represented on the code list at all - a prefix matching nothing is
named rather than silently inert. It does not say whether that tier
excluded anybody; a code count cannot.

For that, the grain table holds each watch-list tier out of the collapse while
the rest stays configured: `collapse without C77/196` and
`collapse without C800/1990`. The gap between either and the configured row is
that tier's own contribution, in patients. Those two because they are the ones
this record says to watch; `C78`/`C79`/`C7B` and their ICD-9 equivalents are
not in question, and a row each would be four more scans for a number nobody
is going to act on.

One assumption, untested. Coding guidance says a secondary neoplasm is
reported alongside its primary where the primary is known. If that holds in this
extract, most metastatic patients are already reachable through their primary
code and this group adds little. Whether it holds in Optum claims is not
something this package has checked.

Status: decided and implemented; magnitude pending the first run.

---

## 5. Study window and data vintage

Decided: `lot` takes the study window as a run argument, and defaults to
this cohort's: `2016-01-01` to `2026-03-31`.

The window is not in `lot`'s `CONTRACT`. `CONTRACT` fixes what a LOT run
means - induction windows, gap days, transplant rules - and a different value
there is a different algorithm. The window is not that: the algorithm is
unchanged and the dates belong to the cohort.

```
Rscript build.R ndmm_NDMM_COHORT ndmm_ 2016-01-01 2026-03-31
Rscript build.R MM_COH_FINAL       mm_   2015-07-01 2025-06-30
```

Both dates go to `LOT_RUN_METADATA`, so an output says which window, and
therefore which CDM vintage, produced it.

Why it has to match. `lot` bounds every claim scan by the cohort's
`INDEX_DATE` and `OBS_END_DT`, which come from the cohort table. A cohort built
to 2026-03-31 read against 2025q2 tables loses nine months of every patient's
follow-up: lines end early, treatment episodes discontinue where the patient was
still being treated, and the end reason comes out `STUDY_END`. Nothing errors
and no count looks wrong.

Made fatal. `check_cohort_window()` reads the cohort's actual date range and
stops if it falls outside the window the run was given, naming the count, the
date and the CDM vintage it would have read. `check_settings()` rejects a window
that runs backwards; `pin_study_window()` rejects dates that will not parse.

Vintage. `2026q1` is the same tables and column names as `2025q2` with data
extended through 2026-03-31 - a wider read of the same structures, so a window
that moves between them has nothing to re-validate first.

Line criteria are recorded, not just applied. `APPLY_NO_BELANTAMAB=TRUE` is
right for this cohort and wrong for one with no such exclusion, and passing a
different cohort does not change it. `report_line_criteria()` logs and records
every criterion, applied or not, with the patients it catches
(`LINE_CRITERIA_APPLIED`, e.g. `no_belantamab=on:truncate:37`). Without it,
"no patient had belantamab", "the criterion was off" and "this is not that
cohort" all produce the same `LOT_LONG_FINAL`.

Status: decided and implemented.

---

## 6. What was checked about the CDM

Assumptions this build makes, and what the vendor documentation says about
them. Check here before asking the warehouse.

`ICD_FLAG` is `'9'` or `'10'` and nothing else. The column is `VARCHAR(2)`,
so longer spellings cannot appear. Both real values are covered and anything
else yields NULL, which matches no code list. Reading every non-ICD-9 spelling
as ICD-10 would mis-class a blank flag on a genuine ICD-9 claim.

Diagnosis position is not filtered, and should not be. `DIAG_POSITION` runs
1 to 25. An MM diagnosis counts in any position, so no step reads the column.

Enrolment spans come from `member_enrollment`, not the rollup.
`member_cont_enrollment` bridges breaks of less than 30 days; the study counts
gaps of 30 days or fewer as continuous. A day's difference at the boundary,
and the rollup is stricter, so it would drop patients the study keeps. Building
the spans here bridges 30 or fewer - and only a raw build reveals the true gaps
`NDMM_ENROLL_SPANS_STRICT` needs.

Medical and pharmacy benefits are satisfied by construction. The extract
does not separate them: `member_enrollment` has 27 columns and none is a benefit
indicator. `ASO`, `BUS`, `CDHP`, `PRODUCT`, `HEALTH_EXCH` and `GROUP_NBR` are
plan structure and funding, not coverage type. A span carries both, so
`ELIGEFF`/`ELIGEND` already express the requirement and a predicate would filter
on nothing.

Do not re-derive this from claims. Enrolled patients with no pharmacy fill look
like a coverage signal and are not: that count is dominated by short spans and
by patients whose only MM code is a rule-out.

The therapy scan needs every source. `rx` holds outpatient prescriptions
only; `medical` holds professional claims coded CPT/HCPCS and facility claims.
An administered agent and a dispensed one arrive by different routes.

`med_procedure.PROC` is read as a medication source, in `overall` and here.
It finds a drug given as a procedure under a HCPCS or CPT code. The scan has
five arms: `PROC_CD`, `BILL_PROC_CD` and `NDC` in `medical`, `NDC` in `rx`, and
`PROC` in `med_procedure`.

Measured over the study period, `PROC` is 43,137,224 of ~43.2M rows at
`ICD_FLAG='10'` and seven characters - ICD-10-PCS. The five-character tail, the
only shape a HCPCS or CPT code could occupy, is about 15,000 rows: 0.035%. So it
adds very few events. It is read because the failure it guards is asymmetric - a
therapy the scan cannot see lets a patient pass the no-prior-therapy criterion
on missing data, and can move the index later than it belongs.

No `ICD_FLAG` condition, matching how `05_sct.R` reads the same column, so a
J-code with an unexpected flag is not dropped. The join is self-limiting anyway:
ICD-10-PCS is seven characters and ICD-9 procedures three or four, so only a
five-character `PROC` can equal a HCPCS or CPT code.

Adding a source can only add therapy events, so the cohort can only get smaller
and index dates can move earlier but never later. Size it from
`<prefix>NDMM_INDEX_AGENTS` and the attrition.

The SCT HCPCS branch matches little. `05_sct.R` joins `CL_CODE_TYPE =
'HCPCS'` against `mp.PROC`. Given the profile above, the HCPCS SCT codes - CPT
`38240`/`38241`, `S2150`, CAR-T `Q2042`/`Q2054`/`Q2055`/`Q2056` - are found
through `medical` in practice. Left in place as a safety net.

`CONFINEMENT` is one undeduplicated row per hospitalisation, with facility
detail bundled in. That is what makes `cf.CONF_ID IS NOT NULL` a sound inpatient
test.

Pregnancy reads diagnosis, procedure and revenue codes in both packages.
`RVNU_CD` and `BILL_PROC_CD` are unstacked from `medical` alongside `PROC_CD`.
`BILL_PROC_CD` is the facility-claim procedure code and the therapy and SCT
scans already read it; pregnancy did not, so a pregnancy HCPCS code populated
only there kept the patient. Of 5,318 codes on `pregnancy.csv`, only the 185
typed `HCPCS` can appear there. A source can only add exclusions.

`pregnancy.csv` stops the run on a code type nothing reads. The scan emits
six - `ICD9DIAG`, `ICD10DIAG`, `ICD9PROC`, `ICD10PROC`, `HCPCS`, `REV` - and a
row typed anything else would load, join, match nothing and keep the patient
with no error. The file carries exactly those six (3,049 / 1,549 / 447 / 69 /
185 / 19), so the guard passes today. It is there because the file is production
and can be re-issued, and a `CPT`-typed delivery code would otherwise be silent.

Still assumed, not documented: that NDCs match once both sides are stripped
to digits and left-padded to 11. Nothing states the width. The join guards the
failure that matters - a code with no digits and a NULL `NDC` both pad to
`00000000000` - by requiring digits on the code-list side, and
`check_ndc_shape()` profiles it every run.

`LOC_CD` marks a facility versus non-facility claim. Used only as part of
the claim key here; inpatient is classified from `POS`, `TOS_CD` and `CONF_ID`.
Changing that would change who counts as inpatient.
