# Pregnancy or childbirth anywhere in the study period.
#

# Every code_type the claim scan below can emit. A pregnancy.csv row typed
# anything else is loaded, joined, and matches nothing - the patient is kept and
# no error is raised. Named here so the guard and the scan cannot drift apart.
NDMM_PREG_CODE_TYPES <- c("ICD9DIAG", "ICD10DIAG", "ICD9PROC", "ICD10PROC",
                          "HCPCS", "REV")

build_ndmm_preg_codes <- function(con) {
  src <- load_codelist_csv("pregnancy.csv", c("code_type", "code"))
  db_exec(con, glue("
    CREATE OR REPLACE TEMPORARY VIEW {NDMM_PREG_CODES} AS
    SELECT upper(trim(code_type)) AS code_type,
           upper(regexp_replace(trim(code), '[^A-Za-z0-9]', '')) AS code
    FROM {src}
    WHERE code IS NOT NULL AND trim(code) <> ''
      AND code_type IS NOT NULL AND trim(code_type) <> ''
      -- Blank after normalising too, or a punctuation-only row matches every
      -- claim whose code is missing. See 03_prior_therapy.R.
      AND regexp_replace(trim(code), '[^A-Za-z0-9]', '') <> ''
  "))
  # A code type no source produces is a rule that cannot fire. Every other named
  # thing in this package stops the run when it matches nothing - the belantamab
  # abbreviation, the index-excluded agents, the MM-adjacent labels - and this
  # code list was the one exemption. Read on the warehouse 2026-08-02 the file
  # carries only the six below, so this passes; it is here because the file is
  # production and can be re-issued, and a CPT-typed delivery code would
  # otherwise be silent.
  # Before the code types: whether any code survived normalising at all.
  # load_codelist_csv counts raw rows, and the view above drops rows whose code
  # is blank or punctuation-only - so a file carrying one row of 'HCPCS,---'
  # is a nonempty file and an empty code list. Every candidate would then get
  # NO_PREGNANCY = 1 and the exclusion would be off with nothing to show for
  # it. The type check below cannot catch that: it reads this same view, and
  # an empty view has no wrong types in it.
  n <- tryCatch(db_q(con, glue("SELECT count(*) AS N FROM {NDMM_PREG_CODES}")),
                error = function(e) NULL)
  if (is.null(n) || !nrow(n))
    stop("Could not count the codes in pregnancy.csv, so this run cannot say ",
         "whether the pregnancy exclusion has anything to match.", call. = FALSE)
  if (as.numeric(n[[1]][1]) == 0)
    stop("pregnancy.csv has rows but no usable codes: every one is blank or ",
         "punctuation-only once non-alphanumerics are stripped. The exclusion ",
         "would match nothing and every candidate would pass it.", call. = FALSE)

  want <- paste(sprintf("'%s'", NDMM_PREG_CODE_TYPES), collapse = ", ")
  bad <- tryCatch(db_q(con, glue("
    SELECT code_type, count(*) AS n
    FROM {NDMM_PREG_CODES}
    WHERE code_type NOT IN ({want})
    GROUP BY code_type ORDER BY code_type")), error = function(e) NULL)
  if (is.null(bad))
    stop("Could not check the code types in pregnancy.csv, so this run cannot ",
         "say whether every pregnancy code is reachable.", call. = FALSE)
  if (nrow(bad))
    stop("pregnancy.csv carries code type(s) no claim source produces: ",
         paste0(bad$code_type, " (", bad$n, " code(s))", collapse = ", "),
         ".\nThey would match nothing and the exclusion would keep those ",
         "patients silently. The scan emits ",
         paste(NDMM_PREG_CODE_TYPES, collapse = ", "),
         "; either retype the rows or add the source that reads them.",
         call. = FALSE)
  invisible(TRUE)
}

# Distinct NDMM-candidate PATIDs with a pregnancy/childbirth claim (dx,
# HCPCS / ICD procedure, or revenue code) anywhere in the study period.
# Restricted to NDMM LOT1 candidates up front in each source (and again by
# the trailing INNER JOIN) so the UNION / de-dupe / codelist-join work runs
# on cohort claims only. This is logical row pruning - Spark may still
# physically scan source partitions before the join, depending on layout/
# stats - not a guaranteed I/O reduction.
build_ndmm_pregnancy_patids <- function(con, med_diag_tbl, medical_tbl, med_proc_tbl) {
  # Two scheduling-only optimisations (the matched PATID set is identical):
  #   1) Restrict every source to NDMM LOT1 candidates UP FRONT (INNER JOIN
  #      NDMM_LOT1_STARTS) instead of only at the very end. The output is
  #      DISTINCT PATID intersected with NDMM_LOT1_STARTS either way, so the
  #      early join only prunes claims that the trailing join would drop
  #      anyway. The trailing join is kept as a belt-and-braces no-op so the
  #      result stays cohort-restricted even if a future source arm forgets
  #      the push-down.
  #   2) Scan the large `medical` table ONCE: stack() emits its HCPCS
  #      (PROC_CD) and REV (RVNU_CD) rows in a single pass instead of two
  #      separate scans. The per-arm CASE reproduces the original inclusion
  #      rules exactly - HCPCS keeps a blank-after-clean code (only PROC_CD
  #      IS NOT NULL was required), REV drops blanks (trim(RVNU_CD) <> '') -
  #      and a blank code never matches a real pregnancy code, so the matched
  #      PATIDs are unchanged.
  db_exec(con, glue("
    CREATE OR REPLACE TEMPORARY VIEW {NDMM_PREGNANCY_EVENTS} AS
    WITH dx AS (
      SELECT cast(d.PATID as string) AS PATID,
             cast(d.FST_DT as date) AS event_dt,
             {icd_family_sql('d.ICD_FLAG', 'ICD9DIAG', 'ICD10DIAG')} AS code_type,
             upper(regexp_replace(d.DIAG, '[^A-Za-z0-9]', '')) AS code
      FROM {med_diag_tbl} d
      INNER JOIN {NDMM_LOT1_STARTS} l1 ON cast(d.PATID as string) = l1.PATID
      WHERE d.DIAG IS NOT NULL
        AND cast(d.FST_DT as date) BETWEEN date('{NDMM_STUDY_START}') AND date('{cfg$study_end}')
    ),
    med AS (
      SELECT s.PATID, s.event_dt, t.code_type, t.code
      FROM (
        SELECT cast(m.PATID as string) AS PATID, cast(m.FST_DT as date) AS event_dt,
               m.PROC_CD, m.BILL_PROC_CD, m.RVNU_CD
        FROM {medical_tbl} m
        INNER JOIN {NDMM_LOT1_STARTS} l1 ON cast(m.PATID as string) = l1.PATID
        WHERE cast(m.FST_DT as date) BETWEEN date('{NDMM_STUDY_START}') AND date('{cfg$study_end}')
      ) s
      LATERAL VIEW stack(3,
        'HCPCS', CASE WHEN s.PROC_CD IS NOT NULL
                      THEN upper(regexp_replace(s.PROC_CD, '[^A-Za-z0-9]', '')) END,
        -- BILL_PROC_CD is the facility-claim procedure code, and the rule
        -- covers diagnosis, procedure and revenue codes. The therapy and SCT
        -- scans already read it as an HCPCS source; pregnancy did not, so a
        -- pregnancy code populated only there kept the patient. Typed HCPCS,
        -- matching how those scans treat the column.
        'HCPCS', CASE WHEN s.BILL_PROC_CD IS NOT NULL
                      THEN upper(regexp_replace(s.BILL_PROC_CD, '[^A-Za-z0-9]', '')) END,
        'REV',   CASE WHEN s.RVNU_CD IS NOT NULL AND trim(s.RVNU_CD) <> ''
                      THEN upper(trim(s.RVNU_CD)) END
      ) t AS code_type, code
      WHERE t.code IS NOT NULL
    ),
    icd_proc AS (
      SELECT cast(p.PATID as string) AS PATID,
             cast(p.FST_DT as date) AS event_dt,
             {icd_family_sql('p.ICD_FLAG', 'ICD9PROC', 'ICD10PROC')} AS code_type,
             upper(regexp_replace(p.PROC, '[^A-Za-z0-9]', '')) AS code
      FROM {med_proc_tbl} p
      INNER JOIN {NDMM_LOT1_STARTS} l1 ON cast(p.PATID as string) = l1.PATID
      WHERE p.PROC IS NOT NULL
        AND cast(p.FST_DT as date) BETWEEN date('{NDMM_STUDY_START}') AND date('{cfg$study_end}')
    ),
    events AS (
      SELECT * FROM dx
      UNION ALL SELECT * FROM med
      UNION ALL SELECT * FROM icd_proc
    ),
    matched AS (
      SELECT DISTINCT e.PATID, e.event_dt
      FROM events e
      INNER JOIN {NDMM_PREG_CODES} p
              ON e.code_type = p.code_type AND e.code = p.code
    )
    SELECT m.PATID, m.event_dt
    FROM matched m
    INNER JOIN {NDMM_LOT1_STARTS} l1 ON m.PATID = l1.PATID
  "))
  # Two readers now - the exclusion below and the window counter - so it is
  # materialised rather than left a view, or Spark rescans the three claim
  # sources once per reader.
  checkpoint(con, "NDMM_PREGNANCY_EVENTS")
  # The exclusion, unchanged: distinct patients with a matched claim anywhere in
  # the study period. It reads the dated view rather than repeating the scan, so
  # the window this criterion applies and the window the review table prices
  # cannot drift - which is the failure a second copy of this scan would invite.
  db_exec(con, glue("CREATE OR REPLACE TEMPORARY VIEW {NDMM_PREGNANCY_PATIDS} AS SELECT DISTINCT PATID FROM {NDMM_PREGNANCY_EVENTS}"))
}
