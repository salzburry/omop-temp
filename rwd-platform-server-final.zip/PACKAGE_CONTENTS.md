# Package contents

The package retains the portal, Python/R engine, all platform tools, reusable
templates, master variable library, terminology, semantic validation, agent
evaluation infrastructure and operational Help.

It starts with no registered product instances or scheduled jobs. Product configuration,
source connections, user access and model connection are supplied by the installation.
Python and declared libraries must be installed on the destination; Spark and the
model service are supplied by the chosen runtime.

The master library retains scientific terminology, citations and recorded review
status. Technical tests and evaluation case definitions are retained to support
maintenance; cases requiring unavailable inputs are not offered as product evidence.
See INSTALL.md and PACKAGE_VERIFICATION.json.
