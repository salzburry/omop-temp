# The authoring-UI boundary — what any Gate 2 front-end may and may never do

Gate 2 currently asks a clinician to hand-edit a YAML form and commit it. That is workable
for engineers and a real adoption ceiling for everyone else, so an authoring front-end (web
form, portal page, chat flow) is an expected build. This document is the boundary that keeps
such a build from silently undoing the trust model. It is written BEFORE any UI code exists,
because the failure it prevents is architectural: **the moment any service can supply
`answered_by`, every guarantee downstream of Gate 2 evaporates.**

## The one rule

A front-end is a **veneer over the same refusal-first tools, plus a transport for what a
person actually typed**. It renders what the tools print, carries the person's own keystrokes
into the committed form, and lets the repository's write paths do the only writing. It never
computes an answer, never fills a field, never interprets a refusal, and never holds a
credential that lets it write governed files on its own authority.

## MUST (each item is testable)

1. **Same tools, same refusals.** Every action the UI offers is one of the existing CLI
   verbs (`decision_record --forms/--apply/--record-event`, `contract_record`, …), invoked
   unmodified. A refusal is surfaced VERBATIM — the refusal text is the product, and a UI
   that softens, retries, or "helpfully" works around one has become a second, weaker
   authority (the class of defect B7 was: a second publication algorithm).
2. **The person types the attestation.** `answer`, `answered_by`, `answer_date` (and every
   approval signer/date field) reach the form ONLY as the authenticated person's own input,
   written verbatim into the same committed YAML form the CLI flow uses. The UI may
   pre-fill NOTHING in these fields — not the logged-in name, not today's date. Convenience
   pre-fill is exactly how "a name nobody typed" comes back.
3. **Identity comes from the forge, not the app.** The commit that lands the form is
   authored by the person's own authenticated identity (their session with the git host,
   per `governance/APPROVAL_IDENTITY.md`). The UI service holds no token that can push to
   the governed repository. If the service commits, the service is the approver — that is
   the design being refused.
4. **Hash bindings are checked at render time.** A form is shown only as issued by
   `--forms`; if `question_sha256` / `records_sha256` are stale the UI shows the refusal
   and the re-issue path, never an editable form over a moved question.
5. **One act per screen.** Answer or withdraw one decision; no batch-sign, no
   "approve all", no default-selected status. `RESOLVED` is chosen by the person each time.
6. **The ledger seals stay downstream.** Recording an event (`--record-event`) happens
   through the same CLI verb after the form is committed — the UI cannot append to the
   event ledger directly.

## NEVER

- Never a CLI flag, API parameter, or config knob that supplies an attestation field.
  Enforced TODAY by `test_governance.py::test_no_write_path_accepts_an_attestation_from_a_flag`
  over every tool's argparse surface — the ban predates the UI so it cannot arrive as
  "just one convenience flag" in a refactor.
- Never a service-held write credential over governed paths (see MUST 3).
- Never auto-fill, remembered values, or templates inside attestation fields.
- Never a summary of a refusal in place of the refusal.
- Never an answer suggested, drafted, or defaulted by the UI or by any model behind it —
  ranking and packet assembly are the loop's contribution; the answer is a person's.

## Threat cases, each bound to its owner

| Tamper | Owned by |
|---|---|
| Form forged / edited after signing | row↔form binding (`decision_record --check`), payload digest vs ledger head |
| Answer transcribed onto a changed question | `question_sha256` staleness refusal |
| Record edited while its question was open | `records_sha256` staleness refusal |
| Service commits as a person | forge authentication + branch protection (Phase 3 owner item) |
| Replayed apply | idempotent waves — re-apply prints `already recorded` |
| UI softens a refusal into a warning | MUST 1; acceptance test on verbatim refusal text |

## What this is not

Not a build plan, not an endorsement of any particular stack, and not a loosening of the
skill rules: the session/agent rule ("the session types NONE of the three, in any mode")
stays as written. A UI changes who can reach the loop, never what the loop accepts.

## Stated limits

The argparse pin covers `platform/tools/*.py`; the HTTP layer EXISTS (`app/serve.py`) and its
parameter surface is pinned by `platform/tests/test_app_serve.py` — including its one POST route,
which is proposal-only: it composes a patch and hands it back, and applies nothing. (This
sentence called HTTP "future" after it had shipped — audit 2026-09-02.) Forge identity and branch
protection are organisational controls (`docs/PRODUCTION_READINESS.md` Phase 3) — the
boundary assumes them and cannot substitute for them.
