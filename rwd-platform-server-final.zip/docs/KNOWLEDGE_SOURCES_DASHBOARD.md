# Knowledge sources and definitions

Open **Definitions and sources → Knowledge sources and definitions**. The default
view, **Semantic sources and graph**, brings the existing semantic tools into one
read-only dashboard. **Definitions and evidence** retains the existing searchable
library, citations and review actions. Links for a particular variable continue
to open that search view.

## What is integrated

RDF/JSON-LD, SKOS and PROV-O describe governed concepts, product implementations,
source citations and recorded provenance. SHACL validates the generated graph and
its declared cross-record constraints. The existing semantic export workflow
requires conformance before it can save an export. Product semantic bindings also
participate in release identity and checks.

YAML and reviewed contracts remain the execution authority. This dashboard adds
neither a remote graph server nor a graph-to-code compiler. RDFS labels/comments
and limited OWL retirement metadata are visible; no general OWL reasoner is
connected. SPARQL is used within SHACL constraints.

## Inspect a knowledge source

Choose a source from **Knowledge source to inspect**, then select **Open source
details**. The dashboard provides the recorded path, full contents, content digest
and a download of the inspected source. Sources include product semantic bindings,
the scientific contract, registered documents, extracted specification rows, shared
analytical definitions, naming lifecycle, master inventory, reusable logic and
terminology layer settings. Missing or malformed sources remain visible as gaps.

Selecting a source does not change its contents. Product bindings can be reviewed
through **Review product concept bindings**, using the existing scientific workflow.

## Inspect and validate a graph

**Load current knowledge graph** calls the existing governed projection without
running SHACL. Select a graph record to see all recorded properties, incoming and
outgoing object relationships, citations, provenance and named-graph membership.
A diagram shows up to 15 relationships; the accompanying table retains all of
the selected record's relationships. Full JSON-LD declarations and SHACL nodes,
including embedded constraints, are inspectable and downloadable.

**Validate this graph with SHACL** regenerates and checks the exact graph and
shapes against current inputs. A changed input, graph digest or shapes digest
withdraws the result. Not loaded, not run, stale, findings and conforms are distinct
states. A processor being installed is not a passing validation result.

The graph inspector reads explicit JSON-LD objects; it does not fetch context URLs
or infer extra equivalence. Validation uses the existing RDFLib/pySHACL processor.

Local inspection uses the reserved `https://preview.invalid/rwd` namespace and
does not publish or save an export. **Open the semantic export workflow** continues
to the existing namespace, versioning and delivery controls for an external consumer.

