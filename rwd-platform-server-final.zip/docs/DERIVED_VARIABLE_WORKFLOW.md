# From a specification row to a derived output

Extraction preserves what the specification requests. A requested variable does
not have to exist as a column in the delivered data. The scientific definition
states whether it is supplied by the vendor, calculated, a parameter or a
constant. Source mapping then connects the required raw inputs to actual tables.

## Example: follow-up end date

This is an illustrative dependency chain, not a scientific rule to adopt:

| Layer | Example | What needs to be recorded |
|---|---|---|
| Raw input | Visit date and treatment date in different tables | Actual table/column mappings and record identifiers |
| Intermediate calculation | Last qualifying visit; last qualifying treatment | Which events count, patient/index scope, date window and tie handling |
| Combined calculation | Follow-up end date | How intermediate dates combine; cutoff, death and missing-input rules |
| Consumer | Follow-up duration or study eligibility | Its dependency on the reviewed end date and index date |

A maximum date is not automatically the correct follow-up rule. Likewise, no
observed event is not automatically evidence of no event. Those choices belong
in the reviewed definition and its expected-result examples.

## Where to enter this in the portal

1. In **Flow → Write the definition here**, use **Meaning**, **Timing** and
   **Missing values** to describe the calculation and its scope.
2. In **Source and names**, select **derived** for **Where the value comes
   from**. The expanded example explains this case. Put upstream definition
   identifiers under **Declared dependencies**. Raw inputs need their actual
   mappings; calculated inputs refer to their definitions. Do not manufacture a
   source column with the requested output name.
3. Review existing definitions and naming decisions before reusing them. Name
   similarity alone does not establish that two calculations mean the same thing.
4. Give the calculated output its intended name/type and write expected results
   under **Review**. Validate the definition, inspect its diff, and save the
   checked record. Saving does not implement or approve the calculation.
5. Continue through source requirements and mapping for the actual delivery.
   Reuse an existing implementation only when its behavior matches the reviewed
   definition. Otherwise, use the connected engineering handoff and implementation
   review, including the existing pipeline and expected-output tests.

## Preparing execution from the reviewed variable table

In **Definitions and sources → Review the variable list**, complete the scientific,
source and output reviews. Under **Output review**, open **Prepare executable
settings**. It shows the saved definitions, the native engine fields they can use,
and proposed configuration changes. Save or discard any output edits first.

For a standard treatment-line variable, explicitly choose its line, numbering and
attribute in the scientific review. The execution panel supports regimen, start
date, delivered end date and last-activity date. It can propose the matching global
numbering and increase the configured number of lines. Product settings use their
explicit reviewed values, including the current product's study dates.

If a name differs, **Use engine field …** saves the chosen native physical name and
reopens the output review. For example, `LOT1DATE` can bind to `lot1sd`; the requested
published name remains metadata. This action does not implement a new column alias.

After confirming the tables, choose **Stage supported settings** to open the exact
configuration proposal and its checks. Unsupported definitions stay in its
implementation handoff. If all requested work needs new code, **Prepare
implementation handoff** creates that proposal without inventing configuration
changes. Open it to inspect the reviewed definitions and request engineering work.

The existing definition-draft and canonical-contract handoff is still required.
Neither staging settings nor requesting implementation approves or releases the
product. If reviewed inputs change, prepare a fresh proposal from the current table.

## What the existing code checks

- `platform/tools/contract_lint.py` resolves declared dependencies and rejects
  self-dependencies and cycles between definition records. A reference to a
  specification variable preserves a dependency; it does not prove that the
  referenced variable has been implemented.
- `platform/tools/source_requirements.py` collects configured source roles and
  columns. `platform/tools/contract_binding.py` checks declared implementation
  references and output bindings. Neither substitutes for scientific review.
- `platform/engine/stages/clinical.py::follow_up_and_death` already implements a
  configurable follow-up calculation from several feeds. Its existing rules must
  be compared with the new product's requirements before reuse.
- `platform/engine/stages/ads_derived.py` supports configured expressions,
  intervals and landmark calculations after the assembled analysis frame exists.
  Items run in configuration order. This is not an automatic compiler of arbitrary
  specification prose or a general dependency scheduler.
- The publication checks reject missing declared published columns. Strict
  output-contract checks also reject unevaluated required checks. A development
  run without a declared publication surface is not evidence that every requested
  variable exists.

The implementation must put prerequisite calculations before their consumers and
test actual output values, types, grain and missing-input behavior. A dependency
list alone does not generate working code. Study-only exclusions remain in the
study plan; they do not remove shared inputs needed by other calculations.
