# Your first data product

Start with the research you want the product to support. For example: “We need a
reusable product for treatment patterns and outcomes, with study-specific
exclusions kept separate.” You can write this in the page's chat when an assistant
is connected. Review any proposed field changes before copying them into the form.
You can also use the same forms directly.

1. **Choose a starting point.** Use New product for a new tumour or another product
   of an existing tumour. Use the existing-tumour option when a familiar disease
   needs a different source or use. Choose a next cut only when an existing
   product's specification has changed. Reference examples show structure; their
   approvals do not transfer to your product.
2. **Describe the product and source.** Name the intended studies, select the actual
   vendor and modality, and attach the specification you are entitled to use.
   Keep uncertain source permissions open. Preview shows what registration will
   create; creating the draft opens Progress and next step.
3. **Interpret one requirement at a time.** After extraction, choose a specification
   row. Read its source wording, then explain its meaning, timing, missing values
   and dependencies. Save unfinished work whenever needed. The connected assistant
   can explain a question or propose choices; “not sure” should remain an open
   question, not an invented rule.
4. **Reuse names and map inputs.** Compare existing names and definitions before
   proposing an output name. A similar name does not establish the same meaning.
   Identify the actual source table and columns. A calculated output may depend
   on raw columns and earlier defined outputs. If implementation is missing,
   continue through the existing engineering handoff and code review.
5. **Review changes and check again.** Validate a definition and inspect its
   before/after change before writing it. Use Plan changes for shared configuration
   revisions and consumer impact; keep study-only exclusions in their separate
   section. The status check tells you the next missing evidence. Saving a draft
   alone does not complete scientific or source review.
6. **Inspect the produced results.** Reviewed implementation changes can run the
   available synthetic pipeline tests. Read their actual pass, fail and skip
   results and input versions. A missing R/Spark prerequisite is not a passing
   comparison. Save shared work on your branch for your company's review process.

For claims, register the draft, use **Attach specification**, then **Configure
claims criteria** from Progress and next step. You can inspect the generated R
and export manifest; a governed claims execution service is not included here.
Another condition outside oncology can be saved as an unfinished setup; do not
relabel it to pass the registration checks.

If you are stuck, ask the connected page assistant “What is missing on this
page?” or open Resolve next step. The technical handoff is for the responsible
data expert or engineer. You do not need to guess a command or supply an approval
merely to ask for an explanation.

The local application supports drafting, implementation review and the available
synthetic tests. A local identity label or signing key does not independently
authenticate a reviewer. Actual data use and release require the source,
scientific and company controls described in [production readiness](PRODUCTION_READINESS.md).
For installation or reconnecting a model, see [local setup](LOCAL_INSTALLATION.md)
and [assistant setup](PORTAL_ASSISTANT_SETUP.md).
