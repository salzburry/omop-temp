# Running the whole journey from chat

For the researcher interface, use the [RWD Portal](../experiments/portal/README.md).
Its Flow page shows the next blocker and a focused Resolve dialog; product creation,
change planning and evidence reading are available without opening a terminal. This
page describes the operator chat workflow and the tools behind its handoffs. The portal
also loads these repository skill sources for the current task; they are no longer
instructions available only to an operator's chat session.

## The same skills in the portal

The [9 September assistant integration review](ASSISTANT_CONTEXT_INTEGRATION_20260909.md)
records the connected scientific context, question choices, coding follow-ups, source
requests and study metadata, with regression evidence and current limits.

| Repository skill | Place in the main workflow |
|---|---|
| `operate-rwd-product` | Progress, the product guide, validation specialist and release readiness |
| `draft-contract-record` | Guided definition drafting and implementation assessment |
| [`implement-product-rule`](../.claude/skills/implement-product-rule/SKILL.md) | Engineering handoff, coding specialist and reviewed implementation proposals with pipeline tests |
| `answer-decisions` | Questions, answer choices and AI-assisted answer drafting |
| `propose-variable-name` | The definition editor's source/name step and prior-name lookup |
| `propose-source-mapping` | Source evidence, mapping review and the source specialist |
| `apply-source-verdicts` | The source-verdict application step reached through Progress |
| `next-cut` | Revision comparison, specification drift and checked carry-forward |

The guide uses the skill for the open task; the definition and answer assistants and
the three specialists load their own task's instructions directly. These are current
`SKILL.md` sources, not a duplicated prompt library. Model requests use explicitly labelled
excerpts when the complete skill exceeds the selected connection's context budget. Saved
responses bind the complete source digest, and a changed skill requires a new response.
Skills supply procedure, not citable scientific evidence or approval. The portal's controls
still call the existing canonical validators and explicit write handlers.

See the [integration and adversarial test report](WORKFLOW_KNOWLEDGE_ASSISTANT_INTEGRATION_20260907.md)
for the main-flow connections, verification and runtime limits.

The chat interface is not a future feature — it is how this repository is operated today. Claude
Code **is** the chat surface: open this repo in VS Code with the Claude Code extension (the panel
is the "popup") or run `claude` in a terminal at the repo root, and type the questions below in
plain language. The skills in `.claude/skills/` cover the recurring governed workflows —
drafting contract records, answering decisions, applying source verdicts, proposing source
mappings, proposing variable names, implementing reviewed rules, starting the next cut, and operating a product; a request
outside those workflows goes straight to the tool that owns it,
with `governance/INDEX.yaml` as the routing map. Nothing here bypasses a gate — the chat
drives the same tools CI verifies, and the acts that need a named human still refuse a session.

## One loop, one thing on screen

The many files under `<pack>/handoff/` are the **ledger, not the interface**. Nobody browses that
folder from chat: `DECISIONS.md` is the register the tools write, `SCIENCE_QUESTIONS.md` is a generated
ranked view of that same register (CI fails if it drifts — the two can never disagree), and the
rest is DataExpert/Engineering working evidence. The only files a stakeholder ever *opens* are the answer forms
in `decision_answers/` — one small YAML per question, and only to type their answer and name.

What chat shows is a loop of four turns, each producing **exactly one page**, repeated until the
question list is empty:

1. **"where do we stand"** → one status view: the six gates, the blockers, the single next action
   and who owes it.
2. **"what do you need from me"** → one ranked question page for the PACK — highest
   blast-radius first, evidence and precedents on the same page. (The page lists each
   question's owner; it is one page per pack, not one page per answerer — several owners
   share it and read their own rows.)
3. **The person types their answers** into the named forms and commits — the one step outside
   chat, by design. Chat points at the exact file; it never types the values.
4. **"the answers are in"** → one all-or-nothing wave (`decision_record.py --apply`), one unblock
   worklist back, and turn 1's standing has moved.

The session rule the skills enforce: **one artifact per turn**. If an answer seems to need two
pages, it is two turns — nothing else pops up alongside.

## The journey, as chat

| you type | what runs | what you get |
|---|---|---|
| "where does prostate stand" / "what is blocking us" | `operate-rwd-product` → `status.py` | the six gates, blockers, next action and its owner |
| "stand bladder up" (a person types the three Gate 1 fields) | `new_product.py` (preview; `--apply` to write) | the plan — eleven files across four directories — staged, run through every validator the repository owns, and written all or none; the pack stands at the start of Gate 1 with nothing asserted that nobody decided |
| "what would the product carry" | `dictionary` (the read tool) | the data dictionary PREVIEW: every contract variable with type, domain, status and required rule, from the contract, no data behind it |
| "how many are left after each criterion" | `quick_counts.py --step "label: col=value"` | the criterion-level attrition table in the exploration lane — remaining and dropped per step under the same floor and rounding, never a person; the kept feasibility request carries the exact command |
| "extract the new spec" (a person registers the workbook first) | `run_spec_pipeline.py` | extraction + lint + coverage, `--check`-fenced |
| "draft the record for clinical:61" | `draft-contract-record` → `contract_record.py --item` | a lint-clean record quoting the spec verbatim (I22) |
| "what should we ask Science" | `answer-decisions` → `decision_report.py`, `decision_packet.py` | questions ranked by blast radius, one page per pack with each question's owner named. Each card names its own answer form, and where EXACTLY ONE other product holds a resolved ruling paired through the precedents store, the card carries a labelled **proposal** — that ruling verbatim, "for you to accept or edit; your name goes on it either way". Zero rulings propose nothing (drafting from evidence prose would be the tool interpreting a specification); two or more propose nothing and say why — choosing which ruling transfers is the judgment the page routes to a person |
| "have we decided something like this before" | `knowledge_graph.py --query` | every pack's ruling, with approver, date and citations |
| "what do we know about X, anywhere" | `knowledge_search.py <terms>` | every surface at once — decisions, precedents, contract records, the shelf, capabilities, citations — each hit carrying WHAT KIND of authority it has and how far that has been taken |
| "Science's answers came back" | `answer-decisions` → `decision_record.py --forms` / `--apply` | the signed forms transcribed, all-or-nothing, plus the unblock worklist |
| "apply the source verdicts" | `apply-source-verdicts` → `contract_record.py --apply-verdicts` | Gate 3 evidence moved into the two evidence-fed axes |
| "what sources does this pack need" | `source_requirements.py` | the requirement matrix: role, availability state, required columns, which blocks read it, expected grain |
| "what could supply biomarkers" (a profile TSV exists) | `propose-source-mapping` → `propose_source_mapping.py` | ranked mapping candidates with counted evidence and blockers — a person applies or declines; `--validate` re-checks a choice, and `mapping_benchmark.py` says how far to trust the ranking |
| "show me this rule three ways" | `rule_review.py` | the spec's words, the interpretation, and the YAML that runs, side by side — the page an approver reads |
| "implement this reviewed rule" / "adapt existing code for this product" | `implement-product-rule` → coding specialist and implementation review | inspect existing capabilities, code and tests; propose a scoped implementation and meaningful expected-output tests. Missing scientific or source decisions return to their owner. Retained code runs through the existing reviewed pipeline validation; a proposal does not approve science or release a product |
| "what should this variable be called" / "does agegrp already exist" | `propose-variable-name` → `naming_registry.py` | the cross-pack name registry, the standard spelling recommended, near-misses and format conflicts as QUESTIONS — a person rules in `governance/NAMING_RULINGS.yaml`, never the tool |
| "has another tumour already defined this" / "do two packs mean the same thing by INDEXDT" | `concept_reuse.py` (a pack for what it could inherit; no argument for the cross-pack view) | compare definitions, derivations and review evidence across packs. `governance/NAMING_RULINGS.yaml` records spelling decisions. Reusing a physical name with different scientific fields surfaces a row comparison and a Gate 4 check; acceptance requires reviewed registered implementations and, for distinct definition identifiers, exact sealed equivalence evidence. A lexical match does not establish shared meaning. Unapproved source records remain open scientific questions. |
| "can we actually explain this variable end to end" / "what can't this product answer about itself" | `competency.py <pack> --variable <ID>` (omit `--variable` for coverage over every record) | the ten lineage questions a governed product must answer — which spec row defines it, what the contract says, which config block runs it, which adapter binds the sources, which decisions it hangs on, which goldens pin its edges, which build produced it, which datasets implement it, whether another dataset's implementation is poolable — each answered from a committed artifact or marked NOT ANSWERABLE with the reason. Lineage only: what a rule *should* say stays Science's |
| "what would this variable be in mCODE?" / "crosswalk this pack to the oncology standard" | `mcode_crosswalk.py <pack> --dictionary <mCODE STU4 .xlsx>` | ranked mCODE profile/element CANDIDATES per variable with the evidence for each match, and a named reason where nothing plausible is found. Proposes only — concept equivalence is a person's ruling, and no identifier is minted here |
| "let a clinician review the semantic layer" / "what bands should this tumour use?" | `review_workbook.py concepts <tumour> --out X.xlsx`, then `read-concepts <filled> <tumour>` | the semantic template as ONE spreadsheet: a Concepts tab (every concept, whether this tumour instantiates it or holds it available, and its required slots) and a Slots tab where a person writes the actual band list or window, each slot carrying its own description so nobody guesses. `read-concepts` verifies the ids and the template fingerprint, refuses an unowned input, and PRINTS — it never writes into the repository |
| "what should this tumour define?" / "give me the semantic template for mcrc" | `semantic_export.py --template <tumour> --base-iri https://…` | the per-tumour semantic template as NAMED GRAPHS — the WHOLE concept space (identical for every tumour — never a private copy) split into what this tumour instantiates, with the parameter slots each definition must state, and what it does NOT use, recorded as AVAILABLE rather than omitted so the next cut reuses the name instead of re-deriving it. Nothing is approved and no slot is filled: a person fills each from the approved workbook |
| "give the enterprise graph our approved meaning" / "export this pack as RDF" | `semantic_export.py <pack> --base-iri https://… --out X.jsonld` (`--shapes` for SHACL, `--check` for staleness) | a JSON-LD projection in the W3C vocabularies — SKOS concepts, PROV-O lineage, light OWL relations — generated from APPROVED records only, with drafts withheld and counted. Concept and implementation stay two identifiers; equivalence appears only where a person ruled it. One-way: the graph is a read-only projection, never an authoring surface, and no build ever consults it |
| "this name is retired — what replaces it" / "can we reuse that name" | `naming_registry.py --retire <name>` | the draft retirement entry with its machine half filled, for `governance/NAME_LIFECYCLE.yaml`. Mint once, never reuse: a retired name that comes back carrying a NEW variable id is reported as reuse, because every citation written against the old meaning would silently read as the new one. The same file records an enterprise IRI beside a name, when one has been minted |
| "the revised workbook landed" | `next-cut` → `spec_diff.py` / `--carry-plan` | what provably carries, what needs re-reading, where |
| "run the build" / "validate it" | `run_rwdp.py` (Databricks), the Spark test suites | candidate vs published, goldens, QC — Gate 5/6 evidence |
| "how did the build behave, stage by stage" | `local_smoke.py --stage-telemetry` locally; the `stage_telemetry` widget on a governed run | per-cohort join counts at every stage boundary and per-item selection counts (candidates, ties, non-null outputs) — evidence a person reads, never a verdict |
| "what does the delivery look like BETWEEN tables" | `eda_report.py` (`--synthetic` for the shape; `eda()` composed on the cluster for the facts) | layered counts: inventory and null keys, grain, patient overlap and fan-out vs the index source, date sanity, the cohort funnel, the output contract |
| "where did this number come from" | `receipt.py <pack> --variable X` | one variable's whole chain on one page: the spec's words, the contract record, the decisions (quoted from the register), the config blocks, the name's registry entry, the build manifest — absence printed as absence |
| "is this cohort even big enough to bother" | `quick_counts.py` (the exploration lane) | counts-only feasibility, small cells pooled; a column no contract defines must be `--assume`d and logged to the intake ledger or the query refuses — `--intake` turns the ledger into demand evidence for the decision loop |
| "one page for the steering meeting" | `executive_page.py --out ~/exec.html` | every pack's six gates and next owner, plus the leverage table: which open decision unblocks the most contract records — the gate tools' own verdicts, rearranged |
| "show me the semantic view" / "can we pool rwPFS across Flatiron and claims" | `semantic_view.py <pack>` (`--pooling VAR A B` for one pair) | the tumour's conceptual layer: every contract variable with its derivation, each dataset's implementation, and the pooling state per source pair — a recorded human ruling from `governance/EQUIVALENCE_RULINGS.yaml`, or NOT ESTABLISHED with the question routed to DataExpert/Science; the tool never rules |
| "put the pages where stakeholders can read them" | `publish_site.py --out <dir>` (`--serve` to preview) | every read surface regenerated into one hostable folder with an index — commit-stamped, input-free, absences listed with their reasons (docs/PILOT.md is the participation runbook) |
| "is my draft workbook ready to hand off" (an Science author asks) | `spec_precheck.py <draft.xlsx>` | the governed pipeline's own extraction and lint over a DRAFT, in fix-it language, exit 1 on blocking findings — a courtesy check that registers nothing and approves nothing |
| "is the platform actually compounding" | `precedent_metric.py` | per pack: decisions, open, resolved, and CANDIDATE precedent coverage against other packs' resolved rulings — every match a question a person confirms, nothing marked answered by the tool |
| "give the reviewer one Excel file" / "the review came back" | `review_workbook.py build <pack> --out X.xlsx` / `read <filled> <pack>` | one workbook per pack — a tab per domain with lint severity beside every extracted row, four reviewer columns to fill; `read` verifies the extraction fingerprint and item ids, refuses drift and unowned decisions, and PRINTS the review — transport, never approval |
| "bind this role to the delivered table, typed" | `source_adapter.py skeleton <pack>` / `check <pack>` | the typed source-adapter contract: per role — physical table, column types and parsers, grain, join cardinality, vocabulary, units, review binding. `skeleton` derives the machine-knowable half; a person fills and signs; `check` refuses partial coverage, TODO types, invented cardinalities and unowned reviews. A checked adapter set with a `dataset:` label is the semantic view's second implementation — the moment the equivalence axis goes live |
| "which delivered column carries this?" (a second vendor, or a second tumour from the same one) | `propose_adapter.py <pack> --profile <p.tsv>` | the column half of the adapter, from the delivered profile: for every column a stage reads, the candidate physical names RANKED with the evidence behind each — normalised name match, shared tokens, delivered kind, missingness, distinct count, top values — plus a `logical_type` proposed from the kind. A TIE is reported as a tie and refused, because choosing between two plausible columns is the judgment this routes to a person. `--patch` prints the block to paste; it writes nothing, and `source_adapter.py check` is what holds the committed file to the engine |
| "promote this reviewed concept into the reusable library" | `template_promote.py --from-pack <pack> --candidate` | a TemplateRelease carrying the reviewed MEANING — clinical role, this cancer's definition, shape, source requirements, evidence and parameter slots, each pinned by `concept_sha256` — cut only from an APPROVED contract, a signed semantic approval and a ruling `match()` still calls confirmed. Prints a manifest; never edits the registry. `--check-releases` refuses an invalid or duplicately versioned library, and `--check-adoptions` re-resolves every pack's recorded pin against the release's own digests |

The whole journey — spec extraction, contract records, ranked questions, config, tests and
release machinery — runs conversationally, every write through a tool that refuses what a
session must not do.

## What chat deliberately cannot do

Approvals, signatures, decision answers, maturity claims. Those arrive only as **committed file
edits by a named person** — the forms in `handoff/decision_answers/`, the approval YAMLs, the
`source_refs.yaml` record. A chat interface that could perform them would be the hole the whole
design exists to close. The chat's job is to make the human act tiny and exactly located.

## For people who will never open VS Code

The read-only surfaces are HTML, generated out-of-checkout and shareable:

    python platform/tools/render_html.py flow <pack> --out ~/flow.html      # the status page
    python platform/tools/decision_packet.py <pack> --out ~/questions.html  # the pack's question page
    python platform/tools/executive_page.py --out ~/exec.html               # every pack + the leverage table

And for a live DEMO there is a chat page that needs no VS Code and no scripts:

    python platform/tools/chat_demo.py        # then open http://127.0.0.1:8377

Three backends, one boundary. `--backend auto` (the default) picks **api** when a key is present
and otherwise the **router**; it never auto-selects **cli** — that one is an explicit, eyes-open
`--backend cli` because the child inherits the environment (`--backend` forces any of them):

  * **claude CLI (no key)** — anywhere Claude Code is installed and logged in, the page is the
    end-to-end ASSISTANT on the operator's own seat: no key is ever provisioned, and the
    allowlist is enforced by Claude Code's OWN permission engine — the model's only permitted
    command is `chat_demo.py --tool …`, which funnels through the same validated allowlist.
  * **API** — with `ANTHROPIC_API_KEY` set and `pip install anthropic`, the same assistant over
    the Messages API. No model is pinned in this repository: pass `--model` or set `ANTHROPIC_MODEL`.
  * **router** — with neither, a fixed intent table maps the questions above to one read-only
    tool each. No model at all.

In every backend the tool's output arrives with the command printed underneath, the model's
only reach is the six read-only tools, and anything approval-shaped gets the standing refusal
BEFORE any model is consulted. Localhost only.

A hosted deployment (Databricks Apps is the ratified route; Domino only as a review surface)
serves the same read surfaces with no script at all: `app/serve.py`
(run by `app.sh`) is the read-only board, and its `/start` page walks a new person through
this exact journey — parsed from this document per request, so the page and this file
cannot drift apart.

## The standalone AI chat page, and why its boundary is small

`chat_demo.py`'s assistant mode IS the second harness this section used to warn about — built
with the boundary the warning demanded. The model holds no shell, no filesystem, and no write
path: its entire reach is six validated read-only argv arrays (`_tool_argv` is the allowlist,
test-pinned), the approval refusal fires before the model sees the message, and every command
it triggers is printed under its reply. What it deliberately still cannot do is everything in
"What chat deliberately cannot do" above — a model with a tool for typing an answer form would
be the approval hole, so no such tool exists. Anything BIGGER than this page (hosted for
stakeholders, authenticated, multi-user) should start from this same shape: grow the tool list
one read-only argv at a time, never hand the model the repository.
