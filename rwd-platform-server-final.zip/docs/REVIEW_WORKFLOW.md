# Review workflow for the local company application

Product authors work in their own company Git branches. Review and merge take
place in the company's Git Enterprise repository. The local portal prepares
records, diffs and validation evidence; it does not authenticate a reviewer from
a display name or establish release authority from a Git merge.

## Author, validate and request review

1. Create a working branch from the company's current default branch.
2. Use the portal to prepare definitions, mappings, configuration proposals or
   implementation changes. Keep shared-product changes and study-only exclusions
   distinct and inspect the before/after comparison.
3. Run the checks appropriate to the actual change. Attach counted results and
   exact code/configuration versions. Missing runtimes and interrupted tests must
   remain visible; a quick local check does not replace the full CI lane.
4. Open a pull request explaining the resulting behavior, the evidence and any
   unresolved scientific or source questions. Do not include credentials, private
   drafts, patient records or unapproved source material.
5. Obtain independent review from the responsible scientific, data or engineering
   owner. A self-merge is not independent review. Resolve findings and rerun checks
   affected by the resulting edits.
6. Merge only after the company's required reviews and status checks pass. A
   merged implementation still needs the product's applicable scientific,
   source, build and release evidence before a patient dataset is consumed.

## Configure repository controls

Repository administrators must replace placeholder CODEOWNERS with real teams,
require review and CI checks on the default branch, and control who can bypass
those rules. These settings are server-side controls; copying source files does
not enable them. Use the company's repository hostname and authentication setup.

## Approval identity remains a separate requirement

An authenticated Git account identifies the account performing a repository
operation. A registered signing key proves possession of that key and binds
signed bytes. Neither alone establishes that a named scientific reviewer has
independently authenticated and approved the relevant product evidence.

The local application distinguishes signatures from authenticated approvals.
Reviewer setup does not create or self-enrol signing keys. Independently
administered enrolment, authenticated review and accountable company ownership
are required before claiming authenticated approvals. Adding a `person_review`
entry or changing an approval baseline cannot satisfy that missing integration.
Follow [approval identity](../governance/APPROVAL_IDENTITY.md) and
[production readiness](PRODUCTION_READINESS.md).

Historical test and audit reports retain their original scope. They do not
establish that the importing repository has review controls or that a current
product has been approved. Reference examples carry no approval into a new study.
