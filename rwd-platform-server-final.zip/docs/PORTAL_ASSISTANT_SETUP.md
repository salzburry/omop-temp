# Portal assistant: setup and use

The scientific-definition editor combines suggested choices, custom text and optional
AI drafting. AI responses are proposals. The drafter chooses which answers to use,
then runs the normal validators and reviews the contract diff.
Recorded scientific questions use the same configured assistant connection and
offer guided starting points, custom text and optional AI answer options.

## Use your local Claude Code sign-in without an API key

The portal can run the standalone, unmodified Claude Code CLI using the account
you signed into through Claude Code. It does not call the extension's private
interface, reuse an extension conversation, or read your Claude credentials.
Installing only the VS Code extension does not put the standalone CLI on PATH.
[Claude Code in VS Code](https://code.claude.com/docs/en/vs-code#run-cli-in-vs-code)

1. Install the standalone CLI using Anthropic's installer if it is not already
   available. In VS Code's terminal, run `claude auth login` and complete Claude's
   own sign-in flow. If already signed in, `claude auth status` checks that state.
2. In VS Code's **Run and Debug** menu, choose **RWD Portal: Claude Code local
   sign-in** and run it. The launcher opens an available local port. Alternatively,
   start the portal normally and select **Claude Code (local sign-in)** under the
   sidebar's **Scientific assistant** section.
3. Choose **Check assistant connection**. This checks installation and sign-in
   metadata without sending a question or generating a model response.
   Cached sign-in metadata can remain present after credentials expire. If a
   suggestion request reports an expired sign-in, run `claude auth login` again;
   the portal does not start login or retry the request automatically.
4. Use the existing **Suggest answers for this row** or **Explain and suggest
   answers** buttons. Selecting this connection applies to both scientific editors.

The setting is local to your portal session. Switching between Claude Code and
VS Code chat requires fresh AI suggestions; your authored draft remains. You can
set `RWD_PORTAL_AI_PROVIDER=claude_code` before launch to make it the initial
choice. `RWD_PORTAL_CLAUDE_CODE_MODEL` selects a full Sonnet model identifier;
the initial supported selection is `claude-sonnet-4-6`. The account must have
access to the selected model. `RWD_PORTAL_CLAUDE_CODE_EXE` can identify the
standalone native executable outside the checkout when it is not on PATH.

This local connection uses your own Claude Code account. It does not enable
extra usage, buy credits or fall back to an API key. Account limits and any
account-enabled extra usage still apply; it is not a promise of free or unlimited
use. Sign-in stays in Anthropic's unmodified binary, as described in its
[authentication guidance](https://code.claude.com/docs/en/legal-and-compliance#authentication-and-credential-use).
This first connection supports personal Pro/Max sign-ins. It reports a clear
unsupported-configuration message for managed installations or credential-helper
settings that could change the isolated request. It does not change those policies.

Requests contain only the selected, access-reviewed source context and your draft.
The CLI runs with tools, MCP connections and session persistence disabled, in a
temporary empty working directory. Prompts are not passed to a shell. Source
access checks, bounded response validation and explicit draft acceptance remain
in force. This option is limited to the local demo; it is not a shared account
backend for a deployed portal.

## Use GPT-5 mini or Claude Sonnet through VS Code

The local prototype connects the row editor to GPT-5 mini or a Sonnet model available through
VS Code's Language Model API. It does not reuse an existing conversation. The
Claude Code extension runs its own assistant and does not, by itself, expose a
model to that API.

1. Build and install this repository's local extension from the VS Code terminal:

   ```powershell
   .\.venv\Scripts\python.exe experiments/vscode-model-bridge/package_extension.py
   code --install-extension experiments/vscode-model-bridge/dist/rwd-portal-model-bridge-0.1.2.vsix
   ```

2. Open this repository in VS Code. Press **Ctrl+Shift+P** and run
   **RWD Portal: Connect Chat Model**. Choose **GPT-5 mini** or the available
   **Claude Sonnet** version and provider. Complete VS Code's model-access prompt if it appears. The command
   tests access with one short request containing no product information.
   If the new command is missing after an extension update, run **Developer:
   Reload Window** in VS Code, then open the command palette again.
3. Set `RWD_PORTAL_AI_PROVIDER=vscode` in `experiments/portal/.env` and start or
   restart Streamlit with the command below. Keep the connected VS Code window open.
4. In the scientific row editor, expand **Ask AI to help with this row**. The
   connection and actual model appear above the request. Click **Suggest answers
   for this row** to make a request; opening the editor does not generate an answer.

If the model you want is unavailable, use **Chat: Manage Language Models** in VS Code to
configure the intended provider. Access depends on the account's configured
chat provider. The bridge discovers what is available and never substitutes a
different model. [VS Code model setup](https://code.visualstudio.com/docs/agent-customization/language-models)

GPT-5 mini is the exact `gpt-5-mini` model, not GPT-5.4 mini, GPT-5.1 Codex mini or
GPT-5 nano. The model's displayed name, provider and ID come from VS Code. Adding
this option does not change a subscription, grant model access or guarantee free
usage. OpenAI API pricing is separate from whatever access your VS Code provider
supplies. [GPT-5 mini model](https://developers.openai.com/api/docs/models/gpt-5-mini)

Run the Connect command again to switch models deliberately. A quota or access
error never switches models automatically. The older **RWD Portal: Connect Claude
Sonnet** command remains available for Sonnet-only selection.

Run **RWD Portal: Disconnect Model** to end the connection. Closing VS Code,
changing workspace folders or changing the model list also disconnects it.
The portal reports the missing connection and keeps manual drafting available.
It does not switch to the direct Anthropic adapter automatically.

The bridge uses authenticated HTTP on a random `127.0.0.1` port. Its private
connection file is `~/.rwd-portal/vscode-model-bridge.json`, outside the repository.
Do not copy this file into the product or share its token. This prototype connects
programs on the same computer; a remote server or container does not share that
loopback connection. See the [extension README](../experiments/vscode-model-bridge/README.md)
for transport limits and security details.

## Local settings and Streamlit launch

The portal reads these environment settings when it starts:

| Setting | Purpose |
|---|---|
| `RWD_PORTAL_LOCAL_DEMO=1` | Enable the local draft workflow. A demo identity label is not authentication. |
| `RWD_PORTAL_AI_PROVIDER` | Initial choice: `vscode`, `claude_code` or `anthropic`. The local sidebar can change it for one session. There is no automatic fallback. |
| `RWD_PORTAL_CLAUDE_CODE_MODEL` | Full Sonnet identifier for the local Claude Code CLI; default `claude-sonnet-4-6`. |
| `RWD_PORTAL_CLAUDE_CODE_EXE` | Optional absolute path to the installed native Claude Code executable outside the checkout. |
| `ANTHROPIC_API_KEY` | Used only by the direct `anthropic` row-assistant adapter. |
| `ANTHROPIC_WORKSPACE_ID` | Workspace header for the direct adapter when required by the credential. |
| `RWD_AGENT_MODEL` | Direct adapter only: a model registered in `experiments/agent/models.yaml`; otherwise the registry default. The VS Code route uses the model chosen in its Connect command. |

For a local session, set them in `experiments/portal/.env` using
[the blank example](../experiments/portal/.env.example). This file is ignored by Git.
Keep real credentials in local configuration or the deployment's secret settings;
this document intentionally contains none. Restart the server after changing settings.

From the repository's VS Code terminal:

```powershell
.\.venv\Scripts\python.exe -m streamlit run experiments/portal/app.py
```

The local `.env` loader works with this command. Environment activation is optional
because the command names the repository's Python interpreter. The Windows launcher
[Start-RwdPortal.cmd](../Start-RwdPortal.cmd) is another way to start a fresh server.
Use the URL printed by the server or launcher.

These settings select the scientific-row and recorded-question helpers. The older general chat and intake
features retain their own direct-provider configuration; the bridge does not
silently reroute those features.

## Answer a scientific-definition row

1. Open the product's **Flow**, choose **Check status**, then **Resolve next step**.
2. Choose a specification row and read its original wording and values.
3. In **Meaning**, write the interpretation and choose what **One value per** means.
   Common questions offer choices, **Write my own answer**, and **Not sure yet**.
   No new answer is selected automatically. **Edit this answer** expands a selected
   answer into text. A not-applicable answer needs its own explanation.
4. For drafting help, expand **Ask AI to help with this row** and choose **Suggest
   answers for this row**. An optional request can identify the part needing help.
5. Read each suggestion, its source quotation, assumptions and questions. Select
   only the answers you want and choose **Use selected suggestions in my unfinished
   draft**. Other current answers are preserved; the functional contract is unchanged.
6. Continue the remaining sections. In **Review**, validate the complete record,
   review the diff and explicitly save a checked draft to the contract. Open
   scientific questions and review requirements remain separate.

The AI helper uses only the selected eligible extraction row and the current
scientific answers. It does not read patient-data files or reuse other products'
definitions. Source mappings, dependencies, implementation, output/publication
settings and definition identifiers remain manual. The helper cannot call tools or
approve, build or release a product.

Each generation has a 45-second deadline and no automatic retries. The direct
adapter sets a 2,000-token output limit and checks a conservative cost ceiling from
the model registry. The VS Code bridge bounds returned text to 2,000 counted tokens
and 24 KB, cancelling streams that exceed its limits; VS Code and the provider
control billing and quotas. This is not a provider billing guarantee. A changed
source, identity, private draft, working answer, provider or model connection
invalidates the proposal. Unaccepted proposals expire after 30 minutes.

## Work through recorded scientific questions

The question editor is shared by **Questions to answer**, the workflow's question
links and **Prioritise questions across my products**. In the priority list, choose
**Help me answer this question**. You can filter the list to the selected product;
reference-example questions remain labelled with the example they belong to.

1. If the answer forms have not been issued, choose **Prepare question drafts**.
   This copies the current questions into blank forms using the existing form
   generator. It preserves existing answers and leaves the register's questions open.
2. Choose a starting point under **How would you like to draft the answer?**
   Every question offers a complete-answer outline, a way to work through its parts,
   **Write my own answer**, and **Not sure yet**. Where the exact question supplies
   alternatives, those alternatives appear too. Nothing is selected automatically.
3. For model help, expand **Ask AI to explain this question and suggest options**
   and choose **Explain and suggest answers**. This uses the configured VS Code
   model or explicitly selected direct provider. It sends only this issued question,
   its literal evidence text, your current answer and optional help request.
   Referenced files are not opened and other portfolio questions are not sent.
4. Read the explanation, candidate answers, exact context quotations, assumptions
   and remaining questions. Select one option explicitly and choose **Copy selected
   option into my draft answer**. The answer stays unsaved and includes a TODO
   marker. AI never fills the decision maker or decision date.
5. Make the scientific decision with the appropriate reviewer, complete the answer
   and resolve its TODOs. Under **Review and record the decision**, enter the actual
   decision maker and date, then choose **Save this answer**. Merely removing a
   marker is not scientific review. The existing form and register validators run
   before saving; stale inputs and unfinished markers are refused.

Complex questions such as a cohort-by-outcome matrix need a structured answer and
the relevant reviewed artifact. A single MCQ cannot establish every scientific
choice in that matrix. AI options help draft the answer; a quotation from an open
question does not prove a ruling.

The existing source-access gate also applies to question AI. Some reference packs
still require an authenticated review of their current sanitized extraction; the
panel explains this and links to product progress. Manual choices and custom
drafting remain available. AI proposals are bound to the current question, evidence,
answer, actor and model connection and expire after 30 minutes. Copying them does
not persist a decision, authenticate an approval or release a product.

## Can the portal use the assistant already running in VS Code?

Launching Streamlit from VS Code does not connect the Python application to VS Code's
chat model. MCP servers expose tools and context to an AI host; they do not, by
themselves, supply its model. Local stdio servers normally have a dedicated client
connection. [MCP architecture](https://modelcontextprotocol.io/docs/learn/architecture)

This repository already registers `rwdp` in [.mcp.json](../.mcp.json). It runs
[mcp_server.py](../platform/tools/mcp_server.py), which exposes governed read tools,
including product status, definitions and validation checks. It has no model endpoint
or write path. The portal already calls the same canonical readers and validators.

| Connection | Current support |
|---|---|
| Portal → configured Anthropic model | Implemented for optional row drafting, with explicit acceptance into a private draft. Works when launched from VS Code or independently. |
| VS Code assistant → `rwdp` MCP tools | The repository supplies the MCP configuration and read-only server. This shares product tools, not the assistant's model session. |
| Portal → VS Code's available GPT-5 mini or Sonnet model | Implemented as the local extension bridge above, with explicit model selection and per-field acceptance. Requires a model exposed to the VS Code API and model access. |

The bridge uses the supported VS Code Language Model API. Its instruction and row
context are separate User messages because the stable API has no system-message
role. It adds no editor files, chat history or tools. Model availability, consent
and quotas still apply.
[VS Code Language Model API](https://code.visualstudio.com/api/extension-guides/ai/language-model)

## When help cannot run

| Message or condition | Next action |
|---|---|
| No provider selected | Set `RWD_PORTAL_AI_PROVIDER` in local configuration and restart the server. |
| VS Code bridge missing or inactive | Run **RWD Portal: Connect Chat Model** in this checkout's VS Code window, then retry in the portal. |
| Requested model unavailable in VS Code | Configure its provider through **Chat: Manage Language Models**, then run the Connect command again. The Claude Code panel alone is not this model provider. |
| `unsupported_response` during Connect on extension 0.1.1 or earlier | Update to 0.1.2 and run **Developer: Reload Window**, then connect again. Earlier versions rejected normal reasoning and provider metadata. The updated bridge discards these known events and keeps final text; tools and other unsupported content still fail. |
| Connected, but generation says the bridge belongs to a different checkout | Check that Streamlit and VS Code use the same repository. The Python adapter now verifies filesystem identity and sends the bridge's advertised path, fixing false Windows `c:` versus `C:` mismatches. Refresh the portal after updating; if its server still has the older adapter loaded, restart Streamlit. This Python fix works with the already connected 0.1.2 extension. |
| Direct Anthropic credential missing | Configure the explicitly selected direct adapter and restart the server. Do not put credentials in a row or help request. |
| Extraction is not eligible for AI | Complete the recorded source-access review for the current sanitized extraction through the workflow. Restricted or redacted material requires its designated review path. |
| Source or working answers changed | Keep the current edits, reload the source when prompted, and explicitly generate fresh suggestions. |
| Invalid or unsupported AI response | Continue manually or explicitly request new suggestions. Rejected responses do not update the private draft or contract. |
| A new derivation or source mapping is needed | Use the engineering handoff and source/configuration workspaces. An AI sentence is not an implemented derivation. |

This setup and workflow description does not assert scientific approval, authenticated
review or release readiness.
