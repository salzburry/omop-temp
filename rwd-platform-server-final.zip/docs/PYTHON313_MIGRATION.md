# Python 3.13 local application migration

The local application and CI target Python **3.13.13**. VS Code's RWD Portal
launch configurations use the selected interpreter for both the debugger and the
portal. Backend jobs, coding-agent checks, generated workflow commands and local
review commands use that same interpreter.

| Component | Current target |
| --- | --- |
| Python | 3.13.13; launcher accepts the 3.13 series and reports patch drift |
| PyYAML | 6.0.3 in portal, backend and generated bundle dependencies |
| Streamlit | 1.62.0 |
| Optional local PySpark | 4.0.4 |
| Optional local Java | 17 or 21 |

The dependency manifest is an actual Windows AMD64 capture from Python 3.13.13.
Its 66-package closure excludes optional Spark and R. Constraints and metadata
describe the Python environment; they do not constitute pipeline output evidence.
Historical Python 3.11 test records remain historical.

## Use an existing VS Code environment

Choose **Python: Select Interpreter**, select your Python 3.13 environment, and
open a new terminal. Verify the selected interpreter before installing:

```powershell
python --version
python -m pip install -c experiments/portal/environment.constraints.txt -r requirements.txt -r platform/requirements.txt
python -m pip check
```

For local synthetic builds, install the engine in the same environment:

```powershell
python -m pip install pyspark==4.0.4
```

Use a RWD Portal launch configuration in VS Code. For an external environment
outside VS Code, pass `--python PATH` to `experiments/portal/launch_portal.py`, or
set `RWD_PORTAL_PYTHON`. An explicit selection is authoritative; an invalid one
does not silently fall back. A server from another interpreter is not reused.

If the old environment is Python 3.11, create a separate `.venv313` or an
environment in a short local directory. Selecting a new interpreter does not
upgrade an existing environment. See [Local installation](LOCAL_INSTALLATION.md)
for commands. `.venv313` is excluded from Git, product staging, workbook discovery
and source-content checks, just like `.venv`.

## Why the Spark pin changed

The initial Python 3.13 run reproduced three actual synthetic stage failures with
Spark 4.0.1 on Windows. Workers exited while writing their results. This matches
Apache's [SPARK-53759](https://issues.apache.org/jira/browse/SPARK-53759), whose
upstream fix first shipped in Spark 4.0.3. The 4.0.4 maintenance release includes
that fix. No Python standard-library or installed Spark files are patched locally.

The existing Spark stage suite now exercises the simple-worker path in Linux CI
as well as Windows. A regression requires two worker actions to return exact
computed values and verifies that worker and driver Python versions match.

## Validation scope

Local checks on 9 September 2026 used Python 3.13.13 in a separate environment;
the checkout's existing Python 3.11 environment was preserved. These are targeted
runs, not a claim that the entire CI lane was rerun.

| Check | Observed outcome |
| --- | --- |
| Portal/backend dependency installation and `pip check` | Installed with captured constraints; no broken requirements |
| Environment manifest, markers and constraints | 19 tests passed |
| Launcher, interpreter selection and process lifecycle | 75 tests passed, including real Streamlit startup, health and owned stop |
| Generated workflow and review commands | 38 tests passed |
| Broad backend/portal migration regressions | 658 tests passed across 17 suites |
| Three researcher journeys | Fresh product and source revision passed initially; template/two-study journey passed after moving the test temporary directory to a supported shorter path |
| Selected Spark stages and worker regression | 4 passed on Spark 4.0.4; 48 unrelated cases deselected |
| Complete selected-product synthetic build | Passed through the existing implementation runtime, checking expected output values and an empty-cohort case |
| Selected Python/R stage conformance | 2 passed with actual R execution required; 16 unrelated cases deselected |
| Repository quick checks | 12 passed; no failures or skips |

The initial Spark 4.0.1 run failed three selected stage cases. All three passed
after upgrading to 4.0.4, alongside the new worker regression. The temporary-path
failure in the template journey was the existing explicit Windows path-length
guard; neither that guard nor the journey assertion was relaxed. The 658-test
run preceded the final chat synchronization edits; subsequent targeted chat/UI
regressions validate that separate change.

Local validation does not authenticate scientific approval or release a product.
Company-hosted CI and real-data validation remain separate. Managed Databricks
cluster runtimes retain their declared provider runtime; selecting Python in
VS Code does not upgrade a remote cluster.
