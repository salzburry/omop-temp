# Engineering notes

`README.md` describes what this repository is; `governance/WORKFLOW.md` describes the six gates. This
file covers the things that are easy to get wrong and expensive to get wrong.

## Before writing a predicate, a parser, or a checksum: check for the existing one

The rule with the worst track record here is duplication. A second implementation of an existing
concept is dangerous in a specific way: the two agree when written and diverge later, on either side
of a decision that matters. A checksum written by one and verified by the other; a status word one
gate accepts and another refuses. That is not a style problem — it is how a governed gate comes to
pass something it exists to stop.

A test asserting two modules share the same function *object* (`a.fn is b.fn`) is worth more than two
tests asserting they agree.

### Where the shared definitions live

Check these before adding to them. All are low in the import graph, so importing from them is
generally safe — `source_manifest` and `source_check` already import from `product_gates`, so
`product_gates` must never import back from those.

**`platform/tools/contract_lint.py`** — owns the CONTRACT and its registers (stdlib only, so every
product's test wrapper can run it standalone).
`decision_rows` · `cell` · `has_register` · `decision_status` · `register_errors` ·
`decision_register_errors` · `open_decisions` · `records` · `read` · `source_kind` ·
`vendor_sourced` · `unverified_sources` · `spec_digest` · `SOURCE_KINDS` · `NOT_VENDOR` · `ID_RE` ·
`DECISION_STATUSES`

`ContractRecord` · `parse_block` · `typed_records` · `typed_errors` · `parse_spec_ref` · `SpecRef` — THE
TYPED CONTRACT (programme item 1). `records` keeps yielding block text, because thirty-four readers speak
that shape; `typed_records` is the same reader followed by `parse_block`, which keeps every cell verbatim
(so `render_row(rec.as_mapping())` is the row as written, byte for byte) and parses the structured cells
once — spec refs, the status axes, source/output/publish maps, the reference lists. A new reader takes
the typed record and never re-derives a field from tokens; `contract_binding` was the first converted
(its `physical_name` regex over the whole file read names out of prose). `typed_errors` is the structural
half of I3/I6/I19/I20 stated by the object itself; on a committed pack it is a subset of what the lint
refuses (platform/tests/test_contract_typed.py holds that). The Markdown table stays the record of truth
and stays hand-editable; no YAML/pydantic here — the pack test wrappers run this file standalone.

`register_errors` is the one structural validator for those registers — required columns, duplicate
ids, blank and unknown statuses — parameterised because `DECISIONS.md` and `SPEC_QC_FINDINGS.md` are
the same shape with different vocabularies. `decision_rows` is the one reader of any `| ID | … |`
markdown register; it locates columns **by name**, since anything positional breaks on the first
product that orders its table differently. `cell` is the one way to read a named column out of a row
— case- and spacing-insensitively, with `default=None` distinguishing an ABSENT column from a blank
cell, which the gates depend on. `has_register` is the one definition of the canonical header, which
separates "QC found nothing" from "nobody looked".

**`platform/tools/definition_registry.py`** — owns ANALYTICAL DEFINITION IDS (programme item 2):
governance/DEFINITIONS.yaml is the mint-once register, keyed namespace:master-family:v-n, each entry
carrying the digest definition_signature.py derives over the approved configuration it names and the
UMLS concept it realises. `read` · `register_errors` · `current` · `signed` · `resolve` · `unregistered`
· `superseded_signed` · `propose` · `pack_errors` · `checkout_root` · `implementations` ·
`implementation_errors` · `propose_implementations` · `supports` · `check`. A pack's definitions resolve
BY SIGNATURE, never by name — two configurations that compute the same thing carry the same id, one
that changed a window is a new version — and --propose writes the entry a person completes. Three
consumers hold the same id: product_gates.configuration_approval_errors refuses configuration:approved
over a signed definition the register does not carry or has superseded (advisory below that level); a
definition axis in config/semantic.yaml (semantic_binding.errors) must be registered, current and the
one this pack's configuration signs; and an equivalence ruling or a sealed equivalence answer may name
definition_a and definition_b — both or neither, each registered, the ruling agreeing with the answer —
under the one rule in decision_record.equivalence_definition_errors. semantic_view.rulings also decides
ONE RULING PER PAIR over the whole file: two rulings on a pair refuse both and semantic_view.pooling
reads the pair as conflicted, so file order never decides comparability. `checkout_root` finds the
register beside the pack (a temp copy carries its own), which is what keeps every check runnable on a
disposable checkout. Programme item 3 sits on the same ids: a dataset's config/implementations.yaml
claims, per contract variable, the registered definition it implements (`implementations`,
`implementation_errors`, `propose_implementations`); the semantic view carries each claim on the
implementation that made it, and a ruling that names the definitions it compared applies only where
both implementations claim exactly those — configuration:approved refuses a claim that does not resolve.

**`platform/tools/approval_record.py`** — owns APPROVALS AS LEDGER EVENTS (programme item 5): `FORMS` ·
`event_payload` · `form_errors` · `record_event` · `sealed_errors` · `claimed_objects` · `check` · `trust`
· `attest`. Each of the four approval forms seals as its own object kind; `form_errors` runs the owning
gate's check (the release form through source_manifest.publish_approval_errors with
require_sealed=False, the others through product_gates) so a seal never records an approval the gate
refuses; `sealed_errors` is what Gate 6 asks. Beside it, event_ledger gained the signing-key
register (governance/SIGNING_KEYS.yaml: event_ledger.signing_keys), event_ledger.attest,
event_ledger.verify_attestation, event_ledger.trust_of, event_ledger.sign_target and
event_ledger.public_key_b64, over platform/tools/ed25519_pure.py — the one signature primitive, RFC
8032 in the standard library, held to the RFC's vectors — so that authenticated is derived from a
verified signature under a registered, active key and never written on an actor.

**`platform/tools/product_gates.py`** — owns pack DISCOVERY and the gate vocabulary.
`requirements_sha256` · `mapping_sha256` · `gate3_evidence_errors` · `claim_consistency_errors` — the
acceptance case's four: the Gate 2 and Gate 4 approvals pin the requirement content, the Gate 3 report
pins the mapping content, and Gate 3's evidence and the configuration-claim consistency are ONE owner
each, so the status page attributes them (a finding no per-gate check accounted for used to hold Gate 1).
`required_evidence_errors` (the files a maturity claim obliges, by axis) · `approval_tolerance_errors` (the
tolerances an approved ehr configuration must rule) — the walkthrough's two: split out of `maturity_errors`
so status.gates files them under Gates 2 and 4 by asking the owner, never by reading the message.
`products` (shape-based, any depth) · `maturity` · `union_members` · `verdict_rel` · `sha256` ·
`unstated` · `bad_date` · `spec_qc_errors` · `approval_record_errors` · `contract_approval_errors` ·
`configuration_approval_errors` · `waiver_errors` · `read_yaml` · `pack_yaml` ·
`config_bundle_sha256` · `delivery_sha256` · `PACK_FILES` · `WAIVED` · `QC_STATUSES` ·
`PLACEHOLDERS_PREFIX` · `PLACEHOLDERS_EXACT` · `QC_ACCOUNTED` · `WAIVER_FIELDS` ·
`CONTRACT_APPROVAL` · `CONFIGURATION_APPROVAL` · `*_APPROVAL_FIELDS` · `registry_entry` ·
`evidence_route` · `uses_data_profiler` · `vendor_policy_errors` · `VENDOR_POLICY` ·
`SCHEMA_EVIDENCE`

`evidence_route` is the one answer to "does this product use the data profiler". The route is
DECLARED per vendor in `governance/vendor_policy.yaml`, overridable per product on the registry
entry, and it FAILS CLOSED: an unknown vendor or unreadable policy refuses rather than defaulting to
"run", because a tool must not read patient-level data on the grounds that nobody said not to.
`registry_entry` matches family/slug and deliberately NOT `current_spec_version` — the vendor is a
property of the product, not of a spec revision.

`approval_record_errors` is the one reader of a formal approval form. Gate 2 and Gate 4 both ask
who / when / over which bytes; each supplies only its own field list and hash targets.

`read_yaml` is the one reader of a governed YAML FILE — it catches the parse AND rejects a
non-mapping root, because `- a\n- b` parses fine and then kills the caller with `AttributeError`.
Every gate reads through it, so a tool keeping its own `yaml.safe_load` is a gate that crashes
instead of reporting.

`pack_yaml` is the one resolver of a pack's ACTIVE config graph, and `config_bundle_sha256` digests
it. The binder and the Gate 4 approval subject must be the same set of files, or an approval covers
something the build does not execute. `delivery_sha256` is the separate DELIVERY digest (refresh,
source schema, data format, source layout) that Gate 3 governs.

**`platform/tools/source_manifest.py`** — owns Gate 1's vocabulary for a source material, and the one
answer to "may this pack publish".
`AI_CLASSES` · `AI_CLASSIFICATION` · `APPROVAL_FIELDS` · `POLICY_FIELDS` · `ATTESTATION_FIELDS` ·
`PENDING_FIELDS` · `materials` · `authoritative` · `source_status` · `resolve` · `vendor_prose` ·
`redact_vendor_prose` · `boundary_report` · `AI_READABLE` · `ai_extraction` · `ai_readable` ·
`ai_extraction_block` · `redaction_policy_sha256` · `AI_EXTRACTION` · `AI_EXTRACTION_FIELDS` ·
`AI_EXTRACTION_APPROVAL_FIELDS` · `releasable` · `evidence_verdict` · `RELEASE_EVIDENCE` ·
`delivery_drift` · `receipts_for` · `validation_verdict` · `publish_approval_errors`

`receipts_for` is the one reader of a pack's committed refresh receipts (matched on each manifest's
own `tumor`/`spec_version`, never its path) and `validation_verdict` reads the newest — or a named
build's — composed candidate verdict out of the receipt's stage blocks through
engine.refresh.candidate_verdict, never out of a stored summary (programme item 4). Gate 5 on the
status page reads it: a receipt whose verdict failed a stage holds the gate with the stage named, and a
pack with no receipt is told so. `publish_approval_errors` takes the candidate manifest at promotion
and refuses an approval over a candidate whose composed verdict failed — an approval binds a build, it
does not make a failed candidate releasable.

These field tuples are mirrored by `governance/schemas/source_refs.schema.json`, which CI validates
every pack against. A parity test holds the two equal — edit one and edit the other, or a pack passes
CI while Gate 1 refuses it.

`ai_readable` is the one answer to "may AI read this pack", and it asks about the DERIVED artifact —
the sanitized `extracted.json` registered as `material_type: ai_extraction` — never the input it came
from. Reading the input's class is unsafe: a sponsor-authored document can quote vendor
documentation and still be recorded `sponsor_ai_eligible`. The approval binds to the BYTES (`sha256`
on `path_or_link`, which must name the file the slicer opens), to the run
(`extraction_fingerprint`), to the policy (`redaction_policy_sha256`) and to the counts it shows a
person — so editing the artifact, re-extracting, or weakening the marker list all revoke it. It
requires `status: reviewed`, because a signature beside a `why_provisional` is two statements about
one artifact. The whole `derived_from` ANCESTRY must be free of `vendor_restricted`, not just the
parent. No tool may fill in the five human fields, including the classification, so
`--register-ai-extraction` prints them as TODO and the pack stays red until a person answers.

`vendor_prose` DETECTS reproduced vendor documentation and `redact_vendor_prose` REMOVES it, side by
side so one marker list serves both — a redactor cleaning a different set than the check refuses
would leave a pack simultaneously sanitized and blocked. The redaction runs in `spec_extract` AFTER
`content_hash`, so `spec_digest` still binds a record to the real specification text; the sponsor's
stand-in is never edited, because `attested_against_sha256` records that it is faithful. Nothing the
redactor emits may contain a marker, including its own notice — naming which markers fired would put
them back in the file.

`releasable` DERIVES the release decision from Gates 1–4; `evidence_verdict` reads that same decision
back out of a `RELEASE_EVIDENCE.yaml` that `deploy_tree.py` wrote. A production tree cannot re-derive
it — the stand-in Gate 1 needs is deliberately not deployed — so the recorded form exists, and
everything that makes it safe (commit binding, `is True` rather than truthiness, refusing
cleared-and-blocked) lives in that one function.

**`platform/tools/profile_io.py`** — the one fail-closed reader of a `data_profiler.R` profile TSV.
`load` · `provenance` · `table_base` · `CUT` · `REQUIRED` · `PROVENANCE` ·
`FULL_PROFILE`

The STAMPED `profile_cut` is the cut identity; the `CUT` table-name suffix only corroborates it.
Reading the cut from the name alone would make one vendor's naming convention load-bearing for every
tumour.

**`platform/tools/contract_record.py`** — the one renderer of a contract row, and the one place a
drafter's judgment is merged with the spec's evidence. `row_for` · `merge_evidence` · `load`

`contract_scaffold.MACHINE_OWNED` / `evidence_for` own the fields the SPEC establishes — `spec_refs`,
`spec_digest`, `required_rule`. `--item <domain:row>` supplies them and the tool REFUSES a draft that
also carries them: a retyped digest fails I15 loudly, but a tidied-up `required_rule` replaces the
spec's exact words with a paraphrase and nothing fails at all. `--product` is REQUIRED
(`--format-only` is the named opt-out) because I8, I15, I17 and the reference checks need the pack.

**`platform/tools/spec_slice.py`** — the one way to assemble one drafting unit's context.
`slice_pack` · `render` · `STYLE_CAP` · `DROP`

It re-derives nothing: domains come from `extracted.json`'s own `domain` field, records through
`contract_lint.records`, decisions through `contract_lint.decision_status`. Recomputing a domain from
the tab label here would be a second mapping free to disagree with the pipeline's — and the tab label
is exactly what differs per tumour. An unknown domain FAILS naming the ones that exist, because an
empty slice reads exactly like a specification that says nothing.

It carries an index of all three registers for the rows in scope — decisions, QC findings, gaps — so
a drafter reuses an id instead of raising the same thing under a second one. Register citations it
cannot resolve to a row are REPORTED, never dropped: dropping one makes a recorded defect read as "no
finding here".

**`platform/tools/finalize.py`** — the one place a pack's stated SUMMARY is checked against the
evidence it summarizes. `facts` · `claim_errors` · `claim_text` · `scope_errors` · `section_errors` ·
`CLAIMS` · `contract_header`

It DERIVES every number from the tool that already owns it — `contract_lint.records`,
`contract_lint.INVARIANTS`, `contract_scaffold.coverage_report` — and reads coverage counts from the
PRODUCER, never by parsing the rendered `COVERAGE.md`. It does not rewrite claims: `MATURITY.yaml` is
a human claim on purpose, and a generator that silently corrected it would destroy what that file
exists to make visible.

**`platform/tools/pack_run.py`** — the pack/cut/member/output contract shared by the two live-evidence
runners (`run_product_profile.py`, `run_product_schema_check.py`).
`pack_config` · `config_path` · `targets` · `restricted_dir` · `evidence_dir` · `product_id`

**`platform/tools/bundle_products.py`** — the one generator of the deployed job set, and the one place
activation is decided. `entries` · `activation` · `activation_errors` · `document` · `render` ·
`ACTIVATION` · `ACTIVATION_FIELDS`

Jobs come from `products/registry.yaml` (materialized products only); pause state, `run_as`,
CAN_MANAGE/CAN_VIEW and cluster policy come from `products/activation.yaml`. `activation_errors` owns
the rule that makes activation governed rather than a `pause_status` somebody edits:
`schedule_enabled: true` REQUIRES `source_manifest.releasable(pack)`. That is not a second release
flag — releasability is derived and unsettable — so the dependency runs one way, and `is True` rather
than truthiness because `1` and `"yes"` are what a hand-edit looks like.

**`platform/tools/repo_hygiene.py`** — the one definition of what may never be COMMITTED.
`NEVER_COMMITTED` · `MACHINE_PATHS` · `GENERATED_ONLY` · `tracked` · `restricted_files` ·
`present_files` · `registered_workbooks` · `production_eligible_workbooks` · `machine_paths_in` ·
`errors` · `NotAGitCheckout`

Two different questions about a spreadsheet: `registered_workbooks` is the CHECKOUT rule (some pack
says what this is — a draft under review belongs in a development repo), and
`production_eligible_workbooks` is the stricter one (`status: reviewed`) that
`deploy_tree.forbidden_in` applies. Conflating them would make "only approved specifications reach
production" untrue. It returns an empty set today, which is the honest answer: no pack yet has a
reviewed specification input.

The repository-content check uses the standard library. It refuses unregistered exported documents,
media, saved web pages, archives, whole-repository snapshots and tracked workstation paths. A SPREADSHEET is judged by REGISTRATION, not extension:
permitted when some pack's `source_refs.yaml` names it as `program_spec` or `extraction_input`,
refused otherwise — a blanket `.xlsx` allowance would equally admit a vendor data dictionary, a
patient-level extract or a saved profile. `restricted_files` reads the git INDEX and `present_files`
WALKS the working tree, because a gitignored file is still on disk and still readable by any local
process. `deploy_tree.forbidden_in` DERIVES its file-kind refusals from `NEVER_COMMITTED` and
`test_spec_pipeline` takes `MACHINE_PATHS` from here, so neither can come to permit what the other
refuses. `tracked` RAISES rather than returning `[]` when git cannot be read: an empty list would
report a clean repository, which is the one answer it may not invent.

**`platform/tools/deploy_tree.py`** — the one definition of what production is allowed to see.
`build` · `check_tree` · `runtime_tools` · `forbidden_in` · `deployed_files` · `tree_digest` ·
`git_state` · `MARKER` · `PLATFORM` · `PACK_EVIDENCE` · `ROOT_FILES` · `FORBIDDEN`

`check_tree` is the one check that looks at a GENERATED tree, and `--check-tree DIR` is what to run
immediately before packaging one. `repo_hygiene --check` cannot: it reads the git INDEX and a tree
has no `.git`, and from the repository it skips `build/` as generated. `runtime_tools` DERIVES the
deployed tool set from what `platform/databricks/` imports, transitively, with `ast`.
`--evidence-out DIR` writes the per-pack audit bundle outside the runtime tree — it answers "what was
approved" and carries source-provenance prose a workspace has no business holding.

An ALLOWLIST, because syncing the repo root minus a few globs ships every stand-in, reference
document and sandbox experiment into the one environment where exposure matters most. Building the
tree DEPLOYS NOTHING and RUNS NOTHING — it copies files into a local directory, and
`test_governance.py` checks the result offline, both directions: nothing forbidden got in, and
nothing the build reads was left out. Take the config graph from `product_gates.pack_yaml` and the
shared product files from `engine.config.SHARED_ASSETS` — never a directory listing, and never a
second inventory.

`deployed_files` WALKS the tree (so an added file counts) and `tree_digest` hashes path+bytes; both
run at build time AND at run time, which is the only reason the recorded digest can be verified. The
commit alone is two strings, and can be satisfied by a dirty checkout stamped with a clean SHA.

**`platform/engine/`** — `config.product_dir` resolves a pack including its registry `family`;
`config.SHARED_ASSETS` / `config.shared_asset` own where the cross-pack runtime files live (registry,
catalog, audiences, dashboard_vars, tfl_specs); `release.versioned_ads` / `release.staging_ads` /
`release.public_tfl` / `release.staging_tfl` own what a release's tables are called — staging is
BUILD-SCOPED, so a validate-only run's staging tables are not overwritten by the next run;
`vendors.resolve` owns physical table layout. Never restate any of these as a path or name literal.

`codelists.sql_str` is the one Spark SQL string literal quoter, and it escapes BACKSLASHES as well as
quotes. Spark drops an unrecognised escape silently — `'\d'` is the string `d` — so a config carrying
a regex would compile to a pattern matching nothing, with no error anywhere. `stages/clinical.py`
imports it as its `_q` and `test_r_parity` asserts the two are the same function OBJECT. `engine-r/`
must define it twice (`cases.R` and `codelists.R` are each `source()`d ALONE by their parity
harnesses, so neither can call the other); the same test compares all three against a hostile string
set, which is what keeps two definitions from becoming two behaviours.

`refresh.CANDIDATE_VERDICTS` is the ONE list of stages a candidate passes through, and
`refresh.candidate_verdict` composes them: source QC, source linkage (its own stage, `{}` until the
pack declares a tolerance, compared on the unrounded rate), ADS QC, the output contract, golden, the
patient differential, EDA acceptance, source grain, stage retention, and LAST the publication surface
(`output_contract.publication_surface_gate` — the columns as they stand against the approved
whitelist; a release-grade run always carries it). The job stops on the same composed verdict the
manifest carries; `build_manifest` stores it under `candidate_verdict` and `validate_manifest` refuses
a copy that disagrees with its own blocks; `audit.build_bundle` writes one file per stage from that
list plus `candidate_verdict.json`, so a stage added tomorrow lands in the stop, the manifest, the
bundle, Gate 5 and Gate 6 without a second edit.

`release.swap_plan` is the one order in which public views move — TFLs first, the ADS last as the
commit anchor — and `release.promotion_plan` reuses it rather than restating it. A build-and-publish
run and a promotion run publish the same set in the same order; two orderings for one operation would
agree today and diverge on the first change to either. `promotion_blockers` is the PHYSICAL half of
Gate 6, separate from `publish_approval_errors`' paperwork half: an approval says a person signed for
a build id and a manifest digest, and says nothing about whether those bytes are still on the cluster.
Promotion is the one step that publishes something it did not just build, so both are required.

`contract_scaffold.judgment_stub` is the one definition of what a DRAFTER answers, and the one place
the field-default policy lives — the rule was written twice already, once building the scaffold record
and once per cell in `to_contract_records`. It omits `MACHINE_OWNED` and `status` because
`contract_record` refuses all four as coming from the extraction and from an accountable person; a
starting point that carried them had to be hand-stripped before the tool that consumes it would take
it, once per record, on every pack. `spec_slice` renders it directly under the spec rows, so the rule
the record must state is on the same page as the stub.

`spec_extract.sheet_key` is the one comparison key for an Excel tab label — casefolded, all whitespace
removed. The shared map's keys, the domain lookup, `ignored:`, a pack's `IGNORE` and an explicit
`--tabs` list all go through it. Comparing `strip().lower()` made `5B. ClinChars` and `5B.ClinChars`
two keys, so a workbook spelling the label without the space matched neither half of the map and an
entire domain — 96 requirement rows — went unscanned, with the symptom appearing far downstream as
citations that would not resolve. `shared_sheet_map` refuses two labels that normalise together and
carry different rulings, because merging spellings is safe and merging answers is not.

`console.use_utf8` is the one place the tools' output encoding is set, called from every
`__main__` block. Python picks stdout's encoding from the platform — cp1252 on Windows — and a `—` or
`∪` in an unrelated message then raises `UnicodeEncodeError` from inside `print`, most often on
redirection. `test_governance.py` holds every tool with an entry point to calling it.

### If it genuinely is a new concept

Put it in the module that owns the thing it is about, export it, and import it everywhere else. Do
not copy it for one caller.

## This is a multi-tumour framework — never write one tumour's name into shared code

Every path assumption is a latent failure for the next product, and it fails silently.

- Discover packs with `product_gates.products()`, never `products/*/*/*` — a fixed depth drops every
  pack under a new grouping level, with nothing going red.
- Take the **pack path** as an argument; never resolve a pack through the registry inside a tool
  stored in a pack. The registry's `current_spec_version` moves, and the tool starts reading a
  different version than the one it lives in.
- Get the family from the registry (`t["family"]`, default `oncology`) — the first heme product fails
  on a hardcoded `products/oncology/…` path, not on anything about its content.
- Resolve table names through `cfg.table()` / `cfg.table_in()`. Do not assume `{stem}_{refresh}`:
  `run.source_layout` is a documented per-product override, and `{schema}` may appear inside the
  physical name.
- Under a `source_union`, one run covers ONE member. `cfg.source_fqns()` deliberately fans out across
  all members (preflight wants that); `cfg.table_in(source, member)` is what member-scoped evidence
  needs.

## Evidence and approval gates fail CLOSED

A field that is not stated is an unanswered question, never a default:

- an absent counter is not a zero;
- `none` / blank identity is not a match;
- a placeholder (`TODO`, `TBD`, `REPLACE_ME`) is not an answer — use `unstated()`;
- a blank status in a register is not "resolved".

When adding a check, add the test that proves it **bites** — revert the fix and confirm the test
fails. A test that passes against the bug is worse than no test.

## Restricted output never enters the checkout

Profiles carry per-column top values and date ranges (the profiler SUPPRESSES categorical
values below its `min_cell` floor, default 11 — but date ranges and schema stay sensitive
regardless); schema reports name
physical vendor tables and columns. `.gitignore` stops a commit, not a read by an indexing tool or
any local process. `--out-dir` is required and is refused inside the checkout. Local/synthetic mode
is a development aid and is refused as Gate 3 evidence.

Unregistered exported source documents and delivered data dictionaries do not enter the repository. `platform/tools/repo_hygiene.py --check` refuses those, and it reads the
git INDEX — `.gitignore` says nothing about what is already tracked and is overridden by
`git add -f`. Link the document from `source_refs.yaml`; do not carry it.

**The AI boundary is VENDOR-derived content, and `governance/WORKFLOW.md` §"Eligibility" defines it
— read there, not here.** Two things this file will not restate, because a second copy of a policy is
how the two come to disagree:

- Eligibility follows the CONTENT's classification and provenance (`source_refs.yaml`'s
  `ai_classification`), never the folder it sits in.
- It is not changed by a task instruction. A prompt saying "go ahead" is not an approval mechanism;
  the classification on the material is.

The one point worth repeating: a sponsor-authored Science specification is AI-eligible **when its
recorded `ai_classification` is `sponsor_ai_eligible`** — drafting contract records from such a spec
is the framework's primary AI function (WORKFLOW.md Gate 2, "AI drafts; humans approve"). Never infer
eligibility from a document's title or folder: an internally authored document that quotes or embeds
vendor material inherits the restricted classification, which is exactly why the field exists. What
AI must never ingest is vendor-originated or vendor-derived content — the delivered data, vendor
prose, a profile TSV, a schema report. Verdicts cross that boundary; contents do not.

## Verify before claiming

From the repository root with the installed environment active, use
`python platform/tools/ci_local.py --json ../local-ci.json` for the local lane.
It records testcase pass/fail/error/skip counts per suite and saves completed
rows while running. An interrupted report says `complete: false`; a suite with
only skipped cases is skipped. The full lane also runs ledger ownership,
source-manifest and approval-identity checks. The quick lane omits these full
governance checks and cannot establish overall readiness.

**The working directory matters, and mirrors CI.** The Python suites run from `platform/`; the gate
tools run from the repo root, because `product_gates --list-*` emits repo-root-relative pack paths.
`products()` also derives its root from the working directory, so a discovery-based test can pass
from one directory and be silently vacuous from the other — run the suites from **both** and assert
non-empty discovery inside any test that sweeps packs.

```bash
set -euo pipefail          # this block states a PASS; without it a failing suite prints and continues
# suites — from platform/ (matches the CI job's working-directory)
cd platform
python -m py_compile engine/*.py engine/stages/*.py tests/*.py tools/*.py \
                      TUMOR_TEMPLATE/handoff/tests/*.py
# the two spark suites skip without PySpark; r_parity is its own CI job
for t in tests/test_*.py; do
  # SAME six exclusions as CI's pure-Python step and the PowerShell twin (the three lists had drifted — audit 5)
  case "$(basename "$t")" in test_stages_spark.py|test_smoke_spark.py|test_r_parity.py|test_delta_promotion_spark.py|test_patient_goldens_spark.py|test_source_portability_spark.py) continue;; esac
  python -m pytest -q "$t"
done
python -m pytest -q -rs tests/test_r_parity.py

# gates — from the repo root (pack paths are root-relative)
cd ..
# FIRST in CI and first here: stdlib-only, and it answers "is there an exported document or a machine
# path in the index" before anything else is known to work.
python platform/tools/repo_hygiene.py --check
# The product tests are the first gate CI runs. Because CI stops at the first failure, everything
# after this step gets SKIPPED when they are red — so run these FIRST; they are what "is the repo
# green" means.
for t in $(python platform/tools/product_gates.py --list-tests); do python -m pytest -q "$t"; done
python platform/tools/source_manifest.py --all --check
for p in $(python platform/tools/product_gates.py --list-contracts); do
  python platform/tools/source_check.py "$p" --structure-only --check
done
for p in $(python platform/tools/product_gates.py --list-config-declared); do
  python platform/tools/contract_binding.py "$p" --enumerations --parameters --check
done
# Every other gate checks an ARTIFACT; this one checks the sentences a pack writes ABOUT its
# artifacts — scope, counts, maturity note.
for p in $(python platform/tools/product_gates.py --list-contracts); do
  python platform/tools/finalize.py "$p" --check
done
```

State what was run and what it said. If a step was skipped, say so. **"The suites pass" is not "the
repo is green"** — they are different claims, and only one is what CI gates on.

### Editing a file and re-running is not enough: clear `__pycache__` first

Python decides a `.pyc` is current by comparing the source's **mtime (whole seconds) and size** with
the two numbers recorded in the `.pyc` header. Both matching means "unchanged" — the contents are
never hashed. So an edit that preserves the byte size and lands in the same second as the compile
that preceded it is **invisible**, and the interpreter keeps serving the old code with nothing to
show for it: the source on disk reads correctly, `grep` agrees, and the imported module disagrees.

This is not a corner case; it is the exact shape of a mutation test. Reverting a mutation is a
same-second, same-size write by construction when the mutation swapped, renamed, or reordered
something of equal length. It has already happened here: a two-element reorder inside a tuple was
"restored", the restore was invisible, and every run afterwards — including a full sweep and six
mutation checks — executed the mutant. One of those six was recorded as caught when nothing had
caught it, and the defect it was supposed to prove was real went unnoticed.

```bash
find . -name __pycache__ -type d -prune -exec rm -rf {} +   # BEFORE the run, not after
python -B -m pytest platform/tests/ -q                     # and do not write new ones
```

`-B` alone is not enough — it stops new caches being written, not stale ones being read. Delete
first. Treat any result from a mutation loop that did not clear the cache as unmeasured, and take it
again.

### Counting failures: use pytest, not the standalone runners

Some older suites retain script entry points; others require pytest fixtures and
parameterization. Invoking a test file as an ordinary script may execute no
assertions and still exit zero. Use pytest for both verdicts and counts. Script
exit codes alone cannot establish that the registered regressions ran.

```bash
python -m pytest platform/tests/ -q -rs --junitxml ../all-tests.xml
```

Inspect counted results and skip reasons. A synthetic comparison, a static guard,
an R execution and a cluster build establish different things.

### On Windows

Every tool is pure Python and runs unchanged; only the loops above are bash. **A PowerShell twin for
every one of them, in the same order** — an earlier version of this section carried three of the six
and dropped the skip-list from the one it did carry, which is worse than carrying none: a runner who
follows an incomplete list believes they ran the suite.

**Read this first, because it is the one that fails silently.** PowerShell does not stop a loop when
a native command exits non-zero, and `$ErrorActionPreference` does not change that — it governs
PowerShell's own errors, not a program's exit code. A failing `py` inside `ForEach-Object` prints its
traceback and the loop carries on to the end, so the block *completes* and reads as a pass. Check
`$LASTEXITCODE` per iteration, or a red gate looks green:

```powershell
$fail = 0
# …inside each loop body, after each `py` call:
if ($LASTEXITCODE -ne 0) { $fail++ ; Write-Host "FAILED: $_" }
# …and at the end:
if ($fail) { Write-Host "$fail step(s) failed"; exit 1 } else { Write-Host "all steps passed" }   # a red gate exits nonzero
```

```powershell
cd platform
# PowerShell does NOT expand wildcards for external programs — `py -m py_compile engine\*.py` passes
# the literal string. Expand them first.
# NATIVE COMMANDS DO NOT THROW. PowerShell only sets $LASTEXITCODE; a loop that ignores it
# reports success after every failed suite. EVERY native call below — compilation, the suites,
# the list-producing commands and R parity included — goes through `Run` or `RunList`, which
# record the failure; the block exits nonzero at the end, the same contract bash gets from
# `set -e`. (An earlier twin left py_compile and the list producers outside the wrapper and
# skipped R parity without running it: a false green — audit 4.) Save as verify.ps1 and run
# `pwsh -File verify.ps1` so `exit 1` ends the script, not your shell.
$failures = @()
$env:PYTHONUTF8 = "1"; $env:PYTHONIOENCODING = "utf-8"   # every child writes UTF-8 (audit 7: this twin wrote cp1252)
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
function Run { param([string]$Label, [scriptblock]$Cmd)
  & $Cmd | Out-Null
  if ($LASTEXITCODE -ne 0) { $script:failures += "$Label (exit $LASTEXITCODE)"; Write-Host "FAIL $Label" }
}
function RunList { param([string]$Label, [scriptblock]$Cmd)   # a producer whose OUTPUT is consumed
  $out = & $Cmd
  if ($LASTEXITCODE -ne 0) { $script:failures += "$Label (exit $LASTEXITCODE)"; Write-Host "FAIL $Label"; return @() }
  return $out
}
Run 'py_compile' { py -m py_compile (Get-ChildItem engine\*.py, engine\stages\*.py, tests\*.py, tools\*.py,
                                     TUMOR_TEMPLATE\handoff\tests\*.py | ForEach-Object FullName) }
# SAME exclusions as the bash/CI loop: the Spark suites run in their own CI job; r_parity is run
# separately BELOW, not skipped
$skip = 'test_stages_spark.py', 'test_smoke_spark.py', 'test_r_parity.py',
        'test_delta_promotion_spark.py', 'test_patient_goldens_spark.py', 'test_source_portability_spark.py'
Get-ChildItem tests\test_*.py |
  Where-Object { $skip -notcontains $_.Name } |
  ForEach-Object { $f = $_.FullName; Run $_.Name { python -m pytest -q $f } }
Run 'r_parity' { python -m pytest -q -rs tests\test_r_parity.py }

cd ..
Run 'repo_hygiene' { py platform\tools\repo_hygiene.py --check }
foreach ($t in (RunList 'list-tests' { py platform\tools\product_gates.py --list-tests })) { Run $t { python -m pytest -q $t } }
Run 'source_manifest' { py platform\tools\source_manifest.py --all --check }
$contracts = RunList 'list-contracts' { py platform\tools\product_gates.py --list-contracts }
foreach ($p in $contracts) {
  Run "source_check $p" { py platform\tools\source_check.py $p --structure-only --check }
}
foreach ($p in (RunList 'list-config-declared' { py platform\tools\product_gates.py --list-config-declared })) {
  Run "contract_binding $p" { py platform\tools\contract_binding.py $p --enumerations --parameters --check }
}
foreach ($p in $contracts) {
  Run "finalize $p" { py platform\tools\finalize.py $p --check }
}
if ($failures.Count) { Write-Host "`n$($failures.Count) FAILED:`n  $($failures -join "`n  ")"; exit 1 }
Write-Host "all checks passed"
```

`run_spec_pipeline.py` exists for this reason: the shell wrapper was the only bash in the workflow, so
on a Windows checkout Gate 2 generation and the `--check` drift verification were unreachable.

Console encoding needs nothing set. Each tool calls `console.use_utf8()` at its entry point, so its
output is UTF-8 whatever the machine's code page is — including when redirected to a file, which is
where a cp1252 default used to raise `UnicodeEncodeError` on a character in an unrelated message.
