# Measured local environment

The portal's [environment manifest](../experiments/portal/environment.manifest.json)
and [constraints](../experiments/portal/environment.constraints.txt) record the
current Python 3.13 environment. They make a version
difference visible on the next checkout. They do not turn an installation into
scientific approval or a passing product/runtime receipt.

The manifest is portable metadata: distribution names, versions, dependency
requirements, the nine declared root requirements, and the measured operating
system/Python version. Its packages follow active dependency markers and extras
from the existing requirements plus pytest. It does not export a full `pip freeze`,
credentials, installation directories, direct package URLs, or unrelated tools.
The current target is Windows AMD64 with Python 3.13.13. The exact measured version
and package closure are recorded in the manifest. Constraints pin versions
only; they do not install packages whose markers are inactive on another platform.
Other operating systems have not been established as identical environments by
this profile. Missing platform-specific dependency metadata is reported as
unavailable rather than inventing a lock solution.

## Deliberate setup

Run these in a fresh checkout or a deliberately selected Python 3.13 environment.
The launcher never replaces an existing environment automatically.

```powershell
py -3.13 -m venv .venv
.\.venv\Scripts\python.exe -m pip install -c experiments/portal/environment.constraints.txt -r requirements.txt -r platform/requirements.txt
.\.venv\Scripts\python.exe -m pip check
.\.venv\Scripts\python.exe experiments/portal/launch_portal.py --doctor --json
```

For an existing older environment, create `.venv313` separately or select an
existing Python 3.13 environment in VS Code; do not overwrite the old environment.
The launcher accepts that explicit interpreter and checks `.venv313` before `.venv`
when none is supplied. Follow the [migration instructions](LOCAL_INSTALLATION.md#use-python-313-in-an-existing-vs-code-checkout).

The existing installation without `-c` remains available. `--doctor` exits with
one on a mismatch or unavailable profile and zero when the base profile matches.
It does not reserve a port, start Streamlit or install anything. Normal launcher
startup remains available with a diagnostic when versions differ. The existing
implementation prerequisite review includes the same profile alongside its
runtime evidence.

The standard portal requirements now include the same measured pytest version for
integrated correction and durable-fix checks. Selecting constraints is optional;
installing their required test runner is part of ordinary local setup.

## Clean setup check on September 8

This is historical Python 3.11 evidence; it does not validate the current Python
3.13 environment. Keep current runtime receipts separate from these prior results.

A separate user-local directory received copied setup files, the manifest,
constraints, launcher and diagnostic tests. A new Python 3.11.15 virtual
environment installed the constrained requirements from public PyPI in 247.67
seconds. `pip check` passed, the actual launcher doctor reported `matched`, and
all **16 metadata tests passed** against the final copied helper and tests.
PySpark was confirmed absent. No package was added to the existing application
environment or a global environment. A separate **26-test** metadata/launcher
run also passed, including the existing browser-free server health smoke.

This checks the Windows setup path and diagnostic portability. It does not rerun
every portal workflow in the new environment, execute Spark/R there, establish
Linux/macOS package resolution, or replace the product-specific runtime checks.

## Optional scientific runtimes

The Python 3.13 local and CI target uses **PySpark 4.0.4** with Java 17. Install
PySpark explicitly in the selected environment using
`python -m pip install "pyspark==4.0.4"`. Spark 4.0.1 has a documented local
Windows worker failure with Python 3.12/3.13; the fix first appeared in 4.0.3.
The 4.0.4 maintenance release retains that fix. See
[SPARK-53759](https://issues.apache.org/jira/browse/SPARK-53759) and the
[Spark 4.0.4 release notes](https://spark.apache.org/releases/spark-release-4-0-4.html).
Use the existing synthetic and expected-output tests to verify actual execution.

Spark and R are separate explicit installations, excluded from the Python base
constraints. The previous local conformance run measured Python 3.11.15,
PySpark 4.0.1, pytest 9.1.1, Java 17.0.20.1+1, and R 4.6.1 with sparklyr 1.9.5,
dplyr 1.2.1, dbplyr 2.6.0 and DBI 1.3.0. The existing runtime prerequisite probe
compares measured R/PySpark versions and probes the selected Java executable's
full runtime version. An unavailable or failed probe stays unobserved. That
historical metadata does not validate Python 3.13, rerun the R comparisons or certify
an installation. R packages remain user-local, and this profile does not
automatically install or upgrade them. See the actual scope and outcomes in the
[runtime retest report](SIX_FIX_ADVERSARIAL_RETEST_20260908.md).

## Updating after dependency changes

Use the existing requirements to declare intended direct changes first. Test the
chosen environment, then explicitly capture its metadata and review both file
diffs:

```powershell
.\.venv\Scripts\python.exe experiments/portal/portal_environment.py --capture
.\.venv\Scripts\python.exe -m pytest platform/tests/test_portal_environment.py platform/tests/test_epi_portal_launcher.py -q
```

Capture is an operator action, not a model response or automatic startup action.
It follows only the declared closure and refuses direct URL dependencies or
inconsistent installed versions. Changing the profile does not replace the
regression checks appropriate to a changed dependency. Runtime receipts still
bind their own exact installed versions, code and test outcomes.
