# The approval-event ledger

Every governed act — a registration, an amendment, a closure, an answer, a revision — is an
immutable EVENT in an append-only ledger, chained per object by content hash. The ledger is
the source of truth for lifecycle transitions; the YAML records people edit are projections
of it, held to the newest event's payload digest. This replaces, one surface at a time, the
older per-surface anchors: those bound single fields to git history; the ledger
binds the whole decision.

Built under twelve operator-ratified safeguards (2026-08-27). The three first integrations —
protocol, specification, request — run SIDE BY SIDE with the existing anchors until parity
is demonstrated; nothing legacy is deleted in this tranche.

## Where events live

    governance/events/<object_uuid>/<seq>-<event_id>.yaml     one file per event
    governance/events/HEAD_CHECKPOINTS.yaml                   object_uuid -> expected head

One file per event makes append-only enforceable the way the run ledger already enforces it:
every path git ever recorded must still exist, byte-identical to its first commit. The
checkpoint file exists because a per-object chain cannot see the removal of its own tail —
the expected head is stored OUTSIDE the chain, and heads only ever advance.

## The event, exactly

```yaml
schema_version: 1
canonicalization_version: c1
hash_algorithm: sha256
event_id: <uuid4>                  # minted at append; globally unique
object_uuid: <uuid4>               # stable identity — survives renames, paths, display ids
object_kind: protocol | specification_material | request | ...
seq: <int>                         # 1-based, contiguous per object
action: registered | amended | closed | answered | withdrawn | superseded |
        revised | attested | legacy_imported | ...
actor:
  subject_id: <string>             # the identity the provider knows, e.g. an email or login
  identity_provider: <string>      # e.g. gsk-ad, github, typed  ("typed" = unauthenticated)
  display_name: <string>
  role: <string>                   # e.g. rwp, rwb, operator
  trust_level: typed | authenticated | unauthenticated_legacy
occurred_at: <RFC 3339 UTC>        # e.g. 2026-08-27T21:04:05Z
idempotency_key: <string>          # retries never create a second event
payload: { ... }                   # the COMPLETE bounded decision content — see limits
payload_sha256: <hex64>
previous_event_sha256: <hex64|"">  # "" only at seq 1
event_sha256: <hex64>
```

There is NO signature field, empty or otherwise — filling one later would mutate an
immutable event. A signature is a separate `attested` event whose payload carries
`target_event_sha256`, `signer_key_id`, `algorithm`, `signature`, and whose own chain
position timestamps the attestation.

## Hashing, defined before code

* `canonical_json(x)` (canonicalization_version **c1**): JSON with keys sorted, separators
  `(",", ":")`, `ensure_ascii=False`, UTF-8 encoded. Values are hashed exactly as given —
  no whitespace collapsing, no case folding; the OWNING tool canonicalises its domain
  content before it becomes a payload.
* `payload_sha256 = SHA256(canonical_json(payload))`
* `event_sha256  = SHA256(canonical_json(event minus event_sha256))`
* An unknown `schema_version`, `canonicalization_version` or `hash_algorithm` REFUSES —
  never "best effort".

## Payload limits

Inline only bounded decision content — the plan sections, the answer, the ruling, the
revision reason. Hard cap: 64 KB of canonical JSON. A workbook, extract, or any source
document enters as a REFERENCE: `{path_or_link, media_type, sha256}`. Patient-level data
never enters a payload in any form.

## Appending

One shared library call — `event_ledger.append_event(...)` — used by every owning tool, so
canonicalization and chaining cannot diverge per tool. The CLI is CHECK-ONLY. The call
requires:

* `expected_previous_event_sha256` — mismatch means someone else appended first: the caller
  re-reads and decides again; competing sequence numbers are rejected, never merged;
* `idempotency_key` — an existing event with the same key on the object is RETURNED, not
  duplicated;
* a structured actor and an RFC 3339 UTC `occurred_at` supplied by the owning tool.

A kind's verbs also carry an ORDER. One shared
`lifecycle_error()` enforces it at the door and under `--check`: a terminal state
(`closed` / `withdrawn` / `superseded` / `retired`) admits attestation only; `legacy_imported` is a
genesis-only act; `registered` happens once — at genesis, or as the adoption re-seal
directly after a legacy import.

The head checkpoint moves under a lock (`HEAD_CHECKPOINTS.yaml.lock`, exclusive-create,
bounded wait) with an atomic replace, and heads only advance in the merge — two concurrent
appends on different objects were both reporting success while the slower writer's unlocked
read-modify-write left one head behind its chain. If the checkpoint cannot move, the event
claim is unwound: a commit carries both or neither.

## Validation (`event_ledger.py --check`)

Refuses, by name: a malformed or non-canonical event; an unknown version; a recomputed
digest that disagrees; a broken or forked chain (two files claiming one seq); a gap in seq;
a duplicate idempotency key; an `attested` event whose target does not exist; a checkpoint
head that does not match the recomputed head; a checkpoint whose own git history ever shows
a HIGHER seq than the present one (tail deletion); an event file whose bytes differ from
their first commit, or that git recorded and the tree no longer holds; and SHALLOW history,
which verifies nothing and therefore refuses everything.

### An orphaned chain and its retirement

A chain whose record git recorded as deleted (the pack was removed after the event was sealed)
is reported by `--check` as `ORPHANED`, with the deletion commit and the exact command that
settles it; the check still exits 1 until a person runs it. `retired` is a universal terminal
action for that case (2026-09-07): `event_ledger.py --retire <object uuid> --deleted-in <commit>`
validates the chain, resolves the commit, refuses a commit that did not delete the record or a
record that is still in the tree, transcribes the actor from the git identity that will commit
the event (refused when absent or not a person), and carries the subject paths and the deleting
commit as payload. It is never a genesis, happens once per chain, admits attestation after it,
and replays idempotently. The act is registered in `governance/ACTIONS.yaml` as
`retire_abandoned_chain`. Retiring a chain is a person's act at a keyboard; no tool runs it on
its own.

## Imports and trust

Existing anchors arrive as `action: legacy_imported` genesis events with
`trust_level: unauthenticated_legacy`. History never appears newly authenticated; a
`typed` actor remains an assertion until an `attested` event with a registered person key
stands behind it.

A record's `object_uuid` is pinned at its FIRST COMMIT. Parity on all three surfaces reads
git history's first uuid for the record — FOLLOWING renames — and refuses a current value
that differs: identity never re-homes, and a swapped uuid grafts the record onto another
object's history. Because a rename disguised as delete/add can defeat any history
tracking, the CLI and release validation also refuse an ABANDONED object (`require_claims`):
every swap, however the move was disguised, leaves the original chain with no file
referencing it, and an unclaimed chain is a record that shed its history. A chain also
opens only with its kind's genesis verb (or a legacy import), a genesis idempotency key
never crosses kinds, and `occurred_at` ordering keeps its fractional seconds.

## The ratified trust closures

**Decisions are ledger objects.** A RESOLVED answer form seals as a `decision` event,
its actor transcribed from the form's own `answered_by`. **The `--apply` wave seals what
it writes** — including already-recorded forms on a re-run, so answers applied before
auto-seal existed catch up — with a retraction skipped by name (no signature by design)
and a seal failure loud and nonzero while the register stands.
`--record-event <ID>` remains the single-form recovery verb. An equivalence answer
carries a STRUCTURED `equivalence` block — `equivalence_outcome` in the rulings' own
closed vocabulary, plus the variable and both sources — validated at the wave's earliest
gate AND at the seal, so agreement is machine-checked, never inferred from prose.

**Rulings bind to the exact decision event.** An equivalence ruling names
`decision_object_uuid` + `decision_event_sha256`; validation loads that event and refuses
an outcome, variable or source-pair disagreement, a stale reference (the decision moved),
or a superseded/withdrawn head. Accepted rulings surface `trust: unsigned` — with zero
signing keys an actor is an immutable UNSIGNED assertion, never an authenticated act.
Rulings themselves seal as `equivalence_ruling` events (`semantic_view.record_ruling`).

**Claims are parity-composed, the text search is gone.** `claims.py` composes per-kind
providers, each returning only records that VALIDATE against their chain head (payload
digest equality). Every kind has a provider or the composition names the gap; every
active object needs exactly one validating owner; prose, comments, block scalars and
decoy files are never claims.

**A copy is not a participant.** Ownership of an object is decided by where its uuid FIRST
entered the repository: the record whose lineage (its file, or a path it was moved from)
introduced the uuid owns it. A pack copied by hand with the fixture's `object_uuid` intact is
told, by name, that it carries a copied uuid and how to exit: remove the copied line, commit,
then `source_manifest.py <pack> --record-event <material_id>` seals the copy's own genesis. The
sticky rule ("participation, once begun, never ends") binds only a uuid a record itself brought
in, so dropping a copied uuid is never answered with "restore it"; and the pin at first commit
is the first uuid the record's own lineage introduced, so the copy's new identity holds from the
commit that sealed it.

## Approvals are ledger objects, and authentication is derived

**The four approval forms seal as events** (programme item 5): `handoff/RELEASE_APPROVAL.yaml`,
`CONFIGURATION_APPROVAL.yaml`, `CONTRACT_APPROVAL.yaml` and `SEMANTIC_APPROVAL.yaml` are
`release_approval` / `configuration_approval` / `contract_approval` / `semantic_approval`
objects. `approval_record.py --record-event <pack> --form <form>` first runs the gate that OWNS
the form (the same function the gate runs, never a shorter copy), seals the declared fields
and digests as the payload with the approver as the typed actor, and writes `object_uuid` back
into the form once at genesis. Sealing the same bytes twice is one act; a changed form on a
sealed object seals as `revised`, never as a new object. `sealed_errors` names a form that no
longer says what its act said, `approval_record.py --check` holds every sealed form to its
chain in CI, and the claims composition proves each object's one owner. Gate 6 is wired first:
`publish_approval_errors` refuses a release approval that is only a form — at promotion, on
the status page, and in the flow, which offers the seal as the next act.

**`authenticated` is derived, never written.** `governance/SIGNING_KEYS.yaml` is where a person
registers a person's ed25519 public key. `approval_record.py --countersign` signs the sealed
approval's head event with the private half (read from a path outside the checkout; the key
handed in must be the key registered under that id, or nothing is written) and appends an
`attested` event carrying the signature. `event_ledger.verify_attestation` checks every
attestation of an object — registered, active key; ed25519; a target that is an event of the
object; a signature that verifies over the target digest — and only then does
`event_ledger.trust_of` answer `authenticated`. A placeholder attestation is structurally a
valid event and cryptographically nothing; a revoked key authenticates nothing from the moment
of revocation, by name. The primitive is `ed25519_pure` (RFC 8032, stdlib only, held to the
RFC's test vectors), so the answer is the signature's and never the environment's.

## Stated limits

The ledger proves what git history witnesses. Full-history CI and protected branches are
part of the control: code cannot protect against an authorized history rewrite by itself,
and release validation fails rather than guesses in a shallow clone.
