# Related specification records

The portal can check a saved workbook extraction against a declared structure and
connect its explicit references. This is the first implementation of schema-driven
extraction across related objects for the RWD workbook flow.

## Use it in the portal

Open **Definitions and sources → Review the variable list**, expand **Variables
and related specification records**, and select **Check specification structure**.
The same panel is available alongside sheet mapping in the extraction workflow.

Findings appear first. Choose a record from the dropdown to compare the original
Excel text with its parsed fields, see the source sheet and row, and inspect related
records. **Review this variable** opens the existing scientific editor for that
source row, including when the selected record is a value or time window.
**Download structure report** exports the inspected objects, relationships and findings.

The check runs only when requested. A change to the saved extraction, source
registration, pipeline declaration or schema withdraws the displayed report.
Switching profiles or products also clears that preview.

## What this version extracts

The default schema separates variable definitions from product values, time windows,
source references and the MININDEX/MAXINDEX study dates. These are independent
objects with links back to the variable and field-level Excel citations.

For example, MININDEX's `01-Jan-2015` is retained as source text and parsed as
`2015-01-01`. Its definition stays in the Variable object. A time-window cell
`MININDEX-MAXINDEX` links to the two study-date objects. An impossible date remains
visible in the original text, has no parsed date, and produces a finding.

The checks expose missing required fields, invalid scalar types, unresolved
placeholders, duplicate identifiers, source-coordinate collisions, missing or
ambiguous explicit references, and dependency cycles. Duplicate rows remain
separate; no first-match rule picks one definition silently.

## Extend the extraction structure

`governance/schemas/rwd_related_extraction.yaml` declares the structure using a
small versioned mapping format. It is not a general JSON Schema interpreter.
Entity declarations choose rows by domain, variable name or field presence, then
map source fields to typed object fields. Link declarations join objects from the
same row or resolve explicit identifiers against another object's key.

New entity types and required fields can be added to that schema without changing
the Python extractor. Supported types are string, integer, number, boolean, date
and string list. The schema file documents the selectors and reference parsers.

The Python API is `related_extraction.load_schema(path)` followed by
`related_extraction.extract(extracted_data, schema)`. Malformed input or schema
raises `ValueError`. A readable report has `ok: true`; `valid: false` means its
structure still has findings. Each report contains objects, relationships,
issues, counts and an input fingerprint.

## Interpretation and execution remain separate

This preview checks the saved source extraction, not subsequent scientific edits.
A source finding can therefore remain visible after its interpretation has been
resolved in the variable review. Correcting the source workbook requires the
existing registration and re-extraction flow. Source freshness and scientific
approval continue to use their existing checks.

This version does not call an AI model, parse unstructured document text, infer missing
clinical dependencies, import another product's parameter values, or change
approvals or executable configuration. It creates a typed, linked evidence layer
that a later document extraction agent can target and validate against.

## Verification on 10 September 2026

The focused extractor, portal workspace and UI suites passed 66 tests. Another
52 existing sheet-mapping and variable-review UI tests passed. These checks cover
custom related entity types, invalid fields and links, unchanged source evidence,
stale previews, access restrictions and navigation from a child record to its
variable editor.

A read-only check of the current GIST extraction produced 76 objects and 52
resolved identity links. Four findings remained: the impossible MAXINDEX date
`30-Feb-2026`, unresolved `TBD` text in IMATINIB_DOSE_ESC, and the two distinct
KIT_MUT rows sharing an identifier. MININDEX retained `01-Jan-2015`, parsed as
`2015-01-01`. A resolved link means the referenced record was located; it does not
mean that record's date or scientific meaning passed review.

The development portal was restarted at 11:15 IST and the existing browser tab
was reloaded. The live GIST panel displayed 76 records, 52 relationships and four
findings, with StudyDate / MAXINDEX selected and a working review-navigation
control available. One process was listening on port 8550. No scientific values,
product configuration or approvals were saved by this check.
