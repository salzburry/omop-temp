"""Human-authored expected slot fills over the existing canonical intake engine."""
from __future__ import annotations
import json
import math
import re

import intake

OBJECTIVE = "intake_elicitation_model"


def validate_record(record, pack):
    import rank
    if (not isinstance(record, dict) or record.get("record_type") != "reviewed_intake_case"
            or record.get("objective_id") != OBJECTIVE or record.get("pack") != pack
            or record.get("origin") != "human_authored_intake_case" or record.get("training_eligible") is not False):
        raise ValueError("Choose a human-authored intake case reviewed for this product.")
    rank.review_metadata(record)
    case = record.get("case")
    if (not isinstance(case, dict) or set(case) != {"case_id", "source_group", "split", "domain", "message", "initial", "expected", "expected_extra"}
            or any(not re.fullmatch(r"[A-Za-z][A-Za-z0-9_-]{0,79}", str(case.get(key, ""))) for key in ("case_id", "source_group"))
            or case.get("split") not in {"development", "heldout"} or case.get("domain") not in intake.domains()
            or not isinstance(case.get("message"), str) or not 1 <= len(case["message"].strip()) <= 4000):
        raise ValueError("Name the intake case, source family, reserved split, domain and exact stakeholder message.")
    slots = {slot["id"] for slot in intake.domains()[case["domain"]]["slots"]}
    for name in ("initial", "expected"):
        values = case[name]
        if (not isinstance(values, dict) or set(values) != slots
                or any(value is not None and (not isinstance(value, str) or len(value) > 2000) for value in values.values())):
            raise ValueError("Review every declared slot explicitly: use text for its value or null to leave it unanswered.")
    extra = case["expected_extra"]
    if (not isinstance(extra, dict) or len(extra) > 8 or set(extra) & slots
            or any(not re.fullmatch(r"[A-Za-z][A-Za-z0-9_]{0,59}", str(key)) or not isinstance(value, str) or len(value) > 2000 for key, value in extra.items())):
        raise ValueError("Expected unsupported requirements must have distinct names and bounded text.")
    text = json.dumps(case, ensure_ascii=False)
    if (len(text.encode()) > 25_000 or intake.classify_ingress(text)
            or any(other != pack for other in re.findall(r"(?:products|fixtures|sandbox)/[A-Za-z0-9_-]+/[A-Za-z0-9_-]+/\d{6}", text))):
        raise ValueError("Keep each case within this product's sanitized metadata-only request scope.")
    return case


def score(case, observed):
    """Literal regression scoring: expected answers are never sent to the model."""
    shaped = isinstance(observed, dict) and set(observed) == {'request', 'extra'}
    actual = observed.get("request") if shaped else None
    extras = observed.get("extra") if shaped else None
    shaped = shaped and isinstance(actual, dict) and isinstance(extras, dict)
    if not isinstance(actual, dict) or not isinstance(extras, dict):
        actual, extras = {}, {}
    expected = case["expected"]
    wrong = [slot for slot, value in expected.items() if slot not in actual or actual[slot] != value]
    unexpected = sorted(set(actual) - set(expected))
    extra_matches = extras == case["expected_extra"]
    newly_filled = [slot for slot, value in expected.items() if value not in (None, "") and value != case["initial"][slot]]
    correct_fills = sum(actual.get(slot) == expected[slot] for slot in newly_filled)
    return {"passed": bool(shaped and not wrong and not unexpected and extra_matches),
        "correct_new_slots": correct_fills, "expected_new_slots": len(newly_filled), "wrong_slots": wrong,
        "unexpected_slots": unexpected, "unsupported_requirements_match": extra_matches,
        "wrong_slot_rate": len(wrong) / max(1, len(expected)), "semantic_correctness": None}


def validate_evaluation(record, pack):
    import model_lifecycle_runtime as runtime
    if (record.get("objective_id") != OBJECTIVE or record.get("pack") != pack
            or record.get("adjudicated") is not False or record.get("training_eligible") is not False
            or not isinstance(record.get("cases"), list) or not 1 <= len(record["cases"]) <= 3
            or not isinstance(record.get("results"), list) or len(record["results"]) != len(record["cases"])
            or not isinstance(record.get("connection"), dict) or not isinstance(record.get("recorded_by"), str)
            or any(not isinstance(record['connection'].get(key), str) for key in ('provider', 'provider_id', 'model'))):
        raise ValueError("The intake measurement has an unreadable structure.")
    for reviewed, row in zip(record["cases"], record["results"]):
        case = validate_record(reviewed, pack)
        if (row.get("case_id") != case["case_id"] or row.get("score") != score(case, row.get("observed"))
                or type(row.get("calls")) is not int or not 0 <= row["calls"] <= 1
                or not isinstance(row.get("reply"), str) or not isinstance(row.get("raw_response"), str)
                or len(row['raw_response'].encode()) > 30_000 or not isinstance(row.get("error"), (type(None), str))
                or type(row.get('elapsed_seconds')) not in {int, float} or not math.isfinite(row['elapsed_seconds']) or row['elapsed_seconds'] < 0
                or row.get('cost_usd') is not None):
            raise ValueError("The retained intake score differs from its reviewed expected slots or observed output.")
        if row.get("error") and row["observed"] is not None:
            raise ValueError("A failed intake response cannot carry a scored successful prediction.")
        if row.get('response_sha256') != (runtime.digest(row['raw_response']) if row['raw_response'] else None):
            raise ValueError('The retained intake response differs from its collected digest.')
        if not row.get('error'):
            requests = []
            class Replay:
                def for_task(self, **kwargs):
                    return self
                def step(self, system, messages):
                    requests.append(runtime.digest([system, messages]))
                    if not isinstance(intake._parse_json(row['raw_response']).get('request'), dict):
                        raise ValueError('The retained intake response has no structured request.')
                    return row['raw_response']
            initial = intake.new_state(case['domain'], pack, record['recorded_by'])
            initial['request'] = dict(case['initial'])
            actual, reply = intake.next_turn(initial, case['message'], Replay())
            expected_observation = {'request': actual['request'], 'extra': actual.get('extra') or {}}
            if (row['observed'] != expected_observation or row['reply'] != reply or row['calls'] != len(requests)
                    or row.get('request_sha256') != (requests[0] if requests else None)):
                raise ValueError('The observed intake slots differ from replaying the exact retained model response.')
