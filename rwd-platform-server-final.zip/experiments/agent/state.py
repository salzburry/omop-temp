"""Run state: every step recorded to runs/<id>.json, resumable.

The transcript is the experiment's only output. It is a record for a person to read and for the
eval runner to score — never evidence, never an artifact a gate may consume.
"""
from __future__ import annotations

import json
import os
from contextvars import ContextVar
import re
import time

HERE = os.path.dirname(os.path.abspath(__file__))
# WHERE THE EXHAUST LIVES. RWDP_STATE_DIR names the one directory a deployment may write (runs,
# candidates, kept requests, the portal roster and snapshot) — on Databricks Apps the checkout is
# not writable and not durable (audit 8). Unset, the agent's own directory, as before.
STATE_DIR = os.path.realpath(os.environ.get("RWDP_STATE_DIR") or HERE)
RUNS = os.path.join(STATE_DIR, "runs")
# THE RUN IN PROGRESS, for whatever a run calls (a specialist stamps its candidate with it).
CURRENT_RUN: ContextVar = ContextVar("rwdp_current_run", default=None)


_RUN_ID = __import__("re").compile(r"^[A-Za-z0-9][A-Za-z0-9_-]{0,80}$")


def new_run_id() -> str:
    """Second-resolution ids collided: two immediate runs overwrote one record (second audit).
    Microseconds plus four random hex characters make a collision practically impossible, and
    the id stays a single safe path segment."""
    import secrets  # noqa: PLC0415
    return time.strftime("%Y%m%d-%H%M%S") + f"-{int(time.time() * 1e6) % 1000000:06d}" \
        + f"-{secrets.token_hex(2)}"


class RunState:
    def __init__(self, goal: str, run_id: str | None = None, actor: dict | None = None):
        # A SUPPLIED id is a filename segment, so it gets the grammar: `..\\state_outside` wrote a
        # record outside runs/ (second audit). Refused, not sanitised — a caller passing a path
        # where an id belongs is a bug to surface, not to paper over.
        if run_id is not None and not _RUN_ID.fullmatch(str(run_id)):
            raise ValueError(f"REFUSED — run_id {run_id!r} is not a safe id ([A-Za-z0-9_-], no "
                             f"separators)")
        self.run_id = run_id or new_run_id()
        self.goal = goal
        # WHO ASKED — portal attribution ({name, role}), or None for CLI runs. A LOG FIELD, never
        # an authority: nothing reads it to permit anything, and it never reaches an approval
        # surface — a typed name is never a signature.
        self.actor = actor
        self.model_id: str | None = None
        self.metrics: dict | None = None          # §19: latency/tokens/cost, stamped at finish
        self.steps: list[dict] = []
        self.outcome: dict | None = None
        self.primary_pack: str | None = None
        self.execution: dict | None = None
        self.workflow_continuations: list[dict] = []

    @property
    def path(self) -> str:
        return os.path.join(RUNS, f"{self.run_id}.json")

    def record(self, kind: str, **payload):
        self.steps.append({"n": len(self.steps) + 1, "kind": kind, **payload})
        self.save()

    def finish(self, status: str, summary: str):
        self.outcome = {"status": status, "summary": summary}
        self.save()

    def save(self):
        # SERIALISE FIRST, THEN REPLACE ATOMICALLY. `open(path, "w")` truncated the previous valid
        # transcript before json.dump could fail on an unserialisable step, leaving an empty file
        # where a record had been (third audit). A failure now leaves the last good record intact.
        payload = json.dumps({"run_id": self.run_id, "goal": self.goal, "actor": self.actor,
                              "model_id": self.model_id, "metrics": self.metrics,
                              "steps": self.steps, "outcome": self.outcome,
                              "primary_pack": self.primary_pack, "execution": self.execution,
                              "workflow_continuations": self.workflow_continuations}, indent=1)
        os.makedirs(RUNS, exist_ok=True)
        # A UNIQUE TEMP NAME PER WRITER: two concurrent resumes shared one `.tmp` and one of them
        # replaced the other's bytes (audit 7). The replace stays atomic; the name no longer races.
        import secrets  # noqa: PLC0415
        tmp = f"{self.path}.{os.getpid()}.{secrets.token_hex(3)}.tmp"
        with open(tmp, "w", encoding="utf-8") as fh:
            fh.write(payload)
        os.replace(tmp, self.path)

    @classmethod
    def resume(cls, run_id: str) -> "RunState":
        if not _RUN_ID.fullmatch(str(run_id)):
            raise ValueError(f"REFUSED — run_id {run_id!r} is not a safe id")
        with open(os.path.join(RUNS, f"{run_id}.json"), encoding="utf-8") as fh:
            d = json.load(fh)
        st = cls(d["goal"], run_id=d["run_id"], actor=d.get("actor"))
        st.steps, st.outcome = d["steps"], d.get("outcome")
        st.model_id, st.metrics = d.get("model_id"), d.get("metrics")
        st.primary_pack, st.execution = d.get('primary_pack'), d.get('execution')
        st.workflow_continuations = d.get('workflow_continuations') or []
        return st


CANDIDATES = os.path.join(STATE_DIR, "candidates")


def candidate_file(prefix: str, stem: str = "") -> str:
    """A fresh, contained filename for a specialist's packet: `<prefix>_<stem>_<run id>.json`
    under candidates/. The stem is flattened to [A-Za-z0-9_-] (a requirement named `PFS/OS`
    made a subdirectory, audit 6) and the id is microsecond + random, so two packets written in
    the same second never collide (they did, under a second-resolution timestamp)."""
    safe = re.sub(r"[^A-Za-z0-9_-]+", "_", str(stem or "")).strip("_")
    name = f"{prefix}_{safe}_{new_run_id()}.json" if safe else f"{prefix}_{new_run_id()}.json"
    path = os.path.realpath(os.path.join(CANDIDATES, name))
    if not path.startswith(os.path.realpath(CANDIDATES) + os.sep):
        raise ValueError("REFUSED — candidate path escaped candidates/")
    os.makedirs(CANDIDATES, exist_ok=True)
    return path
