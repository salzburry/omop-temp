"""Intake: ONE model call per turn, NO tools — the request is elicited, not investigated.

WHY. A chat that investigates on every message is slow, because every message becomes a
governed run (tool catalogue, tool calls, observations, more calls). A clarifying question — "do
you mean baseline or follow-up?" — needs none of that. Intake asks one question per turn and
accumulates a TYPED request object from the answers; only when the person says `check` (or `done`)
does the governed loop take over, with its evidence rules, against that typed request. That is the
"type code" moment of the tool we were compared with, kept — and the part that tool lacks, kept
too: options offered here are labelled as common practice, never as this study's answer, and a
choice the contract does not already state is a DECISION for its owner.

BY DOMAIN. The other tool is fast to elicit because it serves one kind of request (feasibility on
claims), so its slot list is fixed. Ours does the same by making the domain a DATA file:
`intake/<domain>.yaml` declares the slots, which slots are decisions for Science, and where a
finished request hands off. Domain experts edit YAML, not code.

WHAT THE MODEL MAY DO HERE. Ask the next question, restate the answer into the slots, offer
options with the fixed caveat. It has no tools, so it may not state facts about the repository
(what a pack contains, what a contract says) — `to_goal()` hands exactly those checks to the
governed loop. Pure functions apart from the single model call; tested with a scripted model.
"""
from __future__ import annotations

import glob
import copy
import functools
import json
import os
import re

import yaml

HERE = os.path.dirname(os.path.abspath(__file__))
TEMPLATES = os.path.join(HERE, "intake")

CAVEAT = ("Options offered here are common practice, not this study's answer. Which one applies is a "
          "decision for its owner unless the contract already states it. Nothing typed here is recorded. "
          "Type check to hand the request to the governed check, which verifies what it can and asks a "
          "person about the rest.")

_CODE_RE = re.compile(r"^[A-Z][0-9][0-9A-Z](\.[0-9A-Z]{1,4})?$")          # ICD-10-ish
_YEAR_RE = re.compile(r"^(19|20)\d{2}(-(0[1-9]|1[0-2])(-(0[1-9]|[12]\d|3[01]))?)?$")
_FULL_DATE_RE = re.compile(r"\b(19|20)\d{2}-\d{2}-\d{2}\b")
_YEAR_MONTH_RE = re.compile(r"\b(19|20)\d{2}-\d{2}\b(?!-)")
_YEAR_RANGE_RE = re.compile(r"\b((19|20)\d{2})\s*[-–—]\s*((19|20)\d{2})\b")
_BARE_YEAR_RE = re.compile(r"\b(19|20)\d{2}\b")
_NUMERIC_SHAPE_RE = re.compile(r"\d+(?:[/.-]\d+)+")


def date_tokens(text: str) -> tuple[list[str], list[str]]:
    """(dates found, in order; numeric shapes that are not dates). Words are never dates (second
    review: `calendar` and `-2024` were reported as bad dates); `2023-2024` is two years."""
    t = _YEAR_RANGE_RE.sub(r"\1 \3", str(text or ""))
    found = []
    for rx in (_FULL_DATE_RE, _YEAR_MONTH_RE):
        for m in rx.finditer(t):
            found.append((m.start(), m.group(0)))
        t = rx.sub(" ", t)
    bad = _NUMERIC_SHAPE_RE.findall(t)
    t = _NUMERIC_SHAPE_RE.sub(" ", t)
    for m in _BARE_YEAR_RE.finditer(t):
        found.append((m.start(), m.group(0)))
    return [d for _p, d in sorted(found)], bad
_VARIABLE_RE = re.compile(r"^[A-Za-z][A-Za-z0-9_]{1,40}$")
# UNSET. A person may clear a slot: deterministically, by typing `clear <slot>` (no model call), or
# through the model's `"unset": [<slot>, ...]` sentinel. `null`/"" from the model NEVER clears —
# the model returns null for what it did not fill. A none-word on an optional slot is empty.
_CLEAR_RE = re.compile(r"^\s*(?:clear|unset|drop|remove)\s+([A-Za-z][A-Za-z0-9_]{1,40})\s*[.!]?\s*$", re.I)
NONE_WORDS = frozenset({"none", "n/a", "na", "no", "nothing", "not applicable", "-"})
# DESIGN SANITY (ninth review): phrases that describe an invalid design pass no syntax check, so the
# precheck names them — a look-back after index, an exclusion that depends on the outcome, a rule
# chosen by whichever gives more patients. Deterministic phrases; the governed check reads the rest.
# narrowed after the second review: "12 months before index and 6 months after", "whichever is
# earlier" and "who died during baseline" are legitimate designs and are not flagged
_MORE_RE = r"\bwhichever\b(?![^.]*\b(earlier|earliest|first|later|latest|last|smaller|fewer)\b)[^.]*\b(more|most|larger|bigger|higher|greater)\b|\bgives\s+more\s+patients\b|\bmaximi[sz]e[sd]?\s+(the\s+)?(count|cohort|n|number)\b"
_DESIGN_RULES = (
    ("baseline_lookback", re.compile(r"^(?![^\n]*\b(before|prior|preceding)\b)[^\n]*\b(after\s+(the\s+)?index|post[- ]?index)\b", re.I | re.S),
     "a baseline look-back runs before index, not after it"),
    ("exclusions", re.compile(r"\bsurviv\w*\b.*\boutcome\b|\boutcome\b.*\bsurviv\w*\b|"
                              r"\b(die|dies|died|dying|death|deaths|dead|deceased|mortality|develop\w*|progress\w*)\b"
                              r"[^.]*\b(after\s+(the\s+)?index|during\s+follow[- ]?up|post[- ]?index|within\s+\d+\s+(days|months|years)\s+of\s+index)\b", re.I),
     "an exclusion that depends on the outcome (or on surviving it) conditions on the future; that is a design defect, not a decision"),
    ("code_position", re.compile(_MORE_RE, re.I),
     "a rule chosen by whichever gives more patients is not a definition; pick the rule, then count"),
    ("exclusion_rule", re.compile(_MORE_RE, re.I),
     "a rule chosen by whichever gives more patients is not a definition; pick the rule, then count"),
)


class _TemplatesChanged(ValueError):
    pass


def _template_stamp(path):
    info = os.stat(path)
    return (os.path.realpath(path), info.st_dev, info.st_ino, info.st_size,
            info.st_mtime_ns, info.st_ctime_ns)


def _template_inventory():
    return tuple((path, _template_stamp(path)) for path in sorted(glob.glob(os.path.join(TEMPLATES, "*.yaml"))))


@functools.lru_cache(maxsize=8)
def _domain_templates(inventory):
    """Parse once per exact file inventory; never cache an in-flight rewrite."""
    out = {}
    for path, stamp in inventory:
        if _template_stamp(path) != stamp:
            raise _TemplatesChanged("Intake templates changed while being read.")
        with open(path, encoding="utf-8") as fh:
            tpl = yaml.safe_load(fh) or {}
        if _template_stamp(path) != stamp:
            raise _TemplatesChanged("Intake templates changed while being read.")
        name = os.path.splitext(os.path.basename(path))[0]
        slots = tpl.get("slots") or []
        assert tpl.get("title") and tpl.get("handoff") and slots, f"{name}: title, handoff and slots are required"
        for s in slots:
            assert s.get("id") and s.get("ask"), f"{name}: every slot has an id and an ask"
        tpl["name"] = name
        out[name] = tpl
    if _template_inventory() != inventory:
        raise _TemplatesChanged("Intake templates changed while being read.")
    return out


def domains() -> dict:
    """Validated templates with stamp-aware caching and isolated caller copies.

    Every access checks the file inventory, identities, sizes and nanosecond
    modification/change stamps. Editing, replacing, adding or removing a template
    invalidates the parse cache; callers cannot mutate a later person's template.
    """
    for _ in range(3):
        try:
            return copy.deepcopy(_domain_templates(_template_inventory()))
        except _TemplatesChanged:
            continue
    raise ValueError("Intake templates are changing. Retry after the edit finishes.")


def new_state(domain: str, pack: str, actor: str) -> dict:
    tpl = domains()[domain]
    return {"domain": domain, "pack": pack, "actor": actor, "turns": 0,
            "request": {s["id"]: None for s in tpl["slots"]}, "notes": [], "cleared": []}


def _required(tpl) -> list[str]:
    return [s["id"] for s in tpl["slots"] if s.get("required", True)]


def ready(state: dict) -> bool:
    tpl = domains()[state["domain"]]
    return all(_filled(state["request"].get(sid)) for sid in _required(tpl))


def _filled(v) -> bool:
    """A value counts only when it says something: whitespace is empty (ninth review)."""
    if isinstance(v, str):
        return bool(v.strip())
    return v not in (None, "", [], {})


def system_prompt(state: dict) -> str:
    tpl = domains()[state["domain"]]
    lines = [f"You are the INTAKE assistant for a governed RWD platform. Request kind: {tpl['title']}.",
             f"Pack in context: {state['pack']}. You have NO tools: never state what a pack, a contract "
             f"or a database contains — those are checked later by a different loop.",
             "", "Your only job each turn: read the person's message, fill the slots it answers, and ask "
             "ONE question — the first required slot still empty. When every required slot is filled, "
             "ask nothing and say so.", "",
             "Rules: when you offer options, they are common practice, not this study's answer — say "
             "so in one clause; never decide for the person; never invent codes or table names; keep "
             "the question under 60 words.", "", "Slots (id · ask · required · decision-for-owner):"]
    for s in tpl["slots"]:
        opts = ""
        if s.get("options"):
            opts = " options: " + "; ".join(str(o.get("label") if isinstance(o, dict) else o) for o in s["options"])
        lines.append(f"- {s['id']} · {s['ask']} · required={s.get('required', True)} · "
                     f"decision={s.get('decision', False)}{opts}")
    lines += ["", "Reply with ONE JSON object and nothing else:",
              '{"request": {"<slot id>": <value or null>, ...}, "ask": "<the next question, or empty>", '
              '"notes": "<one line at most, optional>"}']
    return "\n".join(lines)


def _parse_json(text: str) -> dict:
    """The first JSON object in `text`; {} when none — the model's prose never becomes a slot."""
    dec = json.JSONDecoder()
    for i, ch in enumerate(text or ""):
        if ch == "{":
            try:
                obj, _ = dec.raw_decode(text[i:])
                return obj if isinstance(obj, dict) else {}
            except ValueError:
                continue
    return {}


# INGRESS CLASSIFICATION (audit 8). The AI boundary admits two sanitized derivations and nothing
# individual-level — and a person can paste anything into a chat. Deterministic patterns, checked
# before ANY model call in either mode: identifiers of individuals, dates of birth or death, a
# national-id shape, and a table of dated rows. The message is refused with a reason; nothing of
# it reaches a model, a transcript or a kept request.
_INGRESS = (
    # the token after the label must carry a digit: "patient number is unknown" is prose (second review)
    (re.compile(r"\b(mrn|medical record (number|no)|patient[\s_-]*(id|number|no)|member[\s_-]*(id|number)|"
                r"enrol{1,2}ee[\s_-]*id|subject[\s_-]*id|nhs number|ssn|social security)\b\s*[:#=]?\s*"
                r"(?=[A-Za-z0-9-]*\d)[A-Za-z0-9-]{4,}",
                re.I), "an identifier of an individual (a record number, patient or member id)"),
    (re.compile(r"\b\d{3}-\d{2}-\d{4}\b"), "a national identifier pattern"),
    (re.compile(r"\b(dob|date of birth|born on|birth ?date)\b\W{0,3}\d{1,4}[-/.]\d{1,2}[-/.]\d{1,4}", re.I),
     "a date of birth"),
    (re.compile(r"\b(died|death|deceased|dod)\b\W{0,6}\d{4}[-/]\d{2}[-/]\d{2}", re.I),
     "an individual's date of death"),
)
_DATED_ROW = re.compile(r"\d{4}-\d{2}-\d{2}|\d{1,2}/\d{1,2}/\d{2,4}")


def classify_ingress(text) -> list[str]:
    """Why this text looks like individual-level data ([] when it does not)."""
    t = str(text or "")
    reasons = [why for rx, why in _INGRESS if rx.search(t)]
    rows = [l for l in t.splitlines() if (l.count(",") + l.count("\t") + l.count("|")) >= 3 and _DATED_ROW.search(l)]
    if len(rows) >= 3:
        reasons.append(f"{len(rows)} delimited rows with dates, which looks like a table of individual records")
    return reasons


def ingress_refusal(reasons: list[str]) -> str:
    return ("This looks like it contains details about individual people: " + "; ".join(reasons)
            + ". I cannot take that here, and none of it was kept or sent to a model. Describe the population "
              "and the rules instead, without identifiers or dates for any one person.")


def _clear(new: dict, sid: str, who: str) -> bool:
    """Empty one slot (or one unsupported extra) and say so; False when there is nothing by that name."""
    if sid in new["request"]:
        new["request"][sid] = None
    elif sid in new["extra"]:
        del new["extra"][sid]
    else:
        return False
    new["cleared"] = sorted(set(new.get("cleared") or []) | {sid})
    new["notes"] = list(new.get("notes") or []) + [f"{sid} cleared by the person ({who}, turn {new['turns']})"]
    return True


def _none_is_empty(slot: dict) -> bool:
    return bool(slot.get("none_is_empty", not slot.get("required", True)))


def next_turn(state: dict, user_text: str, model) -> tuple[dict, str]:
    """One model call. Returns (new state, reply). Slots the model names that the template does
    not declare are dropped; readiness is computed HERE, never taken from the model."""
    reasons = classify_ingress(user_text)
    if reasons:
        return state, ingress_refusal(reasons)
    tpl = domains()[state["domain"]]
    m = _CLEAR_RE.match(str(user_text or ""))
    if m:
        # `clear <slot>`: a person's act, applied here without a model
        new = dict(state); new["request"] = dict(state["request"]); new["extra"] = dict(state.get("extra") or {})
        new["turns"] = state["turns"] + 1
        sid = m.group(1).lower()
        if _clear(new, sid, "typed"):
            missing = [s for s in _required(tpl) if not _filled(new["request"].get(s))]
            nxt = ("" if not missing else " Next: " + next(s["ask"] for s in tpl["slots"] if s["id"] == missing[0]))
            return new, f"{sid} cleared." + nxt
        return state, f"Nothing named {sid!r} is on this request; slots: " + ", ".join(s["id"] for s in tpl["slots"])
    system = system_prompt(state)
    transcript = [{"role": "user", "content":
                   f"Request so far (JSON): {json.dumps(state['request'])}\n"
                   f"The person says: {user_text}"}]
    from control_plane import task_model  # Guidance only; intake has no tool dispatcher.
    model = task_model(model, route="governed_check", query=user_text,
        task_scope={"pack": state["pack"]} if state.get("pack") else {})
    raw = model.step(system, transcript)
    parsed = _parse_json(raw)
    new = dict(state)
    new["request"] = dict(state["request"])
    known = {s["id"] for s in tpl["slots"]}
    by_id = {s["id"]: s for s in tpl["slots"]}
    new["extra"] = dict(state.get("extra") or {})
    new["turns"] = state["turns"] + 1
    for sid, val in (parsed.get("request") or {}).items():
        if not _filled(val):
            continue
        clean = val if isinstance(val, (str, int, float, list)) else json.dumps(val)
        if sid in known and isinstance(clean, str) and clean.strip().lower() in NONE_WORDS and _none_is_empty(by_id[sid]):
            _clear(new, sid, f"answered {clean.strip()!r}")
            continue
        if classify_ingress(str(clean)):
            # a model-produced value that looks like individual data is not kept, and the note says so
            new["notes"] = list(new.get("notes") or []) + [f"a value offered for {sid} looked like data about "
                                                         f"individual people and was not kept"]
            continue
        if sid in known:
            new["request"][sid] = clean
        else:
            # PRESERVED, NOT DROPPED (ninth review): a requirement this request kind has no slot for
            # (an exposure, a comparator, an estimand) stays on the request as UNSUPPORTED, is shown
            # to the person, and rides into the governed check labelled as such
            new["extra"][str(sid)[:60]] = clean
    # the sentinel wins over an echoed value; only names this request carries are cleared
    for sid in (parsed.get("unset") or []) if isinstance(parsed.get("unset"), list) else []:
        _clear(new, str(sid), "model read the message as clearing it")
    note = str(parsed.get("notes") or "").strip()
    if note:
        new["notes"] = list(state.get("notes") or []) + [note[:200]]
    if ready(new):
        reply = ("Every required field is filled. Type `check` to hand this typed request to the "
                 "governed loop (it verifies what tools can verify and escalates the decisions to "
                 "their owners), or keep refining.")
        if new.get("extra"):
            reply += (" Note: " + ", ".join(sorted(new["extra"])) + " are not part of this request kind; they "
                      "are kept on the request as unsupported requirements and will be named, not acted on.")
    else:
        ask = str(parsed.get("ask") or "").strip()
        missing = [s for s in _required(tpl) if not _filled(new["request"].get(s))]
        reply = ask or f"Next: {next(s['ask'] for s in tpl['slots'] if s['id'] == missing[0])}"
    return new, reply


def decisions(state: dict) -> list[dict]:
    """The filled slots the template marks as decisions — each a question for its owner."""
    tpl = domains()[state["domain"]]
    out = []
    for s in tpl["slots"]:
        if s.get("decision") and _filled(state["request"].get(s["id"])):
            out.append({"slot": s["id"], "value": state["request"][s["id"]],
                        "owner": s.get("owner") or tpl.get("owner") or "Science"})
    return out


def precheck(state: dict, known_packs, known_variables=None) -> list[str]:
    """Deterministic findings BEFORE any governed run: the pack must exist, codes must look like
    codes (or name a contract variable, when the caller says which exist), dates must be dates,
    required slots must be filled, and the design must not be self-defeating. Cheap, and no model."""
    tpl = domains()[state["domain"]]
    out = []
    if known_packs is not None and state["pack"] not in set(known_packs):
        out.append(f"pack {state['pack']!r} is not a registered pack")
    variables = {str(x).upper() for x in (known_variables or [])}
    for s in tpl["slots"]:
        v = state["request"].get(s["id"])
        if not _filled(v):
            if s.get("required", True):
                out.append(f"{s['id']} is required and empty")
            continue
        # A NONE-WORD IS NOT AN ANSWER TO A REQUIRED SLOT (twelfth verdict, P1-8): "none" in the
        # exclusions slot read as "exclusions: none" (a design statement) — which it may be, but
        # only when the person says so: `none (say none)` or `no exclusions` is a statement, a bare
        # `none`/`n/a`/`-` is a slot nobody filled.
        if s.get("required", True) and isinstance(v, str) and v.strip().lower() in NONE_WORDS:
            out.append(f"{s['id']}: {v.strip()!r} is a placeholder, not an answer — a required slot "
                       f"takes a statement; if the design truly has no {s['id'].replace('_', ' ')}, "
                       f"say so in words (e.g. 'no exclusions: the full cohort is analysed')")
            continue
        # a VALUE is ingress too, whoever wrote it (tenth review: model-generated or reused values
        # were never rechecked for identifiers)
        _why = classify_ingress(str(v))
        if _why:
            out.append(f"{s['id']}: looks like data about individual people ({_why[0]}); remove it before checking")
            continue
        kind = s.get("kind")
        if kind == "codes":
            # a list from the model is a list of codes, not the text "['C61', 'C79.51']" (tenth review)
            raw = v if isinstance(v, list) else re.split(r"[,\s;]+", str(v))
            tokens = [str(c).strip() for c in raw if str(c).strip()]
            bad = [c.upper() for c in tokens if not _CODE_RE.match(c.upper())
                   and not (variables and _VARIABLE_RE.match(c) and c.upper() in variables)]
            if bad:
                out.append(f"{s['id']}: {', '.join(bad[:5])} do not look like ICD-10 codes (e.g. J44, J45.9)"
                           + (" or name a contract variable of this pack" if variables else ""))
        elif kind == "year":
            # dates are read as dates and nothing else is a date (ninth review: `2024-01-01` was split
            # on its hyphens; second review: ordinary words were reported as bad dates)
            dates, bad = date_tokens(v)
            bad += [d for d in dates if not _YEAR_RE.match(d)]
            if bad:
                out.append(f"{s['id']}: {', '.join(bad[:5])} are not years or dates (YYYY or YYYY-MM-DD)")
            elif not dates:
                out.append(f"{s['id']}: names no year or date (YYYY or YYYY-MM-DD)")
            elif len(dates) >= 2 and dates[0] > dates[-1]:
                out.append(f"{s['id']}: the window ends ({dates[-1]}) before it starts ({dates[0]})")
        for slot, rx, why in _DESIGN_RULES:
            if s["id"] == slot and rx.search(str(v)):
                out.append(f"{slot}: {why} (you wrote {str(v)[:60]!r})")
    return out


def unsupported_requirements(state: dict) -> dict:
    """What the request asks for that this platform does not perform: the requirements no slot
    carries (`extra`) AND the filled slots the template marks `unsupported_downstream` (the brief's
    exposure and comparator). Preserved and named, never acted on."""
    tpl = domains()[state["domain"]]
    out = dict(state.get("extra") or {})
    for s in tpl["slots"]:
        if s.get("unsupported_downstream") and _filled(state["request"].get(s["id"])):
            out[s["id"]] = state["request"][s["id"]]
    return out


def to_goal(state: dict) -> str:
    """The goal handed to the governed loop: verify, cite, escalate — never decide."""
    tpl = domains()[state["domain"]]
    decs = decisions(state)
    lines = [f"Check this {tpl['title']} request against pack {state['pack']} — typed request (JSON):",
             json.dumps({k: v for k, v in state["request"].items() if _filled(v)}, indent=1),
             "", "Use the tools to verify what tools can verify: the pack exists; every variable, code "
             "list or concept named is in the contract or the definitions; precedents for each choice "
             "marked as a decision. Cite the tool output for every claim. Do NOT decide any open "
             "question and do NOT treat a precedent as an answer — a person decides; escalate."]
    if decs:
        lines.append("Decisions in this request (a person answers each; do NOT decide them, do NOT "
                     "treat a precedent as an answer):")
        lines += [f"- {d['slot']} = {d['value']!r} — owner {d['owner']}" for d in decs]
    unsupported = unsupported_requirements(state)
    if state.get("cleared"):
        lines.append("Cleared by the person (empty on purpose; do NOT treat as missing, do NOT re-ask): "
                     + ", ".join(state["cleared"]))
    if unsupported:
        lines.append("Requested but not supported by this request kind or this platform (name them in the reply "
                     "as unsupported; do NOT act on them, do NOT verify them, do NOT drop them): "
                     + "; ".join(f"{k} = {v!r}" for k, v in sorted(unsupported.items())))
    lines.append(f"Hand-off when verified: {tpl['handoff']}")
    return "\n".join(lines)


def exploration_command(state: dict) -> str | None:
    """The exploration-lane command a checked FEASIBILITY request (or a product brief) hands the
    analyst — the counts and the criterion-level attrition table run THERE, never inside the chat
    (feasibility.yaml's hand-off). Deterministic from the typed slots: each inclusion criterion and
    exclusion becomes one `--step` with its column and value left for the analyst to bind, because
    a free-text criterion is not a column and the lane refuses a column nothing defines unless it
    is assumed and logged. None for a request kind with no counts to run."""
    req = state.get("request") or {}
    tpl = domains()[state["domain"]]
    if state["domain"] not in ("feasibility", "product_brief"):
        return None
    steps = []
    for sid, label in (("index_codes", "index condition"), ("inclusion_sequence", "inclusion"),
                       ("exclusions", "exclude")):
        v = req.get(sid)
        if not _filled(v) or str(v).strip().lower() in NONE_WORDS:
            continue
        parts = [p.strip() for p in re.split(r"[;\n]+|\d+\.\s", str(v)) if p.strip()] if sid == "inclusion_sequence" \
            else [str(v).strip()]
        for p in parts:
            # the criterion's words ride in the LABEL; the clause is the analyst's to bind
            steps.append(f'--step "{label} ({p[:60].replace(chr(34), chr(39))}): <col>=<value>"')
    cut = str(req.get("source_cut") or req.get("source") or "<cut>").strip()[:40]
    who = str(req.get("requested_by") or "").strip()
    cmd = (f"python3 platform/tools/quick_counts.py {state['pack']} --frame <patient-level TSV outside the "
           f"checkout> --cut \"{cut}\" --grain patient " + " ".join(steps)
           + " --log-dir <ledger dir outside the checkout>" + (f' --asked-by "{who[:40]}"' if who else ""))
    return cmd + f"   # {tpl['title']}: counts and criterion-level attrition, exploration lane, non-evidence grade"


def to_yaml(state: dict) -> str:
    """The typed request as a person would save it — a draft, written by nobody here."""
    doc = {"kind": state["domain"], "pack": state["pack"], "raised_by": state["actor"],
           "request": {k: v for k, v in state["request"].items() if _filled(v)},
           "cleared": list(state.get("cleared") or []),
           "decisions_for_a_person": decisions(state), "notes": state.get("notes") or [],
           "unsupported_requirements": unsupported_requirements(state),
           "caveat": CAVEAT}
    cmd = exploration_command(state)
    if cmd:
        doc["exploration_command"] = cmd
    return yaml.safe_dump(doc, sort_keys=False, allow_unicode=True, width=100)


# ---------------------------------------------------------------------------------------------
# PAST-REQUEST REUSE, BESIDE PRECEDENTS. The compared tool keeps every prior query and offers the
# similar ones to pre-fill a new request; the precedents store already does that for DECISIONS.
# Kept requests live in the agent's gitignored exhaust (experiments/agent/requests/) — they are
# knowledge about how people ask, never governance, and registering one as a work object stays a
# person's act (governance/ACTIONS.yaml: register_request). Similarity is DETERMINISTIC: token
# overlap of the descriptive slots within the same domain; no model ranks anything. Pre-fill copies
# a past value only into an EMPTY slot, never who asked, and a pre-filled decision stays a decision.
REQUESTS = os.path.join(os.path.realpath(os.environ.get("RWDP_STATE_DIR") or HERE), "requests")
_SIMILARITY_SLOTS = ("source", "population", "index_codes", "measure", "exclusions", "variable_id",
                     "change", "definition", "topic", "question",
                     # the product brief's descriptive slots (eleventh verdict: two briefs differing
                     # in source cut, index, outcomes, variables, grain, cadence and acceptance
                     # criteria scored identically) — never who asked or who consumes
                     "intended_use", "index_definition", "inclusion_sequence", "baseline_lookback",
                     "follow_up", "outcomes", "variables_domains", "source_cut", "output_grain",
                     "refresh_cadence", "acceptance_criteria", "deliverables")
_NEVER_PREFILL = ("requested_by",)
# A KEPT REQUEST HAS A LIFECYCLE (audit 8): what the governed check made of it decides whether it
# may pre-fill another. A draft or a checked request may; a failed or withdrawn one never does.
STATUSES = ("draft", "checked", "failed", "withdrawn")
# ONLY A CHECKED REQUEST PRE-FILLS ANOTHER (eleventh verdict): a draft is kept — it is how people
# ask — but the governed check never saw it, and the module's own premise is that what the check
# made of a request decides whether it may pre-fill the next one.
REUSABLE_STATUSES = ("checked",)


def request_digest(state: dict) -> str:
    """sha256 over the canonical typed request — kind, pack and the filled slots — so a kept
    request's bytes are bound to the check it claims (eleventh verdict: a `checked` request
    carried no digest, and the label rode on bytes no check had seen)."""
    import hashlib  # noqa: PLC0415
    doc = {"kind": state["domain"], "pack": state["pack"],
           "request": {k: v for k, v in sorted(state["request"].items()) if _filled(v)}}
    return hashlib.sha256(json.dumps(doc, sort_keys=True, ensure_ascii=True).encode("utf-8")).hexdigest()


def run_record_path(run_id: str, directory: str | None = None) -> str:
    """Where the orchestrator persisted the run `run_id` (experiments/agent/state.py: runs/<id>.json
    beside the requests directory)."""
    base = os.path.dirname(os.path.realpath(directory or REQUESTS))
    return os.path.join(base, "runs", f"{run_id}.json")


def save_request(state: dict, directory: str | None = None, status: str = "draft",
                 run_id: str | None = None, outcome: str | None = None) -> str:
    """Keep a typed request for reuse: one YAML file, unique name, inside `directory` only, with
    its lifecycle (`status`, the check's `run_id` and `outcome`) on its face.

    A `checked` request names the run that checked THESE bytes: the run record's goal must be the
    goal `to_goal` builds from this state, or the request is refused — the label that authorises
    pre-filling other people's requests never rides on bytes no check saw."""
    import secrets  # noqa: PLC0415
    import time  # noqa: PLC0415
    directory = directory or REQUESTS
    if status not in STATUSES:
        raise ValueError(f"REFUSED — request status {status!r} is not one of {STATUSES}")
    if status == "checked":
        if not run_id:
            raise ValueError("REFUSED — a checked request names the run that checked it")
        try:
            with open(run_record_path(run_id, directory), encoding="utf-8") as fh:
                run = json.load(fh)
        except (OSError, ValueError):
            raise ValueError(f"REFUSED — run {run_id!r} has no readable record, so nothing shows it "
                             f"checked this request") from None
        if str(run.get("goal") or "") != to_goal(state):
            raise ValueError(f"REFUSED — run {run_id!r} did not check this request (its goal is not "
                             f"this typed request); keep it as a draft or check it")
    os.makedirs(directory, exist_ok=True)
    name = f"{state['domain']}_{time.strftime('%Y%m%d-%H%M%S')}-{secrets.token_hex(3)}.yaml"
    path = os.path.realpath(os.path.join(directory, name))
    if not path.startswith(os.path.realpath(directory) + os.sep):
        raise ValueError("REFUSED — request path escaped the requests directory")
    doc = yaml.safe_load(to_yaml(state)) or {}
    doc.update({"status": status, "run_id": run_id, "outcome": outcome,
                "request_sha256": request_digest(state),
                "kept_at": time.strftime("%Y-%m-%dT%H:%M:%S")})
    with open(path, "w", encoding="utf-8") as fh:
        fh.write(yaml.safe_dump(doc, sort_keys=False, allow_unicode=True, width=100))
    return path


def load_requests(directory: str | None = None) -> list[dict]:
    """Every kept request that parses to the saved shape; malformed files are skipped, never raised."""
    out = []
    for path in sorted(glob.glob(os.path.join(directory or REQUESTS, "*.yaml"))):
        try:
            with open(path, encoding="utf-8") as fh:
                doc = yaml.safe_load(fh) or {}
        except (OSError, yaml.YAMLError):
            continue
        if not (isinstance(doc, dict) and doc.get("kind") and isinstance(doc.get("request"), dict)):
            continue
        doc["_file"] = os.path.basename(path)
        # THE STATUS IS RE-DERIVED, NEVER TRUSTED ON LOAD (twelfth verdict, P1-7): a file that SAID
        # `checked` pre-filled other people's requests whatever its bytes were. `checked` holds only
        # while the digest matches these bytes AND the named run's record still has this request as
        # its goal; otherwise the request is read back as a draft, with the reason on its face.
        if doc.get("status") == "checked":
            state = {"domain": doc["kind"], "pack": doc.get("pack"), "request": doc["request"]}
            why = None
            try:
                if str(doc.get("request_sha256") or "") != request_digest(state):
                    why = "its bytes no longer match the digest the check was made over"
                else:
                    with open(run_record_path(str(doc.get("run_id") or ""),
                                              directory or REQUESTS), encoding="utf-8") as fh:
                        run = json.load(fh)
                    if str(run.get("goal") or "") != to_goal(state):
                        why = f"run {doc.get('run_id')!r} did not check this request"
            except (OSError, ValueError, KeyError, TypeError):
                why = f"run {doc.get('run_id')!r} has no readable record"
            if why:
                doc["status"], doc["demoted_from"], doc["demoted_why"] = "draft", "checked", why
        out.append(doc)
    return out


def _tokens(request: dict) -> set:
    words = set()
    for slot in _SIMILARITY_SLOTS:
        v = request.get(slot)
        if _filled(v):
            words |= {w for w in re.split(r"[^a-z0-9]+", str(v).lower()) if len(w) > 2}
    return words


def similar(state: dict, past: list[dict], k: int = 3, scope=None, same_pack: bool = True,
            lineage=()) -> list[tuple[float, dict]]:
    """[(score, past request)] for the same domain, best first, score = Jaccard over the
    descriptive slots' tokens; zero-overlap requests are not offered. Only REUSABLE requests
    (checked) from packs inside `scope` (when given) are candidates, and by default only
    requests about the SAME PRODUCT — this pack, or a prior version of it named in `lineage`
    (eleventh verdict: prostate/202607 could not see prostate/202606's requests; tenth review: an
    ovarian request pre-filled prostate work); `same_pack=False` is an explicit opt-in that the
    caller labels. A request with no status is nobody's evidence and is never offered."""
    mine = _tokens(state["request"])
    if not mine:
        return []
    scope = None if scope is None else {str(p).replace("\\", "/").strip("/") for p in scope}
    my_pack = str(state.get("pack") or "").replace("\\", "/").strip("/")
    same_product = {my_pack} | {str(p).replace("\\", "/").strip("/") for p in (lineage or ())}
    ranked = []
    for req in past:
        if req.get("kind") != state["domain"]:
            continue
        if same_pack and str(req.get("pack") or "").replace("\\", "/").strip("/") not in same_product:
            continue
        if str(req.get("status") or "") not in REUSABLE_STATUSES:
            continue
        if scope is not None and str(req.get("pack") or "").replace("\\", "/").strip("/") not in scope:
            continue
        theirs = _tokens(req.get("request") or {})
        if not theirs:
            continue
        score = len(mine & theirs) / len(mine | theirs)
        if score > 0:
            ranked.append((round(score, 3), req))
    ranked.sort(key=lambda t: (-t[0], t[1].get("_file", "")))
    return ranked[:k]


def prefill(state: dict, past: dict) -> dict:
    """Copy a past request's values into this request's EMPTY slots (never `requested_by`); the
    template's decision flags still apply, so a pre-filled decision remains a person's question."""
    status = str(past.get("status") or "")
    if status not in REUSABLE_STATUSES:
        raise ValueError(f"REFUSED — a {status or 'status-less'} request is never reused to pre-fill another")
    for sid, val in (past.get("request") or {}).items():
        if _filled(val) and classify_ingress(str(val)):
            raise ValueError(f"REFUSED — the past request's {sid} looks like data about individual people; "
                             f"it is not copied anywhere")
    tpl = domains()[state["domain"]]
    new = dict(state)
    new["request"] = dict(state["request"])
    copied = []
    for s in tpl["slots"]:
        sid = s["id"]
        if sid in _NEVER_PREFILL or _filled(new["request"].get(sid)) or sid in (state.get("cleared") or []):
            continue
        val = (past.get("request") or {}).get(sid)
        if _filled(val):
            new["request"][sid] = val
            copied.append(sid)
    if copied:
        new["notes"] = list(state.get("notes") or []) + [
            f"pre-filled {', '.join(copied)} from past request {past.get('_file') or '?'} — check each; "
            f"decisions among them are still this study's to make"]
    return new
