"""A governed run in a background thread, observable while it runs.

WHY. The portal executed `orchestrator.run` inline, so the page blocked for the whole run and the
streamed steps could only be drawn by the same blocked script. A Job runs the loop in a thread,
collects every step the loop reports (`on_step`), and the page polls it: the step stream keeps
flowing, the person can keep reading, and a run that ends in an exception is a recorded error on
the job, never a traceback on the page. ContextVars (the run's usage accumulator and ceiling) are
set inside the thread by the loop itself, so a job is as bounded as an inline run.
"""
from __future__ import annotations

import contextvars
import threading
import time


class Job:
    def __init__(self, label: str = ""):
        self.label = label
        self.steps: list[dict] = []
        self.result = None
        self.error: str | None = None
        self.done = False
        self.started = time.time()
        self.finished: float | None = None
        self._lock = threading.Lock()

    def _on_step(self, step: dict) -> None:
        with self._lock:
            self.steps.append(step)

    def snapshot(self) -> list[dict]:
        with self._lock:
            return list(self.steps)

    @property
    def elapsed(self) -> float:
        return (self.finished or time.time()) - self.started


def start(fn, label: str = "", **kw) -> Job:
    """Run `fn(**kw, on_step=job._on_step)` in a daemon thread; the returned Job fills as it goes.
    `fn` is orchestrator.run or orchestrator.resume_run; any exception becomes `job.error`."""
    job = Job(label)
    ctx = contextvars.copy_context()                 # the page's scope and snapshot travel into the job

    def target():
        try:
            job.result = fn(**kw, on_step=job._on_step)
        except BaseException as e:  # noqa: BLE001 - the page must hear about every failure
            job.error = f"{type(e).__name__}: {str(e)[:400]}"
        finally:
            job.finished = time.time()
            job.done = True
    threading.Thread(target=lambda: ctx.run(target), name=f"rwdp-job-{label[:20]}", daemon=True).start()
    return job
