# experiments/agent — workflow agents, critics and evaluation

These components serve the local Streamlit workflow and the repository's agent
commands. They reuse governed readers, the current workflow skills, selected
model connections and reviewable results. Deterministic validators and explicit
review actions continue to own product changes and release requirements.

The common improvement loop is available from **Improve this step** in the portal:
capture sanitized feedback, run registered checks, review, enable or withdraw
guidance, share it through Git, and rerun its behaviour examples. See
[continuous workflow improvement](../../docs/CONTINUOUS_WORKFLOW_IMPROVEMENT.md).

## The boundary (non-negotiable)

- **Scoped access.** Working products and reference examples use the existing
  product authorization and source-access checks. The legacy CLI default is a
  reference pack; it is not an authorization for other products.
- **Reviewable outputs.** Model generation retains results and critiques. The
  portal's explicit review actions can preserve exact proposal snapshots under a
  product's handoff records. Generated code is not imported or executed by model
  generation, and a saved proposal does not apply itself to the pipeline.
- **Shared corrections.** `knowledge/corrections/` contains explicitly entered,
  sanitized workflow feedback and its check/review state. The same skill reader
  loads enabled guidance; the existing evaluator loads its familiar examples.
- **Stops at authority.** Scientific ambiguity, source equivalence, approvals, recorded answers
  and promotions are a person's; the orchestrator's system prompt says so, tool refusals are
  detected and force an escalation, and there is no tool through which an act could happen anyway.

## Pieces

| file | job |
|---|---|
| `tools.py` | the safe tool registry (MCP read surface + precedents + capabilities) |
| `orchestrator.py` | goal → observe → plan → act → inspect loop; escalates, never decides |
| `critic.py` | independent falsification of a proposal against requirement + evidence |
| `state.py` | run transcripts under `runs/`, resumable |
| `evals/cases.yaml` | adversarial cases, TSST first |
| `evals/cases_science_regressions.yaml` | verified software failure cases, generated/unadjudicated; whole-family split in `science_regression_split.json`, selectable through the existing portal evaluator ([benchmark and rerun instructions](../../docs/SCIENCE_SOFTWARE_REGRESSION_BENCHMARK_20260907.md)) |
| `evals/run.py` | runs cases through the orchestrator and scores expected behaviour (`--critic`, `--specialists`, `--rescore`) |
| `evals/generate_cases.py` | 84 register-derived cases (decisions, capabilities, lint invariants), tagged generated/unadjudicated |
| `evals/specialist_cases.yaml` | structural evals for the three specialists |
| `evals/history.py` | corpus composition and verdict flips between sweeps |
| `source_intel.py` / `coding_agent.py` / `validation_agent.py` | workflow specialists with retained proposals, critiques and review continuations |
| `learn.py` | shared correction capture, registered checks, reviewed guidance, withdrawal and evaluation examples; retains the legacy lesson tool |
| `models.yaml` | the model registry — ids, prices, sampling flags, efforts; **default `claude-sonnet-5`** (operator, 2026-09-01) |
| `bench/run_bench.py` | model × effort benchmark: Wilson intervals, cost per pass, stability, flatters check, budget cap |
| `ml/` | six advisory learners + `train_all.py`; a learner ships only above its baseline at n ≥ 30 |

## Intake, then check

The Agent section has two modes. **Intake** is one model call per turn and no tools: the model
elicits a typed request by domain (`intake/<domain>.yaml` — feasibility, contract change, open
question — the slots, which of them are decisions for an owner, and where a finished request hands
off), offers common options labelled as common practice, never decides, and never states what a
pack contains. Clarifying turns take seconds. **Check** (`check` or `done`) hands the typed request
to the governed loop — tools, evidence, the grounding rule, escalation — which runs in a background
job the page polls, so the step stream keeps flowing. The two are separated on purpose: talking is
cheap and ungoverned; establishing facts is governed and paid for. Kept requests (the agent's exhaust,
`requests/`) are offered to pre-fill a similar new request — deterministic overlap, same domain, never
who asked; a pre-filled decision is still this study's question. `governance/ACTIONS.yaml` and
`governance/OBJECTIVES.yaml` are the typed control plane the portal and the agent read: who performs
each governed act and the evidence required by each model objective. Local
review/evaluation/activation uses those existing objective requirements.

Eighth verdict (2026-09-03): pack scope is context-local and per call (`tools.call(scope=)`,
`run(scope=)`), and the portfolio and search readers filter by it; kept requests carry a lifecycle
(draft, checked, failed, withdrawn) and only draft or checked ones from packs in scope pre-fill; an
escalation reaches a registered owner or is rerouted to the operator; a resume checks the answerer's
eligibility against the roster's `owns` and records `answered` only when the successor reached done or
escalated; generated code identifiers are checked against the reviewed MAPPING_EVIDENCE.json before
the critic and every candidate is stamped with evidence digest, model, prompt version, commit and run;
patient-shaped text is refused at ingress in both modes.

## Running

```
set ANTHROPIC_API_KEY=...                # or it refuses, loudly
python experiments/agent/orchestrator.py --goal "Take fixtures/oncology/prostate/202606 as far toward build readiness as you safely can. Stop whenever scientific or approval authority is required."
python experiments/agent/evals/run.py    # the corpus; prints a scorecard
python experiments/agent/bench/run_bench.py --plan                      # the matrix and its cost, no calls
python experiments/agent/bench/run_bench.py --budget-usd 1              # a paid sweep, capped
python experiments/agent/bench/run_bench.py --report                    # report-only: reads results.jsonl, spends nothing
```

Model defaults to `claude-sonnet-5` — the registry default in `models.yaml` (operator decision,
2026-09-01); `RWD_AGENT_MODEL` overrides it, and the eval runner exists precisely so model choice
becomes evidence, not preference.
Every API call is bounded (`RWD_API_TIMEOUT_S`, default 120 s, one retry): a call that never
answers becomes an error row in the matrix, not a two-hour hang of everything behind it.
