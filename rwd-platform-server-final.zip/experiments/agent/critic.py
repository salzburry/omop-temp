"""The critic: independent falsification of a proposal against requirement + evidence.

The generator never grades its own work — and neither does the critic in any final sense: its
verdict routes (pass on / revise / human), it never accepts. The LLM is not its own acceptance
oracle; acceptance belongs to the deterministic checks and, past them, to a person.
"""
from __future__ import annotations

import json
import os
import re

REVIEW_CONTEXT_PREFIX = "BOUNDED_CRITIC_REVIEW_V1\n"
MAX_REVIEW_BYTES = 9_000

SYSTEM = """You are the critic on a governed oncology RWD platform. You receive a REQUIREMENT
(the authoritative ask), EVIDENCE (tool outputs, spec rows, decisions, profiles), and a PROPOSAL.

Your one job: try to FALSIFY the proposal. Check, in order:
- semantics: does the proposal answer what the requirement actually means?
- authority: does it rest on the current approved spec/decisions, or on something that cannot
  override them (precedent, source metadata, model knowledge)?
- temporality: windows, anchors, censoring — do the dates work?
- grain: does the record selection match the stated grain?
- pipeline integration, when an implementation is proposed: do its declared entry points,
  source/config dependencies and outputs match the supplied orchestration evidence? Are null,
  tie, repeat-run/idempotency and failure-path checks stated as plans, rather than reported as
  executed? Compilation or a static call graph does not establish a successful pipeline run.
- precedent fit: if a precedent is cited, does it actually apply here?
- invention: does ANY claim lack a supporting line in the evidence? Two things are NEVER
  invention: (a) a CITATION — text or a field value that appears in the supplied EVIDENCE,
  quoted or restated, is grounded by definition; check the evidence carefully before charging
  fabrication, because a false invention finding teaches generators to stop citing; (b) a
  DECLARED ASSUMPTION — an unsettled judgment listed openly under assumptions is honesty, and
  the correct response is route it to the owner, not falsify the proposal for containing it.
  Invention is a claim presented AS FACT that the evidence does not carry.

Reply with ONE JSON object only:
{"falsified": true|false, "confidence": "high|medium|low",
 "findings": ["<each concrete defect, or empty>"],
 "route": "pass_on|revise|human", "why": "<one line>"}
Default to "human" whenever scientific meaning or source equivalence is in doubt — a wrong
escalation costs minutes, a wrong acceptance costs a study."""


def _encoded(value):
    return json.dumps(value, ensure_ascii=False, separators=(",", ":"))


def _excerpt(value, limit):
    raw = value.encode("utf-8")
    if len(raw) <= limit:
        return value
    return raw[:limit].decode("utf-8", errors="ignore") + "\n[Excerpt: remaining evidence omitted; do not infer its contents.]"


def _coding_evidence(evidence, budget, *, preserve_excerpts=False):
    """Keep source, tests and orchestration together instead of a JSON prefix.

    Full provenance remains in the canonical candidate. Only the critic's view
    is shortened, with explicit omissions; no omitted fact becomes evidence.
    """
    if evidence.startswith("BOUNDED_VALIDATION_REQUEST_V1\n"):
        import validation_agent
        return validation_agent.bound_request(evidence, budget)
    if evidence.startswith("BOUNDED_SOURCE_REQUEST_V1\n"):
        import source_intel
        return source_intel.bound_request(evidence, budget)
    if len(evidence.encode("utf-8")) <= budget:
        return evidence
    try:
        doc = json.loads(evidence)
    except (ValueError, TypeError, RecursionError):
        return _excerpt(evidence, max(0, budget - 100))
    context = doc.get("implementation_context") if isinstance(doc, dict) else None
    if not isinstance(context, dict) or not isinstance(context.get("files"), list):
        return _excerpt(evidence, max(0, budget - 100))
    files = [f for f in context["files"] if isinstance(f, dict)]
    # At least one real implementation and one real test precede additional
    # references. This uses only supplied excerpts and never reads more files.
    first = [next((f for f in files if f.get("kind") == kind), None) for kind in ("implementation", "test")]
    ordered = [f for f in first if f is not None]
    ordered += [f for f in files if f.get("kind") == "implementation" and f not in ordered]
    ordered += [f for f in files if f not in ordered]
    orchestration = context.get("orchestration")
    capabilities = []
    supplied_capabilities = context.get("capabilities") or []
    if not isinstance(supplied_capabilities, list):
        raise ValueError("The supplied capability context is malformed.")
    for row in supplied_capabilities[:6]:
        if isinstance(row, dict):
            capabilities.append({key: row[key] for key in ("id", "master", "config_keys", "emits", "verification") if key in row})
    stage_modules = {str(row.get("path") or "").replace("\\", "/").rsplit("/", 1)[-1].removesuffix(".py")
                     for row in files if row.get("kind") == "implementation"}
    for count, excerpt_bytes, stage_count, ci_count, definition_bytes in (
            (8, 700, 14, 6, 1000), (6, 400, 8, 3, 700),
            (4, 250, 5, 2, 500), (4, 180, 2, 1, 300), (3, 80, 1, 1, 160)):
        retained = []
        for item in ordered[:count]:
            row = {key: item[key] for key in ("path", "symbol", "kind", "sha256", "line", "end_line", "truncated") if key in item}
            raw = item.get("excerpt") if isinstance(item.get("excerpt"), str) else ""
            row["excerpt"] = raw if preserve_excerpts else _excerpt(raw, excerpt_bytes)
            retained.append(row)
        view = {"pack": doc.get("pack"), "requirement_query": doc.get("requirement_query"),
            "definition": str(doc.get("definition") or "") if preserve_excerpts else _excerpt(str(doc.get("definition") or ""), definition_bytes),
            "implementation_context": {"registry_sha256": context.get("registry_sha256"), "capabilities": capabilities, "files": retained},
            "review_omissions": "This is a bounded evidence view. Some excerpts, capability descriptions and orchestration rows are omitted. Full source hashes and context remain in the candidate; request missing evidence instead of assuming equivalence."}
        if doc.get("user_request"):
            view["user_request"] = doc["user_request"]
        if isinstance(orchestration, dict):
            compact = {key: orchestration[key] for key in ("pack", "files", "entry_points", "configuration", "findings", "notice") if key in orchestration}
            for key, limit in (("stage_calls", stage_count), ("ci_commands", ci_count), ("jobs", ci_count)):
                if isinstance(orchestration.get(key), list):
                    rows = orchestration[key]
                    if key == "stage_calls":
                        matched = [row for row in rows if isinstance(row, dict) and str(row.get("call") or "").split(".", 1)[0] in stage_modules]
                        rows = matched + [row for row in rows if row not in matched]
                    compact[key] = rows[:limit]
                    if len(rows) > limit:
                        compact[key + "_omitted_count"] = len(rows) - limit
            view["implementation_context"]["orchestration"] = compact
        result = _encoded(view)
        if len(result.encode("utf-8")) <= budget:
            return result
    raise ValueError("The proposal and minimum implementation, test and orchestration evidence cannot fit in one critic request.")


def review_request(requirement, evidence, proposal):
    # A partial proposal is not the proposal being reviewed. Preserve its exact
    # text before supporting evidence and refuse oversized review subjects.
    if any(not isinstance(value, str) for value in (requirement, evidence, proposal)):
        raise ValueError("The critic needs textual requirement, evidence and proposal fields.")
    if len(evidence.encode("utf-8")) > 128_000:
        raise ValueError("The evidence exceeds the bounded review input size.")
    if not proposal.strip() or len(requirement.encode("utf-8")) > 1000 or len(proposal.encode("utf-8")) > 6000:
        raise ValueError("The complete requirement or proposal exceeds this bounded review; review a smaller coherent change.")
    head = REVIEW_CONTEXT_PREFIX + f"REQUIREMENT:\n{requirement}\n\nPROPOSAL:\n{proposal}\n\nEVIDENCE:\n"
    budget = MAX_REVIEW_BYTES - len(head.encode("utf-8"))
    result = head + _coding_evidence(evidence, budget)
    if len(result.encode("utf-8")) > MAX_REVIEW_BYTES:
        raise ValueError("The exact review context exceeds its bounded size.")
    return result


def _review(model, requirement: str, evidence: str, proposal: str) -> dict:
    # deterministic pre-checks — no model needed to refuse the obviously unreviewable
    if not isinstance(evidence, str) or not evidence.strip():
        return {"falsified": True, "confidence": "high",
                "findings": ["no evidence supplied — nothing to review against"],
                "route": "human", "why": "a proposal with no evidence cannot be reviewed"}
    try:
        content = review_request(requirement, evidence, proposal)
    except ValueError:
        return {"falsified": True, "confidence": "high", "route": "human",
                "findings": ["The complete proposal and minimum supporting evidence do not fit the bounded critic context."],
                "why": "Review a smaller coherent proposal with its source, tests and pipeline context; no partial proposal was sent."}
    raw = model.step(SYSTEM, [{"role": "user", "content": content}])
    m = re.search(r"\{.*\}", raw, re.S)
    if not m:
        return {"falsified": True, "confidence": "low",
                "findings": ["critic reply unparseable"], "route": "human",
                "why": "an unreadable verdict routes to a person, never to acceptance"}
    try:
        v = json.loads(m.group())
    except json.JSONDecodeError:
        return {"falsified": True, "confidence": "low",
                "findings": ["critic reply not valid JSON"], "route": "human",
                "why": "an unreadable verdict routes to a person, never to acceptance"}
    if (not isinstance(v, dict) or type(v.get("falsified")) is not bool
            or v.get("route") not in ("pass_on", "revise", "human")
            or not isinstance(v.get("findings"), list) or len(v["findings"]) > 100
            or any(not isinstance(item, str) or len(item) > 4000 for item in v["findings"])):
        return {"falsified": True, "confidence": "low", "findings": ["critic reply has an invalid structure"],
                "route": "human", "why": "An unreadable critique requires a new review before acting."}
    return v


def _calibration():
    """ml/calibration.json (train_all.py) — reliability by confidence bucket, or None."""
    p = os.path.join(os.path.dirname(os.path.abspath(__file__)), "ml", "calibration.json")
    if not os.path.exists(p):
        return None
    try:
        return json.load(open(p, encoding="utf-8")).get("buckets") or None
    except (ValueError, OSError):
        return None


def review(model, requirement: str, evidence: str, proposal: str) -> dict:
    """The critic verdict, annotated with the calibration policy (ML item 4).

    `second_vote_recommended` is ADVISORY and comes from measured reliability of this confidence
    bucket on the calibration corpus: a bucket whose Wilson lower bound is under 0.80, or with too
    few verdicts to know, recommends a second independent vote before the verdict is acted on. A
    missing calibration file recommends a second vote for everything — the safe default. The
    verdict itself is unchanged; the route is still the critic's, and acceptance is a person's.
    """
    v = _review(model, requirement, evidence, proposal)
    cal = _calibration()
    conf = str(v.get("confidence") or "unstated")
    if cal is None:
        v["second_vote_recommended"] = True
        v["calibration"] = "no calibration artifact — second vote by default"
    else:
        b = cal.get(conf)
        v["second_vote_recommended"] = True if b is None else bool(b.get("second_vote"))
        v["calibration"] = (f"bucket {conf}: reliability {b['reliability']} [{b['lo']},{b['hi']}] n={b['n']}"
                            if b else f"bucket {conf} unseen in calibration — second vote by default")
    return v
