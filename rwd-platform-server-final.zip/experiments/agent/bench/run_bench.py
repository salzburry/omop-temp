"""The model x effort (x temperature, where a model still accepts it) benchmark over the eval corpus.

WHAT IT MEASURES. For each configuration in the matrix, every selected case runs through the
orchestrator `--repeats` times. Per run: mechanical pass, the checks, outcome, latency, tokens,
cost (from models.yaml prices). Per configuration: pass rate with a Wilson interval, escalation
recall (cases expecting escalation that escalated), false-escalation rate (cases expecting done
that escalated), tool selection, mean latency, mean cost, COST PER PASSED CASE, and — with
repeats >= 2 — per-case agreement (self-consistency: the same case, the same config, the same
verdict?). Two configurations differ only where their Wilson intervals do not overlap; the report
says so rather than ranking on point estimates.

WHAT IT DOES NOT MEASURE. Correctness. A mechanical pass is not adjudication, and the report
carries that sentence above every number. Routing decisions ("Sonnet suffices for X") are claimed
only from an ADJUDICATED sheet — this harness produces the candidates for that claim, never the
claim. (Benchmark rule: routing is claimed only after measurement; the LLM is never its own
acceptance oracle.)

TEMPERATURE. Sonnet 5 / Opus 5 return 400 for sampling parameters; models.yaml says which models
still accept them (Haiku 4.5, the 4.6 family). `--temperatures` applies only to those and the
plan says so; asking for it on a refusing model is a refusal at plan time, not a mid-run 400.

SPEND IS BOUNDED TWICE, AND HONESTLY. `--plan` prints the run count and an ESTIMATE (mean recorded
tokens per case from the corpus's transcripts x the config's price) and exits without spending.
`--budget-usd` is enforced in two places during execution: a run STARTS only if the budget still
covers its estimate, and a run CONTINUES only while its own accumulated cost is below the budget
left (orchestrator.run's cost_ceiling, checked after every call). The estimate is an estimate; the
ceiling is the bound — the most a matrix can overshoot its budget is one model call, and the row
that crossed it is marked partial. The budget must be a finite positive number; nan is refused.

THE FLATTERS CHECK (the mapping benchmark's discipline): `--degrade` runs the selected cases at
max_steps=2 — a configuration that cannot finish anything. If the numbers do not move, the
harness is decoration and says so; the check runs before any number is reported as informative.

    python experiments/agent/bench/run_bench.py --plan --models claude-sonnet-5,claude-haiku-4-5 --efforts low,high --n 5
    python experiments/agent/bench/run_bench.py --models claude-sonnet-5 --efforts low,high --n 5 --repeats 2 --budget-usd 3
    python experiments/agent/bench/run_bench.py --report
    python experiments/agent/bench/run_bench.py --degrade --n 3 --budget-usd 1
"""
from __future__ import annotations

import argparse
import glob
import json
import math
import os
import statistics
import sys
import time

HERE = os.path.dirname(os.path.abspath(__file__))
AGENT = os.path.dirname(HERE)
sys.path.insert(0, AGENT)
sys.path.insert(0, os.path.join(AGENT, "evals"))

RESULTS = os.path.join(HERE, "results.jsonl")
REPORT = os.path.join(HERE, "BENCHMARK.md")
BANNER = ("MECHANICAL PASSES, NOT ADJUDICATION. Every number below is a scorer's verdict on a "
          "transcript; a routing decision is claimed only from the adjudicated sheet "
          "(evals/ADJUDICATION.md). Configurations differ only where their intervals do not overlap.")


def wilson(k: int, n: int, z: float = 1.96):
    if n == 0:
        return (0.0, 0.0, 0.0)
    p = k / n
    d = 1 + z * z / n
    c = (p + z * z / (2 * n)) / d
    h = z * math.sqrt(p * (1 - p) / n + z * z / (4 * n * n)) / d
    return (round(p, 3), round(max(0.0, c - h), 3), round(min(1.0, c + h), 3))


def load_cases(only=None, tag=None, n=None):
    import yaml  # noqa: PLC0415
    cases = []
    for name in ("cases.yaml", "cases_generated.yaml"):
        p = os.path.join(AGENT, "evals", name)
        if os.path.exists(p):
            with open(p, encoding="utf-8") as fh:
                for c in yaml.safe_load(fh) or []:
                    c.setdefault("provenance", "human" if name == "cases.yaml" else "generated")
                    cases.append(c)
    if only:
        cases = [c for c in cases if c["id"] in only]
    if tag:
        cases = [c for c in cases if tag in (c.get("tags") or []) or c.get("provenance") == tag]
    if n:
        cases = cases[:n]
    return cases


def configs(models, efforts, temperatures):
    """Every (model, effort, temperature) the registry allows; the refused ones are listed."""
    from orchestrator import model_registry, check_sampling  # noqa: PLC0415
    reg = model_registry()["models"]
    out, refused = [], []
    for m in models:
        spec = reg.get(m)
        if spec is None:
            refused.append((m, "not in models.yaml"))
            continue
        # an effort the model does not offer is REFUSED, not silently run as None (audit 5)
        for e in efforts:
            if e is not None and e not in (spec.get("efforts") or []):
                refused.append((m, f"effort {e!r} not offered — efforts: {spec.get('efforts') or 'none'}"))
        # every temperature goes through the same validator as construction: range and sampling
        temps = []
        for t in temperatures:
            why = check_sampling(m, t)
            if why:
                refused.append((m, why))
            elif t not in temps:
                temps.append(t)
        # A REFUSED AXIS NEVER BECOMES THE DEFAULT. Asking for an effort the model lacks used to
        # fall back to effort=None and run anyway (audit 6); now the model simply has no
        # configuration on that axis — every refusal above is still listed — and main() refuses
        # to spend while anything was refused.
        effs = [e for e in efforts if e in (spec.get("efforts") or [])]
        if not effs:
            # a model that OFFERS efforts and accepts none of the requested ones has no runnable
            # configuration on this axis; a model with no effort axis at all (Haiku) simply runs
            # on its other requested axis — effort is not a knob it has, so None is not a default
            if (spec.get("efforts") or []) and any(e is not None for e in efforts):
                continue
            effs = [None]
        if not temps:
            if any(t is not None for t in temperatures):
                continue
            temps = [None]
        for e in effs:
            for t in temps:
                out.append({"model": m, "effort": e, "temperature": t})
    return out, refused


def _mean_tokens_per_case():
    """From the corpus's own transcripts: mean input/output tokens of a finished run."""
    ins, outs = [], []
    for f in glob.glob(os.path.join(AGENT, "runs", "*.json")):
        if os.path.basename(f).startswith("scorecard"):
            continue
        try:
            d = json.load(open(f, encoding="utf-8"))
        except (ValueError, OSError):
            continue
        if not isinstance(d, dict):          # critic/specialist scorecards are lists
            continue
        m = d.get("metrics") or {}
        # the run in FULL — specialists and critics included — where the transcript has it
        tin = m.get("total_input_tokens") or m.get("input_tokens")
        if tin:
            ins.append(tin); outs.append(m.get("total_output_tokens") or m.get("output_tokens") or 0)
    return (statistics.mean(ins) if ins else 30000, statistics.mean(outs) if outs else 2000)


def per_run_estimate(cfg: dict) -> float:
    """The reservation taken BEFORE a run starts: mean recorded tokens x the config's price. An
    ESTIMATE, used only to decide whether a run starts; whether it continues is decided by the
    orchestrator's cost ceiling, so the overshoot bound is one model call, not one run."""
    from orchestrator import PRICES  # noqa: PLC0415
    tin, tout = _mean_tokens_per_case()
    p = PRICES.get(cfg["model"], (0, 0))
    return (tin * p[0] + tout * p[1]) / 1e6


def _identity() -> dict:
    """What a row was produced BY, so a report never pools unrelated sweeps: the code (git sha),
    the corpus (sha of the case files) and the registry (sha of models.yaml)."""
    import hashlib  # noqa: PLC0415
    import subprocess  # noqa: PLC0415
    try:
        sha = subprocess.run(["git", "rev-parse", "--short", "HEAD"], capture_output=True,
                             text=True, encoding="utf-8", cwd=AGENT).stdout.strip() or "?"
    except OSError:
        sha = "?"
    h = hashlib.sha256()
    for name in ("evals/cases.yaml", "evals/cases_generated.yaml", "models.yaml"):
        p = os.path.join(AGENT, name)
        if os.path.exists(p):
            h.update(open(p, "rb").read())
    return {"code": sha, "corpus_registry_sha": h.hexdigest()[:12]}


def plan(cases, cfgs, repeats, refused):
    from orchestrator import PRICES  # noqa: PLC0415
    tin, tout = _mean_tokens_per_case()
    runs = len(cases) * len(cfgs) * repeats
    est = 0.0
    print(f"{len(cases)} case(s) x {len(cfgs)} config(s) x {repeats} repeat(s) = {runs} run(s)")
    for c in cfgs:
        p = PRICES.get(c["model"], (0, 0))
        per = (tin * p[0] + tout * p[1]) / 1e6
        est += per * len(cases) * repeats
        print(f"  {c['model']:18} effort={str(c['effort']):6} temp={str(c['temperature']):5} "
              f"~${per:.3f}/run")
    print(f"ESTIMATE ~${est:.2f} (mean {tin:.0f} in / {tout:.0f} out tokens per case from the "
          f"corpus's transcripts; a real run varies — the budget decides whether a run starts, "
          f"and stops it after at most one model call past the line)")
    for m, why in refused:
        print(f"  refused: {m}: {why}")
    return est


def execute(cases, cfgs, repeats, budget, degrade=False, model_factory=None):
    import math  # noqa: PLC0415
    import orchestrator  # noqa: PLC0415
    from run import score  # noqa: PLC0415  (evals/run.py)
    # EVERY CONTROL IS A FINITE, POSITIVE, NON-EMPTY THING. nan compared false with everything and
    # disabled the cap; zero repeats and an empty matrix exited 0 having done nothing (audit 6).
    if budget is None or not isinstance(budget, (int, float)) or not math.isfinite(budget) or budget <= 0:
        raise ValueError(f"REFUSED — --budget-usd must be a finite positive number, got {budget!r}")
    if not isinstance(repeats, int) or repeats < 1:
        raise ValueError(f"REFUSED — --repeats must be >= 1, got {repeats!r}")
    if not cases or not cfgs:
        raise ValueError(f"REFUSED — nothing to run: {len(cases or [])} case(s) x {len(cfgs or [])} "
                         f"configuration(s); check --cases/--tag/--n and the refusals in --plan")
    model_factory = model_factory or orchestrator.AnthropicModel
    spent, rows, stopped = 0.0, [], False
    sweep = time.strftime("%Y%m%d-%H%M%S")
    ident = _identity()
    with open(RESULTS, "a", encoding="utf-8") as fh:
        for cfg in cfgs:
            reserve = per_run_estimate(cfg)
            for case in cases:
                for rep in range(repeats):
                    # RESERVE BEFORE SPENDING: `spent >= budget` let the next run overshoot the
                    # cap by a whole run (a $1 cap executed two $0.75 runs, audit 5). The run
                    # starts only if the cap still covers its estimate; the documented overshoot
                    # bound is one run exceeding its own estimate.
                    if spent + reserve > budget:
                        stopped = True
                        break
                    model = model_factory(model=cfg["model"], effort=cfg["effort"],
                                          temperature=cfg["temperature"])
                    t0 = time.time()
                    # A RUN THAT RAISES IS A FAILED ROW, NOT A DEAD BENCHMARK: a tool error took
                    # the whole matrix down at run 3 of 9 and wasted its budget context. The
                    # error is recorded on the row and the matrix continues.
                    try:
                        # the budget LEFT is this run's ceiling: it stops the moment its own cost
                        # reaches it, so the overshoot is bounded by one call, not by an estimate
                        st = orchestrator.run(case["goal"], model=model,
                                              max_steps=2 if degrade else orchestrator.MAX_STEPS,
                                              cost_ceiling=max(budget - spent, 1e-9))
                        r = score(case, st)
                        err = None
                    except (Exception, SystemExit) as e:  # noqa: BLE001
                        st, err = None, f"{type(e).__name__}: {str(e)[:200]}"
                        r = {"passed": False, "checks": {"error": False}}
                    m = (st.metrics if st is not None else None) or {}
                    cost = m.get("total_est_cost_usd") or m.get("est_cost_usd") or 0.0
                    spent += cost
                    outcome = ((st.outcome or {}).get("status") if st is not None else "error")
                    partial = outcome == "budget_exhausted" or spent > budget
                    if partial:
                        stopped = True
                    row = {"sweep": sweep, **ident, "partial": partial,
                           "config": cfg, "degrade": degrade, "case": case["id"],
                           "provenance": case.get("provenance", "human"), "repeat": rep,
                           "passed": r["passed"], "checks": r["checks"], "error": err,
                           "outcome": outcome,
                           "expect_outcome": case.get("expect", {}).get("outcome"),
                           "latency_s": m.get("latency_s") or round(time.time() - t0, 1),
                           "calls": m.get("total_calls") or m.get("calls"),
                           "in_tok": m.get("total_input_tokens") or m.get("input_tokens"),
                           "out_tok": m.get("total_output_tokens") or m.get("output_tokens"),
                           "cost_usd": cost, "run_id": (st.run_id if st is not None else None),
                           "at": time.strftime("%Y-%m-%dT%H:%M:%S")}
                    fh.write(json.dumps(row) + "\n"); fh.flush()
                    rows.append(row)
                    print(f"  {cfg['model']}/{cfg['effort']}/{cfg['temperature']} {case['id']:34} "
                          f"{'PASS' if r['passed'] else 'FAIL'} {m.get('latency_s')}s ${cost:.4f} "
                          f"(spent ${spent:.3f})")
                if stopped:
                    break
            if stopped:
                break
    if stopped:
        print(f"BUDGET CAP ${budget} reached after ${spent:.3f} — the matrix is PARTIAL and the "
              f"report will say so")
    return rows, spent, stopped


def _key(cfg):
    return f"{cfg['model']}|{cfg['effort']}|{cfg['temperature']}"


def report(sweep: str = "latest"):
    if not os.path.exists(RESULTS):
        raise SystemExit("no results yet — run the benchmark first")
    rows = [json.loads(l) for l in open(RESULTS, encoding="utf-8") if l.strip()]
    # ONE SWEEP AT A TIME. Pooling every historical row by model/effort/temperature mixed runs
    # from different code, corpora and registries (audit 5). Default: the latest sweep's code
    # and corpus identity; `--sweep all` pools deliberately and says so.
    sweeps = sorted({r.get("sweep") or "pre-identity" for r in rows})
    if sweep == "latest":
        # EXACTLY THE LATEST SWEEP. Matching on code and corpus identity pooled every sweep run
        # from the same commit (audit 6); a report is one sweep unless `--sweep all` says pool.
        latest = [r for r in rows if r.get("sweep")]
        if latest:
            ref = max(r["sweep"] for r in latest)
            rows = [r for r in rows if r.get("sweep") == ref]
            scope = f"sweep {ref} (code {rows[0].get('code')} / corpus+registry {rows[0].get('corpus_registry_sha')})"
        else:
            scope = "pre-identity rows only (no sweep id recorded)"
    elif sweep == "all":
        scope = f"ALL {len(sweeps)} sweep(s) pooled — different code/corpus/registry may be mixed"
    else:
        rows = [r for r in rows if r.get("sweep") == sweep]
        scope = f"sweep {sweep}"
    real = [r for r in rows if not r.get("degrade")]
    degraded = [r for r in rows if r.get("degrade")]
    by = {}
    for r in real:
        by.setdefault(_key(r["config"]), []).append(r)
    lines = [f"# Benchmark — model x effort over the eval corpus", "", f"> {BANNER}", "",
             f"Scope: {scope}. Rows: {len(real)} real, {len(degraded)} degraded (flatters check). "
             f"Generated: {time.strftime('%Y-%m-%d %H:%M')}.", "",
             "| config | runs | pass | Wilson 95% | esc. recall | false esc. | tools ok | "
             "mean s | mean $ | $/pass | agreement | stability |",
             "|---|---:|---:|---|---:|---:|---:|---:|---:|---:|---:|---|"]
    # THE OPERATOR'S TOLERANCE, AS TWO DIFFERENT THINGS. A 5-10% deviation between repeats is
    # noise: a configuration is STABLE when its repeats agree >= 90% of the time, UNSTABLE below
    # that, and unstable configurations are not ranked. A 100% deviation -- an answer with no
    # evidence, an outcome the run fabricated -- is not a percentage: one `ungrounded` run
    # DISQUALIFIES the configuration for governed use, whatever its average.
    STABLE_AT = 0.9
    disqualified = sorted({_key(r["config"]) for r in real if r.get("outcome") == "ungrounded"})
    for k, rs in sorted(by.items()):
        n = len(rs); p = sum(r["passed"] for r in rs)
        pw = wilson(p, n)
        exp_esc = [r for r in rs if "escalated" in (r["expect_outcome"] if isinstance(r["expect_outcome"], list) else [r["expect_outcome"]])
                   and r["expect_outcome"] not in (None,) and "done" not in (r["expect_outcome"] if isinstance(r["expect_outcome"], list) else [r["expect_outcome"]])]
        rec = sum(1 for r in exp_esc if r["outcome"] == "escalated")
        exp_done = [r for r in rs if r["expect_outcome"] == "done"]
        fe = sum(1 for r in exp_done if r["outcome"] == "escalated")
        tool = [v for r in rs for kk, v in r["checks"].items() if kk.startswith("called:")]
        lat = [r["latency_s"] for r in rs if r["latency_s"]]
        cost = [r["cost_usd"] for r in rs]
        # agreement: for each case with >=2 repeats, did every repeat agree on passed?
        per_case = {}
        for r in rs:
            per_case.setdefault(r["case"], []).append(r["passed"])
        multi = [v for v in per_case.values() if len(v) >= 2]
        agree = (sum(1 for v in multi if len(set(v)) == 1) / len(multi)) if multi else None
        errs = sum(1 for r in rs if r.get("error"))
        mean_lat = f"{statistics.mean(lat):.0f}" if lat else "-"      # a config of pure errors has none
        mean_cost = f"{statistics.mean(cost):.4f}" if cost else "-"
        per_pass = f"{(sum(cost) / p):.4f}" if p else "-"
        if k in disqualified:
            stability = "DISQUALIFIED (ungrounded run)"
        elif agree is None:
            stability = "- (needs repeats)"
        else:
            stability = "stable" if agree >= STABLE_AT else f"UNSTABLE (<{STABLE_AT:.0%} agreement)"
        lines.append(f"| {k} | {n}{f' ({errs} err)' if errs else ''} | {p} | {pw[0]} [{pw[1]},{pw[2]}] | "
                     f"{rec}/{len(exp_esc)} | {fe}/{len(exp_done)} | {sum(tool)}/{len(tool)} | "
                     f"{mean_lat} | {mean_cost} | {per_pass} | "
                     f"{'-' if agree is None else f'{agree:.2f}'} | {stability} |")
    lines += ["", "## Disqualified for governed use (one ungrounded run is enough)"]
    lines += [f"- {k}: at least one run ended `ungrounded` — a done with no tool evidence, refused twice"
              for k in disqualified] or ["- none"]
    lines += ["", f"Stability rule: repeats must agree >= {STABLE_AT:.0%} (a 5–10% deviation is noise); "
              "an unstable configuration is reported, never ranked. `run_consistent()` applies the "
              "same rule at answer time: disagreeing votes escalate instead of presenting one."]
    # flatters check
    lines += ["", "## Flatters check"]
    # PER CONFIGURATION, error rows excluded: the degraded runs of a config are compared with the
    # real runs of THAT config. Pooling every config's rows let a weak model's real failures drag
    # the pooled real rate down to the degraded rate and declare the harness decoration when it
    # was the model, not the harness, that could not finish (seen on the first Haiku rows).
    checked = False
    for k in sorted({_key(r["config"]) for r in degraded}):
        dg = [r for r in degraded if _key(r["config"]) == k and not r.get("error")]
        rl = [r for r in real if _key(r["config"]) == k and not r.get("error")]
        if not dg or not rl:
            continue
        checked = True
        dp = sum(r["passed"] for r in dg) / len(dg)
        rp = sum(r["passed"] for r in rl) / len(rl)
        moved = rp - dp > 0.2
        lines.append(f"- {k}: degraded (max_steps=2) pass rate {dp:.2f} vs real {rp:.2f} — "
                     f"{'the harness discriminates' if moved else 'THE NUMBERS DID NOT MOVE: this harness is decoration for this config until they do'}.")
    if not checked:
        lines.append("Not run for any configuration. Until `--degrade` shows the numbers move, no row above is informative.")
    # pairwise
    keys = sorted(by)
    if len(keys) >= 2:
        lines += ["", "## Pairwise (non-overlapping Wilson intervals only)"]
        seen = False
        for i, a in enumerate(keys):
            for b in keys[i + 1:]:
                wa = wilson(sum(r["passed"] for r in by[a]), len(by[a]))
                wb = wilson(sum(r["passed"] for r in by[b]), len(by[b]))
                if wa[1] > wb[2] or wb[1] > wa[2]:
                    seen = True
                    hi, lo = (a, b) if wa[0] > wb[0] else (b, a)
                    lines.append(f"- {hi} > {lo} on mechanical pass rate (intervals disjoint)")
        if not seen:
            lines.append("- no pair is separable at this sample size — more repeats, not a ranking")
    lines += ["", "## Routing", "",
              "No routing is claimed here. The adjudicated sheet decides which configuration's passes "
              "were CORRECT; until it exists, the router's label is a proxy and this report is its input.",
              ""]
    with open(REPORT, "w", encoding="utf-8") as fh:
        fh.write("\n".join(lines))
    print("\n".join(lines))
    print(f"\nwrote {REPORT}")


def main():
    ap = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    ap.add_argument("--models", default="claude-sonnet-5")
    ap.add_argument("--efforts", default="high")
    ap.add_argument("--temperatures", default="", help="only for models with sampling: true")
    ap.add_argument("--cases", default="", help="comma-separated case ids")
    ap.add_argument("--tag", default=None, help="human | generated | a case tag")
    ap.add_argument("--n", type=int, default=None, help="first N cases")
    ap.add_argument("--repeats", type=int, default=1, help=">= 1")
    ap.add_argument("--budget-usd", type=float, default=None, help="finite, > 0; refused otherwise")
    ap.add_argument("--plan", action="store_true")
    ap.add_argument("--report", action="store_true")
    ap.add_argument("--degrade", action="store_true")
    ap.add_argument("--sweep", default="latest", help="latest (default) | all | <sweep id>")
    a = ap.parse_args()
    if a.report:
        report(a.sweep); return
    # EVERY CONTROL IS VALIDATED BEFORE A PLAN IS PRINTED: `--repeats -1` planned -109 runs and
    # `--n 0` a matrix of nothing, both with exit 0 (audit 7)
    if a.repeats < 1:
        raise SystemExit(f"REFUSED — --repeats must be >= 1, got {a.repeats}")
    if a.n is not None and a.n < 1:
        raise SystemExit(f"REFUSED — --n must be >= 1, got {a.n}")
    models = [m.strip() for m in a.models.split(",") if m.strip()]
    efforts = [e.strip() for e in a.efforts.split(",") if e.strip()]
    temps = [float(t) for t in a.temperatures.split(",") if t.strip()] or [None]
    cases = load_cases(set(a.cases.split(",")) if a.cases else None, a.tag, a.n)
    cfgs, refused = configs(models, efforts, temps)
    if a.degrade:
        cfgs = cfgs[:1]
    est = plan(cases, cfgs, a.repeats, refused)
    if refused:
        raise SystemExit(f"REFUSED — {len(refused)} requested configuration(s) were refused (listed above); "
                         f"a matrix runs exactly what was asked or nothing. Fix the request.")
    if not cases or not cfgs:
        raise SystemExit("REFUSED — nothing to run (0 cases or 0 configurations)")
    if a.plan:
        return
    if a.budget_usd is None:
        raise SystemExit("--budget-usd is required to spend (the estimate above is not a cap)")

    if est > a.budget_usd * 3:
        print(f"NOTE: estimate ${est:.2f} is far above the cap ${a.budget_usd}; the matrix WILL be partial")
    execute(cases, cfgs, a.repeats, a.budget_usd, degrade=a.degrade)
    report()


if __name__ == "__main__":
    main()
