"""The RWD orchestrator prototype: goal -> observe -> plan -> act -> inspect -> continue|escalate.

WHAT IT IS: the missing reasoning loop over tools that already exist. WHAT IT IS NOT: an authority.
It cannot approve, record, promote, or modify a pack — no tool on its surface does any of that —
and it is told to STOP at scientific or approval questions, with tool refusals detected as a
hard backstop for when it does not.
"""
from __future__ import annotations

import argparse
import json
import os
import re

import tools
import control_plane
from state import RunState

HERE = os.path.dirname(os.path.abspath(__file__))


def model_registry() -> dict:
    """models.yaml — ids, prices, and what each model ACCEPTS (sampling vs effort). One source for
    the orchestrator, the specialists and the benchmark; an unknown model reports cost None."""
    import yaml  # noqa: PLC0415
    with open(os.path.join(HERE, "models.yaml"), encoding="utf-8") as fh:
        return yaml.safe_load(fh)


_REG = model_registry()
MODEL_ID = os.environ.get("RWD_AGENT_MODEL", _REG.get("default", "claude-sonnet-5"))
# $ per MTok (input, output) from the registry — kept as a dict for callers that read PRICES
PRICES = {mid: (m["price_in"], m["price_out"]) for mid, m in _REG["models"].items()}


def usage_cost(model: str, usage: dict):
    p = PRICES.get(model)
    if not p or not usage:
        return None
    return round(usage.get("input_tokens", 0) * p[0] / 1e6
                 + usage.get("output_tokens", 0) * p[1] / 1e6, 6)


def check_sampling(model: str, temperature) -> str | None:
    """None if `temperature` may be sent to `model`, else the reason. Sampling parameters return
    400 on Sonnet 5 / Opus 5 / 4.7 / 4.8; the registry says which models still accept them, so a
    benchmark that asks for a temperature axis fails HERE with a sentence, not mid-run."""
    if temperature is None:
        return None
    spec = _REG["models"].get(model)
    if spec is None:
        return f"{model!r} is not in models.yaml — register it before benchmarking it"
    if not spec.get("sampling"):
        return (f"{model!r} does not accept temperature (the API returns 400); vary "
                f"output_config.effort instead — efforts: {spec.get('efforts')}")
    if not (0.0 <= float(temperature) <= 1.0):
        return f"temperature {temperature!r} outside [0, 1]"
    return None
MAX_STEPS = 20
OBS_CAP = 6000          # per-observation characters handed back to the model

# The repository's own refusal vocabulary. A tool output carrying one of these is the platform
# saying "a person decides here" — the loop escalates on sight, whatever the model thinks next.
# TRUE REFUSAL VOCABULARY ONLY. This carried `requires (Science|DataExpert|...)` — but
# pack_status DESCRIBES who acts in exactly those words on every read, so the backstop
# force-escalated a run whose goal was to delegate to a specialist after checking status
# (seen live: 2 calls, specialist never reached). A description of ownership is context;
# a refusal is a wall. Only walls force the escalation — the system prompt still governs
# real authority questions the model can see for itself.
AUTHORITY_RE = re.compile(
    r"REFUSING|is a HUMAN act|not an approval mechanism|not yours to write", re.I)

SYSTEM = """You are the RWD orchestrator for a governed oncology data-product platform.

Your ONLY job each turn: choose the next safe action toward the goal, or stop.
Reply with ONE JSON object, nothing else:
  {"action":"tool","tool":"<name>","args":{...},"why":"<one line>"}
  {"action":"escalate","to":"DataExpert|Science|operator","question":"<the precise question>","evidence":"<what you found>"}
  {"action":"done","summary":"<what was established, citing tool outputs>"}

Rules you must not break:
- Authority: scientific meaning, source equivalence, approvals, recorded answers and release are
  a PERSON's. When a question needs one, escalate — never answer it yourself, never work around a
  refusal. A refusal from a tool is the platform working, not an obstacle.
- Evidence: claim only what a tool output shows. If evidence conflicts, the current approved
  specification and decisions outrank precedent; precedent outranks source metadata; your own
  knowledge ranks last and never overrides any of them. Recorded lessons (the `lessons`
  tool) sit just above your own knowledge: consult them for known misreadings, and treat
  them as advisory — never as a source of authority.
- Economy: do not re-run a tool you already ran unless something changed.

Tools:
{tools}"""


import contextvars as _cv

# PER-RUN ACCUMULATOR, CONTEXT-SCOPED. A class-level total shared by every run in the process made
# two concurrent one-call runs each report total_calls=2 (third audit). run()/resume_run() install
# a fresh accumulator in the context; every AnthropicModel.step() in that context — the
# orchestrator's, a specialist's, a critic's — adds to it; nothing outside the context is counted.
_RUN_USAGE: "_cv.ContextVar[dict | None]" = _cv.ContextVar("rwd_run_usage", default=None)


def _new_usage_acc() -> dict:
    return {"calls": 0, "input_tokens": 0, "output_tokens": 0, "cost_usd": 0.0}


class AnthropicModel:
    # process-wide, for reporting only — never used for a per-run figure (see _RUN_USAGE)
    TOTAL = _new_usage_acc()

    def __init__(self, model=MODEL_ID, max_tokens=1200, effort=None, temperature=None):
        # effort: None inherits the model default; "low|medium|high|xhigh|max" trades depth for
        # latency. temperature: ONLY on models whose registry row says sampling: true (Haiku 4.5,
        # the 4.6 family) — Sonnet 5 / Opus 5 return 400 for it, so it is refused here first.
        # Knobs, not policy — routing by either is claimed only once the eval corpus measures it.
        # THE REGISTRY IS CHECKED FIRST, WHATEVER THE KNOBS. An unknown model reached the API when
        # no temperature was asked, and an effort the model does not offer was sent as-is (audit 6).
        spec = _REG["models"].get(model)
        if spec is None:
            raise ValueError(f"REFUSED — {model!r} is not in models.yaml; register it before use")
        effort = effort or os.environ.get("RWD_AGENT_EFFORT") or None
        if effort is not None and effort not in (spec.get("efforts") or []):
            raise ValueError(f"REFUSED — effort {effort!r} is not offered by {model!r} "
                             f"(efforts: {spec.get('efforts') or 'none'})")
        why = check_sampling(model, temperature)
        if why:
            raise ValueError(f"REFUSED — {why}")
        self.temperature = temperature
        self.effort = effort
        # §19: every call's usage accumulates here; the scorecard turns it into cost. Prices are
        # per MTok for the models this experiment actually runs; an unknown model reports tokens
        # with cost=None rather than a guessed number.
        self.usage = {"calls": 0, "input_tokens": 0, "output_tokens": 0}
        # the specialists need more room than the loop: adaptive thinking spends from the same
        # budget, and a 1200-token cap on a large assembly prompt returned EMPTY text -- caught
        # by the critic (route=revise) on the Source Intelligence agent's first live run
        self.max_tokens = max_tokens
        key = os.environ.get("ANTHROPIC_API_KEY")
        if not key:
            raise SystemExit("ANTHROPIC_API_KEY is not set — the orchestrator refuses to run "
                             "without a model rather than pretending. Set it and rerun.")
        import anthropic  # noqa: PLC0415
        # identity-linked keys require the workspace id as a header; env-only, never hardcoded
        # (the dev and prod accounts differ, and a key pasted anywhere is a key rotated)
        ws = os.environ.get("ANTHROPIC_WORKSPACE_ID")
        # A call is BOUNDED. The SDK's defaults (10-minute timeout, two silent retries) let one
        # stalled request hold the whole benchmark matrix for over two hours on 2026-09-02; nothing
        # was wrong with the model, the socket simply never answered. 120 s covers every call the
        # nine-run post-grounding sweep made (Sonnet high with 30k-token transcripts included), one
        # retry covers a transient reset, and a call that still fails surfaces as an error ROW in the
        # matrix — the runner records it, the report counts it, the matrix moves on.
        timeout_s = float(os.environ.get("RWD_API_TIMEOUT_S", "120"))
        self.client = anthropic.Anthropic(timeout=timeout_s, max_retries=1,
            default_headers={"anthropic-workspace-id": ws} if ws else None)
        self.model = model

    def step(self, system: str, transcript: list[dict]) -> str:
        kw = {"output_config": {"effort": self.effort}} if self.effort else {}
        if self.temperature is not None:          # registry-validated in __init__
            # the SDK's typed signature no longer carries `temperature` (sampling params are
            # gone from current models); on the models that still accept it, it travels in the
            # request body — the API, not the SDK, is the authority on whether it is honoured
            kw["extra_body"] = {"temperature": float(self.temperature)}
        assert_within_ceiling()                  # a specialist's call inside a tool stops here too
        r = self.client.messages.create(model=self.model, max_tokens=self.max_tokens,
                                        system=system, messages=transcript, **kw)
        it = getattr(r.usage, "input_tokens", 0) or 0
        ot = getattr(r.usage, "output_tokens", 0) or 0
        self.usage["calls"] += 1
        self.usage["input_tokens"] += it
        self.usage["output_tokens"] += ot
        # PROCESS-WIDE TOTAL as well as per-instance: the specialists build their own
        # AnthropicModel, so a run that delegated recorded only the orchestrator's calls — a
        # four-call probe reported two (second audit). Every instance adds here; run() stamps
        # the delta over the run as `total_*` alongside the root model's own numbers.
        cost = usage_cost(self.model, {"input_tokens": it, "output_tokens": ot}) or 0.0
        for acc in (AnthropicModel.TOTAL, _RUN_USAGE.get()):
            if acc is None:
                continue
            acc["calls"] += 1
            acc["input_tokens"] += it
            acc["output_tokens"] += ot
            acc["cost_usd"] += cost
        return "".join(b.text for b in r.content if b.type == "text")


def _parse_any(text: str) -> dict:
    """First valid JSON object in the text, whatever its keys — the specialist agents' parser."""
    dec = json.JSONDecoder()
    for i, ch in enumerate(text):
        if ch == "{":
            try:
                obj, _ = dec.raw_decode(text[i:])
            except json.JSONDecodeError:
                continue
            if isinstance(obj, dict):
                return obj
    return {"unparseable": text[:400]}


def _parse(text: str) -> dict:
    """Find the FIRST valid JSON object carrying an "action" key.

    The original used a greedy brace-to-brace regex: any prose after the object, a brace inside a
    string, or a second object handed json.loads a span it could not parse, and one real run spent
    its last six steps in a malformed loop the feedback message never explained. `raw_decode` from
    each opening brace is exact, and the caller now echoes WHY a reply failed.
    """
    dec = json.JSONDecoder()
    for i, ch in enumerate(text):
        if ch != "{":
            continue
        try:
            obj, _ = dec.raw_decode(text[i:])
        except json.JSONDecodeError:
            continue
        if isinstance(obj, dict) and "action" in obj:
            return obj
    return {"action": "malformed", "raw": text[:400]}


# ---------------------------------------------------------------------------------------------
# ONE BOUNDED LOOP FOR RUN AND RESUME. Two copies of the loop drifted: resume had no cost or
# wall-clock ceiling, and the root loop checked its ceiling after its own call only, so a
# specialist's calls inside a tool ran a $0.50 ceiling to $3.02 (audit 7). The ceiling now lives
# in the run's context: every AnthropicModel.step() in it refuses BEFORE the API once the run is
# over, and the loop re-checks after every tool call. A model's TEXT is never an act: a `done`
# that words an approval, an adoption or a recording is refused, then escalated to the owner the
# tools named — authority is typed metadata on the tool, not four phrases in its output.

_RUN_CEILING: "_cv.ContextVar[float | None]" = _cv.ContextVar("rwd_run_ceiling", default=None)


class BudgetExceeded(RuntimeError):
    """A model call refused BEFORE reaching the API: the run's cost is at or over its ceiling."""


def assert_within_ceiling() -> None:
    acc, cap = _RUN_USAGE.get(), _RUN_CEILING.get()
    if acc is not None and cap is not None and acc["cost_usd"] >= cap:
        raise BudgetExceeded(f"run cost ${acc['cost_usd']:.4f} has reached its ceiling ${cap:.4f} "
                             f"— refused before the API")


CLAIMS_ACT_RE = re.compile(
    r"\bon behalf of\b|\bhereby\b"
    r"|\b(i|we)\s+(have\s+)?(approved|adopted|recorded|signed|bound|ratified)\b"
    r"|\bapproved\s+(by|for)\s+(science|dataexpert|engineering|operator|rwb|rwp)\b"
    r"|\bsign(ed)?[- ]?off\s+(granted|given|recorded|complete)\b"
    r"|\bconsider(ed)?\s+(this|it)\s+approved\b"
    r"|\b(answer|decision)\s+(is\s+|has\s+been\s+)?recorded\b"
    r"|\bbinding\s+(is|has been)\s+(set|recorded)\b"
    # audit 8: "Science approved the window" named the owner as the subject and passed; the review
    # of audit 8: present tense ("Science approves"), a title ("the Science owner"), synonyms
    # (agreed, accepted, confirmed) and a by-phrase with words between ("approved by the Science
    # team") passed too. Nouns stay out on purpose: "Science approval is pending" describes state.
    r"|\b(science|dataexpert|data expert|engineering|operator|rwb|rwp)(\s+(team|owner|owners|group|lead))?"
    r"\s+(has\s+|have\s+)?(approv(e|es|ed|ing)|adopt(s|ed)?|sign(s|ed)?|ratif(y|ies|ied)|recorded|"
    r"authori[sz]e[sd]?|agree[sd]?|accept(s|ed)?|confirm(s|ed)?)\b"
    r"|\b(approv(e|es|ed)|adopt(s|ed)?|ratif(y|ies|ied)|sign(s|ed)?|authori[sz]e[sd]?|accept(s|ed)?|confirm(s|ed)?)"
    r"\s+(by|for)\s+(the\s+)?(science|dataexpert|data expert|engineering|operator|rwb|rwp)\b"
    r"|\bapproval\s+(was\s+|is\s+|has\s+been\s+)?(granted|given|complete|obtained|secured|confirmed)\b", re.I)


def claims_act(text: str) -> bool:
    """True when a summary WORDS an act — an approval given, a precedent adopted, an answer
    recorded, a signature. Descriptions of state ("approval pending", "not approved yet") are
    context and do not match. A done that claims an act is refused, then escalated."""
    return bool(CLAIMS_ACT_RE.search(str(text or "")))


def _escalation(act: dict) -> str:
    """The escalation outcome as recorded: for whom, the question, and the evidence cited."""
    return json.dumps({"to": act.get("to"), "question": act.get("question"),
                       "evidence": act.get("evidence")})


def _answered_step(prev: RunState) -> dict | None:
    """The `answered` step on an escalated run, if a resume already answered it."""
    for s in prev.steps:
        if s.get("kind") == "answered":
            return s
    return None


def _registered_owners() -> set:
    """The roles governance/ACTIONS.yaml declares (plus the operator) — the only valid `to`."""
    try:
        import control_plane  # noqa: PLC0415
        return set(control_plane.owners()) | {"operator"}
    except Exception:  # noqa: BLE001 - a missing registry falls back to the workflow's owners
        return {"Science", "DataExpert", "Engineering", "operator"}


def _asked_owner(prev: RunState) -> str:
    try:
        asked = json.loads((prev.outcome or {}).get("summary") or "{}")
    except (ValueError, TypeError):
        asked = {}
    return str((asked.get("to") if isinstance(asked, dict) else None) or "operator").split("/")[0].strip()


def _roster_owns(name: str):
    """The `owns` list the portal roster records for this person, or None when the roster does
    not say (no roster, no entry, or an entry without `owns`)."""
    import state as _sm  # noqa: PLC0415
    for path in (os.path.join(_sm.STATE_DIR, "users.json"),
                 os.path.join(os.path.dirname(HERE), "portal", "users.json")):
        if not os.path.exists(path):
            continue
        try:
            with open(path, encoding="utf-8") as fh:
                users = json.load(fh)
        except (OSError, ValueError):
            return None
        for u in users if isinstance(users, list) else []:
            if isinstance(u, dict) and u.get("name") == name:
                return set(u["owns"]) if isinstance(u.get("owns"), list) else None
        return None
    return None


def _eligibility(answered_by: str, to: str, owns) -> tuple[str, str]:
    """("roster" | "unverified" | "refused", why). Who may answer a question is what the roster
    records under `owns`; a host that knows it passes it, the CLI looks it up, and an unknown
    person is recorded as unverified rather than trusted (audit 8: any name answered anything)."""
    to = str(to or "operator").split("/")[0].strip()
    if owns is None:
        owns = _roster_owns(answered_by)
    if owns is None:
        return "unverified", "no roster entry records what this person owns; the answer is recorded as unverified"
    owns = {str(x).strip() for x in owns}
    if to in owns or "any" in owns:
        return "roster", f"{answered_by} owns {to}"
    return "refused", (f"{answered_by} is not eligible: owns {sorted(owns) or 'nothing'}, the question is for "
                       f"{to}. A {to} owner answers it, or an administrator records the ownership first")


def _owner_in_context(st: RunState) -> str | None:
    """The owner the tools named while this run ran (typed metadata), if any."""
    for s in reversed(st.steps):
        if s.get("kind") == "authority_detected" and s.get("owner"):
            return str(s["owner"]).split("/")[0].strip()
    return None


def _wire(st: RunState, model, on_step):
    if on_step is not None:
        _rec = st.record

        def _record(kind, **payload):
            _rec(kind, **payload)
            try:
                on_step(st.steps[-1])
            except Exception:  # noqa: BLE001 - a display never breaks a run
                pass
        st.record = _record
    st.model_id = getattr(model, "model", "?")


def _install_metrics(st: RunState, model, acc: dict, t0: float):
    import time  # noqa: PLC0415
    _finish = st.finish

    def finish(status, summary):
        st.metrics = {"latency_s": round(time.time() - t0, 1),
                      "model": getattr(model, "model", "?"),
                      **(getattr(model, "usage", None) or {})}
        st.metrics["est_cost_usd"] = usage_cost(st.metrics.get("model"), getattr(model, "usage", None))
        st.metrics["total_calls"] = acc["calls"]
        st.metrics["total_input_tokens"] = acc["input_tokens"]
        st.metrics["total_output_tokens"] = acc["output_tokens"]
        st.metrics["total_est_cost_usd"] = round(acc["cost_usd"], 6)
        config = getattr(model, "config", {})
        if config.get("provider_id"):
            st.metrics["provider"] = config["provider_id"]
            st.metrics["total_calls"] = getattr(model, "calls", acc["calls"])
            st.metrics["excerpted_calls"] = getattr(model, "excerpted_calls", 0)
            if config["provider_id"] != "anthropic":
                # Local subscription adapters report no token or dollar usage.
                for key in ("est_cost_usd", "total_est_cost_usd", "total_input_tokens", "total_output_tokens"):
                    st.metrics[key] = None
        _finish(status, summary)
        # A learning receipt/continuation is downstream of the persisted result.
        # Failure cannot change the completed check, its owner or its provider.
        completed = getattr(model, 'completed_run', None)
        if callable(completed):
            try:
                completed(st)
            except Exception:
                pass
    st.finish = finish


def _loop(st: RunState, model, transcript: list, *, t0: float, acc: dict, max_steps: int,
          cost_ceiling, max_seconds, scope=None) -> RunState:
    import time  # noqa: PLC0415
    import state as _sm  # noqa: PLC0415

    def over_cost():
        return cost_ceiling is not None and acc["cost_usd"] >= cost_ceiling

    def stop_cost():
        st.record("budget_exhausted", spent_usd=round(acc["cost_usd"], 6), ceiling_usd=cost_ceiling)
        st.finish("budget_exhausted", f"this run's cost ${acc['cost_usd']:.4f} reached its ceiling "
                                      f"${cost_ceiling:.4f} after {acc['calls']} call(s) — stopped; "
                                      f"nothing below is an answer")
        return st

    system = SYSTEM.replace("{tools}", tools.describe())
    tok = _RUN_CEILING.set(cost_ceiling)
    # THIS RUN'S SCOPE AND IDENTITY travel in the context: every tool call below, and every tool a
    # specialist makes inside one, is confined to `scope`; a candidate written inside stamps the run.
    _stok = tools._SCOPE.set(tools._norm(scope)) if scope is not None else None
    _rtok = _sm.CURRENT_RUN.set(st.run_id)
    _mtok = tools._MODEL.set(model)
    try:
        for step_i in range(max_steps):
            if max_steps - step_i == 3:
                transcript.append({"role": "user", "content":
                                   "NOTE: 3 steps remain. Converge now — reach done or escalate with "
                                   "what you have; partial evidence honestly summarised beats a "
                                   "truncated run."})
            if max_seconds is not None and time.time() - t0 >= max_seconds:
                st.record("time_budget_exhausted", elapsed_s=round(time.time() - t0, 1), cap_s=max_seconds)
                st.finish("time_budget_exhausted", f"{round(time.time() - t0)}s elapsed against a "
                                                   f"{max_seconds:.0f}s wall-clock cap after {step_i} step(s) "
                                                   f"— stopped; nothing below is an answer")
                return st
            if over_cost():
                return stop_cost()
            try:
                raw = model.step(system, transcript)
            except BudgetExceeded:
                return stop_cost()
            except (tools.ModelStopped, control_plane.WorkflowModelStopped) as error:
                st.record("model_stopped", explanation=str(error))
                st.finish("model_stopped", str(error))
                return st
            act = _parse(raw)
            st.record("decision", decision=act)
            transcript.append({"role": "assistant", "content": raw})
            if over_cost():
                return stop_cost()

            if act.get("action") == "done":
                summary = str(act.get("summary", ""))
                if claims_act(summary):
                    # A MODEL'S TEXT IS NEVER AN ACT. Refused once with the reason; a second
                    # attempt is routed to the owner the tools named (audit 7: "approved on
                    # behalf of Science" completed as done).
                    if not any(s.get("kind") == "refused_claimed_act" for s in st.steps):
                        st.record("refused_claimed_act", summary=summary[:300])
                        transcript.append({"role": "user", "content":
                                           "REFUSED: that `done` words an ACT — an approval, an adoption, "
                                           "a recording, a signature. Those are a person's acts; nothing "
                                           "you write performs one. State only what the tools showed, or "
                                           "escalate the question to its owner. (Reply with exactly one "
                                           "JSON action object.)"})
                        continue
                    st.finish("escalated", json.dumps({
                        "to": _owner_in_context(st) or "operator",
                        "question": summary[:600],
                        "evidence": "REFUSED twice: the model worded an act (approval/adoption/recording) "
                                    "in its summary. A model's text is not an act — a person decides."}))
                    return st
                if not any(s.get("kind") == "observation" for s in st.steps):
                    # THE GROUNDING RULE: a done with no tool observation is made up
                    if not any(s.get("kind") == "refused_ungrounded" for s in st.steps):
                        st.record("refused_ungrounded", why="done with no tool evidence")
                        transcript.append({"role": "user", "content":
                                           "REFUSED: that `done` cites no tool output — every claim must "
                                           "rest on a tool observation from THIS run. Call a tool, or "
                                           "escalate. (Reply with exactly one JSON action object.)"})
                        continue
                    st.finish("ungrounded", "REFUSED twice: a done with no tool observation is a "
                                            "fabrication, not an answer — routed to a person")
                    return st
                st.finish("done", summary)
                return st
            if act.get("action") == "escalate":
                # ONLY A REGISTERED OWNER RECEIVES A QUESTION (audit 8: `to` was free text, so a
                # question could be addressed to nobody and sit in no queue). An unknown addressee
                # is rerouted to the operator and the rerouting is a recorded step.
                to = str(act.get("to") or "").split("/")[0].strip()
                if to not in _registered_owners():
                    st.record("escalation_rerouted", requested=to[:80], to="operator",
                              why="not a registered owner (governance/ACTIONS.yaml roles)")
                    act = dict(act, to="operator")
                st.finish("escalated", _escalation(act))
                return st
            if act.get("action") != "tool":
                transcript.append({"role": "user", "content":
                                   'Your reply did not contain a JSON object with an "action" key. '
                                   'Reply with EXACTLY one JSON object and nothing else, e.g. '
                                   '{"action":"tool","tool":"pack_status","args":{},"why":"..."} or '
                                   '{"action":"escalate","to":"Science","question":"...","evidence":"..."} '
                                   'or {"action":"done","summary":"..."}.'})
                continue

            name = str(act.get("tool"))
            args = act.get("args")
            if args is None:
                args = {}
            if not isinstance(args, dict):
                # a list or a string where an object belongs is a malformed action, not a crash
                st.record("malformed_args", tool=name, got=type(args).__name__)
                transcript.append({"role": "user", "content":
                                   f"REFUSED: `args` must be a JSON object, got {type(args).__name__}. "
                                   f"(Reply with exactly one JSON action object.)"})
                continue
            out = tools.call(name, args)                        # the context carries this run's scope
            st.record("observation", tool=name, chars=len(out), output=out[:OBS_CAP])
            if over_cost():                      # a specialist inside the tool spent the rest
                return stop_cost()
            meta = tools.meta(name)
            marker = AUTHORITY_RE.search(out)
            if marker or meta.get("decides") == "human":
                # the backstop: the platform said "a person decides here" — by the tool's TYPE
                # (a packet or the open questions hand a question to a person) or by a refusal
                # in its text; the loop does not argue
                st.record("authority_detected", marker=(marker.group(0) if marker else f"tool:{name}"),
                          source=("text" if marker else "tool_metadata"), owner=meta.get("owner"))
                transcript.append({"role": "user", "content":
                                   f"TOOL OUTPUT (this hands a question to a PERSON"
                                   f"{' — ' + str(meta.get('owner')) if meta.get('owner') else ''}: "
                                   f"escalate with the precise question; do not answer it and do not "
                                   f"record anything):\n{out[:OBS_CAP]}"})
            else:
                transcript.append({"role": "user", "content":
                                   f"TOOL OUTPUT:\n{out[:OBS_CAP]}\n"
                                   f"(Reply with exactly one JSON action object.)"})
        st.finish("step_budget_exhausted",
                  "max steps reached without done/escalate — read the transcript")
        return st
    finally:
        _RUN_CEILING.reset(tok)
        _sm.CURRENT_RUN.reset(_rtok)
        tools._MODEL.reset(_mtok)
        if _stok is not None:
            tools._SCOPE.reset(_stok)


def run(goal: str, model=None, max_steps: int = MAX_STEPS, actor: dict | None = None,
        cost_ceiling: float | None = None, max_seconds: float | None = None,
        on_step=None, scope=None, primary_pack=None) -> RunState:
    """One run. `cost_ceiling` (USD) is a REAL bound: checked before and after every model call
    and after every tool call, and enforced inside AnthropicModel.step() for every model instance
    in this run's context (specialists and critics included), so the most a run can overshoot is
    one model call. `max_seconds` is the wall-clock bound checked before every model call; a tool
    call in flight is bounded by RWD_TOOL_TIMEOUT_S. `on_step(step)` reports each recorded step
    to the host; a callback that raises is swallowed."""
    import time  # noqa: PLC0415
    t0 = time.time()
    model = control_plane.task_model(model or AnthropicModel(), route="governed_check", query=goal,
        task_scope={"pack": primary_pack} if primary_pack in (scope or set()) else {})
    st = RunState(goal, actor=actor)
    st.primary_pack = primary_pack if primary_pack in (scope or set()) else None
    if callable(getattr(model, 'start_run', None)):
        model.start_run(st.primary_pack, scope)
    _wire(st, model, on_step)
    acc = _new_usage_acc()
    _RUN_USAGE.set(acc)                          # this run's context: specialists and critics too
    _install_metrics(st, model, acc, t0)
    transcript = [{"role": "user", "content": f"GOAL: {goal}\nBegin."}]
    return _loop(st, model, transcript, t0=t0, acc=acc, max_steps=max_steps,
                 cost_ceiling=cost_ceiling, max_seconds=max_seconds, scope=scope)


def resume_run(run_id: str, answer: str, answered_by: str, model=None,
               max_steps: int = MAX_STEPS, allow_branch: bool = False,
               cost_ceiling: float | None = None, max_seconds: float | None = None,
               on_step=None, answerer_owns=None, scope=None) -> RunState:
    """§20: continue an ESCALATED run after a person answers.

    `answerer_owns` is what the host knows the answerer owns (the roster's `owns`); the question's
    owner must be among them, or the resume is refused before anything is written. Unset, the
    roster is consulted; a person it does not know is recorded as `unverified`, never as eligible.
    The original gains `answered` ONLY when the successor reached done or escalated — an exhausted
    or refused successor records `answer_attempt` and leaves the question open (audit 8).

    The transcript is rebuilt from the recorded steps, the person's answer is appended AS DATA
    WITH ITS ATTRIBUTION, and the SAME bounded loop continues under the same rules. The answer
    informs the agent; whatever governed recording it needs remains the person's act.

    TRANSACTION-SAFE. An exclusive claim file (`<run>.answer.lock`, O_EXCL) is taken before
    anything is written and released when the successor finishes; a concurrent resume sees the
    claim and is refused. The ORIGINAL run gains its append-only `answered` step only AFTER the
    successor finished — a successor that raises closes nothing (audit 7: the step was written
    first, so a model failure closed the question for good, and two concurrent resumes both ran).
    An answered run is not resumed again unless `allow_branch`; a branch names the run it
    diverges from."""
    import time  # noqa: PLC0415
    import state as _state  # noqa: PLC0415
    t0 = time.time()
    prev = RunState.resume(run_id)
    model = control_plane.task_model(model or AnthropicModel(), route="governed_check", query=prev.goal,
        task_scope={"pack": prev.primary_pack} if prev.primary_pack in (scope or set()) else {})
    if (prev.outcome or {}).get("status") != "escalated":
        raise SystemExit(f"run {run_id} is {(prev.outcome or {}).get('status')!r} — only an "
                         f"escalated run resumes; a done run finished and a dead run is a bug")
    already = _answered_step(prev)
    if already and not allow_branch:
        raise SystemExit(f"run {run_id} was already answered by {already.get('by')!r} (run "
                         f"{already.get('run')}); resuming it again would fork the answer. Pass "
                         f"allow_branch=True to branch deliberately — the branch is recorded.")
    # AN ANSWER IS INGRESS TOO (review of audit 8): patient-shaped text typed as an answer would
    # have reached the model and the run record; the same deterministic classifier refuses it here
    try:
        import intake as _intake  # noqa: PLC0415
        _reasons = _intake.classify_ingress(answer)
    except ImportError:
        _reasons = []
    if _reasons:
        raise SystemExit("REFUSED — the answer looks like data about individual people ("
                         + "; ".join(_reasons) + "); nothing was recorded and no model was called")
    asked_to = _asked_owner(prev)
    eligibility, why = _eligibility(answered_by, asked_to, answerer_owns)
    if eligibility == "refused":
        raise SystemExit(f"REFUSED — {why}")
    lock = os.path.join(_state.RUNS, f"{run_id}.answer.lock")
    os.makedirs(_state.RUNS, exist_ok=True)
    try:
        fd = os.open(lock, os.O_CREAT | os.O_EXCL | os.O_WRONLY)
    except FileExistsError:
        raise SystemExit(f"run {run_id} is being answered right now (claim {os.path.basename(lock)}); "
                         f"wait for that resume to finish — then, if a second answer is really "
                         f"wanted, pass allow_branch=True") from None
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as fh:
            fh.write(f"{answered_by} {time.strftime('%Y-%m-%dT%H:%M:%S')}\n")
        try:
            asked = json.loads((prev.outcome or {}).get("summary") or "{}")
            if not isinstance(asked, dict):
                asked = {}
        except (ValueError, TypeError):
            asked = {}
        st = RunState(prev.goal, actor=prev.actor)
        st.primary_pack = prev.primary_pack if prev.primary_pack in (scope or set()) else None
        if callable(getattr(model, 'start_run', None)):
            model.start_run(st.primary_pack, scope)
        _wire(st, model, on_step)
        st.record("human_answer", answers_run=run_id, by=answered_by, answer=answer,
                  question=asked.get("question"), evidence=asked.get("evidence"), to=asked.get("to"),
                  eligibility=eligibility, branches_from=(already.get("run") if already else None))
        transcript = [{"role": "user", "content": f"GOAL: {prev.goal}\nBegin."}]
        for step in prev.steps:
            if step["kind"] == "decision":
                transcript.append({"role": "assistant", "content": json.dumps(step["decision"])})
            elif step["kind"] == "observation":
                transcript.append({"role": "user", "content": f"TOOL OUTPUT:\n{step['output']}"})
        transcript.append({"role": "user", "content":
                           f"HUMAN ANSWER from {answered_by} to your escalated question:\n{answer}\n"
                           f"Continue toward the goal under the same rules. The answer is context — "
                           f"if it needs recording (a decision form, an approval), that remains "
                           f"{answered_by}'s act in the repository, not yours."})
        acc = _new_usage_acc()
        _RUN_USAGE.set(acc)
        _install_metrics(st, model, acc, t0)
        result = _loop(st, model, transcript, t0=t0, acc=acc, max_steps=max_steps,
                       cost_ceiling=cost_ceiling, max_seconds=max_seconds, scope=scope)
        # ONLY NOW — the successor finished — and ONLY ON AN ACCEPTED OUTCOME is the original
        # answered (append-only, never rewritten). A successor that ran out of steps, money or time,
        # or was refused, established nothing: the attempt is recorded and the question stays open.
        status = (result.outcome or {}).get("status")
        if status in ("done", "escalated"):
            prev.record("answered", by=answered_by, run=st.run_id, branch=bool(already),
                        outcome=status, eligibility=eligibility)
        else:
            prev.record("answer_attempt", by=answered_by, run=st.run_id, outcome=status,
                        eligibility=eligibility)
        return result
    finally:
        try:
            os.remove(lock)
        except OSError:
            pass


if __name__ == "__main__":
    ap = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    ap.add_argument("--goal")
    ap.add_argument("--resume", metavar="RUN_ID", help="continue an escalated run")
    ap.add_argument("--answer", help="the human answer (with --resume)")
    ap.add_argument("--answered-by", help="who answered (with --resume)")
    ap.add_argument("--max-steps", type=int, default=MAX_STEPS)
    a = ap.parse_args()
    if a.resume:
        if not (a.answer and a.answered_by):
            ap.error("--resume needs --answer and --answered-by")
        result = resume_run(a.resume, a.answer, a.answered_by, max_steps=a.max_steps)
    else:
        if not a.goal:
            ap.error("--goal required (or --resume)")
        result = run(a.goal, max_steps=a.max_steps)
    print(f"[{result.outcome['status']}] {result.outcome['summary']}\n-> {result.path}")


def _verdict_key(st: RunState) -> tuple:
    """What two runs must agree on to count as the same answer: the outcome, and for an
    escalation its target and the question's first hundred characters normalised; for a done, the
    set of tools it rested on. Wording differences are not disagreement; a different outcome, a
    different escalation target, or an answer resting on different evidence is."""
    status = (st.outcome or {}).get("status")
    tools_used = tuple(sorted({str(s.get("tool")) for s in st.steps if s.get("kind") == "observation"}))
    if status == "escalated":
        try:
            q = json.loads((st.outcome or {}).get("summary") or "{}")
        except (ValueError, TypeError):
            q = {}
        return (status, str(q.get("to")), re.sub(r"[^a-z0-9 ]", "", str(q.get("question", "")).lower())[:100])
    return (status, tools_used)


def run_consistent(goal: str, votes: int = 3, min_agreement: float = 0.9, model=None,
                   max_steps: int = MAX_STEPS, actor: dict | None = None) -> dict:
    """Self-consistency for governed use: run `votes` times, present an answer ONLY when the
    verdicts agree at least `min_agreement` of the time (the operator's tolerance: a 5-10%
    deviation is noise, a 100% deviation is a different answer). Below that, nothing is presented
    -- the goal is escalated as UNSTABLE with every verdict listed, because choosing one of two
    disagreeing answers is exactly the coin-flip a governed surface must never make. Any
    `ungrounded` run disqualifies the whole vote regardless of the others.

    Returns {stable, agreement, verdicts, runs, presented} where `presented` is the RunState whose
    verdict won (only when stable) and `runs` is every RunState for the transcript readers."""
    runs = [run(goal, model=model, max_steps=max_steps, actor=actor) for _ in range(max(1, votes))]
    keys = [_verdict_key(st) for st in runs]
    if any((st.outcome or {}).get("status") == "ungrounded" for st in runs):
        return {"stable": False, "agreement": 0.0, "verdicts": keys, "runs": runs, "presented": None,
                "why": "an ungrounded run disqualifies the vote: at least one answer was fabricated"}
    top = max(set(keys), key=keys.count)
    agreement = keys.count(top) / len(keys)
    stable = agreement >= min_agreement
    return {"stable": stable, "agreement": round(agreement, 3), "verdicts": keys, "runs": runs,
            "presented": next(st for st, k in zip(runs, keys) if k == top) if stable else None,
            "why": None if stable else f"verdicts agree {agreement:.0%} < {min_agreement:.0%}: unstable, escalate rather than pick"}
