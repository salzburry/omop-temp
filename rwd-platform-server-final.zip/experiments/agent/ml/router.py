"""ML item 1 — model routing as a learned classifier.

Today's honest target, with only one model's runs recorded: P(this case needs MORE than the
current model) — proxied by mechanical failure until adjudication and multi-model runs supply
richer labels ("Sonnet suffices / needs Opus / human"). The classifier never decides anything:
its output is advisory routing evidence, and the benchmark's rule stands — routing is CLAIMED
only when these numbers, at real volume, say so.

    python experiments/agent/ml/router.py --train         # from the real ledger (honest small-n)
    python experiments/agent/ml/router.py --synthetic 200 # reviewer mode: known rule, recovered?
"""
from __future__ import annotations

import argparse
import json
import os
import random
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
from features import load_ledger, build_ledger  # noqa: E402
from logreg import LogReg, loo_accuracy  # noqa: E402

FEATS = ["goal_len", "trigger_hits", "steps", "n_tools", "used_specialist",
         "authority_marker", "calls", "in_tok", "out_tok", "latency_s"]
# Local selected-model adapters do not report token usage. The canonical
# reviewed trainer uses only measured completed-check features, never invented
# zero token/cost values. These features must not be used before completion.
REVIEWED_FEATS = ['goal_len', 'trigger_hits', 'steps', 'n_tools', 'used_specialist',
                  'authority_marker', 'total_calls']
# REAL-DATA TRAINING LIVES IN train_all.py — one trainer, one acceptance rule (LOO accuracy
# must beat the majority baseline at n >= 30), one artifact per learner (router.json). This module
# keeps the synthetic harness a reviewer runs without data. Two trainers writing two files under
# two rules was the audit-6 finding.
ARTIFACT = os.path.join(HERE, "router.json")


def rows_to_xy(rows, label_key="needs_more"):
    X, y = [], []
    for r in rows:
        lab = r["labels"].get(label_key)
        if lab is None:
            continue
        X.append([float(r["features"].get(f, 0)) for f in FEATS])
        y.append(int(lab))
    return X, y


def train_real():
    raise SystemExit("real-data training is train_all.py's: run "
                     "`python experiments/agent/ml/train_all.py` — it writes router.json only when "
                     "LOO accuracy beats the majority baseline at n >= 30. This module keeps the "
                     "synthetic harness (--synthetic N).")


def synthetic(n, seed=11):
    """Reviewer mode: generate cases from a KNOWN rule (long goals with trigger words and no
    specialist tend to need more), train, and report whether the learner recovers it. A reviewer
    (human or another model) can vary n and the noise and watch the recovery curve."""
    rng = random.Random(seed)
    X, y = [], []
    for _ in range(n):
        f = [rng.randint(40, 400), rng.randint(0, 6), rng.randint(2, 18), rng.randint(1, 6),
             rng.randint(0, 1), rng.randint(0, 1), rng.randint(2, 20),
             rng.randint(2000, 90000), rng.randint(200, 9000), rng.uniform(5, 300)]
        signal = 0.012 * f[0] + 0.9 * f[1] - 1.2 * f[4] + 0.8 * f[5] - 4.0
        p = 1 / (1 + pow(2.718281828, -signal))
        y.append(int(rng.random() < p))
        X.append(f)
    acc, base = loo_accuracy(FEATS, X, y) if n <= 60 else (None, None)
    m = LogReg(FEATS).fit(X, y)
    # holdout when big enough
    if n > 60:
        cut = int(n * 0.8)
        m = LogReg(FEATS).fit(X[:cut], y[:cut])
        hits = sum(int((m.predict_proba(x) >= .5) == bool(t)) for x, t in zip(X[cut:], y[cut:]))
        acc = hits / (n - cut)
        base = max(sum(y[cut:]), (n - cut) - sum(y[cut:])) / (n - cut)
    print(f"SYNTHETIC n={n}: accuracy={acc:.2f} vs baseline={base:.2f}")
    print("recovered weights (goal_len, trigger_hits, used_specialist, authority_marker should "
          "dominate):")
    print(" ", m.explain()[:5])


if __name__ == "__main__":
    ap = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    ap.add_argument("--train", action="store_true")
    ap.add_argument("--synthetic", type=int, metavar="N")
    a = ap.parse_args()
    if a.synthetic:
        synthetic(a.synthetic)
    elif a.train:
        train_real()
    else:
        ap.error("--train or --synthetic N")
