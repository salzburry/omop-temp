"""ML item 3 — the escalation-recall net: a learned second net behind the AUTHORITY_RE regex.

Label: should this run have escalated? — from the corpus's expectations today, from adjudicated
verdicts as those accrue. The regex stays: this net is measured BY §19's escalation-recall
metric and never replaces the deterministic backstop; a learned net that misses is caught by the
regex, and a regex miss is what the net exists to learn.

    python experiments/agent/ml/escalation_net.py --train
    python experiments/agent/ml/escalation_net.py --synthetic 200
"""
from __future__ import annotations

import argparse
import io
import json
import os
import random
import sys

import yaml

HERE = os.path.dirname(os.path.abspath(__file__))
AGENT = os.path.dirname(HERE)
sys.path.insert(0, HERE)
from features import load_ledger, build_ledger  # noqa: E402
from logreg import LogReg, loo_accuracy  # noqa: E402

# interpretable text features over the GOAL — the escalation question is mostly askable before
# any tool runs, which is what makes this net useful as a pre-flight hint
WORDS = ["decide", "decision", "approve", "equivalent", "bind", "switch", "change", "window",
         "censor", "sign", "release", "should", "rule", "mean"]
FEATS = [f"w_{w}" for w in WORDS] + ["goal_len", "question_mark"]
# REAL-DATA TRAINING LIVES IN train_all.py — one trainer, one acceptance rule (LOO accuracy
# must beat the majority baseline at n >= 30), one artifact per learner (escalation.json). This module
# keeps the synthetic harness a reviewer runs without data. Two trainers writing two files under
# two rules was the audit-6 finding.
ARTIFACT = os.path.join(HERE, "escalation.json")


def goal_features(goal: str):
    g = goal.lower()
    return [float(g.count(w)) for w in WORDS] + [float(len(goal)), float("?" in goal)]


def _expected_escalation() -> dict:
    """case goal -> whether the corpus accepts/expects escalation for it."""
    cases = yaml.safe_load(io.open(os.path.join(AGENT, "evals", "cases.yaml"), encoding="utf-8"))
    out = {}
    for c in cases:
        exp = c.get("expect", {}).get("outcome")
        exp = exp if isinstance(exp, list) else [exp]
        out[c["goal"].strip()[:80]] = int("escalated" in exp and "done" not in exp) \
            if "escalated" in exp else 0
    return out


def train_real():
    raise SystemExit("real-data training is train_all.py's: run "
                     "`python experiments/agent/ml/train_all.py` — it writes escalation.json only when "
                     "LOO accuracy beats the majority baseline at n >= 30. This module keeps the "
                     "synthetic harness (--synthetic N).")


def synthetic(n, seed=13):
    rng = random.Random(seed)
    X, y = [], []
    for _ in range(n):
        k = rng.randint(0, 3)
        words = rng.sample(WORDS, k)
        goal = " ".join(words) + " " + "x" * rng.randint(30, 200) + ("?" if rng.random() < .5 else "")
        lab = int(("decide" in words or "approve" in words or "equivalent" in words)
                  and rng.random() < 0.9 or rng.random() < 0.08)
        X.append(goal_features(goal)); y.append(lab)
    cut = max(10, int(n * 0.8))
    m = LogReg(FEATS).fit(X[:cut], y[:cut])
    hits = sum(int((m.predict_proba(x) >= .5) == bool(t)) for x, t in zip(X[cut:], y[cut:]))
    base = max(sum(y[cut:]), len(y[cut:]) - sum(y[cut:])) / max(1, len(y[cut:]))
    print(f"SYNTHETIC n={n}: holdout accuracy={hits / max(1, len(y[cut:])):.2f} "
          f"vs baseline={base:.2f}")
    print("top weights (decide/approve/equivalent should dominate):", m.explain()[:4])


if __name__ == "__main__":
    ap = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    ap.add_argument("--train", action="store_true")
    ap.add_argument("--synthetic", type=int, metavar="N")
    a = ap.parse_args()
    if a.synthetic:
        synthetic(a.synthetic)
    elif a.train:
        train_real()
    else:
        ap.error("--train or --synthetic N")
