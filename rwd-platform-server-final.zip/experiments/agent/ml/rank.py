"""ML item 2 — learning-to-rank for mapping candidates: the deterministic ranking stays the
floor, accepted human rulings become labels, the decision stays a person's.

Reviewed mappings can be exported from the existing Model lifecycle workspace. Real training
refuses missing or changed evidence and reports insufficient independent data. The --synthetic mode is the
reviewer's harness: it fabricates roles, candidate tables and acceptance labels from a known
preference (coverage beats token overlap beats kind match), trains a pairwise ranker, and
reports whether learned ordering beats the lexical baseline on held-out roles.

    python experiments/agent/ml/rank.py --synthetic 120
    python experiments/agent/ml/rank.py --train labels.yaml --root .
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
from functools import lru_cache
import random
import re
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
from logreg import LogReg  # noqa: E402

FEATS = ["token_jaccard", "coverage", "kind_match", "grain_hit"]
OBJECTIVE = "mapping_candidate_ranker"
MAX_LABELS = 120


def digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(",", ":"), allow_nan=False).encode()).hexdigest()


def review_metadata(record):
    """Locally attributed human review, never an authentication assertion."""
    from pathlib import Path
    sys.path[:0] = [str(Path(HERE).parent), str(Path(HERE).parents[2] / "platform/tools")]
    import person_rules
    import control_plane
    if (person_rules.unstated(record.get("reviewed_by")) or person_rules.not_a_person(record.get("reviewed_by"))
            or control_plane._bad_date(record.get("reviewed_on"))
            or not isinstance(record.get("rationale"), str) or not 10 <= len(record["rationale"].strip()) <= 3000):
        raise ValueError("A named reviewer, review date and independent rationale are required.")


def validate_label(record, pack=None):
    if (not isinstance(record, dict) or record.get("record_type") != "reviewed_mapping_label"
            or record.get("objective_id") != OBJECTIVE or record.get("confirmed_real_work") is not True
            or record.get('training_eligible', True) is not True
            or not re.fullmatch(r"products/[A-Za-z0-9_-]+/[A-Za-z0-9_-]+/\d{6}", str(record.get("pack", "")))
            or pack is not None and record["pack"] != pack):
        raise ValueError("Use a locally reviewed real mapping decision from this working product.")
    review_metadata(record)
    case = record.get("case")
    if (not isinstance(case, dict) or set(case) != {"case_id", "source_group", "split", "evidence", "role_tokens", "required_columns", "candidates", "accepted_candidate"}
            or any(not re.fullmatch(r"[A-Za-z][A-Za-z0-9_-]{0,79}", str(case.get(key, ""))) for key in ("case_id", "source_group"))
            or case.get("split") not in {"development", "heldout"}):
        raise ValueError("Name the mapping case, independent source family and its reserved development/heldout split.")
    for key in ("role_tokens", "required_columns"):
        values = case[key]
        if (not isinstance(values, list) or not 1 <= len(values) <= 100
                or any(not isinstance(v, str) or not re.fullmatch(r"[A-Za-z][A-Za-z0-9_]{0,79}", v) for v in values)
                or len(set(values)) != len(values)):
            raise ValueError("Use distinct declared role tokens and required column names.")
    evidence = case["evidence"]
    if (not isinstance(evidence, dict) or set(evidence) != {"path", "sha256"}
            or not isinstance(evidence.get("path"), str) or "\\" in evidence["path"]
            or not evidence["path"].startswith(record["pack"] + "/")
            or any(part in {"..", ".", ""} for part in evidence["path"].split("/"))
            or not re.fullmatch(r"[a-f0-9]{64}", str(evidence.get("sha256", "")))):
        raise ValueError("Bind the exact reviewed candidate evidence file within this product and its SHA256.")
    candidates = case["candidates"]
    if not isinstance(candidates, list) or not 2 <= len(candidates) <= 20:
        raise ValueError("Retain two to twenty candidates reviewed together, including the accepted table.")
    names = []
    for candidate in candidates:
        if (not isinstance(candidate, dict) or set(candidate) != {"name", "columns", "kind_match"}
                or not isinstance(candidate["name"], str) or not re.fullmatch(r"[A-Za-z][A-Za-z0-9_.]{0,119}", candidate["name"])
                or type(candidate["kind_match"]) is not bool or not isinstance(candidate["columns"], list)
                or len(candidate["columns"]) > 250 or any(not isinstance(column, str) or not re.fullmatch(r"[A-Za-z][A-Za-z0-9_]{0,79}", column) for column in candidate["columns"])
                or len(set(candidate["columns"])) != len(candidate["columns"])):
            raise ValueError("Each candidate needs its actual table name, distinct columns and explicit kind-match review.")
        names.append(candidate["name"])
    if len(set(names)) != len(names) or case["accepted_candidate"] not in names:
        raise ValueError("Name one accepted table among distinct reviewed candidates.")
    accepted = candidates[names.index(case["accepted_candidate"])]
    if not set(case["required_columns"]) <= set(accepted["columns"]):
        raise ValueError("An accepted mapping label must carry every required column; unresolved mappings are not positive labels.")
    return case


def case_fingerprint(case):
    """Order changes do not make the same candidate evidence independent."""
    return digest({'role_tokens': sorted(set(case['role_tokens'])), 'required_columns': sorted(set(case['required_columns'])),
        'candidates': sorted([dict(candidate, columns=sorted(set(candidate['columns']))) for candidate in case['candidates']], key=lambda candidate: candidate['name'])})


def checked_labels(records, root, *, _verify_evidence=True):
    if not isinstance(records, list) or len(records) > MAX_LABELS:
        raise ValueError("Evaluate at most 120 reviewed mapping decisions at a time.")
    try:
        if len(json.dumps(records, allow_nan=False).encode()) > 1_500_000:
            raise ValueError('Keep the combined reviewed mapping metadata within 1.5 megabytes.')
    except (TypeError, RecursionError, OverflowError):
        raise ValueError('The reviewed mapping metadata must contain bounded structured values.') from None
    root = Path(root).resolve()
    seen, fingerprints, groups, evidence_splits = set(), set(), {}, {}
    result = []
    for record in records:
        try:
            case = validate_label(record)
        except (TypeError, KeyError, AttributeError, RecursionError):
            raise ValueError('A reviewed mapping label has malformed nested fields.') from None
        identity = (record["pack"], case["case_id"])
        fingerprint = case_fingerprint(case)
        if identity in seen or fingerprint in fingerprints:
            raise ValueError("Repeated cases or candidate sets cannot count as independent mapping labels.")
        seen.add(identity); fingerprints.add(fingerprint)
        group = case["source_group"]
        evidence = case["evidence"]
        for lookup, key in ((groups, group), (evidence_splits, evidence["sha256"])):
            if key in lookup and lookup[key] != case["split"]:
                raise ValueError("A source family or exact evidence snapshot cannot appear in both development and heldout sets.")
            lookup[key] = case["split"]
        path = root / evidence["path"]
        if _verify_evidence and (path.resolve() != path or not path.is_file() or path.stat().st_size > 2_000_000 or hashlib.sha256(path.read_bytes()).hexdigest() != evidence["sha256"]):
            raise ValueError("The reviewed mapping evidence changed, is unavailable or redirects outside its product.")
        result.append(case)
    return result


def train_reviewed(records, root):
    """Fit development cases only; score the frozen source-disjoint holdout once."""
    cases = checked_labels(records, root)
    return _measure_cases(cases, digest(records))


def _measure_cases(cases, rows_digest):
    development = [case for case in cases if case["split"] == "development"]
    heldout = [case for case in cases if case["split"] == "heldout"]
    measurement = {"development_cases": len(development), "heldout_cases": len(heldout),
        "development_groups": len({c["source_group"] for c in development}), "heldout_groups": len({c["source_group"] for c in heldout}),
        "accepted_for_review": False, "artifact": None, "rows_digest": rows_digest, "activation": False,
        "minimums": {"development_cases": 30, "heldout_cases": 10, "development_groups": 3, "heldout_groups": 2},
        "notice": "Technical mapping-rank evaluation of locally attributed decisions. No mapping is applied, no model is activated and no scientific approval is recorded."}
    if any(measurement[key] < minimum for key, minimum in measurement["minimums"].items()):
        return dict(measurement, status="insufficient_data", findings=["Collect reviewed independent mappings and reserve whole source families before measuring the ranker."])
    pairs = []
    for case in development:
        best = next(candidate for candidate in case["candidates"] if candidate["name"] == case["accepted_candidate"])
        accepted = pair_features(set(case["role_tokens"]), set(case["required_columns"]), best)
        pairs.extend((accepted, pair_features(set(case["role_tokens"]), set(case["required_columns"]), candidate))
                     for candidate in case["candidates"] if candidate["name"] != best["name"])
    model = train_pairwise(pairs)
    sys.path.insert(0, str(Path(HERE).parents[2] / "platform/tools"))
    import propose_source_mapping
    outcomes = []
    for case in heldout:
        order = sorted(case["candidates"], key=lambda candidate: (-model.predict_proba(pair_features(set(case["role_tokens"]), set(case["required_columns"]), candidate)), candidate["name"]))
        baseline = propose_source_mapping.candidates({"role": "_".join(case["role_tokens"]), "required_columns": case["required_columns"]},
            {candidate["name"]: candidate["columns"] for candidate in case["candidates"]}, {}, top=None)
        baseline_top = baseline[0]["table"] if baseline else None
        outcomes.append({"case_id": case["case_id"], "source_group": case["source_group"], "accepted": case["accepted_candidate"],
            "learned": order[0]["name"], "baseline": baseline_top, "learned_correct": order[0]["name"] == case["accepted_candidate"],
            "baseline_correct": baseline_top == case["accepted_candidate"]})
    learned = sum(row["learned_correct"] for row in outcomes) / len(outcomes)
    baseline = sum(row["baseline_correct"] for row in outcomes) / len(outcomes)
    accepted = learned > baseline
    return dict(measurement, status="measured", heldout_results=outcomes, learned_top1=learned, deterministic_top1=baseline,
        accepted_for_review=accepted, artifact={"names": model.names, "w": model.w, "b": model.b, "mu": model.mu, "sd": model.sd} if accepted else None,
        findings=["Learned ordering exceeded the existing deterministic baseline; inspect the exact holdout cases." if accepted else "The learned ordering did not exceed the deterministic baseline. Keep the existing ranking."])


@lru_cache(maxsize=8)
def _reproduce_snapshot(encoded_rows):
    rows = json.loads(encoded_rows)
    # Reading a historical measurement checks its frozen evidence, not today's
    # delivery files. New training always verifies the actual files above.
    cases = checked_labels(rows, '.', _verify_evidence=False)
    return digest(_measure_cases(cases, digest(rows)))


def verify_measurement(rows, measured):
    """Refit the bounded frozen development set and recompute every heldout result."""
    encoded = json.dumps(rows, sort_keys=True, allow_nan=False)
    if digest(measured) != _reproduce_snapshot(encoded):
        raise ValueError('The mapping measurement, fitted parameters or heldout outcomes differ from canonical reproduction.')


def load_labels(path):
    path = Path(path)
    if not path.is_file() or path.stat().st_size > 2_000_000:
        raise ValueError("Choose a reviewed-label export no larger than two megabytes.")
    import yaml
    class UniqueLoader(yaml.SafeLoader):
        pass
    def mapping(loader, node, deep=False):
        result = {}
        for key_node, value_node in node.value:
            key = loader.construct_object(key_node, deep=deep)
            if key in result:
                raise ValueError("Repeated YAML keys are not allowed in reviewed labels.")
            result[key] = loader.construct_object(value_node, deep=deep)
        return result
    UniqueLoader.add_constructor(yaml.resolver.BaseResolver.DEFAULT_MAPPING_TAG, mapping)
    try:
        document = yaml.load(path.read_text(encoding="utf-8"), Loader=UniqueLoader)
        json.dumps(document, allow_nan=False)
    except (yaml.YAMLError, TypeError, RecursionError, ValueError) as error:
        raise ValueError("The reviewed-label export is malformed, recursive or nonfinite.") from None
    if not isinstance(document, dict) or set(document) != {"version", "labels"} or type(document['version']) is not int or document["version"] != 1:
        raise ValueError("Use a version 1 reviewed mapping-label export.")
    return document["labels"]


def pair_features(role_tokens, req_cols, cand):
    name_tokens = set(cand["name"].lower().replace("_", " ").split())
    j = len(role_tokens & name_tokens) / max(1, len(role_tokens | name_tokens))
    cov = len(req_cols & set(cand["columns"])) / max(1, len(req_cols))
    return [j, cov, float(cand.get("kind_match", 0)), float("patientid" in cand["columns"])]


def train_pairwise(samples):
    """samples: [(features_accepted, features_rejected), ...] -> LogReg on the DIFFERENCE."""
    X, y = [], []
    for fa, fr in samples:
        X.append([a - b for a, b in zip(fa, fr)]); y.append(1)
        X.append([b - a for a, b in zip(fa, fr)]); y.append(0)
    return LogReg(FEATS).fit(X, y)


def synthetic(n_roles, seed=19):
    rng = random.Random(seed)
    words = ["biomarker", "lab", "ecog", "lot", "treatment", "death", "visit", "vitals",
             "stage", "histology"]

    def make_role():
        w = rng.choice(words)
        role_tokens = {w, "date"}
        req = {f"{w}value", f"{w}date", "patientid"}
        cands = []
        for i in range(4):
            good = i == 0
            cols = set(rng.sample(sorted(req), rng.randint(2, 3) if good else rng.randint(0, 2)))
            cands.append({"name": f"t_enh_{w if good or rng.random() < .3 else rng.choice(words)}"
                                  f"_{i}",
                          "columns": cols | ({"patientid"} if rng.random() < .8 else set()),
                          "kind_match": int(good or rng.random() < .4)})
        # the KNOWN acceptance rule the learner must recover: highest coverage, ties by tokens
        best = max(cands, key=lambda c: (len(req & set(c["columns"])),
                                         c["name"].count(w), c["kind_match"]))
        return role_tokens, req, cands, best

    roles = [make_role() for _ in range(n_roles)]
    cut = int(n_roles * 0.75)
    pairs = []
    for role_tokens, req, cands, best in roles[:cut]:
        fb = pair_features(role_tokens, req, best)
        for c in cands:
            if c is not best:
                pairs.append((fb, pair_features(role_tokens, req, c)))
    m = train_pairwise(pairs)

    def rank(role, model=None):
        role_tokens, req, cands, best = role
        if model:
            order = sorted(cands, key=lambda c: -model.predict_proba(
                pair_features(role_tokens, req, c)))
        else:  # lexical baseline: token overlap only
            order = sorted(cands, key=lambda c: -pair_features(role_tokens, req, c)[0])
        return order[0] is best

    held = roles[cut:]
    learned = sum(rank(r, m) for r in held) / len(held)
    lexical = sum(rank(r) for r in held) / len(held)
    print(f"SYNTHETIC roles={n_roles} (held-out {len(held)}): top-1 accuracy "
          f"learned={learned:.2f} vs lexical baseline={lexical:.2f}")
    print("weights (coverage should dominate):", m.explain())
    print("PASS" if learned > lexical else "MARGINAL — vary the seed/n; small samples wobble")


if __name__ == "__main__":
    ap = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    ap.add_argument("--synthetic", type=int, metavar="N_ROLES")
    ap.add_argument("--train", metavar="LABELS_YAML")
    ap.add_argument("--root", default=".", help="Checkout containing the exact reviewed evidence files")
    a = ap.parse_args()
    if a.synthetic:
        synthetic(a.synthetic)
    elif a.train:
        try:
            result = train_reviewed(load_labels(a.train), a.root)
            print(json.dumps(result, indent=2, allow_nan=False))
            sys.exit(2 if result["status"] == "insufficient_data" else 0)
        except (OSError, ValueError) as error:
            print("REFUSED: " + str(error), file=sys.stderr)
            sys.exit(1)
    else:
        ap.error("--synthetic N or --train labels.yaml")
