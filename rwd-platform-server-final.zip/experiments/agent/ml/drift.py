"""ML item 5 — profile drift detection between cuts, feeding the Validation agent's checks.

Profiles carry AGGREGATES (top-value counts, missingness, date ranges), not raw samples — so the
right statistics here are L1 distance over the top-value distribution, missingness delta, and
date-range shift. A proper KS test applies only where raw values exist (cluster-side); this tool
says which statistic it used rather than dressing an L1 up as a KS.

Output is Validation-agent food: per drifted column, the finding AND the discriminating check.

    python experiments/agent/ml/drift.py <old_profile.tsv> <new_profile.tsv>
    python experiments/agent/ml/drift.py --demo     # perturbs the synthetic profile; must detect
"""
from __future__ import annotations

import argparse
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(os.path.dirname(os.path.dirname(HERE)))
sys.path.insert(0, os.path.join(ROOT, "platform", "tools"))
sys.path.insert(0, os.path.join(ROOT, "platform"))
import profile_io  # noqa: E402

L1_THRESHOLD = 0.25      # fraction of probability mass that moved
MISS_THRESHOLD = 0.10    # absolute missing-rate delta


def _dist(top_values: str) -> dict:
    """'12:F 8:M' -> {F: .6, M: .4}"""
    pairs = []
    for tok in (top_values or "").replace("|", " ").split():
        if ":" in tok:
            c, v = tok.split(":", 1)
            try:
                pairs.append((v, float(c)))
            except ValueError:
                pass
    total = sum(c for _, c in pairs) or 1.0
    return {v: c / total for v, c in pairs}


def compare(old_tsv: str, new_tsv: str):
    old, _ = profile_io.load(old_tsv)
    new, _ = profile_io.load(new_tsv)
    findings = []
    # SHAPE FIRST: a column that appeared or vanished is the loudest drift there is, and the
    # column-wise loop below cannot see it because it iterates the intersection (second audit:
    # added + removed columns and a five-year date shift all returned no findings).
    for t in sorted(set(old) - set(new)):
        findings.append((t, "*", "table absent from the new cut",
                         "confirm the delivery manifest lists this table; check load filters"))
    for t in sorted(set(new) - set(old)):
        findings.append((t, "*", "table new in this cut",
                         "confirm the source contract expects it before any stage reads it"))
    for t in sorted(set(old) & set(new)):
        for c in sorted(set(old[t]) - set(new[t])):
            findings.append((t, c, "column removed in the new cut",
                             "run the schema preflight; a stage reading it will fail to resolve"))
        for c in sorted(set(new[t]) - set(old[t])):
            findings.append((t, c, "column added in the new cut",
                             "check the dictionary for the new column before mapping anything to it"))
        for c in sorted(set(old[t]) & set(new[t])):
            o, n = old[t][c], new[t][c]
            # DATE RANGE: a shifted min/max on a date column is a cut-boundary or a re-keyed
            # source; measured in days, thresholded at a year
            for edge in ("date_min", "date_max"):
                ov, nv = o.get(edge), n.get(edge)
                if ov in (None, "") and nv in (None, ""):
                    continue                          # no date evidence on either side: not a column of dates
                try:
                    from datetime import date as _d
                    do, dn = _d.fromisoformat(str(ov)[:10]), _d.fromisoformat(str(nv)[:10])
                    days = abs((dn - do).days)
                except (TypeError, ValueError):
                    # LOST OR MALFORMED DATE EVIDENCE IS A FINDING, not "no drift": a parse failure
                    # used to become days=0 and vanish (third audit)
                    findings.append((t, c, f"{edge} evidence unreadable ({ov!r} -> {nv!r})",
                                     "re-profile the column; a date range that cannot be read "
                                     "cannot be compared, and a lost range is itself a change"))
                    continue
                if days > 365:
                    findings.append((t, c, f"{edge} moved by {days} days ({o.get(edge)} -> {n.get(edge)})",
                                     "compare the delivery cut dates and the study window; a "
                                     "shifted range changes every index-anchored derivation"))
            d_o, d_n = _dist(o.get("top_values")), _dist(n.get("top_values"))
            keys = set(d_o) | set(d_n)
            l1 = sum(abs(d_o.get(k, 0) - d_n.get(k, 0)) for k in keys) / 2 if keys else 0
            try:
                miss_d = abs(float(n.get("pct_missing") or 0)
                             - float(o.get("pct_missing") or 0)) / 100.0
            except (TypeError, ValueError):
                miss_d = 0
            if l1 > L1_THRESHOLD:
                findings.append((t, c, f"top-value distribution moved (L1={l1:.2f})",
                                 "pull raw samples cluster-side and run a KS test on this column"))
            if miss_d > MISS_THRESHOLD:
                findings.append((t, c, f"missing rate moved by {miss_d:.2f}",
                                 "compare row counts and load filters between the two cuts"))
    return findings


def demo():
    """Perturb one column of the synthetic profile and require detection — the reviewer's test."""
    scratch = os.environ.get("TEMP", ".")
    # the synthetic profile from the Engineering-chain demo lives under the session scratchpad
    import glob
    hits = glob.glob(os.path.join(scratch, "claude", "**", "profile_2026m06.tsv"),
                     recursive=True)
    if not hits:
        raise SystemExit("demo needs the synthetic profile from the Engineering-chain run "
                         "(scratchpad eng_restricted) — rerun eng_act.py first")
    src = hits[0]
    text = open(src, encoding="utf-8").read()
    # flip the dominant top-value counts on one line to simulate a shifted distribution
    drifted = text.replace("13:V0|13:V1", "24:V0|2:V1").replace("13:V1|13:V0", "24:V1|2:V0")
    dst = os.path.join(os.path.dirname(src), "profile_drifted_demo.tsv")
    open(dst, "w", encoding="utf-8").write(drifted)
    f = compare(src, dst)
    print(f"demo: {len(f)} drift finding(s) between the profile and its perturbed copy")
    for t, c, what, check in f[:6]:
        print(f"  {t}.{c}: {what}\n     discriminating check: {check}")
    print("PASS" if f else "FAIL — the perturbation was not detected")


if __name__ == "__main__":
    ap = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    ap.add_argument("profiles", nargs="*", help="old.tsv new.tsv")
    ap.add_argument("--demo", action="store_true")
    a = ap.parse_args()
    if a.demo:
        demo()
    elif len(a.profiles) == 2:
        for t, c, what, check in compare(*a.profiles):
            print(f"{t}.{c}: {what} | check: {check}")
    else:
        ap.error("two profile TSVs, or --demo")
