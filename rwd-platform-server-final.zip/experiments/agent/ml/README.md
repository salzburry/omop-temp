# ml/ — the six sanctioned ML homes, runnable today

Every model here is **advisory** — a ranker or router over labels the governed workflow produces
as a byproduct. None moves an authority boundary; none scores its own acceptance; fine-tuning
stays out. Stdlib-only on purpose (`logreg.py` is the whole learner, readable in one sitting) —
promoting to sklearn is a deliberate act once data volume justifies it.

## For an external reviewer (synthetic test harnesses)

Each tool has a mode that fabricates data from a **known ground truth** and reports whether the
learner recovers it — no API keys, no repo knowledge, no live data needed:

```
python experiments/agent/ml/router.py --synthetic 200
python experiments/agent/ml/escalation_net.py --synthetic 200
python experiments/agent/ml/calibrate.py --synthetic 300
python experiments/agent/ml/rank.py --synthetic 120
python experiments/agent/ml/drift.py --demo          # needs the synthetic profile (eng_act.py)
python experiments/agent/ml/embed.py --demo
```

What to check, per tool: does it beat its stated baseline; do the recovered weights match the
generative rule the docstring names; do the honesty banners fire at small n; can you make it
fail by cranking noise or shrinking n (it should degrade loudly, not silently).

## Real-data modes and what they honestly say today

| tool | real command | today's expected output |
|---|---|---|
| router | `--train` | trains on the eval ledger; at current n it reports LOO vs baseline and refuses to route if it cannot beat it |
| escalation_net | `--train` | same discipline over goal-text features |
| calibrate | (no flag) | reliability by critic confidence with Wilson intervals; at n≈5 the banner says the only sane policy is second-vote-everything |
| rank | `--train reviewed-mapping-labels.json --root .` | Loads the existing learning-page export, verifies reviewed evidence and measures reserved source families; insufficient labels return no artifact |
| drift | `old.tsv new.tsv` | L1/missingness/date-shift findings, each with a discriminating check for the Validation agent; says it is not a KS test (profiles are aggregates) |
| embed | `--index` / `--query` | pointers into governed rows; hashed-trigram stand-in vectors until the concept-layer coordination — swap seam is `vec()` |

## The data flywheel

`features.py` sweeps every eval run (metrics stamped by §19) into `training_ledger.jsonl`.
Running evals grows the ledger; adjudication upgrades labels; accepted mappings label the ranker;
multi-model runs turn the router's binary proxy into the real "Sonnet suffices / needs Opus /
human" target. No annotation campaign — governance exhaust is the training set.

## Wired into the agents

| learner | where it acts | how |
|---|---|---|
| calibration (item 4) | `critic.review` | every verdict carries `second_vote_recommended` + the bucket's measured reliability; missing artifact = second vote for everything |
| embeddings (item 6) | `tools.semantic_search` | a read-only orchestrator tool; pointers to governed rows, never answers |
| drift (item 5) | `tools.drift_check` | two profiles under `RWD_PROFILE_DIR` only; refuses any other path |
| router / escalation (items 1, 3) | `train_all.py` -> exact product evaluation | The portal reuses the canonical trainer and baseline rule, then requires an explicit local review before `model_lifecycle_runtime` offers a next action after a completed check. Legacy unreviewed `router.json` / `escalation.json` are **not consumed at runtime**. |

One command retrains everything and writes the honest page: `python experiments/agent/ml/train_all.py` -> `ml/REPORT.md`.

## Local product workflow

Open **Improve the assistant from reviewed checks** for a working product. Run a
metadata-only governed check with the explicitly selected assistant, inspect the
retained transcript and metrics, and record the person's label and rationale.
Scripted runs, arbitrary `real` flags and legacy transcripts without the portal's
collected execution receipt do not qualify. These are locally attributed records,
not cryptographically authenticated proof.

The existing objective IDs keep their meanings: escalation uses an independently
reviewed `should_escalate` label; router review requires the exact same case and
source inputs under two different selected models; calibration reviews one actual
recorded critic verdict and its confidence bucket. The canonical binary trainer
requires 30 independent cases, both classes, and leave-one-out accuracy above the
majority baseline. Calibration uses the existing Wilson lower-bound policy and
requires 30 reviewed verdicts per observed bucket.

Labels, measured evaluations (including the exact fitted model), and explicit
activations are immutable JSON records under the selected product's
`handoff/model_lifecycle/{labels,evaluations,activations}/`. They travel with the
local Git branch; the portal does not commit them. Activation re-runs the canonical
measurement, binds the exact input records and objective/trainer versions, and
applies the existing control-plane verdict rules to a product-scoped override.
It does not rewrite the shared objective registry, select another provider,
approve a scientific definition or release a product.

The consumer runs only after a check's outcome and metrics have been recorded.
It offers a button to review an escalation, compare a completed case under another
model, or seek another critic review. A changed/deleted artifact, corrected label,
changed trainer/registry, or explicit deactivation stops that version's suggestions.
Unknown or missing confidence buckets retain the second-review requirement.

Fixed orchestration and intake model choices still need the existing benchmark
and intake-corpus adjudication declared in `governance/OBJECTIVES.yaml`. Ordinary
single-model checks do not establish those comparisons. No actual product model
activation is claimed by implementing or testing this workflow.

The orchestration objective also opens the existing `evals/run.py` behaviour
evaluator directly in this page: preview one to three accessible original cases,
confirm the selected connection and run them through the same bounded SessionModel.
The original reference/default scopes remain visible and unchanged. Each case has
a four-call cap and a 90-second check limit; a call already in flight may finish
after that limit. The retained evaluation includes the canonical mechanical score,
transcript hashes and snapshots, model metadata, and unknown cost as `null` where
the local adapter does not measure it. Changed inputs or a disconnected provider
leave explicit historical/failed results, not an automatic fallback.

A per-request local lease prevents concurrent reruns from duplicating calls. A
retry of a completed request returns its existing record; preparing a new preview
explicitly starts a new request. Corpus evaluations are marked separately from
real-work learning labels and cannot activate a learner or adjudicate a model
choice. The same page now provides separate reviewed intake cases and mapping
decisions. Their data starts empty: neither the behaviour corpus nor the synthetic
ranking harness supplies real reviewed labels.

## Reviewed intake and mapping cases in the same workflow

For **Intake elicitation model**, record the exact stakeholder message, existing
intake domain, slot values before the message and independently reviewed expected
values afterward. Blank cells mean explicitly unanswered. Optional unsupported
requirements stay separate. Name the reviewer, date, rationale, source/request
family and reserved development or heldout split, then confirm the exact case.
These locally attributed, human-authored cases are not model-training labels or
authentication evidence. Correcting a case preserves its prior record and split;
relabeling the same message under another identifier is refused.

Select up to three reviewed cases and preview their exact inputs and selected
connection. Evaluation calls the existing `intake.next_turn` engine through the
selected bounded portal adapter, at most once per case. Expected answers and
review rationale are withheld from the model. The retained record contains the
raw response, request/response digests, observed slots, correct newly filled
slots, wrong-slot rate, elapsed time and explicit failures. The reader replays
the retained response through the canonical intake engine and recomputes the
score. Missing output slots cannot pass an all-null expectation. Scores compare
literal values; a person must adjudicate semantically equivalent wording. Cost
is `null` when this path has no measured per-case cost. Reusing the same completed
request returns its retained result; a new preview is an explicit retest.

For **Mapping candidate ranker**, retain the exact candidates a person reviewed,
their declared columns and kind match, the accepted table and an existing product
evidence file with its SHA256. The accepted table must supply every required
column. This records a technical label; it neither applies a mapping nor approves
source evidence. Evidence snapshots must remain available on the branch for new
training. Exporting these reviewed labels enables the same `rank.py --train`
entry point; it no longer ignores the supplied file.

The mapping evaluation needs at least 30 development cases across three source
families and ten heldout cases across two separate families. Entire families and
identical evidence hashes stay in one split. Repeated candidate sets are refused
even when their list order or case identifier changes. Family identity remains
a reviewer's explicit input; these checks do not prove complete semantic leakage
prevention. The existing logistic pairwise learner fits development cases only;
its frozen heldout order is compared with the existing deterministic mapping
candidate order. A fitted artifact is retained only when it exceeds that baseline.
The record reader independently reproduces fitted parameters, counts and every
heldout result from the frozen labels, using a bounded eight-entry process cache.
Missing, malformed, stale or insufficient labels never create an active artifact.

These records use the existing product branch folders:
`handoff/model_lifecycle/labels/` and `handoff/model_lifecycle/evaluations/`.
The mapping comparison has no activation action. Intake evaluation does not
adjudicate the fixed model choice or train LLM weights. To perform real evaluations,
reviewers still need to provide the actual accepted mapping evidence and an
independently reviewed intake corpus. No such human input is fabricated by setup
or by the regression fixtures.

## The benchmark that feeds the router

`bench/run_bench.py` runs the corpus across a model x effort matrix (temperature only where a
model still accepts it — Sonnet 5 / Opus 5 return 400; see `models.yaml`), bounded by `--plan`
estimates and a `--budget-usd` cap, with a flatters check (`--degrade`) that must move the numbers
before any row is informative. Its rows are the multi-model labels the router cannot otherwise get.
