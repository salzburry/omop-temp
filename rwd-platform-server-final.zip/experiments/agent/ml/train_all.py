"""Retrain every advisory learner from the governance exhaust and write ONE honest report.

    python experiments/agent/ml/train_all.py            # ledger -> models + ml/REPORT.md
    python experiments/agent/ml/train_all.py --min-n 30 # raise the honesty floor

WHAT IT PRODUCES (all under ml/, all gitignored except REPORT.md):
  training_ledger.jsonl   one row per eval transcript (features.build_ledger)
  router.json             the routing classifier, only if it beats its baseline at n >= min-n
  escalation.json         the escalation-need classifier, same rule
  calibration.json        critic reliability by confidence bucket (Wilson), from critic_scorecard
  REPORT.md               what trained, what refused to, why, and the numbers — the reviewer's page

THE RULE EVERY LEARNER OBEYS: below `--min-n` labelled rows, or when leave-one-out accuracy does
not beat the majority baseline, the learner writes NOTHING and the report says INSUFFICIENT DATA
with the counts. A model that ships on 12 rows is not advisory, it is noise with a filename. The
only consumer today is the critic (calibration.json -> second_vote_recommended); router.json and
escalation.json are written for review and are NOT consumed at runtime yet — no orchestrator route
reads them. A missing artifact is "no advice", so refusing to train is always safe.
"""
from __future__ import annotations

import argparse
import json
import math
import os
import sys
import time

HERE = os.path.dirname(os.path.abspath(__file__))
AGENT = os.path.dirname(HERE)
sys.path.insert(0, HERE)
sys.path.insert(0, AGENT)


def wilson(k, n, z=1.96):
    if n == 0:
        return (0.0, 0.0, 0.0)
    import calibrate
    lo, hi = calibrate.wilson(k, n, z)
    return (round(k / n, 3), round(lo, 3), round(hi, 3))


def train_binary(name, rows, feature_keys, label_key, min_n, out_path, lines, *, evaluation=None):
    """One LogReg with LOO accuracy vs majority baseline; ship only if it earns it."""
    import logreg  # noqa: PLC0415
    # rows are FLAT here (see flatten() in main): one dict of features + labels per transcript
    lab = [r for r in rows if r.get(label_key) is not None]
    X = [[float(r.get(k) or 0) for k in feature_keys] for r in lab]
    y = [int(bool(r[label_key])) for r in lab]
    n = len(y)
    classes = len(set(y))
    if evaluation is not None:
        evaluation.update(n=n, classes=classes, accepted=False, min_n=min_n,
                          method='leave-one-out', feature_names=list(feature_keys))
    if n < min_n or classes < 2:
        lines.append(f"- **{name}**: INSUFFICIENT DATA — {n} labelled row(s), {classes} class(es) "
                     f"(needs >= {min_n} and both classes). Nothing written.")
        if os.path.exists(out_path):
            os.remove(out_path)
        return None
    loo, base = logreg.loo_accuracy(feature_keys, X, y)    # returns (accuracy, majority baseline)
    if evaluation is not None:
        evaluation.update(accuracy=loo, majority_baseline=base)
    if loo <= base:
        lines.append(f"- **{name}**: n={n}, LOO accuracy {loo:.2f} does NOT beat the majority "
                     f"baseline {base:.2f}. Nothing written — the baseline is the better router.")
        if os.path.exists(out_path):
            os.remove(out_path)
        return None
    m = logreg.LogReg(feature_keys).fit(X, y)
    if evaluation is not None:
        evaluation['accepted'] = True
    m.save(out_path)
    lines.append(f"- **{name}**: n={n}, LOO accuracy {loo:.2f} vs baseline {base:.2f} — written to "
                 f"`{os.path.basename(out_path)}`. Top weights: "
                 f"{m.explain()[:4]}. ADVISORY: consumers log it, never act on it alone.")
    return m


import router
import escalation_net

REVIEWED_OBJECTIVES = {
    'router_needs_more': {'label': 'needs_more', 'features': router.REVIEWED_FEATS, 'phase': 'completed_check'},
    'escalation_need_classifier': {'label': 'should_escalate',
        'features': escalation_net.FEATS, 'phase': 'completed_check'},
    'critic_calibration': {'label': 'critic_correct', 'features': [], 'phase': 'completed_check'},
}


def calibration_buckets(rows, min_n=30):
    """Shared Wilson calculation for canonical scorecards and reviewed runs."""
    buckets = {}
    for row in rows:
        confidence = str(row['confidence'])
        bucket = buckets.setdefault(confidence, {'n': 0, 'correct': 0})
        bucket['n'] += 1
        bucket['correct'] += int(bool(row['correct']))
    result = {}
    for confidence, bucket in buckets.items():
        pw = wilson(bucket['correct'], bucket['n'])
        result[confidence] = {'n': bucket['n'], 'reliability': pw[0], 'lo': pw[1], 'hi': pw[2],
            'second_vote': pw[1] < .8 or bucket['n'] < min_n}
    return result


def train_reviewed(rows, objective_id):
    """The portal's reviewed evidence uses the existing trainer and acceptance rule.

    This function measures, never activates. Source execution receipts and the
    person's reviewed labels are checked by the caller against immutable files.
    Outcome labels and synthetic harness rows are never inferred here.
    """
    import tempfile
    import pathlib
    if objective_id not in REVIEWED_OBJECTIVES:
        raise ValueError('Choose a supported completed-check learning objective.')
    if not isinstance(rows, list) or len(rows) > 60:
        raise ValueError('Use at most 60 explicitly reviewed independent checks in one bounded evaluation.')
    spec = REVIEWED_OBJECTIVES[objective_id]
    seen_runs, seen_cases, flat = set(), set(), []
    for row in rows:
        if (not isinstance(row, dict) or type(row.get('label')) is not bool
                or not row.get('reviewed_by') or not row.get('reviewed_on')
                or not row.get('execution_receipt_sha256') or not row.get('run_sha256')
                or row.get('execution_mode') != 'native_selected_provider'
                or not row.get('case_sha256')):
            raise ValueError('Each training row needs an explicit human label and bound locally recorded execution evidence.')
        if row.get('run_id') in seen_runs or row['case_sha256'] in seen_cases:
            raise ValueError('Repeated runs of the same case cannot count as independent evaluation evidence.')
        seen_runs.add(row.get('run_id')); seen_cases.add(row['case_sha256'])
        values = row.get('features') or {}
        if any(type(values.get(key)) not in (int, float) or not math.isfinite(values[key]) for key in spec['features']):
            raise ValueError('The reviewed row has missing or non-finite checkpoint features.')
        flat.append({key: values[key] for key in spec['features']} | {spec['label']: row['label']})
    if objective_id == 'critic_calibration':
        if any(row.get('confidence') not in {'low', 'medium', 'high'} for row in rows):
            raise ValueError('Each critic review must name an actual recorded confidence bucket.')
        buckets = calibration_buckets([{'confidence': row['confidence'], 'correct': row['label']} for row in rows])
        accepted = bool(buckets) and all(bucket['n'] >= 30 for bucket in buckets.values())
        return {'objective_id': objective_id, 'evaluation': {'n': len(rows), 'accepted': accepted,
            'min_n': 30, 'method': 'Wilson reliability per observed confidence bucket', 'buckets': buckets},
            'artifact': {'min_n': 30, 'buckets': buckets} if accepted else None,
            'findings': ['Each observed bucket needs at least 30 independently reviewed critic verdicts; missing buckets always require another review.'],
            'phase': spec['phase'], 'label': spec['label'], 'notice': 'Measured local critic reliability; no scientific approval or model switch.'}
    lines, evaluation = [], {}
    with tempfile.TemporaryDirectory(prefix='reviewed-model-') as folder:
        path = pathlib.Path(folder) / 'model.json'
        model = train_binary(objective_id, flat, spec['features'], spec['label'], 30, str(path), lines,
                             evaluation=evaluation)
        artifact = json.loads(path.read_text(encoding='utf-8')) if model is not None else None
    return {'objective_id': objective_id, 'evaluation': evaluation, 'artifact': artifact,
            'findings': lines, 'phase': spec['phase'], 'label': spec['label'],
            'notice': 'Measured on explicitly reviewed local execution evidence. This does not activate a model, select a provider or approve a product.'}


def flatten(row: dict) -> dict:
    """The ledger row is {run_id, model, features:{...}, labels:{...}}; the learners want one flat
    dict. The first trainer read the top level, found the keys 'features' and 'labels', and
    trained on nothing (audit 5) — this is the one join, and the integration test drives it."""
    out = {"run_id": row.get("run_id"), "model": row.get("model")}
    out.update(row.get("features") or {})
    for k, v in (row.get("labels") or {}).items():
        out[k] = v
    return out


def calibration(min_n, lines):
    p = os.path.join(AGENT, "runs", "critic_scorecard.json")
    out = os.path.join(HERE, "calibration.json")
    if not os.path.exists(p):
        # NO EVIDENCE, NO ARTIFACT: a stale calibration.json kept advising after its scorecard was
        # gone (audit 5); the critic then falls back to second-vote-everything, the safe default
        if os.path.exists(out):
            os.remove(out)
        lines.append("- **critic calibration**: no critic_scorecard.json — run `evals/run.py --critic`. "
                     "Any previous calibration.json was removed; the critic recommends a second vote "
                     "for everything until evidence exists.")
        return None
    rows = json.load(open(p, encoding="utf-8"))
    cal = calibration_buckets([{'confidence': (r.get('verdict') or {}).get('confidence') or 'unstated',
                               'correct': bool(r.get('passed'))} for r in rows], min_n)
    json.dump({"as_of": time.strftime("%Y-%m-%d"), "min_n": min_n, "buckets": cal},
              open(out, "w", encoding="utf-8"), indent=1)
    total = sum(b["n"] for b in cal.values())
    lines.append(f"- **critic calibration**: {total} verdict(s) across {len(cal)} confidence "
                 f"bucket(s) -> `calibration.json`. Policy: second vote wherever the reliability "
                 f"lower bound < 0.80 or n < {min_n}"
                 + (" — at this n that is EVERY bucket, which is the correct policy for now." if total < min_n else "."))
    for conf, c in sorted(cal.items()):
        lines.append(f"    - {conf}: n={c['n']} reliability {c['reliability']} "
                     f"[{c['lo']},{c['hi']}] second_vote={c['second_vote']}")
    return cal


def main():
    ap = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    ap.add_argument("--min-n", type=int, default=30)
    a = ap.parse_args()
    import features  # noqa: PLC0415
    features.build_ledger()                       # rewrites training_ledger.jsonl; returns nothing
    ledger = os.path.join(HERE, "training_ledger.jsonl")
    raw_rows = [json.loads(l) for l in open(ledger, encoding="utf-8") if l.strip()]
    rows = [flatten(r) for r in raw_rows]
    lines = [f"# ML report — {time.strftime('%Y-%m-%d %H:%M')}", "",
             "> Every learner here is ADVISORY. Nothing below moves an authority boundary or "
             "scores its own acceptance; a missing artifact means 'no advice', which is always safe.",
             "", f"Ledger: {len(rows)} transcript(s) (features.py). Honesty floor: n >= {a.min_n}.", ""]
    # feature keys come from the FEATURE dict, never from the label dict or the identifiers
    fkeys = sorted({k for r in raw_rows for k in (r.get("features") or {}).keys()})
    # labels: needs_more = not passed (proxy until adjudication); escalated = outcome
    for r in rows:
        if r.get("passed") is not None:
            r["needs_more"] = not r["passed"]
    labelled = sum(1 for r in rows if r.get("passed") is not None)
    lines.append(f"Features ({len(fkeys)}): {fkeys}. Rows with a pass/fail label: {labelled} "
                 f"(labels come from the scorecard join; run the corpus to grow them).")
    lines.append("")
    train_binary("router (needs_more proxy)", rows, fkeys, "needs_more", a.min_n,
                 os.path.join(HERE, "router.json"), lines)
    train_binary("escalation need", rows, fkeys, "escalated", a.min_n,
                 os.path.join(HERE, "escalation.json"), lines)
    calibration(a.min_n, lines)
    lines += ["", "## What would change these numbers",
              "- adjudication sign-off turns the router's proxy label into the real one",
              "- a benchmark sweep across models (bench/run_bench.py) supplies the multi-model rows "
              "the router needs to learn 'Sonnet suffices / needs Opus'",
              "- more critic verdicts (evals/run.py --critic) tighten the calibration intervals", ""]
    rep = os.path.join(HERE, "REPORT.md")
    open(rep, "w", encoding="utf-8").write("\n".join(lines))
    print("\n".join(lines))
    print(f"\nwrote {rep}")


if __name__ == "__main__":
    main()
