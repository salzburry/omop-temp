"""ML item 6 — embedding retrieval over decisions/precedents/lessons. STAND-IN VECTORS.

Retrieval only, authority intact: a hit is a POINTER to a governed row, never an answer. The
vectors here are hashed character-trigram bags (deterministic, dependency-free) — a declared
stand-in until the coordination with the concept layer decides who owns real embeddings, so we
do not duplicate terminology vectors the teammate may already serve. The seam to swap: `vec()`.

    python experiments/agent/ml/embed.py --index
    python experiments/agent/ml/embed.py --query "time to next treatment after progression"
    python experiments/agent/ml/embed.py --demo   # synonym query lexical search misses
"""
from __future__ import annotations

import argparse
import hashlib
import io
import json
import math
import os
import re
from pathlib import Path
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
AGENT = os.path.dirname(HERE)
ROOT = os.path.dirname(os.path.dirname(AGENT))
DIM = 512

SOURCES = [
    ("decision", os.path.join(ROOT, "fixtures/oncology/prostate/202606/handoff/DECISIONS.md")),
    ("decision", os.path.join(ROOT, "fixtures/oncology/oc/202606/handoff/DECISIONS.md")),
    ("glossary", os.path.join(ROOT, "GLOSSARY.md")),
]


ALGO = "trigram-blake2b-v1"     # stamped into the index; a query refuses a mismatched index

# THE INDEX IS A CACHE, NOT A REPOSITORY FILE. A read-only tool must not write into the
# checkout (it built a 411 KB file there on first use — audit 5); it lives in the OS temp dir,
# overridable with RWD_EMBED_INDEX for a shared cache.
import tempfile  # noqa: E402
INDEX = os.environ.get("RWD_EMBED_INDEX") or os.path.join(tempfile.gettempdir(), "rwdp_agent",
                                                          "embed_index.jsonl")


def _dim_of(tri: str) -> int:
    # A STABLE DIGEST, NOT `hash()`: Python salts str hashes per process, so the same text
    # produced three different vectors in three processes and `--index`/`--query` compared
    # vectors from different feature spaces (second audit). blake2b is deterministic everywhere.
    import hashlib
    return int.from_bytes(hashlib.blake2b(tri.encode("utf-8"), digest_size=4).digest(),
                          "big") % DIM


def vec(text: str):
    """Hashed char-trigram bag, L2-normalised. THE SWAP SEAM for real embeddings."""
    v = [0.0] * DIM
    t = re.sub(r"\s+", " ", text.lower())
    for i in range(len(t) - 2):
        v[_dim_of(t[i:i + 3])] += 1.0
    n = math.sqrt(sum(x * x for x in v)) or 1.0
    return [x / n for x in v]


def cosine(a, b):
    return sum(x * y for x, y in zip(a, b))


def _learning():
    if AGENT not in sys.path:
        sys.path.insert(0, AGENT)
    import learn
    return learn


def provenance() -> dict:
    """What an index was built FROM: this checkout, the algorithm, and a digest of the source
    files' bytes. A query refuses an index whose provenance is not the current tree's — one
    global cache stamped only with the algorithm served another checkout's stale decisions
    (audit 6)."""
    h = hashlib.sha256()
    for kind, path in SOURCES:
        if os.path.exists(path):
            h.update(kind.encode("utf-8"))
            h.update(open(path, "rb").read())
    loop = _learning()
    active = loop.active_corrections(ROOT, include_scoped=True)
    return {"meta": True, "algo": ALGO, "root": os.path.realpath(ROOT), "sources_sha": h.hexdigest()[:16],
            "corrections_sha": loop.digest([{key: row[key] for key in ("id", "digest")} for row in active])}


def index():
    before = provenance()
    rows = []
    for kind, path in SOURCES:
        if not os.path.exists(path):
            continue
        text = io.open(path, encoding="utf-8", errors="replace").read()
        # decisions tables: one row per line carrying an id-like token; prose: per paragraph
        units = [l for l in text.split("\n") if l.strip().startswith("|")] or \
                [p for p in text.split("\n\n") if len(p.strip()) > 60]
        for u in units:
            u = u.strip()
            if len(u) < 40:
                continue
            rows.append({"kind": kind, "source": os.path.relpath(path, ROOT),
                         "text": u[:400], "v": vec(u), "algo": ALGO})
    loop = _learning()
    # This CLI query has no declared product scope. Only global active guidance
    # can enter its cache; source-specific lessons remain in scoped retrieval.
    for record in loop.active_corrections(ROOT):
        text = record["context"] + ": " + record["right"]
        rows.append({"kind": "lesson", "source": (loop.CORRECTIONS / (record["id"] + ".yaml")).as_posix(),
            "correction_id": record["id"], "correction_digest": record["digest"],
            "authority": "reviewed workflow guidance; never scientific evidence or approval",
            "text": text[:400], "v": vec(text), "algo": ALGO})
    if provenance() != before:
        raise RuntimeError("The source or correction library changed while indexing. Run --index again.")
    os.makedirs(os.path.dirname(INDEX), exist_ok=True)
    with open(INDEX, "w", encoding="utf-8") as fh:
        fh.write(json.dumps(before) + "\n")     # first line: whose rows these are
        for r in rows:
            fh.write(json.dumps(r) + "\n")
    print(f"indexed {len(rows)} units from {sum(1 for _, p in SOURCES if os.path.exists(p))} "
          f"source(s) -> {INDEX}")


def query(q, k=5, *, include_lessons=True):
    if not os.path.exists(INDEX):
        raise RuntimeError("no index — run --index first")
    qv = vec(q)
    rows = [json.loads(l) for l in open(INDEX, encoding="utf-8")]
    meta = rows[0] if rows and rows[0].get("meta") else None
    rows = [r for r in rows if not r.get("meta")]
    if meta != provenance():
        raise RuntimeError(f"index provenance {meta} is not this checkout's current sources "
                           f"{provenance()} — another checkout's or an older tree's rows would answer "
                           f"as if current; run --index again")
    stale = {r.get("algo") for r in rows} - {ALGO}
    if stale:
        raise RuntimeError(f"index was built with {sorted(map(str, stale))}, this query uses {ALGO} — "
                         f"different feature spaces compare as noise; run --index again")
    if not include_lessons:
        # Model tools retrieve corrections through the task-scoped canonical
        # loader. A shared cache cannot decide a paired evaluation's baseline.
        rows = [row for row in rows if row.get("kind") != "lesson" and not row.get("correction_id")]
    scored = sorted(rows, key=lambda r: -cosine(qv, r["v"]))[:k]
    print(f"query: {q!r}\nAUTHORITY: hits are pointers to governed rows — the row decides, "
          f"never the retriever.\n")
    for r in scored:
        print(f"[{cosine(qv, r['v']):.3f}] ({r['kind']} · {r['source']}) {r['text'][:150]}")


def demo():
    index()
    print("\n--- the synonym case lexical search misses: querying for a concept by its meaning,"
          "\n--- not its registered token ---\n")
    query("time until the next line of treatment begins after this one")


if __name__ == "__main__":
    ap = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    ap.add_argument("--index", action="store_true")
    ap.add_argument("--query")
    ap.add_argument("--demo", action="store_true")
    a = ap.parse_args()
    if a.demo:
        demo()
    elif a.index:
        index()
    elif a.query:
        query(a.query)
    else:
        ap.error("--index, --query, or --demo")
