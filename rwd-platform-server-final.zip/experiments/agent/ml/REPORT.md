# ML report — 2026-09-02 23:05

> Every learner here is ADVISORY. Nothing below moves an authority boundary or scores its own acceptance; a missing artifact means 'no advice', which is always safe.

Ledger: 80 transcript(s) (features.py). Honesty floor: n >= 30.

Features (11): ['authority_marker', 'calls', 'goal_len', 'in_tok', 'latency_s', 'n_tools', 'out_tok', 'steps', 'total_calls', 'trigger_hits', 'used_specialist']. Rows with a pass/fail label: 24 (labels come from the scorecard join; run the corpus to grow them).

- **router (needs_more proxy)**: INSUFFICIENT DATA — 24 labelled row(s), 1 class(es) (needs >= 30 and both classes). Nothing written.
- **escalation need**: n=80, LOO accuracy 0.66 vs baseline 0.65 — written to `escalation.json`. Top weights: [('latency_s', -1.287), ('authority_marker', 0.772), ('out_tok', -0.579), ('trigger_hits', 0.576)]. ADVISORY: consumers log it, never act on it alone.
- **critic calibration**: 1 verdict(s) across 1 confidence bucket(s) -> `calibration.json`. Policy: second vote wherever the reliability lower bound < 0.80 or n < 30 — at this n that is EVERY bucket, which is the correct policy for now.
    - unstated: n=1 reliability 1.0 [0.207,1.0] second_vote=True

## What would change these numbers
- adjudication sign-off turns the router's proxy label into the real one
- a benchmark sweep across models (bench/run_bench.py) supplies the multi-model rows the router needs to learn 'Sonnet suffices / needs Opus'
- more critic verdicts (evals/run.py --critic) tighten the calibration intervals
