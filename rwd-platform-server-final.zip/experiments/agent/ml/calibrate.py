"""ML item 4 — critic calibration curves: confidence -> observed reliability, with honest n.

Reads the critic scorecard (verdict + whether the case judged it correct), buckets by the
critic's own stated confidence, and reports reliability with Wilson intervals — then a
second-vote policy: buckets whose lower bound sits under the threshold earn a second critic
opinion; buckets above it do not. At n=5 the intervals are honest and wide; the tool says so
rather than smoothing.

    python experiments/agent/ml/calibrate.py            # from the real critic scorecard
    python experiments/agent/ml/calibrate.py --synthetic 300
"""
from __future__ import annotations

import argparse
import json
import math
import os
import random

HERE = os.path.dirname(os.path.abspath(__file__))
AGENT = os.path.dirname(HERE)
SCORECARD = os.path.join(AGENT, "runs", "critic_scorecard.json")


def wilson(k, n, z=1.96):
    if n == 0:
        return (0.0, 1.0)
    p = k / n
    den = 1 + z * z / n
    c = (p + z * z / (2 * n)) / den
    h = z * math.sqrt(p * (1 - p) / n + z * z / (4 * n * n)) / den
    return (max(0.0, c - h), min(1.0, c + h))


def report(rows, threshold=0.8):
    buckets = {}
    for r in rows:
        conf = (r.get("verdict") or {}).get("confidence") or "unstated"
        b = buckets.setdefault(conf, [0, 0])
        b[1] += 1
        b[0] += int(bool(r.get("passed")))
    print(f"{len(rows)} critic verdict(s) with case-level correctness labels")
    print(f"{'confidence':12} {'correct':>8} {'n':>4}  reliability  wilson 95%   second vote?")
    for conf in ("high", "medium", "low", "unstated"):
        if conf not in buckets:
            continue
        k, n = buckets[conf]
        lo, hi = wilson(k, n)
        second = "YES — lower bound under threshold" if lo < threshold else "no"
        print(f"{conf:12} {k:>8} {n:>4}  {k / n:>10.2f}  [{lo:.2f},{hi:.2f}]  {second}")
    total = sum(n for _, n in buckets.values())
    if total < 30:
        print(f"\nHONESTY BANNER: n={total} is far below what a calibration curve needs "
              f"(~30+/bucket). These intervals are the point — they are wide because the data "
              f"is thin, and the policy they imply (second-vote everything) is correct for now.")


def synthetic(n, seed=17):
    """Reviewer mode: verdicts generated with KNOWN per-confidence reliability
    (high=0.92, medium=0.75, low=0.55) — the report should recover those within its intervals."""
    rng = random.Random(seed)
    truth = {"high": 0.92, "medium": 0.75, "low": 0.55}
    rows = []
    for _ in range(n):
        conf = rng.choice(list(truth))
        rows.append({"verdict": {"confidence": conf},
                     "passed": rng.random() < truth[conf]})
    print(f"SYNTHETIC n={n} (true reliability: {truth})")
    report(rows)


if __name__ == "__main__":
    ap = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    ap.add_argument("--synthetic", type=int, metavar="N")
    a = ap.parse_args()
    if a.synthetic:
        synthetic(a.synthetic)
    else:
        if not os.path.exists(SCORECARD):
            raise SystemExit(f"no critic scorecard at {SCORECARD} — run evals/run.py --critic")
        report(json.load(open(SCORECARD, encoding="utf-8")))
