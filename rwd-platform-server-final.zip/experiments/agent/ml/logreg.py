"""A tiny, dependency-free logistic regression — the shared learner for the ML roadmap.

Pure stdlib on purpose: these models are ADVISORY rankers/routers over small governed-byproduct
datasets, and a reviewer must be able to read every line of the learner in one sitting. When the
data outgrows this (thousands of rows), promoting to sklearn is a deliberate act, not a default.
"""
from __future__ import annotations

import json
import math
import random


def _standardize(X):
    n, d = len(X), len(X[0])
    mu = [sum(r[j] for r in X) / n for j in range(d)]
    sd = [max(1e-9, math.sqrt(sum((r[j] - mu[j]) ** 2 for r in X) / n)) for j in range(d)]
    Z = [[(r[j] - mu[j]) / sd[j] for j in range(d)] for r in X]
    return Z, mu, sd


class LogReg:
    def __init__(self, feature_names):
        self.names = list(feature_names)
        self.w = [0.0] * len(self.names)
        self.b = 0.0
        self.mu = self.sd = None

    def _z(self, x):
        return [(v - m) / s for v, m, s in zip(x, self.mu, self.sd)]

    def predict_proba(self, x):
        z = self._z(x)
        s = self.b + sum(w * v for w, v in zip(self.w, z))
        return 1.0 / (1.0 + math.exp(-max(-30, min(30, s))))

    def fit(self, X, y, epochs=400, lr=0.1, l2=0.01, seed=7):
        Z, self.mu, self.sd = _standardize(X)
        rng = random.Random(seed)
        idx = list(range(len(Z)))
        for _ in range(epochs):
            rng.shuffle(idx)
            for i in idx:
                s = self.b + sum(w * v for w, v in zip(self.w, Z[i]))
                p = 1.0 / (1.0 + math.exp(-max(-30, min(30, s))))
                g = p - y[i]
                self.b -= lr * g
                self.w = [w - lr * (g * v + l2 * w) for w, v in zip(self.w, Z[i])]
        return self

    def save(self, path):
        json.dump({"names": self.names, "w": self.w, "b": self.b,
                   "mu": self.mu, "sd": self.sd}, open(path, "w", encoding="utf-8"), indent=1)

    @classmethod
    def load(cls, path):
        d = json.load(open(path, encoding="utf-8"))
        m = cls(d["names"])
        m.w, m.b, m.mu, m.sd = d["w"], d["b"], d["mu"], d["sd"]
        return m

    def explain(self):
        """Interpretability is the point: weight per named feature, sorted by influence."""
        pairs = sorted(zip(self.names, self.w), key=lambda t: -abs(t[1]))
        return [(n, round(w, 3)) for n, w in pairs]


def loo_accuracy(feature_names, X, y, **fit_kw):
    """Leave-one-out — the only honest estimate at these sample sizes. Returns (acc, majority)."""
    hits = 0
    for i in range(len(X)):
        Xt = X[:i] + X[i + 1:]
        yt = y[:i] + y[i + 1:]
        m = LogReg(feature_names).fit(Xt, yt, **fit_kw)
        hits += int((m.predict_proba(X[i]) >= 0.5) == bool(y[i]))
    majority = max(sum(y), len(y) - sum(y)) / len(y)
    return hits / len(X), majority
