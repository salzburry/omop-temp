"""Run transcripts -> feature rows -> the training ledger (ML items 1 and 3's raw material).

Every eval run already writes a transcript with §19 metrics; this sweeps them into
ml/training_ledger.jsonl — one row per run, features + the labels the corpus/adjudication supply.
The ledger GROWS as a byproduct of normal eval activity, which is the whole design: no annotation
campaign, just governance exhaust.
"""
from __future__ import annotations

import glob
import json
import os

HERE = os.path.dirname(os.path.abspath(__file__))
AGENT = os.path.dirname(HERE)
RUNS = os.path.join(AGENT, "runs")
LEDGER = os.path.join(HERE, "training_ledger.jsonl")

SPECIALISTS = {"mapping_evidence", "code_candidate", "diagnose"}
# words whose presence in a goal historically correlates with a person's question
TRIGGERS = ("approve", "decide", "decision", "equivalent", "equivalence", "window", "censor",
            "bind", "switch", "change", "sign", "release", "mean the same", "should")


def features_of(run: dict) -> dict:
    goal = run.get("goal", "")
    steps = run.get("steps", [])
    obs = [s for s in steps if s.get("kind") == "observation"]
    m = run.get("metrics") or {}
    return {
        "goal_len": len(goal),
        "trigger_hits": sum(goal.lower().count(t) for t in TRIGGERS),
        "steps": len(steps),
        "n_tools": len({s.get("tool") for s in obs}),
        "used_specialist": int(any(s.get("tool") in SPECIALISTS for s in obs)),
        "authority_marker": int(any(s.get("kind") == "authority_detected" for s in steps)),
        "calls": m.get("calls") or 0,
        "total_calls": m.get("total_calls") or m.get("calls") or 0,   # specialists included (audit 3)
        "in_tok": m.get("input_tokens") or 0,
        "out_tok": m.get("output_tokens") or 0,
        "latency_s": m.get("latency_s") or 0,
    }


def build_ledger() -> int:
    """Sweep runs + scorecards into the ledger. Labels: outcome (always), passed (when the
    scorecard knows the run), adjudicated (only after a person signs — absent until then)."""
    passed_by_run = {}
    for sc in ("scorecard.json",):
        p = os.path.join(RUNS, sc)
        if os.path.exists(p):
            for r in json.load(open(p, encoding="utf-8")):
                passed_by_run[r.get("run")] = r.get("passed")
    rows = []
    for f in sorted(f for f in glob.glob(os.path.join(RUNS, "*.json"))
                    if "scorecard" not in os.path.basename(f)):    # critic_/specialist_ too
        run = json.load(open(f, encoding="utf-8"))
        out = (run.get("outcome") or {}).get("status")
        if not out:
            continue
        rows.append({"run_id": run["run_id"], "model": run.get("model_id"),
                     "features": features_of(run),
                     "labels": {"outcome": out,
                                "escalated": int(out == "escalated"),
                                "passed": passed_by_run.get(run["run_id"]),
                                "adjudicated": None}})
    with open(LEDGER, "w", encoding="utf-8") as fh:
        for r in rows:
            fh.write(json.dumps(r) + "\n")
    return len(rows)


def load_ledger():
    if not os.path.exists(LEDGER):
        return []
    return [json.loads(l) for l in open(LEDGER, encoding="utf-8") if l.strip()]


if __name__ == "__main__":
    print(f"ledger: {build_ledger()} rows -> {LEDGER}")
