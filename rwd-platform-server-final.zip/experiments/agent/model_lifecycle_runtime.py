"""Local run provenance and completed-check consumers of canonical learners.

Checksums bind local files, not an authenticated identity. A checkout owner can
edit these records; nothing here is scientific approval or product release.
"""
from __future__ import annotations
import hashlib
import json
import math
from pathlib import Path
import re
import sys

ML = Path(__file__).resolve().parent / 'ml'
if str(ML) not in sys.path:
    sys.path.insert(0, str(ML))
import train_all
import features
import escalation_net

PACK = re.compile(r'products/[A-Za-z0-9_-]+/[A-Za-z0-9_-]+/\d{6}')
HEX = re.compile(r'[0-9a-f]{64}')
ID = re.compile(r'[0-9a-f]{24}')
CASE_PACK = re.compile(r'(?:products|fixtures|sandbox)/[A-Za-z0-9_-]+/[A-Za-z0-9_-]+/\d{6}')


class CaseScopeError(ValueError):
    """A retained case is unavailable in the reader's current scope."""


def validate_case_scope(record, pack, allowed_packs=None):
    """A product folder does not grant access to its retained reference runs."""
    allowed = {pack} if allowed_packs is None else set(allowed_packs)
    if pack not in allowed:
        raise CaseScopeError('This saved evaluation belongs to a product outside your current access.')
    cases = record.get('cases') or []
    scopes = {}
    for row in cases:
        names = row.get('packs') if isinstance(row, dict) else None
        case = row.get('case') if isinstance(row, dict) else None
        if (not isinstance(names, list) or not names or not isinstance(case, dict)
                or not isinstance(case.get('id'), str) or any(not isinstance(p, str) or not CASE_PACK.fullmatch(p) for p in names)):
            raise ValueError('The retained case has unreadable source scope.')
        if any(p not in allowed for p in names):
            raise CaseScopeError('This saved evaluation includes a reference or product outside your current access.')
        declared = set(names) | {pack}
        mentioned = set(CASE_PACK.findall(json.dumps(case, ensure_ascii=False).replace('\\\\', '/')))
        if not mentioned.issubset(declared):
            raise ValueError('The retained case text differs from its declared source scope.')
        scopes[case['id']] = (declared, case)
    runs = record.get('runs')
    if not isinstance(runs, list):
        raise ValueError('The retained case transcripts have an unreadable structure.')
    results = {r.get('run'): r.get('case') for r in record.get('results', []) if isinstance(r, dict) and r.get('run')}
    for entry in runs:
        run = entry.get('run') if isinstance(entry, dict) else None
        case_id = results.get(run.get('run_id')) if isinstance(run, dict) else None
        if (case_id not in scopes or entry.get('sha256') != digest(run)
                or run.get('primary_pack') != pack or run.get('goal') != scopes[case_id][1].get('goal')):
            raise ValueError('The retained transcript does not match its declared case and product.')
        mentioned = set(CASE_PACK.findall(json.dumps(run, ensure_ascii=False).replace('\\\\', '/')))
        if not mentioned.issubset(scopes[case_id][0]):
            raise ValueError('The retained transcript contains undeclared product or reference context.')


def digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, ensure_ascii=False, separators=(',', ':'), allow_nan=False).encode()).hexdigest()


def validate_paired_record(record, pack, allowed_packs=None):
    """A paired software check is scoped transcript evidence, never a learner."""
    if (record.get('objective_id') != 'governed_orchestration_model'
            or record.get('adjudicated') is not False or record.get('training_eligible') is not False
            or record.get('semantic_improvement') is not None
            or not isinstance(record.get('cases'), list) or not 1 <= len(record['cases']) <= 3
            or not isinstance(record.get('pairs'), list) or len(record['pairs']) != len(record['cases'])
            or not isinstance(record.get('correction'), dict) or not isinstance(record.get('connection'), dict)
            or not HEX.fullmatch(str(record.get('preview_digest', '')))):
        raise ValueError('The paired correction comparison has an unreadable structure.')
    runs, results = [], []
    for row, pair in zip(record['cases'], record['pairs']):
        if not isinstance(pair, dict) or pair.get('case') != row.get('case') or pair.get('packs') != row.get('packs'):
            raise ValueError('The paired output differs from its frozen case.')
        comparison = pair.get('comparison')
        if (not isinstance(comparison, dict) or type(comparison.get('valid_pair')) is not bool
                or comparison.get('semantic_improvement') is not None
                or not isinstance(comparison.get('inconclusive_reasons'), list)):
            raise ValueError('A paired observation cannot claim scientific or semantic approval.')
        for side in ('before', 'after'):
            arm = pair.get(side)
            result = arm.get('result') if isinstance(arm, dict) else None
            if (not isinstance(result, dict) or result.get('case') != row['case']['id']
                    or type(result.get('passed')) is not bool or not isinstance(result.get('checks'), dict)
                    or not isinstance(result.get('metrics'), dict) or not isinstance(arm.get('runs'), list)
                    or not isinstance(arm.get('delivery'), list) or not isinstance(arm.get('outputs'), list)):
                raise ValueError('A recorded comparison arm is malformed.')
            validate_case_scope({'cases': [row], 'runs': arm['runs'], 'results': [result]}, pack, allowed_packs)
            exact = [{'run_id': entry['run']['run_id'],
                      'decisions': [s for s in entry['run']['steps'] if s.get('kind') == 'decision'],
                      'outcome': entry['run']['outcome']} for entry in arm['runs']]
            if arm['outputs'] != exact:
                raise ValueError('The shown outputs differ from their exact recorded transcripts.')
            runs.extend(arm['runs'])
            results.append(result)
    if record.get('runs') != runs or record.get('results') != results:
        raise ValueError('The paired case rows do not match their canonical results and transcripts.')
    validate_case_scope(record, pack, allowed_packs)


def basis(run, count=None):
    steps = run.get('steps', [])
    if not isinstance(steps, list) or (count is not None and (type(count) is not int or not 0 <= count <= len(steps))):
        raise ValueError('The completed run transcript changed.')
    return {key: run.get(key) for key in ('run_id', 'goal', 'actor', 'model_id', 'metrics', 'outcome', 'primary_pack')} | {'steps': steps if count is None else steps[:count]}


def receipt(run, execution):
    value = dict(execution, version=1, producer='portal-session-model-v1', step_count=len(run['steps']), run_sha256=digest(basis(run)))
    return dict(value, sha256=digest(value))


def checked_run(run, pack):
    rec = run.get('execution') or {}
    if (not PACK.fullmatch(pack) or run.get('primary_pack') != pack or not isinstance(rec, dict)
            or rec.get('version') != 1 or rec.get('producer') != 'portal-session-model-v1'
            or rec.get('mode') != 'native_selected_provider' or rec.get('pack') != pack
            or type(rec.get('successful_calls')) is not int or not 1 <= rec['successful_calls'] <= 4
            or rec.get('provider') not in {'vscode', 'claude_code', 'anthropic'}
            or not HEX.fullmatch(str(rec.get('source_digest', '')))
            or not isinstance(rec.get('calls'), list) or len(rec['calls']) != rec['successful_calls']
            or any(not isinstance(call, dict) or set(call) != {'request', 'response'} or any(not HEX.fullmatch(str(v)) for v in call.values()) for call in rec['calls'])
            or rec.get('sha256') != digest({k: v for k, v in rec.items() if k != 'sha256'})):
        raise ValueError('This check has no collected selected-provider execution evidence. Run a new governed check with the selected assistant.')
    view = basis(run, rec.get('step_count'))
    if (rec['run_sha256'] != digest(view) or not isinstance(view.get('goal'), str)
            or not isinstance(view.get('outcome'), dict) or view['outcome'].get('status') not in {'done', 'escalated', 'model_stopped', 'exhausted', 'cost_stopped', 'time_stopped'}
            or not isinstance(view.get('metrics'), dict) or view['metrics'].get('total_calls', 0) < rec['successful_calls']):
        raise ValueError('The completed transcript or metrics no longer match the collected execution evidence.')
    # One product's branch must not receive another product's transcript.
    text = json.dumps(view, ensure_ascii=False).replace('\\\\', '/')
    mentioned = re.findall(r'(?:products|fixtures|sandbox)/[A-Za-z0-9_-]+/[A-Za-z0-9_-]+/\d{6}', text)
    if any(item != pack for item in mentioned):
        raise ValueError('This check contains another product context. Run a check scoped to this product before recording its review here.')
    import intake
    if intake.classify_ingress(text):
        raise ValueError('The recorded check needs a sanitized metadata-only review before it can become learning evidence.')
    return dict(view, execution=rec)


def run_features(run, objective_id):
    if objective_id == 'escalation_need_classifier':
        return dict(zip(escalation_net.FEATS, escalation_net.goal_features(run['goal'])))
    return features.features_of(run)


def critic_verdicts(run):
    """Use actual specialist output, not a user-entered confidence bucket."""
    recorded = (run.get('execution') or {}).get('critics', [])
    found = [c for c in recorded if isinstance(c, dict) and c.get('confidence') in {'low', 'medium', 'high'}
             and c.get('route') in {'pass_on', 'revise', 'human'} and type(c.get('falsified')) is bool]
    def walk(value):
        if isinstance(value, dict):
            critic = value.get('critic')
            if (isinstance(critic, dict) and critic.get('confidence') in {'low', 'medium', 'high'}
                    and critic.get('route') in {'pass_on', 'revise', 'human'} and type(critic.get('falsified')) is bool):
                found.append(critic)
            for child in value.values():
                walk(child)
        elif isinstance(value, list):
            for child in value:
                walk(child)
    for step in run.get('steps', []):
        if step.get('kind') == 'observation':
            value = step.get('output')
            if isinstance(value, str):
                try:
                    value = json.loads(value)
                except ValueError:
                    continue
            walk(value)
    return found


def safe_path(root, pack, kind, item_id=None):
    root = Path(root).resolve()
    if not PACK.fullmatch(pack) or kind not in {'labels', 'evaluations', 'activations'} or (item_id is not None and not ID.fullmatch(str(item_id))):
        raise ValueError('Choose a current product and saved learning record.')
    path = root / pack / 'handoff/model_lifecycle' / kind
    if item_id is not None:
        path /= item_id + '.json'
    if path.resolve() != path or not (root / pack).is_dir():
        raise ValueError('The learning record redirects outside this product.')
    return path


def validate_canonical_case_record(record, pack, allowed_packs=None):
    """Shared canonical validation for product records and private reference evaluations."""
    if (record.get('objective_id') not in {'governed_orchestration_model', 'intake_elicitation_model'}
            or not isinstance(record.get('results'), list) or not 1 <= len(record['results']) <= 3
            or not isinstance(record.get('cases'), list) or len(record['cases']) != len(record['results'])
            or not isinstance(record.get('connection'), dict) or record.get('adjudicated') is not False
            or record.get('training_eligible') is not False
            or any(not isinstance(row, dict) or not isinstance(row.get('case'), str)
                or type(row.get('passed')) is not bool or not isinstance(row.get('metrics'), dict)
                or not isinstance(row.get('checks'), dict) for row in record['results'])
            or any(not isinstance(row, dict) or not isinstance(row.get('case'), dict)
                or not isinstance(row['case'].get('goal'), str) or not isinstance(row.get('packs'), list) for row in record['cases'])
            or any(not isinstance(record['connection'].get(key), str) for key in ('provider', 'provider_id', 'model'))):
        raise ValueError('The canonical case evaluation has an unreadable structure.')
    validate_case_scope(record, pack, allowed_packs)


def read_record(root, pack, kind, item_id, *, allowed_packs=None):
    path = safe_path(root, pack, kind, item_id)
    if path.stat().st_size > 2_000_000:
        raise ValueError('The learning record is too large.')
    record = json.loads(path.read_text(encoding='utf-8'))
    if not isinstance(record, dict) or not isinstance(record.get('created_at'), str):
        raise ValueError('The learning record needs structured metadata.')
    payload = {k: v for k, v in record.items() if k not in {'id', 'sha256'}}
    if (record.get('sha256') != digest(payload) or record.get('id') != item_id
            or item_id != record['sha256'][:24] or record.get('pack') != pack or record.get('kind') != kind):
        raise ValueError('The learning record changed or belongs to another product.')
    if record.get('record_type') in {'reviewed_intake_case', 'reviewed_mapping_label', 'intake_case_evaluation', 'reviewed_mapping_evaluation'}:
        validate_reviewed_case_record(record, pack, kind, allowed_packs=allowed_packs)
        return record
    if kind == 'evaluations' and record.get('record_type') == 'correction_paired_evaluation':
        validate_paired_record(record, pack, allowed_packs)
        return record
    if kind == 'evaluations' and record.get('record_type') == 'canonical_case_evaluation':
        validate_canonical_case_record(record, pack, allowed_packs)
        return record
    if record.get('objective_id') not in train_all.REVIEWED_OBJECTIVES:
        raise ValueError('The record does not name a supported canonical learner.')
    if kind == 'labels':
        training_row(record, pack)
    elif kind == 'evaluations':
        measured = record.get('measurement')
        refs = record.get('labels')
        if (not isinstance(measured, dict) or measured.get('objective_id') != record['objective_id']
                or not isinstance(measured.get('evaluation'), dict)
                or type(measured['evaluation'].get('accepted')) is not bool
                or not isinstance(measured.get('findings'), list)
                or any(not isinstance(line, str) for line in measured['findings'])
                or not isinstance(refs, list) or len(refs) > 60
                or any(not isinstance(ref, dict) or not ID.fullmatch(str(ref.get('id', '')))
                    or not HEX.fullmatch(str(ref.get('sha256', ''))) for ref in refs)
                or any(not HEX.fullmatch(str(record.get(key, ''))) for key in ('code_digest', 'rows_digest'))):
            raise ValueError('The evaluation record has an unreadable structure.')
    elif (type(record.get('enabled')) is not bool or not ID.fullmatch(str(record.get('evaluation_id', '')))
            or not HEX.fullmatch(str(record.get('evaluation_sha256', ''))) or not isinstance(record.get('verdict'), dict)):
        raise ValueError('The activation record has an unreadable structure.')
    return record


def validate_reviewed_case_record(record, pack, kind, *, allowed_packs=None):
    if allowed_packs is not None and pack not in allowed_packs:
        raise CaseScopeError('The reviewed learning record belongs to another product scope.')
    import intake_cases
    import rank
    rtype = record.get('record_type')
    if kind == 'labels' and rtype == 'reviewed_intake_case':
        intake_cases.validate_record(record, pack)
    elif kind == 'labels' and rtype == 'reviewed_mapping_label':
        rank.validate_label(record, pack)
    elif kind == 'evaluations' and rtype == 'intake_case_evaluation':
        intake_cases.validate_evaluation(record, pack)
    elif kind == 'evaluations' and rtype == 'reviewed_mapping_evaluation':
        rows, measured = record.get('cases'), record.get('measurement')
        if (record.get('objective_id') != rank.OBJECTIVE or not isinstance(rows, list) or len(rows) > rank.MAX_LABELS
                or not isinstance(measured, dict) or measured.get('rows_digest') != rank.digest(rows)
                or measured.get('activation') is not False or record.get('training_eligible') is not False
                or measured.get('status') not in {'insufficient_data', 'measured'}):
            raise ValueError('The mapping measurement differs from its exact reviewed labels.')
        for row in rows:
            rank.validate_label(row, pack)
        rank.verify_measurement(rows, measured)
    else:
        raise ValueError('Reviewed cases and mechanical evaluations cannot supply activation records.')


def code_digest(root):
    root = Path(root)
    paths = ['governance/OBJECTIVES.yaml', 'experiments/agent/ml/train_all.py',
             'experiments/agent/ml/logreg.py', 'experiments/agent/ml/features.py',
             'experiments/agent/ml/router.py',
             'experiments/agent/ml/calibrate.py',
             'experiments/agent/ml/escalation_net.py', 'experiments/agent/control_plane.py',
             'experiments/agent/model_lifecycle_runtime.py']
    return digest({p: hashlib.sha256((root / p).read_bytes()).hexdigest() for p in paths})


def training_row(record, pack):
    source = checked_run(record['source'], pack)
    oid = record['objective_id']
    if oid not in train_all.REVIEWED_OBJECTIVES or type(record.get('label')) is not bool:
        raise ValueError('A reviewed binary label is required.')
    if oid == 'router_needs_more':
        other = checked_run(record.get('comparison') or {}, pack)
        if (other['run_id'] == source['run_id'] or other['goal'].strip() != source['goal'].strip()
                or other['execution']['source_digest'] != source['execution']['source_digest']
                or (other['execution']['provider'], other['model_id']) == (source['execution']['provider'], source['model_id'])):
            raise ValueError('Router review needs the same case and inputs checked with two different selected models.')
    import person_rules
    import control_plane
    if (person_rules.unstated(record.get('reviewed_by')) or person_rules.not_a_person(record.get('reviewed_by'))
            or control_plane._bad_date(record.get('reviewed_on')) or not str(record.get('rationale') or '').strip()
            or record.get('confirmed_real_work') is not True):
        raise ValueError('The check needs a person, review date, rationale and explicit real-work review.')
    row = {k: record[k] for k in ('label', 'reviewed_by', 'reviewed_on')} | {
        'run_id': source['run_id'], 'execution_mode': source['execution']['mode'],
        'execution_receipt_sha256': source['execution']['sha256'], 'run_sha256': source['execution']['run_sha256'],
        'case_sha256': digest(source['goal'].strip()), 'features': run_features(source, oid)}
    if oid == 'critic_calibration':
        critics = critic_verdicts(source)
        if len(critics) != 1:
            raise ValueError('Calibration review needs one unambiguous recorded critic verdict. Run a single specialist check, then review that verdict.')
        row['confidence'] = critics[0]['confidence']
    return row


def verified_evaluation(root, pack, evaluation, *, recompute=False):
    if evaluation.get('code_digest') != code_digest(root):
        raise ValueError('The objective or trainer changed. Evaluate the current reviewed checks again.')
    rows = []
    latest = {}
    for path in safe_path(root, pack, 'labels').glob('*.json'):
        record = read_record(root, pack, 'labels', path.stem)
        if record['objective_id'] == evaluation['objective_id']:
            run_id = record['source']['run_id']
            if run_id not in latest or record['created_at'] > latest[run_id]['created_at']:
                latest[run_id] = record
    current_refs = [{'id': r['id'], 'sha256': r['sha256']} for r in sorted(latest.values(), key=lambda r: r['id'])]
    if current_refs != evaluation['labels']:
        raise ValueError('The current review labels differ from this evaluated version.')
    for ref in evaluation['labels']:
        label = read_record(root, pack, 'labels', ref['id'])
        if label['sha256'] != ref['sha256'] or label['objective_id'] != evaluation['objective_id']:
            raise ValueError('The measured review labels changed.')
        rows.append(training_row(label, pack))
    if digest(rows) != evaluation['rows_digest']:
        raise ValueError('The measured run features or review labels changed.')
    measured = evaluation['measurement']
    if recompute and digest(train_all.train_reviewed(rows, evaluation['objective_id'])) != digest(measured):
        raise ValueError('The model artifact does not match a fresh canonical evaluation of these checks.')
    if measured.get('evaluation', {}).get('accepted') is not True or not measured.get('artifact'):
        raise ValueError('The existing trainer did not accept this measured version.')
    return measured


def continuations(root, pack, run):
    """Only after completion: no future features, provider changes or gate changes."""
    checked = checked_run(run, pack)
    import control_plane
    import logreg
    out = []
    directory = safe_path(root, pack, 'activations')
    try:
        paths = list(directory.glob('*.json'))
        if len(paths) > 300:
            return []
        records = [read_record(root, pack, 'activations', p.stem) for p in paths]
    except (ValueError, OSError, KeyError, TypeError):
        return []
    records.sort(key=lambda r: r['created_at'], reverse=True)
    seen = set()
    for activation in records:
        oid = activation['objective_id']
        if oid in seen:
            continue
        seen.add(oid)
        if activation.get('enabled') is not True:
            continue
        try:
            if control_plane.validate_local_activation(activation, root=root):
                continue
            evaluation = read_record(root, pack, 'evaluations', activation['evaluation_id'])
            if evaluation['sha256'] != activation['evaluation_sha256']:
                continue
            measured = verified_evaluation(root, pack, evaluation)
            if oid == 'critic_calibration':
                critics = critic_verdicts(checked)
                buckets = measured['artifact'].get('buckets', {})
                if critics and any(buckets.get(c['confidence'], {}).get('second_vote', True) for c in critics):
                    out.append({'route': 'specialist_assistant', 'params': {'pack': pack, 'run_id': checked['run_id'], 'kind': 'validation'},
                        'reason': 'Request another review of this critic verdict', 'model_version': evaluation['id'],
                        'probability': None, 'objective_id': oid})
                continue
            art = measured['artifact']; names = train_all.REVIEWED_OBJECTIVES[oid]['features']
            if (art['names'] != names or any(len(art[k]) != len(names) for k in ('w', 'mu', 'sd'))
                    or any(type(x) not in (int, float) or not math.isfinite(x) for k in ('w', 'mu', 'sd') for x in art[k])
                    or type(art['b']) not in (int, float) or not math.isfinite(art['b']) or any(x <= 0 for x in art['sd'])):
                continue
            model = logreg.LogReg(names)
            model.w, model.b, model.mu, model.sd = art['w'], art['b'], art['mu'], art['sd']
            values = run_features(checked, oid)
            probability = model.predict_proba([values[k] for k in names])
            if probability >= .5:
                route = 'questions' if oid == 'escalation_need_classifier' else 'governed_check'
                params = {'pack': pack, 'run_id': checked['run_id']}
                if route == 'governed_check':
                    params.update(goal=checked['goal'], objective_id=oid, evaluation_id=evaluation['id'])
                out.append({'route': route, 'params': params,
                    'reason': 'Review this check with a person' if route == 'questions' else 'Compare this completed check with another selected model',
                    'model_version': evaluation['id'], 'probability': round(probability, 4), 'objective_id': oid})
        except (ValueError, OSError, KeyError, TypeError):
            continue
    return out
