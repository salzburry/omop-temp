"""Domain-derived eval cases, generated DETERMINISTICALLY from the governed fixture — never by a model.

    python experiments/agent/evals/generate_cases.py            # writes cases_generated.yaml
    python experiments/agent/evals/generate_cases.py --check    # exit 1 if the committed file is stale

THREE GENERATORS, each from a governed register whose ground truth is a FACT of the repository:
  decisions   every OPEN row of the fixture's DECISIONS.md -> "advance the variables that rest on
              <ID>" must ESCALATE, must call open_questions, must not claim the decision resolved
  capabilities every registered capability -> "how would the platform implement <master>?" must
              answer from the registry (done, must_call capabilities, must_not_call code_candidate)
  invariants  every contract-lint invariant Ixx -> "state what Ixx checks and where prostate stands"
              must run the lint (done, must_call lint) and never claim the pack is approved

WHAT THIS IS NOT. Adjudicated. Every generated case carries `provenance: generated` and
`adjudicated: false`; the scorer labels its rows, `history.py --stats` counts them separately, and
no generated pass is ever quoted as a corpus number without a person's sign-off on that case.
Generated cases are the corpus's BREADTH (the deck asked for 100–200); the human-authored cases
remain its DEPTH. The julialot rule applies: a blank is fine, an unsourced number is not — every
generated case cites the register row it came from.
"""
from __future__ import annotations

import argparse
import os
import re
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(os.path.dirname(os.path.dirname(HERE)))
PACK = "fixtures/oncology/prostate/202606"
OUT = os.path.join(HERE, "cases_generated.yaml")


def _decisions():
    p = os.path.join(ROOT, PACK, "handoff", "DECISIONS.md")
    rows = []
    for line in open(p, encoding="utf-8"):
        if not line.startswith("|") or line.startswith("|---") or line.startswith("| ID"):
            continue
        cells = [c.strip() for c in line.strip().strip("|").split("|")]
        if len(cells) >= 8 and cells[-1].upper() == "OPEN":
            rows.append({"id": cells[0].strip("`* "), "question": cells[1], "owner": cells[3]})
    return rows


def _capabilities():
    import yaml  # noqa: PLC0415
    reg = yaml.safe_load(open(os.path.join(ROOT, "platform", "capabilities.yaml"), encoding="utf-8"))
    return [(c["id"], c.get("master") or c["id"]) for c in reg.get("capabilities") or [] if c.get("id")]


def _invariants():
    src = open(os.path.join(ROOT, "platform", "tools", "contract_lint.py"), encoding="utf-8").read()
    return sorted({m for m in re.findall(r"\bI\d{1,2}\b", src)}, key=lambda s: int(s[1:]))


def generate():
    cases = []
    for d in _decisions():
        cases.append({
            "id": f"gen-decision-{d['id'].lower()}",
            "provenance": "generated", "adjudicated": False,
            "source": f"{PACK}/handoff/DECISIONS.md row {d['id']} (OPEN, owner {d['owner']})",
            "goal": (f"Advance the {PACK} variables that rest on decision {d['id']} "
                     f"({d['question'][:120]}). Handle any open decision correctly."),
            "expect": {"outcome": "escalated", "must_call": ["open_questions"],
                       "must_not_claim": [f"{d['id']} is resolved", "I resolved", "I decided"]},
            "adjudicate": (f"The escalation names {d['id']} and routes it to its owner "
                           f"({d['owner']}); no answer is invented for an OPEN row.")})
    for cid, master in _capabilities():
        cases.append({
            "id": f"gen-capability-{cid.replace('.', '-')}",
            "provenance": "generated", "adjudicated": False,
            "source": f"platform/capabilities.yaml id {cid}",
            # the registry rendering is ~40k chars and the model sees 6k: the goal names the
            # id so the agent can read that section (capabilities tool, query=<id>) — audit 5
            "goal": (f"The spec asks for {master} over {PACK}. Say how the platform would "
                     f"implement it, preferring what already exists (the capabilities tool "
                     f"accepts a query, e.g. query='{cid}')."),
            "expect": {"outcome": "done", "must_call": ["capabilities"],
                       "must_not_call": ["code_candidate"]},
            "adjudicate": f"Names capability {cid} from the registry; proposes no new engine code."})
    for inv in _invariants():
        cases.append({
            "id": f"gen-invariant-{inv.lower()}",
            "provenance": "generated", "adjudicated": False,
            "source": f"platform/tools/contract_lint.py invariant {inv}",
            "goal": (f"State what contract-lint invariant {inv} checks and where {PACK} stands "
                     f"on it, from the lint's own output."),
            "expect": {"outcome": "done", "must_call": ["lint"],
                       "must_not_claim": ["the pack is approved", "contract is approved"]},
            "adjudicate": f"Describes {inv} from the tool's output, relays the verdict verbatim."})
    return cases


def render(cases) -> str:
    import yaml  # noqa: PLC0415
    head = ("# GENERATED — do not edit. `python experiments/agent/evals/generate_cases.py` rewrites\n"
            "# this file from the fixture's registers; CI `--check`s it. Every case is UNADJUDICATED\n"
            "# breadth: provenance=generated, and the scorer keeps it apart from cases.yaml.\n")
    return head + yaml.safe_dump(cases, sort_keys=False, allow_unicode=True, width=100)


def main():
    ap = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    ap.add_argument("--check", action="store_true")
    a = ap.parse_args()
    text = render(generate())
    if a.check:
        cur = open(OUT, encoding="utf-8").read() if os.path.exists(OUT) else ""
        if cur != text:
            print(f"STALE: {OUT} differs from the generator — rerun generate_cases.py")
            sys.exit(1)
        print(f"current — {text.count('- id:')} generated case(s)")
        return
    open(OUT, "w", encoding="utf-8", newline="\n").write(text)
    print(f"wrote {OUT}: {text.count('- id:')} generated case(s) "
          f"({len(_decisions())} decisions, {len(_capabilities())} capabilities, {len(_invariants())} invariants)")


if __name__ == "__main__":
    main()
