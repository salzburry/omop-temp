"""Regression-of-regressions and corpus composition for the eval corpus.

    python experiments/agent/evals/history.py --stats             # what the corpus is made of
    python experiments/agent/evals/history.py --flips             # which cases changed verdict between the last two sweeps
    python experiments/agent/evals/history.py --flips A.json B.json

WHY. A scorecard is a point; the corpus's value is in the DIFFERENCE between points: a case that
passed yesterday and fails today is the finding, and one that fails today and passed yesterday is
the second finding (a rubric loosened, or a model changed). `--stats` says how much of the corpus
is human-authored vs generated and how much is adjudicated — the number the benchmark rule cares
about, since only adjudicated passes support a claim.
"""
from __future__ import annotations

import argparse
import json
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
AGENT = os.path.dirname(HERE)
RUNS = os.path.join(AGENT, "runs")


def _cases():
    import yaml  # noqa: PLC0415
    out = []
    for name in ("cases.yaml", "cases_generated.yaml", "cases_science_regressions.yaml", "specialist_cases.yaml"):
        p = os.path.join(HERE, name)
        if os.path.exists(p):
            with open(p, encoding="utf-8") as fh:
                for c in yaml.safe_load(fh) or []:
                    c.setdefault("provenance", "human" if name == "cases.yaml" else name.split("_")[0])
                    out.append(c)
    sys.path.insert(0, AGENT) if AGENT not in sys.path else None
    import learn
    from pathlib import Path
    out.extend(learn.correction_cases(Path(AGENT).parents[1]))
    return out


def stats():
    cases = _cases()
    by = {}
    for c in cases:
        by.setdefault(c["provenance"], []).append(c)
    adj = os.path.join(HERE, "ADJUDICATION.md")
    signed = False
    if os.path.exists(adj):
        import re  # noqa: PLC0415
        # signed iff the sign-off line carries a value that is not a comment placeholder
        for line in open(adj, encoding="utf-8"):
            m = re.match(r"^adjudicated_by:\s*(.*)$", line.strip())
            if m:
                val = m.group(1).strip()
                signed = bool(val) and not val.startswith("#") and val.upper() not in ("TBD", "<NAME>")
                break
    print(f"corpus: {len(cases)} case(s)")
    for k, v in sorted(by.items()):
        esc = sum(1 for c in v if "escalated" in str((c.get("expect") or {}).get("outcome")))
        print(f"  {k:12} {len(v):4}  (expect-escalation {esc}, expect-done {len(v) - esc})")
    # ASCII only on this line: a redirected Windows child decoded it under the console code page
    print(f"adjudication sign-off present: {'yes' if signed else 'NO -- every pass is mechanical'}")
    hist = os.path.join(RUNS, "scorecard_history.jsonl")
    if os.path.exists(hist):
        rows = [json.loads(l) for l in open(hist, encoding="utf-8") if l.strip()]
        print(f"history: {len(rows)} scored row(s) across sweeps")


def flips(a=None, b=None):
    hist = os.path.join(RUNS, "scorecard_history.jsonl")
    if a and b:
        A = {r["case"]: r for r in json.load(open(a, encoding="utf-8"))}
        B = {r["case"]: r for r in json.load(open(b, encoding="utf-8"))}
    else:
        if not os.path.exists(hist):
            raise SystemExit("no scorecard history yet")
        rows = [json.loads(l) for l in open(hist, encoding="utf-8") if l.strip()]
        # the last two DISTINCT runs per case: a rescore is a re-read of an old transcript, not
        # a new run, and the same run scored twice is one entry (audit 7: two rescores of the
        # failing run made "the last two" identical and a real PASS -> FAIL disappeared)
        per = {}
        for r in rows:
            if r.get("rescored"):
                continue
            lst = per.setdefault(r["case"], [])
            if lst and lst[-1].get("run") == r.get("run"):
                lst[-1] = r
            else:
                lst.append(r)
        A = {c: v[-2] for c, v in per.items() if len(v) >= 2}
        B = {c: v[-1] for c, v in per.items() if len(v) >= 2}
    down = [c for c in A if A[c]["passed"] and not B.get(c, {}).get("passed", True)]
    up = [c for c in A if not A[c]["passed"] and B.get(c, {}).get("passed", False)]
    print(f"compared {len(A)} case(s)")
    print(f"PASS -> FAIL ({len(down)}): {down or '-'}   <- the finding")
    print(f"FAIL -> PASS ({len(up)}): {up or '-'}   <- a rubric loosened, a model changed, or a fix landed: say which")
    return down, up


if __name__ == "__main__":
    ap = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    ap.add_argument("--stats", action="store_true")
    ap.add_argument("--flips", nargs="*", help="two scorecard paths, or none for the last two sweeps")
    a = ap.parse_args()
    if a.stats:
        stats()
    elif a.flips is not None:
        flips(*(a.flips[:2] if len(a.flips) == 2 else (None, None)))
    else:
        ap.error("--stats or --flips")
