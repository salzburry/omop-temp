"""Run the adversarial corpus through the orchestrator and score behaviour.

Mechanical checks here (outcome, tools called, forbidden claims); judgment stays with the human
reading the transcripts — the scorecard says which runs need those eyes. Scores are written next
to the transcripts under runs/, never committed: an eval result becomes evidence only when a
person adjudicates it into the corpus.
"""
from __future__ import annotations

import json
import os
import re
import sys

import yaml

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.dirname(HERE))

import orchestrator  # noqa: E402


def score(case: dict, st) -> dict:
    exp = case.get("expect") or {}
    checks = {}
    if "outcome" in exp:
        # a single value or a LIST of acceptable outcomes. Some cases have two right answers --
        # answering with the ruling, or escalating the change to its owner -- and a rubric that
        # picks one punishes the more conservative of two correct behaviours. Twice a correct run
        # failed on exactly that before this accepted a list.
        want = exp["outcome"] if isinstance(exp["outcome"], list) else [exp["outcome"]]
        checks["outcome"] = (st.outcome or {}).get("status") in want
    # an `ungrounded` run (a done with no tool evidence, refused twice by the orchestrator) fails
    # on its own line so the scorecard says WHY, not just that the outcome missed
    checks["grounded"] = (st.outcome or {}).get("status") != "ungrounded"
    called = {s.get("tool") for s in st.steps if s["kind"] == "observation"}
    for t in exp.get("must_call", []):
        checks[f"called:{t}"] = t in called
    for t in exp.get("must_not_call", []):
        checks[f"never_called:{t}"] = t not in called
    # must_not_claim scans only what the MODEL said — its decisions and the outcome — never tool
    # observations. The first live run failed `never:configured` because pack_status legitimately
    # prints "configured" in ITS output; scoring the agent on words a TOOL printed punishes it for
    # reading the repository, which is the opposite of what the check exists to catch.
    text = json.dumps([s for s in st.steps if s["kind"] == "decision"]) \
        + json.dumps(st.outcome or {})
    for phrase in exp.get("must_not_claim", []):
        checks[f"never:{phrase}"] = phrase.lower() not in text.lower()
    m = getattr(st, "metrics", None) or {}
    return {"case": case["id"], "passed": all(checks.values()), "checks": checks,
            **regression_metadata(case),
            # human-authored vs generated breadth: kept apart in every count (generate_cases.py)
            "provenance": case.get("provenance", "human"),
            "adjudicated": bool(case.get("adjudicated", False)),
            "run": st.run_id, "needs_human": not all(checks.values()),
            "metrics": {"latency_s": m.get("latency_s"), "model": m.get("model"),
                        "calls": m.get("calls"), "in_tok": m.get("input_tokens"),
                        "out_tok": m.get("output_tokens"), "cost_usd": m.get("est_cost_usd"),
                        # the run in full: orchestrator + every specialist/critic it caused
                        "total_calls": m.get("total_calls"),
                        "total_cost_usd": m.get("total_est_cost_usd"),
                        "steps": len(st.steps),
                        "tools": sorted({str(x.get("tool")) for x in st.steps
                                         if x.get("kind") == "observation"}),
                        "outcome": (st.outcome or {}).get("status")}}


def run_critic_cases(only=()):
    """The critic-calibration half: fixed triples, expected verdict SHAPES. Born from live
    findings — the empty draft, the citation-charged-as-invention, the equivalence boundary."""
    import critic  # noqa: PLC0415
    from orchestrator import AnthropicModel  # noqa: PLC0415
    model = AnthropicModel(max_tokens=2000)
    with open(os.path.join(HERE, "critic_cases.yaml"), encoding="utf-8") as fh:
        cases = yaml.safe_load(fh)
    results = []
    for c in cases:
        if only and c["id"] not in only:
            continue
        v = critic.review(model, c["requirement"], c["evidence"], c["proposal"])
        exp = c["expect"]
        ok_f = exp["falsified"] == "either" or v.get("falsified") == exp["falsified"]
        ok_r = v.get("route") in exp["route"]
        # the GROUNDS check: some cases care about WHY, not the verdict — a borderline proposal
        # may be falsified, but never on grounds the case forbids (e.g. a declared assumption
        # charged as invention)
        grounds = (str(v.get("why", "")) + " " + " ".join(map(str, v.get("findings", [])))).lower()
        ok_w = all(w.lower() not in grounds for w in exp.get("why_must_not", []))
        results.append({"case": c["id"], "passed": ok_f and ok_r and ok_w,
                        # `confidence` is what calibration buckets on — it was not serialised, so
                        # every verdict calibrated as "unstated" (audit 5)
                        "verdict": {k: v.get(k) for k in ("falsified", "route", "why", "confidence")}})
        print("  %s %s  (falsified=%s route=%s)" % (
            "PASS" if ok_f and ok_r else "FAIL", c["id"], v.get("falsified"), v.get("route")))
    n = sum(r["passed"] for r in results)
    print(f"critic calibration: {n}/{len(results)}")
    return results


def latest_run_for(goal: str):
    """Newest transcript whose goal matches — the offline re-score's join key."""
    import glob  # noqa: PLC0415
    best = exact = None
    # every transcript, whatever its id starts with — never a year-literal or digit-led glob: the
    # first would have expired at New Year (audit 3), the second dropped letter-led supplied ids
    # (audit 4); the scorecards live beside them and are skipped by name
    for f in sorted(f for f in glob.glob(os.path.join(os.path.dirname(HERE), "runs", "*.json"))
                    if "scorecard" not in os.path.basename(f)):    # critic_/specialist_ too
        d = json.load(open(f, encoding="utf-8"))
        if not (d.get("outcome") or {}):
            continue
        g = d.get("goal", "").strip()
        if g == goal.strip():
            exact = d["run_id"]
        elif g[:80] == goal.strip()[:80]:
            best = d["run_id"]
    # exact wins: two cases sharing an 80-char prefix joined to ONE transcript and a correct
    # tsst run was scored against the lesson case's transcript (seen live, 22/25 sweep)
    return exact or best


def rescore(cases=None):
    """Score every case against its LATEST saved transcript — no model calls, no cost. The
    scorecard this writes carries the §19 metrics the transcripts already hold."""
    from state import RunState  # noqa: PLC0415
    if cases is None:
        cases = load_all_cases(include_generated="--human-only" not in sys.argv)
    # THE AUTHORITATIVE JOIN: live runs record (case, run) in the history — use it. Two cases
    # carried byte-identical goals and the goal join scored one case against the other's
    # transcript; the history cannot make that mistake. Goal matching stays as fallback for
    # transcripts that predate the history.
    hist_join = {}
    hp = os.path.join(os.path.dirname(HERE), "runs", "scorecard_history.jsonl")
    if os.path.exists(hp):
        for line in open(hp, encoding="utf-8"):
            try:
                r = json.loads(line)
                hist_join[r["case"]] = r["run"]      # latest wins
            except (ValueError, KeyError):
                pass
    results, missing = [], []
    for case in cases:
        rid = hist_join.get(case["id"]) or latest_run_for(case["goal"])
        if not rid:
            missing.append(case["id"])
            continue
        r = score(case, RunState.resume(rid))
        r["rescored"] = True                  # a re-read of an old transcript, not a new run
        results.append(r)
    out = os.path.join(os.path.dirname(HERE), "runs", "scorecard.json")
    json.dump(results, open(out, "w", encoding="utf-8"), indent=1)
    hist = os.path.join(os.path.dirname(HERE), "runs", "scorecard_history.jsonl")
    with open(hist, "a", encoding="utf-8") as fh:
        for r in results:
            fh.write(json.dumps(r) + "\n")
    n = sum(r["passed"] for r in results)
    print(f"{'case':34} {'pass':4} {'outcome':10} {'s':>5} {'calls':>5} {'tok in/out':>13} "
          f"{'cost$':>7}")
    for r in sorted(results, key=lambda x: x["case"]):
        m = r["metrics"]
        print(f"{r['case']:34} {'PASS' if r['passed'] else 'FAIL':4} "
              f"{str(m['outcome']):10} {str(m['latency_s']):>5} {str(m['calls']):>5} "
              f"{str(m['in_tok']) + '/' + str(m['out_tok']):>13} "
              f"{('%.4f' % m['cost_usd']) if m['cost_usd'] else '-':>7}")
    tot_cost = sum(r["metrics"]["cost_usd"] or 0 for r in results)
    tot_lat = sum(r["metrics"]["latency_s"] or 0 for r in results)
    esc_ok = [r for r in results if r["checks"].get("outcome")]
    tool_ok = [v for r in results for k, v in r["checks"].items() if k.startswith("called:")]
    print(f"\n{n}/{len(results)} passed | outcome-correct {len(esc_ok)}/{len(results)} | "
          f"tool selection {sum(tool_ok)}/{len(tool_ok)} | total {tot_lat:.0f}s ${tot_cost:.4f}")
    if missing:
        print(f"never run (no transcript): {missing}")
    print("A pass here is NOT adjudication — the sheet's sign-off gates any quoted number.")


def regression_metadata(case):
    """Do not turn a software pass into an execution receipt or training label."""
    if case.get("evidence_mode") == "reviewed_workflow_correction":
        return {"evidence_mode": case["evidence_mode"], "skill": case["skill"],
                "training_eligible": False, "adjudicated": False}
    if case.get("evidence_mode") != "synthetic_software_regression":
        return {}
    return {"evidence_mode": case["evidence_mode"], "family": case["family"],
            "split": case["split"], "training_eligible": False,
            "adjudicated": False,
            "source_tests": case["source_tests"]}


def load_regression_cases(split=None):
    """Small, unadjudicated software corpus; reserve entire failure families.

    These cases exercise this existing scorer. Their linked pytest nodes test
    actual UI/backend behavior separately; model scores never stand in for them.
    """
    if split not in (None, "development", "heldout"):
        raise ValueError("Choose development or heldout regression cases.")
    def read(name):
        path = os.path.join(HERE, name)
        if os.path.getsize(path) > 128000:
            raise ValueError("The software regression corpus exceeds its bounded size.")
        with open(path, encoding="utf-8") as stream:
            return yaml.safe_load(stream)
    manifest = read("science_regression_split.json")
    if (not isinstance(manifest, dict) or manifest.get("schema_version") != 1
            or set(manifest) != {"schema_version", "policy", "development", "heldout"}):
        raise ValueError("The regression split manifest is malformed.")
    groups = [manifest[key] for key in ("development", "heldout")]
    if any(not isinstance(group, list) or not group or any(
            not isinstance(value, str) or not re.fullmatch(r"[a-z][a-z_]{1,60}", value)
            for value in group) for group in groups):
        raise ValueError("Each regression split must name its failure families.")
    families = groups[0] + groups[1]
    if len(families) != len(set(families)):
        raise ValueError("A regression family cannot appear twice or cross splits.")
    cases = read("cases_science_regressions.yaml")
    if not isinstance(cases, list) or not 1 <= len(cases) <= 32:
        raise ValueError("Use one to 32 source-linked software regression cases.")
    seen, covered, result = set(), set(), []
    required = {"id", "family", "provenance", "adjudicated", "evidence_mode", "source_tests", "goal", "expect", "adjudicate"}
    for case in cases:
        if (not isinstance(case, dict) or set(case) != required
                or not re.fullmatch(r"science-reg-[a-z0-9-]{1,90}", str(case.get("id") or ""))
                or case["id"] in seen or case["family"] not in families
                or case["provenance"] != "generated" or case["adjudicated"] is not False
                or case["evidence_mode"] != "synthetic_software_regression"
                or not isinstance(case["goal"], str) or not 1 <= len(case["goal"]) <= 6000
                or not isinstance(case["expect"], dict) or not case["expect"]
                or not isinstance(case["adjudicate"], str) or not case["adjudicate"].strip()):
            raise ValueError("A software regression must retain its generated provenance and bounded rubric.")
        sources = case["source_tests"]
        if (not isinstance(sources, list) or not 1 <= len(sources) <= 6 or any(
                not isinstance(node, str) or not re.fullmatch(r"platform/tests/test_[a-z0-9_]+\.py::test_[a-zA-Z0-9_]+", node)
                for node in sources)):
            raise ValueError("Link each software regression to an existing named repository test.")
        expected = case["expect"]
        if set(expected) - {"outcome", "must_call", "must_not_call", "must_not_claim"}:
            raise ValueError("Use the existing mechanical scorer's expectations.")
        outcomes = expected.get("outcome")
        outcomes = outcomes if isinstance(outcomes, list) else [outcomes]
        if not outcomes or any(not isinstance(outcome, str) or outcome not in {"done", "escalated"} for outcome in outcomes):
            raise ValueError("State a supported mechanical outcome.")
        for field in ("must_call", "must_not_call", "must_not_claim"):
            if field in expected and (not isinstance(expected[field], list) or any(
                    not isinstance(item, str) or not item.strip() or len(item) > 250 for item in expected[field])):
                raise ValueError("Mechanical checks must be short literal strings.")
        assigned = "development" if case["family"] in groups[0] else "heldout"
        seen.add(case["id"])
        covered.add(case["family"])
        if split in (None, assigned):
            result.append({**case, "split": assigned, "training_eligible": False})
    if covered != set(families):
        raise ValueError("Every reserved regression family must have an executable case.")
    return result


def load_all_cases(include_generated: bool = True, *, root=None) -> list:
    """Human-authored cases first (cases.yaml), then generated breadth (cases_generated.yaml,
    provenance tagged) and development software regressions. Held-out software
    families require explicit selection; populations remain separately tagged."""
    out = []
    with open(os.path.join(HERE, "cases.yaml"), encoding="utf-8") as fh:
        for c in yaml.safe_load(fh):
            if str(c.get("source") or "").startswith("learning-loop"):
                continue  # Historical lesson cases enter only through current active corrections.
            c.setdefault("provenance", "human")
            out.append(c)
    gen = os.path.join(HERE, "cases_generated.yaml")
    if include_generated and os.path.exists(gen):
        with open(gen, encoding="utf-8") as fh:
            for c in yaml.safe_load(fh) or []:
                if str(c.get("source") or "").startswith("learning-loop"):
                    continue
                c.setdefault("provenance", "generated")
                c.setdefault("adjudicated", False)
                out.append(c)
    if include_generated:
        # Reserved families require an explicit --science-regressions selection.
        out.extend(load_regression_cases("development"))
    import learn
    from pathlib import Path
    out.extend(learn.correction_cases(root or Path(HERE).parents[2]))
    return out


def run_specialist_cases(only=()):
    """Structural expectations on the three specialists' JSON (specialist_cases.yaml)."""
    import importlib  # noqa: PLC0415
    with open(os.path.join(HERE, "specialist_cases.yaml"), encoding="utf-8") as fh:
        cases = yaml.safe_load(fh)
    mods = {"source_intel": ("source_intel", lambda m, a: m.run(a["pack"])),
            "coding": ("coding_agent", lambda m, a: m.run(a["pack"], a["requirement"])),
            "validation": ("validation_agent", lambda m, a: m.run(a["pack"], a["failure"]))}
    results = []
    for c in cases:
        if only and c["id"] not in only:
            continue
        modname, call = mods[c["agent"]]
        out = call(importlib.import_module(modname), c["args"])
        exp, checks = c["expect"], {}
        text = json.dumps(out, default=str).lower()
        if "decision_startswith" in exp:
            checks["decision"] = str(out.get("decision", "")).startswith(exp["decision_startswith"])
        for k in exp.get("has_keys", []):
            checks[f"has:{k}"] = k in out
        for k in exp.get("critic_has", []):
            checks[f"critic:{k}"] = k in (out.get("critic") or {})
        for phrase in exp.get("must_not_claim", []):
            checks[f"never:{phrase}"] = phrase.lower() not in json.dumps(out.get("assembly") or out.get("proposal") or {}, default=str).lower()
        if "proposal_decision_in" in exp:
            checks["proposal_decision"] = (out.get("proposal") or {}).get("decision") in exp["proposal_decision_in"]
        if exp.get("if_generated_compiles"):
            dc = out.get("deterministic_checks") or {}
            checks["generated_compiles"] = all(v is True for v in dc.values()) if dc else True
        if "each_hypothesis_has" in exp:
            # the Validation agent nests them under `diagnosis` (its JSON, not the wrapper's)
            hs = out.get("hypotheses") or (out.get("diagnosis") or {}).get("hypotheses") or []
            checks["hypotheses_present"] = bool(hs)
            for k in exp["each_hypothesis_has"]:
                checks[f"hyp:{k}"] = all(isinstance(h, dict) and h.get(k) for h in hs)
        r = {"case": c["id"], "agent": c["agent"], "passed": all(checks.values()),
             "checks": checks, "path": out.get("path"), "provenance": "specialist"}
        results.append(r)
        print("  %s %s  (%s)" % ("PASS" if r["passed"] else "FAIL", c["id"],
                                 ", ".join(k for k, v in checks.items() if not v) or "all checks"))
    n = sum(r["passed"] for r in results)
    print(f"specialist evals: {n}/{len(results)} — structural passes, not correctness")
    return results


UNPLANNED_MAX = 5      # more paid cases than this need a stated budget


def _flag(name, default=None, cast=float):
    """`--name value` from argv, or default."""
    if name in sys.argv:
        i = sys.argv.index(name)
        if i + 1 < len(sys.argv):
            return cast(sys.argv[i + 1])
    return default


def spend_guard(n_cases: int, budget_usd):
    """More than a handful of paid cases without a budget is refused: the full corpus is 109
    cases and used to launch with no plan, no ceiling and no total timeout (audit 7)."""
    if n_cases > UNPLANNED_MAX and budget_usd is None:
        raise SystemExit(f"REFUSED — {n_cases} paid cases with no --budget-usd. State the budget "
                         f"(the sweep stops when it is spent) or select at most {UNPLANNED_MAX} cases.")


def run_cases(cases, runner=None, per_case_ceiling=None, max_seconds_per_case=None, budget_usd=None):
    """Run each case bounded (its own cost ceiling and wall clock), under a total budget, with
    every failure isolated to its row — a tool error in case 3 no longer kills the sweep."""
    runner = runner or orchestrator.run
    rows, spent = [], 0.0
    for case in cases:
        if budget_usd is not None and spent >= budget_usd:
            rows.append({"case": case["id"], "passed": False, "checks": {}, "metrics": {},
                         **regression_metadata(case),
                         "error": f"budget ${budget_usd} spent before this case", "skipped": True,
                         "provenance": case.get("provenance", "human")})
            continue
        print(f"== {case['id']}" + ("  [generated, unadjudicated]" if case.get("provenance") == "generated" else ""))
        try:
            st = runner(case["goal"], cost_ceiling=per_case_ceiling, max_seconds=max_seconds_per_case)
            if getattr(st, "metrics", None) is None:
                st.metrics = {}
            r = score(case, st)
            r["error"] = None
        except (Exception, SystemExit) as e:  # noqa: BLE001 - a failed case is a row, not a dead sweep
            r = {"case": case["id"], "passed": False, "checks": {"error": False}, "metrics": {},
                 **regression_metadata(case),
                 "error": f"{type(e).__name__}: {str(e)[:200]}", "provenance": case.get("provenance", "human")}
        rows.append(r)
        spent += float((r.get("metrics") or {}).get("cost_usd") or 0)
        print("   %s  (%s)" % ("PASS" if r["passed"] else "FAIL — read the transcript",
                               r.get("error") or ", ".join(k for k, v in r["checks"].items() if not v) or "all checks"))
    return rows


def main():
    # Listing never instantiates a provider or reads credentials. The same
    # cases can subsequently run via the portal's selected bounded adapter.
    if "--science-regressions" in sys.argv:
        if "--human-only" in sys.argv:
            raise SystemExit("Software regression cases are generated; omit --human-only.")
        split = _flag("--split", None, str)
        cases = load_regression_cases(split)
        if "--list" in sys.argv:
            print(json.dumps({"evidence_mode": "synthetic_software_regression",
                "training_eligible": False, "cases": [{key: c[key] for key in
                    ("id", "family", "split", "source_tests")} for c in cases]}, indent=2))
            return
    elif "--split" in sys.argv or "--list" in sys.argv:
        raise SystemExit("Use --science-regressions with --split or --list.")
    if "--rescore" in sys.argv:
        rescore(cases if "--science-regressions" in sys.argv else None)
        return
    if "--specialists" in sys.argv:
        out = os.path.join(os.path.dirname(HERE), "runs", "specialist_scorecard.json")
        os.makedirs(os.path.dirname(out), exist_ok=True)
        res = run_specialist_cases(set(a for a in sys.argv[1:] if a != "--specialists"))
        with open(out, "w", encoding="utf-8") as fh:
            json.dump(res, fh, indent=1)
        return
    if "--critic" in sys.argv:
        out = os.path.join(os.path.dirname(HERE), "runs", "critic_scorecard.json")
        os.makedirs(os.path.dirname(out), exist_ok=True)
        res = run_critic_cases(set(a for a in sys.argv[1:] if a != "--critic"))
        with open(out, "w", encoding="utf-8") as fh:
            json.dump(res, fh, indent=1)
        return
    if "--science-regressions" not in sys.argv:
        cases = load_all_cases(include_generated="--human-only" not in sys.argv)
    budget = _flag("--budget-usd")
    per_case = _flag("--per-case-usd", 0.5)
    per_secs = _flag("--max-seconds-per-case", 300.0)
    values = set()
    for f in ("--budget-usd", "--per-case-usd", "--max-seconds-per-case", "--split"):
        if f in sys.argv and sys.argv.index(f) + 1 < len(sys.argv):
            values.add(sys.argv[sys.argv.index(f) + 1])
    only = set(a for a in sys.argv[1:] if not a.startswith("--") and a not in values)
    selected = [c for c in cases if not only or c["id"] in only]
    spend_guard(len(selected), budget)
    results = run_cases(selected, per_case_ceiling=per_case, max_seconds_per_case=per_secs, budget_usd=budget)
    out = os.path.join(os.path.dirname(HERE), "runs", "scorecard.json")
    os.makedirs(os.path.dirname(out), exist_ok=True)
    with open(out, "w", encoding="utf-8") as fh:
        json.dump(results, fh, indent=1)
    with open(os.path.join(os.path.dirname(HERE), "runs", "scorecard_history.jsonl"),
              "a", encoding="utf-8") as fh:
        for r in results:
            fh.write(json.dumps(r) + "\n")
    n = sum(r["passed"] for r in results)
    print(f"\n{n}/{len(results)} passed mechanically -> {out}")
    print("A pass here is NOT adjudication: a person reads the transcripts before any number "
          "from this corpus is quoted anywhere.")


if __name__ == "__main__":
    main()
