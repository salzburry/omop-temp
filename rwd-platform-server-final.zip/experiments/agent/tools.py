"""The agent's tool registry: the MCP server's closed read surface, plus two read-only extras.

REUSED, NOT REIMPLEMENTED. `platform/tools/mcp_server.py` already wraps the governed read tools
behind path confinement and a guard test that refuses write-shaped names in both directions.
Importing its READ_TOOLS means the agent's surface and the wire surface cannot drift apart, and
every guarantee proven there (nothing writes to the checkout; a non-zero gate exit is a verdict,
not an error) holds here without restating it.

The two additions are reads the benchmark's tool list names and the wire surface does not carry:
precedent search and capability lookup. Both go through the tools that own the answer.
"""
from __future__ import annotations

import os
import json
import re
import subprocess
import sys
from contextvars import ContextVar

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(os.path.dirname(HERE))
TOOLS_DIR = os.path.join(ROOT, "platform", "tools")
sys.path.insert(0, TOOLS_DIR)

import mcp_server as srv  # noqa: E402  (the closed surface and its confinement)

DEFAULT_PACK = srv.DEFAULT_PACK

# THE SNAPSHOT FAST PATH. `pack_status` computes for ~44s and `portfolio` for ~60s — measured —
# and a chat answer that needs one should not cost a minute when a verified snapshot is already
# loaded. A host (the portal) may install one with `use_snapshot`; the two status tools then
# answer from it in milliseconds, EVERY answer carrying its provenance line so a reader can see
# it is a precomputed view, not a live evaluation. Hosts that install nothing (MCP, CLI, evals)
# keep live computation — the fast path is opt-in, never silent.
# CONTEXT-LOCAL like the scope (tenth review: one portal session's snapshot replaced another's
# provenance in a shared process). A page installs its snapshot per run; a background job inherits
# the page's context (jobs.start copies it), so the agent keeps the fast path.
_SNAP: ContextVar = ContextVar("rwdp_snapshot", default=None)


def use_snapshot(snap: dict | None, label: str = "") -> None:
    """Install a validated snapshot, or clear a previous page's fast path."""
    _SNAP.set((snap, label) if snap is not None else None)


def _snap_pack_status(args):
    snap, label = _SNAP.get()
    rel = str(args.get("pack") or DEFAULT_PACK).replace("\\", "/").strip("/")
    e = snap.get("packs", {}).get(rel)
    if not e:
        return f"[snapshot {label}] no pack {rel!r} in the snapshot — run the live tool"
    lines = [f"[snapshot {label}] {rel} — precomputed status; the Run gates tab computes live"]
    for g in e.get("gates", []):
        if isinstance(g, dict):
            lines.append(f"gate {g.get('gate')} {g.get('name')}: {g.get('status')}")
            for b in (g.get("blockers") or []):
                lines.append(f"   blocker: {b}")
    lines.append(f"next_action: {e.get('next_action')}")
    return "\n".join(lines)


def _snap_portfolio(args):
    snap, label = _SNAP.get()
    lines = [f"[snapshot {label}] portfolio — precomputed"]
    for rel, e in sorted(snap.get("packs", {}).items()):
        lines.append(f"{rel} ({e.get('kind')}): next_action={e.get('next_action')}")
    return "\n".join(lines)


def _run(argv, timeout=None):
    """Run a repository tool in a child, bounded. The bound is RWD_TOOL_TIMEOUT_S (default 300 s;
    the portal sets 90 s for chat turns): a call that outlives it returns a TIMEOUT observation —
    what was asked, how long it was allowed, and where to run it live — instead of holding the
    caller (a chat sat ten minutes on one live portfolio computation, 2026-09-03)."""
    timeout = float(os.environ.get("RWD_TOOL_TIMEOUT_S", "300")) if timeout is None else timeout
    try:
        r = subprocess.run([sys.executable] + argv, cwd=ROOT, capture_output=True,
                           encoding="utf-8", errors="replace", timeout=timeout,
                           env=dict(os.environ, PYTHONUTF8="1", PYTHONIOENCODING="utf-8"))
    except subprocess.TimeoutExpired:
        return (f"TIMEOUT: {os.path.basename(str(argv[0]))} did not finish within {timeout:.0f}s "
                f"(RWD_TOOL_TIMEOUT_S). Not an answer. Use the `packs` tool for existence questions, "
                f"the snapshot-backed status tools for status, or ask the person to run it on the "
                f"Run gates tab.")
    out = ((r.stdout or "") + (r.stderr or "")).strip()
    return out or f"(nothing printed; exit {r.returncode})"


def t_packs(args):
    """Every registered pack — fixtures and products — as `path (slug, version, role, status)`,
    from the two registries alone. A file read: the cheap answer to "does prostate/202609
    exist?" that used to cost a live portfolio computation (2026-09-03)."""
    import glob  # noqa: PLC0415
    import yaml  # noqa: PLC0415
    lines = []
    for reg_rel, base in (("fixtures/registry.yaml", "fixtures"), ("products/registry.yaml", "products")):
        reg_path = os.path.join(ROOT, reg_rel)
        if not os.path.exists(reg_path):
            continue
        try:
            entries = (yaml.safe_load(open(reg_path, encoding="utf-8")) or {}).get("tumors") or []
        except yaml.YAMLError as e:
            lines.append(f"{reg_rel}: unreadable ({type(e).__name__})")
            continue
        for e in entries:
            if not isinstance(e, dict) or not e.get("slug"):
                continue
            fam = e.get("family") or "oncology"
            # a VERSION's status comes from the registry's lineage (tenth review: prostate/202603
            # read `active` from the tumour row while the registry marks it superseded); a YYYYMM
            # directory is a template and says so
            lineage = {str(x.get("spec_version")): str(x.get("status") or "")
                       for x in (e.get("lineage") or []) if isinstance(x, dict)}
            versions = sorted(os.path.basename(d) for d in glob.glob(os.path.join(ROOT, base, fam, e["slug"], "*"))
                              if os.path.isdir(d) and (os.path.basename(d)[:1].isdigit() or os.path.basename(d) == "YYYYMM"))
            for v in versions or [str(e.get("current_spec_version") or "?")]:
                role = "template" if v == "YYYYMM" else (e.get("role") or "product")
                status = lineage.get(v) or (e.get("status") or "?")
                lines.append(f"{base}/{fam}/{e['slug']}/{v} (slug {e['slug']}, version {v}, "
                             f"role {role}, status {status}"
                             f"{', current' if v == str(e.get('current_spec_version')) else ''})")
    if not lines:
        return "no packs registered"
    q = str(args.get("query") or "").strip().lower()
    if q:
        hits = [l for l in lines if q in l.lower()]
        return "\n".join(hits) if hits else (f"no pack matches {q!r}; registered packs:\n" + "\n".join(lines))
    return "\n".join(lines)


def t_precedents(args):
    """What other packs decided when they hit the same question — evidence, never an approval.
    In-process: the CLI's main() under a captured stdout, so a call costs the work and not a
    fresh interpreter plus every import (a subprocess per call was most of the chat's latency)."""
    import contextlib  # noqa: PLC0415
    import io as _io  # noqa: PLC0415
    pack = str(args.get("pack") or DEFAULT_PACK)
    if TOOLS_DIR not in sys.path:
        sys.path.insert(0, TOOLS_DIR)
    import precedents as _pr  # noqa: PLC0415
    buf = _io.StringIO()
    try:
        with contextlib.redirect_stdout(buf):
            _pr.main(["--for", pack])
    except SystemExit as e:
        if e.code not in (0, None):
            buf.write(f"\n(precedents exited {e.code})")
    return buf.getvalue().strip() or "(no output)"


def warm() -> dict:
    """Pay the one-off costs once per process, off the request path: the search validators (cached
    by tree stamp) and the embedding index. The portal calls this in a background thread at
    startup so the first question is not the one that pays."""
    out = {}
    try:
        import knowledge_search as ks  # noqa: PLC0415
        out["search_unusable"] = sorted(ks.surface_errors(str(ROOT)))
    except Exception as e:  # noqa: BLE001
        out["search_error"] = f"{type(e).__name__}: {e}"
    try:
        sys.path.insert(0, os.path.join(HERE, "ml"))
        import embed  # noqa: PLC0415
        if not os.path.exists(embed.INDEX):
            import contextlib  # noqa: PLC0415
            import io as _io  # noqa: PLC0415
            with contextlib.redirect_stdout(_io.StringIO()):
                embed.index()
        out["embed_index"] = embed.INDEX
    except Exception as e:  # noqa: BLE001
        out["embed_error"] = f"{type(e).__name__}: {e}"
    return out


def t_capabilities(args):
    """The capability registry's own rendering: what each engine-coverage claim resolves to.

    `query` (optional) returns only the sections mentioning it, FIRST — the full rendering is
    ~40k characters and the orchestrator hands the model 6k, so 32 of 37 capability ids were cut
    off before the model could see them (audit 5). A filtered read answers the reuse question;
    an unfiltered one still returns the whole page for callers that want it."""
    with open(os.path.join(ROOT, "platform", "CAPABILITIES.md"), encoding="utf-8") as fh:
        text = fh.read()
    q = str((args or {}).get("query") or "").strip().lower()
    if not q:
        return text
    import re as _re  # noqa: PLC0415
    sections = _re.split(r"(?m)^(?=#{2,4} )", text)
    hits = [s for s in sections if q in s.lower()]
    if not hits:
        return (f"no capability section mentions {q!r} — the registry lists: "
                + ", ".join(sorted(set(_re.findall(r"`([a-z_]+\.[a-z_]+)`", text))))[:3000])
    return "\n".join(hits)[:12000]


def _specialist_model(pack, kind, query=None):
    model = _MODEL.get()
    authorize = getattr(model, "authorize_pack", None)
    if callable(authorize):
        authorize(pack)
    bind = getattr(model, "for_task", None)
    return bind(kind=kind, query=query, task_scope={"pack": pack, "variable": query if kind == "implementation" else ""}) if callable(bind) else model


def _retain_critic(pack, result):
    capture = getattr(_MODEL.get(), 'record_critic', None)
    if callable(capture):
        capture(pack, result.get('critic'))


def t_mapping_evidence(args):
    """Run the Source Intelligence specialist: assemble the pack's source-gap/candidate evidence
    into the candidate workspace (critic-reviewed). Returns the summary and the candidate path —
    never a mapping decision; equivalence stays a person's."""
    import source_intel  # noqa: PLC0415
    pack = str(args.get("pack") or DEFAULT_PACK)
    question = args.get("question") or "Assess declared source tables, columns and mapping suitability."
    if not isinstance(question, str) or len(question) > 4000:
        raise ValueError("Keep the source assessment question under 4,000 characters.")
    r = source_intel.run(pack, model=_specialist_model(pack, "source", question), question=question)
    _retain_critic(pack, r)
    return (f"candidate file: {r['path']}\n"
            f"critic: falsified={r['critic'].get('falsified')} route={r['critic'].get('route')}\n"
            f"{json.dumps(r['assembly'], indent=1)[:4000]}")


def t_code_candidate(args):
    """Run the Coding specialist (PySpark only; R goes to the GSK star agent per
    docs/R_STAR_AGENT_BRIEF.md): reuse-first answer or generated candidate code+tests into the
    candidate workspace. Compile-checked, critic-reviewed, never accepted here."""
    import coding_agent  # noqa: PLC0415
    pack = str(args.get("pack") or DEFAULT_PACK)
    r = coding_agent.run(pack, str(args.get("requirement") or ""), model=_specialist_model(pack, "implementation", str(args.get("requirement") or "")))
    _retain_critic(pack, r)
    critic = r.get("critic") or {}                      # None when the guard refused before review
    return (f"candidate file: {r['path']} | decision={r['proposal'].get('decision')} "
            f"| checks={r['deterministic_checks']} "
            + (f"| critic falsified={critic.get('falsified')} route={critic.get('route')}" if critic
               else f"| not reviewed: {str(r.get('decision'))[:160]}"))


def t_diagnose(args):
    """Run the Validation/root-cause specialist: evidence-ranked hypotheses with a
    discriminating check each; diagnoses, never fixes."""
    import validation_agent  # noqa: PLC0415
    pack = str(args.get("pack") or DEFAULT_PACK)
    r = validation_agent.run(pack, args.get("failure"), model=_specialist_model(pack, "validation", args.get("failure") or "Explain the current validation failure and next repair."))
    _retain_critic(pack, r)
    return (f"candidate file: {r['path']} "
            f"| critic falsified={r['critic'].get('falsified')} route={r['critic'].get('route')}"
            + chr(10) + json.dumps(r['diagnosis'], indent=1)[:3000])


def t_lessons(args):
    """§13: the advisory lessons store — corrections that became platform knowledge. Bottom of
    the authority ladder: supports interpretation, never overrides governed sources."""
    import control_plane
    loader = control_plane.workflow_skills()
    model = _MODEL.get()
    current = getattr(model, "workflow_retrieval_context", None)
    context = current() if callable(current) else {"root": ROOT, "route": "governed_check"}
    query, task_scope = loader.task_context(args.get("query") or context.get("query"), context.get("task_scope"))
    scope = current_scope()
    if scope is not None:
        task_scope["packs"] = [pack for pack in task_scope["packs"] if pack in scope]
    result = loader.reviewed_corrections(context["root"], context.get("route"), kind=context.get("kind"),
        query=query, task_scope=task_scope, budget=1400)
    return result["prompt"] or "No relevant enabled correction was found for this task and product scope."


def t_semantic_search(args: dict) -> str:
    """ML item 6 as a READ-ONLY tool: hashed-trigram retrieval over the governed rows (decisions,
    lessons, glossary). Pointers only — the row decides, never the retriever."""
    import contextlib  # noqa: PLC0415
    import io as _io  # noqa: PLC0415
    sys.path.insert(0, os.path.join(HERE, "ml"))
    import embed  # noqa: PLC0415
    q = str(args.get("query") or "").strip()
    if not q:
        return "semantic_search needs a query"
    # THE TOOL OWNS ITS INDEX. A stale or missing index (a pre-algorithm-tag file from an earlier
    # session) is rebuilt here, once; and NOTHING escapes to the orchestrator — a raised error
    # took down a live benchmark at run 3 of 9. A tool returns text, always.
    for attempt in (1, 2):
        try:
            if not os.path.exists(embed.INDEX):
                with contextlib.redirect_stdout(_io.StringIO()):
                    embed.index()
            buf = _io.StringIO()
            with contextlib.redirect_stdout(buf):
                embed.query(q, k=int(args.get("k") or 5), include_lessons=False)
            # Cached correction rows must not bypass skill/product relevance,
            # withdrawal, or the paired evaluation's target exclusion. Reuse
            # the same lookup and delivery observations as the lessons tool.
            return buf.getvalue() + "\n" + t_lessons({"query": q})
        except Exception:  # noqa: BLE001 — including a stale-index refusal
            if attempt == 1:
                try:
                    os.remove(embed.INDEX)
                except OSError:
                    pass
                continue
            return "semantic_search unavailable: the current knowledge cache or scoped correction inputs could not be read. Refresh the current task and retry."
    return "semantic_search unavailable"


def t_drift_check(args: dict) -> str:
    """ML item 5 as a tool, fenced: two profile TSVs under RWD_PROFILE_DIR (never the repo, never
    an arbitrary path — profiles are restricted derivatives), compared with drift.compare."""
    root = os.environ.get("RWD_PROFILE_DIR")
    if not root:
        return "REFUSED — RWD_PROFILE_DIR is not set; drift_check reads profiles only from there"
    root = os.path.realpath(root)
    paths = []
    for k in ("old", "new"):
        p = os.path.realpath(os.path.join(root, str(args.get(k) or "")))
        if not p.startswith(root + os.sep) or not os.path.isfile(p):
            return f"REFUSED — {k}={args.get(k)!r} is not a file under RWD_PROFILE_DIR"
        paths.append(p)
    sys.path.insert(0, os.path.join(HERE, "ml"))
    import drift  # noqa: PLC0415
    f = drift.compare(*paths)
    if not f:
        return "no drift finding between the two profiles (shape, top values, missingness, date ranges)"
    return "\n".join(f"{t}.{c}: {what} | check: {chk}" for t, c, what, chk in f[:40]) + \
        (f"\n… {len(f) - 40} more" if len(f) > 40 else "")


EXTRA_TOOLS = {
    "lessons": (t_lessons, "Recorded corrections (the learning loop): what was once misread and "
                           "what is right — advisory, never overriding spec/decisions/metadata.",
                {"query": {"type": "string", "description": "filter text (optional)"}}),
    "code_candidate": (t_code_candidate,
                       "Coding specialist (PySpark): reuse-first implementation answer or a "
                       "generated candidate with tests — compile-checked, critic-reviewed, "
                       "never accepted by the model.",
                       {"pack": srv.PACK_ARG,
                        "requirement": {"type": "string",
                                        "description": "variable/requirement id, e.g. PFS"}}),
    "diagnose": (t_diagnose,
                 "Validation specialist: root-cause hypotheses ranked by evidence, each with a "
                 "discriminating check.",
                 {"pack": srv.PACK_ARG,
                  "failure": {"type": "string", "description": "failure text (optional)"}}),
    "mapping_evidence": (t_mapping_evidence,
                         "Assemble source-gap and mapping-candidate EVIDENCE for a pack into the "
                         "candidate workspace (Source Intelligence specialist; critic-reviewed; "
                         "never decides equivalence). Retain the person's specific source question.",
                         {"pack": srv.PACK_ARG,
                          "question": {"type": "string", "description": "Exact source or mapping question (optional; maximum 4,000 characters)"}}),
    "precedents": (t_precedents, "Settled-elsewhere decisions relevant to a pack; advisory, "
                                 "no authority.", {"pack": srv.PACK_ARG}),
    "semantic_search": (t_semantic_search, "Meaning-based retrieval over governed rows (decisions, "
                        "lessons, glossary): finds a concept by what it means, not its registered "
                        "token. Returns POINTERS — the row decides, never the retriever.",
                        {"query": "text", "k": "int (default 5)"}),
    "drift_check": (t_drift_check, "Compare two profile TSVs under RWD_PROFILE_DIR: added/removed "
                    "tables and columns, top-value distribution shifts (L1), missingness, "
                    "date-range moves — each finding with its discriminating check. Refuses any "
                    "path outside that directory.", {"old": "relative path", "new": "relative path"}),
    "capabilities": (t_capabilities, "The engine capability registry rendering (verification "
                                     "states, symbols, tests).", {}),
    "packs": (t_packs, "Every registered pack (fixtures and products) with slug, version, role and "
                       "status — a registry read in milliseconds. Use it FIRST for 'does this "
                       "pack/version exist' before any status tool.",
              {"query": "filter text, e.g. a slug or version (optional)"}),
}

# write-shaped words, mirrored from the MCP guard test — the registry refuses them here too,
# so an experiment cannot quietly grow an act while the wire surface stays clean
_WRITE_SHAPED = {"apply", "record", "promote", "write", "activate", "approve", "sign",
                 "adopt", "release", "commit", "draft", "init", "propose"}


def registry():
    tools = dict(srv.READ_TOOLS)
    tools.update(EXTRA_TOOLS)
    for name in tools:
        hit = set(name.split("_")) & _WRITE_SHAPED
        if hit:
            # an explicit raise, not `assert`: assertions vanish under `python -O`, and a safety
            # boundary that evaporates with an interpreter flag is not a boundary (external audit)
            raise RuntimeError(f"{name!r} wears a write-shaped word ({sorted(hit)}) — the agent "
                               f"surface is read-only by construction; refusing to register it")
    return tools


# TYPED AUTHORITY. Which tools hand a QUESTION to a person, and to whom — metadata on the tool,
# not phrases in its output: a probe called the real decision packet, whose wording matched none of
# the four phrases the orchestrator scanned for, then "approved on behalf of Science" and completed
# (audit 7). The orchestrator reads this after every observation; a person's question is never
# answered by the loop, whatever the text said.
AUTHORITY_TOOLS = {"decision_packet": "Science/DataExpert", "open_questions": "Science/DataExpert"}


def meta(name: str) -> dict:
    """{decides: 'human'|None, owner: str|None} for a tool name; unknown names decide nothing."""
    owner = AUTHORITY_TOOLS.get(name)
    return {"decides": "human" if owner else None, "owner": owner}


# PACK SCOPE, ENFORCED WHERE THE READ HAPPENS. A host (the portal) installs the actor's pack
# membership; every tool that takes a pack refuses one outside it — including the DEFAULT pack when
# no argument was given, so a reviewer scoped to one pack cannot read another through the default
# (audit 7: membership filtered the selector only, and the agent's tools ignored it).
# CONTEXT-LOCAL, NEVER PROCESS-GLOBAL (audit 8): the first version was one module variable, so the
# last portal session to render set the scope for every session sharing the process, and a job
# thread started with whatever the previous page had installed. A ContextVar is per thread and per
# run: `call(scope=)` is explicit, `set_pack_scope` installs a default for THIS context only, and a
# run installs its own in `orchestrator._loop` so the specialists it calls inherit it.
_SCOPE: ContextVar = ContextVar("rwdp_pack_scope", default=None)
_MODEL: ContextVar = ContextVar("rwdp_run_model", default=None)


class ModelStopped(RuntimeError):
    """A host's bounded model stopped, with a sanitized user-facing explanation."""
_PACK_RE = re.compile(r"(?:products|fixtures)/[A-Za-z0-9_.-]+/[A-Za-z0-9_.-]+/[A-Za-z0-9_.-]+")


def _norm(packs):
    return None if packs is None else {str(p).replace("\\", "/").strip("/") for p in packs}


def set_pack_scope(packs) -> None:
    """Install a pack scope for the CURRENT context (thread / run) — not for the process."""
    _SCOPE.set(_norm(packs))


def current_scope():
    return _SCOPE.get()


def _scope_refusal(name: str, params, args: dict, scope):
    if scope is None or not isinstance(params, dict) or "pack" not in params:
        return None
    pack = str(args.get("pack") or DEFAULT_PACK).replace("\\", "/").strip("/")
    if pack not in scope:
        return (f"REFUSED — {name}: pack {pack!r} is outside your pack scope "
                f"({', '.join(sorted(scope))}). Ask an administrator for membership.")
    return None


def _scoped_lines(text, scope):
    """Readers with no `pack` argument (portfolio) name every pack; lines about packs outside the
    scope are dropped and counted, so a scoped reader never learns another pack's state."""
    if scope is None:
        return text
    kept, dropped = [], 0
    for line in str(text).splitlines():
        m = _PACK_RE.search(line.replace("\\", "/"))
        if m and m.group(0) not in scope:
            dropped += 1
            continue
        kept.append(line)
    if dropped:
        kept.append(f"({dropped} line(s) about packs outside your scope were not shown)")
    return "\n".join(kept)


# EVERY READER THAT NAMES PACKS WITHOUT TAKING ONE IS LINE-FILTERED (independent review of audit 8:
# `packs` listed every registry entry and `semantic_search` returned another pack's decision rows
# under scope). `precedents` is not in the list on purpose: it is the advisory cross-pack store —
# what other tumours decided about the SAME question — and its pack argument is scope-checked.
_LINE_FILTERED = ("portfolio", "packs", "semantic_search")


def _pack_of(where) -> str | None:
    m = _PACK_RE.match(str(where or "").replace("\\", "/").strip("/"))
    return m.group(0) if m else None


def _search(args, scope):
    """The federated search, rendered here so every pack-bound hit NAMES its pack and hits from
    packs outside the scope are filtered before anything is shown (audit 8: the MCP renderer
    printed hits without their pack and the scope never reached it)."""
    import knowledge_search as ks  # noqa: PLC0415
    terms = [w for w in str(args.get("query") or "").split() if w]
    if not terms:
        return "give a query"
    hits = ks.search(terms)
    kept, dropped = [], 0
    for h in hits:
        pk = _pack_of(h.get("where"))
        if scope is not None and pk is not None and pk not in scope:
            dropped += 1
            continue
        kept.append(h)
    out = ["NOTHING BELOW IS AN APPROVAL — every hit is labelled by what it may settle."]
    for h in kept[:25]:
        pk = _pack_of(h.get("where"))
        out.append(f"[{h.get('kind')}/{h.get('domain', '?')}]" + (f" {pk}" if pk else "")
                   + (f" ({h.get('state')})" if h.get("state") else "")
                   + f" {h.get('title') or h.get('id') or ''} — "
                   + f"{str(h.get('detail') or h.get('text') or h.get('snippet') or '')[:200]}")
    if len(kept) > 25:
        out.append(f"... and {len(kept) - 25} more (narrow the query)")
    if dropped:
        out.append(f"({dropped} hit(s) in packs outside your scope were not shown)")
    return "\n".join(out) if len(out) > 1 else "no hits"


def call(name: str, args: dict, scope=None) -> str:
    """One tool call. `scope` (a set of pack paths) confines it; unset, the context's scope applies."""
    tools = registry()
    if name not in tools:
        return (f"no such tool {name!r} — the surface is closed; available: "
                + ", ".join(sorted(tools)))
    scope = _norm(scope) if scope is not None else _SCOPE.get()
    refused = _scope_refusal(name, tools[name][2], args or {}, scope)
    if refused:
        return refused
    fn = tools[name][0]
    if _SNAP.get() and name == "pack_status":
        fn = _snap_pack_status
    elif _SNAP.get() and name == "portfolio":
        fn = _snap_portfolio
    if name == "search":
        fn = lambda a, _s=scope: _search(a, _s)                       # noqa: E731
    elif name in _LINE_FILTERED:
        fn = lambda a, _f=fn, _s=scope: _scoped_lines(_f(a), _s)      # noqa: E731
    token = _SCOPE.set(scope)
    try:
        return str(fn(args or {}))
    except SystemExit as e:  # a CLI refusal inside a tool is an observation (tenth review: it killed the run)
        return f"tool {name} refused: {e}"
    except Exception as e:  # a tool error is an observation, not a crash
        return f"tool {name} raised {type(e).__name__}: {e}"
    finally:
        _SCOPE.reset(token)


def describe() -> str:
    return "\n".join(f"- {n}: {d}" + (f"  (args: {', '.join(p)})" if p else "")
                     for n, (_f, d, p) in sorted(registry().items()))
