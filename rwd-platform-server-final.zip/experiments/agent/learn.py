"""One reviewed learning lifecycle: propose, check, activate, withdraw.

    python experiments/agent/learn.py --wrong "<what the agent got wrong>" \
        --right "<the correct understanding>" --context "<pack/topic>" --by "<who corrected>"

The compatibility command saves a proposed correction, defaulting to the general
operate-rwd-product skill. Pass --skill to select a specialist. It does not enable
guidance or append the historical lessons/evaluation files. After registered checks
and explicit review, the same record supplies guidance and evaluation examples.
Legacy files remain historical inputs for explicit preview/import, never live memory.
"""
from __future__ import annotations

import argparse
from collections import OrderedDict
import copy
from functools import lru_cache
import importlib.util
import json
import os
import time
import hashlib
from pathlib import Path
import re
import subprocess
import sys
import tempfile
import threading
from contextlib import contextmanager, ExitStack
from datetime import date, datetime, timezone
import uuid

import yaml

HERE = os.path.dirname(os.path.abspath(__file__))
KNOWLEDGE = os.path.join(HERE, "knowledge", "lessons.yaml")
CASES = os.path.join(HERE, "evals", "cases.yaml")
CANDIDATES = os.path.join(HERE, "candidates")


def record_lesson(wrong: str, right: str, context: str, by: str,
                  eval_goal: str | None = None, governed: str | None = None, *, root=None,
                  skill="operate-rwd-product", scope=None) -> dict:
    """Compatibility entry point; every new lesson starts in the same proposed state."""
    root = Path(root or Path(HERE).parents[1]).resolve()
    row = propose_correction(root, skill, wrong, right, context, by,
        eval_goal or f"Context: {context}. Assess this assertion: {wrong}", scope=scope,
        provenance={"entrypoint": "record_lesson", "governed_destination": governed})
    return {"lesson": row["id"], "eval_case": "correction-" + row["id"], "status": row["status"],
            "record": correction_relative_path(root, row["id"]), "correction": row,
            "governed_destination": governed,
            "notice": "Saved for review. Run the linked checks and explicitly activate it before assistants or evaluations use it."}


def lessons_text(query: str | None = None, *, root=None, packs=None) -> str:
    lessons = active_corrections(Path(root or Path(HERE).parents[1]).resolve(), packs=packs)
    hits = [l for l in lessons
            if not query or query.lower() in json.dumps(l).lower()]
    lines = [f"{len(hits)} lesson(s)" + (f" matching {query!r}" if query else "")
             + " — reviewed workflow guidance; never scientific evidence or approval"]
    for l in hits:
        lines.append(f"[{l['id']} {l['skill']} by {l['created_by']}] {l['context']}: "
                     f"WRONG: {l['wrong']} | RIGHT: {l['right']}")
    return "\n".join(lines)


# The same learning loop, exposed to every workflow skill. One record per
# correction avoids array appends racing and gives Git branches mergeable units.
CORRECTIONS = Path("experiments/agent/knowledge/corrections")
CORRECTION_HISTORY = CORRECTIONS / "history"
MAX_CORRECTIONS = 500
MAX_CORRECTION_BYTES = 24_000
MAX_LIBRARY_RECORDS = 20_000
MAX_LIBRARY_BYTES = 128_000_000
MAX_CACHE_BYTES = 32_000_000
_VALIDATED_RECORDS = OrderedDict()
_VALIDATED_BYTES = 0
_CACHE_LOCK = threading.RLock()
DEFAULT_TESTS = {
    "operate-rwd-product": ["platform/tests/test_epi_flow_assistant.py"],
    "draft-contract-record": ["platform/tests/test_epi_scientific_definition_ai.py"],
    "answer-decisions": ["platform/tests/test_epi_decision_answer_ai.py"],
    "propose-variable-name": ["platform/tests/test_epi_scientific_definition_naming.py"],
    "propose-source-mapping": ["platform/tests/test_epi_source_workspace.py"],
    "apply-source-verdicts": ["platform/tests/test_epi_workflow_forms.py"],
    "next-cut": ["platform/tests/test_epi_specification_revision_review.py"],
    "implement-product-rule": ["platform/tests/test_epi_coding_patterns.py"],
}


def _ingress(text):
    """Reuse the same credential/individual-data classifier as portal authoring."""
    base = Path(__file__).resolve().parents[2]
    for path in (base / "platform/tools", base / "experiments/portal"):
        if str(path) not in sys.path:
            sys.path.insert(0, str(path))
    import scientific_definition_ai
    scientific_definition_ai._ingress(text)


def _plain(value):
    if isinstance(value, dict):
        return "\n".join(str(key) + ": " + _plain(item) for key, item in value.items())
    if isinstance(value, list):
        return "\n".join(_plain(item) for item in value)
    return str(value)


def _scope_value(value):
    if value is None:
        return {"kind": "global"}
    if not isinstance(value, dict):
        raise ValueError("Choose global guidance, explicit product scopes, or unresolved original context.")
    if value == {"kind": "global"}:
        return dict(value)
    if value.get("kind") == "packs" and set(value) == {"kind", "packs"}:
        packs = value["packs"]
        if (isinstance(packs, list) and 0 < len(packs) <= 30
                and all(isinstance(p, str) and len(p) <= 240
                        and re.fullmatch(r"(?:products|fixtures)(?:/[A-Za-z0-9_.-]+){3}", p)
                        and not any(part in {".", ".."} for part in p.split("/")) for p in packs)):
            return {"kind": "packs", "packs": sorted(set(packs))}
    if (value.get("kind") == "legacy_context" and set(value) == {"kind", "context"}
            and isinstance(value["context"], str) and 0 < len(value["context"].strip()) <= 1800):
        return {"kind": "legacy_context", "context": value["context"].strip()}
    raise ValueError("The correction's declared scope is unreadable or too broad.")


def _provenance_value(value):
    if value is None:
        return None
    if not isinstance(value, dict) or len(json.dumps(value, allow_nan=False).encode()) > 10000:
        raise ValueError("Keep the correction provenance within its supported size.")
    destination = value.get("governed_destination")
    if destination is not None and (not isinstance(destination, str) or not destination.strip() or len(destination) > 200):
        raise ValueError("Use a concise governed destination for review.")
    return value


def digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, ensure_ascii=False,
                                     allow_nan=False).encode()).hexdigest()


def _safe(root, relative):
    root = Path(root).resolve(strict=True)
    path = root / relative
    if not path.is_relative_to(root) or path.resolve() != path:
        raise ValueError("The improvement record must stay in its declared checkout location.")
    return path


def _skill_hash(root, skill):
    if skill not in DEFAULT_TESTS:
        raise ValueError("Choose a registered workflow skill.")
    path = _safe(root, Path(".claude/skills") / skill / "SKILL.md")
    if not path.is_file() or path.stat().st_size > 65536:
        raise ValueError("Restore the current workflow skill before recording an improvement.")
    # Git may check text out with CRLF on one person's computer and LF on
    # another. Bind portable lessons to instruction text, not checkout EOLs.
    text = path.read_text(encoding="utf-8-sig")
    return hashlib.sha256(text.replace("\r\n", "\n").encode()).hexdigest()


def _record_locations(root, record_id):
    if not isinstance(record_id, str) or not re.fullmatch(r"[a-f0-9]{24}", record_id):
        raise ValueError("Choose an existing improvement record.")
    return (_safe(root, CORRECTIONS / (record_id + ".yaml")),
            _safe(root, CORRECTION_HISTORY / (record_id + ".yaml")))


def _record_path(root, record_id):
    live, historical = _record_locations(root, record_id)
    if historical.exists():
        if live.exists() and (live.stat().st_size > MAX_CORRECTION_BYTES
                or historical.stat().st_size > MAX_CORRECTION_BYTES or live.read_bytes() != historical.read_bytes()):
            raise ValueError("This correction has conflicting current and historical branch records. Resolve that exact record before continuing.")
        return historical
    return live


def correction_relative_path(root, record_id):
    """Canonical Git path, including terminal history after explicit archival."""
    return _record_path(root, record_id).relative_to(Path(root).resolve(strict=True)).as_posix()


def _parse_correction(raw, record_id):
    try:
        if any(isinstance(token, (yaml.AliasToken, yaml.AnchorToken)) for token in yaml.scan(raw)):
            raise ValueError()
        value = yaml.safe_load(raw)
        expected = value.pop("digest")
        if (expected != digest(value) or value["id"] != record_id or value["schema"] != 1
                or value["skill"] not in DEFAULT_TESTS
                or value["status"] not in {"proposed", "checked", "check_failed", "active", "withdrawn", "retired"}):
            raise ValueError()
        for field in ("wrong", "right", "context", "created_by", "created_at", "eval_goal", "authority"):
            if not isinstance(value.get(field), str) or not value[field].strip() or len(value[field]) > 1800:
                raise ValueError()
        for field in ("skill_sha256", "fingerprint"):
            if not isinstance(value.get(field), str) or not re.fullmatch(r"[a-f0-9]{64}", value[field]):
                raise ValueError()
        if value.get("tests") != DEFAULT_TESTS[value["skill"]]:
            raise ValueError()
        _scope_value(value.get("scope"))
        _provenance_value(value.get("provenance"))
        check, review = value.get("check"), value.get("review")
        if check is not None:
            if (not isinstance(check, dict) or type(check.get("passed")) is not bool
                    or check.get("tests") != value["tests"] or not isinstance(check.get("summary"), str)
                    or not isinstance(check.get("source_digest"), str)
                    or not re.fullmatch(r"[a-f0-9]{64}", check["source_digest"])
                    or type(check.get("seconds")) not in {int, float}
                    or (check.get("exit_code") is not None and type(check["exit_code"]) is not int)):
                raise ValueError()
        if review is not None and (not isinstance(review, dict) or not isinstance(review.get("reviewed_by"), str)
                                   or not review["reviewed_by"].strip() or not isinstance(review.get("reviewed_at"), str)):
            raise ValueError()
        if value["status"] in {"checked", "active"} and (not check or check["passed"] is not True):
            raise ValueError()
        if value["status"] == "active" and not review:
            raise ValueError()
        if value.get("durable_fix") is not None:
            fix = value["durable_fix"]
            if (not isinstance(fix, dict) or not re.fullmatch(r"[a-f0-9]{24}", str(fix.get("proposal_id", "")))
                    or fix.get("state") not in {"staged", "applying", "check_failed", "interrupted", "applied"}
                    or not isinstance(fix.get("by"), str)):
                raise ValueError()
        history = value.get("durable_history", [])
        if (not isinstance(history, list) or len(history) > 20
                or any(not isinstance(item, str) or not re.fullmatch(r"[a-f0-9]{24}", item) for item in history)):
            raise ValueError()
        if value["status"] == "retired":
            retired = value.get("retirement") or {}
            if (not isinstance(retired, dict) or not retired.get("retired_by") or not retired.get("retired_at")
                    or retired.get("previous_status") not in {"proposed", "checked", "check_failed", "active"}
                    or not re.fullmatch(r"[a-f0-9]{24}", str(retired.get("owner_id", "")))
                    or not re.fullmatch(r"[a-f0-9]{24}", str(retired.get("proposal_id", "")))
                    or not re.fullmatch(r"[a-f0-9]{64}", str(retired.get("application_digest", "")))):
                raise ValueError()
        value["digest"] = expected
        return value
    except (ValueError, TypeError, KeyError, AttributeError, RecursionError, yaml.YAMLError):
        raise ValueError("The improvement record is unreadable or changed. Review its branch file.") from None


def read_correction(root, record_id):
    """Hash actual bytes on every read; reuse only their exact validated parse."""
    global _VALIDATED_BYTES
    path = _record_path(root, record_id)
    if not path.is_file() or path.stat().st_size > MAX_CORRECTION_BYTES:
        raise ValueError("The improvement record is missing or too large.")
    raw = path.read_bytes()
    if len(raw) > MAX_CORRECTION_BYTES:
        raise ValueError("The improvement record is missing or too large.")
    key = (record_id, hashlib.sha256(raw).hexdigest(), digest(DEFAULT_TESTS))
    with _CACHE_LOCK:
        cached = _VALIDATED_RECORDS.get(key)
        if cached is not None:
            _VALIDATED_RECORDS.move_to_end(key)
            value = copy.deepcopy(cached[0])
        else:
            try:
                value = _parse_correction(raw.decode("utf-8"), record_id)
            except UnicodeError:
                raise ValueError("The improvement record must be readable UTF-8 text.") from None
            _VALIDATED_RECORDS[key] = (copy.deepcopy(value), len(raw))
            _VALIDATED_BYTES += len(raw)
            while _VALIDATED_BYTES > MAX_CACHE_BYTES or len(_VALIDATED_RECORDS) > 4096:
                _, (_, size) = _VALIDATED_RECORDS.popitem(last=False)
                _VALIDATED_BYTES -= size
    if path.parent.name == "history" and value["status"] not in {"withdrawn", "retired"}:
        raise ValueError("Only terminal correction records belong in history. Resolve this branch record before continuing.")
    return value


def correction_snapshot(root, *, include_history=True):
    """A bounded validated index; merged live overflow stays readable for review.

    The 500-record limit governs new unfinished work, not branch reads. History
    stays addressable for provenance and idempotency but is outside hot guidance.
    Cached parsing is keyed by content hashes, never timestamps or expiry times.
    """
    base = Path(root).resolve(strict=True)
    folders = [_safe(base, CORRECTIONS)]
    if include_history:
        folders.append(_safe(base, CORRECTION_HISTORY))
    paths = sorted(path for folder in folders if folder.is_dir() for path in folder.glob("*.yaml"))
    if len(paths) > MAX_LIBRARY_RECORDS or sum(path.stat().st_size for path in paths) > MAX_LIBRARY_BYTES:
        raise ValueError("The correction history exceeds its bounded local reader. Review its branch records before continuing.")
    ids = sorted({path.stem for path in paths})
    records = [read_correction(base, identifier) for identifier in ids]
    if paths != sorted(path for folder in folders if folder.is_dir() for path in folder.glob("*.yaml")):
        raise ValueError("The correction library changed while reading it. Refresh the current workflow.")
    return {"root": str(base), "include_history": include_history, "records": records,
            "by_id": {row["id"]: row for row in records}, "digest": digest([row["digest"] for row in records]),
            "unfinished": sum(row["status"] not in {"withdrawn", "retired"} for row in records),
            "terminal": sum(row["status"] in {"withdrawn", "retired"} for row in records)}


def corrections(root):
    return correction_snapshot(root)["records"]


def _write_correction(root, value):
    path = _record_path(root, value["id"])
    value = {key: item for key, item in value.items() if key != "digest"}
    value["digest"] = digest(value)
    if path.parent.name == "history":
        existing = read_correction(root, value["id"])
        if existing["digest"] != value["digest"]:
            raise ValueError("Archived correction history is immutable. Record a new correction for a new observation.")
        return existing
    raw = yaml.safe_dump(value, sort_keys=False, allow_unicode=True).encode()
    if len(raw) > MAX_CORRECTION_BYTES:
        raise ValueError("Keep the reusable correction within its size limit.")
    path.parent.mkdir(parents=True, exist_ok=True)
    _record_path(root, value["id"])
    temp_path = None
    try:
        with tempfile.NamedTemporaryFile(dir=path.parent, suffix=".tmp", delete=False) as handle:
            temp_path = Path(handle.name)
            handle.write(raw)
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temp_path, path)
    finally:
        if temp_path and temp_path.exists():
            temp_path.unlink()
    return value


@lru_cache(maxsize=1)
def _process_locks():
    path = Path(__file__).resolve().parents[1] / "portal/local_process_lock.py"
    spec = importlib.util.spec_from_file_location("rwd_learning_process_locks", path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def _lock_path(root, record_id):
    return _record_locations(root, record_id)[0].with_suffix(".lock")


def lock_status(root, record_id):
    return _process_locks().lock_status(_lock_path(root, record_id), root)


def recover_lock(root, record_id, *, confirmed=False):
    return _process_locks().recover_lock(_lock_path(root, record_id), root, confirmed=confirmed)


@contextmanager
def _locked(root, record_id):
    with _process_locks().locked(_lock_path(root, record_id), root) as owner:
        yield owner


def archive_correction(root, record_id, expected_digest, by):
    """Explicit terminal-only separation; preserve identical bytes and stable IDs."""
    if not isinstance(by, str) or not by.strip() or len(by) > 200:
        raise ValueError("Name the local reviewer archiving this terminal history.")
    with _locked(root, digest("library-admission")[:24]), _locked(root, record_id):
        row = read_correction(root, record_id)
        if row["digest"] != expected_digest or row["status"] not in {"withdrawn", "retired"}:
            raise ValueError("Only the exact reviewed retired or withdrawn correction can move to history.")
        live, historical = _record_locations(root, record_id)
        if historical.exists() and not live.exists():
            return {"record": row, "changed": False, "path": correction_relative_path(root, record_id),
                    "previous_path": live.relative_to(Path(root).resolve()).as_posix()}
        raw = live.read_bytes()
        historical.parent.mkdir(parents=True, exist_ok=True)
        _record_locations(root, record_id)
        if not historical.exists():
            os.link(live, historical)  # Complete bytes before removal; never overwrite a merged archive.
        if historical.read_bytes() != raw or live.read_bytes() != raw:
            raise ValueError("The terminal correction changed during archival. Its branch bytes were preserved.")
        live.unlink()
        return {"record": row, "changed": True, "path": correction_relative_path(root, record_id),
                "previous_path": live.relative_to(Path(root).resolve()).as_posix()}


def _fresh_correction(root, record_id, expected_digest):
    value = read_correction(root, record_id)
    if value["digest"] != expected_digest:
        raise ValueError("This correction changed. Review its current version before continuing.")
    if value["skill_sha256"] != _skill_hash(root, value["skill"]):
        raise ValueError("The skill changed. Record a correction against its current version.")
    return value


def propose_correction(root, skill, wrong, right, context, by, eval_goal, *, check_text=None, scope=None, provenance=None):
    """Explicit, sanitized reusable software feedback; never automatic chat export."""
    values = {"wrong": wrong, "right": right, "context": context, "created_by": by,
              "eval_goal": eval_goal}
    for key, text in values.items():
        if not isinstance(text, str) or not text.strip() or len(text) > (200 if key == "created_by" else 1800):
            raise ValueError("Enter a concise observation, correction, context, example request and local author.")
        values[key] = text.strip()
    extras = {}
    if scope is not None:
        extras["scope"] = _scope_value(scope)
    if provenance is not None:
        extras["provenance"] = _provenance_value(provenance)
    (check_text or _ingress)(_plain({**values, **extras}))
    skill_hash = _skill_hash(root, skill)
    fingerprint = digest({"skill": skill, "skill_sha256": skill_hash, **values, **extras})
    observation = (extras.get("provenance") or {}).get("observation_id")
    # One short store admission transaction covers both deduplication and the
    # unfinished-work limit. Per-new-UUID locks alone cannot enforce either.
    with _locked(root, digest("library-admission")[:24]):
        snapshot = correction_snapshot(root)
        for row in snapshot["records"]:
            # Replaying an archived interaction is idempotent; a new observation
            # may still report a regression after its earlier durable fix.
            same_observation = bool(observation)
            if (same_observation and row["status"] in {"withdrawn", "retired"}
                    and row["skill"] == skill and row["created_by"] == values["created_by"]
                    and _scope_value(row.get("scope")) == _scope_value(extras.get("scope"))
                    and (row.get("provenance") or {}).get("observation_id") == observation):
                return row
            if row.get("fingerprint") == fingerprint and (row["status"] not in {"withdrawn", "retired"} or same_observation):
                return row
        if snapshot["unfinished"] >= MAX_CORRECTIONS:
            raise ValueError("Review or retire unfinished corrections before adding more. Merged records remain readable; terminal history does not consume this limit.")
        value = {"schema": 1, "id": uuid.uuid4().hex[:24], "skill": skill,
                 "skill_sha256": skill_hash, "created_at": datetime.now(timezone.utc).isoformat(),
                 **values, **extras, "fingerprint": fingerprint, "status": "proposed",
                 "tests": list(DEFAULT_TESTS[skill]), "check": None, "review": None,
                 "authority": "Reusable workflow guidance; never scientific evidence, approval or executable code."}
        with _locked(root, value["id"]):
            return _write_correction(root, value)


def software_digest(root, *, overrides=None):
    """Bind a check to local implementation and test bytes, excluding run exhaust."""
    hashed = hashlib.sha256()
    overrides = dict(overrides or {})
    if any(not isinstance(key, str) or not isinstance(value, bytes) or len(value) > 2_000_000 for key, value in overrides.items()):
        raise ValueError("Software digest replacements must be exact relative file bytes.")
    for name in overrides:
        _safe(root, name)
    observed = set()
    count, total = 0, 0
    for directory in ("experiments/agent", "experiments/portal", "platform/engine", "platform/tools", "platform/tests", "platform/databricks", "resources", ".github/workflows", ".claude/skills"):
        base = _safe(root, directory)
        for path in sorted(base.rglob("*")):
            parts = path.relative_to(base).parts
            if any(part.startswith(".") or part in {"__pycache__", "runs", "candidates", "knowledge", "node_modules"} for part in parts):
                continue
            if not path.is_file() or path.suffix not in {".py", ".yaml", ".yml", ".json", ".md"}:
                continue
            if path.resolve() != path or path.stat().st_size > 2_000_000:
                raise ValueError("A software check input is redirected or exceeds its size limit.")
            relative = path.relative_to(Path(root).resolve()).as_posix()
            raw = overrides.get(relative, path.read_bytes())
            observed.add(relative)
            count += 1
            total += len(raw)
            if count > 4000 or total > 32_000_000:
                raise ValueError("The software check exceeds the supported local source limit.")
            hashed.update(relative.encode())
            hashed.update(hashlib.sha256(raw).digest())
    for name in ("pytest.ini", "pyproject.toml", "requirements.txt", "requirements-dev.txt", "platform/capabilities.yaml"):
        path = _safe(root, name)
        if path.is_file():
            hashed.update(name.encode())
            hashed.update(overrides.get(name, path.read_bytes()))
            observed.add(name)
    if set(overrides) - observed:
        raise ValueError("A proposed software byte replacement is outside the canonical digest inputs.")
    return hashed.hexdigest()


def check_correction(root, record_id, expected_digest, selectors, *, runner=None):
    """Run the existing skill tests with a fixed argv; no model or generated code."""
    with _locked(root, record_id):
        value = _fresh_correction(root, record_id, expected_digest)
        if value["status"] not in {"proposed", "checked", "check_failed", "active"}:
            raise ValueError("Only an unfinished or active correction can be checked.")
        if _scope_value(value.get("scope"))["kind"] == "legacy_context":
            raise ValueError("Resolve the original lesson's scope before running its checks.")
        was_active = value["status"] == "active"
        if selectors != DEFAULT_TESTS[value["skill"]]:
            raise ValueError("Use the registered regression checks for this skill.")
        for selector in selectors:
            path = _safe(root, selector)
            if not path.is_file() or path.suffix != ".py":
                raise ValueError("Restore the registered regression test before checking this correction.")
        before = software_digest(root)
        started = time.monotonic()
        try:
            # Retain an exit/result summary only: test output can contain source data.
            argv = [sys.executable, "-m", "pytest", *selectors, "-q", "--disable-warnings"]
            if runner is not None:
                result = runner(argv, cwd=str(root), timeout_s=180)
            else:
                result = subprocess.run(argv, cwd=root, stdin=subprocess.DEVNULL,
                    stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=180,
                    **({"creationflags": subprocess.CREATE_NO_WINDOW} if os.name == "nt" else {}))
            code = result.returncode
        except (OSError, subprocess.SubprocessError):
            code = None
        after = software_digest(root)
        _fresh_correction(root, record_id, expected_digest)
        passed = code == 0 and before == after
        value.update(status=("active" if was_active else "checked") if passed else "check_failed", check={
            "passed": passed, "exit_code": code, "source_digest": before,
            "seconds": round(time.monotonic() - started, 2), "tests": list(selectors),
            "checked_at": datetime.now(timezone.utc).isoformat(),
            "summary": "Registered software regressions passed." if passed else
                       "Checks failed, timed out, or inputs changed. Inspect the registered tests in VS Code and check again.",
            "limits": "These tests check software behavior. They do not adjudicate this lesson's scientific meaning or execute a patient-data pipeline."})
        if was_active and not passed:
            value["review"] = None
        return _write_correction(root, value)


def activate_correction(root, record_id, expected_digest, by):
    with _locked(root, record_id):
        value = _fresh_correction(root, record_id, expected_digest)
        if _scope_value(value.get("scope"))["kind"] == "legacy_context":
            raise ValueError("Resolve the original lesson's scope before checking and enabling its guidance.")
        check = value.get("check") or {}
        if (value["status"] != "checked" or check.get("passed") is not True
                or check.get("tests") != DEFAULT_TESTS[value["skill"]]
                or check.get("source_digest") != software_digest(root)):
            raise ValueError("Run passing regression checks on the current software before activating this reviewed correction.")
        value.update(status="active", review={"reviewed_by": by, "reviewed_at": datetime.now(timezone.utc).isoformat()})
        return _write_correction(root, value)


def withdraw_correction(root, record_id, expected_digest, by):
    with _locked(root, record_id):
        value = read_correction(root, record_id)
        if value["digest"] != expected_digest:
            raise ValueError("This correction changed. Refresh before withdrawing it.")
        if value["status"] == "retired":
            raise ValueError("This lesson was replaced by a reviewed durable fix. Its history remains available; record a new correction if the fix needs revision.")
        value.update(status="withdrawn", withdrawn_by=by, withdrawn_at=datetime.now(timezone.utc).isoformat())
        return _write_correction(root, value)


def correction_content_digest(row):
    """Staging metadata does not change the reviewed lesson's meaning or status."""
    return digest({key: value for key, value in row.items()
                   if key not in {"digest", "durable_fix", "durable_history"}})


def repeated_corrections(root):
    """Conservative exact-content groups; request reruns are not new observations."""
    groups = {}
    normalize = lambda text: " ".join(str(text).casefold().split())
    for row in correction_snapshot(root, include_history=False)["records"]:
        if row["status"] in {"retired", "withdrawn"}:
            continue
        key = digest({"skill": row["skill"], "scope": _scope_value(row.get("scope")),
                      "context": normalize(row["context"]), "right": normalize(row["right"])})
        group = groups.setdefault(key, {"id": key[:24], "skill": row["skill"],
            "scope": _scope_value(row.get("scope")), "record_ids": [], "observations": set()})
        group["record_ids"].append(row["id"])
        observation = (row.get("provenance") or {}).get("observation_id")
        if isinstance(observation, str) and re.fullmatch(r"[a-f0-9]{64}", observation):
            group["observations"].add(observation)
    return [{"id": group["id"], "skill": group["skill"], "scope": group["scope"],
             "record_ids": sorted(group["record_ids"]), "independent_observations": len(group["observations"]),
             "notice": "Matching reviewed wording and scope; confirm that these independent observations share the same cause."}
            for group in groups.values() if len(group["observations"]) >= 2]


def _matches_retirement(row, application):
    retirement = row.get("retirement") or {}
    original = {key: item for key, item in row.items() if key != "retirement"}
    original["status"] = retirement.get("previous_status")
    return (row["status"] == "retired" and retirement.get("owner_id") == application["owner_id"]
            and retirement.get("proposal_id") == application["proposal_id"]
            and retirement.get("application_digest") == application["digest"]
            and correction_content_digest(original) == application["linked_bindings"].get(row["id"]))


def retire_corrections(root, owner_id, proposal_id, by):
    """Retire a group only against its installed, current canonical application."""
    if not isinstance(by, str) or not by.strip() or len(by) > 200:
        raise ValueError("Name the reviewer who checked the durable replacement.")
    base = Path(__file__).resolve().parents[2]
    sys.path.insert(0, str(base / "experiments/portal"))
    import workflow_durable_fixes as durable
    import delivery_binding
    application = durable.validate_application(root, owner_id, proposal_id)
    ids = sorted(application["linked_bindings"])
    with ExitStack() as locks:
        for identifier in ids:
            locks.enter_context(_locked(root, identifier))
        application = durable.validate_application(root, owner_id, proposal_id)
        rows = [read_correction(root, identifier) for identifier in ids]
        for row in rows:
            if row["status"] == "retired":
                if not _matches_retirement(row, application):
                    raise ValueError("A retired lesson no longer matches this exact durable application. Preserve its history and review the branch.")
            elif (row["status"] == "withdrawn"
                    or correction_content_digest(row) != application["linked_bindings"][row["id"]]):
                raise ValueError("A linked lesson changed after the durable review. No lesson was retired.")
        if all(row["status"] == "retired" for row in rows):
            return rows
        at = datetime.now(timezone.utc).isoformat()
        files, updated = [], []
        for row in rows:
            if row["status"] == "retired":
                updated.append(row)
                continue
            path = _record_path(root, row["id"])
            before = path.read_bytes().decode("utf-8")
            value = {key: item for key, item in row.items() if key != "digest"}
            value.update(status="retired", retirement={"owner_id": owner_id, "proposal_id": proposal_id,
                "application_digest": application["digest"], "retired_by": by.strip(), "retired_at": at,
                "previous_status": row["status"],
                "notice": "Replaced by the exact installed reviewed change and its passing checks. Retained as history; no longer prompt guidance."})
            if row["id"] == owner_id:
                value["durable_fix"] = {"proposal_id": proposal_id, "state": "applied", "by": by.strip()}
            value["digest"] = digest(value)
            after = yaml.safe_dump(value, sort_keys=False, allow_unicode=True)
            if len(after.encode()) > MAX_CORRECTION_BYTES:
                raise ValueError("The retirement history exceeds the correction size limit.")
            files.append({"path": path.relative_to(Path(root).resolve()).as_posix(), "before": before,
                "before_sha256": hashlib.sha256(before.encode()).hexdigest(), "after": after})
            updated.append(value)
        # The existing transaction owns and restores only exact bytes it wrote.
        durable.validate_application(root, owner_id, proposal_id)
        delivery_binding._replace_files(Path(root).resolve(), files)
        return updated


def resolve_legacy_scope(root, record_id, expected_digest, scope, by):
    """An explicit local review resolves only an unfinished legacy import's scope."""
    resolved = _scope_value(scope)
    if resolved["kind"] == "legacy_context" or not isinstance(by, str) or not 0 < len(by.strip()) <= 200:
        raise ValueError("Choose a global or explicit product scope and name its local reviewer.")
    with _locked(root, record_id):
        value = _fresh_correction(root, record_id, expected_digest)
        if (value["status"] != "proposed" or _scope_value(value.get("scope"))["kind"] != "legacy_context"
                or (value.get("provenance") or {}).get("entrypoint") != "legacy_import"):
            raise ValueError("Only a proposed legacy import with unresolved scope can be resolved here. Record a new correction for other changes.")
        provenance = dict(value["provenance"])
        provenance["scope_resolution"] = {"by": by.strip(), "at": datetime.now(timezone.utc).isoformat(), "from": value["scope"]}
        _ingress(_plain({"scope": resolved, "provenance": provenance}))
        value.update(scope=resolved, provenance=provenance, check=None, review=None)
        value["fingerprint"] = digest({key: value[key] for key in ("skill", "skill_sha256", "wrong", "right", "context", "created_by", "eval_goal", "scope", "provenance")})
        return _write_correction(root, value)


LEGACY_LESSONS = Path("experiments/agent/knowledge/lessons.yaml")
LEGACY_CASES = Path("experiments/agent/evals/cases.yaml")
MAX_LEGACY_BYTES = 512_000


def _legacy_read(root, relative, *, json_file=False):
    path = _safe(root, relative)
    if not path.exists():
        return ([] if not json_file else {}), None
    if not path.is_file() or path.stat().st_size > MAX_LEGACY_BYTES:
        raise ValueError("The historical learning source is missing or exceeds its import limit.")
    try:
        raw = path.read_bytes()
        text = raw.decode("utf-8-sig")
        if not json_file and any(isinstance(token, (yaml.AliasToken, yaml.AnchorToken)) for token in yaml.scan(text)):
            raise ValueError()
        value = json.loads(text) if json_file else yaml.safe_load(text)
        return value, hashlib.sha256(raw).hexdigest()
    except (ValueError, TypeError, RecursionError, yaml.YAMLError):
        raise ValueError("A historical learning source is unreadable. Repair its branch file before importing.") from None


def preview_legacy(root, *, skill="operate-rwd-product", skill_by_id=None, scope_by_id=None, check_text=None):
    """Read-only, digest-bound import plan. Historical files never become live guidance."""
    lessons, source_digest = _legacy_read(root, LEGACY_LESSONS)
    cases, cases_digest = _legacy_read(root, LEGACY_CASES)
    if (not isinstance(lessons, list) or len(lessons) > MAX_CORRECTIONS
            or not isinstance(cases, list) or len(cases) > 2000):
        raise ValueError("Historical lessons and evaluation cases must be bounded lists.")
    skill_by_id, scope_by_id = skill_by_id or {}, scope_by_id or {}
    if not isinstance(skill_by_id, dict) or not isinstance(scope_by_id, dict):
        raise ValueError("Choose each lesson's skill and scope by its original identifier.")
    existing = corrections(root)
    imported = {}
    for record in existing:
        provenance = record.get("provenance") or {}
        if provenance.get("entrypoint") == "legacy_import":
            key = provenance.get("legacy_key")
            if key in imported:
                raise ValueError("Multiple correction records claim the same historical lesson. Review the branch merge before importing.")
            imported[key] = record
    rows, seen, hashes = [], set(), {LEGACY_LESSONS.as_posix(): source_digest, LEGACY_CASES.as_posix(): cases_digest}
    for original in lessons:
        if not isinstance(original, dict):
            raise ValueError("Each historical lesson must be a record.")
        lid = original.get("id")
        if not isinstance(lid, str) or not re.fullmatch(r"[A-Za-z0-9_-]{1,80}", lid) or lid in seen:
            raise ValueError("Historical lessons must have unique, safe identifiers.")
        seen.add(lid)
        values = {}
        for source, target in (("context", "context"), ("wrong", "wrong"), ("right", "right"), ("corrected_by", "source_by"), ("recorded", "source_date")):
            text = original.get(source)
            if source == "recorded" and isinstance(text, (datetime, date)):
                text = text.isoformat()
            if not isinstance(text, str) or not text.strip() or len(text) > 1800:
                raise ValueError("A historical lesson is missing its bounded wording, author, context or date.")
            values[target] = text.strip()
        chosen = skill_by_id.get(lid, skill)
        skill_hash = _skill_hash(root, chosen)
        scope = _scope_value(scope_by_id.get(lid, {"kind": "legacy_context", "context": values["context"]}))
        matching = [case for case in cases if isinstance(case, dict) and case.get("id") == "lesson-" + lid.lower()]
        if len(matching) > 1:
            raise ValueError("A historical lesson has duplicate evaluation cases. Review them before importing.")
        case = matching[0] if matching else None
        goal = case.get("goal") if case else f"Context: {values['context']}. Assess this assertion: {values['wrong']}"
        if not isinstance(goal, str) or not goal.strip() or len(goal) > 1800:
            raise ValueError("The historical example request exceeds the correction's supported size.")
        governed_path = Path("experiments/agent/candidates") / ("governed_entry_" + lid + ".json")
        governed, governed_digest = _legacy_read(root, governed_path, json_file=True)
        if governed_digest and (not isinstance(governed, dict) or governed.get("from_lesson") != lid):
            raise ValueError("A historical governed proposal belongs to a different lesson.")
        hashes[governed_path.as_posix()] = governed_digest
        key = digest({"source": LEGACY_LESSONS.as_posix(), "id": lid})
        provenance = {"entrypoint": "legacy_import", "legacy_key": key,
            "source": LEGACY_LESSONS.as_posix(), "source_sha256": source_digest,
            "legacy_id": lid, "source_by": values["source_by"], "source_date": values["source_date"],
            "original_context": values["context"], "original_authority": original.get("authority"),
            "legacy_lesson": {**original, "recorded": values["source_date"]},
            "legacy_eval_case": case, "governed_destination": governed.get("destination") if governed else None,
            "legacy_governed_proposal": governed if governed else None}
        _provenance_value(provenance)
        (check_text or _ingress)(_plain({**values, "eval_goal": goal, "scope": scope, "provenance": provenance}))
        previous = imported.get(key)
        rows.append({"id": lid, **values, "skill": chosen, "scope": scope, "eval_goal": goal.strip(),
            "skill_sha256": skill_hash, "provenance": provenance,
            "imported_id": previous["id"] if previous else None,
            "imported_status": previous["status"] if previous else None,
            "source_changed": bool(previous and (previous.get("provenance") or {}).get("legacy_lesson") != provenance["legacy_lesson"])})
    if (set(skill_by_id) | set(scope_by_id)) - seen:
        raise ValueError("An import mapping names a lesson outside this preview.")
    intent = [{key: value for key, value in row.items() if key not in {"imported_id", "imported_status", "source_changed"}} for row in rows]
    return {"ok": True, "rows": rows, "digest": digest({"sources": hashes, "rows": intent}), "source_digest": source_digest,
        "notice": "Import creates proposed corrections only. Original files stay historical; checks, scope review and explicit activation are required."}


def import_legacy(root, *, expected_digest, by, skill="operate-rwd-product", skill_by_id=None, scope_by_id=None, check_text=None):
    if not isinstance(by, str) or not 0 < len(by.strip()) <= 200:
        raise ValueError("Name the local person importing these historical lessons.")
    (check_text or _ingress)(by)
    initial = preview_legacy(root, skill=skill, skill_by_id=skill_by_id, scope_by_id=scope_by_id, check_text=check_text)
    if initial["digest"] != expected_digest:
        raise ValueError("The historical sources or import choices changed. Review a fresh import preview.")
    # A shared import lock makes retries and concurrent imports idempotent.
    with _locked(root, digest("legacy-import")[:24]):
        preview = preview_legacy(root, skill=skill, skill_by_id=skill_by_id, scope_by_id=scope_by_id, check_text=check_text)
        if preview["digest"] != expected_digest:
            raise ValueError("The historical sources or import choices changed. Review a fresh import preview.")
        if correction_snapshot(root)["unfinished"] + sum(not row["imported_id"] for row in preview["rows"]) > MAX_CORRECTIONS:
            raise ValueError("Review unfinished corrections before importing more lessons. Terminal history does not consume this limit.")
        records, created = [], []
        for row in preview["rows"]:
            if row["imported_id"]:
                records.append(read_correction(root, row["imported_id"]))
                continue
            provenance = {**row["provenance"], "imported_by": by.strip()}
            record = propose_correction(root, row["skill"], row["wrong"], row["right"], row["context"],
                by.strip(), row["eval_goal"], check_text=check_text, scope=row["scope"], provenance=provenance)
            records.append(record)
            created.append(record["id"])
        return {"ok": True, "records": records, "created_ids": created,
                "notice": "Historical lessons imported for review; none were activated."}


def active_corrections(root, skill=None, *, packs=None, include_scoped=False, _snapshot=None):
    """Current reviewed lessons, read at request time; malformed stores fail closed."""
    result = []
    snapshot = _snapshot if _snapshot is not None else correction_snapshot(root, include_history=False)
    if snapshot.get("root") != str(Path(root).resolve(strict=True)):
        raise ValueError("The validated correction snapshot belongs to a different checkout.")
    for value in snapshot["records"]:
        if value["status"] != "active" or (skill and value["skill"] != skill):
            continue
        scope = _scope_value(value.get("scope"))
        if not include_scoped and scope["kind"] != "global":
            if scope["kind"] != "packs" or not set(scope["packs"]).intersection(packs or []):
                continue
        check = value.get("check") or {}
        if (value["skill_sha256"] == _skill_hash(root, value["skill"])
                and check.get("passed") is True and value.get("review", {}).get("reviewed_by")
                and check.get("tests") == DEFAULT_TESTS[value["skill"]]):
            result.append(value)
    return sorted(result, key=lambda value: (value["created_at"], value["id"]), reverse=True)


def correction_cases(root):
    """Review examples join the existing scorer; they are never unseen holdouts."""
    return [{"id": "correction-" + row["id"], "goal": row["eval_goal"],
             "expect": {"outcome": ["done", "escalated"]}, "source": "learning-loop " + row["id"],
             "skill": row["skill"], "provenance": "human", "adjudicated": False,
             "evidence_mode": "reviewed_workflow_correction", "training_eligible": False,
             "scope": _scope_value(row.get("scope")),
             "adjudicate": "Review semantic adherence to: " + row["right"] + ". An outcome code alone is not correctness."}
            for row in active_corrections(root, include_scoped=True)
            if _scope_value(row.get("scope"))["kind"] != "legacy_context"]


if __name__ == "__main__":
    ap = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    ap.add_argument("--wrong", required=True)
    ap.add_argument("--right", required=True)
    ap.add_argument("--context", required=True)
    ap.add_argument("--by", required=True, help="who made the correction (a person)")
    ap.add_argument("--eval-goal", default=None, help="override the drafted eval goal")
    ap.add_argument("--governed", default=None,
                    help="destination for a governed-entry proposal, e.g. 'precedent store'")
    ap.add_argument("--skill", default="operate-rwd-product", choices=sorted(DEFAULT_TESTS), help="Workflow skill for this proposed correction")
    ap.add_argument("--root", default=None, help="Local checkout containing the correction library")
    ap.add_argument("--pack", action="append", help="Limit this guidance to an explicit product/reference path; repeat for multiple paths")
    a = ap.parse_args()
    r = record_lesson(a.wrong, a.right, a.context, a.by, a.eval_goal, a.governed,
        root=a.root, skill=a.skill, scope={"kind": "packs", "packs": a.pack} if a.pack else None)
    print(json.dumps(r, indent=1))
