'use strict';

const crypto = require('node:crypto');
const fs = require('node:fs');
const http = require('node:http');
const os = require('node:os');
const path = require('node:path');
const {execFileSync} = require('node:child_process');

const MAX_BODY_BYTES = 24000;
const MAX_CONTEXT_BYTES = 18000;
const MAX_REPLY_BYTES = 24000;
const MAX_OUTPUT_TOKENS = 2000;
const MAX_TIMEOUT_MS = 45000;
const MAX_STREAM_PARTS = 8192;
const IGNORED_DATA_TYPES = new Set(['usage', 'stateful_marker']);

class Refusal extends Error {
  constructor(code) { super(code); this.code = code; }
}

const GPT5_MINI_NAMES = new Set(['gpt-5-mini', 'gpt-5-mini-2025-08-07', 'gpt-5 mini', 'gpt 5 mini']);

function modelKind(model) {
  const labels = ['id', 'name', 'family'].map(field => typeof model[field] === 'string' ? model[field].trim().toLowerCase() : '');
  if (labels.some(label => /sonnet/i.test(label))) return 'sonnet';
  return labels.some(label => GPT5_MINI_NAMES.has(label)) ? 'gpt-5-mini' : '';
}

function metadata(model) {
  const result = {};
  for (const field of ['id', 'name', 'family', 'vendor', 'version']) {
    const value = model[field] || '';
    if (typeof value !== 'string' || (field !== 'version' && !value.trim()) || [...value].length > 180 ||
        /[\p{C}\p{Z}]/u.test(value.replace(/ /g, '')) ||
        /\bsk-(?:ant-)?[A-Za-z0-9_-]{12,}|\b(?:api[_ -]?key|access[_ -]?token|authorization)\s*[:=]\s*\S+/i.test(value)) throw new Refusal('model_unavailable');
    result[field] = value;
  }
  if (!result.id || !modelKind(result)) throw new Refusal('model_unavailable');
  return result;
}

function exactKeys(value, keys) {
  return value && typeof value === 'object' && !Array.isArray(value) &&
    Object.keys(value).length === keys.length && keys.every(key => Object.hasOwn(value, key));
}

function canonical(value) {
  if (typeof value !== 'string') throw new Refusal('workspace_mismatch');
  try { return fs.realpathSync(value); } catch { throw new Refusal('workspace_mismatch'); }
}

function validateRequest(value, workspaceRoot) {
  if (!exactKeys(value, ['system', 'transcript', 'max_output_tokens', 'timeout_ms', 'workspace_root']) ||
      typeof value.system !== 'string' || !value.system.trim() || !Array.isArray(value.transcript) || value.transcript.length !== 1 ||
      !exactKeys(value.transcript[0], ['role', 'content']) || value.transcript[0].role !== 'user' ||
      typeof value.transcript[0].content !== 'string' || !value.transcript[0].content.trim() ||
      !Number.isInteger(value.max_output_tokens) || value.max_output_tokens < 1 || value.max_output_tokens > MAX_OUTPUT_TOKENS ||
      !Number.isInteger(value.timeout_ms) || value.timeout_ms < 1000 || value.timeout_ms > MAX_TIMEOUT_MS) throw new Refusal('invalid_request');
  if (canonical(value.workspace_root) !== workspaceRoot) throw new Refusal('workspace_mismatch');
  if (Buffer.byteLength(value.system) + Buffer.byteLength(value.transcript[0].content) > MAX_CONTEXT_BYTES) throw new Refusal('request_too_large');
  return value;
}

function safeCode(error) {
  if (error instanceof Refusal) return error.code;
  if (error && error.code === 'NoPermissions') return 'forbidden';
  if (error && error.code === 'NotFound') return 'model_unavailable';
  if (error && error.code === 'Blocked') return 'quota';
  return 'provider_error';
}

async function generate(vscode, model, request, activeTokens = new Set()) {
  const cancellation = new vscode.CancellationTokenSource();
  activeTokens.add(cancellation);
  let timer;
  try {
    // VS Code's stable API has no system role. Send the bounded instruction
    // string as a separate User message; no tools or workspace content added.
    const messages = [vscode.LanguageModelChatMessage.User(request.system),
      vscode.LanguageModelChatMessage.User(request.transcript[0].content)];
    const operation = (async () => {
      let inputTokens = 0;
      for (const message of messages) {
        const count = await model.countTokens(message, cancellation.token);
        if (!Number.isFinite(count) || count < 0) throw new Refusal('provider_error');
        inputTokens += count;
      }
      if (!Number.isFinite(model.maxInputTokens) || model.maxInputTokens < 1) throw new Refusal('model_unavailable');
      if (inputTokens > model.maxInputTokens) throw new Refusal('request_too_large');
      const response = await model.sendRequest(messages, {
        justification: 'Suggest answers for one RWD Portal scientific row. No tools, file edits or approvals are available.'
      }, cancellation.token);
      let text = '', parts = 0;
      for await (const part of response.stream) {
        if (++parts > MAX_STREAM_PARTS) throw new Refusal('response_too_large');
        // VS Code emits reasoning and provider bookkeeping alongside final text.
        // Ignore only these known API types, without inspecting their payloads.
        // Keep the full stream so tool calls and other content are still refused.
        if (typeof vscode.LanguageModelThinkingPart === 'function' &&
            part instanceof vscode.LanguageModelThinkingPart) continue;
        if (typeof vscode.LanguageModelDataPart === 'function' &&
            part instanceof vscode.LanguageModelDataPart && IGNORED_DATA_TYPES.has(part.mimeType)) continue;
        if (!(part instanceof vscode.LanguageModelTextPart) || typeof part.value !== 'string') throw new Refusal('unsupported_response');
        text += part.value;
        if (Buffer.byteLength(text) > MAX_REPLY_BYTES) throw new Refusal('response_too_large');
        const count = await model.countTokens(text, cancellation.token);
        if (!Number.isFinite(count) || count < 0) throw new Refusal('provider_error');
        if (count > request.max_output_tokens) throw new Refusal('response_too_large');
      }
      if (!text.trim()) throw new Refusal('provider_error');
      return text;
    })();
    const timeout = new Promise((_, reject) => {
      timer = setTimeout(() => { cancellation.cancel(); reject(new Refusal('timeout')); }, request.timeout_ms);
    });
    return await Promise.race([operation, timeout]);
  } finally {
    clearTimeout(timer);
    cancellation.cancel();
    cancellation.dispose();
    activeTokens.delete(cancellation);
  }
}

function secureDirectory(directory) {
  if (fs.existsSync(directory) && (!fs.lstatSync(directory).isDirectory() || fs.lstatSync(directory).isSymbolicLink())) throw new Refusal('forbidden');
  fs.mkdirSync(directory, {recursive: true, mode: 0o700});
  fs.chmodSync(directory, 0o700);
  if (process.platform === 'win32') {
    // chmod has limited meaning on Windows. Replace the private directory ACL
    // with a current-user-only ACL before creating any bearer descriptor.
    const script = '$ErrorActionPreference="Stop"; $ProgressPreference="SilentlyContinue"; $p=$env:RWD_BRIDGE_PRIVATE_DIR; $id=[System.Security.Principal.WindowsIdentity]::GetCurrent().Name; ' +
      '$acl=[System.Security.AccessControl.DirectorySecurity]::new(); $acl.SetAccessRuleProtection($true,$false); ' +
      '$rule=[System.Security.AccessControl.FileSystemAccessRule]::new($id,"FullControl","ContainerInherit,ObjectInherit","None","Allow"); ' +
      '$acl.SetAccessRule($rule); [System.IO.Directory]::SetAccessControl($p,$acl)';
    execFileSync(path.join(process.env.SystemRoot || 'C:\\Windows', 'System32', 'WindowsPowerShell', 'v1.0', 'powershell.exe'),
      ['-NoProfile', '-NonInteractive', '-EncodedCommand', Buffer.from(script, 'utf16le').toString('base64')],
      {windowsHide: true, timeout: 10000, stdio: 'ignore', env: {...process.env, RWD_BRIDGE_PRIVATE_DIR: directory}});
  }
}

function writeDescriptor(homeDir, descriptor) {
  const directory = path.join(canonical(homeDir), '.rwd-portal');
  secureDirectory(directory);
  const file = path.join(directory, 'vscode-model-bridge.json');
  if (fs.existsSync(file) && (!fs.lstatSync(file).isFile() || fs.lstatSync(file).isSymbolicLink())) throw new Refusal('forbidden');
  const temporary = path.join(directory, '.bridge-' + crypto.randomBytes(12).toString('hex') + '.tmp');
  try {
    fs.writeFileSync(temporary, JSON.stringify(descriptor), {encoding: 'utf8', flag: 'wx', mode: 0o600});
    fs.renameSync(temporary, file);
    fs.chmodSync(file, 0o600);
  } finally {
    if (fs.existsSync(temporary)) fs.unlinkSync(temporary);
  }
  return file;
}

async function startBridge({vscode, model, workspaceRoot, homeDir = os.homedir(), isWorkspaceOpen = () => true}) {
  workspaceRoot = canonical(workspaceRoot);
  const modelInfo = metadata(model);
  const token = crypto.randomBytes(32).toString('hex');
  const activeTokens = new Set();
  let active = true, busy = false, descriptorPath;
  const send = (response, status, body) => {
    if (!response.destroyed) {
      response.writeHead(status, {'Content-Type': 'application/json', 'Cache-Control': 'no-store', 'Connection': 'close'});
      response.end(JSON.stringify(body));
    }
  };
  const server = http.createServer(async (request, response) => {
    try {
      const port = server.address()?.port;
      const authorization = request.headers.authorization || '';
      const expected = 'Bearer ' + token;
      if (typeof authorization !== 'string' || authorization.length !== expected.length ||
          !crypto.timingSafeEqual(Buffer.from(authorization), Buffer.from(expected))) throw new Refusal('unauthorized');
      if (request.headers.origin || request.headers.host !== '127.0.0.1:' + port) throw new Refusal('forbidden');
      if (!active || !isWorkspaceOpen()) throw new Refusal('workspace_mismatch');
      if (request.method === 'GET' && request.url === '/health') {
        send(response, 200, {version: 1, workspace_root: workspaceRoot, model: modelInfo}); return;
      }
      if (request.method !== 'POST' || request.url !== '/generate') throw new Refusal('forbidden');
      if (request.headers['content-type']?.split(';')[0].trim() !== 'application/json') throw new Refusal('invalid_request');
      if (busy) throw new Refusal('busy');
      if (Number(request.headers['content-length'] || 0) > MAX_BODY_BYTES) throw new Refusal('request_too_large');
      const chunks = []; let total = 0;
      for await (const chunk of request) {
        total += chunk.length;
        if (total > MAX_BODY_BYTES) throw new Refusal('request_too_large');
        chunks.push(chunk);
      }
      let parsed;
      try { parsed = JSON.parse(Buffer.concat(chunks).toString('utf8')); } catch { throw new Refusal('invalid_request'); }
      const value = validateRequest(parsed, workspaceRoot);
      if (busy) throw new Refusal('busy');
      busy = true;
      try {
        const text = await generate(vscode, model, value, activeTokens);
        if (!active || !isWorkspaceOpen()) throw new Refusal('workspace_mismatch');
        send(response, 200, {text, model: modelInfo});
      } finally { busy = false; }
    } catch (error) {
      const code = safeCode(error);
      send(response, code === 'unauthorized' ? 401 : code === 'forbidden' ? 403 : 400, {error: {code}});
    }
  });
  server.requestTimeout = 5000;
  server.headersTimeout = 5000;
  await new Promise((resolve, reject) => { server.once('error', reject); server.listen(0, '127.0.0.1', resolve); });
  if (!isWorkspaceOpen()) { server.close(); throw new Refusal('workspace_mismatch'); }
  const descriptor = {version: 1, url: `http://127.0.0.1:${server.address().port}/generate`, port: server.address().port,
    token, workspace_root: workspaceRoot, model: modelInfo, created_at: new Date().toISOString()};
  try { descriptorPath = writeDescriptor(homeDir, descriptor); }
  catch { server.close(); throw new Refusal('forbidden'); }
  const dispose = () => {
    active = false;
    for (const cancellation of activeTokens) cancellation.cancel();
    server.close();
    server.closeAllConnections?.();
    try {
      const saved = JSON.parse(fs.readFileSync(descriptorPath, 'utf8'));
      if (saved.token === token) fs.unlinkSync(descriptorPath);
    } catch { /* A newer window owns the descriptor, or it is already gone. */ }
  };
  return {descriptor, descriptorPath, dispose};
}

module.exports = {Refusal, modelKind, metadata, validateRequest, safeCode, generate, startBridge, secureDirectory, MAX_OUTPUT_TOKENS, MAX_TIMEOUT_MS};
