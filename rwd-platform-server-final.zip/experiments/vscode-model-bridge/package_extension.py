"""Build a local, unsigned VSIX with only explicitly reviewed runtime files."""
from pathlib import Path
import json
import zipfile
from xml.sax.saxutils import escape

ROOT = Path(__file__).resolve().parent
manifest = json.loads((ROOT / "package.json").read_text(encoding="utf-8"))
version = manifest["version"]
output = ROOT / "dist" / f"{manifest['name']}-{version}.vsix"
output.parent.mkdir(exist_ok=True)
vsix_manifest = f'''<?xml version="1.0" encoding="utf-8"?>
<PackageManifest Version="2.0.0" xmlns="http://schemas.microsoft.com/developer/vsx-schema/2011">
 <Metadata><Identity Language="en-US" Id="{escape(manifest['name'])}" Version="{escape(version)}" Publisher="{escape(manifest['publisher'])}"/>
 <DisplayName>{escape(manifest['displayName'])}</DisplayName><Description xml:space="preserve">{escape(manifest['description'])}</Description>
 <Properties><Property Id="Microsoft.VisualStudio.Code.Engine" Value="{escape(manifest['engines']['vscode'])}"/></Properties></Metadata>
 <Installation><InstallationTarget Id="Microsoft.VisualStudio.Code"/></Installation><Dependencies/>
 <Assets><Asset Type="Microsoft.VisualStudio.Code.Manifest" Path="extension/package.json" Addressable="true"/>
 <Asset Type="Microsoft.VisualStudio.Services.Content.Details" Path="extension/README.md" Addressable="true"/></Assets>
</PackageManifest>'''
content_types = '''<?xml version="1.0" encoding="utf-8"?>
<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">
 <Default Extension="json" ContentType="application/json"/><Default Extension="js" ContentType="application/javascript"/>
 <Default Extension="md" ContentType="text/markdown"/><Default Extension="vsixmanifest" ContentType="text/xml"/>
</Types>'''
with zipfile.ZipFile(output, "w", compression=zipfile.ZIP_DEFLATED) as archive:
    archive.writestr("extension.vsixmanifest", vsix_manifest)
    archive.writestr("[Content_Types].xml", content_types)
    for name in ("package.json", "extension.js", "bridge.js", "README.md"):
        archive.write(ROOT / name, "extension/" + name)
print(output)
