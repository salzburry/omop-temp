'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs');
const http = require('node:http');
const os = require('node:os');
const path = require('node:path');
const test = require('node:test');
const vm = require('node:vm');
const {execFileSync} = require('node:child_process');
const bridge = require('../bridge');

class TextPart { constructor(value) { this.value = value; } }
class ThinkingPart { constructor(value) { this.value = value; } }
class DataPart { constructor(data, mimeType) { this.data = data; this.mimeType = mimeType; } }
class ToolCallPart { constructor() { this.name = 'unexpected_tool'; } }
class ToolResultPart { constructor() { this.content = []; } }
const cancellations = [];
const vscode = {
  LanguageModelTextPart: TextPart,
  LanguageModelThinkingPart: ThinkingPart,
  LanguageModelDataPart: DataPart,
  LanguageModelToolCallPart: ToolCallPart,
  LanguageModelToolResultPart: ToolResultPart,
  LanguageModelChatMessage: {User: content => ({role: 'user', content})},
  CancellationTokenSource: class {
    constructor() { this.token = {isCancellationRequested: false}; cancellations.push(this); }
    cancel() { this.token.isCancellationRequested = true; }
    dispose() {}
  }
};

function model(overrides = {}) {
  const calls = [];
  return {id: 'available-sonnet', name: 'Claude Sonnet from installed provider', family: 'claude-sonnet',
    vendor: 'actual-provider', version: 'test', maxInputTokens: 20000, calls,
    countTokens: async value => Math.ceil((typeof value === 'string' ? value : value.content).length / 4),
    sendRequest: async (messages, options, token) => {
      calls.push({messages, options, token});
      return {stream: (async function* () { yield new TextPart('{"suggestions":[]}'); })()};
    }, ...overrides};
}

function request(workspaceRoot, overrides = {}) {
  return {system: 'Use only the supplied scientific row.', transcript: [{role: 'user', content: 'A synthetic row'}],
    max_output_tokens: 2000, timeout_ms: 1000, workspace_root: workspaceRoot, ...overrides};
}

async function setup(t, selected = model(), isWorkspaceOpen = () => true) {
  const temporary = fs.mkdtempSync(path.join(os.tmpdir(), 'rwd-model-bridge-test-'));
  const workspace = path.join(temporary, 'repo'); fs.mkdirSync(workspace);
  let running;
  t.after(() => {
    if (!running) assert.equal(fs.existsSync(path.join(temporary, '.rwd-portal/vscode-model-bridge.json')), false);
    running?.dispose();
    const resolved = fs.realpathSync(temporary);
    assert.ok(resolved.startsWith(fs.realpathSync(os.tmpdir()) + path.sep));
    assert.ok(path.basename(resolved).startsWith('rwd-model-bridge-test-'));
    fs.rmSync(resolved, {recursive: true, force: true});
  });
  running = await bridge.startBridge({vscode, model: selected, workspaceRoot: workspace, homeDir: temporary, isWorkspaceOpen});
  return {running, workspace, selected, temporary};
}

function call(running, body, {method = 'POST', route = '/generate', headers = {}} = {}) {
  return new Promise((resolve, reject) => {
    const wire = body === undefined ? '' : JSON.stringify(body);
    const req = http.request({hostname: '127.0.0.1', port: running.descriptor.port, path: route, method,
      headers: {'Authorization': 'Bearer ' + running.descriptor.token, 'Content-Type': 'application/json',
        'Content-Length': Buffer.byteLength(wire), ...headers}}, response => {
      let text = '';
      response.on('data', part => { text += part; });
      response.on('end', () => resolve({status: response.statusCode, body: JSON.parse(text)}));
    });
    req.on('error', reject); req.end(wire);
  });
}

test('explicit bridge publishes only a private workspace/model descriptor and health performs no generation', async t => {
  const {running, workspace, selected} = await setup(t);
  const saved = JSON.parse(fs.readFileSync(running.descriptorPath, 'utf8'));
  assert.deepEqual(Object.keys(saved).sort(), ['created_at', 'model', 'port', 'token', 'url', 'version', 'workspace_root']);
  assert.equal(saved.workspace_root, fs.realpathSync(workspace));
  assert.match(saved.url, /^http:\/\/127\.0\.0\.1:\d+\/generate$/);
  assert.match(saved.token, /^[a-f0-9]{64}$/);
  if (process.platform !== 'win32') assert.equal(fs.statSync(running.descriptorPath).mode & 0o777, 0o600);
  else {
    const script = '$ErrorActionPreference="Stop"; $acl=[System.IO.File]::GetAccessControl($env:RWD_BRIDGE_TEST_ACL); ' +
      '$who=[System.Security.Principal.WindowsIdentity]::GetCurrent().Name; $count=0; $bad=0; ' +
      'foreach($entry in $acl.Access){$count++;if($entry.IdentityReference.Value -ne $who -or $entry.AccessControlType -ne "Allow"){$bad++}}; ' +
      '[Console]::WriteLine([string]$count+","+[string]$bad)';
    const result = execFileSync(path.join(process.env.SystemRoot, 'System32/WindowsPowerShell/v1.0/powershell.exe'),
      ['-NoProfile', '-NonInteractive', '-EncodedCommand', Buffer.from(script, 'utf16le').toString('base64')],
      {windowsHide: true, encoding: 'utf8', env: {...process.env, RWD_BRIDGE_TEST_ACL: running.descriptorPath}});
    const [count, other] = result.trim().split(',').map(Number);
    assert.ok(count > 0); assert.equal(other, 0);
  }
  const result = await call(running, undefined, {method: 'GET', route: '/health'});
  assert.equal(result.status, 200);
  assert.deepEqual(result.body, {version: 1, workspace_root: saved.workspace_root, model: saved.model});
  assert.equal(selected.calls.length, 0);
});

test('generation forwards only two text messages to chosen Sonnet with no tools', async t => {
  const {running, workspace, selected} = await setup(t);
  const result = await call(running, request(workspace));
  assert.equal(result.status, 200);
  assert.deepEqual(result.body.model, running.descriptor.model);
  assert.equal(selected.calls.length, 1);
  assert.deepEqual(selected.calls[0].messages, [
    {role: 'user', content: 'Use only the supplied scientific row.'}, {role: 'user', content: 'A synthetic row'}]);
  assert.deepEqual(Object.keys(selected.calls[0].options), ['justification']);
  assert.equal(selected.calls[0].token.isCancellationRequested, true);
});

test('unauthenticated requests, browser origins, host rebinding and unknown routes cannot reach the model', async t => {
  const {running, workspace, selected} = await setup(t);
  for (const options of [
    {headers: {Authorization: 'Bearer incorrect'}}, {headers: {Origin: 'http://malicious.example'}},
    {headers: {Host: 'malicious.example'}}, {route: '/files'}, {route: '/generate?tool=shell'}, {method: 'PUT'},
    {headers: {'Content-Type': 'text/plain'}}
  ]) {
    const result = await call(running, request(workspace), options);
    assert.ok(result.status >= 400);
    assert.equal(Object.keys(result.body.error).join(), 'code');
  }
  assert.equal(selected.calls.length, 0);
});

test('strict schema and workspace boundaries reject actor, tools, role, model, large inputs and oversized limits', async t => {
  const {running, workspace, selected, temporary} = await setup(t);
  for (const fields of [
    {actor: 'administrator'}, {tools: [{name: 'shell'}]}, {model: 'some-other-model'},
    {workspace_root: temporary}, {timeout_ms: 45001}, {max_output_tokens: 2001},
    {transcript: [{role: 'assistant', content: 'prior tool result'}]},
    {transcript: [{role: 'user', content: 'first'}, {role: 'user', content: 'second'}]},
    {system: 'x'.repeat(19000)}, {system: 'x'.repeat(25000)}
  ]) {
    const result = await call(running, request(workspace, fields));
    assert.ok(result.status >= 400);
  }
  assert.equal(selected.calls.length, 0);
});

test('workspace removal refuses requests and disposal removes only its own descriptor', async t => {
  let open = true;
  const {running, workspace, selected} = await setup(t, model(), () => open);
  open = false;
  assert.equal((await call(running, request(workspace))).body.error.code, 'workspace_mismatch');
  assert.equal(selected.calls.length, 0);
  running.dispose();
  assert.equal(fs.existsSync(running.descriptorPath), false);
});

test('canceled startup does not publish or overwrite a descriptor after listening', async t => {
  await assert.rejects(setup(t, model(), () => false), /workspace_mismatch/);
});

test('an older window cannot delete a newer bridge descriptor', async t => {
  const {running} = await setup(t);
  const newer = {...running.descriptor, token: 'newer-window-token'};
  fs.writeFileSync(running.descriptorPath, JSON.stringify(newer));
  running.dispose();
  assert.equal(JSON.parse(fs.readFileSync(running.descriptorPath, 'utf8')).token, newer.token);
});

test('provider errors never echo exception details and non-text/tool responses are refused', async t => {
  for (const [override, wanted] of [
    [{sendRequest: async () => { throw new Error('SENSITIVE-PROVIDER-SENTINEL'); }}, 'provider_error'],
    [{sendRequest: async () => ({stream: (async function* () { yield {name: 'shell', arguments: {}}; })()})}, 'unsupported_response'],
    [{sendRequest: async () => { const error = new Error('SENSITIVE'); error.code = 'Blocked'; throw error; }}, 'quota']
  ]) {
    const {running, workspace} = await setup(t, model(override));
    const result = await call(running, request(workspace));
    assert.deepEqual(result.body, {error: {code: wanted}});
    assert.ok(!JSON.stringify(result.body).includes('SENSITIVE'));
  }
});

test('streaming token and byte bounds cancel without returning a partial suggestion', async t => {
  for (const output of ['x'.repeat(100), 'x'.repeat(25000)]) {
    const selected = model({sendRequest: async () => ({stream: (async function* () { yield new TextPart(output); })()})});
    const {running, workspace} = await setup(t, selected);
    const result = await call(running, request(workspace, {max_output_tokens: 10}));
    assert.deepEqual(result.body, {error: {code: 'response_too_large'}});
    assert.ok(cancellations.at(-1).token.isCancellationRequested);
  }
});

test('normal thinking and provider metadata never become answer text or get inspected', async () => {
  const thinking = new ThinkingPart('unused');
  const usage = new DataPart(new Uint8Array(), 'usage');
  const stateful = new DataPart(new Uint8Array(), 'stateful_marker');
  const unreadable = () => { throw new Error('Ignored payload must never be read'); };
  for (const key of ['value', 'id', 'metadata']) Object.defineProperty(thinking, key, {get: unreadable});
  Object.defineProperty(usage, 'data', {get: unreadable});
  Object.defineProperty(stateful, 'data', {get: unreadable});
  const selected = model({sendRequest: async () => ({stream: (async function* () {
    yield thinking; yield stateful; yield new TextPart('RE');
    yield thinking; yield new TextPart('ADY'); yield usage;
  })()})});
  assert.equal(await bridge.generate(vscode, selected, request(__dirname)), 'READY');
  assert.ok(cancellations.at(-1).token.isCancellationRequested);
});

test('tools, unrecognized data, lookalike metadata and malformed text reject the whole answer', async () => {
  for (const part of [new ToolCallPart(), new ToolResultPart(), new DataPart(new Uint8Array(), 'image/png'),
    new DataPart(new Uint8Array(), 'usage; charset=utf-8'), {mimeType: 'usage', data: 'not an API part'},
    {value: 'thinking-shaped object'}, new TextPart({text: 'not a string'})]) {
    const selected = model({sendRequest: async () => ({stream: (async function* () {
      yield new TextPart('READY'); yield part;
    })()})});
    await assert.rejects(bridge.generate(vscode, selected, request(__dirname)), /unsupported_response/);
    assert.ok(cancellations.at(-1).token.isCancellationRequested);
  }
});

test('reasoning and usage without final text cannot pass a connection check', async () => {
  const selected = model({sendRequest: async () => ({stream: (async function* () {
    yield new ThinkingPart(['internal', 'reasoning']); yield new DataPart(new Uint8Array(), 'usage');
  })()})});
  await assert.rejects(bridge.generate(vscode, selected, request(__dirname)), /provider_error/);
});

test('optional response constructors can be absent without breaking text-only VS Code hosts', async () => {
  const legacy = {...vscode, LanguageModelThinkingPart: undefined, LanguageModelDataPart: undefined};
  assert.equal(await bridge.generate(legacy, model(), request(__dirname)), '{"suggestions":[]}');
  const unknown = model({sendRequest: async () => ({stream: (async function* () { yield new ThinkingPart('unknown'); })()})});
  await assert.rejects(bridge.generate(legacy, unknown, request(__dirname)), /unsupported_response/);
});

test('discarded stream events are bounded and never produce partial answers', async () => {
  const selected = model({sendRequest: async () => ({stream: (async function* () {
    yield new TextPart('READY');
    for (let index = 0; index < 8192; index++) yield new ThinkingPart('');
  })()})});
  await assert.rejects(bridge.generate(vscode, selected, request(__dirname)), /response_too_large/);
  assert.ok(cancellations.at(-1).token.isCancellationRequested);
});

test('timeout bounds an unresponsive provider and concurrent work is refused', async t => {
  const selected = model({sendRequest: async () => new Promise(() => {})});
  const {running, workspace} = await setup(t, selected);
  const first = call(running, request(workspace));
  await new Promise(resolve => setTimeout(resolve, 50));
  assert.equal((await call(running, request(workspace))).body.error.code, 'busy');
  assert.equal((await first).body.error.code, 'timeout');
  assert.ok(cancellations.at(-1).token.isCancellationRequested);
});

test('unsupported model identities and unsafe metadata are refused', () => {
  assert.throws(() => bridge.metadata(model({id: 'other', name: 'Other', family: 'other'})), /model_unavailable/);
  assert.equal(bridge.metadata(model({name: 'Claude Sonnet — sélection', version: ''})).version, '');
  assert.throws(() => bridge.metadata(model({name: 'Sonnet\nforged claim'})), /model_unavailable/);
  assert.throws(() => bridge.metadata(model({name: 'Sonnet api_key=credential'})), /model_unavailable/);
});

test('extension activation registers commands without opening a server or calling a model', async () => {
  const commands = new Map(); const notices = []; let starts = 0, calls = 0;
  const fake = {
    workspace: {isTrusted: true, workspaceFolders: [{uri: {scheme: 'file', fsPath: __dirname}}],
      onDidChangeWorkspaceFolders: () => ({dispose() {}})},
    lm: {selectChatModels: async () => [], onDidChangeChatModels: () => ({dispose() {}})},
    commands: {registerCommand: (id, callback) => { commands.set(id, callback); return {dispose() {}}; }},
    window: {showWarningMessage: message => notices.push(message), showErrorMessage: message => notices.push(message)}
  };
  const module = {exports: {}};
  vm.runInNewContext(fs.readFileSync(path.join(__dirname, '../extension.js'), 'utf8'), {
    module, require: name => name === 'vscode' ? fake : name === './bridge' ? {...bridge,
      generate: async () => { calls++; }, startBridge: async () => { starts++; }} : require(name)
  });
  module.exports.activate({subscriptions: []});
  assert.equal(starts, 0); assert.equal(calls, 0);
  await commands.get('rwdPortal.connectSonnet')();
  assert.equal(starts, 0); assert.equal(calls, 0);
  assert.ok(notices.some(message => message.includes('No Claude Sonnet model is available')));
});

test('failed command consent never starts a server or publishes a descriptor', async () => {
  const commands = new Map(); const notices = []; let starts = 0;
  const fake = {
    workspace: {isTrusted: true, workspaceFolders: [{uri: {scheme: 'file', fsPath: __dirname}}],
      onDidChangeWorkspaceFolders: () => ({dispose() {}})},
    lm: {selectChatModels: async () => [model()], onDidChangeChatModels: () => ({dispose() {}})},
    commands: {registerCommand: (id, callback) => { commands.set(id, callback); return {dispose() {}}; }},
    window: {showErrorMessage: message => notices.push(message)}
  };
  const module = {exports: {}};
  vm.runInNewContext(fs.readFileSync(path.join(__dirname, '../extension.js'), 'utf8'), {
    module, require: name => name === 'vscode' ? fake : name === './bridge' ? {...bridge,
      generate: async () => { throw new bridge.Refusal('unauthorized'); },
      startBridge: async () => { starts++; }} : require(name)
  });
  module.exports.activate({subscriptions: []});
  await commands.get('rwdPortal.connectSonnet')();
  assert.equal(starts, 0);
  assert.ok(notices.some(message => message.includes('unauthorized')));
});

for (const stage of ['selection', 'ready', 'startup']) {
  test(`disconnect invalidates a pending ${stage} and cannot be undone by its late completion`, async () => {
    const commands = new Map(); const notices = [];
    let enter; const entered = new Promise(resolve => { enter = resolve; });
    let finish; const deferred = new Promise(resolve => { finish = resolve; });
    let starts = 0, probes = 0, disposed = 0, cancelled = 0;
    const fake = {
      workspace: {isTrusted: true, workspaceFolders: [{uri: {scheme: 'file', fsPath: __dirname}}],
        onDidChangeWorkspaceFolders: () => ({dispose() {}})},
      lm: {selectChatModels: async () => {
        if (stage === 'selection') { enter(); await deferred; }
        return [model()];
      }, onDidChangeChatModels: () => ({dispose() {}})},
      commands: {registerCommand: (id, callback) => { commands.set(id, callback); return {dispose() {}}; }},
      window: {showInformationMessage: message => notices.push(message), showErrorMessage: message => notices.push(message)}
    };
    const module = {exports: {}};
    vm.runInNewContext(fs.readFileSync(path.join(__dirname, '../extension.js'), 'utf8'), {
      module, require: name => name === 'vscode' ? fake : name === './bridge' ? {...bridge,
        generate: async (_vscode, _model, _request, tokens) => {
          probes++;
          tokens.add({cancel() { cancelled++; }});
          if (stage === 'ready') { enter(); await deferred; }
        },
        startBridge: async () => {
          starts++;
          if (stage === 'startup') { enter(); await deferred; }
          return {dispose() { disposed++; }};
        }} : require(name)
    });
    module.exports.activate({subscriptions: []});
    const connecting = commands.get('rwdPortal.connectSonnet')();
    await entered;
    commands.get('rwdPortal.disconnectModel')();
    finish(); await connecting;
    assert.equal(starts, stage === 'startup' ? 1 : 0);
    assert.equal(disposed, stage === 'startup' ? 1 : 0);
    if (stage === 'selection') assert.equal(probes, 0);
    else assert.ok(cancelled > 0);
    assert.ok(!notices.some(message => message.includes('connected to')));
  });
}
