'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const test = require('node:test');
const vm = require('node:vm');
const bridge = require('../bridge');

const sonnet = {id: 'claude-sonnet-available', name: 'Claude Sonnet', family: 'claude-sonnet', vendor: 'installed-provider', version: ''};
const mini = {id: 'gpt-5-mini', name: 'GPT-5 mini', family: 'gpt-5-mini', vendor: 'installed-provider', version: ''};
const unrelated = {id: 'gpt-5.4-mini', name: 'GPT-5.4 mini', family: 'gpt-5.4-mini', vendor: 'installed-provider', version: ''};

function harness(models, {pick = items => items[0], generate} = {}) {
  const commands = new Map(); const notices = []; const picks = []; const probes = []; const starts = [];
  const vscode = {
    workspace: {isTrusted: true, workspaceFolders: [{uri: {scheme: 'file', fsPath: __dirname}}],
      onDidChangeWorkspaceFolders: () => ({dispose() {}})},
    lm: {selectChatModels: async () => models, onDidChangeChatModels: () => ({dispose() {}})},
    commands: {registerCommand: (id, callback) => { commands.set(id, callback); return {dispose() {}}; }},
    window: {
      showQuickPick: async (items, options) => { picks.push({items, options}); return pick(items); },
      showInformationMessage: message => notices.push(message),
      showWarningMessage: message => notices.push(message),
      showErrorMessage: message => notices.push(message)
    }
  };
  const module = {exports: {}};
  vm.runInNewContext(fs.readFileSync(path.join(__dirname, '../extension.js'), 'utf8'), {
    module, require: name => name === 'vscode' ? vscode : name === './bridge' ? {...bridge,
      generate: async (_vscode, model, request) => { probes.push({model, request}); if (generate) return generate(model); },
      startBridge: async options => { starts.push(options); return {dispose() {}}; }
    } : require(name)
  });
  module.exports.activate({subscriptions: []});
  return {commands, notices, picks, probes, starts};
}

for (const alias of ['gpt-5-mini', 'gpt-5-mini-2025-08-07', 'GPT-5 mini', 'GPT 5 mini']) {
  test(`exact GPT-5 mini alias ${alias} is recognized in provider metadata without rewriting its identity`, () => {
    for (const field of ['id', 'name', 'family']) {
      const value = {...mini, id: 'provider-specific-id', name: 'Provider-specific name', family: 'provider-specific-family', [field]: ` ${alias} `};
      assert.equal(bridge.modelKind(value), 'gpt-5-mini');
      assert.deepEqual(bridge.metadata(value), value);
    }
  });
}

test('neighboring GPT versions, Codex mini, nano and substring matches are not GPT-5 mini', () => {
  for (const label of ['gpt-5.4-mini', 'GPT-5.4 mini', 'gpt-5.1-codex-mini', 'GPT-5.1 Codex mini',
    'gpt-5-nano', 'gpt-5-mini-preview', 'gpt-5-mini-2099-01-01', 'My gpt-5-mini wrapper', 'gpt-5-mini-tools']) {
    const value = {...mini, id: label, name: label, family: label};
    assert.equal(bridge.modelKind(value), '');
    assert.throws(() => bridge.metadata(value), /model_unavailable/);
  }
});

test('generic command offers supported available models and sends only the explicitly selected GPT-5 mini', async () => {
  const app = harness([sonnet, unrelated, mini], {pick: items => items.find(item => item.model === mini)});
  assert.equal(app.probes.length, 0);
  await app.commands.get('rwdPortal.connectModel')();
  assert.equal(app.picks.length, 1);
  assert.deepEqual(Array.from(app.picks[0].items, item => item.model.id), [sonnet.id, mini.id]);
  assert.equal(app.probes.length, 1);
  assert.equal(app.probes[0].model, mini);
  assert.equal(app.probes[0].request.timeout_ms, 45000);
  assert.equal(app.starts.length, 1);
  assert.equal(app.starts[0].model, mini);
  assert.ok(app.notices.some(message => message.includes('connected to GPT-5 mini')));
});

test('generic command requires a picker selection even with only one available model', async () => {
  const app = harness([mini]);
  await app.commands.get('rwdPortal.connectModel')();
  assert.equal(app.picks.length, 1);
  assert.equal(app.picks[0].items.length, 1);
  assert.equal(app.probes.length, 1);
  assert.equal(app.starts[0].model, mini);
});

test('canceling the generic picker makes no access-check call and publishes no descriptor', async () => {
  const app = harness([sonnet, mini], {pick: () => undefined});
  await app.commands.get('rwdPortal.connectModel')();
  assert.equal(app.picks.length, 1);
  assert.equal(app.probes.length, 0);
  assert.equal(app.starts.length, 0);
});

test('legacy Sonnet command remains Sonnet-only when GPT-5 mini is also available', async () => {
  const app = harness([mini, sonnet]);
  await app.commands.get('rwdPortal.connectSonnet')();
  assert.equal(app.probes.length, 1);
  assert.equal(app.probes[0].model, sonnet);
  assert.equal(app.starts[0].model, sonnet);
});

test('legacy Sonnet command never substitutes GPT-5 mini when Sonnet is absent', async () => {
  const app = harness([mini]);
  await app.commands.get('rwdPortal.connectSonnet')();
  assert.equal(app.probes.length, 0);
  assert.equal(app.starts.length, 0);
  assert.ok(app.notices.some(message => message.includes('No Claude Sonnet model is available')));
});

test('unavailable supported models explain provider setup without fallback', async () => {
  const app = harness([unrelated]);
  await app.commands.get('rwdPortal.connectModel')();
  assert.equal(app.picks.length, 0);
  assert.equal(app.probes.length, 0);
  assert.equal(app.starts.length, 0);
  assert.ok(app.notices.some(message => message.includes('No supported Claude Sonnet or GPT-5 mini model is available') &&
    message.includes('Chat: Manage Language Models')));
});

test('denied GPT-5 mini consent never retries with Sonnet', async () => {
  const app = harness([sonnet, mini], {pick: items => items.find(item => item.model === mini),
    generate: () => { throw new bridge.Refusal('forbidden'); }});
  await app.commands.get('rwdPortal.connectModel')();
  assert.equal(app.probes.length, 1);
  assert.equal(app.probes[0].model, mini);
  assert.equal(app.starts.length, 0);
  assert.ok(app.notices.some(message => message.includes('forbidden')));
});

test('Disconnect during the generic picker prevents a late selection from connecting', async () => {
  let enter; const entered = new Promise(resolve => { enter = resolve; });
  let finish; const deferred = new Promise(resolve => { finish = resolve; });
  const app = harness([sonnet, mini], {pick: async items => { enter(); await deferred; return items[1]; }});
  const connecting = app.commands.get('rwdPortal.connectModel')();
  await entered;
  app.commands.get('rwdPortal.disconnectModel')();
  finish(); await connecting;
  assert.equal(app.probes.length, 0);
  assert.equal(app.starts.length, 0);
});

test('the extension manifest declares the generic and compatibility commands', () => {
  const manifest = JSON.parse(fs.readFileSync(path.join(__dirname, '../package.json'), 'utf8'));
  assert.equal(manifest.contributes.commands.find(command => command.command === 'rwdPortal.connectModel').title, 'RWD Portal: Connect Chat Model');
  assert.ok(manifest.contributes.commands.some(command => command.command === 'rwdPortal.connectSonnet'));
  assert.ok(manifest.activationEvents.includes('onCommand:rwdPortal.connectModel'));
});
