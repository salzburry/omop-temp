# RWD Portal Model Bridge

This extension connects the portal's workflow chat and scientific-row suggestions
to a Claude Sonnet or GPT-5 mini model exposed by the **VS Code Language Model API**. It shows
the models actually available from installed providers. Having a Claude Code
extension installed does not guarantee that Sonnet is exposed through this API.
When neither supported model is available, the command explains that and connects
nothing. It never falls back to another model or a separate API credential.

After reviewing and installing the local VSIX, open the intended repository in a
trusted VS Code workspace. Run **RWD Portal: Connect Chat Model** and explicitly
select Claude Sonnet or GPT-5 mini. The picker appears even when only one supported
model is available; cancelling it makes no model request. The previous
**RWD Portal: Connect Claude Sonnet** command remains available as a Sonnet-only
shortcut. VS Code may ask for model consent. The command
makes one tiny `READY` access check without product context, then publishes the
connection. Return to the portal row editor and explicitly request suggestions.
Run **RWD Portal: Disconnect Model** to end access.

GPT-5 mini matching uses the exact `gpt-5-mini` identifier, its documented
`gpt-5-mini-2025-08-07` snapshot, or the exact display spellings `GPT-5 mini` and
`GPT 5 mini` in provider metadata. GPT-5.4 mini, GPT-5.1 Codex mini and GPT-5 nano
are different models and are not included. Sonnet versions are shown using the
provider's actual model name; the extension does not invent a version label.
Provider authentication, subscriptions, billing and quotas still apply. Adding
GPT-5 mini is a model choice, not a promise of subscription-free access.

The bridge exposes authenticated `POST /generate` and authenticated `GET /health`
on a random **127.0.0.1** port. This is plaintext local HTTP, not a remote service.
The bearer descriptor is stored outside the checkout at
`~/.rwd-portal/vscode-model-bridge.json`. The directory/file use 0700/0600 on POSIX;
Windows receives a current-user-only directory ACL before the descriptor is written.
The token is never printed. Disconnect, extension disposal, workspace changes and
model-list changes close the bridge. A stopped or stale descriptor cannot authorize
a different workspace or model.

The only generation input is bounded instruction text and one user-context message.
No file, shell, tool invocation, approval, release or save endpoint exists. VS Code's
stable API does not provide a system-message role, so the instruction text is sent
as a separate User message. The extension adds no editor files or conversation history.
It requests no tools and collects only final text. Typed reasoning events and
provider bookkeeping (`usage` and `stateful_marker` data parts) are discarded
without reading or retaining their payloads. Tool requests, tool results, other
data types and unknown objects are refused. This handles the metadata emitted by
VS Code alongside otherwise valid model answers.

Requests are limited to 18 KB of context, 24 KB of HTTP body, one concurrent
generation and 45 seconds. Responses are capped at 24 KB and 2,000 counted output
tokens; the stream is cancelled when a cap is exceeded. These are returned-output
limits, not a guarantee about the provider's billed tokens or plan quotas.
The total stream is also limited to 8,192 parts, including discarded events.
The portal still validates the response, source eligibility and current evidence,
then requires explicit field selection before saving an unfinished private draft.

Run offline regressions with `node --test test/*.test.js`. Build the reviewable
VSIX with `python package_extension.py`. Neither command installs the extension or
contacts a model.

Version 0.1.2 fixes `unsupported_response` during the connection check when a
normal answer also includes reasoning or provider metadata. After updating the
extension, run **Developer: Reload Window**, then **RWD Portal: Connect Chat Model**.

API references: [Language Model API](https://code.visualstudio.com/api/extension-guides/ai/language-model)
and [VS Code API](https://code.visualstudio.com/api/references/vscode-api#LanguageModelChat).
