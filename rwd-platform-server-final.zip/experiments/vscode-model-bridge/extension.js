'use strict';
const fs = require('node:fs');
const vscode = require('vscode');
const bridge = require('./bridge');

let running;
let connecting;
let connectionEpoch = 0;
const pendingTokens = new Set();

function disconnect() {
  connectionEpoch++;
  connecting = undefined;
  for (const token of pendingTokens) token.cancel();
  pendingTokens.clear();
  running?.dispose(); running = undefined;
}

async function connect(sonnetOnly = false) {
  if (connecting !== undefined) return;
  disconnect();
  const generation = connectionEpoch;
  connecting = generation;
  const current = () => generation === connectionEpoch;
  try {
    if (!vscode.workspace.isTrusted) throw new bridge.Refusal('forbidden');
    const folders = (vscode.workspace.workspaceFolders || []).filter(folder => folder.uri.scheme === 'file');
    if (!folders.length) throw new bridge.Refusal('workspace_mismatch');
    const folder = folders.length === 1 ? folders[0] : await vscode.window.showWorkspaceFolderPick({placeHolder: 'Choose the RWD Portal workspace to connect'});
    if (!folder || !current()) return;
    const workspaceRoot = fs.realpathSync(folder.uri.fsPath);
    const isWorkspaceOpen = () => current() && vscode.workspace.isTrusted && (vscode.workspace.workspaceFolders || []).some(item => {
      try { return item.uri.scheme === 'file' && fs.realpathSync(item.uri.fsPath) === workspaceRoot; } catch { return false; }
    });
    const models = (await vscode.lm.selectChatModels({})).filter(model => {
      try {
        const info = bridge.metadata(model);
        return !sonnetOnly || bridge.modelKind(info) === 'sonnet';
      } catch { return false; }
    });
    if (!isWorkspaceOpen()) return;
    if (!models.length) {
      const missing = sonnetOnly ? 'No Claude Sonnet model is available' : 'No supported Claude Sonnet or GPT-5 mini model is available';
      vscode.window.showWarningMessage(`${missing} through the VS Code Language Model API. Open Chat: Manage Language Models and check provider access. Installing Claude Code alone does not guarantee this API access. No other model was selected.`);
      return;
    }
    const model = sonnetOnly && models.length === 1 ? models[0] : (await vscode.window.showQuickPick(
      models.map(value => ({label: value.name, description: `${value.vendor} · ${value.family} · ${value.id}`, model: value})),
      {placeHolder: sonnetOnly ? 'Select the Claude Sonnet model for RWD Portal row suggestions' :
        'Select Claude Sonnet or GPT-5 mini for RWD Portal row suggestions'}))?.model;
    if (!model || !models.includes(model) || !isWorkspaceOpen()) return;
    // This explicit command is the consent boundary required by VS Code. The
    // small access check contains no product or patient information.
    await bridge.generate(vscode, model, {system: 'Check model access for the RWD Portal bridge. Reply with READY only.',
      transcript: [{role: 'user', content: 'READY'}], max_output_tokens: 20, timeout_ms: 45000}, pendingTokens);
    if (!isWorkspaceOpen()) return;
    const candidate = await bridge.startBridge({vscode, model, workspaceRoot, isWorkspaceOpen});
    if (!isWorkspaceOpen()) { candidate.dispose(); return; }
    running = candidate;
    vscode.window.showInformationMessage(`RWD Portal connected to ${model.name} in this workspace. Return to the row editor and explicitly request suggestions. Disconnect ends access.`);
  } catch (error) {
    if (current()) {
      const code = bridge.safeCode(error);
      const next = code === 'unsupported_response' ?
        'The model returned a tool request or content this bridge cannot use. No tools were run. Report this response-format error or explicitly choose another listed model.' :
        'Check VS Code model access and try the Connect command again.';
      vscode.window.showErrorMessage(`RWD Portal model bridge could not connect (${code}). ${next}`);
    }
  } finally { if (connecting === generation) connecting = undefined; }
}

function activate(context) {
  context.subscriptions.push(vscode.commands.registerCommand('rwdPortal.connectModel', () => connect(false)),
    vscode.commands.registerCommand('rwdPortal.connectSonnet', () => connect(true)),
    vscode.commands.registerCommand('rwdPortal.disconnectModel', () => { disconnect(); vscode.window.showInformationMessage('RWD Portal model bridge disconnected.'); }),
    vscode.workspace.onDidChangeWorkspaceFolders(() => disconnect()),
    vscode.lm.onDidChangeChatModels(() => disconnect()),
    {dispose: disconnect});
}

function deactivate() { disconnect(); }
module.exports = {activate, deactivate};
