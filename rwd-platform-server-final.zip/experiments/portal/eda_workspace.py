"""Read exact, counts-only EDA evidence; save its binding, never its restricted counts.

The runner and canonical validators own computation and acceptance. This workspace
only receives a completed artifact from the configured restricted evidence folder.
"""
from __future__ import annotations

import copy
import difflib
import hashlib
import json
import math
import os
from pathlib import Path
import re
import tempfile

import yaml

import source_workspace as source
import specification_details as details
import product_gates as gates
import eda_report
from engine import refresh, release, telemetry, grain, output_contract, validate
from engine.config import load_config

NOTICE = "Counts remain restricted evidence. Opening or recording this binding does not authenticate a runtime, approve data, or release a product."
REVIEW_DIR = "handoff/EDA_REVIEWS"
LAYERS = (
    ("inventory", "1 · Delivery inventory", "Which sources have rows and usable patient keys?"),
    ("grain_keys", "2 · Source grain and keys", "Do declared keys identify the expected number of records?"),
    ("relationships", "3 · Relationships between sources", "Which patients overlap, disappear or produce multiple joined rows?"),
    ("temporal", "4 · Date checks", "How many dates are missing, unreadable or outside the delivery boundary?"),
    ("funnel", "5 · Cohort and selection funnel", "Where do patients or selected measurements enter and leave the build?"),
    ("ads_output", "6 · Built dataset checks", "Does the output meet its declared keys and scientific checks?"),
)
_ERROR = "The evidence metadata is malformed or contains unsupported fields. Ask the data expert to regenerate the counts-only EDA artifact; restricted contents were not copied."
_SHA = re.compile(r"[a-f0-9]{64}")
_ID = re.compile(r"[A-Za-z0-9_]{1,64}")


class Invalid(ValueError):
    pass


def _sha(value):
    return hashlib.sha256(value if isinstance(value, bytes) else json.dumps(value, sort_keys=True, allow_nan=False).encode()).hexdigest()


def _guard(function):
    def wrapped(*args, **kwargs):
        try:
            return function(*args, **kwargs)
        except (Invalid, source.Invalid, details._Invalid) as error:
            return {"ok": False, "errors": [str(error)], "notice": NOTICE}
        except (OSError, ValueError, TypeError, KeyError, AttributeError, RecursionError, yaml.YAMLError, SystemExit):
            return {"ok": False, "errors": [_ERROR], "notice": NOTICE}
    return wrapped


def _scope(root, pack, actor, allowed):
    return source._scope(root, pack, actor, allowed)[:3]


def _inputs(root, product):
    # Our immutable review bindings do not invalidate the evidence they describe.
    return {key: value for key, value in source._inputs(root, product).items()
            if not key.startswith(product.relative_to(root).as_posix() + "/" + REVIEW_DIR + "/")}


def _yaml(path):
    raw = source._bytes(path)
    doc = yaml.load(raw, Loader=details._StrictLoader)
    # The canonical YAML writer shares eda.acceptance with eda_acceptance, so
    # ordinary receipts legitimately contain aliases. Expand only a bounded,
    # acyclic document; cyclic/exponentially expanded aliases are refused.
    remaining = [100000]
    def plain(value, ancestors=(), depth=0):
        remaining[0] -= 1
        if remaining[0] < 0 or depth > 35 or (isinstance(value, (dict, list)) and id(value) in ancestors):
            raise Invalid(_ERROR)
        if isinstance(value, dict):
            return {key: plain(item, (*ancestors, id(value)), depth + 1) for key, item in value.items()}
        if isinstance(value, list):
            return [plain(item, (*ancestors, id(value)), depth + 1) for item in value]
        return value
    doc = plain(doc)
    if not isinstance(doc, dict):
        raise Invalid(_ERROR)
    return raw, doc


def _receipts(root, product, pack):
    family = pack.split("/")[1]
    names = details._accepted_products(root, pack)
    rows = []
    for name in sorted(names):
        if not _ID.fullmatch(name):
            raise Invalid(_ERROR)
        folder = source._safe(root / "refreshes" / family / name / product.name)
        if not folder.is_dir():
            continue
        for path in sorted(folder.glob("*.yaml")):
            raw, doc = _yaml(path)
            if doc.get("tumor") not in names or str(doc.get("spec_version")) != product.name \
                    or doc.get("family") != family:
                continue
            build = (doc.get("release") or {}).get("build_id")
            if not isinstance(build, str) or not _ID.fullmatch(build):
                continue
            rows.append({"receipt": path.relative_to(root).as_posix(), "build_id": build,
                         "manifest_sha256": _sha(raw), "document": doc})
    return rows


def _preflight_artifacts(root, product, doc):
    # validate_manifest may hash published local artifacts. Never let a receipt
    # redirect that canonical reader to arbitrary files or another product.
    for name, value in (doc.get("artifacts") or {}).items():
        if str((doc.get("artifact_types") or {}).get(name) or "").strip() != "file":
            continue
        if not isinstance(value, str):
            raise Invalid(_ERROR)
        if value.startswith(("dbfs:/", "abfss://", "s3://")):
            continue
        if value.startswith("/Volumes/") and not Path(value).exists():
            continue
        path = Path(value)
        if value.startswith(("\\\\", "//")) or not path.is_absolute():
            raise Invalid("A build artifact has an unscoped path. Have the data expert correct its runtime receipt.")
        path = source._safe(path)
        pack = product.relative_to(root).as_posix()
        receipt_dirs = [root / "refreshes" / pack.split("/")[1] / name / product.name
                        for name in details._accepted_products(root, pack) if _ID.fullmatch(name)]
        allowed = path.is_relative_to(product) or any(path.is_relative_to(folder) for folder in receipt_dirs)
        if name == "eda_report":
            base = source._restricted_base(root)
            allowed = allowed or path.is_relative_to(base)
        if not allowed or path.suffix.lower() not in {".json", ".yaml", ".yml", ".md", ".txt", ".html"}:
            raise Invalid("A build artifact leaves this product's metadata scope. Verify it in the governed runtime first.")
        if path.exists():
            source._bytes(path)  # Bound the file the canonical reader may hash.


def _context(root, pack, actor, allowed, receipt=None):
    root, product, pack = _scope(root, pack, actor, allowed)
    before = _inputs(root, product)
    candidates = _receipts(root, product, pack)
    selected = next((r for r in candidates if r["receipt"] == receipt), None)
    if receipt and selected is None:
        raise Invalid("Choose an exact build receipt from this product and specification cut.")
    if before != _inputs(root, product):
        raise Invalid("The product changed while the build list was read. Check again.")
    basis = {"root": str(root), "pack": pack, "actor": actor, "inputs": before,
             "receipts": [{k: v for k, v in r.items() if k != "document"} for r in candidates]}
    return root, product, pack, before, candidates, selected, _sha(basis)


@_guard
def describe(root, pack, actor_id, *, allowed_packs=None, receipt=None):
    root, product, pack, inputs, candidates, selected, digest = _context(root, pack, actor_id, allowed_packs, receipt)
    summary = None
    if selected:
        doc = selected["document"]
        artifacts = doc.get("artifacts") or {}
        summary = {k: v for k, v in selected.items() if k != "document"}
        summary.update(eda_recorded=bool(doc.get("eda")), artifact_recorded=bool(artifacts.get("eda_report")),
                       report_sha256=artifacts.get("eda_report_sha256") if _SHA.fullmatch(str(artifacts.get("eda_report_sha256") or "")) else "")
    return {"ok": True, "errors": [], "digest": digest, "selected": summary,
            "candidates": [{k: v for k, v in r.items() if k != "document"} for r in candidates],
            "restricted_folder": source.restricted_folder(root), "notice": NOTICE}


def _object(value, keys=None):
    if not isinstance(value, dict) or (keys is not None and set(value) - set(keys)):
        raise Invalid(_ERROR)
    return value


def _count(value):
    if type(value) is not int or not 0 <= value <= 10**15:
        raise Invalid(_ERROR)
    return value


def _counts(value, keys):
    _object(value, keys)
    return {key.replace("_", " "): _count(value[key]) for key in keys if key in value}


def _label(value, known):
    if not isinstance(value, str) or value not in known:
        raise Invalid("The EDA report names metadata outside the selected configuration. Recheck the build and its configured sources; unrecognized labels were not copied.")
    return value


def _known(cfg):
    # Only config-supplied names may label restricted counts. Never display arbitrary
    # labels, cohort values, error strings or sampled values from a result file.
    names = {"patientid", "index_date", "cohort", "cohortn", "data_product_id", "index", "demographics",
             "clinical", "treatment", "outcomes", "cohort_ads", "column_types", "null_limits", "flag_date_pairs",
             "date_order", "nonnegative", "vocabulary"}
    def walk(value):
        if isinstance(value, dict):
            for key, item in value.items():
                if isinstance(key, str) and len(key) <= 160:
                    names.add(key)
                walk(item)
        elif isinstance(value, list):
            for item in value:
                walk(item)
        elif isinstance(value, str) and len(value) <= 160 and re.fullmatch(r"[\w .:/()-]+", value):
            names.add(value)
    walk(cfg.raw)
    for doc in cfg.packs().values():
        walk(doc)
    # Canonical readers also supply engine-defined source columns and derived
    # output labels which need not occur literally in a configuration file.
    walk(validate.required_columns(cfg))
    walk(validate.optional_columns(cfg))
    walk(output_contract.contract_spec(cfg))
    return names | {n.lower() for n in names}


def _list_count(value):
    if not isinstance(value, list) or len(value) > 2000:
        raise Invalid(_ERROR)
    return len(value)


def _layer(name, block, known):
    rows, notes = [], []
    if block is None or block == {}:
        return {"state": "not collected", "rows": [], "notes": ["This layer contains no collected evidence."]}
    _object(block)
    if isinstance(block.get("skipped"), str):
        if set(block) != {"skipped"}:
            raise Invalid(_ERROR)
        return {"state": "not checked", "rows": [], "notes": ["The runtime marked this entire layer as skipped. No passing result is inferred."]}
    state = "counts recorded"
    if name in {"inventory", "relationships", "temporal"}:
        keys = {"inventory": ("rows", "patients", "null_patient_keys", "columns"),
                "relationships": ("overlap", "index_only", "source_only", "max_rows_per_patient"),
                "temporal": ("null", "unparseable", "before_1900", "after_study_end")}[name]
        for role, value in block.items():
            _label(role, known)
            _object(value)
            if name == "inventory" and set(value) == {"skipped"}:
                notes.append(role + ": not checked; no usable patient-key column was reported.")
                continue
            if name == "temporal":
                for column, counts in value.items():
                    if set(_object(counts)) != set(keys):
                        raise Invalid(_ERROR)
                    rows.append({"Source": role, "Column": _label(column, known), **_counts(counts, keys)})
            else:
                if set(value) != set(keys):
                    raise Invalid(_ERROR)
                rows.append({"Source": role, **_counts(value, keys)})
        if notes:
            state = "partly unchecked"
    elif name == "funnel":
        _object(block, {"stages", "selections", "skipped", "observations"})
        for kind, labels, metrics in (("stages", ("cohort", "stage"), telemetry._STAGE_METRICS),
                                      ("selections", ("cohort", "block", "item"), telemetry._SELECTION_METRICS)):
            values = block.get(kind, [])
            _list_count(values)
            for value in values:
                _object(value, {*labels, *metrics})
                if kind == "stages" and not set(metrics).issubset(value):
                    raise Invalid(_ERROR)
                row = {"Kind": kind, **{label.capitalize(): _label(value[label], known) for label in labels}}
                row.update(_counts({k: v for k, v in value.items() if k in metrics}, metrics))
                rows.append(row)
        skipped = _list_count(block.get("skipped", []))
        if skipped:
            state = "partly unchecked"
            notes.append(f"{skipped} stage collection(s) were skipped. Their restricted free-text diagnostics stay in the source report.")
    elif name == "grain_keys":
        _object(block, {"passed", "failures", "unchecked", "report"})
        if not block.get("report"):
            raise Invalid(_ERROR)
        canonical = grain.source_grain_gate(_object(block.get("report", {})))
        if any(block.get(key) != value for key, value in canonical.items()):
            raise Invalid("The source-grain summary disagrees with its recorded counts. Regenerate the EDA report with the existing runner.")
        for role, value in _object(block.get("report", {})).items():
            if role == "_declaration_errors":
                notes.append(f"{_list_count(value)} source-grain declaration finding(s).")
                continue
            _label(role, known)
            _object(value, {"unique_by", "rows", "duplicate_keys", "duplicate_rows", "passed", "skipped"})
            keys = value.get("unique_by", [])
            _list_count(keys)
            row = {"Source": role, "Declared keys": ", ".join(_label(k, known) for k in keys)}
            if "skipped" in value:
                row["Check"] = "not checked"
            else:
                row.update(_counts({k: v for k, v in value.items() if k in {"rows", "duplicate_keys", "duplicate_rows"}}, ("rows", "duplicate_keys", "duplicate_rows")))
            rows.append(row)
    elif name == "ads_output":
        _object(block, {"passed", "failures", "unconfigured", "report"})
        report = _object(block.get("report", {}))
        if not report:
            raise Invalid(_ERROR)
        canonical = output_contract.output_contract_gate(report)
        if any(block.get(key) != value for key, value in canonical.items()):
            raise Invalid("The output-check summary disagrees with its recorded evidence. Regenerate the EDA report with the existing runner.")
        scalars = {"n_rows", "duplicate_keys", "duplicate_key_rows", "duplicate_membership", "duplicate_membership_rows"}
        maps = {"key_nulls", "null_rate", "null_limits", "compared", "violations"}
        metadata = {"key", "strict", "not_applicable", "skipped", "column_types", "key_type_mismatches", "type_mismatches", "publish", "key_missing_columns", "membership_key", "cohort_code_mismatches", "cohorts_expected", "cohorts_missing", "cohorts_allowed_empty", "cohorts_unexpected", "allow_empty_unknown", "cohort_column_missing"}
        _object(report, scalars | maps | metadata)
        for key in sorted(scalars & report.keys()):
            rows.append({"Check": key.replace("_", " "), "Value": "not checked" if report[key] is None else _count(report[key])})
        for group in sorted(maps & report.keys()):
            for key, value in _object(report[group]).items():
                # Violation labels contain a fixed metric prefix and declared columns.
                if group == "violations":
                    parts = key.split("__") if isinstance(key, str) else []
                    if len(parts) < 2 or parts[0] not in {"flagnodate", "datenoflag", "dateorder", "negative", "vocab"}:
                        raise Invalid(_ERROR)
                    for part in parts[1:]:
                        _label(part, known)
                else:
                    _label(key, known)
                if group in {"null_rate", "null_limits"}:
                    if value is not None and (type(value) not in {int, float} or not math.isfinite(value) or not 0 <= value <= 1):
                        raise Invalid(_ERROR)
                elif value is not None:
                    _count(value)
                rows.append({"Check": group.replace("_", " ") + " · " + key, "Value": value if value is not None else "not checked"})
        # Derived text can contain unexpected delivered values. Report finding counts,
        # never the contents of those lists, and direct detailed inspection to runtime.
        for key in sorted(metadata & report.keys()):
            if key in {"cohorts_missing", "cohorts_unexpected", "key_type_mismatches", "type_mismatches", "key_missing_columns", "cohort_code_mismatches"}:
                notes.append(key.replace("_", " ") + ": " + str(_list_count(report[key])) + " finding(s)")
        if report.get("skipped"):
            notes.append("Some output checks were not evaluated; inspect the declared checks and runtime report.")
            state = "partly unchecked"
    if "passed" in block:
        if type(block["passed"]) is not bool:
            raise Invalid(_ERROR)
        state = "recorded checks passed" if block["passed"] else "recorded checks failed"
        failures = _list_count(block.get("failures", []))
        if failures:
            notes.append(f"{failures} recorded finding(s); review their counts and the source or output declarations.")
        unchecked = _list_count(block.get("unchecked", block.get("unconfigured", [])))
        if unchecked:
            state += " · partly unchecked"
            notes.append(f"{unchecked} unchecked or unconfigured check(s). Absence is not a pass.")
    if not rows and state == "counts recorded":
        state = "not collected"
    return {"state": state, "rows": rows, "notes": notes}


def _json(raw):
    def pairs(items):
        doc = {}
        for key, value in items:
            if key in doc:
                raise Invalid(_ERROR)
            doc[key] = value
        return doc
    return json.loads(raw.decode("utf-8"), object_pairs_hook=pairs,
                      parse_constant=lambda value: (_ for _ in ()).throw(Invalid(_ERROR)))


def _receive(root, pack, actor, receipt, name, digest, allowed):
    root, product, pack, inputs, candidates, selected, current = _context(root, pack, actor, allowed, receipt)
    if current != digest:
        raise Invalid("The product or receipt changed. Check the current build before receiving or saving its evidence.")
    doc = selected["document"]
    cfg = load_config(str(product / "config/data_product.yaml"))
    identity = {"config_bundle_sha256": gates.config_bundle_sha256(str(product)),
                "delivery_sha256": gates.delivery_sha256(str(product))}
    if release.candidate_binding_blockers(doc, spec_version=cfg.spec_version, refresh=cfg.refresh,
                                         output_fqn=cfg.output_fqn, config_identity=identity):
        raise Invalid("This build is not bound to the current configuration and delivery. Restore its intended inputs or obtain a current runtime build before reviewing EDA here.")
    if doc.get("data_product_id") != cfg.data_product_id or doc.get("source_schema") != cfg.source_schema \
            or doc.get("source_union") != cfg.source_union or doc.get("vendor") != cfg.vendor:
        raise Invalid("The receipt's product or delivery identity does not match this product.")
    adapter = source._safe(product / "config/source_adapters.yaml")
    adapter_binding = _object(doc.get("adapter_binding") or {})
    if (adapter.exists() and adapter_binding.get("digest") != _sha(source._bytes(adapter))) \
            or (not adapter.exists() and adapter_binding):
        raise Invalid("The source adapter used by this build does not match the current adapter metadata. Obtain evidence from the intended mapping before continuing.")
    path = source._restricted(root, name, (".json",))
    raw = source._bytes(path)
    report = _object(_json(raw), {"pack", "classification", "layers", "acceptance"})
    if report.get("pack") != cfg.data_product_id or _object(report.get("classification", {}), {"state", "note"}).get("state") != "restricted_derived":
        raise Invalid("The report must identify this product and declare restricted-derived EDA evidence.")
    if (doc.get("artifact_types") or {}).get("eda_report") != "file" \
            or not (doc.get("artifacts") or {}).get("eda_report") \
            or (doc.get("artifacts") or {}).get("eda_report_sha256") != _sha(raw) \
            or doc.get("eda") != report:
        raise Invalid("The report bytes or embedded EDA evidence do not match the selected manifest. Obtain the exact artifact from that build.")
    layers = _object(report.get("layers", {}), {key for key, _, _ in LAYERS})
    known = _known(cfg)
    projected = [{"name": key, "title": title, "question": question, **_layer(key, layers.get(key), known)} for key, title, question in LAYERS]
    limits = (cfg.raw.get("qc") or {}).get("eda_acceptance")
    acceptance = eda_report.acceptance(report, dict(limits)) if limits else None
    if (report.get("acceptance") or {}) != (acceptance or {}) or (doc.get("eda_acceptance") or {}) != (acceptance or {}):
        raise Invalid("The EDA acceptance block disagrees with the current declared checks. Regenerate the evidence with the existing runner.")
    _preflight_artifacts(root, product, doc)
    problems = refresh.validate_manifest(copy.deepcopy(doc))
    verdict = refresh.candidate_verdict(copy.deepcopy(doc))
    # Malformed manifests do not become review evidence; a valid failed candidate
    # remains inspectable because its failure is precisely what needs review.
    if problems:
        raise Invalid(f"The existing manifest validator found {len(problems)} structural or binding issue(s). Open candidate validation before recording this EDA evidence.")
    base = source._restricted_base(root)
    record = {"version": 1, "kind": "eda_evidence_binding", "pack": pack, "build_id": selected["build_id"],
              "receipt": receipt, "manifest_sha256": selected["manifest_sha256"], "report_sha256": _sha(raw),
              "evidence_name": path.relative_to(base).as_posix(), "inputs_sha256": _sha(inputs),
              "config_identity": identity, "state": "recorded_for_review"}
    record_id = _sha(record)[:24]
    if _context(root, pack, actor, allowed, receipt)[-1] != digest or source._bytes(path) != raw:
        raise Invalid("The product, receipt or report changed during review. Receive the current evidence again.")
    return {"ok": True, "errors": [], "digest": digest, "review_id": record_id, "record": record,
            "layers": projected, "candidate_passed": verdict["passed"],
            "candidate_failure_count": len(verdict["failures"]), "not_evaluated": verdict["not_evaluated"],
            "acceptance": None if acceptance is None else {"passed": acceptance["passed"], "failures": len(acceptance["failures"]), "unchecked": len(acceptance["unchecked"])},
            "notice": NOTICE}


@_guard
def receive(root, pack, actor_id, *, receipt, report_name, expected_digest, allowed_packs=None):
    """Read-only intake; no upload, computation, mutation or copied restricted counts."""
    result = _receive(root, pack, actor_id, receipt, report_name, expected_digest, allowed_packs)
    raw = yaml.safe_dump(result["record"], sort_keys=False)
    result["diff"] = "".join(difflib.unified_diff([], raw.splitlines(True), fromfile="No saved evidence binding", tofile=REVIEW_DIR + "/" + result["review_id"] + ".yaml"))
    return result


@_guard
def save_review(root, pack, actor_id, *, receipt, report_name, expected_digest, expected_review_id,
                allowed_packs=None, local_demo=False, can_write=False, confirmed=False):
    source._authorized(local_demo, can_write)
    if confirmed is not True:
        raise Invalid("Review the metadata diff and explicitly confirm before saving it to the branch.")
    result = _receive(root, pack, actor_id, receipt, report_name, expected_digest, allowed_packs)
    if result["review_id"] != expected_review_id:
        raise Invalid("The proposed evidence binding changed. Review its current diff before saving.")
    root, product, pack = _scope(root, pack, actor_id, allowed_packs)
    folder = source._safe(product / REVIEW_DIR)
    folder.mkdir(parents=True, exist_ok=True)
    target = source._safe(folder / (result["review_id"] + ".yaml"))
    raw = yaml.safe_dump(result["record"], sort_keys=False).encode("utf-8")
    if target.exists():
        if source._bytes(target) != raw:
            raise Invalid("A different file already occupies this evidence binding. Ask Engineering to review it; nothing was overwritten.")
        return {"ok": True, "errors": [], "changed": False, "review_id": result["review_id"], "notice": NOTICE}
    with tempfile.NamedTemporaryFile(dir=folder, delete=False) as handle:
        handle.write(raw)
        temp = Path(handle.name)
    try:
        # Publish only complete new metadata, and never overwrite a concurrent edit.
        fresh = _receive(root, pack, actor_id, receipt, report_name, expected_digest, allowed_packs)
        if fresh["review_id"] != expected_review_id:
            raise Invalid("The evidence changed before publication. Check it again.")
        os.link(temp, target)
        try:
            fresh = _receive(root, pack, actor_id, receipt, report_name, expected_digest, allowed_packs)
            if fresh["review_id"] != expected_review_id or source._bytes(target) != raw:
                raise Invalid("The evidence changed while its binding was saved. Check the current files before continuing.")
        except BaseException:
            # A concurrent author's changed file is never part of our rollback.
            if target.is_file() and source._bytes(target) == raw:
                target.unlink()
            raise
    finally:
        temp.unlink(missing_ok=True)
    return {"ok": True, "errors": [], "changed": True, "review_id": result["review_id"],
            "path": target.relative_to(root).as_posix(), "notice": NOTICE}


@_guard
def read(root, pack, actor_id, review_id, *, allowed_packs=None):
    root, product, pack = _scope(root, pack, actor_id, allowed_packs)
    if not isinstance(review_id, str) or not re.fullmatch(r"[a-f0-9]{24}", review_id):
        raise Invalid("Choose a saved EDA evidence binding for this product.")
    raw, record = _yaml(product / REVIEW_DIR / (review_id + ".yaml"))
    if _sha(record)[:24] != review_id or record.get("pack") != pack:
        raise Invalid("The saved EDA binding was changed or belongs to another product.")
    current = _context(root, pack, actor_id, allowed_packs, record["receipt"])[-1]
    result = _receive(root, pack, actor_id, record["receipt"], record["evidence_name"], current, allowed_packs)
    if result["record"] != record or source._bytes(product / REVIEW_DIR / (review_id + ".yaml")) != raw:
        raise Invalid("The saved EDA binding is stale. Receive and review the current build evidence again.")
    return result


def recent(root, pack, actor_id, *, allowed_packs=None):
    try:
        root, product, pack = _scope(root, pack, actor_id, allowed_packs)
        rows = []
        folder = source._safe(product / REVIEW_DIR)
        for path in sorted(folder.glob("*.yaml"), reverse=True)[:40]:
            raw, record = _yaml(path)
            if _sha(record)[:24] != path.stem or record.get("pack") != pack or not _ID.fullmatch(str(record.get("build_id") or "")):
                continue
            rows.append({"id": path.stem, "route": "eda_review", "title": "EDA evidence · " + record["build_id"],
                         "state": "binding recorded; recheck on open", "summary": "Six-layer evidence reference; no counts copied into the branch.",
                         "params": {"review_id": path.stem}, "updated_at": ""})
        return rows
    except (OSError, ValueError, TypeError, KeyError, AttributeError, yaml.YAMLError, source.Invalid, details._Invalid):
        return []
