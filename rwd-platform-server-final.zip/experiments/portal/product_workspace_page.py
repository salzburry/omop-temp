"""A task-first doorway to the connected product workflow; no gate is inferred here."""
from __future__ import annotations

import streamlit as st
import connected_workflow as workflow

TASKS = {
    "define": ("Define and reuse", "Start with the specification, compare prior meaning, and draft the interpretation.",
               ("scientific_draft", "knowledge_explorer", "questions", "template_library")),
    "change": ("Change this product", "Review changed requirements, declare a delivery or propose a configuration change.",
               ("revision_review", "plan_changes", "source_delivery", "change_impact", "implementation_patterns")),
    "evaluate": ("Evaluate for my studies", "Inspect data requirements, explore feasibility and review each study's choices.",
                 ("source_requirements", "eda_review", "claims_workspace", "feasibility", "dataset_comparison", "study_protocol")),
    "review": ("Review and prepare promotion", "Keep shared concept reuse and exact build publication as separate, checked decisions.",
               ("review_inbox", "template_library", "semantic_export", "release_readiness", "branch_changes", "handoffs")),
}


def render(root, pack, actor_id, *, allowed_packs, local_demo, can_write, can_review, route, params=None):
    if pack not in allowed_packs:
        st.error("This product is outside your access.")
        return
    context = (str(root), pack, actor_id)
    if st.session_state.get("product_ws_context") != context:
        st.session_state["product_ws_context"] = context
        st.session_state.pop("product_ws_task", None)
    task = st.radio("What would you like to do?", list(TASKS),
                    format_func=lambda value: TASKS[value][0], key="product_ws_task")
    st.write(TASKS[task][1])
    for target in TASKS[task][2]:
        meta = workflow.ROUTES[target]
        with st.container(border=True):
            st.write(meta.purpose)
            if st.button(meta.title, key="product_ws_" + target, width="stretch"):
                return {"route": target}
    with st.expander("Help me work through this"):
        st.write("The product guide explains the current step. For evidence that needs a closer look, run the relevant specialist and review its proposal before continuing.")
        if st.button("Get help with evidence", key="product_ws_assistant"):
            return {"route": "specialist_assistant"}
        if st.button("Review and improve assistant routing", key="product_ws_model_lifecycle"):
            return {"route": "model_lifecycle"}
        if st.button("Check product progress", key="product_ws_progress"):
            return {"route": "progress"}
