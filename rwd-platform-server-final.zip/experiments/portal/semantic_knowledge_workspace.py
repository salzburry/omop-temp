"""Read-only knowledge sources and exact semantic graph inspection for one product.

Graph generation and SHACL use the existing governed exporter. This view cannot
save an export or publish it. Its reserved .invalid identifiers label a preview;
the existing export workspace still requires an organisation-owned namespace.
"""
from __future__ import annotations

import hashlib
import importlib.util
import json
from pathlib import Path
import subprocess

import yaml

import semantic_export_workspace as exports
import science_workspace as science

PREVIEW_NAMESPACE = "https://preview.invalid/rwd"
MAX_BYTES = 8 * 1024 * 1024
NOTICE = ("This dashboard reads the selected product and shared reference declarations. "
          "Graph links and SHACL results describe the inspected evidence; scientific approval remains separate.")
SOURCES = (
    ("bindings", "Product concept bindings", "config/semantic.yaml", "Product", "yaml"),
    ("contract", "Scientific definitions and decisions", "handoff/FUNCTIONAL_CONTRACT.md", "Product", "markdown"),
    ("registration", "Registered source documents", "source_refs.yaml", "Product", "yaml"),
    ("extraction", "Extracted specification rows and citations", "spec_pipeline/out/extracted.json", "Product", "json"),
    ("definitions", "Shared analytical definitions", "governance/DEFINITIONS.yaml", "Shared reference", "yaml"),
    ("identifiers", "Concept identifiers and naming lifecycle", "governance/NAME_LIFECYCLE.yaml", "Shared reference", "yaml"),
    ("master", "Master variable inventory", "governance/reference/variable_inventory/INVENTORY.yaml", "Shared reference", "yaml"),
    ("logic", "Reusable master logic", "governance/reference/variable_inventory/REUSABLE_LOGIC.yaml", "Shared reference", "yaml"),
    ("terminology", "Terminology layer settings", "governance/reference/umls/LAYER.yaml", "Shared reference", "yaml"),
)


class _Loader(yaml.SafeLoader):
    def construct_mapping(self, node, deep=False):
        result = {}
        for key_node, value_node in node.value:
            key = self.construct_object(key_node, deep=deep)
            if not isinstance(key, str) or key in result:
                raise ValueError("Semantic binding keys must be unique text names.")
            result[key] = self.construct_object(value_node, deep=deep)
        return result


def _fail(error):
    message = ("The knowledge source could not be read. Check its registered location and product access."
               if isinstance(error, OSError) else str(error))
    return {"ok": False, "errors": [message], "notice": NOTICE}


def _sha(raw):
    return hashlib.sha256(raw.encode("utf-8") if isinstance(raw, str) else raw).hexdigest()


def _read(path):
    science._safe(path)
    with path.open("rb") as handle:
        raw = handle.read(MAX_BYTES + 1)
    if len(raw) > MAX_BYTES:
        raise ValueError("This source exceeds the supported knowledge preview size of 8 MB.")
    return raw


def _scope(root, pack, actor_id, allowed_packs):
    base, product, pack, actor, _folder = exports._scope(root, pack, actor_id, allowed_packs)
    digest = _sha(json.dumps([str(base), pack, actor, exports._inputs(base, pack)], ensure_ascii=True))
    return base, product, pack, digest


def _source_row(base, product, spec):
    identifier, label, relative, kind, format_name = spec
    path = (product if kind == "Product" else base) / relative
    science._safe(path)
    return {"id": identifier, "label": label, "path": path.relative_to(base).as_posix(),
            "kind": kind, "state": "Available" if path.is_file() else "Not recorded", "format": format_name}


def _bindings(product):
    path = product / "config/semantic.yaml"
    if not path.is_file():
        return "Not recorded", [], ["No product semantic binding file has been recorded."]
    doc = yaml.load(_read(path), Loader=_Loader)
    if not isinstance(doc, dict) or set(doc) - {"concept_set", "variables"}:
        raise ValueError("Product semantic bindings contain unknown fields or are not a mapping. Review clinical bindings.")
    variables = doc.get("variables")
    if variables is None:
        variables = {}
    if not isinstance(variables, dict):
        raise ValueError("Product semantic variables must be a mapping. Review clinical bindings.")
    rows = []
    for name, fields in variables.items():
        if not isinstance(name, str) or not isinstance(fields, dict):
            raise ValueError("Each semantic binding must name a variable and its recorded fields.")
        allowed = {"concept", "lab", "registry_concept", "definition", "status"}
        if set(fields) - allowed or any(not isinstance(v, str) for v in fields.values()):
            raise ValueError("A semantic binding contains an unknown or invalid field. Review clinical bindings.")
        rows.append({"variable": name, **{field: fields.get(field, "") for field in sorted(allowed)}})
    concept_set = doc.get("concept_set")
    if concept_set is not None and not isinstance(concept_set, str):
        raise ValueError("The concept set must be a recorded text identifier.")
    from person_rules import unstated
    warnings = []
    if unstated(concept_set):
        warnings.append("This product's concept set has not been selected.")
    if not rows:
        warnings.append("No variable semantic bindings are declared for this product yet.")
    return concept_set or "Not recorded", rows, warnings


def _capabilities():
    available = all(importlib.util.find_spec(name) is not None for name in ("rdflib", "pyshacl"))
    return [
        {"standard": "RDF / JSON-LD", "status": "Integrated", "purpose": "Concepts, product implementations and their relationships",
         "integration": "Generated from governed definitions; viewed here and saved through the semantic export workflow."},
        {"standard": "SHACL", "status": "Available; run for this graph" if available else "Processor dependencies unavailable",
         "purpose": "Required fields, types, provenance and cross-record constraints",
         "integration": "Explicit validation here; the existing export workflow requires conformance before saving."},
        {"standard": "SKOS", "status": "Integrated", "purpose": "Concept names, schemes and recorded mappings",
         "integration": "Included in the exported graph and linked to product bindings."},
        {"standard": "PROV-O", "status": "Integrated", "purpose": "Source citations, recorded attribution and derivation history",
         "integration": "Graph properties connect implementations to their supporting evidence."},
        {"standard": "RDFS / OWL", "status": "Limited", "purpose": "Labels, comments and recorded retirement",
         "integration": "RDFS metadata and owl:deprecated are used. No general OWL reasoner is connected."},
        {"standard": "SPARQL / graph service", "status": "Local constraints only", "purpose": "Cross-node validation constraints",
         "integration": "SPARQL is used by SHACL. No remote graph-query service or RDF-to-code execution path is connected."},
    ]


def describe(root, pack, actor_id, *, allowed_packs=None):
    try:
        base, product, pack, digest = _scope(root, pack, actor_id, allowed_packs)
        sources = [_source_row(base, product, item) for item in SOURCES]
        warnings = []
        try:
            concept_set, bindings, warnings = _bindings(product)
        except (ValueError, yaml.YAMLError) as error:
            concept_set, bindings = "Needs repair", []
            warnings.append(str(error))
        return {"ok": True, "pack": pack, "input_digest": digest, "sources": sources,
                "bindings": bindings, "capabilities": _capabilities(), "errors": [], "notice": NOTICE,
                "status": {"integration": "Connected to definitions, semantic export and release binding checks",
                           "concept_set": concept_set, "bindings_declared": len(bindings),
                           "warnings": warnings,
                           "execution_authority": "Reviewed YAML and contracts; the RDF graph does not drive builds."}}
    except (ValueError, OSError, TypeError, KeyError, yaml.YAMLError, RecursionError) as error:
        return _fail(error)


def source(root, pack, actor_id, source_id, *, expected_digest, allowed_packs=None):
    try:
        base, product, pack, digest = _scope(root, pack, actor_id, allowed_packs)
        if digest != expected_digest:
            raise ValueError("Knowledge inputs changed. Refresh the dashboard before opening source details.")
        spec = next((item for item in SOURCES if item[0] == source_id), None)
        if spec is None:
            raise ValueError("Choose a knowledge source listed for this product.")
        item = _source_row(base, product, spec)
        if item["state"] != "Available":
            raise ValueError("This source has not been recorded yet. Open the corresponding review step.")
        raw = _read(base / item["path"])
        if _scope(root, pack, actor_id, allowed_packs)[3] != digest:
            raise ValueError("Knowledge inputs changed while reading. Refresh the dashboard.")
        return {"ok": True, "input_digest": digest, "source": {**item, "content": raw.decode("utf-8"),
                "sha256": _sha(raw)}, "errors": []}
    except (ValueError, OSError, TypeError, KeyError, UnicodeError, yaml.YAMLError, RecursionError) as error:
        return _fail(error)


def _projection(root, pack, actor_id, expected_digest, allowed_packs, *, run_validation):
    base, _product, pack, digest = _scope(root, pack, actor_id, allowed_packs)
    if digest != expected_digest:
        raise ValueError("Knowledge inputs changed. Reload the current graph before continuing.")
    value = exports._run(base, pack, PREVIEW_NAMESPACE, run_validation=run_validation)
    if not value.get("ok"):
        raise ValueError("The current semantic graph could not be prepared. Review scientific definitions and clinical bindings.")
    if _scope(root, pack, actor_id, allowed_packs)[3] != digest:
        raise ValueError("Knowledge inputs changed during graph preparation. Reload the current graph.")
    return digest, value


def browse(root, pack, actor_id, *, expected_digest, allowed_packs=None):
    try:
        digest, value = _projection(root, pack, actor_id, expected_digest, allowed_packs, run_validation=False)
        from semantic_knowledge_graph import inspect_graph
        inspected = inspect_graph(value["graph"], value["shapes"])
        return {"ok": True, "input_digest": digest, "namespace": PREVIEW_NAMESPACE, "preview_only": True,
                **value, **inspected, "graph_sha256": _sha(value["graph"]), "shapes_sha256": _sha(value["shapes"]),
                "errors": [], "notice": NOTICE}
    except (ValueError, OSError, TypeError, KeyError, yaml.YAMLError, RecursionError, subprocess.TimeoutExpired) as error:
        return _fail(error)


def validate(root, pack, actor_id, *, expected_digest, graph_sha256, allowed_packs=None):
    try:
        # Reject a changed graph before paying for validation, then validate an
        # independently regenerated projection with exactly the same input binding.
        digest, value = _projection(root, pack, actor_id, expected_digest, allowed_packs, run_validation=False)
        if _sha(value["graph"]) != graph_sha256:
            raise ValueError("The inspected graph changed. Reload it before running SHACL.")
        shapes_sha256 = _sha(value["shapes"])
        _digest, validated = _projection(root, pack, actor_id, expected_digest, allowed_packs, run_validation=True)
        if _sha(validated["graph"]) != graph_sha256 or _sha(validated["shapes"]) != shapes_sha256:
            raise ValueError("The graph or SHACL shapes changed during validation. Reload the graph.")
        return {"ok": True, "input_digest": digest, "graph_sha256": graph_sha256,
                "shapes_sha256": shapes_sha256, "validation": validated["validation"], "errors": []}
    except (ValueError, OSError, TypeError, KeyError, yaml.YAMLError, RecursionError, subprocess.TimeoutExpired) as error:
        return _fail(error)
