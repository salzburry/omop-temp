"""Read-only continuations from a compared source change to its declared work.

Source coordinates identify the selected cut only. A removed row never becomes a
current definition merely because the new workbook reused its row number.
"""
from __future__ import annotations

import difflib
import json
import yaml

import contract_lint as cl
import decision_answers
import lifecycle_workspace as lifecycle
import scientific_definitions as definitions


def _rows(product):
    data = json.loads(lifecycle._read(product / "spec_pipeline/out/extracted.json"))
    rows = {}
    for row in definitions.requirement_rows(data):
        item = definitions.row_item_id(row)
        if item in rows:
            raise ValueError("The extraction repeats a source coordinate. Regenerate it before reviewing this change.")
        rows[item] = row
    return rows


def _source(row):
    if row is None:
        return None
    return {key: row[key] for key in ("variable", "tab", "domain", "citation_domain", "row", "header", "cells", "fields") if key in row}


def review(root, pack, actor_id, previous, *, kind, item_id, expected_digest, allowed_packs):
    """Resolve only a current canonical comparison; never copy or save a judgment."""
    try:
        comparison = lifecycle.revision(root, pack, actor_id, previous, allowed_packs=allowed_packs)
        if not comparison["ok"]:
            return comparison
        if comparison["digest"] != expected_digest:
            raise ValueError("The compared cuts or saved drafts changed. Compare again before continuing this source change.")
        if kind not in {"added", "changed", "removed"} or not any(
                row["item_id"] == item_id for row in comparison["changes"][kind]):
            raise ValueError("Choose a change from the current specification comparison.")
        _base, product, _pack, _owner, _folder = lifecycle._scope(root, pack, actor_id, allowed_packs)
        _base, old, _previous, _owner, _folder = lifecycle._scope(root, previous, actor_id, allowed_packs)
        before = _source(_rows(old).get(item_id)) if kind != "added" else None
        current_row = _rows(product).get(item_id) if kind != "removed" else None
        after = _source(current_row)
        selected, editor_note = None, ""
        if current_row and current_row.get("variable") and not definitions.is_context(current_row):
            editor = definitions.describe(root, pack, actor_id, item_id=item_id, allowed_packs=allowed_packs)
            if editor["ok"]:
                selected = editor["selected"]
                editor_note = editor["apply_blocker"]
            else:
                editor_note = " ".join(editor["errors"])
        elif kind != "removed":
            editor_note = "This source row has no named editable requirement. Review its scientific question before drafting a definition."
        questions, question_note = [], ""
        if current_row is not None:
            contract = lifecycle._read(product / "handoff/FUNCTIONAL_CONTRACT.md").decode("utf-8").replace("\r\n", "\n")
            linked = set()
            domain, number = item_id.rsplit(":", 1)
            for block in cl.records(contract):
                cited = {pair for ref in (cl._list(block, "spec_refs") or []) for pair in cl.spec_ref_rows(ref)}
                if (domain, int(number)) in cited:
                    linked.update(cl._list(block, "decision_ids") or [])
            answers = decision_answers.describe(root, pack, allowed_packs=allowed_packs)
            if not answers["ok"]:
                question_note = " ".join(answers["errors"])
            else:
                register = lifecycle._read(product / "handoff/DECISIONS.md").decode("utf-8").replace("\r\n", "\n")
                states, rows = cl.decision_status(register), cl.decision_rows(register)
                for did in sorted(linked & set(rows)):
                    questions.append({"id": did, "question": cl.decision_question(rows[did]),
                                      "status": states.get(did, "UNKNOWN"),
                                      "issued": did not in answers["unissued_ids"]})
        fresh = lifecycle.revision(root, pack, actor_id, previous, allowed_packs=allowed_packs)
        if not fresh["ok"] or fresh["digest"] != expected_digest:
            raise ValueError("A source or scientific record changed while loading this review. Compare again.")
        text = lambda value: [] if value is None else (json.dumps(value, indent=2, ensure_ascii=False) + "\n").splitlines(True)
        return {"ok": True, "errors": [], "kind": kind, "item_id": item_id,
                "before": before, "after": after, "selected": selected, "editor_note": editor_note,
                "questions": questions, "question_note": question_note,
                "diff": "".join(difflib.unified_diff(text(before), text(after),
                    fromfile=previous + " · " + item_id, tofile=pack + " · " + item_id)),
                "impact_params": {"item_id": item_id + "@" + previous.rsplit("/", 1)[-1] if kind == "removed" else item_id,
                                  "previous_pack": previous}}
    except (OSError, ValueError, TypeError, KeyError, yaml.YAMLError) as error:
        return lifecycle._fail(error)
