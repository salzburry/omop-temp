"""Separate reusable prose from explicitly identified reference-product values.

This is a drafting boundary, not a scientific equivalence classifier. Numbers
are not removed by their shape: arithmetic constants remain part of the rule.
Ambiguous timing/threshold wording needs the person's explicit review.
"""
from __future__ import annotations

import re
import ast

import contract_lint as cl

_MONTH = r"(?:Jan(?:uary)?|Feb(?:ruary)?|Mar(?:ch)?|Apr(?:il)?|May|Jun(?:e)?|Jul(?:y)?|Aug(?:ust)?|Sep(?:tember)?|Oct(?:ober)?|Nov(?:ember)?|Dec(?:ember)?)"
_CALENDAR = re.compile(
    r"(?<![\w.])(?:"
    r"(?:19|20)\d{2}[-/.]\d{1,2}[-/.]\d{1,2}|"
    r"\d{1,2}[-/.]\d{1,2}[-/.](?:(?:19|20)\d{2}|\d{2})|"
    r"\d{1,2}[- ]" + _MONTH + r"[- ]\d{2,4}|"
    + _MONTH + r"\s+\d{1,2}(?:st|nd|rd|th)?(?:,\s*|[- ]+)\d{2,4}|"
    + _MONTH + r"\s+(?:19|20)\d{2}|"
    r"(?:19|20)\d{6})(?!\w|\.\d)", re.I)
_YEAR_CONTEXT = re.compile(r"\b(?:since|from|before|after|starting|through|cutoff|cut-off|start(?:s)?(?: in)?|end(?:s)?(?: in)?)\s+(?:the year\s+)?((?:19|20)\d{2})\b", re.I)
_QUANTITY = re.compile(r"(?<![\w.])-?\d+(?:\.\d+)?\s*(?:days?|weeks?|months?|years?|hours?|minutes?)\b", re.I)
_THRESHOLD = re.compile(r"(?:<=|>=|==|!=|[<>≤≥])\s*[-+]?\d+(?:\.\d+)?\b|"
                        r"\b(?:threshold|cutoff|cut-off|minimum|maximum|at least|at most|more than|less than|greater than)\s*(?:of|is|=|:)?\s*[-+]?\d+(?:\.\d+)?\b", re.I)
_ASSIGNED_STRING = re.compile(r"\b[A-Z][A-Z0-9_]*\s*=\s*([\"'])([^\"'\r\n]+)\1")
_ILLUSTRATIVE = re.compile(r"\be\.g\.|\b(?:for example|for instance|illustrative|examples?)\b", re.I)
_EMPTY = {"", "n/a", "none", "null", "todo", "tbd", "replace_me"}


def _plain(value):
    return str(value if value is not None else "").strip().strip("\"'")


def _source(record):
    interpreted = dict(record.get("interpreted") or [])
    value = interpreted.get("Source table and field", "")
    if isinstance(value, dict):
        return value
    return cl.parse_block("source: " + str(value)).source


def _parameter_value(record, parameter):
    """Resolve only a parameter's exact path in an already resolved config block."""
    parts = parameter.split(".")
    found = []
    for ref, fragment in record.get("executable") or []:
        if "#/" not in str(ref):
            continue
        pointer = str(ref).split("#/", 1)[1].strip("/").split("/")
        pointer = [part for part in pointer if part]
        if parts[:len(pointer)] != pointer:
            continue
        value = fragment
        for part in parts[len(pointer):]:
            if not isinstance(value, dict) or part not in value:
                value = None
                break
            value = value[part]
        if value is not None and not isinstance(value, (dict, list, tuple)):
            found.append(_plain(value))
    unique = set(found)
    return unique.pop() if len(unique) == 1 else ""


def _declared(record):
    source = _source(record)
    values = []
    if _plain(source.get("kind")).lower() == "constant":
        values.append((_plain(source.get("value")), "{{product_value}}"))
    if _plain(source.get("kind")).lower() == "parameter":
        raw = source.get("parameters") or []
        refs = raw if isinstance(raw, list) else re.findall(r"[A-Za-z_][A-Za-z0-9_.]*", str(raw))
        refs = list(dict.fromkeys(str(parameter) for parameter in refs
            if re.fullmatch(r"[A-Za-z_][A-Za-z0-9_]*(?:\.[A-Za-z_][A-Za-z0-9_]*)+", str(parameter))))
        explicit_token = "{{" + refs[0] + "}}" if len(refs) == 1 else "{{product_value}}"
        values.append((_plain(source.get("value")), explicit_token))
        for parameter in refs:
            values.append((_parameter_value(record, parameter), "{{" + parameter + "}}"))
    return list(dict.fromkeys((literal, token) for literal, token in values if literal.casefold() not in _EMPTY))


def _occurs(text, literal):
    return bool(re.search(r"(?<!\w)" + re.escape(literal) + r"(?!\w)", text))


def _calendar_values(text):
    return [match.group(0) for match in _CALENDAR.finditer(text)] + [match.group(1) for match in _YEAR_CONTEXT.finditer(text)]


def _literal_scalar(text):
    """A complete scalar payload, as opposed to a formula or prose instruction."""
    text = text.strip()
    if re.fullmatch(r"\{\{[A-Za-z_][A-Za-z0-9_.]*\}\}", text):
        return False
    if re.fullmatch(r"[-+]?\d+(?:\.\d+)?|[A-Za-z_][A-Za-z0-9_.:/-]*", text):
        return True
    return bool(re.fullmatch(r"([\"'])([^\r\n]+)\1", text) and not re.search(r"[+*/()]", text))


def _named_parameter(text):
    return bool(re.search(r"\{\{[A-Za-z_][A-Za-z0-9_.]*\}\}", text))


def _arithmetic_constants(text):
    # Inspect syntax only; never execute reference text. A label such as
    # "Prostate dataset-1" is not evidence of an arithmetic rule.
    expression = re.sub(r"^\s*(?:use|return|calculate|compute)\s+", "", text, flags=re.I)
    try:
        tree = ast.parse(expression.strip(), mode="eval")
    except (SyntaxError, ValueError, RecursionError):
        return False
    constants = [node.value for node in ast.walk(tree) if isinstance(node, ast.Constant)]
    return bool(constants and all(type(value) in {int, float} for value in constants)
                and any(isinstance(node, ast.BinOp) for node in ast.walk(tree)))


def describe(record):
    """Fields merged into a candidate; a missing safe template is never raw fallback."""
    raw = str(record.get("derivation") or "")
    text = raw
    issues = []
    declarations = _declared(record)
    unresolved_value = _plain(_source(record).get("kind")).lower() in {"constant", "parameter"} and not declarations
    # A repeated value mapped to different parameters cannot name its own role.
    ambiguous = {literal for literal, token in declarations
                 if len({other for value, other in declarations if value == literal}) != 1}
    for literal, token in declarations:
        if not _occurs(text, literal):
            continue
        if literal in ambiguous:
            issues.append("A reference value belongs to multiple parameters. Write the intended parameter in the logic.")
            continue
        if text.strip().strip("\"'") == literal:
            text = token
        elif _CALENDAR.fullmatch(literal):
            text = re.sub(r"(?<!\w)" + re.escape(literal) + r"(?!\w)", lambda _m: token, text)
        else:
            # Whole quoted strings/scalars have a definite boundary. A bare 1
            # or 2 inside a formula does not: replacing it could change the rule.
            quoted = re.compile(r"([\"'])" + re.escape(literal) + r"\1")
            text = quoted.sub(lambda _m: token, text)
        if _occurs(text, literal):
            issues.append("A declared reference value remains inside the logic. Replace the product value with a named parameter; preserve arithmetic constants that define the rule.")
    if _plain(_source(record).get("kind")).lower() in {"constant", "parameter"} and _literal_scalar(text):
        issues.append("The reference contains a scalar value without an unambiguous reusable parameter. Write named-parameter logic and enter the actual value through Edit this product's values.")
    elif unresolved_value and not _named_parameter(text) and not _arithmetic_constants(text):
        issues.append("The reference does not declare or resolve its product value. Write logic using a named parameter before reusing this text.")
    if _calendar_values(text):
        issues.append("The reference logic contains a calendar date. Use a named parameter in the logic and enter the actual date through Edit this product's values.")
    if _QUANTITY.search(text):
        issues.append("Review the stated timing amounts: keep only quantities that define the algorithm, and use named parameters for product-specific windows.")
    if _THRESHOLD.search(text):
        issues.append("Review the numeric cutoff: keep it only if it defines the algorithm, and use a named parameter for a product-specific threshold.")
    if _ASSIGNED_STRING.search(text):
        issues.append("The logic assigns a quoted value. Review whether it is a product-specific label or a category that defines the algorithm.")
    if _ILLUSTRATIVE.search(text):
        issues.append("This reference includes illustrative examples. Edit the reusable logic and confirm which parts describe the algorithm, keeping example values separate.")
    if not raw.strip():
        issues.append("The reference has no interpretation to reuse. Write this product's logic.")
    return {"reusable_derivation": "" if issues else text,
            "reuse_readiness": "needs_edit" if issues else "ready",
            "reuse_issues": list(dict.fromkeys(issues))}


def validate(record, interpretation, *, disposition, logic_reviewed=False):
    """Recheck an explicit stage/copy choice, including proposals saved by older code."""
    original = describe(record)
    text = str(interpretation or "")
    if disposition == "defer":
        return original
    if not text.strip():
        raise ValueError("Write the reusable logic, or defer this choice.")
    if disposition == "inherit":
        if original["reuse_readiness"] != "ready":
            raise ValueError("This reference contains values that need review. Choose adapt and write reusable logic using named parameters.")
        if text != original["reusable_derivation"]:
            raise ValueError("Inherit uses only the displayed reusable logic. Reload the comparison or choose adapt to edit it.")
        return original
    if disposition not in {"adapt", "diverge"}:
        raise ValueError("Choose inherit, adapt, diverge or defer.")
    if _calendar_values(text):
        raise ValueError("Keep calendar dates out of reusable logic. Use a named parameter and enter the actual date through Edit this product's values.")
    source_kind = _plain(_source(record).get("kind")).lower()
    if source_kind in {"constant", "parameter"} and _literal_scalar(text):
        raise ValueError("Use named-parameter logic instead of a raw scalar value. Enter the actual value through Edit this product's values.")
    if source_kind in {"constant", "parameter"} and not _declared(record) and not _named_parameter(text) and not _arithmetic_constants(text):
        raise ValueError("The reference does not identify its product value. Use named-parameter logic and enter the actual value separately.")
    proposed = describe({**record, "derivation": text})
    if (original["reuse_readiness"] == "needs_edit" or proposed["reuse_readiness"] == "needs_edit") and logic_reviewed is not True:
        raise ValueError("Review the logic and confirm that product-specific values stay in this product's value fields; retain only constants that define the algorithm.")
    # Explicit declared string values are product metadata, not mathematical
    # constants. A checkbox cannot turn a copied dataset name into generic logic.
    for literal, _token in _declared(record):
        if (source_kind == "parameter" or not re.fullmatch(r"[-+]?\d+(?:\.\d+)?", literal)) and _occurs(text, literal):
            raise ValueError("Replace the reference product's value with a named parameter in the reusable logic. Enter this product's value separately.")
    return original
