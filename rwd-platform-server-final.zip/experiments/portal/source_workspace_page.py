"""Guided source workspaces, using the existing source and count checks."""
from __future__ import annotations

import copy
from contextlib import nullcontext
import json

import streamlit as st
import source_workspace as backend
import handoffs_page
import document_page
import form_assistance as form_help

PREFIX = "source_ws_"


def _evidence_picker(arguments, label, key, *, kind="profile", record_id=None,
                     previous=False, peer_name=None):
    """The existing receive actions still validate; choosing a file writes nothing."""
    read_arguments = {name: arguments[name] for name in ("root", "pack", "actor_id", "allowed_packs") if name in arguments}
    result = backend.evidence_options(**read_arguments, kind=kind, record_id=record_id,
                                      previous=previous, peer_name=peer_name)
    choice_key, binding_key = key + "_choice", key + "_binding"
    binding = (str(arguments["root"]), arguments["pack"], arguments["actor_id"], record_id,
               previous, peer_name, result.get("inputs_sha256"))
    old_binding = st.session_state.get(binding_key)
    if old_binding is not None and old_binding != binding:
        st.session_state.pop(choice_key, None)
        st.session_state.pop(key, None)
    st.session_state[binding_key] = binding
    options = result.get("options", []) if result.get("ok") else []
    labels = {item["name"]: item["label"] for item in options}
    digests = {item["name"]: item["sha256"] for item in options}
    prior_digests = st.session_state.get(key + "_digests", {})
    chosen = st.session_state.get(choice_key)
    if chosen not in labels or (chosen in prior_digests and prior_digests[chosen] != digests.get(chosen)):
        if chosen:
            st.info("The previously selected evidence changed, is no longer available or no longer matches this step. Choose a current file.")
        st.session_state.pop(choice_key, None)
    st.session_state[key + "_digests"] = digests

    def use_selection():
        st.session_state.pop(key, None)

    selected = st.selectbox(label, list(labels), index=None, key=choice_key,
                            format_func=lambda name: labels.get(name, name),
                            placeholder="Choose compatible evidence" if options else "No compatible evidence found",
                            help="Only existing files matching this product, delivery and request are offered. Selection writes nothing; the receive action checks the file again.",
                            disabled=not options, on_change=use_selection)
    if not result.get("ok"):
        for message in result.get("errors", []):
            st.info(message)
    elif not options:
        st.info("No compatible evidence is available yet. " + result["next_step"])
    else:
        st.caption(f"{len(options)} compatible file(s). A matching file may contain failed checks; review its findings after receiving it.")
    if result.get("truncated"):
        st.caption("The folder could not be searched completely. Ask the data expert to organize the completed files closer to the evidence folder, or enter the known file name below.")
    with st.expander("Enter a known file name · " + label):
        manual = st.text_input(label + " file name", key=key,
                               help="Optional: the completed file's name inside the restricted evidence folder, including its subfolder. A typed name overrides the selection and receives the same binding checks.")
        if manual.strip():
            st.caption("The typed file name will be used. Choose an item above to clear it.")
    return manual.strip() or selected or ""


def _ask(arguments, *, action_id, label, owner, note, key):
    """Hand a step this page cannot do to the role that owns it, as a tracked request. The note
    starts as the page's own statement of the need; the person edits it before sending."""
    note_key = f"{handoffs_page.PREFIX}{key}_note_{action_id}"
    if note_key not in st.session_state:
        st.session_state[note_key] = note
    return handoffs_page.ask(arguments["root"], arguments["pack"], {"id": action_id, "label": label}, {"owner": owner, "text": label},
                             arguments["actor_id"], local_demo=bool(arguments.get("local_demo")), can_view=True,
                             allowed_packs=arguments.get("allowed_packs"), key=key)


def _legacy_review(arguments):
    current = backend.legacy_source_preview(arguments["root"], arguments["pack"], arguments["actor_id"],
        allowed_packs=arguments.get("allowed_packs"))
    if not current.get("ok") or not current.get("count"):
        return
    with st.expander(f"Review older multi-table declarations ({current['count']})"):
        st.write("These definitions combine several source tables in one declaration. A completed delivery profile can identify unambiguous column locations. Review that proposal with Engineering before converting the contract.")
        name = _evidence_picker(arguments, "Completed full profile for these declarations", PREFIX + "legacy_profile")
        if st.button("Compare source declarations", key=PREFIX + "legacy_preview", disabled=not name.strip()):
            st.session_state[PREFIX + "legacy_selected_profile"] = name.strip()
        if st.session_state.get(PREFIX + "legacy_selected_profile") != name.strip() or not name.strip():
            return
        result = backend.legacy_source_preview(arguments["root"], arguments["pack"], arguments["actor_id"],
            profile_name=name.strip(), allowed_packs=arguments.get("allowed_packs"))
        if _errors(result):
            return
        st.caption("Only source table and column names are shown. A unique location does not establish clinical meaning or approve the mapping.")
        for row in result["rows"]:
            st.write("**" + row["variable"] + "**")
            if row["diff"]:
                st.code(row["diff"], language="diff")
            for blocker in row["blockers"]:
                st.warning(blocker)
        _ask(arguments, action_id="legacy-source-review:" + result["inputs_sha256"][:24],
            label="Review and migrate older source declarations", owner="Engineering", note=backend.legacy_handoff_note(result), key="legacy_source")


def _folder_handoff(arguments, reason, key):
    """The restricted evidence folder is absent: say so, and offer the data expert's setup as a handoff
    instead of a form that can only refuse."""
    st.warning(reason)
    st.write("Ask the data expert to set up the restricted evidence folder on this computer. The request is listed on Home and on the Handoffs page until it is answered.")
    _ask(arguments, action_id="source_restricted_folder", label="Set up the restricted evidence folder", owner="Data expert", key=key,
         note=(f"Please set up the restricted evidence folder on this computer for {arguments['pack']}, so delivery evidence files "
               "can be received and mapping suggestions loaded from it."))


def _errors(result):
    if not result.get("ok"):
        for message in result.get("errors", ["The operation could not be completed."]):
            st.error(message)
        return True
    return False


def _remember(route, result):
    if _errors(result):
        return False
    record = result["record"]
    st.session_state[PREFIX + route + "_id"] = record["id"]
    # an answer that changed nothing says so in its own words; a saved record speaks through its summary
    st.session_state[PREFIX + "notice"] = result.get("message") or record["payload"].get("summary", backend.NOTICE)
    return True


def _document_context(arguments):
    """The triple the portal renders its document dialog with (who reads, which product, which
    workspace section). A document opened with another context is dismissed unseen (walk RW4-N01)."""
    return (arguments["actor_id"], arguments["pack"], st.session_state.get("section", "Flow"))


def _show_record(record, stale, enabled, arguments, folder):
    st.markdown(f"**{record['title']} · {record['state'].replace('_', ' ')}**")
    payload = record["payload"]
    st.write(payload.get("summary", backend.NOTICE))
    if stale:
        st.warning("The product changed after this work was saved. Start a new request or reload suggestions before continuing.")
    request = {key: record[key] for key in ("id", "pack", "route", "state", "inputs_sha256", "updated_at")}
    request["payload"] = payload
    st.download_button("Download this request or review record", json.dumps(request, indent=2),
                       file_name=f"{record['route']}-{record['id'][:8]}.json", mime="application/json", key=PREFIX + "download_" + record["id"])
    if record["route"] == "source_evidence":
        expected = payload.get("expected") or {}
        with st.expander("What the approved environment must return", expanded=True):
            st.write(f"Three files are expected back for cut {expected.get('cut') or 'not declared'} of schema {expected.get('schema') or 'not declared'}:")
            for number, sentence in enumerate(backend.runtime_sentences(payload), start=1):
                st.write(f"{number}. {sentence}")
            st.caption("The exact request, with everything an engineer needs to run these steps, is in the download above.")
        _ask(arguments, action_id="source_evidence_" + record["id"][:8], label="Run the delivery evidence steps", owner="Engineering",
             note=backend.engineering_note(arguments["pack"], payload), key="source_ws_runtime")
        st.caption("Evidence files stay in the restricted evidence folder; this page never uploads data. Receiving a file checks identity and exact bytes; it does not prove who ran the job or approve its findings.")
        if not folder["ok"]:
            _folder_handoff(arguments, folder["reason"], key="source_ws_folder")
        else:
            path = _evidence_picker(arguments, "Completed full profile", PREFIX + "profile_return", record_id=record["id"])
            with st.form(PREFIX + "profile_intake"):
                submit = st.form_submit_button("Check and receive profile", disabled=not enabled or stale)
            if submit and _remember("source_evidence", backend.receive_profile(**arguments, record_id=record["id"], profile_name=path)):
                st.rerun()
        if payload.get("received", {}).get("profile"):
            profile = payload["received"]["profile"]
            st.write(f"Profile received: {profile['table_count']} tables and {profile['column_count']} columns.")
            if payload.get("stale_report"):
                st.warning(payload["stale_report"])
            with st.expander("Identifiers and digests"):
                st.write("Profile digest: " + profile["sha256"])
                st.write("Profile file: " + profile["path"])
                for name in ("schema", "source_qc"):
                    if payload["received"].get(name):
                        st.write(f"{name.replace('_', ' ')} result: {payload['received'][name]['result']}; digest {payload['received'][name]['sha256']}")
            if folder["ok"]:
                schema = _evidence_picker(arguments, "Schema check result", PREFIX + "schema_return", kind="schema", record_id=record["id"])
                qc = _evidence_picker(arguments, "Source quality check result", PREFIX + "qc_return", kind="source_qc", record_id=record["id"])
                with st.form(PREFIX + "report_intake"):
                    submit_reports = st.form_submit_button("Check reports and prepare review preview", disabled=not enabled or stale)
                if submit_reports and _remember("source_evidence", backend.receive_source_reports(**arguments, record_id=record["id"], schema_name=schema, qc_name=qc)):
                    st.rerun()
        if payload.get("source_report_preview"):
            st.write("Review this generated report and save it to the workflow record. Next, the data expert reviews the source mappings in the workflow and runs Check again. Receiving or saving these files does not complete Gate 3.")
            with st.expander("Counts from the check"):
                st.json(payload.get("source_counts", {}))
            with st.expander("Source report preview"):
                st.code(payload["source_report_preview"], language="markdown")
            st.download_button("Download generated source report", payload["source_report_preview"],
                               file_name=payload["source_report_target"].rsplit("/", 1)[-1], mime="text/markdown", key=PREFIX + "report_download")
            with st.expander("Changes to the workflow source report", expanded=True):
                st.code(payload.get("source_report_diff") or "No changes to the generated report.", language="diff")
            st.caption("The report is saved as this product's source verdict report. Human review remains pending; the generated report creates no mapping confirmation or approval.")
            if record["state"] == "source_report_ready_for_review":
                confirmed = st.checkbox("I reviewed the generated report diff and want to save it for source review.",
                                        key=PREFIX + "report_confirm_" + record["id"], disabled=not enabled or stale)
                if st.button("Save generated report for source review", key=PREFIX + "save_source_report", disabled=not enabled or stale or not confirmed):
                    result = backend.save_source_report(**arguments, record_id=record["id"], confirmed=confirmed)
                    if _remember("source_evidence", result):
                        # the confirmation and the link to the saved report are shown here, on the
                        # next render; Progress re-evaluates the product when the person continues
                        st.session_state.setdefault("flow_result", {}).pop(arguments["pack"], None)
                        st.rerun()
            elif record["state"] == "source_report_saved_pending_review":
                st.write("The generated report is saved in this product with its review pending. Progress shows Gate 3 evidence for these records only after the data expert confirms the source mappings in the workflow.")
                document_page.reference(arguments["root"], arguments["pack"] + "/" + payload["source_report_target"],
                                        key=PREFIX + "open_report_" + record["id"], label="Open the saved source report",
                                        allowed_packs=arguments.get("allowed_packs"), context=_document_context(arguments))
                # WHERE THE REVIEW HAPPENS (walk RW4-N02): the confirmation is a stage 3 step on the
                # Flow page, which offers only the current stage's steps; a button that sent the
                # person there early landed them on an unrelated act with no word about this report
                st.write("The data expert confirms the source mappings on the Flow page once the product reaches stage 3; "
                         "that step cannot be opened from here before then. Until then the saved report waits here, and the "
                         "request below keeps it on the data expert's list.")
                _ask(arguments, action_id="source_mapping_review_" + record["id"][:8], label="Confirm the source mappings",
                     owner="Data expert", key="source_ws_source_review",
                     note=(f"Please review the generated source report saved for {arguments['pack']} and confirm the source "
                           "mappings on the Flow page when the product reaches stage 3, then run Check again."))
    elif record["route"] == "source_mapping":
        if record["state"] == "unfinished_draft":
            st.info("Continue the saved choices in the role editor below, then stage a diff and run validation.")
            return None
        st.code(payload["diff"] or "No change to the saved adapter.", language="diff")
        validation = payload["validation"]
        incomplete = validation.get("incomplete") or []
        if incomplete:
            st.warning(f"{len(incomplete)} role(s) have no delivered table in this profile. The diff and the checks below cover the mapped roles; "
                       "this draft cannot be saved until each missing role is mapped or declared unavailable with a decision.")
        for title, issues in (("Roles without a delivered table", incomplete),
                              ("Adapter checks", validation["adapter"]["problems"]),
                              ("Configuration checks", validation["configuration"]),
                              ("Strict build readiness", validation["strict_configuration"])):
            with st.expander(f"{title}: {len(issues)} findings", expanded=bool(issues)):
                if issues:
                    for issue in issues:
                        st.write("• " + str(issue))
                else:
                    st.write("No findings from this check.")
        if record["state"] != "saved_pending_review":
            st.caption("A checked draft keeps every adapter review pending. A disagreement between a table and the delivery configuration must be resolved in that configuration before this draft can be saved.")
            confirmed = st.checkbox("I reviewed this diff and want to save the pending adapter draft.",
                                    key=PREFIX + "apply_confirm_" + record["id"], disabled=not enabled or stale)
            if st.button("Save checked adapter draft", key=PREFIX + "apply_adapter", disabled=not enabled or stale or not confirmed or not validation["passed"]):
                result = backend.apply_adapter(**arguments, record_id=record["id"], confirmed=confirmed)
                if _remember("source_mapping", result):
                    return {"route": "source_mapping", "params": {"id": record["id"]}, "changed": True}
    elif record["route"] == "delivery_drift":
        st.write(payload["statistics"])
        st.dataframe(payload["findings"], hide_index=True, width="stretch")
        st.caption("Next, run the named discriminating checks and review whether mappings and definitions remain suitable for this cut.")
    elif record["route"] == "feasibility":
        st.dataframe(payload["criteria"], hide_index=True, width="stretch")
        if payload.get("synthetic"):
            st.warning("Synthetic exploration only. These counts are not evidence about delivered patient data.")
            st.dataframe(payload["attrition"], hide_index=True, width="stretch")
            st.write(payload["counts"]["rounding"])
        elif record["state"] == "awaiting_runtime":
            st.info("No approved data runtime is connected to this page. The saved request is waiting for execution there.")
            st.write(payload["runtime_action"])
            with st.expander("Identifiers for Engineering"):
                st.json(payload["expected_return"])
                st.caption("The returned file wraps the counts result with this request's id and its criteria digest, using the same ordered criteria without extra filters or grouping.")
            _ask(arguments, action_id="feasibility_counts_" + record["id"][:8], label="Run the feasibility counts", owner="Engineering",
                 note=(f"Please run the approved counts tool for {arguments['pack']} against the permitted frame named in this request, "
                       "with its criteria in order, and place the counts-only result in the restricted evidence folder. "
                       "The request is downloadable from the feasibility page."), key="source_ws_counts")
            if not folder["ok"]:
                _folder_handoff(arguments, folder["reason"], key="source_ws_folder")
            else:
                result_path = _evidence_picker(arguments, "Counts-only result", PREFIX + "counts_return", kind="counts", record_id=record["id"])
                with st.form(PREFIX + "counts_intake"):
                    submit = st.form_submit_button("Check returned counts binding", disabled=not enabled or stale)
                if submit and _remember("feasibility", backend.receive_counts(**arguments, record_id=record["id"], result_name=result_path)):
                    st.rerun()
        elif payload.get("returned_counts"):
            st.dataframe(payload["returned_counts"]["attrition"], hide_index=True, width="stretch")
            st.warning("File identity and filter checks do not authenticate runtime execution or establish scientific validity. The result remains exploration for review.")
    return None


def _mapping(arguments, read_arguments, enabled, folder):
    st.write("Review which delivered tables and columns could supply the product's logical source roles.")
    st.caption("Suggestions retain ties and missing-column blockers. You choose the mapping; the existing adapter and configuration validators check the staged draft.")
    if not folder["ok"]:
        _folder_handoff(arguments, folder["reason"], key="source_ws_folder")
        return
    profile = _evidence_picker(arguments, "Full profile for this delivery", PREFIX + "mapping_profile")
    with st.form(PREFIX + "mapping_load"):
        load = st.form_submit_button("Load table and column suggestions", disabled=not enabled)
    if load:
        result = backend.mapping_options(**read_arguments, profile_name=profile)
        if not _errors(result):
            st.session_state[PREFIX + "mapping_options"] = result
            document = copy.deepcopy(result["document"])
            document["schema"], document["cut"] = result["identity"]["schema"], result["identity"]["cut"]
            # A revised mapping cannot inherit a prior review of different bytes.
            for entry in document["adapters"]:
                entry["review"] = {"status": "pending", "approved_by": "TODO", "approval_date": "TODO", "approved_digest": "TODO"}
            st.session_state[PREFIX + "mapping_document"] = document
            st.session_state[PREFIX + "loaded_profile"] = profile
            for key in list(st.session_state):
                if key.startswith(PREFIX + "role_") or key == PREFIX + "dataset":
                    del st.session_state[key]
    options = st.session_state.get(PREFIX + "mapping_options")
    if not options:
        return
    document = st.session_state[PREFIX + "mapping_document"]
    gaps = options["proposal"]["gaps"]
    words = options.get("gap_words") or [backend.gap_words(gap) for gap in gaps]
    for gap, word in zip(gaps, words):
        with st.expander(word["title"]):
            st.write(word["verdict"])
            st.write("Why: " + word["why"])
            if gap.get("candidates"):
                st.dataframe(gap["candidates"], hide_index=True, width="stretch")
            else:
                st.write("No candidate table in this delivery carries evidence for this role.")
            if word.get("required_by"):
                st.write("Required by: " + ", ".join(word["required_by"]))
            st.write("Next: " + word["next_action"])
    if options.get("undeclared_delivered"):
        st.info("Delivered tables nobody declared: " + ", ".join(options["undeclared_delivered"])
                + ". This product does not read them unless a person maps a role to one of them.")
    st.session_state.setdefault(PREFIX + "dataset", str(document.get("dataset") or ""))
    form_binding = (options["inputs_sha256"], options["profile_sha256"])
    dataset = form_help.field(st.text_input, "Dataset label", key=PREFIX + "dataset", binding=form_binding,
                            help="The source dataset's declared name, for example flatiron. This is a draft binding, not a claim that two datasets are comparable.")
    entries = document["adapters"]
    role = st.selectbox("Logical role to work on", [entry["logical_role"] for entry in entries], key=PREFIX + "role_picker")
    current = next(entry for entry in entries if entry["logical_role"] == role)
    role_key = PREFIX + "role_" + role + "_"
    tables = list(options["tables"])
    existing = next((table for table in tables if options["physical_tables"][table] == current.get("physical_table")), None)
    table = form_help.field(st.selectbox, "Delivered table", tables, index=tables.index(existing) if existing in tables else None, binding=form_binding,
                         key=role_key + "table", help="Select one actual table. A tied candidate is unresolved until you choose and review the mapping.")
    if table:
        suggestions = backend.column_options(**read_arguments, profile_name=st.session_state[PREFIX + "loaded_profile"], role=role, table=table)
        if not _errors(suggestions):
            with st.expander("Column suggestions and unresolved ties", expanded=True):
                for logical, suggestion in suggestions["columns"].items():
                    st.write(logical + (": tied candidates; choose one explicitly" if suggestion["tie"] else ": " + (suggestion["proposed"] or "No candidate")))
                    st.dataframe(suggestion["candidates"], hide_index=True, width="stretch")
        with st.form(role_key + "form"):
            st.caption("The physical table name comes from the profile: " + options["physical_tables"][table])
            columns = options["tables"][table]
            names = [row["column"] for row in columns]
            bindings = {}
            for logical, value in (current.get("required_columns") or {}).items():
                value = value or {}
                column = form_help.field(st.selectbox, f"{logical}: delivered column", names, binding=form_binding,
                                      index=names.index(value["physical"]) if value.get("physical") in names else None,
                                      key=role_key + logical + "_physical", help="Choose the observed column that supplies this logical input. Similar spelling does not establish meaning.")
                logical_types = list(backend.adapters.LOGICAL_TYPES)
                kind = form_help.field(st.selectbox, f"{logical}: logical type", logical_types, binding=form_binding,
                                    index=logical_types.index(value["logical_type"]) if value.get("logical_type") in logical_types else None,
                                    key=role_key + logical + "_type", help="The type consumed by the engine. Example: date for a parsed assessment date; string for a category.")
                parsers = ["No parser"] + sorted(backend.adapters.PARSERS)
                parser = form_help.field(st.selectbox, f"{logical}: parser", parsers, binding=form_binding,
                                      index=parsers.index(value["parser"]) if value.get("parser") in parsers else 0,
                                      key=role_key + logical + "_parser", help="Dates/timestamps need the parser for the delivered format. A type cast alone cannot interpret arbitrary date strings.")
                accepted = form_help.field(st.text_input, f"{logical}: accepted physical types", ", ".join(value.get("accepted_physical_types") or []), binding=form_binding,
                                          key=role_key + logical + "_accepted", help="Comma-separated type names verified for this delivery, for example string or date. The observed profile type is shown above; accepted types are your explicit choice.")
                bindings[logical] = {"physical": column or "TODO", "logical_type": kind or "TODO",
                                     "parser": None if parser == "No parser" else parser,
                                     "accepted_physical_types": [item.strip() for item in accepted.split(",") if item.strip()]}
            grain = form_help.field(st.text_input, "Declared source grain keys", ", ".join(current.get("grain") or []), key=role_key + "grain", binding=form_binding,
                                  help="Comma-separated logical keys defining one source record, for example patientid, assessmentdate. Must agree with source_grain when already declared.")
            join = current.get("join") or {}
            join_to = form_help.field(st.text_input, "Join target", str(join.get("to") or ""), key=role_key + "join_to", binding=form_binding, help="The declared target this role joins to, for example index.")
            keys = form_help.field(st.text_input, "Join keys", ", ".join(join.get("keys") or []), key=role_key + "join_keys", binding=form_binding, help="Comma-separated logical join keys, for example patientid. Their cardinality needs data review.")
            cards = list(backend.adapters.CARDINALITIES)
            cardinality = form_help.field(st.selectbox, "Join cardinality", cards, index=cards.index(join["cardinality"]) if join.get("cardinality") in cards else None, binding=form_binding,
                                       key=role_key + "cardinality", help="Choose one_to_one or many_to_one from the intended join. A selection is a draft assertion, not a measured QC result.")
            keep = st.form_submit_button("Keep these role choices", disabled=not enabled)
        if keep:
            current.update({"physical_table": options["physical_tables"][table], "required_columns": bindings,
                            "grain": [item.strip() for item in grain.split(",") if item.strip()],
                            "join": {"to": join_to, "keys": [item.strip() for item in keys.split(",") if item.strip()], "cardinality": cardinality or "TODO"}})
            st.success("Role choices kept in this editing session. Complete the remaining roles, then validate the proposal below.")
    document["dataset"] = dataset
    with st.expander("All current role choices"):
        st.json(document)
    if st.button("Save unfinished mapping choices", key=PREFIX + "save_mapping_draft", disabled=not enabled):
        result = backend.save_mapping_draft(**arguments, profile_name=st.session_state[PREFIX + "loaded_profile"], document=document,
                                            inputs_sha256=options["inputs_sha256"], profile_sha256=options["profile_sha256"])
        if _remember("source_mapping", result):
            st.rerun()
    if st.button("Stage adapter diff and run validators", key=PREFIX + "stage_adapter", disabled=not enabled):
        result = backend.stage_adapter(**arguments, profile_name=st.session_state[PREFIX + "loaded_profile"], document=document,
                                       inputs_sha256=options["inputs_sha256"], profile_sha256=options["profile_sha256"])
        if _remember("source_mapping", result):
            st.rerun()


def _request_controls(description, arguments, enabled):
    identity = description["identity"]
    member = st.selectbox("Delivery member", identity["members"], index=None, key=PREFIX + "request_member",
                          help="A union requires a separate report for every declared member schema.") if identity["members"] else None
    if st.button("Save source evidence request", key=PREFIX + "create_request", disabled=not enabled or bool(description["blockers"])):
        if _remember("source_evidence", backend.create_request(**arguments, member=member)):
            st.rerun()


def render(root, pack, actor_id, *, allowed_packs=None, local_demo=False, can_write=False,
           can_review=False, route="source_requirements", params=None, can_agent=False):
    """Returns a router destination only after explicit navigation or canonical save."""
    context = (str(root), pack, actor_id, tuple(sorted([pack] if allowed_packs is None else allowed_packs)), local_demo, can_write, can_review, can_agent)
    if st.session_state.get(PREFIX + "context") != context:
        for key in list(st.session_state):
            if key.startswith(PREFIX):
                del st.session_state[key]
        st.session_state[PREFIX + "context"] = context
    if route not in backend.ROUTES:
        st.error("Choose a supported source workspace.")
        return None
    read_arguments = dict(root=root, pack=pack, actor_id=actor_id, allowed_packs=allowed_packs)
    arguments = read_arguments | dict(local_demo=local_demo, can_write=can_write)
    if route == "source_delivery":
        import delivery_binding_page
        return delivery_binding_page.render(**arguments, params=params)
    warning = st.session_state.pop(PREFIX + "warning", None)
    if warning:
        st.warning(warning)
    description = backend.describe(**read_arguments)
    if _errors(description):
        return None
    enabled = local_demo is True and can_write is True
    # checked once per render: when the restricted evidence folder is absent, every intake form
    # becomes a handoff to the data expert instead of a form that can only refuse
    folder = backend.restricted_folder(root)
    notice = st.session_state.pop(PREFIX + "notice", None)
    if notice:
        st.success(notice)
    st.caption(backend.NOTICE)
    if not enabled:
        st.info("This identity can inspect this workspace. Saving requests or drafts requires local editing access.")
    assistance = {"active": False, "navigation": None}
    if route in {"source_requirements", "source_evidence", "source_mapping"}:
        import source_assistance_page
        assistance = source_assistance_page.render(root, pack, actor_id, allowed_packs=allowed_packs,
            local_demo=local_demo, can_write=can_write, can_agent=can_agent, route=route, params=params)
        if assistance["navigation"]:
            return assistance["navigation"]
    with (st.expander("Review source details and complete this step", expanded=bool((params or {}).get("show_details")))
          if assistance["active"] else nullcontext()):
        params = params or {}
        parameter_id = params.get("id") or params.get("request_id") or params.get("proposal_id")
        parameter_key = PREFIX + route + "_parameter_id"
        if parameter_id and st.session_state.get(parameter_key) != parameter_id:
            st.session_state[parameter_key] = parameter_id
            st.session_state[PREFIX + route + "_id"] = parameter_id
        selected_id = st.session_state.get(PREFIX + route + "_id")
        if selected_id:
            saved = backend.read(**read_arguments, record_id=selected_id)
            if not _errors(saved) and saved["record"]["route"] == route:
                if route == "source_mapping" and not saved["stale"] and st.session_state.get(PREFIX + "resumed_id") != selected_id:
                    payload = saved["record"]["payload"]
                    options = backend.mapping_options(**read_arguments, profile_name=payload["profile_path"])
                    if not _errors(options) and options["profile_sha256"] == payload["profile_sha256"]:
                        for key in list(st.session_state):
                            if key.startswith(PREFIX + "role_"):
                                del st.session_state[key]
                        st.session_state[PREFIX + "mapping_options"] = options
                        st.session_state[PREFIX + "mapping_document"] = copy.deepcopy(payload["document"])
                        st.session_state[PREFIX + "loaded_profile"] = payload["profile_path"]
                        st.session_state[PREFIX + "resumed_id"] = selected_id
                if route == "feasibility" and st.session_state.get(PREFIX + "resumed_counts_id") != selected_id:
                    st.session_state[PREFIX + "criteria"] = copy.deepcopy(saved["record"]["payload"].get("criteria", []))
                    st.session_state[PREFIX + "resumed_counts_id"] = selected_id
                changed = _show_record(saved["record"], saved["stale"], enabled, arguments, folder)
                if changed:
                    return changed
                if route == "source_evidence" and not saved["stale"]:
                    with st.expander("Prepare another evidence request"):
                        st.caption(description.get("delivery_sentence") or backend.delivery_sentence(description["identity"]))
                        st.write("Use a separate request for another union member or an intentional rerun of this delivery.")
                        for blocker in description["blockers"]:
                            st.warning(blocker)
                        _request_controls(description, arguments, enabled)
                    return None
            st.divider()
        if route == "source_requirements":
            if (params.get("legacy_input_digest") and
                    not description["inputs_sha256"].startswith(str(params["legacy_input_digest"]))):
                st.warning("The source declarations changed after the engineering request. Compare the current contract and profile again before migrating them.")
            st.write("Each row shows a source role, the columns the engine reads, and the scientific records that depend on it.")
            if not description["contract_present"] or not any(row["required_by_variables"] for row in description["rows"]):
                st.info("No consumer links are declared in the current contract. Empty consumer cells do not establish that these sources have no scientific impact.")
            if description.get("undeclared_stems"):
                st.info("The delivery tables are not declared yet for " + ", ".join(description["undeclared_stems"])
                        + "; the data expert uses Declare the source delivery.")
            role = st.selectbox("Source role", ["All roles"] + [row["role"] for row in description["rows"]], key=PREFIX + "requirements_role",
                                help="Choose a role to see its required columns and exactly which configuration blocks and variable definitions consume it.")
            rows = backend.display_rows([row for row in description["rows"] if role == "All roles" or row["role"] == role])
            st.dataframe(rows, hide_index=True, width="stretch")
            for finding in description["findings"]:
                st.warning(finding)
            _legacy_review(arguments)
            if st.button("Declare the source delivery", key=PREFIX + "go_delivery"):
                return {"route": "source_delivery", "params": {}}
            if st.button("Prepare this delivery's evidence", key=PREFIX + "go_evidence"):
                return {"route": "source_evidence", "params": {}}
            if st.button("Review a build's six-layer data report", key=PREFIX + "go_eda"):
                return {"route": "eda_review"}
        elif route == "source_evidence":
            st.write("Prepare one evidence request per delivery or union member, then receive the machine-generated files here.")
            st.write(description.get("delivery_sentence") or backend.delivery_sentence(description["identity"]))
            st.write("Declared evidence route: " + str(description["evidence_route"] or "Not declared"))
            with st.expander("Identifiers and digests"):
                st.json(description["identity"])
            for blocker in description["blockers"]:
                st.warning(blocker)
            if description["blockers"]:
                st.write("Saving an evidence request needs the delivery declared. Use Declare the source delivery to enter the schema, cut and existing roles' table stems, inspect their impact and save a checked draft.")
                reason = description.get("handoff_note") or "Declare the delivery schema, cut and table stems before a source evidence request."
                if enabled and st.button("Declare the source delivery", key=PREFIX + "go_delivery"):
                    return {"route": "source_delivery", "params": {}}
                _ask(arguments, action_id="source_delivery_declaration", label="Declare the delivery", owner="Data expert",
                     note=reason, key="source_ws_delivery")
            with st.expander("What must the approved environment return?", expanded=True):
                st.write("1. The full profile of the delivery, stamped with this product, its schema, cut, source mode and profile mode.")
                st.write("2. The live schema check result, bound to the same delivery configuration digest.")
                st.write("3. The source quality check result, covering targeted grain, joins, duplicates and timing checks.")
                st.write("Next, the data expert reviews the findings. A received file or a passed schema check alone does not complete source review.")
            _request_controls(description, arguments, enabled)
        elif route == "source_mapping":
            _mapping(arguments, read_arguments, enabled, folder)
        elif route == "delivery_drift":
            st.write("Compare two complete profiles for the same product and source member. The newer profile must match the current delivery cut.")
            if not folder["ok"]:
                _folder_handoff(arguments, folder["reason"], key="source_ws_folder")
                return None
            new = _evidence_picker(arguments, "Current profile", PREFIX + "new_profile")
            old = _evidence_picker(arguments, "Previous profile", PREFIX + "old_profile", previous=True, peer_name=new or None)
            with st.form(PREFIX + "drift"):
                compare = st.form_submit_button("Compare deliveries and save findings", disabled=not enabled)
            if compare and _remember(route, backend.compare_profiles(**arguments, old_name=old, new_name=new)):
                st.rerun()
        elif route == "feasibility":
            st.write("Specify the criteria first, then rehearse their attrition with synthetic counts or request execution against an approved frame.")
            options = backend.feasibility_options(**read_arguments)
            if _errors(options):
                return None
            names = [entry["name"] for entry in options["variables"]]
            excluded = options.get("excluded") or []
            if excluded:
                st.caption("Not offered as criteria because they are not categories: " + ", ".join(entry["name"] for entry in excluded)
                           + ". A survival time, an age or a date is counted through a scientific definition, not an equality filter.")
            if not names:
                st.info("This product has no declared category variables yet. Write the scientific definitions and choose their output names before counting a cohort.")
                return None
            if params.get("variable") in names and st.session_state.get(PREFIX + "parameter_variable") != params["variable"]:
                st.session_state[PREFIX + "criterion_variable"] = params["variable"]
                st.session_state[PREFIX + "parameter_variable"] = params["variable"]
            criteria = st.session_state.setdefault(PREFIX + "criteria", [])
            with st.form(PREFIX + "criterion"):
                variable = form_help.field(st.selectbox, "Criterion variable", names, key=PREFIX + "criterion_variable", binding=options, help="Only category variables declared for this product are offered. Identifiers, dates and measurements are excluded.")
                operator = form_help.field(st.selectbox, "Comparison", ["=", "!="], key=PREFIX + "criterion_operator", binding=options, help="Equality or inequality on one defined category. Timing windows and complex derivations require a scientific definition first.")
                value = form_help.field(st.text_input, "Category value", key=PREFIX + "criterion_value", binding=options, help="For the synthetic rehearsal use v1, v2 or v3. For a runtime request use the actual reviewed category; never an identifier or pasted data row.")
                add = st.form_submit_button("Add criterion", disabled=not enabled)
            if add:
                criterion = {"variable": variable, "operator": operator, "value": value}
                # the same rule the run applies, asked before the criterion joins the list
                problem = backend.criterion_problem(criterion, set(names))
                if problem:
                    st.error(problem)
                else:
                    criteria.append(criterion)
            st.dataframe(criteria, hide_index=True, width="stretch")
            if st.button("Clear criteria", key=PREFIX + "clear_criteria", disabled=not enabled):
                st.session_state[PREFIX + "criteria"] = []
                st.rerun()
            mode = st.radio("Execution", ["Synthetic rehearsal", "Approved data-runtime request"], key=PREFIX + "feasibility_mode")
            frame_sha, grain, count = "", "patient", 60
            if mode == "Synthetic rehearsal":
                count = int(st.number_input("Synthetic rows", min_value=11, max_value=10000, value=60, key=PREFIX + "synthetic_rows",
                                            help="Generated rows only, cycling through v1/v2/v3. The existing counts floor and rounding still apply."))
            else:
                frame_sha = st.text_input("Approved frame digest", key=PREFIX + "frame_sha", help="The exact 64-character digest the approved environment reported for the permitted frame. The returned count must name these same bytes.")
                grain = st.selectbox("Frame grain", ["patient", "event"], key=PREFIX + "grain", help="What one input row represents. The runtime must validate patient identity and repeated-event grain before counting.")
            label = "Run synthetic counts" if mode == "Synthetic rehearsal" else "Save feasibility runtime request"
            if st.button(label, key=PREFIX + "run_feasibility", disabled=not enabled or not criteria):
                result = backend.run_feasibility(**arguments, criteria=criteria, synthetic_rows=count,
                                                 mode="synthetic" if mode == "Synthetic rehearsal" else "runtime", frame_sha256=frame_sha, grain=grain)
                if _remember(route, result):
                    st.rerun()
        return None


def source_chat_context(root, pack, actor_id, *, allowed_packs, route):
    """Canonical, access-reviewed declaration context for the common chat."""
    from source_assistance_page import context_for
    return context_for(root, pack, actor_id, allowed_packs=allowed_packs, route=route)
