"""Explicit treatment-line variants of one reusable scientific definition.

Name matching only suggests a family. Nothing here reads or writes a product,
changes engine configuration, or treats a suggested name as a reviewed rule.
"""
from __future__ import annotations

from copy import deepcopy
import re

NAME = "treatment_line"
ATTRIBUTES = {
    "Regimen": "regimen",
    "Start date": "start_date",
    "Delivered end date": "delivered_end_date",
    "Last activity date": "last_activity_date",
    "Associated diagnosis": "diagnosis",
    "Other attribute — describe it": "custom",
}
NUMBERING = {
    "Keep the delivered line numbers": "linenumber",
    "Renumber the eligible lines in date order": "new_lot_n",
}
TYPES = {"regimen": "string", "start_date": "date", "delivered_end_date": "date",
         "last_activity_date": "date", "diagnosis": "string"}
TEXT_FIELDS = {"diagnosis_relationship", "diagnosis_window", "diagnosis_tie_break", "custom_attribute"}
FIELDS = {"name", "line_number", "attribute", "numbering", *TEXT_FIELDS}
MAX_LINE_NUMBER = 2**53 - 1  # Largest integer the browser's numeric input preserves exactly.
SOURCE_ROLES = ("patientid", "linenumber", "startdate", "enddate", "linename")
_NAME = re.compile(r"^LOT[_ -]?([1-9][0-9]*)(SD|DATE|LD|ED|DIAG|DIAGNOSIS)?$", re.I)


def _answered(value):
    return isinstance(value, str) and value.strip().casefold() not in {
        "", "todo", "tbd", "replace_me", "undecided", "none", "not sure", "n/a", "null"}


def selection(row):
    """Saved metadata is kept outside canonical definition values by the caller."""
    return deepcopy(row.get("family") or (row.get("values") or {}).get("family") or {})


def suggestions(row):
    """Return name evidence only: ambiguous DATE intentionally has no attribute."""
    name = str(row.get("variable_id") or row.get("name") or "").strip()
    found = _NAME.fullmatch(name)
    if not found:
        return {}
    suffix = (found.group(2) or "").upper()
    attributes = {"": "regimen", "SD": "start_date", "LD": "delivered_end_date",
                  "ED": "last_activity_date", "DIAG": "diagnosis", "DIAGNOSIS": "diagnosis"}
    return {"line_number": int(found.group(1)), "attribute": attributes.get(suffix, "")}


def matches(row, candidate=None):
    if selection(row).get("name") == NAME:
        return True
    if isinstance(candidate, str):
        master = candidate
    elif isinstance(candidate, dict):
        master = candidate.get("name") or candidate.get("master_name") or candidate.get("variable_id")
    else:
        master = row.get("master_name")
    return str(master or "").upper() == "LINE_OF_THERAPY" or bool(suggestions(row))


def validate(value):
    """Validate structure, allowing an unfinished draft or explicit empty family."""
    if not isinstance(value, dict) or set(value) - FIELDS:
        raise ValueError("The treatment-line choices contain an unsupported field.")
    if not value:
        return {}
    if value.get("name") != NAME:
        raise ValueError("Choose the treatment-line family.")
    line = value.get("line_number")
    if line is not None and (type(line) is not int or not 1 <= line <= MAX_LINE_NUMBER):
        raise ValueError("The treatment line number must be a positive whole number that the browser can represent exactly.")
    if not isinstance(value.get("attribute", ""), str) or value.get("attribute", "") not in {"", *ATTRIBUTES.values()}:
        raise ValueError("Choose a treatment-line attribute, or choose Other attribute.")
    if not isinstance(value.get("numbering", ""), str) or value.get("numbering", "") not in {"", *NUMBERING.values()}:
        raise ValueError("Choose how the treatment lines are numbered.")
    if any(not isinstance(value.get(field, ""), str) for field in TEXT_FIELDS):
        raise ValueError("Diagnosis matching and custom attribute answers must be text.")
    for field in TEXT_FIELDS:
        text = value.get(field, "")
        if len(text) > 12000:
            raise ValueError("A treatment-line answer exceeds the 12000-character text limit.")
        if any((ord(char) < 32 and char not in "\n\r\t") or 127 <= ord(char) <= 159 for char in text):
            raise ValueError("A treatment-line answer contains an unsupported control character.")
    return deepcopy(value)


def _missing(value):
    result = []
    if value.get("line_number") is None:
        result.append("Choose the treatment line number.")
    if not value.get("attribute"):
        result.append("Choose the treatment-line attribute; a date name alone does not identify which date.")
    if not value.get("numbering"):
        result.append("Choose whether to keep delivered line numbers or renumber eligible lines.")
    if value.get("attribute") == "diagnosis":
        for field, issue in {
            "diagnosis_relationship": "Choose how a diagnosis is linked to the treatment line.",
            "diagnosis_window": "Choose the eligible diagnosis window around the treatment line.",
            "diagnosis_tie_break": "Choose which diagnosis to use when several records match.",
        }.items():
            if not _answered(value.get(field)):
                result.append(issue)
    if value.get("attribute") == "custom" and not _answered(value.get("custom_attribute")):
        result.append("Describe the treatment-line attribute to return.")
    return result


def issues(row):
    """Unconfigured legacy rows keep their existing review behavior."""
    value = selection(row)
    if not value:
        return []
    try:
        validate(value)
    except ValueError as error:
        return [str(error)]
    result = _missing(value)
    expected = TYPES.get(value.get("attribute"))
    actual = ((row.get("values") or {}).get("output") or {}).get("type")
    if expected and actual not in (None, "", "TODO", expected):
        result.append(f"The selected treatment-line attribute needs data type {expected}; the row currently uses {actual}.")
    return result


def capability(value):
    if value.get("attribute") in {"diagnosis", "custom"}:
        return "This attribute needs an implementation handoff after its definition and source mapping are reviewed."
    if value.get("attribute") in TYPES:
        return "The existing engine supports this attribute. Its source mapping and product configuration still need review."
    return "Choose an attribute to see its engine support."


def source_roles(row):
    """Common LOT roles required by normalization and per-line row selection.

    Both numbering models use the shared LOT columns, including dates and
    regimen for tie-breaking. Map these once for all standard line variants.
    Config-dependent roles still need the existing engine schema checks.
    Episode dates belong to a separately declared linked input.
    """
    value = selection(row)
    try:
        validate(value)
    except ValueError:
        return []
    if not value or _missing(value) or value.get("attribute") not in {
        "regimen", "start_date", "delivered_end_date", "last_activity_date"}:
        return []
    return list(SOURCE_ROLES)


def source_issues(row):
    """Keep a selected family incomplete until its distinct source roles are mapped."""
    roles = source_roles(row)
    values = row.get("values") or {}
    source = values.get("source") or {}
    if not roles or source.get("kind") != "vendor":
        return []
    columns = source.get("columns") or {}
    if not isinstance(columns, dict):
        columns = {}
    result = [f"Map treatment-line source role '{role}' to its source column."
              for role in roles if not _answered(columns.get(role))]
    from source_check import logical_parts
    if logical_parts(str(source.get("logical_table") or "")) != ["lot"]:
        result.append("Choose source alias 'lot' for this treatment-line definition. The engine reads that alias; "
                      "set its delivered table or adapter mapping in Configuration.")
    if selection(row).get("attribute") == "last_activity_date":
        inputs = source.get("inputs")
        episode = inputs.get("drug_episode") if isinstance(inputs, dict) else None
        episode = episode if isinstance(episode, dict) else {}
        missing = [role for role in ("patientid", "linenumber", "episodedate")
                   if not _answered(episode.get(role))]
        if missing:
            result.append("Map the linked drug-episode source input 'drug_episode', including " +
                          ", ".join(missing) + ". The delivered end date is only the fallback. "
                          "If this value is calculated from a defined variable, choose Calculated from other variables and select its Dependencies.")
    return result


def scientific_updates(value):
    """Build selected logic without copying product values, windows, or output codes."""
    value = validate(value)
    updates = {"family": value}
    if not value:
        return updates
    attribute = value.get("attribute")
    if attribute in TYPES:
        updates["output.type"] = TYPES[attribute]
    if _missing(value):
        return updates
    line = value["line_number"]
    numbering = ("the delivered line number" if value["numbering"] == "linenumber" else
                 "the chronological line number assigned after applying the product's eligible-line filters")
    choose = f"Select treatment line {line} using {numbering} within each patient's cohort."
    result = {
        "regimen": "Return the selected line's regimen name.",
        "start_date": "Return the selected line's start date.",
        "delivered_end_date": "Return the selected line's delivered end date.",
        "last_activity_date": "Return the latest drug-episode date linked to the selected line within the cohort setting; use the delivered line end date when no linked episode date is available.",
        "diagnosis": (f"Return the associated diagnosis. Relationship: {value.get('diagnosis_relationship', '')}. "
                      f"Eligible window: {value.get('diagnosis_window', '')}. "
                      f"When several diagnoses match: {value.get('diagnosis_tie_break', '')}."),
        "custom": f"Return this attribute of the selected line: {value.get('custom_attribute', '')}.",
    }[attribute]
    updates.update({"derivation": choose + " " + result,
                    "record_selection": choose,
                    "grain": "One value per patient within each cohort"})
    if attribute not in {"diagnosis", "custom"}:
        updates["source.kind"] = "vendor"
    if attribute == "diagnosis":
        updates["tie_break"] = value["diagnosis_tie_break"]
    return updates
