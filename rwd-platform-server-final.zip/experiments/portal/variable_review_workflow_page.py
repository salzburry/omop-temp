"""One product-wide review at a time, with edits owned by each review role."""
from __future__ import annotations

from copy import deepcopy
import hashlib
import json

import streamlit as st

import variable_review_workflow as workflow
import definition_reuse_logic as reuse_logic
import variable_review_controls as controls
import variable_review_consistency as consistency
import variable_review_requirements as requirements


PREFIX = "variable_review_"
PHASES = ("science", "source", "output")
LABELS = {"science": "Scientific review", "source": "Source mapping", "output": "Output review"}
ROLES = {"science": "Scientific reviewer", "source": "Data expert", "output": "Output owner"}
SOURCE_KINDS = {"": "Choose a source", "vendor": "Delivered data column",
                "derived": "Calculated from other variables", "parameter": "Product setting",
                "constant": "Fixed value", "unavailable": "Unavailable",
                "pending_mapping": "Source mapping still needed"}
PUBLISH = ("undecided", "proposed", "required", "configured", "excluded")
READ_CACHE = "_variable_review_run_reports"


def begin_run():
    """Called once by the app before chat and the page share this run's read."""
    st.session_state[READ_CACHE] = {}


def _describe(root, pack, actor_id, allowed_packs):
    cache = st.session_state.get(READ_CACHE)
    if cache is None:
        return workflow.describe(root, pack, actor_id, allowed_packs=allowed_packs)
    key = _digest([str(root), pack, actor_id, allowed_packs])
    if key not in cache:
        cache[key] = workflow.describe(root, pack, actor_id, allowed_packs=allowed_packs)
    return cache[key]


def _digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, default=str).encode()).hexdigest()[:16]


def _get(values, path, default=""):
    value = values
    for part in path.split("."):
        if not isinstance(value, dict):
            return default
        value = value.get(part, default)
    return default if value is None else value


def _text(value):
    if value is None:
        return ""
    if isinstance(value, dict):
        return "\n".join(f"{key} = {_text(item)}" for key, item in value.items())
    if isinstance(value, (list, tuple)):
        return "\n".join(_text(item) for item in value)
    return str(value)


def _blank_placeholder(value):
    text = _text(value)
    return "" if text.strip() in {"TODO", "REPLACE_ME"} else text


def _lines(value):
    return list(dict.fromkeys(line.strip() for line in value.splitlines() if line.strip()))


def _spec_values(value):
    if not isinstance(value, dict):
        return _text(value)
    return _text({key: item for key, item in value.items()
                  if str(key).strip().lower().replace("_", " ") in
                  {"value", "values", "codes", "allowed values", "time period"}
                  and item not in (None, "")})


def _issue_text(issue):
    if isinstance(issue, dict) and "message" in issue:
        return (str(issue["variable_id"]) + ": " if issue.get("variable_id") else "") + str(issue["message"])
    return _text(issue)


def _changed_updates(row, updates):
    changed = {}
    for path, value in updates.items():
        original = row.get(path, "") if path in workflow.META_FIELDS else _get(row.get("values") or {}, path)
        if value != original and _blank_placeholder(value) != _blank_placeholder(original):
            changed[path] = value
    # A changed master is reviewed with the displayed interpretation. The backend
    # must not replace that interpretation with an unseen master default.
    if "master_name" in changed:
        changed["derivation"] = updates.get("derivation", _get(row.get("values") or {}, "derivation"))
    if row.get("status") in {"ambiguous", "unmapped"} and "master_name" in updates:
        changed["master_name"] = updates["master_name"]
        changed["derivation"] = updates.get("derivation", _get(row.get("values") or {}, "derivation"))
    return changed


def _columns(value):
    result = {}
    for number, line in enumerate(value.splitlines(), 1):
        if not line.strip():
            continue
        role, separator, column = line.partition("=")
        role, column = role.strip(), column.strip()
        if not separator or not role or not column:
            raise ValueError(f"Source columns, line {number}: enter role = column.")
        if role in result:
            raise ValueError(f"Source columns, line {number}: '{role}' is repeated. Use one column per role.")
        result[role] = column
    return result


def _errors(result):
    errors = result.get("errors") or result.get("issues") or [result.get("message") or "The change could not be saved. Review the details and try again."]
    if isinstance(errors, str):
        errors = [errors]
    for error in errors:
        st.error(_text(error))


def _missing_scientific_answers(values, updates=None):
    updates = updates or {}
    return [label for path, label in (("derivation", "definition / logic / formula"), ("output.type", "data type"))
            if not workflow._answered(updates.get(path, _get(values, path)))]


def _saved_row_notice(report, selection):
    """Explain completion from the fresh dashboard, rather than the write result."""
    phase = selection.get("phase")
    saved = next((row for row in report.get("rows") or [] if row["item_id"] == selection.get("item_id")), None)
    if not saved or phase not in PHASES:
        st.info("Your changes were saved. Reload the table to check what remains.")
        return
    name = saved["variable_id"]
    if saved.get("phase_status", {}).get(phase) == "ready":
        st.success(f"{name} resolved for {LABELS[phase].lower()}. The dashboard is updated.")
        return
    missing = _missing_scientific_answers(saved.get("values") or {}) if phase == "science" else []
    details = ", ".join(missing) if missing else "; ".join(
        _issue_text(issue).rstrip(".") for issue in (saved.get("phase_issues") or {}).get(phase) or [])
    st.warning(f"{name} saved as an unfinished draft. " +
               ("Still needed: " + details + ". " if details else "") +
               "It stays in the attention list until these answers are complete.")


def _status(row, phase):
    if row.get("phase_status", {}).get(phase) == "ready":
        return "Ready for review"
    if phase == "science" and any("specification" in message.lower() for message in consistency.issues(row)):
        return "Data type conflicts with Excel"
    if phase == "science" and row.get("family"):
        import variable_review_family
        issues = variable_review_family.issues(row)
        if issues:
            return issues[0] if len(issues[0]) <= 80 else issues[0][:77] + "..."
    if phase == "science" and row.get("master_name") and not row.get("master_missing"):
        missing = _missing_scientific_answers(row.get("values") or {})
        if len(missing) == 2:
            return "Definition and data type needed"
        if missing == ["definition / logic / formula"]:
            return "Definition / logic needed"
    if phase == "science" and row.get("status") == "unmapped":
        return "Choose a master or custom logic"
    if phase == "science" and row.get("status") == "ambiguous":
        return "Review ambiguous logic"
    issues = (row.get("phase_issues") or {}).get(phase) or []
    if phase == "science" and any("data type" in _issue_text(issue).lower() for issue in issues):
        return "Data type needed"
    if issues:
        issue = _issue_text(issues[0]).rstrip(".")
        return issue if len(issue) <= 80 else issue[:77] + "..."
    return "Needs attention"


def dashboard_rows(rows, phase):
    """A phase's final review includes every variable, including automatic matches."""
    result = []
    for row in rows:
        values = row.get("values") or {}
        item = {"Variable": row.get("variable_id", ""), "Status": _status(row, phase)}
        if phase == "science":
            item.update({"Specification wording": row.get("definition", ""),
                         "Master": row.get("master_name") or _get(values, "master_name") or "Custom / not mapped",
                         "Definition / logic / formula": _get(values, "derivation"),
                         "Data type": _get(values, "output.type"),
                         "Variable kind": SOURCE_KINDS.get(_get(values, "source.kind"), _get(values, "source.kind")),
                         "Product value": _text(_get(values, "source.value")),
                         "Specification values / codes": _spec_values(row.get("spec_values")),
                         "Output codes": _text(_get(values, "output.codes"))})
            if row.get("family"):
                family = row["family"]
                item.update({"Treatment line": family.get("line_number"),
                             "Line attribute": family.get("attribute", "").replace("_", " "),
                             "Line numbering": family.get("numbering", "")})
        elif phase == "source":
            item.update({"Source": SOURCE_KINDS.get(_get(values, "source.kind"), _get(values, "source.kind")),
                         "Source alias": _get(values, "source.logical_table"),
                         "Table": _get(values, "source.physical_stem"),
                         "Columns": _text(_get(values, "source.columns")),
                         "Inputs": _text(_get(values, "source.inputs")),
                         "Dependencies": _text(_get(values, "depends_on"))})
        else:
            item.update({"Output column": _get(values, "output.physical_name"),
                         "Published name": _get(values, "output.target_published_name"),
                         "Role": _get(values, "output.role"),
                         "Analysis dataset": _get(values, "publish.ads"),
                         "Data dictionary": _get(values, "publish.dictionary"),
                         "Dashboard": _get(values, "publish.dashboard"),
                         "Tables, figures and listings": _get(values, "publish.tfl")})
        result.append(item)
    return result


def _input(label, values, path, key, *, multiline=False, disabled=False, options=None):
    choices = controls.choices_for(path) if options is None else options
    if choices or options is not None:
        if not isinstance(choices, dict):
            choices = {str(value): value for value in choices}
        current = _get(values, path)
        if isinstance(current, str) and not _blank_placeholder(current):
            current = ""
        value = controls.render_choice(label, current, choices, key=key + path,
            multiline=multiline, disabled=disabled)
        return "" if value is None else value
    method = st.text_area if multiline else st.text_input
    return method(label, value=_blank_placeholder(_get(values, path)), key=key + path, disabled=disabled)


def _choice(label, values, path, options, key, *, disabled=False, labels=None):
    current = _get(values, path)
    options = list(options)
    if current not in options:
        options.insert(0, current)
    return st.selectbox(label, options, index=options.index(current), key=key + path,
                        format_func=lambda value: (labels or {}).get(value, value or "Choose an answer"),
                        disabled=disabled)


def _science_fields(row, values, key, permitted):
    updates = {
        "derivation": _input("Definition / logic / formula", values, "derivation", key, multiline=True, disabled=not permitted),
        "source.kind": _choice("Variable kind", values, "source.kind", SOURCE_KINDS, key,
                                labels=SOURCE_KINDS, disabled=not permitted),
        "output.type": _input("Data type", values, "output.type", key, disabled=not permitted),
        "source.value": _input("Value for this product", values, "source.value", key, disabled=not permitted),
    }
    st.caption("Keep dates, cutoffs and study-specific values in the product value field. The reusable logic describes how to use them.")
    with st.expander("Scientific details"):
        for path, label in (
            ("grain", "One value per"), ("anchor", "Anchor date or event"),
            ("window", "Eligible time window"), ("record_selection", "Which records qualify"),
            ("tie_break", "Precedence and tie-breaking"), ("cohort_applicability", "Applicable population"),
            ("missing", "Missing / no-record behaviour"), ("units", "Units"),
            ("acceptance", "Example or acceptance criterion"), ("notes", "Review notes"),
            ("output.codes", "Output codes"),
        ):
            updates[path] = _input(label, values, path, key, multiline=True, disabled=not permitted)
        nullable = _get(values, "output.nullable", "")
        nullable_text = "true" if nullable is True else "false" if nullable is False else _text(nullable)
        choice = _choice("Can the result be missing?", {"nullable": nullable_text}, "nullable", ("", "true", "false"), key,
                         labels={"": "Choose an answer", "true": "Yes", "false": "No"}, disabled=not permitted)
        updates["output.nullable"] = {"true": True, "false": False}.get(choice, choice)
    return updates


def _source_fields(values, key, permitted, options=None, row=None):
    options = options or {}
    updates = {"source.kind": _choice("Source kind", values, "source.kind", SOURCE_KINDS, key,
                                      labels=SOURCE_KINDS, disabled=not permitted)}
    st.caption("Changing an already reviewed variable kind reopens the scientific review.")
    kind = updates["source.kind"]
    updates.update({"source.logical_table": deepcopy(_get(values, "source.logical_table")),
        "source.physical_stem": deepcopy(_get(values, "source.physical_stem")),
        "source.columns": deepcopy(_get(values, "source.columns", {})),
        "source.inputs": deepcopy(_get(values, "source.inputs", {})),
        "source.parameters": deepcopy(_get(values, "source.parameters", [])),
        "depends_on": deepcopy(_get(values, "depends_on", [])), "_column_errors": []})
    obsolete = {
        "vendor": ("source.parameters",),
        "derived": ("source.inputs", "source.parameters", "source.physical_stem", "source.columns", "source.logical_table"),
        "constant": ("source.inputs", "source.parameters", "source.physical_stem", "source.columns", "source.logical_table", "depends_on"),
        "unavailable": ("source.inputs", "source.parameters", "source.columns", "source.logical_table", "depends_on"),
        "pending_mapping": ("source.inputs", "source.parameters", "source.columns", "source.logical_table", "depends_on"),
        "parameter": ("source.inputs", "source.columns", "source.logical_table", "depends_on"),
    }.get(kind, ())
    if any(workflow._answered(_get(values, path)) for path in obsolete):
        st.caption("Saving as " + SOURCE_KINDS.get(kind, kind) +
                   " removes the previous source fields that do not apply to this kind.")
    for path in obsolete:
        updates[path] = {} if path in {"source.inputs", "source.columns"} else [] if path in {"source.parameters", "depends_on"} else ""
    current_inputs = _get(values, "source.inputs")
    if kind == "vendor":
        updates["source.logical_table"] = _input("Source alias", values, "source.logical_table", key,
            options=options.get("aliases", []), disabled=not permitted)
        alias = updates["source.logical_table"]
        table_definition = next((table for table in options.get("tables", []) if table.get("alias") == alias), {})
        table_names = table_definition.get("table_stems") or options.get("table_stems", [])
        updates["source.physical_stem"] = _input("Source table name", values, "source.physical_stem", key,
            options=table_names, disabled=not permitted)
        chosen_table = updates["source.physical_stem"]
        known_columns = options.get("columns_by_table", {}).get(chosen_table or alias, [])
        known_roles = (options.get("roles_by_table", {}).get(alias)
                       or options.get("roles_by_table", {}).get(chosen_table)
                       or options.get("column_roles", []))
        if row and row.get("family"):
            import variable_review_family
            needed_roles = variable_review_family.source_roles(row)
            if needed_roles:
                st.caption("This treatment-line variable needs these column roles: " + ", ".join(needed_roles) + ".")
                known_roles = list(dict.fromkeys([*needed_roles, *known_roles]))
        from variable_review_source_controls import render_columns
        updates["source.columns"], updates["_column_errors"] = render_columns(
            _get(values, "source.columns", {}), key=key, roles=known_roles,
            columns=known_columns, disabled=not permitted)
        from variable_review_linked_sources import render as render_linked_sources
        # Inputs takes precedence over the primary mapping in canonical checks.
        # Show linked tables separately, then explicitly include the main table.
        previous_alias = _get(values, "source.logical_table")
        linked = deepcopy(current_inputs)
        if isinstance(linked, dict) and linked.get(previous_alias) == _get(values, "source.columns"):
            linked.pop(previous_alias, None)
        linked, unfinished = render_linked_sources(linked, options, key=key + "linked", permitted=permitted)
        updates["_column_errors"].extend(unfinished)
        if linked:
            if alias in linked and linked[alias] != updates["source.columns"]:
                updates["_column_errors"].append("This input repeats the main source with different columns. Remove it and edit the main mapping above.")
            elif workflow._answered(alias) and updates["source.columns"]:
                linked[alias] = deepcopy(updates["source.columns"])
                st.caption("The main source and its column mappings above are included with these linked inputs.")
            else:
                updates["_column_errors"].append("Complete the main source alias and columns before saving linked sources.")
        updates["source.inputs"] = linked
    elif kind == "parameter":
        updates["source.parameters"] = controls.render_multi("Product settings used", _get(values, "source.parameters"),
            options.get("configured_parameters", options.get("parameters", [])), key=key + "source.parameters", disabled=not permitted)
        st.caption("Use this product's configuration paths. The product value is reviewed in the scientific table.")
    elif kind == "constant":
        st.write("Fixed value for this product: " + (_text(_get(values, "source.value")) or "Not decided"))
        st.caption("Edit the fixed value in the scientific table.")
    elif kind == "derived":
        st.caption("Select the defined variables used by this calculation.")
    elif kind in {"unavailable", "pending_mapping"}:
        if kind == "pending_mapping":
            st.info("This mapping stays unfinished until a source kind and its required fields are resolved.")
        updates["source.physical_stem"] = _input("Source table reference (optional)", values, "source.physical_stem", key,
            options=options.get("table_stems", []), disabled=not permitted)
        reasons = ["Not supplied by this data provider", "Not collected for this population",
                   "Unavailable for the selected data period", "The existing source lacks the required information"] if kind == "unavailable" else [
                   "The source table has not been identified", "The column mapping needs a data expert",
                   "Awaiting delivery metadata", "A new source adapter is required"]
        updates["source.reason"] = _input("Why is this source unavailable?" if kind == "unavailable" else "What needs to be resolved?",
            values, "source.reason", key, options=reasons, multiline=True, disabled=not permitted)
    else:
        st.info("Choose a source kind to see the fields it needs.")
    if kind in {"vendor", "derived"}:
        updates["depends_on"] = controls.render_multi("Dependencies", _get(values, "depends_on"),
            options.get("input_variables", []), key=key + "depends_on", disabled=not permitted)
    with st.expander("Source details"):
        if kind == "parameter":
            updates["source.physical_stem"] = _input("Source table reference (optional)", values, "source.physical_stem", key,
                options=options.get("table_stems", []), disabled=not permitted)
        updates["source.spec_identifiers"] = controls.render_multi("Specification identifiers", _get(values, "source.spec_identifiers"),
            options.get("spec_identifiers", []), key=key + "source.spec_identifiers", disabled=not permitted)
        updates["implementation_refs"] = _input("Implementation references (one per line)", values,
            "implementation_refs", key, multiline=True, disabled=not permitted)
        if kind not in {"unavailable", "pending_mapping"}:
            updates["source.reason"] = _input("Mapping explanation", values, "source.reason", key, multiline=True, disabled=not permitted)
    return updates


def _output_fields(values, key, permitted, options=None):
    options = options or {}
    updates = {}
    for path, label in (("output.physical_name", "Output column name"), ("output.target_published_name", "Published variable name")):
        updates[path] = _input(label, values, path, key, disabled=not permitted,
            options=options.get("output_names" if path == "output.physical_name" else "published_names", []))
    updates["output.role"] = _choice("Output role", values, "output.role", ("", "published", "internal", "metadata", "excluded"), key, disabled=not permitted)
    updates["output.name_status"] = _choice("Naming decision", values, "output.name_status", ("", "undecided", "aligned"), key, disabled=not permitted)
    st.write("**Where should this variable be included?**")
    for path, label in (("publish.ads", "Analysis dataset"), ("publish.dictionary", "Data dictionary"),
                        ("publish.dashboard", "Dashboard"), ("publish.tfl", "Tables, figures and listings")):
        updates[path] = _choice(label, values, path, PUBLISH, key, disabled=not permitted)
    return updates


def _master_fields(row, candidate, comparison, values, key, permitted):
    required_paths = {slot["field"] for slot in requirements.fields(row, candidate) if slot["required"]}
    fields = []
    for original in comparison.get("fields") or []:
        field = dict(original)
        field["has_excel"] = bool(field.get("has_excel") and _blank_placeholder(field.get("excel_value")).strip())
        if not field["has_excel"]:
            field["excel_value"] = None
        field["master_options"] = [option for option in field.get("master_options") or []
                                   if _blank_placeholder(option.get("value")).strip()]
        if not _blank_placeholder(field.get("master_value")).strip():
            field["master_value"] = None
        field["has_master"] = bool(field.get("master_value") is not None or field["master_options"])
        fields.append(field)
    st.dataframe([{"Field": "Name", "Excel": row["variable_id"], "Master": candidate["variable_id"]},
        *[{"Field": "Specification wording (reference)" if field["path"] == "definition" else field["label"], "Excel": _text(field.get("excel_value")) or "Not declared",
           "Master": _text(field.get("master_value")) or " / ".join(_text(option.get("value")) for option in field.get("master_options") or []) or "Not declared"}
          for field in fields if field.get("has_excel") or field.get("has_master") or field.get("master_options")]],
        hide_index=True, width="stretch")
    st.caption("Excel values are kept by default. Choose Master for a field only when that declared value fits this product, or choose Edit.")
    updates, choices = {}, {}
    for field in fields:
        path = field["path"]
        if field.get("editable") is False or path == "definition":
            continue
        current_text = _blank_placeholder(field.get("current_value", _get(values, path))).strip()
        has_value = bool(current_text and current_text.casefold() not in {"n/a", "not applicable"})
        declared = field.get("has_excel") or field.get("has_master") or field.get("master_options")
        product_setting = path == "source.value" and (updates.get("source.kind") or _get(values, "source.kind") or candidate.get("declared_source_kind")) in {"parameter", "constant"}
        if path not in {"derivation", "output.type", "source.kind"} and path not in required_paths and not (declared or has_value or product_setting):
            continue
        label = {"derivation": "Definition / logic / formula", "source.value": "Value for this product", "output.type": "Data type",
                 "source.kind": "Variable kind", "output.codes": "Output codes", "window": "Baseline / eligible window"}.get(path, field["label"])
        options = [*(["excel"] if field.get("has_excel") else []), *(["master"] if field.get("has_master") or field.get("master_options") else []), "edit"]
        saved = (row.get("field_choices") or {}).get(path)
        default = saved or field.get("default_choice") or ("excel" if field.get("has_excel") else "master" if path == "derivation" and "master" in options else "edit")
        if path == "derivation" and not saved and not field.get("has_excel") and candidate["variable_id"] != row.get("master_name") and "master" in options and candidate.get("reuse_readiness") == "ready":
            default = "master"
        if default not in options:
            default = "edit"
        source = st.selectbox("Use for " + label, options, index=options.index(default), key=key + "choose_" + candidate["variable_id"] + "_" + path,
            format_func=lambda choice: {"excel": "Excel", "master": "Master", "edit": "Edit"}[choice], disabled=not permitted)
        choices[path] = source
        if source == "master":
            if path == "derivation" and candidate.get("reuse_readiness") == "needs_edit":
                st.caption("This is the master's recorded wording and needs review. Choose Edit to resolve product-specific values or literals.")
            variants = field.get("master_options") or []
            if variants:
                previous = next((index for index, option in enumerate(variants) if option.get("value") == field.get("current_value")), None) if saved == "master" else None
                option = st.selectbox("Master option for " + label, list(range(len(variants))), index=previous,
                    key=key + "option_" + candidate["variable_id"] + "_" + path,
                    format_func=lambda index: " · ".join(str(part) for part in (
                        "Illustrative" if variants[index].get("illustrative") else "",
                        variants[index].get("variant") or variants[index].get("label"), _text(variants[index].get("value"))) if part),
                    placeholder="Choose the declared master option", disabled=not permitted)
                if option is None:
                    st.info("Choose a master option for " + label.lower() + ".")
                    updates[path] = None
                    continue
                updates[path] = variants[option]["value"]
                provenance = " · ".join(str(part) for part in (variants[option].get("source_path"), variants[option].get("variant")) if part)
                if provenance:
                    st.caption("Master source: " + _text(provenance))
            else:
                updates[path] = field.get("master_value", "")
            st.text(label + ": " + _text(updates[path]))
        elif source == "excel":
            updates[path] = field.get("excel_value", "")
            st.text(label + ": " + (_text(updates[path]) or "Not declared in Excel"))
        elif path == "source.kind":
            updates[path] = _choice(label, values, path, SOURCE_KINDS, key, labels=SOURCE_KINDS, disabled=not permitted)
        else:
            updates[path] = _input(label, values, path, key, multiline=path not in {"output.type", "source.value", "units"}, disabled=not permitted)
            if path in getattr(workflow, "LIST_FIELDS", set()):
                updates[path] = _lines(updates[path])
    updates["field_choices"] = choices
    return updates


def _logic_choice(row, values, candidate, updates, key, permitted):
    interpretation = updates.get("derivation", _get(values, "derivation")) or ""
    record = (candidate or {}).get("record") or {"interpreted": [], "executable": []}
    edited = reuse_logic.describe({**record, "derivation": interpretation})
    if (candidate or {}).get("reuse_readiness") == "needs_edit" or edited["reuse_readiness"] == "needs_edit":
        st.info("Check the thresholds and time windows in this logic. Put product-specific values in the product value field.")
        binding = _digest([updates.get("master_name"), interpretation])
        unchanged = updates.get("master_name", "") == row.get("master_name", "") and interpretation == _get(values, "derivation")
        updates["logic_reviewed"] = st.checkbox("I reviewed the thresholds and time windows in this reusable logic.",
            value=bool(row.get("logic_reviewed") and unchanged), key=key + "logic_reviewed_" + binding, disabled=not permitted)


def _save_to_library(root, pack, actor_id, row, updates, *, local_demo, permitted, allowed_packs):
    key = PREFIX + "library_" + _digest([str(root), pack, actor_id, row["item_id"]]) + "_"
    if st.session_state.get(key + "saved"):
        st.success(st.session_state[key + "saved"] + " is available as a draft master definition.")
        return
    if not st.checkbox("Save this definition to the master library for future products", key=key + "show", disabled=not permitted):
        return
    if _changed_updates(row, updates):
        st.info("Save the definition for this product first. Then review the reusable library entry here.")
        return
    import master_definition_drafts as library_drafts
    context = library_drafts.describe(root, pack, actor_id, item_id=row["item_id"], allowed_packs=allowed_packs)
    if not context.get("ok"):
        _errors(context)
        return
    binding = {name: context[name] for name in ("input_digest", "state_digest", "library_digest")}
    if key + "loaded" not in st.session_state:
        st.session_state[key + "loaded"] = binding
    displayed = st.session_state[key + "loaded"]
    stale = displayed != binding
    if stale:
        st.warning("The product or master library changed while this form was open. Reload its source before saving.")
        if st.button("Reload library source", key=key + "reload"):
            st.session_state[key + "loaded"] = binding
            st.rerun()
    values = row["values"]
    st.caption("This creates a draft library template. Product dates, values and example settings stay with the product.")
    name = st.text_input("New master variable name", value=row["variable_id"], key=key + "name")
    label = st.text_input("Master definition label", value=row["variable_id"], key=key + "label")
    definition = st.text_area("Reusable definition", value=_text(row.get("definition")), key=key + "definition")
    st.text("Saved reusable logic: " + _text(values.get("derivation")))
    st.text("Data type: " + _text(_get(values, "output.type")))
    raw_slots = st.text_area("Product setting slots (name = description, one per line)", key=key + "slots",
                             help="Describe each setting that a future product must supply. Keep actual values in the product.")
    if st.button("Save new master definition", key=key + "save", disabled=not permitted or stale) and not stale:
        try:
            try:
                slots = [{"name": name, "description": description} for name, description in _columns(raw_slots).items()]
            except ValueError as error:
                raise ValueError(str(error).replace("Source columns", "Product setting slots").replace("role = column", "name = description")) from error
            result = library_drafts.save(root, pack, actor_id, item_id=row["item_id"], name=name, label=label,
                definition=definition, logic=values.get("derivation", ""), data_type=_get(values, "output.type"),
                source_kind=_get(values, "source.kind"), parameter_slots=slots,
                expected_input_digest=displayed["input_digest"], expected_state_digest=displayed["state_digest"],
                expected_library_digest=displayed["library_digest"], allowed_packs=allowed_packs,
                local_demo=local_demo, can_write=permitted, confirmed=True)
        except (ValueError, OSError) as error:
            st.error(str(error))
            return
        if not result.get("ok"):
            _errors(result)
            return
        st.session_state[key + "saved"] = result.get("name", name)
        st.session_state[PREFIX + "notice"] = "Saved " + result.get("name", name) + " as a draft master definition for future products."
        st.rerun()


def _shared_source(root, pack, actor_id, report, row, updates, *, key, permitted, local_demo, allowed_packs):
    """Preview an explicit group edit; diagnosis sources are never inferred."""
    import variable_review_source_batch as source_batch
    attributes = {"regimen", "start_date", "delivered_end_date", "last_activity_date"}
    family = row.get("family") or {}
    if family.get("name") != "treatment_line" or family.get("attribute") not in attributes:
        return
    siblings = [item for item in report["rows"] if item["item_id"] != row["item_id"]
                and (item.get("family") or {}).get("name") == "treatment_line"
                and item["family"].get("attribute") in attributes]
    if not siblings:
        return
    with st.expander("Reuse this source for other treatment-line variables"):
        lookup = {item["item_id"]: item for item in siblings}
        selected = st.multiselect("Also apply this source to", list(lookup), key=key + "source_siblings",
            format_func=lambda item_id: lookup[item_id]["variable_id"], disabled=not permitted)
        st.caption("Share the table and role-to-column mapping. Each variable keeps its own line, attribute and scientific definition.")
        if not selected:
            return
        shared_fields = {"source.kind", "source.logical_table", "source.physical_stem", "source.columns"}
        shared = {path: deepcopy(updates[path]) for path in shared_fields}
        extras = {path: value for path, value in updates.items() if path not in shared_fields and path != "_column_errors"}
        trial = deepcopy(row["values"])
        for path, value in shared.items():
            workflow._put(trial, path, value)
        try:
            synchronized = source_batch._sync_primary_input(row, trial)
        except ValueError:
            synchronized = None  # The batch reports the conflicting row before writing.
        if synchronized is not None and extras.get("source.inputs") == synchronized:
            # Updating the redundant main input is part of the shared edit.
            # Actual changes to linked tables still require a separate row save.
            extras.pop("source.inputs", None)
        for path in ("source.parameters", "source.spec_identifiers", "depends_on", "implementation_refs"):
            if isinstance(extras.get(path), str):
                extras[path] = _lines(extras[path])
        pending = bool(_changed_updates(row, extras))
        if pending:
            st.info("Save this variable's other source edits first, then apply its shared mapping.")
        st.dataframe([{"Variable": item["variable_id"], "Source alias": shared["source.logical_table"],
                       "Table": shared["source.physical_stem"], "Columns": _text(shared["source.columns"])}
                      for item in [row, *(lookup[item_id] for item_id in selected)]], hide_index=True, width="stretch")
        if st.button("Apply source to selected variables", key=key + "apply_source", disabled=not permitted or pending):
            if updates.get("_column_errors"):
                _errors({"errors": updates["_column_errors"]})
                return
            result = source_batch.save_rows(root, pack, actor_id, [row["item_id"], *selected], shared,
                expected_input_digest=report["input_digest"], expected_state_digest=report["state_digest"],
                allowed_packs=allowed_packs, local_demo=local_demo, can_write=permitted)
            if not result.get("ok"):
                _errors(result)
                return
            st.session_state[PREFIX + "notice"] = "Source mapping saved for " + ", ".join(result["variable_ids"]) + "."
            st.session_state.setdefault("flow_result", {}).pop(pack, None)
            st.rerun()


def _editor(root, pack, actor_id, report, row, phase, *, permitted, local_demo, allowed_packs, attention_view=False):
    key = PREFIX + "row_" + _digest([pack, actor_id, row["item_id"], phase, report.get("input_digest"), report.get("state_digest")]) + "_"
    values = deepcopy(row.get("values") or {})
    st.write(f"**Edit {row['variable_id']}**")
    st.text("Specification wording (reference): " + _text(row.get("definition")))
    if _spec_values(row.get("spec_values")):
        st.text("Current specification values / codes: " + _spec_values(row["spec_values"]))
    for issue in (row.get("phase_issues") or {}).get(phase, row.get("issues") or []):
        st.caption(_issue_text(issue))
    selected_master = row.get("master_name") or _get(values, "master_name") or ""
    candidate = None
    custom_key = PREFIX + "custom_" + _digest([str(root), pack, actor_id, row["item_id"]])
    if phase == "science":
        import variable_review_family as families
        import variable_review_family_page as family_page
        candidates = report.get("master_candidates") or []
        by_name = {str(candidate.get("variable_id") or candidate.get("name")): candidate for candidate in candidates}
        options = ["", *by_name]
        if selected_master and selected_master not in options:
            options.append(selected_master)
        family_request = PREFIX + "family_request_" + _digest([pack, actor_id, row["item_id"]])
        if st.session_state.pop(family_request, False) and "LINE_OF_THERAPY" in by_name:
            st.session_state[key + "master"] = "LINE_OF_THERAPY"
            st.session_state[custom_key] = False
        selected_master = st.selectbox("Master variable definition", options, index=options.index(selected_master),
            key=key + "master", disabled=not permitted,
            format_func=lambda name: f"{name} · " + ("Draft library definition" if "CUSTOM_LOGIC.yaml" in str(by_name.get(name, {}).get("source_path", "")) else "Library template") if name else "Search the master variable list")
        candidate = by_name.get(selected_master)
        family_mode = bool(selected_master == "LINE_OF_THERAPY" or row.get("family") and selected_master == row.get("master_name"))
        if not family_mode and families.matches(row, candidate) and "LINE_OF_THERAPY" in by_name:
            if st.button("Set up treatment-line variable", key=key + "family", disabled=not permitted):
                st.session_state[family_request] = True
                st.rerun()
        if st.button("No suitable match — create a definition", key=key + "custom", disabled=not permitted):
            st.session_state[custom_key] = True
        custom = st.session_state.get(custom_key, False)
        if custom:
            if st.button("Return to master search", key=key + "search"):
                st.session_state[custom_key] = False
                st.rerun()
            st.caption("Start from this product's Excel values and the answers already entered. Keep reusable logic and product-specific values separate.")
            selected_master, candidate = "", None
            comparison = workflow.comparison_from_report(report, row["item_id"], "")
            if comparison.get("ok"):
                for field in comparison.get("fields") or []:
                    current = _get(values, field["path"])
                    if field.get("editable") and field.get("has_excel") and current in (None, "", "TODO", "undecided"):
                        parts, target = field["path"].split("."), values
                        for part in parts[:-1]:
                            if not isinstance(target.get(part), dict):
                                target[part] = {}
                            target = target[part]
                        target[parts[-1]] = deepcopy(field["excel_value"])
            if not _blank_placeholder(_get(values, "derivation")).strip():
                values["derivation"] = _text(row.get("definition"))
            updates = _science_fields(row, values, key, permitted)
            updates["master_name"] = selected_master
            if row.get("family"):
                updates["family"] = {}
        elif family_mode:
            updates = family_page.render(row, values, key=key + "family_", permitted=permitted)
            updates["master_name"] = selected_master
            if "derivation" in updates:
                updates["logic_reviewed"] = True
        elif candidate:
            comparison = workflow.comparison_from_report(report, row["item_id"], selected_master)
            if not comparison.get("ok"):
                _errors(comparison)
                return
            if any(comparison.get(name) != report.get(name) for name in ("input_digest", "state_digest")):
                st.warning("The table changed while this comparison opened. Refresh it before choosing values.")
                return
            updates = _master_fields(row, candidate, comparison, values, key, permitted)
            updates["master_name"] = selected_master
            if row.get("family"):
                updates["family"] = {}
        else:
            st.info("Search and select a master definition to compare its fields with this product's Excel specification.")
            return
        if custom or not family_mode:
            _logic_choice(row, values, candidate, updates, key, permitted)
        missing = _missing_scientific_answers(values, updates)
        trial = deepcopy(row)
        for path, value in updates.items():
            if path in workflow.META_FIELDS:
                trial[path] = value
            else:
                workflow._put(trial["values"], path, value)
        issues = consistency.issues(trial) + families.issues(trial) + requirements.issues(trial, candidate)
        for issue in issues:
            st.warning(issue)
        if missing:
            st.info("To resolve this variable, complete: " + ", ".join(missing) + ".")
        save_label = "Save unfinished draft" if missing or issues else "Save changes" if custom else "Use this definition"
        save = st.button(save_label, key=key + "save", type="primary", disabled=not permitted)
    else:
        import variable_review_options
        options = variable_review_options.describe(root, pack, actor_id, allowed_packs=allowed_packs)
        if not options.get("ok"):
            with st.expander("Dropdown metadata details"):
                for error in options.get("errors") or []:
                    st.caption(str(error))
            options = {}
        updates = _source_fields(values, key, permitted, options, row=row) if phase == "source" else _output_fields(values, key, permitted, options)
        trial = deepcopy(row)
        for path, value in updates.items():
            if not path.startswith("_"):
                workflow._put(trial["values"], path, value)
        if phase == "source":
            import variable_review_source_validation
            source_trial = deepcopy(trial)
            for path in workflow.LIST_FIELDS:
                value = workflow._get(source_trial["values"], path)
                if isinstance(value, str):
                    workflow._put(source_trial["values"], path, _lines(value))
            preview_issues = variable_review_source_validation.issues(source_trial, options)
        else:
            proposed_rows = [trial if item["item_id"] == row["item_id"] else item for item in report["rows"]]
            preview_issues = consistency.report_issues(proposed_rows).get(row["item_id"], [])
        for issue in preview_issues:
            st.warning(issue)
        if phase == "source":
            _shared_source(root, pack, actor_id, report, row, updates, key=key,
                           permitted=permitted, local_demo=local_demo, allowed_packs=allowed_packs)
        else:
            st.session_state[PREFIX + "output_editor_dirty"] = bool(_changed_updates(row, updates))
        save = st.button("Save unfinished draft" if preview_issues else "Save changes", key=key + "save", disabled=not permitted, type="primary")
    if save:
        try:
            if phase == "science" and any(value is None for value in updates.values()):
                st.error("Choose the master options shown above before using this definition.")
                return
            if phase == "source":
                column_errors = updates.pop("_column_errors", [])
                if column_errors:
                    raise ValueError(" ".join(column_errors))
                for path in ("source.parameters", "source.spec_identifiers", "depends_on", "implementation_refs"):
                    if isinstance(updates[path], str):
                        updates[path] = _lines(updates[path])
            updates = _changed_updates(row, updates)
            if not updates:
                st.info("No changes to save. The current values are already on the dashboard.")
                return
            result = workflow.save_row(root, pack, actor_id, row["item_id"], phase, updates,
                expected_input_digest=report["input_digest"], expected_state_digest=report["state_digest"],
                allowed_packs=allowed_packs, local_demo=local_demo, can_write=permitted)
        except (ValueError, OSError) as error:
            st.error(str(error))
            return
        if not result.get("ok"):
            _errors(result)
            return
        st.session_state[PREFIX + "saved_selection"] = {"phase": phase, "item_id": row["item_id"], "attention": attention_view}
        st.session_state.setdefault("flow_result", {}).pop(pack, None)
        st.rerun()
    if phase == "science" and custom:
        _save_to_library(root, pack, actor_id, row, updates, local_demo=local_demo,
                         permitted=permitted, allowed_packs=allowed_packs)


def _transfer(root, pack, actor_id, report, *, local_demo, can_write, allowed_packs):
    if not all(report["phases"][phase].get("confirmed") for phase in PHASES):
        return
    st.write("**Continue with the reviewed definitions**")
    st.caption("Copy this reviewed table into your definition drafts for the existing validation and contract workflow.")
    key = PREFIX + "transfer_" + _digest([actor_id, report["input_digest"], report["state_digest"]])
    permitted = bool(local_demo and can_write)
    confirmed = st.checkbox("Copy these reviewed variables into my definition drafts.", key=key, disabled=not permitted)
    if st.button("Prepare definition drafts", key=key + "_save", disabled=not permitted or not confirmed):
        try:
            result = workflow.transfer_to_drafts(root, pack, actor_id,
                expected_input_digest=report["input_digest"], expected_state_digest=report["state_digest"],
                confirmed=confirmed, allowed_packs=allowed_packs, local_demo=local_demo, can_write=permitted)
        except (ValueError, OSError) as error:
            st.error(str(error))
            return
        if result.get("ok"):
            transferred = result.get("transferred") or []
            st.session_state[PREFIX + "notice"] = "The reviewed variables are ready in your definition drafts."
            return {"route": "scientific_draft", "params": {"item_id": transferred[0]} if transferred else {}, "changed": True}
        _errors(result)
        if result.get("transferred"):
            st.warning("Some definition drafts were prepared before the operation stopped: " + ", ".join(result["transferred"]))
        st.session_state[key + "_conflicts"] = result.get("conflicts") or []
    conflicts = st.session_state.get(key + "_conflicts") or []
    if conflicts:
        st.info("A definition draft already contains different work. Review that draft before trying the copy again.")
        if st.button("Open the existing definition draft", key=key + "_existing"):
            return {"route": "scientific_draft", "params": {"item_id": conflicts[0]}}


def _confirmation(root, pack, actor_id, report, phase, *, local_demo, can_review, can_write, allowed_packs):
    state = report["phases"][phase]
    if state.get("blocked_by"):
        previous = state["blocked_by"] if isinstance(state["blocked_by"], list) else [state["blocked_by"]]
        st.info("Confirm " + ", ".join(LABELS.get(name, str(name)).lower() for name in previous) + " before confirming this phase.")
        return
    if state.get("confirmed"):
        review = state.get("review") or {}
        st.success(f"{LABELS[phase]} confirmed" + (f" by {review['actor_id']}" if review.get("actor_id") else "") + ".")
        index = PHASES.index(phase)
        if index < len(PHASES) - 1:
            next_phase = PHASES[index + 1]
            if st.button("Continue to " + LABELS[next_phase].lower(), key=PREFIX + "continue_" + phase):
                st.session_state[PREFIX + "next_phase"] = next_phase
                st.rerun()
        else:
            st.success("All three variable review phases are complete.")
            return _transfer(root, pack, actor_id, report, local_demo=local_demo, can_write=can_write, allowed_packs=allowed_packs)
        return
    if not state.get("ready"):
        count = state.get("total_count", len(report["rows"])) - state.get("ready_count", 0)
        st.info(f"Resolve the remaining {count} variable{'s' if count != 1 else ''} before confirming {LABELS[phase].lower()}.")
        if st.button("Resolve remaining variables", key=PREFIX + "resolve_" + phase):
            if phase == "science":
                st.session_state[PREFIX + "next_science_view"] = "attention"
            else:
                incomplete = next((row for row in report["rows"] if row.get("phase_status", {}).get(phase) != "ready"), None)
                if incomplete:
                    st.session_state[PREFIX + "incoming_item"] = {"phase": phase, "item_id": incomplete["item_id"]}
            st.rerun()
        if state.get("issues"):
            with st.expander("Remaining review details", expanded=False):
                for issue in state["issues"]:
                    st.caption(_issue_text(issue))
        return
    if not can_review:
        st.info(f"The dashboard is ready. A permitted {ROLES[phase].lower()} can confirm this phase.")
    key = PREFIX + "confirm_" + _digest([phase, report["input_digest"], report["state_digest"]])
    confirmed = st.checkbox("I have reviewed all variables in this phase.", key=key, disabled=not can_review)
    if st.button("Confirm " + LABELS[phase].lower(), key=key + "_save", type="primary", disabled=not can_review or not confirmed):
        try:
            result = workflow.confirm_phase(root, pack, actor_id, phase,
                expected_input_digest=report["input_digest"], expected_state_digest=report["state_digest"],
                confirmed=confirmed, allowed_packs=allowed_packs, local_demo=local_demo, can_review=can_review)
        except (ValueError, OSError) as error:
            st.error(str(error))
            return
        if not result.get("ok"):
            _errors(result)
            return
        st.session_state[PREFIX + "notice"] = LABELS[phase] + " confirmed."
        st.session_state.setdefault("flow_result", {}).pop(pack, None)
        st.rerun()


def assistant_context(root, pack, actor_id, *, allowed_packs=None, params=None):
    """Give chat the same phase and current blockers as the visible dashboard."""
    report = _describe(root, pack, actor_id, allowed_packs)
    context = st.session_state.get(PREFIX + "context") or []
    current_context = context[:4] == [str(root), pack, actor_id, allowed_packs]
    phase = st.session_state.get(PREFIX + "phase") if current_context else None
    requested = (params or {}).get("phase")
    if st.session_state.get(PREFIX + "incoming") != _digest(params or {}) and requested in PHASES:
        phase = requested
    if phase not in PHASES:
        phase = (params or {}).get("phase") or report.get("current_phase") or "science"
    if phase == "complete":
        phase = "output"
    if phase not in PHASES:
        phase = "science"
    state = (report.get("phases") or {}).get(phase, {})
    blockers = [_text(issue) for issue in report.get("errors") or []]
    blocked_by = state.get("blocked_by") or []
    if isinstance(blocked_by, str):
        blocked_by = [blocked_by]
    blockers.extend("Confirm " + LABELS.get(name, str(name)).lower() + " first." for name in blocked_by)
    blockers.extend(_issue_text(issue) for issue in state.get("issues") or [])
    for row in report.get("rows") or []:
        if row.get("phase_status", {}).get(phase) != "ready":
            blockers.append(f"{row.get('variable_id', '')}: {_status(row, phase)}")
    return {"phase": phase, "blockers": list(dict.fromkeys(blockers)),
            "row_count": len(report.get("rows") or []), "ready_count": state.get("ready_count", 0)}


def render(root, pack, actor_id, params=None, local_demo=False, can_write=False,
           can_view=True, can_review=False, allowed_packs=None):
    if not can_view:
        import related_extraction_page
        related_extraction_page.clear()
        st.info("You need access to this product to review its variables.")
        return True
    context = [str(root), pack, actor_id, allowed_packs, local_demo, can_write, can_review]
    if st.session_state.get(PREFIX + "context") != context:
        for key in list(st.session_state):
            if str(key).startswith(PREFIX):
                del st.session_state[key]
        st.session_state[PREFIX + "context"] = context
    try:
        report = _describe(root, pack, actor_id, allowed_packs)
    except (ValueError, OSError) as error:
        st.error(str(error))
        return True
    if not report.get("ok"):
        _errors(report)
        if st.button("Open specification intake", key=PREFIX + "intake"):
            return {"route": "progress", "params": {"action_id": "g1_extract"}}
        return True
    if st.session_state.get(PREFIX + "notice"):
        st.success(st.session_state.pop(PREFIX + "notice"))
    if st.session_state.get(PREFIX + "saved_selection"):
        _saved_row_notice(report, st.session_state[PREFIX + "saved_selection"])
    if local_demo:
        st.caption("Development review · saved with this product and available to the next reviewer.")
    else:
        st.info("This shared review can be edited and confirmed in development mode.")
    for warning in report.get("warnings") or []:
        st.warning(str(warning))
    rows = report.get("rows") or []
    if not rows:
        st.info("No variables are available to review yet. Extract and check the product specification first.")
        if st.button("Open specification intake", key=PREFIX + "intake"):
            return {"route": "progress", "params": {"action_id": "g1_extract"}}
        return True
    import related_extraction_page
    related_route = related_extraction_page.render(root, pack, actor_id, can_view=can_view,
        allowed_packs=allowed_packs)
    if related_route:
        return related_route
    requested = (params or {}).get("phase")
    incoming = _digest(params or {})
    if st.session_state.get(PREFIX + "incoming") != incoming:
        st.session_state[PREFIX + "incoming"] = incoming
        st.session_state.pop(PREFIX + "incoming_item", None)
        if requested in PHASES:
            st.session_state[PREFIX + "phase"] = requested
        if (params or {}).get("action") == "review":
            st.session_state[PREFIX + "science_view"] = "all"
            st.session_state.pop(PREFIX + "incoming_item", None)
        else:
            item_id = (params or {}).get("item_id")
            matches = [row for row in rows if row["item_id"] == item_id] if item_id else [
                row for row in rows if str(row["variable_id"]).casefold() == str((params or {}).get("variable", "")).casefold()]
            if len(matches) == 1:
                st.session_state[PREFIX + "phase"] = requested if requested in PHASES else "science"
                st.session_state[PREFIX + "incoming_item"] = {"item_id": matches[0]["item_id"],
                    "phase": requested if requested in PHASES else "science"}
                st.session_state[PREFIX + "science_view"] = "all"
    if PREFIX + "next_science_view" in st.session_state:
        st.session_state[PREFIX + "science_view"] = st.session_state.pop(PREFIX + "next_science_view")
    if PREFIX + "next_phase" in st.session_state:
        st.session_state[PREFIX + "phase"] = st.session_state.pop(PREFIX + "next_phase")
    if st.session_state.get(PREFIX + "phase") not in PHASES:
        st.session_state[PREFIX + "phase"] = report.get("current_phase") if report.get("current_phase") in PHASES else "output" if report.get("current_phase") == "complete" else "science"
    phase = st.radio("Review phase", PHASES, key=PREFIX + "phase", horizontal=True,
        format_func=lambda name: f"{PHASES.index(name) + 1}. {LABELS[name]}" + (" · Confirmed" if report["phases"][name].get("confirmed") else ""))
    state = report["phases"][phase]
    st.write(f"**{ROLES[phase]} · {len(rows)} variables**")
    if state.get("blocked_by"):
        blockers = state["blocked_by"] if isinstance(state["blocked_by"], list) else [state["blocked_by"]]
        st.info("Confirm " + ", ".join(LABELS.get(name, str(name)).lower() for name in blockers) + " before starting this phase.")
        return True
    permitted = bool(local_demo and can_write)
    if not permitted:
        st.info("You can review this dashboard. Editing requires permission to change this product.")
    attention = [row for row in rows if row.get("phase_status", {}).get(phase) != "ready"]
    if phase == "science":
        attention.sort(key=lambda row: ({"unmapped": 0, "ambiguous": 1}.get(row.get("status"), 2), row.get("variable_id", "")))
        if attention:
            st.write(f"{len(attention)} variable{'s' if len(attention) != 1 else ''} need{'s' if len(attention) == 1 else ''} attention. Clear master matches are already prepared for the final dashboard.")
            view = st.radio("Scientific review view", ("attention", "all"), horizontal=True, key=PREFIX + "science_view",
                            format_func=lambda value: "Resolve variables needing attention" if value == "attention" else "Review all variables")
        else:
            view = "all"
            st.success("Every variable is prepared. Review the complete dashboard, then confirm once.")
    else:
        view = "all"
    shown = attention if view == "attention" else rows
    st.dataframe(dashboard_rows(shown, phase), hide_index=True, width="stretch")
    editor_options = [row["item_id"] for row in shown]
    lookup = {row["item_id"]: row for row in shown}
    selected_key = PREFIX + "selected_" + _digest([phase, view, editor_options])
    incoming_item = st.session_state.get(PREFIX + "incoming_item") or {}
    if incoming_item.get("phase") == phase and incoming_item.get("item_id") in lookup:
        st.session_state[selected_key] = incoming_item["item_id"]
        st.session_state.pop(PREFIX + "incoming_item", None)
    saved_selection = st.session_state.pop(PREFIX + "saved_selection", None) or {}
    if saved_selection.get("phase") == phase and saved_selection.get("item_id") in lookup:
        saved_row = lookup[saved_selection["item_id"]]
        if not saved_selection.get("attention") or saved_row.get("phase_status", {}).get(phase) != "ready":
            st.session_state[selected_key] = saved_row["item_id"]
    selected = st.selectbox("Resolve a variable" if view == "attention" else "Edit a variable (optional)",
        editor_options, index=0 if view == "attention" else None,
        placeholder="Choose a variable to edit", key=selected_key,
        format_func=lambda item_id: f"{lookup[item_id]['variable_id']} · {_status(lookup[item_id], phase)}")
    st.session_state[PREFIX + "output_editor_dirty"] = False
    if selected:
        _editor(root, pack, actor_id, report, lookup[selected], phase,
                permitted=permitted, local_demo=local_demo, allowed_packs=allowed_packs, attention_view=view == "attention")
    if phase == "output" and st.session_state[PREFIX + "output_editor_dirty"]:
        st.info("Save or discard the output edits above before confirming the table or preparing executable settings.")
        if st.button("Discard unsaved output edits", key=PREFIX + "discard_output", disabled=not permitted):
            row_prefix = PREFIX + "row_" + _digest([pack, actor_id, selected, phase, report.get("input_digest"), report.get("state_digest")]) + "_"
            for key in list(st.session_state):
                if str(key).startswith(row_prefix):
                    del st.session_state[key]
            st.session_state[PREFIX + "notice"] = "Unsaved output edits discarded. The saved review table is unchanged."
            st.rerun()
        return True
    if view == "all":
        action = _confirmation(root, pack, actor_id, report, phase, local_demo=local_demo,
                      can_review=bool(local_demo and can_review), can_write=permitted, allowed_packs=allowed_packs)
        if action:
            return action
    if phase == "output":
        import variable_execution_bridge_page
        action = variable_execution_bridge_page.render(root, pack, actor_id,
            local_demo=local_demo, can_write=permitted, allowed_packs=allowed_packs)
        if action:
            return action
    return True
