"""Bound Excel review transport with an explicit bridge into unfinished row drafts."""
from __future__ import annotations

from datetime import datetime, timezone
import hashlib
import io
import json
from pathlib import Path
import re
import tempfile
import zipfile

import review_workbook
from decision_answers import _paths, _read
from spec_extract import row_item_id

NOTICE = "A checked review workbook records reviewer input. It does not approve a definition, authenticate a signature or release a product."
LIMIT = 10 * 1024 * 1024


def _hash(data):
    return hashlib.sha256(data).hexdigest()


def _scope(root, pack, actor_id, allowed_packs):
    root, pack, product = _paths(root, pack, allowed_packs)
    if not str(actor_id).strip():
        raise ValueError("An editing identity is required.")
    owner = _hash(str(actor_id).encode())[:24]
    folder = product / ".portal-drafts" / "review-exchange" / owner
    if folder.resolve() != folder:
        raise ValueError("The review folder redirects to another location.")
    for path in (product / "spec_pipeline", product / "spec_pipeline/out"):
        if path.resolve() != path:
            raise ValueError("The extraction folder redirects to another location.")
    extraction = _read(product / "spec_pipeline/out/extracted.json")
    register = product / "handoff/DECISIONS.md"
    register_raw = _read(register) if register.exists() else b""
    digest = _hash(extraction + b"\x00" + register_raw)
    return product, folder, owner, digest


def _fail(error):
    return {"ok": False, "errors": [str(error)], "notice": NOTICE}


def _issue(product):
    with tempfile.TemporaryDirectory(prefix="rwd-review-") as tmp:
        path = Path(tmp) / "review.xlsx"
        stats = review_workbook.build(str(product), str(path))
        return path.read_bytes(), stats


def build(root, pack, actor_id, *, allowed_packs):
    try:
        product, _folder, _owner, digest = _scope(root, pack, actor_id, allowed_packs)
        data, stats = _issue(product)
        return {"ok": True, "errors": [], "data": data, "input_digest": digest, "stats": stats, "notice": NOTICE}
    except (OSError, ValueError, KeyError, TypeError, SystemExit) as exc:
        return _fail(exc)


def _inspect(raw):
    from openpyxl import load_workbook
    if not isinstance(raw, bytes) or len(raw) > LIMIT:
        raise ValueError("Use a review workbook of at most 10 MB.")
    with zipfile.ZipFile(io.BytesIO(raw)) as archive:
        if len(archive.infolist()) > 2000 or sum(info.file_size for info in archive.infolist()) > 40 * 1024 * 1024:
            raise ValueError("The expanded workbook exceeds the review transport limit.")
        if any("vbaproject" in name.lower() or "externallinks/" in name.lower() for name in archive.namelist()):
            raise ValueError("Use an .xlsx review workbook without macros or external workbook links.")
    workbook = load_workbook(io.BytesIO(raw), data_only=False)
    for sheet in workbook:
        if sheet.max_row > 10000 or sheet.max_column > 50:
            raise ValueError("The workbook exceeds the review row or column limit.")
        for row in sheet:
            if any(cell.data_type == "f" for cell in row):
                raise ValueError("Review workbooks must contain literal values, without formulas.")
    return workbook


def _checked(product, raw):
    actual = _inspect(raw)
    fresh_bytes, _ = _issue(product)
    fresh = _inspect(fresh_bytes)
    if actual.sheetnames != fresh.sheetnames:
        raise ValueError("Keep the issued workbook's sheets unchanged.")
    for name in ("Provenance", "Findings", "Decisions"):
        values = lambda wb: [tuple(cell.value for cell in row) for row in wb[name]]
        if values(actual) != values(fresh):
            raise ValueError(f"The {name} tab differs from the current product. Download a fresh workbook and review what changed.")
    with tempfile.TemporaryDirectory(prefix="rwd-review-") as tmp:
        path = Path(tmp) / "returned.xlsx"
        path.write_bytes(raw)
        result = review_workbook.read(str(path), str(product))
    if result.get("problems"):
        raise ValueError("\n".join(result["problems"]))
    rows = json.loads(_read(product / "spec_pipeline/out/extracted.json")).get("rows", [])
    by_id = {row.get("item_id"): row for row in rows}
    for decision in result["decisions"]:
        row = by_id[decision["item_id"]]
        decision["source_row"] = row_item_id(row)
        decision["variable"] = row.get("variable", "")
    return result


def receive(root, pack, actor_id, raw, *, expected_input_digest, allowed_packs, local_demo, can_write):
    try:
        if local_demo is not True or can_write is not True:
            raise ValueError("Saving a review return requires an authorized local editing session.")
        product, folder, owner, digest = _scope(root, pack, actor_id, allowed_packs)
        if digest != expected_input_digest:
            raise ValueError("The specification or decision register changed. Download the current workbook before returning the review.")
        result = _checked(product, raw)
        if not result["decisions"]:
            raise ValueError("No reviewer decisions were entered. Fill reviewer_decision, reviewed_by and reviewed_date for at least one row.")
        envelope = {"pack": pack, "owner": owner, "input_digest": digest,
                    "updated_at": datetime.now(timezone.utc).isoformat(), "result": result,
                    "state": "review input checked; scientific review pending", "notice": NOTICE}
        payload = json.dumps(envelope, ensure_ascii=False, sort_keys=True).encode()
        rid = _hash(payload)
        # Recheck the bound files after the canonical reader has finished.
        if _scope(root, pack, actor_id, allowed_packs)[3] != digest:
            raise ValueError("The source changed during review validation. Reload before saving.")
        folder.mkdir(parents=True, exist_ok=True)
        path = folder / f"{rid}.json"
        if path.resolve() != path:
            raise ValueError("The review record redirects to another location.")
        with path.open("xb") as handle:
            handle.write(payload)
        return {"ok": True, "errors": [], "id": rid, **envelope}
    except (OSError, ValueError, KeyError, TypeError, SystemExit, zipfile.BadZipFile) as exc:
        return _fail(exc)


def load(root, pack, actor_id, rid, *, allowed_packs):
    try:
        _product, folder, owner, digest = _scope(root, pack, actor_id, allowed_packs)
        if not re.fullmatch(r"[a-f0-9]{64}", str(rid)):
            raise ValueError("Choose a saved review return.")
        raw = _read(folder / f"{rid}.json")
        if _hash(raw) != rid:
            raise ValueError("The saved review input has changed. Return the workbook again for validation.")
        envelope = json.loads(raw)
        if envelope.get("pack") != pack or envelope.get("owner") != owner:
            raise ValueError("This review belongs to another product or editing identity.")
        return {"ok": True, "errors": [], "id": rid, **envelope, "stale": digest != envelope["input_digest"]}
    except (OSError, ValueError, TypeError, KeyError) as exc:
        return _fail(exc)


def recent(root, pack, actor_id, *, allowed_packs):
    try:
        _product, folder, _owner, _digest = _scope(root, pack, actor_id, allowed_packs)
    except (ValueError, OSError):
        return []
    out = []
    for path in sorted(folder.glob("*.json"))[:200]:
        record = load(root, pack, actor_id, path.stem, allowed_packs=allowed_packs)
        if record["ok"]:
            out.append({"id": path.stem, "route": "review_workbook", "title": "Returned scientific review",
                        "state": "source changed — review again" if record["stale"] else record["state"],
                        "summary": f"{len(record['result']['decisions'])} reviewer decisions; definitions remain pending.",
                        "params": {"id": path.stem}, "updated_at": record["updated_at"]})
    return out


def copy_comment(root, pack, actor_id, rid, item_id, *, expected_input_digest, expected_draft_digest,
                 allowed_packs, local_demo, can_write):
    import scientific_definitions as definitions
    record = load(root, pack, actor_id, rid, allowed_packs=allowed_packs)
    if not record["ok"]:
        return record
    if record["stale"]:
        return _fail("The source changed after this review. Return a review of the current workbook first.")
    item = next((r for r in record["result"]["decisions"] if r["item_id"] == item_id), None)
    if not item or not item.get("variable") or not item.get("comment"):
        return _fail("Select a named source row with an explicit reviewer comment to transfer.")
    current = definitions.describe(root, pack, actor_id, item_id=item["source_row"], allowed_packs=allowed_packs)
    if not current["ok"]:
        return current
    values = dict(current["values"])
    citation = f"Review workbook {rid}: {item['decision']} by {item['reviewed_by']} on {item['reviewed_date']}. {item['comment']}"
    values["notes"] = str(values.get("notes") or "") + "\n" + citation
    return definitions.save_draft(root, pack, actor_id, item["source_row"], values,
        expected_input_digest=expected_input_digest, expected_draft_digest=expected_draft_digest,
        allowed_packs=allowed_packs, local_demo=local_demo, can_write=can_write)
