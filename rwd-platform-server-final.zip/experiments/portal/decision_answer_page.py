"""A scientist's answer form over existing, pack-scoped issued questions."""
from datetime import date
from pathlib import Path

import streamlit as st

import decision_answers as answers
import decision_answer_choices as choices
import form_assistance as form_help


def clear():
    import decision_answer_ai_page
    decision_answer_ai_page._clear_feedback()
    for key in list(st.session_state):
        if str(key).startswith("decision_answer_"):
            st.session_state.pop(key, None)


def _remember(decision_id):
    """Keep typed text when Streamlit removes widgets on another workspace page."""
    drafts = dict(st.session_state.get("decision_answer_drafts") or {})
    drafts[decision_id] = {field: str(st.session_state.get(f"decision_answer_{decision_id}_{field}", "")) for field in answers.FIELDS}
    st.session_state["decision_answer_drafts"] = drafts


def _fill(decision_id, field, value):
    """A button's click writes one field (the clicker's name, today's date) before the next run draws
    the input; nothing is filled in until the person clicks."""
    st.session_state[f"decision_answer_{decision_id}_{field}"] = str(value)
    _remember(decision_id)


def _answer_changed(decision_id):
    choices.note_edit(decision_id)
    _remember(decision_id)


RAISE_KEYS = ("decision_answer_raise_id", "decision_answer_raise_question", "decision_answer_raise_evidence", "decision_answer_raise_owner")


def _remember_raise():
    st.session_state["decision_answer_raise_draft"] = {key: st.session_state.get(key) for key in RAISE_KEYS}


def _use_question_draft(draft):
    st.session_state["decision_answer_raise_question"] = draft["question"]
    st.session_state["decision_answer_raise_evidence"] = draft["evidence"]
    st.session_state["decision_answer_raise_continuation"] = draft["signature"]
    _remember_raise()


def _question_continuation(pack, actor_id, incoming, *, enabled):
    if isinstance(incoming, dict) and isinstance(incoming.get("question"), str) and incoming["question"].strip():
        draft = {field: incoming.get(field) if isinstance(incoming.get(field), str) else ""
                 for field in ("question", "variable", "source", "context", "evidence")}
        signature = tuple(draft.values())
        if st.session_state.get("decision_answer_question_incoming") != signature:
            st.session_state["decision_answer_question_incoming"] = signature
            st.session_state["decision_answer_question_continuation"] = {**draft, "signature": signature}
    draft = st.session_state.get("decision_answer_question_continuation")
    if not draft:
        return None
    st.write("**Draft question from dataset comparison**" if draft["source"] == "dataset_comparison" else "**Draft question from the workflow**")
    if draft["variable"]:
        st.text("Variable: " + draft["variable"])
    if draft["context"]:
        st.text("Comparison: " + draft["context"])
    st.text(draft["question"])
    if draft["evidence"]:
        st.text("Suggested evidence: " + draft["evidence"])
    if draft.get("recorded_id"):
        st.info(f"Question {draft['recorded_id']} was recorded. Prepare or continue its answer draft below; creating the question does not establish pooling equivalence.")
    else:
        st.caption("This question is not in the register yet. Copy it into Raise a new question, review the wording and evidence, "
                   "then choose its identifier and owner before recording it as open. No answer or review details are supplied.")
        st.button("Use this question draft", key="decision_answer_use_question_draft", disabled=not enabled,
                  help="Copies the question and evidence into the unsaved form, replacing those two fields. Review them before raising the question.",
                  on_click=_use_question_draft, args=(draft,))
    if draft["source"] == "dataset_comparison":
        if st.button("Return to dataset comparison", key="decision_answer_return_comparison"):
            import connected_workflow_page
            connected_workflow_page.open_route("dataset_comparison", pack, actor_id, params={"variable": draft["variable"]})
    return draft


def _refresh(pack, context, description, notice):
    """Show `notice` on the next render over the re-read questions; unsaved answer drafts stay.

    The snapshot is replaced, not dropped: a missing snapshot reads as a changed product and
    clears every widget, which would take the notice and the person's unsaved drafts with it.
    """
    st.session_state["decision_answer_snapshot"] = {"context": context, "description": description}
    st.session_state.setdefault("flow_result", {}).pop(pack, None)
    st.session_state["decision_answer_notice"] = notice
    st.rerun()


def _raise_form(root, pack, context, description, *, enabled, can_write, local_demo):
    """One open question appended to the register (2026-09-07, DL-03). No answer, name or date."""
    owners = description.get("owners") or []
    with st.expander("Raise a new question", expanded=bool(st.session_state.get("decision_answer_question_continuation"))):
        st.caption("Add one open question to the decision register. It records no answer, no name and no date; the owner is the role the question goes to.")
        if not owners:
            st.info("The register does not name any owner yet, so a new question has nobody to go to. Ask your data expert to record the first question.")
            return
        if not enabled:
            st.info("Raising a question requires product-author access in a local demo.")
        for key, value in (st.session_state.get("decision_answer_raise_draft") or {}).items():
            if key in RAISE_KEYS and value is not None:
                st.session_state.setdefault(key, value)
        form_help.field(st.text_input, "Question identifier", key="decision_answer_raise_id", disabled=not enabled, binding=description["digest"],
                      on_change=_remember_raise,
                      help="Capital letters, digits and dashes, for example LOT-NULL. Contract records cite this identifier.")
        form_help.field(st.text_area, "Question", key="decision_answer_raise_question", max_chars=1000, disabled=not enabled, binding=description["digest"],
                     on_change=_remember_raise,
                     help="One plain sentence. Avoid | because the register is a table; detail belongs in the answer form.")
        form_help.field(st.text_input, "Evidence", key="decision_answer_raise_evidence", disabled=not enabled, binding=description["digest"],
                      on_change=_remember_raise,
                      help="What the answerer should read: a specification row such as clinical:3, a finding identifier, or a file in the product.")
        form_help.field(st.selectbox, "Owner", owners, index=None, key="decision_answer_raise_owner", placeholder="Choose who answers this question", disabled=not enabled, binding=description["digest"],
                     on_change=_remember_raise,
                     help="The roles the register already uses. A question put to nobody is one nobody answers.")
        if st.button("Raise this question", key="decision_answer_raise", disabled=not enabled):
            values = {name: str(st.session_state.get(key) or "") for name, key in zip(answers.RAISE_FIELDS, RAISE_KEYS)}
            if not all(value.strip() for value in values.values()):
                st.warning("Enter the identifier, the question, its evidence and the owner before raising it.")
                return
            result = answers.raise_question(root, pack, values, expected_digest=description["digest"],
                                            local_demo=local_demo, can_write=can_write, allowed_packs=[pack])
            if result.get("ok"):
                continuation = st.session_state.get("decision_answer_question_continuation")
                if continuation and st.session_state.get("decision_answer_raise_continuation") == continuation["signature"]:
                    st.session_state["decision_answer_question_continuation"] = {**continuation, "recorded_id": result["raised"],
                        "question": values["question"], "evidence": values["evidence"]}
                for key in RAISE_KEYS:
                    st.session_state.pop(key, None)
                st.session_state.pop("decision_answer_raise_draft", None)
                st.session_state.pop("decision_answer_raise_continuation", None)
                _refresh(pack, context, result, f"Question {result['raised']} raised and recorded as open. Prepare its question draft when you are ready to answer it; nothing has been decided.")
            for error in result.get("errors") or ["The question could not be raised."]:
                st.error(str(error))
            if result.get("stale_lock"):
                st.session_state["decision_answer_stale_lock"] = True


def _recheck_worklist(root, pack, actor_id, context, *, enabled, can_write, local_demo):
    """Records that cite answered questions and still wait as decision_required (DL-04)."""
    waiting = answers.settled_records(root, pack, allowed_packs=[pack])
    if not waiting:
        return
    st.write("**Records waiting for a re-check**")
    st.caption("These contract records cite questions that are now answered. Re-checking applies each record's own judgments again through the contract checks so its status can move on. Nothing in the record is edited, and nothing is approved.")
    for entry in waiting:
        left, right = st.columns([3, 1])
        left.text(f"{entry['variable_id']} cites {', '.join(entry['decision_ids'])}")
        if right.button("Re-check record", key=f"decision_answer_recheck_{entry['variable_id']}", disabled=not enabled):
            result = answers.recheck_record(root, pack, actor_id, entry["variable_id"], local_demo=local_demo,
                                            can_write=can_write, allowed_packs=[pack])
            if result.get("ok"):
                _refresh(pack, context, answers.describe(root, pack, allowed_packs=[pack]),
                         f"{entry['variable_id']} re-checked. Its requirement status is now {result.get('requirement') or 'updated'}. "
                         "The definition still needs the answer written in and the named review; nothing is approved.")
            for error in result.get("errors") or ["The record could not be re-checked."]:
                st.error(str(error))
            if result.get("reopen"):
                st.session_state["decision_answer_reopen_offer"] = entry["variable_id"]
            if result.get("stale_lock"):
                st.session_state["decision_answer_stale_contract_lock"] = True
    offer = st.session_state.get("decision_answer_reopen_offer")
    if offer:
        # the act the record check names, on this page (walk NEW-7)
        st.info(f"{offer} changed after the contract was approved. Reopen the approval so the record can be re-checked; "
                "the approval form is then prepared again over the new contract.")
        if st.button("Reopen the contract approval and re-check", key="decision_answer_reopen_contract", disabled=not enabled):
            reopened = answers.reopen_contract(root, pack, actor_id, local_demo=local_demo, can_write=can_write, allowed_packs=[pack])
            for error in reopened.get("errors") or []:
                st.error(str(error))
            if reopened.get("ok"):
                st.session_state.pop("decision_answer_reopen_offer", None)
                again = answers.recheck_record(root, pack, actor_id, offer, local_demo=local_demo, can_write=can_write, allowed_packs=[pack])
                if again.get("ok"):
                    _refresh(pack, context, answers.describe(root, pack, allowed_packs=[pack]),
                             f"{reopened['message']} {offer} re-checked; its requirement status is now {again.get('requirement') or 'updated'}.")
                for error in again.get("errors") or []:
                    st.error(str(error))
    if st.session_state.get("decision_answer_stale_contract_lock"):
        st.warning("An earlier contract save left its lock behind. If nobody else is saving the contract, clear it and re-check again.")
        if st.button("Clear the stale lock", key="decision_answer_clear_contract_lock", disabled=not enabled):
            import scientific_definitions
            cleared = scientific_definitions.clear_stale_lock(root, pack, actor_id, local_demo=local_demo, can_write=can_write, allowed_packs=[pack])
            st.session_state.pop("decision_answer_stale_contract_lock", None)
            if cleared.get("ok"):
                st.success("The stale lock was cleared. Re-check the record again.")
            for error in cleared.get("errors") or []:
                st.error(str(error))


def _stale_lock_offer(root, pack, *, enabled, can_write, local_demo):
    """After a save met a lock older than ten minutes, let the person clear that one file (DL-06)."""
    if not st.session_state.get("decision_answer_stale_lock"):
        return
    st.warning("An earlier save left its lock behind. If nobody else is saving answers for this product, clear it and save again.")
    if st.button("Clear the stale lock", key="decision_answer_clear_lock", disabled=not enabled):
        cleared = answers.clear_stale_lock(root, pack, local_demo=local_demo, can_write=can_write, allowed_packs=[pack])
        st.session_state.pop("decision_answer_stale_lock", None)
        if cleared.get("ok"):
            st.success("The stale lock was cleared. Save your answer again.")
        for error in cleared.get("errors") or []:
            st.error(str(error))


def render(root, pack, actor_id, *, local_demo, can_write, can_view, initial_decision_id=None, actor_name=None, question_draft=None):
    """Return True only after a validated save. Names and dates are never inferred."""
    if not can_view:
        clear()
        st.warning("You no longer have access to this product's questions.")
        return False
    context = (str(Path(root).resolve()), pack, actor_id)
    cached = st.session_state.get("decision_answer_snapshot")
    context_changed = isinstance(cached, dict) and cached.get("context") != context
    if not isinstance(cached, dict) or cached.get("context") != context:
        clear()
        description = answers.describe(root, pack, allowed_packs=[pack])
        st.session_state["decision_answer_snapshot"] = {"context": context, "description": description}
    else:
        description = cached["description"]
    st.write("**Scientific decisions**")
    st.caption("Read the question, draft an answer, then record the decision only after review. Unfinished entries stay available as you move between questions.")
    continuation = _question_continuation(pack, actor_id, question_draft,
        enabled=bool(local_demo and can_write and description.get("ok") and description.get("owners")))
    initial_decision_id = initial_decision_id or (continuation or {}).get("recorded_id")
    if not description.get("ok"):
        for error in description.get("errors") or ["The questions could not be read."]:
            st.warning(str(error))
        if st.button("Reload questions", key="decision_answer_reload"):
            clear()
            st.rerun()
        return False
    # The widgets were cleared above when the product or person changed, so the form is safe to
    # enable on this very render (it used to say 'requires product-author access' to a person who
    # had it, for one click, after every product switch).
    enabled = local_demo and can_write
    if not enabled:
        st.info("Saving answers requires product-author access in a local demo.")
    notice = st.session_state.pop("decision_answer_notice", None)
    if notice:
        st.success(str(notice))
    for error in st.session_state.pop("decision_answer_completion_errors", []):
        st.warning(str(error))
    if description.get("completion_pending_ids") or not description.get("report_current", True):
        st.info("Saved decision evidence needs updating. This refreshes the ranked questions and completes ledger records for answers already recorded; unfinished drafts stay open. It does not authenticate a reviewer.")
        for problem in description.get("completion_problems", []):
            st.warning(str(problem))
        if st.button("Update saved decision evidence", key="decision_answer_complete", disabled=not enabled):
            result = answers.complete_saved(root, pack, expected_digest=description["digest"],
                local_demo=local_demo, can_write=can_write and can_view, allowed_packs=[pack])
            if result.get("ok"):
                st.session_state["decision_answer_snapshot"] = {"context": context, "description": result}
                st.session_state["decision_answer_completion_errors"] = result.get("completion_errors", [])
                if result.get("completion_ok"):
                    st.session_state["decision_answer_notice"] = "Saved decision evidence and ranked questions are current. Reviewer authentication is still a separate step."
                st.session_state.setdefault("flow_result", {}).pop(pack, None)
                st.rerun()
            for error in result.get("errors", []):
                st.error(str(error))
    _raise_form(root, pack, context, description, enabled=enabled, can_write=can_write and can_view, local_demo=local_demo)
    _recheck_worklist(root, pack, actor_id, context, enabled=enabled, can_write=can_write and can_view, local_demo=local_demo)
    unissued = description.get("unissued_ids") or []
    if unissued:
        st.info(f"{len(unissued)} open question(s) need a draft answer form before you can work through them here.")
        st.caption("Preparation copies the issued questions and leaves each answer, decision maker and date blank. The questions remain open.")
        if st.button("Prepare question drafts", key="decision_answer_prepare", disabled=not enabled):
            # the register may have changed since this page was drawn (a definition was just saved):
            # read it again here instead of refusing and sending the person to find Reload (walk UC3-P2-2)
            current = answers.describe(root, pack, allowed_packs=[pack])
            digest = current["digest"] if current.get("ok") else description["digest"]
            prepared = answers.prepare_forms(root, pack, expected_digest=digest,
                local_demo=local_demo, can_write=can_write and can_view, allowed_packs=[pack])
            if prepared.get("ok"):
                st.session_state["decision_answer_snapshot"] = {"context": context, "description": prepared}
                st.success("Question drafts prepared. Choose a question and write your answer; no decision has been recorded.")
                st.session_state["decision_answer_last_action"] = "prepared"
                return True
            for error in prepared.get("errors") or ["Question drafts could not be prepared."]:
                st.error(str(error))
    items = description.get("items") or []
    if not items:
        st.info("No issued answer forms are available yet. Prepare the open question drafts above, or raise a new question above.")
        _stale_lock_offer(root, pack, enabled=enabled, can_write=can_write and can_view, local_demo=local_demo)
        return False
    editable = [item for item in items if item["editable"]]
    ordered = editable + [item for item in items if not item["editable"]]
    by_id = {item["id"]: item for item in ordered}
    if initial_decision_id in by_id and st.session_state.get("decision_answer_incoming") != initial_decision_id:
        st.session_state["decision_answer_selected"] = initial_decision_id
        st.session_state["decision_answer_incoming"] = initial_decision_id
    if st.session_state.get("decision_answer_selected") not in by_id:
        st.session_state["decision_answer_selected"] = next(iter(by_id))
    # Preserve another question's unsaved input when its widgets are not rendered.
    for key in list(st.session_state):
        if str(key).startswith("decision_answer_") and (any(str(key).endswith("_" + field) for field in answers.FIELDS) or str(key).endswith(("_approach", "_choice_explanation"))):
            st.session_state[key] = st.session_state[key]
    selected = st.selectbox("Question", list(by_id), format_func=lambda did: f"{did} · {by_id[did]['status'].lower()}", key="decision_answer_selected")
    item = by_id[selected]
    fresh = answers.describe(root, pack, allowed_packs=[pack])
    stale = not fresh.get("ok") or fresh.get("digest") != description["digest"]
    if stale:
        st.error("The questions, forms or contract changed while this page was open. Your entries are retained; reload and review the current question before recording a decision.")
        if st.button("Reload current questions and keep my drafts", key="decision_answer_reload_keep"):
            if all(f"decision_answer_{selected}_{field}" in st.session_state for field in answers.FIELDS):
                _remember(selected)
            st.session_state["decision_answer_snapshot"] = {"context": context, "description": fresh}
            for key in list(st.session_state):
                if str(key).startswith("decision_answer_ai_"):
                    del st.session_state[key]
            st.rerun()
    st.text(item["question"])
    st.text("Evidence: " + (item["evidence"] or "No evidence supplied."))
    if item["status"] == "OPEN" and str(item["values"].get("answer") or "").strip():
        st.caption("This question remains open. RESOLVED in a prepared answer file is its proposed outcome. "
                   "Review the draft, then choose Save this answer to record it; saving does not authenticate approval.")
    for error in item["errors"]:
        st.warning(str(error))
    if not item["editable"] and item["status"] != "OPEN":
        st.info("This question is already recorded. A changed ruling needs a new decision, preserving the earlier answer.")
    draft = (st.session_state.get("decision_answer_drafts") or {}).get(selected, item["values"])
    for field in answers.FIELDS:
        st.session_state.setdefault(f"decision_answer_{selected}_{field}", draft.get(field, item["values"][field]))
    editable_here = enabled and item["editable"]
    # CHOICES FIRST, THEN HELP, THEN THE TEXT (2026-09-07): the product owner asked for questions that
    # are simple to answer - a choice to pick or an AI suggestion to accept - with free text as the
    # fallback. The choices quote the question's own alternatives; nothing here selects one.
    st.write("**Draft an answer**")
    # An AI copy accepted below lands here, before the choice widgets exist in this run: the copy
    # resets the drafting choice, and a widget's value cannot change once it has been drawn.
    pending = st.session_state.pop("decision_answer_pending_copy", None)
    if isinstance(pending, dict) and pending.get("id") == selected and editable_here:
        choices.use_answer(selected, str(pending.get("answer") or ""))
        _remember(selected)
    guide = choices.render(selected, item["question"], enabled=editable_here, remember=_remember)
    with st.expander("Suggest an answer with AI (optional; you review it before it is used)"):
        import decision_answer_ai_page
        copied = decision_answer_ai_page.render(root, pack, actor_id, item,
            str(st.session_state.get(f"decision_answer_{selected}_answer", "")),
            expected_digest=description["digest"], local_demo=local_demo, can_write=editable_here and not stale,
            allowed_packs=[pack])
        if copied is not None and editable_here:
            st.session_state["decision_answer_pending_copy"] = {"id": selected, "answer": copied}
            st.session_state["decision_answer_notice"] = ("Option copied into your unsaved draft. Review and edit it below. "
                                                          "No decision maker, date or saved decision was changed.")
            st.rerun()
    form_help.field(st.text_area, "Draft answer", key=f"decision_answer_{selected}_answer", max_chars=4000, disabled=not editable_here, on_change=_answer_changed, args=(selected,), binding=description["digest"],
                 help="Example format: state your reviewed rule, its scope and rationale. Keep TODO for unresolved choices. Avoid | because the decision register is a table.")
    answer_text = str(st.session_state.get(f"decision_answer_{selected}_answer", ""))
    decision_answer_ai_page.offer_feedback(root, pack, actor_id, item, answer_text,
        expected_digest=description["digest"], can_write=editable_here and not stale, allowed_packs=[pack])
    unresolved = answers.unresolved_answer(answer_text)
    if unresolved:
        st.info("This answer is unfinished. Review each TODO or unresolved choice and edit the text when the decision has been made. No decision has been recorded.")
    with st.expander("Review and record the decision", expanded=bool(answer_text.strip()) and not unresolved):
        st.caption("Enter who actually made the decision and the date they made it. Draft choices and AI never fill these fields.")
        left, right = st.columns(2)
        with left:
            st.text_input("Decision maker's name", key=f"decision_answer_{selected}_answered_by", disabled=not editable_here, on_change=_remember, args=(selected,),
                          help="The person who made this decision; this is a typed attribution, not a signature.")
            # ONE CLICK, STILL THE PERSON'S ACT: the button writes the name of the person who clicked
            # it, nothing is filled in before they do, and a different decision maker is typed.
            # the click writes the field in an on_click callback: callbacks run before the widgets of the
            # next run are drawn, which is the only moment Streamlit lets a widget's value be set
            # (writing it after the input was drawn crashed the form: walk UC1-03, 2026-09-07)
            if actor_name and editable_here:
                st.button(f"I made this decision: {actor_name}", key=f"decision_answer_{selected}_me",
                          on_click=_fill, args=(selected, "answered_by", str(actor_name)))
        with right:
            st.text_input("Decision date", key=f"decision_answer_{selected}_answer_date", placeholder="YYYY-MM-DD", disabled=not editable_here, on_change=_remember, args=(selected,),
                          help="Enter the date the person made the decision, for example 2026-09-06. It is never inferred from today.")
            if editable_here:
                st.button("Decided today", key=f"decision_answer_{selected}_today",
                          on_click=_fill, args=(selected, "answer_date", date.today().isoformat()))
        st.caption(answers.NOTICE)
        save = st.button("Save this answer", key="decision_answer_save", type="primary", disabled=not editable_here or stale or unresolved or guide.get("pending_choice", False))
    if save:
        values = {field: str(st.session_state.get(f"decision_answer_{selected}_{field}", "")) for field in answers.FIELDS}
        if not all(value.strip() for value in values.values()):
            st.warning("Enter the answer, decision maker and date before saving. Your other draft answers are retained.")
        else:
            result = answers.save(root, pack, {selected: values}, expected_digest=description["digest"], local_demo=local_demo,
                                  can_write=can_write and can_view, allowed_packs=[pack])
            if result.get("ok"):
                st.session_state["decision_answer_completion_errors"] = result.get("completion_errors", [])
                if result.get("completion_ok"):
                    st.session_state["decision_answer_notice"] = "Answer recorded, ledger evidence saved and ranked questions refreshed. Authenticate the decision maker during scientific review; other drafts are retained."
                else:
                    st.session_state["decision_answer_notice"] = "Answer recorded. Its evidence update still needs completion below; other drafts are retained."
                st.session_state["decision_answer_snapshot"] = {"context": context, "description": result}
                st.session_state["decision_answer_last_action"] = "saved"
                st.session_state.setdefault("flow_result", {}).pop(pack, None)
                return True
            for error in result.get("errors") or ["The answers could not be saved."]:
                st.error(str(error))
            if result.get("stale_lock"):
                st.session_state["decision_answer_stale_lock"] = True
    _stale_lock_offer(root, pack, enabled=enabled, can_write=can_write and can_view, local_demo=local_demo)
    if st.button("Reload saved questions", key="decision_answer_reload", help="Discard unsaved entries and read current questions and evidence."):
        clear()
        st.rerun()
    return False
