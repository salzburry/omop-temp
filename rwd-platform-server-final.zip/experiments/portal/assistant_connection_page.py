"""Session-local assistant selection and explicit, metadata-only connection checks."""
from __future__ import annotations

import os
from pathlib import Path

import streamlit as st

import scientific_definition_ai as assistant

LABELS = {"vscode": "VS Code chat model", "claude_code": "Claude Code (local sign-in)",
          "anthropic": "Anthropic API"}


def render(root, actor_id, *, local_demo):
    # Every script run sets its own ContextVar; another user's rerun cannot change
    # the provider of an in-flight request. The server environment is untouched.
    if not local_demo:
        assistant.set_provider_selection(None)
        st.session_state.pop("assistant_connection_context", None)
        return
    context = (str(Path(root).resolve()), actor_id)
    if st.session_state.get("assistant_connection_context") != context:
        configured = os.environ.get("RWD_PORTAL_AI_PROVIDER", "").strip().lower()
        st.session_state["assistant_connection_choice"] = configured if configured in LABELS else None
        st.session_state["assistant_connection_context"] = context
    with st.expander("Assistant connection"):
        choice = st.selectbox("Connection for all agents and drafting helpers", list(LABELS), index=None,
            format_func=LABELS.get, key="assistant_connection_choice",
            placeholder="Choose an assistant connection",
            help="Applies to intake, orchestration, source, coding, validation and critic agents, plus the guide and drafting helpers. Existing drafts are retained when you change it.")
        assistant.set_provider_selection(choice or "")
        if choice == "claude_code":
            st.caption("Uses the Claude Code CLI signed in on this computer. No API key is needed for this connection. Claude account access, usage limits and billing still apply.")
        elif choice == "vscode":
            st.caption("In this repository's VS Code window, run RWD Portal: Connect Chat Model and keep that window open.")
        elif choice == "anthropic":
            st.caption("Uses the API credential already configured in the server environment. Credentials are never entered here.")
        st.caption("Intake, orchestration, source, coding and validation agents share this connection. The critic checks specialist results automatically within a requested run.")
        st.caption("The same connection serves the page guide, scientific definitions, decision answers and form suggestions. Start with the question on your current page; each model request is explicit and proposed changes remain available for review.")
        if st.button("Check assistant connection", key="assistant_connection_check", disabled=choice is None):
            try:
                config = assistant._provider(root, health=True)
                if not config.get("configured"):
                    st.info(config.get("help") or "This connection has not been configured.")
                elif choice == "anthropic":
                    assistant.check_direct_runtime(config)
                    st.info("API configuration and local Python runtime checked. Account and model access will be checked when you request suggestions.")
                    st.caption("No prompt or API request was sent. A local check does not confirm account access.")
                else:
                    model = (config.get("model_info") or {}).get("name") or config.get("model")
                    if choice == "claude_code":
                        st.success(f"Claude Code local sign-in found · {model}")
                        st.caption("CLI version and local sign-in metadata checked. Model access is checked when you request suggestions; no question was sent.")
                    else:
                        st.success(f"{LABELS[choice]} is connected · {model}")
                        st.caption("Connection metadata checked. No question was sent and no model answer was generated.")
            except (assistant.Invalid, assistant.vscode.BridgeError) as error:
                st.warning(str(error))
            except Exception:
                st.warning("The assistant connection could not be checked. Reconnect it and try again; your draft is unchanged.")
