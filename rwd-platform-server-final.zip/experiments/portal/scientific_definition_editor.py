"""Short authoring sections; examples never become scientific answers."""
from copy import deepcopy
import hashlib
import json

import streamlit as st
import yaml
import scientific_definition_choices as choices
import form_assistance as form_help

PREFIX = "scientific_definition_"
SECTIONS = ("1 · Meaning", "2 · Timing", "3 · Missing values", "4 · Source and names", "5 · Review")
GROUPS = (("derivation", "grain"), ("anchor", "window", "record_selection", "tie_break"),
          ("missing", "cohort_applicability", "units"), (), ("acceptance", "notes"))


def blank(value):
    return "" if isinstance(value, str) and value.strip() == "TODO" else value


def _form_binding(selected):
    """Bind drafts to the row and the source/draft snapshot already owned by its page."""
    return st.session_state.get(PREFIX + "loaded", selected["item_id"])


def mapping(value):
    if isinstance(value, dict):
        return deepcopy(value)
    try:
        parsed = yaml.safe_load(value)
        return parsed if isinstance(parsed, dict) else {}
    except (yaml.YAMLError, TypeError):
        return {}


def digest(values):
    return hashlib.sha256(json.dumps(values, sort_keys=True, ensure_ascii=False).encode()).hexdigest()


def retain_fields():
    # Detached widget values must survive section changes and connected routes.
    for key in list(st.session_state):
        if str(key).startswith(PREFIX + "field_") and not str(key).endswith("_edit"):
            st.session_state[key] = st.session_state[key]


def collect(defaults):
    """Merge visible and hidden fields without discarding unedited source detail."""
    values = deepcopy(defaults)
    for field in ("variable_id", *[f for group in GROUPS for f in group]):
        key = PREFIX + "field_" + field
        if key in st.session_state:
            values[field] = st.session_state[key]
    for field in ("depends_on", "decision_ids", "gap_ids", "implementation_refs"):
        key = PREFIX + "field_" + field
        if key in st.session_state:
            values[field] = [line.strip() for line in st.session_state[key].splitlines() if line.strip()]
    errors = []
    source = mapping(values["source"])
    kind_key = PREFIX + "field_source_kind"
    if kind_key in st.session_state:
        kind = st.session_state[kind_key]
        source["kind"] = kind
        for field in ("spec_identifiers", "parameters"):
            key = PREFIX + "field_source_" + field
            if key in st.session_state:
                source[field] = [line.strip() for line in st.session_state[key].splitlines() if line.strip()]
        if PREFIX + "field_source_value" in st.session_state:
            source["value"] = st.session_state[PREFIX + "field_source_value"]
        for field in ("logical_table", "physical_stem"):
            key = PREFIX + "field_source_" + field
            if key in st.session_state:
                value = st.session_state[key].strip()
                if value:
                    source[field] = value
                else:
                    source.pop(field, None)
        key = PREFIX + "field_source_columns"
        if key in st.session_state:
            columns = {}
            for number, line in enumerate(st.session_state[key].splitlines(), 1):
                if not line.strip():
                    continue
                role, separator, column = line.partition("=")
                role, column = role.strip(), column.strip()
                if not separator or not role or not column:
                    errors.append(f"Source columns, line {number}: enter role = column.")
                elif role in columns:
                    errors.append(f"Source columns, line {number}: '{role}' is repeated. Give each role one explicit column.")
                else:
                    columns[role] = column
            if columns:
                source["columns"] = columns
            else:
                source.pop("columns", None)
        values["source"] = "TODO" if kind == "Unanswered" else source
    for group, fields in (("output", ("physical_name", "target_published_name", "name_status", "type", "nullable", "codes", "role")),
                          ("publish", ("ads", "dictionary", "dashboard", "tfl"))):
        value = mapping(values[group])
        changed = False
        for field in fields:
            key = PREFIX + "field_" + group + "_" + field
            if key in st.session_state:
                value[field] = st.session_state[key]
                changed = True
        if changed:
            values[group] = value
    return values, errors


def source_context(selected):
    fields = selected.get("spec_fields") or {}
    # Values often carry the actual requirement (for example, a cutoff date).
    for name, value in fields.items():
        if str(name).lower().replace("_", " ") in {"values", "value", "time period", "notes"} and value not in (None, ""):
            st.text(f"{name}: {value}")
    with st.expander("Full specification details and citation"):
        st.text(f"{selected.get('tab') or selected['item_id'].split(':')[0]} · row {selected.get('row') or selected['item_id'].split(':')[-1]}")
        for name, value in fields.items():
            if value not in (None, ""):
                st.text(f"{name}: {value}")
        if selected.get("notes"):
            st.text(selected["notes"])


def render_fields(root, pack, actor_id, selected, defaults, text_fields, *, permitted, naming_packs):
    section = st.radio("Work through this definition", SECTIONS, key=PREFIX + "section", horizontal=True,
                       help="Move between sections freely. Entries stay in this session; Save unfinished row draft stores them for later.")
    index = SECTIONS.index(section)
    st.caption(f"Section {index + 1} of {len(SECTIONS)} · Blank means not decided. Save unfinished work whenever you need to pause.")
    cutoff = "cutoff" in selected["variable_id"].lower() or "cut-off" in selected["variable_id"].lower()
    intros = (
        "Start with two answers: what should this value mean, and what does one value describe?",
        "Describe the dates that count and how to choose between eligible records.",
        "Explain missing data, who this rule applies to, and the unit of the result.",
        "Work with your data expert to connect the interpretation to its source and output name.",
        "Give a small example, then check the full definition and review the proposed contract change.",
    )
    st.write(intros[index])
    if index == 0:
        def review_names():
            st.session_state[PREFIX + "section"] = SECTIONS[3]
            st.session_state[PREFIX + "show_names"] = True
        st.button("Check existing names and prior definitions for this row", key=PREFIX + "review_names",
                  on_click=review_names, help="Opens the names section for this same row and keeps your current answers.")
        if cutoff:
            st.info("For this cutoff row, decide whether the value describes a data delivery, a study setting, or each patient's record. The date quoted above comes from the specification; it does not answer that design question.")
        st.write("**What does ‘One value per’ mean?** Choose what one result belongs to, such as a delivery or a patient. Choose **Write my own answer** for a different scope or to name the actual identifiers.")
    if index == 1:
        st.caption("For a metadata date, an assessment window may not apply. Explain n/a when appropriate; do not substitute the study index end. If the requirement also filters events, specify that separately.")
    if index == 2 and cutoff:
        st.info("If a delivery cutoff is missing or disagrees with the delivery metadata, should the build stop, or may an unknown value remain? The quoted date alone does not settle this rule.")
    if index == 3:
        _technical(root, pack, actor_id, selected, defaults, permitted, naming_packs)
    for field in GROUPS[index]:
        label, help_text = text_fields[field]
        raw = defaults[field]
        if not isinstance(raw, str):
            raw = yaml.safe_dump(raw, default_flow_style=True).strip().removesuffix("\n...")
        if field in choices.CHOICES:
            choices.render(field, label, blank(raw), help_text, binding=_form_binding(selected))
        else:
            form_help.field(st.text_area, label, value=blank(raw), key=PREFIX + "field_" + field, help=help_text, binding=_form_binding(selected),
                         placeholder="Write your answer, or leave blank to decide later", height=100)
    if index == 0:
        with st.expander("Definition identifier — the stable name of this record"):
            form_help.field(st.text_input, "Definition identifier", value=str(defaults["variable_id"]), key=PREFIX + "field_variable_id", binding=_form_binding(selected),
                          help="Example: DATA_CUTOFF. This identifies the interpretation, not necessarily its output column. Existing identifiers require an explicit revision if renamed.")
    if index == 4:
        with st.expander("Illustrative example — how to test a rule"):
            if cutoff:
                st.write("Illustrative only: checked delivery metadata containing 30-Jun-2026 might produce the date 2026-06-30 at the grain you choose. Explain the expected result when the metadata is missing or disagrees with the specification. This does not define an event-filtering rule, and no example is inserted for you.")
            else:
                st.write("Illustrative only: for a closest-assessment rule, a value 1 three days before index wins over value 2 six days after index if both dates qualify. Supply your own inputs and expected result, including ties and missing data; no example is inserted for you.")
        values, _ = collect(defaults)
        missing = []
        for group, fields in zip(SECTIONS, GROUPS):
            unanswered = [text_fields[f][0] for f in fields if not str(values[f]).strip() or "TODO" in str(values[f]).upper()]
            if unanswered:
                missing.append(f"{group}: {', '.join(unanswered)}")
        if missing:
            st.info("Still unanswered — return to these sections, or save an unfinished draft:")
            for line in missing:
                st.write("• " + line)
        st.caption("This list tracks writing progress. The existing validator checks the full record, including source, naming, dependencies and review references.")
        with st.expander("Read all current answers"):
            st.json(values)
    return index


def _technical(root, pack, actor_id, selected, defaults, permitted, naming_packs):
    import scientific_definition_naming_page
    name = scientific_definition_naming_page.render(root, pack, selected["variable_id"], actor_id=actor_id,
        allowed_packs=naming_packs, can_write=permitted, item_id=selected["item_id"],
        expanded=bool(st.session_state.get(PREFIX + "show_names")))
    if name is not None and permitted:
        st.session_state[PREFIX + "field_output_physical_name"] = name
    source = mapping(defaults["source"])
    kinds = ["Unanswered", "vendor", "derived", "parameter", "constant", "unavailable", "pending_mapping"]
    default = source.get("kind", "vendor" if source else "Unanswered")
    if default not in kinds:
        kinds.insert(0, str(default))
    kind_labels = {"Unanswered": "Choose a source", "vendor": "Delivered data column", "derived": "Calculated from other values",
                   "parameter": "Product setting", "constant": "Fixed value for this product", "unavailable": "Unavailable",
                   "pending_mapping": "Source mapping still needed"}
    kind = form_help.field(st.selectbox, "Where the value comes from", kinds, index=kinds.index(default), key=PREFIX + "field_source_kind", binding=_form_binding(selected),
                 format_func=lambda value: kind_labels.get(value, value),
                 help="Vendor = supplied data; derived = calculated from records; parameter = a configured setting; constant = fixed value; pending_mapping = a source still needs to be chosen. Example: choosing parameter does not create the setting.")
    st.caption("New derivations or missing mappings still need an engineering handoff. Saving this definition does not implement them.")
    if kind == "derived":
        st.info("A calculated value does not need a matching column in the source table. Describe its rule in Meaning and Timing, then list the existing definition identifiers it uses under Declared dependencies.")
        with st.expander("Example: a follow-up end date built from several inputs"):
            st.write("Illustrative chain: source visit and treatment dates → last qualifying visit and last treatment date → follow-up end date → follow-up duration. The study team must decide which events count, the cutoff or death rules, and what happens when inputs are missing.")
            st.write("Map each raw input to its actual table and column. For an input already calculated by another definition, cite that definition's identifier under Declared dependencies. Do not invent a vendor follow-up-end column for the calculated result. Reuse existing checked definitions only after reviewing their meaning.")
            st.write("Use Output fields for the calculated column's name and type. Under Review, give small input examples and their expected dates, including missing or conflicting inputs. Implementation references identify the code or configuration that performs the calculation; unresolved implementation goes through the existing engineering handoff.")
    if kind == "pending_mapping":
        raw = source.get("spec_identifiers", [])
        form_help.field(st.text_area, "Identifiers named in the specification", value="\n".join(raw) if isinstance(raw, list) else str(raw), binding=_form_binding(selected),
                     key=PREFIX + "field_source_spec_identifiers",
                     help="Copy the source identifiers exactly, one per line. Example: DATAV only if the specification names DATAV. This preserves what needs mapping; it does not choose a source table.")
    if kind == "parameter":
        raw = source.get("parameters", [])
        form_help.field(st.text_area, "Declared parameter references", value="\n".join(raw) if isinstance(raw, list) else str(raw), binding=_form_binding(selected),
                     key=PREFIX + "field_source_parameters", help="Example: study.data_cutoff only if this is the proposed parameter. Recording a reference does not configure it; use Plan changes or an engineering handoff.")
    if kind in {"constant", "parameter"}:
        st.caption("Set this product's value from its own specification. Reusing a definition does not fill this field from the reference product.")
        form_help.field(st.text_input, "Value for this product", value=blank(str(source.get("value", ""))), key=PREFIX + "field_source_value", binding=_form_binding(selected),
                      help="Enter the date, threshold or other value for this product, or leave it undecided. This saves the proposed value in the row draft; it does not change executable settings.")
    with st.expander("Source table details and dependencies — with your data expert"):
        for field, label in (("logical_table", "Source alias"), ("physical_stem", "Source table name")):
            form_help.field(st.text_input, label, value=blank(str(source.get(field, ""))), key=PREFIX + "field_source_" + field, binding=_form_binding(selected),
                          help="Example: a declared assessments alias or its vendor table. Use the actual product mapping; leave blank when unknown.")
        columns = source.get("columns", {})
        pairs = "\n".join(f"{k} = {v}" for k, v in columns.items()) if isinstance(columns, dict) else ""
        form_help.field(st.text_area, "Source columns (role = column, one per line)", value=pairs, key=PREFIX + "field_source_columns", binding=_form_binding(selected),
                     help="Example: value = assessment_score, then date = assessment_date on another line. Each role must occur once.")
        for field, label, example in (
            ("depends_on", "Declared dependencies", "an existing definition identifier, a variable named by the extraction, engine:index for an engine intermediate, or none if explicitly independent"),
            ("decision_ids", "Scientific question identifiers", "an existing question ID, or blank if none cited"),
            ("gap_ids", "Engineering gap identifiers", "an existing gap ID for an unsupported implementation"),
            ("implementation_refs", "Implementation references", "an existing code/config reference, or none if no implementation exists"),
        ):
            raw = defaults[field]
            raw = "\n".join(str(v) for v in raw) if isinstance(raw, list) else str(raw).strip("[] ").replace(", ", "\n")
            form_help.field(st.text_area, label, value=blank(raw), key=PREFIX + "field_" + field, binding=_form_binding(selected),
                         help="One entry per line. Example: " + example + ". Citing a question does not resolve it.")
    with st.expander("Output fields and intended destinations"):
        st.caption("A physical name is the stored column. A published name is what consumers would see. Choosing either does not publish data.")
        output = mapping(defaults["output"])
        examples = {"physical_name": "data_cutoff", "target_published_name": "DATA_CUTOFF",
                    "name_status": "aligned or undecided", "type": "date, integer or string",
                    "nullable": "true or false", "codes": "n/a if no codelist applies",
                    "role": "published, internal, metadata or excluded"}
        for field, example in examples.items():
            value = output.get(field, "")
            value = str(value).lower() if isinstance(value, bool) else str(value)
            form_help.field(st.text_input, field.replace("_", " ").capitalize(), value=blank(value), key=PREFIX + "field_output_" + field, binding=_form_binding(selected),
                          help="Example: " + example + ". Use the reviewed choice for this definition.")
        publication = mapping(defaults["publish"])
        for field in ("ads", "dictionary", "dashboard", "tfl"):
            options = ["undecided", "proposed", "required", "configured", "excluded"]
            value = publication.get(field, "undecided")
            if value not in options:
                options.insert(0, str(value))
            form_help.field(st.selectbox, field.upper() if field in {"ads", "tfl"} else field.capitalize(), options, index=options.index(value), binding=_form_binding(selected),
                         key=PREFIX + "field_publish_" + field,
                         help="Example: proposed while under review. Configured is a declaration, not evidence of publication.")
