"""Report what a scientific reviewer still needs to supply; never supply it for them."""
from pathlib import Path

import source_manifest as sm


FIELDS = {
    "document_id": ("Document ID", "The identifier assigned to the specification document."),
    "revision": ("Document revision", "The revision written in that document."),
    "approved_by": ("Scientific reviewer", "The person accountable for the completed review, matching their signing identity."),
    "approval_date": ("Review date", "The date the review was completed, in YYYY-MM-DD format."),
    "data_refresh": ("Data refresh", "The data delivery or cut governed by this specification."),
    "rwb_qc_reference": ("Specification QC reference", "The ID or link for the actual scientific quality-check record for this specification."),
}


def specification(root, pack):
    path = Path(root) / pack / sm.SOURCE_REFS
    try:
        doc = sm.load(str(path))
        materials = doc.get("source_materials") if isinstance(doc, dict) else None
        specs = [m for m in materials or [] if isinstance(m, dict) and m.get("material_type") == sm.PROGRAM_SPEC]
        if len(specs) != 1:
            return {"error": "The source record must identify exactly one program specification.", "missing": []}
        spec = specs[0]
        missing = [{"Field": label, "Record as": field, "What to supply": instruction}
                   for field, (label, instruction) in FIELDS.items() if sm.field_unstated(spec, field)]
        return {"error": "", "status": str(spec.get("status") or ""), "missing": missing,
                "path": path, "complete_fields": len(FIELDS) - len(missing)}
    except (OSError, ValueError, TypeError, sm.Unreadable):
        return {"error": "The source record could not be read. Open its current file or ask your data expert to repair it.", "missing": []}
