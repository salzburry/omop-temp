"""Durable local execution of the portal's existing, explicitly reviewed actions.

The private journal owns progress, not scientific evidence. Each action still
owns its scope, exact-input validation, rollback and canonical result.
"""
from __future__ import annotations

from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import threading
import time
import uuid

import portal_runtime

ACTIONS = {
    "implementation_runtime": "Synthetic implementation checks",
    "correction_comparison": "Before/after assistant comparison",
    "conversation_evaluation": "Scientific conversation journeys",
    "correction_check": "Linked improvement checks",
    "durable_prepare": "Prepare a reviewed workflow fix",
    "durable_apply": "Check and apply the reviewed fix",
    "runtime_prerequisites": "Check local runtime setup",
    "new_product_apply": "Create the reviewed product",
}
TERMINAL = {"completed", "failed", "cancelled", "interrupted"}
HEAVY_ACTIONS = {"implementation_runtime", "durable_apply", "correction_check"}
MAX_BYTES = 8_000_000


def _check_job_path(directory):
    # The worker lock is longer than the journal and handoffs._write temporary.
    # Check before creating directories or saving a queued journal.
    longest = directory / (("0" * 24) + ".worker.lock")
    if os.name == "nt" and len(str(longest.absolute())) >= 260:
        raise ValueError(f"The local job directory is too long for Windows: {directory}. Set RWDP_STATE_DIR to a short private local path, such as C:\\rwd-state, before retrying. No worker was started.")


def _spawn(command, **options):
    """Detached transport seam; action subprocesses retain their own runner."""
    return portal_runtime._popen(command, **options)


def _hash(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, ensure_ascii=False, allow_nan=False).encode()).hexdigest()


def _now():
    return datetime.now(timezone.utc).isoformat()


def _directory(root, actor, *, for_start=False):
    root = Path(root).resolve(strict=True)
    if not isinstance(actor, str) or not actor.strip() or len(actor) > 200:
        raise ValueError("Choose the local author for this action.")
    base = Path(os.environ.get("RWDP_STATE_DIR") or
                Path(os.environ.get("LOCALAPPDATA") or Path.home()) / "RwdPortal")
    # Never save private execution arguments or transcripts among shared code.
    if base.resolve().is_relative_to(root):
        base = Path(os.environ.get("LOCALAPPDATA") or Path.home()) / "RwdPortal"
    directory = base.resolve() / "portal-jobs" / _hash(str(root))[:16] / _hash(actor)[:16]
    if directory.resolve() != directory.absolute() or directory.is_relative_to(root):
        raise ValueError("Restore a private local job directory outside this checkout.")
    if for_start:
        _check_job_path(directory)
    directory.mkdir(parents=True, exist_ok=True)
    return directory


def _path(root, actor, identifier):
    if not isinstance(identifier, str) or not re.fullmatch(r"[a-f0-9]{24}", identifier):
        raise ValueError("Choose a saved local action.")
    path = _directory(root, actor) / (identifier + ".json")
    if path.resolve() != path.absolute():
        raise ValueError("The saved action redirects outside its private directory.")
    return path


def _read(path):
    if not path.is_file() or path.stat().st_size > MAX_BYTES:
        raise ValueError("The saved action is unavailable or too large.")
    try:
        value = json.loads(path.read_bytes())
        if (not isinstance(value, dict) or value.get("schema") != 1 or
                value.get("digest") != _hash({k: v for k, v in value.items() if k != "digest"}) or
                value.get("id") != path.stem or value.get("action") not in ACTIONS or
                value.get("status") not in {"queued", "running", *TERMINAL} or
                not isinstance(value.get("arguments"), dict) or not isinstance(value.get("allowed_packs"), list) or
                any(not isinstance(value.get(key), str) for key in
                    ("root", "actor", "job_key", "request_hash", "created_at", "updated_at", "progress")) or
                any(not isinstance(pack, str) for pack in value["allowed_packs"]) or
                any(not isinstance(value.get(key), bool) for key in ("cancel_requested", "cancel_observed"))):
            raise ValueError()
        return value
    except (TypeError, KeyError, ValueError, RecursionError):
        raise ValueError("The saved local action changed or is unreadable.") from None


def _write(path, value):
    import handoffs
    value = {k: v for k, v in value.items() if k != "digest"}
    value["digest"] = _hash(value)
    if len(json.dumps(value).encode()) > MAX_BYTES:
        raise ValueError("The local action result exceeds its private journal size limit.")
    handoffs._write(path, value)
    return value


def _update(path, changes, *, only_status=None):
    import local_process_lock as locks
    deadline = time.monotonic() + 3
    while True:
        try:
            with locks.locked(path.with_suffix(".lock"), path.parent):
                current = _read(path)
                if only_status and current["status"] not in only_status:
                    return current
                return _write(path, {**current, **changes, "updated_at": _now()})
        except ValueError as error:
            if "already being" not in str(error) or time.monotonic() >= deadline:
                raise
            time.sleep(0.03)


def _scope(value, root, actor, allowed_packs):
    if value["root"] != str(Path(root).resolve()) or value["actor"] != actor:
        raise ValueError("This action belongs to another checkout or author.")
    if any(pack not in (allowed_packs or []) for pack in value["allowed_packs"]):
        raise ValueError("This action includes a product outside your current access.")


def read(root, actor_id, identifier, *, allowed_packs=None):
    import local_process_lock as locks
    path = _path(root, actor_id, identifier)
    value = _read(path)
    _scope(value, root, actor_id, allowed_packs)
    if value["status"] in {"running", "queued"}:
        owner = value.get("worker") or value.get("launcher")
        alive = locks.process_alive(owner) if owner else None
        if alive is False:
            value = _update(path, {
                "status": "interrupted",
                "resource_state": "unknown",
                "progress": "The previous process ended before saving a complete result. Inspect the matching workflow, then explicitly retry.",
            }, only_status={"queued", "running"})
    if value["status"] == "interrupted" and value.get("resource_state") in {"running", "queued"}:
        value = _update(path, {"resource_state": "unknown"}, only_status={"interrupted"})
    if value["status"] == "interrupted" and value.get("worker"):
        import heavy_runtime_queue as queue
        value = {**value, "orphan_recovery": queue.orphan_state(value["worker"])}
    return value


def stop_interrupted_children(root, actor_id, identifier, *, expected_digest, confirmed=False,
                              can_write=False, allowed_packs=None):
    if confirmed is not True or can_write is not True:
        raise ValueError("Explicitly request stopping this action's remaining processes with write access.")
    current = read(root, actor_id, identifier, allowed_packs=allowed_packs)
    recovery = current.get("orphan_recovery") or {}
    if current["status"] != "interrupted" or not recovery.get("can_stop") or recovery.get("digest") != expected_digest:
        raise ValueError("This interrupted action's remaining processes changed. Refresh their current state.")
    import heavy_runtime_queue as queue
    result = queue.stop_orphans(current["worker"], expected_digest=expected_digest, confirmed=True)
    _update(_path(root, actor_id, identifier), {"resource_state": "released",
        "process_recovery": {"stopped_at": _now(), **result},
        "progress": "The ended action's remaining processes were stopped. Inspect its saved workflow evidence before retrying."},
        only_status={"interrupted"})
    return result


def _owned_history(root, actor_id, *, action=None, job_key=None):
    """Admission sees this owner's pending work even after access narrows.

    Callers must separately filter visibility; hidden job details never become
    a user response merely because they still block duplicate execution.
    """
    rows = []
    for path in _directory(root, actor_id).glob("*.json"):
        try:
            stored = _read(path)
            value = read(root, actor_id, path.stem, allowed_packs=stored["allowed_packs"])
            if (action is None or value["action"] == action) and (job_key is None or value["job_key"] == job_key):
                rows.append(value)
        except (ValueError, OSError):
            continue
    return sorted(rows, key=lambda row: row["created_at"], reverse=True)


def recent(root, actor_id, *, action=None, job_key=None, allowed_packs=None):
    return [row for row in _owned_history(root, actor_id, action=action, job_key=job_key)
            if all(pack in (allowed_packs or []) for pack in row["allowed_packs"])][:20]


def retry_guidance(root, value):
    """An exact retry cannot silently adopt a newly written workflow version."""
    action, args, result = value["action"], value["arguments"], value.get("result") or {}
    if action == "new_product_apply":
        return {"allowed": False, "reason": "Review the retained setup result, then Preview the plan again before explicitly requesting Write. Product creation never retries automatically."}
    if action == "implementation_runtime" and result.get("receipt"):
        return {"allowed": False, "reason": "This request already has a final runtime result. Review it and prepare a new runtime preview to execute again."}
    if action == "correction_comparison" and result.get("id"):
        return {"allowed": False, "reason": "This comparison has a retained result. Review it and prepare a new comparison preview to execute again."}
    if action == "conversation_evaluation":
        return {"allowed": False, "reason": "Review the retained conversation results. Prepare a new preview to request another run; interrupted model calls are never replayed automatically."}
    if action in {"correction_check", "durable_apply", "durable_prepare"}:
        try:
            import workflow_skills
            row = workflow_skills.learning().read_correction(root, args["record_id"])
            if row["digest"] == args["expected_digest"] and row["status"] not in {"retired", "withdrawn"}:
                return {"allowed": True, "reason": "Review the unchanged saved request before retrying."}
        except (ValueError, OSError, KeyError):
            pass
        next_action = {"correction_check": "Run linked checks", "durable_apply": "Apply reviewed change",
                       "durable_prepare": "Prepare fix with assistant"}[action]
        return {"allowed": False, "reason": "The lesson changed after this request. Review its current record below and use " + next_action + " with its current confirmation; the earlier attempt remains in history."}
    return {"allowed": True, "reason": "Review the saved request before retrying."}


def start(root, actor_id, *, action, arguments, job_key, confirmed=False,
          can_write=False, allowed_packs=None, retry=False):
    """Start once; an explicit retry creates a separate attempt and retains history."""
    import local_process_lock as locks
    if not (confirmed is True and can_write is True) or not isinstance(action, str) or action not in ACTIONS:
        raise ValueError("Review and explicitly request this local action with editing access.")
    try:
        argument_size = len(json.dumps(arguments, allow_nan=False).encode())
    except (TypeError, ValueError, RecursionError):
        raise ValueError("Use bounded JSON-compatible reviewed action inputs.") from None
    if (not isinstance(arguments, dict) or any(k in arguments for k in ("root", "actor_id", "allowed_packs")) or
            argument_size > 256_000 or
            not isinstance(job_key, str) or not 1 <= len(job_key) <= 300):
        raise ValueError("Choose the current bounded action and its reviewed inputs.")
    root = Path(root).resolve(strict=True)
    if allowed_packs is not None and (not isinstance(allowed_packs, (list, tuple)) or
            any(not isinstance(pack, str) for pack in allowed_packs)):
        raise ValueError("Use canonical product access for the saved action.")
    allowed = sorted(set(allowed_packs or []))
    if any(not isinstance(pack, str) or not re.fullmatch(r"(products|fixtures)/[A-Za-z0-9_/-]+", pack) or ".." in pack for pack in allowed):
        raise ValueError("Use canonical product access for the saved action.")
    directory = _directory(root, actor_id, for_start=True)
    request_hash = _hash({"action": action, "arguments": arguments, "allowed": allowed, "key": job_key})
    with locks.locked(directory / "admission.lock", directory):
        owned = _owned_history(root, actor_id, action=action, job_key=job_key)
        active = [row for row in owned if row["status"] in {"queued", "running"}]
        if active:
            if len(active) != 1 or active[0]["request_hash"] != request_hash:
                raise ValueError("A previous action is still running. Finish it before starting another request; if access changed, restore access to review or cancel it.")
            _scope(active[0], root, actor_id, allowed)
            return active[0]
        previous = [row for row in owned if all(pack in allowed for pack in row["allowed_packs"])]
        if previous:
            last = previous[0]
            if last["request_hash"] == request_hash and (not retry or last["status"] == "completed"):
                return last
            if last["request_hash"] == request_hash and retry:
                guidance = retry_guidance(root, last)
                if not guidance["allowed"]:
                    raise ValueError(guidance["reason"])
        import scientific_definition_ai as ai
        value = {
            "schema": 1, "id": uuid.uuid4().hex[:24], "root": str(root), "actor": actor_id,
            "action": action, "arguments": arguments, "allowed_packs": allowed,
            "job_key": job_key, "request_hash": request_hash, "created_at": _now(), "updated_at": _now(),
            "status": "queued", "progress": "Starting the reviewed action.", "worker": None,
            "launcher": locks.process_identity(), "provider": ai.selected_provider(),
            "cancel_requested": False, "cancel_observed": False, "result": None,
            "previous_attempt": previous[0]["id"] if previous else None,
        }
        path = _path(root, actor_id, value["id"])
        _write(path, value)
        command = [sys.executable, str(Path(__file__).resolve()), "--job", str(path)]
        options = ({"creationflags": subprocess.CREATE_NEW_PROCESS_GROUP | subprocess.CREATE_NO_WINDOW}
                   if os.name == "nt" else {"start_new_session": True})
        try:
            process = _spawn(command, cwd=str(root), stdin=subprocess.DEVNULL,
                stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, env=dict(os.environ, PYTHONUTF8="1"), **options)
            try:
                owner = locks.process_identity(process.pid)
            except (OSError, ValueError):
                owner = None
            if owner:
                _update(path, {"worker": owner}, only_status={"queued"})
            elif process.poll() is not None:
                _update(path, {"status": "failed", "progress": "The worker ended during startup. Check the local Python installation and explicitly retry."}, only_status={"queued"})
        except OSError:
            _update(path, {"status": "failed", "progress": "The worker could not start. Check the local Python installation and explicitly retry."})
        return _read(path)


def cancel(root, actor_id, identifier, *, confirmed=False, can_write=False, allowed_packs=None):
    if not (confirmed is True and can_write is True):
        raise ValueError("Explicitly request cancellation with local editing access.")
    value = read(root, actor_id, identifier, allowed_packs=allowed_packs)
    if value["status"] in TERMINAL:
        return value
    if value["action"] == "new_product_apply":
        raise ValueError("Product creation must finish its staged validation or rollback safely. Review its retained result when it finishes; cancelling a transactional write is unavailable.")
    return _update(_path(root, actor_id, identifier), {
        "cancel_requested": True,
        "progress": "Cancellation requested. The current bounded operation will stop or finish safely before any retry.",
    }, only_status={"queued", "running"})


def _dispatch(value):
    root, actor = value["root"], value["actor"]
    args = dict(value["arguments"], allowed_packs=value["allowed_packs"])
    action = value["action"]
    if action == "new_product_apply":
        import new_product_job
        return new_product_job.execute(root, actor, **args)
    if action == "implementation_runtime":
        import pattern_workspace
        pack = args.pop("pack")
        return pattern_workspace.run_runtime(root, pack, actor, **args)
    if action == "correction_comparison":
        import correction_evaluation
        pack = args.pop("pack")
        return correction_evaluation.run(root, pack, actor, **args)
    if action == "conversation_evaluation":
        import conversation_evaluation
        pack = args.pop("pack")
        return conversation_evaluation.run(root, pack, actor, **args)
    if action == "correction_check":
        import workflow_improvement
        allowed = args.pop("allowed_packs")
        loop = workflow_improvement.workflow_skills.learning()
        record = loop.read_correction(root, args["record_id"])
        scope = loop._scope_value(record.get("scope"))
        if scope["kind"] == "packs" and any(pack not in allowed for pack in scope["packs"]):
            raise ValueError("This correction includes an inaccessible product.")
        checked = workflow_improvement.check(root, actor, **args)
        return {"ok": bool((checked.get("check") or {}).get("passed")), "record": checked, "changed": True}
    if action in {"durable_prepare", "durable_apply"}:
        import workflow_durable_fixes
        fn = workflow_durable_fixes.prepare if action == "durable_prepare" else workflow_durable_fixes.apply
        if action == "durable_prepare":
            args["cancelled"] = portal_runtime.job_cancelled
        return fn(root, actor, **args)
    if action == "runtime_prerequisites":
        import implementation_runtime
        return {"ok": True, "runtime": implementation_runtime.prerequisites(), "changed": False}
    raise ValueError("Unsupported local action.")


def _worker(path):
    import local_process_lock as locks
    value = _read(path)
    if _path(value["root"], value["actor"], value["id"]) != path.resolve():
        raise ValueError("Worker request is outside its canonical private directory.")
    with locks.locked(path.with_suffix(".worker.lock"), path.parent):
        value = _read(path)
        if value["status"] in TERMINAL:
            return
        _update(path, {"worker": locks.process_identity(), "status": "running", "progress": ACTIONS[value["action"]]})
        stop = threading.Event()

        def cancelled():
            current = _read(path)
            if current["cancel_requested"]:
                if not current["cancel_observed"]:
                    _update(path, {"cancel_observed": True})
                return True
            return False

        def progress(message):
            _update(path, {"progress": str(message)[:240]})

        def heartbeat():
            while not stop.wait(3):
                try:
                    _update(path, {"heartbeat_at": _now()})
                except (OSError, ValueError):
                    return

        heartbeat_thread = threading.Thread(target=heartbeat, daemon=True)
        heartbeat_thread.start()
        callbacks_token = portal_runtime.job_callbacks(cancelled, progress)
        import scientific_definition_ai as ai
        previous_provider = ai._PROVIDER_SELECTION.get()
        ai.set_provider_selection(value.get("provider") or "")
        try:
            if cancelled():
                result = {"ok": False, "changed": False, "errors": ["Cancelled before execution."]}
            elif value["action"] in HEAVY_ACTIONS:
                import heavy_runtime_queue as queue
                try:
                    with queue.lease(
                            on_wait=lambda: _update(path, {"resource_state": "waiting"}),
                            on_acquired=lambda: _update(path, {"resource_state": "running"})):
                        result = _dispatch(value)
                except queue.Cancelled:
                    _update(path, {"cancel_observed": True})
                    result = {"ok": False, "changed": False, "errors": ["Cancelled while queued; this action did not execute."]}
            else:
                result = _dispatch(value)
            current = _read(path)
            status = "completed" if isinstance(result, dict) and result.get("ok") else "failed"
            if current["cancel_observed"]:
                status = "cancelled"
            _update(path, {"status": status, "result": result, "resource_state": "released",
                "progress": "Action finished. Inspect its retained results." if status == "completed" else
                "Action stopped. Inspect the recorded result and current workflow before an explicit retry."})
        except Exception:
            _update(path, {"status": "cancelled" if _read(path)["cancel_observed"] else "failed",
                "progress": "The action did not finish. The workflow journal is retained; inspect it before retrying.",
                "result": {"ok": False, "errors": ["The current action or its reviewed inputs could not be completed."]}})
        finally:
            stop.set()
            heartbeat_thread.join(timeout=4)
            portal_runtime.reset_job_callbacks(callbacks_token)
            ai.set_provider_selection(previous_provider)


if __name__ == "__main__":
    if len(sys.argv) != 3 or sys.argv[1] != "--job":
        raise SystemExit(2)
    code_root = Path(__file__).resolve().parents[2]
    sys.path[:0] = [str(code_root / "platform/tools"), str(code_root / "platform"), str(code_root / "experiments/agent")]
    _worker(Path(sys.argv[2]).resolve())
