"""Read the existing naming registry for a scoped, explicit output-name choice."""
from pathlib import Path
from contextlib import contextmanager
import re
import tempfile
import yaml

import naming_registry as names
import specification_details as details


def _safe(path):
    if path.resolve() != path:
        raise details._Invalid("A naming input redirects to another location. Ask the data expert to repair it before using this lookup.")
    return path


def _search_terms(source_label, query):
    """Literal wording and identifiers only; never infer a clinical synonym."""
    if query is not None:
        return [str(query).strip().lower()] if str(query).strip() else []
    label = str(source_label).strip().lower()
    identifiers = re.findall(r"\(([a-z][a-z0-9_]*)\)", label)
    words = [word for word in re.findall(r"[a-z][a-z0-9_]*", label)
             if len(word) >= 3 and word not in {"the", "and", "for", "with", "from", "per"}]
    return list(dict.fromkeys([label, *identifiers, re.sub(r"[^a-z0-9]+", "_", label).strip("_"), *words]))


def _prior_definitions(staged, scope):
    """Use the existing rule reader on the same access-scoped metadata snapshot."""
    import rule_review
    result = {}
    for pack in sorted(scope):
        contract = staged / pack / "handoff/FUNCTIONAL_CONTRACT.md"
        if not contract.is_file():
            continue
        for block in names.cl.records(names.cl.read(str(contract))):
            output = names.cl._inline(block, "output")
            name = (names.cl._kv(output, "physical_name") or "").lower()
            if name:
                result.setdefault(name, []).append({
                    "pack": pack, "variable_id": rule_review._field(block, "variable_id"),
                    "rule": rule_review._field(block, "derivation"),
                    "requirement": rule_review._field(block, "required_rule"),
                    "status": rule_review._field(block, "status"),
                    "spec_refs": names.cl._list(block, "spec_refs") or [],
                    "answers": [{"Question": label, "Recorded answer": rule_review._field(block, field) or "Not recorded"}
                                for label, field in rule_review.REVIEW_ORDER],
                })
    return result


@contextmanager
def _scoped_registry_root(root, scope):
    """The unchanged registry sees only canonical, permitted metadata snapshots."""
    from config import merged_raw
    with tempfile.TemporaryDirectory(prefix="definition-names-") as directory:
        staged = Path(directory).resolve()
        for pack in sorted(scope):
            source, pack = details._paths(root, pack, scope)
            product, target = source.parent, staged / pack
            candidates = []
            for folder in ("config", "variables", "codelists"):
                base = _safe(product / folder)
                if base.is_dir():
                    for file in base.rglob("*"):
                        _safe(file)
                        if file.is_file() and file.suffix.lower() in {".yaml", ".yml"}:
                            candidates.append(file)
            contract = _safe(product / "handoff/FUNCTIONAL_CONTRACT.md")
            if contract.is_file():
                candidates.append(contract)
            for file in candidates:
                if file.stat().st_size > 4 * 1024 * 1024:
                    raise details._Invalid("A naming input exceeds the metadata lookup limit.")
                raw = file.read_bytes()
                _safe(file)
                destination = target / file.relative_to(product)
                destination.parent.mkdir(parents=True, exist_ok=True)
                destination.write_bytes(raw)
            config = target / "config/data_product.yaml"
            if config.is_file():
                try:
                    raw = merged_raw(config)
                except (yaml.YAMLError, ValueError, TypeError, AttributeError):
                    # The canonical registry retains contract names even when
                    # this pack's configuration cannot describe its outputs.
                    continue
                references = [*(raw.get("variables") or []), *(raw.get("codelists") or {}).values()]
                for reference in references:
                    if not isinstance(reference, str):
                        raise details._Invalid("A configured naming input needs a declared local metadata path.")
                    candidate = target / reference
                    if candidate.resolve() != candidate or not candidate.is_relative_to(target):
                        raise details._Invalid("A naming input references metadata outside its product. Ask the data expert to review it.")
        yield staged


def describe(root, pack, source_label, *, query=None, allowed_packs=None):
    """Offer recorded names, never decide concept identity or create a naming ruling."""
    try:
        path, pack = details._paths(root, pack, allowed_packs)
        root = Path(root).resolve()
        scope = set(allowed_packs) if allowed_packs is not None else {pack}
        scope.add(pack)
        from config import load_config
        import validate as engine_validate
        with _scoped_registry_root(root, scope) as staged:
            registry = names.registry(str(staged))
            prior = _prior_definitions(staged, scope)
            try:
                emitted = {str(value).lower() for value in engine_validate.emitted_variables(load_config(str(staged / pack / "config/data_product.yaml")))}
                config_problem = ""
            except (OSError, ValueError, TypeError, KeyError, yaml.YAMLError, AttributeError):
                emitted = set()
                config_problem = "The current configuration could not supply output names. Registered contract names are still shown."
        ruling_review = names.ruling_review(str(_safe(root / "governance/NAMING_RULINGS.yaml")))
        rulings, ruling_problems = ruling_review["current"], ruling_review["problems"]
        lifecycle, lifecycle_problems = names.lifecycle(str(_safe(root / "governance/NAME_LIFECYCLE.yaml")))
        searches = _search_terms(source_label, query)
        candidates = []
        for name in sorted(set(registry) | emitted):
            if not re.fullmatch(r"[a-z][a-z0-9_]{0,79}", name) or name in {"todo", "tbd", "none"}:
                continue
            record = registry.get(name) or {}
            packs = {p: state for p, state in (record.get("packs") or {}).items() if p in scope}
            if not packs and name not in emitted:
                continue
            ids = set(record.get("variable_ids") or [])
            match = ("Exact name" if name in searches else "Recorded specification identifier" if set(searches) & {str(v).lower() for v in ids}
                     else "Similar spelling" if any(names._near(search, name) for search in searches)
                     else "Name contains search text" if any(search in name for search in searches) else "")
            if searches and not match:
                continue
            related = [{key: ruling.get(key) for key in ("a", "b", "ruling", "standard", "decision_id")}
                       for ruling in rulings if name in {str(ruling.get("a")).lower(), str(ruling.get("b")).lower()}
                       and (not searches or set(searches) & {str(ruling.get("a")).lower(), str(ruling.get("b")).lower(), name})]
            retired = next((entry for entry in lifecycle if str(entry.get("name") or "").lower() == name and entry.get("status") == "deprecated"), None)
            types = sorted(kind for kind, owners in (record.get("types") or {}).items() if set(owners) & scope)
            candidates.append({"name": name, "match": match or "Visible registered name",
                               "basis": "Current configured output" if name in emitted else "Accessible functional contract",
                               "types": types, "name_states": packs, "variable_ids": sorted(ids),
                               "rulings": related, "retired": bool(retired), "successor": (retired or {}).get("replaced_by", ""),
                               "naming_conflict": any(names._strip_twin(name) in conflict["family"] for conflict in ruling_review["conflicts"]),
                               "definitions": prior.get(name, [])})
        priority = {"Exact name": 0, "Recorded specification identifier": 1, "Similar spelling": 2}
        candidates.sort(key=lambda item: (priority.get(item["match"], 3), item["name"]))
        visible = {row["name"] for row in candidates}
        conflicts = [conflict for conflict in ruling_review["conflicts"] if any(names._strip_twin(name) in conflict["family"] for name in visible)]
        return {"ok": True, "candidates": candidates, "errors": [], "conflicts": conflicts,
                "naming_history": [item for item in ruling_review["history"] if any(names._strip_twin(name) in item["family"] for name in visible)],
                "warnings": ([config_problem] if config_problem else []) + ruling_problems + lifecycle_problems}
    except (details._Invalid, OSError, ValueError, TypeError, KeyError, AttributeError, yaml.YAMLError) as error:
        return {"ok": False, "candidates": [], "errors": [str(error)], "warnings": []}


def preview_resolution(root, pack, actor_id, *, references, a, b, ruling, standard, reason, decision_id,
                       allowed_packs=None):
    """Review an explicit supersession in the existing shared register, never a rename."""
    import hashlib
    import difflib
    from datetime import date
    import workflow_improvement as improvement
    improvement._author(actor_id)
    details._paths(root, pack, allowed_packs)
    if (not isinstance(references, list) or not references or len(references) > 100
            or any(not isinstance(ref, str) for ref in references)):
        raise ValueError("Select the exact current naming references before reviewing a replacement.")
    root = Path(root).resolve()
    path = _safe(root / "governance/NAMING_RULINGS.yaml")
    if not path.is_file() or path.stat().st_size > 512_000:
        raise ValueError("Restore the bounded naming register before reviewing a resolution.")
    before = path.read_text(encoding="utf-8")
    doc = yaml.safe_load(before)
    review = names.review_rulings(doc)
    conflict = next((item for item in review["conflicts"] if set(item["references"]) == set(references)
                     and names.ruling_family(a, b) == tuple(item["family"])), None)
    if not conflict or len(references) != len(set(references)):
        raise ValueError("Select every current conflicting reference for this naming family; refresh if a decision changed.")
    visible = describe(root, pack, "", query="", allowed_packs=allowed_packs)
    if not any(set(item["references"]) == set(references) for item in visible.get("conflicts", [])):
        raise ValueError("This conflict is not available in the current product scope.")
    if not isinstance(reason, str) or not 10 <= len(reason.strip()) <= 1800 or not str(decision_id).strip():
        raise ValueError("Explain the reviewed naming decision and supply its review reference.")
    entry = {"a": str(a).strip().lower(), "b": str(b).strip().lower(), "ruling": ruling,
        "ruled_by": actor_id, "ruling_date": date.today().isoformat(), "decision_id": str(decision_id).strip(),
        "note": reason.strip(), "supersedes": sorted(references)}
    if ruling == "use_existing":
        entry["standard"] = str(standard).strip().lower()
    import workflow_skills
    workflow_skills.learning()._ingress(workflow_skills.learning()._plain(entry))
    revised = {**doc, "rulings": [*doc["rulings"], entry]}
    checked = names.review_rulings(revised)
    if entry not in checked["current"] or any(names.ruling_family(a, b) == tuple(item["family"]) for item in checked["conflicts"]):
        raise ValueError("The replacement remains ambiguous or invalid: " + "; ".join(checked["problems"]))
    after = yaml.safe_dump(revised, sort_keys=False, allow_unicode=True)
    return {"path": "governance/NAMING_RULINGS.yaml", "before": before, "after": after,
        "before_sha256": hashlib.sha256(before.encode()).hexdigest(), "entry": entry,
        "diff": "".join(difflib.unified_diff(before.splitlines(True), after.splitlines(True), "NAMING_RULINGS.yaml", "NAMING_RULINGS.yaml (proposed)"))}


def apply_resolution(root, pack, actor_id, *, proposal, confirmed=False, can_write=False, allowed_packs=None):
    import workflow_improvement as improvement
    import delivery_binding
    improvement._permission(actor_id, can_write, confirmed)
    entry = proposal["entry"]
    current = preview_resolution(root, pack, actor_id, references=entry["supersedes"], a=entry["a"], b=entry["b"],
        ruling=entry["ruling"], standard=entry.get("standard", ""), reason=entry["note"], decision_id=entry["decision_id"], allowed_packs=allowed_packs)
    if current != proposal:
        raise ValueError("The naming register, reviewed decision or local identity changed. Preview the current resolution again.")
    delivery_binding._replace_files(Path(root).resolve(), [{key: current[key] for key in ("path", "before", "after", "before_sha256")}])
    return {"ok": True, "changed": True, "notice": "Reviewed naming supersession saved on this branch. Historical rulings remain; no column was renamed and no scientific approval was authenticated."}
