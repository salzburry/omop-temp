"""Explicit source-column pairs with known metadata choices and custom recovery."""
from __future__ import annotations

import streamlit as st

import variable_review_controls as controls


def _chosen(value):
    return isinstance(value, str) and value.strip().casefold() not in {
        "", "todo", "tbd", "replace_me", "undecided", "none", "n/a"}


def render_columns(current, *, key, roles, columns, disabled=False):
    """Return completed mappings and actionable errors without dropping typed pairs."""
    current = current if isinstance(current, dict) else {}
    roles = roles if isinstance(roles, dict) else {str(value): value for value in roles}
    columns = columns if isinstance(columns, dict) else {str(value): value for value in columns}
    state_key = key + "_mapping_rows"
    if state_key not in st.session_state:
        st.session_state[state_key] = [
            {"id": index, "role": role, "column": value}
            for index, (role, value) in enumerate(current.items())
        ] or [{"id": 0, "role": "", "column": ""}]
    rows = st.session_state[state_key]
    next_key = key + "_mapping_next"
    if next_key not in st.session_state:
        st.session_state[next_key] = max(row["id"] for row in rows) + 1 if rows else 0
    result, errors = {}, []
    st.write("**Source columns**")
    for number, row in enumerate(rows, 1):
        pair_key = key + "_pair_" + str(row["id"])
        left, right, remove = st.columns([3, 3, 1])
        with left:
            role = controls.render_choice("Column role " + str(number), row["role"], roles,
                key=pair_key + "_role", disabled=disabled)
        with right:
            column = controls.render_choice("Source column " + str(number), row["column"], columns,
                key=pair_key + "_column", disabled=disabled)
        with remove:
            if st.button("Remove", key=pair_key + "_remove", disabled=disabled,
                         help="Remove this column mapping from the draft."):
                st.session_state[state_key] = [entry for entry in rows if entry["id"] != row["id"]]
                st.rerun()
        if not role and not column:
            continue
        if not _chosen(role) or not _chosen(column):
            errors.append(f"Column mapping {number}: choose both a role and a source column.")
        elif role in result:
            errors.append(f"Column role '{role}' is repeated. Keep one mapping for each role.")
        else:
            result[role] = column
    if st.button("Add source column", key=key + "_mapping_add", disabled=disabled):
        rows.append({"id": st.session_state[next_key], "role": "", "column": ""})
        st.session_state[next_key] += 1
        st.rerun()
    return result, errors
