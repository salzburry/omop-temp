"""Three compact, inspectable prior examples beside the current conversation."""
from __future__ import annotations

import streamlit as st

import conversation_examples as examples
import form_assistance as forms


def _feedback_route(card):
    import workflow_skills
    route = ((card or {}).get("current_task") or {}).get("route") or ((card or {}).get("next_step") or {}).get("action_id") or "progress"
    try:
        workflow_skills.binding_for(route)
    except workflow_skills.Invalid:
        route = "progress"
    return route


def render(root, pack, *, question, actor_id, allowed_packs, card=None, key="conversation_examples_", can_write=False):
    if not str(question or "").strip():
        return None
    setup = isinstance((card or {}).get("setup_form"), dict)
    public = forms.context(question)
    # Widget state is scoped to the actor, checkout, product and exact form. A
    # changed question also starts a fresh explicit other-product selection.
    prefix = key + forms.digest([str(root), pack, actor_id, sorted(allowed_packs or []),
                                 question, (public or {}).get("scope")])[:20] + "_"
    try:
        rows = examples.search(root, pack, question=question, actor_id=actor_id,
                               allowed_packs=allowed_packs, public=public, setup=setup)
        choices = examples.scope_choices(root, allowed_packs=allowed_packs, question=question)
    except (OSError, ValueError, TypeError, KeyError):
        st.caption("Prior examples could not be read. Your current conversation and draft remain available.")
        return None
    if not rows and not choices:
        st.caption("No matching shared example is available yet. Reviewed concepts can be added through Shared-library reuse; a prior RDQ must be reviewed and made accessible before other users can reuse it.")
        return None
    with st.expander("Examples you can reuse", expanded=bool(rows)):
        selected_pack = None
        if choices:
            related = [row["label"] for row in choices if row["matching_terms"]][:3]
            if related:
                st.caption("Related catalogue entries: " + "; ".join(related) + ". Choose one to inspect its examples.")
            labels = {row["pack"]: row["label"] for row in choices}
            selected_pack = st.selectbox("Look at another product or reference" if pack else "Choose a product or reference to learn from",
                [None] + list(labels), format_func=lambda value: "Keep this product's scope" if value is None and pack else
                "Choose a starting example" if value is None else labels[value], key=prefix + "scope",
                help="This expands personal request search to the chosen authorized product. Reviewed shared-library concepts are available across authors when their source evidence is accessible. Private requests stay with their author.")
            if selected_pack:
                rows = examples.search(root, pack, question=question, actor_id=actor_id,
                    allowed_packs=allowed_packs, public=public, selected_pack=selected_pack, setup=setup)
        if not rows:
            st.caption("No matching checked requests or reviewed shared concepts in this scope. Keep your checked request for personal reuse, or use Shared-library reuse to prepare reviewed concepts for other researchers.")
        for row in rows:
            row_key = prefix + forms.digest([row["id"], row["digest"]])[:20] + "_"
            st.write("**" + row["title"] + "**")
            st.caption(row["match"])
            for difference in row["differences"]:
                st.caption(difference)
            with st.expander("Read the example"):
                for field in row["summary"]:
                    st.text(field["label"] + ": " + field["value"])
            with st.expander("Source and version · " + row["version"]):
                st.text(row["source"])
                st.text("Product: " + row["pack"])
                st.text("Record SHA-256: " + row["digest"])
                if row["run_id"]:
                    st.text("Checked run: " + row["run_id"])
                if row.get("provenance"):
                    st.json(row["provenance"])
            if not row["changes"]:
                st.caption("This example has no reusable fields in the current form.")
                continue
            labels = {change["id"]: change["label"] for change in row["changes"]}
            chosen = st.multiselect("Fields to reuse", list(labels), default=[], format_func=labels.get,
                key=row_key + "fields", disabled=not can_write or not public)
            selected = [change for change in row["changes"] if change["id"] in chosen]
            if selected:
                st.dataframe([{"Field": item["label"], "Current": item["before"], "From example": item["value"]}
                              for item in selected], hide_index=True)
            if st.button("Use reviewed example fields", key=row_key + "use",
                         disabled=not can_write or not selected or not public):
                try:
                    proposal = examples.prepare(root, pack, example_id=row["id"], expected_digest=row["digest"],
                        field_ids=chosen, question=question, actor_id=actor_id, allowed_packs=allowed_packs,
                        public=public, selected_pack=selected_pack, setup=setup)
                    forms.stage(proposal, public=public,
                        interaction={"id": forms.digest([row["id"], row["digest"], public["scope"]]),
                                     "request": str(question)[:4000], "route": _feedback_route(card)})
                    st.success("Example fields prepared for the existing draft review. Use the form's preview and save when ready.")
                    return proposal
                except ValueError as error:
                    st.warning(str(error))
    return None
