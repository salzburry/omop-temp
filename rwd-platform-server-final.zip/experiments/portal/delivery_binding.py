"""Reviewable source declarations using existing configuration and scientific checks.

This edits existing scalar delivery bindings only. A scaffold may retain identical
pre-existing scientific findings, which are displayed, never treated as a passed gate.
No source review, study rule, adapter, approval or runtime evidence is manufactured.
"""
from __future__ import annotations

from collections import Counter
import difflib
import json
import os
from pathlib import Path
import string
import tempfile

import yaml

import configuration_proposals as proposals
import source_workspace as workspace
from engine.refresh import unsafe_identifier
from engine import vendors, source_contract

ROUTE = "source_delivery"
NOTICE = "Saving declares a draft delivery. It does not establish table availability, source review, scientific approval or release."


def _at(document, keys):
    for key in keys:
        if not isinstance(document, dict) or key not in document:
            return None
        document = document[key]
    return document


def _describe(scope):
    root, product, pack = scope[:3]
    cfg, identity = workspace._identity(product)
    documents = {}
    for rel in ("config/data_product.yaml", "config/pipeline.yaml"):
        file = product / rel
        if file.exists():
            text = workspace._bytes(file).decode("utf-8")
            documents[rel] = (text, yaml.load(text, Loader=workspace.details._StrictLoader))
    blockers = []
    if cfg.source_union:
        blockers.append("This delivery combines source schemas. Engineering must declare each union member and its precedence; the single-delivery form cannot change it.")
    if (product / "config/source_adapters.yaml").exists():
        blockers.append("This product has source adapters. Review its delivered table and column bindings in Map delivered sources; changing table stems here could conflict with those bindings.")
    try:
        layout = vendors.layout_for(cfg.vendor, cfg.source_layout)
        tokens = list(string.Formatter().parse(layout))
        if any(field is not None and (field not in {"schema", "stem", "refresh"} or spec or conversion)
               for _, field, spec, conversion in tokens):
            raise ValueError
    except (KeyError, ValueError, TypeError):
        layout = str(cfg.source_layout or "")
        blockers.append("The table-name layout needs Engineering review before this form can resolve the physical names.")

    fields = {}
    def field(name, keys, label, kind):
        owners = [(rel, doc) for rel, (_, doc) in documents.items() if _at(doc, keys) is not None]
        if len(owners) != 1 or isinstance(_at(owners[0][1], keys), (dict, list, bool)):
            blockers.append(f"{label} is missing or ambiguous in the configuration. Ask Engineering to declare that scalar before using this form.")
            return
        rel, doc = owners[0]
        proposals._scalar_node(documents[rel][0], keys)
        fields[name] = {"path": rel, "keys": keys, "label": label, "kind": kind,
                        "value": str(_at(doc, keys))}
    field("schema", ["run", "source_schema"], "Source schema", "schema")
    field("cut", ["run", "refresh"], "Delivery cut", "sql")
    for role in sorted(cfg.sources):
        keys = (["formats", cfg.data_format, "sources", role]
                if role in (cfg._format_block.get("sources") or {}) else ["sources", role])
        field("source:" + role, keys, role + " table stem", "sql")
    rows, findings, contract_present = workspace.requirements.matrix(str(product))
    return {"ok": True, "supported": not blockers, "blockers": blockers, "fields": fields,
            "values": {name: item["value"] for name, item in fields.items()}, "layout": layout,
            "data_format": cfg.data_format, "identity": identity, "rows": rows, "findings": findings,
            "contract_present": contract_present, "engine_roles": source_contract.compiled(cfg)["roles"],
            "inputs_sha256": workspace._sha(workspace._inputs(root, product)),
            "notice": NOTICE}


@workspace._guard
def describe(root, pack, actor_id, *, allowed_packs=None):
    return _describe(workspace._scope(root, pack, actor_id, allowed_packs))


def _candidate(scope, values, expected_digest):
    root, product, pack = scope[:3]
    description = _describe(scope)
    if description["inputs_sha256"] != expected_digest:
        raise workspace.Invalid("The product or supporting policy changed. Reload the delivery form before staging these choices.")
    if not description["supported"]:
        raise workspace.Invalid(" ".join(description["blockers"]))
    fields = description["fields"]
    if not isinstance(values, dict) or set(values) != set(fields):
        raise workspace.Invalid("Keep the existing source roles and supply every displayed delivery field; adding or removing roles requires Engineering review.")
    for name, value in values.items():
        if not isinstance(value, str) or workspace._stem_unstated(value) or unsafe_identifier(fields[name]["kind"], value):
            raise workspace.Invalid(fields[name]["label"] + " needs an explicit identifier. Use letters, digits and underscores (cut and stem: at most 64 characters); the schema may contain one catalog separator. Do not paste a path or SQL statement.")
    files, edits = [], {}
    for name, item in fields.items():
        if values[name] != item["value"]:
            edits.setdefault(item["path"], []).append((item["keys"], values[name]))
    if not edits:
        raise workspace.Invalid("No delivery fields changed. Continue to evidence preparation for the current delivery.")
    for rel, changes in sorted(edits.items()):
        before = workspace._bytes(product / rel).decode("utf-8")
        replacements = []
        for keys, value in changes:
            node = proposals._scalar_node(before, keys)
            replacements.append((node.start_mark.index, node.end_mark.index, json.dumps(value, ensure_ascii=False)))
        after = before
        for start, end, value in sorted(replacements, reverse=True):
            after = after[:start] + value + after[end:]
        files.append({"path": rel, "before": before, "before_sha256": workspace._sha(before.encode()), "after": after,
                      "diff": "".join(difflib.unified_diff(before.splitlines(True), after.splitlines(True),
                                                        fromfile=rel + " (current)", tofile=rel + " (draft)"))})

    impact = []
    rows = {row["role"]: row for row in description["rows"]}
    for name in fields:
        if not name.startswith("source:"):
            continue
        role = name.split(":", 1)[1]
        current = description["values"]
        before = description["layout"].format(schema=current["schema"], stem=current[name], refresh=current["cut"])
        after = description["layout"].format(schema=values["schema"], stem=values[name], refresh=values["cut"])
        if unsafe_identifier("dotted", after):
            raise workspace.Invalid("The resolved table name for " + role + " is not supported. Engineering must review the existing table-name layout.")
        if before != after:
            row = rows.get(role, {})
            impact.append({"role": role, "before": before, "after": after,
                           "engine_reads": bool(description["engine_roles"].get(role, {}).get("engine_reads")),
                           "required_columns": row.get("required_columns", []),
                           "expected_grain": row.get("expected_grain", ""),
                           "when_absent": row.get("when_absent", ""),
                           "read_by_blocks": row.get("read_by_blocks", []),
                           "required_by_variables": row.get("required_by_variables", [])})
    baseline = proposals.validate_files(root, product, pack, [])
    checks = proposals.validate_files(root, product, pack, files)
    previous = {check["validator"]: Counter(check["errors"]) for check in baseline}
    new_errors = []
    for check in checks:
        if check.get("completed") is False:
            new_errors.append(check["validator"] + ": the validator did not complete.")
        extra = Counter(check["errors"]) - previous.get(check["validator"], Counter())
        # An exception is never an eligible pre-existing scientific finding.
        exceptions = [error for error in check["errors"] if "Error:" in error or "Exception:" in error]
        new_errors.extend(check["validator"] + ": " + error for error in set(extra) | set(exceptions))
    return {"values": values, "files": files, "impact": impact, "checks": checks, "baseline_checks": baseline,
            "new_errors": sorted(new_errors), "can_save": not new_errors,
            "all_checks_passed": all(check["passed"] and check.get("completed") is not False for check in checks),
            "consumer_links_complete": bool(description["contract_present"]) and bool(impact) and all(row["required_by_variables"] for row in impact),
            "summary": "Delivery declaration staged for review. Existing scientific findings remain open; fresh delivery evidence is required after saving."}


@workspace._guard
def stage(root, pack, actor_id, *, values, expected_digest, local_demo=False, can_write=False, allowed_packs=None):
    workspace._authorized(local_demo, can_write)
    scope = workspace._scope(root, pack, actor_id, allowed_packs)
    payload = _candidate(scope, values, expected_digest)
    record = workspace._new(scope, ROUTE, "Review the source delivery declaration",
                            "checked_draft" if payload["can_save"] else "needs_changes", payload,
                            expected_digest=expected_digest)
    return {"ok": True, "record": record}


def _temporary_bytes(directory, raw):
    temporary = None
    try:
        with tempfile.NamedTemporaryFile(dir=directory, delete=False) as handle:
            temporary = Path(handle.name)
            handle.write(raw)
        return temporary
    except BaseException:
        if temporary is not None:
            temporary.unlink(missing_ok=True)
        raise


def _replace_files(product, files):
    """Prepare both replacements before mutation; rollback our own bytes on partial failure."""
    prepared, written = [], []
    try:
        for item in files:
            target = workspace._safe(product / item["path"])
            if workspace._sha(workspace._bytes(target)) != item["before_sha256"]:
                raise workspace.Invalid("A delivery file changed after review. Nothing further was saved; reload the form.")
            temporary = _temporary_bytes(target.parent, item["after"].encode())
            prepared.append((temporary, target, item))
        for temporary, target, item in prepared:
            if workspace._sha(workspace._bytes(target)) != item["before_sha256"]:
                raise workspace.Invalid("A delivery file changed while saving. Reload the form.")
            os.replace(temporary, target)
            written.append((target, item))
    except BaseException:
        for target, item in reversed(written):
            if workspace._bytes(target) == item["after"].encode():
                restore = _temporary_bytes(target.parent, item["before"].encode())
                try:
                    os.replace(restore, target)
                finally:
                    restore.unlink(missing_ok=True)
        raise
    finally:
        for temporary, _, _ in prepared:
            temporary.unlink(missing_ok=True)


@workspace._guard
def save(root, pack, actor_id, *, record_id, confirmed=False, local_demo=False, can_write=False, allowed_packs=None):
    workspace._authorized(local_demo, can_write)
    if confirmed is not True:
        raise workspace.Invalid("Review the staged diff and unresolved findings, then confirm the draft save.")
    scope = workspace._scope(root, pack, actor_id, allowed_packs)
    record = workspace._load(scope, record_id)
    if record["route"] != ROUTE or record["state"] != "checked_draft":
        raise workspace.Invalid("Stage and validate an editable delivery proposal before saving.")
    workspace._fresh(scope, record)
    payload = _candidate(scope, record["payload"]["values"], record["inputs_sha256"])
    if not payload["can_save"] or payload != record["payload"]:
        raise workspace.Invalid("The proposal or validator findings changed. Stage and review it again before saving.")
    workspace._fresh(scope, record)
    _replace_files(scope[1], payload["files"])
    record["state"] = "delivery_saved_pending_review"
    record["payload"]["summary"] = "Draft delivery saved. Prepare fresh delivery evidence, then complete source and scientific review. No approval or release was recorded."
    try:
        record["inputs_sha256"] = workspace._sha(workspace._inputs(scope[0], scope[1]))
        record["updated_at"] = workspace.datetime.now(workspace.timezone.utc).isoformat()
        workspace._write(scope[-1], record)
    except (OSError, ValueError):
        return {"ok": True, "record": record, "changed": True,
                "warning": "The draft delivery files were saved, but their private activity record could not be updated. Prepare evidence against the current delivery. Do not resubmit the old proposal; ask Engineering to repair the private workspace storage."}
    return {"ok": True, "record": record, "changed": True}
