"""Thin local review/evaluation/activation UI backend over the existing learners."""
from __future__ import annotations
from datetime import datetime, timezone
import json
import os
from pathlib import Path
import subprocess
import sys
import uuid
import re

CODE = Path(__file__).resolve().parents[2]
sys.path[:0] = [str(CODE / 'experiments/agent'), str(CODE / 'experiments/agent/ml')]
import control_plane
import model_lifecycle_runtime as runtime
import state
import train_all
import specification_details as details

ROUTE = 'model_lifecycle'
CASE_OBJECTIVES = {'governed_orchestration_model', 'intake_elicitation_model'}
NOTICE = 'These are locally attributed technical learning records for this Git branch. They do not authenticate a person, approve scientific definitions or release a product.'


def _scope(root, pack, actor_id, allowed_packs):
    root = Path(root).resolve()
    _, pack = details._paths(root, pack, allowed_packs)
    if not runtime.PACK.fullmatch(pack) or not str(actor_id or '').strip():
        raise ValueError('Choose a working product and a local identity to review its checks. Reference and synthetic packs do not supply activation evidence.')
    runtime.safe_path(root, pack, 'labels')
    return root, pack


def _write(root, pack, kind, payload, *, allowed_packs=None):
    value = dict(payload, pack=pack, kind=kind)
    if value.get('record_type') == 'canonical_case_evaluation':
        runtime.validate_case_scope(value, pack, allowed_packs)
    elif value.get('record_type') == 'correction_paired_evaluation':
        runtime.validate_paired_record(value, pack, allowed_packs)
    elif value.get('record_type') in {'reviewed_intake_case', 'reviewed_mapping_label', 'intake_case_evaluation', 'reviewed_mapping_evaluation'}:
        runtime.validate_reviewed_case_record(value, pack, kind, allowed_packs=allowed_packs)
    sha = runtime.digest(value)
    value.update(id=sha[:24], sha256=sha)
    path = runtime.safe_path(root, pack, kind, value['id'])
    if os.name == 'nt' and len(str(path)) > 235:
        raise ValueError('The checkout path is too long for this review record. Use a shorter local checkout path.')
    if path.exists():
        return runtime.read_record(root, pack, kind, value['id'], allowed_packs=allowed_packs)
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name('.' + uuid.uuid4().hex + '.tmp')
    try:
        tmp.write_text(json.dumps(value, indent=2, ensure_ascii=False, allow_nan=False) + '\n', encoding='utf-8')
        if path.exists():
            raise ValueError('A record with this exact identity was saved concurrently. Refresh the workspace.')
        os.rename(tmp, path)
    finally:
        if tmp.exists():
            tmp.unlink()
    return value


def _records(root, pack, kind, *, allowed_packs=None):
    out, invalid = [], 0
    directory = runtime.safe_path(root, pack, kind)
    paths = sorted(directory.glob('*.json'))
    if len(paths) > 300:
        raise ValueError('This product has more than 300 learning records in one category. Archive reviewed history before continuing.')
    for path in paths:
        try:
            out.append(runtime.read_record(root, pack, kind, path.stem, allowed_packs=allowed_packs))
        except runtime.CaseScopeError:
            continue  # Withhold the record, including its metadata and existence count.
        except (ValueError, OSError, KeyError, TypeError):
            invalid += 1
    return sorted(out, key=lambda x: x['created_at'], reverse=True), invalid


def _run(run_id, pack):
    if not state._RUN_ID.fullmatch(str(run_id)):
        raise ValueError('Choose a recorded check.')
    path = Path(state.RUNS).resolve() / (run_id + '.json')
    if path.resolve() != path or path.stat().st_size > 1_000_000:
        raise ValueError('The recorded check is unavailable or oversized.')
    run = json.loads(path.read_text(encoding='utf-8'))
    if run.get('run_id') != run_id:
        raise ValueError('The recorded check identity changed.')
    return runtime.checked_run(run, pack)


def _runs(pack):
    out = []
    paths = sorted(Path(state.RUNS).glob('*.json'), reverse=True)[:300]
    for path in paths:
        try:
            run = _run(path.stem, pack)
            out.append({'id': run['run_id'], 'goal': run['goal'], 'model': run['model_id'],
                        'provider': run['execution']['provider'], 'digest': runtime.digest(run)})
        except (ValueError, OSError, KeyError, TypeError):
            continue
    return out


def describe(root, pack, actor_id, *, allowed_packs=None):
    try:
        root, pack = _scope(root, pack, actor_id, allowed_packs)
        records = {}; invalid = 0
        for kind in ('labels', 'evaluations', 'activations'):
            records[kind], count = _records(root, pack, kind, allowed_packs=allowed_packs); invalid += count
        objectives = control_plane.objectives(str(root / 'governance/OBJECTIVES.yaml')).get('objectives', [])
        if (not isinstance(objectives, list) or not objectives or any(not isinstance(o, dict) or any(not o.get(k) for k in
                ('id', 'question', 'status', 'what_would_release_it', 'evaluation')) for o in objectives)):
            raise ValueError('The existing objective registry needs repair.')
        runs = _runs(pack)
        digest = runtime.digest({'code': runtime.code_digest(root), 'records': {k: [r['sha256'] for r in v] for k, v in records.items()},
                                 'runs': [(r['id'], r['digest']) for r in runs]})
        return {'ok': True, 'digest': digest, 'objectives': objectives, 'runs': runs, **records,
                'invalid_records': invalid, 'notice': NOTICE}
    except (ValueError, OSError, KeyError, TypeError, AttributeError):
        return {'ok': False, 'errors': ['The product, objective registry or learning records are unavailable within your access. Repair the product inputs before continuing.']}


def _fresh(root, pack, actor_id, expected_digest, allowed_packs):
    report = describe(root, pack, actor_id, allowed_packs=allowed_packs)
    if not report['ok'] or report['digest'] != expected_digest or report['invalid_records']:
        raise ValueError('The checks, review records or objective changed. Refresh and inspect the current records before saving.')
    return report


def _permission(local_demo, permission, confirmed):
    if not local_demo or not permission or confirmed is not True:
        raise ValueError('This save needs an authorised local reviewer and explicit confirmation of the displayed records.')


def preview_run(root, pack, actor_id, run_id, *, allowed_packs=None):
    _scope(root, pack, actor_id, allowed_packs)
    return _run(run_id, pack)


def save_label(root, pack, actor_id, run_id, objective_id, label, reviewed_by, reviewed_on, rationale, *,
               expected_digest, comparison_run_id=None, confirmed=False, local_demo=False, can_review=False, allowed_packs=None):
    _permission(local_demo, can_review, confirmed)
    root, pack = _scope(root, pack, actor_id, allowed_packs)
    report = _fresh(root, pack, actor_id, expected_digest, allowed_packs)
    import scientific_definition_ai as ai
    ai._ingress(' '.join([str(reviewed_by), str(reviewed_on), str(rationale)]))
    source = _run(run_id, pack)
    value = {'objective_id': objective_id, 'label': label, 'reviewed_by': reviewed_by,
             'reviewed_on': reviewed_on, 'rationale': str(rationale).strip(), 'confirmed_real_work': True,
             'recorded_by': actor_id, 'source': source, 'comparison': _run(comparison_run_id, pack) if comparison_run_id else None,
             'created_at': datetime.now(timezone.utc).isoformat(), 'notice': NOTICE}
    if len(value['rationale']) > 3000:
        raise ValueError('Keep the review rationale within 3,000 characters.')
    runtime.training_row(value, pack)
    prior = next((r for r in report['labels'] if r['objective_id'] == objective_id and (r.get('source') or {}).get('run_id') == run_id), None)
    value['supersedes'] = prior['id'] if prior else None
    _fresh(root, pack, actor_id, expected_digest, allowed_packs)
    return _write(root, pack, 'labels', value)


def _selected(report, objective_id):
    labels = []; seen = set()
    for record in report['labels']:
        if record['objective_id'] == objective_id and record['source']['run_id'] not in seen:
            seen.add(record['source']['run_id']); labels.append(record)
    return sorted(labels, key=lambda r: r['id'])


def _measure(rows, objective_id):
    # A separate bounded process uses the canonical trainer; no model/provider
    # calls and no potentially unbounded worker surviving a portal rerun.
    command = "import json,sys;sys.path.insert(0,sys.argv[1]);import train_all;v=json.load(sys.stdin);print(json.dumps(train_all.train_reviewed(v['rows'],v['objective_id']),allow_nan=False))"
    try:
        result = subprocess.run([sys.executable, '-c', command, str(CODE / 'experiments/agent/ml')],
            input=json.dumps({'rows': rows, 'objective_id': objective_id}), text=True, encoding='utf-8',
            capture_output=True, timeout=90, creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0))
        if result.returncode or len(result.stdout.encode()) > 100_000:
            raise ValueError('The canonical evaluation could not complete. Inspect the reviewed rows and retry explicitly.')
        return json.loads(result.stdout)
    except (subprocess.TimeoutExpired, json.JSONDecodeError):
        raise ValueError('The bounded evaluation did not finish. Reduce the review batch and retry explicitly; nothing was activated.') from None


def evaluate(root, pack, actor_id, objective_id, *, expected_digest, confirmed=False, local_demo=False, can_review=False, allowed_packs=None):
    _permission(local_demo, can_review, confirmed)
    root, pack = _scope(root, pack, actor_id, allowed_packs)
    report = _fresh(root, pack, actor_id, expected_digest, allowed_packs)
    labels = _selected(report, objective_id)
    rows = [runtime.training_row(r, pack) for r in labels]
    measured = _measure(rows, objective_id)
    _fresh(root, pack, actor_id, expected_digest, allowed_packs)
    return _write(root, pack, 'evaluations', {'objective_id': objective_id,
        'labels': [{'id': r['id'], 'sha256': r['sha256']} for r in labels], 'rows_digest': runtime.digest(rows),
        'code_digest': runtime.code_digest(root), 'measurement': measured,
        'recorded_by': actor_id, 'created_at': datetime.now(timezone.utc).isoformat(), 'notice': NOTICE})


def activate(root, pack, actor_id, evaluation_id, reviewed_by, reviewed_on, notes, *,
             expected_digest, confirmed=False, local_demo=False, can_review=False, allowed_packs=None):
    _permission(local_demo, can_review, confirmed)
    root, pack = _scope(root, pack, actor_id, allowed_packs)
    report = _fresh(root, pack, actor_id, expected_digest, allowed_packs)
    evaluation = runtime.read_record(root, pack, 'evaluations', evaluation_id, allowed_packs=allowed_packs)
    if evaluation.get('record_type') in {'canonical_case_evaluation', 'correction_paired_evaluation'} or evaluation.get('objective_id') not in train_all.REVIEWED_OBJECTIVES:
        raise ValueError('Mechanical behaviour scores cannot activate a learner or adjudicate a fixed model choice. Review the recorded comparisons against the existing objective requirements.')
    current = _selected(report, evaluation['objective_id'])
    if evaluation['labels'] != [{'id': r['id'], 'sha256': r['sha256']} for r in current]:
        raise ValueError('Review labels changed since this evaluation. Evaluate the current labels before activation.')
    rows = [runtime.training_row(r, pack) for r in current]
    measured = _measure(rows, evaluation['objective_id'])
    if runtime.digest(measured) != runtime.digest(evaluation['measurement']):
        raise ValueError('The saved model or evaluation differs from the current canonical measurement.')
    runtime.verified_evaluation(root, pack, evaluation)
    import scientific_definition_ai as ai
    ai._ingress(' '.join([str(reviewed_by), str(reviewed_on), str(notes)]))
    if len(str(notes)) > 3000:
        raise ValueError('Keep the activation rationale within 3,000 characters.')
    value = {'objective_id': evaluation['objective_id'], 'evaluation_id': evaluation_id,
        'evaluation_sha256': evaluation['sha256'], 'phase': 'completed_check', 'enabled': True,
        'verdict': {'adjudicated_by': reviewed_by, 'date': reviewed_on, 'decision': 'activate_for_this_product', 'notes': notes},
        'recorded_by': actor_id, 'created_at': datetime.now(timezone.utc).isoformat(), 'notice': NOTICE}
    if control_plane.validate_local_activation(dict(value, pack=pack), root=root):
        raise ValueError('Record a named reviewer, a real review date and a reasoned verdict on this measured version before activation.')
    _fresh(root, pack, actor_id, expected_digest, allowed_packs)
    return _write(root, pack, 'activations', value)


def deactivate(root, pack, actor_id, objective_id, *, expected_digest, confirmed=False, local_demo=False, can_review=False, allowed_packs=None):
    _permission(local_demo, can_review, confirmed)
    root, pack = _scope(root, pack, actor_id, allowed_packs)
    report = _fresh(root, pack, actor_id, expected_digest, allowed_packs)
    active = next((r for r in report['activations'] if r['objective_id'] == objective_id), None)
    if not active or not active['enabled']:
        raise ValueError('This objective has no active local version.')
    return _write(root, pack, 'activations', {k: v for k, v in active.items() if k not in {'id', 'sha256', 'kind', 'pack'}} |
        {'enabled': False, 'recorded_by': actor_id, 'created_at': datetime.now(timezone.utc).isoformat(), 'supersedes': active['id']})


def recent(root, pack, actor_id, *, allowed_packs=None):
    report = describe(root, pack, actor_id, allowed_packs=allowed_packs)
    measured_types = {'canonical_case_evaluation', 'correction_paired_evaluation', 'intake_case_evaluation'}
    return [{'id': r['id'], 'route': ROUTE, 'title': r['objective_id'].replace('_', ' '),
        'state': 'mechanical case results' if r.get('record_type') in measured_types else 'measured evaluation',
        'summary': 'Review the exact scored transcripts; mechanical passes are not adjudication.' if r.get('record_type') in measured_types
            else (r['measurement']['findings'][0] if r['measurement']['findings'] else 'Review measurement'),
        'updated_at': r['created_at'], 'params': {'evaluation_id': r['id'], 'objective_id': r['objective_id']} |
            ({'correction_id': r['correction']['id']} if r.get('record_type') == 'correction_paired_evaluation' else {})}
        for r in report.get('evaluations', []) if r.get('record_type') != 'correction_paired_evaluation' or r.get('recorded_by') == actor_id][:10]


def _case_runner():
    """Load the canonical module by its path; never shadow another run module."""
    import importlib.util
    name = 'rwd_canonical_case_evals'
    if name not in sys.modules:
        spec = importlib.util.spec_from_file_location(name, CODE / 'experiments/agent/evals/run.py')
        module = importlib.util.module_from_spec(spec)
        sys.modules[name] = module
        spec.loader.exec_module(module)
    return sys.modules[name]


def case_options(root, pack, actor_id, *, allowed_packs=None):
    root, pack = _scope(root, pack, actor_id, allowed_packs)
    import tools
    import portal_agent_connection as connection
    runner = _case_runner()
    allowed = set(allowed_packs or [])
    available = []
    for case in runner.load_all_cases(include_generated=False, root=root) + runner.load_regression_cases():
        if (not isinstance(case, dict) or not re.fullmatch(r'[A-Za-z0-9_-]{1,120}', str(case.get('id', '')))
                or not isinstance(case.get('goal'), str) or not 1 <= len(case['goal']) <= 6000
                or not isinstance(case.get('expect'), dict)):
            continue
        text = json.dumps(case, ensure_ascii=False)
        declared = set(re.findall(r'(?:products|fixtures|sandbox)/[A-Za-z0-9_-]+/[A-Za-z0-9_-]+/\d{6}', text))
        # Reusable UI examples explicitly operate on the selected workflow;
        # examples naming a product retain that exact source scope.
        default_scope = pack if case.get('evidence_mode') == 'reviewed_workflow_correction' else tools.DEFAULT_PACK
        scopes = sorted(declared or {default_scope})
        # The original corpus is over its declared reference/default pack. Do
        # not rewrite its scientific meaning to fit the currently selected pack.
        if any(p not in allowed or (p != pack and not p.startswith('fixtures/')) for p in scopes):
            continue
        try:
            for selected in scopes:
                details._paths(root, selected, allowed)
            connection.check_input(case)
        except (ValueError, OSError):
            continue
        available.append({'case': case, 'packs': scopes})
    config = connection.describe(root)
    corpus = runtime.digest({'runner': (CODE / 'experiments/agent/evals/run.py').read_text(encoding='utf-8'), 'cases': available})
    return {'ok': True, 'cases': available, 'connection': config, 'corpus_digest': corpus,
        'notice': 'Human-authored behaviour cases and generated software regressions are scored mechanically. Regression failure families retain development/held-out splits. Reference cases keep their original scope and never become real-work learning labels; linked UI/backend tests are separate evidence.'}


def preview_cases(root, pack, actor_id, objective_id, case_ids, *, allowed_packs=None, _request_id=None):
    root, pack = _scope(root, pack, actor_id, allowed_packs)
    if objective_id not in CASE_OBJECTIVES:
        raise ValueError('Choose the existing fixed-configuration objective for a scored case run.')
    if objective_id == 'intake_elicitation_model':
        return preview_intake_cases(root, pack, actor_id, case_ids, allowed_packs=allowed_packs, _request_id=_request_id)
    options = case_options(root, pack, actor_id, allowed_packs=allowed_packs)
    if not isinstance(case_ids, list) or not 1 <= len(case_ids) <= 3 or len(case_ids) != len(set(case_ids)):
        raise ValueError('Explicitly select one to three distinct accessible cases.')
    lookup = {row['case']['id']: row for row in options['cases']}
    if any(case_id not in lookup for case_id in case_ids):
        raise ValueError('One of these cases is unavailable in the current product/reference scope.')
    if not options['connection']['ok']:
        raise ValueError(options['connection']['errors'][0])
    import specialist_workspace as specialists
    scoped = sorted({p for case_id in case_ids for p in lookup[case_id]['packs']})
    for selected in scoped:
        if specialists._eligibility(root, selected):
            raise ValueError('The selected case source needs its recorded AI-access review before a model can read it. Open Product progress for ' + selected + '.')
    inputs = {p: specialists.science._digest(specialists._inputs(root, p)) for p in scoped}
    request_id = _request_id or uuid.uuid4().hex
    if not re.fullmatch(r'[0-9a-f]{32}', str(request_id)):
        raise ValueError('Prepare a new explicit case-run request.')
    payload = {'request_id': request_id, 'objective_id': objective_id, 'cases': [lookup[i] for i in case_ids], 'connection': options['connection'],
        'corpus_digest': options['corpus_digest'], 'input_digests': inputs, 'pack': pack, 'actor_id': actor_id,
        'allowed_packs': sorted(allowed_packs or []), 'limits': {'max_cases': 3, 'max_calls_per_case': 4, 'max_seconds_per_case': 90}}
    return dict(payload, digest=runtime.digest(payload))


def run_cases(root, pack, actor_id, proposal, *, confirmed=False, local_demo=False, can_review=False, allowed_packs=None):
    _permission(local_demo, can_review, confirmed)
    root, pack = _scope(root, pack, actor_id, allowed_packs)
    request_id = proposal.get('request_id') if isinstance(proposal, dict) else None
    if not re.fullmatch(r'[0-9a-f]{32}', str(request_id)):
        raise ValueError('Prepare an explicit case-run preview before requesting model calls.')
    import science_workspace as science
    lock = science._safe(root / pack / '.portal-drafts/case-evaluations' / (request_id + '.lock'))
    if os.name == 'nt' and len(str(lock)) > 235:
        raise ValueError('Use a shorter checkout path before running this retained evaluation.')
    lock.parent.mkdir(parents=True, exist_ok=True)
    try:
        fd = os.open(lock, os.O_WRONLY | os.O_CREAT | os.O_EXCL)
    except FileExistsError:
        raise ValueError('This case request is already running. Wait for its retained result before starting another preview.') from None
    try:
        os.close(fd)
        records, invalid = _records(root, pack, 'evaluations', allowed_packs=allowed_packs)
        if invalid:
            raise ValueError('Repair the unreadable evaluation records before running another case.')
        prior = next((r for r in records if r.get('request_id') == request_id and r.get('recorded_by') == actor_id), None)
        if prior:
            if prior.get('preview_digest') != proposal.get('digest'):
                raise ValueError('The completed request differs from this preview. Prepare a new request.')
            return prior
        return _run_cases(root, pack, actor_id, proposal, confirmed=confirmed, local_demo=local_demo,
                          can_review=can_review, allowed_packs=allowed_packs)
    finally:
        lock.unlink(missing_ok=True)


def _run_cases(root, pack, actor_id, proposal, *, confirmed=False, local_demo=False, can_review=False, allowed_packs=None):
    _permission(local_demo, can_review, confirmed)
    root, pack = _scope(root, pack, actor_id, allowed_packs)
    if not isinstance(proposal, dict):
        raise ValueError('Preview the exact cases and connection before running them.')
    if proposal.get('objective_id') == 'intake_elicitation_model':
        return _run_intake_cases(root, pack, actor_id, proposal, allowed_packs=allowed_packs)
    try:
        current = preview_cases(root, pack, actor_id, proposal['objective_id'], [r['case']['id'] for r in proposal['cases']], allowed_packs=allowed_packs, _request_id=proposal['request_id'])
    except (KeyError, TypeError):
        raise ValueError('The case preview is unreadable. Prepare it again.') from None
    if runtime.digest(current) != runtime.digest(proposal):
        raise ValueError('The cases, source, identity or selected connection changed. Review a new preview before any model call.')
    import portal_agent_connection as connection
    import orchestrator
    import time
    runner = _case_runner()
    runs = []; started = time.monotonic()
    deadline = started + 270
    selected = {r['case']['goal']: r for r in current['cases']}
    def bounded(goal, *, cost_ceiling, max_seconds):
        if time.monotonic() >= deadline:
            raise RuntimeError('The bounded case request reached its time limit; remaining cases were not run.')
        try:
            fresh = preview_cases(root, pack, actor_id, current['objective_id'], [r['case']['id'] for r in current['cases']], allowed_packs=allowed_packs, _request_id=current['request_id'])
            if fresh['digest'] != current['digest']:
                raise ValueError('Changed case input.')
            model = connection.model(root, expected=current['connection'])
            model.execution_purpose = 'canonical_case_evaluation'
            scope = set(selected[goal]['packs']) | {pack}
            result = orchestrator.run(goal, model=model, actor={'name': actor_id, 'role': 'local reviewer'},
                scope=scope, primary_pack=pack, max_steps=4, cost_ceiling=.5,
                max_seconds=min(90, max(.1, deadline - time.monotonic())))
            snapshot = runtime.basis(vars(result)) | {'execution': result.execution}
            connection.check_input(snapshot)
            if len(json.dumps(snapshot).encode()) > 500_000:
                raise ValueError('The case result exceeds the retained review limit.')
            runs.append({'run': snapshot, 'sha256': runtime.digest(snapshot)})
            return result
        except Exception:
            raise RuntimeError('The selected assistant could not complete this scoped case. Completed run evidence is retained; inspect it before retrying. No other provider was used.') from None
    rows = runner.run_cases([r['case'] for r in current['cases']], runner=bounded,
        per_case_ceiling=.5, max_seconds_per_case=90, budget_usd=None)
    try:
        refreshed = preview_cases(root, pack, actor_id, current['objective_id'], [r['case']['id'] for r in current['cases']],
            allowed_packs=allowed_packs, _request_id=current['request_id'])
        stale = refreshed['digest'] != current['digest']
    except (ValueError, OSError, KeyError, TypeError):
        stale = True
    # The canonical scorer exposes unknown local token/cost usage as null in
    # each row. Never recast that missing measurement as a subscription cost.
    value = {'record_type': 'canonical_case_evaluation', 'request_id': current['request_id'], 'objective_id': current['objective_id'],
        'cases': current['cases'], 'connection': current['connection'], 'preview_digest': current['digest'],
        'results': rows, 'runs': runs, 'elapsed_seconds': round(time.monotonic() - started, 2),
        'cost_known': current['connection']['provider_id'] == 'anthropic',
        'input_digests': current['input_digests'], 'corpus_digest': current['corpus_digest'],
        'cost_usd': sum((r.get('metrics') or {}).get('total_cost_usd') or 0 for r in rows) if current['connection']['provider_id'] == 'anthropic' and all(not r.get('error') for r in rows) else None,
        'adjudicated': False, 'training_eligible': False, 'recorded_by': actor_id,
        'stale_at_completion': stale,
        'created_at': datetime.now(timezone.utc).isoformat(), 'notice': 'Canonical mechanical scores, not human adjudication, intake slot-filling measurement or product approval.'}
    return _write(root, pack, 'evaluations', value, allowed_packs=allowed_packs)


def reviewed_cases(report, record_type):
    latest = {}
    for record in report['labels']:
        if record.get('record_type') == record_type:
            latest.setdefault(record['case']['case_id'], record)
    return sorted(latest.values(), key=lambda record: record['case']['case_id'])


def reviewed_case_code_digest():
    paths = ['experiments/agent/intake.py', 'experiments/agent/intake_cases.py', 'experiments/agent/ml/rank.py',
        'experiments/agent/ml/logreg.py', 'platform/tools/propose_source_mapping.py',
        'experiments/portal/model_lifecycle_workspace.py', 'experiments/agent/model_lifecycle_runtime.py']
    paths += [path.relative_to(CODE).as_posix() for path in sorted((CODE / 'experiments/agent/intake').glob('*.yaml'))]
    return runtime.digest({path: (CODE / path).read_text(encoding='utf-8') for path in paths})


def save_reviewed_case(root, pack, actor_id, record_type, case, reviewed_by, reviewed_on, rationale, *,
        expected_digest, confirmed=False, local_demo=False, can_review=False, allowed_packs=None):
    """Use the existing immutable branch review records for explicit labels/cases."""
    _permission(local_demo, can_review, confirmed)
    root, pack = _scope(root, pack, actor_id, allowed_packs)
    report = _fresh(root, pack, actor_id, expected_digest, allowed_packs)
    if record_type not in {'reviewed_intake_case', 'reviewed_mapping_label'}:
        raise ValueError('Choose a reviewed intake case or mapping candidate decision.')
    import portal_agent_connection as connection
    import intake_cases
    import rank
    connection.check_input(case)
    connection.check_input([reviewed_by, reviewed_on, rationale])
    value = {'record_type': record_type, 'case': case, 'pack': pack, 'reviewed_by': reviewed_by,
        'reviewed_on': reviewed_on, 'rationale': rationale, 'recorded_by': actor_id,
        'created_at': datetime.now(timezone.utc).isoformat(), 'notice': NOTICE, 'training_eligible': False}
    if record_type == 'reviewed_intake_case':
        value.update(objective_id=intake_cases.OBJECTIVE, origin='human_authored_intake_case')
        intake_cases.validate_record(value, pack)
    else:
        value.update(objective_id=rank.OBJECTIVE, confirmed_real_work=True, training_eligible=True)
        rank.checked_labels([value], root)
    prior = reviewed_cases(report, record_type)
    fingerprint_keys = ('domain', 'message', 'initial') if record_type == 'reviewed_intake_case' else ('role_tokens', 'required_columns', 'candidates')
    fingerprint = rank.case_fingerprint(case) if record_type == 'reviewed_mapping_label' else runtime.digest({key: case[key] for key in fingerprint_keys})
    previous = None
    for row in prior:
        old = row['case']
        if old['source_group'] == case['source_group'] and old['split'] != case['split']:
            raise ValueError('Keep one source family in one reserved split; it cannot supply both development and heldout cases.')
        if old['case_id'] == case['case_id']:
            previous = row
            if old['split'] != case['split'] or old['source_group'] != case['source_group']:
                raise ValueError('A reviewed case retains its original source family and reserved split when corrected.')
        elif (rank.case_fingerprint(old) if record_type == 'reviewed_mapping_label' else runtime.digest({key: old[key] for key in fingerprint_keys})) == fingerprint:
            raise ValueError('This same case is already reviewed under another identifier; correct that case instead of duplicating it.')
    value['supersedes'] = previous['id'] if previous else None
    _fresh(root, pack, actor_id, expected_digest, allowed_packs)
    return _write(root, pack, 'labels', value, allowed_packs=allowed_packs)


def evaluate_mapping_labels(root, pack, actor_id, *, expected_digest, confirmed=False, local_demo=False, can_review=False, allowed_packs=None):
    _permission(local_demo, can_review, confirmed)
    root, pack = _scope(root, pack, actor_id, allowed_packs)
    report = _fresh(root, pack, actor_id, expected_digest, allowed_packs)
    import rank
    rows = reviewed_cases(report, 'reviewed_mapping_label')
    # Exact evidence is checked before and after the bounded canonical trainer.
    rank.checked_labels(rows, root)
    command = "import json,sys;sys.path.insert(0,sys.argv[1]);import rank;v=json.load(sys.stdin);print(json.dumps(rank.train_reviewed(v['rows'],v['root']),allow_nan=False))"
    try:
        proc = subprocess.run([sys.executable, '-c', command, str(CODE / 'experiments/agent/ml')],
            input=json.dumps({'rows': rows, 'root': str(root)}), text=True, encoding='utf-8', capture_output=True,
            timeout=90, creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0))
        if proc.returncode or len(proc.stdout.encode()) > 500_000:
            raise ValueError('The canonical mapping trainer did not complete. Inspect the reviewed evidence and retry explicitly.')
        measurement = json.loads(proc.stdout)
    except (subprocess.TimeoutExpired, json.JSONDecodeError):
        raise ValueError('The bounded mapping measurement did not complete; no learned version was activated.') from None
    rank.checked_labels(rows, root)
    _fresh(root, pack, actor_id, expected_digest, allowed_packs)
    return _write(root, pack, 'evaluations', {'record_type': 'reviewed_mapping_evaluation', 'objective_id': rank.OBJECTIVE,
        'cases': rows, 'measurement': measurement, 'training_eligible': False, 'recorded_by': actor_id,
        'code_digest': reviewed_case_code_digest(), 'created_at': datetime.now(timezone.utc).isoformat(), 'notice': NOTICE}, allowed_packs=allowed_packs)


def intake_case_options(root, pack, actor_id, *, allowed_packs=None):
    report = describe(root, pack, actor_id, allowed_packs=allowed_packs)
    if not report['ok'] or report['invalid_records']:
        raise ValueError('Repair unreadable review records before selecting intake cases.')
    import portal_agent_connection as connection
    rows = reviewed_cases(report, 'reviewed_intake_case')
    return {'cases': rows, 'connection': connection.describe(root),
        'corpus_digest': runtime.digest({'cases': rows, 'code': reviewed_case_code_digest()})}


def preview_intake_cases(root, pack, actor_id, case_ids, *, allowed_packs=None, _request_id=None):
    root, pack = _scope(root, pack, actor_id, allowed_packs)
    options = intake_case_options(root, pack, actor_id, allowed_packs=allowed_packs)
    if not options['cases']:
        raise ValueError('No reviewed intake slot-filling corpus exists for this product yet. Record human-authored expected slot fills before evaluating.')
    if not isinstance(case_ids, list) or not 1 <= len(case_ids) <= 3 or len(set(case_ids)) != len(case_ids):
        raise ValueError('Select one to three distinct reviewed intake cases.')
    lookup = {row['case']['case_id']: row for row in options['cases']}
    if any(case_id not in lookup for case_id in case_ids):
        raise ValueError('A selected intake case is unavailable in this product.')
    if not options['connection']['ok']:
        raise ValueError(options['connection']['errors'][0])
    import specialist_workspace as specialists
    if specialists._eligibility(root, pack):
        raise ValueError('Complete the recorded source AI-access review before evaluating this product request.')
    request_id = _request_id or uuid.uuid4().hex
    if not re.fullmatch(r'[0-9a-f]{32}', str(request_id)):
        raise ValueError('Prepare a new explicit intake evaluation request.')
    payload = {'request_id': request_id, 'objective_id': 'intake_elicitation_model',
        'cases': [lookup[case_id] for case_id in case_ids], 'pack': pack, 'actor_id': actor_id,
        'allowed_packs': sorted(allowed_packs or []), 'connection': options['connection'], 'corpus_digest': options['corpus_digest'],
        'input_digests': {pack: specialists.science._digest(specialists._inputs(root, pack))},
        'limits': {'max_cases': 3, 'max_calls_per_case': 1}}
    return dict(payload, digest=runtime.digest(payload))


def _run_intake_cases(root, pack, actor_id, proposal, *, allowed_packs=None):
    import intake
    import intake_cases
    import portal_agent_connection as connection
    import time
    ids = [row['case']['case_id'] for row in proposal.get('cases', [])]
    current = preview_intake_cases(root, pack, actor_id, ids, allowed_packs=allowed_packs, _request_id=proposal.get('request_id'))
    if runtime.digest(current) != runtime.digest(proposal):
        raise ValueError('The reviewed intake cases, product or selected connection changed. Preview them again before any call.')
    rows = []
    for reviewed in current['cases']:
        case = reviewed['case']
        started = time.monotonic()
        observed = None; reply = ''; error = None
        calls, responses = [], []
        try:
            fresh = preview_intake_cases(root, pack, actor_id, ids, allowed_packs=allowed_packs, _request_id=current['request_id'])
            if fresh['digest'] != current['digest']:
                raise ValueError('Changed case input.')
            selected = connection.model(root, expected=current['connection'])
            class Capture:
                def for_task(self, **kwargs):
                    self.target = selected.for_task(**kwargs)
                    return self
                def step(self, system, messages):
                    if calls:
                        raise ValueError('The intake case allows one model call.')
                    calls.append(runtime.digest([system, messages]))
                    raw = self.target.step(system, messages)
                    connection.check_input(raw)
                    if not isinstance(raw, str) or len(raw.encode()) > 30_000:
                        raise ValueError('The intake response is oversized or malformed.')
                    responses.append(raw)
                    if not isinstance(intake._parse_json(raw).get('request'), dict):
                        raise ValueError('The intake response did not contain a structured request.')
                    return raw
            state = intake.new_state(case['domain'], pack, actor_id)
            state['request'] = dict(case['initial'])
            predicted, reply = intake.next_turn(state, case['message'], Capture())
            connection.check_input(predicted)
            observed = {'request': predicted['request'], 'extra': predicted.get('extra') or {}}
        except Exception:
            error = 'The selected assistant did not complete this intake case. No fallback provider was used; inspect the retained failure before retrying.'
            observed = None; reply = ''
        rows.append({'case_id': case['case_id'], 'observed': observed, 'reply': reply, 'raw_response': responses[0] if responses else '',
            'request_sha256': calls[0] if calls else None, 'response_sha256': runtime.digest(responses[0]) if responses else None,
            'calls': len(calls), 'elapsed_seconds': round(time.monotonic() - started, 3), 'cost_usd': None, 'error': error,
            'score': intake_cases.score(case, observed)})
    try:
        stale = preview_intake_cases(root, pack, actor_id, ids, allowed_packs=allowed_packs, _request_id=current['request_id'])['digest'] != current['digest']
    except (ValueError, OSError):
        stale = True
    value = {'record_type': 'intake_case_evaluation', 'objective_id': 'intake_elicitation_model', 'request_id': current['request_id'],
        'cases': current['cases'], 'results': rows, 'connection': current['connection'], 'preview_digest': current['digest'],
        'corpus_digest': current['corpus_digest'], 'input_digests': current['input_digests'], 'code_digest': reviewed_case_code_digest(),
        'adjudicated': False, 'training_eligible': False, 'recorded_by': actor_id, 'stale_at_completion': stale,
        'created_at': datetime.now(timezone.utc).isoformat(),
        'notice': 'Literal intake slot regression results. Expected answers were reviewed before execution and withheld from the model. Semantic adjudication, model activation and scientific approval remain separate.'}
    return _write(root, pack, 'evaluations', value, allowed_packs=allowed_packs)
