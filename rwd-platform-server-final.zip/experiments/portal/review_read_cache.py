"""Small read-only report cache; callers key it by current content and access scope."""
from collections import OrderedDict
import json
from threading import RLock

_REPORTS = OrderedDict()
_LOCK = RLock()
MAX_ENTRIES = 8
MAX_ENTRY_BYTES = 2 * 1024 * 1024


def clear():
    with _LOCK:
        _REPORTS.clear()


def read(key, load):
    with _LOCK:
        encoded = _REPORTS.get(key)
        if encoded is not None:
            _REPORTS.move_to_end(key)
    if encoded is not None:
        return json.loads(encoded)
    result = load()
    # Failed checks are retried. A caller never shares a mutable report with
    # another page, identity or worker thread.
    if not result.get("errors"):
        encoded = json.dumps(result, ensure_ascii=False).encode("utf-8")
        if len(encoded) <= MAX_ENTRY_BYTES:
            with _LOCK:
                _REPORTS[key] = encoded
                _REPORTS.move_to_end(key)
                while len(_REPORTS) > MAX_ENTRIES:
                    _REPORTS.popitem(last=False)
    return result
