"""Inline reuse of the existing checked-request store and product catalogue.

These are inspectable local examples, never implicit model context. Private requests
belong to their original actor. Another product is searched only after it is chosen.
The existing form adapter remains the only path from an example to draft widgets.
"""
from __future__ import annotations

import hashlib
import json
import re
from pathlib import Path

import yaml

import form_assistance as forms
import intake
import portal_packs
import product_gates
import scientific_definition_ai as ai

MAX_EXAMPLES = 3
# Aliases connect existing form labels to the existing typed intake vocabulary.
# Approval, identities, consumer names and output destinations are deliberately absent.
LABEL_SLOTS = {
    "what should this product help you study": "intended_use",
    "why does this setting need to change": "intended_use",
    "objectives": "intended_use", "intended use": "intended_use", "population": "population",
    "index definition": "index_definition", "baseline lookback": "baseline_lookback",
    "follow up": "follow_up", "outcomes": "outcomes", "exclusions": "exclusions",
    "inclusion sequence": "inclusion_sequence", "output grain": "output_grain",
    "refresh cadence": "refresh_cadence", "acceptance criteria": "acceptance_criteria",
    "deliverables": "deliverables", "variables domains": "variables_domains",
    "source cut": "source_cut", "proposed data source": "source",
    "new variable identifier": "variable_id",
    "definition timing and missing data rule": "definition",
}
SETUP_LABELS = {"Vendor": "vendor", "Data modality": "modality",
                "The tumour this product is of": "tumour_key", "Tumour class": "tumor_class"}


def _digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, ensure_ascii=True, allow_nan=False).encode()).hexdigest()


def _pack(value):
    value = str(value or "").replace("\\", "/").strip("/")
    return value if value and not any(part in {"", ".", ".."} for part in value.split("/")) else ""


def _label(value):
    return " ".join(re.findall(r"[a-z0-9]+", str(value).lower()))


def _safe(value):
    try:
        plain = ai._plain(value)
        if len(plain) > 18000:
            return False
        ai._ingress(plain)
        return True
    except (ai.Invalid, ValueError, TypeError, RecursionError):
        return False


def scope_choices(root, *, allowed_packs, question=""):
    """Only registry metadata from packs already available to this person."""
    catalogue = portal_packs.catalogue(str(root))
    known = set(catalogue["products"] + catalogue["references"] + catalogue["superseded"])
    choices = [{"pack": pack, "label": portal_packs.label(pack, catalogue)}
            for pack in sorted({_pack(p) for p in (allowed_packs or [])} & known)
            if _safe(pack)]
    choices = [row for row in choices if _safe(row)]
    terms = set(_label(question).split())
    for row in choices:
        row["matching_terms"] = sorted(terms & set(_label(row["label"]).split()) - {"product", "reference", "draft", "the"})
    choices.sort(key=lambda row: (-len(row["matching_terms"]), row["label"]))
    return choices


def _request_changes(request, public):
    # The established prefill checks lifecycle and every literal request value.
    state = intake.new_state(request["kind"], request["pack"], request["raised_by"])
    copied = intake.prefill(state, request)["request"]
    result = []
    for field in (public or {}).get("fields", []):
        slot = LABEL_SLOTS.get(_label(field["label"]))
        value = copied.get(slot)
        if not slot or value is None or value == field.get("current"):
            continue
        if not field.get("current_complete", True):
            continue
        try:
            forms.check_response({"scope": public["scope"], "fields": [{"id": field["id"], "value": value}]}, public)
        except ValueError:
            continue
        result.append({"id": field["id"], "label": field["label"], "before": field.get("current"),
                       "value": value, "slot": slot})
    return result[:forms.MAX_EDITS]


def _summary(request):
    """Complete bounded descriptive values; no authors, consumers or free-form notes."""
    fields = []
    for slot in ("intended_use", "population", "index_definition", "outcomes", "source_cut", "follow_up",
                 "definition", "source", "measure", "question"):
        value = (request.get("request") or {}).get(slot)
        if not isinstance(value, str) or not value.strip() or len(value) > 900:
            continue
        if sum(len(field["value"]) for field in fields) + len(value) > 3500:
            continue
        fields.append({"label": slot.replace("_", " ").capitalize(), "value": value})
        if len(fields) == 6:
            break
    return fields


def _setup_example(root, pack, question, public):
    """A chosen catalogue entry offers setup metadata, not inferred study science."""
    entry = product_gates.registry_entry(str(root), pack) or {}
    metadata = {key: entry[key] for key in ("name", "code", "vendor", "modality", "tumour_key", "tumor_class") if key in entry}
    if not metadata or not _safe(metadata):
        return None
    changes = []
    for field in (public or {}).get("fields", []):
        value = metadata.get(SETUP_LABELS.get(field["label"]))
        if value is None or value == field.get("current") or not field.get("current_complete", True):
            continue
        try:
            forms.check_response({"scope": public["scope"], "fields": [{"id": field["id"], "value": value}]}, public)
        except ValueError:
            continue
        changes.append({"id": field["id"], "label": field["label"], "before": field.get("current"),
                        "value": value, "slot": SETUP_LABELS[field["label"]]})
    registry = "fixtures/registry.yaml" if pack.startswith("fixtures/") else "products/registry.yaml"
    # Bind the exact record, including its lineage, not just the displayed projection.
    revision = _digest(entry)
    return {"id": _digest(["catalogue", pack]), "kind": "catalogue", "title": str(metadata.get("name") or metadata.get("code") or pack),
            "pack": pack, "version": pack.rsplit("/", 1)[-1], "digest": revision,
            "source": f"{registry} · {metadata.get('code') or pack}", "run_id": None,
            "match": "You selected this existing product or reference as a starting point.",
            "differences": ["Only declared setup metadata can be reused here. A new name, specification cut, study intent and workbook remain your choices.",
                            "Reference examples are synthetic and do not carry scientific approval." if pack.startswith("fixtures/") else
                            "Prior scientific decisions and approvals do not transfer to this product."],
            "summary": [{"label": key.replace("_", " ").capitalize(), "value": str(value)} for key, value in metadata.items()],
            "changes": changes, "score": 0.0}


def _shared_examples(root, *, question, actor_id, allowed_packs, public):
    """Existing released concepts are shared across authors, never private requests."""
    import scientific_conversation_context as evidence
    entries, binding, _notices = evidence.shared_templates(root, actor_id, allowed_packs, question)
    result = []
    for rank, source, reference in entries:
        concept = json.loads(source["text"])
        excluded = concept.get("excludes") or []
        definition = concept.get("definition")
        if isinstance(definition, dict):
            definition = json.dumps(definition, ensure_ascii=False, sort_keys=True)
        values = {"scientific interpretation": definition,
                  "new variable identifier": concept.get("variable_id")}
        if isinstance(definition, str):
            values["definition timing and missing data rule"] = definition + "\nStill to define for this study: " + ", ".join(excluded)
        changes = []
        for field in (public or {}).get("fields", []):
            value = values.get(_label(field["label"]))
            if not isinstance(value, str) or not value.strip() or value == field.get("current") or not field.get("current_complete", True):
                continue
            try:
                forms.check_response({"scope": public["scope"], "fields": [{"id": field["id"], "value": value}]}, public)
            except ValueError:
                continue
            changes.append({"id": field["id"], "label": field["label"], "before": field.get("current"),
                            "value": value, "slot": "definition"})
        result.append({"id": source["id"], "kind": "shared_template", "title": source["label"],
            "pack": reference["pack"], "version": reference["reference_version"],
            "digest": _digest([binding, source, reference]), "source": reference["artifact"], "run_id": None,
            "match": "Matching reviewed shared concept; available to users with access to its source evidence.",
            "differences": ["The shared version records reusable meaning. Its review does not approve this study.",
                            "Still to define for this study: " + ", ".join(excluded) + "."],
            "summary": [{"label": name.replace("_", " ").capitalize(), "value": value if isinstance(value, str) else json.dumps(value, ensure_ascii=False)}
                        for name, value in concept.items() if value is not None],
            "changes": changes[:forms.MAX_EDITS], "score": -rank,
            "provenance": reference})
    return result


def search(root, pack, *, question, actor_id, allowed_packs, public=None, selected_pack=None, setup=False):
    """Top three local examples with exact sources and field-level differences.

    Default: this actor's checked requests for this product and registered lineage.
    A nonempty selected_pack explicitly chooses another authorized product. On a
    new-product page, its existing catalogue entry can also prefill setup metadata.
    """
    if not isinstance(actor_id, str) or not actor_id.strip() or not _safe(question):
        return []
    allowed = {_pack(p) for p in (allowed_packs or [])} - {""}
    current = _pack(pack)
    selected = _pack(selected_pack)
    if current and current not in allowed or selected_pack and (not selected or selected not in allowed):
        return []
    target = selected or current
    shared = _shared_examples(root, question=question, actor_id=actor_id,
                              allowed_packs=allowed_packs, public=public)
    if not target:
        return sorted(shared, key=lambda row: (-row["score"], row["source"]))[:MAX_EXAMPLES]
    try:
        lineage = set(portal_packs.lineage(str(root), target)) & allowed
        past = intake.load_requests()
        templates = intake.domains()
    except (OSError, ValueError, TypeError, KeyError, AssertionError, yaml.YAMLError):
        return sorted(shared, key=lambda row: (-row["score"], row["source"]))[:MAX_EXAMPLES]
    eligible = []
    for record in past:
        if not isinstance(record, dict) or record.get("raised_by") != actor_id:
            continue
        if _pack(record.get("pack")) not in ({target} | lineage) or _pack(record.get("pack")) not in allowed:
            continue
        if record.get("kind") not in templates or record.get("status") not in intake.REUSABLE_STATUSES:
            continue
        # Never expose rejected clinical/patient/credential content even in local cards.
        if not _safe(record.get("request")) or not _safe({k: record.get(k) for k in ("_file", "run_id", "pack")}):
            continue
        eligible.append(record)
    ranked = []
    for domain in templates:
        query = {"question": str(question)}
        for field in (public or {}).get("fields", []):
            slot = LABEL_SLOTS.get(_label(field["label"]))
            if slot and field.get("current_complete", True) and not field.get("empty"):
                query[slot] = field.get("current")
        state = {"domain": domain, "pack": target, "request": query}
        for score, record in intake.similar(state, eligible, k=MAX_EXAMPLES, scope=allowed, lineage=lineage):
            try:
                changes = _request_changes(record, public)
            except (ValueError, TypeError, KeyError, OSError, AssertionError, yaml.YAMLError):
                continue
            common = sorted(intake._tokens(query) & intake._tokens(record["request"]))[:8]
            source_pack = _pack(record["pack"])
            details = ["The checked request is an example; its scientific choices need review for this study."]
            if source_pack != current:
                details.append(f"Different product or specification cut: {source_pack}.")
            existing = [change["label"] for change in changes if not forms.empty(change["before"])]
            if existing:
                details.append("Different from your current draft: " + ", ".join(existing) + ".")
            ranked.append({"id": _digest(["request", source_pack, record["_file"]]), "kind": "request",
                "title": str(templates[domain]["title"]), "pack": source_pack,
                "version": source_pack.rsplit("/", 1)[-1], "digest": record["request_sha256"],
                "source": "Saved request · " + record["_file"], "run_id": str(record.get("run_id") or ""),
                "match": "Matching request terms: " + ", ".join(common) + ".",
                "differences": details, "summary": _summary(record), "changes": changes, "score": score})
    # Reserve space for a reviewed shared concept so personal request history
    # cannot hide the library from the next researcher.
    ranked.sort(key=lambda item: (-item["score"], item["source"]))
    ranked = sorted(shared, key=lambda item: (-item["score"], item["source"]))[:1] + ranked + sorted(shared, key=lambda item: (-item["score"], item["source"]))[1:]
    if setup and selected:
        try:
            catalogue = _setup_example(root, selected, question, public)
            if catalogue:
                ranked.insert(0, catalogue)
        except (OSError, ValueError, TypeError, KeyError):
            pass
    return ranked[:MAX_EXAMPLES]


def prepare(root, pack, *, example_id, expected_digest, field_ids, question, actor_id,
            allowed_packs, public, selected_pack=None, setup=False):
    """Reload source/check binding before proposing only explicitly selected fields."""
    if (not isinstance(field_ids, list) or not 1 <= len(field_ids) <= forms.MAX_EDITS
            or any(not isinstance(identifier, str) for identifier in field_ids)
            or len(set(field_ids)) != len(field_ids)):
        raise ValueError("Choose the example fields you want to review.")
    rows = search(root, pack, question=question, actor_id=actor_id, allowed_packs=allowed_packs,
                  public=public, selected_pack=selected_pack, setup=setup)
    chosen = next((row for row in rows if row["id"] == example_id), None)
    if not chosen or chosen["digest"] != expected_digest:
        raise ValueError("This example or its checked evidence changed. Review the current examples again.")
    available = {change["id"]: change for change in chosen["changes"]}
    if any(identifier not in available for identifier in field_ids):
        raise ValueError("An example field is no longer available in this form.")
    return forms.check_response({"scope": public["scope"], "fields": [
        {"id": identifier, "value": available[identifier]["value"]} for identifier in field_ids]}, public)
