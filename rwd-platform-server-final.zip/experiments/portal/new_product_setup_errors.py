"""Actionable setup input failures shared with the existing assistant."""
from __future__ import annotations

import streamlit as st
import form_assistance as forms


def upload_failure(key, errors):
    messages, _ = forms.validation_messages(errors)
    if not messages:
        messages = ["The workbook upload is unavailable. Choose the file again."]
    st.session_state["_setup_upload_error_" + key] = messages
    for message in messages:
        st.warning(message)
    forms.record_validation(messages, title="Workbook upload needs attention",
        action_id="new_product_workbook", input_digest=forms.digest([key, messages]), primary=True)


def metadata_failure(root, actor_id, error, *, role, permissions, can_agent, local_demo, allowed_packs):
    """Keep explanation/chat available when trustworthy field choices cannot load."""
    import flow_assistant
    import flow_assistant_page
    messages, _ = forms.validation_messages([str(error)])
    diagnostic = messages[0] if messages else "The current setup metadata could not be read."
    guidance = ("Use chat below to work through this diagnostic, then choose Reload setup choices to check the current files again. "
                "The assistant can help identify the correction. A workspace owner must make any shared registry repair; setup fields cannot edit that registry.")
    st.error("The current checkout's setup registry or vendor catalogue could not be read.")
    st.write(diagnostic)
    st.info(guidance)
    st.caption("Your current entries are kept. Preview and product creation remain unavailable until the current choices can be checked.")
    st.button("Reload setup choices", key="np_reload_choices",
        help="Read the current registry and vendor choices again. This does not create a product or retry a write.")
    forms.begin(root, "", actor_id, page="New product", route={"setup_metadata": "unavailable"},
        allowed_packs=allowed_packs, can_write=False)
    forms.record_validation([diagnostic, guidance], title="Setup metadata needs attention",
        action_id="new_product_metadata", input_digest=forms.digest([diagnostic]), primary=True)
    # Commit this failure before the assistant reads it. The initial render
    # reruns once; subsequent questions see the same complete read-only context.
    forms.finish()
    card = flow_assistant.context(label="Product setup", section="New product", rows=[], step={},
        result=None, role=role, perms=permissions, can_review=False)
    card.update(actions=[], current_task={"route": "progress", "title": "Restore setup choices",
        "purpose": guidance}, setup_compatibility={"blockers": [diagnostic, guidance], "warnings": [], "suggestions": {}},
        setup_form={"fields": [], "preview_action": "Unavailable until setup choices reload successfully",
                    "save_requires": "Valid current metadata and a passing explicit preview.",
                    "recovery_action": "Reload setup choices", "guidance": guidance})
    flow_assistant_page.render(root, "", card=card, actor_id=actor_id, primary=True,
        metadata_only=True, can_agent=can_agent, local_demo=local_demo, can_write=False, allowed_packs=allowed_packs)
