"""Search hits as a page, not a dump.

The Definitions-and-search section printed the agent's text rendering of the federated search — one
line per hit, `[kind/domain] pack (state) title — detail`, in a monospace block — and a person reading
twenty-one hits for "ECOG" saw a wall (2026-09-05). This module turns `knowledge_search` hits into
groups a page can render: contract records and decisions first, engine capabilities, then the
literature collapsed behind its count. PURE: no Streamlit here, so the grouping is testable and the
agent's own renderer (experiments/agent/tools.py) is untouched. Scope is applied exactly as the agent
applies it — a hit bound to a pack outside the actor's scope is dropped and counted, never shown.
"""
from __future__ import annotations

import re

BANNER = "Nothing below is an approval — every hit is labelled by what it may settle."
KIND_TITLES = {"contract_record": "Contract records", "decision": "Decisions",
               "precedent": "Precedents from other packs", "capability": "Engine capabilities",
               "citation": "Citations", "inventory": "Literature and inventory"}
KIND_ORDER = ("contract_record", "decision", "precedent", "capability", "citation", "inventory")
# the ledger-like groups open; the literature opens only when it is all there is
COLLAPSED_UNLESS_ALONE = ("inventory", "citation")
_MD = re.compile(r"([\\`*_{}\[\]()#+\-!|<>~])")


def md_escape(text) -> str:
    """Every markdown-significant character escaped: a requirement quoting `[INDEX - 30]` or
    `*` must read as typed, never as a link or emphasis."""
    return _MD.sub(r"\\\1", str(text or ""))


def group(hits, scope=None, pack_of=None, limit=25) -> dict:
    """{banner, groups: [{kind, title, count, open, hits: [{title, detail, pack, state, domain, id}]}],
    dropped, more}. `scope` is the actor's set of packs (None: unconfined); `pack_of` maps a hit's
    `where` to its pack (None when the hit is not pack-bound)."""
    pack_of = pack_of or (lambda where: None)
    kept, dropped = [], 0
    for h in hits or []:
        pk = pack_of(h.get("where"))
        if scope is not None and pk is not None and pk not in scope:
            dropped += 1
            continue
        kept.append((h, pk))
    shown, more = kept[:limit], max(0, len(kept) - limit)
    by_kind = {}
    for h, pk in shown:
        by_kind.setdefault(str(h.get("kind") or "other"), []).append({
            "title": str(h.get("title") or h.get("id") or ""), "detail": str(h.get("detail") or ""),
            "pack": pk or "", "state": str(h.get("state") or ""), "domain": str(h.get("domain") or ""),
            "id": str(h.get("id") or ""), "where": str(h.get("where") or "")})
    order = [k for k in KIND_ORDER if k in by_kind] + sorted(k for k in by_kind if k not in KIND_ORDER)
    alone = len(order) == 1
    groups = [{"kind": k, "title": KIND_TITLES.get(k, k.replace("_", " ").capitalize()),
               "count": len(by_kind[k]), "open": alone or k not in COLLAPSED_UNLESS_ALONE,
               "hits": by_kind[k]} for k in order]
    return {"banner": BANNER, "groups": groups, "dropped": dropped, "more": more}


def caption(h: dict) -> str:
    """The one-line provenance under a hit: pack · state · what it may settle · id."""
    parts = [h.get("pack") or "", h.get("state") or "",
             (f"may settle: {h['domain'].replace('_', ' ')}" if h.get("domain") else ""),
             h.get("id") or ""]
    return " · ".join(p for p in parts if p)
