"""Attach an XLSX specification without carrying reviews onto different source bytes.

Only canonical files inside the selected pack's prog_spec folder are selectable.
Uploads are bounded, parsed locally and published without overwriting another file.
The source record uses the same scalar editor and lock as the other portal forms.
"""
from __future__ import annotations
from contextlib import ExitStack

import hashlib
import io
import os
from pathlib import Path
import re
import tempfile
import unicodedata
import xml.etree.ElementTree as ET
import zipfile

import yaml

import specification_details as details
import source_review as review

MAX_UPLOAD_BYTES = 15 * 1024 * 1024
WORKBOOK_VALIDATION_VERSION = 2  # invalidate private UI metadata when workbook rules change
MAX_EXPANDED_BYTES = 80 * 1024 * 1024
MAX_MEMBER_BYTES = 25 * 1024 * 1024
MAX_ZIP_MEMBERS = 4096
MAX_CELLS = 200000
RESET_FIELDS = ("approved_by", "approval_date", "ai_classification", "classified_by", "classified_date",
                "revision", "data_refresh", "rwb_qc_reference")
NOTICE = ("Attaching a workbook records its exact bytes and leaves the specification pending. "
          "Scientific review and AI access must be decided for this workbook. The document ID and source history identity are retained.")
_FACTUAL_PENDING = "Specification workbook attached through the portal. Scientific review and AI access classification for these bytes are pending."


def _failure(message):
    return {"ok": False, "changed": False, "errors": [str(message)], "digest": "", "choices": [], "notice": NOTICE}


def _safe(path, within):
    path = Path(path).absolute()
    if path.resolve() != path:
        raise details._Invalid("A specification path redirects elsewhere. Ask your data expert to restore a normal product folder.")
    try:
        path.relative_to(Path(within).resolve())
    except ValueError as error:
        raise details._Invalid("Choose a workbook inside this product's specification folder.") from error
    return path


def _spec_directory(product):
    return _safe(product / "prog_spec", product)


def _candidate(product, relative):
    if (not isinstance(relative, str) or "\\" in relative or ":" in relative or not relative.startswith("prog_spec/")
            or any(piece in {"", ".", ".."} or piece.startswith(".") for piece in relative.split("/"))
            or Path(relative).suffix.lower() != ".xlsx"):
        raise details._Invalid("Choose an XLSX workbook from this product's specification folder.")
    return _safe(product / relative, _spec_directory(product))


def _current_path(root, product, pack, material):
    value = str(material.get("path_or_link") or "").replace("\\", "/")
    try:
        path = Path(value)
        if path.is_absolute():
            relative = _safe(path, _spec_directory(product)).relative_to(product).as_posix()
        else:
            relative = value[len(pack) + 1:] if value.startswith(pack + "/") else value
        return _candidate(product, relative)
    except (OSError, ValueError, TypeError):
        return None


def _bytes(path):
    with path.open("rb") as handle:
        value = handle.read(MAX_UPLOAD_BYTES + 1)
    if len(value) > MAX_UPLOAD_BYTES:
        raise details._Invalid("The workbook exceeds the 15 MB upload limit. Ask your data expert to split the specification.")
    return value


def _digest(value):
    return hashlib.sha256(value).hexdigest()


def _recorded(material, key):
    value = material.get(key)
    return value is not None and not details.unstated(value)


def _needs_reset(material):
    return str(material.get("status") or "").lower() == "reviewed" or _recorded(material, "sha256") or any(_recorded(material, field) for field in RESET_FIELDS)


def _describe_loaded(root, path, pack, raw, doc, index):
    product = path.parent
    directory = _spec_directory(product)
    material = doc["source_materials"][index]
    choices, warnings, total = [], [], 0
    if directory.is_dir():
        for current, dirs, files in os.walk(directory, followlinks=False):
            kept = []
            for name in dirs:
                if name.startswith("."):
                    continue
                try:
                    _safe(Path(current) / name, directory)
                    kept.append(name)
                except (OSError, ValueError):
                    pass
            dirs[:] = sorted(kept)
            for name in sorted(files):
                if name.startswith(".") or Path(name).suffix.lower() != ".xlsx":
                    continue
                if len(choices) >= 50 or total > 100 * 1024 * 1024:
                    warnings.append("The chooser shows up to 50 workbooks. Upload the intended specification if it is not listed.")
                    dirs[:] = []
                    break
                try:
                    candidate = _safe(Path(current) / name, directory)
                    value = _bytes(candidate)
                    total += len(value)
                    choices.append({"path": candidate.relative_to(product).as_posix(), "label": candidate.relative_to(directory).as_posix(),
                                    "sha256": _digest(value), "bytes": len(value)})
                except (OSError, ValueError):
                    warnings.append("An unreadable, redirected or oversized workbook was omitted from the chooser.")
    current = _current_path(root, product, pack, material)
    return {"ok": True, "pack": pack, "digest": _digest(raw), "material_id": material["material_id"],
            "current": {"path": str(material.get("path_or_link") or ""), "sha256": str(material.get("sha256") or ""),
                        "status": str(material.get("status") or ""), "exists": bool(current and current.is_file()),
                        "requires_reset": _needs_reset(material)},
            "choices": choices, "errors": [], "warnings": list(dict.fromkeys(warnings)), "notice": NOTICE}


def describe(root, pack, allowed_packs=None):
    try:
        path, pack, raw, _text, doc, index, _node = details._load(root, pack, allowed_packs)
        return _describe_loaded(root, path, pack, raw, doc, index)
    except (details._Invalid, OSError, ValueError, TypeError, UnicodeError, yaml.YAMLError, RecursionError) as error:
        return _failure(str(error) if isinstance(error, details._Invalid) else "The source record or workbook folder could not be read safely.")


def _filename(name):
    if (not isinstance(name, str) or len(name) > 255 or any(char in name for char in ("/", "\\", ":"))
            or Path(name).suffix.lower() != ".xlsx"):
        raise details._Invalid("Upload a file with an .xlsx filename, without folders or path characters.")
    plain = unicodedata.normalize("NFKD", Path(name).stem).encode("ascii", "ignore").decode("ascii")
    stem = re.sub(r"[^A-Za-z0-9._-]+", "_", plain).strip("._-")[:80] or "program_spec"
    # Windows reserves the device prefix even when it has another extension.
    if re.fullmatch(r"(?i:con|prn|aux|nul|com[0-9]|lpt[0-9])", stem.split(".")[0]):
        stem = "spec_" + stem
    return stem + ".xlsx"


def _worksheet_parts(archive):
    """Use the workbook's relationships, as the XLSX reader does, for sheet paths."""
    import posixpath

    content = archive.read("xl/_rels/workbook.xml.rels")
    if b"\x00" in content or re.search(br"<!\s*(?:DOCTYPE|ENTITY)", content, re.I):
        raise details._Invalid("This workbook contains an unsupported XML declaration. Save a plain XLSX copy and try again.")
    paths = set()
    for relation in ET.fromstring(content):
        if str(relation.attrib.get("Type", "")).rsplit("/", 1)[-1] != "worksheet":
            continue
        target = relation.attrib.get("Target", "")
        if relation.attrib.get("TargetMode") == "External" or not target or "\\" in target:
            raise details._Invalid("Use a standalone XLSX specification without linked worksheets.")
        path = target[1:] if target.startswith("/") else posixpath.normpath(posixpath.join("xl", target))
        if path not in archive.namelist() or path.startswith("../"):
            raise details._Invalid("The workbook has an invalid worksheet reference. Save a plain XLSX copy and try again.")
        paths.add(path)
    return paths


def validate_workbook(value, *, allow_macro_container=False):
    """Validate bounded workbook content without evaluating formulas or external links.

    Attachments remain plain XLSX. Existing local registration also accepts XLSM
    paths; its sheet inventory can inspect that container explicitly, discarding
    VBA (openpyxl's default) and never executing it. Upload callers keep the default.
    """
    if not isinstance(value, bytes) or not value or len(value) > MAX_UPLOAD_BYTES:
        raise details._Invalid("Choose a nonempty XLSX workbook of at most 15 MB.")
    try:
        with zipfile.ZipFile(io.BytesIO(value)) as archive:
            members = archive.infolist()
            if len(members) > MAX_ZIP_MEMBERS or sum(item.file_size for item in members) > MAX_EXPANDED_BYTES:
                raise details._Invalid("The workbook expands beyond the supported size. Ask your data expert to simplify it.")
            names = [item.filename.casefold() for item in members]
            if len(set(names)) != len(names) or not {"[content_types].xml", "xl/workbook.xml"}.issubset(names):
                raise details._Invalid("The file is not a well-formed XLSX workbook.")
            for item in members:
                if (item.flag_bits & 1 or item.file_size > MAX_MEMBER_BYTES
                        or (item.file_size > 1024 * 1024 and item.file_size > max(item.compress_size, 1) * 200)
                        or item.compress_type not in {zipfile.ZIP_STORED, zipfile.ZIP_DEFLATED}
                        or item.filename.startswith(("/", "\\")) or "\\" in item.filename
                        or ".." in item.filename.split("/")):
                    raise details._Invalid("This workbook has an encrypted, unsafe or oversized component. Save a plain XLSX copy and try again.")
            # All components have passed archive bounds before relationships or
            # XML are read. Worksheet locations and suffixes are not prescribed
            # by XLSX; follow the same relationship targets as openpyxl.
            worksheet_parts = _worksheet_parts(archive)
            cells = 0
            merged_cells = 0
            for item in members:
                lowered = item.filename.casefold()
                if ("vbaproject" in lowered and not allow_macro_container) or lowered.startswith(("xl/externallinks/", "xl/embeddings/")):
                    raise details._Invalid("Use a standalone XLSX specification without macros, embedded files or linked workbooks.")
                # Reading every bounded component also checks the ZIP CRC before publication.
                content = archive.read(item)
                if lowered.endswith((".xml", ".rels")) or item.filename in worksheet_parts:
                    if b"\x00" in content or re.search(br"<!\s*(?:DOCTYPE|ENTITY)", content, re.I):
                        raise details._Invalid("This workbook contains an unsupported XML declaration. Save a plain XLSX copy and try again.")
                    if lowered == "[content_types].xml" and b"macroenabled" in content.lower() and not allow_macro_container:
                        raise details._Invalid("Macro-enabled workbooks cannot be attached as XLSX specifications.")
                    if item.filename in worksheet_parts:
                        for _event, node in ET.iterparse(io.BytesIO(content), events=("end",)):
                            tag = node.tag.rsplit("}", 1)[-1]
                            if tag == "c":
                                cells += 1
                                match = re.fullmatch(r"([A-Za-z]+)([1-9][0-9]*)", str(node.attrib.get("r", "")))
                                column = 0
                                if match:
                                    for char in match.group(1).upper():
                                        column = column * 26 + ord(char) - 64
                                if not match or int(match.group(2)) > 10000 or column > 200 or cells > MAX_CELLS:
                                    raise details._Invalid("Keep the specification within 10,000 rows, 200 columns and 200,000 populated cells.")
                            elif tag == "row" and int(node.attrib.get("r", "1")) > 10000:
                                raise details._Invalid("Keep the specification within 10,000 rows per sheet.")
                            elif tag == "mergeCell":
                                from openpyxl.utils.cell import range_boundaries
                                left, top, right, bottom = range_boundaries(str(node.attrib.get("ref", "")))
                                if (None in (left, top, right, bottom) or not 1 <= left <= right <= 200
                                        or not 1 <= top <= bottom <= 10000):
                                    raise details._Invalid("Keep merged ranges within 10,000 rows and 200 columns.")
                                merged_cells += (right - left + 1) * (bottom - top + 1)
                                if merged_cells > MAX_CELLS:
                                    raise details._Invalid("Merged ranges expand beyond 200,000 cells. Simplify the workbook before registering it.")
                            node.clear()
        try:
            from openpyxl import load_workbook
        except ImportError as error:
            raise details._Invalid("The portal runtime cannot read workbooks yet. Ask your administrator to install the portal workbook dependency.") from error
        workbook = load_workbook(io.BytesIO(value), read_only=True, data_only=False, keep_links=False)
        try:
            from spec_extract import validate_sheet_titles
            try:
                validate_sheet_titles(workbook.sheetnames)
            except ValueError as error:
                raise details._Invalid(str(error)) from error
            if not workbook.worksheets or len(workbook.worksheets) > 100:
                raise details._Invalid("Choose a workbook with 1 to 100 worksheets.")
            populated = 0
            for sheet in workbook.worksheets:
                sheet.reset_dimensions()
                for row in sheet.iter_rows():
                    populated += sum(cell.value is not None for cell in row)
                    if populated > MAX_CELLS:
                        raise details._Invalid("The workbook has too many populated cells for a program specification.")
            if not populated:
                raise details._Invalid("The workbook contains no specification content.")
            return {"sheets": workbook.sheetnames, "populated_cells": populated, "bytes": len(value), "sha256": _digest(value)}
        finally:
            workbook.close()
    except details._Invalid:
        raise
    except Exception as error:  # third-party parsers expose several format-specific exception types
        raise details._Invalid("The workbook could not be parsed as a plain XLSX specification. Open it in your spreadsheet tool, save an XLSX copy and try again.") from error


def _upload_target(directory, name, digest):
    normalized = _filename(name)
    for filename in (normalized, Path(normalized).stem + "-" + digest[:12] + ".xlsx", Path(normalized).stem + "-" + digest + ".xlsx"):
        target = _safe(directory / filename, directory)
        if not target.exists():
            return target, False
        if target.is_file() and _digest(_bytes(target)) == digest:
            return target, True
    raise details._Invalid("A versioned filename is already occupied by different content. Choose another upload name.")


def _setup_upload_directory(root, actor_id):
    """Pending specifications belong to this OS user's storage, outside Git."""
    if (not isinstance(actor_id, str) or not actor_id.strip() or len(actor_id) > 300
            or any(ord(char) < 32 for char in actor_id)):
        raise details._Invalid("Choose a local application identity before uploading a specification.")
    root = Path(root).resolve(strict=True)
    if not root.is_dir():
        raise details._Invalid("Open a valid application checkout before uploading a specification.")
    base = Path(os.environ.get("LOCALAPPDATA") or Path.home() / ".local" / "state")
    if not base.is_absolute():
        raise details._Invalid("The local application storage location must be an absolute path outside the checkout.")
    directory = (base / "RwdPortal" / "setup-uploads"
                 / _digest(os.path.normcase(str(root)).encode("utf-8"))[:12]
                 / _digest(actor_id.strip().encode("utf-8"))[:16])
    try:
        _safe(directory, base)
        directory.relative_to(root)
    except details._Invalid as error:
        raise details._Invalid("The local upload folder redirects elsewhere. Restore a normal local application storage folder and retry.") from error
    except ValueError:
        return directory
    raise details._Invalid("Pending uploads must be stored outside the checkout. Restore your local application storage setting and retry.")


def save_setup_upload(root, actor_id, *, upload_name, upload_bytes):
    """Validate and retain a pending workbook, without registering or approving it.

    The stand-up tool accepts this absolute path and copies these bytes into the
    product only after the person previews and writes the registration. Existing
    checkout-relative upload paths remain usable by older saved setups.
    """
    temporary = owned = directory = None
    owned_identity = None
    complete = False
    try:
        name = _filename(upload_name)
        validation = validate_workbook(upload_bytes)
        directory = _setup_upload_directory(root, actor_id)
        from design_workspace import _check_storage_paths  # reuse the Windows storage bound
        _check_storage_paths([directory / name])
        directory.mkdir(parents=True, exist_ok=True, mode=0o700)
        _safe(directory, directory)
        if os.name != "nt":
            os.chmod(directory, 0o700)
        selected, exists = _upload_target(directory, name, validation["sha256"])
        _check_storage_paths([selected])
        if not exists:
            with tempfile.NamedTemporaryFile(mode="wb", prefix=".spec-upload-", suffix=".tmp", dir=directory, delete=False) as handle:
                temporary = Path(handle.name)
                handle.write(upload_bytes)
                handle.flush()
                os.fsync(handle.fileno())
                stat = os.fstat(handle.fileno())
                owned_identity = (stat.st_dev, stat.st_ino)
            _safe(temporary, directory)
            _safe(selected, directory)
            os.link(temporary, selected)
            owned = selected
            temporary.unlink()
            temporary = None
        _safe(selected, directory)
        if _digest(_bytes(selected)) != validation["sha256"]:
            raise details._Invalid("The pending workbook changed while it was being saved. Upload it again before previewing the product.")
        complete = True
        return {"ok": True, "path": str(selected), "name": selected.name, "workbook": validation,
                "registered": False, "changed": not exists, "errors": []}
    except FileExistsError:
        message = "Another upload used this filename at the same time. Upload it again to select a safe version; existing files were retained."
    except (OSError, ValueError, TypeError, UnicodeError, RecursionError) as error:
        message = (str(error) if isinstance(error, details._Invalid) else
                   "The pending workbook could not be saved in local application storage. Check that the folder is writable and retry.")
    finally:
        if temporary is not None:
            try:
                _safe(temporary, directory).unlink(missing_ok=True)
            except (OSError, ValueError):
                pass
        if owned is not None and not complete:
            try:
                checked = _safe(owned, directory)
                stat = checked.stat()
                if (stat.st_dev, stat.st_ino) == owned_identity and _digest(_bytes(checked)) == validation["sha256"]:
                    checked.unlink()
            except (OSError, ValueError):
                pass
    return {"ok": False, "path": "", "registered": False, "changed": False, "errors": [message]}


def attach(root, pack, *, expected_digest, existing_path=None, expected_file_digest=None,
           upload_name=None, upload_bytes=None, confirm_reset=False, local_demo=False, can_write=False, allowed_packs=None):
    """Publish exact workbook bytes and atomically update only program_spec scalars."""
    if local_demo is not True or can_write is not True:
        return _failure("Attaching a specification requires product-author access in a local editing session.")
    if not isinstance(expected_digest, str) or not re.fullmatch(r"[0-9a-f]{64}", expected_digest):
        return _failure("Reload the specification attachment form before saving; its starting checksum is required.")
    if bool(existing_path) == (upload_bytes is not None):
        return _failure("Choose either one listed workbook or one XLSX upload.")
    lock_stack = ExitStack()
    temporary_record = temporary_upload = owned_upload = None
    owned_identity = None
    committed = False
    try:
        path, pack = details._paths(root, pack, allowed_packs)
        directory = _spec_directory(path.parent)
        lock_stack.enter_context(details.source_edit_lock(root, path))
        path, pack, raw, text, doc, index, node = details._load(root, pack, allowed_packs)
        if _digest(raw) != expected_digest:
            raise details._Invalid("The source record changed while this form was open. Reload and review the current attachment before saving.")
        product, material = path.parent, doc["source_materials"][index]
        if existing_path:
            selected = _candidate(product, existing_path)
            value = _bytes(selected)
            if not isinstance(expected_file_digest, str) or _digest(value) != expected_file_digest:
                raise details._Invalid("The selected workbook changed after it was listed. Reload the form and review the current file.")
        else:
            _filename(upload_name)
            selected, value = None, upload_bytes
        validation = validate_workbook(value)
        current = _current_path(root, product, pack, material)
        identical_current = bool(current and current.is_file() and material.get("sha256") == validation["sha256"]
                                 and _digest(_bytes(current)) == validation["sha256"])
        if identical_current and (selected is None or selected == current):
            return {**_describe_loaded(root, path, pack, raw, doc, index), "changed": False, "workbook": validation}
        if _needs_reset(material) and confirm_reset is not True:
            raise details._Invalid("Confirm replacement: the prior scientific review, AI access classification and revision details will be cleared for this workbook.")
        directory.mkdir(exist_ok=True)
        _spec_directory(product)
        if selected is None:
            selected, exists = _upload_target(directory, upload_name, validation["sha256"])
            if not exists:
                with tempfile.NamedTemporaryFile(mode="wb", prefix=".spec-upload-", suffix=".tmp", dir=directory, delete=False) as handle:
                    temporary_upload = Path(handle.name)
                    handle.write(value)
                    handle.flush()
                    os.fsync(handle.fileno())
                # Hard-link publication is atomic and refuses an occupied name on
                # both Windows and POSIX; unlike replace/rename it cannot overwrite.
                _safe(selected, directory)
                os.link(temporary_upload, selected)
                owned_upload = selected
                owned_identity = (selected.stat().st_dev, selected.stat().st_ino)
                temporary_upload.unlink()
                temporary_upload = None
        changes = {"path_or_link": selected.relative_to(product).as_posix(), "sha256": validation["sha256"],
                   "status": "pending", "why_provisional": _FACTUAL_PENDING}
        changes.update({field: "" for field in RESET_FIELDS if field in material})
        replacement, resulting_doc = review._edited(text, doc, index, node, changes, pack)
        with tempfile.NamedTemporaryFile(mode="wb", prefix=".spec-attachment-", suffix=".tmp", dir=product, delete=False) as handle:
            temporary_record = Path(handle.name)
            handle.write(replacement)
            handle.flush()
            os.fsync(handle.fileno())
        os.chmod(temporary_record, path.stat().st_mode)
        result = _describe_loaded(root, path, pack, replacement, resulting_doc, index)
        final_path, final_pack, current_bytes, _text, _doc, _index, _node = details._load(root, pack, allowed_packs)
        if final_path != path or final_pack != pack or _digest(current_bytes) != expected_digest:
            raise details._Invalid("The source record changed during this save. Reload before attaching the workbook again.")
        _candidate(product, selected.relative_to(product).as_posix())
        if _digest(_bytes(selected)) != validation["sha256"]:
            raise details._Invalid("The workbook changed during registration. No source update was saved.")
        os.replace(temporary_record, path)
        temporary_record = None
        committed = True
        return {**result, "changed": True,
                "changed_fields": list(changes), "workbook": validation, "authenticated": False}
    except FileExistsError:
        return _failure("Another source edit or upload is in progress. Wait for it to finish, then reload the attachment form.")
    except (details._Invalid, OSError, ValueError, TypeError, UnicodeError, yaml.YAMLError, RecursionError) as error:
        return _failure(str(error) if isinstance(error, details._Invalid) else "The workbook could not be attached safely. The existing source record was retained.")
    finally:
        for temporary in (temporary_record, temporary_upload):
            if temporary is not None:
                try:
                    temporary.unlink(missing_ok=True)
                except OSError:
                    pass
        if owned_upload is not None and not committed:
            try:
                checked = _safe(owned_upload, directory)
                stat = checked.stat()
                if (stat.st_dev, stat.st_ino) == owned_identity and _digest(_bytes(checked)) == validation["sha256"]:
                    checked.unlink()
            except (OSError, ValueError):
                pass
        lock_stack.close()
