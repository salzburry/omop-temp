"""A governed write from a DEPLOYED portal: a branch and a pull request, never a file on the app.

WHY. On Databricks Apps the portal's filesystem is disposable and the governed files live in git,
so "write it into this checkout" (the local demo's button) has nothing to write into. What a person
would do at a keyboard is: clone, run the stand-up, commit, push a branch, open a pull request that
CODEOWNERS routes for review, merge once reviewed. This module does exactly that and nothing else:
it never merges, never approves, never signs — the commit is the portal's, and the Gate 1 fields it
carries stay a person's to authenticate by signing the merge (approval_identity.py).

Pure functions over subprocess and urllib; the HTTP call is injectable so the pull request can be
tested against a stub, and the git half against a local bare repository.
"""
from __future__ import annotations

import json
import os
import re
import shutil
import subprocess
import tempfile
import urllib.request

BRANCH_RE = re.compile(r"^[A-Za-z0-9._/-]{1,120}$")


GIT_TIMEOUT = 120      # seconds for one local git command
CLONE_TIMEOUT = 600    # seconds for the shallow clone and the push over the network


def _timed_out(argv, seconds):
    """A CompletedProcess-shaped result for a command that ran out of time (never a hang in a spinner)."""
    return subprocess.CompletedProcess(argv, 124, "", f"{argv[0]} {argv[-1] if len(argv) > 1 else ''} did not finish within {seconds} seconds")


def _git(cwd, *args, env=None, timeout=GIT_TIMEOUT):
    argv = ["git", "-C", cwd, *args]
    try:
        return subprocess.run(argv, capture_output=True, text=True, encoding="utf-8", errors="replace",
                              env=env or os.environ, timeout=timeout)
    except subprocess.TimeoutExpired:
        return _timed_out(["git", *args], timeout)


def authed_url(remote: str, token: str | None) -> str:
    """The https remote with the token as the basic-auth user, or the remote untouched."""
    if token and remote.startswith("https://") and "@" not in remote.split("//", 1)[1].split("/", 1)[0]:
        return remote.replace("https://", f"https://x-access-token:{token}@", 1)
    return remote


def owner_repo(remote: str) -> str | None:
    m = re.search(r"github\.com[/:]([^/]+)/([^/]+?)(?:\.git)?/?$", remote)
    return f"{m.group(1)}/{m.group(2)}" if m else None


def clone_and_push(remote: str, token: str | None, branch: str, work, *, base: str = "main",
                   author: str = "RWD Portal <portal@rwdp.invalid>", message: str = "stand a product up from the portal"):
    """Clone `remote` at `base`, run `work(clone_dir) -> (rc, output)`, commit everything it wrote on
    `branch`, push. Returns (ok, output, commit_sha). Nothing is pushed when the work fails or writes
    nothing; the clone is removed either way."""
    if not BRANCH_RE.match(branch or "") or ".." in branch:
        return False, f"branch {branch!r} is not a usable name", None
    tmp = tempfile.mkdtemp(prefix="portal_write_")
    clone = os.path.join(tmp, "repo")
    try:
        clone_argv = ["git", "clone", "--quiet", "--branch", base, "--depth", "1", authed_url(remote, token), clone]
        try:
            r = subprocess.run(clone_argv, capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=CLONE_TIMEOUT)
        except subprocess.TimeoutExpired:
            r = _timed_out(["git", "clone"], CLONE_TIMEOUT)
        if r.returncode != 0:
            return False, "clone failed: " + (r.stderr or "").replace(token or "\x00", "***")[-800:], None
        rc, out = work(clone)
        if rc != 0:
            return False, out, None
        _git(clone, "checkout", "-q", "-b", branch)
        _git(clone, "add", "-A")
        if not _git(clone, "status", "--porcelain").stdout.strip():
            return False, out + "\n(nothing was written, so there is nothing to propose)", None
        name, email = author.split("<")[0].strip(), author.split("<")[1].rstrip(">").strip()
        c = _git(clone, "-c", f"user.name={name}", "-c", f"user.email={email}", "-c", "commit.gpgsign=false",
                 "commit", "-q", "-m", message)
        if c.returncode != 0:
            return False, out + "\ncommit failed: " + (c.stderr or "")[-400:], None
        sha = _git(clone, "rev-parse", "HEAD").stdout.strip()
        p = _git(clone, "push", "-q", "-u", "origin", branch, timeout=CLONE_TIMEOUT)
        if p.returncode != 0:
            return False, out + "\npush failed: " + (p.stderr or "").replace(token or "\x00", "***")[-800:], None
        return True, out, sha
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


def _http(url, data, headers):
    req = urllib.request.Request(url, data=json.dumps(data).encode("utf-8"), headers=headers, method="POST")
    with urllib.request.urlopen(req, timeout=60) as resp:
        return resp.status, json.loads(resp.read().decode("utf-8") or "{}")


def open_pull_request(remote: str, token: str, head: str, title: str, body: str, *, base: str = "main",
                      api_base: str = "https://api.github.com", http=_http):
    """(url, error) for the pull request that proposes `head` onto `base`."""
    repo = owner_repo(remote)
    if not repo:
        return None, f"{remote} is not a GitHub repository, so no pull request can be opened; the branch is pushed"
    try:
        status, doc = http(f"{api_base}/repos/{repo}/pulls", {"title": title, "head": head, "base": base, "body": body},
                           {"Authorization": f"Bearer {token}", "Accept": "application/vnd.github+json",
                            "Content-Type": "application/json", "User-Agent": "rwd-portal"})
    except Exception as e:  # noqa: BLE001 - the branch is pushed; the person can open the PR by hand
        return None, f"the pull request could not be opened ({e.__class__.__name__}); the branch {head} is pushed"
    if status not in (200, 201) or not doc.get("html_url"):
        return None, f"GitHub answered {status}: {str(doc.get('message') or doc)[:200]}; the branch {head} is pushed"
    return doc["html_url"], None
