"""Review actual checks, measure existing learners and activate exact local versions."""
import json
import streamlit as st
import model_lifecycle_workspace as workspace

LABELS = {
    'escalation_need_classifier': 'Should this question have been referred to a person?',
    'router_needs_more': 'Did the compared configuration avoid a mechanical failure in this check?',
    'critic_calibration': 'Was the recorded critic verdict correct after your review?',
}


def _conversation_evaluation(root, pack, actor_id, *, allowed_packs, local_demo, can_review):
    import conversation_evaluation as conversations
    import portal_jobs
    import portal_jobs_page
    st.markdown('**Evaluate a complete scientific conversation**')
    st.caption(conversations.NOTICE)
    permission = bool(local_demo and can_review)
    try:
        options = conversations.options(root, pack, actor_id, allowed_packs=allowed_packs)
        saved = conversations.recent(root, pack, actor_id, allowed_packs=allowed_packs)
    except (ValueError, OSError, KeyError, TypeError) as error:
        st.warning(str(error))
        return
    config = options['connection']
    st.caption('Results location: ' + options['storage'])
    if config.get('ok'):
        st.caption('Selected assistant: ' + config['provider'] + ' · ' + config['model'])
    else:
        st.info(config['errors'][0])
    st.write('Each journey asks a question, answers with a short choice, leaves a missing-evidence question unresolved, then changes the study intention. The checks inspect the actual private brief and validated form proposals.')
    choices = {row['id']: row for row in options['cases']}
    selected = st.multiselect('Conversation journeys', list(choices), default=list(choices)[:conversations.MAX_SELECTED_CASES],
        format_func=lambda key: choices[key]['title'], max_selections=conversations.MAX_SELECTED_CASES, key='model_lifecycle_conversation_cases')
    job_key = 'scientific-conversations:' + pack
    portal_jobs_page.render(root, actor_id, action='conversation_evaluation', job_key=job_key,
        can_write=permission, allowed_packs=allowed_packs, key='model_lifecycle_conversation_job')
    if st.button('Preview conversation journeys', key='model_lifecycle_conversation_preview', disabled=not(selected and config.get('ok') and permission)):
        try:
            st.session_state['model_lifecycle_conversation_proposal'] = conversations.preview(root, pack, actor_id, selected, allowed_packs=allowed_packs)
            st.session_state['model_lifecycle_conversation_confirmed'] = False
        except (ValueError, OSError, KeyError, TypeError) as error:
            st.error(str(error))
    proposal = st.session_state.get('model_lifecycle_conversation_proposal')
    if proposal:
        stale = (proposal['connection'] != config or proposal['versions'] != options['versions']
                 or [r['case']['id'] for r in proposal['cases']] != selected)
        if stale:
            st.warning('The selected cases, connection or workflow files changed. Prepare a new preview.')
            st.session_state['model_lifecycle_conversation_confirmed'] = False
        with st.expander('Exact synthetic journeys, reference versions and review rubric'):
            st.json({'cases': proposal['cases'], 'versions': proposal['versions'], 'connection': proposal['connection']})
        st.caption('At most 12 selected-model calls, sequentially, with a 6-minute total check budget. An in-flight call has the existing adapter timeout and can finish after that budget. A failed turn stops that journey; the other selected journeys still run. Cancellation, changed inputs or connection failure stop the whole run. Unrun turns are recorded as skipped. No automatic retry or model switch. Subscription token usage and dollar costs may be unavailable.')
        confirmed = st.checkbox('Run these synthetic journeys with this connection and retain the exact bounded inputs and answers for review.', key='model_lifecycle_conversation_confirmed')
        if st.button('Run conversation journeys', key='model_lifecycle_conversation_run', disabled=not(permission and confirmed and not stale)):
            try:
                portal_jobs.start(root, actor_id, action='conversation_evaluation', job_key=job_key,
                    arguments={'pack': pack, 'proposal': proposal, 'confirmed': confirmed,
                        'local_demo': local_demo, 'can_review': can_review},
                    confirmed=confirmed, can_write=permission, allowed_packs=allowed_packs)
                st.session_state.pop('model_lifecycle_conversation_proposal', None)
                st.rerun()
            except (ValueError, OSError, KeyError, TypeError) as error:
                st.error(str(error))
    if saved['invalid_records']:
        st.error('Some retained conversation packets are unreadable or changed. Inspect the saved records before treating them as evidence.')
    for record in saved['records'][:5]:
        with st.expander(record['created_at'][:19] + ' · ' + record['connection']['model']):
            st.dataframe([{'Journey': r['case'], 'Mechanical result': r['status'], 'Calls': r['metrics']['total_calls']} for r in record['results']], hide_index=True)
            st.caption('Clinical quality: human review required. A mechanical pass is not a scientific approval. Compare models only when the case and input-version hashes match.')
            for case, entry in zip(record['cases'], record['runs']):
                st.write(case['case']['title'])
                st.write(case['case']['human_rubric'])
                st.json(entry['run']['conversation'])
            st.download_button('Download exact conversation evaluation packet', json.dumps(record, indent=2, ensure_ascii=False),
                file_name='conversation-evaluation-' + record['id'] + '.json', mime='application/json',
                key='model_lifecycle_conversation_download_' + record['id'])


def _case_evaluation(root, pack, actor_id, oid, report, *, allowed_packs, local_demo, can_review, permission):
    if oid == 'intake_elicitation_model':
        import reviewed_learning_page
        return reviewed_learning_page.render_intake(root, pack, actor_id, report, allowed_packs=allowed_packs,
            local_demo=local_demo, can_review=can_review, permission=permission)
    st.markdown('**Run the existing behaviour evaluation**')
    st.caption('Select up to three behaviour cases. Each keeps its declared product/reference scope and is scored by the existing evaluator. Software regressions are generated and unadjudicated; their linked UI/backend tests are separate evidence. No model matrix or provider switch is inferred.')
    try:
        options = workspace.case_options(root, pack, actor_id, allowed_packs=allowed_packs)
    except (ValueError, OSError, KeyError, TypeError):
        st.warning('The canonical cases or current connection are unavailable. Repair the corpus or check the selected assistant connection.')
        return None
    config = options['connection']
    if config['ok']:
        st.caption('Selected assistant: ' + config['provider'] + ' · ' + config['model'])
    else:
        st.info(config['errors'][0])
    group = st.selectbox('Case group', ['Human-authored cases', 'Reviewed workflow corrections', 'Development software regressions', 'Held-out software regressions'],
        key='model_lifecycle_case_group', help='Whole failure families are reserved together. A model behaviour score is not a human scientific label or evidence that the linked UI test ran.')
    split = {'Development software regressions': 'development', 'Held-out software regressions': 'heldout'}.get(group)
    def in_group(case):
        if split:
            return case.get('evidence_mode') == 'synthetic_software_regression' and case.get('split') == split
        if group == 'Reviewed workflow corrections':
            return case.get('evidence_mode') == 'reviewed_workflow_correction'
        return case.get('evidence_mode') not in {'synthetic_software_regression', 'reviewed_workflow_correction'}
    choices = {row['case']['id']: row for row in options['cases'] if in_group(row['case'])}
    if group == 'Reviewed workflow corrections':
        st.info('These familiar examples come from explicitly enabled workflow corrections. They are regression examples, not unseen holdouts. Review whether the response follows the correction; a passing outcome code does not establish semantic correctness.')
    if split == 'heldout':
        st.info('These families are reserved from development runs. Repeated evaluation is a retest, not newly unseen evidence. Use the same scored cases when comparing a future model.')
    if any(item not in choices for item in st.session_state.get('model_lifecycle_cases', [])):
        st.session_state['model_lifecycle_cases'] = []
        st.session_state.pop('model_lifecycle_case_proposal', None)
        st.session_state['model_lifecycle_case_run_confirmed'] = False
    selected = st.multiselect('Cases to evaluate', list(choices), max_selections=3, key='model_lifecycle_cases')
    if not choices:
        st.info('No cases in this group are accessible in this product/reference scope. The corpus retains its source context; it is not silently rewritten for this product.')
    if st.button('Preview the exact cases and connection', key='model_lifecycle_case_preview', disabled=not(selected and config['ok'] and permission)):
        try:
            st.session_state['model_lifecycle_case_proposal'] = workspace.preview_cases(root, pack, actor_id, oid, selected, allowed_packs=allowed_packs)
            st.session_state['model_lifecycle_case_run_confirmed'] = False
        except (ValueError, OSError, KeyError, TypeError) as error:
            st.error(str(error))
    proposal = st.session_state.get('model_lifecycle_case_proposal')
    if proposal:
        stale = proposal['objective_id'] != oid or [r['case']['id'] for r in proposal['cases']] != selected or proposal['connection'] != config or proposal['corpus_digest'] != options['corpus_digest']
        if stale:
            st.session_state['model_lifecycle_case_run_confirmed'] = False
            st.warning('The cases or connection changed. Prepare a new preview before any model call.')
        for row in proposal['cases']:
            with st.expander(row['case']['id'] + ' · ' + ', '.join(row['packs'])):
                if row['case'].get('evidence_mode') == 'synthetic_software_regression':
                    st.caption('Generated software regression · ' + row['case']['split'] + ' · family: ' + row['case']['family'] + '. Not training eligible.')
                    st.code('\n'.join(row['case']['source_tests']), language='text')
                elif row['case'].get('evidence_mode') == 'reviewed_workflow_correction':
                    st.caption('Reviewed workflow correction · ' + row['case']['skill'] + '. Familiar regression example; not a training label or unseen holdout.')
                st.write(row['case']['goal'])
                st.json(row['case'].get('expect', {}))
                st.write(row['case'].get('adjudicate', 'Human review remains required.'))
        st.caption('Limit: up to 3 cases, 4 assistant calls and a 90-second check limit per case. A model call already in flight can finish after the check limit. Local subscription token and dollar usage are unavailable when the adapter does not report them.')
        confirmed = st.checkbox('Run these exact cases with this selected assistant and retain their mechanical scores on my branch.', key='model_lifecycle_case_run_confirmed')
        if st.button('Run the selected evaluation cases', key='model_lifecycle_case_run', disabled=not(permission and confirmed and not stale)):
            try:
                with st.spinner('Running the selected bounded cases and the existing mechanical scorer…'):
                    result = workspace.run_cases(root, pack, actor_id, proposal, confirmed=confirmed,
                        local_demo=local_demo, can_review=can_review, allowed_packs=allowed_packs)
                st.session_state.pop('model_lifecycle_case_proposal', None)
                return {'route': 'model_lifecycle', 'params': {'objective_id': oid, 'evaluation_id': result['id']}, 'changed': True}
            except (ValueError, OSError, KeyError, TypeError) as error:
                st.error(str(error))
    saved = [r for r in report['evaluations'] if r.get('record_type') == 'canonical_case_evaluation' and r['objective_id'] == oid]
    if saved:
        st.markdown('**Retained mechanical results**')
        for record in saved[:5]:
            with st.expander(record['created_at'] + ' · ' + record['connection']['model']):
                st.write(record['notice'])
                if record.get('stale_at_completion'):
                    st.warning('The selected connection or source changed during this request. These historical results require a fresh evaluation before review.')
                st.dataframe([{'Case': row['case'], 'Mechanical pass': row['passed'], 'Error': row.get('error') or '',
                    'Run': row.get('run', ''), 'Human adjudication': 'Still required'} for row in record['results']], hide_index=True)
                st.caption('Dollar cost: ' + (str(record['cost_usd']) if record['cost_usd'] is not None else 'unavailable from this connection'))
                st.download_button('Download exact scores and retained transcripts', json.dumps(record, indent=2), file_name=record['id'] + '.json', mime='application/json', key='model_lifecycle_case_download_' + record['id'])
                if st.button('Review these comparisons in the next check', key='model_lifecycle_case_continue_' + record['id']):
                    return {'route': 'governed_check', 'params': {'objective_id': oid, 'evaluation_id': record['id']}}
    return None


def render(root, pack, actor_id, *, allowed_packs, local_demo, can_write, can_review=False,
           route='model_lifecycle', params=None):
    params = params or {}
    context = (str(root), pack, actor_id, tuple(sorted(allowed_packs or [])), local_demo, can_review)
    if st.session_state.get('model_lifecycle_context') != context:
        for key in list(st.session_state):
            if key.startswith('model_lifecycle_'):
                del st.session_state[key]
        st.session_state['model_lifecycle_context'] = context
    st.subheader('Improve the assistant from reviewed checks')
    st.caption(workspace.NOTICE)
    try:
        import specification_details
        specification_details._paths(root, pack, allowed_packs)
    except (ValueError, OSError):
        st.warning('Choose a product or reference example within your access before opening its evaluations.')
        return None
    evaluation_view = st.radio('Evaluation workflow', ['Reviewed checks and improvements', 'Scientific conversations'],
        index=1 if str(pack).startswith('fixtures/') else 0, key='model_lifecycle_evaluation_view', horizontal=True)
    if evaluation_view == 'Scientific conversations':
        return _conversation_evaluation(root, pack, actor_id, allowed_packs=allowed_packs,
            local_demo=local_demo, can_review=can_review)
    import workflow_improvement_page
    with st.expander('Reusable improvements across all workflow skills', expanded=bool(params.get('correction_id'))):
        workflow_improvement_page.render_review(root, actor_id,
            can_review=bool(local_demo and can_review), can_write=bool(local_demo and can_write), key='lifecycle_review',
            pack=pack, allowed_packs=allowed_packs, local_demo=local_demo,
            correction_id=params.get('correction_id'), evaluation_id=params.get('evaluation_id'))
    report = workspace.describe(root, pack, actor_id, allowed_packs=allowed_packs)
    if not report['ok']:
        st.warning(report['errors'][0])
        if st.button('Go to product progress', key='model_lifecycle_progress'):
            return {'route': 'progress', 'params': {}}
        return None
    if report['invalid_records']:
        st.error(f"{report['invalid_records']} saved record(s) are unreadable or changed. Inspect the branch files before another save.")
    if st.session_state.get('model_lifecycle_input_digest') != report['digest']:
        for key in list(st.session_state):
            if key.startswith('model_lifecycle_') and (key.endswith('_confirmed') or '_confirm_' in key):
                st.session_state[key] = False
        st.session_state['model_lifecycle_input_digest'] = report['digest']
    permission = bool(local_demo and can_review and not report['invalid_records'])
    objects = {o['id']: o for o in report['objectives']}
    objects['mapping_candidate_ranker'] = {'question': 'Does the existing mapping ranker improve ordering on reviewed, source-disjoint cases?',
        'status': 'local technical evaluation', 'what_would_release_it': 'Independently reviewed mapping decisions, reserved source families and a measured improvement over the deterministic baseline. Activation is not provided by this comparison.',
        'evaluation': {'development_cases': 30, 'heldout_cases': 10, 'source_families_disjoint': True}}
    initial = params.get('objective_id')
    if 'model_lifecycle_objective' not in st.session_state and initial in objects:
        st.session_state['model_lifecycle_objective'] = initial
    oid = st.selectbox('What should the existing learner improve?', list(objects),
        format_func=lambda value: value.replace('_', ' ').capitalize(), key='model_lifecycle_objective')
    objective = objects[oid]
    st.write(objective['question'])
    with st.expander('Existing objective and evidence requirements'):
        st.write(objective['what_would_release_it'])
        st.json(objective['evaluation'])
    st.caption('Shared registry status: ' + objective['status'] + '. Local activation below applies to this product and does not rewrite that registry.')
    if oid == 'mapping_candidate_ranker':
        import reviewed_learning_page
        return reviewed_learning_page.render_mapping(root, pack, actor_id, report, allowed_packs=allowed_packs,
            local_demo=local_demo, can_review=can_review, permission=permission)
    if oid not in workspace.train_all.REVIEWED_OBJECTIVES:
        return _case_evaluation(root, pack, actor_id, oid, report, allowed_packs=allowed_packs,
            local_demo=local_demo, can_review=can_review, permission=permission)
    st.markdown('**1 · Review an actual completed check**')
    st.caption('Run a metadata-only check using your selected assistant, then record what a person found. Scripted, reference-pack and legacy transcripts do not count as reviewed real-work evidence.')
    if st.button('Run a check with the selected assistant', key='model_lifecycle_new_check'):
        return {'route': 'governed_check', 'params': {'objective_id': oid}}
    runs = {r['id']: r for r in report['runs']}
    if not runs:
        st.info('No eligible completed checks are available for this product. Start a governed check above after the source-access review; return here to review its recorded result.')
    else:
        key = 'model_lifecycle_run_' + oid
        if key not in st.session_state and params.get('run_id') in runs:
            st.session_state[key] = params['run_id']
        if st.session_state.get(key) not in runs:
            st.session_state.pop(key, None)
        run_id = st.selectbox('Completed check', list(runs), format_func=lambda value: runs[value]['goal'][:100] + ' · ' + runs[value]['model'], key=key)
        prefix = 'model_lifecycle_label_' + oid + '_' + run_id
        try:
            source = workspace.preview_run(root, pack, actor_id, run_id, allowed_packs=allowed_packs)
        except (ValueError, OSError, KeyError, TypeError):
            st.warning('This check changed or was removed while the page was opening. Refresh the current product checks.')
            return None
        st.caption(f"Recorded provider: {runs[run_id]['provider']} · Model: {runs[run_id]['model']}")
        st.write(source['outcome']['summary'])
        with st.expander('Inspect the exact transcript, metrics and local execution receipt'):
            st.json(source)
        comparison = None
        if oid == 'router_needs_more':
            st.info('Run this exact case with another explicitly selected model against unchanged inputs, then compare the outcomes. Repeated calls to the same model do not supply the required comparison.')
            options = [r for r in runs if r != run_id]
            comparison = st.selectbox('Comparison check from another model', options, index=None, key=prefix + '_comparison')
            if st.button('Record comparisons across models', key=prefix + '_compare'):
                return {'route': 'governed_check', 'params': {'objective_id': oid, 'run_id': run_id, 'goal': source['goal']}}
        if oid == 'critic_calibration':
            critics = workspace.runtime.critic_verdicts(source)
            if len(critics) == 1:
                st.json(critics[0])
            else:
                st.info('This check needs exactly one recorded critic verdict for calibration review. Open a single specialist check, then return with its completed evidence.')
        answer = st.radio(LABELS[oid], ['Yes', 'No', 'Not sure yet'], index=None, key=prefix + '_answer')
        reviewer = st.text_input('Reviewed by', key=prefix + '_person', help='Enter the person who reviewed this exact check; this is local attribution, not authentication.')
        date = st.text_input('Review date (YYYY-MM-DD)', key=prefix + '_date')
        rationale = st.text_area('What supports your answer?', key=prefix + '_rationale', max_chars=3000,
            help='Describe the observed result and the independent reasoning for your label. Do not infer correctness from the assistant outcome alone.')
        confirmed = st.checkbox('I reviewed this real work and want to record this label on my branch.', key=prefix + '_confirmed')
        if st.button('Save reviewed label', key=prefix + '_save', disabled=not(permission and confirmed and answer in {'Yes', 'No'} and reviewer and date and rationale)):
            try:
                record = workspace.save_label(root, pack, actor_id, run_id, oid, answer == 'Yes', reviewer, date, rationale,
                    expected_digest=report['digest'], comparison_run_id=comparison, confirmed=confirmed,
                    local_demo=local_demo, can_review=can_review, allowed_packs=allowed_packs)
                return {'route': 'model_lifecycle', 'params': {'objective_id': oid, 'run_id': run_id}, 'changed': True}
            except (ValueError, OSError, KeyError, TypeError) as error:
                st.error(str(error))
    st.markdown('**2 · Measure the existing learner**')
    labels = workspace._selected(report, oid)
    st.write(f'{len(labels)} reviewed check(s) available. Evaluation uses at most 60 independent cases.')
    st.caption('The existing binary trainer requires at least 30 labels, both classes and leave-one-out accuracy above the majority baseline. Calibration requires 30 verdicts in each observed confidence bucket and uses the existing Wilson rule.')
    measure = st.checkbox('Evaluate these current review records and save the measured result on this branch.', key='model_lifecycle_measure_confirm_' + oid)
    if st.button('Run the canonical evaluation', key='model_lifecycle_measure_' + oid, disabled=not(permission and measure)):
        try:
            with st.spinner('Measuring the current reviewed cases; no assistant call is made…'):
                result = workspace.evaluate(root, pack, actor_id, oid, expected_digest=report['digest'], confirmed=measure,
                    local_demo=local_demo, can_review=can_review, allowed_packs=allowed_packs)
            return {'route': 'model_lifecycle', 'params': {'objective_id': oid, 'evaluation_id': result['id']}, 'changed': True}
        except (ValueError, OSError, KeyError, TypeError) as error:
            st.error(str(error))
    versions = {r['id']: r for r in report['evaluations'] if r['objective_id'] == oid}
    active = next((r for r in report['activations'] if r['objective_id'] == oid), None)
    if active and active['enabled']:
        st.info('Recorded local activation: ' + active['evaluation_id'] + '. Current records are checked again before each suggested next action.')
        stop = st.checkbox('Stop using this learned version for subsequent checks.', key='model_lifecycle_stop_confirm_' + oid)
        if st.button('Deactivate local version', key='model_lifecycle_stop_' + oid, disabled=not(permission and stop)):
            try:
                workspace.deactivate(root, pack, actor_id, oid, expected_digest=report['digest'], confirmed=stop,
                    local_demo=local_demo, can_review=can_review, allowed_packs=allowed_packs)
                return {'route': 'model_lifecycle', 'params': {'objective_id': oid}, 'changed': True}
            except (ValueError, OSError, KeyError, TypeError) as error:
                st.error(str(error))
    if not versions:
        return None
    st.markdown('**3 · Review and activate an exact measured version**')
    key = 'model_lifecycle_evaluation_' + oid
    requested = params.get('evaluation_id')
    if requested in versions and st.session_state.get('model_lifecycle_requested_evaluation') != requested:
        st.session_state[key] = requested
        st.session_state['model_lifecycle_requested_evaluation'] = requested
    if st.session_state.get(key) not in versions:
        st.session_state.pop(key, None)
    evaluation_id = st.selectbox('Saved evaluation', list(versions), key=key)
    version = versions[evaluation_id]
    st.json(version['measurement']['evaluation'])
    for finding in version['measurement']['findings']:
        st.write(finding)
    st.caption('Exact version: ' + version['sha256'])
    st.download_button('Download the measured record and model', json.dumps(version, indent=2),
        file_name=evaluation_id + '.json', mime='application/json', key='model_lifecycle_download_' + evaluation_id)
    if not version['measurement']['evaluation'].get('accepted'):
        st.info('This version did not meet the existing evidence rule. Review more independent checks or correct labels, then evaluate again.')
        return None
    prefix = 'model_lifecycle_activation_' + evaluation_id
    person = st.text_input('Activation reviewed by', key=prefix + '_person')
    date = st.text_input('Activation review date (YYYY-MM-DD)', key=prefix + '_date')
    notes = st.text_area('Why is this measured result suitable for this product?', key=prefix + '_notes', max_chars=3000)
    confirmed = st.checkbox('Use this exact version for suggested next actions after this product’s completed checks.', key=prefix + '_confirmed')
    st.caption('Activation re-runs the canonical measurement and binds the exact records. It never changes the selected assistant, a scientific decision or a release gate.')
    if st.button('Activate this measured version for this product', key=prefix + '_save', disabled=not(permission and confirmed and person and date and notes)):
        try:
            with st.spinner('Rechecking the exact measured version…'):
                workspace.activate(root, pack, actor_id, evaluation_id, person, date, notes, expected_digest=report['digest'],
                    confirmed=confirmed, local_demo=local_demo, can_review=can_review, allowed_packs=allowed_packs)
            return {'route': 'model_lifecycle', 'params': {'objective_id': oid, 'evaluation_id': evaluation_id}, 'changed': True}
        except (ValueError, OSError, KeyError, TypeError) as error:
            st.error(str(error))
    return None
