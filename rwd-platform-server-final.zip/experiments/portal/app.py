"""The local RWD product application and its explicit hosted identity boundary.

THE DESIGN HEURISTIC, ENFORCED BY STRUCTURE: deterministic retrieval and status interactions never
invoke an LLM — the status, questions, packets, search, gates and eval tabs are direct calls into
the same closed tool registry the MCP server and the orchestrator use, so "what gate is prostate
at" costs a tool call and nothing else. Model requests are explicit: the Agent tab,
the Resume button on the Escalations tab (§20 — the person's answer as context), and
optional selected-row suggestions in the scientific definition editor. Row suggestions
have no tools and enter a private draft only when the drafter selects them. Separate local forms transcribe explicitly entered document details
and scientific answers; they never infer a decision or authenticate an approval.

Heavy compute stays out of this process by construction: the gate buttons run the same `--check`
and report commands CI runs (bounded, no cluster), and anything bigger belongs to Databricks Jobs
in the deployed shape. The same file deploys as a Databricks App later (see app.yaml); nothing
here reads a secret except from the environment.

Run locally: use Start-RwdPortal.cmd, or set RWD_PORTAL_LOCAL_WORKSPACE=1,
              then `streamlit run experiments/portal/app.py --server.address=127.0.0.1`. Without it the app REFUSES: no
              platform forwarded a principal, and it does not assume who you are (audit 6).
              A run started on the Agent tab is capped (RWD_PORTAL_MAX_STEPS, default 10;
              RWD_PORTAL_RUN_CEILING_USD, default 0.25; RWD_PORTAL_MAX_SECONDS, default 180 —
              each validated by limits.caps) and the working box says so.
"""
from __future__ import annotations

import json
import shlex
import subprocess
import contextlib
import os
import re
import sys
import threading
import time

import streamlit as st

HERE = os.path.dirname(os.path.abspath(__file__))

# LOCAL SECRETS: experiments/portal/.env (gitignored) is read into the process environment at
# startup — KEY=value lines, no quoting, no export. This exists so a key never lands in a
# TRACKED file (launch configs are committed; .env never is). On Databricks Apps this whole
# block is inert: the platform injects the environment and no .env ships.
_envp = os.path.join(HERE, ".env")
if os.path.exists(_envp):
    with open(_envp, encoding="utf-8") as _fh:
        for _line in _fh:
            _line = _line.strip()
            if _line and not _line.startswith("#") and "=" in _line:
                _k, _v = _line.split("=", 1)
                os.environ.setdefault(_k.strip(), _v.strip())
ROOT = os.path.dirname(os.path.dirname(HERE))
# THE ONE DIRECTORY THIS APP WRITES (audit 8): the roster, the snapshot, and through the agent's
# state module the runs, candidates and kept requests. Unset, the portal's own directory.
STATE_DIR = os.path.realpath(os.environ.get("RWDP_STATE_DIR") or HERE)
sys.path.insert(0, os.path.join(ROOT, "experiments", "agent"))
# A TOOL CALL MADE FROM A CHAT IS SHORT. The agent's live tools shell out with a 300 s timeout;
# inside a chat turn a single live portfolio computation held the page for ten minutes under
# disk load (2026-09-03). The portal caps each tool call at 90 s (settable) — a call that needs
# longer returns a timeout observation and the person runs it on the Run gates tab instead.
os.environ.setdefault("RWD_TOOL_TIMEOUT_S", "90")

import tools  # noqa: E402  (the closed registry: MCP read surface + precedents + capabilities)
import intake  # noqa: E402  (one model call per turn, no tools — the typed request by domain)
import jobs  # noqa: E402  (the governed loop in a background thread the page polls)
import control_plane  # noqa: E402  (governance/ACTIONS.yaml + OBJECTIVES.yaml: who acts, what is released)
import state as agent_state  # noqa: E402  (where runs, candidates and kept requests live: RWDP_STATE_DIR)
import search_view  # noqa: E402  (search hits grouped for the page; pure)
import walkthrough  # noqa: E402  (workbook → pack → configuration → validation → build → gates, from the files)
sys.path.insert(0, os.path.join(ROOT, "platform", "tools"))
import flow as flow_engine  # noqa: E402  (the gates in order, the current gate's blockers with owner and fixes; re-derives nothing)
sys.path.insert(0, HERE)
import identity  # noqa: E402  (who is using the portal: a forwarded principal, or a labelled demo)
import theme  # noqa: E402  (the palette, the type pair, the pills — pure, tested without a browser)
import stage_model  # noqa: E402  (the six stages, one vocabulary for every progress surface; pure)
import snapshot_policy  # noqa: E402  (which snapshot errors are waivable: a commit mismatch only)
import limits  # noqa: E402  (the run caps, validated — a bad variable is a message, not a traceback)
import ui_text as ui  # noqa: E402  (every sentence the page shows, in plain language)
import portal_packs  # noqa: E402  (the packs on offer, discovered from the registries; products vs references)
import session_drafts  # noqa: E402  (form values survive navigation, isolated by person)
import portal_runtime  # noqa: E402  (bounded commands return an actionable result on failure)
import document_page  # noqa: E402  (scoped document previews instead of broken local web links)
import decision_answer_page  # noqa: E402
import connected_workflow  # noqa: E402
import connected_workflow_page  # noqa: E402
import assistant_connection_page  # noqa: E402

st.set_page_config(page_title="RWD Portal", page_icon="🧬", layout="wide")
# THE IDENTITY, ONCE PER PAGE. .streamlit/config.toml themes Streamlit's own widgets; this block
# styles what the theme cannot reach: the sidebar as a navigation rail, the type pair, the metric
# cards, the gate pills. The only unsafe_allow_html on this page renders fragments theme.py
# escapes — page text is never markup.
st.markdown(theme.css(), unsafe_allow_html=True)


@st.cache_resource(show_spinner=False)
def _warm():
    """ONCE PER PROCESS, OFF THE REQUEST PATH: the search validators (cached by tree stamp) and the
    embedding index are paid for in a background thread at startup, so the first question a
    person asks is not the one that pays eleven seconds of validation."""
    threading.Thread(target=tools.warm, name="rwdp-warm", daemon=True).start()
    return True


_warm()

# THE PACKS ON OFFER ARE DISCOVERED, NOT TYPED (ninth review: five literal fixture paths, one of
# them superseded). Products are the default view; reference fixtures are an explicit opt-in and
# carry a persistent badge; templates and superseded versions are never offered.
_CAT = portal_packs.catalogue(ROOT)
PACKS = _CAT["products"] + _CAT["references"]          # everything a roster entry may be assigned to
import demo_journey  # noqa: E402  (offer rehearsals only when their input files are installed)
_HAS_DEMO_EXAMPLES = any(item["available"] for item in demo_journey.catalogue(ROOT))


@st.cache_data(ttl=120, show_spinner=False)
def cached(scope_key: tuple, tool: str, **args) -> str:
    """Deterministic tool call, cached briefly — a status page should not re-run the tool on
    every widget interaction, and 120s staleness is honest for a read of committed state.
    THE SCOPE IS PART OF THE KEY (independent review of audit 8): st.cache_data is process-wide
    across sessions and keyed on the arguments alone, so a search filtered for one actor was
    served verbatim to every other actor asking the same words within 120 s. `scope_key` is the
    actor's sorted pack membership, and the call is confined to it explicitly, never through the
    context a cached function does not see."""
    return tools.call(tool, args, scope=set(scope_key))


@st.cache_data(ttl=120, show_spinner=False)
def _search_hits(query: str) -> list:
    """Structured hits for the page renderer. Scope is NOT part of this key on purpose: it is applied
    to the result by `search_view.group` on every call, so a cached list never leaks across actors."""
    sys.path.insert(0, os.path.join(ROOT, "platform", "tools"))
    import knowledge_search as ks  # noqa: PLC0415
    terms = [w for w in str(query or "").split() if w]
    return ks.search(terms, root=ROOT) if terms else []


@st.cache_data(ttl=600, show_spinner=False)
def _known_variables(pack_: str) -> set:
    """The contract's variable ids for a pack — so a request may name one where the prompt offers
    'or which contract variable already defines it'. From the naming registry; empty on any error."""
    try:
        sys.path.insert(0, os.path.join(ROOT, "platform", "tools"))
        import naming_registry  # noqa: PLC0415
        out = set()
        for name, rec in naming_registry.registry().items():
            if pack_ in (rec.get("packs") or {}):
                out.add(name.upper())
                out.update(str(v).upper() for v in rec.get("variable_ids") or [])
        return out
    except Exception:  # noqa: BLE001 - a missing registry means no variable stands in for a code
        return set()


def live(tool: str, **args) -> str:
    """Uncached: for the gate buttons, where 'run it NOW' is the point."""
    return tools.call(tool, args)


def _bounded(argv: list, timeout_s: int, **env) -> str:
    """One bounded subprocess at the repository root — the same command CI and the demo run, its
    output shown as printed; a timeout is reported, never swallowed."""
    if (globals().get("ACTOR", {}).get("packs") and "--check-receipts" in argv
            and argv and os.path.basename(argv[0]) == "source_manifest.py"):
        return "This receipt check covers all products. Ask a data expert with portfolio access to run it and provide this product's result."
    # portal_runtime.run stops the whole process tree on timeout, so nothing the check spawned
    # can keep writing after the person has been told it failed.
    r = portal_runtime.run([sys.executable, *argv], cwd=ROOT, timeout_s=timeout_s, extra_env=env)
    failure = portal_runtime.failure_kind(r)
    if failure == "timeout":
        return f"This check exceeded {timeout_s}s. Your draft is retained. Try again or give the check details to your data expert."
    if failure == "start":
        reason = r.stderr.split("(", 1)[1].split(")", 1)[0]
        return f"The check could not start ({reason}). Your data expert can check the runtime installation."
    out = ((r.stdout or "") + (r.stderr or "")).strip() or "(no output)"
    # the process-tree stop echoes one line per child it ended; that is the runner's housekeeping,
    # not the check's result (walk NEW-6)
    out = "\n".join(line for line in out.splitlines()
                    if not line.startswith("SUCCESS: The process with PID") and not line.startswith("ERROR: The process")).strip() or "(no output)"
    return out + f"\n\nexit {r.returncode}"


def _validate_config(pack_: str) -> str:
    """platform/engine/validate.py on the pack: lint, then strict — the refusals a scientist owes an answer to."""
    tool = os.path.join("platform", "engine", "validate.py")
    return "== lint ==\n" + _bounded([tool, pack_], 300) + "\n\n== strict ==\n" + _bounded([tool, pack_, "--strict"], 300)


def _unbound_settings(pack_: str) -> tuple:
    """(count, keys) of settings still carrying the scaffold placeholder — the reason a fresh product
    cannot build yet, said before any Spark starts (walk RW1-12). Empty when the configuration cannot be
    read: the build's own refusal then says why."""
    sys.path.insert(0, os.path.join(ROOT, "platform"))
    try:
        from engine.config import load_config  # noqa: PLC0415
        from engine import validate as _validate  # noqa: PLC0415
        cfg = load_config(os.path.join(ROOT, pack_, "config", "data_product.yaml"))
        rows = [line for line in _validate.problems(cfg, strict=True) if _validate.PLACEHOLDER in line]
    except Exception:  # noqa: BLE001
        return 0, []
    keys = [line.split(" ", 1)[0] for line in rows]
    return len(rows), keys


def _synthetic_build(pack_: str) -> str:
    """local_smoke.py on synthetic sources — a LOCAL DEMO act only, bounded; never Gate 3 or Gate 5 evidence."""
    # 1800 s: the prostate reference took 860 s on this class of laptop, and a bound equal to the
    # typical duration lost the result (walk RW-06, 2026-09-07)
    import heavy_runtime_queue
    # Interactive pages have no background-job Cancel control. Bound their queue
    # wait while retaining the existing cancellable queue for background callers.
    interactive = not portal_runtime.has_job_callbacks()
    acquired = {"value": False}
    began = time.monotonic()
    callback_token = (portal_runtime.job_callbacks(cancelled=lambda: not acquired["value"] and time.monotonic() - began >= 30)
                      if interactive else None)
    def waiting():
        if interactive:
            st.info("Another local heavy check is running. Waiting up to 30 seconds for its slot; if it remains busy, retry after that check finishes.")
    def ready():
        acquired["value"] = True
    try:
        with heavy_runtime_queue.lease(on_wait=waiting, on_acquired=ready):
            return _bounded([os.path.join("platform", "tools", "local_smoke.py"), pack_], portal_runtime.timeout("RWD_PORTAL_BUILD_TIMEOUT_S", 1800))
    except heavy_runtime_queue.Cancelled:
        return "The synthetic build was cancelled or its queue wait expired. No new build result was recorded. Retry explicitly when the local heavy-check slot is available."
    except (OSError, ValueError):
        return "The local heavy-check queue could not grant this build a slot. Review the current queued action, then retry; no new build result was recorded."
    finally:
        if callback_token is not None:
            portal_runtime.reset_job_callbacks(callback_token)


@st.cache_data(ttl=600, show_spinner=False)
def _spark_ready() -> tuple:
    """(ready, why) from doctor's own local-Spark verdict — the page never guesses at a JVM."""
    sys.path.insert(0, os.path.join(ROOT, "platform", "tools"))
    try:
        import doctor  # noqa: PLC0415
        verdict = doctor._spark_runtime()
        return verdict[0] == doctor.OK, str(verdict[2])
    except Exception as _e:  # noqa: BLE001
        return False, f"doctor could not decide ({_e})"


USERS_PATH = os.path.join(STATE_DIR, "users.json")

# GENERIC FUNCTION ROLES, not departments (operator decision: department-wise roles are
# problematic — org labels move, functions don't). The governance OWNERS are separate and
# untouched: an escalation still routes to whoever answers science or registers artifacts in
# governance/WORKFLOW.md; a portal role only says what THIS user may do in THIS app. Permissions
# are DECLARED DATA so deployment binds the same table to authenticated identity. Local authoring
# permissions do not authenticate scientific approvals or release signatures.
PERMISSIONS = {
    "viewer":        {"view"},
    "initiator":     {"view", "agent", "queue", "start", "pin", "answer"},
    "qc_programmer": {"view", "run_gates", "evals", "queue", "start"},
    "reviewer":      {"view", "agent", "evals", "queue", "pin", "answer"},
    "admin":         {"view", "agent", "run_gates", "evals", "queue", "manage_users", "start", "pin", "answer", "review"},
}
# `pin`: the Studies section's write. A study pins a product and decides, per contract variable,
# what it reuses or reconsiders (study_pin.py, the bound action). The scientist's roles hold it; the
# QC programmer reads the studies and does not decide for one.
# `answer`: explicitly entered scientific answers to existing issued forms. Local saves validate
# their question and record bindings; the resulting register still requires named authentication.
# `start`: the New product section. It previews the stand-up command, and in a LOCAL demo — the
# person's own checkout — it runs `new_product.py --apply`, the bound action in
# governance/ACTIONS.yaml, which stages a copy, validates it and writes a SCAFFOLD: no approval,
# no answer, no promotion, which stay a person's acts. Deployed, the portal owns no checkout and
# hands over the command instead. The initiator is by name the person who starts things
# (2026-09-04: an admin on the pushed branch could not create a product from the portal).
# `queue`: the escalation queue and the evidence packets — READ surfaces over the agent's exhaust
# (runs/, candidates/). Resuming an escalation with an answer additionally needs `agent`, because
# it invokes a model; recording that answer is never a portal act.
ROLES = list(PERMISSIONS)


MODE = identity.mode(os.environ)
DEVELOPMENT = os.environ.get(identity.DEVELOPMENT_ENV) == "1"
LOCAL_WORKSPACE = MODE == "local"
LOCAL_DEMO = MODE == "demo"
LOCAL_WRITES = MODE in {"local", "demo"}


def _users() -> list[dict]:
    if LOCAL_WORKSPACE:
        return [identity.local_user(ROOT)]
    if os.path.exists(USERS_PATH):
        with open(USERS_PATH, encoding="utf-8") as fh:
            return json.load(fh)
    return identity.default_users(LOCAL_WRITES, os.environ.get("RWD_PORTAL_BOOTSTRAP_ADMIN"))


def _save_users(users: list[dict]):
    identity.save_users(USERS_PATH, users)     # creates RWDP_STATE_DIR when it does not exist yet


st.sidebar.title("RWD Portal")

# RBAC OVER A RESOLVED IDENTITY. Deployed, the platform forwards the authenticated principal and
# the actor is the roster entry it matches — nothing else. Locally, RWD_PORTAL_LOCAL_WORKSPACE=1 turns
# the picker on and labels it: attribution for a demo, never authentication. With neither, the
# app stops here. A typed answer can be captured by its explicit local form; a typed
# name is never a signature and cannot authenticate an approval or authorize promotion.
users = _users()
if DEVELOPMENT:
    import development_profile_page
    development_profile_page.render(USERS_PATH, users, enabled=True)
names = [u["name"] for u in users]
try:
    _headers = dict(st.context.headers)          # Databricks Apps forwards the principal here
except Exception:  # noqa: BLE001 - no request context (older Streamlit, bare import)
    _headers = {}
_chosen = st.sidebar.selectbox(ui.WORKING_AS, names,
                               key="who") if LOCAL_DEMO and names else None
ACTOR, _why = identity.resolve(_headers, users, LOCAL_DEMO, _chosen, local_workspace=LOCAL_WORKSPACE)
if ACTOR is None:
    st.sidebar.error(_why)
    st.error(ui.access_denied(_why))
    st.stop()
if LOCAL_WORKSPACE:
    st.sidebar.caption("Local workspace · " + ACTOR["name"])
elif DEVELOPMENT:
    st.sidebar.caption("Development demo · " + (ACTOR.get("email") or ACTOR["name"]))
st.session_state["_portal_profile"] = {"name": ACTOR["name"], "email": ACTOR.get("email", "")}
PERMS = PERMISSIONS.get(ACTOR["role"], {"view"})
if ACTOR["role"] == "reviewer":
    PERMS = PERMS | {"review"}
session_drafts.preserve(st.session_state, ACTOR.get("email") or ACTOR["name"])


def can(perm: str) -> bool:
    return perm in PERMS


# PROJECT MEMBERSHIP (operator ask): a user sees only the packs they are assigned to, in the
# picker and the portfolio alike. `packs: []` means ALL — the admin's view, and what membership
# means before anyone assigns it. This filters VISIBILITY in this app, nothing else: the
# repository itself remains the source of truth and is not access-controlled by a prototype.
MY_PACKS = [p for p in PACKS if not ACTOR.get("packs") or p in ACTOR["packs"]]
if not MY_PACKS and ACTOR.get("packs"):
    st.sidebar.error(ui.NO_PACKS)
    st.stop()
# THE ENTRY POINT COMES FIRST. Starting a product used to sit under a view, a pack and a section:
# a person had to pick a reference fixture to reach it, and with no products the Products view
# stopped the page (2026-09-04). Now: one button at the top for the roles that may start one,
# ONE picker with the products first and the references after, and a checkout with no products
# opens on the New product page.
for _k in ("pack", "section"):
    _v = st.session_state.pop(f"{_k}_suggested", None)
    if _v:
        st.session_state[_k] = _v
        if _k == "pack" and _v in _CAT["references"]:
            st.session_state["show_reference_examples"] = True
if can("start") and st.sidebar.button(ui.START_PRODUCT, key="nav_new", type="primary", width="stretch"):
    st.session_state["section"] = "New product"
_products = [p for p in MY_PACKS if p in _CAT["products"]]
_references = [p for p in MY_PACKS if p in _CAT["references"]]
_show_references = bool(_references) and (not LOCAL_WORKSPACE or st.sidebar.toggle("Browse reference examples", key="show_reference_examples"))
if st.session_state.get("pack") in _references and not _show_references:
    st.session_state.pop("pack", None)
_offered = _products + (_references if _show_references else [])
if not _offered and not can("start"):
    st.sidebar.caption(ui.NO_PACKS_IN_VIEW)
    st.markdown(theme.section_title("Nothing to show yet", ui.NO_PACKS_MAIN), unsafe_allow_html=True)
    st.stop()
if not _products:
    st.sidebar.caption(ui.NO_PRODUCTS_YET if _references else ui.NO_PRODUCTS_START)
st.session_state.setdefault("section", "Home")
pack = st.sidebar.selectbox(ui.PICK_PACK if _references else "Product", _offered, key="pack", format_func=lambda p: portal_packs.label(p, _CAT)) if _offered else ""
VIEW = "Products" if pack in _CAT["products"] else "Reference library"
BADGE = portal_packs.badge(pack, _CAT)
# SCOPE, ENFORCED WHERE THE READ HAPPENS: every tool call from this page — the deterministic
# sections and the agent alike — refuses a pack outside this actor's membership (audit 7:
# membership filtered the selector only, and a prostate-only reviewer could read ovarian).
tools.set_pack_scope(set(MY_PACKS))
SCOPE_KEY = tuple(sorted(MY_PACKS))            # the cache key's scope half
if pack and VIEW != "Products":
    st.sidebar.caption(ui.FIXTURES_NOTE)

# SECTIONS, NOT TABS. Streamlit tabs execute EVERY tab's code on every interaction — eight
# sections' worth of registry reads, queue scans and renders per click, which is what "clunky"
# felt like (operator, 2026-09-03) — and a chat input inside a tab renders inline instead of
# pinned. One section runs per interaction; the Agent section's input pins to the page bottom.
SECTIONS = ["Home", "Flow", "Status", "Open questions", "Search & definitions", "Plan changes", "Studies", "New product", "Waiting on a person",
            "Run gates", "Walkthrough", "Evidence packets", "Agent", "Eval corpus"]
# THE SHAPE OF A PRODUCT PORTAL (2026-09-04): a HOME that lists the products with their progress and
# next step, a product page with its own navigation across the top, and one way to start a product.
# The scientist's five sections are the navigation; the operator's five sit behind one toggle. The
# internal names stay — every section test pins them — and the labels are a person's words.
MAIN_SECTIONS = ["Home", "Flow", "Status", "Open questions", "Search & definitions", "Plan changes", "Studies", "New product"]
MORE_SECTIONS = [s for s in SECTIONS if s not in MAIN_SECTIONS]
_more = st.sidebar.toggle(ui.MORE_TOGGLE, key="more_sections",
                          value=st.session_state.get("section") in MORE_SECTIONS)
_offered_sections = MAIN_SECTIONS + (MORE_SECTIONS if _more or st.session_state.get("section") in MORE_SECTIONS else [])
if not pack:
    _offered_sections = ["Home", "New product"]
    if st.session_state.get("section") not in _offered_sections:
        st.session_state["section"] = "Home"
# ONE NAVIGATION, IN THE ORDER A PRODUCT MOVES (2026-09-07): the product's pages first, the
# technical tools after the toggle; the radio is styled as a rail (theme.css) and its label hidden.
st.sidebar.markdown(theme.navhead(ui.NAV_PRODUCT if pack else ui.NAV_START), unsafe_allow_html=True)
section = st.sidebar.radio("Workspace", _offered_sections, key="section",
                   format_func=lambda s: ui.SECTION_LABELS.get(s, s))
if section != "Flow":
    st.session_state.pop("flow_dialog", None)
    st.session_state.pop("flow_dialog_feedback", None)
# WHO YOU ARE AND THE ASSISTANT sit BELOW the navigation: a person reads where they can go before
# they read the fine print about their identity (the rail used to open with three paragraphs).
with st.sidebar:
    assistant_connection_page.render(ROOT, ACTOR.get("email") or ACTOR["name"], local_demo=LOCAL_WRITES)
    if LOCAL_WORKSPACE and pack in _products and st.button("Save work to my branch", key="sidebar_branch_changes"):
        connected_workflow_page.open_route("branch_changes", pack, ACTOR.get("email") or ACTOR["name"])
    _improvement_slot = st.container()
with st.sidebar.expander(ui.ABOUT_IDENTITY):
    # WHO THIS IS, in a person's words (walk UC4-01, 2026-09-07): the demo label carried the environment
    # variable on every page; the identity module keeps its own line for the technical reader
    st.caption(ui.DEMO_IDENTITY_NOTE.format(name=ACTOR["name"])
               if LOCAL_DEMO and not identity.principal(_headers) else _why)
    st.caption(ui.role_line(ACTOR['role'], sorted(PERMS)))
    st.caption(ui.SIDEBAR_READS_ONLY)
_DOC_SCOPE = set(MY_PACKS) if ACTOR.get("packs") else None
_DOC_CONTEXT = (ACTOR.get("email") or ACTOR["name"], pack, section)


def _source_link(target, *, key, label="Open source", source_path="", inline=False):
    document_page.reference(ROOT, target, key=key, label=label, source_path=source_path,
                            allowed_packs=_DOC_SCOPE, context=_DOC_CONTEXT, inline=inline)


def _document_markdown(text, *, key, source_path=""):
    return document_page.markdown(ROOT, text, key=key, source_path=source_path,
                                  allowed_packs=_DOC_SCOPE, context=_DOC_CONTEXT)
if _more and can("manage_users") and not LOCAL_WORKSPACE:
    with st.sidebar.expander("Manage users (admin)"):
        nn = st.text_input("New user name", key="new_user_name")
        nr = st.selectbox("Role", ROLES, key="new_user_role")
        ne = ""
        if not LOCAL_WRITES:
            # DEPLOYED, THE ROSTER MATCHES THE FORWARDED PRINCIPAL: a person added by display name
            # alone was refused at login (thirteenth pass, J5); the panel asks for the e-mail
            ne = st.text_input(ui.PRINCIPAL_LABEL, key="new_user_email", help=ui.PRINCIPAL_HELP).strip().lower()
        if st.button("Create user") and nn.strip():
            if nn.strip() in names:
                st.warning(ui.NAME_EXISTS)
            elif not LOCAL_WRITES and not ne:
                st.warning(ui.PRINCIPAL_HELP)
            else:
                users.append({"name": nn.strip(), "role": nr, **({"email": ne} if ne else {})})
                _save_users(users)
                st.rerun()
        st.divider()
        eu = st.selectbox("Assign role to", names, key="edit_user")
        # WIDGETS KEYED BY THE PERSON: with one key the previous person's role and packs stayed in
        # the widgets when another was picked, and Assign wrote them onto that person (thirteenth
        # pass, J5). A key per person starts every widget from that person's own roster values.
        _cur = next((u for u in users if u["name"] == eu), {})
        er = st.selectbox("New role", ROLES, key=f"edit_role_{eu}",
                          index=(ROLES.index(_cur.get("role")) if _cur.get("role") in ROLES else 0))
        _assigned = _cur.get("packs") or []
        _keep, _gone = portal_packs.assigned_defaults(_assigned, PACKS)
        if _gone:
            st.caption(ui.packs_no_longer_offered(_gone))
        ep = st.multiselect("Assigned packs (none = all)", PACKS, default=_keep, key=f"edit_packs_{eu}",
                            format_func=lambda p: portal_packs.label(p, _CAT))
        # WHO MAY ANSWER FOR WHOM (audit 8): a question sent to Science is answered by someone the
        # roster records as owning Science; the resume checks it. A portal role is not ownership.
        eo = st.multiselect(ui.OWNS_LABEL, control_plane.owners(), default=_cur.get("owns") or [],
                            key=f"edit_owns_{eu}")
        if st.button("Assign"):
            for u in users:
                if u["name"] == eu:
                    u["role"] = er
                    u["packs"] = ep
                    u["owns"] = eo
            _save_users(users)
            st.rerun()
# A PAGE ABOUT THE SELECTED PACK, OR NOT. New product starts something that does not exist yet, so
# the selected pack's banner, counters and lifecycle strip are noise above its form (a person on
# the pushed branch: "why does starting a product appear under reference fixture", 2026-09-04).
PACK_PAGE = section not in ("New product", "Home", "Plan changes")
if LOCAL_WRITES and BADGE and PACK_PAGE:
    # the reference/synthetic watermark belongs to a non-product pack; a real product in a local
    # demo carries the demo identity label in the sidebar, not "nothing here is a product"
    st.markdown(theme.watermark(), unsafe_allow_html=True)

# THE FOUR DETERMINISTIC FLOWS (status, ranked questions, escalation queue, evidence packets) are
# pure functions in queues.py; these tabs only render them. No model is invoked on any of them.
sys.path.insert(0, HERE)
import queues  # noqa: E402
RUNS_DIR = agent_state.RUNS                 # under RWDP_STATE_DIR when set
CANDIDATES_DIR = agent_state.CANDIDATES


# QUEUE READS ARE CACHED FOR 20 s: the escalation and packet scans glob and parse every run
# file, and they used to run again on every widget click. A resume clears them (below).
@st.cache_data(ttl=20, show_spinner=False)
def _esc_rows(runs_dir: str, to, pack, within=None):
    return queues.escalations(runs_dir, to, pack, within=within)


@st.cache_data(ttl=20, show_spinner=False)
def _packet_rows(cands: str, pack, within=None):
    return queues.packets(cands, pack, within=within)


@st.cache_data(ttl=20, show_spinner=False)
def _counts(page: str, runs_dir: str, cands: str, pack):
    return queues.queue_counts(page, runs_dir, cands, pack)

# THE HEADER STRIP: which pack, who, and the three numbers a person checks first — computed by
# the same pure functions, never by a model, and rendered as cards rather than a sentence in
# the sidebar (the operator called the page bland, 2026-09-03; the numbers were hard to find).
_hdr = None
# THE PRODUCT HEADER (2026-09-07): every page about the selected product opens with the same card:
# its name, the six stages in one strip, the next step in the Flow card's own words, and when it was
# last checked. It is filled after the snapshot is read (below) so the stages come from the freshest
# source: this session's evaluation, else the saved status report, else "not checked yet".
import assistant_layout
with assistant_layout.workspace(enabled=section != "Agent"):
    _header_slot = st.container() if pack and section not in ("New product", "Home") else None
    if section in ("Waiting on a person", "Evidence packets"):
        try:
            _hdr = _counts(cached(SCOPE_KEY, "open_questions", pack=pack), RUNS_DIR, CANDIDATES_DIR, pack)
            _q = int(_hdr.get("quarantined", 0) or 0)
            _cols = st.columns(4 if _q else 3)
            _cols[0].metric("open questions", _hdr["open_questions"])
            _cols[1].metric("waiting on a person", _hdr["escalations_open"])
            _cols[2].metric("evidence packets", _hdr["packets"])
            if _q:
                _cols[3].metric("set aside (malformed)", _q)
        except Exception as _e:  # noqa: BLE001 - a header count must never take the page down
            _hdr = None
            st.caption(ui.counts_unavailable(_e))

    SNAP_ENV = "RWDP_GOVERNANCE_SNAPSHOT"
    _snapshot_fallback = None


    class _NotAPackPage(Exception):
        """The strip is skipped on a page that is not about the selected pack."""


    def _snapshot():
        """(snapshot, note). The precomputed governance snapshot, verified against this checkout.

        THE LAG THIS EXISTS TO KILL, measured before it was written: `pack_status` computes for 44s
        and `portfolio` for 60s, because both run the full gate evaluation — which is exactly the
        VS Code-path lag the portal replaces. The repo already built the cure once (the job/serve
        split): a Job builds the snapshot (~4 min, all packs), readers load it in milliseconds. The
        portal is a reader. Live computation stays available, per pack, behind an explicit button.
        """
        global _snapshot_fallback
        path = portal_runtime.snapshot_path(ROOT, STATE_DIR, HERE)
        if os.path.isdir(path):
            return None, ui.snapshot_is_a_directory(path, SNAP_ENV)
        if not os.path.exists(path):
            return None, ui.no_snapshot(path, SNAP_ENV)
        sys.path.insert(0, os.path.join(ROOT, "platform", "tools"))
        import subprocess  # noqa: PLC0415
        import governance_snapshot as gs  # noqa: PLC0415
        try:
            commit = subprocess.run(["git", "rev-parse", "HEAD"], cwd=ROOT, capture_output=True,
                                    text=True, timeout=30).stdout.strip()
        except (OSError, subprocess.SubprocessError):
            # a machine without git (a scientist's laptop) still gets a page; the snapshot is then
            # served only when it needs no commit comparison
            commit = ""
        snap, errs = gs.load(path, ROOT, commit, allow_dirty=True)
        if not isinstance(snap, dict) or not isinstance(snap.get("provenance"), dict) or not isinstance(snap.get("packs"), dict):
            return None, "The status snapshot is malformed. A data expert can rebuild it; product authoring is still available."
        if not any(not snapshot_policy.COMMIT_MISMATCH.match(str(e).strip()) for e in errs):
            _snapshot_fallback = snap
        if errs:
            # ONLY A COMMIT MISMATCH IS WAIVABLE, and only when no governed path changed since the
            # snapshot's commit; a structural error (schema, packs, provenance) is never waived —
            # `schema: 999` with no packs was served as current (audit 7). snapshot_policy decides.
            GOVERNED = ("fixtures/", "products/", "platform/", "governance/", "refreshes/",
                        "releases/", "intake/", "resources/")
            snap_commit = str((snap or {}).get("provenance", {}).get("commit", ""))
            touched = ["<diff unavailable>"]
            if snap_commit and commit:
                try:
                    r = subprocess.run(["git", "diff", "--name-only", snap_commit, "HEAD"],
                                       cwd=ROOT, capture_output=True, text=True, timeout=60)
                except (OSError, subprocess.SubprocessError):
                    r = None
                if r is not None and r.returncode == 0:
                    touched = [l for l in r.stdout.splitlines() if l.startswith(GOVERNED)
                               and not l.startswith(("platform/tests/", "platform/engine-r/tests/"))]
            ok, why = snapshot_policy.accept(errs, touched)
            if ok:
                return snap, why
            structural = [e for e in errs if not snapshot_policy.COMMIT_MISMATCH.match(str(e).strip())]
            if st.session_state.get("accept_stale_snapshot") and not structural:
                return snap, ui.OLDER_SNAPSHOT + why
            return None, ui.SNAPSHOT_UNUSABLE + why
        return snap, None


    def _build_snapshot():
        sys.path.insert(0, os.path.join(ROOT, "platform", "tools"))
        import governance_snapshot as gs  # noqa: PLC0415
        import tempfile
        path = portal_runtime.snapshot_path(ROOT, STATE_DIR, HERE)
        _errors = gs.out_path_errors(path, root=os.path.realpath(ROOT))
        if _errors and not all(e.endswith(" does not exist") for e in _errors):
            st.error("The status snapshot needs a runtime folder outside the repository. "
                     "Ask your data expert to configure that location. " + " ".join(_errors))
            st.stop()
        os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
        _errors = gs.out_path_errors(path, root=os.path.realpath(ROOT))
        if _errors or os.path.isdir(path):
            st.error("The status snapshot destination is unavailable. " + " ".join(_errors))
            st.stop()
        snap = gs.build(ROOT)
        fd, pending = tempfile.mkstemp(prefix="snapshot_", suffix=".tmp", dir=os.path.dirname(os.path.abspath(path)))
        try:
            with os.fdopen(fd, "w", encoding="utf-8") as fh:
                json.dump(snap, fh)
            os.replace(pending, path)
        finally:
            if os.path.exists(pending):
                os.remove(pending)
        return path


    snap, note = _snapshot()


    def _edited_since(pack_: str, generated_at) -> bool:
        """True when a file of this pack changed after the saved status report was made (audit ST-02,
        2026-09-07): the report was built from the tree as it was then, so an in-portal edit since is
        not covered by its verdicts. Read from git's own list of changed files and their modification
        times; a machine without git, or a report with no timestamp, counts as edited when any file of
        the pack is changed at all, never as verified."""
        import datetime as _dt  # noqa: PLC0415
        import subprocess  # noqa: PLC0415
        try:
            r = subprocess.run(["git", "status", "--porcelain", "--untracked-files=all", "--", pack_], cwd=ROOT,
                               capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=30)
            lines = r.stdout.splitlines() if r.returncode == 0 else []
        except (OSError, subprocess.SubprocessError):
            return False
        changed = []
        for line in lines:
            path = line[3:].strip().strip('"').replace("\\", "/")
            rename_marker = " " + "-" + ">" + " "      # git's rename notation, never a person-facing string
            if rename_marker in path:
                path = path.split(rename_marker)[-1]
            changed.append(path)
        if not changed:
            return False
        try:
            text = str(generated_at or "").strip().replace("Z", "+00:00")
            made = _dt.datetime.fromisoformat(text)
            if made.tzinfo is None:
                made = made.replace(tzinfo=_dt.timezone.utc)
        except ValueError:
            return True
        for rel in changed:
            try:
                modified = _dt.datetime.fromtimestamp(os.path.getmtime(os.path.join(ROOT, rel)), _dt.timezone.utc)
            except OSError:
                return True      # deleted since: the report no longer describes the pack
            if modified > made:
                return True
        return False


    def _stage_rows(pack_: str):
        """(rows, next step, checked_at, source) for a pack: this session's evaluation first, else the
        saved status report (marked when the pack was edited after the report was made), else six
        unchecked stages. The header and the Home cards both use it."""
        result = (st.session_state.get("flow_result") or {}).get(pack_)
        if isinstance(result, dict) and result.get("gates") and not result.get("error"):
            rows = stage_model.from_flow(result)
            step = stage_model.next_step(ROOT, pack_, result)
            return rows, step, str(result.get("checked_at") or ""), "live"
        entry = (snap or {}).get("packs", {}).get(pack_) if snap else None
        if isinstance(entry, dict) and entry.get("gates"):
            rows = stage_model.from_snapshot(entry)
            step = {"title": queues.next_action_text(entry.get("next_action")), "summary": "", "owner": "", "gate": None,
                    "action_id": "", "known": bool(entry.get("next_action"))}
            made = ((snap or {}).get("provenance") or {}).get("generated_at")
            if _edited_since(pack_, made):
                return rows, step, ui.HEADER_FROM_SNAPSHOT_EDITED, "snapshot-edited"
            return rows, step, ui.HEADER_FROM_SNAPSHOT, "snapshot"
        return stage_model.from_flow(None), {"title": "", "summary": "", "owner": "", "gate": None, "action_id": "", "known": False}, "", "none"


    import form_assistance as form_help
    _setup_choices = None
    _setup_sheet_scope = None
    _setup_compatibility = None
    if section == "New product" and can("start"):
        try:
            _setup_choices = session_drafts.setup_choices(ROOT, MY_PACKS)
        except (OSError, ValueError, TypeError, KeyError, AttributeError, RecursionError) as _setup_choices_error:
            st.session_state.pop("np_previewed", None)
            import new_product_setup_errors
            new_product_setup_errors.metadata_failure(ROOT, ACTOR.get("email") or ACTOR["name"],
                _setup_choices_error, role=ACTOR["role"], permissions=PERMS, can_agent=can("agent"),
                local_demo=LOCAL_WRITES, allowed_packs=MY_PACKS)
            st.stop()
        import session_drafts_page
        session_drafts_page.render(ROOT, ACTOR.get("email") or ACTOR["name"], allowed_packs=MY_PACKS,
            can_write=LOCAL_WRITES and can("start"), choices=_setup_choices)
        import new_product_sheet_scope
        _setup_sheet_scope = new_product_sheet_scope.reconcile(st.session_state,
            new_product_sheet_scope.describe(ROOT, st.session_state,
                allowed_packs=MY_PACKS if ACTOR.get("packs") else None))
        import new_product_setup
        _setup_compatibility = new_product_setup.describe(ROOT, st.session_state, _setup_sheet_scope)
    import flow_page
    form_help.begin(ROOT, pack if section not in {"New product"} else "", ACTOR.get("email") or ACTOR["name"],
        page=section, route={"workspace": st.session_state.get(connected_workflow_page.KEY),
                             "step": st.session_state.get("flow_resolution_action"),
                             "setup_workbook": (_setup_sheet_scope or {}).get("binding")},
        allowed_packs=MY_PACKS, can_write=LOCAL_WRITES and any(can(permission) for permission in ("start", "answer", "run_gates", "review", "pin")),
        workflow_reader=flow_page.prefill_revision)
    with _improvement_slot:
        import workflow_improvement_page
        _improvement_actor = ACTOR.get("email") or ACTOR["name"]
        _improvement_route = workflow_improvement_page.current_route(ROOT, st.session_state,
            pack=pack, actor_id=_improvement_actor, section=section, allowed_packs=MY_PACKS)
        workflow_improvement_page.render_step(ROOT, _improvement_actor, _improvement_route,
            can_write=LOCAL_WRITES and (can("start") or can("answer") or can("run_gates")),
            can_review=LOCAL_WRITES and can("review"), scope=(pack, SCOPE_KEY),
            pack=pack, allowed_packs=MY_PACKS, local_demo=LOCAL_WRITES)

    if _header_slot is not None:
        _rows, _step, _checked, _source = _stage_rows(pack)
        with _header_slot:
            st.markdown(theme.product_header(
                portal_packs.label(pack, _CAT), _rows, badge=BADGE, actor=ACTOR["name"], role=ACTOR["role"],
                crumb=ui.SECTION_LABELS.get(section, section) if section != "Flow" else "",
                next_title=_step["title"] if _step["known"] else "", next_owner=_step.get("owner", ""),
                checked_at=_checked, unchecked_note=ui.HEADER_NOT_CHECKED), unsafe_allow_html=True)
            # THE GUIDE ON EVERY PRODUCT PAGE (2026-09-07): one assistant that knows the product, the stage,
            # the next step and this person's role, and offers the page's own buttons; a connected
            # assistant (the sidebar picker) answers over this same card, else the checks' own words
            import flow_assistant
            import flow_assistant_page
            _card = flow_assistant.context(
                label=portal_packs.label(pack, _CAT), section=ui.SECTION_LABELS.get(section, section), rows=_rows,
                step=_step if _step.get("known") else {}, result=(st.session_state.get("flow_result") or {}).get(pack),
                role=ACTOR["role"], perms=PERMS, can_review=can("review"))
            _workflow_context = st.session_state.get(connected_workflow_page.KEY)
            if connected_workflow.valid(_workflow_context, pack=pack, actor_id=ACTOR.get("email") or ACTOR["name"],
                                        section=section, allowed_packs=MY_PACKS):
                _current_task = connected_workflow.ROUTES[_workflow_context["route"]]
                _card["current_task"] = {"route": _workflow_context["route"], "title": _current_task.title, "purpose": _current_task.purpose,
                                         "variable": str((_workflow_context.get("params") or {}).get("variable") or "")[:100]}
                if _workflow_context["route"] == "progress" and (_workflow_context.get("params") or {}).get("action_id"):
                    _card["current_task"]["route"] = _workflow_context["params"]["action_id"]
            elif (section == "Flow" and (st.session_state.get("flow_dialog") or {}).get("pack") == pack
                  and (st.session_state.get("flow_dialog") or {}).get("actor") == (ACTOR.get("email") or ACTOR["name"])
                  and st.session_state.get("flow_resolution_action")):
                _card["current_task"] = {"route": str(st.session_state["flow_resolution_action"]), "title": "Current resolution step"}
            try:
                # the cut's place in its product's lineage (walk NC-14, 2026-09-07): a next cut says so
                _earlier_cuts = sorted(p for p in portal_packs.lineage(ROOT, pack) if p.rsplit("/", 1)[-1] < pack.rsplit("/", 1)[-1])
            except Exception:  # noqa: BLE001 - an unreadable registry never breaks the header
                _earlier_cuts = []
            if _earlier_cuts:
                st.caption(f"Next cut of {portal_packs.label(_earlier_cuts[-1], _CAT)}"
                           + (" (draft, not released)" if BADGE and "draft" in str(BADGE).lower() else "")
                           + ". Review what changed from the previous cut under Plan changes.")
            try:
                _later_cuts = sorted(p for p in portal_packs.lineage(ROOT, pack) if p.rsplit("/", 1)[-1] > pack.rsplit("/", 1)[-1] and p in MY_PACKS)
            except Exception:  # noqa: BLE001
                _later_cuts = []
            if _later_cuts:
                st.caption("A later cut of this product exists: " + ", ".join(portal_packs.label(p, _CAT) for p in _later_cuts)
                           + ". This cut stays what studies read until that one is released.")
            _guided_route = (_card.get("current_task") or {}).get("route", "")
            if _guided_route == "plan_changes" or (section == "Plan changes" and not _guided_route):
                _card = flow_assistant.plan_context(_card, root=ROOT, pack=pack,
                    actor_id=ACTOR.get("email") or ACTOR["name"], allowed_packs=MY_PACKS,
                    state=st.session_state, params=(_workflow_context or {}).get("params") if _guided_route == "plan_changes" else None)
            if _guided_route in {"source_requirements", "source_delivery", "source_evidence", "source_mapping"}:
                import source_workspace_page
                _source_chat = source_workspace_page.source_chat_context(ROOT, pack, ACTOR.get("email") or ACTOR["name"],
                    allowed_packs=MY_PACKS, route=_guided_route)
                if _source_chat.get("ok"):
                    _card.update(_source_chat["context"])
            if _guided_route in {"study_refresh", "study_protocol", "study_runs"}:
                import lifecycle_workspace_page
                _card.update(lifecycle_workspace_page.assistant_context(ROOT, pack, ACTOR.get("email") or ACTOR["name"],
                    allowed_packs=MY_PACKS, route=_guided_route, params=(_workflow_context or {}).get("params")))
            if _guided_route == "variable_review":
                import variable_review_workflow_page
                variable_review_workflow_page.begin_run()
                _card["variable_workflow"] = variable_review_workflow_page.assistant_context(
                    ROOT, pack, ACTOR.get("email") or ACTOR["name"], allowed_packs=MY_PACKS,
                    params=(_workflow_context or {}).get("params"))
            _dedicated_chat = _guided_route in {"scientific_draft", "g2_draft"}
            flow_assistant_page.render(ROOT, pack, card=_card, actor_id=ACTOR.get("email") or ACTOR["name"],
                                       primary=section != "Agent" and not _dedicated_chat, can_agent=can("agent"),
                                       local_demo=LOCAL_WRITES,
                                       can_write=LOCAL_WRITES and (can("start") or can("answer") or can("run_gates")), allowed_packs=MY_PACKS)
    elif section in {"Home", "New product"}:
        import flow_assistant
        import flow_assistant_page
        _home_rehearsal = bool(section == "Home" and LOCAL_WRITES and _HAS_DEMO_EXAMPLES and st.session_state.get("guided_demo_open")
            and st.session_state.get("guided_demo_actor") in (None, ACTOR["name"]))
        _home_product = pack if section == "Home" and pack in MY_PACKS and not _home_rehearsal else ""
        _home_rows, _home_step, *_ = _stage_rows(_home_product) if _home_product else ([], {}, "", "")
        _start_card = flow_assistant.context(label=portal_packs.label(_home_product, _CAT) if _home_product else "Product setup",
            section=ui.SECTION_LABELS.get(section, section), rows=_home_rows, step=_home_step,
            result=(st.session_state.get("flow_result") or {}).get(_home_product), role=ACTOR["role"], perms=PERMS, can_review=can("review"))
        if _home_rehearsal:
            import demo_journey_page
            _start_card = demo_journey_page.assistant_context(_start_card, ROOT,
                actor_id=ACTOR.get("email") or ACTOR["name"], local_demo=LOCAL_WRITES,
                can_write=can("start"), can_view=can("view"))
        elif not _home_product:
            _start_card["actions"] = ["open_new_product"] if can("start") else []
            _start_card = flow_assistant.setup_context(_start_card, mode=st.session_state.get("np_mode"), local_writes=LOCAL_WRITES,
                sheet_scope=_setup_sheet_scope)
            if _setup_compatibility:
                _start_card["setup_compatibility"] = new_product_setup.context(_setup_compatibility)
        else:
            _home_context = st.session_state.get(connected_workflow_page.KEY)
            if connected_workflow.valid(_home_context, pack=_home_product, actor_id=ACTOR.get("email") or ACTOR["name"],
                                        section=section, allowed_packs=MY_PACKS):
                _home_task = connected_workflow.ROUTES[_home_context["route"]]
                _start_card["current_task"] = {"route": _home_context["route"], "title": _home_task.title, "purpose": _home_task.purpose}
        flow_assistant_page.render(ROOT, _home_product, card=_start_card, actor_id=ACTOR.get("email") or ACTOR["name"],
            key=("fa_rehearsal_" + str((_start_card.get("rehearsal_form") or {}).get("run_id") or "new") + "_") if _home_rehearsal else flow_assistant_page.KEY,
            primary=True, can_agent=can("agent"), metadata_only=not bool(_home_product),
            local_demo=LOCAL_WRITES,
            can_write=LOCAL_WRITES and (can("start") or can("answer") or can("run_gates")), allowed_packs=MY_PACKS)
    try:
        if section != "Status":
            raise _NotAPackPage()
        _entry = (snap or {}).get("packs", {}).get(pack) if snap else None
        _kept_n = sum(1 for r in intake.load_requests() if str(r.get("pack") or "") == pack)
        _has_ev = os.path.exists(os.path.join(ROOT, pack, "handoff", "MAPPING_EVIDENCE.json")) \
            or queues.source_evidence_on_disk(os.path.join(ROOT, pack))
        # WITHOUT A SNAPSHOT THE FILES ARE THE FACTS: the record count is read from the contract itself
        # and a fixture is known from where it lives, so the strip never says "no extraction yet" or
        # "not built" about a pack nobody has evaluated (2026-09-04, a person on the pushed branch)
        _recs = queues.record_count(_entry) if _entry is not None else queues.records_on_disk(os.path.join(ROOT, pack))
        _rows = queues.extracted_rows(os.path.join(ROOT, pack))
        _is_fixture = (str((_entry or {}).get("kind") or "") == "fixture") if _entry is not None else bool(BADGE)
        with st.expander("Saved status report and evaluation tools"):
            # ONE VOCABULARY (2026-09-07): this expander drew an eight-step lifecycle strip with its own
            # words ('Brief', 'Source fitness', 'Candidate') beside the six stages the header shows, and
            # the two disagreed on the same pack. The header's stages are the product's progress; this
            # expander holds the saved report's provenance and the operator's tools.
            st.caption(ui.records_line(_recs) + (f"; {_rows} specification row(s) extracted" if _rows else "")
                       + (f"; {_kept_n} kept request(s)" if _kept_n else ""))
            if _entry is None:
                st.caption(ui.NO_SNAPSHOT_STRIP)
                if can("run_gates"):
                    # THE ACTS, WHERE THE GAP IS SEEN (2026-09-05: "but then you don't see gates"): a person
                    # reading "build it in Overview" under a strip of not-evaluated steps had to go find it
                    _g1, _g2 = st.columns(2)
                    if _g1.button(ui.compute_live(portal_packs.label(pack, _CAT)), key="strip_live"):
                        with st.spinner("running the full gate evaluation…"):
                            st.code(live("pack_status", pack=pack), language=None)
                    if _g2.button(ui.REBUILD_SNAPSHOT, key="strip_snapshot"):
                        with st.spinner("building the governance snapshot…"):
                            st.success(ui.built(_build_snapshot()))
                        st.rerun()
    except _NotAPackPage:
        pass
    except Exception as _e:  # noqa: BLE001 - the stepper is a summary, never a blocker
        st.caption(ui.stepper_unavailable(_e))
    if snap:
        # the AGENT gets the same fast path: its status tools answer from this snapshot in ms
        # (provenance labelled) instead of recomputing for 44-60s per call — the measured cause
        # of the first chat answer taking a minute. Installed whatever section is shown.
        tools.use_snapshot(snap, str(snap.get("provenance", {}).get("commit", ""))[:7])
    if not snap:
        # A REFUSED SNAPSHOT STILL BEATS A TEN-MINUTE LIVE COMPUTATION INSIDE A CHAT. The Status
        # tab keeps refusing it (a person reading gates deserves the verified view or an explicit
        # override), but the agent's two status tools answer from the stale file with its commit
        # and STALE in every line — the label is the honesty — and the person runs the Run gates
        # tab live when it matters (2026-09-03: a chat asking about a mistyped version sat on a
        # live portfolio computation with nothing to stop it).
        if _snapshot_fallback is not None:
            _sc = str(_snapshot_fallback["provenance"].get("commit", ""))[:7]
            tools.use_snapshot(_snapshot_fallback, f"{_sc} STALE snapshot, verify in Run gates")
        else:
            tools.use_snapshot(None)
    if connected_workflow_page.render_active(
        ROOT, pack, ACTOR.get("email") or ACTOR["name"], section=section, allowed_packs=MY_PACKS,
        local_demo=LOCAL_WRITES, can_write=can("start") or can("run_gates"), can_review=can("review"),
        can_view=can("view"), can_pin=can("pin"), can_answer=can("answer"), can_plan=can("start"), can_agent=can("agent"),
        can_manage_library=can("manage_users"),
        label=portal_packs.label(pack, _CAT) if pack else "", section_label=ui.SECTION_LABELS.get(section, section),
    ):
        form_help.finish()
        st.stop()

    if not _HAS_DEMO_EXAMPLES or section != "Home" or st.session_state.get("guided_demo_actor") not in (None, ACTOR["name"]):
        st.session_state.pop("guided_demo_open", None)
    if section == "Home":
        st.session_state["guided_demo_actor"] = ACTOR["name"]
        if LOCAL_WRITES and _HAS_DEMO_EXAMPLES:
            if st.session_state.get("guided_demo_open"):
                if st.button("Back to my products", key="home_demo_back"):
                    st.session_state["guided_demo_open"] = False
                    st.rerun()
                import demo_journey_page
                demo_journey_page.render(ROOT, actor_id=ACTOR.get("email") or ACTOR["name"],
                                         local_demo=LOCAL_WRITES, can_write=can("start"), can_view=can("view"))
                form_help.finish()
                st.stop()
        st.markdown(theme.section_title(ui.HOME_TITLE, "Open a product to see where it stands and what it needs next."), unsafe_allow_html=True)
        if pack and pack in MY_PACKS:
            if st.button("Open this product's workspace", key="home_product_workspace",
                         help="Define and reuse, plan changes, evaluate studies, or prepare a review."):
                connected_workflow_page.open_route("product_workspace", pack, ACTOR.get("email") or ACTOR["name"])
        if LOCAL_WRITES and _HAS_DEMO_EXAMPLES:
            # THE GUIDED DEMO IS A SIDE DOOR, NOT THE FRONT DOOR (2026-09-07): it sat above the page title.
            if st.button("Try the guided demo on a synthetic example", key="home_demo"):
                st.session_state["guided_demo_open"] = True
                st.rerun()
        if not _products:
            # THE FIRST-PRODUCT HERO (2026-09-07): an empty portfolio used to read as an error message
            # above a list of fixtures. It is the start of the journey, and says so.
            with st.container(border=True):
                st.markdown(theme.card_title(ui.HOME_HERO_TITLE), unsafe_allow_html=True)
                st.write(ui.HOME_HERO_TEXT)
                if can("start") and st.button(ui.START_PRODUCT, key="home_start", type="primary"):
                    st.session_state["section_suggested"] = "New product"
                    st.rerun()
                elif not can("start"):
                    st.caption(ui.HOME_EMPTY if _references else ui.HOME_EMPTY_NO_REFERENCES)
        for _row in range(0, len(_products), 3):
            _cols = st.columns(3)
            for _col, _p in zip(_cols, _products[_row:_row + 3]):
                _rows_p, _step_p, _checked_p, _source_p = _stage_rows(_p)
                _sum = stage_model.summary(_rows_p)
                with _col, st.container(border=True):
                    st.markdown(theme.card_title(portal_packs.label(_p, _CAT), _rows_p, _sum["line"]), unsafe_allow_html=True)
                    st.caption(ui.records_line(queues.records_on_disk(os.path.join(ROOT, _p))))
                    if _step_p["known"] and _step_p["title"]:
                        st.write(f"**Next:** {_step_p['title']}")
                    elif not _sum["checked"]:
                        st.caption(ui.HOME_CARD_UNCHECKED)
                    if st.button(ui.HOME_OPEN, key=f"open_{_p}"):
                        st.session_state["pack_suggested"] = _p
                        st.session_state["section_suggested"] = "Flow"
                        st.rerun()
        with st.expander("Questions across my products and saved work"):
            connected_workflow_page.links(("portfolio",), pack, ACTOR.get("email") or ACTOR["name"],
                                          key="home", label="Questions across my products")
            connected_workflow_page.recent_work(ROOT, pack, ACTOR.get("email") or ACTOR["name"], allowed_packs=MY_PACKS)
        if _references:
            with st.expander(ui.HOME_REFERENCES, expanded=not bool(_products) and not LOCAL_WORKSPACE):
                st.caption(ui.FIXTURES_NOTE)
                for _row in range(0, len(_references), 3):
                    _cols = st.columns(3)
                    for _col, _p in zip(_cols, _references[_row:_row + 3]):
                        _rows_p, _step_p, _checked_p, _source_p = _stage_rows(_p)
                        _sum = stage_model.summary(_rows_p)
                        with _col, st.container(border=True):
                            st.markdown(theme.card_title(portal_packs.label(_p, _CAT), _rows_p, _sum["line"]), unsafe_allow_html=True)
                            if st.button(ui.HOME_OPEN, key=f"open_{_p}"):
                                st.session_state["pack_suggested"] = _p
                                st.session_state["section_suggested"] = "Flow"
                                st.rerun()

    if section == "Flow":
        import flow_page

        if LOCAL_WRITES:
            import conversation_intake_page as _brief_handoff_page
            _brief_handoff_page.render_registration_handoff(ROOT, pack, ACTOR.get("email") or ACTOR["name"],
                allowed_packs=MY_PACKS, can_write=can("start") or can("answer") or can("run_gates"))

        # THE FIRST OPEN CHECKS THE PRODUCT (2026-09-07): a page that said "Check status to see what this
        # product needs next" and waited was the operator's console again. The evaluation runs once per
        # session per product (a spinner, up to a minute on a slow disk); Check status refreshes it.
        if pack not in (st.session_state.get("flow_result") or {}) and can("view") \
                and not st.session_state.get("flow_requested_action"):
            st.session_state["flow_requested_action"] = {"pack": pack, "actor": ACTOR.get("email") or ACTOR["name"], "action_id": None}

        # THE CONFIRMATION STAYS (walk NC-04, 2026-09-07): the first evaluation of a new product reruns this
        # section once; a flash popped before that rerun vanished. It is popped only once the evaluation
        # has landed, so the person reads it at least once, and it is gone when they come back later.
        _np_flash = st.session_state.get("np_flash")
        if _np_flash:
            st.success(_np_flash[0])
            # a first cut's next steps ride in the flash's third element; a next cut's message carries its
            # own, so nothing contradicts it (walk RW-02, 2026-09-07)
            _next_words = _np_flash[2] if len(_np_flash) > 2 else ui.NEW_PRODUCT_NEXT_STEPS
            if _next_words:
                st.info(_next_words)
            with st.expander("What the stand-up wrote (the tool's own report)"):
                st.code(_np_flash[1], language=None)
            if pack in (st.session_state.get("flow_result") or {}):
                st.session_state.pop("np_flash", None)
        # THE PREVIOUS CUT COMES FROM THE REGISTRY'S LINEAGE, not from this session (walk NC-09, 2026-09-07):
        # a reload used to lose the "what changed" link; the lineage list survives it
        _previous_cut = st.session_state.get("connected_previous_cut", {}).get(pack)
        if not _previous_cut:
            try:
                _earlier = [p for p in portal_packs.lineage(ROOT, pack) if p in MY_PACKS and p.rsplit("/", 1)[-1] < pack.rsplit("/", 1)[-1]]
            except Exception:  # noqa: BLE001 - an unreadable registry never breaks the page
                _earlier = []
            _previous_cut = max(_earlier, key=lambda p: p.rsplit("/", 1)[-1]) if _earlier else None
        if _previous_cut in MY_PACKS:
            connected_workflow_page.links(("revision_review",), pack, ACTOR.get("email") or ACTOR["name"],
                key="new_cut", params={"previous_pack": _previous_cut}, label="Review what changed in this specification cut", expanded=True)
        _had_result = pack in (st.session_state.get("flow_result") or {})
        flow_page.render(
            root=ROOT, pack=pack, label=portal_packs.label(pack, _CAT),
            actor_id=ACTOR.get("email") or ACTOR["name"], actor_name=ACTOR["name"],
            local_demo=LOCAL_WRITES, can_write=can("start") or can("run_gates"), can_view=can("view"),
            evaluate=lambda: flow_engine.flow(ROOT, pack, development=LOCAL_WRITES),
            run_action=lambda argv: _bounded(argv, portal_runtime.timeout("RWD_PORTAL_ACT_TIMEOUT_S", 600)),
            show_reference=_source_link,
            can_manage_users=can("manage_users"),
            can_review=can("review"),
            naming_packs=MY_PACKS,
            show_title=False,
        )
        if not _had_result and pack in (st.session_state.get("flow_result") or {}):
            st.rerun()        # the header above was drawn before the first evaluation landed; draw it once more

    if section == "Status":
        st.markdown(theme.section_title("Evidence overview", "Saved evidence for this product. Check current progress whenever its files change."), unsafe_allow_html=True)
        if st.button("Check current product", key="status_open_flow", type="primary"):
            with st.spinner("Checking current evidence…"):
                try:
                    _current_flow = flow_engine.flow(ROOT, pack, development=LOCAL_WRITES)
                except Exception as _error:
                    _current_flow = {"error": f"{type(_error).__name__}: {_error}"}
            st.session_state.setdefault("flow_result", {})[pack] = _current_flow
            st.session_state["section_suggested"] = "Flow"
            st.rerun()
        if snap:
            prov = snap.get("provenance", {})
            st.caption(ui.snapshot_line(str(prov.get('commit', ''))[:7], prov.get('generated_at', '?'), bool(prov.get('dirty'))))
            entry = snap.get("packs", {}).get(pack)
            if entry:
                st.subheader(f"Where {portal_packs.label(pack, _CAT)} stands")
                gates = entry.get("gates", [])
                st.markdown(theme.gate_table(gates), unsafe_allow_html=True)   # pills: colour AND word
                for g in gates:
                    if isinstance(g, dict) and g.get("blockers"):
                        with st.expander(ui.gate_blockers(g.get('gate'), g.get('name'), len(g['blockers']))):
                            for b in g["blockers"]:
                                st.write("•", b)
                na = entry.get("next_action")
                st.info(f"**Next action:** {queues.next_action_text(na)}")
            st.subheader("Portfolio")
            member = ACTOR.get("packs") or None      # None -> all (admin / unassigned-means-all)
            rows = [{"pack": k, "kind": v.get("kind"),
                     "next": queues.next_action_text(v.get("next_action"))[:120]}
                    for k, v in sorted(snap.get("packs", {}).items())
                    if member is None or k in member]
            st.caption(f"showing {len(rows)} pack(s)"
                       + ("" if member is None else f" assigned to {ACTOR['name']}"))
            st.dataframe(rows, width="stretch")
            if snap.get("unreadable"):
                st.warning(ui.unreadable(snap['unreadable']))
        else:
            st.info("No usable saved report is available. Choose Check current product above to continue.")
            with st.expander("Saved report details"):
                st.caption(note)
                st.checkbox("Show the older snapshot anyway (its commit stays in the banner)",
                            key="accept_stale_snapshot")
        if snap and note:
            st.warning(note)
        # the operator's two tools live in the expander above the title (one place, not two)
        if not can("run_gates"):
            st.caption(ui.STATUS_OPERATOR_NOTE)

    if section == "Open questions":
        st.markdown(theme.section_title("Questions to answer", "One question at a time, ranked by what each answer unblocks. Choose an answer or write your own; the named decision maker records it."), unsafe_allow_html=True)
        _question_report = connected_workflow.question_report(ROOT, pack, allowed_packs=MY_PACKS)
        _ranked_page = _question_report["page"]
        _ranked = queues.fill_owners(queues.ranked_questions(_ranked_page), _question_report["register"])
        if not _question_report["ok"]:
            st.warning(_question_report["error"])
        else:
            st.subheader(f"{len(_ranked)} open question(s), ranked by what each answer unblocks")
            if _ranked:
                st.caption("Start with the first one; the form below records the decision actually made.")
                st.dataframe([{"rank": q["rank"], "decision": q["id"], "unblocks": q["unblocks"], "owner": q["owner_display"]} for q in _ranked],
                             width="stretch", hide_index=True)
            else:
                st.info("No recorded questions are open. Check Progress and next step to see whether the specification and its review are ready.")
        if decision_answer_page.render(ROOT, pack, ACTOR.get("email") or ACTOR["name"],
                                       local_demo=LOCAL_WRITES, can_write=can("answer"), can_view=can("view"), actor_name=ACTOR["name"]):
            cached.clear()
            st.session_state.setdefault("flow_result", {}).pop(pack, None)
            st.session_state["questions_saved"] = {"pack": pack, "action": st.session_state.pop("decision_answer_last_action", "saved")}
            st.rerun()
        connected_workflow_page.links(("variable_lineage", "scientific_draft", "review_workbook"), pack,
            ACTOR.get("email") or ACTOR["name"], key="questions", label="Evidence and definitions for these questions")
        question_notice = st.session_state.pop("questions_saved", None)
        if isinstance(question_notice, dict) and question_notice.get("pack") == pack:
            if question_notice.get("action") == "prepared":
                st.success("Question drafts prepared. Choose a question above and draft your answer; no decision has been recorded.")
            else:
                st.success("Your answers were saved and the question list was refreshed. Complete the named review before using them as approved evidence.")
        page, ranked = _ranked_page, _ranked
        owners = sorted({q["owner_display"] for q in ranked})
        if not ranked:
            if st.button("Go to product progress", key="questions_open_flow"):
                st.session_state["section_suggested"] = "Flow"
                st.rerun()
        with st.expander("Evidence for one question, by owner"):
          owner = st.selectbox("Owner", ["any"] + owners, key="q_owner")
          top = next((q for q in ranked if owner == "any" or q["owner_display"] == owner), None)
          if top:
            _packet = cached(SCOPE_KEY, "decision_packet", pack=pack, decision_id=top["id"])
            _card = queues.question_card(top, _packet)
            st.markdown(ui.ask_now(top))
            _c1, _c2, _c3 = st.columns(3)
            _c1.metric("unblocks", _card["unblocks"])
            _c2.metric("evidence cited", _card["evidence_count"])
            _c3.metric("owner", _card["owner"])
            if _card["form"]:
                _source_link(_card["form"], key="question_form_source", label="Open this question's answer form")
            st.caption(ui.QUESTION_ACTIONS)
            st.code(_packet, language=None)
          did = st.text_input("Another decision's packet (id)", "")
          if did:
            st.code(cached(SCOPE_KEY, "decision_packet", pack=pack, decision_id=did), language=None)
        with st.expander(ui.WHOLE_PAGE):
            # the file's "GENERATED by ..." note is for whoever edits it, not for the reader (walk NEW-5)
            _document_markdown("\n".join(line for line in str(page).splitlines() if not line.startswith("GENERATED by ")),
                               key="question_register", source_path=f"{pack}/handoff/DECISIONS.md")

    if section == "Search & definitions":
        st.markdown(theme.section_title("Definitions and sources", "Match variables to the master library, review the science, then complete sources and outputs."), unsafe_allow_html=True)
        if st.button("Review the variable list", key="search_variable_review", type="primary"):
            connected_workflow_page.open_route("variable_review", pack, ACTOR.get("email") or ACTOR["name"], params={"phase": "science"})
        if st.button("Knowledge sources and definitions", key="search_knowledge_workspace"):
            connected_workflow_page.open_route("knowledge_explorer", pack, ACTOR.get("email") or ACTOR["name"])
        q = st.text_input("Search decisions, contracts, capabilities, literature", "")
        if q:
            # A PAGE, NOT A DUMP (2026-09-05): grouped by kind, records and decisions first, the
            # literature behind its count; the same scope rule the agent's renderer applies
            view = search_view.group(_search_hits(q), scope=set(SCOPE_KEY), pack_of=tools._pack_of)
            st.caption(view["banner"])
            if not view["groups"]:
                st.info(ui.NO_HITS)
            for _group_index, g in enumerate(view["groups"]):
                with st.expander(f"{g['title']} ({g['count']})", expanded=g["open"]):
                    for _hit_index, h in enumerate(g["hits"]):
                        st.markdown(f"**{search_view.md_escape(h['title'])}**  \n{search_view.md_escape(h['detail'])}")
                        st.caption(search_view.caption(h))
                        if h.get("where"):
                            _source_link(h["where"], key=f"search_source_{_group_index}_{_hit_index}")
            if view["more"]:
                st.caption(ui.more_hits(view["more"]))
            if view["dropped"]:
                st.caption(ui.dropped_hits(view["dropped"]))
        v = st.text_input("A variable's definition, in the contract's own words (e.g. ECOG)", "")
        connected_workflow_page.links(("variable_lineage", "definition_reuse", "clinical_standards", "definition_identity"),
            pack, ACTOR.get("email") or ACTOR["name"], key="search", params={"variable": v},
            label="Review this variable across the workflow")
        if v:
            st.code(cached(SCOPE_KEY, "definition", pack=pack, variable=v), language=None)
            _defn = cached(SCOPE_KEY, "definition", pack=pack, variable=v)
            if "treated" in v.lower() or "treated" in _defn.lower():       # the flag or a cohort labelled by it
                st.warning(ui.TREATED_NOTE)
        if st.toggle(ui.PRECEDENTS_TOGGLE):
            st.code(cached(SCOPE_KEY, "precedents", pack=pack), language=None)
        # THE DICTIONARY PREVIEW (audit item 7): what the product WOULD carry — every contract
        # variable with type, domain, status and rule — read from the contract, no build behind it
        if st.toggle(ui.DICTIONARY_TOGGLE):
            _document_markdown(cached(SCOPE_KEY, "dictionary", pack=pack), key="dictionary_sources",
                               source_path=f"{pack}/handoff/FUNCTIONAL_CONTRACT.md")

    if section == "Run gates":
        if not can("run_gates"):
            st.info(ui.no_gates(ACTOR['role']) + (" " + ui.DEMO_ROLE_HINT if LOCAL_DEMO else ""))
        else:
            st.markdown(theme.section_title("Run checks", "The same checks CI runs, on this product, with nothing written."), unsafe_allow_html=True)
            st.caption(ui.GATES_CAPTION)
            c1, c2, c3 = st.columns(3)
            if c1.button("Contract lint", width="stretch"):
                with st.spinner("running contract_lint…"):
                    st.code(live("lint", pack=pack), language=None)
            if c2.button("Spec-pipeline drift check", width="stretch"):
                with st.spinner("regenerating into a temp dir and comparing…"):
                    st.code(live("pipeline_check", pack=pack), language=None)
            if c3.button("Pilot readiness", width="stretch"):
                with st.spinner("running pilot_readiness…"):
                    st.code(live("readiness", pack=pack), language=None)
            c4, c5 = st.columns(2)
            if c4.button(ui.VALIDATE_CONFIG, width="stretch"):
                with st.spinner("checking the configuration (first the shape, then every value)…"):
                    st.code(_validate_config(pack), language=None)
            _sp_ok, _sp_why = _spark_ready()
            _unbound, _unbound_keys = _unbound_settings(pack) if LOCAL_WRITES else (0, [])
            _build_help = None if (LOCAL_WRITES and _sp_ok) else ui.build_disabled(LOCAL_WRITES, _sp_why)
            if _unbound:
                _build_help = ui.build_unbound(_unbound)
            if c5.button(ui.BUILD_SYNTHETIC, width="stretch", disabled=not (LOCAL_WRITES and _sp_ok and not _unbound), help=_build_help):
                with st.spinner("building on synthetic sources (local Spark)…"):
                    st.code(_synthetic_build(pack), language=None)
            if _unbound:
                st.info(ui.build_unbound(_unbound))
                with st.expander("Which settings"):
                    st.write("\n".join("- " + k for k in _unbound_keys))

    if section == "Walkthrough":
        # THE CHAIN AS A PAGE (2026-09-05: "I cannot run it end to end on the Streamlit app"): every
        # step's state from the pack's files, and the bounded act for the next one — the same commands
        # CI and the demo run. Approvals, answers and promotions stay a person's acts at a keyboard.
        if not can("run_gates"):
            st.info(ui.no_gates(ACTOR['role']) + (" " + ui.DEMO_ROLE_HINT if LOCAL_DEMO else ""))
        else:
            st.markdown(theme.section_title("Walkthrough", "One specification from workbook to gate verdicts, each step read from the product files."), unsafe_allow_html=True)
            st.caption(ui.WALKTHROUGH_CAPTION)
            _subject = pack
            if LOCAL_WRITES and os.path.isdir(os.path.join(ROOT, walkthrough.DEMO_PACK)):
                _choice = st.radio(ui.WALKTHROUGH_SUBJECT, [ui.WALKTHROUGH_SELECTED.format(pack=pack), ui.WALKTHROUGH_DEMO],
                                   horizontal=True, key="wt_subject")
                if _choice == ui.WALKTHROUGH_DEMO:
                    _subject = walkthrough.DEMO_PACK
            if _subject == pack:
                if st.button("Open Progress and next step", key="wt_progress", type="primary"):
                    st.session_state["section_suggested"] = "Flow"
                    st.rerun()
                st.caption("Continue the selected product's guided editors and current checks there. This page keeps the technical run details together.")
            else:
                st.info("This shared synthetic example demonstrates extraction and execution. To develop a product for your studies, start your own product draft.")
                if can("start") and st.button("Start my own product", key="wt_start_product"):
                    st.session_state["section_suggested"] = "New product"
                    st.rerun()
            st.session_state.setdefault("wt_last", {})
            _wt_owner = ACTOR.get("email") or ACTOR["name"]
            _last = st.session_state.wt_last.setdefault((_wt_owner, _subject), {})
            _sp_ok, _sp_why = _spark_ready()
            _entry_wt = (snap or {}).get("packs", {}).get(_subject) if snap else None
            for _stp in walkthrough.steps(ROOT, _subject, _sp_ok, _sp_why, LOCAL_WRITES, _entry_wt, _last):
                _c1, _c2 = st.columns([5, 2])
                _c1.markdown(f"{walkthrough.GLYPH[_stp['state']]} **{_stp['title']}**  \n{_stp['detail']}")
                _act = _stp["action"]
                if _act == "new_product":
                    if _c2.button(ui.WALKTHROUGH_GO_NEW, key=f"wt_np_{_stp['id']}"):
                        st.session_state["section_suggested"] = "New product"
                        st.rerun()
                elif _act == "validate":
                    if _c2.button(ui.VALIDATE_CONFIG, key="wt_validate"):
                        with st.spinner("validating…"):
                            _last["validate"] = _validate_config(_subject)
                        st.rerun()
                elif _act == "build":
                    if _c2.button(ui.BUILD_SYNTHETIC, key="wt_build"):
                        with st.spinner("building on synthetic sources (local Spark)…"):
                            _last["build"] = _synthetic_build(_subject)
                        st.rerun()
                elif _act == "evaluate":
                    # status.py, bounded, on THIS subject: the agent's pack_status tool is confined to the
                    # actor's membership by design, and the shipped demo pack is in nobody's; the
                    # selected pack is already the picker's, so a person who may run checks may read it
                    if _c2.button(ui.compute_live(_subject), key="wt_evaluate"):
                        with st.spinner("running the full gate evaluation…"):
                            try:
                                _wt_before = walkthrough.input_digest(ROOT, _subject)
                            except Exception:  # malformed input preparation must remain a visible finding
                                _last["gates"] = "The product inputs could not be read safely. Repair the source or configuration findings above, then evaluate again."
                                _last["gates_result"] = {"ok": False}
                            else:
                                _last["gates"] = _bounded([os.path.join("platform", "tools", "status.py"), _subject, "--json"], 300)
                                _last["gates_result"] = walkthrough.record_result(ROOT, _subject, _last["gates"], _wt_before)
                        st.rerun()
            for _k in ("validate", "build", "gates"):
                if _last.get(_k):
                    with st.expander(ui.WALKTHROUGH_OUTPUT.format(step=_k), expanded=(_k == "gates")):
                        st.code(_last[_k], language=None)

    if section == "Plan changes":
        connected_workflow_page.links(("revision_review", "change_impact", "template_review"), pack,
            ACTOR.get("email") or ACTOR["name"], key="changes", label="Compare the current product before proposing a change")
        import plan_changes_page
        plan_changes_page.render(ROOT, pack, actor_id=ACTOR.get("email") or ACTOR["name"],
                           local_demo=LOCAL_WRITES, can_write=can("start"), allowed_packs=MY_PACKS)

    if section == "Studies":
        # WHICH STUDIES READ THIS PRODUCT, AND HOW (2026-09-05: "what about knowledge retention and
        # segregating them"). The product's definitions stay one governed thing; each study's departures
        # are its own record under work/<study>/PINS.yaml, read here through the tool's own read surface
        # and written only by the bound tool, in a local demo, by a role that may pin.
        sys.path.insert(0, os.path.join(ROOT, "platform", "tools"))
        import study_pin  # noqa: PLC0415
        st.markdown(theme.section_title("Studies", "Which studies read this product, at which cut, and what each reuses or reconsiders."), unsafe_allow_html=True)
        st.caption(ui.STUDIES_CAPTION)
        if VIEW == "Products":
            connected_workflow_page.links(("study_protocol", "study_refresh", "study_runs", "feasibility", "dataset_comparison"),
                pack, ACTOR.get("email") or ACTOR["name"], key="studies", label="Continue the study workflow")
        # Widget values must not move between products or demo identities.
        _study_context = (ACTOR.get("email") or ACTOR["name"], pack)
        if st.session_state.get("_study_form_context") != _study_context:
            for _key in list(st.session_state):
                if str(_key).startswith(("pin_", "dec_", "refresh_", "study_new_")):
                    del st.session_state[_key]
            st.session_state["_study_form_context"] = _study_context
        _flash = st.session_state.pop("studies_flash", None)       # the tool's words from the write that just landed
        if _flash:
            st.success(_flash)
        if VIEW != "Products":
            st.info(ui.STUDIES_FIXTURE)
        else:
            _rows = study_pin.pins_for_product(pack, ROOT)
            if not _rows:
                st.info(ui.STUDIES_NONE)
            else:
                st.dataframe([{"study": r["study"], "cut": r["spec_version"], "build": r.get("build_id") or "(pack only)",
                               "status": r["status"], "reuse": r["reuse"],
                               "reconsider": r["reconsider"], "exclude": r["exclude"], "stale": "yes" if r["stale"] else "",
                               "build stale": "yes" if r.get("build_stale") else "",
                               "pinned by": r["pinned_by"], "on": r["pinned_date"]} for r in _rows], width="stretch")
                for r in _rows:
                    with st.expander(f"{r['study']}: {len(r['definitions'])} decision(s)"):
                        connected_workflow_page.links(("study_refresh", "study_protocol", "study_runs", "dataset_comparison"),
                            pack, ACTOR.get("email") or ACTOR["name"], key=f"study_{r['study']}",
                            params={"study": r["study"]}, label="Continue with this study")
                        if r["stale"]:
                            st.warning(ui.STUDIES_STALE)
                        if r.get("build_stale"):
                            st.warning(ui.STUDIES_BUILD_STALE)
                        if r["superseded"]:
                            st.warning(ui.STUDIES_SUPERSEDED)
                        if r["definitions"]:
                            # a plain table, not the canvas grid: a definition is read in full and copied, never truncated
                            st.table([{"variable": d.get("variable_id"), "decision": d.get("decision"), "why": d.get("why"),
                                       "definition": d.get("definition", ""), "decided by": d.get("decided_by"),
                                       "on": d.get("decided_date")} for d in r["definitions"]])
            if not can("pin"):
                st.caption(ui.no_pin(ACTOR["role"]) + (" " + ui.DEMO_ROLE_HINT if LOCAL_DEMO else ""))
            else:
                import datetime as _dt  # noqa: PLC0415
                import shlex  # noqa: PLC0415
                import subprocess  # noqa: PLC0415
                _PY = "python" if os.name == "nt" else "python3"
                _TOOL = os.path.join("platform", "tools", "study_pin.py")
                _work = os.path.join(ROOT, "work")
                if can("start"):
                    with st.expander("Start a study draft"):
                        st.caption("Create a place to record a study's protocol and product choices. "
                                   "Your scientific owner must complete and review the protocol before registration.")
                        _new_study = form_help.field(st.text_input, "Study identifier", key="study_new_id", placeholder="renal_outcomes")
                        if LOCAL_WRITES:
                            if st.button("Create study draft", key="study_create") and not re.fullmatch(r"[a-z][a-z0-9_-]{2,40}", _new_study.strip()):
                                st.warning(ui.STUDY_ID_RULE)
                            elif st.session_state.get("study_create"):
                                _res = portal_runtime.run([sys.executable, os.path.join(ROOT, "platform", "tools", "protocol_record.py"),
                                                           "--new", _new_study.strip()], cwd=ROOT, timeout_s=90)
                                if _res.returncode == 0:
                                    st.session_state["studies_flash"] = "Study draft created. You can record its product choices below; protocol review remains pending."
                                    st.rerun()
                                else:
                                    st.error((_res.stdout + _res.stderr).strip() or "The study draft could not be created.")
                        else:
                            st.info("Study registration is managed by your data expert in this deployment. "
                                    "Use Plan changes to include your study questions in a downloadable review brief.")
                _studies = sorted(d for d in os.listdir(_work)
                                  if os.path.isdir(os.path.join(_work, d)) and study_pin.study_kind(d, ROOT)) if os.path.isdir(_work) else []
                if not _studies:
                    st.caption(ui.STUDIES_NO_STUDIES if can("start") else ui.STUDIES_NO_STUDIES_ASK)
                else:
                    st.caption(ui.STUDIES_LOCAL if LOCAL_WRITES else ui.STUDIES_DEPLOYED)

                    def _pin_tool(argv):
                        """The bound tool, on this checkout; its exit and its words, never a function call."""
                        p = portal_runtime.run([sys.executable, os.path.join(ROOT, _TOOL), *argv, "--root", ROOT],
                                               cwd=ROOT, timeout_s=300)
                        return p.returncode, ((p.stdout or "") + (p.stderr or "")).strip()

                    def _plain_refusal(out):
                        """The tool's refusal in the person's words; its own text stays under details (walk NC-10)."""
                        text = str(out or "")
                        if "SCAFFOLD" in text or "status: scaffold" in text:
                            return "This product is not released yet, so a study cannot pin it. Studies pin a product once it is released (stage 6)."
                        if "not a study" in text or "no PROTOCOL" in text:
                            return "This study has no protocol record yet. Create the study draft first."
                        if "superseded" in text:
                            return "This product cut is superseded by a later one. Pin the current cut, or refresh the study's pin."
                        plain = []
                        if "--pinned-by is a placeholder" in text or "--reviewed-by is a placeholder" in text:
                            plain.append("Type your name; a placeholder is not a person.")
                        if "--pinned-date" in text or "--reviewed-date" in text:
                            plain.append("Write the date as YYYY-MM-DD, for example 2026-09-07.")
                        return " ".join(plain)
                    def _hand_over(argv):
                        if LOCAL_WRITES:
                            rc, out = _pin_tool(argv)
                            if rc == 0:
                                st.session_state["studies_flash"] = out or "done"
                                st.rerun()                      # the table below shows the pin; the words survive the rerun
                            else:
                                plain = _plain_refusal(out)
                                st.error(plain or (out or "not done"))     # a refusal stays on the page with the form
                                if plain:
                                    with st.expander("Details from the study tool"):
                                        st.code(out or "(no output)", language=None)
                        else:
                            st.code(shlex.join([_PY, _TOOL, *argv]), language=None)
                    with st.form("pin_form"):
                        st.subheader(ui.STUDIES_PIN_FORM)
                        _ps = st.selectbox("Study", _studies, key="pin_study")
                        _pby = st.text_input("Your name", key="pin_by").strip()
                        _pon = st.text_input("Date (YYYY-MM-DD)", key="pin_date", help="the day you pinned it").strip()
                        _pbuild = st.text_input("Exact published build (optional)", key="pin_build",
                                                help="a build id from this product's committed refresh receipts; leave blank to pin the specification cut only").strip()
                        _pgo = st.form_submit_button("Pin" if LOCAL_WRITES else "Show the command")
                    if _pgo:
                        _hand_over([_ps, "--pin", pack, "--pinned-by", _pby, "--pinned-date", _pon] + (["--build", _pbuild] if _pbuild else []))
                    # REFRESH IS ITS OWN ACT (2026-09-07): a stale pin used to offer only Pin again, which the
                    # tool refuses; the person who re-read the product records that with --refresh.
                    _stale_studies = [r["study"] for r in _rows if r.get("stale") or r.get("build_stale") or r.get("superseded")]
                    if _stale_studies:
                        with st.form("refresh_form"):
                            st.subheader(ui.STUDIES_REFRESH_FORM)
                            st.caption(ui.STUDIES_REFRESH_HELP)
                            _rs = st.selectbox("Study", _stale_studies, key="refresh_study")
                            _rby = st.text_input("Your name", key="refresh_by").strip()
                            _ron = st.text_input("Date (YYYY-MM-DD)", key="refresh_date", help="the day you re-read the product").strip()
                            _rbuild = st.text_input("Exact published build (optional)", key="refresh_build").strip()
                            _rgo = st.form_submit_button("Record the refresh" if LOCAL_WRITES else "Show the command")
                        if _rgo:
                            _hand_over([_rs, "--refresh", pack, "--reviewed-by", _rby, "--reviewed-date", _ron] + (["--build", _rbuild] if _rbuild else []))
                    _vars = sorted(study_pin.contract_variables(os.path.join(ROOT, pack)))
                    if not _vars:
                        st.caption(ui.STUDIES_NO_DECISION_FORM)
                        _dgo = False
                    if _vars:
                        _ds = st.selectbox("Study for these variable decisions", _studies, key="dec_study")
                        _dv = st.selectbox("Variable", _vars, key="dec_var")
                        _decision_context = (_study_context, _ds, _dv)
                        if st.session_state.get("_decision_form_context") != _decision_context:
                            for _key in list(st.session_state):
                                if str(_key).startswith("dec_") and _key not in ("dec_study", "dec_var"):
                                    del st.session_state[_key]
                            st.session_state["_decision_form_context"] = _decision_context
                    with st.form("decide_form") if _vars else contextlib.nullcontext():
                      if _vars:
                        st.subheader(ui.STUDIES_DECIDE_FORM)
                        _dd = st.selectbox("Decision", list(study_pin.DECISIONS), key="dec_decision")
                        _dwhy = form_help.field(st.text_input, "Why", key="dec_why", binding=_decision_context).strip()
                        _ddef = form_help.field(st.text_area, "The study's own definition (reconsider only)", key="dec_defn", binding=_decision_context).strip()
                        _dby = st.text_input("Your name", key="dec_by").strip()
                        _don = st.text_input("Date (YYYY-MM-DD)", key="dec_date", help="the day you decided").strip()
                        _drev = st.checkbox("Revise an earlier decision about this variable", key="dec_revise")
                        _dgo = st.form_submit_button("Record" if LOCAL_WRITES else "Show the command")
                    if _dgo:
                        argv = [_ds, "--decide", pack, "--variable", _dv, "--decision", _dd, "--why", _dwhy,
                                "--decided-by", _dby, "--decided-date", _don]
                        if _ddef:
                            argv += ["--definition", _ddef]
                        if _drev:
                            argv += ["--revise"]
                        _hand_over(argv)

    if section == "New product":
        # A PREVIEW, NEVER A WRITE. The portal has no write to grant (PERMISSIONS above), and standing a
        # product up is one: `new_product.py --apply` is a person's act at a keyboard. What the page
        # does is what a person does first anyway: compose the command from the governed vocabularies,
        # run it WITHOUT --apply (it prints the plan and every refusal and writes nothing), and hand
        # over the exact command to run. A person testing the pushed branch asked "as an admin I can't
        # create a new project" (2026-09-04); this is the answer that keeps the write boundary.
        if not can("start"):
            st.info(ui.no_new_product(ACTOR['role']) + (" " + ui.DEMO_ROLE_HINT if LOCAL_DEMO else ""))
        else:
            import datetime as _dt  # noqa: PLC0415
            import shlex  # noqa: PLC0415
            import subprocess  # noqa: PLC0415
            sys.path.insert(0, os.path.join(ROOT, "platform", "tools"))
            import oncology_registry as _onc  # noqa: PLC0415
            import product_gates as _pg  # noqa: PLC0415
            import source_manifest as _sm  # noqa: PLC0415
            import spec_lint as _sl  # noqa: PLC0415
            import new_product_words as _npw  # noqa: PLC0415
            import new_product_recovery as _npr  # noqa: PLC0415
            _recovery_actor = ACTOR.get("email") or ACTOR["name"]
            st.markdown(theme.section_title("New product", "Four short steps: the product, its data, the specification, and who classified it."), unsafe_allow_html=True)
            st.caption(ui.NEW_PRODUCT_CAPTION if LOCAL_WRITES else ui.NEW_PRODUCT_CAPTION_DEPLOYED)
            _recovery_panel = st.container()
            _edit_panel = st.container()

            def _setup_step_panel(step):
                return _edit_panel if (_npr.editing(ROOT, _recovery_actor, step)
                                       or _npr.editing(ROOT, _recovery_actor, "all")) else st.container()

            _np_flash = st.session_state.pop("np_flash", None)
            if _np_flash:
                # (message, the tool's report, next steps): the steps are the page's, the report stays under the details
                st.success(_np_flash[0])
                if len(_np_flash) > 2 and _np_flash[2]:
                    st.info(_np_flash[2])
                with st.expander(ui.NEW_PRODUCT_REPORT):
                    st.code(_np_flash[1] or "(no output)", language=None)
            st.write(ui.NEW_PRODUCT_DECLARATIONS)
            # NOTHING HERE IS A HARD-CODED PATH: the interpreter is the one this platform documents for
            # the person's OS, the tool is named relative to the checkout with the OS separator, and a
            # workbook is picked from the checkout (or named) rather than assumed to live anywhere.
            _PY = "python" if os.name == "nt" else "python3"
            _TOOL = os.path.join("platform", "tools", "new_product.py")

            def _workbooks():
                """Every .xlsx under the checkout, checkout-relative, for the picker."""
                found = []
                for dirpath, dirs, files in os.walk(ROOT):
                    dirs[:] = [d for d in dirs if d not in (".git", ".history", "__pycache__", "node_modules", ".venv", ".venv313", "venv",
                                                           ".pytest_cache", ".mypy_cache", ".ruff_cache")]
                    for f in files:
                        if f.lower().endswith((".xlsx", ".xlsm")):
                            _rel = os.path.relpath(os.path.join(dirpath, f), ROOT).replace(os.sep, "/")
                            if not ACTOR.get("packs") or portal_runtime.within_packs(_rel, ROOT, MY_PACKS):
                                found.append(_rel)
                return sorted(found)

            def _uploaded_workbook(key):
                """Validate a private pending upload; stand-up later copies it into prog_spec/."""
                import specification_attachment as _attachment  # noqa: PLC0415
                import new_product_setup_errors as _setup_errors
                _error_key = "_setup_upload_error_" + key
                st.session_state.pop(_error_key, None)
                _up = st.file_uploader("Upload the workbook (.xlsx)", type=["xlsx"], accept_multiple_files=False,
                                       max_upload_size=_attachment.MAX_UPLOAD_BYTES // (1024 * 1024), key=key + "_upload")
                _cache_key = "_setup_upload_cache_" + key
                if _up is None:
                    st.session_state.pop(_cache_key, None)
                    return ""
                if isinstance(getattr(_up, "size", None), int) and _up.size > _attachment.MAX_UPLOAD_BYTES:
                    _setup_errors.upload_failure(key, ["The workbook is larger than 15 MB. Choose a smaller valid workbook or ask your data expert to register it."])
                    return ""
                try:
                    _raw = _up.getvalue()
                except (OSError, ValueError):
                    _setup_errors.upload_failure(key, ["The upload could not be read. Choose the workbook again."])
                    return ""
                _actor = ACTOR.get("email") or ACTOR.get("name", "")
                _identity = (os.path.realpath(ROOT), _actor, _up.name, _attachment._digest(_raw),
                             _attachment.WORKBOOK_VALIDATION_VERSION)
                _cached = st.session_state.get(_cache_key)
                _saved = None
                if isinstance(_cached, dict) and _cached.get("identity") == _identity:
                    try:
                        _directory = _attachment._setup_upload_directory(ROOT, _actor)
                        _path = _attachment._safe(_cached["saved"]["path"], _directory)
                        if _attachment._digest(_attachment._bytes(_path)) == _identity[3]:
                            _saved = _cached["saved"]
                    except (OSError, ValueError, TypeError, KeyError):
                        pass
                if _saved is None:
                    _saved = _attachment.save_setup_upload(ROOT, _actor, upload_name=_up.name, upload_bytes=_raw)
                    if _saved["ok"]:
                        # Metadata only, private to this session and exact input bytes.
                        # Canonical Preview/write validation still runs independently.
                        st.session_state[_cache_key] = {"identity": _identity, "saved": _saved}
                if not _saved["ok"]:
                    _setup_errors.upload_failure(key, _saved["errors"])
                    return ""
                st.caption(f"Uploaded {_saved['name']} ({_saved['workbook']['bytes']:,} bytes). It is kept in local application storage and registered with the product when you write it.")
                return _saved["path"]

            def _workbook_field(label, key, required):
                _opts = ["(none)", "(upload a workbook)"] + _workbooks() + ["(another file: type its path)"]
                _pick = st.selectbox(label, _opts, key=key,
                                     help="Upload the approved workbook, or pick one already in this checkout. Reference examples are listed for demonstrations only.")
                if _pick == "(upload a workbook)":
                    _uploaded = _uploaded_workbook(key)
                    if not _uploaded:
                        _upload_errors = st.session_state.get("_setup_upload_error_" + key) or [
                            "Choose a valid workbook to upload." if required else
                            "Choose a valid workbook to upload, or explicitly select (none) to continue without a workbook."]
                        _workbook_input_errors.extend(_upload_errors)
                        form_help.record_validation(_upload_errors, title="Workbook upload needs attention",
                            action_id="new_product_workbook", input_digest=form_help.digest([key, _upload_errors]), primary=True)
                    return _uploaded
                if _pick == "(another file: type its path)":
                    _typed = st.text_input("Path of the workbook on this machine", key=key + "_path").strip()
                    if _typed and ACTOR.get("packs") and not portal_runtime.within_packs(_typed, ROOT, MY_PACKS):
                        st.warning("Choose a workbook within an assigned product. Your data expert can register a shared specification for you.")
                        return ""
                    if _typed and not os.path.isfile(_typed if os.path.isabs(_typed) else os.path.join(ROOT, _typed)):
                        st.caption(ui.PATH_NOT_HERE.format(path=_typed))
                    return _typed
                return "" if _pick == "(none)" else _pick
            # a suggestion the person accepted on the previous run lands here, before the radio renders
            if st.session_state.pop("np_mode_suggested", None):
                st.session_state["np_mode"] = ui.NEW_PRODUCT_MODES[1]
            _family_suggested = st.session_state.pop("np_family_suggested", None)
            if _family_suggested:
                st.session_state["np_family"] = _family_suggested
            _slug_suggested = st.session_state.pop("np_slug_suggested", None)
            if _slug_suggested:
                st.session_state["np_slug"] = _slug_suggested
            _code_suggested = st.session_state.pop("np_code_suggested", None)
            if _code_suggested is not None:
                st.session_state["np_code"] = _code_suggested
            _mode = st.radio("What are you starting?", list(ui.NEW_PRODUCT_MODES), horizontal=True, key="np_mode")
            st.caption(ui.NEW_PRODUCT_MODE_HELP[ui.NEW_PRODUCT_MODES.index(_mode)])
            _vendors = _setup_choices["np_vendor"]
            _families = _setup_choices["np_family"]
            _cuts = _setup_choices["np_old"]
            argv, missing, _workbook_input_errors = [], [], []

            def _ident(raw):
                """An identifier as the tools spell it: lower case, words joined by underscores."""
                return re.sub(r"_+", "_", re.sub(r"[^a-z0-9]+", "_", str(raw or "").strip().lower())).strip("_")

            def _known_family(slug):
                """The registry family a slug names or shares a token with, or None."""
                toks = set(slug.split("_"))
                for fam, stems in _sl.tumour_registry()["families"].items():
                    if slug == fam or toks & set(stems) or fam in toks:
                        return fam
                return _sl.tumour_registry()["aliases"].get(slug)
            _details_panel = _setup_step_panel("details")
            with _details_panel:
                st.subheader(ui.STEP_1, anchor="new-product-details")
                st.caption(ui.STEP_1_HELP)
                c1, c2 = st.columns(2)
            # THE IDENTIFIER FOLLOWS THE NAME (2026-09-07): a scientist names the product; the folder and
            # job identifier is derived from that name the first time, and stays editable.
            if not str(st.session_state.get("np_slug") or "").strip() and str(st.session_state.get("np_name") or "").strip():
                st.session_state["np_slug"] = _ident(st.session_state["np_name"])
            _slug_raw = form_help.field(c1.text_input, "Product slug", key="np_slug", help="letters, digits and underscores: the folder and the job name; suggested from the display name").strip()
            _slug = _ident(_slug_raw)
            if _slug_raw and _slug != _slug_raw:
                c1.caption(ui.NEW_PRODUCT_NORMALISED.format(value=_slug))
            _ver = form_help.field(c2.text_input, "Specification cut (YYYYMM)", key="np_ver", help="the month of the specification this pack governs").strip()
            _fam_hit = _known_family(_slug) if _slug else None
            if _fam_hit and _mode == ui.NEW_PRODUCT_MODES[0]:
                _suggested = f"{_fam_hit}_{_ver or 'program'}" if _slug == _fam_hit else _slug
                st.warning(ui.known_tumour_hint(_fam_hit, _suggested))
                if st.button(ui.use_known_tumour(_fam_hit), key="np_use_family"):
                    # widget values are set BEFORE their widgets render, on the next run
                    st.session_state["np_mode_suggested"] = True
                    st.session_state["np_family_suggested"] = _fam_hit
                    if _slug == _fam_hit:
                        st.session_state["np_slug_suggested"] = _suggested
                    st.rerun()
            if _mode == ui.NEW_PRODUCT_MODES[2]:
                if not _cuts:
                    st.info(ui.NEW_PRODUCT_NO_CUTS)
                with _details_panel:
                    _old = st.selectbox("The previous cut", _cuts or ["(no registered product)"], key="np_old",
                                        format_func=lambda p: portal_packs.label(p, _CAT) if p.startswith("products/") else p)
                # a next cut has no vendor field; the person still reads that the vendor carries over (walk UC4-45)
                st.caption(ui.NEW_PRODUCT_VENDOR_CARRIES)
                _specification_panel = _setup_step_panel("specification")
                with _specification_panel:
                    st.subheader(ui.STEP_3, anchor="new-product-specification")
                    st.caption(ui.STEP_3_HELP)
                    _wb = _workbook_field("Revised workbook", "np_wb", required=True)
                    _cls = st.selectbox("What the revision does to existing values", ["breaking", "additive"], key="np_cls",
                                        help="breaking changes existing values; additive only adds")
                    _note = form_help.field(st.text_input, "One line for the changelog", key="np_note").strip()
                argv = [_slug, "--next-cut-of", _old, "--spec-version", _ver, "--workbook", _wb, "--change-class", _cls]
                if _note:
                    argv += ["--change-note", _note]
                missing = [w for w, v in (("the slug", _slug), ("the cut", _ver),
                                          ("the previous cut", _old if _old in _cuts else ""), ("the workbook", _wb),
                                          ("the changelog line", _note)) if not v]
                if not _cuts:
                    missing.append("a registered product")
            else:
                _name = form_help.field(c1.text_input, "Display name", key="np_name", help='what people call it, e.g. "Kidney"').strip()
                _code_raw = form_help.field(c2.text_input, "Registry code", key="np_code", value="", help="the short registry name; the slug when left empty").strip()
                _code = _ident(_code_raw) or _slug
                if _code_raw and _code != _code_raw:
                    c2.caption(ui.NEW_PRODUCT_NORMALISED.format(value=_code))
                with _details_panel:
                    _area = form_help.field(st.selectbox, "Product folder group", _setup_choices["np_area"], key="np_area",
                        help="Choose oncology or heme before creating the product. This controls its repository folder; the tumour class and definitions are declared separately. Next cuts retain the same group.")
                if _mode == ui.NEW_PRODUCT_MODES[1]:
                    if _fam_hit in _families:
                        st.session_state.setdefault("np_family", _fam_hit)
                    with _details_panel:
                        _fam = form_help.field(st.selectbox, "The tumour this product is of", _families, key="np_family", index=None,
                                            placeholder=ui.DECLARE_PLACEHOLDER, help="the tumour the registry already knows; this product becomes its second product")
                with _setup_step_panel("data"):
                    st.subheader(ui.STEP_2, anchor="new-product-data")
                    st.caption(ui.STEP_2_HELP)
                    d1, d2 = st.columns(2)
                # NOTHING HERE IS PRE-FILLED (thirteenth pass, J1): the page said these declarations have
                # no default while every selectbox showed its first option and the date showed today,
                # so an untouched form recorded a vendor, a modality, an AI access and a date under the
                # person's name. `index=None` shows a prompt until the person chooses.
                _vendor = form_help.field(d1.selectbox, "Vendor", _vendors or ["flatiron"], key="np_vendor", index=None,
                                       placeholder=ui.DECLARE_PLACEHOLDER,
                                       help="who delivers the data; the vendor policy says which tumours each delivers")
                d1.caption(ui.NEW_PRODUCT_VENDOR_CARRIES + " " + ui.NEW_PRODUCT_VENDOR_NOT_LISTED)
                _modality = form_help.field(d2.selectbox, "Data modality", _setup_choices["np_modality"], key="np_modality", index=None,
                                         placeholder=ui.DECLARE_PLACEHOLDER,
                                         help="ehr: electronic health records; claims: insurance claims")
                if _modality == "claims":
                    d2.info("For a claims-layout workbook, leave Approved workbook empty during registration. After creating the draft, use Attach specification in Progress and next step, then Configure claims criteria to bind events, validate the export and save its configuration. Claims execution is outside this local application.")
                _tclass = form_help.field(d1.selectbox, "Tumour class", _setup_choices["np_tclass"], key="np_tclass", index=None,
                                       placeholder=ui.DECLARE_PLACEHOLDER,
                                       help="solid tumours or haematological malignancies: it drives staging, outcomes and sources")
                _narrow = form_help.field(d2.selectbox, "Catalogue axis", _setup_choices["np_narrow"], key="np_narrow", index=None,
                                       placeholder=ui.DECLARE_PLACEHOLDER,
                                       help="where the tumour sits in the oncology catalogue, which decides the reference shelf it draws on")
                _cond = form_help.field(d1.selectbox, "Condition class", _setup_choices["np_cond"], key="np_cond", index=None,
                                     placeholder=ui.DECLARE_PLACEHOLDER,
                                     format_func=ui.CONDITION_CLASS_WORDS.get,
                                     help="Choose the actual condition class. Another condition can be retained as an unfinished setup; only oncology is supported for registration.")
                _specification_panel = _setup_step_panel("specification")
                with _specification_panel:
                    st.subheader(ui.STEP_3, anchor="new-product-specification")
                    st.caption(ui.STEP_3_HELP)
                    _wb = _workbook_field("Approved workbook (optional)", "np_wb2", required=False)
                argv = [_slug, "--code", _code, "--name", _name, "--vendor", _vendor, "--tumor-class", _tclass,
                        "--spec-version", _ver, "--narrow", _narrow, "--condition-class", _cond, "--modality", _modality, "--family", _area]
                missing = [w for w, v in (("the slug", _slug), ("the cut", _ver), ("the name", _name), ("the vendor", _vendor),
                                          ("the modality", _modality), ("the tumour class", _tclass), ("the catalogue axis", _narrow),
                                          ("the condition class", _cond)) if not v]
                argv = [str(x) for x in argv]
                if _mode == ui.NEW_PRODUCT_MODES[1]:
                    argv += ["--tumour-family", _fam or ""]
                    if not _fam:
                        missing.append("the tumour family")
                else:
                    with _details_panel:
                        _terms = form_help.field(st.text_input, "How specifications name this disease", key="np_terms",
                                               help='comma separated phrases, e.g. "renal cell carcinoma, kidney cancer"').strip()
                    argv += ["--disease-terms", _terms]
                    if not _terms:
                        missing.append("the disease phrases")
                if _wb:
                    argv += ["--workbook", _wb]
            with _specification_panel:
                _sheet_args, _sheet_missing = new_product_sheet_scope.render(_setup_sheet_scope or {})
            argv += _sheet_args
            missing += _sheet_missing
            missing += _workbook_input_errors
            missing += new_product_setup.render(new_product_setup.describe(ROOT, st.session_state, _setup_sheet_scope))
            with _setup_step_panel("classification"):
                st.subheader(ui.STEP_4, anchor="new-product-classification")
                st.caption(ui.STEP_4_HELP)
                c3, c4, c5 = st.columns(3)
            _ai_word = c3.selectbox("What AI may read of the specification", list(ui.AI_ACCESS_WORDS), key="np_ai",
                                    index=None, placeholder=ui.DECLARE_PLACEHOLDER)
            _ai = ui.AI_ACCESS_WORDS.get(_ai_word, "")
            st.session_state.setdefault("np_by", ACTOR["name"] if not LOCAL_DEMO else "")
            _by = c4.text_input("Classified by (your name)", key="np_by").strip()
            _on = c5.text_input("Classified on (YYYY-MM-DD)", key="np_on", help="the day you made this call").strip()
            argv += ["--ai-classification", _ai, "--classified-by", _by, "--classified-date", _on]
            for w, v in (("what AI may read", _ai), ("your name", _by), ("the date", _on)):
                if not v:
                    missing.append(w)
            _cmd = [_PY, _TOOL, *argv]

            def _git_configured():
                return bool(os.environ.get("RWD_PORTAL_GIT_REMOTE")) and bool(os.environ.get("RWD_PORTAL_GIT_TOKEN"))

            def _new_product(extra, timeout_s):
                return portal_runtime.run([sys.executable, os.path.join(ROOT, "platform", "tools", "new_product.py"), *argv, *extra],
                                          cwd=ROOT, timeout_s=timeout_s)
            st.session_state.setdefault("np_previewed", None)
            _recovery_preview_requested = _npr.take_preview_request(ROOT, _recovery_actor)
            if st.button(ui.NEW_PRODUCT_PREVIEW, key="np_preview") or _recovery_preview_requested:
                if _mode != ui.NEW_PRODUCT_MODES[2] and st.session_state.get("np_cond") == "non_oncology":
                    st.session_state.pop("np_previewed", None)
                    st.warning(ui.NON_ONCOLOGY_SETUP_HELP)
                elif missing:
                    st.warning(ui.NEW_PRODUCT_NEED.format(what=", ".join(missing)))
                else:
                    with st.spinner("previewing"):
                        _r = _new_product([], portal_runtime.timeout("RWD_TOOL_TIMEOUT_S", 90))
                    _r_out = ((_r.stdout or "") + (_r.stderr or "")).strip()
                    if _r.returncode == 0:
                        _npr.clear()
                        st.success(ui.NEW_PRODUCT_PREVIEW_PASSED)
                        # THE DELTA IN WORDS (walk NC-07): for a next cut the tool says which variables changed
                        _delta = _npw.delta_sentences(_r.stdout or "")
                        if _delta:
                            st.info(ui.NEW_PRODUCT_DELTA_TITLE + ". " + " ".join(s.rstrip(".") + "." for s in _delta))
                    else:
                        _npr.capture(ROOT, _recovery_actor, _r, phase="preview")
                    if _r.returncode == 0:
                        with st.expander(ui.NEW_PRODUCT_DETAILS, expanded=False):
                            st.code(_r_out or "(no output)", language=None)
                    st.session_state.np_previewed = tuple(argv) if _r.returncode == 0 else None
                    if _r.returncode == 0 and not LOCAL_WRITES and not _git_configured():
                        st.caption(ui.NEW_PRODUCT_PR_NOT_CONFIGURED)
                        st.write(ui.NEW_PRODUCT_APPLY_LINE)
                        st.code(shlex.join(_cmd + ["--apply"]), language=None)
            if not LOCAL_WRITES and _git_configured():
                # DEPLOYED, THE WRITE IS A PULL REQUEST: the app owns no checkout, so the stand-up runs on a
                # fresh clone, lands on a branch, and a person reviews and merges it (git_write.py)
                if st.session_state.get("np_previewed") == tuple(argv) and not missing:
                    if st.button(ui.NEW_PRODUCT_PR, key="np_pr"):
                        import git_write  # noqa: PLC0415
                        _remote, _token = os.environ.get("RWD_PORTAL_GIT_REMOTE", ""), os.environ.get("RWD_PORTAL_GIT_TOKEN", "")
                        _branch = f"portal/new-product-{_slug}-{_dt.datetime.now().strftime('%Y%m%d-%H%M%S')}"

                        def _work(clone):
                            _w = portal_runtime.run([sys.executable, os.path.join(clone, "platform", "tools", "new_product.py"),
                                                     *argv, "--apply", "--root", clone], cwd=clone, timeout_s=1800)
                            return _w.returncode, (_w.stdout or "") + (_w.stderr or "")
                        with st.spinner(ui.NEW_PRODUCT_PR_WORKING):
                            _ok, _out, _sha = git_write.clone_and_push(
                                _remote, _token, _branch, _work, base=os.environ.get("RWD_PORTAL_GIT_BASE", "main"),
                                author=f"{ACTOR['name']} via RWD Portal <portal@rwdp.invalid>",
                                message=f"Stand {_slug} up from the portal (classified by {_by})")
                        st.code(_out.strip() or "(no output)", language=None)
                        if not _ok:
                            st.error(ui.NEW_PRODUCT_PR_FAILED.format(why=_out.strip().splitlines()[-1] if _out.strip() else ""))
                        else:
                            _url, _why = git_write.open_pull_request(
                                _remote, _token, _branch, f"Stand {_slug} up ({_ver})",
                                f"Proposed from the portal by {ACTOR['name']}; Gate 1 fields classified by {_by} on {_on}.\n\n"
                                f"The stand-up ran on a fresh clone with every validator; review under CODEOWNERS and merge signed.",
                                base=os.environ.get("RWD_PORTAL_GIT_BASE", "main"))
                            if _url:
                                st.success(ui.NEW_PRODUCT_PR_DONE.format(url=_url))
                            else:
                                st.warning(ui.NEW_PRODUCT_PR_PUSHED.format(branch=_branch, why=_why))
                            st.session_state.np_previewed = None
                            st.session_state["_completed_setup_actor"] = ACTOR.get("email") or ACTOR["name"]
                else:
                    st.caption(ui.NEW_PRODUCT_PREVIEW_FIRST)
            if LOCAL_WRITES:
                # The saved worker owns this write; chat clearing and page reruns
                # only reconnect to progress and never cancel or repeat staging.
                import new_product_job as _npj
                _setup_progress_available = True
                try:
                    _setup_job = _npj.current(ROOT, _recovery_actor, allowed_packs=MY_PACKS)
                except (ValueError, OSError):
                    _setup_job = None
                    _setup_progress_available = False
                    st.warning("Saved setup progress is unavailable. Check the current product before requesting another write.")
                _setup_running = bool(_setup_job and _setup_job["status"] in {"queued", "running"})
                if (_setup_progress_available and st.session_state.get("np_previewed") == tuple(argv)
                        and not missing and not _setup_running):
                    st.caption(ui.NEW_PRODUCT_WRITE_TAKES)
                    if st.button(ui.NEW_PRODUCT_WRITE, key="np_write"):
                        try:
                            _setup_job = _npj.start(ROOT, _recovery_actor, argv,
                                can_write=can("start"), allowed_packs=MY_PACKS,
                                launch_context=_npj.context(ROOT, _recovery_actor, st.session_state, allowed_packs=MY_PACKS))
                            st.session_state.np_previewed = None
                            _setup_running = _setup_job["status"] in {"queued", "running"}
                        except (ValueError, OSError) as _setup_error:
                            st.warning(str(_setup_error))
                elif not _setup_running:
                    st.caption(ui.NEW_PRODUCT_PREVIEW_FIRST)
                _job_seen_key = "new_product_result_seen_" + _recovery_actor
                if (_setup_job and _setup_job["status"] in _npj.jobs.TERMINAL
                        and not _setup_job.get("result_acknowledged")
                        and st.session_state.get(_job_seen_key) != _setup_job["id"]):
                    _w = _npj.result(_setup_job)
                    _w_out = ((_w.stdout or "") + (_w.stderr or "")).strip()
                    _job_argv = _setup_job["arguments"]["argv"]
                    _launched_context = _setup_job["arguments"].get("launch_context") or {}
                    _setup_form_changed = (tuple(argv) != tuple(_job_argv) or
                        _launched_context.get("form_digest") is not None
                        and _launched_context["form_digest"] != _npr._inputs(st.session_state))
                    _next_cut = "--next-cut-of" in _job_argv
                    if _w.returncode == 0:
                        _npr.clear()
                        _m = re.search(r"WROTE .*?\n((?:  .*\n)+)", (_w.stdout or "") + "\n")
                        _pack = next((ln.strip() for ln in (_m.group(1).splitlines() if _m else [])
                                      if ln.strip().startswith("products/") and ln.strip().endswith("source_refs.yaml")), "")
                        _branch_note = ""
                        if _pack and _m:
                            # The canonical tool's successful write list includes shared
                            # registration dependencies needed when this branch is cloned.
                            # Recording their names/digests does not stage or commit them.
                            import branch_workspace as _branch_workspace
                            try:
                                _branch_workspace.record_created_files(ROOT, os.path.dirname(_pack), ACTOR.get("email") or ACTOR["name"],
                                    written_paths=[ln.strip() for ln in _m.group(1).splitlines() if ln.strip()],
                                    allowed_packs=[*MY_PACKS, os.path.dirname(_pack)], local_demo=LOCAL_WRITES, can_write=can("start"))
                            except (ValueError, OSError):
                                _branch_note = (" The product was created, but its branch-dependency record could not be saved. "
                                                "Review the successful tool's written-file list in Run details and include its shared registration files in your branch. Do not create the product again.")
                        st.session_state.np_previewed = None
                        _made = os.path.dirname(_pack) if _pack else _job_argv[0]
                        if _pack and not _setup_form_changed:
                            import conversation_intake_page as _brief_handoff_page
                            try:
                                _current_context = _npj.context(ROOT, _recovery_actor, st.session_state, allowed_packs=MY_PACKS)
                                if _launched_context.get("brief_revision") != _current_context["brief_revision"]:
                                    raise ValueError("The setup brief changed during registration.")
                                _brief_handoff_page.registration_completed(ROOT, _made, ACTOR.get("email") or ACTOR["name"],
                                    allowed_packs=[*MY_PACKS, _made], state=st.session_state)
                            except (ValueError, OSError, TypeError, KeyError):
                                _branch_note += " Your setup study brief remains saved, but its continuation could not be prepared. Open the saved brief before re-entering its wording."
                        if _setup_form_changed:
                            _branch_note += " Your edited setup draft is kept here. The completed product used the inputs saved when you chose Write; open that product from the picker when ready."
                        # the picker learns of the new product on the next run; the words travel with it:
                        # the message, the tool's report (kept under the details), the page's own next steps
                        st.session_state["np_flash"] = (
                            ((ui.NEW_PRODUCT_WRITTEN_NEXT_CUT.format(pack=_made) + " " + ui.NEW_PRODUCT_NEXT_STEPS_NEXT_CUT)
                            if _next_cut else ui.NEW_PRODUCT_WRITTEN.format(pack=_made)) + _branch_note,
                            _w_out, "" if _next_cut else ui.NEW_PRODUCT_NEXT_STEPS)
                        if _pack and not _setup_form_changed:
                            # THE NEXT STEP IS THE NEW PRODUCT'S FLOW (2026-09-05: "I create a product
                            # and write a contract — what after that? where do I go?")
                            st.session_state["pack_suggested"] = os.path.dirname(_pack)
                            st.session_state["section_suggested"] = "Flow"
                            if _next_cut:
                                st.session_state.setdefault("connected_previous_cut", {})[os.path.dirname(_pack)] = _job_argv[_job_argv.index("--next-cut-of") + 1]
                        _npj.acknowledge(ROOT, _recovery_actor, _setup_job, allowed_packs=MY_PACKS)
                        st.session_state[_job_seen_key] = _setup_job["id"]
                        st.rerun()
                    else:
                        _npr.capture(ROOT, _recovery_actor, _w, phase="write")
                        if _launched_context.get("form_digest"):
                            st.session_state[_npr.KEY]["inputs"] = _launched_context["form_digest"]
                        st.session_state[_job_seen_key] = _setup_job["id"]
                if _setup_running:
                    st.info(ui.NEW_PRODUCT_WRITE_RUNS)
                    _npj.render_progress(ROOT, _recovery_actor, allowed_packs=MY_PACKS, can_write=can("start"))
                elif _setup_job and _setup_job.get("result_acknowledged"):
                    with st.expander("Previous setup run"):
                        st.caption("Completed · " + _setup_job["created_at"][:19])
                        st.code((_setup_job.get("result") or {}).get("stdout") or "The previous setup completed.", language=None)
            with _recovery_panel:
                _npr.render(ROOT, _recovery_actor, sheet_scope=_setup_sheet_scope)

    if section == "Agent":
        if not can("agent"):
            st.info(ui.no_agent(ACTOR['role']))
        else:
            st.markdown(theme.section_title("Assistant", "Ask about this product, or describe a request. A model runs only when you send a message."), unsafe_allow_html=True)
            st.caption(ui.AGENT_CAPTION)
            import portal_agent_connection as agent_connection
            _connection = agent_connection.describe(ROOT)
            if _connection["ok"]:
                st.caption(f"Selected assistant: {_connection['provider']} · {_connection['model']}")
                st.caption("Request drafting and governed checks use this connection. A check shares a four-call limit across its specialists; model access is checked when you send a message.")

            # KEYED BY ACTOR AND PACK: switching either starts a clean conversation, so nothing said
            # about one pack (or by one person) rides into another (audit 7)
            _chat_actor = ACTOR.get("email") or ACTOR["name"]
            _ckey = (_chat_actor, pack)
            st.session_state.setdefault("chats", {})
            st.session_state.setdefault("memos", {})
            chat = st.session_state.chats.setdefault(_ckey, [])          # [{role, content, steps?}]
            memo_list = st.session_state.memos.get(_ckey) or []
            if chat and st.sidebar.button("Clear chat"):
                st.session_state.chats[_ckey] = []
                st.rerun()

            for _message_index, m in enumerate(chat):
                with st.chat_message(m["role"]):
                    if m.get("who"):
                        st.caption(m["who"])
                    if m.get("steps"):
                        with st.expander(ui.steps_title(len(m['steps']))):
                            for line in m["steps"]:
                                st.write(line)
                    st.write(m["content"])
                    if m.get("path"):
                        st.caption(ui.finished(m.get('status'), m['path']))
                    if m.get("run"):
                        connected_workflow_page.run_continuations(ROOT, pack, ACTOR.get("email") or ACTOR["name"], m["run"],
                            allowed_packs=MY_PACKS, key=f"agent_run_{_message_index}")

            MEMO_LINES, MEMO_LINE = 12, 160           # what rides along: at most 12 facts x 160 chars
            # "What the agent remembers" is a deterministic memo from tool outputs, never a model's
            # summary of its own conversation; the page text lives in ui_text.memo_title
            if memo_list:
                with st.expander(ui.memo_title(len(memo_list))):
                    for f in memo_list:
                        st.write(f"- {f}")
                    if st.button("Forget these facts", key="memo_clear"):
                        st.session_state.memos[_ckey] = []
                        st.rerun()
            # TWO MODES, SEPARATED ON PURPOSE. Intake is ONE model call per turn and NO tools: it
            # elicits a typed request by domain and never states what a pack contains. Check hands the
            # typed request (or a raw message) to the governed loop — tools, evidence, escalation — in a
            # BACKGROUND JOB the page polls, so the step stream keeps flowing while a real check runs
            # (the compared tool is fast because talking and checking are different moments; ours
            # investigated on every message, 2026-09-03).
            MODES = [ui.MODE_INTAKE, ui.MODE_CHECK]
            st.session_state.setdefault("intakes", {})
            st.session_state.setdefault("jobs", {})
            _incoming_check = st.session_state.pop("connected_governed_check", None)
            if (isinstance(_incoming_check, dict) and _incoming_check.get("pack") == pack
                    and _incoming_check.get("actor") == (ACTOR.get("email") or ACTOR["name"])):
                st.session_state[f"mode_{_ckey}"] = ui.MODE_INTAKE if _incoming_check.get("mode") == "intake" else ui.MODE_CHECK
                st.session_state.setdefault("agent_followups", {})[_ckey] = _incoming_check.get("params") or {}
            mode = st.radio("Mode", MODES, horizontal=True, key=f"mode_{_ckey}")
            intake_mode = mode == ui.MODE_INTAKE
            state = None
            if intake_mode:
                dom = st.selectbox("Request kind", sorted(intake.domains(), key=lambda k: (k != "feasibility", k)),
                                   key=f"dom_{_ckey}", format_func=lambda k: intake.domains()[k]["title"])
                state = st.session_state.intakes.get(_ckey)
                if state is None or state["domain"] != dom:
                    state = intake.new_state(dom, pack, _chat_actor)
                    st.session_state.intakes[_ckey] = state
                _filled_n = sum(1 for v in state["request"].values() if v not in (None, "", [], {}))
                with st.expander(ui.request_so_far(_filled_n)):
                    st.code(intake.to_yaml(state), language="yaml")
                    if _filled_n and st.button(ui.KEEP_REQUEST, key=f"keep_{_ckey}"):
                        # THE LIFECYCLE RIDES WITH THE REQUEST (audit 8): what the last governed check
                        # made of it decides whether it may ever pre-fill another
                        # ...AND THE RUN MUST HAVE CHECKED THIS REQUEST: the newest result for THIS typed
                        # request's goal, never a check made for another kind or a free-text question
                        # (eleventh verdict); save_request refuses a run whose record disagrees
                        _goal = intake.to_goal(state)
                        _last = next((m for m in reversed(chat) if m.get("status") and not m.get("intake")
                                      and m.get("goal") == _goal), None)
                        _status = ("draft" if _last is None else
                                   "checked" if _last["status"] in ("done", "escalated") else "failed")
                        _kept = intake.save_request(
                            state, status=_status, outcome=(_last["status"] if _last else None),
                            run_id=(os.path.splitext(os.path.basename(_last["path"]))[0] if _last and _last.get("path") else None))
                        st.caption(ui.kept(os.path.basename(_kept), _status))
                # PAST REQUESTS, BESIDE PRECEDENTS: the similar ones are offered to pre-fill EMPTY slots —
                # deterministic overlap, same domain only, never who asked; a pre-filled decision is still
                # this study's question (the compared tool's best idea, kept inside the boundary)
                _past = intake.similar(state, intake.load_requests(), k=3, scope=set(MY_PACKS),
                                       lineage=portal_packs.lineage(str(ROOT), pack))
                if _past:
                    with st.expander(ui.similar_title(len(_past))):
                        for _score, _req in _past:
                            _r = _req.get("request") or {}
                            st.write(ui.similar_row(_score, _req.get('_file'),
                                                    str(_r.get('population') or _r.get('topic') or '')[:60],
                                                    str(_r.get('measure') or _r.get('question') or '')[:60]))
                            if st.button(ui.prefill_button(_req.get('_file')), key=f"prefill_{_ckey}_{_req.get('_file')}"):
                                st.session_state.intakes[_ckey] = intake.prefill(state, _req)
                                st.rerun()
                st.caption(intake.CAVEAT)

            def _show(s_):
                if s_["kind"] == "decision":
                    st.write(ui.step_line(s_["decision"]))
                elif s_["kind"] == "observation":
                    first = next((l for l in str(s_.get("output") or "").splitlines() if l.strip()), "")
                    st.caption(ui.checked_line(s_.get('tool'), first[:160]))
                else:
                    _lbl = queues.describe_step(s_)
                    if _lbl:
                        st.warning(_lbl)

            def _finish_job(job):
                """The governed job ended: record the reply and the memo, then re-render."""
                result, steps = job.result, []
                if job.error or result is None:
                    answer = ui.check_failed(job.error or 'no result')
                    chat.append({"role": "assistant", "content": answer, "steps": [], "status": "error"})
                else:
                    for s_ in result.steps:
                        if s_["kind"] == "decision":
                            steps.append(ui.step_line(s_["decision"]))
                        elif s_["kind"] == "observation":
                            # A specialist can finish its review on the final shared
                            # call. Keep that observed result visible even when the
                            # orchestrator has no budget left to summarize it.
                            # The persisted observation is already bounded by the
                            # runner. Show it whole so the critic result after a
                            # packet's first-line path does not disappear.
                            steps.append(ui.checked_line(s_.get("tool"), str(s_.get("output") or "").strip()))
                        elif s_["kind"] == "authority_detected":
                            steps.append(ui.authority_line(s_['marker']))
                    esc = None
                    if result.outcome["status"] == "escalated":
                        esc = json.loads(result.outcome["summary"])
                        answer = ui.needs_person(esc.get('to'), esc.get('question'))
                    else:
                        answer = result.outcome["summary"]
                    if result.outcome["status"] in {"model_stopped", "budget_exhausted", "time_budget_exhausted", "step_budget_exhausted"}:
                        _observations = sum(s_.get("kind") == "observation" for s_ in result.steps)
                        if _observations:
                            answer += (f"\n\n{_observations} tool result(s) were recorded before this check stopped. "
                                       "Open the step details to inspect them. The overall request is incomplete; "
                                       "review the recorded results before starting another check.")
                    chat.append({"role": "assistant", "content": answer, "steps": steps,
                                 "path": result.path, "status": result.outcome["status"],
                                 "goal": getattr(result, "goal", None), "run": dict(vars(result))})
                    facts = list(memo_list)
                    for s_ in result.steps:
                        if s_["kind"] == "observation":
                            first = next((l.strip() for l in str(s_.get("output") or "").splitlines()
                                          if l.strip() and not l.strip().startswith("=")), "")
                            if first:
                                facts.append(f"{s_.get('tool')}: {first[:MEMO_LINE]}")
                    if esc is not None:
                        facts.append(ui.fact_sent(esc.get('to'), result.run_id))
                    else:
                        facts.append(f"run {result.run_id} ended {result.outcome['status']}")
                    seen, kept = set(), []
                    for f in reversed(facts):                     # newest first, deduplicated, capped
                        if f not in seen:
                            seen.add(f); kept.append(f)
                    st.session_state.memos[_ckey] = list(reversed(kept))[-MEMO_LINES:]
                    _esc_rows.clear(); _counts.clear()
                del st.session_state.jobs[_ckey]
                st.session_state.get("agent_followups", {}).pop(_ckey, None)
                st.rerun()

            job = st.session_state.jobs.get(_ckey)
            if job is not None:
                with st.chat_message("assistant"):
                    with st.status(f"checking… {job.label} ({job.elapsed:.0f}s)", expanded=True) as box:
                        for s_ in job.snapshot():
                            _show(s_)
                        if job.done:
                            box.update(label=f"finished: {(job.result.outcome['status'] if job.result else 'error')}",
                                       state="complete", expanded=False)
                if job.done:
                    _finish_job(job)
                time.sleep(1.0)
                st.rerun()

            if not _connection["ok"]:
                for _problem in _connection["errors"]:
                    st.warning(_problem)
            _followup = (st.session_state.get("agent_followups") or {}).get(_ckey) or {}
            _run_followup = False
            if _followup and not intake_mode:
                st.caption("Continuing from the selected assistant review" +
                    (": " + str(_followup.get("evaluation_id") or _followup.get("run_id")) if _followup.get("evaluation_id") or _followup.get("run_id") else "."))
                if _followup.get("goal"):
                    st.write(_followup["goal"])
                    _run_followup = st.button("Run this comparison check", key=f"agent_followup_{_ckey}", disabled=not _connection["ok"])
            q = st.chat_input(ui.INTAKE_PLACEHOLDER if intake_mode else ui.CHECK_PLACEHOLDER, disabled=not _connection["ok"])
            if _run_followup:
                q = _followup["goal"]
            if q:
                # INGRESS CLASSIFICATION, BEFORE EITHER MODE (audit 8): text that looks like data about
                # individual people is refused here; nothing of it reaches a model, a transcript or a
                # kept request, and the person is told why
                _flag = intake.classify_ingress(q)
                if _flag:
                    chat.append({"role": "user", "content": ui.WITHHELD, "who": ACTOR["name"]})
                    chat.append({"role": "assistant", "content": intake.ingress_refusal(_flag), "intake": True})
                    st.rerun()
                try:
                    agent_connection.check_input(q)
                except agent_connection.ai.Invalid as _refusal:
                    chat.append({"role": "user", "content": ui.WITHHELD, "who": ACTOR["name"]})
                    chat.append({"role": "assistant", "content": str(_refusal), "intake": True})
                    st.rerun()
                chat.append({"role": "user", "content": q, "who": ACTOR["name"]})
                import orchestrator  # noqa: PLC0415
                wants_check = q.strip().lower().rstrip(".!") in ("check", "done")
                if intake_mode and not wants_check:
                    # ONE call, NO tools: the model asks the next question and fills the slots
                    _drafted = agent_connection.intake_turn(ROOT, state, q, actor_id=_chat_actor,
                        allowed_packs=MY_PACKS, expected=_connection)
                    st.session_state.intakes[_ckey] = _drafted["state"]
                    chat.append({"role": "assistant", "content": _drafted.get("reply") or " ".join(_drafted["errors"]), "intake": True})
                    st.rerun()
                if intake_mode:
                    findings = intake.precheck(state, PACKS, known_variables=_known_variables(pack))
                    if findings or not intake.ready(state):
                        chat.append({"role": "assistant", "intake": True, "content":
                                     "Not ready to check:\n" + "\n".join(f"- {f}" for f in findings)})
                        st.rerun()
                    goal = intake.to_goal(state)
                    label = f"{intake.domains()[state['domain']]['title']} request"
                elif _run_followup:
                    # Paired model checks must retain the reviewed goal byte-for-byte.
                    # Current scope and ingress checks still apply independently.
                    goal = q
                    label = "comparison question"
                else:
                    prior = chat[:-1][-4:]
                    ctx = "".join(f"{'You said' if m['role']=='assistant' else 'User asked'}: "
                                  f"{m['content'][:400]}\n" for m in prior)
                    memo_txt = ("Facts established earlier in this conversation (from tool outputs, "
                                "verbatim; trust these over memory):\n" + "\n".join(f"- {f}" for f in memo_list)
                                + "\n") if memo_list else ""
                    goal = (f"{memo_txt}Conversation so far:\n{ctx}\nCurrent pack: {pack}\n"
                            f"User's new message: {q}") if (ctx or memo_txt) else f"Current pack: {pack}\n{q}"
                    label = "question"
                try:
                    _caps = limits.caps(os.environ)      # finite, positive, or the page says which variable
                except ValueError as _bad:
                    st.error(ui.bad_limit(_bad))
                    st.stop()
                try:
                    _selected_model = agent_connection.model(ROOT, expected=_connection)
                except agent_connection.ai.Invalid as _unavailable:
                    chat.append({"role": "assistant", "content": str(_unavailable)})
                    st.rerun()
                st.session_state.jobs[_ckey] = jobs.start(
                    orchestrator.run, model=_selected_model, primary_pack=pack, label=label, goal=goal, actor=ACTOR, max_steps=_caps["steps"],
                    cost_ceiling=_caps["usd"], max_seconds=_caps["seconds"], scope=set(MY_PACKS))
                st.rerun()

    if section == "Eval corpus":
        if not can("evals"):
            st.info(ui.no_evals(ACTOR['role']))
        else:
            st.markdown(theme.section_title("Evaluations", "The latest mechanical scorecard of the adversarial corpus."), unsafe_allow_html=True)
            st.caption(ui.EVALS_CAPTION)
            sc = os.path.join(ROOT, "experiments", "agent", "runs", "scorecard.json")
            if os.path.exists(sc):
                with open(sc, encoding="utf-8") as fh:
                    st.dataframe(json.load(fh), width="stretch")
            else:
                st.write(ui.NO_SCORECARD)
            adj = os.path.join(ROOT, "experiments", "agent", "evals", "ADJUDICATION.md")
            if os.path.exists(adj) and st.toggle("Show the adjudication sheet"):
                with open(adj, encoding="utf-8") as fh:
                    _document_markdown(fh.read(), key="adjudication_sources", source_path="experiments/agent/evals/ADJUDICATION.md")

    if section == "Waiting on a person":
        if not can("queue"):
            st.info(ui.no_queue(ACTOR['role']))
        else:
            st.markdown(theme.section_title("Waiting on a person", "Questions the assistant could not answer without a person."), unsafe_allow_html=True)
            st.caption(ui.ESCALATIONS_CAPTION)
            owners = ["any"] + control_plane.owners()          # the declared roles, from governance/ACTIONS.yaml
            to = st.selectbox("For", owners, key="esc_owner")
            esc_scope = st.radio("Scope", ["this pack", "all (incl. runs naming no pack)"], horizontal=True,
                                 key="esc_scope")
            rows = _esc_rows(RUNS_DIR, None if to == "any" else to,
                             pack if esc_scope == "this pack" else None,
                             within=(None if esc_scope != "this pack" and not ACTOR.get("packs") else set(MY_PACKS)))
            open_rows = [r for r in rows if not r["answered"]]
            st.write(f"{len(open_rows)} open, {len(rows) - len(open_rows)} answered")
            if rows:
                st.dataframe([{"run": r["run_id"], "for": r["to"], "asked by": r["asked_by"],
                               "answered": ("yes" if r["answered"] else ""), "tried": r.get("attempts") or "",
                               "question": r["question"][:110]} for r in rows[:50]],
                             width="stretch", hide_index=True)
                pick = st.selectbox("Open one", [r["run_id"] for r in rows[:50]], key="esc_pick")
                row = next(r for r in rows if r["run_id"] == pick)
                st.write(f"For {row['to']}. Asked by {row['asked_by']}. Goal:")
                st.text(str(row["goal"]))
                st.write(row["question"])
                with st.expander("Evidence the agent cited"):
                    st.write(row["evidence"] or "(none recorded)")
                st.code(queues.forward_text(row), language=None)
                if can("agent"):
                    import portal_agent_connection as agent_connection
                    _resume_connection = agent_connection.describe(ROOT)
                    if _resume_connection["ok"]:
                        st.caption(f"Continue with: {_resume_connection['provider']} · {_resume_connection['model']}")
                    else:
                        for _problem in _resume_connection["errors"]:
                            st.warning(_problem)
                    ans = st.text_area(ui.YOUR_ANSWER, key=f"esc_answer_{row['run_id']}")
                    if row["answered"]:
                        st.info(ui.already_answered(row['answered_by'], row.get('eligibility')))
                    elif row.get("attempts"):
                        st.caption(ui.attempts_line(row["attempts"]))
                    if st.button("Resume with this answer", disabled=(not ans.strip()) or row["answered"] or not _resume_connection["ok"]):
                        import orchestrator  # noqa: PLC0415
                        _flag = intake.classify_ingress(ans)              # an answer is ingress too
                        if _flag:
                            st.error(intake.ingress_refusal(_flag))
                            st.stop()
                        try:
                            agent_connection.check_input(ans)
                            _c = limits.caps(os.environ)
                            _resume_model = agent_connection.model(ROOT, expected=_resume_connection)
                        except agent_connection.ai.Invalid as _unavailable:
                            st.error(str(_unavailable))
                            st.stop()
                        except ValueError as _bad:
                            st.error(ui.bad_limit(_bad))
                            st.stop()
                        with st.spinner(ui.RESUMING):
                            # the answerer's ownership travels with the answer (audit 8): the resume refuses
                            # a person the roster does not record as owning the question's addressee
                            try:
                                res = orchestrator.resume_run(row["run_id"], ans.strip(), ACTOR["name"], model=_resume_model, max_steps=_c["steps"],
                                                              cost_ceiling=_c["usd"], max_seconds=_c["seconds"],
                                                              answerer_owns=set(ACTOR.get("owns") or []), scope=set(MY_PACKS))
                            except SystemExit as _refusal:
                                # State/ownership refusals are expected review outcomes,
                                # not Streamlit crashes or requests for a different API key.
                                st.error(str(_refusal))
                                st.stop()
                            except Exception:
                                st.error("This check could not continue. Your answer remains in the form. Refresh the recorded run and selected assistant connection before retrying; no other provider was used.")
                                st.stop()
                        _esc_rows.clear(); _counts.clear()          # the queue changed
                        st.success(ui.resumed(res.outcome['status'], res.run_id))
                        st.write(res.outcome.get("summary"))
                        st.caption(ui.ANSWER_IS_CONTEXT)
                else:
                    st.info(ui.RESUME_NEEDS_AGENT)
            else:
                st.write(ui.NOTHING_WAITING)

    if section == "Evidence packets":
        if not can("queue"):
            st.info(ui.no_packets_role(ACTOR['role']))
        else:
            st.markdown(theme.section_title("Evidence packets", "What the specialists produced for a person to decide on."), unsafe_allow_html=True)
            st.caption(ui.PACKETS_CAPTION)
            scope = st.radio("Scope", ["this pack", "all packs"], horizontal=True, key="pk_scope")
            rows = _packet_rows(CANDIDATES_DIR, pack if scope == "this pack" else None, within=set(MY_PACKS))
            st.write(f"{len(rows)} packet(s)")
            if rows:
                st.dataframe([{"when": r["generated_at"], "kind": r["kind"], "pack": r["pack"],
                               "requirement": r["requirement"] or "", "critic": r["critic"],
                               "second vote": "yes" if r["second_vote"] else ""} for r in rows[:60]],
                             width="stretch", hide_index=True)
                pick = st.selectbox("Open one", [r["file"] for r in rows[:60]], key="pk_pick")
                row = next(r for r in rows if r["file"] == pick)
                st.markdown(ui.packet_line(row))
                st.write(row["summary"] or "(no summary field)")
                st.warning(row["decision"])
                st.code(queues.forward_text(row), language=None)
                with st.expander("Raw packet"):
                    st.json(json.load(open(row["path"], encoding="utf-8")))
            else:
                st.write(ui.NO_PACKETS)

    with st.sidebar.expander("Getting started and help"):
        _source_link("docs/RESEARCHER_QUICK_START.md", key="portal_help", label="Open the first-time guide")
    document_page.render_open_document(ROOT, allowed_packs=_DOC_SCOPE, context=_DOC_CONTEXT)
    form_help.finish()
