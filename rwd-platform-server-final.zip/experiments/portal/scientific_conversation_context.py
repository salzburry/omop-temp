"""Bounded scientific evidence, using the workbench's existing canonical readers.

Accessible products must pass the existing AI source gate before their authored
definitions, decisions or configured code lists are read. Reuse carries recorded
status and provenance, never approval for the current question. Licensed reference
consultation is not permission to disclose a projection to a model.
"""
from __future__ import annotations

from collections import Counter
from functools import lru_cache
import hashlib
import importlib.util
import json
from pathlib import Path
import re

import yaml

import knowledge_search
import science_workspace
import scientific_definitions as definitions
import source_manifest
import workflow_skills

MAX_BYTES = 4500
MAX_CANDIDATE_ROWS = 12
CHAT_KINDS = {"related_spec", "precedent", "recorded_definition", "recorded_decision",
              "product_codelist", "clinical_code", "shared_template", "source_dictionary", "reference_example"}
_STUDY_DOMAINS = {"study", "study_period", "study_population", "population", "cohort", "cohorts", "inclusion", "exclusion", "index"}
_UNSAFE = re.compile(
    r"VENDOR[_ ]REDACTED|VENDOR DOCUMENTATION REDACTED|"
    r"\bsk-(?:ant-)?[A-Za-z0-9_-]{12,}|"
    r"\b(?:api[_ -]?key|access[_ -]?token|authorization)[\"']?\s*[:=]\s*\S+|"
    r"(?<![A-Za-z0-9])[A-Za-z]:[\\/]|\\\\|(?:^|\s)/(?:home|Users|etc|tmp|mnt|private|var|opt)/|"
    r"\.portal-drafts|<\|(?:system|assistant|developer)|"
    r"\b(?:ignore|override|disregard)\s+(?:all\s+)?(?:previous|prior|system|developer)\b|"
    r"\b(?:system|developer)\s*(?:prompt|message|instruction)\s*:|"
    r"\b(?:you are now|act as (?:the )?(?:system|developer)|reveal (?:the )?(?:system|developer) prompt)\b|"
    r"\b(?:send|upload|exfiltrate)\b.{0,60}\b(?:secret|credential|patient|token)\b", re.I)


def _json(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"))


def _hash(value):
    return hashlib.sha256(value if isinstance(value, bytes) else _json(value).encode("utf-8")).hexdigest()


@lru_cache(maxsize=1)
def _classifier():
    path = Path(__file__).resolve().parents[1] / "agent/intake.py"
    spec = importlib.util.spec_from_file_location("scientific_context_ingress", path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module.classify_ingress


def _safe_text(text):
    return not _UNSAFE.search(text) and not _classifier()(text)


def _product_snapshot(root, target, actor_id, scope):
    # Canonical access checks precede source text. Check redirectable fixed inputs
    # before ai_gate, whose own fingerprint checks read the extraction bytes.
    product, canonical, _owner, _folder = definitions._scope(root, target, actor_id, scope)
    paths = [product / name for name in
             ("source_refs.yaml", "spec_pipeline/pipeline.conf", "spec_pipeline/out/extracted.json")]
    for path in paths:
        definitions._safe(path)
        if path.is_file() and path.stat().st_size > definitions.LIMIT:
            raise ValueError("The optional source exceeds the context reader limit.")
    definitions.cs.ai_gate(str(product))
    inputs = {path.relative_to(product).as_posix(): definitions._read(path) for path in paths}
    data = definitions._json(inputs["spec_pipeline/out/extracted.json"])
    if not isinstance(data, dict) or not isinstance(data.get("rows"), list):
        raise ValueError("The optional extraction is incomplete.")
    material = source_manifest.ai_extraction(str(product))
    # Only hashes leave this function for source registrations. A registration
    # may contain private raw-document paths unrelated to the approved artifact.
    binding = _hash({name: _hash(raw) for name, raw in inputs.items()})
    return product, canonical, data, material, binding


def _candidate(product, target, row, data, material, kind):
    item_id = definitions.row_item_id(row)
    if not re.fullmatch(r"[A-Za-z0-9_. -]+:[1-9][0-9]*", item_id):
        return None
    evidence = definitions.cs.evidence_for(str(product), item_id, data=data, reader="ai")
    pieces = [str(evidence["required_rule"])]
    if evidence.get("_notes"):
        pieces.append("Notes: " + str(evidence["_notes"]))
    for key, value in evidence.get("_spec_columns") or []:
        pieces.append(str(key) + ": " + (value if isinstance(value, str) else _json(value)))
    body = "\n".join(pieces)
    label = str(evidence.get("_variable") or item_id)
    if not _safe_text(label + "\n" + body):
        return None
    identifier = "related_" + _hash([target, item_id])[:16]
    source = {"id": identifier, "kind": kind, "label": label + " · " + item_id, "text": body}
    reference = {"source_id": identifier, "pack": target, "item_id": item_id,
                 "artifact": "spec_pipeline/out/extracted.json", "source_status": material["status"],
                 "ai_classification": material["ai_classification"], "spec_digest": evidence["spec_digest"]}
    return source, reference


def _spec_context(root, pack, actor_id, selected, values, *, allowed_packs):
    """Return bounded JSON data; optional unavailable evidence never blocks a row.

    All source prose is untrusted reference data. `related_spec` gives context
    for this product; `precedent` is a matching specification in an accessible
    peer. Neither kind is authority to fill an unresolved current-row choice.
    """
    result = {"sources": [], "overview": {}, "references": [], "notices": [], "digest": "0" * 64}
    bindings, candidates = [], []
    omitted = {"unavailable_products": 0, "unsafe_rows": 0, "unmatched_rows": 0, "budget_rows": 0}
    try:
        base, pack, owner, _folder, scope = science_workspace._scope(root, pack, actor_id, allowed_packs)
    except (OSError, ValueError, TypeError, KeyError, AttributeError, yaml.YAMLError):
        result["notices"] = ["Broader scientific context is unavailable for this access scope."]
        result["digest"] = _hash(result)
        return result
    query = " ".join(str(value or "") for value in
                     (selected.get("label"), selected.get("definition"), values.get("variable_id")))
    terms = sorted(workflow_skills._tokens(query))
    domains = Counter()
    current_rows = 0
    for target in sorted(scope, key=lambda name: (name != pack, name)):
        try:
            product, target, data, material, binding = _product_snapshot(base, target, actor_id, scope)
            bindings.append([target, "eligible", binding])
            rows = definitions.requirement_rows(data)
            ids = [definitions.row_item_id(row) for row in rows]
            if len(set(ids)) != len(ids):
                raise ValueError("Ambiguous optional row references.")
            ranked_rows = []
            for row, item_id in zip(rows, ids):
                if target == pack:
                    current_rows += 1
                    domain = str(row.get("domain") or row["tab"])
                    if re.fullmatch(r"[A-Za-z0-9_ -]{1,50}", domain) and _safe_text(domain):
                        domains[domain] += 1
                if target == pack and item_id == selected.get("item_id"):
                    continue
                definition, notes = definitions.cs._definition_and_notes(row)
                haystack = " ".join((str(row.get("variable") or ""), definition, str(notes or "")))
                # Reuse the workbench's literal relevance function over this
                # eligible pool only; no separate cross-product index is built.
                score = sum(knowledge_search._matches(haystack, [term]) for term in terms)
                domain = str(row.get("domain") or "").lower()
                study_context = target == pack and domain in _STUDY_DOMAINS
                if not score and not study_context:
                    omitted["unmatched_rows"] += 1
                    continue
                rank = (0 if study_context else 1 if target == pack else 2, -score, target, item_id)
                ranked_rows.append((rank, row))
            ranked_rows.sort(key=lambda entry: entry[0])
            omitted["budget_rows"] += max(0, len(ranked_rows) - MAX_CANDIDATE_ROWS)
            for rank, row in ranked_rows[:MAX_CANDIDATE_ROWS]:
                candidate = _candidate(product, target, row, data, material,
                                       "related_spec" if target == pack else "precedent")
                if candidate is None:
                    omitted["unsafe_rows"] += 1
                    continue
                candidates.append((rank, candidate))
            # Gate again after assembling references, and compare the precise
            # approved inputs rather than accepting a mid-read source change.
            if _product_snapshot(base, target, actor_id, scope)[-1] != binding:
                raise ValueError("The optional source changed while reading.")
        except (OSError, ValueError, TypeError, KeyError, AttributeError,
                definitions.cs.NotApprovedForAI, source_manifest.Unreadable, yaml.YAMLError):
            candidates = [entry for entry in candidates if entry[1][1]["pack"] != target]
            bindings.append([target, "unavailable"])
            omitted["unavailable_products"] += 1
            if target == pack:
                current_rows, domains = 0, Counter()
    result["overview"] = {"current_product_requirement_rows": current_rows,
                          "domains": dict(sorted(domains.items())[:12]), "omitted": omitted}
    result["notices"] = [
        "Related rows give study context; peer specifications are comparison examples, not adopted decisions.",
        "Source status describes the AI-approved extraction only."]
    if len(scope) == 1:
        result["notices"].append("No other product was included in the permitted comparison scope.")
    result["digest"] = _hash({"actor": owner, "pack": pack, "scope": sorted(scope), "query": terms, "inputs": bindings})
    for _rank, (source, reference) in sorted(candidates):
        result["sources"].append(source)
        result["references"].append(reference)
        if len(json.dumps(result, ensure_ascii=False).encode("utf-8")) > MAX_BYTES - 180:
            result["sources"].pop()
            result["references"].pop()
            omitted["budget_rows"] += 1
    if not result["sources"]:
        result["notices"].append("No eligible broader scientific material was selected; use the current row and state any missing evidence.")
    return result


def _optional(path, inputs, *, root):
    """Read one bounded fixed input, including absence in the freshness identity."""
    definitions._safe(path)
    relative = path.relative_to(root).as_posix()
    raw = definitions._read(path) if path.is_file() else None
    inputs[relative] = raw
    return raw


@lru_cache(maxsize=8)
def _yaml(raw):
    from engine.strict_yaml import strict_load
    return strict_load(raw.decode("utf-8")) if raw else {}


def _score(text, terms):
    # Short clinical tokens such as the two halves of PD-L1 must not match
    # incidental identifier substrings ("l1" in "CL1914012"). Keep the
    # canonical reader's fragment matching for meaningful longer terms.
    return sum(knowledge_search._matches(text, [term]) for term in terms
               if len(term) > 3 or re.search(r"(?<![a-z0-9])" + re.escape(term) + r"(?![a-z0-9])", text, re.I))


def _entry(kind, label, text, reference, terms, *, match_score=None):
    """Whole records only: qualification, exclusions and uncertainty stay together."""
    score = _score(label + " " + text, terms) if match_score is None else match_score
    if not score or not _safe_text(label + "\n" + text + "\n" + _json(reference)):
        return None
    identifier = "knowledge_" + _hash([kind, reference.get("pack"), reference["artifact"], label])[:16]
    return (-score, {"id": identifier, "kind": kind, "label": label, "text": text},
            {"source_id": identifier, **reference})


def _recorded_context(root, pack, actor_id, scope, terms):
    """Project existing authored records after exactly the specialist's AI gate.

    Specification quotations and source-document paths are deliberately absent
    from these projections. Status is the file's assertion, not authentication.
    """
    import contract_lint as cl
    import knowledge_graph as kg
    candidates, bindings, omitted = [], [], 0
    for target in sorted(scope, key=lambda value: (value != pack, value)):
        inputs, proposed = {}, []
        try:
            product, target, _data, material, source_binding = _product_snapshot(root, target, actor_id, scope)
            config = _yaml(_optional(product / "config/data_product.yaml", inputs, root=root))
            if not isinstance(config, dict):
                raise ValueError("Unreadable source identity")
            applicability = {key: str(config.get(key) or "not declared") for key in ("vendor", "modality")}
            applicability["pack_version"] = target.split("/")[-1]
            common = {"pack": target, "applicability": applicability,
                      "source_status": material["status"], "ai_classification": material["ai_classification"],
                      "review_note": "Recorded status only; not authenticated here or adopted for this study."}
            contract = _optional(product / "handoff/FUNCTIONAL_CONTRACT.md", inputs, root=root)
            decisions = _optional(product / "handoff/DECISIONS.md", inputs, root=root)
            decision_text = decisions.decode("utf-8").replace("\r\n", "\n") if decisions else ""
            if decision_text and cl.decision_register_errors(decision_text, "DECISIONS.md"):
                raise ValueError("Inconsistent decision register")
            statuses = cl.decision_status(decision_text)
            if contract:
                records = list(cl.typed_records(contract.decode("utf-8").replace("\r\n", "\n"), keep_unnamed=True))
                identifiers = [record.variable_id.casefold() for record in records]
                if not all(identifiers) or len(set(identifiers)) != len(identifiers):
                    raise ValueError("Ambiguous recorded definitions")
                for record in records:
                    if record.requirement() != "approved" or any(statuses.get(did) != "RESOLVED" for did in record.decision_ids):
                        continue
                    fields = {key: record.cells.get(key, "") for key in
                              ("derivation", "grain", "anchor", "window", "record_selection", "tie_break",
                               "missing", "cohort_applicability", "units", "depends_on", "output", "acceptance", "notes")}
                    if not fields["derivation"] or re.search(r"\bTODO\b|REPLACE_ME", _json(fields), re.I):
                        continue
                    entry = _entry("recorded_definition", record.variable_id + " · " + target,
                        _json(fields), {**common, "artifact": "handoff/FUNCTIONAL_CONTRACT.md",
                        "artifact_sha256": _hash(contract), "record_id": record.variable_id,
                        "recorded_status": record.status, "decision_ids": record.decision_ids,
                        "spec_digest": record.spec_digest}, terms)
                    if entry:
                        proposed.append(entry)
            for did, row in sorted(cl.decision_rows(decision_text).items()):
                node = {"status": str(statuses.get(did) or ""), "approved_by": cl.decision_approver(row).strip(),
                        "approval_date": cl.decision_approval_date(row).strip()}
                if not kg.ruled(node):
                    continue
                text = _json({"question": cl.decision_question(row), "answer": cl.decision_answer(row)})
                if not cl.decision_answer(row).strip() or re.search(r"\bTODO\b|REPLACE_ME", text, re.I):
                    continue
                entry = _entry("recorded_decision", did + " · " + target, text,
                    {**common, "artifact": "handoff/DECISIONS.md", "artifact_sha256": _hash(decisions),
                     "record_id": did, "recorded_status": node["status"],
                     "recorded_reviewer": node["approved_by"], "recorded_review_date": node["approval_date"]}, terms)
                if entry:
                    proposed.append(entry)
            code_lists = config.get("codelists") or {}
            if not isinstance(code_lists, dict):
                raise ValueError("Unreadable configured code lists")
            for name, relative in sorted(code_lists.items()):
                if not isinstance(relative, str) or not relative.startswith("codelists/") or ".." in Path(relative).parts:
                    continue
                path = product / relative
                raw = _optional(path, inputs, root=root)
                doc = _yaml(raw)
                if not raw or not isinstance(doc, dict):
                    continue
                entry = _entry("product_codelist", str(name) + " · " + target, _json(doc),
                    {**common, "artifact": relative, "artifact_sha256": _hash(raw),
                     "recorded_status": "Configured code list; clinical validity and target-source applicability need review."}, terms)
                if entry:
                    proposed.append(entry)
            proposed.extend(_source_dictionary(root, product, config, inputs, common, terms))
            # Same gate and exact bytes again, including formerly absent files.
            if _product_snapshot(root, target, actor_id, scope)[-1] != source_binding:
                raise ValueError("Source changed")
            for relative, raw in inputs.items():
                check = root / relative
                definitions._safe(check)
                if (definitions._read(check) if check.is_file() else None) != raw:
                    raise ValueError("Reference changed")
            candidates.extend(proposed)
            bindings.append([target, source_binding, _hash({key: _hash(raw) if raw else None for key, raw in inputs.items()})])
        except (OSError, ValueError, TypeError, KeyError, AttributeError,
                definitions.cs.NotApprovedForAI, source_manifest.Unreadable, yaml.YAMLError):
            omitted += 1
            bindings.append([target, "authored records unavailable"])
    return candidates, bindings, omitted


def _source_dictionary(root, product, config, inputs, common, terms):
    """Names/types from the existing registered, reviewed mapping-evidence reader.

    Raw vendor dictionaries and profiler values are never read. The registration
    and the exact file must independently permit model use, on this data cut.
    """
    import propose_source_mapping as mapping
    import mapping_evidence
    registered = [row for row in source_manifest.materials(str(product)) or []
                  if row.get("material_type") == source_manifest.AI_MAPPING_EVIDENCE]
    if len(registered) != 1:
        return []
    registration = source_manifest.ai_mapping_evidence(str(product))
    if not registration or not source_manifest.ai_eligible(registration) or registration.get("status") != "reviewed":
        return []
    path = Path(source_manifest.material_file(str(product), registration.get("path_or_link"), root=str(root)))
    if not path.is_absolute():
        path = root / path
    definitions._safe(path)
    if not path.is_relative_to(product) or path.suffix.lower() != ".json":
        return []
    raw = _optional(path, inputs, root=root)
    if not raw:
        return []
    doc = definitions._json(raw)
    try:
        tables, cuts = mapping._tables_and_cuts(str(product), str(path))
    except SystemExit:
        return []
    refresh = str((config.get("run") or {}).get("refresh") or "")
    if not refresh or doc.get("cut") != refresh or set(cuts) != {refresh}:
        return []
    output = []
    for table, columns in sorted(tables.items()):
        if not re.fullmatch(r"[A-Za-z][A-Za-z0-9_]{0,127}", table):
            continue
        for column, metadata in sorted(columns.items()):
            if (not re.fullmatch(r"[A-Za-z][A-Za-z0-9_]{0,127}", column)
                    or metadata.get("kind") not in mapping_evidence.KINDS):
                continue
            datatype = metadata.get("type")
            if datatype is not None and not re.fullmatch(r"[A-Za-z][A-Za-z0-9_.]{0,31}", str(datatype)):
                continue
            entry = _entry("source_dictionary", table + "." + column,
                _json({"table": table, "column": column, **metadata}),
                {**common, "artifact": path.relative_to(product).as_posix(), "artifact_sha256": _hash(raw),
                 "reference_version": {"data_cut": refresh, "profile_sha256": doc.get("profile_sha256")},
                 "recorded_status": "Reviewed names/types only; clinical meaning, completeness of derivations and mappings still require review.",
                 "record_id": table + "." + column}, terms)
            if entry:
                output.append(entry)
    return output


def shared_templates(root, actor_id, allowed_packs, query):
    """Read the existing committed library across authors within source access.

    The promotion validator remains authoritative. This adapter adds the same
    access and source-path checks as the library workbench, plus the AI gate.
    Empty libraries are expected: the reader never invents a reviewed RDQ.
    """
    import product_gates as gates
    import source_workspace as storage
    import template_promote as promotion
    root = Path(root).resolve()
    scope = set(allowed_packs or [])
    terms = sorted(workflow_skills._tokens(query))
    inputs, bindings, entries, notices, seen, conflicted = {}, [], [], [], set(), set()
    folder = root / promotion.RELEASES
    try:
        definitions._safe(folder)
        paths = sorted(folder.glob("*.yaml"))
        if len(paths) > 100:
            raise ValueError("Library exceeds bounded reader")
        for path in paths:
            raw = _optional(path, inputs, root=root)
            doc = _yaml(raw)
            if not isinstance(doc, dict) or not isinstance(doc.get("source"), dict):
                continue
            source = doc["source"].get("pack")
            key = (str(doc.get("template_id")), str(doc.get("version")))
            if key in seen:
                conflicted.add(key)
            seen.add(key)
            if source not in scope:
                continue
            try:
                product, _pack, _data, _material, binding = _product_snapshot(root, source, actor_id, scope)
                storage._configured_inputs(product)
                permitted = set(gates.semantic_manifest(str(product), str(root)))
                if set(doc["source"].get("semantic_manifest") or {}) - permitted:
                    continue
                if promotion.release_errors(doc, str(root)) or (doc.get("lifecycle") or {}).get("status") != "active":
                    continue
                if not isinstance(doc.get("excludes"), list) or not doc["excludes"] or any(not isinstance(value, str) or not value.strip() for value in doc["excludes"]):
                    continue
                relative = path.relative_to(root).as_posix()
                if promotion._git_bytes(str(root), "show", "HEAD:" + relative) != raw:
                    continue
                if _product_snapshot(root, source, actor_id, scope)[-1] != binding:
                    continue
                bindings.append([source, binding])
                for concept in doc["concepts"]:
                    body = {name: concept.get(name) for name in ("slot", "variable_id", "clinical_role", "applicability",
                        "definition", "shape", "source_requirements", "evidence", "parameters", "parameter_values")}
                    body["excludes"] = doc.get("excludes")
                    entry = _entry("shared_template", "@".join(key) + " · " + str(concept["slot"]), _json(body),
                        {"artifact": relative, "artifact_sha256": _hash(raw), "pack": source,
                         "record_id": str(concept["slot"]), "reference_version": key[1],
                         "recorded_status": "Active shared library version; recorded review does not approve this study.",
                         "applicability": {"cancer": doc["cancer"], "excludes": doc.get("excludes")},
                         "issued_at_commit": doc["source"].get("issued_at_commit"),
                         "reviewers": doc.get("reviewers"), "provenance_notices": promotion.release_notices(doc, str(root))}, terms)
                    if entry:
                        entries.append((key, entry))
            except (OSError, ValueError, TypeError, KeyError, AttributeError,
                    definitions.cs.NotApprovedForAI, source_manifest.Unreadable, yaml.YAMLError):
                continue
        if sorted(folder.glob("*.yaml")) != paths:
            raise ValueError("Library changed")
        for relative, raw in inputs.items():
            if definitions._read(root / relative) != raw:
                raise ValueError("Library changed")
        rows = [entry for key, entry in entries if key not in conflicted]
        if not rows:
            notices.append("No matching active shared example is available with readable review evidence. Shared-library reuse can promote a reviewed concept for future users; private unchecked requests are not shared examples.")
        if conflicted:
            notices.append("Conflicting shared template versions were withheld; resolve the library entries before reuse.")
        return rows, _hash([bindings, {key: _hash(raw) for key, raw in inputs.items()}]), notices
    except (OSError, ValueError, TypeError, KeyError, AttributeError, yaml.YAMLError):
        return [], "unavailable", ["Shared examples could not be verified. Review the shared-library source and version before reuse."]


@lru_cache(maxsize=1)
def _clinical_generic():
    return workflow_skills._tokens(
        "all any another available unavailable standard defined missing date dates cutoff last first second new "
        "study studies patient patients person people adult adults child children age year month day time timing "
        "line treatment therapy systemic source data table column database record field code codes clinical cancer "
        "tumor tumour neoplasm malignant malignancy benign advanced metastatic recurrent human cell cellular "
        "outcome result index end follow followup population product start create use define propose review "
        "variable window condition group category type method test marker score scoring status performance "
        "risk high low positive negative normal abnormal stage staging assessment level value set system report "
        "description name observation observable event activity current prior previous next recent latest "
        "baseline reference evidence interpretation decision question answer option choice clear unclear "
        "useful exact complete completeness incomplete recorded verified selected common specific possible "
        "primary secondary local general total clinical diagnostic diagnosis procedure drug medication "
        "mapping dictionary terminology catalogue algorithm rule definition form request private draft "
        "synthetic fixture example proposed received receiving include inclusion exclusion exclude "
        "needed need should would could may might help compare comparison distinguish different same "
        "share shared meaning known unknown not sure none supplied supporting support documented "
        "preserve assume assumption question brief consumers intended acceptance criterion criteria "
        "death blood tissue specimen serum plasma urine gene genetic genetics molecular mutation found identifier")


def _clinical_terms(text):
    """Whole concept tokens, including spelling variants such as PD-L1/PDL1.

    A vocabulary lookup is narrower than the general library's fragment search:
    `last` must not match `lymphoblastic`, nor may JSON field names rank a code.
    Generic qualifiers cannot identify a disease, biomarker or named instrument.
    """
    compact = re.sub(r"(?<=[A-Za-z0-9])-(?=[A-Za-z0-9])", "", text)
    return {term for term in workflow_skills._tokens(text) | workflow_skills._tokens(compact)
            if len(term) >= 3 and term not in _clinical_generic()}


def _clinical_match(query, query_terms, code, description, value_set):
    # An explicit complete identifier can be looked up even if its label has no
    # distinctive word. Boundaries prevent a partial code/column-name match.
    if re.search(r"(?<![A-Za-z0-9_])" + re.escape(code) + r"(?![A-Za-z0-9_])", query, re.I):
        return 100
    # LOINC descriptions name the analyte before specimen/method qualifiers.
    # Colorectal cancer in a KRAS assay's specimen context does not make that
    # assay evidence for a colorectal procedure cohort.
    primary = re.split(r"\b(?:in|by|from|with)\b", str(description or ""), maxsplit=1, flags=re.I)[0]
    score = len(query_terms & _clinical_terms(primary))
    # A complete named value-set request can retrieve its enumerated values;
    # one generic word from its title cannot make every member relevant.
    title = re.sub(r"\s+(?:value set|vs)\s*$", "", str(value_set or ""), flags=re.I)
    title_words = " ".join(re.findall(r"[a-z0-9]+", title.casefold()))
    query_words = " ".join(re.findall(r"[a-z0-9]+", query.casefold()))
    if _clinical_terms(title) and title_words and " " + title_words + " " in " " + query_words + " ":
        score += 1
    return score


def _clinical_context(root, query):
    """Use mCODE's enumerated public vocabulary entries; never infer exact codes.

    UMLS's local consultation switch is checked without opening its projections.
    Restricted labels are not sent to a provider without a separate disclosure
    grant. No source licence or AI-classification record is changed here.
    """
    import semantic_binding as semantic
    import umls_subset
    terms = _clinical_terms(query)
    inputs, candidates, notices = {}, [], []
    try:
        switch = root / "governance/reference/umls/LAYER.yaml"
        _optional(switch, inputs, root=root)
        state = umls_subset.layer_state(str(switch))
        notices.append("UMLS is enabled for local consultation but its licensed projections are not supplied to the assistant; model disclosure needs a separate authorised source registration."
            if state.get("enabled") else "The UMLS layer was not consulted because its licence switch is disabled or unavailable.")
        path = root / "governance/reference/mcode_stu4/VALUE_SET_CODES.json"
        raw = _optional(path, inputs, root=root)
        if raw:
            doc = definitions._json(raw)
            if not isinstance(doc, dict) or not isinstance(doc.get("codes"), list):
                raise ValueError("Unreadable clinical vocabulary")
            guide = doc.get("implementation_guide") or {}
            # The existing canonical lab-code reader supplies the same LOINC
            # names as the workbench. Other public systems use these enumerated
            # mCODE value-set rows; restricted SNOMED/UMLS labels are withheld.
            labs = semantic.lab_codes(str(path))
            artifact_digest = _hash(raw)
            public_systems = {"LOINC", "NCIT", "RxNorm", "ICD-10-CM", "ICD10CM"}
            meanings = {}
            for row in doc["codes"]:
                if isinstance(row, dict) and row.get("code_system") in public_systems and row.get("code"):
                    key = (row["code_system"], str(row["code"]))
                    meanings.setdefault(key, set()).add(str(row.get("description") or "").strip().casefold())
            conflicting_codes = {key for key, labels in meanings.items() if len(labels) > 1}
            if conflicting_codes:
                notices.append("Clinical reference codes with conflicting recorded descriptions were withheld; a terminology reviewer must resolve those source rows.")
            for row in doc["codes"]:
                if not isinstance(row, dict) or row.get("code_system") not in public_systems:
                    continue
                system, code = row["code_system"], str(row.get("code") or "")
                if not code or (system, code) in conflicting_codes:
                    continue
                description = labs.get(code) if system == "LOINC" else row.get("description")
                if system == "LOINC" and description != row.get("description"):
                    # The canonical lab reader is code keyed. Do not attach its
                    # final label to an earlier, differently labelled row.
                    continue
                score = _clinical_match(query, terms, code, description, row.get("value_set"))
                if not score:
                    continue
                text = _json({"code_system": system, "code": code, "description": description,
                              "value_set": row.get("value_set")})
                entry = _entry("clinical_code", system + " " + code + " · " + str(row.get("value_set") or "mCODE"), text,
                    {"artifact": "governance/reference/mcode_stu4/VALUE_SET_CODES.json", "artifact_sha256": artifact_digest,
                     "reference_version": {"dictionary_ig_version": guide.get("IG version"),
                                           "package_version": (guide.get("package") or {}).get("version")},
                     "source_url": guide.get("IG URL"), "recorded_status": "Enumerated reference code; candidate for scientific review.",
                     "applicability": "Clinical vocabulary evidence; availability and coding in the selected database are not established."}, terms,
                    match_score=score)
                if entry:
                    candidates.append(entry)
            notices.append("Clinical codes come from the supplied mCODE enumeration and recorded product lists. They are not a complete or validated phenotype; review source coding, exclusions and timing.")
        else:
            notices.append("The mCODE code reference is not installed; no exact clinical codes were retrieved from it.")
        for relative, raw in inputs.items():
            path = root / relative
            definitions._safe(path)
            if (definitions._read(path) if path.is_file() else None) != raw:
                raise ValueError("Reference changed")
        return candidates, _hash({key: _hash(raw) if raw else None for key, raw in inputs.items()}), notices
    except (OSError, ValueError, TypeError, KeyError, AttributeError, yaml.YAMLError):
        return [], "unavailable", ["Clinical reference metadata is unavailable or changed while reading; no codes were supplied from it."]


def reference_examples(root, query):
    """Literature-derived inventory guidance, never a reviewed study definition.

    Preserve the entire scientific sketch, source requirements and citations.
    Product-derived entries require their product authorization and are supplied
    by the separate scoped readers instead of this public-reference path.
    """
    import citation_register as citations
    import inventory_coverage as coverage
    root = Path(root).resolve()
    path = root / "governance/reference/variable_inventory/INVENTORY.yaml"
    inputs, output = {}, []
    try:
        raw = _optional(path, inputs, root=root)
        if not raw:
            return [], "absent"
        doc = _yaml(raw)
        if not isinstance(doc, dict) or coverage.coverage_errors(doc):
            return [], "invalid"
        terms = sorted(workflow_skills._tokens(query))
        tumors = doc.get("tumours") or {}
        # A named disease constrains the comparison. Cross-tumour matches on
        # generic words such as "line" cannot overrule an explicit NSCLC brief.
        query_words = set(re.findall(r"[a-z0-9]+", query.casefold()))
        selected = {tumor for tumor in tumors if tumor.casefold() in query_words}
        if not selected:
            generic = {"cancer", "carcinoma", "advanced", "metastatic", "cell", "non", "small", "solid", "disease", "and", "or"}
            identities = {tumor: set(re.findall(r"[a-z0-9]+", str(body.get("tumour") or tumor).casefold())) - generic
                          for tumor, body in tumors.items()}
            best = max((len(words & query_words) for words in identities.values()), default=0)
            if best:
                selected = {tumor for tumor, words in identities.items() if len(words & query_words) == best}
        if not selected:
            return [], _hash(raw)
        for tumor, body in sorted(tumors.items()):
            if selected and tumor not in selected:
                continue
            names = [str(row.get("name") or "").casefold() for row in body.get("variables") or []]
            duplicates = {name for name in names if names.count(name) > 1}
            for variable in body.get("variables") or []:
                cites = variable.get("citations") or []
                if (str(variable.get("name") or "").casefold() in duplicates or not cites
                        or any(str(cite).lstrip().casefold().startswith("in-house:") for cite in cites)
                        or citations.basis_of(variable) != "literature_inferred"):
                    continue
                payload = {key: variable.get(key) for key in ("name", "definition_sketch", "common_sources", "citations", "parameter_values")}
                payload["caveats"] = body.get("caveats")
                focused_terms = [term for term in terms if term != tumor.casefold()]
                # Keep partial name matches (PD-L1/PDL1), but require scientific
                # content beyond the disease label when such content is given.
                if focused_terms and not _score(_json(payload), focused_terms):
                    continue
                entry = _entry("reference_example", str(tumor) + " · " + str(variable.get("name")), _json(payload),
                    {"artifact": path.relative_to(root).as_posix(), "artifact_sha256": _hash(raw),
                     "record_id": str(tumor) + ":" + str(variable.get("name")),
                     "reference_version": "sha256:" + _hash(raw),
                     "recorded_status": "Literature-derived reference only; citations and scientific applicability require review.",
                     "applicability": {"tumour": tumor, "database": "Not established by this reference inventory"}}, terms)
                if entry:
                    output.append(entry)
        if definitions._read(path) != raw:
            return [], "changed"
        return output, _hash(raw)
    except (OSError, ValueError, TypeError, KeyError, AttributeError, yaml.YAMLError):
        return [], "unavailable"


def build_chat(root, pack, actor_id, query, *, allowed_packs, max_bytes=MAX_BYTES):
    """Read-only, explicit-call API for the guide and row/decision conversations.

    Call again with the identical arguments after generation; a changed digest
    invalidates the response. `pack=None` reads shared public references only.
    No hidden product corpus, new index, provider call or persistent write exists.
    `max_bytes` includes UTF-8 metadata and keeps whole evidence records.
    """
    result = {"sources": [], "references": [], "notices": [], "digest": "0" * 64}
    if type(max_bytes) is not int or not 512 <= max_bytes <= MAX_BYTES:
        raise ValueError("Scientific context budget must be between 512 and 4500 bytes.")
    try:
        root = Path(root).resolve()
        if not isinstance(actor_id, str) or not actor_id.strip() or len(actor_id) > 300 or any(ord(c) < 32 for c in actor_id):
            raise ValueError("An identified session is required")
        if not isinstance(query, str) or len(query) > 4000 or not _safe_text(query):
            raise ValueError("Use a bounded scientific question")
        if pack:
            root, pack, owner, _folder, scope = science_workspace._scope(root, pack, actor_id, allowed_packs)
        else:
            owner, scope = _hash(actor_id.strip()), set()
        # Preserve both clinical spelling and the common compact identifier:
        # PD-L1 may be recorded as PDL1_TPS, without making its short "l1"
        # component match arbitrary catalogue identifiers.
        compact = re.sub(r"(?<=[A-Za-z0-9])-(?=[A-Za-z0-9])", "", query)
        terms = sorted(workflow_skills._tokens(query) | workflow_skills._tokens(compact))
        candidates, bindings, unavailable = _recorded_context(root, pack, actor_id, scope, terms)
        clinical, clinical_binding, notices = _clinical_context(root, query)
        shared, shared_binding, shared_notices = shared_templates(root, actor_id, allowed_packs, query)
        examples, example_binding = reference_examples(root, query)
        # Mix useful evidence types before a second item of the same kind, so a
        # long code-list match cannot crowd every scientific precedent away.
        candidates += clinical + shared + examples
        unique, conflicts = {}, set()
        for entry in candidates:
            identifier = entry[1]["id"]
            if identifier in unique and unique[identifier] != entry:
                conflicts.add(identifier)
            unique[identifier] = entry
        candidates = [entry for key, entry in unique.items() if key not in conflicts]
        result["notices"] = ["Prior interpretations and named rulings are comparison evidence. Recorded review does not authenticate an identity or approve reuse for this study."] + notices + shared_notices
        if pack and not any(entry[1]["kind"] == "source_dictionary" for entry in candidates):
            result["notices"].append("No matching authorised database dictionary entry was retrieved. Use Source review to register reviewed names/types for the current delivery; raw vendor dictionaries and patient values are not supplied to chat.")
        if conflicts:
            result["notices"].append("Conflicting reference rows were withheld; review their source register before reusing them.")
        if unavailable:
            result["notices"].append(str(unavailable) + " accessible product(s) had no usable AI-authorised authored context.")
        result["digest"] = _hash({"actor": owner, "pack": pack, "scope": sorted(scope), "query": terms,
                                  "inputs": bindings, "clinical": clinical_binding, "shared": shared_binding,
                                  "reference_examples": example_binding, "budget": max_bytes})
        ordered, used, remaining = [], set(), []
        for entry in sorted(candidates, key=lambda value: (value[0], value[1]["id"])):
            kind = entry[1]["kind"]
            if kind in used:
                remaining.append(entry)
            else:
                ordered.append(entry)
                used.add(kind)
        ordered += remaining
        omitted = 0
        # Reserve an explicit omission notice. Small budgets trim optional
        # general notices before dropping the exact source/reference pair.
        while len(json.dumps(result, ensure_ascii=False).encode()) > max_bytes - 120 and result["notices"]:
            result["notices"].pop()
        for _rank, source, reference in ordered:
            result["sources"].append(source)
            result["references"].append(reference)
            if len(json.dumps(result, ensure_ascii=False).encode()) > max_bytes - 120:
                result["sources"].pop()
                result["references"].pop()
                omitted += 1
        if omitted:
            result["notices"].append(str(omitted) + " matching evidence record(s) omitted whole to keep this conversation bounded.")
        if not result["sources"] and not omitted:
            result["notices"].append("No matching eligible clinical code or recorded scientific precedent was retrieved.")
    except (OSError, ValueError, TypeError, KeyError, AttributeError, yaml.YAMLError):
        result = {"sources": [], "references": [], "notices": ["Scientific evidence is unavailable for this request and access scope."],
                  "digest": _hash(["unavailable", str(pack)])}
    return result


def build(root, pack, actor_id, selected, values, *, allowed_packs):
    """One bounded context across extraction, authored decisions and vocabulary."""
    result = _spec_context(root, pack, actor_id, selected, values, allowed_packs=allowed_packs)
    query = " ".join(str(value or "") for value in (selected.get("label"), selected.get("definition"), values.get("variable_id")))
    knowledge = build_chat(root, pack, actor_id, query[:4000], allowed_packs=allowed_packs)
    result["digest"] = _hash([result["digest"], knowledge["digest"]])
    # Offer the first match from each evidence kind before additional rows of
    # one kind. A long extraction must not make the newly connected decision
    # library invisible. The selected row itself is a separate mandatory input.
    pairs = list(zip(result["sources"], result["references"])) + list(zip(knowledge["sources"], knowledge["references"]))
    first, rest, kinds = [], [], set()
    for pair in pairs:
        kind = pair[0]["kind"]
        (rest if kind in kinds else first).append(pair)
        kinds.add(kind)
    result["sources"], result["references"] = [], []
    result["notices"] += knowledge["notices"][:1]
    for source, reference in first + rest:
        result["sources"].append(source)
        result["references"].append(reference)
        if len(json.dumps(result, ensure_ascii=False).encode()) > MAX_BYTES - 120:
            result["sources"].pop()
            result["references"].pop()
            result["overview"].setdefault("omitted", {}).setdefault("budget_rows", 0)
            result["overview"]["omitted"]["budget_rows"] += 1
    # Surface reference availability even if no code matched.
    for notice in knowledge["notices"][1:]:
        result["notices"].append(notice)
        if len(json.dumps(result, ensure_ascii=False).encode()) > MAX_BYTES:
            result["notices"].pop()
    return result
