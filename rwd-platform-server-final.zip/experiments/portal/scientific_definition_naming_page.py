"""Explain specification labels and let a drafter explicitly reuse a recorded name."""
from pathlib import Path

import streamlit as st

import scientific_definition_naming as naming


def render(root, pack, source_label, *, actor_id, allowed_packs=None, can_write=False, item_id=None, expanded=False):
    prefix = "definition_naming_"
    context = (str(Path(root).resolve()), pack, source_label, item_id, actor_id, bool(can_write),
               None if allowed_packs is None else tuple(sorted(allowed_packs)))
    previous_context = st.session_state.get(prefix + "context")
    context_changed = previous_context is not None and previous_context != context
    if previous_context != context:
        for key in list(st.session_state):
            if str(key).startswith(prefix):
                st.session_state.pop(key, None)
        st.session_state[prefix + "context"] = context
    with st.expander("Use a consistent variable name", expanded=expanded):
        st.write("Start with names related to this requirement, or browse the prior list. Select one to read its existing definitions here before proposing it.")
        st.caption("The existing naming registry checks spelling, recorded naming decisions and declared types. "
                   "A similar spelling is a review question; it does not establish that two definitions mean the same thing.")
        st.text("Specification label: " + source_label)
        browse = st.checkbox("Browse all available names", key=prefix + "browse",
                             help="Shows this product's configured names and contract names from products you can access.")
        query = st.text_input("Find an existing output name", key=prefix + "query",
                              placeholder="Optional: search age, ecog or an exact identifier",
                              help="Leave blank for suggestions from this row's literal wording and identifiers. Browse all available names to inspect the prior list.")
        result = naming.describe(root, pack, source_label, query=query.strip() or ("" if browse else None), allowed_packs=allowed_packs)
        for message in result.get("errors") or []:
            st.warning(message)
        for message in result.get("warnings") or []:
            st.caption(message)
        _resolve_conflicts(root, pack, actor_id, result, prefix, allowed_packs, can_write)
        candidates = result["candidates"]
        if candidates:
            st.caption(f"{len(candidates)} available name(s). A match in wording is a suggestion for review.")
            choices = {row["name"]: row for row in candidates}
            if st.session_state.get(prefix + "choice") not in choices:
                st.session_state.pop(prefix + "choice", None)
            chosen = st.selectbox("Existing output name to review", list(choices), index=None,
                                  key=prefix + "choice")
            if chosen:
                row = choices[chosen]
                st.write("**Name evidence · optional product examples**")
                st.caption("Declared type: " + (", ".join(row["types"]) or "not recorded") + " · Naming state: "
                           + (", ".join(sorted(set(row["name_states"].values()))) or "configured output"))
                prior = row.get("definitions") or []
                if not prior:
                    st.info("This name is configured, but no accessible scientific definition is recorded for it. Its meaning still needs review.")
                for definition in prior:
                    current = definition["pack"] == pack
                    label = "Current-product definition" if current else "Prior-product example"
                    with st.expander(label + " · " + definition["variable_id"] + " · " + definition["pack"], expanded=False):
                        st.text(("Current-product requirement: " if current else "Prior-product example value / requirement: ")
                                + (definition["requirement"] or "Not recorded"))
                        st.text(("Current-product interpretation: " if current else "Prior-product example interpretation: ")
                                + (definition["rule"] or "Not recorded"))
                        st.dataframe(definition["answers"], hide_index=True, width="stretch")
                        st.caption("Citations: " + (", ".join(definition["spec_refs"]) or "not recorded")
                                   + " · Recorded status: " + (definition["status"] or "not recorded"))
                st.caption("Prior definitions are comparison evidence. Their interpretation, type and approval are not copied into this row.")
                st.caption("Example dates and values belong to the cited product. They are not values for the current product or part of the shared master variable definition.")
                for ruling in row["rulings"]:
                    st.write(f"Recorded naming decision: {ruling['a']} / {ruling['b']} · {ruling['ruling']} · "
                             f"standard: {ruling.get('standard') or 'not specified'} · reference: {ruling.get('decision_id') or 'not specified'}")
                if len(row["types"]) > 1:
                    st.warning("This name has conflicting declared types. Review the relevant definitions before reuse.")
                if row.get("naming_conflict"):
                    st.warning("Conflicting naming decisions remain open. Review their explicit replacement above before reusing this name.")
                if row["retired"]:
                    st.warning("This name is retired. Review its successor: " + str(row["successor"] or "not recorded"))
            with st.expander("Naming registry details"):
                st.dataframe([{"Existing name": row["name"], "Match": row["match"], "Recorded in": row["basis"],
                               "Declared types": ", ".join(row["types"]) or "Not declared here",
                               "Naming state": ", ".join(sorted(set(row["name_states"].values()))) or "Configured output",
                               "Retired": "Yes" if row["retired"] else "No"} for row in candidates], hide_index=True, width="stretch")
            enabled = not context_changed and can_write and bool(chosen) and not choices[chosen]["retired"] and not choices[chosen].get("naming_conflict") if chosen else False
            if st.button("Use this name in my draft", key=prefix + "use", disabled=not enabled) and enabled:
                st.caption("The name is proposed in the output fields below. Review its meaning, type and naming status before validation.")
                return chosen
        elif result.get("ok"):
            st.info("No matching name is visible in this product's configured outputs or accessible contracts. "
                    "Choose Browse all available names or search another spelling. Leave naming undecided if its meaning is unresolved.")
        st.caption("Ask the data expert to resolve ambiguous matches in the shared naming registry. "
                   "This lookup changes only your proposed physical name; it does not rename an existing column or mark naming aligned.")
    return None


def _resolve_conflicts(root, pack, actor, result, prefix, allowed, can_write):
    for number, conflict in enumerate(result.get("conflicts", [])):
        key = prefix + "conflict_" + str(number) + "_"
        with st.expander("Resolve conflicting naming decisions: " + " / ".join(conflict["family"]), expanded=True):
            st.warning("These current decisions disagree. Neither closes this naming question.")
            for ref, record in zip(conflict["references"], conflict["records"]):
                st.write(record)
                st.caption("Exact ruling reference: " + ref)
            pair = conflict["records"][0]
            ruling = st.selectbox("Reviewed replacement decision", naming.names.RULING_KINDS, index=None, key=key + "ruling")
            standard = st.selectbox("Standard name if these are one concept", [pair["a"], pair["b"]], index=None, key=key + "standard")
            reason = st.text_area("Why does this decision replace the conflicting rulings?", key=key + "reason")
            reference = st.text_input("Naming review reference", key=key + "reference")
            signature = (conflict["references"], ruling, standard, reason, reference)
            if st.session_state.get(key + "inputs") != signature:
                st.session_state.pop(key + "proposal", None)
                st.session_state.pop(key + "reviewed", None)
                st.session_state[key + "inputs"] = signature
            if st.button("Preview naming resolution", key=key + "preview", disabled=not can_write or ruling is None):
                try:
                    st.session_state[key + "proposal"] = naming.preview_resolution(root, pack, actor,
                        references=conflict["references"], a=pair["a"], b=pair["b"], ruling=ruling,
                        standard=standard or "", reason=reason, decision_id=reference, allowed_packs=allowed)
                except (ValueError, OSError, TypeError) as error:
                    st.error(str(error))
            proposal = st.session_state.get(key + "proposal")
            if proposal:
                st.code(proposal["diff"], language="diff")
                reviewed = st.checkbox("I reviewed this replacement and its exact superseded rulings. Save my naming decision on this branch.", key=key + "reviewed")
                if st.button("Save reviewed naming resolution", key=key + "save", disabled=not (can_write and reviewed)):
                    try:
                        naming.apply_resolution(root, pack, actor, proposal=proposal, confirmed=reviewed,
                            can_write=can_write, allowed_packs=allowed)
                        st.session_state.pop(key + "proposal", None)
                        st.rerun()
                    except (ValueError, OSError, TypeError) as error:
                        st.error(str(error))
            st.caption("Historical decisions remain in the naming register. This action does not rename a column or authenticate scientific approval.")
    if result.get("naming_history"):
        with st.expander("Naming decision history"):
            for item in result["naming_history"]:
                st.write({"state": item["state"], **item["record"], "reference": item["ref"]})
