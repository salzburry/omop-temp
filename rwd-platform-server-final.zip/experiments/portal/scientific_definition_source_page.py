"""Explain and record the current extracted source's explicit human review."""
from pathlib import Path

import streamlit as st

import scientific_definition_source as source


_PREFIX = "definition_source_"
_CLASSES = {
    "sponsor_ai_eligible": "Sponsor AI may read this extracted material",
    "vendor_restricted": "Vendor material: AI access restricted",
    "restricted_derived": "Derived material: AI access restricted",
}
_LABELS = {
    "classified_by": "Access classifier's name",
    "classified_date": "Classification date",
    "approved_by": "Extracted material reviewer's name",
    "approval_date": "Extracted material review date",
}


def _clear():
    for key in list(st.session_state):
        if str(key).startswith(_PREFIX):
            st.session_state.pop(key, None)


def _errors(result):
    import form_assistance
    form_assistance.record_validation(result.get("errors") or [], title="Extracted specification validation", action_id="g2_draft",
        input_digest=result.get("input_digest") or "")
    for error in result.get("errors") or []:
        st.error(str(error))


def _inherited_sentence(inherited):
    """The workbook's decision as one plain sentence, from the recorded values only."""
    return ("Uses the workbook's AI decision: sponsor AI eligible, classified by "
            + str(inherited.get("classified_by") or "") + " on " + str(inherited.get("classified_date") or "")
            + "; approved by " + str(inherited.get("approved_by") or "") + " on "
            + str(inherited.get("approval_date") or "") + ".")


def _review_form(description, enabled):
    """The five-field form. Returns (submitted, updates, confirmed); every value is what the person typed."""
    values = description.get("values") or {}
    with st.form(_PREFIX + "review_form"):
        initial_class = values.get("ai_classification")
        options = list(_CLASSES)
        classification = st.selectbox("What may AI read?", options,
                                      index=options.index(initial_class) if initial_class in options else None,
                                      format_func=lambda value: _CLASSES[value], key=_PREFIX + "ai_classification",
                                      disabled=not enabled,
                                      help="Choose the access decision actually made for these extracted bytes. Restricted material remains blocked for assisted drafting.")
        updates = {"ai_classification": classification or ""}
        for field, label in _LABELS.items():
            is_date = field.endswith("date")
            updates[field] = st.text_input(label, value=str(values.get(field) or ""), key=_PREFIX + field,
                                          placeholder="YYYY-MM-DD" if is_date else "Enter the person's actual name",
                                          help="Enter when this review or classification was actually made; do not use today's date by default." if is_date else
                                          "Name the person who actually made this decision. This field does not verify their identity.",
                                          disabled=not enabled)
        confirmed = st.checkbox("I reviewed this extracted material and confirm these are the decisions, people and dates actually recorded.",
                                key=_PREFIX + "confirmed", disabled=not enabled)
        st.caption("Saving records the review you enter. It does not authenticate a signature, approve scientific definitions or release a product.")
        submitted = st.form_submit_button("Record extracted source review", disabled=not enabled)
    return submitted, updates, confirmed


def render(root, pack, *, local_demo, can_write, can_review, allowed_packs=None, actor_id=""):
    """Return true after an intentional write; never invent a source decision."""
    scope = None if allowed_packs is None else tuple(sorted(str(value) for value in allowed_packs))
    context = (str(Path(root).resolve()), pack, actor_id, bool(can_write), bool(can_review), bool(local_demo), scope)
    previous_context = st.session_state.get(_PREFIX + "context")
    context_changed = previous_context is not None and previous_context != context
    if previous_context != context:
        _clear()
        st.session_state[_PREFIX + "context"] = context
    if _PREFIX + "snapshot" not in st.session_state:
        st.session_state[_PREFIX + "snapshot"] = source.describe(root, pack, allowed_packs=allowed_packs)
    description = st.session_state[_PREFIX + "snapshot"]
    st.write("**Prepare the extracted source for definition drafting**")
    st.write("The workbook and the extracted rows are separate source records. The current extraction must be registered "
             "and its content and AI access reviewed before it can supply evidence to the scientific contract.")
    inherited = bool(description.get("inherited_from_parent"))
    if not description.get("ok"):
        _errors(description)
    elif description.get("ready") and not inherited:
        st.success("The extracted source meets the current drafting eligibility checks. Continue with your definition below.")
    elif not description.get("registered"):
        if description.get("inheritance_available"):
            st.info("First register the current extraction. This records its location and checksums. "
                    "The workbook's own AI decision applies to it, so no separate review is needed unless you record a different one.")
        else:
            st.info("First register the current extraction. This records its location and checksums and leaves its review pending.")
        if description.get("registration_preview"):
            with st.expander("Registration details"):
                st.code(description["registration_preview"], language="yaml")
        register_enabled = not context_changed and local_demo is True and can_write is True and description.get("registration_available")
        if st.button("Register current extraction", key=_PREFIX + "register", disabled=not register_enabled) and register_enabled:
            result = source.register(root, pack, expected_digest=description["digest"],
                                     local_demo=local_demo, can_write=can_write, allowed_packs=allowed_packs)
            if result.get("ok"):
                _clear()
                if result.get("inherited_from_parent"):
                    st.success("Extraction registered with the workbook's AI decision. Check the remaining drafting requirements below.")
                else:
                    st.success("Extraction registered with review pending. Enter the actual source review below after reviewing its content.")
                return True
            _errors(result)
    else:
        material = description.get("material") or {}
        if description.get("ready"):
            st.success("The extracted source meets the current drafting eligibility checks. Continue with your definition below.")
        st.text("Extracted material: " + str(material.get("path_or_link") or material.get("material_id") or "Current extraction"))
        st.caption("Review status: " + str(material.get("status") or "pending"))
        enabled = local_demo is True and can_review is True and not context_changed
        if inherited:
            # The person answered these five questions when they started the product and reviewed
            # the workbook. Say so, and keep the form one click away for a different decision.
            st.write(_inherited_sentence(description.get("inherited") or {}))
            holder = st.expander("Record a different decision")
        else:
            st.write("An authorized reviewer must inspect the extracted content, assess its access restrictions, and enter the decision actually made. "
                     "The reviewer of the workbook is not automatically the reviewer of this extraction.")
            holder = st.container()
        with holder:
            if not enabled:
                st.info("Recording this decision requires reviewer access in a local session. You can still save an unfinished definition draft.")
            submitted, updates, confirmed = _review_form(description, enabled)
        if submitted and enabled:
            result = source.record_review(root, pack, updates, expected_digest=description["digest"], confirmed=confirmed,
                                          local_demo=local_demo, can_review=can_review, allowed_packs=allowed_packs)
            if result.get("ok"):
                _clear()
                st.success("Source review recorded. Check the remaining drafting requirements below.")
                return True
            _errors(result)
    reasons = description.get("reasons") or []
    if reasons:
        with st.expander("Current extraction requirements"):
            for reason in reasons:
                st.write(str(reason))
    if st.button("Reload extracted source status", key=_PREFIX + "reload"):
        _clear()
        st.rerun()
    return False
