"""Science review stays attached to the selected product, row, and next action."""
from __future__ import annotations

import json
from pathlib import Path

import streamlit as st
import form_assistance as form_help

import science_workspace as science


def _messages(result):
    for problem in result.get("errors") or []:
        st.error(problem)
    for warning in result.get("warnings") or []:
        st.info(warning)


def _table(rows):
    if rows:
        st.dataframe(rows, hide_index=True, width="stretch")


def _finding_list(findings, label="Existing validator findings"):
    if findings:
        with st.expander(f"{label} ({len(findings)})", expanded=True):
            for finding in findings:
                st.write(str(finding))


def _go(label, route, params, key):
    if st.button(label, key=key):
        return {"route": route, "params": {key: value for key, value in params.items() if value is not None}}
    return None


def _saved(root, pack, actor, proposal, allowed_packs, writable):
    import connected_workflow_page
    connected_workflow_page.select_context(pack, actor, variable=proposal["values"].get("variable"), item_id=proposal["values"].get("item_id"))
    st.success("Proposal saved for review. Its validation findings remain attached.")
    st.write(proposal["summary"])
    st.caption("This is a private proposal. It has not changed the functional contract, shared registry, approvals, or released output.")
    if proposal.get("diff"):
        st.code(proposal["diff"], language="diff")
    elif proposal["values"].get("disposition") in {"reject", "defer"}:
        st.info("The review disposition is retained separately; it proposes no change to the current binding.")
    _finding_list(proposal.get("findings") or [], "Validation and remaining review")
    st.caption("Checked with: " + "; ".join(proposal.get("validators") or []))
    st.download_button("Download this review proposal", json.dumps(proposal, indent=2, ensure_ascii=False),
                       file_name="science-proposal-" + proposal["id"] + ".json", mime="application/json",
                       key="science_download_" + proposal["id"])
    if proposal["route"] in {"definition_reuse", "template_review"}:
        target = science.draft_target(root, pack, actor, proposal["id"], allowed_packs=allowed_packs)
        if target["ok"] and proposal["values"].get("disposition") != "defer":
            st.write("Continue this interpretation in the scientific row editor")
            st.caption("Only the interpretation text is copied. Timing, missing values, dependencies and naming remain your row draft's existing values and must be reviewed there.")
            st.text("Current unfinished interpretation: " + str(target["values"].get("derivation") or "Not entered"))
            if st.button("Copy interpretation into my row draft", key="science_copy_" + proposal["id"], disabled=not writable):
                copied = science.use_in_draft(root, pack, actor, proposal["id"], expected_draft_digest=target["draft_digest"],
                                             allowed_packs=allowed_packs, local_demo=writable, can_write=writable)
                _messages(copied)
                if copied["ok"]:
                    return {**copied["next"], "changed": True}
        elif not target["ok"]:
            _messages(target)
        return _go("Open scientific row draft", "scientific_draft", proposal["next"]["params"], "science_next_draft_" + proposal["id"])
    if proposal["route"] == "clinical_standards":
        import science_review_handoffs as reviews
        st.write("Share this exact proposal with the person responsible for reviewing its clinical meaning. They will see its source context, diff and unresolved validator findings in Handoffs.")
        st.caption("Only this selected proposal is shared with people who can access this product. Your other private drafts remain private.")
        with st.form("science_review_share_" + proposal["id"]):
            owner = st.selectbox("Who should review this clinical meaning?", ["Science", "Reviewer", "Engineering"],
                                 key="science_review_owner_" + proposal["id"])
            note = form_help.field(st.text_area, "What should the reviewer examine?", key="science_review_note_" + proposal["id"],
                                help="State the unresolved clinical question or the evidence supporting the proposed binding. Do not enter an approval on behalf of the reviewer.", binding=proposal.get("payload_sha256"))
            share = st.form_submit_button("Share this exact proposal for review", disabled=not writable,
                                          key="science_review_share_button_" + proposal["id"])
        if share:
            with st.spinner("Rechecking this exact clinical proposal before sharing it…"):
                shared = reviews.share(root, pack, actor, proposal["id"], expected_proposal_digest=proposal.get("payload_sha256"),
                                       owner=owner, note=note, allowed_packs=allowed_packs,
                                       local_demo=writable, can_write=writable)
            _messages(shared)
            if shared["ok"]:
                if shared.get("message"):
                    st.session_state["handoffs_notice"] = shared["message"]
                return {"route": "handoffs", "params": {"handoff_id": shared["handoff"]["id"]}, "changed": True}
        return None
    st.info("The registry steward reviews the shared definition entry. Product implementation claims proceed through configuration review with this checked proposal. Their stated reviewer fields have not authenticated a review.")
    return _go("Review product progress", "progress", {}, "science_next_progress_" + proposal["id"])


def _submit(root, pack, actor, route, report, values, scope, writable, key):
    if st.button("Validate and save proposal", key=key, disabled=not writable, type="primary"):
        with st.spinner("Checking the exact proposal against current product and reference evidence…"):
            result = science.stage(root, pack, actor, route=route, values=values,
                                   expected_input_digest=report["input_digest"], allowed_packs=scope,
                                   local_demo=writable, can_write=writable)
        _messages(result)
        if result["ok"]:
            return {"route": route, "params": {"proposal_id": result["proposal"]["id"], "edit": False}, "changed": True}
    return None


def _references(report):
    with st.expander("Reference suggestions and actual engine support"):
        st.caption("Reference wording is a drafting aid. Capability evidence describes what the engine supports. Neither chooses the scientific interpretation for this requirement.")
        hits = report.get("references") or []
        if hits:
            _table([{"Kind": h["kind"], "Evidence state": h["state"], "Name": h["id"],
                     "Description": h["title"], "Basis / limits": h["detail"], "Source": h["where"]} for h in hits])
        else:
            st.info("No matching reference or engine capability is declared for this name. Use its scientific definition to clarify the requirement; unsupported derivations need an engineering handoff.")


def _reuse(root, pack, actor, report, scope, writable, prefix):
    current = report.get("current") or {}
    selected = next((row for row in report.get("source_rows") or [] if row["item_id"] == report.get("item_id")), {})
    st.write("Start with the master variable logic, then supply this product's values.")
    st.caption("Master library templates require this product's review. Approval recorded for another product does not carry into this draft.")
    st.text("Current product requirement: " + str(selected.get("definition") or (current.get("spec") or {}).get("rule") or "Not recorded"))
    for field, value in (selected.get("spec_fields") or {}).items():
        if str(field).lower().replace("_", " ").strip() in {"values", "value", "codes", "values / codes", "values codes"} and value not in (None, ""):
            st.text("Current specification values / codes: " + str(value))
    st.text("Current interpretation: " + str(current.get("derivation") or "Not yet drafted"))
    edit = _go("Edit this product's definition and values", "scientific_draft", {"item_id": report.get("item_id")}, prefix + "edit_current")
    if edit:
        return edit
    available = report.get("candidates") or []
    masters = {row["key"]: row for row in available if row.get("source_kind") == "master"}
    examples = {row["key"]: row for row in available if row.get("source_kind") != "master"}
    request = st.session_state.get(prefix + "request") or (None, None, None, None)
    show_examples = False
    if examples:
        toggle_key = prefix + "show_examples_" + science._hash([report.get("item_id"), report.get("variable"), request[3]])[:12]
        show_examples = st.checkbox("Show prior-product examples", value=st.session_state.get(prefix + "show_examples", False), key=toggle_key)
        st.session_state[prefix + "show_examples"] = show_examples
    candidates = {**masters, **examples} if show_examples else masters
    if not candidates:
        st.info("No matching master variable definition is available yet. You can draft this product's definition" +
                (" or turn on prior-product examples to inspect earlier work." if examples else "."))
        _references(report)
        return _go("Draft this requirement", "scientific_draft", {"item_id": report.get("item_id")}, prefix + "draft")
    candidate_labels = {key: (row["variable_id"] + (" · " + row["display_name"] if row.get("display_name") and row["display_name"] != row["variable_id"] else "") + " · Library template · product review required"
                              if row.get("source_kind") == "master" else
                              "Prior product example · " + row["pack"] + " · " + row["variable_id"] + " · " + row["status"])
                        for key, row in candidates.items()}
    candidate_widget = prefix + "candidate_" + science._hash([report.get("item_id"), report.get("variable"), request[3],
                                                             list(candidate_labels.items())])[:12]
    default_candidate = st.session_state.get(prefix + "candidate")
    if default_candidate not in candidates:
        default_candidate = next((key for key, row in masters.items() if row.get("match_kind") == "exact"),
                                 next(iter(examples)) if show_examples and not masters else None)
    choice = st.selectbox("Definition to use or inspect" if show_examples else "Master variable definition", list(candidates),
                          index=list(candidates).index(default_candidate) if default_candidate is not None else None,
                          format_func=candidate_labels.__getitem__, key=candidate_widget, placeholder="Choose the definition that matches this requirement")
    # Keep the stable field for saved-proposal restoration; the actual widget
    # is tied to its row and labels so the browser cannot retain another row's label.
    st.session_state[prefix + "candidate"] = choice
    if choice is None:
        st.info("Choose the master definition that matches this requirement. A similar name alone does not establish the same meaning.")
        return None
    candidate = candidates[choice]
    reusable = candidate.get("reusable_derivation")
    ready = candidate.get("reuse_readiness") == "ready"
    if isinstance(reusable, str) and reusable.strip():
        st.text("Reusable logic: " + reusable)
    else:
        reusable = ""
        st.info("Review this reference and write the logic that applies to this product before reusing it.")
    st.caption("Reference dates and values are not automatically adopted. Use this product's specification for its own dates and values.")
    is_master = candidate.get("source_kind") == "master"
    if is_master and candidate.get("parameter_slots"):
        st.write("**Product settings for this definition**")
        _table([{"Setting": item.get("name", ""), "Meaning": item.get("description", "")} if isinstance(item, dict)
                else {"Setting": str(item), "Meaning": ""} for item in candidate["parameter_slots"]])
    for issue in candidate.get("reuse_issues") or []:
        st.warning(issue)
    with st.expander("Master library source details" if is_master else "Reference example values and source details"):
        st.text(("Master definition: " if is_master else "Reference example requirement: ") + candidate["record"]["spec"]["rule"])
        st.text(("Master logic: " if is_master else "Reference example interpretation: ") + candidate["record"]["derivation"])
        _table([{"Question": label, "Recorded answer": value or "Not stated"} for label, value in candidate["record"]["interpreted"]])
        st.caption("Reference provenance: " + str(candidate.get("source_path") or candidate.get("pack") or "Master variable library") +
                   " · " + ", ".join(candidate["spec_refs"]) + " · Decisions: " + (", ".join(candidate["decisions"]) or "None cited"))
        if candidate["diff"]:
            st.code(candidate["diff"], language="diff")
    if candidate["caveat"]:
        st.warning(candidate["caveat"])
    choices = ["defer", "inherit", "adapt", "diverge"] if reusable and ready else ["defer", "adapt", "diverge"]
    if st.session_state.get(prefix + "disposition") not in choices:
        st.session_state.pop(prefix + "disposition", None)
    disposition = form_help.field(st.selectbox, "Proposed reuse choice", choices, key=prefix + "disposition",
                              format_func=lambda value: {"defer": "Decide later", "inherit": "Use logic only", "adapt": "Adapt logic", "diverge": "Use different logic"}[value],
                              help="Use logic only copies the reusable interpretation. This product keeps its own dates and values. Adapt logic changes the interpretation; use different logic records an intentional difference.", binding=(report["input_digest"], choice))
    if disposition == "inherit":
        interpretation = reusable
        st.text("Proposed logic: " + interpretation)
    else:
        interpretation = form_help.field(st.text_area, "Your proposed interpretation", key=prefix + "interpretation", height=140,
                                     help="For example: use the closest qualifying observation within the reviewed baseline window; specify your actual tie-break and missing-value behavior in the row editor. This example is not a selected rule.", binding=(report["input_digest"], choice, disposition))
    proposed_ready = True
    if disposition in {"adapt", "diverge"} and interpretation.strip():
        import definition_reuse_logic
        proposed = definition_reuse_logic.describe({**candidate["record"], "derivation": interpretation})
        proposed_ready = proposed["reuse_readiness"] == "ready"
        for issue in proposed.get("reuse_issues") or []:
            if issue not in (candidate.get("reuse_issues") or []):
                st.warning(issue)
    extra = {}
    if (not ready or not proposed_ready) and disposition in {"adapt", "diverge"}:
        basis = (report["input_digest"], choice, disposition, interpretation)
        if st.session_state.get(prefix + "logic_review_basis") != basis:
            st.session_state[prefix + "logic_reviewed"] = False
            st.session_state[prefix + "logic_review_basis"] = basis
        extra["logic_reviewed"] = st.checkbox("I checked that this is reusable logic and kept product-specific values in this product's settings.",
                                              key=prefix + "logic_reviewed")
    reason = form_help.field(st.text_area, "Why this choice, and what remains unresolved?", key=prefix + "reason",
                          help="Explain what agrees or differs: population, anchor date, timing window, record selection, missingness or output meaning. Cite a decision when one exists.", binding=(report["input_digest"], choice, disposition))
    _references(report)
    return _submit(root, pack, actor, "definition_reuse", report,
                   {"variable": report["variable"], "item_id": report.get("item_id"), "candidate": choice,
                    "disposition": disposition, "interpretation": interpretation, "reason": reason, **extra},
                   scope, writable and extra.get("logic_reviewed", True), prefix + "save")


def _lineage(report, prefix):
    current = report.get("current")
    receipt = report.get("receipt")
    if not receipt:
        return _go("Create the scientific row draft", "scientific_draft", {"item_id": report.get("item_id")}, prefix + "draft")
    columns = st.columns(3)
    with columns[0]:
        st.write("Specification")
        st.text(current["spec"]["rule"] or "Required wording not recorded")
        st.caption(", ".join(current["spec"]["refs"]) or "Source row citation missing")
    with columns[1]:
        st.write("Scientific interpretation")
        st.text(current["derivation"] or "No interpretation recorded")
        _table([{"Question": label, "Answer": value or "Not stated"} for label, value in current["interpreted"]])
    with columns[2]:
        st.write("Executable configuration")
        if not current["executable"]:
            st.info("No implementation is cited. This rule is not linked to an executable configuration block.")
        for ref, fragment in current["executable"]:
            st.caption(ref)
            st.json(fragment) if fragment is not None else st.text("Engine symbol cited; configuration fragment unavailable")
        for ref in current["unresolved"]:
            st.warning("Unresolved implementation: " + ref)
    if report.get("overlaps"):
        st.warning("These fields occur on both sides. A reviewer must decide whether they agree.")
        _table([{"Field": r[0], "Interpretation": r[1], "Configuration": r[2], "Configured value": str(r[3])} for r in report["overlaps"]])
    st.write("Decisions and build evidence")
    for decision in receipt["decisions"]:
        st.write(decision.get("decision") + " · " + decision.get("status", "Missing register row"))
        st.text(decision.get("approved_answer") or decision.get("question") or decision.get("note") or "No answer recorded")
        if st.button("Open decision " + decision["decision"], key=prefix + "decision_" + decision["decision"]):
            return {"route": "questions", "params": {"decision_id": decision["decision"]}}
    st.json(receipt["build"])
    st.write("What this product can explain")
    _table([{"Question": row["question"], "State": row["state"], "Evidence / missing link": row.get("answer") or row.get("reason") or row.get("text") or "See attached evidence"}
            for row in report["competency"]["answers"]])
    with st.expander("Exact provenance receipt and competency evidence"):
        st.json({"receipt": receipt, "competency": report["competency"]})
    _references(report)
    return _go("Compare definitions for this variable", "definition_reuse",
               {"variable": report["variable"], "item_id": report.get("item_id")}, prefix + "reuse")


def _relation_tools(report, prefix):
    relation = report.get("relation_review") or {}
    with st.expander("Explore terminology relations and recorded concept sets"):
        for message in relation.get("findings") or []:
            st.info(message)
        if not relation.get("available"):
            return None
        st.caption("Reference release: " + relation["release"] + ". These are association candidates, not clinical equivalence rulings. Direct relationships are shown separately for each source and set member; ancestor inheritance is not enabled in this view.")
        with st.form(prefix + "relation_search"):
            query = st.text_input("Find a disease or concept", value=relation.get("query") or "", max_chars=100,
                                  key=prefix + "relation_query", help="Search the existing projection by a disease name or exact CUI. This performs no online lookup and changes no binding.")
            search = st.form_submit_button("Search relation concepts")
        if search:
            return {"route": "clinical_standards", "params": {"variable": report["variable"], "item_id": report.get("item_id"), "relation_query": query}}
        options = {entry["key"]: entry["name"] for entry in relation["concepts"]}
        options.update({entry["key"]: "Recorded set: " + entry["name"] for entry in relation["sets"]})
        if not options:
            st.info("No disease matched this search and no valid concept set is recorded. Try a different name or ask the scientist which concepts should define this population.")
            return None
        if st.session_state.get(prefix + "relation_subject") not in options:
            st.session_state.pop(prefix + "relation_subject", None)
        selected = st.selectbox("Relation evidence to inspect", list(options), format_func=options.get, key=prefix + "relation_subject")
        entry = next((item for item in relation["sets"] if item["key"] == selected), None)
        if entry:
            _table([{ "Concept": m["cui"], "Meaning": m["name"], "Recorded use": m["status"] } for m in entry["members"]])
            st.text("Scope basis: " + str(entry["basis"]))
            st.text("Citation: " + str(entry["citation"]))
            st.caption("Recorded attribution: " + str(entry["asserted_by"]) + " · " + str(entry["asserted_on"]) + ". This page has not authenticated it. Only active members contribute to the relations below.")
            if st.button("Use this recorded set in the proposal below", key=prefix + "select_set"):
                st.session_state[prefix + "axis"] = "concept_set"
                st.session_state[prefix + "value_concept_set"] = entry["name"]
        group = relation["groups"][selected]
        modality = st.selectbox("Evidence modality", ["All", "asserted", "possible", "refuted"], key=prefix + "relation_modality",
                               help="Possible and refuted associations remain separate from asserted evidence. A conflicting edge retains every recorded modality.")
        rows = [row for row in group["rows"] if modality == "All" or modality in row["modalities"]]
        _table([{ "Partner": row["name"], "CUI or code": row["partner"], "Axis": row["axis"],
                  "Modalities": ", ".join(row["modalities"]), "Conflicting evidence": row["conflict"],
                  "Source": row["source"], "Vocabulary": ", ".join(row["source_vocabularies"]),
                  "Relation": ", ".join(row["relations"]), "From concept": row["from_concept"],
                  "Citation": row["citation"] } for row in rows])
        if not rows:
            st.info("No direct association is present for this selection and modality. Absence is not evidence of clinical absence.")
        if group["omitted"]:
            st.caption(f"Showing the first {len(group['rows'])} of {group['total']} relations before filtering; {group['omitted']} are omitted from this bounded view.")
    return None


def _clinical(root, pack, actor, report, scope, writable, prefix):
    navigation = _relation_tools(report, prefix)
    if navigation:
        return navigation
    st.write("Choose the clinical meaning separately from its physical column name.")
    st.caption("Profile ranking proposes possibilities. A saved accept, reject or defer choice is review work; the shared terminology and current semantic bindings remain unchanged.")
    variable = report["variable"]
    existing = (report.get("bindings", {}).get("variables") or {}).get(variable) or {}
    st.write("Current binding")
    st.json(existing or {"state": "No clinical meaning declared"})
    crosswalk = [row for row in report.get("crosswalk") or [] if str(row["name"]).lower() == str(variable).lower()]
    for row in crosswalk:
        st.text("Reference definition: " + str(row.get("definition") or "Not stated"))
        _table([{"Candidate profile": c["profile"], "Evidence channel": c["channel"], "Score": c.get("score"),
                 "Carrier": c.get("carrier_element"), "Evidence terms": ", ".join(c.get("evidence_terms") or [])} for c in row["candidates"]])
    if not crosswalk:
        st.info("No mCODE profile candidate is available for this variable. A profile match is optional and cannot replace review of its analytical definition.")
    offered = report.get("candidates", {}).get(variable) or []
    if offered:
        _table([{"Suggested concept": value, "Reference meaning": report["concept_names"].get(value, "")} for value in offered])
    axis = st.selectbox("Binding to review", ["concept", "lab", "registry_concept", "definition", "mcode_profile", "concept_set"], key=prefix + "axis",
                        format_func=lambda key: {"concept": "UMLS clinical concept", "lab": "LOINC laboratory code", "registry_concept": "Reusable oncology concept", "definition": "Registered analytical definition", "mcode_profile": "mCODE profile candidate disposition", "concept_set": "Product population concept set"}[key],
                        help="Choose a clinical concept, laboratory code, oncology slot or already registered analytical-definition ID. These have different meanings and are not interchangeable.")
    options = {"concept": list(report.get("concept_names") or {}), "lab": list(report.get("labs") or {}),
               "registry_concept": report.get("slots") or [], "definition": [],
               "concept_set": [entry["name"] for entry in (report.get("relation_review") or {}).get("sets") or []],
               "mcode_profile": sorted({candidate["profile"] for row in crosswalk for candidate in row["candidates"]})}
    if axis == "definition":
        st.info("Choose an analytical definition in the identity workspace, which compares its registered signature with this product's configuration.")
        return _go("Open definition identity", "definition_identity", {"variable": variable}, prefix + "identity")
    if axis == "mcode_profile":
        st.info("A profile disposition records terminology review. The current semantic schema does not execute mCODE profile mappings; any implementation must name a supported binding axis and carrier.")
    if axis == "concept_set":
        st.warning("This proposes the population concept set for the whole product. Review every active, not-used and deprecated member above; selecting a set does not establish equivalence or approve a population definition.")
    names = report.get("concept_names") or {} if axis == "concept" else {}
    options[axis] = sorted(options[axis], key=lambda value: (value not in offered, value))
    if not options[axis]:
        st.info("This reference axis has no available entries. Ask the terminology steward to prepare its reference layer, or use another declared axis.")
        if axis == "concept_set":
            return _go("Ask which concepts define this population", "questions",
                {"variable": variable, "question": "Which recorded concept set should define this product population? Review active and excluded members and cite the population scope basis.",
                 "question_source": "clinical_standards", "question_context": "Product population concept set",
                 "question_evidence": report.get("item_id") or ""}, prefix + "set_question")
        return None
    if st.session_state.get(prefix + "value_" + axis) not in options[axis]:
        st.session_state.pop(prefix + "value_" + axis, None)
    value = form_help.field(st.selectbox, "Meaning to propose", options[axis], key=prefix + "value_" + axis,
                         format_func=lambda value: value + (" · " + str(names.get(value)) if names.get(value) else ""), binding=(report["input_digest"], axis))
    disposition = st.selectbox("Review disposition", ["defer", "accept", "reject"], key=prefix + "disposition",
                              help="Accept proposes the displayed binding in a staged semantic-file diff. Reject and defer retain the review note without changing the current binding.")
    reason = form_help.field(st.text_area, "Clinical rationale or unresolved question", key=prefix + "reason",
                          help="Explain how the reference concept matches this variable's population, measurement and timing. If it does not, say which clinical distinction matters.", binding=(report["input_digest"], axis, value, disposition))
    _finding_list(report.get("findings") or [])
    return _submit(root, pack, actor, "clinical_standards", report,
                   {"variable": variable, "axis": axis, "value": value, "disposition": disposition, "reason": reason},
                   scope, writable, prefix + "save")


def _templates(root, pack, actor, report, scope, writable, prefix):
    result = report["reconciliation"]
    st.write("Review what this product can reuse from the oncology template.")
    st.caption("Template slots describe reusable clinical concepts. The current contract supplies the product's actual timing, selection and outputs. A draft disposition does not confirm a template ruling or promote a shared-library release.")
    st.write(f"{result['declared']} contract rows reviewed · {result['concepts']} template concepts assembled · {result['cancer']}")
    buckets = ("confirmed", "proposed", "ambiguous", "incompatible", "possible", "unmatched", "not_matchable")
    rows = [{**row, "bucket": bucket} for bucket in buckets for row in result.get(bucket) or [] if row["variable_id"] == report["variable"]]
    candidates = {candidate["slot"]: candidate for row in rows for candidate in row.get("candidates") or []}
    _table([{"Variable": row["variable_id"], "Reconciliation": row["bucket"], "Reason": row.get("why", ""),
             "Candidate concepts": ", ".join(c["slot"] for c in row.get("candidates") or [])} for row in rows])
    _finding_list(report.get("findings") or [])
    with st.expander("Template questions that unlock further reuse"):
        _table(report["worklist"].get("by_pack", [])[:12])
    if not candidates:
        st.info("This row has no supported template pairing. Clarify the scientific record first; unsupported concepts need an explicit template-steward or engineering decision.")
        return _go("Open scientific row draft", "scientific_draft", {"item_id": report.get("item_id")}, prefix + "draft")
    if st.session_state.get(prefix + "slot") not in candidates:
        st.session_state.pop(prefix + "slot", None)
    slot = st.selectbox("Template concept to compare", list(candidates), key=prefix + "slot")
    candidate = candidates[slot]
    st.json(candidate)
    disposition = form_help.field(st.selectbox, "Proposed template use", ["defer", "inherit", "adapt", "diverge"], key=prefix + "disposition",
                              help="Record whether this product will retain the reusable meaning, adapt it, use a distinct meaning, or leave the question open. No scientific approval is inferred.", binding=(report["input_digest"], slot))
    interpretation = form_help.field(st.text_area, "Product interpretation to carry into drafting", key=prefix + "interpretation",
                                  help="Write the interpretation for this product's source requirement, including the concrete difference from the reusable concept. It will be available to copy into the scientific row draft.", binding=(report["input_digest"], slot, disposition))
    reason = form_help.field(st.text_area, "Reason and unresolved differences", key=prefix + "reason", binding=(report["input_digest"], slot, disposition))
    return _submit(root, pack, actor, "template_review", report,
                   {"variable": report["variable"], "item_id": report.get("item_id"), "slot": slot,
                    "disposition": disposition, "interpretation": interpretation, "reason": reason}, scope, writable, prefix + "save")


def _identity(root, pack, actor, report, scope, writable, prefix):
    st.write("Connect clinical meaning → analytical definition → dataset implementation.")
    st.caption("Definition signatures are calculated from configuration measurement rules. A signature digest is not a person's signature or an approval. Existing validators check the exact staged files before they are saved.")
    _table([{"Family": row.get("master"), "Signature available": bool(row.get("signed")),
             "Digest": row.get("digest", ""), "Missing rule detail": row.get("reason", "")} for row in report["signatures"]])
    _finding_list(report.get("findings") or [])
    kind = st.radio("What needs to be recorded?", ["registration", "implementation"], key=prefix + "kind", horizontal=True,
                    format_func=lambda value: "A shared definition identity" if value == "registration" else "This dataset's implementation")
    values = {"kind": kind, "variable": report["variable"]}
    if kind == "registration":
        available = {row["master"]: row for row in report.get("proposed_definitions") or []}
        if not available:
            st.info("There is no unregistered calculated definition to propose. Review unsigned configuration rules above, or continue with the existing registered identity and dataset claim.")
            return _go("Review this variable's rule and implementation", "variable_lineage", {"variable": report["variable"]}, prefix + "lineage")
        if st.session_state.get(prefix + "master") not in available:
            st.session_state.pop(prefix + "master", None)
        master = st.selectbox("Definition family", list(available), key=prefix + "master")
        proposal = available[master]
        st.text("Calculated signature: " + proposal["signature_sha256"])
        values.update(master=master,
                      definition_id=form_help.field(st.text_input, "Proposed stable definition ID", value=proposal["definition_id"], key=prefix + "id_" + master,
                                                  help="Use the suggested namespace:family:version identity. A revised measurement rule needs a new version, not a replacement digest under an existing ID.", binding=(report["input_digest"], kind, master)),
                      concept=form_help.field(st.text_input, "Clinical concept CUI", key=prefix + "concept_" + master,
                                            help="The reviewed UMLS identifier this analytical definition measures, such as C followed by seven digits. A similar physical name does not establish concept identity.", binding=(report["input_digest"], kind, master)),
                      registered_by=st.text_input("Proposed registration author", key=prefix + "registered_by"),
                      registration_date=st.text_input("Proposed registration date", key=prefix + "registration_date", placeholder="YYYY-MM-DD"),
                      supersedes=form_help.field(st.text_input, "Earlier definition ID, or none", value=proposal["supersedes"], key=prefix + "supersedes_" + master, binding=(report["input_digest"], kind, master)))
    else:
        choices = [row["definition_id"] for row in report["registered"]]
        if not choices:
            st.info("No analytical definition is registered yet. Stage its identity registration first, then have the registry steward review it before this dataset claims it.")
            return None
        if st.session_state.get(prefix + "definition_id") not in choices:
            st.session_state.pop(prefix + "definition_id", None)
        if prefix + "roles" in st.session_state:
            st.session_state[prefix + "roles"] = [role for role in st.session_state[prefix + "roles"] if role in report["roles"]]
        values.update(definition_id=st.selectbox("Registered analytical definition", choices, key=prefix + "definition_id"),
                      dataset=st.text_input("Dataset label", value=report["implementations"].get("dataset", ""), key=prefix + "dataset",
                                            help="Use the dataset identity carried by your product and delivery evidence. This is where the definition is implemented, not the clinical meaning itself."),
                      roles=st.multiselect("Declared source roles read by this implementation", report["roles"], key=prefix + "roles"),
                      reviewed_by=st.text_input("Stated claim reviewer", key=prefix + "reviewed_by"),
                      review_date=st.text_input("Stated claim review date", key=prefix + "review_date", placeholder="YYYY-MM-DD"))
        st.caption("Record only actual review attribution. These entered fields are retained in the staged proposal; this form does not authenticate the reviewer.")
    values["reason"] = form_help.field(st.text_area, "Measurement meaning, version change or claim rationale", key=prefix + "reason",
                                    help="Explain the scientific measurement and, for a new version, exactly what changed. For an implementation claim, explain how the declared source roles produce this definition.", binding=(report["input_digest"], kind, values.get("master"), values.get("definition_id")))
    return _submit(root, pack, actor, "definition_identity", report, values, scope, writable, prefix + "save")


def _comparison(report, prefix):
    comparison = report["comparison"]
    st.write("Compare the implemented definitions before considering combined analyses.")
    st.caption("The same column name or analytical-definition ID does not establish pooling equivalence. This view uses recorded dataset claims and exact scientific decisions.")
    variables = [row for row in comparison["variables"] if row["variable_id"] == report["variable"]]
    for row in variables:
        st.text(row["derivation"])
        _table([{"Dataset / product": key, "Definition claim": (row["definitions"] or {}).get(key) or "Not declared",
                 "Implementation evidence": value.get("evidence") or value.get("note") or value.get("state") or "See declared details"}
                for key, value in row["implementations"].items()])
        if not row["equivalence"]:
            st.info("Fewer than two eligible implementations are linked to this variable. There is no pair to assess; this does not establish comparability.")
        for pair in row["equivalence"]:
            sources = pair.get("sources") or [str(pair.get("source_a") or "Unstated source"), str(pair.get("source_b") or "Unstated source")]
            st.write(" / ".join(sources) + " · " + pair["state"])
            st.text(pair.get("question") or pair.get("note") or "See the recorded equivalence decision.")
            if pair.get("decision_id"):
                if st.button("Read decision " + pair["decision_id"], key=prefix + "decision_" + pair["decision_id"]):
                    return {"route": "questions", "pack": pair.get("decision_pack"), "params": {"decision_id": pair["decision_id"]}}
            elif st.button("Open the scientific question workflow", key=prefix + "question_" + "_".join(sources)):
                return {"route": "questions", "params": {"variable": report["variable"], "question": pair.get("question", ""),
                        "question_source": "dataset_comparison", "question_context": " / ".join(sources),
                        "question_evidence": report.get("item_id") or ""}}
    _finding_list(comparison.get("ruling_problems") or [])
    with st.expander("Exact dataset claims and equivalence evidence"):
        st.json({"variables": variables, "implementation_problems": comparison.get("implementation_problems")})
    return _go("Review this dataset's definition claim", "definition_identity", {"variable": report["variable"]}, prefix + "identity")


def render(root, pack, actor_id, *, allowed_packs, local_demo, can_write, can_review, route, params=None):
    params = params or {}
    context = (str(Path(root).resolve()), pack, actor_id, None if allowed_packs is None else tuple(sorted(allowed_packs)), bool(local_demo), bool(can_write), bool(can_review))
    if st.session_state.get("science_context") != context:
        for key in list(st.session_state):
            if str(key).startswith("science_"):
                st.session_state.pop(key, None)
        st.session_state["science_context"] = context
    if allowed_packs is not None and pack not in allowed_packs:
        st.error("This product is outside your current access.")
        return None
    if route not in science.ROUTES:
        st.error("Choose a connected science workflow.")
        return None
    writable = local_demo is True and can_write is True
    st.subheader(science.ROUTES[route])
    st.caption(pack)
    saved_values = None
    if params.get("proposal_id"):
        saved = science.read(root, pack, actor_id, params["proposal_id"], allowed_packs=allowed_packs)
        _messages(saved)
        if saved["ok"] and params.get("edit"):
            if saved["proposal"]["route"] != route:
                st.error("This proposal belongs to another science workflow.")
                return None
            saved_values = saved["proposal"]["values"]
            params = {**params, "variable": saved_values.get("variable"), "item_id": saved_values.get("item_id")}
        elif saved["ok"]:
            next_route = _saved(root, pack, actor_id, saved["proposal"], allowed_packs, writable)
            if next_route:
                return next_route
            return _go("Revise this proposal from current evidence", saved["proposal"]["route"],
                       {"proposal_id": saved["proposal"]["id"], "edit": True}, "science_revise_saved")
        else:
            return None
    prefix = "science_" + route + "_"
    request = (route, params.get("variable"), params.get("item_id"), params.get("proposal_id"))
    if st.session_state.get(prefix + "request") != request:
        previous_request = st.session_state.get(prefix + "request")
        previous_report = st.session_state.get(prefix + "report") or {}
        # Shared navigation fills the exact displayed row into its context. That
        # enrichment is not a new subject and must not discard the next click.
        same_subject = bool(previous_request and previous_request[0] == route and previous_request[3] == request[3]
                            and (request[1] or request[2])
                            and request[1] in (None, previous_report.get("variable"))
                            and request[2] in (None, previous_report.get("item_id")))
        if not same_subject:
            for key in list(st.session_state):
                if str(key).startswith(prefix):
                    st.session_state.pop(key, None)
        st.session_state[prefix + "request"] = request
    if st.button("Reload current evidence", key=prefix + "reload"):
        st.session_state.pop(prefix + "report", None)
    if st.session_state.get(prefix + "incoming_relation_query") != params.get("relation_query"):
        st.session_state.pop(prefix + "report", None)
        st.session_state[prefix + "incoming_relation_query"] = params.get("relation_query")
    if prefix + "report" not in st.session_state:
        with st.spinner("Reading accessible product definitions and reference evidence…"):
            st.session_state[prefix + "report"] = science.describe(root, pack, actor_id, route=route,
                    allowed_packs=allowed_packs, variable=params.get("variable"), item_id=params.get("item_id"),
                    **({"relation_query": params.get("relation_query")} if route == "clinical_standards" else {}))
    report = st.session_state[prefix + "report"]
    _messages(report)
    if not report["ok"]:
        return _go("Return to product progress", "progress", {}, prefix + "progress")
    if saved_values is not None and not st.session_state.get(prefix + "restored"):
        for key in ("disposition", "interpretation", "reason", "slot", "axis", "kind", "registered_by", "registration_date", "dataset", "reviewed_by", "review_date", "roles", "master", "definition_id"):
            if key in saved_values:
                st.session_state[prefix + key] = saved_values[key]
        if route == "definition_reuse" and saved_values.get("candidate") in {row["key"] for row in report.get("candidates") or []}:
            st.session_state[prefix + "candidate"] = saved_values["candidate"]
            saved_source = next(row for row in report["candidates"] if row["key"] == saved_values["candidate"])
            if saved_source.get("source_kind") != "master":
                st.session_state[prefix + "show_examples"] = True
        if route == "clinical_standards":
            st.session_state[prefix + "value_" + saved_values["axis"]] = saved_values["value"]
        if route == "definition_identity" and saved_values.get("kind") == "registration":
            master = saved_values.get("master", "")
            for field, key in (("definition_id", "id_"), ("concept", "concept_"), ("supersedes", "supersedes_")):
                st.session_state[prefix + key + master] = saved_values.get(field, "")
        st.session_state[prefix + "restored"] = True
    choices = {"row:" + row["item_id"]: {"item_id": row["item_id"], "variable": row["variable_id"]} for row in report["source_rows"]}
    for row in report["records"]:
        if not any(c["variable"] == row["variable_id"] for c in choices.values()):
            choices["variable:" + row["variable_id"]] = {"variable": row["variable_id"], "item_id": (row["spec"]["refs"] or [None])[0]}
    if choices:
        default = next((key for key, row in choices.items() if row["item_id"] == report.get("item_id") and row["item_id"]),
                       next((key for key, row in choices.items() if row["variable"] == report["variable"]), next(iter(choices))))
        selected = st.selectbox("Requirement or variable", list(choices), index=list(choices).index(default), key=prefix + "subject",
                                format_func=lambda key: choices[key]["variable"] + (" · " + choices[key]["item_id"] if choices[key]["item_id"] else ""))
        desired = choices[selected]
        if desired["item_id"] != report.get("item_id") or (not desired["item_id"] and desired["variable"] != report["variable"]):
            return {"route": route, "params": {**desired, "proposal_id": None, "edit": False}}
    else:
        st.info("This product has no extracted requirements or contract records yet. Prepare its source extraction and specification outline first.")
        return _go("Open product progress", "progress", {}, prefix + "progress")
    st.caption("The evidence shown is a review snapshot. Saving rechecks every input and refuses stale proposals. Use Reload current evidence after another editor changes the product.")
    import connected_workflow_page
    connected_workflow_page.select_context(pack, actor_id, variable=report.get("variable"), item_id=report.get("item_id"))
    if route == "definition_reuse":
        return _reuse(root, pack, actor_id, report, allowed_packs, writable, prefix)
    if route == "variable_lineage":
        return _lineage(report, prefix)
    if route == "clinical_standards":
        return _clinical(root, pack, actor_id, report, allowed_packs, writable, prefix)
    if route == "template_review":
        return _templates(root, pack, actor_id, report, allowed_packs, writable, prefix)
    if route == "definition_identity":
        return _identity(root, pack, actor_id, report, allowed_packs, writable, prefix)
    return _comparison(report, prefix)
