"""The guide on every product page: ask about this product, get the page's own buttons (2026-09-07)."""
from __future__ import annotations

import streamlit as st
from contextlib import nullcontext
import hashlib
import json
from pathlib import Path
import uuid

import flow_assistant as fa
import form_assistance as form_help
import assistant_layout

KEY = "flow_assistant_"


def _provider_words(root):
    try:
        import scientific_definition_ai as ai
        selected = ai.selected_provider()
        if not selected:
            return None, "No assistant is connected; answers come from the product's own checks. Choose one under Assistant connection in the sidebar for a model's help."
        config = ai._provider(root)
        if not config.get("configured", True):
            return None, f"{config.get('provider', 'The selected assistant')} is selected but not configured; answers come from the product's own checks."
        return config, f"Answers come from {config.get('provider', 'the selected assistant')} using this page's context and the repository's workflow instructions."
    except Exception as error:
        # Invalid carries the adapter's fixed diagnostic, never raw provider text.
        import scientific_definition_ai as ai
        if isinstance(error, ai.vscode.BridgeError):
            return None, ai.vscode.ERRORS.get(error.code, ai.vscode.ERRORS["provider_error"]) + " Answers come from the product's own checks until the connection is restored."
        if isinstance(error, ai.Invalid) and error.code and error.code != "provider_error":
            return None, str(error) + " Answers come from the product's own checks until the connection is restored."
        return None, "The selected assistant connection is unavailable; answers come from the product's own checks."


def _feedback_route(card):
    import workflow_skills
    route = (card.get("current_task") or {}).get("route") or (card.get("next_step") or {}).get("action_id") or "progress"
    try:
        workflow_skills.binding_for(route)
    except workflow_skills.Invalid:
        route = "progress"
    return route


def _value_text(value):
    return value if isinstance(value, str) else json.dumps(value, ensure_ascii=False, sort_keys=True)


def _field_feedback_text(fields, *, state, revised=False):
    blocks = []
    for field in fields:
        if revised:
            text = _value_text(field["current"]) if field["current_present"] else "Not currently displayed in this form."
            blocks.append(field["label"] + " — current draft:\n" + text)
            continue
        applied = (_value_text(field["applied"]) if field["applied_present"] else
                   "Not applied: the existing entries were kept." if state == "rejected" else
                   "Not available after the form updated." if state == "applied" else "Not applied; awaiting your review.")
        blocks.append(field["label"] + "\nBefore chat:\n" + _value_text(field["before"]) +
                      "\nProposed:\n" + _value_text(field["proposed"]) + "\nActually applied:\n" + applied)
    return "\n\n".join(blocks)


def _offer_form_feedback(root, pack, actor_id, record, *, can_write, allowed_packs, key):
    """Prepare feedback from actual form values through the existing improvement form."""
    import interaction_feedback_page
    fields = record["fields"]
    ui_key = key + "form_feedback"
    st.session_state[form_help.KEY + "feedback_ui_key"] = ui_key
    answer = _field_feedback_text(fields, state=record["state"])
    revised = _field_feedback_text(fields, state=record["state"], revised=True)
    # The existing feedback API checks complete values before excerpting. A large
    # form therefore gets explicit field selection, never silent data truncation.
    if max(len(answer), len(revised)) > 30000:
        labels = {field["id"]: field["label"] for field in fields}
        selected = st.selectbox("Which prepared field needs feedback?", list(labels), format_func=labels.get,
            key=key + "feedback_field_" + record["id"],
            help="This form has long entries. Choose one field so its complete proposed and current values can be reviewed.")
        fields = [field for field in fields if field["id"] == selected]
        answer = _field_feedback_text(fields, state=record["state"])
        revised = _field_feedback_text(fields, state=record["state"], revised=True)
    with st.expander("Review the form values behind this feedback"):
        st.caption("These are the actual proposed and rendered values. Preparing feedback does not save a correction or change the product.")
        st.dataframe([{"Field": field["label"], "Before chat": _value_text(field["before"]),
            "Proposed": _value_text(field["proposed"]),
            "Actually applied": _value_text(field["applied"]) if field["applied_present"] else "Not applied",
            "Current draft": _value_text(field["current"]) if field["current_present"] else "Not currently displayed"}
            for field in fields], hide_index=True, width="stretch")
    event_id = form_help.digest({"interaction": record["id"], "state": record["state"],
        "outcome": record["outcome"], "fields": fields})
    interaction_feedback_page.offer(root, pack, actor_id, route=record["route"], interaction_id=event_id,
        request=record["request"], answer=answer,
        revised_answer=revised if record["outcome"] in {"edited", "rejected"} else None,
        outcome=record["outcome"], can_write=can_write, allowed_packs=allowed_packs or [], key=ui_key,
        title="Feedback on these form values")


def _go(action_id, card, pack, actor_id, question=None):
    """Perform one catalogue action: the page's own navigation, never a governed act."""
    spec = fa.ACTIONS.get(action_id)
    if not spec or action_id not in card.get("actions", []):
        return
    kind, target = spec["kind"], spec["target"]
    if action_id == "open_new_product" and question and st.session_state.get(form_help.KEY + "enabled"):
        import scientific_definition_ai as ai
        try:
            ai._ingress(question)
        except ai.Invalid:
            pass
        else:
            form_help.defer_creation(question)
            if st.session_state.get(form_help.KEY + "page") == "New product":
                return  # Finish this form so navigation cannot discard its unsaved widgets.
    if kind in {"section", "check"}:
        # A section action leaves the current child workspace even when that
        # workspace was opened from the same sidebar section. Keep row/form
        # drafts, but do not let its old route or resolution reopen on rerun.
        for marker in ("connected_workflow", "connected_specialist_evidence", "flow_dialog",
                       "flow_dialog_feedback", "flow_resolution_action", "flow_requested_action"):
            st.session_state.pop(marker, None)
    if kind == "section":
        st.session_state["section_suggested"] = target
    elif kind == "check":
        st.session_state.setdefault("flow_result", {}).pop(pack, None)
        st.session_state["section_suggested"] = "Flow"
    elif kind == "step":
        problem_action = (card.get("workflow_feedback") or {}).get("action_id")
        act = target or (problem_action if isinstance(problem_action, str) and problem_action.startswith(tuple(f"g{n}_" for n in range(1, 7))) else None) or (card.get("next_step") or {}).get("action_id")
        if act:
            import connected_workflow_page
            connected_workflow_page.open_route("progress", pack, actor_id, params={"action_id": act})
            return
    elif kind == "route":
        import connected_workflow_page
        import connected_workflow as workflow
        if action_id == "open_variable_review":
            if not pack:
                st.warning("Choose a product before reviewing its variables.")
                return
            connected_workflow_page.open_route(target, pack, actor_id, params={"phase": "science", "action": "review"})
            return
        current = st.session_state.get(connected_workflow_page.KEY)
        params = {}
        if workflow.valid(current, pack=pack, actor_id=actor_id,
                          section=st.session_state.get("section", "Flow"), allowed_packs=[pack]):
            # Carry the same semantic selection as the workspace's own links.
            # A model chooses only an action id; it cannot supply route params.
            params = workflow.continuation_params(current["route"], target, current.get("params"))
        if action_id in {"open_coding", "open_source_mapping", "open_specialist"}:
            # Only the person's actual submitted question travels with the
            # navigation. The model can select an action, never route content.
            params.pop("user_request", None)
            if isinstance(question, str) and question.strip() and len(question) <= fa.MAX_QUESTION:
                import scientific_definition_ai as ai
                try:
                    ai._ingress(question)
                except ai.Invalid:
                    pass
                else:
                    params["user_request"] = question
        connected_workflow_page.open_route(target, pack, actor_id, params=params)
        return
    st.rerun()


def _forget_chat_suggestions(key):
    import interaction_feedback_page
    interaction_feedback_page.clear(key + "feedback")
    st.session_state.pop(key + "feedback_last", None)
    form_help._forget_feedback()
    for suffix in ("proposal", "apply", "applied", "applied_feedback", "deferred", "notice"):
        st.session_state.pop(form_help.KEY + suffix, None)


def _load_history(history_key, storage):
    """Refresh this profile's history while retaining unsaved local metadata."""
    import chat_history
    revision_key = history_key + "_revision"
    try:
        saved = chat_history.load(**storage)
        if st.session_state.pop(history_key + "_restore_requested", False):
            saved = chat_history.save(**storage, turns=st.session_state.get(history_key, []),
                expected_revision=saved["revision"])
        if revision_key not in st.session_state or st.session_state[revision_key] != saved["revision"]:
            # A durable empty revision also wins over stale browser state.
            if saved["revision"] is not None or history_key not in st.session_state:
                st.session_state[history_key] = saved["turns"]
                if saved["revision"] is not None and not saved["turns"]:
                    _forget_chat_suggestions(storage["channel"])
        st.session_state[revision_key] = saved["revision"]
        return True
    except (ValueError, OSError, TypeError):
        st.warning("Private chat history is unavailable. Messages in this browser are kept; saving will be retried when you return.")
        return False


def _save_history(history_key, storage):
    import chat_history
    try:
        saved = chat_history.save(**storage, turns=st.session_state.get(history_key, []),
            expected_revision=st.session_state.get(history_key + "_revision"))
        st.session_state[history_key + "_revision"] = saved["revision"]
        return True
    except chat_history.Changed:
        _load_history(history_key, storage)
        st.warning("This conversation changed in another session. Review its latest messages before asking again.")
        return False
    except (ValueError, OSError, TypeError):
        st.warning("These messages are available in this browser but could not be saved to your private chat history.")
        return True


def _clear_conversation(history_key, key, question_key=None, storage=None):
    """Clear this profile's conversation, preserving running work and records."""
    if storage is not None:
        import chat_history
        try:
            saved = chat_history.clear(**storage)
            st.session_state[history_key + "_revision"] = saved["revision"]
        except (ValueError, OSError, TypeError):
            st.session_state[key + "clear_failed"] = True
            return
    st.session_state[history_key] = []
    if question_key is not None:
        st.session_state.pop(question_key, None)
    _forget_chat_suggestions(key)
    st.session_state[key + "conversation_cleared"] = True


def _brief_options(root, pack, card, provider, *, actor_id, allowed_packs, render_snapshot=None):
    """Bind draft questions to source inputs, independent of page navigation."""
    connection = {field: (provider or {}).get(field) for field in ("provider_id", "model", "connection_id")}
    study = card.get("study_context") or {}
    scope_id = str(study.get("study_id") or "")
    if pack:
        import specialist_workspace
        try:
            if render_snapshot is None:
                report = specialist_workspace.describe(root, pack, actor_id, allowed_packs=allowed_packs)
            else:
                import specialist_chat
                report = specialist_chat.describe_for_render(root, pack, actor_id,
                    allowed_packs=allowed_packs, render_snapshot=render_snapshot)
            source = {"inputs": report.get("input_digest", "unavailable")}
        except (ValueError, OSError, TypeError):
            source = {"inputs": "unavailable"}
    else:
        setup = card.get("setup_form") or {}
        source = {"sheet_scope": setup.get("sheet_scope"), "compatibility": card.get("setup_compatibility")}
    return {"connection": connection, "source": source, "scope_id": scope_id}


@assistant_layout.in_panel
def render(root, pack, *, card, actor_id, key=KEY, expanded=False, primary=False, can_agent=True, metadata_only=False,
           can_write=False, allowed_packs=None, local_demo=False):
    """A bounded conversation with the composer after its answers and tools."""
    import flow_page
    specialist_snapshot = {}
    observed_feedback = flow_page.assistant_feedback(root, pack, actor_id, card=card)
    if observed_feedback is not None:
        card = {**card, "workflow_feedback": observed_feedback}
    workflow_feedback = card.get("workflow_feedback") or {}
    workflow_paused = workflow_feedback.get("status") in {"blocked", "needs_recheck"}
    workflow_revision = workflow_feedback.get("input_digest")
    revision_key = key + "workflow_revision"
    if st.session_state.get(revision_key) != workflow_revision:
        pending = any(st.session_state.get(form_help.KEY + suffix) for suffix in ("proposal", "apply"))
        for suffix in ("proposal", "apply"):
            st.session_state.pop(form_help.KEY + suffix, None)
        if pending:
            st.session_state[form_help.KEY + "notice"] = {"kind": "warning",
                "text": "The workflow check changed. Earlier pending suggestions were withdrawn; your current form entries are kept."}
        st.session_state[revision_key] = workflow_revision
    provider, words = _provider_words(root)
    if not can_agent:
        provider, words = None, "Answers come from the product's own checks. Model assistance requires permission to use the assistant."
    if provider is not None and not metadata_only:
        try:
            import scientific_definition_ai as ai
            ai.definitions.cs.ai_gate(str(Path(root).resolve() / pack))
        except Exception:
            provider = None
            words = "Answers come from the product's own checks until its source material has recorded AI access. Guided actions remain available."
    live_chat = bool(primary and provider is not None)
    feedback_context = hashlib.sha256(json.dumps({"root": str(Path(root).resolve()), "pack": pack, "actor": actor_id,
        "card": card, "permission": bool(can_write), "scope": sorted(allowed_packs or []),
        "connection": {field: (provider or {}).get(field) for field in ("provider_id", "model", "connection_id")}},
        sort_keys=True, default=str).encode()).hexdigest()
    if st.session_state.get(key + "feedback_context") != feedback_context:
        import interaction_feedback_page
        interaction_feedback_page.clear(key + "feedback")
        st.session_state.pop(key + "feedback_last", None)
        st.session_state[key + "feedback_context"] = feedback_context
    with (st.container(border=True) if live_chat else st.expander(
            "Ask about this rehearsal" if card.get("rehearsal_form") else "Ask about this product", expanded=expanded)):
        if live_chat:
            st.markdown("### Assistant")
        nxt = card.get("next_step") or {}
        st.caption((card.get("stages") or "Not checked in this session yet.") + (f" Next: {nxt['title']}." if nxt.get("title") else ""))
        st.caption(words)
        if workflow_paused:
            st.info("Working on the current workflow problem: " + str(workflow_feedback.get("title") or "Validation needs attention"))
            for blocker in workflow_feedback.get("blockers") or []:
                st.write(blocker)
            if workflow_feedback.get("status") == "needs_recheck":
                st.caption("The form changed after this check. Validate the current entries again before treating the earlier findings as resolved.")
            st.caption("Study-design questions are paused while this problem is open. Earlier chat answers remain visible as history.")
        saved = (card.get("plan_form") or {}).get("saved_proposal") or {}
        if saved.get("proposal_id"):
            purpose = str(saved.get("purpose") or "").strip()[:200]
            st.info((f"Selected saved proposal: {purpose}. " if purpose else "Selected saved proposal. ") +
                    f"Recorded status: {str(saved.get('status', 'unknown')).replace('_', ' ')}. "
                    f"Next action: {saved.get('next_visible_action', 'Open staged proposal')}.")
            st.caption("This status comes from the selected saved snapshot. Earlier chat messages are history; submission requests review and does not approve or release the product.")
        owner = hashlib.sha256((str(root) + "\0" + actor_id).encode()).hexdigest()[:20]
        history_key = f"{key}history_{owner}_{pack}"
        scope_key = history_key + "_scope"
        scope = sorted(allowed_packs or [])
        if st.session_state.get(scope_key) not in (None, scope):
            # References and private specialist results cannot follow a revoked
            # product grant into a smaller access scope. Form drafts are separate.
            st.session_state[history_key] = []
        st.session_state[scope_key] = scope
        history = st.session_state.setdefault(history_key, [])
        storage = {"root": root, "pack": pack, "actor": actor_id,
                   "allowed_packs": allowed_packs or [], "channel": key} if local_demo else None
        if storage is not None:
            if _load_history(history_key, storage):
                st.caption("Your last eight messages and answers are saved privately for this profile and product in this workspace.")
            history = st.session_state[history_key]
        composer_owner = key + "composer_owner"
        if st.session_state.get(composer_owner) != history_key:
            # Keep legacy widget keys, but never expose another profile's
            # unfinished question when switching identities in this browser.
            st.session_state.pop(f"{key}q_{pack}", None)
            st.session_state[composer_owner] = history_key
        brief, brief_options = None, None
        brief_write = bool(local_demo and can_write)
        if local_demo and not card.get("rehearsal_form"):
            import conversation_intake as brief_api
            import conversation_intake_page as brief_page
            try:
                brief_options = _brief_options(root, pack, card, provider, actor_id=actor_id, allowed_packs=allowed_packs or [],
                                               render_snapshot=specialist_snapshot)
                brief = brief_api.load(root, pack, actor_id, allowed_packs=allowed_packs or [], **brief_options)
                brief = brief_page.render(root, pack, actor_id, brief, allowed_packs=allowed_packs or [],
                    can_write=brief_write and not workflow_paused, scope_id=brief_options["scope_id"], key=key + "study_brief_",
                    ask_question=False)["brief"]
            except (ValueError, OSError, TypeError, KeyError):
                brief = None
                st.warning("The saved study brief is unavailable. Your form entries are kept; reload the private draft before continuing its questions.")
        if st.session_state.pop(key + "conversation_cleared", False):
            st.success("Conversation cleared for this profile and product. Your running task, form entries and saved setup drafts are kept.")
        if st.session_state.pop(key + "clear_failed", False):
            st.warning("The saved conversation could not be cleared. Its messages are kept so you can retry.")
        had_history = bool(history)
        clear_control = st.empty()
        def clear_button():
            with clear_control.container():
                st.button("Clear this conversation", key=f"{key}clear_{owner}_{pack}",
                    help="Remove this profile's conversation for the current product and its pending chat suggestions. Running tasks, form entries, product records and saved setup snapshots are kept.",
                    on_click=_clear_conversation, args=(history_key, key, f"{key}q_{pack}", storage))
        if had_history:
            clear_button()
        form_help.review()
        def show_turn(turn, i, *, submitted=False):
            reference = fa.history_reference(card, task_scope={"pack": pack} if pack else {})
            current_turn = reference is None or turn.get("context_reference") == reference
            with (st.chat_message("user") if live_chat else nullcontext()):
                st.write(turn['question'] if live_chat else f"**You:** {turn['question']}")
            with (st.chat_message("assistant") if live_chat else nullcontext()):
                st.write(turn['answer'] if live_chat else f"**Guide:** {turn['answer']}")
                if not current_turn:
                    st.caption("Earlier workflow state — retained for reference. Its suggested actions are no longer active.")
                knowledge = turn.get("knowledge") or {}
                if knowledge.get("sources"):
                    with st.expander("References used for this conversation"):
                        references = {item.get("source_id"): item for item in knowledge.get("references", [])}
                        cited = set(turn.get("evidence_ids") or [])
                        for source in knowledge["sources"]:
                            reference = references.get(source["id"], {})
                            st.write(source.get("label") or "Reference")
                            st.caption("Cited in this answer" if source["id"] in cited else "Provided as context")
                            details = [reference.get(field) for field in ("source_status", "recorded_status", "status", "reference_version", "version", "release", "applicability")]
                            st.caption(" · ".join(str(value) for value in details if value))
                            st.text(source.get("text") or "")
                            st.caption("Reference: " + source["id"])
                            for field, label in (("artifact", "Record"), ("record_id", "Record identifier"),
                                                 ("artifact_sha256", "Source SHA-256")):
                                if reference.get(field):
                                    st.text(label + ": " + str(reference[field]))
                            url = reference.get("source_url")
                            if isinstance(url, str) and url.startswith("https://"):
                                from urllib.parse import urlsplit
                                try:
                                    parsed_url = urlsplit(url)
                                    if parsed_url.hostname and not parsed_url.username and not parsed_url.password:
                                        st.link_button("Open reference source", url,
                                            key=f"{key}reference_{owner}_{pack}_{turn.get('id') or i}_{source['id']}")
                                except ValueError:
                                    pass
                        for notice in knowledge.get("notices") or []:
                            st.caption(notice)
                elif knowledge.get("notices"):
                    with st.expander("Reference availability"):
                        for notice in knowledge["notices"]:
                            st.caption(notice)
                if turn.get("specialist"):
                    import specialist_chat
                    specialist_chat.render(root, pack, actor_id, turn, card=card, allowed_packs=allowed_packs or [],
                        provider=provider, local_demo=local_demo, can_agent=can_agent and current_turn, can_write=can_write and current_turn,
                        key=f"{key}specialist_{owner}_{pack}_{turn.get('id') or i}", submitted=submitted and current_turn,
                        render_snapshot=specialist_snapshot, historical=not submitted and i < len(history) - 1)
            if turn.get("note"):
                st.caption(turn["note"])
            window = turn.get("context_window") or {}
            if window.get("omitted_turns"):
                st.caption(f"This answer included {window.get('included_turns', 0)} earlier conversation turns. "
                           f"{window['omitted_turns']} earlier turns were outside its context window; restate any details you still need.")
            actions = [a for a in turn.get("actions", []) if current_turn and (submitted or i == len(history) - 1)
                       and a in card.get("actions", []) and a in fa.ACTIONS]
            cols = st.columns(len(actions)) if actions else []
            for col, action_id in zip(cols, actions):
                with col:
                    if st.button(fa.ACTIONS[action_id]["label"], key=f"{key}act_{pack}_{i}_{action_id}"):
                        _go(action_id, card, pack, actor_id, question=turn.get("question"))
        conversation = st.container(height=320, border=False, autoscroll=True) if live_chat else st.container()
        with conversation:
            if live_chat and not history:
                with st.chat_message("assistant"):
                    st.write("Tell me what you want to do. I can compare relevant references and prior study examples, prepare draft fields, or ask a specialist and show its findings here.")
            for i, turn in enumerate(history[-fa.MAX_CONVERSATION_TURNS:]):
                show_turn(turn, i)
        tools_area = st.container()
        with tools_area:
            question_area = st.empty()
        question_reply = {"reply": None, "question_token": None}
        previous_question_token = (brief or {}).get("pending_question", {}) or {}
        previous_question_token = previous_question_token.get("token")
        if brief is not None and brief.get("pending_question") and live_chat and not workflow_paused:
            with question_area.container():
                question_reply = brief_page.render_question(brief, key=key + "study_brief_", can_write=brief_write)
        if live_chat:
            question = st.chat_input("What would you like to do next?", key=f"{key}chat_{owner}_{pack}", max_chars=fa.MAX_QUESTION)
            asked = bool(question)
        else:
            with st.form(f"{key}form_{pack}", clear_on_submit=True):
                question = st.text_input("Your question", key=f"{key}q_{pack}", placeholder="What do I do next? What blocks this? Who signs?", max_chars=fa.MAX_QUESTION)
                asked = st.form_submit_button("Ask", key=f"{key}ask_{pack}")
        if question_reply["reply"]:
            question, asked = question_reply["reply"], True
        resumed_question = form_help.deferred_question()
        if resumed_question:
            question, asked = resumed_question, True
        public_form = form_help.context(question) if asked else None
        needs_creation_form = st.session_state.get(form_help.KEY + "page") != "New product" or not public_form
        if asked and question.strip() and fa.creation_request(question) and needs_creation_form and "open_new_product" in card.get("actions", []) and st.session_state.get(form_help.KEY + "enabled"):
            import scientific_definition_ai as ai
            try:
                ai._ingress(question)
            except ai.Invalid:
                pass  # The normal answer path displays the existing ingress refusal.
            else:
                form_help.defer_creation(question)
                st.info("Opening the product form so I can prepare its actual fields from your request.")
                asked = False
        if asked and question.strip():
            reviewing_variables = fa.variable_review_request(question)
            resolved_question = None
            brief_error = None
            if brief is not None and brief_write and not workflow_paused and not reviewing_variables:
                try:
                    updated, expanded_question, matched = brief_api.resolve_reply(brief, question,
                        question_token=question_reply["question_token"])
                    if matched:
                        resolved_question = expanded_question
                        brief = brief_api.save(root, pack, actor_id, updated,
                            allowed_packs=allowed_packs or [], can_write=brief_write,
                            expected_revision=brief["revision"], scope_id=brief_options["scope_id"])
                except brief_api.ai.Invalid:
                    pass  # The guide's normal ingress refusal scrubs the history.
                except (ValueError, OSError, TypeError, KeyError):
                    brief_error = "This brief question changed or its answer could not be saved. Your wording is kept; review the current brief before answering again."
            answer_card = {**card, **({"editable_form": public_form} if public_form else {})}
            specialist = None
            if not brief_error and provider is not None and can_agent and local_demo and not card.get("rehearsal_form") and not reviewing_variables:
                import specialist_chat
                try:
                    specialist = specialist_chat.prepare(question, root=root, pack=pack, actor_id=actor_id,
                        card=card, allowed_packs=allowed_packs or [], provider=provider,
                        previous_turn=history[-1] if history and
                            (fa.history_reference(card, task_scope={"pack": pack} if pack else {}) is None or
                             history[-1].get("context_reference") == fa.history_reference(card, task_scope={"pack": pack} if pack else {})) else None)
                except (ValueError, OSError):
                    pass  # The existing answer path supplies the ingress refusal.
            if brief_error:
                reply = {"answer": brief_error, "actions": [], "source": "checks"}
            elif specialist and specialist["explicit"]:
                reply = {"answer": "I'll work through this request here and show the specialist's findings and critique. Any missing definition choice will appear below.",
                         "actions": [], "source": "specialist"}
            else:
                reply = fa.answer(question, answer_card, root=root, provider=provider, history=history[-fa.MAX_CONVERSATION_TURNS:] if live_chat else None,
                    task_scope={"pack": pack} if pack else {}, actor_id=actor_id, allowed_packs=allowed_packs,
                    study_brief=None if workflow_paused else brief, resolved_question=resolved_question)
            latest_feedback = flow_page.assistant_feedback(root, pack, actor_id, card=card)
            if latest_feedback != observed_feedback:
                if reviewing_variables and reply.get("source") != "refused":
                    reply = fa.answer(question, {**card, "workflow_feedback": latest_feedback,
                                                  "variable_workflow": {}, "blockers": []})
                    reply["note"] = "The workflow changed while answering. The review page rechecks the current table before confirmation."
                else:
                    reply = {"answer": "The workflow changed while I was answering. Your current entries are kept. Review the latest check and ask again so suggestions use that result.",
                             "actions": [], "source": "checks"}
                specialist = None
            if brief is not None and reply.get("source") == "assistant" and not workflow_paused:
                try:
                    current_provider = _provider_words(root)[0] if can_agent else None
                    current_options = _brief_options(root, pack, card, current_provider, actor_id=actor_id, allowed_packs=allowed_packs or [])
                    if current_options != brief_options:
                        raise ValueError("Source changed")
                    latest_brief = brief_api.load(root, pack, actor_id, allowed_packs=allowed_packs or [], **current_options)
                    if latest_brief["revision"] != brief["revision"]:
                        raise ValueError("Draft changed")
                    if reply.get("brief_updates") or reply.get("questions") or reply.get("prefill"):
                        # The expanded MCQ includes the assistant's prompt. Only
                        # the submitted user text can justify verbatim wording.
                        updated = brief_api.apply_reply(brief, reply, user_text=question,
                            public_form=form_help.context(question) if reply.get("prefill") else public_form)
                        brief = brief_api.save(root, pack, actor_id, updated, allowed_packs=allowed_packs or [],
                            can_write=brief_write, expected_revision=brief["revision"], scope_id=brief_options["scope_id"])
                        st.caption("Study brief updated. Your exact wording is retained; inferred wording is available to inspect in the brief.")
                except (ValueError, OSError, TypeError, KeyError):
                    reply.pop("prefill", None)
                    reply.pop("questions", None)
                    reply.pop("brief_updates", None)
                    reply["note"] = "The study brief changed or could not be saved. Your current form entries are kept. Reload the brief before requesting more changes."
            safe_question = "Message not retained because it contains restricted information." if reply.get("source") == "refused" else " ".join(question.split())[:fa.MAX_QUESTION]
            interaction_id = uuid.uuid4().hex
            turn = {"id": interaction_id, "question": safe_question, "answer": reply["answer"],
                    "actions": reply.get("actions") or [], "note": reply.get("note", ""), "source": reply.get("source"),
                    "context_window": reply.get("context_window") or {},
                    "context_reference": fa.history_reference(card, task_scope={"pack": pack} if pack else {})}
            if reply.get("knowledge"):
                turn.update(knowledge=reply["knowledge"], evidence_ids=reply.get("evidence_ids") or [])
            if specialist and reply.get("source") != "refused":
                turn["specialist"] = specialist
            turn_index = len(history[-fa.MAX_CONVERSATION_TURNS:])
            history.append(turn)
            st.session_state[history_key] = history[-fa.MAX_CONVERSATION_TURNS:]
            current_conversation = storage is None or _save_history(history_key, storage)
            if current_conversation and reply.get("prefill") and reply.get("source") != "refused":
                try:
                    form_help.stage(reply["prefill"], public=public_form,
                        interaction={"id": interaction_id, "request": safe_question, "route": _feedback_route(card)})
                except ValueError as error:
                    st.warning(str(error))
            if not current_conversation:
                history = st.session_state[history_key]
            if not had_history:
                clear_button()
            # Persist the request before a specialist starts. A Streamlit rerun
            # during its bounded worker must not silently replay or lose it.
            with conversation:
                if current_conversation:
                    show_turn(turn, turn_index, submitted=True)
            if brief is not None and live_chat and not workflow_paused:
                current_token = (brief.get("pending_question") or {}).get("token")
                if current_token != previous_question_token:
                    question_area.empty()
                    if current_token:
                        with question_area.container():
                            brief_page.render_question(brief, key=key + "study_brief_", can_write=brief_write)
            if current_conversation and reply.get("source") == "assistant" and provider is not None:
                st.session_state[key + "feedback_last"] = {"id": interaction_id,
                    "request": safe_question, "answer": reply["answer"]}
            else:
                st.session_state.pop(key + "feedback_last", None)
            # Finish rendering the editor below. An early rerun here removes its
            # widgets and can discard unsaved fields on an assistant timeout.
        if history and history[-1].get("source") != "refused" and not card.get("rehearsal_form"):
            import conversation_examples_page
            example_query = fa.retrieval_query(history[-1]["question"],
                fa.conversation_history(card, history[:-1], task_scope={"pack": pack} if pack else {}),
                brief_terms=brief_api.retrieval_context(brief) if brief is not None else None)
            with tools_area:
                if st.toggle("Find reusable examples", key=f"{key}show_examples_{owner}_{pack}",
                             help="Search prior requests and reviewed concepts when you need them."):
                    conversation_examples_page.render(root, pack, question=example_query, actor_id=actor_id,
                        allowed_packs=allowed_packs or [], card=card, key=f"{key}examples_{owner}_{pack}", can_write=can_write)
        feedback = st.session_state.get(key + "feedback_last")
        field_feedback = form_help.feedback()
        newer_answer = bool(feedback and field_feedback and feedback["id"] != field_feedback["id"])
        if field_feedback and field_feedback["outcome"] in {"edited", "rejected"}:
            with tools_area:
                _offer_form_feedback(root, pack, actor_id, field_feedback, can_write=can_write,
                    allowed_packs=allowed_packs, key=key)
        if feedback and provider is not None and (not field_feedback or newer_answer):
            import interaction_feedback_page
            route = _feedback_route(card)
            with tools_area:
                if st.toggle("Give feedback on the latest answer", key=key + "feedback_open_" + feedback["id"]):
                    st.caption("Answer: " + feedback["answer"][:180])
                    interaction_feedback_page.offer(root, pack, actor_id, route=route, interaction_id=feedback["id"],
                        request=feedback["request"], answer=feedback["answer"], can_write=can_write,
                        allowed_packs=allowed_packs or [], key=key + "feedback")
        quick = [a for a in ("open_step", "open_questions", "open_handoffs") if a in (card.get("actions") or [])]
        if not history and quick and not live_chat:
            st.caption("Or go straight to:")
            cols = st.columns(len(quick))
            for col, action_id in zip(cols, quick):
                with col:
                    if st.button(fa.ACTIONS[action_id]["label"], key=f"{key}quick_{pack}_{action_id}"):
                        _go(action_id, card, pack, actor_id)
        if storage is not None:
            # Specialist results may update their turn while it is rendered.
            # No job handles or workflow controls enter the private snapshot.
            _save_history(history_key, storage)
