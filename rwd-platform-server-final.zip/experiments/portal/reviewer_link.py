"""Explain source-review identity setup without registering or authenticating anyone.

`linked` means an eligible verification key is registered for the exact canonical
name. Only `authenticated` means the existing verifier accepted this review's
signature. Neither asserts a portal-account mapping, which is not implemented.
"""
from __future__ import annotations

from pathlib import Path
import hashlib
import re

import yaml

import approval_identity as ai
from person_rules import unstated
from product_gates import bad_date

SOURCE_FIELDS = ("approved_by", "classified_by")
DOC = "governance/APPROVAL_IDENTITY.md"
REGISTRY = "governance/allowed_signers.yaml"
TOOL = "platform/tools/approval_identity.py"


class Invalid(ValueError):
    pass


class Loader(yaml.SafeLoader):
    def construct_mapping(self, node, deep=False):
        keys = []
        for key, _ in node.value:
            if not isinstance(key, yaml.ScalarNode) or key.tag != "tag:yaml.org,2002:str" or key.value in keys:
                raise Invalid("The identity records contain duplicate or non-text field names.")
            keys.append(key.value)
        return super().construct_mapping(node, deep=deep)


def _read(path, *, with_digest=False):
    if path.resolve() != path:
        raise Invalid("An identity record redirects to another location; ask the administrator to repair it.")
    with path.open("rb") as handle:
        raw = handle.read(1024 * 1024 + 1)
    if len(raw) > 1024 * 1024:
        raise Invalid("An identity record is too large to inspect safely.")
    text = raw.decode("utf-8")
    if any(isinstance(token, (yaml.AliasToken, yaml.AnchorToken)) for token in yaml.scan(text)):
        raise Invalid("An identity record uses YAML aliases; ask the administrator to review it.")
    doc = yaml.load(text, Loader=Loader)
    if not isinstance(doc, dict):
        raise Invalid("An identity record must contain a mapping of named fields.")
    return (doc, hashlib.sha256(raw).hexdigest()) if with_digest else doc


def _registered(root):
    path = root / REGISTRY
    if not path.is_file():
        return {}, ["The reviewer verification-key registry has not been provided."], ""
    try:
        doc, digest = _read(path, with_digest=True)
        signers = doc.get("signers")
        ineligible = doc.get("known_ineligible", [])
        if not isinstance(signers, list) or not isinstance(ineligible, list):
            raise Invalid("The reviewer registry needs lists of signers and known ineligible keys.")
        for entry in ineligible:
            if not isinstance(entry, dict) or not isinstance(entry.get("key_id"), str) or not entry["key_id"].strip():
                raise Invalid("An ineligible-key entry is malformed; the administrator must repair the registry.")
        seen = set()
        for entry in signers:
            if not isinstance(entry, dict):
                raise Invalid("A reviewer-key entry is malformed; the administrator must repair the registry.")
            for field in ("key_id", "identity", "registered_by"):
                if not isinstance(entry.get(field), str) or unstated(entry[field]):
                    raise Invalid("A reviewer-key entry is missing its key, exact identity or registration owner.")
            if unstated(entry.get("registered_date")) or bad_date(entry.get("registered_date")) or entry.get("attests") != ai.PERSON_REVIEW:
                raise Invalid("Only dated person-review key registrations can connect a reviewer; automation and hosting-platform keys cannot.")
            if entry["key_id"] in seen:
                raise Invalid("A verification key is registered more than once; its identity must be unambiguous.")
            seen.add(entry["key_id"])
        keys = ai.person_keys(doc)
        if len(keys) != len(signers):
            raise Invalid("An ineligible key appears in the reviewer registry; it cannot connect a reviewer.")
        return keys, [], digest
    except (Invalid, OSError, UnicodeError, yaml.YAMLError, ValueError, TypeError, RecursionError) as error:
        return {}, [str(error) if isinstance(error, Invalid) else "The reviewer registry could not be read safely; an administrator must repair it."], ""


def describe(root, pack, actor_id, local_demo):
    """Read the selected source's named reviewers and existing signature evidence."""
    root = Path(root).resolve()
    pack = str(pack or "").replace("\\", "/")
    source = root / pack / "source_refs.yaml"
    errors, people, materials, source_digest = [], {}, [], ""
    try:
        if not re.fullmatch(r"(?:products|fixtures)/[A-Za-z0-9_-]+/[A-Za-z0-9_-]+/\d{6}", pack):
            raise Invalid("Choose a product inside the current workspace before requesting reviewer setup.")
        if (root / pack).resolve() != root / pack:
            raise Invalid("The selected product redirects to another location.")
        doc, source_digest = _read(source, with_digest=True)
        materials = doc.get("source_materials")
        if not isinstance(materials, list) or not all(isinstance(m, dict) for m in materials):
            raise Invalid("The source record needs a list of source materials before reviewer setup can be checked.")
        for material in materials:
            mid = str(material.get("material_id") or "unnamed material")
            for field in SOURCE_FIELDS:
                name = material.get(field)
                if unstated(name):
                    continue
                if not isinstance(name, str):
                    raise Invalid("A source reviewer name is malformed. Correct the typed attribution first.")
                person = people.setdefault(name, {"name": name, "display_name": name.replace("_", " "), "fields": [], "materials": [], "claims": []})
                person["claims"].append({"material_id": mid, "field": field})
                if field not in person["fields"]:
                    person["fields"].append(field)
                if mid not in person["materials"]:
                    person["materials"].append(mid)
    except (Invalid, OSError, UnicodeError, yaml.YAMLError, ValueError, TypeError, RecursionError) as error:
        errors.append(str(error) if isinstance(error, Invalid) else "The source-review record could not be read safely.")
        people = {}

    keys, registry_errors, registry_digest = _registered(root)
    errors += registry_errors
    rows = []
    if people and not errors and any(identity in people for identity in keys.values()):
        try:
            relative = f"{pack}/source_refs.yaml"
            rows, audit_errors = ai.audit(str(root), files=lambda path: str(path).replace("\\", "/") == relative)
            errors += list(audit_errors)
            if not isinstance(rows, list) or not all(isinstance(row, dict) for row in rows):
                raise Invalid("The signature verifier returned an unreadable result.")
        except (Invalid, OSError, UnicodeError, ValueError, TypeError, AttributeError, KeyError, RecursionError):
            errors.append("The existing signature verifier could not finish. This review remains unverified.")
            rows = []

    if source_digest:
        try:
            if _read(source, with_digest=True)[1] != source_digest or (registry_digest and _read(root / REGISTRY, with_digest=True)[1] != registry_digest):
                errors.append("The source record or reviewer registry changed during this check. Prepare a new request from the current files.")
                rows = []
        except (Invalid, OSError, UnicodeError, yaml.YAMLError, ValueError, TypeError, RecursionError):
            errors.append("The source record or reviewer registry could not be rechecked. Prepare a new request before relying on this result.")
            rows = []

    reviewers = []
    for name, person in people.items():
        registered = any(identity == name for identity in keys.values()) and not registry_errors
        matching = [row for row in rows if str(row.get("file") or "").replace("\\", "/") == f"{pack}/source_refs.yaml" and row.get("who") == name and row.get("field") in person["fields"]]
        # The current identity verifier groups by file/field/name, not material.
        # Shared names on repeated material fields cannot be silently counted as
        # independently verified claims by this more detailed UI inventory.
        distinct_claims = len(person["claims"]) == len(person["fields"])
        authenticated = bool(registered and not errors and matching and all(row.get("authenticated") is True for row in matching)
                             and {row.get("field") for row in matching} == set(person["fields"]) and distinct_claims)
        signature_verified = bool(registered and not errors and matching and distinct_claims
                                  and all(row.get("signature_verified") is True for row in matching)
                                  and {row.get("field") for row in matching} == set(person["fields"]))
        if authenticated:
            status, explanation = "authenticated", "The existing verifier confirms this person's signature for the current source review."
        elif registered:
            status, explanation = "registered_unverified", "A verification key is registered for this exact name. The current review still lacks verified signature evidence; registering a key alone does not approve it."
            if signature_verified:
                explanation = ai.IDENTITY_EVIDENCE_REQUIRED
            if not distinct_claims:
                explanation = "This person is named on multiple materials. The existing verifier groups matching names by file and field; this report cannot confirm each material's attribution separately. Ask Engineering to check the material-specific review evidence."
        else:
            status, explanation = "setup_required", "No eligible reviewer key is registered for this exact name. The reviewer and platform administrator need to complete identity setup once before reviews can be verified."
        reviewers.append({**person, "linked": registered, "key_registered": registered, "authenticated": authenticated,
                          "signature_verified": signature_verified,
                          "status": status, "explanation": explanation, "claim_coverage_complete": distinct_claims and authenticated,
                          "verification_reasons": [str(row.get("why") or "") for row in matching if row.get("authenticated") is not True]})

    setup = bool(registry_errors or any(not person["key_registered"] for person in reviewers))
    if not reviewers:
        title = "Identify the source reviewer"
        summary = "The source record must name the people who approved it and classified access before their reviews can be verified."
    elif setup:
        title = "Connect the reviewer once"
        summary = "The reviewer's name is recorded, but the platform has no registered proof connecting that name to their reviews. Ask your platform administrator to help the named reviewer complete setup."
    elif all(person["authenticated"] for person in reviewers):
        title = "Reviewer identity verified"
        summary = "The named source reviews have verified identity evidence. Check status for any remaining source-history or scientific requirements."
    elif any(person["signature_verified"] for person in reviewers):
        title = "Independent reviewer identity evidence is required"
        summary = ai.IDENTITY_EVIDENCE_REQUIRED
    else:
        title = "Confirm this review with the reviewer"
        summary = "Reviewer setup exists. The person must still confirm the current review through the registered signing process; a typed name or a portal login does not supply that proof."
    actor = {"id": str(actor_id or ""), "mode": "demo" if local_demo else "hosted_context",
             "explanation": "The selected demo name is a roster label, not a verified sign-in." if local_demo else "The portal's signed-in identity and a verified scientific-review signature are separate checks.",
             "matches_canonical_reviewer": str(actor_id or "") in people, "account_to_key_mapping_implemented": False}
    steps = ["Review the named people and their responsibilities below. Correct a wrong attribution through the review workflow before connecting an identity.",
             "Give the administrator the reviewer setup request. The named reviewer confirms ownership of their organization account and their own verification key; only public verification details belong in the registry.",
             "After setup, the named reviewer confirms the exact source review using their own registered signing process. Engineering runs the existing identity check and returns the result to this product.",
             "Return to Flow and choose Check status. Setup is reused for later reviews; each changed review still needs that person's confirmation."]
    if local_demo:
        steps = ["For development workflow testing, confirm the current review in the portal with the named reviewer's own name and email. The saved confirmation is development-only and portable with the product.",
                 "For production approval, the responsible administrator must arrange authenticated reviewer identity and review evidence through the configured review service."]
    if reviewers and any(person["signature_verified"] for person in reviewers) and not all(person["authenticated"] for person in reviewers):
        steps = ["Keep the recorded review and its verified local signature.", ai.IDENTITY_EVIDENCE_REQUIRED]
    if reviewers and all(person["authenticated"] for person in reviewers):
        steps = ["Return to Flow and choose Check status to see what remains for this product."]
    links = [{"label": label, "path": path} for label, path in (("Reviewer identity design and current implementation", DOC), ("Registered verification keys", REGISTRY)) if (root / path).is_file() and (root / path).resolve() == root / path]
    command = ["python", TOOL, "--check"] if (root / TOOL).is_file() and (root / TOOL).resolve() == root / TOOL else []
    handoff = ["Reviewer setup / current review verification request", f"Product: {pack}", f"Source record: {pack}/source_refs.yaml",
               "Source record SHA-256: " + (source_digest or "Unavailable; repair the record and prepare a new request."),
               "If the source record changes, prepare a new request; this request describes only the bytes identified above.", "", title, summary, "", actor["explanation"], ""]
    for person in reviewers:
        handoff += [f"Canonical reviewer: {person['name']}", "Responsibilities: " + ", ".join(person["fields"]), "Materials: " + ", ".join(person["materials"]), "Status: " + person["status"], person["explanation"], ""]
    handoff += ["Administrator / Engineering:"] + [f"{i}. {step}" for i, step in enumerate(steps, 1)]
    handoff += ["", "Implementation boundary: independent enrolment evidence and portal-account-to-review-key mapping are not implemented. Local signing verifies key possession only. Do not treat adding a roster entry, registering a key, or a hosting-platform merge signature as authenticating this review. Keep private keys with their owners."]
    if links:
        handoff += ["", "Existing references:"] + [link["path"] for link in links]
    if command:
        handoff += ["", "Engineering check, from the repository root (read-only; audits the repository, not just this product):", " ".join(command), "Report this product's source-review findings and preserve all existing review/signature checks."]
    if errors:
        handoff += ["", "Prerequisites needing repair:"] + errors
    return {"reviewers": reviewers, "setup_required": setup, "title": title, "summary": summary, "steps": steps,
            "handoff": "\n".join(handoff), "current_actor": actor, "links": links, "admin_check_argv": command,
            "errors": errors, "read_only": True, "source_sha256": source_digest,
            "linked_means": "eligible_person_review_key_registered", "account_link_implemented": False}
