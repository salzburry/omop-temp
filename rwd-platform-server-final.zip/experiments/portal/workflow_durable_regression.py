"""One reviewed counterexample, evaluated by the same fixed test in two snapshots."""
from __future__ import annotations

import ast
import hashlib
import json
from pathlib import Path
import re
import shutil
import sys
import tempfile
import xml.etree.ElementTree as ET

import portal_runtime

MAX_CASE = 8_000
RUNNER = '''import importlib.util
import json
from pathlib import Path
import sys
import yaml

CASE = json.loads(Path("durable_case.json").read_text(encoding="utf-8"))
ROOT = Path.cwd()
OWNER = ROOT / CASE["path"]

def expect(condition, reason):
    if not condition:
        Path("durable_assertion.json").write_text(json.dumps({"kind": "reviewed_expectation", "reason": reason}), encoding="utf-8")
    assert condition, reason

def test_reviewed_correction():
    case = CASE["case"]
    if case["type"] == "python_call":
        for folder in ("experiments/portal", "experiments/agent", "platform/tools", "platform/engine"):
            sys.path.insert(0, str(ROOT / folder))
        spec = importlib.util.spec_from_file_location("reviewed_durable_owner", OWNER)
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        function = getattr(module, case["function"], None)
        expect(callable(function), "The reviewed owning function is missing.")
        def inputs(value):
            if value == {"$workspace": True}:
                return str(ROOT)
            if isinstance(value, list):
                return [inputs(item) for item in value]
            if isinstance(value, dict):
                return {key: inputs(item) for key, item in value.items()}
            return value
        actual = function(*inputs(case["args"]), **inputs(case["kwargs"]))
        expect(actual == case["expected"], "The owning function did not produce the reviewed expected result.")
    elif case["type"] == "skill_instructions":
        actual = OWNER.read_text(encoding="utf-8")
        expect(all(text in actual for text in case["required"]), "A required reviewed instruction is missing.")
        expect(all(text not in actual for text in case["forbidden"]), "A superseded instruction remains.")
    else:
        document = yaml.safe_load(OWNER.read_text(encoding="utf-8"))
        expect(any(all(entry.get(key) == value for key, value in case["match"].items())
            for entry in document.get(case["collection"], []) if isinstance(entry, dict)), "The reviewed register entry is missing or different.")
'''


def digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, ensure_ascii=False, allow_nan=False).encode()).hexdigest()


def validate(case, kind, path, collection=None):
    try:
        raw = json.dumps(case, ensure_ascii=False, allow_nan=False)
        if len(raw.encode()) > MAX_CASE or not isinstance(case, dict):
            raise ValueError()
        expected = {"code": "python_call", "skill": "skill_instructions"}.get(kind, "registry_entry")
        if case.get("type") != expected:
            raise ValueError()
        if kind == "code":
            if (set(case) != {"type", "function", "args", "kwargs", "expected"}
                    or not re.fullmatch(r"[A-Za-z_][A-Za-z0-9_]{0,79}", str(case["function"]))
                    or case["function"].startswith("__") or not isinstance(case["args"], list) or len(case["args"]) > 10
                    or not isinstance(case["kwargs"], dict) or len(case["kwargs"]) > 10):
                raise ValueError()
        elif kind == "skill":
            if (set(case) != {"type", "required", "forbidden"} or not isinstance(case["required"], list)
                    or not case["required"] or not isinstance(case["forbidden"], list)
                    or len(case["required"]) + len(case["forbidden"]) > 12
                    or any(not isinstance(text, str) or not 3 <= len(text) <= 1500 for text in case["required"] + case["forbidden"])):
                raise ValueError()
        elif (set(case) != {"type", "collection", "match"} or case["collection"] != collection
                or not isinstance(case["match"], dict) or not case["match"]):
            raise ValueError()
        return json.loads(raw)
    except (ValueError, KeyError, TypeError, RecursionError):
        raise ValueError("Provide a reviewed test case for this target: function inputs and expected output, exact skill instructions, or an exact owning-register entry.") from None


def example(kind, collection=None):
    if kind == "code":
        return {"type": "python_call", "function": "function_to_check", "args": [], "kwargs": {}, "expected": "expected result"}
    if kind == "skill":
        return {"type": "skill_instructions", "required": ["The reviewed instruction that should apply."], "forbidden": []}
    return {"type": "registry_entry", "collection": collection, "match": {"name": "reviewed record identifier"}}


def _copy(root, destination):
    # Only repository software and metadata. No .git, credentials, raw delivery,
    # model connection, private run exhaust or binary source workbook is copied.
    folders = ("experiments/portal", "experiments/agent", "platform/tools", "platform/engine", "platform/tests",
               "platform/databricks", "resources", "governance", "products", "fixtures", ".claude/skills", ".github/workflows")
    count, size = 0, 0
    for folder in folders:
        base = root / folder
        for source in sorted(base.rglob("*")):
            if portal_runtime.job_cancelled():
                raise ValueError("The isolated regression snapshot was cancelled.")
            parts = source.relative_to(base).parts
            if any(part.startswith(".") or part in {"__pycache__", "knowledge", "candidates", "runs", "node_modules", "IMPLEMENTATION_REVIEWS"} for part in parts):
                continue
            if not source.is_file() or source.suffix not in {".py", ".yaml", ".yml", ".json", ".md", ".conf"}:
                continue
            count += 1
            size += source.stat().st_size
            if source.resolve() != source or count > 7000 or size > 70_000_000:
                raise ValueError("The isolated regression snapshot is redirected or exceeds its metadata bound.")
            target = destination / source.relative_to(root)
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(source, target)


def _arm(snapshot, case, path, expected_failure):
    if portal_runtime.job_cancelled():
        raise ValueError("The isolated regression was cancelled.")
    portal_runtime.job_progress("Checking the reviewed case " + ("before" if expected_failure else "after") + " the durable change.")
    (snapshot / "durable_case.json").write_text(json.dumps({"path": path, "case": case}), encoding="utf-8")
    (snapshot / "test_durable_case.py").write_text(RUNNER, encoding="utf-8")
    (snapshot / "durable_pytest.ini").write_text("[pytest]\n", encoding="utf-8")
    report = snapshot / "durable_result.xml"
    result = portal_runtime.run([sys.executable, "-m", "pytest", "test_durable_case.py", "--noconftest",
        "-c", "durable_pytest.ini", "-q", "-o", "addopts=", "--junitxml=durable_result.xml"],
        cwd=str(snapshot), timeout_s=90, extra_env={"PYTEST_ADDOPTS": "", "PYTEST_PLUGINS": "",
            "PYTEST_DISABLE_PLUGIN_AUTOLOAD": "1", "PYTHONDONTWRITEBYTECODE": "1", "RWD_PORTAL_LOCAL_WORKSPACE": "0",
            "RWD_PORTAL_LOCAL_DEMO": "0", "ANTHROPIC_API_KEY": "", "OPENAI_API_KEY": ""})
    value = {"exit_code": result.returncode, "tests_run": 0, "failure": 0, "error": 0, "skipped": 0,
             "assertion_failure": False, "passed": False}
    try:
        if report.stat().st_size > 2_000_000:
            raise ValueError()
        tree = ET.parse(report).getroot()
        value.update(tests_run=len(list(tree.iter("testcase"))), **{key: len(list(tree.iter(key))) for key in ("failure", "error", "skipped")})
        failures = list(tree.iter("failure"))
        marker = snapshot / "durable_assertion.json"
        assertion = json.loads(marker.read_text(encoding="utf-8")) if marker.is_file() and marker.stat().st_size <= 1000 else {}
        value["assertion_failure"] = len(failures) == 1 and assertion.get("kind") == "reviewed_expectation"
        if failures:
            value["failure_type"] = "AssertionError" if value["assertion_failure"] else failures[0].get("type", "unclassified failure")[:80]
            value["failure_summary"] = (assertion["reason"] if value["assertion_failure"]
                else "The test failed before establishing the reviewed assertion; this is not a usable counterexample.")
        value["passed"] = (value["tests_run"] == 1 and value["error"] == 0 and value["skipped"] == 0
            and ((result.returncode == 1 and value["failure"] == 1 and value["assertion_failure"]) if expected_failure
                 else (result.returncode == 0 and value["failure"] == 0)))
    except (OSError, ValueError, ET.ParseError):
        pass
    return value


def run(root, proposal, file):
    case = proposal["regression_case"]
    receipt = {"schema": 1, "case_digest": digest(case), "runner_sha256": hashlib.sha256(RUNNER.encode()).hexdigest(),
               "before_sha256": proposal["before_sha256"], "after_sha256": proposal["after_sha256"], "passed": False}
    with tempfile.TemporaryDirectory(prefix="rwd-case-") as temporary:
        snapshot, revised = Path(temporary) / "before", Path(temporary) / "after"
        snapshot.mkdir()
        _copy(Path(root), snapshot)
        shutil.copytree(snapshot, revised)
        target = snapshot / proposal["path"]
        # Each arm starts from the same copied metadata; code and module caches
        # are discarded between arms, and the exact reviewed test is unchanged.
        target.write_bytes(file["before"].encode())
        receipt["before"] = _arm(snapshot, case, proposal["path"], True)
        if receipt["before"]["passed"]:
            (revised / proposal["path"]).write_bytes(file["after"].encode())
            receipt["after"] = _arm(revised, case, proposal["path"], False)
        receipt["passed"] = receipt["before"]["passed"] and (receipt.get("after") or {}).get("passed") is True
    receipt["notice"] = "Same reviewed case and fixed test: an assertion fails before and passes after. This demonstrates the stated case, not universal correctness or scientific approval."
    receipt["digest"] = digest(receipt)
    return receipt


def current(receipt, proposal):
    if not isinstance(receipt, dict):
        return False
    before, after = receipt.get("before") or {}, receipt.get("after") or {}
    if not isinstance(before, dict) or not isinstance(after, dict):
        return False
    return (receipt.get("digest") == digest({key: value for key, value in receipt.items() if key != "digest"})
        and receipt.get("passed") is True and receipt.get("case_digest") == digest(proposal.get("regression_case"))
        and receipt.get("runner_sha256") == hashlib.sha256(RUNNER.encode()).hexdigest()
        and receipt.get("before_sha256") == proposal["before_sha256"] and receipt.get("after_sha256") == proposal["after_sha256"]
        and before.get("exit_code") == 1 and before.get("assertion_failure") is True and before.get("failure") == 1
        and after.get("exit_code") == 0 and after.get("failure") == 0
        and all(arm.get("passed") is True and arm.get("tests_run") == 1 and arm.get("error") == 0 and arm.get("skipped") == 0 for arm in (before, after)))
