"""Exact build release evidence alongside the product's existing human steps."""
from __future__ import annotations

import streamlit as st
import form_assistance as form_help

import release_workspace as backend

PREFIX = "release_workspace_"


def _problems(label, errors):
    if errors:
        with st.expander(f"{label} · {len(errors)} finding(s)"):
            for error in errors:
                st.write(error)


def _step(label, action_id, key, *, selected=None):
    if st.button(label, key=PREFIX + key):
        params = {"action_id": action_id}
        if selected:
            params.update(receipt=selected["receipt"], build_id=selected["build_id"])
        return {"route": "progress", "params": params}
    return None


def render(root, pack, actor_id, *, allowed_packs, local_demo, can_write, can_review=False,
           route="release_readiness", params=None):
    params = params or {}
    context = (str(root), pack, actor_id, tuple(sorted(allowed_packs or [])), local_demo, can_write, can_review)
    if st.session_state.get(PREFIX + "context") != context:
        for key in list(st.session_state):
            if key.startswith(PREFIX):
                del st.session_state[key]
        st.session_state[PREFIX + "context"] = context
    st.subheader("Review an exact build for release")
    st.write("Check the candidate, the approval that names it, and any recorded publication. Continue the existing workflow from the finding that needs attention.")
    st.caption(backend.NOTICE)
    report = backend.describe(root, pack, actor_id, allowed_packs=allowed_packs)
    if not report["ok"]:
        for error in report["errors"]:
            st.error(error)
        return _step("Open product progress", "", "progress_error")
    if not report["production_product"]:
        st.info("This reference or demo pack does not release. Use its evidence to understand the workflow, then open the intended working product.")
    st.markdown("**Current product checks**")
    for gate in report["gates"]:
        st.write(f"{gate['gate']} · {gate['title']}: {gate['state']}")
    with st.expander("Product check findings"):
        for gate in report["gates"]:
            _problems(f"Step {gate['gate']}", gate["blockers"])
    candidates = {row["receipt"]: row for row in report["candidates"]}
    if not candidates:
        st.info("No build receipt is recorded for this product and cut. Run or locate the candidate build, then have the data expert bring its exact manifest into the refresh ledger before reviewing it here.")
        return _step("Prepare or locate the candidate build", "g5_build", "build")
    key = PREFIX + "receipt"
    requested = params.get("receipt")
    request_context = (requested, params.get("build_id"))
    if st.session_state.get(PREFIX + "request_context") != request_context:
        st.session_state[PREFIX + "request_context"] = request_context
        # A return from another workflow without a new explicit selection resumes
        # this person's last receipt, rather than discarding its review context.
        if requested or params.get("build_id"):
            st.session_state[key] = requested if requested in candidates else None
        if not requested and params.get("build_id"):
            matches = [path for path, item in candidates.items() if item["build_id"] == params["build_id"]]
            if len(matches) == 1:
                st.session_state[key] = matches[0]
    if st.session_state.get(key) not in candidates:
        st.session_state[key] = None
    chosen = st.selectbox("Exact build receipt", list(candidates), index=None, key=key,
        placeholder="Choose the build you want reviewed",
        format_func=lambda path: f"{candidates[path]['build_id'] or 'Missing build ID'} · {candidates[path]['status']} · {path}",
        help="Choose the actual receipt. The newest build is never selected on your behalf.")
    if not chosen:
        if requested or params.get("build_id"):
            st.warning("The requested build is missing or ambiguous. Choose its exact recorded receipt.")
        return None
    report = backend.describe(root, pack, actor_id, receipt=chosen, allowed_packs=allowed_packs)
    if not report["ok"]:
        for error in report["errors"]:
            st.error(error)
        return None
    selected = report["selected"]
    # Rechecking changes the displayed basis; it does not silently carry confirmation forward.
    basis = (chosen, report["digest"])
    stale = st.session_state.get(PREFIX + "basis") not in (None, basis)
    if stale:
        st.session_state[PREFIX + "confirm"] = False
        st.warning("The selected build or its supporting evidence changed. Review the current findings before confirming a handoff.")
    st.session_state[PREFIX + "basis"] = basis
    st.markdown("**Selected evidence**")
    st.write(f"Build: {selected['build_id']} · Recorded state: {selected['status']}")
    st.caption("Receipt: " + selected["receipt"])
    if st.button("Review this build's six-layer data report", key=PREFIX + "eda"):
        return {"route": "eda_review", "params": {"receipt": chosen, "build_id": selected["build_id"]}}
    with st.expander("Exact receipt identity"):
        st.code(selected["manifest_sha256"], language=None)
        st.caption("SHA256 of these local receipt bytes. A released receipt has different bytes from the candidate that was approved.")
    if selected["multiple_receipts"]:
        st.info("More than one receipt names this build. This view checks the selected receipt; publication evidence is checked across the recorded receipts by the canonical validator.")
    verdict = selected["verdict"]
    if selected["manifest_errors"] or not verdict["passed"]:
        st.warning("This receipt has validation findings. A named approval cannot turn failed evidence into a passing candidate.")
    else:
        st.success("The recorded candidate stage verdict passes; review and publication requirements remain separate.")
    _problems("Manifest validation", selected["manifest_errors"])
    _problems("Candidate stage findings", verdict["failures"])
    with st.expander("Checks evaluated and not evaluated"):
        st.write("Evaluated: " + (", ".join(verdict["evaluated"]) or "None"))
        st.write("Not evaluated: " + (", ".join(verdict["not_evaluated"]) or "None"))
    st.markdown("**Approval and publication**")
    if selected["candidate_binding_checked"]:
        st.write("Exact candidate approval: " + ("requirements satisfied" if not selected["approval_errors"] else "needs attention"))
        _problems("Exact candidate approval findings", selected["approval_errors"])
    else:
        st.info("This is a released receipt. Its bytes cannot verify the earlier candidate approval digest; use the recorded publication check below.")
    st.write("Approval event trust: " + (str(selected["trust"]) if selected["trust"] else "no recorded trust"))
    _problems("Approval event findings", selected["seal_errors"])
    if selected["published"]:
        st.success("A valid governed publication receipt is recorded for this exact build.")
    else:
        st.info("No valid governed publication is established for this build.")
        _problems("Publication findings", selected["published_errors"])
    if selected["unverified_artifacts"]:
        st.info("Some published artifacts are recorded by the runtime but cannot be reread from this checkout.")
        _problems("Artifacts not reread here", selected["unverified_artifacts"])
    with st.expander("Typed approval record"):
        st.caption("Typed names and dates record attribution. Authentication depends on the existing event and signature checks.")
        st.table([{"Field": key.replace("_", " ").capitalize(), "Recorded value": value or "Not recorded"}
                  for key, value in report["approval"].items()])
    for label, action, key in (
        ("Review the candidate validation evidence", "g5_validate", "validate"),
        ("Open exact build approval", "g6_approve", "approve"),
        ("Record the approval event", "g6_seal", "seal"),
        ("Authenticate the approval event", "g6_countersign", "attest"),
        ("Sign the release review history", "g6_commit", "sign"),
        ("Open the promotion handoff", "g6_promote", "promote")):
        navigation = _step(label, action, key, selected=selected)
        if navigation:
            return navigation
    with st.expander("Ask an owner to review this build"):
        st.caption("This creates a tracked request containing the exact build, receipt digest and your note. It does not fill an approval form or start a job.")
        owner = st.selectbox("Who should act?", ["Data expert", "Reviewer", "Engineering"], index=None,
                             key=PREFIX + "owner", placeholder="Choose the responsible role")
        note = form_help.field(st.text_area, "What should they check?", key=PREFIX + "note", max_chars=1800,
                            help="Example: Review the candidate QC findings against the intended study and confirm which evidence is still missing.", binding=basis)
        confirmed = st.checkbox("I reviewed this exact build and want to request this work.", key=PREFIX + "confirm")
        editable = local_demo and can_write and report["production_product"]
        if st.button("Request exact build review", key=PREFIX + "request",
                     disabled=not (editable and owner and note.strip() and confirmed and selected["build_id"])):
            result = backend.request_review(root, pack, actor_id, receipt=chosen, expected_digest=report["digest"],
                owner=owner, note=note, allowed_packs=allowed_packs, local_demo=local_demo, can_write=can_write)
            if not result["ok"]:
                for error in result["errors"]:
                    st.error(error)
            else:
                st.success("Build review requested. No approval or release was recorded.")
                return {"route": "handoffs", "params": {"handoff_id": result["handoff"]["id"]}, "changed": True}
    return None
