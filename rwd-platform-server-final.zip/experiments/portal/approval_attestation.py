"""Explicit local signature over an existing sealed release approval.

The canonical approval/event ledger owns cryptographic signature verification,
idempotency and append-only write. Private key contents never leave this call.
"""
from __future__ import annotations

import hashlib
import json
from pathlib import Path

import yaml

import approval_record as approvals
import approval_identity as identity
import event_ledger as ledger
import source_workspace
import specification_details as details

NOTICE = ("This verifies a key's signature over an existing approval event. It does not authenticate "
          "the named person, approve new content, sign Git history, start a job or publish a build.")


def _sha(value):
    raw = value if isinstance(value, bytes) else json.dumps(value, sort_keys=True).encode()
    return hashlib.sha256(raw).hexdigest()


def _raw(path):
    path = Path(path).absolute()
    if path.resolve() != path or not path.is_file() or path.stat().st_size > 8 * 1024 * 1024:
        raise ValueError("An approval input is missing, too large or redirects elsewhere. Review its canonical record first.")
    raw = path.read_bytes()
    if path.suffix.lower() in {".yaml", ".yml"} and any(
            isinstance(token, (yaml.AliasToken, yaml.AnchorToken)) for token in yaml.scan(raw)):
        raise ValueError("Approval metadata uses YAML aliases. Ask the data expert to repair its record before signing.")
    return raw


def _scope(root, pack, actor_id, allowed_packs):
    source, pack = details._paths(root, pack, allowed_packs)
    if not isinstance(actor_id, str) or not actor_id.strip() or len(actor_id) > 200:
        raise ValueError("An identified portal session is required.")
    root, product = Path(root).resolve(), source.parent
    source_workspace._configured_inputs(product)
    return root, product, pack


def _snapshot(root, product):
    files = source_workspace._inputs(root, product)
    form = product / "handoff/RELEASE_APPROVAL.yaml"
    document = yaml.load(_raw(form), Loader=details._StrictLoader) if form.is_file() else {}
    if not isinstance(document, dict):
        raise ValueError("The release approval must be a YAML mapping.")
    registry = root / ledger.SIGNING_KEYS
    if registry.resolve() != registry:
        raise ValueError("The signing-key register redirects elsewhere. Ask its owner to repair it.")
    if registry.is_file():
        files[registry.relative_to(root).as_posix()] = _sha(_raw(registry))
    object_id = str(document.get("object_uuid") or "")
    events = root / ledger.EVENTS_DIR
    if events.resolve() != events:
        raise ValueError("The approval event ledger redirects elsewhere. Ask its owner to repair it.")
    checkpoint = root / ledger.CHECKPOINTS
    if checkpoint.resolve() != checkpoint:
        raise ValueError("The event checkpoint redirects elsewhere. Ask its owner to repair it.")
    if checkpoint.is_file():
        files[checkpoint.relative_to(root).as_posix()] = _sha(_raw(checkpoint))
    if ledger.UUID4.fullmatch(object_id):
        directory = events / object_id
        if directory.resolve() != directory:
            raise ValueError("The approval event chain redirects elsewhere. Ask its owner to repair it.")
        if directory.is_dir():
            for path in sorted(directory.rglob("*")):
                if path.resolve() != path:
                    raise ValueError("The approval event chain redirects elsewhere. Ask its owner to repair it.")
                if path.is_file():
                    files[path.relative_to(root).as_posix()] = _sha(_raw(path))
    return files, document


def _fail(error):
    return {"ok": False, "changed": False, "errors": [str(error)], "notice": NOTICE}


def describe(root, pack, actor_id, *, allowed_packs=None):
    try:
        root, product, pack = _scope(root, pack, actor_id, allowed_packs)
        before, document = _snapshot(root, product)
        errors = list(approvals.form_errors(str(root), pack, "release"))
        errors += list(approvals.sealed_errors(str(root), pack, "release"))
        keys, key_errors = ledger.signing_keys(str(root))
        errors += list(key_errors)
        object_id = str(document.get("object_uuid") or "")
        head, events = approvals._head(str(root), object_id) if ledger.UUID4.fullmatch(object_id) else (None, [])
        if head:
            checkpoints = ledger._checkpoints(str(root)).get("heads") or {}
            errors += ledger._check_object(str(root), object_id, checkpoints.get(object_id))
        trust = approvals.trust(str(root), pack, "release") if not errors else None
        after, _document = _snapshot(root, product)
        if before != after:
            raise ValueError("Approval evidence changed while it was checked. Reload the current event before signing.")
        return {"ok": True, "errors": [], "findings": errors, "pack": pack, "object_uuid": object_id,
                "event_sha256": str((head or {}).get("event_sha256") or ""), "trust": trust,
                "signature_verified": trust == "authenticated", "identity_authenticated": False,
                "recorded_events": [str(event.get("event_sha256") or "") for event in events],
                "digest": _sha({"root": str(root), "pack": pack, "actor": actor_id, "files": before}),
                "keys": [{"key_id": key_id, "person": str(value["person"])} for key_id, value in keys.items()
                         if value.get("status") == "active"],
                "approval": {key: str(document.get(key) or "") for key in (
                    "approved_by", "approval_date", "approved_build_id", "approved_manifest_sha256")},
                "notice": NOTICE}
    except (OSError, ValueError, TypeError, KeyError, AttributeError, yaml.YAMLError,
            details._Invalid, source_workspace.Invalid, ledger.LedgerError) as error:
        return _fail(error)


def attest(root, pack, actor_id, *, expected_digest, key_id, private_key_path, confirmed=False,
           local_demo=False, can_review=False, allowed_packs=None):
    """Read a selected external key only after all metadata and permission guards pass."""
    try:
        if local_demo is not True or can_review is not True or confirmed is not True:
            raise ValueError("Signing requires a local reviewer session and your explicit confirmation.")
        current = describe(root, pack, actor_id, allowed_packs=allowed_packs)
        if not current["ok"]:
            return current
        if current["digest"] != expected_digest:
            raise ValueError("The approval, product inputs, event or key register changed. Reload and review the current signature request.")
        if current["findings"]:
            raise ValueError("Complete the existing approval and event checks before signing: " + current["findings"][0])
        if not isinstance(key_id, str) or key_id not in {item["key_id"] for item in current["keys"]}:
            raise ValueError("Choose a registered active signing key. Its owner or Administrator must register the public key first.")
        if not isinstance(private_key_path, str) or not private_key_path.strip():
            raise ValueError("Choose your private-key file outside the checkout.")
        path = Path(private_key_path).expanduser()
        root = Path(root).resolve()
        if not path.is_absolute() or private_key_path.startswith(("\\\\", "//")) \
                or path.resolve() != path or path.is_relative_to(root) or path.name.endswith(".pub"):
            raise ValueError("Use your private-key file at its canonical local path outside the checkout. Network paths and public-key files cannot sign.")
        if not path.is_file() or path.stat().st_size > 4096:
            raise ValueError("The selected private-key file is missing or too large. Use the existing ledger key format.")
        with path.open("rb") as handle:
            private_bytes = handle.read(4097)
        if len(private_bytes) > 4096:
            raise ValueError("The selected private-key file is too large.")
        fresh = describe(root, pack, actor_id, allowed_packs=allowed_packs)
        if not fresh["ok"] or fresh["digest"] != expected_digest:
            raise ValueError("The signing evidence changed before the signature was recorded. Reload and review it again.")
        event, error = approvals.attest(str(root), pack, "release", key_id, private_bytes)
        del private_bytes
        if error or not event:
            raise ValueError(error or "The existing approval recorder did not return an attestation.")
    except (OSError, ValueError, TypeError, KeyError, AttributeError, yaml.YAMLError,
            details._Invalid, source_workspace.Invalid, ledger.LedgerError) as error:
        return _fail(error)
    # An append-only signature may exist even if a later read fails. Never offer a
    # retry as if nothing happened, or rewrite/remove a recorded event.
    changed = event["event_sha256"] not in current["recorded_events"]
    warning = ""
    signature_verified = False
    try:
        verification = ledger.verify_attestation(str(root), current["object_uuid"])
        signature_verified = key_id in verification["authenticated"].get(current["event_sha256"], [])
        checkpoints = ledger._checkpoints(str(root)).get("heads") or {}
        binding_errors = approvals.sealed_errors(str(root), pack, "release") + ledger._check_object(
            str(root), current["object_uuid"], checkpoints.get(current["object_uuid"]))
        if not signature_verified or binding_errors:
            signature_verified = False
            warning = "The signature was recorded, but current event-signature verification needs review. Check the recorded event before taking another action."
    except (OSError, ValueError, TypeError, KeyError, AttributeError, ledger.LedgerError):
        warning = "The signature was recorded, but its verification could not be reread. Check the recorded event before taking another action."
    return {"ok": True, "changed": changed, "authenticated": False, "identity_authenticated": False,
            "signature_verified": signature_verified, "identity_notice": identity.IDENTITY_EVIDENCE_REQUIRED,
            "errors": [], "warning": warning,
            "event_sha256": event["event_sha256"], "object_uuid": current["object_uuid"], "notice": NOTICE}
