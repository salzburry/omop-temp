"""Scoped continuations for specification revisions, study pins, plans and run evidence.

The portal composes existing tools. It never transfers an approval with a definition,
silently changes a frozen plan, or substitutes a draft for a published build receipt.
"""
from __future__ import annotations

import copy
from datetime import datetime, timezone
import difflib
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import tempfile
import time
import yaml

TOOLS = Path(__file__).resolve().parents[2] / "platform/tools"
if str(TOOLS) not in sys.path:
    sys.path.insert(0, str(TOOLS))
import contract_lint as cl
import portal_packs
import product_gates as pg
import project_run
import protocol_record
import scientific_definitions as definitions
import source_manifest
import spec_diff
import specification_details as details
import study_pin

# The portal's own writer lock for one study's protocol. A lock this old is from a
# portal session that never finished its save (audit 2026-09-07, S-07): it is reported
# as stale and may be cleared by a person, never silently reused.
PROTOCOL_LOCK = ".portal-protocol.lock"
LOCK_STALE_SECONDS = 600
# The two record fields the registration form itself supplies (walk 2026-09-07, S-REG). The
# readiness rehearsal cannot type them for a person, so the protocol check's refusals about
# them are set aside there and enforced, with the typed values, by register_protocol.
REGISTRATION_FIELDS = ("registered_by", "registered_date")
_REGISTRATION_FIELD_RE = re.compile(r"\bregistered_(?:by|date)\b")


def _fail(error):
    if isinstance(error, OSError):
        # the file system's refusal in words, never the server's path (walk RW-01, 2026-09-07)
        return {"ok": False, "changed": False, "errors": [definitions._os_words(error)]}
    return {"ok": False, "changed": False, "errors": [str(error)]}


def _plain_os_error(error, what):
    """An OSError names the server's absolute path (audit 2026-09-07, S-07). A person
    reads what failed and that nothing moved; the path stays in the server log."""
    reason = getattr(error, "strerror", None) or type(error).__name__
    return f"The portal could not {what}: {reason}. Nothing was changed."


def _hash(value):
    return hashlib.sha256(value if isinstance(value, bytes) else
                          json.dumps(value, sort_keys=True, default=str).encode()).hexdigest()


def _safe(path):
    path = Path(path)
    if path.resolve() != path:
        raise ValueError("A lifecycle record redirects to another location.")
    return path


def _scope(root, pack, actor_id, allowed_packs):
    product, pack, owner, folder = definitions._scope(root, pack, actor_id, allowed_packs)
    # a short owner folder keeps the record's path under Windows' limit (walk RW-01, 2026-09-07);
    # a folder written under the earlier 24-character name is still read
    lifecycle = folder.parent.parent / "lifecycle"
    short, legacy = lifecycle / owner[:definitions.DIGEST_CHARS], lifecycle / owner[:definitions.LEGACY_DIGEST_CHARS]
    chosen = legacy if (legacy.is_dir() and not short.is_dir()) else short
    return Path(root).resolve(), product, pack, owner, _safe(chosen)


def _write_allowed(local_demo, can_write, confirmed=True):
    if local_demo is not True or can_write is not True or confirmed is not True:
        raise ValueError("Review the proposal in an authorized local editing session before saving.")


def _read(path):
    path = _safe(path)
    if path.stat().st_size > 4 * 1024 * 1024:
        raise ValueError("This record exceeds the editor's 4 MB limit.")
    return path.read_bytes()


def _json_file(path, payload):
    _safe(path.parent).mkdir(parents=True, exist_ok=True)
    definitions._atomic(_safe(path), json.dumps(payload, indent=2, default=str).encode())


def revision(root, pack, actor_id, previous, *, allowed_packs):
    """Evidence and drafter-owned candidates, using the canonical carry verdicts."""
    try:
        base, product, pack, _owner, _folder = _scope(root, pack, actor_id, allowed_packs)
        _base, old, previous, _o, _f = _scope(root, previous, actor_id, allowed_packs)
        if previous == pack or previous.split("/")[:3] != pack.split("/")[:3]:
            raise ValueError("Choose another accessible cut of this same product.")
        delta, note = spec_diff.spec_delta(previous, pack, str(base))
        if note:
            raise ValueError(note)
        verdicts = spec_diff.carry(previous, pack, str(base)) or []
        blocks = {}
        for block in cl.records(cl.read(str(old / "handoff/FUNCTIONAL_CONTRACT.md"))):
            blocks.setdefault(cl._scalar(block, "variable_id"), []).append(block)
        old_bodies, new_bodies = spec_diff._bodies(str(old)), spec_diff._bodies(str(product))
        named = {definitions.row_item_id(r) for r in
                 definitions.requirement_rows(json.loads(_read(product / "spec_pipeline/out/extracted.json")))
                 if r.get("variable") and not definitions.is_context(r)}
        _p, _n, draft_owner, drafts_folder = definitions._scope(root, pack, actor_id, allowed_packs)
        candidates = []
        for variable, verdict, reason in verdicts:
            candidate = {"variable_id": variable, "verdict": verdict, "reason": reason,
                         "item_id": "", "eligible": False, "values": {}}
            if verdict != spec_diff.REDRAFT and len(blocks.get(variable, [])) == 1:
                block = blocks[variable][0]
                cited = [(domain, row) for ref in (cl._list(block, "spec_refs") or [])
                         for domain, row in cl.spec_ref_rows(ref)]
                targets = set(cited) if verdict == spec_diff.AS_IS else {
                    (domain, target) for domain, row in cited
                    for target in spec_diff._where(old_bodies, new_bodies, domain, row)[0]}
                if len(targets) == 1:
                    domain, row = next(iter(targets))
                    item_id = f"{domain}:{row}"
                    if item_id in named:
                        draft_path = definitions._draft_path(drafts_folder, item_id)
                        draft_raw = _read(draft_path) if draft_path.exists() else None
                        if draft_raw:
                            saved = json.loads(draft_raw)
                            if saved.get("owner") != draft_owner or saved.get("pack") != pack or saved.get("item_id") != item_id:
                                raise ValueError("A saved carried-row draft belongs to another context.")
                        candidate.update(item_id=item_id, eligible=True,
                                         values={field: cl._scalar(block, field) or "" for field in definitions.FIELDS},
                                         draft_exists=draft_raw is not None, draft_digest=_hash(draft_raw) if draft_raw else "")
                    else:
                        candidate["reason"] += " This target is not a named requirement available in the scientific editor."
                else:
                    candidate["reason"] += " Several source targets require an explicit row decision."
            elif len(blocks.get(variable, [])) > 1:
                candidate["reason"] += " Duplicate variable identifiers require repair."
            candidates.append(candidate)
        findings, findings_note = spec_diff.findings_check(previous, pack, str(base))
        target_digest = definitions._snapshot(product)
        digest = _hash({"before": definitions._snapshot(old), "after": target_digest,
                        "drafts": [{"item": c["item_id"], "digest": c.get("draft_digest")} for c in candidates]})
        return {"ok": True, "errors": [], "previous": previous, "pack": pack, "delta": delta,
                "changes": _row_changes(old, product),
                "candidates": candidates, "findings": findings or [], "findings_note": findings_note,
                "digest": digest, "target_input_digest": target_digest}
    except (OSError, ValueError, TypeError, KeyError, yaml.YAMLError) as error:
        return _fail(error)


def stage_carry(root, pack, actor_id, previous, selected, *, expected_digest, allowed_packs,
                local_demo, can_write, confirmed):
    """Stage selected individual row drafts; a saved draft is never silently replaced."""
    try:
        _write_allowed(local_demo, can_write, confirmed)
        current = revision(root, pack, actor_id, previous, allowed_packs=allowed_packs)
        if not current["ok"]:
            return current
        if current["digest"] != expected_digest:
            raise ValueError("One of the cuts or saved drafts changed. Compare again before carrying definitions.")
        eligible = {r["variable_id"]: r for r in current["candidates"] if r["eligible"] and not r.get("draft_exists")}
        if not selected or len(set(selected)) != len(selected) or any(v not in eligible for v in selected):
            raise ValueError("Select unchanged single-row definitions without an existing saved draft. Review existing drafts in the row editor.")
        if len({eligible[v]["item_id"] for v in selected}) != len(selected):
            raise ValueError("Several selected definitions resolve to the same new row. Choose one explicit interpretation to review there.")
        staged = []
        for variable in selected:
            row = eligible[variable]
            current_row = definitions.describe(root, pack, actor_id, item_id=row["item_id"], allowed_packs=allowed_packs)
            if not current_row["ok"]:
                return {**current_row, "staged": staged}
            result = definitions.save_draft(root, pack, actor_id, row["item_id"], row["values"],
                                            expected_input_digest=current["target_input_digest"],
                                            expected_draft_digest="", local_demo=local_demo, can_write=can_write,
                                            allowed_packs=allowed_packs)
            if not result["ok"]:
                return {**result, "staged": staged}
            staged.append({"variable_id": variable, "item_id": row["item_id"]})
        _base, _product, pack, owner, folder = _scope(root, pack, actor_id, allowed_packs)
        try:
            _json_file(folder / ("carry-" + _hash(previous)[:16] + ".json"),
                       {"owner": owner, "pack": pack, "previous": previous, "staged": staged, "approved": False})
        except OSError as error:
            # the drafts are saved; the record of the carry is not: say exactly that (walk RW-01)
            return {"ok": False, "changed": True, "staged": staged, "approved": False,
                    "errors": [definitions._os_words(error) + " The row drafts were saved; the record of this carry was not, "
                               "so the carried rows show as ordinary drafts."]}
        return {"ok": True, "changed": True, "staged": staged, "approved": False, "errors": []}
    except (OSError, ValueError, TypeError, KeyError, yaml.YAMLError) as error:
        return _fail(error)


def impact(root, pack, actor_id, rows, *, allowed_packs):
    try:
        base, product, pack, _owner, _folder = _scope(root, pack, actor_id, allowed_packs)
        data = json.loads(_read(product / "spec_pipeline/out/extracted.json"))
        known = {definitions.row_item_id(r) for r in data.get("rows", []) if r.get("row")}
        if not rows or any(r not in known for r in rows):
            raise ValueError("Select current specification rows before calculating impact.")
        # This legacy calculator binds its repository through a module constant. Run
        # the binding in its own process so concurrent Streamlit sessions never share it.
        completed = subprocess.run([sys.executable, str(Path(__file__).resolve()), "--impact", str(base), pack],
                                   input=json.dumps(rows), capture_output=True, text=True, encoding="utf-8", timeout=90)
        if completed.returncode:
            raise ValueError(completed.stderr.strip() or "The impact calculator failed.")
        result = json.loads(completed.stdout)
        result.update(ok=True, errors=[])
        if not result["goldens_to_rerun"]:
            result["coverage_note"] = "No golden cases cite these rows. Missing citations are a coverage finding, not evidence of no impact."
        return result
    except (OSError, ValueError, TypeError, KeyError, subprocess.TimeoutExpired, yaml.YAMLError) as error:
        return _fail(error)


def _citations_allowed(citations, allowed_packs):
    pairs = {(p.split("/")[-2], p.split("/")[-1]) for p in allowed_packs if p.startswith("products/")}
    return all(isinstance(c, dict) and (str(c.get("product")), str(c.get("spec_version"))) in pairs for c in citations)


def _plan_scope_allowed(doc, allowed_packs):
    pre = doc.get("prespecified") if isinstance(doc, dict) else None
    if not isinstance(doc, dict) or pre is not None and not isinstance(pre, dict):
        return False
    scope = (pre or {}).get("scope") or []
    if not isinstance(scope, list):
        return False
    if doc.get("status") == "draft":
        # A newly scaffolded protocol has no chosen scope yet. The product pin is
        # its access association; placeholder pairs are not hidden product grants.
        scope = [c for c in scope if not (isinstance(c, dict) and
                 str(c.get("product")) == "REPLACE_ME" and str(c.get("spec_version")) == "REPLACE_ME")]
    return _citations_allowed(scope, allowed_packs)


def _study_ids(base, pack, allowed_packs):
    """A study appears only when its entire declared product scope is accessible."""
    rows = {}
    if study_pin.resolve_product(pack, str(base))[2]:
        return rows
    pair = tuple(pack.split("/")[-2:])
    _safe(base / "products/registry.yaml")
    entries = {str(w.get("id")): w for w in pg.work_entries(str(base))}
    work = _safe(base / "work")
    if not work.is_dir():
        return rows
    for directory in work.iterdir():
        _safe(directory)
        if not directory.is_dir() or not pg.safe_work_id(directory.name)[0]:
            continue
        study = directory.name
        for name in ("PINS.yaml", "PROTOCOL.yaml", "REQUEST.yaml"):
            _safe(directory / name)
        entry = entries.get(study, {})
        citations = entry.get("cites_release") or []
        protocol_path = directory / "PROTOCOL.yaml"
        if protocol_path.is_file():
            doc = project_run._strict_yaml(_read(protocol_path).decode(), "Study protocol")
            if not _plan_scope_allowed(doc, allowed_packs):
                continue
        pins, err = study_pin.load(study, str(base))
        pinrows = [] if err else pins["pins"]
        pinpacks = [p.get("product") for p in pinrows if isinstance(p, dict)]
        if any(p not in allowed_packs for p in pinpacks) or not _citations_allowed(citations, allowed_packs):
            continue
        if pack in pinpacks or any((str(c.get("product")), str(c.get("spec_version"))) == pair for c in citations):
            rows[study] = {"study": study, "kind": entry.get("kind") or study_pin.study_kind(study, str(base)),
                           "protocol": entry.get("protocol", ""), "entry": entry, "pins": pinrows}
    # Projects point to their analysis plan; show that plan only if its own scope
    # also passes the same access test.
    for row in list(rows.values()):
        pid = str(row.get("protocol") or "")
        pentry = entries.get(pid, {})
        if pid and pg.safe_work_id(pid)[0] and _citations_allowed(pentry.get("cites_release") or [], allowed_packs):
            _safe(work / pid)
            protocol_path = _safe(work / pid / "PROTOCOL.yaml")
            if protocol_path.is_file():
                doc = project_run._strict_yaml(_read(protocol_path).decode(), "Project protocol")
                if not _plan_scope_allowed(doc, allowed_packs):
                    continue
            rows.setdefault(pid, {"study": pid, "kind": "protocol", "protocol": "", "entry": pentry, "pins": []})
    return rows


def _study(root, pack, actor_id, study, allowed_packs):
    base, product, pack, owner, folder = _scope(root, pack, actor_id, allowed_packs)
    if not pg.safe_work_id(study)[0]:
        raise ValueError("Choose a valid study identifier.")
    choices = _study_ids(base, pack, allowed_packs)
    if study not in choices:
        raise ValueError("This study is not bound to the selected product within your access.")
    directory = _safe(base / "work" / study)
    for path in directory.rglob("*"):
        _safe(path)
    return base, product, pack, owner, folder, directory, choices[study]


def _study_digest(base, product, directory):
    values = {str(p.relative_to(directory)): _hash(_read(p)) for p in directory.rglob("*") if p.is_file() and not p.name.endswith(".lock")}
    values["registry"] = _hash(_read(_safe(base / "products/registry.yaml")))
    values["product"] = definitions._snapshot(product)
    return _hash(values)


def studies(root, pack, actor_id, *, allowed_packs):
    try:
        base, _product, pack, _owner, _folder = _scope(root, pack, actor_id, allowed_packs)
        return {"ok": True, "errors": [], "studies": list(_study_ids(base, pack, allowed_packs).values())}
    except (OSError, ValueError, TypeError, KeyError, yaml.YAMLError) as error:
        return _fail(error)


def refresh_details(root, pack, actor_id, study, *, allowed_packs):
    try:
        base, product, pack, _o, _f, directory, row = _study(root, pack, actor_id, study, allowed_packs)
        pin = next((p for p in row["pins"] if p.get("product") == pack), None)
        if pin is None:
            raise ValueError("Pin this product to the study first, then use refresh when its definition, configuration or selected build changes.")
        slug, cut = pack.split("/")[-2:]
        builds = []
        for _receipt, doc in source_manifest.receipts_for(str(base), slug, cut):
            build_id = str((doc.get("release") or {}).get("build_id") or "")
            if build_id:
                built, error = study_pin.build_receipt(str(base), slug, cut, build_id)
                if not error and built["status"] == "released" and built["verdict"].get("passed"):
                    builds.append(built)
        current_contract = study_pin.contract_digest(str(product))
        current_config = pg.config_bundle_sha256(str(product))
        # The same comparison the pin tool's refresh makes before it refuses "nothing to
        # refresh" (audit 2026-09-07, S-04): the page disables its button on this instead
        # of offering a refresh that errors.
        unchanged = current_contract == pin.get("contract_sha256") and current_config == pin.get("config_bundle_sha256")
        return {"ok": True, "errors": [], "pin": pin, "builds": builds, "unchanged": unchanged,
                "current_contract": current_contract, "current_config": current_config,
                "checks": study_pin.check_study(study, str(base)),
                "digest": _hash({"study": _study_digest(base, product, directory), "builds": builds})}
    except (OSError, ValueError, TypeError, KeyError, yaml.YAMLError) as error:
        return _fail(error)


def refresh_pin(root, pack, actor_id, study, *, reviewed_by, reviewed_date, build_id,
                expected_digest, allowed_packs, local_demo, can_write, confirmed):
    try:
        _write_allowed(local_demo, can_write, confirmed)
        _study(root, pack, actor_id, study, allowed_packs)
        # Hold the canonical study writer lock across the optimistic recheck and
        # its ordinary refresh implementation, so another pin writer cannot slip
        # a decision or refresh between the reviewed comparison and the write.
        with study_pin._writing(study, str(Path(root).resolve())):
            current = refresh_details(root, pack, actor_id, study, allowed_packs=allowed_packs)
            if not current["ok"]:
                return current
            if current["digest"] != expected_digest:
                raise ValueError("The study, product or available builds changed. Reload and review the comparison again.")
            if build_id and build_id not in {b["build_id"] for b in current["builds"]}:
                raise ValueError("Choose an exact published build with a passing committed receipt.")
            path, errors = study_pin._refresh(study, pack, reviewed_by, reviewed_date, str(Path(root).resolve()), build=build_id or None)
        return {"ok": not errors, "changed": bool(path), "errors": errors, "path": path,
                "next": "Review the study's per-variable reuse, reconsider and exclusion decisions against the refreshed pin."}
    except (OSError, ValueError, TypeError, KeyError, RuntimeError, yaml.YAMLError) as error:
        return _fail(error)


def _scope_from_pins(pins):
    """The plan's product scope, copied from the study's own pins (audit 2026-09-07, S-02).

    A protocol saved from the portal kept `scope: REPLACE_ME` after every save, so no study
    could leave draft. The releases a study reads are recorded once, in work/<study>/PINS.yaml
    by the pin tool, and the scope entry the protocol check compares against the registry is
    that same product and cut. Nothing here names a product the person did not pin; a
    superseded pin is the cut the study no longer reads."""
    scope = []
    for pin in pins:
        if not isinstance(pin, dict) or str(pin.get("status") or "pinned") == "superseded":
            continue
        parts = str(pin.get("product") or "").replace("\\", "/").split("/")
        slug = str(pin.get("slug") or (parts[2] if len(parts) == 4 else "")).strip()
        version = str(pin.get("spec_version") or (parts[3] if len(parts) == 4 else "")).strip()
        if not slug or not version:
            raise ValueError("A study pin names no product and cut. Repair the study's pins on the Studies page before saving its protocol.")
        entry = {"product": slug, "spec_version": version}
        for key in ("build_id", "manifest_sha256"):
            if pin.get(key):
                entry[key] = str(pin[key])
        scope.append(entry)
    return scope


def _lock_state(directory):
    lock = _safe(directory / PROTOCOL_LOCK)
    if not lock.exists():
        return {"held": False, "stale": False, "minutes": 0}
    age = max(0.0, time.time() - lock.stat().st_mtime)
    return {"held": True, "stale": age > LOCK_STALE_SECONDS, "minutes": int(age // 60)}


def _record_checks(base, study, text, registry_text=None):
    """The protocol tool's own check over a disposable copy; no temporary write ever enters the plan.

    `registry_text` is the registry AS IT WOULD BE after a registration appends the study's work
    entry; without it the checkout's registry is copied as it stands."""
    with tempfile.TemporaryDirectory(prefix="portal-protocol-") as temporary:
        temp = Path(temporary)
        directory = temp / "work" / study
        directory.mkdir(parents=True)
        (directory / "PROTOCOL.yaml").write_bytes(text.encode("utf-8"))
        (temp / "products").mkdir()
        if registry_text is None:
            shutil.copyfile(Path(base) / "products/registry.yaml", temp / "products/registry.yaml")
        else:
            (temp / "products/registry.yaml").write_bytes(registry_text.encode("utf-8"))
        return list(dict.fromkeys(protocol_record.record_errors(str(temp), {"id": study})))


def _registry_entry_for(base, study):
    return next((w for w in pg.work_entries(str(base)) if str(w.get("id") or "") == study), None)


def _work_entry(study, doc, scope, owner):
    """The registry work entry a registration appends: the shape the registry's own comment block
    documents, with the releases copied from the study's pins. Nothing here is invented: the owner
    is the person who typed the registration, and `title` is the plan's own."""
    entry = {"id": study, "kind": "protocol", "title": str(doc.get("title") or "")}
    if owner:
        entry["owner"] = owner
    entry["cites_release"] = [dict(c) for c in scope]
    return entry


def _registration_rehearsal(base, study, doc, pins, *, registered_by=None, registered_on=None):
    """(protocol text, registry text or None) as the portal's registration would write them.

    Everything the act supplies is carried on the copy: status registered, both digests over the
    plan as it stands, the typed name and date when given, and the registry work entry when the
    study has none yet. A rehearsal never touches the checkout."""
    rehearsed = copy.deepcopy(doc)
    rehearsed["status"] = "registered"
    digest = protocol_record.prespecification_digest(doc)
    if digest:
        rehearsed["registration_digest"] = digest
        rehearsed["prespecification_sha256"] = digest
    if registered_by is not None:
        rehearsed["registered_by"] = registered_by
    if registered_on is not None:
        rehearsed["registered_date"] = registered_on
    registry_text = None
    if _registry_entry_for(base, study) is None:
        scope = _scope_from_pins(pins)
        if scope:
            owner = registered_by if registered_by is not None else (
                None if pg.unstated(doc.get("registered_by")) or protocol_record.MARK in str(doc.get("registered_by"))
                else str(doc.get("registered_by")))
            registry_text = _registry_with_entry(_read(_safe(base / "products/registry.yaml")).decode("utf-8"),
                                                 _work_entry(study, doc, scope, owner))
    return yaml.safe_dump(rehearsed, sort_keys=False, allow_unicode=True), registry_text


def _registration_checks(base, study, doc, pins=()):
    """What protocol_record would still refuse if a person registered this draft from the portal now.

    The page used to say only that registration is the owner's act (audit 2026-09-07, S-02).
    The check that decides it is the tool's; the portal rehearses it on a copy that carries what
    the registration itself writes (status, the plan digests, the registry entry citing the pinned
    releases) and quotes every refusal, so a scientist sees the exact remaining work. The two
    fields the registration form types, the name and the date, are the person's to supply at
    that moment: the check's words about them are set aside here and enforced, on the typed
    values, when the registration is made (walk 2026-09-07, S-REG)."""
    if not isinstance(doc, dict) or str(doc.get("status") or "") != "draft":
        return []
    try:
        text, registry_text = _registration_rehearsal(base, study, doc, pins)
    except ValueError as error:
        return [str(error)]
    checks = _record_checks(base, study, text, registry_text)
    return [check for check in checks if not _REGISTRATION_FIELD_RE.search(check)]


def _named_rows(product):
    """{item id: variable name} for the named requirement rows of one extraction, the rows the
    scientific editor offers."""
    data = json.loads(_read(Path(product) / "spec_pipeline/out/extracted.json"))
    return {definitions.row_item_id(r): str(r.get("variable") or "").strip()
            for r in definitions.requirement_rows(data)
            if r.get("variable") and not definitions.is_context(r)}


def _row_changes(old, new):
    """Rows added, removed and changed in place between two extractions, each named by variable.

    Identity is the row's CONTENT, as spec_diff counts it (a row number is a position, and a
    position moves for reasons that have nothing to do with the text), with the same fallback the
    carry verdict uses for a workbook that renumbers its own Row cell. A row whose text is gone but
    whose number still holds the same variable is an edit in place; a row whose text and variable
    are both gone is removed; new text under no earlier variable is added."""
    old_bodies, new_bodies = spec_diff._bodies(str(old)) or {}, spec_diff._bodies(str(new)) or {}
    old_names, new_names = cl.spec_variables(str(old)), cl.spec_variables(str(new))
    survived, unchanged, changed, removed = set(), 0, [], []
    for domain, rows in old_bodies.items():
        for n, (digest, _key) in rows.items():
            exact = [m for m, (other, _k) in (new_bodies.get(domain) or {}).items() if other == digest]
            where = exact or spec_diff._where(old_bodies, new_bodies, domain, n)[0]
            name = old_names.get((domain, n), "")
            if where:
                survived.update((domain, m) for m in where)
                unchanged += 1
            elif n in (new_bodies.get(domain) or {}) and name and new_names.get((domain, n), "") == name:
                survived.add((domain, n))
                changed.append({"item_id": f"{domain}:{n}", "variable": name})
            else:
                removed.append({"item_id": f"{domain}:{n}", "variable": name})
    added = [{"item_id": f"{domain}:{m}", "variable": new_names.get((domain, m), "")}
             for domain, rows in new_bodies.items() for m in rows if (domain, m) not in survived]
    return {"unchanged": unchanged, "added": added, "removed": removed, "changed": changed}


def previous_cut(root, pack, allowed_packs):
    """The nearest earlier cut of this product within the person's access, from the registry's
    lineage (the same reading the product page makes), or None."""
    version = pack.rsplit("/", 1)[-1]
    earlier = [p for p in portal_packs.lineage(str(Path(root).resolve()), pack)
               if p in allowed_packs and p.rsplit("/", 1)[-1] < version]
    return max(earlier, key=lambda p: p.rsplit("/", 1)[-1]) if earlier else None


def removed_rows(root, pack, actor_id, *, allowed_packs, previous=None):
    """The previous cut's named requirement rows that this cut no longer carries, so a removed
    variable can be examined for its consumers (walk 2026-09-07, NC-08)."""
    try:
        base, product, pack, _owner, _folder = _scope(root, pack, actor_id, allowed_packs)
        previous = previous or previous_cut(root, pack, allowed_packs)
        if not previous:
            return {"ok": True, "errors": [], "previous": None, "cut": "", "rows": []}
        _base, old, previous, _o, _f = _scope(root, previous, actor_id, allowed_packs)
        if previous == pack or previous.split("/")[:3] != pack.split("/")[:3]:
            raise ValueError("Choose another accessible cut of this same product for removed-row impact.")
        named = _named_rows(old)
        cut = previous.rsplit("/", 1)[-1]
        rows = [{"item_id": r["item_id"], "variable_id": named[r["item_id"]], "cut": cut}
                for r in _row_changes(old, product)["removed"] if r["item_id"] in named]
        return {"ok": True, "errors": [], "previous": previous, "cut": cut, "rows": rows}
    except (OSError, ValueError, TypeError, KeyError, yaml.YAMLError) as error:
        return _fail(error)


def protocol(root, pack, actor_id, study, *, allowed_packs):
    try:
        base, product, pack, owner, folder, directory, _row = _study(root, pack, actor_id, study, allowed_packs)
        path = directory / "PROTOCOL.yaml"
        raw = _read(path)
        doc = project_run._strict_yaml(raw.decode("utf-8"), "Protocol")
        if not isinstance(doc, dict) or doc.get("protocol_id") != study:
            raise ValueError("The protocol identifier does not match this study.")
        saved_path = folder / ("protocol-" + study + ".json")
        saved = json.loads(_read(saved_path)) if saved_path.exists() else None
        if saved and (saved.get("owner") != owner or saved.get("pack") != pack or saved.get("study") != study):
            raise ValueError("The saved protocol proposal belongs to another context.")
        pins_doc, pins_error = study_pin.load(study, str(base))
        pins = [] if pins_error else [p for p in pins_doc.get("pins", []) if isinstance(p, dict)]
        scope = _scope_from_pins(pins) or None
        return {"ok": True, "errors": [], "doc": doc, "text": raw.decode("utf-8"),
                "digest": _study_digest(base, product, directory), "saved": saved,
                "checks": protocol_record.record_errors(str(base), {"id": study}),
                "registration_checks": _registration_checks(base, study, doc, pins),
                "pins": pins, "pins_error": pins_error or "", "scope": scope,
                "lock": _lock_state(directory),
                "registered": {"by": str(doc.get("registered_by") or ""), "date": str(doc.get("registered_date") or "")}
                if str(doc.get("status") or "") in protocol_record.FROZEN else None,
                "prespecification_digest": protocol_record.prespecification_digest(doc)}
    except (OSError, ValueError, TypeError, KeyError, SystemExit, yaml.YAMLError) as error:
        return _fail(error)


def _line_end(text, index):
    """Just past the newline ending the line that holds `index`; the text's end when none."""
    if index and text[index - 1] == "\n":
        return index
    end = text.find("\n", index)
    return len(text) if end < 0 else end + 1


def _own_end(node):
    """Where a node's own text ends. PyYAML closes a block collection at the NEXT token, so
    its end mark swallows every comment and blank line up to the following key; the
    scope guidance inside `prespecified:` vanished that way (audit 2026-09-07, S-13)."""
    while not isinstance(node, yaml.ScalarNode):
        if getattr(node, "flow_style", False) or not node.value:
            return node.end_mark.index
        node = node.value[-1][1] if isinstance(node, yaml.MappingNode) else node.value[-1]
    return node.end_mark.index


def _fragment(field, value, column, newline, first_line_indent):
    dumped = yaml.safe_dump({field: value}, sort_keys=False, allow_unicode=True, width=110)
    lines = dumped.rstrip("\n").split("\n")
    indent = " " * column
    return newline.join([(indent if first_line_indent else "") + lines[0]] + [indent + line if line else line for line in lines[1:]]) + newline


def _mapping_edits(text, node, changes, newline):
    """(start, end, replacement) edits that touch only the changed fields of one block mapping.

    A scalar replaced by a scalar keeps its line, its trailing comment and everything around it
    (the approach of specification_details._edited and workflow_record_editor._scalar_edits).
    A structured value replaces its own lines only; a new field lands after the mapping's last
    field. Every other byte of the record is untouched."""
    if not isinstance(node, yaml.MappingNode) or node.flow_style or not node.value:
        raise ValueError("This part of the protocol is written inline. Lay it out one field per line before editing it here.")
    pairs = {key.value: (key, value) for key, value in node.value}
    column = node.value[0][0].start_mark.column
    edits, additions = [], []
    for field, value in changes.items():
        if field not in pairs:
            additions.append(_fragment(field, value, column, newline, True))
            continue
        key, old = pairs[field]
        if isinstance(old, yaml.ScalarNode) and isinstance(value, str):
            prefix = " " if old.start_mark.index and text[old.start_mark.index - 1] == ":" else ""
            suffix = newline if text[old.start_mark.index:old.end_mark.index].endswith("\n") else ""
            edits.append((old.start_mark.index, old.end_mark.index, prefix + json.dumps(value, ensure_ascii=False) + suffix))
        else:
            edits.append((key.start_mark.index, _line_end(text, _own_end(old)), _fragment(field, value, column, newline, False)))
    if additions:
        at = _line_end(text, _own_end(node.value[-1][1]))
        lead = "" if at == 0 or text[at - 1] == "\n" else newline
        edits.append((at, at, lead + "".join(additions)))
    return edits


def _protocol_edit(before, edits, scope=None):
    if not isinstance(edits, dict) or set(edits) - {"title", "prespecified"}:
        raise ValueError("Only the protocol title and plan sections can be changed here.")
    doc = project_run._strict_yaml(before, "Protocol")
    if not isinstance(doc, dict):
        raise ValueError("The protocol must be a YAML mapping before it can be edited here.")
    if not isinstance(edits.get("title"), str) or not isinstance(edits.get("prespecified"), dict):
        raise ValueError("State a title and the prespecified plan sections.")
    pre = edits["prespecified"]
    if set(pre) - set(protocol_record.PRESPECIFIED):
        raise ValueError("Product/build scope and additional registered fields are preserved. Scope changes require a separate protocol amendment review.")
    if "prespecified" in doc and not isinstance(doc["prespecified"], dict):
        raise ValueError("The prespecified block must hold the plan sections as a mapping before it can be edited here.")
    wanted = dict(pre)
    if scope is not None:
        wanted[protocol_record.SCOPE_KEY] = scope
    after_doc = copy.deepcopy(doc)
    after_doc["title"] = edits["title"]
    after_doc.setdefault("prespecified", {}).update(wanted)
    if len(json.dumps(after_doc, default=str)) > 256 * 1024:
        raise ValueError("The protocol draft exceeds the editor limit.")
    # Replace just the values the person changed. Other records, comments, guidance and
    # human transition fields remain byte-for-byte as read.
    tree = yaml.compose(before)
    newline = "\r\n" if "\r\n" in before else "\n"
    top_changes = {} if doc.get("title") == edits["title"] else {"title": edits["title"]}
    existing = doc.get("prespecified") if isinstance(doc.get("prespecified"), dict) else None
    missing = object()
    changed = {k: v for k, v in wanted.items() if existing is None or existing.get(k, missing) != v}
    replacements = []
    if existing is None and changed:
        top_changes["prespecified"] = after_doc["prespecified"]
    if top_changes:
        replacements += _mapping_edits(before, tree, top_changes, newline)
    if existing is not None and changed:
        pre_node = next(value for key, value in tree.value if key.value == "prespecified")
        replacements += _mapping_edits(before, pre_node, changed, newline)
    after = before
    for start, end, fragment in sorted(replacements, reverse=True):
        after = after[:start] + fragment + after[end:]
    if project_run._strict_yaml(after, "Protocol proposal") != after_doc:
        raise ValueError("The protocol structure could not be preserved.")
    return after, after_doc


def preview_protocol(root, pack, actor_id, study, edits, *, expected_digest, allowed_packs):
    try:
        current = protocol(root, pack, actor_id, study, allowed_packs=allowed_packs)
        if not current["ok"]:
            return current
        if current["digest"] != expected_digest:
            raise ValueError("The protocol or its product context changed. Reload before previewing.")
        if current["pins_error"]:
            raise ValueError("The study's pins could not be read, so its product scope cannot be filled: " + current["pins_error"])
        after, doc = _protocol_edit(current["text"], edits, scope=current["scope"])
        checks = list(dict.fromkeys(current["checks"] + _record_checks(root, study, after)))
        status = current["doc"].get("status")
        return {"ok": True, "errors": [], "checks": checks, "passed": not checks,
                "before": current["text"], "after": after, "edits": edits, "digest": current["digest"],
                "proposal_digest": _hash(after.encode()), "status": status, "scope": current["scope"],
                "registration_checks": _registration_checks(Path(root).resolve(), study, doc, current["pins"]),
                "prespecification_digest": protocol_record.prespecification_digest(doc),
                "draft_only": status == "draft", "diff": "".join(difflib.unified_diff(current["text"].splitlines(True), after.splitlines(True), fromfile="Current protocol", tofile="Proposed plan"))}
    except (OSError, ValueError, TypeError, KeyError, SystemExit, yaml.YAMLError) as error:
        return _fail(error)


def _lock_message(state):
    if state["stale"]:
        return (f"A protocol save for this study started {state['minutes']} minute(s) ago and never finished, so its lock "
                f"still blocks saving. Clear the stale lock, then preview and save again.")
    return "Another protocol save for this study is in progress. Wait a moment, then reload and save again."


def clear_protocol_lock(root, pack, actor_id, study, *, allowed_packs, local_demo, can_write, confirmed=True):
    """Remove this study's stale portal protocol lock and nothing else (audit 2026-09-07, S-07)."""
    try:
        _write_allowed(local_demo, can_write, confirmed)
        _base, _product, _pack, _owner, _folder, directory, _row = _study(root, pack, actor_id, study, allowed_packs)
        state = _lock_state(directory)
        if not state["held"]:
            return {"ok": True, "changed": False, "errors": [], "next": "No save lock is held for this protocol. Saving is available."}
        if not state["stale"]:
            raise ValueError(f"Another protocol save for this study started {state['minutes']} minute(s) ago and may still be running. "
                             f"A lock can be cleared only after {LOCK_STALE_SECONDS // 60} minutes.")
        _safe(directory / PROTOCOL_LOCK).unlink()
        return {"ok": True, "changed": True, "errors": [], "next": "The stale lock was cleared. Preview the protocol again, then save."}
    except OSError as error:
        return _fail(_plain_os_error(error, "clear the stale lock"))
    except (ValueError, TypeError, KeyError, RuntimeError, yaml.YAMLError) as error:
        return _fail(error)


def save_protocol(root, pack, actor_id, study, edits, *, expected_digest, expected_proposal_digest,
                  allowed_packs, local_demo, can_write, confirmed):
    lock = None
    fd = None
    try:
        _write_allowed(local_demo, can_write, confirmed)
        base, product, pack, owner, folder, directory, _row = _study(root, pack, actor_id, study, allowed_packs)
        lock = _safe(directory / PROTOCOL_LOCK)
        state = _lock_state(directory)
        if state["held"]:
            raise ValueError(_lock_message(state))
        try:
            fd = os.open(lock, os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o600)
        except FileExistsError:
            raise ValueError(_lock_message(_lock_state(directory))) from None
        proposal = preview_protocol(root, pack, actor_id, study, edits, expected_digest=expected_digest, allowed_packs=allowed_packs)
        if not proposal["ok"]:
            return proposal
        if proposal["proposal_digest"] != expected_proposal_digest:
            raise ValueError("The proposed plan changed after its preview. Preview the current edits again.")
        if proposal["status"] == "closed":
            raise ValueError("A closed protocol accepts no new work. Start a new study plan with its scientific owner.")
        if proposal["status"] == "draft":
            if not proposal["passed"]:
                return {**proposal, "ok": False, "errors": proposal["checks"]}
            definitions._atomic(directory / "PROTOCOL.yaml", proposal["after"].encode())
            return {"ok": True, "changed": True, "errors": [], "draft_only": True, "approved": False,
                    "registration_checks": proposal["registration_checks"],
                    "next": "Complete all plan sections, then have the scientific owner review registration and its declared product/build scope."}
        _json_file(folder / ("protocol-" + study + ".json"), {"owner": owner, "pack": pack, "study": study,
                   "route": "study_protocol", "kind": "amendment_proposal", "base_digest": expected_digest,
                   "edits": edits, "before": proposal["before"], "after": proposal["after"],
                   "checks": proposal["checks"], "approved": False})
        return {"ok": True, "changed": True, "errors": [], "draft_only": True, "amendment_proposal": True,
                "next": "The frozen protocol is unchanged. Its scientific owner must record the amendment reason, named reviewer, date and digest chain before the changed plan is usable."}
    except OSError as error:
        return _fail(_plain_os_error(error, "save the protocol"))
    except (ValueError, TypeError, KeyError, RuntimeError, yaml.YAMLError) as error:
        return _fail(error)
    finally:
        if fd is not None:
            os.close(fd)
            lock.unlink(missing_ok=True)


def _entry_lines(entry, dash, keys, newline):
    """The registry lines for one work entry, in the layout the registry's own comment block
    documents, at the indentation of the entries already there. Every value is written as a
    quoted string so an identifier or cut made of digits can never be read back as a number."""
    pad = " " * keys
    lines = [" " * dash + "- id: " + json.dumps(str(entry["id"]), ensure_ascii=False),
             pad + "kind: " + str(entry["kind"])]
    for field in ("title", "owner"):
        if field in entry:
            lines.append(pad + field + ": " + json.dumps(str(entry[field]), ensure_ascii=False))
    lines.append(pad + "cites_release:")
    for citation in entry["cites_release"]:
        lines.append(pad + "  - { " + ", ".join(f"{key}: {json.dumps(str(value), ensure_ascii=False)}"
                                                for key, value in citation.items()) + " }")
    return newline.join(lines) + newline


def _registry_with_entry(text, entry):
    """The registry text with one work entry appended under `work:`, every other byte intact.

    The registry is a commented document a person maintains, so it is never re-dumped: the
    `work:` key is located by the parser (its own comment block spells the key inside a comment,
    so a text search would land in the wrong place). A registry without the key gains it at the
    end of the file with the entry; an empty one (`[]`, `~` or a bare key) takes the entry on the
    lines below the key; a list already written one entry per line takes the entry after its last
    one, at the same indentation. A list written inline is refused in plain words. The result is
    parsed back and must equal the registry as read plus this one entry."""
    newline = "\r\n" if "\r\n" in text else "\n"
    doc = project_run._strict_yaml(text, "Product registry")
    if not isinstance(doc, dict):
        raise ValueError("The product registry must be a mapping before a study can be entered in it.")
    existing = doc.get("work")
    if existing is not None and not isinstance(existing, list):
        raise ValueError("The product registry's list of work entries is not a list. Repair it before registering.")
    if any(isinstance(w, dict) and str(w.get("id") or "") == str(entry["id"]) for w in existing or []):
        raise ValueError("The product registry already has an entry with this study's identifier.")
    tree = yaml.compose(text)
    pair = next(((key, value) for key, value in tree.value if key.value == "work"), None)
    edits = []
    if pair is None:
        lead = "" if not text or text.endswith("\n") else newline
        edits.append((len(text), len(text), lead + "work:" + newline + _entry_lines(entry, 2, 4, newline)))
    else:
        key, node = pair
        if isinstance(node, yaml.SequenceNode) and not node.flow_style and node.value:
            first = node.value[0]
            line_start = text.rfind("\n", 0, first.start_mark.index) + 1
            dash = max(text.rfind("-", line_start, first.start_mark.index) - line_start, 0)
            at = _line_end(text, _own_end(node))
            lead = "" if at == 0 or text[at - 1] == "\n" else newline
            edits.append((at, at, lead + _entry_lines(entry, dash, first.start_mark.column, newline)))
        elif (isinstance(node, yaml.SequenceNode) and node.flow_style and not node.value) or \
                (isinstance(node, yaml.ScalarNode) and node.tag.endswith(":null")):
            start, end = node.start_mark.index, node.end_mark.index
            if text[start:end].strip():
                while start > 0 and text[start - 1] == " ":
                    start -= 1
                edits.append((start, end, ""))
            at = _line_end(text, key.end_mark.index)
            lead = "" if at == 0 or text[at - 1] == "\n" else newline
            edits.append((at, at, lead + _entry_lines(entry, 2, 4, newline)))
        else:
            raise ValueError("The product registry's work entries are written inline. Lay them out one entry per line before registering from the portal.")
    after = text
    for start, end, fragment in sorted(edits, reverse=True):
        after = after[:start] + fragment + after[end:]
    expected = copy.deepcopy(doc)
    expected["work"] = list(existing or []) + [copy.deepcopy(entry)]
    if project_run._strict_yaml(after, "Product registry") != expected:
        raise ValueError("The product registry's structure could not be preserved.")
    return after


def _study_for_registration(base, study, allowed_packs):
    """The study's folder and pins, when its whole product scope lies within the person's access."""
    if not pg.safe_work_id(study)[0]:
        raise ValueError("Choose a valid study identifier.")
    directory = _safe(base / "work" / study)
    if not (directory / "PROTOCOL.yaml").is_file():
        raise ValueError("This study has no protocol record to register.")
    pins_doc, pins_error = study_pin.load(study, str(base))
    if pins_error:
        raise ValueError("The study's pins could not be read, so its product scope cannot be entered in the registry: " + pins_error)
    pins = [p for p in pins_doc.get("pins", []) if isinstance(p, dict)]
    packs = [str(p.get("product") or "") for p in pins if str(p.get("status") or "pinned") != "superseded"]
    if not packs:
        raise ValueError("Pin a product to this study on the Studies page before registering its protocol. "
                         "The registry entry cites the releases the study reads, and those come from its pins.")
    if any(p not in allowed_packs for p in packs) or study not in _study_ids(base, packs[0], allowed_packs):
        raise ValueError("This study is not bound to a product within your access.")
    for path in directory.rglob("*"):
        _safe(path)
    return directory, pins


def register_protocol(root, study, *, registered_by, registered_on, local_demo, can_review, allowed_packs):
    """Register a complete draft protocol from the portal (walk 2026-09-07, S-REG).

    A person could complete a plan here and then be sent to a terminal to register it. This is
    the act, with the protocol tool's own check as its gate. It refuses, before writing anything,
    unless the session is a local reviewing one, the typed name is a person and the typed date is
    a real day, and unless the tool refuses nothing for a rehearsal copy that carries exactly what
    the registration writes. What it writes: in the study's protocol, `status: registered`, the
    typed `registered_by` and `registered_date`, and both plan digests over `prespecified:` as it
    now stands (`registration_digest`, the plan AS REGISTERED, which never moves, and
    `prespecification_sha256`, which later moves only by amendment); in the product registry, the
    study's work entry citing the releases its pins name, only when no entry with that
    identifier exists. Each file is replaced whole or not at all, the registry's other bytes and
    comments are untouched, and a registry failure restores the protocol's draft. A plan that is
    not a draft is refused with its own registration named, and nothing is written."""
    lock = None
    fd = None
    try:
        if local_demo is not True or can_review is not True:
            raise ValueError("Registering a protocol is a reviewer's act in an authorized local editing session.")
        base = Path(root).resolve()
        directory, pins = _study_for_registration(base, study, allowed_packs)
        name, date = str(registered_by or "").strip(), str(registered_on or "").strip()
        if pg.unstated(name):
            raise ValueError("Type the name of the person registering this protocol.")
        not_person = pg.not_a_person(name)
        if not_person:
            raise ValueError("The name typed for this registration: " + not_person)
        bad_date = pg.bad_date(date)
        if bad_date:
            raise ValueError(f"The registration date {bad_date}.")
        lock = _safe(directory / PROTOCOL_LOCK)
        state = _lock_state(directory)
        if state["held"]:
            raise ValueError(_lock_message(state))
        try:
            fd = os.open(lock, os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o600)
        except FileExistsError:
            raise ValueError(_lock_message(_lock_state(directory))) from None
        path = directory / "PROTOCOL.yaml"
        before = _read(path)
        text = before.decode("utf-8")
        doc = project_run._strict_yaml(text, "Protocol")
        if not isinstance(doc, dict) or doc.get("protocol_id") != study:
            raise ValueError("The protocol identifier does not match this study.")
        status = str(doc.get("status") or "")
        if status != "draft":
            raise ValueError(f"This protocol is already {status}: registered on {doc.get('registered_date')} by "
                             f"{doc.get('registered_by')}. Nothing was changed; a registered plan changes only by amendment.")
        digest = protocol_record.prespecification_digest(doc)
        if not digest:
            raise ValueError("The protocol has no prespecified plan to freeze.")
        changes = {"status": "registered", "registered_by": name, "registered_date": date,
                   "registration_digest": digest, "prespecification_sha256": digest}
        after_doc = copy.deepcopy(doc)
        after_doc.update(changes)
        newline = "\r\n" if "\r\n" in text else "\n"
        after = text
        for start, end, fragment in sorted(_mapping_edits(text, yaml.compose(text), changes, newline), reverse=True):
            after = after[:start] + fragment + after[end:]
        if project_run._strict_yaml(after, "Registered protocol") != after_doc:
            raise ValueError("The protocol structure could not be preserved.")
        registry_path = _safe(base / "products/registry.yaml")
        registry_text = None
        if _registry_entry_for(base, study) is None:
            registry_text = _registry_with_entry(_read(registry_path).decode("utf-8"),
                                                 _work_entry(study, doc, _scope_from_pins(pins), name))
        checks = _record_checks(base, study, after, registry_text)
        if checks:
            return {"ok": False, "changed": False, "errors": checks}
        definitions._atomic(path, after.encode("utf-8"))
        if registry_text is not None:
            try:
                definitions._atomic(registry_path, registry_text.encode("utf-8"))
            except OSError as error:
                what = _plain_os_error(error, "enter the study in the product registry")
                try:
                    definitions._atomic(path, before)
                except OSError as second:
                    reason = getattr(second, "strerror", None) or type(second).__name__
                    raise ValueError(f"The portal could not enter the study in the product registry, and could not restore "
                                     f"the protocol draft afterwards: {reason}. The protocol says registered while the "
                                     f"registry has no entry for it; ask your data expert to reconcile the two.") from None
                raise ValueError(what + " The protocol draft was restored.") from None
        return {"ok": True, "changed": True, "errors": [], "registered_by": name, "registered_date": date,
                "digest": digest, "registry_entry_added": registry_text is not None,
                "next": "The plan is frozen as registered. From now on it changes only by an amendment that names "
                        "a person, a date, what changed and why. Analysis projects can be registered under it."}
    except OSError as error:
        return _fail(_plain_os_error(error, "register the protocol"))
    except (ValueError, TypeError, KeyError, RuntimeError, yaml.YAMLError) as error:
        return _fail(error)
    finally:
        if fd is not None:
            os.close(fd)
            lock.unlink(missing_ok=True)


def runs(root, pack, actor_id, study, *, allowed_packs):
    try:
        base, product, pack, _owner, _folder, directory, row = _study(root, pack, actor_id, study, allowed_packs)
        if row["kind"] != "project":
            raise ValueError("Select a registered analysis project. Protocols hold plans; project runs record the executed analysis and its outputs.")
        records = []
        for path in sorted((directory / "runs").glob("*.yaml"), reverse=True):
            doc = project_run._strict_yaml(_read(path).decode(), "Run record")
            if not isinstance(doc, dict) or doc.get("project") != study:
                raise ValueError("A run record names a different analysis project.")
            if not _citations_allowed(doc.get("cites_release") or [], allowed_packs):
                continue
            records.append({"path": path.relative_to(base).as_posix(), "record": doc})
        checks = project_run.run_errors(str(base), study)
        # The run recorder's real precondition (audit 2026-09-07, S-05): the project's protocol
        # is registered or amended, and every release the project cites is a published build
        # with a committed receipt. `ready` is that check's verdict, never a portal guess.
        return {"ok": True, "errors": [], "records": records, "checks": checks, "ready": not checks,
                "protocol": str(row["entry"].get("protocol") or ""),
                "digest": _study_digest(base, product, directory), "entry": row["entry"]}
    except (OSError, ValueError, TypeError, KeyError, SystemExit, yaml.YAMLError) as error:
        return _fail(error)


def record_run(root, pack, actor_id, study, parameters, environment, outputs, *, expected_digest,
               allowed_packs, local_demo, can_write, confirmed):
    try:
        _write_allowed(local_demo, can_write, confirmed)
        current = runs(root, pack, actor_id, study, allowed_packs=allowed_packs)
        if not current["ok"]:
            return current
        if current["digest"] != expected_digest:
            raise ValueError("The project, plan or product changed. Reload before attaching analysis evidence.")
        if not isinstance(parameters, dict) or not isinstance(outputs, dict) or not outputs:
            raise ValueError("Provide analysis parameters as a mapping and at least one named output artifact.")
        if any(not isinstance(k, str) or not re.fullmatch(r"[A-Za-z][A-Za-z0-9_-]{0,79}", k) or not isinstance(v, str)
               for k, v in outputs.items()):
            raise ValueError("Use short output names and explicitly supplied artifact paths.")
        path = project_run.record(str(Path(root).resolve()), study, parameters, environment, outputs)
        return {"ok": True, "changed": True, "errors": [], "path": path,
                "next": "Review the recorded output digests and their bound published build and protocol evidence."}
    except (OSError, ValueError, TypeError, KeyError, SystemExit, yaml.YAMLError) as error:
        return _fail(error)


def recent(root, pack, actor_id, *, allowed_packs):
    try:
        base, _product, pack, owner, folder = _scope(root, pack, actor_id, allowed_packs)
        available = _study_ids(base, pack, allowed_packs)
        items = []
        for path in folder.glob("carry-*.json"):
            doc = json.loads(_read(path))
            if doc.get("owner") == owner and doc.get("pack") == pack and doc.get("previous") in allowed_packs:
                for row in doc.get("staged") or []:
                    items.append({"id": "carried:" + row["item_id"], "route": "scientific_draft", "title": "Carried definition · " + row["variable_id"],
                                  "state": "draft", "summary": "Continue the row interpretation carried from " + doc["previous"] + "; no approval was transferred.",
                                  "params": {"item_id": row["item_id"]}, "updated_at": datetime.fromtimestamp(path.stat().st_mtime, timezone.utc).isoformat()})
        for path in folder.glob("protocol-*.json"):
            doc = json.loads(_read(path))
            if doc.get("owner") == owner and doc.get("pack") == pack and doc.get("study") in available:
                items.append({"id": _hash(str(path))[:16], "route": "study_protocol", "title": "Amendment proposal · " + doc["study"],
                              "state": "draft", "summary": "Frozen protocol remains unchanged; continue amendment review.",
                              "params": {"study": doc["study"]}, "updated_at": datetime.fromtimestamp(path.stat().st_mtime, timezone.utc).isoformat()})
        for study, row in available.items():
            path = base / "work" / study / "PROTOCOL.yaml"
            if path.exists():
                doc = project_run._strict_yaml(_read(path).decode(), "Protocol")
                items.append({"id": "protocol:" + study, "route": "study_protocol", "title": "Protocol · " + study,
                              "state": doc.get("status", "unknown"), "summary": "Continue the study plan and review its product scope.",
                              "params": {"study": study}, "updated_at": datetime.fromtimestamp(path.stat().st_mtime, timezone.utc).isoformat()})
        return items
    except (OSError, ValueError, TypeError, KeyError, SystemExit, yaml.YAMLError):
        return []


if __name__ == "__main__":
    if len(sys.argv) == 4 and sys.argv[1] == "--impact":
        import change_impact
        change_impact.REPO = sys.argv[2]  # isolated worker process, never a shared UI module
        print(json.dumps(change_impact.impact(sys.argv[3], json.load(sys.stdin))))
