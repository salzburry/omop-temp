"""Check explicit scientific declarations without choosing the reviewer's answers.

These issues keep a shared review draft incomplete. They neither validate engine
execution nor prevent an unfinished draft from being saved.
"""
from __future__ import annotations

import re


_TYPE_FIELDS = {"data_type", "datatype", "output_type", "type"}
_EMPTY = {"", "todo", "tbd", "replace_me", "none", "null", "n/a", "undecided"}
_ALIASES = {
    "string": "string", "text": "string", "str": "string",
    "integer": "integer", "int": "integer", "whole number": "integer",
    "long": "integer", "bigint": "integer", "large whole number": "integer",
    "double": "decimal", "float": "decimal", "decimal": "decimal", "decimal number": "decimal",
    "boolean": "boolean", "bool": "boolean",
    "date": "date",
    "timestamp": "timestamp", "datetime": "timestamp", "date and time": "timestamp",
}
_LABELS = {"string": "Text", "integer": "Whole number", "decimal": "Decimal number",
           "boolean": "Yes / no", "date": "Date", "timestamp": "Date and time"}


def _text(value):
    return value.strip() if isinstance(value, str) else ""


def _type(value):
    # Exact type names only: neither a date value nor prose about dates is a
    # datatype declaration. Yes/No categories do not establish their storage.
    return _ALIASES.get(re.sub(r"\s+", " ", _text(value).casefold()))


def canonical_type(value):
    """Canonical type for an exact declaration, never a parsed example value."""
    declared = _type(value)
    if declared == "integer" and _text(value).casefold() in {"long", "bigint", "large whole number"}:
        return "long"
    return "double" if declared == "decimal" else declared


value_type = canonical_type


def _declarations(row):
    fields = row.get("spec_values") or row.get("spec_fields") or {}
    if not isinstance(fields, dict):
        return []
    declared = []
    for key, value in fields.items():
        name = re.sub(r"[\s-]+", "_", str(key).strip().casefold())
        datatype = _type(value)
        if datatype and name in _TYPE_FIELDS | {"value", "values"}:
            declared.append((name, _text(value), datatype))
    return declared


def issues(row):
    """Return correctable contradictions from the row's explicit declarations.

    Missing general scientific answers are checked by the owning workflow.
    Custom types stay editable drafts, but cannot claim an executable logical
    type until the reviewer chooses one supported by the source adapter.
    """
    values = row.get("values") or {}
    output = values.get("output") or {}
    selected = _text(output.get("type"))
    selected_type = _type(selected)
    declarations = _declarations(row)
    declared_types = {datatype for _name, _value, datatype in declarations}
    problems = []
    if selected.casefold() not in _EMPTY and not canonical_type(selected):
        problems.append(f"Data type '{selected}' is not a supported logical type. Choose Text, Whole number, "
                        "Large whole number, Decimal number, Yes / no, Date or Date and time. "
                        "Keep special storage requirements in Review notes for the data expert.")
    if len(declared_types) > 1:
        displayed = ", ".join(f"{name}: {value}" for name, value, _datatype in declarations)
        problems.append("The specification has conflicting data type declarations (" + displayed
                        + "). Correct these declarations in Specification before finalizing this variable.")
    elif selected_type and declared_types and selected_type not in declared_types:
        name, declared, datatype = declarations[0]
        problems.append(f"The specification declares {declared} ({name}), but Data type is {selected}. "
                        f"Choose {_LABELS[datatype]} in Data type, or correct the declaration in Specification.")
    source = values.get("source") or {}
    if source.get("kind") == "constant":
        value = source.get("value")
        if value is None or isinstance(value, str) and value.strip().casefold() in _EMPTY:
            problems.append("Fixed value is selected. Enter the Value for this product, or choose the variable kind that supplies this value.")
    return problems


def _identifier(value):
    value = _text(value).strip('"\'`').casefold()
    return value if value not in _EMPTY else ""


def _output_names(row, path):
    # Match the canonical contract's compound physical-name notation.
    output = (row.get("values") or {}).get("output") or {}
    return {_identifier(name) for name in _text(output.get(path)).split("/")} - {""}


def _destinations(row):
    publish = (row.get("values") or {}).get("publish") or {}
    return {name for name in ("ads", "dictionary", "dashboard", "tfl")
            if publish.get(name) in {"proposed", "required", "configured"}}


def _local_target(row):
    values = row.get("values") or {}
    source = values.get("source") or {}
    grain = _identifier(values.get("grain"))
    table = _identifier(source.get("logical_table")) or _identifier(source.get("physical_stem"))
    # A source-local field can share a spelling with a field in another source
    # or grain. Unknown scope is not proof of a collision.
    return (grain, table) if grain and table else None


def report_issues(rows):
    """Output-name collisions, keyed by item_id; input rows are never changed.

    A published ADS has one namespace even when its inputs have different
    grains. Names used only in source-local/internal rows are compared only
    within a known common grain and logical source. Shared source columns do
    not collide when their derived output names differ (LOT1 / LOT2).
    """
    findings = {}
    active = [row for row in rows if ((row.get("values") or {}).get("output") or {}).get("role")
              in {"published", "internal", "metadata"}]
    for position, left in enumerate(active):
        for right in active[position + 1:]:
            if left.get("item_id") == right.get("item_id"):
                continue
            overlap = _destinations(left) & _destinations(right)
            shared_ads = "ads" in overlap
            left_scope, right_scope = _local_target(left), _local_target(right)
            local_match = left_scope is not None and left_scope == right_scope
            for path, label in (("physical_name", "Physical output name"),
                                ("target_published_name", "Published variable name")):
                if path == "target_published_name":
                    if not overlap or any(((row.get("values") or {}).get("output") or {}).get("role")
                                          != "published" for row in (left, right)):
                        continue
                elif not shared_ads and not local_match:
                    continue
                for name in sorted(_output_names(left, path) & _output_names(right, path)):
                    for row, other in ((left, right), (right, left)):
                        other_label = other.get("variable_id") or other["item_id"]
                        scope = "the ADS" if shared_ads else (", ".join(sorted(overlap)) if path == "target_published_name" else "the same source and grain")
                        findings.setdefault(row["item_id"], []).append(
                            f"{label} '{name}' is also used by {other_label} in {scope}. "
                            "Choose distinct output names, or resolve the duplicate requirement in Specification.")
    return findings
