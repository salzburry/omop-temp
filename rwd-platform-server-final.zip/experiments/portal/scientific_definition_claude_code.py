"""Bounded local requests through the user's unmodified, signed-in Claude Code.

Authentication belongs to the CLI. This adapter never opens a credential file,
extracts a token, starts sign-in, or shares a Claude account with another user.
"""
from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import tempfile
import threading
import time

MAX_CONTEXT_BYTES = 18_000
MAX_REPLY_BYTES = 24_000
MAX_ENVELOPE_BYTES = 64_000
MAX_STDERR_BYTES = 8_000
MAX_OUTPUT_TOKENS = 2_000
TIMEOUT_SECONDS = 40
HEALTH_TIMEOUT_SECONDS = 5
MINIMUM_VERSION = (2, 1, 246)
DEFAULT_MODEL = "claude-sonnet-4-6"
HELP = ("Use your own local Claude Code sign-in. Install Claude Code from Anthropic, run claude auth login "
        "in your terminal if needed, and select this provider in the local portal. Opening Streamlit from "
        "VS Code is optional; this uses the installed CLI, not an extension conversation. No API key is required.")
QUOTA_NOTE = ("Requests use the account signed into your local Claude Code. Access, subscription limits and any "
              "account-enabled extra usage remain controlled by Anthropic. The portal does not estimate a USD cost or enable extra usage.")
ERRORS = {
    "local_only": "Claude Code drafting is available only in an authorized local demo session. Continue manually in shared deployments.",
    "cli_missing": "Claude Code is not installed as a local executable. Install it from Anthropic and sign in through claude auth login, then retry explicitly.",
    "cli_invalid": "The configured Claude Code executable is unsupported. Select the installed native executable outside the product checkout; shell wrappers are not supported.",
    "cli_version": "Update Claude Code through its official installer before using this local drafting connection.",
    "cli_version_timeout": "Claude Code did not finish its local version check within 5 seconds and was stopped. Run claude --version in the terminal to check startup, then retry Check connection. Model access has not been checked.",
    "auth_status_timeout": "Claude Code did not finish checking local sign-in metadata within the remaining time and was stopped. Run claude auth status --json in the terminal; if it reports that you are signed out, run claude auth login, then retry explicitly. Do not paste account details into chat. Model access is not confirmed.",
    "auth_status_unreadable": "Claude Code returned incomplete or unsupported sign-in metadata. Run claude auth status --json in the terminal to check the CLI, then retry explicitly. Do not paste account details into chat. This does not establish that you are signed out or have model access.",
    "not_signed_in": "Claude Code sign-in is missing, expired or was rejected. Run claude auth login in your terminal to sign in again, then retry explicitly; no API key is required.",
    "access_denied": "Claude Code denied this model request. Check your Claude account and model access; a saved sign-in alone does not confirm permission. No provider fallback was used.",
    "subscription_required": "This connection requires your own Claude subscription sign-in. API keys, gateways and cloud-provider credentials are not used as a fallback.",
    "managed_policy": "This local connection cannot isolate the active Claude Code managed policy or credential-helper settings. Use the configured VS Code/API provider or continue manually; no policy was changed.",
    "connection_changed": "The local Claude Code account, executable or selected model changed. Request fresh suggestions before copying an answer.",
    "model_unavailable": "The selected Claude Code model is unavailable or unsupported. Choose an accessible full Claude Sonnet model identifier and retry explicitly.",
    "invalid_request": "Claude Code drafting accepts one bounded text request without tools or conversation history.",
    "request_too_large": "The selected question and working answer exceed the Claude Code drafting limit. Shorten them or continue manually.",
    "response_too_large": "Claude Code exceeded the bounded response limit. Nothing was copied or saved.",
    "unsupported_response": "Claude Code returned unsupported or incomplete output. Only a completed text response from the selected model can be used.",
    "timeout": "The local Claude Code request timed out and was stopped. No suggestions were saved; retry explicitly when it is available.",
    "quota": "Claude Code reported a usage or billing limit. Check your Claude account usage before retrying; no provider fallback or extra usage was enabled.",
    "provider_error": "Claude Code could not complete this request. Check its local sign-in and model access, then retry explicitly; no draft was saved.",
}
_SETTINGS = json.dumps({"disableAllHooks": True, "autoMemoryEnabled": False, "disableClaudeAiConnectors": True,
                       "syncClaudeAiSkills": False, "enableArtifact": False, "fastMode": False,
                       "fallbackModel": [], "remoteControlAtStartup": False}, separators=(",", ":"))


class ClaudeCodeError(ValueError):
    def __init__(self, code):
        self.code = code if code in ERRORS else "provider_error"
        super().__init__(ERRORS[self.code])


def _json(raw):
    def pairs(items):
        result = {}
        for key, value in items:
            if key in result:
                raise ValueError("duplicate")
            result[key] = value
        return result
    return json.loads(raw, object_pairs_hook=pairs,
                      parse_constant=lambda _value: (_ for _ in ()).throw(ValueError("nonfinite")))


def _hash(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, ensure_ascii=False,
                                     separators=(",", ":")).encode("utf-8")).hexdigest()


def _environment():
    # Preserve only ordinary OS runtime variables. Do not forward provider keys,
    # OAuth overrides, API endpoints, editor context, cloud credentials, proxy
    # credentials, telemetry exporters, or instructions from the parent process.
    allowed = {"SYSTEMROOT", "WINDIR", "COMSPEC", "PATH", "PATHEXT", "USERPROFILE", "HOME", "HOMEDRIVE", "HOMEPATH",
               "APPDATA", "LOCALAPPDATA", "PROGRAMDATA", "PROGRAMFILES", "PROGRAMFILES(X86)", "TEMP", "TMP",
               "TMPDIR", "LANG", "LC_ALL", "LC_CTYPE", "SHELL", "XDG_CONFIG_HOME", "XDG_RUNTIME_DIR"}
    env = {key: value for key, value in os.environ.items() if key.upper() in allowed}
    env.update({"CLAUDE_CODE_SAFE_MODE": "1", "CLAUDE_CODE_DISABLE_NONESSENTIAL_TRAFFIC": "1",
                "CLAUDE_CODE_DISABLE_OFFICIAL_MARKETPLACE_AUTOINSTALL": "1", "CLAUDE_CODE_DISABLE_CLAUDE_MDS": "1",
                "CLAUDE_CODE_DISABLE_TERMINAL_TITLE": "1", "CLAUDE_CODE_DISABLE_FAST_MODE": "1",
                "CLAUDE_CODE_DISABLE_NONSTREAMING_FALLBACK": "1", "CLAUDE_CODE_SKIP_PROMPT_HISTORY": "1",
                "CLAUDE_CODE_ENABLE_PROMPT_SUGGESTION": "false", "CLAUDE_CODE_MAX_RETRIES": "0",
                "CLAUDE_CODE_MAX_OUTPUT_TOKENS": str(MAX_OUTPUT_TOKENS), "MAX_THINKING_TOKENS": "0",
                "API_TIMEOUT_MS": str(TIMEOUT_SECONDS * 1000), "DISABLE_AUTO_COMPACT": "1",
                "DISABLE_EXTRA_USAGE_COMMAND": "1", "NO_COLOR": "1"})
    return env


def _executable(root):
    configured = os.environ.get("RWD_PORTAL_CLAUDE_CODE_EXE")
    candidate = configured or shutil.which("claude")
    if not candidate:
        raise ClaudeCodeError("cli_missing")
    path = Path(candidate)
    try:
        if not path.is_absolute() or not path.is_file():
            raise ClaudeCodeError("cli_invalid")
        path = path.resolve(strict=True)
        if path.is_relative_to(root) or (os.name == "nt" and path.suffix.lower() != ".exe"):
            raise ClaudeCodeError("cli_invalid")
        return path
    except (OSError, ValueError):
        raise ClaudeCodeError("cli_invalid") from None


def _settings_file(path):
    if not path.exists():
        return {}
    try:
        if path.is_symlink() or path.resolve() != path.absolute() or not path.is_file() or path.stat().st_size > 64_000:
            raise ValueError()
        with path.open("rb") as handle:
            raw = handle.read(64_001)
        if len(raw) > 64_000:
            raise ValueError()
        result = _json(raw)
        if not isinstance(result, dict):
            raise ValueError()
        return result
    except (OSError, ValueError, TypeError):
        raise ClaudeCodeError("managed_policy") from None


def _managed_paths():
    if os.name == "nt":
        base = Path(os.environ.get("ProgramFiles", r"C:\Program Files")) / "ClaudeCode"
    elif sys_platform() == "darwin":
        base = Path("/Library/Application Support/ClaudeCode")
    else:
        base = Path("/etc/claude-code")
    paths = [base / "managed-settings.json", base / "managed-mcp.json", Path.home() / ".claude/remote-settings.json"]
    dropins = base / "managed-settings.d"
    if dropins.exists():
        paths.extend(dropins.glob("*.json"))
    return paths


def sys_platform():
    import sys
    return sys.platform


def _registry_policy_exists():
    if os.name != "nt":
        return False
    import winreg
    for hive in (winreg.HKEY_LOCAL_MACHINE, winreg.HKEY_CURRENT_USER):
        for view in (winreg.KEY_WOW64_64KEY, winreg.KEY_WOW64_32KEY):
            try:
                with winreg.OpenKey(hive, r"SOFTWARE\Policies\ClaudeCode", 0, winreg.KEY_READ | view):
                    return True
            except FileNotFoundError:
                continue
            except OSError:
                raise ClaudeCodeError("managed_policy") from None
    return False


def _policy_identity():
    # These are ordinary configuration/policy files, never .claude.json,
    # .credentials.json, keychains, or any other authentication storage.
    try:
        if _registry_policy_exists():
            raise ClaudeCodeError("managed_policy")
        if sys_platform() == "darwin":
            # The first slice does not interpret macOS managed preference plists.
            preferences = [Path("/Library/Managed Preferences/com.anthropic.claudecode.plist"),
                           Path.home() / "Library/Preferences/com.anthropic.claudecode.plist"]
            if any(path.exists() for path in preferences):
                raise ClaudeCodeError("managed_policy")
        if any(_settings_file(path) for path in _managed_paths()):
            raise ClaudeCodeError("managed_policy")
        settings = _settings_file(Path.home() / ".claude/settings.json")
        if any(settings.get(key) for key in ("apiKeyHelper", "env", "otelHeadersHelper", "awsAuthRefresh", "awsCredentialExport")):
            raise ClaudeCodeError("managed_policy")
        return _hash(settings)
    except ClaudeCodeError:
        raise
    except OSError:
        raise ClaudeCodeError("managed_policy") from None


class _ProcessTree:
    """Keep the bridge's existing error codes around the shared OS lifetime."""
    def __init__(self):
        from process_lifetime import ProcessTree
        try:
            self._tree = ProcessTree()
        except OSError:
            raise ClaudeCodeError("provider_error") from None

    def attach(self, process):
        try:
            self._tree.attach(process)
        except OSError:
            raise ClaudeCodeError("provider_error") from None

    def close(self):
        self._tree.close()


def _remaining(deadline, maximum):
    remaining = deadline - time.monotonic()
    if remaining <= 0:
        raise ClaudeCodeError("timeout")
    return min(maximum, remaining)


def _run(executable, args, *, payload=b"", timeout=HEALTH_TIMEOUT_SECONDS, maximum=MAX_ENVELOPE_BYTES):
    """Drain bounded pipes concurrently; kill the process on timeout or overflow."""
    process = None
    tree = None
    threads = []
    overflow = threading.Event()
    stdout = bytearray()
    deadline = time.monotonic() + timeout
    try:
        temporary_root = Path(tempfile.gettempdir()).resolve()
        with tempfile.TemporaryDirectory(prefix="rwd-claude-request-", dir=str(temporary_root)) as folder:
            if not Path(folder).resolve().is_relative_to(temporary_root):
                raise ClaudeCodeError("cli_invalid")
            tree = _ProcessTree()
            process = subprocess.Popen([str(executable), *args], stdin=subprocess.PIPE, stdout=subprocess.PIPE,
                                       stderr=subprocess.PIPE, cwd=folder, env=_environment(), shell=False,
                                       creationflags=subprocess.CREATE_NO_WINDOW if os.name == "nt" else 0,
                                       start_new_session=os.name != "nt")
            tree.attach(process)
            def drain(stream, limit, destination=None):
                count = 0
                try:
                    while True:
                        chunk = stream.read1(min(4096, limit + 1 - count))
                        if not chunk:
                            break
                        count += len(chunk)
                        if count > limit:
                            overflow.set()
                            process.kill()
                            break
                        if destination is not None:
                            destination.extend(chunk)
                except (OSError, ValueError):
                    pass
            for stream, limit, destination in ((process.stdout, maximum, stdout), (process.stderr, MAX_STDERR_BYTES, None)):
                thread = threading.Thread(target=drain, args=(stream, limit, destination), daemon=True)
                thread.start()
                threads.append(thread)
            def write_input():
                try:
                    process.stdin.write(payload)
                except (BrokenPipeError, OSError, ValueError):
                    pass
                finally:
                    try:
                        process.stdin.close()
                    except OSError:
                        pass
            writer = threading.Thread(target=write_input, daemon=True)
            writer.start()
            threads.append(writer)
            try:
                code = process.wait(timeout=_remaining(deadline, timeout))
            except subprocess.TimeoutExpired:
                tree.close()
                process.wait(timeout=2)
                raise ClaudeCodeError("timeout") from None
            tree.close()
            for thread in threads:
                # A finished process may still have buffered output waiting for
                # its reader on a busy laptop. Drain within the same deadline;
                # a separate 200 ms cap falsely timed out successful commands.
                thread.join(timeout=max(0, deadline - time.monotonic()))
            if overflow.is_set():
                raise ClaudeCodeError("response_too_large")
            if any(thread.is_alive() for thread in threads):
                raise ClaudeCodeError("timeout")
            return code, bytes(stdout)
    except ClaudeCodeError:
        raise
    except (OSError, ValueError, subprocess.SubprocessError):
        raise ClaudeCodeError("provider_error") from None
    finally:
        if tree is not None:
            tree.close()
        if process is not None:
            if process.poll() is None:
                process.kill()
                process.wait(timeout=2)
            for stream in (process.stdin, process.stdout, process.stderr):
                if stream is not None:
                    stream.close()


def _status(executable, *, timeout=HEALTH_TIMEOUT_SECONDS):
    try:
        code, raw = _run(executable, ["auth", "status", "--json"], maximum=8_000, timeout=timeout)
    except ClaudeCodeError as error:
        if error.code == "timeout":
            raise ClaudeCodeError("auth_status_timeout") from None
        raise
    try:
        value = _json(raw)
        if not isinstance(value, dict):
            raise ValueError()
        if value.get("loggedIn") is False:
            raise ClaudeCodeError("not_signed_in")
        if value.get("loggedIn") is not True:
            raise ValueError()
        if code != 0 or value.get("authMethod") != "claude.ai" or value.get("apiProvider") != "firstParty":
            raise ClaudeCodeError("subscription_required")
        identity = {key: value.get(key) for key in ("email", "orgId", "subscriptionType")}
        if (not identity["email"] or any(not isinstance(item, str) or len(item) > 320 or
                                         any(not char.isprintable() for char in item) for item in identity.values())):
            raise ValueError()
        if identity["subscriptionType"] in ("team", "enterprise"):
            raise ClaudeCodeError("managed_policy")
        if identity["subscriptionType"] not in ("pro", "max"):
            raise ClaudeCodeError("subscription_required")
        return _hash(identity)
    except ClaudeCodeError:
        raise
    except (ValueError, TypeError):
        raise ClaudeCodeError("auth_status_unreadable") from None


class ClaudeCodeModel:
    def __init__(self, root, *, local_demo=False):
        if local_demo is not True:
            raise ClaudeCodeError("local_only")
        self.root = Path(root).resolve()
        self._policy = _policy_identity()
        self._executable = _executable(self.root)
        self.model = os.environ.get("RWD_PORTAL_CLAUDE_CODE_MODEL", DEFAULT_MODEL)
        if not re.fullmatch(r"claude-sonnet-\d+(?:-\d+)?(?:-20\d{6})?", self.model):
            raise ClaudeCodeError("model_unavailable")
        try:
            code, raw = _run(self._executable, ["--version"], maximum=200)
        except ClaudeCodeError as error:
            if error.code == "timeout":
                raise ClaudeCodeError("cli_version_timeout") from None
            raise
        match = re.fullmatch(rb"(\d+)\.(\d+)\.(\d+) \(Claude Code\)\s*", raw)
        if code != 0 or not match or tuple(map(int, match.groups())) < MINIMUM_VERSION:
            raise ClaudeCodeError("cli_version")
        self._version = ".".join(part.decode("ascii") for part in match.groups())
        self.model_info = {"id": self.model, "name": "Claude Sonnet · local Claude Code", "family": "sonnet",
                           "vendor": "Anthropic", "version": ""}
        self._identity = _status(self._executable)
        self.connection_id = self._connection()

    def _connection(self):
        try:
            stat = self._executable.stat()
            return _hash({"root": str(self.root), "executable": str(self._executable), "size": stat.st_size,
                          "modified": stat.st_mtime_ns, "version": self._version, "model": self.model,
                          "identity": self._identity, "policy": self._policy})
        except OSError:
            raise ClaudeCodeError("connection_changed") from None

    def _fresh(self, *, deadline=None):
        if (_policy_identity() != self._policy or _executable(self.root) != self._executable or
                os.environ.get("RWD_PORTAL_CLAUDE_CODE_MODEL", DEFAULT_MODEL) != self.model or
                _status(self._executable, timeout=_remaining(deadline, HEALTH_TIMEOUT_SECONDS) if deadline is not None else HEALTH_TIMEOUT_SECONDS) != self._identity or
                self._connection() != self.connection_id):
            raise ClaudeCodeError("connection_changed")

    def health(self):
        self._fresh()
        return self.model_info.copy()

    def step(self, system, transcript, tools=None):
        # Reserve two seconds to reap a stopped native process. The preflight,
        # generation and postflight share this one deadline under the portal's
        # outer request timeout; none receives a new full request window.
        deadline = time.monotonic() + TIMEOUT_SECONDS - 2
        if (tools or not isinstance(system, str) or not isinstance(transcript, list) or len(transcript) != 1 or
                not isinstance(transcript[0], dict) or set(transcript[0]) != {"role", "content"} or
                transcript[0]["role"] != "user" or not isinstance(transcript[0]["content"], str)):
            raise ClaudeCodeError("invalid_request")
        payload = transcript[0]["content"].encode("utf-8")
        if len(system.encode("utf-8")) + len(payload) > MAX_CONTEXT_BYTES:
            raise ClaudeCodeError("request_too_large")
        self._fresh(deadline=deadline)
        args = ["-p", "--safe-mode", "--setting-sources", "", "--settings", _SETTINGS,
                "--tools", "", "--disallowedTools", "mcp__*", "--strict-mcp-config", "--mcp-config", '{"mcpServers":{}}',
                "--disable-slash-commands", "--no-chrome", "--no-session-persistence", "--permission-mode", "dontAsk",
                "--max-turns", "1", "--output-format", "json", "--model", self.model,
                "--effort", "low", "--system-prompt", system]
        code, raw = _run(self._executable, args, payload=payload, timeout=_remaining(deadline, TIMEOUT_SECONDS))
        try:
            result = _json(raw)
            if not isinstance(result, dict):
                raise ValueError()
            if result.get("api_error_status") == 401:
                raise ClaudeCodeError("not_signed_in")
            if result.get("api_error_status") == 403:
                raise ClaudeCodeError("access_denied")
            if result.get("api_error_status") in (402, 429) or result.get("subtype") == "error_max_budget_usd":
                raise ClaudeCodeError("quota")
            if result.get("api_error_status") == 404:
                raise ClaudeCodeError("model_unavailable")
            if (code != 0 or result.get("type") != "result" or result.get("subtype") != "success" or
                    result.get("is_error") is not False):
                diagnostic = result.get("result")
                if isinstance(diagnostic, str) and re.search(
                        r"\boauth\b[^\r\n]{0,160}\bexpired\b|\bexpired\b[^\r\n]{0,160}\boauth\b", diagnostic, re.I):
                    raise ClaudeCodeError("not_signed_in")
                if isinstance(diagnostic, str) and re.search(r"rate.?limit|usage limit|quota|billing|credit balance", diagnostic, re.I):
                    raise ClaudeCodeError("quota")
                raise ClaudeCodeError("provider_error")
            if (type(result.get("num_turns")) is not int or result["num_turns"] != 1 or result.get("permission_denials") != [] or
                    result.get("stop_reason") not in ("end_turn", "stop_sequence") or
                    result.get("terminal_reason", "completed") != "completed" or
                    any(key in result for key in ("deferred_tool_use", "tool_calls", "structured_output"))):
                raise ValueError()
            models = result.get("modelUsage")
            if not isinstance(models, dict) or set(models) != {self.model}:
                raise ClaudeCodeError("model_unavailable")
            usage = models[self.model]
            if (not isinstance(usage, dict) or type(usage.get("outputTokens")) is not int or
                    not 0 < usage["outputTokens"] <= MAX_OUTPUT_TOKENS or usage.get("webSearchRequests", 0) != 0):
                raise ValueError()
            text = result.get("result")
            if not isinstance(text, str) or not text.strip():
                raise ValueError()
            if len(text.encode("utf-8")) > MAX_REPLY_BYTES:
                raise ClaudeCodeError("response_too_large")
        except ClaudeCodeError:
            raise
        except (ValueError, TypeError):
            raise ClaudeCodeError("unsupported_response") from None
        self._fresh(deadline=deadline)
        _remaining(deadline, TIMEOUT_SECONDS)
        return text


def describe_connection(root, *, local_demo=False, health=True):
    instance = ClaudeCodeModel(root, local_demo=local_demo)
    # Construction just checked version and sign-in. Keep the public health
    # argument for callers, without immediately launching auth status again.
    # Existing instances still use health/_fresh before and after each request.
    return {"configured": True, "provider": "Claude Code", "provider_id": "claude_code", "model": instance.model,
            "model_info": instance.model_info.copy(), "connection_id": instance.connection_id,
            "instance": instance, "help": HELP, "quota_note": QUOTA_NOTE}
