"""Settle a record's requirement: the scientific owner's word that the record asks for the right thing.

The contract's status cell reads `{requirement: draft, ...}` until a person settles it to `approved`;
no tool writes that word (contract_record refuses it), and until 2026-09-07 no portal act did either,
so the person edited the contract by hand. This module makes the act a form: it lists the records
that are eligible (requirement `draft`, not waiting on a decision), and rewrites exactly the chosen
rows' status cells, one word each, under a lock and an expected digest, verifying afterwards that
the contract still parses to the same records and that nothing else changed. It never approves the
contract (the approval form does that), never signs, never touches another axis.
"""
from __future__ import annotations

import hashlib
import os
import re
import tempfile
import time
from pathlib import Path

import contract_lint

LOCK_NAME = "handoff/.requirement-settle.portal.lock"
LOCK_STALE_SECONDS = 10 * 60
CONTRACT = "handoff/FUNCTIONAL_CONTRACT.md"
_ID = re.compile(r"^variable_id:\s*(\S+)\s*$", re.M)
_REQ = re.compile(r"requirement:\s*([A-Za-z_]+)")
_STATUS_LINE = re.compile(r"^status:\s*(\{.*\})\s*$", re.M)


class Refused(Exception):
    """Nothing was written; the message says why in the person's words."""


def _paths(root, pack, allowed_packs):
    text = str(pack or "").replace("\\", "/").strip("/")
    if not text or ".." in text.split("/"):
        raise Refused("Choose a product first.")
    if allowed_packs is not None and text not in {str(p).replace("\\", "/").strip("/") for p in allowed_packs}:
        raise Refused("This product is outside your access.")
    product = Path(root).resolve() / text
    if product.resolve() != product or not product.is_dir():
        raise Refused("The product location is unavailable.")
    contract = product / CONTRACT
    if contract.exists() and contract.resolve() != contract:
        raise Refused("The contract redirects to another location. Ask your data expert to repair it.")
    if not contract.is_file():
        raise Refused("This product has no contract yet. Draft the definitions first.")
    return product, contract, text


def _digest(raw):
    return hashlib.sha256(raw).hexdigest()


def _records(text):
    rows = []
    for block in contract_lint.records(text):
        m = _ID.search(block)
        if not m:
            continue
        status = _STATUS_LINE.search(block)
        req = _REQ.search(status.group(1)) if status else None
        rows.append({"id": m.group(1), "requirement": req.group(1) if req else "", "status": status.group(1) if status else ""})
    return rows


def describe(root, pack, allowed_packs=None):
    """The records and which of them a person may settle now. Read-only."""
    try:
        _product, contract, _text = _paths(root, pack, allowed_packs)
        raw = contract.read_bytes()
        rows = _records(raw.decode("utf-8"))
    except Refused as error:
        return {"ok": False, "errors": [str(error)], "records": [], "eligible": [], "digest": ""}
    except (OSError, UnicodeDecodeError) as error:
        return {"ok": False, "errors": ["The contract could not be read. " + type(error).__name__], "records": [], "eligible": [], "digest": ""}
    for row in rows:
        req = row["requirement"]
        row["eligible"] = req == "draft"
        row["why"] = ("" if req == "draft" else
                      "already settled" if req == "approved" else
                      "waiting on a scientific decision; answer it and re-check the record first" if req == "decision_required" else
                      f"requirement is {req or 'not stated'}")
    return {"ok": True, "errors": [], "records": rows, "eligible": [r["id"] for r in rows if r["eligible"]],
            "digest": _digest(raw), "counts": {"approved": sum(1 for r in rows if r["requirement"] == "approved"), "total": len(rows)}}


def _row_line(line, record_id):
    cells = line.split("|")
    return len(cells) > 2 and cells[1].strip() == record_id


def _settled_text(text, ids):
    lines = text.split("\n")
    changed = 0
    for i, line in enumerate(lines):
        if not line.startswith("|"):
            continue
        for record_id in ids:
            if _row_line(line, record_id) and "{requirement: draft," in line:
                lines[i] = line.replace("{requirement: draft,", "{requirement: approved,", 1)
                changed += 1
                break
    return "\n".join(lines), changed


def settle(root, pack, ids, *, expected_digest, local_demo, can_settle, confirmed, allowed_packs=None):
    """Settle the chosen records' requirement to approved. Refuses before writing; verifies after."""
    if not local_demo:
        raise Refused("Settling a requirement is done on the person's own checkout in this version.")
    if not can_settle:
        raise Refused("Settling a requirement is the scientific owner's act; your role cannot record it.")
    if not confirmed:
        raise Refused("Tick the confirmation first: the requirement is your word that each record asks for the right thing.")
    ids = [str(i).strip() for i in (ids or []) if str(i).strip()]
    if not ids:
        raise Refused("Choose at least one record to settle.")
    if len(set(ids)) != len(ids):
        raise Refused("A record is listed twice.")
    product, contract, _text = _paths(root, pack, allowed_packs)
    lock = product / LOCK_NAME
    try:
        handle = os.open(lock, os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o600)
        os.close(handle)
    except FileExistsError as error:
        try:
            age = time.time() - lock.stat().st_mtime
        except OSError:
            age = None
        if age is not None and age > LOCK_STALE_SECONDS:
            raise Refused("An earlier save stopped and left its lock behind. Ask your data expert to remove "
                          "handoff/.requirement-settle.portal.lock, then try again.") from error
        raise Refused("Another save is in progress. Wait for it to finish, then try again.") from error
    try:
        raw = contract.read_bytes()
        if _digest(raw) != str(expected_digest or ""):
            raise Refused("The contract changed since this page was opened. Reload the page and choose again.")
        text = raw.decode("utf-8")
        before = _records(text)
        by_id = {r["id"]: r for r in before}
        unknown = [i for i in ids if i not in by_id]
        if unknown:
            raise Refused("Not in the contract: " + ", ".join(unknown[:10]))
        blocked = [i for i in ids if by_id[i]["requirement"] != "draft"]
        if blocked:
            raise Refused("Cannot settle: " + "; ".join(f"{i} ({'already settled' if by_id[i]['requirement'] == 'approved' else by_id[i]['requirement'] or 'no requirement'})" for i in blocked[:10]))
        new_text, changed = _settled_text(text, ids)
        if changed != len(ids):
            raise Refused("A chosen record's row could not be found in the contract table. Nothing was written.")
        after = _records(new_text)
        if [r["id"] for r in after] != [r["id"] for r in before]:
            raise Refused("The edit would change the set of records. Nothing was written.")
        for old, new in zip(before, after):
            if old["id"] in ids:
                if new["requirement"] != "approved" or new["status"] != old["status"].replace("{requirement: draft,", "{requirement: approved,", 1):
                    raise Refused(f"The edit to {old['id']} would change more than the requirement word. Nothing was written.")
            elif new != old:
                raise Refused(f"The edit would touch {old['id']}, which was not chosen. Nothing was written.")
        old_lines, new_lines = text.split("\n"), new_text.split("\n")
        if len(old_lines) != len(new_lines) or sum(1 for a, b in zip(old_lines, new_lines) if a != b) != len(ids):
            raise Refused("The edit would change lines beyond the chosen rows. Nothing was written.")
        payload = new_text.encode("utf-8")
        fd, temp = tempfile.mkstemp(prefix=".contract-", suffix=".tmp", dir=str(contract.parent))
        try:
            with os.fdopen(fd, "wb") as out:
                out.write(payload)
            os.replace(temp, contract)
        finally:
            try:
                os.unlink(temp)
            except OSError:
                pass
        return {"ok": True, "settled": ids, "digest": _digest(payload),
                "message": f"Settled {len(ids)} record(s) to requirement: approved. The contract approval form and its signature are still separate acts."}
    finally:
        try:
            lock.unlink()
        except OSError:
            pass
