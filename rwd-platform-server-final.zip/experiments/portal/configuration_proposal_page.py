"""Review isolated configuration proposals without changing the live product.

The editor is offered to any product whose files carry a supported setting; it never
names a product. A product with none simply does not show this section.
"""
from __future__ import annotations

import hashlib
import json
import math

import streamlit as st

import configuration_proposals as proposals
import form_assistance as form_help


def selection_context(root, pack, actor_id, local_demo, can_write, allowed_packs):
    """The page and its guide identify the same explicitly opened proposal."""
    context = hashlib.sha256(json.dumps([str(root), pack, actor_id, local_demo, can_write,
                                        sorted(allowed_packs) if allowed_packs is not None else None]).encode()).hexdigest()
    return context, "configuration_proposal_" + context


def _restore_for_revision(pack, proposal, description, supported, guided, revision_metadata_key):
    """Copy a displayed snapshot into unsaved widgets, before this run renders them."""
    prefix = f"design_{pack}_"
    plan = proposal["brief"]
    st.session_state[prefix + "purpose"] = plan["purpose"]
    st.session_state[prefix + "studies"] = "\n".join(plan["studies"])
    st.session_state[prefix + "baseline"] = proposal["baseline_sha256"]
    st.session_state[prefix + "source"] = plan["source"]["proposed"]["vendor"]
    st.session_state[prefix + "modality"] = plan["source"]["proposed"]["modality"]
    st.session_state[prefix + "additions"] = plan["added"]
    st.session_state[prefix + "domains"] = sorted({row["domain"] for row in description["rows"]})
    st.session_state[prefix + "excluded"] = list(plan["removed"])
    settings = {change["ref"]: change["value"] for change in proposal["configuration_changes"] if change["ref"] in supported}
    st.session_state[prefix + "proposal_selected_settings"] = list(settings)
    for ref, (_label, kind, value) in supported.items():
        field = hashlib.sha256(ref.encode()).hexdigest()[:12]
        st.session_state[prefix + "proposal_" + field + "_change"] = ref in settings
        st.session_state[prefix + "proposal_" + field + "_value"] = _widget_value(settings.get(ref, value), kind)
    exclusions = {row["study"]: row["variables"] for row in proposal["study_exclusions"]}
    for study in plan["studies"]:
        field = hashlib.sha256(study.encode()).hexdigest()[:12]
        st.session_state[prefix + "proposal_study_" + field] = exclusions.get(study, [])
    if guided:
        st.session_state["plan_guide_baseline"] = proposal["baseline_sha256"]
        if plan["removed"] or plan["added"] or plan["source_changed"]:
            st.session_state["plan_guide_intent"] = "revision"
    # These inputs belong to a new proposal, not a saved definition revision.
    st.session_state.pop(revision_metadata_key, None)
    st.session_state.pop(revision_metadata_key.replace("revision_saved_", "configuration_import_", 1), None)


def _value(text, kind):
    """Only explicitly entered structured values become configuration changes."""
    if kind == "lot_numbering":
        if text not in proposals.LOT_NUMBERING_CHOICES:
            raise ValueError("Choose a treatment line numbering rule.")
        return text
    if kind in {"integer", "int", "positive_integer"}:
        return int(text)
    if kind in {"number", "float"}:
        value = float(text)
        if not math.isfinite(value):
            raise ValueError("Enter a finite number.")
        return value
    return text.strip()


def _widget_value(value, kind):
    if kind == "positive_integer":
        if type(value) is int:
            return value if value >= 1 else None
        if isinstance(value, str) and value.isdecimal() and int(value) >= 1:
            return int(value)
        return None
    if kind == "lot_numbering":
        return value if value in proposals.LOT_NUMBERING_CHOICES else None
    return str(value)


def _parameter_field(parameter, *, value_key, selected, binding):
    kind = parameter["kind"]
    st.session_state[value_key] = _widget_value(st.session_state.get(value_key, parameter["value"]), kind)
    common = {"key": value_key, "disabled": not selected, "binding": binding}
    if kind == "lot_numbering":
        labels = {"linenumber": "Delivered line number (linenumber)",
                  "new_lot_n": "Chronological numbering after filters (new_lot_n)"}
        value = form_help.field(st.selectbox, parameter["label"], list(proposals.LOT_NUMBERING_CHOICES),
            index=None, format_func=labels.get, **common)
        st.caption("One numbering rule applies to the whole product, including treatment-line cohorts. If omitted, the engine uses new_lot_n.")
        return value
    if kind == "positive_integer":
        value = form_help.field(st.number_input, parameter["label"], min_value=1, step=1, value=None, **common)
        st.caption("The engine prepares its standard treatment fields for every line from 1 through this number.")
        return value
    return form_help.field(st.text_input, parameter["label"], **common)


def _show_errors(result, fallback):
    for error in result.get("errors") or [fallback]:
        st.error(str(error))


def _reopen_variable_review(root, pack, actor_id, *, allowed_packs, key):
    if st.button("Review current variable table", key=key):
        import variable_review_workflow
        import connected_workflow_page as navigation
        report = variable_review_workflow.describe(root, pack, actor_id, allowed_packs=allowed_packs)
        phase = report.get("current_phase", "science")
        if phase == "complete":
            phase = "output"
        if phase not in {"science", "source", "output"}:
            phase = "science"
        navigation.open_route("variable_review", pack, actor_id, params={"phase": phase, "action": "review"})


def _reviewed_definitions(proposal, context):
    records = proposal.get("variable_review_records")
    if not records:
        return
    prefix = "configuration_records_" + context + "_" + proposal["proposal_id"]
    panel = st.expander("Reviewed definitions behind this proposal", key=prefix, on_change="rerun")
    if not panel.open:
        return
    with panel:
        st.caption("These are the definitions saved with this proposal. They preserve the requested work for engineering and do not confer approval.")
        st.dataframe([{"Variable": row["variable_id"], "Reviewed logic": row["values"].get("derivation", ""),
            "Physical column": row["values"].get("output", {}).get("physical_name", ""),
            "Published name": row["values"].get("output", {}).get("target_published_name", "")}
            for row in records], hide_index=True, width="stretch")
        labels = {row["item_id"]: row["variable_id"] + " · " + row["item_id"] for row in records}
        selected = st.selectbox("Reviewed variable details", list(labels), format_func=labels.get, key=prefix + "_row")
        row = next(row for row in records if row["item_id"] == selected)
        st.write(row["definition"])
        st.json({"Specification values": row["spec_values"], "Source mapping": row["values"].get("source", {}),
                 "Family choices": row["family"], "Master definition": row["master_name"],
                 "Reviewed fields": row["values"]})


def _shared_key(root, pack, actor_id, local_demo, can_write, allowed_packs, suffix):
    context, _ = selection_context(root, pack, actor_id, local_demo, can_write, allowed_packs)
    return "configuration_branch_" + context + "_" + suffix


def render_shared(root, pack, actor_id, *, local_demo, can_write, allowed_packs, key):
    """The same read-only handoff and explicit canonical restage on both pages."""
    prefix = _shared_key(root, pack, actor_id, local_demo, can_write, allowed_packs, key)
    panel = st.expander("Proposal handoffs saved in this branch", key=prefix + "_open", on_change="rerun")
    if not panel.open:
        return
    with panel:
        listing = proposals.list_shared(root, pack, actor_id=actor_id, allowed_packs=allowed_packs,
            page=st.session_state.get(prefix + "_page", 0))
        for error in listing.get("errors", []):
            st.warning(error)
        page = listing.get("page", 0)
        st.caption(f"Page {page + 1} · {listing.get('total', 0)} branch handoffs. Each opened handoff is checked against the current product.")
        prev, following = st.columns(2)
        if prev.button("Previous handoffs", key=prefix + "_previous", disabled=page == 0):
            st.session_state[prefix + "_page"] = page - 1
            st.rerun()
        if following.button("More handoffs", key=prefix + "_next", disabled=not listing.get("has_next")):
            st.session_state[prefix + "_page"] = page + 1
            st.rerun()
        rows = listing.get("records") or []
        if not rows:
            st.info("No readable handoffs on this page.")
            return
        labels = {row["packet_id"]: (row["purpose"] or "Configuration proposal") + " · " + row["packet_id"][:8] for row in rows}
        if st.session_state.get(prefix + "_selected") not in labels:
            st.session_state[prefix + "_selected"] = next(iter(labels))
        selected = st.selectbox("Branch proposal handoff", list(labels), format_func=labels.get, key=prefix + "_selected")
        loaded = proposals.load_shared(root, pack, packet_id=selected, actor_id=actor_id, allowed_packs=allowed_packs)
        if not loaded.get("ok"):
            _show_errors(loaded, "The branch handoff could not be opened.")
            return
        _shared_packet(root, pack, actor_id, loaded, local_demo=local_demo, can_write=can_write,
                       allowed_packs=allowed_packs, prefix=prefix)


def _shared_packet(root, pack, actor_id, loaded, *, local_demo, can_write, allowed_packs, prefix):
    packet, proposal = loaded["packet"], loaded["packet"]["proposal"]
    st.info(proposals.SHARED_NOTICE)
    st.write(proposal["purpose"])
    if loaded.get("line_endings_changed"):
        st.caption("Git changed text line endings only. The diff below is the original handoff; restaging binds this checkout's exact current bytes and requires fresh checks.")
    for entry in proposal["files"]:
        st.caption(entry["path"])
        st.code(entry["diff"], language="diff")
    _impact(proposal["impact"])
    st.write("**Study-only exclusions preserved in this handoff**")
    if proposal["study_exclusions"]:
        st.table(proposal["study_exclusions"])
    else:
        st.caption("None recorded.")
    st.write("**Engineering work still required**")
    if proposal["engineering_handoff"]:
        st.json(proposal["engineering_handoff"])
    else:
        st.caption("No unsupported changes requested in this snapshot.")
    with st.expander("Historical validator results — fresh checks are required here"):
        st.json(packet["validation"] or {"status": "not_run"})
    with st.expander("Exact branch handoff record"):
        st.caption(f"Proposal {proposal['proposal_id']} · handoff {packet['packet_id']} · digest {packet['digest']}")
        st.code(json.dumps(packet, indent=2, ensure_ascii=False), language="json")
    current_key = prefix + "_" + loaded["digest"]
    if loaded["stale"]:
        st.warning("The product baseline changed. Review the conflicts below and continue in a fresh editable plan.")
        revision = proposals.shared_revision_preview(root, pack, packet_id=packet["packet_id"], actor_id=actor_id, allowed_packs=allowed_packs)
        if not revision.get("ok"):
            _show_errors(revision, "The current revision could not be prepared.")
            return
        st.write("**Current product compared with the requested intent**")
        if revision["settings"]:
            st.dataframe(revision["settings"], hide_index=True, width="stretch")
        if revision["conflicts"]:
            st.table(revision["conflicts"])
        else:
            st.caption("No removed definitions or selected-setting conflicts detected. Review the updated product context before continuing.")
        for entry in revision["files"]:
            st.code(entry["diff"], language="diff")
        _impact(revision["impact"])
        for error in revision["errors"]:
            st.warning(error)
        st.info(revision["notice"])
        confirmed = st.checkbox("I reviewed these conflicts and want to copy this intent into an unfinished revision.", key=current_key + "_" + revision["digest"] + "_revise_confirm")
        if st.button("Continue this intent in the current product", key=current_key + "_revise", disabled=not (confirmed and local_demo and can_write)):
            fresh = proposals.shared_revision_preview(root, pack, packet_id=packet["packet_id"], actor_id=actor_id, allowed_packs=allowed_packs)
            if not fresh.get("ok") or fresh["digest"] != revision["digest"]:
                st.error("The handoff or current product changed. Review the current conflicts again.")
                return
            context, selection_key = selection_context(root, pack, actor_id, local_demo, can_write, allowed_packs)
            _restore_for_revision(pack, fresh["restore"], proposals.dw.describe(root, pack), proposals.supported_parameters(root, pack), True, "revision_saved_" + context)
            st.session_state.pop(selection_key, None)
            st.session_state["configuration_import_" + context] = {"unsupported_changes": fresh["unsupported_changes"], "notice": fresh["notice"], "conflicts": fresh["conflicts"]}
            import connected_workflow_page as navigation
            navigation.open_route("plan_changes", pack, actor_id, params={"intent": "revision"})
        return
    confirmed = st.checkbox("I reviewed this handoff and want a new local proposal. Its previous checks and reviews are not carried forward.", key=current_key + "_confirm")
    if st.button("Restage this handoff here", key=current_key + "_restage", disabled=not (local_demo and can_write and confirmed)):
        result = proposals.restage_shared(root, pack, packet_id=packet["packet_id"], actor_id=actor_id,
            expected_digest=loaded["digest"], expected_baseline=loaded["baseline_sha256"], confirmed=confirmed,
            local_demo=local_demo, can_write=can_write, allowed_packs=allowed_packs)
        if result.get("ok"):
            import connected_workflow_page as navigation
            navigation.open_route("plan_changes", pack, actor_id, params={"proposal_id": result["proposal_id"]})
        else:
            _show_errors(result, "The handoff could not be restaged.")


def render_engineering_request(root, pack, handoff_id, actor_id, *, local_demo, can_write, allowed_packs):
    prefix = _shared_key(root, pack, actor_id, local_demo, can_write, allowed_packs, handoff_id)
    panel = st.expander("Exact proposal for this engineering request", key=prefix + "_details_open", on_change="rerun")
    if not panel.open:
        return
    with panel:
        loaded = proposals.load_engineering_request(root, pack, handoff_id, actor_id=actor_id, allowed_packs=allowed_packs)
        if not loaded.get("ok"):
            _show_errors(loaded, "The exact proposal could not be opened.")
            return
        _shared_packet(root, pack, actor_id, loaded, local_demo=local_demo, can_write=can_write,
            allowed_packs=allowed_packs, prefix=prefix)


def _request_engineering(root, pack, proposal_id, actor_id, *, local_demo, can_write, allowed_packs):
    preview = proposals.share_preview(root, pack, proposal_id=proposal_id, actor_id=actor_id, allowed_packs=allowed_packs)
    if not preview.get("ok"):
        _show_errors(preview, "Reopen a current proposal before handing it to Engineering.")
        return
    prefix = _shared_key(root, pack, actor_id, local_demo, can_write, allowed_packs, "engineering_" + preview["digest"])
    with st.expander("Hand this exact proposal to Engineering"):
        st.caption("The engineer receives the full reviewed diff, source request, study exclusions and packet identity. Its shared packet can travel in your Git branch; unfinished drafts and reviewer decisions remain private.")
        with st.expander("Exact engineering handoff record"):
            st.code(json.dumps(preview["packet"], indent=2, ensure_ascii=False), language="json")
        note = form_help.field(st.text_area, "What should the engineer resolve?", key=prefix + "_note", binding=(pack, proposal_id, preview["digest"]))
        confirmed = st.checkbox("I reviewed this exact proposal and confirm its contents may be shared with Engineering in my branch.", key=prefix + "_confirm")
        if st.button("Hand this reviewed proposal to Engineering", key=prefix + "_send", disabled=not (local_demo and can_write and confirmed and note.strip())):
            result = proposals.request_engineering(root, pack, proposal_id=proposal_id, actor_id=actor_id,
                expected_digest=preview["digest"], note=note, confirmed=confirmed, local_demo=local_demo,
                can_write=can_write, allowed_packs=allowed_packs)
            if result.get("ok"):
                st.success("Handed to Engineering with the exact proposal. Open Handoffs and requests to follow its response; Save work to my branch shares the reviewed packet.")
            else:
                _show_errors(result, "The engineering request could not be saved.")


def _share_current(root, pack, proposal_id, actor_id, *, local_demo, can_write, allowed_packs):
    with st.expander("Save a reviewed proposal handoff to my branch"):
        st.caption("This copies only the selected proposal, its declared impact and historical checks into a reviewable handoff file. Private drafts and reviewer decisions stay private.")
        preview = proposals.share_preview(root, pack, proposal_id=proposal_id, actor_id=actor_id, allowed_packs=allowed_packs)
        if not preview.get("ok"):
            _show_errors(preview, "A current proposal is required before preparing a branch handoff.")
            return
        st.info(proposals.SHARED_NOTICE)
        packet, proposal = preview["packet"], preview["packet"]["proposal"]
        st.write(proposal["purpose"])
        st.caption("Configuration files: " + (", ".join(entry["path"] for entry in proposal["files"]) or "none")
                   + f". Study exclusions: {len(proposal['study_exclusions'])}. Engineering items: {len(proposal['engineering_handoff'])}.")
        check = packet["validation"] or {}
        st.caption("Historical proposal checks: " + ("review-submission requirements met; remaining product findings are retained."
            if check.get("passed") else "findings remain unresolved." if check else "not run."))
        with st.expander("Exact handoff record"):
            st.code(json.dumps(packet, indent=2, ensure_ascii=False), language="json")
        prefix = _shared_key(root, pack, actor_id, local_demo, can_write, allowed_packs, preview["digest"])
        confirmed = st.checkbox("I reviewed this exact handoff and confirm its contents may be shared in my Git branch.", key=prefix + "_share_confirm")
        if st.button("Save proposal handoff", key=prefix + "_share", disabled=not (local_demo and can_write and confirmed)):
            result = proposals.share(root, pack, proposal_id=proposal_id, actor_id=actor_id, expected_digest=preview["digest"],
                confirmed=confirmed, local_demo=local_demo, can_write=can_write, allowed_packs=allowed_packs)
            if result.get("ok"):
                st.success("Saved the reviewed handoff. Use Save work to my branch to inspect and commit its file. In another checkout, open Plan changes or Review requests to restage it and run fresh validators.")
            else:
                _show_errors(result, "The proposal handoff could not be saved.")


def _consumer_table(rows, *, registry=False):
    """Keep nested pin records out of the main study-impact table."""
    def words(value, fallback="Not declared"):
        return str(value) if isinstance(value, (str, int, float)) and str(value).strip() else fallback
    result = []
    decisions = {"reuse": "reuse", "reconsider": "review a study-specific definition", "exclude": "exclude in this study"}
    for row in rows:
        if registry:
            citations = [words(cite.get("product")) + " · " + words(cite.get("spec_version"))
                         for cite in row.get("cites_release") or [] if isinstance(cite, dict)]
            result.append({"Study": words(row.get("study")), "Cited products and versions": "; ".join(citations) or "Not declared"})
            continue
        definitions = []
        for definition in row.get("definitions") or []:
            if isinstance(definition, dict):
                identifier = definition.get("variable_id") or definition.get("variable")
                decision = definition.get("decision")
                choice = decisions.get(decision, words(decision, "decision not recorded")) if isinstance(decision, str) else "decision not recorded"
                definitions.append(words(identifier) + ": " + choice)
        follow_up = []
        if row.get("status") == "unreadable":
            follow_up.append("Repair the unreadable study selection")
        if row.get("stale"):
            follow_up.append("Review changed product definitions or settings")
        if row.get("build_stale"):
            follow_up.append("Recheck the selected build")
        if row.get("superseded"):
            follow_up.append("Review the newer product version")
        result.append({"Study": words(row.get("study")), "Selected version": words(row.get("spec_version")),
                       "Study choice": "Product selected" if row.get("status") == "pinned" else words(row.get("status")).replace("_", " "),
                       "Definition choices": "; ".join(definitions) or "No per-definition choices recorded",
                       "Follow-up": "; ".join(follow_up) or "No recorded change detected"})
    return result


def _impact(impact):
    st.write("**Declared dependency and consumer impact**")
    st.caption("This report uses declared dependencies and registered consumers. Reviewers must assess any undeclared dependencies.")
    labels = {"direct_variables": "Directly affected definitions", "dependent_variables": "Definitions that depend on them",
              "dependencies": "Declared definition dependencies", "external_dependencies": "Dependencies outside this contract",
              "consumers": "Studies pinned to this product", "registry_consumers": "Studies citing this product in the registry",
              "shared_removed": "Requested shared-product removals", "study_dependency_conflicts": "Study-only dependency conflicts"}
    for name, value in impact.items():
        if name == "capabilities":
            if value:
                with st.expander("Declared engine capability details"):
                    st.json(value)
            continue
        if name in {"notes", "errors"}:
            for item in value:
                (st.warning if name == "errors" else st.caption)(str(item))
            continue
        label = labels.get(name, str(name).replace("_", " ").capitalize())
        if isinstance(value, list):
            st.write(f"{label}:" if value else f"{label}: none declared")
            if value and all(isinstance(row, dict) for row in value):
                if name in {"consumers", "registry_consumers"}:
                    st.dataframe(_consumer_table(value, registry=name == "registry_consumers"), hide_index=True, width="stretch")
                    with st.expander("Recorded study pin details" if name == "consumers" else "Recorded registry citation details"):
                        st.json(value)
                else:
                    st.dataframe(value, hide_index=True, width="stretch")
            elif value:
                st.write(", ".join(str(item) for item in value))
        elif isinstance(value, dict):
            st.write(f"{label}:")
            st.json(value)
        else:
            st.write(f"{label}: {value}")


def render(root, pack, brief, *, expected_baseline, baseline_changed=False,
           actor_id="", local_demo=False, can_write=False, allowed_packs=None, guided=False, initial_proposal_id=None):
    try:
        supported = proposals.supported_parameters(root, pack)
    except (OSError, ValueError) as exc:
        st.error(f"Supported configuration settings could not be read: {exc}")
        return
    if not supported:
        return
    st.subheader("Propose settings for review" if guided else "4. Stage a configuration proposal")
    st.caption("Enter supported settings explicitly. Each staged proposal preserves a before-and-after diff, "
               "study exclusions, and an engineering handoff. Submission requests review; it does not approve or release a product.")
    st.write("Choose a setting below and stage your proposal. Review the saved changes, run the validators, "
             "then submit for review when every required check passes.")
    prefix = f"design_{pack}_proposal_"
    context, metadata_key = selection_context(root, pack, actor_id, local_demo, can_write, allowed_packs)
    imported = st.session_state.get("configuration_import_" + context) or {}
    if initial_proposal_id and st.session_state.get(metadata_key + "_incoming") != initial_proposal_id:
        st.session_state.pop("configuration_import_" + context, None)
        imported = {}
        st.session_state[metadata_key] = initial_proposal_id
        st.session_state[metadata_key + "_incoming"] = initial_proposal_id
    notice_key = metadata_key + "_notice"
    if st.session_state.get(notice_key):
        st.success(st.session_state.pop(notice_key))

    parameters = [{"ref": ref, "label": label, "kind": kind, "value": value}
                  for ref, (label, kind, value) in supported.items()]
    changes, input_errors = [], []
    with st.expander("Supported shared-product settings", expanded=True):
        st.caption("Select a setting to change it. Free-text scientific definitions are preserved for engineering review.")
        chosen_refs = None
        if guided:
            labels = {p["ref"]: p["label"] for p in parameters}
            chosen_refs = form_help.field(st.multiselect, "Settings to change", list(labels), key=prefix + "selected_settings", format_func=labels.get, binding=(pack, expected_baseline),
                help="Choose one or more settings. Only your selected settings will appear in the proposal diff.")
            if not chosen_refs:
                st.caption("Choose a setting above to see its current value and enter your proposed value.")
        for parameter in parameters:
            if guided and parameter["ref"] not in chosen_refs:
                continue
            field = hashlib.sha256(parameter["ref"].encode()).hexdigest()[:12]
            selected = True if guided else st.checkbox("Change " + parameter["label"], key=prefix + field + "_change")
            value_key = prefix + field + "_value"
            value = _parameter_field(parameter, value_key=value_key, selected=selected,
                binding=(pack, expected_baseline, parameter["ref"], parameter["kind"], parameter["value"]))
            st.caption(f"Current value: {parameter['value']}")
            if guided and str(parameter["value"]) == "REPLACE_ME":
                st.caption("This value is still unspecified. Enter the value agreed for the intended product; the validator will check its format and consistency.")
            if selected:
                try:
                    changes.append({"ref": parameter["ref"], "value": _value(value, parameter["kind"])})
                except (TypeError, ValueError, OverflowError):
                    input_errors.append(f"Enter a valid {parameter['kind']} for {parameter['label']}.")
    for error in input_errors:
        st.info(error)
    if imported:
        st.info(imported["notice"])
        if imported["conflicts"]:
            with st.expander("Conflicts reviewed when this intent was restored"):
                st.table(imported["conflicts"])
        if imported["unsupported_changes"]:
            st.warning("These settings remain engineering requests. They are preserved with this revision and cannot execute as configuration changes.")
            st.json(imported["unsupported_changes"])
            keep = st.checkbox("Keep these unsupported setting requests in this proposal", value=True, key="configuration_import_keep_" + context)
            if keep:
                changes.extend(imported["unsupported_changes"])

    exclusions = []
    with st.expander("Study-only exclusions") if not guided else __import__("contextlib").nullcontext():
      if not guided:
        st.caption("Choose removed variables that should be excluded only for a named study. "
                   "These stay separate from shared-product settings and do not remove engine outputs.")
        removed = brief.get("removed") or []
        # The brief validator reports duplicate names. Render one widget per name
        # while that input is being corrected, without changing the saved brief.
        studies = list(dict.fromkeys(brief.get("studies") or []))
        if not removed or not studies:
            st.info("Name the intended studies and select variables to remove above to record study-only exclusions.")
        for study in studies:
            field = hashlib.sha256(study.encode()).hexdigest()[:12]
            key = prefix + "study_" + field
            if key in st.session_state:
                st.session_state[key] = [identifier for identifier in st.session_state[key] if identifier in removed]
            selected = form_help.field(st.multiselect, f"Exclude only in {study}", removed, key=key, binding=(pack, expected_baseline, study))
            if selected:
                exclusions.append({"study": study, "variables": selected})

    enabled = bool(actor_id and local_demo and can_write)
    has_changes = bool(changes or brief.get("removed") or brief.get("added") or brief.get("source_changed"))
    if not enabled:
        st.info("Staging, validation, and submission require a local editing session with permission to change this product.")
    if st.button("Stage configuration proposal", key=f"configuration_stage_{pack}",
                 disabled=not enabled or baseline_changed or bool(input_errors) or not has_changes or not brief.get("purpose")):
        result = proposals.stage(root, pack, brief, configuration_changes=changes, study_exclusions=exclusions,
                                 expected_baseline=expected_baseline, actor_id=actor_id, local_demo=local_demo,
                                 can_write=can_write, allowed_packs=allowed_packs)
        if result.get("ok"):
            st.session_state[metadata_key] = result["proposal_id"]
            st.session_state[notice_key] = "Configuration proposal staged. Review its exact changes and run validators before submitting for review."
            st.rerun()
        else:
            _show_errors(result, "The configuration proposal could not be staged.")
            st.session_state[metadata_key + "_refused"] = True    # the earlier proposal's results are labelled as such (walk UC3-P2-5)

    if not actor_id:
        return
    catalog = proposals.list_proposals(root, pack, actor_id=actor_id, allowed_packs=allowed_packs)
    for error in catalog.get("errors") or []:
        st.warning(str(error))
    entries = catalog.get("proposals") or []
    if entries:
        with st.expander("Your staged configuration proposals"):
            labels = {entry["proposal_id"]: f"{entry.get('purpose') or 'Configuration proposal'} · {entry['proposal_id'][:8]}" for entry in entries}
            key = prefix + "saved_choice"
            if st.session_state.get(key) not in labels:
                st.session_state[key] = next(iter(labels))
            choice = st.selectbox("Staged proposal", list(labels), key=key, format_func=labels.get)
            if st.button("Open staged proposal", key=f"configuration_open_{pack}"):
                st.session_state.pop("configuration_import_" + context, None)
                st.session_state[metadata_key] = choice
                st.rerun()
    proposal_id = st.session_state.get(metadata_key)
    if not proposal_id:
        return
    loaded = proposals.load(root, pack, proposal_id=proposal_id, actor_id=actor_id, allowed_packs=allowed_packs)
    if not loaded.get("ok"):
        _show_errors(loaded, "The staged proposal could not be opened.")
        return
    proposal = loaded["proposal"]
    st.subheader("Review staged proposal")
    st.write(f"Proposal {proposal_id[:8]} · {proposal.get('status', 'staged').replace('_', ' ')}")
    st.caption("You are reviewing this saved snapshot. Changes in the plan above need to be staged as a new proposal.")
    if proposal.get("variable_review_binding"):
        st.caption("Prepared from the completed scientific, source and output tables. Changes to those reviews or their inputs require a fresh proposal.")
        _reopen_variable_review(root, pack, actor_id, allowed_packs=allowed_packs,
            key="configuration_review_variables_" + context + "_" + proposal_id)
    _reviewed_definitions(proposal, context)
    if proposal.get("purpose"):
        st.write(proposal["purpose"])
    stale = bool(loaded.get("stale"))
    if stale:
        st.warning("The reviewed variable table, source product or declared consumer impact changed. Stage a new proposal from the current baseline before submission.")
    description = proposals.dw.describe(root, pack)
    st.button("Revise this proposal", key=f"configuration_revise_{pack}",
              disabled=not enabled or stale or bool(description["errors"]),
              help="Restore this proposal's inputs above. Edit them and stage a new snapshot; the existing proposal and review remain unchanged.",
              on_click=_restore_for_revision,
              args=(pack, proposal, description, supported, guided, "revision_saved_" + context))
    for warning in proposal.get("warnings") or []:
        st.warning(str(warning))
    for error in proposal.get("errors") or []:
        st.warning(str(error))

    st.write("**Before-and-after configuration diff**")
    files = proposal.get("files") or []
    if not files:
        st.info("No supported shared-product configuration changes are staged. Review the study exclusions and engineering handoff below.")
    for file in files:
        st.caption(file["path"])
        st.code(file["diff"], language="diff")
        with st.expander("Full before-and-after configuration: " + file["path"]):
            left, right = st.columns(2)
            with left:
                st.caption("Before")
                st.code(file["before"], language="yaml")
            with right:
                st.caption("Proposed after")
                st.code(file["after"], language="yaml")
    _impact(proposal.get("impact") or {})
    st.write("**Study-only exclusions**")
    if proposal.get("study_exclusions"):
        st.table(proposal["study_exclusions"])
    else:
        st.caption("No study-only exclusions are included in this proposal.")
    st.write("**Engineering handoff**")
    handoff = proposal.get("engineering_handoff") or []
    if handoff:
        st.warning("Unsupported derivations remain an engineering handoff. No derivation logic is generated by this proposal.")
        st.dataframe(handoff, hide_index=True, width="stretch")
        st.info("This work is done by the engineering team. Hand it over below so it has an owner and a status; "
                "to submit the supported settings independently, stage a separate proposal without these unresolved derivations.")
        _request_engineering(root, pack, proposal_id, actor_id, local_demo=local_demo,
                             can_write=can_write, allowed_packs=allowed_packs)
    else:
        st.caption("No unsupported derivation changes are requested.")

    validation = loaded.get("validation") or {}
    if loaded.get("validation_error"):
        st.warning("The saved validation receipt could not be verified, so submission is disabled. The staged proposal is intact.")
        if stale:
            st.caption("Stage a new proposal from the current baseline to check the current product and consumer inputs.")
        elif loaded.get("submission"):
            st.caption("The existing submitted review request and its evidence are retained. Use Revise this proposal to stage and validate a new snapshot.")
        elif not enabled:
            st.caption("Open a local editing session with permission to change this product, then run the proposal validators.")
        else:
            st.caption("Choose Run proposal validators below to replace the unusable receipt with fresh results. The proposal and product are unchanged.")
        with st.expander("Why the previous validation cannot be used"):
            st.text(loaded["validation_error"])
    if validation:
        st.write("**Existing validator results**")
        if any(check.get("pre_existing") and not check.get("passed") for check in validation.get("checks") or []):
            st.warning("The full product checks have not passed. Unchanged existing findings remain open; this proposal can only request review of the supported change.")
        if st.session_state.pop(metadata_key + "_refused", None):
            st.caption("The last stage attempt was refused, so these results belong to the previously staged proposal.")
        for check in validation.get("checks") or []:
            if check.get("passed"):
                st.success(f"{check['validator']}: passed")
            elif check.get("pre_existing"):
                st.warning(f"{check['validator']}: failed before this change too (the product's own open work; it does not block this proposal)")
            else:
                st.error(f"{check['validator']}: failed")
            findings = check.get("errors") or []
            if findings:
                with st.expander(f"{check['validator']}: read {len(findings)} finding(s)"):
                    for error in findings:
                        st.text(str(error))
            if check.get("note"):
                st.caption(check["note"])
        for caveat in validation.get("caveats") or []:
            st.info(caveat)
        for error in validation.get("errors") or []:
            st.error(str(error))
        if not validation.get("passed"):
            st.info("Submission is blocked by the findings above. Correct a supported setting in the form, stage a new proposal, "
                    "and run validators again. Contract, mapping, and engine findings need the product's data expert; "
                    "staging a parameter change does not complete those requirements.")
    elif not loaded.get("validation_error") and not loaded.get("submission"):
        st.info("Run the existing validators on the staged proposal before submitting it for review.")
    submission = loaded.get("submission")
    action_args = dict(proposal_id=proposal_id, actor_id=actor_id, local_demo=local_demo,
                       can_write=can_write, allowed_packs=allowed_packs)
    if st.button("Run proposal validators", key=f"configuration_validate_{pack}",
                 disabled=not enabled or stale or bool(submission)):
        result = proposals.validate(root, pack, **action_args)
        if result.get("ok"):
            st.session_state[notice_key] = ("Proposal checks completed and the review-submission requirements are satisfied. Review all remaining product findings below."
                                           if result.get("passed") else "Proposal validators ran. Resolve their findings before submission.")
            st.rerun()
        else:
            _show_errors(result, "The proposal validators could not run.")
    can_submit = loaded.get("can_submit") is True
    if st.button("Submit proposal for review", key=f"configuration_submit_{pack}",
                 disabled=not enabled or not can_submit or bool(submission)):
        result = proposals.submit(root, pack, **action_args)
        if result.get("ok"):
            st.session_state[notice_key] = "Submitted the staged configuration proposal for review. No approval or release was recorded."
            st.rerun()
        else:
            _show_errors(result, "The configuration proposal could not be submitted for review.")
    if submission:
        st.success("This configuration proposal was submitted for review. Approval and release remain separate decisions.")
        # THE AUTHOR SEES THE REVIEW (2026-09-07): the receipt names the published request, so the
        # reviewer's decision and the later apply and validate acts are shown here, by name and date.
        if loaded.get("review_request"):
            import review_inbox
            request = review_inbox.load_request(root, pack, request_id=loaded["review_request"], actor_id=actor_id,
                                                allowed_packs=allowed_packs)
            if request.get("ok"):
                st.write(f"**Review request {request['request_id'][:8]}: {request['status_words']}**")
                for line in request["history"]:
                    st.write(line)
                if request["proposal_state"] != "intact":
                    st.warning("The submitted snapshot no longer matches this proposal, so it cannot be accepted. Stage and submit the current proposal again.")
            else:
                _show_errors(request, "The review request for this proposal could not be opened.")
    st.download_button("Download staged configuration proposal", json.dumps(proposal, indent=2, ensure_ascii=False),
                       file_name=f"configuration_proposal_{proposal_id[:8]}.json", mime="application/json",
                       key=f"configuration_download_{pack}")
    _share_current(root, pack, proposal_id, actor_id, local_demo=local_demo, can_write=can_write, allowed_packs=allowed_packs)
