"""Durable fixes inside the existing selected correction review."""
from pathlib import Path
import json

import streamlit as st

import workflow_durable_fixes as workspace
import portal_jobs as jobs
import portal_jobs_page as job_page
import portal_agent_connection as connection


def render(root, actor_id, record_id, *, can_write=False, can_review=False, allowed_packs=None,
           key="workflow_durable_"):
    prefix = key + record_id + "_"
    context = (str(Path(root).resolve()), actor_id, tuple(sorted(allowed_packs or [])))
    if st.session_state.get(prefix + "context") != context:
        for name in list(st.session_state):
            if str(name).startswith(prefix):
                st.session_state.pop(name, None)
        st.session_state[prefix + "context"] = context
    # An apply action occurs above the editor and reruns before those widgets
    # render. Preserve their private draft values through Streamlit's cleanup.
    draft_key = prefix + "draft_values"
    for name, value in st.session_state.get(draft_key, {}).items():
        if name not in st.session_state:
            st.session_state[name] = value
    def retain_draft():
        st.session_state[draft_key] = {name: st.session_state[name] for name in list(st.session_state)
            if name.startswith(prefix) and (name[len(prefix):].startswith(("before_", "after_", "path_", "case_", "goal_"))
                or name[len(prefix):] in {"expectation", "linked", "kind"})}
    with st.expander("Replace this lesson with a durable fix"):
        try:
            report = workspace.describe(root, actor_id, record_id, allowed_packs=allowed_packs)
        except (ValueError, OSError, TypeError, KeyError):
            st.warning("The lesson or its owning files are unavailable. Refresh the current review.")
            return
        st.caption(workspace.NOTICE)
        if report["repeat_groups"]:
            group = report["repeat_groups"][0]
            st.info(f"{group['independent_observations']} independent observations have matching guidance and scope. Review whether one durable change addresses them together.")
        notice = st.session_state.get(prefix + "notice")
        if notice:
            st.info(notice)
        row = report["record"]
        history = report["history"]
        if history:
            identifier = st.selectbox("Saved durable review", history, index=len(history) - 1, key=prefix + "history")
            try:
                saved = workspace.read(root, actor_id, record_id, identifier, allowed_packs=allowed_packs)
                proposal = saved["proposal"]
                st.write(workspace.KINDS[proposal["kind"]] + " · " + proposal["path"])
                st.code(proposal["diff"], language="diff")
                st.write("Expected regression behavior: " + proposal["regression_expectation"])
                st.write("Reviewed counterexample — the same test must fail before and pass after")
                st.json(proposal.get("regression_case") or {"missing": "Add a reviewed case before applying this historical proposal."})
                st.caption("Required checks: " + ", ".join(proposal["tests"]))
                st.caption("Run limits: up to 90 seconds per isolated counterexample, 3 minutes for the owning validator, then up to 10 minutes for registered regressions. A timeout or skipped check keeps the lessons available.")
                apply_result = job_page.render(root, actor_id, action="durable_apply", job_key=record_id + ":" + identifier,
                    can_write=can_write and can_review, allowed_packs=allowed_packs, key=prefix + "apply_job_" + identifier)
                if apply_result and not apply_result.get("ok"):
                    st.warning(" ".join(apply_result.get("errors", ["The requested checks did not complete successfully."])))
                if proposal["path"] in workspace.REGISTERS:
                    st.caption("Owning validator: " + workspace.REGISTERS[proposal["path"]][2] + " --check")
                if proposal.get("application"):
                    st.json(proposal["application"]["check"])
                for attempt in proposal.get("attempts", [])[-1:]:
                    st.json(attempt)
                if row["status"] == "retired" and saved["retirement_complete"]:
                    st.success("The linked lessons were replaced and retained as history. They no longer enter assistant prompts.")
                if saved["stale"]:
                    st.warning("The installed file, linked lesson or validation inputs have changed since this application. Record a new correction if the fix needs revision; past lessons are not automatically re-enabled.")
                if saved["pending_retirement"]:
                    st.warning("The installed fix passed its checks, but saving the linked lesson history was interrupted. Review and apply below to finish the remaining exact records.")
                if ((row.get("durable_fix") or {}).get("proposal_id") == identifier
                        and (row["status"] != "retired" or saved["pending_retirement"])):
                    reviewed = st.checkbox("I reviewed this exact diff and it addresses every linked lesson. Run the required checks before retiring those lessons.", key=prefix + "apply_review_" + identifier)
                    if st.button("Apply reviewed change and run checks", key=prefix + "apply_" + identifier,
                                 disabled=not (reviewed and can_write and can_review)):
                        try:
                            jobs.start(root, actor_id, action="durable_apply", job_key=record_id + ":" + identifier,
                                arguments={"record_id": record_id, "proposal_id": identifier, "expected_digest": report["digest"],
                                    "confirmed": reviewed, "can_write": can_write, "can_review": can_review},
                                confirmed=True, can_write=can_write and can_review, allowed_packs=allowed_packs)
                            retain_draft()
                            st.rerun()
                        except ValueError as error:
                            st.error(str(error))
                        except (OSError, TypeError, KeyError):
                            st.error("The apply or check did not finish. Review the retained proposal and current branch before retrying.")
            except (ValueError, OSError, TypeError, KeyError):
                st.warning("This retained proposal cannot be read. Its branch history is preserved.")
        if row["status"] in {"retired", "withdrawn"}:
            return
        st.write("Describe the fix you want")
        st.caption("Use Python for behavior, the skill for reusable procedure, naming for a reviewed naming record, or knowledge for a reviewed definition/precedent. Shared files affect their existing consumers. A new register entry must preserve prior records and supply its own human-reviewed evidence.")
        kind = st.selectbox("Where should the durable fix live?", list(workspace.KINDS),
                            format_func=workspace.KINDS.get, key=prefix + "kind")
        paths = report["targets"].get(kind) or []
        if not paths:
            st.info("Restore the existing owning file before preparing this target.")
            return
        path = st.selectbox("Existing owning file", paths, key=prefix + "path_" + kind)
        options = {item["id"]: item for item in report["related"]}
        selected = st.multiselect("Lessons addressed by this change", list(options), default=[record_id],
            format_func=lambda value: options[value]["context"] + " · " + value[:8], key=prefix + "linked")
        for identifier in selected:
            st.caption("Selected lesson: " + options[identifier]["right"])
        _prepare(root, actor_id, row, report, kind, path, prefix, can_write, can_review, allowed_packs, retain_draft, selected)
        try:
            text = workspace.target_text(root, actor_id, record_id, kind, path, allowed_packs=allowed_packs)
        except (ValueError, OSError):
            st.warning("The selected owning file is unavailable.")
            return
        with st.expander("Advanced: read the current owning file"):
            st.code(text, language="python" if kind == "code" else "yaml" if kind in {"naming", "knowledge"} else "markdown")
        with st.expander("Advanced: edit exact patch and test case"):
            before = st.text_area("Exact current text to replace", key=prefix + "before_" + path,
                help="Copy a unique fragment from the owning file. It must match once, including whitespace. At most 12 KB.")
            after = st.text_area("Reviewed replacement text", key=prefix + "after_" + path,
                help="Write the complete replacement for that fragment. Skill changes also need an explicit version update. Register changes add a reviewed entry and preserve existing records.")
            expectation = st.text_area("What should the regression checks demonstrate?", key=prefix + "expectation",
                placeholder="Describe the original error, the corrected behavior and how this exact edit covers each selected lesson.")
            case_text = st.text_area("Reviewed test case (JSON)", key=prefix + "case_" + path,
                max_chars=8000,
                placeholder=json.dumps(workspace.regression.example(kind, workspace.REGISTERS.get(path, (None, None))[1]), indent=2),
                help="The fixed runner uses the identical case before and after. Python checks an owning function's returned result; other targets check the specific reviewed instructions or registry fields. No model-written test program is executed.")
            reviewed = st.checkbox("I reviewed the proposed text and linked lessons; stage their before-and-after diff.", key=prefix + "stage_review")
            if st.button("Stage durable fix for review", key=prefix + "stage", disabled=not (reviewed and can_write and can_review)):
                try:
                    try:
                        parsed_case = json.loads(case_text)
                    except (ValueError, TypeError, RecursionError):
                        raise ValueError("Enter a complete bounded JSON test case using the displayed example.") from None
                    result = workspace.stage(root, actor_id, record_id, kind=kind, path=path, before_text=before,
                        after_text=after, linked_ids=selected, regression_expectation=expectation,
                        regression_case=parsed_case,
                        expected_digest=report["digest"], confirmed=reviewed, can_write=can_write,
                        can_review=can_review, allowed_packs=allowed_packs)
                    st.session_state.pop(prefix + "history", None)
                    st.session_state[prefix + "notice"] = "Exact durable diff staged. Review it above before applying and running the required checks."
                    retain_draft()
                    st.rerun()
                except ValueError as error:
                    st.error(str(error))
                except (OSError, TypeError, KeyError):
                    st.error("The durable proposal could not be saved. Your entered text remains available.")


def _prepare(root, actor, row, report, kind, path, prefix, can_write, can_review, allowed, retain_draft, linked_ids):
    job_key = "durable-prepare:" + row["id"]
    result = job_page.render(root, actor, action="durable_prepare", job_key=job_key,
        can_write=can_write and can_review, allowed_packs=allowed, key=prefix + "prepare_job")
    selected = connection.describe(root)
    goal = st.text_area("What should work differently?", value=row["right"], key=prefix + "goal_" + path,
        help="Explain the desired behavior in plain language. The existing coding specialist will propose the patch and a concrete input/expected-result test for your review.")
    if not selected.get("ok"):
        st.info("Connect an assistant to prepare this fix in plain language. The advanced reviewer editor remains available below.")
    else:
        st.caption("Selected assistant: " + selected["model"] + ". Its proposal and critic findings require your review.")
    requested = st.checkbox("Use the selected assistant to prepare this fix and its test case for review.", key=prefix + "prepare_confirm")
    linked_bindings = {item["id"]: item["content_digest"] for item in report["related"] if item["id"] in linked_ids}
    if st.button("Prepare fix with assistant", key=prefix + "prepare", disabled=not (requested and can_write and can_review and selected.get("ok"))):
        try:
            jobs.start(root, actor, action="durable_prepare", arguments={"record_id": row["id"], "goal": goal,
                "kind": kind, "path": path, "expected_digest": report["digest"], "expected_connection": selected,
                "linked_ids": linked_ids, "expected_linked_bindings": linked_bindings,
                "confirmed": requested, "can_write": can_write, "can_review": can_review}, job_key=job_key,
                confirmed=True, can_write=can_write and can_review, allowed_packs=allowed)
            retain_draft()
            st.rerun()
        except (ValueError, OSError) as error:
            st.error(str(error))
    if not result:
        return
    if not result.get("ok"):
        st.warning(" ".join(result.get("errors", ["The assistant could not prepare a complete reviewed fix. Clarify the goal or use advanced review."])))
        return
    proposed = result["prepared"]
    saved_bindings = result.get("linked_bindings") or {row["id"]: linked_bindings.get(row["id"])}
    identity = workspace.regression.digest([result["input_digest"], proposed, result["connection"], saved_bindings])
    if st.session_state.get(prefix + "prepared_identity") != identity:
        st.session_state.pop(prefix + "prepared_review", None)
        st.session_state[prefix + "prepared_identity"] = identity
    st.caption("Saved proposal target: " + workspace.KINDS[result["kind"]] + " · " + result["path"])
    st.caption("Prepared for selected lessons: " + ", ".join(saved_bindings))
    if saved_bindings != linked_bindings:
        st.warning("The selected lessons or their wording changed. Restore the reviewed selection or prepare a new fix.")
    st.write(proposed["rationale"])
    st.code(result["diff"], language="diff")
    st.write("Proposed counterexample: review its inputs and expected result")
    st.json(proposed["regression_case"])
    with st.expander("Coding specialist critique"):
        st.json(result["critic"])
    reviewed = st.checkbox("I reviewed this patch and this counterexample addresses the lesson.", key=prefix + "prepared_review")
    if st.button("Stage this proposed fix", key=prefix + "prepared_stage", disabled=not (reviewed and can_write and can_review and saved_bindings == linked_bindings)):
        try:
            if workspace._inputs(Path(root).resolve()) != result["input_digest"]:
                raise ValueError("The owning inputs changed after preparation. Request a current proposal.")
            if (result["record_id"] != row["id"] or result["record_digest"] != report["digest"]
                    or connection._binding(connection.describe(root)) != connection._binding(result["connection"])):
                raise ValueError("The lesson or selected connection changed after preparation. Request a current proposal.")
            workspace.stage(root, actor, row["id"], kind=result["kind"], path=result["path"], before_text=proposed["before_text"],
                after_text=proposed["after_text"], regression_case=proposed["regression_case"], linked_ids=list(saved_bindings),
                expected_linked_bindings=saved_bindings,
                regression_expectation=proposed["rationale"], expected_digest=result["record_digest"],
                confirmed=reviewed, can_write=can_write, can_review=can_review, allowed_packs=allowed)
            st.session_state.pop(prefix + "history", None)
            retain_draft()
            st.rerun()
        except (ValueError, OSError) as error:
            st.error(str(error))
