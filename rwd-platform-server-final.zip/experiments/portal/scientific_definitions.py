"""Human-authored row drafts and checked contract updates; never approval transitions.

Unfinished judgments live in the actor's local draft store. Applying a complete
record uses the same evidence merge, status policy, renderer and product lint as
contract_record. No scientific judgment is derived from specification prose.

A person drafts here and no model reads the row, so the evidence is asked for as
reader="human": the specification must be recorded as reviewed, and nothing about
AI eligibility is required. The AI gate is still reported, as ai_help_blocker, so
the AI helper page can say that AI help is unavailable; it no longer blocks a save.
"""
from __future__ import annotations

import difflib
from collections import Counter
from functools import lru_cache
import errno
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import tempfile
import time

import yaml

import contract_lint as cl
import contract_record as cr
import contract_scaffold as cs
import design_workspace as dw
import specification_details as details
from spec_extract import requirement_rows, is_context, row_item_id

FIELDS = ("variable_id", *cs.JUDGMENT_FIELDS, "implementation_refs")
LIMIT = 4 * 1024 * 1024
SHARED_INPUTS = ("products/_reporting/dashboard/dashboard_vars.yaml",)
# A LEFTOVER LOCK (2026-09-07, decision loop audit DL-06). A save that died mid-way leaves its lock
# file, and every later save then failed with the operating system's own text and an absolute path.
# The message now says what it means, and a lock older than this may be cleared by the person.
LOCK_STALE_SECONDS = 10 * 60
LOCK_MESSAGE = "Another save is in progress. Wait for it to finish, then reload the row."
STALE_LOCK_MESSAGE = ("Another save is in progress, or an earlier save stopped and left its lock behind more than "
                      "10 minutes ago. If nobody else is saving, clear the stale lock and try again.")
NO_JUDGMENT_MESSAGE = ("Every judgment field is still TODO or its starting value, so there is nothing to save to the contract yet. "
                       "Write at least one interpretation, or save an unfinished row draft instead.")
# THE DRAFT STORE'S NAMES ARE SHORT (walk NC-01, 2026-09-07): a draft used to live under two 24-character
# digests, which crossed the Windows path limit on a deep checkout and failed with the operating
# system's own text. Twelve hexadecimal characters of each digest keep a draft unique per editing
# identity and per row; a draft saved under the old names is still read.
DIGEST_CHARS = 12
LEGACY_DIGEST_CHARS = 24
WINDOWS_PATH_LIMIT = 240
LONG_PATH_MESSAGE = ("The product's folder path is too long for Windows, so this file could not be written. Move the checkout "
                     "to a shorter folder close to the root of the drive, or ask your data expert to enable long paths. "
                     "Nothing was changed.")
FILESYSTEM_MESSAGE = "The file system refused this change ({why}). Nothing was changed. Ask your data expert if it happens again."


def _os_words(error):
    """An operating-system error as a sentence: the length problem by name when that is what it is,
    its own reason otherwise; never the path."""
    name = str(getattr(error, "filename", "") or getattr(error, "filename2", "") or "")
    long_path = getattr(error, "errno", None) == errno.ENAMETOOLONG or getattr(error, "winerror", None) == 206 \
        or (os.name == "nt" and len(name) > WINDOWS_PATH_LIMIT)
    if long_path:
        return LONG_PATH_MESSAGE
    why = str(getattr(error, "strerror", None) or type(error).__name__).strip().rstrip(".")
    return FILESYSTEM_MESSAGE.format(why=why)


def _fail(error):
    return {"ok": False, "changed": False, "passed": False,
            "errors": [_os_words(error) if isinstance(error, OSError) else str(error)]}


def _lock_age(lock):
    try:
        return time.time() - Path(lock).stat().st_mtime
    except OSError:
        return None


def _lock_result(lock):
    age = _lock_age(lock)
    stale = age is not None and age > LOCK_STALE_SECONDS
    return {**_fail(STALE_LOCK_MESSAGE if stale else LOCK_MESSAGE), "stale_lock": stale}


def _contract_lock(product):
    target = _safe(product / "handoff/FUNCTIONAL_CONTRACT.md")
    return target.with_name("." + target.name + ".portal-definition.lock")


def clear_stale_lock(root, pack, actor_id, item_id=None, *, local_demo, can_write, allowed_packs=None):
    """Remove one save lock (the contract's, or a row draft's), only when it is older than ten minutes."""
    if local_demo is not True or can_write is not True:
        return _fail("Clearing a stale lock requires an authorized local editing session.")
    try:
        product, _pack, _owner, folder = _scope(root, pack, actor_id, allowed_packs)
        lock = _draft_path(folder, item_id).with_suffix(".lock") if item_id else _contract_lock(product)
        if lock.is_symlink() or (lock.exists() and not lock.is_file()):
            raise details._Invalid("The lock redirects to another location. Ask your data expert to remove it.")
        if not lock.exists():
            return {"ok": True, "changed": False, "passed": False, "cleared": False, "errors": []}
        age = _lock_age(lock)
        if age is None or age <= LOCK_STALE_SECONDS:
            return _fail("The lock is recent, so another save may still be running. Wait 10 minutes, then try again.")
        lock.unlink()
        return {"ok": True, "changed": True, "passed": False, "cleared": True, "errors": []}
    except (details._Invalid, dw._DraftError, OSError, ValueError, TypeError, KeyError, AttributeError, yaml.YAMLError) as error:
        return _fail(error if isinstance(error, (details._Invalid, dw._DraftError)) else "The stale lock could not be cleared. Ask your data expert to remove it.")


def _placeholder(value):
    text = str(value if value is not None else "").strip().strip("\"'")
    return not text or bool(cl.PLACEHOLDER_VALUE_RE.match(text))


def _as_mapping(value):
    if isinstance(value, dict):
        return value
    if isinstance(value, str) and value.strip().startswith("{"):
        try:
            parsed = yaml.safe_load(value)
        except yaml.YAMLError:
            return None
        return parsed if isinstance(parsed, dict) else None
    return None


def _is_answered(field, value, stub):
    """A judgment field carries a real value when it is not blank, a placeholder, or the stub's start."""
    default = stub.get(field)
    mapping, default_mapping = _as_mapping(value), _as_mapping(default)
    if mapping is not None and default_mapping is not None:
        return any(not _placeholder(item) and item != default_mapping.get(key) for key, item in mapping.items())
    if isinstance(value, str):
        text = value.strip()
        return not _placeholder(text) and text != str(default if default is not None else "").strip()
    if isinstance(value, (list, dict)):
        return bool(value) and value != default and value != ["none"]
    return value not in (None, "")


def answered_fields(values):
    """The judgment fields a person has actually answered; empty means nothing but placeholders (DL-08)."""
    stub = yaml.safe_load(cs.judgment_stub(str(values.get("variable_id") or "X")))
    if not isinstance(stub, dict):
        stub = {}
    return [field for field in cs.JUDGMENT_FIELDS if _is_answered(field, values.get(field), stub)]


def folded_fields(values):
    """Judgment fields whose line breaks the one-line contract row will turn into spaces (DL-12)."""
    return [field for field in cs.JUDGMENT_FIELDS
            if isinstance(values.get(field), str) and ("\n" in values[field] or "\r" in values[field])]


def _hash(value):
    raw = value if isinstance(value, bytes) else json.dumps(value, sort_keys=True, ensure_ascii=False).encode("utf-8")
    return hashlib.sha256(raw).hexdigest()


def _safe(path):
    if path.resolve() != path:
        raise details._Invalid("A definition input or draft redirects to another location.")
    return path


def _read(path):
    _safe(path)
    if not path.is_file() or path.stat().st_size > LIMIT:
        raise details._Invalid("A definition input is missing or exceeds the 4 MB editor limit: " + path.name)
    return path.read_bytes()


def _scope(root, pack, actor_id, allowed_packs):
    source, pack = details._paths(root, pack, allowed_packs)
    _base, _name, owner, _directory = dw._store(root, pack, actor_id, allowed_packs)
    product = source.parent
    # The canonical lint can follow config-controlled variable/codelist reads.
    # Scope them before any canonical reader, including in disposable copies.
    for name in ("data_product.yaml", "pipeline.yaml"):
        path = _safe(product / "config" / name)
        if not path.is_file():
            continue
        document = yaml.load(_read(path), Loader=details._StrictLoader)
        if not isinstance(document, dict):
            raise details._Invalid("The configuration must contain a YAML mapping before a definition can be checked.")
        variables, codelists = document.get("variables") or [], document.get("codelists") or {}
        if not isinstance(variables, list) or not isinstance(codelists, dict):
            raise details._Invalid("Variable and codelist references need the existing configuration schema.")
        for ref in [*variables, *codelists.values()]:
            if not isinstance(ref, str) or Path(ref).is_absolute() or ".." in Path(ref).parts:
                raise details._Invalid("A configuration reference leaves this product. Repair its declared metadata path before checking a definition.")
            target = _safe(product / ref)
            if not target.is_relative_to(product):
                raise details._Invalid("Configuration metadata must stay inside the selected product.")
    folder = _safe(product / ".portal-drafts" / "definitions" / owner[:DIGEST_CHARS])
    return product, pack, owner, folder


def _snapshot(product):
    import workflow_outputs
    files = {}
    root = product.parents[3]
    references = workflow_outputs.declared_references(product, _read)
    # Bind every input used by the canonical contract lint, including config and
    # question registers. Private drafts never become governed validation inputs.
    for path in sorted(product.rglob("*")):
        if ".portal-drafts" in path.relative_to(product).parts:
            continue
        _safe(path)
        if workflow_outputs.is_saved_output(path.relative_to(root).as_posix()) and path.resolve() not in references:
            continue
        if path.is_file() and not path.name.endswith((".lock", ".tmp")):
            files[path.relative_to(product).as_posix()] = _hash(path.read_bytes())
    for name in SHARED_INPUTS:
        path = _safe(root / name)
        files["shared:" + name] = _hash(_read(path)) if path.is_file() else None
    return _hash(files)


def _values(values):
    if not isinstance(values, dict) or set(values) != set(FIELDS):
        raise details._Invalid("Supply only the displayed judgment fields; source citations, source wording and statuses are supplied by the workflow.")
    # Literal strings/lists/mappings only, with a bounded nesting/size envelope.
    def walk(value, depth=0):
        if depth > 5:
            raise details._Invalid("A judgment is nested too deeply.")
        if isinstance(value, str):
            if len(value) > 12000 or any(ord(c) < 32 and c not in "\n\r\t" for c in value):
                raise details._Invalid("A judgment exceeds its text limit or contains control characters.")
        elif isinstance(value, list):
            for child in value:
                walk(child, depth + 1)
        elif isinstance(value, dict):
            for key, child in value.items():
                if not isinstance(key, str):
                    raise details._Invalid("Judgment field names must be text.")
                walk(key, depth + 1)
                walk(child, depth + 1)
        elif not isinstance(value, (bool, int, float, type(None))):
            raise details._Invalid("A judgment contains an unsupported value.")
    walk(values)
    raw = json.dumps(values, allow_nan=False, ensure_ascii=False).encode("utf-8")
    if len(raw) > 128 * 1024:
        raise details._Invalid("This row draft is too large.")
    if not isinstance(values["variable_id"], str) or not re.fullmatch(r"[A-Za-z][A-Za-z0-9_]{0,79}", values["variable_id"]):
        raise details._Invalid("Use a variable identifier beginning with a letter, containing only letters, digits and underscores.")
    return json.loads(raw)


def _json(raw):
    def object_fields(pairs):
        result = {}
        for key, value in pairs:
            if key in result:
                raise details._Invalid("The saved draft repeats a field. Repair or remove that draft before reopening this row.")
            result[key] = value
        return result
    return json.loads(raw, object_pairs_hook=object_fields)


def _surrounding_text(text):
    """Prose and other tables must survive a single definition update unchanged."""
    kept, in_records = [], False
    for line in text.splitlines(True):
        if not line.lstrip().startswith("|"):
            in_records = False
        elif not in_records:
            cells = [cl._unpipe(cell).lower() for cell in re.split(r"(?<!\\)\|", line.strip())[1:-1]]
            in_records = "variable_id" in cells
        if not in_records:
            kept.append(line)
    return "".join(kept).strip()


def _draft_name(item_id, chars=DIGEST_CHARS):
    if not isinstance(item_id, str) or not re.fullmatch(r"[A-Za-z0-9_.-]+:[1-9][0-9]*", item_id):
        raise details._Invalid("Choose one explicit specification row before saving a definition.")
    return _hash(item_id)[:chars] + ".json"


def _draft_path(folder, item_id):
    """Where a row draft is written: the short names."""
    return _safe(folder / _draft_name(item_id))


def _saved_draft_path(product, owner, folder, item_id):
    """Where a row draft is read from: the short names, else the long names an earlier portal wrote
    (still readable), else the short names for a draft that does not exist yet."""
    short = _draft_path(folder, item_id)
    if short.exists():
        return short
    legacy = _safe(product / ".portal-drafts" / "definitions" / owner[:LEGACY_DIGEST_CHARS]
                   / _draft_name(item_id, LEGACY_DIGEST_CHARS))
    return legacy if legacy.exists() else short


def _requirements(data, blocks):
    rows = []
    for row in requirement_rows(data):
        if is_context(row) or not row.get("variable"):
            continue
        ref = row_item_id(row)
        definition, notes = cs._definition_and_notes(row)
        rows.append({"item_id": ref, "variable_id": cs._scalar(row["variable"]),
                     "definition": definition, "notes": notes,
                     "existing": [b for b in blocks if ref in (cl._list(b, "spec_refs") or [])],
                     "tab": row.get("tab") or row.get("domain"), "row": row["row"],
                     "spec_fields": row.get("fields") if isinstance(row.get("fields"), dict) else {}})
    if any(count > 1 for count in Counter(row["item_id"] for row in rows).values()):
        raise details._Invalid("The extraction repeats a specification row identifier. Regenerate it before choosing which requirement to edit.")
    return rows


def _load_draft(path, pack, owner, item_id):
    saved = _json(_read(path))
    if not isinstance(saved, dict) or set(saved) != {"pack", "owner", "item_id", "values", "extraction_sha256", "draft_only", "approved"}:
        raise details._Invalid("The saved row draft has an unsupported format. Repair or remove it before reopening this row.")
    if saved["draft_only"] is not True or saved["approved"] is not False:
        raise details._Invalid("A saved row draft cannot claim approval or another workflow state.")
    if saved.get("pack") != pack or saved.get("owner") != owner or saved.get("item_id") != item_id:
        raise details._Invalid("The saved row draft belongs to another product, row or editing identity.")
    return {**saved, "values": _values(saved["values"])}


def same_answers(left, right):
    """Compare form and stored answers through the existing contract representation."""
    def canonical(value):
        if _placeholder(value):
            return "TODO"
        return cl._unpipe(cl.pipe(cl.inline(value))).strip()
    def field_value(key, value):
        # Merely opening the source section presents an implicit vendor mapping
        # with an explicit kind. Equivalent map ordering and display defaults
        # must not turn an unedited checked definition into a new draft.
        if key in {"source", "output", "publish", "missing", "tie_break"}:
            mapping = _as_mapping(value)
            if mapping is not None:
                mapping = dict(mapping)
                if key == "source" and (mapping.get("logical_table") or mapping.get("physical_stem")):
                    mapping.setdefault("kind", "vendor")
                def ordered(item):
                    if isinstance(item, dict):
                        return {str(name): ordered(child) for name, child in sorted(item.items(), key=lambda pair: str(pair[0]))}
                    if isinstance(item, list):
                        return [ordered(child) for child in item]
                    return canonical(item)
                return ordered(mapping)
        return canonical(value)
    return all(canonical(left.get(key)) == canonical(right.get(key)) or
               field_value(key, left.get(key)) == field_value(key, right.get(key)) for key in FIELDS)


@lru_cache(maxsize=16)
def _queue_lint(product_path, input_digest):
    # Only the immutable lint result is cached. The key covers the same inputs
    # as row validation; actor drafts and unsaved typing are read on every run.
    errors, count = cl.run(product_path)
    return tuple(errors), count


def work_queue(root, pack, actor_id, *, allowed_packs=None):
    """Current writing progress, never approval, scoped to one editing identity."""
    try:
        product, pack, owner, folder = _scope(root, pack, actor_id, allowed_packs)
        digest = _snapshot(product)
        raw = _read(product / "spec_pipeline/out/extracted.json")
        data = _json(raw)
        if not isinstance(data, dict) or not isinstance(data.get("rows"), list):
            raise details._Invalid("Regenerate the extraction before reviewing definition progress.")
        text = _read(product / "handoff/FUNCTIONAL_CONTRACT.md").decode("utf-8")
        blocks = list(cl.records(text))
        rows = _requirements(data, blocks)
        errors, checked_count = _queue_lint(str(product), digest) if blocks else ((), 0)
        decisions = product / "handoff/DECISIONS.md"
        decision_text = _read(decisions).decode("utf-8") if decisions.exists() else ""
        decision_status = cl.decision_status(decision_text)
        incomplete_inputs = bool(cl.decision_register_errors(decision_text, product.name)) or any(
            not (product / "spec_pipeline/out" / name).is_file() or cl.pipeline_payload_error(str(product), name)
            for name in cl.PIPELINE_REQUIRED_KEYS)
        try:
            cs.human_gate(str(product))
            source_blocker = ""
        except cs.SourceNotReviewed:
            source_blocker = "The current specification still needs its recorded source review."
        structural = bool(cl.table_shape_errors(text)) or bool(list(cl._fenced_blocks(text))) or checked_count != len(blocks)
        extraction_digest = _hash(raw)
        result = []
        for row in rows:
            existing = row.pop("existing")
            status, reason = "Untouched", "Write this requirement's interpretation."
            contract_values = None
            if existing:
                if len(existing) != 1 or structural:
                    status, reason = "Unresolved", "The contract needs an explicit record or structure repair."
                else:
                    block = existing[0]
                    vid = cl._scalar(block, "variable_id") or ""
                    contract_values = {key: cl._scalar(block, key) or "" for key in FIELDS}
                    findings = [error for error in errors if f"[{vid}]" in error or
                                ("depends_on cycle:" in error and re.search(r"\b" + re.escape(vid) + r"\b", error))]
                    if source_blocker:
                        status, reason = "Unresolved", source_blocker
                    elif incomplete_inputs:
                        status, reason = "Unresolved", "The current extraction or scientific question register needs repair before the row can be checked."
                    elif findings:
                        status, reason = "Unresolved", "The current saved record has validator findings; review this row."
                    elif cl.blocking_decisions(cl._list(block, "decision_ids") or [], decision_status):
                        status, reason = "Unresolved", "A cited scientific question is still open."
                    elif cl.TODO_RE.search(block) or not answered_fields(contract_values):
                        status, reason = "Unresolved", "The saved record still contains unanswered details."
                    else:
                        status, reason = "Checked", "The saved definition passes its current record checks. Scientific review is separate."
            path = _saved_draft_path(product, owner, folder, row["item_id"])
            draft_digest, draft_values = "", None
            if path.exists():
                draft_digest = _hash(_read(path))
                try:
                    saved = _load_draft(path, pack, owner, row["item_id"])
                    draft_values = saved["values"]
                    if saved.get("extraction_sha256") != extraction_digest:
                        status, reason = "Unresolved", "The extraction changed after your row draft was saved. Compare its source."
                    elif contract_values is None or not same_answers(draft_values, contract_values):
                        status, reason = "Draft", "Your saved row draft has not been checked and saved to the current contract."
                except (details._Invalid, ValueError, TypeError, KeyError, RecursionError, yaml.YAMLError):
                    status, reason = "Unresolved", "Your saved row draft needs repair before it can be reopened."
            result.append({**row, "work_status": status, "work_reason": reason,
                           "draft_digest": draft_digest, "values": draft_values or contract_values})
        if _snapshot(product) != digest:
            raise details._Invalid("The product changed while progress was checked. Reload to see its current rows.")
        return {"ok": True, "errors": [], "rows": result, "input_digest": digest,
                "extraction_sha256": extraction_digest,
                "counts": dict(Counter(row["work_status"] for row in result)),
                "total": len(result), "approved": False}
    except (details._Invalid, dw._DraftError, OSError, ValueError, TypeError, KeyError, AttributeError, RecursionError, yaml.YAMLError) as error:
        return _fail(error)


def describe(root, pack, actor_id, *, item_id=None, allowed_packs=None):
    try:
        product, pack, owner, folder = _scope(root, pack, actor_id, allowed_packs)
        input_digest = _snapshot(product)
        raw = _read(product / "spec_pipeline/out/extracted.json")
        data = _json(raw)
        if not isinstance(data, dict) or not isinstance(data.get("rows"), list):
            raise details._Invalid("The extraction must contain its envelope and source rows. Regenerate the extraction before opening definitions.")
        text = _read(product / "handoff/FUNCTIONAL_CONTRACT.md").decode("utf-8").replace("\r\n", "\n")
        blocks = list(cl.records(text))
        rows = _requirements(data, blocks)
        selected = next((r for r in rows if r["item_id"] == (item_id if item_id is not None else (rows[0]["item_id"] if rows else ""))), None)
        if selected is None:
            raise details._Invalid("Choose a named requirement from the current extraction. Unnamed requirements need the scientific question workflow.")
        selected = dict(selected)
        existing = selected.pop("existing")
        # One source row driving multiple records needs an explicit engineering
        # decision about the record to change, rather than silently picking one.
        if len(existing) > 1:
            raise details._Invalid("This specification row has several contract records. Ask your data expert to split the revision into explicit record updates.")
        selected["contract_variable_id"] = cl._scalar(existing[0], "variable_id") if existing else ""
        if existing:
            values = {key: cl._scalar(existing[0], key) or "" for key in FIELDS}
        else:
            vid = re.sub(r"[^A-Za-z0-9_]", "_", selected["variable_id"].split("<br>")[0].strip())[:40].upper()
            values = yaml.safe_load(cs.judgment_stub(vid))
        path = _saved_draft_path(product, owner, folder, selected["item_id"])
        saved, stale = None, False
        if path.exists():
            saved = _load_draft(path, pack, owner, selected["item_id"])
            values = saved["values"]
            stale = saved.get("extraction_sha256") != _hash(raw)
        # Two gates, two questions. The human gate decides whether this editor may write a row at
        # all; the AI gate only decides whether the AI helper may read the row. Neither is a client
        # choice: the operation is a person drafting, so the operation names the reader.
        try:
            cs.human_gate(str(product))
            blocker = ""
        except cs.SourceNotReviewed as error:
            blocker = str(error)
        try:
            cs.ai_gate(str(product))
            ai_blocker = ""
        except cs.NotApprovedForAI as error:
            ai_blocker = str(error)
        if _snapshot(product) != input_digest:
            raise details._Invalid("The product changed while the row was loading. Reload its current source and draft.")
        return {"ok": True, "errors": [], "rows": [{k: v for k, v in r.items() if k != "existing"} for r in rows],
                "selected": selected, "values": values, "contract_count": len(blocks),
                "extraction_sha256": _hash(raw), "input_digest": input_digest,
                "draft_digest": _hash(_read(path)) if path.exists() else "", "saved": saved is not None,
                "stale_draft": stale, "apply_blocker": blocker, "ai_help_blocker": ai_blocker}
    except (details._Invalid, dw._DraftError, cs.SourceNotReviewed, cs.NotApprovedForAI, OSError, ValueError, TypeError, KeyError, AttributeError, RecursionError, yaml.YAMLError) as error:
        return _fail(error)


def _atomic(path, payload, check=None):
    temporary = None
    try:
        with tempfile.NamedTemporaryFile(mode="wb", dir=path.parent, prefix=".definition-", suffix=".tmp", delete=False) as handle:
            temporary = Path(handle.name)
            handle.write(payload)
            handle.flush()
            os.fsync(handle.fileno())
        _safe(path)
        if check is not None:
            check()
        os.replace(temporary, path)
    finally:
        if temporary is not None:
            temporary.unlink(missing_ok=True)


def save_draft(root, pack, actor_id, item_id, values, *, expected_input_digest, expected_draft_digest,
               local_demo, can_write, allowed_packs=None):
    lock_fd = None
    lock = None
    try:
        if local_demo is not True or can_write is not True:
            raise details._Invalid("Saving a definition requires an authorized local editing session.")
        values = _values(values)
        product, pack, owner, folder = _scope(root, pack, actor_id, allowed_packs)
        folder.mkdir(parents=True, exist_ok=True)
        path = _draft_path(folder, item_id)
        lock = path.with_suffix(".lock")
        try:
            lock_fd = os.open(lock, os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o600)
        except FileExistsError:
            return _lock_result(lock)
        current = describe(root, pack, actor_id, item_id=item_id, allowed_packs=allowed_packs)
        if not current["ok"]:
            raise details._Invalid(" ".join(current["errors"]))
        if current["input_digest"] != expected_input_digest or current["draft_digest"] != expected_draft_digest:
            raise details._Invalid("The product or this saved draft changed. Reload the row before saving; your current text is still in the form.")
        envelope = {"pack": pack, "owner": owner, "item_id": item_id, "values": values,
                    "extraction_sha256": current["extraction_sha256"], "draft_only": True, "approved": False}
        def still_current():
            saved_at = _saved_draft_path(product, owner, folder, item_id)     # the file describe() read, long names included
            if _snapshot(product) != expected_input_digest or (_hash(_read(saved_at)) if saved_at.exists() else "") != expected_draft_digest:
                raise details._Invalid("The product or saved draft changed during the save. Reload before trying again.")
        _atomic(path, json.dumps(envelope, indent=2, ensure_ascii=False).encode("utf-8"), check=still_current)
        return {"ok": True, "changed": True, "draft_only": True, "errors": [], "path": str(path)}
    except (details._Invalid, dw._DraftError, OSError, ValueError, TypeError, KeyError, AttributeError, yaml.YAMLError) as error:
        return _fail(error)
    finally:
        if lock_fd is not None:
            os.close(lock_fd)
            lock.unlink(missing_ok=True)


def _name_reviews(root, pack, after, variable_id, allowed_packs, naming_packs):
    """Compare accessible scientific records using the existing reuse authority."""
    import concept_reuse
    scope = set(naming_packs if naming_packs is not None else
                allowed_packs if allowed_packs is not None else [pack])
    scope.add(pack)
    for peer in scope:
        details._paths(root, peer, scope)
    reviews = concept_reuse.physical_name_reviews(pack, root=str(Path(root).resolve()),
                                                contract_text=after, pack_scope=scope)
    return [row for row in reviews if row["variable_id"] == variable_id], sorted(scope)


def preview(root, pack, actor_id, item_id, values, *, expected_input_digest, allowed_packs=None, naming_packs=None):
    try:
        values = _values(values)
        product, scoped_pack, owner, _folder = _scope(root, pack, actor_id, allowed_packs)
        current = describe(root, pack, actor_id, item_id=item_id, allowed_packs=allowed_packs)
        if not current["ok"]:
            raise details._Invalid(" ".join(current["errors"]))
        if current["input_digest"] != expected_input_digest:
            raise details._Invalid("The product changed while this row was open. Reload it and review the current source before validating.")
        if current["selected"]["contract_variable_id"] and current["selected"]["contract_variable_id"] != values["variable_id"]:
            raise details._Invalid("Renaming an existing definition affects its dependents. Keep its current identifier here and use an engineering handoff for the rename.")
        # reader="human" is the operation speaking, not a form field: a person is drafting this
        # row and no model reads it, so the specification's review is what gates the words.
        rec, problems = cr.merge_evidence(values, str(product), item_id, reader="human")
        if problems:
            return {**_fail(" ".join(problems)), "problems": problems}
        contract = product / "handoff/FUNCTIONAL_CONTRACT.md"
        before = _read(contract).decode("utf-8").replace("\r\n", "\n")
        if any(cl._fenced_blocks(before)):
            raise details._Invalid("This contract contains legacy fenced definition records. Engineering must convert and check all records together before this row editor can update them; a new table would hide the existing records.")
        structure_errors = cl.table_shape_errors(before)
        if structure_errors:
            raise details._Invalid("Repair the contract's table shape before editing one row: " + " ".join(structure_errors))
        existing_ids = [cl._scalar(block, "variable_id") or "" for block in cl.records(before, keep_unnamed=True)]
        if any(not name for name in existing_ids) or len(set(name.casefold() for name in existing_ids)) != len(existing_ids):
            raise details._Invalid("The contract contains unnamed or duplicate definition identifiers. Repair that ambiguity before updating one row.")
        if any(name.casefold() == values["variable_id"].casefold() and name != values["variable_id"] for name in existing_ids):
            raise details._Invalid("That identifier differs only in case from an existing definition. Use its current identifier or an explicit rename handoff.")
        existing = next((b for b in cl.records(before) if cl._scalar(b, "variable_id") == values["variable_id"]), None)
        if existing and item_id not in (cl._list(existing, "spec_refs") or []):
            raise details._Invalid("That variable identifier already belongs to another specification row. Choose an explicit distinct identifier for this record.")
        if existing and len(cl._list(existing, "spec_refs") or []) != 1:
            raise details._Invalid("This record combines multiple specification rows. Ask your data expert to preserve every citation in an explicit engineering handoff.")
        moved = cr.requirement_changes(rec, existing)
        status = cr._status_map({"status": cl._scalar(existing, "status")}) if existing else None
        decisions = product / "handoff/DECISIONS.md"
        dec_open = cl.decision_status(_read(decisions).decode("utf-8")) if decisions.exists() else {}
        register_errors = cl.decision_register_errors(_read(decisions).decode("utf-8") if decisions.exists() else "", product.name)
        if register_errors:
            raise details._Invalid(" ".join(register_errors))
        for name in cl.PIPELINE_REQUIRED_KEYS:
            path = product / "spec_pipeline/out" / name
            problem = cl.pipeline_payload_error(str(product), name)
            if not path.is_file() or problem:
                raise details._Invalid(problem or f"Regenerate the complete extraction: spec_pipeline/out/{name} is missing.")
        rec, problems = cr.apply_status(rec, status, dec_open=dec_open, reopen=bool(moved))
        _row, row_problems = cr.row_for(rec)
        problems += row_problems
        # NOTHING TO SAVE YET (DL-08). A row whose every judgment is TODO or the stub's own starting
        # value passed the row checks and could be written to the contract as a definition of nothing.
        # The draft store still takes it; the contract does not.
        if not answered_fields(values):
            problems.append(NO_JUDGMENT_MESSAGE)
        after = cr.upsert(before, [rec])
        with tempfile.TemporaryDirectory(prefix="definition-check-") as temporary:
            staged_root = Path(temporary)
            staged = staged_root / scoped_pack
            (staged_root / "platform/tools").mkdir(parents=True)
            shutil.copytree(product, staged, ignore=shutil.ignore_patterns(".portal-drafts", "*.lock", "*.tmp"))
            for name in SHARED_INPUTS:
                source = _safe(Path(root).resolve() / name)
                if source.is_file():
                    target = staged_root / name
                    target.parent.mkdir(parents=True, exist_ok=True)
                    target.write_bytes(_read(source))
            baseline_errors, _baseline_count = cl.run(str(staged))
            (staged / "handoff/FUNCTIONAL_CONTRACT.md").write_text(after, encoding="utf-8", newline="\n")
            errors, record_count = cl.run(str(staged))
        record_errors = [e for e in errors if f"[{values['variable_id']}]" in e]
        # Cross-record invariants, such as cycles, can be tagged with a different
        # variable. An edit must not introduce one just because its tag differs.
        problems += list(dict.fromkeys([*record_errors, *(error for error in errors if error not in baseline_errors)]))
        before_other = [block for block in cl.records(before, keep_unnamed=True) if cl._scalar(block, "variable_id") != values["variable_id"]]
        after_other = [block for block in cl.records(after, keep_unnamed=True) if cl._scalar(block, "variable_id") != values["variable_id"]]
        actual = [block for block in cl.records(after) if cl._scalar(block, "variable_id") == values["variable_id"]]
        expected = list(cl.records(cl.render_table([rec])))
        if before_other != after_other or actual != expected or _surrounding_text(before) != _surrounding_text(after):
            problems.append("The rendered update changes or hides another definition. Use an explicit engineering handoff instead of saving this row.")
        name_reviews, naming_scope = _name_reviews(root, scoped_pack, after, values["variable_id"], allowed_packs, naming_packs)
        # Mirror contract_record's record-scoped lint boundary while showing all
        # remaining pack findings separately. A row save never means Gate 2 passes.
        if _snapshot(product) != expected_input_digest:
            raise details._Invalid("The product changed during validation. Reload before trying again.")
        return {"ok": True, "passed": not problems, "errors": problems,
                "warnings": [row["question"] for row in name_reviews if not row["resolved"]],
                "name_reviews": name_reviews, "record_count": record_count,
                "folded_fields": folded_fields(values),
                "pack_findings": [e for e in errors if e not in record_errors], "after": after,
                "diff": "".join(difflib.unified_diff(before.splitlines(True), after.splitlines(True), fromfile="Current functional contract", tofile="Proposed draft record")),
                "reopened": bool(moved and status and status != cr.INITIAL_STATUS),
                "manifest_digest": _hash({"pack": scoped_pack, "owner": owner, "input": expected_input_digest, "item": item_id,
                                          "values": values, "after": after, "name_reviews": name_reviews, "naming_scope": naming_scope}),
                "input_digest": expected_input_digest, "values": values, "item_id": item_id}
    except (details._Invalid, dw._DraftError, cs.SourceNotReviewed, cs.NotApprovedForAI, OSError, ValueError, TypeError, KeyError, AttributeError, yaml.YAMLError) as error:
        return _fail(error)


def apply(root, pack, actor_id, item_id, values, *, expected_input_digest, expected_manifest_digest,
          confirmed, local_demo, can_write, allowed_packs=None, naming_packs=None):
    lock_fd = None
    lock = None
    try:
        if local_demo is not True or can_write is not True or confirmed is not True:
            raise details._Invalid("Saving to the contract requires an authorized local editor and confirmation of the displayed row diff.")
        product, _pack, _owner, _folder = _scope(root, pack, actor_id, allowed_packs)
        target = _safe(product / "handoff/FUNCTIONAL_CONTRACT.md")
        lock = _contract_lock(product)
        try:
            lock_fd = os.open(lock, os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o600)
        except FileExistsError:
            return _lock_result(lock)
        checked = preview(root, pack, actor_id, item_id, values, expected_input_digest=expected_input_digest,
                          allowed_packs=allowed_packs, naming_packs=naming_packs)
        if not checked["ok"] or not checked["passed"]:
            return checked
        if checked["manifest_digest"] != expected_manifest_digest:
            raise details._Invalid("The reviewed proposal changed. Preview the exact row again before saving it to the contract.")
        if _snapshot(product) != expected_input_digest:
            raise details._Invalid("The product changed during the save. Reload before trying again.")
        def still_current():
            if _snapshot(product) != expected_input_digest:
                raise details._Invalid("The product changed immediately before saving. Reload the row and validate its current source.")
            reviews, _scope_names = _name_reviews(root, _pack, checked["after"], values["variable_id"], allowed_packs, naming_packs)
            if reviews != checked["name_reviews"]:
                raise details._Invalid("A compared definition or its naming review changed. Preview the row again before saving.")
        _atomic(target, checked["after"].encode("utf-8"), check=still_current)
        return {**checked, "changed": True, "approved": False, "released": False}
    except (details._Invalid, dw._DraftError, cs.SourceNotReviewed, OSError, ValueError, TypeError, KeyError, AttributeError, yaml.YAMLError) as error:
        return _fail(error)
    finally:
        if lock_fd is not None:
            os.close(lock_fd)
            lock.unlink(missing_ok=True)
