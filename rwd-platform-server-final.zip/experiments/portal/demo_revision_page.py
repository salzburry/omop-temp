"""Edit a saved rehearsal in the page while retaining its previous run results."""
from __future__ import annotations

import copy
import hashlib
import uuid

import streamlit as st

import demo_journey as journeys
import demo_revisions as revisions


def _clear():
    for key in list(st.session_state):
        if key.startswith("demo_edit_") or key == "demo_revision_editor":
            del st.session_state[key]


def _begin(snapshot):
    _clear()
    record, plan = snapshot["run"], snapshot["run"]["plan"]
    st.session_state.demo_revision_editor = {
        "run_id": record["id"], "snapshot": snapshot,
        "label": record["label"], "purpose": plan["purpose"],
        "studies": "\n".join(plan["studies"]), "sections": plan["retained_sections"][:],
        "source": plan["proposed_source"], "modality": plan["proposed_modality"],
        "definitions": {row["key"]: row["definition"] for row in snapshot["definitions"]},
        "additions": [{**copy.deepcopy(row), "_key": uuid.uuid4().hex[:12]}
                      for row in plan["proposed_additions"]],
    }


def _remember(field, key, definition=None, addition=None):
    draft = st.session_state.get("demo_revision_editor")
    if draft is None:
        return
    value = st.session_state.get(key)
    if definition is not None:
        draft["definitions"][definition] = value
    elif addition is not None:
        for row in draft["additions"]:
            if row["_key"] == addition:
                row[field] = value
    else:
        draft[field] = value


def _widget(draft, field):
    key = "demo_edit_" + field
    st.session_state.setdefault(key, draft[field])
    return {"key": key, "on_change": _remember, "args": (field, key)}


def _issues(result):
    for error in result.get("errors") or []:
        st.error(str(error))


def _additions(draft):
    with st.expander("Proposed new definitions", expanded=bool(draft["additions"])):
        st.caption("New variables remain proposals for implementation review. They do not generate executable derivations.")
        for index, row in enumerate(draft["additions"], 1):
            st.write(f"Proposed addition {index}")
            for field, label in (("variable_id", "New variable identifier"), ("domain", "Section"),
                                 ("definition", "Proposed definition")):
                key = f"demo_edit_addition_{row['_key']}_{field}"
                st.session_state.setdefault(key, row[field])
                args = {"key": key, "on_change": _remember, "args": (field, key, None, row["_key"])}
                if field == "definition":
                    st.text_area(label, max_chars=4000, **args)
                elif field == "domain":
                    options = list(dict.fromkeys([*journeys.SECTIONS, row[field]]))
                    st.selectbox(label, options, **args)
                else:
                    st.text_input(label, max_chars=80, **args)
            if st.button("Remove this proposed addition", key="demo_edit_remove_" + row["_key"]):
                draft["additions"] = [item for item in draft["additions"] if item["_key"] != row["_key"]]
                st.rerun()
        if st.button("Add a proposed definition", key="demo_edit_add", disabled=len(draft["additions"]) >= 30):
            draft["additions"].append({"variable_id": "", "domain": "outcomes", "definition": "", "_key": uuid.uuid4().hex[:12]})
            st.rerun()


def render(root, state_root, actor_id, record, *, allowed, local_demo, can_write):
    """Return true while editing so the parent does not show old completion as current."""
    current = st.session_state.get("demo_revision_editor")
    if current and current["run_id"] != record["id"]:
        _clear()
        current = None
    if not current:
        if st.button("Edit this rehearsal", key="demo_edit", disabled=not allowed or record["stage"] == "running"):
            result = revisions.read_editor(root, state_root, actor_id, record["id"])
            if result["ok"]:
                _begin(result)
                st.rerun()
            _issues(result)
        return False

    draft, snapshot = current, current["snapshot"]
    st.subheader("Edit this rehearsal")
    st.write("Update the plan and draft scientific definitions here. Save a revision, then rerun its draft checks.")
    st.caption("The previous run stays available. Draft definition edits update the rehearsal's scientific interpretation; "
               "the source wording and executable example configuration are separate.")
    st.text_input("Rehearsal name", max_chars=120, **_widget(draft, "label"))
    st.text_area("Study question", max_chars=4000,
                 help="Describe the question this rehearsal should help answer. Example: Describe treatment patterns after the study index date.",
                 **_widget(draft, "purpose"))
    st.text_area("Intended studies (one per line)", max_chars=3000,
                 help="Enter the names or identifiers of the studies that would use these definitions, one per line.",
                 **_widget(draft, "studies"))
    st.multiselect("Sections proposed for this revision", journeys.SECTIONS,
                   format_func=lambda value: value.replace("_", " ").title(), **_widget(draft, "sections"))
    left, right = st.columns(2)
    with left:
        st.text_input("Proposed data source", max_chars=120, **_widget(draft, "source"))
    with right:
        st.selectbox("Proposed source type", ["ehr", "claims"], format_func=str.upper, **_widget(draft, "modality"))

    st.write("**Draft scientific definitions**")
    definitions = snapshot["definitions"]
    if definitions:
        choices = {row["key"]: row for row in definitions}
        picker = "demo_edit_definition_choice"
        if st.session_state.get(picker) not in choices:
            st.session_state[picker] = draft.get("definition_choice") if draft.get("definition_choice") in choices else next(iter(choices))
        choice = st.selectbox("Definition to edit", list(choices), key=picker,
                              format_func=lambda key: f"{choices[key]['variable_id']} · " + ", ".join(choices[key].get("spec_refs") or [choices[key]["domain"]]),
                              on_change=_remember, args=("definition_choice", picker))
        row = choices[choice]
        st.caption("Original specification wording")
        st.text(row["source_definition"] or "No definition wording is recorded for this source row.")
        key = "demo_edit_definition_" + hashlib.sha256(choice.encode()).hexdigest()[:12]
        st.session_state.setdefault(key, draft["definitions"][choice])
        st.text_area("Your draft definition / interpretation", key=key, max_chars=4000, height=160,
                     on_change=_remember, args=("definitions", key, choice))
        st.caption("State the intended rule, timing, and missing-data handling. Source citations remain attached; "
                   "your interpretation needs scientific review before implementation.")
        with st.expander("How to write a draft definition", expanded=True):
            st.write("Describe which observation to use, its timing relative to the study index date, how to choose between multiple observations, "
                     "and what to do when a value is missing. Name any other variable needed by the rule.")
            st.write("**Illustrative example only:** For a hypothetical baseline measurement, use the most recent value on or before the index date "
                     "within the agreed baseline window. If none is available, leave it missing. This depends on the index date. "
                     "The window length and same-day tie rule still need a scientific decision.")
            st.caption("Replace the example with your team's intended rule. If a choice is unresolved, state the question explicitly; "
                       "saving a draft does not resolve it or approve the definition.")
    else:
        st.info("Run the rehearsal once to generate the specification rows for editing. You can update the plan now.")
    _additions(draft)

    if st.button("Save revision", key="demo_edit_save", type="primary", disabled=not allowed):
        result = revisions.revise(
            root, state_root, actor_id, record["id"], base_sha256=snapshot["base_sha256"],
            label=draft["label"], purpose=draft["purpose"],
            studies=[line.strip() for line in draft["studies"].splitlines() if line.strip()],
            sections=draft["sections"], proposed_source=draft["source"], proposed_modality=draft["modality"],
            additions=[{key: row[key] for key in ("variable_id", "domain", "definition")} for row in draft["additions"]],
            definitions=[{"key": key, "definition": value} for key, value in draft["definitions"].items()],
            local_demo=local_demo, can_write=can_write)
        if result["ok"]:
            st.session_state.demo_active_id = result["run"]["id"]
            st.session_state.demo_revision_notice = "Revision saved. Run this revision's checks below to get current results. Your previous run remains available."
            _clear()
            st.rerun()
        _issues(result)
    if st.button("Cancel editing", key="demo_edit_cancel"):
        _clear()
        st.rerun()
    with st.expander("Reload the saved version"):
        st.caption("Reload discards the edits in this form and reopens the selected saved version.")
        if st.button("Reload saved version", key="demo_edit_reload"):
            result = revisions.read_editor(root, state_root, actor_id, record["id"])
            if result["ok"]:
                _begin(result)
                st.rerun()
            _issues(result)
    return True
