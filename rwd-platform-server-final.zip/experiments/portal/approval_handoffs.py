"""A read-only, versioned preparation report for three proposed approval checkpoints.

This module does not implement approvals or claim that grouping tasks has reduced
the number of signing sessions. Its dependency lists expose what an orchestrated
review session still needs to automate before a three-session promise is honest.
"""
from __future__ import annotations

import hashlib
import json
from pathlib import Path

import flow
import flow_guidance as guidance
import product_gates as pg
import source_manifest as sm


CHECKPOINTS = (
    ("source_access", "Source and access", (1,)),
    ("science_configuration", "Scientific definitions, source evidence and configuration", (2, 3, 4)),
    ("validation_release", "Validation and release", (5, 6)),
)

LIMITATIONS = [
    "Three checkpoints are a proposed review workflow, not three implemented approval transactions. This report does not satisfy the three-visit acceptance criterion.",
    "Approving fields watched by approval_identity require the named person's authentication. Supporting fields such as technically_reviewed_by are validated as metadata but are not all separate signature surfaces. The current portal cannot authenticate a repository approval or use an external private signing key for its reviewer.",
    "The current Flow asks for committed answer forms, but decision_record.apply_forms checks their content rather than their signatures. Applying answers changes the decision register, which must then be authenticated; contract drafting and coverage preparation precede the final contract and configuration approvals.",
    "Delivered-data profiling, schema validation and source-QC evidence run in the approved data environment. This local report cannot create or verify a deployed cluster session.",
    "Release approval requires a completed candidate build's exact identifier and manifest digest. Validation, release approval, sealing, countersigning and promotion remain ordered operations, with separate accountable roles.",
    "The target is at most three external approval checkpoints per complete draft-to-release pass. Later revisions can reopen the checkpoint whose evidence changed; the current tools do not yet automate each checkpoint as one transaction.",
]

DEPENDENCIES = {
    "source_access": [
        {"before": "review_source", "after": "identify_source", "reason": "The named reviewer must see the exact workbook and its version."},
        {"before": "review_extraction_access", "after": "prepare_extraction", "reason": "AI-access review concerns the actual redacted extraction, which must exist first."},
        {"before": "seal_source", "after": "authenticate_source_review", "reason": "The source ledger transcribes the existing attribution; it cannot supply a reviewer or signature."},
    ],
    "science_configuration": [
        {"before": "transcribe_answers", "after": "capture_current_answer_forms", "reason": "decision_record --apply validates answers bound to the current question and citing records. It does not verify a form commit or signature; the resulting decision-register attribution is authenticated separately."},
        {"before": "approve_contract", "after": "apply_answers_and_regenerate_coverage", "reason": "The approval binds the resulting requirement content, decision register, findings and coverage."},
        {"before": "approve_configuration", "after": "review_current_source_reports_and_rules", "reason": "Source verdicts bind the current mapping and delivery configuration; the configuration approval also binds the approved contract."},
        {"before": "finish_checkpoint", "after": "authenticate_each_named_reviewer", "reason": "Scientific approval and technical review must remain attributable to their respective people."},
    ],
    "validation_release": [
        {"before": "validate_candidate", "after": "stage_candidate", "reason": "The staged build produces the build identifier, manifest and validation evidence."},
        {"before": "seal_and_countersign_release", "after": "validate_and_approve_exact_candidate", "reason": "The release form names one candidate and the different people who validated and approved it."},
        {"before": "promote_candidate", "after": "record_authenticated_release_evidence", "reason": "Promotion adopts the approved staged bytes rather than building a replacement."},
    ],
}


def _digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, ensure_ascii=False).encode("utf-8")).hexdigest()


def _file(root, target, role, *, required=True):
    path = Path(target)
    path = path if path.is_absolute() else root / path
    try:
        shown = path.relative_to(root).as_posix()
    except ValueError:
        shown = str(path)
    entry = {"path": shown, "role": role, "required": required, "exists": path.is_file(), "sha256": ""}
    if entry["exists"]:
        try:
            entry["sha256"] = sm.sha256(str(path))
        except OSError:
            entry["exists"] = False
            entry["problem"] = "The file cannot be read with current permissions."
    return entry


def _review(root, pack, relative, fields):
    target = root / pack / relative
    doc, error = pg.read_yaml(str(target))
    doc = doc if isinstance(doc, dict) else {}
    return {"path": f"{pack}/{relative}", "exists": target.is_file(),
            "missing_fields": [field for field in fields if sm.field_unstated(doc, field)],
            "read_error": str(error or ""), "authenticated": None}


def _command(action, root):
    argv = action.get("argv") or []
    if not argv or any("<" in str(arg) or ">" in str(arg) for arg in argv):
        return None
    # External runners and signing keys need an environment the local report cannot verify.
    if not (root / argv[0]).is_file():
        return None
    return {"action_id": action["id"], "label": action["label"], "kind": action["kind"], "argv": list(argv)}


def manifest(root, pack, *, previous=None):
    """Return exactly three checkpoint preparations, without writing or approving anything.

    `previous` may be an earlier manifest. A changed checkpoint input invalidates
    that prepared handoff; the report never treats its own snapshot as approval.
    Caller authorization remains responsible for access to the selected pack.
    """
    root = Path(root).resolve()
    product = (root / pack).resolve()
    try:
        relative = product.relative_to(root)
    except ValueError as exc:
        raise ValueError("Select a product inside the current workspace.") from exc
    if product == root or not product.is_dir():
        raise ValueError("The selected product is no longer available.")
    pack = relative.as_posix()
    actions = flow.acts(pack, str(root))
    previous = previous if isinstance(previous, dict) and previous.get("pack") == pack else {}
    old_checkpoints = previous.get("checkpoints", [])
    old_checkpoints = old_checkpoints if isinstance(old_checkpoints, list) else []
    checkpoints = [{"id": cid, "title": title, "gates": list(gates), "files": [], "review_records": [],
                    "prerequisites": [], "person_actions": [], "commands": [],
                    "dependencies": list(DEPENDENCIES[cid])} for cid, title, gates in CHECKPOINTS]
    source, science, release = checkpoints

    def add_file(checkpoint, path, role, required=True):
        entry = _file(root, path, role, required=required)
        if not any(existing["path"] == entry["path"] for existing in checkpoint["files"]):
            checkpoint["files"].append(entry)
        return entry

    def need(checkpoint, code, message, paths=()):
        checkpoint["prerequisites"].append({"code": code, "message": message, "paths": list(paths)})

    add_file(source, f"{pack}/source_refs.yaml", "source and access decisions")
    spec, materials, source_error = guidance._registered_spec(str(product))
    if source_error:
        need(source, "source_register", source_error, [f"{pack}/source_refs.yaml"])
    else:
        for material in materials:
            mid = material["material_id"]
            target = material.get("path_or_link")
            fields = (sm.AI_EXTRACTION_APPROVAL_FIELDS if material.get("material_type") == sm.AI_EXTRACTION else sm.APPROVAL_FIELDS)
            if material.get("material_type") == sm.PROGRAM_SPEC:
                fields = list(fields) + sm.POLICY_FIELDS
            source["review_records"].append({"path": f"{pack}/source_refs.yaml", "material_id": mid,
                "status": material.get("status"), "missing_fields": [f for f in list(fields) + ["ai_classification", "classified_by", "classified_date"] if sm.field_unstated(material, f)],
                "authenticated": None})
            if material.get("status") not in sm.MATERIAL_STATUSES:
                need(source, "unsupported_source_status", f"{mid} uses an unsupported review status; pending and reviewed are different evidence states.", [f"{pack}/source_refs.yaml"])
            if sm.field_unstated(material, "path_or_link") or not isinstance(target, str) or "://" in target:
                need(source, "source_location", f"{mid} needs a locally retrievable registered source before preparation.", [f"{pack}/source_refs.yaml"])
                continue
            actual = Path(sm.material_file(str(product), target, str(root)))
            if actual.is_dir():
                # Registered tab folders have a defined directory digest owned by product_gates.
                try:
                    current = sm.sha256(str(actual))
                    source["files"].append({"path": str(actual.relative_to(root)) if actual.is_relative_to(root) else str(actual),
                        "role": f"registered input {mid}", "required": True, "exists": True, "sha256": current, "kind": "directory"})
                except OSError:
                    need(source, "source_unreadable", f"The registered input {mid} cannot be read.")
                    continue
            else:
                entry = add_file(source, actual, f"registered input {mid}")
                current = entry["sha256"]
            if current and not sm.field_unstated(material, "sha256") and current != str(material["sha256"]):
                need(source, "source_changed", f"{mid} no longer matches its recorded checksum; review the source revision before reusing its prepared handoff.", [str(actual)])
        if not any(m.get("material_type") == sm.AI_EXTRACTION for m in materials):
            need(source, "extraction_registration", "Prepare and register the actual extraction before its access review can be completed.", [f"{pack}/spec_pipeline/out/extracted.json"])
        current_reason = guidance._extraction_reason(root, product, materials, registering=False)
        if current_reason:
            need(source, "current_extraction", current_reason, [f"{pack}/spec_pipeline/out/extracted.json"])
    add_file(source, f"{pack}/spec_pipeline/out/extracted.json", "derived artifact for access review")
    add_file(source, sm.AI_BOUNDARY, "redaction policy")

    for path, role in (("handoff/FUNCTIONAL_CONTRACT.md", "scientific requirements"),
                       ("handoff/DECISIONS.md", "scientific decisions"), ("handoff/SPEC_QC_FINDINGS.md", "specification findings"),
                       ("spec_pipeline/out/COVERAGE.md", "traceability coverage"), ("spec_pipeline/out/extracted.json", "source extraction"),
                       ("config/data_product.yaml", "executable configuration")):
        add_file(science, f"{pack}/{path}", role)
    for directory in ("config", "variables", "codelists"):
        for file in sorted((product / directory).glob("*.yaml")):
            add_file(science, file, "configuration review input")
    try:
        verdicts = pg.verdict_paths(str(product))
    except (OSError, ValueError, TypeError, AttributeError, KeyError):
        verdicts = []
        need(science, "source_configuration", "Repair the source-union configuration before its report paths can be prepared.", [f"{pack}/config/data_product.yaml"])
    for member, path in verdicts:
        add_file(science, f"{pack}/{path}", "source review" + (f" for {member}" if member else ""))
    for file in sorted((product / "handoff/decision_answers").glob("*.yaml")):
        add_file(science, file, "scientific answer form")
    science["review_records"] += [
        _review(root, pack, pg.CONTRACT_APPROVAL, pg.CONTRACT_APPROVAL_FIELDS),
        _review(root, pack, pg.CONFIGURATION_APPROVAL, pg.CONFIGURATION_APPROVAL_FIELDS),
    ]
    if (product / pg.SEMANTIC_YAML).is_file():
        try:
            semantic_errors = pg.semantic_approval_errors(str(product), pack)
        except (OSError, ValueError, TypeError, AttributeError):
            semantic_errors = ["The semantic bindings could not be checked."]
        if semantic_errors or (product / pg.SEMANTIC_APPROVAL).is_file():
            science["review_records"].append(_review(root, pack, pg.SEMANTIC_APPROVAL, pg.SEMANTIC_APPROVAL_FIELDS))
            for error in semantic_errors:
                need(science, "semantic_review", str(error), [f"{pack}/{pg.SEMANTIC_YAML}"])
    if (product / "handoff/DECISIONS.md").is_file():
        import decision_record as dr
        try:
            errors = dr.check_bindings(pack, root=str(root))
        except (OSError, ValueError, TypeError, KeyError, AttributeError):
            errors = ["The decision-to-form bindings could not be checked."]
        for error in errors:
            need(science, "decision_binding", str(error), [f"{pack}/handoff/DECISIONS.md"])

    release["review_records"].append(_review(root, pack, pg.RELEASE_APPROVAL, pg.RELEASE_APPROVAL_FIELDS))
    add_file(release, f"{pack}/handoff/FUNCTIONAL_CONTRACT.md", "recorded validation evidence")
    release_doc, _error = pg.read_yaml(str(product / pg.RELEASE_APPROVAL))
    release_doc = release_doc if isinstance(release_doc, dict) else {}
    if any(sm.field_unstated(release_doc, key) for key in ("approved_build_id", "approved_manifest_sha256")):
        need(release, "candidate_identity", "Stage and validate a candidate before preparing release approval; its exact build identifier and manifest digest are required.", [f"{pack}/{pg.RELEASE_APPROVAL}"])
    if len(relative.parts) == 4 and relative.parts[0] == "products":
        receipts = root / "refreshes" / relative.parts[1] / relative.parts[2] / relative.parts[3]
        for file in sorted(receipts.glob("*.yaml")):
            if file.resolve().parent == receipts.absolute():
                add_file(release, file, "candidate or release receipt")
    if not any(file["role"] == "candidate or release receipt" for file in release["files"]):
        need(release, "build_evidence", "No product-scoped build receipt is available locally; Engineering must provide the candidate's own evidence from the approved data environment.")

    # Missing files are different from unanswered review fields; neither is approval.
    for checkpoint in checkpoints:
        for record in checkpoint["review_records"]:
            add_file(checkpoint, record["path"], "review record")
            if record["missing_fields"]:
                need(checkpoint, "review_fields", "Complete the review record's stated metadata and human judgments: " + ", ".join(record["missing_fields"]), [record["path"]])
            if record.get("read_error"):
                need(checkpoint, "review_unreadable", "The review record could not be parsed.", [record["path"]])
        for file in checkpoint["files"]:
            if file["required"] and not file["exists"]:
                need(checkpoint, "missing_file", f"Prepare {file['role']} before completing this checkpoint.", [file["path"]])
        for gate in checkpoint["gates"]:
            for action in actions[gate]:
                if action["kind"] == flow.PERSON:
                    checkpoint["person_actions"].append({"id": action["id"], "label": action["label"], "path": action["path"], "note": action["note"]})
                # Commands are concrete checks/preparation only; this report cannot sign or deploy.
                if action["kind"] == flow.PERSON:
                    continue
                if gate == 1 and not (product / "source_refs.yaml").is_file():
                    continue
                if any(not file["exists"] for file in checkpoint["files"] if file["required"]) and gate != 1:
                    continue
                try:
                    reason = guidance.action_guard(str(root), pack, action, local_demo=True, can_write=True)
                except (OSError, ValueError, TypeError, AttributeError, KeyError):
                    reason = "The prerequisite check could not finish."
                command = _command(action, root) if not reason else None
                if command:
                    checkpoint["commands"].append(command)
        checkpoint["input_digest"] = _digest([{k: file[k] for k in ("path", "exists", "sha256")} for file in checkpoint["files"]])
        old = next((item for item in old_checkpoints if isinstance(item, dict) and item.get("id") == checkpoint["id"]), {})
        checkpoint["changed_since_previous"] = bool(old and old.get("input_digest") != checkpoint["input_digest"])
        checkpoint["preparation_state"] = "incomplete" if checkpoint["prerequisites"] else "files_present"
        checkpoint["approval_state"] = "not_evaluated"
        checkpoint["person_action_count"] = len(checkpoint["person_actions"])
    return {"schema": 1, "pack": pack, "checkpoints": checkpoints, "target_maximum_external_checkpoints": 3,
            "three_visit_acceptance_met": False, "read_only": True, "limitations": list(LIMITATIONS),
            "current_person_action_count": sum(c["person_action_count"] for c in checkpoints),
            "current_person_actions_by_gate": {str(g): sum(a["kind"] == flow.PERSON for a in menu) for g, menu in actions.items()},
            "count_scope": "Current Flow person-action entries for the selected pack, not measured visits or distinct signatures.",
            "state_digest": _digest({"pack": pack, "inputs": [c["input_digest"] for c in checkpoints]})}


def render(report):
    """A shareable preparation report, without fabricated approval commands."""
    lines = [f"Approval preparation: {report['pack']}", "", "Read-only preparation; no approval or signature has been recorded.",
             f"Current Flow person actions: {report['current_person_action_count']} (actions, not measured visits).", ""]
    for index, checkpoint in enumerate(report["checkpoints"], 1):
        lines += [f"{index}. {checkpoint['title']}", f"Preparation: {checkpoint['preparation_state']}"]
        for prerequisite in checkpoint["prerequisites"]:
            lines.append("- " + prerequisite["message"] + (" (" + ", ".join(prerequisite["paths"]) + ")" if prerequisite["paths"] else ""))
        for record in checkpoint["review_records"]:
            lines.append(f"- Review record: {record['path']}" + (f" [{record['material_id']}]" if record.get("material_id") else ""))
            if record["missing_fields"]:
                lines.append("  Fields still needed: " + ", ".join(record["missing_fields"]))
        lines.append("")
    lines += ["What prevents a three-visit guarantee today:"] + ["- " + reason for reason in report["limitations"]]
    return "\n".join(lines)
