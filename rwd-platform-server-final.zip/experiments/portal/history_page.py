"""Record a product's pending files in history as the person, in a LOCAL demo (one plain commit).

The Flow's Gate 1 "commit" act asks the person to commit the registration so that an approval can
bind to the commit whose diff wrote it. In a local demo the portal runs on the person's own checkout,
so the act is a button: git add of the product's files (and the registries the stand-up touched) and
one commit under the git identity configured on this computer. It never signs (a signature is the
review's own act on the signing form), never pushes, and refuses when git has no identity for this
person or nothing of this product is pending.
"""
from __future__ import annotations

import os
import subprocess
from hashlib import sha256
from pathlib import Path

import streamlit as st

import git_index_lock

# every file outside the pack that the stand-up, a next cut or a study act writes (new_product.py's own
# WROTE list, the lifecycle registry, the study pins): the record carries the whole act (walk RW1-01)
REGISTRIES = ("products/registry.yaml", "fixtures/registry.yaml", "governance/NAME_LIFECYCLE.yaml",
              "products/activation.yaml", "products/metadata/catalog.yaml", "products/PORTFOLIO.md",
              "governance/tumour_registry.yaml", "governance/CURRENT_STATE.md",
              "governance/reference/oncology_modules/CATALOGUE.yaml", "governance/reference/oncology_modules/indication",
              "governance/reference/variable_inventory", "resources/products.yml")
TIMEOUT = 120


class Refused(Exception):
    """Nothing was recorded; the message says why in the person's words."""

    def __init__(self, message, *, detail=""):
        super().__init__(message)
        self.detail = detail


def _git_failure(message, error):
    """Keep the complete lock diagnostic; its path is often lost in Git's long footer."""
    if "index.lock" in error.lower():
        return Refused(message + " Git could not obtain its history lock (index.lock). "
                       "Use the Git lock controls on this page to check and resolve it before recording again.",
                       detail=error.strip())
    return Refused(message + " " + error.strip()[-300:])


def _git(root, *args):
    try:
        r = subprocess.run(["git", "-C", str(root), *args], capture_output=True, text=True, encoding="utf-8",
                           errors="replace", timeout=TIMEOUT)
    except (OSError, subprocess.SubprocessError) as error:
        raise Refused("Git could not be run on this computer. Ask your data expert to install it.") from error
    return r.returncode, (r.stdout or ""), (r.stderr or "")


def identity(root):
    """(name, email) git will record, or None when either is not configured."""
    _c1, name, _e1 = _git(root, "config", "--get", "user.name")
    _c2, email, _e2 = _git(root, "config", "--get", "user.email")
    name, email = name.strip(), email.strip()
    return (name, email) if name and email else None


def pending(root, pack):
    """The product's files git would record, as (status word, path), from git's own list."""
    scope = [str(pack)] + [r for r in REGISTRIES if os.path.exists(os.path.join(root, r))]
    code, out, err = _git(root, "status", "--porcelain", "--untracked-files=all", "--", *scope)
    if code != 0:
        raise Refused("The product's pending files could not be listed. " + err.strip()[-300:])
    rows = []
    words = {"M": "changed", "A": "added", "D": "deleted", "R": "renamed", "?": "new"}
    for line in out.splitlines():
        if len(line) < 4:
            continue
        flag = (line[:2].strip() or "?")[0]
        path = line[3:].strip().strip('"').replace("\\", "/")
        if " -> " in path:
            path = path.split(" -> ")[-1]
        rows.append((words.get(flag, "changed"), path))
    return rows


def record(root, pack, message, *, local_demo, can_write):
    """One plain commit of the product's pending files as the configured person. Refuses first."""
    if not local_demo:
        raise Refused("Recording history is done on the person's own checkout. A hosted portal proposes a pull request instead.")
    if not can_write:
        raise Refused("Recording history needs product-author access.")
    who = identity(root)
    if not who:
        raise Refused("Git does not know who you are on this computer. Ask your data expert to set your name and email in git once "
                      "(git config user.name and user.email); the record must carry a person's name.")
    rows = pending(root, pack)
    if not rows:
        raise Refused("Nothing of this product is pending. There is nothing to record.")
    text = " ".join(str(message or "").split())[:160] or f"Record {pack}"
    if any(ord(ch) < 32 for ch in text):
        raise Refused("The message must be one line of plain text.")
    paths = [path for _w, path in rows]
    code, _out, err = _git(root, "add", "-A", "--", *paths)
    if code != 0:
        raise _git_failure("The files could not be staged.", err)
    code, _out, err = _git(root, "commit", "--no-gpg-sign", "-q", "-m", text, "--", *paths)
    if code != 0:
        raise _git_failure("The record could not be made.", err)
    _c, sha, _e = _git(root, "rev-parse", "HEAD")
    return {"ok": True, "commit": sha.strip(), "files": paths, "by": who[0],
            "message": f"Recorded {len(paths)} file(s) as {who[0]} (commit {sha.strip()[:12]}). Nothing was signed or pushed."}


def _state_key(root, pack, action, actor_id):
    scope = [str(Path(root).resolve()), str(pack), str(action.get("id", "commit")), str(actor_id)]
    return "history_feedback_" + sha256(repr(scope).encode("utf-8")).hexdigest()[:24]


def _recover_git_lock(root, fingerprint, key, *, local_demo, can_write):
    """The recovery click authorizes only the lock shown on the preceding render."""
    if not local_demo or not can_write:
        st.session_state[key] = {"error": "Releasing the Git lock needs product-author access on your own checkout."}
        return
    try:
        git_index_lock.recover(root, expected_fingerprint=fingerprint, confirmed=True, can_write=can_write)
    except (ValueError, OSError, subprocess.SubprocessError) as error:
        st.session_state[key] = {"error": "The Git lock was not released. " + str(error)}
        return
    st.session_state[key] = {"notice": "The stale Git lock was released. Review the files below, then choose "
                             "Record these files in history when ready."}


def _render_git_lock(root, action, key, *, local_demo, can_write):
    feedback = st.session_state.get(key) or {}
    feedback_area = st.empty()
    with feedback_area.container():
        if feedback.get("error"):
            st.error(feedback["error"])
        if feedback.get("notice"):
            st.success(feedback["notice"])
        if feedback.get("detail"):
            with st.expander("Git details from the failed record"):
                st.code(feedback["detail"], language=None)
    report = git_index_lock.inspect(root)
    if report["state"] == "absent":
        return False, feedback_area
    st.warning(report["message"])
    st.caption("Checking or releasing this lock preserves your files and does not record them. "
               "Recording remains a separate action.")
    action_id = action.get("id", "commit")
    st.button("Check Git lock again", key=f"history_lock_check_{action_id}")
    if report["can_recover"]:
        st.button("Release stale Git lock", key=f"history_lock_release_{action_id}", disabled=not can_write,
                  on_click=_recover_git_lock, args=(root, report["fingerprint"], key),
                  kwargs={"local_demo": local_demo, "can_write": can_write},
                  help="Release the checked abandoned lock so you can record the product's files when ready.")
    return True, feedback_area


def render(root, pack, action, actor_id, *, local_demo, can_write, can_view):
    """The act on the Flow page. Returns True when a record was just made (the caller re-checks)."""
    if not can_view:
        return False
    st.write("**Record in history**")
    if not local_demo:
        st.info("Recording history happens on the person's own checkout; a hosted portal proposes a pull request instead.")
        return False
    key = _state_key(root, pack, action, actor_id)
    locked, feedback_area = _render_git_lock(root, action, key, local_demo=local_demo, can_write=can_write)
    try:
        rows = pending(root, pack)
        who = identity(root)
    except Refused as error:
        st.warning(str(error))
        return False
    if not who:
        st.warning("Git does not know who you are on this computer. Ask your data expert to set your name and email in git once; "
                   "the record must carry a person's name.")
        return False
    if not rows:
        st.info("Nothing of this product is pending; its files are already in history. Choose Check again.")
        return False
    st.caption(f"Recorded as {who[0]} ({who[1]}). The record is a plain history entry; the review signature is a separate act.")
    prefix = str(pack).replace("\\", "/").strip("/") + "/"
    with st.expander(f"{len(rows)} file(s) of this product to record"):
        for word, path in rows[:60]:
            st.write(f"- {word}: {path[len(prefix):] if path.startswith(prefix) else path}")
        if len(rows) > 60:
            st.caption(f"and {len(rows) - 60} more")
    label = str(action.get("label") or "Record the product's files")
    if st.button("Record these files in history", key=f"history_record_{action.get('id', 'commit')}", type="primary",
                 disabled=not can_write or locked):
        try:
            result = record(root, pack, f"{label.split(':')[0]} ({pack})", local_demo=local_demo, can_write=can_write)
        except Refused as error:
            st.session_state[key] = {"error": "Not recorded. " + str(error), "detail": error.detail}
            st.rerun()
            return False
        st.session_state.pop(key, None)
        feedback_area.empty()
        st.session_state.setdefault("flow_result", {}).pop(pack, None)
        st.success(result["message"])
        return True
    return False
