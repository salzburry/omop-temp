"""Task-oriented continuations that return to the shared product workspace."""
from __future__ import annotations

import hashlib
import json
from pathlib import Path

import streamlit as st
import form_assistance as form_help
import yaml

import lifecycle_workspace as backend
import scientific_definitions

PREFIX = "lifecycle_"
ROUTES = ("revision_review", "change_impact", "study_refresh", "study_protocol", "study_runs")


def assistant_context(root, pack, actor_id, *, allowed_packs, route, params=None):
    """Project selected study metadata through the page's existing scoped readers."""
    study = (params or {}).get("study")
    if route not in {"study_refresh", "study_protocol", "study_runs"} or not isinstance(study, str) or not study:
        return {}
    try:
        report = backend.studies(root, pack, actor_id, allowed_packs=allowed_packs)
        row = next((item for item in report.get("studies", []) if item["study"] == study), None) if report.get("ok") else None
        if row is None:
            return {}
        def metadata(rows, fields):
            return [{key: value[key] for key in fields if isinstance(value.get(key), str)}
                    for value in rows[:24] if isinstance(value, dict)]
        pins = row.get("pins") or []
        declared = (row.get("entry") or {}).get("cites_release") or []
        context = {"study_id": study, "kind": row.get("kind"), "route": route,
                   "protocol_id": study if route == "study_protocol" else row.get("protocol") or None,
                   "declared_products": metadata(declared, ("product", "spec_version", "build_id")),
                   "pins": metadata(pins, ("product", "spec_version", "build_id", "status")),
                   "omitted_entries": max(0, len(pins) - 24) + max(0, len(declared) - 24),
                   "next_visible_action": {"study_refresh": "Review study pin comparison",
                       "study_protocol": "Validate and preview protocol changes", "study_runs": "Review analysis evidence"}[route],
                   "basis": "Recorded study identity and release metadata only; no protocol prose, source data or scientific decision was retrieved."}
        if route == "study_protocol":
            current = backend.protocol(root, pack, actor_id, study, allowed_packs=allowed_packs)
            if not current.get("ok"):
                return {}
            context["protocol_status"] = str((current.get("doc") or {}).get("status") or "not recorded")
            context["saved_amendment_proposal"] = bool(current.get("saved"))
            if (current.get("lock") or {}).get("held"):
                context["next_visible_action"] = "Review the protocol save lock before saving"
            elif current.get("pins_error") or not current.get("scope"):
                context["next_visible_action"] = "Open the Studies page"
        import scientific_definition_ai as ai
        ai._ingress(ai._plain(context))
        if len(json.dumps(context, ensure_ascii=False).encode("utf-8")) > 4000:
            return {}
        return {"study_context": context}
    except (OSError, ValueError, TypeError, KeyError, yaml.YAMLError):
        return {}


def _errors(result):
    for error in result.get("errors", []):
        st.error(error)
    return not result.get("ok")


def _nav(label, route, params=None, key=None):
    if st.button(label, key=PREFIX + (key or route)):
        return {"route": route, "params": params or {}}
    return None


def _studies_page(key):
    """The Studies page is a sidebar section, not a workflow route; pinning lives there."""
    if st.button("Open the Studies page", key=PREFIX + key):
        st.session_state.pop("connected_workflow", None)
        st.session_state["section_suggested"] = "Studies"
        st.rerun()


def _select_context(pack, actor_id, **fields):
    import connected_workflow_page
    connected_workflow_page.select_context(pack, actor_id, **fields)


def _rows(root, pack, actor_id, allowed_packs):
    description = scientific_definitions.describe(root, pack, actor_id, allowed_packs=allowed_packs)
    if not description["ok"]:
        _errors(description)
        return []
    return description["rows"]


def _impact(result, *, historical=False):
    if _errors(result):
        return
    if result["rows_no_record_cites"]:
        st.warning("No contract record cites: " + ", ".join(result["rows_no_record_cites"]) + ". Review missing implementation or citations; this is not a finding of no impact.")
    st.markdown("**Definitions and affected outputs**")
    if result["records"]:
        st.table(result["records"])
    else:
        st.info("The earlier cut has no definition citing this removed requirement. Review its missing prior citations with the scientific owner before assessing its consumers."
                if historical else "The declared chain has no linked definitions yet. Draft the selected requirements to establish their lineage.")
    st.markdown("**Configuration and engine consumers**")
    st.write({"configuration_blocks": result["blocks"], "published_columns": result["output_columns"],
              "capabilities": result["capabilities"]})
    if result["blocks_not_governed"]:
        st.warning("These cited configuration blocks are not read by the build: " + ", ".join(result["blocks_not_governed"]))
    if result.get("capability_note"):
        st.warning(result["capability_note"])
    st.markdown("**Regression checks to rerun**")
    if result["goldens_to_rerun"]:
        st.table([{"fixture": path, "cases": ", ".join(cases)} for path, cases in result["goldens_to_rerun"].items()])
    else:
        st.warning(result.get("coverage_note") or "No golden case cites these rows. Confirm coverage with engineering before treating the change as checked.")
    st.caption("This is declared reach, not a safety verdict or a completed test run.")


def _delta_sentence(previous, delta, changes):
    cut = previous.rsplit("/", 1)[-1]
    return (f"Compared with the {cut} cut, this cut keeps {changes['unchanged']} row(s) with the same text, adds "
            f"{len(changes['added'])}, removes {len(changes['removed'])} and changes {len(changes['changed'])} in place "
            f"({delta['old_rows']} row(s) before, {delta['new_rows']} now).")


def _delta_lists(changes):
    for kind, label in (("added", "Added in this cut"), ("removed", "Removed in this cut"), ("changed", "Changed in place")):
        rows = changes[kind]
        if rows:
            st.markdown(f"**{label}:** " + "; ".join((r["variable"] or "unnamed row") + " (" + r["item_id"] + ")" for r in rows))


def _review_source_change(root, pack, actor_id, previous, allowed_packs, result, params):
    import specification_revision_review
    choices = {kind + ":" + row["item_id"]: (kind, row)
               for kind in ("changed", "added", "removed") for row in result["changes"][kind]}
    if not choices:
        return None
    st.markdown("**Resolve one source change**")
    st.write("Choose a changed requirement, read its source comparison, then continue directly to its definition or recorded question.")
    key = PREFIX + "revision_change"
    preferred = next((token for token, (_kind, row) in choices.items()
                      if row["item_id"] == params.get("item_id") and _kind != "removed"), None)
    context = (pack, actor_id, previous, preferred)
    if st.session_state.get(key + "_context") != context:
        st.session_state[key] = preferred or next(iter(choices))
        st.session_state[key + "_context"] = context
    if st.session_state.get(key) not in choices:
        st.session_state[key] = next(iter(choices))
    token = st.selectbox("Source change to resolve", list(choices), key=key,
                         format_func=lambda token: choices[token][0].capitalize() + " · "
                         + (choices[token][1]["variable"] or "unnamed requirement") + " · " + choices[token][1]["item_id"])
    kind, row = choices[token]
    review = specification_revision_review.review(root, pack, actor_id, previous, kind=kind,
        item_id=row["item_id"], expected_digest=result["digest"], allowed_packs=allowed_packs)
    if _errors(review):
        return None
    with st.expander("Compare the exact source fields", expanded=True):
        st.code(review["diff"], language="diff")
        st.caption("This comparison shows extracted source fields. It does not decide their scientific meaning or transfer prior approval.")
    if kind == "removed":
        st.info("This requirement is absent from the current cut. Review its previously declared consumers; there is no current definition row to open for this removal.")
    else:
        _select_context(pack, actor_id, item_id=row["item_id"], variable=row["variable"], previous_pack=previous)
        if review["editor_note"]:
            st.warning(review["editor_note"])
        if review["selected"]:
            nav = _nav("Review this changed definition" if kind == "changed" else "Draft this added definition",
                       "scientific_draft", {"item_id": row["item_id"]}, key="revision_definition")
            if nav:
                return nav
        else:
            nav = _nav("Resolve this row's scientific prerequisites", "progress", {"action_id": "g2_draft"}, key="revision_prerequisites")
            if nav:
                return nav
        if review["question_note"]:
            st.info(review["question_note"])
        questions = {question["id"]: question for question in review["questions"] if question["status"] == "OPEN"}
        if questions:
            question_key = PREFIX + "revision_question"
            if st.session_state.get(question_key) not in questions:
                st.session_state.pop(question_key, None)
            chosen = st.selectbox("Open question cited by this definition", list(questions), key=question_key,
                                  format_func=lambda did: did + " · " + questions[did]["question"])
            if not questions[chosen]["issued"]:
                st.caption("Its answer form has not been prepared. The question page lets you prepare the missing forms and continue with this question.")
            nav = _nav("Continue this scientific question", "questions", {"decision_id": chosen}, key="revision_question_open")
            if nav:
                return nav
        elif not review["question_note"]:
            st.caption("No open question is explicitly linked by the current definition. This does not establish that the changed wording is scientifically settled.")
    return _nav("Inspect this change's affected outputs and checks", "change_impact", review["impact_params"], key="revision_impact")


def _revision(root, pack, actor_id, allowed_packs, local_demo, can_write, params):
    st.subheader("Review a revised specification")
    st.write("Compare the source text with an earlier cut. Select unchanged definitions to carry as unfinished row drafts; changed or ambiguous requirements need a new interpretation.")
    cuts = sorted(p for p in allowed_packs if p != pack and p.split("/")[:3] == pack.split("/")[:3])
    if not cuts:
        st.info("This product has no other accessible cut to compare. Create the next cut from New product, then return to this review.")
        return _nav("Return to product progress", "progress")
    preferred = params.get("previous_pack")
    if preferred in cuts and st.session_state.get(PREFIX + "previous_incoming") != preferred:
        st.session_state[PREFIX + "previous"] = preferred
        st.session_state[PREFIX + "previous_incoming"] = preferred
    previous = st.selectbox("Compare with earlier cut", cuts, index=cuts.index(preferred) if preferred in cuts else len(cuts) - 1,
                            key=PREFIX + "previous", help="Choose the cut whose definitions you want to compare. The current product remains the destination.")
    _select_context(pack, actor_id, previous_pack=previous)
    result = backend.revision(root, pack, actor_id, previous, allowed_packs=allowed_packs)
    if _errors(result):
        return None
    # One sentence and the rows by variable name, not a block of counts (walk 2026-09-07, NC-13).
    st.write(_delta_sentence(previous, result["delta"], result["changes"]))
    _delta_lists(result["changes"])
    nav = _review_source_change(root, pack, actor_id, previous, allowed_packs, result, params)
    if nav:
        return nav
    with st.expander("Reuse unchanged definitions", expanded=not any(result["changes"][kind] for kind in ("changed", "added", "removed"))):
        nav = _carry_revision(root, pack, actor_id, previous, allowed_packs, local_demo, can_write, result)
    return nav


def _carry_revision(root, pack, actor_id, previous, allowed_packs, local_demo, can_write, result):
    if result["candidates"]:
        st.table([{k: c[k] for k in ("variable_id", "verdict", "reason", "item_id")} for c in result["candidates"]])
    else:
        st.info("The earlier cut has no definition records to carry. The row comparison still identifies source changes.")
    with st.expander("Previously reported specification findings"):
        if result["findings"]:
            st.table([dict(zip(("finding", "verdict", "evidence"), r)) for r in result["findings"]])
        else:
            st.write(result["findings_note"] or "No open specification findings were registered in the earlier cut.")
    eligible = [c["variable_id"] for c in result["candidates"] if c["eligible"] and not c.get("draft_exists")]
    selected = st.multiselect("Definitions to carry as row drafts", eligible, key=PREFIX + "carry_selection",
                             help="Only unchanged requirements with one unambiguous target and no existing saved row draft are selectable. Their source fields are supplied from the new cut during validation; approval does not carry.")
    if any(c.get("draft_exists") for c in result["candidates"]):
        st.caption("Some rows already have saved drafts. Open the scientific editor to review those drafts; carrying does not overwrite them.")
    confirmed = st.checkbox("I reviewed the selected source matches and want to stage these definitions as drafts", key=PREFIX + "carry_confirm")
    if st.button("Stage selected row drafts", key=PREFIX + "carry_save", disabled=not (local_demo and can_write and selected and confirmed)):
        saved = backend.stage_carry(root, pack, actor_id, previous, selected, expected_digest=result["digest"],
                                   allowed_packs=allowed_packs, local_demo=local_demo, can_write=can_write, confirmed=confirmed)
        if not _errors(saved):
            st.success(f"Staged {len(saved['staged'])} definition draft(s). Next, open each row to review its interpretation and run contract validation. No approval was transferred.")
            st.session_state[PREFIX + "carried"] = saved["staged"]
    valid_targets = {c["item_id"] for c in result["candidates"] if c.get("eligible")}
    just_carried = [row for row in st.session_state.get(PREFIX + "carried", []) if row["item_id"] in valid_targets]
    carried = list({row["item_id"]: row for row in [
        *({"variable_id": c["variable_id"], "item_id": c["item_id"]} for c in result["candidates"] if c.get("draft_exists")),
        *just_carried]}.values())
    if carried:
        choice_key = PREFIX + "carried_choice"
        if st.session_state.get(choice_key) not in carried:
            st.session_state.pop(choice_key, None)
        chosen = st.selectbox("Continue a saved row draft", carried, format_func=lambda r: r["variable_id"] + " · " + r["item_id"], key=choice_key)
        nav = _nav("Review carried definition" if just_carried else "Review saved definition", "scientific_draft", {"item_id": chosen["item_id"]})
        if nav:
            return nav
    return _nav("Inspect affected outputs and checks", "change_impact", {"previous_pack": previous})


def _change_impact(root, pack, actor_id, allowed_packs, params):
    st.subheader("Affected outputs and checks")
    st.write("Select the requirements being changed. Follow their declared links to definitions, configuration, published columns and cited regression cases.")
    rows = _rows(root, pack, actor_id, allowed_packs)
    # the studies that pin this product are consumers too (walk UC3-P2-6, 2026-09-07)
    try:
        import study_pin  # noqa: PLC0415
        pinned = [r for r in study_pin.pins_for_product(pack, str(root)) if r.get("study")]
    except Exception:  # noqa: BLE001 - an unreadable pin never hides the page; the Studies page names it
        pinned = []
    if pinned:
        st.info("Studies that pin this product: " + ", ".join(f"{r['study']} ({r.get('status') or 'pinned'})" for r in pinned)
                + ". A change here reaches them at their next refresh; their current pins stay as they are.")
    options = {r["item_id"]: r for r in rows}
    # A variable REMOVED in this cut had no row here to pick, so its consumers could not be examined
    # (walk 2026-09-07, NC-08): the previous cut's rows this cut no longer carries are offered too,
    # marked as removed, and their consumers are read as that cut declared them.
    gone = backend.removed_rows(root, pack, actor_id, allowed_packs=allowed_packs, previous=params.get("previous_pack"))
    removed = {}
    if not _errors(gone):
        for r in gone["rows"]:
            token = r["item_id"] + "@" + r["cut"]
            removed[token] = r
            options[token] = {"item_id": r["item_id"], "variable_id": r["variable_id"]}
    if not options:
        return _nav("Continue scientific definitions", "scientific_draft")
    if removed:
        st.caption(f"Rows marked removed in this cut were in the {gone['cut']} cut and are absent from this extraction. "
                   "Their consumers are shown as that cut declared them.")
    initial = [r for r in params.get("rows", [params.get("item_id")]) if r in options]
    variables = sorted({r["variable_id"] for r in options.values()})
    incoming = (tuple(initial), params.get("variable"))
    if any(incoming) and st.session_state.get(PREFIX + "impact_incoming") != incoming:
        st.session_state[PREFIX + "impact_rows"] = initial
        st.session_state[PREFIX + "impact_variables"] = [params["variable"]] if params.get("variable") in variables else []
        st.session_state[PREFIX + "impact_incoming"] = incoming
    by_variable = st.multiselect("Find rows by variable", variables, default=[params["variable"]] if params.get("variable") in variables else [],
                                key=PREFIX + "impact_variables", help="Variable names help locate requirements; source-row citations determine the impact calculation.")
    selected = st.multiselect("Changed specification rows", list(options), default=initial,
                             format_func=lambda item: options[item]["item_id"] + " · " + options[item]["variable_id"]
                             + (" (removed in this cut)" if item in removed else ""), key=PREFIX + "impact_rows")
    selected = sorted(set(selected) | {token for token, r in options.items() if r["variable_id"] in by_variable})
    current = [s for s in selected if s not in removed]
    gone_selected = [s for s in selected if s in removed]
    if current:
        _impact(backend.impact(root, pack, actor_id, current, allowed_packs=allowed_packs))
    if gone_selected:
        st.markdown(f"**Removed in this cut: consumers declared in the {gone['cut']} cut**")
        _impact(backend.impact(root, gone["previous"], actor_id, [removed[s]["item_id"] for s in gone_selected], allowed_packs=allowed_packs), historical=True)
    if current:
        chosen = st.selectbox("Requirement to resolve next", current, key=PREFIX + "impact_next")
        _select_context(pack, actor_id, item_id=chosen, variable=options[chosen]["variable_id"])
        nav = _nav("Open this scientific definition", "scientific_draft", {"item_id": chosen})
        if nav:
            return nav
    elif gone_selected:
        st.caption("A removed row has no definition in this cut to open. Its consumers above are what the removal reaches.")
        return _nav("Return to specification change review", "revision_review", {"previous_pack": gone["previous"]})
    return _nav("Review the implementation and evidence", "variable_lineage", {"item_id": current[0]} if current else {})


def _study_choice(root, pack, actor_id, allowed_packs, route, params):
    result = backend.studies(root, pack, actor_id, allowed_packs=allowed_packs)
    if _errors(result):
        return None
    rows = result["studies"]
    if route == "study_runs":
        rows = [r for r in rows if r["kind"] == "project"]
    elif route == "study_protocol":
        rows = [r for r in rows if (Path(root) / "work" / r["study"] / "PROTOCOL.yaml").is_file()]
    elif route == "study_refresh":
        rows = [r for r in rows if any(p.get("product") == pack for p in r["pins"])]
    choices = [r["study"] for r in rows]
    if not choices:
        if route == "study_runs":
            # The real precondition (audit 2026-09-07, S-05): run evidence belongs to an analysis
            # project, and a project needs a registered protocol reading a released product.
            st.info("Run evidence is recorded against an analysis project: a registry work entry of kind project that names "
                    "a registered protocol and cites a published build of this product. No such project is bound to this "
                    "product within your access. Complete and register the study protocol first, then ask the data expert "
                    "to register the analysis project under it.")
            _studies_page("runs_open_studies")
        else:
            st.info("No eligible study is bound to this product within your access. In Studies, create the study draft and pin this product first.")
            _studies_page("choice_open_studies")
        return None
    preferred = params.get("study")
    key = PREFIX + "study_" + route
    incoming_key = key + "_incoming"
    if preferred in choices and st.session_state.get(incoming_key) != preferred:
        st.session_state[key] = preferred
        st.session_state[incoming_key] = preferred
    if st.session_state.get(key) not in choices:
        st.session_state.pop(key, None)
    selected = st.selectbox("Study" if route != "study_runs" else "Analysis project", choices,
                            index=choices.index(preferred) if preferred in choices else 0, key=key)
    st.session_state[incoming_key] = selected
    _select_context(pack, actor_id, study=selected)
    return selected


def _refresh(root, pack, actor_id, study, allowed_packs, local_demo, can_write):
    st.subheader("Review and refresh this study's product pin")
    current = backend.refresh_details(root, pack, actor_id, study, allowed_packs=allowed_packs)
    if _errors(current):
        return None
    st.write("Review changes to the product before recording that the study has read the current contract and configuration. Study exclusions and alternative definitions remain in the study record.")
    st.table([{"evidence": "Scientific contract", "study previously read": current["pin"].get("contract_sha256"), "current product": current["current_contract"]},
              {"evidence": "Configuration", "study previously read": current["pin"].get("config_bundle_sha256"), "current product": current["current_config"]}])
    with st.expander("Current study decisions and validation findings"):
        st.write(current["pin"].get("definitions") or "No variable decisions have been recorded.")
        for check in current["checks"]:
            st.warning(check)
    builds = [""] + [b["build_id"] for b in current["builds"]]
    build_id = st.selectbox("Published build to read", builds, format_func=lambda b: b or "Keep the current build selection",
                            key=PREFIX + "refresh_build", help="Only committed published receipts with a passing composed candidate verdict appear. A draft build is never a study input.")
    by = st.text_input("Person who reviewed the product changes", key=PREFIX + "refresh_by", help="Enter the actual reviewer's name. Example: Alex Morgan; no name is inferred from the session.")
    date = st.text_input("Date of that review (YYYY-MM-DD)", key=PREFIX + "refresh_date", help="Enter when the review took place. The date cannot precede the existing pin or refresh.")
    review_context = (pack, actor_id, study, current["digest"], build_id)
    review_key = PREFIX + "refresh_review_context"
    previous_review = st.session_state.get(review_key)
    if previous_review != review_context:
        # The button causes a rerun. A new digest read during that rerun must not
        # inherit confirmation of the comparison previously shown to the person.
        st.session_state[PREFIX + "refresh_confirm"] = False
        if previous_review is not None:
            st.warning("The study, product or build selection changed. Review the comparison and confirm again before refreshing.")
        st.session_state[review_key] = review_context
    confirmed = st.checkbox("I reviewed the current product changes and want to record this study refresh", key=PREFIX + "refresh_confirm")
    # Nothing changed means the pin tool would refuse (audit 2026-09-07, S-04): say so and
    # keep the button off instead of offering a refresh that ends in an error.
    unchanged = current["unchanged"] and (not build_id or build_id == str(current["pin"].get("build_id") or ""))
    if unchanged:
        st.caption("Nothing to refresh: the study already read the current contract and configuration"
                   + (", and the selected build is the one it reads." if build_id else
                      ". Refresh becomes available when the product changes or when you choose another published build."))
    if st.button("Refresh study pin", key=PREFIX + "refresh_save", disabled=not (local_demo and can_write and confirmed and not unchanged)):
        result = backend.refresh_pin(root, pack, actor_id, study, reviewed_by=by, reviewed_date=date, build_id=build_id,
                                     expected_digest=current["digest"], allowed_packs=allowed_packs, local_demo=local_demo, can_write=can_write, confirmed=confirmed)
        if not _errors(result):
            st.success("Study refresh recorded. " + result["next"])
            return {"changed": True}
    nav = _nav("Inspect changed-row impact", "change_impact")
    return nav or _nav("Continue this study's protocol", "study_protocol", {"study": study})


HELP = {
    "objectives": "State what the study should learn. Illustrative example: Describe treatment patterns in the prespecified population. Use one objective per line for a simple list.",
    "design": "State the study design, index event and observation period. Illustrative example: Retrospective cohort indexed at first eligible treatment; specify actual dates and rationale.",
    "population": "State inclusion, exclusion and eligibility timing. Illustrative example: Require the defined diagnosis before index; justify each restriction with your scientific owner.",
    "endpoints": "Define each outcome, timing, event and censoring rule. Illustrative example: Primary endpoint = time from the defined index to the specified event; unresolved choices stay explicit.",
    "analyses": "State the estimand, analysis method, adjustment and missing-data strategy. Illustrative example: Tabulate the prespecified categories and report missing values separately.",
}


def _scope_words(scope):
    return ", ".join(f"{s['product']} {s['spec_version']}" + (f" build {s['build_id']}" if s.get("build_id") else "") for s in scope)


def _readiness(checks, *, proposed, registered=None, status="draft"):
    """What the protocol tool's registration check still refuses, in its own words (audit 2026-09-07, S-02);
    for a registered plan, who registered it and when (walk 2026-09-07, S-REG)."""
    if registered:
        with st.expander("Registration", expanded=True):
            st.success(f"This protocol was registered on {registered['date']} by {registered['by']}. Its status is {status}; "
                       "the plan changes only by an amendment that names a person, a date, what changed and why.")
        return
    source = "the proposed plan" if proposed else "the saved plan"
    with st.expander("Ready for registration", expanded=True):
        if not checks:
            st.success(f"The protocol check refuses nothing for {source}. A reviewer registers the saved plan below by typing "
                       "their name and the date; the portal records the plan digest and enters the study in the product "
                       "registry with the releases it pins.")
        else:
            st.write(f"Before this study can be registered, the protocol check still refuses {source} for these reasons, quoted from the check:")
            for check in checks:
                st.warning(check)


def _register(root, study, current, previewed, allowed_packs, local_demo, can_review):
    """The registration form (walk 2026-09-07, S-REG): offered only when the protocol check refuses
    nothing for the saved plan. The name and the date are typed here, never filled in."""
    st.markdown("**Register this protocol**")
    st.write("Registration freezes the plan as saved: the person named here, the date and the plan digest are written into "
             "the protocol record, and the study is entered in the product registry with the releases it pins. "
             "After that the plan changes only by amendment.")
    if previewed is not None and previewed["after"] != current["text"]:
        st.warning("The previewed edits are not saved. Save the draft first, or the plan is registered as last saved.")
    by = st.text_input("Person registering this protocol", key=PREFIX + "protocol_register_by",
                       help="Type the name of the scientific owner registering the plan. Example: Alex Morgan; no name is filled in for you.")
    date = st.text_input("Registration date (YYYY-MM-DD)", key=PREFIX + "protocol_register_date",
                         help="The day this registration is made.")
    confirmed = st.checkbox("I confirm this plan is complete and is to be registered as it stands", key=PREFIX + "protocol_register_confirm")
    if not can_review:
        st.caption("Registering is a reviewer's act. Ask a reviewer to register this plan.")
    if st.button("Register this protocol", key=PREFIX + "protocol_register", disabled=not (local_demo and can_review and confirmed)):
        result = backend.register_protocol(root, study, registered_by=by, registered_on=date, local_demo=local_demo,
                                           can_review=can_review, allowed_packs=allowed_packs)
        if not _errors(result):
            st.success(f"Registered on {result['registered_date']} by {result['registered_by']}. " + result["next"])
            return {"changed": True}
    return None


def _protocol(root, pack, actor_id, study, allowed_packs, local_demo, can_write, can_review=False):
    st.subheader("Edit the study protocol")
    current = backend.protocol(root, pack, actor_id, study, allowed_packs=allowed_packs)
    if _errors(current):
        return None
    doc = current["doc"]
    st.write("Complete the plan in sections, preview the before/after change, then save a draft. Existing registration and amendment history are preserved.")
    st.caption("Current protocol status: " + str(doc.get("status")) + ". Saving here does not register, authenticate or release the study.")
    lock = current["lock"]
    if lock["held"] and lock["stale"]:
        st.warning(f"A protocol save started {lock['minutes']} minute(s) ago and never finished, so its lock still blocks saving. "
                   "If nobody else is saving this protocol right now, clear the stale lock and save again.")
        if st.button("Clear the stale lock", key=PREFIX + "protocol_clear_lock", disabled=not (local_demo and can_write)):
            cleared = backend.clear_protocol_lock(root, pack, actor_id, study, allowed_packs=allowed_packs,
                                                  local_demo=local_demo, can_write=can_write, confirmed=True)
            if not _errors(cleared):
                st.success(cleared["next"])
                st.rerun()
    elif lock["held"]:
        st.info("Another protocol save for this study is in progress. Wait a moment, then reload before saving.")
    if current["pins_error"]:
        st.error("The study's pins could not be read, so the plan's product scope cannot be filled: " + current["pins_error"])
    elif not current["scope"]:
        st.warning("This study has no product pin yet, so saving keeps the plan's product scope as it is. "
                   "Pin this product to the study on the Studies page, then return here and save the protocol again.")
        _studies_page("protocol_open_studies")
    else:
        st.caption("Product scope for this plan comes from the study's pins: " + _scope_words(current["scope"])
                   + ". Saving writes that scope into the plan; a different scope needs a different pin.")
    saved = current.get("saved")
    if saved:
        st.info("A saved amendment proposal is available. Its frozen protocol has not been changed.")
        if saved.get("base_digest") != current["digest"]:
            st.warning("The protocol context changed since that proposal. Reconcile the proposal with the current plan before saving again.")
    initial = (saved or {}).get("edits") or {"title": doc.get("title", ""), "prespecified": doc.get("prespecified") or {}}
    title = form_help.field(st.text_input, "Protocol title", value=str(initial.get("title", "")), key=PREFIX + "protocol_title",
                          help="A short study title. Example: Treatment patterns in the prespecified cohort.", binding=(study, current["digest"]))
    pre = {}
    for field in backend.protocol_record.PRESPECIFIED:
        original = (initial.get("prespecified") or {}).get(field, "")
        structured = isinstance(original, (list, dict))
        with st.expander(field.replace("_", " ").capitalize(), expanded=field in ("objectives", "design")):
            if structured:
                st.caption("This section has an existing structured list or mapping. Preserve its structure below; examples explain the content to supply.")
            text = form_help.field(st.text_area, field.capitalize() + (" (structured YAML)" if structured else ""),
                                value=yaml.safe_dump(original, sort_keys=False, allow_unicode=True) if structured else str(original or ""),
                                key=PREFIX + "protocol_" + field, height=125, help=HELP[field], binding=(study, current["digest"], field))
            try:
                pre[field] = backend.project_run._strict_yaml(text, field) if structured else text
            except (ValueError, yaml.YAMLError) as error:
                st.error(str(error))
                return None
    with st.expander("Product and published-build scope"):
        if current["scope"]:
            st.write(current["scope"])
            st.caption("Copied from the study's pins when you save. A change to which releases the plan reads is made by pinning, and for a frozen plan needs an amendment.")
        else:
            st.write((doc.get("prespecified") or {}).get("scope", []))
            st.caption("Retained from the study record until the study pins a product.")
    with st.expander("Current validation findings and amendment history"):
        for check in current["checks"]:
            st.warning(check)
        st.write(doc.get("amendments") or "No amendment history.")
    edits = {"title": title, "prespecified": pre}
    marker = hashlib.sha256(json.dumps(edits, sort_keys=True, default=str).encode()).hexdigest()
    if st.button("Validate and preview protocol changes", key=PREFIX + "protocol_preview"):
        result = backend.preview_protocol(root, pack, actor_id, study, edits, expected_digest=current["digest"], allowed_packs=allowed_packs)
        st.session_state[PREFIX + "protocol_preview_result"] = {"marker": marker, "result": result}
    stored = st.session_state.get(PREFIX + "protocol_preview_result")
    previewed = stored["result"] if stored and stored["marker"] == marker and stored["result"].get("ok") else None
    _readiness((previewed or current)["registration_checks"], proposed=previewed is not None,
               registered=current["registered"], status=str(doc.get("status")))
    if stored and stored["marker"] == marker:
        proposal = stored["result"]
        if not _errors(proposal):
            st.code(proposal["diff"] or "No text changes.", language="diff")
            for check in proposal["checks"]:
                st.warning(check)
            if proposal["passed"]:
                st.success("Protocol record validation passed for this proposal. Scientific review remains required.")
            frozen = proposal["status"] != "draft"
            if frozen:
                st.info("This plan is frozen. Saving stages an amendment proposal and preserves the registered protocol. The scientific owner must supply the amendment reason, reviewer, date and digest chain.")
            confirmed = st.checkbox("I reviewed this protocol diff and want to save the proposal", key=PREFIX + "protocol_confirm")
            if st.button("Save amendment proposal" if frozen else "Save protocol draft", key=PREFIX + "protocol_save",
                         disabled=not (local_demo and can_write and confirmed and proposal["status"] != "closed" and (frozen or proposal["passed"]))):
                result = backend.save_protocol(root, pack, actor_id, study, edits, expected_digest=proposal["digest"],
                                                expected_proposal_digest=proposal["proposal_digest"], allowed_packs=allowed_packs,
                                                local_demo=local_demo, can_write=can_write, confirmed=confirmed)
                if not _errors(result):
                    st.success("Saved. " + result["next"])
                    return {"changed": True}
    if doc.get("status") == "draft" and not current["registration_checks"]:
        registered = _register(root, study, current, previewed, allowed_packs, local_demo, can_review)
        if registered:
            return registered
    return _nav("Review analysis-run evidence", "study_runs", {"study": study})


def _runs(root, pack, actor_id, study, allowed_packs, local_demo, can_write):
    st.subheader("Study analysis runs")
    current = backend.runs(root, pack, actor_id, study, allowed_packs=allowed_packs)
    if _errors(current):
        return None
    st.write("Review immutable run records and attach outputs explicitly returned by the analysis environment. This action records evidence; it does not execute an analysis.")
    for row in current["records"]:
        with st.expander(row["path"]):
            st.json(row["record"])
    if not current["records"]:
        st.info("No analysis-run records have been recorded for this project.")
    with st.expander("Bound product/build citations", expanded=False):
        st.write(current["entry"].get("cites_release") or [])
    if not current["ready"]:
        # The real precondition, and no form until it holds (audit 2026-09-07, S-05): the run
        # recorder refuses every project whose protocol is not registered or whose citations
        # do not pin a published build, so a form here was a guaranteed dead end.
        protocol_id = current["protocol"] or "its protocol"
        st.warning("Run evidence can be recorded once this project's protocol (" + protocol_id + ") is registered or amended and every "
                   "release the project cites is a published build of the product with a committed receipt. The run recorder "
                   "still refuses this project for these reasons, quoted from its check:")
        for check in current["checks"]:
            st.warning(check)
        st.caption("Complete and register the protocol, then have the data expert pin the published build on the project's registry entry. The evidence form appears when the check passes.")
        return _nav("Review the linked protocol", "study_protocol", {"study": current["entry"].get("protocol") or study})
    environment = st.text_input("Analysis environment used", key=PREFIX + "run_environment", help="State the actual runtime and version, for example the named approved analytics workspace and environment revision. This is your declaration, not an automatic environment capture.")
    parameters = st.text_area("Parameters used (YAML mapping)", value="{}", key=PREFIX + "run_parameters",
                              help="Record actual analysis settings. Illustrative example: analysis_id: primary. Do not paste patient data.")
    outputs = st.text_area("Returned artifacts (name = full path, one per line)", key=PREFIX + "run_outputs",
                           help="Example: results = D:\\analysis-outputs\\study-results.csv. Files must exist outside this checkout. The canonical recorder stores paths, digests and sizes, not their data bytes.")
    confirmed = st.checkbox("These paths identify the actual returned outputs for this project's declared analysis", key=PREFIX + "run_confirm")
    if st.button("Validate and record analysis evidence", key=PREFIX + "run_save", disabled=not (local_demo and can_write and confirmed)):
        try:
            parsed = backend.project_run._strict_yaml(parameters, "Parameters")
            paths = {}
            for line in outputs.splitlines():
                if not line.strip():
                    continue
                name, separator, path = line.partition("=")
                if not separator or not name.strip() or not path.strip() or name.strip() in paths:
                    raise ValueError("Use a unique name = full path on every artifact line.")
                paths[name.strip()] = path.strip()
            result = backend.record_run(root, pack, actor_id, study, parsed, environment, paths, expected_digest=current["digest"],
                                        allowed_packs=allowed_packs, local_demo=local_demo, can_write=can_write, confirmed=confirmed)
            if not _errors(result):
                st.success("Analysis evidence recorded. " + result["next"])
                return {"changed": True}
        except (ValueError, yaml.YAMLError) as error:
            st.error(str(error))
    return _nav("Review the linked protocol", "study_protocol", {"study": current["entry"].get("protocol") or study})


def render(root, pack, actor_id, *, allowed_packs, local_demo, can_write, can_review, route, params=None):
    """Render within the shared work area; return an optional route continuation."""
    params = params or {}
    context = (str(Path(root).resolve()), pack, actor_id, tuple(sorted(allowed_packs)), local_demo, can_write, can_review)
    if st.session_state.get(PREFIX + "context") != context:
        for key in list(st.session_state):
            if str(key).startswith(PREFIX):
                del st.session_state[key]
        st.session_state[PREFIX + "context"] = context
    if pack not in allowed_packs:
        st.error("This product is outside your access.")
        return None
    if route == "revision_review":
        return _revision(root, pack, actor_id, allowed_packs, local_demo, can_write, params)
    if route == "change_impact":
        return _change_impact(root, pack, actor_id, allowed_packs, params)
    if route in ("study_refresh", "study_protocol", "study_runs"):
        study = _study_choice(root, pack, actor_id, allowed_packs, route, params)
        if study:
            context_key = PREFIX + "study_context_" + route
            if st.session_state.get(context_key) != study:
                field_prefix = {"study_protocol": "protocol_", "study_runs": "run_", "study_refresh": "refresh_"}[route]
                for key in list(st.session_state):
                    if str(key).startswith(PREFIX + field_prefix):
                        del st.session_state[key]
                st.session_state[context_key] = study
            function = {"study_refresh": _refresh, "study_protocol": _protocol, "study_runs": _runs}[route]
            extra = {"can_review": can_review} if route == "study_protocol" else {}
            return function(root, pack, actor_id, study, allowed_packs, local_demo, can_write, **extra)
        return _nav("Return to product progress", "progress")
    st.error("Choose a connected lifecycle action from the product workspace.")
    return None
