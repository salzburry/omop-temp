"""Explicit save/resume controls for the existing unfinished registration form."""
import streamlit as st

import session_drafts as drafts


def render(root, actor, *, allowed_packs, can_write, choices):
    if not can_write:
        return
    context = drafts.dw._hash([str(root), actor, sorted(allowed_packs), choices])
    if st.session_state.get("setup_saved_context") != context:
        st.session_state.pop("setup_resume_proposal", None)
        st.session_state.pop("setup_saved_choice", None)
        st.session_state["setup_saved_context"] = context
    with st.expander("Save or resume unfinished setup"):
        st.caption(drafts.SETUP_NOTICE)
        try:
            if st.button("Save unfinished setup", key="setup_save"):
                saved = drafts.save_setup(root, actor, st.session_state, allowed_packs=allowed_packs, can_write=can_write)
                st.success("Unfinished setup saved privately for this identity and checkout. You can reopen it after restarting the portal.")
                st.session_state["setup_last_saved"] = saved["id"]
            listing = drafts.list_setups(root, actor, allowed_packs=allowed_packs)
            for warning in listing["warnings"]:
                st.warning(warning)
            records = {row["id"]: row for row in listing["records"]}
            if not records:
                st.caption("No saved setup yet. Enter a few details or ask the assistant, then save your unfinished setup here.")
                return
            if st.session_state.get("setup_saved_choice") not in records:
                st.session_state.pop("setup_saved_choice", None)
            selected = st.selectbox("Resume saved setup", list(records), index=None, key="setup_saved_choice",
                format_func=lambda identifier: records[identifier]["name"] + " · " + records[identifier]["saved_at"][:19].replace("T", " "))
            if st.button("Review saved setup", key="setup_review", disabled=selected is None):
                st.session_state["setup_resume_proposal"] = drafts.resume_preview(root, actor, selected, st.session_state,
                    allowed_packs=allowed_packs, expected_digest=records[selected]["digest"], choices=choices)
            proposal = st.session_state.get("setup_resume_proposal")
            if proposal:
                if proposal["id"] != selected:
                    st.session_state.pop("setup_resume_proposal", None)
                    return
                current = drafts.resume_preview(root, actor, selected, st.session_state,
                    allowed_packs=allowed_packs, expected_digest=proposal["digest"], choices=choices)
                if current != proposal:
                    st.session_state.pop("setup_resume_proposal", None)
                    st.warning("Your current setup or its choices changed. Review the saved setup again.")
                    return
                if proposal["resets"]:
                    st.warning("These saved choices are no longer available and will be cleared: " + ", ".join(proposal["resets"]) + ".")
                if proposal["diff"]:
                    st.dataframe(proposal["diff"], hide_index=True)
                st.caption("Resuming replaces the current setup fields and setup conversation." if proposal["replaces"] else
                           "Resume these entries in the existing registration form below.")
                label = "Replace current setup with this saved draft" if proposal["replaces"] else "Resume this saved setup"
                if st.button(label, key="setup_resume"):
                    drafts.restore_setup(root, actor, st.session_state, proposal, allowed_packs=allowed_packs,
                        choices=choices, can_write=can_write, confirmed=True)
                    st.session_state.pop("setup_resume_proposal", None)
                    st.success("Saved setup resumed. Review the fields below and supply the current workbook and declarations again.")
        except (OSError, ValueError, TypeError, KeyError, RecursionError) as error:
            st.warning(drafts.dw._storage_message(error, str(error) if isinstance(error, ValueError) else
                "The saved setup could not be read or written. Your current form is unchanged."))
