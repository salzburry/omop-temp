"""Shared, content-bound preparation of a product's variables by three roles.

This store is a reviewable draft table. Its confirmations record the people who
reviewed the table; they are never contract approvals or signing identities.
Canonical contracts, product configuration and private row drafts are read only
until an explicit transfer into the existing private draft workflow.
"""
from __future__ import annotations

from contextlib import contextmanager
from copy import deepcopy
from datetime import datetime, timezone
import json
import os
from pathlib import Path
import re

import yaml

import scientific_definitions as definitions
import master_variable_library as library
import definition_reuse_logic as reuse_logic
import variable_review_consistency as consistency
import variable_review_requirements as requirements

PHASES = ("science", "source", "output")
SCIENCE_FIELDS = {
    "master_name", "logic_reviewed", "field_choices", "family", "derivation", "grain", "anchor", "window",
    "record_selection", "tie_break", "cohort_applicability", "missing", "units",
    "acceptance", "notes", "source.value", "source.kind", "output.type",
    "output.codes", "output.nullable", "decision_ids", "gap_ids",
}
SOURCE_FIELDS = {
    "source.kind", "source.logical_table", "source.physical_stem", "source.columns",
    "source.inputs", "source.parameters", "source.spec_identifiers", "source.reason",
    "depends_on", "implementation_refs",
}
OUTPUT_FIELDS = {
    "output.physical_name", "output.target_published_name", "output.name_status", "output.role",
    "publish.ads", "publish.dictionary", "publish.dashboard", "publish.tfl",
}
FIELDS = {"science": SCIENCE_FIELDS, "source": SOURCE_FIELDS, "output": OUTPUT_FIELDS}
ALL_FIELDS = set.union(*FIELDS.values())
KINDS = {"vendor", "derived", "parameter", "constant", "unavailable", "pending_mapping"}
DESTINATIONS = {"undecided", "proposed", "required", "configured", "excluded"}
LIST_FIELDS = {"source.parameters", "source.spec_identifiers", "depends_on",
               "implementation_refs", "decision_ids", "gap_ids"}
META_FIELDS = {"master_name", "logic_reviewed", "field_choices", "family"}
LABELS = {"science": "scientific table", "source": "source mappings", "output": "output table"}
STORE = ".portal-drafts/variable-review/workflow.json"


def _fail(error):
    result = definitions._fail(error)
    return {**result, "message": result["errors"][0]}


def _now():
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def _get(values, key):
    parts = key.split(".")
    value = values
    for part in parts:
        value = value.get(part) if isinstance(value, dict) else None
    return value


def _put(values, key, value):
    parts = key.split(".")
    target = values
    for part in parts[:-1]:
        if not isinstance(target.get(part), dict):
            target[part] = {}
        target = target[part]
    target[parts[-1]] = deepcopy(value)


def _answered(value):
    if isinstance(value, (dict, list)):
        return bool(value) and any(_answered(item) for item in (value.values() if isinstance(value, dict) else value))
    if type(value) in {bool, int, float}:
        return True
    return not definitions._placeholder(value) and str(value).strip().casefold() not in {"undecided", "none", "n/a", "null"}


def _normalized(values):
    result = deepcopy(values)
    for key in ("source", "output", "publish"):
        result[key] = deepcopy(definitions._as_mapping(result.get(key)) or {})
    for key in LIST_FIELDS:
        raw = _get(result, key)
        if isinstance(raw, str) and raw.strip().startswith("["):
            parsed = yaml.safe_load(raw)
            if isinstance(parsed, list):
                _put(result, key, parsed)
    # An empty inputs key is a malformed claimed multi-table mapping downstream.
    # Preserve nonempty legacy lists as unfinished drafts so the UI can repair them.
    if result["source"].get("inputs") in (None, "", [], {}):
        result["source"].pop("inputs", None)
    declared_type = consistency.canonical_type(result["output"].get("type"))
    if declared_type:
        result["output"]["type"] = declared_type
    return definitions._values(result)


def _input_digest(root, product):
    shared = {}
    for relative in (library.INVENTORY, library.SUPPLEMENT, "governance/reference/variable_inventory/CUSTOM_LOGIC.yaml"):
        path = definitions._safe(root / relative)
        shared[relative] = definitions._hash(path.read_bytes()) if path.is_file() else None
    return definitions._hash({"product": definitions._snapshot(product), "library": shared})


def _empty(pack, digest):
    return {"version": 1, "pack": pack, "input_digest": digest, "rows": {}, "reviews": {},
            "history": [], "draft_only": True, "approved": False}


def _load(path, pack, digest):
    if not path.exists():
        return _empty(pack, digest), ""
    raw = definitions._read(path)
    state = definitions._json(raw)
    if not isinstance(state, dict) or set(state) != set(_empty(pack, digest)) or state.get("version") != 1:
        raise ValueError("The shared variable review has an unsupported format. Repair its saved review file before continuing.")
    if state.get("pack") != pack or state.get("draft_only") is not True or state.get("approved") is not False:
        raise ValueError("A shared variable review must belong to this product and cannot claim contract approval.")
    if not isinstance(state["rows"], dict) or not isinstance(state["reviews"], dict) or set(state["reviews"]) - set(PHASES):
        raise ValueError("The shared variable review contains invalid rows or review phases.")
    if not isinstance(state["history"], list) or not isinstance(state["input_digest"], str):
        raise ValueError("The shared variable review history has an unsupported format.")
    for item_id, saved in state["rows"].items():
        definitions._draft_name(item_id)
        if not isinstance(saved, dict) or not {"updates", "actor_id", "updated_at"} <= set(saved) or set(saved) - {"updates", "actor_id", "updated_at", "kind_owner", "choice_evidence"}:
            raise ValueError("A shared variable row has an unsupported format.")
        if any(not isinstance(saved[name], str) or not saved[name] for name in ("actor_id", "updated_at")) or saved.get("kind_owner", "science") not in {"science", "source"}:
            raise ValueError("A shared variable row is missing its editing identity or field ownership.")
        _validate_updates(saved["updates"], ALL_FIELDS)
        if "choice_evidence" in saved and not isinstance(saved["choice_evidence"], dict):
            raise ValueError("A shared field choice has an unsupported evidence format.")
    for phase, review in state["reviews"].items():
        if not isinstance(review, dict) or set(review) != {"actor_id", "confirmed_at", "content_digest", "input_digest"}:
            raise ValueError("A shared table confirmation has an unsupported format.")
        if any(not isinstance(value, str) or not value for value in review.values()):
            raise ValueError("A shared table confirmation is missing its reviewer or content binding.")
    return state, definitions._hash(raw)


def _validate_updates(updates, allowed):
    if not isinstance(updates, dict) or not updates or set(updates) - allowed:
        raise ValueError("Supply only fields owned by the displayed review phase.")
    for key, value in updates.items():
        if key in LIST_FIELDS:
            if not isinstance(value, list) or any(not isinstance(item, str) for item in value):
                raise ValueError(key + " must contain a list of names or references.")
        elif key == "source.inputs":
            legacy = isinstance(value, list) and all(isinstance(item, str) for item in value)
            mapped = isinstance(value, dict) and all(
                isinstance(alias, str) and isinstance(columns, dict) and all(
                    isinstance(role, str) and isinstance(column, str) for role, column in columns.items())
                for alias, columns in value.items())
            if not (legacy or mapped):
                raise ValueError("Source inputs must map each source alias to its column roles and source columns.")
        elif key == "source.columns":
            if not isinstance(value, dict) or any(not isinstance(k, str) or not isinstance(v, str) for k, v in value.items()):
                raise ValueError("Source columns must map each logical field name to a source column name.")
        elif key == "logic_reviewed":
            if type(value) is not bool:
                raise ValueError("The logic review choice must be explicit.")
        elif key == "family":
            import variable_review_family
            variable_review_family.validate(value)
        elif key == "field_choices":
            if not isinstance(value, dict) or set(value) - (SCIENCE_FIELDS - META_FIELDS) or any(choice not in {"excel", "master", "edit"} for choice in value.values()):
                raise ValueError("Field choices must name displayed scientific fields and choose excel, master or edit.")
        elif key == "source.value":
            if not isinstance(value, (str, bool, int, float, type(None))):
                raise ValueError("The product value must be a single value; keep mapping choices in their own fields.")
        elif key == "output.nullable":
            if not isinstance(value, (str, bool)):
                raise ValueError("The missing-value choice must contain a displayed answer.")
        elif key == "output.codes":
            if not isinstance(value, (str, list, dict)):
                raise ValueError("Allowed values must contain text or a displayed list of categories.")
        elif key == "window":
            if not isinstance(value, (str, int, float)) or isinstance(value, bool):
                raise ValueError("A time window must contain text or a declared numeric duration.")
        elif not isinstance(value, str):
            raise ValueError(key + " must contain text.")
        if key == "source.kind" and value not in KINDS | {""}:
            raise ValueError("Choose a displayed variable/source kind.")
        if key.startswith("publish.") and value not in DESTINATIONS:
            raise ValueError("Choose a displayed destination decision.")
        if key == "output.role" and value not in {"", "published", "internal", "metadata", "excluded"}:
            raise ValueError("Choose published, internal, metadata or excluded for the output role.")
        if key == "output.name_status" and value not in definitions.cl.NAMEST | {""}:
            raise ValueError("Choose a displayed output naming status.")
    # Reuse the canonical judgment bounds even for metadata-only row edits.
    stub = yaml.safe_load(definitions.cs.judgment_stub("CHECK"))
    for key, value in updates.items():
        if key not in META_FIELDS:
            _put(stub, key, value)
        elif isinstance(value, str) and len(value) > 12000:
            raise ValueError("A review field exceeds its text limit.")
    definitions._values(stub)


def _candidates(root):
    result = library.candidates(root)
    for candidate in result:
        candidate.update(reuse_logic.describe(candidate["record"]))
    return result


def _base_rows(product, masters):
    data = definitions._json(definitions._read(product / "spec_pipeline/out/extracted.json"))
    if not isinstance(data, dict) or not isinstance(data.get("rows"), list):
        raise ValueError("Regenerate the specification extraction before preparing the variable table.")
    text = definitions._read(product / "handoff/FUNCTIONAL_CONTRACT.md").decode("utf-8")
    source_rows = definitions._requirements(data, list(definitions.cl.records(text)))
    rows = []
    for original in source_rows:
        row = deepcopy(original)
        existing = row.pop("existing")
        if len(existing) > 1:
            raise ValueError(f"{row['item_id']} has several contract records. Resolve their row mapping in the advanced definition editor first.")
        if existing:
            values = {key: definitions.cl._scalar(existing[0], key) or "" for key in definitions.FIELDS}
        else:
            variable = re.sub(r"[^A-Za-z0-9_]", "_", row["variable_id"].split("<br>")[0].strip())[:40].upper()
            values = yaml.safe_load(definitions.cs.judgment_stub(variable))
        values = _normalized(values)
        wanted = row["variable_id"].strip().casefold()
        labeled_id = re.search(r"\(\s*([A-Za-z][A-Za-z0-9_]*)\s*\)\s*$", row["variable_id"])
        if labeled_id and any(item["variable_id"].casefold() == labeled_id[1].casefold() for item in masters):
            wanted = labeled_id[1].casefold()
        exact = [item for item in masters if item["variable_id"].casefold() == wanted]
        aliases = [item for item in masters if wanted in {name.casefold() for name in item["aliases"]}]
        match = exact[0] if len(exact) == 1 else None
        original_logic = _answered(values.get("derivation"))
        status = "resolved" if original_logic else "unmapped"
        master_name = ""
        if not original_logic and match and match["reuse_readiness"] == "ready":
            values["derivation"] = match["reusable_derivation"]
            master_name, status = match["variable_id"], "matched"
        elif not original_logic and (exact or aliases):
            status = "ambiguous"
        # Only explicitly named schema cells supply defaults. No interpretation
        # of dates, names, examples, prose or allowed categories chooses a type.
        fields = row["spec_fields"]
        for name in ("data_type", "datatype", "output_type", "type"):
            if not _answered(values["output"].get("type")) and isinstance(fields.get(name), str):
                values["output"]["type"] = fields[name]
        declared_value_types = {consistency.value_type(fields[name]) for name in ("value", "values") if name in fields}
        declared_value_types.discard(None)
        if not _answered(values["output"].get("type")) and len(declared_value_types) == 1:
            values["output"]["type"] = declared_value_types.pop()
        for name in ("source_kind", "variable_kind"):
            if not _answered(values["source"].get("kind")) and fields.get(name) in KINDS:
                values["source"]["kind"] = fields[name]
        if match and status == "matched":
            declared_type, declared_kind = match.get("data_type"), match.get("declared_source_kind")
            actual_type = consistency.canonical_type(values["output"].get("type")) or str(values["output"].get("type", "")).casefold()
            master_type = consistency.canonical_type(declared_type) or str(declared_type or "").casefold()
            if declared_type and _answered(values["output"].get("type")) and actual_type != master_type:
                status = "ambiguous"
            elif declared_type and not _answered(values["output"].get("type")):
                values["output"]["type"] = declared_type
            if declared_kind in KINDS and _answered(values["source"].get("kind")) and values["source"]["kind"] != declared_kind:
                status = "ambiguous"
            elif declared_kind in KINDS and not _answered(values["source"].get("kind")):
                values["source"]["kind"] = declared_kind
            if match["derivation"] == match["record"]["spec"]["rule"]:
                # Inventory sketches explain a concept but do not independently
                # establish an executable formula's applicability.
                status = "ambiguous"
        explicit_logic = [fields[name] for name in ("derivation", "formula", "logic") if isinstance(fields.get(name), str) and _answered(fields[name])]
        if not original_logic and explicit_logic:
            values["derivation"] = explicit_logic[0]
            if match and (len(set(explicit_logic)) > 1 or explicit_logic[0].strip() != match["reusable_derivation"].strip()):
                status = "ambiguous"
        if values["source"].get("kind") in {"constant", "parameter"} and not _answered(values["source"].get("value")):
            # This is the selected product's explicit value cell, never a
            # reference example or a library default.
            declared_values = [fields[name] for name in ("value", "values") if name in fields and fields[name] not in (None, "")]
            if len(declared_values) == 1 and isinstance(declared_values[0], (str, bool, int, float)) and not consistency.value_type(declared_values[0]):
                values["source"]["value"] = declared_values[0]
        if not _answered(values.get("window")) and isinstance(fields.get("time_period"), str):
            values["window"] = fields["time_period"]
        row.update(values=values, spec_values=deepcopy(fields), master_name=master_name, master=match,
                   status=status, logic_reviewed=False, field_choices={}, family={}, candidate_names=[item["variable_id"] for item in exact + aliases],
                   existing_contract=bool(existing), prepared_automatically=status == "matched")
        rows.append(row)
    return rows


def _logic_issues(row, masters):
    text = row["values"].get("derivation", "")
    master = next((item for item in masters if item["variable_id"] == row["master_name"]), None)
    if not _answered(text):
        if master:
            return [f"Master {master['variable_id']} is selected. Enter this variable's definition / logic / formula."]
        return ["Choose a master definition or write this variable's scientific logic."]
    # Existing authored contract rules are preserved; these are current-product
    # records, not imported templates. New master/custom edits use the boundary.
    if row["existing_contract"] and not row.get("logic_changed"):
        return []
    record = deepcopy(master["record"]) if master else {"derivation": text, "interpreted": [], "executable": []}
    source = row["values"].get("source", {})
    if source.get("kind") in {"parameter", "constant"}:
        interpreted = dict(record.get("interpreted") or [])
        interpreted["Source table and field"] = deepcopy(source)
        record["interpreted"] = list(interpreted.items())
    try:
        disposition = "inherit" if master and text == master["reusable_derivation"] and master["reuse_readiness"] == "ready" else "adapt"
        reuse_logic.validate(record, text, disposition=disposition, logic_reviewed=row.get("logic_reviewed") is True)
        return []
    except ValueError as error:
        return [str(error)]


def _row_issues(row, masters, source_metadata=None):
    values = row["values"]
    science = _logic_issues(row, masters)
    selected_master_needs_logic = (
        row["status"] == "unmapped"
        and not _answered(values.get("derivation"))
        and any(item["variable_id"] == row["master_name"] for item in masters)
    )
    if row["status"] in {"unmapped", "ambiguous"} and not selected_master_needs_logic:
        science.append("Resolve this variable's master mapping or explicitly choose custom logic.")
    if not _answered(_get(values, "output.type")):
        science.append("Choose the variable's data type in the scientific table.")
    science.extend(consistency.issues(row))
    science.extend(requirements.issues(row))
    if row.get("family"):
        import variable_review_family
        import variable_review_family_binding
        science.extend(variable_review_family.issues(row))
        science.extend(variable_review_family_binding.coherence_issues(row))
    source = values["source"]
    kind = source.get("kind")
    mapping = []
    if kind not in KINDS or kind == "pending_mapping":
        mapping.append("Choose and complete the source kind for this variable.")
    elif kind == "vendor" and (not _answered(source.get("logical_table")) or not _answered(source.get("columns"))):
        mapping.append("Name the source table and map its source columns.")
    elif kind == "parameter" and not _answered(source.get("parameters")):
        mapping.append("Name this product's configuration parameter reference.")
    elif kind == "constant" and not _answered(source.get("value")):
        mapping.append("Enter this product's constant value in the scientific table.")
    elif kind == "derived" and not _answered(values.get("depends_on")):
        mapping.append("Name the variables this calculation depends on.")
    elif kind == "unavailable" and not _answered(source.get("reason")):
        mapping.append("Explain why a source is unavailable.")
    if row.get("family"):
        import variable_review_family
        mapping.extend(variable_review_family.source_issues(row))
    if source_metadata is not None:
        import variable_review_source_validation
        mapping.extend(variable_review_source_validation.issues(row, source_metadata))
    output = []
    role = values["output"].get("role")
    if role not in {"published", "internal", "metadata", "excluded"}:
        output.append("Choose whether this variable is published, internal, metadata or excluded.")
    if role != "excluded" and not _answered(values["output"].get("physical_name")):
        output.append("Choose the physical output column name.")
    if role == "published" and not _answered(values["output"].get("target_published_name")):
        output.append("Choose the published variable name.")
    if any(values["publish"].get(name) not in DESTINATIONS - {"undecided"} for name in ("ads", "dictionary", "dashboard", "tfl")):
        output.append("Decide each output destination, including explicit exclusions.")
    return {"science": science, "source": mapping, "output": output}


def _phase_digest(rows, phase, input_digest):
    names = set.union(*(FIELDS[name] for name in PHASES[:PHASES.index(phase) + 1]))
    payload = [{"item_id": row["item_id"], "values": {key: row.get(key) if key in META_FIELDS else _get(row["values"], key)
                 for key in sorted(names) if key != "source.kind" or phase != "science" or row["source_kind_scientific"]}}
               for row in sorted(rows, key=lambda item: item["item_id"])]
    return definitions._hash({"input_digest": input_digest, "rows": payload})


def _describe(root, pack, actor_id, allowed_packs):
    root = Path(root).resolve()
    product, pack, _owner, _folder = definitions._scope(root, pack, actor_id, allowed_packs)
    digest = _input_digest(root, product)
    path = definitions._safe(product / STORE)
    state, state_digest = _load(path, pack, digest)
    masters = _candidates(root)
    rows = _base_rows(product, masters)
    import variable_review_options
    source_metadata = variable_review_options.describe(root, pack, actor_id, allowed_packs=allowed_packs)
    for row in rows:
        saved = state["rows"].get(row["item_id"], {})
        updates = saved.get("updates", {})
        row["source_kind_scientific"] = _answered(_get(row["values"], "source.kind"))
        if "source.kind" in updates:
            row["source_kind_scientific"] = saved.get("kind_owner", "science") == "science" and _answered(updates["source.kind"])
        for key, value in updates.items():
            if key in META_FIELDS:
                row[key] = deepcopy(value)
            else:
                _put(row["values"], key, value)
        row["values"] = _normalized(row["values"])
        row["logic_changed"] = "derivation" in updates or "master_name" in updates
        if row["logic_changed"]:
            row["status"] = "resolved" if _answered(row["values"].get("derivation")) else "unmapped"
            row["prepared_automatically"] = False
        if row["master_name"] and not any(item["variable_id"] == row["master_name"] for item in masters):
            row["status"] = "ambiguous"
            row["master_missing"] = True
        row["master"] = next((item for item in masters if item["variable_id"] == row["master_name"]), None)
        row["phase_issues"] = _row_issues(row, masters, source_metadata)
        if row.get("master_missing"):
            row["phase_issues"]["science"].append("The chosen master is no longer in the library. Review this mapping.")
        row["issues"] = [message for phase in PHASES for message in row["phase_issues"][phase]]
        row["phase_status"] = {phase: "incomplete" if row["phase_issues"][phase] else "ready" for phase in PHASES}
        row["last_edited_by"] = saved.get("actor_id", "")
        row["field_choice_evidence"] = deepcopy(saved.get("choice_evidence", {}))
    collisions = consistency.report_issues(rows)
    for row in rows:
        row["phase_issues"]["output"].extend(collisions.get(row["item_id"], []))
        row["issues"] = [message for phase in PHASES for message in row["phase_issues"][phase]]
        row["phase_status"] = {phase: "incomplete" if row["phase_issues"][phase] else "ready" for phase in PHASES}
    # One queue across profiles; unmapped first, then ambiguous and unfinished.
    rows.sort(key=lambda row: ({"unmapped": 0, "ambiguous": 1, "resolved": 2, "matched": 3}[row["status"]], row["item_id"]))
    phases = {}
    for phase in PHASES:
        issues = [{"item_id": row["item_id"], "variable_id": row["variable_id"], "message": issue}
                  for row in rows for issue in row["phase_issues"][phase]]
        content_digest = _phase_digest(rows, phase, digest)
        review = state["reviews"].get(phase)
        blocked_by = [previous for previous in PHASES[:PHASES.index(phase)] if not phases[previous]["confirmed"]]
        confirmed = bool(review and review["content_digest"] == content_digest and review["input_digest"] == digest and not issues and not blocked_by)
        phases[phase] = {"ready": bool(rows) and not issues and not blocked_by, "confirmed": confirmed,
                         "blocked_by": blocked_by, "issues": issues, "ready_count": sum(not row["phase_issues"][phase] for row in rows),
                         "total_count": len(rows), "review": deepcopy(review), "content_digest": content_digest}
    if _input_digest(root, product) != digest:
        raise ValueError("The product or master library changed while the table loaded. Reload the current table.")
    current_phase = next((phase for phase in PHASES if not phases[phase]["confirmed"]), "complete")
    report = {"ok": True, "errors": [], "rows": rows, "phases": phases, "current_phase": current_phase,
              "input_digest": digest, "state_digest": state_digest, "master_candidates": masters,
              "input_changed": state["input_digest"] != digest,
              "warnings": ["Product or library inputs changed. Compare the current source values and review each table again."] if state["input_digest"] != digest else [],
              "history": deepcopy(state["history"]), "draft_only": True, "approved": False,
              "approval_created": False, "shared_across_profiles": True}
    return report, state, path, product


def describe(root, pack, actor_id, *, allowed_packs=None):
    try:
        return _describe(root, pack, actor_id, allowed_packs)[0]
    except (ValueError, TypeError, KeyError, AttributeError, OSError, RecursionError, yaml.YAMLError, definitions.dw._DraftError) as error:
        return _fail(error)


COMPARISON_LABELS = {
    "derivation": "Logic / formula", "output.type": "Data type", "source.kind": "Variable kind",
    "source.value": "Product value", "window": "Time window", "output.codes": "Allowed values / age groups",
    "grain": "One value per", "anchor": "Anchor date or event", "record_selection": "Which records qualify",
    "tie_break": "Precedence and tie-breaking", "cohort_applicability": "Applicable population",
    "missing": "Missing / no-record behaviour", "units": "Units", "acceptance": "Acceptance criterion",
    "notes": "Review notes", "output.nullable": "Can the result be missing?",
}


def _comparison(report, row, master_name):
    master = next((item for item in report["master_candidates"] if item["variable_id"] == master_name), None)
    if master_name and master is None:
        raise ValueError("Choose a master from the current library before comparing its fields.")
    raw_fields = {str(key).strip().lower().replace(" ", "_"): value for key, value in row["spec_values"].items()}
    # A Values cell that declares a type is neither an output category nor a
    # constant to apply to every patient.
    declared_value_types = {consistency.value_type(raw_fields[name]) for name in ("value", "values") if name in raw_fields}
    declared_value_types.discard(None)
    if len(declared_value_types) == 1 and not any(name in raw_fields for name in ("data_type", "datatype", "output_type", "type")):
        raw_fields["data_type"] = declared_value_types.pop()
    raw_fields = {name: value for name, value in raw_fields.items()
                  if name not in {"value", "values"} or not consistency.value_type(value)}
    kind = _get(row["values"], "source.kind") or (master or {}).get("declared_source_kind")
    aliases = {
        "derivation": ("derivation", "formula", "logic"),
        "output.type": ("data_type", "datatype", "output_type", "type"),
        "source.kind": ("source_kind", "variable_kind"),
        "source.value": ("value", "values") if kind in {"constant", "parameter"} else ("product_value",),
        "window": ("window", "time_window", "time_period"),
        "output.codes": ("codes", "allowed_values", "age_groups", "categories") + (("values",) if kind not in {"constant", "parameter"} else ()),
        "output.nullable": ("nullable",),
    }
    # A reviewed, explicit Master choice can start from declared wording even
    # when that wording is unsuitable for automatic reuse. This comparison is
    # not the inheritance payload: save_row still applies the review and hard
    # literal guards, and _base_rows only prepares safe reusable_derivation.
    master_logic = (master or {}).get("reusable_derivation") or (master or {}).get("record", {}).get("derivation", "")
    direct = {"derivation": master_logic,
              "output.type": (master or {}).get("data_type", ""),
              "source.kind": (master or {}).get("declared_source_kind", "")}
    reference_options = (master or {}).get("reference_options") or []
    result = [{"path": "definition", "label": "Definition", "editable": False,
               "excel_value": row["definition"], "master_value": (master or {}).get("record", {}).get("spec", {}).get("rule", ""),
               "has_excel": bool(row["definition"]), "has_master": bool(master), "master_options": [],
               "current_value": row["definition"], "default_choice": "excel"}]
    for path, label in COMPARISON_LABELS.items():
        excel = next((raw_fields[name] for name in aliases.get(path, (path,)) if name in raw_fields and raw_fields[name] not in (None, "")), None)
        current = _get(row["values"], path)
        options = [deepcopy(option) for option in reference_options if isinstance(option, dict) and option.get("path") == path and "value" in option]
        master_value = direct.get(path)
        if path == "output.type":
            excel = consistency.canonical_type(excel) or excel
            master_value = consistency.canonical_type(master_value) or master_value
            for option in options:
                option["value"] = consistency.canonical_type(option["value"]) or option["value"]
        has_master_direct = master_value not in (None, "")
        default = row.get("field_choices", {}).get(path)
        if default is None:
            if excel is not None and current == excel:
                default = "excel"
            elif has_master_direct and current == master_value:
                default = "master"
            elif excel is not None and not _answered(current):
                default = "excel"
            else:
                default = "edit"
        result.append({"path": path, "label": label, "editable": True, "excel_value": deepcopy(excel),
                       "master_value": deepcopy(master_value), "has_excel": excel is not None,
                       "has_master": has_master_direct or bool(options), "master_options": options,
                       "current_value": deepcopy(current), "default_choice": default,
                       "master_requires_logic_review": path == "derivation" and (master or {}).get("reuse_readiness") == "needs_edit",
                       "master_review_issues": deepcopy((master or {}).get("reuse_issues") or []) if path == "derivation" else [],
                       "master_source_path": (master or {}).get("source_path", "")})
    return result


def comparison_from_report(report, item_id, master_name):
    """Render an already scoped snapshot; saving always reloads authoritative inputs."""
    try:
        if not report.get("ok"):
            raise ValueError("Reload the current variable table before comparing fields.")
        row = next((item for item in report["rows"] if item["item_id"] == item_id), None)
        if row is None:
            raise ValueError("Choose one variable from the current shared table.")
        return {"ok": True, "errors": [], "fields": _comparison(report, row, master_name),
                "input_digest": report["input_digest"], "state_digest": report["state_digest"]}
    except (ValueError, TypeError, KeyError, AttributeError, OSError, RecursionError, yaml.YAMLError, definitions.dw._DraftError) as error:
        return _fail(error)


def compare_fields(root, pack, actor_id, item_id, master_name, *, allowed_packs=None):
    return comparison_from_report(describe(root, pack, actor_id, allowed_packs=allowed_packs), item_id, master_name)


def _choice_evidence(report, row, updates):
    choices = updates.get("field_choices") or {}
    master_name = updates.get("master_name", row["master_name"])
    comparison = {item["path"]: item for item in _comparison(report, row, master_name)}
    result = {}
    for path, choice in choices.items():
        if path not in comparison:
            raise ValueError("Choose provenance only for a displayed comparison field.")
        field = comparison[path]
        value = updates.get(path, _get(row["values"], path))
        source_path, variant = "", ""
        if choice == "excel":
            if not field["has_excel"] or value != field["excel_value"]:
                raise ValueError("The Excel choice must use the current specification's displayed value for " + field["label"] + ".")
            source_path = row["item_id"]
        elif choice == "master":
            options = [option for option in field["master_options"] if option["value"] == value]
            if field["master_value"] not in (None, "") and value == field["master_value"]:
                source_path = field["master_source_path"]
            elif options:
                source_path = str(options[0].get("source_path") or field["master_source_path"])
                variant = str(options[0].get("variant") or options[0].get("label") or "")
            else:
                raise ValueError("The Master choice must use one explicitly displayed library value for " + field["label"] + ".")
        result[path] = {"choice": choice, "master_name": master_name if choice == "master" else "",
                        "source_path": source_path, "variant": variant, "value_digest": definitions._hash(value)}
    return result


@contextmanager
def _locked(path):
    # OS advisory locks disappear with the process; a crashed save does not
    # leave a sentinel that blocks the user's next session indefinitely.
    path.parent.mkdir(parents=True, exist_ok=True)
    lock = definitions._safe(path.with_suffix(".lock"))
    handle = open(lock, "a+b")
    acquired = False
    try:
        if os.name == "nt":
            import msvcrt
            handle.seek(0, os.SEEK_END)
            if handle.tell() == 0:
                handle.write(b"0")
                handle.flush()
            handle.seek(0)
            try:
                msvcrt.locking(handle.fileno(), msvcrt.LK_NBLCK, 1)
            except OSError as error:
                raise ValueError("Another person is saving this table. Reload after their save finishes.") from error
        else:
            import fcntl
            try:
                fcntl.flock(handle.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
            except OSError as error:
                raise ValueError("Another person is saving this table. Reload after their save finishes.") from error
        acquired = True
        yield
    finally:
        if acquired:
            if os.name == "nt":
                handle.seek(0)
                msvcrt.locking(handle.fileno(), msvcrt.LK_UNLCK, 1)
            else:
                fcntl.flock(handle.fileno(), fcntl.LOCK_UN)
        handle.close()


def _fresh(report, expected_input_digest, expected_state_digest):
    if expected_input_digest != report["input_digest"]:
        raise ValueError("The product or master library changed. Reload the current table before saving or confirming.")
    if expected_state_digest != report["state_digest"]:
        raise ValueError("Another person changed the shared table. Reload their changes before saving or confirming.")


def _write(root, product, path, state, report):
    def still_current():
        if _input_digest(Path(root).resolve(), product) != report["input_digest"]:
            raise ValueError("The product or master library changed during the save. Reload the table and try again.")
        now = definitions._hash(definitions._read(path)) if path.exists() else ""
        if now != report["state_digest"]:
            raise ValueError("The shared table changed during this save. Reload it and try again.")
    state["input_digest"] = report["input_digest"]
    if len(state["history"]) > 2000:
        raise ValueError("This review history has reached its draft limit. Archive the review before adding another change.")
    payload = json.dumps(state, ensure_ascii=False, sort_keys=True, allow_nan=False, indent=2).encode("utf-8")
    if len(payload) > definitions.LIMIT:
        raise ValueError("The shared review exceeds its draft size limit.")
    definitions._atomic(path, payload, check=still_current)


def _invalidate(state, phase, report):
    start = 0 if state["input_digest"] != report["input_digest"] else PHASES.index(phase)
    for name in PHASES[start:]:
        state["reviews"].pop(name, None)


def save_row(root, pack, actor_id, item_id, phase, updates, *, expected_input_digest, expected_state_digest,
             allowed_packs=None, local_demo=False, can_write=False):
    if local_demo is not True or can_write is not True:
        return _fail("Saving the shared table requires an authorized editing session.")
    try:
        if phase not in PHASES:
            raise ValueError("Choose science, source or output review.")
        _validate_updates(updates, FIELDS[phase])
        report, _state, path, _product = _describe(root, pack, actor_id, allowed_packs)
        with _locked(path):
            report, state, path, product = _describe(root, pack, actor_id, allowed_packs)
            _fresh(report, expected_input_digest, expected_state_digest)
            row = next((item for item in report["rows"] if item["item_id"] == item_id), None)
            if row is None:
                raise ValueError("Choose one variable from the current shared table.")
            updates = deepcopy(updates)
            if consistency.canonical_type(updates.get("output.type")):
                updates["output.type"] = consistency.canonical_type(updates["output.type"])
            if updates.get("family"):
                import variable_review_family_binding
                updates = variable_review_family_binding.bind_updates(updates)
            if "master_name" in updates and updates["master_name"]:
                master = next((item for item in report["master_candidates"] if item["variable_id"] == updates["master_name"]), None)
                if master is None:
                    raise ValueError("Choose a master from the current library, or clear its name to write a custom definition.")
                if "derivation" not in updates:
                    if master["reuse_readiness"] != "ready":
                        raise ValueError("This master needs edited reusable logic. Write it before saving this mapping.")
                    updates["derivation"] = master["reusable_derivation"]
            if "derivation" in updates and updates["derivation"] != row["values"].get("derivation"):
                updates.setdefault("logic_reviewed", False)
            trial = deepcopy(row)
            for key, value in updates.items():
                if key in META_FIELDS:
                    trial[key] = value
                else:
                    _put(trial["values"], key, value)
            trial["values"] = _normalized(trial["values"])
            trial["logic_changed"] = row.get("logic_changed") or bool({"derivation", "master_name"} & updates.keys())
            if {"derivation", "master_name", "logic_reviewed"} & updates.keys() and _answered(trial["values"].get("derivation")):
                issues = _logic_issues(trial, report["master_candidates"])
                if issues:
                    raise ValueError(issues[0])
            changed = {key: value for key, value in updates.items()
                       if value != (row.get(key) if key in META_FIELDS else _get(row["values"], key))}
            if row["status"] in {"unmapped", "ambiguous"} and {"master_name", "derivation"} & updates.keys():
                # Saving an explicit choice resolves an ambiguity even when
                # its displayed text already matches the chosen template.
                changed.setdefault("derivation", trial["values"].get("derivation", ""))
            if not changed:
                return {"ok": True, "errors": [], "changed": False, "message": "This row already contains these choices.", "draft_only": True, "approval_created": False}
            explicit_choices = updates.get("field_choices") or {}
            evidence = _choice_evidence(report, row, updates) if explicit_choices else {}
            merged_choices = deepcopy(row.get("field_choices") or {})
            if "master_name" in changed:
                merged_choices = {key: "edit" if choice == "master" else choice for key, choice in merged_choices.items()}
            for key in changed.keys() & COMPARISON_LABELS.keys():
                if key == "source.kind" and phase == "source" and not row["source_kind_scientific"]:
                    continue
                merged_choices[key] = explicit_choices.get(key, "edit")
                if key not in evidence:
                    evidence[key] = {"choice": "edit", "master_name": "", "source_path": "", "variant": "",
                                     "value_digest": definitions._hash(updates[key])}
            merged_choices.update(explicit_choices)
            if merged_choices:
                updates["field_choices"] = merged_choices
            saved = state["rows"].setdefault(item_id, {"updates": {}, "actor_id": actor_id.strip(), "updated_at": _now()})
            saved["updates"].update(updates)
            saved.setdefault("choice_evidence", {}).update(evidence)
            saved.update(actor_id=actor_id.strip(), updated_at=_now())
            if "source.kind" in changed:
                saved["kind_owner"] = "science" if phase == "science" or row["source_kind_scientific"] else "source"
            invalidated = "science" if phase == "source" and "source.kind" in changed and row["source_kind_scientific"] else phase
            _invalidate(state, invalidated, report)
            state["history"].append({"action": "save_row", "phase": phase, "item_id": item_id,
                                     "fields": sorted(changed), "actor_id": actor_id.strip(), "at": _now(),
                                     "input_digest": report["input_digest"]})
            _write(root, product, path, state, report)
        return {"ok": True, "errors": [], "changed": True, "message": "Saved to the shared variable table.", "draft_only": True,
                "approval_created": False, "invalidated_from": invalidated}
    except (ValueError, TypeError, KeyError, AttributeError, OSError, RecursionError, yaml.YAMLError, definitions.dw._DraftError) as error:
        return _fail(error)


def confirm_phase(root, pack, actor_id, phase, *, expected_input_digest, expected_state_digest, confirmed=False,
                  allowed_packs=None, local_demo=False, can_review=False):
    if local_demo is not True or can_review is not True or confirmed is not True:
        return _fail("Confirming a table requires an authorized reviewer and an explicit review confirmation.")
    try:
        if phase not in PHASES:
            raise ValueError("Choose science, source or output review.")
        report, _state, path, _product = _describe(root, pack, actor_id, allowed_packs)
        with _locked(path):
            report, state, path, product = _describe(root, pack, actor_id, allowed_packs)
            _fresh(report, expected_input_digest, expected_state_digest)
            if not report["phases"][phase]["ready"]:
                blockers = report["phases"][phase]["blocked_by"]
                if blockers:
                    raise ValueError("Confirm the " + LABELS[blockers[0]] + " before confirming this phase.")
                raise ValueError("Complete the remaining " + LABELS[phase] + " decisions before confirming the full table.")
            if report["phases"][phase]["confirmed"]:
                return {"ok": True, "errors": [], "changed": False, "message": "This current table is already confirmed.", "draft_only": True, "approval_created": False}
            _invalidate(state, phase, report)
            review = {"actor_id": actor_id.strip(), "confirmed_at": _now(),
                      "content_digest": report["phases"][phase]["content_digest"], "input_digest": report["input_digest"]}
            state["reviews"][phase] = review
            state["history"].append({"action": "confirm_phase", "phase": phase, **review})
            _write(root, product, path, state, report)
        return {"ok": True, "errors": [], "changed": True, "message": "Confirmed the " + LABELS[phase] + ". The next role can continue.",
                "review": review, "draft_only": True, "approved": False, "approval_created": False}
    except (ValueError, TypeError, KeyError, AttributeError, OSError, RecursionError, yaml.YAMLError, definitions.dw._DraftError) as error:
        return _fail(error)


def transfer_to_drafts(root, pack, actor_id, *, expected_input_digest, expected_state_digest, confirmed=False,
                       allowed_packs=None, local_demo=False, can_write=False):
    """Explicitly continue through the established row-draft checks, preserving private edits.

All existing drafts are checked for conflicts first. A concurrent private edit
or filesystem failure can still interrupt the later writes; the response names
every draft actually transferred so a partial operation is never hidden.
"""
    if local_demo is not True or can_write is not True or confirmed is not True:
        return _fail("Transferring the table requires an authorized editor and an explicit transfer confirmation.")
    transferred = []
    try:
        report, _state, path, _product = _describe(root, pack, actor_id, allowed_packs)
        with _locked(path):
            report, state, path, product = _describe(root, pack, actor_id, allowed_packs)
            _fresh(report, expected_input_digest, expected_state_digest)
            if report["current_phase"] != "complete":
                raise ValueError("Confirm the scientific, source and output tables before transferring their rows for contract checks.")
            _product, _pack, owner, folder = definitions._scope(root, pack, actor_id, allowed_packs)
            planned, conflicts = [], []
            extraction_digest = definitions._hash(definitions._read(product / "spec_pipeline/out/extracted.json"))
            for row in report["rows"]:
                draft = definitions._saved_draft_path(product, owner, folder, row["item_id"])
                if draft.exists():
                    saved = definitions._load_draft(draft, pack, owner, row["item_id"])
                    if not definitions.same_answers(saved["values"], row["values"]):
                        conflicts.append(row["item_id"])
                    elif saved["extraction_sha256"] != extraction_digest:
                        planned.append((row, definitions._hash(definitions._read(draft))))
                    continue
                planned.append((row, ""))
            if conflicts:
                return {**_fail("Your existing row drafts differ from the shared table. Reconcile those drafts in the advanced definition editor before transferring; nothing was changed."),
                        "conflicts": conflicts, "transferred": []}
            canonical_digest = definitions._snapshot(product)
            for row, draft_digest in planned:
                if _input_digest(Path(root).resolve(), product) != report["input_digest"]:
                    raise ValueError("The product or library changed during transfer. Reload and review the table before continuing.")
                result = definitions.save_draft(root, pack, actor_id, row["item_id"], row["values"],
                    expected_input_digest=canonical_digest, expected_draft_digest=draft_digest, allowed_packs=allowed_packs,
                    local_demo=True, can_write=True)
                if not result.get("ok"):
                    raise ValueError("The draft transfer stopped: " + "; ".join(result.get("errors") or ["Reload the current row draft."]))
                transferred.append(row["item_id"])
            if transferred:
                state["history"].append({"action": "transfer_to_drafts", "actor_id": actor_id.strip(), "at": _now(),
                                         "items": transferred, "input_digest": report["input_digest"]})
                _write(root, product, path, state, report)
        return {"ok": True, "errors": [], "changed": bool(transferred), "transferred": transferred, "conflicts": [],
                "message": "Prepared rows are saved as your row drafts. Continue through the existing definition checks and contract review.",
                "draft_only": True, "approved": False, "approval_created": False}
    except (ValueError, TypeError, KeyError, AttributeError, OSError, RecursionError, yaml.YAMLError, definitions.dw._DraftError) as error:
        return {**_fail(error), "changed": bool(transferred), "transferred": transferred, "conflicts": [],
                "draft_only": True, "approval_created": False}
