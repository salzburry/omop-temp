"""Retain reviewed coding-agent outputs and apply checked capability metadata.

Generated code remains an inspectable branch artifact. The existing capability
registry owns source/test resolution; no proposed code is imported or executed.
"""
from __future__ import annotations

import ast
from datetime import datetime, timezone
import difflib
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import tempfile

import yaml
import science_workspace as science
import source_workspace as storage
import specialist_workspace as specialist
import handoffs

ROUTE = "implementation_patterns"
FOLDER = "handoff/IMPLEMENTATION_REVIEWS"
NOTICE = "Reviewed branch artifacts and checked registry declarations. Runtime execution requires a separate confirmed check of the installed code. No scientific approval or release is recorded."
LIMIT = 2_000_000


def _guard(fn):
    def wrapped(*args, **kwargs):
        try:
            return fn(*args, **kwargs)
        except (ValueError, OSError, TypeError, KeyError, AttributeError, SyntaxError, handoffs.Refused, yaml.YAMLError, subprocess.SubprocessError) as error:
            return {"ok": False, "errors": [str(error)], "changed": False, "notice": NOTICE}
    return wrapped


def _coding():
    path = str(Path(__file__).resolve().parents[1] / "agent")
    if path not in sys.path:
        sys.path.insert(0, path)
    import coding_agent
    return coding_agent


def _scope(root, pack, actor, allowed):
    root, product, pack, owner, folder = storage._scope(root, pack, actor, allowed)
    return root, product, pack, owner, science._safe(folder / "patterns")


def _semantic_digest(root, pack):
    files = specialist._inputs(root, pack)
    return science._digest({name: raw for name, raw in files.items()
                           if name.startswith(pack + "/") or name.startswith(".claude/skills/")})


def _path(product, identifier):
    if not re.fullmatch(r"[a-f0-9]{24}", str(identifier)):
        raise ValueError("Choose a retained implementation review for this product.")
    return science._safe(product / FOLDER / identifier / "review.json")


def _read(path, pack):
    if path.stat().st_size > LIMIT:
        raise ValueError("The implementation review exceeds its metadata limit.")
    record = json.loads(path.read_bytes())
    unsigned = dict(record)
    digest = unsigned.pop("digest", None)
    if science._hash(unsigned) != digest or record.get("pack") != pack or record.get("id") != path.parent.name:
        raise ValueError("The retained implementation review was changed or belongs to another product.")
    for name, expected in record["files"].items():
        if name not in {"candidate.py", "candidate_tests.py"}:
            raise ValueError("The review names an unsupported artifact.")
        if science._hash(science._safe(path.parent / name).read_bytes()) != expected:
            raise ValueError("The retained code or tests changed after review. Retain a fresh result.")
    return record


@_guard
def persist_result(root, pack, actor_id, *, run_id=None, review_id=None, note, confirmed=False,
                   allowed_packs=None, local_demo=False, can_write=False, can_review=False):
    storage._authorized(local_demo, can_write)
    if can_review is not True or confirmed is not True:
        raise ValueError("An authorized reviewer must inspect the code, tests and findings and confirm retention.")
    root, product, pack, _owner, _folder = _scope(root, pack, actor_id, allowed_packs)
    if bool(run_id) == bool(review_id):
        raise ValueError("Choose one exact private result or shared review result.")
    source = (specialist.read(root, pack, actor_id, run_id, allowed_packs=allowed_packs) if run_id else
              specialist.shared(root, pack, review_id, allowed_packs=allowed_packs))
    if source["kind"] != "implementation" or source.get("stale"):
        raise ValueError("Choose a current implementation result; changed evidence needs a fresh run.")
    result = source["result"]
    if result.get("requirement") != source.get("question") or result.get("pack") != pack:
        raise ValueError("The result does not match its reviewed requirement.")
    code = _coding()
    proposal = result["proposal"]
    generated = proposal.get("generated") or {}
    if not generated.get("code") or not generated.get("tests") or result.get("pattern") != code.pattern_metadata(generated["code"]):
        raise ValueError("This result has no checked generated code pattern. Reuse its registered capability through Plan changes.")
    if (result.get("deterministic_checks", {}).get("static_findings") or
            result.get("deterministic_checks", {}).get("code_compiles") is not True or
            result.get("deterministic_checks", {}).get("tests_compiles") is not True or
            result.get("provenance", {}).get("identifier_guard") != "ok"):
        raise ValueError("Resolve the static or source-identifier refusal before retaining an implementation pattern.")
    if not code.context_current(result.get("implementation_context"), root=root):
        raise ValueError("Implementation or test sources changed; request a current result.")
    checks, guard = code.static_review(proposal, pack, root=root,
        orchestration=result.get("implementation_context", {}).get("orchestration"))
    if checks != result["deterministic_checks"] or guard["status"] != "ok" or checks["static_findings"]:
        raise ValueError("The code no longer passes its exact static/source checks. Request a current result.")
    # Compile only: this does not import or run either artifact.
    for key in ("code", "tests"):
        compile(generated[key], "<reviewed " + key + ">", "exec")
    note = handoffs._text(note, "the actual reviewer findings and unresolved work")
    specialist.ai._ingress(note)
    identifier = source["id"]
    path = _path(product, identifier)
    snapshot = _semantic_digest(root, pack)
    files = {"candidate.py": generated["code"].encode(), "candidate_tests.py": generated["tests"].encode()}
    record = {"id": identifier, "pack": pack, "requirement": source["question"], "actor": actor_id,
        "created_at": datetime.now(timezone.utc).isoformat(), "review_note": note,
        "input_digest": snapshot, "originating_result_digest": source["digest"],
        "pattern": result["pattern"], "result": result, "skills": source.get("skills", []),
        "files": {name: science._hash(raw) for name, raw in files.items()},
        "state": "retained for implementation review", "notice": NOTICE}
    record["digest"] = science._hash(record)
    if len(json.dumps(record, ensure_ascii=False).encode()) > LIMIT:
        raise ValueError("The reviewed implementation exceeds the bounded artifact metadata size.")
    if path.exists():
        existing = _read(path, pack)
        if existing["originating_result_digest"] != source["digest"]:
            raise ValueError("A different implementation review already occupies this immutable result id.")
        return {"ok": True, "record": existing, "changed": False}
    if _semantic_digest(root, pack) != snapshot or not code.context_current(result["implementation_context"], root=root):
        raise ValueError("Evidence changed before retention. Nothing was saved.")
    science._safe(path.parent.parent).mkdir(parents=True, exist_ok=True)
    created = []
    try:
        path.parent.mkdir()  # Exclusive immutable review directory.
        for name, raw in files.items():
            file = path.parent / name
            with file.open("xb") as handle:
                created.append(file)
                handle.write(raw)
        with path.open("xb") as handle:
            created.append(path)
            handle.write(json.dumps(record, ensure_ascii=False, indent=2).encode())
    except BaseException:
        for file in reversed(created):
            file.unlink(missing_ok=True)
        if created:
            path.parent.rmdir()
        raise
    return {"ok": True, "record": record, "changed": True, "notice": NOTICE}


@_guard
def retained(root, pack, actor_id, *, record_id, allowed_packs=None):
    root, product, pack, _owner, _folder = _scope(root, pack, actor_id, allowed_packs)
    record = _read(_path(product, record_id), pack)
    return {"ok": True, "record": record, "stale": record["input_digest"] != _semantic_digest(root, pack) or not _orchestration_current(root, record)}


def _orchestration_current(root, record):
    context = record.get("result", {}).get("implementation_context", {}).get("orchestration")
    if context is None:
        return True  # Historical records never claimed this additional evidence.
    try:
        return context == _coding().orchestration_context(record["pack"], root=root)
    except (ValueError, OSError, TypeError, AttributeError, KeyError):
        return False


@_guard
def request_implementation(root, pack, actor_id, *, record_id, note, allowed_packs=None, local_demo=False, can_write=False):
    storage._authorized(local_demo, can_write)
    root, product, pack, _, _ = _scope(root, pack, actor_id, allowed_packs)
    record = _read(_path(product, record_id), pack)
    if record["input_digest"] != _semantic_digest(root, pack) or not _orchestration_current(root, record):
        raise ValueError("Scientific or source context changed. Review a current implementation result before requesting Engineering work.")
    note = handoffs._text(note, "the implementation work needed")
    if len(note) > 2000:
        raise ValueError("Keep the implementation request under 2,000 characters; the exact artifacts carry the code and checks.")
    specialist.ai._ingress(note)
    action = "implementation-review:" + record_id + ":" + record["digest"]
    body = note + " Exact reviewed artifacts: " + pack + "/" + FOLDER + "/" + record_id + "/review.json, candidate.py and candidate_tests.py. Review the recorded assumptions, connect the actual engine entry point and R counterpart, and run the relevant canonical stage/conformance tests in the supported runtime. Return to Reuse and improve implementation code to validate the present symbols and exact registry diff. No approval, runtime execution or release is recorded by this request."
    existing = next((item for item in handoffs.listing(root, pack, allowed_packs=allowed_packs, include_closed=False) if item.get("action_id") == action), None)
    doc = existing or handoffs.create(root, pack, title="Implement and validate " + record["requirement"], owner="Engineering", note=body,
        requested_by=actor_id, action_id=action, allowed_packs=allowed_packs, local_demo=local_demo, can_view=can_write)
    return {"ok": True, "handoff": doc, "changed": False}


def review_target(root, pack, actor_id, handoff_id, *, allowed_packs=None):
    """A work request reopens only its exact intact product implementation review."""
    _, product, pack, _, _ = _scope(root, pack, actor_id, allowed_packs)
    request = handoffs.load(root, pack, handoff_id, allowed_packs=allowed_packs)
    match = re.fullmatch(r"implementation-review:([a-f0-9]{24}):([a-f0-9]{64})", str(request.get("action_id", "")))
    if not match:
        raise ValueError("The work request does not name an exact implementation review.")
    record = _read(_path(product, match[1]), pack)
    if record["digest"] != match[2]:
        raise ValueError("The implementation review changed after this work request. Ask its author for a current request.")
    return {"route": ROUTE, "params": {"record_id": record["id"], "variable": record["requirement"]}}


def _registry_inputs(root, entry=None):
    from engine.strict_yaml import strict_load_path
    registry = _coding()._source_path(root, "capabilities.yaml")
    doc = strict_load_path(registry)
    entries = doc.get("capabilities") or []
    if not isinstance(entries, list):
        raise ValueError("Repair the canonical capability registry before continuing.")
    refs = {"platform/capabilities.yaml", "platform/CAPABILITIES.md", "platform/tools/capability_registry.py"}
    for cap in [*entries, *([entry] if entry else [])]:
        for item in cap.get("python", []):
            refs.add(item["module"])
        for item in cap.get("r", []):
            refs.add(item["file"])
        for test in cap.get("tests", []):
            refs.add(test.split("::", 1)[0])
    hashes = {}
    for name in sorted(refs):
        if not name.startswith("platform/"):
            raise ValueError("Capability source and tests must name declared files inside platform.")
        path = _coding()._source_path(root, name)
        if path.stat().st_size > LIMIT:
            raise ValueError("A declared capability source exceeds the bounded review size.")
        hashes[name] = science._hash(path.read_bytes())
    inventory = science._safe(root / "governance/reference/variable_inventory/INVENTORY.yaml")
    hashes[inventory.relative_to(root).as_posix()] = science._hash(inventory.read_bytes())
    return doc, hashes


def _run(root, entry=None):
    payload = {"root": str(root), "entry": entry}
    result = subprocess.run([sys.executable, str(Path(__file__).resolve()), "--worker"], input=json.dumps(payload),
        cwd=root, capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=45,
        env={**os.environ, "PYTHONDONTWRITEBYTECODE": "1"})
    if result.returncode or len(result.stdout.encode()) > LIMIT:
        raise ValueError("The canonical capability check could not finish. Run platform/tools/capability_registry.py --check to inspect the checkout.")
    return json.loads(result.stdout)


@_guard
def describe(root, pack, actor_id, *, allowed_packs=None):
    root, _product, pack, _owner, _folder = _scope(root, pack, actor_id, allowed_packs)
    scope = set(allowed_packs) if allowed_packs is not None else {pack}
    if pack not in scope:
        raise ValueError("The selected product is outside your access.")
    rows, problems = [], []
    for name in sorted(scope):
        _, product, name, _, _ = _scope(root, name, actor_id, scope)
        snapshot = _semantic_digest(root, name)
        for path in sorted((product / FOLDER).glob("*/review.json")):
            try:
                record = _read(science._safe(path), name)
                rows.append({"id": record["id"], "pack": name, "requirement": record["requirement"],
                    "key": record["pattern"]["key"], "created_at": record["created_at"],
                    "stale": record["input_digest"] != snapshot})
            except (ValueError, OSError, KeyError, TypeError):
                problems.append("A retained implementation review in " + name + " needs repair.")
    groups = {}
    for row in rows:
        if not row["stale"]:
            groups.setdefault(row["key"], set()).add((row["pack"], row["requirement"]))
    doc, hashes = _registry_inputs(root)
    checked = _run(root)
    if _registry_inputs(root)[1] != hashes:
        raise ValueError("Capability sources changed while checking. Reload the current registry.")
    return {"ok": True, "rows": rows, "patterns": [{"key": key, "distinct_contexts": len(contexts),
        "contexts": sorted(contexts), "recurring": len(contexts) >= 3} for key, contexts in sorted(groups.items())],
        "capabilities": doc["capabilities"], "errors": checked.get("errors", []), "problems": problems,
        "input_digest": science._hash(hashes), "notice": NOTICE}


def _entry(doc, values):
    fields = {"base_capability_id", "id", "summary", "python_module", "python_symbol", "r_file", "r_symbol", "config_keys", "emits", "tests"}
    if not isinstance(values, dict) or set(values) != fields:
        raise ValueError("Use only the displayed capability fields; verification is declared until independently demonstrated.")
    base = next((cap for cap in doc["capabilities"] if cap["id"] == values["base_capability_id"]), None)
    if not base:
        raise ValueError("Choose the existing capability family this implementation adapts.")
    if any(cap["id"] == values["id"] for cap in doc["capabilities"]):
        raise ValueError("Choose a new capability id. Existing registry entries are not overwritten here.")
    for key in fields - {"config_keys", "emits", "tests"}:
        if not isinstance(values[key], str) or not values[key].strip() or len(values[key]) > 2000:
            raise ValueError("Complete every capability identity and real implementation symbol.")
    if not re.fullmatch(r"[a-z][a-z0-9_.-]{2,100}", values["id"]):
        raise ValueError("Use a new lowercase capability identifier with letters, digits, dots, underscores or hyphens.")
    for key in ("config_keys", "emits", "tests"):
        if not isinstance(values[key], list) or not values[key] or len(values[key]) > 40 or any(not isinstance(x, str) or not x.strip() or len(x) > 300 for x in values[key]):
            raise ValueError("Declare bounded nonempty config keys, outputs and exact test references.")
    entry = {"id": values["id"], "master": base["master"], "supports": base["supports"], "summary": values["summary"],
        "verification": {"python": "declared", "r": "declared"}, "config_keys": values["config_keys"],
        "python": [{"module": values["python_module"], "symbol": values["python_symbol"]}],
        "r": [{"file": values["r_file"], "symbol": values["r_symbol"]}], "emits": values["emits"], "tests": values["tests"]}
    if base.get("upstream_table"):
        entry["upstream_table"] = base["upstream_table"]
    return entry


def _matches_retained(root, record, entry):
    """Require reviewed function/test ASTs in real target files, never execute them."""
    generated = record["result"]["proposal"]["generated"]
    for field, targets in (("code", [(i["module"], i["symbol"]) for i in entry["python"]]),
                           ("tests", [tuple(ref.split("::", 1)) for ref in entry["tests"] if "::" in ref])):
        expected = [n for n in ast.parse(generated[field]).body if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef))]
        actual = []
        for relative, symbol in targets:
            actual.extend(n for n in ast.parse(_coding()._source_path(root, relative).read_text(encoding="utf-8-sig")).body
                          if getattr(n, "name", None) == symbol)
        if not expected or any(ast.dump(n, include_attributes=False) not in {ast.dump(a, include_attributes=False) for a in actual} for n in expected):
            raise ValueError("The reviewed " + field + " is not present in the named implementation/test symbols. Engineering must adapt and review the actual source on this branch before registering it.")


def _connected_to_base(root, base, entry):
    """Conservative AST call path from an already registered engine function.

    Dynamic dispatch, new-module loading and execution coverage are not proven.
    Those changes require Engineering to establish the runtime integration first.
    """
    for implementation in entry["python"]:
        anchors = [item["symbol"] for item in base.get("python", []) if item["module"] == implementation["module"]]
        if not anchors:
            raise ValueError("A new Python module needs Engineering to wire it into the engine before capability registration. This form supports an existing base symbol or its direct same-module helper calls.")
        tree = ast.parse(_coding()._source_path(root, implementation["module"]).read_text(encoding="utf-8-sig"))
        functions = {node.name: node for node in tree.body if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef))}
        pending, reached = list(anchors), set()
        while pending:
            name = pending.pop()
            if name in reached:
                continue
            reached.add(name)
            node = functions.get(name)
            if node is not None:
                pending.extend(call.func.id for call in ast.walk(node) if isinstance(call, ast.Call)
                               and isinstance(call.func, ast.Name) and call.func.id in functions and call.func.id not in reached)
        if implementation["symbol"] not in reached:
            raise ValueError("The proposed function exists but is not called from the selected base capability. Engineering must connect and review the real engine call path before registration.")


def _proposal(root, pack, actor, record_id, values, allowed):
    root, product, pack, owner, folder = _scope(root, pack, actor, allowed)
    record = _read(_path(product, record_id), pack)
    if record["input_digest"] != _semantic_digest(root, pack) or not _orchestration_current(root, record):
        raise ValueError("The scientific or source context changed after the implementation review. Review a current result first.")
    doc, _ = _registry_inputs(root)
    entry = _entry(doc, values)
    _, inputs = _registry_inputs(root, entry)
    _matches_retained(root, record, entry)
    _connected_to_base(root, next(cap for cap in doc["capabilities"] if cap["id"] == values["base_capability_id"]), entry)
    checked = _run(root, entry)
    if checked.get("errors"):
        raise ValueError("; ".join(checked["errors"]))
    if (_registry_inputs(root, entry)[1] != inputs or record["input_digest"] != _semantic_digest(root, pack)
            or not _orchestration_current(root, record)):
        raise ValueError("Sources changed during validation. Check the current implementation again.")
    files = []
    for name, after in (("platform/capabilities.yaml", checked["yaml"]), ("platform/CAPABILITIES.md", checked["markdown"])):
        before = (root / name).read_bytes().decode("utf-8")
        files.append({"path": name, "before": before, "before_sha256": storage._sha(before.encode()), "after": after,
                      "diff": "".join(difflib.unified_diff(before.splitlines(True), after.splitlines(True), name, name + " (proposed)"))})
    return root, folder, {"record_id": record_id, "pack": pack, "owner": owner, "values": values, "entry": entry,
        "inputs": inputs, "source_digest": record["input_digest"], "review_digest": record["digest"], "files": files,
        "validation": "Canonical registry check passed; Python/R symbols and test names resolve. The Python symbol is an existing base entry or reachable through same-module calls. This is static integration evidence; no runtime tests were run.",
        "impact": {"master": entry["master"], "config_keys": entry["config_keys"], "emits": entry["emits"],
                   "existing_consumers_changed": False, "consumer_action": "Explicitly configure the accepted capability in Plan changes; existing products are not edited."}}


@_guard
def stage(root, pack, actor_id, *, record_id, values, allowed_packs=None, local_demo=False, can_write=False, can_review=False):
    storage._authorized(local_demo, can_write)
    if can_review is not True:
        raise ValueError("Capability review requires an authorized reviewer.")
    _, folder, proposal = _proposal(root, pack, actor_id, record_id, values, allowed_packs)
    proposal["id"] = hashlib.sha256(json.dumps(proposal, sort_keys=True).encode()).hexdigest()[:24]
    proposal["digest"] = science._hash(proposal)
    handoffs._write(science._safe(folder / (proposal["id"] + ".json")), proposal)
    return {"ok": True, "proposal": proposal, "changed": False}


@_guard
def apply(root, pack, actor_id, *, proposal_id, confirmed=False, allowed_packs=None, local_demo=False,
          can_write=False, can_review=False, can_manage_library=False):
    storage._authorized(local_demo, can_write)
    if can_review is not True or can_manage_library is not True or confirmed is not True:
        raise ValueError("An authorized shared-library administrator must review the exact diff and explicitly confirm this registry save.")
    root, _, _, owner, folder = _scope(root, pack, actor_id, allowed_packs)
    import review_inbox
    lock_folder = science._safe(folder.parents[2])
    lock_folder.mkdir(parents=True, exist_ok=True)
    try:
        lock = review_inbox._lock(lock_folder / "capability-registry.json")
    except review_inbox.Refused:
        raise ValueError("Another shared capability save is in progress. Reload after it finishes.") from None
    try:
        return _apply_checked(root, pack, actor_id, owner, folder, proposal_id, allowed_packs)
    finally:
        review_inbox._unlock(lock)


def _apply_checked(root, pack, actor_id, owner, folder, proposal_id, allowed_packs):
    if not re.fullmatch(r"[a-f0-9]{24}", str(proposal_id)):
        raise ValueError("Choose a checked capability proposal.")
    path = science._safe(folder / (proposal_id + ".json"))
    if path.stat().st_size > LIMIT:
        raise ValueError("The capability proposal exceeds its size limit.")
    proposal = json.loads(path.read_bytes())
    unsigned = dict(proposal)
    digest = unsigned.pop("digest", None)
    if science._hash(unsigned) != digest or proposal["owner"] != owner or proposal["pack"] != pack:
        raise ValueError("The capability proposal changed or belongs to another editing identity.")
    _, _, fresh = _proposal(root, pack, actor_id, proposal["record_id"], proposal["values"], allowed_packs)
    if fresh != {k: v for k, v in proposal.items() if k not in {"id", "digest"}}:
        raise ValueError("The checked capability or sources changed. Stage the current diff before applying it.")
    application_path = _path(root / pack, proposal["record_id"]).with_name("capability_application.json")
    if application_path.exists():
        raise ValueError("This implementation review already has an immutable capability application record. Review that saved declaration before preparing another implementation review.")
    # Reuse the existing byte-owned draft transaction; no generated Python/R is installed.
    import delivery_binding
    delivery_binding._replace_files(root, proposal["files"])
    try:
        checked = _run(root)
        expected = dict(proposal["inputs"])
        expected.update({item["path"]: science._hash(item["after"].encode()) for item in proposal["files"]})
        if (checked.get("errors") or _registry_inputs(root)[1] != expected or
                _semantic_digest(root, pack) != proposal["source_digest"] or
                not _orchestration_current(root, _read(_path(root / pack, proposal["record_id"]), pack))):
            raise ValueError("The saved registry or its source context changed during validation. Our registry save was rolled back.")
        application = {"pack": pack, "record_id": proposal["record_id"], "review_digest": proposal["review_digest"],
            "capability_id": proposal["entry"]["id"], "proposal_digest": proposal["digest"], "actor": actor_id,
            "created_at": datetime.now(timezone.utc).isoformat(), "validation": proposal["validation"],
            "files": [{"path": item["path"], "before_sha256": item["before_sha256"],
                       "after_sha256": science._hash(item["after"].encode())} for item in proposal["files"]],
            "notice": NOTICE, "implementation_values": proposal["values"]}
        application["digest"] = science._hash(application)
        handoffs._write(application_path, application)
    except BaseException:
        reverse = [{**item, "before": item["after"], "after": item["before"], "before_sha256": storage._sha(item["after"].encode())} for item in proposal["files"]]
        delivery_binding._replace_files(root, reverse)
        raise
    return {"ok": True, "changed": True, "capability_id": proposal["entry"]["id"], "notice": NOTICE,
        "message": "Capability declaration and canonical catalogue saved on this branch. Commit/review and scientific validation remain required; configure its use through Plan changes."}


def recent(root, pack, actor_id, *, allowed_packs=None):
    try:
        _, product, pack, _, _ = _scope(root, pack, actor_id, allowed_packs)
        rows = [_read(path, pack) for path in sorted((product / FOLDER).glob("*/review.json"))]
        return [{"id": r["id"], "route": ROUTE, "title": "Implementation Â· " + r["requirement"],
            "state": r["state"], "summary": "Reviewed code and tests retained on the product branch.",
            "updated_at": r["created_at"], "params": {"record_id": r["id"], "variable": r["requirement"]}} for r in rows]
    except (OSError, ValueError, KeyError, TypeError):
        return []


def read_application(root, pack, record_id, *, allowed_packs=None):
    """Exact current application bytes for the existing branch-checkpoint consumer."""
    product, pack = handoffs._pack_dir(root, pack, allowed_packs)
    root = Path(root).resolve()
    storage._configured_inputs(product)
    record = _read(_path(product, record_id), pack)
    path = science._safe(_path(product, record_id).with_name("capability_application.json"))
    if path.stat().st_size > 10000:
        raise ValueError("The capability application record exceeds its metadata size limit.")
    application = json.loads(path.read_bytes())
    unsigned = dict(application)
    digest = unsigned.pop("digest", None)
    if (science._hash(unsigned) != digest or application.get("pack") != pack or application.get("record_id") != record_id
            or application.get("review_digest") != record["digest"]
            or not re.fullmatch(r"[a-f0-9]{64}", str(application.get("proposal_digest", "")))):
        raise ValueError("This capability application does not match its retained product review.")
    files = application.get("files")
    if not isinstance(files, list) or len(files) != 2 or {row.get("path") for row in files if isinstance(row, dict)} != {"platform/capabilities.yaml", "platform/CAPABILITIES.md"}:
        raise ValueError("The application must identify the two exact canonical capability files.")
    for row in files:
        if (set(row) != {"path", "before_sha256", "after_sha256"}
                or any(not re.fullmatch(r"[a-f0-9]{64}", str(row.get(key, ""))) for key in ("before_sha256", "after_sha256"))
                or science._hash(_coding()._source_path(root, row["path"]).read_bytes()) != row["after_sha256"]):
            raise ValueError("The capability files changed after the recorded application. Review the current shared diff before checkpointing it.")
    return application


def _synthetic():
    canonical = Path(__file__).resolve().parents[2] / "platform"
    for path in (canonical, canonical / "tools"):
        if str(path) not in sys.path:
            sys.path.insert(0, str(path))
    import synthetic_expected
    return synthetic_expected


def _execution_controls():
    import heavy_runtime_queue
    import local_process_lock
    import process_lifetime
    return {Path(module.__file__).name: science._hash(Path(module.__file__).read_bytes())
            for module in (heavy_runtime_queue, local_process_lock, process_lifetime)}


def _case_options(root, pack, actor_id, record_id, allowed_packs):
    root, product, pack, owner, folder = _scope(root, pack, actor_id, allowed_packs)
    record = _read(_path(product, record_id), pack)
    if record["input_digest"] != _semantic_digest(root, pack) or not _orchestration_current(root, record):
        raise ValueError("Review the current implementation before preparing expected product outputs.")
    helper = _synthetic()
    from engine.strict_yaml import strict_load
    config = strict_load((product / "config/data_product.yaml").read_text(encoding="utf-8"))
    cohorts = config.get("cohorts", [])
    if not isinstance(cohorts, list) or not cohorts or any(not isinstance(c, dict) or not isinstance(c.get("id"), str) or type(c.get("cohortn")) is not int for c in cohorts):
        raise ValueError("Declare the product's cohorts before reviewing its expected synthetic outputs.")
    relative = pack + "/" + FOLDER + "/" + record_id + "/" + helper.NAME
    path = science._safe(root / relative)
    if path.is_file() and path.stat().st_size > helper.LIMIT:
        raise ValueError("The expected-output artifact exceeds its bounded size. Repair that review file before reopening it.")
    before = path.read_bytes() if path.is_file() else b""
    saved, issues = None, []
    if before:
        try:
            saved = helper.load(root, pack, relative, cohorts)
            if saved["review_digest"] != record["digest"]:
                raise ValueError("Expected cases belong to a different retained implementation review.")
        except ValueError as error:
            saved = None
            issues.append(str(error))
    value = {"context": helper.context(root, pack), "review_digest": record["digest"], "before_sha256": science._hash(before),
        "path": relative, "cohorts": [{"id": c["id"], "cohortn": c["cohortn"], "label": str(c.get("label", c["id"]))} for c in cohorts],
        "subjects": ["p1", *sorted({"pc" + str(c["cohortn"]) for c in cohorts})], "saved": saved, "issues": issues}
    value["digest"] = science._hash(value)
    return root, product, owner, folder, value


@_guard
def synthetic_case_options(root, pack, actor_id, *, record_id, allowed_packs=None):
    return {"ok": True, **_case_options(root, pack, actor_id, record_id, allowed_packs)[-1]}


@_guard
def preview_synthetic_cases(root, pack, actor_id, *, record_id, cases, note, expected_digest, allowed_packs=None):
    root, product, owner, folder, current = _case_options(root, pack, actor_id, record_id, allowed_packs)
    if current["digest"] != expected_digest:
        raise ValueError("The product, fixture or saved expectations changed. Reload before reviewing this diff.")
    helper = _synthetic()
    helper.validate_cases(cases, current["cohorts"])
    if not isinstance(note, str) or not 12 <= len(note.strip()) <= 2000:
        raise ValueError("Describe the independent basis for these literal expected values and any open scientific choices.")
    import scientific_definition_ai as ai
    try:
        ai._ingress(note + "\n" + json.dumps([c["expected"] for c in cases]))
    except ai.Invalid:
        raise ValueError("Use fabricated synthetic values only; remove sensitive information from the expectations and review note.") from None
    document = {"schema": 1, "context": current["context"], "review_digest": current["review_digest"], "cases": cases,
        "review_note": note.strip(), "recorded_by": actor_id, "recorded_at": datetime.now(timezone.utc).isoformat(),
        "scientific_approval": False}
    document["digest"] = helper.digest(document)
    before = (root / current["path"]).read_text(encoding="utf-8") if (root / current["path"]).is_file() else ""
    after = json.dumps(document, sort_keys=True, indent=2) + "\n"
    proposal = {"owner": owner, "pack": pack, "record_id": record_id, "expected_digest": expected_digest,
        "document": document, "path": current["path"], "before_sha256": current["before_sha256"],
        "diff": "".join(difflib.unified_diff(before.splitlines(True), after.splitlines(True), current["path"] + " (before)", current["path"] + " (reviewed draft)"))}
    proposal["id"] = science._hash(proposal)[:24]
    proposal["digest"] = science._hash(proposal)
    handoffs._write(science._safe(folder / ("cases-" + proposal["id"] + ".json")), proposal)
    return {"ok": True, "proposal": proposal}


@_guard
def save_synthetic_cases(root, pack, actor_id, *, record_id, proposal_id, confirmed=False,
                         allowed_packs=None, local_demo=False, can_write=False, can_review=False):
    storage._authorized(local_demo, can_write)
    if confirmed is not True or can_review is not True:
        raise ValueError("Review and explicitly confirm the synthetic expectations before saving them.")
    if not re.fullmatch(r"[a-f0-9]{24}", str(proposal_id)):
        raise ValueError("Choose a current reviewed expectation diff.")
    root, product, owner, folder, current = _case_options(root, pack, actor_id, record_id, allowed_packs)
    private = science._safe(folder / ("cases-" + proposal_id + ".json"))
    if private.stat().st_size > LIMIT:
        raise ValueError("The expected-output preview exceeds its bounded review size.")
    try:
        proposal = json.loads(private.read_bytes())
    except (ValueError, RecursionError, UnicodeError):
        raise ValueError("The expected-output preview is malformed. Prepare a new diff.") from None
    unsigned = dict(proposal); checksum = unsigned.pop("digest", None)
    if (checksum != science._hash(unsigned) or proposal["owner"] != owner or proposal["pack"] != pack or
            proposal["record_id"] != record_id or proposal["expected_digest"] != current["digest"]):
        raise ValueError("The expected-output review changed or belongs to another editing context.")
    doc_unsigned = dict(proposal["document"]); doc_digest = doc_unsigned.pop("digest", None)
    if (doc_digest != _synthetic().digest(doc_unsigned) or proposal["document"]["context"] != current["context"] or
            proposal["document"]["review_digest"] != current["review_digest"] or proposal["document"]["scientific_approval"] is not False):
        raise ValueError("The expectation document changed after the exact review preview.")
    import local_process_lock
    path = science._safe(root / current["path"])
    with local_process_lock.locked(path.with_suffix(".lock"), root):
        if _case_options(root, pack, actor_id, record_id, allowed_packs)[-1]["digest"] != proposal["expected_digest"]:
            raise ValueError("Expected outputs changed during saving. Reload the current diff.")
        _synthetic().validate_cases(proposal["document"]["cases"], current["cohorts"])
        handoffs._write(path, proposal["document"])
    return {"ok": True, "changed": True, "path": current["path"], "document": proposal["document"]}


def _runtime_binding(root, pack, actor_id, record_id, values, suite_ids, allowed_packs):
    import implementation_runtime as runtime
    root, product, pack, owner, folder = _scope(root, pack, actor_id, allowed_packs)
    record = _read(_path(product, record_id), pack)
    if record["input_digest"] != _semantic_digest(root, pack) or not _orchestration_current(root, record):
        raise ValueError("The implementation review's scientific or orchestration context changed. Review a current implementation before running it.")
    doc, _ = _registry_inputs(root)
    # Running installed code is possible both before and after the separate
    # registry save. An existing declaration must match these exact form values.
    present = next((cap for cap in doc["capabilities"] if cap["id"] == values.get("id")), None) if isinstance(values, dict) else None
    catalogue = {**doc, "capabilities": [cap for cap in doc["capabilities"] if cap is not present]}
    entry = _entry(catalogue, values)
    if present and present != entry:
        raise ValueError("The installed capability declaration differs from these fields. Review the current declaration before running its tests.")
    _registry_inputs(root, entry)
    _matches_retained(root, record, entry)
    _connected_to_base(root, next(cap for cap in doc["capabilities"] if cap["id"] == values["base_capability_id"]), entry)
    checked = _run(root, None if present else entry)
    if checked.get("errors"):
        raise ValueError("The existing canonical capability validator refused the installed implementation. Check its symbols, configuration keys and tests.")
    lanes = runtime.suites(suite_ids, entry["tests"])
    for lane in lanes:
        lane["dependency_mode"] = "suite_dependencies_v1"
        if lane["id"] == "selected_product":
            options = _case_options(root, pack, actor_id, record_id, allowed_packs)[-1]
            doc = options["saved"]
            lane["product_cases"] = {"path": options["path"], "digest": doc["digest"], "count": len(doc["cases"]),
                "ids": [case["id"] for case in doc["cases"]]} if doc else None
    snapshot = runtime.inputs(root, pack, lanes=lanes)
    if any(selector.split("::")[0] not in snapshot for lane in lanes for selector in lane["selectors"]):
        raise ValueError("A selected canonical test file is missing from this checkout. Restore it or choose another displayed suite.")
    review_digest = _read(_path(product, record_id), pack)["digest"]
    if review_digest != record["digest"] or record["input_digest"] != _semantic_digest(root, pack) or not _orchestration_current(root, record):
        raise ValueError("Review inputs changed during runtime preparation. Reload the review.")
    return root, folder, {"record_id": record_id, "review_digest": review_digest, "pack": pack, "owner": owner,
        "actor": actor_id, "root": str(root), "values": values, "entry": entry, "suite_ids": suite_ids, "lanes": lanes,
        "source_digest": record["input_digest"], "branch": runtime.branch(root), "inputs": snapshot,
        "dependency_manifest": runtime.test_dependencies(root, lanes),
        "runtime": runtime.prerequisites(), "runner_sha256": runtime.sha(Path(runtime.__file__).read_bytes()),
        "adapter_sha256": runtime.sha(Path(__file__).read_bytes()),
        "process_runner_sha256": runtime.sha(Path(runtime.portal_runtime.__file__).read_bytes()),
        "execution_controls": _execution_controls(),
        "coverage": {"declared_tests": "Reviewed tests of the installed implementation", "broad_suites": "Existing repository synthetic reference fixtures",
                     "selected_product_build": False, "scientific_approval": False, "delivery_validation": False},
        "notice": runtime.NOTICE}


@_guard
def runtime_preview(root, pack, actor_id, *, record_id, values, suite_ids, allowed_packs=None):
    """Check real installation and freeze the exact code/config/tests for review."""
    _, folder, proposal = _runtime_binding(root, pack, actor_id, record_id, values, suite_ids, allowed_packs)
    # A new explicit preview may request a new attempt after a transient failure.
    # Running/resuming this same proposal remains idempotent and never retries.
    proposal["requested_at"] = datetime.now(timezone.utc).isoformat()
    proposal["id"] = science._hash(proposal)[:24]
    proposal["digest"] = science._hash(proposal)
    handoffs._write(science._safe(folder / ("runtime-" + proposal["id"] + ".json")), proposal)
    return {"ok": True, "proposal": proposal, "changed": False}


def _runtime_path(product, record_id, identifier):
    if not re.fullmatch(r"[a-f0-9]{24}", str(identifier)):
        raise ValueError("Choose a saved runtime review.")
    return science._safe(_path(product, record_id).with_name("runtime-" + identifier + ".json"))


def _runtime_followups(root, pack, lanes, allowed_packs):
    import implementation_runtime as runtime
    codes = {test["skip_code"] for lane in lanes for test in lane.get("tests", []) if test.get("skip_code") in runtime.SKIP_CODES}
    followups = []
    if not codes:
        return followups
    import decision_answers
    questions = decision_answers.describe(root, pack, allowed_packs)
    existing = {item["id"] for item in questions.get("items", [])} | set(questions.get("unissued_ids", []))
    for code in sorted(codes):
        for decision in runtime.SKIP_CODES[code]["decisions"]:
            if decision in existing:
                followups.append({"code": code, "label": "Review " + decision, "route": "questions", "params": {"decision_id": decision}})
        if runtime.SKIP_CODES[code]["decisions"] and not existing.intersection(runtime.SKIP_CODES[code]["decisions"]):
            followups.append({"code": code, "label": "Review applicable scientific questions", "route": "questions", "params": {},
                "explanation": "This skip belongs to a reference scenario. Its decision identifiers are not issued for this product; review applicability before raising or answering a product question."})
    return followups


def read_runtime(root, pack, record_id, runtime_id, *, allowed_packs=None):
    """Read exact historical outcomes and independently check current file binding."""
    import implementation_runtime as runtime
    root = Path(root).resolve()
    product, pack = handoffs._pack_dir(root, pack, allowed_packs)
    storage._configured_inputs(product)
    record = _read(_path(product, record_id), pack)
    path = _runtime_path(product, record_id, runtime_id)
    if path.stat().st_size > runtime.MAX_REPORT:
        raise ValueError("The saved runtime outcome exceeds its metadata size limit.")
    receipt = json.loads(path.read_bytes())
    if not isinstance(receipt, dict) or not isinstance(receipt.get("proposal"), dict):
        raise ValueError("The saved runtime record is malformed.")
    unsigned = dict(receipt)
    digest = unsigned.pop("digest", None)
    proposal = receipt.get("proposal", {})
    expected = dict(proposal)
    proposed_digest = expected.pop("digest", None)
    if (science._hash(unsigned) != digest or receipt.get("id") != runtime_id or receipt.get("record_id") != record_id
            or receipt.get("pack") != pack or receipt.get("review_digest") != record["digest"]
            or proposed_digest != science._hash(expected) or proposal.get("record_id") != record_id
            or proposal.get("review_digest") != record["digest"] or proposal.get("pack") != pack
            or proposal.get("id") != runtime_id or not re.fullmatch(r"[a-f0-9]{64}", str(proposal.get("checkout_id", "")))
            or receipt.get("type") != "installed_implementation_runtime" or receipt.get("notice") != runtime.NOTICE):
        raise ValueError("The saved runtime outcome does not match its exact retained implementation review.")
    outcomes = receipt.get("outcome", {})
    if (not isinstance(outcomes, dict) or not isinstance(proposal.get("lanes"), list)
            or not isinstance(proposal.get("inputs"), dict) or not isinstance(proposal.get("entry"), dict)
            or not isinstance(proposal.get("values"), dict) or not isinstance(proposal.get("branch"), dict)
            or not re.fullmatch(r"[a-f0-9]{40,64}", str(proposal["branch"].get("head", "")))
            or not isinstance(proposal["branch"].get("name"), str)):
        raise ValueError("The runtime source and branch binding is malformed.")
    lanes = outcomes.get("lanes", [])
    if (not isinstance(lanes, list) or not 1 <= len(lanes) <= len(runtime.SUITES) or len(lanes) != len(proposal.get("lanes", []))
            or any(not isinstance(lane, dict) or not isinstance(selected, dict) or lane.get("id") != selected.get("id") or lane.get("selectors") != selected.get("selectors")
                   or not isinstance(lane.get("selectors"), list) or not lane["selectors"]
                   or any(not isinstance(selector, str) for selector in lane["selectors"])
                   or lane.get("status") not in {"passed", "failed", "partial", "skipped", "error", "timeout", "unavailable", "cancelled"}
                   for lane, selected in zip(lanes, proposal["lanes"]))):
        raise ValueError("The saved test outcomes do not match the selected runtime suites.")
    for lane in lanes:
        local_pipeline = any(selector.split("::")[0] in {"platform/tests/test_synthetic_spark_uat.py", "platform/tests/test_selected_product_outputs.py"}
                             for selector in lane["selectors"])
        if local_pipeline and lane["status"] == "passed" and (
                lane.get("execution_mode") != "local_cohort_checkpoints" or
                lane.get("expected_execution_mode") != "local_cohort_checkpoints" or
                lane.get("cluster_recovery_tested") is not False):
            raise ValueError("A passing local pipeline lane must retain its observed local execution mode; it cannot prove cluster recovery.")
        tests = lane.get("tests", [])
        if not isinstance(tests, list) or any(not isinstance(test, dict) or test.get("outcome") not in {"passed", "failed", "error", "skipped"} for test in tests):
            raise ValueError("The runtime case outcomes are malformed.")
        if any(test.get("skip_code") not in {None, *runtime.SKIP_CODES} or
               (test.get("skip_code") and test["outcome"] != "skipped") for test in tests):
            raise ValueError("The runtime scientific skip code contradicts its case outcome.")
        if lane["id"] == "selected_product":
            selected = next(item for item in proposal["lanes"] if item["id"] == lane["id"])
            cases = selected.get("product_cases") or {}
            if lane.get("selected_product_build") is True and (lane["status"] != "passed" or
                    lane.get("execution_mode") != "local_cohort_checkpoints" or
                    lane.get("product_cases_digest") != cases.get("digest") or
                    lane.get("expected_case_count") != cases.get("count") or not cases.get("count") or
                    sorted(lane.get("expected_cases", []), key=lambda item: item["id"]) !=
                    sorted([{"id": name, "outcome": "passed"} for name in cases.get("ids", [])], key=lambda item: item["id"])):
                raise ValueError("Selected-product execution must match the exact reviewed expectations and actual passing outcome.")
            if lane["status"] == "passed" and lane.get("selected_product_build") is not True:
                raise ValueError("A selected-product pass needs its verified expected-output marker.")
        if tests:
            counts = {name: sum(test["outcome"] == name for test in tests) for name in ("passed", "failed", "error", "skipped")}
            if lane.get("counts") != counts or not re.fullmatch(r"[a-f0-9]{64}", str(lane.get("report_sha256", ""))):
                raise ValueError("Runtime totals do not agree with the actual recorded case outcomes.")
            if lane["status"] == "passed" and (counts["passed"] != len(tests) or lane.get("exit_code") != 0 or lane.get("r_conformance") in {"skipped", "unproven"}):
                raise ValueError("An incomplete or failed test lane cannot be reported as passed.")
    actual_status = _runtime_status(outcomes, receipt.get("changed_during_run", True))
    if actual_status != receipt.get("status"):
        raise ValueError("The runtime summary contradicts its recorded test outcomes.")
    after = receipt.get("after")
    if (receipt.get("changed_during_run") is False and (not isinstance(after, dict)
            or any(after.get(key) != proposal.get(key) for key in ("branch", "inputs", "source_digest")))):
        raise ValueError("The runtime after snapshot contradicts its unchanged-context claim.")
    if outcomes.get("copy_unchanged") is True and outcomes.get("copied_after") != proposal["inputs"]:
        raise ValueError("The isolated execution snapshot changed despite its recorded unchanged claim.")
    try:
        scope_lanes = proposal["lanes"] if proposal.get("dependency_manifest", {}).get("mode") == "suite_dependencies_v1" else None
        current_inputs = runtime.inputs(root, pack, lanes=scope_lanes)
        differences = runtime.changed_files(proposal["inputs"], current_inputs)
        current_branch = runtime.branch(root)
        ancestor = runtime.portal_runtime.run(["git", "merge-base", "--is-ancestor", proposal["branch"]["head"], current_branch["head"]], cwd=str(root), timeout_s=5)
        stale = (current_branch["name"] != proposal["branch"]["name"] or ancestor.returncode != 0 or bool(differences)
                 or _semantic_digest(root, pack) != proposal["source_digest"] or not _orchestration_current(root, record)
                 or runtime.sha(Path(runtime.__file__).read_bytes()) != proposal["runner_sha256"]
                 or runtime.sha(Path(__file__).read_bytes()) != proposal["adapter_sha256"]
                 or runtime.sha(Path(runtime.portal_runtime.__file__).read_bytes()) != proposal["process_runner_sha256"])
        if proposal.get("execution_controls") is not None:
            stale = stale or proposal["execution_controls"] != _execution_controls()
    except (OSError, ValueError):
        stale = True
        differences = []
    if not stale:
        # Branch checkpoint consumers may offer these exact implementation
        # paths. Reuse the canonical installed-AST and engine-call-path guards,
        # rather than trusting edited metadata to authorize a shared code diff.
        doc, _ = _registry_inputs(root)
        entry = _entry({**doc, "capabilities": [cap for cap in doc["capabilities"] if cap["id"] != proposal["values"].get("id")]}, proposal["values"])
        if entry != proposal["entry"]:
            raise ValueError("The saved runtime implementation does not match its reviewed declaration.")
        _matches_retained(root, record, entry)
        base = next(cap for cap in doc["capabilities"] if cap["id"] == proposal["values"]["base_capability_id"])
        _connected_to_base(root, base, entry)
    followups = _runtime_followups(root, pack, lanes, allowed_packs)
    return {"ok": True, "receipt": receipt, "stale": stale, "changed_files": differences, "followups": followups,
        "freshness_explanation": "Review the listed changed dependencies." if differences else "Branch, runner or scientific review context changed." if stale else "The recorded dependencies are current.",
        "usable_pass": not stale and receipt["status"] == "passed"}


def _runtime_status(outcome, changed):
    if changed or outcome.get("copy_unchanged") is not True:
        return "stale"
    lanes = outcome.get("lanes", [])
    if not lanes:
        return "incomplete"
    if any(lane.get("status") == "cancelled" for lane in lanes):
        return "cancelled"
    if any(lane.get("status") in {"failed", "error"} for lane in lanes):
        return "failed"
    if any(lane.get("status") == "timeout" for lane in lanes):
        return "timeout"
    if any(lane.get("status") != "passed" for lane in lanes):
        return "incomplete"
    if any(not lane.get("tests") or not lane.get("report_sha256") for lane in lanes):
        return "incomplete"
    return "passed"


@_guard
def run_runtime(root, pack, actor_id, *, record_id, proposal_id, confirmed=False,
                allowed_packs=None, local_demo=False, can_write=False, can_review=False):
    import implementation_runtime as runtime
    storage._authorized(local_demo, can_write)
    if confirmed is not True or can_review is not True:
        raise ValueError("An authorized reviewer must explicitly confirm the installed code, selected tests and isolated runtime execution.")
    root, product, pack, owner, folder = _scope(root, pack, actor_id, allowed_packs)
    destination = _runtime_path(product, record_id, proposal_id)
    if destination.exists():
        return {**read_runtime(root, pack, record_id, proposal_id, allowed_packs=allowed_packs), "changed": False}
    path = science._safe(folder / ("runtime-" + proposal_id + ".json"))
    if path.stat().st_size > runtime.MAX_REPORT:
        raise ValueError("The runtime proposal exceeds its review size limit.")
    proposal = json.loads(path.read_bytes())
    unsigned = dict(proposal)
    digest = unsigned.pop("digest", None)
    if science._hash(unsigned) != digest or proposal.get("owner") != owner or proposal.get("record_id") != record_id or proposal.get("pack") != pack:
        raise ValueError("The runtime proposal changed or belongs to another editing identity.")
    _, _, fresh = _runtime_binding(root, pack, actor_id, record_id, proposal["values"], proposal["suite_ids"], allowed_packs)
    if fresh != {k: v for k, v in proposal.items() if k not in {"id", "digest", "requested_at"}}:
        raise ValueError("The branch, installed files, tests or runtime changed. Review a fresh runtime preview before execution.")
    import local_process_lock
    try:
        lock = local_process_lock.locked(destination.with_suffix(".lock"), root)
        lock.__enter__()
    except ValueError:
        raise ValueError("This runtime review is already running. Wait for its outcome before reopening it.") from None
    try:
        if destination.exists():
            return {**read_runtime(root, pack, record_id, proposal_id, allowed_packs=allowed_packs), "changed": False}
        outcome = runtime.execute(root, pack, proposal["inputs"], proposal["lanes"], proposal["runtime"])
        try:
            after = {"inputs": runtime.inputs(root, pack, lanes=proposal["lanes"]), "branch": runtime.branch(root), "source_digest": _semantic_digest(root, pack)}
            changed = any(after[key] != proposal[key] for key in after)
            changed = changed or (_read(_path(product, record_id), pack)["digest"] != proposal["review_digest"]
                or not _orchestration_current(root, _read(_path(product, record_id), pack))
                or runtime.sha(Path(runtime.__file__).read_bytes()) != proposal["runner_sha256"]
                or runtime.sha(Path(__file__).read_bytes()) != proposal["adapter_sha256"]
                or runtime.sha(Path(runtime.portal_runtime.__file__).read_bytes()) != proposal["process_runner_sha256"]
                or runtime.prerequisites() != proposal["runtime"])
            changed = changed or proposal.get("execution_controls") != _execution_controls()
        except (ValueError, OSError):
            after, changed = {"unavailable": True}, True
        # Shared branch outcomes retain version facts and executable hashes,
        # never a person's absolute checkout/interpreter/JDK/home paths.
        public_proposal = json.loads(json.dumps(proposal))
        public_proposal.pop("digest")
        public_proposal["checkout_id"] = runtime.sha(public_proposal.pop("root").encode())
        versions = public_proposal["runtime"]
        for key in ("python_executable", "java", "rscript"):
            executable = versions.pop(key, None)
            versions[key + "_available"] = bool(executable)
        public_proposal["digest"] = science._hash(public_proposal)
        receipt = {"id": proposal_id, "type": "installed_implementation_runtime", "record_id": record_id,
            "review_digest": proposal["review_digest"], "pack": pack, "actor": actor_id, "created_at": datetime.now(timezone.utc).isoformat(),
            "proposal": public_proposal, "outcome": outcome, "after": after, "changed_during_run": changed,
            "status": _runtime_status(outcome, changed), "notice": runtime.NOTICE}
        receipt["digest"] = science._hash(receipt)
        raw = json.dumps(receipt, sort_keys=True, indent=2).encode("utf-8")
        if len(raw) > runtime.MAX_REPORT:
            raise ValueError("The runtime receipt exceeds its bounded record size; no pass is recorded.")
        with destination.open("xb") as stream:
            stream.write(raw)
        return {"ok": True, "receipt": receipt, "stale": changed, "usable_pass": receipt["status"] == "passed", "changed": True}
    finally:
        lock.__exit__(None, None, None)


@_guard
def runtime_results(root, pack, actor_id, *, record_id, allowed_packs=None):
    root, product, pack, _, _ = _scope(root, pack, actor_id, allowed_packs)
    _read(_path(product, record_id), pack)
    rows = [read_runtime(root, pack, record_id, path.stem[8:], allowed_packs=allowed_packs)
            for path in sorted(_path(product, record_id).parent.glob("runtime-*.json"))]
    return {"ok": True, "results": rows}


def _worker(payload):
    root = Path(payload["root"]).resolve()
    sys.path[:0] = [str(root / "platform/tools"), str(root / "platform")]
    import capability_registry as registry
    # Canonical module in the chosen checkout owns its roots and schema.
    if registry.REPO.resolve() != root:
        raise ValueError("Start from the selected checkout's canonical checker.")
    doc = registry.load()
    if payload.get("entry"):
        doc["capabilities"].append(payload["entry"])
    inventory = registry.inventory_classes()
    errors = registry.registry_errors(doc, inventory)
    return {"errors": errors, "yaml": yaml.safe_dump(doc, sort_keys=False, allow_unicode=True),
            "markdown": registry.render_md(doc, inventory) if not errors else ""}


if __name__ == "__main__" and "--worker" in sys.argv:
    try:
        print(json.dumps(_worker(json.loads(sys.stdin.read()))))
    except Exception:
        print(json.dumps({"errors": ["The canonical capability metadata could not be read. Repair the declared registry files before continuing."]}))
