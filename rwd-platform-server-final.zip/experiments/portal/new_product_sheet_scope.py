"""Connect product registration to the existing per-product extraction scope.

Only sheet metadata reaches the form/chat. The selected workbook is never edited.
Selections are bound to its bytes and the current sheet map, not just its filename.
"""
from __future__ import annotations

import hashlib
import io
import json
from pathlib import Path
import re

import new_product
import specification_attachment as attachment
import ui_text as ui

SELECTION = "np_excluded_sheets"
REASON = "np_excluded_sheets_reason"
BINDING = "np_sheet_scope_binding"
HINT = "np_sheet_scope_hint"
HINT_MODE = "np_sheet_scope_hint_mode"
MAPPINGS = "np_sheet_domains"
MAPPING_REASON = "np_sheet_domain_reason"


def mapping_key(sheet):
    return "np_sheet_domain_choice_" + hashlib.sha256(sheet.encode()).hexdigest()[:16]


def validate_hint(value):
    """A private continuation hint carries no paths, workbook cells or approval."""
    extra = {"sheet_mappings", "mapping_reason", "mapping_previous_pack"}
    if (not isinstance(value, dict) or set(value) not in (
            {"workbook_sha256", "sheets", "reason"}, {"workbook_sha256", "sheets", "reason"} | extra)
            or not isinstance(value["workbook_sha256"], str) or not re.fullmatch(r"[0-9a-f]{64}", value["workbook_sha256"])
            or not isinstance(value["sheets"], list) or not 0 <= len(value["sheets"]) <= 100
            or any(not isinstance(name, str) or not name.strip() or len(name) > 128 or any(ord(c) < 32 for c in name) for name in value["sheets"])
            or len(set(value["sheets"])) != len(value["sheets"])
            or not isinstance(value["reason"], str) or len(value["reason"]) > 1000 or any(ord(c) < 32 for c in value["reason"])):
        raise ValueError("The saved sheet-scope hint is malformed. Choose the sheets again for this workbook.")
    mappings = value.get("sheet_mappings") or {}
    previous_pack = value.get("mapping_previous_pack")
    valid_previous = isinstance(previous_pack, str) and (previous_pack == "" or re.fullmatch(
        r"products/[a-z0-9_]+/[a-z0-9_]+/[0-9]{6}", previous_pack) is not None)
    if (not isinstance(mappings, dict) or len(mappings) > 100 or (not value["sheets"] and not mappings)
            or any(not isinstance(name, str) or not name or len(name) > 128 or any(ord(c) < 32 for c in name)
                or not isinstance(domain, str) or not re.fullmatch(r"[a-z][a-z0-9_]*", domain)
                for name, domain in mappings.items())
            or (mappings and (not isinstance(value.get("mapping_reason"), str)
                or len(value["mapping_reason"]) > 1000 or any(ord(c) < 32 for c in value["mapping_reason"])
                or not valid_previous))):
        raise ValueError("The saved sheet mapping is malformed. Choose the sections again for this workbook.")
    return {**value, "sheets": list(value["sheets"])}


def capture_hint(root, state):
    """Snapshot current choices only while bound to their exact selected source."""
    scope = describe(root, state)
    if scope.get("ok") and state.get(BINDING) == scope["binding"] and (state.get(SELECTION) or state.get(MAPPINGS)):
        selected = state.get(SELECTION) or []
        selectable = {row["name"] for row in scope["sheets"] if row["selectable"]}
        if isinstance(selected, list) and all(name in selectable for name in selected):
            hint = {"workbook_sha256": scope["sha256"], "sheets": selected,
                    "reason": str(state.get(REASON) or "")}
            if state.get(MAPPINGS):
                hint.update(sheet_mappings=dict(state[MAPPINGS]), mapping_reason=str(state.get(MAPPING_REASON) or ""),
                            mapping_previous_pack=scope.get("previous_pack") or "")
            return validate_hint(hint)
    # A resumed setup may be saved again before its workbook is reselected.
    if not scope.get("available") and state.get(HINT) and state.get(HINT_MODE) == state.get("np_mode"):
        return validate_hint(state[HINT])
    return None


def hint_status(scope, state):
    hint = state.get(HINT)
    if not hint:
        return {"available": False}
    try:
        hint = validate_hint(hint)
    except ValueError as error:
        return {"available": True, "eligible": False, "reason": str(error)}
    if state.get(HINT_MODE) != state.get("np_mode"):
        return {"available": True, "eligible": False, "reason": "The starting point changed. Choose sheet sections and exclusions for this setup; the saved choices have not been applied."}
    if not scope.get("ok") or hint["workbook_sha256"] != scope.get("sha256"):
        return {"available": True, "eligible": False, "reason": "Saved sheet choices belong to a different workbook. Select the original workbook or choose sheets for this one."}
    options = {row["name"] for row in scope["sheets"] if row["selectable"]}
    if any(name not in options for name in hint["sheets"]):
        return {"available": True, "eligible": False, "reason": "Saved exclusions no longer match the current sheet mapping. Review the available sheets and choose their scope again."}
    mappings = hint.get("sheet_mappings") or {}
    choices = {row["name"] for row in scope["sheets"] if row.get("mapping_selectable")}
    if mappings and (hint.get("mapping_previous_pack") != (scope.get("previous_pack") or "")
            or any(name not in choices or domain not in scope.get("mapping_domains", []) for name, domain in mappings.items())
            or set(mappings) & set(hint["sheets"])):
        return {"available": True, "eligible": False, "reason": "Saved sheet sections no longer match this starting point and workbook. Review the current mappings again."}
    return {"available": True, "eligible": state.get(BINDING) == scope["binding"], "hint": hint}


def restore_hint(scope, state, *, confirmed):
    status = hint_status(scope, state)
    if confirmed is not True or not status.get("eligible"):
        raise ValueError("Review the saved sheet choices against the current workbook and sheet mapping before restoring them.")
    hint = status["hint"]
    state[SELECTION] = list(hint["sheets"])
    state[REASON] = hint["reason"]
    state[MAPPINGS] = dict(hint.get("sheet_mappings") or {})
    state[MAPPING_REASON] = hint.get("mapping_reason") or ""
    for name, domain in state[MAPPINGS].items():
        state[mapping_key(name)] = domain
    state.pop("np_previewed", None)
    state.pop(HINT, None)
    state.pop(HINT_MODE, None)


def describe(root, state, *, allowed_packs=None):
    """Read the currently selected path/upload before chat and widgets render."""
    mode = state.get("np_mode")
    revised = mode == ui.NEW_PRODUCT_MODES[2]
    key = "np_wb" if revised else "np_wb2"
    pick = state.get(key)
    empty = {"ok": False, "available": False, "binding": "", "selected": [], "reason": ""}
    if not pick or pick == "(none)":
        return empty
    try:
        allow_macro_container = False
        if pick == "(upload a workbook)":
            upload = state.get(key + "_upload")
            if upload is None:
                return empty
            raw = upload.getvalue()
            source = upload.name
        else:
            chosen = state.get(key + "_path", "").strip() if pick == "(another file: type its path)" else pick
            if not chosen:
                return empty
            if allowed_packs is not None:
                import portal_runtime
                if not portal_runtime.within_packs(chosen, root, allowed_packs):
                    raise ValueError("Choose a workbook within an assigned product.")
            path = Path(chosen)
            if not path.is_absolute():
                path = Path(root) / path
            source = str(path.resolve())
            # Existing local registration accepts XLSM paths. Inspect their bounded
            # metadata without keeping or executing VBA; uploads remain plain XLSX.
            allow_macro_container = path.suffix.lower() == ".xlsm"
            raw = attachment._bytes(path)
        digest = hashlib.sha256(raw).hexdigest()
        cache = state.get("np_wb_scope_cache") or {}
        if cache.get("sha256") == digest and cache.get("allow_macro_container") == allow_macro_container:
            metadata = cache["metadata"]
        else:
            metadata = attachment.validate_workbook(raw, allow_macro_container=allow_macro_container)
            state["np_wb_scope_cache"] = {"sha256": digest, "metadata": metadata,
                "allow_macro_container": allow_macro_container}
        previous = state.get("np_old") if revised else None
        if previous and allowed_packs is not None and previous not in allowed_packs:
            raise ValueError("Choose an assigned previous product before selecting its revised sheets.")
        try:
            scope = new_product.sheet_scope_options(metadata["sheets"], root, previous_pack=previous)
        except OSError as error:
            previous_conf = Path(root) / str(previous or "") / "spec_pipeline/pipeline.conf"
            if not previous or not error.filename or Path(error.filename).resolve() != previous_conf.resolve():
                raise
            return {**empty, "available": True,
                    "error": "The selected previous cut's extraction configuration could not be read. "
                             "Choose another available previous cut or restore its extraction configuration before previewing.",
                    "missing_entry": "a previous cut with a readable extraction configuration"}
        registry_digest = hashlib.sha256((Path(root) / "governance/tumour_registry.yaml").read_bytes()).hexdigest()
        population_key = [digest, registry_digest, scope["sheets"]]
        population_cache = state.get("np_wb_population_cache") or {}
        if population_cache.get("key") == population_key:
            population = population_cache["value"]
        else:
            import spec_extract
            domains = {spec_extract.sheet_key(row["name"]): row["domain"] for row in scope["sheets"] if row["domain"]}
            population = new_product.workbook_population(io.BytesIO(raw), root, domains=domains)
            state["np_wb_population_cache"] = {"key": population_key, "value": population}
        binding = hashlib.sha256(json.dumps([str(Path(root).resolve()), source, digest, mode, previous, scope, registry_digest],
            sort_keys=True, ensure_ascii=False).encode()).hexdigest()
        return {**scope, "ok": True, "available": True, "sha256": digest, "binding": binding, "population": population,
                "previous_pack": previous,
                "selected": list(state.get(SELECTION) or []), "reason": str(state.get(REASON) or "")}
    except OSError:
        return {**empty, "available": True, "error": "The selected workbook or its required metadata could not be read. "
                "Check that the files are available and accessible, then try again."}
    except (ValueError, TypeError, KeyError, SystemExit) as error:
        return {**empty, "available": True, "error": str(error)}


def reconcile(state, scope):
    """Discard selections and preview authorization when their source changes."""
    binding = scope.get("binding", "")
    changed = state.get(BINDING, "") != binding
    if changed:
        had_choices = bool(state.get(SELECTION) or state.get(MAPPINGS))
        state[SELECTION] = []
        state[REASON] = ""
        state[MAPPINGS] = {}
        state[MAPPING_REASON] = ""
        for key in list(state):
            if str(key).startswith("np_sheet_domain_choice_"):
                state.pop(key, None)
        state[BINDING] = binding
        state.pop("np_previewed", None)
        if had_choices:
            state["np_sheet_scope_notice"] = "The workbook or its sheet mapping changed. Review sheet sections and exclusions again for this specification."
    options = {sheet["name"] for sheet in scope.get("sheets", []) if sheet.get("selectable")}
    # A restored draft or a stale external widget state cannot name missing sheets.
    selected = state.get(SELECTION) or []
    if not isinstance(selected, list) or any(name not in options for name in selected):
        state[SELECTION] = []
        state.pop("np_previewed", None)
    scope["selected"] = list(state.get(SELECTION) or [])
    scope["reason"] = str(state.get(REASON) or "")
    return scope


def render(scope):
    """Return canonical CLI arguments and missing entries from the shared form."""
    import streamlit as st
    import form_assistance as forms
    notice = st.session_state.pop("np_sheet_scope_notice", None)
    if notice:
        st.info(notice)
    if not scope.get("available"):
        return [], []
    if not scope.get("ok"):
        st.warning(scope.get("error", "Choose a readable workbook to review its sheets."))
        return [], [scope.get("missing_entry", "a readable specification workbook")]
    options = [sheet["name"] for sheet in scope["sheets"] if sheet.get("selectable")]
    if not options:
        st.caption("The workbook has no additional sheets needing a scope choice. Its mapped specification sections remain included.")
        return [], []
    with st.expander("Choose which sheets belong in this product", expanded=True):
        st.caption("Assign unclassified sheets to their specification sections; several sheets can share one section. Leave out additional sheets whose variables this product does not need. The original workbook and source trace are kept. For an exclusion needed by only one study, use Studies after creating the product.")
        saved = hint_status(scope, st.session_state)
        if saved.get("eligible"):
            st.info("Saved choices for this same workbook are ready for review. They have not been applied.")
            if saved["hint"]["sheets"]:
                st.write("Saved sheet exclusions: " + ", ".join(saved["hint"]["sheets"]))
            st.caption("Saved reason: " + (saved["hint"]["reason"] or "No reason entered yet."))
            if saved["hint"].get("sheet_mappings"):
                st.write("Saved sheet sections: " + "; ".join(f"{name}: {domain}" for name, domain in saved["hint"]["sheet_mappings"].items()))
                st.caption("Saved mapping reason: " + (saved["hint"].get("mapping_reason") or "No reason entered yet."))
            if st.session_state.get(SELECTION):
                st.caption("Restoring replaces your current selection: " + ", ".join(st.session_state[SELECTION]))
            if st.button("Restore these sheet choices for review", key="np_sheet_scope_restore_hint"):
                restore_hint(scope, st.session_state, confirmed=True)
        elif saved.get("available"):
            st.caption(saved.get("reason", "Review the current workbook before restoring saved sheet choices."))
        mappings = {}
        for sheet in scope["sheets"]:
            if not sheet.get("mapping_selectable"):
                continue
            name = sheet["name"]
            domain = forms.field(st.selectbox, f"Specification section for {name}",
                ["", *scope["mapping_domains"]], key=mapping_key(name), binding=scope["binding"],
                format_func=lambda value: value or "Choose a section if this sheet contains requirements",
                help="Choose the section described by this sheet. Several sheets may belong to the same section. The choice applies to this product specification; no mapping is inferred from variable names.")
            if domain:
                mappings[name] = domain
        st.session_state[MAPPINGS] = mappings
        mapping_reason = ""
        if mappings:
            mapping_reason = forms.field(st.text_input, "Why do these sheets belong to these sections?",
                key=MAPPING_REASON, binding=scope["binding"], max_chars=1000,
                help="Explain the specification's sheet layout. Preview shows these exact mappings before the product is created.").strip()
            st.info("Workbook sheet sections: " + "; ".join(f"{name}: {domain}" for name, domain in mappings.items()))
        options = [name for name in options if name not in mappings]
        if any(name not in options for name in st.session_state.get(SELECTION, [])):
            st.session_state[SELECTION] = [name for name in st.session_state.get(SELECTION, []) if name in options]
        if scope.get("inherited"):
            st.info("Previously left out: " + ", ".join(scope["inherited"]) + ". Select them again only if they are also out of scope for this revised specification.")
        if scope.get("missing_inherited"):
            st.caption("Previously excluded sheets absent from this workbook: " + ", ".join(scope["missing_inherited"]))
        selected = forms.field(st.multiselect, "Sheets to leave out of this product", options,
            key=SELECTION, binding=scope["binding"],
            help="Select the exact sheet name, for example 9.PROC PSOC Strategy. This is a draft product-scope decision; it does not require an approval record. Mapped requirement sections stay in the extraction and can be reviewed through Plan changes after creation.")
        reason = forms.field(st.text_input, "Why are these sheets out of scope?", key=REASON,
            binding=scope["binding"], max_chars=1000,
            placeholder="For example: These strategy variables are not needed for this product.",
            help="Use your own reason. This is required only when leaving out a sheet and appears in the product's preview and extraction configuration.").strip()
        if selected:
            st.info("Will leave out of this product: " + ", ".join(selected) + ". Review this scope in Preview before creating the product.")
        st.caption("Mapped specification sections remain included. Leaving out a sheet does not approve scientific definitions or change the workbook's AI access classification.")
    args = [value for name in selected for value in ("--exclude-sheet", name)]
    if selected and reason:
        args.extend(["--exclude-sheet-reason", reason])
    args += [value for name, domain in mappings.items() for value in ("--sheet-domain", f"{name}={domain}")]
    if mappings and mapping_reason:
        args.extend(["--sheet-domain-reason", mapping_reason])
    missing = (["why the selected sheets are out of scope"] if selected and not reason else [])
    if mappings and not mapping_reason:
        missing.append("why the mapped sheets belong to the selected specification sections")
    return args, missing
