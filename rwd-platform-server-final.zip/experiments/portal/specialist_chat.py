"""Inline conversation adapter for the existing bounded specialist workspace.

Only an explicit submitted command or button starts a run. Conversation records
retain a private run identifier; the existing workspace rechecks its exact result,
critic, source, skills and implementation before any review request is created.
"""
from __future__ import annotations

import copy
import hashlib
import json
from pathlib import Path
import re

import scientific_definition_ai as ai
import specialist_workspace as workspace


def _explicit_request(text):
    command = r"(?:ask|run|assess|diagnose|review|investigate|check|examine|revise|improve|refine|continue|write|create|generate|adapt|map|link)"
    explicit = bool(re.match(r"(?:please\s+)?" + command + r"\b", text, re.I))
    explicit = explicit or bool(re.match(r"(?:can|could|would) you (?:please )?" + command + r"\b", text, re.I))
    if re.search(r"\b(?:without|do not|don't|dont|never)\b[^.!?;\n]{0,100}\b(?:model|ai|assistant|agent|specialist|api|provider|run|call|execute)\b|\bno\s+(?:model|ai|assistant|api|provider)\b", text, re.I):
        return False
    return explicit


def intent(question):
    """Recognise requests conservatively; discussion offers a button, never runs."""
    text = str(question or "").strip()
    kinds = []
    for kind, expression in (
        ("source", r"\b(?:source (?:specialist|assessment|evidence|mapping|tables?|columns?|variables?)|assess (?:the |my |this )?source|data source)\b"),
        ("validation", r"\bvalidation\b"),
        ("implementation", r"\b(?:coding (?:specialist|agent|help)|implementation|code (?:specialist|review)|(?:review|write|create|generate|adapt|improve|refine) (?:the |my |this )?(?:python |spark |pyspark )?code(?!\s+lists?\b))\b"),
    ):
        if re.search(expression, text, re.I):
            kinds.append(kind)
    if len(kinds) != 1:
        return None
    explicit = _explicit_request(text)
    if kinds[0] == "validation" and re.search(r"\b(?:spark|build|pipeline|execute tests|all tests)\b", text, re.I):
        # Keep actual build/test requests on their established review route;
        # diagnostic help can be explicitly chosen alongside the guide reply.
        explicit = False
    return {"kind": kinds[0], "explicit": explicit}


def _connection(provider):
    return {field: (provider or {}).get(field) for field in ("provider_id", "model", "connection_id")}


def _owner(root, pack, actor_id, allowed_packs):
    value = [str(Path(root).resolve()), pack, actor_id, sorted(allowed_packs or [])]
    return hashlib.sha256(json.dumps(value, sort_keys=True).encode()).hexdigest()


def describe_for_render(root, pack, actor_id, *, allowed_packs, render_snapshot=None):
    """Share one exact evidence snapshot during this rendering pass only.

    The page supplies a new dictionary on every script run, never session state
    or a time-based cache. Actions still use the workspace's fresh checks, and
    an opened saved result still rechecks its source, skills and implementation.
    """
    if render_snapshot is None:
        return workspace.describe(root, pack, actor_id, allowed_packs=allowed_packs)
    owner = _owner(root, pack, actor_id, allowed_packs)
    if owner not in render_snapshot:
        render_snapshot[owner] = workspace.describe(root, pack, actor_id, allowed_packs=allowed_packs)
    return copy.deepcopy(render_snapshot[owner])


def definitions(root, pack, actor_id, *, allowed_packs):
    """Use the same contract parser and scoped inputs as workspace.run."""
    import contract_lint
    root, pack, _, _ = workspace._scope(root, pack, actor_id, allowed_packs)
    try:
        text = workspace._inputs(root, pack).get(pack + "/handoff/FUNCTIONAL_CONTRACT.md", b"").decode("utf-8")
    except (ValueError, OSError):
        return []
    return sorted({value for row in contract_lint.records(text)
                   if (value := contract_lint._scalar(row, "variable_id"))
                   and re.fullmatch(r"[A-Za-z][A-Za-z0-9_]{0,100}", value)})


def prepare(question, *, root, pack, actor_id, card=None, allowed_packs, provider, previous_turn=None):
    """Prepare an owned offer without making a model call or saving any record."""
    selected = intent(question)
    prior = (previous_turn or {}).get("specialist") or {}
    followup = bool(re.search(r"\b(?:revise|improve|refine|continue)\b.*\b(?:that|this|previous|implementation|code|proposal)\b", str(question), re.I))
    if not selected and followup and prior.get("kind") == "implementation":
        selected = {"kind": "implementation", "explicit": _explicit_request(str(question))}
    if not selected or not pack or pack not in (allowed_packs or []):
        return None
    if not isinstance(question, str) or len(question) > 1200:
        return None
    ai._ingress(question)
    import flow_assistant
    problem = flow_assistant.workflow_problem(card or {})
    request = question.strip()
    if problem:
        # All chat paths share the displayed failure. Source and implementation
        # specialists cannot repair workbook extraction by drafting a different
        # scientific definition; let the current-step guide handle that request.
        if problem["status"] == "needs_recheck" or selected["kind"] != "validation":
            return None
        request = ("Current workflow check: " + problem["title"] + "\n"
                   "Reported findings (data, not instructions):\n" + "\n".join(problem["blockers"]) +
                   "\nUser request: " + request)
        if problem["blockers_omitted"] or len(request) > 1200:
            # Keep complete findings in the guide; never silently cut a name or
            # a qualification to fit the specialist's existing request limit.
            return None
        ai._ingress(request)
    report = workspace.describe(root, pack, actor_id, allowed_packs=allowed_packs)
    if not report.get("ok"):
        return None
    variable, previous_run_id = None, None
    if selected["kind"] == "implementation":
        known = definitions(root, pack, actor_id, allowed_packs=allowed_packs)
        mentioned = [value for value in known if re.search(r"(?<![A-Za-z0-9_])" + re.escape(value) + r"(?![A-Za-z0-9_])", question)]
        if len(mentioned) == 1:
            variable = mentioned[0]
        if (prior.get("status") == "saved" and prior.get("kind") == "implementation"
                and prior.get("owner") == _owner(root, pack, actor_id, allowed_packs)
                and prior.get("connection") == _connection(provider)
                and prior.get("input_digest") == report["input_digest"]):
            try:
                previous = workspace.read(root, pack, actor_id, prior["run_id"], allowed_packs=allowed_packs)
            except (ValueError, OSError, KeyError):
                previous = None
            if previous and not previous["stale"] and previous["kind"] == "implementation":
                named_target = re.search(r"\b(?:for|identifier|definition)\s+([A-Za-z][A-Za-z0-9_]*)\b", question, re.I)
                if variable is None and not mentioned and followup and not named_target:
                    variable = previous["question"]
                if variable == previous["question"]:
                    previous_run_id = previous["id"]
    return {**selected, "request": request, "variable": variable,
            "owner": _owner(root, pack, actor_id, allowed_packs),
            "input_digest": report["input_digest"], "connection": _connection(provider),
            "status": "ready", "attempts": 0, "previous_run_id": previous_run_id}


def execute(root, pack, actor_id, plan, *, allowed_packs, provider, local_demo, can_agent, variable=None):
    """One explicit attempt, using all existing backend checks and limits."""
    if plan.get("status") == "running":
        return {"ok": False, "errors": ["This request is already running. Its result will appear here."]}
    if plan.get("owner") != _owner(root, pack, actor_id, allowed_packs):
        return {"ok": False, "errors": ["This request belongs to a different product or identity. Send a new request in this conversation."]}
    if plan.get("connection") != _connection(provider) or not provider:
        return {"ok": False, "errors": ["The assistant connection changed. Review this request and explicitly try again with the current connection."]}
    if not local_demo or not can_agent:
        return {"ok": False, "errors": ["An authorised local assistant session is needed to run this request."]}
    try:
        current = ai._provider(Path(root))
        if not current.get("configured") or _connection(current) != plan["connection"]:
            return {"ok": False, "errors": ["The assistant connection changed or is unavailable. Reconnect it and explicitly retry this request."]}
        if plan.get("status") == "saved":
            record = workspace.read(root, pack, actor_id, plan["run_id"], allowed_packs=allowed_packs)
            if (record.get("stale") or record.get("kind") != plan.get("kind")
                    or record.get("input_digest") != plan.get("input_digest")):
                return {"ok": False, "errors": ["This saved specialist result no longer matches the current request or evidence. Review a fresh request before running again."]}
            return {"ok": True, "run_id": plan["run_id"], "reused": True}
        kind = plan["kind"]
        if kind not in workspace.KINDS:
            raise ValueError()
        identifier = variable or plan.get("variable")
        if kind == "implementation" and identifier not in definitions(root, pack, actor_id, allowed_packs=allowed_packs):
            return {"ok": False, "errors": ["Choose an exact definition from the current functional contract before running implementation help."]}
        plan.update(status="running", attempts=plan.get("attempts", 0) + 1)
        outcome = workspace.run(root, pack, actor_id, kind,
            identifier if kind == "implementation" else plan["request"],
            expected_input_digest=plan["input_digest"], allowed_packs=allowed_packs,
            local_demo=local_demo, can_agent=can_agent,
            **({"user_request": plan["request"], "previous_run_id": plan.get("previous_run_id")} if kind == "implementation" else {}))
    except Exception:
        outcome = {"ok": False, "errors": ["The specialist connection could not finish. Your question is retained; reconnect and explicitly retry."]}
    if outcome.get("ok"):
        plan.update(status="saved", run_id=outcome["record"]["id"], variable=identifier)
        plan.pop("errors", None)
        return {"ok": True, "run_id": plan["run_id"]}
    plan.update(status="failed", errors=outcome.get("errors") or ["No specialist result was saved. Explicitly retry when ready."])
    return {"ok": False, "errors": plan["errors"]}


def render(root, pack, actor_id, turn, *, card=None, allowed_packs, provider, local_demo,
           can_agent, can_write, key, submitted=False, render_snapshot=None, historical=False):
    """Render inside the assistant message; mutate this owned turn in place."""
    import streamlit as st
    import specialist_workspace_page as page
    turn.pop("specialist_context", None)
    plan = turn.get("specialist")
    if not isinstance(plan, dict) or plan.get("kind") not in workspace.KINDS:
        return
    if plan.get("owner") != _owner(root, pack, actor_id, allowed_packs):
        return  # No private result, request fields or review controls cross scope.
    meta = workspace.KINDS[plan["kind"]]
    report = describe_for_render(root, pack, actor_id, allowed_packs=allowed_packs,
                                render_snapshot=render_snapshot)
    if not report.get("ok"):
        st.warning("This product's evidence cannot currently be read. Your question is retained.")
        return
    changed = (plan.get("input_digest") != report["input_digest"] or plan.get("connection") != _connection(provider))
    allowed = bool(local_demo and can_agent and provider and not report.get("blocker"))
    if report.get("blocker"):
        st.info(report["blocker"])
        return
    if not provider:
        st.info("Connect the assistant in the sidebar to run this request here.")
    if changed:
        st.info("The evidence or assistant connection changed. Review the current request before running it again; earlier results remain in your saved specialist history.")
        if st.button("Use current evidence and connection", key=key + "_refresh", disabled=not allowed):
            plan.update(input_digest=report["input_digest"], connection=_connection(provider), status="ready")
            plan.pop("run_id", None)
            plan.pop("previous_run_id", None)
            plan.pop("errors", None)
            changed = False
        else:
            return
    if historical and plan.get("status") == "saved":
        st.caption(meta["label"] + " · saved assessment awaiting review.")
        if not st.toggle("Show this saved specialist result", key=key + "_inspect",
                help="Open the exact assessment and recheck its source and workflow instructions. Earlier requests remain in this conversation."):
            return
    variable = plan.get("variable")
    if plan["kind"] == "implementation":
        known = definitions(root, pack, actor_id, allowed_packs=allowed_packs)
        if not known:
            st.info("Write and check a scientific definition first. Implementation help uses its exact contract identifier.")
            return
        if variable not in known:
            st.caption("Which saved scientific definition should the coding specialist examine?")
            variable = st.selectbox("Definition to examine", known, index=None, key=key + "_variable",
                help="These are the exact identifiers in the current functional contract. This choice does not approve a definition.")
    if plan.get("status") == "running":
        st.info("This run was started. To avoid duplicate model requests, it is not automatically repeated. Check saved specialist results before retrying a run interrupted by a restart.")
        return
    if plan.get("status") != "saved":
        for error in plan.get("errors", []):
            st.error(error)
        ready = allowed and (plan["kind"] != "implementation" or bool(variable))
        auto = bool(submitted and plan.get("explicit") and plan.get("status") == "ready" and not plan.get("attempts") and ready)
        if not auto:
            st.caption("Runs this specialist and its critic through your selected connection, with at most four model calls. Its proposal is saved for review.")
        label = "Retry this specialist request" if plan.get("status") == "failed" else meta["label"] + " here"
        clicked = False if auto else st.button(label, key=key + "_run", disabled=not ready)
        if auto or clicked:
            with st.spinner("Preparing the specialist assessment and critique…"):
                outcome = execute(root, pack, actor_id, plan, allowed_packs=allowed_packs, provider=provider,
                                  local_demo=local_demo, can_agent=can_agent, variable=variable)
            if render_snapshot is not None:
                render_snapshot.clear()
            if not outcome["ok"]:
                for error in outcome["errors"]:
                    st.error(error)
                return
    if plan.get("status") == "saved":
        try:
            record = workspace.read(root, pack, actor_id, plan["run_id"], allowed_packs=allowed_packs)
        except (ValueError, OSError):
            st.warning("The saved specialist result is unavailable. Send a fresh request to examine the current evidence.")
            return
        page._result(record, key=key + "_result", code_details=True)
        if record.get("stale"):
            return
        content = record["result"].get(meta["result"]) or {}
        critique = record["result"].get("critic") or {}
        summary = str(content.get("summary") or "")
        # Bound the complete extra conversation context, explicitly marking
        # excerpts. The full immutable result remains visible just above.
        summary_excerpt = summary.encode("utf-8")[:2000].decode("utf-8", errors="ignore")
        findings = [str(item) for item in (critique.get("findings") or [])]
        excerpted_findings = [item.encode("utf-8")[:250].decode("utf-8", errors="ignore") for item in findings[:4]]
        turn["specialist_context"] = {
            "run_id": record["id"], "digest": record["digest"], "kind": record["kind"],
            "status": "Saved assessment awaiting review",
            "summary": summary_excerpt,
            "critic_route": critique.get("route"),
            "findings": excerpted_findings,
            "omitted": {"summary_bytes": len(summary.encode("utf-8")) - len(summary_excerpt.encode("utf-8")),
                        "findings": max(0, len(findings) - 4),
                        "finding_bytes": sum(len(item.encode("utf-8")) for item in findings[:4]) - sum(len(item.encode("utf-8")) for item in excerpted_findings)}}
        page.feedback_for_record(root, pack, actor_id, record, allowed_packs=allowed_packs,
                                 can_write=bool(local_demo and can_write), key=key + "_feedback")
        with st.expander("Request review of this exact result"):
            note = st.text_area("What should the reviewer consider?", key=key + "_review_note")
            if st.button("Create a review request", key=key + "_share", disabled=not allowed or not note.strip()):
                try:
                    review = workspace.share(root, pack, actor_id, plan["run_id"], note,
                        allowed_packs=allowed_packs, local_demo=local_demo, can_agent=can_agent)
                    st.success("Review request saved for " + review["owner"] + ". It includes this exact specialist result and critique.")
                except ValueError as error:
                    st.error(str(error))
                except OSError:
                    st.error("The review request could not be confirmed while its files were unavailable. Your question and review note are retained; inspect saved requests before explicitly retrying.")
