"""Owned handoffs: a piece of work the portal cannot do for the person becomes a request with an
owner, a status and a return path, instead of a line that says "give this to your data expert".

A handoff lives at <product>/.portal-drafts/handoffs/<id>.json (the drafts folder is ignored by git;
the request is shared by everyone using this checkout). It carries the product, the step it came
from, who asked and when, the owner role that must act, the status, and the owner's response.
Statuses: open, in progress, done, declined, withdrawn. Every transition names the person who made
it and the date the store recorded it; the requester withdraws, the owner role (or an administrator)
answers. Nothing here changes a product file, an approval or a gate; when the owner reports "done",
the product's own checks decide whether the step is met (2026-09-07).
"""
from __future__ import annotations

import json
import os
import re
import tempfile
import uuid
from datetime import datetime, timezone
from pathlib import Path

OWNERS = ("Data expert", "Science", "Engineering", "Reviewer", "Administrator")
STATUSES = ("open", "in progress", "done", "declined", "withdrawn")
OPEN = ("open", "in progress")
MAX_TEXT = 4000
_ID = re.compile(r"[0-9a-f]{32}")


class Refused(Exception):
    """Nothing was written; the message says why in the person's words."""


def _now():
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat().replace("+00:00", "Z")


def _pack_dir(root, pack, allowed_packs):
    text = str(pack or "").replace("\\", "/").strip("/")
    if not text or ".." in text.split("/"):
        raise Refused("Choose a product first.")
    if allowed_packs is not None and text not in {str(p).replace("\\", "/").strip("/") for p in allowed_packs}:
        raise Refused("This product is outside your access.")
    base = Path(root).resolve()
    product = (base / text)
    if product.resolve() != product or not product.is_dir():
        raise Refused("The product location is unavailable.")
    return product, text


def _store(root, pack, allowed_packs):
    product, text = _pack_dir(root, pack, allowed_packs)
    directory = product / ".portal-drafts" / "handoffs"
    if directory.exists() and directory.resolve() != directory:
        raise Refused("The handoff folder redirects to another location. Ask your data expert to repair it.")
    return directory, text


def _text(value, what, *, required=True):
    value = " ".join(str(value or "").split())
    if required and not value:
        raise Refused(f"Enter {what}.")
    if len(value) > MAX_TEXT:
        raise Refused(f"Keep {what} under {MAX_TEXT} characters.")
    return value


def _write(file, doc):
    file.parent.mkdir(parents=True, exist_ok=True)
    handle, temp = tempfile.mkstemp(prefix=".handoff-", suffix=".tmp", dir=str(file.parent))
    try:
        with os.fdopen(handle, "w", encoding="utf-8", newline="\n") as out:
            json.dump(doc, out, indent=1, sort_keys=True)
            out.write("\n")
        os.replace(temp, file)
    finally:
        try:
            os.unlink(temp)
        except OSError:
            pass


def _read(file):
    try:
        doc = json.loads(file.read_text(encoding="utf-8"))
    except (OSError, ValueError) as error:
        raise Refused(f"Handoff {file.stem[:8]} could not be read. Ask your data expert to repair or remove it.") from error
    if not isinstance(doc, dict) or not _ID.fullmatch(str(doc.get("id", ""))) or doc.get("status") not in STATUSES:
        raise Refused(f"Handoff {file.stem[:8]} is not a handoff record. Ask your data expert to repair or remove it.")
    return doc


def create(root, pack, *, title, owner, note, requested_by, action_id="", allowed_packs=None, local_demo=True, can_view=True):
    """One new open handoff. Refuses before writing; the id is minted here, never typed."""
    if not local_demo:
        raise Refused("Handoffs are recorded on the person's own checkout in this version.")
    if not can_view:
        raise Refused("This product is outside your access.")
    if owner not in OWNERS:
        raise Refused("Choose who owns this: " + ", ".join(OWNERS) + ".")
    directory, text = _store(root, pack, allowed_packs)
    title = _text(title, "what is being asked for")
    note = _text(note, "the details the owner needs")     # the owner reads the requester's own words (walk NEW-3)
    if action_id:
        # one open request per step (walk NEW-2): a second click adds nothing and the person is told
        for existing in listing(root, pack, allowed_packs=allowed_packs, include_closed=False):
            if existing.get("action_id") == action_id and existing.get("status") in OPEN:
                raise Refused(f"This step is already handed to {existing['owner']} by {existing['requested_by']} "
                              f"on {str(existing.get('requested_at', ''))[:10]} ({existing['status']}). Wait for the answer, or withdraw that request first.")
    doc = {
        "id": uuid.uuid4().hex, "pack": text, "title": title,
        "note": note, "owner": owner,
        "action_id": _text(action_id, "the step", required=False), "status": "open",
        "requested_by": _text(requested_by, "your name"), "requested_at": _now(),
        "history": [{"status": "open", "by": _text(requested_by, "your name"), "at": _now(), "note": ""}],
        "response": "",
    }
    _write(directory / (doc["id"] + ".json"), doc)
    return doc


def load(root, pack, handoff_id, *, allowed_packs=None):
    if not _ID.fullmatch(str(handoff_id or "")):
        raise Refused("That handoff does not exist.")
    directory, _text_ = _store(root, pack, allowed_packs)
    file = directory / (handoff_id + ".json")
    if not file.is_file():
        raise Refused("That handoff does not exist.")
    return _read(file)


def listing(root, pack, *, allowed_packs=None, include_closed=True):
    """Every handoff of the product, newest first; an unreadable file is reported as a row, not hidden."""
    directory, _text_ = _store(root, pack, allowed_packs)
    rows = []
    if not directory.is_dir():
        return rows
    for file in sorted(directory.glob("*.json")):
        try:
            doc = _read(file)
        except Refused as error:
            rows.append({"id": file.stem[:32], "status": "unreadable", "title": str(error), "owner": "", "requested_by": "",
                         "requested_at": "", "note": "", "response": "", "history": [], "pack": "", "action_id": ""})
            continue
        if include_closed or doc["status"] in OPEN:
            rows.append(doc)
    rows.sort(key=lambda r: str(r.get("requested_at", "")), reverse=True)
    return rows


def transition(root, pack, handoff_id, *, status, by, note="", allowed_packs=None, local_demo=True, is_owner=False, is_requester=False):
    """The owner (or an administrator) moves it forward or declines; the requester withdraws."""
    if not local_demo:
        raise Refused("Handoffs are recorded on the person's own checkout in this version.")
    if status not in STATUSES or status == "open":
        raise Refused("Choose what happened: in progress, done, declined or withdrawn.")
    doc = load(root, pack, handoff_id, allowed_packs=allowed_packs)
    if doc["status"] not in OPEN:
        raise Refused(f"This handoff is already {doc['status']} (by {doc['history'][-1]['by']} on {doc['history'][-1]['at'][:10]}). Nothing changed.")
    who = _text(by, "your name")
    if status == "withdrawn":
        if not is_requester:
            raise Refused("Only the person who asked can withdraw a handoff.")
    elif not is_owner:
        raise Refused(f"Only the {doc['owner']} role (or an administrator) records progress on this handoff.")
    note = _text(note, "a note", required=False)
    if status in ("done", "declined") and not note:
        raise Refused("Say what was done, or why not, in a sentence; the requester reads it.")
    doc["status"] = status
    doc["history"].append({"status": status, "by": who, "at": _now(), "note": note})
    if status in ("done", "declined"):
        doc["response"] = note
    directory, _text_ = _store(root, pack, allowed_packs)
    _write(directory / (doc["id"] + ".json"), doc)
    return doc


def open_count(root, pack, *, allowed_packs=None):
    try:
        return sum(1 for r in listing(root, pack, allowed_packs=allowed_packs, include_closed=False) if r["status"] in OPEN)
    except Refused:
        return 0


def recent(root, pack, actor_id, *, allowed_packs):
    """Rows for the Home saved-work list: every open handoff of the product, resumable on its page."""
    rows = []
    try:
        docs = listing(root, pack, allowed_packs=allowed_packs, include_closed=False)
    except Refused:
        return rows
    for doc in docs:
        rows.append({"route": "handoffs", "id": doc["id"], "title": f"Handoff to {doc['owner']}: {doc['title']}",
                     "state": doc["status"], "updated_at": doc["history"][-1]["at"] if doc.get("history") else doc.get("requested_at", ""),
                     "summary": f"Asked by {doc['requested_by']} on {str(doc.get('requested_at', ''))[:10]}.",
                     "params": {"handoff_id": doc["id"]}})
    return rows
