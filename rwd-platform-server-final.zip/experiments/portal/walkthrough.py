"""The walkthrough as a page: workbook → stand-up → extraction and scaffolds → executable configuration
→ validation → synthetic build → gate verdicts, each step's state read from the pack's files.

A person could stand a product up in the portal, then found no way to see the gates, validate the
configuration or build, and was sent to a terminal for each (2026-09-05: "I cannot run it end to end
on the Streamlit app"). This module computes what each step's files say; the page offers the bounded
act for the next step — the same commands CI and the demo run, as subprocesses with a timeout — and
never an approval, an answer or a promotion, which stay a person's acts at a keyboard. PURE: no
Streamlit here, so the states are testable on a directory.
"""
from __future__ import annotations

import hashlib
import json
import os
import re
import sys
from pathlib import Path

import yaml

_TOOLS = str(Path(__file__).resolve().parents[2] / "platform" / "tools")
if _TOOLS not in sys.path:
    sys.path.insert(0, _TOOLS)
import source_manifest as sm  # noqa: E402
from person_rules import unstated  # noqa: E402
from engine.strict_yaml import strict_load  # noqa: E402

DEMO_PACK = "sandbox/demo_walkthrough/bladder/202609"
DEMO_WORKBOOK = "sandbox/demo_walkthrough/bladder_202609_program_spec.xlsx"
DONE, TODO, BLOCKED, RUN, UNAVAILABLE = "done", "todo", "blocked", "run", "unavailable"


def _sha(path: str) -> str:
    digest = hashlib.sha256()
    with open(path, "rb") as fh:
        for chunk in iter(lambda: fh.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _pack_path(root, pack):
    base = Path(root).resolve()
    if Path(str(pack)).is_absolute():
        raise ValueError("The selected pack must be repository-relative.")
    expected = base / str(pack)
    product = expected.resolve()
    product.relative_to(base)
    if product == base or product != expected.absolute():
        raise ValueError("The selected pack location is invalid or redirects elsewhere.")
    return base, product


def _pack_file(product, relative):
    expected = product / relative
    path = expected.resolve()
    path.relative_to(product)
    if path != expected.absolute():
        raise ValueError("A product file redirects to another location.")
    return path


def _error(identifier, title, detail):
    return {"id": identifier, "title": title, "state": BLOCKED, "detail": detail, "action": None}


def _json(path):
    with path.open("rb") as handle:
        raw = handle.read(16 * 1024 * 1024 + 1)
    if len(raw) > 16 * 1024 * 1024:
        raise ValueError("Artifact too large for a walkthrough check")
    return json.loads(raw)


def _source_registration(product):
    path = _pack_file(product, "source_refs.yaml")
    with path.open("rb") as handle:
        raw = handle.read(4 * 1024 * 1024 + 1)
    if len(raw) > 4 * 1024 * 1024 or any(isinstance(token, (yaml.AliasToken, yaml.AnchorToken)) for token in yaml.scan(raw)):
        raise ValueError("Source registration needs a bounded, explicit mapping")
    return sm.load(str(path))


def workbook(root: str, pack: str) -> dict:
    """Only the authoritative registered file supplies this step's identity and digest."""
    title = "The specification workbook"
    try:
        base, product = _pack_path(root, pack)
        register = _pack_file(product, "source_refs.yaml")
        if not register.is_file():
            return {"id": "workbook", "title": title, "state": TODO,
                    "detail": "No source registration yet. Start a product draft, then attach its specification when supplied.", "action": "new_product"}
        doc = _source_registration(product)
        materials = doc.get("source_materials") if isinstance(doc, dict) else None
        if not isinstance(materials, list) or any(not isinstance(m, dict) for m in materials):
            raise ValueError("Source material list")
        ids = [m.get("material_id") for m in materials]
        if any(not isinstance(mid, str) or unstated(mid) for mid in ids) or len(set(ids)) != len(ids):
            raise ValueError("Source identifiers")
        specs = [m for m in materials if m.get("material_type") == sm.PROGRAM_SPEC]
        if len(specs) != 1:
            return _error("workbook", title, "The source register must identify exactly one authoritative program specification. Ask your data expert to repair it.")
        material = specs[0]
        if sm.field_unstated(material, "path_or_link"):
            return {"id": "workbook", "title": title, "state": TODO,
                    "detail": "The specification is still pending. Attach the supplied workbook and register its path in Progress and next step; the product draft can already exist.", "action": None}
        target = material.get("path_or_link")
        if not isinstance(target, str):
            raise ValueError("Source location")
        if target.lower().startswith(sm.REMOTE_PREFIXES):
            return _error("workbook", title, "The specification is registered as a link. Its local bytes have not been checked; ask your data expert to attach and register the same document.")
        path = Path(sm.material_file(str(product), target, str(base))).resolve()
        path.relative_to(base)
        if not path.is_file():
            return _error("workbook", title, "The registered specification file is unavailable. Attach the correct file or repair its registered path in Progress and next step.")
        if path.suffix.lower() not in {".xlsx", ".xlsm"}:
            return _error("workbook", title, "The registered specification is not a supported Excel workbook. Ask your data expert to check the selected document.")
        digest, registered = _sha(path), material.get("sha256")
        if not isinstance(registered, str) or not re.fullmatch(r"[0-9a-f]{64}", registered):
            return _error("workbook", title, "The registered workbook is present but its checksum is missing or invalid. Record its exact bytes in Progress and next step; scientific review remains separate.")
        same = digest == registered
        return {"id": "workbook", "title": title, "state": DONE if same else BLOCKED,
                "detail": (f"{path.relative_to(base).as_posix()} — sha256 {digest[:12]}… "
                           + ("matches the registered digest. This confirms the file identity, not scientific approval." if same else
                              "does NOT match the registered digest. Review the changed document before updating its record.")), "action": None}
    except (OSError, ValueError, TypeError, yaml.YAMLError, sm.Unreadable, RecursionError):
        return _error("workbook", title, "The registered specification cannot be read safely. Ask your data expert to check the source record and its repository location.")


def stand_up(root: str, pack: str) -> dict:
    try:
        _base, product = _pack_path(root, pack)
        have = [f for f in ("source_refs.yaml", "config/data_product.yaml", "variables/outcomes.yaml")
                if _pack_file(product, f).is_file()]
    except (OSError, ValueError, TypeError):
        return _error("stand_up", "The pack", "The product files cannot be read safely. Ask your data expert to check their location.")
    if len(have) == 3:
        return {"id": "stand_up", "title": "The pack", "state": DONE,
                "detail": f"{pack} carries its registration, configuration and variable files. Their contents still need review and validation.", "action": None}
    return {"id": "stand_up", "title": "The pack", "state": TODO,
            "detail": "Some product files are missing. For a new draft, use New product and preview its plan; for an existing product, ask your data expert to check the missing files.", "action": "new_product"}


def _extraction_current(base, product, metadata, rows):
    """Reuse the registered pipeline source and canonical extraction identity."""
    import spec_extract
    _source_registration(product)
    _pack_file(product, "spec_pipeline/pipeline.conf")
    material = sm.pipeline_material(str(product))
    sources = metadata.get("sources")
    if (not isinstance(material, dict) or not isinstance(sources, list) or not sources
            or any(not isinstance(source, dict) for source in sources)
            or metadata.get("extractor_version") != spec_extract.EXTRACTOR_VERSION):
        return False
    target = material.get("path_or_link")
    if not isinstance(target, str) or unstated(target) or target.lower().startswith(sm.REMOTE_PREFIXES):
        return False
    source_path = Path(sm.material_file(str(product), target, str(base)))
    if source_path.resolve() != source_path:
        return False
    source_path.relative_to(base)
    names = []
    for source in sources:
        name = source.get("file")
        if not isinstance(name, str) or Path(name).name != name:
            return False
        file = source_path / name if source_path.is_dir() else source_path
        file.resolve().relative_to(base)
        if file.resolve() != file:
            return False
        if file.name != name or not file.is_file() or _sha(file)[:16] != source.get("sha256"):
            return False
        names.append(name)
    if source_path.is_dir():
        for file in source_path.iterdir():
            if file.name in names or file.suffix.lower() not in {".md", ".tsv"} or not file.is_file():
                continue
            if file.resolve() != file or file.stat().st_size > 16 * 1024 * 1024:
                return False
            # The canonical extractor intentionally omits empty/header-only tabs.
            reader = spec_extract.read_markdown_tab if file.suffix.lower() == ".md" else spec_extract.read_tsv_tab
            _tab, extra_rows, _shape = reader(str(file))
            if extra_rows:
                return False
    if any(not isinstance(row.get("item_id"), str) or not isinstance(row.get("content_hash"), str) for row in rows):
        return False
    return spec_extract.extraction_fingerprint(sources, rows) == metadata.get("fingerprint")


def extraction(root: str, pack: str) -> dict:
    title = "Extraction and scaffolded records"
    try:
        base, product = _pack_path(root, pack)
        ext = _pack_file(product, "spec_pipeline/out/extracted.json")
        if not ext.is_file():
            return {"id": "extraction", "title": title, "state": TODO,
                    "detail": "No extraction has been prepared. In Flow, connect the registered workbook and prepare its extraction. A supplied draft can be extracted when the pipeline's access and input checks pass; extraction does not approve it.", "action": None}
        extracted = _json(ext)
        if not isinstance(extracted, dict) or not isinstance(extracted.get("rows"), list) \
                or any(not isinstance(row, dict) for row in extracted["rows"]) or not isinstance(extracted.get("extraction"), dict):
            raise ValueError("Extraction structure")
        rows, metadata = len(extracted["rows"]), extracted["extraction"]
        if type(metadata.get("row_count")) is not int or metadata["row_count"] != rows \
                or not isinstance(metadata.get("fingerprint"), str) or not metadata["fingerprint"]:
            raise ValueError("Extraction metadata")
        if not rows:
            return _error("extraction", title, "The extraction contains no specification rows. Check the workbook, selected sheets and pipeline input before continuing.")
        scaffold_path = _pack_file(product, "spec_pipeline/out/scaffold.json")
        lint_path = _pack_file(product, "spec_pipeline/out/lint.json")
        findings_path = _pack_file(product, "spec_pipeline/out/SPEC_FINDINGS.txt")
        if not all(path.is_file() for path in (scaffold_path, lint_path, findings_path)):
            return {"id": "extraction", "title": title, "state": TODO,
                    "detail": f"{rows} specification row(s) extracted, but the scaffold or findings artifacts are missing. Complete the extraction workflow in Progress and next step.", "action": None}
        scaffold, lint = _json(scaffold_path), _json(lint_path)
        if not isinstance(scaffold, dict) or not isinstance(scaffold.get("records"), list) \
                or any(not isinstance(record, dict) for record in scaffold["records"]) \
                or not isinstance(scaffold.get("scaffold"), dict) \
                or scaffold["scaffold"].get("fingerprint") != metadata["fingerprint"]:
            raise ValueError("Scaffold structure or fingerprint")
        if not isinstance(lint, dict) or not isinstance(lint.get("findings"), list) \
                or any(not isinstance(finding, dict) for finding in lint["findings"]) \
                or lint.get("fingerprint") != metadata["fingerprint"]:
            raise ValueError("Findings structure or fingerprint")
        with findings_path.open(encoding="utf-8-sig") as handle:
            report = handle.read(1024 * 1024 + 1)
        if len(report) > 1024 * 1024 or not report.strip():
            raise ValueError("Findings report unavailable")
        if not _extraction_current(base, product, metadata, extracted["rows"]):
            return _error("extraction", title, "The stored extraction does not match the current registered source or extractor identity. Refresh the extraction in Progress and next step, then run the existing drift check; matching stored fingerprints alone cannot prove current inputs.")
        high = sum(str(finding.get("severity") or "").upper() in {"HIGH", "ERROR"} for finding in lint["findings"])
        return {"id": "extraction", "title": title, "state": BLOCKED if high else DONE,
                "detail": f"{rows} specification row(s) extracted, {len(scaffold['records'])} record(s) scaffolded, "
                          f"{len(lint['findings'])} finding(s) in SPEC_FINDINGS.txt. "
                          + (f"Resolve {high} blocking finding(s) before continuing." if high else
                             "Artifacts are present and share a fingerprint. Check them in Progress and next step for current inputs and review requirements."), "action": None}
    except (OSError, ValueError, TypeError, KeyError, AttributeError, yaml.YAMLError, sm.Unreadable, RecursionError):
        return _error("extraction", title, "The extraction, scaffold or findings artifacts are malformed, unreadable or from different runs. Regenerate them from the registered input in Progress and next step.")


def configuration(root: str, pack: str) -> dict:
    title = "Configuration file check"
    try:
        _base, product = _pack_path(root, pack)
        files = sorted(list((product / "config").glob("*.yaml")) + list((product / "variables").glob("*.yaml")))
        if not files:
            return {"id": "configuration", "title": title, "state": TODO,
                    "detail": "No configuration or variable files are present yet.", "action": None}
        replace_pending = other_pending = 0
        for file in files:
            path = _pack_file(product, file.relative_to(product))
            with path.open(encoding="utf-8-sig") as handle:
                text = handle.read(4 * 1024 * 1024 + 1)
            if len(text) > 4 * 1024 * 1024:
                raise ValueError("Configuration file too large")
            if any(isinstance(token, (yaml.AliasToken, yaml.AnchorToken)) for token in yaml.scan(text)):
                raise ValueError("Configuration aliases require an engineering review")
            doc = strict_load(text)
            if not isinstance(doc, dict):
                raise ValueError("Configuration mapping")
            def pending(value):
                nonlocal replace_pending, other_pending
                if isinstance(value, dict):
                    for nested in value.values():
                        pending(nested)
                elif isinstance(value, list):
                    for nested in value:
                        pending(nested)
                elif isinstance(value, str):
                    if "REPLACE_ME" in value:
                        replace_pending += 1
                    elif value.strip() and unstated(value):
                        other_pending += 1
            pending(doc)
        names = ", ".join(file.relative_to(product).as_posix() for file in files[:4]) + (" …" if len(files) > 4 else "")
        if replace_pending or other_pending:
            counts = []
            if replace_pending:
                counts.append(f"{replace_pending} value(s) still REPLACE_ME")
            if other_pending:
                counts.append(f"{other_pending} other placeholder value(s)")
            return {"id": "configuration", "title": title, "state": TODO,
                    "detail": f"{names}: {', '.join(counts)}. Ask the relevant scientific owner or data expert to supply the actual values.", "action": None}
        if not (product / "config/data_product.yaml").is_file() or not list((product / "variables").glob("*.yaml")):
            return {"id": "configuration", "title": title, "state": TODO,
                    "detail": "The main product configuration or variable files are missing. Complete the product structure before validation.", "action": None}
        return {"id": "configuration", "title": title, "state": DONE,
                "detail": f"{names}: files parsed and no placeholder values found. This file check does not establish a complete implementation. Validate definitions, types, source mappings and execution next.", "action": None}
    except (OSError, ValueError, TypeError, yaml.YAMLError, RecursionError):
        return _error("configuration", title, "A configuration or variable file is malformed, unreadable or outside this product. Ask your data expert to repair it before validation.")


def validation(root: str, pack: str, last: str | None = None) -> dict:
    return {"id": "validate", "title": "Validate the configuration (lint, then strict)", "state": RUN,
            "detail": last or "platform/engine/validate.py refuses an undeclared, mistyped or defaulted scientific value.",
            "action": "validate"}


def build(root: str, pack: str, spark_ready: bool, spark_why: str, local_demo: bool, last: str | None = None) -> dict:
    if not local_demo:
        return {"id": "build", "title": "Build on synthetic sources (local Spark)", "state": UNAVAILABLE,
                "detail": "Builds run as Databricks Jobs when deployed; the portal never runs an engine in-process there.",
                "action": None}
    if not spark_ready:
        # NOT A DEFECT OF THE PRODUCT (2026-09-07): a laptop without Spark showed the same red glyph a
        # corrupt artifact earns; this step is simply not available here.
        return {"id": "build", "title": "Build on synthetic sources (local Spark)", "state": UNAVAILABLE,
                "detail": f"Not available on this machine: {spark_why} A data expert runs the synthetic build where Spark is installed.",
                "action": None}
    return {"id": "build", "title": "Build on synthetic sources (local Spark)", "state": RUN,
            "detail": last or "Run the existing product pipeline against synthetic sources and inspect its reported rows, cohorts and columns. "
                              "This checks configuration execution, not delivered data. Laptop builds may take several minutes.",
            "action": "build"}


def gates(root: str, pack: str, snapshot_entry: dict | None) -> dict:
    if isinstance(snapshot_entry, dict) and snapshot_entry:
        if snapshot_entry.get("product") not in (None, str(pack).replace("\\", "/")):
            return {"id": "gates", "title": "Gate verdicts need a current check", "state": BLOCKED,
                    "detail": "The result belongs to another product. Evaluate this selected product again.", "action": "evaluate"}
        gs = snapshot_entry.get("gates") or []
        rows = [g for g in gs if isinstance(g, dict) and type(g.get("gate")) is int
                and 1 <= g["gate"] <= 6 and isinstance(g.get("status"), str) and g["status"].strip()] if isinstance(gs, list) else []
        if any(row.get("product") not in (None, str(pack).replace("\\", "/")) for row in rows):
            return {"id": "gates", "title": "Gate verdicts need a current check", "state": BLOCKED,
                    "detail": "Some gate results belong to another product. Evaluate this selected product again.", "action": "evaluate"}
        if len({g["gate"] for g in rows}) != len(rows):
            return {"id": "gates", "title": "Gate verdicts need a current check", "state": BLOCKED,
                    "detail": "The result repeats a gate number. Evaluate this selected product again; duplicated results cannot complete the workflow.", "action": "evaluate"}
        rows.sort(key=lambda row: row["gate"])
        summary = ", ".join(f"gate {g.get('gate')}: {g.get('status')}" for g in rows[:6])
        if summary:
            # EVALUATED IS NOT PASSED (2026-09-07): a recorded verdict earned a completion glyph even
            # when it said the product was blocked at Gate 1. Complete means every gate is done;
            # anything else is the verdict, shown as the open step it is.
            statuses = [str(g.get("status")).strip().lower() for g in rows]
            all_done = len(rows) == 6 and len(rows) == len(gs) and all(s == "done" for s in statuses)
            first_open = next((g for g, s in zip(rows, statuses) if s != "done"), None)
            if all_done:
                return {"id": "gates", "title": "Gate verdicts: every gate done", "state": DONE,
                        "detail": summary + ". These are recorded verdicts; check current progress in Progress and next step.", "action": "evaluate"}
            if first_open is None:
                missing = sorted(set(range(1, 7)) - {g["gate"] for g in rows})
                return {"id": "gates", "title": "Gate verdicts are incomplete", "state": TODO,
                        "detail": summary + ". " + ("Missing gate results: " + ", ".join(map(str, missing)) + ". " if missing else "Some result rows are malformed. ")
                                  + "Evaluate this product again; a partial result does not complete the workflow.", "action": "evaluate"}
            blocked = str(first_open.get("status")).strip().lower() in ("blocked", "cannot complete") if first_open else False
            return {"id": "gates", "title": f"Gate verdicts: evaluated, gate {first_open.get('gate')} is {first_open.get('status')}",
                    "state": BLOCKED if blocked else TODO,
                    "detail": summary + ". These are recorded verdicts, not a pass; open Progress and next step for what to do.", "action": "evaluate"}
    sandbox = str(pack).replace("\\", "/").startswith("sandbox/")
    return {"id": "gates", "title": "Gate verdicts", "state": TODO,
            "detail": ("Not evaluated yet: evaluate this pack live (up to two minutes)." if sandbox else
                       "Not evaluated for this checkout: evaluate this pack live (up to two minutes) or rebuild the saved status report (about four minutes, every pack)."),
            "action": "evaluate"}


def input_digest(root, pack):
    """Bind a live result to the existing product snapshot plus shared gate code/rules."""
    import scientific_definitions
    base, product = _pack_path(root, pack)
    if not product.is_dir() or len(product.relative_to(base).parts) != 4:
        raise ValueError("Choose an existing product cut before evaluating it.")
    shared = {}
    for name in ("platform/tools", "platform/engine", "governance"):
        directory = base / name
        if directory.is_dir():
            for file in sorted(directory.rglob("*")):
                if file.suffix.lower() in {".py", ".yaml", ".yml", ".json", ".md"} and file.is_file():
                    if file.resolve() != file or not file.is_relative_to(base):
                        raise ValueError("A shared evaluation input redirects elsewhere.")
                    shared[file.relative_to(base).as_posix()] = _sha(file)
    # A registered workbook may be elsewhere in this checkout, outside the pack.
    registration = _source_registration(product) if (product / "source_refs.yaml").exists() else {}
    for material in registration.get("source_materials") or []:
        target = material.get("path_or_link") if isinstance(material, dict) else None
        if not isinstance(target, str) or unstated(target) or target.lower().startswith(sm.REMOTE_PREFIXES):
            continue
        file = Path(sm.material_file(str(product), target, str(base)))
        if file.resolve() != file or not file.is_relative_to(base):
            raise ValueError("A registered input redirects outside this checkout.")
        if file.is_file():
            shared[file.relative_to(base).as_posix()] = _sha(file)
        elif file.is_dir():
            for child in file.rglob("*"):
                if child.resolve() != child or not child.is_relative_to(base):
                    raise ValueError("A registered source directory redirects elsewhere.")
            shared[file.relative_to(base).as_posix() + "/"] = sm.sha256(str(file))
    value = {"root": str(base), "pack": str(pack).replace("\\", "/"),
             "product": scientific_definitions._snapshot(product), "shared": shared}
    return hashlib.sha256(json.dumps(value, sort_keys=True).encode()).hexdigest()


def record_result(root, pack, output, before):
    """Read the bounded runner's structured status output; exit text alone is no verdict."""
    invalid = {"product": str(pack).replace("\\", "/"), "ok": False, "entry": None}
    try:
        if not isinstance(output, str) or len(output.encode("utf-8")) > 16 * 1024 * 1024:
            return invalid
        text, separator, ending = output.rpartition("\n\n")
        if not separator or ending.strip() != "exit 0":
            return invalid
        entry = json.loads(text)
        rows = entry.get("gates") if isinstance(entry, dict) else None
        if (entry.get("product") != invalid["product"] or not isinstance(rows, list) or len(rows) != 6
                or any(not isinstance(row, dict) or type(row.get("gate")) is not int
                       or not isinstance(row.get("status"), str) or not row["status"].strip()
                       or row.get("product") not in (None, invalid["product"]) for row in rows)
                or {row["gate"] for row in rows} != set(range(1, 7))):
            return invalid
        if not isinstance(before, str) or before != input_digest(root, pack):
            return invalid
        return {"product": invalid["product"], "ok": True, "entry": entry, "input_digest": before}
    except (OSError, ValueError, TypeError, AttributeError, KeyError, yaml.YAMLError, sm.Unreadable, RecursionError):
        return invalid


def result_current(root, pack, result):
    try:
        return (isinstance(result, dict) and result.get("ok") is True
                and result.get("product") == str(pack).replace("\\", "/")
                and isinstance(result.get("entry"), dict)
                and result.get("input_digest") == input_digest(root, pack))
    except (OSError, ValueError, TypeError, AttributeError, KeyError, yaml.YAMLError, sm.Unreadable, RecursionError):
        return False


def steps(root: str, pack: str, spark_ready: bool, spark_why: str, local_demo: bool,
          snapshot_entry: dict | None = None, last: dict | None = None) -> list[dict]:
    last = last if isinstance(last, dict) else {}
    config = configuration(root, pack)
    synthetic = build(root, pack, spark_ready, spark_why, local_demo, last.get("build"))
    if synthetic["action"] == "build" and config["state"] != DONE:
        synthetic = {**synthetic, "state": BLOCKED, "action": None,
                     "detail": "Complete or repair the configuration values shown above, then validate them before starting a synthetic build."}
    verdict = gates(root, pack, snapshot_entry)
    saved = last.get("gates_result")
    if isinstance(saved, dict):
        if result_current(root, pack, saved):
            verdict = gates(root, pack, saved["entry"])
        else:
            verdict = {"id": "gates", "title": "Gate verdicts need a current check", "state": TODO,
                       "detail": "The last live evaluation failed, is incomplete, or its product inputs changed. Evaluate this product again; the retained output is historical.", "action": "evaluate"}
    return [workbook(root, pack), stand_up(root, pack), extraction(root, pack), config,
            validation(root, pack, last.get("validate")), synthetic, verdict]


GLYPH = {DONE: "✅", TODO: "⬜", BLOCKED: "⛔", RUN: "▶️", UNAVAILABLE: "⏸️"}
