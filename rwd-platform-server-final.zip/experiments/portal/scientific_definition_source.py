"""Register extraction evidence and record explicit human access-review fields.

The canonical source helpers own registration and eligibility. This adapter adds
portal scope, concurrency and atomicity; it never supplies a person's decision.
"""
from __future__ import annotations
from contextlib import ExitStack

import copy
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import tempfile

import yaml

import specification_details as details
import source_review
import source_manifest as sm
import flow_guidance as guidance

FIELDS = ("ai_classification", "classified_by", "classified_date", "approved_by", "approval_date")
NOTICE = ("Registration leaves human decisions pending unless the workbook's own signed AI decision applies. "
          "Saving review fields records only the review you entered; "
          "it does not authenticate a signature, approve scientific definitions or approve a release.")
MAX_EXTRACTION = 4 * 1024 * 1024


def _failure(error):
    return {"ok": False, "changed": False, "digest": "", "registered": False, "ready": False,
            "reasons": [str(error)], "errors": [str(error)], "values": {field: "" for field in FIELDS},
            "material": {}, "registration_available": False, "registration_preview": "", "notice": NOTICE,
            "inherited_from_parent": False, "inheritance_available": False,
            "inherited": {field: "" for field in FIELDS}}


def _parent(product, doc):
    """The workbook record the pipeline names, read from the SAME parsed document as the extraction.

    Reading it from disk again would let the two disagree for the length of a save; the candidate
    checked and the record written must be one document.
    """
    source_id = sm.pipeline_source_id(str(product))
    if not source_id:
        return None
    return next((item for item in doc["source_materials"] if item.get("material_id") == source_id), None)


def _inheritance(product, doc):
    """The five values the workbook's record lets the extraction take verbatim, or (None, why).

    One definition, the canonical helper's: the portal must never be able to inherit a decision
    the command line would refuse, or the reverse.
    """
    return sm.inheritable_classification(_parent(product, doc))


def _inherited_from(material, inherited):
    """True when the registered extraction carries exactly the workbook's five values, reviewed."""
    if not inherited or not material or material.get("status") != sm.REVIEWED:
        return False
    return all(material.get(field) == inherited[field] for field in FIELDS)


def _safe(path):
    path = Path(path).absolute()
    if path.resolve() != path:
        raise details._Invalid("An extraction-review input redirects to another location. Ask your data expert to repair it.")
    return path


def _hash(raw):
    return hashlib.sha256(raw).hexdigest()


def _load(root, pack, allowed_packs):
    path, pack, raw, text, doc, _, _ = details._load(root, pack, allowed_packs)
    root, product = Path(root).resolve(), path.parent
    matches = [i for i, item in enumerate(doc["source_materials"]) if item.get("material_type") == sm.AI_EXTRACTION]
    if len(matches) > 1:
        raise details._Invalid("The source record has multiple extracted-specification registrations. Ask your data expert to repair it.")
    index = matches[0] if matches else None
    evidence = {"source_refs.yaml": _hash(raw)}
    for label, candidate in (("extraction", product / sm.AI_READABLE[0]),
                             ("pipeline", product / "spec_pipeline/pipeline.conf"),
                             ("policy", root / sm.AI_BOUNDARY)):
        candidate = _safe(candidate)
        if candidate.is_file():
            if candidate.stat().st_size > MAX_EXTRACTION:
                raise details._Invalid("An extraction-review input exceeds the 4 MB editor limit.")
            evidence[label] = _hash(candidate.read_bytes())
        else:
            evidence[label] = None
    reason = guidance._extraction_reason(root, product, doc["source_materials"], registering=False)
    if not reason:
        selected = sm.pipeline_material(str(product))
        selected_path = _safe(sm.material_file(str(product), selected["path_or_link"], str(root)))
        if selected_path.is_file():
            evidence["selected_source"] = sm.sha256(str(selected_path))
        else:
            for candidate in selected_path.rglob("*"):
                _safe(candidate)
            evidence["selected_source"] = sm.sha256(str(selected_path))
    digest = _hash(json.dumps(evidence, sort_keys=True).encode("utf-8"))
    return path, pack, raw, text, doc, index, digest, reason


def _check_candidate(root, product, doc):
    """Run the unchanged eligibility gate against candidate metadata in a process.

    The candidate never replaces the product's source register for a preview.
    Isolation also keeps concurrent Streamlit sessions' source readers untouched.
    """
    temporary = None
    try:
        with tempfile.NamedTemporaryFile(mode="w", encoding="utf-8", prefix="rwd-extraction-review-",
                                         suffix=".json", delete=False) as handle:
            temporary = Path(handle.name)
            json.dump(doc, handle, ensure_ascii=False, default=str)
        result = subprocess.run([sys.executable, str(Path(__file__).resolve()), "--check-candidate",
                                 str(Path(root).resolve()), str(product), str(temporary)],
                                capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=60,
                                env={**os.environ, "PYTHONUTF8": "1"})
        if result.returncode:
            raise details._Invalid("The extraction eligibility check could not finish. No review was saved.")
        checked = json.loads(result.stdout)
        if (not isinstance(checked, dict) or type(checked.get("ready")) is not bool
                or not isinstance(checked.get("reasons"), list)
                or any(not isinstance(item, str) for item in checked["reasons"])):
            raise details._Invalid("The extraction eligibility check returned an unreadable result.")
        return checked["ready"], checked["reasons"]
    except (subprocess.TimeoutExpired, json.JSONDecodeError) as error:
        raise details._Invalid("The extraction eligibility check did not return a current result. No review was saved.") from error
    finally:
        if temporary is not None:
            temporary.unlink(missing_ok=True)


def _description(root, loaded):
    path, pack, raw, _, doc, index, digest, reason = loaded
    material = doc["source_materials"][index] if index is not None else {}
    ready, reasons = (False, [reason]) if reason else _check_candidate(root, path.parent, doc)
    inherited, _ = _inheritance(path.parent, doc)
    preview, registration_problem = ("", "")
    if index is None and not reason:
        # The preview shows what registering would write: the workbook's decision when it applies,
        # the five TODOs when it does not.
        preview, registration_problem = sm.ai_extraction_block(str(path.parent), inherit=bool(inherited))
        preview = preview or ""
        if preview and not registration_problem:
            try:
                _registration_bytes(raw, doc, pack, preview, inherited)
            except details._Invalid as error:
                registration_problem = str(error)
        if registration_problem:
            reasons.append(str(registration_problem))
    return {"ok": True, "changed": False, "pack": pack, "digest": digest, "registered": index is not None,
            "ready": ready, "reasons": reasons, "errors": [], "notice": NOTICE,
            "values": {field: "" if sm.unstated(material.get(field)) else str(material[field]) for field in FIELDS},
            "material": {field: str(material.get(field) or "") for field in ("material_id", "path_or_link", "status")},
            "registration_available": index is None and not reason and bool(preview) and not registration_problem,
            "registration_preview": preview,
            "inherited_from_parent": _inherited_from(material, inherited),
            "inheritance_available": bool(inherited),
            "inherited": {field: str(inherited[field]) if inherited else "" for field in FIELDS}}


def describe(root, pack, allowed_packs=None):
    try:
        return _description(root, _load(root, pack, allowed_packs))
    except (details._Invalid, sm.Unreadable, OSError, ValueError, TypeError, KeyError,
            UnicodeError, yaml.YAMLError, RecursionError) as error:
        return _failure(error)


def _expected(loaded, expected_digest):
    if not isinstance(expected_digest, str) or not re.fullmatch(r"[0-9a-f]{64}", expected_digest):
        raise details._Invalid("Reload the current extraction review before saving; its starting digest is required.")
    if loaded[6] != expected_digest:
        raise details._Invalid("The source or extraction changed while this form was open. Reload and review the current version before saving.")
    if loaded[7]:
        raise details._Invalid(loaded[7])


def _write(root, pack, path, replacement, expected_digest, allowed_packs):
    temporary = None
    try:
        with tempfile.NamedTemporaryFile(mode="wb", prefix=".extraction-review-", suffix=".tmp",
                                         dir=path.parent, delete=False) as handle:
            temporary = Path(handle.name)
            handle.write(replacement)
            handle.flush()
            os.fsync(handle.fileno())
        os.chmod(temporary, path.stat().st_mode)
        current = _load(root, pack, allowed_packs)
        _expected(current, expected_digest)
        if current[0] != path:
            raise details._Invalid("The source location changed during this save. Nothing was saved.")
        os.replace(temporary, path)
        temporary = None
    finally:
        if temporary is not None:
            temporary.unlink(missing_ok=True)


def _registration_bytes(raw, doc, pack, block, inherited=None):
    """The source_refs.yaml bytes with the block registered, proven to add nothing else.

    Without `inherited` the new material must be pending with every human field unstated. With it,
    the material must be reviewed and carry EXACTLY the workbook's five values: a block that named
    any other person, date or class would be the tool supplying a decision, and is refused.
    """
    with tempfile.TemporaryDirectory(prefix="rwd-extraction-registration-") as directory:
        staged = Path(directory)
        (staged / sm.SOURCE_REFS).write_bytes(raw)
        _, ok = sm.write_ai_extraction_block(str(staged), block)
        if not ok:
            raise details._Invalid("The existing source-material list cannot accept this registration safely. Ask your data expert to use the canonical indented source-material layout.")
        replacement = (staged / sm.SOURCE_REFS).read_bytes()
    _, resulting, _, _ = details._parse(replacement, pack)
    inserted = [item for item in resulting["source_materials"] if item.get("material_type") == sm.AI_EXTRACTION]
    expected = copy.deepcopy(doc)
    if len(inserted) != 1:
        raise details._Invalid("The extraction registration did not create exactly one material.")
    expected["source_materials"].append(inserted[0])
    if resulting != expected:
        raise details._Invalid("The registration would change another source field or supply a human decision. Nothing was saved.")
    if inherited:
        if (inserted[0].get("status") != sm.REVIEWED or "why_provisional" in inserted[0]
                or any(inserted[0].get(field) != inherited[field] for field in FIELDS)):
            raise details._Invalid("The registration would record a decision other than the workbook's own. Nothing was saved.")
    elif (inserted[0].get("status") != "pending"
            or any(not sm.unstated(inserted[0].get(field)) for field in FIELDS)):
        raise details._Invalid("The registration would change another source field or supply a human decision. Nothing was saved.")
    return replacement


def register(root, pack, *, expected_digest, local_demo=False, can_write=False, allowed_packs=None):
    """Append only canonical machine-known extraction metadata, leaving review pending.

    When the workbook's own record is AI-eligible, reviewed and signed, the extraction takes that
    record's five values verbatim and registers reviewed, because the person answered those
    questions when they started the product. The inherited candidate is still put through the
    unchanged eligibility gate first: if the derived bytes fail it, the review is left pending
    and the person sees why, exactly as a hand-typed eligible review would be refused.
    """
    if local_demo is not True or can_write is not True:
        return _failure("Registering extraction evidence requires author access in an authorized local session.")
    lock_stack = ExitStack()
    try:
        path, pack = details._paths(root, pack, allowed_packs)
        lock_stack.enter_context(details.source_edit_lock(root, path))
        loaded = _load(root, pack, allowed_packs)
        _expected(loaded, expected_digest)
        _, _, raw, _, doc, index, _, _ = loaded
        if index is not None:
            raise details._Invalid("This extraction is already registered. Review its current entry; registration never replaces a person's review.")
        inherited, _ = _inheritance(path.parent, doc)
        skipped = ""
        replacement = None
        if inherited:
            block, problem = sm.ai_extraction_block(str(path.parent), inherit=True)
            if problem or not block:
                raise details._Invalid(problem or "The current extraction could not be registered.")
            replacement = _registration_bytes(raw, doc, pack, block, inherited)
            _, candidate, _, _ = details._parse(replacement, pack)
            ready, reasons = _check_candidate(root, path.parent, candidate)
            if not ready:
                skipped = ("The workbook's AI decision was not applied to this extraction because the extraction "
                           "does not pass the eligibility checks: " + " ".join(reasons))
                replacement = None
        if replacement is None:
            block, problem = sm.ai_extraction_block(str(path.parent))
            if problem or not block:
                raise details._Invalid(problem or "The current extraction could not be registered.")
            replacement = _registration_bytes(raw, doc, pack, block)
        _write(root, pack, path, replacement, expected_digest, allowed_packs)
        result = {**describe(root, pack, allowed_packs), "changed": True, "authenticated": False}
        if skipped:
            result["reasons"] = [skipped, *result.get("reasons", [])]
        return result
    except FileExistsError:
        return _failure("Another source edit is in progress. Wait for it to finish, then reload.")
    except (details._Invalid, sm.Unreadable, OSError, ValueError, TypeError, KeyError,
            UnicodeError, yaml.YAMLError, RecursionError) as error:
        return _failure(error)
    finally:
        lock_stack.close()


def record_review(root, pack, updates, *, expected_digest, confirmed=False, local_demo=False,
                  can_review=False, allowed_packs=None):
    """Record the five human-entered fields without inferring names, dates or class."""
    if local_demo is not True or can_review is not True:
        return _failure("Recording extraction review requires reviewer access in an authorized local session.")
    if confirmed is not True:
        return _failure("Confirm that you reviewed this extraction and are recording the decision actually made before saving.")
    if not isinstance(updates, dict) or set(updates) != set(FIELDS):
        return _failure("Enter all five displayed review fields; source metadata and other material fields cannot be changed here.")
    clean = {}
    for field, value in updates.items():
        if (not isinstance(value, str) or not value.strip() or len(value) > 200
                or any(ord(c) < 32 or ord(c) == 127 for c in value) or sm.unstated(value)):
            return _failure(f"{field} needs an actual single-line value of at most 200 characters.")
        clean[field] = value.strip()
    problems = sm.classification_errors(clean)
    for field in ("classified_date", "approval_date"):
        problem = sm.bad_date(clean[field])
        if problem:
            problems.append(field + " " + problem)
    if problems:
        return _failure(" ".join(problems))
    lock_stack = ExitStack()
    try:
        path, pack = details._paths(root, pack, allowed_packs)
        lock_stack.enter_context(details.source_edit_lock(root, path))
        loaded = _load(root, pack, allowed_packs)
        _expected(loaded, expected_digest)
        _, _, _, text, doc, index, _, _ = loaded
        if index is None:
            raise details._Invalid("Register the extracted specification before recording its review.")
        tree = yaml.compose(text, Loader=details._StrictLoader)
        material_nodes = next(value for key, value in tree.value if key.value == "source_materials")
        changes = {**clean, "status": sm.REVIEWED}
        # The registration block's pending reason says the review is awaited; a
        # reviewed material must not keep saying so (the shared editor drops it).
        removals = tuple(field for field in sm.PENDING_FIELDS if field in doc["source_materials"][index])
        replacement, resulting = source_review._edited(text, doc, index, material_nodes.value[index], changes, pack,
                                                       removals=removals)
        ready, reasons = _check_candidate(root, path.parent, resulting)
        if clean["ai_classification"] == sm.AI_ELIGIBLE and not ready:
            raise details._Invalid("This extraction cannot be recorded as ready for AI use: " + " ".join(reasons))
        if clean["ai_classification"] != sm.AI_ELIGIBLE:
            # A restricted human decision is valid, but it must still describe
            # the current registered bytes. Test the same candidate's integrity
            # with its explicit classification refusal removed in this preview.
            integrity = copy.deepcopy(resulting)
            integrity["source_materials"][index]["ai_classification"] = sm.AI_ELIGIBLE
            _, integrity_reasons = _check_candidate(root, path.parent, integrity)
            allowed_reasons = [reason for reason in integrity_reasons if "derives (via" not in reason]
            if allowed_reasons:
                raise details._Invalid("Review the current registered extraction before recording this decision: " + " ".join(allowed_reasons))
        if replacement == loaded[2]:
            return {**_description(root, loaded), "changed": False, "authenticated": False}
        _write(root, pack, path, replacement, expected_digest, allowed_packs)
        return {**describe(root, pack, allowed_packs), "changed": True, "authenticated": False,
                "changed_fields": [field for field, value in changes.items() if doc["source_materials"][index].get(field) != value]
                                  + list(removals)}
    except FileExistsError:
        return _failure("Another source edit is in progress. Wait for it to finish, then reload.")
    except (details._Invalid, sm.Unreadable, OSError, ValueError, TypeError, KeyError,
            UnicodeError, yaml.YAMLError, RecursionError) as error:
        return _failure(error)
    finally:
        lock_stack.close()


def _candidate_main(root, product, candidate):
    doc = json.loads(Path(candidate).read_text(encoding="utf-8"))
    # These substitutions are confined to this short-lived checker process.
    sm.materials = lambda _product: doc["source_materials"]
    sm.repo_root = lambda: root
    sm._BOUNDARY_ROOT = root
    ready, reasons = sm.ai_readable(product)
    print(json.dumps({"ready": ready, "reasons": reasons}, ensure_ascii=False))


if __name__ == "__main__" and len(sys.argv) == 5 and sys.argv[1] == "--check-candidate":
    _candidate_main(*sys.argv[2:])
