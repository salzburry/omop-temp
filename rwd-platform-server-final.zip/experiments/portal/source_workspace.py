"""Scoped source workspaces; canonical checks own every scientific verdict.

Requests and proposals live outside the checkout. Profiles remain in the configured
restricted directory: only identities, names, findings and counts reach this UI.
Receiving a file checks its binding, never authenticates a runtime or approves data.
"""
from __future__ import annotations

import copy
import csv
import difflib
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import stat
import tempfile
import uuid
from datetime import date, datetime, timezone

import yaml

import specification_details as details
import source_requirements as requirements
import source_adapter as adapters
import profile_io
import product_gates as gates
import propose_source_mapping as mappings
from engine.config import load_config
from engine.validate import problems as config_problems

LIMIT = 8 * 1024 * 1024
EVIDENCE_SCAN_ENTRIES = 256
EVIDENCE_SCAN_BYTES = 32 * 1024 * 1024
ROUTES = {"source_requirements", "source_delivery", "source_evidence", "source_mapping", "delivery_drift", "feasibility"}
NOTICE = "Draft work only. No source review, authenticated runtime result, scientific approval or release is created."
PROFILE_UNCHANGED = "This profile was already received; nothing changed."
REPORT_STALE = ("A different profile was received. The source report prepared or saved from the earlier profile is now "
                "out of date; receive the schema check and source quality results again to regenerate it.")
REPORT_STATES = {"source_report_ready_for_review", "source_report_saved_pending_review"}


class Invalid(ValueError):
    pass


def _fail(error):
    return {"ok": False, "errors": [str(error)], "notice": NOTICE}


def _guard(function):
    def wrapped(*args, **kwargs):
        try:
            return function(*args, **kwargs)
        except SystemExit:
            return _fail("The existing checker refused the supplied metadata. Regenerate the restricted artifacts and review the product's declared inputs; restricted field contents were not copied.")
        except (Invalid, details._Invalid, OSError, ValueError, KeyError, TypeError, AttributeError,
                yaml.YAMLError) as error:
            return _fail(error)
    return wrapped


def _safe(path):
    path = Path(path).absolute()
    if path.resolve() != path:
        raise Invalid("A workspace input redirects to another location. Reopen its canonical path.")
    return path


def _bytes(path):
    path = _safe(path)
    if not path.is_file() or path.stat().st_size > LIMIT:
        raise Invalid("The selected metadata file is missing or exceeds the 8 MB limit.")
    with path.open("rb") as handle:
        raw = handle.read(LIMIT + 1)
    if len(raw) > LIMIT:
        raise Invalid("The selected metadata file is missing or exceeds the 8 MB limit.")
    return raw


def _sha(value):
    raw = value if isinstance(value, bytes) else json.dumps(value, sort_keys=True, ensure_ascii=False, allow_nan=False).encode()
    return hashlib.sha256(raw).hexdigest()


def _configured_inputs(product):
    """Constrain every config-controlled read before calling canonical readers."""
    references = []
    for path in (product / "config/data_product.yaml", product / "config/pipeline.yaml"):
        _safe(path)
        if not path.exists() and path.name == "pipeline.yaml":
            continue
        raw = _bytes(path)
        if any(isinstance(token, (yaml.AliasToken, yaml.AnchorToken)) for token in yaml.scan(raw)):
            raise Invalid("Configuration aliases need Engineering review before this workspace can read them.")
        document = yaml.load(raw, Loader=details._StrictLoader)
        if not isinstance(document, dict):
            raise Invalid("The product configuration must contain a YAML mapping.")
        variables, codelists = document.get("variables") or [], document.get("codelists") or {}
        if not isinstance(variables, list) or not isinstance(codelists, dict):
            raise Invalid("Declare variable files as a list and codelist files as a mapping.")
        for ref in [*variables, *codelists.values()]:
            if not isinstance(ref, str) or not ref or Path(ref).is_absolute() or ".." in Path(ref).parts:
                raise Invalid("A configuration reference leaves its selected product. Review the declared metadata paths first.")
            target = _safe(product / ref)
            if not target.is_relative_to(product) or target.suffix.lower() not in {".yaml", ".yml"}:
                raise Invalid("Configuration references must name YAML metadata inside the selected product.")
            _bytes(target)
            references.append(target)
        union = document.get("source_union") or {}
        if not isinstance(union, dict) or not isinstance(union.get("members", []), list):
            raise Invalid("Declare source union members using the existing configuration schema.")
        for member in union.get("members", []):
            if not isinstance(member, dict) or not re.fullmatch(r"[A-Za-z_][A-Za-z0-9_]*(?:\.[A-Za-z_][A-Za-z0-9_]*)*", str(member.get("schema") or "")):
                raise Invalid("A union member must name a source schema, without file-path characters.")
    # Canonical source readers also inspect these fixed product folders.
    for directory in ("config", "variables", "codelists", "handoff"):
        base = _safe(product / directory)
        if base.is_dir():
            for path in base.rglob("*"):
                _safe(path)
    return references


def _scope(root, pack, actor_id, allowed_packs):
    source, pack = details._paths(root, pack, allowed_packs)
    if not isinstance(actor_id, str) or not actor_id.strip() or len(actor_id) > 200:
        raise Invalid("An identified portal session is required.")
    root, product = Path(root).resolve(), source.parent
    _configured_inputs(product)
    owner = _sha(actor_id)
    default = Path(os.environ.get("LOCALAPPDATA") or tempfile.gettempdir()) / "RWDPortal" / "source-workspaces"
    base = _safe(Path(os.environ.get("RWD_SOURCE_WORKSPACE_DIR") or default))
    if base.is_relative_to(root):
        raise Invalid("Source workspace storage must be outside the checkout.")
    folder = _safe(base / _sha(str(root))[:16] / owner[:24] / _sha(pack)[:16])
    return root, product, pack, owner, folder


def _authorized(local_demo, can_write):
    if local_demo is not True or can_write is not True:
        raise Invalid("Saving or running this work requires an authorized local editing session.")


def _inputs(root, product):
    import workflow_outputs
    files = {}
    for path in _configured_inputs(product):
        files[path.relative_to(root).as_posix()] = _sha(_bytes(path))
    for directory in ("config", "variables", "codelists", "handoff"):
        base = _safe(product / directory)
        if base.is_dir():
            for file in sorted(base.rglob("*")):
                _safe(file)
                if workflow_outputs.is_saved_output(file.relative_to(root).as_posix()):
                    continue
                if file.is_file() and file.suffix.lower() in {".yaml", ".yml", ".md"}:
                    files[file.relative_to(root).as_posix()] = _sha(_bytes(file))
    for file in (product / "source_refs.yaml", root / "products/registry.yaml", root / "fixtures/registry.yaml",
                 root / "governance/vendor_policy.yaml", root / "governance/NAMING_RULINGS.yaml"):
        if file.exists():
            files[file.relative_to(root).as_posix()] = _sha(_bytes(file))
    return files


def _write(folder, record):
    _safe(folder).mkdir(parents=True, exist_ok=True)
    target = _safe(folder / (record["id"] + ".json"))
    raw = json.dumps(record, indent=2, ensure_ascii=False, allow_nan=False).encode()
    if len(raw) > LIMIT:
        raise Invalid("Split this work into a smaller proposal.")
    with tempfile.NamedTemporaryFile(dir=folder, delete=False) as handle:
        handle.write(raw)
        temporary = Path(handle.name)
    try:
        _safe(target)
        os.replace(temporary, target)
    finally:
        if temporary.exists():
            temporary.unlink()


def _load(scope, record_id, *, allowed_routes=None):
    # Reusers of the private record store opt in at their trusted call site.
    # A saved payload cannot extend the source workspace's route allowlist.
    routes = ROUTES if allowed_routes is None else allowed_routes
    root, _product, pack, owner, folder = scope
    if not isinstance(record_id, str) or not re.fullmatch(r"[a-f0-9]{32}", record_id):
        raise Invalid("Choose a saved request or proposal from this workspace.")
    try:
        record = json.loads(_bytes(folder / (record_id + ".json")))
    except (ValueError, RecursionError):
        raise Invalid("The saved source work is unreadable. Ask the workspace owner to repair it, or choose another saved request.") from None
    if (not isinstance(record, dict) or not isinstance(record.get("payload"), dict)
            or any(not isinstance(record.get(key), str) for key in
                   ("id", "pack", "owner", "root", "route", "title", "state", "updated_at", "inputs_sha256"))
            or record["route"] not in routes or not re.fullmatch(r"[0-9a-f]{64}", record["inputs_sha256"])):
        raise Invalid("The saved source work has an unsupported format. Ask the workspace owner to repair it, or choose another saved request.")
    if record.get("id") != record_id or record.get("pack") != pack or record.get("owner") != owner or record.get("root") != str(root):
        raise Invalid("The saved work belongs to a different product or identity.")
    _saved_payload_shape(record)
    return record


def _saved_payload_shape(record):
    """Check the nested evidence fields consumed by the UI and handoff readers.

    This is format validation only; original files and canonical intake checks
    still determine the current evidence identity, findings and eligibility.
    """
    payload = record["payload"]
    def require(condition):
        if not condition:
            raise Invalid("The saved source work contains incomplete or unsupported details. Ask the workspace owner to repair this record, or prepare a fresh request; nothing was changed.")
    def strings(value, fields):
        return isinstance(value, dict) and all(isinstance(value.get(field), str) for field in fields)
    require("summary" not in payload or isinstance(payload["summary"], str))
    if record["route"] == "source_evidence":
        require(strings(payload.get("expected"), ("product_id", "schema", "cut", "delivery_sha256")))
        received = payload.get("received")
        require(isinstance(received, dict))
        for kind, entry in received.items():
            require(kind in {"profile", "schema", "source_qc"} and strings(entry, ("path", "sha256")))
            require(bool(re.fullmatch(r"[0-9a-f]{64}", entry["sha256"])))
            if kind == "profile":
                require(all(isinstance(entry.get(key), int) and not isinstance(entry[key], bool) and entry[key] >= 0
                            for key in ("table_count", "column_count")))
            else:
                require(isinstance(entry.get("result"), str) and entry["result"] in {"passed_live", "failed_live"})
        if "source_report_preview" in payload:
            require(strings(payload, ("source_report_preview", "source_report_target", "source_report_diff", "source_report_before_sha256")))
            require(isinstance(payload.get("source_counts"), dict))
    elif record["route"] == "feasibility":
        criteria = payload.get("criteria")
        require(isinstance(criteria, list) and 1 <= len(criteria) <= 20)
        require(all(strings(item, ("variable", "operator", "value")) for item in criteria))
        require(strings(payload, ("criteria_sha256", "lane")) and isinstance(payload.get("identity"), dict))
        require(payload["criteria_sha256"] == _sha(criteria))
        if payload.get("synthetic"):
            require(isinstance(payload.get("attrition"), list) and all(isinstance(item, dict) for item in payload["attrition"]))
            require(strings(payload.get("counts"), ("rounding",)))
        else:
            require(strings(payload, ("frame_sha256", "grain", "runtime_action")) and isinstance(payload.get("expected_return"), dict))
            if "returned_counts" in payload:
                returned = payload["returned_counts"]
                require(isinstance(returned, dict) and "total" in returned and isinstance(returned.get("attrition"), list))
                require(_safe_count(returned["total"]) and all(isinstance(item, dict) and _safe_count(item.get("remaining"))
                    and _safe_count(item.get("dropped")) for item in returned["attrition"]))


def _new(scope, route, title, state, payload, *, expected_digest=None):
    root, product, pack, owner, folder = scope
    digest = _sha(_inputs(root, product))
    if expected_digest is not None and digest != expected_digest:
        raise Invalid("The product or supporting policy changed during validation. Stage fresh work against the current configuration.")
    record = {"id": uuid.uuid4().hex, "root": str(root), "pack": pack, "owner": owner,
              "route": route, "title": title, "state": state, "inputs_sha256": digest,
              "updated_at": datetime.now(timezone.utc).isoformat(), "payload": payload, "notice": NOTICE}
    _write(folder, record)
    return record


def _fresh(scope, record):
    if record.get("inputs_sha256") != _sha(_inputs(scope[0], scope[1])):
        raise Invalid("The product or supporting policy changed. Prepare fresh work against the current definitions and configuration.")


def state_words(state):
    """A record's state as the words a recent-work row shows: 'source report saved pending review',
    never the identifier with its underscores (walk RW4-N05)."""
    return str(state or "").replace("_", " ")


def recent(root, pack, actor_id, *, allowed_packs=None):
    try:
        scope = _scope(root, pack, actor_id, allowed_packs)
        folder = scope[-1]
        result = []
        if folder.is_dir():
            for path in folder.glob("*.json"):
                try:
                    record = _load(scope, path.stem)
                except (Invalid, details._Invalid, OSError, ValueError, KeyError, TypeError):
                    # One interrupted/corrupt save must not hide every other
                    # request, and listing never deletes the damaged artifact.
                    continue
                result.append({key: record[key] for key in ("id", "route", "title", "updated_at")}
                              | {"state": state_words(record["state"]), "summary": record["payload"].get("summary", NOTICE),
                                 "params": {"id": record["id"]}})
        return sorted(result, key=lambda item: item["updated_at"], reverse=True)[:40]
    except (Invalid, details._Invalid, OSError, ValueError, KeyError, TypeError, yaml.YAMLError):
        return []


@_guard
def read(root, pack, actor_id, record_id, *, allowed_packs=None):
    scope = _scope(root, pack, actor_id, allowed_packs)
    record = _load(scope, record_id)
    return {"ok": True, "record": record, "stale": record["inputs_sha256"] != _sha(_inputs(scope[0], scope[1])), "errors": []}


def _identity(product):
    cfg = load_config(str(product / "config/data_product.yaml"))
    run = cfg.raw.get("run") or {}
    members = [str(item["schema"]) for item in (cfg.source_union or {}).get("members", [])]
    return cfg, {"product_id": cfg.data_product_id, "schema": str(run.get("source_schema") or ""),
                 "cut": str(run.get("refresh") or ""), "members": members, "vendor": str(cfg.raw.get("vendor") or "")}


def _stem_unstated(stem):
    """A table stem nobody has declared: blank, a placeholder, or the template's REPLACE_ME inside a name."""
    text = str(stem or "")
    return gates.unstated(text) or "REPLACE_ME" in text.upper()


def delivery_sentence(identity):
    """One sentence a person reads instead of the identity record; every blank is named as a blank."""
    schema = identity.get("schema") or ""
    members = identity.get("members") or []
    parts = ["product " + (identity.get("product_id") if not gates.unstated(identity.get("product_id")) else "not declared yet")]
    if members:
        parts.append("union members " + ", ".join(members))
    else:
        parts.append("schema " + (schema if not gates.unstated(schema) else "not declared yet"))
    parts.append("cut " + (identity["cut"] if not gates.unstated(identity.get("cut")) else "not declared yet"))
    parts.append("vendor " + (identity["vendor"] if not gates.unstated(identity.get("vendor")) else "not declared yet"))
    return "Delivery: " + "; ".join(parts) + "."


@_guard
def describe(root, pack, actor_id, *, allowed_packs=None):
    root, product, pack, _owner, _folder = _scope(root, pack, actor_id, allowed_packs)
    _cfg, identity = _identity(product)
    rows, findings, contract_present = requirements.matrix(str(product))
    route, reason = gates.evidence_route(str(root), pack)
    blockers, needs = [], []
    if gates.unstated(identity["product_id"]):
        blockers.append("The product identifier is not declared in the delivery configuration yet.")
        needs.append("the product identifier")
    if gates.unstated(identity["cut"]):
        blockers.append("The delivery cut is not declared yet; evidence is requested for one named cut.")
        needs.append("the delivery cut")
    if not identity["members"] and gates.unstated(identity["schema"]):
        blockers.append("The delivered source schema is not declared yet.")
        needs.append("the delivered source schema")
    if not route:
        blockers.append("Declare this vendor's evidence route: " + str(reason))
    undeclared = sorted(row["role"] for row in rows if row.get("declared") and _stem_unstated(row.get("physical_stem")))
    if undeclared:
        blockers.append("The delivery tables are not declared yet for " + ", ".join(undeclared)
                        + "; the data expert uses Declare the source delivery before a runtime can profile this delivery.")
        needs.append("the delivered table for each of " + ", ".join(undeclared))
    handoff_note = ("" if not needs else
                    f"Please declare {'; '.join(needs)} in the delivery configuration of {pack}, "
                    "so a source evidence request can be saved for this delivery.")
    return {"ok": True, "rows": rows, "findings": findings, "contract_present": contract_present,
            "identity": identity, "delivery_sentence": delivery_sentence(identity),
            "evidence_route": route, "evidence_reason": reason, "blockers": blockers,
            "undeclared_stems": undeclared, "delivery_needs": needs, "handoff_note": handoff_note,
            "inputs_sha256": _sha(_inputs(root, product)), "errors": [], "notice": NOTICE}


@_guard
def legacy_source_preview(root, pack, actor_id, *, profile_name=None, allowed_packs=None):
    """Reuse the canonical legacy resolver; only a names-only diff leaves the profile.

    Legacy fenced contracts need a coordinated migration. This prepares its
    exact engineering evidence, without bypassing the row editor's refusal.
    """
    import difflib
    import legacy_source_resolve as resolver
    scope = _scope(root, pack, actor_id, allowed_packs)
    base, product = scope[:2]
    contract = _safe(product / "handoff/FUNCTIONAL_CONTRACT.md")
    raw = _bytes(contract) if contract.is_file() else b""
    records = resolver.legacy_records(raw.decode("utf-8"))
    if len(records) > 500 or len({vid for vid, _ in records}) != len(records):
        raise Invalid("The older source declarations have repeated identifiers or exceed the review limit. Ask Engineering to reconcile the contract first.")
    digest = _sha(_inputs(base, product))
    result = {"ok": True, "errors": [], "count": len(records), "rows": [], "inputs_sha256": digest}
    if not profile_name or not records:
        return result
    _cfg, wanted = _identity(product)
    path, tables, identity, profile_digest = _profile(scope, profile_name, cut=wanted["cut"])
    index = resolver.column_index(tables)
    for variable, before in records:
        after, blockers = resolver.resolve(variable, before, index)
        diff = "".join(difflib.unified_diff((before + "\n").splitlines(True), ((after or before) + "\n").splitlines(True),
            fromfile="Current source declaration", tofile="Proposed source declaration"))
        result["rows"].append({"variable": variable, "before": before, "after": after,
                               "blockers": blockers, "diff": diff})
    if digest != _sha(_inputs(base, product)) or _sha(_bytes(path)) != profile_digest:
        raise Invalid("The contract or profile changed during this review. Prepare the current source proposal again.")
    result.update(profile_sha256=profile_digest, delivery=identity)
    return result


def legacy_handoff_note(result):
    """A bounded summary, never an apparently complete truncated migration."""
    import handoffs
    lines = ["Review the older source declarations together using the existing legacy source resolver and contract checks.",
             "Current product inputs SHA256: " + result["inputs_sha256"],
             "Completed profile SHA256: " + result["profile_sha256"]]
    rows = result["rows"]
    included = 0
    for row in rows:
        line = row["variable"] + ": " + (row["after"] or "; ".join(row["blockers"]))
        if len("\n".join([*lines, line])) > handoffs.MAX_TEXT - 160:
            break
        lines.append(line)
        included += 1
    if included < len(rows):
        lines.append(f"{len(rows) - included} additional declaration(s) omitted from this summary. Reopen the current source declarations and the profile matching the recorded SHA256 before migration.")
    return "\n".join(lines)


def _column_words(columns):
    """Column names as words; a placeholder column name (the template's, before anyone declared it)
    is counted as not declared yet rather than echoed."""
    named = [str(c) for c in (columns or []) if not _stem_unstated(c)]
    pending = len(columns or []) - len(named)
    words = ", ".join(named)
    if pending:
        words += (" and " if named else "") + f"{pending} column{'s' if pending > 1 else ''} not declared yet"
    return words


def _dashless(text):
    """The engine's own sentence with its dash punctuation made plain."""
    return str(text or "").replace(" — ", "; ").replace("—", ";").strip()


def availability_words(row):
    """(availability, reason) for one source role as a reader's words (walk RW4-N08). The engine
    marks a role nobody declared as '(default)' and explains an engine-guarded role with its own
    configuration key; the reader gets the state word and one sentence saying what the build does."""
    raw = str(row.get("availability") or "")
    default = "(default)" in raw
    state = raw.replace("(default)", "").strip()
    reason = _dashless(row.get("availability_reason"))
    engine_guarded = reason.lower().startswith("engine-guarded")
    if state == "optional":
        shown = "optional"
        why = ("Optional: the build continues without this table; When absent says what the definitions that read it then do."
               if engine_guarded or not reason else "Optional: " + reason)
    elif state == "unavailable_by_design":
        shown = "unavailable by design"
        why = "Declared unavailable: " + reason if reason else "Declared unavailable; the reason is not recorded yet."
    elif state == "required":
        shown = "required"
        if reason and not engine_guarded:
            why = "Required: " + reason
        elif default:
            why = "Required by default: nobody has declared this table optional or unavailable."
        else:
            why = "Required: the product declares that this table must be delivered."
    else:
        shown, why = state.replace("_", " "), reason
    return shown, why


def display_rows(rows):
    """The required-source rows as text cells: a list becomes comma-separated words, an absent
    value an empty cell (never a numeric placeholder) and an undeclared stem says so in words."""
    shown = []
    for row in rows:
        stem = row.get("physical_stem")
        availability, reason = availability_words(row)
        grain = str(row.get("expected_grain") or "").strip()
        shown.append({
            "Role": str(row.get("role") or ""),
            "Declared": "yes" if row.get("declared") else "no",
            "Delivered table": ("not declared yet" if _stem_unstated(stem) else str(stem)),
            "Availability": availability,
            "Availability reason": reason,
            "Decision": str(row.get("availability_decision") or ""),
            "Required columns": _column_words(row.get("required_columns")),
            "Optional columns": _column_words(row.get("optional_columns")),
            "Read by": ", ".join(str(c) for c in (row.get("read_by_blocks") or [])),
            "Required by": ", ".join(str(c) for c in (row.get("required_by_variables") or [])),
            "Mapping status": ", ".join(str(c) for c in (row.get("source_mapping_statuses") or [])),
            "Expected grain": "not declared yet" if grain in ("", "(not declared)") else grain,
            "When absent": _dashless(row.get("when_absent")),
        })
    return shown


FOLDER_UNSET = ("The restricted evidence folder is not set up on this computer; that is the data expert's one-time setup. "
                "Evidence files stay in that folder; this page never uploads raw data.")
FOLDER_INVALID = ("The restricted evidence folder must be an existing folder outside the checkout; "
                  "that is the data expert's one-time setup.")


def _restricted_base(root):
    """The restricted evidence folder, or a plain refusal. The folder's setting is the data
    expert's one-time setup on each computer; its name is never part of a person-facing sentence."""
    configured = os.environ.get("RWD_PROFILE_DIR")
    if not configured:
        raise Invalid(FOLDER_UNSET)
    base = _safe(Path(configured))
    if not base.is_dir() or base.is_relative_to(Path(root).resolve()):
        raise Invalid(FOLDER_INVALID)
    # Check Windows junction/reparse ancestors once at the restricted boundary;
    # individual discovered entries are checked without following them below.
    for part in (base, *base.parents):
        if getattr(part.lstat(), "st_file_attributes", 0) & stat.FILE_ATTRIBUTE_REPARSE_POINT:
            raise Invalid(FOLDER_INVALID)
    return base


def restricted_folder(root):
    """{"ok", "reason"}: whether evidence intake can work on this computer, without raising, so a
    page checks once and offers a handoff instead of a form that can only refuse."""
    try:
        _restricted_base(root)
    except (Invalid, OSError, ValueError) as error:
        return {"ok": False, "reason": str(error)}
    return {"ok": True, "reason": ""}


def _restricted(root, name, suffixes=(".tsv",)):
    base = _restricted_base(root)
    supplied = Path(str(name))
    path = _safe(supplied if supplied.is_absolute() else base / supplied)
    if not path.is_relative_to(base) or path == base or path.suffix.lower() not in suffixes:
        raise Invalid("Choose an allowed metadata file inside the restricted evidence folder.")
    for part in (path, *path.parents):
        if part == base:
            break
        if part.exists() and getattr(part.lstat(), "st_file_attributes", 0) & stat.FILE_ATTRIBUTE_REPARSE_POINT:
            raise Invalid("Choose an allowed metadata file inside the restricted evidence folder.")
    _bytes(path)
    return path


def _profile(scope, name, *, schema=None, cut=None, synthetic=False):
    root, product = scope[:2]
    route, _why = gates.evidence_route(str(root), scope[2])
    if route != "data_profile":
        raise Invalid("This product's declared evidence route does not authorize a data-profile workflow. Open its source-evidence requirements first.")
    path = _restricted(root, name)
    raw = _bytes(path)
    try:
        tables, cuts = profile_io.load(str(path))
    except (SystemExit, csv.Error, UnicodeError):
        raise Invalid("The profile failed the existing structural checks. Regenerate it with the current profiler; restricted cell contents were not copied.") from None
    # The drift renderer quotes unreadable aggregates. Keep arbitrary profile
    # text in the restricted file instead of echoing it into a saved finding.
    for columns in tables.values():
        for row in columns.values():
            for field in ("date_min", "date_max"):
                value = row.get(field)
                if value in (None, ""):
                    continue
                try:
                    if not isinstance(value, str) or not re.fullmatch(r"\d{4}-\d{2}-\d{2}", value):
                        raise ValueError
                    date.fromisoformat(value)
                except ValueError:
                    raise Invalid("The profile contains an unreadable date-range aggregate. Re-profile that column with the current profiler; restricted cell contents were not copied.") from None
    identity = profile_io.provenance(tables)
    _cfg, wanted = _identity(product)
    if identity["product_id"] != wanted["product_id"]:
        raise Invalid("The profile belongs to another product. Nothing was imported.")
    schemas = wanted["members"] or [wanted["schema"]]
    if identity["schema"] not in schemas or schema and identity["schema"] != schema:
        raise Invalid("The profile describes a different source schema or union member.")
    if cut is not None and identity["cut"] != cut:
        raise Invalid("The profile describes a different delivery cut.")
    if not identity["cut"] or cuts and cuts != {identity["cut"]}:
        raise Invalid("The profile's embedded cut and table suffixes disagree or are unstated.")
    if identity["mode"] != "full":
        raise Invalid("Use a full profile. Inventory-only and partial profiles cannot establish absence or temporal drift.")
    if identity["source_mode"] != "dbi" and not (synthetic and identity["source_mode"] == "local"):
        raise Invalid("Use the approved data runtime's profile; a synthetic profile cannot support a delivery claim.")
    if _sha(_bytes(path)) != _sha(raw):
        raise Invalid("The profile changed while it was being read. Select the completed file again.")
    return path, tables, identity, _sha(raw)


def _runtime_report(scope, record, name, kind):
    """One canonical report binding, shared by discovery and final intake."""
    import source_check
    path = _restricted(scope[0], name, (".json",))
    digest = _sha(_bytes(path))
    expected = record["payload"]["expected"]
    prefix = "schema_validation" if kind == "schema" else "preflight"
    try:
        actual = (source_check._schema_validation_fields(str(path)) if kind == "schema"
                  else source_check._preflight_fields(str(path)))
    except (SystemExit, AttributeError, TypeError, ValueError):
        raise Invalid("The schema or source-QC return failed the existing artifact checks. Regenerate it in the approved runtime; restricted field contents were not copied.") from None
    if actual[prefix + "_result"] not in {"passed_live", "failed_live"}:
        raise Invalid("Return the canonical passed_live or failed_live result from each runtime checker.")
    for field, target in (("product_id", "product_id"), ("schema", "schema"),
                          ("cut" if kind == "schema" else "refresh", "cut")):
        if actual[prefix + "_" + field] != expected[target]:
            raise Invalid("The returned " + prefix + " report describes a different product, source schema or cut.")
    if kind == "schema" and actual["schema_validation_config_sha256"] != expected["delivery_sha256"]:
        raise Invalid("The schema report describes a different delivery configuration digest.")
    if _sha(_bytes(path)) != digest or actual[prefix + "_sha256"] != digest:
        raise Invalid("A returned evidence file changed during checking. Receive the completed files again.")
    return path, actual, digest


def _evidence_files(base, suffix):
    """Bounded discovery; never follow links or echo rejected names/contents."""
    pending, paths, seen, size, truncated = [(base, 0)], [], 0, 0, False
    while pending and not truncated:
        directory, depth = pending.pop()
        try:
            with os.scandir(_safe(directory)) as entries:
                for entry in entries:
                    seen += 1
                    if seen > EVIDENCE_SCAN_ENTRIES:
                        truncated = True
                        break
                    try:
                        info = entry.stat(follow_symlinks=False)
                        if entry.is_symlink() or getattr(info, "st_file_attributes", 0) & stat.FILE_ATTRIBUTE_REPARSE_POINT:
                            continue
                        if entry.is_dir(follow_symlinks=False):
                            if depth < 3:
                                pending.append((Path(entry.path), depth + 1))
                            else:
                                truncated = True
                            continue
                        if not entry.is_file(follow_symlinks=False) or Path(entry.name).suffix.lower() != suffix:
                            continue
                        if info.st_size > LIMIT:
                            continue
                        if size + info.st_size > EVIDENCE_SCAN_BYTES:
                            truncated = True
                            break
                        paths.append(_safe(entry.path))
                        size += info.st_size
                    except (Invalid, OSError, ValueError):
                        continue
        except (Invalid, OSError, ValueError):
            # Permission loss or an inaccessible subdirectory is an incomplete
            # scan, never evidence that a delivery has no matching artifacts.
            truncated = True
    return sorted(paths), truncated


@_guard
def evidence_options(root, pack, actor_id, *, kind="profile", record_id=None,
                     previous=False, peer_name=None, allowed_packs=None):
    """Discover only metadata accepted by the existing delivery/request checks.

    This catalogue is for the local picker, not an AI context. No aggregates,
    arbitrary returned labels, rows, or rejected filenames leave the reader.
    Selection never receives evidence or saves a workflow record.
    """
    if kind not in {"profile", "schema", "source_qc", "counts"}:
        raise Invalid("Choose a profile, schema check, source quality check or counts return.")
    scope = _scope(root, pack, actor_id, allowed_packs)
    base = _restricted_base(scope[0])
    _cfg, wanted = _identity(scope[1])
    if (gates.unstated(wanted["product_id"]) or gates.unstated(wanted["cut"]) or
            not wanted["members"] and gates.unstated(wanted["schema"])):
        raise Invalid("Declare the source delivery first: choose the product identifier, source schema and delivery cut. Then this page can find evidence for that delivery.")
    record = None
    if record_id:
        record = _load(scope, record_id)
        _fresh(scope, record)
        if record["route"] != ("feasibility" if kind == "counts" else "source_evidence"):
            raise Invalid("Choose the evidence request for this step.")
    if kind != "profile" and record is None:
        raise Invalid("Save and select this delivery's request before choosing returned evidence.")
    expected = record["payload"]["expected"] if record and kind != "counts" else wanted
    schema = expected["schema"] if record else None
    if peer_name:
        _path, _tables, peer, _digest = _profile(scope, peer_name, cut=wanted["cut"])
        schema = peer["schema"]
    if kind in {"schema", "source_qc"}:
        profile = record["payload"].get("received", {}).get("profile")
        if not profile:
            raise Invalid("Receive and check the complete profile first. Then choose the schema and source quality results for that delivery.")
        _path, _tables, _identity_value, digest = _profile(scope, profile["path"], schema=expected["schema"], cut=expected["cut"])
        if digest != profile["sha256"]:
            raise Invalid("The received profile changed. Receive the current file before adding reports.")
    if kind == "counts" and record["state"] != "awaiting_runtime":
        raise Invalid("Choose an outstanding feasibility runtime request.")
    files, truncated = _evidence_files(base, ".tsv" if kind == "profile" else ".json")
    options = []
    for path in files:
        try:
            if kind == "profile":
                _path, _tables, identity, digest = _profile(scope, str(path), schema=schema, cut=None if previous else expected["cut"])
                if previous and identity["cut"] == wanted["cut"]:
                    continue
                label = f"{identity['schema']} · {identity['cut']} · Full profile"
            elif kind == "counts":
                _path, raw, _counts = _counts_result(scope, record, str(path))
                digest = _sha(raw)
                identity = {"schema": wanted["schema"], "cut": record["payload"]["identity"]["cut"]}
                label = f"{identity['cut']} · Counts for request {record['id'][:8]}"
            else:
                _path, actual, digest = _runtime_report(scope, record, str(path), kind)
                prefix = "schema_validation" if kind == "schema" else "preflight"
                outcome = "check passed" if actual[prefix + "_result"] == "passed_live" else "findings to review"
                identity = {"schema": expected["schema"], "cut": expected["cut"]}
                label = f"{identity['schema']} · {identity['cut']} · {outcome}"
            name = path.relative_to(base).as_posix()
            options.append({"name": name, "label": label + " · " + name, "sha256": digest,
                            "schema": identity.get("schema", ""), "cut": identity["cut"]})
        except (SystemExit, Invalid, OSError, ValueError, KeyError, TypeError, AttributeError):
            continue
    if record:
        _fresh(scope, record)
    next_step = {
        "profile": ("Ask Engineering to place the previous delivery's completed full profile in the restricted evidence folder. It must describe the same product and source member, with a different cut." if previous else
                    "Ask Engineering to complete the saved delivery request and place its completed full profile in the restricted evidence folder." if record else
                    "Use Prepare this delivery's evidence to save a request, then ask Engineering to place the completed full profile in the restricted evidence folder."),
        "schema": "Ask Engineering to return the live schema check from the saved delivery request to the restricted evidence folder.",
        "source_qc": "Ask Engineering to return the source quality check from the saved delivery request to the restricted evidence folder.",
        "counts": "Ask Engineering to run this saved feasibility request and place its counts-only return in the restricted evidence folder.",
    }[kind]
    return {"ok": True, "options": options, "truncated": truncated, "next_step": next_step,
            "inputs_sha256": _sha(_inputs(scope[0], scope[1])), "errors": []}


@_guard
def create_request(root, pack, actor_id, *, member=None, allowed_packs=None, local_demo=False, can_write=False):
    _authorized(local_demo, can_write)
    scope = _scope(root, pack, actor_id, allowed_packs)
    description = describe(root, pack, actor_id, allowed_packs=allowed_packs)
    if not description["ok"]:
        raise Invalid("; ".join(description["errors"]))
    if description["blockers"]:
        raise Invalid("; ".join(description["blockers"]))
    if description["evidence_route"] != "data_profile":
        raise Invalid("This product requires " + str(description["evidence_route"]) + ". Its policy does not authorize a profile request. Ask Engineering to implement the declared evidence adapter.")
    identity = description["identity"]
    schema = member or identity["schema"]
    if identity["members"] and schema not in identity["members"]:
        raise Invalid("Choose one declared union member; every member requires its own evidence.")
    if not identity["members"] and member not in (None, "", identity["schema"]):
        raise Invalid("This product does not declare that union member.")
    expected = {"product_id": identity["product_id"], "schema": schema, "cut": identity["cut"],
                "profile_mode": "full", "source_mode": "dbi", "evidence_route": description["evidence_route"],
                "delivery_sha256": gates.delivery_sha256(str(scope[1]))}
    sentences = runtime_sentences({"expected": expected})
    payload = {"summary": f"Awaiting source evidence for {schema} / {identity['cut']}",
               "expected": expected,
               "required_artifacts": ["profile_<cut>.tsv", "SCHEMA_VALIDATION.json", "source_qc.json"],
               # the sentences are what a person reads; the argument lists travel only in the
               # downloadable request, for the engineer who runs the approved environment
               "runtime_steps": [
                   {"runtime": "Approved data environment: profile", "sentence": sentences[0],
                    "argv": ["platform/tools/run_product_profile.py", pack,
                       "--cut", identity["cut"], "--member" if identity["members"] else "--schema", schema, "--out-dir", "<restricted output root>"]},
                   {"runtime": "Approved data environment: schema check", "sentence": sentences[1],
                    "argv": ["platform/tools/run_product_schema_check.py", pack,
                       "--cut", identity["cut"], "--member" if identity["members"] else "--schema", schema, "--out-dir", "<restricted output root>"]},
                   {"runtime": "Approved build preflight", "sentence": sentences[2],
                    "action": "Return the source quality check result for this delivery, including targeted grain, joins, duplicate and window checks."}],
               "received": {}}
    record = _new(scope, "source_evidence", "Source evidence request", "awaiting_runtime", payload)
    return {"ok": True, "record": record, "errors": [], "notice": NOTICE}


def runtime_sentences(payload):
    """The three runtime steps of an evidence request as sentences a person reads; derived from
    the request's own expected delivery, so a request saved before the sentences existed reads the same."""
    expected = (payload or {}).get("expected") or {}
    where = f"cut {expected.get('cut') or 'not declared'} of schema {expected.get('schema') or 'not declared'}"
    return [
        f"Profile the delivery for {where} in the approved data environment and return the full profile; Engineering runs this.",
        f"Check the live schema of that delivery ({where}) against this product's declared tables and return the schema check result; Engineering runs this.",
        "Return the source quality check result for the same delivery, covering record grain, joins, duplicates and timing windows; Engineering runs this.",
    ]


def engineering_note(pack, payload):
    """The words of a handoff to Engineering for one evidence request, ready for the person to edit."""
    expected = (payload or {}).get("expected") or {}
    return (f"Please run the three evidence steps for {pack}, cut {expected.get('cut') or 'not declared'} of schema "
            f"{expected.get('schema') or 'not declared'}: the full profile, the live schema check and the source quality check, "
            "and place the three result files in the restricted evidence folder. The exact request is downloadable from the delivery evidence page.")


def _plain(text):
    """The mapping tool's own words with its role spellings and dash punctuation made plain."""
    return (str(text or "").replace(" — ", ": ").replace("DataExpert/Engineering decision", "the data expert or Engineering decides")
            .replace("DataExpert", "the data expert"))


def gap_words(gap):
    """One mapping gap in a person's words: what the gap is, the tool's verdict, its why and the next
    action. The recommendation code stays in the record; it is never the title a person reads."""
    role = str(gap.get("role") or "")
    kind = str(gap.get("kind") or "")
    recommendation = str(gap.get("recommendation") or "")
    if kind == "undeclared":
        what = "this product reads it, but no delivered table is declared for it"
    elif kind == "declared_but_undelivered":
        what = f"declared as {gap.get('stem')}, which this delivery does not carry"
    else:
        what = "needs a mapping decision"
    why = str(gap.get("why") or "")
    # the verdict follows the tool's own reason for it; the tool's code word never becomes a title
    if recommendation == "map_candidate":
        verdict = f"Exactly one delivered table carries every required column ({gap.get('proposed')}); a person still applies it."
    elif recommendation == "do_not_map" and not gap.get("candidates"):
        verdict = "No delivered table supplies this role; the mapping is incomplete."
    elif recommendation == "do_not_map" and why.startswith("every candidate carries a blocker"):
        verdict = "Every candidate table carries a blocker, so no delivered table supplies this role as declared; the mapping is incomplete."
    elif recommendation == "do_not_map":
        verdict = "Several delivered tables could supply this role; choosing one is a person's decision, never this page's."
    else:
        verdict = recommendation.replace("_", " ")
    return {"role": role, "title": f"{role}: {what}", "verdict": verdict, "why": _plain(why),
            "next_action": _plain(gap.get("next_action")), "required_by": list(gap.get("required_by") or [])}


@_guard
def receive_profile(root, pack, actor_id, record_id, profile_name, *, allowed_packs=None, local_demo=False, can_write=False):
    _authorized(local_demo, can_write)
    scope = _scope(root, pack, actor_id, allowed_packs)
    record = _load(scope, record_id)
    _fresh(scope, record)
    if record["route"] != "source_evidence":
        raise Invalid("Choose a source evidence request.")
    payload = record["payload"]
    expected = payload["expected"]
    path, tables, identity, digest = _profile(scope, profile_name, schema=expected["schema"], cut=expected["cut"])
    previous = payload["received"].get("profile") or {}
    if previous.get("sha256") == digest:
        # the same bytes again (walk RW4-N05): the record keeps its state and its saved-report
        # links, nothing is written, and the answer says so
        return {"ok": True, "record": record, "changed": False, "message": PROFILE_UNCHANGED, "errors": [], "notice": NOTICE}
    received = {"path": str(path), "sha256": digest, "identity": identity,
                "table_count": len(tables), "column_count": sum(len(cols) for cols in tables.values())}
    payload["received"]["profile"] = received
    payload["summary"] = "Profile identity checked. Schema, source-QC and accountable review still required."
    if previous and (payload.get("source_report_preview") or record["state"] in REPORT_STATES):
        # a different profile after a report was prepared or saved: the record moves on as before,
        # and the earlier report is named out of date instead of left looking current
        payload["stale_report"] = REPORT_STALE
        payload["summary"] = REPORT_STALE
    record["state"] = "profile_received_for_review"
    record["updated_at"] = datetime.now(timezone.utc).isoformat()
    _write(scope[-1], record)
    return {"ok": True, "record": record, "errors": [], "notice": NOTICE}


@_guard
def mapping_options(root, pack, actor_id, profile_name, *, allowed_packs=None):
    scope = _scope(root, pack, actor_id, allowed_packs)
    _cfg, wanted = _identity(scope[1])
    path, tables, identity, digest = _profile(scope, profile_name, cut=wanted["cut"])
    proposal = mappings.proposal(str(scope[1]), str(path), top=None)
    skeleton = yaml.safe_load(adapters.skeleton(str(scope[1])))
    existing = scope[1] / "config/source_adapters.yaml"
    document = yaml.load(_bytes(existing), Loader=details._StrictLoader) if existing.is_file() else skeleton
    # tables the delivery carries that no declared stem or adapter names: listed, never mapped
    declared = set()
    for stem in (_cfg.raw.get("sources") or {}).values():
        stem = stem if isinstance(stem, str) else (stem or {}).get("table", "")
        if not _stem_unstated(stem):
            declared.add(str(stem).lower().split(".")[-1])
    for entry in (document.get("adapters") or []) if isinstance(document, dict) else []:
        stem = str((entry or {}).get("physical_table") or "")
        if not _stem_unstated(stem):
            declared.add(stem.lower().split(".")[-1])
    undeclared_delivered = sorted(table for table in tables
                                  if not any(table.lower() == stem or table.lower().startswith(stem + "_") for stem in declared))
    return {"ok": True, "proposal": proposal, "document": document, "skeleton": skeleton,
            "gap_words": [gap_words(gap) for gap in proposal.get("gaps", [])],
            "undeclared_delivered": undeclared_delivered,
            "identity": identity, "profile_sha256": digest, "inputs_sha256": _sha(_inputs(scope[0], scope[1])),
            "physical_tables": {table: (str(next(iter(cols.values()))["table"]) if "." in str(next(iter(cols.values()))["table"])
                                        else identity["schema"] + "." + str(next(iter(cols.values()))["table"]))
                                for table, cols in tables.items()},
            "tables": {table: [{"column": col, "type": str(row.get("type") or ""), "kind": str(row.get("kind") or "")}
                               for col, row in columns.items()] for table, columns in tables.items()}, "errors": []}


@_guard
def column_options(root, pack, actor_id, profile_name, role, table, *, allowed_packs=None):
    scope = _scope(root, pack, actor_id, allowed_packs)
    _cfg, wanted = _identity(scope[1])
    _path, tables, _identity_value, _digest_value = _profile(scope, profile_name, cut=wanted["cut"])
    skeleton = yaml.safe_load(adapters.skeleton(str(scope[1])))
    entry = next((item for item in skeleton["adapters"] if item["logical_role"] == role), None)
    if entry is None or table not in tables:
        raise Invalid("Choose a current logical role and a table present in this profile.")
    import propose_adapter
    suggestions = {}
    for logical in entry.get("required_columns") or {}:
        ranked = propose_adapter.candidates(logical, tables[table])
        tie = len(ranked) > 1 and ranked[0][1] == ranked[1][1]
        suggestions[logical] = {"tie": tie, "proposed": ranked[0][0] if ranked and not tie else None,
                                "candidates": [{"column": column, "score": score, "reasons": reasons}
                                               for column, score, reasons in ranked[:4]]}
    return {"ok": True, "columns": suggestions, "errors": []}


@_guard
def save_mapping_draft(root, pack, actor_id, profile_name, document, *, inputs_sha256, profile_sha256,
                       allowed_packs=None, local_demo=False, can_write=False):
    _authorized(local_demo, can_write)
    scope = _scope(root, pack, actor_id, allowed_packs)
    options = mapping_options(root, pack, actor_id, profile_name, allowed_packs=allowed_packs)
    if not options["ok"]:
        raise Invalid("; ".join(options["errors"]))
    if options["inputs_sha256"] != inputs_sha256 or options["profile_sha256"] != profile_sha256:
        raise Invalid("The source inputs changed. Reload the current profile and mapping choices.")
    if not isinstance(document, dict) or not isinstance(document.get("adapters"), list):
        raise Invalid("Keep the canonical adapter skeleton while recording unfinished choices.")
    candidate = copy.deepcopy(document)
    for entry in candidate["adapters"]:
        if not isinstance(entry, dict):
            raise Invalid("Each source role needs an adapter mapping.")
        entry["review"] = {"status": "pending", "approved_by": "TODO", "approval_date": "TODO", "approved_digest": "TODO"}
    record = _new(scope, "source_mapping", "Unfinished source mapping", "unfinished_draft",
                  {"document": candidate, "profile_path": str(_restricted(scope[0], profile_name)),
                   "profile_sha256": profile_sha256, "summary": "Unfinished source choices saved privately. Resume them, then validate the adapter diff before any product edit."})
    return {"ok": True, "record": record, "changed": False, "errors": [], "notice": NOTICE}


def _stage(scope, document):
    """Run the existing validators against a metadata-only product copy."""
    root, product = scope[:2]
    text = yaml.safe_dump(document, sort_keys=False, allow_unicode=True)
    with tempfile.TemporaryDirectory(prefix="source-adapter-check-") as directory:
        staged = Path(directory) / scope[2]
        for relative in _inputs(root, product):
            source = root / relative
            target = Path(directory) / relative
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes(_bytes(source))
        target = staged / "config/source_adapters.yaml"
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text(text, encoding="utf-8")
        checked = adapters.check(str(staged))
        cfg = load_config(str(staged / "config/data_product.yaml"))
        lint = config_problems(cfg, strict=False)
        strict = config_problems(cfg, strict=True)
    return text, {"adapter": checked, "configuration": lint, "strict_configuration": strict,
                  "passed": not checked["problems"] and not lint}


@_guard
def stage_adapter(root, pack, actor_id, profile_name, document, *, inputs_sha256, profile_sha256,
                  allowed_packs=None, local_demo=False, can_write=False, _validate_only=False):
    _authorized(local_demo, can_write)
    scope = _scope(root, pack, actor_id, allowed_packs)
    options = mapping_options(root, pack, actor_id, profile_name, allowed_packs=allowed_packs)
    if not options["ok"]:
        raise Invalid("; ".join(options["errors"]))
    if options["inputs_sha256"] != inputs_sha256 or options["profile_sha256"] != profile_sha256:
        raise Invalid("The mapping inputs changed. Reload suggestions before staging a proposal.")
    if not isinstance(document, dict) or set(document) - {"dataset", "schema", "cut", "adapters"}:
        raise Invalid("Only executed adapter fields are supported. Custom standard profiles need Engineering implementation.")
    candidate = copy.deepcopy(document)
    if candidate.get("schema") != options["identity"]["schema"] or candidate.get("cut") != options["identity"]["cut"]:
        raise Invalid("The adapter must name the profile's exact schema and cut.")
    if not isinstance(candidate.get("adapters"), list) or not candidate["adapters"]:
        raise Invalid("Complete the canonical adapter skeleton for the required roles.")
    allowed_roles = {item["logical_role"] for item in options["skeleton"]["adapters"]}
    incomplete = []
    for entry in candidate["adapters"]:
        if not isinstance(entry, dict) or entry.get("logical_role") not in allowed_roles:
            raise Invalid("An adapter names no existing source role.")
        if set(entry) - {"logical_role", "physical_table", "required_columns", "grain", "join", "review"}:
            raise Invalid("An adapter carries a field the runtime does not execute.")
        review = entry.get("review") or {}
        if review.get("status", "pending") != "pending" or any(not gates.unstated(review.get(key)) for key in ("approved_by", "approval_date", "approved_digest")):
            raise Invalid("This form saves pending adapter drafts only. Reviewed mappings require a separate accountable review.")
        entry["review"] = {"status": "pending", "approved_by": "TODO", "approval_date": "TODO", "approved_digest": "TODO"}
        physical = str(entry.get("physical_table") or "")
        matching = [table for table in options["tables"] if physical == options["physical_tables"][table]]
        if _stem_unstated(physical) or not matching:
            # a role this delivery cannot supply is a finding on the staged draft, not a refusal of
            # the rest: the diff and the validators still run for the mapped roles, and the draft
            # stays needs_changes (never applied) until the role is mapped or declared unavailable
            incomplete.append(f"{entry['logical_role']}: no delivered table supplies this role; the mapping is incomplete.")
            continue
        if len(matching) != 1:
            raise Invalid(f"{entry['logical_role']}: explicitly choose one table present in this profile.")
        columns = {row["column"].lower() for row in options["tables"][matching[0]]}
        required_columns = entry.get("required_columns")
        if not isinstance(required_columns, dict):
            raise Invalid("Each adapter needs explicit logical-to-physical column bindings.")
        canonical_entry = next(item for item in options["skeleton"]["adapters"] if item["logical_role"] == entry["logical_role"])
        if set(required_columns) - set(canonical_entry.get("required_columns") or {}):
            raise Invalid("A new logical input is outside this role's declared engine columns. Record an engineering handoff for it.")
        for name, binding in required_columns.items():
            if not isinstance(binding, dict) or str(binding.get("physical") or "").lower() not in columns:
                raise Invalid(f"{entry['logical_role']}.{name}: choose an actual column from the selected table.")
            if set(binding) - {"physical", "logical_type", "accepted_physical_types", "parser"}:
                raise Invalid("Only executed column fields can be saved in an adapter draft.")
            accepted = binding.get("accepted_physical_types")
            if not isinstance(accepted, list) or any(not isinstance(kind, str) or not re.fullmatch(r"[A-Za-z][A-Za-z0-9_.]{0,31}", kind) for kind in accepted):
                raise Invalid("Accepted physical types must be an explicit list of type names.")
    after, validation = _stage(scope, candidate)
    validation["incomplete"] = incomplete
    validation["passed"] = validation["passed"] and not incomplete
    target = scope[1] / "config/source_adapters.yaml"
    before = _bytes(target).decode() if target.is_file() else ""
    diff = "".join(difflib.unified_diff(before.splitlines(True), after.splitlines(True), fromfile="Before/source_adapters.yaml", tofile="Proposed/source_adapters.yaml"))
    if _validate_only:
        return {"ok": True, "after": after, "validation": validation, "errors": []}
    summary = ("Pending-review adapter diff; existing validators determine whether it can be saved." if not incomplete else
               f"Adapter draft staged with {len(incomplete)} role(s) this delivery cannot supply; the mapping is incomplete and cannot be saved until each is mapped or declared unavailable.")
    record = _new(scope, "source_mapping", "Source adapter proposal", "validated_draft" if validation["passed"] else "needs_changes",
                  {"summary": summary,
                   "document": candidate, "before_sha256": _sha(before.encode()), "after": after, "diff": diff,
                   "profile_path": str(_restricted(scope[0], profile_name)), "profile_sha256": profile_sha256,
                   "validation": validation})
    return {"ok": True, "record": record, "changed": False, "errors": [], "notice": NOTICE}


@_guard
def apply_adapter(root, pack, actor_id, record_id, *, allowed_packs=None, local_demo=False, can_write=False, confirmed=False):
    _authorized(local_demo, can_write)
    if confirmed is not True:
        raise Invalid("Review the before-and-after diff and explicitly confirm saving this pending adapter draft.")
    scope = _scope(root, pack, actor_id, allowed_packs)
    record = _load(scope, record_id)
    _fresh(scope, record)
    if record["route"] != "source_mapping" or record["state"] not in {"validated_draft", "needs_changes"}:
        raise Invalid("Choose an unapplied adapter proposal.")
    payload = record["payload"]
    if _sha(_bytes(_restricted(scope[0], payload["profile_path"]))) != payload["profile_sha256"]:
        raise Invalid("The profile changed after the proposal. Reopen its current evidence.")
    checked = stage_adapter(root, pack, actor_id, payload["profile_path"], payload["document"],
                            inputs_sha256=record["inputs_sha256"], profile_sha256=payload["profile_sha256"],
                            allowed_packs=allowed_packs, local_demo=local_demo, can_write=can_write, _validate_only=True)
    if not checked["ok"]:
        raise Invalid("; ".join(checked["errors"]))
    after, validation = checked["after"], checked["validation"]
    if not validation["passed"] or after != payload["after"]:
        raise Invalid("The existing adapter or configuration validator refuses this draft. Resolve its displayed findings before saving.")
    target = _safe(scope[1] / "config/source_adapters.yaml")
    before = _bytes(target) if target.is_file() else b""
    if _sha(before) != payload["before_sha256"]:
        raise Invalid("The adapter changed while the proposal was open. Reopen the current mapping.")
    _fresh(scope, record)
    with tempfile.NamedTemporaryFile(dir=target.parent, delete=False) as handle:
        handle.write(after.encode())
        temporary = Path(handle.name)
    try:
        if _sha(_bytes(target) if target.is_file() else b"") != payload["before_sha256"]:
            raise Invalid("Another edit changed the target before saving.")
        if _sha(_bytes(_restricted(scope[0], payload["profile_path"]))) != payload["profile_sha256"]:
            raise Invalid("The profile changed before the draft could be saved.")
        os.replace(temporary, target)
    finally:
        if temporary.exists():
            temporary.unlink()
    record["state"] = "saved_pending_review"
    record["updated_at"] = datetime.now(timezone.utc).isoformat()
    record["payload"]["summary"] = "Adapter draft saved with every review pending. Complete source review and rerun the workflow checks."
    record["payload"]["checked_inputs_sha256"] = record["inputs_sha256"]
    record["inputs_sha256"] = _sha(_inputs(scope[0], scope[1]))
    _write(scope[-1], record)
    return {"ok": True, "record": record, "changed": True, "errors": [], "notice": NOTICE}


@_guard
def receive_source_reports(root, pack, actor_id, record_id, schema_name, qc_name, *,
                           allowed_packs=None, local_demo=False, can_write=False, _validate_only=False):
    """Intake runtime-authored metadata without promoting it into a source review."""
    _authorized(local_demo, can_write)
    scope = _scope(root, pack, actor_id, allowed_packs)
    record = _load(scope, record_id)
    _fresh(scope, record)
    if record["route"] != "source_evidence":
        raise Invalid("Choose a source evidence request.")
    payload, expected = record["payload"], record["payload"]["expected"]
    profile = payload["received"].get("profile")
    if not profile:
        raise Invalid("Receive and check the complete profile first.")
    path, tables, _profile_identity, digest = _profile(scope, profile["path"], schema=expected["schema"], cut=expected["cut"])
    if digest != profile["sha256"]:
        raise Invalid("The received profile changed. Receive the current file before adding reports.")
    schema_path, schema, schema_sha = _runtime_report(scope, record, schema_name, "schema")
    qc_path, qc, qc_sha = _runtime_report(scope, record, qc_name, "source_qc")
    import source_check
    member = expected["schema"] if _identity(scope[1])[1]["members"] else None
    findings, counts = source_check.check(str(scope[1]), str(path), complete=True, union_member=member)
    # The canonical renderer carries machine facts plus any existing human block;
    # it generates no acceptance, approval, or new source-mapping verdict.
    report = source_check.render(str(scope[1]), str(path), findings, counts, True, member,
                                 str(schema_path), preflight=str(qc_path), tables=tables, cuts={expected["cut"]})
    if (_sha(_bytes(schema_path)) != schema_sha or _sha(_bytes(qc_path)) != qc_sha or
            _sha(_bytes(path)) != digest or schema["schema_validation_sha256"] != schema_sha or qc["preflight_sha256"] != qc_sha):
        raise Invalid("A returned evidence file changed during checking. Receive the completed files again.")
    _fresh(scope, record)
    target = _safe(scope[1] / gates.verdict_rel(member))
    if target.parent != scope[1] / "handoff":
        raise Invalid("The source report target must stay in this product's handoff folder.")
    before = _bytes(target) if target.is_file() else b""
    review_index = next((index for index, (report_member, _rel) in enumerate(gates.verdict_paths(str(scope[1]))) if report_member == member), None)
    if review_index is None:
        raise Invalid("The workflow verdict reader does not recognize this configured union member. Ask Engineering to reconcile its declaration before saving a report.")
    received = payload["received"]
    received["schema"] = {"path": str(schema_path), "sha256": schema["schema_validation_sha256"], "result": schema["schema_validation_result"]}
    received["source_qc"] = {"path": str(qc_path), "sha256": qc["preflight_sha256"], "result": qc["preflight_result"]}
    payload.pop("stale_report", None)  # a report regenerated from the current profile is current again
    payload.update({"source_report_preview": report, "source_counts": counts,
                    "source_report_target": target.relative_to(scope[1]).as_posix(), "source_report_before_sha256": _sha(before),
                    "source_review_action_id": "g3_confirm" + (f"_{review_index + 1}" if review_index else ""),
                    "source_report_diff": "".join(difflib.unified_diff(before.decode("utf-8").splitlines(True), report.splitlines(True),
                                                        fromfile="Current/" + target.name, tofile="Generated/" + target.name)),
                    "summary": "Matching artifacts received; canonical source-check preview prepared for accountable review."})
    record["state"] = "source_report_ready_for_review"
    record["updated_at"] = datetime.now(timezone.utc).isoformat()
    if not _validate_only:
        _write(scope[-1], record)
    return {"ok": True, "record": record, "errors": [], "notice": NOTICE}


@_guard
def save_source_report(root, pack, actor_id, record_id, *, confirmed=False, allowed_packs=None, local_demo=False, can_write=False):
    """Save only freshly regenerated verdicts, retaining pending human review."""
    _authorized(local_demo, can_write)
    if confirmed is not True:
        raise Invalid("Review the generated source-report diff and confirm the draft save.")
    scope = _scope(root, pack, actor_id, allowed_packs)
    record = _load(scope, record_id)
    _fresh(scope, record)
    if record["route"] != "source_evidence" or record["state"] != "source_report_ready_for_review":
        raise Invalid("Prepare a source report from the current matching artifacts first.")
    payload = record["payload"]
    checked = receive_source_reports(root, pack, actor_id, record_id,
                                    payload["received"]["schema"]["path"], payload["received"]["source_qc"]["path"],
                                    allowed_packs=allowed_packs, local_demo=local_demo, can_write=can_write, _validate_only=True)
    if not checked["ok"]:
        raise Invalid("; ".join(checked["errors"]))
    fresh = checked["record"]["payload"]
    if any(payload[key] != fresh[key] for key in ("source_report_preview", "source_report_target", "source_report_before_sha256")):
        raise Invalid("The generated report or its target changed. Receive the reports again to review the current diff.")
    target = _safe(scope[1] / fresh["source_report_target"])
    if target.parent != scope[1] / "handoff":
        raise Invalid("The source report target must stay in this product's handoff folder.")
    _fresh(scope, record)
    target.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.NamedTemporaryFile(dir=target.parent, delete=False) as handle:
        handle.write(fresh["source_report_preview"].encode("utf-8"))
        temporary = Path(handle.name)
    try:
        for evidence in fresh["received"].values():
            if _sha(_bytes(_restricted(scope[0], evidence["path"], (".tsv", ".json")))) != evidence["sha256"]:
                raise Invalid("A returned evidence file changed before saving the generated report.")
        if _sha(_bytes(target) if target.exists() else b"") != fresh["source_report_before_sha256"]:
            raise Invalid("Another edit changed the source report before saving.")
        os.replace(temporary, target)
    finally:
        if temporary.exists():
            temporary.unlink()
    record["state"] = "source_report_saved_pending_review"
    record["updated_at"] = datetime.now(timezone.utc).isoformat()
    payload["summary"] = "Generated source report saved with human review pending. Return to the workflow to review the mappings and run Check again."
    payload["checked_inputs_sha256"] = record["inputs_sha256"]
    record["inputs_sha256"] = _sha(_inputs(scope[0], scope[1]))
    _write(scope[-1], record)
    return {"ok": True, "record": record, "changed": True, "errors": [], "notice": NOTICE}


@_guard
def compare_profiles(root, pack, actor_id, old_name, new_name, *, allowed_packs=None, local_demo=False, can_write=False):
    _authorized(local_demo, can_write)
    scope = _scope(root, pack, actor_id, allowed_packs)
    old_path, _old, previous, old_sha = _profile(scope, old_name)
    _cfg, wanted = _identity(scope[1])
    new_path, _new_tables, current, new_sha = _profile(scope, new_name, schema=previous["schema"], cut=wanted["cut"])
    if previous["cut"] == current["cut"]:
        raise Invalid("Choose two different delivery cuts for a temporal drift comparison.")
    module_path = Path(__file__).resolve().parents[1] / "agent/ml/drift.py"
    spec = importlib.util.spec_from_file_location("portal_source_drift", module_path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    rows = [{"table": table, "column": column, "finding": finding, "next_check": check}
            for table, column, finding, check in module.compare(str(old_path), str(new_path))]
    if _sha(_bytes(old_path)) != old_sha or _sha(_bytes(new_path)) != new_sha:
        raise Invalid("One of the profiles changed during comparison. Reopen the completed files.")
    record = _new(scope, "delivery_drift", "Delivery drift comparison", "compared_for_review",
                  {"summary": f"{len(rows)} findings; {previous['cut']} to {current['cut']}. No comparability approval.",
                   "previous": previous, "current": current, "old_sha256": old_sha, "new_sha256": new_sha,
                   "findings": rows, "statistics": "Existing drift checker: top-value L1 distance, missingness delta and date-range shift."})
    return {"ok": True, "record": record, "errors": [], "notice": NOTICE}


@_guard
def feasibility_options(root, pack, actor_id, *, allowed_packs=None):
    scope = _scope(root, pack, actor_id, allowed_packs)
    import naming_registry
    import quick_counts
    from scientific_definition_naming import _scoped_registry_root
    with _scoped_registry_root(scope[0], {scope[2]}) as staged:
        registry = naming_registry.registry(str(staged))
    names, excluded = [], []
    for name, entry in sorted(registry.items()):
        if scope[2] not in (entry.get("packs") or {}) or not quick_counts.filter_column_ok(name)[0]:
            continue
        types = sorted(kind for kind, packs in (entry.get("types") or {}).items() if scope[2] in packs)
        row = {"name": name, "status": entry["packs"][scope[2]], "types": types}
        # only a category is an equality criterion, in both modes: a survival month or an age in
        # years is not a value a person types into a filter, and the existing counts tool refuses
        # the same variables when it groups a count
        if set(types) & quick_counts.CATEGORICAL_TYPES:
            names.append(row)
        else:
            excluded.append(row)
    return {"ok": True, "variables": names, "excluded": excluded, "errors": []}


def criterion_problem(criterion, names):
    """Why one criterion cannot be used, in the words the run refuses with; None when it can. The
    page asks this before adding a criterion, so a blank or identifier-like value is refused at once."""
    if not isinstance(criterion, dict) or set(criterion) != {"variable", "operator", "value"}:
        return "Each criterion needs a variable, = or !=, and one category value."
    name, operator, value = criterion["variable"], criterion["operator"], criterion["value"]
    if name not in names or operator not in {"=", "!="} or not isinstance(value, str) or not value.strip() or len(value) > 120:
        return "Use an existing variable, an equality operator and one nonempty category value."
    if not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9 _.+-]{0,30}", value) or re.search(r"\d{4,}", value):
        return "Use one short category label without long digit sequences; never an identifier or pasted data row."
    return None


@_guard
def run_feasibility(root, pack, actor_id, criteria, *, synthetic_rows=60, mode="synthetic", frame_sha256="",
                    grain="patient", allowed_packs=None, local_demo=False, can_write=False):
    _authorized(local_demo, can_write)
    scope = _scope(root, pack, actor_id, allowed_packs)
    import quick_counts
    options = feasibility_options(root, pack, actor_id, allowed_packs=allowed_packs)
    if not options["ok"]:
        raise Invalid("; ".join(options["errors"]))
    names = {entry["name"] for entry in options["variables"]}
    if not isinstance(criteria, list) or not criteria or len(criteria) > 20:
        raise Invalid("Add between one and twenty explicit criteria using this product's declared variables.")
    steps = []
    for index, criterion in enumerate(criteria):
        problem = criterion_problem(criterion, names)
        if problem:
            raise Invalid(problem)
        name, operator, value = criterion["variable"], criterion["operator"], criterion["value"]
        steps.append((f"Criterion {index + 1}: {name}", [(name, operator, value)]))
    _cfg, identity = _identity(scope[1])
    payload = {"criteria": criteria, "criteria_sha256": _sha(criteria), "identity": identity,
               "lane": "exploration", "summary": "Counts-only feasibility; no scientific or delivered-data evidence."}
    if mode == "runtime":
        if not re.fullmatch(r"[0-9a-f]{64}", frame_sha256) or grain not in quick_counts.GRAINS or gates.unstated(identity["cut"]):
            raise Invalid("A data-runtime request needs the exact approved frame digest (64 characters), the delivery cut and the patient or event grain.")
        types = {entry["name"]: set(entry["types"]) for entry in options["variables"]}
        if any(not types[item["variable"]] & quick_counts.CATEGORICAL_TYPES for item in criteria):
            raise Invalid("Runtime category criteria need an explicitly declared categorical type so the returned filter identity can be checked without exposing values.")
        payload.update({"frame_sha256": frame_sha256, "grain": grain,
                        "expected_return": {"lane": "exploration", "pack": pack, "cut": identity["cut"],
                                            "frame_sha256": frame_sha256, "criteria_sha256": _sha(criteria)},
                        "runtime_action": ("Ask Engineering to run the approved counts tool against this exact permitted frame with these "
                                           "criteria in this order, and to return the counts-only result together with this request's id "
                                           "and criteria digest. No dataset is read in the portal."),
                        "summary": "Awaiting approved data-runtime counts. No dataset was read in the portal."})
        state = "awaiting_runtime"
    elif mode == "synthetic":
        if isinstance(synthetic_rows, bool) or not isinstance(synthetic_rows, int) or not 11 <= synthetic_rows <= 10000:
            raise Invalid("Choose 11–10,000 synthetic rows.")
        rows = list(quick_counts.synthetic(synthetic_rows, {criterion["variable"] for criterion in criteria}))
        payload.update({"synthetic": True, "synthetic_rows": synthetic_rows, "counts": quick_counts.counts(rows),
                        "attrition": quick_counts.attrition(rows, steps),
                        "summary": "Synthetic counts rehearsal complete. Values v1/v2/v3 are generated examples, never patient data."})
        state = "synthetic_complete"
    else:
        raise Invalid("Choose a synthetic rehearsal or an approved-runtime request.")
    record = _new(scope, "feasibility", "Feasibility criteria and counts", state, payload)
    return {"ok": True, "record": record, "errors": [], "notice": NOTICE}


def _safe_count(value):
    import quick_counts
    return (isinstance(value, int) and not isinstance(value, bool) and value >= 0 and value % quick_counts.ROUND_TO == 0) or value == f"<{quick_counts.MIN_CELL}"


def _counts_result(scope, record, result_name):
    """Validate a counts return without storing it; reused by discovery and intake."""
    if record["route"] != "feasibility" or record["state"] != "awaiting_runtime":
        raise Invalid("Choose an outstanding feasibility runtime request.")
    path = _restricted(scope[0], result_name, (".json",))
    raw = _bytes(path)
    try:
        document = json.loads(raw)
    except (ValueError, RecursionError):
        raise Invalid("The counts return is unreadable. Ask Engineering to regenerate the completed counts-only result; restricted field contents were not copied.") from None
    if not isinstance(document, dict) or set(document) != {"request_id", "criteria_sha256", "result"} or document["request_id"] != record["id"]:
        raise Invalid("The counts return must wrap the canonical result with this exact request_id and criteria_sha256.")
    payload = record["payload"]
    if document["criteria_sha256"] != payload["criteria_sha256"]:
        raise Invalid("The returned counts use different criteria.")
    result = document["result"]
    if (not isinstance(result, dict) or any(not isinstance(result.get(key), dict) for key in ("identity", "asked", "counts"))
            or not isinstance(result.get("attrition"), list)
            or not isinstance(result["asked"].get("steps"), list)
            or any(not isinstance(item, dict) or not isinstance(item.get("where"), list)
                   or any(not isinstance(value, str) for value in item["where"]) for item in result["asked"]["steps"])):
        raise Invalid("The counts return has incomplete or unsupported fields. Ask Engineering to return the canonical counts-only result with its identity, ordered criteria and attrition table.")
    identity = result.get("identity") or {}
    if result.get("lane") != "exploration" or result.get("pack") != scope[2] or identity.get("pack") != scope[2]:
        raise Invalid("The return is not the existing exploration tool's result for this product.")
    if identity.get("frame_sha256") != payload["frame_sha256"] or identity.get("cut") != payload["identity"]["cut"] or identity.get("grain") != payload["grain"]:
        raise Invalid("The returned frame, cut or grain differs from the requested runtime input.")
    expected_steps = [[c["variable"] + c["operator"] + c["value"]] for c in payload["criteria"]]
    actual_steps = [(item or {}).get("where") for item in (result.get("asked") or {}).get("steps", [])]
    if _sha(actual_steps) != _sha(expected_steps) or (result.get("asked") or {}).get("where") or (result.get("asked") or {}).get("by"):
        raise Invalid("The canonical output's actual ordered filters differ from this request.")
    import quick_counts
    counts = result.get("counts") or {}
    attrition = result.get("attrition") or []
    if not _safe_count(counts.get("total")) or len(attrition) != len(payload["criteria"]) + 1 or any(
        not isinstance(item, dict) or not _safe_count(item.get("remaining")) or not _safe_count(item.get("dropped")) for item in attrition):
        raise Invalid("Return rounded/suppressed counts and all ordered attrition steps; row-level results are unsupported.")
    inconsistent = attrition[0]["dropped"] != 0
    # Patient grain has one row per person, so the unfiltered total and frame
    # attrition have the same meaning. Event totals count rows; attrition counts
    # distinct people, and those values must not be equated.
    if payload["grain"] == "patient" and counts["total"] != attrition[0]["remaining"]:
        inconsistent = True
    def count_bounds(value):
        # These bounds apply to attrition's distinct-person counts. The event
        # total may also be suppressed for too few distinct people, so it must
        # never be assigned these row-count bounds. Inclusive half-unit edges
        # conservatively cover the canonical rounding function's tie behavior.
        if value == 0:
            return 0, 0
        if isinstance(value, str):
            return 1, quick_counts.MIN_CELL - 1
        half_unit = quick_counts.ROUND_TO // 2
        return max(quick_counts.MIN_CELL, value - half_unit), value + half_unit
    possible_before = count_bounds(attrition[0]["remaining"])
    for previous, current in zip(attrition, attrition[1:]):
        before, remaining, dropped = previous["remaining"], current["remaining"], current["dropped"]
        if isinstance(before, int):
            inconsistent |= any(isinstance(value, int) and value > before for value in (remaining, dropped))
            inconsistent |= before == 0 and any(value != 0 for value in (remaining, dropped))
        else:
            inconsistent |= any(isinstance(value, int) and value > 0 for value in (remaining, dropped))
        # Retain only remaining-count values compatible with conservation:
        # before = remaining + dropped. This works when either value is
        # suppressed and propagates compatible bounds through later criteria;
        # it never invents or reveals an exact suppressed count.
        remaining_low, remaining_high = count_bounds(remaining)
        dropped_low, dropped_high = count_bounds(dropped)
        possible_before = (max(remaining_low, possible_before[0] - dropped_high),
                           min(remaining_high, possible_before[1] - dropped_low))
        inconsistent |= possible_before[0] > possible_before[1]
    if inconsistent:
        raise Invalid("The returned counts contain contradictory frame or attrition values even after allowing for rounding and suppression. Ask Engineering to regenerate the canonical result for this request.")
    # Copy only bounded numbers; free-form returned labels, rows and extra fields
    # are never rendered or retained as evidence.
    safe_result = {"total": counts["total"], "attrition": [
        {"step": "Frame" if index == 0 else f"Criterion {index}", "remaining": item["remaining"], "dropped": item["dropped"]}
        for index, item in enumerate(attrition)]}
    if _sha(_bytes(path)) != _sha(raw):
        raise Invalid("The counts result changed during intake. Receive the completed file again.")
    return path, raw, safe_result


@_guard
def receive_counts(root, pack, actor_id, record_id, result_name, *, allowed_packs=None, local_demo=False, can_write=False):
    _authorized(local_demo, can_write)
    scope = _scope(root, pack, actor_id, allowed_packs)
    record = _load(scope, record_id)
    _fresh(scope, record)
    _path, raw, safe_result = _counts_result(scope, record, result_name)
    _fresh(scope, record)
    payload = record["payload"]
    payload["returned_counts"] = safe_result
    payload["result_sha256"] = _sha(raw)
    payload["summary"] = "Returned counts match the request identity and criteria. Runtime authenticity and scientific validity are not established by file intake."
    record["state"] = "returned_counts_for_review"
    record["updated_at"] = datetime.now(timezone.utc).isoformat()
    _write(scope[-1], record)
    return {"ok": True, "record": record, "errors": [], "notice": NOTICE}
