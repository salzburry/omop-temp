"""Explicit AI explanations and options for one unsaved scientific answer."""
from __future__ import annotations

import hashlib
import json
from pathlib import Path
import uuid

import streamlit as st

import decision_answer_ai as assistant

PREFIX = "decision_answer_ai_"


def _clear_proposal(*, clear_widgets=True):
    for key in list(st.session_state):
        if key in (PREFIX + "proposal", PREFIX + "binding") or (clear_widgets and key.startswith(PREFIX + "selection_")):
            del st.session_state[key]


def _errors(result):
    for error in result.get("errors") or ["AI help could not complete safely. Your answer is unchanged."]:
        st.error(str(error))


def _clear_feedback():
    import interaction_feedback_page
    for suffix in ("accepted_feedback", "rejected_feedback"):
        interaction_feedback_page.clear(PREFIX + suffix)
    for suffix in ("feedback_context", "feedback_response", "feedback_accepted"):
        st.session_state.pop(PREFIX + suffix, None)


def offer_feedback(root, pack, actor_id, item, working_answer, *, expected_digest, can_write, allowed_packs):
    """Compare the actual draft against the exact text returned by accept()."""
    accepted = st.session_state.get(PREFIX + "feedback_accepted")
    scope = (str(Path(root).resolve()), pack, actor_id, item["id"], expected_digest, tuple(sorted(allowed_packs or [])))
    if not accepted or accepted.get("scope") != scope or not can_write:
        return
    if working_answer == accepted["answer"]:
        accepted["loaded"] = True
    elif accepted.get("loaded"):
        import interaction_feedback_page
        interaction_feedback_page.offer(root, pack, actor_id, route="questions", interaction_id=accepted["id"],
            request=accepted["request"], answer=accepted["answer"], revised_answer=working_answer,
            outcome="edited", can_write=can_write, allowed_packs=allowed_packs, key=PREFIX + "accepted_feedback")


def _rejected_feedback(root, pack, actor_id, *, can_write, allowed_packs):
    response = st.session_state.get(PREFIX + "feedback_response")
    if not response:
        return
    if not response.get("rejected") and st.button("This answer needs changes", key=PREFIX + "reject", disabled=not can_write):
        response["rejected"] = True
    if response.get("rejected"):
        import interaction_feedback_page
        interaction_feedback_page.offer(root, pack, actor_id, route="questions", interaction_id=response["id"],
            request=response["request"], answer=response["answer"], outcome="rejected", can_write=can_write,
            allowed_packs=allowed_packs, key=PREFIX + "rejected_feedback")


def render(root, pack, actor_id, item, working_answer, *, expected_digest, local_demo, can_write, allowed_packs):
    """Return copied draft text only; the caller updates its still-unsaved widget."""
    context = (str(Path(root).resolve()), pack, actor_id, item["id"], bool(local_demo), bool(can_write), tuple(sorted(allowed_packs or [])))
    if st.session_state.get(PREFIX + "context") != context:
        _clear_feedback()
        for key in list(st.session_state):
            if key.startswith(PREFIX):
                del st.session_state[key]
        st.session_state[PREFIX + "context"] = context
    available = assistant.describe_availability(root, pack, actor_id, item["id"], allowed_packs=allowed_packs)
    provider = available.get("provider") or "Not connected"
    model = available.get("model") or "No model connected"
    st.caption("AI can explain this question and suggest options to review. Your question, its evidence, current draft and relevant AI-approved specification context within your access scope are sent only when you request help.")
    if not available.get("ok", True):
        _clear_feedback()
        _clear_proposal()
        _errors(available)
        return None
    if not available.get("source_eligible"):
        _clear_feedback()
        _clear_proposal()
        st.info(available.get("blocker") or "Complete the recorded source-access review before requesting AI help.")
        import connected_workflow_page
        connected_workflow_page.links(("progress",), pack, actor_id, key="decision_ai_source",
            label="Complete the source review in product progress", expanded=True)
        return None
    if not available.get("configured"):
        _clear_feedback()
        _clear_proposal()
        st.info("Open Assistant connection in the sidebar and select your connection. "
                "It is shared by question answers, scientific rows, the product guide and specialist requests. "
                "Return here and explicitly request help; your current answer is kept.")
        st.info(available.get("help") or "Connect a supported model in VS Code with RWD Portal: Connect Chat Model, then return here. You can keep drafting manually.")
        return None
    st.caption(f"Provider: {provider} · Model: {model}")
    if available.get("quota_note"):
        st.caption(available["quota_note"])
    permitted = local_demo and can_write and item.get("editable")
    stale = available.get("digest") is not None and available["digest"] != expected_digest
    if stale:
        _clear_feedback()
        _clear_proposal()
        st.warning("This question or its evidence changed. Reload the current questions while keeping your draft before asking for AI help.")
    if not permitted:
        _clear_feedback()
        _clear_proposal()
        st.info("AI drafting is available for open questions with local editing access.")
    feedback_context = hashlib.sha256(json.dumps({"context": context, "digest": expected_digest,
        "connection": available.get("connection_id"), "provider": available.get("provider_id"), "model": model,
        "skill": available.get("workflow_skill_digest")}, sort_keys=True, ensure_ascii=False).encode()).hexdigest()
    if st.session_state.get(PREFIX + "feedback_context") != feedback_context:
        _clear_feedback()
        st.session_state[PREFIX + "feedback_context"] = feedback_context
    binding = hashlib.sha256(json.dumps({"context": context, "digest": expected_digest, "answer": working_answer,
        "connection": available.get("connection_id"), "provider": available.get("provider_id"), "model": model},
        sort_keys=True, ensure_ascii=False).encode()).hexdigest()
    if st.session_state.get(PREFIX + "binding") not in (None, binding):
        _clear_proposal()
        st.info("Your answer, evidence or model connection changed. Request fresh options before copying one.")
    request = st.text_area("What should AI help explain? (optional)", max_chars=1200, key=PREFIX + "request",
        help="Example: Explain the alternatives in this question, identify what each would change, and list evidence that is still missing.",
        disabled=not permitted or stale)
    if st.button("Explain and suggest answers", key=PREFIX + "generate", disabled=not permitted or stale):
        previous = st.session_state.get(PREFIX + "proposal")
        with st.spinner("Preparing options for this question…"):
            result = assistant.suggest(root, pack, actor_id, item["id"], working_answer,
                expected_digest=expected_digest, user_request=request, local_demo=local_demo,
                can_write=can_write, allowed_packs=allowed_packs, previous_proposal=previous)
        if result.get("ok"):
            response_text = "\n\n".join([result["proposal"]["explanation"],
                *[option["label"] + ": " + option["answer"] for option in result["proposal"]["options"]]])
            st.session_state[PREFIX + "feedback_response"] = {"id": uuid.uuid4().hex,
                "request": request or "Explain the selected scientific question and suggest draft options.", "answer": response_text}
            _clear_proposal()
            st.session_state[PREFIX + "proposal"] = result["proposal"]
            st.session_state[PREFIX + "binding"] = binding
            st.session_state[PREFIX + "generation"] = st.session_state.get(PREFIX + "generation", 0) + 1
        else:
            _errors(result)
    if permitted and not stale:
        _rejected_feedback(root, pack, actor_id, can_write=can_write, allowed_packs=allowed_packs)
    proposal = st.session_state.get(PREFIX + "proposal")
    if not proposal or not permitted or stale:
        return None
    st.text(proposal["explanation"])
    from scientific_definition_ai_page import _scientific_context
    _scientific_context(proposal)
    window = proposal.get("conversation_window") or {}
    if window.get("omitted_turns"):
        st.caption(f"This answer used {window.get('included_turns', 0)} discussion turns; {window['omitted_turns']} earlier turns were outside its context window.")
    st.info("These options are unreviewed. Quoted question or evidence text is context, not independent proof. Copying an option keeps TODO visible and changes only your unsaved answer.")
    sources = {source["id"]: source for source in proposal.get("sources", [])}
    options = {option["id"]: option for option in proposal["options"]}
    for option in options.values():
        st.text(option["label"])
        st.caption("Proposed draft answer")
        st.text(option["answer"])
        st.caption("References supplied for this question")
        if not option.get("support"):
            st.warning("No source quotation supports this option. Its assumptions and open questions need review.")
        for support in option.get("support", []):
            source = sources.get(support["source_id"], {})
            st.text(f"{source.get('label', support['source_id'])} [{support['source_id']}]\n{support['quote']}")
        st.caption("Assumptions to review")
        for assumption in option.get("assumptions") or ["None listed; check the proposed interpretation against the evidence."]:
            st.text(assumption)
        st.caption("Questions still open")
        for question in option.get("questions") or ["None listed; confirm whether other scientific questions remain."]:
            st.text(question)
    chosen = st.radio("Option to copy into my draft", list(options), index=None,
        format_func=lambda option_id: options[option_id]["label"],
        key=PREFIX + "selection_" + str(st.session_state.get(PREFIX + "generation", 0)))
    if st.button("Copy selected option into my draft answer", key=PREFIX + "copy", disabled=chosen is None):
        result = assistant.accept(root, pack, actor_id, item["id"], working_answer, proposal, chosen,
            expected_digest=expected_digest, local_demo=local_demo, can_write=can_write, allowed_packs=allowed_packs)
        if result.get("ok"):
            response = st.session_state.get(PREFIX + "feedback_response") or {}
            st.session_state[PREFIX + "feedback_accepted"] = {"id": response.get("id") or uuid.uuid4().hex,
                "request": response.get("request") or "Suggest a draft answer for the selected scientific question.",
                "answer": result["answer"], "loaded": False,
                "scope": (str(Path(root).resolve()), pack, actor_id, item["id"], expected_digest, tuple(sorted(allowed_packs or [])))}
            # This radio is still in the current widget tree. Let the next run
            # retire it instead of deleting state after the widget was rendered.
            _clear_proposal(clear_widgets=False)
            st.success("Option copied into your unsaved draft. Review and edit it below. No decision maker, date or saved decision was changed.")
            return result["answer"]
        _errors(result)
    return None
