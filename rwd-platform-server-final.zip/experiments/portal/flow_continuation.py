"""Open an explicitly requested current Flow action without changing gate order.

Blocker cards describe the first unfinished gate. They are not the complete action
catalogue. Connected workspaces can open later review forms while their owning
validators and permission checks still decide whether an act may be performed.
"""
from __future__ import annotations

import copy
from pathlib import Path

import flow
import specification_details

PREFIX = "requested:"


def resolve(root, pack, actor_id, action_id, *, allowed_packs, can_view):
    """Return a fresh canonical card; never accept an action body or execute it."""
    try:
        if can_view is not True:
            raise ValueError("You no longer have access to this product's workflow.")
        if not isinstance(actor_id, str) or not actor_id.strip() or len(actor_id) > 200:
            raise ValueError("An identified portal session is required.")
        if not isinstance(action_id, str) or not action_id or len(action_id) > 160:
            raise ValueError("Choose a workflow action from the current product.")
        source, pack = specification_details._paths(root, pack, allowed_packs)
        root, product = Path(root).resolve(), source.parent
        # The catalogue reads these metadata paths to decide which acts exist.
        # Do not let merely opening an action follow a redirected product record.
        for name in ("handoff", "config", "spec_pipeline"):
            directory = product / name
            if directory.resolve() != directory:
                raise ValueError("A workflow record redirects elsewhere. Ask the data expert to repair the product's canonical path.")
            if directory.is_dir():
                for path in directory.rglob("*"):
                    if path.resolve() != path:
                        raise ValueError("A workflow record redirects elsewhere. Ask the data expert to repair the product's canonical path.")
        match = next(((gate, action) for gate, actions in flow.acts(pack, str(root)).items()
                      for action in actions if action.get("id") == action_id), None)
        if match is None:
            raise ValueError("This action is no longer available for this product. Check its current progress and choose the next recorded action.")
        gate, original = match
        action = copy.deepcopy(original)
        card = {"text": "Requested workflow action: " + action["label"],
                "owner": flow.status.OWNER[gate], "held_by": gate,
                "requested": True, "fixes": [action]}
        return {"ok": True, "key": PREFIX + action_id, "card": card, "action": action,
                "pack": pack, "actor": actor_id, "errors": []}
    except (OSError, ValueError, TypeError, KeyError, AttributeError, specification_details._Invalid) as error:
        return {"ok": False, "errors": [str(error)]}
