"""Explicit name/email profiles for a portable development demonstration."""
from __future__ import annotations

from pathlib import Path

import streamlit as st

import identity


def render(path, users, *, enabled=False):
    if not enabled:
        return
    chosen = st.session_state.get("who")
    saved = Path(path).exists()
    current = next((user for user in users if saved and user.get("name") == chosen), {})
    if not current and saved and users:
        current = users[0]
    context = (current.get("name", ""), current.get("email", ""))
    if st.session_state.get("_development_profile_context") != context:
        st.session_state["_development_profile_context"] = context
        st.session_state["development_profile_name"] = context[0]
        st.session_state["development_profile_email"] = context[1]
    with st.sidebar.expander("Development profile", expanded=not bool(current.get("email"))):
        st.caption("Use a name and email for this demo. The selected profile owns its chat and review entries.")
        with st.form("development_profile_form"):
            name = st.text_input("Name", key="development_profile_name")
            email = st.text_input("Email", key="development_profile_email")
            save = st.form_submit_button("Save and use profile")
        if save:
            try:
                # The first real profile replaces the unsaved bootstrap picker entry.
                roster = users if Path(path).exists() else []
                updated = identity.development_profile(roster, name, email)
                identity.save_users(str(path), updated)
            except (ValueError, OSError) as exc:
                st.error(f"Profile not saved. {exc}")
            else:
                selected = next(user for user in updated if user["name"].casefold() == name.strip().casefold())
                st.session_state["who"] = selected["name"]
                st.rerun()
