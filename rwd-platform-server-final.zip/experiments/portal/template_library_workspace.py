"""A checked template-library candidate and a separate explicit steward act.

Canonical readers run separately against the selected checkout so that immutable
Git provenance and semantic-approval digests retain their actual subjects.
Preparation and sharing write no library entries. An authorized steward can
apply exact reviewed bytes as a new version; commit/signature remain their act.
"""
from __future__ import annotations

from datetime import datetime, timezone
import difflib
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import tempfile
import uuid

import yaml

_WORKER_REQUEST = None
if __name__ == "__main__" and "--worker" in sys.argv:
    _WORKER_REQUEST = json.loads(sys.stdin.read())
    _worker_root = Path(_WORKER_REQUEST["root"]).resolve()
    sys.path[:0] = [str(_worker_root / "platform/tools"), str(_worker_root / "platform")]

import science_workspace as science
import source_workspace as storage
import handoffs

ROUTE = "template_library"
ACTION_PREFIX = "template-review:"
NOTICE = "Candidate for review only. No shared library entry, template adoption, approval or product release is created."
RELEASES = "governance/reference/template_releases"
LIMIT = 2 * 1024 * 1024
ERRORS = (OSError, ValueError, TypeError, KeyError, AttributeError, yaml.YAMLError, subprocess.TimeoutExpired)


def _fail(error):
    return {"ok": False, "errors": [str(error)], "notice": NOTICE}


def _scope(root, pack, actor_id, allowed_packs):
    base, product, pack, owner, folder = storage._scope(root, pack, actor_id, allowed_packs)
    return base, product, pack, owner, science._safe(folder / "template-library")


def _allowed(root, pack, allowed_packs):
    import design_workspace as design
    scope = {pack} if allowed_packs is None else set(allowed_packs)
    for name in scope:
        design._pack_path(root, name, scope)
    return sorted(scope)


def _git(root, *args):
    result = subprocess.run(["git", "-C", str(root), *args], capture_output=True, text=True,
                            encoding="utf-8", errors="replace", timeout=10)
    return result.stdout.strip() if result.returncode == 0 else None


def _inputs(root, scope):
    # Hash actual bytes, including the unfiltered semantic registers. Filtering a
    # register before hashing would silently change a signed approval's subject.
    files = science._inputs(root, set(scope))
    hashes = {}
    for name in files:
        path = science._safe(root / name)
        if path.is_file():
            hashes[name] = science._hash(path.read_bytes())
    return {"files": hashes, "head": _git(root, "rev-parse", "HEAD")}


def _source_digest(root, pack):
    # Committing/installing a release is expected to move HEAD and the library
    # index. Neither edits the source meaning that the reviewer examined.
    files = _inputs(root, [pack])["files"]
    return science._hash({name: digest for name, digest in files.items() if not name.startswith(RELEASES + "/")})


def _run(root, pack, scope, operation="describe", values=None):
    payload = {"root": str(root), "pack": pack, "scope": scope,
               "operation": operation, "values": values or {}}
    result = subprocess.run([sys.executable, str(Path(__file__).resolve()), "--worker"],
        input=json.dumps(payload), capture_output=True, text=True, encoding="utf-8", errors="replace",
        cwd=root, timeout=90, env={**os.environ, "PYTHONUTF8": "1", "PYTHONDONTWRITEBYTECODE": "1"})
    if result.returncode or len(result.stdout.encode()) > LIMIT:
        raise ValueError("The canonical template checker could not finish a bounded report. Ask Engineering to inspect the local template checks.")
    try:
        return json.loads(result.stdout)
    except json.JSONDecodeError as error:
        raise ValueError("The template checker did not return a readable report.") from error


def describe(root, pack, actor_id, *, allowed_packs=None):
    try:
        base, _product, pack, _owner, _folder = _scope(root, pack, actor_id, allowed_packs)
        scope = _allowed(base, pack, allowed_packs)
        inputs = _inputs(base, scope)
        report = _run(base, pack, scope)
        if report.get("errors"):
            raise ValueError("; ".join(report["errors"]))
        if _inputs(base, scope) != inputs:
            raise ValueError("Evidence changed during the library check. Check the current evidence again.")
        return {"ok": True, "pack": pack, "input_digest": science._hash(inputs), "errors": [], "notice": NOTICE, **report}
    except ERRORS as error:
        return _fail(error)


def _record_path(folder, identifier):
    if not re.fullmatch(r"[0-9a-f]{32}", str(identifier)):
        raise ValueError("Choose a saved library candidate from this product.")
    return science._safe(folder / (identifier + ".json"))


def _read(path):
    if science._safe(path).stat().st_size > LIMIT:
        raise ValueError("This candidate exceeds the review metadata limit.")
    doc = json.loads(path.read_bytes())
    unsigned = dict(doc)
    digest = unsigned.pop("sha256", None)
    if digest != science._hash(unsigned):
        raise ValueError("The saved candidate changed after validation. Prepare a fresh candidate.")
    return doc


def _write_new(path, doc):
    raw = json.dumps(doc, ensure_ascii=False, indent=2).encode()
    if len(raw) > LIMIT:
        raise ValueError("This candidate exceeds the review metadata limit.")
    science._safe(path.parent).mkdir(parents=True, exist_ok=True)
    created = False
    try:
        with science._safe(path).open("xb") as handle:
            created = True
            handle.write(raw)
    except BaseException:
        if created and path.exists():
            path.unlink()
        raise


def stage(root, pack, actor_id, *, values, expected_digest, allowed_packs=None, local_demo=False, can_write=False):
    try:
        storage._authorized(local_demo, can_write)
        base, _product, pack, owner, folder = _scope(root, pack, actor_id, allowed_packs)
        scope = _allowed(base, pack, allowed_packs)
        if not isinstance(values, dict) or set(values) != {"template_id", "version", "reviewed_by", "date", "reason"}:
            raise ValueError("Supply only the displayed candidate identity, actual review attribution and review note.")
        if any(not isinstance(value, str) or not value.strip() or len(value) > 2000 for value in values.values()):
            raise ValueError("Complete the candidate fields. Record actual review attribution; do not invent a reviewer or date.")
        inputs = _inputs(base, scope)
        if science._hash(inputs) != expected_digest:
            raise ValueError("The source evidence or checkout revision changed. Check readiness again before preparing a candidate.")
        checked = _run(base, pack, scope, "candidate", values)
        if checked.get("blockers"):
            return {"ok": False, "errors": checked["blockers"], "notice": NOTICE}
        if _inputs(base, scope) != inputs:
            raise ValueError("Evidence changed during candidate validation. Nothing was saved; check readiness again.")
        record = {"id": uuid.uuid4().hex, "root": str(base), "pack": pack, "owner": owner,
                  "scope": scope, "route": ROUTE, "created_at": datetime.now(timezone.utc).isoformat(),
                  "input_digest": expected_digest, "values": values, "checked": checked,
                  "draft_only": True, "approval_created": False, "notice": NOTICE}
        record["sha256"] = science._hash(record)
        _write_new(_record_path(folder, record["id"]), record)
        return {"ok": True, "record": record, "changed": True, "errors": [], "notice": NOTICE}
    except ERRORS as error:
        return _fail(error)


def read(root, pack, actor_id, proposal_id, *, allowed_packs=None):
    try:
        base, _product, pack, owner, folder = _scope(root, pack, actor_id, allowed_packs)
        scope = _allowed(base, pack, allowed_packs)
        record = _read(_record_path(folder, proposal_id))
        if (record.get("owner") != owner or record.get("pack") != pack or record.get("root") != str(base)
                or record.get("route") != ROUTE or record.get("id") != proposal_id
                or record.get("draft_only") is not True or record.get("approval_created") is not False
                or not set(record.get("scope") or []).issubset(scope)):
            raise ValueError("This saved candidate belongs to another product, identity or access scope.")
        stale = science._hash(_inputs(base, record["scope"])) != record["input_digest"]
        requests = [row for row in handoffs.listing(base, pack, allowed_packs=scope)
                    if str(row.get("action_id") or "").startswith(ACTION_PREFIX + proposal_id + ":")]
        requests.sort(key=lambda row: (str(row.get("action_id") or "").endswith(":apply"), str(row.get("requested_at") or "")), reverse=True)
        return {"ok": True, "record": record, "stale": stale,
                "review_id": requests[0]["id"] if requests else None, "errors": []}
    except ERRORS as error:
        return _fail(error)


def recent(root, pack, actor_id, *, allowed_packs=None):
    try:
        folder = _scope(root, pack, actor_id, allowed_packs)[-1]
        rows = []
        for path in folder.glob("*.json"):
            result = read(root, pack, actor_id, path.stem, allowed_packs=allowed_packs)
            if result["ok"]:
                doc = result["record"]
                rows.append({"id": doc["id"], "route": ROUTE, "title": "Template candidate " + doc["values"]["template_id"],
                             "state": "continue shared review and integration" if result.get("review_id") else ("needs a fresh check" if result["stale"] else "candidate for review"),
                             "summary": NOTICE, "params": {"review_id": result["review_id"]} if result.get("review_id") else {"proposal_id": doc["id"]}, "updated_at": doc["created_at"]})
        return sorted(rows, key=lambda row: row["updated_at"], reverse=True)[:40]
    except ERRORS:
        return []


def share(root, pack, actor_id, proposal_id, *, expected_digest, note, owner="Reviewer", allowed_packs=None,
          local_demo=False, can_write=False):
    try:
        storage._authorized(local_demo, can_write)
        if owner not in {"Science", "Reviewer", "Engineering", "Administrator"}:
            raise ValueError("Choose Science, Reviewer, Engineering or Administrator for the library review.")
        note = handoffs._text(note, "the library review request")
        current = read(root, pack, actor_id, proposal_id, allowed_packs=allowed_packs)
        if not current["ok"]:
            return current
        record = current["record"]
        if current["stale"] or expected_digest != record["sha256"]:
            raise ValueError("The candidate or its evidence changed. Prepare a fresh candidate before sharing it.")
        base, product, pack, _owner, _folder = _scope(root, pack, actor_id, allowed_packs)
        checked = _run(base, pack, record["scope"], "candidate", record["values"])
        if checked != record["checked"] or science._hash(_inputs(base, record["scope"])) != record["input_digest"]:
            raise ValueError("Canonical validation changed. Nothing was shared; prepare a fresh candidate.")
        # Publish exactly this selection. Private inputs, actor folder and other drafts are omitted.
        public = {key: record[key] for key in ("id", "root", "pack", "route", "created_at", "values", "checked", "draft_only", "approval_created", "notice")}
        public["source_digest"] = _source_digest(base, pack)
        public["sha256"] = science._hash(public)
        if science._hash(_inputs(base, record["scope"])) != record["input_digest"]:
            raise ValueError("Source evidence changed while the review snapshot was being prepared. Nothing was shared; check a fresh candidate.")
        path = _record_path(science._safe(product / ".portal-drafts/template-reviews"), proposal_id)
        created = not path.exists()
        if created:
            _write_new(path, public)
        elif _read(path) != public:
            raise ValueError("This candidate was already shared with different evidence. Prepare a new candidate.")
        action = ACTION_PREFIX + proposal_id + ":" + public["sha256"]
        try:
            request = handoffs.create(base, pack, title="Review template candidate: " + record["values"]["template_id"],
                owner=owner, note=f"{note} Exact candidate {proposal_id}; digest {public['sha256']}. {NOTICE}",
                requested_by=actor_id, action_id=action, allowed_packs=allowed_packs, local_demo=True, can_view=True)
        except (handoffs.Refused, OSError, ValueError):
            matches = [row for row in handoffs.listing(base, pack, allowed_packs=allowed_packs, include_closed=False)
                       if row.get("action_id") == action]
            if matches:
                return {"ok": True, "handoff": matches[0], "already_shared": True, "errors": []}
            if created and path.exists() and _read(path) == public:
                path.unlink()
            raise
        return {"ok": True, "handoff": request, "errors": []}
    except ERRORS as error:
        return _fail(error)


def shared(root, pack, handoff_id, *, allowed_packs=None):
    try:
        request = handoffs.load(root, pack, handoff_id, allowed_packs=allowed_packs)
        match = re.fullmatch(re.escape(ACTION_PREFIX) + r"([0-9a-f]{32}):([0-9a-f]{64})(?::apply)?", request.get("action_id", ""))
        if not match:
            raise ValueError("This request does not identify a template candidate.")
        product, pack = handoffs._pack_dir(root, pack, allowed_packs)
        public = _read(_record_path(science._safe(product / ".portal-drafts/template-reviews"), match[1]))
        if (public["sha256"] != match[2] or public.get("pack") != pack or public.get("id") != match[1]
                or public.get("root") != str(Path(root).resolve()) or public.get("route") != ROUTE
                or public.get("draft_only") is not True or public.get("approval_created") is not False):
            raise ValueError("The review request does not match its exact template candidate.")
        return {"ok": True, "record": public, "errors": [],
                "stale": public["source_digest"] != _source_digest(Path(root).resolve(), pack)}
    except ERRORS as error:
        return _fail(error)


def integration(root, pack, handoff_id, *, allowed_packs=None):
    try:
        result = shared(root, pack, handoff_id, allowed_packs=allowed_packs)
        if not result["ok"]:
            return result
        record = result["record"]
        base = Path(root).resolve()
        scope = _allowed(base, pack, allowed_packs)
        before = _inputs(base, scope)
        checked = _run(base, pack, scope, "integration", {"candidate": record["checked"]["candidate"], "yaml": record["checked"]["yaml"]})
        if _inputs(base, scope) != before:
            raise ValueError("Library evidence changed during the integration check. Check again.")
        return {"ok": True, "record": record, "stale": result["stale"], "errors": [], **checked}
    except ERRORS as error:
        return _fail(error)


def request_application(root, pack, actor_id, handoff_id, *, note, allowed_packs=None, local_demo=False, can_review=False):
    try:
        if local_demo is not True or can_review is not True:
            raise ValueError("An authorized local reviewer requests the library administrator's next step.")
        result = shared(root, pack, handoff_id, allowed_packs=allowed_packs)
        if not result["ok"]:
            return result
        doc = result["record"]
        note = handoffs._text(note, "the administrator's review and application request")
        action = ACTION_PREFIX + doc["id"] + ":" + doc["sha256"] + ":apply"
        existing = [row for row in handoffs.listing(root, pack, allowed_packs=allowed_packs, include_closed=False)
                    if row.get("action_id") == action]
        request = existing[0] if existing else handoffs.create(root, pack, owner="Administrator",
            title="Review and apply library version: " + doc["values"]["template_id"], note=note + " " + NOTICE,
            requested_by=actor_id, action_id=action, allowed_packs=allowed_packs, local_demo=True, can_view=True)
        return {"ok": True, "handoff": request, "errors": []}
    except ERRORS as error:
        return _fail(error)


def apply_reviewed(root, pack, actor_id, handoff_id, *, expected_digest, confirmed=False,
                   allowed_packs=None, local_demo=False, can_review=False, can_manage_library=False):
    """One explicit steward act installs exact reviewed bytes, never overwrites or commits."""
    try:
        if local_demo is not True or can_review is not True or can_manage_library is not True or confirmed is not True:
            raise ValueError("Applying a shared version requires the local library steward's review permission and explicit confirmation of this exact diff.")
        base, _product, pack, _owner, _folder = _scope(root, pack, actor_id, allowed_packs)
        scope = _allowed(base, pack, allowed_packs)
        result = shared(base, pack, handoff_id, allowed_packs=scope)
        if not result["ok"]:
            return result
        record = result["record"]
        if expected_digest != record["sha256"] or result["stale"]:
            raise ValueError("The exact reviewed candidate or its source evidence changed. Prepare and review a fresh candidate.")
        before = _inputs(base, scope)
        values = {"candidate": record["checked"]["candidate"], "yaml": record["checked"]["yaml"]}
        checked = _run(base, pack, scope, "validate_application", values)
        if checked.get("blockers") or checked.get("errors"):
            return {"ok": False, "errors": checked.get("blockers") or checked["errors"], "notice": NOTICE}
        if _inputs(base, scope) != before:
            raise ValueError("Evidence changed during the final review check. Nothing was applied.")
        if checked["state"] in {"applied_pending_commit", "recorded_in_library"}:
            return {"ok": True, "changed": False, "state": checked["state"], "target": checked["target"],
                    "errors": [], "message": "This exact version is already present; no file was changed."}
        if checked["state"] != "not_applied":
            raise ValueError("That version identifies different library bytes. Existing versions are never overwritten.")
        target = science._safe(base / checked["target"])
        if target.parent != base / RELEASES:
            raise ValueError("The library target is outside the declared release folder.")
        raw = record["checked"]["yaml"].encode("utf-8")
        if len(raw) > LIMIT:
            raise ValueError("The reviewed candidate exceeds the metadata limit.")
        science._safe(target.parent).mkdir(parents=True, exist_ok=True)
        created = False
        temporary = None
        try:
            # Prepare complete bytes before exposing a release. Windows rename
            # refuses an existing destination; POSIX hard-link creation does too.
            with tempfile.NamedTemporaryFile(dir=target.parent, suffix=".tmp", delete=False) as handle:
                temporary = Path(handle.name)
                handle.write(raw)
            if os.name == "nt":
                os.rename(temporary, target)
            else:
                os.link(temporary, target)
            created = True
            if temporary.exists():
                temporary.unlink()
            after = _run(base, pack, scope, "validate_application", values)
            if after.get("errors") or after.get("blockers") or after.get("state") != "applied_pending_commit":
                raise ValueError("The canonical release check did not confirm the newly applied exact bytes.")
            expected_files = dict(before["files"])
            expected_files[checked["target"]] = science._hash(raw)
            if _inputs(base, scope) != {"files": expected_files, "head": before["head"]}:
                raise ValueError("Source or library evidence changed during application; the new file was not confirmed.")
        except BaseException as error:
            if created and target.exists():
                if target.read_bytes() == raw:
                    committed = subprocess.run(["git", "-C", str(base), "show", "HEAD:" + checked["target"]],
                                               capture_output=True, timeout=10)
                    if committed.returncode == 0 and committed.stdout == raw:
                        return {"ok": False, "changed": True, "errors": ["Another action committed this version during validation. The portal left that committed file intact; check its current library evidence before continuing."]}
                    target.unlink()
                    if isinstance(error, ERRORS):
                        raise ValueError(str(error) + " The unchanged new file was removed; no existing version was touched.") from error
                else:
                    return {"ok": False, "changed": True, "errors": ["Validation did not finish and the new library file changed concurrently. The portal left those changed bytes intact; the library steward must inspect them before continuing."]}
            raise error
        finally:
            if temporary is not None and temporary.exists():
                temporary.unlink()
        return {"ok": True, "changed": True, "state": "applied_pending_commit", "target": checked["target"], "errors": [],
                "message": "The exact reviewed version is applied to the working library. Its governed commit remains required; no approval, signature or product release was created."}
    except ERRORS as error:
        return _fail(error)


def _worker(request):
    root = Path(request["root"]).resolve()
    canonical = root / "platform/tools"
    if not (canonical / "template_promote.py").is_file():
        raise ValueError("Restore the canonical template checker in this checkout before checking library readiness.")
    # Imports happen only in this worker. No shared Streamlit module globals are changed.
    sys.path[:0] = [str(canonical), str(root / "platform")]
    import template_promote as tp
    import product_gates as pg
    import template_reconcile as tr
    product = root / request["pack"]
    scope = set(request["scope"])
    known, problems, hidden, seen = {}, [], False, set()
    reserved = set()
    for path in sorted((root / RELEASES).glob("*.yaml")):
        if science._safe(path).stat().st_size > LIMIT:
            problems.append("A library record exceeds the metadata limit; ask the library steward to repair it.")
            continue
        try:
            doc = yaml.safe_load(path.read_bytes())
        except yaml.YAMLError:
            problems.append("A library record cannot be parsed; ask the library steward to repair it.")
            continue
        if not isinstance(doc, dict) or not isinstance(doc.get("source"), dict):
            problems.append("A library record cannot identify its source; ask the library steward to repair it.")
            continue
        source = doc["source"].get("pack")
        key = (str(doc.get("template_id")), str(doc.get("version")))
        reserved.add(key)
        if source not in scope:
            hidden = True
            continue
        # An accessible release source still must not redirect its configuration
        # readers into another product through pipeline or format references.
        storage._configured_inputs(root / source)
        permitted = set(pg.semantic_manifest(str(root / source), str(root)))
        if set(doc["source"].get("semantic_manifest") or {}) - permitted:
            problems.append("An accessible release declares unexpected provenance paths; ask the library steward to inspect it.")
            continue
        errors = tp.release_errors(doc, str(root))
        if key in seen:
            problems.append("Two accessible releases claim the same template version: " + "@".join(key))
            known.pop(key, None)
        elif errors:
            problems.extend(["@".join(key) + ": " + error for error in errors])
        else:
            known[key] = (path.relative_to(root).as_posix(), doc)
        seen.add(key)
    # Canonical adoption resolution uses only the validated, accessible index.
    # Its full-library caveat is explicit; an incomplete index never becomes a pass.
    tp.releases = lambda _root, strict=True: (known, problems)
    adoption = product / tp.ADOPTION
    adoption_doc, adoption_parse_error = {}, False
    if adoption.is_file():
        try:
            adoption_doc = yaml.safe_load(adoption.read_bytes()) or {}
            adoption_parse_error = not isinstance(adoption_doc, dict)
        except yaml.YAMLError:
            adoption_parse_error = True
    adoption_problems = (["The current adoption record cannot be parsed. Ask the library steward to repair handoff/TEMPLATE_ADOPTION.yaml."]
                         if adoption_parse_error else tp.adoption_errors(str(root), str(product)))
    if hidden:
        adoption_problems.append("Some template source evidence is outside this product session's access. The full library and adoption check is incomplete; ask its steward for a scoped review.")
    blockers = tp.promotion_blockers(str(root), str(product))
    manifest = pg.semantic_manifest(str(product), str(root))
    dirty = tp.uncommitted_inputs(str(root), request["pack"], manifest,
                                contract_rel=request["pack"] + "/handoff/FUNCTIONAL_CONTRACT.md")
    if dirty:
        blockers.append("Commit the exact reviewed semantic inputs before preparing a candidate: " + ", ".join(dirty))
    if not tp.issuance_commit(str(root)):
        blockers.append("The current checkout has no readable Git commit. Engineering must restore immutable provenance before a library candidate can be prepared.")
    if request["operation"] in {"integration", "validate_application"}:
        candidate, raw = request["values"]["candidate"], request["values"]["yaml"].encode("utf-8")
        key = (str(candidate.get("template_id")), str(candidate.get("version")))
        if not tp.TEMPLATE_ID.fullmatch(key[0]) or not tp.SEMVER.fullmatch(key[1]) or (candidate.get("source") or {}).get("pack") != request["pack"]:
            raise ValueError("The reviewed candidate does not identify this product and a valid immutable version.")
        target = RELEASES + "/" + key[0] + "-" + key[1] + ".yaml"
        state, evidence_errors, commit = "not_applied", [], None
        hit = known.get(key)
        if hit:
            target, doc = hit
            actual = (root / target).read_bytes()
            if doc != candidate or actual != raw:
                state = "different_version_bytes"
            else:
                commit = tp.issuance_commit(str(root))
                committed = tp._git_bytes(str(root), "show", str(commit) + ":" + target)
                state = "recorded_in_library" if committed == actual else "applied_pending_commit"
        elif key in reserved:
            state = "invalid_or_inaccessible_version"
            evidence_errors = ["This version is already declared but cannot be validated as the exact reviewed candidate."]
        elif (root / target).exists():
            state = "different_version_bytes"
        if request["operation"] == "validate_application":
            blockers += tp.release_errors(candidate, str(root))
            blockers += problems
            if hidden:
                blockers.append("Applying a shared version requires steward access to the source evidence for the existing library. The current library check is incomplete.")
            source = candidate["source"]
            current_contract = tp._sha((product / "handoff/FUNCTIONAL_CONTRACT.md").read_text(encoding="utf-8"))
            if (source.get("contract_sha256") != current_contract or source.get("semantic_sha256") != pg.semantic_sha256(str(product))
                    or source.get("semantic_manifest_sha256") != pg.semantic_manifest_sha256(str(product), str(root))):
                blockers.append("The source meaning differs from the reviewed candidate. Prepare and review a fresh candidate.")
            if not blockers:
                regenerated = tp.candidate(str(root), str(product), *key, reviewers=candidate.get("reviewers"))
                # An unrelated later commit need not replace the original,
                # already verified issuance subject. Every meaning field must
                # still equal the canonical candidate derived from source.
                regenerated["source"]["issued_at_commit"] = source["issued_at_commit"]
                regenerated = json.loads(json.dumps(regenerated, default=str))
                if regenerated != candidate:
                    blockers.append("The reviewed payload differs from the canonical current concepts and rulings. Prepare a fresh candidate; do not hand-edit its meaning or hashes.")
        return {"state": state, "target": target, "commit": commit, "blockers": blockers if request["operation"] == "validate_application" else [],
                "errors": evidence_errors, "can_review_adoption": state == "recorded_in_library"}
    if request["operation"] == "candidate":
        if blockers:
            return {"blockers": blockers}
        values = request["values"]
        # not_a_person intentionally leaves placeholders to its caller. A typed
        # TODO is not an accountable review even if the release shape is sound.
        if pg.unstated(values["reviewed_by"]) or pg.unstated(values["date"]):
            return {"blockers": ["reviewers: record the actual reviewer and review date; a placeholder is not attribution."]}
        key = (values["template_id"], values["version"])
        if key in reserved:
            return {"blockers": ["This template version already exists. Preserve it and propose a new version."]}
        candidate = tp.candidate(str(root), str(product), *key,
                                 reviewers=[{"reviewed_by": values["reviewed_by"], "date": values["date"]}])
        errors = tp.release_errors(candidate, str(root))
        if errors:
            return {"blockers": errors}
        after = yaml.safe_dump(candidate, sort_keys=False, allow_unicode=True)
        return {"candidate": candidate, "yaml": after,
                "diff": "\n".join(difflib.unified_diff([], after.splitlines(), fromfile="Shared library: no new entry", tofile="Proposed candidate only", lineterm="")),
                "validators": ["template_promote.promotion_blockers", "person_rules.unstated (review attribution)", "template_promote.candidate", "template_promote.release_errors (immutable Git provenance)"],
                "notices": tp.release_notices(candidate, str(root)), "blockers": []}
    reconciliation = tr.match(str(product))
    head = tp.issuance_commit(str(root))
    release_rows = []
    for path, doc in known.values():
        committed = bool(head) and tp._git_bytes(str(root), "show", str(head) + ":" + path) == (root / path).read_bytes()
        release_rows.append({"path": path, "document": doc, "committed": committed,
                             "notices": tp.release_notices(doc, str(root))})
        if not committed and not adoption_parse_error and any(isinstance(row, dict) and row.get("template_id") == doc["template_id"]
                                 and row.get("version") == doc["version"] for row in (adoption_doc.get("adopts") or [])):
            adoption_problems.append("A referenced library version is only in the working tree. Record its governed commit before completing adoption review.")
    return {"blockers": blockers, "confirmed": tp.promotable(reconciliation), "dirty_inputs": dirty,
            "releases": release_rows,
            "library_findings": problems, "scope_complete": not hidden,
            "adoption": {} if adoption_parse_error else adoption_doc,
            "adoption_findings": adoption_problems,
            "adoption_notices": [] if adoption_parse_error else tp.adoption_notices(str(root), str(product))}


if __name__ == "__main__" and "--worker" in sys.argv:
    try:
        print(json.dumps(_worker(_WORKER_REQUEST), ensure_ascii=False, default=str))
    except Exception as error:
        print(json.dumps({"blockers": [str(error)], "errors": [str(error)]}))
