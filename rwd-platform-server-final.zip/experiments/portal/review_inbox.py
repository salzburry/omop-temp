"""Review requests for configuration proposals: the states after 'Submit proposal for review'.

WHY (2026-09-07). Submitting a proposal wrote a receipt into the author's private draft
folder and stopped: no other person could see it, nothing accepted it, nothing applied it.
This module holds the rest of the workflow as data plus explicit human acts:

    submitted            the author's checked proposal, published as an immutable snapshot
    changes requested    a reviewer's typed note; the author revises and submits again
    accepted             a reviewer's typed name and date, confirmed, on these exact bytes
    applied              the accepted files written into a DRAFT REVISION folder, never config/
    validated            the existing gates run on that draft revision

A request lives at <product>/.portal-drafts/reviews/<request_id>.json. The ``request`` part
is immutable and carries its own digest; decisions are appended, each with the identity of the
person who typed it. Nothing here approves a product, releases it or changes a study pin: the
file says so in every state, and a reviewer's acceptance is acceptance for a draft revision.

Only the submitted snapshot is visible to a reviewer. The author's other drafts stay in the
author's folder; this module reads the author's folder for one purpose, to notice that the
submitted proposal no longer matches its snapshot, and it never shows that folder's contents.
"""
from __future__ import annotations

import hashlib
from copy import deepcopy
import json
import os
import re
import shutil
import tempfile
import uuid
from datetime import date, datetime, timezone
from pathlib import Path

import design_workspace as dw
import configuration_proposals as cp

STATUS_WORDS = {
    "submitted": "waiting for review",
    "changes_requested": "changes requested",
    "accepted": "accepted for a draft revision",
    "applied": "applied to a draft revision",
    "validated": "validators run on the draft revision",
    "superseded": "superseded by the author's later request",
}
# Which recorded act may follow which state. Applying twice is answered without a record
# (a no-op with a message), so 'applied' follows 'accepted' only.
TRANSITIONS = {
    "changes_requested": ("submitted", "changes_requested"),
    "accepted": ("submitted", "changes_requested"),
    "applied": ("accepted",),
    "validated": ("applied", "validated"),
    # the author submitted a revised proposal for the same files: the earlier request closes and
    # points at the new one, so the reviewer reads one request, not two (walk NEW-4)
    "superseded": ("submitted", "changes_requested"),
}
NOTICE = ("A review request records people's decisions about one exact set of proposed settings. "
          "Accepting it, applying it to a draft revision and running the validators do not approve "
          "the product, release it or change any study.")
UNREADABLE = "Review request {short} cannot be read safely. Its file changed or is incomplete; nothing was written."
SELF_REVIEW = "You submitted this request, so another reviewer records its decision."
NOT_REVIEWER = "Recording a review decision needs the review permission."
NOT_LOCAL = "Recording review decisions, applying changes and running validators need a local editing session."
CHANGED = "The submitted proposal changed after it was submitted, so it cannot be accepted. Ask the author to submit the current proposal again."
BASE_MOVED = "The product changed since this request was submitted. Nothing was written. Ask the author to stage a fresh proposal from the current product."
STALE = "The reviewed variables or proposal inputs changed since submission. Reopen the current review and stage a fresh proposal before accepting these changes."
NOT_ACCEPTED = "These changes have not been accepted yet, so they cannot be applied."
NOT_APPLIED = "Apply the accepted changes before running the validators on them."
NOT_PARTY = "Applying accepted changes and running the validators is for the request's author or a reviewer."
REVISION_NOTE = ("Draft revision written by the portal from an accepted review request. It is not the product's "
                 "configuration; the files under config/ and variables/ of the product are unchanged.")


class Refused(ValueError):
    pass


def _failure(exc):
    message = str(exc) if isinstance(exc, (Refused, cp.Invalid, dw._DraftError)) else (
        "The review request could not be processed safely. Nothing was written.")
    return {"ok": False, "changed": False, "errors": [message]}


def _now():
    return datetime.now(timezone.utc).isoformat()


def _when(stamp):
    """A timestamp the way a person reads it; the file keeps the full value."""
    try:
        moment = datetime.fromisoformat(str(stamp))
    except ValueError:
        return str(stamp)
    return moment.astimezone(timezone.utc).strftime("%Y-%m-%d %H:%M UTC")


def _actor(actor_id):
    """The same identity rule as the draft stores: a non-empty label, digested for the file."""
    if not isinstance(actor_id, str) or not actor_id.strip() or len(actor_id) > 300 or any(ord(c) < 32 for c in actor_id):
        raise Refused("An identified session is required to work with review requests.")
    return actor_id.strip(), hashlib.sha256(actor_id.strip().encode("utf-8")).hexdigest()


def _person(name, on, what):
    """A typed name and a typed date; neither is ever supplied by the portal."""
    if not isinstance(name, str) or not name.strip() or len(name.strip()) > 200 or any(ord(c) < 32 for c in name):
        raise Refused(f"Type your name to record {what}.")
    if not isinstance(on, str) or not re.fullmatch(r"\d{4}-\d{2}-\d{2}", on.strip()):
        raise Refused(f"Type the date of {what} as YYYY-MM-DD.")
    try:
        date.fromisoformat(on.strip())
    except ValueError as exc:
        raise Refused(f"The date of {what} must be a real calendar date in YYYY-MM-DD form.") from exc
    return name.strip(), on.strip()


def _scope(root, pack, allowed_packs=None):
    base, path, name = dw._pack_path(root, pack, allowed_packs)
    directory = cp._safe(path / ".portal-drafts" / "reviews")
    return base, path, name, directory


def _file(directory, request_id):
    if not isinstance(request_id, str) or not re.fullmatch(r"[0-9a-f]{32}", request_id):
        raise Refused("Choose a review request from this product.")
    return cp._safe(directory / (request_id + ".json"))


def _sealed(record, key):
    return {**record, key: dw._hash(record)}


def _intact(record, key):
    return isinstance(record, dict) and record.get(key) == dw._hash({k: v for k, v in record.items() if k != key})


def _status(decisions):
    status = "submitted"
    for record in decisions:
        act = record.get("act")
        if act not in TRANSITIONS or status not in TRANSITIONS[act]:
            raise Refused("A recorded decision does not follow from the request's state.")
        status = act
    return status


def _document(request, decisions):
    doc = {"schema_version": 1, "draft_only": True, "approved": False, "released": False,
           "request": request, "decisions": decisions, "status": _status(decisions)}
    return _sealed(doc, "file_sha256")


def _write(file, doc):
    """Atomic: the whole document lands or nothing does. Never touches a governed file."""
    file.parent.mkdir(parents=True, exist_ok=True)
    temp = cp._safe(file.parent / (".request-" + uuid.uuid4().hex))
    try:
        temp.write_bytes(cp._encode(doc))
        os.replace(temp, file)
    finally:
        if temp.exists() and temp.resolve() == temp and temp.parent == file.parent:
            temp.unlink()


def _read(file, request_id, name):
    doc = cp._json(file)
    short = request_id[:8]
    try:
        if (not isinstance(doc, dict) or doc.get("schema_version") != 1 or doc.get("draft_only") is not True
                or doc.get("approved") is not False or doc.get("released") is not False
                or not _intact(doc, "file_sha256")):
            raise Refused("")
        request, decisions = doc.get("request"), doc.get("decisions")
        if (not _intact(request, "request_sha256") or request.get("request_id") != request_id
                or request.get("pack") != name or request.get("status") != "submitted"
                or not isinstance(request.get("files"), list) or not isinstance(request.get("candidate"), dict)
                or not isinstance(request.get("base"), dict) or not isinstance(request.get("author"), dict)
                or not isinstance(decisions, list) or not all(_intact(r, "record_sha256") for r in decisions)
                or doc.get("status") != _status(decisions)):
            raise Refused("")
        for entry in request["files"]:
            if cp._digest(entry["after"].encode("utf-8")) != request["candidate"].get(entry["path"]):
                raise Refused("")
        _review_metadata(request)
        _validation_checks(request.get("validation") or {})
    except (ValueError, KeyError, TypeError, AttributeError) as exc:
        raise Refused(UNREADABLE.format(short=short)) from exc
    return doc


def _review_metadata(record):
    if "variable_review_binding" in record:
        cp._binding_shape(record["variable_review_binding"])
    cp._check_review_records(record)


def _validation_checks(validation):
    checks = validation.get("checks") or []
    if not isinstance(checks, list) or len(checks) > 100:
        raise Refused("The submitted validator details are incomplete or too large.")
    result = []
    for check in checks:
        if not isinstance(check, dict):
            raise Refused("The submitted validator details are unreadable.")
        saved = {"validator": check.get("validator"), "passed": check.get("passed") is True,
                 "pre_existing": check.get("pre_existing") is True}
        if "errors" in check:
            errors = check["errors"]
            if (not isinstance(errors, list) or len(errors) > 2000
                    or any(not isinstance(error, str) or len(error) > 20000 for error in errors)):
                raise Refused("The submitted validator findings exceed the supported review size.")
            saved["errors"] = list(errors)
        if "note" in check:
            if not isinstance(check["note"], str) or len(check["note"]) > 20000:
                raise Refused("The submitted validator note exceeds the supported review size.")
            saved["note"] = check["note"]
        result.append(saved)
    return result


def _lock(file):
    lock = cp._safe(file.parent / (file.stem + ".lock"))
    try:
        handle = os.open(lock, os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o600)
    except FileExistsError as exc:
        raise Refused("Another decision is being recorded on this request. Reopen it and try again.") from exc
    os.close(handle)
    return lock


def _unlock(lock):
    if lock is not None and lock.exists() and lock.resolve() == lock:
        lock.unlink()


def publish(root, pack, *, proposal, validation, actor_id, request_id, allowed_packs=None):
    """Publish the checked proposal as the review request its submission receipt names.

    Called by configuration_proposals.submit after the receipt is written. Idempotent on the
    request id: a request that already exists for these proposal bytes is returned unchanged.
    """
    base, path, name, directory = _scope(root, pack, allowed_packs)
    author_id, author_owner = _actor(actor_id)
    if proposal.get("owner") != author_owner or proposal.get("pack") != name:
        raise Refused("Only the proposal's author can submit it for review.")
    _review_metadata(proposal)
    file = _file(directory, request_id)
    if file.exists():
        doc = _read(file, request_id, name)
        if doc["request"]["proposal_sha256"] != proposal["proposal_sha256"]:
            raise Refused("The submission receipt names a review request for different proposal bytes.")
        return doc
    candidate = {entry["path"]: cp._digest(entry["after"].encode("utf-8")) for entry in proposal["files"]}
    if any(proposal["artifacts"].get("candidate/" + rel) != digest for rel, digest in candidate.items()):
        raise Refused("The candidate files do not match the proposal's own record of them.")
    earlier = _open_by_author(directory, name, author_id, set(candidate), skip=request_id)
    request = {
        "supersedes": earlier,
        "request_id": request_id, "pack": name, "status": "submitted", "draft_only": True,
        "author": {"id": author_id, "owner": author_owner},
        "proposal_id": proposal["proposal_id"], "proposal_sha256": proposal["proposal_sha256"],
        "purpose": proposal.get("purpose") or "",
        "studies": list((proposal.get("brief") or {}).get("studies") or []),
        "base": {"baseline_sha256": proposal["baseline_sha256"], "snapshot_sha256": proposal["snapshot_sha256"],
                 "files": {entry["path"]: cp._digest(entry["before"].encode("utf-8")) for entry in proposal["files"]}},
        "candidate": candidate,
        "files": [{key: entry[key] for key in ("path", "before", "after", "diff", "semantic_diff")} for entry in proposal["files"]],
        "configuration_changes": proposal.get("configuration_changes") or [],
        "study_exclusions": proposal.get("study_exclusions") or [],
        "impact": proposal.get("impact") or {},
        "validation": {"passed": validation.get("passed") is True, "validated_at": validation.get("validated_at"),
                       "checks": _validation_checks(validation),
                       # a failure the product already had, so the reviewer reads it as the product's
                       # own open work and not as this change's (walk UC3-P1-4)
                       "caveats": [str(c) for c in (validation.get("caveats") or []) if isinstance(c, str)][:20]},
        "submitted_at": _now(),
        "scope": "Review request only. Acceptance is for a draft revision; no product, approval, release or study pin is changed.",
    }
    for field in ("variable_review_binding", "variable_review_records"):
        if field in proposal:
            request[field] = deepcopy(proposal[field])
    if not _base_current(base, path, name, request):
        raise Refused(BASE_MOVED)
    doc = _document(_sealed(request, "request_sha256"), [])
    _write(file, doc)
    for other_id in earlier:
        _record(root, pack, other_id, actor_id, allowed_packs, "superseded",
                lambda base, path, nm, d, actor, owner, _new=request_id: {
                    "name": actor, "date": _now()[:10], "superseded_by": _new,
                    "note": "The author submitted a revised proposal for the same files."})
    return doc


def _open_by_author(directory, name, author_id, paths, *, skip):
    """The author's own requests still waiting (submitted or changes requested) that touch any of
    these files, oldest first; an unreadable request is left alone."""
    found = []
    if not directory.is_dir():
        return found
    for other in sorted(directory.glob("*.json")):
        other_id = other.stem
        if other_id == skip or not re.fullmatch(r"[0-9a-f]{32}", other_id):
            continue
        try:
            odoc = _read(other, other_id, name)
        except Refused:
            continue
        request = odoc.get("request") or {}
        if odoc.get("status") not in ("submitted", "changes_requested"):
            continue
        if (request.get("author") or {}).get("id") != author_id:
            continue
        if not (paths & set((request.get("candidate") or {}).keys())):
            continue
        found.append((str(request.get("submitted_at", "")), other_id))
    return [other_id for _at, other_id in sorted(found)]


def _proposal_state(base, path, name, request):
    """intact, stale, changed or missing: current inputs and the author's exact snapshot.

    Reads one proposal by id in the author's folder and compares digests only; the reviewer
    is shown the snapshot, never that folder.
    """
    author = request["author"]["owner"]
    directory = cp._owner_directory(path, author)
    try:
        proposal, _folder, stale = cp._load(base, path, name, author, directory, request["proposal_id"])
    except cp.Invalid:
        folder = directory / request["proposal_id"]
        return "missing" if not folder.exists() else "changed"
    except (OSError, ValueError, TypeError, KeyError):
        return "changed"
    if proposal["proposal_sha256"] != request["proposal_sha256"]:
        return "changed"
    if "variable_review_binding" in proposal and "variable_review_binding" not in request:
        return "stale"  # A pre-upgrade request lacks the evidence needed to continue this bound review.
    for field in ("variable_review_binding", "variable_review_records"):
        if dw._hash(proposal.get(field)) != dw._hash(request.get(field)):
            return "changed"
    return "stale" if stale else "intact"


def _base_current(base, path, name, request, *, proposal_state=None):
    """Every stored validation input and reviewed choice still matches the request."""
    description = dw.describe(base, name)
    if description["errors"] or description["baseline_sha256"] != request["base"]["baseline_sha256"]:
        return False
    fingerprint = request["base"].get("snapshot_sha256")
    if fingerprint is not None and cp._snapshot(base, path) != fingerprint:
        return False
    if proposal_state is None:
        proposal_state = _proposal_state(base, path, name, request)
    if proposal_state == "stale":
        return False
    if "variable_review_binding" in request and (proposal_state != "intact"
            or cp._review_binding_stale(base, path, request["variable_review_binding"])):
        return False
    for rel, digest in request["base"]["files"].items():
        file = cp._safe(path / rel)
        if not file.is_file() or cp._digest(file.read_bytes()) != digest:
            return False
    return True


def _history(request, decisions):
    author = request["author"]["id"]
    lines = [f"Submitted by {author} on {_when(request['submitted_at'])}."]
    for record in decisions:
        who, on, by = record["name"], record["date"], record["recorded_by"]["id"]
        if record["act"] == "changes_requested":
            lines.append(f"Changes requested by {who} on {on}, recorded under {by}: {record['note']}")
        elif record["act"] == "accepted":
            lines.append(f"Accepted for a draft revision by {who} on {on}, recorded under {by}.")
        elif record["act"] == "applied":
            lines.append(f"Applied to draft revision {record['revision_path']} by {who} on {on}, recorded under {by}.")
        elif record["act"] == "validated":
            verdict = "every validator passed" if record["passed"] else "at least one validator failed"
            lines.append(f"Validators run on the draft revision by {who} on {on}, recorded under {by}: {verdict}.")
        elif record["act"] == "superseded":
            lines.append(f"Superseded on {on} by the author's later request {str(record.get('superseded_by', ''))[:8]}, recorded under {by}.")
    return lines


def _view(base, path, name, doc, actor_owner):
    request, decisions = doc["request"], doc["decisions"]
    status = doc["status"]
    proposal_state = _proposal_state(base, path, name, request)
    base_current = _base_current(base, path, name, request, proposal_state=proposal_state)
    last = decisions[-1] if decisions else None
    return {"ok": True, "request_id": request["request_id"], "status": status, "status_words": STATUS_WORDS[status],
            "request": request, "decisions": decisions, "history": _history(request, decisions),
            "is_author": actor_owner == request["author"]["owner"],
            "proposal_state": proposal_state, "base_current": base_current,
            "can_accept": proposal_state == "intact" and base_current and status in TRANSITIONS["accepted"],
            "last_act": None if last is None else {"act": last["act"], "name": last["name"], "date": last["date"]},
            "validation": next((r for r in reversed(decisions) if r["act"] == "validated"), None),
            "applied": next((r for r in decisions if r["act"] == "applied"), None),
            "errors": []}


def list_requests(root, pack, *, actor_id, allowed_packs=None):
    """Every request in this product, newest first; an unreadable one is named, never skipped."""
    try:
        base, path, name, directory = _scope(root, pack, allowed_packs)
        _actor_id, owner = _actor(actor_id)
        rows, errors = [], []
        if directory.exists():
            for file in sorted(directory.iterdir()):
                if file.suffix != ".json" or not re.fullmatch(r"[0-9a-f]{32}", file.stem):
                    continue
                try:
                    view = _view(base, path, name, _read(file, file.stem, name), owner)
                except (Refused, cp.Invalid):
                    errors.append(UNREADABLE.format(short=file.stem[:8]))
                    continue
                except (OSError, ValueError, TypeError, KeyError, UnicodeError):
                    errors.append(UNREADABLE.format(short=file.stem[:8]))
                    continue
                rows.append({"request_id": view["request_id"], "status": view["status"], "status_words": view["status_words"],
                             "purpose": view["request"]["purpose"], "author": view["request"]["author"]["id"],
                             "submitted_at": view["request"]["submitted_at"], "is_author": view["is_author"],
                             "proposal_state": view["proposal_state"], "base_current": view["base_current"],
                             "last_act": view["last_act"]})
        rows.sort(key=lambda row: row["submitted_at"], reverse=True)
        return {"ok": True, "requests": rows, "errors": errors}
    except (OSError, ValueError, TypeError, KeyError, UnicodeError, RecursionError) as exc:
        return {**_failure(exc), "requests": []}


def load_request(root, pack, *, request_id, actor_id, allowed_packs=None):
    try:
        base, path, name, directory = _scope(root, pack, allowed_packs)
        _actor_id, owner = _actor(actor_id)
        return _view(base, path, name, _read(_file(directory, request_id), request_id, name), owner)
    except (OSError, ValueError, TypeError, KeyError, UnicodeError, RecursionError) as exc:
        return _failure(exc)


def _record(root, pack, request_id, actor_id, allowed_packs, act, build):
    """Append one decision under a lock; ``build`` sees the fresh document and returns the record body."""
    lock = None
    try:
        base, path, name, directory = _scope(root, pack, allowed_packs)
        actor, owner = _actor(actor_id)
        file = _file(directory, request_id)
        doc = _read(file, request_id, name)
        lock = _lock(file)
        doc = _read(file, request_id, name)
        if doc["status"] not in TRANSITIONS[act]:
            raise Refused({"changes_requested": "This request is no longer waiting for review; its decision was recorded.",
                           "accepted": "This request is no longer waiting for review; its decision was recorded.",
                           "superseded": "This request is no longer waiting for review; its decision was recorded.",
                           "applied": NOT_ACCEPTED, "validated": NOT_APPLIED}[act])
        body = build(base, path, name, doc, actor, owner)
        if body is None:
            return {"ok": True, "changed": False, "status": doc["status"], "errors": []}
        record = _sealed({"act": act, "recorded_at": _now(), "recorded_by": {"id": actor, "owner": owner}, **body}, "record_sha256")
        if act in {"accepted", "validated"} and not _base_current(base, path, name, doc["request"]):
            raise Refused(STALE if act == "accepted" else BASE_MOVED)
        _write(file, _document(doc["request"], doc["decisions"] + [record]))
        return {"ok": True, "changed": True, "status": act, "record": record, "errors": []}
    except (OSError, ValueError, TypeError, KeyError, UnicodeError, RecursionError) as exc:
        return _failure(exc)
    finally:
        _unlock(lock)


def _reviewer(doc, owner, can_review, local_demo):
    if local_demo is not True:
        raise Refused(NOT_LOCAL)
    if can_review is not True:
        raise Refused(NOT_REVIEWER)
    if owner == doc["request"]["author"]["owner"]:
        raise Refused(SELF_REVIEW)


def request_changes(root, pack, *, request_id, actor_id, can_review, local_demo, note, reviewer_name, reviewed_on,
                    allowed_packs=None):
    def build(base, path, name, doc, actor, owner):
        _reviewer(doc, owner, can_review, local_demo)
        who, on = _person(reviewer_name, reviewed_on, "your request for changes")
        if not isinstance(note, str) or not note.strip() or len(note) > 20000:
            raise Refused("Type what needs to change so the author can act on it.")
        return {"name": who, "date": on, "note": note.strip()}
    return _record(root, pack, request_id, actor_id, allowed_packs, "changes_requested", build)


def accept(root, pack, *, request_id, actor_id, can_review, local_demo, reviewer_name, reviewed_on, confirmed,
           allowed_packs=None):
    def build(base, path, name, doc, actor, owner):
        _reviewer(doc, owner, can_review, local_demo)
        who, on = _person(reviewer_name, reviewed_on, "your acceptance")
        if confirmed is not True:
            raise Refused("Confirm that you accept these exact changes before recording the acceptance.")
        proposal_state = _proposal_state(base, path, name, doc["request"])
        if proposal_state == "stale":
            raise Refused(STALE)
        if proposal_state != "intact":
            raise Refused(CHANGED)
        if not _base_current(base, path, name, doc["request"], proposal_state=proposal_state):
            raise Refused(STALE)
        return {"name": who, "date": on, "proposal_sha256": doc["request"]["proposal_sha256"],
                "candidate": dict(doc["request"]["candidate"])}
    return _record(root, pack, request_id, actor_id, allowed_packs, "accepted", build)


NOT_WRITER = ("Applying changes and running the validators need product-author access. Your role can record the review "
              "decision; the author, or a person with author access, applies it.")


def _party(doc, owner, can_review, local_demo, can_write):
    if local_demo is not True:
        raise Refused(NOT_LOCAL)
    if can_write is not True:
        raise Refused(NOT_WRITER)     # a reviewer in a local session lacks write access, not the session (walk UC3-P2-4)
    if owner != doc["request"]["author"]["owner"] and can_review is not True:
        raise Refused(NOT_PARTY)


def _revision_dir(path, request_id):
    return cp._safe(path / ".portal-drafts" / "revisions" / request_id)


def apply(root, pack, *, request_id, actor_id, can_review, local_demo, can_write, applied_by, applied_on,
          allowed_packs=None):
    """Write the accepted candidate files into a draft revision folder, never into the product."""
    staging = None

    def build(base, path, name, doc, actor, owner):
        nonlocal staging
        _party(doc, owner, can_review, local_demo, can_write)
        who, on = _person(applied_by, applied_on, "applying these changes")
        request = doc["request"]
        if not _base_current(base, path, name, request):
            raise Refused(BASE_MOVED)
        accepted = next(r for r in reversed(doc["decisions"]) if r["act"] == "accepted")
        if accepted["candidate"] != request["candidate"]:
            raise Refused("The accepted files no longer match the request. Nothing was written.")
        destination = _revision_dir(path, request_id)
        if destination.exists():
            raise Refused("A draft revision folder already exists for this request without an applied record. Ask the operator to check it; nothing was written.")
        destination.parent.mkdir(parents=True, exist_ok=True)
        staging = Path(tempfile.mkdtemp(prefix=".applying-", dir=cp._safe(destination.parent)))
        applied = {}
        for entry in request["files"]:
            data = entry["after"].encode("utf-8")
            target = staging / entry["path"]
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes(data)
            applied[entry["path"]] = cp._digest(data)
        (staging / "REVISION.json").write_bytes(cp._encode({
            "draft_only": True, "executable": False, "approved": False, "released": False,
            "request_id": request_id, "pack": name, "base": request["base"], "files": applied,
            "applied_by": who, "applied_on": on, "recorded_under": actor, "note": REVISION_NOTE}))
        if not _base_current(base, path, name, request):
            raise Refused(BASE_MOVED)
        os.rename(staging, destination)
        staging = None
        return {"name": who, "date": on, "applied_files": applied,
                "revision_path": destination.relative_to(base).as_posix()}

    try:
        view = load_request(root, pack, request_id=request_id, actor_id=actor_id, allowed_packs=allowed_packs)
        if view["ok"] and view["status"] in ("applied", "validated"):
            done = view["applied"]
            return {"ok": True, "changed": False, "status": view["status"], "errors": [],
                    "message": f"These changes were already applied by {done['name']} on {done['date']}. Nothing was written."}
        return _record(root, pack, request_id, actor_id, allowed_packs, "applied", build)
    finally:
        if staging is not None and staging.exists() and staging.resolve() == staging:
            shutil.rmtree(staging)


def validate(root, pack, *, request_id, actor_id, can_review, local_demo, can_write, validated_by, validated_on,
             allowed_packs=None):
    """Run the existing gates on the applied draft revision and record the verdict on the request."""
    def build(base, path, name, doc, actor, owner):
        _party(doc, owner, can_review, local_demo, can_write)
        who, on = _person(validated_by, validated_on, "running the validators")
        request = doc["request"]
        if not _base_current(base, path, name, request):
            raise Refused(BASE_MOVED)
        applied = next(r for r in doc["decisions"] if r["act"] == "applied")
        revision = _revision_dir(path, request_id)
        files = []
        for rel, digest in applied["applied_files"].items():
            data = cp._read(cp._safe(revision / rel))
            if cp._digest(data) != digest:
                raise Refused("The draft revision files changed after they were applied. Nothing was validated.")
            files.append({"path": rel, "after": data.decode("utf-8")})
        checks = cp.validate_files(base, path, name, files)
        if not _base_current(base, path, name, request):
            raise Refused(BASE_MOVED)
        passed = bool(checks) and all(c.get("passed") is True for c in checks)
        errors = [] if passed else ["At least one existing validator did not pass on the draft revision."]
        return {"name": who, "date": on, "revision_path": applied["revision_path"], "validated_files": dict(applied["applied_files"]),
                "passed": passed, "checks": checks, "errors": errors}
    return _record(root, pack, request_id, actor_id, allowed_packs, "validated", build)


def recent(root, pack, actor_id, *, allowed_packs):
    """Rows for the saved-work queue: this product's open requests, so a person can resume them."""
    listing = list_requests(root, pack, actor_id=actor_id, allowed_packs=allowed_packs)
    rows = []
    for row in listing.get("requests") or []:
        if row["status"] == "validated":
            continue
        rows.append({"id": "review-" + row["request_id"], "route": "review_inbox", "title": "Configuration review request",
                     "state": row["status_words"], "summary": row["purpose"] or f"Submitted by {row['author']}",
                     "updated_at": row["submitted_at"], "params": {"request_id": row["request_id"]}})
    return rows
