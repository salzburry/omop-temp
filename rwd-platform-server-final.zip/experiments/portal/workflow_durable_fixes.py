"""Reviewed durable replacements owned by the existing correction lifecycle.

An explicit exact-file edit, the owning validators and current regression evidence
replace temporary guidance. The original lessons and every proposal remain history.
"""
from __future__ import annotations

import ast
from datetime import datetime, timezone
import difflib
import hashlib
import json
from pathlib import Path
import re
import sys
import tempfile
import time
import uuid
import xml.etree.ElementTree as ET

import yaml

import delivery_binding
import portal_runtime
import workflow_improvement as improvement
import workflow_skills
import workflow_durable_regression as regression

LIMIT = 96_000
MAX_FILE = 512_000
FRAGMENT = 12_000
KINDS = {"code": "Python implementation", "skill": "Workflow skill", "naming": "Naming registry", "knowledge": "Knowledge register"}
REGISTERS = {
    "governance/NAMING_RULINGS.yaml": ("naming", "rulings", "platform/tools/naming_registry.py", "platform/tests/test_naming_registry.py"),
    "governance/NAME_LIFECYCLE.yaml": ("naming", "names", "platform/tools/naming_registry.py", "platform/tests/test_naming_registry.py"),
    "governance/DEFINITIONS.yaml": ("knowledge", "definitions", "platform/tools/definition_registry.py", "platform/tests/test_definition_registry.py"),
    "governance/precedents.yaml": ("knowledge", "precedents", "platform/tools/precedents.py", "platform/tests/test_precedents.py"),
}
NOTICE = ("Replace repeated guidance with an exact reviewed branch change. The owning validators and registered regressions must pass "
          "before linked lessons leave future prompts. History remains available. This does not authenticate scientific approval or release a product.")


class Invalid(ValueError):
    pass


def _loop():
    return workflow_skills.learning()


def _sha(raw):
    return hashlib.sha256(raw).hexdigest()


def _scope(root, actor, record_id, allowed):
    actor = improvement._author(actor)
    root = Path(root).resolve(strict=True)
    row = _loop().read_correction(root, record_id)
    scope = _loop()._scope_value(row.get("scope"))
    if scope["kind"] == "legacy_context":
        raise Invalid("Resolve the lesson's original scope before proposing a durable replacement.")
    if scope["kind"] == "packs" and any(pack not in (allowed or []) for pack in scope["packs"]):
        raise Invalid("This lesson includes a product outside the current workspace access.")
    return root, actor, row


def _path(root, owner, proposal_id):
    _loop()._record_path(root, owner)
    if not isinstance(proposal_id, str) or not re.fullmatch(r"[a-f0-9]{24}", proposal_id):
        raise Invalid("Choose an existing durable-change proposal.")
    return _loop()._safe(root, _loop().CORRECTIONS / owner / ("durable-" + proposal_id + ".json"))


def _write(root, owner, proposal):
    path = _path(root, owner, proposal["id"])
    unsigned = {key: value for key, value in proposal.items() if key != "digest"}
    proposal = {**unsigned, "digest": _loop().digest(unsigned)}
    raw = json.dumps(proposal, ensure_ascii=False, allow_nan=False).encode()
    if len(raw) > LIMIT:
        raise Invalid("Keep the durable proposal and its check history within the supported size.")
    path.parent.mkdir(parents=True, exist_ok=True)
    import handoffs
    handoffs._write(path, proposal)
    return proposal


def _read(root, owner, proposal_id):
    path = _path(root, owner, proposal_id)
    if not path.is_file() or path.stat().st_size > LIMIT:
        raise Invalid("The durable proposal is missing or too large.")
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
        if not isinstance(value, dict):
            raise ValueError()
        unsigned = {key: item for key, item in value.items() if key != "digest"}
        if value["digest"] != _loop().digest(unsigned) or value["id"] != proposal_id or value["owner_id"] != owner:
            raise ValueError()
        if value["state"] not in {"staged", "applying", "check_failed", "interrupted", "validated", "applied"}:
            raise ValueError()
        if (value.get("schema") != 1 or value.get("kind") not in KINDS or value.get("skill") not in workflow_skills.BINDINGS
                or any(not isinstance(value.get(key), str) for key in ("path", "actor_id", "before_text", "after_text", "regression_expectation"))
                or any(not re.fullmatch(r"[a-f0-9]{64}", str(value.get(key, "")))
                       for key in ("before_sha256", "after_sha256", "input_digest", "installed_input_digest"))
                or not isinstance(value.get("linked_bindings"), dict) or not 1 <= len(value["linked_bindings"]) <= 12
                or owner not in value["linked_bindings"]
                or any(not re.fullmatch(r"[a-f0-9]{24}", key) or not re.fullmatch(r"[a-f0-9]{64}", str(item))
                       for key, item in value["linked_bindings"].items())
                or not isinstance(value.get("attempts"), list) or len(value["attempts"]) > 10
                or any(not isinstance(item, dict) for item in value["attempts"])
                or not isinstance(value.get("tests"), list) or not value["tests"]
                or any(not isinstance(item, str) for item in value["tests"])):
            raise ValueError()
        application = value.get("application")
        if application is not None:
            if (not isinstance(application, dict) or not isinstance(application.get("check"), dict)
                    or not isinstance(application["check"].get("commands"), list)
                    or any(not isinstance(item, dict) for item in application["check"]["commands"])):
                raise ValueError()
        return value
    except (ValueError, KeyError, TypeError, RecursionError):
        raise Invalid("The durable proposal changed or is unreadable. Review its branch file.") from None


def _text(root, path):
    target = _loop()._safe(root, path)
    if not target.is_file() or target.stat().st_size > MAX_FILE:
        raise Invalid("Restore the existing owning file; it must be readable and at most 512 KB.")
    try:
        return target.read_bytes().decode("utf-8")
    except UnicodeDecodeError:
        raise Invalid("The owning file must contain UTF-8 text.") from None


def _targets(root, row):
    # Existing task bindings own these addresses. No prompt or supplied path can
    # expand them into arbitrary files, validator code, credentials or approvals.
    code = set()
    for handler in workflow_skills.BINDINGS[row["skill"]]["handlers"]:
        path = Path(handler["path"])
        if path.suffix != ".py":
            continue
        code.add(path.as_posix())
        # The existing renderer family owns its backend/chat/choice companions
        # too. Resolve only that same filename family beside the bound handler;
        # do not crawl imports into unrelated authorization or validator files.
        prefix = path.stem.removesuffix("_page")
        for companion in (root / path.parent).glob(prefix + "*.py"):
            code.add(companion.relative_to(root).as_posix())
    result = {"code": sorted(code),
              "skill": [".claude/skills/" + row["skill"] + "/SKILL.md"],
              "naming": [path for path, entry in REGISTERS.items() if entry[0] == "naming"],
              "knowledge": [path for path, entry in REGISTERS.items() if entry[0] == "knowledge"]}
    return {kind: [path for path in paths if _loop()._safe(root, path).is_file()] for kind, paths in result.items()}


def _selectors(skill, kind, path):
    tests = list(_loop().DEFAULT_TESTS[skill])
    if path in REGISTERS:
        tests.append(REGISTERS[path][3])
    if kind == "skill":
        tests.append("platform/tests/test_epi_workflow_skills.py")
        if skill == "draft-contract-record":
            tests.append("platform/tests/test_skill_currency.py")
    return list(dict.fromkeys(tests))


def _inputs(root, replacement=None):
    """Bind commands, tests and metadata consumed by the owning register checks."""
    metadata, count, size = {}, 0, 0
    for folder in ("governance", "products", "fixtures"):
        base = _loop()._safe(root, folder)
        for path in sorted(base.rglob("*")):
            parts = path.relative_to(base).parts
            if any(part.startswith(".") or part in {"__pycache__", "IMPLEMENTATION_REVIEWS"} for part in parts):
                continue
            if not path.is_file() or path.suffix not in {".yaml", ".yml", ".json", ".md", ".py", ".conf"}:
                continue
            relative = path.relative_to(root).as_posix()
            _loop()._safe(root, relative)
            count += 1
            size += path.stat().st_size
            # The bundled UMLS relation/terminology metadata are multi-MB
            # canonical validator inputs; hash them without exposing their text.
            if count > 5000 or size > 32_000_000 or path.stat().st_size > 16_000_000:
                raise Invalid("The durable validation inputs exceed the supported local metadata bound.")
            raw = replacement["after"].encode() if replacement and replacement["path"] == relative else path.read_bytes()
            metadata[relative] = _sha(raw)
    software = {replacement["path"]: replacement["after"].encode()} if replacement and replacement["path"] not in REGISTERS else None
    return _loop().digest({"software": _loop().software_digest(root, overrides=software), "metadata": metadata})


def _linked(root, primary, ids):
    if (not isinstance(ids, list) or not 1 <= len(ids) <= 12 or len(ids) != len(set(ids))
            or primary["id"] not in ids):
        raise Invalid("Select this lesson and at most eleven related lessons to replace.")
    rows = [_loop().read_correction(root, identifier) for identifier in sorted(ids)]
    for row in rows:
        if (row["status"] in {"retired", "withdrawn"} or row["skill"] != primary["skill"]
                or _loop()._scope_value(row.get("scope")) != _loop()._scope_value(primary.get("scope"))):
            raise Invalid("Linked lessons must have the same skill and exact scope and still need a replacement.")
    return {row["id"]: _loop().correction_content_digest(row) for row in rows}


def _yaml(text):
    try:
        if any(isinstance(token, (yaml.AliasToken, yaml.AnchorToken)) for token in yaml.scan(text)):
            raise ValueError()
        return yaml.safe_load(text)
    except (ValueError, RecursionError, yaml.YAMLError):
        raise Invalid("The register must be plain, bounded YAML without aliases.") from None


def _shape(root, row, kind, path, before, after, actor, allowed):
    if kind == "code":
        try:
            ast.parse(after, filename=path)
        except (SyntaxError, ValueError, RecursionError):
            raise Invalid("The proposed Python has a syntax error; it was not installed or executed.") from None
    elif kind == "skill":
        header = re.match(r"\A---\r?\n(.*?)\r?\n---(?:\r?\n|$)", after, re.S)
        old = re.match(r"\A---\r?\n(.*?)\r?\n---(?:\r?\n|$)", before, re.S)
        meta = _yaml(header[1]) if header else None
        previous = _yaml(old[1]) if old else None
        if (not isinstance(meta, dict) or meta.get("name") != row["skill"]
                or not re.fullmatch(r"\d+\.\d+\.\d+(?:[-+][A-Za-z0-9.-]+)?", str(meta.get("version", "")))
                or not isinstance(previous, dict) or meta.get("version") == previous.get("version")
                or not str(meta.get("description") or "").strip()):
            raise Invalid("Keep the skill identity and description and explicitly update its version with the reviewed instructions.")
    else:
        key = REGISTERS[path][1]
        previous, proposed = _yaml(before), _yaml(after)
        if (not isinstance(previous, dict) or not isinstance(proposed, dict) or set(proposed) != set(previous)
                or not isinstance(proposed.get(key), list) or not isinstance(previous.get(key), list)
                or len(proposed[key]) <= len(previous[key]) or proposed[key][:len(previous[key])] != previous[key]
                or any(proposed.get(other) != previous[other] for other in previous if other != key)):
            raise Invalid("Add a reviewed owning-register entry; preserve every existing record. Existing scientific identities and rulings are not silently rewritten.")
        added = proposed[key][len(previous[key]):]
        if any(not isinstance(entry, dict) for entry in added):
            raise Invalid("Each new owning-register entry must be a mapping.")
        authors = {"rulings": ["ruled_by"], "names": ["retired_by", "registered_by"], "definitions": ["registered_by"]}.get(key, [])
        for entry in added:
            if authors and (not any(field in entry for field in authors)
                    or any(entry[field] != actor for field in authors if field in entry)):
                raise Invalid("The explicit local reviewer must be the named author of each new register entry; no identity is filled or authenticated automatically.")
        mentioned = set(re.findall(r"(?:products|fixtures)/[A-Za-z0-9_.-]+/[A-Za-z0-9_.-]+/[A-Za-z0-9_.-]+", json.dumps(added)))
        if mentioned - set(allowed or []):
            raise Invalid("The proposed knowledge cites a product outside the current workspace access.")


def _case_link(case, kind, path, before, after):
    if kind == "code":
        functions = {node.name for node in ast.parse(before).body if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef))}
        if case["function"] not in functions:
            raise Invalid("Test an existing owning function's behavior. A newly added helper alone does not demonstrate that the current workflow was fixed.")
    elif kind == "skill":
        body = lambda text: re.sub(r"\A---\r?\n.*?\r?\n---(?:\r?\n|$)", "", text, count=1, flags=re.S)
        old_body, new_body = body(before), body(after)
        if (not all(text in new_body for text in case["required"])
                or not (any(text not in old_body for text in case["required"])
                        or any(text in old_body and text not in new_body for text in case["forbidden"]))):
            raise Invalid("The skill case must check the changed body instructions, including a new required instruction or a removed superseded instruction. A version bump alone is not a regression test.")
    else:
        collection = REGISTERS[path][1]
        previous, revised = _yaml(before), _yaml(after)
        if case["match"] not in revised[collection][len(previous[collection]):]:
            raise Invalid("The registry case must assert every field of an exact newly added reviewed record.")


def _file(root, proposal):
    before = _text(root, proposal["path"])
    if _sha(before.encode()) != proposal["before_sha256"] or before.count(proposal["before_text"]) != 1:
        raise Invalid("The owning file changed after staging. Review its current contents and stage a new diff.")
    after = before.replace(proposal["before_text"], proposal["after_text"], 1)
    if _sha(after.encode()) != proposal["after_sha256"]:
        raise Invalid("The staged replacement no longer produces the reviewed file.")
    return {"path": proposal["path"], "before": before, "after": after, "before_sha256": proposal["before_sha256"]}


def _mark(root, primary_id, proposal, actor):
    with _loop()._locked(root, primary_id):
        row = _loop().read_correction(root, primary_id)
        history = list(row.get("durable_history") or [])
        if proposal["id"] not in history:
            if len(history) >= 20:
                raise Invalid("This lesson already has twenty retained durable proposals. Record a new reviewed correction to continue.")
            history.append(proposal["id"])
        state = "applied" if proposal["state"] in {"applied", "validated"} and row["status"] == "retired" else proposal["state"]
        if state == "validated":
            state = "applying"
        row.update(durable_history=history, durable_fix={"proposal_id": proposal["id"], "state": state, "by": actor})
        return _loop()._write_correction(root, row)


def describe(root, actor_id, record_id, *, allowed_packs=None):
    root, actor, row = _scope(root, actor_id, record_id, allowed_packs)
    groups = _loop().repeated_corrections(root)
    related = [other for other in _loop().corrections(root) if other["skill"] == row["skill"]
               and _loop()._scope_value(other.get("scope")) == _loop()._scope_value(row.get("scope"))
               and other["status"] not in {"retired", "withdrawn"}]
    return {"ok": True, "record": row, "targets": _targets(root, row), "digest": row["digest"],
        "related": [{**{key: other[key] for key in ("id", "right", "context", "status")},
                     "content_digest": _loop().correction_content_digest(other)} for other in related],
        "repeat_groups": [group for group in groups if row["id"] in group["record_ids"]],
        "history": row.get("durable_history", []), "notice": NOTICE}


def target_text(root, actor_id, record_id, kind, path, *, allowed_packs=None):
    root, actor, row = _scope(root, actor_id, record_id, allowed_packs)
    if kind not in KINDS or path not in _targets(root, row)[kind]:
        raise Invalid("Choose the existing owning file for this workflow skill.")
    return _text(root, path)


def _excerpt(text, goal, kind):
    if len(text.encode()) <= 6500:
        return text
    if kind != "code":
        return text[:1800] + "\n[Middle records omitted; preserve them.]\n" + text[-4500:]
    lines = text.splitlines(True)
    tree = ast.parse(text)
    tokens = set(re.findall(r"[a-z_]{3,}", goal.lower()))
    nodes = [node for node in tree.body if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef))]
    nodes.sort(key=lambda node: len(tokens & set(re.findall(r"[a-z_]{3,}", node.name.lower()))), reverse=True)
    result = "".join(lines[:16])
    for node in nodes:
        segment = "".join(lines[node.lineno - 1:node.end_lineno])
        if len((result + segment).encode()) <= 6200:
            result += "\n" + segment
    return result + "\n[Other definitions omitted; preserve unseen interfaces and request needed context.]"


def prepare(root, actor_id, record_id, *, goal, kind, path, expected_digest, expected_connection,
            confirmed=False, can_write=False, can_review=False, allowed_packs=None, cancelled=None,
            linked_ids=None, expected_linked_bindings=None):
    """Selected coding agent prepares a patch/test for review; never stages it."""
    improvement._permission(actor_id, can_write is True and can_review is True, confirmed)
    root, actor, row = _scope(root, actor_id, record_id, allowed_packs)
    if row["digest"] != expected_digest or row["status"] in {"retired", "withdrawn"}:
        raise Invalid("Refresh this unfinished lesson before requesting its durable fix.")
    if not isinstance(goal, str) or not 10 <= len(goal.strip()) <= 1800:
        raise Invalid("Describe the behavior or reusable instruction this fix should establish.")
    if (not isinstance(expected_connection, dict) or expected_connection.get("ok") is not True
            or not expected_connection.get("provider_id") or not expected_connection.get("model")):
        raise Invalid("Choose and review the selected assistant connection before requesting this fix.")
    source = target_text(root, actor, record_id, kind, path, allowed_packs=allowed_packs)
    linked = _linked(root, row, [record_id] if linked_ids is None else linked_ids)
    if ((len(linked) > 1 or expected_linked_bindings is not None) and linked != expected_linked_bindings):
        raise Invalid("A selected lesson changed. Review the current related lessons before requesting this fix.")
    before_inputs = _inputs(root)
    context = {"skill": row["skill"], "kind": kind, "path": path, "goal": goal.strip(),
        "lesson": {key: row[key] for key in ("wrong", "right", "context")},
        "selected_lessons": [{"id": identifier, **{key: _loop().read_correction(root, identifier)[key]
                             for key in ("wrong", "right", "context")}} for identifier in linked],
        "current_file_excerpt": _excerpt(source, goal, kind), "reviewer": actor,
        "packs": _loop()._scope_value(row.get("scope")).get("packs", []),
        "regression_example": regression.example(kind, REGISTERS.get(path, (None, None))[1])}
    _loop()._ingress(_loop()._plain(context))
    if cancelled and cancelled():
        raise Invalid("The preparation was cancelled before requesting the assistant.")
    import portal_agent_connection as connection
    sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "agent"))
    import coding_agent
    result = coding_agent.prepare_durable(context, connection.model(root, expected=expected_connection), actor={"name": actor})
    if cancelled and cancelled():
        raise Invalid("The preparation was cancelled; no proposal was staged.")
    if (_inputs(root) != before_inputs or _loop().read_correction(root, record_id)["digest"] != expected_digest
            or _linked(root, row, list(linked)) != linked
            or connection._binding(connection.describe(root)) != connection._binding(expected_connection)):
        raise Invalid("The lesson, owning files or selected connection changed during preparation. Request a current proposal.")
    proposed = result["proposal"]
    _loop()._ingress(_loop()._plain(result))
    if (not proposed["before_text"] or len(proposed["before_text"].encode()) > FRAGMENT
            or len(proposed["after_text"].encode()) > FRAGMENT or source.count(proposed["before_text"]) != 1
            or proposed["before_text"] == proposed["after_text"]):
        raise Invalid("The proposed patch does not uniquely match the current owning file. Clarify the goal or edit its exact fragment in advanced review.")
    after = source.replace(proposed["before_text"], proposed["after_text"], 1)
    _shape(root, row, kind, path, source, after, actor, allowed_packs)
    proposed["regression_case"] = regression.validate(proposed["regression_case"], kind, path, REGISTERS.get(path, (None, None))[1])
    _case_link(proposed["regression_case"], kind, path, source, after)
    return {"ok": True, "changed": False, "prepared": proposed, "critic": result["critic"],
        "kind": kind, "path": path, "record_id": record_id, "record_digest": expected_digest,
        "linked_bindings": linked,
        "input_digest": before_inputs, "connection": expected_connection, "model_calls": result["model_calls"],
        "diff": "".join(difflib.unified_diff(source.splitlines(True), after.splitlines(True), path, path + " (proposed)")),
        "notice": result["notice"]}


def stage(root, actor_id, record_id, *, kind, path, before_text, after_text, linked_ids,
          regression_expectation, expected_digest, regression_case=None, confirmed=False, can_write=False, can_review=False, allowed_packs=None,
          expected_linked_bindings=None):
    improvement._permission(actor_id, can_write is True and can_review is True, confirmed)
    root, actor, row = _scope(root, actor_id, record_id, allowed_packs)
    if row["digest"] != expected_digest or row["status"] in {"retired", "withdrawn"}:
        raise Invalid("Refresh the current lesson before staging its durable replacement.")
    if kind not in KINDS or path not in _targets(root, row)[kind]:
        raise Invalid("Choose an existing owning file; arbitrary paths and validator edits are not supported.")
    if (not isinstance(before_text, str) or not before_text or len(before_text.encode()) > FRAGMENT
            or not isinstance(after_text, str) or len(after_text.encode()) > FRAGMENT or before_text == after_text):
        raise Invalid("Enter a changed exact fragment, with before and after each at most 12 KB.")
    if not isinstance(regression_expectation, str) or not 10 <= len(regression_expectation.strip()) <= 1800:
        raise Invalid("Explain the expected regression behavior and how this edit addresses every linked lesson.")
    case = regression.validate(regression_case, kind, path, REGISTERS.get(path, (None, None))[1])
    _loop()._ingress(_loop()._plain({"before": before_text, "after": after_text, "expectation": regression_expectation, "regression_case": case}))
    before = _text(root, path)
    if before.count(before_text) != 1:
        raise Invalid("The before fragment must match exactly once in the current owning file.")
    after = before.replace(before_text, after_text, 1)
    if len(after.encode()) > MAX_FILE:
        raise Invalid("The proposed owning file exceeds the supported size.")
    _shape(root, row, kind, path, before, after, actor, allowed_packs)
    _case_link(case, kind, path, before, after)
    linked = _linked(root, row, linked_ids)
    if expected_linked_bindings is not None and linked != expected_linked_bindings:
        raise Invalid("A selected lesson changed after preparation. Review its current wording and request a new fix.")
    proposal = {"schema": 1, "id": uuid.uuid4().hex[:24], "owner_id": record_id, "actor_id": actor,
        "state": "staged", "kind": kind, "path": path, "skill": row["skill"],
        "scope": _loop()._scope_value(row.get("scope")), "linked_bindings": linked,
        "before_text": before_text, "after_text": after_text,
        "before_sha256": _sha(before.encode()), "after_sha256": _sha(after.encode()),
        "diff": "".join(difflib.unified_diff(before.splitlines(True), after.splitlines(True), path, path + " (proposed)")),
        "regression_expectation": regression_expectation.strip(), "tests": _selectors(row["skill"], kind, path),
        "regression_case": case,
        "input_digest": _inputs(root), "created_at": datetime.now(timezone.utc).isoformat(),
        "installed_input_digest": _inputs(root, {"path": path, "after": after}),
        "attempts": [], "application": None, "notice": NOTICE}
    proposal = _write(root, record_id, proposal)
    saved = _mark(root, record_id, proposal, actor)
    return {"ok": True, "proposal": proposal, "record_digest": saved["digest"], "changed": False}


def _checks(root, proposal, file):
    """Only registered commands. Skip/no-collection is never a passing check."""
    started, records = time.monotonic(), []
    if portal_runtime.job_cancelled():
        raise Invalid("The durable check was cancelled. No lesson may be retired.")
    portal_runtime.job_progress("Testing the exact reviewed case in separate before and after snapshots.")
    specific = regression.run(root, proposal, file)
    if not specific["passed"]:
        return {"passed": False, "commands": [], "tests": proposal["tests"], "specific_regression": specific,
                "seconds": round(time.monotonic() - started, 2), "checked_at": datetime.now(timezone.utc).isoformat()}
    commands = []
    if proposal["path"] in REGISTERS:
        tool = REGISTERS[proposal["path"]][2]
        commands.append(("owning validator", [sys.executable, str(root / tool), "--check"]))
    with tempfile.TemporaryDirectory(prefix="rwd-durable-check-") as temporary:
        junit = Path(temporary) / "regressions.xml"
        commands.append(("registered regressions", [sys.executable, "-m", "pytest", *proposal["tests"],
            "-q", "--disable-warnings", "-o", "addopts=", "--junitxml=" + str(junit)]))
        for label, command in commands:
            if portal_runtime.job_cancelled():
                raise Invalid("The durable check was cancelled. No lesson may be retired.")
            portal_runtime.job_progress("Running " + label + " for the reviewed durable change.")
            for path in proposal["tests"]:
                if not _loop()._safe(root, path).is_file():
                    raise Invalid("Restore the existing registered regressions before applying this fix.")
            completed = portal_runtime.run(command, cwd=str(root), timeout_s=600 if label == "registered regressions" else 180,
                extra_env={"PYTHONDONTWRITEBYTECODE": "1", "PYTEST_ADDOPTS": "", "PYTEST_PLUGINS": "",
                           "PYTEST_DISABLE_PLUGIN_AUTOLOAD": "1"})
            checks = {"label": label, "exit_code": completed.returncode, "passed": completed.returncode == 0}
            if label == "registered regressions":
                try:
                    if junit.stat().st_size > 5_000_000:
                        raise ValueError()
                    suites = ET.parse(junit).getroot()
                    cases = list(suites.iter("testcase"))
                    counts = {key: len(list(suites.iter(key))) for key in ("failure", "error", "skipped")}
                    checks.update(tests_run=len(cases), **counts)
                    checks["passed"] = checks["passed"] and bool(cases) and not any(counts.values())
                except (OSError, ValueError, ET.ParseError):
                    checks.update(passed=False, tests_run=0, report_missing=True)
            records.append(checks)
            if not checks["passed"]:
                break
    return {"passed": bool(records) and len(records) == len(commands) and all(row["passed"] for row in records),
        "specific_regression": specific,
        "commands": records, "tests": proposal["tests"], "seconds": round(time.monotonic() - started, 2),
        "checked_at": datetime.now(timezone.utc).isoformat(),
        "notice": "Actual fixed owning checks and regressions. These checks do not establish the scientific meaning of the reviewed edit."}


def _fresh_links(root, proposal):
    primary = _loop().read_correction(root, proposal["owner_id"])
    if (primary.get("durable_fix") or {}).get("proposal_id") != proposal["id"]:
        raise Invalid("A newer proposal replaced this review. Open the latest durable diff.")
    current = _linked(root, primary, list(proposal["linked_bindings"]))
    if current != proposal["linked_bindings"]:
        raise Invalid("A linked lesson changed. Review and stage its current wording before applying.")
    return primary


def validate_application(root, owner_id, proposal_id):
    """Canonical retirement prerequisite; an input flag cannot claim a pass."""
    root = Path(root).resolve(strict=True)
    proposal = _read(root, owner_id, proposal_id)
    primary = _loop().read_correction(root, owner_id)
    application = proposal.get("application") or {}
    check = application.get("check") or {}
    if (proposal["state"] not in {"validated", "applied"} or not application
            or (primary.get("durable_fix") or {}).get("proposal_id") != proposal_id
            or proposal.get("skill") != primary["skill"]
            or proposal.get("scope") != _loop()._scope_value(primary.get("scope"))
            or proposal.get("path") not in _targets(root, primary).get(proposal.get("kind"), [])
            or application.get("owner_id") != owner_id or application.get("proposal_id") != proposal_id
            or application.get("path") != proposal["path"]
            or application.get("reviewed_by") != proposal["actor_id"]
            or application.get("input_digest") != proposal["installed_input_digest"]
            or check.get("passed") is not True or check.get("tests") != _selectors(proposal["skill"], proposal["kind"], proposal["path"])
            or application.get("input_digest") != _inputs(root)
            or _sha(_text(root, proposal["path"]).encode()) != proposal["after_sha256"]
            or application.get("file_sha256") != proposal["after_sha256"]
            or application.get("linked_bindings") != proposal["linked_bindings"]):
        raise Invalid("The exact installed replacement and current passing required checks are not available. No lesson may be retired.")
    if not regression.current(check.get("specific_regression"), proposal):
        raise Invalid("The reviewed correction-specific case must fail before and pass after the current exact change. Generic passing suites cannot retire this lesson.")
    commands = check.get("commands") or []
    expected = ["owning validator", "registered regressions"] if proposal["path"] in REGISTERS else ["registered regressions"]
    if [row.get("label") for row in commands] != expected or any(row.get("passed") is not True or row.get("exit_code") != 0 for row in commands):
        raise Invalid("Every required owning check must actually pass before retirement.")
    pytest = commands[-1]
    if type(pytest.get("tests_run")) is not int or pytest["tests_run"] <= 0 or any(pytest.get(key) != 0 for key in ("failure", "error", "skipped")):
        raise Invalid("Skipped, missing or failing regressions cannot retire lessons.")
    unsigned = {key: value for key, value in application.items() if key != "digest"}
    if application.get("digest") != _loop().digest(unsigned):
        raise Invalid("The durable application evidence changed.")
    return application


def apply(root, actor_id, record_id, *, proposal_id, expected_digest, confirmed=False,
          can_write=False, can_review=False, allowed_packs=None):
    improvement._permission(actor_id, can_write is True and can_review is True, confirmed)
    if portal_runtime.job_cancelled():
        raise Invalid("The durable application was cancelled before changing the owning file.")
    root, actor, primary = _scope(root, actor_id, record_id, allowed_packs)
    if primary["digest"] != expected_digest:
        raise Invalid("The lesson changed. Refresh its reviewed durable proposal before applying.")
    # One shared owner transaction at a time, separate from per-record locks.
    with _loop()._locked(root, _loop().digest("durable-change-transaction")[:24]):
        proposal = _read(root, record_id, proposal_id)
        if proposal["actor_id"] != actor:
            raise Invalid("Review and stage the exact diff under your current local identity.")
        if proposal["tests"] != _selectors(proposal["skill"], proposal["kind"], proposal["path"]):
            raise Invalid("The registered owning checks changed. Preserve this history and stage the current diff again.")
        regression.validate(proposal.get("regression_case"), proposal["kind"], proposal["path"], REGISTERS.get(proposal["path"], (None, None))[1])
        if proposal["state"] in {"validated", "applied"}:
            application = validate_application(root, record_id, proposal_id)
            previously_retired = all(_loop().read_correction(root, identifier)["status"] == "retired"
                                     for identifier in application["linked_bindings"])
            rows = _loop().retire_corrections(root, record_id, proposal_id, actor)
            proposal["state"] = "applied"
            proposal = _write(root, record_id, proposal)
            return {"ok": True, "changed": not previously_retired, "retired_ids": [row["id"] for row in rows], "proposal": proposal}
        _fresh_links(root, proposal)
        if proposal["path"] not in _targets(root, primary).get(proposal["kind"], []):
            raise Invalid("The owning target binding changed. Stage a current proposal.")
        _loop()._ingress(_loop()._plain({"before": proposal["before_text"], "after": proposal["after_text"], "expectation": proposal["regression_expectation"]}))
        current = _text(root, proposal["path"])
        installed = _sha(current.encode()) == proposal["after_sha256"]
        if not installed:
            if proposal["input_digest"] != _inputs(root):
                raise Invalid("The branch or validation inputs changed after staging. Stage and review the current diff.")
            file = _file(root, proposal)
            _shape(root, primary, proposal["kind"], proposal["path"], file["before"], file["after"], actor, allowed_packs)
        elif proposal["state"] not in {"applying", "interrupted"}:
            raise Invalid("The file changed outside this application. Stage its current state instead of claiming that this proposal installed it.")
        else:
            # Explicit recovery accepts only the exact bytes installed by this
            # transaction. It still runs all checks before retiring anything.
            file = {"path": proposal["path"], "before": current.replace(proposal["after_text"], proposal["before_text"], 1),
                    "after": current, "before_sha256": proposal["before_sha256"]}
            if _sha(file["before"].encode()) != proposal["before_sha256"]:
                raise Invalid("The interrupted edit cannot be reconstructed exactly. Preserve it and inspect the branch diff.")
            if _inputs(root) != proposal["installed_input_digest"]:
                raise Invalid("Other validation inputs changed during the interruption. Preserve the current branch and review a new replacement.")
        proposal["state"] = "applying"
        proposal = _write(root, record_id, proposal)
        _mark(root, record_id, proposal, actor)
        if not installed:
            delivery_binding._replace_files(root, [file])
        installed_inputs = _inputs(root)
        if installed_inputs != proposal["installed_input_digest"]:
            raise Invalid("The branch changed while installing the reviewed fix. No lesson was retired; inspect the staged file and current branch.")
        try:
            checks = _checks(root, proposal, file)
            _fresh_links(root, proposal)
            unchanged = _inputs(root) == installed_inputs and _sha(_text(root, proposal["path"]).encode()) == proposal["after_sha256"]
            if not checks["passed"] or not unchanged or portal_runtime.job_cancelled():
                raise Invalid("Required checks failed, skipped, or validation inputs changed. No linked lesson was retired.")
        except Exception as error:
            # Preserve a concurrent edit; restore only the exact bytes we own.
            rolled_back = False
            if _text(root, proposal["path"]) == file["after"]:
                reverse = {"path": file["path"], "before": file["after"], "after": file["before"],
                           "before_sha256": _sha(file["after"].encode())}
                delivery_binding._replace_files(root, [reverse])
                rolled_back = True
            proposal["state"] = "check_failed" if rolled_back else "interrupted"
            proposal["attempts"] = (proposal.get("attempts", []) + [{"check": locals().get("checks"),
                "rolled_back": rolled_back, "at": datetime.now(timezone.utc).isoformat()}])[-10:]
            proposal = _write(root, record_id, proposal)
            saved = _mark(root, record_id, proposal, actor)
            return {"ok": False, "changed": not rolled_back, "retired_ids": [], "record_digest": saved["digest"],
                "proposal": proposal, "errors": ["Required checks did not pass or inputs changed. " +
                    ("Our file edit was rolled back; the lessons remain available." if rolled_back else "A concurrent edit was preserved. Inspect the branch before continuing; the lessons remain available.")]}
        application = {"owner_id": record_id, "proposal_id": proposal_id, "path": proposal["path"],
            "file_sha256": proposal["after_sha256"], "input_digest": installed_inputs, "check": checks,
            "linked_bindings": proposal["linked_bindings"], "reviewed_by": actor,
            "reviewed_at": datetime.now(timezone.utc).isoformat(), "regression_expectation": proposal["regression_expectation"]}
        application["digest"] = _loop().digest(application)
        proposal.update(state="validated", application=application)
        proposal = _write(root, record_id, proposal)
        rows = _loop().retire_corrections(root, record_id, proposal_id, actor)
        proposal["state"] = "applied"
        proposal = _write(root, record_id, proposal)
        return {"ok": True, "changed": True, "retired_ids": [row["id"] for row in rows], "proposal": proposal, "notice": NOTICE}


def read(root, actor_id, record_id, proposal_id, *, allowed_packs=None):
    root, actor, primary = _scope(root, actor_id, record_id, allowed_packs)
    proposal = _read(root, record_id, proposal_id)
    valid, complete, pending = False, False, []
    try:
        application = validate_application(root, record_id, proposal_id)
        valid = True
        for identifier, binding in application["linked_bindings"].items():
            row = _loop().read_correction(root, identifier)
            if _loop()._matches_retirement(row, application):
                continue
            if row["status"] not in {"retired", "withdrawn"} and _loop().correction_content_digest(row) == binding:
                pending.append(identifier)
            else:
                valid = False
        complete = valid and not pending
    except ValueError:
        pass
    return {"ok": True, "proposal": proposal, "record_digest": primary["digest"], "current_application": valid,
            "retirement_complete": complete, "pending_retirement": pending if valid else [],
            "stale": proposal["state"] in {"applied", "validated"} and not valid}
