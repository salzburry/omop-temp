"""Stage explicit Plan changes for review without changing the governed product.

Only allowlisted scalar parameters can be translated. The optional LOT numbering
setting may be explicitly added; other settings must already exist. Scientific prose
is retained in an engineering handoff, never compiled into a derivation. Candidate
bytes, exclusions and impact are immutable; submission reruns the existing gates
in an isolated copy and records a local review request, never approval or release.

THE REVIEW REQUEST LEAVES THE AUTHOR'S FOLDER (2026-09-07): submission used to stop at a
receipt inside the author's private draft folder, where no reviewer could see it. Submission
now also publishes an immutable snapshot of the checked proposal under the product's shared
.portal-drafts/reviews/ folder (review_inbox.py); the receipt names that request so the author
can follow it. The gates run in the same isolated copy for a proposal and for an applied draft
revision (``validate_files``), so a reviewer's later check is the same check the author ran.
"""
from __future__ import annotations

import difflib
from copy import deepcopy
import hashlib
import json
import math
import os
import re
import shutil
import tempfile
import uuid
from datetime import date, datetime, timezone
from pathlib import Path

import yaml

import design_workspace as dw
import contract_binding as cb
import config_diff
import study_pin
from engine.config import load_config
from engine.strict_yaml import strict_load
from engine.validate import problems

PARAMETERS = {
    "config/data_product.yaml#/study/index_start": ("Study index start", "date"),
    "config/data_product.yaml#/study/index_end": ("Study index end", "date"),
    "variables/outcomes.yaml#/min_followup_days": ("Minimum follow-up days", "integer"),
    "variables/outcomes.yaml#/visit_recency_days": ("Visit recency days", "integer"),
    "variables/outcomes.yaml#/days_per_month": ("Days per month", "number"),
    "variables/treatment.yaml#/max_lines": ("Maximum treatment line", "positive_integer"),
    "config/data_product.yaml#/lot/line_number": ("Treatment line numbering", "lot_numbering"),
    # the delivery declaration (walk UC4-20, 2026-09-07): the schema the vendor delivers into and the cut
    # label a build reads; both are names, checked as names, never data
    # (walk RW4-N03: the run block lives in config/pipeline.yaml on every product and fixture)
    "config/pipeline.yaml#/run/source_schema": ("Delivered source schema", "text"),
    "config/pipeline.yaml#/run/refresh": ("Delivery cut", "text"),
}
LOT_NUMBERING_REF = "config/data_product.yaml#/lot/line_number"
LOT_NUMBERING_CHOICES = ("linenumber", "new_lot_n")
LOT_NUMBERING_DEFAULT = "new_lot_n"
REVIEW_RECORD_FIELDS = ("item_id", "variable_id", "definition", "spec_values", "values", "family", "master_name", "logic_reviewed")
MAX_REVIEW_RECORDS = 2000
TEXT_NAME = re.compile(r"[A-Za-z0-9][A-Za-z0-9_.\-]{0,79}")
# Two ceilings, because two different things happen to a product file. A file this module
# PARSES (YAML, JSON, a diff) is loaded whole, so it stays small. A file it only fingerprints
# or copies (an attached specification workbook under prog_spec/) is streamed in chunks and
# never decoded, so the ceiling is the size of a document a person may legitimately attach.
LIMIT = 4 * 1024 * 1024
SOURCE_LIMIT = 128 * 1024 * 1024
CHUNK = 1024 * 1024
SHARED_FOLDER = "handoff/CONFIGURATION_PROPOSALS"
SHARED_NOTICE = "Branch handoff only. Validator results are historical; restage in this checkout and run fresh validators before submission. No approval, reviewer decision, release or study pin is imported."
NO_SUPPORTED_SETTINGS = "This product has no supported settings to change yet."
SHARED_INPUTS = ("products/registry.yaml", "products/metadata/catalog.yaml",
                 "products/_reporting/dashboard/dashboard_vars.yaml")


class Invalid(ValueError):
    pass


def _failure(exc):
    message = str(exc) if isinstance(exc, (Invalid, dw._DraftError)) else dw._storage_message(exc,
        "The configuration proposal could not be processed safely. Reopen it or ask its owner to repair the inputs.")
    return {"ok": False, "passed": False, "changed": False, "errors": [message]}


def _path(root, pack, allowed_packs=None):
    """Applicability is a property of the product's files, never of a product name.

    The feature once compared the pack to one hard-coded product; when that product left the
    repository the whole editor became unreachable. Any pack the workspace accepts qualifies as
    soon as one supported setting is actually present in its YAML.
    """
    base, path, name = dw._pack_path(root, pack, allowed_packs)
    if not supported_parameters(base, name):
        raise Invalid(NO_SUPPORTED_SETTINGS)
    return base, path, name


def _safe(file):
    if file.resolve() != file:
        raise Invalid("A proposal input redirects to another location.")
    return file


def _name(file):
    """Name a file the way the person sees it: relative to its pack when it lives in one."""
    parts = file.parts
    for index, part in enumerate(parts):
        if part in ("products", "fixtures") and len(parts) > index + 4:
            return "/".join(parts[index + 4:])
    return "/".join(parts[-2:])


def _bounded(file, limit):
    """Refuse a missing or oversized file by name, so the person knows which file to look at."""
    _safe(file)
    if not file.is_file():
        raise Invalid(f"A proposal input is missing: {_name(file)}.")
    size = file.stat().st_size
    if size > limit:
        megabytes = -(-size // (1024 * 1024))
        raise Invalid(f"{_name(file)} is larger than the supported size of {limit // (1024 * 1024)} MB; "
                      f"it is {megabytes} MB.")
    return file


def _read(file):
    """Bytes of a file this module parses whole; the small ceiling bounds memory, not attachments."""
    return _bounded(file, LIMIT).read_bytes()


def _fingerprint(file):
    """Streamed digest: an attached workbook is hashed in chunks and never held in memory."""
    digest = hashlib.sha256()
    with _bounded(file, SOURCE_LIMIT).open("rb") as stream:
        for chunk in iter(lambda: stream.read(CHUNK), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _copy(file, dest):
    """Stream a product file into the isolated candidate under the same ceiling as its digest."""
    shutil.copyfile(_bounded(file, SOURCE_LIMIT), dest)


def _json(file):
    return json.loads(_read(file).decode("utf-8"))


def _digest(data):
    return hashlib.sha256(data).hexdigest()


def _parse(text):
    doc = _parameter_document(text, "configuration YAML")
    if not isinstance(doc, dict):
        raise Invalid("Configuration must be a YAML mapping.")
    return doc


def _encode(value):
    data = json.dumps(value, indent=2, ensure_ascii=False, allow_nan=False).encode("utf-8")
    if len(data) > LIMIT:
        raise Invalid("This proposal is too large; split it into smaller changes.")
    return data


def _owner_directory(path, owner):
    """Resolve the same private proposal location for authors and review receipts."""
    # Preserve old proposals in place. The full digest remains in every packet;
    # shorter new folders leave room for candidate paths in a Windows checkout.
    parent = path / ".portal-drafts" / "configuration"
    legacy = _safe(parent / owner[:24])
    return legacy if legacy.exists() else _safe(parent / owner[:dw.OWNER_DIRECTORY_CHARS])


def _store(root, pack, actor_id, allowed_packs):
    base, path, name = _path(root, pack, allowed_packs)
    # Reuse the draft editor's actor identity rules without reading another actor.
    _base, _name, owner, _directory = dw._store(base, name, actor_id, allowed_packs)
    directory = _owner_directory(path, owner)
    return base, path, name, owner, directory


def _authorized(local_demo, can_write):
    if local_demo is not True or can_write is not True:
        raise Invalid("Staging, validation and submission require an authorized local editing session.")


def _folder(directory, proposal_id):
    if not isinstance(proposal_id, str) or not re.fullmatch(r"[0-9a-f]{32}", proposal_id):
        raise Invalid("Choose a staged proposal from this product and editing session.")
    return _safe(directory / proposal_id)


def _tree_files(folder):
    if not folder.exists():
        return []
    _safe(folder)
    result = []
    for directory, dirs, files in os.walk(folder, followlinks=False):
        dirs[:] = [name for name in dirs if name not in {".portal-drafts", "__pycache__", ".git"}]
        for name in dirs:
            _safe(Path(directory) / name)
        for name in files:
            file = _safe(Path(directory) / name)
            if file.suffix not in {".pyc", ".pyo"}:
                result.append(file)
    return sorted(result)


def _snapshot(base, path):
    """Fingerprint validation and declared consumer inputs, including absent files."""
    import workflow_outputs
    references = workflow_outputs.declared_references(path, _read)
    files = {file for file in _tree_files(path)
             if not workflow_outputs.is_saved_output(file.relative_to(base).as_posix()) or file.resolve() in references}
    for rel in (*SHARED_INPUTS, "work", "refreshes"):
        file = _safe(base / rel)
        if file.is_dir():
            # Consumer enumeration reads pins and published build receipts. Other
            # study documents and delivered data are outside this review surface.
            files.update(p for p in _tree_files(file) if (
                p.name == study_pin.PINS if rel == "work" else p.suffix.lower() in {".yaml", ".yml", ".json"}))
        else:
            files.add(file)
    return dw._hash({file.relative_to(base).as_posix(): _fingerprint(file) if file.is_file() else None
                     for file in sorted(files)})


def _scalar_node(text, keys):
    node = yaml.compose(text)
    for key in keys:
        if not isinstance(node, yaml.MappingNode):
            raise Invalid("The configured parameter is no longer an editable scalar.")
        matches = [value for name, value in node.value if name.value == key]
        if len(matches) != 1:
            raise Invalid("The configured parameter is missing or ambiguous.")
        node = matches[0]
    if not isinstance(node, yaml.ScalarNode):
        raise Invalid("The configured parameter is no longer an editable scalar.")
    return node


def _parameter_document(text, relative):
    # An alias can make an apparent scalar edit change another configuration
    # field too. Refuse it before construction, including recursive aliases.
    try:
        if any(isinstance(token, (yaml.AliasToken, yaml.AnchorToken)) for token in yaml.scan(text)):
            raise Invalid("YAML aliases and anchors are not supported by this scalar editor.")
        return strict_load(text)
    except (yaml.YAMLError, ValueError) as exc:
        raise Invalid(f"Repair {relative} before proposing changes: {exc}") from exc


def _lot_parent(document):
    if not isinstance(document, dict):
        raise Invalid("Repair config/data_product.yaml: treatment numbering requires a YAML mapping.")
    if "lot" in document and not isinstance(document["lot"], dict):
        raise Invalid("Repair config/data_product.yaml: lot must be a mapping before proposing treatment numbering.")
    parent = document.get("lot", {})
    if "line_number" in parent and (parent["line_number"] is None or isinstance(parent["line_number"], (dict, list))):
        raise Invalid("Repair config/data_product.yaml: lot.line_number must be a scalar setting.")
    return parent


def _insert_mapping_entry(text, node, key, value):
    """Insert one explicit key without rewriting unrelated YAML or its comments."""
    if node.flow_style:
        position = node.end_mark.index - 1
        if text[position:position + 1] != "}":
            raise Invalid("The configuration mapping cannot be edited safely.")
        preceding = [token for token in yaml.scan(text) if token.start_mark.index < position]
        has_comma = preceding and isinstance(preceding[-1], yaml.FlowEntryToken)
        entry = (", " if node.value and not has_comma else " ") + key + ": " + value
        return text[:position] + entry + text[position:]
    if not node.value:
        raise Invalid("The configuration mapping cannot be edited safely.")
    first_key = node.value[0][0]
    position = first_key.start_mark.index
    newline = "\r\n" if "\r\n" in text else "\n"
    entry = key + ": " + value + newline + " " * first_key.start_mark.column
    return text[:position] + entry + text[position:]


def _patch_parameter(text, ref, value):
    relative, pointer = ref.split("#/", 1)
    document = _parameter_document(text, relative)
    replacement = yaml.safe_dump(value, allow_unicode=True, default_flow_style=True).removesuffix("...\n").rstrip("\n")
    if ref == LOT_NUMBERING_REF:
        parent = _lot_parent(document)
        if "line_number" not in parent:
            root = yaml.compose(text)
            if "lot" not in document:
                return _insert_mapping_entry(text, root, "lot", "{line_number: " + replacement + "}")
            node = next(child for name, child in root.value if name.value == "lot")
            return _insert_mapping_entry(text, node, "line_number", replacement)
    node = _scalar_node(text, pointer.split("/"))
    return text[:node.start_mark.index] + replacement + text[node.end_mark.index:]


def supported_parameters(root, pack):
    """{parameter path: (label, kind, current value)} for the allowlisted settings this product carries.

    Each entry resolves against the product's own YAML, read with the strict loader the
    validators use, so a duplicated key or an impossible date is reported rather than read
    last-wins. A file that fails to parse is an error, never 'no settings': a broken file must
    not silently hide a setting a person expects to change. A missing file or a missing key
    simply means that setting is not offered for this product, except the optional
    numbering setting on a product carrying a treatment configuration. Its displayed
    value is the engine default until the reviewer explicitly proposes a declaration.
    """
    _base, path, _name = dw._pack_path(root, pack)
    documents, result = {}, {}
    for ref, (label, kind) in PARAMETERS.items():
        rel, pointer = ref.split("#/", 1)
        if rel not in documents:
            file = _safe(path / rel)
            documents[rel] = None
            if file.is_file():
                try:
                    documents[rel] = _parameter_document(_read(file).decode("utf-8"), rel)
                except Invalid:
                    raise
                except (yaml.YAMLError, ValueError) as exc:
                    raise Invalid(f"Repair {rel} before proposing changes: {exc}") from exc
        value = documents[rel]
        if ref == LOT_NUMBERING_REF:
            if value is None:
                continue
            parent = _lot_parent(value)
            if "line_number" not in parent:
                if _safe(path / "variables/treatment.yaml").is_file():
                    result[ref] = (label, kind, LOT_NUMBERING_DEFAULT)
                continue
        for key in pointer.split("/"):
            value = value.get(key) if isinstance(value, dict) else None
        if value is None or isinstance(value, (dict, list)):
            continue
        result[ref] = (label, kind, str(value) if isinstance(value, date) else value)
    return result


def applicable(root, pack):
    """Whether to offer the configuration route at all; a page that cannot read the product says why itself."""
    try:
        return bool(supported_parameters(root, pack))
    except (OSError, ValueError, TypeError, UnicodeError, RecursionError):
        return False


def editable_parameters(root, pack):
    parameters = supported_parameters(root, pack)
    if not parameters:
        raise Invalid(NO_SUPPORTED_SETTINGS)
    return [{"ref": ref, "label": label, "kind": kind, "value": value}
            for ref, (label, kind, value) in parameters.items()]


def _value(ref, value):
    kind = PARAMETERS[ref][1]
    if kind == "date":
        if not isinstance(value, str) or not re.fullmatch(r"\d{4}-\d{2}-\d{2}", value):
            raise Invalid("Study dates must be explicit YYYY-MM-DD values.")
        try:
            date.fromisoformat(value)
        except ValueError as exc:
            raise Invalid("Study dates must be real calendar dates in YYYY-MM-DD form.") from exc
    elif kind == "integer":
        if type(value) is not int or value < 0:
            raise Invalid("Day windows must be non-negative whole numbers.")
    elif kind == "positive_integer":
        if type(value) is not int or value < 1:
            raise Invalid("Maximum treatment line must be a positive whole number.")
    elif kind == "lot_numbering":
        if not isinstance(value, str) or value not in LOT_NUMBERING_CHOICES:
            raise Invalid("Treatment line numbering must be linenumber or new_lot_n.")
    elif kind == "text":
        if not isinstance(value, str) or not TEXT_NAME.fullmatch(value.strip()) or "REPLACE_ME" in value:
            raise Invalid("A schema or cut name uses letters, digits, underscores, dots or hyphens, up to 80 characters.")
        return value.strip()
    elif type(value) not in (int, float) or not math.isfinite(value) or value <= 0:
        raise Invalid("Days per month must be a finite positive number.")
    return value


def _compose(path, changes):
    if not isinstance(changes, list) or len(changes) > 100:
        raise Invalid("Supply a list of explicit configuration changes.")
    available = {p["ref"] for p in editable_parameters(path.parents[3], path.relative_to(path.parents[3]).as_posix())}
    originals, proposed, seen, handoff = {}, {}, set(), []
    for change in changes:
        if not isinstance(change, dict) or set(change) != {"ref", "value"} or not isinstance(change["ref"], str):
            raise Invalid("Each configuration change needs only ref and value.")
        ref = change["ref"]
        if ref in seen:
            raise Invalid("List each configuration parameter only once.")
        seen.add(ref)
        if ref not in PARAMETERS or ref not in available:
            handoff.append({"kind": "unsupported_configuration", "requested_change": change,
                            "reason": "This setting has no supported explicit editor.",
                            "required_work": "Establish specification references, declared consumers and an engine-supported implementation before proposing a configuration patch."})
            continue
        value = _value(ref, change["value"])
        rel, pointer = ref.split("#/", 1)
        if rel not in originals:
            originals[rel] = _read(path / rel).decode("utf-8")
            proposed[rel] = originals[rel]
        text = proposed[rel]
        proposed[rel] = _patch_parameter(text, ref, value)
        parsed = _parse(proposed[rel])
        for key in pointer.split("/"):
            parsed = parsed.get(key) if isinstance(parsed, dict) else None
        if parsed != value or type(parsed) is not type(value):
            raise Invalid("The proposed value did not survive configuration read-back.")
    files = []
    config_text = proposed.get("config/data_product.yaml")
    if config_text:
        study = _parse(config_text).get("study") or {}
        start, end = (str(study.get(key) or "") for key in ("index_start", "index_end"))
        if re.fullmatch(r"\d{4}-\d{2}-\d{2}", start) and re.fullmatch(r"\d{4}-\d{2}-\d{2}", end) and start > end:
            raise Invalid("Study index start must be on or before study index end.")
    for rel, after in proposed.items():
        before = originals[rel]
        if before == after:
            continue
        files.append({"path": rel, "before": before, "after": after,
                      "diff": "".join(difflib.unified_diff(before.splitlines(True), after.splitlines(True),
                                      fromfile="a/" + rel, tofile="b/" + rel)),
                      "semantic_diff": config_diff.diff_docs(_parse(before), _parse(after))})
    return files, handoff


def _brief(description, brief):
    if not isinstance(brief, dict) or brief.get("pack") != description["pack"]:
        raise Invalid("The revision brief belongs to a different product.")
    if brief.get("baseline_sha256") != description["baseline_sha256"]:
        raise Invalid("The revision brief is stale. Rebuild it from the current product.")
    source = (brief.get("source") or {}).get("proposed") or {}
    inputs = dw._inputs({"retained": brief.get("kept"), "additions": brief.get("added"),
                         "purpose": brief.get("purpose"), "studies": brief.get("studies"),
                         "target_source": source.get("vendor"), "target_modality": source.get("modality")})
    plan = dw.build_plan(description, **inputs)
    if brief.get("removed") != plan["removed"]:
        raise Invalid("The brief selections do not match the current contract.")
    return plan


def _plan_errors(plan):
    # A configuration-only brief (including an empty scaffold contract) can be
    # staged without inventing a new scientific definition. Removed dependencies
    # are assessed against shared changes and each study's actual exclusions.
    ignored = {"No product change is selected. Add or remove a definition, or propose a different source.",
               "Keep or propose at least one definition so the planned product is not empty."}
    return [error for error in plan["errors"] if error not in ignored and "depends on removed variable(s):" not in error]


def _exclusions(plan, exclusions):
    if not isinstance(exclusions, list) or len(exclusions) > 1000:
        raise Invalid("Study exclusions must be a list, separate from shared-product changes.")
    result, seen = [], set()
    for row in exclusions:
        if not isinstance(row, dict) or set(row) != {"study", "variables"}:
            raise Invalid("Each study-only exclusion needs study and variables.")
        study, variables = row["study"], row["variables"]
        if not isinstance(study, str) or study not in plan["studies"] or study in seen:
            raise Invalid("Name each exclusion study once in the brief's intended studies.")
        if (not isinstance(variables, list) or not all(isinstance(v, str) for v in variables)
                or len(set(variables)) != len(variables) or not set(variables) <= set(plan["removed"])):
            raise Invalid("Study-only exclusions must identify removed variables from this brief exactly once.")
        if variables:
            result.append({"study": study, "variables": variables})
        seen.add(study)
    return result


def _impact(base, path, plan, changes, exclusions):
    records = list(dw.cl.typed_records(dw.cl.read(str(path / "handoff/FUNCTIONAL_CONTRACT.md"))))
    by_id = {r.variable_id: r for r in records}
    refs = {c["ref"] for c in changes if c["ref"] in PARAMETERS}
    excluded = {v for row in exclusions for v in row["variables"]}
    shared_removed = [v for v in plan["removed"] if v not in excluded]
    direct = set(by_id) if plan["source_changed"] else set(shared_removed)
    for record in records:
        if any(ref == binding or ref.startswith(binding + "/") for ref in refs for binding in record.implementation_refs or []):
            direct.add(record.variable_id)
    affected = set(direct)
    while True:
        more = {r.variable_id for r in records if set(r.depends_on) & affected}
        if more <= affected:
            break
        affected.update(more)
    dependencies = [{"variable_id": r.variable_id, "depends_on": [d for d in r.depends_on if d != "none"],
                     "dependencies_declared": dw.cl._list(r.raw, "depends_on") is not None}
                    for r in records if r.variable_id in affected]
    errors, consumers = [], []
    # The canonical convenience reader skips corrupt pins. Surface that uncertainty
    # before using it, so an unreadable consumer can never mean 'no consumers'.
    for study in study_pin.studies(str(base)):
        _doc, error = study_pin.load(study, str(base))
        if error:
            errors.append(f"Declared consumer {study} could not be read: {error}")
    for row in study_pin.pins_for_product(plan["pack"], str(base)):
        consumers.append({key: value for key, value in row.items() if key not in {"pinned_by", "pinned_date"}})
    # Registry citations are also declared consumers even before a PINS file exists.
    registry, err = dw.pg.read_yaml(str(base / "products/registry.yaml")) if (base / "products/registry.yaml").exists() else ({}, None)
    if err:
        errors.append("The consumer registry could not be read: " + str(err))
    slug, version = plan["pack"].split("/")[-2:]
    registry_consumers = []
    for entry in (registry or {}).get("work", []) if isinstance(registry, dict) else []:
        if isinstance(entry, dict) and any(isinstance(c, dict) and str(c.get("product")) == slug and str(c.get("spec_version")) == version for c in entry.get("cites_release") or []):
            registry_consumers.append({"study": entry.get("id"), "cites_release": entry["cites_release"]})
    conflicts = []
    for row in exclusions:
        for rec in records:
            missing = sorted(set(rec.depends_on) & set(row["variables"]))
            if rec.variable_id not in row["variables"] and missing:
                conflicts.append({"study": row["study"], "variable_id": rec.variable_id, "missing_dependencies": missing})
    import change_impact
    capabilities, capability_error = change_impact.capabilities_for(refs)
    notes = ["Impact covers declared metadata only; unrecorded consumers and engine dependencies require engineering review."]
    if not records:
        notes.append("No contract records are declared; variable dependencies and output consumers are not established.")
    if not consumers and not registry_consumers:
        notes.append("No study consumers were found in declared pins or registry citations; this is not proof that no studies are affected.")
    if capability_error:
        notes.append(capability_error)
    return {"direct_variables": sorted(direct), "dependent_variables": sorted(affected - direct),
            "dependencies": dependencies,
            "external_dependencies": sorted({d for r in dependencies for d in r["depends_on"] if d not in by_id}),
            "consumers": consumers, "registry_consumers": registry_consumers, "capabilities": capabilities,
            "shared_removed": shared_removed, "study_dependency_conflicts": conflicts,
            "notes": notes, "errors": errors}


def _engineering_handoff(plan, impact, unsupported):
    handoff = list(unsupported)
    for item in plan["added"]:
        handoff.append({"kind": "new_derivation", **item, "reason": "Scientific text has no supported executable mapping.",
                        "required_work": "Bind specification rows, source fields, dependencies and acceptance examples; implement and review the derivation."})
    for vid in impact["shared_removed"]:
        handoff.append({"kind": "shared_removal", "variable_id": vid,
                        "reason": "Removing a contract selection does not remove an engine output or its shared configuration block.",
                        "required_work": "Review declared and engine consumers, revise the contract and emitted surface, and produce a reviewed implementation patch."})
    if plan["source_changed"]:
        handoff.append({"kind": "source_change", "source": plan["source"],
                        "reason": "A source name or modality does not establish delivered mappings.",
                        "required_work": "Review the delivery schema, adapters, availability, cohort attrition and source evidence before implementation."})
    return handoff


def _binding_shape(binding):
    if (not isinstance(binding, dict) or set(binding) != {"input_digest", "state_digest"}
            or any(not isinstance(value, str) or not re.fullmatch(r"[0-9a-f]{64}", value) for value in binding.values())):
        raise Invalid("A variable-review proposal must name the exact reviewed inputs and shared table snapshot.")


def _require_review_binding(base, name, actor_id, binding, allowed_packs):
    if binding is None:
        return
    _binding_shape(binding)
    import variable_review_workflow as workflow
    report = workflow.describe(base, name, actor_id, allowed_packs=allowed_packs)
    if (not report.get("ok") or report.get("current_phase") != "complete"
            or any(report.get(key) != value for key, value in binding.items())):
        raise Invalid("The reviewed variable tables changed or are incomplete. Reload and complete their reviews before preparing configuration.")
    return report


def _review_handoff(base, path, name, report, changes):
    import variable_execution_rules
    compiled = variable_execution_rules.build(report, load_config(path / "config/data_product.yaml"),
                                               supported_parameters(base, name))
    expected = compiled["configuration_changes"]
    if (not isinstance(changes, list) or any(not isinstance(row, dict) or set(row) != {"ref", "value"}
            or not isinstance(row["ref"], str) for row in changes)
            or _encode(sorted(changes, key=lambda row: row["ref"])) != _encode(sorted(expected, key=lambda row: row["ref"]))):
        raise Invalid("The configuration changes differ from the reviewed variable choices. Reload the execution proposal before staging.")
    return [{"kind": "reviewed_definition", "item_id": row.get("item_id", ""),
        "variable_id": row.get("variable_id", ""), "reason": row["message"],
        "required_work": row.get("required_work") or "Resolve this variable in the reviewed tables or provide a reviewed implementation, then prepare a fresh configuration proposal."}
        for row in compiled["blockers"]]


def _check_review_records(proposal):
    """Literal historical requirements only; no copied identities or approvals."""
    if "variable_review_binding" not in proposal:
        if "variable_review_records" in proposal:
            raise Invalid("Reviewed variable records require their originating review snapshot.")
        return
    records = proposal.get("variable_review_records")
    if not isinstance(records, list) or not 1 <= len(records) <= MAX_REVIEW_RECORDS:
        raise Invalid("The proposal needs its complete, bounded reviewed-variable snapshot. Prepare a fresh proposal.")
    import scientific_definitions as definitions
    import variable_review_family

    def literal(value, depth=0):
        if depth > 7:
            raise Invalid("A reviewed-variable snapshot is nested too deeply.")
        if isinstance(value, str):
            if len(value) > 65536 or any(ord(char) < 32 and char not in "\n\r\t" for char in value):
                raise Invalid("A reviewed-variable reference exceeds its text limit or contains control characters.")
        elif isinstance(value, dict):
            if len(value) > 2000 or any(not isinstance(key, str) for key in value):
                raise Invalid("Reviewed-variable fields must be bounded mappings with text keys.")
            for key, child in value.items():
                literal(key, depth + 1)
                literal(child, depth + 1)
        elif isinstance(value, list):
            if len(value) > 2000:
                raise Invalid("A reviewed-variable reference contains too many entries.")
            for child in value:
                literal(child, depth + 1)
        elif type(value) not in (bool, int, float, type(None)):
            raise Invalid("A reviewed-variable snapshot contains an unsupported value.")

    seen = set()
    for row in records:
        if (not isinstance(row, dict) or set(row) != set(REVIEW_RECORD_FIELDS)
                or not isinstance(row["definition"], str) or not isinstance(row["spec_values"], dict)
                or not isinstance(row["master_name"], str) or type(row["logic_reviewed"]) is not bool):
            raise Invalid("A reviewed-variable snapshot has unsupported or missing fields.")
        definitions._draft_name(row["item_id"])
        if row["item_id"] in seen:
            raise Invalid("The reviewed-variable snapshot repeats a specification row.")
        seen.add(row["item_id"])
        values = definitions._values(row["values"])
        if any(not isinstance(values.get(key), dict) for key in ("source", "output", "publish")):
            raise Invalid("Reviewed source, output and destination fields must preserve their structured mappings.")
        if row["variable_id"] != values["variable_id"]:
            raise Invalid("A reviewed-variable snapshot names inconsistent variable identifiers.")
        variable_review_family.validate(row["family"])
        literal(row)
    _encode(records)  # The same total byte limit as every other proposal artifact.


def _review_records(report):
    records = [{key: deepcopy(row[key]) for key in REVIEW_RECORD_FIELDS} for row in report["rows"]]
    _check_review_records({"variable_review_binding": True, "variable_review_records": records})
    return records


def _recorded_review_handoff(proposal):
    """Branch copies carry historical open work, never a fresh workflow claim."""
    rows = [row for row in proposal["engineering_handoff"] if row.get("kind") == "reviewed_definition"]
    if rows and "variable_review_binding" not in proposal:
        raise Invalid("Reviewed-definition work must identify its originating variable review.")
    if "variable_review_binding" in proposal:
        _binding_shape(proposal["variable_review_binding"])
    _check_review_records(proposal)
    if any(set(row) != {"kind", "item_id", "variable_id", "reason", "required_work"}
           or any(not isinstance(value, str) for value in row.values())
           or not row["reason"] or not row["required_work"] for row in rows):
        raise Invalid("The variable-review engineering handoff is incomplete.")
    records = {row["item_id"]: row["variable_id"] for row in proposal.get("variable_review_records", [])}
    if any((row["item_id"] or row["variable_id"]) and records.get(row["item_id"]) != row["variable_id"] for row in rows):
        raise Invalid("The engineering handoff names a variable absent from its reviewed snapshot.")
    return rows


def _review_binding_stale(base, path, binding):
    _binding_shape(binding)
    import variable_review_workflow as workflow
    state_path = workflow.definitions._safe(path / workflow.STORE)
    state_digest = workflow.definitions._hash(workflow.definitions._read(state_path)) if state_path.is_file() else ""
    return (state_digest != binding["state_digest"]
            or workflow._input_digest(base, path) != binding["input_digest"])


def stage(root, pack, brief, *, configuration_changes, study_exclusions, actor_id,
          local_demo, can_write, expected_baseline, allowed_packs=None, variable_review_binding=None):
    temporary = None
    try:
        _authorized(local_demo, can_write)
        base, path, name, owner, directory = _store(root, pack, actor_id, allowed_packs)
        description = dw.describe(base, name)
        if description["errors"] or not expected_baseline or expected_baseline != description["baseline_sha256"]:
            raise Invalid("The starting product changed or cannot be read. Reopen it before staging.")
        review_report = _require_review_binding(base, name, actor_id, variable_review_binding, allowed_packs)
        fingerprint = _snapshot(base, path)
        plan = _brief(description, brief)
        exclusions = _exclusions(plan, study_exclusions)
        files, handoff = _compose(path, configuration_changes)
        impact = _impact(base, path, plan, configuration_changes, exclusions)
        # Configuration-only and study-only briefs do not need an invented variable.
        errors = _plan_errors(plan)
        if errors:
            raise Invalid(" ".join(errors))
        handoff = _engineering_handoff(plan, impact, handoff)
        if variable_review_binding is not None:
            handoff.extend(_review_handoff(base, path, name, review_report, configuration_changes))
        if not files and not handoff and not exclusions:
            raise Invalid("No configuration change, study-only exclusion or engineering handoff is selected.")
        errors = impact["errors"][:]
        if impact["study_dependency_conflicts"]:
            errors.append("Study-only exclusions leave declared dependent variables in scope. Resolve the study dependency conflicts before submission.")
        identifier = uuid.uuid4().hex
        proposal = {"schema_version": 1, "proposal_id": identifier, "pack": name, "owner": owner,
                    "created_at": datetime.now(timezone.utc).isoformat(), "status": "staged",
                    "draft_only": True, "approved": False, "released": False, "can_submit": False,
                    "baseline_sha256": expected_baseline, "snapshot_sha256": fingerprint,
                    "purpose": plan["purpose"], "brief": plan,
                    "configuration_changes": configuration_changes, "files": files,
                    "study_exclusions": exclusions, "impact": impact, "engineering_handoff": handoff,
                    "errors": errors, "warnings": impact["notes"] + ["A submitted proposal requests local review only. It confers no scientific approval, release, execution or study-pin change."]}
        if variable_review_binding is not None:
            proposal["variable_review_binding"] = dict(variable_review_binding)
            proposal["variable_review_records"] = _review_records(review_report)
        artifacts = {"review.diff": "".join(f["diff"] for f in files).encode("utf-8"),
                     "STUDY_EXCLUSIONS.json": _encode({"draft_only": True, "study_exclusions": exclusions}),
                     "ENGINEERING_HANDOFF.json": _encode({"draft_only": True, "items": handoff})}
        artifacts.update({"candidate/" + f["path"]: f["after"].encode("utf-8") for f in files})
        proposal["artifacts"] = {rel: _digest(data) for rel, data in artifacts.items()}
        proposal["proposal_sha256"] = dw._hash(proposal)
        artifacts["proposal.json"] = _encode(proposal)
        destination = _folder(directory, identifier)
        dw._check_storage_paths([destination / rel for rel in artifacts]
                                + [destination / name for name in ("validation.json", "submission.json", ".receipt-" + "0" * 24)])
        directory.mkdir(parents=True, exist_ok=True)
        temporary = Path(tempfile.mkdtemp(prefix=".staging-", dir=_safe(directory)))
        for rel, data in artifacts.items():
            dest = temporary / rel
            dest.parent.mkdir(parents=True, exist_ok=True)
            dest.write_bytes(data)
        if _snapshot(base, path) != fingerprint or dw.describe(base, name)["baseline_sha256"] != expected_baseline:
            raise Invalid("Product or consumer inputs changed during staging. Rebuild the proposal.")
        current_review = _require_review_binding(base, name, actor_id, variable_review_binding, allowed_packs)
        if variable_review_binding is not None and dw._hash(_review_records(current_review)) != dw._hash(proposal["variable_review_records"]):
            raise Invalid("The reviewed variable definitions changed during staging. Prepare a fresh proposal.")
        os.rename(_safe(temporary), destination)
        temporary = None
        return load(base, name, proposal_id=identifier, actor_id=actor_id, allowed_packs=allowed_packs)
    except (OSError, ValueError, TypeError, KeyError, AttributeError, UnicodeError, RecursionError) as exc:
        return _failure(exc)
    finally:
        if temporary is not None and temporary.exists() and temporary.resolve() == temporary and temporary.parent == directory:
            shutil.rmtree(temporary)


def _load(base, path, name, owner, directory, proposal_id):
    folder = _folder(directory, proposal_id)
    proposal = _json(folder / "proposal.json")
    if (not isinstance(proposal, dict) or proposal.get("proposal_id") != proposal_id
            or proposal.get("pack") != name or proposal.get("owner") != owner
            or proposal.get("status") != "staged" or proposal.get("draft_only") is not True
            or proposal.get("approved") is not False or proposal.get("released") is not False
            or proposal.get("proposal_sha256") != dw._hash({k: v for k, v in proposal.items() if k != "proposal_sha256"})):
        raise Invalid("The staged proposal identity or contents changed. Create a fresh proposal.")
    expected = {"review.diff", "STUDY_EXCLUSIONS.json", "ENGINEERING_HANDOFF.json"}
    expected.update("candidate/" + f["path"] for f in proposal["files"])
    if set(proposal["artifacts"]) != expected:
        raise Invalid("The staged proposal artifact list is incomplete.")
    allowed_files = {ref.split("#/", 1)[0] for ref in PARAMETERS}
    if any(f["path"] not in allowed_files for f in proposal["files"]):
        raise Invalid("The proposal contains an unsupported candidate file.")
    for rel, digest in proposal["artifacts"].items():
        if _digest(_read(folder / rel)) != digest:
            raise Invalid("A staged artifact changed. Stage a fresh proposal before validation or submission.")
    for f in proposal["files"]:
        if _read(folder / "candidate" / f["path"]) != f["after"].encode("utf-8"):
            raise Invalid("Candidate bytes differ from the reviewed proposal.")
    stale = _snapshot(base, path) != proposal["snapshot_sha256"] or dw.describe(base, name)["baseline_sha256"] != proposal["baseline_sha256"]
    if "variable_review_binding" in proposal:
        _check_review_records(proposal)
        stale = _review_binding_stale(base, path, proposal["variable_review_binding"]) or stale
    elif "variable_review_records" in proposal:
        _check_review_records(proposal)
    return proposal, folder, stale


def _check_validation_consistency(validation):
    """A saved check cannot exempt an engine failure or claim an unfinished run passed."""
    if (not isinstance(validation, dict) or type(validation.get("passed")) is not bool
            or not isinstance(validation.get("checks"), list) or not isinstance(validation.get("errors"), list)):
        raise Invalid("The validation receipt is incomplete. Run the proposal validators again.")
    seen = set()
    for check in validation["checks"]:
        if (not isinstance(check, dict) or not isinstance(check.get("validator"), str) or not check["validator"]
                or check["validator"] in seen or type(check.get("passed")) is not bool
                or type(check.get("completed", True)) is not bool or type(check.get("pre_existing", False)) is not bool
                or not isinstance(check.get("errors"), list)):
            raise Invalid("The saved validator checks are malformed or repeated. Run the proposal validators again.")
        seen.add(check["validator"])
        if check["passed"] and (check.get("completed") is False or check["errors"]):
            raise Invalid("A failed or unfinished validator cannot be reported as passed. Run the proposal validators again.")
        if check.get("pre_existing") is True and (check["validator"] not in PRE_EXISTING_EXEMPT
                or check.get("completed") is False or check["passed"]):
            raise Invalid("Only completed existing scientific findings can be carried as caveats; strict engine validation cannot be exempted. Run the proposal validators again.")
    if seen - REQUIRED_VALIDATORS:
        raise Invalid("The saved checks name an unsupported validator. Run the proposal validators again.")
    if validation["passed"] and (seen != REQUIRED_VALIDATORS or validation["errors"] or
            not all(check["passed"] or check.get("pre_existing") is True for check in validation["checks"])):
        raise Invalid("The saved validation does not contain all required passing checks. Run the proposal validators again.")


def _read_receipt(file, proposal):
    record = _json(file)
    if (not isinstance(record, dict) or record.get("proposal_sha256") != proposal["proposal_sha256"]
            or record.get("receipt_sha256") != dw._hash({k: v for k, v in record.items() if k != "receipt_sha256"})):
        raise Invalid("The proposal receipt changed or belongs to different candidate bytes.")
    if file.name == "submission.json" and (
            record.get("status") != "submitted_for_review" or record.get("draft_only") is not True
            or record.get("approved") is not False or record.get("released") is not False
            or record.get("proposal_id") != proposal["proposal_id"]):
        raise Invalid("A proposal receipt can record a review request only, never approval or release.")
    if file.name == "submission.json" and "request_id" in record and (
            not isinstance(record["request_id"], str) or not re.fullmatch(r"[0-9a-f]{32}", record["request_id"])):
        raise Invalid("The submission receipt names a review request that cannot exist.")
    validation = record.get("validation") if file.name == "submission.json" else record
    _check_validation_consistency(validation)
    if validation.get("proposal_sha256") != proposal["proposal_sha256"] or (
            file.name == "submission.json" and validation["passed"] is not True):
        raise Invalid("A submission receipt requires passing validation of these exact proposal bytes.")
    return record


def load(root, pack, *, proposal_id, actor_id, allowed_packs=None):
    try:
        base, path, name, owner, directory = _store(root, pack, actor_id, allowed_packs)
        proposal, folder, stale = _load(base, path, name, owner, directory, proposal_id)
        validation, validation_error = None, ""
        if (folder / "validation.json").exists():
            try:
                validation = _read_receipt(folder / "validation.json", proposal)
            except (ValueError, TypeError, KeyError, AttributeError, UnicodeError, RecursionError) as exc:
                # Keep the immutable proposal and its existing revalidation
                # action reachable. The invalid receipt is preserved until an
                # explicit fresh validator run replaces it; it confers no state.
                validation_error = str(exc)
        submission = _read_receipt(folder / "submission.json", proposal) if (folder / "submission.json").exists() else None
        can_submit = bool(validation and validation.get("passed") is True and not stale and not submission
                          and not proposal["errors"] and not proposal["engineering_handoff"])
        return {"ok": True, "proposal_id": proposal_id, "proposal_sha256": proposal["proposal_sha256"],
                "path": folder.relative_to(base).as_posix(), "proposal": proposal, "stale": stale,
                "validation": validation, "submission": submission, "can_submit": can_submit,
                "validation_error": validation_error,
                "review_request": (submission or {}).get("request_id"), "errors": []}
    except (OSError, ValueError, TypeError, KeyError, AttributeError, UnicodeError, RecursionError) as exc:
        return _failure(exc)


def list_proposals(root, pack, *, actor_id, allowed_packs=None):
    try:
        base, path, name, owner, directory = _store(root, pack, actor_id, allowed_packs)
        proposals, errors = [], []
        if directory.exists():
            for folder in sorted(directory.iterdir()):
                if not re.fullmatch(r"[0-9a-f]{32}", folder.name):
                    continue
                result = load(base, name, proposal_id=folder.name, actor_id=actor_id, allowed_packs=allowed_packs)
                if result["ok"]:
                    proposals.append({"proposal_id": folder.name, "purpose": result["proposal"]["purpose"],
                                      "created_at": result["proposal"]["created_at"], "stale": result["stale"]})
                else:
                    errors.extend(result["errors"])
        return {"ok": True, "proposals": sorted(proposals, key=lambda p: p["created_at"], reverse=True), "errors": errors}
    except (OSError, ValueError, TypeError, KeyError, UnicodeError) as exc:
        return {**_failure(exc), "proposals": []}


def _share_ingress(value):
    # Scan the complete selected packet before preview/persistence, never an excerpt.
    import scientific_definition_ai as ai
    ai._ingress(_encode(value).decode("utf-8"))


def _shared_file(path, packet_id):
    if not isinstance(packet_id, str) or not re.fullmatch(r"[a-f0-9]{32}", packet_id):
        raise Invalid("Choose an existing branch proposal handoff.")
    return _safe(path / SHARED_FOLDER / (packet_id + ".json"))


def _shared_inputs(proposal):
    plan = proposal["brief"]
    source = plan["source"]["proposed"]
    return dw._inputs({"retained": plan["kept"], "additions": plan["added"], "purpose": plan["purpose"],
        "studies": plan["studies"], "target_source": source["vendor"], "target_modality": source["modality"]})


def _branch_text_baseline(base, path, name):
    entry = dw.pg.registry_entry(str(base), name) or {}
    return dw._hash(dw._baseline(path, name, entry if isinstance(entry, dict) else {}, branch_text=True))


def _branch_text(value):
    if isinstance(value, str):
        return value.replace("\r\n", "\n")
    if isinstance(value, dict):
        return {key: _branch_text(item) for key, item in value.items()}
    if isinstance(value, (list, tuple)):
        return [_branch_text(item) for item in value]
    return value


def _check_shared(packet, name):
    if (not isinstance(packet, dict) or set(packet) != {"schema_version", "packet_id", "pack", "proposal", "validation", "historical_submission", "notice", "digest", "baseline_text_sha256"}
            or packet["schema_version"] != 1 or packet["pack"] != name
            or not re.fullmatch(r"[a-f0-9]{64}", str(packet["baseline_text_sha256"]))
            or packet["digest"] != dw._hash({k: v for k, v in packet.items() if k != "digest"})):
        raise Invalid("The branch proposal handoff is unreadable or changed.")
    proposal = packet["proposal"]
    if (not isinstance(proposal, dict) or proposal.get("pack") != name or proposal.get("status") != "staged"
            or proposal.get("draft_only") is not True or proposal.get("approved") is not False or proposal.get("released") is not False
            or not re.fullmatch(r"[a-f0-9]{32}", str(proposal.get("proposal_id", "")))
            or proposal.get("proposal_sha256") != dw._hash({k: v for k, v in proposal.items() if k != "proposal_sha256"})):
        raise Invalid("The shared proposal must preserve its exact unapproved draft snapshot.")
    _shared_inputs(proposal)
    _recorded_review_handoff(proposal)
    if proposal.get("purpose") != proposal["brief"].get("purpose"):
        raise Invalid("The shared purpose differs from its declared planning inputs.")
    _exclusions(proposal["brief"], proposal["study_exclusions"])
    changes = proposal["configuration_changes"]
    if (not isinstance(changes, list) or len(changes) > 100
            or any(not isinstance(c, dict) or set(c) != {"ref", "value"} or not isinstance(c["ref"], str) for c in changes)
            or len({c["ref"] for c in changes}) != len(changes)):
        raise Invalid("The shared handoff has inconsistent setting selections.")
    files = proposal["files"]
    allowed = {ref.split("#/", 1)[0] for ref in PARAMETERS}
    if (not isinstance(files, list) or len(files) > len(allowed)
            or any(not isinstance(f, dict) or set(f) != {"path", "before", "after", "diff", "semantic_diff"}
                   or f["path"] not in allowed or any(not isinstance(f[k], str) for k in ("before", "after", "diff")) for f in files)
            or len({f["path"] for f in files}) != len(files)):
        raise Invalid("The shared handoff names unsupported or duplicate configuration files.")
    # A rehashed foreign packet is untrusted input. Prove each displayed candidate
    # is exactly its declared allowlisted scalar edits, without writing its paths.
    for file in files:
        after = file["before"]
        for change in changes:
            ref = change["ref"]
            if ref in PARAMETERS and ref.split("#/", 1)[0] == file["path"]:
                value = _value(ref, change["value"])
                after = _patch_parameter(after, ref, value)
        expected_diff = "".join(difflib.unified_diff(file["before"].splitlines(True), after.splitlines(True),
            fromfile="a/" + file["path"], tofile="b/" + file["path"]))
        if (after == file["before"] or after != file["after"] or expected_diff != file["diff"]
                or _encode(config_diff.diff_docs(_parse(file["before"]), _parse(after))) != _encode(file["semantic_diff"])):
            raise Invalid("The shared candidate does not match its declared supported settings.")
    artifacts = {"review.diff": _digest("".join(f["diff"] for f in files).encode()),
        "STUDY_EXCLUSIONS.json": _digest(_encode({"draft_only": True, "study_exclusions": proposal["study_exclusions"]})),
        "ENGINEERING_HANDOFF.json": _digest(_encode({"draft_only": True, "items": proposal["engineering_handoff"]}))}
    artifacts.update({"candidate/" + f["path"]: _digest(f["after"].encode()) for f in files})
    if artifacts != proposal["artifacts"]:
        raise Invalid("The shared proposal artifacts differ from the reviewed snapshot.")
    validation = packet["validation"]
    if validation is not None and (not isinstance(validation, dict)
            or validation.get("proposal_sha256") != proposal["proposal_sha256"]
            or validation.get("receipt_sha256") != dw._hash({k: v for k, v in validation.items() if k != "receipt_sha256"})):
        raise Invalid("Historical validation does not belong to this proposal.")
    if validation is not None:
        _check_validation_consistency(validation)
    history = packet["historical_submission"]
    if history is not None and (not isinstance(history, dict) or set(history) != {"request_id", "submitted_at", "receipt_sha256"}
            or not re.fullmatch(r"[a-f0-9]{32}", str(history.get("request_id", "")))
            or not re.fullmatch(r"[a-f0-9]{64}", str(history.get("receipt_sha256", "")))
            or history.get("submitted_at") is not None and (not isinstance(history["submitted_at"], str) or len(history["submitted_at"]) > 80)):
        raise Invalid("A branch handoff can retain a submission reference only; reviewer decisions are not portable authority.")
    expected_id = dw._hash({"proposal": proposal["proposal_sha256"], "validation": validation,
        "submission": packet["historical_submission"], "baseline_text": packet["baseline_text_sha256"]})[:32]
    if packet["packet_id"] != expected_id:
        raise Invalid("The branch handoff identity does not match its snapshot.")
    _share_ingress(packet)
    return packet


def share_preview(root, pack, *, proposal_id, actor_id, allowed_packs=None):
    """Explicitly selected existing artifacts only; never export other private work."""
    try:
        loaded = load(root, pack, proposal_id=proposal_id, actor_id=actor_id, allowed_packs=allowed_packs)
        if not loaded.get("ok") or loaded["stale"] or loaded.get("validation_error"):
            raise Invalid("Reopen a current intact proposal before preparing its branch handoff.")
        submission = loaded.get("submission")
        base, path, name = _path(root, pack, allowed_packs)
        history = ({key: submission.get(key) for key in ("request_id", "submitted_at", "receipt_sha256")}
                   if submission else None)
        packet = {"schema_version": 1, "pack": loaded["proposal"]["pack"], "proposal": loaded["proposal"],
            "validation": loaded.get("validation"), "historical_submission": history, "notice": SHARED_NOTICE,
            "baseline_text_sha256": _branch_text_baseline(base, path, name)}
        packet["packet_id"] = dw._hash({"proposal": loaded["proposal_sha256"], "validation": packet["validation"], "submission": history,
            "baseline_text": packet["baseline_text_sha256"]})[:32]
        packet["digest"] = dw._hash(packet)
        _check_shared(packet, packet["pack"])
        return {"ok": True, "packet": packet, "digest": packet["digest"], "packet_id": packet["packet_id"],
                "path": packet["pack"] + "/" + SHARED_FOLDER + "/" + packet["packet_id"] + ".json"}
    except (OSError, ValueError, TypeError, KeyError, UnicodeError, RecursionError) as exc:
        return _failure(exc)


def share(root, pack, *, proposal_id, actor_id, expected_digest, confirmed=False, local_demo=False, can_write=False, allowed_packs=None):
    try:
        _authorized(local_demo, can_write)
        if confirmed is not True:
            raise Invalid("Review the complete branch handoff and confirm sharing those exact records.")
        preview = share_preview(root, pack, proposal_id=proposal_id, actor_id=actor_id, allowed_packs=allowed_packs)
        if not preview.get("ok") or preview["digest"] != expected_digest:
            raise Invalid("The proposal or its checks changed. Review a fresh handoff preview.")
        base, path, name = _path(root, pack, allowed_packs)
        target = _shared_file(path, preview["packet_id"])
        if target.exists():
            if _check_shared(_json(target), name) != preview["packet"]:
                raise Invalid("A different branch handoff already uses this identity.")
            return {**preview, "changed": False}
        target.parent.mkdir(parents=True, exist_ok=True)
        # Publish complete bytes without clobbering a concurrent conflicting file.
        # The link is on the same filesystem and the random temporary file is ours.
        temporary = None
        try:
            with tempfile.NamedTemporaryFile(prefix=".sharing-", dir=target.parent, delete=False) as stream:
                temporary = Path(stream.name)
                stream.write(_encode(preview["packet"]))
                stream.flush()
                os.fsync(stream.fileno())
            try:
                os.link(temporary, target)
            except FileExistsError:
                if _check_shared(_json(target), name) != preview["packet"]:
                    raise Invalid("A different branch handoff was saved concurrently. It was not overwritten.")
                return {**preview, "changed": False}
        finally:
            if temporary is not None:
                _safe(temporary).unlink(missing_ok=True)
        return {**preview, "changed": True}
    except (OSError, ValueError, TypeError, KeyError, UnicodeError, RecursionError) as exc:
        return _failure(exc)


def load_shared(root, pack, *, packet_id, actor_id, allowed_packs=None):
    try:
        base, path, name, _owner, _directory = _store(root, pack, actor_id, allowed_packs)
        packet = _check_shared(_json(_shared_file(path, packet_id)), name)
        if packet["packet_id"] != packet_id:
            raise Invalid("The handoff filename does not match its record.")
        description = dw.describe(base, name)
        baseline = description["baseline_sha256"]
        same_text = _branch_text_baseline(base, path, name) == packet["baseline_text_sha256"]
        if same_text:
            proposal = packet["proposal"]
            # Rebuild the origin plan's metadata only to compare intentions.
            # The eventual stage always receives the current exact raw baseline.
            origin_description = {**description, "baseline_sha256": proposal["baseline_sha256"],
                "contract_sha256": proposal["brief"]["contract_sha256"]}
            plan = _brief(origin_description, proposal["brief"])
            files, unsupported = _compose(path, proposal["configuration_changes"])
            impact = _impact(base, path, plan, proposal["configuration_changes"], proposal["study_exclusions"])
            if (_encode(plan) != _encode(proposal["brief"]) or _encode(_branch_text(files)) != _encode(_branch_text(proposal["files"]))
                    or _encode(_engineering_handoff(plan, impact, unsupported) + _recorded_review_handoff(proposal)) != _encode(proposal["engineering_handoff"])):
                raise Invalid("The shared handoff omits or changes part of its declared proposal. Restaging cannot introduce hidden changes.")
        return {"ok": True, "packet": packet, "packet_id": packet_id, "digest": packet["digest"],
                "baseline_sha256": baseline, "stale": not same_text,
                "line_endings_changed": same_text and baseline != packet["proposal"]["baseline_sha256"], "notice": SHARED_NOTICE}
    except (OSError, ValueError, TypeError, KeyError, UnicodeError, RecursionError) as exc:
        return _failure(exc)


def list_shared(root, pack, *, actor_id, allowed_packs=None, page=0, page_size=20):
    """Read one bounded page of validated packet metadata, without recomposing each product."""
    try:
        if type(page) is not int or page < 0 or type(page_size) is not int or not 1 <= page_size <= 50:
            raise Invalid("Choose a valid handoff history page.")
        base, path, name, _owner, _directory = _store(root, pack, actor_id, allowed_packs)
        folder = _safe(path / SHARED_FOLDER)
        files = sorted(f for f in folder.glob("*.json") if re.fullmatch(r"[a-f0-9]{32}", f.stem)) if folder.is_dir() else []
        page = min(page, max(0, (len(files) - 1) // page_size))
        baseline = _branch_text_baseline(base, path, name) if files else None
        records, errors = [], []
        for file in files[page * page_size:(page + 1) * page_size]:
            try:
                packet = _check_shared(_json(_shared_file(path, file.stem)), name)
                if packet["packet_id"] != file.stem:
                    raise Invalid("The handoff filename does not match its record.")
                records.append({"packet_id": file.stem, "purpose": packet["proposal"]["purpose"],
                                "stale": baseline != packet["baseline_text_sha256"]})
            except (OSError, ValueError, TypeError, KeyError, UnicodeError, RecursionError) as exc:
                errors.extend(_failure(exc)["errors"])
        return {"ok": True, "records": records, "errors": errors, "page": page, "page_size": page_size,
                "total": len(files), "has_next": (page + 1) * page_size < len(files)}
    except (OSError, ValueError, TypeError, KeyError, UnicodeError, RecursionError) as exc:
        return {**_failure(exc), "records": []}


def request_engineering(root, pack, *, proposal_id, actor_id, expected_digest, note,
                        confirmed=False, local_demo=False, can_write=False, allowed_packs=None):
    """Share the explicitly reviewed snapshot, then reference its full immutable identity."""
    import handoffs
    try:
        _authorized(local_demo, can_write)
        # Validate user text before publishing any shared bytes.
        handoffs._text(note, "the details the engineer needs")
        _share_ingress(note)
        preview = share_preview(root, pack, proposal_id=proposal_id, actor_id=actor_id, allowed_packs=allowed_packs)
        if not preview.get("ok") or not preview["packet"]["proposal"]["engineering_handoff"]:
            raise Invalid("Choose a current proposal with unresolved engineering work.")
        saved = share(root, pack, proposal_id=proposal_id, actor_id=actor_id, expected_digest=expected_digest,
            confirmed=confirmed, local_demo=local_demo, can_write=can_write, allowed_packs=allowed_packs)
        if not saved.get("ok"):
            return saved
        reference = "configuration-proposal:" + saved["packet_id"] + ":" + saved["digest"]
        for doc in handoffs.listing(root, pack, allowed_packs=allowed_packs, include_closed=False):
            if doc.get("action_id") == reference:
                return {"ok": True, "handoff": doc, "packet_id": saved["packet_id"], "changed": False}
        doc = handoffs.create(root, pack, title="Review the requested implementation changes", owner="Engineering",
            note=note, requested_by=actor_id, action_id=reference, allowed_packs=allowed_packs,
            local_demo=local_demo, can_view=True)
        return {"ok": True, "handoff": doc, "packet_id": saved["packet_id"], "changed": True}
    except (OSError, ValueError, TypeError, KeyError, UnicodeError, RecursionError, handoffs.Refused) as exc:
        return _failure(exc)


def load_engineering_request(root, pack, handoff_id, *, actor_id, allowed_packs=None):
    import handoffs
    try:
        doc = handoffs.load(root, pack, handoff_id, allowed_packs=allowed_packs)
        reference = re.fullmatch(r"configuration-proposal:([a-f0-9]{32}):([a-f0-9]{64})", str(doc.get("action_id", "")))
        if not reference:
            raise Invalid("This engineering request has no exact proposal reference.")
        loaded = load_shared(root, pack, packet_id=reference[1], actor_id=actor_id, allowed_packs=allowed_packs)
        if not loaded.get("ok") or loaded["digest"] != reference[2]:
            raise Invalid("The engineering request's exact shared proposal is missing or changed. Ask its author to share a fresh reviewed handoff.")
        return {**loaded, "handoff": doc}
    except (OSError, ValueError, TypeError, KeyError, UnicodeError, RecursionError, handoffs.Refused) as exc:
        return _failure(exc)


def shared_revision_preview(root, pack, *, packet_id, actor_id, allowed_packs=None):
    """Prepare reviewed intent for the existing editor; never import validation or write a draft."""
    try:
        loaded = load_shared(root, pack, packet_id=packet_id, actor_id=actor_id, allowed_packs=allowed_packs)
        if not loaded.get("ok"):
            return loaded
        original = loaded["packet"]["proposal"]
        description = dw.describe(root, pack)
        if description["errors"]:
            raise Invalid("The current product needs repair before revising this handoff.")
        current = {row["variable_id"] for row in description["rows"]}
        old = set(original["brief"]["kept"]) | set(original["brief"]["removed"])
        conflicts = []
        if original["brief"]["contract_sha256"] != description["contract_sha256"]:
            conflicts.append({"Item": "Scientific definitions", "Change": "The contract changed since this handoff",
                "Restoration": "Review current meanings and dependencies; old selections do not approve the revised definitions."})
        for variable in sorted(old - current):
            conflicts.append({"Item": variable, "Change": "No longer in the current contract", "Restoration": "Not selected; review its intended study use."})
        for variable in sorted(current - old):
            conflicts.append({"Item": variable, "Change": "Added to the current contract", "Restoration": "Retained; this handoff did not request removing it."})
        values = _shared_inputs(original)
        values["retained"] = [row["variable_id"] for row in description["rows"] if row["variable_id"] not in original["brief"]["removed"]]
        if not original["brief"]["source_changed"]:
            values.update(target_source=description["source"]["vendor"], target_modality=description["source"]["modality"])
        elif original["brief"]["source"]["current"] != description["source"]:
            conflicts.append({"Item": "Data source", "Change": "The baseline source changed", "Restoration": "The explicitly proposed source is retained for review."})
        plan = dw.build_plan(description, **values)
        exclusions = []
        for row in original["study_exclusions"]:
            kept = [v for v in row["variables"] if v in plan["removed"]]
            if kept:
                exclusions.append({"study": row["study"], "variables": kept})
            missing = sorted(set(row["variables"]) - set(kept))
            if missing:
                conflicts.append({"Item": row["study"], "Change": "Excluded definitions are absent: " + ", ".join(missing),
                                  "Restoration": "These exclusions cannot be restored; reconsider the study's current choices."})
        supported = supported_parameters(root, pack)
        settings = []
        for change in original["configuration_changes"]:
            ref = change["ref"]
            present = supported.get(ref)
            previous = next((f["before"] for f in original["files"] if f["path"] == ref.split("#/", 1)[0]), None)
            prior = None
            if previous is not None and ref in PARAMETERS:
                prior = _parse(previous)
                for part in ref.split("#/", 1)[1].split("/"):
                    prior = prior.get(part) if isinstance(prior, dict) else None
            settings.append({"Setting": present[0] if present else ref, "Original": prior,
                "Current": present[2] if present else "Unsupported", "Requested": change["value"]})
            if present and (prior is None or type(prior) is not type(present[2]) or prior != present[2]):
                conflicts.append({"Item": present[0], "Change": "Current value differs or the old value is unavailable",
                    "Restoration": "The explicit requested value is retained for editing."})
        try:
            files, unsupported = _compose(Path(root) / pack, original["configuration_changes"])
            preview_errors = list(plan["errors"])
        except (ValueError, OSError) as exc:
            files, preview_errors = [], list(plan["errors"]) + _failure(exc)["errors"]
        restored = {"brief": plan, "baseline_sha256": description["baseline_sha256"],
            "configuration_changes": original["configuration_changes"], "study_exclusions": exclusions}
        result = {"ok": True, "packet_id": packet_id, "packet_digest": loaded["digest"],
            "baseline_sha256": description["baseline_sha256"], "restore": restored, "conflicts": conflicts,
            "snapshot_sha256": _snapshot(Path(root).resolve(), Path(root).resolve() / pack),
            "impact": _impact(Path(root).resolve(), Path(root).resolve() / pack, plan, original["configuration_changes"], exclusions),
            "settings": settings, "files": files, "errors": preview_errors,
            "unsupported_changes": [c for c in original["configuration_changes"] if c["ref"] not in supported],
            "notice": "Copying this intent only fills an unfinished revision. Review every changed selection, stage a new diff and run fresh validators. Prior checks, submission and approvals are not carried forward."}
        _share_ingress(result)
        return {**result, "digest": dw._hash(result)}
    except (OSError, ValueError, TypeError, KeyError, UnicodeError, RecursionError) as exc:
        return _failure(exc)


def restage_shared(root, pack, *, packet_id, actor_id, expected_digest, expected_baseline,
                   confirmed=False, local_demo=False, can_write=False, allowed_packs=None):
    try:
        _authorized(local_demo, can_write)
        if confirmed is not True:
            raise Invalid("Review the branch handoff and confirm a new local proposal.")
        loaded = load_shared(root, pack, packet_id=packet_id, actor_id=actor_id, allowed_packs=allowed_packs)
        if not loaded.get("ok") or loaded["digest"] != expected_digest or loaded["stale"] or loaded["baseline_sha256"] != expected_baseline:
            raise Invalid("The branch handoff or product changed. Review the differences before creating a new proposal.")
        proposal = loaded["packet"]["proposal"]
        plan = dw.build_plan(dw.describe(root, pack), **_shared_inputs(proposal))
        if plan["removed"] != proposal["brief"]["removed"]:
            raise Invalid("The current definitions no longer match these retained and removed selections.")
        return stage(root, pack, plan, configuration_changes=proposal["configuration_changes"],
            study_exclusions=proposal["study_exclusions"], actor_id=actor_id, expected_baseline=expected_baseline,
            local_demo=local_demo, can_write=can_write, allowed_packs=allowed_packs)
    except (OSError, ValueError, TypeError, KeyError, UnicodeError, RecursionError) as exc:
        return _failure(exc)


def _run_validators(root, candidate_pack):
    """Existing pure-Python gates; never execute the proposed derivations."""
    checks = []
    def check(name, fn):
        try:
            errors, detail = fn()
            checks.append({"validator": name, "passed": not errors, "errors": list(errors), "detail": detail, "completed": True})
        except Exception as exc:  # A gate that cannot run is a failed gate.
            checks.append({"validator": name, "passed": False, "completed": False, "errors": [f"{type(exc).__name__}: {exc}"]})
    check("engine.validate (strict)", lambda: (problems(load_config(candidate_pack / "config/data_product.yaml"), strict=True), {}))
    check("contract_lint", lambda: dw.cl.run(str(candidate_pack)))
    check("contract_binding", lambda: cb.check(str(candidate_pack), cb.pack_yaml(str(candidate_pack))))
    def blocks():
        return cb.governed_blocks(str(candidate_pack), cb.pack_yaml(str(candidate_pack)))
    check("contract_binding parameters", lambda: cb.compare_parameters(str(candidate_pack), blocks()))
    def enumerations():
        read = cb.enumerations_read(str(candidate_pack))
        errors = cb.compare_enumerations(str(candidate_pack), blocks())
        if read["present"] and not read["parsed"]:
            errors.append("The specification enumeration artifact could not be parsed.")
        return errors, {"present": read["present"], "parsed": read["parsed"],
                        "enumeration_groups": len(read["enumerations"])}
    check("contract_binding enumerations", enumerations)
    for result in checks:
        detail = result.get("detail")
        if isinstance(detail, dict) and detail.get("compared") == 0:
            result["note"] = "No readable parameter comparisons were made; this does not establish agreement with the scientific requirement."
        if isinstance(detail, dict) and detail.get("enumeration_groups") == 0:
            result["note"] = "No declared enumeration groups were compared; this does not establish agreement on codes or categories."
    return checks


def _candidate(base, path, proposal, target):
    """Mirror ancestry for root-sensitive validators, omitting all portal artifacts."""
    (target / "platform/tools").mkdir(parents=True)
    for file in _tree_files(path):
        dest = target / file.relative_to(base)
        dest.parent.mkdir(parents=True, exist_ok=True)
        _copy(file, dest)
    for rel in SHARED_INPUTS:
        source = base / rel
        for file in _tree_files(source) if source.is_dir() else ([source] if source.is_file() else []):
            dest = target / file.relative_to(base)
            dest.parent.mkdir(parents=True, exist_ok=True)
            _copy(file, dest)
    for file in proposal["files"]:
        (target / proposal["pack"] / file["path"]).write_bytes(file["after"].encode("utf-8"))
    return target / proposal["pack"]


def validate_files(base, path, name, files):
    """Run the existing gates on an isolated copy of the product carrying these candidate files.

    One entry point for the two moments a candidate is checked: when its author validates the
    staged proposal and when a reviewer validates the applied draft revision. The product itself
    is never the candidate; the copy is discarded once the gates have reported.
    """
    with tempfile.TemporaryDirectory(prefix="rwd-config-review-") as temporary:
        target = Path(temporary).resolve()
        candidate = _candidate(base, path, {"pack": name, "files": files}, target)
        return _run_validators(target, candidate)


# The checks a product between Gate 2 and Gate 4 fails for reasons a supported setting does not
# touch; a failure that is identical without the change is a caveat for the reviewer, not a block.
# The strict engine validation of the changed configuration is never exempt.
PRE_EXISTING_EXEMPT = frozenset({"contract_lint", "contract_binding", "contract_binding parameters", "contract_binding enumerations"})
REQUIRED_VALIDATORS = PRE_EXISTING_EXEMPT | {"engine.validate (strict)"}


def _validate(base, path, name, owner, directory, proposal_id):
    proposal, folder, stale = _load(base, path, name, owner, directory, proposal_id)
    if stale:
        raise Invalid("Product or declared consumer inputs changed since staging. Create a fresh proposal.")
    # Checksums detect accidents; they are not an authorization mechanism. Rebuild
    # the candidate from the supported inputs before letting any saved bytes run
    # through the validators, even if somebody recomputed a packet checksum.
    description = dw.describe(base, name)
    plan = _brief(description, proposal["brief"])
    exclusions = _exclusions(plan, proposal["study_exclusions"])
    files, unsupported = _compose(path, proposal["configuration_changes"])
    impact = _impact(base, path, plan, proposal["configuration_changes"], exclusions)
    if dw._hash(files) != dw._hash(proposal["files"]) or dw._hash(impact) != dw._hash(proposal["impact"]):
        raise Invalid("The staged configuration or impact no longer matches its supported inputs. Stage a fresh proposal.")
    if "variable_review_binding" in proposal:
        report = _require_review_binding(base, name, owner, proposal["variable_review_binding"], [name])
        if dw._hash(_review_records(report)) != dw._hash(proposal["variable_review_records"]):
            raise Invalid("The staged variable definitions differ from the reviewed table. Prepare a fresh proposal.")
        expected_handoff = _engineering_handoff(plan, impact, unsupported)
        expected_handoff.extend(_review_handoff(base, path, name, report, proposal["configuration_changes"]))
        if _encode(expected_handoff) != _encode(proposal["engineering_handoff"]):
            raise Invalid("The staged proposal no longer includes the reviewed variables' implementation work. Prepare a fresh proposal.")
    checks = validate_files(base, path, name, proposal["files"])
    # A FAILURE THE PRODUCT ALREADY HAD IS NOT THIS PROPOSAL'S (walk UC3-P1-4, 2026-09-07): a product
    # between Gate 2 and Gate 4 fails contract lint or binding for reasons the proposed setting does
    # not touch. Those checks are run once more on the product as it stands; a validator that fails
    # there with the same reasons is recorded as pre-existing, shown to the reviewer as a caveat, and
    # does not block submission. A failure the proposal ADDS still blocks.
    needs_baseline = any(not c.get("passed") and c["validator"] in PRE_EXISTING_EXEMPT for c in checks)
    baseline = {c["validator"]: c for c in validate_files(base, path, name, {})} if needs_baseline else {}
    caveats = []
    for check in checks:
        if check.get("passed") or check["validator"] not in PRE_EXISTING_EXEMPT:
            continue        # the changed configuration itself must always validate (engine.validate strict)
        before = baseline.get(check["validator"])
        if (before and check.get("completed", True) and before.get("completed", True)
                and not before.get("passed") and set(check.get("errors") or []) <= set(before.get("errors") or [])):
            check["pre_existing"] = True
            caveats.append(f"{check['validator']} already fails on this product without the proposed change "
                           f"({len(before.get('errors') or [])} reason(s)); the reviewer sees them as the product's own open work.")
    # Check both original inputs and exact reviewed bytes again after validation.
    fresh, _folder_, stale = _load(base, path, name, owner, directory, proposal_id)
    if stale or fresh["proposal_sha256"] != proposal["proposal_sha256"]:
        raise Invalid("Proposal or product inputs changed during validation. Stage and validate a fresh proposal.")
    errors = list(proposal["errors"]) + impact["errors"] + _plan_errors(plan)
    if impact["study_dependency_conflicts"]:
        errors.append("Study exclusions leave unresolved declared dependencies.")
    if proposal["engineering_handoff"] or unsupported or plan["added"] or plan["source_changed"] or impact["shared_removed"]:
        errors.append("Engineering handoff remains unresolved. Stage supported changes separately before submission.")
    if len(checks) != len(REQUIRED_VALIDATORS) or {check.get("validator") for check in checks} != REQUIRED_VALIDATORS:
        errors.append("The complete required validator set did not run. Run all proposal validators again.")
    passed = bool(checks) and all(c.get("passed") is True or c.get("pre_existing") is True for c in checks) and not errors
    return {"ok": True, "passed": passed, "proposal_sha256": proposal["proposal_sha256"],
            "validated_at": datetime.now(timezone.utc).isoformat(), "checks": checks, "errors": errors,
            "caveats": caveats}, folder


def _receipt(folder, name, record):
    target = _safe(folder / name)
    temp = _safe(folder / (".receipt-" + uuid.uuid4().hex[:24]))
    try:
        saved = {**record, "receipt_sha256": dw._hash(record)}
        temp.write_bytes(_encode(saved))
        os.replace(temp, target)
    finally:
        if temp.exists() and temp.resolve() == temp and temp.parent == folder:
            temp.unlink()


def validate(root, pack, *, proposal_id, actor_id, local_demo, can_write, allowed_packs=None):
    try:
        _authorized(local_demo, can_write)
        context = _store(root, pack, actor_id, allowed_packs)
        result, folder = _validate(*context, proposal_id)
        _receipt(folder, "validation.json", result)
        return result
    except (OSError, ValueError, TypeError, KeyError, AttributeError, UnicodeError, RecursionError) as exc:
        return _failure(exc)


def submit(root, pack, *, proposal_id, actor_id, local_demo, can_write, allowed_packs=None):
    try:
        _authorized(local_demo, can_write)
        context = _store(root, pack, actor_id, allowed_packs)
        # Never trust a browser flag or even a saved validation receipt.
        result, folder = _validate(*context, proposal_id)
        _receipt(folder, "validation.json", result)
        if not result["passed"]:
            return {**result, "ok": False, "errors": result["errors"] + ["Existing validators must pass before this proposal can be submitted for review."]}
        receipt = {"status": "submitted_for_review", "draft_only": True, "approved": False, "released": False,
                   "proposal_id": proposal_id, "proposal_sha256": result["proposal_sha256"],
                   "request_id": uuid.uuid4().hex,
                   "submitted_at": datetime.now(timezone.utc).isoformat(), "validation": result,
                   "scope": "Local review request only; no product, approval, release or study pin is changed."}
        receipt["receipt_sha256"] = dw._hash(receipt)
        proposal, _folder_, stale = _load(*context, proposal_id)
        if stale or proposal["proposal_sha256"] != result["proposal_sha256"]:
            raise Invalid("The product or proposal changed before submission. Stage a fresh proposal.")
        target = _safe(folder / "submission.json")
        try:
            with target.open("xb") as stream:
                stream.write(_encode(receipt))
        except FileExistsError:
            receipt = _read_receipt(target, proposal)
        # The receipt is the author's; the request is what a reviewer sees. Publishing is
        # idempotent on the receipt's request id, so a submit repeated after a failed publish
        # completes the same request instead of opening a second one.
        import review_inbox
        request = None
        if receipt.get("request_id"):
            request = review_inbox.publish(context[0], context[2], proposal=proposal, validation=receipt["validation"],
                                           actor_id=actor_id, request_id=receipt["request_id"])
        return {"ok": True, "submission": receipt, "review_request": request, "errors": []}
    except (OSError, ValueError, TypeError, KeyError, AttributeError, UnicodeError, RecursionError) as exc:
        return _failure(exc)
