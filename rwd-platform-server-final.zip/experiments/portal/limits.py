"""The portal's run limits, read from the environment and VALIDATED: every cap is a finite,
positive number or the page says which variable is wrong. `nan` compared false with everything
and silently disabled a comparison; a non-number raised a traceback onto the page (audit 7)."""
from __future__ import annotations

import math

DEFAULTS = {"RWD_PORTAL_MAX_STEPS": ("steps", int, 10),
            "RWD_PORTAL_RUN_CEILING_USD": ("usd", float, 0.25),
            "RWD_PORTAL_MAX_SECONDS": ("seconds", float, 180.0)}


def caps(env) -> dict:
    """{steps, usd, seconds} from `env` (any mapping), or ValueError naming the variable."""
    out = {}
    for var, (key, typ, default) in DEFAULTS.items():
        raw = env.get(var)
        if raw is None or str(raw).strip() == "":
            out[key] = default
            continue
        try:
            val = typ(float(str(raw).strip())) if typ is int else typ(str(raw).strip())
        except (TypeError, ValueError):
            raise ValueError(f"{var}={raw!r} is not a number") from None
        if isinstance(val, float) and not math.isfinite(val):
            raise ValueError(f"{var}={raw!r} is not finite")
        if val <= 0:
            raise ValueError(f"{var}={raw!r} must be positive")
        if typ is int and float(str(raw).strip()) != val:
            raise ValueError(f"{var}={raw!r} must be a whole number")
        out[key] = val
    return out
