"""Shared navigation, context and saved-work queue for the product workflow."""
from __future__ import annotations

import importlib
import streamlit as st
import connected_workflow as workflow

KEY = "connected_workflow"
PREFIXES = ("variable_review_", "pattern_ws_", "model_lifecycle_", "branch_ws_", "eda_workspace_", "claims_ws_", "semantic_export_", "semantic_knowledge_", "scientific_definition_", "decision_answer_", "science_", "lifecycle_", "source_ws_", "review_exchange_",
            "design_", "plan_guide_", "workflow_record_", "workflow_forms_", "spec_details_", "source_review_", "resolution_command_",
            "review_inbox_", "handoffs_", "knowledge_ws_", "product_ws_", "specialist_ws_", "template_library_", "release_workspace_", "approval_attestation_")


def open_route(route, pack, actor_id, *, origin=None, params=None):
    origin = origin or st.session_state.get("section", "Flow")
    if route == "governed_check":
        st.session_state.pop(KEY, None)
        st.session_state["section_suggested"] = "Agent"
        st.session_state["connected_governed_check"] = {"pack": pack, "actor": actor_id,
            "mode": "intake" if (params or {}).get("mode") == "intake" else "check",
            "params": {key: value for key, value in (params or {}).items()
                       if key in {"goal", "run_id", "evaluation_id", "objective_id"} and isinstance(value, str)
                       and (key == "goal" or len(value) <= 4000)}}
        st.rerun()
    if (params or {}).get("specialist_run") or (params or {}).get("specialist_review"):
        st.session_state["connected_specialist_evidence"] = {"pack": pack, "actor": actor_id,
            "specialist_run": params.get("specialist_run"), "specialist_review": params.get("specialist_review")}
    else:
        st.session_state.pop("connected_specialist_evidence", None)
    if route == "progress":
        st.session_state.pop(KEY, None)
        st.session_state.pop("flow_dialog", None)
        st.session_state.pop("flow_dialog_feedback", None)
        st.session_state.setdefault("flow_result", {}).pop(pack, None)
        st.session_state["flow_requested_action"] = {"pack": pack, "actor": actor_id,
                                                     "action_id": (params or {}).get("action_id"),
                                                     "params": {key: value for key, value in (params or {}).items()
                                                                if key in {"receipt", "build_id"} and isinstance(value, str)}}
        st.session_state["section_suggested"] = "Flow"
    else:
        for marker in {
            "plan_changes": ("plan_guide_requested_intent", "plan_guide_incoming"),
            "scientific_draft": ("scientific_definition_incoming_row",),
            "questions": ("decision_answer_incoming",),
        }.get(route, ()):
            st.session_state.pop(marker, None)
        st.session_state[KEY] = workflow.destination(route, pack=pack, actor_id=actor_id,
                                                    origin=origin, params=params)
        st.session_state.pop("flow_dialog", None)
        st.session_state.pop("flow_dialog_feedback", None)
    st.rerun()


def specialist_evidence(root, pack, actor_id, *, allowed_packs, params=None):
    """Carry the selected, verified result into the task that uses its evidence."""
    context = params or st.session_state.get("connected_specialist_evidence") or {}
    if context.get("pack", pack) != pack or context.get("actor", actor_id) != actor_id:
        st.session_state.pop("connected_specialist_evidence", None)
        return
    if not (context.get("specialist_run") or context.get("specialist_review")):
        return
    import specialist_workspace as specialist
    try:
        record = (specialist.shared(root, pack, context["specialist_review"], allowed_packs=allowed_packs)
                  if context.get("specialist_review") else
                  specialist.read(root, pack, actor_id, context["specialist_run"], allowed_packs=allowed_packs))
    except (ValueError, OSError):
        st.warning("The linked specialist result is unavailable in this product context. Reopen it from saved work or its review request.")
        return
    with st.expander("Evidence carried from the specialist", expanded=True):
        meta = specialist.KINDS[record["kind"]]
        content = record["result"].get(meta["result"]) or {}
        st.write(str(content.get("summary") or meta["label"]) if isinstance(content, dict) else meta["label"])
        if record.get("stale"):
            st.warning("The inputs or instructions have changed. This result is historical context; run again before acting on it.")
        for finding in (record["result"].get("critic") or {}).get("findings") or []:
            st.write("• " + str(finding))
        st.caption("Use these findings while completing this step. The step's existing validation and review still apply.")
        if st.button("Open the complete specialist result", key="connected_specialist_open"):
            reference = {"review_id": context["specialist_review"]} if context.get("specialist_review") else {"run_id": record["id"]}
            open_route("specialist_assistant", pack, actor_id, params=reference)


def links(routes, pack, actor_id, *, key, params=None, label="Continue with related work", expanded=False):
    if not pack:
        return
    with st.expander(label, expanded=expanded):
        for route in routes:
            meta = workflow.ROUTES[route]
            if st.button(meta.title, key=f"connected_{key}_{route}", help=meta.purpose, width="stretch"):
                source = st.session_state.get(KEY, {}).get("route")
                open_route(route, pack, actor_id, params=workflow.continuation_params(source, route, params))


def select_context(pack, actor_id, **fields):
    context = st.session_state.get(KEY)
    if context and context.get("pack") == pack and context.get("actor") == actor_id:
        context.setdefault("params", {}).update({k: v for k, v in fields.items()
            if k in {"item_id", "variable", "study", "previous_pack"}})
        st.session_state[KEY] = context


def step_links(action_id, pack, actor_id, *, key="step", label="Tools for this step"):
    try:
        stage = int(action_id[1])
    except (ValueError, IndexError, TypeError):
        return
    routes = tuple(r for r in workflow.STAGES.get(stage, ()) if r != "scientific_draft")
    links(routes, pack, actor_id, key=key, label=label)


def recent_work(root, pack, actor_id, *, allowed_packs):
    if not pack or pack not in allowed_packs:
        return
    with st.expander("Saved work and pending handoffs"):
        rows, errors = [], []
        for name in ("science_workspace", "source_workspace", "lifecycle_workspace", "review_exchange", "connected_workflow", "handoffs", "template_library_workspace", "specialist_workspace", "eda_workspace", "claims_workspace", "semantic_export_workspace", "pattern_workspace", "model_lifecycle_workspace"):
            try:
                rows.extend(importlib.import_module(name).recent(root, pack, actor_id, allowed_packs=allowed_packs))
            except (ValueError, OSError) as exc:
                errors.append(str(exc))
        for error in errors:
            st.warning(error)
        rows = [r for r in rows if r.get("route") in workflow.ROUTES]
        rows.sort(key=lambda r: str(r.get("updated_at", "")), reverse=True)
        if not rows:
            st.caption("No saved workspace proposals or delivery requests for this product and identity yet. Saved definition drafts remain available in the row editor.")
        for index, row in enumerate(rows[:30]):
            st.write(f"**{row.get('title', workflow.ROUTES[row['route']].title)}** · {row.get('state', 'draft')}")
            st.caption(str(row.get("summary", "")))
            if st.button("Resume", key=f"connected_resume_{index}_{row['id']}"):
                open_route(row["route"], pack, actor_id, params=row.get("params"))
        # REVIEW REQUESTS FROM HOME (2026-09-07): a reviewer's first stop for a submitted configuration
        # change is this queue, so the inbox opens from here as well as from the Gate 4 step links.
        meta = workflow.ROUTES["review_inbox"]
        if st.button(meta.title, key="connected_home_review_inbox", help=meta.purpose):
            open_route("review_inbox", pack, actor_id)
        hand = workflow.ROUTES["handoffs"]
        if st.button(hand.title, key="connected_home_handoffs", help=hand.purpose):
            open_route("handoffs", pack, actor_id)


def run_continuations(root, pack, actor_id, run, *, allowed_packs, key):
    """Recheck the saved model review before offering its existing workflow action."""
    if pack not in (allowed_packs or []) or not isinstance(run, dict):
        return
    try:
        import model_lifecycle_runtime
        continuations = model_lifecycle_runtime.continuations(root, pack, run)
    except (ValueError, OSError, KeyError, TypeError, AttributeError):
        return
    for index, item in enumerate(continuations[:3]):
        if not isinstance(item, dict) or item.get("route") not in workflow.ROUTES:
            continue
        params = item.get("params") or {}
        if not isinstance(params, dict) or params.get("pack") != pack:
            continue
        route = item["route"]
        st.caption(str(item.get("reason") or workflow.ROUTES[route].purpose))
        if st.button(workflow.ROUTES[route].title, key=f"{key}_continue_{index}_{route}"):
            open_route(route, pack, actor_id, params=params)


def _portfolio(root, pack, actor_id, allowed_packs, origin):
    scope = st.radio("Show questions from", ("all", "current"),
                     format_func=lambda value: "All products I can access" if value == "all" else "The selected product only",
                     key="connected_portfolio_scope", horizontal=True)
    result = workflow.portfolio(root, [pack] if scope == "current" and pack in allowed_packs else allowed_packs)
    st.info("Open a question for guided choices, a custom answer or optional AI help. You review the draft before recording a decision.")
    st.caption("Ranked by declared definition dependencies. This count does not measure clinical importance or approval readiness.")
    if result["problems"]:
        with st.expander("Products not ready for question review"):
            for item in result["problems"]:
                st.info(f"{item['pack']}: {item['message']}")
    if not result["rows"]:
        st.info("No open decisions were found in the accessible decision registers. Check product progress for other missing requirements.")
    for index, row in enumerate(result["rows"]):
        with st.container(border=True):
            st.write(f"**{row['decision_id']}** · {row['pack']} · {row['count']} dependent definitions")
            if row["pack"].startswith("fixtures/"):
                st.caption("Reference example · answers belong to this example, not the selected product.")
            st.write(row["question"])
            st.caption(f"Responsible: {row['owner']}")
            if row["variables"]:
                st.caption(", ".join(row["variables"]))
            if st.button("Help me answer this question", key=f"connected_question_{index}",
                         help="Open this question's choices, editable answer and AI drafting helper."):
                st.session_state["pack_suggested"] = row["pack"]
                open_route("questions", row["pack"], actor_id, origin=origin, params={"decision_id": row["decision_id"]})


def render_active(root, pack, actor_id, *, section, allowed_packs, local_demo, can_write,
                  can_review, can_view, can_pin=False, can_answer=False, can_plan=None, can_agent=False,
                  can_manage_library=False, label=None, section_label=None):
    # Streamlit normally removes widgets when their page is absent. Keep typed work through
    # related screens; each editor still clears its own state on actor/product change.
    for key in list(st.session_state):
        # A chat input is a one-run submission, not a persistent text field.
        # Self-assignment consumes Streamlit's trigger before its composer can
        # read it, which silently dropped messages in the connected row editor.
        if str(key).endswith(("_chat", "_chat_input")) and isinstance(st.session_state[key], str):
            continue
        if str(key).startswith(PREFIXES) and type(st.session_state[key]) in (str, int, float, list, dict, tuple):
            st.session_state[key] = st.session_state[key]
    context = st.session_state.get(KEY)
    if not workflow.valid(context, pack=pack, actor_id=actor_id, section=section, allowed_packs=allowed_packs):
        st.session_state.pop(KEY, None)
        return False
    if not can_view:
        st.info("You need access to this product to use its workflow.")
        return True
    route, params = context["route"], context.get("params", {})
    meta = workflow.ROUTES[route]
    # WHERE YOU ARE, IN THE PAGE'S OWN WORDS (2026-09-07): the crumb showed the raw pack path and
    # the internal section name; a person reads the product's name and the sidebar's label.
    shown_section = section_label or section
    st.caption(f"{label or pack} › {shown_section} › {meta.title}")
    if st.button(f"Back to {shown_section}", key="connected_back"):
        st.session_state.pop(KEY, None)
        st.rerun()
    if meta.module not in {"science_workspace", "lifecycle_workspace"} and route != "plan_changes":
        st.subheader(meta.title)
    st.write(meta.purpose)
    if params.get("study"):
        st.caption(f"Study: {params['study']}")
    if params.get("variable"):
        st.caption(f"Variable: {params['variable']}")
    specialist_evidence(root, pack, actor_id, allowed_packs=allowed_packs, params=params)
    result = None
    if route == "portfolio":
        _portfolio(root, pack, actor_id, allowed_packs, section)
    elif route == "variable_review":
        import variable_review_workflow_page
        result = variable_review_workflow_page.render(root, pack, actor_id, params=params,
            allowed_packs=allowed_packs, local_demo=local_demo,
            can_write=can_write, can_review=can_review, can_view=can_view)
    elif route == "specialist_assistant":
        import specialist_workspace_page
        result = specialist_workspace_page.render(root, pack, actor_id, allowed_packs=allowed_packs,
            local_demo=local_demo, can_write=can_write, can_review=can_review,
            can_agent=can_agent, route=route, params=params)
    elif route in {"template_library", "implementation_patterns"}:
        page = importlib.import_module(meta.module + "_page")
        result = page.render(root, pack, actor_id, allowed_packs=allowed_packs,
            local_demo=local_demo, can_write=can_write, can_review=can_review,
            can_manage_library=can_manage_library, route=route, params=params)
    elif route == "branch_changes":
        import branch_workspace_page
        result = branch_workspace_page.render(root, pack, actor_id, allowed_packs=allowed_packs,
            local_demo=local_demo, can_write=can_write, can_review=can_review,
            can_manage_shared=can_manage_library, route=route, params=params)
    elif meta.module == "source_workspace":
        import source_workspace_page
        result = source_workspace_page.render(root, pack, actor_id, allowed_packs=allowed_packs,
            local_demo=local_demo, can_write=can_write, can_review=can_review, can_agent=can_agent,
            route=route, params=params)
    elif route == "plan_changes":
        import plan_changes_page
        plan_changes_page.render(root, pack, actor_id=actor_id, local_demo=local_demo,
                                 can_write=can_write if can_plan is None else can_plan,
                                 allowed_packs=allowed_packs, params=params)
    elif route == "scientific_draft":
        import scientific_definition_page
        changed = scientific_definition_page.render(root, pack, actor_id, local_demo=local_demo,
            can_write=can_write, can_view=can_view, can_review=can_review,
            naming_packs=allowed_packs, initial_item_id=params.get("item_id"))
        result = {"changed": changed}
    elif route == "questions":
        import decision_answer_page
        notice = st.session_state.pop("connected_question_notice", None)
        if notice and (notice.get("pack"), notice.get("actor")) == (pack, actor_id):
            st.success(notice["text"])
        if params.get("decision_id"):
            st.info(f"Continue with {params['decision_id']} in the issued answer forms below.")
        changed = decision_answer_page.render(root, pack, actor_id, local_demo=local_demo,
                                              can_write=can_answer, can_view=can_view, initial_decision_id=params.get("decision_id"),
                                              question_draft={"question": params.get("question"), "variable": params.get("variable"),
                                                  "source": params.get("question_source"), "context": params.get("question_context"),
                                                  "evidence": params.get("question_evidence")})
        result = {"changed": changed}
    else:
        page = importlib.import_module(meta.module + "_page")
        writable = can_pin if route == "study_refresh" else (
            can_plan if route == "study_protocol" and can_plan is not None else can_write)
        result = page.render(root, pack, actor_id, allowed_packs=allowed_packs, local_demo=local_demo,
            can_write=writable, can_review=can_review,
            route=route, params=params)
    if isinstance(result, dict):
        if result.get("changed"):
            st.session_state.setdefault("flow_result", {}).pop(pack, None)
            if route == "questions":
                action = st.session_state.pop("decision_answer_last_action", "saved")
                message = ("Question drafts prepared. Choose a question below; each new draft has a blank answer, decision maker and date."
                           if action == "prepared" else "Answer saved as draft evidence. Complete the named review before treating it as approved evidence.")
                st.session_state["connected_question_notice"] = {"pack": pack, "actor": actor_id, "text": message}
                st.rerun()
            if route != "variable_review":
                st.caption("Saved work changed. Check product progress to re-evaluate the current files.")
        if result.get("route"):
            target = result.get("pack", pack)
            if target not in allowed_packs:
                st.error("The requested product is outside your access.")
            else:
                if target != pack:
                    st.session_state["pack_suggested"] = target
                open_route(result["route"], target, actor_id, origin=section,
                           params=workflow.continuation_params(route, result["route"], params, result.get("params")))
    # These evidence pages render their own verified receipt continuations. Generic
    # links would retain only incoming params, losing a later selection in the page.
    if route not in {"eda_review", "variable_review", "scientific_draft"}:
        st.divider()
        links(meta.next, pack, actor_id, key="next", params=params, label="What to do next", expanded=True)
    return True
