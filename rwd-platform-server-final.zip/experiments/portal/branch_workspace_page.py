"""An explicit, scoped Git checkpoint at the end of the product's editing workflow."""
import streamlit as st
import branch_workspace as workspace


def render(root, pack, actor_id, *, allowed_packs, local_demo, can_write, can_review, route, params=None, can_manage_shared=False):
    context = (str(root), pack, actor_id, tuple(sorted(allowed_packs or [])), local_demo, can_write, can_review, can_manage_shared)
    if st.session_state.get("branch_ws_context") != context:
        for key in list(st.session_state):
            if key.startswith("branch_ws_"):
                del st.session_state[key]
        st.session_state["branch_ws_context"] = context
    notice = st.session_state.pop("branch_ws_notice", None)
    if notice:
        (st.success if notice["ok"] else st.warning)(notice["message"])
        st.caption("Git commit: " + notice["commit"])
    try:
        state = workspace.describe(root, pack, actor_id, allowed_packs=allowed_packs, summary_only=True, can_manage_shared=can_manage_shared)
        st.write("Current branch: **" + (state["branch"] or "Detached HEAD — choose a branch in VS Code") + "**")
        st.write("Edits are saved to files as you work. A branch checkpoint records the selected product definitions, configuration and review records in Git so they travel with your branch.")
        st.caption(state["private_notice"])
        for warning in state["application_warnings"]:
            st.warning(warning)
        if state["sources"]:
            with st.expander("Will the source be available on another computer?", expanded=True):
                for source in state["sources"]:
                    st.write(source["path"] + " — " + source["state"])
                st.caption("This checkpoint saves metadata only. It never force-adds an ignored source workbook. Keep its source registration and exact digest, and arrange that registered source before extracting in another checkout.")
        if state["shared_pending"]:
            st.info("This product has changes to shared registration or capability files. Include the checked dependencies so its registered workflows are available in another checkout.")
            st.write("Pending shared dependencies: " + ", ".join(state["shared_pending"]))
            if not can_manage_shared:
                st.warning("A local administrator must review and checkpoint these shared-file changes. You can checkpoint this product's own records here.")
        if not state["offered"]:
            st.info("There are no changed product records to checkpoint. Continue editing this product, then return here.")
            return
        selected = st.multiselect("Product records to include", state["offered"], key="branch_ws_files")
        if not selected:
            return
        checked = workspace.describe(root, pack, actor_id, allowed_packs=allowed_packs, selected=selected, can_manage_shared=can_manage_shared)
        if checked["shared_selected"]:
            st.warning("The diff includes complete shared registration files. Review every changed row, including any changes for other products; this is not a partial-row commit.")
        st.code(checked["diff"], language="diff")
        if st.session_state.get("branch_ws_digest") != checked["digest"]:
            st.session_state["branch_ws_digest"] = checked["digest"]
            st.session_state["branch_ws_confirm"] = False
            st.session_state["branch_ws_confirm_shared"] = False
        confirmed_shared = (st.checkbox("I reviewed the complete shared-file diffs and want to include them.", key="branch_ws_confirm_shared")
                            if checked["shared_selected"] else False)
        remaining = set(checked["shared_pending"]) - set(checked["shared_selected"])
        if remaining:
            st.caption("This selection leaves registration dependencies outside the checkpoint: " + ", ".join(sorted(remaining)))
        message = st.text_input("What did you change?", placeholder="Clarify index date and missing-value rules", key="branch_ws_message")
        confirmed = st.checkbox("I reviewed these exact files and want to save them to this branch.", key="branch_ws_confirm")
        if st.button("Save checkpoint to my branch", type="primary", key="branch_ws_save",
                     disabled=not (confirmed and checked["can_commit"] and local_demo and can_write and
                                   (not checked["shared_selected"] or confirmed_shared))):
            result = workspace.commit(root, pack, actor_id, allowed_packs=allowed_packs, selected=selected,
                expected_digest=checked["digest"], message=message, confirmed=confirmed, local_demo=local_demo, can_write=can_write,
                can_manage_shared=can_manage_shared, confirmed_shared=confirmed_shared)
            st.session_state["branch_ws_notice"] = result
            st.session_state.pop("branch_ws_files", None)
            st.rerun()
        if state["other_changes"]:
            st.caption("Additional product files need review in VS Code. Source workbooks and private drafts are outside this metadata checkpoint.")
    except (ValueError, OSError) as exc:
        st.error(str(exc))
