"""Identity boundaries for a local checkout, a synthetic role rehearsal or a hosted app.

Databricks Apps forwards the authenticated principal on every request as headers
(X-Forwarded-Email, X-Forwarded-Preferred-Username, X-Forwarded-User); the app binds the actor to
the users.json entry that principal matches, and to nothing else. With no forwarded principal the
app refuses unless a local mode is explicit. RWD_PORTAL_LOCAL_WORKSPACE=1 uses the checkout
owner's Git attribution; RWD_PORTAL_LOCAL_DEMO=1 enables a sidebar picker for attribution
for a demo and is labelled as such. RWD_PORTAL_DEVELOPMENT=1 enables the same
demonstration on a development server with saved name/email profiles. A missing roster grants nothing: the "admin" the app
used to mint when users.json was absent (audit 6) exists only in demo mode. Pure functions; the
Streamlit page only renders what they return (platform/tests/test_audit6_20260903.py).
"""
from __future__ import annotations

FORWARDED = ("X-Forwarded-Email", "X-Forwarded-Preferred-Username", "X-Forwarded-User")
DEMO_ENV = "RWD_PORTAL_LOCAL_DEMO"
DEVELOPMENT_ENV = "RWD_PORTAL_DEVELOPMENT"
WORKSPACE_ENV = "RWD_PORTAL_LOCAL_WORKSPACE"


def mode(environ):
    """Development demos are portable; legacy demo flags keep workspace precedence."""
    if environ.get(DEVELOPMENT_ENV) == "1":
        return "demo"
    if environ.get(WORKSPACE_ENV) == "1":
        return "local"
    return "demo" if environ.get(DEMO_ENV) == "1" else "hosted"


def development_profile(users: list[dict], name: str, email: str) -> list[dict]:
    """Create or update explicit demo attribution while retaining role and product access.

    The page calls this only in development mode. This is a profile identifier,
    not a verification of the entered email address.
    """
    import re
    name, email = str(name or "").strip(), str(email or "").strip().lower()
    if not name or len(name) > 240 or any(ord(c) < 32 for c in name):
        raise ValueError("Enter a profile name, up to 240 characters.")
    if (len(email) > 240 or any(ord(c) < 32 for c in email)
            or not re.fullmatch(r"[^\s@]+@[^\s@]+\.[^\s@]+", email)):
        raise ValueError("Enter an email address such as priya@example.org.")
    result = [dict(user) for user in users]
    matches = [user for user in result if str(user.get("name", "")).casefold() == name.casefold()]
    if len(matches) > 1:
        raise ValueError("This name has more than one profile. Choose a different name.")
    current = matches[0] if matches else None
    if any(str(user.get("email", "")).lower() == email and user is not current for user in result):
        raise ValueError("That email belongs to another profile. Select that profile or use a different email.")
    if current is None:
        result.append({"name": name, "email": email, "role": "admin", "development_profile": True})
    else:
        current.update(email=email, development_profile=True)
    return result


def local_user(root):
    """Git attribution for the person who owns this checkout; never a sign-in."""
    import getpass
    import os
    import subprocess
    values = {}
    for field in ("name", "email"):
        try:
            result = subprocess.run(["git", "config", "--get", "user." + field], cwd=root,
                capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=5,
                **({"creationflags": subprocess.CREATE_NO_WINDOW} if os.name == "nt" else {}))
            values[field] = result.stdout.strip()[:240] if result.returncode == 0 else ""
        except (OSError, subprocess.SubprocessError):
            values[field] = ""
    return {"name": values["name"] or getpass.getuser(), "email": values["email"], "role": "admin"}


def principal(headers) -> str | None:
    """The forwarded principal, lower-cased, or None when the platform forwarded none."""
    if not headers:
        return None
    for h in FORWARDED:
        for k in (h, h.lower()):
            try:
                v = headers.get(k)
            except AttributeError:
                v = None
            if v:
                return str(v).strip().lower()
    return None


def default_users(local_demo: bool, bootstrap_admin: str | None = None) -> list[dict]:
    """The roster when users.json is absent: a demo admin locally; when deployed, NOBODY — unless
    the deployment names its first administrator (RWD_PORTAL_BOOTSTRAP_ADMIN, a principal the
    platform forwards), who then adds everyone else from the Manage users panel (audit 7: a
    deployed portal with no roster had no way to admit its first person)."""
    if local_demo:
        return [{"name": "admin", "role": "admin"}]
    who = str(bootstrap_admin or "").strip().lower()
    return [{"name": who, "email": who, "role": "admin"}] if who else []


def save_users(path: str, users: list[dict]) -> None:
    """Write the roster where RWDP_STATE_DIR says — creating that directory when it does not exist
    yet. The first local run pointed RWDP_STATE_DIR at a directory nobody had made, and the first
    page crashed on writing users.json into it (a person testing the pushed branch, 2026-09-04)."""
    import json  # noqa: PLC0415
    import os  # noqa: PLC0415
    os.makedirs(os.path.dirname(os.path.abspath(path)) or ".", exist_ok=True)
    with open(path, "w", encoding="utf-8") as fh:
        json.dump(users, fh, indent=1)


def resolve(headers, users: list[dict], local_demo: bool, chosen: str | None = None, *, local_workspace=False):
    """(actor, why). `actor` is a users.json entry or None; `why` says how it was decided and is
    shown beside the name so nobody mistakes a demo pick for authentication."""
    # Local requests can supply arbitrary HTTP headers. Explicit local modes
    # own attribution and must never turn those headers into a sign-in claim.
    if local_workspace:
        if len(users or []) == 1:
            return users[0], ("Local checkout owner: changes are attributed to your Git identity. "
                              "This is not a hosted sign-in or a scientific approval.")
        return None, "Local workspace attribution requires exactly one checkout owner."
    if local_demo:
        for u in users or []:
            if u.get("name") == chosen:
                return u, (f"DEMO identity {chosen!r}: profile attribution for this development demo, "
                           f"not authentication")
        return None, "DEMO mode: pick a roster entry"
    # Hosted mode retains the corporate trusted-proxy principal/roster boundary.
    who = principal(headers)
    if who:
        for u in users or []:
            ids = {str(u.get("email") or "").lower(), str(u.get("principal") or "").lower(),
                   str(u.get("name") or "").lower()} - {""}
            if who in ids:
                return u, f"authenticated as {who} (principal forwarded by the platform)"
        return None, (f"{who} is not in users.json — an administrator adds people to the roster; "
                      f"nothing is assumed from a login alone")
    return None, (f"no authenticated identity: the platform forwarded no principal and {DEMO_ENV} "
                  f"is not set — refusing rather than assuming who you are. For local branch editing, "
                  f"use Start-RwdPortal.cmd or set {WORKSPACE_ENV}=1 and bind Streamlit to 127.0.0.1. For a laptop demo, set "
                  f"{DEMO_ENV}=1 in the environment (or in experiments/portal/.env) and restart; deployed "
                  f"on Databricks Apps the platform forwards your principal and nothing is set by hand")
