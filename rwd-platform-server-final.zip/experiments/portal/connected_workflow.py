"""One product workflow: contextual routes and explicit, scoped continuations."""
from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class Route:
    title: str
    section: str
    module: str
    purpose: str
    next: tuple[str, ...]


ROUTES = {
    "variable_review": Route("Review the variable list", "Flow", "variable_review_workflow", "Complete scientific definitions, source mappings and output fields as separate reviews of the whole variable list.", ()),
    "governed_check": Route("Continue in chat with a product check", "Agent", "existing", "Run the existing bounded assistant check using your selected connection.", ("model_lifecycle",)),
    "implementation_patterns": Route("Reuse and improve implementation code", "Flow", "pattern_workspace", "Inspect existing code and tests, retain reviewed implementation evidence and apply checked reusable capability metadata.", ("specialist_assistant", "definition_identity", "branch_changes")),
    "model_lifecycle": Route("Review and improve assistant routing", "Flow", "model_lifecycle_workspace", "Review completed runs, evaluate learned continuations and activate an exact checked version for this product.", ("specialist_assistant", "branch_changes")),
    "branch_changes": Route("Save work to my branch", "Flow", "branch_workspace", "Review the exact product file changes and save a Git checkpoint in your current branch.", ("progress",)),
    "eda_review": Route("Review the six-layer data report", "Flow", "eda_workspace", "Inspect the data report bound to an exact build, then save a review record and continue validation.", ("source_evidence", "release_readiness", "branch_changes")),
    "claims_workspace": Route("Configure claims criteria", "Flow", "claims_workspace", "Map explicit claims events and cohort criteria, validate the generated export and save reviewed bindings.", ("source_evidence", "handoffs", "branch_changes")),
    "semantic_export": Route("Export the product knowledge graph", "Flow", "semantic_export_workspace", "Review the scoped graph and its SHACL validation, then save an exact version for downstream use.", ("definition_identity", "handoffs", "branch_changes")),
    "product_workspace": Route("Product workspace", "Home", "product_workspace", "Choose a task and continue with its evidence, review and next action in one workflow.", ("progress",)),
    "knowledge_explorer": Route("Knowledge sources and definitions", "Search & definitions", "knowledge_workspace", "Inspect source declarations, concepts, provenance and SHACL results, or search definitions and implementation evidence.", ("scientific_draft", "clinical_standards", "semantic_export")),
    "template_library": Route("Shared-library reuse and promotion", "Flow", "template_library_workspace", "Review, apply and record a shared-library version, then continue with its reuse review.", ("knowledge_explorer", "template_review", "handoffs")),
    "release_readiness": Route("Build promotion readiness", "Flow", "release_workspace", "Inspect an exact candidate build, its checks and remaining review or publication steps.", ("progress", "study_refresh", "handoffs")),
    "specialist_assistant": Route("Help with evidence", "Flow", "specialist_workspace", "Run a specialist for source assessment, a validation failure or an implementation question, then review its result and continue in the product workflow.", ("source_mapping", "scientific_draft", "handoffs")),
    "plan_changes": Route("Plan a product change", "Plan changes", "existing", "Describe the change and review its supported configuration proposal or engineering handoff.", ("change_impact", "scientific_draft", "progress")),
    "definition_reuse": Route("Reuse a master variable definition", "Flow", "science_workspace", "Choose logic from the master variable library and set this product's values separately. Prior-product examples are optional.", ("scientific_draft", "variable_lineage")),
    "variable_lineage": Route("Trace a variable", "Search & definitions", "science_workspace", "Follow the specification, decisions, rule, implementation and available evidence for this variable.", ("scientific_draft", "change_impact", "questions")),
    "clinical_standards": Route("Review clinical standards", "Flow", "science_workspace", "Review proposed clinical and semantic bindings against their source evidence.", ("scientific_draft", "definition_identity")),
    "template_review": Route("Reconcile the example template", "Flow", "science_workspace", "Record which template concepts apply and which need a different scientific interpretation.", ("definition_reuse", "scientific_draft")),
    "definition_identity": Route("Register definitions and implementation claims", "Flow", "science_workspace", "Connect the shared definition identity to its explicit implementation evidence.", ("variable_lineage", "change_impact", "progress")),
    "dataset_comparison": Route("Compare study datasets", "Studies", "science_workspace", "Inspect semantic differences and unresolved comparability conditions before proposing pooling.", ("questions", "study_protocol")),
    "revision_review": Route("Review changes from the previous cut", "Plan changes", "lifecycle_workspace", "Compare source rows and explicitly carry forward only the judgments you have checked.", ("scientific_draft", "change_impact")),
    "change_impact": Route("Review dependent outputs and studies", "Plan changes", "lifecycle_workspace", "Trace declared dependencies through outputs and consumers, including gaps in evidence.", ("variable_lineage", "study_refresh", "progress")),
    "study_refresh": Route("Review and refresh a study pin", "Studies", "lifecycle_workspace", "Compare the study's saved choice with the current product and select an exact published build when available.", ("study_protocol", "study_runs", "dataset_comparison")),
    "study_protocol": Route("Edit the study protocol", "Studies", "lifecycle_workspace", "Record the study's question, population and analysis plan; a frozen plan requires an amendment proposal.", ("feasibility", "study_refresh", "study_runs")),
    "study_runs": Route("Record study run evidence", "Studies", "lifecycle_workspace", "Validate evidence from an actual study run against its protocol and pinned product.", ("dataset_comparison", "study_protocol")),
    "source_requirements": Route("Review required source data", "Flow", "source_workspace", "See which tables and columns each definition requires and who consumes them.", ("source_delivery", "source_evidence", "source_mapping")),
    "source_delivery": Route("Declare the source delivery", "Flow", "source_workspace", "Enter the delivered table names and cut, review their resolved names and validate the configuration changes.", ("source_evidence", "source_mapping", "progress")),
    "source_evidence": Route("Prepare and receive delivery evidence", "Flow", "source_workspace", "Bind a delivery request to this product, then inspect returned profile and schema evidence.", ("source_mapping", "delivery_drift", "progress")),
    "source_mapping": Route("Map source tables and columns", "Flow", "source_workspace", "Resolve candidates explicitly, review the adapter diff and run its existing validators.", ("source_evidence", "change_impact", "progress")),
    "delivery_drift": Route("Compare delivery profiles", "Flow", "source_workspace", "Compare identified deliveries and inspect changes before using a new cut.", ("source_evidence", "source_mapping")),
    "feasibility": Route("Explore study feasibility", "Studies", "source_workspace", "Bind explicit criteria to a synthetic rehearsal or a request for the approved data environment.", ("study_protocol", "source_evidence")),
    "review_workbook": Route("Exchange a scientific review workbook", "Flow", "review_exchange", "Download the current specification, check the returned review and continue on the selected source row.", ("scientific_draft", "questions")),
    "portfolio": Route("Prioritise questions across my products", "Home", "connected_workflow", "See which open decisions block the most declared definitions, within your product access.", ("questions", "progress")),
    "scientific_draft": Route("Draft the scientific definition", "Flow", "existing", "Write and validate the interpretation for one source row, using examples beside each field.", ("definition_reuse", "review_workbook", "source_requirements", "progress")),
    # THE STATES AFTER 'SUBMIT PROPOSAL FOR REVIEW' (2026-09-07): a submitted configuration change
    # had no page a second person could open. Reviewers record their decision here, and accepted
    # changes are applied to a draft revision and validated here; the product itself is not edited.
    "review_inbox": Route("Review requests", "Flow", "review_inbox", "See each submitted configuration change with its exact diff and impact, record your review decision, then apply accepted changes to a draft revision and run the validators on it.", ("plan_changes", "change_impact", "progress")),
    "handoffs": Route("Handoffs and requests", "Flow", "handoffs", "Every piece of work handed to a data expert, reviewer or engineer for this product: who asked, who owns it, its status and the answer.", ("progress",)),
    "questions": Route("Answer the recorded scientific questions", "Open questions", "existing", "Compare choices or ask AI for drafting help, then record the decision actually made by the named reviewer.", ("scientific_draft", "progress")),
    "progress": Route("Check product progress", "Flow", "existing", "Run the existing checks and resolve the next unmet requirement.", ()),
}

# Each audited group is reachable in the ordinary workflow. Existing naming lookup and
# reference/capability context share the comparison and lineage routes, not extra menus.
CAPABILITIES = {
    "implementation_patterns": "implementation_patterns", "learned_continuations": "model_lifecycle",
    "branch_persistence": "branch_changes", "six_layer_eda": "eda_review",
    "claims_criteria": "claims_workspace", "enterprise_graph": "semantic_export",
    "reuse_and_names": "definition_reuse", "lineage": "variable_lineage",
    "specification_revision": "revision_review", "consumer_impact": "change_impact",
    "source_requirements": "source_requirements", "delivery_evidence": "source_evidence",
    "source_mapping": "source_mapping", "study_pins": "study_refresh",
    "protocol_and_runs": "study_protocol", "review_exchange": "review_workbook",
    "shared_identity": "definition_identity", "portfolio_priorities": "portfolio",
    "template_reconciliation": "template_review", "clinical_standards": "clinical_standards",
    "semantic_comparison": "dataset_comparison", "delivery_drift": "delivery_drift",
    "reference_and_capability_context": "variable_lineage", "feasibility": "feasibility",
}

STAGES = {
    1: ("review_workbook", "revision_review"),
    2: ("variable_review", "knowledge_explorer", "definition_reuse", "review_workbook", "template_review", "clinical_standards", "variable_lineage"),
    3: ("source_requirements", "source_delivery", "source_evidence", "source_mapping", "claims_workspace", "delivery_drift", "specialist_assistant"),
    4: ("change_impact", "definition_identity", "implementation_patterns", "variable_lineage", "review_inbox"),
    5: ("eda_review", "variable_lineage", "change_impact", "source_evidence", "specialist_assistant", "model_lifecycle", "release_readiness"),
    6: ("release_readiness", "template_library", "semantic_export", "study_refresh", "study_protocol", "study_runs", "dataset_comparison", "branch_changes"),
}

SECTIONS = {
    "Home": ("product_workspace", "portfolio", "review_inbox", "handoffs"), "Flow": tuple(dict.fromkeys([*(r for routes in STAGES.values() for r in routes), "handoffs"])),
    "Search & definitions": ("variable_review", "knowledge_explorer", "variable_lineage", "definition_reuse", "clinical_standards", "definition_identity", "template_library"),
    "Plan changes": ("revision_review", "change_impact", "template_review", "review_inbox", "handoffs"),
    "Studies": ("study_protocol", "study_refresh", "study_runs", "feasibility", "dataset_comparison"),
    "Open questions": ("variable_lineage", "scientific_draft", "review_workbook"),
}


def destination(route, *, pack, actor_id, origin, params=None):
    if route not in ROUTES:
        raise ValueError("That workflow action is unavailable.")
    return {"route": route, "pack": pack, "actor": actor_id, "origin": origin,
            "params": {k: v for k, v in (params or {}).items() if isinstance(k, str) and isinstance(v, (str, int, bool, type(None)))}}


def valid(context, *, pack, actor_id, section, allowed_packs):
    return bool(isinstance(context, dict) and isinstance(context.get("route"), str) and context.get("route") in ROUTES and context.get("pack") == pack
                and context.get("actor") == actor_id and context.get("origin") == section
                and isinstance(context.get("params", {}), dict) and pack in (allowed_packs or []))


def continuation_params(source, target, params, explicit=None):
    # Artifact identifiers belong to the workflow that created them. Only semantic
    # context travels automatically; a destination may explicitly supply its own id.
    inherited = dict(params or {}) if source == target else {
        key: value for key, value in (params or {}).items()
        if key in {"item_id", "variable", "study", "previous_pack", "specialist_run", "specialist_review"}
        or (key in {"receipt", "build_id"} and source in {"eda_review", "release_readiness"}
            and target in {"eda_review", "release_readiness", "progress"})}
    return {**inherited, **(explicit or {})}


def question_report(root, pack, *, allowed_packs):
    """Render the current register and dependencies without a stale generated page."""
    import contract_lint as cl
    import decision_report
    from decision_answers import _paths, _read
    try:
        _, pack, product = _paths(root, pack, allowed_packs)
        register = _read(product / "handoff/DECISIONS.md").decode("utf-8")
        _read(product / "handoff/FUNCTIONAL_CONTRACT.md")
        errors = cl.decision_register_errors(register, pack)
        if errors:
            raise ValueError("The question register needs repair before its open questions can be counted. Open this product's Progress and next step to review it.")
        graph = decision_report.blast_radius(str(product))
        return {"ok": True, "page": decision_report.render(str(product), *graph),
                "register": register, "error": ""}
    except FileNotFoundError:
        message = "The scientific contract or question register has not been prepared. Open this product's Progress and next step to prepare it."
    except OSError:
        message = "The scientific question files could not be read. Open this product's Progress and next step to check the available evidence."
    except UnicodeError:
        message = "The scientific question files need repair before their open questions can be counted. Open this product's Progress and next step to review them."
    except (ValueError, KeyError) as exc:
        message = str(exc)
    return {"ok": False, "page": "", "register": "", "error": message}


def portfolio(root, allowed_packs):
    """Use the canonical decision dependency graph without its global portfolio scan."""
    import contract_lint as cl
    import decision_report
    from decision_answers import _paths, _read
    rows, problems = [], []
    for pack in sorted(set(allowed_packs)):
        try:
            _, _, product = _paths(root, pack, allowed_packs)
            for name in ("DECISIONS.md", "FUNCTIONAL_CONTRACT.md"):
                _read(product / "handoff" / name)
            blocks, table, _idle, statuses = decision_report.blast_radius(str(product))
            for did, state in statuses.items():
                if state == "OPEN":
                    row = table.get(did, {})
                    rows.append({"pack": pack, "decision_id": did, "owner": cl.cell(row, *cl.OWNER_COLUMNS) or "Unassigned",
                                 "question": cl.decision_question(row), "variables": sorted(blocks.get(did, [])),
                                 "count": len(blocks.get(did, []))})
        except FileNotFoundError:
            problems.append({"pack": pack, "message": "The scientific contract or question register has not been prepared. Open this product's Progress and next step to prepare it."})
        except OSError:
            problems.append({"pack": pack, "message": "The scientific question files could not be read. Open this product's Progress and next step to check the available evidence."})
        except (ValueError, KeyError) as exc:
            problems.append({"pack": pack, "message": str(exc)})
    return {"rows": sorted(rows, key=lambda r: (-r["count"], r["pack"], r["decision_id"])), "problems": problems}


def recent(root, pack, actor_id, *, allowed_packs):
    """Connect original Plan changes and row drafts to the same resume queue."""
    from datetime import datetime, timezone
    import json
    import design_workspace
    import configuration_proposals
    import scientific_definitions
    rows = []
    drafts = design_workspace.list_drafts(root, pack, actor_id=actor_id, allowed_packs=allowed_packs)
    for draft in drafts.get("drafts", []):
        rows.append({"id": f"{draft['draft_id']}-{draft['version']}", "route": "plan_changes", "title": "Product revision brief",
                     "state": f"draft version {draft['version']}", "summary": draft["purpose"], "updated_at": draft["created_at"],
                     "params": {"draft_id": draft["draft_id"], "version": draft["version"]}})
    if configuration_proposals.applicable(root, pack):
        import review_inbox
        proposals = configuration_proposals.list_proposals(root, pack, actor_id=actor_id, allowed_packs=allowed_packs)
        for proposal in proposals.get("proposals", []):
            loaded = configuration_proposals.load(root, pack, proposal_id=proposal["proposal_id"], actor_id=actor_id, allowed_packs=allowed_packs)
            state = "source changed, review again" if proposal["stale"] else (
                "submitted for review" if loaded.get("submission") else "proposal staged")
            if loaded.get("review_request"):
                request = review_inbox.load_request(root, pack, request_id=loaded["review_request"], actor_id=actor_id, allowed_packs=allowed_packs)
                if request.get("ok"):
                    state = "review: " + request["status_words"]
            rows.append({"id": proposal["proposal_id"], "route": "plan_changes", "title": "Configuration proposal",
                "state": state, "summary": proposal["purpose"], "updated_at": proposal["created_at"],
                "params": {"proposal_id": proposal["proposal_id"]}})
        # Requests are the product's, not the actor's: a reviewer resumes one from the same queue.
        rows.extend(review_inbox.recent(root, pack, actor_id, allowed_packs=allowed_packs))
    try:
        _product, _pack, owner, folder = scientific_definitions._scope(root, pack, actor_id, allowed_packs)
        for path in sorted(folder.glob("*.json"))[:200]:
            record = json.loads(scientific_definitions._read(path))
            if record.get("pack") != pack or record.get("owner") != owner:
                continue
            row = scientific_definitions.describe(root, pack, actor_id, item_id=record["item_id"], allowed_packs=allowed_packs)
            if row["ok"] and row["saved"]:
                rows.append({"id": path.stem, "route": "scientific_draft", "title": f"Definition draft: {row['selected']['variable_id']}",
                    "state": "source changed, review again" if row["stale_draft"] else "unfinished scientific draft",
                    "summary": record["item_id"], "updated_at": datetime.fromtimestamp(path.stat().st_mtime, timezone.utc).isoformat(),
                    "params": {"item_id": record["item_id"], "variable": row["selected"]["variable_id"]}})
    except (ValueError, OSError, KeyError, TypeError):
        pass
    return rows
