"""Six-layer EDA review beside source evidence and candidate validation."""
from __future__ import annotations

import streamlit as st

import eda_workspace as backend

PREFIX = "eda_workspace_"


def _errors(result):
    for error in result.get("errors", []):
        st.error(error)


def _next(receipt=None):
    if st.button("Review source evidence", key=PREFIX + "source"):
        return {"route": "source_evidence", "params": {"receipt": receipt} if receipt else {}}
    if st.button("Review candidate validation", key=PREFIX + "validation"):
        return {"route": "progress", "params": {"action_id": "g5_validate", **({"receipt": receipt} if receipt else {})}}
    if receipt and st.button("Review this build's release readiness", key=PREFIX + "release"):
        return {"route": "release_readiness", "params": {"receipt": receipt}}
    return None


def _evidence(result):
    st.markdown("**Exact report verified against the selected receipt**")
    st.caption("The file digest and embedded report agree with this manifest and its current configuration. This checks recorded bindings; it does not authenticate who ran the build.")
    if not result["candidate_passed"]:
        st.warning(f"The candidate has {result['candidate_failure_count']} failed stage finding(s). Use the layers below to understand the evidence before continuing validation.")
    acceptance = result["acceptance"]
    if acceptance is None:
        st.info("EDA acceptance: not evaluated. This product declares no EDA acceptance limits; these counts are evidence to review.")
    elif not acceptance["passed"]:
        st.warning(f"Declared EDA acceptance checks failed: {acceptance['failures']} finding(s).")
    else:
        st.write("Declared EDA acceptance checks passed for these recorded counts.")
    if acceptance and acceptance["unchecked"]:
        st.warning(f"{acceptance['unchecked']} EDA acceptance check(s) remain unchecked.")
    for layer in result["layers"]:
        with st.expander(layer["title"] + " · " + layer["state"], expanded=True):
            st.write(layer["question"])
            if layer["rows"]:
                st.dataframe(layer["rows"], hide_index=True, width="stretch")
            else:
                st.info("No collected counts are available for this layer. This is not a passing check.")
            for note in layer["notes"]:
                st.write(note)
    st.caption("Tables contain aggregate counts and configuration labels only. Restricted free-text diagnostics and unexpected delivered values remain in the original report for the data expert to inspect in the governed environment.")


def render(root, pack, actor_id, *, allowed_packs, local_demo, can_write, can_review=False,
           route="eda_review", params=None):
    params = params or {}
    context = (str(root), pack, actor_id, tuple(sorted(allowed_packs or [])), local_demo, can_write, can_review)
    if st.session_state.get(PREFIX + "context") != context:
        for key in list(st.session_state):
            if key.startswith(PREFIX):
                del st.session_state[key]
        st.session_state[PREFIX + "context"] = context
    st.subheader("Review the build's six evidence layers")
    st.write("Choose a completed build, receive its exact EDA report, then review source coverage, keys, relationships, dates, the cohort funnel and the built dataset.")
    st.caption(backend.NOTICE)
    baseline = backend.describe(root, pack, actor_id, allowed_packs=allowed_packs)
    if not baseline["ok"]:
        _errors(baseline)
        return None
    requested_review = params.get("review_id")
    saved = backend.recent(root, pack, actor_id, allowed_packs=allowed_packs)
    saved_options = {row["id"]: row["title"] for row in saved}
    if saved_options:
        key = PREFIX + "saved"
        if st.session_state.get(PREFIX + "requested_review") != requested_review:
            st.session_state[PREFIX + "requested_review"] = requested_review
            if requested_review:
                st.session_state[key] = requested_review if requested_review in saved_options else None
        if st.session_state.get(key) not in saved_options:
            st.session_state[key] = None
        resume = st.selectbox("Resume a saved evidence binding", list(saved_options), index=None, key=key,
                              format_func=saved_options.get, placeholder="Choose recorded work")
        if resume:
            result = backend.read(root, pack, actor_id, resume, allowed_packs=allowed_packs)
            if not result["ok"]:
                _errors(result)
                st.info("If this is another computer, ask the data expert to place the exact report in its restricted evidence folder. Receive it below to verify its digest before saving a new locator.")
            else:
                st.info("Saved branch metadata rechecked against the current receipt, configuration and restricted report.")
                _evidence(result)
                return _next(result["record"]["receipt"])
    elif requested_review:
        st.warning("That saved evidence binding is unavailable for this product. Choose the intended build again.")
    candidates = {row["receipt"]: row for row in baseline["candidates"]}
    if not candidates:
        st.info("No build receipt is recorded for this product. The data expert must run the intended delivery in the governed environment and return its manifest before EDA can be reviewed.")
        if st.button("Prepare or locate the build", key=PREFIX + "build"):
            return {"route": "progress", "params": {"action_id": "g5_build"}}
        return None
    key = PREFIX + "receipt"
    requested = (params.get("receipt"), params.get("build_id"))
    if st.session_state.get(PREFIX + "requested") != requested:
        st.session_state[PREFIX + "requested"] = requested
        if requested[0] or requested[1]:
            matches = [r for r, row in candidates.items() if r == requested[0] or (not requested[0] and row["build_id"] == requested[1])]
            st.session_state[key] = matches[0] if len(matches) == 1 else None
    if st.session_state.get(key) not in candidates:
        st.session_state[key] = None
    receipt = st.selectbox("Exact build receipt", list(candidates), key=key, index=None,
                           format_func=lambda item: candidates[item]["build_id"] + " · " + item,
                           placeholder="Choose the build; no latest build is assumed")
    if not receipt:
        return None
    baseline = backend.describe(root, pack, actor_id, allowed_packs=allowed_packs, receipt=receipt)
    if not baseline["ok"]:
        _errors(baseline)
        return None
    basis = (receipt, baseline["digest"])
    if st.session_state.get(PREFIX + "basis") not in (None, basis):
        st.session_state.pop(PREFIX + "received", None)
        st.session_state[PREFIX + "confirm"] = False
        st.warning("The build or product changed. Receive the current report and review its counts again.")
    st.session_state[PREFIX + "basis"] = basis
    selected = baseline["selected"]
    if not selected["eda_recorded"] or not selected["artifact_recorded"] or not selected["report_sha256"]:
        st.info("This receipt does not bind a completed EDA artifact. Ask the data expert to enable EDA collection in the existing runtime and return the report with its generated manifest. No evidence is inferred from its absence.")
        with st.expander("Runtime handoff"):
            st.write("Use the existing run_rwdp EDA collection option (eda=true). A declared qc.eda_acceptance contract also requires collection. Return eda_report.json and the exact manifest that records artifacts.eda_report_sha256. Run delivered data in its governed environment.")
        return _next(receipt)
    if not baseline["restricted_folder"]["ok"]:
        st.info(baseline["restricted_folder"]["reason"])
        return _next(receipt)
    st.write("The data expert places the completed JSON artifact in this computer's configured restricted evidence folder. Enter its relative filename; patient data uploads are not accepted.")
    name = st.text_input("EDA report filename", key=PREFIX + "filename", placeholder="build-2026q3/eda_report.json",
                         help="A JSON file under the configured restricted evidence folder. The report must match this build's recorded SHA256 and embedded EDA document.")
    if st.button("Receive and check the EDA report", key=PREFIX + "receive", disabled=not name.strip()):
        st.session_state[PREFIX + "confirm"] = False
        result = backend.receive(root, pack, actor_id, receipt=receipt, report_name=name,
                                 expected_digest=baseline["digest"], allowed_packs=allowed_packs)
        if result["ok"]:
            # Only metadata is retained in widget state; reread counts every render.
            st.session_state[PREFIX + "received"] = (name, result["review_id"])
        else:
            st.session_state.pop(PREFIX + "received", None)
            _errors(result)
    received = st.session_state.get(PREFIX + "received")
    if received and received[0] == name:
        result = backend.receive(root, pack, actor_id, receipt=receipt, report_name=name,
                                 expected_digest=baseline["digest"], allowed_packs=allowed_packs)
        if not result["ok"] or result.get("review_id") != received[1]:
            st.session_state.pop(PREFIX + "received", None)
            st.session_state[PREFIX + "confirm"] = False
            _errors(result)
            st.warning("The received evidence changed or is unavailable. Receive it again before recording its binding.")
        else:
            _evidence(result)
            st.markdown("**Save this evidence reference in your branch**")
            st.write("Only build, receipt, report and configuration bindings are saved. This records a reviewable reference; it does not record a scientific approval. Restricted counts stay outside Git.")
            with st.expander("Review the metadata diff", expanded=True):
                st.code(result["diff"], language="diff")
            confirmed = st.checkbox("I reviewed this metadata diff and want to save this evidence binding.", key=PREFIX + "confirm")
            if st.button("Save EDA evidence binding", key=PREFIX + "save", disabled=not (local_demo and can_write and confirmed)):
                saved_result = backend.save_review(root, pack, actor_id, receipt=receipt, report_name=name,
                    expected_digest=baseline["digest"], expected_review_id=result["review_id"], allowed_packs=allowed_packs,
                    local_demo=local_demo, can_write=can_write, confirmed=confirmed)
                if saved_result["ok"]:
                    st.success("EDA evidence binding saved in the branch. No approval or release was recorded.")
                    return {"route": "eda_review", "params": {"review_id": saved_result["review_id"]}, "changed": saved_result["changed"]}
                _errors(saved_result)
    return _next(receipt)
