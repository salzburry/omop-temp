"""One FIFO heavy-runtime lease across this local account's portal checkouts.

The existing OS process lock owns exclusion; tickets own ordering only. Tickets
contain process identity, never product names, reviewers or model arguments.
Private job journals keep progress/cancellation and canonical workflow results.
"""
from contextlib import contextmanager
from contextvars import ContextVar
import json
import hashlib
import os
from pathlib import Path
import time
import uuid

import local_process_lock as locks
import portal_runtime

_HELD = ContextVar("rwd_heavy_runtime_lease", default=None)
MAX_WAIT_SECONDS = 6 * 60 * 60
POLL_SECONDS = 0.2
MAX_TICKETS = 16
WAITING = "Waiting for another local heavy check to finish. You can cancel this queued action."
RUNNING = "The local heavy-check slot is available. Checking the reviewed inputs before execution."


class Cancelled(ValueError):
    """The user cancelled while waiting; no protected action has started."""


def _directory():
    # RWDP_STATE_DIR, checkout and portal author must not create separate queues.
    # Separate OS accounts require a hosted scheduler and are outside local mode.
    base = Path(os.environ.get("LOCALAPPDATA") or Path.home() / ".local/state")
    path = base / "RwdPortal" / "heavy-runtime"
    if not base.is_absolute() or path.absolute() != path.resolve() or path.resolve().is_relative_to(Path(__file__).resolve().parents[2]):
        raise ValueError("The local heavy-check queue redirects to another directory. Restore its user-local location.")
    path.mkdir(parents=True, exist_ok=True)
    return path.resolve()


def _ticket(path):
    if path.is_symlink() or not path.is_file() or path.stat().st_size > locks.MAX_OWNER_BYTES:
        raise ValueError("A local heavy-check queue ticket cannot be inspected safely.")
    try:
        value = json.loads(path.read_bytes())
        if (set(value) != {"version", "id", "created", "owner", "children", "state"} or value["version"] != 1
                or value["id"] != path.stem or len(path.stem) != 32
                or any(c not in "0123456789abcdef" for c in path.stem)
                or type(value["created"]) is not int or value["created"] <= 0
                or value["state"] not in {"waiting", "running", "released"}
                or not isinstance(value["owner"], dict) or not isinstance(value["children"], list)
                or len(value["children"]) > 20 or any(not isinstance(item, dict) for item in value["children"])):
            raise ValueError()
        return value
    except (ValueError, TypeError, KeyError, RecursionError):
        raise ValueError("A local heavy-check queue ticket is unreadable. Preserve it for inspection.") from None


def _waiting(directory):
    paths = list(directory.glob("*.json"))
    if len(paths) > MAX_TICKETS:
        raise ValueError("The local heavy-check queue exceeds its capacity. Review queued actions before adding another.")
    live = []
    for path in paths:
        value = _ticket(path)
        alive = locks.process_alive(value["owner"])
        children = [locks.process_alive(item) for item in value["children"]]
        if alive is None or any(item is None for item in children):
            raise ValueError("A queued heavy check belongs to an unverifiable process. Inspect its local queue ticket before continuing.")
        if (not alive or value["state"] == "released") and not any(children):
            # Only validated dead-owner tickets inside this exact directory are removed.
            path.unlink()
        else:
            live.append(value)
    return sorted(live, key=lambda row: (row["created"], row["id"]))


@contextmanager
def _admission(directory):
    deadline = time.monotonic() + 10
    while True:
        guard = locks.locked(directory / "admission.lock", directory)
        try:
            guard.__enter__()
            break
        except ValueError as error:
            if "already being" not in str(error) or time.monotonic() >= deadline:
                raise
            if portal_runtime.job_cancelled():
                raise Cancelled("Cancelled while waiting for a local heavy-check slot.") from None
            time.sleep(POLL_SECONDS)
    try:
        yield
    finally:
        guard.__exit__(None, None, None)


def _remove(directory, path, value):
    # Cancellation callbacks may remain true during cleanup. Never leave our live
    # ticket at the front just because that callback refuses admission waiting.
    token = portal_runtime.job_callbacks()
    try:
        with _admission(directory):
            if path.exists() and _ticket(path) == value:
                path.unlink()
    finally:
        portal_runtime.reset_job_callbacks(token)


def orphan_state(owner):
    """Only inspect tickets of the caller's already scoped, verified dead worker."""
    if locks.process_alive(owner) is not False:
        return {"present": False, "can_stop": False}
    directory = _directory()
    matching = []
    for path in directory.glob("*.json"):
        try:
            ticket = _ticket(path)
        except (OSError, ValueError):
            continue
        if ticket["owner"] == owner and ticket["children"]:
            matching.append(ticket)
    states = [locks.process_alive(child) for ticket in matching for child in ticket["children"]]
    live = any(state is not False for state in states)
    return {"present": live, "can_stop": live and all(state is not None for state in states),
            "count": sum(state is True for state in states),
            "digest": hashlib.sha256(json.dumps(sorted(matching, key=lambda value: value["id"]), sort_keys=True).encode()).hexdigest()}


def _stop_child(identity):
    """Terminate only a still-matching child of the explicitly selected ended action."""
    alive = locks.process_alive(identity)
    if alive is False:
        return
    if alive is not True:
        raise ValueError("The remaining process identity cannot be verified. It was not stopped.")
    if os.name == "nt":
        _stop_windows_child(identity)
    else:
        _stop_pidfd_child(identity)
    deadline = time.monotonic() + 5
    while locks.process_alive(identity) is True and time.monotonic() < deadline:
        time.sleep(POLL_SECONDS)
    if locks.process_alive(identity) is not False:
        raise ValueError("The remaining process has not verifiably ended. Its queue capacity is retained.")


_RECOVERY_FAILED = "The selected remaining process could not be stopped safely. Its queue record is retained."
_RECOVERY_TREE = "This legacy process has descendants whose ownership cannot be proved. Inspect its remaining processes before retrying."


class _WindowsRecovery:
    """Small handle-bound Win32 boundary; no command, executable name or PID kill."""
    def __init__(self):
        import ctypes
        from ctypes import wintypes as w
        self.c, self.w = ctypes, w
        self.kernel = ctypes.WinDLL("kernel32", use_last_error=True)
        for name, args, result in (
            ("OpenProcess", [w.DWORD, w.BOOL, w.DWORD], w.HANDLE),
            ("CloseHandle", [w.HANDLE], w.BOOL),
            ("GetProcessTimes", [w.HANDLE, *([ctypes.POINTER(w.FILETIME)] * 4)], w.BOOL),
            ("WaitForSingleObject", [w.HANDLE, w.DWORD], w.DWORD),
            ("CreateJobObjectW", [ctypes.c_void_p, w.LPCWSTR], w.HANDLE),
            ("AssignProcessToJobObject", [w.HANDLE, w.HANDLE], w.BOOL),
            ("IsProcessInJob", [w.HANDLE, w.HANDLE, ctypes.POINTER(w.BOOL)], w.BOOL),
            ("TerminateJobObject", [w.HANDLE, w.UINT], w.BOOL),
            ("QueryInformationJobObject", [w.HANDLE, ctypes.c_int, ctypes.c_void_p, w.DWORD, ctypes.c_void_p], w.BOOL),
            ("CreateToolhelp32Snapshot", [w.DWORD, w.DWORD], w.HANDLE),
        ):
            fn = getattr(self.kernel, name)
            fn.argtypes, fn.restype = args, result

    def open(self, pid, *, owner=False):
        # Assignment requires SET_QUOTA and TERMINATE; all handles remain local.
        handle = self.kernel.OpenProcess(0x100000 | 0x1000 | (0x101 if owner else 0), False, pid)
        if not handle and self.c.get_last_error() != 87:
            raise OSError(_RECOVERY_FAILED)
        return handle

    def close(self, handle):
        if handle:
            self.kernel.CloseHandle(handle)

    def start(self, handle):
        if self.kernel.WaitForSingleObject(handle, 0) == 0:
            return False
        times = [self.w.FILETIME() for _ in range(4)]
        if not self.kernel.GetProcessTimes(handle, *(self.c.byref(value) for value in times)):
            raise OSError(_RECOVERY_FAILED)
        return str((times[0].dwHighDateTime << 32) | times[0].dwLowDateTime)

    def create_job(self):
        # Intentionally no KILL_ON_JOB_CLOSE: a refused inspection must not kill
        # the original. Future ordinary children inherit this job on assignment.
        job = self.kernel.CreateJobObjectW(None, None)
        if not job:
            raise OSError(_RECOVERY_FAILED)
        return job

    def assign(self, job, handle):
        if not self.kernel.AssignProcessToJobObject(job, handle):
            raise OSError(_RECOVERY_FAILED)

    def contains(self, job, handle):
        inside = self.w.BOOL()
        if not self.kernel.IsProcessInJob(handle, job, self.c.byref(inside)):
            raise OSError(_RECOVERY_FAILED)
        return bool(inside.value)

    def children(self, pid):
        c, w = self.c, self.w

        class Entry(c.Structure):
            _fields_ = [("size", w.DWORD), ("usage", w.DWORD), ("pid", w.DWORD),
                        ("heap", c.c_size_t), ("module", w.DWORD), ("threads", w.DWORD),
                        ("parent", w.DWORD), ("priority", w.LONG), ("flags", w.DWORD),
                        ("exe", w.WCHAR * 260)]

        snapshot = self.kernel.CreateToolhelp32Snapshot(2, 0)  # TH32CS_SNAPPROCESS
        if not snapshot or snapshot == c.c_void_p(-1).value:
            raise OSError(_RECOVERY_FAILED)
        try:
            first, following = self.kernel.Process32FirstW, self.kernel.Process32NextW
            for fn in (first, following):
                fn.argtypes, fn.restype = [w.HANDLE, c.POINTER(Entry)], w.BOOL
            entry = Entry()
            entry.size = c.sizeof(entry)
            present = first(snapshot, c.byref(entry))
            children, count = [], 0
            while present:
                count += 1
                if count > 65536:
                    raise OSError(_RECOVERY_FAILED)
                if entry.parent == pid:
                    children.append(entry.pid)
                present = following(snapshot, c.byref(entry))
            if c.get_last_error() != 18:  # ERROR_NO_MORE_FILES
                raise OSError(_RECOVERY_FAILED)
            return children
        finally:
            self.close(snapshot)

    def active(self, job):
        c, w = self.c, self.w

        class Accounting(c.Structure):
            _fields_ = [(name, c.c_longlong) for name in ("user", "kernel", "period_user", "period_kernel")] + [
                (name, w.DWORD) for name in ("faults", "total", "active", "terminated")]

        value = Accounting()
        if not self.kernel.QueryInformationJobObject(job, 1, c.byref(value), c.sizeof(value), None):
            raise OSError(_RECOVERY_FAILED)
        return value.active

    def terminate(self, job):
        if not self.kernel.TerminateJobObject(job, 130):
            raise OSError(_RECOVERY_FAILED)


def _stop_windows_child(identity):
    api = _WindowsRecovery()
    handle = job = None
    children, jobs = [], []
    try:
        handle = api.open(identity["pid"], owner=True)
        # Recheck through the retained HANDLE, not a second PID lookup. A new
        # process that took this PID after the initial check must be untouched.
        if not handle or api.start(handle) != identity["start"]:
            return
        job = api.create_job()
        jobs.append(job)
        api.assign(job, handle)
        bound = [handle]
        pending = [(handle, identity["pid"], identity["start"], job)]
        deadline = time.monotonic() + 5
        while pending:
            parent, parent_pid, parent_start, parent_job = pending.pop()
            if time.monotonic() >= deadline or api.start(parent) != parent_start:
                raise ValueError(_RECOVERY_TREE)
            for pid in api.children(parent_pid):
                child = api.open(pid, owner=True)
                if not child:
                    raise ValueError(_RECOVERY_TREE)
                children.append(child)
                if len(children) > 128 or time.monotonic() >= deadline:
                    raise ValueError(_RECOVERY_TREE)
                started = api.start(child)
                # A stale Toolhelp parent PID can name an older, ended parent.
                if started is not False and int(started) < int(parent_start):
                    continue
                if api.contains(parent_job, child):
                    bound.append(child)
                    continue  # A future child already inherited our containment.
                # Keep both handles alive and re-read the parent relationship.
                # The PID snapshot alone never authorizes assigning a process:
                # either endpoint changing/ending makes this ancestry uncertain.
                related = pid in api.children(parent_pid)
                if (not related or started is False or api.start(parent) != parent_start
                        or api.start(child) != started):
                    raise ValueError(_RECOVERY_TREE)
                # Existing launchers can own an older, separate job hierarchy.
                # Nest an empty job per verified process instead of merging
                # incompatible nonempty jobs; every kill still names a handle.
                child_job = api.create_job()
                jobs.append(child_job)
                api.assign(child_job, child)
                bound.append(child)
                pending.append((child, pid, started, child_job))
        # A legacy ticket cannot reconstruct descendants already orphaned before
        # inspection. Only retained, verified ancestry is included; newly spawned
        # children belong to this exact job, even if their parent now exits.
        for owned in reversed(jobs):
            api.terminate(owned)
        deadline = time.monotonic() + 5
        def ended():
            return not any(api.active(owned) for owned in jobs) and all(api.start(item) is False for item in bound)
        while not ended() and time.monotonic() < deadline:
            time.sleep(POLL_SECONDS)
        if not ended():
            raise ValueError(_RECOVERY_FAILED)
    except OSError:
        raise ValueError(_RECOVERY_FAILED) from None
    finally:
        for child in reversed(children):
            api.close(child)
        for owned in reversed(jobs):
            api.close(owned)
        api.close(handle)


def _pidfd_children(pid):
    """Read every stopped process thread's kernel child list, without PID signals."""
    directory = Path(f"/proc/{pid}/task")
    children = set()
    tasks = list(directory.iterdir())
    if not tasks or len(tasks) > 4096:
        raise OSError(_RECOVERY_TREE)
    for task in tasks:
        children.update((task / "children").read_text().split())
    return children


def _pidfd_stopped(pid):
    tasks = list(Path(f"/proc/{pid}/task").iterdir())
    if not tasks or len(tasks) > 4096:
        raise OSError(_RECOVERY_TREE)
    for task in tasks:
        raw = (task / "stat").read_text()
        if raw[raw.rfind(")") + 2:].split()[0] not in {"T", "t"}:
            return False
    return True


def _stop_pidfd_child(identity):
    import signal
    if not hasattr(os, "pidfd_open") or not hasattr(signal, "pidfd_send_signal"):
        raise ValueError("This platform cannot safely recover legacy process identities. Inspect its remaining processes before retrying.")
    descriptor, stopped, killed = None, False, False
    try:
        descriptor = os.pidfd_open(identity["pid"], 0)
        # Opening first and checking afterwards makes PID replacement harmless:
        # even a subsequent replacement cannot redirect this retained pidfd.
        alive = locks.process_alive(identity)
        if alive is False:
            return
        if alive is not True:
            raise ValueError(_RECOVERY_FAILED)
        already_stopped = _pidfd_stopped(identity["pid"])
        signal.pidfd_send_signal(descriptor, signal.SIGSTOP)
        stopped = not already_stopped
        deadline = time.monotonic() + 5
        while not _pidfd_stopped(identity["pid"]):
            if time.monotonic() >= deadline:
                raise ValueError(_RECOVERY_FAILED)
            time.sleep(POLL_SECONDS)
        if _pidfd_children(identity["pid"]):
            raise ValueError(_RECOVERY_TREE)
        signal.pidfd_send_signal(descriptor, signal.SIGKILL)
        killed = True
    except ProcessLookupError:
        pass
    except OSError:
        raise ValueError(_RECOVERY_FAILED) from None
    finally:
        if descriptor is not None:
            try:
                if stopped and not killed:
                    try:
                        signal.pidfd_send_signal(descriptor, signal.SIGCONT)
                    except ProcessLookupError:
                        pass
            finally:
                os.close(descriptor)


def stop_orphans(owner, *, expected_digest, confirmed=False):
    if confirmed is not True:
        raise ValueError("Explicitly request stopping the remaining processes for this ended action.")
    directory = _directory()
    with _admission(directory):
        current = orphan_state(owner)
        if not current["can_stop"] or current.get("digest") != expected_digest:
            raise ValueError("The remaining process records changed or cannot be verified. Refresh this action.")
        children = []
        for path in directory.glob("*.json"):
            try:
                ticket = _ticket(path)
            except (OSError, ValueError):
                continue
            if ticket["owner"] == owner:
                children.extend(ticket["children"])
    # Do not hold queue admission during OS termination. Each child is rechecked
    # by its original process-start identity, never by a user-entered process ID.
    for child in children:
        _stop_child(child)
    with _admission(directory):
        if orphan_state(owner)["present"]:
            raise ValueError("A remaining process still owns this action's slot. Refresh before retrying.")
        _waiting(directory)
    return {"stopped": current["count"]}


@contextmanager
def lease(*, on_wait=None, on_acquired=None):
    """Wait in FIFO order, cancellably; nested calls in the same worker reuse its lease."""
    if _HELD.get() == os.getpid():
        yield
        return
    if portal_runtime.job_cancelled():
        raise Cancelled("Cancelled before requesting a local heavy-check slot.")
    directory = _directory()
    value = {"version": 1, "id": uuid.uuid4().hex, "created": time.time_ns(), "owner": locks.process_identity(), "children": [], "state": "waiting"}
    path = directory / (value["id"] + ".json")
    import handoffs
    with _admission(directory):
        current = _waiting(directory)
        if len(current) >= MAX_TICKETS:
            raise ValueError("The local heavy-check queue is full. Finish or cancel a queued action first.")
        # Use admission order, not process creation order.
        value["created"] = max(time.time_ns(), current[-1]["created"] + 1 if current else 1)
        handoffs._write(path, value)
    deadline = time.monotonic() + MAX_WAIT_SECONDS
    held = None
    waiting_announced = False
    try:
        while held is None:
            if portal_runtime.job_cancelled():
                raise Cancelled("Cancelled while waiting for a local heavy-check slot.")
            if time.monotonic() >= deadline:
                raise ValueError("The local heavy-check queue wait expired. Inspect the current action before explicitly retrying.")
            with _admission(directory):
                waiting = _waiting(directory)
                if not any(item == value for item in waiting):
                    raise ValueError("This heavy-check ticket changed while queued. Review the retained action.")
                if waiting[0] == value:
                    candidate = locks.locked(directory / "running.lock", directory)
                    try:
                        candidate.__enter__()
                        held = candidate
                        value["state"] = "running"
                        handoffs._write(path, value)
                    except ValueError as error:
                        if "already being" not in str(error):
                            raise
            if held is None:
                if not waiting_announced:
                    portal_runtime.job_progress(WAITING)
                    if on_wait:
                        on_wait()
                    waiting_announced = True
                time.sleep(POLL_SECONDS)
        if portal_runtime.job_cancelled():
            raise Cancelled("Cancelled before executing the queued heavy check.")
        portal_runtime.job_progress(RUNNING)
        if on_acquired:
            on_acquired()
        token = _HELD.set(os.getpid())
        def observe(process, started):
            with _admission(directory):
                if _ticket(path) != value:
                    raise ValueError("The heavy-check process ticket changed during execution.")
                if started:
                    if process.poll() is None:
                        try:
                            child = locks.process_identity(process.pid)
                        except ValueError:
                            if process.poll() is None:
                                raise
                        else:
                            value["children"].append(child)
                else:
                    # Never release capacity while a launched child is still live.
                    value["children"] = [child for child in value["children"]
                        if child["pid"] != process.pid or locks.process_alive(child) is not False]
                handoffs._write(path, value)
        observer_token = portal_runtime.process_observer(observe)
        try:
            yield
        finally:
            portal_runtime.reset_process_observer(observer_token)
            _HELD.reset(token)
    finally:
        try:
            if held is not None:
                held.__exit__(None, None, None)
        finally:
            if not value["children"]:
                _remove(directory, path, value)
            else:
                callback_token = portal_runtime.job_callbacks()
                try:
                    with _admission(directory):
                        if _ticket(path) == value:
                            value["state"] = "released"
                            handoffs._write(path, value)
                finally:
                    portal_runtime.reset_job_callbacks(callback_token)
