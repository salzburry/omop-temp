"""Repository documents are explicit read actions, never Streamlit HTTP routes.

These pure helpers treat Markdown as content. They do not execute instructions,
fetch URLs, edit files, or expose arbitrary source data through the document reader.
Scope and canonical-path checks run again when a document is opened.
"""
from __future__ import annotations

import html
import re
from pathlib import Path
from urllib.parse import unquote, urlsplit

TEXT_EXTENSIONS = {".md", ".txt", ".rst", ".yaml", ".yml", ".json", ".toml"}
ROOT_PREFIXES = {"docs", "platform", "experiments", "products", "fixtures", "governance", "work",
                 "sandbox", "refreshes", "releases", "resources", "intake"}
DATA_DIRS = {"data", "raw", "raw_data", "patient_data", "patient-level", "patients", "inputs",
             "outputs", "exports", "deliveries", "delivery", "node_modules", "archive", "archives"}


def _blocked(reason, *, redacted=False):
    return {"kind": "blocked", "target": "", "path": "", "anchor": "", "line": None,
            "reason": reason, "redacted": redacted}


def _policy(path):
    parts = [part.casefold() for part in path.parts]
    if any(part.startswith(".") or part in DATA_DIRS for part in parts):
        return "This location is not available through the documentation reader."
    name = path.name.casefold()
    if any(word in name for word in ("private_key", "private-key", "credentials", "password", "secret", "id_rsa", "id_ed25519")):
        return "Private credentials are not available through the documentation reader."
    if any(suffix in {".pem", ".key", ".p12", ".pfx"} for suffix in path.suffixes):
        return "Private credentials are not available through the documentation reader."
    if path.suffix.casefold() not in TEXT_EXTENSIONS:
        return "This reader supports documentation and review text; data files and workbooks need their dedicated workflow."
    if any(word in name for word in ("patient_records", "patient_data", "patient_level", "patient-level", "patients.", "sample_data", "raw_data")):
        return "Source records and patient-level data are not available through the documentation reader."
    if path.suffix.casefold() in {".txt", ".rst"} and name != "requirements.txt" \
            and not any(part in {"docs", "governance", "handoff"} for part in parts):
        return "Open source text through its dedicated workflow; this reader is limited to documentation and governed review records."
    if path.suffix.casefold() in {".json", ".yaml", ".yml", ".toml"}:
        if any(word in name for word in ("patient", "sample_data", "raw_data", "profile", "extract")):
            return "Source records and patient-level data are not available through the documentation reader."
        if not any(part in {"governance", "config", "handoff", "variables", "codelists", "resources", "work"} for part in parts) \
                and name not in {"source_refs.yaml", "registry.yaml", "manifest.yaml", "manifest.json", "receipt.yaml", "receipt.json"}:
            return "Open this file through its dedicated workflow; the generic reader is limited to documentation and governed review records."
    return ""


def resolve(root, target, source_path="", allowed_packs=None):
    """Resolve a link to metadata without reading content or contacting a website.

    ``source_path`` is the source document's repository-relative filename. Standard
    document-relative links and explicit repository-root references are supported.
    ``allowed_packs=None`` means unconfined; an empty collection permits no pack.
    A trailing ``:line`` or GitHub-style ``#L12`` is retained for a source viewer.
    """
    raw = html.unescape(str(target or "").strip())
    if raw.startswith("<") and raw.endswith(">"):
        raw = raw[1:-1].strip()
    if raw.startswith("\\\\"):
        return _blocked("Network file shares need their dedicated source workflow.")
    decoded = unquote(raw).replace("\\", "/")
    if not decoded or any(ord(ch) < 32 for ch in decoded):
        return _blocked("This document reference is empty or invalid.")
    if decoded.startswith("#"):
        return {"kind": "anchor", "target": raw, "path": "", "anchor": decoded[1:], "line": None, "reason": ""}
    windows_path = bool(re.match(r"^[A-Za-z]:/", decoded))
    try:
        parsed = urlsplit(decoded if not windows_path else decoded[2:])
    except ValueError:
        return _blocked("This document reference is invalid.")
    if not windows_path and (parsed.scheme or parsed.netloc):
        scheme = parsed.scheme.lower()
        if (scheme in {"https", "http"} and parsed.netloc) or (scheme == "mailto" and parsed.path):
            return {"kind": "external", "target": raw, "path": "", "anchor": parsed.fragment, "line": None, "reason": ""}
        if not scheme and parsed.netloc:
            return {"kind": "external", "target": "https:" + raw, "path": "", "anchor": parsed.fragment, "line": None, "reason": ""}
        return _blocked("This link type is not supported by the documentation reader.")
    anchor = parsed.fragment
    local = (decoded.split("#", 1)[0].split("?", 1)[0] if windows_path else parsed.path)
    match = re.search(r":(\d+)(?::\d+)?$", local)
    line = int(match.group(1)) if match else None
    if match:
        local = local[:match.start()]
    if line is None and re.fullmatch(r"L\d+(?:-L?\d+)?", anchor):
        line = int(re.match(r"L(\d+)", anchor).group(1))
    try:
        base = Path(root).resolve()
        origin = (base / str(source_path).replace("\\", "/")).resolve() if source_path else base
        origin.relative_to(base)
        origin_dir = origin.parent if source_path else base
        first = local.lstrip("/").split("/", 1)[0].casefold()
        if windows_path:
            candidate = Path(local).resolve()
        elif local.startswith("/") or first in ROOT_PREFIXES:
            candidate = (base / local.lstrip("/")).resolve()
        else:
            candidate = (origin_dir / local).resolve()
        relative = candidate.relative_to(base)
        parts = relative.parts
        normalized_scope = None if allowed_packs is None else {str(p).replace("\\", "/").strip("/").casefold() for p in allowed_packs}
        if normalized_scope is not None:
            if parts and parts[0].casefold() in {"products", "fixtures"} and len(parts) < 4:
                return _blocked("Open product records through a product you can access.", redacted=True)
            if parts and parts[0].casefold() in {"products", "fixtures"} and len(parts) >= 4:
                pack = "/".join(parts[:4]).casefold()
                if pack not in normalized_scope:
                    return _blocked("This document is outside your product access.", redacted=True)
            if parts and parts[0].casefold() == "work":
                return _blocked("Open study evidence through the scoped Studies view.", redacted=True)
        reason = _policy(relative)
        if reason:
            return _blocked(reason)
        exists = candidate.is_file()
        return {"kind": "local" if exists else "missing", "target": relative.as_posix() + (f":{line}" if match else "") + ("#" + anchor if anchor else ""),
                "path": relative.as_posix(), "anchor": anchor, "line": line,
                "reason": "" if exists else "This document is not present yet. It may be a draft artifact that the product workflow still needs to create."}
    except (OSError, ValueError, TypeError):
        return _blocked("The document reference leaves the repository or cannot be resolved.", redacted=True)


def read_text(root, reference, allowed_packs=None, max_bytes=524288):
    """Read an allowed text document after revalidating its current path and scope."""
    reference = reference if isinstance(reference, dict) else {"target": reference}
    target = reference.get("path") or reference.get("target") or ""
    checked = resolve(root, target, allowed_packs=allowed_packs)
    result = {**checked, "ok": False, "text": "", "safe_markdown": "", "links": []}
    if checked["kind"] != "local":
        return result
    try:
        limit = min(max(1, int(max_bytes)), 2 * 1024 * 1024)
        with (Path(root).resolve() / checked["path"]).open("rb") as handle:
            contents = handle.read(limit + 1)
        if len(contents) > limit:
            result["reason"] = "This document is too large for an inline preview. Ask your data expert for the relevant section."
            return result
        if b"\x00" in contents:
            result["reason"] = "This file is not a supported text document."
            return result
        result["text"] = contents.decode("utf-8-sig").replace("\r\n", "\n")
        result["anchor"] = reference.get("anchor") or checked["anchor"]
        result["line"] = reference.get("line") or checked["line"]
        prepared = prepare_markdown(root, result["text"], source_path=checked["path"], allowed_packs=allowed_packs)
        result["safe_markdown"], result["links"] = prepared["markdown"], prepared["links"]
        result["ok"] = True
    except (OSError, ValueError, TypeError, UnicodeError):
        result["reason"] = "This document could not be read as UTF-8 text. It may have moved or need a dedicated viewer."
    return result


_INLINE = re.compile(r"(!?)\[((?:\\.|[^\[\]\n]|\[[^\]\n]*\])*)\]\(\s*(<[^>\n]+>|(?:\\.|[^\s()]|\([^()\n]*\))*)(?:\s+(?:\"[^\"\n]*\"|'[^'\n]*'))?\s*\)")
_DEFINITION = re.compile(r"^\s{0,3}\[([^\]]+)\]:\s*(<[^>\n]+>|\S+)(?:\s+.*)?$")
_REFERENCE = re.compile(r"(!?)\[([^\]\n]+)\]\[([^\]\n]*)\]")
_HTML_LINK = re.compile(r"<a\b[^>]*\bhref\s*=\s*(?:\"([^\"]*)\"|'([^']*)'|([^\s>]+))[^>]*>(.*?)</a>", re.IGNORECASE)
_HTML_IMAGE = re.compile(r"<img\b[^>]*\bsrc\s*=\s*(?:\"([^\"]*)\"|'([^']*)'|([^\s>]+))[^>]*>", re.IGNORECASE)


def prepare_markdown(root, text, source_path="", allowed_packs=None):
    """Keep external links/anchors; replace local hrefs with explicit reference metadata.

    Fenced and inline code are left verbatim. Governed Markdown remains document
    content; local links never turn into HTTP navigation under the Streamlit app.
    """
    text = str(text or "")
    links, definitions, definition_fence = [], {}, None
    for line in text.splitlines():
        marker = re.match(r"^\s{0,3}(`{3,}|~{3,})", line)
        if marker:
            token = marker.group(1)
            if definition_fence is None:
                definition_fence = token
            elif token[0] == definition_fence[0] and len(token) >= len(definition_fence):
                definition_fence = None
            continue
        if definition_fence:
            continue
        match = _DEFINITION.match(line)
        if match:
            definitions[match.group(1).casefold()] = match.group(2)

    def visit(label, target, original, image=False):
        ref = resolve(root, target, source_path=source_path, allowed_packs=allowed_packs)
        safe_label = "Restricted document" if ref.get("redacted") else label
        metadata = {"label": safe_label, **ref}
        if metadata not in links:
            links.append(metadata)
        if ref["kind"] in {"external", "anchor"}:
            return original
        return ("Image: " if image else "") + safe_label

    output, fence = [], None
    for line in text.splitlines(keepends=True):
        marker = re.match(r"^\s{0,3}(`{3,}|~{3,})", line)
        if marker:
            token = marker.group(1)
            if fence is None:
                fence = token
            elif token[0] == fence[0] and len(token) >= len(fence):
                fence = None
            output.append(line)
            continue
        if fence:
            output.append(line)
            continue
        definition = _DEFINITION.match(line.rstrip("\r\n"))
        if definition:
            ref = resolve(root, definition.group(2), source_path=source_path, allowed_packs=allowed_packs)
            output.append(line if ref["kind"] in {"external", "anchor"} else "\n")
            continue
        code_spans = []

        def hide_code(match):
            code_spans.append(match.group(0))
            return f"\x00CODE{len(code_spans) - 1}\x00"

        line = re.sub(r"(`+).*?\1", hide_code, line)
        line = _INLINE.sub(lambda m: visit(m.group(2), m.group(3), m.group(0), bool(m.group(1))), line)
        line = _REFERENCE.sub(lambda m: visit(m.group(2), definitions[(m.group(3) or m.group(2)).casefold()], m.group(0), bool(m.group(1)))
                              if (m.group(3) or m.group(2)).casefold() in definitions else m.group(0), line)
        line = re.sub(r"(?<!!)\[([^\]\n]+)\](?![\[(])", lambda m: visit(m.group(1), definitions[m.group(1).casefold()], m.group(0))
                      if m.group(1).casefold() in definitions else m.group(0), line)
        line = _HTML_LINK.sub(lambda m: visit(re.sub(r"<[^>]*>", "", m.group(4)), m.group(1) or m.group(2) or m.group(3), m.group(0)), line)
        line = _HTML_IMAGE.sub(lambda m: visit("Referenced image", m.group(1) or m.group(2) or m.group(3), m.group(0), True), line)
        line = re.sub(r"\x00CODE(\d+)\x00", lambda m: code_spans[int(m.group(1))], line)
        output.append(line)
    return {"markdown": "".join(output), "links": links}
