"""Scientific change plans and immutable, actor-scoped draft revisions.

The contract parser supplies the literal requirement and dependency list. Kept variables
are exactly the scientist's selection: dependencies are reported, never silently added.
The JSON result is a review packet, not executable configuration or clinical evidence.
"""
from __future__ import annotations

import hashlib
import errno
import json
import os
import re
import shutil
import sys
import tempfile
import uuid
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "platform" / "tools"))

import contract_lint as cl  # noqa: E402
import product_gates as pg  # noqa: E402


def _hash(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, ensure_ascii=False, default=str,
                                     separators=(",", ":")).encode("utf-8")).hexdigest()


class _DraftError(ValueError):
    pass


def _pack_path(root, pack, allowed_packs=None):
    base = Path(root).resolve()
    name = str(pack or "").replace("\\", "/")
    if not re.fullmatch(r"(?:products|fixtures)/[A-Za-z0-9_-]+/[A-Za-z0-9_-]+/\d{6}", name):
        raise _DraftError("Choose an existing product or reference pack.")
    path = base / name
    if path.resolve() != path or not path.is_dir():
        raise _DraftError("The selected pack is unavailable or redirects to another location.")
    if allowed_packs is not None:
        if not isinstance(allowed_packs, (list, tuple, set)) or name.casefold() not in {
                str(p).replace("\\", "/").casefold() for p in allowed_packs}:
            raise _DraftError("This product is outside your access.")
    return base, path, name


def _baseline(path, pack, registry, *, branch_text=False):
    """One exact input inventory; branch handoffs may normalize CRLF text only.

    Scientific approval and ordinary draft freshness use the default raw bytes.
    """
    files = [path / "handoff/FUNCTIONAL_CONTRACT.md", path / "source_refs.yaml"]
    for directory in ("config", "variables", "codelists"):
        folder = path / directory
        if folder.is_dir():
            files.extend(p for p in folder.rglob("*") if p.is_file() and p.suffix.lower() in (".yaml", ".yml", ".csv", ".tsv"))
    baseline = {"pack": pack, "registry": registry, "files": {}}
    for file in sorted(set(files)):
        if file.resolve() != file:
            raise _DraftError("A baseline file redirects to another location.")
        raw = file.read_bytes() if file.is_file() else None
        if raw is not None and branch_text:
            try:
                raw.decode("utf-8")
            except UnicodeError:
                pass  # Non-text inputs keep their exact raw digest.
            else:
                if b"\0" not in raw:
                    raw = raw.replace(b"\r\n", b"\n")
        baseline["files"][file.relative_to(path).as_posix()] = hashlib.sha256(raw).hexdigest() if raw is not None else None
    return baseline


def describe(root, pack):
    """Read contract rows and source identity; report input problems without a traceback.

    ``baseline_sha256`` binds contract, source references, config/variables/codelists,
    and the registry entry. Re-describe before reusing a plan to detect staleness.
    A missing contract is an intentional empty draft, not evidence of completeness.
    """
    result = {"pack": str(pack).replace("\\", "/"), "name": str(pack),
              "is_reference": False, "contract_sha256": None, "baseline_sha256": None,
              "rows": [], "source": {"vendor": "", "modality": ""}, "source_tables": {},
              "errors": [], "warnings": []}
    try:
        base, path, _name = _pack_path(root, pack)
        rel = path.relative_to(base)
        if not rel.parts or not path.is_dir():
            raise ValueError("Choose an existing product or reference pack.")
        result["pack"] = rel.as_posix()
        result["is_reference"] = rel.parts[0] != "products"
        if result["is_reference"]:
            result["warnings"].append("Reference material is never clinical approval or releasable evidence.")

        cfg_path = path / "config" / "data_product.yaml"
        if cfg_path.resolve() != cfg_path:
            raise _DraftError("The configuration redirects to another location.")
        cfg, err = pg.read_yaml(str(cfg_path))
        if err or not isinstance(cfg, dict):
            result["errors"].append("The product configuration is missing or unreadable; ask the product owner to repair it.")
            cfg = {}
        entry = pg.registry_entry(str(base), result["pack"]) or {}
        if not isinstance(entry, dict):
            entry = {}
        # Modality is governed by the registry; older entries explicitly default to EHR
        # through the existing authority. Config is used only for unregistered drafts.
        modality, modality_error = pg.pack_modality(entry or {"modality": cfg.get("modality")})
        if modality_error:
            result["errors"].append(modality_error)
        result["name"] = str(cfg.get("name") or entry.get("name") or result["pack"])
        result["source"] = {"vendor": str(cfg.get("vendor") or entry.get("vendor") or ""),
                            "modality": modality or ""}
        if isinstance(cfg.get("sources"), dict):
            result["source_tables"] = json.loads(json.dumps(cfg["sources"], default=str))
        if not result["source_tables"]:
            result["warnings"].append("No source tables are declared in the configuration yet; a vendor name alone does not establish a usable delivery.")

        contract = path / "handoff" / "FUNCTIONAL_CONTRACT.md"
        if contract.resolve() != contract:
            raise _DraftError("The contract redirects to another location.")
        if contract.is_file():
            contents = contract.read_bytes()
            result["contract_sha256"] = hashlib.sha256(contents).hexdigest()
            # The canonical reader normalizes Windows CRLF before parsing fenced records.
            # Hash raw bytes for staleness, but never pass unnormalized newlines to the parser.
            for rec in cl.typed_records(cl.read(str(contract)), keep_unnamed=True):
                if not rec.variable_id:
                    result["errors"].append("A contract record has no variable identifier; repair it before planning changes.")
                    continue
                result["rows"].append({
                    "variable_id": rec.variable_id,
                    "domain": rec.spec_refs[0].domain if rec.spec_refs else "other",
                    "definition": rec.cells.get("required_rule", ""),
                    "depends_on": [str(dep) for dep in rec.depends_on if str(dep).strip() != "none"],
                    "dependencies_declared": cl._list(rec.raw, "depends_on") is not None,
                })
            duplicate = [v for v, count in Counter(r["variable_id"].casefold() for r in result["rows"]).items() if count > 1]
            if duplicate:
                result["errors"].append("The contract has duplicate variable identifiers: " + ", ".join(duplicate))
            undeclared = [r["variable_id"] for r in result["rows"] if not r["dependencies_declared"]]
            if undeclared:
                result["warnings"].append("Dependency metadata is missing for: " + ", ".join(undeclared) + ". A data expert must establish their dependencies before implementation.")
        if not result["rows"]:
            result["warnings"].append("No contract definitions are available yet. Added definitions remain scientific proposals.")

        result["baseline_sha256"] = _hash(_baseline(path, result["pack"], entry))
    except (OSError, ValueError, TypeError, UnicodeError, AttributeError) as exc:
        result["errors"].append(f"The product draft could not be read: {type(exc).__name__}. Select a valid pack or ask its owner to repair the files.")
    return result


def build_plan(description, retained, additions, purpose, studies, target_source, target_modality):
    """Build an exportable review plan from a ``describe`` result; never write files.

    ``kept`` and ``removed`` are identifier lists, ``added`` is a list of proposed
    definition rows, and ``dependency_conflicts`` names retained records whose
    recorded dependencies were removed. ``valid`` means a review packet is ready,
    not that the proposed science, data mapping, or implementation is approved.
    """
    errors = list(description.get("errors") or [])
    warnings = list(description.get("warnings") or [])
    rows = description.get("rows") or []
    current = dict(description.get("source") or {})
    purpose = str(purpose or "").strip()
    if not purpose:
        errors.append("Describe why this product change is needed.")
    if not description.get("baseline_sha256"):
        errors.append("The starting product could not be fingerprinted. Reopen it before planning changes.")
    retained = list(retained or [])
    known = [row["variable_id"] for row in rows]
    known_set, retained_set = set(known), set(retained)
    if len({v.casefold() for v in known}) != len(known):
        errors.append("The starting contract has duplicate identifiers; a selection would be ambiguous.")
    if len({str(v).casefold() for v in retained}) != len(retained):
        errors.append("Select each retained variable only once.")
    unknown = sorted(retained_set - known_set)
    if unknown:
        errors.append("Unknown retained variable(s): " + ", ".join(str(v) for v in unknown))
    kept = [vid for vid in known if vid in retained_set]
    removed = [vid for vid in known if vid not in retained_set]
    added, added_ids = [], set()
    folded_known = {vid.casefold() for vid in known}
    for position, item in enumerate(additions or [], 1):
        if not isinstance(item, dict):
            errors.append(f"Addition {position} must specify a section, variable identifier, and definition.")
            continue
        vid = str(item.get("variable_id") or "").strip()
        domain = str(item.get("domain") or "").strip()
        # Retain literal user-authored scientific text in the exported proposal.
        definition = str(item.get("definition") or "")
        if not vid or not domain or not definition.strip():
            errors.append(f"Addition {position} needs a section, variable identifier, and definition.")
        if vid.casefold() in folded_known:
            errors.append(f"{vid} already exists. Reusing its identifier would hide a definition change; propose a reviewed revision instead.")
        if vid.casefold() in added_ids:
            errors.append(f"The added variable {vid} is listed more than once.")
        added_ids.add(vid.casefold())
        added.append({"variable_id": vid, "domain": domain, "definition": definition})

    proposed = {"vendor": str(target_source or "").strip(),
                "modality": str(target_modality or "").strip().lower()}
    if not proposed["vendor"]:
        errors.append("Name the proposed data source, or retain the current source name.")
    if proposed["modality"] not in pg.MODALITIES:
        errors.append("Choose a supported source modality: ehr or claims.")
    source_changed = proposed != {"vendor": str(current.get("vendor") or ""),
                                  "modality": str(current.get("modality") or "")}
    conflicts = []
    for row in rows:
        missing = sorted(set(row.get("depends_on") or []) & set(removed))
        if row["variable_id"] in retained_set and missing:
            conflicts.append({"variable_id": row["variable_id"], "missing_dependencies": missing})
            errors.append(f"{row['variable_id']} depends on removed variable(s): {', '.join(missing)}. Restore them or remove the dependent variable.")
    classification = "breaking" if removed or source_changed else ("additive" if added else "none")
    if classification == "none":
        errors.append("No product change is selected. Add or remove a definition, or propose a different source.")
    if not kept and not added:
        errors.append("Keep or propose at least one definition so the planned product is not empty.")
    clean_studies = [str(study).strip() for study in (studies or []) if str(study).strip()]
    if len(set(clean_studies)) != len(clean_studies):
        errors.append("List each intended study only once.")
    if not clean_studies:
        warnings.append("No intended studies are named yet; identify affected studies during review.")
    warnings.append("This is a draft review plan. It does not alter a product, pin a study, generate derivation logic, approve evidence, or run an analysis.")
    warnings.append("Dependency checks cover declared contract identifiers only; they do not prove that the proposed product can execute.")
    external_dependencies = sorted({dep for row in rows if row["variable_id"] in retained_set
                                    for dep in row.get("depends_on", [])
                                    if dep not in known_set and dep != "none"})
    if external_dependencies:
        warnings.append("Dependencies outside this contract require data-expert review: " + ", ".join(external_dependencies))
    checklist = [
        "Scientific owner reviews the purpose, retained definitions, removals, and proposed additions.",
        "Review all affected study pins; keep existing studies on their current version until their owners accept a revision.",
        "Check the baseline fingerprint against the current product before implementing this plan.",
    ]
    if added:
        checklist.append("Map each added definition to specification rows, dependencies, source fields, executable configuration, and acceptance examples before implementation.")
    if removed:
        checklist.append("Review removed definitions and downstream dependencies, then create a new specification version with a before-and-after comparison.")
    if source_changed:
        checklist.extend([
            "Treat the source change as breaking; previous source evidence and approvals do not validate the proposed source.",
            "Verify the delivered live schema and review source mapping, coding systems, units, and dates.",
            "Recompute cohort attrition and compare eligibility, observation windows, and follow-up on the proposed source.",
            "Review nulls and missingness; distinguish unavailable fields, absent records, and negative findings.",
            "Validate outcome definitions, completeness, and censoring against the new delivery before approving its use.",
        ])
    return {"schema_version": 1, "draft_only": True, "valid": not errors,
            "pack": description.get("pack"), "name": description.get("name"),
            "is_reference": bool(description.get("is_reference")),
            "contract_sha256": description.get("contract_sha256"),
            "baseline_sha256": description.get("baseline_sha256"),
            "purpose": purpose, "studies": clean_studies, "classification": classification,
            "kept": kept, "removed": removed, "added": added,
            "dependency_conflicts": conflicts, "source_changed": source_changed,
            "external_dependencies": external_dependencies,
            "source_tables": description.get("source_tables") or {},
            "source": {"current": current, "proposed": proposed},
            "review_checklist": checklist, "errors": list(dict.fromkeys(errors)),
            "warnings": list(dict.fromkeys(warnings))}


# Saved files contain a proposal, not product configuration. They deliberately omit
# source approvals, row status, reviewer identities, signatures, and study pins.
MAX_DRAFT_BYTES = 4 * 1024 * 1024
_INPUT_FIELDS = {"retained", "additions", "purpose", "studies", "target_source", "target_modality"}
_ARTIFACTS = ("plan.json", "DEFINITIONS.json", "DRAFT_SPECIFICATION.md")
OWNER_DIRECTORY_CHARS = 12
STORAGE_PATH_HELP = ("The draft folder path is too long for this Windows workflow. Move the checkout to a shorter folder, "
                     "such as C:\\rwd, then retry. No product files were changed.")


def _check_storage_paths(paths):
    """Refuse unreadable final artifacts before creating any private draft files."""
    if os.name != "nt":
        return
    def units(value):
        return len(str(value).encode("utf-16-le")) // 2
    for path in paths:
        # Retain room for the terminator and the legacy directory-creation limit.
        if units(path) >= 260 or units(path.parent) >= 248 or any(units(part) > 255 for part in path.parts):
            raise _DraftError(STORAGE_PATH_HELP)


def _storage_message(error, fallback):
    """Explain Windows storage failures without exposing the private absolute path."""
    filename = str(getattr(error, "filename", "") or getattr(error, "filename2", "") or "")
    if isinstance(error, OSError) and (error.errno == errno.ENAMETOOLONG or getattr(error, "winerror", None) == 206
            or (os.name == "nt" and len(filename) >= 240)):
        return STORAGE_PATH_HELP
    return fallback


def _failure(message):
    return {"ok": False, "changed": False, "errors": [str(message)], "drafts": []}


def _store(root, pack, actor_id, allowed_packs):
    base, path, name = _pack_path(root, pack, allowed_packs)
    if not isinstance(actor_id, str) or not actor_id.strip() or len(actor_id) > 300 or any(ord(c) < 32 for c in actor_id):
        raise _DraftError("An identified editing session is required to open saved drafts.")
    owner = hashlib.sha256(actor_id.strip().encode("utf-8")).hexdigest()
    parent = path / ".portal-drafts" / "revisions"
    legacy = parent / owner
    # Keep existing draft histories in their original location. New actor folders
    # use shorter names; the full digest still verifies every saved envelope.
    directory = legacy if legacy.exists() else parent / owner[:OWNER_DIRECTORY_CHARS]
    if directory.resolve() != directory:
        raise _DraftError("The draft location redirects to another location.")
    return base, name, owner, directory


def _draft_dir(directory, draft_id):
    if not isinstance(draft_id, str) or not re.fullmatch(r"[0-9a-f]{32}", draft_id):
        raise _DraftError("Choose a saved draft from the current product.")
    path = directory / draft_id
    if path.resolve() != path:
        raise _DraftError("The saved draft redirects to another location.")
    return path


def _versions(path):
    if not path.exists():
        return []
    if not path.is_dir():
        raise _DraftError("The saved draft location is not a folder.")
    versions = []
    for item in path.iterdir():
        if re.fullmatch(r"v\d{6}", item.name):
            if item.resolve() != item or not item.is_dir():
                raise _DraftError("A saved version is unavailable or redirects to another location.")
            versions.append(int(item.name[1:]))
    return sorted(versions)


def _json_read(path):
    if path.resolve() != path or not path.is_file():
        raise _DraftError("A saved draft file is missing or redirects to another location.")
    with path.open("rb") as handle:
        data = handle.read(MAX_DRAFT_BYTES + 1)
    if len(data) > MAX_DRAFT_BYTES:
        raise _DraftError("This saved draft exceeds the supported size.")
    return json.loads(data.decode("utf-8"))


def _read_version(directory, name, owner, draft_id, version=None):
    path = _draft_dir(directory, draft_id)
    versions = _versions(path)
    if not versions:
        raise _DraftError("This draft has no saved versions in your current product.")
    version = versions[-1] if version is None else version
    if type(version) is not int or version not in versions:
        raise _DraftError("The requested saved version is unavailable.")
    folder = path / f"v{version:06d}"
    envelope = _json_read(folder / "plan.json")
    if not isinstance(envelope, dict):
        raise _DraftError("The saved draft is malformed; it cannot be resumed.")
    checksum = envelope.get("payload_sha256")
    if (envelope.get("schema_version") != 1 or envelope.get("draft_only") is not True
            or envelope.get("pack") != name or envelope.get("owner") != owner
            or envelope.get("draft_id") != draft_id or envelope.get("version") != version
            or checksum != _hash({k: v for k, v in envelope.items() if k != "payload_sha256"})):
        raise _DraftError("The saved draft identity or contents do not match this version. Recreate it from the current product.")
    _inputs(envelope.get("inputs"))
    if not isinstance(envelope.get("summary"), dict) or not isinstance(envelope.get("baseline"), dict):
        raise _DraftError("The saved draft is incomplete; it cannot be resumed.")
    # All materialized files belong to this immutable snapshot, even when only the
    # plan is opened. A missing/changed specification is never presented as intact.
    for filename, expected in (envelope.get("artifacts") or {}).items():
        if filename not in _ARTIFACTS[1:]:
            raise _DraftError("The saved draft lists an unsupported artifact.")
        artifact = folder / filename
        if artifact.resolve() != artifact or not artifact.is_file() or artifact.stat().st_size > MAX_DRAFT_BYTES:
            raise _DraftError("A materialized draft definition file is unavailable.")
        if hashlib.sha256(artifact.read_bytes()).hexdigest() != expected:
            raise _DraftError("A materialized draft definition file changed after saving. Recreate this draft.")
    if set(envelope.get("artifacts") or {}) != set(_ARTIFACTS[1:]):
        raise _DraftError("The saved draft has no complete definition snapshot.")
    return envelope, folder, versions[-1]


def _inputs(value):
    if not isinstance(value, dict) or set(value) != _INPUT_FIELDS:
        raise _DraftError("The draft must contain purpose, studies, selections, additions, source and modality only.")
    for field, limit in (("purpose", 20000), ("target_source", 1000), ("target_modality", 30)):
        if not isinstance(value[field], str) or len(value[field]) > limit or "\x00" in value[field]:
            raise _DraftError(f"The draft {field} is missing or too long.")
    for field in ("retained", "studies"):
        if not isinstance(value[field], list) or len(value[field]) > 10000 or any(
                not isinstance(v, str) or len(v) > 1000 or "\x00" in v for v in value[field]):
            raise _DraftError(f"The draft {field} must be a list of text values.")
    additions = value["additions"]
    if not isinstance(additions, list) or len(additions) > 10000:
        raise _DraftError("Proposed definitions must be a list.")
    for item in additions:
        if not isinstance(item, dict) or set(item) != {"domain", "variable_id", "definition"}:
            raise _DraftError("Each proposed definition needs only section, identifier and scientific text.")
        for key, limit in (("domain", 1000), ("variable_id", 1000), ("definition", 100000)):
            if not isinstance(item[key], str) or len(item[key]) > limit or "\x00" in item[key]:
                raise _DraftError("A proposed definition is malformed or too long.")
    result = json.loads(json.dumps(value, ensure_ascii=False))
    if len(json.dumps(result, ensure_ascii=False).encode("utf-8")) > MAX_DRAFT_BYTES // 3:
        raise _DraftError("The proposed draft is too large. Split it into smaller revisions.")
    return result


def _projection(description, plan):
    kept = set(plan["kept"])
    result = [{"variable_id": row["variable_id"], "domain": row["domain"],
               "definition": row["definition"], "depends_on": list(row.get("depends_on") or []),
               "dependencies_declared": bool(row.get("dependencies_declared")), "origin": "retained"}
              for row in description["rows"] if row["variable_id"] in kept]
    result.extend({**item, "depends_on": [], "dependencies_declared": False, "origin": "proposed"}
                  for item in plan["added"])
    return {"schema_version": 1, "draft_only": True, "executable": False,
            "approval_carryover": False, "baseline_sha256": description["baseline_sha256"],
            "source": plan["source"]["proposed"], "studies": plan["studies"], "variables": result}


def _literal(text):
    text = str(text)
    fence = "`" * max(3, max((len(v) for v in re.findall(r"`+", text)), default=0) + 1)
    return fence + "text\n" + text + "\n" + fence + "\n"


def _specification(plan, definitions):
    lines = ["# Draft product specification", "",
             "Saved proposal only. No scientific review, approval, source validation or executable mapping is carried over.",
             "Exact scientific text is also available in DEFINITIONS.json. Missing dependencies on proposed definitions remain unresolved.",
             "", "## Purpose", _literal(plan["purpose"]), "## Intended studies", _literal("\n".join(plan["studies"])),
             "## Proposed source", _literal(json.dumps(plan["source"]["proposed"], ensure_ascii=False)),
             "## Selected definitions"]
    for index, row in enumerate(definitions["variables"], 1):
        lines.extend([f"### Definition {index}", "Identifier / section / origin:",
                      _literal(f"{row['variable_id']} / {row['domain']} / {row['origin']}"),
                      "Scientific definition:", _literal(row["definition"]),
                      "Declared dependencies:", _literal(", ".join(row["depends_on"]) if row["dependencies_declared"] else "Not established")])
    lines.extend(["## Removed identifiers", _literal("\n".join(plan["removed"]) or "None"),
                  "## Review before implementation", _literal("\n".join(plan["review_checklist"]))])
    return "\n".join(lines)


def list_drafts(root, pack, *, actor_id, allowed_packs=None):
    """List this actor's immutable versions in this pack; never read another scope."""
    try:
        _base, name, owner, directory = _store(root, pack, actor_id, allowed_packs)
        drafts, errors = [], []
        if directory.exists():
            for folder in directory.iterdir():
                if not re.fullmatch(r"[0-9a-f]{32}", folder.name):
                    continue
                try:
                    path = _draft_dir(directory, folder.name)
                    for version in _versions(path):
                        saved, _folder, latest = _read_version(directory, name, owner, folder.name, version)
                        drafts.append({"draft_id": folder.name, "version": version, "latest_version": latest,
                                       "created_at": saved["created_at"], "purpose": saved["inputs"]["purpose"],
                                       "summary": saved["summary"]})
                except (OSError, ValueError, TypeError, KeyError, UnicodeError, RecursionError):
                    errors.append("A saved draft could not be read safely. Its files have been left unchanged.")
        return {"ok": True, "drafts": sorted(drafts, key=lambda d: (d["created_at"], d["version"]), reverse=True),
                "errors": list(dict.fromkeys(errors))}
    except (OSError, ValueError, TypeError, UnicodeError, RecursionError) as exc:
        return _failure(str(exc) if isinstance(exc, _DraftError) else _storage_message(exc, "Saved drafts could not be listed safely."))


def load_draft(root, pack, *, actor_id, draft_id, version=None, allowed_packs=None):
    """Read a saved version and report changed baseline; loading grants no approval."""
    try:
        base, name, owner, directory = _store(root, pack, actor_id, allowed_packs)
        saved, folder, latest = _read_version(directory, name, owner, draft_id, version)
        current = describe(base, name)
        return {"ok": True, **saved, "latest_version": latest, "path": folder.relative_to(base).as_posix(),
                "stale": bool(current["errors"]) or saved["baseline"]["baseline_sha256"] != current["baseline_sha256"],
                "errors": current["errors"]}
    except (OSError, ValueError, TypeError, KeyError, UnicodeError, RecursionError) as exc:
        return _failure(str(exc) if isinstance(exc, _DraftError) else _storage_message(exc, "The saved draft could not be opened safely."))


def save_draft(root, pack, inputs, *, actor_id, local_demo, can_write, expected_baseline,
               draft_id=None, expected_version=None, allowed_packs=None):
    """Save a new immutable draft version, rebuilding the plan from current files.

    The baseline digest is mandatory. Updating a draft also requires its latest
    version, so concurrent editors cannot silently replace each other's work.
    No original product file, registry entry, approval or study pin is changed.
    """
    if local_demo is not True or can_write is not True:
        return _failure("Saving draft revisions requires an authorized local editing session.")
    lock = stage = None
    try:
        base, name, owner, directory = _store(root, pack, actor_id, allowed_packs)
        clean = _inputs(inputs)
        if not isinstance(expected_baseline, str) or not re.fullmatch(r"[0-9a-f]{64}", expected_baseline):
            raise _DraftError("Reload and review the starting product before saving this draft.")
        current = describe(base, name)
        if current["errors"]:
            raise _DraftError("The starting product cannot be read safely. Repair its reported issues before saving.")
        if current["baseline_sha256"] != expected_baseline:
            raise _DraftError("The starting product changed. Review its current definitions before saving.")
        plan = build_plan(current, **clean)
        if not plan["valid"]:
            return {**_failure("Resolve the plan's issues before saving a revision."), "errors": plan["errors"], "plan": plan}
        new = draft_id is None
        if new and expected_version is not None:
            raise _DraftError("A new draft cannot replace an existing version.")
        draft_id = uuid.uuid4().hex if new else draft_id
        path = _draft_dir(directory, draft_id)
        _check_storage_paths([path / folder / filename for folder in ("v000001", ".saving-00000000")
                              for filename in _ARTIFACTS])
        if not new and not path.is_dir():
            raise _DraftError("The draft to update is no longer available in this product.")
        path.mkdir(parents=True, exist_ok=True)
        # Recheck canonical ownership after creating parent directories.
        _store(base, name, actor_id, allowed_packs)
        _draft_dir(directory, draft_id)
        lock_path = path / ".save.lock"
        try:
            handle = os.open(lock_path, os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o600)
        except FileExistsError as exc:
            raise _DraftError("Another save is in progress. Reopen the latest version and try again.") from exc
        os.close(handle)
        lock = lock_path
        versions = _versions(path)
        latest = versions[-1] if versions else 0
        if not new and (type(expected_version) is not int or expected_version != latest):
            raise _DraftError("A newer draft version exists. Reopen it before saving your next version.")
        if latest:
            previous, folder, _latest = _read_version(directory, name, owner, draft_id, latest)
            if previous["inputs"] == clean and previous["baseline"]["baseline_sha256"] == expected_baseline:
                return {"ok": True, "changed": False, "draft_id": draft_id, "version": latest,
                        "path": folder.relative_to(base).as_posix(), "plan": previous["plan"],
                        "summary": previous["summary"], "errors": []}
        if latest >= 999999:
            raise _DraftError("This draft has reached its version limit; start a new draft.")
        version = latest + 1
        definitions = _projection(current, plan)
        definition_bytes = json.dumps(definitions, indent=2, ensure_ascii=False).encode("utf-8")
        specification_bytes = _specification(plan, definitions).encode("utf-8")
        baseline = {k: current[k] for k in ("pack", "name", "is_reference", "contract_sha256", "baseline_sha256", "rows", "source", "source_tables")}
        summary = {"before_count": len(current["rows"]), "after_count": len(definitions["variables"]),
                   "kept_count": len(plan["kept"]), "removed_count": len(plan["removed"]), "added_count": len(plan["added"]),
                   "source": plan["source"], "studies": plan["studies"], "classification": plan["classification"]}
        saved = {"schema_version": 1, "draft_only": True, "executable": False, "approval_carryover": False,
                 "pack": name, "owner": owner, "draft_id": draft_id, "version": version,
                 "created_at": datetime.now(timezone.utc).isoformat(), "inputs": clean, "baseline": baseline,
                 "plan": plan, "summary": summary, "artifacts": {
                     "DEFINITIONS.json": hashlib.sha256(definition_bytes).hexdigest(),
                     "DRAFT_SPECIFICATION.md": hashlib.sha256(specification_bytes).hexdigest()}}
        saved["payload_sha256"] = _hash(saved)
        payload = json.dumps(saved, indent=2, ensure_ascii=False).encode("utf-8")
        if any(len(b) > MAX_DRAFT_BYTES for b in (payload, definition_bytes, specification_bytes)):
            raise _DraftError("This draft snapshot is too large. Split it into smaller revisions.")
        stage = Path(tempfile.mkdtemp(prefix=".saving-", dir=path))
        for filename, data in zip(_ARTIFACTS, (payload, definition_bytes, specification_bytes)):
            with (stage / filename).open("xb") as stream:
                stream.write(data)
                stream.flush()
                os.fsync(stream.fileno())
        fresh = describe(base, name)
        if fresh["errors"] or fresh["baseline_sha256"] != expected_baseline:
            raise _DraftError("The starting product changed during the save. Review it and try again.")
        destination = path / f"v{version:06d}"
        if destination.exists() or destination.resolve() != destination or path.resolve() != path:
            raise _DraftError("The draft destination changed during the save. Reopen the product.")
        os.rename(stage, destination)
        stage = None
        return {"ok": True, "changed": True, "draft_id": draft_id, "version": version,
                "path": destination.relative_to(base).as_posix(), "plan": plan, "summary": summary, "errors": []}
    except (OSError, ValueError, TypeError, KeyError, UnicodeError, RecursionError) as exc:
        return _failure(str(exc) if isinstance(exc, _DraftError) else _storage_message(exc, "The draft could not be saved safely. No product files were changed."))
    finally:
        # Only this call's random staging directory and exclusively acquired lock
        # are eligible for cleanup; original products and saved versions are never removed.
        try:
            if stage is not None and stage.exists() and stage.resolve() == stage and stage.parent == path:
                stage.relative_to(base)
                shutil.rmtree(stage)
            if lock is not None and lock.resolve() == lock:
                lock.unlink(missing_ok=True)
        except OSError:
            # An unpublished random staging folder is not a saved revision. Do not
            # replace the original result with a cleanup traceback on a locked disk.
            pass
