"""Read the product's semantic knowledge sources and inspect an exact graph."""
from __future__ import annotations

import json
from pathlib import Path

import streamlit as st

import semantic_knowledge_workspace as backend


PREFIX = "semantic_knowledge_"


def clear():
    for key in list(st.session_state):
        if str(key).startswith(PREFIX):
            st.session_state.pop(key, None)


def _text(value):
    if value is None:
        return ""
    if isinstance(value, (dict, list, tuple)):
        return json.dumps(value, ensure_ascii=False, default=str)
    return str(value)


def _errors(result):
    for message in result.get("errors") or []:
        st.error(str(message))
    return not result.get("ok")


def _source_details(root, pack, actor_id, allowed_packs, current):
    sources = current.get("sources") or []
    if not sources:
        st.info("No semantic knowledge sources were returned for this product.")
        return
    by_id = {source["id"]: source for source in sources}
    if st.session_state.get(PREFIX + "source") not in by_id:
        st.session_state[PREFIX + "source"] = sources[0]["id"]
    source_id = st.selectbox("Knowledge source to inspect", list(by_id), key=PREFIX + "source",
        format_func=lambda key: _text(by_id[key].get("label") or key))
    source = by_id[source_id]
    cached = st.session_state.get(PREFIX + "source_details")
    if cached and (cached.get("input_digest") != current["input_digest"] or cached.get("source", {}).get("id") != source_id):
        st.session_state.pop(PREFIX + "source_details", None)
        cached = None
    st.write(source.get("summary") or source.get("purpose") or source.get("label") or source_id)
    st.caption("Source: " + _text(source.get("path")) + " · " + _text(source.get("state") or source.get("status")))
    if st.button("Open source details", key=PREFIX + "open_source"):
        opened = backend.source(root, pack, actor_id, source_id, expected_digest=current["input_digest"], allowed_packs=allowed_packs)
        if opened.get("ok") and (opened.get("input_digest") != current["input_digest"] or opened.get("source", {}).get("id") != source_id):
            opened = {"ok": False, "errors": ["The source changed while opening. Open its current details again."]}
        if _errors(opened):
            st.session_state.pop(PREFIX + "source_details", None)
            cached = None
        else:
            st.session_state[PREFIX + "source_details"] = opened
            cached = opened
    if cached:
        source = cached["source"]
        with st.expander("All recorded source details", expanded=True):
            st.code(_text(source.get("content")), language=source.get("format") or "text")
        with st.expander("Source metadata"):
            st.json({key: value for key, value in source.items() if key != "content"})
        st.download_button("Download this knowledge source", _text(source.get("content")),
            file_name=Path(source.get("path") or "knowledge-source.txt").name, mime="text/plain",
            key=PREFIX + "download_source")
    if source.get("findings"):
        for finding in source["findings"]:
            st.warning(_text(finding))


def _validation(result, *, stale=False):
    if stale:
        if result:
            st.warning("SHACL status: stale. The knowledge inputs changed after this check. Load the current graph and validate it again.")
        else:
            st.info("SHACL status: not run for current inputs. Load the current graph before validating.")
        return
    if not result:
        st.info("SHACL status: not run for this graph.")
        return
    state = result.get("state")
    if state == "conforms":
        st.success("SHACL status: conforms for this exact graph and shapes.")
    elif state in {"unchecked", "not_run"}:
        st.info("SHACL status: not run for this graph.")
    else:
        st.warning("SHACL status: findings need review.")
    st.caption("SHACL checks structure and declared constraints. It does not approve scientific meaning.")
    if result.get("why") or result.get("report"):
        with st.expander("Full SHACL findings", expanded=state not in {"conforms", "unchecked", "not_run"}):
            st.text(_text(result.get("why") or result.get("report")))


def _node_details(snapshot):
    nodes = snapshot.get("nodes") or []
    edges = snapshot.get("edges") or []
    st.caption(f"{len(nodes)} graph nodes · {len(edges)} relationships")
    if not nodes:
        st.info("This graph contains no nodes. Review the source status and withheld records below.")
    else:
        by_id = {node["id"]: node for node in nodes}
        if st.session_state.get(PREFIX + "node") not in by_id:
            st.session_state[PREFIX + "node"] = nodes[0]["id"]
        selected = st.selectbox("Graph record to inspect", list(by_id), key=PREFIX + "node",
            format_func=lambda key: _text(by_id[key].get("label") or key))
        node = by_id[selected]
        st.caption("Identifier: " + selected)
        st.write("Type: " + _text(node.get("type")))
        properties = node.get("properties") or {}
        if isinstance(properties, dict) and properties:
            st.dataframe([{"Property": key, "Recorded value": _text(value)} for key, value in properties.items()],
                hide_index=True, width="stretch")
        elif properties:
            st.json(properties)
        connected = [edge for edge in edges if selected in (edge.get("source"), edge.get("target"))]
        if connected:
            st.write("**All relationships for this record**")
            st.dataframe(connected, hide_index=True, width="stretch")
            with st.expander("View these graph relationships"):
                shown = connected[:15]
                identifiers = list(dict.fromkeys(identifier for edge in shown for identifier in (edge["source"], edge["target"])))
                aliases = {identifier: f"n{index}" for index, identifier in enumerate(identifiers)}
                lines = ["digraph knowledge { rankdir=LR; node [shape=box];"]
                for identifier in identifiers:
                    label = _text(by_id.get(identifier, {}).get("label") or identifier)
                    lines.append(aliases[identifier] + " [label=" + json.dumps(label) + "];")
                for edge in shown:
                    lines.append(aliases[edge["source"]] + " -> " + aliases[edge["target"]]
                                 + " [label=" + json.dumps(_text(edge.get("predicate"))) + "];")
                st.graphviz_chart("\n".join([*lines, "}"]))
                st.caption(f"Showing {len(shown)} of {len(connected)} recorded relationships. The table includes every relationship for this record.")
        provenance = node.get("citations") or node.get("provenance")
        if provenance:
            with st.expander("Source citations and provenance", expanded=True):
                st.json(provenance)
        if node.get("statements"):
            with st.expander("All RDF statements for this record"):
                st.json(node["statements"])
        if node.get("graph_memberships"):
            st.caption("Named graphs: " + _text(node["graph_memberships"]))
        with st.expander("Exact graph record"):
            st.json(node.get("raw") or node)
        with st.expander("All graph nodes and relationships"):
            st.dataframe([{"Identifier": row["id"], "Label": _text(row.get("label")),
                           "Type": _text(row.get("type"))} for row in nodes], hide_index=True, width="stretch")
            if edges:
                st.dataframe(edges, hide_index=True, width="stretch")
    if snapshot.get("report"):
        if snapshot["report"].get("note"):
            st.info(_text(snapshot["report"]["note"]))
        if snapshot["report"].get("scope_note"):
            st.caption(_text(snapshot["report"]["scope_note"]))
        if snapshot["report"].get("withheld"):
            st.write("**Records withheld from this graph**")
            st.table([{"Recorded state": name, "Count": value} for name, value in snapshot["report"]["withheld"].items()])
        for warning in snapshot["report"].get("binding_withheld") or []:
            st.warning(_text(warning))
        with st.expander("Graph scope and withheld records", expanded=bool(snapshot["report"].get("withheld") or snapshot["report"].get("binding_withheld"))):
            st.json(snapshot["report"])
    shape_nodes = snapshot.get("shape_nodes") or []
    if shape_nodes:
        with st.expander(f"SHACL nodes ({len(shape_nodes)}) · shapes and embedded constraints"):
            shape_ids = list(range(len(shape_nodes)))
            if st.session_state.get(PREFIX + "shape") not in shape_ids:
                st.session_state[PREFIX + "shape"] = shape_ids[0]
            selected_shape = st.selectbox("SHACL shape or constraint to inspect", shape_ids, key=PREFIX + "shape",
                format_func=lambda index: _text(shape_nodes[index].get("label") or shape_nodes[index].get("id") or index))
            st.json(shape_nodes[selected_shape])
    with st.expander("Exact graph and SHACL shapes"):
        st.caption("Preview identifier namespace: " + _text(snapshot.get("namespace")))
        st.code(_text(snapshot.get("graph")), language="json")
        st.code(_text(snapshot.get("shapes")), language="json")
        st.caption("Graph SHA256: " + _text(snapshot.get("graph_sha256")))
        st.caption("Shapes SHA256: " + _text(snapshot.get("shapes_sha256")))
    st.download_button("Download exact graph JSON-LD", _text(snapshot.get("graph")), file_name="knowledge-graph.jsonld",
        mime="application/ld+json", key=PREFIX + "download_graph")
    st.download_button("Download exact SHACL shapes", _text(snapshot.get("shapes")), file_name="knowledge-shapes.jsonld",
        mime="application/ld+json", key=PREFIX + "download_shapes")


def render(root, pack, actor_id, *, allowed_packs, can_view=True):
    """Browse metadata immediately; build and validate only on explicit clicks."""
    if not can_view or pack not in allowed_packs:
        clear()
        st.info("You need access to this product to inspect its knowledge sources.")
        return None
    owner = (str(Path(root).resolve()), pack, actor_id, tuple(sorted(allowed_packs)))
    if st.session_state.get(PREFIX + "owner") != owner:
        clear()
        st.session_state[PREFIX + "owner"] = owner
    current = backend.describe(root, pack, actor_id, allowed_packs=allowed_packs)
    if _errors(current):
        st.session_state.pop(PREFIX + "snapshot", None)
        st.session_state.pop(PREFIX + "validation", None)
        st.session_state.pop(PREFIX + "source_details", None)
        return None
    st.write("Read where the product's concepts, definitions, bindings and validation rules come from, then inspect their graph.")
    if current.get("notice"):
        st.caption(str(current["notice"]))
    if current.get("capabilities"):
        st.dataframe(current["capabilities"], hide_index=True, width="stretch")
    if current.get("status"):
        status_rows = [{"Product knowledge status": name.replace("_", " "), "Current value": _text(value)}
                       for name, value in current["status"].items() if name not in {"validation_state", "warnings"}]
        if status_rows:
            st.table(status_rows)
        for warning in current["status"].get("warnings") or []:
            st.warning(_text(warning))
    _source_details(root, pack, actor_id, allowed_packs, current)
    if current.get("bindings"):
        with st.expander("Product concept bindings", expanded=True):
            st.dataframe(current["bindings"], hide_index=True, width="stretch")
    else:
        st.info("No product concept bindings are recorded in this view.")
    if st.button("Review product concept bindings", key=PREFIX + "bindings"):
        return {"route": "clinical_standards", "params": {}}
    for finding in current.get("findings") or []:
        st.warning(_text(finding))
    st.write("**Inspect the product graph**")
    digest = current["input_digest"]
    snapshot = st.session_state.get(PREFIX + "snapshot")
    stale = bool(snapshot and snapshot.get("input_digest") != digest)
    validation = st.session_state.get(PREFIX + "validation")
    if st.button("Load current knowledge graph", key=PREFIX + "browse"):
        with st.spinner("Building the current knowledge graph…"):
            loaded = backend.browse(root, pack, actor_id, expected_digest=digest, allowed_packs=allowed_packs)
        st.session_state.pop(PREFIX + "validation", None)
        st.session_state.pop(PREFIX + "node", None)
        validation = None
        if loaded.get("ok") and loaded.get("input_digest") != digest:
            loaded = {"ok": False, "errors": ["The knowledge changed while loading. Load the current graph again."]}
        if _errors(loaded):
            st.session_state.pop(PREFIX + "snapshot", None)
            snapshot, stale = None, False
        else:
            snapshot, stale = loaded, False
            st.session_state[PREFIX + "snapshot"] = loaded
    if stale:
        st.warning("Graph status: stale. The source metadata changed. Load the current graph to inspect the updated knowledge.")
    elif snapshot:
        st.caption("Graph status: current input snapshot.")
    else:
        st.caption("Graph status: not loaded. Loading builds a read-only view of the current knowledge.")
    if snapshot:
        if snapshot.get("preview_only"):
            st.caption("This graph uses local preview identifiers. Use the export workflow to prepare a version for an external graph consumer.")
        if st.button("Validate this graph with SHACL", key=PREFIX + "validate", disabled=stale):
            with st.spinner("Validating the exact graph and SHACL shapes…"):
                checked = backend.validate(root, pack, actor_id, expected_digest=digest,
                    graph_sha256=snapshot["graph_sha256"], allowed_packs=allowed_packs)
            if checked.get("ok") and (checked.get("input_digest") != digest
                    or checked.get("graph_sha256") != snapshot["graph_sha256"]
                    or checked.get("shapes_sha256") != snapshot["shapes_sha256"]):
                checked = {"ok": False, "errors": ["The graph changed during validation. Load the current graph and validate again."]}
            if _errors(checked):
                st.session_state.pop(PREFIX + "validation", None)
                validation = None
            else:
                validation = checked["validation"]
                st.session_state[PREFIX + "validation"] = validation
        _validation(validation, stale=stale)
        if stale:
            st.caption("Reload to inspect or download current graph contents.")
        else:
            _node_details(snapshot)
    else:
        _validation(None)
    if st.button("Open the semantic export workflow", key=PREFIX + "export"):
        return {"route": "semantic_export", "params": {}}
    return None
