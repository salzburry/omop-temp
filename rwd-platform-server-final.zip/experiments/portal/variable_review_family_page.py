"""Dropdown editor for an explicitly selected treatment-line definition family."""
from __future__ import annotations

from copy import deepcopy
import streamlit as st

import variable_review_controls as controls
import variable_review_family as family

RELATIONSHIPS = {
    "Diagnosis recorded on the same treatment-line row": "Use the diagnosis recorded on the selected treatment-line row",
    "Diagnosis linked by patient and treatment-line identifier": "Link by patient identifier and the selected treatment-line identifier",
    "Diagnosis matched by patient and date": "Match the patient's diagnosis records to the selected treatment line by date",
}
WINDOWS = {
    "Same treatment-line record": "Use the diagnosis on the selected treatment-line record; no separate date window",
    "On or before the line start date": "On or before the selected line start date, inclusive",
    "On the line start date": "On the selected line start date",
    "Between line start and delivered end": "Between the selected line start and delivered end dates, inclusive",
}
TIES = {
    "Require exactly one diagnosis; flag multiple matches": "Require exactly one diagnosis and flag multiple matches for review",
    "Closest diagnosis date; flag equal-distance ties": "Use the diagnosis closest to the selected line start date and flag equal-distance ties for review",
    "Latest eligible diagnosis; flag ties on that date": "Use the latest eligible diagnosis and flag multiple diagnoses on that date for review",
}


def _enum(label, current, choices, *, key, permitted):
    values = list(choices.values())
    return st.selectbox(label, values, index=values.index(current) if current in values else None,
                        format_func=lambda item: next(name for name, value in choices.items() if item == value),
                        key=key, disabled=not permitted, placeholder="Choose an answer") or ""


def render(row, values, *, key, permitted):
    """Return proposed updates only; the caller owns explicit saving and authorization."""
    saved = family.selection(row)
    selected = deepcopy(saved) or {"name": family.NAME, "line_number": None, "attribute": "", "numbering": ""}
    st.write("**Treatment-line definition**")
    st.caption("Reuse the same treatment-line rule by choosing its line number and the attribute to return.")
    suggestion = family.suggestions(row)
    if suggestion and not saved:
        label = next((label for label, value in family.ATTRIBUTES.items() if value == suggestion["attribute"]), "date type not specified")
        st.caption(f"Name suggests line {suggestion['line_number']} · {label}. Confirm your choices below.")
    current = selected.get("line_number")
    offered = list(range(1, 11))
    if type(current) is int and current not in offered:
        offered.append(current)
    chosen = st.selectbox("Treatment line number", [*offered, "Another line number"],
                          index=offered.index(current) if current in offered else None,
                          key=key + "_line", disabled=not permitted, placeholder="Choose an answer")
    if chosen == "Another line number":
        chosen = int(st.number_input("Other treatment line number", min_value=1, max_value=family.MAX_LINE_NUMBER, value=current or 1,
                                     step=1, key=key + "_line_other", disabled=not permitted))
    selected["line_number"] = chosen
    selected["attribute"] = _enum("Treatment-line attribute", selected.get("attribute"), family.ATTRIBUTES,
                                   key=key + "_attribute", permitted=permitted)
    selected["numbering"] = _enum("How to count treatment lines", selected.get("numbering"), family.NUMBERING,
                                   key=key + "_numbering", permitted=permitted)
    st.caption("Delivered numbering keeps the source's line labels. Renumbering starts at 1 after the product's eligible-line filters and orders the remaining lines by date.")
    if selected["attribute"] == "diagnosis":
        for field, label, options in (
            ("diagnosis_relationship", "How diagnosis is linked to the line", RELATIONSHIPS),
            ("diagnosis_window", "Eligible diagnosis window", WINDOWS),
            ("diagnosis_tie_break", "When several diagnoses match", TIES),
        ):
            selected[field] = controls.render_choice(label, saved.get(field, ""), options,
                key=key + "_" + field, disabled=not permitted, multiline=True)
    if selected["attribute"] == "custom":
        selected["custom_attribute"] = controls.render_choice("Attribute to return", saved.get("custom_attribute", ""), {},
            key=key + "_custom_attribute", disabled=not permitted, multiline=True)
    updates = family.scientific_updates(selected)
    if selected["attribute"] == "custom":
        updates["output.type"] = controls.render_choice("Data type", (values.get("output") or {}).get("type") or "",
            controls.choices_for("output.type"), key=key + "_custom_type", disabled=not permitted)
    if selected.get("attribute") in {"regimen", "start_date", "delivered_end_date", "last_activity_date"}:
        st.caption("The engine supports this attribute. Saving prepares its scientific definition; before execution, treatment configuration must match the selected line and numbering rule, and the output name must be mapped.")
    else:
        st.caption(family.capability(selected))
    if family.source_roles({"family": selected}):
        st.caption("In Sources, map the common treatment-line columns once: patient, delivered line number, start date, delivered end date and regimen. Reuse that mapping for the related line variables.")
    if updates.get("output.type"):
        st.caption("Data type: " + controls.TYPE_LABELS.get(updates["output.type"], updates["output.type"]))
    if updates.get("derivation"):
        st.write("**Proposed definition**")
        st.write(updates["derivation"])
    else:
        st.caption("Choose the remaining answers to prepare the definition. Unfinished choices can be saved as a draft.")
    return updates
