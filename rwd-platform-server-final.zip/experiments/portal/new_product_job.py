"""Keep the explicitly requested product write independent of Streamlit reruns."""
from __future__ import annotations

from pathlib import Path
import re
import subprocess
import sys
import uuid

import portal_jobs as jobs
import portal_runtime

ACTION = "new_product_apply"
JOB_KEY = "new-product"
OPTIONS = {
    "--next-cut-of", "--change-class", "--change-note", "--code", "--name", "--vendor",
    "--tumor-class", "--spec-version", "--family", "--broad", "--narrow", "--condition-class",
    "--modality", "--disease-terms", "--tumour-family", "--ai-classification", "--classified-by",
    "--classified-date", "--workbook", "--exclude-sheet", "--exclude-sheet-reason",
    "--sheet-domain", "--sheet-domain-reason",
}


def _arguments(argv, allowed_packs):
    # The saved request selects only the canonical product command. Neither a
    # different executable nor a checkout override can enter a worker journal.
    if (not isinstance(argv, (list, tuple)) or not argv or len(argv) > 1001 or
            any(not isinstance(part, str) for part in argv) or
            not re.fullmatch(r"[a-z][a-z0-9_]*", argv[0]) or len(argv) % 2 != 1):
        raise ValueError("Preview the current product inputs before requesting Write.")
    for option, value in zip(argv[1::2], argv[2::2]):
        if option not in OPTIONS or value.startswith("--"):
            raise ValueError("Use the reviewed product fields without command or checkout overrides.")
        if option == "--next-cut-of" and value not in (allowed_packs or []):
            raise ValueError("The previous product is outside your current access.")
    return list(argv)


def execute(root, actor_id, *, argv, request_id, launch_context=None, allowed_packs=None):
    argv = _arguments(argv, allowed_packs)
    if not isinstance(request_id, str) or not re.fullmatch(r"[a-f0-9]{32}", request_id):
        raise ValueError("Use the current explicitly requested product write.")
    portal_runtime.job_progress("Staging the reviewed product and running its validators. Clearing chat does not cancel this work.")
    command = [sys.executable, str(Path(root) / "platform/tools/new_product.py"),
               *argv, "--apply", "--root", str(Path(root).resolve())]
    result = portal_runtime.run(command, cwd=str(root), timeout_s=1800)
    return {"ok": result.returncode == 0, "returncode": result.returncode,
            "stdout": result.stdout or "", "stderr": result.stderr or ""}


def current(root, actor_id, *, allowed_packs=None):
    rows = jobs.recent(root, actor_id, action=ACTION, job_key=JOB_KEY, allowed_packs=allowed_packs)
    return rows[0] if rows else None


def context(root, actor_id, state, *, allowed_packs=None):
    """Bind completion to the form and saved brief reviewed when Write was clicked."""
    import conversation_intake
    import new_product_recovery
    scope, directory = conversation_intake._scope(root, "", actor_id, allowed_packs or [])
    brief = conversation_intake._read(directory, scope, actor_id)
    return {"form_digest": new_product_recovery._inputs(state),
            "brief_revision": (brief or {}).get("revision")}


def start(root, actor_id, argv, *, can_write=False, allowed_packs=None, launch_context=None):
    argv = _arguments(argv, allowed_packs)
    return jobs.start(root, actor_id, action=ACTION, job_key=JOB_KEY,
        arguments={"argv": argv, "request_id": uuid.uuid4().hex, "launch_context": launch_context},
        confirmed=True, can_write=can_write, allowed_packs=allowed_packs)


def result(row):
    saved = row.get("result") or {}
    if "returncode" in saved:
        return subprocess.CompletedProcess([], saved["returncode"], saved.get("stdout", ""), saved.get("stderr", ""))
    return subprocess.CompletedProcess([], 1, "", row["progress"] +
        " Check product progress before repeating Write; this attempt did not retain a complete tool result.")


def acknowledge(root, actor_id, row, *, allowed_packs=None):
    """Retain successful output without reopening the same product on every visit."""
    owned = jobs.read(root, actor_id, row["id"], allowed_packs=allowed_packs)
    if owned["status"] == "completed":
        jobs._update(jobs._path(root, actor_id, row["id"]), {"result_acknowledged": True},
                     only_status={"completed"})


def render_progress(root, actor_id, *, allowed_packs=None, can_write=False):
    import streamlit as st

    @st.fragment(run_every="2s")
    def progress():
        row = current(root, actor_id, allowed_packs=allowed_packs)
        if row is None:
            return
        if row["status"] in jobs.TERMINAL:
            st.rerun()
        st.caption(jobs.ACTIONS[ACTION] + " · " + row["status"])
        st.write(row["progress"])
        st.caption("You may leave this page or close Streamlit. Reopening New product restores this progress and its saved result.")
        if st.button("Refresh setup progress", key="np_job_refresh"):
            st.rerun()
        st.caption("Clearing the conversation keeps this setup running. Its result will appear here when it finishes.")

    progress()
