"""A scientist's revision workspace with immutable saved drafts and exact definitions."""
from __future__ import annotations

import json
import hashlib

import streamlit as st

import design_workspace as workspace
import configuration_proposal_page
import form_assistance as form_help


def _restore(prefix, saved, description):
    """Restore literal inputs before widgets are created; retain the saved baseline."""
    values = saved["inputs"]
    for field, value in (("purpose", values["purpose"]), ("studies", "\n".join(values["studies"])),
                         ("source", values["target_source"]), ("modality", values["target_modality"]),
                         ("additions", values["additions"]), ("baseline", saved["baseline"]["baseline_sha256"])):
        st.session_state[prefix + field] = value
    rows = description["rows"]
    st.session_state[prefix + "domains"] = sorted({row["domain"] for row in rows})
    st.session_state[prefix + "excluded"] = [row["variable_id"] for row in rows if row["variable_id"] not in values["retained"]]
    st.session_state[prefix + "loaded_unknown"] = [v for v in values["retained"] if v not in {r["variable_id"] for r in rows}]
    for field in ("add_domain", "add_variable", "add_definition"):
        st.session_state[prefix + field] = ""


def render(root, pack, *, actor_id="", local_demo=False, can_write=False, allowed_packs=None,
           show_intro=True, initial_draft=None, initial_version=None):
    if show_intro:
        st.title("Plan changes")
        st.write("Shape a reusable product for your studies. Keep or remove sections, propose a variable, "
             "and assess a different data source before requesting a revision.")
    st.caption("Save a draft revision to return to it later. Each saved version includes your selected definitions and "
               "a before-and-after brief. It does not approve the science or create executable source mappings.")
    try:
        workspace._pack_path(root, pack, allowed_packs)
    except ValueError as exc:
        st.error(str(exc))
        return
    description = workspace.describe(root, pack)
    for error in description["errors"]:
        st.error(error)
    if description["errors"]:
        return
    rows = description["rows"]
    draft_binding = (pack, description["baseline_sha256"])
    if not rows:
        st.info("This product has no contract variables yet. You can still propose new sections and their definitions below.")
    prefix = f"design_{pack}_"
    context = hashlib.sha256(json.dumps([str(root), pack, actor_id, local_demo, can_write,
                                        sorted(allowed_packs) if allowed_packs is not None else None]).encode()).hexdigest()
    context_key = "revision_active_context"
    same_context = st.session_state.get(context_key, context) == context
    st.session_state[context_key] = context
    metadata_key = "revision_saved_" + context
    if initial_draft and st.session_state.get("revision_incoming_" + context) != (initial_draft, initial_version):
        requested_version = initial_version
        try:
            requested_version = None if initial_version is None else int(initial_version)
        except (TypeError, ValueError):
            requested_version = 0  # the backend returns a scoped, readable refusal
        reopened = workspace.load_draft(root, pack, actor_id=actor_id, allowed_packs=allowed_packs,
                                       draft_id=initial_draft, version=requested_version)
        if reopened["ok"]:
            st.session_state.pop("configuration_import_" + context, None)
            _restore(f"design_{pack}_", reopened, description)
            st.session_state[metadata_key] = {"draft_id": initial_draft, "version": reopened["version"],
                "expected_version": reopened["latest_version"], "summary": reopened["summary"]}
        else:
            for error in reopened["errors"]:
                st.error(error)
        st.session_state["revision_incoming_" + context] = (initial_draft, initial_version)
    saved_metadata = st.session_state.get(metadata_key)
    notice_key = "revision_notice_" + context
    if st.session_state.get(notice_key):
        st.success(st.session_state.pop(notice_key))
    if actor_id:
        catalog = workspace.list_drafts(root, pack, actor_id=actor_id, allowed_packs=allowed_packs)
        for error in catalog["errors"]:
            st.warning(error)
        entries = catalog["drafts"]
        if entries:
            with st.expander("Your saved draft revisions"):
                labels = {f"{d['draft_id']}:{d['version']}": f"{d['purpose'][:90]} · version {d['version']} · {d['draft_id'][:8]}" for d in entries}
                picker_key = prefix + "saved_choice"
                if st.session_state.get(picker_key) not in labels:
                    st.session_state[picker_key] = next(iter(labels))
                choice = st.selectbox("Saved version", list(labels), key=picker_key, format_func=labels.get)
                if st.button("Open saved version", key=f"revision_open_{pack}",
                             help="Replace the current form with this saved version. Existing saved versions remain available.") and same_context:
                    identifier, version = choice.split(":")
                    reopened = workspace.load_draft(root, pack, actor_id=actor_id, allowed_packs=allowed_packs,
                                                     draft_id=identifier, version=int(version))
                    if not reopened["ok"]:
                        for error in reopened["errors"]:
                            st.error(error)
                    else:
                        st.session_state.pop("configuration_import_" + context, None)
                        _restore(prefix, reopened, description)
                        st.session_state[metadata_key] = {"draft_id": identifier, "version": int(version),
                                                         "expected_version": reopened["latest_version"], "summary": reopened["summary"]}
                        st.rerun()
        if saved_metadata:
            st.info(f"Continuing draft {saved_metadata['draft_id'][:8]}, version {saved_metadata['version']}. Saving keeps this version and creates the next one.")
            if st.button("Save the next change as a separate draft", key=f"revision_fork_{pack}") and same_context:
                st.session_state.pop(metadata_key, None)
                st.rerun()
    previous = st.session_state.get(prefix + "baseline")
    changed = previous is not None and previous != description["baseline_sha256"]
    if changed:
        st.warning("The source product changed since this plan began. Review its current definitions and your selections before saving or exporting.")
        if st.session_state.get(prefix + "loaded_unknown"):
            st.warning("Previously retained variables no longer present: " + ", ".join(st.session_state[prefix + "loaded_unknown"]))
        if st.button("Use the current definitions", key=f"revision_refresh_{pack}"):
            st.session_state[prefix + "baseline"] = description["baseline_sha256"]
            st.session_state.pop(prefix + "loaded_unknown", None)
            st.rerun()
    else:
        st.session_state[prefix + "baseline"] = description["baseline_sha256"]
    left, right = st.columns([3, 2])
    with left:
        purpose = form_help.field(st.text_area, "What should this product help you study?", key=prefix + "purpose", binding=draft_binding,
                               placeholder="Describe the population, index event, outcomes, and why a change is needed.")
    with right:
        studies_text = form_help.field(st.text_area, "Studies that may use it (one per line)", key=prefix + "studies", binding=draft_binding,
                                    placeholder="Treatment patterns study\nOutcomes study")
    if rows:
        st.subheader("1. Choose the sections to keep")
    domains = sorted({r["domain"] for r in rows})
    domain_key = prefix + "domains"
    if domain_key in st.session_state:
        st.session_state[domain_key] = [d for d in st.session_state[domain_key] if d in domains]
    else:
        st.session_state[domain_key] = domains
    selected = form_help.field(st.multiselect, "Included sections", domains, key=domain_key, binding=draft_binding) if rows else []
    candidates = [r["variable_id"] for r in rows if r["domain"] in selected]
    excluded_key = prefix + "excluded"
    all_variables = [r["variable_id"] for r in rows]
    if excluded_key in st.session_state:
        st.session_state[excluded_key] = [v for v in st.session_state[excluded_key] if v in all_variables]
    excluded = []
    if rows:
      with st.expander("Choose individual variables and read their definitions"):
        excluded = form_help.field(st.multiselect, "Also remove these variables", all_variables, key=excluded_key, binding=draft_binding,
                                  help="Individual removals are remembered when you turn a section off and back on.")
        st.dataframe([{"Variable": r["variable_id"], "Section": r["domain"], "Definition": r["definition"]}
                      for r in rows], hide_index=True, width="stretch")
    retained = [v for v in candidates if v not in excluded]
    st.subheader("2. Propose additions")
    st.caption("Describe the rule in your own words. A data expert will map it to the source and implementation.")
    additions_key = prefix + "additions"
    additions = st.session_state.setdefault(additions_key, [])
    c1, c2 = st.columns(2)
    domain = form_help.field(c1.text_input, "Section for the new variable", key=prefix + "add_domain", binding=draft_binding, placeholder="Laboratory results")
    variable = form_help.field(c2.text_input, "New variable identifier", key=prefix + "add_variable", binding=draft_binding, placeholder="BASELINE_ALBUMIN")
    definition = form_help.field(st.text_area, "Definition, timing, and missing-data rule", key=prefix + "add_definition", binding=draft_binding)
    if st.button("Add to the draft", key=f"revision_add_{pack}"):
        item = {"domain": domain.strip(), "variable_id": variable.strip(), "definition": definition}
        if not all(value.strip() for value in item.values()):
            st.warning("Complete the section, identifier, and definition before adding the variable.")
        elif item["variable_id"].casefold() in {r["variable_id"].casefold() for r in rows + additions}:
            st.warning("That identifier already exists. Describe a revision in the purpose field or choose a new identifier.")
        else:
            st.session_state[additions_key] = additions + [item]
            st.rerun()
    if additions:
        st.table(additions)
        drop_options = [a["variable_id"] for a in additions]
        drop_key = prefix + "drop"
        if st.session_state.get(drop_key) not in drop_options:
            st.session_state[drop_key] = drop_options[0]
        drop = st.selectbox("Remove a proposed addition", drop_options, key=drop_key)
        if st.button("Remove from the draft", key=f"revision_remove_{pack}"):
            st.session_state[additions_key] = [a for a in additions if a["variable_id"] != drop]
            st.rerun()
    st.subheader("3. Review the data source")
    current = description["source"]
    st.caption(f"Current source: {current.get('vendor') or 'not declared'} · {current.get('modality') or 'modality not declared'}")
    with st.expander("Current source tables and mappings"):
        if description.get("source_tables"):
            st.table([{"Source": name, "Configured table or mapping": json.dumps(value, ensure_ascii=False)
                       if isinstance(value, (dict, list)) else str(value)}
                      for name, value in description["source_tables"].items()])
        else:
            st.info("No source tables are configured yet. A source choice needs a delivery and reviewed mappings before it can run.")
    c1, c2 = st.columns(2)
    source_key, modality_key = prefix + "source", prefix + "modality"
    st.session_state.setdefault(source_key, current.get("vendor") or "")
    source = form_help.field(c1.text_input, "Proposed data source", key=source_key, binding=draft_binding,
                            help="Use the existing source name to retain it, or describe the proposed replacement.")
    modalities = ["ehr", "claims"]
    st.session_state.setdefault(modality_key, current.get("modality") if current.get("modality") in modalities else None)
    modality = form_help.field(c2.selectbox, "Proposed data modality", modalities, binding=draft_binding,
                             index=None, key=modality_key,
                             format_func=lambda value: "Electronic health records" if value == "ehr" else "Insurance claims")
    plan = workspace.build_plan(description, retained, additions, purpose,
                                 [s.strip() for s in studies_text.splitlines() if s.strip()], source, modality)
    st.subheader("Change impact")
    c1, c2, c3 = st.columns(3)
    c1.metric("Variables retained", len(plan["kept"]))
    c2.metric("Variables removed", len(plan["removed"]))
    c3.metric("Variables proposed", len(plan["added"]))
    if plan["classification"] != "none":
        st.write(f"**Revision type: {plan['classification']}.** Your data expert must validate the implementation and affected studies.")
    for warning in plan["warnings"]:
        st.warning(warning)
    if plan["errors"]:
        st.write("**Definition brief requirements**")
    import configuration_proposals
    if configuration_proposals.applicable(root, pack):
        st.caption("The requirements below govern saving or downloading a definition brief. For a configuration-only change, "
                   "describe its purpose above and use Stage a configuration proposal below; no new definition is required.")
    for error in plan["errors"]:
        st.info(error)
    if plan["dependency_conflicts"]:
        st.table(plan["dependency_conflicts"])
    with st.expander("What needs review before this can run", expanded=bool(plan["source_changed"])):
        for step in plan["review_checklist"]:
            st.write(f"• {step}")
        if plan["removed"]:
            st.write("Removed variables: " + ", ".join(plan["removed"]))
    with st.expander("Review the exact draft definitions"):
        st.caption(f"{len(rows)} current variables → {len(plan['kept']) + len(plan['added'])} draft variables. "
                   "Original product files, study pins and approvals stay on their existing version.")
        definitions = workspace._projection(description, plan)
        st.dataframe([{"Variable": row["variable_id"], "Section": row["domain"], "Origin": row["origin"],
                       "Definition": row["definition"]} for row in definitions["variables"]], hide_index=True, width="stretch")
        st.write("Intended studies: " + (", ".join(plan["studies"]) or "not yet named"))
        st.write(f"Source: {current.get('vendor') or 'not declared'} ({current.get('modality') or 'unknown'}) → {source} ({modality or 'choose modality'})")
    if not (actor_id and local_demo and can_write):
        st.info("Saving revisions requires a local editing session with permission to change this product. You can still download a valid brief.")
    if st.button("Save draft revision", key=f"revision_save_{pack}",
                 disabled=not (actor_id and local_demo and can_write and plan["valid"] and not changed)) and same_context:
        inputs = {"retained": retained, "additions": additions, "purpose": purpose,
                  "studies": [s.strip() for s in studies_text.splitlines() if s.strip()],
                  "target_source": source, "target_modality": modality}
        result = workspace.save_draft(root, pack, inputs, actor_id=actor_id, local_demo=local_demo,
                                      can_write=can_write, allowed_packs=allowed_packs,
                                      expected_baseline=st.session_state[prefix + "baseline"],
                                      draft_id=saved_metadata["draft_id"] if saved_metadata else None,
                                      expected_version=saved_metadata["expected_version"] if saved_metadata else None)
        if result["ok"]:
            st.session_state[metadata_key] = {"draft_id": result["draft_id"], "version": result["version"],
                                             "expected_version": result["version"], "summary": result["summary"]}
            st.session_state[notice_key] = (f"Saved draft version {result['version']} with {result['summary']['after_count']} definitions. "
                                           "Reopen it under Your saved draft revisions." if result["changed"] else
                                           f"No changes since saved version {result['version']}; that version is still available.")
            st.rerun()
        else:
            for error in result["errors"]:
                st.error(error)
    st.download_button("Download the revision brief", json.dumps(plan, indent=2, ensure_ascii=False),
                       file_name="product_revision_brief.json", mime="application/json",
                       disabled=not plan["valid"] or changed, key=f"revision_download_{pack}")
    configuration_proposal_page.render(root, pack, plan, expected_baseline=st.session_state[prefix + "baseline"],
                                       baseline_changed=changed, actor_id=actor_id, local_demo=local_demo,
                                       can_write=can_write, allowed_packs=allowed_packs)
