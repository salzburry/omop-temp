"""Question-bound drafting choices; nothing selects or records a scientific ruling."""
from __future__ import annotations

import hashlib
import re

import streamlit as st

CUSTOM = "Write my own answer"
UNSURE = "Not sure yet"
COMPLETE = "Build a complete answer"
PARTS = "Work through the question in parts"

# Match the full question, not a decision ID or a disease/name keyword. These
# choices quote alternatives the issued question itself states.
_ALTERNATIVES = {
    'For a nonexistent line, is the LOT category null or 17 "No treatment"?':
        ['null', '17 "No treatment"'],
    'Progression eligibility boundary `> index+14` vs `>= index+14`':
        ['> index+14', '>= index+14'],
    'Is struck `TTNTFL` published, internal-only, or removed? (cross-setting TTNT itself is a confirmed engine requirement — in ENGINE_GAPS)':
        ['published', 'internal-only', 'removed'],
    'Are ID_PD_mCRPC / ID_PD_mHSPC published ADS vars, internal gates, or replaced by cohort-row inclusion?':
        ['published ADS vars', 'internal gates', 'replaced by cohort-row inclusion'],
    'Is LOTN mCRPC-only, or cohort-setting-specific? (LOTN=0-for-untreated is a *requirement*, in ENGINE_GAPS)':
        ['mCRPC-only', 'cohort-setting-specific'],
    'Keep or drop TRTDIS / TTD / TSST (struck in the spec but still emitted)? If kept, TTD needs the `+1`':
        ['Keep', 'drop'],
}
_COMPOUND = {
    'Window (`[-30,+7]` vs any-time-before-index) and date basis (specimen-collected vs -received)': [
        'Window: TODO — compare [-30,+7] with any-time-before-index.',
        'Date basis: TODO — choose specimen-collected or specimen-received and explain the source implication.',
    ],
    'How is end-of-follow-up defined (which activity sources, death cap, study-end cap)?': [
        'Activity sources: TODO.', 'Death cap: TODO.', 'Study-end cap: TODO.',
    ],
    'What is the valid study-end, and does the 60-day delivery lag apply?': [
        'Valid study-end date: TODO — confirm a real calendar date against the source.',
        'Whether and how the 60-day delivery lag applies: TODO.',
    ],
}
_MATRIX = ('The per-cohort **C1–C7** applicability matrix for every FU outcome: applicable-or-null, line anchor, event + censor defs, '
           'ID3MOSFU + DTH_BEFORE_FUED gating, and the C7 next-treatment **source** + event definition + censoring when no qualifying next treatment '
           'is observed (the boundary is the next-treatment *source*, not ADS publication — a LOT5 source record may be usable even if LOT5 isn\'t '
           'a published column). RWP drafts the matrix, RWB approves')
_COMPOUND[_MATRIX] = [
    'For each C1–C7 cohort and each FU outcome: TODO — applicable or null.',
    'For each applicable combination: TODO — line anchor, event definition, censor definition and gating.',
    'C7 next-treatment source: TODO — identify the source separately from ADS publication.',
    'No qualifying next treatment observed: TODO — state the censoring rule.',
    'Detailed matrix location and review rationale: TODO — reference the reviewed artifact in the final ruling.',
]


def _normal(text):
    return re.sub(r"\s+", " ", str(text or "")).strip()


# DERIVED FROM THE QUESTION ITSELF (2026-09-07, decision loop audit DL-11). The table above only
# knew the prostate fixture's wordings, so every other pack's question offered no choice at all.
# The patterns below quote alternatives the question states in its own words: 'A vs B', 'A or B',
# 'either A or B', 'keep or drop', and a yes/no question. The table stays as an override for the
# wordings whose alternatives a person has already checked. Nothing here selects an answer.
_STEM = re.compile(r"^(?:is|are|was|were|does|do|did|should|shall|can|could|will|would|has|have|may|must|keep)\b", re.I)
_YES_NO = re.compile(r"^(?:is|are|was|were|does|do|did|should|shall|can|could|will|would|has|have|may|must)\b", re.I)
_STOP = {"is", "are", "was", "were", "be", "the", "a", "an", "should", "does", "do", "as", "either", "and",
         "within", "in", "at", "for", "of", "to", "when", "if", "before", "after", "with", "on", "from", "by"}
_ARTICLES = ("the", "a", "an")


def _first_sentence(question):
    """The clause that asks; a trailing remark after the question mark is not part of the choice."""
    text = _normal(question)
    head = text.split("?", 1)[0]
    return head.strip(" .:;,")


def _side(words, limit):
    """Up to `limit` words of one alternative, read from the word nearest the 'or' or 'vs'."""
    words = list(words)
    while words and words[0].lower() in _ARTICLES:
        words = words[1:]
    kept = []
    for word in words:
        if word.lower() in _STOP or not word:
            break
        kept.append(word)
        if len(kept) >= limit:
            break
    return kept


def _unquote(phrase):
    phrase = phrase.strip(" `")
    if len(phrase) > 1 and phrase[0] == phrase[-1] and phrase[0] in "'\"":
        phrase = phrase[1:-1]
    words = phrase.split()
    while words and words[0].lower() in _ARTICLES:
        words = words[1:]
    return " ".join(words)


def _versus(sentence):
    quoted = re.search(r"`([^`]+)`\s+(?:vs\.?|versus)\s+`([^`]+)`", sentence, re.I)
    if quoted:
        return [quoted.group(1).strip(), quoted.group(2).strip()]
    match = re.search(r"\s+(?:vs\.?|versus)\s+", sentence, re.I)
    if not match:
        return []
    left = re.split(r"[,;:()]", sentence[:match.start()])[-1].split()
    right = re.split(r"[,;:()]", sentence[match.end():])[0].split()
    right_words = _side(right, 3)
    left_words = list(reversed(_side(list(reversed(left)), max(len(right_words), 1))))
    if left_words != left or right[len(right_words):] not in ([], ["within", "the", "window"]):
        return []
    if left_words and right_words:
        return [" ".join(left_words), " ".join(right_words)]
    return []


def _either_or(sentence):
    match = re.search(r"\beither\s+(.+?)\s+or\s+(.+)$", sentence, re.I)
    if not match:
        return []
    left, right = match.group(1).strip(" ,"), match.group(2).strip(" ,")
    return [left, right] if left and right else []


def _or_list(sentence):
    if not re.search(r"\bor\b", sentence, re.I):
        return []
    if re.search(r"\bkeep or drop\b", sentence, re.I):
        return ["Keep", "drop"]
    if re.search(r"[\[(][^\])]*,[^\])]*[\])]", sentence):
        return []
    parts = [part.strip() for part in re.split(r",\s*(?:or\s+)?|\s+or\s+", sentence) if part.strip()]
    if len(parts) < 2:
        return []
    # A stated predicate supplies the whole alternatives, including negation,
    # timing qualifiers and parenthesized boundaries. Word-count clipping turned
    # 'not excluded or imputed from the next visit' into 'excluded or imputed'.
    predicate = re.search(r"\bbe\s+(.+)$", parts[0], re.I)
    if predicate and _STEM.match(parts[0]):
        whole = [predicate.group(1), *parts[1:]]
        if all(len(phrase) <= 160 for phrase in whole):
            return whole
    # "censored at death, at the last recorded administration, or at the last visit" (walk UC3-P3-2):
    # a list whose items all open with the same short word names the alternatives after that word
    lead = re.match(r"(at|in|on|by|to|from|of|with|as|after|before|under)\s+", parts[1], re.I)
    if lead and all(re.match(lead.group(1) + r"\s+", part, re.I) for part in parts[1:]):
        word = lead.group(1).lower()
        anchor = parts[0].lower().rfind(" " + word + " ")
        if anchor >= 0:
            first = parts[0][anchor + len(word) + 2:].strip(" ?.;:")
            rest = [re.sub(r"^" + word + r"\s+", "", part, flags=re.I).strip(" ?.;:") for part in parts[1:]]
            if first and all(rest) and all(len(p.split()) <= 6 for p in [first, *rest]):
                return [first, *rest]
    starts = [index for index, part in enumerate(parts) if _STEM.match(part)]
    parts = parts[starts[-1]:] if starts else parts
    if len(parts) < 2:
        return []
    rest = [" ".join(_side(part.split(), 4)) for part in parts[1:]]
    if not all(rest):
        return []
    # Without an explicit predicate, do not silently discard a second option's
    # qualifiers. Ambiguous wording retains the complete-answer/manual routes.
    if any(_unquote(part) != phrase for part, phrase in zip(parts[1:], rest)):
        return []
    width = len(rest[0].split())
    first = list(reversed(_side(list(reversed(parts[0].split())), width)))
    if not first:
        return []
    prefix = parts[0][:-len(" ".join(first))].split()
    if prefix and prefix[-1].lower() in {"not", "never", "no", "without"}:
        return []
    return [" ".join(first), *rest]


def derived_alternatives(question):
    """Alternatives quoted from the question's own wording, or [] when it states none.

    Every phrase returned appears verbatim in the normalized question, so a choice can only ever
    repeat what the question already says. A wording the table knows wins over this derivation.
    """
    sentence = _first_sentence(question)
    if not sentence:
        return []
    normal = _normal(question)
    # One choice must not conceal a second scientific question. Checked compound
    # prompts use their explicit component guide above; other compound prompts
    # keep all their wording visible in the manual drafting route.
    if (re.search(r"\b(?:and|also|then)\s+(?:how|what|which|should|is|are|does|do)\b", normal, re.I)
            or re.search(r"\?\s*(?:how|what|which|should|is|are|does|do)\b", normal, re.I)
            or len(re.findall(r"\b(?:vs\.?|versus)\b", sentence, re.I)) > 1):
        return []
    # A parenthesized qualifier is part of an alternative, not disposable prose.
    # Only the explicit either/or or predicate form below can preserve it whole.
    if "(" in sentence and not re.search(r"\b(?:either|be)\b", sentence, re.I):
        return []
    for derive in (_versus, _either_or, _or_list):
        phrases = [_unquote(phrase) for phrase in derive(sentence)]
        phrases = [phrase for phrase in phrases if phrase and phrase in normal]
        if len(phrases) >= 2 and len(set(p.lower() for p in phrases)) == len(phrases):
            return phrases
    if _YES_NO.match(sentence) and not re.search(r"\b(?:or|vs\.?|versus|which|what|how)\b", sentence, re.I):
        return ["Yes", "No"]
    return []


def describe(question):
    question = _normal(question)
    alternatives = next((values for wording, values in _ALTERNATIVES.items() if _normal(wording) == question), [])
    components = next((values for wording, values in _COMPOUND.items() if _normal(wording) == question), [])
    if not alternatives and not components:
        alternatives = derived_alternatives(question)
    options = {}
    for phrase in alternatives:
        options["Consider: " + phrase] = phrase
    complete = "TODO: State the ruling for this question.\nScope or population: TODO.\nRationale and supporting evidence: TODO.\nRemaining questions: TODO."
    parts = "TODO: Work through every part before recording the decision.\n" + "\n".join(components or [
        "List each part of the issued question: TODO.",
        "For each part, state the answer, scope and supporting evidence: TODO.",
        "Confirm whether any part is still unresolved: TODO.",
    ])
    options.update({COMPLETE: complete, PARTS: parts})
    return {"options": options, "alternatives": alternatives, "components": components,
            "kind": "alternatives" if alternatives else "compound" if components else "open"}


def prefix(decision_id):
    return f"decision_answer_{decision_id}_"


def use_answer(decision_id, answer):
    """Called before this question's widgets render, including an explicit AI copy."""
    base = prefix(decision_id)
    st.session_state[base + "answer"] = answer
    st.session_state[base + "approach"] = CUSTOM
    st.session_state[base + "previous_approach"] = CUSTOM
    st.session_state[base + "custom_answer"] = answer


def note_edit(decision_id):
    base = prefix(decision_id)
    st.session_state[base + "approach"] = CUSTOM
    st.session_state[base + "previous_approach"] = CUSTOM
    st.session_state[base + "custom_answer"] = st.session_state.get(base + "answer", "")


def render(decision_id, question, *, enabled, remember):
    base = prefix(decision_id)
    guide = describe(question)
    signature = hashlib.sha256(str(question).encode()).hexdigest()
    if st.session_state.get(base + "guide") not in (None, signature):
        # Keep authored text but do not reuse a choice from a different question.
        st.session_state[base + "approach"] = CUSTOM if st.session_state.get(base + "answer") else None
        st.session_state[base + "previous_approach"] = st.session_state[base + "approach"]
        st.session_state.pop(base + "choice_explanation", None)
    st.session_state[base + "guide"] = signature
    raw = st.session_state.get(base + "answer", "")
    if base + "approach" not in st.session_state:
        prior = st.session_state.get(base + "previous_approach")
        st.session_state[base + "approach"] = prior if prior in (*guide["options"], CUSTOM, UNSURE) else CUSTOM if raw else None
        st.session_state[base + "previous_approach"] = st.session_state[base + "approach"]

    def changed():
        old = st.session_state.get(base + "previous_approach")
        previous_answer = st.session_state.get(base + "answer", "")
        if old in (None, CUSTOM):
            st.session_state[base + "custom_answer"] = previous_answer
        mode = st.session_state[base + "approach"]
        if mode != old and str(mode).startswith("Consider: "):
            st.session_state.pop(base + "choice_explanation", None)
        if mode in guide["options"]:
            if not mode.startswith("Consider: "):
                st.session_state[base + "answer"] = guide["options"][mode]
        elif mode == UNSURE:
            st.session_state[base + "answer"] = "TODO: Not sure yet. Record what needs discussion and which evidence is still needed."
        elif mode == CUSTOM:
            st.session_state[base + "answer"] = st.session_state.get(base + "custom_answer", previous_answer)
        elif mode is None and previous_answer:
            st.session_state[base + "approach"] = CUSTOM
        st.session_state[base + "previous_approach"] = st.session_state[base + "approach"]
        remember(decision_id)

    st.selectbox("How would you like to draft the answer?", [*guide["options"], CUSTOM, UNSURE],
                 index=None, key=base + "approach", placeholder="Choose a starting point, or type your own answer below",
                 disabled=not enabled, on_change=changed,
                  help="Nothing is selected automatically. Quoted alternatives come from this exact question. Add your explanation, then explicitly copy the choice into your draft before reviewing it.")
    mode = st.session_state.get(base + "approach")
    guide["pending_choice"] = bool(mode in guide["options"] and str(mode).startswith("Consider: "))
    if guide["pending_choice"]:
        phrase = guide["options"][mode]
        st.info("Next: explain where this choice applies and why the evidence supports it. Then use it in your draft and review the full answer below.")
        explanation = st.text_area("Why this choice, and where does it apply?", key=base + "choice_explanation",
            max_chars=2500, disabled=not enabled,
            help="One or two sentences can be enough. State the population or fields, the complete rule and its source. Include any limits or exceptions; if still unresolved, keep the question open.")
        import decision_answers
        ready = bool(explanation.strip()) and not decision_answers.unresolved_answer(explanation)
        composed = f"Question: {question}\nDecision: {phrase}\nScope, rationale and evidence: {explanation.strip()}"
        if len(composed) > 4000:
            ready = False
            st.warning("Shorten the explanation so the complete answer fits the 4,000-character decision record; cite longer evidence separately.")
        def use_choice():
            # An explicit draft action, never attribution, application or scientific approval.
            use_answer(decision_id, composed)
            remember(decision_id)
        st.button("Use choice and explanation in my draft", key=base + "use_choice", disabled=not enabled or not ready,
                  on_click=use_choice)
    if guide["alternatives"] == ["Yes", "No"]:
        st.caption("This reads as a yes or no question. Your explanation supplies the rule, scope and reason. The question stays open until you explicitly save the reviewed answer.")
    elif guide["alternatives"]:
        st.caption("The quoted alternatives are stated in this question. Selecting one does not change your answer until you choose Use choice and explanation in my draft.")
    elif guide["components"]:
        st.caption("This question has several parts. Use the structured starting point and answer every applicable part; one yes/no choice would leave the ruling incomplete.")
    else:
        st.caption("This question does not supply a complete set of selectable rulings. The choices organize your draft; they do not invent scientific answers.")
    with st.expander("What to put in this answer"):
        if guide["components"]:
            for component in guide["components"]:
                st.text(component)
        st.write("State the rule, the population or outputs it applies to, and why the cited evidence supports it. For several decisions in one question, address each part and reference any detailed matrix or reviewed artifact.")
        st.caption("Illustrative format: Decision: [your reviewed rule]; Scope: [affected population or fields]; Rationale: [evidence and reasoning]; Open points: [anything still unresolved]. Replace the placeholders with your own judgment.")
    return guide
