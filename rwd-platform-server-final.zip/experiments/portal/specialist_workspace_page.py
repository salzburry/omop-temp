"""One explicit evidence-assistance action, followed by a human-review continuation."""
from __future__ import annotations

import json
import hashlib
from pathlib import Path
import streamlit as st
import form_assistance as form_help
import specialist_workspace as workspace
import scientific_definition_ai as ai

PREFIX = "specialist_ws_"
# A content-free receipt survives the field reset when the identity changes.
HANDOFF_RECEIPT = "specialist_request_handoff_receipt"


def feedback_for_record(root, pack, actor_id, record, *, allowed_packs, can_write, key=PREFIX + "feedback"):
    """Use the same prepared feedback form for a selected specialist answer."""
    import interaction_feedback_page as feedback
    if not record or record.get("stale") or record.get("kind") not in workspace.KINDS:
        feedback.clear(key)
        return
    meta = workspace.KINDS[record["kind"]]
    content = record.get("result", {}).get(meta["result"], {})
    summary = content.get("summary") if isinstance(content, dict) else None
    if not isinstance(summary, str) or not summary.strip():
        feedback.clear(key)
        return
    feedback.offer(root, pack, actor_id, route=record["kind"],
        interaction_id=record["id"] + ":" + record.get("digest", ""),
        request=record.get("question") or meta["purpose"], answer=summary,
        can_write=can_write, allowed_packs=allowed_packs, key=key)


def _result(record, *, key=PREFIX + "result", code_details=False):
    meta = workspace.KINDS[record["kind"]]
    st.write("**" + meta["label"] + " · saved proposal**")
    st.caption(f"{record['created_at'][:19]} · {record['provider']} · {record.get('calls', 0)} model calls")
    if record.get("excerpted_calls"):
        st.warning("This run used labelled evidence excerpts to fit the model connection. Omitted material was not assessed; inspect the original evidence before acting.")
    if record.get("stale"):
        st.warning("Product evidence changed after this run. Keep this as historical context and run again before requesting review.")
    result = record["result"]
    content = result.get(meta["result"]) or {}
    if isinstance(content, dict) and content.get("summary"):
        st.write(str(content["summary"]))
    critic = result.get("critic")
    if isinstance(critic, dict):
        st.info("Model critique: " + str(critic.get("route", "human")) + ". Review the findings below, then continue with the matching workflow.")
        for finding in critic.get("findings") or []:
            st.write("• " + str(finding))
        if critic.get("second_vote_recommended"):
            st.caption("The critic recommends a second review before acting on this result.")
    else:
        st.warning("This result has no model critique. Inspect its reported refusals before continuing.")
    st.caption(str(result.get("decision") or "The result remains an unreviewed proposal."))
    if record["kind"] == "implementation":
        from pattern_workspace_page import integration_details, _code
        if code_details:
            try:
                _code(result)
            except (ValueError, TypeError, KeyError, AttributeError):
                st.warning("The structured code view is unavailable for this result. Inspect the exact saved proposal and checks below before requesting review.")
        else:
            integration_details(result)
    with st.expander("Inspect the full proposal and checks"):
        if record.get("skills"):
            st.caption("Workflow instructions used: " + ", ".join(skill["name"] + " v" + skill["version"] for skill in record["skills"]))
            if any(skill.get("coverage") != "full" for skill in record["skills"]):
                st.caption("Labelled skill excerpts were used within the connection's context limit. The saved source digest identifies the complete instructions.")
        st.json(result)
    st.download_button("Download this exact result", json.dumps(record, indent=2),
                       file_name="specialist-result-" + record["id"] + ".json", mime="application/json", key=key + "_download")


def render(root, pack, actor_id, *, allowed_packs, local_demo, can_write, can_review,
           route, params=None, can_agent=False):
    context = (str(root), pack, actor_id, bool(local_demo and can_write),
               tuple(sorted(allowed_packs or [])))
    if st.session_state.get(PREFIX + "context") != context:
        import interaction_feedback_page
        interaction_feedback_page.clear(PREFIX + "feedback")
        for key in list(st.session_state):
            if str(key).startswith(PREFIX):
                del st.session_state[key]
        st.session_state[PREFIX + "context"] = context
    params = params or {}
    if params.get("run_id") and st.session_state.get(PREFIX + "incoming_run") != params["run_id"]:
        st.session_state[PREFIX + "incoming_run"] = params["run_id"]
        st.session_state[PREFIX + "run_id"] = params["run_id"]
    if params.get("review_id"):
        try:
            record = workspace.shared(root, pack, params["review_id"], allowed_packs=allowed_packs)
        except ValueError as error:
            feedback_for_record(root, pack, actor_id, None, allowed_packs=allowed_packs, can_write=False)
            st.error(str(error))
            return
        _result(record)
        feedback_for_record(root, pack, actor_id, record, allowed_packs=allowed_packs, can_write=bool(local_demo and can_write))
        st.caption("This is the exact snapshot shared with the request. Your review does not edit the author's private runs.")
        if st.button("Return to the review request", key=PREFIX + "back_review"):
            return {"route": "handoffs"}
        if st.button("Continue reviewing in the related workflow", key=PREFIX + "review_continue"):
            return {"route": "implementation_patterns" if record["kind"] == "implementation" else workspace.KINDS[record["kind"]]["next"],
                    "params": {"specialist_review": params["review_id"],
                               "variable": record["question"] if record["kind"] == "implementation" else None}}
        return
    report = workspace.describe(root, pack, actor_id, allowed_packs=allowed_packs)
    if not report["ok"]:
        feedback_for_record(root, pack, actor_id, None, allowed_packs=allowed_packs, can_write=False)
        for error in report["errors"]:
            st.error(error)
        return
    if PREFIX + "kind" not in st.session_state:
        st.session_state[PREFIX + "kind"] = params.get("kind") if params.get("kind") in workspace.KINDS else "source"
    incoming = {key: params.get(key) for key in ("kind", "failure", "variable", "user_request")}
    incoming_digest = hashlib.sha256(json.dumps(incoming, sort_keys=True).encode()).hexdigest()
    owner = (str(Path(root).resolve()), pack, actor_id)
    receipt = st.session_state.get(HANDOFF_RECEIPT)
    stale = bool(isinstance(receipt, dict) and receipt.get("digest") == incoming_digest and receipt.get("owner") != owner)
    if not stale and incoming["kind"] in workspace.KINDS and st.session_state.get(PREFIX + "incoming") != incoming:
        try:
            ai._ingress(json.dumps(incoming))
            if any(value is not None and (not isinstance(value, str) or len(value) > 1200) for value in incoming.values()):
                raise ai.Invalid("Keep the assistant handoff under 1,200 characters per field.")
        except ai.Invalid as error:
            st.error(str(error))
            return
        st.session_state[PREFIX + "incoming"] = incoming
        st.session_state[HANDOFF_RECEIPT] = {"digest": incoming_digest, "owner": owner}
        st.session_state[PREFIX + "kind"] = incoming["kind"]
        for source, field in (("failure", "failure"), ("variable", "requirement")):
            if incoming[source] and not st.session_state.get(PREFIX + field):
                st.session_state[PREFIX + field] = str(incoming[source])
        request_field = {"implementation": "implementation_request", "source": "source_request", "validation": "failure"}[incoming["kind"]]
        if incoming["user_request"] and not st.session_state.get(PREFIX + request_field):
            st.session_state[PREFIX + request_field] = str(incoming["user_request"])
    kind = st.radio("What would you like help with?", list(workspace.KINDS), key=PREFIX + "kind",
                    format_func=lambda value: workspace.KINDS[value]["label"])
    meta = workspace.KINDS[kind]
    st.write(meta["purpose"])
    implementation_request, previous_run_id = "", None
    if kind == "implementation":
        question = form_help.field(st.text_input, "Definition identifier", key=PREFIX + "requirement",
            help="Use the exact identifier from the scientific definition, for example BASELINE_ALBUMIN.", binding=(report["input_digest"], kind))
        implementation_request = form_help.field(st.text_area, "What should the coding assistant investigate or change?", key=PREFIX + "implementation_request",
            max_chars=1200, help="Describe the behavior to preserve or fix, a test failure, or what to refine in the previous proposal.",
            binding=(report["input_digest"], kind, question))
        selected_run = st.session_state.get(PREFIX + "run_id")
        if selected_run:
            try:
                previous = workspace.read(root, pack, actor_id, selected_run, allowed_packs=allowed_packs)
            except ValueError:
                previous = None
            if previous and previous["kind"] == "implementation" and previous["question"] == question and not previous["stale"]:
                if st.checkbox("Continue from the displayed proposal and its recorded checks", value=True,
                               key=PREFIX + "continue_" + selected_run):
                    previous_run_id = selected_run
    elif kind == "validation":
        question = form_help.field(st.text_area, "Which failure should it examine?", key=PREFIX + "failure",
            help="Paste the validation message without patient records or credentials. Leave blank to inspect current check failures.", binding=(report["input_digest"], kind))
    else:
        question = form_help.field(st.text_area, "What should it investigate?", key=PREFIX + "source_request",
            max_chars=1200, help="Ask about a source, missing evidence, or a mapping concern. Leave blank for an overview of the current declarations.",
            binding=(report["input_digest"], kind))
        st.caption("Uses the current source declarations and cleared mapping evidence. Missing evidence remains a question for the data expert.")
    selected = ai.selected_provider()
    st.caption("Assistant connection: " + (ai.PROVIDERS.get(selected) or "choose one in the sidebar"))
    st.caption("A run includes the specialist and its critic: at most four model calls and three minutes. API requests are capped at $0.50; VS Code and Claude Code use their account limits. Generated code is not executed.")
    if report["blocker"]:
        st.info(report["blocker"])
    if not can_agent or not local_demo:
        st.info("You can inspect shared results. An authorised local assistant user starts new runs.")
    disabled = bool(report["blocker"] or not local_demo or not can_agent or selected not in ai.PROVIDERS)
    if st.button("Run this evidence check", key=PREFIX + "run", disabled=disabled, type="primary"):
        with st.spinner("Checking the evidence and preparing a proposal…"):
            outcome = workspace.run(root, pack, actor_id, kind, question,
                expected_input_digest=report["input_digest"], allowed_packs=allowed_packs,
                local_demo=local_demo, can_agent=can_agent,
                **({"user_request": implementation_request, "previous_run_id": previous_run_id} if kind == "implementation" else {}))
        if outcome["ok"]:
            st.session_state[PREFIX + "run_id"] = outcome["record"]["id"]
            st.rerun()
        else:
            for error in outcome["errors"]:
                st.error(error)
    if report["runs"]:
        with st.expander("Resume a saved result"):
            chosen = st.selectbox("Saved result", report["runs"], key=PREFIX + "saved",
                format_func=lambda row: row["created_at"][:19] + " · " + workspace.KINDS[row["kind"]]["label"])
            if st.button("Open this result", key=PREFIX + "open"):
                st.session_state[PREFIX + "run_id"] = chosen["id"]
    run_id = st.session_state.get(PREFIX + "run_id")
    if run_id:
        try:
            record = workspace.read(root, pack, actor_id, run_id, allowed_packs=allowed_packs)
        except ValueError as error:
            feedback_for_record(root, pack, actor_id, None, allowed_packs=allowed_packs, can_write=False)
            st.error(str(error))
            return
        _result(record)
        feedback_for_record(root, pack, actor_id, record, allowed_packs=allowed_packs, can_write=bool(local_demo and can_write))
        with st.expander("Share this exact result with its reviewer"):
            note = form_help.field(st.text_area, "What should the reviewer consider?", key=PREFIX + "review_note", binding=(run_id, record.get("input_digest")))
            if st.button("Create a review request", key=PREFIX + "share", disabled=record["stale"] or not can_agent or not local_demo):
                try:
                    doc = workspace.share(root, pack, actor_id, run_id, note, allowed_packs=allowed_packs,
                                          local_demo=local_demo, can_agent=can_agent)
                    st.success("Review request saved for " + doc["owner"] + ". It includes this exact result.")
                except ValueError as error:
                    st.error(str(error))
        target = "implementation_patterns" if record["kind"] == "implementation" else workspace.KINDS[record["kind"]]["next"]
        if st.button("Continue with this result's workflow", key=PREFIX + "continue"):
            params = {"variable": record["question"]} if record["kind"] == "implementation" else {}
            params["specialist_run"] = record["id"]
            return {"route": target, "params": params}
    if st.button("Open the related workflow without AI", key=PREFIX + "manual"):
        return {"route": meta["next"], "params": {"variable": question} if kind == "implementation" else {}}
