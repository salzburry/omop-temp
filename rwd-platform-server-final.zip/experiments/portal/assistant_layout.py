"""One responsive assistant dock beside the current Streamlit workspace."""
from contextlib import contextmanager, nullcontext
from contextvars import ContextVar
from functools import wraps

import streamlit as st


_dock = ContextVar("portal_assistant_dock", default=None)


@contextmanager
def workspace(*, enabled=True):
    """Keep the layout local to this script run and browser session."""
    token = _dock.set(None)
    try:
        if not enabled:
            yield
            return
        with st.container(key="rwd_workspace_layout"):
            work, chat = st.columns([1.4, 1], gap="medium", vertical_alignment="top")
            with chat:
                with st.container(key="rwd_assistant_dock"):
                    slot = st.empty()
            _dock.set(slot)
            with work:
                yield
    finally:
        _dock.reset(token)


def in_panel(function):
    """Route chat to the dock; isolated pages/tests retain their natural layout.

    A row-specific conversation replaces the general guide in the same slot.
    The surrounding workspace and its unfinished widgets are not rerendered.
    """
    @wraps(function)
    def wrapped(*args, **kwargs):
        slot = _dock.get()
        with slot.container() if slot is not None else nullcontext():
            return function(*args, **kwargs)
    return wrapped
