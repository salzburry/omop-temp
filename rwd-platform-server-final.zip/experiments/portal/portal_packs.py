"""Which packs the portal offers, discovered from the registries — never a literal list.

WHY. The page carried five hard-coded fixture paths, one of them superseded (ninth review): a real
product added to products/registry.yaml would not have appeared, and a template or a superseded
version could be picked as a working object. Four kinds exist and the page must keep them apart:

  product     a governed product under products/ (the deployment list) — the default view
  reference   a dated fixture under fixtures/ — reference material, badged, never releasable
  superseded  a fixture version the registry marks superseded — listed, not offered
  template    a `YYYYMM` scaffold — never in a working selector

Pure functions over product_gates; no Streamlit here.
"""
from __future__ import annotations

import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(os.path.dirname(HERE))
sys.path.insert(0, os.path.join(ROOT, "platform", "tools"))

REFERENCE_BADGE = "REFERENCE FIXTURE · NOT CLINICALLY APPROVED · NEVER RELEASABLE"
NO_PRODUCTS = "No live products have been onboarded."


def _superseded(root: str, rel: str) -> bool:
    import product_gates as pg  # noqa: PLC0415
    entry = pg.registry_entry(root, rel) or {}
    ver = rel.rstrip("/").rsplit("/", 1)[-1]
    for v in (entry.get("lineage") or entry.get("versions") or []):   # the registry's key is `lineage`
        if isinstance(v, dict) and str(v.get("spec_version")) == ver and str(v.get("status")) == "superseded":
            return True
    return False


def catalogue(root: str = ROOT) -> dict:
    """{products, references, superseded, templates} — each a sorted list of repo-relative packs."""
    import product_gates as pg  # noqa: PLC0415
    products_all = sorted(pg.products(root))
    fixtures = sorted(pg.fixture_packs(root))
    # templates and superseded versions are filtered on BOTH sides (review of the ninth review: a
    # products/.../YYYYMM scaffold or a superseded product version would have been offered as live)
    templates = [p for p in products_all + fixtures if "YYYYMM" in p]
    superseded = [p for p in products_all + fixtures if p not in templates and _superseded(root, p)]
    products = [p for p in products_all if p not in templates and p not in superseded]
    references = [p for p in fixtures if p not in templates and p not in superseded]
    # THE REFERENCE WITH EVIDENCE FIRST: the local demo opens on the first offered pack, and
    # alphabetical order opened it on the emptiest fixture while DEMO.md names prostate/202606 as
    # the one pack with something real at every gate (eleventh verdict). Registry-driven — the
    # fixture registry's `status: active` entries lead — never a hard-coded pack.
    references.sort(key=lambda p: (str((pg.registry_entry(root, p) or {}).get("status")) != "active", p))
    # THE REGISTERED NAME AND THE CUT'S LINEAGE, for the labels (thirteenth pass, J1/J2): a product is
    # shown by the name the person typed, and a draft cut says it is not released
    names, drafts = {}, set()
    for p in products:
        entry = pg.registry_entry(root, p) or {}
        if str(entry.get("name") or "").strip():
            names[p] = str(entry["name"]).strip()
        cut = p.rstrip("/").rsplit("/", 1)[-1]
        for row in entry.get("lineage") or []:
            if isinstance(row, dict) and str(row.get("spec_version")) == cut and str(row.get("status")) == "draft":
                drafts.add(p)
    return {"products": products, "references": references, "superseded": superseded, "templates": templates,
            "names": names, "drafts": drafts}


def lineage(root: str, rel: str) -> list:
    """The other spec versions of the SAME product, from its registry entry's `lineage` list —
    what a request kept for prostate/202606 may pre-fill on prostate/202607 (eleventh verdict:
    same-pack filtering hid a product's own prior version from its successor)."""
    import product_gates as pg  # noqa: PLC0415
    entry = pg.registry_entry(root, rel) or {}
    base, ver = rel.rstrip("/").rsplit("/", 1)
    out = []
    for v in (entry.get("lineage") or []):
        sv = str((v or {}).get("spec_version") or "") if isinstance(v, dict) else ""
        if sv and sv != ver:
            out.append(f"{base}/{sv}")
    return out


def label(pack: str, cat: dict) -> str:
    """What the picker shows for a pack: the product's name and cut, never the file path
    (`products/oncology/kidney/202609` read as a path to a person, 2026-09-04). A reference
    fixture says so after its name."""
    parts = pack.replace("\\", "/").rstrip("/").split("/")
    slug = parts[-2] if len(parts) >= 2 else pack
    cut = parts[-1] if len(parts) >= 2 else ""
    name = cat.get("names", {}).get(pack) or slug.replace("_", " ")
    if pack not in cat.get("names", {}):
        name = name.upper() if len(name) <= 5 else name[:1].upper() + name[1:]
    shown = name if cut and name.endswith(cut) else f"{name} {cut}".strip()   # a slug that carries its cut, once
    return shown + ("" if pack in cat.get("products", []) else " (reference)") \
        + (" (draft, not released)" if pack in cat.get("drafts", set()) else "")


def badge(pack: str, cat: dict) -> str:
    """The persistent label a non-product pack carries on every surface; empty for a product."""
    return "" if pack in cat.get("products", []) else REFERENCE_BADGE


def assigned_defaults(assigned, offered) -> tuple[list, list]:
    """(the assigned packs the picker can offer, the ones it no longer offers). A roster written
    before a version was superseded still names it; a multiselect default outside its options is a
    page-killing exception, not a warning (seen 2026-09-04: a user's `prostate/202603`)."""
    offered = list(offered or [])
    kept = [p for p in (assigned or []) if p in offered]
    dropped = [p for p in (assigned or []) if p not in offered]
    return kept, dropped
