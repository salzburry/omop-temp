"""A scoped, validated semantic projection saved as exact immutable branch files."""
from __future__ import annotations

from datetime import datetime, timezone
import difflib
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import tempfile
from urllib.parse import urlsplit

import yaml

_REQUEST = None
if __name__ == '__main__' and '--worker' in sys.argv:
    _REQUEST = json.load(sys.stdin)
    _root = Path(_REQUEST['root']).resolve()
    sys.path[:0] = [str(_root / 'platform/tools'), str(_root / 'platform/engine'), str(_root / 'platform')]

import science_workspace as science
import source_workspace as sources
import specification_details as details
import handoffs

ROUTE = 'semantic_export'
FOLDER = 'handoff/semantic_exports'
MAX_BYTES = 4 * 1024 * 1024
NOTICE = 'Read-only projection of reviewed meaning. Saving records these export files for branch review; it does not approve definitions, publish to a graph service or release a product.'


def _fail(error, changed=False):
    return {'ok': False, 'changed': changed, 'errors': [str(error)], 'notice': NOTICE}


def _scope(root, pack, actor_id, allowed_packs):
    source, pack = details._paths(root, pack, allowed_packs)
    if not isinstance(actor_id, str) or not actor_id.strip() or len(actor_id) > 200:
        raise ValueError('An identified portal session is required.')
    root = Path(root).resolve()
    sources._configured_inputs(source.parent)
    folder = science._safe(source.parent / FOLDER)
    return root, source.parent, pack, actor_id, folder


def _namespace(value):
    if not isinstance(value, str) or value != value.strip() or not 1 <= len(value) <= 240 or any(c.isspace() or ord(c) < 32 for c in value):
        raise ValueError('Enter the absolute HTTP or HTTPS identifier namespace owned by your organisation.')
    parsed = urlsplit(value)
    if parsed.scheme not in {'http', 'https'} or not parsed.hostname or parsed.username or parsed.password or parsed.query or parsed.fragment:
        raise ValueError('Use an absolute HTTP or HTTPS namespace without credentials, a query or fragment. This is an identifier, not a delivery endpoint.')
    return value.rstrip('/')


def _inputs(root, pack):
    files = science._inputs(root, {pack})
    files = {name: raw for name, raw in files.items() if not name.startswith(pack + '/' + FOLDER + '/')}
    # Actual shared register/event bytes preserve canonical approval subjects.
    # No other product's contract or decision register is copied or rendered.
    for folder in ('governance', 'platform/tools', 'platform/engine'):
        base = science._safe(root / folder)
        if base.is_dir():
            for path in base.rglob('*'):
                science._safe(path)
                if path.is_file() and path.suffix.lower() in {'.yaml', '.yml', '.json', '.md', '.py'}:
                    if path.stat().st_size > science.MAX_FILE:
                        raise ValueError('A semantic dependency exceeds the supported metadata size.')
                    files[path.relative_to(root).as_posix()] = path.read_bytes()
    for path in sources._configured_inputs(root / pack):
        files[path.relative_to(root).as_posix()] = path.read_bytes()
    files['experiments/portal/semantic_export_workspace.py'] = Path(__file__).read_bytes()
    return science._digest(files)


def _read(path):
    path = science._safe(path)
    with path.open('rb') as handle:
        data = handle.read(MAX_BYTES + 1)
    if len(data) > MAX_BYTES:
        raise ValueError('The export exceeds the supported review size.')
    return data


def _identifier(value):
    if not isinstance(value, str) or not re.fullmatch('[a-f0-9]{24}', value):
        raise ValueError('Choose a saved export version from this product.')
    return value


def _digest(data):
    return hashlib.sha256(data.encode() if isinstance(data, str) else data).hexdigest()


def _load(folder, version_id, pack):
    base = science._safe(folder / _identifier(version_id))
    record = json.loads(_read(base / 'manifest.json'))
    unsigned = dict(record)
    if unsigned.pop('manifest_sha256', None) != science._hash(unsigned) or record.get('pack') != pack or record.get('id') != version_id:
        raise ValueError('This export manifest changed or belongs to another product. Prepare a fresh export.')
    expected_id = science._hash({key: record[key] for key in ('pack', 'namespace', 'input_digest', 'graph_sha256', 'shapes_sha256')})[:24]
    if expected_id != version_id:
        raise ValueError('The export content no longer matches its immutable version identifier.')
    graph, shapes = _read(base / 'graph.jsonld').decode(), _read(base / 'shapes.jsonld').decode()
    if _digest(graph) != record.get('graph_sha256') or _digest(shapes) != record.get('shapes_sha256'):
        raise ValueError('The saved graph or shapes changed after validation. Prepare a fresh export.')
    if record.get('validation', {}).get('state') != 'conforms':
        raise ValueError('This saved version has no passing SHACL result.')
    return {**record, 'graph': graph, 'shapes': shapes}


def describe(root, pack, actor_id, *, allowed_packs=None):
    try:
        root, _product, pack, _actor, folder = _scope(root, pack, actor_id, allowed_packs)
        digest = _inputs(root, pack)
        versions, unreadable = [], 0
        for path in folder.iterdir() if folder.exists() else []:
            if not path.is_dir() or not re.fullmatch('[a-f0-9]{24}', path.name):
                continue
            try:
                record = _load(folder, path.name, pack)
                versions.append({key: record[key] for key in ('id', 'created_at', 'namespace', 'graph_sha256', 'input_digest', 'saved_by')})
            except (ValueError, OSError, KeyError, TypeError):
                unreadable += 1
        versions.sort(key=lambda row: row['created_at'], reverse=True)
        return {'ok': True, 'pack': pack, 'input_digest': digest, 'versions': versions,
                'unreadable_versions': unreadable, 'namespace': '', 'errors': [], 'notice': NOTICE}
    except Exception:
        return _fail('This product or its semantic dependencies cannot be read within the declared scope. Repair its metadata before preparing an export.')


def _run(root, pack, namespace, *, run_validation=True):
    process = subprocess.run([sys.executable, str(Path(__file__).resolve()), '--worker'],
        input=json.dumps({'root': str(root), 'pack': pack, 'namespace': namespace,
                         'run_validation': run_validation}), cwd=root,
        capture_output=True, text=True, encoding='utf-8', errors='replace', timeout=90,
        env={**os.environ, 'PYTHONUTF8': '1', 'PYTHONDONTWRITEBYTECODE': '1'})
    if process.returncode or len(process.stdout.encode()) > MAX_BYTES:
        raise ValueError('The canonical export or SHACL check could not complete. Ask Engineering to inspect the local semantic export tools; no export was saved.')
    return json.loads(process.stdout)


def prepare(root, pack, actor_id, *, namespace, expected_digest, allowed_packs=None):
    try:
        root, _product, pack, _actor, _folder = _scope(root, pack, actor_id, allowed_packs)
        namespace = _namespace(namespace)
        digest = _inputs(root, pack)
        if digest != expected_digest:
            raise ValueError('Product evidence changed. Refresh this page and prepare the export again.')
        result = _run(root, pack, namespace)
        if not result.get('ok'):
            raise ValueError('The canonical semantic projection could not be prepared. Review the current source, contract and clinical bindings.')
        if _inputs(root, pack) != digest:
            raise ValueError('Evidence changed during export validation. Prepare the current evidence again.')
        proposal = {'root': str(root), 'pack': pack, 'actor_id': actor_id, 'namespace': namespace,
                    'input_digest': digest, 'graph': result['graph'], 'shapes': result['shapes'],
                    'report': result['report'], 'validation': result['validation']}
        proposal['graph_sha256'], proposal['shapes_sha256'] = _digest(proposal['graph']), _digest(proposal['shapes'])
        proposal['proposal_sha256'] = science._hash(proposal)
        return {'ok': True, 'proposal': proposal, 'errors': [], 'notice': NOTICE}
    except yaml.YAMLError:
        return _fail('A semantic dependency is malformed. Repair the current metadata before preparing an export.')
    except (ValueError, OSError, KeyError, TypeError, subprocess.TimeoutExpired) as error:
        return _fail(error)


def read(root, pack, actor_id, version_id, *, allowed_packs=None):
    try:
        root, _product, pack, _actor, folder = _scope(root, pack, actor_id, allowed_packs)
        record = _load(folder, version_id, pack)
        return {'ok': True, 'record': record, 'stale': record['input_digest'] != _inputs(root, pack), 'errors': [], 'notice': NOTICE}
    except Exception:
        return _fail('This export version is unavailable, belongs to another product or changed after validation. Prepare a fresh version.')


def difference(before, after):
    return ''.join(difflib.unified_diff(before.splitlines(True), after.splitlines(True), fromfile='saved graph', tofile='prepared graph')) or 'No graph statements changed.'


def save(root, pack, actor_id, proposal, *, confirmed=False, namespace_confirmed=False,
         allowed_packs=None, local_demo=False, can_write=False):
    try:
        if local_demo is not True or can_write is not True or confirmed is not True or namespace_confirmed is not True:
            raise ValueError('Saving needs an authorised local editing session and explicit confirmation of the namespace and exact export.')
        root, _product, pack, _actor, folder = _scope(root, pack, actor_id, allowed_packs)
        if not isinstance(proposal, dict) or (proposal.get('root'), proposal.get('pack'), proposal.get('actor_id')) != (str(root), pack, actor_id):
            raise ValueError('This preview belongs to another identity or product. Prepare it in the current context.')
        fresh = prepare(root, pack, actor_id, namespace=proposal['namespace'], expected_digest=proposal['input_digest'], allowed_packs=allowed_packs)
        if not fresh['ok']:
            return fresh
        if fresh['proposal'] != proposal:
            raise ValueError('The prepared export or validator result changed. Inspect a fresh preview before saving.')
        if proposal['validation'].get('state') != 'conforms':
            raise ValueError('SHACL must run and conform before an export version can be saved. Review the validator finding first.')
        identifier = science._hash({key: proposal[key] for key in ('pack', 'namespace', 'input_digest', 'graph_sha256', 'shapes_sha256')})[:24]
        destination = science._safe(folder / identifier)
        if destination.exists():
            existing = _load(folder, identifier, pack)
            return {'ok': True, 'changed': False, 'record': existing, 'errors': [], 'notice': NOTICE}
        for name in ('graph.jsonld', 'shapes.jsonld', 'manifest.json'):
            if os.name == 'nt' and len(str(destination / name)) > 235:
                raise ValueError('The checkout path is too long for this export bundle. Use a shorter checkout location.')
        record = {key: value for key, value in proposal.items() if key not in ('graph', 'shapes', 'actor_id', 'proposal_sha256', 'root')}
        record.update(id=identifier, saved_by=actor_id, created_at=datetime.now(timezone.utc).isoformat(),
                      path=(destination.relative_to(root)).as_posix(), projection='selected-product reviewed semantic projection',
                      namespace_owner_confirmed=True, published=False)
        record['manifest_sha256'] = science._hash(record)
        folder.mkdir(parents=True, exist_ok=True)
        temporary = Path(tempfile.mkdtemp(prefix='.export-', dir=folder))
        try:
            for name, raw in [('graph.jsonld', proposal['graph']), ('shapes.jsonld', proposal['shapes']), ('manifest.json', json.dumps(record, indent=2, ensure_ascii=False) + '\n')]:
                if len(raw.encode()) > MAX_BYTES:
                    raise ValueError('The export exceeds the supported review size.')
                (temporary / name).write_text(raw, encoding='utf-8', newline='\n')
            if _inputs(root, pack) != proposal['input_digest']:
                raise ValueError('Evidence changed before saving. No export was recorded; prepare the current evidence again.')
            os.rename(temporary, destination)
        finally:
            if temporary.exists():
                science._safe(temporary).relative_to(folder)
                shutil.rmtree(temporary)
        return {'ok': True, 'changed': True, 'record': record, 'errors': [], 'notice': NOTICE}
    except yaml.YAMLError:
        return _fail('A semantic dependency changed to malformed metadata. No export was saved; repair it before trying again.')
    except (ValueError, OSError, KeyError, TypeError, subprocess.TimeoutExpired) as error:
        return _fail(error)


def request_delivery(root, pack, actor_id, version_id, *, destination, note, confirmed=False,
                     allowed_packs=None, local_demo=False, can_write=False):
    try:
        if local_demo is not True or can_write is not True or confirmed is not True:
            raise ValueError('Requesting delivery needs an authorised local session and explicit confirmation.')
        result = read(root, pack, actor_id, version_id, allowed_packs=allowed_packs)
        if not result['ok'] or result['stale']:
            raise ValueError('Prepare and validate a current export before requesting delivery.')
        record = result['record']
        current = _run(Path(root).resolve(), pack, record['namespace'])
        if (not current.get('ok') or current.get('validation', {}).get('state') != 'conforms'
                or current.get('graph') != record['graph'] or current.get('shapes') != record['shapes']
                or _inputs(Path(root).resolve(), pack) != record['input_digest']):
            raise ValueError('The saved export no longer matches the current validated projection. Prepare and review a fresh version before requesting delivery.')
        destination = handoffs._text(destination, 'the destination or responsible graph service team')
        note = handoffs._text(note, 'what Engineering should check')
        if len(destination) > 500 or len(note) > 1800:
            raise ValueError('Keep the destination under 500 characters and the request under 1800 characters.')
        # A note is metadata, never a place to paste a credential or patient row.
        import scientific_definition_ai as ingress
        ingress._ingress(destination + '\n' + note)
        handoff = handoffs.create(root, pack, title='Review semantic export delivery', owner='Engineering', requested_by=actor_id,
            action_id='semantic-export:' + version_id + ':' + record['graph_sha256'],
            note=f"Destination supplied by requester: {destination}\n{note}\nExact export: {record['path']}/graph.jsonld\nGraph SHA256: {record['graph_sha256']}\nSHACL: conforms. No external delivery has occurred.",
            allowed_packs=allowed_packs, local_demo=local_demo, can_view=can_write)
        return {'ok': True, 'changed': True, 'handoff': handoff, 'errors': [], 'notice': NOTICE}
    except yaml.YAMLError:
        return _fail('A semantic dependency is malformed. Repair it and prepare a current export before requesting delivery.')
    except (ValueError, OSError, KeyError, TypeError, subprocess.TimeoutExpired, handoffs.Refused) as error:
        return _fail(error)


def recent(root, pack, actor_id, *, allowed_packs=None):
    # No saved versions means there is no export whose freshness needs checking.
    # Keep scoped path validation, but avoid snapshotting the entire codebase for
    # an empty Home queue. Existing versions still use the full current checks.
    try:
        _, _, _, _, folder = _scope(root, pack, actor_id, allowed_packs)
        if not folder.is_dir() or not any(re.fullmatch('[a-f0-9]{24}', path.name) and path.is_dir()
                                          for path in folder.iterdir()):
            return []
    except (ValueError, OSError, TypeError, KeyError, yaml.YAMLError, RecursionError):
        return []
    report = describe(root, pack, actor_id, allowed_packs=allowed_packs)
    return [{'id': row['id'], 'route': ROUTE, 'title': 'Semantic export ' + row['id'][:8],
             'state': 'Evidence changed' if row['input_digest'] != report['input_digest'] else 'Validated export files',
             'summary': 'Saved JSON-LD and SHACL for branch review; no external publication.',
             'params': {'version_id': row['id']}, 'updated_at': row['created_at']} for row in report.get('versions', [])]


def _project(root, pack, namespace, *, run_validation=True):
    import semantic_export as canonical
    import product_gates as gates
    import contract_lint as contract
    product = str(Path(root) / pack)
    graph, report = canonical.export(product, namespace, decision_pack_scope={pack})
    findings = []
    if report['exported']:
        if not (Path(product) / gates.CONTRACT_APPROVAL).is_file():
            findings.append('The current contract approval record is missing.')
        else:
            findings.extend(gates.contract_approval_errors(product, pack, {'contract': 'approved'}))
        lint, _count = contract.run(product)
        approved = [entry['variable_id'] for entry in canonical.rule_review.chain(product) if canonical._status_of(entry) == canonical.APPROVED]
        if any(any(error.startswith('[' + variable + ']') for variable in approved) for error in lint):
            findings.append('An approved contract row has canonical scientific-definition findings.')
    if findings:
        # Gate-owned checks decide whether authored meanings are current. Keep
        # structural nodes and separately governed inherited library concepts.
        removed = {'rwdp:Implementation', 'skos:Concept', 'rwdp:EquivalenceRuling', 'rwdp:Dataset', 'prov:Person'}
        graph['@graph'] = [node for node in graph['@graph'] if (
            'rwdp:adoptionDisposition' in node or not (
                set(node['@type'] if isinstance(node.get('@type'), list) else [node.get('@type')]) & removed
                or 'rwdp:specRow' in node))]
        report['withheld']['approval_or_definition_not_current'] = report['exported']
        report.update(exported=0, concepts=0, concepts_bound=0, variables_bound=0)
        report['note'] = 'Authored meanings were withheld because their current contract approval or scientific checks need attention. Inherited concepts retain their separate provenance.'
    report['nodes'] = len(graph['@graph'])
    report['structural_nodes'] = report['nodes'] - report['concepts']
    report['contract_findings'] = len(findings)
    report['scope_note'] = 'Only this product and equivalence decisions recorded for this product are included. Existing minted concept IRIs are reused; the supplied namespace is not a delivery endpoint.'
    if report.get('binding_withheld'):
        report['binding_withheld'] = ["The product's clinical binding is not current, approved and resolvable. Inspect clinical bindings for its canonical findings."]
    shapes = canonical.shapes(namespace)
    validation = (canonical.conformance(graph, shapes) if run_validation else
                  {'state': 'unchecked', 'why': 'Graph prepared for inspection; SHACL has not run for this snapshot.'})
    return {'ok': True, 'graph': canonical.serialize(graph), 'shapes': canonical.serialize(shapes), 'report': report, 'validation': validation}


if _REQUEST is not None:
    try:
        print(json.dumps(_project(_REQUEST['root'], _REQUEST['pack'], _REQUEST['namespace'],
                                  run_validation=_REQUEST.get('run_validation', True)), ensure_ascii=False))
    except BaseException:
        print(json.dumps({'ok': False}))
