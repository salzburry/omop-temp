"""Progress and recovery for existing long actions; no session-only run ownership."""
import streamlit as st
import portal_jobs as jobs


def render(root, actor_id, *, action, job_key, can_write=False, allowed_packs=None, key):
    try:
        rows = jobs.recent(root, actor_id, action=action, job_key=job_key, allowed_packs=allowed_packs)
    except (ValueError, OSError):
        st.warning("Saved action progress is unavailable for this author and checkout.")
        return
    if not rows:
        return
    current = rows[0]
    context = (str(root), actor_id, action, job_key, current["id"], bool(can_write),
               tuple(sorted(allowed_packs or [])))
    if st.session_state.get(key + "_context") != context:
        st.session_state[key + "_retry_confirm"] = False
        st.session_state[key + "_context"] = context
    display_status = "queued for a local heavy check" if current.get("resource_state") == "waiting" and current["status"] in {"queued", "running"} else current["status"]
    st.caption(jobs.ACTIONS[action] + " · " + display_status)
    st.write(current["progress"])
    if current["status"] in {"queued", "running"}:
        st.caption("You may leave this page or close Streamlit. Reopening this workflow resumes the progress view. A computer restart retains an interrupted record.")
        if st.button("Refresh action progress", key=key + "_refresh"):
            st.rerun()
        if st.button("Cancel this action", key=key + "_cancel", disabled=not can_write or current["cancel_requested"]):
            try:
                jobs.cancel(root, actor_id, current["id"], confirmed=True, can_write=can_write, allowed_packs=allowed_packs)
                st.rerun()
            except (ValueError, OSError):
                st.warning("This action changed or is unavailable. Refresh its current progress before cancelling.")
        return
    result = current.get("result")
    if len(rows) > 1:
        with st.expander("Previous attempts"):
            for row in rows[1:]:
                st.caption(row["created_at"][:19] + " · " + row["status"])
    if current["status"] in {"failed", "cancelled", "interrupted"}:
        st.warning("This attempt is not a successful completion. Review the workflow's saved state before retrying.")
        recovery = current.get("orphan_recovery") or {}
        if recovery.get("present"):
            st.warning("The worker ended, but its recorded subprocesses still hold the local heavy-check slot.")
            if not recovery.get("can_stop"):
                st.caption("Their original process identities cannot be verified. Preserve the records and ask your data expert to inspect the local processes.")
            elif st.button("Stop remaining processes for this action", key=key + "_stop_remaining", disabled=not can_write):
                try:
                    jobs.stop_interrupted_children(root, actor_id, current["id"], expected_digest=recovery["digest"],
                        confirmed=True, can_write=can_write, allowed_packs=allowed_packs)
                    st.rerun()
                except ValueError as error:
                    st.warning(str(error))
                except OSError:
                    st.warning("The remaining processes changed or could not be stopped safely. Refresh the current action.")
            return result
        guidance = jobs.retry_guidance(root, current)
        st.caption(guidance["reason"])
        if not guidance["allowed"]:
            return result
        reviewed = st.checkbox("I inspected the current workflow and want to retry this exact action.", key=key + "_retry_confirm")
        if st.button("Retry the inspected action", key=key + "_retry", disabled=not (reviewed and can_write)):
            try:
                jobs.start(root, actor_id, action=action, arguments=current["arguments"], job_key=job_key,
                    confirmed=True, can_write=can_write, allowed_packs=allowed_packs, retry=True)
                st.rerun()
            except (ValueError, OSError):
                st.warning("This action changed or is unavailable. Refresh and inspect the current workflow before retrying.")
    return result
