"""A specification row, its human interpretation, and a checked contract diff."""
from __future__ import annotations

import streamlit as st
from collections import Counter

import scientific_definitions as definitions
import scientific_definition_editor as editor

PREFIX = "scientific_definition_"
TEXT_FIELDS = editor.choices.TEXT_FIELDS


def clear():
    for key in list(st.session_state):
        if str(key).startswith(PREFIX):
            del st.session_state[key]


def _errors(result):
    import form_assistance
    form_assistance.record_validation(result.get("errors") or [], title="Scientific definition validation", action_id="g2_draft",
        input_digest=result.get("input_digest") or "")
    for error in result.get("errors", []):
        st.error(str(error))


def _queue_with_entries(queue, cache):
    """Overlay this session's unsaved work without treating a preview as saved."""
    rows = []
    for source in queue["rows"]:
        row = dict(source)
        cached = cache.get(row["item_id"])
        if cached:
            snapshot = cached["snapshot"]
            if (snapshot["input_digest"], snapshot["draft_digest"]) != (queue["input_digest"], row["draft_digest"]):
                row.update(work_status="Unresolved", work_reason="This open row used earlier inputs. Reload it and compare your entries before validation.")
            elif cached.get("entry_errors"):
                row.update(work_status="Unresolved", work_reason="Your unsaved entries need correction before validation.")
            elif not definitions.same_answers(cached["values"], snapshot["values"]):
                row.update(work_status="Draft", work_reason="You have unsaved edits in this session. Save the draft before leaving the application.")
        rows.append(row)
    return {**queue, "rows": rows, "counts": dict(Counter(row["work_status"] for row in rows))}


def _queue_controls(queue):
    counts = queue["counts"]
    st.caption(f"{counts.get('Checked', 0)} of {queue['total']} rows checked in the saved contract · "
               f"{counts.get('Untouched', 0)} untouched · {counts.get('Draft', 0)} drafts · "
               f"{counts.get('Unresolved', 0)} unresolved")
    st.caption("Checked means current record checks pass and answers are present. Scientific approval is a separate review.")
    def matches(row, selected_filter):
        return (selected_filter == "All rows" or
                selected_filter == "Needs work" and row["work_status"] != "Checked" or
                row["work_status"] == selected_filter)
    selected = st.session_state.get(PREFIX + "row")
    active = next((row for row in queue["rows"] if row["item_id"] == selected), None)
    current_filter = st.session_state.get(PREFIX + "queue_filter", "All rows")
    if (active and selected in st.session_state.get(PREFIX + "queue_visible", [])
            and st.session_state.get(PREFIX + "queue_last_filter") == current_filter
            and not matches(active, current_filter)):
        # Editing an Untouched/Checked row changes its status immediately. Keep
        # the active editor available to save; an explicit filter change still
        # takes effect normally and never restores a hidden row on its own.
        st.session_state[PREFIX + "queue_filter"] = "All rows"
        st.info("This row's progress changed. Showing all rows so you can finish and save your current entries.")
    left, right = st.columns([2, 1])
    with left:
        selected_filter = st.selectbox("Show definition rows", ["All rows", "Needs work", "Untouched", "Draft", "Unresolved", "Checked"],
                                      key=PREFIX + "queue_filter", help="Drafts include your saved drafts and unsaved session edits. Unresolved rows need a source, question or validator finding reviewed.")
    all_ids = [row["item_id"] for row in queue["rows"]]
    position = all_ids.index(selected) + 1 if selected in all_ids else 0
    ordered = queue["rows"][position:] + queue["rows"][:position]
    next_row = next((row["item_id"] for row in ordered if row["work_status"] != "Checked" and row["item_id"] != selected), None)
    def advance():
        st.session_state[PREFIX + "row"] = next_row
        st.session_state[PREFIX + "queue_filter"] = "Needs work"
    with right:
        st.button("Next unfinished row", key=PREFIX + "next_row", on_click=advance, disabled=next_row is None,
                  help="Your current entries stay in this session. Save an unfinished draft before closing or restarting the app.")
    rows = [row for row in queue["rows"] if matches(row, selected_filter)]
    st.session_state[PREFIX + "queue_last_filter"] = selected_filter
    st.session_state[PREFIX + "queue_visible"] = [row["item_id"] for row in rows]
    if not queue["rows"]:
        st.info("No named specification rows are available to define. Review the extraction and any unnamed scientific questions.")
    elif counts.get("Checked", 0) == queue["total"]:
        st.info("All named rows pass their current record checks. Check again to see the remaining scientific review and workflow requirements.")
    elif not rows:
        st.info("No rows match this filter. Choose All rows to continue; your entries are kept in this session.")
    return rows


def _render_name_reviews(reviews):
    if not reviews:
        return
    pending = any(not row["resolved"] for row in reviews)
    with st.expander("Compare meanings behind reused names", expanded=pending):
        if pending:
            st.warning("This output name has different recorded scientific definitions. You can save the draft; its naming review must be resolved before configuration approval.")
        for row in reviews:
            st.write("**" + row["physical_name"] + "**")
            st.caption(row["question"])
            st.dataframe([{"Scientific field": item["field"].replace("_", " "),
                           "This proposed definition": item["current"],
                           "Existing definition": item["peer"]}
                          for item in row["differences"]], hide_index=True, width="stretch")
            if row["resolved"]:
                st.caption("Existing review basis: " + str((row.get("resolution") or {}).get("basis", "recorded definition review")))
        if pending:
            st.info("For different concepts, return to Output and choose a distinct physical name. For intentional reuse, compare the definitions in the science workbench and complete their registered definition and equivalence review with the data expert. A spelling match alone cannot settle it.")


def render(root, pack, actor_id, *, local_demo, can_write, can_view, can_review=False, naming_packs=None, initial_item_id=None):
    if not can_view:
        clear()
        st.info("You need access to this product to read its scientific definitions.")
        return False
    context = (str(root), pack, actor_id, bool(local_demo), bool(can_write), bool(can_review),
               None if naming_packs is None else tuple(sorted(naming_packs)))
    previous_context = st.session_state.get(PREFIX + "context")
    if st.session_state.get(PREFIX + "context") != context:
        clear()
        st.session_state[PREFIX + "context"] = context
        if previous_context is not None:
            # Discard submit events created under the former actor/permissions.
            st.rerun()
    import specification_sheet_mapping_page
    if specification_sheet_mapping_page.render(root, pack, actor_id, local_demo=local_demo,
            can_write=can_write, can_view=can_view, allowed_packs=naming_packs if naming_packs is not None else [pack],
            action_id="g2_refresh_extraction"):
        return True
    if initial_item_id and st.session_state.get(PREFIX + "incoming_row") != initial_item_id:
        st.session_state[PREFIX + "row"] = initial_item_id
        st.session_state[PREFIX + "incoming_row"] = initial_item_id
        st.session_state[PREFIX + "queue_filter"] = "All rows"
    editor.retain_fields()
    # Cache by source row, including its original validation snapshot. Returning
    # to a row must not silently bless changed source material or lose typing.
    old = st.session_state.get(PREFIX + "snapshot")
    if old:
        cache = st.session_state.setdefault(PREFIX + "row_cache", {})
        values, entry_errors = editor.collect(old["values"])
        cache[old["selected"]["item_id"]] = {
            "snapshot": old,
            "fields": {k: st.session_state[k] for k in st.session_state if str(k).startswith(PREFIX + "field_") and not str(k).endswith("_edit")},
            "section": st.session_state.get(PREFIX + "section", editor.SECTIONS[0]),
            "values": values, "entry_errors": entry_errors,
        }
    queue = definitions.work_queue(root, pack, actor_id, allowed_packs=[pack])
    if not queue["ok"]:
        _errors(queue)
        st.info("Prepare this product's extraction and functional-contract file first, then reopen the definition editor.")
        return False
    queue = _queue_with_entries(queue, st.session_state.get(PREFIX + "row_cache", {}))
    visible = _queue_controls(queue)
    if not visible:
        import connected_workflow_page
        connected_workflow_page.select_context(pack, actor_id, item_id=None, variable=None)
        return False
    rows = {row["item_id"]: row for row in visible}
    if st.session_state.get(PREFIX + "row") not in rows:
        previous_row = st.session_state.get(PREFIX + "row")
        if previous_row and previous_row not in {row["item_id"] for row in queue["rows"]}:
            st.warning("The previously selected row is no longer in the extraction. Choose a current row; its source must be reviewed again.")
        st.session_state[PREFIX + "row"] = visible[0]["item_id"]
    selected_id = st.session_state.get(PREFIX + "row")
    current = definitions.describe(root, pack, actor_id, item_id=selected_id, allowed_packs=[pack])
    if not current["ok"] and selected_id and any("Choose a named requirement" in e for e in current["errors"]):
        current = definitions.describe(root, pack, actor_id, allowed_packs=[pack])
        if current["ok"]:
            st.session_state[PREFIX + "row"] = current["selected"]["item_id"]
            st.warning("The previously selected row is no longer in the extraction. Choose a current row; its source must be reviewed again.")
    if not current["ok"]:
        _errors(current)
        st.info("Prepare this product's extraction and functional-contract file first, then reopen the definition editor.")
        return False
    st.write("**Write the definition here**")
    count = current["contract_count"]
    st.caption(f"{count} definition record{'s' if count != 1 else ''} in the functional contract · You are editing a draft.")
    if count == 0:
        st.info("The functional contract has no definition rows yet. Start with one row and two short answers below.")
    chosen = st.selectbox("Specification row to define", list(rows), key=PREFIX + "row",
                          format_func=lambda ref: f"{rows[ref]['work_status']} · {rows[ref]['variable_id']} · {ref}",
                          help="Choose the original requirement you are interpreting. Illustrative example: ECOG · clinical:2 identifies the ECOG row and its source citation.")
    st.caption(rows[chosen]["work_reason"])
    st.caption("Choose one requirement to interpret. Study-only exclusions remain in Plan changes.")
    import connected_workflow_page
    connected_workflow_page.select_context(pack, actor_id, item_id=chosen, variable=rows[chosen]["variable_id"])
    connected_workflow_page.links(("definition_reuse", "variable_lineage", "review_workbook"), pack, actor_id,
        key="definition_context", params={"item_id": chosen, "variable": rows[chosen]["variable_id"]},
        label="Compare existing definitions and review evidence")
    if chosen != current["selected"]["item_id"]:
        current = definitions.describe(root, pack, actor_id, item_id=chosen, allowed_packs=[pack])
    if not current["ok"]:
        _errors(current)
        return False
    fresh = current
    loaded = st.session_state.get(PREFIX + "snapshot")
    if loaded is None or loaded["selected"]["item_id"] != chosen:
        cached = st.session_state.get(PREFIX + "row_cache", {}).get(chosen) if loaded else None
        for key in list(st.session_state):
            if str(key).startswith(PREFIX + "field_"):
                del st.session_state[key]
        if cached:
            st.session_state.update(cached["fields"])
        st.session_state[PREFIX + "section"] = cached["section"] if cached else st.session_state.get(PREFIX + "section", editor.SECTIONS[0]) if loaded is None else editor.SECTIONS[0]
        st.session_state[PREFIX + "snapshot"] = cached["snapshot"] if cached else fresh
        restored = st.session_state[PREFIX + "snapshot"]
        st.session_state[PREFIX + "loaded"] = (chosen, restored["input_digest"], restored["draft_digest"])
        st.session_state.pop(PREFIX + "preview", None)
        st.session_state.pop(PREFIX + "confirm", None)
        if loaded:
            st.session_state.pop(PREFIX + "feedback", None)
    current = st.session_state[PREFIX + "snapshot"]
    if (fresh["input_digest"], fresh["draft_digest"]) != (current["input_digest"], current["draft_digest"]):
        if st.button("Reload current row and keep my entries", key=PREFIX + "reload"):
            st.session_state[PREFIX + "snapshot"] = fresh
            st.session_state[PREFIX + "loaded"] = (chosen, fresh["input_digest"], fresh["draft_digest"])
            st.session_state.pop(PREFIX + "preview", None)
            st.session_state.pop(PREFIX + "confirm", None)
            # Render the existing field widgets in this same run. An early
            # rerun would trigger widget cleanup before the form was reached,
            # dropping the very unsaved entries this action promises to keep.
            current = fresh
            st.success("Current row reloaded and your entries kept. Compare the source, then validate the revised definition again.")
        else:
            st.warning("The product or saved row changed while this editor was open. Your entries remain in the form. Reload the current row and compare the source before validating; an old preview cannot be saved.")
    token = (chosen, current["input_digest"], current["draft_digest"])
    if st.session_state.get(PREFIX + "loaded") != token:
        for key in list(st.session_state):
            if str(key).startswith(PREFIX + "field_"):
                del st.session_state[key]
        st.session_state[PREFIX + "loaded"] = token
        st.session_state.pop(PREFIX + "preview", None)
        st.session_state.pop(PREFIX + "confirm", None)
    selected, defaults = current["selected"], current["values"]
    # Place repair beside the row, but execute its controls after the field
    # widgets below. A source-status rerun must retain unsaved field entries.
    source_review_slot = st.container() if current.get("ai_help_blocker") else None
    st.write("**What the specification says**")
    st.text(selected["definition"])
    editor.source_context(selected)
    st.caption("Quoted source information is read-only. Your interpretation stays separate.")
    if current["saved"]:
        st.caption("Your saved row draft is loaded.")
    if current["stale_draft"]:
        st.warning("The extraction changed after this draft was saved. Compare your interpretation with the current specification above before validating it.")
    feedback = st.session_state.get(PREFIX + "feedback")
    if feedback:
        st.success(feedback)
    permitted = local_demo and can_write
    def edit_section(index):
        st.session_state[PREFIX + "section"] = editor.SECTIONS[index]
        st.session_state[PREFIX + "edit_fields"] = True
    edit_logic, edit_settings = st.columns(2)
    edit_logic.button("Edit definition logic", key=PREFIX + "edit_logic", disabled=not permitted,
                      on_click=edit_section, args=(0,))
    edit_settings.button("Edit this product's values", key=PREFIX + "edit_values", disabled=not permitted,
                         on_click=edit_section, args=(3,))
    import scientific_definition_ai as row_ai
    import scientific_definition_ai_page
    from contextlib import nullcontext
    working, working_errors = editor.collect(defaults)
    connection = row_ai.describe_availability(root, pack, actor_id, chosen, allowed_packs=[pack])
    chat_mode = bool(permitted and connection.get("ok") and connection.get("configured") and connection.get("source_eligible"))
    if chat_mode and not working_errors:
        if scientific_definition_ai_page.render(root, pack, actor_id, {**current, "values": working},
                local_demo=local_demo, can_write=can_write, allowed_packs=[pack], chat=True):
            st.session_state[PREFIX + "feedback"] = "Proposed wording saved in your unfinished draft. Continue the conversation or validate the definition below."
            st.session_state.pop(PREFIX + "snapshot", None)
            st.session_state.pop(PREFIX + "preview", None)
            st.session_state.pop(PREFIX + "confirm", None)
            st.session_state.get(PREFIX + "row_cache", {}).pop(chosen, None)
            st.rerun()
    with (st.expander("Review details and edit fields", expanded=bool(st.session_state.get(PREFIX + "edit_fields"))) if chat_mode else nullcontext()):
        section = editor.render_fields(root, pack, actor_id, selected, defaults, TEXT_FIELDS,
                                       permitted=permitted, naming_packs=naming_packs if naming_packs is not None else [pack])
    if chat_mode:
        section = len(editor.SECTIONS) - 1
    values, entry_errors = editor.collect(defaults)
    current_answer_digest = editor.digest(values)
    if (st.session_state.get(PREFIX + "preview") and
            (st.session_state.get(PREFIX + "preview_answers") != current_answer_digest or entry_errors)):
        st.session_state.pop(PREFIX + "preview", None)
        st.session_state.pop(PREFIX + "confirm", None)
        st.info("Your answers changed. Validate again in Review to see an up-to-date diff.")
    for error in entry_errors:
        st.error(error)
    if entry_errors:
        import form_assistance
        form_assistance.record_validation(entry_errors, title="Scientific definition validation", action_id="g2_draft")
    if not chat_mode:
        with st.expander("Ask AI to help with this row"):
            if entry_errors:
                st.info("Correct the source-column entries above before requesting suggestions so all your current answers can be preserved.")
            else:
                import scientific_definition_ai_page
                if scientific_definition_ai_page.render(root, pack, actor_id, {**current, "values": values},
                        local_demo=local_demo, can_write=can_write, allowed_packs=[pack]):
                    st.session_state[PREFIX + "feedback"] = "Selected AI suggestions saved in your unfinished draft. Review the answers below, then complete the remaining sections and validate in Review."
                    st.session_state.pop(PREFIX + "snapshot", None)
                    st.session_state.pop(PREFIX + "preview", None)
                    st.session_state.pop(PREFIX + "confirm", None)
                    st.session_state.get(PREFIX + "row_cache", {}).pop(chosen, None)
                    st.rerun()
    save = st.button("Save unfinished row draft", key=PREFIX + "save", disabled=not permitted or bool(entry_errors))
    validate = False
    if section == len(editor.SECTIONS) - 1:
        validate = st.button("Validate and preview contract change", key=PREFIX + "validate", type="primary",
                             disabled=not permitted or bool(entry_errors))
    else:
        def next_section():
            st.session_state[PREFIX + "section"] = editor.SECTIONS[section + 1]
        st.button("Continue to " + editor.SECTIONS[section + 1].split(" · ", 1)[1],
                  key=PREFIX + "continue", type="primary", on_click=next_section)
    if save and permitted:
        st.session_state.pop(PREFIX + "preview", None)
        st.session_state.pop(PREFIX + "confirm", None)
        result = definitions.save_draft(root, pack, actor_id, chosen, values, expected_input_digest=current["input_digest"],
                                        expected_draft_digest=current["draft_digest"], local_demo=local_demo, can_write=can_write, allowed_packs=[pack])
        if result["ok"]:
            st.session_state[PREFIX + "feedback"] = "Row draft saved. Next, complete the remaining sections, then validate in Review. The functional contract is unchanged."
            st.session_state.pop(PREFIX + "snapshot", None)
            st.session_state.get(PREFIX + "row_cache", {}).pop(chosen, None)
            st.rerun()
        _errors(result)
        if result.get("stale_lock"):
            st.session_state[PREFIX + "stale_lock"] = "draft"
    if validate and permitted:
        st.session_state.pop(PREFIX + "confirm", None)
        with st.spinner("Checking the proposed record with the existing contract validator…"):
            result = definitions.preview(root, pack, actor_id, chosen, values, expected_input_digest=current["input_digest"],
                                         allowed_packs=[pack], naming_packs=naming_packs)
        st.session_state[PREFIX + "preview"] = result
        st.session_state[PREFIX + "preview_answers"] = current_answer_digest
    candidate = st.session_state.get(PREFIX + "preview")
    if candidate and section == len(editor.SECTIONS) - 1:
        _render_name_reviews(candidate.get("name_reviews") or [])
        if candidate.get("errors"):
            st.error("Some answers need attention. Use the section selector above to correct them, then validate again.")
            with st.expander("Validator findings: fields and details", expanded=True):
                _errors(candidate)
        if candidate.get("folded_fields"):
            # The contract row is one line (DL-12): a person who wrote a list on several lines
            # should see that the breaks will not survive, before they confirm the diff.
            names = [TEXT_FIELDS[field][0] if field in TEXT_FIELDS else field for field in candidate["folded_fields"]]
            st.info("Line breaks become spaces in the contract. Affected: " + ", ".join(names) + ". Use semicolons if the parts must stay separate.")
        if candidate.get("diff"):
            st.write("**Before and after**")
            st.code(candidate["diff"], language="diff")
        if candidate.get("reopened"):
            st.warning("This changes an existing requirement. Its prior evidence statuses will be reopened for review by the existing contract rules.")
        if candidate.get("pack_findings"):
            with st.expander("Other product requirements still open"):
                for finding in candidate["pack_findings"]:
                    st.text(finding)
        if candidate.get("passed"):
            st.success("The proposed row passed the existing record checks. Review the diff before saving it to the contract.")
            confirmed = st.checkbox("I reviewed this row diff and want to save it as a draft definition.", key=PREFIX + "confirm")
            if st.button("Save checked definition to contract", key=PREFIX + "apply", disabled=not (confirmed and permitted), type="primary"):
                result = definitions.apply(root, pack, actor_id, candidate["item_id"], candidate["values"],
                                           expected_input_digest=candidate["input_digest"], expected_manifest_digest=candidate["manifest_digest"],
                                           confirmed=confirmed, local_demo=local_demo, can_write=can_write,
                                           allowed_packs=[pack], naming_packs=naming_packs)
                if result["ok"] and result.get("changed"):
                    st.session_state[PREFIX + "feedback"] = "Draft definition saved to the functional contract. Next, define the remaining rows, resolve the scientific questions, then complete the scientific review. Check again refreshes the workflow requirements; this save is not approval or release."
                    st.session_state.pop(PREFIX + "preview", None)
                    st.session_state.pop(PREFIX + "snapshot", None)
                    st.session_state.get(PREFIX + "row_cache", {}).pop(chosen, None)
                    st.success(st.session_state[PREFIX + "feedback"])
                    return True
                _errors(result)
                if result.get("stale_lock"):
                    st.session_state[PREFIX + "stale_lock"] = "contract"
        else:
            st.info("The row has not been written to the contract. Correct the findings above, or save the unfinished row draft and continue it with the responsible reviewer.")
    if st.session_state.get(PREFIX + "stale_lock"):
        # A lock older than ten minutes was met (DL-06). Only that one file is removed, on the
        # person's click; a recent lock is another save and is left alone.
        which = st.session_state[PREFIX + "stale_lock"]
        st.warning("An earlier save left its lock behind. If nobody else is saving this row, clear it and save again.")
        if st.button("Clear the stale lock", key=PREFIX + "clear_lock", disabled=not permitted):
            cleared = definitions.clear_stale_lock(root, pack, actor_id, item_id=chosen if which == "draft" else None,
                                                   local_demo=local_demo, can_write=can_write, allowed_packs=[pack])
            st.session_state.pop(PREFIX + "stale_lock", None)
            if cleared["ok"]:
                st.success("The stale lock was cleared. Save again.")
            _errors(cleared)
    if current["apply_blocker"] and section == len(editor.SECTIONS) - 1:
        st.warning("Before a definition can be added to the contract, the program specification needs its recorded review. You can save unfinished row drafts while that review is pending.")
        with st.expander("Specification review requirement"):
            st.text(current["apply_blocker"])
    # The AI-access review governs AI help only. A person can still draft and save a definition
    # while it is pending; the expander is where a reviewer records it when they choose to.
    if source_review_slot is not None:
        with source_review_slot:
            st.info("AI help needs the current extracted source's access review. Review it here, or continue writing and saving an unfinished definition.")
            with st.expander("Resolve extracted-source access review"):
                import scientific_definition_source_page
                if scientific_definition_source_page.render(root, pack, actor_id=actor_id, local_demo=local_demo, can_write=can_write,
                                                              can_review=can_review, allowed_packs=[pack]):
                    refreshed = definitions.describe(root, pack, actor_id, item_id=chosen, allowed_packs=[pack])
                    if refreshed["ok"]:
                        st.session_state[PREFIX + "snapshot"] = refreshed
                        st.session_state[PREFIX + "loaded"] = (chosen, refreshed["input_digest"], refreshed["draft_digest"])
                    else:
                        st.session_state.pop(PREFIX + "snapshot", None)
                    st.session_state.pop(PREFIX + "preview", None)
                    st.session_state.pop(PREFIX + "confirm", None)
                    st.rerun()
    st.caption("Saving drafts does not approve or release this product. After checked rows are saved, Check again shows the remaining scientific review work.")
    return False
