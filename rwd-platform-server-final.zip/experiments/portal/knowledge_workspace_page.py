"""One knowledge worklist, with typed evidence and the existing next action."""
from pathlib import Path
import json

import streamlit as st

import knowledge_workspace as backend

PREFIX = "knowledge_ws_"


def _issues(result):
    for error in result.get("errors", []):
        st.error(error)
    return not result.get("ok")


def _relationships(item):
    links = item["links"]
    if not links:
        st.caption("No consumer relationship is declared in this view. This is not evidence that the item has no impact.")
        return
    st.markdown("**Declared relationships**")
    st.dataframe(links, hide_index=True, width="stretch")
    with st.expander("View these relationships as a graph"):
        quote = lambda value: json.dumps(str(value))
        lines = ["digraph evidence { rankdir=LR; node [shape=box];", "subject [label=" + quote(item["title"]) + "];"]
        for index, link in enumerate(links[:12]):
            lines += [f"n{index} [label=" + quote(link["target"] + "\n" + link["source"]) + "];",
                      f"subject -> n{index} [label=" + quote(link["relation"]) + "];"]
        st.graphviz_chart("\n".join([*lines, "}"]))
        st.caption("Edges reproduce the declared relationship labels; they do not establish clinical equivalence. The graph shows up to 12 relationships; the table shows all returned links.")


def render(root, pack, actor_id, *, allowed_packs, local_demo=False, can_write=False,
           can_review=False, route="knowledge_explorer", params=None):
    params = params or {}
    context = (str(Path(root).resolve()), pack, actor_id, tuple(sorted(allowed_packs)))
    if st.session_state.get(PREFIX + "context") != context:
        for key in list(st.session_state):
            if str(key).startswith(PREFIX):
                del st.session_state[key]
        st.session_state[PREFIX + "context"] = context
    incoming = json.dumps(params, sort_keys=True, default=str)
    if st.session_state.get(PREFIX + "incoming") != incoming:
        st.session_state[PREFIX + "incoming"] = incoming
        st.session_state[PREFIX + "view"] = "definitions" if params.get("variable") or params.get("query") else "semantic"
    view = st.radio("Knowledge view", ("semantic", "definitions"), horizontal=True, key=PREFIX + "view",
        format_func=lambda value: "Semantic sources and graph" if value == "semantic" else "Definitions and evidence")
    if view == "semantic":
        import semantic_knowledge_page
        return semantic_knowledge_page.render(root, pack, actor_id, allowed_packs=allowed_packs)
    st.write("Find an existing definition, output name, decision or clinical concept, read what supports it, then continue in the workflow that owns it.")
    st.caption(backend.NOTICE)
    with st.form(PREFIX + "search_form"):
        query = st.text_input("Name or phrase", value=str(params.get("variable") or params.get("query") or ""),
                              key=PREFIX + "query", placeholder="For example ECOG, follow-up or missing dates")
        kind = st.selectbox("Knowledge type", ["all", *backend.KINDS], key=PREFIX + "kind",
                            format_func=lambda value: "All knowledge types" if value == "all" else backend.KINDS[value])
        refresh = st.form_submit_button("Search and refresh knowledge", key=PREFIX + "search")
    if refresh or PREFIX + "report" not in st.session_state:
        with st.spinner("Reading the accessible knowledge and its declared evidence…"):
            result = backend.describe(root, pack, actor_id, allowed_packs=allowed_packs, query=query, kind=kind)
        st.session_state[PREFIX + "report"] = result
        st.session_state.pop(PREFIX + "selected", None)
    report = st.session_state[PREFIX + "report"]
    if _issues(report):
        return None
    current = backend.freshness(root, pack, actor_id, expected_digest=report["input_digest"], allowed_packs=allowed_packs)
    stale = _issues(current) or current.get("stale", True)
    if stale:
        st.warning("The knowledge or product access changed since this search. Search and refresh before continuing from an item.")
    st.caption(f"{report['total']} matching item(s) across {len(report['scope'])} accessible product cut(s), plus shared reference declarations.")
    if report["truncated"]:
        st.info(f"Showing the first {backend.MAX_ITEMS} items. Choose a knowledge type or a more specific phrase to narrow the list.")
    if report["search_needed"]:
        st.caption("Browsing shows definitions, names, decisions and clinical template concepts. Enter a phrase to include matching implementation capabilities, reference inventory and citation provenance.")
    if report["problems"]:
        with st.expander("Evidence that needs attention", expanded=not bool(report["items"])):
            for problem in report["problems"]:
                st.write("**" + problem["surface"] + "**")
                st.write(problem["finding"])
            st.caption("Unreadable or invalid search surfaces are reported here; missing evidence does not become a positive result.")
    items = {item["id"]: item for item in report["items"]}
    if not items:
        st.info("No accessible item matches this search. Try a shorter literal name or browse a knowledge type. A missing match does not establish that two concepts differ.")
        return None
    chosen = st.selectbox("Knowledge item to inspect", list(items), index=None, key=PREFIX + "selected",
                          format_func=lambda identifier: backend.KINDS[items[identifier]["kind"]] + " · "
                          + items[identifier]["title"][:120] + ("…" if len(items[identifier]["title"]) > 120 else "")
                          + " · " + items[identifier]["source"])
    if not chosen:
        st.info("Choose one item to see its evidence, declared relationships and available next step.")
        return None
    item = items[chosen]
    st.markdown("**" + (item["details"]["id"] if item["kind"] == "decision" else item["title"]) + "**")
    st.caption(backend.KINDS[item["kind"]] + " · " + item["source"])
    st.write("Recorded evidence state: " + item["state"])
    st.write(item["summary"])
    if item["citations"]:
        with st.expander("Source citations", expanded=True):
            for citation in item["citations"]:
                st.text(str(citation))
    else:
        st.caption("No source citation is supplied for this item in the returned metadata.")
    _relationships(item)
    with st.expander("Read the recorded definition and evidence", expanded=True):
        if item["kind"] == "definition":
            record = item["details"]
            st.text("Specification: " + record["spec"]["rule"])
            st.dataframe([{"Question": label, "Recorded answer": answer or "Not recorded"}
                          for label, answer in record["interpreted"]], hide_index=True, width="stretch")
            if record["unresolved"]:
                st.warning("Unresolved implementation references: " + ", ".join(record["unresolved"]))
            st.caption("Recorded status: " + record["status"])
        elif item["kind"] == "decision":
            record = item["details"]
            st.write("**Recorded question**")
            st.write(record["question"])
            st.write("**Supporting evidence**")
            st.write(record["evidence"] or "No supporting evidence recorded.")
            st.write("**Recorded answer**")
            st.write(record["answer"] or "No answer recorded.")
        elif item["kind"] == "name":
            prior = item["details"]["prior_definitions"]
            if not prior:
                st.info("This is a configured name with no accessible scientific definition. Its meaning still needs review.")
            for record in prior:
                st.write("**" + record["variable"] + " · " + record["pack"] + "**")
                st.write(record["rule"] or "No interpretation recorded.")
                st.caption("Source rows: " + (", ".join(record["spec_refs"]) or "not recorded"))
        elif item["kind"] == "clinical_concept":
            record = item["details"]
            st.write("Template position (slot): " + record["slot"])
            st.write("Cancer context: " + record["cancer"])
            st.caption("A reusable position and its cancer-specific meaning are distinct. Review the existing template relation before adopting it.")
        else:
            st.write(item["details"].get("detail") or "Read the cited reference and its recorded evidence state.")
        with st.expander("Exact registry metadata"):
            st.json(item["details"])
    if item["actions"]:
        st.markdown("**Continue with this evidence**")
        for index, action in enumerate(item["actions"]):
            if st.button(action["label"], key=PREFIX + "action_" + str(index), disabled=stale):
                return {key: value for key, value in action.items() if key != "label"}
        st.caption("The next workspace checks its own source, access and review prerequisites. This explorer saves no judgments or approvals.")
    else:
        st.info("This is supporting reference evidence. Record the interpretation against the current scientific requirement before it can be reused or implemented.")
    return None
