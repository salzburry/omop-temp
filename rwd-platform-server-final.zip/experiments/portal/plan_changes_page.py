"""Choose one change, then continue through the product's existing workflow."""
from __future__ import annotations

import json
import streamlit as st

import design_workspace as workspace
import configuration_proposals
import configuration_proposal_page
import connected_workflow_page as navigation
import form_assistance as form_help


INTENTS = {
    "definition": "Write or revise a scientific definition",
    "configuration": "Change a supported product setting",
    "study": "Change how one study uses the product",
    "revision": "Propose a larger product or source revision",
}


def render(root, pack, *, actor_id, local_demo, can_write, allowed_packs, params=None):
    params = params or {}
    context = (str(root), pack, actor_id, bool(local_demo), bool(can_write), tuple(sorted(allowed_packs)))
    if st.session_state.get("plan_guide_context") != context:
        for key in list(st.session_state):
            if str(key).startswith("plan_guide_"):
                del st.session_state[key]
        st.session_state["plan_guide_context"] = context
    for key in list(st.session_state):
        if str(key).startswith(f"design_{pack}_"):
            st.session_state[key] = st.session_state[key]
    try:
        workspace._pack_path(root, pack, allowed_packs)
        description = workspace.describe(root, pack)
    except (ValueError, OSError) as exc:
        st.error(str(exc))
        return
    if description["errors"]:
        for error in description["errors"]:
            st.error(error)
        return
    requested_intent = params.get("intent")
    if requested_intent in INTENTS and st.session_state.get("plan_guide_requested_intent") != requested_intent:
        st.session_state["plan_guide_intent"] = requested_intent
        st.session_state["plan_guide_requested_intent"] = requested_intent
    if params.get("proposal_id") and st.session_state.get("plan_guide_incoming") != params["proposal_id"]:
        st.session_state["plan_guide_intent"] = "configuration"
        st.session_state["plan_guide_incoming"] = params["proposal_id"]
    elif params.get("draft_id") and st.session_state.get("plan_guide_incoming") != params["draft_id"]:
        st.session_state["plan_guide_intent"] = "revision"
        st.session_state["plan_guide_incoming"] = params["draft_id"]
    st.title("Plan changes")
    st.write("Choose what you want to change. We’ll take you through the relevant draft, impact review and checks.")
    st.caption("Saving a proposal requests review. Approval and release remain separate workflow requirements.")
    configuration_proposal_page.render_shared(root, pack, actor_id, local_demo=local_demo, can_write=can_write,
                                              allowed_packs=allowed_packs, key="plan")
    preselect_delivery = False
    if params.get("reason"):
        st.warning(str(params["reason"]))
        st.write("Use Declare the source delivery to enter the delivered tables, source schema and delivery cut together. "
                 "The source schema and cut are also settings you can stage below for review. "
                 "The download preserves any unsupported mapping request for the data expert.")
        if st.button("Declare the source delivery", key="plan_guide_source_delivery", type="primary"):
            navigation.open_route("source_delivery", pack, actor_id)
        handoff = {"pack": pack, "baseline_sha256": description["baseline_sha256"],
                   "state": "engineering_review_required", "scope": "shared_product_delivery_configuration",
                   "requested_work": str(params["reason"]), "current_source": description["source"],
                   "current_source_tables": description.get("source_tables", {}),
                   "target": f"{pack}/config/data_product.yaml", "next_route": "source_delivery",
                   "notice": "Review the proposed configuration diff and run its existing validators before using this delivery. This request is not approval or a release."}
        st.download_button("Download delivery setup handoff", json.dumps(handoff, indent=2),
                           file_name="delivery-configuration-handoff.json", mime="application/json", key="plan_guide_delivery_handoff")
        if st.button("Plan another supported change", key="plan_guide_other_change"):
            navigation.open_route("plan_changes", pack, actor_id, params={"intent": "configuration"})
        # the delivery settings are chosen for the person once per request; the selection stays theirs to change
        if st.session_state.get("plan_guide_delivery_reason") != str(params["reason"]):
            st.session_state["plan_guide_delivery_reason"] = str(params["reason"])
            st.session_state["plan_guide_intent"] = "configuration"
            preselect_delivery = True
    else:
        st.session_state.pop("plan_guide_delivery_reason", None)
    if not description["rows"]:
        st.info("This product has no scientific definitions yet. Start by interpreting a specification row; its source text and field examples are supplied in the definition editor.")
    if "plan_guide_intent" not in st.session_state:
        st.session_state["plan_guide_intent"] = st.session_state.get("plan_guide_saved_intent", "definition")
    intent = st.radio("What would you like to change?", list(INTENTS), format_func=INTENTS.get, key="plan_guide_intent")
    # Unlike widget state, this context-scoped value survives visiting another workflow page.
    st.session_state["plan_guide_saved_intent"] = intent
    if intent == "definition":
        st.write("Read the source requirement, compare existing definitions and standard names, then enter your interpretation. You can save unfinished work and validate a before-and-after contract change here.")
        if st.button("Open the guided definition editor", key="plan_guide_define", type="primary"):
            navigation.open_route("scientific_draft", pack, actor_id)
        navigation.links(("definition_reuse", "review_workbook"), pack, actor_id, key="plan_definitions",
                         label="Use existing definitions or a returned review")
        return
    if intent == "study":
        st.write("A study exclusion or different interpretation belongs with that study's product pin. Choose the study, review its protocol and record its own decisions there.")
        if st.button("Open study choices", key="plan_guide_study", type="primary"):
            st.session_state.pop(navigation.KEY, None)
            st.session_state["section_suggested"] = "Studies"
            st.rerun()
        navigation.links(("study_protocol", "study_refresh"), pack, actor_id, key="plan_study",
                         label="Review the protocol or refresh a saved product choice")
        return
    if intent == "revision":
        st.caption("Use this for adding or removing shared definitions or proposing a different source. Unsupported derivations remain an engineering handoff with your exact requested rule.")
        import design_page
        design_page.render(root, pack, actor_id=actor_id, local_demo=local_demo, can_write=can_write,
                           allowed_packs=allowed_packs, show_intro=False, initial_draft=params.get("draft_id"),
                           initial_version=params.get("version"))
        return
    try:
        supported = configuration_proposals.supported_parameters(root, pack)
    except (OSError, ValueError) as exc:
        st.error(f"Supported configuration settings could not be read: {exc}")
        return
    if not supported:
        st.info(configuration_proposals.NO_SUPPORTED_SETTINGS
                + " Describe other product settings in a larger revision for the data expert's review.")
        return
    st.write("1. Describe the reason. 2. Select only the settings you need. 3. Stage the diff, run the validators and submit the checked proposal for review.")
    prefix = f"design_{pack}_"
    if preselect_delivery:
        delivery = [ref for ref in supported if ref.rsplit("#/", 1)[-1] in ("run/source_schema", "run/refresh")]
        if delivery:
            st.session_state[prefix + "proposal_selected_settings"] = delivery
    draft_binding = (pack, description["baseline_sha256"])
    purpose = form_help.field(st.text_area, "Why does this setting need to change?", key=prefix + "purpose", binding=draft_binding,
        placeholder="Example: propose a 90-day minimum follow-up for the named outcomes study; confirm the rule with its scientific owner.")
    studies = form_help.field(st.text_area, "Affected studies (one per line, if known)", key=prefix + "studies", binding=draft_binding)
    baseline_key = "plan_guide_baseline"
    st.session_state.setdefault(baseline_key, description["baseline_sha256"])
    changed = st.session_state[baseline_key] != description["baseline_sha256"]
    if changed:
        st.warning("The product changed while this proposal was open. Review its current settings before staging.")
        if st.button("Reload the current product settings", key="plan_guide_reload"):
            for key in list(st.session_state):
                if str(key).startswith(prefix + "proposal_"):
                    del st.session_state[key]
            st.session_state[baseline_key] = description["baseline_sha256"]
            st.rerun()
    current = description["source"]
    brief = workspace.build_plan(description, [r["variable_id"] for r in description["rows"]], [], purpose,
        [s.strip() for s in studies.splitlines() if s.strip()], current.get("vendor"), current.get("modality"))
    configuration_proposal_page.render(root, pack, brief, expected_baseline=st.session_state[baseline_key],
        baseline_changed=changed, actor_id=actor_id, local_demo=local_demo, can_write=can_write,
        allowed_packs=allowed_packs, guided=True, initial_proposal_id=params.get("proposal_id"))
    # WHERE A SUBMITTED PROPOSAL GOES (2026-09-07): the author follows the reviewer's decision, and
    # the later apply and validate acts, on the same Review requests page the reviewer uses.
    navigation.links(("review_inbox",), pack, actor_id, key="plan_review", label="Follow the review of submitted changes")
