"""Read the shared variable library as unapproved drafting candidates.

Only master declarations and reusable-logic supplements enter this view. Tumour
overlays and example parameter values remain outside the reusable payload.
"""
from __future__ import annotations

from pathlib import Path
from copy import deepcopy
from functools import lru_cache

import yaml

from variable_review_requirements import field_path

INVENTORY = "governance/reference/variable_inventory/INVENTORY.yaml"
SUPPLEMENT = "governance/reference/variable_inventory/REUSABLE_LOGIC.yaml"
CUSTOM = "governance/reference/variable_inventory/CUSTOM_LOGIC.yaml"
MAX_BYTES = 16 * 1024 * 1024
REVIEW_LABELS = ("Applicable population", "Source table and field", "Anchor date", "Window",
                 "Which records qualify", "Precedence and tie-breaking", "Missing / no-record behaviour", "Resulting output")


def _read(root, relative, key):
    path = root / relative
    if not path.exists():
        return []
    if path.resolve() != path or not path.is_file():
        raise ValueError("The master variable library redirects outside its declared file.")
    raw = path.read_bytes()
    if len(raw) > MAX_BYTES:
        raise ValueError("The master variable library exceeds its metadata limit.")
    return deepcopy(_rows(raw, key))


@lru_cache(maxsize=8)
def _rows(raw, key):
    # Files are still read and checked on each call. Parsing unchanged shared
    # reference bytes should not delay every page/phase switch.
    try:
        doc = yaml.load(raw, Loader=getattr(yaml, "CSafeLoader", yaml.SafeLoader))
    except (yaml.YAMLError, UnicodeError) as error:
        raise ValueError("The master variable library could not be read as YAML.") from error
    if not isinstance(doc, dict) or not isinstance(doc.get(key), list):
        raise ValueError(f"The master variable library needs a {key} list.")
    seen = set()
    for row in doc[key]:
        if not isinstance(row, dict) or not isinstance(row.get("name"), str) or not row["name"].strip():
            raise ValueError("Every master variable needs a declared name.")
        name = row["name"].strip().casefold()
        if name in seen:
            raise ValueError("A master variable name occurs more than once in a library source.")
        seen.add(name)
    return doc[key]


def _strings(value):
    if isinstance(value, str):
        value = [value]
    if not isinstance(value, list):
        return []
    return list(dict.fromkeys(item.strip() for item in value if isinstance(item, str) and item.strip()))


def _slots(value):
    """Descriptions and explicit requirements; never example/default answers."""
    rows = []
    if isinstance(value, dict):
        rows = [{**item, "name": name} if isinstance(item, dict) else {"name": name, "description": item}
                for name, item in value.items()]
    elif isinstance(value, list):
        rows = value
    result = []
    for row in rows:
        if not isinstance(row, dict) or not isinstance(row.get("name"), str) or not row["name"].strip():
            continue
        slot = {"name": row["name"].strip(), "description": str(row.get("description") or "")}
        path = field_path(row.get("field") or row.get("path"))
        if path:
            slot["field"] = path
        if type(row.get("required")) is bool:
            slot["required"] = row["required"]
        result.append(slot)
    return result


_SLOT_FIELDS = {"convention": "anchor", "bands": "output.codes", "line_rules": "record_selection",
                "window": "window", "baseline_window": "window", "baseline_window_days": "window",
                "lookback_window": "window", "lookback_days": "window"}
_CHOICE_FIELDS = {"derivation", "anchor", "window", "record_selection", "tie_break", "missing",
                  "units", "cohort_applicability", "source.value", "output.type", "output.codes"}


def _reference_options(slots, source_path):
    """Expose declared alternatives for explicit comparison; never as copy defaults."""
    rows = ([{"name": name, **value} for name, value in slots.items() if isinstance(value, dict)]
            if isinstance(slots, dict) else slots if isinstance(slots, list) else [])
    result = []
    for slot in rows:
        if not isinstance(slot, dict):
            continue
        name = str(slot.get("name") or "")
        path = slot.get("field") or slot.get("path") or _SLOT_FIELDS.get(name)
        if path not in _CHOICE_FIELDS:
            continue
        examples = slot.get("example_values")
        if isinstance(examples, dict):
            for variant, value in examples.items():
                if value is not None:
                    result.append({"path": path, "value": deepcopy(value), "variant": str(variant),
                                   "source_path": source_path, "label": name, "illustrative": True})
        if "default_value" in slot and slot["default_value"] is not None:
            result.append({"path": path, "value": deepcopy(slot["default_value"]), "variant": "Declared master value",
                           "source_path": source_path, "label": name, "illustrative": False})
    return result


def candidates(root, variable=None):
    """All masters, ranked by exact name then explicit alias; rank is not equivalence."""
    root = Path(root).resolve()
    inventory = _read(root, INVENTORY, "master")
    supplement = _read(root, SUPPLEMENT, "templates")
    custom = _read(root, CUSTOM, "templates")
    combined = {entry["name"].strip().casefold(): {"inventory": entry} for entry in inventory}
    for entry in supplement:
        combined.setdefault(entry["name"].strip().casefold(), {})["supplement"] = entry
    for entry in custom:
        key = entry["name"].strip().casefold()
        if key in combined:
            raise ValueError("A new library definition duplicates an existing master name. Give it a distinct name before reusing it.")
        combined[key] = {"supplement": entry, "custom": True}
    wanted = str(variable or "").strip().casefold()
    result = []
    for sources in combined.values():
        base, extra = sources.get("inventory", {}), sources.get("supplement", {})
        name = str(extra.get("name") or base["name"]).strip()
        definition = str(extra.get("definition") or base.get("definition_sketch") or "").strip()
        explicit_logic = str(extra.get("logic") or "").strip()
        derivation = explicit_logic or definition
        extra_path = CUSTOM if sources.get("custom") else SUPPLEMENT
        source_path = extra_path if extra else INVENTORY
        source_paths = [relative for relative, source in ((INVENTORY, base), (extra_path, extra)) if source]
        evidence = list(dict.fromkeys([*_strings(base.get("citations")), *_strings(extra.get("evidence"))]))
        aliases = list(dict.fromkeys([*_strings(base.get("aliases")), *_strings(extra.get("aliases"))]))
        match = "exact" if wanted and name.casefold() == wanted else "alias" if wanted and wanted in {alias.casefold() for alias in aliases} else "none"
        slots = _slots(extra["parameter_slots"] if "parameter_slots" in extra else base.get("parameter_slots"))
        result.append({
            "key": "master:" + name, "source_kind": "master", "source_path": source_path,
            "source_paths": source_paths, "display_name": str(extra.get("label") or name),
            "variable_id": name, "pack": "Master variable library", "status": "draft" if sources.get("custom") else "library template", "settled": False,
            "caveat": "New library draft; review applicability for this product." if sources.get("custom") else "Library template; review applicability for this product.",
            "match_kind": match, "match": {"exact": "exact name", "alias": "declared alias", "none": "library browsing"}[match],
            "aliases": aliases, "category": str(extra.get("category") or base.get("category") or ""),
            "data_type": str(extra.get("data_type") or base.get("data_type") or ""),
            "declared_source_kind": str(extra.get("source_kind") or base.get("source_kind") or ""),
            "spec_refs": evidence, "decisions": [], "derivation": derivation, "parameter_slots": slots,
            "reference_options": _reference_options(base.get("parameter_slots"), INVENTORY) + _reference_options(extra.get("parameter_slots"), extra_path),
            "record": {"variable_id": name, "spec": {"refs": list(evidence), "rule": definition, "digest": ""},
                       "derivation": derivation, "interpreted": [(label, "") for label in REVIEW_LABELS],
                       "executable": [], "unresolved": [], "status": "", "decisions": []},
        })
    return sorted(result, key=lambda item: ({"exact": 0, "alias": 1, "none": 2}[item["match_kind"]], item["variable_id"].casefold()))
