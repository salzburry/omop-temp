"""Development profile confirmation and production reviewer identity setup."""
from __future__ import annotations

import streamlit as st

import reviewer_link
import signing_command_page


ROLES = {"approved_by": "Specification review", "classified_by": "Permission to use AI"}
STATES = {"setup_required": "Setup needed", "registered_unverified": "Review not yet verified",
          "authenticated": "Identity verified for this review"}


def _valid(description):
    if not isinstance(description, dict):
        return False
    people, errors, links = (description.get(key) for key in ("reviewers", "errors", "links"))
    if not isinstance(people, list) or not isinstance(errors, list) or not all(isinstance(error, str) for error in errors):
        return False
    if not isinstance(description.get("current_actor"), dict) or not isinstance(description.get("handoff"), str):
        return False
    if not isinstance(links, list) or not all(isinstance(link, dict) and isinstance(link.get("path"), str)
                                           and isinstance(link.get("label"), str) for link in links):
        return False
    for person in people:
        if not isinstance(person, dict) or not all(isinstance(person.get(key), str) for key in ("name", "display_name")):
            return False
        if person.get("status") not in STATES or not isinstance(person.get("fields"), list):
            return False
        if not all(isinstance(field, str) for field in person["fields"]):
            return False
        if not all(isinstance(person.get(key), bool) for key in ("key_registered", "authenticated")):
            return False
        if person["authenticated"] != (person["status"] == "authenticated"):
            return False
        if person["key_registered"] != (person["status"] != "setup_required"):
            return False
    return True


def render(root, pack, actor_id, *, local_demo, can_view, can_manage_users=False, show_reference=None, can_review=False, actor_name="", actor_email=""):
    """Read current evidence on each render; a request is downloaded, never sent."""
    if not can_view:
        st.info("You do not have access to this product's reviewer details.")
        return
    if local_demo:
        signing_command_page.render(root, pack, "source", actor_id, local_demo=True,
                                    can_review=can_review, can_view=can_view, actor_name=actor_name, actor_email=actor_email)
        return
    try:
        description = reviewer_link.describe(root, pack, actor_id, local_demo)
    except Exception:
        description = None
    if not _valid(description):
        st.warning("Reviewer details could not be checked. Check again below; if it continues, ask your administrator to check reviewer access.")
        return

    people, errors = description["reviewers"], description["errors"]
    verified = bool(people and not errors and all(person["authenticated"] and person["key_registered"] for person in people))
    setup = bool(not people or errors or any(not person["key_registered"] for person in people))
    if errors:
        st.subheader("Reviewer setup needs attention")
        st.write("The reviewer details could not be fully verified. Download the administrator request below so the setup can be checked.")
    elif not people:
        st.subheader("Choose the person responsible for review")
        st.write("The product owner needs to name the people responsible for the specification review and permission to use AI.")
    elif setup:
        st.subheader("Set up the reviewer's signing key")
        st.write("The reviewer's name is saved. Their personal signing key needs to be registered before they can sign. "
                 "Download the administrator request below to arrange setup.")
        st.caption("This key is the reviewer's personal credential. Recording files in history is a separate step; "
                   "clearing a temporary file lock does not set up a signing key.")
    elif verified:
        st.subheader("Reviewer identity verified")
        st.success("The current review has verified identity evidence. Check again below to see the next product requirement.")
    elif any(person.get("signature_verified") for person in people):
        st.subheader("Independent reviewer identity evidence is required")
        st.write(description["summary"])
    else:
        st.subheader("Ask the reviewer to confirm this version")
        st.write("Reviewer setup is available. The decision for this product version still needs the reviewer's verified confirmation.")

    for person in people:
        with st.container(border=True):
            state = "Verification unavailable" if errors else STATES[person["status"]]
            if not errors and person.get("signature_verified") and not person["authenticated"]:
                state = "Key signature verified; identity evidence missing"
            # Names in source files are literal data, not Markdown or links.
            st.text(f"{person['display_name']}: {state}")
            st.caption(" · ".join(ROLES.get(field, "Source review") for field in person["fields"]))
    st.caption("Choosing a name in this local demo does not sign in as that person." if local_demo
               else "Signing in to the portal does not, by itself, verify a scientific review.")

    signing_available = not verified and not errors and any(person["key_registered"] for person in people)
    if signing_available:
        signing_command_page.render(root, pack, "source", actor_id, local_demo=local_demo,
                                    can_review=can_review, can_view=can_view, actor_name=actor_name)
    if not verified:
        label = "Download administrator request" if setup else "Download reviewer request"
        filename = "reviewer-setup-request.txt" if setup else "review-verification-request.txt"
        st.download_button(label, description["handoff"], file_name=filename, mime="text/plain",
                           key="reviewer_link_request", type="secondary" if signing_available and local_demo and can_review else "primary")
        st.caption("This downloads a request for you to share. It does not send a message or approve the product.")

    if can_manage_users:
        with st.expander("Administrator setup and verification"):
            st.write("Manage users controls portal access. The review command uses an existing registered key to record a local signature; it cannot create keys, enrol identities or authenticate a person. Private keys stay on the reviewer's computer. Independent enrolment and review identity still require an authenticated review service.")
            st.text(description["handoff"])
            if show_reference:
                for index, link in enumerate(description["links"]):
                    show_reference(link["path"], key=f"reviewer_link_reference_{index}", label=link["label"], inline=True)
