"""A lazy, reviewable handoff from the output table to engine configuration."""
from __future__ import annotations

import hashlib

import streamlit as st

import variable_execution_bridge as bridge


PREFIX = "variable_review_execution_"
STATUS = {"supported": "Supported by existing code",
          "needs_output_binding": "Choose an engine output", "engineering": "Implementation needed"}


def _errors(result):
    for error in result.get("errors") or ["The settings could not be prepared. Reload the preview and try again."]:
        st.error(str(error))


def _snapshot(plan):
    return {"expected_input_digest": plan["input_digest"], "expected_state_digest": plan["state_digest"],
            "expected_plan_digest": plan["plan_digest"]}


def render(root, pack, actor_id, *, local_demo=False, can_write=False, allowed_packs=None):
    identity = hashlib.sha256(repr((str(root), pack, actor_id, allowed_packs)).encode()).hexdigest()[:16]
    prefix = PREFIX + identity
    panel = st.expander("Prepare executable settings", key=prefix + "_open", on_change="rerun")
    if not panel.open:
        return None
    with panel:
        st.caption("Turn reviewed product values and treatment-line choices into a configuration proposal.")
        plan = bridge.describe(root, pack, actor_id, allowed_packs=allowed_packs)
        if not plan.get("ok"):
            _errors(plan)
            if st.button("Open configuration editor", key=prefix + "_repair"):
                return {"route": "plan_changes", "params": {"intent": "configuration"}}
            return None
        snapshot_key = prefix + "_displayed_plan"
        if st.session_state.get(snapshot_key) not in (None, plan["plan_digest"]):
            st.info("The reviewed table or configuration changed. Check this refreshed proposal before continuing.")
        st.session_state[snapshot_key] = plan["plan_digest"]
        action_key = prefix + "_" + plan["plan_digest"]
        permitted = bool(local_demo and can_write)
        rows = plan.get("rows") or []
        if rows:
            st.dataframe([{"Variable": row["variable_id"], "Engine field": row.get("engine_column") or "—",
                           "Next step": STATUS.get(row["status"], row["status"]),
                           "Details": row.get("message", "")} for row in rows], hide_index=True, width="stretch")
        for warning in plan.get("warnings") or []:
            st.warning(str(warning))
        bindings = {row["item_id"]: row for row in rows if row["status"] == "needs_output_binding"}
        if bindings:
            selected = st.selectbox("Resolve an output name", list(bindings),
                format_func=lambda item: f"{bindings[item]['variable_id']} → {bindings[item]['engine_column']}",
                key=prefix + "_binding_" + plan["plan_digest"][:16])
            row = bindings[selected]
            st.caption("Choose the field the engine produces. The requested published name stays in the review table; a custom physical rename still needs implementation.")
            if st.button("Use engine field " + row["engine_column"], key=action_key + "_use_output_" + selected, disabled=not permitted):
                result = bridge.use_engine_output(root, pack, actor_id, selected, **_snapshot(plan),
                    confirmed=True, local_demo=local_demo, can_write=can_write, allowed_packs=allowed_packs)
                if not result.get("ok"):
                    _errors(result)
                else:
                    st.session_state["variable_review_notice"] = f"Saved {row['variable_id']} with engine field {row['engine_column']}. Review and confirm the updated output table."
                    st.session_state.setdefault("flow_result", {}).pop(pack, None)
                    st.rerun()
        blockers = plan.get("blockers") or []
        if blockers:
            st.warning("Some variables still need work. Staging supported settings keeps these items open for review.")
            st.dataframe([{"Variable": item.get("variable_id") or "Product setting", "What needs resolving": item["message"]}
                          for item in blockers], hide_index=True, width="stretch")
            review_rows = {row["item_id"]: row for row in rows if row["status"] != "supported"}
            if review_rows:
                selected = st.selectbox("Variable to revisit", list(review_rows),
                    format_func=lambda item: review_rows[item]["variable_id"], key=prefix + "_revisit")
                phase = st.selectbox("Review to open", ("science", "source", "output"),
                    format_func=lambda value: {"science": "Scientific definition", "source": "Source mapping", "output": "Output fields"}[value],
                    key=prefix + "_phase")
                if st.button("Edit this variable", key=prefix + "_edit"):
                    return {"route": "variable_review", "params": {"phase": phase, "item_id": selected}}
        if plan.get("settings"):
            st.write("**Proposed settings**")
            st.dataframe([{"Setting": item["label"], "Current": str(item["current"]), "Proposed": str(item["proposed"])}
                          for item in plan["settings"]], hide_index=True, width="stretch")
        if plan.get("files"):
            with st.expander("Exact configuration changes"):
                for item in plan["files"]:
                    st.caption(item["path"])
                    st.code(item["diff"], language="diff")
        else:
            st.info("Supported settings already match the current configuration." if any(row["status"] == "supported" for row in rows)
                    else "No supported configuration changes are available from these definitions yet.")
        if plan.get("files") or blockers:
            if not plan["review_confirmed"]:
                st.info("Confirm the scientific, source and output tables before preparing this proposal.")
            st.caption("Stage the proposal to run its checks and continue through configuration review. The proposal also retains the unresolved items listed above." if plan.get("files")
                       else "Prepare these reviewed requirements as an implementation handoff, then open the proposal to request engineering work.")
            label = "Stage supported settings" if plan.get("files") else "Prepare implementation handoff"
            if st.button(label, key=action_key + "_stage", type="primary",
                         disabled=not (permitted and plan["can_stage"])):
                result = bridge.stage(root, pack, actor_id, **_snapshot(plan), confirmed=True,
                    local_demo=local_demo, can_write=can_write, allowed_packs=allowed_packs)
                if result.get("ok"):
                    return {"route": "plan_changes", "params": {"proposal_id": result["proposal_id"]}, "changed": True}
                _errors(result)
        if not plan.get("files"):
            if st.button("Open configuration checks", key=prefix + "_checks"):
                return {"route": "plan_changes", "params": {"intent": "configuration"}}
    return None
