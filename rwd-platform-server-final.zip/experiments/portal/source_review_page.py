"""Human source-review and AI-access forms, without YAML or signing shortcuts."""
from pathlib import Path

import streamlit as st

import source_review as review
import specification_details as details
import form_assistance as form_help

LABELS = {"document_id": "Document ID", "revision": "Document revision", "data_refresh": "Data refresh or delivery",
          "rwb_qc_reference": "Specification QC reference", "approved_by": "Scientific reviewer's name",
          "approval_date": "Scientific review date", "classified_by": "Access classifier's name", "classified_date": "Classification date"}
CLASSES = {"sponsor_ai_eligible": "Sponsor AI may read this material", "vendor_restricted": "Vendor material: AI access restricted",
           "restricted_derived": "Derived material: AI access restricted"}


def clear():
    for key in list(st.session_state):
        if str(key).startswith("source_review_"):
            st.session_state.pop(key, None)


def _remember(field, mode):
    drafts = dict(st.session_state.get("source_review_drafts") or {})
    drafts[field] = st.session_state.get("source_review_" + field, "")
    st.session_state["source_review_drafts"] = drafts
    st.session_state["source_review_confirm_" + mode] = False


def render(root, pack, actor_id, *, local_demo, can_review, can_view, initial_mode="review"):
    """Return True after saving intentional fields; never supplies an actor or date."""
    if not can_view:
        clear()
        st.warning("You no longer have access to this product's source review.")
        return False
    context = (str(Path(root).resolve()), pack, actor_id)
    saved_metadata = False
    cached = st.session_state.get("source_review_snapshot")
    context_changed = isinstance(cached, dict) and cached.get("context") != context
    if not isinstance(cached, dict) or cached.get("context") != context:
        clear()
        description = review.describe(root, pack, allowed_packs=[pack])
        st.session_state["source_review_snapshot"] = {"context": context, "description": description}
    else:
        description = cached["description"]
    st.write("**Review the program specification**")
    if not description.get("ok"):
        for error in description.get("errors") or ["The source review could not be read."]:
            st.warning(str(error))
        if st.button("Reload source review", key="source_review_reload"):
            clear()
            st.rerun()
        return False
    st.caption("Record the decision you actually made about this specification. Names and dates are entered by the reviewer.")
    st.text("Registered specification: " + description["source"]["path"])
    st.caption("Recorded review status: " + description["status"])
    if not description["source"]["ready"]:
        st.warning(description["source"]["problem"])
    enabled = local_demo is True and can_review is True and not context_changed
    if not enabled:
        if local_demo is True and can_review is not True:
            st.info("The scientific review is recorded by the reviewer of this specification, not by the person who started the product. "
                    "In this local demo, choose the reviewer under Working as in the sidebar, or ask your reviewer to open this step.")
        else:
            st.info("Saving a source decision requires reviewer access in a local session.")
    st.session_state.setdefault("source_review_section", "AI access" if initial_mode == "access" else "Scientific review")
    section = st.radio("Decision to record", ["Scientific review", "AI access"], horizontal=True, key="source_review_section")
    mode = "review" if section == "Scientific review" else "access"
    drafts = st.session_state.get("source_review_drafts") or {}
    for field in review.FIELDS:
        key = "source_review_" + field
        if key in st.session_state:
            st.session_state[key] = st.session_state[key]
        elif field in drafts:
            st.session_state[key] = drafts[field]
        else:
            st.session_state[key] = description["values"].get(field, "")
    if mode == "review":
        if not description["values"].get("document_id"):
            if st.button("Generate and save document ID", key="source_review_generate_id", disabled=not enabled):
                metadata = details.describe(root, pack, allowed_packs=[pack])
                result = details.save(root, pack, {"document_id": details.suggest_document_id(metadata)},
                                      expected_digest=description["digest"], local_demo=local_demo,
                                      can_write=can_review and can_view, allowed_packs=[pack])
                if result.get("ok"):
                    description = review.describe(root, pack, allowed_packs=[pack])
                    st.session_state["source_review_snapshot"] = {"context": context, "description": description}
                    st.session_state["source_review_document_id"] = description["values"]["document_id"]
                    cached_drafts = dict(st.session_state.get("source_review_drafts") or {})
                    cached_drafts["document_id"] = description["values"]["document_id"]
                    st.session_state["source_review_drafts"] = cached_drafts
                    st.success("Document ID saved. Your other entries are retained; the review decision is unchanged.")
                    saved_metadata = bool(result.get("changed"))
                else:
                    for error in result.get("errors") or ["The document ID could not be saved."]:
                        st.error(str(error))
        left, right = st.columns(2)
        for index, field in enumerate(review.REVIEW_FIELDS):
            with (left if index % 2 == 0 else right):
                kwargs = dict(key="source_review_" + field, disabled=not enabled,
                              placeholder="YYYY-MM-DD" if field.endswith("date") else None,
                              on_change=_remember, args=(field, mode))
                if field in review.METADATA:
                    form_help.field(st.text_input, LABELS[field], binding=description["digest"], **kwargs)
                else:
                    st.text_input(LABELS[field], **kwargs)
        missing_access = [field for field in review.ACCESS_FIELDS if field in description["missing_fields"]]
        if missing_access:
            st.info("An AI access decision is needed before the scientific review can be recorded. Choose AI access above to enter it.")
        with st.expander("Keep incomplete details for later"):
            form_help.field(st.text_area, "Why the specification is still pending", key="source_review_why_provisional", disabled=not enabled, binding=description["digest"],
                         on_change=_remember, args=("why_provisional", mode))
            st.caption("Save known document details and this explanation. Reviewer names, review dates and the current review status are preserved.")
            if st.button("Save document details", key="source_review_save_draft", disabled=not enabled):
                updates = {field: str(st.session_state.get("source_review_" + field, "")) for field in review.DRAFT_FIELDS}
                result = review.save(root, pack, updates, expected_digest=description["digest"], mode="draft",
                                     local_demo=local_demo, can_review=can_review and can_view, allowed_packs=[pack])
                if result.get("ok"):
                    st.session_state["source_review_snapshot"] = {"context": context, "description": result}
                    st.success("Document details saved. The scientific review decision was preserved.")
                    return bool(result.get("changed"))
                for error in result.get("errors") or ["The details could not be saved."]:
                    st.error(str(error))
        st.checkbox("I reviewed this specification and confirm the scientific decision and reviewer details above.",
                    key="source_review_confirm_review", disabled=not enabled)
        label = "Record scientific review"
    else:
        # THIS FORM EDITS THE WORKBOOK ONLY (2026-09-07): a check that reported the extracted
        # specification's TODOs used to open this form, whose decision was already recorded, and
        # every save reported success while the extraction's TODOs stayed. Say so when the workbook
        # has nothing left to record here, so a cached session cannot loop on it.
        if not any(field in description["missing_fields"] for field in review.ACCESS_FIELDS):
            st.info("The workbook's AI access decision is already recorded. If the check names the extracted specification, "
                    "record that decision in the extracted source form from Progress and next step instead; saving here changes only the workbook's record.")
        selected = st.session_state.get("source_review_ai_classification")
        if selected not in CLASSES:
            st.session_state["source_review_ai_classification"] = None
        st.selectbox("What may AI read?", list(CLASSES), index=None, format_func=lambda value: CLASSES.get(value, value),
                     key="source_review_ai_classification", disabled=not enabled, on_change=_remember, args=("ai_classification", mode))
        left, right = st.columns(2)
        with left:
            st.text_input(LABELS["classified_by"], key="source_review_classified_by", disabled=not enabled,
                          on_change=_remember, args=("classified_by", mode))
        with right:
            st.text_input(LABELS["classified_date"], key="source_review_classified_date", placeholder="YYYY-MM-DD", disabled=not enabled,
                          on_change=_remember, args=("classified_date", mode))
        st.checkbox("I assessed this material's access restrictions and confirm the classification and classifier details above.",
                    key="source_review_confirm_access", disabled=not enabled)
        label = "Record AI access decision"
    st.caption(review.NOTICE)
    if st.button(label, key="source_review_save", type="primary", disabled=not enabled):
        fields = review.REVIEW_FIELDS if mode == "review" else review.ACCESS_FIELDS
        updates = {field: str(st.session_state.get("source_review_" + field) or "") for field in fields}
        result = review.save(root, pack, updates, expected_digest=description["digest"], mode=mode,
                             confirmed=st.session_state.get("source_review_confirm_" + mode, False),
                             local_demo=local_demo, can_review=can_review and can_view, allowed_packs=[pack])
        if result.get("ok"):
            st.session_state["source_review_snapshot"] = {"context": context, "description": result}
            for warning in result.get("warnings") or []:
                st.warning(warning)
            if result.get("changed"):
                st.success("Decision recorded. The named reviewer still needs to authenticate the current record.")
                return True
            st.info("This decision is already recorded. Its identity verification and source history are checked separately in Progress and next step.")
        else:
            for error in result.get("errors") or ["The decision could not be saved."]:
                st.error(str(error))
    if st.button("Reload saved source review", key="source_review_reload", help="Discard unsaved entries and read the latest source record."):
        clear()
        st.rerun()
    return saved_metadata
