"""Continue a checked rehearsal to an isolated, explicitly synthetic ADS build."""
from __future__ import annotations

import os
from pathlib import Path
import sys
import time

import demo_journey as journeys
import demo_revisions
import portal_runtime


def checked_summary(summary, expected):
    """Bind successful output to the configuration actually requested."""
    fields = ("pack", "source_mode", "science_digest", "committed_delivery_digest", "effective_run_bindings")
    if not isinstance(summary, dict) or any(summary.get(key) != expected.get(key) for key in fields):
        raise ValueError("The synthetic build summary does not match this example and configuration. No build success is recorded.")
    result = summary.get("gate5")
    if (not isinstance(result, dict) or type(result.get("rows")) is not int or result["rows"] < 0
            or type(result.get("columns")) is not int or result["columns"] < 1
            or not isinstance(result.get("column_list"), list)
            or not all(isinstance(value, str) and value for value in result["column_list"])
            or len(result["column_list"]) != result["columns"]
            or len(set(result["column_list"])) != result["columns"]):
        raise ValueError("The synthetic build did not return readable row and column counts. No build success is recorded.")
    return result


def validate_saved(root, folder, record):
    """A displayed build remains tied to the saved inputs and exact output."""
    product = demo_revisions._tracked_inputs(folder, record)
    if journeys._read(journeys._canonical(folder / "plan.json", folder)) != record["plan"]:
        raise ValueError("The saved plan changed. Its earlier synthetic build is no longer current.")
    sys.path.insert(0, str(Path(root) / "platform/tools"))
    import product_gates
    from spec_extract import repo_relative
    artifact = journeys._canonical(folder / "synthetic-build.json", folder)
    if record["report"].get("build_artifact_sha256") not in (None, journeys._sha(artifact)):
        raise ValueError("The saved synthetic build output changed. Its earlier success is no longer current.")
    expected = {"pack": repo_relative(str(product), str(root)), "source_mode": "synthetic",
        "science_digest": product_gates.config_bundle_sha256(str(product)),
        "committed_delivery_digest": product_gates.delivery_sha256(str(product)),
        "effective_run_bindings": {"refresh": "synthetic", "source_schema": "synthetic", "output_schema": "synthetic"}}
    summary = checked_summary(journeys._read(artifact), expected)
    if summary != record["report"].get("build_summary"):
        raise ValueError("The saved synthetic build summary changed. Its earlier success is no longer current.")


def build(root, state_root, actor_id, run_id, *, local_demo=False, can_write=False):
    """Preserve completed draft checks even when the optional build fails."""
    if local_demo is not True or can_write is not True:
        return journeys._error("A product author can build this synthetic example in a local demo session.")
    loaded = journeys.read_run(root, state_root, actor_id, run_id)
    if not loaded["ok"]:
        return loaded
    record = loaded["run"]
    if record["stage"] != "complete":
        return journeys._error("Run the rehearsal checks first, then build its synthetic ADS here.")
    if record["report"].get("synthetic_ads") == "built":
        return loaded
    runtime = journeys.runtime()
    if not runtime["build_available"]:
        return journeys._error(runtime["build_reason"])
    folder = journeys._folder(root, state_root, actor_id, run_id)
    lock = folder / ".running"
    handle = None
    attempt = None
    try:
        # Same lock as draft execution and revision. Allow enough time for the
        # longest supported local build before recovering an interrupted run.
        if lock.exists() and time.time() - lock.stat().st_mtime > 2400:
            journeys._canonical(lock, folder).unlink()
        try:
            handle = os.open(lock, os.O_CREAT | os.O_EXCL | os.O_WRONLY)
        except FileExistsError:
            raise ValueError("This rehearsal is already running or being edited. Wait for it to finish before building.") from None
        # A different session may have completed a build after the first read.
        # Read again under the shared lock before changing attempt history.
        loaded = journeys.read_run(root, state_root, actor_id, run_id)
        if not loaded["ok"]:
            return loaded
        record = loaded["run"]
        if record["stage"] != "complete":
            raise ValueError("The rehearsal changed. Finish its current checks before building.")
        if record["report"].get("synthetic_ads") == "built":
            return loaded
        product = demo_revisions._tracked_inputs(folder, record)
        if journeys._read(journeys._canonical(folder / "plan.json", folder)) != record["plan"]:
            raise ValueError("The saved plan changed. Reopen an unchanged rehearsal before building.")
        sys.path.insert(0, str(Path(root) / "platform/tools"))
        import local_smoke
        expected = local_smoke.binding(str(product))
        output = journeys._canonical(folder / "synthetic-build.json", folder)
        # A failed retry cannot reuse an older success file.
        output.unlink(missing_ok=True)
        timeout = min(1800, portal_runtime.timeout("RWD_PORTAL_BUILD_TIMEOUT_S", 1800))
        attempt = {"started_at": journeys._now(), "status": "running", "source_mode": "synthetic"}
        record["build_attempts"] = [*record.get("build_attempts", [])[-19:], attempt]
        journeys._json(folder / "rehearsal.json", record)
        result = portal_runtime.run([sys.executable, str(Path(root) / "platform/tools/local_smoke.py"),
            str(product), "--evidence-out", str(output)], cwd=str(root), timeout_s=timeout, kill_tree=True)
        attempt.update(exit_code=result.returncode, output=((result.stdout or "") + (result.stderr or ""))[-60000:])
        if result.returncode:
            raise ValueError("The synthetic ADS build needs attention. Your completed draft checks and plan are retained. Read the build details, then retry here or share them with your data expert.")
        demo_revisions._tracked_inputs(folder, record)
        summary = checked_summary(journeys._read(journeys._canonical(output, folder)), expected)
        attempt.update(status="complete", finished_at=journeys._now())
        record["report"].update(synthetic_ads="built", build_summary=summary,
            build_artifact_sha256=journeys._sha(output),
            build_scope="Saved example configuration on synthetic inputs; proposed changes remain unapplied.")
        journeys._json(folder / "qc-report.json", record["report"])
        journeys._json(folder / "rehearsal.json", record)
        return {"ok": True, "run": record, "errors": []}
    except (OSError, ValueError, TypeError, KeyError) as error:
        if attempt is not None:
            attempt.update(status="needs_attention", error=str(error), finished_at=journeys._now())
            journeys._json(folder / "rehearsal.json", record)
        return {"ok": False, "run": record, "errors": [str(error)]}
    finally:
        if handle is not None:
            os.close(handle)
            lock.unlink(missing_ok=True)
