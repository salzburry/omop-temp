"""Plain-language Flow guidance and read-only prerequisites for its action buttons.

These checks improve the next step a scientist sees. The governed command remains
the authority and performs its own checks again when an action is executed.
"""
from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import zipfile

import source_manifest as sm


def _registered_spec(product):
    """Return (authoritative material, all materials, a friendly refusal)."""
    try:
        doc = sm.load(os.path.join(product, sm.SOURCE_REFS))
    except (sm.Unreadable, OSError, ValueError, TypeError):
        return None, [], "The source register cannot be read. Ask your data expert to repair it, then check status again."
    if not isinstance(doc, dict):
        return None, [], "Register the program specification before continuing. Your product owner or data expert can attach the workbook."
    materials = doc.get("source_materials")
    if not isinstance(materials, list) or not materials or any(not isinstance(m, dict) for m in materials):
        return None, [], "The source register needs a valid list of source materials. Ask your data expert to repair it."
    ids = [m.get("material_id") for m in materials]
    if any(not isinstance(mid, str) or sm.unstated(mid) for mid in ids) or len(set(ids)) != len(ids):
        return None, materials, "Each registered source needs its own material identifier. Ask your data expert to correct missing or duplicate identifiers."
    specs = [m for m in materials if m.get("material_type") == sm.PROGRAM_SPEC]
    if len(specs) != 1:
        return None, materials, "Identify exactly one authoritative program specification in the source register before continuing."
    return specs[0], materials, ""


def _local_source(root, product, material, *, file_only=True):
    if sm.field_unstated(material, "path_or_link"):
        return None, "Attach the program specification and register its file location before continuing."
    target = material.get("path_or_link")
    if not isinstance(target, str):
        return None, "The registered source location is invalid. Ask your data expert to correct it."
    if target.lower().startswith(sm.REMOTE_PREFIXES):
        return None, "This source is registered as a link. Ask your data expert to make the same document available locally and register that copy."
    try:
        path = Path(sm.material_file(str(product), target, str(root))).resolve()
        if not path.exists() or (file_only and not path.is_file()):
            return None, "The registered specification file is unavailable. Attach the correct workbook or ask your data expert to repair its location."
    except (OSError, ValueError, TypeError):
        return None, "The registered specification file cannot be accessed. Ask your data expert to check its location and permissions."
    return path, ""


def _extraction_reason(root, product, materials, *, registering=True):
    if registering and any(m.get("material_type") == sm.AI_EXTRACTION for m in materials):
        return "An extracted specification is already registered. A changed extraction needs its existing record reviewed; this action never overwrites a review."
    target = product / "spec_pipeline" / "out" / "extracted.json"
    if not target.is_file():
        return "Prepare the specification extraction first. Your data expert can run the extraction workflow after the source is attached."
    try:
        doc = json.loads(target.read_text(encoding="utf-8"))
        if not isinstance(doc, dict) or not isinstance(doc.get("extraction"), dict) or not isinstance(doc.get("rows"), list):
            raise ValueError("extraction structure")
        extraction, rows = doc["extraction"], doc["rows"]
        sources, redaction = extraction.get("sources"), extraction.get("redaction")
        if (not isinstance(sources, list) or not sources or any(not isinstance(s, dict) for s in sources)
                or not isinstance(redaction, dict) or any(not isinstance(row, dict) for row in rows)):
            raise ValueError("extraction metadata")
        if type(extraction.get("row_count")) is not int or extraction["row_count"] != len(rows):
            raise ValueError("extraction row count")
        for key in ("cells_redacted", "rows_redacted"):
            if type(redaction.get(key)) is not int or redaction[key] < 0:
                raise ValueError("redaction counts")
        if redaction["rows_redacted"] > len(rows):
            raise ValueError("redaction row count")
        version, fingerprint = extraction.get("extractor_version"), extraction.get("fingerprint")
        if not isinstance(version, str) or not version or not isinstance(fingerprint, str) or not re.fullmatch(r"[0-9a-f]{16}", fingerprint):
            raise ValueError("extraction fingerprint")
        if any(not isinstance(row.get(key), str) or not row[key] for row in rows for key in ("item_id", "content_hash")):
            raise ValueError("extraction row identity")
        parts = [version] + [f'{source.get("file", "")}={source.get("sha256", "")}' for source in sources]
        parts += [f'{row["item_id"]}={row["content_hash"]}' for row in rows]
        if hashlib.sha256("\x1f".join(parts).encode("utf-8")).hexdigest()[:16] != fingerprint:
            return "The extraction metadata no longer matches its rows. Ask your data expert to regenerate the extraction before registering it."
        policy = root / sm.AI_BOUNDARY
        if not policy.is_file() or redaction.get("policy_sha256") != sm.sha256(str(policy)):
            return "The extraction does not match the current document-redaction policy. Ask your data expert to regenerate it before registering it."
        parent_id = sm.pipeline_source_id(str(product))
        parent = next((m for m in materials if m.get("material_id") == parent_id), None)
        if parent is None:
            return "Select a registered input for the extraction workflow first. Your data expert can connect the specification to this product's pipeline."
        parent_path, reason = _local_source(root, product, parent, file_only=False)
        if reason:
            return reason
        extracted_target = extraction.get("target")
        if not isinstance(extracted_target, str) or not extracted_target:
            raise ValueError("extraction target")
        if Path(sm.material_file(str(product), extracted_target, str(root))).resolve() != parent_path:
            return "The selected source has changed since this extraction. Ask your data expert to regenerate it for the current input."
        source_dir = parent_path.parent if parent_path.is_file() else parent_path
        if parent_path.is_dir():
            source_dir = next((parent_path / folder for folder in ("prog_spec", "ref/prog_spec", "Program Specification")
                               if (parent_path / folder).is_dir()), parent_path)
        for source in sources:
            name, digest = source.get("file"), source.get("sha256")
            if not isinstance(name, str) or not name or not isinstance(digest, str) or not re.fullmatch(r"(?:[0-9a-f]{16}|[0-9a-f]{64})", digest):
                raise ValueError("extraction source identity")
            # The extractor records a basename beside its target, including for
            # workbook inputs. Older explicit paths still resolve as registered paths.
            source_path = (source_dir / name if Path(name).name == name
                           else Path(sm.material_file(str(product), name, str(root))))
            if not source_path.is_file() or not sm.sha256(str(source_path)).startswith(digest):
                return "The input files have changed or are unavailable since extraction. Ask your data expert to regenerate the extraction from the current source."
    except (OSError, ValueError, TypeError, KeyError, sm.Unreadable):
        return "The extraction file is incomplete or unreadable. Ask your data expert to regenerate it before registering it."
    return ""


def _pipeline_reason(root, product, materials):
    """Check the runner's input prerequisites without extracting or approving anything."""
    import run_spec_pipeline as pipeline
    conf_path = product / "spec_pipeline" / "pipeline.conf"
    if not conf_path.is_file():
        return "Configure this product's specification pipeline before preparing the extraction. Your data expert can connect its registered input."
    try:
        conf = pipeline.read_conf(str(conf_path))
        if any(sm.unstated(conf.get(key)) or "<" in str(conf.get(key)) for key in ("TUMOR", "SPEC_SOURCE_ID")):
            return "Complete the tumour and registered source selection in spec_pipeline/pipeline.conf first."
        parent = next((m for m in materials if m.get("material_id") == conf["SPEC_SOURCE_ID"]), None)
        if not parent or parent.get("material_type") not in (sm.PROGRAM_SPEC, sm.EXTRACTION_INPUT):
            return "The pipeline must select a registered program specification or its registered extraction input. Ask your data expert to correct SPEC_SOURCE_ID."
        if sm.classification_errors(parent):
            return "Have the authorized person complete this source's access classification before extraction."
        path, reason = _local_source(root, product, parent, file_only=False)
        if reason:
            return reason
        if path.is_file() and path.suffix.lower() not in (".xlsx", ".tsv"):
            return "The specification pipeline accepts an Excel workbook, a TSV file or a folder of specification tabs. Ask your data expert to register a supported input."
        if not sm.field_unstated(parent, "sha256") and str(parent["sha256"]).lower() != sm.sha256(str(path)).lower():
            return "The pipeline input has changed since its checksum was recorded. Review the source revision before regenerating its extraction."
        if path.is_file() and path.suffix.lower() == ".xlsx":
            try:
                with zipfile.ZipFile(path) as workbook:
                    if not {"[Content_Types].xml", "xl/workbook.xml"}.issubset(workbook.namelist()):
                        raise zipfile.BadZipFile("missing workbook metadata")
            except zipfile.BadZipFile:
                return "The registered .xlsx file is not a readable Excel workbook. Ask your data expert to attach a valid workbook before extraction."
        registry, error = sm.read_yaml(str(root / "governance" / "tumour_registry.yaml"))
        if error or not isinstance(registry, dict):
            return "The tumour registry cannot be read. Your data expert must repair it before the pipeline can identify the workbook's disease."
        aliases, families = registry.get("aliases") or {}, registry.get("families") or {}
        if not isinstance(aliases, dict) or not isinstance(families, dict):
            return "The tumour registry is incomplete. Ask your data expert to repair it before extraction."
        tumor = str(conf["TUMOR"]).strip().lower()
        if aliases.get(tumor, tumor) not in families:
            return "This pipeline's tumour is not registered. Your data expert must connect it to the correct supported tumour family before extraction."
        if not (root / sm.AI_BOUNDARY).is_file():
            return "Restore the governed document-redaction policy before preparing the extraction."
    except (OSError, ValueError, TypeError, KeyError, sm.Unreadable):
        return "The specification pipeline inputs cannot be read. Ask your data expert to repair the source and pipeline configuration."
    return ""


def _decision_reason(product, *, forms=False):
    import contract_lint as cl
    import decision_record as dr
    path = product / "handoff" / "DECISIONS.md"
    if not path.is_file():
        return "Create the decision register with the scientific owner before preparing questions or answer forms."
    try:
        text = path.read_text(encoding="utf-8")
        errors = cl.decision_register_errors(text, str(product))
        if errors:
            return "Repair the decision register before continuing: " + str(errors[0])
        if forms:
            rows, states = dr.decision_rows(text), dr.decision_status(text)
            open_rows = {did: row for did, row in rows.items() if str(states.get(did, "OPEN")).strip().upper() == "OPEN"}
            if not open_rows:
                return "There are no open decision rows to issue forms for. Review the existing decisions or record a new question first."
            for row in open_rows.values():
                if any(dr._blankish(value) for value in (dr.decision_question(row), dr.decision_evidence(row), dr.cell(row, "Owner", default=""))):
                    return "Each open decision needs a question, supporting evidence and an owner before an answer form can be issued."
            if all((product / dr.FORMS_DIR / f"{did}.yaml").is_file() for did in open_rows):
                return "Answer forms are already available. Have the scientific owner complete those forms; existing answers are never overwritten."
    except (OSError, ValueError, TypeError, KeyError):
        return "The decision register cannot be read. Ask your data expert to repair it before continuing."
    return ""


def _verdict_reason(root, product, action):
    import product_gates as pg
    from engine.strict_yaml import strict_load
    import yaml
    member = action.get("member")
    path = product / pg.verdict_rel(member)
    try:
        path.resolve().relative_to(product)
    except ValueError:
        return "The source report location is outside this product. Ask your data expert to correct the member configuration."
    contract = product / "handoff" / "FUNCTIONAL_CONTRACT.md"
    if not path.is_file() or not contract.is_file():
        return "Prepare the contract and the source verdict report before applying source findings."
    try:
        text = path.read_text(encoding="utf-8")
        match = re.match(r"---\n(.*?)\n---(?:\n|$)", text, re.DOTALL)
        metadata = strict_load(match.group(1)) if match else None
        if not isinstance(metadata, dict):
            return "The source report has no readable review metadata. Ask your data expert to regenerate it."
        if sm.unstated(metadata.get("reviewed_by")) or sm.not_a_person(metadata.get("reviewed_by")) or sm.bad_date(metadata.get("review_date")):
            return "The named data expert must review and date the source report before its findings are applied."
        if str(metadata.get("contract_sha256")) != pg.mapping_sha256(str(contract)) or str(metadata.get("config_sha256")) != pg.delivery_sha256(str(product)):
            return "The contract mappings or delivery configuration changed after this source report. Ask your data expert to regenerate and review it."
        relative = path.relative_to(root).as_posix()
        committed = subprocess.run(["git", "-C", str(root), "show", f"HEAD:{relative}"], capture_output=True, timeout=10)
        if committed.returncode or committed.stdout.replace(b"\r\n", b"\n") != path.read_bytes().replace(b"\r\n", b"\n"):
            return "Record the reviewed source report in the repository before applying its findings to the contract."
    except (OSError, ValueError, TypeError, KeyError, AttributeError, yaml.YAMLError, subprocess.TimeoutExpired):
        return "The source review could not be verified. Ask your data expert to repair the report and its recorded history."
    return ""


def action_guard(root, pack, action, *, local_demo, can_write):
    """Empty means runnable; otherwise explain the prerequisite without changing files."""
    if not isinstance(action, dict):
        return "This action is unavailable. Check status again."
    kind = action.get("kind")
    if kind == "person":
        return "This step needs the named reviewer or product owner. Follow the guidance below, then check status again."
    argv = action.get("argv")
    if not isinstance(argv, list) or not argv or any(not isinstance(arg, str) or not arg.strip() for arg in argv):
        return "This step needs more information before it can run. Follow the guidance below or ask your data expert for help."
    if any(re.search(r"<[^>]+>", arg) for arg in argv):
        return "This step still needs a person to provide the required details. Follow the guidance below before continuing."
    if kind not in ("read", "write"):
        return "This action is unavailable. Check status again."
    try:
        root = Path(root).resolve()
        product = (root / pack).resolve()
        product.relative_to(root)
        if product == root or not product.is_dir():
            raise ValueError("missing product")
    except (OSError, ValueError, TypeError):
        return "This product is no longer available in the current workspace. Select a product and check status again."
    if kind == "read":
        if action.get("id") == "g5_smoke":
            import doctor
            try:
                state, _subject, detail, _fix = doctor._spark_runtime()
            except (ImportError, OSError, ValueError):
                return "The local build runtime could not be checked. Your data expert can run the environment check and prepare Spark."
            if state != doctor.OK:
                return "Prepare the local build runtime with your data expert before running the synthetic example: " + detail
        return ""
    if not can_write:
        return "Your current role can check status. A product owner or data expert with write access must perform this change."
    if not local_demo:
        return "This shared portal allows status checks. Ask your data expert to perform this change through the governed review workflow."
    aid = action.get("id")
    if aid in ("g2_questions", "g2_forms"):
        return _decision_reason(product, forms=aid == "g2_forms")
    if aid == "g3_apply" or str(aid).startswith("g3_apply_"):
        return _verdict_reason(root, product, action)
    if aid == "g6_seal":
        import approval_record as approvals
        try:
            errors = approvals.form_errors(str(root), product.relative_to(root).as_posix(), "release")
        except (OSError, ValueError, TypeError, KeyError, AttributeError):
            return "The release approval cannot be checked. Ask your data expert to repair the release evidence before recording it."
        return "Complete the release review before recording it: " + str(errors[0]) if errors else ""
    if aid not in ("g1_digest", "g1_extract", "g1_register_extraction", "g1_seal", "g2_scaffold", "g2_extract", "g2_refresh_extraction"):
        return ""
    spec, materials, reason = _registered_spec(str(product))
    if reason:
        return reason
    if aid == "g1_register_extraction":
        return _extraction_reason(root, product, materials)
    if aid in ("g1_extract", "g2_extract", "g2_refresh_extraction"):
        return _pipeline_reason(root, product, materials)
    if aid == "g2_scaffold":
        # Recheck even a previously rendered action: older portal state must not
        # retain the former destination that overwrote the authored contract.
        try:
            output = argv[argv.index("--records") + 1]
        except (ValueError, IndexError):
            return "Check status again to refresh the outline action and its generated-file destination."
        expected = product / "spec_pipeline" / "out" / "SCAFFOLDED_RECORDS.md"
        if (root / output).resolve() != expected.resolve():
            return "Check status again. The outline must be written to its generated draft file so the authored contract is preserved."
        return _extraction_reason(root, product, materials, registering=False)
    path, reason = _local_source(root, product, spec)
    if reason:
        return reason
    try:
        digest = sm.sha256(str(path))
    except OSError:
        return "The specification cannot be read. Ask your data expert to check file permissions, then check status again."
    recorded = not sm.field_unstated(spec, "sha256")
    if recorded and spec.get("sha256") != digest:
        return "The workbook has changed since its recorded version. Have the product owner review the new source and update its record before continuing."
    if aid == "g1_digest":
        return "This workbook version already has its checksum recorded. Check status to see the next step." if recorded else ""
    if not recorded:
        return "Record the workbook checksum first so the review refers to an exact document version."
    if spec.get("status") not in sm.MATERIAL_STATUSES:
        return "Correct the source review status first: use pending while review is incomplete, or reviewed only with its completed review evidence. 'approved' is not a source-material status."
    if spec.get("status") != sm.REVIEWED:
        return "The program specification is still awaiting review. The named reviewer must complete the review before its decision can be recorded."
    missing = [field for field in sm.APPROVAL_FIELDS + sm.POLICY_FIELDS if sm.field_unstated(spec, field)]
    if missing:
        return "Complete the specification's review record first: " + ", ".join(field.replace("_", " ") for field in missing) + "."
    try:
        errors = sm.classification_errors(spec)
        if not errors:
            errors = [error for error in sm.check(str(root), product.relative_to(root).as_posix())
                      if "moved past its ledger" not in error and "holds no lifecycle event" not in error]
    except (OSError, ValueError, TypeError, KeyError, AttributeError, sm.Unreadable):
        return "The specification checks could not finish. Ask your data expert to repair the source records, then check status again."
    if errors:
        return "Resolve the specification check before recording its review: " + str(errors[0])
    return ""


def action_state(root, pack, action, *, local_demo, can_write):
    """A verified completed step is distinct from a missing prerequisite or permission."""
    reason = action_guard(root, pack, action, local_demo=local_demo, can_write=can_write)
    if isinstance(action, dict) and action.get("id") == "g1_digest":
        try:
            base = Path(root).resolve()
            product = (base / pack).resolve()
            product.relative_to(base)
            spec, _materials, refusal = _registered_spec(str(product))
            if product != base and not refusal and not sm.field_unstated(spec, "sha256"):
                path, refusal = _local_source(base, product, spec)
                if not refusal and spec.get("sha256") == sm.sha256(str(path)):
                    return {"state": "complete", "reason": "This workbook's checksum is already recorded and still matches. Continue with the next review requirement."}
        except (OSError, ValueError, TypeError, KeyError):
            pass
    return {"state": "blocked" if reason else "ready", "reason": reason}


def specification_outline(root, pack):
    """Read a generated outline and compare its records with the current drafting inputs.

    Outline freshness and the next drafting action are separate. Saving a definition removes
    its row from the next scaffold, but does not make another scaffold a prerequisite to editing.
    Neither a row count nor a current reading outline advances a gate.
    """
    result = {"current": False, "rows": [], "reason": "Prepare the specification outline first.",
              "path": f"{pack}/spec_pipeline/out/SCAFFOLDED_RECORDS.md", "continue_action": None,
              "drafted_count": 0, "remaining_count": None}
    try:
        import contract_lint as cl
        import contract_scaffold as scaffold
        base = Path(root).resolve()
        product = base / pack
        if product.resolve() != product or product == base or not product.is_relative_to(base):
            return result
        path = product / "spec_pipeline/out/SCAFFOLDED_RECORDS.md"
        extracted = product / "spec_pipeline/out/extracted.json"
        contract = product / "handoff/FUNCTIONAL_CONTRACT.md"
        if any(p.resolve() != p for p in (path, extracted, contract)):
            return result
        if (not extracted.is_file() or extracted.stat().st_size > 16 * 1024 * 1024
                or any(p.is_file() and p.stat().st_size > 4 * 1024 * 1024 for p in (path, contract))):
            result["reason"] = "The outline or extraction cannot be reviewed here. Ask your data expert to inspect it."
            return result
        data = json.loads(extracted.read_text(encoding="utf-8"))
        pending = scaffold.scaffold(data, str(product))
        expected = scaffold.to_contract_records(pending["records"])
        _spec, materials, reason = _registered_spec(str(product))
        reason = reason or _extraction_reason(base, product, materials, registering=False)
        if reason:
            result["reason"] = reason
            return result
        result["drafted_count"] = sum(1 for _ in cl.typed_records(cl.read(str(contract)))) if contract.is_file() else 0
        result["remaining_count"] = len(pending["records"])
        if result["drafted_count"]:
            result["continue_action"] = "g2_draft" if pending["records"] else "g2_lint"
        if not path.is_file():
            if result["drafted_count"]:
                result["reason"] = "Saved definition records are available. Continue their review; a generated reading outline is optional."
            return result
        text = cl.read(str(path))
        records = cl.typed_records(text)
        result["rows"] = [{"Specification row": ", ".join(cl._list(rec.raw, "spec_refs") or []),
                           "Variable": rec.variable_id, "Specification definition": rec.cells.get("required_rule", "")}
                          for rec in records]
        if list(cl.records(text)) != list(cl.records(expected)):
            result["reason"] = "The outline differs from the current specification or drafting progress. The editor uses the current extraction; regenerate this reading aid if you need an updated outline."
            return result
        result.update(current=True, reason="The outline matches the current extraction and drafting progress. Definition and review checks still determine what remains.")
    except (OSError, ValueError, TypeError, KeyError, AttributeError, UnicodeError):
        result["reason"] = "The outline could not be checked against its current source. Prepare it again or ask your data expert to repair the drafting inputs."
    return result


_COPY = {
    "g1_check": ("Check the specification record", "Check what has been supplied and what still needs review.",
                 ["Run the registration check to inspect the current record.", "Review any remaining requirements. A valid pending record is still awaiting scientific approval."]),
    "g1_init": ("Register the program specification", "Create the source record using an accountable person's AI-access classification.",
                ["Decide how AI may read this material, then enter that choice with your own name and the date in the form here.", "Registering creates the record with the specification pending. The workbook, its checksum and the named scientific review are recorded afterwards."]),
    "g1_repair": ("Repair the source record", "The source record exists but cannot be used as it stands.",
                  ["Ask your data expert to open the file, correct the problem the check names and keep every value a person already recorded.", "Check status again. The record is never regenerated automatically because it may carry someone's registration."]),
    "g1_classify_extraction": ("Confirm how the extracted specification may be used", "An accountable person must record whether the extracted rows may be read by AI, separately from the workbook.",
                               ["Inspect the extracted content and the restrictions that apply to it.", "Record the classification, the names and the dates in the extracted source form here.", "Check status again; the workbook's own decision does not cover the extraction unless it was recorded that way."]),
    "g1_workbook": ("Add the program specification", "The product needs the document its definitions come from.",
                    ["Choose the correct workbook and revision with your product owner.", "Ask your data expert to attach the file and register its location for this product.", "Check status again after the source is registered."]),
    "g1_digest": ("Identify this workbook version", "A checksum connects the review to the exact workbook bytes. It does not approve the document.",
                  ["Confirm that the registered file is the intended specification.", "Record its checksum when this action becomes available.", "If the file has changed since review, ask the product owner to review the new version first."]),
    "g1_classify": ("Confirm how the source may be used", "An accountable person must record whether this material may be read by AI.",
                    ["Have the authorized reviewer inspect the source and applicable restrictions.", "Record the classification, the person's name and the date in the source register.", "Check status again; classification and scientific approval are separate decisions."]),
    "g1_review": ("Complete the specification details and review", "Save the document details here, then complete the named scientific review.",
                  ["Save the document's existing ID or generate a reusable ID here, and enter its actual revision and data refresh.", "Have the designated reviewer confirm the specification and QC reference, then record the reviewer and completed review date.", "The source uses reviewed only after that decision. Check status to see what remains."]),
    "g1_review_recorded": ("Correct the recorded review", "The scientific review is recorded and can still be corrected until it is signed.",
                           ["Check the reviewer's name, the review date and the document details as they were saved.", "Correct any entry that is wrong and record the review again; the record stands as typed until the reviewer signs it.", "After the signature a correction is a new review of the changed record. Check status to see what remains."]),
    "g1_extract": ("Prepare the specification for review", "Extract the registered workbook and prepare its draft review outputs.",
                   ["Confirm the source, its AI-access classification, and the prerequisites shown here.",
                    "Run this step to generate the extraction and review outline from the registered source.",
                    "Review the findings before registering or approving the extraction. Generated content remains a draft."]),
    "g1_register_extraction": ("Prepare the extracted specification for review", "Register the current extraction so a person can review how it may be used.",
                               ["Ask your data expert to prepare an extraction from the currently selected source.", "Use this action to register the extraction's version and redaction details.", "Have an authorized person complete its classification and approval; registration leaves those decisions pending."]),
    "g1_commit": ("Connect the review to its reviewer", "Check who needs to review and whether their review can be verified.",
                  ["Open the reviewer details to see whether setup or a completed review is needed.", "Use the prepared request for your administrator or reviewer, then check status when they have completed it."]),
    "g1_seal": ("Record the reviewed specification", "The lifecycle record preserves an existing, completed review of this document version.",
                ["Complete the specification review and record its exact workbook checksum.", "Resolve the source checks and record the review through the existing identity process.", "Use this action when available, then check status to confirm the recorded state."]),
    "g2_scaffold": ("Prepare the specification outline", "Create a reading outline of the extracted specification. This step leaves the scientific definition records unchanged.",
                    ["Run this step once for the current specification, then review the definitions shown below.", "Use Open Plan changes to write proposed definitions in plain language, or Open definition editor to work with your data expert on the scientific records.", "The scientific-definition check stays open until the required records and review evidence are complete. Repeating outline generation does not complete that work."]),
    "g2_questions": ("Prepare the open questions", "Collect unresolved specification questions so the appropriate reviewer can answer them.",
                     ["Generate the current questions.", "Review them with the scientific owner and record the decisions through the review workflow.", "Check status again after decisions are recorded."]),
    "g2_forms": ("Prepare decision forms", "Prepare the records used to capture the scientific owner's decisions.",
                 ["Prepare the forms for the current questions.", "Have the named reviewer answer and record the decisions.", "Check status again after the completed records are reviewed."]),
    "g2_draft": ("Draft the scientific definition", "Review the outline, then record how each specification requirement should be interpreted.",
                 ["Choose one specification row. Start with Meaning: what the value means and what one result describes.", "Continue through the short sections, saving unfinished work as needed. In Review, validate your answers and check the before-and-after diff before saving a checked draft to the contract."]),
    "g2_lint": ("Check the scientific definitions", "Check that the definition records are complete, consistent, and tied to their source.",
                ["Run the check and review the reported requirements with your data expert.", "Refer scientific ambiguities to the owner. A clean structural check does not approve an interpretation."]),
    "g2_packet": ("Review the scientific questions", "Read the context for decisions that still need an accountable answer.",
                  ["Open the question packet and review the source evidence.", "Have the appropriate scientific owner answer each question through the decision workflow."]),
    "g2_answer": ("Answer the scientific questions", "The scientific owner must supply the decisions that the specification leaves open.",
                  ["Open Questions to answer and read the question and its supporting evidence.", "Enter the decision actually made, its decision maker and date, then save it in the portal.", "The named reviewer authenticates the resulting decision register during scientific review."]),
    "g2_apply": ("Save the scientific answers", "The portal can validate and save answers from issued forms into the decision register.",
                 ["Open Questions to answer and confirm the current question and supporting evidence.", "Save the decision, decision maker and date. The form and register update together after their checks pass.", "Authenticate the resulting register during scientific review; saving does not approve the contract."]),
    "g2_registers": ("Prepare the scientific review records", "The product needs records of open decisions, specification findings and engine gaps.",
                     ["Create each missing review register here using the standard format, or ask your data expert to.", "Record the actual open questions, findings and gaps. An absent register must not be treated as an empty review."]),
    "g2_settle": ("Confirm the agreed requirements", "The scientific owner must confirm which definitions state the intended requirement.",
                  ["Review each definition against the specification and the recorded decisions.", "Record approval only for requirements the owner has agreed; retain unresolved questions and implementation gaps."]),
    "g2_approve": ("Approve the scientific definitions", "The scientific owner reviews one exact version of the definitions and supporting evidence.",
                   ["Review the extraction, coverage, definitions, decisions, and specification findings together.", "Record the accountable approval against those exact versions through the identity process. Changed evidence needs a new review."]),
    "g2_maturity": ("Update the definition review status", "Update the progress label after the required approval evidence is recorded.",
                    ["Have your data expert verify that the definition checks and committed approval support the new status.", "Update the status and check again. Changing this label does not create approval evidence."]),
    "g2_commit": ("Record the definition review history", "The reviewed definitions and approval need traceable, authenticated authorship.",
                  ["Confirm that the records reflect the decisions actually made by the named people.", "Ask your data expert to help record the exact reviewed files through the repository's identity process."]),
    "g3_structure": ("Check source declarations", "Check the source declarations attached to the scientific definitions.",
                     ["Run this check to find incomplete or inconsistent source declarations in the contract.", "Have your data expert resolve the findings and review the delivery evidence separately. This check does not establish source suitability."]),
    "g3_registry": ("Identify the data provider", "The product must identify its provider so the correct evidence requirements apply.",
                    ["Confirm the provider and delivery with the product owner.", "Ask your data expert to register the product under the correct provider, then check status again."]),
    "g3_run": ("Check the delivered data", "The source review needs evidence from the actual delivery in its approved data environment.",
               ["Engineering supplies the delivery's schema and profile.", "Your data expert runs the source checks in that environment and provides the resulting review report."]),
    "g3_confirm": ("Confirm the source mappings", "A data expert must verify that the selected fields represent the intended clinical concepts.",
                   ["Review each mapping against the definition and delivery evidence, including dates, units, and codes.", "Record the confirmed mappings, rationale, and accountable review in the source report."]),
    "g3_apply": ("Record the reviewed source findings", "Apply the committed source report to the definition records.",
                 ["Confirm that the report covers the current delivery and configuration and has been reviewed.", "Apply those findings, then review the updated evidence status. This step does not make new mapping decisions."]),
    "g3_judge": ("Review source suitability", "The data expert must judge the dictionary and data-profile evidence for each requirement.",
                 ["Review missingness, available source information, and unresolved data issues. Distinguish an unavailable dictionary from a failed check.", "Record only the conclusions supported by the reviewed delivery evidence."]),
    "g3_commit": ("Record the source review history", "Preserve the source report and the accountable mapping and suitability decisions.",
                  ["Confirm the report and decisions refer to the same delivery and configuration.", "Have your data expert record the reviewed files through the repository's identity process, then check status again."]),
    "g4_validate": ("Check the build configuration", "Check that the proposed build rules meet the configuration requirements.",
                    ["Run the configuration checks and review any findings with your data expert.", "Resolve missing or invalid settings before a build. Passing these checks does not establish scientific validity."]),
    "g4_validate_strict": ("Check readiness to build", "Run the strict configuration checks before building a candidate.",
                           ["Complete configuration lint and resolve its findings first.", "Run this check to find unfinished configuration or missing build requirements. Review the findings with your data expert."]),
    "g4_review": ("Compare definitions with build rules", "Review how the specification, scientific interpretation, and configured rule relate.",
                  ["Open the rule comparison and look for differences in timing, selection, coding, and missing values.", "Have the scientific owner and data expert resolve any disagreement before approval."]),
    "g4_binding": ("Check that definitions have build rules", "Check the links between the scientific contract and the executable configuration.",
                   ["Run the binding check and review definitions with missing or inconsistent implementation links.", "Ask your data expert to repair the configuration or record an implementation gap."]),
    "g4_author": ("Prepare the build rules", "A data expert must translate the agreed definitions into the product's configuration.",
                  ["Resolve scientific choices with the owner instead of filling placeholders by assumption.", "Have your data expert prepare the rules and code lists, then request the technical review and configuration checks."]),
    "g4_tolerances": ("Agree acceptable data-quality limits", "The product needs reviewed limits for parsing losses and unmatched records.",
                      ["Review the delivery evidence and agree appropriate limits with the responsible data expert and scientific owner.", "Record the limits and rerun source checks against the changed configuration."]),
    "g4_definitions": ("Identify reusable definitions", "Inspect which analytical definitions this configuration needs to reference.",
                       ["Generate the proposed definition entries and review their meaning and versions.", "Use the proposal to prepare the governed register. This check does not register or approve definitions."]),
    "g4_register": ("Register the reusable definitions", "Reviewed definitions need stable identities and versions for use across products and studies.",
                    ["Confirm each definition's meaning, concept reference, and version with its owner.", "Have your data expert record the reviewed entry and attribution; a changed rule needs a new version and its relationship to the prior one."]),
    "g4_implementations": ("Prepare the definition links", "Inspect the proposed links between this dataset's variables and registered definitions.",
                           ["Generate the proposed implementation record from the current configuration.", "Have your data expert review the dataset, variable roles, and definition versions before recording any claim."]),
    "g4_claim": ("Confirm how definitions are implemented", "A data expert must review the definitions that this dataset claims to implement.",
                 ["Review each variable's implementation against the registered definition and current contract.", "Record the confirmed links and accountable review; leave unsupported implementation claims unresolved."]),
    "g4_approve": ("Approve the build configuration", "The data expert and a separate technical reviewer must review the same configuration version.",
                   ["Review the rules, source evidence, definition links, and check results against the agreed contract.", "Record both required reviews against the exact configuration and contract versions. Changes require review again."]),
    "g4_maturity": ("Update the build review status", "Update the progress label to reflect completed configuration work and review evidence.",
                    ["Have your data expert confirm the authored configuration and any required approval support the proposed status.", "Record the status and check again. The label alone does not establish readiness."]),
    "g4_commit": ("Record the build review history", "The configuration and its approval need traceable, authenticated authorship.",
                  ["Confirm the files match the exact versions reviewed by the data expert and technical reviewer.", "Record them through the repository's identity process, then check status again."]),
    "g5_smoke": ("Check the example run", "Run the available local example checks for this product.",
                 ["Run the check and review its results.", "Ask your data expert to resolve any execution errors.", "A passing example does not establish readiness on a study's real data; review the data validation and release requirements separately."]),
    "g5_readiness": ("Review readiness for a pilot", "Inspect the remaining preparation and evidence needed before a pilot run.",
                     ["Run the readiness report and review the outstanding requirements with your data expert.", "Resolve them before relying on a candidate dataset for a study."]),
    "g5_build": ("Build a candidate dataset", "Your data expert stages a candidate on the approved compute environment for validation.",
                 ["Confirm that the product configuration and delivery are ready for the candidate run.", "Have your data expert run the configured job and collect its build evidence. A candidate run stages results without publishing them."]),
    "g5_record": ("Record validation evidence", "The definition records must reflect the results demonstrated by this exact build.",
                  ["Review the build's evidence against the agreed requirements.", "Record only implementation and validation states supported by that evidence. A synthetic example cannot establish validation on the live delivery."]),
    "g5_validate": ("Confirm candidate validation", "A named reviewer must confirm that this candidate's validation evidence has been reviewed.",
                    ["Review the candidate build and its quality-control evidence.", "Record the validator and review date against the correct candidate through the approval workflow."]),
    "g6_approve": ("Approve this candidate for release", "The release approver must approve one validated build and its exact manifest.",
                   ["Review the candidate, validation evidence, and intended release with the accountable approver.", "Record approval for that build identifier and manifest through the review process. Approval of another build does not cover this one."]),
    "g6_promote": ("Publish the approved build", "Publication must promote the exact candidate that the release approver reviewed.",
                   ["Have your data expert verify the approval matches the intended candidate build.", "Run the governed publication workflow for that build, then verify the resulting release receipt."]),
    "g6_seal": ("Record the release approval event", "Add a lifecycle record for an existing release approval that passes its checks.",
                ["Confirm that the release approval stands against its build and evidence.", "Record the event when available. Recording an event does not supply the approval or the reviewer's signature."]),
    "g6_countersign": ("Authenticate the release approval", "The authorized reviewer must sign the recorded approval with their registered review key.",
                       ["Have the reviewer verify the sealed approval and its exact build evidence.", "The reviewer completes the signature through the established signing process. The portal cannot sign on another person's behalf."]),
    "g6_commit": ("Record the signed release history", "The approval, lifecycle event, and signature must be preserved in the governed history.",
                  ["Confirm that the signed records refer to the intended published build.", "Have your data expert help record those exact files through the identity process, then check the release receipt."]),
    "g6_receipt": ("Verify the release receipt", "Check the committed evidence identifying what was actually released.",
                   ["Run the receipt check and review any discrepancy with your data expert.", "Use the verified release and build identifiers when a study pins this product."]),
}


def issue_copy(action, blocker_text=""):
    """Explain existing actions without inventing scientific decisions or approvals."""
    action = action if isinstance(action, dict) else {}
    if action.get("development_review") is True:
        reviewer = str(action.get("reviewer") or "the named reviewer").replace("_", " ")
        return {"title": f"Confirm {reviewer}'s review with name and email",
                "summary": "Record this review for the development workflow. No signing key is required.",
                "steps": ["Check that the current records show the review you completed.",
                          "Enter your email, confirm your review, and save. Each named reviewer confirms separately.",
                          "Check status to continue. Changes to the reviewed content require a new confirmation."]}
    copy_id = action.get("copy_id") or action.get("id")
    if copy_id == "g1_classify" and action.get("material_type") == sm.AI_EXTRACTION:
        # The act names its material (flow.acts, 2026-09-07): the extraction's TODOs are answered
        # in the extracted source form, and the guidance says so instead of describing the workbook.
        copy_id = "g1_classify_extraction"
    if copy_id == "g1_review" and action.get("recorded"):
        # the review is complete and unsigned (flow.acts, walk UC1-05): a correction, not a first review
        copy_id = "g1_review_recorded"
    copy = _COPY.get(copy_id)
    if copy:
        title, summary, steps = copy
        steps = list(steps)
        if copy_id == "g1_workbook" and action.get("path"):
            # the folder and the record are named in plain words; their paths are under the
            # technical handoff (walk NC-16, 2026-09-07)
            steps[1] = ("Provide the workbook to your data expert. They place it in the product's specification folder and "
                        "register its exact location in the source register; document approval is recorded separately.")
        if action.get("member"):
            title += " · " + str(action["member"])
        return {"title": title, "summary": summary, "steps": steps}
    title = "Review the next requirement"
    summary = "This requirement needs review with the responsible product team. Its reported details are available in the technical handoff."
    if action.get("kind") == "person":
        steps = ["Share this requirement with the named reviewer, product owner or data expert responsible for it.",
                 "Record their decision through the existing review process, then check status again."]
    else:
        steps = ["Review the prerequisite shown here.", "Run this action when it becomes available, then check status again."]
    return {"title": title, "summary": summary, "steps": steps}


# ---------------------------------------------------------------------------------------------
# PLAIN SENTENCES FOR WHAT THE CHECKS REPORT (walks NC-16 and the UC1 P3s, 2026-09-07).
# status.py and the gate functions quote their findings for the maintainer: file names, flags,
# field names and the command that writes a report. The page reads each finding to a person
# here, in one sentence, chosen by the words the finding already carries; the raw line stays
# available word for word under the technical handoff. Nothing here re-derives a state, and a
# finding no pattern knows is scrubbed of its technical tokens rather than described around.
# ---------------------------------------------------------------------------------------------

_FILE_NAMES = {
    "source_refs.yaml": "the source register",
    "DECISIONS.md": "the decision register",
    "SPEC_QC_FINDINGS.md": "the specification findings register",
    "ENGINE_GAPS.md": "the engine gaps register",
    "SCIENCE_QUESTIONS.md": "the ranked open questions",
    "FUNCTIONAL_CONTRACT.md": "the scientific definition records",
    "CONTRACT_APPROVAL.yaml": "the definitions approval form",
    "CONFIGURATION_APPROVAL.yaml": "the build configuration approval form",
    "RELEASE_APPROVAL.yaml": "the release approval form",
    "SOURCE_VERDICTS.md": "the delivered data report",
    "MATURITY.yaml": "the progress claims",
    "data_product.yaml": "the build configuration",
    "implementations.yaml": "the definition implementation claims",
    "DEFINITIONS.yaml": "the definitions register",
    "allowed_signers.yaml": "the reviewer key register",
    "SIGNING_KEYS.yaml": "the signing key register",
    "registry.yaml": "the product registry",
    "pipeline.conf": "the specification pipeline settings",
    "SCAFFOLDED_RECORDS.md": "the generated review outline",
    "extracted.json": "the specification extraction",
    "OPERATIONS.md": "the operations guide",
    "WORKFLOW.md": "the workflow rules",
    "out": "the extraction output folder",
    "decision_answers": "the answer forms folder",
    "prog_spec": "the specification folder",
}

_FIELD_LABELS = {
    "document_id": "document ID", "revision": "document revision", "data_refresh": "data refresh or delivery",
    "rwb_qc_reference": "specification QC reference", "approved_by": "reviewer's name", "approval_date": "review date",
    "classified_by": "access classifier's name", "classified_date": "classification date",
    "ai_classification": "AI access classification", "why_provisional": "reason the review is still pending",
    "validated_by": "validator's name", "validation_date": "validation date",
    "technically_reviewed_by": "technical reviewer's name", "technical_review_date": "technical review date",
    "spec_qc_reviewed_by": "specification QC reviewer's name", "spec_qc_review_date": "specification QC review date",
    "reviewed_by": "reviewer's name", "review_date": "review date",
    "approved_build_id": "approved build identifier", "approved_manifest_sha256": "approved manifest digest",
}

_APPROVAL_FORMS = {
    "CONTRACT_APPROVAL.yaml": "the approval of the scientific definitions",
    "CONFIGURATION_APPROVAL.yaml": "the approval of the build configuration",
    "RELEASE_APPROVAL.yaml": "the release approval",
}

_STATE_WORDS = {"not_started": "not started", "coverage_complete": "complete for every specification row",
                "draft": "a draft", "approved": "approved"}

_TECHNICAL_TOKEN = re.compile(r"[A-Za-z_]/|/[A-Za-z_]|\\|^--|\.(?:py|md|yaml|yml|json|conf|tsv|xlsx)$", re.I)
_TECHNICAL_MARKS = (" — ", "->", "→", "↳")


def technical_tokens(text):
    """The tokens of `text` a person should not be shown: a path, a command flag, a file name, a
    dash or an arrow used as punctuation. Empty means the text reads as plain English."""
    found = [mark for mark in _TECHNICAL_MARKS if mark in str(text)]
    for token in str(text).split():
        bare = token.strip(".,;:()[]{}\"'`*")
        if bare and _TECHNICAL_TOKEN.search(bare):
            found.append(bare)
    return found


def file_label(path):
    """A file the checks name, as a person knows it; never the path itself."""
    text = str(path or "").replace("\\", "/")
    name = text.rstrip("/").rsplit("/", 1)[-1]
    if not name:
        return "the product's files"
    return _FILE_NAMES.get(name) or ("the product's files" if text.endswith("/") else "the product's record file")


def act_title(action):
    """The label a person reads for an act, from its id alone when that is all a page has (the
    run list, a stored handoff). A member suffix (g3_run_2) reads as its base act."""
    action = dict(action) if isinstance(action, dict) else {"id": str(action or "")}
    copy_id = str(action.get("copy_id") or action.get("id") or "")
    if copy_id not in _COPY:
        action["copy_id"] = re.sub(r"_\d+$", "", copy_id)
    return issue_copy(action)["title"]


def _field_label(field):
    field = str(field or "").strip("`")
    return _FIELD_LABELS.get(field) or field.replace("_sha256", " digest").replace("_", " ")


def _named_file(text):
    for name in _FILE_NAMES:
        if name in text and "." in name:
            return name
    return ""


def _why_unsigned(text):
    if "no commit's diff" in text or "uncommitted" in text:
        return "It has not been committed yet."
    if "UNSIGNED" in text:
        return "The commit that recorded it carries no signature."
    if "moved after it was written" in text:
        return "The record changed after it was signed, so it needs signing again."
    if "attributed to" in text:
        return "It was signed by someone other than the person named."
    if "INELIGIBLE" in text or "does not register" in text:
        return "The signing key is not registered for review."
    if "shallow" in text.lower() or "depth" in text.lower():
        return "The checkout's history is too short to verify it."
    if "cannot verify" in text or "BAD" in text or "expired" in text or "revoked" in text:
        return "The signature could not be verified."
    return ""


def _unsigned(match, text):
    field, who = match.group(1), match.group(2).strip()
    named = _named_file(text)
    if field.startswith("decision:"):
        act = "answer to decision " + field.split(":", 1)[1]
    elif field == "classified_by":
        act = "classification"
    elif field == "approved_by":
        act = ("review of the specification" if named == "source_refs.yaml" else _APPROVAL_FORMS.get(named, "approval"))
        act = act.replace("the approval", "approval").replace("the release", "release")
    elif field == "validated_by":
        act = "validation of the candidate"
    elif field == "technically_reviewed_by":
        act = "technical review"
    elif field == "spec_qc_reviewed_by":
        act = "specification QC review"
    elif field == "reviewed_by":
        act = "review of the delivered data report" if named == "SOURCE_VERDICTS.md" else "review"
    else:
        act = _field_label(field)
    sentence = f"{who}'s {act} has not been signed yet."
    why = _why_unsigned(text)
    return sentence + (" " + why if why else "")


def _scrubbed(text):
    """A finding no pattern knows, with its technical tokens replaced by plain names or dropped."""
    text = re.sub(r"^\s*(?:\(when claimed\)\s*)?(?:Gate \d:\s*|evidence:\s*)?", "", str(text))
    text = re.sub(r"`([^`]*)`", lambda m: _FILE_NAMES.get(m.group(1).replace("\\", "/").rsplit("/", 1)[-1], ""), text)
    text = text.replace(" — ", ". ").replace("—", ",").replace("->", " to ").replace("→", " to ").replace("↳", "")
    words = []
    for token in text.split():
        bare = token.strip(".,;:()[]{}\"'*")
        if not bare or not _TECHNICAL_TOKEN.search(bare):
            words.append(token)
            continue
        name = bare.replace("\\", "/").rstrip("/").rsplit("/", 1)[-1]
        if name in _FILE_NAMES:
            words.append(_FILE_NAMES[name] + token[len(token.rstrip(".,;:)]}\"'*")):])
        elif re.match(r"^(?:products|fixtures|sandbox)/", bare):
            words.append("this product" + token[len(token.rstrip(".,;:)]}\"'*")):])
    sentence = re.sub(r"\s+([.,;:)])", r"\1", " ".join(words)).strip(" ,;:")
    sentence = re.sub(r"\s{2,}", " ", sentence)
    if sentence and not sentence.endswith("."):
        sentence += "."
    if not sentence or technical_tokens(sentence):
        return "A check reported a technical finding; its exact wording is under the technical details."
    return sentence[0].upper() + sentence[1:]


def blocker_lines(blockers, *, development=False):
    """The plain sentences for one step's findings, each said once. Several of the checks' lines can
    stand behind one sentence (walk RW4-N06, 2026-09-07: the same sentence three times under step 3);
    a sentence more than one line stands behind says how many, and the lines themselves stay under
    the technical details. Order is the checks' order of first appearance."""
    counts = {}
    for blocker in blockers or []:
        sentence = blocker_copy(blocker, development=development)
        counts[sentence] = counts.get(sentence, 0) + 1
    return [sentence if n == 1 else f"{sentence} That covers {n} lines of the checks."
            for sentence, n in counts.items()]


def blocker_copy(text, *, development=False):
    """One plain sentence for a line the status check reported (see the note above)."""
    text = str(text or "").strip()
    if not text:
        return "Review the current step with your product team."
    if development:
        from flow import development_review_request
        request = development_review_request(text)
        if request:
            return request["text"]
    if text.endswith(":"):
        return "The build configuration step will also require the source checks listed below; that is the data expert's step."
    m = re.search(r"([A-Za-z_]+(?::[A-Za-z0-9_.-]+)?)=(.+?) is not authenticated", text)
    if m:
        return _unsigned(m, text)
    m = re.search(r"source is (\w+), not approved", text)
    if m:
        return {"unregistered": "The program specification has not been registered yet.",
                "provisional": "The program specification is registered; its scientific review is not complete yet.",
                "reviewed": "The specification review is recorded; the remaining checks say what is still needed.",
                }.get(m.group(1), f"The program specification is {m.group(1).replace('_', ' ')}, not approved.")
    m = re.search(r"status:(\w+) requires `([^`]+)`", text)
    if m:
        return f"The recorded review is missing its {_field_label(m.group(2))}."
    m = re.search(r"requires `(ai_classification|classified_by|classified_date)`", text)
    if m:
        return ("The AI access decision has not been fully recorded yet: what AI may read, who decided it and the date. "
                "That is the access classifier's step.")
    if "unsupported status" in text:
        return "The specification record carries a status the register does not support; a completed review is recorded as reviewed."
    if "moved past its ledger" in text:
        return "The specification record changed after its last history entry; record the change in the history."
    if "holds no lifecycle event" in text:
        return "The reviewed specification has not been recorded in the history yet."
    if "names a path in the repo that does not exist" in text:
        return "The registered workbook location points at a file that is not there; register the real location."
    if "the pipeline's source" in text and "does not exist" in text:
        return "The specification pipeline points at a workbook file that is not there."
    if "lists no source_materials" in text:
        return "The source register names no materials yet."
    if "is not readable" in text or "could not be read" in text or "could not be evaluated" in text:
        return "A product file cannot be read; it needs repair before the checks can run. That is the data expert's step."
    m = re.search(r"contract is (\w+), not approved", text)
    if m:
        return f"The scientific definitions are {_STATE_WORDS.get(m.group(1), m.group(1).replace('_', ' '))}, not approved yet."
    m = re.search(r"configuration is (\w+), not approved", text)
    if m:
        return f"The build configuration is {_STATE_WORDS.get(m.group(1), m.group(1).replace('_', ' '))}, not approved yet."
    if "no contract yet" in text:
        return "No scientific definitions have been drafted yet."
    m = re.search(r"(\d+) vendor-sourced record\(s\) have no Gate 3 evidence", text)
    if m:
        return (f"The delivered data has not been checked yet; that is the data expert's step. "
                f"{m.group(1)} definition(s) depend on it.")
    if "evidence route undecided" in text:
        return "This product's data provider is not registered yet, so its source checks cannot be planned; that is the data expert's step."
    if text.startswith("(when claimed)"):
        if "SOURCE_VERDICTS" in text and ("but no" in text or "is missing" in text):
            return "The delivered data report has not been prepared yet; the build configuration will need it once approved. That is the data expert's step."
        if "moved since the verdict" in text or "Re-run source_check" in text:
            return "The delivered data report is older than the current configuration or mappings; the data expert needs to check the delivered data again."
        return "The build configuration approval will also need the source evidence the checks describe; that is the data expert's step."
    m = re.search(r"(DECISIONS|SPEC_QC_FINDINGS|ENGINE_GAPS)\.md(?: is missing|, which is missing)", text) or \
        re.search(r"requires handoff/(DECISIONS|SPEC_QC_FINDINGS|ENGINE_GAPS)\.md", text)
    if m:
        return f"{_FILE_NAMES[m.group(1) + '.md'].capitalize()} has not been created yet."
    if "has no findings table" in text:
        return "The specification findings register has no findings table."
    m = re.search(r"requires `([^`]+)` in handoff/(CONTRACT_APPROVAL|CONFIGURATION_APPROVAL|RELEASE_APPROVAL)\.yaml", text)
    if m:
        return f"{_APPROVAL_FORMS[m.group(2) + '.yaml'].capitalize()} is missing its {_field_label(m.group(1))}."
    m = re.search(r"(CONTRACT_APPROVAL|CONFIGURATION_APPROVAL|RELEASE_APPROVAL)\.yaml does not parse", text)
    if m:
        return f"{_APPROVAL_FORMS[m.group(1) + '.yaml'].capitalize()} cannot be read; it needs repair."
    if "after the approval" in text or "after it was approved" in text:
        subject = ("the specification extraction" if "re-extracted" in text else
                   "the definitions" if "requirements were edited" in text else
                   "the coverage report" if "coverage report" in text else
                   "the decision register" if "decision register" in text else
                   "the specification findings register" if "QC register" in text else
                   "the build configuration" if "configuration was edited" in text else
                   "the definitions" if "contract moved" in text else
                   "the binding between definitions and configuration" if "binding" in text else
                   "something the approval covered")
        return f"{subject[0].upper() + subject[1:]} changed after it was approved, so the approval needs to be made again."
    if "qc.source_thresholds" in text:
        return "The build configuration does not state its accepted data-quality limits for parsing loss and unmatched records."
    if "DEFINITIONS.yaml" in text or "still signs" in text:
        return "The configuration uses analytical definitions that are not registered yet."
    if "implementations.yaml" in text:
        return "The definition implementation claims for this dataset need correcting."
    m = re.search(r"no record has an approved requirement yet \((\d+) record\(s\) drafted\)", text)
    if m:
        return f"None of the {m.group(1)} drafted definition(s) has an agreed requirement yet; validation needs agreed requirements."
    m = re.search(r"(\d+)/(\d+) approved record\(s\) report validation:passed_live", text)
    if m:
        return f"{m.group(1)} of {m.group(2)} approved definition(s) are validated on a live build; the rest are not."
    if "no committed refresh receipt" in text:
        return "No build receipt has been recorded for this cut yet; a data expert records it after the governed run."
    if "candidate verdict FAILED" in text:
        return "The candidate build did not pass all of its checks; see the build receipt with your data expert."
    if "candidate verdict passed" in text:
        return "The candidate build passed its checks."
    if "Gates 1-4 are not all passed" in text:
        return "Steps 1 to 4 have not all passed, so nothing can be released yet."
    m = re.search(r"Gate 5 is ([a-z ]+?) — a release approves", text)
    if m:
        return f"Validation is {m.group(1).strip()}; a release needs a validated build."
    if "RELEASE_APPROVAL" in text and ("no handoff" in text or "NAMED final approval" in text):
        return "The release needs a named final approval after the build."
    if "a build run stages the candidate and stops" in text:
        return "A build stages a candidate and stops; publishing it needs the release approval that names that build."
    if "not recorded in the ledger" in text:
        return "The release approval has not been recorded in the history yet."
    if "edited after it was sealed" in text:
        return "The release approval changed after it was recorded in the history; record it again."
    if "records the approved build as published" in text:
        return "The approved build is recorded as published."
    if "names no build id" in text:
        return "The release approval names no build, so the release receipt cannot be checked."
    m = re.search(r"answer the open decisions \((\d+) open\)", text)
    if m:
        return f"{m.group(1)} scientific question(s) are open; the scientific owner needs to answer them."
    if "stand against this pack's claims" in text:
        return "A check found evidence that does not support this product's current progress claims; the details are under the technical details."
    if text.startswith("event ledger:") or text.startswith("approval identity:"):
        return "The history or identity records could not be verified; ask your data expert."
    return _scrubbed(text)
