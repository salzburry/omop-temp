"""Review requests: what a reviewer sees, what they record, and what happens to accepted changes.

WHY (2026-09-07). The proposal page ended at 'Submit proposal for review' with nowhere for a
second person to go. This page is that place. Every act on it is typed by a person: the name
and the date are never pre-filled, a decision cannot be recorded by the request's own author,
and each screen says who did what and when. Acceptance here is acceptance for a draft revision;
applying writes that draft revision beside the product, never into it.
"""
from __future__ import annotations

import streamlit as st

import review_inbox as inbox
import configuration_proposal_page

PREFIX = "review_inbox_"


def _errors(result, fallback):
    for error in result.get("errors") or [fallback]:
        st.error(str(error))


def _person_fields(key, what):
    name = st.text_input("Your name", key=key + "_name", help=f"Typed by you; the portal never fills it in. It is recorded with {what}.")
    on = st.text_input("Date, as YYYY-MM-DD", key=key + "_date", help="Typed by you; the portal never fills it in.")
    return name, on


def _finish(result, notice, fallback):
    if result.get("ok"):
        st.session_state[PREFIX + "notice"] = result.get("message") or notice
        st.rerun()
    else:
        _errors(result, fallback)


def _decision_forms(root, pack, actor_id, view, *, allowed_packs, local_demo, can_write, can_review):
    request_id, status = view["request_id"], view["status"]
    key = PREFIX + request_id
    common = dict(request_id=request_id, actor_id=actor_id, allowed_packs=allowed_packs, local_demo=local_demo)
    if status in inbox.TRANSITIONS["accepted"]:
        st.write("**Record your review decision**")
        if view["is_author"]:
            st.info(inbox.SELF_REVIEW)
            return
        if not can_review:
            st.info(inbox.NOT_REVIEWER)
            return
        if not local_demo:
            st.info(inbox.NOT_LOCAL)
        note = st.text_area("What needs to change", key=key + "_note",
                            help="Required for Request changes. The author reads this note and submits a revised proposal.")
        name, on = _person_fields(key + "_review", "your decision")
        confirmed = st.checkbox("I confirm that I accept these exact changes for a draft revision. This is not scientific approval or a release.",
                                key=key + "_confirm")
        left, right = st.columns(2)
        if left.button("Request changes", key=key + "_request_changes", disabled=not local_demo):
            result = inbox.request_changes(root, pack, **common, can_review=can_review, note=note,
                                           reviewer_name=name, reviewed_on=on)
            _finish(result, "Your request for changes is recorded on this review request. The author can now revise and submit again.",
                    "The request for changes could not be recorded.")
        if right.button("Accept", key=key + "_accept", disabled=not local_demo or not confirmed or not view["can_accept"]):
            result = inbox.accept(root, pack, **common, can_review=can_review, reviewer_name=name, reviewed_on=on, confirmed=confirmed)
            _finish(result, "Your acceptance is recorded on this review request. The accepted changes can now be applied to a draft revision.",
                    "The acceptance could not be recorded.")
        if not view["can_accept"] and view["proposal_state"] != "intact":
            st.caption("Accept is unavailable because the proposal changed since submission.")
        return
    party = view["is_author"] or can_review
    if status == "accepted":
        st.write("**Apply the accepted changes to a draft revision**")
        st.caption("The accepted files are written under the product's draft folder. The product's own configuration is not changed.")
        if not party:
            st.info(inbox.NOT_PARTY)
            return
        if not (local_demo and can_write):
            st.info(inbox.NOT_LOCAL)
        name, on = _person_fields(key + "_apply", "the applied revision")
        if st.button("Apply accepted changes", key=key + "_apply", disabled=not (local_demo and can_write) or not view["base_current"]):
            result = inbox.apply(root, pack, **common, can_review=can_review, can_write=can_write, applied_by=name, applied_on=on)
            _finish(result, "The accepted changes were applied to a draft revision. Run the validators on it next.",
                    "The accepted changes could not be applied.")
        if not view["base_current"]:
            st.caption("Apply is unavailable because the product changed since this request was submitted.")
        return
    if status in ("applied", "validated"):
        st.write("**Run the validators on the applied revision**")
        st.caption("The same existing checks the author ran, on the draft revision as it was applied.")
        if not party:
            st.info(inbox.NOT_PARTY)
            return
        if not (local_demo and can_write):
            st.info(inbox.NOT_LOCAL)
        name, on = _person_fields(key + "_validate", "the validator run")
        left, right = st.columns(2)
        if left.button("Run the validators on the applied revision", key=key + "_validate",
                       disabled=not (local_demo and can_write) or not view["base_current"]):
            result = inbox.validate(root, pack, **common, can_review=can_review, can_write=can_write, validated_by=name, validated_on=on)
            _finish(result, "The validators ran on the applied revision and their result is recorded on this request.",
                    "The validators could not run on the applied revision.")
        if right.button("Apply accepted changes", key=key + "_reapply", disabled=not (local_demo and can_write)):
            result = inbox.apply(root, pack, **common, can_review=can_review, can_write=can_write, applied_by=name, applied_on=on)
            _finish(result, "Nothing was written.", "The accepted changes could not be applied.")


def _validation_checks(checks):
    for check in checks:
        if check.get("passed"):
            st.success(f"{check.get('validator')}: passed")
        elif check.get("pre_existing"):
            st.warning(f"{check.get('validator')}: failed before this change too (the product's own open work)")
        else:
            st.error(f"{check.get('validator')}: failed")
        for error in check.get("errors") or []:
            st.write(str(error))
        if check.get("note"):
            st.caption(check["note"])


def _validation(record):
    if not record:
        return
    st.write("**Validator results on the draft revision**")
    st.caption(f"Run by {record['name']} on {record['date']}, recorded under {record['recorded_by']['id']}.")
    _validation_checks(record.get("checks") or [])
    for caveat in record.get("caveats") or []:
        st.info(caveat)
    for error in record.get("errors") or []:
        st.error(str(error))


def render(root, pack, actor_id, *, allowed_packs, local_demo, can_write, can_review, route, params=None):
    context = (str(root), pack, actor_id, bool(local_demo), bool(can_write), bool(can_review), tuple(sorted(allowed_packs)))
    if st.session_state.get(PREFIX + "context") != context:
        for key in list(st.session_state):
            if str(key).startswith(PREFIX):
                del st.session_state[key]
        st.session_state[PREFIX + "context"] = context
    st.caption(inbox.NOTICE)
    configuration_proposal_page.render_shared(root, pack, actor_id, local_demo=local_demo, can_write=can_write,
                                              allowed_packs=allowed_packs, key="inbox")
    notice = st.session_state.pop(PREFIX + "notice", None)
    if notice:
        st.success(notice)
    listing = inbox.list_requests(root, pack, actor_id=actor_id, allowed_packs=allowed_packs)
    for error in listing.get("errors") or []:
        st.warning(str(error))
    if not listing.get("ok"):
        return None
    rows = listing["requests"]
    if not rows:
        st.info("No configuration change has been submitted for review in this product yet. "
                "An author stages a proposal under Plan changes, runs the validators and submits it; it then appears here.")
        return None
    labels = {row["request_id"]: f"{row['purpose'] or 'Configuration change'} · {row['request_id'][:8]} · {row['status_words']}" for row in rows}
    incoming = (params or {}).get("request_id")
    if incoming in labels and st.session_state.get(PREFIX + "incoming") != incoming:
        st.session_state[PREFIX + "selected"] = incoming
        st.session_state[PREFIX + "incoming"] = incoming
    if st.session_state.get(PREFIX + "selected") not in labels:
        st.session_state[PREFIX + "selected"] = next(iter(labels))
    request_id = st.selectbox("Review request", list(labels), key=PREFIX + "selected", format_func=labels.get)
    view = inbox.load_request(root, pack, request_id=request_id, actor_id=actor_id, allowed_packs=allowed_packs)
    if not view.get("ok"):
        _errors(view, "The review request could not be opened.")
        return None
    request = view["request"]
    st.subheader(f"Request {request_id[:8]}: {view['status_words']}")
    if request.get("purpose"):
        st.write(request["purpose"])
    st.write("**Who did what and when**")
    for line in view["history"]:
        st.write(line)
    if view["proposal_state"] == "changed":
        st.warning("Changed since submission: the author's proposal no longer matches this snapshot. It cannot be accepted; the author submits the current proposal again.")
    elif view["proposal_state"] == "missing":
        st.warning("Changed since submission: the author's proposal is no longer available. It cannot be accepted; the author submits a current proposal again.")
    elif view["proposal_state"] == "stale":
        st.warning("The reviewed variables, source inputs or consumer requirements changed after submission. Review the current inputs and submit a fresh proposal before accepting or applying it.")
    if not view["base_current"] and view["proposal_state"] != "stale":
        st.warning("The product changed since this request was submitted. Accepted changes cannot be applied to it; the author stages a fresh proposal from the current product.")
    configuration_proposal_page._reviewed_definitions(request, PREFIX + request_id)
    if request.get("variable_review_binding"):
        configuration_proposal_page._reopen_variable_review(root, pack, actor_id,
            allowed_packs=allowed_packs, key=PREFIX + request_id + "_review_variables")
    st.write("**Exact proposed changes**")
    if not request["files"]:
        st.info("This request carries no supported configuration file change. Review its study exclusions and impact below.")
    for entry in request["files"]:
        st.caption(entry["path"])
        st.code(entry["diff"], language="diff")
        with st.expander("Full before-and-after configuration: " + entry["path"]):
            left, right = st.columns(2)
            with left:
                st.caption("Before")
                st.code(entry["before"], language="yaml")
            with right:
                st.caption("Proposed after")
                st.code(entry["after"], language="yaml")
    studies = request.get("studies") or []
    st.write("Studies the author named: " + (", ".join(studies) if studies else "none named"))
    if request.get("study_exclusions"):
        st.write("**Study-only exclusions**")
        st.table(request["study_exclusions"])
    configuration_proposal_page._impact(request.get("impact") or {})
    checks = request.get("validation", {}).get("checks") or []
    st.caption("Validators at submission: " + (", ".join(f"{c['validator']} {'passed' if c['passed'] else 'failed'}" for c in checks) if checks else "none recorded") + ".")
    if checks or request.get("validation", {}).get("caveats"):
        with st.expander("Validation details at submission"):
            _validation_checks(checks)
            for caveat in request.get("validation", {}).get("caveats") or []:
                st.info(str(caveat))
    _validation(view.get("validation"))
    st.divider()
    _decision_forms(root, pack, actor_id, view, allowed_packs=allowed_packs, local_demo=local_demo,
                    can_write=can_write, can_review=can_review)
    return None
