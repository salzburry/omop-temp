"""Required product answers explicitly declared by a selected master template.

Slot names and illustrative examples never create requirements or supply answers.
The library must name an editable scientific field and set required to true.
"""
from __future__ import annotations


SCIENCE_FIELDS = frozenset({
    "derivation", "grain", "anchor", "window", "record_selection", "tie_break",
    "cohort_applicability", "missing", "units", "acceptance", "notes",
    "source.value", "source.kind", "output.type", "output.codes", "output.nullable",
    "decision_ids", "gap_ids",
})
_LABELS = {"output.codes": "Output codes / age groups", "window": "Baseline / eligible window",
           "anchor": "Anchor date or event", "derivation": "Definition / logic / formula",
           "source.value": "Value for this product", "output.type": "Data type",
           "source.kind": "Variable kind", "output.nullable": "Can the result be missing?"}
_EMPTY = {"", "todo", "tbd", "replace_me", "none", "null", "n/a", "undecided", "not applicable", "not sure yet"}


def field_path(value):
    """Validate an explicitly declared scientific field without guessing a path."""
    return value.strip() if isinstance(value, str) and value.strip() in SCIENCE_FIELDS else ""


def fields(row, master=None):
    """Return bound slots of the chosen master; old unbound slots remain optional."""
    if master is None:
        master = row.get("master") if row.get("master_name") else None
    if not isinstance(master, dict):
        return []
    slots = master.get("parameter_slots") or []
    if isinstance(slots, dict):
        slots = [{**value, "name": name} for name, value in slots.items() if isinstance(value, dict)]
    if not isinstance(slots, list):
        return []
    result = []
    for slot in slots:
        if not isinstance(slot, dict) or not isinstance(slot.get("name"), str) or not slot["name"].strip():
            continue
        path = field_path(slot.get("field") or slot.get("path"))
        if not path:
            continue
        result.append({"name": slot["name"].strip(), "description": str(slot.get("description") or ""),
                       "field": path, "required": slot.get("required") is True})
    return result


def _answered(value):
    if isinstance(value, str):
        return value.strip().casefold() not in _EMPTY
    if isinstance(value, dict):
        return bool(value) and all(_answered(item) for item in value.values())
    if isinstance(value, list):
        return bool(value) and all(_answered(item) for item in value)
    return type(value) in {bool, int, float}


def issues(row, master=None):
    """Report missing required field answers without changing any draft value."""
    problems = []
    for slot in fields(row, master):
        if not slot["required"]:
            continue
        value = row.get("values") or {}
        for part in slot["field"].split("."):
            value = value.get(part) if isinstance(value, dict) else None
        if not _answered(value):
            label = _LABELS.get(slot["field"], slot["field"].replace("_", " ").capitalize())
            problems.append(f"Enter {label} for the selected master's required {slot['name']} parameter.")
    return list(dict.fromkeys(problems))
