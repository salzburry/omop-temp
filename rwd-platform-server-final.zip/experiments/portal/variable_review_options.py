"""Names for review controls from one product's declared metadata.

These are possible choices, not mappings, verified delivery columns or approvals.
The reader uses canonical config/source-contract readers and the current product's
contract naming axis. It never scans data, follows profile folders, connects to a
database, or validates a disposable checkout.
"""
from __future__ import annotations

from collections import OrderedDict
from copy import deepcopy
from pathlib import Path
import re
from threading import Lock

import yaml

import scientific_definitions as definitions
from spec_extract import requirement_rows, row_item_id

LIMIT = 16 * 1024 * 1024
CACHE_SIZE = 12
_CACHE = OrderedDict()
_CACHE_LOCK = Lock()
FIXED = ("config/data_product.yaml", "config/pipeline.yaml", "config/source_adapters.yaml",
         "handoff/FUNCTIONAL_CONTRACT.md", "spec_pipeline/out/extracted.json")
EXCLUDED_PARAMETER_ROOTS = {
    "run", "formats", "sources", "source_union", "source_grain", "source_availability",
    "variables", "codelists", "credentials", "connections", "auth", "secrets", "tokens",
    "description", "name", "owner", "version", "status", "data_product_id", "vendor",
    "condition_class", "tumor_class", "request_type", "deliverables", "qc", "golden",
}
IDENTIFIER = re.compile(r"[A-Za-z_][A-Za-z0-9_]*")


def _name(value):
    if not isinstance(value, str):
        return ""
    value = value.strip()
    if not value or definitions._placeholder(value) or value.casefold() in {"none", "n/a", "null", "undecided"}:
        return ""
    if re.search(r"(?:^|[^A-Za-z0-9])(?:TODO|TBD|REPLACE_ME)(?:$|[^A-Za-z0-9])", value, re.I):
        return ""
    if len(value) > 300 or any(ord(char) < 32 for char in value):
        return ""
    return value


def _sorted(values):
    return sorted({_name(value) for value in values if _name(value)}, key=str.casefold)


def _yaml(raw, relative):
    try:
        doc = yaml.load(raw, Loader=definitions.details._StrictLoader)
    except yaml.YAMLError as error:
        raise ValueError("Repair " + relative + " before loading its declared choices.") from error
    if not isinstance(doc, dict):
        raise ValueError(relative + " must contain a YAML mapping before its choices can be read.")
    return doc


def _capture(product):
    files = {}
    for relative in FIXED:
        path = definitions._safe(product / relative)
        files[relative] = definitions._read(path) if path.exists() else None
    if files["config/data_product.yaml"] is None:
        raise ValueError("Create the product configuration before loading declared review choices.")
    for relative in FIXED[:2]:
        if files[relative] is None:
            continue
        doc = _yaml(files[relative], relative)
        variables, codelists = doc.get("variables") or [], doc.get("codelists") or {}
        if not isinstance(variables, list) or not isinstance(codelists, dict):
            raise ValueError("Declare variable files as a list and codelist files as a mapping.")
        for reference in [*variables, *codelists.values()]:
            if not isinstance(reference, str) or not reference or Path(reference).is_absolute() or ".." in Path(reference).parts:
                raise ValueError("A metadata reference leaves the selected product. Repair its local path before choosing fields.")
            path = definitions._safe(product / reference)
            if not path.is_relative_to(product) or path.suffix.lower() not in {".yaml", ".yml"}:
                raise ValueError("Review choices can read only declared YAML metadata inside the selected product.")
            files[path.relative_to(product).as_posix()] = definitions._read(path) if path.exists() else None
    if sum(len(raw) for raw in files.values() if raw is not None) > LIMIT:
        raise ValueError("The declared review metadata exceeds the 16 MB lookup limit.")
    return files


def _digest(files):
    return definitions._hash({name: definitions._hash(raw) if raw is not None else None for name, raw in files.items()})


def _leaf_parameters(value, prefix=""):
    """Dotted paths only; parameter values never leave the metadata reader."""
    result = set()
    if isinstance(value, dict):
        for name, child in value.items():
            if not isinstance(name, str) or not IDENTIFIER.fullmatch(name):
                continue
            path = prefix + "." + name if prefix else name
            if isinstance(child, dict):
                result.update(_leaf_parameters(child, path))
            elif prefix and not isinstance(child, list):
                result.add(path)
    return result


def _read_options(product, files):
    from engine.config import load_config, canonical_physical
    from engine import source_contract
    from engine.validate import emitted_variables
    from source_check import config_base

    warnings = []
    cfg = load_config(str(product / "config/data_product.yaml"))
    # Preload the files captured above so the canonical metadata readers cannot
    # follow an uncaptured file during compilation. No runtime is initialized.
    variable_docs = {}
    for reference in cfg.raw.get("variables") or []:
        relative = Path(reference).as_posix()
        raw = files.get(relative)
        if raw is None:
            warnings.append(relative + " is missing; use Custom where its choices are unavailable.")
            continue
        variable_docs[relative] = _yaml(raw, relative)
    cfg._packs_by_role = {Path(relative).stem: doc for relative, doc in variable_docs.items()}
    cfg._packs = {str(doc.get("pack_id") or Path(relative).stem): doc for relative, doc in variable_docs.items()}
    cfg._codelists = {}
    for name, reference in (cfg.raw.get("codelists") or {}).items():
        relative = Path(reference).as_posix()
        cfg._codelists[name] = _yaml(files[relative], relative) if files.get(relative) is not None else {}

    compiled = source_contract.compiled(cfg)
    tables = {}
    # A contract claim or an unbound adapter can be offered for editing without
    # certifying itself as an executable source mapping. Keep this authority
    # separate from the union of suggestions shown in the controls.
    configured_sources = {}

    def table(alias, stem=""):
        alias = _name(alias)
        if not alias:
            return None
        entry = tables.setdefault(alias, {"alias": alias, "stems": set(), "columns": set(), "roles": set(),
                                           "role_columns": {}, "basis": set()})
        if isinstance(stem, dict):
            stem = stem.get("table") or stem.get("physical_table")
        if _name(stem):
            entry["stems"].add(_name(stem))
        return entry

    for alias, record in compiled["roles"].items():
        if not record["declared"]:
            continue
        entry = table(alias, record.get("physical"))
        if entry is None:
            continue
        expected = _sorted([*record.get("required_columns", []), *record.get("optional_columns", []), *record.get("grain", [])])
        physical = canonical_physical(cfg, alias)
        role_columns = {}
        for logical in expected:
            column = _name(physical.get(logical.lower()) or logical)
            if column:
                entry["columns"].add(column)
                entry["roles"].add(logical)
                entry["role_columns"].setdefault(logical, set()).add(column)
                role_columns[logical] = _sorted([logical, column])
        for logical, column in physical.items():
            if _name(logical) and _name(column):
                role_columns.setdefault(logical, _sorted([logical, column]))
        base = _name(config_base(cfg, alias))
        if base:
            entry["stems"].add(base)
        configured_sources[alias] = {
            "physical_stem": base,
            "configured_table": _name(record.get("physical")),
            "role_columns": role_columns,
            "columns": _sorted(column for names in role_columns.values() for column in names),
        }
        entry["basis"].add("Configured source requirements")

    adapter_raw = files.get("config/source_adapters.yaml")
    if adapter_raw is not None:
        adapters = _yaml(adapter_raw, "config/source_adapters.yaml").get("adapters")
        if not isinstance(adapters, list):
            raise ValueError("config/source_adapters.yaml needs its declared adapters list.")
        for adapter in adapters:
            if not isinstance(adapter, dict):
                raise ValueError("Every source adapter must contain a mapping of its declared fields.")
            entry = table(adapter.get("logical_role"), adapter.get("physical_table"))
            if entry is None:
                continue
            columns = adapter.get("required_columns") or {}
            if not isinstance(columns, dict):
                raise ValueError("Adapter required_columns must map logical column names to their declarations.")
            for logical, declaration in columns.items():
                if not isinstance(declaration, dict):
                    raise ValueError("Each adapter column needs its declared physical column metadata.")
                column = _name(declaration.get("physical"))
                logical = _name(logical)
                if logical:
                    entry["roles"].add(logical)
                if column:
                    entry["columns"].add(column)
                    if logical:
                        entry["role_columns"].setdefault(logical, set()).add(column)
            entry["basis"].add("Declared source adapter; review remains separate")

    variables, spec_ids, outputs, published, parameters = set(), set(), set(), set(), set()
    for name, value in cfg.raw.items():
        if name not in EXCLUDED_PARAMETER_ROOTS and isinstance(value, dict):
            parameters.update(_leaf_parameters(value, name))
    configured_parameters = _sorted(parameters)
    contract = files.get("handoff/FUNCTIONAL_CONTRACT.md")
    if contract is not None:
        for block in definitions.cl.records(contract.decode("utf-8")):
            variable = definitions.cl._scalar(block, "variable_id")
            variables.add(variable)
            record = definitions.cl.parse_block(block)
            output = definitions._as_mapping(definitions.cl._scalar(block, "output")) or record.output
            outputs.add(output.get("physical_name"))
            published.add(output.get("target_published_name"))
            source = definitions._as_mapping(definitions.cl._scalar(block, "source")) or record.source
            refs = source.get("parameters") or []
            if isinstance(refs, str):
                refs = yaml.safe_load(refs) if refs.strip().startswith("[") else []
            if isinstance(refs, list):
                parameters.update(ref for ref in refs if isinstance(ref, str))
            ids = source.get("spec_identifiers") or []
            if isinstance(ids, list):
                spec_ids.update(value for value in ids if isinstance(value, str))
            entry = table(source.get("logical_table"), source.get("physical_stem"))
            columns = source.get("columns") or {}
            if entry is not None and isinstance(columns, dict):
                for logical, column in columns.items():
                    if _name(logical):
                        entry["roles"].add(logical)
                    if _name(column):
                        entry["columns"].add(column)
                        entry["role_columns"].setdefault(logical, set()).add(column)
                entry["basis"].add("Current product functional contract")

    extracted = files.get("spec_pipeline/out/extracted.json")
    if extracted is not None:
        data = definitions._json(extracted)
        if not isinstance(data, dict) or not isinstance(data.get("rows"), list):
            raise ValueError("The current extraction needs its envelope and rows list before identifier choices can be read.")
        for row in requirement_rows(data):
            spec_ids.add(row_item_id(row))
            variable = str(row.get("variable") or "").strip()
            if IDENTIFIER.fullmatch(variable):
                variables.add(variable)
                spec_ids.add(variable)
            else:
                explicit = re.search(r"\(\s*([A-Za-z][A-Za-z0-9_]*)\s*\)\s*$", variable)
                if explicit:
                    variables.add(explicit[1])
                    spec_ids.add(explicit[1])
    else:
        warnings.append("Specification identifiers will appear after the current specification is extracted.")
    outputs.update(emitted_variables(cfg))
    variables.update(outputs)

    table_rows, columns_by_table, roles_by_table = [], {}, {}
    for entry in sorted(tables.values(), key=lambda item: item["alias"].casefold()):
        columns, roles = _sorted(entry["columns"]), _sorted(entry["roles"])
        stems = _sorted(entry["stems"])
        for name in [entry["alias"], *stems]:
            columns_by_table[name] = _sorted([*columns_by_table.get(name, []), *columns])
            roles_by_table[name] = _sorted([*roles_by_table.get(name, []), *roles])
        table_rows.append({"alias": entry["alias"], "logical_table": entry["alias"], "table_stems": stems,
                           "physical_stem": stems[0] if len(stems) == 1 else "", "columns": columns,
                           "column_roles": roles, "role_columns": {key: _sorted(value) for key, value in entry["role_columns"].items()},
                           "basis": sorted(entry["basis"])})
    if not tables:
        warnings.append("No source table metadata is declared yet. Use Custom to enter the reviewed table and columns.")
    if tables and not any(columns_by_table.values()):
        warnings.append("Column metadata is not declared yet. Use Custom to enter reviewed source columns.")
    return {"ok": True, "errors": [], "warnings": warnings, "tables": table_rows,
            "aliases": _sorted(tables), "table_stems": _sorted(stem for entry in tables.values() for stem in entry["stems"]),
            "columns_by_table": columns_by_table, "column_roles": _sorted(role for entry in tables.values() for role in entry["roles"]),
            "roles_by_table": roles_by_table, "input_variables": _sorted(variables), "parameters": _sorted(parameters),
            "spec_identifiers": _sorted(spec_ids), "output_names": _sorted(outputs), "published_names": _sorted(published),
            "source_paths": sorted(name for name, raw in files.items() if raw is not None),
            "configured_sources": configured_sources, "configured_parameters": configured_parameters,
            "metadata_only": True, "approval_created": False}


def describe(root, pack, actor_id, *, allowed_packs=None):
    try:
        product, pack, _owner, _folder = definitions._scope(root, pack, actor_id, allowed_packs)
        files = _capture(product)
        digest = _digest(files)
        key = (str(product), digest)
        with _CACHE_LOCK:
            cached = _CACHE.get(key)
            if cached is not None:
                _CACHE.move_to_end(key)
                return deepcopy(cached)
        report = _read_options(product, files)
        if _digest(_capture(product)) != digest:
            raise ValueError("Product metadata changed while choices loaded. Reload the current review table.")
        report["input_digest"] = digest
        report["pack"] = pack
        with _CACHE_LOCK:
            _CACHE[key] = deepcopy(report)
            _CACHE.move_to_end(key)
            while len(_CACHE) > CACHE_SIZE:
                _CACHE.popitem(last=False)
        return report
    except (ValueError, TypeError, KeyError, AttributeError, OSError, RecursionError, yaml.YAMLError, definitions.dw._DraftError) as error:
        return {"ok": False, "errors": [str(error)], "warnings": [], "aliases": [], "table_stems": [],
                "columns_by_table": {}, "column_roles": [], "roles_by_table": {}, "tables": [],
                "input_variables": [], "parameters": [], "spec_identifiers": [], "output_names": [],
                "published_names": [], "source_paths": [], "configured_sources": {}, "configured_parameters": [],
                "metadata_only": True, "approval_created": False}
