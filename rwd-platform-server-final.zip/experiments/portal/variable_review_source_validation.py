"""Cheap source-review checks against the selected product's executable metadata.

These checks establish that a mapping can be asked of the engine. They make no
claim about a delivered table's actual presence, data types, or live schema.
Unknown names stay editable drafts until their declaration is resolved.
"""
from __future__ import annotations

from copy import deepcopy
import re

import contract_lint
import source_check


def _text(value):
    return value.strip() if isinstance(value, str) else ""


def _answered(value):
    if isinstance(value, (list, dict)):
        return bool(value)
    return bool(_text(value)) and _text(value).casefold() not in {
        "todo", "tbd", "replace_me", "undecided", "none", "n/a", "null"}


def _choices(values):
    values = sorted(set(values), key=str.casefold)
    return ", ".join(values[:12]) + (" …" if len(values) > 12 else "") or "none declared yet"


def _column_issues(alias, columns, configured):
    declared = configured.get(alias)
    if declared is None:
        return [f"Source alias '{alias}' is not configured for this product. Choose a Source alias from "
                f"{_choices(configured)}, or declare the new source in Configuration before completing this review."]
    if not declared.get("physical_stem"):
        return [f"Source alias '{alias}' still has an unfinished table name in Configuration. "
                "Complete that table declaration before completing this source mapping."]
    if not isinstance(columns, dict) or not columns:
        return [f"Map at least one column role and source column for '{alias}'."]
    role_columns = {str(role).casefold(): list(names) for role, names in declared.get("role_columns", {}).items()}
    result = []
    for role, column in columns.items():
        role, column = _text(role), _text(column)
        if not _answered(role) or not _answered(column):
            result.append(f"Complete both the column role and source column for '{alias}'.")
            continue
        if not re.fullmatch(r"[A-Za-z_][A-Za-z0-9_]*", column):
            result.append(f"Source column '{column}' in '{alias}' must be one column name. "
                          "Put expressions in the scientific logic or choose Product setting for a configuration value.")
            continue
        allowed = role_columns.get(role.casefold())
        if allowed is None:
            result.append(f"Column role '{role}' is not declared for '{alias}'. Choose a Column role from "
                          f"{_choices(role_columns)}, or declare this role in Source adapters before completing this review.")
        elif column.casefold() not in {name.casefold() for name in allowed}:
            result.append(f"Column role '{role}' in '{alias}' maps to {_choices(allowed)}, not '{column}'. "
                          "Choose its declared Source column or update the source mapping in Configuration / Source adapters.")
    return result


def issues(row, metadata):
    """Return unresolved source questions; never mutate the row or its metadata."""
    values = row.get("values") or {}
    source = deepcopy(values.get("source") or {})
    if not isinstance(source, dict):
        return ["Choose and complete a structured source mapping for this variable."]
    kind = source.get("kind")
    if kind not in {"vendor", "derived", "parameter", "constant", "unavailable", "pending_mapping"}:
        return []  # The workflow owns the missing-kind question.
    # The single-table editor has no linked inputs. Canonical serializers omit
    # empty inputs, because the downstream parser treats a present empty map as
    # a claimed but malformed structured mapping.
    if source.get("inputs") in (None, {}, [], ""):
        source.pop("inputs", None)
    rendered = contract_lint.render_table([{
        "variable_id": values.get("variable_id") or row.get("variable_id") or "REVIEW_ROW",
        "source": source, "depends_on": values.get("depends_on") or [],
    }])
    parsed = source_check.parse_sources(rendered)
    defects = [f"Source fields conflict: {record[4]}. Edit Source kind and its associated fields."
               for record in parsed if record[1] in {"bad_shape", "unparseable"}]
    if defects:
        return defects
    if kind in {"constant", "unavailable", "pending_mapping"}:
        return []
    if not metadata or not metadata.get("ok"):
        detail = "; ".join(str(error) for error in (metadata or {}).get("errors", [])[:2])
        return ["Declared source metadata could not be checked. Keep this draft and repair the product metadata "
                "in Configuration, then reload this table." + (" " + detail if detail else "")]
    if kind == "parameter":
        declared = set(metadata.get("configured_parameters", []))
        return [f"Product setting '{path}' is not declared in this product's configuration. "
                "Choose a Product settings used option or add the setting in Configuration."
                for path in source.get("parameters") or [] if path not in declared]
    if kind == "derived":
        known = {str(name).casefold() for name in metadata.get("input_variables", [])}
        result = [f"Dependency '{name}' is not a declared variable in this product. Choose a Dependencies option "
                "or add and define that variable before completing this review."
                for name in values.get("depends_on") or [] if str(name).casefold() not in known]
        own_name = str(values.get("variable_id") or row.get("variable_id") or "").casefold()
        if own_name and any(str(name).casefold() == own_name for name in values.get("depends_on") or []):
            result.append("A calculated variable cannot depend on itself. Choose the input variables used by this calculation.")
        return result
    configured = metadata.get("configured_sources", {})
    inputs = source.get("inputs")
    result = []
    if inputs:
        normalized_inputs = {_text(alias).lower(): columns for alias, columns in inputs.items()}
        if len(normalized_inputs) != len(inputs):
            result.append("A source alias is repeated with different capitalization. Keep one mapping for each source input.")
        for alias, columns in inputs.items():
            result.extend(_column_issues(_text(alias).lower(), columns, configured))
        primary = source_check.logical_parts(_text(source.get("logical_table")))
        if source.get("columns") and (len(primary) != 1 or normalized_inputs.get(primary[0]) != source["columns"]):
            result.append("Linked source mappings must include the main source alias and its exact column mappings. "
                          "Add the main source alongside the linked sources; otherwise the downstream check skips it.")
    else:
        aliases = source_check.logical_parts(_text(source.get("logical_table")))
        if len(aliases) != 1:
            if aliases:
                result.append("Map each source alias separately under Source inputs so every column has one table. "
                              "A combined alias leaves the column's source ambiguous.")
            return result
        result.extend(_column_issues(aliases[0], source.get("columns"), configured))
    aliases = [_text(alias).lower() for alias in inputs] if inputs else source_check.logical_parts(_text(source.get("logical_table")))
    stem = _text(source.get("physical_stem"))
    if len(aliases) == 1 and stem and aliases[0] in configured:
        expected = configured[aliases[0]].get("physical_stem")
        # Match source_check's interpretation of physical_stem, including its
        # accepted refresh suffix, rather than inventing a second table rule.
        actual = source_check.CUT.sub("", stem.casefold())
        if expected and actual != expected.casefold():
            result.append(f"Source table name '{stem}' disagrees with alias '{aliases[0]}', which resolves to "
                          f"'{expected}'. Select '{expected}' or clear Source table name to use the configured alias.")
    return list(dict.fromkeys(result))
