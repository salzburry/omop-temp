"""Actor-scoped, immutable revisions of saved synthetic rehearsals.

Scientists edit literal draft interpretations. The specification's own text and
the executable example stay separate; neither is rewritten from free text.
"""
from __future__ import annotations

import hashlib
import json
import os
import re
import shutil
import uuid
from pathlib import Path

import yaml

import demo_journey as journeys
import design_workspace as design


DRAFT_STATUS = {"requirement": "draft", "source": "unverified",
                "implementation": "not_implemented", "validation": "not_run"}
EXECUTION_SCOPE = ("Extract the saved synthetic workbook, regenerate review artifacts using the revised "
                   "draft interpretations, check the draft contract and check the saved example configuration. "
                   "Section, source and new-variable proposals require engineering review before implementation.")
DRAFT_REGISTERS = {
    "DECISIONS.md": ("# Synthetic draft questions\n\nNo decisions or scientific approvals are carried forward. "
                     "Draft interpretations still require scientific review.\n\n"
                     "| ID | Question | Evidence | Owner | Resolution | Approved by | Approval date | Status |\n"
                     "|---|---|---|---|---|---|---|---|\n"),
    "ENGINE_GAPS.md": ("# Synthetic draft engineering gaps\n\nNo resolved gaps or implementation claims are carried forward. "
                       "Proposed engineering work is recorded in plan.json.\n\n"
                       "| Gap ID | What is not met |\n|---|---|\n"),
}


def _digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, ensure_ascii=False,
                                     separators=(",", ":")).encode("utf-8")).hexdigest()


def _text(value, label, maximum, *, empty=False, strip=True):
    if (not isinstance(value, str) or len(value) > maximum
            or any(ord(c) < 32 and c not in "\n\r\t" for c in value)
            or (not empty and not value.strip())):
        raise ValueError(f"{label} must be {'optional ' if empty else ''}plain text of at most {maximum} characters.")
    return value.strip() if strip else value


def _tracked_inputs(folder, record):
    """Verify all worker-readable inputs, including unexpected added config files."""
    product = journeys._canonical(folder / record["product"], folder)
    allowed = {"source_refs.yaml", "spec_pipeline/pipeline.conf", "handoff/FUNCTIONAL_CONTRACT.md",
               "prog_spec/" + Path(record["example"]["workbook"]).name}
    if record.get("revision_of"):
        allowed.update("handoff/" + name for name in DRAFT_REGISTERS)
        allowed.add("handoff/tests/test_functional_contract.py")
    for directory in ("config", "variables", "codelists"):
        base = product / directory
        if base.exists():
            journeys._canonical(base, folder)
            for path in base.rglob("*"):
                journeys._canonical(path, folder)
                if path.is_file():
                    if path.suffix.lower() not in {".yaml", ".yml", ".csv", ".tsv"} or path.name.startswith("."):
                        raise ValueError("An unsupported file was added to the saved example inputs.")
                    allowed.add(path.relative_to(product).as_posix())
    expected = {f"{record['product']}/{relative}" for relative in allowed}
    if set(record["input_sha256"]) != expected:
        raise ValueError("The saved input inventory changed. Reopen an unchanged saved rehearsal.")
    for relative, digest in record["input_sha256"].items():
        path = journeys._canonical(folder / relative, product)
        if path.stat().st_size > 4 * 1024 * 1024 or journeys._sha(path) != digest:
            raise ValueError("A saved rehearsal input changed. Reopen an unchanged rehearsal before editing.")
    # Generated directories cannot redirect later readers or workers either.
    for path in product.rglob("*"):
        journeys._canonical(path, folder)
        if (path.is_file() and path.relative_to(folder).as_posix() not in expected
                and path.relative_to(product).parts[:2] != ("spec_pipeline", "out")):
            raise ValueError("An untracked file was added to the saved rehearsal. Reopen an unchanged draft.")
    source = yaml.safe_load((product / "source_refs.yaml").read_text(encoding="utf-8"))
    materials = source.get("source_materials", []) if isinstance(source, dict) else []
    if len(materials) != 1 or not isinstance(materials[0], dict):
        raise ValueError("The saved rehearsal must identify its single synthetic workbook.")
    workbook = product / "prog_spec" / Path(record["example"]["workbook"]).name
    if (journeys._canonical(materials[0].get("path_or_link", ""), product) != workbook
            or materials[0].get("sha256") != journeys._sha(workbook)):
        raise ValueError("The saved source registration does not match its isolated workbook.")
    return product


def _definition_rows(product, record):
    rows = [(row, "existing") for row in design.cl.typed_records(
        design.cl.read(str(product / "handoff/FUNCTIONAL_CONTRACT.md")), keep_unnamed=True)]
    used_outputs = {}
    if record["stage"] == "complete":
        # Regenerate the machine-owned cells from the registered, hashed workbook.
        # Older saved runs did not record output digests, so merely trusting their
        # scaffold JSON could otherwise turn an altered output into a new source.
        import contract_scaffold
        import run_spec_pipeline
        import spec_extract
        import spec_lint

        conf = run_spec_pipeline.read_conf(str(product / "spec_pipeline/pipeline.conf"))
        workbook = product / "prog_spec" / Path(record["example"]["workbook"]).name
        extracted = spec_extract.extract(str(workbook),
            dict(spec_extract.shared_domains(), **spec_extract.parse_domains(conf["DOMAINS"])),
            spec_extract.parse_ignore(conf["IGNORE"]))
        tabs = conf["TABS"].split(",") if conf["TABS"] else None
        findings = spec_lint.scan(extracted, conf["TUMOR"], tabs)
        scaffold = contract_scaffold.scaffold(extracted, str(product), findings, tabs)
        out = product / "spec_pipeline/out"
        saved = journeys._read(out / "scaffold.json")
        if _digest(saved.get("records")) != _digest(scaffold["records"]):
            raise ValueError("The saved generated definitions changed or are stale. Re-run the saved draft before editing its generated definitions.")
        for name in ("extracted.json", "lint.json", "scaffold.json"):
            path = journeys._canonical(out / name, product)
            used_outputs[name] = journeys._sha(path)
        rendered = contract_scaffold.to_contract_records(scaffold["records"])
        rows += [(row, "scaffold") for row in design.cl.typed_records(rendered, keep_unnamed=True)]
    public, cells_by_key = [], {}
    for row, origin in rows:
        refs = [str(ref) for ref in row.spec_refs]
        # Citations distinguish duplicate workbook identifiers; no row is selected
        # or updated solely by the human-facing variable name.
        key = _digest({"spec_refs": refs} if refs else {"variable_id": row.variable_id})[:24]
        if not row.variable_id or key in cells_by_key:
            raise ValueError("The saved definitions have ambiguous record identities; include this issue in the engineering handoff.")
        public.append({"key": key, "variable_id": row.variable_id,
                       "domain": row.spec_refs[0].domain if row.spec_refs else "other",
                       "spec_refs": refs, "source_definition": row.cells.get("required_rule", ""),
                       "definition": row.cells.get("derivation", ""), "origin": origin})
        cells_by_key[key] = dict(row.cells)
    return public, cells_by_key, used_outputs


def _snapshot(root, state_root, actor_id, run_id):
    loaded = journeys.read_run(root, state_root, actor_id, run_id)
    if not loaded["ok"]:
        raise ValueError(loaded["errors"][0])
    record = loaded["run"]
    if record["stage"] == "running":
        raise ValueError("This rehearsal is running. Open its saved result when the run finishes before editing.")
    folder = journeys._folder(root, state_root, actor_id, run_id)
    product = _tracked_inputs(folder, record)
    if journeys._read(folder / "plan.json") != record["plan"]:
        raise ValueError("The saved plan changed. Reopen the rehearsal before editing.")
    definitions, cells, outputs = _definition_rows(product, record)
    base = _digest({"record": journeys._sha(folder / "rehearsal.json"),
                    "plan": journeys._sha(folder / "plan.json"), "inputs": record["input_sha256"],
                    "definition_outputs": outputs})
    return record, folder, product, definitions, cells, base


def read_editor(root, state_root, actor_id, run_id):
    """Read editable interpretations beside the original literal source definition."""
    try:
        record, _, _, definitions, _, base = _snapshot(root, state_root, actor_id, run_id)
        return {"ok": True, "run": record, "definitions": definitions,
                "base_sha256": base, "errors": []}
    except (OSError, ValueError, TypeError, KeyError, yaml.YAMLError) as error:
        return journeys._error(error)


def revise(root, state_root, actor_id, run_id, *, base_sha256, label, purpose, studies=(),
           sections=None, additions=(), proposed_source="flatiron", proposed_modality="ehr",
           definitions=(), local_demo=False, can_write=False):
    """Create a linked prepared run from the exact saved inputs reviewed in the editor."""
    if not local_demo or not can_write:
        return journeys._error("Editing a rehearsal requires product-author access in a local demo.")
    lock_fd = None
    child_folder = None
    try:
        folder = journeys._folder(root, state_root, actor_id, run_id)
        lock = journeys._canonical(folder / ".running", folder)
        try:
            lock_fd = os.open(lock, os.O_CREAT | os.O_EXCL | os.O_WRONLY)
        except FileExistsError:
            raise ValueError("This rehearsal is already running or being revised. Reopen it when the operation finishes.") from None
        parent, _, source, before, cells, actual_base = _snapshot(root, state_root, actor_id, run_id)
        if not isinstance(base_sha256, str) or base_sha256 != actual_base:
            raise ValueError("This rehearsal changed since the editor opened. Reopen it and review the latest draft before saving.")
        label = _text(label, "Rehearsal name", 120)
        purpose = _text(purpose, "Study question", 4000)
        proposed_source = _text(proposed_source, "Proposed source", 120)
        if proposed_modality not in {"ehr", "claims"}:
            raise ValueError("Choose EHR or claims for the proposed source type.")
        if not isinstance(studies, (tuple, list)) or len(studies) > 30:
            raise ValueError("Use at most 30 intended studies.")
        studies = [_text(item, "Study name", 300) for item in studies]
        sections = journeys.SECTIONS[:] if sections is None else sections
        if (not isinstance(sections, (tuple, list)) or not all(isinstance(item, str) for item in sections)
                or not set(sections).issubset(journeys.SECTIONS) or len(set(sections)) != len(sections)):
            raise ValueError("Choose each proposed section once from the example list.")
        if not isinstance(additions, (tuple, list)) or len(additions) > 30:
            raise ValueError("Use at most 30 proposed additions.")
        clean_additions = []
        for item in additions:
            if not isinstance(item, dict) or set(item) != {"variable_id", "domain", "definition"}:
                raise ValueError("Each proposed addition needs a variable identifier, section and literal definition.")
            identifier = _text(item["variable_id"], "Variable identifier", 80)
            if not re.fullmatch(r"[A-Za-z][A-Za-z0-9_]*", identifier) or item["domain"] not in journeys.SECTIONS:
                raise ValueError("Use a simple variable identifier and one of the supported sections.")
            clean_additions.append({"variable_id": identifier, "domain": item["domain"],
                                    "definition": _text(item["definition"], "Proposed definition", 4000, strip=False)})
        if (not isinstance(definitions, (tuple, list)) or len(definitions) != len(before)
                or any(not isinstance(item, dict) or set(item) != {"key", "definition"}
                       or not isinstance(item["key"], str) for item in definitions)):
            raise ValueError("Save the complete set of editable definitions, using only the record key and interpretation text.")
        edited = {item["key"]: _text(item["definition"], "Draft interpretation", 8000, strip=False) for item in definitions}
        if len(edited) != len(definitions) or set(edited) != set(cells):
            raise ValueError("The edited definition keys do not match this saved draft. Reopen the editor.")
        records, changes, handoffs = [], [], []
        for row in before:
            value = edited[row["key"]]
            changed = value != row["definition"]
            if row["origin"] == "scaffold" and not changed:
                continue
            draft = dict(cells[row["key"]])
            draft.update(derivation=value, status=DRAFT_STATUS.copy(), decision_ids=[], gap_ids=[])
            if changed:
                draft["implementation_refs"] = "[none]"
                changes.append({"key": row["key"], "variable_id": row["variable_id"], "domain": row["domain"],
                                "origin": row["origin"], "before": row["definition"], "after": value})
                handoffs.append({"kind": "derivation", "variable_id": row["variable_id"],
                                 "detail": "Review this draft interpretation, resolve scientific details and implement its accepted executable derivation; this rehearsal changed only literal draft text."})
            records.append(draft)
        description = journeys._describe_copy(source, parent["example"], parent["input_sha256"])
        retained = [row["variable_id"] for row in description["rows"] if row["domain"] in sections]
        review = design.build_plan(description, retained, clean_additions, purpose, studies,
                                   proposed_source, proposed_modality)
        if clean_additions:
            handoffs.append({"kind": "new_variables", "detail": "Review source evidence and implement accepted new-variable derivations; additions remain proposals."})
        if set(sections) != set(journeys.SECTIONS):
            handoffs.append({"kind": "sections", "detail": "Review dependencies and consumer impact before changing executable section selection."})
        if review.get("source_changed"):
            handoffs.append({"kind": "source", "detail": "Review access, mapping, cohort and outcome validation for the proposed source; this run uses the saved synthetic workbook and bindings."})
        plan = {"journey": parent["journey"], "purpose": purpose, "studies": studies,
                "retained_sections": list(sections), "removed_sections": [s for s in journeys.SECTIONS if s not in sections],
                "proposed_additions": clean_additions, "proposed_source": proposed_source,
                "proposed_modality": proposed_modality, "applied_to_execution": False,
                "draft_interpretations_applied": bool(changes), "definition_changes": changes,
                "definition_review": review, "engineering_handoff": handoffs,
                "execution_scope": EXECUTION_SCOPE, "notice": journeys.NOTICE}
        if not clean_additions and set(sections) == set(journeys.SECTIONS) and not review.get("source_changed"):
            # A label, intended-study or literal draft edit is a valid rehearsal
            # revision. The product-change planner's 'no change selected' error
            # is irrelevant when no section/source/addition was requested.
            plan.pop("definition_review")
        child_id = uuid.uuid4().hex
        child_folder = journeys._folder(root, state_root, actor_id, child_id)
        child_folder.mkdir(parents=True)
        product = child_folder / parent["product"]
        for relative in parent["input_sha256"]:
            original = journeys._canonical(folder / relative, source)
            target = journeys._canonical(child_folder / relative, child_folder)
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(original, target)
        source_doc = yaml.safe_load((product / "source_refs.yaml").read_text(encoding="utf-8"))
        material = source_doc["source_materials"][0]
        for field in ("approved_by", "approval_date", "object_uuid"):
            material.pop(field, None)
        material.update(path_or_link=str(product / "prog_spec" / Path(parent["example"]["workbook"]).name),
                        status="pending", why_provisional=journeys.NOTICE)
        (product / "source_refs.yaml").write_text(yaml.safe_dump(source_doc, sort_keys=False), encoding="utf-8")
        contract = ("# Synthetic rehearsal draft\n\nDraft interpretations are authored for scientific review. "
                    "The original specification wording is preserved. No approvals or validation status carry forward.\n\n")
        if records:
            contract += design.cl.render_table(records)
        (product / "handoff/FUNCTIONAL_CONTRACT.md").write_text(contract, encoding="utf-8")
        for name, content in DRAFT_REGISTERS.items():
            (product / "handoff" / name).write_text(content, encoding="utf-8")
        # contract_lint.pack_floors reads this literal declaration, never imports
        # the file. A draft has no carried decisions/gaps; its record count is a
        # real parser tripwire. No user-authored Python is accepted or copied.
        floors_path = product / "handoff/tests/test_functional_contract.py"
        floors_path.parent.mkdir(exist_ok=True)
        floors_path.write_text("# Generated synthetic draft parser floors; read as literal metadata.\n"
                               + "FLOORS = " + repr({"decisions": 0, "gaps": 0, "records": len(records)}) + "\n", encoding="utf-8")
        input_names = set(parent["input_sha256"]) | {f"{parent['product']}/handoff/{name}" for name in DRAFT_REGISTERS}
        input_names.add(f"{parent['product']}/handoff/tests/test_functional_contract.py")
        inputs = {relative: journeys._sha(child_folder / relative) for relative in sorted(input_names)}
        child = {"schema_version": 1, "id": child_id, "owner": parent["owner"], "repository": parent["repository"],
                 "label": label, "journey": parent["journey"], "example_id": parent["example_id"], "example": parent["example"],
                 "created_at": journeys._now(), "stage": "prepared", "product": parent["product"],
                 "input_sha256": inputs, "plan": plan, "steps": [], "source_mode": "synthetic", "releasable": False,
                 "revision_of": run_id, "parent_sha256": actual_base,
                 "revision_number": int(parent.get("revision_number", 0)) + 1}
        # Both the source bytes and generated records must remain unchanged until
        # publication of the new saved revision. The execution lock prevents the
        # portal worker from racing this clone; the digest catches external edits.
        if _snapshot(root, state_root, actor_id, run_id)[-1] != actual_base:
            raise ValueError("The parent rehearsal changed while saving. Reopen it before trying again.")
        journeys._json(child_folder / "plan.json", plan)
        journeys._json(child_folder / "rehearsal.json", child)
        return {"ok": True, "run": child, "errors": []}
    except (OSError, ValueError, TypeError, KeyError, yaml.YAMLError) as error:
        if child_folder is not None and not (child_folder / "rehearsal.json").exists():
            try:
                # Only an unpublished UUID child allocated by this invocation is
                # eligible for cleanup, and no redirected path is followed.
                safe = journeys._folder(root, state_root, actor_id, child_folder.name)
                if safe == child_folder and safe.is_dir():
                    for path in safe.rglob("*"):
                        journeys._canonical(path, safe)
                    shutil.rmtree(safe)
            except (OSError, ValueError):
                pass
        return journeys._error(error)
    finally:
        if lock_fd is not None:
            os.close(lock_fd)
            lock.unlink(missing_ok=True)
