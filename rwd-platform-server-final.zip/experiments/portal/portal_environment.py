"""Portable metadata for the measured local Python environment; never an installer.

Capture follows only the declared portal/platform dependency closure plus pytest.
Normal startup reports drift without turning a different transitive version into a
product gate. Native runtimes remain explicit optional installations.
"""
from __future__ import annotations

import argparse
import hashlib
import importlib.metadata as metadata
import json
import platform
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
MANIFEST = "experiments/portal/environment.manifest.json"
CONSTRAINTS = "experiments/portal/environment.constraints.txt"
TEST_REQUIREMENT = "pytest==9.1.1"
NOTICE = ("Dependency metadata only. A matching environment is not a workflow, scientific, "
          "Spark or R test result. Optional native runtimes are installed and checked separately.")


def _requirement(text):
    from packaging.requirements import Requirement
    item = Requirement(text)
    if item.url or not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9._-]*", item.name):
        raise ValueError("Only named package requirements are included; direct URLs are not portable constraints.")
    return item


def _name(value):
    return re.sub(r"[-_.]+", "-", value).lower()


def roots(root):
    """Read the existing requirements, without pip options, URL sources or escapes."""
    root = Path(root).resolve()
    found, visited = {"pytest": TEST_REQUIREMENT}, set()
    def read(relative):
        path = (root / relative).resolve()
        if not path.is_relative_to(root) or path in visited:
            raise ValueError("Requirements include an unsafe or repeated include.")
        visited.add(path)
        for raw in path.read_text(encoding="utf-8").splitlines():
            line = raw.split("#", 1)[0].strip()
            if not line:
                continue
            if line.startswith("-r "):
                read(path.parent.joinpath(line[3:].strip()).relative_to(root))
                continue
            requirement = _requirement(line)
            name = _name(requirement.name)
            canonical = str(requirement)
            if name in found and found[name] != canonical:
                raise ValueError("Requirements disagree for " + name)
            found[name] = canonical
    read("requirements.txt")
    read("platform/requirements.txt")
    return dict(sorted(found.items()))


def _closure(root_requirements, get_record, environment=None):
    """Resolve markers and extras from metadata, without importing package code."""
    from packaging.markers import default_environment
    env = {**default_environment(), **(environment or {})}
    selected, extras_seen, pending = {}, {}, list(root_requirements.values())
    while pending:
        requirement = _requirement(pending.pop())
        if requirement.marker and not requirement.marker.evaluate({**env, "extra": ""}):
            continue
        name = _name(requirement.name)
        record = selected.setdefault(name, get_record(name))
        if not requirement.specifier.contains(record["version"], prereleases=True):
            raise ValueError("Installed dependency does not satisfy " + str(requirement))
        extras = set(requirement.extras) | {""}
        if name in extras_seen and extras <= extras_seen[name]:
            continue
        extras_seen.setdefault(name, set()).update(extras)
        for raw in record["requires"]:
            child = _requirement(raw)
            if child.marker is None or any(child.marker.evaluate({**env, "extra": extra}) for extra in extras_seen[name]):
                # The marker was evaluated in its parent's extras context. Keeping
                # it would incorrectly evaluate it again in the child's context.
                child.marker = None
                pending.append(str(child))
    return dict(sorted(selected.items()))


def capture(root=ROOT, *, distribution=None):
    distribution = distribution or metadata.distribution
    def get_record(name):
        dist = distribution(name)
        version = dist.version
        if not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9.!+_-]*", version):
            raise ValueError("Unusable package version metadata.")
        return {"version": version, "requires": sorted(str(_requirement(value)) for value in (dist.requires or []))}
    declared = roots(root)
    packages = _closure(declared, get_record)
    version = platform.python_version()
    profile = "local-python" + "".join(version.split(".")[:2]) + "-20260909"
    return {"schema_version": 1, "profile": profile, "python": version,
            "system": platform.system(), "machine": platform.machine(), "roots": declared, "packages": packages,
            "optional_runtime": {}, "optional_runtime_status": "not_checked",
            "evidence": "Python distribution metadata captured by portal_environment.capture; no native runtime tests were run.", "notice": NOTICE}


def load(root=ROOT):
    path = Path(root) / MANIFEST
    if path.stat().st_size > 512_000:
        raise ValueError("Environment manifest is too large.")
    doc = json.loads(path.read_text(encoding="utf-8"))
    if (not isinstance(doc, dict) or doc.get("schema_version") != 1 or not isinstance(doc.get("packages"), dict)
            or not 1 <= len(doc["packages"]) <= 300 or not isinstance(doc.get("roots"), dict)):
        raise ValueError("Environment manifest is malformed.")
    for name, record in doc["packages"].items():
        if (not isinstance(name, str) or name != _name(name) or not re.fullmatch(r"[a-z0-9][a-z0-9-]*", name)
                or not isinstance(record, dict) or set(record) != {"version", "requires"}
                or not isinstance(record["version"], str) or not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9.!+_-]*", record["version"])
                or not isinstance(record["requires"], list) or len(record["requires"]) > 300):
            raise ValueError("Environment package metadata is malformed.")
        for value in record["requires"]:
            _requirement(value)
    for name, value in doc["roots"].items():
        if _name(_requirement(value).name) != name:
            raise ValueError("Environment root metadata is malformed.")
    return doc


def package_names(root=ROOT):
    try:
        return list(load(root)["packages"])
    except (OSError, ValueError, TypeError, KeyError, RecursionError, ImportError):
        return []


def report(root=ROOT, *, observed=None, runtime=None, observed_environment=None):
    """Stable, path-free diagnostics suitable for the existing prerequisite receipt.

    Pass an interpreter probe's observed versions to inspect that interpreter;
    otherwise read metadata from this process. Unrelated site packages are ignored.
    """
    try:
        doc = load(root)
        portable = observed_environment or {"python": platform.python_version(), "system": platform.system(), "machine": platform.machine()}
        portable = {key: portable.get(key) for key in ("python", "system", "machine")}
        marker_environment = {}
        if portable["python"]:
            marker_environment.update(python_full_version=portable["python"],
                                      python_version=".".join(portable["python"].split(".")[:2]))
        if portable["system"]:
            marker_environment["platform_system"] = portable["system"]
            marker_environment["sys_platform"] = {"Windows": "win32", "Linux": "linux", "Darwin": "darwin"}.get(portable["system"], sys.platform)
        if portable["machine"]:
            marker_environment["platform_machine"] = portable["machine"]
        selected = _closure(doc["roots"], lambda name: doc["packages"][name], marker_environment)
        current = {}
        for name in selected:
            if observed is not None:
                current[name] = observed.get(name)
            else:
                try:
                    current[name] = metadata.version(name)
                except metadata.PackageNotFoundError:
                    current[name] = None
        entries = [{"package": name, "expected": record["version"], "observed": current[name]} for name, record in selected.items()]
        missing = [item for item in entries if item["observed"] is None]
        mismatched = [item for item in entries if item["observed"] is not None and item["observed"] != item["expected"]]
        runtime_entries = []
        if runtime is not None:
            expected_native = doc.get("optional_runtime", {})
            for name in ("r_version", "pyspark", "java_version"):
                runtime_entries.append({"package": name, "expected": expected_native.get(name), "observed": runtime.get(name)})
            for name, expected in expected_native.get("r_packages", {}).items():
                runtime_entries.append({"package": "R:" + name, "expected": expected, "observed": runtime.get("r_packages", {}).get(name)})
        drift = roots(root) != doc["roots"]
        profile_matches = all(doc.get(key) == value for key, value in portable.items())
        return {"status": "matched" if not missing and not mismatched and not drift and profile_matches else "mismatch",
                "manifest": MANIFEST, "manifest_sha256": hashlib.sha256(json.dumps(doc, sort_keys=True).encode()).hexdigest(),
                "profile": doc["profile"], "expected_runtime": {key: doc[key] for key in portable}, "observed_runtime": portable,
                "requirements_changed": drift, "packages": entries, "missing": missing, "mismatched": mismatched,
                "optional_runtime": runtime_entries,
                "optional_runtime_status": ("not_checked" if runtime is None or not doc.get("optional_runtime") else
                    "matched" if all(item["expected"] == item["observed"] and item["expected"] is not None for item in runtime_entries) else "mismatch"),
                "notice": NOTICE}
    except (OSError, ValueError, TypeError, KeyError, RecursionError, ImportError):
        return {"status": "unavailable", "manifest": MANIFEST,
                "reason": "The measured environment manifest is missing, invalid, or does not cover this platform's dependency closure.", "notice": NOTICE}


def constraints(doc):
    minor = ".".join(doc["python"].split(".")[:2])
    return (f"# Measured local Python {minor} dependency closure; optional Spark/R are separate.\n"
            "# Constraints select versions; install the existing requirements plus pytest.\n" +
            "".join(name + "==" + record["version"] + "\n" for name, record in sorted(doc["packages"].items())))


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--capture", action="store_true", help="Explicitly rewrite the measured manifest and constraints from the current dependency metadata; review the diff.")
    parser.add_argument("--json", action="store_true")
    args = parser.parse_args(argv)
    if args.capture:
        doc = capture()
        (ROOT / MANIFEST).write_text(json.dumps(doc, indent=2, sort_keys=True) + "\n", encoding="utf-8")
        (ROOT / CONSTRAINTS).write_text(constraints(doc), encoding="utf-8")
    result = report()
    print(json.dumps(result, indent=2) if args.json else "Measured local environment: " + result["status"] + ". " + NOTICE)
    return 0 if result["status"] == "matched" else 1


if __name__ == "__main__":
    raise SystemExit(main())
