"""Keep explicit treatment-line choices bound to their generated scientific rule."""
from __future__ import annotations

from copy import deepcopy

import variable_review_family as family

_LABELS = {
    "derivation": "definition", "record_selection": "record selection", "grain": "grain",
    "output.type": "data type", "source.kind": "source kind", "tie_break": "diagnosis tie-breaking",
}


def bind_updates(updates):
    """Complete selections carry their canonical rule in the same row transaction."""
    result = deepcopy(updates)
    selected = result.get("family")
    if not selected:
        return result
    generated = family.scientific_updates(selected)
    if "derivation" not in generated:
        # A partial choice stays a draft and does not replace its previous rule.
        return result
    for path, value in generated.items():
        if path in result and result[path] != value:
            label = _LABELS.get(path, path)
            raise ValueError(f"The supplied {label} conflicts with the treatment-line choices. Save the generated definition, or use a custom definition without this family.")
        result[path] = deepcopy(value)
    # The line, attribute and numbering were chosen explicitly. Still run the
    # reusable-logic validator; this flag does not permit forbidden literals.
    result.setdefault("logic_reviewed", True)
    return result


def coherence_issues(row):
    """Previously saved metadata cannot confirm a different scientific rule."""
    selected = family.selection(row)
    if not selected:
        return []
    try:
        generated = family.scientific_updates(selected)
    except ValueError:
        return []  # The family structure/completeness check supplies the issue.
    if "derivation" not in generated:
        return []
    mismatches = []
    for path, expected in generated.items():
        if path == "family":
            continue
        actual = row.get("values") or {}
        for part in path.split("."):
            actual = actual.get(part) if isinstance(actual, dict) else None
        if actual != expected:
            mismatches.append(_LABELS.get(path, path))
    if not mismatches:
        return []
    return ["The treatment-line choices do not match the saved " + ", ".join(mismatches)
            + ". Reopen the treatment-line choices and save the generated definition, or choose a custom definition."]
