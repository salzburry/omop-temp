"""Derived workflow records are reviewed outputs, not new scientific inputs.

Each owning workspace verifies these records against its real inputs when reopening
them. Saving an unrelated review must not force every other review to start again.
"""
from pathlib import PurePosixPath
import re

FOLDERS = {"EDA_REVIEWS", "semantic_exports", "IMPLEMENTATION_REVIEWS", "model_lifecycle"}


def is_saved_output(relative):
    parts = PurePosixPath(str(relative).replace("\\", "/")).parts
    if (len(parts) == 7 and parts[0] in {"products", "fixtures"} and parts[4:6] == ("handoff", "CONFIGURATION_PROPOSALS")
            and re.fullmatch(r"[a-f0-9]{32}\.json", parts[6])):
        return True
    return bool(len(parts) >= 6 and parts[0] in {"products", "fixtures"}
                and parts[4] == "handoff" and
                (parts[5] in FOLDERS or parts[5] == "BRANCH_FILES.yaml"))


def declared_references(product, read):
    """Conservatively retain explicit config consumers in a review snapshot.

    The owning caller supplies its bounded, safe reader. This only identifies
    paths; the existing configuration validators still decide their validity.
    """
    import yaml
    refs = set()
    for path in (product / "config").glob("*.yaml"):
        doc = yaml.safe_load(read(path)) or {}
        if not isinstance(doc, dict):
            continue
        variables, codelists = doc.get("variables") or [], doc.get("codelists") or {}
        if not isinstance(variables, list) or not isinstance(codelists, dict):
            continue
        refs.update((product / ref).resolve() for ref in [*variables, *codelists.values()] if isinstance(ref, str))
    return refs
