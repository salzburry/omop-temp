"""A reviewer's workbook return continues on its exact source row."""
from __future__ import annotations

import streamlit as st
import review_exchange as exchange


def render(root, pack, actor_id, *, allowed_packs, local_demo, can_write, can_review, route, params=None):
    prefix = "review_exchange_"
    context = (str(root), pack, actor_id, bool(local_demo), bool(can_write), tuple(sorted(allowed_packs)))
    if st.session_state.get(prefix + "context") != context:
        for key in list(st.session_state):
            if str(key).startswith(prefix):
                del st.session_state[key]
        st.session_state[prefix + "context"] = context
    st.caption(exchange.NOTICE)
    st.write("1. Download the current specification workbook. Enter ACCEPT, REVISE or QUESTION in reviewer_decision, explain your judgment in reviewer_comment, and supply your name and the review date (YYYY-MM-DD).")
    st.write("2. Return the workbook here. Keep all source text, findings and existing question sheets unchanged.")
    if st.button("Prepare current review workbook", key=prefix + "build"):
        st.session_state[prefix + "issued"] = exchange.build(root, pack, actor_id, allowed_packs=allowed_packs)
    issued = st.session_state.get(prefix + "issued")
    if issued:
        if issued["ok"]:
            st.download_button("Download scientific review workbook", issued["data"], file_name="scientific-review.xlsx",
                               mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", key=prefix + "download")
            st.caption(f"{issued['stats']['rows']} specification rows; {issued['stats']['findings']} findings to consider.")
            uploaded = st.file_uploader("Return the completed review workbook", type=["xlsx"], key=prefix + "upload",
                help="Only specification review metadata belongs here. Do not upload patient records or a source dataset.")
            if st.button("Validate and save reviewer input", disabled=uploaded is None or not (local_demo and can_write), key=prefix + "receive"):
                result = exchange.receive(root, pack, actor_id, uploaded.getvalue(), expected_input_digest=issued["input_digest"],
                                          allowed_packs=allowed_packs, local_demo=local_demo, can_write=can_write)
                st.session_state[prefix + "result"] = result
                if result["ok"]:
                    st.session_state[prefix + "selected_id"] = result["id"]
        else:
            for error in issued["errors"]:
                st.error(error)
    prior_result = st.session_state.get(prefix + "result")
    if prior_result and not prior_result["ok"]:
        for error in prior_result["errors"]:
            st.error(error)
    saved = exchange.recent(root, pack, actor_id, allowed_packs=allowed_packs)
    if not saved:
        return None
    ids = [r["id"] for r in saved]
    incoming = (params or {}).get("id")
    if incoming in ids and st.session_state.get(prefix + "incoming") != incoming:
        st.session_state[prefix + "selected_id"] = incoming
        st.session_state[prefix + "incoming"] = incoming
    rid = st.selectbox("Saved review return", ids, key=prefix + "selected_id", format_func=lambda value: value[:12])
    record = exchange.load(root, pack, actor_id, rid, allowed_packs=allowed_packs)
    if not record["ok"]:
        for error in record["errors"]:
            st.error(error)
        return None
    if record["stale"]:
        st.warning("The source or question register changed after this review. Download and review the current workbook before transferring comments.")
    st.write("3. Continue on a reviewed row. ACCEPT records what the reviewer entered; the scientific definition still needs its own validation and review.")
    decisions = record["result"]["decisions"]
    st.dataframe(decisions, hide_index=True, width="stretch")
    selected = st.selectbox("Reviewed row to continue", range(len(decisions)), key=prefix + "row",
                            format_func=lambda i: f"{decisions[i]['variable'] or decisions[i]['item_id']} · {decisions[i]['decision']}")
    item = decisions[selected]
    if item.get("variable"):
        import scientific_definitions as definitions
        draft = definitions.describe(root, pack, actor_id, item_id=item["source_row"], allowed_packs=allowed_packs)
        if st.button("Copy this comment to the unfinished definition draft", key=prefix + "copy",
                     disabled=record["stale"] or not item.get("comment") or not draft["ok"] or not (local_demo and can_write)):
            copied = exchange.copy_comment(root, pack, actor_id, rid, item["item_id"],
                expected_input_digest=draft["input_digest"], expected_draft_digest=draft["draft_digest"],
                allowed_packs=allowed_packs, local_demo=local_demo, can_write=can_write)
            if copied["ok"]:
                return {"route": "scientific_draft", "params": {"item_id": item["source_row"], "variable": item["variable"]}, "changed": True}
            for error in copied["errors"]:
                st.error(error)
        if st.button("Open this scientific definition", key=prefix + "open"):
            return {"route": "scientific_draft", "params": {"item_id": item["source_row"], "variable": item["variable"]}}
    if st.button("Review the recorded scientific questions", key=prefix + "questions"):
        return {"route": "questions", "params": {"item_id": item["source_row"]}}
    return None
