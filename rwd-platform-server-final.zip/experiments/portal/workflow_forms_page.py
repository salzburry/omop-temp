"""Prepare complete human review forms without copying placeholder files."""
from pathlib import Path

import streamlit as st
import form_assistance as form_help

import workflow_forms as forms
from source_review_page import CLASSES


def clear():
    for key in list(st.session_state):
        if str(key).startswith("workflow_forms_"):
            st.session_state.pop(key, None)


def _remember(name):
    values = dict(st.session_state.get("workflow_forms_values") or {})
    values[name] = st.session_state.get("workflow_forms_value_" + name, "")
    st.session_state["workflow_forms_values"] = values
    st.session_state["workflow_forms_confirm"] = False


def _human_fields(description, enabled):
    """Shared chat can prepare notes; review attribution and access choices stay manual.
    A closed vocabulary (the AI classification) has no default selected."""
    remembered = st.session_state.get("workflow_forms_values") or {}
    for field in description["fields"]:
        name = field["name"]
        key = "workflow_forms_value_" + name
        if field.get("choices"):
            st.session_state.setdefault(key, remembered.get(name) or None)
            if st.session_state[key] not in field["choices"]:
                st.session_state[key] = None
            st.selectbox(field["label"], field["choices"], key=key, disabled=not enabled,
                         format_func=lambda value: CLASSES.get(value, value), on_change=_remember, args=(name,))
            continue
        st.session_state.setdefault(key, remembered.get(name, ""))
        st.session_state[key] = st.session_state[key]
        if name == "notes":
            form_help.field(st.text_area, field["label"], key=key, disabled=not enabled, on_change=_remember, args=(name,), binding=(st.session_state.get("workflow_forms_context"), description.get("manifest_digest"), description.get("target")))
        else:
            st.text_input(field["label"], key=key, disabled=not enabled,
                          placeholder="YYYY-MM-DD" if name.endswith("_date") else None,
                          on_change=_remember, args=(name,))


def _candidate_selection(root, pack, *, prefix, receipt=None, build_id=None, candidate_path=None):
    key = prefix + "candidate"
    if key not in st.session_state:
        selected = forms.candidate_context(root, pack, receipt=receipt, build_id=build_id,
            candidate_path=candidate_path, allowed_packs=[pack]) if receipt is not None else {}
        st.session_state[key] = selected.get("candidate_path", "") if receipt is not None else str(candidate_path or "")
    if receipt is not None:
        st.caption("Selected build: " + str(build_id or "from the exact receipt") + " · " + str(receipt))
    st.text_input("Candidate sidecar path", key=key,
        help="The local copy of release_candidate.yaml beside its unchanged manifest.yaml from this product's selected build.")
    path = st.session_state.get(key) or None
    context = forms.candidate_context(root, pack, receipt=receipt, build_id=build_id,
        candidate_path=path, allowed_packs=[pack]) if receipt is not None else None
    if context is not None and not context["ok"]:
        for error in context["errors"]:
            st.warning(error)
    return path, context


def render(root, pack, action, actor_id, *, target=None, candidate_path=None, local_demo, can_review, can_view,
           show_reference=None, receipt=None, build_id=None):
    if not can_view:
        clear()
        st.warning("You no longer have access to this product's review preparation.")
        return False
    aid = action.get("id") if isinstance(action, dict) else action
    base = (str(Path(root).resolve()), pack, actor_id, aid, receipt, build_id)
    previous = st.session_state.get("workflow_forms_context")
    changed_context = previous is not None and previous != base
    if previous != base:
        clear()
        st.session_state["workflow_forms_context"] = base
    enabled = local_demo is True and can_review is True and not changed_context
    if aid in {"g5_validate", "g6_approve"}:
        candidate_path, linked = _candidate_selection(root, pack, prefix="workflow_forms_", receipt=receipt,
            build_id=build_id, candidate_path=candidate_path)
        if linked is not None and not linked["ok"]:
            return False
    binding = {"receipt": receipt, "build_id": build_id}
    probe = forms.describe(root, pack, action, target=target, candidate_path=candidate_path, allowed_packs=[pack], **binding)
    st.write("**Prepare the missing workflow record**")
    st.caption(str(probe.get("notice") or forms.NOTICE))
    if not probe.get("ok"):
        for error in probe.get("errors") or ["Preparation is unavailable."]:
            st.warning(str(error))
        return False
    if st.session_state.get("workflow_forms_target") not in probe["targets"]:
        st.session_state["workflow_forms_target"] = probe["target"]
    selected = st.selectbox("Record to prepare", probe["targets"], key="workflow_forms_target", format_func=lambda path: Path(path).name)
    if selected != probe["target"]:
        probe = forms.describe(root, pack, action, target=selected, candidate_path=candidate_path, allowed_packs=[pack], **binding)
    if not probe.get("ok"):
        for error in probe.get("errors") or ["The selected form could not be prepared."]:
            st.warning(str(error))
        return False
    if probe["exists"]:
        if probe.get("kind") == "registration":
            st.info("This product's source record already exists. Record the workbook, its checksum and the review in the source review forms; registration never replaces a record.")
        else:
            st.info("This record already exists. Use its editor to revise it; preparation never overwrites an existing review.")
        return False
    context = (*base, selected, candidate_path)
    snapshot = st.session_state.get("workflow_forms_snapshot")
    if not isinstance(snapshot, dict) or snapshot.get("context") != context:
        for key in list(st.session_state):
            if str(key).startswith("workflow_forms_value_") or key in {"workflow_forms_values", "workflow_forms_confirm"}:
                st.session_state.pop(key, None)
        snapshot = {"context": context, "description": probe}
        st.session_state["workflow_forms_snapshot"] = snapshot
    description = snapshot["description"]
    stale = probe["manifest_digest"] != description["manifest_digest"]
    if stale:
        st.warning("The preparation evidence changed. Reload preparation and review the latest inputs before saving.")
    for problem in description["missing_inputs"]:
        st.warning(str(problem))
    if not enabled:
        st.info("Creating this record requires reviewer access in a local session.")
    if description["kind"] == "register":
        st.write("Create the canonical empty table, then enter the questions or findings that actually exist. Creating it does not state that QC was performed.")
        label = "Create empty register for review"
        confirmation = "I want to create this empty register and will record the actual questions or findings before claiming the review is complete."
    elif description["kind"] == "maturity":
        st.write("The initial record sets contract and configuration to not_started. It makes no approval claim.")
        label = "Create initial maturity record"
        confirmation = "I want to create the initial maturity record without claiming an approval."
    elif description["kind"] == "registration":
        # THE FIRST REGISTRATION (2026-09-07): the three values only a person supplies, chosen or
        # typed here, and the tool's own composition writes the file (workflow_forms._registration_payload).
        st.write("Decide how AI may read this specification, then enter your own name and the date of that decision. "
                 "The specification stays pending until the workbook is attached, its checksum recorded and its review completed.")
        if description.get("workbooks") and len(description["workbooks"]) == 1:
            st.caption("The one workbook in prog_spec/ is registered as the specification's location: " + description["path_or_link"])
        elif description.get("workbooks"):
            st.caption("More than one workbook is in prog_spec/, so the location is left as TBD; name the approved one afterwards in the source review.")
        else:
            st.caption("No workbook is in prog_spec/ yet, so the location is left as TBD until it is attached.")
        if description.get("replaces"):
            st.caption("The existing source_refs.yaml holds no registration (it is empty or not a mapping) and will be replaced.")
        _human_fields(description, enabled)
        label = "Register the program specification"
        confirmation = "I made this AI access decision for the specification and these are my actual name and date. The specification is not approved by registering it."
    else:
        st.write("Enter the people and dates from the review actually performed. The evidence fingerprints below are calculated from current files.")
        _human_fields(description, enabled)
        with st.expander("Evidence included in this review"):
            for field, value in description["digests"].items():
                st.text(field.replace("_", " ") + ": " + str(value))
            for index, path in enumerate(description["inputs"]):
                st.text(path)
                if show_reference and st.button("Open review input", key=f"workflow_forms_open_{index}"):
                    show_reference(path)
        label = "Record the completed review"
        confirmation = "I reviewed the evidence and confirm these are the actual people, dates and review decisions. The record still requires identity authentication."
    st.checkbox(confirmation, key="workflow_forms_confirm", disabled=not enabled)
    if st.button(label, key="workflow_forms_save", type="primary", disabled=not enabled or stale or bool(description["missing_inputs"])):
        values = {field["name"]: str(st.session_state.get("workflow_forms_value_" + field["name"]) or "") for field in description["fields"]}
        result = forms.save(root, pack, action, values, expected_manifest_digest=description["manifest_digest"],
                            confirmed=st.session_state.get("workflow_forms_confirm", False), local_demo=local_demo,
                            can_review=can_review and can_view, target=selected, candidate_path=candidate_path, allowed_packs=[pack], **binding)
        if result.get("ok"):
            st.success("Record created. Its validation and identity authentication remain separate requirements.")
            return True
        for error in result.get("errors") or ["The record could not be created."]:
            st.error(str(error))
    if st.button("Reload preparation", key="workflow_forms_reload", help="Discard unsaved review entries and inspect current evidence."):
        st.session_state.pop("workflow_forms_snapshot", None)
        st.rerun()
    return False
