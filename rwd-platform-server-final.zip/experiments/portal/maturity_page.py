"""The maturity claim as a form (walk UC1-MATURITY, 2026-09-07): a person states which level a product
has reached on one axis, and the gate checks decide whether the claim holds. Until now the act was an
edit of one line inside a YAML document shown in the record editor; the form rewrites that one line
and leaves every other line, comment and line ending as it was."""
from __future__ import annotations

import os
import re
import tempfile
from pathlib import Path

import streamlit as st

import product_gates as pg

PREFIX = "maturity_"
AXES = {
    "contract": ("specification and definitions (stage 2)", tuple(pg.CONTRACT_LEVELS)),
    "configuration": ("configuration (stage 4)", tuple(pg.CONFIG_LEVELS)),
}
WORDS = {
    "not_started": "not started",
    "draft": "draft: the work is being written",
    "coverage_complete": "coverage complete: every specification row is traced to a record",
    "approved": "approved: the typed approval record exists and its digests match",
}


class Refused(Exception):
    """Nothing was written; the message says why."""


def _file(root, pack, allowed_packs):
    text = str(pack or "").replace("\\", "/").strip("/")
    if not text or ".." in text.split("/"):
        raise Refused("Choose a product first.")
    if allowed_packs is not None and text not in {str(p).replace("\\", "/").strip("/") for p in allowed_packs}:
        raise Refused("This product is outside your access.")
    base = Path(root).resolve()
    product = base / text
    if product.resolve() != product or not product.is_dir():
        raise Refused("The product location is unavailable.")
    file = product / "handoff" / "MATURITY.yaml"
    if file.exists() and file.resolve() != file:
        raise Refused("The maturity record redirects to another location. Ask your data expert to repair it.")
    return file


def _lines(file):
    try:
        text = file.read_bytes().decode("utf-8")      # bytes: the line ending is kept as written
    except FileNotFoundError:
        raise Refused("This product has no maturity record yet. The stand-up writes it; ask your data expert.") from None
    except (OSError, UnicodeError):
        raise Refused("The maturity record could not be read. Ask your data expert to repair it.") from None
    newline = "\r\n" if "\r\n" in text else "\n"
    return text.split(newline), newline


def _claim_lines(lines, axis):
    return [i for i, line in enumerate(lines) if re.match(rf"^{axis}:\s*[A-Za-z_]+\s*(#.*)?$", line)]


def has_record(root, pack, allowed_packs=None):
    """Whether the product carries a maturity record at all; without one the register form creates it."""
    try:
        return _file(root, pack, allowed_packs).is_file()
    except Refused:
        return False


def describe(root, pack, allowed_packs=None):
    """{"ok", "errors", "levels": {axis: level}}, read line by line the way the gate reads it."""
    try:
        file = _file(root, pack, allowed_packs)
        lines, _newline = _lines(file)
    except Refused as error:
        return {"ok": False, "errors": [str(error)], "levels": {}}
    levels, errors = {}, []
    for axis in AXES:
        hits = _claim_lines(lines, axis)
        if len(hits) > 1:
            errors.append(f"The maturity record states the {axis} level more than once. Ask your data expert to repair it.")
        levels[axis] = re.match(rf"^{axis}:\s*([A-Za-z_]+)", lines[hits[0]]).group(1) if hits else "not_started"
    return {"ok": not errors, "errors": errors, "levels": levels}


def set_level(root, pack, axis, level, *, local_demo, can_write, confirmed, allowed_packs=None):
    """Rewrite the one claim line. Refuses before writing; nothing else in the record changes."""
    if not local_demo:
        raise Refused("The maturity claim is recorded on the person's own checkout in this version.")
    if not can_write:
        raise Refused("Recording a maturity claim needs product-author access.")
    if axis not in AXES:
        raise Refused("Choose which stage the claim is about.")
    if level not in AXES[axis][1]:
        raise Refused("Choose one of the listed levels.")
    if not confirmed:
        raise Refused("Tick the confirmation first. Nothing was recorded.")
    file = _file(root, pack, allowed_packs)
    lines, newline = _lines(file)
    hits = _claim_lines(lines, axis)
    if len(hits) > 1:
        raise Refused(f"The maturity record states the {axis} level more than once. Ask your data expert to repair it.")
    if not hits:
        raise Refused(f"The maturity record has no {axis} line. Ask your data expert to repair it.")
    current = re.match(rf"^{axis}:\s*([A-Za-z_]+)", lines[hits[0]]).group(1)
    if current == level:
        raise Refused(f"The {axis} claim is already {WORDS.get(level, level)}. Nothing changed.")
    lines[hits[0]] = re.sub(rf"^({axis}:\s*)[A-Za-z_]+", lambda m: m.group(1) + level, lines[hits[0]], count=1)
    handle, temporary = tempfile.mkstemp(prefix=".maturity-", suffix=".tmp", dir=str(file.parent))
    try:
        with os.fdopen(handle, "w", encoding="utf-8", newline="") as out:
            out.write(newline.join(lines))
        os.replace(temporary, file)
    finally:
        try:
            os.unlink(temporary)
        except OSError:
            pass
    return {"ok": True, "axis": axis, "before": current, "after": level,
            "message": (f"The {axis} claim is now {WORDS.get(level, level)} (it was {WORDS.get(current, current)}). "
                        "Choose Check status: the gate checks decide whether the claim holds.")}


def render(root, pack, actor_id, axis, *, local_demo, can_write, can_view, allowed_packs=None):
    """Returns True when the claim was just recorded (the caller re-checks the product)."""
    if not can_view:
        return False
    title, levels = AXES.get(axis, AXES["contract"])
    st.write(f"**State how far this product has come: {title}**")
    st.caption("A claim is the person's own statement; the gate checks decide whether it holds. Claiming approved "
               "before the typed approval record exists makes the gate say so. Nothing here signs or approves anything.")
    info = describe(root, pack, allowed_packs)
    for error in info["errors"]:
        st.warning(error)
    if not info["ok"]:
        return False
    current = info["levels"].get(axis, "not_started")
    st.write(f"Current claim: {WORDS.get(current, current)}.")
    if not local_demo:
        st.info("The maturity claim is recorded on the person's own checkout in this version.")
        return False
    if not can_write:
        st.info("Recording a maturity claim is the product author's act; your role can read this page but not record it.")
        return False
    with st.form(PREFIX + "form_" + axis):
        level = st.selectbox("New level", list(levels), index=levels.index(current) if current in levels else 0,
                             key=PREFIX + "level_" + axis, format_func=lambda v: WORDS.get(v, v))
        confirmed = st.checkbox("I am stating this level for the product on my own judgement.", key=PREFIX + "confirm_" + axis)
        sent = st.form_submit_button("Record the claim", type="primary", key=PREFIX + "submit_" + axis)
    if not sent:
        return False
    try:
        result = set_level(root, pack, axis, level, local_demo=local_demo, can_write=can_write, confirmed=confirmed,
                           allowed_packs=allowed_packs)
    except Refused as error:
        st.error("Not recorded. " + str(error))
        return False
    st.session_state.setdefault("flow_result", {}).pop(pack, None)
    st.session_state["flow_notice"] = result["message"]
    st.success(result["message"])
    return True
