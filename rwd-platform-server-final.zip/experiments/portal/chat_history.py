"""Bounded private chat snapshots, separate from workflow jobs and product files.

Identity comes from the portal's resolved actor. Local/demo mode is attribution,
not authentication. Revision checks and empty snapshots prevent an older browser
or in-flight answer from restoring a conversation that was cleared elsewhere.
"""
from __future__ import annotations

import copy
import json
import uuid

import design_workspace as design
import session_drafts

MAX_BYTES = 256_000
TURN_FIELDS = {"id", "question", "answer", "actions", "note", "source", "context_window",
               "context_reference", "knowledge", "evidence_ids", "specialist", "specialist_context"}


class Changed(ValueError):
    """Another session changed or cleared this conversation."""


def _scope(root, pack, actor, allowed_packs, channel):
    owner, setup_directory = session_drafts._setup_scope(root, actor, allowed_packs)
    name = design._pack_path(root, pack, allowed_packs)[2] if pack else ""
    if not isinstance(channel, str) or not channel or len(channel) > 100:
        raise ValueError("Choose a supported conversation.")
    scope = {"checkout": owner["checkout"], "owner": owner["owner"], "pack": name,
             "channel": channel, "access": sorted(set(allowed_packs))}
    directory = setup_directory.parent.parent.parent / "chat-history" / scope["checkout"][:12] / scope["owner"][:12]
    path = directory / (design._hash([name, channel])[:24] + ".json")
    if path.resolve() != path:
        raise ValueError("The private chat location redirects to another folder.")
    design._check_storage_paths([path])
    return scope, path


def _turns(turns):
    import flow_assistant
    import scientific_definition_ai as ai
    if not isinstance(turns, list) or len(turns) > flow_assistant.MAX_CONVERSATION_TURNS:
        raise ValueError("The conversation exceeds its supported history.")
    result = []
    for turn in turns:
        if (not isinstance(turn, dict) or not {"question", "answer"} <= set(turn)
                or not all(isinstance(turn[name], str) for name in ("question", "answer"))):
            raise ValueError("The saved conversation is malformed.")
        for name in ("actions", "evidence_ids"):
            if name in turn and (not isinstance(turn[name], list) or any(not isinstance(value, str) for value in turn[name])):
                raise ValueError("The saved conversation contains malformed references.")
        for name in ("context_window", "context_reference", "knowledge", "specialist", "specialist_context"):
            if turn.get(name) is not None and not isinstance(turn[name], dict):
                raise ValueError("The saved conversation contains malformed context.")
        result.append({name: copy.deepcopy(value) for name, value in turn.items() if name in TURN_FIELDS})
    raw = json.dumps(result, ensure_ascii=False, allow_nan=False)
    if len(raw.encode("utf-8")) > MAX_BYTES - 4000:
        raise ValueError("This conversation is too large to save privately.")
    # Use the same ingress guard as saved setup and model-bound conversation.
    ai._ingress(raw + "\n" + ai._plain(result))
    return result


def _read(path, scope):
    if not path.exists():
        return {"revision": None, "turns": [], "scope": scope}
    if path.stat().st_size > MAX_BYTES:
        raise ValueError("The saved conversation is too large to read.")
    value = design._json_read(path)
    if (not isinstance(value, dict) or set(value) != {"schema", "scope", "revision", "turns", "digest"}
            or value.get("schema") != 1 or not isinstance(value.get("scope"), dict)
            or set(value["scope"]) != set(scope)
            or any(value["scope"].get(name) != scope[name] for name in scope if name != "access")
            or not isinstance(value.get("revision"), str) or len(value["revision"]) != 32
            or value.get("digest") != design._hash({name: data for name, data in value.items() if name != "digest"})):
        raise ValueError("The saved conversation changed or belongs to another profile or product.")
    value["turns"] = _turns(value["turns"])
    return value


def _write(path, scope, turns):
    from scientific_definitions import _atomic
    value = {"schema": 1, "scope": scope, "revision": uuid.uuid4().hex, "turns": turns}
    value["digest"] = design._hash(value)
    raw = json.dumps(value, ensure_ascii=False, allow_nan=False).encode("utf-8")
    if len(raw) > MAX_BYTES:
        raise ValueError("This conversation is too large to save privately.")
    _atomic(path, raw)
    return value


def load(root, pack, actor, *, allowed_packs, channel="flow_assistant_"):
    scope, path = _scope(root, pack, actor, allowed_packs, channel)
    current = _read(path, scope)
    if current["scope"]["access"] != scope["access"]:
        # References can mention other permitted products. Revocation discards
        # them permanently, even if the original grant is later restored.
        from local_process_lock import locked
        with locked(path.with_suffix(".lock"), path.parent):
            current = _read(path, scope)
            if current["scope"]["access"] != scope["access"]:
                current = _write(path, scope, [])
    return current


def save(root, pack, actor, turns, *, allowed_packs, expected_revision, channel="flow_assistant_"):
    scope, path = _scope(root, pack, actor, allowed_packs, channel)
    clean = _turns(turns)
    current = _read(path, scope)
    if current["revision"] == expected_revision and current["scope"] == scope and current["turns"] == clean:
        return current
    from local_process_lock import locked
    path.parent.mkdir(parents=True, exist_ok=True)
    with locked(path.with_suffix(".lock"), path.parent):
        current = _read(path, scope)
        if current["revision"] != expected_revision or current["scope"] != scope:
            raise Changed("This conversation changed in another session. Review its latest messages before asking again.")
        return current if current["turns"] == clean else _write(path, scope, clean)


def clear(root, pack, actor, *, allowed_packs, channel="flow_assistant_"):
    scope, path = _scope(root, pack, actor, allowed_packs, channel)
    from local_process_lock import locked
    path.parent.mkdir(parents=True, exist_ok=True)
    with locked(path.with_suffix(".lock"), path.parent):
        # Keep a new empty revision, even when already empty. In-flight answers
        # are now stale and cannot repopulate the cleared transcript.
        return _write(path, scope, [])
