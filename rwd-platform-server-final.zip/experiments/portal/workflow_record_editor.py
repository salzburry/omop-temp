"""Human editing of existing, declared workflow records; validation remains authoritative."""
from __future__ import annotations

import copy
import datetime
import hashlib
import json
import math
import os
from pathlib import Path
import re
import tempfile

import yaml

import contract_lint as cl
import flow
import specification_details as details

MAX_BYTES = 512 * 1024
NOTICE = "Saving records your draft edit. It does not authenticate an approval, seal an event, prove scientific validity, run a build or release a product. Check status after saving."
SECRET_FIELDS = {"password", "access_token", "refresh_token", "client_secret", "private_key", "privatekey", "credentials", "credential", "api_key", "token", "secret", "authorization", "ssh_private_key", "gpg_private_key"}
PROTECTED_FIELDS = {"object_uuid", "signature", "signatures", "countersignature", "countersignatures", "key_id"}
EXCLUDED = {"source_refs.yaml", "handoff/decision_answers"}
SECRET_FILES = {"allowed_signers.yaml", "signing_keys.yaml", "private_key.yaml", "public_key.yaml", "secrets.yaml", "credentials.yaml"}


def _fail(message):
    return {"ok": False, "changed": False, "errors": [str(message)], "paths": [], "fields": [], "text": "", "digest": "", "notice": NOTICE}


def _scope(root, pack, action, path, allowed_packs):
    # Reuse canonical pack/scope checks; source_refs itself need not exist.
    source, pack = details._paths(root, pack, allowed_packs)
    root, product = Path(root).resolve(), source.parent
    aid = action.get("id") if isinstance(action, dict) else action
    menu = [item for items in flow.acts(pack, str(root)).values() for item in items]
    current = next((item for item in menu if item["id"] == aid and item["kind"] == flow.PERSON), None)
    if current is None:
        raise details._Invalid("This workflow action is no longer available for human record editing. Check status again.")
    declared = str(current.get("path") or "").replace("\\", "/")
    paths = []
    if declared.startswith(pack + "/"):
        relative = declared[len(pack) + 1:]
        if relative not in EXCLUDED and not relative.startswith("handoff/decision_answers/"):
            paths.append(relative)
    if aid == "g2_draft":
        paths = ["handoff/FUNCTIONAL_CONTRACT.md"]
    if aid == "g2_registers":
        paths = ["handoff/DECISIONS.md", "handoff/SPEC_QC_FINDINGS.md"]
    if aid == "g4_author":
        paths = [file.relative_to(product).as_posix() for directory in ("config", "variables", "codelists")
                 for file in sorted((product / directory).rglob("*.yaml"))]
    paths = [p for p in paths if Path(p).suffix.lower() in {".yaml", ".yml", ".md", ".txt"}
             and p != "source_refs.yaml" and Path(p).name.lower() not in SECRET_FILES]
    if not paths:
        raise details._Invalid("This action has no supported product record to edit here. Use its dedicated form or preparation action.")
    requested = str(path or (pack + "/" + paths[0])).replace("\\", "/")
    relative = requested[len(pack) + 1:] if requested.startswith(pack + "/") else requested
    if relative not in paths:
        raise details._Invalid("The requested file is outside this workflow action's declared product records.")
    target = product / relative
    if target.resolve() != target or not target.is_file():
        raise details._Invalid("The selected workflow record is missing or redirects elsewhere. Prepare it through the declared template or scaffold action before editing.")
    return root, pack, product, target, [pack + "/" + p for p in paths]


def _yaml(text):
    if any(isinstance(token, (yaml.AliasToken, yaml.AnchorToken)) for token in yaml.scan(text)):
        raise details._Invalid("YAML aliases need a data expert's review before this record can be edited.")
    doc = yaml.load(text, Loader=details._StrictLoader)
    if not isinstance(doc, (dict, list)):
        raise details._Invalid("A workflow YAML record must contain a mapping or list.")
    return doc


def _walk(value, at=(), depth=0):
    if depth > 15:
        raise details._Invalid("The record is nested too deeply for this editor.")
    if isinstance(value, dict):
        for key, child in value.items():
            if str(key).lower().replace("-", "_") in SECRET_FIELDS:
                raise details._Invalid("This record contains credential fields and must be handled in its secure configuration workflow.")
            yield from _walk(child, (*at, key), depth + 1)
    elif isinstance(value, list):
        for index, child in enumerate(value):
            yield from _walk(child, (*at, index), depth + 1)
    else:
        if not isinstance(value, (str, int, float, bool, datetime.date, type(None))):
            raise details._Invalid("The YAML record contains an unsupported scalar value.")
        if isinstance(value, float) and not math.isfinite(value):
            raise details._Invalid("Numeric fields must be finite values.")
        yield at, value


def _read(path):
    if path.resolve() != path:
        raise details._Invalid("The record redirects to another location.")
    with path.open("rb") as handle:
        raw = handle.read(MAX_BYTES + 1)
    if len(raw) > MAX_BYTES:
        raise details._Invalid("This record exceeds the editor's 512 KB limit.")
    text = raw.decode("utf-8")
    if "PRIVATE KEY-----" in text:
        raise details._Invalid("Private signing material cannot be read or edited through this workflow.")
    doc = _yaml(text) if path.suffix.lower() in {".yaml", ".yml"} else None
    leaves = list(_walk(doc)) if doc is not None else []
    if len(leaves) > 2000:
        raise details._Invalid("The YAML record exceeds this editor's 2,000-field limit.")
    return raw, text, doc, leaves


def _description(root, pack, path, paths, raw, text, doc, leaves):
    fields = [{"id": json.dumps(at, separators=(",", ":")), "path": list(at),
               "label": " / ".join(str(part) for part in at), "value": value,
               "kind": "bool" if isinstance(value, bool) else "number" if isinstance(value, (int, float)) else "date" if isinstance(value, datetime.date) else "text",
               "editable": not any(str(part).lower() in PROTECTED_FIELDS for part in at)} for at, value in leaves]
    return {"ok": True, "pack": pack, "path": path.relative_to(root).as_posix(), "paths": paths,
            "format": "yaml" if doc is not None else "markdown" if path.suffix.lower() == ".md" else "text",
            "text": text, "digest": hashlib.sha256(raw).hexdigest(), "fields": fields, "errors": [], "notice": NOTICE}


def describe(root, pack, action, path=None, allowed_packs=None):
    try:
        root, pack, _product, target, paths = _scope(root, pack, action, path, allowed_packs)
        return _description(root, pack, target, paths, *_read(target))
    except (details._Invalid, OSError, ValueError, TypeError, UnicodeError, yaml.YAMLError, RecursionError, KeyError) as error:
        return _fail(str(error) if isinstance(error, details._Invalid) else "The workflow record could not be read safely.")


def _same_type(old, new):
    if old is None:
        return new is None or isinstance(new, str)
    return type(old) is type(new)


def _scalar_edits(original, updates, by_id, expected):
    tree = yaml.compose(original, Loader=details._StrictLoader)
    replacements = []
    newline = "\r\n" if "\r\n" in original else "\n"
    for fid, value in updates.items():
        at, _old = by_id[fid]
        node = tree
        for part in at:
            if isinstance(node, yaml.MappingNode):
                node = next(child for key, child in node.value if key.value == part)
            elif isinstance(node, yaml.SequenceNode) and isinstance(part, int):
                node = node.value[part]
            else:
                raise details._Invalid("This YAML field cannot be changed without rewriting another structure.")
        if not isinstance(node, yaml.ScalarNode):
            raise details._Invalid("Only literal scalar values can be edited in the field view.")
        encoded = value.isoformat() if isinstance(value, datetime.date) else json.dumps(value, ensure_ascii=False)
        prefix = " " if node.start_mark.index and original[node.start_mark.index - 1] == ":" else ""
        suffix = newline if node.style in {"|", ">"} and original[node.start_mark.index:node.end_mark.index].endswith("\n") else ""
        replacements.append((node.start_mark.index, node.end_mark.index, prefix + encoded + suffix))
    result = original
    for start, end, value in sorted(replacements, reverse=True):
        result = result[:start] + value + result[end:]
    if _yaml(result) != expected:
        raise details._Invalid("This field edit would change another YAML value. Nothing was saved.")
    return result


def save(root, pack, action, path, *, expected_digest, text=None, updates=None, confirmed=False, local_demo,
         can_review, allowed_packs=None, receipt=None, build_id=None, candidate_path=None):
    if local_demo is not True or can_review is not True or confirmed is not True:
        return _fail("Saving a workflow record requires reviewer access in a local session and your explicit confirmation of the edit.")
    if (text is None) == (updates is None):
        return _fail("Provide either document text or field edits for one record.")
    if not isinstance(expected_digest, str) or not re.fullmatch(r"[0-9a-f]{64}", expected_digest):
        return _fail("Reload the current record before saving; its starting checksum is required.")
    lock_fd = None
    lock_path = temporary = None
    try:
        root, pack, product, target, paths = _scope(root, pack, action, path, allowed_packs)
        lock_path = target.with_name("." + target.name + ".portal-edit.lock")
        lock_fd = os.open(lock_path, os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o600)
        raw, original, doc, leaves = _read(target)
        if hashlib.sha256(raw).hexdigest() != expected_digest:
            raise details._Invalid("This record changed while the editor was open. Reload and compare the current version before saving.")
        if updates is not None:
            if doc is None or not isinstance(updates, dict):
                raise details._Invalid("Field edits are supported only for YAML records.")
            by_id = {json.dumps(at, separators=(",", ":")): (at, value) for at, value in leaves}
            edited = copy.deepcopy(doc)
            for fid, value in updates.items():
                if fid not in by_id:
                    raise details._Invalid("A field changed or no longer exists. Reload before editing it.")
                at, old = by_id[fid]
                if not _same_type(old, value):
                    raise details._Invalid("A field edit changed its YAML type. Use the document view for an intentional structural change.")
                node = edited
                for key in at[:-1]:
                    node = node[key]
                node[at[-1]] = value
            text = _scalar_edits(original, updates, by_id, edited)
        if not isinstance(text, str) or not text.strip() or len(text.encode("utf-8")) > MAX_BYTES or any(ord(c) < 32 and c not in "\n\r\t" for c in text):
            raise details._Invalid("Enter a nonempty text record within the 512 KB limit, without control characters.")
        if "PRIVATE KEY-----" in text:
            raise details._Invalid("Private signing material cannot be saved in a workflow record.")
        new_doc = _yaml(text) if doc is not None else None
        new_leaves = list(_walk(new_doc)) if new_doc is not None else []
        if len(new_leaves) > 2000:
            raise details._Invalid("The YAML record exceeds this editor's 2,000-field limit.")
        if doc is not None and type(new_doc) is not type(doc):
            raise details._Invalid("The YAML record's top-level structure must remain the same kind.")
        if receipt is not None:
            import workflow_forms
            aid = action.get("id") if isinstance(action, dict) else action
            if aid not in {"g5_validate", "g6_approve"} or target.name != "RELEASE_APPROVAL.yaml":
                raise details._Invalid("The selected candidate binding belongs to its release approval record.")
            candidate = workflow_forms.candidate_context(root, pack, receipt=receipt, build_id=build_id,
                candidate_path=candidate_path, allowed_packs=allowed_packs)
            if not candidate["ok"]:
                raise details._Invalid(" ".join(candidate["errors"]))
            if not isinstance(new_doc, dict) or any(new_doc.get(key) != value for key, value in candidate["digests"].items()):
                raise details._Invalid("The approval edits must name the selected build and its exact manifest digest. Correct both candidate identity fields before saving this review.")
        protected = lambda values: {json.dumps(at): value for at, value in values if any(str(part).lower() in PROTECTED_FIELDS for part in at)}
        if protected(leaves) != protected(new_leaves):
            raise details._Invalid("Event identifiers and signature fields belong to their governed tools and cannot be edited here.")
        if target.name == "DECISIONS.md":
            errors = cl.decision_register_errors(text, pack)
            if errors:
                raise details._Invalid("The decision table is malformed: " + " ".join(errors))
            old_rows, new_rows, statuses = cl.decision_rows(original), cl.decision_rows(text), cl.decision_status(original)
            if any(new_rows.get(did) != row for did, row in old_rows.items() if statuses.get(did) != "OPEN"):
                raise details._Invalid("An existing closed decision cannot be overwritten or removed. Create a new question and use the decision revision workflow.")
        replacement = text.encode("utf-8")
        if replacement == raw:
            return {**_description(root, pack, target, paths, raw, original, doc, leaves), "changed": False}
        with tempfile.NamedTemporaryFile(mode="wb", prefix=".workflow-record-", suffix=".tmp", dir=target.parent, delete=False) as handle:
            temporary = Path(handle.name)
            handle.write(replacement)
            handle.flush()
            os.fsync(handle.fileno())
        os.chmod(temporary, target.stat().st_mode)
        current_root, current_pack, _product, current_target, _paths = _scope(root, pack, action, path, allowed_packs)
        if current_root != root or current_pack != pack or current_target != target or _read(target)[0] != raw:
            raise details._Invalid("This workflow record changed during the save. Reload before trying again.")
        if receipt is not None:
            current_candidate = workflow_forms.candidate_context(root, pack, receipt=receipt, build_id=build_id,
                candidate_path=candidate_path, allowed_packs=allowed_packs)
            if not current_candidate["ok"] or current_candidate["inputs"] != candidate["inputs"]:
                raise details._Invalid("The selected candidate evidence changed during the save. Reload and review its current identity.")
        os.replace(temporary, target)
        temporary = None
        return {**_description(root, pack, target, paths, replacement, text, new_doc, new_leaves), "changed": True}
    except FileExistsError:
        return _fail("Another edit is in progress for this record. Wait for it to finish, then reload.")
    except (details._Invalid, OSError, ValueError, TypeError, UnicodeError, yaml.YAMLError, RecursionError, KeyError) as error:
        return _fail(str(error) if isinstance(error, details._Invalid) else "The record could not be saved safely. The original file was retained.")
    finally:
        if temporary is not None:
            try:
                temporary.unlink(missing_ok=True)
            except OSError:
                pass
        if lock_fd is not None:
            os.close(lock_fd)
            try:
                lock_path.unlink(missing_ok=True)
            except OSError:
                pass
