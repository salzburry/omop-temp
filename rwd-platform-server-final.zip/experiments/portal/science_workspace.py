"""Connect canonical science readers and explicit, private review proposals.

Canonical readers execute in a disposable checkout containing only accessible
product metadata. They keep their own schemas and root discovery; the Streamlit
process never patches a shared module's repository globals.
"""
from __future__ import annotations

from datetime import datetime, timezone
import difflib
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import tempfile
import uuid

import yaml

ROUTES = {
    "definition_reuse": "Choose a reusable definition",
    "variable_lineage": "Explain a variable",
    "clinical_standards": "Review clinical meaning",
    "template_review": "Review reusable template concepts",
    "definition_identity": "Register definition and dataset claims",
    "dataset_comparison": "Compare dataset implementations",
}
CODE_ROOT = Path(__file__).resolve().parents[2]
MAX_FILE = 24 * 1024 * 1024


def _hash(value):
    return hashlib.sha256(value if isinstance(value, bytes) else
                          json.dumps(value, sort_keys=True, ensure_ascii=False).encode()).hexdigest()


def _safe(path):
    if path.resolve() != path:
        raise ValueError("A science input or saved proposal redirects outside its declared location.")
    return path


def _scope(root, pack, actor_id, allowed_packs):
    import design_workspace as dw
    root, pack, owner, _directory = dw._store(root, pack, actor_id, allowed_packs)
    scope = set(allowed_packs) if allowed_packs is not None else {pack}
    scope.add(pack)
    for name in scope:
        dw._pack_path(root, name, scope)
    return root, pack, owner, _safe(root / pack / ".portal-drafts/science" / owner), scope


def _inputs(root, scope):
    """Bound metadata and code, excluding workbooks, deliveries, and private drafts."""
    import workflow_outputs
    files = {}

    def add(path, name=None):
        _safe(path)
        if not path.is_file():
            return
        if path.stat().st_size > MAX_FILE:
            raise ValueError("A science metadata input exceeds the 24 MB limit: " + path.name)
        files[name or path.relative_to(root).as_posix()] = path.read_bytes()

    for pack in sorted(scope):
        product = root / pack
        for folder in ("config", "variables", "codelists", "handoff"):
            base = _safe(product / folder)
            if base.exists():
                for file in sorted(base.rglob("*")):
                    _safe(file)
                    if workflow_outputs.is_saved_output(file.relative_to(root).as_posix()):
                        continue
                    if file.suffix.lower() in {".yaml", ".yml", ".json", ".md"}:
                        add(file)
        for rel in ("source_refs.yaml", "spec_pipeline/out/extracted.json", "spec_pipeline/pipeline.conf"):
            add(product / rel)
        # Canonical config readers may open declared variable/codelist files.
        # Every reference must resolve inside this product snapshot.
        cfg = files.get(pack + "/config/data_product.yaml")
        if cfg:
            doc = yaml.safe_load(cfg) or {}
            refs = [*(doc.get("variables") or []), *(doc.get("codelists") or {}).values()]
            for ref in refs:
                if not isinstance(ref, str) or Path(ref).is_absolute() or not (product / ref).resolve().is_relative_to(product):
                    raise ValueError("A configuration lookup names metadata outside its product; review its declared paths first.")
                # Explicit consumers remain inputs even if a person places one
                # under a folder normally reserved for derived review records.
                add(product / ref)
        # Build evidence is metadata; scope both registry code and folder spelling.
        parts = pack.split("/")
        ledgers = {"/".join(parts[1:])}
        reg_path = root / parts[0] / "registry.yaml"
        if _safe(reg_path).is_file():
            reg = yaml.safe_load(reg_path.read_bytes()) or {}
            for entry in reg.get("tumors") or []:
                if entry.get("slug") == parts[2] and entry.get("code"):
                    ledgers.add("/".join([parts[1], str(entry["code"]), parts[3]]))
        for ledger in ledgers:
            base = _safe(root / "refreshes" / ledger)
            if base.is_dir():
                for file in sorted(base.glob("*.yaml")):
                    add(file)
    for base in ("products", "fixtures"):
        source = _safe(root / base / "registry.yaml")
        doc = yaml.safe_load(source.read_bytes()) if source.is_file() else {"tumors": []}
        doc = doc or {}
        slugs = {p.split("/")[2] for p in scope if p.startswith(base + "/")}
        doc["tumors"] = [entry for entry in doc.get("tumors") or [] if entry.get("slug") in slugs]
        files[base + "/registry.yaml"] = yaml.safe_dump(doc, sort_keys=False).encode()
    governance = _safe(root / "governance")
    if governance.is_dir():
        for file in sorted(governance.rglob("*")):
            _safe(file)
            if file.suffix.lower() not in {".yaml", ".yml", ".json", ".md"} or not file.is_file():
                continue
            # Decisions/precedents are product work, not shared reference content.
            if file.parent != governance and "reference" not in file.relative_to(governance).parts:
                continue
            add(file)
    ruling_key = "governance/EQUIVALENCE_RULINGS.yaml"
    if ruling_key in files:
        doc = yaml.safe_load(files[ruling_key]) or {}
        doc["rulings"] = [row for row in doc.get("rulings") or [] if row.get("decision_pack") in scope]
        files[ruling_key] = yaml.safe_dump(doc, sort_keys=False).encode()
    # Shared reference declarations are visible; governed product records remain scoped.
    for folder in ("platform/tools", "platform/engine"):
        base = CODE_ROOT / folder
        for file in sorted(base.rglob("*")):
            if file.suffix.lower() in {".py", ".yaml", ".yml"}:
                add(file, file.relative_to(CODE_ROOT).as_posix())
    for rel in ("platform/capabilities.yaml", "platform/CAPABILITIES.md"):
        add(CODE_ROOT / rel, rel)
    for pack in scope:
        name = pack.split("/")[2]
        add(CODE_ROOT / "platform/tests/fixtures" / (name + "_goldens.yaml"),
            "platform/tests/fixtures/" + name + "_goldens.yaml")
    return files


def _digest(files):
    return _hash({name: _hash(raw) for name, raw in sorted(files.items())})


def _run(files, request):
    with tempfile.TemporaryDirectory(prefix="science-review-") as directory:
        staged = Path(directory).resolve()
        for name, raw in files.items():
            path = staged / name
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_bytes(raw)
        payload = {**request, "root": str(staged)}
        proc = subprocess.run([sys.executable, str(Path(__file__).resolve()), "--worker"],
                              input=json.dumps(payload), text=True, encoding="utf-8", errors="replace",
                              capture_output=True, cwd=staged, timeout=90,
                              env={**os.environ, "PYTHONUTF8": "1", "PYTHONDONTWRITEBYTECODE": "1"})
        if proc.returncode:
            raise ValueError("The existing science reader could not finish: " + proc.stderr[-1500:])
        try:
            result = json.loads(proc.stdout)
        except json.JSONDecodeError as exc:
            raise ValueError("The science reader did not return a usable report.") from exc
        # Never present an ephemeral checkout as the user's product path.
        return json.loads(json.dumps(result).replace(str(staged).replace("\\", "\\\\"), "<review snapshot>"))


def describe(root, pack, actor_id, *, route, allowed_packs=None, variable=None, item_id=None, relation_query=None):
    try:
        if route not in ROUTES:
            raise ValueError("Choose a connected science workflow.")
        root, pack, owner, folder, scope = _scope(root, pack, actor_id, allowed_packs)
        files = _inputs(root, scope)
        digest = _digest(files)
        request = {"route": route, "pack": pack, "scope": sorted(scope),
                   "variable": variable, "item_id": item_id, "relation_query": relation_query}
        import review_read_cache
        cache_key = _hash([str(root), owner, digest, request])
        report = review_read_cache.read(cache_key, lambda: _run(files, request))
        return {"ok": not bool(report.get("errors")), "errors": [], "pack": pack, "route": route,
                "input_digest": digest, **report}
    except (OSError, ValueError, TypeError, KeyError, AttributeError, yaml.YAMLError, subprocess.TimeoutExpired) as error:
        return {"ok": False, "errors": [str(error)], "route": route}


def _record_path(folder, proposal_id):
    if not isinstance(proposal_id, str) or not re.fullmatch(r"[0-9a-f]{32}", proposal_id):
        raise ValueError("Choose a saved proposal from this product.")
    return _safe(folder / (proposal_id + ".json"))


def read(root, pack, actor_id, proposal_id, *, allowed_packs=None):
    try:
        root, pack, owner, folder, scope = _scope(root, pack, actor_id, allowed_packs)
        path = _record_path(folder, proposal_id)
        if path.stat().st_size > 2 * 1024 * 1024:
            raise ValueError("The saved proposal exceeds its metadata limit.")
        value = json.loads(path.read_bytes())
        signed = dict(value)
        digest = signed.pop("payload_sha256", None)
        if value.get("owner") != owner or value.get("pack") != pack or value.get("id") != proposal_id or digest != _hash(signed):
            raise ValueError("The saved proposal does not match this product and editing identity.")
        if not set(value.get("scope") or []).issubset(scope):
            raise ValueError("The proposal includes products outside your current access. Start a comparison within your current scope.")
        return {"ok": True, "proposal": value, "errors": []}
    except (OSError, ValueError, TypeError, KeyError, AttributeError) as error:
        return {"ok": False, "errors": [str(error)]}


def recent(root, pack, actor_id, *, allowed_packs=None):
    try:
        _, _, _, folder, _ = _scope(root, pack, actor_id, allowed_packs)
        if not folder.is_dir():
            return []
        found = []
        for path in sorted(folder.glob("*.json")):
            result = read(root, pack, actor_id, path.stem, allowed_packs=allowed_packs)
            if not result["ok"]:
                continue
            p = result["proposal"]
            found.append({"id": p["id"], "route": p["route"], "title": p["title"],
                          "state": p["state"], "summary": p["summary"], "params": {"proposal_id": p["id"]},
                          "updated_at": p["created_at"]})
        return sorted(found, key=lambda row: row["updated_at"], reverse=True)
    except (OSError, ValueError, TypeError, AttributeError):
        return []


def draft_target(root, pack, actor_id, proposal_id, *, allowed_packs=None):
    """Preview the exact unfinished row draft that an explicit reuse choice will change."""
    result = read(root, pack, actor_id, proposal_id, allowed_packs=allowed_packs)
    if not result["ok"]:
        return result
    proposal = result["proposal"]
    if proposal["route"] not in {"definition_reuse", "template_review"}:
        return {"ok": False, "errors": ["This proposal does not contain a scientific interpretation."]}
    item_id = proposal["next"]["params"].get("item_id")
    if not item_id:
        return {"ok": False, "errors": ["This record has no current specification-row link. Resolve its source citation first."]}
    import scientific_definitions as definitions
    target = definitions.describe(root, pack, actor_id, item_id=item_id, allowed_packs=allowed_packs)
    return {**target, "proposal": proposal}


def use_in_draft(root, pack, actor_id, proposal_id, *, expected_draft_digest,
                 allowed_packs=None, local_demo=False, can_write=False):
    try:
        if local_demo is not True or can_write is not True:
            raise ValueError("Editing a row draft requires an authorized local editing session.")
        target = draft_target(root, pack, actor_id, proposal_id, allowed_packs=allowed_packs)
        if not target["ok"]:
            return target
        proposal = target["proposal"]
        root, pack, owner, folder, scope = _scope(root, pack, actor_id, allowed_packs)
        files = _inputs(root, scope)
        if _digest(files) != proposal["input_digest"]:
            raise ValueError("This proposal's product or reference evidence changed. Compare the current records and save a new proposal first.")
        if target["draft_digest"] != expected_draft_digest:
            raise ValueError("Your scientific row draft changed. Review it again before copying this interpretation.")
        if proposal["values"].get("disposition") == "defer":
            raise ValueError("A deferred choice remains a review question; it has no interpretation to copy.")
        artifact = proposal["artifact"]
        if proposal["route"] == "definition_reuse":
            # Re-read the candidate and apply today's logic/value boundary even
            # for proposals saved before that boundary existed.
            checked = _run(files, {"route": "definition_reuse", "pack": pack, "scope": sorted(scope),
                                   "operation": "stage", "values": proposal["values"]})
            if checked.get("errors"):
                raise ValueError(" ".join(str(error) for error in checked["errors"]))
            artifact = checked["artifact"]
        interpretation = artifact.get("derivation", artifact.get("interpretation", ""))
        if not interpretation.strip():
            raise ValueError("Write the proposed interpretation before copying it into a row draft.")
        values = dict(target["values"])
        values["derivation"] = interpretation
        if _digest(_inputs(root, scope)) != proposal["input_digest"]:
            raise ValueError("The product or reference evidence changed while checking this proposal. Reload the comparison before copying its logic.")
        import scientific_definitions as definitions
        result = definitions.save_draft(root, pack, actor_id, target["selected"]["item_id"], values,
                                        expected_input_digest=target["input_digest"], expected_draft_digest=expected_draft_digest,
                                        allowed_packs=allowed_packs, local_demo=local_demo, can_write=can_write)
        return {**result, "next": proposal["next"]}
    except (OSError, ValueError, TypeError, KeyError, AttributeError) as error:
        return {"ok": False, "errors": [str(error)]}


def stage(root, pack, actor_id, *, route, values, expected_input_digest,
          allowed_packs=None, local_demo=False, can_write=False):
    """Create an immutable proposal, including failed validation for further editing."""
    try:
        if local_demo is not True or can_write is not True:
            raise ValueError("Saving a science proposal requires an authorized local editing session.")
        if route not in {"definition_reuse", "clinical_standards", "template_review", "definition_identity"}:
            raise ValueError("This science workflow is read-only.")
        root, pack, owner, folder, scope = _scope(root, pack, actor_id, allowed_packs)
        if not isinstance(values, dict) or len(json.dumps(values)) > 64000:
            raise ValueError("Keep the proposal to one displayed definition or binding.")
        files = _inputs(root, scope)
        digest = _digest(files)
        if digest != expected_input_digest:
            raise ValueError("The product or its reference evidence changed. Reload the comparison before saving.")
        result = _run(files, {"route": route, "pack": pack, "scope": sorted(scope), "operation": "stage", "values": values})
        if result.get("errors"):
            return {"ok": False, "errors": result["errors"]}
        proposal = {"schema_version": 1, "id": uuid.uuid4().hex, "pack": pack, "owner": owner,
                    "scope": sorted(scope), "route": route, "title": ROUTES[route],
                    "created_at": datetime.now(timezone.utc).isoformat(), "input_digest": digest,
                    "inputs": {name: _hash(raw) for name, raw in sorted(files.items())},
                    "values": values, "draft_only": True, "approval_created": False,
                    "state": "needs_attention" if result.get("findings") else "staged",
                    **result}
        proposal["payload_sha256"] = _hash(proposal)
        folder.mkdir(parents=True, exist_ok=True)
        _scope(root, pack, actor_id, allowed_packs)
        # Freshness is checked again after the canonical validator has run.
        if _digest(_inputs(root, scope)) != digest:
            raise ValueError("Evidence changed during validation. Reload and compare the current records.")
        path = _record_path(folder, proposal["id"])
        with path.open("xb") as stream:
            stream.write(json.dumps(proposal, indent=2, ensure_ascii=False).encode())
        return {"ok": True, "proposal": proposal, "errors": []}
    except (OSError, ValueError, TypeError, KeyError, AttributeError, yaml.YAMLError, subprocess.TimeoutExpired) as error:
        return {"ok": False, "errors": [str(error)]}


def _worker(request):
    """Uses the canonical readers from the metadata checkout, in this process only."""
    root = Path(request["root"])
    sys.path[:0] = [str(root / "platform/tools"), str(root / "platform/engine"), str(root / "platform")]
    import contract_lint as cl
    import concept_reuse as reuse
    import rule_review as rules
    import product_gates as pg
    from spec_extract import requirement_rows, is_context, row_item_id
    pack = root / request["pack"]
    route = request["route"]
    records = rules.chain(str(pack))
    source_rows = []
    extracted = pack / "spec_pipeline/out/extracted.json"
    if extracted.is_file():
        import contract_scaffold as cs
        for row in requirement_rows(json.loads(extracted.read_bytes())):
            if row.get("variable") and not is_context(row):
                definition, notes = cs._definition_and_notes(row)
                source_rows.append({"item_id": row_item_id(row),
                                    "variable_id": cs._scalar(row["variable"]), "definition": definition,
                                    "spec_fields": row.get("fields") if isinstance(row.get("fields"), dict) else {}})
    variable = request.get("variable") or (request.get("values") or {}).get("variable")
    item_id = request.get("item_id") or (request.get("values") or {}).get("item_id")
    selected = next((row for row in source_rows if row["item_id"] == item_id), None)
    if selected:
        variable = selected["variable_id"]
    if variable is None:
        variable = records[0]["variable_id"] if records else source_rows[0]["variable_id"] if source_rows else None
    current = next((row for row in records if item_id and item_id in row["spec"]["refs"]), None)
    if item_id and selected is None and current is None:
        raise ValueError("The selected specification row is unavailable. Choose its current sheet-specific row before continuing.")
    if not item_id:
        current = current or next((row for row in records if row["variable_id"] == variable), None)
    if current:
        variable = current["variable_id"]
    if not item_id:
        selected = selected or next((row for row in source_rows if row["variable_id"] == variable), None)
    if not current and selected:
        current = {"variable_id": variable, "derivation": "", "status": "{requirement: draft}",
                   "spec": {"refs": [selected["item_id"]], "rule": selected["definition"], "digest": ""},
                   "interpreted": [], "executable": [], "unresolved": [], "decisions": []}
    common = {"records": records, "source_rows": source_rows, "variable": variable,
              "item_id": (selected or {}).get("item_id") or (((current or {}).get("spec") or {}).get("refs") or [None])[0],
              "current": current, "warnings": []}
    if request.get("operation") == "stage":
        return _stage_worker(root, pack, route, request["values"], request["scope"], common)
    if route in {"definition_reuse", "variable_lineage"}:
        import knowledge_search as knowledge
        terms = [str(variable or "").lower()]
        common["references"] = knowledge._inventory(terms, str(root)) + knowledge._capabilities(terms, str(root))
        if route == "definition_reuse":
            import definition_reuse_logic
            import master_variable_library
            by_pack = {name: {row["variable_id"]: row for row in rules.chain(str(root / name))}
                       for name in request["scope"]}
            if current:
                by_pack.setdefault(request["pack"], {})[variable] = current
            result = reuse.inheritable(request["pack"], by_pack, variable)
            examples = result[0]["candidates"] if result else []
            for candidate in examples:
                candidate["record"] = by_pack[candidate["pack"]][candidate["variable_id"]]
                candidate["source_kind"] = "product_example"
            candidates = master_variable_library.candidates(root, variable) + examples
            for candidate in candidates:
                candidate.update(definition_reuse_logic.describe(candidate["record"]))
                candidate["key"] = _hash([candidate["pack"], candidate["variable_id"]])[:24]
                candidate["diff"] = "\n".join(difflib.unified_diff(
                    ((current or {}).get("derivation") or "").splitlines(),
                    candidate["record"]["derivation"].splitlines(), fromfile="Current interpretation", tofile="Existing definition", lineterm=""))
            return {**common, "candidates": candidates}
        if current and current in records:
            import receipt
            import competency
            common.update(receipt=receipt.receipt(str(pack), variable), competency=competency.ask(str(pack), variable),
                          overlaps=rules.overlaps(current), value_sets=rules.value_sets(current))
        else:
            common["warnings"].append("This source row has no saved scientific definition yet. Draft it to create the first link in its lineage.")
        return common
    if route == "clinical_standards":
        import semantic_binding as sb
        import mcode_crosswalk as mcode
        doc, problems = sb.read(str(pack))
        common.update(bindings=doc, findings=sb.errors(str(pack)), umls_enabled=sb.umls_enabled(),
                      candidates={key: sorted(value) for key, value in sb.candidates(str(pack)).items()},
                      concept_names=sb.concept_names() if sb.umls_enabled() else {}, labs=sb.lab_codes(), crosswalk=[])
        slots, why = sb.registry_slots(str(pack))
        common["slots"] = sorted(slots)
        if why:
            common["warnings"].append(why)
        if mcode.DICTIONARY.is_file():
            slug = pg.tumour_key_for(str(root), request["pack"])
            common["crosswalk"] = mcode.crosswalk(tumour=slug)["rows"]
        else:
            common["warnings"].append("The mCODE dictionary is absent. The terminology steward must install governance/reference/mcode_stu4/DICTIONARY.json using mcode_ingest before profile candidates can be ranked. Existing bindings and other declared axes remain reviewable.")
        import clinical_relation_review
        relation_query = request.get("relation_query")
        if relation_query is None:
            relation_query = str(pg.tumour_key_for(str(root), request["pack"]) or request["pack"].split("/")[2]).replace("_", " ")
        common["relation_review"] = clinical_relation_review.describe(query=relation_query,
            bound_concept=((doc or {}).get("variables") or {}).get(variable, {}).get("concept"))
        return common
    if route == "template_review":
        import template_reconcile as templates
        import oncology_registry as registry
        report = templates.match(str(pack), draft=True)
        return {**common, "reconciliation": report, "findings": templates.reconcile_errors(report),
                "worklist": templates.worklist(report), "catalogue": registry.catalogue()}
    if route == "definition_identity":
        import definition_registry as dr
        import definition_signature as ds
        from config import merged_raw
        registered, problems = dr.read(str(root))
        config = merged_raw(pack / "config/data_product.yaml")
        implementation, issues = dr.implementations(request["pack"], str(root))
        proposed = dr.propose(request["pack"], str(root))
        return {**common, "registered": registered, "signatures": ds.signatures(str(pack)),
                "proposed_definitions": yaml.safe_load(proposed) if proposed else [],
                "implementations": implementation, "roles": sorted((config.get("sources") or {}).keys()),
                "findings": problems + issues + dr.register_errors(str(root)) + dr.implementation_errors(request["pack"], str(root))}
    if route == "dataset_comparison":
        import semantic_view as sv
        return {**common, "comparison": sv.view(str(pack))}
    raise ValueError("Unknown science workflow.")


def _stage_worker(root, pack, route, values, scope, common):
    """Validate exact displayed choices, never trust caller-authored provenance."""
    import contract_lint as cl
    variable, current = common["variable"], common["current"]
    if not current:
        raise ValueError("Select a requirement or saved scientific definition before proposing a change.")
    allowed = {"variable", "item_id", "reason"}
    fields = {"definition_reuse": {"candidate", "disposition", "interpretation", "logic_reviewed"},
              "clinical_standards": {"axis", "value", "disposition"},
              "template_review": {"slot", "disposition", "interpretation"},
              "definition_identity": {"kind", "definition_id", "concept", "registered_by", "registration_date", "supersedes", "dataset", "roles", "reviewed_by", "review_date", "master"}}
    if set(values) - allowed - fields[route]:
        raise ValueError("Supply only the displayed proposal fields; provenance and statuses are supplied by the workflow.")
    reason = str(values.get("reason") or "").strip()
    if not reason or len(reason) > 8000:
        raise ValueError("Explain the proposed choice in a short review note.")
    report = _worker({"root": str(root), "pack": pack.relative_to(root).as_posix(), "scope": scope,
                      "route": route, "variable": variable, "item_id": common["item_id"]})
    findings, artifact, before, validators = [], {}, "", []
    if route == "definition_reuse":
        candidate = next((row for row in report["candidates"] if row["key"] == values.get("candidate")), None)
        if not candidate or values.get("disposition") not in {"inherit", "adapt", "diverge", "defer"}:
            raise ValueError("Choose an existing candidate and a reuse disposition from the current comparison.")
        text = str(values.get("interpretation") or "")
        if values["disposition"] in {"inherit", "adapt", "diverge"} and not text.strip():
            raise ValueError("Write the proposed interpretation, or defer the choice with a review question.")
        import definition_reuse_logic
        definition_reuse_logic.validate(candidate["record"], text,
            disposition=values["disposition"], logic_reviewed=values.get("logic_reviewed") is True)
        artifact = {"variable_id": variable, "spec_refs": current["spec"]["refs"], "derivation": text,
                    "reuse": values["disposition"], "source": candidate["record"], "source_pack": candidate["pack"], "reason": reason}
        before = current["derivation"]
        after = text
        if not candidate["settled"]:
            findings.append(candidate["caveat"])
        findings.append("Scientific row validation remains required before this interpretation enters the functional contract.")
        validators = ["Master library or accessible product reference re-read with its identity and source status",
                      "definition_reuse_logic.validate: product values remain separate from reusable logic"]
    elif route == "clinical_standards":
        import semantic_binding as sb
        if current not in report["records"]:
            raise ValueError("Save the scientific definition before binding its clinical meaning.")
        axis, value = values.get("axis"), str(values.get("value") or "").strip()
        disposition = values.get("disposition")
        if axis not in (*sb.BINDING_AXES, "mcode_profile", "concept_set") or disposition not in {"accept", "reject", "defer"} or not value:
            raise ValueError("Choose a supported binding axis, value and explicit disposition.")
        import definition_registry as dr
        known = {"concept": set(report["concept_names"]), "lab": set(report["labs"]),
                 "registry_concept": set(report["slots"]),
                 "definition": {row["definition_id"] for row in dr.read(str(root))[0]},
                 "concept_set": {entry["name"] for entry in report["relation_review"]["sets"]},
                 "mcode_profile": {candidate["profile"] for row in report["crosswalk"]
                                   if str(row["name"]).lower() == str(variable).lower() for candidate in row["candidates"]}}
        if value not in known[axis]:
            raise ValueError("That clinical meaning is not carried by the current reference layer. Ask the terminology steward to register it first.")
        artifact = {"variable": variable, "axis": axis, "value": value, "disposition": disposition, "reason": reason}
        if axis == "concept_set":
            artifact.update(scope="product", affected_variables=[record["variable_id"] for record in report["records"]],
                concept_set=next(entry for entry in report["relation_review"]["sets"] if entry["name"] == value),
                relation_release=report["relation_review"]["release"])
        baseline = report["bindings"] or {}
        before = yaml.safe_dump(baseline, sort_keys=False)
        if disposition == "accept" and axis != "mcode_profile":
            if axis == "concept_set":
                baseline["concept_set"] = value
            else:
                baseline.setdefault("variables", {}).setdefault(variable, {}).update({axis: value, "status": "active"})
            target = pack / "config/semantic.yaml"
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_text(yaml.safe_dump(baseline, sort_keys=False), encoding="utf-8")
        after = yaml.safe_dump(baseline, sort_keys=False)
        artifact["proposed_semantic_yaml"] = after
        findings = sb.errors(str(pack))
        validators = ["semantic_binding.errors (including semantic approval checks)"]
        if axis == "concept_set":
            validators.append("umls_relations.layer_errors + concept_sets + set_errors: active and excluded members re-read")
            findings.append("This scopes the entire product to the recorded set, not only the selected variable. Associations do not establish clinical equivalence; the scientific reviewer must assess the active and excluded population members.")
        if axis == "mcode_profile":
            artifact["candidate_evidence"] = [candidate for row in report["crosswalk"]
                if str(row["name"]).lower() == str(variable).lower() for candidate in row["candidates"] if candidate["profile"] == value]
            validators.append("mcode_crosswalk.crosswalk: current ranked profile and carrier evidence re-read")
            findings.append("mCODE profile disposition is recorded for terminology review. The semantic binding schema does not execute a profile mapping; implementation needs the declared carrier and supported binding axis.")
    elif route == "template_review":
        import template_reconcile as templates
        import oncology_registry as registry
        rows = [row for bucket in templates.BUCKETS for row in report["reconciliation"][bucket]
                if row["variable_id"] == variable]
        candidate = next((c for row in rows for c in row.get("candidates") or [] if c["slot"] == values.get("slot")), None)
        if not candidate or values.get("disposition") not in {"inherit", "adapt", "diverge", "defer"}:
            raise ValueError("Choose a proposed concept from this row's reconciliation and an explicit disposition.")
        artifact = {"variable": variable, "slot": candidate["slot"], "disposition": values["disposition"],
                    "interpretation": str(values.get("interpretation") or ""), "reason": reason,
                    "candidate": candidate, "provenance": report["reconciliation"]["digest"]}
        before = current["derivation"]
        after = artifact["interpretation"]
        findings = templates.reconcile_errors(report["reconciliation"]) + registry.registry_errors()
        validators = ["template_reconcile.match + reconcile_errors", "oncology_registry.registry_errors"]
    else:
        import definition_registry as dr
        kind = values.get("kind")
        rel = pack.relative_to(root).as_posix()
        if kind == "registration":
            proposed = next((row for row in report["proposed_definitions"] or [] if row["master"] == values.get("master")), None)
            if not proposed:
                raise ValueError("This family has no current unregistered definition signature. Review configuration first; never type a signature digest.")
            proposed.update({key: str(values.get(key) or "") for key in ("definition_id", "concept", "registered_by", "registration_date", "supersedes")})
            proposed["note"] = reason
            doc = {"definitions": report["registered"]}
            before = yaml.safe_dump(doc, sort_keys=False)
            doc["definitions"].append(proposed)
            (root / dr.REGISTRY).write_text(yaml.safe_dump(doc, sort_keys=False), encoding="utf-8")
            artifact = {"target": Path(dr.REGISTRY).as_posix(), "entry": proposed}
            findings = dr.register_errors(str(root)) + dr.pack_errors(rel, str(root))
            if not proposed["registered_by"].strip():
                findings.append("Definition proposal registered_by: no registration author is recorded.")
            after = yaml.safe_dump(doc, sort_keys=False)
            validators = ["definition_registry.register_errors", "definition_registry.pack_errors"]
        elif kind == "implementation":
            if current not in report["records"]:
                raise ValueError("Save the scientific definition before creating an implementation claim.")
            if values.get("definition_id") not in {row["definition_id"] for row in report["registered"]}:
                raise ValueError("Choose a currently registered definition; stage missing identity registration first.")
            roles = values.get("roles") or []
            if not roles or not isinstance(roles, list) or set(roles) - set(report["roles"]):
                raise ValueError("Choose the declared source roles this implementation reads.")
            doc = report["implementations"] or {"dataset": "", "implements": []}
            before = yaml.safe_dump(doc, sort_keys=False)
            dataset = str(values.get("dataset") or "").strip()
            if not dataset or len(dataset) > 100:
                raise ValueError("Name the dataset implemented by this product, for example the recorded delivery vendor.")
            doc["dataset"] = dataset
            entry = {"variable": variable, "definition": values["definition_id"], "roles": roles,
                     "reviewed_by": str(values.get("reviewed_by") or ""), "review_date": str(values.get("review_date") or ""), "note": reason}
            doc["implements"] = [row for row in doc.get("implements") or [] if row["variable"] != variable] + [entry]
            (pack / dr.IMPLEMENTATIONS).write_text(yaml.safe_dump(doc, sort_keys=False), encoding="utf-8")
            artifact = {"target": Path(dr.IMPLEMENTATIONS).as_posix(), "document": doc}
            findings = dr.implementation_errors(rel, str(root))
            if not entry["reviewed_by"].strip():
                findings.append("Implementation proposal reviewed_by: no claim reviewer is recorded.")
            after = yaml.safe_dump(doc, sort_keys=False)
            validators = ["definition_registry.implementation_errors"]
        else:
            raise ValueError("Choose definition registration or dataset implementation.")
    diff = "\n".join(difflib.unified_diff(before.splitlines(), after.splitlines(), fromfile="Current record", tofile="Proposed record", lineterm=""))
    result = {"summary": f"{variable}: {values.get('disposition') or values.get('kind')} — {reason[:180]}",
            "artifact": artifact, "diff": diff, "findings": findings, "validators": validators,
            "next": {"route": "scientific_draft" if route in {"definition_reuse", "template_review"} else "progress",
                     "params": {"item_id": common["item_id"]} if route in {"definition_reuse", "template_review"} else {}}, "errors": []}
    if route == "clinical_standards":
        result["review_context"] = {"variable": variable, "item_id": common["item_id"],
                                    "spec": current.get("spec") or {}, "derivation": current.get("derivation") or "",
                                    "status": current.get("status") or ""}
    return result


if __name__ == "__main__" and "--worker" in sys.argv:
    try:
        result = _worker(json.load(sys.stdin))
    except (Exception, SystemExit) as exc:
        result = {"errors": [str(exc)]}
    print(json.dumps(result, ensure_ascii=False, default=lambda value: sorted(value) if isinstance(value, set) else str(value)))
