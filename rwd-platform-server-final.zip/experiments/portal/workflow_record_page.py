"""Scoped human editing for existing scientific workflow records."""
from pathlib import Path
import datetime
import hashlib

import streamlit as st

import workflow_record_editor as editor


def clear():
    for key in list(st.session_state):
        if str(key).startswith("workflow_record_"):
            st.session_state.pop(key, None)


def _remember(path, field_id=None, key=None):
    drafts = dict(st.session_state.get("workflow_record_drafts") or {})
    entry = dict(drafts[path])
    if field_id is None:
        entry["text"] = st.session_state.get("workflow_record_text", "")
    else:
        values = dict(entry.get("values") or {})
        values[field_id] = st.session_state.get(key)
        entry["values"] = values
    entry["dirty"] = True
    drafts[path] = entry
    st.session_state["workflow_record_drafts"] = drafts
    st.session_state["workflow_record_confirm"] = False


def render(root, pack, action, actor_id, *, path=None, local_demo, can_review, can_view,
           receipt=None, build_id=None):
    if not can_view:
        clear()
        st.warning("You no longer have access to this workflow record.")
        return False
    context = (str(Path(root).resolve()), pack, actor_id, receipt, build_id)
    previous = st.session_state.get("workflow_record_context")
    changed_context = previous is not None and previous != context
    if previous != context:
        clear()
        st.session_state["workflow_record_context"] = context
    candidate_path, candidate = None, None
    if receipt is not None:
        import workflow_forms_page
        candidate_path, candidate = workflow_forms_page._candidate_selection(root, pack,
            prefix="workflow_record_", receipt=receipt, build_id=build_id)
        if not candidate["ok"]:
            return False
    probe = editor.describe(root, pack, action, path, allowed_packs=[pack])
    st.write("**Edit the workflow record**")
    if not probe.get("ok"):
        for error in probe.get("errors") or ["The workflow record is unavailable."]:
            st.warning(str(error))
        return False
    paths = probe["paths"]
    if st.session_state.get("workflow_record_selected") not in paths:
        st.session_state["workflow_record_selected"] = probe["path"]
    selected = st.selectbox("Record", paths, key="workflow_record_selected", format_func=lambda value: value[len(pack) + 1:])
    if selected != probe["path"]:
        probe = editor.describe(root, pack, action, selected, allowed_packs=[pack])
        if not probe.get("ok"):
            for error in probe.get("errors") or ["The record could not be read."]:
                st.warning(str(error))
            return False
    drafts = dict(st.session_state.get("workflow_record_drafts") or {})
    if selected not in drafts:
        drafts[selected] = {"description": probe, "text": probe["text"], "values": {}, "dirty": False,
                            "mode": "Fields" if probe["format"] == "yaml" else "Document"}
        st.session_state["workflow_record_drafts"] = drafts
    draft = drafts[selected]
    description = draft["description"]
    if candidate is not None:
        identities = {field["path"][0]: field["value"] for field in description["fields"] if len(field["path"]) == 1}
        if any(identities.get(key) != value for key, value in candidate["digests"].items()):
            st.warning("This saved approval names a different candidate. Correct its build ID and manifest digest below, and enter the people and dates who reviewed this selected build.")
        with st.expander("Selected candidate identity", expanded=True):
            st.table([{"Field": key, "Required value": value} for key, value in candidate["digests"].items()])
    if st.session_state.get("workflow_record_active") != selected:
        for key in list(st.session_state):
            if str(key).startswith("workflow_record_value_") or key in {"workflow_record_text", "workflow_record_mode", "workflow_record_group", "workflow_record_confirm"}:
                st.session_state.pop(key, None)
        st.session_state["workflow_record_active"] = selected
    enabled = local_demo is True and can_review is True and not changed_context
    if not enabled:
        st.info("Saving this record requires reviewer access in a local session.")
    st.caption(editor.NOTICE)
    if probe["digest"] != description["digest"]:
        st.warning("This record changed outside the editor. Your draft is retained; reload and compare before saving.")
    mode = "Document"
    if description["format"] == "yaml":
        st.session_state.setdefault("workflow_record_mode", draft["mode"])
        if draft["dirty"]:
            st.session_state["workflow_record_mode"] = draft["mode"]
        mode = st.radio("Editing view", ["Fields", "Document"], horizontal=True, key="workflow_record_mode", disabled=draft["dirty"])
        draft["mode"] = mode
        if draft["dirty"]:
            st.caption("Save or reload before switching editing views. Your unsaved work is retained.")
    if mode == "Document":
        st.session_state.setdefault("workflow_record_text", draft["text"])
        st.text_area("Scientific record" if description["format"] != "yaml" else "YAML document — add, remove or revise sections explicitly",
                     key="workflow_record_text", height=450, disabled=not enabled, on_change=_remember, args=(selected,))
    else:
        groups = {}
        for field in description["fields"]:
            at = field["path"]
            group = " / ".join(str(part) for part in (at[:2] if len(at) > 1 and isinstance(at[1], int) else at[:1])) or "Record"
            groups.setdefault(group, []).append(field)
        if not groups:
            st.info("This YAML record has no scalar fields. Switch to Document to add its intended sections.")
        else:
            if st.session_state.get("workflow_record_group") not in groups:
                st.session_state["workflow_record_group"] = next(iter(groups))
            group = st.selectbox("Section", list(groups), key="workflow_record_group")
            for field in groups[group]:
                fid = field["id"]
                key = "workflow_record_value_" + hashlib.sha256((selected + fid).encode()).hexdigest()[:20]
                current = draft["values"].get(fid, field["value"])
                st.text(field["label"])
                if field["kind"] == "bool":
                    st.session_state.setdefault(key, bool(current))
                    st.checkbox("Value", key=key, disabled=not enabled or not field["editable"], on_change=_remember, args=(selected, fid, key))
                else:
                    st.session_state.setdefault(key, "" if current is None else str(current))
                    st.text_input("Value", key=key, disabled=not enabled or not field["editable"], on_change=_remember, args=(selected, fid, key))
    st.checkbox("I reviewed these edits and want to save this record. This does not authenticate or release it.", key="workflow_record_confirm", disabled=not enabled)
    if st.button("Save record", key="workflow_record_save", type="primary", disabled=not enabled):
        try:
            arguments = {"text": st.session_state.get("workflow_record_text", draft["text"])} if mode == "Document" else {"updates": {}}
            if mode == "Fields":
                by_id = {field["id"]: field for field in description["fields"]}
                for fid, value in draft["values"].items():
                    field = by_id[fid]
                    if field["kind"] == "number":
                        value = int(value) if isinstance(field["value"], int) else float(value)
                    elif field["kind"] == "date":
                        value = datetime.date.fromisoformat(value)
                    elif field["value"] is None and value == "":
                        value = None
                    if value != field["value"]:
                        arguments["updates"][fid] = value
            result = editor.save(root, pack, action, selected, expected_digest=description["digest"],
                                 confirmed=st.session_state.get("workflow_record_confirm", False), local_demo=local_demo,
                                 can_review=can_review and can_view, allowed_packs=[pack],
                                 receipt=receipt, build_id=build_id, candidate_path=candidate_path, **arguments)
            if result.get("ok"):
                drafts[selected] = {"description": result, "text": result["text"], "values": {}, "dirty": False, "mode": mode}
                st.session_state["workflow_record_drafts"] = drafts
                st.success("Draft record saved. Check status to validate its scientific and workflow requirements.")
                return bool(result.get("changed"))
            for error in result.get("errors") or ["The record could not be saved."]:
                st.error(str(error))
        except (ValueError, TypeError, KeyError):
            st.error("Enter a valid number or ISO date for the edited field. Your draft is retained.")
    if st.button("Reload record", key="workflow_record_reload", help="Discard this record's unsaved draft and read its current bytes."):
        drafts.pop(selected, None)
        st.session_state["workflow_record_drafts"] = drafts
        st.session_state.pop("workflow_record_active", None)
        st.rerun()
    return False
