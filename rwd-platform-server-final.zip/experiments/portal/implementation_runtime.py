"""Fixed synthetic pytest lanes for an explicitly reviewed, installed implementation.

The disposable copy is execution isolation, not a security sandbox. Only reviewed
branch code is eligible. No model response, exit code alone, or skipped R half is
runtime success evidence.
"""
from __future__ import annotations

import ast
import hashlib
import importlib.metadata
import importlib.util
import json
import os
from pathlib import Path
import re
import shutil
import sys
import tempfile
import time
import xml.etree.ElementTree as ET

import portal_runtime

SUITES = {
    "declared": {"title": "Reviewed implementation tests", "selectors": [], "spark": False},
    "spark_stages": {"title": "Synthetic Spark stage assertions", "selectors": ["platform/tests/test_stages_spark.py"], "spark": True},
    "conformance": {"title": "Stage expected outputs and Python/R conformance", "selectors": ["platform/tests/test_stage_conformance.py"], "spark": True},
    "expected_outputs": {"title": "Hand-computed synthetic patient outputs", "selectors": ["platform/tests/test_patient_goldens_spark.py"], "spark": True},
    "synthetic_pipeline": {"title": "Composed synthetic Spark pipeline scenarios", "selectors": ["platform/tests/test_synthetic_spark_uat.py"], "spark": True,
                           "execution_mode": "local_cohort_checkpoints"},
    "selected_product": {"title": "Reviewed expected outputs for this product", "selectors": ["platform/tests/test_selected_product_outputs.py::test_selected_product_expected_outputs"], "spark": True,
                         "execution_mode": "local_cohort_checkpoints"},
}
PER_SUITE_SECONDS = 240
# The golden now finishes in ~180s after removing fixture worker transport.
# Conformance's13 R comparisons completed in1117s. Composed UAT retains11
# independent seven-cohort builds; measured cases took289–350s, so the original
# 30-minute suite limit could not complete them. These finite fixed bounds are
# visible before a run; callers cannot submit an arbitrary timeout.
SUITE_SECONDS = {"conformance": 1800, "synthetic_pipeline": 3600, "selected_product": 900}
TOTAL_SECONDS = 5400
MAX_BYTES = 64 * 1024 * 1024
MAX_REPORT = 4 * 1024 * 1024
NOTICE = "Actual local synthetic test outcomes for the recorded code and fixtures. This does not validate a patient delivery, approve scientific definitions, or release a product."
SKIP_CODES = {"FUED_CARDINALITY": {"decisions": ["FUED-DEFINITION", "DTHFUFL-RULE"],
    "message": "FUED/DTHDT cardinality still needs a reviewed scientific ruling."},
    "SELECTED_CASES_MISSING": {"decisions": [], "message": "Prepare reviewed synthetic expected outputs for this product."}}
BOOTSTRAP = ("import os,runpy,sys; from pathlib import Path; "
    "[os.environ.pop(k,None) for k,v in list(os.environ.items()) if not v]; "
    "sys.path.insert(0,str(Path('platform/tools').resolve())); "
    "exec('if Path(\"platform/tools/java_home.py\").is_file():\\n import java_home; java_home.ensure()'); "
    "sys.argv=['pytest',*sys.argv[1:]]; runpy.run_module('pytest',run_name='__main__')")

# A fixed observer of real pytest reports, not a second test runner. JUnit is
# written at session finish; this atomic journal keeps earlier completed cases
# if a later case times out or the reviewer cancels the process tree.
PARTIAL_PLUGIN = r'''
import hashlib,json,math,os,re
from pathlib import Path
_root=Path.cwd().resolve()
_path=Path(os.environ['RWDP_RUNTIME_JOURNAL'])
_state={'version':1,'collected':{},'phases':{}}
def _key(node):return hashlib.sha256(node.encode()).hexdigest()
def _write():
 raw=json.dumps(_state,sort_keys=True,allow_nan=False).encode()
 if len(raw)>4*1024*1024:raise RuntimeError('Runtime journal size bound exceeded.')
 temporary=_path.with_suffix('.tmp')
 with temporary.open('wb') as stream:stream.write(raw);stream.flush();os.fsync(stream.fileno())
 os.replace(temporary,_path)
def pytest_collection_finish(session):
 if len(session.items)>5000:raise RuntimeError('Runtime collection bound exceeded.')
 for item in session.items:
  relative=item.path.resolve().relative_to(_root).as_posix()
  name=item.name if re.fullmatch(r'[A-Za-z0-9_.-]{1,300}',item.name) else 'nonportable_test_identifier'
  _state['collected'][_key(item.nodeid)]={'path':relative,'function':getattr(item,'originalname',None) or item.name,'name':name}
 _write()
def pytest_runtest_logreport(report):
 key=_key(report.nodeid)
 if key not in _state['collected'] or report.when not in ('setup','call','teardown'):return
 if report.outcome not in ('passed','failed','skipped') or not math.isfinite(report.duration) or report.duration<0:
  raise RuntimeError('Invalid pytest report metadata.')
 phase={'outcome':report.outcome,'seconds':report.duration}
 if report.outcome=='skipped':
  text=str(report.longrepr)[:4000]
  if _state['collected'][key]['function']=='test_fued_and_dthdt_cardinality_follows_the_ruling_not_the_accident' and 'FUED-DEFINITION / DTHFUFL-RULE' in text:phase['skip_code']='FUED_CARDINALITY'
  if _state['collected'][key]['function']=='test_selected_product_expected_outputs' and 'SELECTED-PRODUCT-CASES-MISSING' in text:phase['skip_code']='SELECTED_CASES_MISSING'
 _state['phases'].setdefault(key,{})[report.when]=phase
 _write()
'''


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def branch(root):
    result = portal_runtime.run(["git", "rev-parse", "--verify", "HEAD"], cwd=str(root), timeout_s=5)
    head = result.stdout.strip()
    if result.returncode or not re.fullmatch(r"[a-f0-9]{40,64}", head):
        raise ValueError("Runtime review needs a local Git checkout with an initial commit. Save the installed implementation on your working branch first.")
    result = portal_runtime.run(["git", "symbolic-ref", "--quiet", "--short", "HEAD"], cwd=str(root), timeout_s=5)
    if result.returncode or not result.stdout.strip():
        raise ValueError("Choose a local working branch before preparing runtime checks; a detached checkout is not a branch save.")
    return {"head": head, "name": result.stdout.strip()}


def _safe(root, path):
    if path.is_symlink() or not path.resolve().is_relative_to(root.resolve()):
        raise ValueError("Runtime inputs must be ordinary files inside this checkout.")
    return path


def test_dependencies(root, lanes):
    """Conservative import closure; dynamic readers retain the full test tree.

    Shared engine/tools/fixture metadata remain fully bound. Only unrelated test
    modules are omitted; ambiguous imports include every matching local module.
    """
    root = Path(root)
    files = {p.relative_to(root).as_posix(): p for p in (root / "platform/tests").rglob("*.py")}
    modules_by_path = dict(files)
    for folder in ("platform/tools", "platform/engine"):
        modules_by_path.update({p.relative_to(root).as_posix(): p for p in (root / folder).rglob("*.py")})
    selected = {s.split("::")[0] for lane in lanes for s in lane["selectors"]}
    keep = selected | {name for name, path in files.items() if not path.name.startswith("test_")}
    pending, seen = list(selected | {n for n in files if Path(n).name == "conftest.py"}), set()
    fallback = False
    while pending:
        name = pending.pop()
        if name in seen or name not in modules_by_path:
            continue
        seen.add(name)
        try:
            tree = ast.parse(modules_by_path[name].read_text(encoding="utf-8-sig"))
        except (ValueError, SyntaxError, UnicodeError):
            fallback = True
            break
        modules = set()
        for node in ast.walk(tree):
            if isinstance(node, ast.Import):
                modules.update(alias.name for alias in node.names)
            elif isinstance(node, ast.ImportFrom):
                modules.add(node.module or "")
                modules.update(alias.name for alias in node.names)
            elif isinstance(node, ast.Call):
                fn = node.func.attr if isinstance(node.func, ast.Attribute) else node.func.id if isinstance(node.func, ast.Name) else ""
                if fn in {"__import__", "import_module", "run_path", "run_module", "spec_from_file_location", "Popen", "run", "check_call", "check_output"}:
                    fallback = True
        for module in modules:
            for candidate, path in modules_by_path.items():
                if path.stem in module.split(".") and candidate not in seen:
                    if candidate in files:
                        keep.add(candidate)
                    pending.append(candidate)
    return {"mode": "suite_dependencies_v1", "test_files": sorted(files if fallback else keep),
            "full_test_fallback": fallback,
            "reason": "Dynamic or unparseable test dependencies retain the full test tree." if fallback else
                      "Selected tests and their local imports are bound; shared engine, tools and fixture metadata remain conservative."}


def changed_files(before, after):
    return [{"path": name, "change": "added" if name not in before else "removed" if name not in after else "changed"}
            for name in sorted(set(before) | set(after)) if before.get(name) != after.get(name)]


def inputs(root, pack, *, lanes=None):
    """Closed code/reference-metadata copy; never copy source deliveries or other products."""
    root = Path(root).resolve()
    paths = set()
    for folder, suffixes in (
        ("platform/engine", {".py", ".yaml", ".yml", ".sql"}),
        ("platform/engine-r", {".R", ".r", ".yaml", ".yml", ".sql"}),
        ("platform/tools", {".py"}), ("platform/tests", {".py", ".R", ".r"}),
        ("platform/tests/conformance", {".yaml", ".yml"}),
        ("platform/tests/fixtures", {".yaml", ".yml", ".json", ".csv", ".tsv"}),
        ("products/metadata", {".yaml", ".yml"}),
        ("products/_reporting", {".yaml", ".yml"}),
    ):
        base = root / folder
        if base.exists():
            for path in base.rglob("*"):
                if path.is_file() and path.suffix in suffixes and "__pycache__" not in path.parts:
                    paths.add(_safe(root, path))
    for name in ("platform/capabilities.yaml", "platform/CAPABILITIES.md", "fixtures/registry.yaml", "products/registry.yaml"):
        if (root / name).is_file():
            paths.add(_safe(root, root / name))
    # The repository's reference fixture configurations feed the fixed tests.
    # Only config/variables/codelists are copied; workbooks, extracted rows,
    # handoffs, patient delivery files and other working products are excluded.
    packs = [root / pack]
    packs += list((root / "fixtures").glob("*/*/*")) if (root / "fixtures").exists() else []
    for product in packs:
        for name in ("config", "variables", "codelists"):
            base = product / name
            if base.is_dir():
                for path in base.rglob("*"):
                    if path.is_file() and path.suffix in {".yaml", ".yml", ".csv", ".tsv"}:
                        paths.add(_safe(root, path))
    if lanes is not None:
        keep = set(test_dependencies(root, lanes)["test_files"])
        paths = {path for path in paths if not (path.suffix == ".py" and path.is_relative_to(root / "platform/tests"))
                 or path.relative_to(root).as_posix() in keep}
        for lane in lanes:
            relative = (lane.get("product_cases") or {}).get("path")
            if relative:
                if not re.fullmatch(re.escape(pack) + r"/handoff/IMPLEMENTATION_REVIEWS/[a-f0-9]{24}/synthetic_cases\.json", relative):
                    raise ValueError("Runtime cases must belong to the selected product review.")
                paths.add(_safe(root, root / relative))
    total, answer = 0, {}
    for path in sorted(paths):
        if path.stat().st_size > MAX_REPORT:
            raise ValueError("A runtime code or reference metadata file exceeds the review size bound.")
        raw = path.read_bytes()
        total += len(raw)
        if total > MAX_BYTES:
            raise ValueError("The runtime source snapshot exceeds its bounded local copy size.")
        answer[path.relative_to(root).as_posix()] = sha(raw)
    return answer


def _rscript():
    """Discover an existing installation, without installing or editing PATH/registry."""
    tools_dir = str(Path(__file__).resolve().parents[2] / "platform/tools")
    if tools_dir not in sys.path:
        sys.path.insert(0, tools_dir)
    from runtime_discovery import find_rscript
    return find_rscript()


def _r_library(rscript):
    local = Path(os.environ.get("LOCALAPPDATA") or Path.home() / "AppData/Local")
    match = re.search(r"R-(\d+[.]\d+)", str(rscript or ""))
    return local / "RwdPortal/R/library" / (match.group(1) if match else "current")


def _winutils():
    """Effective native helper used by sparklyr's documented Windows bootstrap."""
    if os.name != "nt":
        return None
    spec = importlib.util.find_spec("pyspark")
    if spec and spec.origin:
        cached = Path(spec.origin).parent / "tmp/hadoop/bin/winutils.exe"
        if cached.is_file():
            return cached
    local = Path(os.environ.get("LOCALAPPDATA") or Path.home() / "AppData/Local")
    installed = local / "RwdPortal/hadoop/hadoop-3.0.0/x64/winutils.exe"
    return installed if installed.is_file() else None


def _r_metadata(rscript):
    empty = {"r_version": None, "r_packages": {name: None for name in ("sparklyr", "dplyr", "dbplyr", "DBI")}}
    if not rscript:
        return empty
    # Availability is installed-version metadata, not a test run. Loading all of
    # sparklyr's namespaces on every freshness read blocked the UI for seconds;
    # packageVersion reads DESCRIPTION and actual suite execution checks loading.
    expression = ('cat("R_VERSION=",as.character(getRversion()),"\\n",sep=""); '
        'for(p in c("sparklyr","dplyr","dbplyr","DBI")) cat("R_PACKAGE=",p,"=",'
        'tryCatch(as.character(utils::packageVersion(p)),error=function(e) "MISSING"),"\\n",sep="")')
    with tempfile.TemporaryDirectory(prefix="rwd-r-check-") as directory:
        env = _env(Path(directory), Path(directory), {"rscript": rscript})
        result = portal_runtime.run([rscript, "--vanilla", "-e", expression], cwd=directory, timeout_s=20, extra_env=env)
    if result.returncode:
        return empty
    for line in result.stdout.splitlines():
        if re.fullmatch(r"R_VERSION=\d+[.]\d+[.]\d+", line):
            empty["r_version"] = line.split("=", 1)[1]
        elif re.fullmatch(r"R_PACKAGE=(sparklyr|dplyr|dbplyr|DBI)=(?:[0-9.\-]+|MISSING)", line):
            _, name, version = line.split("=")
            empty["r_packages"][name] = None if version == "MISSING" else version
    return empty


def _java_metadata(java):
    """Observe the selected JVM's full runtime version; never infer it from a folder name."""
    empty = {"java_version": None}
    if not java:
        return empty
    with tempfile.TemporaryDirectory(prefix="rwd-java-check-") as directory:
        env = _env(Path(directory), Path(directory), {"java": java})
        result = portal_runtime.run([java, "-XshowSettings:properties", "-version"],
            cwd=directory, timeout_s=10, extra_env=env)
    if result.returncode:
        return empty
    versions = []
    for line in ((result.stdout or "") + "\n" + (result.stderr or "")).splitlines():
        match = re.fullmatch(r"\s*java[.]runtime[.]version\s*=\s*(\d+(?:[._]\d+)*(?:[-+][A-Za-z0-9._+-]+)?)\s*", line)
        if match and len(match.group(1)) <= 128:
            versions.append(match.group(1))
    if len(set(versions)) == 1:
        empty["java_version"] = versions[0]
    return empty


def prerequisites():
    # Match the worker bootstrap: a valid JAVA_HOME wins over a different Java on PATH.
    tools_dir = str(Path(__file__).resolve().parents[2] / "platform/tools")
    if tools_dir not in sys.path:
        sys.path.insert(0, tools_dir)
    import java_home
    discovered = java_home.discover()
    candidate = Path(discovered) / "bin" / ("java.exe" if os.name == "nt" else "java") if discovered else None
    java = str(candidate) if candidate and candidate.is_file() else shutil.which("java")
    # Resolve PATH symlinks before deriving the worker's JAVA_HOME from the executable.
    java = str(Path(java).resolve()) if java else None
    versions = {}
    for name in ("pytest", "pyspark"):
        try:
            versions[name] = importlib.metadata.version(name)
        except importlib.metadata.PackageNotFoundError:
            versions[name] = None
    binaries = {"python_executable": sys.executable, "java": java, "rscript": _rscript()}
    r = _r_metadata(binaries["rscript"])
    native = _winutils()
    actions = []
    if not java or not versions["pyspark"]:
        actions.append("Local Spark needs PySpark and Java 17 or 21. The existing user-folder JDK discovery is used; no system PATH changes are required.")
    if not r["r_version"] or not all(r["r_packages"].values()):
        actions.append("Python/R conformance needs an existing R installation plus sparklyr, dplyr, dbplyr and DBI in the user-local RwdPortal/R/library/<major.minor> library. Missing dependencies remain unproven.")
    if os.name == "nt" and not native:
        actions.append("Windows sparklyr also needs its documented native winutils helper. Install the real helper in the user-local Spark runtime before running R conformance; no system PATH or registry changes are needed.")
    result = {"python": sys.version.split()[0], **versions, **binaries, **r, **_java_metadata(java), "actions": actions,
            "winutils_sha256": sha(native.read_bytes()) if native else None,
            **{name + "_sha256": sha(Path(path).read_bytes()) if path and Path(path).is_file() else None for name, path in binaries.items()}}
    import portal_environment
    result["environment_profile"] = portal_environment.report(Path(__file__).resolve().parents[2], runtime=result)
    return result


def suites(ids, declared):
    if not isinstance(ids, list) or not ids or len(ids) > len(SUITES) or len(set(ids)) != len(ids) or any(i not in SUITES for i in ids):
        raise ValueError("Choose one or more of the displayed fixed runtime checks.")
    if not declared or any(not re.fullmatch(r"platform/tests/test_[A-Za-z0-9_]+\.py::test_[A-Za-z0-9_]+", ref) for ref in declared):
        raise ValueError("Use actual reviewed top-level test functions in platform/tests/test_name.py. Arbitrary commands and parametrized selectors cannot be entered here.")
    chosen = ["declared", *(["selected_product"] if "selected_product" in ids else []),
              *[key for key in ids if key not in {"declared", "selected_product"}]]
    return [{"id": key, **SUITES[key], "timeout_seconds": SUITE_SECONDS.get(key, PER_SUITE_SECONDS),
             "selectors": list(declared) if key == "declared" else list(SUITES[key]["selectors"])} for key in chosen]


def _env(home, copied, runtime):
    # Do not inherit API keys, cloud connections, pytest plugins, Spark submission
    # arguments, or a real user's home into reviewed local test execution.
    keep = {"PATH", "SYSTEMROOT", "WINDIR", "COMSPEC", "PATHEXT", "SYSTEMDRIVE", "PROCESSOR_ARCHITECTURE", "PROCESSOR_ARCHITEW6432"}
    env = {key: value if key.upper() in keep else "" for key, value in os.environ.items() if key != "PYTHONUTF8"}
    env.update({"HOME": str(home), "USERPROFILE": str(home), "APPDATA": str(home), "LOCALAPPDATA": str(home),
        "TMP": str(home), "TEMP": str(home), "TMPDIR": str(home), "PYTHONDONTWRITEBYTECODE": "1",
        "PYTEST_DISABLE_PLUGIN_AUTOLOAD": "1", "PYTEST_ADDOPTS": "", "PYTHONPATH": str(copied / "platform"),
        "PYSPARK_PYTHON": sys.executable, "PYSPARK_DRIVER_PYTHON": sys.executable, "SPARK_LOCAL_IP": "127.0.0.1",
        "RWDP_STATE_DIR": str(home / "state"), "RWDP_CONFORMANCE_REQUIRE_R": "0"})
    env.update({"LANG": "en_US.UTF-8", "LC_ALL": "C"})
    if runtime.get("java"):
        env["JAVA_HOME"] = str(Path(runtime["java"]).parent.parent)
        env["PATH"] = str(Path(runtime["java"]).parent) + os.pathsep + env.get("PATH", "")
    if runtime.get("rscript"):
        env["PATH"] = str(Path(runtime["rscript"]).parent) + os.pathsep + env.get("PATH", "")
        library = _r_library(runtime["rscript"])
        if library.is_dir():
            env["R_LIBS_USER"] = str(library)
            env["R_STAGE_LIB"] = str(library)
        local_native = _r_library(runtime["rscript"]).parents[2] / "hadoop/hadoop-3.0.0"
        if (local_native / "x64/winutils.exe").is_file():
            env["RSTUDIO_WINUTILS"] = str(local_native)
    return env


def _partial_outcomes(path, suite):
    if path is None or not path.is_file() or path.stat().st_size > MAX_REPORT:
        return None
    try:
        raw = path.read_bytes(); doc = json.loads(raw)
        if not isinstance(doc, dict) or set(doc) != {"version", "collected", "phases"} or type(doc["version"]) is not int or doc["version"] != 1:
            return None
        collected, phases = doc["collected"], doc["phases"]
        if not isinstance(collected, dict) or not 1 <= len(collected) <= 5000 or not isinstance(phases, dict) or set(phases) - set(collected):
            return None
        tests = []
        for key, item in collected.items():
            if (not re.fullmatch(r"[a-f0-9]{64}", key) or not isinstance(item, dict) or set(item) != {"path", "function", "name"}
                    or not isinstance(item["path"], str) or not re.fullmatch(r"platform/tests/(?:[A-Za-z0-9_-]+/)*test_[A-Za-z0-9_]+\.py", item["path"])
                    or not isinstance(item["function"], str) or not re.fullmatch(r"test_[A-Za-z0-9_]+", item["function"])
                    or not isinstance(item["name"], str) or not re.fullmatch(r"[A-Za-z0-9_.-]{1,300}", item["name"])):
                return None
            if not any(item["path"] == ref.split("::")[0] and ("::" not in ref or item["function"] == ref.split("::")[1]) for ref in suite["selectors"]):
                return None
            observed = phases.get(key, {})
            if not isinstance(observed, dict) or set(observed) - {"setup", "call", "teardown"}:
                return None
            for phase in observed.values():
                if (not isinstance(phase, dict) or not {"outcome", "seconds"} <= set(phase) or set(phase) - {"outcome", "seconds", "skip_code"} or phase["outcome"] not in {"passed", "failed", "skipped"}
                        or phase.get("skip_code") not in {None, *SKIP_CODES} or (phase.get("skip_code") and phase["outcome"] != "skipped")
                        or type(phase["seconds"]) not in {int, float} or not 0 <= phase["seconds"] < float("inf")):
                    return None
            if "teardown" not in observed or "setup" not in observed:
                continue  # A passed call followed by an unfinished teardown is not completed.
            if any(observed.get(phase, {}).get("outcome") == "failed" for phase in ("setup", "teardown")):
                status = "error"
            elif observed.get("call", {}).get("outcome") == "failed":
                status = "failed"
            elif any(phase["outcome"] == "skipped" for phase in observed.values()):
                status = "skipped"
            elif observed.get("call", {}).get("outcome") == "passed":
                status = "passed"
            else:
                continue
            entry = {"name": item["name"], "class": "", "source_file": item["path"], "outcome": status,
                "seconds": sum(phase["seconds"] for phase in observed.values())}
            if status == "skipped":
                for phase in observed.values():
                    if phase.get("skip_code"):
                        entry["skip_code"] = phase["skip_code"]
            tests.append(entry)
        return {"tests": tests, "report_sha256": sha(raw), "report_kind": "partial_pytest_journal",
            "completed_cases_only": True, "collection_sha256": sha(json.dumps(collected, sort_keys=True).encode()),
            "counts": {name: sum(test["outcome"] == name for test in tests) for name in ("passed", "failed", "error", "skipped")}}
    except (OSError, ValueError, TypeError, KeyError):
        return None


def parse_report(path, result, suite, elapsed, runtime, partial_path=None):
    conformance = suite["id"] == "conformance" or any(selector.split("::")[0] == "platform/tests/test_stage_conformance.py" for selector in suite["selectors"])
    local_pipeline = any(selector.split("::")[0] in {"platform/tests/test_synthetic_spark_uat.py", "platform/tests/test_selected_product_outputs.py"} for selector in suite["selectors"])
    output = {"id": suite["id"], "title": suite["title"], "selectors": suite["selectors"],
              "status": "error", "tests": [], "elapsed_seconds": round(elapsed, 3), "exit_code": result.returncode,
              "report_sha256": None, "output_sha256": sha((result.stdout + result.stderr).encode()), "reason": "No complete pytest report was produced."}
    if local_pipeline:
        # An installed test file or declared intent is not proof that the guarded
        # path executed. This fixed marker is emitted by the real engine only
        # after the local-master check. It never turns incomplete assertions into
        # a pass or claims distributed checkpoint recovery.
        observed = bool(re.search(r"(?m)^\s*LOCAL-COHORT-EXECUTION local_cohort_checkpoints\s*$", result.stdout))
        output.update(execution_mode="local_cohort_checkpoints" if observed else "unproven",
                      expected_execution_mode="local_cohort_checkpoints", cluster_recovery_tested=False)
    def incomplete():
        if conformance:
            output["r_conformance"] = "unproven" if runtime.get("rscript") else "skipped"
        partial = _partial_outcomes(partial_path, suite)
        if partial:
            output.update(partial)
            output["reason"] += " Only completed cases from the partial pytest journal are shown."
        return output
    kind = portal_runtime.failure_kind(result)
    if kind:
        output.update(status={"timeout": "timeout", "cancelled": "cancelled"}.get(kind, "unavailable"),
            reason={"timeout": "The bounded test process timed out.", "cancelled": "The reviewer cancelled this runtime check; no pass is claimed."}.get(kind, "The local test process could not start."))
        return incomplete()
    if not path.is_file() or path.stat().st_size > MAX_REPORT:
        return incomplete()
    raw = path.read_bytes()
    if b"<!DOCTYPE" in raw or b"<!ENTITY" in raw:
        return incomplete()
    try:
        tree = ET.fromstring(raw)
        cases = tree.findall(".//testcase")
        if not cases or len(cases) > 5000:
            return incomplete()
        for case in cases:
            status = "failed" if case.find("failure") is not None else "error" if case.find("error") is not None else "skipped" if case.find("skipped") is not None else "passed"
            duration = float(case.get("time", "0"))
            if duration < 0 or duration != duration or duration == float("inf"):
                raise ValueError("invalid duration")
            name, classname = case.get("name", ""), case.get("classname", "")
            # The fixed selectors are unparameterized. Never publish temporary
            # checkout paths or arbitrary data from generated pytest node IDs.
            if not re.fullmatch(r"[A-Za-z0-9_.-]{1,300}", name) or not re.fullmatch(r"[A-Za-z0-9_.-]{0,300}", classname):
                name, classname = "nonportable_test_identifier", ""
            entry = {"name": name, "class": classname, "outcome": status, "seconds": duration}
            if status == "skipped":
                message = str(case.find("skipped").get("message", ""))[:4000]
                if name == "test_fued_and_dthdt_cardinality_follows_the_ruling_not_the_accident" and "FUED-DEFINITION / DTHFUFL-RULE" in message:
                    entry["skip_code"] = "FUED_CARDINALITY"
                elif name == "test_selected_product_expected_outputs" and "SELECTED-PRODUCT-CASES-MISSING" in message:
                    entry["skip_code"] = "SELECTED_CASES_MISSING"
            output["tests"].append(entry)
    except (ET.ParseError, ValueError, TypeError):
        output["tests"] = []
        return incomplete()
    counts = {name: sum(t["outcome"] == name for t in output["tests"]) for name in ("passed", "failed", "error", "skipped")}
    status = "failed" if counts["failed"] or counts["error"] else "partial" if counts["skipped"] and counts["passed"] else "skipped" if counts["skipped"] else "passed"
    if result.returncode and status not in {"failed", "error"}:
        status = "error"
    output.update(status=status, counts=counts, report_sha256=sha(raw), reason="Exact selected pytest assertion outcomes; skipped cases remain unproven.")
    if local_pipeline:
        if output["execution_mode"] == "unproven" and status == "passed":
            output["status"] = "partial"
        output["reason"] += " The selected local cohort execution mode is reported separately; cluster recovery is not tested."
    if conformance:
        r_skipped = not runtime.get("rscript") or bool(re.search(r"(?m)^\s*(?:R-CONFORMANCE SKIP|R-RUNNER SKIP)\b", result.stdout))
        compared = set(re.findall(r"(?m)^\s*R-CONFORMANCE PASS ([a-z0-9_]+)\s*$", result.stdout))
        required = {test["name"].removeprefix("test_conformance_") for test in output["tests"] if test["name"].startswith("test_conformance_")}
        r_passed = not r_skipped and status == "passed" and bool(required) and required <= compared
        output["r_conformance"] = "skipped" if r_skipped else "passed" if r_passed else "unproven"
        if not r_passed and status == "passed":
            output["status"] = "partial"
        output["reason"] = "Python expected-output assertions and R parity are reported separately; missing R is not conformance success."
    if suite["id"] == "selected_product":
        cases = suite.get("product_cases") or {}
        observed = re.findall(r"(?m)^SELECTED-PRODUCT-EXPECTED PASS ([a-f0-9]{64}) ([1-9][0-9]?)\s*$", result.stdout)
        case_outcomes = re.findall(r"(?m)^SELECTED-PRODUCT-CASE (PASS|FAIL) ([a-z][a-z0-9_]{0,47})\s*$", result.stdout)
        valid_cases = (len(case_outcomes) == len(cases.get("ids", [])) and
                       sorted(name for _, name in case_outcomes) == sorted(cases.get("ids", [])))
        proven = (output["status"] == "passed" and observed == [(cases.get("digest"), str(cases.get("count")))] and
                  valid_cases and all(state == "PASS" for state, _ in case_outcomes))
        output["expected_cases"] = [{"id": name, "outcome": "passed" if state == "PASS" else "failed"} for state, name in case_outcomes] if valid_cases else []
        output["selected_product_build"] = proven
        output["product_cases_digest"] = cases.get("digest")
        output["expected_case_count"] = cases.get("count", 0)
        if output["status"] == "passed" and not proven:
            output["status"] = "partial"
            output["reason"] = "The selected product expectation marker was not verified; no product-specific pass is claimed."
    return output


def execute(root, pack, snapshot, lanes, runtime):
    import heavy_runtime_queue
    try:
        with heavy_runtime_queue.lease():
            return _execute(root, pack, snapshot, lanes, runtime)
    except heavy_runtime_queue.Cancelled:
        return {"lanes": [{"id": lane["id"], "title": lane["title"], "selectors": lane["selectors"],
            "status": "cancelled", "tests": [], "elapsed_seconds": 0, "exit_code": None,
            "report_sha256": None, "output_sha256": None, "reason": "Cancelled while waiting for local runtime capacity."} for lane in lanes],
            "copy_unchanged": True, "copied_after": snapshot, "elapsed_seconds": 0}


def _execute(root, pack, snapshot, lanes, runtime):
    """Run real pytest against exact copied installed code, never candidate files."""
    root = Path(root)
    results = []
    start = time.monotonic()
    with tempfile.TemporaryDirectory(prefix="rwd-implementation-") as temporary:
        work = Path(temporary)
        copied, home = work / "checkout", work / "home"
        copied.mkdir(); home.mkdir()
        for name, digest in snapshot.items():
            original = _safe(root, root / name)
            raw = original.read_bytes()
            if sha(raw) != digest:
                raise ValueError("Installed files changed while preparing the isolated runtime copy. Review them again.")
            destination = copied / name
            destination.parent.mkdir(parents=True, exist_ok=True)
            destination.write_bytes(raw)
        # Legacy proposals retain their original broad fingerprint.
        scoped = any(lane.get("dependency_mode") == "suite_dependencies_v1" for lane in lanes)
        copied_before = inputs(copied, pack, lanes=lanes if scoped else None)
        if copied_before != snapshot:
            raise ValueError("The isolated runtime copy does not match the reviewed snapshot.")
        env = _env(home, copied, runtime)
        (copied / "rwd_runtime_reports.py").write_text(PARTIAL_PLUGIN, encoding="utf-8")
        for number, suite in enumerate(lanes):
            if portal_runtime.job_cancelled():
                results.append({"id": suite["id"], "title": suite["title"], "selectors": suite["selectors"], "status": "cancelled",
                    "tests": [], "elapsed_seconds": 0, "exit_code": None, "report_sha256": None, "output_sha256": None,
                    "reason": "The reviewer cancelled this request before this lane ran."})
                continue
            if suite["id"] == "selected_product" and not suite.get("product_cases"):
                results.append({"id": suite["id"], "title": suite["title"], "selectors": suite["selectors"], "status": "unavailable",
                    "tests": [], "elapsed_seconds": 0, "exit_code": None, "report_sha256": None, "output_sha256": None,
                    "selected_product_build": False, "skip_code": "SELECTED_CASES_MISSING",
                    "reason": SKIP_CODES["SELECTED_CASES_MISSING"]["message"]})
                continue
            remaining = TOTAL_SECONDS - (time.monotonic() - start)
            missing = not runtime.get("pytest") or (suite["spark"] and (not runtime.get("pyspark") or not runtime.get("java")))
            if missing or remaining < 1:
                results.append({"id": suite["id"], "title": suite["title"], "selectors": suite["selectors"], "status": "unavailable" if missing else "timeout",
                    "tests": [], "elapsed_seconds": 0, "exit_code": None, "report_sha256": None, "output_sha256": None,
                    "reason": "Install pytest and, for Spark checks, PySpark with Java 17 or 21 in this local environment." if missing else "The total runtime budget was exhausted; this lane did not run."})
                continue
            report = work / (str(number) + ".xml")
            partial = work / (str(number) + ".partial.json")
            env["RWDP_RUNTIME_JOURNAL"] = str(partial)
            env["RWDP_SYNTHETIC_PACK"] = pack if suite["id"] == "selected_product" else ""
            env["RWDP_SYNTHETIC_CASES"] = (suite.get("product_cases") or {}).get("path", "")
            # portal_runtime overlays its environment. Remove the deliberately
            # blanked variables before imports: SPARK_HOME='' is not absence.
            argv = [sys.executable, "-c", BOOTSTRAP, "-q", "-s", "-p", "rwd_runtime_reports", "-p", "no:cacheprovider", "-c", os.devnull,
                    "--confcutdir=" + str(copied / "platform/tests"), "--junitxml=" + str(report), *suite["selectors"]]
            begun = time.monotonic()
            portal_runtime.job_progress("Running " + suite["title"])
            result = portal_runtime.run(argv, cwd=str(copied), timeout_s=min(SUITE_SECONDS.get(suite["id"], PER_SUITE_SECONDS), max(1, int(remaining))), extra_env=env)
            results.append(parse_report(report, result, suite, time.monotonic() - begun, runtime, partial_path=partial))
            portal_runtime.job_progress(suite["title"] + ": " + results[-1]["status"])
        copied_after = inputs(copied, pack, lanes=lanes if scoped else None)
    return {"lanes": results, "copy_unchanged": copied_before == copied_after, "copied_after": copied_after,
            "elapsed_seconds": round(time.monotonic() - start, 3)}
