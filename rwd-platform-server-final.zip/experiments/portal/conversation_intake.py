"""One private study brief behind chat, using the existing typed intake store.

This adapter never calls a model. The workflow guide supplies proposals from its
one ordinary response; exact user wording and explicit choices are draft input,
while inferred wording stays separate until the user accepts it.
"""
from __future__ import annotations

import copy
import hashlib
import json
import re
import tempfile
from pathlib import Path

import intake
import scientific_definition_ai as ai
import session_drafts
import design_workspace as design

DOMAIN = "product_brief"
MAX_VALUE = 1800
MAX_UPDATES = 6
MAX_SNAPSHOT_BYTES = 80_000
UNKNOWN = frozenset({"not sure", "unsure", "unknown", "i don't know", "i do not know", "undecided"})


def _hash(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, ensure_ascii=True, allow_nan=False).encode()).hexdigest()


def slots():
    return {slot["id"]: slot for slot in intake.domains()[DOMAIN]["slots"]}


def _text(value, limit=MAX_VALUE, *, empty=False):
    if not isinstance(value, str) or len(value) > limit or (not empty and not value.strip()) or "\0" in value:
        raise ValueError("Keep study brief entries within the supported text size.")
    ai._ingress(value)
    return value.strip()


def _scope(root, pack, actor_id, allowed_packs, scope_id=""):
    scope, directory = session_drafts._setup_scope(root, actor_id, allowed_packs)
    root = Path(root).resolve(strict=True)
    name = ""
    if pack:
        _, _, name = design._pack_path(root, pack, allowed_packs)
    # Access-list changes do not erase one's own descriptive draft. The current
    # pack is checked on every access; pending evidence-bound choices are reset.
    if not isinstance(scope_id, str) or len(scope_id) > 200 or "\0" in scope_id:
        raise ValueError("Choose a supported study identifier for this brief.")
    scope = {"checkout": scope["checkout"], "owner": scope["owner"], "pack": name, "study": scope_id}
    directory = directory.parent.parent.parent / "study-briefs" / scope["checkout"][:12] / scope["owner"][:12] / _hash([name, scope_id])[:12]
    if directory.resolve() != directory:
        raise ValueError("The private brief location redirects to another folder.")
    design._check_storage_paths([directory / "product_brief_20000101-000000-000000.yaml"])
    return scope, directory


def _binding(connection, source, allowed_packs):
    return {"connection": _hash(connection), "source": _hash(source), "access": _hash(sorted(set(allowed_packs)))}


def new(root, pack, actor_id, *, allowed_packs, connection=None, source=None, scope_id=""):
    scope, _ = _scope(root, pack, actor_id, allowed_packs, scope_id)
    return {"schema": 1, "scope": scope,
            "state": intake.new_state(DOMAIN, scope["pack"], actor_id),
            "binding": _binding(connection, source, allowed_packs),
            "pending_question": None, "proposed_updates": [], "unknown_slots": [],
            "question_epoch": 0, "revision": None, "notice": ""}


def validate_reply(updates=None, questions=None, context=None):
    """Validate optional additions to the workflow guide's existing JSON reply."""
    updates = [] if updates is None else updates
    questions = [] if questions is None else questions
    known = slots()
    if not isinstance(updates, list) or len(updates) > MAX_UPDATES:
        raise ValueError("The assistant returned too many study brief changes.")
    seen = set()
    clean = []
    for update in updates:
        if (not isinstance(update, dict) or set(update) != {"slot", "value", "quote"}
                or update.get("slot") not in known or update["slot"] in seen):
            raise ValueError("The assistant returned an unsupported or repeated study brief field.")
        seen.add(update["slot"])
        clean.append({"slot": update["slot"], "value": _text(update["value"]),
                      "quote": _text(update["quote"], 600, empty=True)})
    ai._questions(questions, option_id_limit=128)
    if len(questions) > 1 or any(question["id"] not in known for question in questions):
        raise ValueError("Ask one study brief question using its existing field identifier.")
    for question in questions:
        ai._ingress(json.dumps(question, ensure_ascii=False))
        labels = {option["label"].strip().casefold() for option in question["options"]}
        identifiers = [option["id"].casefold() for option in question["options"]]
        if len(identifiers) != len(set(identifiers)):
            raise ValueError("Question choice identifiers must be distinct regardless of letter case.")
        if labels & UNKNOWN:
            raise ValueError("The interface supplies Not sure separately from the proposed choices.")
    return {"brief_updates": clean, "questions": copy.deepcopy(questions)}


def _question(question, binding, source_cut=None, epoch=0):
    result = copy.deepcopy(question)
    result["token"] = _hash({"question": question, "binding": binding, "draft_source": source_cut, "epoch": epoch})
    return result


def _template_question(brief):
    for sid, slot in slots().items():
        if slot.get("required", True) and not intake._filled(brief["state"]["request"].get(sid)):
            options = [{"id": chr(97 + i), "label": str(option.get("label") if isinstance(option, dict) else option),
                        "explanation": str(option.get("note") or "") if isinstance(option, dict) else ""}
                       for i, option in enumerate(slot.get("options", [])[:4])]
            question = {"id": sid, "prompt": slot["ask"], "options": options if len(options) >= 2 else [], "allow_text": True}
            return _question(question, brief["binding"], brief["state"]["request"].get("source_cut"), brief["question_epoch"])
    return None


def current_question(brief):
    return copy.deepcopy(brief.get("pending_question") or _template_question(brief))


def _prefill_updates(prefill, public_form, user_text):
    """Project the existing, validated form adapter into known brief slots."""
    if prefill is None:
        return []
    import form_assistance as forms
    import conversation_examples as examples
    checked = forms.check_response(prefill, public_form)
    fields = {field["id"]: field for field in public_form["fields"]}
    known = slots()
    projected = {}
    for row in checked["fields"]:
        field = fields[row["id"]]
        sid = examples.LABEL_SLOTS.get(examples._label(field["label"]))
        if sid not in known:
            continue  # Row-level definitions, identities and outputs are not study intent.
        value = _text(row["value"])
        if sid in projected and projected[sid]["value"] != value:
            raise ValueError("The proposed form contains conflicting wording for the same study brief detail.")
        projected[sid] = {"slot": sid, "value": value, "quote": value if value in user_text else ""}
    return list(projected.values())


def apply_reply(brief, parsed, *, user_text, public_form=None):
    """Keep exact user wording; inferred interpretations are separate proposals."""
    _text(user_text, 6000)
    clean = validate_reply(parsed.get("brief_updates"), parsed.get("questions"))
    updates = {item["slot"]: item for item in clean["brief_updates"]}
    for update in _prefill_updates(parsed.get("prefill"), public_form, user_text):
        previous = updates.get(update["slot"])
        if previous and previous["value"] != update["value"]:
            raise ValueError("The proposed form and study brief disagree about the same detail. Request consistent wording before applying them.")
        if previous is None or update["quote"]:
            updates[update["slot"]] = update
    clean["brief_updates"] = list(updates.values())
    new_brief = copy.deepcopy(brief)
    new_brief["state"]["turns"] = int(new_brief["state"].get("turns") or 0) + 1
    proposed = {update["slot"]: update for update in new_brief["proposed_updates"]}
    for update in clean["brief_updates"]:
        sid, value, quote = update["slot"], update["value"], update["quote"]
        literal = bool(quote) and quote in user_text and value == quote
        if literal and value.casefold() not in UNKNOWN:
            new_brief["state"]["request"][sid] = value
            proposed.pop(sid, None)
            new_brief["unknown_slots"] = [item for item in new_brief["unknown_slots"] if item != sid]
        elif literal:
            if sid not in new_brief["unknown_slots"]:
                new_brief["unknown_slots"].append(sid)
        elif value != new_brief["state"]["request"].get(sid):
            proposed[sid] = {**update, "quote": quote if quote and quote in user_text else "",
                             "before": new_brief["state"]["request"].get(sid)}
    new_brief["proposed_updates"] = list(proposed.values())
    if new_brief["state"]["request"].get("source_cut") != brief["state"]["request"].get("source_cut"):
        current_slots = {item["slot"] for item in clean["brief_updates"]}
        new_brief.update(pending_question=None,
            proposed_updates=[item for item in new_brief["proposed_updates"] if item["slot"] in current_slots],
            notice="Your source description changed. Existing draft definitions are retained for review; previous proposed choices need to be reconsidered for this source.")
    # A completed slot may need a refinement; the pending question remains a
    # draft choice and never overwrites the existing value on its own.
    if clean["questions"]:
        new_brief["question_epoch"] += 1
        new_brief["pending_question"] = _question(clean["questions"][0], new_brief["binding"], new_brief["state"]["request"].get("source_cut"), new_brief["question_epoch"])
    elif new_brief.get("pending_question") and new_brief["pending_question"]["id"] in {
            item["slot"] for item in clean["brief_updates"] if item["value"] == item["quote"]
            and item["quote"] in user_text and item["value"].casefold() not in UNKNOWN}:
        new_brief["pending_question"] = None
    return new_brief


def resolve_reply(brief, user_text, *, question_token=None):
    """Resolve a short response only against this exact displayed question.

    Returns (brief, expanded message, matched). Free prose still goes through the
    guide, which proposes slot updates. A UI-bound typed answer is deterministic.
    """
    text = _text(user_text, 6000)
    question = current_question(brief)
    if question_token is not None and question_token != (question or {}).get("token"):
        raise ValueError("This question changed. Review the current choices before answering.")
    clearing = intake._CLEAR_RE.fullmatch(text)
    if clearing and clearing[1].lower() in slots():
        sid = clearing[1].lower()
        result = edit(brief, {sid: ""})
        result["state"]["cleared"] = sorted(set(result["state"].get("cleared") or []) | {sid})
        return result, f"I cleared {sid} from my private study brief. Keep that field empty until I provide replacement wording.", True
    if not brief.get("pending_question") and question_token is None:
        if re.fullmatch(r"(?:[1-4][.)]?|(?:1\s*[.)]?\s*)?[A-Da-d][.)]?)", text):
            raise ValueError("There is no current displayed brief question for this short answer. Review a fresh question or describe your intended answer in words.")
        return copy.deepcopy(brief), text, False
    if not question:
        return copy.deepcopy(brief), text, False
    choices = {option["id"].casefold(): option for option in question["options"]}
    answer = None
    # Letters/numbers identify the displayed positions, independently of the
    # model's semantic IDs. Explicit id:... remains available for an ID that
    # collides with a position letter (e.g. first option id=b).
    position = re.fullmatch(r"(?:1\s*[.)]?\s*)?([A-Za-z])[.)]?", text)
    number = re.fullmatch(r"([1-9])[.)]?", text)
    explicit_id = re.fullmatch(r"id\s*:\s*([A-Za-z][A-Za-z0-9_-]{0,127})", text, re.I)
    if position or number:
        index = ord(position[1].lower()) - ord("a") if position else int(number[1]) - 1
        if index >= len(question["options"]):
            if question_token is not None:
                raise ValueError("That choice is not shown in the current question. Select a displayed option or describe your alternative in words.")
            return copy.deepcopy(brief), text, False
        answer = question["options"][index]["label"]
    elif explicit_id and explicit_id[1].casefold() in choices:
        answer = choices[explicit_id[1].casefold()]["label"]
    elif text.casefold() in choices:
        answer = choices[text.casefold()]["label"]
    elif text.casefold() in UNKNOWN:
        answer = "Not sure"
    elif question_token is not None:
        # Only a submitted form names the exact slot for a typed alternative.
        answer = text
    else:
        for option in question["options"]:
            if text.casefold() == option["label"].casefold():
                answer = option["label"]
                break
    if answer is None:
        return copy.deepcopy(brief), text, False
    result = copy.deepcopy(brief)
    sid = question["id"]
    if answer.casefold() in UNKNOWN:
        if sid not in result["unknown_slots"]:
            result["unknown_slots"].append(sid)
        result["pending_question"] = question
        expanded = f"For the study brief question {question['prompt']} My answer: Not sure. Keep this unresolved and help me understand the options."
    else:
        result["state"]["request"][sid] = _text(answer)
        result["unknown_slots"] = [item for item in result["unknown_slots"] if item != sid]
        result["proposed_updates"] = [item for item in result["proposed_updates"] if item["slot"] != sid]
        result["pending_question"] = None
        if sid == "source_cut" and answer != brief["state"]["request"].get(sid):
            result["proposed_updates"] = []
            result["notice"] = "Your source description changed. Existing draft definitions are retained for review; previous proposed choices need to be reconsidered for this source."
        expanded = f"For the study brief question {question['prompt']} My answer: {answer}"
    return result, expanded, True


def edit(brief, values):
    if not isinstance(values, dict) or not set(values) <= set(slots()):
        raise ValueError("Choose existing study brief fields to edit.")
    result = copy.deepcopy(brief)
    for sid, value in values.items():
        value = _text(value, empty=True)
        if value.casefold() in UNKNOWN:
            if sid not in result["unknown_slots"]:
                result["unknown_slots"].append(sid)
        else:
            result["state"]["request"][sid] = value or None
    result["proposed_updates"] = [item for item in result["proposed_updates"] if item["slot"] not in values]
    result["unknown_slots"] = [sid for sid in result["unknown_slots"] if sid not in values or values[sid].strip().casefold() in UNKNOWN]
    if result.get("pending_question") and result["pending_question"]["id"] in values:
        result["pending_question"] = None
    if "source_cut" in values and result["state"]["request"].get("source_cut") != brief["state"]["request"].get("source_cut"):
        result.update(pending_question=None, proposed_updates=[],
            notice="Your source description changed. Existing draft definitions are retained for review; previous proposed choices need to be reconsidered for this source.")
    return result


def accept_updates(brief, slot_ids):
    if not isinstance(slot_ids, list) or not set(slot_ids) <= {item["slot"] for item in brief["proposed_updates"]}:
        raise ValueError("Select the current proposed study brief fields.")
    return edit(brief, {item["slot"]: item["value"] for item in brief["proposed_updates"] if item["slot"] in slot_ids})


def clear(brief):
    result = copy.deepcopy(brief)
    result["state"] = intake.new_state(DOMAIN, brief["state"]["pack"], brief["state"]["actor"])
    result.update(pending_question=None, proposed_updates=[], unknown_slots=[], notice="", question_epoch=result["question_epoch"] + 1)
    return result


def model_context(brief, max_bytes=3500):
    """Whole values only; omitted entries are named, never silently truncated."""
    context = {"status": "private draft; no scientific approval", "request": {},
               "unresolved": list(brief["unknown_slots"]), "omitted_slots": [],
               "active_question": copy.deepcopy(brief.get("pending_question"))}
    if brief["unknown_slots"]:
        context["previous_unresolved"] = {}
    base_size = len(json.dumps(context, ensure_ascii=False).encode())
    if base_size > max_bytes:
        raise ValueError("The complete active study question does not fit this request's context budget.")
    for sid, value in brief["state"]["request"].items():
        if not intake._filled(value):
            continue
        destination = "previous_unresolved" if sid in brief["unknown_slots"] else "request"
        context[destination][sid] = value
        if len(json.dumps(context, ensure_ascii=False).encode()) > max_bytes - 200:
            del context[destination][sid]
            context["omitted_slots"].append(sid)
    if len(json.dumps(context, ensure_ascii=False).encode()) > max_bytes:
        raise ValueError("The complete active study question does not fit this request's context budget.")
    return context


def _slot_hints(question, known):
    """Only the current request can name a question's intended brief field."""
    normal = " ".join(re.findall(r"[a-z0-9]+", str(question or "").lower()))
    mentioned, requested = [], []
    for sid in known:
        phrase = re.escape(sid.replace("_", " "))
        match = re.search(r"(?<!\w)" + phrase + r"(?!\w)", normal)
        if not match:
            continue
        mentioned.append((match.start(), sid))
        patterns = (
            r"(?<!\w)" + phrase + r"\s+(?:clarification\s+)?(?:question|mcq)\b",
            r"\b(?:question|mcq)\s+(?:(?:about|on|for|regarding|covering)\s+)?(?:the\s+)?" + phrase + r"(?!\w)",
            r"\b(?:ask|clarify|discuss)\s+(?:me\s+)?(?:about\s+)?(?:the\s+)?" + phrase + r"(?!\w)",
        )
        for pattern in patterns:
            found = re.search(pattern, normal)
            if found and not re.search(r"\b(?:do not|dont|don t|never|avoid|rather than)\b", normal[max(0, found.start() - 35):found.start()]):
                requested.append(sid)
                break
    return [sid for _, sid in sorted(mentioned)], requested[0] if len(requested) == 1 else None


def prompt_instructions(question=None):
    """Compact schema plus whole, canonical intake questions for this request."""
    known = slots()
    mentioned, focus = _slot_hints(question, known)
    text = ("study_brief is private draft; previous_unresolved is historical, not decided. "
        'For study planning return ONE next unresolved question in JSON, not only prose: "questions":[{"id":"slot","prompt":"question","options":[{"id":"a","label":"choice","explanation":"meaning"}],"allow_text":true}]. '
        "Use 2-4 options; UI adds Not sure. Continue one detail at a time; omit questions for unrelated tasks. "
        "Keep unknowns open; infer no defaults/codes. Use brief_updates:[{slot,value,quote}] for answers, quoting exact latest user wording; inferred wording needs review. "
        "Slot IDs: " + ",".join(known) + ".\n")
    if focus:
        text += "Requested question field: " + focus + ". questions[0].id MUST be " + focus + "; use its meaning below.\n"
    counterparts = {"follow_up": "outcomes", "outcomes": "follow_up", "index_definition": "inclusion_sequence", "inclusion_sequence": "index_definition"}
    priority = ([focus] if focus else []) + ([counterparts[focus]] if focus in counterparts else [])
    priority += mentioned + ["follow_up", "outcomes", "index_definition", "inclusion_sequence"]
    seen = set()
    for sid in priority:
        if sid in seen:
            continue
        seen.add(sid)
        line = sid + ": " + known[sid]["ask"] + "\n"
        if len((text + line).encode("utf-8")) <= 1400:
            text += line
        elif sid == focus:
            raise ValueError("The requested field's complete canonical question exceeds the assistant guidance budget.")
    if len(text.encode("utf-8")) > 1400:
        raise ValueError("The intake field vocabulary exceeds the assistant guidance budget.")
    return text


def retrieval_context(brief, max_chars=2200):
    lines = []
    for sid in ("intended_use", "population", "source_cut", "index_definition", "outcomes", "follow_up", "variables_domains"):
        if sid in brief["unknown_slots"]:
            continue
        value = brief["state"]["request"].get(sid)
        if value and sum(map(len, lines)) + len(value) + len(sid) + 2 < max_chars:
            lines.append(sid + ": " + value)
    question = current_question(brief)
    if question and sum(map(len, lines)) + len(question["prompt"]) < max_chars:
        lines.append(question["prompt"])
    return "\n".join(lines)


def _validate(brief, scope, actor_id):
    if (not isinstance(brief, dict) or brief.get("schema") != 1 or brief.get("scope") != scope
            or not isinstance(brief.get("state"), dict) or brief["state"].get("domain") != DOMAIN
            or brief["state"].get("pack") != scope["pack"] or brief["state"].get("actor") != actor_id):
        raise ValueError("This study brief belongs to a different checkout, person or product.")
    known = slots()
    request = brief["state"].get("request")
    if type(brief.get("question_epoch")) is not int or not 0 <= brief["question_epoch"] <= 1_000_000_000:
        raise ValueError("The saved study brief question version is unreadable.")
    binding = brief.get("binding")
    if (not isinstance(binding, dict) or set(binding) != {"connection", "source", "access"}
            or any(not isinstance(value, str) or not re.fullmatch(r"[0-9a-f]{64}", value) for value in binding.values())):
        raise ValueError("The saved study brief context is unreadable.")
    if not isinstance(request, dict) or set(request) != set(known):
        raise ValueError("The saved study brief has unsupported fields.")
    for value in request.values():
        if value is not None:
            _text(value)
    if not isinstance(brief.get("unknown_slots"), list) or not set(brief["unknown_slots"]) <= set(known):
        raise ValueError("The saved study brief has unsupported unresolved questions.")
    if not isinstance(brief.get("proposed_updates"), list) or len(brief["proposed_updates"]) > len(known):
        raise ValueError("The saved study brief has unsupported proposed changes.")
    for item in brief["proposed_updates"]:
        validate_reply([{key: item.get(key) for key in ("slot", "value", "quote")}])
    pending = brief.get("pending_question")
    if pending:
        question = {key: pending.get(key) for key in ("id", "prompt", "options", "allow_text")}
        if question["options"]:
            validate_reply([], [question])
        elif (question["id"] not in known or question["prompt"] != known[question["id"]]["ask"]
                or question["allow_text"] is not True):
            raise ValueError("The saved question is malformed.")
        if pending.get("token") != _question(question, brief["binding"], brief["state"]["request"].get("source_cut"), brief["question_epoch"])["token"]:
            raise ValueError("The saved question no longer matches its context.")
    if len(json.dumps(brief, ensure_ascii=False).encode()) > MAX_SNAPSHOT_BYTES:
        raise ValueError("This study brief exceeds its supported local draft size.")
    ai._ingress(json.dumps({"request": request, "pending": pending, "proposals": brief["proposed_updates"]}, ensure_ascii=False))


def _read(directory, scope, actor_id):
    path = directory / "current.json"
    if not path.exists():
        return None
    if path.resolve() != path or path.stat().st_size > 2000:
        raise ValueError("The saved study brief pointer is unreadable.")
    head = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(head, dict) or set(head) != {"file", "revision"}:
        raise ValueError("The saved study brief pointer is unreadable.")
    name = head.get("file", "")
    if not isinstance(name, str) or not re.fullmatch(r"product_brief_[0-9-]+-[0-9a-f]{6}\.yaml", name):
        raise ValueError("The saved study brief version is unreadable.")
    file = directory / name
    if file.resolve() != file or file.stat().st_size > MAX_SNAPSHOT_BYTES:
        raise ValueError("The saved study brief version is unreadable.")
    raw = file.read_bytes()
    if head.get("revision") != hashlib.sha256(raw).hexdigest():
        raise ValueError("The saved study brief changed outside this conversation. Reload its draft history.")
    # Load only the published version using the canonical kept-request parser.
    with tempfile.TemporaryDirectory(prefix="rwdbrief-") as staging:
        (Path(staging) / name).write_bytes(raw)
        documents = intake.load_requests(staging)
    if len(documents) != 1:
        raise ValueError("The saved study brief is unreadable.")
    document = documents[0]
    if document.get("kind") != DOMAIN or document.get("status") != "draft":
        raise ValueError("The saved study brief must remain a private intake draft.")
    notes = document.get("notes")
    if not isinstance(notes, list) or len(notes) != 1 or not isinstance(notes[0], dict) or set(notes[0]) != {"portal_study_brief"}:
        raise ValueError("The saved study brief continuation is unreadable.")
    brief = notes[0]["portal_study_brief"]
    if not isinstance(brief, dict):
        raise ValueError("The saved study brief continuation is unreadable.")
    state = intake.new_state(DOMAIN, document.get("pack"), document.get("raised_by"))
    state["request"].update(document["request"])
    cleared = document.get("cleared") or []
    known = slots()
    if not isinstance(cleared, list) or any(not isinstance(sid, str) or sid not in known for sid in cleared):
        raise ValueError("The saved study brief has unsupported cleared fields.")
    state["cleared"] = cleared
    brief["state"] = state
    brief["revision"] = head["revision"]
    if "question_epoch" not in brief:
        brief.update(question_epoch=0, pending_question=None,
                     notice="Your saved study wording was restored. Request a fresh clarification after this assistant update.")
    _validate(brief, scope, actor_id)
    return brief


def load(root, pack, actor_id, *, allowed_packs, connection=None, source=None, scope_id=""):
    scope, directory = _scope(root, pack, actor_id, allowed_packs, scope_id)
    brief = _read(directory, scope, actor_id) or new(root, pack, actor_id, allowed_packs=allowed_packs, connection=connection, source=source, scope_id=scope_id)
    binding = _binding(connection, source, allowed_packs)
    if brief["binding"] != binding:
        brief.update(binding=binding, pending_question=None, proposed_updates=[],
                     question_epoch=brief["question_epoch"] + 1,
                     notice="The assistant connection, source or available products changed. Your draft wording is retained; previous proposed choices need a fresh question.")
    return brief


def save(root, pack, actor_id, brief, *, allowed_packs, can_write, expected_revision=None, scope_id=""):
    if can_write is not True:
        raise ValueError("Saving a private study brief requires editing access in this workspace.")
    scope, directory = _scope(root, pack, actor_id, allowed_packs, scope_id)
    _validate(brief, scope, actor_id)
    from local_process_lock import locked
    from scientific_definitions import _atomic
    directory.mkdir(parents=True, exist_ok=True)
    with locked(directory / ".save.lock", directory):
        current = _read(directory, scope, actor_id)
        if (current or {}).get("revision") != expected_revision:
            raise ValueError("This study brief changed in another session. Reload it before saving your edits.")
        meta = {key: copy.deepcopy(value) for key, value in brief.items() if key not in {"state", "revision"}}
        state = copy.deepcopy(brief["state"])
        state["notes"] = [{"portal_study_brief": meta}]
        # The intake writer publishes into a temporary directory first; only a
        # complete immutable version is made current under the existing lock.
        with tempfile.TemporaryDirectory(prefix="rwdbrief-") as staging:
            saved = Path(intake.save_request(state, directory=staging, status="draft"))
            raw = saved.read_bytes()
            revision = hashlib.sha256(raw).hexdigest()
            _atomic(directory / saved.name, raw)
            _atomic(directory / "current.json", json.dumps({"file": saved.name, "revision": revision}).encode())
        result = copy.deepcopy(brief)
        result["revision"] = revision
        return result


def registration_handoff(root, target_pack, actor_id, *, allowed_packs):
    """Capture the exact private brief only after a successful registration.

    The caller places this token in session state. There is no discovery of an
    unrelated previous brief when merely opening an existing product.
    """
    source_scope, source_dir = _scope(root, "", actor_id, allowed_packs)
    target_scope, target_dir = _scope(root, target_pack, actor_id, allowed_packs)
    if not target_scope["pack"].startswith("products/"):
        raise ValueError("A setup brief continues into the product that was just created.")
    source = _read(source_dir, source_scope, actor_id)
    if not source or not _copy_values(source):
        return None
    target = _read(target_dir, target_scope, actor_id)
    return {"schema": 1, "source_scope": source_scope, "target_scope": target_scope,
            "source_revision": source["revision"], "target_revision": (target or {}).get("revision")}


def _copy_values(brief):
    # The actor was established independently; a requested-by label cannot
    # authenticate anyone. Unresolved and model-inferred wording never travels.
    return {sid: value for sid, value in brief["state"]["request"].items()
            if sid != "requested_by" and sid not in brief["unknown_slots"] and intake._filled(value)}


def review_handoff(root, target_pack, actor_id, token, *, allowed_packs):
    source_scope, source_dir = _scope(root, "", actor_id, allowed_packs)
    target_scope, target_dir = _scope(root, target_pack, actor_id, allowed_packs)
    if (not isinstance(token, dict) or set(token) != {"schema", "source_scope", "target_scope", "source_revision", "target_revision"}
            or token.get("schema") != 1 or token.get("source_scope") != source_scope or token.get("target_scope") != target_scope):
        raise ValueError("This brief continuation belongs to a different checkout, person or newly created product.")
    source = _read(source_dir, source_scope, actor_id)
    target = _read(target_dir, target_scope, actor_id)
    if not source or source["revision"] != token["source_revision"] or (target or {}).get("revision") != token["target_revision"]:
        raise ValueError("The setup or product brief changed. Review a fresh continuation before copying its wording.")
    target = target or new(root, target_pack, actor_id, allowed_packs=allowed_packs)
    values = _copy_values(source)
    if not values:
        raise ValueError("This setup brief has no resolved descriptive wording to continue.")
    changes = [{"slot": sid, "before": target["state"]["request"].get(sid), "value": value}
               for sid, value in values.items()]
    return {"values": values, "changes": changes, "target": target,
            "digest": _hash({"token": token, "changes": changes})}


def apply_handoff(root, target_pack, actor_id, token, *, allowed_packs, can_write, expected_digest):
    if can_write is not True:
        raise ValueError("Continuing a study brief requires editing access in this workspace.")
    review_handoff(root, target_pack, actor_id, token, allowed_packs=allowed_packs)
    _, source_dir = _scope(root, "", actor_id, allowed_packs)
    from local_process_lock import locked
    # Serialize against a concurrent change of the source, then use the existing
    # target compare-and-swap lock; no product/contract files are written.
    with locked(source_dir / ".save.lock", source_dir):
        reviewed = review_handoff(root, target_pack, actor_id, token, allowed_packs=allowed_packs)
        if reviewed["digest"] != expected_digest:
            raise ValueError("The brief comparison changed. Review it again before continuing.")
        target = edit(reviewed["target"], reviewed["values"])
        target.update(pending_question=None, proposed_updates=[])
        return save(root, target_pack, actor_id, target, allowed_packs=allowed_packs,
            can_write=can_write, expected_revision=token["target_revision"])
