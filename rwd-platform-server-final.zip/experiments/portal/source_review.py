"""Capture an authorized person's source review and AI-access judgment.

The form changes only intentional fields of the authoritative program_spec.
Names, dates and decisions come from the person; signatures are never inferred.
"""
from __future__ import annotations
from contextlib import ExitStack

import copy
import hashlib
import json
import os
from pathlib import Path
import re
import tempfile

import yaml

import flow_guidance as guidance
import product_gates as pg
import source_manifest as sm
import specification_details as details

METADATA = details.FIELDS
REVIEW_FIELDS = (*METADATA, "approved_by", "approval_date")
ACCESS_FIELDS = ("ai_classification", "classified_by", "classified_date")
DRAFT_FIELDS = (*METADATA, "why_provisional")
FIELDS = (*REVIEW_FIELDS, *ACCESS_FIELDS, "why_provisional")
# the words the form shows for each field; a refusal names those, never the field ids (walk UC4-14)
LABELS = {"document_id": "Document ID", "revision": "Document revision", "data_refresh": "Data refresh or delivery",
          "rwb_qc_reference": "Specification QC reference", "approved_by": "Scientific reviewer's name",
          "approval_date": "Scientific review date", "classified_by": "Access classifier's name", "classified_date": "Classification date"}
NOTICE = ("Saving records the review you entered. It does not verify your identity, sign the review, "
          "seal its history or approve a release. The named reviewer must still authenticate the current record.")


def _failure(message):
    return {"ok": False, "changed": False, "errors": [str(message)], "values": {}, "digest": "", "notice": NOTICE}


def _source(root, product, material):
    path, problem = guidance._local_source(Path(root), Path(product), material, file_only=False)
    current = ""
    if path is not None:
        try:
            current = sm.sha256(str(path))
        except (OSError, ValueError):
            problem = "The registered specification cannot be read with current permissions."
    recorded = str(material.get("sha256") or "")
    if not problem and not re.fullmatch(r"[0-9a-f]{64}", recorded):
        problem = "Record the specification's checksum in Progress and next step before completing a review or access decision."
    if not problem and current != recorded:
        problem = "The specification changed after its checksum was recorded. Review the source revision before recording a decision about these bytes."
    return {"path": str(material.get("path_or_link") or ""), "recorded_sha256": recorded,
            "current_sha256": current, "ready": not problem and bool(current), "problem": problem}


def _describe_loaded(root, path, pack, raw, doc, index):
    material = doc["source_materials"][index]
    values = {field: "" if sm.unstated(material.get(field)) else str(material[field]) for field in FIELDS}
    missing = [field for field in (*REVIEW_FIELDS, *ACCESS_FIELDS) if sm.field_unstated(material, field)]
    return {"ok": True, "pack": pack, "path": pack + "/source_refs.yaml", "digest": hashlib.sha256(raw).hexdigest(),
            "material_id": material["material_id"], "status": str(material.get("status") or ""), "values": values,
            "missing_fields": missing, "source": _source(root, path.parent, material), "errors": [], "notice": NOTICE}


def describe(root, pack, allowed_packs=None):
    try:
        path, pack, raw, _text, doc, index, _node = details._load(root, pack, allowed_packs)
        return _describe_loaded(root, path, pack, raw, doc, index)
    except (details._Invalid, OSError, ValueError, TypeError, UnicodeError, yaml.YAMLError, RecursionError) as error:
        return _failure(str(error) if isinstance(error, details._Invalid) else "The source record could not be read safely. Ask your data expert to repair it.")


def _edited(text, doc, index, node, changes, pack, removals=()):
    """Replace only scalar values, preserving other materials, comments and fields.

    `removals` names fields dropped whole. A reviewed material that still carries the
    pending reason ("Not yet approved") is two statements about one artifact, and a
    UAT run left exactly that standing; the save that settles the status takes the
    sentence saying it is unsettled with it, and nothing else on the material moves.
    """
    if not isinstance(node, yaml.MappingNode) or node.flow_style:
        raise details._Invalid("The program specification uses an inline mapping. Ask your data expert to convert it before using this form.")
    entries = {key.value: (key, value) for key, value in node.value}
    pairs = {field: value for field, (_key, value) in entries.items()}
    edits, additions = [], []
    newline = "\r\n" if "\r\n" in text else "\n"
    for field in removals:
        if field not in entries or field in changes:
            continue
        key, old = entries[field]
        line_start = text.rfind("\n", 0, key.start_mark.index) + 1
        if text[line_start:key.start_mark.index].strip():
            raise details._Invalid(f"The existing {field} shares a line with another field. Ask your data expert to move it to its own line before recording the review.")
        # A block scalar's end mark already sits after its final line break; a plain
        # scalar's sits before it, so the break is taken along with the line.
        end = old.end_mark.index
        if text.startswith("\r\n", end):
            end += 2
        elif text.startswith("\n", end):
            end += 1
        edits.append((line_start, end, ""))
    for field, value in changes.items():
        encoded = json.dumps(value, ensure_ascii=False)
        if field not in pairs:
            additions.append(f"{field}: {encoded}")
            continue
        old = pairs[field]
        if not isinstance(old, yaml.ScalarNode):
            raise details._Invalid(f"The existing {field} is not a scalar field. Ask your data expert to repair it.")
        prefix = " " if old.start_mark.index and text[old.start_mark.index - 1] == ":" else ""
        suffix = newline if old.style in {"|", ">"} and text[old.start_mark.index:old.end_mark.index].endswith("\n") else ""
        edits.append((old.start_mark.index, old.end_mark.index, prefix + encoded + suffix))
    if additions:
        first_key = node.value[0][0]
        end = text.find("\n", first_key.end_mark.index)
        end, prefix = (len(text), newline) if end < 0 else (end + 1, "")
        indent = " " * first_key.start_mark.column
        edits.append((end, end, prefix + "".join(indent + item + newline for item in additions)))
    for start, end, value in sorted(edits, key=lambda edit: (edit[0], edit[1]), reverse=True):
        text = text[:start] + value + text[end:]
    expected = copy.deepcopy(doc)
    expected["source_materials"][index].update(changes)
    for field in removals:
        expected["source_materials"][index].pop(field, None)
    replacement = text.encode("utf-8")
    _text, actual, _index, _node = details._parse(replacement, pack)
    if actual != expected:
        raise details._Invalid("The edit would change another source field. Nothing was saved.")
    return replacement, actual


def save(root, pack, updates, *, expected_digest, mode, confirmed=False, local_demo, can_review, allowed_packs=None):
    """Atomically save explicit source-review fields; there is no signing operation."""
    if local_demo is not True or can_review is not True:
        return _failure("Recording source decisions requires reviewer access in an authorized local session.")
    permitted = {"review": REVIEW_FIELDS, "access": ACCESS_FIELDS, "draft": DRAFT_FIELDS}
    if mode not in permitted or not isinstance(updates, dict) or any(field not in permitted[mode] for field in updates):
        return _failure("Only the fields shown in this source-review form can be saved.")
    if mode != "draft" and confirmed is not True:
        return _failure("Confirm that you reviewed the specification and are recording the decision actually made before saving.")
    if not isinstance(expected_digest, str) or not re.fullmatch(r"[0-9a-f]{64}", expected_digest):
        return _failure("Reload the current source review before saving; its starting checksum is required.")
    clean = {}
    for field, value in updates.items():
        if not isinstance(value, str):
            return _failure(f"{field} must be entered as text.")
        value = value.strip()
        if mode == "draft" and not value:
            continue
        limit = details.LIMITS.get(field, 4000 if field == "why_provisional" else 200)
        if len(value) > limit or any((ord(c) < 32 and not (field == "why_provisional" and c in "\n\r\t")) or ord(c) == 127 for c in value):
            return _failure(f"{field} must be a single line of at most {limit} characters.")
        if value and sm.unstated(value):
            return _failure(f"{field} needs the actual value. Leave unknown metadata blank when saving a draft.")
        clean[field] = value
    lock_stack = ExitStack()
    temporary = None
    try:
        path, pack = details._paths(root, pack, allowed_packs)
        lock_stack.enter_context(details.source_edit_lock(root, path))
        path, pack, raw, text, doc, index, node = details._load(root, pack, allowed_packs)
        if hashlib.sha256(raw).hexdigest() != expected_digest:
            raise details._Invalid("The source record changed while this form was open. Reload and review the current values before saving.")
        material = doc["source_materials"][index]
        updated = {**material, **clean}
        if mode != "draft":
            source = _source(root, path.parent, material)
            if not source["ready"]:
                raise details._Invalid(source["problem"])
        if mode == "review":
            missing = [field for field in (*REVIEW_FIELDS, *ACCESS_FIELDS) if sm.field_unstated(updated, field)]
            if missing:
                raise details._Invalid("Complete these fields before recording the scientific review: "
                                       + ", ".join(LABELS.get(field, field) for field in missing) + ". AI access fields are entered in the AI access view.")
            bad = pg.not_a_person(updated.get("approved_by"))
            if bad:
                raise details._Invalid("Scientific reviewer: " + bad)
            bad = pg.bad_date(updated.get("approval_date"))
            if bad:
                raise details._Invalid("Review date " + bad)
            bad = sm.classification_errors(updated)
            if bad:
                raise details._Invalid("Complete a valid AI access decision first: " + " ".join(bad))
            clean["status"] = "reviewed"
        if mode == "access":
            bad = sm.classification_errors({field: updated.get(field) for field in ACCESS_FIELDS})
            if bad:
                raise details._Invalid("AI access decision: " + " ".join(bad))
        changes = {field: value for field, value in clean.items() if material.get(field) != value}
        # The pending reason says the review has not happened. Once this save records
        # that it has, the sentence is false and Gate 1 reads it beside `reviewed`.
        removals = tuple(field for field in sm.PENDING_FIELDS if mode == "review" and field in material)
        if not changes and not removals:
            return {**_describe_loaded(root, path, pack, raw, doc, index), "changed": False, "changed_fields": []}
        replacement, resulting_doc = _edited(text, doc, index, node, changes, pack, removals=removals)
        with tempfile.NamedTemporaryFile(mode="wb", prefix=".source-review-", suffix=".tmp", dir=path.parent, delete=False) as handle:
            temporary = Path(handle.name)
            handle.write(replacement)
            handle.flush()
            os.fsync(handle.fileno())
        os.chmod(temporary, path.stat().st_mode)
        final_path, final_pack, current, _text, current_doc, current_index, _node = details._load(root, pack, allowed_packs)
        if final_path != path or final_pack != pack or hashlib.sha256(current).hexdigest() != expected_digest:
            raise details._Invalid("The source record changed during this save. Reload before trying again.")
        if mode != "draft":
            current_source = _source(root, path.parent, current_doc["source_materials"][current_index])
            if not current_source["ready"] or current_source["current_sha256"] != source["current_sha256"]:
                raise details._Invalid("The specification changed during this save. Nothing was saved; review the current source first.")
        os.replace(temporary, path)
        temporary = None
        warnings = []
        # ONE PERSON, TWO HATS (walks UC1-04 and NC-11, 2026-09-07): the reviewer who is also the person
        # who classified the material is recorded, and told so; Gate 1 has no two-person rule of its own
        if mode == "review" and str(updated.get("approved_by") or "").casefold() == str(updated.get("classified_by") or "").casefold():
            warnings.append(f"{updated.get('approved_by')} both classified this specification and is recorded as its scientific reviewer. "
                            "A second person is the usual practice; the record stands as typed.")
        return {**_describe_loaded(root, path, pack, replacement, resulting_doc, index), "changed": True,
                "changed_fields": [*changes, *removals], "authenticated": False, "warnings": warnings}
    except FileExistsError:
        return _failure("Another source edit is in progress. Wait for it to finish, then reload.")
    except (details._Invalid, OSError, ValueError, TypeError, UnicodeError, yaml.YAMLError, RecursionError) as error:
        return _failure(str(error) if isinstance(error, details._Invalid) else "The review could not be saved safely. The existing source record was retained.")
    finally:
        if temporary is not None:
            try:
                temporary.unlink(missing_ok=True)
            except OSError:
                pass
        lock_stack.close()
