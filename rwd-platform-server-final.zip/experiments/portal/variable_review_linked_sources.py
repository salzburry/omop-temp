"""Per-table source inputs, in the shape consumed by source_check and contracts."""
from __future__ import annotations

from copy import deepcopy

import streamlit as st

import variable_review_controls as controls
from variable_review_source_controls import render_columns, _chosen


def _initial(current):
    if isinstance(current, dict):
        return [{"id": number, "alias": str(alias), "columns": deepcopy(columns) if isinstance(columns, dict) else {},
                 "legacy": "" if isinstance(columns, dict) else str(columns)}
                for number, (alias, columns) in enumerate(current.items())]
    if current in (None, "", []):
        return []
    try:
        names = controls.list_values(current)
    except ValueError:
        names = [str(current)]
    return [{"id": number, "alias": name, "columns": {}, "legacy": name}
            for number, name in enumerate(names)]


def render(current, metadata, *, key, permitted=True):
    """Return explicit alias -> role -> column mappings and unfinished-card errors.

    The caller can show the main table separately and pass only additional
    sources here; it must merge that main mapping when storing nonempty inputs.
    Legacy input-name lists remain visible until mapped or explicitly removed.
    """
    state_key, next_key = key + "_source_cards", key + "_source_next"
    if state_key not in st.session_state:
        st.session_state[state_key] = _initial(current)
    cards = st.session_state[state_key]
    if next_key not in st.session_state:
        st.session_state[next_key] = max((card["id"] for card in cards), default=-1) + 1
    configured = (metadata or {}).get("configured_sources", {})
    aliases = {alias: alias for alias in configured}
    result, errors = {}, []
    seen = set()
    st.write("**Source inputs**")
    st.caption("Map additional tables separately. Calculated variable names belong in Dependencies.")
    for number, card in enumerate(cards, 1):
        card_key = key + "_source_" + str(card["id"])
        st.write(f"**Source input {number}**")
        if card["legacy"]:
            st.info("Previously saved input name: " + card["legacy"] +
                    ". Select its source table and columns, or remove it and use Dependencies if it is a calculated variable.")
        alias = controls.render_choice("Input source alias " + str(number), card["alias"], aliases,
            key=card_key + "_alias", disabled=not permitted)
        declaration = configured.get(str(alias).strip().lower(), {})
        roles = declaration.get("role_columns", {})
        columns = declaration.get("columns", [])
        mapped, unfinished = render_columns(card["columns"], key=card_key,
            roles=list(roles), columns=columns, disabled=not permitted)
        errors.extend(f"Source input {number}: {message}" for message in unfinished)
        if not _chosen(alias) or not mapped:
            errors.append(f"Source input {number}: choose its source alias and map at least one column, or remove this input.")
        elif alias.casefold() in seen:
            errors.append(f"Source input '{alias}' is repeated. Keep one mapping for each source alias.")
        else:
            seen.add(alias.casefold())
            result[alias] = mapped
        if st.button("Remove source input " + str(number), key=card_key + "_remove", disabled=not permitted):
            st.session_state[state_key] = [entry for entry in cards if entry["id"] != card["id"]]
            st.rerun()
    if st.button("Add source input", key=key + "_source_add", disabled=not permitted):
        cards.append({"id": st.session_state[next_key], "alias": "", "columns": {}, "legacy": ""})
        st.session_state[next_key] += 1
        st.rerun()
    return result, errors
