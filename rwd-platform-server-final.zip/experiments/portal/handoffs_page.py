"""The handoffs page and the "ask" widget: every piece of work handed to another role, with its
owner, status and response, on the product it belongs to (2026-09-07)."""
from __future__ import annotations

import streamlit as st
import form_assistance as form_help
import re

import handoffs

PREFIX = "handoffs_"
OWNER_WORDS = {"dataexpert": "Data expert", "data expert": "Data expert", "science": "Science", "engineering": "Engineering",
               "reviewer": "Reviewer", "administrator": "Administrator", "admin": "Administrator", "qc": "Data expert"}


def owner_from(text):
    """The owner role a step's own words name (status.py's owner line), else the data expert."""
    low = str(text or "").lower()
    for word, owner in OWNER_WORDS.items():
        if word in low:
            return owner
    return "Data expert"


def _is_owner(doc, role, perms):
    if role == "admin" or "manage_users" in perms:
        return True
    owner = doc.get("owner")
    if owner == "Data expert":
        return "run_gates" in perms
    if owner == "Science":
        return "answer" in perms
    if owner == "Reviewer":
        return "review" in perms or role == "reviewer"
    if owner == "Engineering":
        return "run_gates" in perms
    return False


def ask(root, pack, action, card, actor_id, *, local_demo, can_view, allowed_packs=None, key="ask"):
    """The widget on a Flow step: hand this step to the role that owns it, as a tracked request."""
    if not can_view:
        return False
    action_id = str((action or {}).get("id") or "")
    try:
        existing = [h for h in handoffs.listing(root, pack, allowed_packs=allowed_packs, include_closed=False) if h.get("action_id") == action_id]
    except handoffs.Refused as error:
        st.warning(str(error))
        existing = []
    for doc in existing:
        st.info(f"Already handed to {doc['owner']} by {doc['requested_by']} on {str(doc['requested_at'])[:10]}: {doc['status']}. "
                "The answer appears on the Handoffs page.")
    if existing:
        return False          # one open request per step (walk NEW-2): no second form
    if not local_demo:
        st.caption("Handoffs are recorded on the person's own checkout in this version.")
        return False
    suggested = owner_from((card or {}).get("owner"))
    with st.form(f"{PREFIX}{key}_{action_id}"):
        owner = st.selectbox("Who should do this?", list(handoffs.OWNERS), index=list(handoffs.OWNERS).index(suggested), key=f"{PREFIX}{key}_owner_{action_id}")
        note = form_help.field(st.text_area, "What exactly do you need, in your words? (required)", key=f"{PREFIX}{key}_note_{action_id}",
                            placeholder="Example: the delivery for 2026 Q3 is on the shared drive; please register it and check the source.", binding=(pack, actor_id, action_id))
        sent = st.form_submit_button(f"Hand this step to {owner}", key=f"{PREFIX}{key}_send_{action_id}")
    if not sent:
        return False
    title = str((action or {}).get("label") or (card or {}).get("text") or "This step").split(":")[0][:160]
    try:
        doc = handoffs.create(root, pack, title=title, owner=owner, note=note, requested_by=actor_id, action_id=action_id,
                              allowed_packs=allowed_packs, local_demo=local_demo, can_view=can_view)
    except handoffs.Refused as error:
        st.error("Not recorded. " + str(error))
        return False
    st.success(f"Handed to {doc['owner']}. It is listed on the Handoffs page and on Home until {doc['owner']} answers.")
    return True


def render(root, pack, actor_id, *, allowed_packs, local_demo, can_write, can_review, route="handoffs", params=None,
           role="", perms=()):
    params = params or {}
    notice = st.session_state.pop(PREFIX + "notice", None)
    if notice:
        st.success(str(notice))
    try:
        rows = handoffs.listing(root, pack, allowed_packs=allowed_packs)
    except handoffs.Refused as error:
        st.warning(str(error))
        return
    if not rows:
        st.info("Nothing has been handed to another role for this product yet. A step's page offers this when the portal cannot do the step itself.")
    focus = params.get("handoff_id")
    for doc in rows:
        if doc.get("status") == "unreadable":
            st.warning(doc["title"])
            continue
        open_it = focus == doc["id"] or doc["status"] in handoffs.OPEN
        with st.expander(f"{doc['title']} · {doc['owner']} · {doc['status']}", expanded=bool(open_it)):
            st.write(f"Asked by **{doc['requested_by']}** on {str(doc['requested_at'])[:10]}" + (f" for step `{doc['action_id']}`" if doc.get("action_id") else "") + ".")
            if doc.get("note"):
                st.write(doc["note"])
            if doc.get("response"):
                st.write(f"**Answer:** {doc['response']}")
            if str(doc.get("action_id") or "").startswith("science-review:"):
                import science_review_handoffs_page
                navigation = science_review_handoffs_page.render_snapshot(root, pack, doc["id"], allowed_packs=allowed_packs)
                if navigation:
                    return navigation
            if str(doc.get("action_id") or "").startswith("configuration-proposal:"):
                import configuration_proposal_page
                configuration_proposal_page.render_engineering_request(root, pack, doc["id"], actor_id,
                    local_demo=local_demo, can_write=can_write, allowed_packs=allowed_packs)
            elif str(doc.get("action_id") or "").startswith("proposal_"):
                st.info("This older engineering request has no exact proposal snapshot. Ask its author to share the reviewed proposal from Plan changes and create a linked engineering request.")
            if str(doc.get("action_id") or "").startswith("template-review:"):
                import template_library_workspace_page
                navigation = template_library_workspace_page.render_shared(root, pack, doc["id"], allowed_packs=allowed_packs)
                if navigation:
                    return navigation
            if str(doc.get("action_id") or "").startswith("specialist-review:"):
                if st.button("Open the specialist result", key="handoffs_specialist_" + doc["id"]):
                    return {"route": "specialist_assistant", "params": {"review_id": doc["id"]}}
            if str(doc.get("action_id") or "").startswith("implementation-review:"):
                import pattern_workspace
                try:
                    destination = pattern_workspace.review_target(root, pack, actor_id, doc["id"], allowed_packs=allowed_packs)
                except (ValueError, OSError, KeyError, TypeError, handoffs.Refused) as error:
                    st.warning(str(error))
                else:
                    if st.button("Open the exact implementation review", key="handoffs_implementation_" + doc["id"]):
                        return destination
            if str(doc.get("action_id") or "").startswith("claims-review:"):
                if st.button("Open the claims criteria workspace", key="handoffs_claims_" + doc["id"]):
                    return {"route": "claims_workspace", "params": {"handoff_id": doc["id"]}}
            legacy_source = re.fullmatch(r"legacy-source-review:([a-f0-9]{24})", str(doc.get("action_id") or ""))
            if legacy_source and st.button("Review the current source declarations", key="handoffs_legacy_source_" + doc["id"]):
                return {"route": "source_requirements", "params": {"legacy_input_digest": legacy_source[1]}}
            if str(doc.get("action_id") or "").startswith("semantic-export:"):
                if st.button("Open the exact knowledge export", key="handoffs_semantic_" + doc["id"]):
                    return {"route": "semantic_export", "params": {"version_id": doc["action_id"].split(":")[1]}}
            with st.expander("Who did what and when"):
                for h in doc.get("history") or []:
                    st.write(f"- {h['at'][:16].replace('T', ' ')}: {h['status']} by {h['by']}" + (f": {h['note']}" if h.get("note") else ""))
            if doc["status"] not in handoffs.OPEN:
                continue
            # the connected page knows the person's product permissions, not their role word: a person
            # who can review or write on this product may answer as its owner role
            is_owner = _is_owner(doc, role, perms) if (role or perms) else bool(can_review or can_write)
            is_requester = doc.get("requested_by") == actor_id
            if not (is_owner or is_requester):
                st.caption(f"Waiting on {doc['owner']}.")
                continue
            choices = ["in progress", "done", "declined"] if is_owner else []
            if is_requester:
                choices.append("withdrawn")
            with st.form(f"{PREFIX}respond_{doc['id']}"):
                status = st.selectbox("Record", choices, key=f"{PREFIX}status_{doc['id']}")
                note = form_help.field(st.text_area, "What was done, or why not (the requester reads this)", key=f"{PREFIX}rnote_{doc['id']}", binding=(doc["id"], doc.get("history")))
                sent = st.form_submit_button("Record", key=f"{PREFIX}record_{doc['id']}")
            if sent:
                try:
                    handoffs.transition(root, pack, doc["id"], status=status, by=actor_id, note=note, allowed_packs=allowed_packs,
                                        local_demo=local_demo, is_owner=is_owner, is_requester=is_requester)
                except handoffs.Refused as error:
                    st.error("Not recorded. " + str(error))
                else:
                    # the confirmation survives the rerun that redraws the list (walk UC3-P3-3)
                    st.session_state[PREFIX + "notice"] = f"Recorded: {status} on \"{doc['title']}\"."
                    st.rerun()
