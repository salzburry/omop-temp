"""The product-to-library review loop, with its exact version and evidence."""
from __future__ import annotations

import json
from pathlib import Path

import streamlit as st
import form_assistance as form_help

import template_library_workspace as backend

PREFIX = "template_library_"


def _errors(result):
    for error in result.get("errors") or []:
        st.error(error)


def _candidate(record, *, stale=False):
    checked = record["checked"]
    candidate = checked["candidate"]
    st.markdown("**Exact template candidate for review**")
    st.caption("This exact candidate was prepared for review. Its current library state is checked separately; no product release or authenticated approval is implied.")
    st.write(candidate["template_id"] + " · proposed version " + candidate["version"])
    if stale:
        st.warning("The source evidence or checkout revision changed. This is the historical candidate; prepare a fresh candidate before sharing it for action.")
    st.caption("Source: " + candidate["source"]["pack"] + " · commit " + str(candidate["source"].get("issued_at_commit")))
    st.dataframe([{"Reusable concept": row["slot"], "Source variable": row["variable_id"],
                   "Reviewed meaning": row.get("definition") or "Not stated"} for row in candidate["concepts"]],
                 hide_index=True, width="stretch")
    st.info("These choices stay with each adopting product: " + ", ".join(candidate["excludes"]) + ".")
    with st.expander("Exact before/after candidate and validator evidence", expanded=True):
        st.code(checked["diff"], language="diff")
        st.caption("Checked with: " + "; ".join(checked["validators"]))
        for notice in checked.get("notices") or []:
            st.info(notice)
    st.download_button("Download candidate for library review", checked["yaml"],
        file_name=candidate["template_id"] + "-" + candidate["version"] + "-candidate.yaml",
        mime="text/yaml", key=PREFIX + "download_" + record["id"])
    st.caption("Downloading this canonical manifest does not install it. The review and integration step below checks whether this exact version was applied and committed by the library steward.")


def render_shared(root, pack, handoff_id, *, allowed_packs):
    result = backend.shared(root, pack, handoff_id, allowed_packs=allowed_packs)
    _errors(result)
    if result["ok"]:
        _candidate(result["record"], stale=result["stale"])
        st.caption("Use the response below for review findings. Closing this work request does not install or approve the candidate.")
        if st.button("Continue library review and integration", key=PREFIX + "integrate_" + handoff_id):
            return {"route": backend.ROUTE, "params": {"review_id": handoff_id}}
        if st.button("Open current template-library readiness", key=PREFIX + "current_" + handoff_id):
            return {"route": backend.ROUTE, "params": {}}
    return None


def _integration(root, pack, actor_id, review_id, record, *, allowed_packs, local_demo, can_review, can_manage_library):
    st.markdown("**Review → apply the exact version → record its history**")
    notice = st.session_state.pop(PREFIX + "integration_notice", None)
    if notice:
        st.warning(notice)
    if st.button("Check this candidate in the library", key=PREFIX + "integration_refresh"):
        st.session_state.pop(PREFIX + "integration", None)
    if PREFIX + "integration" not in st.session_state:
        with st.spinner("Checking the exact version, source evidence and committed library bytes…"):
            st.session_state[PREFIX + "integration"] = backend.integration(root, pack, review_id, allowed_packs=allowed_packs)
    current = st.session_state[PREFIX + "integration"]
    _errors(current)
    if not current["ok"]:
        return None
    state = current["state"]
    if state == "recorded_in_library":
        st.success("The exact reviewed version is recorded in the shared library at commit " + str(current["commit"])[:12] + ".")
        st.caption("The version's content and source provenance passed the existing checks. This does not authenticate its review or release a product.")
        variables = list(dict.fromkeys(row["variable_id"] for row in record["checked"]["candidate"]["concepts"]))
        variable = st.selectbox("Which source concept should the next template review start from?", variables,
                                index=None, key=PREFIX + "adoption_variable")
        if st.button("Continue with this product's template review", key=PREFIX + "adoption", disabled=variable is None):
            return {"route": "template_review", "params": {"variable": variable}}
        return None
    if state == "applied_pending_commit":
        st.warning("The exact version is applied to the working library. Record its governed history before treating it as an available version for adoption.")
        st.caption("Run this on the library steward's own checkout with their configured signing identity, then choose Check this candidate in the library. It stages and commits only this exact release file; it does not push or release a product.")
        args = ["-C", str(Path(root).resolve())]
        commands = [args + ["add", "--", current["target"]],
                    args + ["commit", "-S", "--only", "-m", "Record reviewed template " + record["values"]["template_id"], "--", current["target"]]]
        # PowerShell single-quoted literals preserve paths without evaluating them.
        st.code("\n".join("git " + " ".join("'" + value.replace("'", "''") + "'" for value in command) for command in commands), language="powershell")
        return None
    if state != "not_applied":
        st.error("That library version already identifies different or unvalidated bytes. Existing versions are never overwritten; the steward must resolve the conflict or prepare a new version.")
        return None
    if current["stale"]:
        st.warning("The source evidence changed after this review request. Return to readiness and prepare a fresh candidate before application.")
        if st.button("Prepare a fresh candidate from current evidence", key=PREFIX + "fresh"):
            return {"route": backend.ROUTE, "params": {}}
        return None
    st.write("After reviewing the diff above, a library steward can apply these exact bytes as a new immutable version. Canonical checks run again before and after the write; failed validation removes only the unchanged new file.")
    authorized = local_demo is True and can_review is True and can_manage_library is True
    if not authorized:
        st.info("A library administrator with global library-management and review permission must perform this step. Product review permission alone cannot change the shared library.")
        if local_demo and can_review:
            with st.form(PREFIX + "request_admin"):
                note = form_help.field(st.text_area, "Review findings for the library administrator", key=PREFIX + "admin_note", binding=(review_id, record["sha256"]))
                requested = st.form_submit_button("Send this exact candidate to the library administrator", key=PREFIX + "request_admin_button")
            if requested:
                result = backend.request_application(root, pack, actor_id, review_id, note=note,
                    allowed_packs=allowed_packs, local_demo=local_demo, can_review=can_review)
                _errors(result)
                if result["ok"]:
                    return {"route": "handoffs", "params": {"handoff_id": result["handoff"]["id"]}, "changed": True}
    confirmed = st.checkbox("I reviewed this exact candidate and want to apply this new version to the working library. Its signed commit remains a separate step.", key=PREFIX + "apply_confirm", disabled=not authorized)
    if st.button("Apply reviewed library version", key=PREFIX + "apply", disabled=not authorized or not confirmed, type="primary"):
        with st.spinner("Revalidating and applying only the reviewed new library version…"):
            result = backend.apply_reviewed(root, pack, actor_id, review_id, expected_digest=record["sha256"], confirmed=confirmed,
                allowed_packs=allowed_packs, local_demo=local_demo, can_review=can_review, can_manage_library=can_manage_library)
        _errors(result)
        if result["ok"]:
            st.session_state.pop(PREFIX + "integration", None)
            return {"route": backend.ROUTE, "params": {"review_id": review_id}, "changed": bool(result.get("changed"))}
        if result.get("changed"):
            st.session_state.pop(PREFIX + "integration", None)
            st.session_state[PREFIX + "integration_notice"] = " ".join(result.get("errors") or [])
            return {"route": backend.ROUTE, "params": {"review_id": review_id}, "changed": True}
    return None


def render(root, pack, actor_id, *, allowed_packs, local_demo, can_write, can_review, route=backend.ROUTE, params=None, can_manage_library=False):
    params = params or {}
    context = (str(Path(root).resolve()), pack, actor_id, None if allowed_packs is None else tuple(sorted(allowed_packs)),
               bool(local_demo), bool(can_write), bool(can_manage_library), params.get("proposal_id"), params.get("review_id"))
    if st.session_state.get(PREFIX + "context") != context:
        for key in list(st.session_state):
            if str(key).startswith(PREFIX):
                st.session_state.pop(key, None)
        st.session_state[PREFIX + "context"] = context
    if allowed_packs is not None and pack not in allowed_packs:
        st.error("This product is outside your current access.")
        return None
    writable = local_demo is True and can_write is True
    st.caption("Move reviewed clinical meaning into a reusable library candidate, then let each product decide how to adopt a version. Study and delivery choices remain separate.")
    if params.get("review_id"):
        shared = backend.shared(root, pack, params["review_id"], allowed_packs=allowed_packs)
        _errors(shared)
        if not shared["ok"]:
            return None
        _candidate(shared["record"], stale=shared["stale"])
        return _integration(root, pack, actor_id, params["review_id"], shared["record"], allowed_packs=allowed_packs,
                            local_demo=local_demo, can_review=can_review, can_manage_library=can_manage_library)
    if params.get("proposal_id"):
        current = backend.read(root, pack, actor_id, params["proposal_id"], allowed_packs=allowed_packs)
        _errors(current)
        if not current["ok"]:
            return None
        if current.get("review_id"):
            return {"route": backend.ROUTE, "params": {"review_id": current["review_id"]}}
        record = current["record"]
        _candidate(record, stale=current["stale"])
        if not current["stale"]:
            with st.form(PREFIX + "share"):
                owner = st.selectbox("Who should review the library candidate?", ["Reviewer", "Science", "Engineering", "Administrator"], key=PREFIX + "owner")
                note = form_help.field(st.text_area, "What should the library steward examine?", key=PREFIX + "review_note",
                                    help="Describe the reusable clinical meaning, limits and proposed version change. This request does not record approval.", binding=record["sha256"])
                sent = st.form_submit_button("Share exact candidate for review", disabled=not writable, key=PREFIX + "share_button")
            if sent:
                with st.spinner("Rechecking the exact candidate before sharing it…"):
                    shared = backend.share(root, pack, actor_id, record["id"], expected_digest=record["sha256"],
                        note=note, owner=owner, allowed_packs=allowed_packs, local_demo=local_demo, can_write=can_write)
                _errors(shared)
                if shared["ok"]:
                    return {"route": "handoffs", "params": {"handoff_id": shared["handoff"]["id"]}, "changed": True}
        if st.button("Check readiness for a new candidate", key=PREFIX + "new"):
            return {"route": backend.ROUTE, "params": {}}
        return None
    if st.button("Check library readiness again", key=PREFIX + "refresh"):
        st.session_state.pop(PREFIX + "report", None)
    if PREFIX + "report" not in st.session_state:
        with st.spinner("Checking template rulings, approval evidence and committed provenance…"):
            st.session_state[PREFIX + "report"] = backend.describe(root, pack, actor_id, allowed_packs=allowed_packs)
    report = st.session_state[PREFIX + "report"]
    _errors(report)
    if not report["ok"]:
        return None
    st.markdown("**1 · What this product can contribute**")
    rows = report.get("confirmed") or []
    if rows:
        st.dataframe([{"Variable": row["variable_id"], "Reusable concept": row["slot"],
                       "Recorded ruling": row["relation"]} for row in rows], hide_index=True, width="stretch")
    else:
        st.info("No current confirmed ruling states that a product row realises a reusable concept. Review the proposed concept against the actual scientific row first.")
    if report["blockers"]:
        st.warning("This product is not ready to prepare a library candidate.")
        with st.expander("What must be completed first", expanded=True):
            for blocker in report["blockers"]:
                st.write(blocker)
        if st.button("Review this row's reusable concept", key=PREFIX + "template"):
            return {"route": "template_review", "params": {key: params[key] for key in ("variable", "item_id") if params.get(key)}}
        if st.button("Review clinical meaning and its evidence", key=PREFIX + "clinical"):
            return {"route": "clinical_standards", "params": {key: params[key] for key in ("variable", "item_id") if params.get(key)}}
        if st.button("Open the required scientific review step", key=PREFIX + "progress"):
            return {"route": "progress", "params": {"action_id": "g2_approve"}}
        import handoffs_page
        handoffs_page.ask(root, pack, {"id": "template-library-prerequisites", "label": "Complete template-library prerequisites"},
            {"owner": "Science"}, actor_id, local_demo=local_demo, can_view=can_write,
            allowed_packs=allowed_packs, key="template_library")
    else:
        st.success("The existing prerequisite checks passed for preparing a candidate. This does not publish or authenticate a release.")
        with st.form(PREFIX + "candidate"):
            template_id = form_help.field(st.text_input, "Proposed template ID", key=PREFIX + "id", placeholder="prostate_performance_status",
                                        help="Use a stable lower-case library identity. Do not overwrite an existing version.", binding=report["input_digest"])
            version = form_help.field(st.text_input, "Proposed version", key=PREFIX + "version", placeholder="1.0.0", binding=report["input_digest"])
            reviewer = st.text_input("Who actually reviewed this library recommendation?", key=PREFIX + "reviewer")
            date = st.text_input("Date of that review", key=PREFIX + "date", placeholder="YYYY-MM-DD")
            reason = form_help.field(st.text_area, "Reusable meaning, limitations and version change", key=PREFIX + "reason", binding=report["input_digest"])
            st.caption("Enter actual review attribution only. Typed names do not authenticate an approval, and no name or date is filled for you.")
            submitted = st.form_submit_button("Validate and save private candidate", disabled=not writable, key=PREFIX + "stage")
        if submitted:
            with st.spinner("Validating the exact candidate against immutable source evidence…"):
                saved = backend.stage(root, pack, actor_id, values={"template_id": template_id, "version": version,
                    "reviewed_by": reviewer, "date": date, "reason": reason}, expected_digest=report["input_digest"],
                    allowed_packs=allowed_packs, local_demo=local_demo, can_write=can_write)
            _errors(saved)
            if saved["ok"]:
                return {"route": backend.ROUTE, "params": {"proposal_id": saved["record"]["id"]}, "changed": True}
    st.markdown("**2 · Available versions and this product's adoption**")
    if not report.get("releases"):
        st.info("No validated template release with accessible source evidence is available. A private candidate becomes reusable only after the library steward accepts and commits it.")
    for release in report.get("releases") or []:
        doc = release["document"]
        with st.expander(doc["template_id"] + " @ " + doc["version"] + " · " + doc["lifecycle"]["status"]):
            st.caption("Source: " + doc["source"]["pack"])
            if not release.get("committed"):
                st.warning("This validated record is only in the working library. Its governed commit is still required before adoption review can continue.")
            st.dataframe([{"Concept": c["slot"], "Meaning": c.get("definition")} for c in doc["concepts"]], hide_index=True, width="stretch")
            st.write("Product-specific choices: " + ", ".join(doc.get("excludes") or []))
            for notice in release["notices"]:
                st.info(notice)
            st.download_button("Download this template record", json.dumps(doc, indent=2),
                file_name=doc["template_id"] + "-" + doc["version"] + ".json", mime="application/json",
                key=PREFIX + "release_" + doc["template_id"] + "_" + doc["version"])
    for finding in report.get("library_findings") or []:
        st.warning(finding)
    adoption = report.get("adoption") or {}
    if adoption.get("adopts"):
        st.dataframe(adoption["adopts"], hide_index=True, width="stretch")
    else:
        st.caption("This product has not recorded a versioned template adoption. No adoption is inferred from similar variable names.")
    for finding in report.get("adoption_findings") or []:
        st.warning(finding)
    for notice in report.get("adoption_notices") or []:
        st.info(notice)
    if any(row.get("committed") for row in report.get("releases") or []):
        st.caption("Adoption changes published meaning. Record an explicit inherited, adapted, diverged or deferred disposition, named person and date in handoff/TEMPLATE_ADOPTION.yaml; the steward must run template_promote.adoption_errors. This page does not install that governed record.")
        if st.button("Compare the meaning before proposing adoption", key=PREFIX + "reuse"):
            return {"route": "definition_reuse", "params": {key: params[key] for key in ("variable", "item_id") if params.get(key)}}
    return None
