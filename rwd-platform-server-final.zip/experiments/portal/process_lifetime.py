"""Owned process groups shared by the local portal runner and Claude Code bridge.

The fixed guard accepts no shell program. It waits for ownership before launching
the original argv and keeps a parent lifeline open until the entire run ends.
Windows job handles are deliberately not inherited by descendants.
"""
from __future__ import annotations

import os
from pathlib import Path
import signal
import subprocess
import sys


def _guard_executable():
    if os.name != "nt":
        return sys.executable
    # Windows venv python.exe is a redirector: it can spawn the interpreter
    # before we attach its process to the job. The guard must start directly in
    # the actual native interpreter, then run no site hooks before activation.
    import ctypes
    from ctypes import wintypes
    kernel = ctypes.WinDLL("kernel32", use_last_error=True)
    kernel.GetModuleFileNameW.argtypes = [wintypes.HMODULE, wintypes.LPWSTR, wintypes.DWORD]
    kernel.GetModuleFileNameW.restype = wintypes.DWORD
    buffer = ctypes.create_unicode_buffer(32768)
    count = kernel.GetModuleFileNameW(None, buffer, len(buffer))
    candidate = getattr(sys, "_base_executable", None)
    if not 0 < count < len(buffer) or not isinstance(candidate, str) or not Path(candidate).is_absolute():
        raise OSError("The native Python interpreter identity could not be verified.")
    native, base = Path(buffer.value).resolve(strict=True), Path(candidate).resolve(strict=True)
    if native != base or not base.is_file():
        raise OSError("The native Python interpreter identity could not be verified.")
    return str(base)


class ProcessTree:
    """Closing a Windows job or POSIX group also stops children of an exited parent."""
    def __init__(self):
        self.job = None
        self.process = None
        if os.name == "nt":
            import ctypes
            from ctypes import wintypes

            class IO(ctypes.Structure):
                _fields_ = [(name, ctypes.c_ulonglong) for name in ("read", "write", "other", "read_bytes", "write_bytes", "other_bytes")]

            class Basic(ctypes.Structure):
                _fields_ = [("process_time", ctypes.c_longlong), ("job_time", ctypes.c_longlong), ("flags", wintypes.DWORD),
                            ("min_working_set", ctypes.c_size_t), ("max_working_set", ctypes.c_size_t),
                            ("active_processes", wintypes.DWORD), ("affinity", ctypes.c_size_t),
                            ("priority", wintypes.DWORD), ("scheduling", wintypes.DWORD)]

            class Limits(ctypes.Structure):
                _fields_ = [("basic", Basic), ("io", IO), ("process_memory", ctypes.c_size_t), ("job_memory", ctypes.c_size_t),
                            ("peak_process_memory", ctypes.c_size_t), ("peak_job_memory", ctypes.c_size_t)]

            kernel = ctypes.WinDLL("kernel32", use_last_error=True)
            kernel.CreateJobObjectW.argtypes = [ctypes.c_void_p, wintypes.LPCWSTR]
            kernel.CreateJobObjectW.restype = wintypes.HANDLE
            kernel.SetInformationJobObject.argtypes = [wintypes.HANDLE, ctypes.c_int, ctypes.c_void_p, wintypes.DWORD]
            kernel.SetInformationJobObject.restype = wintypes.BOOL
            kernel.AssignProcessToJobObject.argtypes = [wintypes.HANDLE, wintypes.HANDLE]
            kernel.AssignProcessToJobObject.restype = wintypes.BOOL
            kernel.CloseHandle.argtypes = [wintypes.HANDLE]
            kernel.CloseHandle.restype = wintypes.BOOL
            self.kernel = kernel
            self.job = kernel.CreateJobObjectW(None, None)
            limits = Limits()
            limits.basic.flags = 0x2000  # JOB_OBJECT_LIMIT_KILL_ON_JOB_CLOSE
            if not self.job or not kernel.SetInformationJobObject(self.job, 9, ctypes.byref(limits), ctypes.sizeof(limits)):
                self.close()
                raise OSError("A local process lifetime could not be created.")

    def attach(self, process):
        self.process = process
        if self.job and not self.kernel.AssignProcessToJobObject(self.job, int(process._handle)):
            process.kill()
            raise OSError("A local process could not join its owned lifetime.")

    def close(self):
        if self.job:
            self.kernel.CloseHandle(self.job)
            self.job = None
        elif os.name != "nt" and self.process is not None:
            try:
                os.killpg(self.process.pid, signal.SIGKILL)
            except ProcessLookupError:
                pass
            self.process = None


class GuardedProcess:
    """Popen-compatible result whose target waits for explicit activation."""
    def __init__(self, argv, **options):
        if not isinstance(argv, (list, tuple)) or not argv or options.get("shell") or options.get("stdin") != subprocess.DEVNULL:
            raise ValueError("Owned portal commands need an explicit argv and no interactive input.")
        self.args = argv
        self._tree = ProcessTree()
        self._process = None
        self._lifeline = None
        self._started = False
        try:
            guarded = [_guard_executable(), "-I", "-S", str(Path(__file__).resolve()), "--guard", *map(os.fspath, argv)]
            options = {**options, "stdin": subprocess.PIPE}
            self._process = subprocess.Popen(guarded, **options)
            self._lifeline = self._process.stdin
            # communicate() must drain output without closing the lifetime pipe.
            self._process.stdin = None
            self._tree.attach(self._process)
        except BaseException:
            self.close_tree()
            raise

    def __getattr__(self, name):
        return getattr(self._process, name)

    def start_tree(self):
        if not self._started:
            self._lifeline.write("1" if self._process.text_mode else b"1")
            self._lifeline.flush()
            self._started = True

    def close_tree(self):
        self._tree.close()
        if self._lifeline is not None:
            lifeline = self._lifeline
            self._lifeline = None
            try:
                lifeline.close()
            except (OSError, ValueError):
                # Activation can fail after the guard exits. Closing a buffered
                # pipe retries its failed flush; still finish owned-tree cleanup.
                pass
        if self._process is not None:
            try:
                self._process.wait(timeout=5)
            except subprocess.TimeoutExpired:
                self._process.kill()
                self._process.wait(timeout=5)


def popen(argv, *args, _owned_tree=False, **options):
    """The existing injectable factory; detached workers remain ordinary Popen."""
    if not _owned_tree:
        return subprocess.Popen(argv, *args, **options)
    if args:
        raise ValueError("Owned portal commands use named Popen options.")
    return GuardedProcess(argv, **options)


def _guard(argv):
    # EOF before attachment or activation means the launcher ended. No target ran.
    if os.read(0, 1) != b"1":
        return 126

    if os.name != "nt":
        # This monitor stays alive even if the original command and guard exit
        # while a grandchild still owns their output pipe. It belongs to the
        # same group, holds no output handles, and dies with that group.
        monitor = os.fork()
        if monitor == 0:
            sink = os.open(os.devnull, os.O_WRONLY)
            os.dup2(sink, 1)
            os.dup2(sink, 2)
            os.close(sink)
            while os.read(0, 1):
                pass
            os.killpg(os.getpgrp(), signal.SIGKILL)
            os._exit(130)
    # Windows descendants are already bound to the non-inherited job handle.
    # Closing the worker's handle (including worker death) stops the whole job.
    try:
        command = subprocess.Popen(argv, stdin=subprocess.DEVNULL)
        code = command.wait()
    except OSError as error:
        sys.stderr.write(f"The action could not start ({type(error).__name__}). Your form is retained. Your data expert can check the runtime installation.\n")
        sys.stderr.flush()
        return 126
    if os.name != "nt" and code < 0:
        # Python changes SIGINT and ignores SIGPIPE at startup. Restore native
        # semantics so a signalled target does not become an ordinary exit 243.
        if -code not in {signal.SIGKILL, signal.SIGSTOP}:
            signal.signal(-code, signal.SIG_DFL)
        os.kill(os.getpid(), -code)
    return code


if __name__ == "__main__":
    if len(sys.argv) < 3 or sys.argv[1] != "--guard":
        raise SystemExit(2)
    result = _guard(sys.argv[2:])
    if os.name == "nt":
        # Preserve the command's complete DWORD exit code, including native faults.
        import ctypes
        ctypes.windll.kernel32.ExitProcess(ctypes.c_uint32(result))
    os._exit(result)
