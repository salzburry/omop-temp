"""Edit document metadata without making or authenticating a scientific decision."""
from pathlib import Path

import streamlit as st

import specification_details as details


FIELDS = {
    "document_id": ("Document ID", "Use the document's existing ID, or generate one once for this registered specification."),
    "revision": ("Document revision", "Enter the revision stated in the supplied document."),
    "data_refresh": ("Data refresh or delivery", "Enter the delivery or data cut covered by this specification."),
    "rwb_qc_reference": ("Specification QC reference", "Enter the ID or link for the record of scientific quality checks on this specification, such as its reviewed findings report. A general website is not a QC review record."),
}


def clear():
    for key in list(st.session_state):
        if str(key).startswith("spec_details_"):
            st.session_state.pop(key, None)


def render(root, pack, actor_id, *, local_demo, can_write, can_view):
    """Return True only after a verified save; retain input on every refused save."""
    context = (str(Path(root).resolve()), pack, actor_id)
    cached = st.session_state.get("spec_details_snapshot")
    if not cached or cached["context"] != context:
        clear()
        description = details.describe(root, pack, allowed_packs=[pack])
        st.session_state["spec_details_snapshot"] = {"context": context, "description": description}
    else:
        description = cached["description"]
    st.write("**Specification details**")
    st.caption("Save the details you know. Leave unknown fields blank. The document ID is reusable; generating it does not approve the specification.")
    if not description.get("ok"):
        for error in description.get("errors") or ["The specification details could not be read."]:
            st.warning(str(error))
        if st.button("Reload specification details", key="spec_details_reload"):
            clear()
            st.rerun()
        return False
    enabled = local_demo and can_write and can_view
    if not enabled:
        st.info("Saving document details is available to product authors in a local demo. Your data expert can update this record in a hosted session.")
    values = description.get("values") or {}
    for field in FIELDS:
        st.session_state.setdefault(f"spec_details_{field}", str(values.get(field) or ""))

    saved = False
    if not values.get("document_id"):
        if st.button("Generate and save document ID", key="spec_details_generate", disabled=not enabled):
            result = details.save(root, pack, {"document_id": details.suggest_document_id(description)},
                                  expected_digest=description["digest"], local_demo=local_demo,
                                  can_write=can_write and can_view, allowed_packs=[pack])
            if result.get("ok"):
                description = result
                st.session_state["spec_details_snapshot"]["description"] = result
                st.session_state["spec_details_document_id"] = result["values"]["document_id"]
                st.success("Document ID saved. Keep this ID when you return to this specification.")
                saved = True
            else:
                for error in result.get("errors") or ["The document ID could not be saved."]:
                    st.error(str(error))
    else:
        st.caption("A document ID is already saved. You do not need to generate another one.")
    st.caption("Blank fields keep any previously saved value.")

    # Individual inputs reach session state before an ID-generation click. A form
    # would keep its unsent draft in the browser while the separate button reruns.
    for field, (label, help_text) in FIELDS.items():
        st.text_input(label, key=f"spec_details_{field}", help=help_text, disabled=not enabled)
    submit = st.button("Save specification details", key="spec_details_save", disabled=not enabled, type="primary")
    if submit:
        updates = {field: st.session_state.get(f"spec_details_{field}", "") for field in FIELDS}
        result = details.save(root, pack, updates, expected_digest=description["digest"],
                              local_demo=local_demo, can_write=can_write and can_view, allowed_packs=[pack])
        if result.get("ok"):
            st.session_state["spec_details_snapshot"]["description"] = result
            if result.get("changed"):
                st.success("Specification details saved. The review decision and its authentication are separate requirements.")
                saved = True
            else:
                st.info("No changes to save. Blank fields keep the saved value.")
        else:
            for error in result.get("errors") or ["The details could not be saved."]:
                st.error(str(error))
    if st.button("Reload saved details", key="spec_details_reload", help="Discard unsaved entries and read the current file."):
        clear()
        st.rerun()
    return saved
