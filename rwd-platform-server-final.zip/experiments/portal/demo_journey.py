"""Isolated, resumable rehearsals using the existing specification and build workers.

Only shipped synthetic examples are accepted. A rehearsal never registers a product,
records an approval, modifies a source fixture, or creates release evidence.
"""
from __future__ import annotations

import hashlib
import importlib.util
import io
import json
import os
import re
import shutil
import subprocess
import sys
import time
import uuid
import zipfile
from datetime import datetime, timezone
from pathlib import Path

import yaml

EXAMPLES = {
    "gist": {"label": "GIST mock specification", "pack": "fixtures/oncology/gist/202608",
             "workbook": "fixtures/oncology/gist/202608/prog_spec/reference/PROG_SPEC_RWDP_GIST_MOCK_202608.xlsx",
             "note": "Includes deliberate date and duplicate-variable defects so you can review real QC findings."},
    "bladder": {"label": "Bladder example template", "pack": "sandbox/demo_walkthrough/bladder/202609",
                "workbook": "sandbox/demo_walkthrough/bladder_202609_program_spec.xlsx",
                "note": "Includes an example ECOG definition and an executable demonstration configuration."},
}
JOURNEYS = {"new": "Start a new example draft", "template": "Reuse an example template",
            "revise": "Plan section and source changes"}
SECTIONS = ["study_period", "study_population", "demographics", "clinical", "treatment", "outcomes"]
OUTPUTS = ["extracted.json", "lint.json", "scaffold.json", "SPEC_FINDINGS.txt", "COVERAGE.md",
           "SCAFFOLDED_RECORDS.md", "ENUMERATION_CANDIDATES.yaml"]
NOTICE = ("Synthetic draft rehearsal only. Generated definitions and QC findings require review. "
          "Proposed section, definition and source changes are not executable changes. "
          "This run is not an approved product, a release, or evidence about delivered patient data.")


def _sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def _now():
    return datetime.now(timezone.utc).isoformat()


def _error(message):
    return {"ok": False, "errors": [str(message)]}


def _canonical(path, within=None):
    expected = Path(path).absolute()
    actual = expected.resolve()
    if actual != expected:
        raise ValueError("The rehearsal location redirects elsewhere. Choose a separate local workspace.")
    if within is not None:
        actual.relative_to(Path(within).resolve())
    return actual


def _owner(actor_id):
    if not isinstance(actor_id, str) or not actor_id.strip() or len(actor_id) > 300:
        raise ValueError("Choose your portal identity before starting a rehearsal.")
    return hashlib.sha256(actor_id.encode("utf-8")).hexdigest()[:24]


def _base(root, state_root=None):
    root = Path(root).resolve()
    default = Path(os.environ.get("LOCALAPPDATA") or Path.home()) / "RWDPortal" / "rehearsals"
    path = _canonical(state_root or os.environ.get("RWDP_DEMO_DIR") or default)
    if path == root or root in path.parents:
        raise ValueError("Rehearsals must be stored outside the repository. Set RWDP_DEMO_DIR to a separate local folder.")
    return path


def _folder(root, state_root, actor_id, run_id):
    if not isinstance(run_id, str) or not re.fullmatch(r"[0-9a-f]{32}", run_id):
        raise ValueError("Choose a saved rehearsal from your list.")
    base = _base(root, state_root)
    return _canonical(base / _owner(actor_id) / run_id, base)


def _json(path, value):
    _canonical(path)
    temporary = path.with_name(path.name + ".tmp")
    _canonical(temporary, path.parent)
    temporary.write_text(json.dumps(value, indent=2, ensure_ascii=False), encoding="utf-8")
    os.replace(temporary, path)


def _read(path):
    _canonical(path)
    if path.stat().st_size > 4 * 1024 * 1024:
        raise ValueError("This rehearsal record is too large to read safely.")
    value = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise ValueError("The saved rehearsal needs repair.")
    return value


def catalogue(root):
    """The two shipped test inputs, not a discovery walk through user documents."""
    result = []
    for identifier, example in EXAMPLES.items():
        item = {"id": identifier, **example, "available": False}
        try:
            pack = _canonical(Path(root) / example["pack"], root)
            workbook = _canonical(Path(root) / example["workbook"], root)
            item["available"] = workbook.is_file() and (pack / "config/data_product.yaml").is_file()
        except (OSError, ValueError):
            pass
        result.append(item)
    return result


def runtime():
    """Inspect dependencies; never install a runtime or claim a Spark build ran."""
    java = shutil.which("java")
    if not java and os.environ.get("JAVA_HOME"):
        candidate = Path(os.environ["JAVA_HOME"]) / "bin" / ("java.exe" if os.name == "nt" else "java")
        java = str(candidate) if candidate.is_file() else None
    if not java:
        # Use the same user-folder discovery as local_smoke, without installing
        # Java or changing the Streamlit server's process environment.
        sys.path.insert(0, str(Path(__file__).resolve().parents[2] / "platform/tools"))
        import java_home
        java = java_home.discover() or None
    try:
        spark = importlib.util.find_spec("pyspark") is not None
    except (ImportError, ValueError):
        spark = False
    return {"build_available": bool(java and spark),
            "build_reason": "The optional synthetic ADS build needs PySpark and Java 17 or 21 in the portal runtime. "
                            "Your administrator can enable them; specification extraction, QC and planning work without Spark." if not (java and spark) else
                            "The synthetic ADS worker is available. The run must still finish successfully before a result is shown."}


def _copy_inputs(source, destination):
    for name in ("config", "variables", "codelists"):
        directory = source / name
        if not directory.is_dir():
            continue
        for current, dirs, files in os.walk(directory, followlinks=False):
            dirs[:] = [d for d in dirs if not d.startswith(".") and not (Path(current) / d).is_symlink()]
            for filename in files:
                original = _canonical(Path(current) / filename, source)
                if original.suffix.lower() not in {".yaml", ".yml", ".csv", ".tsv"} or original.name.startswith("."):
                    continue
                if original.stat().st_size > 4 * 1024 * 1024:
                    raise ValueError("A shipped example input is unexpectedly large.")
                target = destination / original.relative_to(source)
                target.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(original, target)


def _describe_copy(product, example, inputs):
    """Use the existing contract parser on an allowlisted, isolated example copy.

    Product navigation deliberately rejects sandbox paths. Do not loosen that
    boundary just to reuse the pure dependency/impact checker for a rehearsal.
    """
    import design_workspace
    contract = product / "handoff/FUNCTIONAL_CONTRACT.md"
    rows = []
    for row in design_workspace.cl.typed_records(design_workspace.cl.read(str(contract)), keep_unnamed=True):
        rows.append({"variable_id": row.variable_id,
                     "domain": row.spec_refs[0].domain if row.spec_refs else "other",
                     "definition": row.cells.get("required_rule", ""),
                     "depends_on": [str(dep) for dep in row.depends_on if str(dep).strip() != "none"]})
    config = yaml.safe_load((product / "config/data_product.yaml").read_text(encoding="utf-8")) or {}
    return {"pack": example["pack"], "name": example["label"], "is_reference": True,
            "rows": rows, "contract_sha256": _sha(contract),
            "baseline_sha256": hashlib.sha256(json.dumps(inputs, sort_keys=True).encode()).hexdigest(),
            "source": {"vendor": config.get("vendor", "flatiron"), "modality": config.get("modality", "ehr")},
            "source_tables": config.get("sources") or {}, "errors": [],
            "warnings": ["This example is synthetic; its definitions are not approved scientific requirements."]}


def _draft_contract(source, destination):
    import design_workspace
    records = []
    for row in design_workspace.cl.typed_records(design_workspace.cl.read(str(source)), keep_unnamed=True):
        cells = dict(row.cells)
        cells.update(status={"requirement": "draft", "source": "unverified",
                             "implementation": "not_implemented", "validation": "not_run"},
                     decision_ids=[], gap_ids=[])
        records.append(cells)
    text = "# Synthetic rehearsal draft\n\nLiteral example definitions are reused for review. No approvals or decision records are carried forward.\n\n"
    if records:
        text += design_workspace.cl.render_table(records) + "\n"
    destination.write_text(text, encoding="utf-8")


def prepare(root, state_root, actor_id, *, journey, example_id, label, purpose, studies=(),
            sections=None, additions=(), proposed_source="flatiron", proposed_modality="ehr",
            local_demo=False, can_write=False):
    """Create a new isolated draft, leaving every existing rehearsal and product intact."""
    if not local_demo or not can_write:
        return _error("Starting a rehearsal requires product-author access in a local demo.")
    try:
        if journey not in JOURNEYS or example_id not in EXAMPLES:
            raise ValueError("Choose a supported journey and shipped synthetic example.")
        if not str(label).strip() or len(str(label)) > 120 or not str(purpose).strip():
            raise ValueError("Name the rehearsal and describe the study question you want to explore.")
        sections = SECTIONS[:] if sections is None else list(sections)
        if not set(sections).issubset(SECTIONS) or len(sections) != len(set(sections)):
            raise ValueError("Choose each proposed section once from the example list.")
        if len(str(purpose)) > 4000 or len(additions) > 30 or len(studies) > 30:
            raise ValueError("Keep this rehearsal to a short study question and at most 30 proposals or studies.")
        if not str(proposed_source).strip() or proposed_modality not in {"ehr", "claims"}:
            raise ValueError("Name the proposed source and choose EHR or claims.")
        if any(not isinstance(item, dict) or not all(isinstance(item.get(field), str) and item[field].strip()
                   for field in ("variable_id", "domain", "definition")) for item in additions):
            raise ValueError("Each proposed addition needs a section, identifier and literal definition.")
        source = _canonical(Path(root) / EXAMPLES[example_id]["pack"], root)
        workbook = _canonical(Path(root) / EXAMPLES[example_id]["workbook"], root)
        source_doc = yaml.safe_load((source / "source_refs.yaml").read_text(encoding="utf-8"))
        material = next(m for m in source_doc["source_materials"] if m["material_type"] == "program_spec")
        if _sha(workbook) != material.get("sha256"):
            raise ValueError("The shipped example workbook differs from its registered checksum. Ask your administrator to restore the test input.")
        run_id = uuid.uuid4().hex
        folder = _folder(root, state_root, actor_id, run_id)
        folder.mkdir(parents=True)
        product = folder / "example" / source.parent.name / source.name
        product.mkdir(parents=True)
        _copy_inputs(source, product)
        (product / "spec_pipeline").mkdir(exist_ok=True)
        shutil.copy2(_canonical(source / "spec_pipeline/pipeline.conf", source), product / "spec_pipeline/pipeline.conf")
        (product / "prog_spec").mkdir()
        copied_workbook = product / "prog_spec" / workbook.name
        shutil.copy2(workbook, copied_workbook)
        # Copy source identity and its existing access declaration, never approval or ledger identity.
        material = dict(material)
        for field in ("approved_by", "approval_date", "object_uuid"):
            material.pop(field, None)
        material.update(path_or_link=str(copied_workbook), status="pending", why_provisional=NOTICE)
        (product / "source_refs.yaml").write_text(yaml.safe_dump(
            {"product": source.parent.name, "spec_version": source.name, "source_materials": [material]}, sort_keys=False), encoding="utf-8")
        (product / "handoff").mkdir()
        contract = source / "handoff/FUNCTIONAL_CONTRACT.md"
        if journey != "new" and contract.is_file():
            _draft_contract(_canonical(contract, source), product / "handoff/FUNCTIONAL_CONTRACT.md")
        else:
            (product / "handoff/FUNCTIONAL_CONTRACT.md").write_text("# Synthetic rehearsal draft\n\nNo scientific requirements are approved.\n", encoding="utf-8")
        # These are the same explicit synthetic run bindings used by local_smoke.py.
        bindings = yaml.safe_load((product / "config/pipeline.yaml").read_text(encoding="utf-8")) or {}
        bindings.setdefault("run", {}).update(refresh="synthetic", source_schema="synthetic", output_schema="synthetic")
        (product / "config/pipeline.yaml").write_text(yaml.safe_dump(bindings, sort_keys=False), encoding="utf-8")
        inputs = {p.relative_to(folder).as_posix(): _sha(p) for p in product.rglob("*") if p.is_file()}
        plan = {"journey": journey, "purpose": str(purpose).strip(), "studies": list(studies),
                "retained_sections": sections, "removed_sections": [s for s in SECTIONS if s not in sections],
                "proposed_additions": list(additions), "proposed_source": proposed_source,
                "proposed_modality": proposed_modality, "applied_to_execution": False,
                "execution_scope": "The shipped example's baseline configuration and synthetic specification.", "notice": NOTICE}
        if journey == "revise":
            import design_workspace
            described = _describe_copy(product, EXAMPLES[example_id], inputs)
            retained = [row["variable_id"] for row in described["rows"] if row["domain"] in sections]
            plan["definition_review"] = design_workspace.build_plan(described, retained, additions, purpose, studies,
                                                                      proposed_source, proposed_modality)
        _json(folder / "plan.json", plan)
        record = {"schema_version": 1, "id": run_id, "owner": _owner(actor_id), "repository": str(Path(root).resolve()),
                  "label": str(label).strip(), "journey": journey, "example_id": example_id, "example": EXAMPLES[example_id],
                  "created_at": _now(), "stage": "prepared", "product": product.relative_to(folder).as_posix(),
                  "input_sha256": inputs, "plan": plan, "steps": [], "source_mode": "synthetic", "releasable": False}
        _json(folder / "rehearsal.json", record)
        return {"ok": True, "run": record, "errors": []}
    except (OSError, ValueError, TypeError, KeyError, StopIteration, yaml.YAMLError) as error:
        return _error(error)


def _completion_binding(folder, record):
    """Bind draft-worker success to this saved plan, exact inputs and review artifacts."""
    import demo_revisions
    product = demo_revisions._tracked_inputs(folder, record)
    if _read(_canonical(folder / "plan.json", folder)) != record["plan"]:
        raise ValueError("The saved rehearsal plan changed. Reopen an unchanged rehearsal before continuing.")
    outputs = {}
    for name in OUTPUTS:
        path = _canonical(product / "spec_pipeline/out" / name, folder)
        if path.stat().st_size > 4 * 1024 * 1024:
            raise ValueError("A saved review artifact exceeds the rehearsal limit.")
        outputs[name] = _sha(path)
    # An optional ADS has its own existing receipt. Its later result must not
    # invalidate the completed specification checks or imply they tested an ADS.
    report = {key: value for key, value in record["report"].items()
              if key not in {"synthetic_ads", "build_summary", "build_artifact_sha256", "build_scope"}}
    return {"inputs": demo_revisions._digest(record["input_sha256"]),
            "plan": demo_revisions._digest(record["plan"]),
            "report": demo_revisions._digest(report), "outputs": outputs}


def read_run(root, state_root, actor_id, run_id):
    try:
        folder = _folder(root, state_root, actor_id, run_id)
        record = _read(_canonical(folder / "rehearsal.json", folder))
        if record.get("owner") != _owner(actor_id) or record.get("repository") != str(Path(root).resolve()):
            raise ValueError("This rehearsal belongs to another user or checkout.")
        if (record.get("id") != run_id or record.get("journey") not in JOURNEYS or record.get("example_id") not in EXAMPLES
                or record.get("stage") not in {"prepared", "running", "needs_attention", "complete"}
                or not isinstance(record.get("label"), str) or not isinstance(record.get("created_at"), str)
                or not isinstance(record.get("plan"), dict) or not isinstance(record.get("steps"), list)
                or not isinstance(record.get("input_sha256"), dict) or not record["input_sha256"]):
            raise ValueError("This saved rehearsal record is incomplete. Start another example or ask your administrator to restore it.")
        example = EXAMPLES[record["example_id"]]
        expected = "example/" + "/".join(Path(example["pack"]).parts[-2:])
        if (record.get("product") != expected or not isinstance(record.get("example"), dict)
                or any(record["example"].get(key) != example[key] for key in ("pack", "workbook"))):
            raise ValueError("This rehearsal no longer describes its original shipped example.")
        record["example"] = example
        plan = record["plan"]
        if (not all(isinstance(plan.get(key), str) for key in ("purpose", "proposed_source", "proposed_modality"))
                or not all(isinstance(plan.get(key), list) for key in ("studies", "retained_sections", "removed_sections", "proposed_additions"))
                or any(not isinstance(item, str) for key in ("studies", "retained_sections", "removed_sections") for item in plan[key])
                or any(not isinstance(item, dict) for item in plan["proposed_additions"])
                or ("definition_review" in plan and not isinstance(plan["definition_review"], dict))
                or any(not isinstance(step, dict) or not all(key in step for key in ("title", "exit_code", "output")) for step in record["steps"])):
            raise ValueError("The saved plan or run details are unreadable. Start another rehearsal.")
        if "revision_of" in record:
            if (not isinstance(record["revision_of"], str) or not re.fullmatch(r"[0-9a-f]{32}", record["revision_of"])
                    or not isinstance(record.get("parent_sha256"), str) or not re.fullmatch(r"[0-9a-f]{64}", record["parent_sha256"])
                    or type(record.get("revision_number")) is not int or record["revision_number"] < 1
                    or type(plan.get("draft_interpretations_applied")) is not bool
                    or not isinstance(plan.get("definition_changes"), list)
                    or any(not isinstance(item, dict) or not all(isinstance(item.get(key), str)
                        for key in ("key", "variable_id", "domain", "origin", "before", "after")) for item in plan["definition_changes"])
                    or not isinstance(plan.get("engineering_handoff"), list)
                    or any(not isinstance(item, dict) or not all(isinstance(item.get(key), str)
                        for key in ("kind", "detail")) for item in plan["engineering_handoff"])):
                raise ValueError("The saved draft revision is incomplete. Open its original rehearsal or ask your administrator to restore it.")
        if record["stage"] == "complete":
            report = record.get("report")
            if (not isinstance(report, dict) or not all(isinstance(report.get(key), int) for key in ("specification_rows", "artifact_count", "high_findings"))
                    or not isinstance(report.get("findings"), list) or not all(isinstance(item, dict) for item in report["findings"])
                    or report.get("source_mode") != "synthetic" or report.get("releasable") is not False):
                raise ValueError("The saved result is incomplete. No successful result can be shown.")
            if "revision_of" in record and (
                    report.get("draft_contract_check") not in {"passed", "needs_attention"}
                    or not isinstance(report.get("draft_contract_findings"), str)
                    or type(report.get("draft_interpretations_applied")) is not bool
                    or type(report.get("definition_change_count")) is not int or report["definition_change_count"] < 0):
                raise ValueError("The saved revision checks are incomplete. No current draft result can be shown.")
            if report.get("synthetic_ads") == "built":
                import demo_build
                demo_build.validate_saved(root, folder, record)
            # Changed saved inputs are refused, never silently rebound to an old
            # success. Missing/changed outputs can be recreated by an explicit run.
            import demo_revisions
            demo_revisions._tracked_inputs(folder, record)
            if _read(_canonical(folder / "plan.json", folder)) != plan:
                raise ValueError("The saved rehearsal plan changed. Reopen an unchanged rehearsal before continuing.")
            try:
                current = _completion_binding(folder, record)
                fresh = (record.get("completion_binding") == current
                         and _read(_canonical(folder / "qc-report.json", folder)) == report)
            except (OSError, ValueError, TypeError):
                fresh = False
            if not fresh:
                # Reading never rewrites a historical record or deletes its files.
                # The returned view deliberately cannot display/download old success
                # as current evidence. execute() can regenerate the same saved inputs.
                record.update(stage="needs_attention", result_recheck_required=True,
                    error="The saved result is not bound to the current review artifacts. Choose Run rehearsal to check this saved version again. Earlier artifacts are retained as unverified history.")
                for key in ("report", "completed_at", "completion_binding"):
                    record.pop(key, None)
                return {"ok": True, "run": record, "errors": []}
        return {"ok": True, "run": record, "errors": []}
    except (OSError, ValueError, TypeError, KeyError, RecursionError, yaml.YAMLError) as error:
        return _error(error)


def list_runs(root, state_root, actor_id):
    try:
        owner = _canonical(_base(root, state_root) / _owner(actor_id))
        if not owner.is_dir():
            return []
        runs = []
        for path in sorted(owner.iterdir(), key=lambda p: p.name):
            if re.fullmatch(r"[0-9a-f]{32}", path.name):
                value = read_run(root, state_root, actor_id, path.name)
                if value["ok"]:
                    runs.append(value["run"])
        return sorted(runs, key=lambda r: r["created_at"], reverse=True)[:100]
    except (OSError, ValueError, TypeError):
        return []


def execute(root, state_root, actor_id, run_id, *, local_demo=False, can_write=False, include_build=False):
    """Run existing CLI workers; only successful, checked output becomes a completed rehearsal."""
    if not local_demo or not can_write:
        return _error("Running a rehearsal requires product-author access in a local demo.")
    loaded = read_run(root, state_root, actor_id, run_id)
    if not loaded["ok"]:
        return loaded
    record = loaded["run"]
    if record["stage"] == "complete":
        return loaded
    lock_fd = None
    try:
        folder = _folder(root, state_root, actor_id, run_id)
        lock = folder / ".running"
        try:
            # All worker timeouts together are below 15 minutes. A lock older than
            # 20 minutes is from an interrupted portal session and may be retried.
            if lock.exists() and time.time() - lock.stat().st_mtime > 1200:
                _canonical(lock, folder).unlink()
            lock_fd = os.open(lock, os.O_CREAT | os.O_EXCL | os.O_WRONLY)
        except FileExistsError:
            raise ValueError("This rehearsal is already running. Reopen its saved result when the run finishes; an interrupted run can be retried after 20 minutes.") from None
        product = _canonical(folder / record["product"], folder)
        # Retry never follows a link planted in a generated-output directory.
        for existing in product.rglob("*"):
            _canonical(existing, folder)
        for relative, digest in record["input_sha256"].items():
            if _sha(_canonical(folder / relative, folder)) != digest:
                raise ValueError("A prepared example input changed. Start a new rehearsal to preserve what each run tested.")
        import demo_revisions
        demo_revisions._tracked_inputs(folder, record)
        if _read(_canonical(folder / "plan.json", folder)) != record["plan"]:
            raise ValueError("The saved rehearsal plan changed. Reopen an unchanged rehearsal before continuing.")
        record.pop("error", None)
        for key in ("report", "completed_at", "completion_binding", "result_recheck_required"):
            record.pop(key, None)
        record.update(stage="running", steps=[], started_at=_now())
        _json(folder / "rehearsal.json", record)
        jobs = [("Extract specification and prepare review artifacts", "platform/tools/run_spec_pipeline.py", [str(product)], 180)]
        if record.get("revision_of"):
            jobs.append(("Check revised draft contract", "platform/tools/contract_lint.py", [str(product)], 60))
        jobs.append(("Check example configuration", "platform/engine/validate.py", [str(product), "--strict"], 60))
        build = runtime()
        for title, worker, args, timeout in jobs:
            try:
                result = subprocess.run([sys.executable, str(_canonical(Path(root) / worker, root)), *args], cwd=root,
                                        capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=timeout,
                                        env={**os.environ, "PYTHONUTF8": "1"})
                code, output = result.returncode, ((result.stdout or "") + (result.stderr or ""))[-60000:]
            except subprocess.TimeoutExpired:
                code, output = 124, "The worker exceeded its time limit. No successful result is claimed. Retry or share the report with your administrator."
            except OSError as error:
                code, output = 126, f"The worker could not start: {type(error).__name__}. Ask your administrator to check the portal runtime."
            record["steps"].append({"title": title, "worker": worker, "exit_code": code, "output": output})
            _json(folder / "rehearsal.json", record)
            if code and worker != "platform/tools/contract_lint.py":
                raise ValueError(f"{title} needs attention. Your plan and diagnostic output were retained.")
        out = product / "spec_pipeline/out"
        extracted, lint = _read(out / "extracted.json"), _read(out / "lint.json")
        if not isinstance(extracted.get("rows"), list) or not extracted["rows"] or not all((out / name).is_file() for name in OUTPUTS):
            raise ValueError("The worker did not produce the expected specification artifacts. No successful result is claimed.")
        findings = lint.get("findings")
        if not isinstance(findings, list) or not all(isinstance(item, dict) for item in findings):
            raise ValueError("The generated QC findings are unreadable.")
        report = {"title": "Synthetic draft rehearsal", "source_mode": "synthetic", "releasable": False,
                  "specification_rows": len(extracted["rows"]), "findings": findings,
                  "high_findings": sum(f.get("severity") == "HIGH" for f in findings),
                  "artifact_count": len(OUTPUTS), "configuration_check": "passed",
                  "synthetic_ads": "not_requested" if not include_build or build["build_available"] else "unavailable",
                  "build_reason": build["build_reason"], "proposal_changes_applied": False, "notice": NOTICE}
        if record.get("revision_of"):
            contract_step = next(step for step in record["steps"] if step["worker"] == "platform/tools/contract_lint.py")
            report.update(draft_contract_check="passed" if contract_step["exit_code"] == 0 else "needs_attention",
                draft_contract_findings=contract_step["output"] if contract_step["exit_code"] else "",
                draft_interpretations_applied=bool(
                record["plan"].get("draft_interpretations_applied")),
                definition_change_count=len(record["plan"].get("definition_changes", [])))
        _json(folder / "qc-report.json", report)
        record.update(stage="complete", completed_at=_now(), report=report)
        record["completion_binding"] = _completion_binding(folder, record)
        _json(folder / "rehearsal.json", record)
        if include_build and build["build_available"]:
            # The optional build owns its own attempt and lock. A failed Spark
            # run must not erase successfully completed specification checks.
            os.close(lock_fd)
            lock.unlink(missing_ok=True)
            lock_fd = None
            import demo_build
            return demo_build.build(root, state_root, actor_id, run_id,
                                    local_demo=local_demo, can_write=can_write)
        return {"ok": True, "run": record, "errors": []}
    except (OSError, ValueError, TypeError, KeyError, RecursionError, yaml.YAMLError) as error:
        if lock_fd is not None:
            record.pop("report", None)
            record.pop("completed_at", None)
            record.pop("completion_binding", None)
            record.update(stage="needs_attention", error=str(error))
            _json(folder / "rehearsal.json", record)
        return {"ok": False, "run": record, "errors": [str(error)]}
    finally:
        if lock_fd is not None:
            os.close(lock_fd)
            lock.unlink(missing_ok=True)


def bundle(root, state_root, actor_id, run_id):
    """Download only known synthetic artifacts from this actor's saved rehearsal."""
    loaded = read_run(root, state_root, actor_id, run_id)
    if not loaded["ok"]:
        raise ValueError("This rehearsal is unavailable.")
    folder = _folder(root, state_root, actor_id, run_id)
    record = loaded["run"]
    product = _canonical(folder / record["product"], folder)
    unverified = "unverified/" if record["stage"] != "complete" else ""
    items = [(folder / "plan.json", "plan.json"), (folder / "qc-report.json", unverified + "qc-report.json")]
    build_prefix = "" if (record.get("report") or {}).get("synthetic_ads") == "built" else "unverified/"
    items.append((folder / "synthetic-build.json", build_prefix + "synthetic-build.json"))
    items += [(product / "spec_pipeline/out" / name, unverified + "specification/" + name) for name in OUTPUTS]
    items.append((product / "handoff/FUNCTIONAL_CONTRACT.md", "draft/FUNCTIONAL_CONTRACT.md"))
    if record.get("revision_of"):
        items += [(product / "handoff" / name, "draft/" + name) for name in ("DECISIONS.md", "ENGINE_GAPS.md")]
    output = io.BytesIO()
    with zipfile.ZipFile(output, "w", zipfile.ZIP_DEFLATED) as archive:
        archive.writestr("READ-ME.txt", NOTICE + ("\n\n" + record.get("error", "Artifacts from an unfinished run are unverified.") if unverified else ""))
        archive.writestr("rehearsal.json", json.dumps(record, ensure_ascii=False, indent=2))
        for path, name in items:
            safe = _canonical(path, folder)
            if safe.is_file():
                if safe.stat().st_size > 4 * 1024 * 1024:
                    raise ValueError("A rehearsal artifact is too large to package. Run the saved rehearsal again before downloading its packet.")
                archive.writestr(name, safe.read_bytes())
    return output.getvalue()
