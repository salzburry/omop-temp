"""Keep a failed setup visible while the researcher corrects the existing form."""
from __future__ import annotations

from pathlib import Path
import re
import unicodedata

import streamlit as st

import form_assistance as forms
import new_product_words as words
import portal_runtime
import session_drafts
import ui_text as ui


KEY = "np_recovery"


def clear():
    st.session_state.pop(KEY, None)


def _edit(section):
    record = st.session_state.get(KEY)
    if isinstance(record, dict):
        record["edit"] = section
    st.session_state.pop("np_previewed", None)


def editing(root, actor_id, section):
    """Move the existing form controls beside this owner's retained failure."""
    record = st.session_state.get(KEY)
    return (isinstance(record, dict) and record.get("owner") == _owner(root, actor_id)
            and record.get("edit") == section)


def _edit_button(label, section):
    st.button(label, key="np_recovery_edit_" + section, on_click=_edit, args=(section,))


def _request_preview():
    record = st.session_state.get(KEY)
    if isinstance(record, dict):
        record["preview_requested"] = True


def take_preview_request(root, actor_id):
    record = st.session_state.get(KEY)
    return (isinstance(record, dict) and record.get("owner") == _owner(root, actor_id)
            and record.pop("preview_requested", False))


def _ask_chat():
    # Reuse the owner-bound, one-shot chat request after a full form render.
    # The current validation supplies sanitized diagnostics; raw logs stay local.
    forms.defer_creation("Help me resolve the current product setup error using the displayed findings and editable fields. "
        "Explain the next action I can take here in the UI, and suggest supported draft corrections where needed. "
        "If the earlier findings are stale, help me recheck the current setup first.")


def _owner(root, actor_id):
    return forms.digest([str(Path(root).resolve()), actor_id])


def _inputs(state):
    fields = session_drafts.FIELDS | {"np_sheet_domains", "np_sheet_domain_reason"}
    values = {key: state[key] for key in state if key in fields or
              str(key).startswith("np_wb") and not str(key).endswith("_upload")}
    return forms.digest(values)


def _diagnostic_text(output):
    lines = str(output or "").splitlines()
    first = next((index for index, line in enumerate(lines) if line.startswith("REFUSED")), 0)
    return "\n".join(lines[first:])


def _lock_failure(diagnostic):
    """Recognize only a refusal from the setup lock, including retained old reports."""
    for line in words.refusal_lines(diagnostic):
        if re.match(r"^Setup lock \[[a-z_]+\]: ", line) or line.startswith(
                "Another product setup is running in this checkout, or its local lock cannot be verified."):
            return True
    return False


def describe(output, *, phase="write", runtime_failure=None):
    """Read stage identities from the tool's report; never infer execution from PLAN."""
    diagnostic = _diagnostic_text(output)
    changed_files = words.CHANGED_SETUP_INPUTS in words.refusal_lines(diagnostic)
    match = next((found for line in diagnostic.splitlines() if (found := words.STAGED_FAILURE.search(line))), None)
    stage = match.group(1) if match else ""
    if runtime_failure == "start":
        title = "Starting the setup check"
    elif runtime_failure in {"timeout", "cancelled"}:
        title = "Setup run interrupted; the failed stage was not reported"
    elif _lock_failure(diagnostic):
        title = "Waiting for setup access"
    elif changed_files:
        title = "Files changed during validation"
    elif "Gate 2" in stage or "extraction" in stage.lower():
        title = "Specification extraction (Gate 2)"
    elif "Gate 1" in stage:
        title = "Specification registration (Gate 1)"
    elif stage:
        label = re.sub(r"\s*\([^)]*\.py[^)]*\)", "", stage).strip()
        messages, omitted = forms.validation_messages([label])
        title = (messages[0] if messages and not omitted and len(messages[0]) <= 160
                 and not any(unicodedata.category(char).startswith("C") for char in label)
                 else "Setup validation (stage details are in the run report)")
    else:
        title = "Setup validation" if phase == "preview" else "Product creation"
    from flow_page import _run_findings
    findings = _run_findings(diagnostic)
    if changed_files:
        details = [line for line in words.refusal_lines(diagnostic)
                   if re.match(r'^(?:checkout input|selected workbook) (?:changed|created|removed): ', line)]
        findings = forms.validation_messages(details)[0]
    sentences, untranslated = words.refusal_sentences(diagnostic)
    confirmed_refusal = bool(re.search(r"^REFUSED\b[^\n]*nothing was written\.", diagnostic, re.M))
    # A traceback or an interrupted process cannot supply a verified rollback.
    state = "refused" if confirmed_refusal and not words.is_operational_failure(diagnostic) and not runtime_failure else "unconfirmed"
    text = " ".join([stage, *findings, *words.refusal_lines(diagnostic)]).lower()
    form_error = not changed_files and not _lock_failure(diagnostic) and not words.is_operational_failure(diagnostic) and not runtime_failure
    return {"title": title, "stage": stage, "findings": findings, "sentences": sentences,
            "untranslated": untranslated, "operational": words.is_operational_failure(diagnostic),
            "state": state, "runtime_failure": runtime_failure, "phase": phase,
            "setup_lock": _lock_failure(diagnostic) and not stage and state == "refused",
            "changed_files": changed_files and not stage and state == "refused",
            "workbook": form_error and bool(re.search(r"workbook|sheet|\btab\b|header|extraction|change.class|change.note", text)),
            "mapping": form_error and bool(re.search(r"unclassified|unmapped|sheet.mapping|sheet.domain", text)),
            "headers": form_error and bool(re.search(r"header|cell position|zero rows|named column|resolves no .+ column", text)),
            "identity": form_error and bool(re.search(r"classified.by|classified.date|ai.classification", text)),
            "product": form_error and bool(re.search(r"\bslug\b|spec.version|tumou?r.family|disease.terms|already.*alias|\bcode\b|\bname\b|next.cut.of", text)),
            "data": form_error and bool(re.search(r"\bvendor\b|\bmodality\b|tumou?r.class|condition.class|\bnarrow\b|\bbroad\b", text))}


def capture(root, actor_id, result, *, phase):
    """Retain failure details and withdraw the earlier write preview; change no fields."""
    if result.returncode == 0:
        clear()
        return
    output = ((result.stdout or "") + (result.stderr or "")).strip()
    st.session_state[KEY] = {"owner": _owner(root, actor_id), "inputs": _inputs(st.session_state),
        "output": output, "failure": describe(output, phase=phase, runtime_failure=portal_runtime.failure_kind(result))}
    st.session_state.pop("np_previewed", None)


def _family_repair(root, record):
    """Offer the existing registration route only for a current, exact family collision."""
    family, _ = words.family_collision(_diagnostic_text(record["output"]))
    if not family:
        return False
    import spec_lint
    try:
        registry = spec_lint.load_tumour_registry(root)
    except (SystemExit, OSError, ValueError, TypeError):
        return False
    if family not in registry["families"]:
        return False
    if st.session_state.get("np_mode") == ui.NEW_PRODUCT_MODES[2]:
        return False
    current = str(st.session_state.get("np_slug") or "").strip()
    current_code = str(st.session_state.get("np_code") or "").strip()
    selected = (st.session_state.get("np_mode") == ui.NEW_PRODUCT_MODES[1]
                and st.session_state.get("np_family") == family)
    if selected and current and current != family and current_code != family:
        st.info(f"The form now uses the existing {family} tumour family and product identifier {current}. Preview the updated plan to check it.")
        return True
    st.write("**Correct the starting point here**")
    st.caption(f"Use the existing {family} tumour family. Choose a distinct product identifier below; this only updates your form.")
    key = "np_recovery_product_slug_" + forms.digest([record["owner"], record["inputs"], record["output"]])[:16]
    identifier = st.text_input("Distinct product identifier", value="" if current == family else current, key=key,
        help=f"Lower-case letters, digits and underscores, starting with a letter. Use your product's identifier, for example {family}_outcomes; {family} is reserved for the tumour family.").strip()
    valid = bool(re.fullmatch(r"[a-z][a-z0-9_]*", identifier)) and identifier not in registry["families"]
    if identifier and not valid:
        st.caption("Choose an identifier different from the tumour family, using lower-case letters, digits and underscores.")
    code = None
    if current_code == family:
        st.caption(f"Your registry code is also {family}. Leave the code below empty to use the new product identifier, or enter a distinct code.")
        code = st.text_input("Registry code for this product (optional)", value="", key=key + "_code",
                             help="An empty code follows the new product identifier. Other saved registry codes are kept.").strip()
        valid = valid and (not code or bool(re.fullmatch(r"[a-z][a-z0-9_]*", code)) and code not in registry["families"])
    if st.button(f"Use {family} for this product", key="np_recovery_use_family", disabled=not valid):
        # The app consumes these existing hooks before instantiating the real widgets.
        # Do not mutate widget values after rendering, or repeat the failed operation.
        st.session_state["np_mode_suggested"] = True
        st.session_state["np_family_suggested"] = family
        st.session_state["np_slug_suggested"] = identifier
        if code is not None:
            st.session_state["np_code_suggested"] = code
        st.session_state.pop("np_previewed", None)
        st.rerun()
    return True


def _lock_help(root):
    """Inspect current access without recovering a lock or repeating the setup."""
    import new_product
    current = new_product.standup_status(root)
    ready = current["state"] in {"absent", "dead"}
    if ready:
        message = ("No product setup holds this lock now. Your entries are retained. "
                   "Choose Preview the plan, then Write when that preview passes.")
        st.info(message)
        st.caption("Write checks access again before making changes. Nothing retries automatically.")
    else:
        message = current["reason"]
        st.warning(message)
        st.caption("Your entries are retained. Check setup access again after the running operation finishes or the reported problem is resolved.")
    st.button("Check setup access again", key="np_recovery_check_lock",
              help="Refresh the lock status only; this does not preview, create, cancel or unlock a product.")
    return ready, message


def render(root, actor_id, *, sheet_scope=None):
    record = st.session_state.get(KEY)
    if not isinstance(record, dict):
        return
    if record.get("owner") != _owner(root, actor_id):
        clear()
        return
    previous = record["failure"]
    # Existing sessions may hold an earlier wording/parser result after a code update.
    failure = describe(record["output"], phase=previous["phase"], runtime_failure=previous["runtime_failure"])
    record["failure"] = failure
    changed = record["inputs"] != _inputs(st.session_state)
    with st.container(border=True):
        st.subheader("Stopped at: " + failure["title"])
        show = st.warning if failure["phase"] == "preview" else st.error
        lock_ready, lock_message = False, ""
        if failure["setup_lock"]:
            show("This attempt could not acquire setup access. Nothing was written by this attempt.")
            lock_ready, lock_message = _lock_help(root)
        elif failure["changed_files"]:
            show("Files changed while this setup was being checked. This attempt wrote no product.")
            st.info("Wait until code, configuration or workbook edits have finished, then choose Preview the plan and Write again. Your form entries are retained; this report does not identify a workbook-content error.")
        elif failure["operational"]:
            show(words.OPERATIONAL_FAILURE)
        elif failure["runtime_failure"]:
            show(record["output"] or "The setup could not finish. Check its current state before retrying.")
        elif failure["sentences"] or failure["untranslated"]:
            text = (ui.NEW_PRODUCT_PREVIEW_REFUSED if failure["phase"] == "preview" else ui.NEW_PRODUCT_REFUSED)
            if failure["state"] == "refused" or failure["phase"] == "preview":
                show(text.format(n=len(failure["sentences"]) + failure["untranslated"]))
            else:
                show("Creation did not report success. Review the findings and current product state before retrying.")
        else:
            show("The setup check did not complete. Your entries remain available below.")
        for sentence in failure["sentences"]:
            if sentence != words.OPERATIONAL_FAILURE:
                st.markdown("- " + sentence)
        if failure["findings"]:
            st.write("**What needs attention**")
            for finding in failure["findings"]:
                st.write("• " + finding)
        if changed:
            st.info("Your setup changed after this failed run. These are the previous findings; Preview the updated plan before trying Write again.")
        elif not failure["setup_lock"] and not failure["changed_files"]:
            st.caption("Your form entries are retained below. Correct the indicated input, then choose Preview the plan again. No retry runs automatically.")
        offered = failure["setup_lock"] or failure["changed_files"] or (not changed and _family_repair(root, record))
        if failure["workbook"]:
            _edit_button("Edit the specification input (step 3)", "specification")
            selectable = any(row.get("mapping_selectable") for row in (sheet_scope or {}).get("sheets") or [])
            if failure["mapping"] and selectable:
                st.write("Use the sheet section choices below to classify the named sheets, then preview again.")
            if failure["headers"]:
                st.write("Correct the named header or column in the source workbook, then select or upload that corrected workbook in step 3. A section mapping does not rename workbook columns.")
            elif not (failure["mapping"] and selectable):
                st.write("Review the selected workbook and its sheet scope in step 3. If its source content needs correction, choose the corrected workbook there before previewing again.")
            offered = True
        if failure["identity"]:
            _edit_button("Edit classification details (step 4)", "classification")
            offered = True
        if failure["data"]:
            _edit_button("Edit data details (step 2)", "data")
            offered = True
        if failure["product"] and not offered:
            _edit_button("Edit product details (step 1)", "details")
            offered = True
        _edit_button("Edit setup inputs", "all")
        st.button("Ask chat to help resolve this error", key="np_recovery_ask_chat", on_click=_ask_chat,
                  disabled=not st.session_state.get(forms.KEY + "enabled"),
                  help="Send this setup's current findings and editable field context to the assistant. Review any suggested corrections before writing.")
        st.button("Preview setup again", key="np_recovery_preview", on_click=_request_preview,
                  help="Check the current entries once. A successful preview lets you review the plan before choosing Write.")
        if record.get("edit"):
            st.info("The selected step's editable fields are directly below this report. Your other setup entries are retained.")
            st.button("Show setup steps in their original order", key="np_recovery_edit_done",
                      on_click=_edit, args=(None,))
        if not offered:
            st.write("Ask chat to work through this error with the current setup context, or open Edit setup inputs to correct the form. Preview setup again checks your changes before Write becomes available.")
        if failure["phase"] == "write" and failure["state"] != "refused":
            st.caption("The tool did not verify whether a product was installed. Check product progress before repeating a write.")
        with st.expander("Run details for the failed setup"):
            st.code(record["output"] or "(no output)", language=None)
            st.download_button("Download setup failure report", record["output"] or "No output was returned.",
                file_name="product-setup-failure.txt", mime="text/plain", key="np_recovery_download")
        diagnostics = forms.validation_messages(words.refusal_lines(_diagnostic_text(record["output"])))[0]
        blockers = [lock_message] if failure["setup_lock"] else failure["findings"] or [*failure["sentences"]] or diagnostics or ["The setup check did not complete; inspect its retained run details."]
        if failure["changed_files"]:
            blockers = ["Checkout or workbook edits invalidated this validation run. Once edits finish, preview the unchanged form again before an explicit Write.", *failure["findings"]]
        forms.record_validation([f"{failure['title']}: {line}" for line in blockers],
            title="Product setup stopped: " + failure["title"], action_id="new_product_" + failure["phase"],
            input_digest=forms.digest([record["inputs"], _inputs(st.session_state), record["output"], lock_message]),
            primary=True, status="needs_recheck" if changed or lock_ready or failure["changed_files"] else "blocked")
