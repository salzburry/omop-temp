"""Open cited review documents without navigating to nonexistent Streamlit URLs."""
from __future__ import annotations

import hashlib
from pathlib import Path

import streamlit as st

import portal_links
import search_view


def _dismiss():
    st.session_state.pop("portal_document", None)
    st.session_state.pop("portal_document_history", None)


def reference(root, target, *, key, label="Open source", source_path="", allowed_packs=None,
              context=(), inline=False):
    ref = portal_links.resolve(root, target, source_path=source_path, allowed_packs=allowed_packs)
    if ref["kind"] == "external":
        st.link_button(label, ref["target"])
    elif ref["kind"] == "anchor":
        st.markdown(f"[{search_view.md_escape(label)}]({ref['target']})")
    elif ref["kind"] != "local":
        st.button(label, key=key, disabled=True, help=ref["reason"])
        st.caption(ref["reason"])
    elif inline:
        if st.checkbox(label, key=key):
            _preview(root, ref, allowed_packs=allowed_packs, context=context, key=key, links=False)
    elif st.button(label, key=key):
        current = st.session_state.get("portal_document")
        if current and current.get("context") == context:
            history = st.session_state.setdefault("portal_document_history", [])
            history.append(current)
            del history[:-20]
        st.session_state["portal_document"] = {"reference": ref, "context": context}
        st.rerun()


def markdown(root, text, *, key, source_path="", allowed_packs=None, context=(), links=True):
    prepared = portal_links.prepare_markdown(root, text, source_path=source_path, allowed_packs=allowed_packs)
    st.markdown(prepared["markdown"])
    local = [ref for ref in prepared["links"] if ref["kind"] not in {"external", "anchor"}]
    if links and local:
        with st.expander("Sources and linked documents"):
            for i, ref in enumerate(local):
                label = ref["label"] or Path(ref["path"]).name or "Linked document"
                if ref["kind"] != "local":
                    st.button(label, key=f"{key}_source_{i}", disabled=True, help=ref["reason"])
                    st.caption(ref["reason"])
                else:
                    reference(root, ref["target"], key=f"{key}_source_{i}", label=label,
                              allowed_packs=allowed_packs, context=context)
    return prepared


def _preview(root, ref, *, key, allowed_packs, context, links=True):
    result = portal_links.read_text(root, ref, allowed_packs=allowed_packs)
    if not result.get("ok"):
        st.info(result.get("reason") or "This document is no longer available. Check its source reference.")
        return
    st.caption(result["path"])
    if result.get("line"):
        line = int(result["line"])
        rows = result.get("safe_markdown", result["text"]).splitlines()
        if 1 <= line <= len(rows):
            st.caption(f"Cited line {line}")
            st.code("\n".join(rows[max(0, line - 4):line + 7]), language=None)
        else:
            st.info("The cited line is no longer in this file. Review the current document below.")
    suffix = Path(result["path"]).suffix.lower()
    if suffix == ".md":
        prepared = markdown(root, result["text"], source_path=result["path"], key=key,
                            allowed_packs=allowed_packs, context=context, links=links)
        download = prepared["markdown"]
    else:
        download = result.get("safe_markdown", result["text"]) if allowed_packs is not None else result["text"]
        st.code(download, language={".yaml": "yaml", ".yml": "yaml", ".json": "json", ".toml": "toml"}.get(suffix))
    st.download_button("Download this document", download, file_name=Path(result["path"]).name,
                       mime="text/plain", key=f"{key}_download")


@st.dialog("Source document", width="large", on_dismiss=_dismiss)
def _dialog(root, *, allowed_packs, context):
    current = st.session_state.get("portal_document") or {}
    if current.get("context") != context:
        _dismiss()
        st.rerun()
    ref = current.get("reference") or {}
    st.subheader(Path(ref.get("path") or "Document").name)
    key = "document_" + hashlib.sha256(str(ref).encode()).hexdigest()[:12]
    _preview(root, ref, key=key, allowed_packs=allowed_packs, context=context)
    cols = st.columns(2)
    if st.session_state.get("portal_document_history") and cols[0].button("Back to previous document", key="document_back"):
        st.session_state["portal_document"] = st.session_state.portal_document_history.pop()
        st.rerun()
    if cols[1].button("Close document", key="document_close"):
        _dismiss()
        st.rerun()


def render_open_document(root, *, allowed_packs=None, context=()):
    current = st.session_state.get("portal_document")
    if current and current.get("context") != context:
        _dismiss()
    elif current:
        _dialog(root, allowed_packs=allowed_packs, context=context)
