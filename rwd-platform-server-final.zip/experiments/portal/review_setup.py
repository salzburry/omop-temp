"""Local signing with an existing registered key; never independent person authentication.

The interactive command and local portal require explicit confirmation, keep private
keys outside the checkout, and use Git's SSH signing and the existing verifier.
Key creation/enrolment and independent identity evidence are separate requirements.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import tempfile

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "platform" / "tools"))
import approval_identity as identity
import product_gates as pg
import yaml
from person_rules import not_a_person

REGISTRY = "governance/allowed_signers.yaml"
CHECKPOINTS = {"source": "Specification and source access", "science": "Science, source evidence and configuration",
               "release": "Candidate validation and release"}
MAX_BYTES = 32 * 1024 * 1024
# Approval forms whose digest fields pin OTHER files of the same pack, and what each pins.
# A signed review commit re-asserts the decision register's bytes, and the Gate 2 form
# pins that register by digest: left alone, the commit that authenticates the approval
# is the commit that voids it, and Gate 2 read "the decision register changed after the
# approval" after every signing in a UAT run. The subjects are the ones
# product_gates.contract_approval_errors verifies and workflow_forms.describe filled, so
# the same functions compute them here; a third definition would be the one that drifts.
# A subject is a pack-relative path (digest of its bytes) or a (path, function of a path)
# pair when the gate digests the file's content rather than its bytes. Gate 4's form is
# not here: its subjects (the contract's requirements, the configuration graph) carry no
# attribution a review commit rewrites, so this act cannot leave them stale.
DIGEST_SUBJECTS = {
    "handoff/CONTRACT_APPROVAL.yaml": (
        ("approved_extraction_sha256", "spec_pipeline/out/extracted.json"),
        ("approved_contract_sha256", ("handoff/FUNCTIONAL_CONTRACT.md", pg.requirements_sha256)),
        ("approved_coverage_sha256", "spec_pipeline/out/COVERAGE.md"),
        ("approved_decisions_sha256", "handoff/DECISIONS.md"),
        ("approved_spec_qc_sha256", pg.SPEC_QC)),
}


class Refused(ValueError):
    pass


def development_snapshot(root, pack, checkpoint):
    """Prepare a portable demonstration review without Git or signing credentials."""
    import development_review
    try:
        prepared = development_review.snapshot(root, pack, checkpoint)
        accepted = development_review.confirmed_claims(root, pack)
        prepared["confirmed_reviewers"] = [name for name in prepared["reviewers"]
            if all((claim["file"], claim["field"], name) in accepted
                   for claim in prepared["claims"] if claim["who"] == name)]
        return prepared
    except ValueError as error:
        raise Refused(str(error)) from error


def confirm_development(root, pack, checkpoint, reviewer, email, expected_digest, *,
                        confirmed=False, local_demo=False, can_review=False):
    """Save an explicit email confirmation for development, never a production signature."""
    from datetime import datetime, timezone
    import uuid
    import development_review
    import local_process_lock
    if local_demo is not True or can_review is not True:
        raise Refused("Development review confirmation requires development mode and review permission.")
    if confirmed is not True:
        raise Refused("Confirm that you have reviewed these details before saving.")
    email = str(email or "").strip().casefold()
    if len(email) > 254 or not re.fullmatch(r"[^\s@<>]+@[^\s@<>]+\.[^\s@<>]+", email):
        raise Refused("Enter your email address to record this development review.")
    root, pack, product = development_review.product(root, pack)
    destination = product / development_review.RECORD
    if destination.resolve() != destination:
        raise Refused("The development review record redirects elsewhere.")
    destination.parent.mkdir(parents=True, exist_ok=True)
    lock = destination.with_name(".development-reviews.portal-edit.lock")
    if lock.resolve() != lock:
        raise Refused("The development review lock redirects elsewhere.")
    handle = os.open(lock, os.O_CREAT | os.O_RDWR, 0o600)
    acquired = False
    try:
        # Only an OS advisory lock is needed: a crashed writer releases it, and
        # moving the product to another server carries no machine-owner state.
        try:
            local_process_lock._advisory(handle, True)
            acquired = True
        except OSError:
            raise Refused("Another review is being saved. Retry after it finishes.") from None
        current = development_review.snapshot(root, pack, checkpoint)
        if current["digest"] != expected_digest:
            raise Refused("The review details changed. Refresh this form, check the changes and confirm again.")
        if reviewer not in current["reviewers"]:
            raise Refused("Choose a reviewer named in this checkpoint's records.")
        document = development_review.records(root, pack)
        for other in document["reviews"]:
            if (other.get("checkpoint") == checkpoint and other.get("digest") == current["digest"]
                    and other.get("reviewer") != reviewer and str(other.get("email", "")).casefold() == email):
                raise Refused("Use separate email addresses for different reviewers. The independent reviewer must confirm with their own profile.")
        record = {"record_id": uuid.uuid4().hex, "development_only": True, "checkpoint": checkpoint,
                  "reviewer": reviewer, "email": email, "digest": current["digest"],
                  "confirmed_at": datetime.now(timezone.utc).isoformat(),
                  "claims": [claim for claim in current["claims"] if claim["who"] == reviewer]}
        document["reviews"] = [row for row in document["reviews"]
            if not (row.get("checkpoint") == checkpoint and row.get("reviewer") == reviewer)] + [record]
        if development_review.snapshot(root, pack, checkpoint)["digest"] != current["digest"]:
            raise Refused("The review details changed while saving. Refresh this form and confirm again.")
        _atomic(destination, (json.dumps(document, indent=2, ensure_ascii=False) + "\n").encode())
        return {"ok": True, "development_only": True, "reviewer": reviewer, "email": email,
                "record_id": record["record_id"], "message": "Development review confirmed. Choose Check again to continue the workflow."}
    except ValueError as error:
        raise Refused(str(error)) from error
    finally:
        if acquired:
            local_process_lock._advisory(handle, False)
        os.close(handle)


def _run(root, args, *, capture=True, env=None):
    result = subprocess.run(args, cwd=root, capture_output=capture is True,
                            stdout=subprocess.PIPE if capture == "stdout" else None, text=True, encoding="utf-8",
                            errors="replace", env=env, timeout=180)
    if result.returncode:
        raise Refused((result.stderr or result.stdout or "The signing command was cancelled or failed.").strip()[-2500:])
    return (result.stdout or "").strip()


def _git(root, *args, env=None):
    return _run(root, ["git", "-C", str(root), *args], env=env)


def _bytes(root, relative):
    path = root / relative
    if path.resolve() != path or not path.is_file():
        raise Refused(f"The review input is unavailable or redirects elsewhere: {relative}")
    with path.open("rb") as handle:
        raw = handle.read(MAX_BYTES + 1)
    if len(raw) > MAX_BYTES:
        raise Refused(f"The review input is too large for this local signing workflow: {relative}")
    return raw


def _sha(raw):
    return hashlib.sha256(raw).hexdigest()


def _bucket(relative):
    if relative.endswith("/source_refs.yaml"):
        return "source"
    if relative.endswith("/RELEASE_APPROVAL.yaml"):
        return "release"
    return "science"


def snapshot(root, pack, checkpoint):
    """Public, read-only preparation for any of the three signing checkpoints."""
    root = Path(root).resolve()
    pack = str(pack).replace("\\", "/")
    if checkpoint not in CHECKPOINTS or not re.fullmatch(r"(?:products|fixtures)/[A-Za-z0-9_-]+/[A-Za-z0-9_-]+/\d{6}", pack):
        raise Refused("Choose a product and one of the three review checkpoints.")
    if (root / pack).resolve() != root / pack or not (root / pack).is_dir():
        raise Refused("The selected product is unavailable or redirects elsewhere.")
    if identity.shallow(str(root)):
        raise Refused("The reviewer needs this repository's full history before signing.")
    head = _git(root, "rev-parse", "HEAD")
    registry = _bytes(root, REGISTRY)
    def _mine(file):
        rel = str(file).replace("\\", "/")
        return rel.startswith(pack + "/") and _bucket(rel) == checkpoint
    audited, _registry_errors = identity.audit(str(root), files=_mine)
    if any(claim.get("unreadable") for claim in audited):
        raise Refused("A review record could not be read. Correct it in Resolve before preparing the signature.")
    # A cryptographically verified claim needs no repeated local signature.
    # Independent identity evidence remains missing and is reported separately.
    claims = [{"file": str(c["file"]).replace("\\", "/"), "field": c["field"], "who": c["who"]}
              for c in audited if c.get("signature_verified") is not True]
    if audited and not claims:
        raise Refused("Every review record at this checkpoint already has a verified key signature. "
                      "Independent reviewer identity evidence is still required; repeated signing cannot supply it. "
                      "See governance/APPROVAL_IDENTITY.md.")
    files = set(claim["file"] for claim in claims)
    # Bind the command to the current scientific/configuration inputs as well as
    # the assertions. Do not read arbitrary delivery data or follow symlinks.
    for directory in ("config", "variables", "codelists", "handoff", "spec_pipeline/out", "prog_spec"):
        base = root / pack / directory
        if base.exists() and base.resolve() != base:
            raise Refused(f"A review input directory redirects elsewhere: {directory}")
        if base.is_dir():
            for path in base.rglob("*"):
                if path.suffix.lower() in {".yaml", ".yml", ".json", ".md", ".csv", ".tsv", ".xlsx"} and path.is_file():
                    files.add(path.relative_to(root).as_posix())
    if (root / pack / "source_refs.yaml").is_file():
        files.add(f"{pack}/source_refs.yaml")
    if len(files) > 2000:
        raise Refused("This product needs an operator review bundle; too many inputs for the local helper.")
    hashes = {name: _sha(_bytes(root, name)) for name in sorted(files)}
    data = {"pack": pack, "checkpoint": checkpoint, "head": head, "registry_sha256": _sha(registry),
            "claims": claims, "files": hashes}
    data["digest"] = _sha(json.dumps(data, sort_keys=True).encode())
    data["reviewers"] = sorted({c["who"] for c in claims if not not_a_person(c["who"])})
    return data


def command(root, pack, checkpoint, reviewer, expected_digest, *, windows=None):
    from resolution_commands import render
    return render(root, ["experiments/portal/review_setup.py", "--pack", pack, "--checkpoint", checkpoint,
                         "--reviewer", reviewer, "--expected", expected_digest], windows=windows)


def _load(raw):
    from specification_details import _StrictLoader
    # The same duplicate-field, alias and UTF-8 rules used by portal editors.
    text = raw.decode("utf-8-sig")
    if any(isinstance(token, (yaml.AliasToken, yaml.AnchorToken)) for token in yaml.scan(text)):
        raise Refused("Review records cannot use YAML aliases or anchors.")
    doc = yaml.load(text, Loader=_StrictLoader)
    if not isinstance(doc, dict):
        raise Refused("The review record must contain named fields.")
    return doc


def _registry_entry(raw, fingerprint, public_key, reviewer, email):
    doc = _load(raw)
    if not isinstance(doc, dict) or not isinstance(doc.get("signers"), list):
        raise Refused("The signer registry is malformed. It needs an administrator's repair.")
    if fingerprint in identity.ineligible_keys(doc):
        raise Refused("This key is explicitly ineligible for a person's review.")
    existing = [entry for entry in doc["signers"] if isinstance(entry, dict) and entry.get("key_id") == fingerprint]
    if existing:
        if len(existing) != 1 or existing[0].get("identity") != reviewer or existing[0].get("attests") != "person_review":
            raise Refused("This key already belongs to a different identity or purpose.")
        if str(existing[0].get("public_key") or "").split()[:2] != public_key.split()[:2]:
            raise Refused("The chosen public key differs from its registered key material. Ask the administrator to repair enrolment.")
        return raw, False
    raise Refused("This key is not registered for the named reviewer. The signing helper cannot enrol identities. "
                  "Ask the responsible administrator to arrange independently reviewed public-key enrolment.")


def _pending(root, head, relative, raw):
    """The change this commit already carries for a file: the working tree against the
    reviewed parent, or the whole file when the parent does not have it yet."""
    if not _git(root, "ls-tree", head, "--", relative):
        return "".join("+" + line for line in raw.decode("utf-8-sig", "replace").splitlines(keepends=True))
    return _git(root, "diff", head, "--", relative)


def _reassert(raw, reviewer, fields, pending_diff=""):
    """An explicit new review must write the attribution in the signed diff."""
    text = raw.decode("utf-8-sig")
    if any(field.startswith("decision:") for field in fields):
        # A row the working tree already changed against the parent is written by the
        # signed diff as it stands, so the verifier binds it to this commit without
        # help. Moving its whitespace as well would change the register's bytes for
        # nothing, and an approval form given the register's digest before signing
        # would be voided by the very signature meant to stand behind it.
        carried = {line[1:].strip() for line in pending_diff.splitlines()
                   if line.startswith("+") and not line.startswith("+++")}
        lines = text.splitlines(keepends=True)
        for i, line in enumerate(lines):
            if any(field.split(":", 1)[1] in line for field in fields) and reviewer in re.sub(r"[*`_]", "", line):
                if line.strip() in carried:
                    continue
                # Table whitespace is semantically neutral but records the new
                # human assertion in the diff that the existing verifier reads.
                lines[i] = line.replace("| ", "|  ", 1) if "| " in line else line.replace("|", "| ", 1)
        return "".join(lines).encode("utf-8")
    doc = _load(raw)
    nodes = []
    def walk(node):
        if isinstance(node, yaml.MappingNode):
            for key, value in node.value:
                if key.value in fields and isinstance(value, yaml.ScalarNode) and value.value == reviewer:
                    nodes.append(value)
                walk(value)
        elif isinstance(node, yaml.SequenceNode):
            for value in node.value:
                walk(value)
    walk(yaml.compose(text))
    for node in sorted(nodes, key=lambda n: n.start_mark.index, reverse=True):
        old = text[node.start_mark.index:node.end_mark.index]
        value = json.dumps(reviewer, ensure_ascii=False)
        if value == old:
            value = "'" + reviewer.replace("'", "''") + "'"
        text = text[:node.start_mark.index] + value + text[node.end_mark.index:]
    changed = text.encode("utf-8")
    if _load(changed) != doc:
        raise Refused("Re-recording this review would alter the scientific content.")
    return changed


def _restamped(root, pack, relative, raw, committed):
    """(form bytes, [digest fields rewritten]) so the form describes what this commit carries.

    Each digest is recomputed with the gate's own function over the bytes the signed
    commit will hold: the re-asserted bytes for a file this review rewrites, the current
    bytes otherwise. Only a stated digest that differs is rewritten, quoted as it was;
    a placeholder stays a placeholder (that finding is the gate's, never this helper's
    to fill), an absent subject binds to nothing, and no other field moves.
    """
    subjects = DIGEST_SUBJECTS.get(relative[len(pack) + 1:])
    if not subjects:
        return raw, []
    doc = _load(raw)
    wanted = {}
    for field, subject in subjects:
        recorded = str(doc.get(field) or "").strip()
        if pg.unstated(recorded):
            continue
        path, function = subject if isinstance(subject, tuple) else (subject, None)
        name = f"{pack}/{path}"
        if name in committed:
            content = committed[name]
        elif (root / name).is_file():
            content = _bytes(root, name)
        else:
            continue
        if function is None:
            digest = _sha(content)
        elif name in committed:
            with tempfile.TemporaryDirectory(prefix="rwd-review-subject-") as directory:
                staged = Path(directory) / Path(path).name
                staged.write_bytes(content)
                digest = function(str(staged))
        else:
            digest = function(str(root / name))
        if digest != recorded:
            wanted[field] = digest
    if not wanted:
        return raw, []
    text = raw.decode("utf-8-sig")
    nodes = {key.value: value for key, value in yaml.compose(text).value
             if key.value in wanted and isinstance(value, yaml.ScalarNode)}
    if set(nodes) != set(wanted):
        raise Refused(f"The checksum fields in {relative} could not be updated safely. Nothing was signed.")
    for field, node in sorted(nodes.items(), key=lambda item: item[1].start_mark.index, reverse=True):
        old = text[node.start_mark.index:node.end_mark.index]
        quote = old[0] if old and old[0] in "\"'" else ""
        text = text[:node.start_mark.index] + quote + wanted[field] + quote + text[node.end_mark.index:]
    changed = text.encode("utf-8")
    if _load(changed) != {**doc, **wanted}:
        raise Refused(f"Updating the checksums in {relative} would change another field. Nothing was signed.")
    return changed, sorted(wanted)


def _review_changes(root, prepared, reviewer, claims, paths, originals):
    """The exact bytes the signed commit carries for the reviewer's files, and the
    approval digests that had to move with them, computed before the person confirms."""
    changes = {}
    for relative in paths:
        fields = {claim["field"] for claim in claims if claim["file"] == relative}
        pending = _pending(root, prepared["head"], relative, originals[relative])
        changes[relative] = _reassert(originals[relative], reviewer, fields, pending_diff=pending)
    restamped = {}
    for relative in paths:
        changes[relative], fields = _restamped(root, prepared["pack"], relative, changes[relative], changes)
        if fields:
            restamped[relative] = fields
    return changes, restamped


def _atomic(path, raw):
    if path.resolve() != path:
        raise Refused("A review destination redirects to another location; nothing was replaced.")
    handle, tmp = tempfile.mkstemp(prefix=".review-", dir=path.parent)
    try:
        with os.fdopen(handle, "wb") as stream:
            stream.write(raw)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(tmp, path)
    finally:
        if os.path.exists(tmp):
            os.unlink(tmp)


def _unchanged_inputs(root, prepared, changes):
    current = snapshot(root, prepared["pack"], prepared["checkpoint"])
    expected = {name: _sha(changes[name]) if name in changes else digest for name, digest in prepared["files"].items()}
    registry = _sha(changes[REGISTRY]) if REGISTRY in changes else prepared["registry_sha256"]
    if (current["head"] != prepared["head"] or current["files"] != expected
            or current["registry_sha256"] != registry or current["claims"] != prepared["claims"]):
        raise Refused("The review inputs or repository history changed during setup. Copy a fresh command from Resolve.")


def _refresh_index(root, git_dir, old_index, changes, staged_paths):
    """Advance only untouched review entries; preserve pre-existing/concurrent staging."""
    index = git_dir / "index"
    lock = index.with_name("index.lock")
    acquired = False
    try:
        handle = os.open(lock, os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o600)
        os.close(handle)
        acquired = True
        if (index.read_bytes() if index.exists() else None) != old_index:
            return "Your staging changed during review and was left intact."
        refresh = sorted(set(changes) - set(staged_paths))
        if not refresh:
            return "Your existing staged review edits were left intact."
        with tempfile.TemporaryDirectory(prefix="rwd-index-", dir=git_dir) as directory:
            private = Path(directory) / "index"
            environment = dict(os.environ, GIT_INDEX_FILE=str(private))
            if old_index is not None:
                private.write_bytes(old_index)
            else:
                _git(root, "read-tree", "--empty", env=environment)
            _git(root, "reset", "--quiet", "HEAD", "--", *refresh, env=environment)
            # Publish with the normal Git index lock, so another Git writer cannot
            # slip an edit between comparison and replacement.
            _atomic(index, private.read_bytes())
        return "Your existing staged review edits were left intact." if staged_paths else ""
    except (OSError, Refused):
        return "The review was signed; staging could not be refreshed and was left intact."
    finally:
        if acquired:
            lock.unlink(missing_ok=True)


def _config_scope(root):
    """Where the verifier setting lives: a git worktree keeps it in its own config (walk RW-05,
    2026-09-07: `--local` in a worktree is the repository's shared config, so one worktree's signing
    set-up changed another checkout's verdicts); a plain checkout keeps `--local`."""
    common = subprocess.run(["git", "-C", str(root), "rev-parse", "--git-common-dir"], capture_output=True, text=True, encoding="utf-8", errors="replace")
    own = subprocess.run(["git", "-C", str(root), "rev-parse", "--git-dir"], capture_output=True, text=True, encoding="utf-8", errors="replace")
    if common.returncode == 0 and own.returncode == 0 and common.stdout.strip() and os.path.realpath(os.path.join(str(root), common.stdout.strip())) != os.path.realpath(os.path.join(str(root), own.stdout.strip())):
        subprocess.run(["git", "-C", str(root), "config", "extensions.worktreeConfig", "true"], capture_output=True)
        return ["--worktree"]
    return ["--local"]


def perform(root, prepared, reviewer, email, key_path, *, confirm, create_key=False, noninteractive=False):
    """Sign with an existing registered key from a terminal or explicitly local portal.

    No key is created or enrolled. Noninteractive mode never reads stdin.
    Verification proves key possession; independent person authentication is unavailable.
    """
    root = Path(root).resolve()
    if create_key:
        raise Refused("The signing helper cannot create keys or enrol identities. Use an existing registered key; "
                      "the reviewer and responsible administrator arrange enrolment separately.")
    if not re.fullmatch(r"[^\x00-\x1f\x7f]{1,160}", reviewer) or not_a_person(reviewer) or reviewer not in prepared["reviewers"]:
        raise Refused("Choose a named reviewer who actually appears in this checkpoint's records.")
    if not re.fullmatch(r"[^\s@<>]+@[^\s@<>]+\.[^\s@<>]+", email):
        raise Refused("Enter the reviewer's email address.")
    _registry, registry_errors = identity.registry(str(root))
    if registry_errors:
        raise Refused("The signer registry needs an administrator's repair before a new signature: " + "; ".join(registry_errors))
    current = snapshot(root, prepared["pack"], prepared["checkpoint"])
    if current["digest"] != prepared["digest"]:
        raise Refused("The product changed. Return to Resolve and copy a fresh command before reviewing.")
    prepared = current
    key = Path(key_path).expanduser().resolve()
    if key.is_relative_to(root) or key.name.endswith(".pub"):
        raise Refused("The reviewer-owned private key must stay outside the checkout; choose a private-key location outside this repository, for example under your home folder.")
    program = shutil.which("ssh-keygen")
    if not program:
        raise Refused("OpenSSH ssh-keygen is unavailable. Install the Windows OpenSSH client once, then repeat this command.")
    claims = [claim for claim in prepared["claims"] if claim["who"] == reviewer]
    paths = sorted({claim["file"] for claim in claims})
    if not paths:
        raise Refused("This checkpoint has no review attributed to this person yet. Complete the review form first.")
    originals = {relative: _bytes(root, relative) for relative in paths}
    changes, restamped = _review_changes(root, prepared, reviewer, claims, paths, originals)
    if not confirm({"reviewer": reviewer, "email": email, "files": paths, "checkpoint": prepared["checkpoint"], "claims": claims,
                    "digest": prepared["digest"], "file_sha256": {path: prepared["files"][path] for path in paths},
                    "pending_diff": _git(root, "diff", "HEAD", "--", *paths), "restamped": restamped}):
        raise Refused("Cancelled. No review or signer registration was changed.")
    if not key.exists():
        raise Refused("The chosen personal key does not exist. No key was created; arrange enrolment with the responsible administrator.")
    public_path = Path(str(key) + ".pub")
    if not public_path.is_file():
        raise Refused("The matching public key is missing. Choose a complete personal SSH key pair.")
    public_key = public_path.read_text(encoding="utf-8").strip()
    if not re.fullmatch(r"ssh-ed25519 [A-Za-z0-9+/=]+(?: [^\r\n]*)?", public_key):
        raise Refused("This assistant currently supports personal Ed25519 SSH keys.")
    fingerprint = _run(root, [program, "-lf", str(public_path), "-E", "sha256"]).split()[1]
    if snapshot(root, prepared["pack"], prepared["checkpoint"])["digest"] != prepared["digest"]:
        raise Refused("The review changed during setup. Your personal key is retained; copy a fresh command from Resolve.")
    originals[REGISTRY] = _bytes(root, REGISTRY)
    registry, new_key = _registry_entry(originals[REGISTRY], fingerprint, public_key, reviewer, email)
    # Keep verification configuration local to this checkout. The file contains
    # public keys only; no credential is copied into the repository or portal.
    git_dir = Path(_git(root, "rev-parse", "--absolute-git-dir"))
    public_file = git_dir / "rwd-review-allowed-signers"
    if public_file.resolve() != public_file or (public_file.exists() and public_file.stat().st_size > 1024 * 1024):
        raise Refused("The local public verifier file redirects elsewhere or is too large. Repair that setup first.")
    previous_public = public_file.read_bytes() if public_file.exists() else None
    scope = _config_scope(root)
    prior_verifier = identity._git(str(root), "config", *scope, "--get", "gpg.ssh.allowedSignersFile")
    effective_verifier = identity._git(str(root), "config", "--get", "gpg.ssh.allowedSignersFile")
    principal = "rwd-" + _sha(reviewer.encode())[:20]
    line = f'{principal} namespaces="git" {public_key}\n'
    public_contents = (previous_public or b"").decode("utf-8")
    if "PRIVATE KEY" in public_contents:
        raise Refused("The local public verifier file contains private-key material. Ask its owner to repair the setting.")
    if effective_verifier:
        prior_path = Path(effective_verifier).expanduser()
        prior_path = prior_path if prior_path.is_absolute() else root / prior_path
        if prior_path.resolve() != public_file.resolve():
            if not prior_path.is_file() or prior_path.stat().st_size > 1024 * 1024:
                raise Refused("The existing SSH verification file is unavailable. Repair that setup before adding another reviewer.")
            old_lines = prior_path.read_text(encoding="utf-8")
            if "PRIVATE KEY" in old_lines:
                raise Refused("The existing SSH verification setting points to a private key. Ask the key owner to correct the local setting.")
            for existing_line in old_lines.splitlines():
                if existing_line not in public_contents.splitlines():
                    public_contents += ("\n" if public_contents and not public_contents.endswith("\n") else "") + existing_line + "\n"
    if line not in public_contents.splitlines(keepends=True):
        public_contents += ("\n" if public_contents and not public_contents.endswith("\n") else "") + line
    index_path = git_dir / "index"
    if index_path.resolve() != index_path:
        raise Refused("The Git index redirects elsewhere; ask the repository owner to repair it.")
    old_index = index_path.read_bytes() if index_path.exists() else None
    staged_paths = _git(root, "diff", "--cached", "--name-only", "--", *changes).splitlines()
    client_lock = git_dir / "rwd-review-client.lock"
    try:
        handle = os.open(client_lock, os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o600)
        os.close(handle)
    except FileExistsError as error:
        raise Refused("Another reviewer is signing in this checkout. Wait for that review to finish, then prepare a fresh command.") from error
    committed = False
    written = {}
    public_written = verifier_written = False
    new_commit = ""
    staging_notice = ""
    try:
        _unchanged_inputs(root, prepared, {})
        for relative, raw in changes.items():
            if _bytes(root, relative) != originals[relative]:
                raise Refused("A review record changed before writing. Your edit was left intact; prepare a fresh command.")
            written[relative] = raw
            _atomic(root / relative, raw)
        public_written = True
        _atomic(public_file, public_contents.encode())
        verifier_written = True
        _git(root, "config", *scope, "gpg.ssh.allowedSignersFile", str(public_file))
        _unchanged_inputs(root, prepared, changes)
        # Hash exactly the reviewed bytes into a private index. `commit --only`
        # would re-read working files and could sign a late, unreviewed edit.
        # commit-tree signs this immutable tree; update-ref publishes it only if
        # HEAD is still the reviewed parent. Required server/CI checks still apply.
        with tempfile.TemporaryDirectory(prefix="rwd-review-", dir=git_dir) as directory:
            environment = dict(os.environ, GIT_INDEX_FILE=str(Path(directory) / "index"))
            _git(root, "read-tree", prepared["head"], env=environment)
            for relative, raw in changes.items():
                stored = subprocess.run(["git", "-C", str(root), "hash-object", "-w", "--stdin"],
                                        input=raw, capture_output=True, timeout=180)
                if stored.returncode:
                    raise Refused("The exact review bytes could not be staged safely.")
                blob = stored.stdout.decode("ascii").strip()
                old_entry = _git(root, "ls-tree", prepared["head"], "--", relative)
                mode = old_entry.split()[0] if old_entry else "100644"
                if mode not in {"100644", "100755"}:
                    raise Refused("Review records must be regular files.")
                _git(root, "update-index", "--add", "--cacheinfo", f"{mode},{blob},{relative}", env=environment)
            tree = _git(root, "write-tree", env=environment)
            _unchanged_inputs(root, prepared, changes)
            new_commit = _run(root, ["git", "-C", str(root), "-c", f"user.name={reviewer}", "-c", f"user.email={email}",
                        "-c", "gpg.format=ssh", "-c", f"gpg.ssh.program={program}", "-c", f"user.signingkey={key}",
                        "commit-tree", tree, "-p", prepared["head"], "-S", "-m",
                        f"Record {CHECKPOINTS[prepared['checkpoint']]} review by {reviewer}"], capture="stdout", env=environment)
            signature = _git(root, "show", "-s", "--format=%G?|%GK", new_commit)
            if signature not in {"G|" + fingerprint, "U|" + fingerprint}:
                raise Refused("The private key's signature does not match its registered public key. No review commit was published.")
            _unchanged_inputs(root, prepared, changes)
            _git(root, "update-ref", "-m", "Record local review signature", "HEAD", new_commit, prepared["head"])
            committed = True
        staging_notice = _refresh_index(root, git_dir, old_index, changes, staged_paths)
    finally:
        if not committed:
            # Never restore over another editor's new bytes or a concurrent
            # commit. Rollback is limited to the exact bytes this call wrote.
            observed_head = identity._git(str(root), "rev-parse", "HEAD")
            for relative, raw in written.items():
                path = root / relative
                unchanged_history = observed_head == prepared["head"] or (
                    identity._git(str(root), "rev-parse", f"{observed_head}:{relative}") ==
                    identity._git(str(root), "rev-parse", f"{prepared['head']}:{relative}"))
                if unchanged_history and path.resolve() == path and path.is_file() and path.read_bytes() == raw:
                    _atomic(path, originals[relative])
            if public_written and public_file.resolve() == public_file and public_file.is_file() and public_file.read_bytes() == public_contents.encode():
                if previous_public is None:
                    public_file.unlink(missing_ok=True)
                else:
                    _atomic(public_file, previous_public)
            if verifier_written and identity._git(str(root), "config", *scope, "--get", "gpg.ssh.allowedSignersFile") == str(public_file):
                if prior_verifier:
                    _git(root, "config", *scope, "gpg.ssh.allowedSignersFile", prior_verifier)
                else:
                    subprocess.run(["git", "-C", str(root), "config", *scope, "--unset", "gpg.ssh.allowedSignersFile"], capture_output=True)
        client_lock.unlink(missing_ok=True)
    rows, errors = identity.audit(str(root), files=lambda rel: rel.replace("\\", "/") in paths)
    own = [row for row in rows if row.get("who") == reviewer]
    if errors or not own or any(not row.get("signature_verified") for row in own):
        raise Refused("The signed commit was kept, but review verification is incomplete. Return to Check status; do not repeat the scientific decision blindly. " + "; ".join(errors + [str(row.get("why")) for row in own if not row.get("authenticated")]))
    restamp_notice = " ".join(f"Updated checksums in {relative} so the approval describes the bytes in this signed commit: "
                              + ", ".join(fields) + "." for relative, fields in restamped.items())
    return {"ok": True, "commit": new_commit, "reviewer": reviewer,
            "authenticated_claims": 0, "signature_verified_claims": len(own), "identity_authenticated": False,
            "new_key": new_key, "restamped": restamped,
            "message": "The local review signature is verified. " + identity.IDENTITY_EVIDENCE_REQUIRED + " "
                       + " ".join(part for part in (staging_notice, restamp_notice) if part)}


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--pack", required=True)
    parser.add_argument("--checkpoint", choices=CHECKPOINTS, required=True)
    parser.add_argument("--reviewer", required=True)
    parser.add_argument("--expected", required=True)
    parser.add_argument("--key", help="Existing personal Ed25519 private-key path, outside this checkout; never supply it to the portal")
    parser.add_argument("--email")
    parser.add_argument("--check-only", action="store_true")
    args = parser.parse_args(argv)
    try:
        prepared = snapshot(ROOT, args.pack, args.checkpoint)
        if prepared["digest"] != args.expected:
            raise Refused("The product changed since this command was prepared. Copy a fresh command from Resolve.")
        if args.reviewer not in prepared["reviewers"]:
            raise Refused("The named person has no review recorded in this checkpoint.")
        print(f"Product: {args.pack}\nReview checkpoint: {CHECKPOINTS[args.checkpoint]}\nReviewer: {args.reviewer}")
        for claim in prepared["claims"]:
            if claim["who"] == args.reviewer:
                print(f"  {claim['file']}: {claim['field']}")
        if args.check_only:
            print("Ready for the named reviewer's interactive setup. No files or identities changed.")
            return 0
        if not sys.stdin.isatty():
            raise Refused("Run this command yourself in an interactive terminal. The portal and unattended workers cannot sign your review.")
        email = args.email or input("Your email address: ").strip()
        key = Path(args.key).expanduser() if args.key else Path.home() / ".ssh" / ("rwd-review-" + _sha(args.reviewer.encode())[:12])
        print("Your existing registered private key stays outside the repository. Enrolment is handled separately by the reviewer and responsible administrator.")
        print("The helper makes one signed local commit containing only your review files. It does not create or register keys, authenticate a person, push or release a product.")
        def confirm(_preview):
            print("Exact review checkpoint digest: " + _preview["digest"])
            print("Pending changes in the files you are reviewing:")
            print(_preview["pending_diff"] or "No content changes; this records your new personal review of the existing records.")
            for relative, fields in _preview["restamped"].items():
                print(f"This signing also updates checksums in {relative} so your approval keeps describing the bytes it signs: " + ", ".join(fields))
            return input("If you are this reviewer and have reviewed these exact decisions, type REVIEWED to continue: ").strip() == "REVIEWED"
        result = perform(ROOT, prepared, args.reviewer, email, key, confirm=confirm)
        print(result["message"])
        print("Verified review commit: " + result["commit"])
        return 0
    except (Refused, OSError, ValueError, yaml.YAMLError, subprocess.SubprocessError) as error:
        print("Not completed: " + str(error), file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
