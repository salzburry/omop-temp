"""Inspect supplied JSON-LD without resolving contexts or contacting an RDF service.

This is a literal document view, not RDF normalization or SHACL validation. Only
explicit @id objects form edges; compact-context coercions and equivalence are
not inferred. Named-graph memberships and every supplied node statement remain
inspectable. Anonymous objects receive local display IDs, never external IRIs.
"""
from __future__ import annotations

from copy import deepcopy
import hashlib
import json

MAX_INPUT_BYTES = 8 * 1024 * 1024
MAX_DEPTH = 80


def _json(value):
    try:
        return json.dumps(value, ensure_ascii=False, sort_keys=True, allow_nan=False, separators=(",", ":"))
    except (TypeError, ValueError, RecursionError) as exc:
        raise ValueError("Graph documents must contain finite JSON-compatible values.") from exc


def _pairs(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError(f"Duplicate JSON key: {key}")
        result[key] = value
    return result


def _invalid_constant(token):
    raise ValueError(f"Invalid JSON constant: {token}")


def _decode(value, label):
    if isinstance(value, str):
        try:
            size = len(value.encode("utf-8"))
            if size > MAX_INPUT_BYTES:
                raise ValueError("Graph inspection accepts at most 8 MB of supplied JSON.")
            value = json.loads(value, object_pairs_hook=_pairs, parse_constant=_invalid_constant)
        except (UnicodeError, json.JSONDecodeError, RecursionError) as exc:
            raise ValueError(f"Cannot decode {label} JSON: {exc}") from exc
    else:
        if not isinstance(value, (dict, list)):
            raise ValueError(f"{label} must be a JSON object, array or JSON string.")
        try:
            size = len(_json(value).encode("utf-8"))
        except UnicodeError as exc:
            raise ValueError(f"Cannot decode {label} JSON: {exc}") from exc
    if not isinstance(value, (dict, list)):
        raise ValueError(f"{label} must contain a JSON object or array.")
    if size > MAX_INPUT_BYTES:
        raise ValueError("Graph inspection accepts at most 8 MB of supplied JSON.")
    return value, size


def _provenance(predicate):
    return (predicate.startswith(("prov:", "dct:", "dc:", "http://www.w3.org/ns/prov#",
                                 "https://www.w3.org/ns/prov#", "http://purl.org/dc/", "https://purl.org/dc/"))
            or predicate.rsplit("#", 1)[-1].rsplit("/", 1)[-1].rsplit(":", 1)[-1]
            in {"specRow", "specRef", "specRefs", "specDigest", "citation", "citations", "sourceRow", "sourceRef", "sourceRefs"})


def _label(node):
    for predicate in ("skos:prefLabel", "rdfs:label", "dct:title", "schema:name", "label", "name",
                      "http://www.w3.org/2004/02/skos/core#prefLabel", "http://www.w3.org/2000/01/rdf-schema#label"):
        value = node["properties"].get(predicate)
        for entry in value if isinstance(value, list) else [value]:
            if isinstance(entry, dict):
                entry = entry.get("@value")
            if isinstance(entry, str) and entry:
                return entry
    identifier = node["id"]
    return identifier.rsplit("#", 1)[-1].rstrip("/").rsplit("/", 1)[-1] or identifier


def _merge(properties, predicate, value):
    if predicate not in properties:
        properties[predicate] = deepcopy(value)
        return
    old = properties[predicate]
    if _json(old) == _json(value):
        return
    result, seen = [], set()
    for entry in (old if isinstance(old, list) else [old]) + (value if isinstance(value, list) else [value]):
        key = _json(entry)
        if key not in seen:
            seen.add(key)
            result.append(deepcopy(entry))
    properties[predicate] = result


def _inspect(document, scope):
    nodes, edges, edge_ids, reserved = {}, [], set(), set()
    pending = [(document, 0)]
    while pending:
        value, depth = pending.pop()
        if depth > MAX_DEPTH:
            raise ValueError(f"JSON-LD nesting exceeds {MAX_DEPTH} levels.")
        if isinstance(value, dict):
            if any(not isinstance(key, str) for key in value):
                raise ValueError("JSON-LD property names must be strings.")
            if "@id" in value:
                if not isinstance(value["@id"], str) or not value["@id"].strip():
                    raise ValueError("JSON-LD @id must be nonempty text.")
                reserved.add(value["@id"])
            if "@context" in value and value["@context"] is not None and not isinstance(value["@context"], (str, dict, list)):
                raise ValueError("JSON-LD @context must be text, an object, array or null.")
            pending.extend((child, depth + 1) for key, child in value.items() if key not in {"@context", "@value"})
        elif isinstance(value, list):
            pending.extend((child, depth + 1) for child in value)

    def ensure(identifier, anonymous=False):
        if identifier not in nodes:
            nodes[identifier] = {"id": identifier, "label": "", "type": "Reference", "properties": {}, "citations": [],
                                 "graph_memberships": [], "statements": [], "reference_only": True,
                                 "display_id_only": anonymous}
        return nodes[identifier]

    def edge(source, predicate, target):
        token = (source, predicate, target)
        if token not in edge_ids:
            edge_ids.add(token)
            edges.append({"source": source, "predicate": predicate, "target": target})

    def walk(value, path, graph_path=(), parent=None, predicate=None):
        if isinstance(value, list):
            for index, entry in enumerate(value):
                walk(entry, path + (index,), graph_path, parent, predicate)
            return
        if not isinstance(value, dict):
            if parent is None:
                raise ValueError("JSON-LD graph entries must be objects.")
            return
        if "@value" in value:
            if parent is None or any(key not in {"@value", "@type", "@language", "@direction", "@index"} for key in value):
                raise ValueError("Malformed JSON-LD literal object.")
            if "@type" in value and not isinstance(value["@type"], str):
                raise ValueError("A literal @type must be text.")
            if "@language" in value and (not isinstance(value["@language"], str) or "@type" in value):
                raise ValueError("Literal language must be text and cannot accompany a datatype.")
            if "@direction" in value and value["@direction"] not in ("ltr", "rtl"):
                raise ValueError("Literal direction must be ltr or rtl.")
            if isinstance(value["@value"], (dict, list)) and value.get("@type") != "@json":
                raise ValueError("Structured literal values require @type: @json.")
            return
        for container in ("@list", "@set"):
            if container in value:
                if parent is None or not isinstance(value[container], list) or set(value) - {container, "@index"}:
                    raise ValueError(f"Malformed JSON-LD {container} container.")
                walk(value[container], path + (container,), graph_path, parent, predicate)
                return
        if "@type" in value:
            types = value["@type"] if isinstance(value["@type"], list) else [value["@type"]]
            if not types or any(not isinstance(item, str) or not item for item in types):
                raise ValueError("JSON-LD @type must be text or a nonempty text array.")
        if "@graph" in value and not isinstance(value["@graph"], (dict, list)):
            raise ValueError("JSON-LD @graph must be an object or array.")
        regular = {key: item for key, item in value.items() if key not in {"@id", "@context", "@graph"}}
        identifier = value.get("@id")
        if not identifier and (regular or parent is not None):
            digest = hashlib.sha256(_json([scope, path, value]).encode("utf-8")).hexdigest()[:20]
            identifier = f"_:view_{scope}_{digest}"
            while identifier in reserved:
                identifier += "_"
            reserved.add(identifier)
        if identifier and (regular or "@graph" not in value or parent is not None):
            node = ensure(identifier, anonymous="@id" not in value)
            if parent is not None:
                edge(parent, predicate, identifier)
            if regular:
                node["reference_only"] = False
                graph = graph_path[-1] if graph_path else "@default"
                if graph not in node["graph_memberships"]:
                    node["graph_memberships"].append(graph)
                node["statements"].append({"graph": graph, "graph_path": list(graph_path), "properties": deepcopy(value)})
                for key, item in regular.items():
                    _merge(node["properties"], key, item)
                    if _provenance(key):
                        node["citations"].append({"predicate": key, "value": deepcopy(item), "graph": graph})
                    if key not in {"@type", "@index", "@reverse"}:
                        walk(item, path + (key,), graph_path, identifier, key)
                if "@reverse" in regular:
                    reverse = regular["@reverse"]
                    if not isinstance(reverse, dict):
                        raise ValueError("JSON-LD @reverse must be an object.")
                    for key, items in reverse.items():
                        for index, item in enumerate(items if isinstance(items, list) else [items]):
                            if not isinstance(item, dict) or "@id" not in item:
                                raise ValueError("Reverse links require explicit @id objects.")
                            walk(item, path + ("@reverse", key, index), graph_path)
                            edge(item["@id"], key, identifier)
        if "@graph" in value:
            nested_path = graph_path + (value["@id"],) if "@id" in value else graph_path
            walk(value["@graph"], path + ("@graph",), nested_path)

    walk(document, ())
    for node in nodes.values():
        value = node["properties"].get("@type", [])
        types = value if isinstance(value, list) else [value]
        node["type"] = ", ".join(dict.fromkeys(types)) if types else "Reference" if node["reference_only"] else "Object"
        node["label"] = _label(node)
    return list(nodes.values()), edges


def inspect_graph(graph: str | dict | list, shapes: str | dict | list):
    """Return an evidence-preserving view of two supplied JSON-LD documents.

    `edges` describes the data graph. `shape_nodes` includes supplied SHACL node,
    property and constraint objects, excluding reference-only vocabulary terms.
    `counts.shapes` counts these inspectable SHACL objects, not valid shapes.
    Repeated @id declarations retain all raw statements and graph memberships;
    properties provide a union for browsing. No context URL is ever fetched.
    """
    graph, graph_bytes = _decode(graph, "Graph")
    shapes, shape_bytes = _decode(shapes, "Shapes")
    if graph_bytes + shape_bytes > MAX_INPUT_BYTES:
        raise ValueError("Graph inspection accepts at most 8 MB of supplied JSON in total.")
    nodes, edges = _inspect(graph, "data")
    shape_nodes, _shape_edges = _inspect(shapes, "shape")
    shape_nodes = [node for node in shape_nodes if not node["reference_only"]]
    return {"nodes": nodes, "edges": edges, "shape_nodes": shape_nodes,
            "counts": {"nodes": len(nodes), "edges": len(edges), "shapes": len(shape_nodes)}}
