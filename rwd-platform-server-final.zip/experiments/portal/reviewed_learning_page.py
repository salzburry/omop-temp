"""Reviewed mapping labels and intake cases within the existing learning workflow."""
import hashlib
import json
from pathlib import Path

import pandas as pd
import streamlit as st
import model_lifecycle_workspace as workspace


def _review_fields(prefix):
    reviewer = st.text_input('Reviewed by', key=prefix + '_reviewer')
    date = st.text_input('Review date (YYYY-MM-DD)', key=prefix + '_date')
    why = st.text_area('Independent reason for these expected answers', key=prefix + '_why', max_chars=3000)
    confirmed = st.checkbox('I reviewed these exact inputs and expected answers and want to retain this case on my branch.', key=prefix + '_confirm')
    return reviewer, date, why, confirmed


def _identity(prefix):
    identifier = st.text_input('Case identifier', key=prefix + '_case', help='A stable name; use the same name to correct the same case.')
    family = st.text_input('Independent source or request family', key=prefix + '_family', help='Related deliveries or paraphrases belong in one family. Reserve the whole family in one split.')
    split = st.selectbox('Reserved case split', ['development', 'heldout'], index=None, key=prefix + '_split')
    return identifier, family, split


def _save(root, pack, actor_id, kind, case, report, prefix, *, allowed_packs, local_demo, can_review, permission):
    reviewer, date, why, confirmed = _review_fields(prefix)
    if st.button('Save reviewed case', key=prefix + '_save', disabled=not(permission and confirmed and reviewer and date and why)):
        try:
            workspace.save_reviewed_case(root, pack, actor_id, kind, case, reviewer, date, why,
                expected_digest=report['digest'], confirmed=confirmed, local_demo=local_demo, can_review=can_review, allowed_packs=allowed_packs)
            return {'route': 'model_lifecycle', 'params': {'objective_id': 'intake_elicitation_model' if kind == 'reviewed_intake_case' else 'mapping_candidate_ranker'}, 'changed': True}
        except (ValueError, OSError, KeyError, TypeError) as error:
            st.error(str(error))
    return None


def render_mapping(root, pack, actor_id, report, *, allowed_packs, local_demo, can_review, permission):
    prefix = 'model_lifecycle_mapping'
    st.write('Review accepted mapping decisions, then compare the existing pairwise ranker against the deterministic mapping order. No mapping or learned version is applied here.')
    labels = workspace.reviewed_cases(report, 'reviewed_mapping_label')
    st.caption(f'{len(labels)} reviewed mapping decision(s). Measurement requires 30 development cases across 3 source families and 10 heldout cases across 2 different families.')
    with st.expander('Record an accepted mapping decision', expanded=not labels):
        st.caption('Use real mapping review evidence. The accepted table must contain every required column; unresolved mappings do not supply positive labels. The evidence file and exact candidates stay attached to this local review.')
        identifier, family, split = _identity(prefix)
        files = sorted(path.relative_to(Path(root)).as_posix() for path in (Path(root) / pack).rglob('*')
            if path.is_file() and path.suffix.lower() in {'.json', '.yaml', '.md'} and '.portal-drafts' not in path.parts and 'model_lifecycle' not in path.parts)[:200]
        evidence = st.selectbox('Reviewed mapping evidence file', files, index=None, key=prefix + '_evidence')
        evidence_sha = ''
        if evidence:
            path = Path(root) / evidence
            if path.resolve() == path and path.stat().st_size <= 2_000_000:
                evidence_sha = hashlib.sha256(path.read_bytes()).hexdigest()
                st.caption('Exact evidence SHA256: ' + evidence_sha)
        tokens = st.text_input('Logical role tokens (comma separated)', key=prefix + '_tokens')
        required = st.text_input('Required columns (comma separated)', key=prefix + '_columns')
        table = st.data_editor(pd.DataFrame([{'name': '', 'columns': '', 'kind_match': None}]), num_rows='dynamic', hide_index=True,
            key=prefix + '_candidates', column_config={'name': st.column_config.TextColumn('Candidate table'),
                'columns': st.column_config.TextColumn('Declared columns, comma separated'), 'kind_match': st.column_config.CheckboxColumn('Reviewed kind match')})
        candidates = [{'name': str(row.get('name') or '').strip(), 'columns': [part.strip() for part in str(row.get('columns') or '').split(',') if part.strip()],
            'kind_match': row.get('kind_match')} for row in table.to_dict('records') if str(row.get('name') or '').strip()]
        names = list(dict.fromkeys(row['name'] for row in candidates))
        accepted = st.selectbox('Table accepted in the reviewed decision', names, index=None, key=prefix + '_accepted')
        case = {'case_id': identifier, 'source_group': family, 'split': split,
            'evidence': {'path': evidence, 'sha256': evidence_sha}, 'role_tokens': [part.strip() for part in tokens.split(',') if part.strip()],
            'required_columns': [part.strip() for part in required.split(',') if part.strip()], 'candidates': candidates, 'accepted_candidate': accepted}
        changed = _save(root, pack, actor_id, 'reviewed_mapping_label', case, report, prefix,
            allowed_packs=allowed_packs, local_demo=local_demo, can_review=can_review, permission=permission)
        if changed:
            return changed
    if labels:
        st.dataframe([{'Case': row['case']['case_id'], 'Family': row['case']['source_group'], 'Split': row['case']['split'], 'Reviewer': row['reviewed_by']} for row in labels], hide_index=True)
        st.download_button('Download reviewed labels for the existing trainer', json.dumps({'version': 1, 'labels': labels}, indent=2), file_name='reviewed-mapping-labels.json', key=prefix + '_export')
    confirmed = st.checkbox('Evaluate the current reviewed mapping labels and retain the measured result.', key=prefix + '_measure_confirm')
    if st.button('Measure mapping order', key=prefix + '_measure', disabled=not(permission and confirmed)):
        try:
            result = workspace.evaluate_mapping_labels(root, pack, actor_id, expected_digest=report['digest'], confirmed=confirmed,
                local_demo=local_demo, can_review=can_review, allowed_packs=allowed_packs)
            return {'route': 'model_lifecycle', 'params': {'objective_id': 'mapping_candidate_ranker', 'evaluation_id': result['id']}, 'changed': True}
        except (ValueError, OSError) as error:
            st.error(str(error))
    for result in [row for row in report['evaluations'] if row.get('record_type') == 'reviewed_mapping_evaluation'][:5]:
        with st.expander('Mapping measurement · ' + result['created_at']):
            st.json(result['measurement'])
            st.caption('This preserves the fitted parameters only when they exceed the frozen deterministic baseline. There is no activation action for this measurement.')
    return None


def render_intake(root, pack, actor_id, report, *, allowed_packs, local_demo, can_review, permission):
    import intake
    prefix = 'model_lifecycle_intake_cases'
    st.write('Record stakeholder messages and independently reviewed expected slot fills. The existing intake engine runs one turn; its expected answers stay outside the model prompt.')
    labels = workspace.reviewed_cases(report, 'reviewed_intake_case')
    if not labels:
        st.info('No reviewed intake slot-filling corpus exists for this product yet. Add a human-authored case below; example text and synthetic regression scores are not substituted for reviewed answers.')
    with st.expander('Review an intake example', expanded=not labels):
        identifier, family, split = _identity(prefix)
        domain = st.selectbox('Existing intake domain', list(intake.domains()), index=None, key=prefix + '_domain')
        message = st.text_area('Exact stakeholder message', key=prefix + '_message', max_chars=4000)
        case = None
        if domain:
            data = [{'slot': slot['id'], 'question': slot['ask'], 'before': '', 'expected': ''} for slot in intake.domains()[domain]['slots']]
            table = st.data_editor(pd.DataFrame(data), hide_index=True, disabled=['slot', 'question'], key=prefix + '_slots_' + domain,
                column_config={'before': st.column_config.TextColumn('Value before this message'), 'expected': st.column_config.TextColumn('Expected value after this message')})
            st.caption('Blank means explicitly unanswered. Preserve a prior value in the expected column when this message should not change it. Literal text is compared exactly; a person adjudicates equivalent wording.')
            def slot_value(value):
                return None if value is None or pd.isna(value) else str(value).strip() or None
            initial = {row['slot']: slot_value(row['before']) for row in table.to_dict('records')}
            expected = {row['slot']: slot_value(row['expected']) for row in table.to_dict('records')}
            extra = st.text_area('Expected unsupported requirements (JSON object, if any)', value='{}', key=prefix + '_extra')
            try:
                extras = json.loads(extra)
            except (ValueError, RecursionError):
                extras = None
            case = {'case_id': identifier, 'source_group': family, 'split': split, 'domain': domain,
                'message': message, 'initial': initial, 'expected': expected, 'expected_extra': extras}
        changed = _save(root, pack, actor_id, 'reviewed_intake_case', case, report, prefix,
            allowed_packs=allowed_packs, local_demo=local_demo, can_review=can_review, permission=permission)
        if changed:
            return changed
    options = workspace.intake_case_options(root, pack, actor_id, allowed_packs=allowed_packs)
    group = st.selectbox('Intake case group', ['development', 'heldout'], key=prefix + '_group')
    choices = {row['case']['case_id']: row for row in labels if row['case']['split'] == group}
    if any(value not in choices for value in st.session_state.get(prefix + '_selected', [])):
        st.session_state[prefix + '_selected'] = []
    selected = st.multiselect('Reviewed intake cases to evaluate', list(choices), max_selections=3, key=prefix + '_selected')
    st.caption('Whole request families stay in one split. Repeating a heldout evaluation is a retest, not newly unseen evidence. No model/provider switch is inferred.')
    config = options['connection']
    if not config['ok']:
        st.info(config['errors'][0])
    if st.button('Preview reviewed intake cases', key=prefix + '_preview', disabled=not(permission and selected and config['ok'])):
        try:
            st.session_state[prefix + '_proposal'] = workspace.preview_cases(root, pack, actor_id, 'intake_elicitation_model', selected, allowed_packs=allowed_packs)
            st.session_state[prefix + '_run_confirm'] = False
        except (ValueError, OSError) as error:
            st.error(str(error))
    proposal = st.session_state.get(prefix + '_proposal')
    if proposal:
        stale = proposal['connection'] != config or proposal['corpus_digest'] != options['corpus_digest'] or [row['case']['case_id'] for row in proposal['cases']] != selected
        with st.expander('Exact reviewed intake cases and selected connection', expanded=True):
            st.json(proposal)
        confirmed = st.checkbox('Run these exact reviewed intake cases with the selected assistant and retain their slot scores.', key=prefix + '_run_confirm')
        if st.button('Run reviewed intake cases', key=prefix + '_run', disabled=not(permission and confirmed and not stale)):
            try:
                result = workspace.run_cases(root, pack, actor_id, proposal, confirmed=confirmed, local_demo=local_demo, can_review=can_review, allowed_packs=allowed_packs)
                st.session_state.pop(prefix + '_proposal', None)
                return {'route': 'model_lifecycle', 'params': {'objective_id': 'intake_elicitation_model', 'evaluation_id': result['id']}, 'changed': True}
            except (ValueError, OSError, KeyError, TypeError) as error:
                st.error(str(error))
    for result in [row for row in report['evaluations'] if row.get('record_type') == 'intake_case_evaluation'][:5]:
        with st.expander('Intake slot results · ' + result['created_at'], expanded=True):
            st.write(result['notice'])
            st.caption('Selected model: ' + result['connection']['model'])
            st.dataframe([{'Case': row['case_id'], 'Literal pass': row['score']['passed'], 'Correct new slots': row['score']['correct_new_slots'],
                'Wrong-slot rate': row['score']['wrong_slot_rate'], 'Calls': row['calls'], 'Elapsed seconds': row['elapsed_seconds'], 'Error': row['error'] or ''} for row in result['results']], hide_index=True)
            st.json(result['results'])
            st.download_button('Download exact intake expectations and outcomes', json.dumps(result, indent=2), file_name=result['id'] + '.json', key=prefix + '_download_' + result['id'])
    if st.button('Open the request conversation', key='model_lifecycle_intake'):
        return {'route': 'governed_check', 'params': {'mode': 'intake', 'objective_id': 'intake_elicitation_model'}}
    return None
