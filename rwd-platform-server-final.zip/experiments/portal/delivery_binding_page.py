"""Literal delivery bindings, impact, checked draft, then evidence."""
import streamlit as st

import delivery_binding as backend
import source_workspace as workspace
import form_assistance as form_help

PREFIX = "source_ws_delivery_form_"


def _errors(result):
    for error in result.get("errors", []):
        st.error(error)
    return not result.get("ok")


def render(root, pack, actor_id, *, allowed_packs=None, local_demo=False, can_write=False, params=None, **_):
    read_args = dict(root=root, pack=pack, actor_id=actor_id, allowed_packs=allowed_packs)
    arguments = read_args | dict(local_demo=local_demo, can_write=can_write)
    enabled = local_demo is True and can_write is True
    description = backend.describe(**read_args)
    if _errors(description):
        return None
    st.write("Declare where this product's source tables will be read. Ask the data expert for the schema, delivery cut and actual table stems; a plausible name does not establish that a table exists.")
    st.caption(backend.NOTICE)
    if not description["supported"]:
        for blocker in description["blockers"]:
            st.warning(blocker)
        st.write("Take the requirements and existing delivery configuration to the data expert or Engineering. Union members, new source roles, layout changes and adapter bindings need their existing review workflow.")
        from source_workspace_page import _ask
        _ask(arguments, action_id="source_delivery_unsupported", label="Review the unsupported delivery declaration",
             owner="Engineering", note=" ".join(description["blockers"]), key="source_ws_delivery_unsupported")
        if st.button("Review delivered source mappings", key=PREFIX + "mapping"):
            return {"route": "source_mapping", "params": {}}
        if st.button("Read the source requirements", key=PREFIX + "requirements"):
            return {"route": "source_requirements", "params": {}}
        return None
    if not enabled:
        st.info("Inspect the declaration here. Saving requires local editing access.")
    initial = description["values"]
    params = params or {}
    selected = params.get("id") or params.get("proposal_id")
    if selected and st.session_state.get(PREFIX + "parameter") != selected:
        saved = workspace.read(**read_args, record_id=selected)
        if not _errors(saved) and saved["record"]["route"] == backend.ROUTE:
            st.session_state[PREFIX + "id"] = selected
            st.session_state[PREFIX + "parameter"] = selected
            if not saved["stale"]:
                initial = saved["record"]["payload"]["values"]
                for name, value in initial.items():
                    st.session_state[PREFIX + "value_" + name] = value
                st.session_state[PREFIX + "digest"] = description["inputs_sha256"]
    st.session_state.setdefault(PREFIX + "digest", description["inputs_sha256"])
    form_stale = st.session_state[PREFIX + "digest"] != description["inputs_sha256"]
    if form_stale:
        st.warning("The product changed while this form was open. Reload its current delivery before staging another proposal.")
        if st.button("Reload current delivery", key=PREFIX + "reload"):
            for key in list(st.session_state):
                if key.startswith(PREFIX):
                    del st.session_state[key]
            st.rerun()
    st.markdown("**1 · Identify the delivery**")
    values = {}
    for name in ("schema", "cut"):
        item = description["fields"][name]
        values[name] = form_help.field(st.text_input, item["label"], "" if workspace._stem_unstated(initial[name]) else initial[name], binding=description["inputs_sha256"],
                                    key=PREFIX + "value_" + name, disabled=not enabled,
                                    help=("Schema or catalog.schema containing this delivery, for example research_source. Use the delivered value, not a file path."
                                          if name == "schema" else "The exact suffix/token identifying this delivery, for example 2026m06. It is not the specification version or an invented date."))
    st.caption("Active format: " + str(description["data_format"]) + ". Existing table-name layout: " + description["layout"])
    st.markdown("**2 · Declare the table for each existing role**")
    st.write("Enter the part used as the table stem by the displayed layout. For example, under {schema}.{stem}_{refresh}, a delivered table research_source.t_enh_demo_2026m06 has stem t_enh_demo. Retain the vendor's spelling and do not append the cut twice.")
    for name, item in description["fields"].items():
        if not name.startswith("source:"):
            continue
        values[name] = form_help.field(st.text_input, item["label"], "" if workspace._stem_unstated(initial[name]) else initial[name], binding=description["inputs_sha256"],
                                    key=PREFIX + "value_" + name, disabled=not enabled,
                                    help="This is the existing logical role's table stem. The current format and naming layout are preserved. Required columns and consumers appear in the review below.")
    with st.expander("A source role or delivery layout needs a different change"):
        st.write("If a declared table is not delivered, do not point the role at an unrelated table. Adding or removing roles, accepting source absence, changing a layout or combining schemas needs its own scientific and Engineering review.")
        from source_workspace_page import _ask
        _ask(arguments, action_id="source_delivery_scope", label="Review a source-role or delivery-layout change",
             owner="Engineering", note="Please review the required source-role or delivery-layout change for this product. State the affected roles, observed delivery and unresolved scientific impact before implementation.",
             key="source_ws_delivery_scope")
    if st.button("Stage delivery diff and run validators", key=PREFIX + "stage", disabled=not enabled or form_stale):
        with st.spinner("Checking the proposed delivery against the current configuration and scientific records…"):
            result = backend.stage(**arguments, values=values, expected_digest=st.session_state[PREFIX + "digest"])
        if not _errors(result):
            st.session_state[PREFIX + "id"] = result["record"]["id"]
    record_id = st.session_state.get(PREFIX + "id")
    if record_id:
        saved = workspace.read(**read_args, record_id=record_id)
        if _errors(saved):
            return None
        record, payload = saved["record"], saved["record"]["payload"]
        st.markdown("**3 · Review the exact change and remaining findings**")
        st.write(payload["summary"])
        for file in payload["files"]:
            st.code(file["diff"], language="diff")
        st.dataframe([{"Role": item["role"], "Current table": item["before"], "Proposed table": item["after"],
                       "Engine reads": "yes" if item["engine_reads"] else "no declared read",
                       "Required columns": workspace._column_words(item["required_columns"]),
                       "Expected grain": "not declared yet" if item["expected_grain"] in ("", "(not declared)") else item["expected_grain"],
                       "When absent": workspace._dashless(item["when_absent"]),
                       "Read by": ", ".join(item["read_by_blocks"]),
                       "Required by": ", ".join(item["required_by_variables"])} for item in payload["impact"]],
                     hide_index=True, width="stretch")
        if not payload["consumer_links_complete"]:
            st.info("Consumer links are incomplete or absent in the current scientific contract. Empty cells do not establish that there is no impact.")
        st.caption("Impact lists declared links only. A missing or incomplete scientific record may hide additional consumers.")
        st.write("Changing the delivery requires fresh source evidence and runtime checks for every affected role. Study exclusions and scientific definitions are separate records; no scientific meaning is inferred from a table name.")
        if not payload["all_checks_passed"]:
            st.warning("The full configuration/scientific checks have not passed. Identical pre-existing findings remain unresolved; saving only the delivery declaration does not clear them.")
        for check in payload["checks"]:
            with st.expander(check["validator"] + (": passed" if check["passed"] else ": unresolved findings")):
                for error in check["errors"]:
                    st.write(error)
                if check.get("note"):
                    st.caption(check["note"])
        for error in payload["new_errors"]:
            st.error("New or unreadable validator finding: " + error)
        stale = saved["stale"] or payload["values"] != values
        if stale:
            st.warning("This preview no longer matches the current form or product. Stage and review the current answers before saving.")
        if record["state"] == "delivery_saved_pending_review":
            st.success("Draft delivery saved. Source and scientific review remain pending.")
            if st.button("Prepare evidence for this delivery", key=PREFIX + "evidence"):
                return {"route": "source_evidence", "params": {}}
        else:
            confirmed = st.checkbox("I reviewed this delivery diff and its unresolved findings and want to save the draft declaration.",
                                    key=PREFIX + "confirm_" + record_id, disabled=not enabled or stale or not payload["can_save"])
            if st.button("Save reviewed delivery draft", key=PREFIX + "save", disabled=not enabled or stale or not payload["can_save"] or not confirmed):
                with st.spinner("Rechecking the reviewed diff before saving this draft…"):
                    result = backend.save(**arguments, record_id=record_id, confirmed=confirmed)
                if not _errors(result):
                    st.session_state[PREFIX + "digest"] = result["record"]["inputs_sha256"]
                    if result.get("warning"):
                        st.session_state["source_ws_warning"] = result["warning"]
                        return {"route": "source_evidence", "params": {}, "changed": True}
                    return {"route": backend.ROUTE, "params": {"id": record_id}, "changed": True}
    return None
