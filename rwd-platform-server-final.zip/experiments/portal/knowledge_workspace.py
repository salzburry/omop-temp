"""A scoped, read-only shelf of the repository's existing knowledge graphs.

Canonical readers run in a disposable metadata checkout. No reader sees another
product merely because a cross-product register points there, and no graph edge
creates clinical equivalence, adoption, approval or a release.
"""
from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile

MAX_ITEMS = 250
KINDS = {"definition": "Scientific definitions", "name": "Output names", "decision": "Product decisions",
         "clinical_concept": "Clinical template concepts", "capability": "Implementation capabilities",
         "inventory": "Reference inventory", "citation": "Citation provenance", "precedent": "Decision precedents"}
NOTICE = "These are different kinds of evidence. A shared name, shape or citation does not establish equivalent clinical meaning. Reading or reusing a draft does not transfer approval."


def _failure(error):
    if isinstance(error, OSError):
        message = "The knowledge metadata could not be read. Check the repository location and your product access."
    else:
        message = str(error)
    return {"ok": False, "errors": [message], "items": [], "notice": NOTICE}


def _snapshot(root, pack, actor_id, allowed_packs):
    import science_workspace as science
    import scientific_definitions as definitions
    import yaml
    base, pack, owner, _folder, scope = science._scope(root, pack, actor_id, allowed_packs)
    try:
        for target in scope:
            definitions._scope(base, target, actor_id, scope)
        files = science._inputs(base, scope)
        capabilities = yaml.safe_load(files.get("platform/capabilities.yaml", b"{}")) or {}
        references = set()
        for capability in capabilities.get("capabilities") or []:
            references.update(row.get("module") for row in capability.get("python") or [])
            references.update(row.get("file") for row in capability.get("r") or [])
            references.update(str(row).partition("::")[0] for row in capability.get("tests") or [])
        for reference in references:
            source = science.CODE_ROOT / str(reference or "")
            if (not isinstance(reference, str) or Path(reference).is_absolute() or ".." in Path(reference).parts
                    or not source.is_relative_to(science.CODE_ROOT / "platform")):
                raise ValueError("A capability names evidence outside the platform metadata. Repair its declared path before loading knowledge.")
            science._safe(source)
            if source.is_file():
                files[reference] = source.read_bytes()
    except yaml.YAMLError:
        raise ValueError("A knowledge input is not readable YAML. Repair its metadata before reloading.") from None
    # A precedent is a set of product pointers. Only whole, visible entries can
    # be compared; dropping one sighting would manufacture a different claim.
    name = "governance/precedents.yaml"
    if name in files:
        try:
            doc = yaml.safe_load(files[name])
            if not isinstance(doc, dict) or not isinstance(doc.get("precedents"), list):
                raise ValueError
            visible = []
            for entry in doc["precedents"]:
                if not isinstance(entry, dict) or not isinstance(entry.get("seen_in"), list) or not entry["seen_in"]:
                    raise ValueError
                if all(isinstance(ref, dict) and ref.get("pack") in scope for ref in entry["seen_in"]):
                    visible.append(entry)
            files[name] = yaml.safe_dump({"precedents": visible}, sort_keys=False).encode()
        except (ValueError, TypeError, yaml.YAMLError):
            raise ValueError("The shared precedent index needs repair before scoped knowledge can be loaded.") from None
    digest = science._hash({"actor": owner, "pack": pack, "scope": sorted(scope), "files": science._digest(files)})
    return base, pack, scope, files, digest


def freshness(root, pack, actor_id, *, expected_digest, allowed_packs):
    try:
        *_rest, digest = _snapshot(root, pack, actor_id, allowed_packs)
        return {"ok": True, "stale": digest != expected_digest, "errors": []}
    except (OSError, ValueError, TypeError, KeyError, AttributeError) as error:
        return _failure(error)


def _run(files, request):
    with tempfile.TemporaryDirectory(prefix="knowledge-review-") as temporary:
        staged = Path(temporary).resolve()
        for name, raw in files.items():
            target = staged / name
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes(raw)
        result = subprocess.run([sys.executable, str(Path(__file__).resolve()), "--worker"],
            input=json.dumps({**request, "root": str(staged)}), capture_output=True, text=True,
            encoding="utf-8", errors="replace", cwd=staged, timeout=90,
            env={**os.environ, "PYTHONUTF8": "1", "PYTHONDONTWRITEBYTECODE": "1"})
        if result.returncode:
            raise ValueError("The canonical knowledge readers could not complete. Review the repository metadata before reloading.")
        if len(result.stdout) > 8 * 1024 * 1024:
            raise ValueError("This knowledge result is too large. Search for a narrower requirement or name.")
        value = json.loads(result.stdout)
        # Canonical readers sometimes return their own root in a diagnostic.
        return json.loads(json.dumps(value).replace(str(staged).replace("\\", "\\\\"), "<knowledge snapshot>")
                          .replace(staged.as_posix(), "<knowledge snapshot>"))


def describe(root, pack, actor_id, *, allowed_packs, query="", kind="all"):
    try:
        if not isinstance(query, str) or len(query) > 200 or any(ord(char) < 32 for char in query):
            raise ValueError("Use a short name or phrase to search the knowledge metadata.")
        if kind != "all" and kind not in KINDS:
            raise ValueError("Choose an available knowledge type.")
        base, pack, scope, files, digest = _snapshot(root, pack, actor_id, allowed_packs)
        result = _run(files, {"pack": pack, "scope": sorted(scope), "query": query.strip(), "kind": kind})
        if _snapshot(base, pack, actor_id, scope)[-1] != digest:
            raise ValueError("Knowledge inputs or access context changed while loading. Reload before choosing a continuation.")
        return {"ok": True, "errors": [], "pack": pack, "query": query.strip(), "kind": kind,
                "input_digest": digest, "notice": NOTICE, **result}
    except (OSError, ValueError, TypeError, KeyError, AttributeError, subprocess.TimeoutExpired) as error:
        return _failure(error)


def _worker(request):
    root = Path(request["root"])
    sys.path[:0] = [str(root / "platform/tools"), str(root / "platform/engine"), str(root / "platform")]
    import knowledge_search as search
    import knowledge_graph as graph
    import contract_lint as cl
    import rule_review as rules
    import naming_registry as names
    import oncology_registry as oncology
    import product_gates as gates
    from spec_extract import requirement_rows, is_context, row_item_id

    pack, scope = request["pack"], set(request["scope"])
    query, wanted = request["query"].lower(), request["kind"]
    terms = query.split()
    items, problems = [], []
    unusable = search.surface_errors(str(root))
    for kind, findings in unusable.items():
        problems.append({"surface": kind, "finding": "\n".join(str(finding) for finding in findings)})

    def action(label, route, params=None, target=None):
        result = {"label": label, "route": route, "params": params or {}}
        if target and target != pack:
            result["pack"] = target
        return result

    def add(kind, key, title, source, state, summary, *, details=None, citations=None, links=None, actions=None):
        hay = json.dumps([title, summary, details, citations, source], ensure_ascii=False, default=str).lower()
        if wanted not in {"all", kind} or not all(term in hay for term in terms):
            return
        items.append({"id": hashlib.sha256(json.dumps([kind, source, key]).encode()).hexdigest()[:24],
                      "kind": kind, "title": str(title), "source": str(source), "state": str(state), "summary": str(summary),
                      "details": details or {}, "citations": citations or [], "links": links or [], "actions": actions or []})

    source_rows, records, by_variable, blocks_by_pack = {}, {}, {}, {}
    for target in sorted(scope):
        path = root / target / "spec_pipeline/out/extracted.json"
        rows = requirement_rows(json.loads(path.read_bytes())) if path.is_file() else []
        source_rows[target] = [{"item_id": row_item_id(row), "variable": str(row["variable"])}
                               for row in rows if row.get("variable") and not is_context(row)]
        contract = root / target / "handoff/FUNCTIONAL_CONTRACT.md"
        if not contract.is_file():
            # New and scaffolded cuts legitimately have no contract yet. The
            # canonical chain reader treats this as empty; do not follow it
            # with an unconditional read that takes every other cut offline.
            records[target], blocks_by_pack[target] = [], []
            problems.append({"surface": "contract_record", "source": target,
                "finding": target + " has no scientific definition record yet. Open its Scientific definitions step to draft the requirements. Other accessible evidence remains searchable."})
            continue
        if "contract_record" in unusable:
            continue
        records[target] = rules.chain(str(root / target))
        text = cl.read(str(contract))
        blocks_by_pack[target] = list(cl.records(text))
        for record in records[target]:
            by_variable.setdefault(record["variable_id"], []).append((target, record))
    current_rows = source_rows.get(pack, [])

    def current_match(variable):
        candidates = [row for row in current_rows if row["variable"] == variable]
        return candidates[0] if len(candidates) == 1 else None

    for target, values in records.items():
        for record in values:
            variable = record["variable_id"]
            refs = record["spec"]["refs"]
            exact = [row for row in source_rows[target] if row["item_id"] in refs]
            params = {"variable": variable}
            if len(exact) == 1:
                params["item_id"] = exact[0]["item_id"]
            links = [{"relation": "cites decision", "target": did, "source": target} for did in record["decisions"]]
            for block in blocks_by_pack[target]:
                if variable in (cl._list(block, "depends_on") or []):
                    links.append({"relation": "consumed by definition", "target": cl._scalar(block, "variable_id"), "source": target})
            links += [{"relation": "declares implementation", "target": ref, "source": target} for ref, _ in record["executable"]]
            actions = [action("Trace this definition and its consumers", "variable_lineage", params, target)]
            if target == pack and len(exact) == 1:
                actions.append(action("Review this scientific definition", "scientific_draft", {"item_id": exact[0]["item_id"]}))
            match = current_match(variable)
            if match:
                actions.append(action("Compare reuse for the current requirement", "definition_reuse", {"item_id": match["item_id"], "variable": variable}))
            add("definition", variable, variable, target, "Recorded requirement and implementation status",
                record["derivation"] or "No interpretation recorded.", details=record, citations=refs, links=links, actions=actions)

    if "decision" not in unusable:
        nodes = graph.build(str(root))
        for node in nodes:
            if node["pack"] not in scope:
                continue
            state = "Attribution recorded; not authenticated here" if graph.ruled(node) else (
                "Answered without complete attribution" if graph.resolved_unsigned(node) else node["status"] or "No recorded status")
            add("decision", node["id"], node["id"] + " · " + node["question"], node["pack"], state,
                node["answer"] or "No answer recorded.", details=node,
                citations=[node["pack"] + "/handoff/DECISIONS.md#" + node["id"]],
                links=[{"relation": "cited by definition", "target": variable, "source": node["pack"]} for variable in node["cited_by"]],
                actions=[action("Open this recorded question", "questions", {"decision_id": node["id"]}, node["pack"])])

    registry = names.registry(str(root))
    for name, entry in registry.items():
        prior = [{"pack": target, "variable": record["variable_id"], "rule": record["derivation"], "spec_refs": record["spec"]["refs"]}
                 for target, blocks in blocks_by_pack.items() for block in blocks
                 if (cl._kv(cl._inline(block, "output"), "physical_name") or "").lower() == name
                 for record in records.get(target, []) if record["variable_id"] == cl._scalar(block, "variable_id")]
        add("name", name, name, "Accessible output-name registry", "Spelling and declared output metadata; not concept equivalence",
            "Read the prior definitions before proposing this output name.", details={"registry": entry, "prior_definitions": prior},
            links=[{"relation": "named by definition", "target": value["variable"], "source": value["pack"]} for value in prior],
            citations=[value["pack"] + "/handoff/FUNCTIONAL_CONTRACT.md" for value in prior],
            actions=[action("Trace " + value["variable"] + " in its product", "variable_lineage", {"variable": value["variable"]}, value["pack"]) for value in prior[:8]])

    catalogue = oncology.catalogue()
    modules, module_errors = oncology.load_modules()
    for finding in module_errors:
        problems.append({"surface": "clinical_concept", "finding": finding})
    if not module_errors:
        for finding in oncology.registry_errors(catalogue, modules):
            problems.append({"surface": "clinical_concept", "finding": finding})
        slug = oncology.overlay_slug(pack.split("/")[2], catalogue)
        if slug in catalogue:
            for entry in oncology.assemble(slug, catalogue, modules):
                slot = oncology.slot_name(entry)
                concept = oncology.concepts_of(entry).get(slug, {})
                realises = oncology.realised(entry, slug)
                links = [{"relation": "declared library realisation", "target": variable, "source": "reference inventory:" + slug} for variable in realises]
                actions = []
                for variable in realises:
                    match = current_match(variable)
                    if match:
                        params = {"variable": variable, "item_id": match["item_id"]}
                        actions += [action("Review template relation for " + variable, "template_review", params),
                                    action("Review clinical binding for " + variable, "clinical_standards", params),
                                    action("Review shared-library promotion and adoption", "template_library", params)]
                if not actions:
                    actions = [action("Review this product's template worklist", "template_review")]
                add("clinical_concept", slot, str(concept.get("concept") or slot), "Shared clinical library · " + entry["module"],
                    "Module review recorded" if entry["module_reviewed"] else "Candidate module; scientific review pending",
                    str(concept.get("definition") or entry.get("definition") or entry.get("clinical_role") or "Read the declared slot and cancer-specific concept separately."),
                    details={"slot": slot, "cancer": slug, "concept": concept, "entry": entry},
                    citations=concept.get("citations") or entry.get("citations") or [], links=links, actions=actions)
        else:
            problems.append({"surface": "clinical_concept", "finding": "This product has no clinical template catalogue entry. Its definition and naming evidence remain searchable."})

    # Federated evidence keeps the canonical domain/state vocabulary and its own
    # validator refusals. Blank browsing never invents a search match.
    if terms:
        for hit in search.search(terms, kinds=["capability", "inventory", "citation", "precedent"], root=str(root), unusable=unusable):
            add(hit["kind"], hit["id"], hit["title"] or hit["id"], hit["where"], hit["domain"] + " · " + hit["state"],
                hit["detail"], details=hit, citations=[hit["where"]])
    counts = {kind: sum(item["kind"] == kind for item in items) for kind in KINDS}
    items.sort(key=lambda item: (list(KINDS).index(item["kind"]), item["title"].casefold(), item["source"]))
    return {"items": items[:MAX_ITEMS], "total": len(items), "counts": counts, "truncated": len(items) > MAX_ITEMS,
            "problems": problems, "search_needed": not bool(terms), "scope": sorted(scope)}


if __name__ == "__main__" and "--worker" in sys.argv:
    try:
        print(json.dumps(_worker(json.load(sys.stdin)), ensure_ascii=False, default=str))
    except BaseException:
        sys.exit(1)
