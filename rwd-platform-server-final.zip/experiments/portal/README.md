# RWD Portal

The Streamlit portal is the starting point for an epidemiologist or biostatistician
planning a data product. It shows the current blocker, the evidence behind it, and the
person or action needed next. Normal product status, definition review, search and
change planning do not need an AI API key.

With an assistant connected, ask it to prepare the current form: for example,
**“Create a GIST product 202606”** or **“Set the vendor to flatiron and modality to ehr.”**
Chat uses the existing draft fields and their choices. Empty fields fill directly;
replacing an existing entry shows a before-and-after review first. Previewing,
saving, validating and approving remain the form's explicit actions. See
[chat-assisted form entry](../../docs/CHAT_FORM_PREFILL_20260908.md) for coverage and limits.

After selecting a workbook on **New product**, use **Choose which sheets belong
in this product** to leave out additional sheets such as **9.PROC PSOC Strategy**.
Select its exact name and give a short reason, or ask the connected assistant to
prepare those fields. **Preview the plan** shows the scope change. The original
workbook and source trace remain intact; the extraction excludes the selected
sheets for this product only. Revised specifications need a fresh scope choice.
Mapped scientific sections use **Plan changes** after creation; exclusions needed
by just one study use **Studies**. Source classification and review still apply.

The main product chat belongs to the current profile and product in this checkout.
In local workspace/demo mode its last eight question-and-answer turns are saved
under the private portal state directory and return after a refresh or new browser
session. Local Git attribution and the demo identity picker are not authentication;
hosted chat uses the resolved signed-in identity and remains browser-session history.
The separate **Agent** page also separates profiles and products, with session-only history.

Use **Clear this conversation** to remove this profile's current product messages
and pending suggestions, including its saved local transcript. This keeps running
tasks, form entries, product records, other conversations and saved setup snapshots.
Other open browsers pick up the clear on their next page update; an older pending
answer cannot restore the cleared transcript.

When product setup fails, use its recovery panel to **Edit setup inputs**, open
the named step, or **Ask chat to help resolve this error**. The assistant receives
the current findings and editable field context. **Preview setup again** checks
the current form once; writing still requires a successful preview and an explicit
**Write**. Changed-file refusals identify the affected inputs instead of treating
every refusal as a workbook error.

Product creation runs as a saved local job. Clearing chat, refreshing, or leaving
the page keeps staging active; return to **New product** to see its result. If the
form changes while a write is running, completion stays bound to the submitted
inputs and preserves the newer draft.

**Check your setup** compares a known tumour with the workbook's population
wording and the existing catalogue. A different disease or contradictory tumour
class must be corrected before Preview. **Review catalogue suggestions** uses
the normal before-and-after form review; it does not change the data modality or
make source-classification declarations for you.

In **Draft the scientific definition**, use the progress counts and row filter to
find **Untouched**, **Draft**, **Checked** or **Unresolved** work. **Next unfinished
row** keeps your current typing while moving on. Save row drafts to return after
a restart. Checked rows still need the product's scientific review.

Source review offers compatible completed profiles and returned checks by delivery
name. Choose the evidence, receive it, review the diff and use the existing save
action. If no matching evidence exists, the page names the request or engineering
return needed next. A changed file needs a fresh selection.

**Save or resume unfinished setup** also remembers the workbook checksum and
your proposed extra-sheet exclusions. After reopening the setup, reselect the
workbook and choose **Restore these exclusions for review**. Changed workbooks
or incompatible mappings need new choices. The snapshot carries no workbook
bytes, file path, preview permission or classification declarations.

See [the local workflow hardening report](../../docs/LOCAL_WORKFLOW_HARDENING_20260908.md)
for regression results, three researcher journeys and the synthetic pipeline check.
The [repeated QC report](../../docs/PORTAL_RESTART_STRESS_QC_20260908.md) covers
connected-chat follow-ups, saved-evidence recovery, proposal validation receipts,
process cleanup and another run of all three researcher scenarios.

Use **Improve this step** in the sidebar to record reusable feedback for the
current skill. Shared review, fixed regression checks, activation, withdrawal and
Git sharing reuse the existing learning loop. See
[continuous workflow improvement](../../docs/CONTINUOUS_WORKFLOW_IMPROVEMENT.md).

For the latest setup recovery, feedback, reviewed-learning and live-connection
checks, see the [local workflow completion report](../../docs/LOCAL_WORKFLOW_COMPLETION_20260908.md).

## Start a local session

### Demonstrate on a development server

Set `RWD_PORTAL_DEVELOPMENT=1` to use saved name/email profiles on a laptop or a
development server. It takes precedence over the older local workspace/demo flags.
In the sidebar, open **Development profile**, enter a name and email, then select
**Save and use profile**. The email identifies this profile's chat; the review form
can use the same profile email. Add a separate profile for the independent reviewer.
The profile picker lets a demonstration switch between those people.

The development review form records the selected reviewer and email without an SSH
key. Its confirmation is development evidence; production authentication and release
remain separate. Without the explicit development or local flags, the portal still
requires the platform's forwarded signed-in identity.

For example, start a Linux development server from the repository root with an
installed environment:

```sh
export RWD_PORTAL_DEVELOPMENT=1
export RWDP_STATE_DIR=/srv/rwd-portal-state
./.venv/bin/python -m streamlit run experiments/portal/app.py --server.address=0.0.0.0
```

`RWDP_STATE_DIR` must be writable by the portal process. It stores `users.json` and
private application state outside the code checkout. When moving a demonstration,
copy that state directory and the product checkout, then set the same mode on the
new server. No workstation key or private key transfer is required. Existing chat
history is also scoped to the checkout path; changing that path starts a separate
conversation even when the email profile is the same.

### Use the desktop launcher

On Windows, double-click [Start-RwdPortal.cmd](../../Start-RwdPortal.cmd) in the repository
folder. No command entry or environment activation is needed after the initial setup.
The launcher uses Python 3.13 from an explicit interpreter selection, or from this
repository's `.venv313` then `.venv`, starts the local server in the
background and opens the browser when the new server is ready. Its window then closes.

The preferred port is **8517**. If another server is using it, the launcher selects a
free port and leaves that server alone. Use the URL it opens, rather than an old
`localhost:8501` bookmark. A launch reuses this checkout's healthy server in the same
operating mode, or starts a new one when necessary.

Simultaneous ordinary launches share the same startup check. If another launch is
still starting, wait for it to finish and open the launcher again. For operator
cleanup, `python experiments/portal/launch_portal.py --status` includes unhealthy
servers owned by this checkout. `--stop` confirms termination before clearing its
receipt and reports any process it could not safely stop.

If the environment is missing, the launcher displays these one-time setup commands.
An operator runs them from the repository root in **PowerShell**; nothing is installed
automatically. An existing environment with a different Python version needs the data
expert to prepare a Python 3.13 environment deliberately. Preserve any older
environment and create `.venv313` separately when migrating an existing checkout.
The fresh-checkout commands below assume `.venv` does not already exist.

```powershell
py -3.13 -m venv .venv
.\.venv\Scripts\python.exe -m pip install -c experiments/portal/environment.constraints.txt -r requirements.txt -r platform/requirements.txt
```

If the launcher tag is unavailable, use `py -0p` to find a Python 3.13 executable
and invoke its full path with `-m venv .venv`. Stop on environment-creation errors.
Use a short local checkout outside synchronized folders. See the
[installation runbook](../../docs/LOCAL_INSTALLATION.md) for recovery.

On Linux, use Python 3.13 from a terminal in the repository root:

```sh
python3.13 -m venv .venv
./.venv/bin/python -m pip install -c experiments/portal/environment.constraints.txt -r requirements.txt -r platform/requirements.txt
./.venv/bin/python experiments/portal/launch_portal.py
```

These commands use the current checkout and require no developer-specific paths.
macOS currently lacks the required local process-identity adapter and is not a
supported startup target; the launcher explains that limitation before starting.
The same environment checks run before startup; the measured dependency profile
below records Windows evidence, so other operating systems still need their own
runtime verification. Java for optional Spark builds is discovered from a valid
`JAVA_HOME`, `PATH`, or the existing user-local JDK location. A stale `JAVA_HOME`
does not override a usable discovered runtime in the launched application; the
launcher never changes the user's system environment.

The standard requirements include pytest for the workflow's registered correction
and durable-fix checks. The launcher reports a missing runner before starting.

For the measured local dependency versions, use the same requirements with the
checked-in constraints:

```powershell
.\.venv\Scripts\python.exe -m pip install -c experiments/portal/environment.constraints.txt -r requirements.txt -r platform/requirements.txt
.\.venv\Scripts\python.exe experiments/portal/launch_portal.py --doctor
```

The doctor compares this checkout's interpreter and package metadata with the
[measured environment](environment.manifest.json). `--doctor --json` shows exact
expected and observed versions, missing dependencies, and changed requirements.
It starts no server and installs nothing. A mismatch returns a nonzero doctor
exit code; ordinary startup still permits dependency drift when the required
modules and Python 3.13 are available. The profile captures packages in the
declared Windows Python 3.13 dependency closure, excluding unrelated installed
tools. It is not a cross-platform lock or a product validation receipt. See the
[environment setup notes](../../docs/LOCAL_ENVIRONMENT_PROFILE.md) for scope,
optional Spark/R versions, and refreshing the profile after testing changes.

Then create your working branch in VS Code and double-click the launcher again. The
normal application opens a **Local workspace**, using your Git name and email for
attribution. The person who owns the checkout can edit its product records. There is
no demo identity selector, and reference examples are optional under **Browse
reference examples**. Git attribution is not a sign-in or a scientific signature.

On **New product**, use **Save or resume unfinished setup** to keep incomplete
registration fields and the setup conversation across browser or server restarts.
Each explicit save keeps an immutable private snapshot for this checkout and
editing identity in the existing state directory (or ignored `.portal-drafts`).
Choose a snapshot, review the current/saved values, then resume it. Existing text
requires a replacement review. Re-select the workbook and supply access,
classification and author/date declarations again; unavailable choices are cleared
with an explanation. A saved setup is not a product or a Git checkpoint, and
resuming it does not send a model request or run the creation command.

Use **Save work to my branch** to review a before/after diff of selected product
configuration, definition and review files and make a Git checkpoint. Unrelated staged
changes are preserved. Private unfinished drafts stay on this machine; save checked
records into the product before checkpointing them. Source workbooks and restricted
data remain outside these metadata commits. Nothing is pushed automatically.

VS Code's two launch configurations use the interpreter chosen through **Python:
Select Interpreter**, the same local application and the selected chat connection.
Open a new terminal after changing the interpreter. For an environment outside the
checkout, the launcher also accepts `--python PATH` or `RWD_PORTAL_PYTHON`; see
[migration instructions](../../docs/LOCAL_INSTALLATION.md#use-python-313-in-an-existing-vs-code-checkout).
For direct Streamlit startup, set `RWD_PORTAL_LOCAL_WORKSPACE=1` and
run `python -m streamlit run experiments/portal/app.py --server.address=127.0.0.1`.
An explicit `python experiments/portal/launch_portal.py --demo` remains available for
synthetic role rehearsals. Existing demo servers are not reused as normal workspaces.

For a hosted service, follow [Deployment](../../docs/DEPLOYMENT.md). The service uses
the authenticated identity forwarded by its hosting platform and the configured user
roster. Hosted sign-in and enterprise deployment are a later implementation phase;
the local flags must not be enabled in a hosted service.

## Work through a product

With an enabled, available assistant connection, the product guide is a conversation
on the current task. In scientific drafting, send the interpretation in plain language,
review the proposed wording, choose the answers to keep, and save the unfinished draft.
**Review details and edit fields** contains the manual editor; **Validate and preview
contract change** remains the path to a checked contract record. An unavailable or
disabled connection leaves the manual workflow usable. Opening a page makes no model
request. The guide preserves unsaved fields when a model times out.

The source step brings its declared delivery, roles and blockers into the same guide.
An explicit source assessment uses the existing specialist and critic. Older multi-table
declarations have a profile-bound, names-only diff and an Engineering request; ambiguous
columns remain unresolved. The science workbench connects reuse, standard names, clinical
standards, terminology relation sets, decisions and implementation evidence. Its findings
keep their own scientific status and citations.

Implementation assistance reads actual registered code and tests, uses the
`implement-product-rule` skill, and retains a reviewed proposal with its critique.
Supported capability changes pass canonical validation and static integration checks.
Unsupported module wiring opens an exact Engineering handoff. Generated code is never
executed just because an assistant returned it.

The workflow also exposes claims criteria and export, six-layer EDA receipt review,
validated knowledge-graph export, and assistant evaluation. Model review reuses the
existing canonical trainers and scorer. A measured version can be explicitly activated
for this product only with the required evidence. Original accessible evaluation cases
can be run in a bounded batch with the selected connection; mechanical scores remain
distinct from human adjudication. Review records resume from the product's saved-work
queue and can be checkpointed into the current branch.

New product setup supports oncology registration. For another condition, select
**Another condition (not supported yet)** and use **Save or resume unfinished setup**
to retain the actual request; registration stays blocked until its definitions,
source mappings and pipeline tests are implemented. Optum is available for claims
draft authoring through the existing claims workspace. Its delivery terms and
source-evidence route remain pending source-owner review, so this registration
does not enable profiling, source access, AI access, EHR or claims execution.
For a claims-layout workbook, register without a workbook first, then use
**Attach specification** in **Progress and next step**, followed by
**Configure claims criteria**. This is the exercised claims authoring route;
arbitrary claims sheets are not EHR extraction definitions.

**Check connection** distinguishes local client/CLI initialization from a successful
model response. The Anthropic check sends no API request; the Claude Code check reads
CLI version and sign-in metadata. A successful local check still needs an explicit
suggestion request to establish model access. Path, dependency and probe failures
retain form entries and display recovery guidance without provider exception bodies.

See [the local integration and three-case adversarial report](../../docs/LOCAL_WORKFLOW_ADVERSARIAL_SWEEP_20260907.md)
for tested boundaries and outstanding runtime prerequisites.

**Open this product's workspace** brings definition/reuse, product changes, study
evaluation and review into a task-based starting point. Progress offers the assistant
or evidence action appropriate to its current step. Knowledge search brings prior
definitions, naming decisions, clinical concepts and implementation evidence together;
each result continues into the relevant editor or review.

The repository skills now support the guide and task-specific assistants. The
selected connection also serves Request studio and delegated specialists, with no
silent switch to another provider. Specialist findings can be saved, shared as an exact
review snapshot and carried into the next workflow. Shared-library integration and
exact-build promotion readiness have separate validated actions within this flow.
See the [integration report](../../docs/WORKFLOW_KNOWLEDGE_ASSISTANT_INTEGRATION_20260907.md).

1. **Start a new product.** Enter the disease, data source and specification details. Review the
   draft before creating it. If the workbook has not arrived, keep that input pending;
   creating a draft does not mean its specification has been supplied or approved.
2. **Use prior work.** Explore an example in the reference library. During creation,
   **A second product of a tumour the registry knows** reuses the tumour entry and creates
   a fresh draft; it does not copy another product's definitions. **The next cut of a
   registered product** carries configuration into a revision that needs a revised
   workbook and review. Reference examples provide material to reconsider; their
   approvals and validation evidence do not approve the new product.
3. **Revise an existing product.** Open **Plan changes** to retain or remove sections
   and variables, add proposed definitions, name the studies that need them, or propose
   another source. Review the dependency conflicts and exact definitions, then choose
   **Save draft revision**. **Your saved draft revisions → Open saved version** restores
   it in a later session. Each save creates an immutable version with a before-and-after
   brief and the selected scientific definitions; unchanged saves reuse the same version.
   The original product, approvals and study pins remain intact. A changed baseline
   must be reviewed before saving again. Drafts are specific to your portal identity
   and product, stored locally under that product's `.portal-drafts` folder. Download
   the brief to share it for implementation and scientific review; these drafts do not
   create executable mappings or an approved release.
4. **Resolve the next blocker.** Open **Progress and next step**, then **Resolve**. Read the focused
   instructions and current evidence. Use **Check status** after the relevant change.
   Each of the six steps shows its editor, runnable action, or the responsible person
   and record to update. A successful command keeps its result open and offers
   **Continue: [next action]**. If the same step remains open, read the remaining
   requirement; command success alone does not complete an evidence check.
5. **Save document details.** Use **Generate and save document ID** once, or enter the
   document's existing ID. Enter its actual revision, data delivery and scientific QC
   review reference, then **Save specification details**. Leave unknown details blank.
   Return through **Progress and next step → Product details → Edit specification details** for corrections.
   These edits do not create a review decision or signature.
6. **Answer scientific questions.** After the issued forms are prepared in Progress and next step, open
   **Questions to answer**. Read the question and evidence. Where the question supplies
   alternatives, choose one, explain its scope and supporting evidence, then use the
   choice in your draft. You can also write your own answer. Enter the decision actually
   made, its decision maker and date, then **Save this answer**. Saving records typed
   ledger evidence and refreshes the ranked questions. If either update is interrupted,
   **Update saved decision evidence** completes the saved answer without submitting other drafts.
   Other unsaved answers
   survive question and workspace changes within the same browser session. The named
   reviewer authenticates the resulting register when completing scientific review.
7. **Check reviewer setup.** If Progress and next step says **Connect the review to its reviewer**, open
   Resolve to see the named reviewer and whether setup or review verification is needed.
   **Download administrator request** prepares the exact product, recorded name, source
   checksum and setup details for you to share. Once setup exists, an unverified review
   offers **Download reviewer request** instead. Downloads do not send a message or
   complete an approval. Administrator references open inside the dialog.
8. **Do the person's acts on the page (local session).** The steps a person used to complete
   at a terminal are forms in a local session: **Record these files in history** writes the
   registration as a plain history entry under the git identity configured on this computer;
   **Sign as [reviewer]** confirms a review with a personal key kept in your own user folder
   (a key with a passphrase still uses the prepared command shown above the form); **Settle
   these requirements** records the scientific owner's word on the chosen records, one
   word each, and leaves the contract approval and its signature as separate acts; the same
   form stays on the **Definitions** page after the approval, because a record settled later
   moves the approved digest and the approval is then made again. **Record these files in
   history** lists every file the stand-up wrote outside the product too (the registry, the
   catalogue mirror, the tumour registry, the oncology catalogue, the portfolio and activation
   files), so the history entry carries the whole act. On **Questions to answer**, a record
   that changed after the contract was approved offers **Reopen the contract approval and
   re-check**. **Build on synthetic sources** stays disabled, with the count of unfilled
   settings, until the configuration is bound. A hosted portal never signs or commits; it
   proposes a pull request instead.
9. **Hand a step to its owner.** When the portal cannot do a step for you, the step's
   technical handoff offers **Hand this step to [Data expert, Science, Engineering, Reviewer
   or Administrator]**. That creates a request with an owner and a status, listed on Home
   under saved work and on the **Handoffs and requests** page until the owner records what
   was done or why not; the requester can withdraw it. One open request per step: the form
   asks for your own words and does not appear again while a request is open. The product's
   own checks decide whether the step is then met. A configuration change submitted again
   after **changes requested** supersedes the earlier request for the same files, so the
   reviewer's inbox shows one request, with the earlier one closed and pointing at it.
10. **Ask the guide.** Every product page carries **Ask about this product** under the
   product header. It knows the product, its stage, the next step, what blocks it and what
   your role can do here, and answers with the page's own buttons (open the step, the
   questions, the editor, a handoff). Without a connected assistant the answers come from
   the product's own checks; with one chosen under **Assistant** in the sidebar (Claude Code
   sign-in, VS Code, or an API key) the same context and your question go to that model,
   which may only answer and point at those buttons. It never writes a file or navigates on
   its own, and text that looks like data about individual people is refused before it is
   sent anywhere.

The **Studies** view records which product version a study uses and whether individual
definitions are reused, reconsidered or excluded. A source change needs renewed schema,
mapping, cohort attrition, missingness and outcome validation before its scientific
results can be relied on.

## Edit a completed rehearsal

Open **Try a workflow**, resume the saved rehearsal, and choose **Edit this rehearsal**.
The saved plan and scientific interpretations are prefilled. Choose a definition to
read its original specification wording beside your editable interpretation. The
expanded writing guide explains timing, record selection, missing values and
dependencies with an illustrative example; examples are never entered on your behalf.

Choose **Save revision** to retain the previous run and create a revised draft, then
run that revision's checks on the same page. Review the before-and-after definition
table and any validator findings. Draft contract findings remain visible even when
extraction and example configuration checks succeed. **Resume a saved rehearsal**
can reopen either version. A proposed new variable, source or section change remains
an implementation handoff; it does not change the executable example configuration.

After the checks complete, choose **Build synthetic ADS from this example** on the
same page. It runs the saved example configuration through the existing local Spark
worker and shows synthetic row/column counts and a sample. A failed build keeps the
completed specification checks and its diagnostics, with a retry on the same page.
The result is bound to that saved example; a changed input or build output cannot
keep an old success badge. Proposed definitions, sections and data sources still
need implementation before they affect the dataset.

For a working product, **Progress and next step → Tools for this step → Declare
the source delivery** provides a form for existing source table names, schema and
delivery cut. Review resolved physical names, declared consumers, the diff and
validator findings before saving the draft. Existing scientific findings remain
open. Source unions, new table roles and adapter changes continue through the
mapping or engineering handoff shown on the page.

## Write a scientific definition from a specification row

In **Progress and next step → Resolve → Draft the scientific definition**, select a specification row.
The form supplies its source wording and citation. Enter your intended interpretation,
timing, record selection, missing-value handling, dependencies and a worked example.
Read the field guidance and illustrative example alongside the form. Use **Save
unfinished row draft** when choices are still open; this saves your work separately
and does not add an incomplete row to the functional contract.

Use **Check existing names and prior definitions for this row** to open the names
section while keeping the row's unfinished answers. **Use a consistent variable
name** suggests matches from the row's literal wording and identifiers (for example,
`DATAV` in `Data cutoff (DATAV)`), without requiring a separate search. **Browse all
available names** opens the accessible prior list. Selecting a name shows its
recorded interpretations, timing, missing-value rules and citations in the same
section; a configured name without a scientific record is identified explicitly.
The source label,
definition identifier, physical column and intended published name have separate
purposes. **Use this name in my draft** proposes a physical name explicitly; it does
not infer concept equivalence, rename an existing column, or mark naming aligned.
Ambiguous matches remain questions for the data expert's naming ruling. The existing
cross-product registry and naming checks remain authoritative.

When the extraction needs its own source record, **Register current extraction**
records its machine-derived location and checksums with review pending. An authorized
reviewer inspects the extracted content and enters the actual access classification,
reviewer names and dates in **Record extracted source review**. Registration does not
carry over the workbook's review or infer a decision about extracted material.

Choose **Validate and preview contract change**, resolve the reported row findings,
review the before-and-after diff, and use **Save checked definition to contract**.
Repeat for the remaining requirements, resolve scientific questions, and complete the
scientific review. **Check again** refreshes the workflow requirements. Saving an empty
contract template cannot complete scientific definition drafting; a saved checked row
also does not authenticate an approval or create a release.

## Stage a GIST configuration proposal

For a product whose configuration carries supported settings (the portal offers the intent
only for such a product), an authorized local editor can turn an explicit supported setting
change into a saved configuration proposal:

1. Open **Plan changes → Change a supported product setting**, describe the purpose,
   and name the affected studies. Under **Settings to change**, select the settings
   you need and enter their replacements. Supported settings are
   **Study index start** and **Study index end** (`YYYY-MM-DD`), **Minimum follow-up
   days** and **Visit recency days** (non-negative whole numbers), and **Days per
   month** (a finite positive number). Values are never inferred from scientific prose.
2. For a study-specific change, choose **Change how one study uses the product** to
   continue into Studies. In a larger revision brief, removed variables can also be
   assigned under **Study-only exclusions → Exclude only in [study]**. These exclusions remain
   separate from shared configuration and existing study pins. Review any dependency
   conflicts. New definitions, source switches, shared output removals, and unsupported
   rules remain an **Engineering handoff**; this flow does not generate their logic.
3. Click **Stage configuration proposal**. Review the saved before-and-after diff,
   declared dependency and consumer impact, exclusions, and engineering handoff. A
   configuration-only proposal can be staged even when no definition brief is ready.
4. Click **Run proposal validators**. The existing strict engine, contract lint, and
   contract binding checks run against an isolated candidate. Read each finding;
   correct supported settings and stage a new proposal, or give contract, mapping,
   and engine findings to the data expert. An unresolved engineering handoff blocks
   submission. Stage supported changes separately if they need independent review.
5. Once the required checks pass, **Submit proposal for review** reruns the validators
   and checks for changes to the product and declared consumers. Reopen saved proposals
   through **Your staged configuration proposals → Open staged proposal**.

The current GIST scaffold has unresolved configuration and contract requirements, so
staging a supported parameter change does not make its validators pass. Submitted
proposals are local review requests only: they do not apply changes to the product,
change study pins, execute an analysis, record approval, or create a release.

## Continue through one connected workflow

The existing product picker and workspace remain the navigation. **Tools for this
step** in Progress and next step and **What to do next** inside a work area connect the underlying
capabilities while preserving the current product, selected variable or study.
Artifact identifiers stay with the tool that created them. A different product or
identity cannot reopen the former context. **Saved work and pending handoffs** on
Home and Progress and next step resumes private drafts, review returns, proposals and runtime requests.

| Where you are working | Connected actions and continuation |
|---|---|
| Scientific definitions | Compare rules and standard names; record inherit/adapt/diverge; reconcile templates; inspect clinical standards. Selected reviewer input can become an unfinished draft in the existing row editor. |
| Scientific review workbook | Download the actual extracted rows and findings, return the four reviewer columns, validate the exact current context, and continue on the source row or its questions. |
| Search and definition review | Trace specification → decisions → rule → configuration → implementation/build evidence; missing citations remain visible. Stage shared definition identities and implementation claims for review. |
| A revised specification or proposed change | Resolve one added, changed or removed row, compare its exact source fields, then open its definition, cited question or affected consumers. Removed rows retain the selected earlier cut. Reuse of unchanged definitions is a separate explicit choice. |
| Source review | Follow the required table/column worklist into bound delivery requests, profile/schema/QC returns, explicit mapping choices, checked adapter diffs and delivery-profile comparisons. |
| Studies | Complete a draft protocol or stage a frozen-plan amendment; inspect/refresh a pin and select a published build; explore explicit feasibility criteria; validate actual run evidence and compare dataset semantics. |
| Home | Rank accessible open decisions by declared definition impact and reopen saved work. |

Plan changes now asks for one intent first: scientific definition, supported setting,
one study's use, or a larger revision. An empty contract points to the guided row
editor. Configuration fields appear only after the user selects the settings to change.
**Revise this proposal** restores the saved inputs without changing the earlier
review snapshot or study pins. Validator status is shown before the optional full
findings; satisfying review-submission requirements does not mean the product's
scientific checks have passed.

Dataset comparison's **Open scientific question workflow** retains the proposed
question, variable, dataset pair and citation. **Use this question draft** fills
only the unsaved question/evidence fields. Enter the identifier and owner, then
explicitly raise it as open and prepare its answer form. No pooling decision is
inferred from opening or recording the question.

These are connected editing and evidence workflows, not a completed deployment.
Approved-data execution, authenticated signatures and steward changes to global
registries remain explicit handoffs. Returned metadata is checked for its declared
binding; it is not proof that a claimed production run occurred. Synthetic feasibility
counts remain labelled synthetic. A new product's delivery/schema/table settings
can be declared through the checked **Declare the source delivery** form for existing
roles. Adapters, unions and new source roles keep their engineering review workflow.
Clinical bindings and shared identity proposals preserve validator results and exact
file diffs; the relevant reviewer/steward must implement and authenticate accepted work.
Saved clinical-standard proposals now offer **Share this exact proposal for review**.
Choose the responsible role and review note; the existing Handoffs page shows the
reviewer the selected proposal's source context, exact diff and remaining findings.
Other private drafts are not shared. A stale snapshot is labelled, and closing the
request does not apply the binding or approve its clinical meaning.

The [7 September adversarial retest](../../docs/EPIDEMIOLOGIST_ADVERSARIAL_RETEST_20260907.md)
records the exercised journeys, regressions, actual synthetic build and remaining
integration limits, including the layered EDA evidence viewer and specialised claims setup.

## Read evidence and hand off work

Use **Open source** or **Sources and linked documents** to read a cited document in the
portal. **Back to previous document** returns to the earlier source; **Close document**
returns to the product page. Links to files that have not been created yet explain that
they are pending. Restricted files and source data use their dedicated workflows.

If Progress and next step asks for a workbook, the data expert places the actual supplied workbook in
the product's `prog_spec/` location and records its `path_or_link` in `source_refs.yaml`.
The portal runs in its own checkout: a path on a different person's desktop is not
available to it. A pending path such as `TBD` means the workbook is still needed.

Scientific answers and approvals remain the responsibility of their named owners.
The scientific definition editor starts with two questions in **Meaning**, then
continues through **Timing**, **Missing values**, **Source and names**, and **Review**.
The original specification values and citation remain visible separately. Blank
answers mean undecided. Common questions offer unselected choices, **Write my own
answer**, and **Not sure yet**. The exact draft answer is shown after a selection;
**Edit this answer** lets the drafter refine it. A not-applicable answer needs an
explanation. Illustrative help examples are never inserted automatically. Moving
between rows or sections retains session entries; **Save unfinished row draft**
stores them for later. In **Review**, the existing validator checks the proposed
record and displays its contract diff. Editing an answer invalidates that preview.
A checked draft can retain explicit unresolved questions under the canonical
draft policy; it does not complete scientific review. Legacy contract formats and
unsupported derivations retain an explicit engineering handoff.

**Ask AI to help with this row** is optional. An explicit request sends only the
eligible selected specification row, current answers and the help request to
the explicitly configured assistant. It does not send patient-data files or other definition rows. The helper
shows proposed answers, supporting source quotes, assumptions and review questions.
Select individual suggestions to copy them into the unfinished private draft;
unselected answers are preserved. The source, identifiers, implementation and
publication settings remain manual. The normal validator and contract-diff review
still follow; an AI suggestion does not complete a scientific review.

The existing source-access checks must allow this extraction before AI suggestions
can be requested. For VS Code's available GPT-5 mini or Sonnet model, install the local bridge,
run **RWD Portal: Connect Chat Model** in VS Code, select the model and set
`RWD_PORTAL_AI_PROVIDER=vscode` in the local, gitignored `experiments/portal/.env`.
The selected VS Code window must remain open. Model access and quotas are controlled
by its provider. The standalone Claude Code extension has its own connection and
does not register its models with this API.

The direct Anthropic adapter is a separate explicit option:
`RWD_PORTAL_AI_PROVIDER=anthropic` with `ANTHROPIC_API_KEY`, and
`ANTHROPIC_WORKSPACE_ID` when the credential requires it. There is no automatic
provider fallback. Restart the portal after changing settings. See [.env.example](.env.example).
Never put credentials in a definition or help request; examples and tests contain
no working credential.
See [assistant setup and VS Code/MCP options](../../docs/PORTAL_ASSISTANT_SETUP.md)
for the full local workflow and the distinction between sharing MCP tools and using
a VS Code chat model.

Local answer forms capture only what the person enters; they never guess a decision,
reviewer or date. A question or underlying requirement that changed while the form was
open must be reviewed again before saving. Hosted answer writes are not implemented.
Where an action still needs a repository edit, authenticated signature or production
runtime, **Resolve** names the file and handoff. Researchers can review that evidence
and send the handoff to their data expert. Recording a typed classification or ledger
event alone does not authenticate an approval. Use the [Operator's Card](../../docs/OPERATORS_CARD.md)
for the engineering commands behind those handoffs.

Synthetic rehearsals show whether an implementation runs with example inputs. A real
study also needs delivered-source checks, scientific review, build evidence and release
approval. See [Production readiness](../../docs/PRODUCTION_READINESS.md) for that boundary.

## Run the end-to-end user acceptance test

One command walks a synthetic product from its specification workbook to the release gates on a
disposable copy of this checkout, through the same tools and portal backends a person uses:

```powershell
.\.venv\Scripts\python.exe platform/tools/uat_journey.py --out C:\rwdp-uat --json C:\rwdp-uat\report.json
```

It stands the product up, records the specification review, registers the extraction, signs the
reviews with UAT-only keys, drafts nine definitions (one through the row editor backend), answers
two questions, creates the contract approval, validates the example configuration, drafts a study
and pins the product. Its report (`UAT_REPORT.md`) says for every step whether it passed, failed,
could not run on this machine, was a refusal the platform makes on purpose at that stage, or was a
step the harness performed as the named person. A synthetic build and delivered-source evidence are
reported as blocked on a laptop without Spark or vendor data. Add `--keep` to inspect the copy.

## Run the checks CI would run

Run the repository's local check lane from this checkout:

```powershell
.\.venv\Scripts\python.exe platform/tools/ci_local.py            # everything pure-Python, one table
.\.venv\Scripts\python.exe platform/tools/ci_local.py --portal   # only the Streamlit journey suites
```

The lane collects test modules with pytest, including fixtures and parameterized tests.
The repository's Linux and Windows workflow definitions also use pytest and retain JUnit
results. Spark, R and cluster steps that cannot run locally are reported as skipped with
the reason; skipped is never a pass. A local result does not establish a successful hosted run.

For a requested output that is calculated from several tables or prior definitions, see
[the derived-variable workflow](../../docs/DERIVED_VARIABLE_WORKFLOW.md). The row editor's
**Source and names** section also explains this when **derived** is selected.

## Common setup problems

| Symptom | Next step |
|---|---|
| `No module named streamlit` | Ask the operator to run the dependency-install command above, then use the launcher. |
| Starting locally without enterprise sign-in | Use the launcher, which starts the local workspace mode. Work on your own Git branch; the local identity is attribution, not an enterprise sign-in. |
| An old browser tab is disconnected or shows `WinError 10054` | Use the fresh URL opened by the launcher. A socket reset alone does not identify a data-product failure; use Progress and next step to check the product itself. |
| No products appear in the local workspace | Confirm this checkout contains a registered product or reference fixture. Use [local setup](../../docs/LOCAL_INSTALLATION.md) and Start a product for a new draft; registration does not approve it. Hosted roster access is configured separately by the deployment administrator. |
| The synthetic build says no Java runtime is available | A local build needs `pyspark` in the repository environment and a JDK 17. No system setting is required: unpack a Temurin JDK 17 once under `%LOCALAPPDATA%\RwdPortal\jdk` (the folder name starts with `jdk-17`); the launcher and the build find it there and set it only for their own process. |
| The synthetic build stops with "Python worker failed to connect back" | Spark gives each worker ten seconds to start, and a laptop that is busy with other work misses that window. Run the build when nothing else heavy is running; it takes a few minutes on four cores. |
| A workbook or source document is unavailable | Check that it exists in the checkout serving the portal; a draft may intentionally have no workbook yet. |
| A Spark rehearsal is unavailable | The operator checks the separate Spark and Java prerequisites in [platform requirements](../../platform/requirements.txt). Status and planning remain available. |

This repository targets **Python 3.13**, with **3.13.13** pinned in CI. Streamlit
recommends an isolated environment and supports
launching with the selected interpreter's `python -m streamlit` command. See the
[official installation guide](https://docs.streamlit.io/get-started/installation/command-line).

The launcher checks the new server's own startup message and its health endpoint.
That verifies server readiness, not all product workflows or scientific results.
Startup logs and launch receipts are stored outside the repository under the local
application-data `RwdPortal` directory. An operator can run
`.\.venv\Scripts\python.exe experiments/portal/launch_portal.py --check-only` for a setup
check, or add `--no-browser` for a browser-free launch diagnostic. A second double-click
reuses the portal that is already running instead of starting another server;
`launch_portal.py --status` lists the servers this launcher started and
`launch_portal.py --stop` stops them (no other process is ever touched).
