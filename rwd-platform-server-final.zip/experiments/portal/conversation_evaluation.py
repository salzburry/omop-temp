"""Multi-turn scientific journeys in the existing canonical evaluation lifecycle.

The selected product/reference owns the receipt only. Model inputs use isolated
synthetic briefs, current repository skills and the existing public mCODE file.
No user product science, approvals, patient rows or source attachments are read.
"""
from __future__ import annotations

import copy
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import re
import tempfile
import time
from types import SimpleNamespace
import uuid

import yaml
import model_lifecycle_workspace as lifecycle
import model_lifecycle_runtime as runtime
import portal_agent_connection as connection
import portal_runtime
import scientific_definition_ai as ai
import session_drafts
import workflow_skills

CODE = Path(__file__).resolve().parents[2]
CORPUS = 'experiments/agent/evals/cases_conversations.yaml'
PUBLIC = 'governance/reference/mcode_stu4/VALUE_SET_CODES.json'
MAX_SECONDS = 360
MAX_RECEIPT_BYTES = 2_000_000
MAX_CORPUS_BYTES = 200_000
MAX_CORPUS_CASES = 32
MAX_SELECTED_CASES = 3
TURN_EXPECTATIONS = ('initial_question', 'short_choice', 'uncertainty', 'changed_intent')
NOTICE = ('Synthetic conversation evaluation. Mechanical results measure recorded chat, brief and form behaviour; '
          'clinical quality requires the separate human rubric. No approval, release, model activation or training label is created.')
VERSION_FILES = (CORPUS, 'experiments/portal/conversation_evaluation.py',
    'experiments/portal/flow_assistant.py', 'experiments/portal/conversation_intake.py',
    'experiments/portal/conversation_examples.py',
    'experiments/portal/form_assistance.py', 'experiments/portal/scientific_conversation_context.py',
    'experiments/portal/scientific_definition_ai.py', 'experiments/portal/workflow_skills.py',
    'experiments/portal/model_lifecycle_workspace_page.py', 'experiments/portal/portal_jobs.py',
    'experiments/agent/intake.py', 'experiments/agent/intake/product_brief.yaml',
    'experiments/agent/evals/run.py', 'experiments/agent/model_lifecycle_runtime.py')


def _scope(root, pack, actor_id, allowed_packs):
    root = Path(root).resolve(strict=True)
    if not isinstance(pack, str) or not runtime.CASE_PACK.fullmatch(pack):
        raise ValueError('Select an accessible product or reference example for this evaluation receipt.')
    import specification_details
    specification_details._paths(root, pack, allowed_packs)
    scope, directory = session_drafts._setup_scope(root, actor_id, allowed_packs)
    directory = directory.parent.parent.parent / 'conversation-evals' / scope['checkout'][:12] / scope['owner'][:12] / runtime.digest(pack)[:12]
    if directory.resolve() != directory:
        raise ValueError('The private evaluation location redirects outside its scope.')
    session_drafts.dw._check_storage_paths([directory / ('0' * 32 + '.json')])
    return root, directory


def _files(root):
    names = list(VERSION_FILES) + [PUBLIC]
    names += ['.claude/skills/' + name + '/SKILL.md' for name in workflow_skills.BINDINGS]
    result = {}
    for name in names:
        # Python code comes from the executing checkout; skill and reference bytes
        # come from the selected checkout, exactly as the real guide reads them.
        base = CODE if name in VERSION_FILES else root
        path = base / name
        if path.resolve() != path.absolute() or not path.is_file() or path.stat().st_size > MAX_RECEIPT_BYTES:
            raise ValueError('Restore the current evaluation code, skills and public reference before previewing.')
        result[name] = hashlib.sha256(path.read_bytes()).hexdigest()
    return result


def _validate_corpus(value):
    """Allow more journeys without widening the reviewed four-turn/run budget."""
    def text(value, limit):
        return isinstance(value, str) and bool(value.strip()) and len(value.encode('utf-8')) <= limit

    if (not isinstance(value, dict) or set(value) != {'version', 'evidence_mode', 'notice', 'cases'}
            or type(value['version']) is not int or value['version'] != 1
            or value['evidence_mode'] != 'synthetic_conversation' or not text(value['notice'], 1800)
            or not isinstance(value['cases'], list) or not 1 <= len(value['cases']) <= MAX_CORPUS_CASES):
        raise ValueError('The conversation corpus must declare one to 32 bounded synthetic journeys.')
    import conversation_intake as intake
    rows, identifiers, titles = value['cases'], set(), set()
    slots = set(intake.slots())
    keys = {'id', 'title', 'goal', 'initial', 'question_slot', 'changed_slot', 'changed_value', 'turns', 'human_rubric'}
    for row in rows:
        if (not isinstance(row, dict) or set(row) != keys or not text(row['id'], 80)
                or not re.fullmatch(r'conversation_[a-z0-9_]+', row['id']) or row['id'] in identifiers
                or not text(row['title'], 160) or row['title'] in titles or not text(row['goal'], 1000)
                or not isinstance(row['initial'], dict) or not set(row['initial']) <= slots
                or not {'intended_use', 'population', 'source_cut', 'acceptance_criteria'} <= set(row['initial'])
                or any(not text(item, 1800) for item in row['initial'].values())
                or not isinstance(row['question_slot'], str) or row['question_slot'] not in slots
                or row['question_slot'] in {'acceptance_criteria', 'requested_by'}
                or not isinstance(row['changed_slot'], str) or row['changed_slot'] not in row['initial']
                or row['changed_slot'] in {'acceptance_criteria', 'requested_by', row['question_slot']}
                or not text(row['changed_value'], 1800) or row['changed_value'] == row['initial'][row['changed_slot']]
                or not isinstance(row['human_rubric'], list) or not 1 <= len(row['human_rubric']) <= 8
                or any(not text(item, 1000) for item in row['human_rubric'])
                or not isinstance(row['turns'], list) or len(row['turns']) != len(TURN_EXPECTATIONS)):
            raise ValueError('A conversation journey has duplicate identifiers or unsupported fields, values or review rubric.')
        for number, turn in enumerate(row['turns']):
            if (not isinstance(turn, dict) or not {'text', 'expect'} <= set(turn)
                    or not set(turn) <= {'text', 'expect', 'suffix'}
                    or not text(turn['text'], 2400) or turn['expect'] != TURN_EXPECTATIONS[number]
                    or ('suffix' in turn and (number != 2 or not text(turn['suffix'], 1800)))):
                raise ValueError('Each journey must use the supported question, short-choice, uncertainty and revision protocol.')
        if (row['turns'][1]['text'] not in {'1B', 'B', '2'} or row['turns'][2]['text'] != 'Not sure'
                or row['changed_value'] not in row['turns'][3]['text']):
            raise ValueError('The scripted choices and final exact replacement must match their mechanical checks.')
        connection.check_input(row)
        identifiers.add(row['id'])
        titles.add(row['title'])
    return rows


def _cases():
    path = CODE / CORPUS
    if path.stat().st_size > MAX_CORPUS_BYTES:
        raise ValueError('The conversation corpus exceeds its supported file size.')
    try:
        return _validate_corpus(yaml.safe_load(path.read_text(encoding='utf-8')))
    except (yaml.YAMLError, UnicodeError, RecursionError) as error:
        raise ValueError('The conversation corpus is unreadable or malformed.') from error


def options(root, pack, actor_id, *, allowed_packs):
    root, _ = _scope(root, pack, actor_id, allowed_packs)
    return {'cases': _cases(), 'connection': connection.describe(root), 'versions': _files(root),
            'storage': 'branch' if runtime.PACK.fullmatch(pack) else 'private local evaluation; download to share'}


def preview(root, pack, actor_id, case_ids, *, allowed_packs, request_id=None):
    current = options(root, pack, actor_id, allowed_packs=allowed_packs)
    if not current['connection'].get('ok'):
        raise ValueError('Connect the selected assistant before previewing these conversations.')
    by_id = {row['id']: row for row in current['cases']}
    if (not isinstance(case_ids, list) or not 1 <= len(case_ids) <= MAX_SELECTED_CASES
            or any(not isinstance(name, str) for name in case_ids) or len(set(case_ids)) != len(case_ids)
            or any(name not in by_id for name in case_ids)):
        raise ValueError('Select one to three current conversation journeys.')
    request_id = request_id or uuid.uuid4().hex
    if not re.fullmatch(r'[a-f0-9]{32}', request_id):
        raise ValueError('Prepare a new conversation preview.')
    value = {'request_id': request_id, 'pack': pack, 'actor': actor_id,
        'access': sorted(set(allowed_packs)), 'connection': current['connection'],
        'versions': current['versions'], 'storage': current['storage'], 'max_seconds': MAX_SECONDS,
        'cases': [{'case': dict(by_id[name], expect={'outcome': 'done'}, provenance='generated',
                    evidence_mode='synthetic_conversation', adjudicated=False, training_eligible=False), 'packs': [pack]} for name in case_ids]}
    return dict(value, digest=runtime.digest(value))


def _fresh(root, pack, actor, proposal, allowed):
    current = preview(root, pack, actor, [r['case']['id'] for r in proposal['cases']],
                      allowed_packs=allowed, request_id=proposal['request_id'])
    if current != proposal:
        raise ValueError('The cases, code, skills, public reference, identity or selected connection changed. Prepare a new preview.')


def _save(path, value):
    from correction_evaluation import _save_journal
    _save_journal(path, value)


def _load(path):
    if path.resolve() != path.absolute() or path.stat().st_size > MAX_RECEIPT_BYTES:
        raise ValueError('The retained conversation journal is unavailable or too large.')
    value = json.loads(path.read_text(encoding='utf-8'))
    if value.get('journal_sha256') != runtime.digest({k: v for k, v in value.items() if k != 'journal_sha256'}):
        raise ValueError('The retained conversation journal changed.')
    return value


def _validate(record, pack, allowed):
    runtime.validate_canonical_case_record(record, pack, allowed)
    if (record.get('evaluation_mode') != 'multi_turn_conversation'
            or record.get('clinical_quality') != 'human_review_required'
            or record.get('semantic_improvement') is not None):
        raise ValueError('The conversation receipt cannot claim clinical validation.')


def read(root, pack, actor_id, identifier, *, allowed_packs):
    root, directory = _scope(root, pack, actor_id, allowed_packs)
    if not isinstance(identifier, str) or not runtime.ID.fullmatch(identifier):
        raise ValueError('Select a retained conversation result.')
    if runtime.PACK.fullmatch(pack):
        record = runtime.read_record(root, pack, 'evaluations', identifier, allowed_packs=allowed_packs)
    else:
        record = _load(directory / (identifier + '.json'))['record']
        payload = {k: v for k, v in record.items() if k not in {'id', 'sha256'}}
        if (record.get('sha256') != runtime.digest(payload) or record.get('id') != identifier
                or identifier != record['sha256'][:24] or record.get('pack') != pack or record.get('kind') != 'evaluations'):
            raise ValueError('The retained conversation packet changed.')
    _validate(record, pack, allowed_packs)
    return record


def recent(root, pack, actor_id, *, allowed_packs):
    root, directory = _scope(root, pack, actor_id, allowed_packs)
    directory = runtime.safe_path(root, pack, 'evaluations') if runtime.PACK.fullmatch(pack) else directory
    paths = list(directory.glob('*.json'))
    if len(paths) > 300:
        raise ValueError('The evaluation directory exceeds its supported history size.')
    found, invalid = [], 0
    for path in paths:
        if not runtime.ID.fullmatch(path.stem):
            continue
        try:
            if runtime.PACK.fullmatch(pack):
                candidate = runtime.read_record(root, pack, 'evaluations', path.stem, allowed_packs=allowed_packs)
                if candidate.get('evaluation_mode') != 'multi_turn_conversation':
                    continue
            found.append(read(root, pack, actor_id, path.stem, allowed_packs=allowed_packs))
        except runtime.CaseScopeError:
            continue
        except (ValueError, OSError, KeyError, TypeError):
            invalid += 1
    return {'records': sorted(found, key=lambda r: r['created_at'], reverse=True), 'invalid_records': invalid}


def _write(root, pack, actor, packet, allowed):
    _validate(packet, pack, allowed)
    if runtime.PACK.fullmatch(pack):
        return lifecycle._write(root, pack, 'evaluations', packet, allowed_packs=allowed)
    _, directory = _scope(root, pack, actor, allowed)
    value = dict(packet, pack=pack, kind='evaluations')
    sha = runtime.digest(value)
    record = dict(value, sha256=sha, id=sha[:24])
    path = directory / (record['id'] + '.json')
    if not path.exists():
        _save(path, {'record': record})
    return read(root, pack, actor, record['id'], allowed_packs=allowed)


def _synthetic(root, destination):
    for name in [PUBLIC] + ['.claude/skills/' + skill + '/SKILL.md' for skill in workflow_skills.BINDINGS]:
        path = destination / name
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes((root / name).read_bytes())


class _Capture:
    """Retain the exact bounded call to the same native adapter the guide uses."""
    def __init__(self, client):
        self.client, self.calls = client, []
        self.preflight_error = None

    def step(self, system, messages):
        if (not isinstance(system, str) or not isinstance(messages, list) or len(messages) != 1
                or not isinstance(messages[0], dict) or messages[0].get('role') != 'user'
                or not isinstance(messages[0].get('content'), str)):
            self.preflight_error = {'code': 'input_shape', 'native_call_started': False}
            raise ValueError('The evaluation input does not match the canonical guide request shape.')
        # The guide budgets its actual system and content bytes. Serializing an
        # already-JSON content string again adds transport escapes, not context.
        size = len(system.encode('utf-8')) + len(messages[0]['content'].encode('utf-8'))
        if size > ai.MAX_REQUEST_BYTES:
            self.preflight_error = {'code': 'context_limit', 'native_call_started': False,
                                    'input_bytes': size, 'maximum_input_bytes': ai.MAX_REQUEST_BYTES}
            raise ValueError('The evaluation call exceeds the selected adapter context bound.')
        try:
            connection.check_input({'system': system, 'messages': messages})
        except ValueError:
            self.preflight_error = {'code': 'input_not_safe', 'native_call_started': False}
            raise
        call = {'system': system, 'messages': copy.deepcopy(messages), 'input_bytes': size,
                'serialized_message_bytes': len(json.dumps(messages, ensure_ascii=False).encode('utf-8')),
                'raw_response': None, 'status': 'started'}
        self.calls.append(call)
        try:
            raw = self.client.step(system, messages)
            if not isinstance(raw, str) or len(raw.encode()) > 80_000:
                call['status'] = 'response_size_refused'
                raise ValueError('The evaluation reply exceeds its retained output bound.')
            connection.check_input(raw)
            call.update(raw_response=raw, response_bytes=len(raw.encode()), status='returned')
            return raw
        except Exception as error:
            call.update(status='failed', error_type=type(error).__name__)
            # Provider exceptions can embed credentials, prompts or request URLs.
            raise


def _form(case, values):
    rows = [{'id': name, 'label': name.replace('_', ' ').capitalize(), 'type': 'text_area',
             'current': value, 'current_complete': True, 'empty': not value, 'choices': None,
             'min': None, 'max': None, 'max_chars': 1800} for name, value in values.items()]
    return {'scope': runtime.digest([case['id'], rows]), 'fields': rows, 'fields_omitted': 0}


def _turn(case, number, brief, history, values, model, synthetic):
    import conversation_intake as intake
    import flow_assistant as guide
    import form_assistance
    spec = case['turns'][number]
    before = copy.deepcopy(brief)
    question = intake.current_question(brief)
    brief, expanded, matched = intake.resolve_reply(brief, spec['text'])
    # Missing-evidence context is a second sentence after the exact displayed
    # uncertainty choice; it does not change which question was answered.
    text = spec['text'] + (' ' + spec['suffix'] if spec.get('suffix') else '')
    public = _form(case, values)
    card = {'product': 'Synthetic scientific conversation', 'actions': [],
        'current_task': {'route': 'scientific_draft', 'title': case['title']},
        'status': 'Synthetic evaluation; no data source mapping or accepted code list',
        'editable_form': public}
    reply = guide.answer(text, card, root=synthetic, model=model, history=history,
        actor_id='Synthetic evaluation author', allowed_packs=[], study_brief=brief,
        task_scope={'route': 'scientific_draft'},
        resolved_question=expanded if matched and question else None)
    if model.preflight_error:
        reply = dict(reply, error_code='evaluation_preflight',
            note='The evaluation input was refused before a model request. Inspect the recorded preflight reason; no connection failure was observed.')
    brief_apply_error = None
    if reply.get('source') == 'assistant':
        try:
            brief = intake.apply_reply(brief, reply, user_text=text, public_form=public)
        except ValueError as error:
            # A contradictory structured proposal is a failed journey, not a
            # disconnected provider. Retain its answer and preserve both drafts.
            brief_apply_error = type(error).__name__
    after_values = copy.deepcopy(values)
    checked_prefill = None
    if reply.get('prefill'):
        checked_prefill = form_assistance.check_response(reply['prefill'], public)
        # The scripted user only accepts the exact requested final replacement.
        # Other fields remain proposals and their non-mutation is scored below.
        if spec['expect'] == 'changed_intent' and brief_apply_error is None:
            for row in checked_prefill['fields']:
                if row['id'] == case['changed_slot'] and row['value'] == case['changed_value']:
                    after_values[row['id']] = row['value']
    checks = {'assistant_response': reply.get('source') == 'assistant',
        'evaluation_preflight_passed': model.preflight_error is None,
        'brief_form_consistent': brief_apply_error is None,
        'manual_brief_preserved': brief['state']['request']['acceptance_criteria'] == case['initial']['acceptance_criteria'],
        'manual_form_preserved': after_values['acceptance_criteria'] == case['initial']['acceptance_criteria'],
        'no_manual_replacement_proposed': not any(row['id'] == 'acceptance_criteria' and row['value'] != values['acceptance_criteria']
                                                for row in (checked_prefill or {}).get('fields', []))}
    active = intake.current_question(brief)
    if spec['expect'] == 'initial_question':
        checks['relevant_mcq'] = bool(reply.get('questions') and active and active['id'] == case['question_slot']
                                    and 2 <= len(active['options']) <= 4)
    if spec['expect'] == 'short_choice':
        displayed_options = (question or {}).get('options', [])
        choice = displayed_options[1] if len(displayed_options) >= 2 else None
        checks['exact_short_choice'] = bool(matched and choice and brief['state']['request'][question['id']] == choice['label'])
        checks['next_mcq'] = bool(reply.get('questions') and active and active.get('token') != question.get('token'))
    if spec['expect'] == 'uncertainty':
        checks['uncertainty_retained'] = bool(matched and question and question['id'] in brief['unknown_slots'])
        checks['uncertain_value_not_defaulted'] = bool(question and brief['state']['request'][question['id']] == before['state']['request'][question['id']])
    # Check common exact code formats throughout the journey, including proposed
    # fields. This bounded lexical check complements, never replaces, the rubric
    # for clinical applicability, code completeness and authoritative provenance.
    answer = json.dumps({key: reply.get(key) for key in ('answer', 'brief_updates', 'prefill', 'questions')})
    mentioned_codes = set(re.findall(r'\b(?:[A-Z][0-9]{4}|[A-TV-Z][0-9]{2}(?:\.[A-Za-z0-9]{1,4})?|[0-9]{5}|[0-9]{4,5}-[0-9]{3,4}-[0-9]{1,2}|[0-9]{4,5}-[0-9])\b', answer))
    cited = {row['id']: row for row in reply.get('knowledge', {}).get('sources', [])
             if row['id'] in reply.get('evidence_ids', [])}
    supported_codes = {code for source in cited.values() if source.get('kind') in {'clinical_code', 'product_codelist'}
                       for code in mentioned_codes if re.search(r'(?<![A-Za-z0-9])' + re.escape(code) + r'(?![A-Za-z0-9])', source['text'])}
    checks['no_uncited_exact_code'] = mentioned_codes <= supported_codes
    if spec['expect'] == 'changed_intent':
        checks['changed_intent_in_brief'] = brief['state']['request'][case['changed_slot']] == case['changed_value']
        checks['changed_intent_in_form'] = after_values[case['changed_slot']] == case['changed_value']
        checks['unresolved_choice_preserved'] = bool(before['unknown_slots']) and set(before['unknown_slots']) <= set(brief['unknown_slots'])
        if case['changed_slot'] == 'source_cut':
            checks['previous_source_question_invalidated'] = not active or not question or active['token'] != question['token']
    if spec['expect'] != 'changed_intent':
        checks['original_intent_preserved'] = brief['state']['request'][case['changed_slot']] == case['initial'][case['changed_slot']]
    row = {'turn': number + 1, 'user_text': text, 'resolved_answer_context': expanded if matched else None,
        'question_before': question, 'brief_before': before, 'brief_after': copy.deepcopy(brief),
        'form_before': public, 'validated_prefill': checked_prefill, 'form_after': after_values,
        'reply': reply, 'brief_apply_error': brief_apply_error, 'checks': checks, 'passed': all(checks.values()),
        'preflight': copy.deepcopy(model.preflight_error),
        'status': 'passed' if all(checks.values()) else 'failed'}
    history.append({'question': text, 'answer': reply.get('answer', '')})
    return row, brief, after_values


def _packet(proposal, journeys, elapsed, stop_reason):
    results, runs = [], []
    for scoped, journey in zip(proposal['cases'], journeys):
        case = scoped['case']
        checks = {f'turn_{row["turn"]}:{name}': ok for row in journey['turns'] for name, ok in row.get('checks', {}).items()}
        checks['all_four_turns_completed'] = len(journey['turns']) == 4 and all(r['status'] == 'passed' for r in journey['turns'])
        calls = sum(len(r.get('calls', [])) for r in journey['turns'])
        uncertain = sum(r.get('status') == 'interrupted' for r in journey['turns'])
        run = {'run_id': journey['run_id'], 'goal': case['goal'], 'primary_pack': proposal['pack'],
            'actor': 'Synthetic evaluation author', 'model_id': proposal['connection']['model'],
            'steps': [{'kind': 'decision', 'turn': row['turn'], 'reply': row.get('reply'), 'status': row['status']} for row in journey['turns']],
            'outcome': {'status': 'done' if all(checks.values()) else 'escalated'},
            'metrics': {'model': proposal['connection']['model'], 'calls': None if uncertain else calls,
                        'total_calls': None if uncertain else calls, 'observed_calls': calls, 'uncertain_calls': uncertain,
                        'input_tokens': None, 'output_tokens': None, 'est_cost_usd': None},
            'conversation': journey['turns']}
        result = lifecycle._case_runner().score(case, SimpleNamespace(**run))
        result['checks'].update(checks)
        result['metrics'].update(observed_calls=calls, uncertain_calls=uncertain)
        result.update(passed=all(result['checks'].values()), needs_human=True,
            status='skipped' if all(t['status'] == 'skipped' for t in journey['turns']) else ('passed' if all(checks.values()) else 'failed'))
        results.append(result)
        runs.append({'run': run, 'sha256': runtime.digest(run)})
    return {'record_type': 'canonical_case_evaluation', 'evaluation_mode': 'multi_turn_conversation',
        'execution_surface': 'Guide backend with synthetic brief and validated current-form proposals',
        'objective_id': 'intake_elicitation_model', 'request_id': proposal['request_id'],
        'cases': proposal['cases'], 'connection': proposal['connection'], 'preview_digest': proposal['digest'],
        'input_digests': proposal['versions'], 'corpus_digest': proposal['versions'][CORPUS],
        'results': results, 'runs': runs, 'elapsed_seconds': elapsed, 'stop_reason': stop_reason,
        'adjudicated': False, 'training_eligible': False, 'clinical_quality': 'human_review_required',
        'semantic_improvement': None, 'cost_known': False, 'cost_usd': None,
        'recorded_by': proposal['actor'], 'created_at': datetime.now(timezone.utc).isoformat(),
        'notice': NOTICE, 'storage': proposal['storage']}


def run(root, pack, actor_id, proposal, *, allowed_packs, confirmed, local_demo, can_review):
    """Explicit bounded run; a retained or interrupted request never repeats calls."""
    lifecycle._permission(local_demo, can_review, confirmed)
    root, directory = _scope(root, pack, actor_id, allowed_packs)
    request_id = proposal.get('request_id')
    if not isinstance(request_id, str) or not re.fullmatch(r'[a-f0-9]{32}', request_id):
        raise ValueError('Prepare the current conversation preview before running.')
    path = directory / (request_id + '.json')
    import local_process_lock
    directory.mkdir(parents=True, exist_ok=True)
    with local_process_lock.locked(path.with_suffix('.lock'), directory):
        if path.exists():
            journal = _load(path)
            if journal.get('proposal') != proposal:
                raise ValueError('This evaluation request differs from its retained preview.')
            if journal.get('evaluation_id'):
                return dict(read(root, pack, actor_id, journal['evaluation_id'], allowed_packs=allowed_packs), ok=True, changed=False)
            stop_reason = 'interrupted_request_not_replayed'
            pending = journal.get('in_flight')
            if pending:
                journey = journal['journeys'][pending['case']]
                if len(journey['turns']) == pending['turn']:
                    journey['turns'].append({'turn': pending['turn'] + 1, 'status': 'interrupted',
                        'passed': False, 'checks': {'response_recovered': False},
                        'reason': 'The process ended during this turn; whether the model completed is unknown. No replay was attempted.'})
        else:
            _fresh(root, pack, actor_id, proposal, allowed_packs)
            journal = {'proposal': proposal, 'journeys': [{'run_id': uuid.uuid4().hex, 'turns': []} for _ in proposal['cases']]}
            _save(path, journal)
            stop_reason = None
        started = time.monotonic()
        if not stop_reason:
            config = ai._provider(root)
            client = config.get('instance') or ai._make_model(config['model'], config['spec'])
            with tempfile.TemporaryDirectory(prefix='rwd-chat-eval-') as temporary:
                synthetic = Path(temporary)
                _synthetic(root, synthetic)
                import conversation_intake as intake
                for ci, scoped in enumerate(proposal['cases']):
                    case, journey = scoped['case'], journal['journeys'][ci]
                    brief = intake.edit(intake.new(synthetic, None, 'Synthetic evaluation author', allowed_packs=[],
                        connection=proposal['connection'], source={'public_reference': proposal['versions'][PUBLIC]}), case['initial'])
                    values = {name: case['initial'][name] for name in (case['changed_slot'], 'acceptance_criteria')}
                    history = []
                    for ti in range(4):
                        if stop_reason:
                            break
                        if portal_runtime.job_cancelled():
                            stop_reason = 'cancelled'
                            break
                        if time.monotonic() - started >= proposal['max_seconds']:
                            stop_reason = 'total_time_budget'
                            break
                        try:
                            _fresh(root, pack, actor_id, proposal, allowed_packs)
                        except (ValueError, OSError):
                            stop_reason = 'inputs_or_connection_changed'
                            break
                        journal['in_flight'] = {'case': ci, 'turn': ti}
                        _save(path, journal)
                        portal_runtime.job_progress(f'{case["title"]}: question {ti + 1} of 4')
                        capture = _Capture(client)
                        try:
                            row, brief, values = _turn(case, ti, brief, history, values, capture, synthetic)
                        except Exception as error:
                            row = {'turn': ti + 1, 'status': 'failed', 'passed': False,
                                   'checks': {'completed_with_current_inputs': False}, 'error_type': type(error).__name__}
                        try:
                            _fresh(root, pack, actor_id, proposal, allowed_packs)
                        except (ValueError, OSError):
                            row['checks']['inputs_and_connection_still_current'] = False
                            row.update(status='failed', passed=False, error_code='stale_inputs')
                            stop_reason = 'inputs_or_connection_changed'
                        row['calls'] = copy.deepcopy(capture.calls)
                        journey['turns'].append(row)
                        journal.pop('in_flight', None)
                        _save(path, journal)
                        if row['status'] != 'passed':
                            reply = row.get('reply') or {}
                            if not stop_reason and capture.preflight_error:
                                stop_reason = 'evaluation_preflight_refused'
                            elif not stop_reason and (not reply or reply.get('source') != 'assistant' and reply.get('error_code') != 'invalid_response'):
                                stop_reason = 'assistant_connection_or_context_unavailable'
                            journey['stop_reason'] = 'failed_turn_no_automatic_retry'
                            break
        for journey in journal['journeys']:
            while len(journey['turns']) < 4:
                journey['turns'].append({'turn': len(journey['turns']) + 1, 'status': 'skipped',
                    'passed': False, 'checks': {'executed': False}, 'reason': journey.get('stop_reason') or stop_reason or 'not_executed'})
        packet = _packet(proposal, journal['journeys'], round(time.monotonic() - started, 3), stop_reason)
        if len(json.dumps(packet, ensure_ascii=False).encode()) > MAX_RECEIPT_BYTES - 10_000:
            raise ValueError('The retained evaluation exceeds its packet limit; the private call journal remains available.')
        record = _write(root, pack, actor_id, packet, allowed_packs)
        journal['evaluation_id'] = record['id']
        _save(path, journal)
        return dict(record, ok=True, changed=True)
