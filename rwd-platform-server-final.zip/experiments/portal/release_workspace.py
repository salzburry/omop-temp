"""Read exact build evidence and request its review; never promote or approve.

The owning gate, manifest and approval readers supply every scientific verdict.
A handoff binds the bytes reviewed here and records work, not release authority.
"""
from __future__ import annotations

import copy
import hashlib
import json
from pathlib import Path

import yaml

import approval_record
from engine import refresh
import handoffs
import source_manifest
import source_workspace
import specification_details
import status

NOTICE = "Checking or handing off this evidence does not approve a build, run a promotion or release a product."
PREFIX = "release-review:"
LIMIT = 8 * 1024 * 1024


def _sha(value):
    raw = value if isinstance(value, bytes) else json.dumps(value, sort_keys=True, default=str).encode()
    return hashlib.sha256(raw).hexdigest()


def _safe(path):
    path = Path(path).absolute()
    if path.resolve() != path:
        raise ValueError("Release evidence redirects to another location. Ask the data expert to repair its canonical path.")
    return path


def _raw(path):
    path = _safe(path)
    if path.stat().st_size > LIMIT:
        raise ValueError("Release metadata exceeds the 8 MB limit. Ask the data expert to review the evidence location.")
    return path.read_bytes()


def _scope(root, pack, actor_id, allowed_packs):
    source, pack = specification_details._paths(root, pack, allowed_packs)
    if not isinstance(actor_id, str) or not actor_id.strip() or len(actor_id) > 200:
        raise ValueError("An identified portal session is required.")
    root, product = Path(root).resolve(), source.parent
    source_workspace._configured_inputs(product)
    return root, product, pack


def _inputs(root, product):
    """Preflight canonical readers and bind mutable evidence, including ledger trust."""
    files = source_workspace._inputs(root, product)
    # The canonical gate readers also consume shared policies, reference definitions,
    # approval events and refresh metadata. Refuse redirects before any reader runs.
    names = specification_details._accepted_products(root, product.relative_to(root).as_posix())
    for directory in (root / "governance", root / "refreshes"):
        _safe(directory)
        if directory.is_dir():
            for path in sorted(directory.rglob("*")):
                _safe(path)
                if path.is_file() and path.suffix.lower() in {".yaml", ".yml", ".json", ".jsonl", ".md"}:
                    raw = _raw(path)
                    if path.suffix.lower() in {".yaml", ".yml"} and any(
                            isinstance(token, (yaml.AliasToken, yaml.AnchorToken)) for token in yaml.scan(raw)):
                        raise ValueError("Release metadata uses YAML aliases. Ask Engineering to review the metadata before checking release readiness.")
                    files[path.relative_to(root).as_posix()] = _sha(raw)
                    if directory.name == "refreshes" and path.suffix.lower() in {".yaml", ".yml"}:
                        document = yaml.load(raw, Loader=specification_details._StrictLoader)
                        if isinstance(document, dict) and str(document.get("tumor") or "") in names \
                                and str(document.get("spec_version") or "") == product.name:
                            files.update(_artifact_inputs(root, product, document))
    return files


def _artifact_inputs(root, product, document):
    """Bound any local file hashes the canonical publication validator may read.

    Cluster paths remain unavailable here and are explicitly reported by its own
    unverified-artifacts API. A receipt cannot grant access to arbitrary local files.
    """
    files = {}
    artifacts, kinds = document.get("artifacts") or {}, document.get("artifact_types") or {}
    if not isinstance(artifacts, dict) or not isinstance(kinds, dict):
        return files  # The owning manifest validator reports malformed structures.
    for name, value in artifacts.items():
        if kinds.get(name) != "file" or not isinstance(value, str) or not value.strip():
            continue
        value = value.strip()
        if value.startswith(("dbfs:/", "abfss://", "s3://")):
            continue
        if value.startswith("/Volumes/") and not Path(value).is_file():
            continue
        path = Path(value)
        if not path.is_absolute() or value.startswith(("\\\\", "//")):
            raise ValueError("A release artifact uses an unscoped local or network path. Ask the data expert to verify it in the governed runtime before reviewing publication here.")
        path = _safe(path)
        if not (path.is_relative_to(product) or path.is_relative_to(root / "refreshes")) \
                or path.suffix.lower() not in {".yaml", ".yml", ".json", ".md", ".txt", ".html"}:
            raise ValueError("A release artifact points outside this product's review metadata. Ask the data expert to verify the artifact in its governed runtime; this workspace does not open patient data or arbitrary files.")
        if path.is_file():
            files[path.relative_to(root).as_posix()] = _sha(_raw(path))
    return files


def _binding(root, product, pack, actor_id, files):
    return _sha({"root": str(root), "pack": pack, "actor": actor_id, "files": files})


def _build(doc):
    release = doc.get("release") or {}
    return str(release.get("build_id") or "") if isinstance(release, dict) else ""


def _receipts(root, pack):
    family, slug, cut = pack.split("/")[1:]
    found = []
    # Use the canonical registry-code/content matcher, rather than assuming code == slug.
    for path, doc in source_manifest.receipts_for(str(root), slug, cut):
        target = _safe(root / path)
        if not target.is_relative_to(root / "refreshes") or str(doc.get("family") or family) != family:
            continue
        found.append({"receipt": path.replace("\\", "/"), "build_id": _build(doc),
                      "status": str(doc.get("status") or "unknown"), "built_at": str(doc.get("built_at") or ""),
                      "manifest_sha256": _sha(_raw(target)), "document": doc})
    return found


def _fail(error):
    return {"ok": False, "errors": [str(error)], "notice": NOTICE}


def describe(root, pack, actor_id, *, allowed_packs=None, receipt=None):
    """No selection means no candidate verdict. A receipt is an allowlisted local record."""
    try:
        root, product, pack = _scope(root, pack, actor_id, allowed_packs)
        before = _inputs(root, product)
        candidates = _receipts(root, pack)
        gates = [{"gate": number, "title": title, "state": state, "blockers": list(blockers)}
                 for number, title, state, blockers in status.gates(str(root), pack)]
        form = product / "handoff/RELEASE_APPROVAL.yaml"
        approval = yaml.safe_load(_raw(form)) if form.is_file() else {}
        if not isinstance(approval, dict):
            approval = {}
        approval_summary = {key: str(approval.get(key) or "") for key in (
            "approved_build_id", "approved_manifest_sha256", "validated_by", "validation_date", "approved_by", "approval_date")}
        selected = None
        if receipt:
            selected = next((copy.deepcopy(row) for row in candidates if row["receipt"] == receipt), None)
            if selected is None:
                raise ValueError("That receipt is no longer available for this product. Choose its current recorded build.")
            doc = selected.pop("document")
            findings = list(refresh.validate_manifest(copy.deepcopy(doc)))
            try:
                verdict = refresh.candidate_verdict(copy.deepcopy(doc))
            except (TypeError, AttributeError, KeyError, ValueError):
                verdict = {"passed": False, "failures": ["The candidate's stage blocks are malformed."],
                           "evaluated": [], "not_evaluated": []}
            selected.update(manifest_errors=findings, verdict=verdict,
                            unverified_artifacts=refresh.unverified_artifacts(copy.deepcopy(doc)) if not findings else [])
            same_build = [row for row in candidates if row["build_id"] == selected["build_id"]]
            selected["multiple_receipts"] = len(same_build) > 1
            selected["published_errors"] = (source_manifest.promoted_receipt_errors(
                str(root), pack.split("/")[2], pack.split("/")[3], selected["build_id"])
                if selected["build_id"] else ["The receipt does not identify an exact build."])
            selected["published"] = not selected["published_errors"]
            if selected["status"] == "released":
                # Promotion changes receipt bytes. The candidate digest cannot be reconstructed
                # from the released copy; the owning publication checker binds the build instead.
                selected["approval_errors"] = []
                selected["candidate_binding_checked"] = False
            else:
                selected["approval_errors"] = source_manifest.publish_approval_errors(
                    str(root), pack, selected["build_id"], selected["manifest_sha256"], manifest=doc)
                selected["candidate_binding_checked"] = True
            selected["seal_errors"] = approval_record.sealed_errors(str(root), pack, "release")
            selected["trust"] = approval_record.trust(str(root), pack, "release")
        after = _inputs(root, product)
        if before != after:
            raise ValueError("Release evidence changed while it was checked. Check the current build again.")
        return {"ok": True, "errors": [], "pack": pack, "digest": _binding(root, product, pack, actor_id, before),
                "gates": gates, "approval": approval_summary, "selected": selected,
                "candidates": [{k: v for k, v in row.items() if k != "document"} for row in candidates],
                "production_product": pack.startswith("products/"), "notice": NOTICE}
    except (OSError, ValueError, TypeError, KeyError, AttributeError, yaml.YAMLError,
            specification_details._Invalid, source_workspace.Invalid) as error:
        return _fail(error)


def request_review(root, pack, actor_id, *, receipt, expected_digest, owner, note,
                   allowed_packs=None, local_demo=False, can_write=False):
    """Explicit exact-evidence handoff. Canonical product files and study pins stay intact."""
    try:
        if local_demo is not True or can_write is not True:
            raise ValueError("Requesting this review requires an authorized local editing session.")
        if owner not in {"Data expert", "Reviewer", "Engineering"}:
            raise ValueError("Choose Data expert, Reviewer or Engineering for the release work.")
        if not isinstance(note, str) or not note.strip() or len(note) > 1800:
            raise ValueError("Describe what this owner should check, using 1 to 1800 characters.")
        current = describe(root, pack, actor_id, receipt=receipt, allowed_packs=allowed_packs)
        if not current["ok"]:
            return current
        if current["digest"] != expected_digest:
            raise ValueError("The product, approval or build evidence changed. Check the exact build again before requesting review.")
        selected = current["selected"]
        if not selected or not selected["build_id"]:
            raise ValueError("Choose a receipt that names an exact build before requesting its review.")
        if not current["production_product"]:
            raise ValueError("Reference and demo packs do not release. Open the intended working product first.")
        root, product, pack = _scope(root, pack, actor_id, allowed_packs)
        if _binding(root, product, pack, actor_id, _inputs(root, product)) != expected_digest:
            raise ValueError("Release evidence changed before the request was recorded. Check again.")
        text = (f"Exact build: {selected['build_id']}; receipt: {selected['receipt']}; "
                f"receipt SHA256: {selected['manifest_sha256']}; reviewed context SHA256: {expected_digest}. "
                f"Recorded state: {selected['status']}. Candidate binding checked: {selected['candidate_binding_checked']}. "
                "Recheck current evidence before acting; this request is not an approval or promotion. " + note.strip())
        document = handoffs.create(root, pack, title="Review exact build " + selected["build_id"], owner=owner,
            note=text, requested_by=actor_id, action_id=PREFIX + _sha([receipt, selected["manifest_sha256"]])[:24],
            allowed_packs=allowed_packs, local_demo=local_demo, can_view=can_write)
        return {"ok": True, "changed": True, "handoff": document, "errors": [], "notice": NOTICE}
    except (OSError, ValueError, handoffs.Refused, specification_details._Invalid, source_workspace.Invalid) as error:
        return _fail(error)


def recent(root, pack, actor_id, *, allowed_packs=None):
    # Existing handoff recent rows provide the shared, resumable record without duplication.
    return []
