"""Reviewed coding result → branch artifacts → checked capability → Plan changes."""
from __future__ import annotations

import difflib
import json
import streamlit as st
import pattern_workspace as workspace
import specialist_workspace as specialist
import form_assistance as form_help

PREFIX = "pattern_ws_"


def _runtime_receipt(result):
    receipt = result["receipt"]
    st.write("Runtime outcome: **" + receipt["status"] + "** · " + receipt["created_at"][:19])
    if result.get("stale"):
        st.warning("The branch, code, configuration, test or review context changed. These historical outcomes cannot validate the current implementation.")
        st.caption(result.get("freshness_explanation", "Review current dependency versions."))
        if result.get("changed_files"):
            st.dataframe(result["changed_files"], hide_index=True)
    st.caption(receipt["notice"])
    st.caption("Broad suites exercise existing synthetic reference configurations. The selected product's scientific interpretations and actual delivery still require their workflow checks.")
    st.caption("Branch " + receipt["proposal"]["branch"]["name"] + " · HEAD " + receipt["proposal"]["branch"]["head"][:12] + " · immutable outcome " + receipt["id"])
    for lane in receipt["outcome"]["lanes"]:
        st.write(lane["title"] + ": **" + lane["status"] + "**")
        st.caption(lane["reason"])
        if lane.get("r_conformance"):
            st.caption("R conformance: " + lane["r_conformance"])
        if lane["id"] == "selected_product":
            st.caption("This product's reviewed expected cells were executed and matched." if lane.get("selected_product_build") is True else
                       "This product's expected-output check remains unproven.")
            if lane.get("expected_cases"):
                st.dataframe(lane["expected_cases"], hide_index=True)
        if lane.get("expected_execution_mode"):
            st.caption("Execution mode: local Spark. Distributed worker recovery was not tested."
                if lane.get("execution_mode") == "local_cohort_checkpoints" else
                "Local Spark execution was not verified for this result.")
        if lane["tests"]:
            st.dataframe(lane["tests"], hide_index=True)
    with st.expander("Exact runtime versions and file hashes"):
        st.json({"runtime": receipt["proposal"]["runtime"], "before": receipt["proposal"]["inputs"],
                 "after": receipt["after"], "receipt_digest": receipt["digest"]})
    for index, followup in enumerate(result.get("followups", [])):
        if followup.get("explanation"):
            st.info(followup["explanation"])
        if st.button(followup["label"], key=PREFIX + "skip_" + receipt["id"] + "_" + str(index)):
            return {"route": followup["route"], "params": followup["params"]}


def _case_table(cases):
    rows = []
    for case in cases:
        for column, value in (case["expected"] or {"": None}).items():
            kind = "null" if value is None else "boolean" if isinstance(value, bool) else "number" if isinstance(value, (int, float)) else "text"
            rows.append({"case": case["id"], "cohort": case["cohort"], "subject": case["patientid"],
                "rows": case["row_count"], "column": column, "type": kind,
                "value": "" if value is None else json.dumps(value) if isinstance(value, (bool, int, float)) else value})
    return rows


def _parse_case_table(rows):
    cases = {}
    if len(rows) > 288:
        raise ValueError("Keep at most twelve cases with twenty-four expected cells each.")
    for row in rows:
        if all(value in (None, "") for value in row.values()):
            continue
        identifier = row.get("case")
        count = row.get("rows")
        if type(count) is float and count in {0.0, 1.0}:
            count = int(count)
        value = {"id": identifier, "cohort": row.get("cohort"), "patientid": row.get("subject"),
                 "row_count": count, "expected": {}}
        previous = cases.setdefault(identifier, value)
        if any(previous[key] != value[key] for key in ("cohort", "patientid", "row_count")):
            raise ValueError("Rows belonging to one case must use the same cohort, subject and expected row count.")
        column, kind, literal = row.get("column"), row.get("type"), row.get("value")
        if row.get("rows") == 0 and not column and literal in (None, ""):
            continue
        if not column or column in previous["expected"]:
            raise ValueError("Use one explicit expected value for each output column in a case.")
        if kind == "null":
            if literal not in (None, ""):
                raise ValueError("Leave the value blank when the expected value is null.")
            expected = None
        elif kind == "text":
            expected = str(literal or "")
        elif kind in {"number", "boolean"}:
            try:
                expected = json.loads(str(literal))
            except (ValueError, TypeError):
                raise ValueError("Use a literal number, or true/false for a boolean.") from None
            if (kind == "number" and type(expected) not in {int, float}) or (kind == "boolean" and type(expected) is not bool):
                raise ValueError("The entered value does not match its selected type.")
        else:
            raise ValueError("Choose a type for each expected cell.")
        previous["expected"][column] = expected
    return list(cases.values())


def _synthetic_cases_form(root, pack, actor_id, record_id, *, allowed_packs, local_demo, can_write, can_review):
    report = workspace.synthetic_case_options(root, pack, actor_id, record_id=record_id, allowed_packs=allowed_packs)
    with st.expander("Review expected outputs for this product", expanded=not report.get("saved")):
        if not report["ok"]:
            _errors(report)
            return
        st.write("Use the shared fabricated subjects and this product's configured cohorts. Enter expected values from your reviewed definition, before running the build. One table row describes one expected output cell; repeat the case identifier for more cells.")
        st.caption("The fixture starts at 2020-01-01, uses subject p1 and pc<cohort number>, and supplies configured source roles. Dates use ISO text. An excluded subject has expected row count 0 and no output cells. These are synthetic software expectations, not scientific approval.")
        st.caption("Fixture: " + report["context"]["fixture"] + " · " + report["context"]["fixture_sha256"][:12])
        for issue in report["issues"]:
            st.warning(issue)
        saved = report["saved"]
        import pandas as pd
        data = pd.DataFrame(_case_table(saved["cases"] if saved else []), columns=["case", "cohort", "subject", "rows", "column", "type", "value"])
        table = st.data_editor(data, num_rows="dynamic", hide_index=True, key=PREFIX + "case_table", column_config={
            "case": st.column_config.TextColumn("Case identifier", help="For example baseline_subject. This name does not supply an expectation."),
            "cohort": st.column_config.SelectboxColumn("Configured cohort", options=[c["id"] for c in report["cohorts"]]),
            "subject": st.column_config.SelectboxColumn("Synthetic subject", options=report["subjects"]),
            "rows": st.column_config.SelectboxColumn("Expected row count", options=[0, 1]),
            "column": st.column_config.TextColumn("Output column"),
            "type": st.column_config.SelectboxColumn("Expected type", options=["text", "number", "boolean", "null"]),
            "value": st.column_config.TextColumn("Expected literal value")})
        note = st.text_area("Basis for these expected values and remaining scientific questions", value=(saved or {}).get("review_note", ""), key=PREFIX + "case_note")
        rows = table.astype(object).where(table.notna(), None).to_dict("records")
        state = json.dumps({"rows": rows, "note": note, "source": report["digest"]}, sort_keys=True, default=str)
        if st.button("Preview expected-output diff", key=PREFIX + "case_preview"):
            try:
                cases = _parse_case_table(rows)
                result = workspace.preview_synthetic_cases(root, pack, actor_id, record_id=record_id, cases=cases, note=note,
                    expected_digest=report["digest"], allowed_packs=allowed_packs)
                if result["ok"]:
                    st.session_state[PREFIX + "case_proposal"] = (state, result["proposal"])
                else:
                    _errors(result)
            except ValueError as error:
                st.error(str(error))
        proposal = st.session_state.get(PREFIX + "case_proposal")
        if proposal:
            st.code(proposal[1]["diff"], language="diff")
            confirmed = st.checkbox("I reviewed these independent synthetic expectations and want to save this exact diff.", key=PREFIX + "case_confirm")
            if proposal[0] != state:
                st.warning("The case values, notes or source changed. Preview the diff again.")
            if st.button("Save reviewed expected outputs", key=PREFIX + "case_save",
                disabled=not(confirmed and proposal[0] == state and local_demo and can_write and can_review)):
                outcome = workspace.save_synthetic_cases(root, pack, actor_id, record_id=record_id, proposal_id=proposal[1]["id"],
                    confirmed=True, allowed_packs=allowed_packs, local_demo=local_demo, can_write=can_write, can_review=can_review)
                if outcome["ok"]:
                    st.session_state.pop(PREFIX + "runtime_proposal", None)
                    st.session_state.pop(PREFIX + "case_proposal", None)
                    return {"route": workspace.ROUTE, "params": {"record_id": record_id}, "changed": True}
                _errors(outcome)


def _runtime_progress(root, pack, actor_id, record_id, *, allowed_packs, local_demo, can_write, can_review):
    """Reopen the saved job before any installation form selection is required."""
    import portal_jobs_page
    job_key = "implementation:" + pack + ":" + record_id
    finished = portal_jobs_page.render(root, actor_id, action="implementation_runtime", job_key=job_key,
        can_write=bool(local_demo and can_write and can_review), allowed_packs=allowed_packs, key=PREFIX + "runtime_job")
    if finished:
        if finished.get("ok"):
            st.caption("The action finished. Its saved outcome and current file freshness appear in the implementation history above.")
        else:
            _errors(finished)


def _runtime_form(root, pack, actor_id, record_id, values, *, allowed_packs, local_demo, can_write, can_review, stale):
    import implementation_runtime
    import portal_jobs
    st.write("**4 · Run the installed implementation against synthetic data**")
    job_key = "implementation:" + pack + ":" + record_id
    st.write("First install and review the exact retained function and tests in the named branch modules above. Preview verifies their match and engine call path. Execution uses an isolated copy of those files and existing synthetic fixtures; candidate files are never imported.")
    selected = st.multiselect("Runtime checks", list(implementation_runtime.SUITES), default=["declared"],
        format_func=lambda key: implementation_runtime.SUITES[key]["title"], key=PREFIX + "runtime_suites")
    st.caption("The reviewed implementation's declared tests always run, including when you select a broader suite.")
    if "synthetic_pipeline" in selected:
        st.caption("The composed pipeline runs locally with every configured cohort. These checks do not test recovery after a distributed worker fails.")
    if "selected_product" in selected:
        navigation = _synthetic_cases_form(root, pack, actor_id, record_id, allowed_packs=allowed_packs,
            local_demo=local_demo, can_write=can_write, can_review=can_review)
        if navigation:
            return navigation
    if st.button("Preview installed code and runtime checks", key=PREFIX + "runtime_preview", disabled=stale or not selected):
        result = workspace.runtime_preview(root, pack, actor_id, record_id=record_id, values=values, suite_ids=selected, allowed_packs=allowed_packs)
        if result["ok"]:
            st.session_state[PREFIX + "runtime_proposal"] = result["proposal"]
        else:
            st.session_state.pop(PREFIX + "runtime_proposal", None)
            _errors(result)
    proposal = st.session_state.get(PREFIX + "runtime_proposal")
    if not proposal:
        return
    matches = proposal["values"] == values and proposal["suite_ids"] == selected
    if not matches:
        st.warning("The implementation fields or selected checks changed. Preview them again before running.")
    limits = "; ".join(lane["title"] + ": " + str(lane.get("timeout_seconds", implementation_runtime.PER_SUITE_SECONDS) // 60) + " minutes"
        for lane in proposal["lanes"])
    st.caption(f"Maximum time for the selected checks: {limits}; {implementation_runtime.TOTAL_SECONDS // 60} minutes overall. Progress is saved while you leave this page. Missing runtimes, skipped assertions, failures and timeouts remain visible.")
    st.json({"branch": proposal["branch"], "runtime": {k: v for k, v in proposal["runtime"].items() if k != "environment_profile"}, "tests": proposal["lanes"]})
    if proposal["runtime"].get("environment_profile"):
        with st.expander("Compare this environment with the tested dependency profile"):
            st.json(proposal["runtime"]["environment_profile"])
    if proposal.get("dependency_manifest"):
        st.caption(proposal["dependency_manifest"]["reason"])
    for action in proposal["runtime"].get("actions", []):
        st.info(action)
    with st.expander("Review the exact installed files to be executed"):
        st.json(proposal["inputs"])
    confirmed = st.checkbox("I reviewed the installed branch code and named tests and want to execute these checks on synthetic fixtures.", key=PREFIX + "runtime_confirm")
    if st.button("Run reviewed synthetic checks", key=PREFIX + "runtime_run",
        disabled=not(matches and confirmed and not stale and local_demo and can_write and can_review)):
        try:
            portal_jobs.start(root, actor_id, action="implementation_runtime", job_key=job_key,
                arguments=dict(pack=pack, record_id=record_id, proposal_id=proposal["id"],
                    confirmed=confirmed, local_demo=local_demo, can_write=can_write, can_review=can_review),
                confirmed=confirmed, can_write=bool(local_demo and can_write and can_review), allowed_packs=allowed_packs)
            st.rerun()
        except (ValueError, OSError) as error:
            st.error(str(error))


def _errors(result):
    for error in result.get("errors", []):
        st.error(error)


def integration_details(result):
    context = (result.get("implementation_context") or {}).get("orchestration")
    plan = (result.get("proposal") or {}).get("integration")
    if not context and not plan:
        return
    with st.expander("Review pipeline integration and remaining runtime checks"):
        st.caption("Actual static declarations and proposed integration work. No pipeline, generated code, tests or job was executed by this review.")
        if context:
            st.write("Current engine entry points")
            for point in context.get("entry_points", []):
                st.code(point, language="text")
            if context.get("stage_calls"):
                st.dataframe(context["stage_calls"], hide_index=True)
            st.json({key: context.get(key) for key in ("configuration", "jobs", "ci_commands")})
            for finding in context.get("findings", []):
                st.warning(finding)
            st.caption("Source snapshots: " + ", ".join(file["path"] + " · " + str(file.get("sha256") or "absent") for file in context.get("files", [])))
        if plan:
            st.write("Proposed integration plan")
            st.json(plan)


def _code(result):
    proposal = result.get("proposal") or {}
    generated = proposal.get("generated") or {}
    reuse = proposal.get("reuse")
    if isinstance(reuse, dict):
        st.write("**Existing capability: " + str(reuse.get("capability_id", "not identified")) + "**")
        st.write(str(reuse.get("why_it_answers") or "Inspect the requirement and current capability before accepting this reuse."))
        st.code(str(reuse.get("config_sketch") or "No configuration sketch supplied."), language="yaml")
        st.caption("Proposed configuration sketch only. Plan changes validates the actual product diff before it can be saved or submitted.")
    for kind, key in (("Implementation", "code"), ("Tests", "tests")):
        with st.expander("Review " + kind.lower(), expanded=key == "code"):
            st.code(generated.get(key) or "No generated " + key + ".", language="python")
    context = result.get("implementation_context") or {}
    integration_details(result)
    with st.expander("Existing code examined and exact proposed changes"):
        for source in context.get("files", []):
            st.caption(source["path"] + "::" + source["symbol"] + " · SHA256 " + source["sha256"])
            after = generated.get("tests" if source["kind"] == "test" else "code", "")
            st.code("".join(difflib.unified_diff(source["excerpt"].splitlines(True), after.splitlines(True),
                source["path"] + " (supplied excerpt)", "candidate " + source["kind"])), language="diff")
        for omitted in context.get("omissions", []):
            st.caption(omitted)
    st.write("**What was checked**")
    st.json(result.get("deterministic_checks", {}))
    st.caption("Compile and static checks do not execute code or establish scientific correctness.")
    critique = result.get("critic") or {}
    for finding in critique.get("findings", []):
        st.warning(finding)
    for assumption in generated.get("assumptions", []):
        st.write("Unresolved assumption: " + str(assumption))
    if result.get("revisions"):
        with st.expander("Corrections made after static checks or critique"):
            for revision in result["revisions"]:
                st.write(revision["reason"])
                for finding in revision["findings"]:
                    st.write(finding)


def _implementation_params(params):
    next_params = {"kind": "implementation", "variable": params.get("variable", "")}
    request = params.get("user_request")
    if isinstance(request, str) and request.strip() and len(request) <= 4000:
        import scientific_definition_ai as ai
        try:
            ai._ingress(request)
        except ai.Invalid:
            pass
        else:
            next_params["user_request"] = request
    return next_params


def render(root, pack, actor_id, *, allowed_packs, local_demo, can_write, can_review,
           route=workspace.ROUTE, params=None, can_manage_library=False):
    params = params or {}
    context = (str(root), pack, actor_id, params.get("specialist_run"), params.get("specialist_review"), params.get("record_id"))
    if st.session_state.get(PREFIX + "context") != context:
        for key in list(st.session_state):
            if str(key).startswith(PREFIX):
                del st.session_state[key]
        st.session_state[PREFIX + "context"] = context
    st.caption(workspace.NOTICE)
    report = workspace.describe(root, pack, actor_id, allowed_packs=allowed_packs)
    if not report["ok"]:
        _errors(report)
        if st.button("Open implementation help", key=PREFIX + "repair"):
            return {"route": "specialist_assistant", "params": _implementation_params(params)}
        return
    for issue in report["problems"]:
        st.warning(issue)
    if report["patterns"]:
        with st.expander("Repeated patterns in accessible product reviews"):
            for pattern in report["patterns"]:
                st.write(f"{pattern['key']} · {pattern['distinct_contexts']} distinct product/requirement contexts")
                st.caption("Structural similarity only. Repeated runs of the same requirement count once; stale reviews do not count.")
    record_id = st.session_state.get(PREFIX + "record_id") or params.get("record_id")
    run_id, review_id = params.get("specialist_run"), params.get("specialist_review")
    if (run_id or review_id) and not record_id:
        try:
            source = (specialist.read(root, pack, actor_id, run_id, allowed_packs=allowed_packs) if run_id else
                      specialist.shared(root, pack, review_id, allowed_packs=allowed_packs))
        except ValueError as error:
            st.error(str(error))
            return
        if source["kind"] != "implementation":
            st.error("Choose an implementation result for this workflow.")
            return
        st.write("**1 · Review the proposed implementation for " + source["question"] + "**")
        _code(source["result"])
        if not source["result"].get("pattern"):
            st.info("This result proposes reuse or has unresolved implementation checks. Reuse can continue through Plan changes; refused code needs a corrected implementation result.")
            if st.button("Plan use of an existing capability", key=PREFIX + "reuse"):
                return {"route": "plan_changes", "params": {"variable": source["question"]}}
        else:
            note = st.text_area("Your review findings and remaining implementation work", key=PREFIX + "note",
                help="Record the actual code/test review, assumptions, dependency effects and checks still required. This is not a scientific approval.")
            confirmed = st.checkbox("I reviewed the code, tests and findings and want to retain these exact artifacts on this product branch.", key=PREFIX + "retain_confirm")
            if st.button("Save reviewed code and tests to the branch", key=PREFIX + "retain",
                         disabled=not(local_demo and can_write and can_review and confirmed and note.strip()) or source["stale"]):
                saved = workspace.persist_result(root, pack, actor_id, run_id=run_id, review_id=review_id, note=note,
                    confirmed=confirmed, allowed_packs=allowed_packs, local_demo=local_demo, can_write=can_write, can_review=can_review)
                if saved["ok"]:
                    st.session_state[PREFIX + "record_id"] = saved["record"]["id"]
                    st.success("Exact code, tests and review provenance saved as branch artifacts. No runtime code was installed.")
                    return {"route": workspace.ROUTE, "params": {"record_id": saved["record"]["id"], "variable": source["question"]}, "changed": True}
                _errors(saved)
        if source["stale"]:
            st.warning("Evidence or code changed since this result. Request a current result before retaining it.")
        return
    if not record_id:
        rows = [r for r in report["rows"] if r["pack"] == pack]
        if rows:
            chosen = st.selectbox("Reviewed implementation", rows, key=PREFIX + "saved", format_func=lambda r: r["requirement"] + " · " + r["created_at"][:19])
            if st.button("Open the reviewed implementation", key=PREFIX + "open"):
                return {"route": workspace.ROUTE, "params": {"record_id": chosen["id"], "variable": chosen["requirement"]}}
        else:
            st.info("Start with the exact scientific definition. The coding specialist examines existing functions and tests and proposes reuse or a reviewed adaptation.")
        if st.button("Examine implementation options", key=PREFIX + "start"):
            return {"route": "specialist_assistant", "params": _implementation_params(params)}
        return
    current = workspace.retained(root, pack, actor_id, record_id=record_id, allowed_packs=allowed_packs)
    if not current["ok"]:
        _errors(current)
        return
    record = current["record"]
    st.write("**2 · Review the branch implementation for " + record["requirement"] + "**")
    _code(record["result"])
    st.caption("Saved at " + pack + "/" + workspace.FOLDER + "/" + record_id + ". Commit these files through Save branch changes.")
    if current["stale"]:
        st.warning("The scientific or source context changed. Review a fresh implementation result before registering a capability.")
    history = workspace.runtime_results(root, pack, actor_id, record_id=record_id, allowed_packs=allowed_packs)
    if not history["ok"]:
        _errors(history)
    elif history["results"]:
        with st.expander("Saved runtime checks for this implementation", expanded=True):
            for result in history["results"]:
                navigation = _runtime_receipt(result)
                if navigation:
                    return navigation
    _runtime_progress(root, pack, actor_id, record_id, allowed_packs=allowed_packs,
        local_demo=local_demo, can_write=can_write, can_review=can_review)
    with st.expander("Ask Engineering to finish the implementation"):
        request_note = form_help.field(st.text_area, "What implementation or runtime checks are still needed?", key=PREFIX + "engineering_note", binding=(pack, record_id, record))
        if st.button("Create an Engineering work request", key=PREFIX + "engineering_request",
            disabled=current["stale"] or not(local_demo and can_write and request_note.strip())):
            outcome = workspace.request_implementation(root, pack, actor_id, record_id=record_id, note=request_note,
                allowed_packs=allowed_packs, local_demo=local_demo, can_write=can_write)
            if outcome["ok"]:
                return {"route": "handoffs", "params": {"handoff_id": outcome["handoff"]["id"]}}
            _errors(outcome)
    st.write("**3 · Identify the installed implementation**")
    st.write("Engineering first places the reviewed Python function and named tests in their real engine/test modules and implements the R counterpart. Enter those existing symbols below; the registry checker verifies they exist. This form saves only the canonical capability declaration and catalogue.")
    st.caption("The Python function and tests must match the retained review. Source implementation and scientific decisions are reviewed separately; declaring an R symbol does not prove parity.")
    st.caption("The Python function must be the selected existing capability entry or a helper it calls in the same module. New-module or dynamic wiring needs Engineering to establish the engine path first.")
    caps = report["capabilities"]
    try:
        application = workspace.read_application(root, pack, record_id, allowed_packs=allowed_packs)
    except (ValueError, OSError):
        application = None
    if application:
        st.info("This capability declaration is already saved on the branch. Continue with the installed runtime checks below, then configure its use in Plan changes. Its verification remains declared until the separate evidence supports more.")
    # A saved declaration carries the installation fields so another scoped
    # reviewer can continue into runtime checks in this same workflow.
    if PREFIX + "base" not in st.session_state:
        saved = (application or {}).get("implementation_values", {})
        if saved:
            st.session_state[PREFIX + "base"] = next((cap for cap in caps if cap["id"] == saved.get("base_capability_id")), None)
            for key, value in saved.items():
                if key != "base_capability_id":
                    st.session_state[PREFIX + key] = "\n".join(value) if isinstance(value, list) else value
    base = st.selectbox("Existing capability family to adapt", caps, index=None, key=PREFIX + "base", format_func=lambda c: c["id"] + " · " + c["master"])
    if base is None:
        return
    st.caption("Inherited family: " + base["master"] + "; supported classifications: " + ", ".join(base["supports"]))
    values = {"base_capability_id": base["id"]}
    labels = {"id": "Capability identifier", "summary": "What the implementation does", "python_module": "Existing Python module path",
              "python_symbol": "Python function name", "r_file": "Existing R file path", "r_symbol": "R function name"}
    for key, label in labels.items():
        values[key] = form_help.field(st.text_input, label, key=PREFIX + key, binding=(pack, record_id, record, base["id"]), help="Use a real declared path or symbol. Paths start platform/." if "module" in key or "file" in key else None)
    for key, label in (("config_keys", "Configuration keys consumed, one per line"), ("emits", "Output columns, one per line"), ("tests", "Existing tests: platform/tests/file.py::test_name, one per line")):
        values[key] = [line.strip() for line in form_help.field(st.text_area, label, key=PREFIX + key, binding=(pack, record_id, record, base["id"])).splitlines() if line.strip()]
    runtime_navigation = _runtime_form(root, pack, actor_id, record_id, values, allowed_packs=allowed_packs,
        local_demo=local_demo, can_write=can_write, can_review=can_review, stale=current["stale"])
    if runtime_navigation:
        return runtime_navigation
    st.write("**5 · Review the capability declaration**")
    st.caption("Verification will be recorded as declared for both engines. This action does not run tests or change existing consumers.")
    if st.button("Validate and review the capability diff", key=PREFIX + "stage",
                 disabled=bool(application) or current["stale"] or not(local_demo and can_write and can_review)):
        result = workspace.stage(root, pack, actor_id, record_id=record_id, values=values, allowed_packs=allowed_packs,
            local_demo=local_demo, can_write=can_write, can_review=can_review)
        if result["ok"]:
            st.session_state[PREFIX + "proposal"] = result["proposal"]
        else:
            st.session_state.pop(PREFIX + "proposal", None)
            _errors(result)
    proposal = st.session_state.get(PREFIX + "proposal")
    if proposal:
        matches = proposal["values"] == values
        if not matches:
            st.warning("The form changed. Validate the updated fields before applying this diff.")
        st.info(proposal["validation"])
        for file in proposal["files"]:
            with st.expander("Exact diff · " + file["path"], expanded=True):
                st.code(file["diff"], language="diff")
        st.json(proposal["impact"])
        confirm = st.checkbox("I reviewed this exact registry diff and want to save its declaration on this branch.", key=PREFIX + "apply_confirm")
        if not can_manage_library:
            st.info("A shared-library administrator applies the checked declaration. The product review artifacts are already available on the branch for that reviewer.")
        if st.button("Apply checked capability declaration", key=PREFIX + "apply",
            disabled=not(matches and confirm and local_demo and can_write and can_review and can_manage_library)):
            result = workspace.apply(root, pack, actor_id, proposal_id=proposal["id"], confirmed=confirm,
                allowed_packs=allowed_packs, local_demo=local_demo, can_write=can_write, can_review=can_review, can_manage_library=can_manage_library)
            if result["ok"]:
                st.success(result["message"])
                st.session_state.pop(PREFIX + "proposal", None)
                return {"route": workspace.ROUTE, "params": {"record_id": record_id, "variable": record["requirement"]}, "changed": True}
            _errors(result)
    if st.button("Continue to configure the reviewed capability", key=PREFIX + "configure"):
        return {"route": "plan_changes", "params": {"variable": record["requirement"]}}
