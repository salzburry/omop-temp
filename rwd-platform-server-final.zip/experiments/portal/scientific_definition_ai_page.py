"""Optional, source-bound suggestions within the scientific row editor."""
from __future__ import annotations

import hashlib
import json
from pathlib import Path
from contextlib import nullcontext
import uuid

import streamlit as st

import scientific_definition_ai as assistant
import assistant_layout


PREFIX = "scientific_definition_ai_"
HISTORY_MESSAGES = 16
LABELS = {field: definition[0] for field, definition in assistant.field_choices.TEXT_FIELDS.items()}


def _digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, ensure_ascii=False, default=str).encode()).hexdigest()


def _clear_proposal(*, keep_rendered_widgets=False, clear_conversation=False):
    for key in list(st.session_state):
        if (not keep_rendered_widgets and key.startswith(PREFIX + "select_")) or key in (PREFIX + "proposal", PREFIX + "response", PREFIX + "binding", PREFIX + "feedback_proposal"):
            del st.session_state[key]
        elif clear_conversation and (key == PREFIX + "messages" or key.startswith(PREFIX + "question_")):
            del st.session_state[key]


def _errors(result, fallback):
    for error in result.get("errors") or [fallback]:
        st.error(str(error))


def _text(value):
    if isinstance(value, (dict, list)):
        return json.dumps(value, ensure_ascii=False, indent=2)
    return str(value or "(empty)")


def _feedback_text(values):
    return "\n\n".join(LABELS.get(field, field) + ": " + _text(value) for field, value in values.items())


def _clear_feedback():
    import interaction_feedback_page
    for suffix in ("accepted_feedback", "rejected_feedback"):
        interaction_feedback_page.clear(PREFIX + suffix)
    for suffix in ("feedback_context", "feedback_response", "feedback_accepted", "feedback_proposal"):
        st.session_state.pop(PREFIX + suffix, None)


def _feedback(root, pack, actor_id, working_values, *, can_write, allowed_packs):
    """Offer review of an explicit rejection or a changed, accepted answer only."""
    import interaction_feedback_page
    accepted = st.session_state.get(PREFIX + "feedback_accepted")
    if accepted:
        revised = {field: working_values.get(field) for field in accepted["values"]}
        if revised == accepted["values"]:
            accepted["loaded"] = True
        elif accepted.get("loaded"):
            interaction_feedback_page.offer(root, pack, actor_id, route="scientific_draft",
                interaction_id=accepted["id"], request=accepted["request"],
                answer=_feedback_text(accepted["values"]), revised_answer=_feedback_text(revised), outcome="edited",
                can_write=can_write, allowed_packs=allowed_packs, key=PREFIX + "accepted_feedback")
            return
    response = st.session_state.get(PREFIX + "feedback_response")
    if response and response["answer"]:
        if not response.get("rejected") and st.button("This answer needs changes", key=PREFIX + "reject", disabled=not can_write):
            response["rejected"] = True
        if response.get("rejected"):
            interaction_feedback_page.offer(root, pack, actor_id, route="scientific_draft",
                interaction_id=response["id"], request=response["request"], answer=response["answer"], outcome="rejected",
                can_write=can_write, allowed_packs=allowed_packs, key=PREFIX + "rejected_feedback")


def _accepted_feedback(result, proposal, selected_fields):
    response = st.session_state.get(PREFIX + "feedback_proposal") or st.session_state.get(PREFIX + "feedback_response") or {}
    values = result.get("values") or {item["field"]: item["value"] for item in proposal["suggestions"]}
    st.session_state[PREFIX + "feedback_accepted"] = {"id": response.get("id") or uuid.uuid4().hex,
        "request": response.get("request") or "Suggest wording for the selected scientific definition.",
        "values": {field: values[field] for field in selected_fields}, "loaded": False}


def _question_reply(response):
    """Collect a response for the model; choices never fill scientific fields."""
    questions = response.get("questions") or []
    if not questions:
        return None
    token = _digest(response)[:16]
    st.caption("Choose an answer, write your own, or keep the choice open. These replies help the assistant prepare wording for review.")
    replies = []
    with st.form(PREFIX + "question_form_" + token):
        for question in questions:
            options = {option["id"]: option for option in question["options"]}
            labels = {key: option["label"] for key, option in options.items()}
            labels["__not_sure"] = "Not sure"
            key = PREFIX + "question_" + token + "_" + question["id"]
            choice = st.radio(question["prompt"], list(labels), index=None, format_func=labels.get,
                captions=[option["explanation"] for option in options.values()] + ["Keep this question open and ask for help deciding."],
                key=key + "_choice")
            typed = st.text_area("Your answer or clarification (optional)", key=key + "_text", max_chars=600,
                help="You can reply in your own words without selecting an option.")
            if choice is not None or typed.strip():
                answer = "\n".join(filter(None, [labels.get(choice), typed.strip()]))
                replies.append(question["prompt"] + "\nMy response: " + answer)
        submitted = st.form_submit_button("Send answers", key=PREFIX + "question_send_" + token)
    if not submitted:
        return None
    if not replies:
        st.info("Choose an answer, select Not sure, or write a reply before sending.")
        return None
    request = "\n\n".join(replies)
    if len(request) > 1200:
        st.error("Please shorten your replies so the questions and answers fit within 1,200 characters. Your replies are retained.")
        return None
    return request


def _scientific_context(response):
    context = response.get("scientific_context")
    if not isinstance(context, dict):
        return
    with st.expander("Scientific context used for this answer", expanded=False):
        st.caption("These sources and their recorded statuses were retrieved for this answer. Related context does not settle an unresolved scientific choice.")
        overview = context.get("overview") or {}
        if isinstance(overview.get("current_product_requirement_rows"), int):
            st.text("Requirement rows in this product: " + str(overview["current_product_requirement_rows"]))
        domains = overview.get("domains") or {}
        if domains:
            st.caption("Specification domains: " + ", ".join(str(name) + " (" + str(count) + ")" for name, count in domains.items()))
        omitted = overview.get("omitted") or {}
        skipped = [str(omitted[key]) + " " + label for key, label in
                   (("unavailable_products", "unavailable products"), ("unsafe_rows", "excluded rows"),
                    ("budget_rows", "rows outside the context limit")) if omitted.get(key)]
        if skipped:
            st.caption("Optional context omitted: " + "; ".join(skipped) + ".")
        for notice in context.get("notices") or []:
            st.caption(str(notice))
        references = {reference.get("source_id"): reference for reference in context.get("references") or []}
        sources = context.get("sources") or [source for source in response.get("sources") or []
                                             if source.get("id") in references]
        for source in sources:
            label = source.get("label") or source.get("id") or "Retrieved source"
            kind = source.get("kind")
            st.text(str(label) + (" · " + str(kind) if kind else ""))
            reference = references.get(source.get("id"), {})
            detail = [label + ": " + str(reference[key]) for key, label in
                      (("pack", "Product"), ("item_id", "Row"), ("source_status", "Source status"),
                       ("ai_classification", "AI access"), ("artifact", "Reference"),
                       ("record_id", "Record"), ("recorded_review_date", "Recorded review date"),
                       ("recorded_reviewer", "Recorded reviewer")) if isinstance(reference.get(key), str)]
            if detail:
                st.caption(" · ".join(detail))
            for key, label in (("reference_version", "Reference version"), ("recorded_status", "Recorded status"),
                               ("applicability", "Applicability")):
                if reference.get(key):
                    st.text(label + ": " + str(reference[key]))
            if source.get("text"):
                st.text(str(source["text"]))


def _variable_review_turn():
    import flow_assistant
    reply = flow_assistant.variable_review_answer({"actions": ["open_variable_review"]})
    return {"id": uuid.uuid4().hex, "role": "assistant", "content": reply["answer"] +
            " Your unsaved row entries and existing proposal are retained; save any changes you want included in the table.",
            "variable_review": True}


def _variable_review_action(turn, pack, actor_id):
    if not turn.get("variable_review"):
        return
    if st.button("Review all variables", key=PREFIX + "review_variables_" + turn["id"],
                 on_click=_retain_review_fields):
        import connected_workflow_page
        connected_workflow_page.open_route("variable_review", pack, actor_id,
            params={"phase": "science", "action": "review"})


def _retain_review_fields():
    # The callback runs before widgets render, so their values can be detached
    # safely before navigation removes those widgets from the next page.
    import scientific_definition_editor
    scientific_definition_editor.retain_fields()
    _retain_proposal_choices()


def _retain_proposal_choices():
    for key in list(st.session_state):
        if str(key).startswith(PREFIX + "select_"):
            st.session_state[key] = st.session_state[key]


def _navigation_only_chat(pack, actor_id):
    """Keep local review navigation usable while row drafting is unavailable."""
    import flow_assistant
    _retain_proposal_choices()
    history = st.session_state.setdefault(PREFIX + "messages", [])
    with st.container(height=320, border=False, autoscroll=True):
        if not history:
            st.info("You can still ask to review or finalize all variables here. The review page checks the current saved rows before any confirmation.")
        for turn in history[-HISTORY_MESSAGES:]:
            with st.chat_message(turn["role"]):
                st.write(turn["content"])
                _variable_review_action(turn, pack, actor_id)
        conversation = st.container()
    request = st.chat_input("Ask to review all variables", key=PREFIX + "chat", max_chars=1200)
    if not request:
        return
    try:
        assistant._ingress(request)
    except assistant.Invalid as error:
        st.error(str(error))
        return
    turn = (_variable_review_turn() if flow_assistant.variable_review_request(request) else
            {"role": "assistant", "content": "Row drafting is currently unavailable. Follow the message above to restore it, or ask to review all variables to open the saved scientific table and resolve its blockers."})
    history.extend([{"role": "user", "content": request}, turn])
    st.session_state[PREFIX + "messages"] = history[-HISTORY_MESSAGES:]
    with conversation:
        with st.chat_message("user"):
            st.write(request)
        with st.chat_message("assistant"):
            st.write(turn["content"])
            _variable_review_action(turn, pack, actor_id)


@assistant_layout.in_panel
def render(root, pack, actor_id, current, *, local_demo, can_write, allowed_packs, chat=False):
    """Return True only after explicitly selected fields reach a private draft.

    The caller supplies its unsaved working values together with the original
    source/draft digests, then reloads the saved values when this returns True.
    """
    selected = current.get("selected") or {}
    item_id = selected.get("item_id")
    context = (str(Path(root).resolve()), pack, actor_id, item_id,
               bool(local_demo), bool(can_write), tuple(sorted(allowed_packs or [])))
    if st.session_state.get(PREFIX + "context") != context:
        _clear_feedback()
        for key in list(st.session_state):
            if key.startswith(PREFIX):
                del st.session_state[key]
        st.session_state[PREFIX + "context"] = context

    if not chat:
        st.caption("Optional help with this row. Suggestions are drafts to review, not scientific decisions.")
    if not current.get("ok") or not item_id:
        _clear_feedback()
        st.info("Select a specification row before asking for suggestions.")
        return False
    if allowed_packs is not None and pack not in allowed_packs:
        st.info("You need access to this product to review its variables.")
        return False
    if chat:
        import flow_assistant
        if flow_assistant.variable_review_request(st.session_state.get(PREFIX + "chat")):
            # Navigation does not need a provider health check or a fresh row
            # proposal. The destination rechecks all saved rows before approval.
            _navigation_only_chat(pack, actor_id)
            return False
    availability = assistant.describe_availability(root, pack, actor_id, item_id, allowed_packs=allowed_packs)
    if not availability.get("ok"):
        _clear_feedback()
        _clear_proposal(clear_conversation=True)
        _errors(availability, "AI suggestions are unavailable for this row.")
        return False
    if not availability.get("configured"):
        if not chat:
            _clear_feedback()
            _clear_proposal(clear_conversation=True)
        st.info("Open Assistant connection in the sidebar and select your connection. "
                "It is shared by this row, question answers, the product guide and specialist requests. "
                "Return here and explicitly request help; your current entries are kept.")
        st.info(availability.get("help") or
                "See docs/PORTAL_ASSISTANT_SETUP.md for connection setup; "
                "do not paste a credential into this editor.")
        if availability.get("provider_id") == "anthropic":
            st.caption("Set ANTHROPIC_WORKSPACE_ID in the same local configuration when your credential requires a workspace header.")
        if chat:
            _navigation_only_chat(pack, actor_id)
        return False
    provider = availability.get("provider") or "the configured provider"
    model_info = availability.get("model_info") or {}
    model_name = model_info.get("name") or availability.get("model") or "selected model"
    st.caption(f"{provider} · {model_name}")
    if availability.get("quota_note") and not chat:
        st.caption(availability["quota_note"])
    if not availability.get("source_eligible"):
        if not chat:
            _clear_feedback()
            _clear_proposal(clear_conversation=True)
        st.info(availability.get("blocker") or "Complete the source review for this extraction before requesting suggestions.")
        if chat:
            _navigation_only_chat(pack, actor_id)
        return False

    permitted = bool(local_demo and can_write)
    if not permitted:
        _clear_feedback()
        _clear_proposal(clear_conversation=True)
        st.info("AI drafting requires permission to edit this product in the local draft workflow.")
        if chat:
            _navigation_only_chat(pack, actor_id)
            return False

    stale = any(availability.get(key) is not None and availability[key] != current.get(key)
                for key in ("input_digest", "draft_digest"))
    if stale:
        _clear_feedback()
        _clear_proposal(clear_conversation=True)
        st.warning("This row or its saved draft changed. Reload the current row while keeping your entries before asking for suggestions.")
        if chat:
            _navigation_only_chat(pack, actor_id)
            return False

    working_values = current.get("values") or {}
    feedback_context = _digest({"context": context, "input": current.get("input_digest"),
        "provider": availability.get("provider_id", provider), "model": availability.get("model"),
        "connection": availability.get("connection_id"), "skill": availability.get("workflow_skill_digest")})
    if st.session_state.get(PREFIX + "feedback_context") != feedback_context:
        _clear_feedback()
        st.session_state[PREFIX + "feedback_context"] = feedback_context
    binding = _digest({"context": context, "input": current.get("input_digest"),
                       "draft": current.get("draft_digest"), "values": working_values,
                       "provider": availability.get("provider_id", provider),
                       "model": availability.get("model"), "connection": availability.get("connection_id"),
                       "skill": availability.get("workflow_skill_digest")})
    if st.session_state.get(PREFIX + "binding") not in (None, binding):
        _clear_proposal(clear_conversation=True)
        st.info("Your answers, source or assistant connection changed. Generate fresh suggestions before selecting answers.")

    destination = ("the selected model through VS Code" if availability.get("provider_id") == "vscode"
                   else provider)
    if chat:
        import specialist_chat
        had_history = bool(st.session_state.get(PREFIX + "messages") or st.session_state.get(PREFIX + "response"))
        clear_control = st.empty()
        def clear_button():
            with clear_control.container():
                if st.button("Clear conversation", key=PREFIX + "clear_conversation", disabled=not permitted or stale):
                    _clear_feedback()
                    _clear_proposal(clear_conversation=True)
        if had_history:
            clear_button()
        history = st.session_state.setdefault(PREFIX + "messages", [])
        conversation = st.container(height=320, border=False, autoscroll=True)
        with conversation:
            if not history:
                with st.chat_message("assistant"):
                    st.write("Let's work through this row together. Tell me what the value should mean, ask me to explain the specification, or ask for proposed wording. We'll review the draft before saving it.")
            for index, turn in enumerate(history[-HISTORY_MESSAGES:]):
                with st.chat_message(turn["role"]):
                    st.write(turn["content"])
                    _variable_review_action(turn, pack, actor_id)
                    if turn.get("specialist"):
                        specialist_chat.render(root, pack, actor_id, turn, allowed_packs=allowed_packs,
                            provider=availability, local_demo=local_demo, can_agent=permitted, can_write=can_write,
                            key=PREFIX + "specialist_" + turn.get("id", str(index)))
        response = st.session_state.get(PREFIX + "response") or {}
        rendered_question_token = _digest(response)
        window = response.get("conversation_window") or {}
        if window.get("omitted_turns"):
            st.caption(f"This answer used {window.get('included_turns', 0)} conversation turns. Earlier turns were outside its context window; restate any details you still need.")
        tools_area = st.container()
        with tools_area:
            questions_area = st.empty()
            with questions_area.container():
                option_reply = _question_reply(response) if permitted and not stale else None
        typed_request = st.chat_input("Ask about this row or explain the rule you want", key=PREFIX + "chat", max_chars=1200,
                                      disabled=not permitted or stale)
        request = typed_request or option_reply
        generate = bool(request)
        if request:
            try:
                assistant._ingress(request)
            except assistant.Invalid as error:
                st.error(str(error))
                return False
            history.append({"role": "user", "content": request})
            st.session_state[PREFIX + "messages"] = history[-HISTORY_MESSAGES:]
            if not had_history:
                clear_button()
            st.session_state[PREFIX + "binding"] = binding
            with conversation, st.chat_message("user"):
                st.write(request)
            import flow_assistant
            specialist_plan = None
            if flow_assistant.variable_review_request(request):
                review_turn = _variable_review_turn()
                st.session_state[PREFIX + "messages"].append(review_turn)
                st.session_state[PREFIX + "messages"] = st.session_state[PREFIX + "messages"][-HISTORY_MESSAGES:]
                with conversation, st.chat_message("assistant"):
                    st.write(review_turn["content"])
                    _variable_review_action(review_turn, pack, actor_id)
                generate = False
            else:
                specialist_plan = specialist_chat.prepare(request, root=root, pack=pack, actor_id=actor_id,
                    allowed_packs=allowed_packs, provider=availability,
                    previous_turn=next((turn for turn in reversed(history[:-1]) if turn.get("role") == "assistant"), None))
            if specialist_plan and specialist_plan["explicit"]:
                specialist_turn = {"id": uuid.uuid4().hex, "role": "assistant",
                    "content": "I'll handle this specialist request here and keep its assessment and critique together for review.",
                    "specialist": specialist_plan}
                st.session_state[PREFIX + "messages"].append(specialist_turn)
                st.session_state[PREFIX + "messages"] = st.session_state[PREFIX + "messages"][-HISTORY_MESSAGES:]
                with conversation, st.chat_message("assistant"):
                    st.write(specialist_turn["content"])
                    specialist_chat.render(root, pack, actor_id, specialist_turn, allowed_packs=allowed_packs,
                        provider=availability, local_demo=local_demo, can_agent=permitted, can_write=can_write,
                        key=PREFIX + "specialist_" + specialist_turn["id"], submitted=True)
                generate = False
    else:
        st.caption(f"When you request suggestions, the selected specification row and your current answers are sent to {destination}. "
                   "Patient-data files and other definition rows are not sent.")
        request = st.text_area(
            "What would you like help with? (optional)", key=PREFIX + "request", max_chars=1200,
            help="Example: Explain the time window in this row, suggest missing-value handling, and flag choices the specification does not answer.",
            disabled=not permitted or stale,
        )
        generate = st.button("Suggest answers for this row", key=PREFIX + "generate", disabled=not permitted or stale)
    if generate:
        previous = st.session_state.get(PREFIX + "response") or st.session_state.get(PREFIX + "proposal")
        with st.spinner("Preparing suggestions from this specification row…"):
            result = assistant.suggest(
                root, pack, actor_id, item_id, working_values,
                expected_input_digest=current["input_digest"], expected_draft_digest=current["draft_digest"],
                user_request=request, local_demo=local_demo, can_write=can_write, allowed_packs=allowed_packs,
                **({"previous_proposal": previous, "conversation": True} if chat else {}),
            )
        if result.get("ok"):
            response_values = {item["field"]: item["value"] for item in result["proposal"].get("suggestions", [])}
            response_text = "\n\n".join(filter(None, [result["proposal"].get("answer", ""), _feedback_text(response_values)]))
            st.session_state[PREFIX + "feedback_response"] = {"id": uuid.uuid4().hex,
                "request": request or "Suggest wording for the selected scientific definition.", "answer": response_text}
            st.session_state[PREFIX + "response"] = result["proposal"]
            if result["proposal"].get("suggestions"):
                _clear_proposal()
                st.session_state[PREFIX + "proposal"] = result["proposal"]
                st.session_state[PREFIX + "response"] = result["proposal"]
                st.session_state[PREFIX + "feedback_proposal"] = dict(st.session_state[PREFIX + "feedback_response"])
            st.session_state[PREFIX + "binding"] = binding
            if chat:
                items = result["proposal"].get("suggestions", [])
                questions = [q for item in items for q in item.get("questions", [])]
                response = result["proposal"].get("answer")
                if not response:
                    response = "I've prepared proposed wording for " + ", ".join(LABELS.get(item["field"], item["field"]).lower() for item in items) + "."
                    response += "\n\n" + questions[0] if questions else " Review the proposed draft below, or tell me what to change."
                assistant_turn = {"role": "assistant", "content": response}
                if specialist_plan:
                    assistant_turn.update(id=uuid.uuid4().hex, specialist=specialist_plan)
                st.session_state[PREFIX + "messages"].append(assistant_turn)
                st.session_state[PREFIX + "messages"] = st.session_state[PREFIX + "messages"][-HISTORY_MESSAGES:]
                with conversation, st.chat_message("assistant"):
                    st.write(response)
                if _digest(result["proposal"]) != rendered_question_token:
                    questions_area.empty()
                    with questions_area.container():
                        _question_reply(result["proposal"])
        else:
            with tools_area if chat else nullcontext():
                _errors(result, "Suggestions could not be generated. Your entries have not been changed.")

    with tools_area if chat else nullcontext():
        if permitted and not stale:
            response = st.session_state.get(PREFIX + "response")
            if response:
                _scientific_context(response)
            _feedback(root, pack, actor_id, working_values, can_write=can_write, allowed_packs=allowed_packs)
        proposal = st.session_state.get(PREFIX + "proposal")
        if not proposal or not permitted or stale:
            return False
        if chat:
            with st.expander("Review the proposed draft", expanded=True):
                st.table([{"Part of the definition": LABELS.get(item["field"], item["field"]),
                           "Current wording": _text(working_values.get(item["field"])), "Proposed wording": _text(item["value"])}
                          for item in proposal["suggestions"]])
                with st.expander("Source quotations, assumptions and open questions"):
                    st.caption("A matching quotation shows where words came from. Check that it actually supports the proposed rule; it does not validate the scientific interpretation.")
                    sources = {source["id"]: source for source in proposal.get("sources", [])}
                    for item in proposal["suggestions"]:
                        st.write("**" + LABELS.get(item["field"], item["field"]) + "**")
                        if not item["support"]:
                            st.warning("No specification quotation supports this answer. Review its assumptions and questions before using it.")
                        for support in item["support"]:
                            st.text(support["source_id"] + ": " + support["quote"])
                            if sources.get(support["source_id"], {}).get("kind") == "current_draft":
                                st.caption("This quotation is from your unreviewed answer; it is not specification evidence.")
                        for text in [*item["assumptions"], *item["questions"]]:
                            st.write(text)
                fields = [item["field"] for item in proposal["suggestions"]]
                selected_fields = st.multiselect("Answers to use", fields, default=fields,
                    format_func=lambda field: LABELS.get(field, field), key=PREFIX + "select_chat",
                    help="Remove any proposed answer you want to keep as you wrote it. Only selected fields replace your unfinished draft.")
                st.caption("This replaces the selected fields in your unfinished draft. Unresolved choices stay open. The functional contract changes only after validation and a separate reviewed diff.")
                if st.button("Use this proposed draft", key=PREFIX + "accept_chat", type="primary", disabled=not selected_fields):
                    result = assistant.accept(root, pack, actor_id, item_id, working_values, proposal,
                        selected_fields, expected_input_digest=current["input_digest"],
                        expected_draft_digest=current["draft_digest"], local_demo=local_demo, can_write=can_write, allowed_packs=allowed_packs)
                    if result.get("ok"):
                        _accepted_feedback(result, proposal, selected_fields)
                        _clear_proposal(keep_rendered_widgets=True)
                        st.session_state[PREFIX + "messages"].append({"role": "assistant", "content": "Saved to your unfinished row draft. Tell me what to refine next, or review the details and validate the definition."})
                        return True
                    _errors(result, "The draft could not be saved. Reload the row before trying again.")
            return False
        st.info("Review the source, assumptions and questions for each answer. Nothing is selected automatically. "
                "You can refine accepted answers in the row editor.")
        sources = {source["id"]: source for source in proposal.get("sources", [])}
        selected_fields = []
        for suggestion in proposal.get("suggestions", []):
            field = suggestion["field"]
            label = LABELS.get(field, field)
            st.markdown(f"**{label}**")
            before, after = st.columns(2)
            with before:
                st.caption("Your current answer")
                st.text(_text(working_values.get(field)))
            with after:
                st.caption("Suggested answer")
                st.text(_text(suggestion["value"]))
            st.caption("Source references")
            support_items = suggestion.get("support", [])
            if not support_items:
                st.warning("No specification quotation supports this answer. Review its assumptions and questions before using it.")
            for support in support_items:
                source = sources.get(support["source_id"], {})
                st.text(f"{source.get('label', support['source_id'])} [{support['source_id']}]\n{support['quote']}")
                if source.get("kind") == "current_draft":
                    st.caption("This quotation is from your unreviewed answer; it is not specification evidence.")
            st.caption("Assumptions to check")
            for assumption in suggestion.get("assumptions") or ["No assumptions listed; verify the answer against the source."]:
                st.text(assumption)
            st.caption("Questions for scientific review")
            for question in suggestion.get("questions") or ["No questions listed; confirm whether additional review is needed."]:
                st.text(question)
            if st.checkbox("Use this answer: " + label, value=False, key=PREFIX + "select_" + field):
                selected_fields.append(field)

        st.caption("Selected answers replace only those fields in your unfinished private draft. "
                   "Your other current answers are preserved. This does not change the functional contract, approve a definition or release a product.")
        if st.button("Use selected suggestions in my unfinished draft", key=PREFIX + "accept", disabled=not selected_fields):
            result = assistant.accept(
                root, pack, actor_id, item_id, working_values, proposal, selected_fields,
                expected_input_digest=current["input_digest"], expected_draft_digest=current["draft_digest"],
                local_demo=local_demo, can_write=can_write, allowed_packs=allowed_packs,
            )
            if result.get("ok"):
                _accepted_feedback(result, proposal, selected_fields)
                _clear_proposal(keep_rendered_widgets=True)
                st.success("Selected answers saved to your unfinished private draft. Review and edit them in the row editor, then validate the completed definition.")
                return True
            _errors(result, "The draft could not be saved. Reload this row and review fresh suggestions.")
        return False
