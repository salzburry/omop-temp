"""Shared workflow capture/review over agent.learn; no model-weight training."""
from pathlib import Path

import workflow_skills

NOTICE = ("Record a reusable workflow correction or successful pattern, using sanitized examples. "
          "It is saved on this Git branch. After regression checks and your explicit review, it is "
          "loaded by the relevant assistants and added to their behaviour evaluation cases. "
          "Share it through your normal Git review and merge; other checkouts receive it when they pull. "
          "Chat transcripts, source data and patient records are not copied automatically.")


class Invalid(ValueError):
    pass


def _author(actor_id):
    if not isinstance(actor_id, str) or not actor_id.strip() or len(actor_id) > 200:
        raise Invalid("Choose your local workspace identity before recording a correction.")
    return actor_id.strip()


def _permission(actor_id, permission, confirmed):
    actor = _author(actor_id)
    if permission is not True or confirmed is not True:
        raise Invalid("Review the displayed correction and confirm this action with the required local permission.")
    return actor


def _guard(call):
    try:
        return call()
    except (ValueError, OSError, TypeError, KeyError) as error:
        if isinstance(error, ValueError):
            raise Invalid(str(error)) from None
        raise Invalid("The correction library could not be read or saved. Check its branch files and retry.") from None


def describe(root, actor_id, route=None):
    try:
        _author(actor_id)
        base = Path(root).resolve(strict=True)
        loop = workflow_skills.learning()
        skill = workflow_skills.binding_for(route)["name"] if route is not None else None
        records = loop.corrections(base)
        records = [row for row in records if not skill or row["skill"] == skill]
        code_digest = loop.software_digest(base) if any(r["status"] == "checked" for r in records) else None
        rows = []
        for row in reversed(records):
            if skill and row["skill"] != skill:
                continue
            current = row["skill_sha256"] == loop._skill_hash(base, row["skill"])
            scoped = (row.get("scope") or {}).get("kind") != "legacy_context"
            check = row.get("check") or {}
            rows.append({**row, "default_tests": list(loop.DEFAULT_TESTS[row["skill"]]),
                         "stale_skill": not current, "in_effect": current and scoped and row["status"] == "active",
                         "stale": not current or (row["status"] == "checked" and check.get("source_digest") != code_digest),
                         "can_activate": current and scoped and row["status"] == "checked" and check.get("passed") is True and check.get("source_digest") == code_digest})
        return {"ok": True, "errors": [], "skill": skill, "records": rows,
                "digest": loop.digest([r["digest"] for r in rows]), "notice": NOTICE}
    except (ValueError, OSError, TypeError, KeyError):
        return {"ok": False, "errors": ["The step or correction library is unavailable. Review the current skill and branch files."],
                "skill": None, "records": [], "digest": None, "notice": NOTICE}


def _scope(value, allowed_packs):
    if value is None or value == {"kind": "global"}:
        return {"kind": "global"}
    if not isinstance(value, dict) or set(value) != {"kind", "packs"} or value["kind"] != "packs":
        raise Invalid("Choose the current product or the shared workflow for this guidance.")
    packs = value["packs"]
    if (not isinstance(packs, list) or not packs or any(not isinstance(p, str) for p in packs)
            or len(packs) != len(set(packs)) or any(p not in (allowed_packs or []) for p in packs)):
        raise Invalid("Choose only products available in this workspace for this guidance.")
    return {"kind": "packs", "packs": sorted(packs)}


def propose(root, actor_id, route, wrong, right, context, eval_goal, *, confirmed=False, can_write=False,
            scope=None, allowed_packs=None, provenance=None):
    actor = _permission(actor_id, can_write, confirmed)
    import scientific_definition_ai as ai
    name = workflow_skills.binding_for(route)["name"]
    scope = _scope(scope, allowed_packs)
    return _guard(lambda: workflow_skills.learning().propose_correction(root, name, wrong, right, context, actor, eval_goal,
                                                                      check_text=ai._ingress, scope=scope, provenance=provenance))


FEEDBACK_REASONS = {
    "wrong_interpretation": "Wrong interpretation",
    "missing_source": "Missing source",
    "unclear_explanation": "Unclear explanation",
    "other": "Something else — describe it",
}
_FEEDBACK_GUIDANCE = {
    "wrong_interpretation": "Check the interpretation against the supplied requirement. Keep unresolved scientific choices open and ask for clarification.",
    "missing_source": "Identify the source that supports the answer. If support is missing, say what evidence is needed and keep the proposed interpretation unresolved.",
    "unclear_explanation": "Explain the answer in plain language, with an illustrative example and a clear next step. Distinguish the example from evidence for this product.",
    "other": "Address the reviewer findings below while preserving unresolved scientific questions.",
}


def _excerpt(text, limit):
    marker = "\n[Excerpt — review the original answer]"
    return text if len(text) <= limit else text[:limit - len(marker)] + marker


def prepare_interaction(root, actor_id, route, *, pack, interaction_id, request, answer,
                        category, notes="", revised_answer=None, outcome=None,
                        can_write=False, allowed_packs=None):
    """Prepare inspectable form values only; no correction, model call or transcript export."""
    actor = _permission(actor_id, can_write, True)
    base = Path(root).resolve(strict=True)
    loop = workflow_skills.learning()
    skill = workflow_skills.binding_for(route)["name"]
    if category not in FEEDBACK_REASONS or outcome not in {None, "edited", "rejected", "reported"}:
        raise Invalid("Choose the reason for this feedback and its actual interaction.")
    pack = pack or None
    scope = _scope({"kind": "packs", "packs": [pack]} if pack else None, allowed_packs)
    loop._scope_value(scope)
    values = {"interaction_id": interaction_id, "request": request, "answer": answer,
              "notes": notes, "revised_answer": revised_answer or ""}
    for key, value in values.items():
        limit = 32000 if key in {"answer", "revised_answer"} else 4000 if key == "request" else 1800
        if not isinstance(value, str) or len(value) > limit or any(ord(c) < 32 and c not in "\r\n\t" for c in value):
            raise Invalid("Keep feedback to the selected answer and a concise explanation.")
    if not interaction_id.strip() or not answer.strip() or (category == "other" and not notes.strip()):
        raise Invalid("Include the selected answer and describe what needs to change.")
    import scientific_definition_ai as ai
    # Inspect complete input before excerpting: a secret past the displayed
    # excerpt must never enter prepared or saved feedback.
    ai._ingress(ai._plain(values))
    state = outcome or "reported"
    observation = loop.digest({"skill": skill, "pack": pack, "actor": actor,
        "interaction_id": interaction_id, "request": request, "answer": answer,
        "revised_answer": revised_answer or "", "outcome": state})
    wrong = FEEDBACK_REASONS[category] + " · " + state + " assistant answer:\n" + _excerpt(answer.strip(), 1400)
    right = ("Proposed revision to review; unresolved choices still need scientific review:\n" +
             _excerpt(revised_answer.strip(), 1100)) if revised_answer and revised_answer.strip() else _FEEDBACK_GUIDANCE[category]
    if notes.strip():
        right += "\nReviewer findings: " + _excerpt(notes.strip(), 450)
    goal = request.strip() or "Explain the selected answer and the next step using the available evidence."
    context = "Feedback on " + skill + (" for " + pack if pack else " in product setup") + ".\n" + _excerpt(goal, 1200)
    result = {"root": str(base), "actor_id": actor, "pack": pack, "skill": skill,
        "skill_sha256": loop._skill_hash(base, skill), "scope": scope,
        "fields": {"wrong": wrong, "right": right, "applies": context, "goal": _excerpt(goal, 1800)},
        "provenance": {"entrypoint": "interaction_feedback", "observation_id": observation,
                       "category": category, "outcome": state}}
    result["digest"] = loop.digest(result)
    return result


def validate_prepared(root, actor_id, prepared, *, pack, allowed_packs=None):
    """Bind the prepared form to its original identity, product and skill source."""
    try:
        loop = workflow_skills.learning()
        if (not isinstance(prepared, dict) or prepared.get("digest") != loop.digest({k: v for k, v in prepared.items() if k != "digest"})
                or prepared.get("root") != str(Path(root).resolve(strict=True))
                or prepared.get("actor_id") != _author(actor_id) or prepared.get("pack") != (pack or None)
                or prepared["skill_sha256"] != loop._skill_hash(root, prepared["skill"])
                or set(prepared["fields"]) != {"wrong", "right", "applies", "goal"}
                or any(not isinstance(v, str) or len(v) > 1800 for v in prepared["fields"].values())):
            raise Invalid("This feedback draft belongs to an earlier interaction or changed workflow. Prepare it again from the current answer.")
        _scope(prepared["scope"], allowed_packs)
        return prepared
    except (ValueError, KeyError, TypeError, OSError) as error:
        if isinstance(error, Invalid):
            raise
        raise Invalid("This feedback draft is unavailable for the current interaction. Prepare it again from the answer.") from None


def check(root, actor_id, record_id, selectors, *, expected_digest, confirmed=False, can_review=False):
    _permission(actor_id, can_review, confirmed)
    import portal_runtime
    options = {"runner": portal_runtime.run} if portal_runtime.has_job_callbacks() else {}
    return _guard(lambda: workflow_skills.learning().check_correction(root, record_id, expected_digest, selectors, **options))


def activate(root, actor_id, record_id, *, expected_digest, confirmed=False, can_review=False):
    actor = _permission(actor_id, can_review, confirmed)
    import scientific_definition_ai as ai
    # Re-read and re-classify before a saved correction can reach future prompts.
    value = _guard(lambda: workflow_skills.learning().read_correction(root, record_id))
    ai._ingress(ai._plain(value))
    return _guard(lambda: workflow_skills.learning().activate_correction(root, record_id, expected_digest, actor))


def withdraw(root, actor_id, record_id, *, expected_digest, confirmed=False, can_review=False):
    actor = _permission(actor_id, can_review, confirmed)
    return _guard(lambda: workflow_skills.learning().withdraw_correction(root, record_id, expected_digest, actor))


def legacy_preview(root, actor_id, *, skill_by_id=None, scope_by_id=None, allowed_packs=None):
    _author(actor_id)
    scopes = {key: _scope(value, allowed_packs) for key, value in (scope_by_id or {}).items()}
    return _guard(lambda: workflow_skills.learning().preview_legacy(root, skill_by_id=skill_by_id, scope_by_id=scopes))


def import_legacy(root, actor_id, *, expected_digest, skill_by_id=None, scope_by_id=None,
                  allowed_packs=None, confirmed=False, can_review=False):
    actor = _permission(actor_id, can_review, confirmed)
    scopes = {key: _scope(value, allowed_packs) for key, value in (scope_by_id or {}).items()}
    return _guard(lambda: workflow_skills.learning().import_legacy(root, expected_digest=expected_digest,
        by=actor, skill_by_id=skill_by_id, scope_by_id=scopes))


def resolve_legacy_scope(root, actor_id, record_id, scope, *, expected_digest, allowed_packs=None,
                          confirmed=False, can_review=False):
    actor = _permission(actor_id, can_review, confirmed)
    selected = _scope(scope, allowed_packs)
    return _guard(lambda: workflow_skills.learning().resolve_legacy_scope(root, record_id, expected_digest, selected, actor))
