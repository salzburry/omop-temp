"""Guided claims bindings, checked draft review and an owned runtime continuation."""
from pathlib import Path
import json

import streamlit as st
import yaml
import claims_workspace as backend
import form_assistance as form_help

PREFIX = "claims_ws_"


def _failed(result):
    for error in result.get("errors", []):
        st.error(error)
    return not result.get("ok")


def _report(report):
    st.markdown("**Rules lifted from the registered workbook**")
    st.dataframe([{"Source row": key, "Stated value": str(value)} for key, value in report["study_specs"].items()],
                 hide_index=True, width="stretch")
    st.dataframe([{"Source row": row["row"], "Rule": row["definition"], "Trace call": (row["call"] or {}).get("fn"),
                   "Remaining gap": row["gap"] or ""} for row in report["criteria"]], hide_index=True, width="stretch")
    if report["gaps"]:
        st.warning(f"{len(report['gaps'])} blocking gap(s) remain. A saved draft with these gaps cannot execute.")
        for gap in report["gaps"]:
            st.write("• " + gap)
    else:
        st.success("The canonical exporter found no blocking extraction or binding gaps. Scientific review and runtime checks remain required.")
    with st.expander("Exact generated R and integrity-sealed manifest"):
        st.code(report["script"], language="r")
        st.download_button("Download this exact R draft", report["script"], "claims-draft.R", key=PREFIX + "download_r")
        st.code(report["manifest"], language="yaml")
        st.download_button("Download this exact manifest", report["manifest"], "claims-manifest.yaml", key=PREFIX + "download_manifest")
        st.caption("Workbook SHA256: " + report["workbook_sha256"])
        st.caption("Manifest content SHA256: " + report["manifest_sha256"])


def render(root, pack, actor_id, *, allowed_packs, local_demo=False, can_write=False,
           can_review=False, route="claims_workspace", params=None):
    params = params or {}
    context = (str(Path(root).resolve()), pack, actor_id, tuple(sorted(allowed_packs)), params.get("proposal_id"), params.get("handoff_id"))
    if st.session_state.get(PREFIX + "context") != context:
        for key in list(st.session_state):
            if str(key).startswith(PREFIX):
                del st.session_state[key]
        st.session_state[PREFIX + "context"] = context
    st.write("Connect each claims code list to a named event, then connect the workbook's criteria to those events. Dates, counts, windows and clinical rules come from the workbook.")
    st.caption(backend.NOTICE)
    if PREFIX + "report" not in st.session_state or st.button("Reload registered claims specification", key=PREFIX + "reload"):
        with st.spinner("Checking the registered workbook and current bindings…"):
            st.session_state[PREFIX + "report"] = backend.describe(root, pack, actor_id, allowed_packs=allowed_packs)
        st.session_state.pop(PREFIX + "proposal", None)
    current = st.session_state[PREFIX + "report"]
    if _failed(current):
        if st.button("Open specification registration", key=PREFIX + "source"):
            return {"route": "progress", "params": {"action_id": "g1_register"}}
        return None
    if params.get("proposal_id") and PREFIX + "proposal" not in st.session_state:
        result = backend.read(root, pack, actor_id, proposal_id=params["proposal_id"], allowed_packs=allowed_packs)
        if not _failed(result):
            st.session_state[PREFIX + "proposal"] = result["proposal"]
    st.caption("Registered workbook: " + current["source"])
    if params.get("handoff_id"):
        review = backend.review_status(root, pack, actor_id, handoff_id=params["handoff_id"], allowed_packs=allowed_packs)
        if not _failed(review):
            st.write("**Requested runtime review**")
            st.text(review["handoff"]["note"])
            if review["stale"]:
                st.warning("The current export differs from the requested review. Ask the drafter to validate and request review of the current inputs before using this result.")
            else:
                st.info("This regenerated workbook, bindings and manifest match the requested hashes. This checks integrity, not scientific approval or an executed result.")
    for error in current.get("binding_errors", []):
        st.warning("The saved bindings failed validation: " + error)
        st.caption("Use the form below to repair them. The review diff keeps their current exact text.")
    st.markdown("**1 · Name the events and choose their code lists**")
    st.dataframe([{"Code-list tab": name, **details} for name, details in current["code_lists"].items()], hide_index=True, width="stretch")
    st.caption("An event name is a short R identifier such as diagnosis_event. Choosing a tab declares which codes that event uses; it does not change the code list.")
    proposal = st.session_state.get(PREFIX + "proposal")
    saved = proposal["payload"]["values"] if proposal else None
    if saved is None:
        original = {} if current.get("binding_errors") else yaml.safe_load(current["current_bindings"]) or {}
        saved = {"events": [{"name": name, **mapping} for name, mapping in (original.get("events") or {}).items()],
                 "criteria": original.get("criteria") or {}, "ignore_tabs": original.get("ignore_tabs") or []}
    draft_binding = (pack, current["input_digest"], proposal.get("id") if proposal else None)
    count = form_help.field(st.number_input, "Number of events to bind", min_value=1, max_value=30, value=max(1, len(saved["events"])), binding=draft_binding,
                            key=PREFIX + "count", help="This controls the number of form rows, not a scientific event-count threshold.")
    events, names = [], []
    for index in range(count):
        previous = saved["events"][index] if index < len(saved["events"]) else {}
        with st.container(border=True):
            name = form_help.field(st.text_input, f"Event {index + 1} name", value=previous.get("name", ""), key=PREFIX + f"event_{index}", binding=draft_binding)
            row = {"name": name}
            for arg in backend.ARGS:
                tabs = list(current["code_lists"])
                existing = previous.get(arg)
                selected = form_help.field(st.selectbox, {"dx_cd": "Diagnosis codes", "ndc_cd": "Drug codes", "cpt_hcpcs_cd": "CPT / HCPCS codes", "px_cd": "Procedure codes"}[arg],
                    tabs, index=tabs.index(existing) if existing in tabs else None, key=PREFIX + f"event_{index}_{arg}", binding=(*draft_binding, index),
                    placeholder="Choose a code-list tab, if this event uses it", help="The canonical validator checks each code system against this argument.")
                if selected:
                    row[arg] = selected
            events.append(row)
            if name.strip():
                names.append(name.strip())
    st.markdown("**2 · Connect the criteria to events**")
    st.caption("The full sheet and row name identifies the criterion. Its threshold, window and inclusion or exclusion meaning stay exactly as the workbook states.")
    criteria = {}
    for index, key in enumerate(current["event_criteria"]):
        unique_names = list(dict.fromkeys(names))
        existing = saved["criteria"].get(key, saved["criteria"].get(key.split(":", 1)[-1]))
        selected = form_help.field(st.selectbox, key, unique_names, index=unique_names.index(existing) if existing in unique_names else None, binding=draft_binding,
            key=PREFIX + f"criterion_{index}", placeholder="Choose the event this criterion counts")
        if selected:
            criteria[key] = selected
    ignored = st.multiselect("Tabs reviewed as containing no cohort rules", list(current["unread_tabs"]),
        default=[name for name in saved["ignore_tabs"] if name in current["unread_tabs"]], key=PREFIX + "ignored",
        help="Choose a tab only after reviewing its contents. This cannot ignore a code list or a scientific criterion.")
    values = {"events": events, "criteria": criteria, "ignore_tabs": ignored}
    if st.button("Validate and stage claims bindings", key=PREFIX + "stage", disabled=not (local_demo and can_write)):
        result = backend.stage(root, pack, actor_id, values=values, expected_digest=current["input_digest"],
                               allowed_packs=allowed_packs, local_demo=local_demo, can_write=can_write)
        if not _failed(result):
            st.session_state[PREFIX + "proposal"] = result["proposal"]
            proposal = result["proposal"]
    st.markdown("**3 · Review the exact draft and remaining gaps**")
    if not proposal:
        _report(current)
        if st.button("Continue scientific review", key=PREFIX + "science"):
            return {"route": "progress", "params": {"action_id": "g2_approve"}}
        return None
    payload = proposal["payload"]
    st.code(payload["diff"] or "No changes to the current bindings.", language="diff")
    _report(payload["report"])
    same_form = json.dumps(values, sort_keys=True) == json.dumps(payload["values"], sort_keys=True)
    if not same_form:
        st.warning("The form changed after validation. Stage the current answers before saving or requesting review.")
    if not proposal["state"].startswith("bindings saved"):
        confirm = st.checkbox("I reviewed the exact bindings, generated rules and remaining gaps. Save these bindings as a draft.", key=PREFIX + "confirm")
        if st.button("Save checked bindings to this product", key=PREFIX + "save", disabled=not (confirm and same_form and local_demo and can_write)):
            result = backend.save_bindings(root, pack, actor_id, proposal_id=proposal["id"], expected_digest=proposal["inputs_sha256"],
                confirmed=confirm, allowed_packs=allowed_packs, local_demo=local_demo, can_write=can_write)
            if not _failed(result):
                st.session_state[PREFIX + "proposal"] = result["proposal"]
                st.session_state[PREFIX + "report"] = backend.describe(root, pack, actor_id, allowed_packs=allowed_packs)
                st.success("The checked bindings are saved in this product's working branch. Scientific review remains open.")
                return {"route": route, "params": {"proposal_id": proposal["id"]}, "changed": True}
    else:
        st.success("Bindings saved in config/cohortly_bindings.yaml. Continue with scientific and runtime review.")
        st.markdown("**4 · Continue review and track the execution prerequisite**")
        note = form_help.field(st.text_area, "What should Engineering review or resolve?", key=PREFIX + "note", binding=draft_binding,
                            placeholder="For example: confirm the installed cohortly interface and the declared claims cut before draft UAT.")
        if st.button("Request claims runtime review", key=PREFIX + "request", disabled=not (same_form and note.strip() and local_demo and can_write)):
            result = backend.request_review(root, pack, actor_id, proposal_id=proposal["id"], note=note,
                allowed_packs=allowed_packs, local_demo=local_demo, can_write=can_write)
            if not _failed(result):
                return {"route": "handoffs", "params": {"handoff_id": result["handoff"]["id"]}}
        st.caption("The request states the exact input hashes and required execution evidence. Completing a handoff cannot authenticate a run or pass a claims release gate.")
    if st.button("Continue scientific review", key=PREFIX + "science"):
        return {"route": "progress", "params": {"action_id": "g2_approve"}}
    return None
