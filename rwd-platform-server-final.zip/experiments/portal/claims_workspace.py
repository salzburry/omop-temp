"""Registered claims specifications -> checked bindings -> exact cohortly review.

The canonical exporter owns extraction and every runnable gap. This workspace
records draft bindings, never a clinical ruling, executor attestation or release.
"""
from __future__ import annotations

import copy
import contextlib
import difflib
import io
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import tempfile
import uuid
import zipfile
from datetime import datetime, timezone

import yaml
CODE_ROOT = Path(__file__).resolve().parents[2]
sys.path[:0] = [str(CODE_ROOT / "platform/tools"), str(CODE_ROOT / "platform")]
import specification_details as details
import source_workspace as storage
import source_manifest as sources
import product_gates as gates
import handoffs

BINDINGS = "config/cohortly_bindings.yaml"
ROUTE = "claims_workspace"
NOTICE = ("Draft claims work. Saving bindings does not approve the scientific rules or execute a cohort. "
          "The existing cohortly runtime permits draft UAT only; governed claims execution and release are not implemented.")
ARGS = ("dx_cd", "ndc_cd", "cpt_hcpcs_cd", "px_cd")
SAVED_STATE = "bindings saved; scientific and runtime review pending"


def _guard(fn):
    def call(*args, **kwargs):
        try:
            return fn(*args, **kwargs)
        except (ValueError, OSError, TypeError, KeyError, details._Invalid, handoffs.Refused,
                subprocess.TimeoutExpired, yaml.YAMLError) as error:
            return {"ok": False, "changed": False, "errors": [str(error)], "notice": NOTICE}
    return call


def _scope(root, pack, actor_id, allowed_packs):
    scoped = storage._scope(root, pack, actor_id, allowed_packs)
    entry = gates.registry_entry(str(scoped[0]), scoped[2])
    modality, error = gates.pack_modality(entry)
    if entry is None or error or modality != "claims":
        raise ValueError("This workspace requires a registered claims product. EHR products continue through their scientific definition and ADS workflow.")
    return (*scoped[:4], storage._safe(scoped[4] / "claims"))


def _source(scope):
    root, product, pack, *_ = scope
    _path, _pack, raw, _text, doc, index, _node = details._load(root, pack, [pack])
    material = doc["source_materials"][index]
    source = storage._safe(Path(sources.material_file(str(product), material.get("path_or_link"), str(root))))
    if not source.is_relative_to(product) or source.suffix.lower() != ".xlsx":
        raise ValueError("Register the claims specification as an .xlsx file inside this product's prog_spec folder. External and cross-product workbooks must be imported through source registration first.")
    data = storage._bytes(source)
    if storage._sha(data) != str(material.get("sha256") or ""):
        raise ValueError("The registered workbook digest is missing or changed. Record the current specification digest in stage 1 before exporting claims rules.")
    try:
        with zipfile.ZipFile(io.BytesIO(data)) as archive:
            if sum(item.file_size for item in archive.infolist()) > 32 * 1024 * 1024:
                raise ValueError("The workbook expands beyond the claims review limit. Ask Engineering to review this workbook.")
    except zipfile.BadZipFile:
        raise ValueError("The registered source is not a readable .xlsx workbook.") from None
    return source, data, raw


def _input_files(scope):
    source, data, registration = _source(scope)
    files = storage._inputs(scope[0], scope[1])
    files[source.relative_to(scope[0]).as_posix()] = storage._sha(data)
    for name in ("platform/tools/cohortly_export.py", "platform/engine-r/cohortly_manifest.R"):
        files[name] = storage._sha((CODE_ROOT / name).read_bytes())
    return files, source, data


def _inputs(scope):
    files, source, data = _input_files(scope)
    return storage._sha(files), source, data


def _values(values):
    if not isinstance(values, dict) or set(values) != {"events", "criteria", "ignore_tabs"}:
        raise ValueError("Supply event bindings, criterion bindings and reviewed non-cohort tabs only.")
    if not isinstance(values["events"], list) or len(values["events"]) > 30:
        raise ValueError("Use at most 30 named events in one bindings proposal.")
    events = {}
    for event in values["events"]:
        if not isinstance(event, dict) or set(event) - {"name", *ARGS}:
            raise ValueError("An event has an unsupported field.")
        name = str(event.get("name") or "").strip()
        if not name or name in events:
            raise ValueError("Each event needs a distinct name; duplicate events cannot overwrite an earlier binding.")
        events[name] = {key: value for key, value in event.items() if key in ARGS and value}
    if not isinstance(values["criteria"], dict) or not isinstance(values["ignore_tabs"], list):
        raise ValueError("Choose an event for each criterion and a list of reviewed non-cohort tabs.")
    doc = {"events": events, "criteria": values["criteria"], "ignore_tabs": values["ignore_tabs"]}
    if len(json.dumps(doc)) > 50000:
        raise ValueError("The bindings proposal is too large.")
    return yaml.safe_dump(doc, sort_keys=False, allow_unicode=True)


def _export(source, data, bindings=None):
    with tempfile.TemporaryDirectory(prefix="claims-export-") as directory:
        book = Path(directory) / source.name
        book.write_bytes(data)
        request = {"workbook": str(book), "bindings": bindings}
        result = subprocess.run([sys.executable, str(Path(__file__).resolve()), "--worker"],
            input=json.dumps(request), capture_output=True, text=True, encoding="utf-8", errors="replace",
            cwd=directory, timeout=45, env={**os.environ, "PYTHONDONTWRITEBYTECODE": "1", "PYTHONUTF8": "1"})
        if result.returncode or len(result.stdout) > 4 * 1024 * 1024:
            raise ValueError("The canonical claims exporter could not complete. Ask Engineering to check the registered workbook; no output was accepted.")
        report = json.loads(result.stdout)
        if not report.get("ok"):
            raise ValueError(str(report.get("error") or "The canonical claims exporter refused this input.").replace(directory, "<claims review>"))
        return report


def _baseline(scope):
    path = storage._safe(scope[1] / BINDINGS)
    return storage._bytes(path).decode("utf-8") if path.exists() else ""


@_guard
def describe(root, pack, actor_id, *, allowed_packs=None):
    scope = _scope(root, pack, actor_id, allowed_packs)
    digest, source, data = _inputs(scope)
    raw = _baseline(scope)
    binding_errors = []
    try:
        report = _export(source, data, raw or None)
    except ValueError as error:
        if not raw:
            raise
        # An invalid old bindings file is an editable draft, not a reason to
        # lose the source form. Re-read without it, retaining the exact old
        # bytes for review and making its failed check visible.
        report = _export(source, data)
        binding_errors = [str(error)]
    if _inputs(scope)[0] != digest:
        raise ValueError("Claims inputs changed while loading. Reload before editing bindings.")
    return {"ok": True, "errors": [], "pack": pack, "input_digest": digest, "source": source.relative_to(scope[0]).as_posix(),
            "current_bindings": raw, "binding_errors": binding_errors, "notice": NOTICE, **report}


@_guard
def stage(root, pack, actor_id, *, values, expected_digest, allowed_packs=None, local_demo=False, can_write=False):
    storage._authorized(local_demo, can_write)
    scope = _scope(root, pack, actor_id, allowed_packs)
    digest, source, data = _inputs(scope)
    if digest != expected_digest:
        raise ValueError("Claims inputs changed. Reload the workbook and bindings before staging.")
    raw = _values(values)
    before = _baseline(scope)
    result = _export(source, data, raw)
    if _inputs(scope)[0] != digest:
        raise ValueError("Claims inputs changed during canonical validation. Stage the current inputs again.")
    record = {"id": uuid.uuid4().hex, "root": str(scope[0]), "pack": pack, "owner": scope[3],
        "route": ROUTE, "title": "Claims bindings and cohort definition", "state": "checked draft",
        "updated_at": datetime.now(timezone.utc).isoformat(), "inputs_sha256": digest,
        "payload": {"values": copy.deepcopy(values), "before": before, "bindings": raw, "report": result,
            "diff": "".join(difflib.unified_diff(before.splitlines(True), raw.splitlines(True),
                fromfile=BINDINGS + " (current)", tofile=BINDINGS + " (proposed)"))}, "notice": NOTICE}
    storage._write(scope[4], record)
    return {"ok": True, "errors": [], "proposal": record, "notice": NOTICE}


def _load(scope, proposal_id, expected_digest=None, *, verify=True):
    record = storage._load(scope, proposal_id, allowed_routes={ROUTE})
    if record.get("route") != ROUTE:
        raise ValueError("Choose a claims proposal from this product.")
    digest = _inputs(scope)[0]
    if record["inputs_sha256"] != digest or expected_digest is not None and digest != expected_digest:
        raise ValueError("The workbook, bindings or review context changed. Reload and stage a fresh proposal.")
    if record.get("state") not in {"checked draft", SAVED_STATE}:
        raise ValueError("This claims proposal has an unknown review state.")
    payload = record["payload"]
    if _values(payload["values"]) != payload["bindings"]:
        raise ValueError("The saved claims proposal's answers no longer match its bindings.")
    current = _baseline(scope)
    if current != (payload["bindings"] if record["state"] == SAVED_STATE else payload["before"]):
        raise ValueError("The saved claims state does not match this product's current bindings.")
    if verify:
        _digest, source, data = _inputs(scope)
        if _export(source, data, payload["bindings"]) != payload["report"] or _inputs(scope)[0] != digest:
            raise ValueError("The saved claims report no longer matches a fresh canonical export. Stage it again.")
    return record


@_guard
def read(root, pack, actor_id, *, proposal_id, allowed_packs=None):
    scope = _scope(root, pack, actor_id, allowed_packs)
    return {"ok": True, "errors": [], "proposal": _load(scope, proposal_id), "notice": NOTICE}


@_guard
def save_bindings(root, pack, actor_id, *, proposal_id, expected_digest, confirmed,
                  allowed_packs=None, local_demo=False, can_write=False):
    storage._authorized(local_demo, can_write)
    if confirmed is not True:
        raise ValueError("Review the exact bindings and remaining gaps before saving this draft.")
    scope = _scope(root, pack, actor_id, allowed_packs)
    with _product_lock(scope):
        return _save_bindings(scope, proposal_id, expected_digest)


@contextlib.contextmanager
def _product_lock(scope):
    # source_workspace owns <base>/<root>/<actor>/<product>/claims. Locks are
    # beside all actor folders so two users cannot overwrite one product.
    folder = storage._safe(scope[4].parents[2] / "claims-locks")
    folder.mkdir(parents=True, exist_ok=True)
    path = storage._safe(folder / (storage._sha(scope[2])[:24] + ".lock"))
    with path.open("a+b") as handle:
        if path.stat().st_size == 0:
            handle.write(b"0")
            handle.flush()
        handle.seek(0)
        try:
            if os.name == "nt":
                import msvcrt
                msvcrt.locking(handle.fileno(), msvcrt.LK_NBLCK, 1)
            else:
                import fcntl
                fcntl.flock(handle.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
        except OSError:
            raise ValueError("Another claims save is in progress for this product. Reload after it finishes.") from None
        try:
            yield
        finally:
            handle.seek(0)
            if os.name == "nt":
                msvcrt.locking(handle.fileno(), msvcrt.LK_UNLCK, 1)
            else:
                fcntl.flock(handle.fileno(), fcntl.LOCK_UN)


def _save_bindings(scope, proposal_id, expected_digest):
    pack = scope[2]
    record = _load(scope, proposal_id, expected_digest, verify=False)
    digest, source, data = _inputs(scope)
    payload = record["payload"]
    if _values(payload["values"]) != payload["bindings"] or _baseline(scope) != payload["before"]:
        raise ValueError("The saved proposal no longer matches its exact checked inputs. Stage it again.")
    fresh = _export(source, data, payload["bindings"])
    if fresh != payload["report"] or _inputs(scope)[0] != digest:
        raise ValueError("The claims export changed since review. Stage it again before saving.")
    path = storage._safe(scope[1] / BINDINGS)
    before = storage._bytes(path) if path.exists() else None
    raw = payload["bindings"].encode()
    expected_files = _input_files(scope)[0]
    if storage._sha(expected_files) != digest:
        raise ValueError("Claims inputs changed before saving. Stage the current inputs again.")
    before_files = dict(expected_files)
    expected_files[pack + "/" + BINDINGS] = storage._sha(raw)
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = None
    published = False
    try:
        with tempfile.NamedTemporaryFile(dir=path.parent, delete=False) as handle:
            temporary = Path(handle.name)
            handle.write(raw)
        if _input_files(scope)[0] != before_files or (storage._bytes(path) if path.exists() else None) != before:
            raise ValueError("The claims bindings or source changed before publication. Their current bytes were preserved; reload before saving.")
        os.replace(temporary, path)
        published = True
        actual_files = _input_files(scope)[0]
        if actual_files != expected_files:
            raise ValueError("Another claims input changed during the save. The draft bindings were rolled back; reload the current inputs.")
        record["state"] = SAVED_STATE
        record["payload"]["before"] = payload["bindings"]
        record["inputs_sha256"] = storage._sha(expected_files)
        record["updated_at"] = datetime.now(timezone.utc).isoformat()
        storage._write(scope[4], record)
    except BaseException:
        if published and path.is_file() and path.read_bytes() == raw:
            if before is None:
                path.unlink()
            else:
                path.write_bytes(before)
        raise
    finally:
        if temporary is not None and temporary.exists():
            temporary.unlink()
    return {"ok": True, "errors": [], "changed": True, "proposal": record, "path": pack + "/" + BINDINGS, "notice": NOTICE}


@_guard
def request_review(root, pack, actor_id, *, proposal_id, note, allowed_packs=None, local_demo=False, can_write=False):
    storage._authorized(local_demo, can_write)
    scope = _scope(root, pack, actor_id, allowed_packs)
    record = _load(scope, proposal_id)
    if record["state"] != SAVED_STATE:
        raise ValueError("Save the checked bindings in the product before requesting runtime review.")
    report = record["payload"]["report"]
    note = handoffs._text(note, "what Engineering should review")
    if len(note) > 1000:
        raise ValueError("Keep the runtime review request under 1000 characters; the exact export supplies the technical evidence.")
    body = (note + "\n\nChecked bindings: " + pack + "/" + BINDINGS +
        "\nWorkbook SHA256: " + report["workbook_sha256"] + "\nBindings SHA256: " + report["bindings_sha256"] +
        "\nManifest content SHA256: " + report["manifest_sha256"] +
        "\nRegenerate with platform/tools/cohortly_export.py using the registered workbook and saved bindings; outputs must stay outside the checkout."
        "\nReview cohortly version, db, data_refresh, source table and each trace call before any draft UAT."
        "\nExecution evidence needed: exact workbook/bindings/manifest hashes, installed cohortly version, declared source cut, ordered attrition and membership comparison in the restricted data environment."
        "\nThe current runtime has no governed claims receipt or release validator. A reported run is not authenticated by this request."
        + (f"\nBlocking gaps: {len(report['gaps'])}. Open this product's Claims cohort workflow for every gap in the exact export."
           if report["gaps"] else "\nExporter reports no blocking extraction gaps. Scientific and runtime review remain required."))
    body = handoffs._text(body, "the claims review context")
    action_id = "claims-review:" + record["id"] + ":" + storage._sha(body)
    existing = next((row for row in handoffs.listing(root, pack, allowed_packs=allowed_packs, include_closed=False)
                     if row.get("action_id") == action_id), None)
    doc = existing or handoffs.create(root, pack, title="Review claims bindings and runtime readiness", owner="Engineering",
        note=body, requested_by=actor_id, action_id=action_id, allowed_packs=allowed_packs, local_demo=local_demo, can_view=can_write)
    return {"ok": True, "errors": [], "handoff": doc, "notice": NOTICE}


@_guard
def review_status(root, pack, actor_id, *, handoff_id, allowed_packs=None):
    _scope(root, pack, actor_id, allowed_packs)
    document = handoffs.load(root, pack, handoff_id, allowed_packs=allowed_packs)
    action = document.get("action_id") or ""
    if not re.fullmatch(r"claims-review:[a-f0-9]{32}:[a-f0-9]{64}", action) or action.rsplit(":", 1)[-1] != storage._sha(document["note"]):
        raise ValueError("This request does not identify an intact claims review context.")
    report = describe(root, pack, actor_id, allowed_packs=allowed_packs)
    if not report["ok"]:
        return report
    markers = {"Workbook SHA256": "workbook_sha256", "Bindings SHA256": "bindings_sha256",
               "Manifest content SHA256": "manifest_sha256"}
    expected = {}
    for label, key in markers.items():
        found = re.findall(re.escape(label) + r": ([a-f0-9]{64})(?![a-f0-9])", document["note"])
        if len(found) != 1:
            raise ValueError("The claims request has incomplete or ambiguous input hashes. Ask its drafter to create a current request.")
        expected[key] = found[0]
    return {"ok": True, "errors": [], "handoff": document, "stale": any(report[key] != value for key, value in expected.items()),
            "expected": expected, "notice": NOTICE}


def recent(root, pack, actor_id, *, allowed_packs=None):
    try:
        scope = _scope(root, pack, actor_id, allowed_packs)
        rows = []
        if scope[4].is_dir():
            for path in sorted(scope[4].glob("*.json"), reverse=True):
                record = storage._load(scope, path.stem, allowed_routes={ROUTE})
                rows.append({key: record[key] for key in ("id", "route", "title", "state", "updated_at")}
                            | {"summary": NOTICE, "params": {"proposal_id": record["id"]}})
        return rows
    except (ValueError, OSError, TypeError, details._Invalid):
        return []


def _worker(request):
    import cohortly_export as exporter
    workbook = request["workbook"]
    spine, tabs, digest = exporter.read_workbook(workbook)
    extracted = exporter.extract(spine)
    event_rows = [row["key"] for row in extracted["criteria"] if row["call"] and row["call"][0] in ("trace_event_count", "trace_events")]
    bindings = None
    if request["bindings"] is not None:
        path = Path(workbook).parent / "bindings.yaml"
        path.write_bytes(request["bindings"].encode("utf-8"))
        bindings = exporter.load_bindings(str(path), tabs, extracted)
    exporter.apply_bindings(extracted, bindings)
    manifest = exporter.manifest(workbook, tabs, extracted, digest, bindings)
    text, seal = exporter.seal_manifest(yaml.safe_dump(manifest, sort_keys=False, allow_unicode=True, width=100))
    script = exporter.render(Path(workbook).name, tabs, extracted, digest, bindings)
    return {"ok": True, "workbook_sha256": digest, "bindings_sha256": bindings["sha256"] if bindings else None,
            "manifest_sha256": seal, "manifest": text, "script": script, "gaps": manifest["blocking_gaps"],
            "criteria": manifest["criteria"], "event_criteria": event_rows, "study_specs": manifest["study_specs"],
            "code_lists": {name: {"count": len(tab["codes"]), "systems": sorted({str(row.get('type') or '') for row in tab["codes"]})}
                           for name, tab in tabs["lists"].items()}, "unread_tabs": tabs["unread"]}


if __name__ == "__main__" and "--worker" in sys.argv:
    try:
        print(json.dumps(_worker(json.load(sys.stdin)), ensure_ascii=False, default=str))
    except SystemExit as error:
        print(json.dumps({"ok": False, "error": str(error)}))
    except Exception:
        print(json.dumps({"ok": False, "error": "The canonical claims exporter could not parse the workbook or bindings. Repair their structure before continuing."}))
