"""Text-only client for the explicitly connected VS Code language-model bridge.

The descriptor stays in the user's home directory. It grants access only to an
authenticated loopback endpoint bound to this checkout and a selected model.
No proxy, redirect, tools, provider fallback or credential persistence is used.
"""
from __future__ import annotations

import hashlib
import http.client
import json
from pathlib import Path
import re
import socket
import threading
import time
from urllib.parse import urlsplit

MAX_CONTEXT_BYTES = 18_000
MAX_BODY_BYTES = 24_000
MAX_REPLY_BYTES = 24_000
MAX_OUTPUT_TOKENS = 2_000
TIMEOUT_SECONDS = 45
HEALTH_TIMEOUT_SECONDS = 1.5
MODEL_KEYS = {"id", "name", "family", "vendor", "version"}
GPT5_MINI_ALIASES = {"gpt-5-mini", "gpt-5-mini-2025-08-07", "gpt-5 mini", "gpt 5 mini"}
ERRORS = {
    "bridge_missing": "The VS Code bridge is not connected. Open this checkout in VS Code and run RWD Portal: Connect Chat Model, then retry explicitly.",
    "bridge_invalid": "The local VS Code bridge descriptor is invalid. Reconnect the chat model from this checkout in VS Code.",
    "bridge_inactive": "The VS Code bridge is inactive. Keep the connected VS Code window open or reconnect the chat model.",
    "bridge_changed": "The VS Code connection or selected model changed. Reconnect and request fresh suggestions explicitly.",
    "model_unavailable": "The selected VS Code chat model is unavailable or unsupported. Run RWD Portal: Connect Chat Model and select an available Claude Sonnet or GPT-5 mini model.",
    "unauthorized": "The VS Code bridge rejected its local connection credential. Reconnect the chat model in VS Code.",
    "forbidden": "VS Code denied language-model access. Grant access through its chat-model connection command, then retry explicitly.",
    "workspace_mismatch": "The VS Code bridge belongs to a different checkout. Connect the chat model from this repository's VS Code window.",
    "invalid_request": "The VS Code bridge rejected this bounded text request. Reconnect a compatible bridge before retrying.",
    "request_too_large": "The selected row and draft exceed the VS Code bridge request limit. Shorten the working answers or continue manually.",
    "response_too_large": "The VS Code response exceeded the bounded suggestion limit. No suggestions were saved.",
    "timeout": "The VS Code model request timed out. No suggestions were saved; retry explicitly when it is available.",
    "quota": "VS Code reported a model quota or usage limit. Check the selected model's access in VS Code before retrying.",
    "busy": "The VS Code bridge is handling another request. Wait for it to finish, then retry explicitly.",
    "unsupported_response": "The VS Code model returned unsupported content. This drafting connection accepts text only.",
    "provider_error": "The VS Code model could not complete this request. Check its access in VS Code and retry explicitly; no draft was saved.",
}


class BridgeError(ValueError):
    """Only fixed error codes/messages can cross the local bridge boundary."""

    def __init__(self, code):
        self.code = code if code in ERRORS else "provider_error"
        super().__init__(ERRORS[self.code])


def descriptor_path():
    return Path.home() / ".rwd-portal" / "vscode-model-bridge.json"


def _json(raw):
    def pairs(items):
        result = {}
        for key, value in items:
            if key in result:
                raise ValueError("duplicate")
            result[key] = value
        return result
    return json.loads(raw, object_pairs_hook=pairs, parse_constant=lambda _value: (_ for _ in ()).throw(ValueError("nonfinite")))


def _model(value):
    if not isinstance(value, dict) or set(value) != MODEL_KEYS:
        raise BridgeError("model_unavailable")
    if any(not isinstance(item, str) or (key != "version" and not item.strip()) or len(item) > 180 or
           any(not character.isprintable() for character in item) or
           re.search(r"\bsk-(?:ant-)?[A-Za-z0-9_-]{12,}|\b(?:api[_ -]?key|access[_ -]?token|authorization)\s*[:=]", item, re.I)
           for key, item in value.items()):
        raise BridgeError("model_unavailable")
    identities = [value[key].strip().lower() for key in ("id", "name", "family")]
    if not (any("sonnet" in identity for identity in identities) or any(identity in GPT5_MINI_ALIASES for identity in identities)):
        raise BridgeError("model_unavailable")
    return dict(value)


def _same_workspace(workspace, root):
    try:
        return workspace.is_absolute() and workspace.samefile(root)
    except (OSError, ValueError):
        return False


def _descriptor(root, path):
    try:
        root, path = Path(root).resolve(), Path(path)
        if not path.is_absolute() or path.resolve() != path.absolute() or path.resolve().is_relative_to(root):
            raise BridgeError("bridge_invalid")
        if not path.is_file():
            raise BridgeError("bridge_missing")
        with path.open("rb") as handle:
            raw = handle.read(8_001)
        if len(raw) > 8_000:
            raise BridgeError("bridge_invalid")
        data = _json(raw)
        if not isinstance(data, dict) or set(data) != {"version", "url", "port", "token", "workspace_root", "model", "created_at"}:
            raise BridgeError("bridge_invalid")
        if type(data["version"]) is not int or data["version"] != 1:
            raise BridgeError("bridge_invalid")
        if type(data["port"]) is not int or not 1 <= data["port"] <= 65535:
            raise BridgeError("bridge_invalid")
        url = urlsplit(data["url"])
        if (url.scheme != "http" or url.hostname != "127.0.0.1" or url.port != data["port"] or
                data["url"] != f"http://127.0.0.1:{data['port']}/generate"):
            raise BridgeError("bridge_invalid")
        if not isinstance(data["token"], str) or not re.fullmatch(r"[A-Za-z0-9_-]{32,256}", data["token"]):
            raise BridgeError("bridge_invalid")
        workspace = Path(data["workspace_root"])
        if not _same_workspace(workspace, root):
            raise BridgeError("workspace_mismatch")
        if not isinstance(data["created_at"], str) or not 1 <= len(data["created_at"]) <= 80:
            raise BridgeError("bridge_invalid")
        data["model"] = _model(data["model"])
        return data, hashlib.sha256(raw).hexdigest()
    except BridgeError:
        raise
    except Exception:
        raise BridgeError("bridge_invalid") from None


class VSCodeModel:
    def __init__(self, root, *, path=None):
        self.root = Path(root).resolve()
        self._path = Path(path) if path is not None else descriptor_path()
        self._connection, self._digest = _descriptor(self.root, self._path)
        self.model_info = dict(self._connection["model"])
        self.model = self.model_info["id"]
        self.connection_id = self._digest

    def _fresh(self):
        _data, digest = _descriptor(self.root, self._path)
        if digest != self._digest:
            raise BridgeError("bridge_changed")

    def _request(self, path, body=None, *, timeout):
        self._fresh()
        connection = None
        timer = None
        expired = threading.Event()
        try:
            deadline = time.monotonic() + timeout
            connection = http.client.HTTPConnection("127.0.0.1", self._connection["port"], timeout=timeout)
            headers = {"Authorization": "Bearer " + self._connection["token"], "Accept": "application/json"}
            if body is not None:
                headers["Content-Type"] = "application/json"
            connection.request("POST" if body is not None else "GET", path, body=body, headers=headers)
            # HTTPConnection detaches its socket after Connection: close
            # headers. Preserve it so every streamed read still gets the
            # remaining absolute deadline instead of a fresh full timeout.
            request_socket = connection.sock
            if request_socket is not None:
                def abort_at_deadline():
                    expired.set()
                    try:
                        request_socket.shutdown(socket.SHUT_RDWR)
                    except OSError:
                        pass
                timer = threading.Timer(max(0, deadline - time.monotonic()), abort_at_deadline)
                timer.daemon = True
                timer.start()
            response = connection.getresponse()
            if 300 <= response.status < 400:
                raise BridgeError("bridge_invalid")
            length = response.getheader("Content-Length")
            if length is not None and (not length.isdecimal() or int(length) > MAX_REPLY_BYTES):
                raise BridgeError("response_too_large")
            if response.getheader("Content-Encoding", "identity") != "identity":
                raise BridgeError("unsupported_response")
            chunks, total = [], 0
            while True:
                remaining = deadline - time.monotonic()
                if remaining <= 0:
                    raise BridgeError("timeout")
                if request_socket is not None:
                    request_socket.settimeout(remaining)
                chunk = response.read1(min(4096, MAX_REPLY_BYTES + 1 - total))
                if not chunk:
                    break
                total += len(chunk)
                if total > MAX_REPLY_BYTES:
                    raise BridgeError("response_too_large")
                chunks.append(chunk)
            result = _json(b"".join(chunks))
            if not isinstance(result, dict):
                raise BridgeError("unsupported_response")
            if "error" in result:
                error = result["error"]
                code = error.get("code") if isinstance(error, dict) else None
                raise BridgeError(code if isinstance(code, str) else "provider_error")
            if response.status != 200:
                raise BridgeError("unauthorized" if response.status == 401 else "provider_error")
            if expired.is_set() or time.monotonic() >= deadline:
                raise BridgeError("timeout")
            self._fresh()
            return result
        except BridgeError:
            raise
        except TimeoutError:
            raise BridgeError("timeout") from None
        except (ConnectionError, OSError, http.client.HTTPException):
            raise BridgeError("timeout" if expired.is_set() else "bridge_inactive") from None
        except Exception:
            raise BridgeError("timeout" if expired.is_set() else "unsupported_response") from None
        finally:
            if timer is not None:
                timer.cancel()
            if connection is not None:
                connection.close()

    def health(self):
        result = self._request("/health", timeout=HEALTH_TIMEOUT_SECONDS)
        if set(result) != {"version", "workspace_root", "model"} or type(result["version"]) is not int or result["version"] != 1:
            raise BridgeError("bridge_invalid")
        try:
            workspace = Path(result["workspace_root"])
            if not _same_workspace(workspace, self.root):
                raise BridgeError("workspace_mismatch")
            if _model(result["model"]) != self.model_info:
                raise BridgeError("bridge_changed")
        except BridgeError:
            raise
        except Exception:
            raise BridgeError("bridge_invalid") from None
        return self.model_info.copy()

    def step(self, system, transcript):
        if (not isinstance(system, str) or not isinstance(transcript, list) or len(transcript) != 1 or
                not isinstance(transcript[0], dict) or set(transcript[0]) != {"role", "content"} or
                transcript[0]["role"] != "user" or not isinstance(transcript[0]["content"], str)):
            raise BridgeError("invalid_request")
        if len(system.encode("utf-8")) + len(transcript[0]["content"].encode("utf-8")) > MAX_CONTEXT_BYTES:
            raise BridgeError("request_too_large")
        # The descriptor is already bound to self.root by filesystem identity.
        # Preserve Node's spelling on the wire, including Windows drive casing.
        body = json.dumps({"system": system, "transcript": transcript, "max_output_tokens": MAX_OUTPUT_TOKENS,
                           "timeout_ms": TIMEOUT_SECONDS * 1000, "workspace_root": self._connection["workspace_root"]},
                          ensure_ascii=False, allow_nan=False, separators=(",", ":")).encode("utf-8")
        if len(body) > MAX_BODY_BYTES:
            raise BridgeError("request_too_large")
        result = self._request("/generate", body, timeout=TIMEOUT_SECONDS)
        if set(result) != {"text", "model"} or not isinstance(result["text"], str):
            raise BridgeError("unsupported_response")
        if _model(result["model"]) != self.model_info:
            raise BridgeError("bridge_changed")
        return result["text"]
