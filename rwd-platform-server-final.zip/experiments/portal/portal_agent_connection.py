"""The request studio and governed loop use the explicit session connection."""
from contextvars import copy_context
from pathlib import Path
import threading

import scientific_definition_ai as ai
import specialist_workspace as specialists
import specification_details as details
from specialist_workspace import BoundedModel, MAX_CALLS


def describe(root):
    """Read connection configuration only; never send a model request."""
    try:
        config = ai._provider(Path(root))
        if not config.get("configured"):
            return {"ok": False, "errors": [config["help"]]}
        return {"ok": True, "provider": config["provider"], "provider_id": config["provider_id"],
                "model": config["model"], "connection_id": config.get("connection_id", ""),
                "help": config.get("help", ""), "errors": []}
    except ai.Invalid as error:
        return {"ok": False, "errors": [str(error)]}
    except ai.vscode.BridgeError as error:
        return {"ok": False, "errors": [ai.vscode.ERRORS.get(error.code, ai.vscode.ERRORS["provider_error"])]}
    except Exception:
        return {"ok": False, "errors": ["The selected assistant configuration is unavailable. Check Assistant connection in the sidebar; no other provider will be used."]}


def _binding(config):
    return tuple(config.get(key, "") for key in ("provider_id", "model", "connection_id"))


def check_input(value):
    """Refuse sensitive text before either chat history or a model receives it."""
    ai._ingress(ai._plain(value))


class _SafeClient:
    def __init__(self, root, config, client):
        self.root, self.binding, self.client = Path(root), _binding(config), client
        self.model = config["model"]

    def _fresh(self):
        current = ai._provider(self.root)
        if not current.get("configured") or _binding(current) != self.binding:
            raise ai.Invalid("The selected assistant connection changed. Your request and recorded checks remain available; send a new request to use the current connection.")

    def step(self, system, messages):
        self._fresh()
        # The bounded adapter has already flattened the transcript. Keep the run's
        # identity, scope and usage accumulator inside the timeout thread as well.
        context, client = copy_context(), self.client
        class ContextClient:
            def step(self, inner_system, inner_messages):
                return context.run(client.step, inner_system, inner_messages)
        raw = ai._call(ContextClient(), messages[0]["content"], system=system)
        self._fresh()
        return raw


class _TaskModel:
    """A task address on the same session model, never another request budget."""
    def __init__(self, model, route, kind, *, query=None, task_scope=None):
        self._model, self._route, self._kind = model, route, kind
        import workflow_skills
        self._query, self._task_scope = workflow_skills.task_context(query, task_scope)

    def __getattr__(self, name):
        return getattr(self._model, name)

    def step(self, system, messages):
        return self._model._step_for(system, messages, self._route, self._kind, self._query, self._task_scope)

    def for_task(self, *, route=None, kind=None, query=None, task_scope=None):
        return self._model.for_task(route=route, kind=kind, query=self._query if query is None else query,
            task_scope=self._task_scope if task_scope is None else task_scope)

    def workflow_retrieval_context(self):
        return {"root": self._model.client.root, "route": self._route, "kind": self._kind,
                "query": self._query, "task_scope": dict(self._task_scope)}


class SessionModel(BoundedModel):
    """One cumulative budget for the orchestrator, delegated agents and critics."""
    def __init__(self, client, config):
        super().__init__(client, config)
        self._lock = threading.RLock()
        self._evidence = {}
        self._completed_calls = []
        self._primary_pack = None
        self._critics = []
        self._skill_digests = {}
        self._task_query, self._task_scope = "", {}
        self.execution_purpose = 'governed_check'

    def for_task(self, *, route=None, kind=None, query=None, task_scope=None):
        """Canonical callers name the task; prompt wording never selects skills."""
        if kind is None and route in (None, "governed_check"):
            if query is not None or task_scope is not None:
                import workflow_skills
                with self._lock:
                    self._task_query, self._task_scope = workflow_skills.task_context(query, task_scope)
            return self
        return _TaskModel(self, route or ("governed_check" if kind is None else None), kind, query=query, task_scope=task_scope)

    def workflow_retrieval_context(self):
        return {"root": self.client.root, "route": "governed_check", "kind": None,
                "query": self._task_query, "task_scope": dict(self._task_scope)}

    def start_run(self, pack, scope):
        """Bind local execution collection to the explicitly selected product."""
        self._primary_pack = None
        self._completed_calls = []
        self._critics = []
        if not pack or pack not in (scope or set()) or not str(pack).startswith('products/'):
            return
        # This collects provenance only. Existing tool authorization still gates
        # source access; ineligible metadata cannot become learning evidence.
        try:
            details._paths(self.client.root, pack, scope)
            if specialists._eligibility(self.client.root, pack):
                return
            self._evidence[pack] = specialists.science._digest(specialists._inputs(self.client.root, pack))
            self._primary_pack = pack
        except Exception:
            return

    def completed_run(self, st):
        import orchestrator
        import model_lifecycle_runtime as learning
        classes = (ai.vscode.VSCodeModel, ai.claude_code.ClaudeCodeModel, orchestrator.AnthropicModel)
        native = any(isinstance(cls, type) and type(self.client.client) is cls for cls in classes)
        if not native or not self._primary_pack or not self._completed_calls:
            return
        self._fresh_evidence()
        run = learning.basis(vars(st))
        st.execution = learning.receipt(run, {'mode': 'native_selected_provider' if self.execution_purpose == 'governed_check' else 'canonical_case_evaluation', 'pack': self._primary_pack,
            'provider': self.config['provider_id'], 'source_digest': self._evidence[self._primary_pack],
            'successful_calls': len(self._completed_calls), 'calls': self._completed_calls,
            'critics': self._critics,
            'notice': 'Locally attributed execution metadata; not cryptographically authenticated evidence.'})
        st.save()
        if self.execution_purpose != 'governed_check':
            return
        st.workflow_continuations = learning.continuations(self.client.root, self._primary_pack, vars(st))
        st.save()

    def record_critic(self, pack, value):
        with self._lock:
            if (pack == self._primary_pack and isinstance(value, dict)
                    and value.get('confidence') in {'low', 'medium', 'high'}
                    and value.get('route') in {'pass_on', 'revise', 'human'} and type(value.get('falsified')) is bool):
                ai._ingress(ai._plain(value))
                self._critics.append({key: value[key] for key in ('confidence', 'route', 'falsified')} |
                    {'findings': list(value.get('findings') or [])})

    def authorize_pack(self, pack):
        """A delegated source read has the same eligibility as the specialist page."""
        import tools
        with self._lock:
            try:
                scope = tools.current_scope()
                if scope is None:
                    raise ValueError("No product scope was supplied.")
                _path, pack = details._paths(self.client.root, pack, scope)
                if specialists._eligibility(self.client.root, pack):
                    raise tools.ModelStopped("The sanitized source needs its recorded AI-access review before a specialist can read it. Continue with the source review in Product progress.")
                digest = specialists.science._digest(specialists._inputs(self.client.root, pack))
                if pack in self._evidence and self._evidence[pack] != digest:
                    raise tools.ModelStopped("Product evidence changed during this check. Your completed checks are retained; check the current evidence before explicitly starting again.")
                self._evidence[pack] = digest
            except tools.ModelStopped:
                raise
            except Exception:
                raise tools.ModelStopped("The specialist evidence cannot be read within this product's access and declared paths. Repair it in Product progress before requesting help.") from None

    def _fresh_evidence(self):
        for pack in tuple(self._evidence):
            self.authorize_pack(pack)

    def step(self, system, messages):
        return self._step_for(system, messages, "governed_check", None, self._task_query, self._task_scope)

    def _step_for(self, system, messages, route, kind, query=None, task_scope=None):
        with self._lock:
            return self._step(system, messages, route, kind, query, task_scope)

    def _step(self, system, messages, route, kind, query=None, task_scope=None):
        import tools
        import workflow_skills
        if self.calls >= MAX_CALLS:
            raise tools.ModelStopped("This request reached its four-call assistant limit. Your draft and completed checks are retained. Review them before explicitly continuing.")
        try:
            self._fresh_evidence()
            key = (route, kind)
            skills = workflow_skills.context_for(self.client.root, route, kind=kind, max_bytes=4500,
                expected_digest=self._skill_digests.get(key), query=query, task_scope=task_scope)
            if not skills.get("ok"):
                raise tools.ModelStopped(" ".join(skills.get("errors") or ["The current workflow skill could not be read."]))
            self._skill_digests[key] = skills["digest"]
            previous = self.skills
            self.skills = skills
            try:
                # BoundedModel is the single skill injector for both standalone
                # and delegated agents. The view and critic share these counters.
                result = super().step(system, messages)
            finally:
                self.skills = previous
            fresh = workflow_skills.freshness(self.client.root, route, skills["digest"], kind=kind)
            if not fresh.get("ok"):
                raise tools.ModelStopped(" ".join(fresh.get("errors") or ["The workflow skill changed during this request."]))
            self._fresh_evidence()
            import model_lifecycle_runtime as learning
            self._completed_calls.append({'request': learning.digest([route, kind, skills["digest"], system, messages]),
                                          'response': learning.digest(result)})
            return result
        except tools.ModelStopped:
            raise
        except ai.Invalid as error:
            raise tools.ModelStopped(str(error)) from None
        except Exception:
            # Never persist adapter exception bodies, credentials or HTTP headers.
            raise tools.ModelStopped("The selected assistant could not continue within this request's limits. Your draft and completed checks are retained. Check the selected connection and retry explicitly; no other provider was used.") from None


def model(root, *, expected=None):
    """Construct only the selected provider and bind subsequent calls to it."""
    try:
        config = ai._provider(Path(root))
        if not config.get("configured"):
            raise ai.Invalid(config["help"])
        if expected is not None and (not expected.get("ok") or _binding(config) != _binding(expected)):
            raise ai.Invalid("The selected assistant changed after this page was shown. Check its connection and send the request again.")
        client = config.get("instance") or ai._make_model(config["model"], config["spec"])
        return SessionModel(_SafeClient(root, config, client), config)
    except ai.Invalid:
        raise
    except Exception:
        raise ai.Invalid("The selected assistant is unavailable. Your request is retained. Check its connection in the sidebar; no other provider was used.") from None


def intake_turn(root, state, text, *, actor_id, allowed_packs, expected=None):
    import intake
    try:
        if state.get("actor") != actor_id or state.get("pack") not in set(allowed_packs):
            raise ai.Invalid("This request belongs to a different identity or product. Reopen the request in its own context.")
        check_input(text)
        check_input(state)
        current, reply = intake.next_turn(state, text, model(root, expected=expected).for_task(route="governed_check"))
        return {"ok": True, "state": current, "reply": reply, "errors": []}
    except ai.Invalid as error:
        return {"ok": False, "state": state, "errors": [str(error)]}
    except Exception as error:
        import tools
        message = str(error) if isinstance(error, tools.ModelStopped) else "The selected assistant could not draft the next question. Your request is retained; retry explicitly after checking the connection."
        return {"ok": False, "state": state, "errors": [message]}
