"""Edit specification identifiers, never reviews, classifications or approvals.

The editor replaces only explicitly requested scalar values and checks the parsed
result against that exact change. It does not dump YAML or alter neighbouring fields.
All reads and saves are confined to a canonical pack's source_refs.yaml.
"""
from __future__ import annotations

import copy
from contextlib import contextmanager, ExitStack
import hashlib
import json
import os
import re
import sys
import tempfile
import uuid
from pathlib import Path

import yaml
import local_process_lock

_TOOLS = str(Path(__file__).resolve().parents[2] / "platform" / "tools")
if _TOOLS not in sys.path:
    sys.path.insert(0, _TOOLS)
from person_rules import unstated  # noqa: E402 — same placeholder rule as source_manifest
try:
    import product_gates  # noqa: E402 — the registry's own names for a pack (code and slug)
except Exception:  # noqa: BLE001 — the editor still works without the registry; it then accepts the slug only
    product_gates = None

FIELDS = ("document_id", "revision", "data_refresh", "rwb_qc_reference")
LIMITS = {"document_id": 160, "revision": 120, "data_refresh": 100, "rwb_qc_reference": 2000}
MAX_BYTES = 512 * 1024
NOTICE = ("These details identify the specification. Saving them does not record a scientific approval, "
          "complete a QC review, authenticate a signature or seal a source event.")


@contextmanager
def source_edit_lock(root, path):
    """One process-owned source lock shared by metadata, review and attachment edits."""
    with ExitStack() as stack:
        try:
            stack.enter_context(local_process_lock.locked(path.with_name(".source_refs.portal-edit.lock"), root))
        except (ValueError, OSError) as error:
            raise _Invalid("Source editing is unavailable. " + str(error)) from None
        yield


class _Invalid(ValueError):
    pass


class _StrictLoader(yaml.SafeLoader):
    def construct_mapping(self, node, deep=False):
        keys = []
        for key, _value in node.value:
            if not isinstance(key, yaml.ScalarNode) or key.tag != "tag:yaml.org,2002:str":
                raise _Invalid("Source record keys must be unique text names.")
            if key.value in keys:
                raise _Invalid("The source record contains a duplicate field. Ask your data expert to repair it.")
            keys.append(key.value)
        return super().construct_mapping(node, deep=deep)


def _paths(root, pack, allowed_packs):
    base = Path(root).resolve()
    text = str(pack or "").replace("\\", "/")
    # products, the reference fixtures and the shipped demo copy under sandbox/ are the packs the
    # portal offers; the cut label is a six-digit YYYYMM (a template's literal YYYYMM is not a pack)
    if not re.fullmatch(r"(?:products|fixtures|sandbox)/[A-Za-z0-9_-]+/[A-Za-z0-9_-]+/\d{6}", text):
        raise _Invalid("Choose a registered product, reference pack or demo pack before editing specification details.")
    expected = base / text
    parent = expected.resolve()
    if parent != expected or not parent.is_dir():
        raise _Invalid("The product location is unavailable or redirects outside its canonical path.")
    parent.relative_to(base)
    if allowed_packs is not None:
        scope = {str(p).replace("\\", "/").strip("/").casefold() for p in allowed_packs}
        if text.casefold() not in scope:
            raise _Invalid("This product is outside your access.")
    path = parent / "source_refs.yaml"
    if path.resolve() != path:
        raise _Invalid("The source record redirects to another location. Ask your data expert to repair it.")
    return path, text


def _accepted_products(root, pack):
    """The names the source record may call this product: the pack's slug and, when the registry
    knows the pack, its registry code (the prostate fixture says `mcrpc` for the slug `prostate`)."""
    names = {str(pack).replace("\\", "/").split("/")[-2]}
    if product_gates is not None:
        try:
            entry = product_gates.registry_entry(root, pack)
        except Exception:  # noqa: BLE001 — an unreadable registry never widens what is accepted
            entry = None
        if isinstance(entry, dict):
            names |= {str(entry[k]) for k in ("code", "slug") if isinstance(entry.get(k), str) and entry[k].strip()}
    return names


def _parse(raw, pack, accepted=()):
    if len(raw) > MAX_BYTES:
        raise _Invalid("The source record is too large for this metadata editor.")
    text = raw.decode("utf-8")
    if any(isinstance(token, (yaml.AliasToken, yaml.AnchorToken)) for token in yaml.scan(text)):
        raise _Invalid("This source record uses YAML aliases. Ask your data expert to edit it directly.")
    doc = yaml.load(text, Loader=_StrictLoader)
    tree = yaml.compose(text, Loader=_StrictLoader)
    if not isinstance(doc, dict) or not isinstance(tree, yaml.MappingNode):
        raise _Invalid("The source record must be a YAML mapping.")
    names = {pack.split("/")[-2]} | set(accepted or ())
    if str(doc.get("product") or "") not in names or str(doc.get("spec_version") or "") != pack.split("/")[-1]:
        raise _Invalid("The source record's product and specification cut must match the selected pack.")
    materials = doc.get("source_materials")
    if not isinstance(materials, list) or not materials or not all(isinstance(m, dict) for m in materials):
        raise _Invalid("The source record must contain a list of named source materials.")
    ids = [m.get("material_id") for m in materials]
    if any(not isinstance(mid, str) or not mid.strip() for mid in ids) or len(set(ids)) != len(ids):
        raise _Invalid("Source materials must have unique, nonempty material identifiers.")
    specs = [i for i, material in enumerate(materials) if material.get("material_type") == "program_spec"]
    if len(specs) != 1:
        raise _Invalid("The source record must identify exactly one program specification.")
    index = specs[0]
    material = materials[index]
    identity = material.get("object_uuid")
    if identity is not None and (not isinstance(identity, str) or not identity.strip()):
        raise _Invalid("The existing object_uuid is malformed. Ask your data expert to repair it.")
    if identity:
        try:
            uuid.UUID(identity)
        except ValueError as exc:
            raise _Invalid("The existing object_uuid is malformed. Ask your data expert to repair it.") from exc
    for field in FIELDS:
        if material.get(field) is not None and not isinstance(material[field], str):
            raise _Invalid(f"The existing {field} must be text. Ask your data expert to repair its YAML value.")
    materials_node = next(value for key, value in tree.value if key.value == "source_materials")
    if not isinstance(materials_node, yaml.SequenceNode):
        raise _Invalid("The source material list is malformed.")
    return text, doc, index, materials_node.value[index]


def _load(root, pack, allowed_packs):
    path, pack = _paths(root, pack, allowed_packs)
    if not path.is_file():
        raise _Invalid("This pack has no source record yet. Register the program specification first "
                       "(Progress and next step, stage 1); the details can be edited after that.")
    with path.open("rb") as handle:
        raw = handle.read(MAX_BYTES + 1)
    text, doc, index, node = _parse(raw, pack, _accepted_products(root, pack))
    return path, pack, raw, text, doc, index, node


def suggest_document_id(description):
    """Return an existing identifier, or a stable suggestion; this never writes."""
    if not isinstance(description, dict) or not description.get("ok"):
        return ""
    existing = (description.get("values") or {}).get("document_id") or ""
    if existing.strip():
        return existing
    identity = str(description.get("object_uuid") or "").strip()
    if identity:
        try:
            identity = str(uuid.UUID(identity))
        except ValueError:
            return ""
    identifier = uuid.uuid5(uuid.NAMESPACE_URL, "rwdp:specification:" + (identity or description["pack"]))
    return "SPEC-" + identifier.hex.upper()


def _failure(error):
    return {"ok": False, "changed": False, "errors": [str(error)], "warnings": [NOTICE],
            "values": {field: "" for field in FIELDS}, "digest": "", "suggested_document_id": ""}


def describe(root, pack, allowed_packs=None):
    """Read current editable values and a byte digest for optimistic concurrency."""
    try:
        _path, pack, raw, _text, doc, index, _node = _load(root, pack, allowed_packs)
        material = doc["source_materials"][index]
        result = {"ok": True, "pack": pack, "path": pack + "/source_refs.yaml",
                  "digest": hashlib.sha256(raw).hexdigest(), "material_id": material["material_id"],
                  "object_uuid": str(material.get("object_uuid") or ""), "status": str(material.get("status") or ""),
                  "values": {field: "" if unstated(material.get(field)) else material[field] for field in FIELDS},
                  "errors": [], "warnings": [NOTICE]}
        result["suggested_document_id"] = suggest_document_id(result)
        return result
    except (_Invalid, OSError, ValueError, TypeError, UnicodeError, yaml.YAMLError, RecursionError) as exc:
        return _failure(str(exc) if isinstance(exc, _Invalid) else "The source record could not be read safely. Ask your data expert to repair it.")


def _edited(text, doc, index, node, changes, pack, accepted=()):
    if not isinstance(node, yaml.MappingNode) or node.flow_style:
        raise _Invalid("This source record uses an inline YAML mapping. Ask your data expert to edit it directly.")
    pairs = {key.value: (key, value) for key, value in node.value}
    edits, additions = [], []
    for field, value in changes.items():
        encoded = json.dumps(value, ensure_ascii=False)
        if field in pairs:
            _key, old = pairs[field]
            if not isinstance(old, yaml.ScalarNode) or old.style in {"|", ">"}:
                raise _Invalid(f"The existing {field} uses a multiline YAML value. Ask your data expert to edit it directly.")
            prefix = " " if old.start_mark.index and text[old.start_mark.index - 1] == ":" else ""
            edits.append((old.start_mark.index, old.end_mark.index, prefix + encoded))
        else:
            additions.append(f"{field}: {encoded}")
    if additions:
        # Insert immediately after the mapping's first physical line. All original
        # lines, comments and following materials retain their exact bytes.
        first_key = node.value[0][0]
        end = text.find("\n", first_key.end_mark.index)
        if end < 0:
            end = len(text)
            prefix = "\r\n" if "\r\n" in text else "\n"
        else:
            end += 1
            prefix = ""
        newline = "\r\n" if "\r\n" in text else "\n"
        indent = " " * first_key.start_mark.column
        edits.append((end, end, prefix + "".join(indent + item + newline for item in additions)))
    for start, end, value in sorted(edits, key=lambda edit: (edit[0], edit[1]), reverse=True):
        text = text[:start] + value + text[end:]
    expected = copy.deepcopy(doc)
    expected["source_materials"][index].update(changes)
    _text, actual, _index, _node = _parse(text.encode("utf-8"), pack, accepted)
    if actual != expected:
        raise _Invalid("The YAML layout cannot be edited without changing other content. Ask your data expert to edit it directly.")
    return text.encode("utf-8")


def save(root, pack, updates, *, expected_digest, local_demo, can_write, allowed_packs=None):
    """Atomically save explicitly supplied metadata after scope, role and digest checks.

    Empty values keep existing fields. The lock serializes portal saves; the byte
    digest is checked again immediately before replacement to detect outside edits.
    """
    if local_demo is not True or can_write is not True:
        return _failure("Saving specification details requires an authorized local editing session.")
    if not isinstance(updates, dict) or any(field not in FIELDS for field in updates):
        return _failure("Only document_id, revision, data_refresh and rwb_qc_reference can be edited here.")
    if not isinstance(expected_digest, str) or not re.fullmatch(r"[0-9a-f]{64}", expected_digest):
        return _failure("Reload the current specification details before saving; their baseline digest is required.")
    clean = {}
    for field, value in updates.items():
        if value is None or value == "":
            continue
        if not isinstance(value, str):
            return _failure(f"{field} must be text.")
        value = value.strip()
        if not value:
            continue
        if unstated(value):
            return _failure(f"{field} needs its actual value; leave it blank to keep it pending.")
        if len(value) > LIMITS[field] or any(ord(c) < 32 or ord(c) == 127 for c in value):
            return _failure(f"{field} must be a single line of at most {LIMITS[field]} characters.")
        clean[field] = value
    temporary = None
    lock_stack = ExitStack()
    try:
        path, pack = _paths(root, pack, allowed_packs)
        lock_stack.enter_context(source_edit_lock(root, path))
        path, pack, raw, text, doc, index, node = _load(root, pack, allowed_packs)
        if hashlib.sha256(raw).hexdigest() != expected_digest:
            raise _Invalid("The source record changed while this form was open. Reload it and review the latest details before saving.")
        changes = {field: value for field, value in clean.items() if doc["source_materials"][index].get(field) != value}
        if not changes:
            return {**describe(root, pack, allowed_packs), "changed": False, "changed_fields": []}
        replacement = _edited(text, doc, index, node, changes, pack, _accepted_products(root, pack))
        with tempfile.NamedTemporaryFile(mode="wb", prefix=".source_refs-", suffix=".tmp", dir=path.parent, delete=False) as handle:
            temporary = Path(handle.name)
            handle.write(replacement)
            handle.flush()
            os.fsync(handle.fileno())
        os.chmod(temporary, path.stat().st_mode)
        current_path, _pack = _paths(root, pack, allowed_packs)
        with path.open("rb") as handle:
            current_bytes = handle.read(MAX_BYTES + 1)
        if current_path != path or hashlib.sha256(current_bytes).hexdigest() != expected_digest:
            raise _Invalid("The source record changed during this save. Reload it and review the latest details before saving.")
        os.replace(temporary, path)
        temporary = None
        result = describe(root, pack, allowed_packs)
        return {**result, "changed": True, "changed_fields": list(changes)}
    except FileExistsError:
        return _failure("Another metadata save is in progress. Wait for it to finish, then reload the details.")
    except (_Invalid, OSError, ValueError, TypeError, UnicodeError, yaml.YAMLError, RecursionError) as exc:
        return _failure(str(exc) if isinstance(exc, _Invalid) else "The details could not be saved safely. The existing source record was retained.")
    finally:
        if temporary is not None:
            try:
                temporary.unlink(missing_ok=True)
            except OSError:
                pass
        lock_stack.close()
