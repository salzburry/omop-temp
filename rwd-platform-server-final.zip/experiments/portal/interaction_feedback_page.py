"""Small interaction choices that prepare the existing improvement form."""
from pathlib import Path

import streamlit as st

import workflow_improvement as workspace
import workflow_improvement_page as improvement
import workflow_skills


def clear(key):
    """Forget interaction form state when its owning row, source or identity changes."""
    prefix = "interaction_feedback_" + workflow_skills.learning().digest(str(key))[:16] + "_"
    for name in list(st.session_state):
        if str(name).startswith(prefix) or str(name).startswith(improvement.PREFIX + prefix + "form_"):
            st.session_state.pop(name, None)


def offer(root, pack, actor_id, *, route, interaction_id, request, answer,
          revised_answer=None, outcome=None, can_write, allowed_packs, key,
          title="Feedback on this answer"):
    """Keep one answer's feedback in session; save only through explicit form review."""
    prefix = "interaction_feedback_" + workflow_skills.learning().digest(str(key))[:16] + "_"
    # Never retain another identity's or product's prepared text in widget state.
    context = (str(Path(root).resolve()), pack or None, actor_id, route, interaction_id,
               bool(can_write), tuple(sorted(allowed_packs or [])))
    if st.session_state.get(prefix + "context") != context:
        clear(key)
        st.session_state[prefix + "context"] = context
    if not isinstance(answer, str) or not answer.strip():
        return
    with st.expander(title, expanded=outcome in {"edited", "rejected"}):
        if outcome == "edited":
            st.caption("You changed the proposed answer. You can explain what needed to change and prepare feedback for review.")
        elif outcome == "rejected":
            st.caption("You marked this answer as needing changes. You can explain why and prepare feedback for review.")
        else:
            st.caption("If this answer needs a change, choose a reason or describe it in your own words.")
        category = st.radio("What needs to improve?", list(workspace.FEEDBACK_REASONS), index=None,
            format_func=workspace.FEEDBACK_REASONS.get, key=prefix + "category")
        notes = st.text_area("What would help? (optional unless you chose something else)",
            key=prefix + "notes", max_chars=600,
            placeholder="For example: explain which date starts follow-up and show the source for that choice.")
        prepared = st.session_state.get(prefix + "prepared")
        if prepared:
            st.caption("Your prepared draft is below. Finish it or discard it before preparing different feedback.")
        if st.button("Prepare feedback for review", key=prefix + "prepare",
                disabled=not(can_write and category and (category != "other" or notes.strip())) or bool(prepared)):
            try:
                prepared = workspace.prepare_interaction(root, actor_id, route, pack=pack,
                    interaction_id=interaction_id, request=request, answer=answer,
                    revised_answer=revised_answer, outcome=outcome, category=category, notes=notes,
                    can_write=can_write, allowed_packs=allowed_packs)
                st.session_state[prefix + "prepared"] = prepared
            except (workspace.Invalid, ValueError) as error:
                st.warning(str(error))
        if not can_write:
            st.caption("Feedback can be saved by an author with local editing access.")
        if prepared:
            improvement.render_step(root, actor_id, prepared["skill"], can_write=can_write,
                pack=pack, allowed_packs=allowed_packs, key=prefix + "form", prepared=prepared)
            if st.button("Discard this prepared feedback", key=prefix + "discard"):
                st.session_state.pop(prefix + "prepared", None)
                for name in list(st.session_state):
                    if str(name).startswith(improvement.PREFIX + prefix + "form_"):
                        st.session_state.pop(name, None)
                st.rerun()
