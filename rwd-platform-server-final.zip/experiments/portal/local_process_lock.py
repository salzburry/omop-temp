"""Local process ownership and crash-safe advisory locks; never resume journaled work."""
from contextlib import contextmanager
import ctypes
import errno
import hashlib
import json
import os
from pathlib import Path
import socket
import uuid

MAX_OWNER_BYTES = 4096


class LockError(ValueError):
    """A bounded acquisition category; existing ValueError callers remain compatible."""
    def __init__(self, reason, code):
        super().__init__(reason)
        self.code = code


def _host():
    # Host names can repeat across users' machines. Bind their local machine ID
    # as well; retain only its digest in portable ownership metadata.
    machine = None
    if os.name == "nt":
        try:
            import winreg
            with winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\Microsoft\Cryptography") as key:
                machine = winreg.QueryValueEx(key, "MachineGuid")[0]
        except OSError:
            pass
    else:
        try:
            machine = Path("/etc/machine-id").read_text().strip()
        except OSError:
            pass
    if not machine:
        raise ValueError("The local machine identity cannot be established safely.")
    return hashlib.sha256((socket.gethostname() + "|" + str(machine)).encode()).hexdigest()


def _process_start(pid):
    """Return exact OS start identity, False for absent, None for uncertain."""
    if os.name == "nt":
        from ctypes import wintypes
        kernel = ctypes.WinDLL("kernel32", use_last_error=True)
        kernel.OpenProcess.argtypes = [wintypes.DWORD, wintypes.BOOL, wintypes.DWORD]
        kernel.OpenProcess.restype = wintypes.HANDLE
        handle = kernel.OpenProcess(0x1000, False, pid)
        if not handle:
            return False if ctypes.get_last_error() == 87 else None
        try:
            kernel.GetExitCodeProcess.argtypes = [wintypes.HANDLE, ctypes.POINTER(wintypes.DWORD)]
            code = wintypes.DWORD()
            if not kernel.GetExitCodeProcess(handle, ctypes.byref(code)):
                return None
            if code.value != 259:
                return False
            times = [wintypes.FILETIME() for _ in range(4)]
            kernel.GetProcessTimes.argtypes = [wintypes.HANDLE, *([ctypes.POINTER(wintypes.FILETIME)] * 4)]
            if not kernel.GetProcessTimes(handle, *(ctypes.byref(value) for value in times)):
                return None
            return str((times[0].dwHighDateTime << 32) | times[0].dwLowDateTime)
        finally:
            kernel.CloseHandle.argtypes = [wintypes.HANDLE]
            kernel.CloseHandle(handle)
    try:
        stat = Path(f"/proc/{pid}/stat").read_text()
        boot = Path("/proc/sys/kernel/random/boot_id").read_text().strip()
        # The process name in parentheses may itself contain spaces or ')'.
        fields = stat[stat.rfind(")") + 2:].split()
        if fields[0] == "Z":
            return False
        return boot + ":" + fields[19]
    except FileNotFoundError:
        try:
            os.kill(pid, 0)
        except ProcessLookupError:
            return False
        except (PermissionError, OSError):
            pass
        return None
    except (OSError, IndexError):
        return None


def process_identity(pid=None):
    pid = os.getpid() if pid is None else pid
    if type(pid) is not int or not 0 < pid <= 0xFFFFFFFF:
        raise ValueError("A local process identity requires a positive process ID.")
    started = _process_start(pid)
    if not isinstance(started, str) or not started:
        raise ValueError("The process start identity cannot be established safely.")
    return {"pid": pid, "start": started, "host": _host()}


def process_alive(identity):
    """True: same live process; False: verified original is dead; None: uncertain."""
    if (not isinstance(identity, dict) or type(identity.get("pid")) is not int
            or not 0 < identity["pid"] <= 0xFFFFFFFF or not isinstance(identity.get("start"), str)
            or not identity["start"] or len(identity["start"]) > 200):
        return None
    try:
        if identity.get("host") != _host():
            return None
    except ValueError:
        return None
    current = _process_start(identity["pid"])
    return None if current is None else False if current is False else current == identity["start"]


def _path(path, checkout):
    path, checkout = Path(path).absolute(), Path(checkout).resolve(strict=True)
    if path.resolve() != path or not path.is_relative_to(checkout):
        raise ValueError("The local lock must stay in its declared checkout.")
    return path, hashlib.sha256(os.path.normcase(str(checkout)).encode()).hexdigest()


def _advisory(handle, acquire):
    os.lseek(handle, 0, os.SEEK_SET)
    if os.name == "nt":
        import msvcrt
        msvcrt.locking(handle, msvcrt.LK_NBLCK if acquire else msvcrt.LK_UNLCK, 1)
    else:
        import fcntl
        fcntl.flock(handle, fcntl.LOCK_EX | fcntl.LOCK_NB if acquire else fcntl.LOCK_UN)


def _read(handle, checkout):
    os.lseek(handle, 0, os.SEEK_SET)
    raw = os.read(handle, MAX_OWNER_BYTES + 1)
    try:
        owner = json.loads(raw)
        if (len(raw) > MAX_OWNER_BYTES or not isinstance(owner, dict)
                or type(owner.get("version")) is not int or owner["version"] != 1
                or owner.get("checkout") != checkout or not isinstance(owner.get("state"), str)
                or owner["state"] not in {"held", "released"}
                or not isinstance(owner.get("token"), str) or len(owner["token"]) != 32):
            return None
        return owner
    except (ValueError, UnicodeError, RecursionError):
        return None


def _write(handle, value):
    raw = json.dumps(value, sort_keys=True).encode()
    if len(raw) > MAX_OWNER_BYTES:
        raise ValueError("The lock identity exceeds its supported size.")
    os.lseek(handle, 0, os.SEEK_SET)
    view = memoryview(raw)
    while view:
        count = os.write(handle, view)
        if count <= 0:
            raise OSError("The local lock identity could not be written completely.")
        view = view[count:]
    os.ftruncate(handle, len(raw))
    os.fsync(handle)


def _status(owner):
    if owner is None:
        return {"state": "uncertain", "recovery_allowed": False,
                "reason": "This correction is already locked, but its owner is unknown. Inspect the local lock before retrying."}
    # The OS advisory lock has already been acquired by the caller. A valid
    # same-machine release does not require probing a former PID forever: that
    # PID may now be inaccessible or reused by an unrelated protected process.
    # Unreleased, malformed and foreign ownership still needs verification.
    if owner["state"] == "released":
        try:
            released_here = (type(owner.get("pid")) is int and 0 < owner["pid"] <= 0xFFFFFFFF
                and isinstance(owner.get("start"), str) and 0 < len(owner["start"]) <= 200
                and owner.get("host") == _host())
        except ValueError:
            released_here = False
        if released_here:
            return {"state": "absent", "recovery_allowed": False, "reason": "No operation holds this local lock."}
    alive = process_alive(owner)
    if alive is None:
        return {"state": "uncertain", "recovery_allowed": False,
                "reason": "The lock belongs to another or unverifiable local process. Preserve it and inspect its owner."}
    return {"state": "active" if alive else "dead", "recovery_allowed": not alive,
            "reason": "This correction is already being checked or reviewed." if alive else
                      "The original local process has ended. Its lock can be recovered; retained work still needs explicit retry."}


@contextmanager
def _opened(path, checkout, *, create):
    checkout_path = Path(checkout).resolve(strict=True)
    path, checkout = _path(path, checkout)
    created = False
    if create:
        path.parent.mkdir(parents=True, exist_ok=True)
        _path(path, checkout_path)
        try:
            handle = os.open(path, os.O_CREAT | os.O_EXCL | os.O_RDWR, 0o600)
            created = True
        except FileExistsError:
            handle = os.open(path, os.O_RDWR)
    else:
        handle = os.open(path, os.O_RDWR)
    acquired = False
    try:
        _path(path, checkout_path)
        if os.fstat(handle).st_ino != path.stat().st_ino:
            raise ValueError("The local lock file changed while opening it. Retry after reviewing its owner.")
        try:
            _advisory(handle, True)
            acquired = True
        except OSError as error:
            if error.errno in {errno.EACCES, errno.EAGAIN, errno.EDEADLK}:
                raise LockError("This correction is already being checked or reviewed. Refresh after it finishes.", "busy") from None
            raise LockError("The local operating system lock could not be acquired safely.", "os_lock_unavailable") from None
        yield handle, checkout, created
    finally:
        try:
            if acquired:
                _advisory(handle, False)
        finally:
            os.close(handle)


@contextmanager
def locked(path, checkout):
    """Recover only verified dead owners under the same OS lock; preserve journals."""
    with _opened(path, checkout, create=True) as (handle, checkout_id, created):
        previous = _read(handle, checkout_id)
        state = _status(previous)
        if not created and state["state"] not in {"absent", "dead"}:
            raise LockError(state["reason"], "busy" if state["state"] == "active" else "owner_unverifiable")
        try:
            identity = process_identity()
        except ValueError:
            raise LockError("The current local process identity could not be verified.", "identity_unverifiable") from None
        owner = {"version": 1, **identity, "checkout": checkout_id,
                 "state": "held", "token": uuid.uuid4().hex}
        _write(handle, owner)
        try:
            yield dict(owner)
        finally:
            if _read(handle, checkout_id) == owner:
                _write(handle, owner | {"state": "released"})


def lock_status(path, checkout):
    path, _ = _path(path, checkout)
    try:
        with _opened(path, checkout, create=False) as (handle, checkout_id, _):
            return _status(_read(handle, checkout_id))
    except FileNotFoundError:
        return {"state": "absent", "recovery_allowed": False, "reason": "No operation holds this local lock."}
    except ValueError as error:
        return {"state": "active" if "already being" in str(error) else "uncertain",
                "code": getattr(error, "code", "location_unverifiable"),
                "recovery_allowed": False, "reason": str(error)}
    except OSError:
        return {"state": "uncertain", "code": "storage_unavailable", "recovery_allowed": False,
                "reason": "The local lock cannot be inspected safely. Preserve it and review its permissions."}


def recover_lock(path, checkout, *, confirmed=False):
    if confirmed is not True:
        raise ValueError("Review the ended process and confirm recovering its local lock.")
    with _opened(path, checkout, create=False) as (handle, checkout_id, _):
        owner = _read(handle, checkout_id)
        state = _status(owner)
        if state["state"] != "dead":
            raise ValueError(state["reason"])
        _write(handle, owner | {"state": "released"})
    return {"state": "absent", "recovery_allowed": False,
            "reason": "The ended process lock was recovered. Retained work was preserved; review it before retrying."}
