"""The portal's visual identity: one palette, one type pair, and the HTML fragments the page
renders through them. Pure functions and constants — no Streamlit import — so the escaping and
the status vocabulary are tested without a browser (platform/tests/test_portal_theme.py).

WHY A MODULE. Streamlit's defaults read as a stock dashboard, and the operator said so
(2026-09-03). The identity lives in two places: `.streamlit/config.toml` (the theme Streamlit
applies to its own widgets) and the CSS here (the sidebar as a navigation rail, the type pair, the
metric cards, the gate pills). Semantic colours for gate status are separate from the accent, so
the accent never has to mean "good": complete, in progress, not started and blocked each carry
their own colour and their own word — never colour alone.
"""
from __future__ import annotations

import html

# GSK WHITE AND ORANGE (operator, 2026-09-03). The brand orange is the ONE accent — the active
# section, links, focus — on a white ground with dark-grey ink. Gate status keeps its own semantic
# colours, and amber is kept visibly distinct from the brand orange so "in progress" never reads
# as a highlight: every pill also carries its word.
PALETTE = {
    "ground": "#FFFFFF",        # the page
    "surface": "#FFFFFF",       # cards, tables, messages
    "ink": "#2B2B2B",           # text (GSK dark grey)
    "muted": "#6B6B6B",         # captions, labels
    "line": "#E5E5E5",          # hairlines
    "rail": "#FFFFFF",          # the sidebar — white, with an orange edge
    "rail_ink": "#2B2B2B",      # sidebar text
    "rail_muted": "#6B6B6B",    # sidebar captions
    "rail_hover": "#FFF1EA",    # a section under the pointer: a pale orange wash
    "rail_line": "#E5E5E5",     # sidebar hairlines and control borders
    "rail_field": "#FAFAFA",    # sidebar select background
    "accent": "#F36633",        # GSK orange
    "accent_ink": "#FFFFFF",    # text on the accent
    "complete": "#1E8E5A",
    "in_progress": "#B8860B",   # amber, deliberately darker than the brand orange
    "not_started": "#8A97A3",
    "blocked": "#B3261E",
}

STATUS_STYLE = {                # gate status -> (colour key, label shown); status.py's own words included
    "complete": ("complete", "complete"),
    "done": ("complete", "done"),
    "in progress": ("in_progress", "in progress"),
    "approved, awaiting promotion": ("in_progress", "approved, awaiting promotion"),
    "awaiting a named approval": ("in_progress", "awaiting a named approval"),
    "not started": ("not_started", "not started"),
    "blocked": ("blocked", "blocked"),
    "cannot complete": ("blocked", "cannot complete"),
}

FONTS_URL = ("https://fonts.googleapis.com/css2?family=IBM+Plex+Sans:wght@400;500;600"
             "&family=IBM+Plex+Mono:wght@400;500&display=swap")


TOP_CLEARANCE = ".block-container{padding-top:3.5rem !important;}"


def css() -> str:
    """The style block injected once per page. Every colour comes from PALETTE; the two faces
    fall back to the system stack when the font host is unreachable (an offline GSK laptop).
    Emitted WITHOUT blank lines: Streamlit's markdown renderer ends an HTML block at a blank
    line, and everything after the first one inside <style> was printed on the page as text."""
    return "\n".join(l for l in _css_source().splitlines() if l.strip()).replace("</style>", TOP_CLEARANCE + "</style>", 1)


def _css_source() -> str:
    p = PALETTE
    return f"""
<link rel="stylesheet" href="{FONTS_URL}">
<style>
:root {{ --rwdp-ground:{p['ground']}; --rwdp-surface:{p['surface']}; --rwdp-ink:{p['ink']};
        --rwdp-muted:{p['muted']}; --rwdp-line:{p['line']}; --rwdp-rail:{p['rail']};
        --rwdp-rail-ink:{p['rail_ink']}; --rwdp-rail-muted:{p['rail_muted']};
        --rwdp-rail-hover:{p['rail_hover']}; --rwdp-rail-line:{p['rail_line']};
        --rwdp-rail-field:{p['rail_field']}; --rwdp-accent:{p['accent']};
        --rwdp-accent-ink:{p['accent_ink']}; }}
html, body, [data-testid="stAppViewContainer"], .stMarkdown, .stCaption, button, input, textarea {{
  font-family: "IBM Plex Sans", "Segoe UI", system-ui, -apple-system, sans-serif; }}
code, pre, .stCode, [data-testid="stCode"] {{ font-family: "IBM Plex Mono", Consolas, "Courier New", monospace; }}
h1, h2, h3 {{ font-weight: 600; letter-spacing: -0.01em; text-wrap: balance; color: var(--rwdp-ink); }}
.block-container {{ padding-top: 1.4rem; padding-bottom: 5rem; max-width: 1180px; }}
/* The working form and its assistant share a row on laptop/desktop screens. */
.block-container:has(.st-key-rwd_workspace_layout) {{ max-width: 1720px; padding-left: 2rem; padding-right: 2rem; }}
.st-key-rwd_workspace_layout {{ container: rwd-workspace / inline-size; }}
.st-key-rwd_workspace_layout > [data-testid="stLayoutWrapper"] > [data-testid="stHorizontalBlock"] {{ align-items: flex-start; }}
.st-key-rwd_assistant_dock {{ min-width: 0; }}
.st-key-rwd_assistant_dock [data-testid="stChatMessage"] {{ padding: 0.65rem; }}
.st-key-rwd_assistant_dock [data-testid="stChatMessage"] p {{ overflow-wrap: anywhere; }}
@container rwd-workspace (min-width: 760px) {{
  .st-key-rwd_workspace_layout > [data-testid="stHorizontalBlock"] > [data-testid="stColumn"]:last-child,
  .st-key-rwd_workspace_layout > [data-testid="stLayoutWrapper"] > [data-testid="stHorizontalBlock"] > [data-testid="stColumn"]:last-child {{
    position: sticky; top: 1rem; max-height: calc(100vh - 2rem); overflow-y: auto;
  }}
}}
@container rwd-workspace (max-width: 759px) {{
  .st-key-rwd_workspace_layout > [data-testid="stHorizontalBlock"],
  .st-key-rwd_workspace_layout > [data-testid="stLayoutWrapper"] > [data-testid="stHorizontalBlock"] {{ flex-wrap: wrap; }}
  .st-key-rwd_workspace_layout > [data-testid="stHorizontalBlock"] > [data-testid="stColumn"],
  .st-key-rwd_workspace_layout > [data-testid="stLayoutWrapper"] > [data-testid="stHorizontalBlock"] > [data-testid="stColumn"] {{
    flex: 1 1 100%; width: 100%; min-width: 0;
  }}
}}

/* the sidebar is a navigation rail */
[data-testid="stSidebar"] {{ background: var(--rwdp-rail); border-right: 4px solid var(--rwdp-accent); }}
[data-testid="stSidebar"] * {{ color: var(--rwdp-rail-ink); }}
[data-testid="stSidebar"] h1 {{ font-size: 1.1rem; letter-spacing: 0.08em; text-transform: uppercase;
                               color: var(--rwdp-accent); margin-bottom: 0.2rem; }}
[data-testid="stSidebar"] [data-testid="stCaptionContainer"] p {{ color: var(--rwdp-rail-muted); font-size: 0.78rem; }}
[data-testid="stSidebar"] [role="radiogroup"] label {{ padding: 0.35rem 0.6rem; border-radius: 6px;
                               margin: 1px 0; display: flex; }}
[data-testid="stSidebar"] [role="radiogroup"] label:hover {{ background: var(--rwdp-rail-hover); }}
[data-testid="stSidebar"] [role="radiogroup"] label[data-checked="true"],
[data-testid="stSidebar"] [role="radiogroup"] label:has(input:checked) {{ background: var(--rwdp-accent); }}
[data-testid="stSidebar"] [role="radiogroup"] label:has(input:checked) * {{ color: var(--rwdp-accent-ink) !important; }}
[data-testid="stSidebar"] [data-baseweb="select"] > div {{ background: var(--rwdp-rail-field); border-color: var(--rwdp-rail-line); }}
[data-testid="stSidebar"] [data-baseweb="select"] div, [data-testid="stSidebar"] [data-baseweb="select"] span,
[data-testid="stSidebar"] [data-baseweb="select"] svg {{ color: var(--rwdp-rail-ink) !important; fill: var(--rwdp-rail-ink); }}
[data-testid="stSidebar"] [data-baseweb="popover"] li {{ color: var(--rwdp-ink) !important; }}
[data-testid="stSidebar"] hr {{ border-color: var(--rwdp-rail-line); }}
a, [data-testid="stMarkdown"] a {{ color: var(--rwdp-accent); }}
[data-testid="stChatInput"] {{ border-color: var(--rwdp-accent); }}

/* header strip and metric cards */
.rwdp-strip {{ display: flex; align-items: baseline; gap: 0.8rem; margin-bottom: 0.6rem; }}
.rwdp-strip .pack {{ font-family: "IBM Plex Mono", Consolas, monospace; font-size: 0.95rem;
                     color: var(--rwdp-muted); }}
.rwdp-strip .role {{ font-size: 0.78rem; color: var(--rwdp-muted); text-transform: uppercase;
                     letter-spacing: 0.06em; }}
[data-testid="stMetric"] {{ background: var(--rwdp-surface); border: 1px solid var(--rwdp-line);
                            border-radius: 10px; padding: 0.7rem 0.9rem; }}
[data-testid="stMetricLabel"] p {{ color: var(--rwdp-muted); font-size: 0.78rem; text-transform: uppercase;
                                   letter-spacing: 0.06em; }}
[data-testid="stMetricValue"] {{ font-variant-numeric: tabular-nums; color: var(--rwdp-ink); }}

/* gate pills and table */
.rwdp-pill {{ display: inline-block; padding: 0.12rem 0.55rem; border-radius: 999px; font-size: 0.78rem;
              font-weight: 500; color: var(--rwdp-accent-ink); white-space: nowrap; }}
.rwdp-gates {{ width: 100%; border-collapse: collapse; background: var(--rwdp-surface);
               border: 1px solid var(--rwdp-line); border-radius: 10px; overflow: hidden; }}
.rwdp-gates th {{ text-align: left; font-size: 0.75rem; text-transform: uppercase; letter-spacing: 0.06em;
                  color: var(--rwdp-muted); padding: 0.55rem 0.8rem; border-bottom: 1px solid var(--rwdp-line); }}
.rwdp-gates td {{ padding: 0.5rem 0.8rem; border-bottom: 1px solid var(--rwdp-line); font-size: 0.9rem;
                  vertical-align: middle; }}
.rwdp-gates tr:last-child td {{ border-bottom: none; }}
.rwdp-gates td.n {{ font-family: "IBM Plex Mono", Consolas, monospace; color: var(--rwdp-muted); width: 3rem; }}
.rwdp-gates td.b {{ font-variant-numeric: tabular-nums; text-align: right; width: 5rem; }}

/* chat */
[data-testid="stChatMessage"] {{ background: var(--rwdp-surface); border: 1px solid var(--rwdp-line);
                                 border-radius: 12px; padding: 0.6rem 0.9rem; }}
[data-testid="stChatInput"] textarea {{ font-family: "IBM Plex Sans", system-ui, sans-serif; }}
[data-testid="stStatusWidget"], [data-testid="stExpander"] {{ border-radius: 10px; }}
.rwdp-strip .badge {{ background: {p['blocked']}; color: #fff; font: 600 11px/1 "IBM Plex Mono", monospace; letter-spacing: .04em; padding: 5px 8px; border-radius: 4px; margin-left: 10px; }}
.rwdp-watermark {{ background: {p['in_progress']}; color: #fff; font: 600 12px/1.4 "IBM Plex Sans", sans-serif; padding: 6px 12px; border-radius: 6px; margin: 0 0 8px 0; }}
.rwdp-stepper {{ display: grid; grid-template-columns: repeat(auto-fit, minmax(110px, 1fr)); gap: 8px; margin: 8px 0 16px 0; }}
.rwdp-stepper .step {{ border-top: 4px solid {p['line']}; padding: 6px 4px 2px 4px; }}
.rwdp-stepper .step-name {{ font: 600 12px/1.3 "IBM Plex Sans", sans-serif; color: {p['ink']}; }}
.rwdp-stepper .step-state {{ font: 500 11px/1.3 "IBM Plex Mono", monospace; }}
.rwdp-stepper .step-why {{ font: 400 11px/1.3 "IBM Plex Sans", sans-serif; color: {p['muted']}; }}
[data-testid="stRadio"] [role="radiogroup"] {{ gap: 0.3rem 0.8rem; flex-wrap: wrap; }}
[data-testid="stVerticalBlockBorderWrapper"] > div {{ border-radius: 12px; }}
[data-testid="stButton"] button, [data-testid="stDownloadButton"] button {{ border-radius: 8px; min-height: 2.65rem; }}
[data-testid="stTextArea"] textarea, [data-testid="stTextInput"] input {{ border: 1px solid {p['line']}; border-radius: 8px; background: {p['rail_field']}; }}
[data-testid="stTextArea"] textarea:focus, [data-testid="stTextInput"] input:focus {{ border-color: {p['accent']}; }}
.rwdp-gates {{ width: 100%; }}

/* the product header: name, badge, the six stages as one strip, the next step */
.rwdp-header {{ background: var(--rwdp-surface); border: 1px solid var(--rwdp-line); border-radius: 12px;
                padding: 0.9rem 1.1rem 0.8rem 1.1rem; margin: 0 0 1rem 0; }}
.rwdp-header .crumbs {{ font-size: 0.78rem; color: var(--rwdp-muted); margin-bottom: 0.15rem; }}
.rwdp-header .crumbs b {{ color: var(--rwdp-ink); font-weight: 500; }}
.rwdp-header .name {{ font-size: 1.35rem; font-weight: 600; letter-spacing: -0.01em; color: var(--rwdp-ink);
                      display: flex; align-items: center; gap: 0.6rem; flex-wrap: wrap; }}
.rwdp-header .badge {{ font: 600 10px/1.2 "IBM Plex Sans", sans-serif; letter-spacing: .04em; text-transform: uppercase; color: {p['blocked']}; border: 1px solid {p['blocked']}; border-radius: 4px; padding: 3px 6px; }}
.rwdp-header .who {{ font-size: 0.78rem; color: var(--rwdp-muted); margin-left: auto; text-transform: uppercase; letter-spacing: 0.06em; }}
.rwdp-stages {{ display: flex; gap: 0; margin: 0.7rem 0 0.4rem 0; align-items: stretch; }}
.rwdp-stages .stage {{ flex: 1 1 0; position: relative; padding: 0.35rem 0.2rem 0.2rem 0.2rem; text-align: center;
                       border-top: 4px solid {p['line']}; }}
.rwdp-stages .stage .num {{ display: inline-block; width: 1.5rem; height: 1.5rem; line-height: 1.5rem; border-radius: 999px;
                            font: 600 0.78rem/1.5rem "IBM Plex Mono", monospace; color: #fff; background: {p['not_started']}; }}
.rwdp-stages .stage .lbl {{ display: block; font-size: 0.78rem; color: var(--rwdp-muted); margin-top: 0.2rem; }}
.rwdp-stages .stage .st {{ display: block; font-size: 0.7rem; letter-spacing: 0.04em; text-transform: uppercase; color: var(--rwdp-muted); }}
.rwdp-stages .stage.complete {{ border-top-color: {p['complete']}; }}
.rwdp-stages .stage.complete .num {{ background: {p['complete']}; }}
.rwdp-stages .stage.current {{ border-top-color: {p['accent']}; }}
.rwdp-stages .stage.current .num {{ background: {p['accent']}; }}
.rwdp-stages .stage.current .lbl {{ color: var(--rwdp-ink); font-weight: 600; }}
.rwdp-stages .stage.blocked {{ border-top-color: {p['blocked']}; }}
.rwdp-stages .stage.blocked .num {{ background: {p['blocked']}; }}
.rwdp-stages .stage.blocked .lbl {{ color: var(--rwdp-ink); font-weight: 600; }}
.rwdp-header .next {{ margin-top: 0.5rem; font-size: 0.92rem; color: var(--rwdp-ink); }}
.rwdp-header .next .k {{ font-size: 0.72rem; text-transform: uppercase; letter-spacing: 0.06em; color: var(--rwdp-muted); margin-right: 0.5rem; }}
.rwdp-header .next .owner {{ color: var(--rwdp-muted); font-size: 0.82rem; margin-left: 0.5rem; }}
.rwdp-header .checked {{ font-size: 0.74rem; color: var(--rwdp-muted); margin-top: 0.25rem; }}
/* the small strip a Home card carries */
.rwdp-mini {{ display: flex; gap: 3px; margin: 0.35rem 0 0.4rem 0; }}
.rwdp-mini span {{ flex: 1 1 0; height: 6px; border-radius: 3px; background: {p['line']}; }}
.rwdp-mini span.complete {{ background: {p['complete']}; }}
.rwdp-mini span.current {{ background: {p['accent']}; }}
.rwdp-mini span.blocked {{ background: {p['blocked']}; }}
.rwdp-mini-line {{ font-size: 0.82rem; color: var(--rwdp-ink); }}
.rwdp-mini-line .muted {{ color: var(--rwdp-muted); }}
/* the sidebar rail reads as one navigation, not a form */
[data-testid="stSidebar"] [data-testid="stRadio"] > label {{ display: none; }}
[data-testid="stSidebar"] [data-testid="stRadio"] [role="radiogroup"] {{ gap: 0; flex-direction: column; }}
[data-testid="stSidebar"] [data-testid="stRadio"] [role="radiogroup"] label > div:first-child {{ display: none; }}
[data-testid="stSidebar"] [data-testid="stRadio"] [role="radiogroup"] label {{ padding: 0.42rem 0.7rem; margin: 1px 0; font-size: 0.92rem; }}
[data-testid="stSidebar"] .rwdp-navhead {{ font-size: 0.7rem; letter-spacing: 0.08em; text-transform: uppercase; color: var(--rwdp-rail-muted);
                                            margin: 0.6rem 0 0.15rem 0.2rem; }}
[data-testid="stSidebar"] [data-testid="stSelectbox"] > label {{ font-size: 0.74rem; text-transform: uppercase; letter-spacing: 0.06em; color: var(--rwdp-rail-muted); }}
[data-testid="stSidebar"] [data-testid="stButton"] button {{ min-height: 2.3rem; }}
/* cards and section titles */
.rwdp-card-title {{ font-size: 1.05rem; font-weight: 600; margin-bottom: 0.2rem; color: var(--rwdp-ink); }}
.rwdp-card-sub {{ font-size: 0.8rem; color: var(--rwdp-muted); }}
.rwdp-section {{ margin: 0 0 0.6rem 0; }}
.rwdp-section .t {{ font-size: 1.5rem; font-weight: 600; letter-spacing: -0.01em; color: var(--rwdp-ink); }}
.rwdp-section .s {{ font-size: 0.9rem; color: var(--rwdp-muted); margin-top: 0.1rem; }}
[data-testid="stExpander"] details summary p {{ font-size: 0.9rem; }}
@media (max-width: 760px) {{
  .rwdp-stepper {{ grid-template-columns: repeat(2, minmax(0, 1fr)); }}
  .rwdp-strip {{ flex-wrap: wrap; gap: 8px; }}
  .rwdp-stages {{ flex-wrap: wrap; }}
  .rwdp-stages .stage {{ flex: 1 1 30%; }}
  .block-container {{ padding-left: 1rem; padding-right: 1rem; }}
}}
</style>"""


def pill(status: str) -> str:
    """A status pill: colour AND word, HTML-escaped. Unknown statuses render muted, never blank."""
    key, label = STATUS_STYLE.get(str(status or "").strip().lower(), ("not_started", str(status or "unknown")))
    return f'<span class="rwdp-pill" style="background:{PALETTE[key]}">{html.escape(label)}</span>'


def gate_table(gates: list) -> str:
    """The six gates as a table with pills. Every cell is escaped: a gate name or a blocker is
    text from a governance page, and text from a page is never markup."""
    rows = []
    for g in gates or []:
        if not isinstance(g, dict):
            continue
        n = html.escape(str(g.get("gate") if g.get("gate") is not None else ""))
        name = html.escape(str(g.get("name") or ""))
        blockers = g.get("blockers") or []
        rows.append(f'<tr><td class="n">{n}</td><td>{name}</td><td>{pill(g.get("status"))}</td>'
                    f'<td class="b">{len(blockers) if isinstance(blockers, list) else 0}</td></tr>')
    return ('<table class="rwdp-gates"><thead><tr><th>gate</th><th>name</th><th>status</th>'
            '<th>blockers</th></tr></thead><tbody>' + "".join(rows) + "</tbody></table>")


def strip(pack: str, actor_name: str, role: str, badge: str = "") -> str:
    """The header strip: which pack, who, as what — and the PERSISTENT badge a non-product pack
    carries (ninth review: fixtures read as live products). Escaped."""
    b = f'<span class="badge">{html.escape(badge)}</span>' if badge else ""
    return (f'<div class="rwdp-strip"><span class="pack">{html.escape(pack)}</span>{b}'
            f'<span class="role">{html.escape(actor_name)} · {html.escape(role)}</span></div>')


def watermark() -> str:
    """The demo watermark: reference fixtures and synthetic data, nothing here is a product."""
    return ('<div class="rwdp-watermark">DEMO / SYNTHETIC. Reference fixtures and synthetic data. '
            'Nothing shown here is a product, a count of real patients, or a release.</div>')


LIFECYCLE_STATES = {"done": "complete", "open": "in_progress", "blocked": "blocked", "not started": "not_started",
                    # the six gates on the Flow page speak status.py's words; the current gate is the one a person acts on
                    "in progress": "in_progress", "current": "in_progress", "approved, awaiting promotion": "in_progress",
                    "awaiting a named approval": "in_progress", "cannot complete": "blocked"}


def stepper(steps: list) -> str:
    """The product lifecycle as one row of steps, each with its colour AND its word."""
    cells = []
    for s in steps or []:
        key = LIFECYCLE_STATES.get(str(s.get("state") or "not started"), "not_started")
        cells.append(f'<div class="step" style="border-top-color:{PALETTE[key]}">'
                     f'<div class="step-name">{html.escape(str(s.get("name") or ""))}</div>'
                     f'<div class="step-state" style="color:{PALETTE[key]}">{html.escape(str(s.get("state") or ""))}</div>'
                     f'<div class="step-why">{html.escape(str(s.get("why") or ""))}</div></div>')
    return '<div class="rwdp-stepper">' + "".join(cells) + "</div>"


# The six stages (stage_model) as HTML. State words are stage_model's; the CSS class is the word.
_STAGE_WORDS = {"complete": "complete", "current": "current step", "blocked": "blocked", "upcoming": "upcoming", "not checked": "not checked"}


def stages_strip(rows: list) -> str:
    """The six stages as one strip: number, name, state — colour AND word, escaped."""
    cells = []
    for r in rows or []:
        if not isinstance(r, dict):
            continue
        state = str(r.get("state") or "not checked")
        cls = {"complete": "complete", "current": "current", "blocked": "blocked"}.get(state, "")
        cells.append(f'<div class="stage {cls}"><span class="num">{html.escape(str(r.get("gate") or ""))}</span>'
                     f'<span class="lbl">{html.escape(str(r.get("label") or ""))}</span>'
                     f'<span class="st">{html.escape(_STAGE_WORDS.get(state, state))}</span></div>')
    return '<div class="rwdp-stages">' + "".join(cells) + "</div>"


def product_header(label: str, rows: list, *, badge: str = "", actor: str = "", role: str = "", crumb: str = "",
                   next_title: str = "", next_owner: str = "", checked_at: str = "", unchecked_note: str = "") -> str:
    """The card at the top of every product page: where you are, how far the product is, what it
    needs next — the same words the Flow card uses. Every string is escaped."""
    b = f'<span class="badge">{html.escape(badge)}</span>' if badge else ""
    who = f'<span class="who">{html.escape(actor)} · {html.escape(role)}</span>' if actor else ""
    crumbs = f'<div class="crumbs">Home › <b>{html.escape(label)}</b>' + (f' › {html.escape(crumb)}' if crumb else "") + "</div>"
    if next_title:
        nxt = (f'<div class="next"><span class="k">Next step</span>{html.escape(next_title)}'
               + (f'<span class="owner">{html.escape(next_owner)}</span>' if next_owner else "") + "</div>")
    else:
        nxt = f'<div class="next"><span class="k">Next step</span>{html.escape(unchecked_note or "Not checked yet.")}</div>'
    checked = f'<div class="checked">Checked {html.escape(checked_at)}</div>' if checked_at else ""
    return (f'<div class="rwdp-header">{crumbs}<div class="name">{html.escape(label)}{b}{who}</div>'
            f'{stages_strip(rows)}{nxt}{checked}</div>')


def mini_stages(rows: list, line: str = "") -> str:
    """A Home card's six-segment progress strip with its one-line summary, escaped."""
    segs = "".join(f'<span class="{ {"complete": "complete", "current": "current", "blocked": "blocked"}.get(str(r.get("state")), "") }"></span>'
                   for r in rows or [] if isinstance(r, dict))
    return f'<div class="rwdp-mini">{segs}</div>' + (f'<div class="rwdp-mini-line">{html.escape(line)}</div>' if line else "")


def section_title(title: str, sub: str = "") -> str:
    """A page title with its one-line purpose, so every section opens the same way."""
    return f'<div class="rwdp-section"><div class="t">{html.escape(title)}</div>' + (f'<div class="s">{html.escape(sub)}</div>' if sub else "") + "</div>"


def navhead(text: str) -> str:
    return f'<div class="rwdp-navhead">{html.escape(text)}</div>'


def card_title(text: str, rows: list | None = None, line: str = "") -> str:
    """A card's title, optionally with its six-segment stage strip beneath. Escaped."""
    return f'<div class="rwdp-card-title">{html.escape(text)}</div>' + (mini_stages(rows, line) if rows is not None else "")
