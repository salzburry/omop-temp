"""Collect the actual remaining arguments instead of displaying broken placeholders."""
import streamlit as st
import resolution_commands as commands


def render(root, pack, action, actor_id, *, can_view):
    if not can_view:
        return False
    try:
        description = commands.describe(root, pack, action)
    except Exception:
        st.warning("The current command could not be prepared. Check status again.")
        return False
    if not description["available"]:
        return False
    context = (str(root), pack, action["id"], actor_id)
    if st.session_state.get("resolution_command_context") != context:
        for key in list(st.session_state):
            if str(key).startswith("resolution_command_"):
                st.session_state.pop(key, None)
        st.session_state["resolution_command_context"] = context
    st.write("**Run with one complete command**")
    values = {}
    for index, field in enumerate(description["fields"]):
        values[field["name"]] = st.text_input(field["label"], value=field["suggested"], key=f"resolution_command_field_{index}")
    try:
        result = commands.build(root, pack, action, values)
    except commands.Invalid as error:
        st.info(str(error))
        return True
    st.code(result["command"], language="powershell" if commands.os.name == "nt" else "bash")
    st.caption(f"Copy this command into a terminal in {result['environment']}, then return to Check again. The command selects the correct checkout and Python environment for you.")
    return True
