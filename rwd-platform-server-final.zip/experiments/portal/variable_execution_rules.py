"""Pure, bounded translation of explicit reviewed choices into engine settings.

Support describes an existing translation, not approval or successful execution.
No source examples, master values, arbitrary prose or variable-name guesses are
compiled. The caller rechecks the review snapshot and stages these proposals.
"""
from __future__ import annotations

from datetime import date
import math
import re

from engine.stages.treatment import line_cols
import variable_review_consistency as consistency
import variable_review_family as family


MAX_AUTO_LINES = 100
MAX_LINES_REF = "variables/treatment.yaml#/max_lines"
NUMBERING_REF = "config/data_product.yaml#/lot/line_number"
START_REF = "config/data_product.yaml#/study/index_start"
END_REF = "config/data_product.yaml#/study/index_end"
_KINDS = {
    START_REF: "date", END_REF: "date",
    "variables/outcomes.yaml#/min_followup_days": "integer",
    "variables/outcomes.yaml#/visit_recency_days": "integer",
    "variables/outcomes.yaml#/days_per_month": "number",
    MAX_LINES_REF: "positive_integer", NUMBERING_REF: "lot_numbering",
    "config/pipeline.yaml#/run/source_schema": "text",
    "config/pipeline.yaml#/run/refresh": "text",
}
_ALIASES = {"study.index_start": START_REF, "study.index_end": END_REF,
            "treatment.max_lines": MAX_LINES_REF, "lot.line_number": NUMBERING_REF,
            "run.source_schema": "config/pipeline.yaml#/run/source_schema",
            "run.refresh": "config/pipeline.yaml#/run/refresh"}
_ALIASES.update({"outcomes." + name: "variables/outcomes.yaml#/" + name
                 for name in ("min_followup_days", "visit_recency_days", "days_per_month")})
_ATTRIBUTES = {"regimen": "name", "start_date": "start",
               "delivered_end_date": "end", "last_activity_date": "lastdate"}
_MONTHS = {name: n for n, name in enumerate(
    ("jan", "feb", "mar", "apr", "may", "jun", "jul", "aug", "sep", "oct", "nov", "dec"), 1)}


def _normalize(kind, value):
    """Accept explicit unambiguous scalar input, and produce editor-safe types."""
    if kind == "date":
        if type(value) is date:
            return value.isoformat()
        if not isinstance(value, str):
            raise ValueError("Enter a date as YYYY-MM-DD or dd-Mon-YYYY, with a four-digit year.")
        value = value.strip()
        if re.fullmatch(r"\d{4}-\d{2}-\d{2}", value):
            try:
                return date.fromisoformat(value).isoformat()
            except ValueError:
                pass
        match = re.fullmatch(r"(\d{2})-([A-Za-z]{3})-(\d{4})", value)
        if match and match[2].lower() in _MONTHS:
            try:
                return date(int(match[3]), _MONTHS[match[2].lower()], int(match[1])).isoformat()
            except ValueError:
                pass
        raise ValueError("Enter a real calendar date as YYYY-MM-DD or dd-Mon-YYYY, with a four-digit year.")
    if kind in {"integer", "positive_integer"}:
        if isinstance(value, str) and re.fullmatch(r"[0-9]+", value.strip()):
            value = int(value.strip())
        if type(value) is not int or value < (1 if kind == "positive_integer" else 0):
            raise ValueError("Enter a positive whole number." if kind == "positive_integer" else
                             "Enter a non-negative whole number of days.")
        return value
    if kind == "number":
        if isinstance(value, str) and re.fullmatch(r"[+]?(?:\d+(?:\.\d*)?|\.\d+)", value.strip()):
            value = float(value.strip())
        if type(value) not in {int, float} or not math.isfinite(value) or value <= 0:
            raise ValueError("Enter a finite positive number.")
        return value
    if kind == "lot_numbering":
        if value not in ("linenumber", "new_lot_n"):
            raise ValueError("Choose linenumber or new_lot_n for treatment-line numbering.")
        return value
    if kind == "text":
        if not isinstance(value, str) or not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9_.\-]{0,79}", value.strip()) or "REPLACE_ME" in value:
            raise ValueError("Enter a schema or cut name using letters, digits, underscores, dots or hyphens (up to 80 characters).")
        return value.strip()
    raise ValueError("This setting has no supported scalar translation.")


def _type_matches(kind, declared):
    actual = consistency.canonical_type(declared)
    return actual in ({"date"} if kind == "date" else
                      {"integer", "long"} if kind in {"integer", "positive_integer"} else
                      {"integer", "long", "double"} if kind == "number" else {"string"})


def _active(ref, raw):
    relative = ref.split("#/", 1)[0]
    return not relative.startswith("variables/") or relative in raw.get("variables", [])


def build(report, cfg, parameters):
    """Return rows, scalar configuration_changes, structured blockers and warnings.

    Inputs are read-only. In particular, cfg.pack() is never called: it performs
    lazy filesystem reads. Current treatment scope comes from the supplied
    supported_parameters snapshot. Native names are computed one row at a time.
    """
    raw = cfg.raw
    result = {"rows": [], "configuration_changes": [], "blockers": [], "warnings": []}
    proposals = {}  # ref -> [(value, row-result)]; distinct explicit values conflict.
    line_requests = []
    family_numbering = []
    review_blocked = set()

    def block(item, message, ref=None):
        entry = {"item_id": item.get("item_id", ""), "variable_id": item.get("variable_id", ""), "message": message}
        if ref:
            entry["ref"] = ref
        if entry not in result["blockers"]:
            result["blockers"].append(entry)

    def engineering(item, message, ref=None):
        item["status"] = "engineering"
        item["message"] = message
        block(item, message, ref)

    def propose(ref, value, item):
        proposals.setdefault(ref, []).append((value, item))

    def warning(message):
        if message not in result["warnings"]:
            result["warnings"].append(message)

    current_max = parameters.get(MAX_LINES_REF, (None, None, None))[2]
    valid_max = type(current_max) is int and current_max > 0
    numbering = (raw.get("lot") or {}).get("line_number", "new_lot_n")
    for row in sorted(report["rows"], key=lambda row: (row["item_id"], row["variable_id"])):
        item = {"item_id": row["item_id"], "variable_id": row["variable_id"],
                "status": "supported", "engine_column": "", "message": "", "output_updates": {}}
        result["rows"].append(item)
        values = row.get("values") or {}
        source, output = values.get("source") or {}, values.get("output") or {}
        phase_issues = row.get("phase_issues") or {}
        has_review_issues = False
        for phase in sorted(phase_issues):
            for issue in phase_issues[phase]:
                block(item, f"{phase.capitalize()} review: {issue}")
                has_review_issues = True
        for phase, status in sorted((row.get("phase_status") or {}).items()):
            if status != "ready" and not phase_issues.get(phase):
                block(item, f"{phase.capitalize()} review is incomplete. Resolve and check this phase before execution preparation.")
                has_review_issues = True
        if has_review_issues:
            review_blocked.add(item["item_id"])

        # Parameter metadata is executable configuration even when no column is delivered.
        if source.get("kind") == "parameter":
            refs = source.get("parameters")
            if not isinstance(refs, list) or len(refs) != 1 or not isinstance(refs[0], str):
                engineering(item, "Select exactly one supported configuration parameter for this value; multiple references need an implementation handoff.")
                continue
            ref = _ALIASES.get(refs[0], refs[0])
            if ref not in _KINDS or ref not in parameters or not _active(ref, raw):
                engineering(item, "Choose an active supported configuration setting in Sources, or request an implementation handoff.", ref)
                continue
            kind = _KINDS[ref]
            if not _type_matches(kind, output.get("type")):
                engineering(item, f"Choose a data type compatible with the {kind.replace('_', ' ')} configuration value.", ref)
                continue
            try:
                value = _normalize(kind, source.get("value"))
            except (ValueError, TypeError, OverflowError) as error:
                engineering(item, str(error), ref)
                continue
            if ref == MAX_LINES_REF and (not valid_max or value < current_max):
                engineering(item, "The automatic bridge only increases the current treatment-line scope. Review reductions in Configuration.", ref)
                continue
            if ref == MAX_LINES_REF and value > current_max and value > MAX_AUTO_LINES:
                engineering(item, f"A new scope above {MAX_AUTO_LINES} treatment lines needs an engineering review.", ref)
                continue
            if output.get("role") not in {"metadata", "excluded"}:
                engineering(item, "This parameter translates to configuration only. Choose Metadata or Excluded, or request implementation of a delivered value column.", ref)
                continue
            item["message"] = "Explicit product value maps to " + ref + "; it does not emit a data column."
            if not has_review_issues:
                propose(ref, value, item)
            if ref == NUMBERING_REF and not has_review_issues:
                family_numbering.append((value, item))
            continue

        if output.get("role") == "excluded":
            item["message"] = "Excluded from output; no emitted column or new execution setting is required."
            continue
        selected = family.selection(row)
        if not selected:
            engineering(item, "This definition needs an implementation handoff. A familiar output name or free-text rule does not establish an executable mapping.")
            continue
        issues = family.issues(row)
        if issues:
            engineering(item, " ".join(issues))
            continue
        if selected.get("attribute") not in _ATTRIBUTES:
            engineering(item, "Associated diagnoses and custom treatment-line attributes need an implementation handoff; no computation is inferred.")
            continue
        if source.get("kind") != "vendor":
            engineering(item, "The native treatment-line mapping requires the configured LOT vendor input; a derived or other source needs an implementation handoff.")
            continue
        expected_type = family.TYPES[selected["attribute"]]
        if consistency.canonical_type(output.get("type")) != expected_type:
            engineering(item, f"Choose data type {expected_type} for this treatment-line attribute.")
            continue
        if not valid_max or not _active(MAX_LINES_REF, raw):
            engineering(item, "Activate and configure the treatment variable pack before binding its native outputs.", MAX_LINES_REF)
            continue
        line = selected["line_number"]
        if line > current_max and line > MAX_AUTO_LINES:
            engineering(item, f"Line {line} would create a new scope above {MAX_AUTO_LINES} treatment lines; request an engineering review.", MAX_LINES_REF)
            continue
        chosen_numbering = selected["numbering"]
        if not has_review_issues:
            family_numbering.append((chosen_numbering, item))
        if NUMBERING_REF not in parameters and chosen_numbering != numbering:
            engineering(item, "The selected numbering has no supported configuration editor for this product.", NUMBERING_REF)
            continue
        native = line_cols(line)[_ATTRIBUTES[selected["attribute"]]]
        item["engine_column"] = native
        item["message"] = f"Explicit treatment-line choices map to native column {native}. Configuration and execution checks still apply."
        if str(output.get("physical_name") or "").strip().casefold() != native:
            item["status"] = "needs_output_binding"
            item["output_updates"] = {"output.physical_name": native}
            item["message"] = (f"Choose native physical column {native} to bind this definition. The reviewed published name is retained as metadata; "
                               "it does not rename the engine column. A different physical name needs an implementation handoff.")
            block(item, f"Choose whether to bind the physical output to {native}; the current name is not emitted by this rule.")
        projection = (raw.get("publication") or {}).get("columns")
        if isinstance(projection, list) and native not in {str(name).casefold() for name in projection}:
            engineering(item, f"Native column {native} is excluded by publication.columns. Review the publication list in Configuration; this bridge does not replace it.")
        if not has_review_issues:
            line_requests.append((line, item))
            if NUMBERING_REF in parameters:
                propose(NUMBERING_REF, chosen_numbering, item)

    # Numbering is shared with cohort indexing and outcomes, never per variable.
    if family_numbering:
        warning("Treatment-line numbering is a product-wide setting used by cohort indexing, treatment and outcomes. Review its impact on every line-dependent variable.")
        if len({value for value, _item in family_numbering}) > 1:
            block({}, "Treatment-line definitions request conflicting product-wide numbering. Choose one numbering model for the product.", NUMBERING_REF)
            proposals.pop(NUMBERING_REF, None)
            for _value, item in family_numbering:
                engineering(item, "Resolve the conflicting product-wide treatment-line numbering.", NUMBERING_REF)

    if line_requests:
        required = max(line for line, _item in line_requests)
        explicit = proposals.get(MAX_LINES_REF, [])
        if explicit and any(value < required for value, _item in explicit):
            block({}, "The explicit maximum treatment line is below a reviewed output's required line. Resolve the scope conflict.", MAX_LINES_REF)
            proposals.pop(MAX_LINES_REF, None)
            for _value, item in explicit + line_requests:
                engineering(item, "Resolve the conflict between the maximum treatment line and the reviewed line outputs.", MAX_LINES_REF)
        elif required > current_max and not explicit:
            propose(MAX_LINES_REF, required, next(item for line, item in line_requests if line == required))

    for ref in sorted(proposals):
        entries = proposals[ref]
        values = []
        for value, _item in entries:
            if value not in values:
                values.append(value)
        if len(values) > 1:
            block({}, "Reviewed variables request conflicting values for " + ref + ". Resolve this setting before staging.", ref)
            for _value, item in entries:
                engineering(item, "Resolve the conflicting values for this configuration setting.", ref)
            continue
        value = entries[0][0]
        try:
            current = _normalize(_KINDS[ref], parameters[ref][2])
        except (ValueError, TypeError, OverflowError):
            current = parameters[ref][2]
        if value != current:
            result["configuration_changes"].append({"ref": ref, "value": value})
            if ref == MAX_LINES_REF:
                warning(f"Increasing treatment scope to {value} emits the engine's native line fields through that line, including attributes beyond this reviewed list.")

    # A valid scalar date is insufficient if the combined cohort interval is reversed.
    changes = {item["ref"]: item["value"] for item in result["configuration_changes"]}
    if START_REF in changes or END_REF in changes:
        try:
            start = _normalize("date", changes.get(START_REF, parameters.get(START_REF, (None, None, None))[2]))
            end = _normalize("date", changes.get(END_REF, parameters.get(END_REF, (None, None, None))[2]))
            if start > end:
                block({}, "Study index start is after index end. Resolve the product date interval before staging.", START_REF)
                result["configuration_changes"] = [item for item in result["configuration_changes"] if item["ref"] not in {START_REF, END_REF}]
                for ref in (START_REF, END_REF):
                    for _value, item in proposals.get(ref, []):
                        engineering(item, "Resolve the study index date interval before staging.", ref)
        except (ValueError, TypeError):
            block({}, "The complete study date interval cannot be validated. Check both index dates in Configuration.", START_REF)
            result["configuration_changes"] = [item for item in result["configuration_changes"] if item["ref"] not in {START_REF, END_REF}]
            for ref in (START_REF, END_REF):
                for _value, item in proposals.get(ref, []):
                    engineering(item, "Check both study index dates before staging.", ref)
    for item in result["rows"]:
        if item["item_id"] in review_blocked:
            if item["status"] == "supported":
                item["status"] = "engineering"
            item["message"] += " Resolve the current review issues before execution preparation."
    return result
