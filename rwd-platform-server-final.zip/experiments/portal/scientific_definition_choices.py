"""Explicit answer choices that remain literal, editable scientific drafts."""

PREFIX = "scientific_definition_field_"
CUSTOM = "Write my own answer"
UNSURE = "Not sure yet"
NA = "Does not apply — explain why"
TEXT_FIELDS = {
    "derivation": ("Scientific interpretation", "The rule you propose to implement. Illustrative example: use the closest recorded assessment within the stated window. Leave TODO where the scientific owner still needs to decide."),
    "grain": ("One value per", "The identifiers defining one output row. Illustrative example: [patientid, index_date, cohortn]."),
    "anchor": ("Reference date or event", "What timing is measured from. Illustrative example: index_date. Use n/a when timing does not apply."),
    "window": ("Time window", "Bounds and whether they are included. Illustrative example: 30 days before through 7 days after index, inclusive."),
    "record_selection": ("Which source record to use", "What to do when several records qualify. Illustrative example: closest assessment to index_date."),
    "tie_break": ("How to resolve ties", "How equally suitable records are resolved. Illustrative example: prefer the earlier date when two assessments are equally distant; use the highest value on the same day."),
    "missing": ("Missing-value handling", "Distinguish no record from a missing value. Illustrative example: output null when no assessment qualifies or the selected value is null; do not substitute zero."),
    "cohort_applicability": ("Applicable populations or cohorts", "Which shared-product populations use this definition. Illustrative example: all defined cohorts. Study-only exclusions belong in Plan changes."),
    "units": ("Units", "The measurement unit. Illustrative example: mg/day for daily dose, or n/a for a category."),
    "acceptance": ("Worked example and expected result", "Concrete inputs and their expected answer. Illustrative example: assessments at index-3 days with value 1 and index+6 days with value 2 produce value 1 under a closest-date rule."),
    "notes": ("Rationale and unresolved questions", "Why you chose the rule and what needs review. Illustrative example: confirm the same-day tie rule with the scientific owner. Use n/a when no additional notes apply."),
}

CHOICES = {
    "grain": {
        "One per delivery": "One value for the entire data delivery.",
        "One per patient": "One value per patient.",
        "One per patient and cohort": "One value per patient and product cohort.",
        "One per source event": "One value per qualifying source event.",
    },
    "anchor": {
        "Study index date": "The study index date.",
        "Treatment start date": "The treatment start date.",
        "Source event date": "The date of the source event.",
        "Data delivery date": "The data delivery date.",
    },
    "window": {
        "On the reference date": "On the reference date only.",
        "On or before it": "On or before the reference date, inclusive; no lower date bound.",
        "On or after it": "On or after the reference date, inclusive; no upper date bound.",
    },
    "record_selection": {
        "Earliest qualifying record": "Use the earliest qualifying record by the stated date field.",
        "Latest qualifying record": "Use the latest qualifying record by the stated date field.",
        "Closest to the reference date": "Use the qualifying record closest to the reference date.",
    },
    "tie_break": {
        "Flag the tie for resolution": "Report an unresolved-tie finding; do not select a record arbitrarily.",
        "Earlier date, then flag remaining ties": "Prefer the earlier date; report an unresolved-tie finding if records remain tied.",
        "Later date, then flag remaining ties": "Prefer the later date; report an unresolved-tie finding if records remain tied.",
    },
    "missing": {
        "Leave the result missing": "Output null if no qualifying record exists or the selected record has a missing value; do not substitute zero.",
        "Stop and report the missing data": "Stop the affected build and report a data issue if no qualifying record exists or the selected record has a missing value.",
    },
    "cohort_applicability": {"All product cohorts": "All defined product cohorts."},
    "units": {"Days": "days", "Months": "months", "Years": "years", "Percent": "percent"},
}


def render(field, label, raw, help_text, *, binding=None):
    """Retain custom answers across selection changes, rows and resumable drafts."""
    import streamlit as st
    import form_assistance as form_help
    key = PREFIX + field
    mode_key = key + "_choice"
    previous_key = key + "_previous_choice"
    custom_key = key + "_custom_answer"
    na_key = key + "_not_applicable_answer"
    values = CHOICES[field]
    current = st.session_state.get(key, raw)
    unanswered = not str(current).strip() or str(current).strip() == "TODO"
    if key not in st.session_state:
        st.session_state[key] = "" if unanswered else current
    if mode_key not in st.session_state:
        # Exact existing answers can be displayed as choices; never infer a
        # scientific answer from a similar phrase or the specification label.
        matched = next((option for option, value in values.items() if value == current), None)
        mode = None if unanswered else matched or CUSTOM
        st.session_state[mode_key] = mode
        st.session_state[previous_key] = mode
    options = [*values, CUSTOM, UNSURE]
    if field != "grain":
        options.append(NA)

    def changed():
        old_mode = st.session_state.get(previous_key)
        old_value = st.session_state.get(key, "")
        if old_mode == CUSTOM:
            st.session_state[custom_key] = old_value
        elif old_mode == NA:
            st.session_state[na_key] = old_value
        mode = st.session_state[mode_key]
        if mode is None and str(old_value).strip() not in ("", "TODO"):
            # Clearing a dropdown is not consent to discard authored text.
            mode = CUSTOM
            st.session_state[mode_key] = mode
            st.session_state[custom_key] = old_value
        if mode == CUSTOM:
            st.session_state[key] = st.session_state.get(custom_key, "" if old_value == "TODO" else old_value)
        elif mode == NA:
            st.session_state[key] = st.session_state.get(na_key, "n/a — TODO: explain why this does not apply.")
        elif mode == UNSURE:
            st.session_state[key] = "TODO"
        elif mode in values:
            st.session_state[key] = values[mode]
        st.session_state[previous_key] = mode

    choice = form_help.field(st.selectbox, label, options, index=None, key=mode_key, on_change=changed, binding=binding,
                          placeholder="Choose an answer or write your own", help=help_text)
    if choice in (CUSTOM, NA):
        form_help.field(st.text_area, "Your answer: " + label, key=key, help=help_text, height=100, binding=binding,
                     placeholder="Write the rule in your own words")
        if choice == NA:
            st.caption("Explain why this question does not apply. An unanswered reason stays unresolved.")
    elif choice == UNSURE:
        st.caption("Left unresolved. Save this draft and return to the question with your study team.")
    elif choice in values:
        st.caption("Draft answer: " + str(st.session_state[key]))
        def edit():
            st.session_state[custom_key] = st.session_state[key]
            st.session_state[mode_key] = CUSTOM
            st.session_state[previous_key] = CUSTOM
        st.button("Edit this answer", key=key + "_edit", on_click=edit)
