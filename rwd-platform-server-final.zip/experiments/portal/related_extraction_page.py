"""Inspect a typed specification snapshot and its explicit object relationships."""
from __future__ import annotations

import json
from pathlib import Path

import streamlit as st

import related_extraction_workspace as backend


PREFIX = "related_extraction_"


def clear():
    for key in list(st.session_state):
        if str(key).startswith(PREFIX):
            st.session_state.pop(key, None)


def _text(value):
    if value is None:
        return ""
    if isinstance(value, (dict, list, tuple)):
        return json.dumps(value, ensure_ascii=False, default=str)
    return str(value)


def _label(item):
    return f"{item.get('type', 'Record')} · {item.get('key') or item.get('id', '')}"


def _citation_rows(citations):
    return [{"Specification row": _text(item.get("item_id")), "Sheet": _text(item.get("tab")),
             "Row": _text(item.get("row")), "Field": _text(item.get("field"))}
            for item in citations or []]


def _show_report(report):
    objects = report.get("objects") or []
    links = report.get("relationships") or []
    issues = report.get("issues") or []
    by_id = {item["id"]: item for item in objects}
    counts = report.get("counts") or {}
    st.caption(f"{len(objects)} records · {len(links)} relationships · "
               f"{counts.get('resolved', sum(link.get('status') == 'resolved' for link in links))} resolved relationships")
    if issues:
        st.warning(f"{len(issues)} structure finding{'s' if len(issues) != 1 else ''} to review.")
        st.dataframe([{"Finding": _text(issue.get("message")),
                       "Record": _label(by_id[issue["object_id"]]) if issue.get("object_id") in by_id else "",
                       "Specification row": _text(issue.get("item_id")), "Field": _text(issue.get("field")),
                       "Severity": _text(issue.get("severity"))} for issue in issues],
                     hide_index=True, width="stretch")
    elif report.get("valid"):
        st.success("No structure findings in this source extraction snapshot.")
    else:
        st.warning("This source extraction snapshot did not pass its structure checks.")
    st.caption("Structure checks do not settle scientific decisions. Review definitions and product values in the variable review.")
    if not objects:
        st.info("No typed specification records were found. Check the workbook sheet mapping and extraction.")
    else:
        issue_ids = {issue.get("object_id") for issue in issues}
        ordered = sorted(objects, key=lambda item: (item["id"] not in issue_ids, _label(item).casefold()))
        options = [item["id"] for item in ordered]
        if st.session_state.get(PREFIX + "object") not in options:
            st.session_state[PREFIX + "object"] = options[0]
        selected = st.selectbox("Inspect a specification record", options, key=PREFIX + "object",
                                format_func=lambda value: _label(by_id[value]))
        item = by_id[selected]
        fields, raw = item.get("fields") or {}, item.get("raw_fields") or {}
        st.dataframe([{"Field": field, "Specification text": _text(raw.get(field)),
                       "Parsed value": _text(fields.get(field))} for field in dict.fromkeys([*raw, *fields])],
                     hide_index=True, width="stretch")
        if item.get("citations"):
            st.caption("Original specification citations")
            st.dataframe(_citation_rows(item["citations"]), hide_index=True, width="stretch")
        related = [link for link in links if selected in (link.get("source_id"), link.get("target_id"))]
        if related:
            st.caption("Related records")
            st.dataframe(_link_rows(related, by_id), hide_index=True, width="stretch")
        item_ids = list(dict.fromkeys(citation["item_id"] for citation in item.get("citations") or []
                                     if citation.get("item_id")))
        variable_rows = {citation["item_id"] for variable in objects
                         if str(variable.get("type", "")).casefold() == "variable"
                         for citation in variable.get("citations") or [] if citation.get("item_id")}
        if len(item_ids) == 1 and item_ids[0] in variable_rows:
            if st.button("Review this variable", key=PREFIX + "review"):
                return {"route": "variable_review", "params": {"phase": "science", "item_id": item_ids[0]}}
        with st.expander("All specification records and relationships"):
            st.dataframe([{"Record": _label(item), "ID": item["id"],
                           "Specification row": ", ".join(dict.fromkeys(str(citation.get("item_id", ""))
                               for citation in item.get("citations") or []))} for item in objects],
                         hide_index=True, width="stretch")
            if links:
                st.dataframe(_link_rows(links, by_id), hide_index=True, width="stretch")
    st.download_button("Download structure report", json.dumps(report, indent=2, ensure_ascii=False, default=str),
                       file_name="specification-structure.json", mime="application/json", key=PREFIX + "download")
    return None


def _link_rows(links, by_id):
    return [{"From": _label(by_id[link["source_id"]]) if link.get("source_id") in by_id else _text(link.get("source_id")),
             "Relationship": _text(link.get("kind")),
             "To": _label(by_id[link["target_id"]]) if link.get("target_id") in by_id else _text(link.get("reference")),
             "Status": _text(link.get("status")),
             "Possible matches": ", ".join(_label(by_id[candidate]) if candidate in by_id else str(candidate)
                                            for candidate in link.get("candidates") or [])} for link in links]


def render(root, pack, actor_id, *, can_view=True, allowed_packs=None):
    """Return a review navigation request; inspect only after an explicit check."""
    if not can_view:
        clear()
        return None
    allowed_packs = [pack] if allowed_packs is None else allowed_packs
    owner = (str(Path(root).resolve()), pack, actor_id, tuple(sorted(allowed_packs)))
    old_owner = st.session_state.get(PREFIX + "owner")
    if old_owner != owner:
        clear()
        st.session_state[PREFIX + "owner"] = owner
    current = backend.describe(root, pack, actor_id, allowed_packs=allowed_packs)
    digest = current.get("input_digest")
    previous = st.session_state.get(PREFIX + "digest")
    changed = previous is not None and previous != digest
    if changed or not current.get("ok"):
        st.session_state.pop(PREFIX + "preview", None)
        st.session_state.pop(PREFIX + "object", None)
    st.session_state[PREFIX + "digest"] = digest
    with st.expander("Variables and related specification records"):
        st.caption("Inspect variables, product values, time windows and their explicit links in the extracted specification.")
        if current.get("notice"):
            st.caption(str(current["notice"]))
        if changed:
            st.info("The specification or structure schema changed. Check again to see the current records.")
        if not current.get("ok"):
            for error in current.get("errors") or ["The current specification snapshot could not be read."]:
                st.info(str(error))
            return None
        if st.button("Check specification structure", key=PREFIX + "check"):
            with st.spinner("Checking specification records and relationships…"):
                result = backend.preview(root, pack, actor_id, expected_digest=digest, allowed_packs=allowed_packs)
            st.session_state.pop(PREFIX + "object", None)
            if result.get("ok") and result.get("input_digest") != digest:
                result = {"ok": False, "errors": ["The specification changed during the check. Check again to see current records."]}
            st.session_state[PREFIX + "preview"] = result
        checked = st.session_state.get(PREFIX + "preview")
        if checked:
            if not checked.get("ok"):
                for error in checked.get("errors") or ["The specification structure could not be checked."]:
                    st.error(str(error))
            elif isinstance(checked.get("report"), dict):
                return _show_report(checked["report"])
        else:
            st.caption("Run this check when you want to inspect the current extraction. It does not save changes or run an AI model.")
    return None
