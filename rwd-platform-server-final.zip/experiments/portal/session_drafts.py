"""Preserve a scientist's form across Streamlit widget cleanup without sharing it with another actor."""
from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path
import re
from datetime import datetime, timezone

import design_workspace as dw

FIELDS = {"np_mode", "np_slug", "np_ver", "np_name", "np_code", "np_family", "np_area", "np_vendor",
          "np_modality", "np_tclass", "np_narrow", "np_cond", "np_terms", "np_old", "np_cls",
          "np_note", "np_ai", "np_by", "np_on", "np_excluded_sheets", "np_excluded_sheets_reason",
          "np_sheet_scope_binding", "np_sheet_scope_hint", "np_sheet_scope_hint_mode"}


def _field(key):
    # a file uploader's key is never a draft field: Streamlit refuses to have its value set from
    # session state, and re-assigning it crashed the New product page (walk UC1-01, 2026-09-07)
    if key.endswith("_upload"):
        return False
    return key in FIELDS or key.startswith(("np_wb", "design_"))


def preserve(state, actor):
    """Called before widgets: self-assignment keeps values when their page is not rendered.

    Button state and preview authorization are never restored. Actor changes discard preview
    and flow action results; drafts are private to the actor within this browser session only.
    """
    completed = state.pop("_completed_setup_actor", None)
    if completed is not None:
        saved = state.get("_form_drafts", {}).get(completed, {})
        for key in list(saved):
            if str(key).startswith("np_"):
                del saved[key]
        if completed == state.get("_draft_actor", actor):
            for key in list(state):
                if str(key).startswith("np_") and key != "np_flash":
                    del state[key]
    previous = state.get("_draft_actor", actor)
    drafts = state.setdefault("_form_drafts", {})
    saved = drafts.setdefault(previous, {})
    for key in list(state):
        if _field(str(key)):
            saved[key] = state[key]
            if previous != actor:
                del state[key]
    if previous != actor:
        for key in list(state):
            if str(key).startswith(("spec_details_", "decision_answer_")):
                state.pop(key, None)
        for key in ("np_previewed", "np_flash", "flow_result", "flow_output", "studies_flash",
                    "flow_dialog", "flow_dialog_feedback", "flow_feedback", "flow_resolution_action",
                    "portal_document", "portal_document_history",
                    "np_slug_suggested", "np_mode_suggested", "np_family_suggested", "np_code_suggested", "study_new_id",
                    "pack_suggested", "section_suggested"):
            state.pop(key, None)
    current = drafts.setdefault(actor, {})
    for key, value in current.items():
        state[key] = value
    state["_draft_actor"] = actor


# This is the registration form's private continuation, not a product record.
# Workbook controls and declarations must be supplied again against current files.
SETUP_FIELDS = {"np_mode", "np_slug", "np_ver", "np_name", "np_code", "np_family", "np_area", "np_vendor",
                "np_modality", "np_tclass", "np_narrow", "np_cond", "np_terms", "np_old", "np_note"}
SETUP_LABELS = {"np_mode": "Starting point", "np_slug": "Product slug", "np_ver": "Specification cut",
    "np_area": "Product folder group",
    "np_name": "Display name", "np_code": "Registry code", "np_family": "Tumour family", "np_vendor": "Vendor",
    "np_modality": "Data modality", "np_tclass": "Tumour class", "np_narrow": "Catalogue axis",
    "np_cond": "Condition class", "np_terms": "Disease names", "np_old": "Previous cut", "np_note": "Changelog note"}
SETUP_NOTICE = ("Private unfinished setup only. Re-select the workbook and make access, classification and author/date "
                "declarations again. Saved sheet sections and exclusions can be reviewed after selecting the same workbook. "
                "Resuming does not create a product, call an assistant, validate, approve or release anything.")
MAX_SETUP_BYTES = 80_000


def setup_choices(root, allowed_packs):
    """The existing registration vocabularies, shared by restore and the widgets."""
    import ui_text as ui
    import oncology_registry as oncology
    import product_gates as gates
    import spec_lint
    policy, error = gates.read_yaml(str(Path(root) / "governance/vendor_policy.yaml"))
    if (error or not isinstance(policy, dict) or not isinstance(policy.get("vendors"), dict)
            or not policy["vendors"] or any(not isinstance(name, str) or not name.strip()
                or not isinstance(value, dict) for name, value in policy["vendors"].items())):
        raise ValueError("The vendor policy is unreadable or has invalid vendor entries. Repair the current checkout's vendor catalogue before setting up a product.")
    vendors = sorted(policy["vendors"])
    registry, error = gates.read_yaml(str(Path(root) / "products/registry.yaml"))
    if (error or not isinstance(registry, dict) or not isinstance(registry.get("tumors"), list)
            or any(not isinstance(row, dict) or not isinstance(row.get("slug"), str) or not row["slug"].strip()
                   for row in registry["tumors"])):
        raise ValueError("The product registry is unreadable or has invalid product entries. Repair the current checkout's registry before setting up a product.")
    cuts = sorted(f"products/{row.get('family') or 'oncology'}/{row['slug']}/{row.get('current_spec_version')}"
        for row in registry["tumors"])
    try:
        families = sorted(spec_lint.load_tumour_registry(root)["families"])
    except SystemExit as error:
        raise ValueError(str(error)) from None
    return {"np_mode": list(ui.NEW_PRODUCT_MODES), "np_family": families, "np_area": ["oncology", "heme"],
        "np_vendor": vendors, "np_modality": list(gates.MODALITIES), "np_tclass": ["solid", "heme"],
        "np_narrow": list(oncology.NARROW), "np_cond": list(ui.CONDITION_CLASS_WORDS), "np_old": [p for p in cuts if p in allowed_packs]}


def history_key(root, actor):
    owner = hashlib.sha256((str(root) + "\0" + actor).encode()).hexdigest()[:20]
    return f"flow_assistant_history_{owner}_"


def _setup_scope(root, actor, allowed_packs):
    root = Path(root).resolve(strict=True)
    if not isinstance(actor, str) or not actor.strip() or len(actor) > 300 or any(ord(c) < 32 for c in actor):
        raise ValueError("Choose the current editing identity before saving setup.")
    if not isinstance(allowed_packs, (list, tuple, set)) or any(not isinstance(p, str) for p in allowed_packs):
        raise ValueError("Current product access is unavailable.")
    scope = {"checkout": dw._hash(str(root)), "owner": dw._hash(actor), "access": sorted(set(allowed_packs))}
    base = Path(os.environ.get("RWDP_STATE_DIR") or root / ".portal-drafts").absolute()
    directory = base / "setup-drafts" / scope["checkout"][:12] / scope["owner"][:12]
    if directory.resolve() != directory:
        raise ValueError("The private setup location redirects to another folder.")
    dw._check_storage_paths([directory / ("0" * 24 + ".json")])
    return scope, directory


def _setup_values(values):
    if not isinstance(values, dict) or not set(values) <= SETUP_FIELDS:
        raise ValueError("The saved setup contains unsupported fields.")
    if any(value is not None and (not isinstance(value, str) or len(value) > 4000 or "\0" in value)
           for value in values.values()):
        raise ValueError("Keep setup entries within the supported text size.")
    return dict(values)


def _setup_history(history):
    if not isinstance(history, list) or len(history) > 8:
        raise ValueError("The setup conversation exceeds its supported history.")
    result = []
    for turn in history:
        if (not isinstance(turn, dict) or set(turn) != {"question", "answer"}
                or any(not isinstance(value, str) or len(value) > 6000 or "\0" in value for value in turn.values())):
            raise ValueError("The saved setup conversation is malformed.")
        result.append(dict(turn))
    return result


def _setup_ingress(values, history, hint=None):
    from scientific_definition_ai import _ingress
    try:
        _ingress("\n".join(str(value or "") for value in values.values()) + "\n" +
                 "\n".join(turn[part] for turn in history for part in ("question", "answer")) + "\n" +
                 (json.dumps(hint, ensure_ascii=False) if hint else ""))
    except ValueError:
        raise ValueError("Remove credentials or details about individual people before saving or resuming setup.") from None


def capture_setup(state, root, actor):
    values = _setup_values({key: state[key] for key in SETUP_FIELDS if key in state})
    history = _setup_history([{part: turn.get(part, "") for part in ("question", "answer")}
        for turn in state.get(history_key(root, actor), [])[-8:]])
    import new_product_sheet_scope as sheets
    hint = sheets.capture_hint(root, state)
    _setup_ingress(values, history, hint)
    return {"fields": values, "history": history, **({"sheet_scope_hint": hint} if hint else {})}


def _setup_access_current(saved, current):
    """A new product may expand access; previous access must never be lost.

    Earlier snapshots retained only the access digest, so their readable scope
    remains exact. They cannot safely infer a subset from that one-way digest.
    """
    if (not isinstance(saved, dict) or set(saved) != {"checkout", "owner", "access"}
            or any(saved.get(key) != current[key] for key in ("checkout", "owner"))):
        return False
    access = saved["access"]
    if isinstance(access, str):
        return access == dw._hash(current["access"])
    return (isinstance(access, list) and all(isinstance(pack, str) for pack in access)
            and access == sorted(set(access)) and set(access) <= set(current["access"]))


def _read_setup(path, scope):
    if path.stat().st_size > MAX_SETUP_BYTES:
        raise ValueError("The saved setup is too large to resume.")
    value = dw._json_read(path)
    required = {"schema", "id", "scope", "fields", "history", "saved_at", "digest"}
    if (not isinstance(value, dict) or not required <= set(value) or not set(value) <= required | {"sheet_scope_hint"}
            or value.get("schema") != 1 or not _setup_access_current(value.get("scope"), scope)
            or value.get("digest") != dw._hash({k: v for k, v in value.items() if k != "digest"})
            or value.get("id") != path.stem or not isinstance(value.get("saved_at"), str)):
        raise ValueError("This saved setup changed or belongs to a different checkout, identity or product access.")
    _setup_values(value["fields"])
    _setup_history(value["history"])
    if "sheet_scope_hint" in value:
        import new_product_sheet_scope as sheets
        sheets.validate_hint(value["sheet_scope_hint"])
    keys = ("scope", "fields", "history") + (("sheet_scope_hint",) if "sheet_scope_hint" in value else ())
    if value["id"] != dw._hash({key: value[key] for key in keys})[:24]:
        raise ValueError("This saved setup does not match its original snapshot.")
    _setup_ingress(value["fields"], value["history"], value.get("sheet_scope_hint"))
    return value


def save_setup(root, actor, state, *, allowed_packs, can_write):
    """Save one explicit immutable snapshot; equal content reuses its original ID."""
    if can_write is not True:
        raise ValueError("Saving setup requires permission to start a product in this local workspace.")
    scope, directory = _setup_scope(root, actor, allowed_packs)
    payload = {"scope": scope, **capture_setup(state, root, actor)}
    if not payload["history"] and not any(value for key, value in payload["fields"].items() if key != "np_mode"):
        raise ValueError("Enter a product name, another setup detail or a setup question before saving.")
    identifier = dw._hash(payload)[:24]
    value = {"schema": 1, "id": identifier, **payload, "saved_at": datetime.now(timezone.utc).isoformat()}
    value["digest"] = dw._hash(value)
    raw = json.dumps(value, ensure_ascii=False, indent=2).encode("utf-8")
    if len(raw) > MAX_SETUP_BYTES:
        raise ValueError("This setup is too large to save. Shorten its entries before saving.")
    from local_process_lock import locked
    from scientific_definitions import _atomic
    directory.mkdir(parents=True, exist_ok=True)
    with locked(directory / ".save.lock", directory):
        path = directory / (identifier + ".json")
        if path.exists():
            return _read_setup(path, scope)
        if len(list(directory.glob("*.json"))) >= 200:
            raise ValueError("This identity has 200 saved setup snapshots. Ask the workspace owner to manage its private saved history.")
        _atomic(path, raw)
    return value


def list_setups(root, actor, *, allowed_packs):
    scope, directory = _setup_scope(root, actor, allowed_packs)
    records, warnings = [], []
    files = list(directory.glob("*.json")) if directory.exists() else []
    if len(files) > 200:
        raise ValueError("The saved setup history exceeds its supported size.")
    for path in files:
        try:
            record = _read_setup(path, scope)
            records.append({"id": record["id"], "digest": record["digest"], "saved_at": record["saved_at"],
                            "name": record["fields"].get("np_name") or record["fields"].get("np_slug") or "Unfinished setup"})
        except (OSError, ValueError, TypeError, KeyError, RecursionError):
            warnings.append("A saved setup is unreadable or outside the current product access and was not offered.")
    return {"records": sorted(records, key=lambda record: record["saved_at"], reverse=True), "warnings": sorted(set(warnings))}


def load_setup(root, actor, identifier, *, allowed_packs, expected_digest):
    scope, directory = _setup_scope(root, actor, allowed_packs)
    if not isinstance(identifier, str) or not re.fullmatch(r"[0-9a-f]{24}", identifier):
        raise ValueError("Choose a saved setup from the current list.")
    value = _read_setup(directory / (identifier + ".json"), scope)
    if value["digest"] != expected_digest:
        raise ValueError("The saved setup changed. Reload the saved list before resuming.")
    return value


def resume_preview(root, actor, identifier, state, *, allowed_packs, expected_digest, choices):
    saved = load_setup(root, actor, identifier, allowed_packs=allowed_packs, expected_digest=expected_digest)
    fields = {key: saved["fields"].get(key, "" if key not in choices else None) for key in SETUP_FIELDS}
    reset = []
    for key, options in choices.items():
        if fields[key] is not None and fields[key] not in options:
            if fields[key]:
                reset.append(SETUP_LABELS[key])
            fields[key] = options[0] if key == "np_mode" else None
    if fields["np_mode"] is None:
        fields["np_mode"] = choices["np_mode"][0]
    if fields["np_old"] and fields["np_old"] not in allowed_packs:
        reset.append(SETUP_LABELS["np_old"])
        fields["np_old"] = None
    before = capture_setup(state, root, actor)
    diff = [{"Field": SETUP_LABELS[key], "Current": before["fields"].get(key) or "", "Saved": value or ""}
            for key, value in sorted(fields.items()) if (before["fields"].get(key) or "") != (value or "")]
    if before["history"] != saved["history"]:
        diff.append({"Field": "Setup conversation", "Current": json.dumps(before["history"], ensure_ascii=False),
                     "Saved": json.dumps(saved["history"], ensure_ascii=False)})
    if before.get("sheet_scope_hint") != saved.get("sheet_scope_hint"):
        diff.append({"Field": "Sheet exclusions to review after workbook selection",
                     "Current": json.dumps(before.get("sheet_scope_hint") or {}, ensure_ascii=False),
                     "Saved": json.dumps(saved.get("sheet_scope_hint") or {}, ensure_ascii=False)})
    replaces = bool(before["history"] or before.get("sheet_scope_hint") or any(value for key, value in before["fields"].items() if key != "np_mode"))
    return {"id": identifier, "digest": expected_digest, "fields": fields, "history": saved["history"], "diff": diff,
            "resets": reset, "replaces": replaces, "current_digest": dw._hash(before), "choices_digest": dw._hash(choices),
            **({"sheet_scope_hint": saved["sheet_scope_hint"], "sheet_scope_hint_mode": saved["fields"].get("np_mode")}
               if saved.get("sheet_scope_hint") else {})}


def restore_setup(root, actor, state, proposal, *, allowed_packs, choices, can_write, confirmed):
    """Apply a fresh reviewed continuation before any registration widget renders."""
    if can_write is not True or confirmed is not True:
        raise ValueError("Explicitly choose to resume this setup in the current editing session.")
    current = resume_preview(root, actor, proposal["id"], state, allowed_packs=allowed_packs,
        expected_digest=proposal["digest"], choices=choices)
    if current != proposal:
        raise ValueError("Your current setup or available choices changed. Review the saved setup again.")
    for key in list(state):
        if str(key).startswith(("np_", "chat_form_", "flow_assistant_feedback")) and not str(key).endswith("_upload"):
            state.pop(key, None)
    state.update(current["fields"])
    if current.get("sheet_scope_hint"):
        import new_product_sheet_scope as sheets
        state[sheets.HINT] = sheets.validate_hint(current["sheet_scope_hint"])
        state[sheets.HINT_MODE] = current["sheet_scope_hint_mode"]
    # Explicit empty declaration values prevent the local identity default from
    # being mistaken for a declaration restored from this snapshot.
    state.update(np_by="", np_on="", np_ai=None)
    state[history_key(root, actor)] = [{**turn, "actions": [], "source": "saved_setup"} for turn in current["history"]]
    state[history_key(root, actor) + "_restore_requested"] = True
    state.setdefault("_form_drafts", {})[actor] = {key: value for key, value in state.items() if _field(str(key))}
    return current
