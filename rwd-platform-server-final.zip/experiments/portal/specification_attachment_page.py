"""Choose or upload a program specification from the focused Flow dialog."""
from pathlib import Path

import streamlit as st

import specification_attachment as attachment


def clear():
    for key in list(st.session_state):
        if str(key).startswith("spec_attach_"):
            st.session_state.pop(key, None)


def _changed():
    st.session_state["spec_attach_confirm"] = False


def render(root, pack, actor_id, *, local_demo, can_write, can_view):
    """Return True only when a workbook registration changed successfully."""
    if not can_view:
        clear()
        st.warning("You no longer have access to this product's specification.")
        return False
    context = (str(Path(root).resolve()), pack, actor_id, bool(local_demo), bool(can_write))
    cached = st.session_state.get("spec_attach_snapshot")
    context_changed = isinstance(cached, dict) and cached.get("context") != context
    if not isinstance(cached, dict) or cached.get("context") != context:
        clear()
        description = attachment.describe(root, pack, allowed_packs=[pack])
        st.session_state["spec_attach_snapshot"] = {"context": context, "description": description}
    else:
        description = cached["description"]
    st.write("**Attach the program specification**")
    st.caption("Choose the intended workbook already in this product, or upload its XLSX file. The portal records the file and its checksum together.")
    if not description.get("ok"):
        for error in description.get("errors") or ["The attachment form could not be opened."]:
            st.warning(str(error))
        if st.button("Reload attachment form", key="spec_attach_reload"):
            clear()
            st.rerun()
        return False
    current = description["current"]
    if current["exists"]:
        st.text("Current specification: " + current["path"])
        st.caption("Recorded status: " + current["status"])
    else:
        st.info("There is no readable specification workbook registered in this product yet.")
    enabled = local_demo is True and can_write is True and not context_changed
    if not enabled:
        st.info("Attaching a workbook requires product-author access in a local session. If your context just changed, reopen this form to continue.")
    choices = {item["path"]: item for item in description["choices"]}
    methods = ["Choose existing workbook", "Upload XLSX"] if choices else ["Upload XLSX"]
    if st.session_state.get("spec_attach_method") not in methods:
        st.session_state["spec_attach_method"] = methods[0]
    method = st.radio("Where is the specification?", methods, horizontal=True, key="spec_attach_method", disabled=not enabled,
                      on_change=_changed)
    selected = uploaded = None
    if method == "Choose existing workbook":
        if st.session_state.get("spec_attach_existing") not in choices:
            st.session_state["spec_attach_existing"] = None
        selected = st.selectbox("Workbook in this product", list(choices), index=None,
                                format_func=lambda value: choices[value]["label"], key="spec_attach_existing",
                                disabled=not enabled, on_change=_changed)
        if selected:
            st.caption(f"{choices[selected]['bytes']:,} bytes · the workbook will be checked before registration.")
    else:
        uploaded = st.file_uploader("Program specification (.xlsx)", type=["xlsx"], accept_multiple_files=False,
                                    max_upload_size=15, key="spec_attach_upload", disabled=not enabled, on_change=_changed)
        st.caption("Maximum 15 MB. Use a standalone workbook without macros or linked workbooks. A different file with the same name is saved as a separate version.")
    for warning in description.get("warnings", []):
        st.caption(str(warning))
    if current["requires_reset"]:
        st.warning("Replacing the specification resets its scientific review, AI access decision, revision, data refresh and QC reference. Its document ID and source history identity stay the same.")
        st.checkbox("I confirm this replacement and understand that these details must be reviewed for the attached workbook.",
                    key="spec_attach_confirm", disabled=not enabled)
    st.caption(attachment.NOTICE)
    if st.button("Attach specification", key="spec_attach_save", type="primary", disabled=not enabled):
        if not selected and uploaded is None:
            st.warning("Choose a listed workbook or upload an XLSX specification first.")
        else:
            try:
                kwargs = {"existing_path": selected, "expected_file_digest": choices[selected]["sha256"]} if selected else {
                    "upload_name": uploaded.name, "upload_bytes": uploaded.getvalue()}
                with st.spinner("Checking the workbook and recording its source…"):
                    result = attachment.attach(root, pack, expected_digest=description["digest"],
                                               confirm_reset=st.session_state.get("spec_attach_confirm", False),
                                               local_demo=local_demo, can_write=can_write and can_view,
                                               allowed_packs=[pack], **kwargs)
            except (OSError, ValueError, TypeError, AttributeError):
                result = {"ok": False, "errors": ["The selected upload could not be read. Choose the workbook again."]}
            if result.get("ok"):
                st.session_state["spec_attach_snapshot"] = {"context": context, "description": result}
                if result.get("changed"):
                    st.success("Specification attached and checksum recorded. Scientific review and AI access classification are pending.")
                    return True
                st.info("This exact workbook is already registered. Its existing review details were preserved.")
            else:
                for error in result.get("errors") or ["The workbook could not be attached."]:
                    st.error(str(error))
    if st.button("Reload saved attachment", key="spec_attach_reload", help="Discard the selected file and read the current source record."):
        clear()
        st.rerun()
    return False
