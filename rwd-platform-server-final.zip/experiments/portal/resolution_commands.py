"""Turn an existing Flow command into one complete, correctly quoted command."""
from pathlib import Path
import os
import re
import shlex
import sys

import flow
import yaml
import specification_details as details


class Invalid(ValueError):
    pass


def current_action(root, pack, action):
    aid = action.get("id") if isinstance(action, dict) else action
    return next((item for group in flow.acts(pack, str(root)).values() for item in group if item["id"] == aid), None)


def describe(root, pack, action):
    root = Path(root).resolve()
    try:
        _source, pack = details._paths(root, pack, [pack])
    except (details._Invalid, ValueError, TypeError, OSError) as error:
        raise Invalid("Choose a product inside this checkout before preparing its command.") from error
    current = current_action(root, pack, action)
    if not current or not current.get("argv"):
        return {"available": False, "fields": [], "argv": [], "reason": "This action is completed through its review form."}
    argv = [str(arg) for arg in current["argv"]]
    fields = []
    for arg in argv:
        for name in re.findall(r"<([^<>]+)>", arg):
            if name not in [field["name"] for field in fields]:
                fields.append({"name": name, "label": {"profile.tsv": "Complete delivery profile (.tsv)",
                    "SCHEMA_VALIDATION.json": "Schema validation report (.json)", "source_qc.json": "Source QC report (.json)",
                    "judgment.yaml": "Saved scientific interpretation (.yaml)", "domain:row": "Specification row to interpret",
                    "key id": "Registered release-signing key ID", "file outside the checkout": "Your signing-key path on the reviewer's computer",
                    "build_id": "Approved candidate build ID"}.get(name, name.replace("_", " ").capitalize()), "suggested": ""})
    release = root / pack / "handoff/RELEASE_APPROVAL.yaml"
    if any(field["name"] == "build_id" for field in fields) and release.is_file() and release.resolve() == release:
        try:
            doc = yaml.safe_load(release.read_text(encoding="utf-8"))
            build = doc.get("approved_build_id") if isinstance(doc, dict) else None
            if isinstance(build, str) and build.strip() and "<" not in build and build.lower() not in {"tbd", "todo", "pending"}:
                next(field for field in fields if field["name"] == "build_id")["suggested"] = build
        except (OSError, UnicodeError, yaml.YAMLError):
            pass
    return {"available": True, "fields": fields, "argv": argv,
            "environment": "approved Databricks environment" if argv[0] == "databricks" else "this computer", "action_id": current["id"]}


def interpreter(root, *, windows=None):
    """Use the portal's selected interpreter, including external and .venv313 environments.

    The shell choice changes quoting, never runtime selection. Do not resolve the
    executable's symlink: on Linux that would discard the virtual environment.
    """
    return Path(sys.executable).absolute()


def render(root, argv, *, windows=None):
    """ONE COMMAND STYLE (2026-09-07): the Flow page's technical handoff printed `python
    platform/tools/...` while this module built the checkout's venv wrapper, so a person saw two
    different commands for one act. Every command shown anywhere is rendered here: the checkout's
    selected interpreter, the tool's absolute path, the arguments as given (a placeholder such as <you> is
    left for the reader to fill), wrapped to start in the exact checkout. Empty argv renders as
    an empty string; nothing is verified here, `build` verifies before it substitutes."""
    root = Path(root).resolve()
    argv = [str(arg) for arg in argv or []]
    if not argv:
        return ""
    windows = os.name == "nt" if windows is None else windows
    if argv[0].endswith(".py"):
        argv = [str(interpreter(root, windows=windows)), str(root / argv[0]), *argv[1:]]
    # Existing tools take repository-relative arguments; starting in the exact
    # checkout avoids the earlier missing-file failures in another working dir.
    if windows:
        quoted = " ".join("'" + arg.replace("'", "''") + "'" for arg in argv)
        directory = str(root).replace("'", "''")
        return f"& {{ Push-Location -LiteralPath '{directory}'; try {{ & {quoted} }} finally {{ Pop-Location }} }}"
    return "(cd " + shlex.quote(str(root)) + " && " + shlex.join(argv) + ")"


def build(root, pack, action, values=None, *, windows=None):
    root = Path(root).resolve()
    description = describe(root, pack, action)
    if not description["available"]:
        raise Invalid(description["reason"])
    values = values or {}
    required = {field["name"] for field in description["fields"]}
    if set(values) - required:
        raise Invalid("The command has changed. Reopen the current resolution.")
    replacements = {}
    for field in description["fields"]:
        value = values.get(field["name"], field["suggested"])
        if not isinstance(value, str) or not value.strip() or value.strip().lower() in {"tbd", "todo", "pending"}:
            raise Invalid("Complete " + field["label"] + " before generating the command.")
        value = value.strip()
        if len(value) > 2000 or value.startswith("-") or any(char in value for char in "\r\n\0<>"):
            raise Invalid(field["label"] + " needs one literal value, without placeholders or command options.")
        replacements[field["name"]] = value
    argv = [re.sub(r"<([^<>]+)>", lambda match: replacements[match.group(1)], arg) for arg in description["argv"]]
    windows = os.name == "nt" if windows is None else windows
    if argv[0].endswith(".py"):
        script = root / argv[0]
        if script.resolve() != script or not script.is_file() or not script.is_relative_to(root):
            raise Invalid("The command's tool is unavailable in this checkout.")
        if not interpreter(root, windows=windows).is_file():
            raise Invalid("The portal's selected Python interpreter is unavailable. Restart the portal using your Python 3.13 environment before preparing commands.")
    command = render(root, argv, windows=windows)
    if argv[0].endswith(".py"):
        argv = [str(interpreter(root, windows=windows)), str(root / argv[0]), *argv[1:]]
    return {**description, "command": command, "argv": argv, "values": replacements}
