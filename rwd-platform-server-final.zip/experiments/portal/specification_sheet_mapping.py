"""Review product-local worksheet mappings using the existing extraction pipeline."""
from __future__ import annotations

import difflib
from collections import OrderedDict
import hashlib
import json
import os
from pathlib import Path
import re
import tempfile
from threading import Lock
from types import SimpleNamespace
import yaml

import specification_details as details
import specification_attachment as attachment
import contract_lint as cl
import contract_scaffold as scaffold
import new_product
import run_spec_pipeline as pipeline
import spec_extract as extract
import spec_lint

NOTICE = ("Saving updates this product's sheet mapping only. Run the extraction step again, then review its "
          "definitions. It does not approve science, change study exclusions or release a product.")
LIMIT = 4 * 1024 * 1024
SHEET_FIELD_PREFIX = "Specification section for "
REASON_FIELD = "Why do these sheets belong to these sections?"
_METADATA = OrderedDict()
_METADATA_LOCK = Lock()


class _Unavailable(details._Invalid):
    pass


def _hash(value):
    return hashlib.sha256(value if isinstance(value, bytes) else
                          json.dumps(value, sort_keys=True, ensure_ascii=False).encode()).hexdigest()


def _workbook_metadata(raw):
    """Reuse validated metadata for identical bytes; keep no workbook content."""
    key = (_hash(raw), _hash(Path(attachment.__file__).read_bytes()))
    with _METADATA_LOCK:
        if key in _METADATA:
            _METADATA.move_to_end(key)
            return _METADATA[key]
    metadata = attachment.validate_workbook(raw)
    with _METADATA_LOCK:
        _METADATA[key] = metadata
        while len(_METADATA) > 16:
            _METADATA.popitem(last=False)
    return metadata


def _read(path, *, optional=False):
    if path.resolve() != path:
        raise details._Invalid("A mapping input redirects outside its normal location.")
    if optional and not path.exists():
        return b""
    if not path.is_file() or path.stat().st_size > LIMIT:
        raise details._Invalid("A mapping input is missing or exceeds the editor limit: " + path.name)
    return path.read_bytes()


def _fail(error, *, available=True):
    message = str(error) if isinstance(error, details._Invalid) else "The worksheet mapping could not be checked safely. Reload the specification and try again."
    return {"ok": False, "available": available and not isinstance(error, _Unavailable), "changed": False, "can_apply": False,
            "errors": [message], "digest": "", "notice": NOTICE}


def _load(root, pack, actor_id, allowed_packs):
    if not isinstance(actor_id, str) or not actor_id.strip() or len(actor_id) > 200:
        raise details._Invalid("Choose the current workspace identity before editing the mapping.")
    if not str(pack).replace("\\", "/").startswith("products/"):
        raise details._Invalid("Create a working product before changing its worksheet mapping.")
    registered, _pack = details._paths(root, pack, allowed_packs)
    if not registered.is_file():
        raise _Unavailable("Register the specification workbook before mapping its worksheets.")
    source, pack, source_raw, _text, document, _index, _node = details._load(root, pack, allowed_packs)
    product = source.parent
    conf_path = product / "spec_pipeline/pipeline.conf"
    conf_raw = _read(conf_path)
    conf_text = conf_raw.decode("utf-8")
    keys = re.findall(r"^\s*([A-Z_]+)\s*=", conf_text, re.M)
    if len(keys) != len(set(keys)):
        raise details._Invalid("The extraction configuration repeats a setting. Resolve it before editing worksheet mappings.")
    conf = pipeline.read_conf(conf_path)
    selected = [m for m in document["source_materials"] if m.get("material_id") == conf.get("SPEC_SOURCE_ID")]
    if len(selected) != 1:
        raise details._Invalid("The extraction configuration must select one registered specification material.")
    workbook = attachment._current_path(root, product, pack, selected[0])
    if workbook is None or not workbook.is_file():
        raise _Unavailable("This editor requires a registered XLSX workbook in the product's specification folder.")
    raw = attachment._bytes(workbook)
    metadata = _workbook_metadata(raw)
    recorded = str(selected[0].get("sha256") or "")
    if recorded and not details.unstated(recorded) and recorded.lower() != _hash(raw):
        raise details._Invalid("The workbook changed after registration. Update the registered specification before changing its mapping.")
    names = list(metadata["sheets"])
    scope = new_product.sheet_scope_options(names, root, pack)
    ignored = extract.parse_ignore(conf.get("IGNORE", "")) | set(extract.shared_sheet_map(root)["ignored"])
    sheets = []
    for row in scope["sheets"]:
        name = row["name"]
        excluded = extract.sheet_key(name) in ignored and not row["domain"]
        safe = bool(name.strip()) and not any(c in name for c in ",#\"'\r\n=$`") and not any(ord(c) < 32 for c in name)
        sheets.append({**{key: row[key] for key in ("name", "domain", "kind", "ambiguous")},
                       "excluded": excluded, "editable": safe and not excluded and not row["ambiguous"]})
    contract = _read(product / "handoff/FUNCTIONAL_CONTRACT.md", optional=True)
    previous = _read(product / "spec_pipeline/out/extracted.json", optional=True)
    code = {Path(module.__file__).name: _hash(Path(module.__file__).read_bytes())
            for module in (extract, spec_lint, scaffold, cl, pipeline, new_product)}
    code[Path(__file__).name] = _hash(Path(__file__).read_bytes())
    state = {"source": _hash(source_raw), "configuration": _hash(conf_raw), "workbook": _hash(raw),
             "contract": _hash(contract), "extraction": _hash(previous), "shared_map": extract.shared_sheet_map(root),
             "code": code, "pack": pack, "actor": actor_id}
    # Sets occur in the canonical map; normalize only for fingerprinting.
    state["shared_map"] = {key: sorted(value) if isinstance(value, set) else value for key, value in state["shared_map"].items()}
    return {"source": source, "product": product, "pack": pack, "workbook": workbook,
            "conf_path": conf_path, "conf_raw": conf_raw, "conf_text": conf_text, "conf": conf,
            "sheets": sheets, "domains": scope["mapping_domains"], "contract": contract,
            "previous": previous, "digest": _hash(state)}


def describe(root, pack, actor_id, *, allowed_packs):
    if not str(pack).replace("\\", "/").startswith("products/"):
        return {"ok": True, "available": False, "errors": [], "notice": NOTICE}
    try:
        state = _load(root, pack, actor_id, allowed_packs)
        return {"ok": True, "available": True, "errors": [], "notice": NOTICE,
                **{key: state[key] for key in ("digest", "sheets", "domains")}}
    except (OSError, ValueError, TypeError, KeyError, UnicodeError, yaml.YAMLError, RecursionError) as error:
        return _fail(error)


def _proposal(state, mappings, reason):
    if not isinstance(mappings, dict) or any(not isinstance(key, str) or not isinstance(value, str) for key, value in mappings.items()):
        raise details._Invalid("Choose a domain for each worksheet using the offered names.")
    if not isinstance(reason, str) or details.unstated(reason) or len(reason) > 1000 or any(ord(c) < 32 for c in reason):
        raise details._Invalid("Explain the mapping change in one line, up to 1,000 characters.")
    rows = {row["name"]: row for row in state["sheets"]}
    changes = []
    for name, domain in mappings.items():
        row = rows.get(name)
        if not row or not row["editable"] or domain not in state["domains"]:
            raise details._Invalid("Choose an editable worksheet and one of its offered specification domains.")
        if domain != row["domain"]:
            changes.append({"sheet": name, "before": row["domain"] or "Unclassified", "after": domain})
    if not changes:
        raise details._Invalid("Select at least one worksheet mapping to change.")
    args = SimpleNamespace(sheet_domain=[f"{row['sheet']}={row['after']}" for row in changes],
                           sheet_domain_reason=reason.strip(), exclude_sheet=[], next_cut_of=None)
    candidate = new_product._scope_conf(state["conf_text"], args)
    with tempfile.TemporaryDirectory(prefix="rwd-sheet-") as folder:
        path = Path(folder) / "pipeline.conf"
        path.write_text(candidate, encoding="utf-8", newline="")
        conf = pipeline.read_conf(path)
    # A redundant legacy TABS list must not turn complete coverage into partial
    # coverage. Remove it only when it already includes every mapped worksheet;
    # a genuinely partial selection still fails the existing integrity check.
    selected_tabs = extract.parse_ignore(conf["TABS"])
    candidate_domains = {extract.sheet_key(row["name"]): mappings.get(row["name"], row["domain"])
                         for row in state["sheets"]}
    required_tabs = {name for name, domain in candidate_domains.items() if domain}
    if selected_tabs and required_tabs and required_tabs <= selected_tabs:
        candidate = re.sub(r'^[ \t]*TABS[ \t]*=[^\n]*', 'TABS=""', candidate, flags=re.M)
        conf["TABS"] = ""
    if any(conf.get(key) != value for key, value in state["conf"].items() if key not in {"DOMAINS", "TABS"}):
        raise details._Invalid("The mapping would change another extraction setting; the configuration was kept.")
    return candidate, conf, changes


def preview(root, pack, actor_id, mappings, reason, *, expected_digest, allowed_packs):
    try:
        state = _load(root, pack, actor_id, allowed_packs)
        if state["digest"] != expected_digest:
            raise details._Invalid("The workbook, configuration or review inputs changed. Reload and preview the current mapping.")
        candidate, conf, changes = _proposal(state, mappings, reason)
        domains = dict(extract.shared_domains(root), **extract.parse_domains(conf["DOMAINS"]))
        data = extract.extract(str(state["workbook"]), domains, extract.parse_ignore(conf["IGNORE"]))
        tabs = list(extract.parse_ignore(conf["TABS"])) or None
        findings = spec_lint.scan(data, tumor=conf["TUMOR"] or None, tabs=tabs)
        errors = list(dict.fromkeys([*extract.integrity_failures(data),
                                    *scaffold.extraction_integrity(data, findings, tabs)]))
        requirements = [row for row in extract.requirement_rows(data, tabs) if row.get("domain") and row.get("variable") and not extract.is_context(row)]
        if not requirements:
            errors.append("Keep at least one named specification requirement.")
        checks = [{"name": "Extraction integrity and source identities", "status": "fail" if errors else "pass", "details": errors},
                  {"name": "Scientific specification lint", "status": "needs_review" if findings else "pass",
                   "details": [f"{item['kind']}: {item.get('detail', '')}" for item in findings]}]
        prior = json.loads(state["previous"]) if state["previous"] else {"rows": []}
        previous_ids = {(row.get("tab"), row.get("row")): row.get("item_id") or extract.row_item_id(row) for row in prior.get("rows", [])}
        changed_refs = sum(previous_ids.get((row["tab"], row["row"])) not in (None, extract.row_item_id(row)) for row in requirements)
        impact = {"previous_definition_records": sum(1 for _ in cl.records(state["contract"].decode("utf-8"))), "citation_changes": changed_refs}
        warnings = ["Scientific findings require review after extraction; a mapping check does not resolve them."] if findings else []
        if changed_refs:
            warnings.append(f"{changed_refs} existing source references change. Review affected definitions after regenerating the extraction; no citations are rewritten automatically.")
        if _load(root, pack, actor_id, allowed_packs)["digest"] != expected_digest:
            raise details._Invalid("The inputs changed during preview. Reload the current mapping.")
        return {"ok": True, "errors": errors, "can_apply": not errors, "digest": state["digest"],
                "preview_digest": _hash([state["digest"], candidate, checks, impact]),
                "diff": "".join(difflib.unified_diff(state["conf_text"].splitlines(True), candidate.splitlines(True),
                                                    fromfile="Current worksheet mapping", tofile="Proposed worksheet mapping")),
                "changes": changes, "rows": [{"sheet": sheet["name"], "domain": domains.get(extract.sheet_key(sheet["name"]), ""),
                    "requirements": sum(row["tab"] == sheet["name"] for row in requirements)} for sheet in state["sheets"]],
                "checks": checks, "warnings": warnings, "impact": impact, "notice": NOTICE}
    except (OSError, ValueError, TypeError, KeyError, UnicodeError, yaml.YAMLError, RecursionError) as error:
        return _fail(error)


def apply(root, pack, actor_id, mappings, reason, *, expected_digest, expected_preview_digest,
          allowed_packs, can_write, confirmed):
    temporary = None
    try:
        if can_write is not True or confirmed is not True:
            raise details._Invalid("Review the mapping diff and confirm saving it with workspace write access.")
        source, _pack = details._paths(root, pack, allowed_packs)
        with details.source_edit_lock(root, source):
            checked = preview(root, pack, actor_id, mappings, reason, expected_digest=expected_digest, allowed_packs=allowed_packs)
            if not checked["ok"] or not checked.get("can_apply"):
                return {**checked, "ok": False, "changed": False}
            if checked["preview_digest"] != expected_preview_digest:
                raise details._Invalid("The reviewed mapping or its checks changed. Preview it again before saving.")
            state = _load(root, pack, actor_id, allowed_packs)
            if state["digest"] != expected_digest:
                raise details._Invalid("The mapping inputs changed before saving. Preview again.")
            candidate, _conf, _changes = _proposal(state, mappings, reason)
            descriptor, name = tempfile.mkstemp(prefix=".mapping-", suffix=".tmp", dir=state["conf_path"].parent)
            temporary = Path(name)
            with os.fdopen(descriptor, "wb") as handle:
                handle.write(candidate.encode("utf-8"))
                handle.flush()
                os.fsync(handle.fileno())
            if _load(root, pack, actor_id, allowed_packs)["digest"] != expected_digest:
                raise details._Invalid("The mapping inputs changed while saving. Your current files were kept; preview again.")
            os.replace(temporary, state["conf_path"])
            temporary = None
        return {"ok": True, "changed": True, "errors": [], "notice": NOTICE}
    except (OSError, ValueError, TypeError, KeyError, UnicodeError, yaml.YAMLError, RecursionError) as error:
        return _fail(error)
    finally:
        if temporary is not None:
            temporary.unlink(missing_ok=True)
