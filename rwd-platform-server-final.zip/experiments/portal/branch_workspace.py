"""Review and commit selected product metadata in the user's current local branch."""
from __future__ import annotations

import difflib
import hashlib
import json
import os
from pathlib import Path
from pathlib import PurePosixPath
import re
import subprocess
import tempfile

import yaml

import design_workspace
import specification_details

MAX_BYTES = 2 * 1024 * 1024
EXTENSIONS = {".yaml", ".yml", ".md", ".json", ".jsonld", ".ttl", ".conf"}
BRANCH_FILES = "handoff/BRANCH_FILES.yaml"
SHARED_FILES = frozenset({"products/registry.yaml", "products/activation.yaml", "products/metadata/catalog.yaml",
    "governance/tumour_registry.yaml", "governance/reference/oncology_modules/CATALOGUE.yaml",
    "governance/reference/variable_inventory/INVENTORY.yaml", "resources/products.yml"})
GENERATED_REPORTS = {"governance/CURRENT_STATE.md", "products/PORTFOLIO.md",
    "governance/reference/variable_inventory/COVERAGE.md", "governance/reference/variable_inventory/CITATIONS.md"}
TEMPLATE_CODE = "handoff/tests/test_functional_contract.py"


def _git(root, args, *, check=True):
    try:
        # check-ignore accepts file names rather than pathspecs and rejects the
        # literal pathspec magic added by this global flag. Its paths follow --.
        flags = [] if args and args[0] == "check-ignore" else ["--literal-pathspecs"]
        result = subprocess.run(["git", *flags, *args], cwd=root, capture_output=True,
            timeout=45, **({"creationflags": subprocess.CREATE_NO_WINDOW} if os.name == "nt" else {}))
    except (OSError, subprocess.SubprocessError) as exc:
        raise ValueError("Git could not finish. Check this checkout's Git installation and retry.") from exc
    if check and result.returncode:
        # Git hooks may emit sensitive content; keep their output in the user's terminal.
        raise ValueError("Git refused this operation. Check Git identity, signing, hooks and file locks in VS Code. Selected files may remain staged; no push was requested.")
    return result


def _hash(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, ensure_ascii=False).encode()).hexdigest()


def _scope(root, pack, actor_id, allowed_packs):
    base, product, pack = design_workspace._pack_path(root, pack, allowed_packs)
    if not actor_id or not pack.startswith("products/"):
        raise ValueError("Choose your working product. Reference examples are separate from branch editing.")
    top = Path(_git(base, ["rev-parse", "--show-toplevel"]).stdout.decode().strip()).resolve()
    if top != base:
        raise ValueError("Open the repository root that owns this product.")
    return base, product, pack


def _allowed(base, product, relative):
    path = base / relative
    implementation = re.fullmatch(r"handoff/IMPLEMENTATION_REVIEWS/[a-f0-9]{24}/(?:candidate|candidate_tests)\.py",
                                 path.relative_to(product).as_posix()) if path.is_relative_to(product) else None
    if (path.resolve() != path or not path.is_relative_to(product)
            or (path.suffix.lower() not in EXTENSIONS and not implementation and relative != product.relative_to(base).as_posix() + "/spec_pipeline/out/SPEC_FINDINGS.txt")):
        return False
    parts = path.relative_to(product).parts
    return (parts in {("source_refs.yaml",), ("NEW_TUMOUR.md",), ("prog_spec", "README.md")} or
            (len(parts) > 1 and parts[0] in {"config", "handoff", "variables", "codelists", "spec_pipeline"}
             and not any(p.startswith(".") for p in parts)))


def _relative(value):
    if not isinstance(value, str) or not value or len(value) > 600 or "\\" in value or ":" in value \
            or any(ord(char) < 32 for char in value):
        raise ValueError("A creation record contains an unsupported path.")
    path = PurePosixPath(value)
    if path.is_absolute() or path.as_posix() != value or any(p in {".", ".."} or p.startswith(".") for p in path.parts):
        raise ValueError("Creation paths must stay in the selected product or its exact registration metadata.")
    return value


def _shared(pack):
    return SHARED_FILES | {"governance/reference/oncology_modules/indication/" + pack.split("/")[2] + ".yaml"}


def _bytes(path, limit=MAX_BYTES):
    if path.resolve() != path or not path.is_file() or path.stat().st_size > limit:
        raise ValueError("A branch dependency is missing, redirected or too large. Review its canonical location in VS Code.")
    return path.read_bytes()


def _kind(base, product, pack, relative):
    relative = _relative(relative)
    if relative in _shared(pack):
        return "shared_registration"
    if relative in GENERATED_REPORTS:
        return "generated_report"
    if _allowed(base, product, relative) or relative == pack + "/" + TEMPLATE_CODE:
        return "product_metadata"
    path = base / relative
    if path.is_relative_to(product / "prog_spec") and path.suffix.lower() in {".xlsx", ".xlsm"}:
        return "source_workbook"
    raise ValueError("A creation record names a file outside the supported product and registration dependencies.")


def _creation_manifest(base, product, pack):
    path = product / BRANCH_FILES
    if path.resolve() != path:
        raise ValueError("The product's branch dependency record redirects to another location.")
    if not path.exists():
        return None, None
    raw = _bytes(path)
    try:
        if any(isinstance(token, (yaml.AliasToken, yaml.AnchorToken)) for token in yaml.scan(raw)):
            raise ValueError
        doc = yaml.load(raw, Loader=specification_details._StrictLoader)
        if not isinstance(doc, dict) or set(doc) != {"version", "kind", "pack", "generated_by", "files"} \
                or type(doc["version"]) is not int or doc["version"] != 1 or doc["kind"] != "product_creation_files" or doc["pack"] != pack \
                or doc["generated_by"] != "platform/tools/new_product.py" or not isinstance(doc["files"], list) \
                or not 1 <= len(doc["files"]) <= 1000:
            raise ValueError
        seen = set()
        for row in doc["files"]:
            if not isinstance(row, dict) or set(row) != {"path", "kind", "sha256"} \
                    or row["kind"] != _kind(base, product, pack, row["path"]) \
                    or not isinstance(row["sha256"], str) or not re.fullmatch(r"[a-f0-9]{64}", row["sha256"]) \
                    or row["path"] in seen or row["path"] == pack + "/" + BRANCH_FILES:
                raise ValueError
            seen.add(row["path"])
    except (yaml.YAMLError, ValueError, TypeError, KeyError):
        raise ValueError("The product's branch dependency record is malformed or names unsupported files. Restore its recorded creation metadata before checkpointing shared dependencies.") from None
    return doc, hashlib.sha256(raw).hexdigest()


def record_created_files(root, pack, actor_id, *, written_paths, allowed_packs, local_demo, can_write):
    """Record the successful canonical WROTE list; never stage files or add a workbook.

    Called only after new_product exits successfully. The hashes identify that
    initial write, not an approval of future edits to these files.
    """
    if local_demo is not True or can_write is not True:
        raise ValueError("Recording product creation requires an authorized local editing session.")
    base, product, pack = _scope(root, pack, actor_id, allowed_packs)
    if not isinstance(written_paths, (list, tuple)) or not 1 <= len(written_paths) <= 1000:
        raise ValueError("The product creation tool did not return a bounded written-file list.")
    paths = sorted({_relative(value) for value in written_paths})
    if not {pack + "/source_refs.yaml", pack + "/config/data_product.yaml"}.issubset(paths):
        raise ValueError("The product creation result does not identify this product's source registration and configuration.")
    rows = []
    for relative in paths:
        kind = _kind(base, product, pack, relative)
        raw = _bytes(base / relative, 64 * 1024 * 1024 if kind == "source_workbook" else MAX_BYTES)
        rows.append({"path": relative, "kind": kind, "sha256": hashlib.sha256(raw).hexdigest()})
    doc = {"version": 1, "kind": "product_creation_files", "pack": pack,
           "generated_by": "platform/tools/new_product.py", "files": rows}
    target = product / BRANCH_FILES
    raw = yaml.safe_dump(doc, sort_keys=False).encode("utf-8")
    if target.resolve() != target:
        raise ValueError("The branch dependency record redirects to another location.")
    if target.exists():
        if _bytes(target) == raw:
            return {"changed": False, "path": pack + "/" + BRANCH_FILES}
        raise ValueError("A branch dependency record already exists. It was not overwritten; review its creation context in VS Code.")
    target.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.NamedTemporaryFile(dir=target.parent, delete=False) as handle:
        handle.write(raw)
        temporary = Path(handle.name)
    try:
        for row in rows:
            actual = _bytes(base / row["path"], 64 * 1024 * 1024 if row["kind"] == "source_workbook" else MAX_BYTES)
            if hashlib.sha256(actual).hexdigest() != row["sha256"]:
                raise ValueError("A created file changed before its dependencies were recorded. Check the current files in VS Code.")
        os.link(temporary, target)  # Complete new file only; no overwrite of concurrent work.
    finally:
        temporary.unlink(missing_ok=True)
    return {"changed": True, "path": pack + "/" + BRANCH_FILES}


def _source_portability(base, product, pack, head):
    path = product / "source_refs.yaml"
    if not path.exists():
        return []
    try:
        raw = _bytes(path)
        if any(isinstance(token, (yaml.AliasToken, yaml.AnchorToken)) for token in yaml.scan(raw)):
            raise ValueError
        doc = yaml.load(raw, Loader=specification_details._StrictLoader)
        materials = doc.get("source_materials", [])
        if not isinstance(materials, list) or len(materials) > 100:
            raise ValueError
        rows = []
        for material in materials:
            if not isinstance(material, dict):
                raise ValueError
            if material.get("material_type") not in {"program_spec", "extraction_input"}:
                continue
            reference = material.get("path_or_link")
            if not isinstance(reference, str):
                raise ValueError
            if "://" in reference:
                rows.append({"path": "Registered external source", "state": "Reacquire the registered source on the other computer; it is not included in this checkpoint."})
                continue
            candidate = reference if reference.startswith("products/") else pack + "/" + reference
            candidate = _relative(candidate)
            target = base / candidate
            if not target.is_relative_to(product) or target.resolve() != target:
                raise ValueError
            exists = target.is_file()
            ignored = _git(base, ["check-ignore", "--quiet", "--", candidate], check=False).returncode == 0
            in_branch = bool(head and _git(base, ["cat-file", "-e", "HEAD:" + candidate], check=False).returncode == 0)
            changed = bool(in_branch and _git(base, ["diff", "--quiet", "HEAD", "--", candidate], check=False).returncode)
            state = ("Missing locally; obtain the registered source before re-extraction." if not exists else
                     "Ignored by Git; remains on this computer." if ignored else
                     "Present in the branch but changed locally; the reviewed source bytes must be available on the other computer." if changed else
                     "Already present in this branch." if in_branch else
                     "Not committed to this branch; arrange the registered source on the other computer.")
            rows.append({"path": candidate, "state": state})
        return rows
    except (yaml.YAMLError, ValueError, TypeError, AttributeError):
        return [{"path": "Source registration", "state": "Source portability could not be established from the current registration. Review its path and digest before using another checkout."}]


def _implementation_dependencies(base, product, pack, can_manage_shared):
    """Consume exact application receipts; never infer a global edit from a name."""
    paths, bindings, warnings = set(), [], []
    folder = product / "handoff/IMPLEMENTATION_REVIEWS"
    if folder.resolve() != folder:
        raise ValueError("The implementation review folder redirects outside this product.")
    for path in sorted(folder.glob("*/capability_application.json")) if folder.exists() else []:
        if not re.fullmatch(r"[a-f0-9]{24}", path.parent.name):
            continue
        # No shared bytes are opened for a reader without the shared-file role.
        if can_manage_shared is not True:
            warnings.append("A retained implementation has a shared capability application. A local administrator must review its exact registry files.")
            continue
        raw = _bytes(path)
        bindings.append(hashlib.sha256(raw).hexdigest())
        try:
            import pattern_workspace
            application = pattern_workspace.read_application(base, pack, path.parent.name, allowed_packs=[pack])
            paths.update(row["path"] for row in application["files"])
        except (ValueError, OSError, TypeError, KeyError):
            warnings.append("A retained capability application no longer matches the current review or shared files. Review the current capability changes in the implementation workspace before checkpointing those shared files.")
    for path in sorted(folder.glob("*/runtime-*.json")) if folder.exists() else []:
        if not re.fullmatch(r"[a-f0-9]{24}", path.parent.name) or not re.fullmatch(r"runtime-[a-f0-9]{24}\.json", path.name):
            continue
        if can_manage_shared is not True:
            warnings.append("A runtime review names installed shared code and tests. A local administrator can review those exact file changes with its retained outcomes.")
            continue
        bindings.append(hashlib.sha256(_bytes(path)).hexdigest())
        try:
            import pattern_workspace
            checked = pattern_workspace.read_runtime(base, pack, path.parent.name, path.stem[8:], allowed_packs=[pack])
            if checked.get("stale"):
                raise ValueError("The runtime inputs changed.")
            entry = checked["receipt"]["proposal"]["entry"]
            paths.update(row["module"] for row in entry["python"])
            paths.update(row["file"] for row in entry["r"])
            paths.update(selector.split("::", 1)[0] for selector in entry["tests"])
            # The tested environment may import edited helpers or depend on
            # changed synthetic fixtures. Offer its exact validated snapshot
            # dependencies for explicit diff review; Git filters unchanged ones.
            paths.update(checked["receipt"]["proposal"].get("inputs", {}))
        except (ValueError, OSError, TypeError, KeyError):
            warnings.append("A runtime review no longer matches the installed code or tests. Its outcomes remain historical; reopen implementation review before checkpointing those shared files.")
    return paths, bindings, sorted(set(warnings))


def describe(root, pack, actor_id, *, allowed_packs, selected=None, summary_only=False, can_manage_shared=False):
    base, product, pack = _scope(root, pack, actor_id, allowed_packs)
    branch = _git(base, ["symbolic-ref", "--quiet", "--short", "HEAD"], check=False).stdout.decode().strip()
    head = _git(base, ["rev-parse", "--verify", "HEAD"], check=False).stdout.decode().strip()
    creation, creation_sha = _creation_manifest(base, product, pack)
    shared = {r["path"] for r in (creation or {}).get("files", []) if r["kind"] in {"shared_registration", "generated_report"}}
    implementation_paths, application_bindings, application_warnings = _implementation_dependencies(base, product, pack, can_manage_shared)
    shared.update(implementation_paths)
    correction_bindings = []
    if can_manage_shared is True:
        # Reuse the explicit shared-file checkpoint; feedback is never inferred
        # from private chats or included for a product-only editor.
        import workflow_skills
        loop = workflow_skills.learning()
        for correction in loop.corrections(base):
            # An archive checkpoint includes both the historical destination and
            # the original deletion; the exact record keeps its stable identity.
            shared.add((loop.CORRECTIONS / (correction["id"] + ".yaml")).as_posix())
            shared.add(loop.correction_relative_path(base, correction["id"]))
            correction_bindings.append(correction["digest"])
            import workflow_durable_fixes as durable
            for identifier in correction.get("durable_history", []):
                # Exact owned sidecars share with their lesson; no arbitrary
                # neighbouring code or register is inferred from a file name.
                proposal = durable._read(base, correction["id"], identifier)
                relative = (loop.CORRECTIONS / correction["id"] / ("durable-" + identifier + ".json")).as_posix()
                shared.add(relative)
                correction_bindings.append(proposal["digest"])
                if proposal.get("application"):
                    try:
                        application = durable.validate_application(base, correction["id"], identifier)
                        shared.add(application["path"])
                    except (ValueError, OSError, TypeError, KeyError):
                        application_warnings.append("A durable replacement changed after its checks. Its lesson and proposal history are available; review the current replacement before sharing its target file.")
    template_code = {r["path"] for r in (creation or {}).get("files", []) if r["path"] == pack + "/" + TEMPLATE_CODE}
    search = [pack, *sorted(shared)]
    # Review both sides of a file move, including after Git recognizes a staged
    # rename. Otherwise the original deletion disappears between preview/commit.
    changed = _git(base, ["diff", "--no-renames", "--name-only", "-z", "HEAD", "--", *search]).stdout if head else b""
    staged = _git(base, ["diff", "--cached", "--no-renames", "--name-only", "-z", "--", *search]).stdout
    untracked = _git(base, ["ls-files", "--others", "--exclude-standard", "-z", "--", *search]).stdout
    candidates = sorted(set(x.decode("utf-8") for x in (changed + staged + untracked).split(b"\0") if x))
    offered = [p for p in candidates if _allowed(base, product, p) or p in template_code or (can_manage_shared is True and p in shared)]
    # Validate every new shared/code read before showing a diff or staging bytes.
    for relative in offered:
        path = base / relative
        if path.resolve() != path:
            raise ValueError("A selected dependency redirects to another location. Restore its canonical path first.")
    selected = [] if summary_only else (offered if selected is None else sorted(set(selected)))
    if len(selected) > 100:
        raise ValueError("Review at most 100 product records in one checkpoint.")
    if any(p not in offered for p in selected):
        raise ValueError("The selected changes are no longer available in this product. Refresh the review.")
    records, chunks = [], []
    for relative in selected:
        path = base / relative
        if path.exists() and (not path.is_file() or path.stat().st_size > MAX_BYTES):
            raise ValueError("A selected record is too large or is not a regular file. Review it in VS Code.")
        after = path.read_bytes() if path.exists() else None
        previous = _git(base, ["show", f"HEAD:{relative}"], check=False) if head else None
        before = previous.stdout if previous and previous.returncode == 0 else None
        if before and len(before) > MAX_BYTES:
            raise ValueError("A selected record is too large. Review it in VS Code.")
        try:
            old, new = (before or b"").decode("utf-8"), (after or b"").decode("utf-8")
        except UnicodeError as exc:
            raise ValueError("A selected record is not readable text. Review it in VS Code.") from exc
        if "\0" in old + new:
            raise ValueError("A selected record contains binary data. Review it in VS Code.")
        records.append({"path": relative, "before": hashlib.sha256(before).hexdigest() if before is not None else None,
                        "after": hashlib.sha256(after).hexdigest() if after is not None else None,
                        "git_after": _git(base, ["hash-object", "--path=" + relative, relative]).stdout.decode().strip()
                                     if after is not None else None})
        chunks.append("".join(difflib.unified_diff(old.splitlines(True), new.splitlines(True),
                      fromfile=relative + " (branch)", tofile=relative + " (working file)")))
    data = {"root": str(base), "pack": pack, "actor": actor_id, "branch": branch, "head": head,
            "records": records, "creation_sha256": creation_sha, "application_bindings": application_bindings,
            "correction_bindings": correction_bindings,
            "can_manage_shared": can_manage_shared is True}
    return {**data, "digest": _hash(data), "diff": "\n".join(chunks), "offered": offered,
            "other_changes": len(candidates) - len(offered),
            "can_commit": bool(branch and head and records),
            "private_drafts": (product / ".portal-drafts").is_dir(),
            "shared_pending": sorted(set(candidates) & shared), "shared_selected": sorted(set(selected) & shared),
            "application_warnings": application_warnings,
            "sources": _source_portability(base, product, pack, head),
            "private_notice": "Unfinished private drafts and restricted evidence remain on this computer. Save their checked product records before checkpointing; they are never force-added."}


def commit(root, pack, actor_id, *, allowed_packs, selected, expected_digest, message,
           confirmed, local_demo, can_write, can_manage_shared=False, confirmed_shared=False):
    if not (confirmed and local_demo and can_write):
        raise ValueError("Review the selected diff and confirm saving it to your local branch.")
    if not isinstance(message, str) or not 5 <= len(message.strip()) <= 500 or "\0" in message:
        raise ValueError("Describe this branch checkpoint in 5–500 characters.")
    current = describe(root, pack, actor_id, allowed_packs=allowed_packs, selected=selected, can_manage_shared=can_manage_shared)
    if current["digest"] != expected_digest:
        raise ValueError("The branch or selected files changed. Refresh and review the new diff.")
    if not current["can_commit"]:
        raise ValueError("Use a named branch with an existing Git commit and choose product records to save.")
    if current["shared_selected"] and confirmed_shared is not True:
        raise ValueError("Review the complete shared-file diffs and explicitly confirm their inclusion. They may contain changes for other products.")
    base = Path(root).resolve()
    paths = [r["path"] for r in current["records"]]
    # --only commits these working files, preserving unrelated staged changes. add makes
    # new records known to Git; a failed commit leaves them visible in the index for retry.
    _git(base, ["add", "--", *paths])
    fresh = describe(root, pack, actor_id, allowed_packs=allowed_packs, selected=selected, can_manage_shared=can_manage_shared)
    if fresh["digest"] != expected_digest:
        raise ValueError("The files changed while preparing the commit. Review again; selected files remain staged.")
    with tempfile.TemporaryDirectory(prefix="rwd-branch-message-") as directory:
        body = Path(directory) / "message.txt"
        body.write_text(message.strip() + "\n", encoding="utf-8")
        _git(base, ["commit", "--only", "--file", str(body), "--", *paths])
    revision = _git(base, ["rev-parse", "HEAD"]).stdout.decode().strip()
    actual_branch = _git(base, ["symbolic-ref", "--quiet", "--short", "HEAD"], check=False).stdout.decode().strip()
    parents = _git(base, ["rev-list", "--parents", "-n", "1", revision]).stdout.decode().split()[1:]
    committed_paths = set(p.decode() for p in _git(base, ["diff-tree", "--no-commit-id", "--name-only", "-z", "-r", revision]).stdout.split(b"\0") if p)
    exact = all((blob.stdout.decode().strip() if blob.returncode == 0 else None) == row["git_after"]
                for row in current["records"]
                for blob in [_git(base, ["rev-parse", "--verify", f"{revision}:{row['path']}"], check=False)])
    exact = exact and actual_branch == current["branch"] and parents == [current["head"]] and committed_paths <= set(paths)
    return {"ok": exact, "commit": revision, "branch": actual_branch, "paths": paths,
            "message": ("Saved the reviewed records to your branch. This records work; it does not approve or release the product."
                        if exact else "Git created a commit whose branch, parent or files differ from this review. Inspect hooks and the commit in VS Code before continuing.")}
