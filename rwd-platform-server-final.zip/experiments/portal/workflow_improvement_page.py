"""Small explicit correction capture and review over the shared learning backend."""
import json
from pathlib import Path

import streamlit as st
import form_assistance as form_help

import workflow_improvement as workspace
import workflow_skills

PREFIX = "workflow_improvement_"
SKILL_LABELS = {
    "operate-rwd-product": "Workflow guidance", "draft-contract-record": "Scientific definitions",
    "answer-decisions": "Open questions", "propose-variable-name": "Variable naming",
    "propose-source-mapping": "Source mappings", "apply-source-verdicts": "Source review decisions",
    "next-cut": "Specification revisions", "implement-product-rule": "Implementation code",
}


def current_route(root, state, *, pack, actor_id, section, allowed_packs):
    """Bind feedback to the actual open task, never to copied conversation text."""
    import connected_workflow as workflow
    import connected_workflow_page as navigation

    current = state.get(navigation.KEY)
    if workflow.valid(current, pack=pack, actor_id=actor_id, section=section, allowed_packs=allowed_packs):
        route = current["route"]
        if route == "specialist_assistant":
            saved = state.get("specialist_ws_context")
            kind = state.get("specialist_ws_kind") if saved and saved[:3] == (str(root), pack, actor_id) else (current.get("params") or {}).get("kind")
            if kind in {"source", "validation", "implementation"}:
                return workflow_skills.binding_for(route, kind=kind)["name"]
    else:
        route = {"Home": "progress", "New product": "progress", "Flow": "progress",
                 "Status": "progress", "Open questions": "questions", "Plan changes": "plan_changes",
                 "Search & definitions": "knowledge_explorer", "Studies": "study_protocol",
                 "Agent": "governed_check"}.get(section)
    dialog = state.get("flow_dialog") or {}
    if route == "progress" and section == "Flow" and dialog.get("pack") == pack and dialog.get("actor") == actor_id:
        route = state.get("flow_resolution_action") or dialog.get("card_key") or route
    if route in {"scientific_draft", "g2_draft"}:
        editor_context = state.get("scientific_definition_context")
        if editor_context and editor_context[:3] == (str(root), pack, actor_id):
            import scientific_definition_editor as editor
            if state.get("scientific_definition_section") == editor.SECTIONS[3]:
                route = "scientific_draft.source"
    if route is None:
        return None
    try:
        workflow_skills.binding_for(route)
    except ValueError:
        return None
    return route


def _context(prefix, root, actor_id, route, permission, scope):
    context = (str(Path(root).resolve()), actor_id, route, permission, scope)
    if st.session_state.get(prefix + "context") != context:
        for key in list(st.session_state):
            if str(key).startswith(prefix):
                st.session_state.pop(key, None)
        st.session_state[prefix + "context"] = context


def _report(root, actor_id, route):
    try:
        report = workspace.describe(root, actor_id, route)
    except (ValueError, OSError, TypeError, KeyError):
        st.warning("The shared correction library is unavailable. Check its branch files and reopen this step.")
        return None
    if not report["ok"]:
        st.warning(report["errors"][0])
        return None
    return report


def _action(call, prefix, notice):
    try:
        result = call()
    except workspace.Invalid as error:
        st.error(str(error))
        return
    except (ValueError, OSError, TypeError, KeyError):
        st.error("This correction could not be updated. Refresh its current branch record and try again.")
        return
    st.session_state[prefix + "notice"] = notice(result) if callable(notice) else notice
    st.rerun()


def _legacy(root, actor_id, *, can_review, prefix, allowed_packs):
    try:
        initial = workspace.legacy_preview(root, actor_id, allowed_packs=allowed_packs)
    except workspace.Invalid as error:
        st.warning(str(error))
        return
    if not initial.get("rows"):
        return
    with st.expander("Bring older lessons into this workflow"):
        st.caption("Preserve the original lesson and author, then use the same checks, review and withdrawal as new feedback. Importing does not enable guidance.")
        skills, scopes = {}, {}
        for row in initial["rows"]:
            identifier = row["id"]
            st.markdown("**" + identifier + " · " + row["context"] + "**")
            st.text(row["right"])
            st.caption("Original author: " + row.get("source_by", "Not recorded") + " · " + row.get("source_date", "Not recorded"))
            if row.get("imported_id"):
                st.caption("Already imported. Continue with its saved improvement record below.")
                continue
            options = list(SKILL_LABELS)
            chosen = row.get("skill", "operate-rwd-product")
            skills[identifier] = st.selectbox("Workflow step for " + identifier, options,
                index=options.index(chosen) if chosen in options else 0, format_func=SKILL_LABELS.get,
                key=prefix + "legacy_skill_" + identifier)
            scope_options = ["Keep original context unresolved", "Across the workflow", *sorted(set(allowed_packs or []))]
            choice = st.selectbox("Where " + identifier + " applies", scope_options,
                key=prefix + "legacy_scope_" + identifier,
                help="Use a product scope for scientific or source-specific lessons. Unresolved context is retained for review and is excluded from assistance.")
            if choice == "Across the workflow":
                scopes[identifier] = {"kind": "global"}
            elif choice != "Keep original context unresolved":
                scopes[identifier] = {"kind": "packs", "packs": [choice]}
        if not skills:
            return
        try:
            preview = workspace.legacy_preview(root, actor_id, skill_by_id=skills, scope_by_id=scopes,
                allowed_packs=allowed_packs)
        except workspace.Invalid as error:
            st.warning(str(error))
            return
        if st.session_state.get(prefix + "legacy_digest") != preview["digest"]:
            st.session_state[prefix + "legacy_confirm"] = False
            st.session_state[prefix + "legacy_digest"] = preview["digest"]
        confirmed = st.checkbox("I reviewed these original lessons and their proposed workflow scopes.", key=prefix + "legacy_confirm")
        if st.button("Import older lessons for review", key=prefix + "legacy_import", disabled=not(can_review and confirmed)):
            _action(lambda: workspace.import_legacy(root, actor_id, expected_digest=preview["digest"],
                skill_by_id=skills, scope_by_id=scopes, allowed_packs=allowed_packs,
                confirmed=confirmed, can_review=can_review), prefix,
                "Older lessons now have saved improvement records. Review their scope, run the linked checks and inspect the guidance before enabling it.")


def _response_text(outputs):
    """Show exact response prose first; retain complete structures in the details."""
    lines = []
    for output in outputs:
        if not isinstance(output, dict):
            continue
        payloads = [output.get("outcome", {}), output]
        for step in output.get("decisions", []):
            if isinstance(step, dict):
                payloads.append(step.get("decision", step))
        for payload in payloads:
            if isinstance(payload, dict):
                for key in ("answer", "summary", "question"):
                    value = payload.get(key)
                    values = [value]
                    # Canonical escalations retain a JSON summary as well as
                    # the decision. Show its exact prose without JSON escapes.
                    if key == "summary" and isinstance(value, str) and value.lstrip().startswith("{"):
                        try:
                            structured = json.loads(value)
                        except ValueError:
                            structured = None
                        if isinstance(structured, dict):
                            prose = [structured.get(field) for field in ("answer", "summary", "question")]
                            prose = [part for part in prose if isinstance(part, str) and part.strip()]
                            values = prose or values
                    for part in values:
                        if isinstance(part, str) and part.strip() and part not in lines:
                            lines.append(part)
    return lines


def _pair_result(record):
    st.caption("Saved comparison · " + record.get("created_at", "") + " · " + record.get("connection", {}).get("model", ""))
    if record.get("stale") or record.get("stale_at_completion"):
        st.warning("This is historical evidence: its source, correction, software or connection has changed. Prepare a fresh comparison before relying on it.")
    for pair in record.get("pairs", []):
        with st.expander(pair["case"]["goal"][:180], expanded=len(record.get("pairs", [])) == 1):
            st.caption("Review criterion: " + pair["case"].get("adjudicate", "Review the exact responses."))
            comparison = pair["comparison"]
            if comparison.get("valid_pair"):
                st.info("Both sides completed under comparable conditions. Review the answers to judge whether the correction helped.")
            else:
                st.warning("Inconclusive comparison. " + " ".join(comparison.get("inconclusive_reasons", [])))
            for col, side, label in zip(st.columns(2), ("before", "after"), ("Before · correction excluded", "After · correction available")):
                with col:
                    arm = pair[side]
                    st.markdown("**" + label + "**")
                    st.caption("Elapsed seconds: " + str(arm.get("elapsed_seconds") if arm.get("elapsed_seconds") is not None else "Unavailable"))
                    if arm.get("error"):
                        st.warning(arm["error"])
                    if lines := _response_text(arm.get("outputs", [])):
                        for line in lines:
                            st.write(line)
                    elif arm.get("outputs"):
                        st.caption("A structured response was recorded. Open the recorded details below to inspect it.")
                    else:
                        st.caption("No completed response was retained.")
            with st.expander("Recorded checks and delivered guidance"):
                st.json({"checks": comparison.get("checks", {}), "metrics": comparison.get("metrics", {}),
                    "before_guidance": pair["before"].get("delivery", []), "after_guidance": pair["after"].get("delivery", []),
                    "before_outputs": pair["before"].get("outputs", []), "after_outputs": pair["after"].get("outputs", [])}, expanded=False)
            st.caption("Mechanical checks do not grade scientific meaning. An unavailable cost is not zero cost, and a skipped skill is not a successful test of that skill.")


def _comparison(root, actor_id, row, *, can_review, prefix, pack, allowed_packs, local_demo, incoming_id=None):
    prefix += "comparison_"
    _context(prefix, root, actor_id, row["id"], (bool(can_review), bool(local_demo)),
        (row["digest"], pack, tuple(sorted(allowed_packs or []))))
    with st.expander("Compare answers before and after", expanded=bool(incoming_id)):
        st.caption("Run the same case with this correction excluded and available. This comparison uses the selected assistant and does not enable the correction for other requests.")
        products = sorted(p for p in set(allowed_packs or []) if p.startswith("products/"))
        if not products:
            st.info("Open a working product with reviewed AI-readable evidence to compare answers. Feedback and its software checks remain available here.")
            return
        if pack in products:
            selected_pack = pack
            st.caption("Comparison product: " + pack)
        else:
            selected_pack = st.selectbox("Product for this comparison", products, index=None, key=prefix + "product")
            if not selected_pack:
                return
        import correction_evaluation as comparison
        import portal_jobs
        import portal_jobs_page
        job_key = "comparison:" + selected_pack + ":" + row["id"]
        finished = portal_jobs_page.render(root, actor_id, action="correction_comparison", job_key=job_key,
            can_write=bool(can_review and local_demo), allowed_packs=allowed_packs, key=prefix + "job")
        if finished:
            if finished.get("ok"):
                st.caption("The action finished. Open its saved comparison below to inspect the current evidence and freshness.")
            else:
                st.warning((finished.get("errors") or ["The comparison did not finish."])[0])
        recent = comparison.recent(root, selected_pack, actor_id, allowed_packs=allowed_packs)
        retained = {r["id"]: r for r in recent if r.get("params", {}).get("correction_id") == row["id"]}
        if incoming_id in retained and st.session_state.get(prefix + "incoming") != incoming_id:
            st.session_state[prefix + "saved"] = incoming_id
            st.session_state[prefix + "incoming"] = incoming_id
        if retained:
            if st.session_state.get(prefix + "saved") not in retained:
                st.session_state.pop(prefix + "saved", None)
            saved_id = st.selectbox("Saved before/after comparison", list(retained), key=prefix + "saved",
                format_func=lambda value: retained[value]["updated_at"])
            result = comparison.read(root, selected_pack, actor_id, saved_id, allowed_packs=allowed_packs)
            if result.get("ok"):
                _pair_result(result)
            else:
                st.warning(result["errors"][0])
        options = comparison.options(root, selected_pack, actor_id, row["id"], allowed_packs=allowed_packs)
        if not options.get("ok"):
            st.info(options["errors"][0])
            return
        cfg = options["connection"]
        st.caption("Selected assistant: " + cfg.get("provider", "Unavailable") + " · " + cfg.get("model", ""))
        if not cfg.get("ok"):
            st.info("Connect the scientific assistant to run a comparison. No model call has been made.")
        st.markdown("**Included example**")
        st.text(row["eval_goal"])
        st.caption("This example is familiar to the correction's author. It is not an unseen test.")
        group = st.selectbox("Additional checks", ["No additional cases", "Human-authored cases", "Development software regressions", "Held-out software regressions"], key=prefix + "group")
        split = {"Development software regressions": "development", "Held-out software regressions": "heldout"}.get(group)
        choices = {}
        for entry in options["cases"]:
            case = entry["case"]
            if case["id"] == options["own_case_id"]:
                continue
            if ((split and case.get("split") == split) or
                    (group == "Human-authored cases" and case.get("evidence_mode") not in {"synthetic_software_regression", "reviewed_workflow_correction"})):
                choices[case["id"]] = case
        if any(value not in choices for value in st.session_state.get(prefix + "cases", [])):
            st.session_state[prefix + "cases"] = []
        extra = st.multiselect("Choose up to two additional cases", list(choices), key=prefix + "cases",
            max_selections=2, format_func=lambda value: choices[value]["goal"][:140]) if choices else []
        if split == "heldout":
            st.info("These failure families were reserved from development. Repeated runs are retests, not newly unseen evidence.")
        signature = (options["digest"], tuple(extra), selected_pack)
        if st.session_state.get(prefix + "selection") != signature:
            st.session_state.pop(prefix + "preview", None)
            st.session_state[prefix + "confirmed"] = False
            st.session_state[prefix + "selection"] = signature
        if st.button("Preview before/after comparison", key=prefix + "prepare", disabled=not(can_review and local_demo and cfg.get("ok"))):
            result = comparison.preview(root, selected_pack, actor_id, row["id"], extra,
                expected_digest=options["digest"], allowed_packs=allowed_packs)
            if result.get("ok"):
                st.session_state[prefix + "preview"] = result
                st.session_state[prefix + "confirmed"] = False
            else:
                st.warning(result["errors"][0])
        proposal = st.session_state.get(prefix + "preview")
        if proposal:
            st.write(str(len(proposal["cases"])) + " case(s), each run twice with the same connection and source snapshot.")
            st.caption("Each side permits up to four assistant calls and 90 seconds; the whole request is bounded to six minutes. Failed or interrupted calls are not retried automatically.")
            confirmed = st.checkbox("Run this exact before/after comparison and retain its results for review.", key=prefix + "confirmed")
            if st.button("Run before/after comparison", key=prefix + "run", disabled=not(can_review and local_demo and confirmed)):
                try:
                    portal_jobs.start(root, actor_id, action="correction_comparison", job_key=job_key,
                        arguments=dict(pack=selected_pack, proposal=proposal, confirmed=confirmed,
                            local_demo=local_demo, can_review=can_review),
                        confirmed=confirmed, can_write=bool(can_review and local_demo), allowed_packs=allowed_packs)
                    st.rerun()
                except (ValueError, OSError) as error:
                    st.warning(str(error))


def _records(root, actor_id, report, *, can_review, prefix, can_write=False, pack=None, allowed_packs=None, local_demo=False,
             incoming_correction=None, incoming_evaluation=None):
    import portal_jobs
    import portal_jobs_page
    rows = {row["id"]: row for row in report["records"]}
    if not rows:
        st.caption("No reusable corrections have been recorded here yet.")
        return
    if incoming_correction in rows and st.session_state.get(prefix + "incoming") != incoming_correction:
        st.session_state[prefix + "selected"] = incoming_correction
        st.session_state[prefix + "incoming"] = incoming_correction
    if st.session_state.get(prefix + "selected") not in rows:
        st.session_state.pop(prefix + "selected", None)
    selected = st.selectbox("Saved improvement", list(rows), key=prefix + "selected",
        format_func=lambda value: rows[value]["skill"] + " · " + rows[value]["status"] + " · " + rows[value]["context"][:70])
    row = rows[selected]
    check_job_key = "correction-check:" + selected
    completed_check = portal_jobs_page.render(root, actor_id, action="correction_check", job_key=check_job_key,
        can_write=bool(can_review and local_demo), allowed_packs=allowed_packs, key=prefix + "check_job")
    if completed_check and not completed_check.get("ok"):
        st.warning("The last linked check did not pass. Inspect this correction's current check result before continuing.")

    def start_check(confirmed):
        try:
            portal_jobs.start(root, actor_id, action="correction_check", job_key=check_job_key,
                arguments=dict(record_id=selected, selectors=row["default_tests"], expected_digest=row["digest"],
                    confirmed=confirmed, can_review=can_review),
                confirmed=confirmed, can_write=bool(can_review and local_demo), allowed_packs=allowed_packs)
            st.rerun()
        except (ValueError, OSError) as error:
            st.warning(str(error))
    if st.session_state.get(prefix + "record_digest") != row["digest"]:
        for action in ("check", "activate", "withdraw", "resolve_scope"):
            st.session_state[prefix + "confirm_" + action] = False
        st.session_state[prefix + "record_digest"] = row["digest"]
    st.caption("Recorded by " + row["created_by"] + " · " + row["skill"] + " · " + row["status"])
    applicability = row.get("scope") or {"kind": "global"}
    if applicability["kind"] == "packs":
        st.caption("Applies to: " + ", ".join(applicability["packs"]))
    elif applicability["kind"] == "legacy_context":
        st.warning("This older lesson's product context is unresolved. It is retained for review and is not used by assistants.")
    else:
        st.caption("Applies across this workflow skill.")
    for label, field in (("Observed behaviour or pattern", "wrong"), ("Guidance to reuse", "right"),
                         ("When it applies", "context"), ("Example request to evaluate", "eval_goal")):
        st.markdown("**" + label + "**")
        st.text(row[field])
    if applicability["kind"] != "legacy_context":
        import workflow_durable_fixes_page
        workflow_durable_fixes_page.render(root, actor_id, selected,
            can_write=bool(can_write and local_demo), can_review=can_review,
            allowed_packs=allowed_packs, key=prefix + "durable_")
    if applicability["kind"] == "legacy_context":
        choices = ["Across the workflow", *sorted(set(allowed_packs or []))]
        selected_scope = st.selectbox("Resolve where this older lesson applies", choices, index=None,
            key=prefix + "resolved_scope", placeholder="Choose its reviewed scope")
        if st.session_state.get(prefix + "resolved_scope_value") != selected_scope:
            st.session_state[prefix + "confirm_resolve_scope"] = False
            st.session_state[prefix + "resolved_scope_value"] = selected_scope
        confirmed = st.checkbox("I reviewed the original context and this lesson applies to the selected scope.",
            key=prefix + "confirm_resolve_scope")
        if st.button("Save the lesson's scope", key=prefix + "resolve_scope", disabled=not(can_review and confirmed and selected_scope)):
            new_scope = ({"kind": "global"} if selected_scope == "Across the workflow" else
                         {"kind": "packs", "packs": [selected_scope]})
            _action(lambda: workspace.resolve_legacy_scope(root, actor_id, selected, new_scope,
                expected_digest=row["digest"], allowed_packs=allowed_packs, confirmed=confirmed,
                can_review=can_review), prefix, "Scope recorded. Continue with the linked checks and guidance review.")
        return
    if row.get("stale_skill"):
        st.warning("This correction is inactive because the skill changed. Record updated feedback against the current instructions.")
    elif row["stale"]:
        st.warning("The skill or checked software changed. Review this correction against the current instructions and run fresh checks before enabling it.")
    check = row.get("check")
    if check:
        (st.success if check["passed"] else st.warning)(check["summary"])
    with st.expander("Linked software checks"):
        st.code("\n".join(row["default_tests"]), language="text")
        st.caption("These registered checks run locally for up to three minutes. They test software behaviour; a person must still review whether the correction is appropriate.")
    _comparison(root, actor_id, row, can_review=can_review, prefix=prefix, pack=pack,
        allowed_packs=allowed_packs, local_demo=local_demo,
        incoming_id=incoming_evaluation if incoming_correction == selected else None)
    if not can_review:
        st.info("A local reviewer can run the linked checks and enable this correction. Share the saved branch record through your normal Git review.")
        return
    if row["status"] in {"proposed", "checked", "check_failed"} and not row.get("stale_skill"):
        confirmed = st.checkbox("Run the linked software checks for this exact correction.", key=prefix + "confirm_check")
        if st.button("Run linked checks", key=prefix + "check", disabled=not confirmed):
            start_check(confirmed)
        if row["can_activate"]:
            reviewed = st.checkbox("I reviewed this correction and want relevant assistants in this branch to use it.", key=prefix + "confirm_activate")
            if st.button("Use correction in future assistance", key=prefix + "activate", disabled=not reviewed):
                _action(lambda: workspace.activate(root, actor_id, selected, expected_digest=row["digest"],
                    confirmed=reviewed, can_review=can_review), prefix,
                    "Correction enabled for the relevant assistants in this branch. Share it through Git review and merge; other checkouts receive it when they pull.")
        else:
            st.caption("Next: run passing checks, then review and explicitly enable this correction.")
    elif row["status"] == "active":
        if row.get("in_effect", not row["stale"]):
            st.info("This correction is enabled for its relevant assistants. Git review, merge and pull carry it to other checkouts; existing scientific decisions are unchanged.")
        recheck = st.checkbox("Recheck this active correction against the current software.", key=prefix + "confirm_check")
        st.caption("Passing checks retain its current review. A failed check stops its reuse until the issue is resolved and the correction is reviewed again.")
        if st.button("Recheck linked software", key=prefix + "check", disabled=not recheck):
            start_check(recheck)
        confirmed = st.checkbox("Stop using this correction in future assistance.", key=prefix + "confirm_withdraw")
        if st.button("Stop using correction", key=prefix + "withdraw", disabled=not confirmed):
            _action(lambda: workspace.withdraw(root, actor_id, selected, expected_digest=row["digest"],
                confirmed=confirmed, can_review=can_review), prefix,
                "Correction withdrawn. Its review history stays on the branch.")
    elif row["status"] == "withdrawn":
        st.caption("This correction is withdrawn. Record a new correction if the guidance needs to change.")
    elif row["status"] == "retired":
        st.caption("This lesson was replaced by a reviewed durable fix. Its history remains available; it no longer enters assistant prompts.")
    if row["status"] in {"retired", "withdrawn"}:
        import workflow_skills
        loop = workflow_skills.learning()
        if loop.correction_relative_path(root, selected) == (loop.CORRECTIONS / (selected + ".yaml")).as_posix():
            with st.expander("Keep this completed lesson in history"):
                st.caption("Move its exact record into historical storage. Its identity, provenance and review remain readable and share through the same Git workflow.")
                archive_reviewed = st.checkbox("Keep this completed record as immutable history.", key=prefix + "archive_confirm")
                if st.button("Move completed lesson to history", key=prefix + "archive",
                    disabled=not (archive_reviewed and can_review and can_write and local_demo)):
                    _action(lambda: loop.archive_correction(root, selected, row["digest"], actor_id), prefix,
                        "Completed lesson retained in history. Review its file move in Save work to my branch.")
        else:
            st.caption("This completed lesson is retained in historical storage.")


def render_review(root, actor_id, *, can_review, can_write=False, key="review", pack=None, allowed_packs=None, local_demo=False,
                  correction_id=None, evaluation_id=None):
    """Read and review every skill's shared corrections, without requiring a product."""
    prefix = PREFIX + key + "_"
    _context(prefix, root, actor_id, None, (bool(can_review), bool(can_write)), (pack, tuple(sorted(allowed_packs or [])), local_demo))
    st.markdown("**Reviewed improvements across the workflow**")
    st.caption(workspace.NOTICE)
    report = _report(root, actor_id, None)
    if report is None:
        return
    if notice := st.session_state.pop(prefix + "notice", None):
        st.success(notice)
    _legacy(root, actor_id, can_review=can_review, prefix=prefix, allowed_packs=allowed_packs)
    _records(root, actor_id, report, can_review=can_review, prefix=prefix,
        can_write=can_write, pack=pack, allowed_packs=allowed_packs, local_demo=local_demo,
        incoming_correction=correction_id, incoming_evaluation=evaluation_id)


def render_step(root, actor_id, route, *, can_write, can_review=False, scope=None,
                pack=None, allowed_packs=None, local_demo=False, key="step", prepared=None):
    """Reuse the explicit reviewed form in the sidebar or beside one interaction."""
    prefix = PREFIX + key + "_"
    _context(prefix, root, actor_id, route, (bool(can_write), bool(can_review)),
        (scope, pack, tuple(sorted(allowed_packs or [])), local_demo,
         prepared.get("digest") if isinstance(prepared, dict) else None))
    if prepared is not None:
        try:
            workspace.validate_prepared(root, actor_id, prepared, pack=pack, allowed_packs=allowed_packs)
            if workflow_skills.binding_for(route)["name"] != prepared["skill"]:
                raise workspace.Invalid("Keep the feedback with the workflow that produced this answer.")
        except workspace.Invalid as error:
            st.warning(str(error))
            return
        if st.session_state.get(prefix + "prepared_digest") != prepared["digest"]:
            for field, value in prepared["fields"].items():
                st.session_state[prefix + field] = value
            st.session_state[prefix + "prepared_digest"] = prepared["digest"]
            st.session_state[prefix + "confirm_save"] = False
    if st.session_state.pop(prefix + "reset_save", False):
        st.session_state[prefix + "confirm_save"] = False
    for field in ("wrong", "right", "applies", "goal"):
        key = prefix + field
        if key in st.session_state:
            st.session_state[key] = st.session_state[key]
    if route is None:
        return
    with st.expander("Review prepared feedback" if prepared else "Improve this step", expanded=bool(prepared)):
        if prepared is None and st.toggle("Review shared improvements", key=prefix + "review_all"):
            render_review(root, actor_id, can_review=can_review, key="sidebar_review",
                can_write=can_write, pack=pack, allowed_packs=allowed_packs, local_demo=local_demo)
            return
        report = _report(root, actor_id, route)
        if report is None:
            return
        st.caption("Relevant skill: " + report["skill"])
        st.caption("Inspect and edit these excerpts before saving. This is proposed feedback; it does not establish that the revised scientific answer is correct." if prepared else
                   "Record a reusable correction or successful pattern using a sanitized example. Saved feedback stays on this Git branch until you share it through Git review and merge.")
        if notice := st.session_state.pop(prefix + "notice", None):
            st.success(notice)
        wrong = form_help.field(st.text_area, "What happened or worked well?", key=prefix + "wrong", max_chars=1800,
            placeholder="Example: Returning from source mapping opened the first row.", binding=st.session_state.get(prefix + "context"))
        right = form_help.field(st.text_area, "What should the assistant do next time?", key=prefix + "right", max_chars=1800,
            placeholder="Example: Preserve the selected specification row when returning to its editor.", binding=st.session_state.get(prefix + "context"))
        context = form_help.field(st.text_area, "When should this guidance apply?", key=prefix + "applies", max_chars=1800,
            placeholder="Example: Moving between a definition and its source mapping.", binding=st.session_state.get(prefix + "context"))
        goal = form_help.field(st.text_area, "An example request to test", key=prefix + "goal", max_chars=1800,
            placeholder="Example: Take me back to the definition I was editing.", binding=st.session_state.get(prefix + "context"))
        current = (wrong, right, context, goal)
        applies = {"kind": "global"}
        if pack and pack in (allowed_packs or []):
            where = st.radio("Where should this guidance apply?", ["This product", "Across the workflow"],
                key=prefix + "scope_choice", help="Keep scientific and source-specific lessons with their product. General workflow lessons can be shared across products.")
            if where == "This product":
                applies = {"kind": "packs", "packs": [pack]}
        if st.session_state.get(prefix + "input") != (current, applies):
            st.session_state[prefix + "confirm_save"] = False
            st.session_state[prefix + "input"] = (current, applies)
        confirmed = st.checkbox("I removed private data and credentials and want to save this reusable feedback on my branch.", key=prefix + "confirm_save")
        if not can_write:
            st.info("You can read improvements here. A local author saves reusable feedback and a local reviewer enables it.")
        if st.button("Save reusable feedback", key=prefix + "save", disabled=not(can_write and confirmed and all(value.strip() for value in current))):
            def save():
                row = workspace.propose(root, actor_id, route, wrong, right, context, goal,
                    confirmed=confirmed, can_write=can_write, scope=applies, allowed_packs=allowed_packs,
                    provenance=prepared["provenance"] if prepared else None)
                st.session_state[prefix + "selected"] = row["id"]
                st.session_state[prefix + "reset_save"] = True
                return row
            _action(save, prefix, lambda row: "This exact feedback is already enabled. Its current review record is shown below."
                if row["status"] == "active" else "Feedback saved or reopened. Review its current record below; passing checks and explicit review are required before it can be enabled.")
        st.caption("Only the reviewed form fields and an interaction reference are saved. Source files and the full conversation are not copied." if prepared else
                   "Chat transcripts and source data are not copied. Enabling feedback changes reusable guidance, not a scientific decision, model weights or a product release.")
        if prepared is None:
            _records(root, actor_id, report, can_review=can_review, prefix=prefix,
                can_write=can_write, pack=pack, allowed_packs=allowed_packs, local_demo=local_demo)
        else:
            st.caption("Continue checks and review from Improve this step → Review shared improvements.")
