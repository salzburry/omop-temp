"""Share one checked clinical-meaning proposal through the existing owned handoffs.

The public snapshot contains only the explicitly selected proposal and source-row
context. It never opens another author's private folder for a reviewer or applies
the semantic YAML. A handoff response is a work update, not scientific approval.
"""
from __future__ import annotations

import json
import re
import subprocess

import yaml

import handoffs
import science_workspace as science

ACTION_PREFIX = "science-review:"
MAX_SNAPSHOT = 2 * 1024 * 1024
NOTICE = "Shared for review only. The proposed binding is not applied, authenticated or approved; a handoff response does not release a product."


def _failure(error):
    return {"ok": False, "errors": [str(error)]}


def _location(root, pack, proposal_id, allowed_packs):
    product, pack = handoffs._pack_dir(root, pack, allowed_packs)
    if not re.fullmatch(r"[0-9a-f]{32}", str(proposal_id)):
        raise ValueError("Choose a clinical-standard proposal from this product.")
    directory = science._safe(product / ".portal-drafts/science-reviews")
    return pack, science._safe(directory / (proposal_id + ".json"))


def _read(path):
    if path.stat().st_size > MAX_SNAPSHOT:
        raise ValueError("The shared review snapshot exceeds its metadata limit.")
    doc = json.loads(science._safe(path).read_bytes())
    signed = dict(doc)
    digest = signed.pop("snapshot_sha256", None)
    if digest != science._hash(signed):
        raise ValueError("The shared review snapshot changed after it was sent. Ask its author to share a fresh proposal.")
    return doc


def share(root, pack, actor_id, proposal_id, *, expected_proposal_digest, owner, note,
          allowed_packs=None, local_demo=False, can_write=False):
    try:
        if local_demo is not True or can_write is not True:
            raise ValueError("Sharing a proposal requires an authorized local editing session.")
        if owner not in {"Science", "Reviewer", "Engineering"}:
            raise ValueError("Choose Science, Reviewer or Engineering to review this proposal.")
        note = handoffs._text(note, "what the reviewer should examine")
        result = science.read(root, pack, actor_id, proposal_id, allowed_packs=allowed_packs)
        if not result["ok"]:
            return result
        proposal = result["proposal"]
        if proposal["route"] != "clinical_standards" or proposal.get("draft_only") is not True or proposal.get("approval_created") is not False:
            raise ValueError("This handoff is for a clinical-standard proposal.")
        if expected_proposal_digest != proposal["payload_sha256"]:
            raise ValueError("The selected proposal differs from the one displayed. Reopen it before sharing.")
        base, pack, _owner, _folder, scope = science._scope(root, pack, actor_id, allowed_packs)
        files = science._inputs(base, scope)
        if science._digest(files) != proposal["input_digest"]:
            raise ValueError("The product or reference evidence changed. Revise and validate a fresh proposal before sharing.")
        checked = science._run(files, {"route": "clinical_standards", "pack": pack, "scope": sorted(scope),
                                      "operation": "stage", "values": proposal["values"]})
        if checked.get("errors") or any(checked.get(key) != proposal.get(key) for key in
                                        ("artifact", "diff", "findings", "validators", "summary")):
            raise ValueError("The canonical validation or proposed diff changed. Revise and review it before sharing.")
        # Revalidation retains findings: sharing an unresolved question must not turn it into a verdict.
        selected_inputs = science._inputs(base, {pack})
        public = {key: proposal[key] for key in ("id", "pack", "route", "title", "created_at", "values",
                                                 "artifact", "diff", "findings", "validators", "summary",
                                                 "draft_only", "approval_created", "payload_sha256")}
        public["review_context"] = checked["review_context"]
        snapshot = {"schema_version": 1, "root": str(base), "pack": pack, "proposal": public,
                    "selected_input_digest": science._digest(selected_inputs), "notice": NOTICE}
        snapshot["snapshot_sha256"] = science._hash(snapshot)
        raw = json.dumps(snapshot, indent=2, ensure_ascii=False).encode()
        if len(raw) > MAX_SNAPSHOT:
            raise ValueError("Keep the shared review to one bounded clinical proposal.")
        action = ACTION_PREFIX + proposal_id + ":" + snapshot["snapshot_sha256"]
        details = (f"Review clinical meaning for {proposal['values']['variable']}. "
                   f"Proposal {proposal_id}; snapshot digest {snapshot['snapshot_sha256']}. "
                   f"The exact diff, source context and unresolved validator findings are attached below. "
                   f"{note} {NOTICE}")
        handoffs._text(details, "the review request")
        # Check again after canonical readers and before publishing any private content.
        if science._digest(science._inputs(base, scope)) != proposal["input_digest"]:
            raise ValueError("Evidence changed during validation. Nothing was shared; prepare a fresh proposal.")
        _pack, path = _location(base, pack, proposal_id, allowed_packs)
        created = False
        if path.exists():
            existing = _read(path)
            if existing != snapshot:
                raise ValueError("This proposal was already shared with a different snapshot. Create a new proposal.")
        else:
            path.parent.mkdir(parents=True, exist_ok=True)
            science._safe(path)
            try:
                with path.open("xb") as out:
                    created = True
                    out.write(raw)
            except BaseException:
                # Only this exclusive creation owns a partial new file.
                if created and path.exists():
                    path.unlink()
                raise
        try:
            document = handoffs.create(base, pack, title="Review clinical meaning: " + str(proposal["values"]["variable"]),
                owner=owner, note=details, requested_by=actor_id, action_id=action,
                allowed_packs=allowed_packs, local_demo=local_demo, can_view=True)
        except (handoffs.Refused, OSError, ValueError) as error:
            matching = [row for row in handoffs.listing(base, pack, allowed_packs=allowed_packs, include_closed=False)
                        if row.get("action_id") == action]
            if matching:
                return {"ok": True, "handoff": matching[0], "snapshot": snapshot, "already_shared": True,
                        "message": "This exact proposal is already shared. Its existing owner and request note remain unchanged.", "errors": []}
            if created and path.exists() and path.read_bytes() == raw:
                path.unlink()
            raise error
        return {"ok": True, "handoff": document, "snapshot": snapshot, "errors": []}
    except (handoffs.Refused, OSError, ValueError, TypeError, KeyError, AttributeError,
            yaml.YAMLError, subprocess.TimeoutExpired) as error:
        return _failure(error)


def load(root, pack, handoff_id, *, allowed_packs=None):
    """Read the published selection only; never read the author's other private work."""
    try:
        document = handoffs.load(root, pack, handoff_id, allowed_packs=allowed_packs)
        match = re.fullmatch(re.escape(ACTION_PREFIX) + r"([0-9a-f]{32}):([0-9a-f]{64})", document.get("action_id", ""))
        if not match:
            raise ValueError("This handoff does not carry a clinical review snapshot.")
        name, path = _location(root, pack, match[1], allowed_packs)
        snapshot = _read(path)
        from pathlib import Path
        base = Path(root).resolve()
        if (document.get("pack") != name or snapshot.get("pack") != name or snapshot.get("root") != str(base)
                or snapshot.get("snapshot_sha256") != match[2] or snapshot["proposal"].get("id") != match[1]
                or snapshot["proposal"].get("pack") != name or snapshot["proposal"].get("route") != "clinical_standards"
                or snapshot["proposal"].get("draft_only") is not True or snapshot["proposal"].get("approval_created") is not False):
            raise ValueError("The handoff and review snapshot do not identify the same product and proposal.")
        stale = science._digest(science._inputs(base, {name})) != snapshot["selected_input_digest"]
        return {"ok": True, "handoff": document, "snapshot": snapshot, "stale": stale, "errors": []}
    except (handoffs.Refused, OSError, ValueError, TypeError, KeyError, AttributeError, yaml.YAMLError) as error:
        return _failure(error)
