"""The exact selected clinical proposal as visible to an authorized reviewer."""
import json

import streamlit as st

import science_review_handoffs as backend


def render_snapshot(root, pack, handoff_id, *, allowed_packs):
    result = backend.load(root, pack, handoff_id, allowed_packs=allowed_packs)
    if not result["ok"]:
        for error in result["errors"]:
            st.error(error)
        return None
    snapshot = result["snapshot"]
    proposal = snapshot["proposal"]
    st.markdown("**Clinical proposal attached for review**")
    st.caption(backend.NOTICE)
    st.write(proposal["summary"])
    st.caption("Proposal " + proposal["id"] + " · snapshot " + snapshot["snapshot_sha256"])
    if result["stale"]:
        st.warning("The product or reference evidence changed after this proposal was shared. This remains the exact historical proposal; ask its author for a fresh validated proposal before acting on it.")
    context = proposal.get("review_context") or {}
    with st.expander("Selected scientific definition and source context"):
        st.write("Variable: " + str(context.get("variable") or proposal["values"]["variable"]))
        st.write("Source row: " + str(context.get("item_id") or "Not linked"))
        st.write(context.get("derivation") or "No interpretation recorded.")
        st.json(context.get("spec") or {})
        st.caption("Recorded status: " + str(context.get("status") or "Not declared"))
    st.write("Proposed choice: " + str(proposal["values"].get("axis")) + " = " + str(proposal["values"].get("value")))
    st.write("Disposition: " + str(proposal["values"].get("disposition")))
    if proposal.get("diff"):
        st.code(proposal["diff"], language="diff")
    else:
        st.info("This disposition proposes no semantic-file change; its rationale and remaining questions still need review.")
    with st.expander("Canonical validation and remaining questions", expanded=bool(proposal["findings"])):
        st.caption("Checked with: " + "; ".join(proposal["validators"]))
        for finding in proposal["findings"]:
            st.write(str(finding))
        if not proposal["findings"]:
            st.write("No findings were reported by these checks. Review still requires the responsible person's judgment.")
    st.download_button("Download the shared review snapshot", json.dumps(snapshot, indent=2, ensure_ascii=False),
                       file_name="clinical-review-" + proposal["id"] + ".json", mime="application/json",
                       key="science_review_download_" + handoff_id)
    st.caption("Use the response below to record findings or request changes. 'Done' closes this work request; it does not apply the proposed YAML or approve its scientific meaning.")
    if st.button("Open the current clinical binding", key="science_review_current_" + handoff_id):
        return {"route": "clinical_standards", "params": {"variable": proposal["values"]["variable"],
                "item_id": context.get("item_id")}}
    return None
