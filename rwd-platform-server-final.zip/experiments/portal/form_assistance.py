"""Chat prepares the existing visible draft widgets, never save/approval controls.

Pages opt in explicitly with field(existing_widget, ...). Metadata is derived
from those widgets rather than a second set of product forms. A complete render
is checked before the next render applies edits; existing callbacks invalidate
their previews and maintain their own draft caches.
"""
from __future__ import annotations

import copy
import hashlib
import json
import math
import re
from pathlib import Path

import streamlit as st

KEY = "chat_form_"
KINDS = {"text_input", "text_area", "number_input", "selectbox", "multiselect", "radio"}
MAX_FIELDS = 80
MAX_EDITS = 16
MAX_TEXT = 4000


def validation_messages(errors):
    """Bound complete displayed findings; exclude credentials and workstation paths."""
    messages, omitted = [], 0
    for error in errors or []:
        if not isinstance(error, str) or not error.strip():
            continue
        # Worksheet names are exact identifiers: an internal double space can
        # distinguish two sheets implicated in the same collision diagnostic.
        text = error.replace("\r\n", "\n").replace("\r", "\n").replace("\n", " ").strip()
        if re.search(r"\b(?:sk-[A-Za-z0-9_-]{12,}|Bearer\s+\S+|(?:api[_-]?key|password|access_token)\s*[:=])", text, re.I):
            text = "A validation detail contains restricted connection information. Inspect the local run details with your data expert."
        text = re.sub(r"(?:[A-Za-z]:[\\/]|\\\\)[^\n\r]*?(?=[\"'](?:[,.: ]|$)|$)", "[local path]", text)
        text = re.sub(r"/(?:Users|home|tmp|private|var)/[^\s\"']+", "[local path]", text)
        if len(text) > 600 or len(messages) >= 6:
            omitted += 1
        elif text not in messages:
            messages.append(text)
    if omitted and not messages:
        messages.append("A current validation failure is too long to include in chat. Inspect its complete details below before continuing.")
    return messages, omitted


def record_validation(errors, *, title="Current form validation", action_id="", input_digest="", primary=False,
                      status="blocked"):
    """Publish the form's displayed errors, retaining draft fields unchanged."""
    if status not in {"blocked", "needs_recheck"}:
        raise ValueError("A displayed validation must be blocked or need a fresh check.")
    if not st.session_state.get(KEY + "scope"):
        return
    messages, omitted = validation_messages(errors)
    if not messages and not omitted:
        return
    current = st.session_state.get(KEY + "validation_current") or {}
    combined, extra = validation_messages([*messages, *(current.get("blockers") or [])] if primary else
                                         [*(current.get("blockers") or []), *messages])
    if current.get("primary") and not primary:
        title, action_id, input_digest = current["title"], current["action_id"], current["source_digest"]
        status = current["status"]
    st.session_state[KEY + "validation_current"] = {"status": status, "title": str(title)[:160],
        "action_id": str(action_id or st.session_state.get("flow_resolution_action") or "")[:100],
        "blockers": combined, "blockers_omitted": omitted + extra,
        "source_digest": str(input_digest)[:128], "primary": bool(primary or current.get("primary"))}


def validation_context():
    """Last complete render's validation, bound to current widget values."""
    record = st.session_state.get(KEY + "validation")
    if not isinstance(record, dict) or record.get("scope") != st.session_state.get(KEY + "scope"):
        return None
    catalog = st.session_state.get(KEY + "catalog") or {}
    revision = digest([(entry["id"], entry["schema"], st.session_state.get(entry["key"], entry["value"]))
                       for entry in catalog.values()])
    public = {key: value for key, value in record.items() if key not in {"scope", "field_revision", "source_digest"}}
    if revision != record.get("field_revision"):
        public["status"] = "needs_recheck"
        public["input_digest"] = digest([record["input_digest"], revision])
    return public


def _commit_validation(current):
    observed = st.session_state.get(KEY + "validation_current")
    previous = st.session_state.get(KEY + "validation")
    if observed is None and previous is None:
        return False
    next_validation = dict(observed or {"status": "clear", "title": "Current form validation", "action_id": "",
        "blockers": [], "blockers_omitted": 0, "source_digest": ""})
    next_validation["scope"] = st.session_state.get(KEY + "scope")
    next_validation["field_revision"] = digest([(entry["id"], entry["schema"], entry["value"]) for entry in current.values()])
    next_validation["input_digest"] = digest(next_validation)
    st.session_state[KEY + "validation"] = next_validation
    if previous == next_validation:
        return False
    for suffix in ("proposal", "apply", "applied", "applied_feedback"):
        st.session_state.pop(KEY + suffix, None)
    return True


def digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, ensure_ascii=False, default=str, allow_nan=False).encode()).hexdigest()


def empty(value):
    return value is None or value == [] or isinstance(value, str) and value.strip() in {"", "TODO", "REPLACE_ME"}


def _scalar(value):
    return value is None or type(value) in {str, int, bool} or type(value) is float and math.isfinite(value)


def _scope(root, pack, actor_id, page, route, allowed_packs, can_write):
    return digest({"root": str(Path(root).resolve()), "pack": pack, "actor": actor_id,
        "page": page, "route": route, "scope": sorted(allowed_packs or []), "write": bool(can_write)})


def _workflow_revision():
    """Recheck the source and displayed failures before touching draft widgets.

    begin() precedes the shared chat, so its later freshness check cannot guard
    this rerun's pending assignments. Reuse its checked-state reader here, with
    only the current form's navigation and identity (never model content).
    """
    reader = st.session_state.get(KEY + "workflow_reader")
    if reader is None:
        return None
    try:
        revision = reader(copy.deepcopy(st.session_state[KEY + "workflow_identity"]))
    except Exception:
        # The page may still render its draft while an input cannot be read,
        # but neither a new nor an earlier suggestion can be applied then.
        return "unavailable"
    return revision if isinstance(revision, str) and re.fullmatch(r"[0-9a-f]{64}", revision) else "unavailable"


def _forget_feedback():
    """Discard only this form interaction's unsaved feedback when its owner changes."""
    st.session_state.pop(KEY + "feedback", None)
    ui_key = st.session_state.pop(KEY + "feedback_ui_key", None)
    if ui_key:
        import interaction_feedback_page
        interaction_feedback_page.clear(ui_key)


def _observe_feedback(catalog, *, live=False):
    record = st.session_state.get(KEY + "feedback")
    if not record:
        return None
    if record["scope"] != st.session_state.get(KEY + "scope") or not st.session_state.get(KEY + "enabled"):
        _forget_feedback()
        return None
    matches = [(field, catalog.get(field["id"])) for field in record["fields"]]
    if not any(entry is not None for _, entry in matches) or any(
            entry is not None and field["binding"] != entry["binding"] for field, entry in matches):
        _forget_feedback()
        return None
    for field, entry in matches:
        field["current_present"] = entry is not None
        if entry is not None:
            field["current"] = copy.deepcopy(st.session_state.get(entry["key"], entry["value"]) if live else entry["value"])
    record["outcome"] = "rejected" if record["state"] == "rejected" else "edited" if record["state"] == "applied" and any(
        field["current_present"] and field["applied_present"] and field["current"] != field["applied"] for field in record["fields"]
    ) else None
    return record


def feedback():
    """Current exact form interaction; read-only data for the existing feedback form."""
    record = _observe_feedback(st.session_state.get(KEY + "catalog") or {}, live=True)
    return copy.deepcopy(record) if record else None


def _feedback_record(proposal, state, catalog):
    interaction = proposal.get("interaction")
    if not interaction:
        return
    fields = []
    for change in proposal["entries"]:
        entry = catalog.get(change["id"])
        fields.append({"id": change["id"], "label": change["label"], "binding": entry["binding"] if entry else change["binding"],
            "before": copy.deepcopy(change["before"]), "proposed": copy.deepcopy(change["value"]),
            "applied": copy.deepcopy(entry["value"]) if state == "applied" and entry is not None else None,
            "applied_present": state == "applied" and entry is not None,
            "current": copy.deepcopy(entry["value"]) if entry is not None else None, "current_present": entry is not None})
    if fields:
        _forget_feedback()
        st.session_state[KEY + "feedback"] = {**copy.deepcopy(interaction), "scope": proposal["scope"],
            "state": state, "fields": fields, "outcome": "rejected" if state == "rejected" else None}


def begin(root, pack, actor_id, *, page, route=None, allowed_packs=None, can_write=False, workflow_reader=None):
    """Call after navigation/identity resolution and before the shared chat."""
    can_write = bool(can_write and (not pack or pack in (allowed_packs or [])))
    scope = _scope(root, pack, actor_id, page, route, allowed_packs, can_write)
    if st.session_state.get(KEY + "scope") == scope and st.session_state.get(KEY + "validation_current"):
        # A dialog can rerun as a fragment without reaching the outer finish().
        # Commit its displayed errors before this full rerun reads the chat.
        current = st.session_state.get(KEY + "current") or st.session_state.get(KEY + "catalog") or {}
        st.session_state[KEY + "catalog"] = current
        _commit_validation(current)
    if st.session_state.get(KEY + "scope") != scope:
        _forget_feedback()
        for name in ("catalog", "proposal", "apply", "applied", "applied_feedback", "notice", "undo", "validation", "validation_current"):
            st.session_state.pop(KEY + name, None)
    st.session_state[KEY + "scope"] = scope
    st.session_state[KEY + "enabled"] = bool(can_write)
    st.session_state[KEY + "page"] = page
    st.session_state[KEY + "pack"] = pack
    st.session_state[KEY + "owner"] = digest([str(Path(root).resolve()), actor_id])
    st.session_state[KEY + "workflow_identity"] = {"root": str(Path(root).resolve()), "pack": pack,
        "actor": actor_id, "page": page, "route": copy.deepcopy(route) if isinstance(route, dict) else {}}
    st.session_state[KEY + "workflow_reader"] = workflow_reader
    deferred = st.session_state.get(KEY + "deferred")
    if deferred and deferred["owner"] != st.session_state[KEY + "owner"]:
        st.session_state.pop(KEY + "deferred", None)
    st.session_state[KEY + "current"] = {}
    st.session_state[KEY + "validation_current"] = None
    pending = st.session_state.pop(KEY + "apply", None)
    if not pending:
        return
    catalog = st.session_state.get(KEY + "catalog") or {}
    try:
        edits = _checked(pending, catalog, scope, live=True)
        if not can_write:
            raise ValueError("Draft editing is no longer available for this identity.")
    except ValueError as error:
        st.session_state[KEY + "notice"] = {"kind": "warning", "text": str(error)}
        return
    # All targets are checked before any field is changed. Only opted-in widget
    # keys can be assigned; buttons, approvals and arbitrary state are absent.
    # Existing callbacks also maintain canonical answers and hidden draft caches.
    # Keep those changes in the same transaction as the visible widget values.
    # Copy only data containers: runtime/provider objects can be noncopyable and
    # remain opaque references, just as they do during an ordinary widget edit.
    def clone_state(value, memo):
        if id(value) in memo:
            return memo[id(value)]
        if type(value) is dict:
            result = {}
            memo[id(value)] = result
            result.update((key, clone_state(item, memo)) for key, item in value.items())
            return result
        if type(value) is list:
            result = []
            memo[id(value)] = result
            result.extend(clone_state(item, memo) for item in value)
            return result
        if type(value) is tuple:
            result = tuple(clone_state(item, memo) for item in value)
            memo[id(value)] = result
            return result
        return value

    def same_state(left, right, seen):
        if left is right:
            return True
        if type(left) is not type(right):
            return False
        pair = (id(left), id(right))
        if pair in seen:
            return True
        seen.add(pair)
        if type(left) is dict:
            return left.keys() == right.keys() and all(same_state(left[key], right[key], seen) for key in left)
        if type(left) in {list, tuple}:
            return len(left) == len(right) and all(same_state(a, b, seen) for a, b in zip(left, right))
        if type(left) in {str, int, bool, bytes, type(None)}:
            return left == right
        if type(left) is float:
            return left == right or math.isnan(left) and math.isnan(right)
        return False

    snapshot = clone_state(dict(st.session_state), {})
    try:
        for entry, value in edits:
            st.session_state[entry["key"]] = copy.deepcopy(value)
        for entry, value in edits:
            callback = entry.get("callback")
            if callback:
                callback(*entry.get("args", ()), **entry.get("kwargs", {}))
    except Exception:
        for key in set(st.session_state) - snapshot.keys():
            del st.session_state[key]
        for key, value in snapshot.items():
            if key not in st.session_state or not same_state(st.session_state[key], value, set()):
                st.session_state[key] = value
        st.session_state[KEY + "notice"] = {"kind": "warning", "text": "These entries could not be prepared. Your prior field values and draft state were restored; use the existing editor."}
        return
    st.session_state[KEY + "applied"] = [{"id": entry["id"], "label": entry["label"], "value": value} for entry, value in edits]
    if pending.get("interaction"):
        st.session_state[KEY + "applied_feedback"] = pending


def field(widget, label, *args, binding=None, **kwargs):
    """Opt one existing draft input into assistance; otherwise behave identically."""
    kind = getattr(widget, "__name__", "")
    key = kwargs.get("key")
    eligible = (kind in KINDS and isinstance(key, str) and st.session_state.get(KEY + "enabled")
                and not kwargs.get("disabled") and kwargs.get("type") != "password")
    value = widget(label, *args, **kwargs)
    if not eligible:
        return value
    if kind in {"selectbox", "multiselect", "radio"}:
        options = kwargs.get("options", args[0] if args else [])
        options = list(options)
        if len(options) > 100 or any(not _scalar(option) for option in options):
            return value
        formatter = kwargs.get("format_func", str)
        choices = [{"value": option, "label": str(formatter(option))[:160]} for option in options]
    else:
        choices = None
    if not (_scalar(value) or isinstance(value, list) and all(_scalar(item) for item in value)):
        return value
    schema = {"kind": kind, "choices": choices, "min": kwargs.get("min_value"), "max": kwargs.get("max_value"),
              "max_chars": kwargs.get("max_chars"), "binding": digest(binding), "label": str(label)}
    identifier = digest([st.session_state[KEY + "scope"], key])[:20]
    current = st.session_state[KEY + "current"]
    if len(current) >= MAX_FIELDS and identifier not in current:
        return value
    current[identifier] = {"id": identifier, "key": key, "label": str(label), "value": copy.deepcopy(value),
        "schema": digest(schema), **schema, "callback": kwargs.get("on_change"),
        "args": kwargs.get("args") or (), "kwargs": kwargs.get("kwargs") or {}}
    return value


def context(question=None):
    """Bounded public field vocabulary; no session-state keys or callbacks."""
    if not st.session_state.get(KEY + "enabled"):
        return None
    fields = []
    entries = list((st.session_state.get(KEY + "catalog") or {}).values())
    terms = set(re.findall(r"[a-z0-9]+", str(question or "").lower())) - {"the", "a", "an", "my", "to", "this", "please", "set", "change", "fill"}
    def relevance(label):
        return len(terms & set(re.findall(r"[a-z0-9]+", str(label).lower())))
    for entry in sorted(entries, key=lambda item: -relevance(item["label"])):
        if entry["key"] not in st.session_state:
            continue
        value = st.session_state[entry["key"]]
        choices = entry["choices"]
        if choices and len(choices) > 24:
            choices = sorted(choices, key=lambda choice: -relevance(str(choice["value"]) + " " + choice["label"]))[:24]
        item = {"id": entry["id"], "label": entry["label"], "type": entry["kind"],
                "current": value, "current_complete": True,
                "empty": empty(value), "choices": choices, "min": entry["min"], "max": entry["max"],
                "max_chars": entry.get("max_chars")}
        if choices is not None and len(choices) < len(entry["choices"]):
            item["choices_omitted"] = len(entry["choices"]) - len(choices)
        if len(json.dumps(fields + [item], ensure_ascii=False).encode()) > 7000:
            # A prefix can reverse a scientific statement when its qualification
            # is at the end. Supply the complete value or explicitly omit it;
            # the full value remains in the local replacement diff and binding.
            item["current"] = None
            item["current_complete"] = False
            item["current_omitted_chars"] = len(value) if isinstance(value, str) else len(json.dumps(value, ensure_ascii=False))
            if len(json.dumps(fields + [item], ensure_ascii=False).encode()) > 7000:
                continue
        fields.append(item)
    if not fields:
        return None
    revision = [(entry["id"], entry["schema"], st.session_state.get(entry["key"], entry["value"]))
                for entry in (st.session_state.get(KEY + "catalog") or {}).values()]
    return {"scope": digest([st.session_state[KEY + "scope"], revision]), "fields": fields, "fields_omitted": len(entries) - len(fields),
        "workflow_revision": _workflow_revision(),
        "rule": "Suggest only values supported by the user's request or supplied context. Omit unknowns. current_complete=false means the existing value was omitted, not blank: do not infer its meaning or propose a partial revision from a missing value. Empty fields can be filled; replacements show the full local before-and-after diff. Saving, validating, attesting, approving and releasing remain the existing explicit actions."}


def check_response(proposal, public):
    if not isinstance(proposal, dict) or set(proposal) != {"scope", "fields"} or not public or proposal["scope"] != public["scope"]:
        raise ValueError("The proposed fields do not belong to this form.")
    rows = proposal["fields"]
    if not isinstance(rows, list) or not 1 <= len(rows) <= MAX_EDITS:
        raise ValueError("Propose between one and sixteen draft fields at a time.")
    allowed = {item["id"]: item for item in public["fields"]}
    seen = set()
    for row in rows:
        if not isinstance(row, dict) or set(row) != {"id", "value"} or row["id"] not in allowed or row["id"] in seen:
            raise ValueError("The proposal includes an unavailable or repeated field.")
        seen.add(row["id"])
        _validate(allowed[row["id"]], row["value"])
    return copy.deepcopy(proposal)


def _validate(entry, value):
    kind = entry.get("kind", entry.get("type"))
    if kind in {"text_input", "text_area"}:
        if not isinstance(value, str) or len(value) > min(MAX_TEXT, entry.get("max_chars") or MAX_TEXT) or "\x00" in value:
            raise ValueError("A proposed text entry exceeds the form's supported size.")
    elif kind == "number_input":
        if type(value) not in {int, float} or not math.isfinite(value):
            raise ValueError("Use a finite number for this field.")
        if type(entry.get("value", entry.get("current"))) is int and type(value) is not int:
            raise ValueError("Use a whole number for this field.")
        if entry.get("min") is not None and value < entry["min"] or entry.get("max") is not None and value > entry["max"]:
            raise ValueError("The number is outside this form's permitted range.")
    elif kind in {"selectbox", "multiselect", "radio"}:
        options = [item["value"] for item in entry["choices"]]
        values = value if kind == "multiselect" else [value]
        if not isinstance(values, list) or len(values) > 100 or any(not _scalar(v) or not any(type(v) is type(o) and v == o for o in options) for v in values):
            raise ValueError("Choose only options currently offered by this field.")
        if len({digest(v) for v in values}) != len(values):
            raise ValueError("A choice was repeated.")
    else:
        raise ValueError("This control cannot be filled from chat.")


def stage(proposal, *, replace=False, public=None, interaction=None):
    current = context()
    if public is not None and (not current or public.get("scope") != current["scope"]
                              or public.get("workflow_revision") != current.get("workflow_revision")):
        raise ValueError("The current form changed while answering. Your entries were kept; ask again.")
    public = public or current
    check_response(proposal, public)
    if current.get("workflow_revision") == "unavailable":
        raise ValueError("The current workflow inputs could not be checked. Your entries were kept; check the current step before requesting suggestions.")
    if interaction is not None and (not isinstance(interaction, dict) or set(interaction) != {"id", "request", "route"}
            or any(not isinstance(value, str) or not value.strip() or len(value) > (4000 if name == "request" else 200)
                   for name, value in interaction.items())):
        raise ValueError("The form feedback context is not valid for this interaction.")
    catalog = st.session_state.get(KEY + "catalog") or {}
    entries = []
    for item in proposal["fields"]:
        original = catalog.get(item["id"])
        if original is None:
            raise ValueError("The proposal includes a field unavailable in the current form.")
        _validate(original, item["value"])
        before = copy.deepcopy(st.session_state.get(original["key"], original["value"]))
        if before != item["value"]:
            entries.append({**item, "before": before, "schema": original["schema"], "label": original["label"], "binding": original["binding"]})
    st.session_state[KEY + "proposal"] = {"scope": st.session_state[KEY + "scope"], "entries": entries, "replace": replace,
        "reviewed": False, "workflow_revision": current.get("workflow_revision"),
        **({"interaction": copy.deepcopy(interaction)} if interaction else {})}


def _checked(proposal, catalog, scope, *, live=False):
    if proposal.get("scope") != scope:
        raise ValueError("The product, page, identity or permissions changed. Ask again in the current form.")
    revision = _workflow_revision()
    if revision == "unavailable" or proposal.get("workflow_revision") != revision:
        raise ValueError("The workflow check or specification changed after this suggestion. Your current entries were kept; review the current issue and ask again.")
    edits = []
    for change in proposal.get("entries", []):
        entry = catalog.get(change["id"])
        if not entry or entry["schema"] != change["schema"]:
            raise ValueError("The available fields or their source context changed. Ask again in the current form.")
        value = st.session_state.get(entry["key"], entry["value"]) if live else entry["value"]
        if value != change["before"]:
            raise ValueError("A draft value changed after the suggestion. Your current edits were kept; ask again or edit the form.")
        _validate(entry, change["value"])
        edits.append((entry, change["value"]))
    return edits


def finish():
    """Complete the form render before scheduling the next-run widget update."""
    current = st.session_state.get(KEY + "current")
    if current is None:
        return
    st.session_state[KEY + "catalog"] = current
    if _commit_validation(current):
        # The assistant is above the editor. One rerun makes the newly shown
        # validation authoritative there before another suggestion can apply.
        st.rerun()
    applied = st.session_state.pop(KEY + "applied", None)
    if applied:
        feedback_proposal = st.session_state.pop(KEY + "applied_feedback", None)
        if feedback_proposal:
            _feedback_record(feedback_proposal, "applied", current)
        kept_ids = {change["id"] for change in applied if change["id"] in current and current[change["id"]]["value"] == change["value"]}
        kept = [change["label"] for change in applied if change["id"] in kept_ids]
        reset = [change["label"] for change in applied if change["id"] not in kept_ids]
        message = ("Prepared draft fields: " + ", ".join(kept) + ". ") if kept else ""
        if reset:
            message += "These entries need another choice after the form updated: " + ", ".join(reset) + ". "
        message += "Review the entries below, then use the form's existing preview and save actions."
        st.session_state[KEY + "notice"] = {"kind": "warning" if reset else "success", "text": message}
        st.rerun()
    had_feedback = bool(st.session_state.get(KEY + "feedback"))
    if had_feedback and _observe_feedback(current) is None:
        # A source/row change may first become visible while the form renders,
        # after the header showed its previous interaction. Remove that stale UI.
        st.rerun()
    proposal = st.session_state.get(KEY + "proposal")
    if proposal and not proposal.get("reviewed"):
        try:
            edits = _checked(proposal, current, st.session_state[KEY + "scope"])
        except ValueError as error:
            st.session_state.pop(KEY + "proposal", None)
            st.session_state[KEY + "notice"] = {"kind": "warning", "text": str(error)}
        else:
            if edits and (proposal.get("replace") or all(empty(entry["value"]) for entry, value in edits)):
                st.session_state[KEY + "apply"] = proposal
                st.session_state.pop(KEY + "proposal", None)
            else:
                proposal["reviewed"] = True
                _feedback_record(proposal, "proposed", current)
        st.rerun()
    deferred = st.session_state.get(KEY + "deferred")
    if deferred and st.session_state.get(KEY + "enabled"):
        if st.session_state.get(KEY + "page") != "New product":
            for marker in ("connected_workflow", "connected_specialist_evidence", "flow_dialog", "flow_dialog_feedback", "flow_resolution_action", "flow_requested_action"):
                st.session_state.pop(marker, None)
            st.session_state["section_suggested"] = "New product"
            st.rerun()
        if deferred.get("ready") is False and current:
            deferred["ready"] = True
            st.rerun()


def defer_creation(question):
    """Carry this explicitly requested creation into the real registration form."""
    st.session_state[KEY + "deferred"] = {"question": question, "owner": st.session_state[KEY + "owner"], "ready": False}


def deferred_question():
    value = st.session_state.get(KEY + "deferred")
    if value and value["owner"] == st.session_state.get(KEY + "owner") and value["ready"] and st.session_state.get(KEY + "page") == "New product":
        st.session_state.pop(KEY + "deferred", None)
        return value["question"]
    return None


def review():
    notice = st.session_state.get(KEY + "notice")
    if notice:
        getattr(st, notice["kind"])(notice["text"])
    proposal = st.session_state.get(KEY + "proposal")
    if not proposal or not proposal.get("reviewed"):
        return
    catalog = st.session_state.get(KEY + "catalog") or {}
    try:
        edits = _checked(proposal, catalog, st.session_state[KEY + "scope"], live=True)
    except ValueError as error:
        st.warning(str(error))
        st.session_state.pop(KEY + "proposal", None)
        return
    if not edits:
        st.caption("These values are already in the form.")
        return
    st.write("**Review suggested replacements**")
    st.dataframe([{"Field": entry["label"], "Current": str(entry["value"]), "Suggested": str(value)} for entry, value in edits], hide_index=True)
    if st.button("Use these suggested values", key=KEY + "replace"):
        proposal.update(replace=True, reviewed=False)
    if st.button("Keep my current entries", key=KEY + "discard"):
        _feedback_record(proposal, "rejected", catalog)
        st.session_state.pop(KEY + "proposal", None)
