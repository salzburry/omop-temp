"""Explicit dropdown choices for variable review, with lossless custom fallbacks."""
from __future__ import annotations

from copy import deepcopy
import hashlib
import json

import streamlit as st
import yaml

import scientific_definition_choices as scientific
import contract_lint
from source_adapter import LOGICAL_TYPES

CUSTOM = scientific.CUSTOM
UNSURE = scientific.UNSURE
CURRENT = "Keep current answer"
TYPE_LABELS = {"string": "Text", "integer": "Whole number", "long": "Large whole number",
               "double": "Decimal number", "boolean": "Yes / no", "date": "Date", "timestamp": "Date and time"}
SOURCE_LABELS = {"Delivered data column": "vendor", "Calculated from other variables": "derived",
                 "Product setting": "parameter", "Fixed value": "constant", "Unavailable": "unavailable",
                 "Source mapping still needed": "pending_mapping"}


def choices_for(field):
    """Return declared literal choices; these are suggestions, never defaults."""
    if field in scientific.CHOICES:
        return deepcopy(scientific.CHOICES[field])
    if field == "output.type":
        return {TYPE_LABELS.get(value, value): value for value in LOGICAL_TYPES}
    if field == "output.nullable":
        return {"Yes — missing results are allowed": True, "No — a value is required": False}
    if field == "source.kind":
        return dict(SOURCE_LABELS)
    if field == "output.role":
        labels = {"published": "Published output", "internal": "Internal calculation", "metadata": "Product metadata", "excluded": "Excluded"}
        return {labels[value]: value for value in ("published", "internal", "metadata", "excluded") if value in contract_lint.ROLE}
    if field == "output.name_status":
        labels = {"aligned": "Names aligned", "undecided": "Not decided yet"}
        return {labels.get(value, value): value for value in sorted(contract_lint.NAMEST)}
    if field.startswith("publish."):
        labels = {"undecided": "Not decided yet", "proposed": "Proposed", "required": "Required", "configured": "Configured", "excluded": "Excluded"}
        return {labels[value]: value for value in ("undecided", "proposed", "required", "configured", "excluded") if value in contract_lint.PUB}
    return {}


def _digest(value):
    return hashlib.sha256(json.dumps([type(value).__name__, value], sort_keys=True, default=str).encode()).hexdigest()


def _text(value):
    if value is None:
        return ""
    if isinstance(value, (dict, list, bool)):
        return json.dumps(value, ensure_ascii=False)
    return str(value)


def _answered(value):
    return value is not None and (not isinstance(value, str) or value.strip() not in {"", "TODO"})


def _same(left, right):
    return type(left) is type(right) and left == right


def render_choice(label, current, options, *, key, disabled=False, multiline=False, help=None):
    """Return a selected literal while retaining an unmatched or custom answer.

    ``options`` maps friendly labels to values. Caller keys identify the product,
    row and field. A changed saved value resets that field's UI; option-list
    changes retain the current working answer until explicitly replaced.
    """
    options = dict(options)
    if any(not isinstance(label, str) for label in options) or set(options) & {CUSTOM, UNSURE, CURRENT}:
        raise ValueError("Dropdown choices need distinct labels separate from the custom-answer controls.")
    memory_key, choice_key, custom_key = key + "__memory", key + "__choice", key + "__custom"
    baseline = _digest(current)
    if st.session_state.get(memory_key, {}).get("baseline") != baseline:
        state = {"baseline": baseline, "value": deepcopy(current), "retained": deepcopy(current)}
        st.session_state[memory_key] = state
        st.session_state.pop(choice_key, None)
        st.session_state.pop(custom_key, None)
    state = st.session_state[memory_key]
    if choice_key not in st.session_state:
        st.session_state[choice_key] = next((name for name, value in options.items() if _same(value, current)),
                                            CURRENT if _answered(current) else None)
    elif st.session_state[choice_key] not in [*options, CUSTOM, UNSURE, CURRENT, None]:
        state["retained"] = deepcopy(state["value"])
        st.session_state[choice_key] = CURRENT if _answered(state["value"]) else None

    def changed():
        selected = st.session_state[choice_key]
        if selected is None and _answered(state["value"]):
            state["retained"] = deepcopy(state["value"])
            st.session_state[choice_key] = CURRENT
        elif selected == CUSTOM:
            if "custom_text" not in state:
                state["custom_origin"] = deepcopy(state["value"])
                state["custom_text"] = "" if state["value"] == "TODO" else _text(state["value"])
            st.session_state[custom_key] = state["custom_text"]
        elif selected == UNSURE:
            state["value"] = "TODO"
        elif selected in options:
            state["value"] = deepcopy(options[selected])
        elif selected == CURRENT:
            state["value"] = deepcopy(state["retained"])

    labels = [*options]
    if _answered(state["retained"]):
        labels.append(CURRENT)
    labels.extend([CUSTOM, UNSURE])
    selected = st.selectbox(label, labels, index=None, key=choice_key, disabled=disabled,
                            help=help, placeholder="Choose an answer", on_change=changed)
    if selected == CUSTOM:
        if "custom_text" not in state:
            state["custom_origin"] = deepcopy(state["value"])
            state["custom_text"] = _text(state["value"])
        widget = st.text_area if multiline else st.text_input
        text = widget("Your answer: " + label, value=state["custom_text"], key=custom_key, disabled=disabled, help=help)
        state["custom_text"] = text
        state["value"] = deepcopy(state["custom_origin"]) if text == _text(state["custom_origin"]) else text
    elif selected in options:
        state["value"] = deepcopy(options[selected])
    elif selected == UNSURE:
        state["value"] = "TODO"
    elif selected == CURRENT:
        state["value"] = deepcopy(state["retained"])
        st.caption("Current answer: " + _text(state["value"]))
    return deepcopy(state["value"])


def list_values(value):
    """Normalize legacy list displays without splitting identifiers at commas."""
    if value is None or isinstance(value, str) and value.strip() in {"", "TODO"}:
        return []
    if isinstance(value, str):
        if value.strip().startswith("["):
            value = yaml.safe_load(value)
        else:
            value = [line.strip() for line in value.splitlines() if line.strip()]
    if not isinstance(value, list) or any(not isinstance(item, str) for item in value):
        raise ValueError("Variable selections must be a list of names.")
    return deepcopy(value)


def render_multi(label, current, options, *, key, disabled=False, help=None, allow_custom=True):
    """Select named inputs; keep unknown existing names and allow explicit additions."""
    current, offered = list_values(current), list_values(list(options))
    memory_key, widget_key = key + "__baseline", key + "__values"
    baseline = _digest(current)
    if st.session_state.get(memory_key) != baseline:
        st.session_state[memory_key] = baseline
        st.session_state.pop(widget_key, None)
    working = list_values(st.session_state.get(widget_key, current))
    offered = list(dict.fromkeys([*offered, *current, *working]))
    return list(st.multiselect(label, offered, default=current, key=widget_key, disabled=disabled,
                               help=help, accept_new_options=allow_custom,
                               placeholder="Choose names or type a new one" if allow_custom else "Choose names"))
