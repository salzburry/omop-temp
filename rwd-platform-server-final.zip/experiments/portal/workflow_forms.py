"""Prepare missing workflow records from canonical templates and actual evidence.

Approval fields come only from literal human input. Generated subject digests use
the existing gate functions. Creation never overwrites, signs, seals or releases.
"""
from __future__ import annotations

import copy
import hashlib
import json
import os
from pathlib import Path
import re
import tempfile

import yaml

import contract_lint as cl
import flow
import product_gates as pg
from engine import refresh
import source_manifest as sm
import source_refs_init as init
import specification_details as details

TEMPLATES = "platform/TUMOR_TEMPLATE/handoff"
NOTICE = "Creation records the supplied review or an empty register for later review. It does not authenticate an approval, complete QC, raise maturity, seal history or release a product."
FORMS = {"g2_approve": ("CONTRACT_APPROVAL.yaml", pg.CONTRACT_APPROVAL_FIELDS),
         "g4_approve": ("CONFIGURATION_APPROVAL.yaml", pg.CONFIGURATION_APPROVAL_FIELDS),
         "g5_validate": ("RELEASE_APPROVAL.yaml", pg.RELEASE_APPROVAL_FIELDS),
         "g6_approve": ("RELEASE_APPROVAL.yaml", pg.RELEASE_APPROVAL_FIELDS)}
REGISTER_ACTIONS = {"g2_registers": tuple(flow.REGISTERS),
                    "g2_maturity": ("MATURITY.yaml",), "g4_maturity": ("MATURITY.yaml",)}
# THE FIRST REGISTRATION AS A FORM (2026-09-07). An unregistered pack dead-ended on a write act
# whose command carried <class> <you> <YYYY-MM-DD> placeholders, a disabled button and no form.
# The three values are the person's, so this form collects them and hands them to
# source_refs_init.py's own composition and validation (human_errors, document, schema_errors,
# render): the file written is byte-for-byte the tool's, and no default is supplied for any of them.
INIT_ACTION = "g1_init"
WRITE_FORMS = frozenset({INIT_ACTION})
INIT_FIELDS = (("ai_classification", "What may AI read?"), ("classified_by", "Access classifier's name"),
               ("classified_date", "Classification date"))
INIT_NOTICE = ("Registration records your AI access decision and leaves the specification pending. It does not attach the "
               "workbook, record its checksum, review it or authenticate anything.")


def _fail(message, *, supported=True):
    return {"ok": False, "supported": supported, "exists": False, "target": "", "targets": [], "fields": [],
            "digests": {}, "missing_inputs": [], "errors": [str(message)], "manifest_digest": "", "notice": NOTICE}


def _read(path):
    if path.resolve() != path or not path.is_file():
        raise details._Invalid("An input is missing or redirects outside its declared path: " + path.name)
    with path.open("rb") as handle:
        raw = handle.read(2 * 1024 * 1024 + 1)
    if len(raw) > 2 * 1024 * 1024:
        raise details._Invalid("An approval input exceeds the 2 MB preparation limit: " + path.name)
    return raw


def _yaml(raw):
    text = raw.decode("utf-8")
    if any(isinstance(token, (yaml.AliasToken, yaml.AnchorToken)) for token in yaml.scan(text)):
        raise details._Invalid("An approval input uses YAML aliases; ask your data expert to review it.")
    doc = yaml.load(text, Loader=details._StrictLoader)
    if not isinstance(doc, dict):
        raise details._Invalid("The approval input must be a YAML mapping.")
    return doc


def _scope(root, pack, action, target, allowed_packs):
    source, pack = details._paths(root, pack, allowed_packs)
    root, product = Path(root).resolve(), source.parent
    if (product / "handoff").resolve() != product / "handoff":
        raise details._Invalid("The product's handoff folder redirects to another location.")
    aid = action.get("id") if isinstance(action, dict) else action
    supported = aid in FORMS or aid in REGISTER_ACTIONS or aid == INIT_ACTION
    if not supported:
        raise details._Invalid("This action has no supported missing-form preparation.")
    kinds = (flow.PERSON, flow.WRITE) if aid == INIT_ACTION else (flow.PERSON,)
    current = next((item for menu in flow.acts(pack, str(root)).values() for item in menu if item["id"] == aid and item["kind"] in kinds), None)
    if aid == INIT_ACTION:
        if current is None:
            raise details._Invalid("A source registration now exists for this product, or its record needs repair. Check status again; registration never replaces a record.")
        targets = [f"{pack}/source_refs.yaml"]
        if target and str(target).replace("\\", "/") not in targets:
            raise details._Invalid("Choose one of this action's declared product records.")
        return root, pack, product, aid, root / targets[0], targets
    if current is None:
        # Existing completed targets are still identified honestly when their
        # creation action disappears after the file was written; never recreated.
        names = REGISTER_ACTIONS.get(aid, (FORMS[aid][0],) if aid in FORMS else ())
        if not all((product / "handoff" / name).is_file() for name in names):
            raise details._Invalid("This preparation action is no longer available. Check status again.")
    names = REGISTER_ACTIONS.get(aid, (FORMS[aid][0],) if aid in FORMS else ())
    targets = [f"{pack}/handoff/{name}" for name in names]
    chosen = str(target or next((p for p in targets if not (root / p).exists()), targets[0])).replace("\\", "/")
    if chosen not in targets:
        raise details._Invalid("Choose one of this action's declared product records.")
    destination = root / chosen
    if destination.resolve() != destination:
        raise details._Invalid("The target record redirects to another location.")
    return root, pack, product, aid, destination, targets


def _candidate(root, pack, product, candidate_path, inputs):
    if not candidate_path:
        raise details._Invalid("Stage the candidate through the build action, then provide its release_candidate.yaml and unchanged manifest.yaml from the same artifact folder.")
    candidate = Path(candidate_path)
    candidate = candidate if candidate.is_absolute() else root / candidate
    candidate.relative_to(root)  # Product identity below is required even for a shared artifact directory.
    raw = _read(candidate)
    doc = _yaml(raw)
    inputs[candidate.relative_to(root).as_posix()] = hashlib.sha256(raw).hexdigest()
    # The runner writes these two files beside each other. A local copy retains
    # the cluster URI inside the sidecar; equality is established by its digest.
    manifest = candidate.parent / "manifest.yaml"
    data = _read(manifest)
    manifest_doc = _yaml(data)
    digest = hashlib.sha256(data).hexdigest()
    inputs[manifest.relative_to(root).as_posix()] = digest
    release = manifest_doc.get("release")
    if not isinstance(release, dict):
        raise details._Invalid("The candidate manifest does not identify its staged release build.")
    family, slug, cut = pack.split("/")[1:]
    if str(manifest_doc.get("family") or "") != family or str(manifest_doc.get("spec_version") or "") != cut or str(manifest_doc.get("tumor") or "") not in sm._tumour_names(str(root), slug):
        raise details._Invalid("This candidate manifest belongs to a different product or specification cut.")
    bid = str(doc.get("build_id") or "")
    if sm.unstated(bid) or bid != str(release.get("build_id") or "") or doc.get("candidate_manifest_sha256") != digest:
        raise details._Invalid("The candidate sidecar and manifest do not agree on the build and exact manifest bytes.")
    if doc.get("granted") is not False or doc.get("stopped_before") != "versioned_release_tables" or manifest_doc.get("status") != "qc_passed" or manifest_doc.get("published_at") is not None:
        raise details._Invalid("Provide the staged, QC-passed candidate that stopped before release; a published or incomplete run cannot be reused here.")
    # The summary word is not the verdict. Use the same manifest and composed
    # stage checks that later promotion uses, while still operating only on this
    # unpublished candidate's metadata. Canonical readers may normalize nested
    # values, so keep their input separate from the exact bytes being approved.
    try:
        findings = refresh.validate_manifest(copy.deepcopy(manifest_doc))
        verdict = refresh.candidate_verdict(copy.deepcopy(manifest_doc)) if not findings else None
    except (TypeError, AttributeError, KeyError, ValueError, IndexError, RecursionError):
        raise details._Invalid("The candidate's validation blocks are malformed. Repair and rerun candidate validation before preparing its review.") from None
    if findings:
        raise details._Invalid("The candidate manifest fails the existing manifest validator. Inspect the build's manifest findings and repair the candidate before preparing its review.")
    if verdict.get("passed") is not True:
        # Findings can contain delivered values. The detailed report stays with
        # its owner; a form needs only the fact that the composed check failed.
        raise details._Invalid("The candidate has failed or missing stage verdicts. Complete the source QC, ADS QC, output-contract and any declared comparison checks before preparing its review.")
    if _read(candidate) != raw or _read(manifest) != data:
        raise details._Invalid("The candidate evidence changed during validation. Reload the unchanged sidecar and manifest before preparing its review.")
    return {"approved_build_id": bid, "approved_manifest_sha256": digest}


def candidate_context(root, pack, *, receipt, build_id=None, candidate_path=None, allowed_packs=None):
    """Match one selected ledger receipt to an explicitly supplied candidate pair.

    Only the receipt's own sibling pair is suggested automatically. Other local
    copies remain an explicit path choice, validated by the existing reader.
    """
    result = {"ok": False, "candidate_path": "", "digests": {}, "inputs": {}, "errors": []}
    try:
        source, pack = details._paths(root, pack, allowed_packs)
        root, product = Path(root).resolve(), source.parent
        if not isinstance(receipt, str) or not receipt.strip() or len(receipt) > 4000:
            raise details._Invalid("Choose the exact build receipt again in Release readiness.")
        selected = Path(receipt)
        selected = selected if selected.is_absolute() else root / selected
        if not selected.is_relative_to(root / "refreshes") or selected.resolve() != selected:
            raise details._Invalid("The selected receipt must be a canonical file in this checkout's refresh ledger.")
        raw = _read(selected)
        doc = _yaml(raw)
        family, slug, cut = pack.split("/")[1:]
        release = doc.get("release") or {}
        bid = str(release.get("build_id") or "") if isinstance(release, dict) else ""
        if (str(doc.get("family") or "") != family or str(doc.get("spec_version") or "") != cut
                or str(doc.get("tumor") or "") not in sm._tumour_names(str(root), slug)
                or sm.unstated(bid) or build_id is not None and bid != build_id):
            raise details._Invalid("The selected receipt no longer identifies this product and build. Return to Release readiness and select its current receipt.")
        digest = hashlib.sha256(raw).hexdigest()
        result.update(receipt=selected.relative_to(root).as_posix(), build_id=bid,
                      manifest_sha256=digest)
        if doc.get("status") != "qc_passed" or doc.get("published_at") is not None:
            raise details._Invalid("This selected receipt is not an unpublished, QC-passed candidate. Select its original candidate receipt before preparing approval.")
        chosen = candidate_path
        if not chosen:
            sibling = selected.parent / "release_candidate.yaml"
            if sibling.is_file() and (selected.parent / "manifest.yaml").is_file():
                chosen = sibling.relative_to(root).as_posix()
        if not chosen:
            raise details._Invalid("Provide this selected build's release_candidate.yaml beside its unchanged manifest.yaml. The exact manifest must match the selected receipt; another build's previous path is not reused.")
        inputs = {selected.relative_to(root).as_posix(): digest}
        identity = _candidate(root, pack, product, chosen, inputs)
        if identity != {"approved_build_id": bid, "approved_manifest_sha256": digest}:
            raise details._Invalid("This sidecar belongs to a different candidate than the selected receipt. Provide the sidecar and unchanged manifest for build " + bid + ".")
        if _read(selected) != raw:
            raise details._Invalid("The selected receipt changed while its candidate was checked. Return to Release readiness and review it again.")
        result.update(ok=True, candidate_path=str(chosen), digests=identity, inputs=inputs)
    except (details._Invalid, OSError, ValueError, TypeError, UnicodeError, yaml.YAMLError, RecursionError, KeyError) as error:
        result["errors"] = [str(error) if isinstance(error, details._Invalid) else "The selected candidate files could not be read safely. Provide its unchanged sidecar and manifest within this checkout."]
    return result


def _registration(root, pack, product, destination, targets):
    """What the first registration would write, from the pack as it stands: the registry row the
    tool composes product and spec_version from, the one workbook already in prog_spec/ (named the
    way the tool names it), and whether an existing file with no registration in it is replaced.
    The three human fields are empty; nothing here suggests a value for them."""
    reg = flow.registration_state(str(product))
    inputs, missing = {}, []
    registry = root / pack.split("/")[0] / "registry.yaml"
    if registry.is_file() and registry.resolve() == registry:
        inputs[registry.relative_to(root).as_posix()] = hashlib.sha256(_read(registry)).hexdigest()
    if pg.registry_entry(str(root), pack) is None:
        missing.append("Register this product in its registry (Start a new product does this) before registering its specification.")
    path_or_link = "TBD — workbook not yet supplied to this pack"
    books = sorted(p.name for p in (product / "prog_spec").iterdir() if p.is_file() and p.suffix.lower() in (".xlsx", ".xlsm")) \
        if (product / "prog_spec").is_dir() else []
    if len(books) == 1:
        path_or_link = f"{pack}/prog_spec/{books[0]}"
    fields = [{"name": name, "label": label, "value": "", "required": True,
               **({"choices": list(sm.AI_CLASSES)} if name == "ai_classification" else {})}
              for name, label in INIT_FIELDS]
    exists = bool(reg["exists"] or reg["unreadable"])
    replaces = bool(reg["present"] and not exists)
    manifest = {"pack": pack, "action": INIT_ACTION, "target": destination.relative_to(root).as_posix(), "inputs": inputs,
                "path_or_link": path_or_link, "exists": exists, "replaces": replaces, "missing_inputs": missing}
    return {"ok": True, "supported": True, "exists": exists, "target": manifest["target"], "targets": targets, "fields": fields,
            "digests": {}, "missing_inputs": missing, "template": "platform/tools/source_refs_init.py", "inputs": inputs,
            "manifest_digest": hashlib.sha256(json.dumps(manifest, sort_keys=True).encode()).hexdigest(),
            "kind": "registration", "path_or_link": path_or_link, "replaces": replaces, "workbooks": books,
            "errors": [], "notice": INIT_NOTICE}


def _registration_payload(root, pack, clean, description):
    """The tool's own file for these values: its refusals verbatim, its schema check, its rendering."""
    bad = init.human_errors(clean["ai_classification"], clean["classified_by"], clean["classified_date"])
    if bad:
        raise details._Invalid(" ".join(bad))
    try:
        doc = init.document(pack, clean["ai_classification"], clean["classified_by"], clean["classified_date"],
                            description["path_or_link"], root=str(root))
    except SystemExit as error:
        raise details._Invalid(str(error)) from error
    bad = init.schema_errors(doc)
    if bad:
        raise details._Invalid(" ".join(bad))
    return init.render(doc).encode("utf-8")


def describe(root, pack, action, *, target=None, candidate_path=None, allowed_packs=None, receipt=None, build_id=None):
    aid = action.get("id") if isinstance(action, dict) else action
    if not isinstance(aid, str) or (aid not in FORMS and aid not in REGISTER_ACTIONS and aid != INIT_ACTION):
        return _fail("This action has no supported missing-form preparation.", supported=False)
    try:
        root, pack, product, aid, destination, targets = _scope(root, pack, action, target, allowed_packs)
        if aid == INIT_ACTION:
            return _registration(root, pack, product, destination, targets)
        name = destination.name
        approval = aid in FORMS
        template = root / TEMPLATES / (name.replace(".yaml", ".example.yaml") if approval else name)
        template_bytes = _read(template)
        inputs = {template.relative_to(root).as_posix(): hashlib.sha256(template_bytes).hexdigest()}
        missing, digests = [], {}
        template_doc = _yaml(template_bytes) if template.suffix == ".yaml" else None
        fields = []

        def file(relative):
            path = product / relative
            try:
                raw = _read(path)
                inputs[f"{pack}/{relative}"] = hashlib.sha256(raw).hexdigest()
                return path, raw
            except details._Invalid as error:
                missing.append(str(error) + " (" + relative + ")")
                return None, None

        if aid == "g2_approve":
            for field, relative in (("approved_extraction_sha256", "spec_pipeline/out/extracted.json"),
                                    ("approved_coverage_sha256", "spec_pipeline/out/COVERAGE.md"),
                                    ("approved_decisions_sha256", "handoff/DECISIONS.md"),
                                    ("approved_spec_qc_sha256", "handoff/SPEC_QC_FINDINGS.md")):
                _path, raw = file(relative)
                if raw is not None:
                    digests[field] = hashlib.sha256(raw).hexdigest()
            path, raw = file("handoff/FUNCTIONAL_CONTRACT.md")
            if path:
                if not list(cl.records(raw.decode("utf-8").replace("\r\n", "\n"))):
                    missing.append("Draft the requirement records before preparing contract approval.")
                digests["approved_contract_sha256"] = pg.requirements_sha256(str(path))
        elif aid == "g4_approve":
            path, raw = file("handoff/FUNCTIONAL_CONTRACT.md")
            if path:
                if not list(cl.records(raw.decode("utf-8").replace("\r\n", "\n"))):
                    missing.append("Draft the requirement records before preparing configuration approval.")
                digests["approved_against_contract_sha256"] = pg.requirements_sha256(str(path))
            file("config/data_product.yaml")
            try:
                graph = pg.scientific_yaml(str(product))
                for relative in graph:
                    file(relative)
                if not graph:
                    missing.append("Prepare the active configuration graph before its approval.")
                if not missing:
                    digests["approved_configuration_bundle_sha256"] = pg.config_bundle_sha256(str(product))
            except (OSError, ValueError, TypeError, KeyError, AttributeError):
                missing.append("The active configuration graph could not be resolved. Repair the configuration before preparing approval.")
        elif aid in {"g5_validate", "g6_approve"}:
            try:
                if receipt is not None:
                    context = candidate_context(root, pack, receipt=receipt, build_id=build_id,
                        candidate_path=candidate_path, allowed_packs=allowed_packs)
                    if not context["ok"]:
                        raise details._Invalid(" ".join(context["errors"]))
                    digests = context["digests"]
                    inputs.update(context["inputs"])
                else:
                    digests = _candidate(root, pack, product, candidate_path, inputs)
            except (details._Invalid, OSError, ValueError, TypeError, UnicodeError, yaml.YAMLError, RecursionError, KeyError) as error:
                missing.append(str(error) if isinstance(error, details._Invalid) else "The candidate files could not be read safely. Provide this product's staged candidate and its unchanged manifest.")
        if approval:
            required = FORMS[aid][1]
            if any(field not in template_doc for field in required):
                raise details._Invalid("The canonical approval example is missing a required field. Ask Engineering to repair the template.")
            for field in template_doc:
                if field not in digests and not field.endswith("_sha256") and field != "approved_build_id":
                    fields.append({"name": field, "label": field.replace("_", " ").capitalize(), "value": "", "required": field in required})
        manifest = {"pack": pack, "action": aid, "target": destination.relative_to(root).as_posix(), "inputs": inputs,
                    "digests": digests, "missing_inputs": missing, "exists": destination.exists()}
        return {"ok": True, "supported": True, "exists": destination.exists(), "target": manifest["target"], "targets": targets,
                "fields": fields, "digests": digests, "missing_inputs": missing, "template": template.relative_to(root).as_posix(),
                "manifest_digest": hashlib.sha256(json.dumps(manifest, sort_keys=True).encode()).hexdigest(), "inputs": inputs,
                "kind": "approval" if approval else "maturity" if name == "MATURITY.yaml" else "register", "errors": [], "notice": NOTICE}
    except (details._Invalid, OSError, ValueError, TypeError, UnicodeError, yaml.YAMLError, RecursionError, KeyError) as error:
        return _fail(str(error) if isinstance(error, details._Invalid) else "The canonical preparation inputs could not be read safely.")


def _register(raw):
    lines = raw.decode("utf-8").splitlines()
    # ENGINE_GAPS.md heads its key column `Gap ID` (contract_lint reads it by that name).
    header = next((index for index, line in enumerate(lines) if line.startswith(("| ID |", "| Gap ID |"))), None)
    if header is None or header + 1 >= len(lines) or not lines[header + 1].startswith("|---"):
        raise details._Invalid("The canonical register has no usable table header.")
    return (lines[0] + "\n\n" + lines[header] + "\n" + lines[header + 1] + "\n").encode("utf-8")


def save(root, pack, action, values, *, expected_manifest_digest, confirmed=False, local_demo, can_review,
         target=None, candidate_path=None, allowed_packs=None, receipt=None, build_id=None):
    if local_demo is not True or can_review is not True or confirmed is not True:
        return _fail("Creating this record requires reviewer access in a local session and explicit confirmation of the supplied review or empty register.")
    if not isinstance(values, dict):
        return _fail("Enter the human fields shown in the preparation form.")
    lock_fd = None
    lock_path = temporary = None
    try:
        root, pack, product, aid, destination, _targets = _scope(root, pack, action, target, allowed_packs)
        if not destination.parent.is_dir():
            raise details._Invalid("Prepare the product's handoff folder through its product setup before creating a workflow record.")
        lock_path = destination.with_name("." + destination.name + ".portal-prepare.lock")
        lock_fd = os.open(lock_path, os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o600)
        description = describe(root, pack, action, target=target, candidate_path=candidate_path,
                               allowed_packs=allowed_packs, receipt=receipt, build_id=build_id)
        if not description["ok"]:
            raise details._Invalid(" ".join(description["errors"]))
        if description["exists"]:
            raise details._Invalid("This record already exists. Use its editor; preparation never overwrites it.")
        if not isinstance(expected_manifest_digest, str) or description["manifest_digest"] != expected_manifest_digest:
            raise details._Invalid("The template, target or evidence changed while this form was open. Reload preparation and review the current inputs.")
        if description["missing_inputs"]:
            raise details._Invalid("Complete these preparation inputs first: " + " ".join(description["missing_inputs"]))
        names = {field["name"] for field in description["fields"]}
        if any(field not in names for field in values):
            raise details._Invalid("Only the displayed human fields can be supplied. Subject digests and build identifiers come from the actual inputs.")
        clean = {}
        for field in description["fields"]:
            name = field["name"]
            value = values.get(name, "")
            if not isinstance(value, str) or len(value) > (4000 if name == "notes" else 250):
                raise details._Invalid(name + " must be literal text within the form's length limit.")
            value = value.strip()
            if any(ord(c) < 32 and not (name == "notes" and c in "\n\r\t") for c in value):
                raise details._Invalid(name + " contains unsupported control characters.")
            if field["required"] and sm.unstated(value):
                raise details._Invalid("Enter the actual " + field["label"].lower() + ". No name, date or decision is supplied automatically.")
            if field.get("choices") and value not in field["choices"]:
                raise details._Invalid("Choose one of the listed options for: " + field["label"])
            # the refusal names the field as the form labels it, not by its record key (walk RW1-08)
            if value and name.endswith("_by") and pg.not_a_person(value):
                raise details._Invalid("The " + field["label"].lower() + ": " + pg.not_a_person(value))
            if value and name.endswith("_date") and pg.bad_date(value):
                raise details._Invalid("The " + field["label"].lower() + " " + pg.bad_date(value))
            clean[name] = value
        if aid == "g2_approve" and clean.get("approved_by", "").casefold() == clean.get("spec_qc_reviewed_by", "").casefold():
            raise details._Invalid("Contract approval and specification QC review require two different people.")
        if aid == "g4_approve" and clean["approved_by"].casefold() == clean["technically_reviewed_by"].casefold():
            raise details._Invalid("Configuration approval and technical review require two different people.")
        if aid in {"g5_validate", "g6_approve"} and clean["approved_by"].casefold() == clean["validated_by"].casefold():
            raise details._Invalid("Candidate validation and release approval require two different people.")
        template_raw = None if aid == INIT_ACTION else _read(root / description["template"])
        if aid == INIT_ACTION:
            payload = _registration_payload(root, pack, clean, description)
        elif description["kind"] == "register":
            payload = _register(template_raw)
        elif description["kind"] == "maturity":
            doc = _yaml(template_raw)
            if doc.get("contract") != "not_started" or doc.get("configuration") != "not_started":
                raise details._Invalid("The canonical maturity template must start without an approval claim.")
            payload = template_raw
        else:
            template = _yaml(template_raw)
            actual = {key: description["digests"].get(key, clean.get(key, "")) for key in template}
            if any(sm.unstated(actual.get(field)) for field in FORMS[aid][1]):
                raise details._Invalid("Every required approval field must be complete before the actual approval record is created.")
            payload = yaml.safe_dump(actual, sort_keys=False, allow_unicode=True).encode("utf-8")
        with tempfile.NamedTemporaryFile(mode="wb", prefix=".workflow-form-", suffix=".tmp", dir=destination.parent, delete=False) as handle:
            temporary = Path(handle.name)
            handle.write(payload)
            handle.flush()
            os.fsync(handle.fileno())
        final = describe(root, pack, action, target=target, candidate_path=candidate_path,
                         allowed_packs=allowed_packs, receipt=receipt, build_id=build_id)
        if not final["ok"] or final["manifest_digest"] != expected_manifest_digest:
            raise details._Invalid("The preparation inputs changed during this save. Reload before trying again.")
        if description.get("replaces"):
            # The person asked to register and the file on disk holds no registration (empty or
            # not a mapping; flow.registration_state): the complete file replaces it atomically.
            # `final` above re-read the file, so a registration written meanwhile refused this.
            os.replace(temporary, destination)
            temporary = None
        else:
            # A hard link creates a complete file atomically and fails if a competing
            # writer created the target. Unlike replace(), it never overwrites it.
            os.link(temporary, destination)
        return {**description, "exists": True, "changed": True, "authenticated": False}
    except FileExistsError:
        return _fail("This record now exists or another preparation is in progress. Reload; existing records are never overwritten.")
    except (details._Invalid, OSError, ValueError, TypeError, UnicodeError, yaml.YAMLError, RecursionError, KeyError) as error:
        return _fail(str(error) if isinstance(error, details._Invalid) else "The record could not be created atomically. No existing target was replaced.")
    finally:
        if temporary is not None:
            try:
                temporary.unlink(missing_ok=True)
            except OSError:
                pass
        if lock_fd is not None:
            os.close(lock_fd)
            try:
                lock_path.unlink(missing_ok=True)
            except OSError:
                pass
