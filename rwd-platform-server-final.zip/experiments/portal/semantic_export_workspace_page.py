"""Prepare, compare and record the selected product's semantic export in one flow."""
from __future__ import annotations

import streamlit as st

import semantic_export_workspace as backend

PREFIX = 'semantic_export_'


def _errors(result):
    for error in result.get('errors', []):
        st.error(error)


def _inspect(proposal):
    report, validation = proposal['report'], proposal['validation']
    st.table([{'Measure': label, 'Count': report.get(key, 0)} for label, key in (
        ('Contract records', 'records'), ('Exported approved records', 'exported'),
        ('Authored concepts', 'concepts'), ('Inherited concepts', 'concepts_inherited'),
        ('Bound variables', 'variables_bound'), ('Graph nodes', 'nodes'))])
    st.caption(report['scope_note'])
    st.info(report['note'])
    if report.get('withheld'):
        st.table([{'Withheld record state': state.replace('_', ' '), 'Count': count}
                  for state, count in report['withheld'].items()])
    for reason in report.get('binding_withheld', []):
        st.warning(reason)
    if report.get('inherited_note'):
        st.caption(report['inherited_note'])
    status = validation.get('state')
    if status == 'conforms':
        st.success('The exact graph conforms to the canonical SHACL shapes.')
        st.caption('This checks RDF structure and declared constraints; it does not approve scientific meaning or deliver the graph.')
    elif status == 'unchecked':
        st.warning('SHACL was not run. Install the repository’s rdflib and pyshacl dependencies before saving an export.')
    else:
        st.warning('The graph has validation findings and cannot be saved as a validated export.')
    if validation.get('why') or validation.get('report'):
        with st.expander('Validator findings'):
            st.text(validation.get('why') or validation.get('report'))
    with st.expander('Inspect the exact graph and shapes'):
        st.code(proposal['graph'], language='json')
        st.code(proposal['shapes'], language='json')
        st.caption('Graph SHA256: ' + proposal['graph_sha256'])
    if report.get('contract_findings') or report.get('withheld'):
        if st.button('Review scientific definitions', key=PREFIX + 'definitions'):
            return {'route': 'scientific_draft', 'params': {}}
    if report.get('binding_withheld'):
        if st.button('Review clinical bindings', key=PREFIX + 'bindings'):
            return {'route': 'clinical_standards', 'params': {}}
    return None


def render(root, pack, actor_id, *, allowed_packs, local_demo, can_write, can_review=False,
           route=backend.ROUTE, params=None):
    params = params or {}
    context = (str(root), pack, actor_id, tuple(sorted(allowed_packs or [])), local_demo, can_write, can_review)
    if st.session_state.get(PREFIX + 'context') != context:
        for key in list(st.session_state):
            if key.startswith(PREFIX):
                del st.session_state[key]
        st.session_state[PREFIX + 'context'] = context
    st.subheader('Export the reviewed semantic graph')
    st.write('Prepare this product’s approved meaning and clinical bindings for a graph consumer. Inspect what is included and withheld, validate it, then save the exact files on your branch.')
    st.caption(backend.NOTICE)
    report = backend.describe(root, pack, actor_id, allowed_packs=allowed_packs)
    _errors(report)
    if not report['ok']:
        if st.button('Open product progress', key=PREFIX + 'progress'):
            return {'route': 'progress', 'params': {}}
        return None
    if notice := st.session_state.pop(PREFIX + 'notice', None):
        st.success(notice)
    ids = [row['id'] for row in report['versions']]
    requested = params.get('version_id')
    if requested and requested != st.session_state.get(PREFIX + 'requested'):
        st.session_state[PREFIX + 'requested'] = requested
        st.session_state[PREFIX + 'version'] = requested if requested in ids else None
    if st.session_state.get(PREFIX + 'version') not in ids:
        st.session_state[PREFIX + 'version'] = None
    chosen = st.selectbox('Saved export to inspect or compare', ids, index=None, key=PREFIX + 'version',
        placeholder='Choose an exact version, or prepare a first export',
        format_func=lambda value: value[:12] + ' · ' + next(row['created_at'][:19] for row in report['versions'] if row['id'] == value))
    saved, saved_stale = None, True
    if chosen:
        result = backend.read(root, pack, actor_id, chosen, allowed_packs=allowed_packs)
        _errors(result)
        if result['ok']:
            saved = result['record']
            saved_stale = result['stale']
            if result['stale']:
                st.warning('The source evidence changed since this saved version. Its download is historical; prepare a fresh export before requesting delivery.')
            else:
                st.caption('This saved version matches the current input digests.')
            st.caption('Branch files: ' + saved['path'])
            with st.expander('Saved export contents'):
                st.code(saved['graph'], language='json')
            st.download_button('Download saved JSON-LD', saved['graph'], file_name=f'{chosen}.jsonld', mime='application/ld+json', key=PREFIX + 'download_graph')
            st.download_button('Download saved SHACL shapes', saved['shapes'], file_name=f'{chosen}-shapes.jsonld', mime='application/ld+json', key=PREFIX + 'download_shapes')
    if report['unreadable_versions']:
        st.warning('A saved bundle is unreadable or was edited after validation. Prepare a fresh version; existing files are preserved for review.')
    st.markdown('**Prepare the current graph**')
    if pending := st.session_state.pop(PREFIX + 'pending_namespace', None):
        st.session_state[PREFIX + 'namespace'] = pending
    namespace = st.text_input('Organisation-owned identifier namespace', key=PREFIX + 'namespace', max_chars=240,
        placeholder='Enter the namespace supplied by your identifier owner',
        help='Use the absolute HTTPS or HTTP namespace your organisation owns. Existing concept IRIs recorded in NAME_LIFECYCLE.yaml are reused. The namespace is not a delivery endpoint and is never guessed from a product name.')
    if saved and st.button('Use this saved version’s namespace', key=PREFIX + 'reuse_namespace'):
        st.session_state[PREFIX + 'pending_namespace'] = saved['namespace']
        st.rerun()
    if st.session_state.get(PREFIX + 'namespace_basis') != namespace:
        st.session_state[PREFIX + 'namespace_confirmed'] = False
        st.session_state[PREFIX + 'save_confirmed'] = False
        st.session_state[PREFIX + 'namespace_basis'] = namespace
    owned = st.checkbox('I confirmed that my organisation owns this identifier namespace.', key=PREFIX + 'namespace_confirmed')
    proposal = st.session_state.get(PREFIX + 'proposal')
    stale = proposal is not None and (proposal['input_digest'] != report['input_digest'] or proposal['namespace'] != namespace.rstrip('/'))
    if stale:
        st.session_state[PREFIX + 'save_confirmed'] = False
        st.warning('The inputs or namespace changed after the preview. Prepare the current graph again; the previous preview remains available for comparison.')
    if st.button('Prepare and validate graph', key=PREFIX + 'prepare', disabled=not namespace.strip()):
        prepared = backend.prepare(root, pack, actor_id, namespace=namespace, expected_digest=report['input_digest'], allowed_packs=allowed_packs)
        _errors(prepared)
        if prepared['ok']:
            st.session_state[PREFIX + 'proposal'] = prepared['proposal']
            st.session_state[PREFIX + 'save_confirmed'] = False
            proposal, stale = prepared['proposal'], False
    if proposal:
        navigation = _inspect(proposal)
        if navigation:
            return navigation
        with st.expander('Before and after graph statements', expanded=True):
            if saved:
                st.code(backend.difference(saved['graph'], proposal['graph']), language='diff')
            else:
                st.caption('First export: the before version is empty.')
                st.code(backend.difference('', proposal['graph']), language='diff')
        st.caption('Saving creates immutable graph.jsonld, shapes.jsonld and manifest.json in this product’s handoff/semantic_exports folder. Review and commit them with your branch when ready.')
        confirmed = st.checkbox('I reviewed these exact graph statements, withheld content and validation results.', key=PREFIX + 'save_confirmed')
        editable = local_demo and can_write
        if not editable:
            st.info('This session can inspect exports. An authorised local editor saves the reviewed branch files.')
        if st.button('Save validated export files', key=PREFIX + 'save', disabled=not (editable and owned and confirmed and not stale and proposal['validation'].get('state') == 'conforms')):
            result = backend.save(root, pack, actor_id, proposal, confirmed=confirmed, namespace_confirmed=owned,
                allowed_packs=allowed_packs, local_demo=local_demo, can_write=can_write)
            _errors(result)
            if result['ok']:
                st.session_state[PREFIX + 'notice'] = 'Validated export files saved for branch review. No graph service was updated.' if result['changed'] else 'This exact validated export version is already recorded.'
                return {'route': backend.ROUTE, 'params': {'version_id': result['record']['id']}, 'changed': result['changed']}
    if saved:
        with st.expander('Request delivery to a graph consumer'):
            st.caption('Engineering receives the exact saved file and digest. Enter the destination or responsible team; this page does not contact an external endpoint.')
            destination = st.text_input('Destination or graph service team', key=PREFIX + 'destination', max_chars=500)
            note = st.text_area('What should Engineering verify?', key=PREFIX + 'delivery_note', max_chars=1800,
                help='For example: verify this namespace and the target graph’s import procedure, then report the received graph digest.')
            basis = (chosen, saved['manifest_sha256'], report['input_digest'], destination, note)
            if st.session_state.get(PREFIX + 'delivery_basis') != basis:
                st.session_state[PREFIX + 'delivery_confirmed'] = False
                st.session_state[PREFIX + 'delivery_basis'] = basis
            confirmed = st.checkbox('I reviewed this saved export and want to request delivery.', key=PREFIX + 'delivery_confirmed')
            if st.button('Request Engineering delivery', key=PREFIX + 'handoff', disabled=not (local_demo and can_write and not saved_stale and confirmed and destination.strip() and note.strip())):
                result = backend.request_delivery(root, pack, actor_id, chosen, destination=destination, note=note, confirmed=confirmed,
                    allowed_packs=allowed_packs, local_demo=local_demo, can_write=can_write)
                _errors(result)
                if result['ok']:
                    return {'route': 'handoffs', 'params': {'handoff_id': result['handoff']['id']}, 'changed': True}
    return None
