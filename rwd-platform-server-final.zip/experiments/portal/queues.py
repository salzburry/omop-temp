"""The portal's four deterministic flows as pure functions: status (the snapshot), the ranked
open-question queue, the escalation queue, and evidence packets.

WHY A MODULE. The deck's 80/20 rule: most interactions are status and retrieval and never need a
model. These functions read committed pages and the agent's gitignored exhaust and return plain
dicts; the Streamlit tabs only render them. Nothing here writes, and nothing here decides — an
escalation is a question FOR a person, a packet is evidence FOR a person, and the one place a
model is invoked (resuming an escalation with a person's answer) is an explicit, attributed act
in the tab, not in this module. Testable without Streamlit (platform/tests/test_portal_queues.py).
"""
from __future__ import annotations

import glob
import json
import os
import re

_RANK_RE = re.compile(r"^## (\d+)\. `([^`]+)`.*?unblocks (\d+) record", re.M)
_OWNER_RE = re.compile(r"^\*\*Owner:\*\*\s*(.+)$", re.M)
# the two unranked sections list decisions as bullets: "- `ID` (owner) — question" or "- `ID` — q"
_BULLET_RE = re.compile(r"^- `([^`]+)`(?:\s*\(([^)]*)\))?", re.M)

# The generated page quotes each register row's Owner cell VERBATIM, and recorded rows still carry
# the pre-rename team tokens (history is never rewritten). The portal shows the functional name
# beside the quoted one; it never edits the page.
LEGACY_OWNERS = {"RWB": "Science", "RWP": "DataExpert", "RWDE": "Engineering"}


def owner_display(owner: str) -> str:
    parts = [p.strip() for p in re.split(r"[/,]", owner or "") if p.strip()]
    shown = [LEGACY_OWNERS.get(p.upper(), p) for p in parts]
    return "/".join(shown) if shown else "?"


def ranked_questions(page: str) -> list[dict]:
    """The generated open-question page -> [{rank, id, unblocks, owner, owner_display}] in the
    page's own order: the ranked headings first (blast radius), then the bullets of the unranked
    sections ("blocking no record", "output layer") with unblocks 0. Nothing is re-ranked here —
    decision_report.py ranks; this only reads."""
    out, seen = [], set()
    heads = list(_RANK_RE.finditer(page))
    for i, m in enumerate(heads):
        seg = page[m.end(): heads[i + 1].start() if i + 1 < len(heads) else len(page)]
        o = _OWNER_RE.search(seg)
        owner = o.group(1).strip() if o else "?"
        out.append({"rank": int(m.group(1)), "id": m.group(2), "unblocks": int(m.group(3)),
                    "owner": owner, "owner_display": owner_display(owner)})
        seen.add(m.group(2))
    tail_start = heads[-1].end() if heads else 0
    for m in _BULLET_RE.finditer(page[tail_start:]):
        did = m.group(1)
        if did in seen:
            continue
        owner = (m.group(2) or "?").strip()
        out.append({"rank": len(out) + 1, "id": did, "unblocks": 0, "owner": owner,
                    "owner_display": owner_display(owner)})
        seen.add(did)
    return out


def top_question(page: str, owner: str | None = None) -> dict | None:
    """The ONE question to ask now: highest blast radius, optionally for one owner. The
    answer-decisions rule — a stakeholder gets one question at a time, in packet order."""
    for q in ranked_questions(page):
        if owner is None or owner.lower() in q["owner"].lower() \
                or owner.lower() in q["owner_display"].lower():
            return q
    return None


# MALFORMED RECORDS ARE QUARANTINED, NOT RAISED. A string-valued `critic` and a numeric `steps`
# are valid JSON that took a tab down (audit 6). Each reader keeps the shape it needs, reports
# what it set aside, and never lets one bad file hide the good ones.
_QUARANTINE: dict[str, list[dict]] = {}


def quarantined(directory: str) -> list[dict]:
    """[{file, why}] set aside by the last read of `directory`."""
    return list(_QUARANTINE.get(os.path.realpath(directory), []))


def _load_records(directory: str) -> list[tuple[str, dict]]:
    good, bad = [], []
    for f in sorted(glob.glob(os.path.join(directory, "*.json"))):
        if "scorecard" in os.path.basename(f):
            continue
        try:
            d = json.load(open(f, encoding="utf-8"))
        except (ValueError, OSError) as e:
            bad.append({"file": os.path.basename(f), "why": f"unreadable: {type(e).__name__}"})
            continue
        if not isinstance(d, dict):
            bad.append({"file": os.path.basename(f), "why": "not a JSON object"})
            continue
        good.append((f, d))
    _QUARANTINE[os.path.realpath(directory)] = bad
    return good


def _mentions(goal: str, pack: str | None) -> bool:
    """A run belongs to a pack when its goal names the pack path; a run naming no pack is
    GLOBAL and appears only in the unscoped view, never under every pack (audit 6)."""
    return pack is None or (pack in (goal or ""))


def _within(goal: str, within) -> bool:
    """Membership: a run belongs to the actor's packs when its goal names one of them. With a
    membership set, a run naming NO pack is excluded too — a prostate-only reviewer must not read
    an escalation that could be about ovarian (audit 7: membership filtered the selector only)."""
    if within is None:
        return True
    return any(p in (goal or "") for p in within)


def escalations(runs_dir: str, to: str | None = None, pack: str | None = None,
                within=None) -> list[dict]:
    """Every run that ended by asking a person, newest first: who it is for, the question, the
    evidence the agent cited, who asked, and whether a resume already answered it (the original
    run's append-only `answered` step, written by orchestrator.resume_run, or a successor run's
    `human_answer` step naming it). `within` — the actor's pack membership — bounds every view."""
    rows, answered, eligibility, attempts = [], {}, {}, {}
    records = _load_records(runs_dir)
    bad = _QUARANTINE[os.path.realpath(runs_dir)]
    for f, d in records:
        steps = d.get("steps")
        if not isinstance(steps, list) or not all(isinstance(s, dict) for s in steps):
            bad.append({"file": os.path.basename(f), "why": "steps is not a list of objects"})
            continue
        outcome = d.get("outcome") if isinstance(d.get("outcome"), dict) else {}
        # A SUCCESSOR ANSWERS ONLY IF IT FINISHED (independent review of audit 8): its human_answer
        # step is written before its loop runs, so an exhausted or refused successor carried one and
        # the queue closed the question the orchestrator had left open.
        accepted = str(outcome.get("status")) in ("done", "escalated")
        for s in steps:
            if s.get("kind") == "human_answer" and s.get("answers_run") and accepted:
                answered.setdefault(str(s["answers_run"]), str(s.get("by") or "?"))
                eligibility.setdefault(str(s["answers_run"]), str(s.get("eligibility") or "unverified"))
            if s.get("kind") == "answered":
                answered[str(d.get("run_id"))] = str(s.get("by") or "?")
                eligibility[str(d.get("run_id"))] = str(s.get("eligibility") or "unverified")
            if s.get("kind") == "answer_attempt":
                attempts[str(d.get("run_id"))] = attempts.get(str(d.get("run_id")), 0) + 1
        if outcome.get("status") != "escalated":
            continue
        if not _mentions(str(d.get("goal") or ""), pack) or not _within(str(d.get("goal") or ""), within):
            continue
        try:
            esc = json.loads(outcome.get("summary") or "{}")
            if not isinstance(esc, dict):
                esc = {"question": str(outcome.get("summary"))[:400]}
        except (ValueError, TypeError):
            esc = {"question": str(outcome.get("summary"))[:400]}
        actor = d.get("actor") if isinstance(d.get("actor"), dict) else {}
        rows.append({"run_id": d.get("run_id"), "to": str(esc.get("to") or "?"),
                     "question": str(esc.get("question") or "")[:600],
                     "evidence": str(esc.get("evidence") or "")[:1200],
                     "asked_by": actor.get("name") or "cli",
                     "goal": str(d.get("goal") or "")[:200],
                     "at": str(d.get("run_id") or "")[:15]})
    if to:
        rows = [r for r in rows if to.lower() in r["to"].lower()]
    rows.sort(key=lambda r: r["run_id"] or "", reverse=True)
    for r in rows:
        r["answered"] = r["run_id"] in answered
        r["answered_by"] = answered.get(r["run_id"])
        r["eligibility"] = eligibility.get(r["run_id"])
        r["attempts"] = attempts.get(r["run_id"], 0)
    return rows


def packets(candidates_dir: str, pack: str | None = None, within=None) -> list[dict]:
    """The candidate workspace, newest first: what each specialist produced, for whom, with the
    critic's verdict and the HUMAN decision line every packet carries. Under a selected pack only
    that pack's packets appear; a packet naming no pack belongs to the unscoped view — and with a
    membership set (`within`), a packet outside it, or naming no pack, is never shown."""
    rows = []
    records = _load_records(candidates_dir)
    bad = _QUARANTINE[os.path.realpath(candidates_dir)]
    for f, d in records:
        if not d.get("kind"):
            continue
        if pack is not None and d.get("pack") != pack:
            continue
        if within is not None and d.get("pack") not in within:
            continue
        crit = d.get("critic")
        if crit is not None and not isinstance(crit, dict):
            bad.append({"file": os.path.basename(f), "why": "critic is not an object"})
            crit = {"falsified": "?", "route": "malformed verdict"}
        crit = crit or {}
        body = d.get("assembly") or d.get("proposal") or d.get("diagnosis") or {}
        body = body if isinstance(body, dict) else {}
        rows.append({"path": f, "file": os.path.basename(f), "kind": str(d["kind"]),
                     "pack": d.get("pack"), "generated_at": d.get("generated_at"),
                     "requirement": d.get("requirement"),
                     "critic": (f"falsified={crit.get('falsified')} route={crit.get('route')}"
                                if crit else "no critic verdict"),
                     "second_vote": crit.get("second_vote_recommended"),
                     "decision": str(d.get("decision") or "")[:160],
                     "summary": str(body.get("summary") or "")[:400]})
    rows.sort(key=lambda r: str(r["generated_at"] or ""), reverse=True)
    return rows


def forward_text(row: dict) -> str:
    """The forwardable block for a packet or an escalation: what it is, what it needs, and the
    sentence that keeps the boundary — the person decides; nothing here did."""
    if "question" in row:
        return (f"ESCALATION for {row['to']} (run {row['run_id']}, asked by {row['asked_by']})\n\n"
                f"Question: {row['question']}\n\nEvidence the agent cited: {row['evidence']}\n\n"
                f"Answering is your act: reply in the portal to resume the run with your answer "
                f"attributed to you, and record it in the repository if it is a decision.")
    return (f"EVIDENCE PACKET {row['kind']} for {row['pack']} ({row['file']})\n"
            f"Critic: {row['critic']}"
            + ("; a second vote is recommended" if row.get("second_vote") else "") + "\n"
            f"Decision line: {row['decision']}\n\n{row['summary']}\n\n"
            f"This is evidence for a person; it approves, binds and records nothing.")


def queue_counts(page: str, runs_dir: str, candidates_dir: str, pack: str | None = None) -> dict:
    """The three sidebar numbers, all scoped to `pack` when one is selected."""
    return {"open_questions": len(ranked_questions(page)),
            "escalations_open": sum(1 for e in escalations(runs_dir, pack=pack) if not e["answered"]),
            "packets": len(packets(candidates_dir, pack)),
            "quarantined": len(quarantined(runs_dir)) + len(quarantined(candidates_dir))}


# WHAT A RECORDED STEP MEANS, IN A PERSON'S WORDS. The page used to print the step's kind verbatim
# ("refused_ungrounded: ..."); these are the sentences a reviewer reads instead (audit 8).
STEP_LABELS = {
    "authority_detected": "A person decides here",
    "budget_exhausted": "Stopped: the cost limit was reached",
    "time_budget_exhausted": "Stopped: the time limit was reached",
    "refused_ungrounded": "Refused: the agent tried to answer without checking anything",
    "refused_claimed_act": "Refused: the agent worded an approval or a recording, which only a person can do",
    "human_answer": "A person answered",
    "escalation_rerouted": "Sent to the operator instead: the agent named someone who is not a registered owner",
    "answer_attempt": "An answer was tried, but the run did not finish, so the question stays open",
}


def describe_step(step: dict) -> str | None:
    """A plain sentence for a recorded step, or None for steps the page renders itself."""
    label = STEP_LABELS.get(str(step.get("kind")))
    if not label:
        return None
    detail = step.get("marker") or step.get("why") or step.get("by") or step.get("requested") or ""
    return f"{label}: {detail}" if detail else label


# THE LIFECYCLE AS ONE ROW OF STEPS (ninth review): computed from evidence the page already reads —
# the snapshot's gates, the open questions, whether source evidence exists, the record count, the
# kept requests — never typed. A fixture never reaches Candidate, QC or Release.
LIFECYCLE = ("Brief", "Specification", "Decisions", "Source fitness", "Configuration", "Candidate", "QC", "Release")


NO_SNAPSHOT = "not evaluated: no governance snapshot for this checkout (build it in Overview)"


def records_on_disk(pack_dir: str) -> int:
    """The contract's record count read from the pack itself, for a checkout with no snapshot yet.

    Without a snapshot the strip said "no extraction yet" about a fixture carrying two hundred
    records (a person testing the pushed branch, 2026-09-04): the count came from the snapshot's
    entry alone, and an absent entry read as zero. The contract file is the fact; it is cheap."""
    import os  # noqa: PLC0415
    import sys  # noqa: PLC0415
    path = os.path.join(pack_dir, "handoff", "FUNCTIONAL_CONTRACT.md")
    if not os.path.exists(path):
        return 0
    # THE ONE READER of contract records is contract_lint's; a second parser here would count
    # something else on the day the table gains a column
    sys.path.insert(0, os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))),
                                    "platform", "tools"))
    try:
        import contract_lint as cl  # noqa: PLC0415
        return sum(1 for _ in cl.records(cl.read(path)))
    except Exception:  # noqa: BLE001 - an unreadable contract counts as nothing, and the page says so elsewhere
        return 0


def source_evidence_on_disk(pack_dir: str) -> bool:
    import os  # noqa: PLC0415
    return os.path.exists(os.path.join(pack_dir, "handoff", "SOURCE_VERDICTS.md"))


def extracted_rows(pack_dir: str) -> int:
    """How many specification rows the pack's extraction carries (0 when there is none): the strip
    said 'no extraction yet' about packs whose extraction existed, because it was reading the
    contract record count and wording it as extraction (thirteenth pass, J5)."""
    import json                                                              # noqa: PLC0415
    path = os.path.join(pack_dir, "spec_pipeline", "out", "extracted.json")
    if not os.path.isfile(path):
        return 0
    try:
        with open(path, encoding="utf-8") as fh:
            doc = json.load(fh)
    except (OSError, ValueError):
        return 0
    rows = doc.get("rows") if isinstance(doc, dict) else doc
    return len(rows) if isinstance(rows, list) else 0


def lifecycle(entry: dict | None, open_questions: int = 0, has_source_evidence: bool = False,
              records: int = 0, kept_requests: int = 0, fixture: bool | None = None,
              extracted: int = 0) -> list[dict]:
    """The row of steps. `entry` is the snapshot's entry for the pack, or None when this checkout
    has no snapshot: then the gate verdict says so in words, and everything else is what the
    files say (the callers pass disk-read counts), never "not built" about a pack nobody evaluated."""
    have_snapshot = entry is not None
    entry = entry or {}
    gates = {str(g.get("gate")): str(g.get("status") or "") for g in (entry.get("gates") or []) if isinstance(g, dict)}
    if fixture is None:
        fixture = str(entry.get("kind") or "") == "fixture"

    def st(name, state, why):
        return {"name": name, "state": state, "why": why}
    out = [st("Brief", "done" if kept_requests else "not started",
              f"{kept_requests} kept request(s)" if kept_requests else "no request kept yet"),
           st("Specification", "done" if records else ("open" if extracted else "not started"),
              (f"{records} contract record(s) drafted from {extracted} specification row(s)" if records and extracted
               else f"{records} contract record(s)" if records
               else f"{extracted} specification row(s) extracted, no contract record yet" if extracted
               else "no specification extracted yet")),
           st("Decisions", "open" if open_questions else ("done" if records else "not started"),
              f"{open_questions} open question(s) for a person" if open_questions else "nothing open"),
           st("Source fitness", "done" if has_source_evidence else "blocked",
              "reviewed mapping evidence present" if has_source_evidence else "no source evidence for this pack"),
           # GATE 4 IS THE CONFIGURATION GATE, and status.results() emits done / in progress / not started /
           # blocked — this step keyed on Gate 2 and on a word nothing emits, so it could never read done
           # (the fourteenth pass, 2026-09-05)
           st("Configuration", "done" if gates.get("4", "") == "done" else ("open" if gates.get("4", "") == "in progress" or records else "not started"),
              f"gate 4: {gates.get('4') or 'not evaluated'}" if have_snapshot else NO_SNAPSHOT)]
    for name in ("Candidate", "QC", "Release"):
        out.append(st(name, "not started", "a reference fixture never builds or releases" if fixture else "not built"))
    return out


def question_card(q: dict, packet_text: str = "") -> dict:
    """A plain card for one open question: the text without markup, what it blocks, who owns it,
    how much evidence the packet cites, where the form is, and the three acts a PERSON may take."""
    text = re.sub(r"<br\s*/?>", " ", str(q.get("question") or q.get("id") or ""), flags=re.I)
    text = re.sub(r"<[^>]+>", "", text)
    evidence = [l.strip() for l in str(packet_text or "").splitlines() if l.strip().startswith("- ")]
    form = next((m.group(0) for m in re.finditer(r"\S*decision_answers/\S+\.yaml", str(packet_text or ""))), "")
    return {"id": q.get("id"), "question": " ".join(text.split()), "unblocks": int(q.get("unblocks") or 0),
            "owner": q.get("owner_display") or q.get("owner") or "?", "recorded_owner": q.get("owner") or "?",
            "evidence_count": len(evidence), "evidence": evidence[:6], "form": form,
            "actions": ["answer", "defer", "needs evidence"],
            "note": "Answering is the owner's act, recorded through the decision form; deferring and asking for "
                    "evidence are said in the form too. Nothing here records anything."}


# OWNERS FROM THE REGISTER (tenth review: three questions showed owner `?` because the generated
# page's unranked bullets carry no owner while DECISIONS.md does). The page stays the ranking; the
# register fills the owner a bullet lacks. Pure text parsing of the register's markdown table.
def owners_from_register(decisions_md: str) -> dict:
    """{decision id: Owner cell} from a markdown table whose header names an id column and Owner."""
    out, cols = {}, None
    for line in str(decisions_md or "").splitlines():
        if not line.strip().startswith("|"):
            cols = None if cols is None else cols
            continue
        cells = [c.strip() for c in line.strip().strip("|").split("|")]
        low = [c.lower() for c in cells]
        if "owner" in low and any(c in ("id", "decision", "decision id", "decision_id") for c in low):
            cols = {"id": next(i for i, c in enumerate(low) if c in ("id", "decision", "decision id", "decision_id")),
                    "owner": low.index("owner")}
            continue
        if cols and len(cells) > max(cols.values()) and not set(cells[cols["id"]]) <= set("-: "):
            did = cells[cols["id"]].strip("`* ")
            if did:
                out[did] = cells[cols["owner"]].strip("`* ")
    return out


def fill_owners(ranked: list[dict], decisions_md: str) -> list[dict]:
    reg = owners_from_register(decisions_md)
    for q in ranked:
        if q.get("owner") in (None, "", "?") and reg.get(str(q.get("id"))):
            q["owner"] = reg[str(q["id"])]
            q["owner_display"] = owner_display(q["owner"])
    return ranked


# THE SNAPSHOT'S SHAPES, READ DEFENSIVELY (seen 2026-09-04: `records` is a mapping whose `records` key is
# the count, and `next_action` is a [gate, owner, reason] triple; the page did int(dict) and printed the
# raw list)
def record_count(entry) -> int:
    r = (entry or {}).get("records") if isinstance(entry, dict) else None
    if isinstance(r, dict):
        r = r.get("records") or r.get("total") or 0
    try:
        return int(r or 0)
    except (TypeError, ValueError):
        return 0


def next_action_text(na) -> str:
    """One sentence for the snapshot's next action, whatever shape it came in."""
    if isinstance(na, (list, tuple)) and len(na) == 3:
        gate, owner, reason = na
        reason = re.sub(r"^\s*gate\s*\d+\s*:\s*", "", str(reason), flags=re.I)     # the reason often names the gate too
        if gate in (None, "", "None"):
            # a released product has no next gate; this read 'Gate None: every gate is done. Owner: ?.'
            return str(reason).rstrip(".") + "." if str(reason).strip() else "Every gate is done; the release is receipted."
        return f"Gate {gate}: {reason}. Owner: {owner}."
    if isinstance(na, dict):
        parts = [str(na.get(k)) for k in ("gate", "action", "reason", "owner") if na.get(k)]
        return ". ".join(parts) + "." if parts else str(na)
    return str(na or "")
