"""Paired correction checks over the canonical case runner and retained run format.

Only the evaluation's context changes. A checked correction is never activated,
withdrawn, adjudicated or turned into a training label by this module.
"""
from __future__ import annotations

from datetime import datetime, timezone
import contextlib
import importlib
import io
import json
import os
from pathlib import Path
import re
import sys
import tempfile
import time
from types import SimpleNamespace
import uuid

import model_lifecycle_workspace as lifecycle
import model_lifecycle_runtime as runtime
import portal_agent_connection as connection
import portal_runtime
import scientific_definition_ai as ai
import specialist_workspace as specialists
import workflow_skills

CODE = Path(__file__).resolve().parents[2]
RECORD_TYPE = 'correction_paired_evaluation'
OBJECTIVE = 'governed_orchestration_model'
MAX_CASES = 3
MAX_SECONDS = 360
ARM_SECONDS = 90
NOTICE = ('Compare the same accessible cases with and without one software-checked correction. '
          'Mechanical checks and exact outputs support human review; done or escalated alone is not semantic correctness. '
          'The correction is not activated, and no scientific approval, release or training label is created.')


class Invalid(ValueError):
    pass


def _guard(fn):
    try:
        return fn()
    except Invalid as error:
        return {'ok': False, 'changed': False, 'errors': [str(error)]}
    except Exception:
        return {'ok': False, 'changed': False, 'errors': ['The comparison inputs or retained record are unavailable within your current access. Refresh the product, correction and assistant connection.']}


def _scope(root, pack, actor_id, allowed_packs):
    if not isinstance(pack, str) or not runtime.PACK.fullmatch(pack):
        raise Invalid('Choose a working product with reviewed AI-readable source evidence before comparing corrections. A productless chat does not establish the case source context.')
    if not isinstance(actor_id, str) or not actor_id.strip() or len(actor_id) > 200:
        raise Invalid('Choose the local identity that will own this comparison.')
    return lifecycle._scope(root, pack, actor_id, allowed_packs)


def _target(root, pack, correction_id, allowed):
    loop = workflow_skills.learning()
    row = loop.read_correction(root, correction_id)
    check = row.get('check') or {}
    if (row['status'] not in {'checked', 'active'} or check.get('passed') is not True
            or check.get('tests') != loop.DEFAULT_TESTS[row['skill']]
            or check.get('source_digest') != loop.software_digest(root)
            or row['skill_sha256'] != loop._skill_hash(root, row['skill'])):
        raise Invalid('Run passing registered software checks on this correction and the current branch before comparing its behavior. Global activation is not required.')
    connection.check_input(row)
    if (row.get('scope') or {}).get('kind') == 'legacy_context':
        raise Invalid('Resolve this imported lesson\'s product scope before preparing a paired comparison.')
    mentioned = set(runtime.CASE_PACK.findall(json.dumps(row, ensure_ascii=False).replace('\\\\', '/')))
    if any(p not in allowed or (p != pack and not p.startswith('fixtures/')) for p in mentioned):
        raise Invalid('This correction references another product or source outside this comparison. Choose its own product and current access.')
    return row, sorted(mentioned | {pack})


def _own_case(row, scopes):
    return {'case': {'id': 'correction-' + row['id'], 'goal': row['eval_goal'],
        'expect': {'outcome': ['done', 'escalated']}, 'source': 'Selected reviewed correction example',
        'skill': row['skill'], 'provenance': 'human', 'adjudicated': False,
        'scope': row.get('scope', {'kind': 'global'}),
        'evidence_mode': 'reviewed_workflow_correction', 'training_eligible': False,
        'adjudicate': 'Compare the exact observed behavior against this correction: ' + row['right'] +
            '. Check whether the prior error recurs: ' + row['wrong'] + '. An outcome code alone is not correctness.',
        'familiar_example': True}, 'packs': scopes}


def _options(root, pack, actor_id, correction_id, allowed_packs):
    root, pack = _scope(root, pack, actor_id, allowed_packs)
    allowed = sorted(set(allowed_packs or [pack]))
    target, scopes = _target(root, pack, correction_id, allowed)
    source = lifecycle.case_options(root, pack, actor_id, allowed_packs=allowed)
    own = _own_case(target, scopes)
    cases = [own] + [row for row in source['cases']
                     if row['case'].get('evidence_mode') != 'reviewed_workflow_correction']
    active = workflow_skills.learning().active_corrections(root, include_scoped=True)
    before = sorted(row['id'] for row in active if row['id'] != target['id'])
    value = {'ok': True, 'pack': pack, 'actor_id': actor_id,
        'correction': {key: target[key] for key in ('id', 'digest', 'skill', 'skill_sha256', 'status', 'wrong', 'right', 'context', 'eval_goal')},
        'cases': cases, 'own_case_id': own['case']['id'], 'connection': source['connection'],
        'software_digest': target['check']['source_digest'],
        'library_digest': workflow_skills.correction_library_digest(root),
        'corpus_digest': runtime.digest({'canonical': source['corpus_digest'], 'cases': cases}),
        'before_ids': before, 'after_ids': sorted(before + [target['id']]),
        'allowed_packs': allowed, 'notice': NOTICE,
        'limits': {'max_cases': MAX_CASES, 'max_calls_per_arm': 4, 'max_seconds_per_arm': ARM_SECONDS,
                   'max_seconds_total': MAX_SECONDS, 'max_output_tokens': 2000},
        'errors': []}
    value['target'] = value['correction']
    value['ready'] = bool(source['connection'].get('ok'))
    if not value['ready']:
        value['errors'].append('Connect the explicitly selected assistant before running a comparison.')
    if any(specialists._eligibility(root, selected) for selected in scopes):
        value['ready'] = False
        value['errors'].append('Complete the existing product and reference AI-access reviews before sending these cases.')
    value['digest'] = runtime.digest(value)
    return value


def options(root, pack, actor_id, correction_id, *, allowed_packs=None):
    return _guard(lambda: _options(root, pack, actor_id, correction_id, allowed_packs))


def _preview(root, pack, actor_id, correction_id, case_ids, expected_digest, allowed_packs, request_id=None):
    value = _options(root, pack, actor_id, correction_id, allowed_packs)
    if expected_digest is not None and expected_digest != value['digest']:
        raise Invalid('The correction, cases, branch or connection changed. Refresh the available cases before preparing this comparison.')
    if not isinstance(case_ids, list) or len(case_ids) != len(set(case_ids)) or any(not isinstance(x, str) for x in case_ids):
        raise Invalid('Select distinct accessible case identifiers.')
    chosen = [value['own_case_id']] + [x for x in case_ids if x != value['own_case_id']]
    if len(chosen) > MAX_CASES:
        raise Invalid('Compare the correction example and at most two additional cases.')
    lookup = {row['case']['id']: row for row in value['cases']}
    if any(x not in lookup for x in chosen):
        raise Invalid('A selected case is outside the available canonical corpus or source scope.')
    if not value['connection'].get('ok'):
        raise Invalid('Connect the explicitly selected assistant before previewing a comparison. No alternative provider will be used.')
    scoped = sorted({p for key in chosen for p in lookup[key]['packs']} | {pack})
    inputs = {}
    for selected in scoped:
        if specialists._eligibility(Path(root), selected):
            raise Invalid('A selected case source still needs its existing AI-access review. Complete Product progress for the selected product and references first.')
        inputs[selected] = specialists.science._digest(specialists._inputs(Path(root), selected))
    request_id = request_id or uuid.uuid4().hex
    if not re.fullmatch(r'[a-f0-9]{32}', str(request_id)):
        raise Invalid('Prepare a new explicit comparison request.')
    payload = {key: value[key] for key in ('pack', 'actor_id', 'correction', 'connection', 'software_digest',
        'library_digest', 'corpus_digest', 'before_ids', 'after_ids', 'allowed_packs', 'limits')}
    payload.update(root=str(Path(root).resolve()), request_id=request_id, cases=[lookup[x] for x in chosen],
                   options_digest=value['digest'], input_digests=inputs, objective_id=OBJECTIVE, notice=NOTICE)
    connection.check_input(payload)
    return dict(payload, digest=runtime.digest(payload), ok=True)


def preview(root, pack, actor_id, correction_id, case_ids, *, expected_digest=None, allowed_packs=None):
    return _guard(lambda: _preview(root, pack, actor_id, correction_id, case_ids, expected_digest, allowed_packs))


def _fresh(root, pack, actor, proposal, allowed):
    if not isinstance(proposal, dict):
        raise Invalid('Prepare the exact paired comparison before requesting any model calls.')
    fresh = _preview(root, pack, actor, proposal['correction']['id'],
        [row['case']['id'] for row in proposal['cases']], None, allowed, proposal['request_id'])
    if runtime.digest(fresh) != runtime.digest(proposal):
        raise Invalid('The preview, identity, source, branch, correction library or selected assistant changed. Prepare a fresh comparison before running it.')
    return fresh


def _journal(root, pack, request_id):
    if not re.fullmatch(r'[a-f0-9]{32}', str(request_id)):
        raise Invalid('Prepare a current comparison request.')
    path = specialists.science._safe(Path(root) / pack / '.portal-drafts/pair-evals' / (request_id + '.json'))
    if os.name == 'nt' and len(str(path)) > 235:
        raise Invalid('Use a shorter local checkout path before running this retained comparison.')
    return path


def _save_journal(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(uuid.uuid4().hex + '.tmp')
    try:
        payload = {key: item for key, item in value.items() if key != 'journal_sha256'}
        payload['journal_sha256'] = runtime.digest(payload)
        temporary.write_text(json.dumps(payload, ensure_ascii=False, allow_nan=False), encoding='utf-8')
        os.replace(temporary, path)
    finally:
        temporary.unlink(missing_ok=True)


def _error_arm(case, why):
    return {'result': {'case': case['id'], 'passed': False, 'checks': {'complete': False}, 'metrics': {}, 'error': why},
        'runs': [], 'outputs': [], 'delivery': [], 'elapsed_seconds': None,
        'excerpted_calls': 0, 'error': why, 'stale': False}


def _outputs(runs):
    return [{'run_id': entry['run']['run_id'], 'decisions': [s for s in entry['run']['steps'] if s.get('kind') == 'decision'],
             'outcome': entry['run']['outcome']} for entry in runs]


def _execute_arm(proposal, row, include_target, remaining_seconds):
    """One isolated invocation of the existing orchestrator/case scorer."""
    with tempfile.TemporaryDirectory(prefix='rwd-paired-check-') as directory:
        request = Path(directory) / 'request.json'
        response = Path(directory) / 'response.json'
        request.write_text(json.dumps({'proposal': proposal, 'case': row, 'include_target': include_target}, ensure_ascii=False), encoding='utf-8')
        completed = portal_runtime.run([sys.executable, str(Path(__file__).resolve()), '--worker', str(request), str(response)],
            cwd=proposal['root'], timeout_s=min(ARM_SECONDS + 10, max(1, int(remaining_seconds))),
            extra_env={'RWDP_STATE_DIR': directory, 'RWD_TOOL_TIMEOUT_S': '25', 'PYTHONDONTWRITEBYTECODE': '1',
                       'RWD_PORTAL_AI_PROVIDER': proposal['connection']['provider_id']})
        # Raw worker/provider stdout and stderr never enter retained results.
        if completed.returncode or not response.is_file() or response.stat().st_size > 600_000:
            return _error_arm(row['case'], 'The isolated case did not complete within its bounds. No automatic retry was attempted.')
        try:
            value = json.loads(response.read_text(encoding='utf-8'))
            _validate_arm(value, proposal, row)
            return value
        except Exception:
            return _error_arm(row['case'], 'The isolated case returned an unreadable or out-of-scope result. No automatic retry was attempted.')


def _validate_arm(arm, proposal, row):
    if (not isinstance(arm, dict) or not isinstance(arm.get('result'), dict)
            or arm['result'].get('case') != row['case']['id'] or type(arm['result'].get('passed')) is not bool
            or not isinstance(arm['result'].get('metrics'), dict) or not isinstance(arm['result'].get('checks'), dict)
            or not isinstance(arm.get('outputs'), list) or not isinstance(arm.get('delivery'), list)):
        raise Invalid('The recorded comparison arm is malformed.')
    runtime.validate_case_scope({'cases': [row], 'runs': arm.get('runs'), 'results': [arm['result']]},
                               proposal['pack'], proposal['allowed_packs'])
    if arm['outputs'] != _outputs(arm['runs']):
        raise Invalid('The displayed comparison output does not match its exact recorded transcript.')
    if not arm['result'].get('error') and arm['runs']:
        if len(arm['runs']) != 1:
            raise Invalid('A comparison arm must retain exactly its one canonical case transcript.')
        source = arm['runs'][0]['run']
        expected = lifecycle._case_runner().score(row['case'], SimpleNamespace(**source))
        if (source.get('execution') or {}).get('provider') != 'anthropic':
            for field in ('cost_usd', 'total_cost_usd'):
                expected['metrics'][field] = None
        if any(arm['result'].get(key) != expected.get(key) for key in ('case', 'run', 'passed', 'checks', 'metrics')):
            raise Invalid('The mechanical scores do not match the canonical scorer applied to the exact transcript.')
    if any(not isinstance(entry, dict) or not isinstance(entry.get('skill'), str)
           or not isinstance(entry.get('ids'), list) or any(not isinstance(i, str) for i in entry['ids'])
           for entry in arm['delivery']):
        raise Invalid('The correction delivery observations are malformed.')
    connection.check_input(arm)


def _comparison(before, after, correction):
    reasons = []
    if before.get('error') or after.get('error') or before['result'].get('error') or after['result'].get('error') or not before['runs'] or not after['runs']:
        reasons.append('At least one side did not complete.')
    for arm in (before, after):
        for entry in arm['runs']:
            source = entry['run']
            receipt = source.get('execution') or {}
            if (receipt.get('mode') != 'canonical_case_evaluation'
                    or receipt.get('sha256') != runtime.digest({k: v for k, v in receipt.items() if k != 'sha256'})
                    or receipt.get('run_sha256') != runtime.digest(runtime.basis(source, receipt.get('step_count')))):
                reasons.append('A side lacks collected canonical case execution evidence.')
            if (source.get('outcome') or {}).get('status') not in {'done', 'escalated'}:
                reasons.append('A side stopped before reaching a complete case outcome.')
    if before.get('stale') or after.get('stale'):
        reasons.append('The inputs changed during a run.')
    if before.get('excerpted_calls') or after.get('excerpted_calls'):
        reasons.append('A model request was truncated.')
    deliveries = []
    for arm in (before, after):
        relevant = [entry for entry in arm['delivery'] if isinstance(entry, dict) and entry.get('skill') == correction['skill']]
        deliveries.append({item for entry in relevant for item in entry.get('ids', []) if isinstance(item, str)})
        if not relevant:
            reasons.append('The intended skill was not exercised on both sides.')
    if correction['id'] in deliveries[0]:
        reasons.append('The target correction reached the baseline.')
    if correction['id'] not in deliveries[1]:
        reasons.append('The target correction was not delivered on the after side.')
    other_after = deliveries[1] - {correction['id']}
    delivery_changes = {'before_only': sorted(deliveries[0] - other_after),
                        'after_only': sorted(other_after - deliveries[0]),
                        'notice': 'Differences can reflect bounded retrieval displacement or a changed agent path. The frozen library differs only by the target; inspect the exact delivery traces.'}
    checks = {}
    for key in sorted(set(before['result']['checks']) | set(after['result']['checks'])):
        checks[key] = {'before': before['result']['checks'].get(key), 'after': after['result']['checks'].get(key)}
    metrics = {}
    for key in ('total_calls', 'calls', 'latency_s', 'total_cost_usd', 'cost_usd'):
        a, b = before['result']['metrics'].get(key), after['result']['metrics'].get(key)
        metrics[key] = {'before': a, 'after': b, 'delta': b - a if type(a) in (int, float) and type(b) in (int, float) else None}
    return {'valid_pair': not reasons, 'inconclusive_reasons': list(dict.fromkeys(reasons)),
        'checks': checks, 'metrics': metrics, 'delivery_changes': delivery_changes, 'semantic_improvement': None,
        'notice': 'These are paired mechanical observations. Read both exact outputs against the human rubric; a done/escalated outcome alone establishes no semantic gain.'}


def _record(proposal, arms, *, interrupted=False):
    pairs, runs, results = [], [], []
    for index, row in enumerate(proposal['cases']):
        values = []
        for side in ('before', 'after'):
            value = arms.get(str(index) + ':' + side) or _error_arm(row['case'], 'This side was not run; prepare a new request for an explicit retry.')
            _validate_arm(value, proposal, row)
            values.append(value)
            runs.extend(value['runs'])
            results.append(value['result'])
        pairs.append({'case': row['case'], 'packs': row['packs'], 'before': values[0], 'after': values[1],
                      'comparison': _comparison(*values, proposal['correction'])})
    return {'record_type': RECORD_TYPE, 'request_id': proposal['request_id'], 'preview_digest': proposal['digest'],
        'objective_id': OBJECTIVE, 'recorded_by': proposal['actor_id'], 'correction': proposal['correction'],
        'connection': proposal['connection'], 'cases': proposal['cases'], 'runs': runs, 'results': results, 'pairs': pairs,
        'binding': {key: proposal[key] for key in ('root', 'software_digest', 'library_digest', 'corpus_digest', 'input_digests', 'allowed_packs', 'limits', 'before_ids', 'after_ids')},
        'interrupted': interrupted, 'stale_at_completion': any(a.get('stale') for a in arms.values()),
        'adjudicated': False, 'training_eligible': False, 'semantic_improvement': None,
        'created_at': datetime.now(timezone.utc).isoformat(), 'notice': NOTICE}


def _run(root, pack, actor_id, proposal, confirmed, local_demo, can_review, allowed_packs):
    if not (confirmed is True and local_demo is True and can_review is True):
        raise Invalid('Review this exact paired request and confirm running it with local review permission.')
    root, pack = _scope(root, pack, actor_id, allowed_packs)
    path = _journal(root, pack, proposal.get('request_id') if isinstance(proposal, dict) else None)
    path.parent.mkdir(parents=True, exist_ok=True)
    lock = path.with_suffix('.lock')
    import local_process_lock
    try:
        owner = local_process_lock.locked(lock, root)
        owner.__enter__()
    except ValueError:
        raise Invalid('This comparison is already running. Wait for its retained result; no duplicate calls were started.') from None
    try:
        if path.exists():
            saved = json.loads(path.read_text(encoding='utf-8'))
            if (saved.get('journal_sha256') != runtime.digest({k: v for k, v in saved.items() if k != 'journal_sha256'})
                    or runtime.digest(saved.get('proposal')) != runtime.digest(proposal)
                    or saved.get('actor_id') != actor_id or saved.get('preview_digest') != proposal.get('digest')):
                raise Invalid('This request belongs to another identity or preview.')
            if saved.get('evaluation_id'):
                return _read(root, pack, actor_id, saved['evaluation_id'], allowed_packs)
            # A previous interruption never silently repeats an uncertain call.
            try:
                _fresh(root, pack, actor_id, proposal, allowed_packs)
            except Exception:
                for arm in saved.get('arms', {}).values():
                    arm['stale'] = True
            record = _record(saved['proposal'], saved.get('arms', {}), interrupted=True)
        else:
            current = _fresh(root, pack, actor_id, proposal, allowed_packs)
            saved = {'actor_id': actor_id, 'preview_digest': current['digest'], 'proposal': current, 'arms': {}}
            _save_journal(path, saved)
            deadline = time.monotonic() + MAX_SECONDS
            stopped = False
            for index, row in enumerate(current['cases']):
                for side, enabled in (('before', False), ('after', True)):
                    key = str(index) + ':' + side
                    if portal_runtime.job_cancelled():
                        stopped = True
                    portal_runtime.job_progress('Comparing case ' + str(index + 1) + ' · ' + side)
                    if stopped or time.monotonic() >= deadline:
                        saved['arms'][key] = _error_arm(row['case'], 'The bounded comparison stopped before this side. No automatic retry was attempted.')
                        continue
                    try:
                        _fresh(root, pack, actor_id, current, allowed_packs)
                    except Exception:
                        saved['arms'][key] = _error_arm(row['case'], 'The frozen comparison inputs changed before this side; no model call was made.')
                        stopped = True
                        continue
                    saved['running'] = key
                    _save_journal(path, saved)
                    arm = _execute_arm(current, row, enabled, deadline - time.monotonic())
                    try:
                        _fresh(root, pack, actor_id, current, allowed_packs)
                    except Exception:
                        arm['stale'] = True
                        stopped = True
                    saved['arms'][key] = arm
                    saved.pop('running', None)
                    _save_journal(path, saved)
                    if arm.get('error'):
                        stopped = True
            record = _record(current, saved['arms'])
        value = lifecycle._write(root, pack, 'evaluations', record, allowed_packs=allowed_packs)
        saved['evaluation_id'] = value['id']
        _save_journal(path, saved)
        return dict(value, ok=True)
    finally:
        owner.__exit__(None, None, None)


def run(root, pack, actor_id, proposal, *, confirmed=False, local_demo=False, can_review=False, allowed_packs=None):
    return _guard(lambda: _run(root, pack, actor_id, proposal, confirmed, local_demo, can_review, allowed_packs))


def _read(root, pack, actor_id, evaluation_id, allowed_packs):
    root, pack = _scope(root, pack, actor_id, allowed_packs)
    value = runtime.read_record(root, pack, 'evaluations', evaluation_id, allowed_packs=allowed_packs)
    if value.get('record_type') != RECORD_TYPE or value.get('recorded_by') != actor_id:
        raise Invalid('Choose a paired comparison saved by this identity for this product.')
    runtime.validate_case_scope(value, pack, allowed_packs)
    if not isinstance(value.get('pairs'), list) or len(value['pairs']) != len(value['cases']):
        raise Invalid('The recorded paired comparison is malformed.')
    for pair, row in zip(value['pairs'], value['cases']):
        if pair.get('case') != row['case'] or pair.get('packs') != row['packs']:
            raise Invalid('The paired outputs no longer match their frozen cases.')
        for side in ('before', 'after'):
            _validate_arm(pair[side], {'pack': pack, 'allowed_packs': list(allowed_packs or [pack])}, row)
        if pair['comparison'] != _comparison(pair['before'], pair['after'], value['correction']):
            raise Invalid('The displayed comparison differs from its recorded observations.')
    connection.check_input(value)
    if value.get('semantic_improvement') is not None or value.get('training_eligible') is not False or value.get('adjudicated') is not False:
        raise Invalid('The retained comparison contains an unsupported scientific or learning claim.')
    try:
        current = _preview(root, pack, actor_id, value['correction']['id'], [r['case']['id'] for r in value['cases']], None,
                           allowed_packs, value['request_id'])
        stale = current['digest'] != value['preview_digest']
    except Exception:
        stale = True
    return dict(value, ok=True, stale=stale)


def read(root, pack, actor_id, evaluation_id, *, allowed_packs=None):
    return _guard(lambda: _read(root, pack, actor_id, evaluation_id, allowed_packs))


def recent(root, pack, actor_id, *, allowed_packs=None):
    try:
        root, pack = _scope(root, pack, actor_id, allowed_packs)
        records, _ = lifecycle._records(root, pack, 'evaluations', allowed_packs=allowed_packs)
        return [{'id': r['id'], 'route': 'model_lifecycle', 'title': 'Correction comparison',
                 'state': 'paired observations; human review needed', 'summary': 'Compare exact before/after outputs and lesson delivery.',
                 'params': {'evaluation_id': r['id'], 'correction_id': r['correction']['id'], 'objective_id': OBJECTIVE}, 'updated_at': r['created_at']}
                for r in records if r.get('record_type') == RECORD_TYPE and r.get('recorded_by') == actor_id
                and runtime.validate_case_scope(r, pack, allowed_packs) is None][:10]
    except Exception:
        return []


def _worker(request):
    proposal, row, enabled = request['proposal'], request['case'], request['include_target']
    root = Path(proposal['root']).resolve()
    if not root.samefile(CODE) or type(enabled) is not bool:
        raise Invalid('The isolated reader must run from this exact checkout.')
    ai.set_provider_selection(proposal['connection']['provider_id'])
    _fresh(root, proposal['pack'], proposal['actor_id'], proposal, proposal['allowed_packs'])
    import orchestrator
    import state
    for kind in specialists.KINDS.values():
        importlib.import_module(kind['module']).CANDIDATES = state.CANDIDATES
    model = connection.model(root, expected=proposal['connection'])
    model.execution_purpose = 'canonical_case_evaluation'
    collected = []
    started = time.monotonic()
    with workflow_skills.evaluation_corrections(root, record_id=proposal['correction']['id'],
            expected_digest=proposal['correction']['digest'], include_target=enabled,
            expected_library_digest=proposal['library_digest']) as delivery:
        def bounded(goal, *, cost_ceiling, max_seconds):
            try:
                value = orchestrator.run(goal, model=model, actor={'name': proposal['actor_id'], 'role': 'local reviewer'},
                    scope=set(row['packs']) | {proposal['pack']}, primary_pack=proposal['pack'],
                    max_steps=4, cost_ceiling=.5, max_seconds=ARM_SECONDS)
                snapshot = runtime.basis(vars(value)) | {'execution': value.execution}
                connection.check_input(snapshot)
                collected.append({'run': snapshot, 'sha256': runtime.digest(snapshot)})
                return value
            except Exception:
                raise RuntimeError('The isolated selected-provider case could not complete. No fallback or automatic retry was used.') from None
        with contextlib.redirect_stdout(io.StringIO()):
            result = lifecycle._case_runner().run_cases([row['case']], runner=bounded,
                per_case_ceiling=.5, max_seconds_per_case=ARM_SECONDS, budget_usd=None)[0]
        observations = list(delivery)
    if result.get('error'):
        result['error'] = 'The selected assistant did not return a complete case result.'
    if proposal['connection']['provider_id'] != 'anthropic':
        for field in ('cost_usd', 'total_cost_usd'):
            result['metrics'][field] = None
    value = {'result': result, 'runs': collected, 'outputs': _outputs(collected), 'delivery': observations,
        'elapsed_seconds': round(time.monotonic() - started, 3), 'excerpted_calls': model.excerpted_calls,
        'error': result.get('error'), 'stale': False}
    _validate_arm(value, proposal, row)
    return value


if __name__ == '__main__':
    if len(sys.argv) != 4 or sys.argv[1] != '--worker':
        raise SystemExit(2)
    try:
        request = json.loads(Path(sys.argv[2]).read_text(encoding='utf-8'))
        value = _worker(request)
        Path(sys.argv[3]).write_text(json.dumps(value, ensure_ascii=False, allow_nan=False), encoding='utf-8')
    except Exception:
        # The caller receives a fixed bounded failure; raw errors can carry source text.
        raise SystemExit(1) from None
