"""A focused next step and a resolution dialog over the authoritative gate results.

This view never treats a successful command as an approval or as a resolved gate.
Only a fresh evaluation changes the progress shown to the user.
"""
from __future__ import annotations

from datetime import datetime
import re

import streamlit as st

import flow_guidance as guidance
import theme
import review_checklist
import reviewer_link_page
import specification_details_page
import source_review_page
import signing_command_page
import history_page
import handoffs_page
import requirement_settle_page
import maturity_page
import workflow_record_page
import workflow_record_editor
import resolution_command_page
import resolution_commands
import specification_attachment_page
import workflow_forms
import workflow_forms_page
import scientific_definition_page
import scientific_definition_source_page


def _run_findings(output):
    """Select validator findings, not traceback frames or unrestricted run logs."""
    import form_assistance
    import ast
    findings, unclassified, colliding = [], False, False
    for raw in str(output or "").splitlines():
        line = raw.strip()
        if line.startswith("UNCLASSIFIED SHEET(S)"):
            unclassified = True
            continue
        if line.startswith("SHEET LABELS COLLIDE"):
            colliding = True
            continue
        if colliding:
            if (line.startswith(("'", '"')) and len(line) <= 600
                    and re.fullmatch(r".+ -> key .+ \(domain [^()\s]+\)", line)):
                findings.append("Sheet labels collide: " + line)
                continue
            colliding = False
        if unclassified:
            match = re.fullmatch(r"((?:'[^\n]*')|(?:\"[^\n]*\")):\s*(\d+) row\(s\) NOT scanned", line)
            if match and len(line) <= 600:
                try:
                    name = ast.literal_eval(match[1])
                except (ValueError, SyntaxError, RecursionError):
                    name = None
                if isinstance(name, str):
                    findings.append(f"Unclassified sheet {name!r}: {match[2]} row(s) were not read.")
                continue
            unclassified = False
        if not line or line.startswith(("File ", "Traceback", "raise ", "return ", "$ ", "> ", "exit ")):
            continue
        if "--allow-unclassified" in line:
            continue
        if (re.search(r"\b(?:sheets?|tabs?|domains?|headers?|columns?)\b", line, re.I)
                and re.search(r"missing|unmapped|unknown|not found|not in|does not|invalid|unclassified|absent|"
                              r"header names no|resolves no|CELL POSITION rather than a named column|"
                              r"produced ZERO rows|fold to ONE (?:sheet )?key", line, re.I)):
            findings.append(re.sub(r"^(?:ValueError|Error|ERROR|FAIL|REFUSED):\s*", "", line))
    return form_assistance.validation_messages(findings)[0]


def _source_revision(root, pack):
    """Fingerprint current specification inputs without placing their contents in chat."""
    import form_assistance as forms
    from pathlib import Path
    base = Path(root).resolve()
    product = base / pack
    if product.resolve() != product or not product.is_relative_to(base):
        return forms.digest("unavailable product")
    paths = [product / name for name in ("source_refs.yaml", "spec_pipeline/pipeline.conf", "spec_pipeline/out/extracted.json")]
    material, _materials, _reason = guidance._registered_spec(product)
    if material:
        source, _reason = guidance._local_source(base, product, material)
        if source and source.is_relative_to(base):
            paths.append(source)
    values = []
    for path in paths:
        try:
            if path.is_file() and path.resolve() == path and path.stat().st_size <= 32 * 1024 * 1024:
                values.append([path.relative_to(base).as_posix(), guidance.sm.sha256(str(path))])
            else:
                values.append([path.relative_to(base).as_posix(), "unavailable"])
        except (OSError, ValueError):
            values.append([path.name, "unavailable"])
    return forms.digest(values)


def assistant_feedback(root, pack, actor_id, *, card=None, _source_revision_value=None):
    """The same checked state and form failures displayed below the shared chat."""
    import form_assistance as forms
    from pathlib import Path
    route = str((card or {}).get("current_task", {}).get("route") or "")
    flow_scope = (bool(re.fullmatch(r"g[1-6]_[a-z_]+", route)) or route in {"progress", "scientific_draft"}
                  or not route and (card or {}).get("page") in {"Flow", "Progress and next step", "Evidence overview", "Run gates"})
    result = (st.session_state.get("flow_result") or {}).get(pack) if flow_scope else None
    dialog = st.session_state.get("flow_dialog") or {}
    current_dialog = flow_scope and dialog.get("pack") == pack and dialog.get("actor") == actor_id
    run = (st.session_state.get("flow_dialog_feedback") or {}) if current_dialog else {}
    form = (forms.validation_context() if st.session_state.get(forms.KEY + "pack") == pack
            and st.session_state.get(forms.KEY + "owner") == forms.digest([str(Path(root).resolve()), actor_id]) else None)
    if not isinstance(result, dict) and not run and not form:
        return None
    result = result if isinstance(result, dict) else {}
    action_id = str((card or {}).get("current_task", {}).get("route") or
                    (st.session_state.get("flow_resolution_action") if current_dialog else "") or "")
    blockers, title = [], "Current workflow check"
    primary_form = bool(form and form.get("primary") and form.get("status") in {"blocked", "needs_recheck"})
    if run and run.get("ok") is False and not primary_form:
        title = str(run.get("title") or "Most recent workflow step")
        action_id = str(run.get("id") or action_id)
        blockers.extend(run.get("blockers") or _run_findings(run.get("output")) or
                        ["The most recent workflow step failed. Inspect its run details before retrying."])
    if form and form.get("status") in {"blocked", "needs_recheck"}:
        if not blockers:
            title = form["title"]
            action_id = form.get("action_id") or action_id
        blockers.extend(form.get("blockers", []))
    if result.get("error"):
        blockers.append("The current product status could not be checked. Retry Check status; inspect the local details if it fails again.")
    rows = result.get("blockers") or []
    rows = sorted([row for row in rows if isinstance(row, dict)],
        key=lambda row: not any(item.get("id") == action_id for item in row.get("fixes", []) if isinstance(item, dict)))
    blockers.extend(guidance.blocker_copy(row.get("text")) for row in rows)
    messages, omitted = forms.validation_messages(blockers)
    if not messages and not result.get("clear") and not form:
        return None
    # prefill_revision has just read these exact inputs in the same call. Reuse
    # that value without caching it across renders or mutation boundaries.
    source_revision = _source_revision_value if _source_revision_value is not None else _source_revision(root, pack)
    source_changed = bool(not primary_form and run.get("source_digest") and run["source_digest"] != source_revision)
    failed = (run.get("ok") is False or bool(result.get("error")) or
              bool(form and form.get("status") in {"blocked", "needs_recheck"}))
    # Gate requirements describe work still to do, including ordinary unfinished
    # definitions. Only a failed action/check or displayed invalid form should
    # suspend the interview that helps someone complete that work.
    status = ("needs_recheck" if source_changed or form and form.get("status") == "needs_recheck" else
              "blocked" if failed else "pending" if messages or omitted else "clear")
    feedback = {"status": status,
                "action_id": action_id[:100], "title": title[:160], "blockers": messages,
                "blockers_omitted": omitted + int((form or {}).get("blockers_omitted") or 0)}
    feedback["input_digest"] = forms.digest({"root": str(Path(root).resolve()), "pack": pack, "actor": actor_id,
        "task": (card or {}).get("current_task"), "result": result, "run": run, "form": form, "source_revision": source_revision, "feedback": feedback})
    return feedback


def prefill_revision(identity):
    """Recheck the page-owned workflow before queued draft fields can be filled."""
    import connected_workflow
    import form_assistance as forms
    root, pack, actor_id = identity["root"], identity["pack"], identity["actor"]
    navigation = identity.get("route") or {}
    workspace = navigation.get("workspace") or {}
    task = ""
    if connected_workflow.valid(workspace, pack=pack, actor_id=actor_id,
                                section=identity["page"], allowed_packs=[pack] if pack else []):
        task = workspace["route"]
        if task == "progress":
            task = (workspace.get("params") or {}).get("action_id") or task
    elif identity["page"] == "Flow":
        dialog = st.session_state.get("flow_dialog") or {}
        if dialog.get("pack") == pack and dialog.get("actor") == actor_id:
            task = navigation.get("step") or ""
    card = {"page": identity["page"], "current_task": {"route": task}}
    source_revision = _source_revision(root, pack) if pack else None
    feedback = assistant_feedback(root, pack, actor_id, card=card, _source_revision_value=source_revision)
    return forms.digest({"workflow": (feedback or {}).get("input_digest"),
                         "source": source_revision})


STEPS = {
    1: "Input specification", 2: "Scientific definitions", 3: "Source suitability",
    4: "Build configuration", 5: "Validate results", 6: "Release for studies",
}


def assistant_path(stage):
    """Dispatch from the current workflow step, without a learned-model guess."""
    return {
        1: ("Prepare this step with guided help", "product_workspace", {}),
        2: ("Review the variable list", "variable_review", {}),
        3: ("Ask the assistant to assess source evidence", "specialist_assistant", {"kind": "source"}),
        4: ("Ask the assistant to inspect configuration failures", "specialist_assistant", {"kind": "validation"}),
        5: ("Ask the assistant to explain validation failures", "specialist_assistant", {"kind": "validation"}),
        6: ("Review exact build promotion readiness", "release_readiness", {}),
    }.get(stage, ("Open the product workspace", "product_workspace", {}))


def _actions(card):
    """The engine repeats a gate menu under each blocker; show each action once."""
    unique = {}
    for action in card.get("fixes") or []:
        if isinstance(action, dict) and action.get("id"):
            unique.setdefault(action["id"], action)
    actions = list(unique.values())
    # Older browser sessions can hold an action catalogue created before the
    # missing-metadata route existed. Keep that cached record actionable after
    # an app upgrade instead of sending it back to the same signing dead end.
    if "status:reviewed requires" in str(card.get("text", "")) and any(aid.startswith("g1_") for aid in unique):
        review = unique.get("g1_review")
        if review is None:
            source = next((a for a in actions if str(a.get("path", "")).endswith("source_refs.yaml")), {})
            review = {"id": "g1_review", "kind": "person", "argv": [],
                      "path": source.get("path", ""), "note": "Complete the missing details before authenticating the review."}
        return [review, *[a for a in actions if a["id"] != "g1_review"]]
    if any(reason in str(card.get("text", "")) for reason in ("moved past its ledger", "holds no lifecycle event")) and "g1_seal" in unique:
        return [unique["g1_seal"], *[a for a in actions if a["id"] != "g1_seal"]]
    # A generic registration check is diagnostic. The engine omits completed
    # preparation steps, so advance to the next remaining task in that sequence.
    # Preserve explicit routes such as authenticating a review or fixing a seal.
    if actions and actions[0]["id"] == "g1_check":
        next_id = next((aid for aid in ("g1_repair", "g1_init", "g1_workbook", "g1_digest", "g1_classify",
                                       "g1_review", "g1_commit") if aid in unique), None)
        if next_id:
            actions = [unique[next_id], *[a for a in actions if a["id"] != next_id]]
    return actions


def _cards(result):
    unique = {}
    for card in result.get("blockers") or []:
        if not isinstance(card, dict):
            continue
        actions = _actions(card)
        key = actions[0]["id"] if actions else str(card.get("text", "Review the current step"))
        unique.setdefault(key, card)
    if result.get("clear") and result.get("closing"):
        unique["closing"] = {"text": "Review the release handoff", "owner": "Accountable reviewer",
                             "fixes": result["closing"], "confirmation": True}
    return list(unique.items())


def _locate(cards, context):
    """(key, card) for the open dialog: the card it was opened with, else the card that now carries
    the act the person was working on. After a save the first act of a card moves (the review is
    recorded, so its commit stands first) and the person saw "This item has changed" instead of the
    form they had just used, with no way back to it (walk UC1-05, 2026-09-07)."""
    by_key = dict(cards)
    key = context.get("card_key")
    if key in by_key:
        return key, by_key[key]
    wanted = {str(st.session_state.get("flow_resolution_action") or ""), str(key or "")}
    for other_key, card in cards:
        if other_key != "closing" and any(a.get("id") in wanted for a in _actions(card)):
            return other_key, card
    return key, None


def _review_card(cards):
    """The card that offers the review act, if the current evidence offers one."""
    return next(((key, card) for key, card in cards if key != "closing"
                 and any(a.get("id") == "g1_review" for a in _actions(card))), None)


def _copy(card, action=None):
    actions = _actions(card)
    if card.get("confirmation") and action is None:
        return {"title": "Review the release handoff",
                "summary": "All six checks passed. Confirm the signed records and release receipt before using this release in a study.",
                "steps": []}
    copy = guidance.issue_copy(action or (actions[0] if actions else {}), str(card.get("text", "")))
    if card.get("confirmation"):
        copy["summary"] = "Use this guidance to verify the release handoff. If this step is already complete, no repeat action is needed."
    return copy


def _preferred_action(root, pack, card, completed_id=None):
    actions = _actions(card)
    if not actions:
        return None
    if actions[0]["id"] == "g2_scaffold":
        outline = guidance.specification_outline(root, pack)
        next_id = outline.get("continue_action") or ("g2_draft" if outline["current"] else None)
        if next_id:
            if next_id == "g2_lint" and completed_id == next_id:
                continuation = _after_scientific_check(root, pack, actions)
                if continuation:
                    return continuation
            return next((a for a in actions if a["id"] == next_id),
                        next((a for a in actions if a["id"] == "g2_draft"), actions[0]))
    if actions[0]["id"] == "g2_forms":
        continuation = _after_scientific_check(root, pack, actions)
        if continuation:
            return continuation
    if actions[0]["id"] == completed_id and len(actions) > 1:
        return actions[1]
    return actions[0]


def _after_scientific_check(root, pack, actions):
    """Use the existing question reader to avoid offering already-issued forms again."""
    import decision_answers
    questions = decision_answers.describe(root, pack, allowed_packs=[pack])
    if not questions["ok"]:
        return None
    if questions["unissued_ids"]:
        candidates = ("g2_forms",)
    elif any(item["status"] == "OPEN" for item in questions["items"]):
        candidates = ("g2_answer",)
    else:
        candidates = ("g2_settle", "g2_approve")
    return next((action for aid in candidates for action in actions if action["id"] == aid), None)


def _definition_routes(root, pack, actions, actor_id, *, can_view, editor_button=True):
    outline = guidance.specification_outline(root, pack)
    if outline.get("drafted_count"):
        st.caption(f"{outline['drafted_count']} saved definition record(s); "
                   f"{outline['remaining_count']} named specification row(s) remain to draft. Saving does not approve them.")
    if outline["rows"]:
        title = "Read the specification outline" if outline["current"] else "Earlier specification outline"
        with st.expander(title, expanded=editor_button and outline["current"]):
            st.caption(outline["reason"])
            st.dataframe(outline["rows"], hide_index=True, width="stretch", height=230)
    elif outline["current"]:
        st.info("The current outline has no remaining named definition rows. Review the coverage findings with your data expert.")
    st.caption("Review the whole variable list by responsibility: scientific definitions, source mapping, then output fields.")
    if editor_button and any(a["id"] == "g2_draft" for a in actions):
        if st.button("Review the variable list", key="flow_go_definition_editor", disabled=not can_view):
            import connected_workflow_page
            connected_workflow_page.open_route("variable_review", pack, actor_id, params={"phase": "science"})
    if st.button("Open Plan changes", key="flow_go_plan_changes", disabled=not can_view):
        st.session_state["section_suggested"] = "Plan changes"
        _dismiss()
        st.rerun()


def _configuration_route(root, pack, actor_id, *, can_view):
    # Offered by what the product's files carry, not by the product's name: only the settings
    # actually present are listed, so the caption never promises a setting the editor cannot show.
    import configuration_proposals
    try:
        supported = configuration_proposals.supported_parameters(root, pack)
    except (OSError, ValueError):
        return
    if not supported:
        return
    st.write("**Propose supported configuration changes**")
    st.write("Open Plan changes and choose **Change a supported product setting** to enter "
             "supported settings, review the before-and-after diff and affected studies, and run the validators.")
    st.caption("Supported settings: " + ", ".join(label for label, _kind, _value in supported.values()) +
               ". Other derivations need the engineering handoff. Submission requests review; it does not approve or release a product.")
    if st.button("Open Plan changes", key="flow_go_plan_changes", disabled=not can_view):
        _dismiss()
        import connected_workflow_page
        connected_workflow_page.open_route("plan_changes", pack, actor_id, params={"intent": "configuration"})


def _completed_step(root, pack, actor_id, result, feedback, *, can_view, evaluate):
    """Retain a command's outcome until the person chooses the next real action."""
    st.success(f"{feedback['title']}: command finished successfully.")
    st.caption("The command result does not approve a product or complete a workflow check. Current evidence determines progress.")
    cards = _cards(result)
    if result.get("error"):
        st.warning("The command finished, but status could not be refreshed. Check again before choosing the next step.")
    elif result.get("clear"):
        st.info("The current evidence checks pass. Continue to the release handoff to inspect the recorded reviews and receipt.")
    elif cards:
        key, card = cards[0]
        action = _preferred_action(root, pack, card, completed_id=feedback["id"])
        copy = _copy(card, action)
        if result.get("current") == feedback.get("gate_before"):
            st.info(f"Step {result.get('current')} remains open. The next requirement is {copy['title'].lower()}.")
        else:
            st.info(f"Status now points to step {result.get('current')}: {STEPS.get(result.get('current'), 'Product review')}.")
        st.write(copy["summary"])
        if feedback["id"] == "g2_scaffold":
            st.write("The outline is a reading aid. The scientific definition records still need your interpretations and review evidence.")
            _definition_routes(root, pack, _actions(card), actor_id, can_view=can_view, editor_button=False)
    else:
        st.info(_proceed(result))
    if cards and not result.get("error"):
        key, card = cards[0]
        action = _preferred_action(root, pack, card, completed_id=feedback["id"])
        title = _copy(card, action)["title"]
        if st.button(f"Continue: {title}", key="flow_continue", type="primary", disabled=not can_view):
            _open(pack, key, actor_id)
            if action:
                st.session_state["flow_resolution_action"] = action["id"]
            st.rerun()
    with st.expander("Run details"):
        st.code(feedback["output"], language=None)
    if st.button("Check again", key="flow_recheck", disabled=not can_view):
        _refresh(pack, evaluate)
        st.rerun()
    if st.button("Back to Flow", key="flow_close"):
        _dismiss()
        st.rerun()


def _owner(card):
    owner = str(card.get("owner") or "Product team")
    return " · ".join(part.split("(", 1)[0].strip().replace("DataExpert", "Data expert").replace("/", " or ")
                      for part in owner.split(" · "))


def _proceed(result):
    """The flow's proceed line in the page's words: the step by its name, the owner as a role
    (the tools' line names the gate and quotes the owner roles with their duties; walk NC-16)."""
    if result.get("clear"):
        return "All six checks pass; the release is receipted. Review the release handoff."
    current = result.get("current")
    if not isinstance(current, int):
        return "Review the current step with your product team."
    owner = next((g.get("owner") for g in result.get("gates") or [] if g.get("gate") == current), "") or "Product team"
    count = len(result.get("blockers") or [])
    return (f"Step {current} ({STEPS.get(current, 'Product review')}) has {count} item(s) to resolve. "
            f"Responsible team: {_owner({'owner': owner})}.")


def _command(root, action):
    """The act's command in the one style every page shows (resolution_commands.render, 2026-09-07):
    this page printed `python platform/tools/...` while the command form built the checkout's
    Python wrapper, and a person copying either saw two commands for one act."""
    try:
        return resolution_commands.render(root, action.get("argv") or [])
    except (OSError, ValueError, TypeError):
        return ""


def _refresh(pack, evaluate):
    try:
        result = evaluate()
    except Exception as exc:  # the refusal is visible without losing navigation
        result = {"error": f"{type(exc).__name__}: {exc}"}
    result = dict(result)
    result["checked_at"] = datetime.now().astimezone().strftime("%d %b, %H:%M:%S %Z")
    st.session_state.flow_result[pack] = result
    return result


def _clear_forms():
    specification_details_page.clear()
    source_review_page.clear()
    workflow_record_page.clear()
    specification_attachment_page.clear()
    workflow_forms_page.clear()
    scientific_definition_page.clear()
    scientific_definition_source_page._clear()


def _dismiss():
    st.session_state.pop("flow_dialog", None)
    st.session_state.pop("flow_dialog_feedback", None)
    _clear_forms()


def _open(pack, key, actor_id, params=None):
    _clear_forms()
    st.session_state["flow_dialog"] = {"pack": pack, "card_key": key, "actor": actor_id,
        "params": {k: v for k, v in (params or {}).items() if k in {"receipt", "build_id"} and isinstance(v, str)}}
    st.session_state.pop("flow_resolution_action", None)
    st.session_state.pop("flow_dialog_feedback", None)


def _extraction_classify(action):
    """Whether this classify act names the extracted specification (flow.acts sets material_type),
    so the page opens the extraction's review form and not the workbook's access form."""
    return action.get("id") == "g1_classify" and action.get("material_type") == guidance.sm.AI_EXTRACTION


def _handoff(root, pack, card, action, copy):
    lines = [f"Product: {pack}", copy["title"], "", copy["summary"], "",
             f"Responsible team: {card.get('owner', 'Product team')}", ""]
    lines.extend(f"{i}. {step}" for i, step in enumerate(copy["steps"], 1))
    if action.get("path"):
        lines += ["", "File:", str(action["path"])]
    if _command(root, action):
        lines += ["", "Command:", _command(root, action)]
    if action.get("note"):
        lines += ["", str(action["note"])]
    lines += ["", "Reported blocker:", str(card.get("reported_text", card.get("text", ""))), "",
              "Return to Flow and choose Check status after updating the evidence."]
    return "\n".join(lines)


def _failed_run(root, pack, actor_id, action, feedback, *, local_demo, can_write, can_view):
    """Show the actual stopped step before its editors and retain its diagnostic report."""
    findings = feedback.get("blockers") or _run_findings(feedback.get("output"))
    with st.container(border=True):
        st.error("Stopped at: " + str(feedback.get("title") or guidance.act_title(action)))
        if findings:
            for finding in findings:
                st.write("• " + str(finding))
        else:
            st.write("The run did not identify a supported form correction. Open the run details below and use the technical handoff for your data expert.")
        st.caption("Your draft entries are retained. Correct the input, then run this step again; no retry or approval happens automatically.")
        extraction = action.get("id") in {"g1_extract", "g2_extract", "g2_refresh_extraction", "g2_scaffold"}
        problem = " ".join(str(finding) for finding in findings).lower()
        if extraction and re.search(r"unclassified|unmapped|sheet.*domain", problem):
            st.info("Use Map workbook sheets to specification sections below to assign the named sheets. Review and save the mapping, then run extraction again.")
        if extraction and re.search(r"header|cell position|zero rows|named column|resolves no .+ column", problem):
            st.info("This finding concerns the workbook's content. Correct the named header or column in the source workbook; a section mapping cannot rename its columns.")
            with st.expander("Choose a corrected specification workbook"):
                if specification_attachment_page.render(root, pack, actor_id, local_demo=local_demo,
                        can_write=can_write, can_view=can_view):
                    return True
        with st.expander("Run details"):
            output = str(feedback.get("output") or "(no output)")
            st.code(output, language=None)
            st.download_button("Download failed step report", output, file_name="workflow-step-failure.txt",
                               mime="text/plain", key="flow_failed_report")
    return False


@st.dialog("Resolve next step", width="large", on_dismiss=_dismiss)
def _resolve(*, root, pack, label, actor_id, local_demo, can_write, can_view, evaluate, run_action, show_reference=None, can_manage_users=False, can_review=False, naming_packs=None, actor_name=""):
    context = st.session_state.get("flow_dialog") or {}
    if context.get("pack") != pack or context.get("actor") != actor_id:
        _dismiss()
        st.rerun()
    linked = context.get("params") or {}
    if linked.get("receipt"):
        import release_workspace
        import connected_workflow_page
        build = release_workspace.describe(root, pack, actor_id, receipt=linked["receipt"],
            allowed_packs=naming_packs if naming_packs is not None else [pack])
        selected_build = build.get("selected") or {}
        matches = (build.get("ok") and selected_build.get("build_id")
                   and linked.get("build_id") in (None, selected_build["build_id"]))
        if matches:
            linked = {**linked, "build_id": selected_build["build_id"]}
            st.info(f"Continuing the review for build {linked['build_id']}. Review records must identify this same build.")
        else:
            st.warning("The linked build is no longer available with the same receipt. Review the recorded build before preparing further evidence.")
        if st.button("Return to the selected build", key="flow_linked_build"):
            connected_workflow_page.open_route("release_readiness", pack, actor_id, params=linked)
        if not matches:
            return
    result = st.session_state.flow_result.get(pack) or {}
    feedback = st.session_state.get("flow_dialog_feedback")
    if feedback and feedback.get("ok"):
        _completed_step(root, pack, actor_id, result, feedback, can_view=can_view, evaluate=evaluate)
        return
    cards = _cards(result)
    if context.get("card_key") == "specification_details":
        card = {"text": "Review the current specification details before changing them.", "owner": "Science · Data expert",
                "fixes": [{"id": "g1_review", "kind": "person", "argv": [], "path": f"{pack}/source_refs.yaml"}]}
    elif str(context.get("card_key") or "").startswith("requested:"):
        import flow_continuation
        requested = flow_continuation.resolve(root, pack, actor_id, context["card_key"][len("requested:"):],
            allowed_packs=naming_packs if naming_packs is not None else [pack], can_view=can_view)
        card = requested.get("card") if requested["ok"] else None
        if not requested["ok"]:
            for error in requested["errors"]:
                st.warning(error)
    else:
        key, card = _locate(cards, context)
        if card is not None and key != context.get("card_key"):
            st.session_state["flow_dialog"] = dict(context, card_key=key)
    if card is None:
        st.info("This item has changed. Check the current status to find the next step.")
        if st.button("Check again", key="flow_recheck", disabled=not can_view):
            _refresh(pack, evaluate)
            _dismiss()
            st.rerun()
        return
    actions = _actions(card)
    if not actions:
        st.write(guidance.blocker_copy(card.get("text", "Review the current step with your product team.")))
        st.caption(f"Responsible team: {_owner(card)}")
    else:
        ids = [action["id"] for action in actions]
        chosen = st.session_state.get("flow_resolution_action")
        # An action can rerun before the optional selector below is rendered.
        # Preserve its value through Streamlit's widget cleanup so a failed run
        # stays on that action with its error and retry instructions visible.
        st.session_state["flow_resolution_action"] = chosen if chosen in ids else ids[0]
        st.caption(label)
        selected = st.session_state.get("flow_resolution_action", ids[0])
        action = next(a for a in actions if a["id"] == selected)
        if linked.get("receipt") and action["id"] in {"g6_seal", "g6_countersign", "g6_commit", "g6_promote"}:
            approval = build.get("approval") or {}
            if (approval.get("approved_build_id") != selected_build["build_id"]
                    or selected_build.get("candidate_binding_checked")
                    and approval.get("approved_manifest_sha256") != selected_build["manifest_sha256"]):
                st.warning("The saved release approval names a different candidate. Review this selected build's approval before continuing this step.")
                if st.button("Open approval for the selected build", key="flow_linked_approval"):
                    connected_workflow_page.open_route("progress", pack, actor_id,
                        params={"action_id": "g6_approve", **linked})
                return
        if action.get("id") == "g2_draft":
            import connected_workflow_page
            connected_workflow_page.open_route("variable_review", pack, actor_id, params={"phase": "science"})
            return
        if action.get("id") == "g2_settle":
            import requirement_settle
            prepared = requirement_settle.describe(root, pack, allowed_packs=[pack])
            if prepared.get("ok") and not (prepared.get("counts") or {}).get("total"):
                import connected_workflow_page
                connected_workflow_page.open_route("variable_review", pack, actor_id, params={"phase": "science"})
                return
        copy = _copy(card, action)
        is_reviewer = action.get("id") == "g1_commit"
        if is_reviewer:
            reviewer_link_page.render(root, pack, actor_id, local_demo=local_demo, can_view=can_view,
                                      can_manage_users=can_manage_users, show_reference=show_reference, can_review=can_review,
                                      actor_name=actor_name)
            # THE RECORDED REVIEW CAN STILL BE CORRECTED (walk UC1-05, 2026-09-07): once the review was
            # saved the page offered only its signature, and a wrong reviewer name had no way back.
            # The review act stays in the menu until the record is signed; the reviewer page hides
            # the step selector, so the route to it is named here.
            correction = next((a for a in actions if a.get("id") == "g1_review"), None)
            if correction is not None and can_view:
                st.caption("You can correct the recorded review and confirm it again." if result.get("development") else
                           "The recorded review can still be corrected until it is signed.")
                if st.button(guidance.act_title(correction), key="flow_correct_review"):
                    st.session_state["flow_resolution_action"] = "g1_review"
                    st.session_state.pop("flow_dialog_feedback", None)
                    st.rerun()
            # THE EXTRACTION STILL TO REGISTER IS NAMED HERE TOO (walk UC4-64, 2026-09-07): the reviewer
            # step hides the step selector, and the registration act was unreachable until the signature
            pending_extraction = next((a for a in actions if a.get("id") in ("g1_register_extraction", "g1_extract")), None)
            if pending_extraction is not None and can_view:
                st.caption("The sanitized extraction can be registered before or after confirming the review." if result.get("development") else
                           "The sanitized extraction is not registered yet; it can be done before or after the signature.")
                if st.button(guidance.act_title(pending_extraction), key="flow_register_extraction"):
                    st.session_state["flow_resolution_action"] = pending_extraction["id"]
                    st.session_state.pop("flow_dialog_feedback", None)
                    st.rerun()
        else:
            st.subheader(copy["title"])
            st.write(copy["summary"])
            st.caption(f"Responsible team: {_owner(card)}")
        feedback = st.session_state.get("flow_dialog_feedback")
        if feedback and feedback.get("ok") is False and feedback.get("id") == action["id"]:
            if _failed_run(root, pack, actor_id, action, feedback, local_demo=local_demo,
                           can_write=can_write, can_view=can_view):
                st.session_state.pop("flow_dialog_feedback", None)
                _refresh(pack, evaluate)
                st.rerun()
        if _extraction_classify(action) and context.get("card_key") != "specification_details":
            # THE FORM THAT EDITS THE MATERIAL THE CHECK NAMED (2026-09-07): the extraction's TODOs
            # opened the workbook's access form, which reported success and changed nothing the
            # check reads, so the same step came back on every check.
            if scientific_definition_source_page.render(root, pack, local_demo=local_demo, can_write=can_write,
                                                        can_review=can_review, allowed_packs=[pack], actor_id=actor_id):
                _refresh(pack, evaluate)
        elif action.get("id") in ("g1_review", "g1_classify") and context.get("card_key") != "specification_details":
            if source_review_page.render(root, pack, actor_id, local_demo=local_demo, can_review=can_review,
                                         can_view=can_view, initial_mode="access" if action["id"] == "g1_classify" else "review"):
                _refresh(pack, evaluate)
        elif action.get("id") == "g1_review":
            if specification_details_page.render(root, pack, actor_id, local_demo=local_demo,
                                                  can_write=can_write, can_view=can_view):
                _refresh(pack, evaluate)
            review = review_checklist.specification(root, pack)
            if review.get("error"):
                st.info(review["error"])
            else:
                if review.get("status") == "approved":
                    st.warning("The file says status: approved. This source record uses reviewed for a completed review; approved is not a supported value.")
                if review["missing"]:
                    st.write(f"**{len(review['missing'])} review details are still missing:**")
                    with st.expander("Remaining review details"):
                        st.dataframe(review["missing"], hide_index=True, width="stretch")
                    st.caption("Keep status pending with a reason in why_provisional while review is unfinished. The reviewer records reviewed after completing the required details.")
                else:
                    st.info("The review fields are present. Check status to see whether authentication and the recorded history also pass.")
            # the reviewer's name and the review date are corrected in the review form, which the
            # current evidence offers while the record is unsigned (walk UC1-05, 2026-09-07)
            review_card = _review_card(cards)
            if review_card is not None and can_view:
                st.caption("To correct the reviewer's name or the review date, open the review form.")
                if st.button("Correct the recorded review", key="flow_correct_review"):
                    _open(pack, review_card[0], actor_id)
                    st.session_state["flow_resolution_action"] = "g1_review"
                    st.rerun()
        if not is_reviewer:
            st.markdown("\n".join(f"{i}. {step}" for i, step in enumerate(copy["steps"], 1)))
        if action.get("id") in ("g1_extract", "g2_extract", "g2_refresh_extraction", "g2_scaffold"):
            import specification_sheet_mapping_page
            if specification_sheet_mapping_page.render(root, pack, actor_id, local_demo=local_demo,
                    can_write=can_write, can_view=can_view, allowed_packs=naming_packs if naming_packs is not None else [pack],
                    action_id=action["id"]):
                st.session_state.pop("flow_dialog_feedback", None)
                _refresh(pack, evaluate)
                st.rerun()
            import related_extraction_page
            related_route = related_extraction_page.render(root, pack, actor_id, can_view=can_view,
                allowed_packs=naming_packs if naming_packs is not None else [pack])
            if related_route:
                import connected_workflow_page
                connected_workflow_page.open_route(related_route["route"], pack, actor_id,
                    params=related_route.get("params"))
        if action.get("id") in ("g2_scaffold", "g2_draft"):
            _definition_routes(root, pack, actions, actor_id, can_view=can_view,
                               editor_button=action["id"] != "g2_draft")
        if action.get("id") in ("g4_author", "g4_validate", "g4_validate_strict", "g4_binding"):
            _configuration_route(root, pack, actor_id, can_view=can_view)
        if can_view:
            import connected_workflow_page
            connected_workflow_page.step_links(action.get("id"), pack, actor_id)

        # A write whose values a form collects (workflow_forms.WRITE_FORMS: the first registration)
        # is offered as that form, not as a button the placeholders in its command keep disabled.
        if action.get("kind") in ("read", "write") and action.get("id") not in workflow_forms.WRITE_FORMS:
            availability = guidance.action_state(root, pack, action, local_demo=local_demo, can_write=can_write)
            reason = availability["reason"]
            if availability["state"] == "complete":
                st.success("Already complete")
                st.write(reason)
                st.caption("Choose Check again below to see the next requirement. You do not need to repeat this step.")
            elif reason:
                st.info(reason)
                if availability["state"] == "blocked":
                    import form_assistance
                    form_assistance.record_validation([reason], title=copy["title"], action_id=action["id"])
            button_label = "Run check" if action["kind"] == "read" else "Run this step"
            if st.button(button_label, key="flow_run_action", type="primary", disabled=availability["state"] != "ready" or not can_view):
                # File prerequisites are checked again at the mutation boundary, including when
                # another tab or a person changed them while this dialog was open.
                reason = guidance.action_guard(root, pack, action, local_demo=local_demo, can_write=can_write)
                if reason or not can_view:
                    st.warning(reason or "You do not have permission to run this step.")
                    import form_assistance
                    form_assistance.record_validation([reason or "You do not have permission to run this step."],
                        title=copy["title"], action_id=action["id"])
                else:
                    with st.spinner("Running this step…"):
                        try:
                            output = str(run_action(action["argv"]))
                        except Exception as exc:
                            output = f"{type(exc).__name__}: {exc}"
                    st.session_state.flow_output[(pack, action["id"])] = output
                    exits = re.findall(r"^exit\s+(-?\d+)\s*$", output, flags=re.MULTILINE)
                    ok = bool(exits and exits[-1] == "0")
                    with st.spinner("Checking what remains…"):
                        _refresh(pack, evaluate)
                    feedback = {"ok": ok, "title": copy["title"], "output": output,
                                "id": action["id"], "gate_before": result.get("current"), "blockers": _run_findings(output) if not ok else [],
                                "source_digest": _source_revision(root, pack)}
                    st.session_state["flow_dialog_feedback"] = feedback
                    st.rerun()
        else:
            if action.get("id") == "g1_workbook":
                if specification_attachment_page.render(root, pack, actor_id, local_demo=local_demo,
                                                         can_write=can_write, can_view=can_view):
                    _refresh(pack, evaluate)
            elif action.get("id") in ("g1_review", "g1_classify"):
                st.caption("Save the details here. Check again to see whether the review also needs authentication or a history update.")
            elif action.get("id") in ("g2_answer", "g2_apply"):
                st.caption("You can enter and save the answer inside Questions to answer.")
            elif action.get("id") == "g2_draft":
                if scientific_definition_page.render(root, pack, actor_id, local_demo=local_demo,
                                                     can_write=can_write, can_view=can_view, can_review=can_review,
                                                     naming_packs=naming_packs):
                    _refresh(pack, evaluate)
            elif action.get("id") in ("g2_commit", "g3_commit", "g4_commit", "g6_commit"):
                signing_command_page.render(root, pack, "release" if action["id"] == "g6_commit" else "science", actor_id,
                                            local_demo=local_demo, can_review=can_review, can_view=can_view, actor_name=actor_name)
            elif action.get("id") == "g6_countersign":
                import approval_attestation_page
                if approval_attestation_page.render(root, pack, actor_id, local_demo=local_demo,
                        can_review=can_review, can_view=can_view,
                        allowed_packs=naming_packs if naming_packs is not None else [pack]):
                    _refresh(pack, evaluate)
            elif action.get("id") == "g2_settle":
                # the scientific owner's word on each record, as a form (2026-09-07); the person no
                # longer edits the contract table by hand
                if requirement_settle_page.render(root, pack, actor_id, local_demo=local_demo,
                                                  can_settle=bool(can_write or can_review), can_view=can_view, allowed_packs=[pack]):
                    _refresh(pack, evaluate)
            elif action.get("id") in ("g2_maturity", "g4_maturity") and maturity_page.has_record(root, pack, allowed_packs=[pack]):
                # the maturity claim as a form (walk UC1-MATURITY): one line of the record, chosen from
                # the levels the gate knows, never an edit of the YAML text; a product with no record
                # yet falls through to the register form that creates it
                if maturity_page.render(root, pack, actor_id, "contract" if action["id"] == "g2_maturity" else "configuration",
                                        local_demo=local_demo, can_write=can_write, can_view=can_view, allowed_packs=[pack]):
                    _refresh(pack, evaluate)
            elif action.get("kind") == "person" and str(action.get("id", "")).endswith("_commit"):
                # the Gate 1 registration record: a plain history entry as the person (local demo);
                # the review signature that follows it is the signing form's act
                if history_page.render(root, pack, action, actor_id, local_demo=local_demo, can_write=can_write, can_view=can_view):
                    _refresh(pack, evaluate)
            elif not is_reviewer:
                candidate_binding = {"receipt": linked["receipt"], "build_id": linked.get("build_id")} \
                    if linked.get("receipt") and action.get("id") in {"g5_validate", "g6_approve"} else {}
                record = workflow_record_editor.describe(root, pack, action, allowed_packs=[pack]) if can_view else {}
                preparation = {}
                if record.get("ok"):
                    if workflow_record_page.render(root, pack, action, actor_id, local_demo=local_demo,
                                                   can_review=can_review, can_view=can_view, **candidate_binding):
                        _refresh(pack, evaluate)
                else:
                    preparation = workflow_forms.describe(root, pack, action, allowed_packs=[pack]) if can_view else {}
                    if preparation.get("supported"):
                        if workflow_forms_page.render(root, pack, action, actor_id, local_demo=local_demo,
                                                      can_review=can_review, can_view=can_view, **candidate_binding):
                            _refresh(pack, evaluate)
                # The command form would ask for the same three values the registration form
                # collects; the technical handoff below still carries the command.
                command_available = (action.get("id") in workflow_forms.WRITE_FORMS and preparation.get("supported")) or \
                    resolution_command_page.render(root, pack, action, actor_id, can_view=can_view)
                if not record.get("ok") and not preparation.get("supported") and not command_available:
                    st.write("**Where to complete this step**")
                    if action.get("path"):
                        # the file by its plain name; its path is under the technical handoff (walk NC-16)
                        st.write(f"The responsible reviewer or data expert updates {guidance.file_label(action['path'])}.")
                        if show_reference:
                            show_reference(str(action["path"]), key="flow_external_record", label="Open current record", inline=True)
                    else:
                        st.write("Use Download instructions below to give the responsible reviewer or data expert the exact requirement and next action.")
                    st.caption("This action has no supported editor in the portal. After the record is updated, choose Check again to validate it.")
            extraction = next((a for a in actions if a.get("id") == "g1_extract"), None)
            if action.get("id") == "g1_review" and extraction:
                readiness = guidance.action_state(root, pack, extraction, local_demo=local_demo, can_write=can_write)
                if readiness["state"] == "ready" and st.button("Prepare draft extraction", key="flow_prepare_draft"):
                    st.session_state["flow_resolution_action"] = extraction["id"]
                    st.rerun()

        if not is_reviewer:
            with st.expander("Detailed instructions / technical handoff"):
                if action.get("path"):
                    st.caption("File to update")
                    st.code(str(action["path"]), language=None)
                    if show_reference:
                        show_reference(str(action["path"]), key="flow_source_file", label="View current file", inline=True)
                if _command(root, action) and action.get("kind") in ("read", "write"):
                    st.caption("Command for your data expert")
                    st.code(_command(root, action), language=None)
                if action.get("note"):
                    st.write(str(action["note"]))
                st.caption("Reported by the status check")
                st.text(str(card.get("reported_text", card.get("text", ""))))
                # EVERY RAW LINE LIVES HERE (walk NC-16, 2026-09-07): the step details on the page read
                # each finding in plain words, and the checks' own wording is kept, word for word,
                # under this expander for the data expert
                reported = [str(line) for gate in result.get("gates") or [] for line in gate.get("blockers") or []]
                if reported:
                    st.caption("Every line the checks reported, word for word")
                    st.code("\n".join(reported), language=None)
                st.download_button("Download instructions", _handoff(root, pack, card, action, copy),
                                   file_name="resolution-instructions.txt", mime="text/plain", key="flow_download_handoff")
                # AN OWNED HANDOFF, NOT A LINE OF ADVICE (2026-09-07): the step is handed to the role that owns
                # it as a tracked request with a status and an answer; it shows on Home until answered
                handoffs_page.ask(root, pack, action, card, actor_id, local_demo=local_demo, can_view=can_view,
                                  allowed_packs=[pack], key="flow")
        if len(ids) > 1 and not is_reviewer:
            with st.expander("Other resolution steps"):
                st.selectbox("Step to work on", ids, key="flow_resolution_action",
                             format_func=lambda aid: _copy(card, next(a for a in actions if a["id"] == aid))["title"])
        if action.get("id") in ("g2_answer", "g2_apply") or card.get("held_by") == 2 or "decision" in str(card.get("text", "")).lower():
            if st.button("Open questions to answer", key="flow_go_questions"):
                st.session_state["section_suggested"] = "Open questions"
                _dismiss()
                st.rerun()

    st.divider()
    st.caption("After updating the evidence, check again. Progress changes when the requirements pass.")
    c1, c2 = st.columns([1, 1])
    if c1.button("Check again", key="flow_recheck", disabled=not can_view):
        with st.spinner("Checking current evidence…"):
            _refresh(pack, evaluate)
        _dismiss()
        st.rerun()
    if c2.button("Close", key="flow_close"):
        _dismiss()
        st.rerun()


def render(*, root, pack, label, actor_id, local_demo, can_write, can_view, evaluate, run_action, show_reference=None, can_manage_users=False, can_review=False, naming_packs=None, show_title=True, actor_name=""):
    st.session_state.setdefault("flow_result", {})
    st.session_state.setdefault("flow_output", {})
    heading, check = st.columns([4, 1.2], vertical_alignment="center")
    if show_title:
        heading.title(label)
    else:
        # The product header above the page already names the product and shows its six stages
        # (2026-09-07); this page owns the next step and the resolution dialog.
        heading.markdown(theme.section_title("Progress and next step", "Resolve one step at a time. Check status refreshes the evidence."),
                         unsafe_allow_html=True)
    check_clicked = check.button("Check status", key="flow_check", type="primary", disabled=not can_view)
    if can_view:
        import connected_workflow_page
        connected_workflow_page.specialist_evidence(root, pack, actor_id,
                                                   allowed_packs=naming_packs if naming_packs is not None else [pack])
    # the outcome of an act done inside a dialog (a signature, a settled requirement, a maturity
    # claim) stays on the page until the person checks status again (walk RW1-04): a rerun is not
    # a person reading, so the notice is not consumed by the first redraw
    flow_notice = st.session_state.get("flow_notice")
    if isinstance(flow_notice, str) and flow_notice:
        if check_clicked:
            st.session_state.pop("flow_notice", None)
        else:
            st.success(flow_notice)
    if show_title:
        st.caption("Check progress, then resolve one step at a time.")
    result = st.session_state.flow_result.get(pack)
    requested = st.session_state.pop("flow_requested_action", None)
    if requested and (requested.get("pack") != pack or requested.get("actor") != actor_id):
        requested = None
    if check_clicked or (requested and can_view):
        with st.spinner("Checking current evidence…"):
            result = _refresh(pack, evaluate)
        _dismiss()
    if not result:
        st.info("Check status to see what this product needs next.")
        return
    if result.get("development"):
        st.caption("Development progress · Reviews use the saved name and email confirmations.")
    if result.get("checked_at"):
        st.caption(f"Last checked {result['checked_at']}")
    if result.get("error"):
        st.error("Status could not be checked. Try again; if it continues, share the details with your data expert.")
        with st.expander("Status check details"):
            st.code(result["error"], language=None)
        if st.session_state.get("flow_dialog"):
            _resolve(root=root, pack=pack, label=label, actor_id=actor_id, local_demo=local_demo,
                     can_write=can_write, can_view=can_view, evaluate=evaluate, run_action=run_action,
                     show_reference=show_reference, can_manage_users=can_manage_users, can_review=can_review, naming_packs=naming_packs,
                     actor_name=actor_name)
        return

    gates = result.get("gates") or []
    current = result.get("current")
    done = sum(g.get("state") == "done" for g in gates)
    if show_title:
        st.progress(min(done / 6, 1.0), text=f"{done} of 6 checks passed")
    feedback = st.session_state.get("flow_feedback", {}).pop(pack, None)
    if feedback:
        st.info("Step finished and status refreshed. The next step below reflects the evidence still needed.")
    cards = _cards(result)
    if requested and requested.get("action_id") and can_view:
        target = next(((key, card) for key, card in cards
                       if any(a.get("id") == requested["action_id"] for a in _actions(card))), None)
        if target:
            _open(pack, target[0], actor_id, requested.get("params"))
            st.session_state["flow_resolution_action"] = requested["action_id"]
        else:
            import flow_continuation
            continuation = flow_continuation.resolve(root, pack, actor_id, requested["action_id"],
                allowed_packs=naming_packs if naming_packs is not None else [pack], can_view=can_view)
            if continuation["ok"]:
                _open(pack, continuation["key"], actor_id, requested.get("params"))
                st.session_state["flow_resolution_action"] = requested["action_id"]
            else:
                for error in continuation["errors"]:
                    st.info(error)
    if result.get("clear"):
        st.success(_proceed(result))
    if cards:
        first_key, first_card = cards[0]
        preferred = _preferred_action(root, pack, first_card)
        copy = _copy(first_card, None if first_card.get("confirmation") else preferred)
        with st.container(border=True):
            st.caption(f"STEP {current} OF 6 · {STEPS.get(current, 'Product review').upper()}" if current else "RELEASE HANDOFF")
            st.subheader(copy["title"])
            st.write(copy["summary"])
            st.caption(f"Responsible team: {_owner(first_card)}")
            if st.button("Review handoff" if first_card.get("confirmation") else "Resolve next step",
                         key="flow_resolve", disabled=not can_view):
                _open(pack, first_key, actor_id)
                if preferred:
                    st.session_state["flow_resolution_action"] = preferred["id"]
            if can_view:
                assist_label, assist_route, assist_params = assistant_path(current)
                if st.button(assist_label, key="flow_assistant_step",
                             help="Continue with the assistant and the evidence for this step. A model runs only when you request it."):
                    import connected_workflow_page
                    if assist_params.get("kind") == "validation":
                        assist_params = {**assist_params, "failure": str(first_card.get("text") or "")[:4000]}
                    connected_workflow_page.open_route(assist_route, pack, actor_id, origin="Flow", params=assist_params)
        # THE WORKSPACES FOR THIS STEP, ON THE PAGE (2026-09-07): they were reachable only from inside
        # the Resolve dialog, so the definition editor, source worklist and study tools read as
        # unrelated pages. The same routes, under the step they belong to.
        if preferred and can_view:
            import connected_workflow_page
            connected_workflow_page.step_links(preferred.get("id", ""), pack, actor_id, key="page_step", label="Work on this step")
            # WORK AHEAD (2026-09-07): while Gate 1 waits on a reviewer's signature the definitions
            # editor was unreachable, because the page offered only the current gate's acts. The next
            # stage's workspaces are offered too; nothing there advances a gate out of order.
            if isinstance(current, int) and current < 6:
                connected_workflow_page.step_links(f"g{current + 1}_ahead", pack, actor_id, key="page_ahead",
                                                   label=f"Work ahead on stage {current + 1} ({STEPS.get(current + 1, '')})")
            if isinstance(current, int) and current < 2:
                # the source pages are reachable from any stage (walk UC4-13, 2026-09-07): a person told
                # "the vendor changes" on a Gate 1 product has somewhere to look
                connected_workflow_page.step_links("g3_sources", pack, actor_id, key="page_sources",
                                                   label=f"Sources (stage 3, {STEPS.get(3, '')})")
        if len(cards) > 1:
            with st.expander(f"Other items in this step ({len(cards) - 1})"):
                for i, (key, card) in enumerate(cards[1:], 1):
                    cols = st.columns([4, 1])
                    cols[0].write(_copy(card)["title"])
                    if cols[1].button("Resolve", key=f"flow_resolve_{i}", disabled=not can_view):
                        _open(pack, key, actor_id)
    elif not result.get("clear"):
        st.info(_proceed(result))

    with st.expander("Product details"):
        st.caption("You can return to the document details when its identifier, revision, delivery or QC reference needs correction.")
        if st.button("Edit specification details", key="flow_edit_specification", disabled=not can_view):
            _open(pack, "specification_details", actor_id)

    with st.expander("All six steps and check details"):
        # PLAIN WORDS HERE (walk NC-16, 2026-09-07): the checks name files, flags and fields; a
        # person reads each finding as a sentence, and the exact wording stays under the technical
        # handoff in Resolve next step
        st.caption("What each check found, in plain words. The checks' exact wording is under Detailed instructions in Resolve next step.")
        for gate in gates:
            number = gate.get("gate")
            lines = [f"**{number}. {STEPS.get(number, gate.get('title', 'Review'))}**: {gate.get('state', 'not checked')}"]
            lines += [f"- {sentence}" for sentence in guidance.blocker_lines(
                gate.get("blockers") or [], development=bool(result.get("development")))]
            st.markdown("\n".join(lines))
    outputs = [(aid, out) for (pk, aid), out in st.session_state.flow_output.items() if pk == pack]
    if outputs:
        with st.expander("Activity and run details"):
            st.caption("Run output is diagnostic. A successful command does not approve a product or complete a gate.")
            for aid, output in reversed(outputs):
                st.write(guidance.act_title(aid))                      # the act by its label, never its id (walk UC1-27)
                st.code(output, language=None)
    if st.session_state.get("flow_dialog"):
        _resolve(root=root, pack=pack, label=label, actor_id=actor_id, local_demo=local_demo,
                 can_write=can_write, can_view=can_view, evaluate=evaluate, run_action=run_action,
                 show_reference=show_reference, can_manage_users=can_manage_users, can_review=can_review, naming_packs=naming_packs,
                     actor_name=actor_name)
