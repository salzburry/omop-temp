"""Review exact workbook-sheet assignments inside the current scientific workflow."""
from __future__ import annotations

from pathlib import Path

import streamlit as st

import form_assistance as forms
import specification_sheet_mapping as mapping


PREFIX = "spec_sheet_mapping_"


def sheet_key(name):
    return PREFIX + "sheet_" + forms.digest(name)[:20]


def clear():
    for key in list(st.session_state):
        if str(key).startswith(PREFIX):
            st.session_state.pop(key, None)


def _errors(result, action_id):
    errors = result.get("errors") or []
    for error in errors:
        st.error(str(error))
    if errors:
        forms.record_validation(errors, title="Map specification sheets", action_id=action_id,
                                input_digest=result.get("digest", ""), primary=True)


def _continue(root, pack, actor_id):
    if st.button("Continue to extraction", key=PREFIX + "continue"):
        import connected_workflow_page
        import flow
        action = next((item["id"] for item in flow.acts(pack, str(root))[2]
                       if item["id"] in {"g2_extract", "g2_refresh_extraction"}), None)
        connected_workflow_page.open_route("progress", pack, actor_id, params={"action_id": action})


def _review(result, action_id):
    st.write("**Review the proposed mapping**")
    if result.get("changes"):
        st.dataframe(result["changes"], hide_index=True, width="stretch")
    if result.get("diff"):
        st.code(result["diff"], language="diff")
    if result.get("rows"):
        st.write("Requirements found in each sheet")
        st.dataframe(result["rows"], hide_index=True, width="stretch")
    if result.get("checks"):
        st.write("Validation results")
        st.dataframe(result["checks"], hide_index=True, width="stretch")
    _errors(result, action_id)
    for warning in result.get("warnings") or []:
        st.warning(str(warning))
    impact = result.get("impact") or {}
    if impact:
        with st.expander("Effect on existing definitions and source citations"):
            st.write(f"Existing definition records: {impact.get('previous_definition_records', 0)}")
            if impact.get("citation_changes"):
                st.write(impact["citation_changes"])
            else:
                st.caption("No source citation changes were reported by this preview.")
    failed = [str(row.get("details") or row.get("name")) for row in result.get("checks") or []
              if str(row.get("status", "")).lower() in {"failed", "fail", "blocked", "error"}]
    if failed:
        forms.record_validation(failed, title="Map specification sheets", action_id=action_id,
                                input_digest=result.get("digest", ""), primary=True)


def render(root, pack, actor_id, *, local_demo, can_write, can_view, allowed_packs=None,
           action_id="g2_extract"):
    """Return True only after a checked configuration save; run no extraction."""
    if not can_view:
        clear()
        return False
    allowed_packs = [pack] if allowed_packs is None else allowed_packs
    owner = forms.digest([str(Path(root).resolve()), pack, actor_id, sorted(allowed_packs),
                          bool(local_demo), bool(can_write), bool(can_view)])
    current = mapping.describe(root, pack, actor_id, allowed_packs=allowed_packs)
    if not current.get("available"):
        clear()
        return False
    if not current.get("ok"):
        with st.expander("Map workbook sheets to specification sections", expanded=True):
            _errors(current, action_id)
        return False
    context = (owner, current["digest"])
    previous = st.session_state.get(PREFIX + "context")
    saved_notice = st.session_state.get(PREFIX + "saved")
    reload_saved = st.session_state.pop(PREFIX + "reload", False)
    if previous != context or reload_saved:
        clear()
        st.session_state[PREFIX + "context"] = context
        if saved_notice and saved_notice.get("owner") == owner and (reload_saved or saved_notice.get("digest") == current["digest"]):
            st.session_state[PREFIX + "saved"] = dict(saved_notice, digest=current["digest"])
        elif previous and previous[0] == owner:
            st.session_state[PREFIX + "changed"] = True
    editable = [sheet for sheet in current["sheets"] if sheet.get("editable") and not sheet.get("excluded")]
    excluded = [sheet for sheet in current["sheets"] if sheet.get("excluded")]
    other = [sheet for sheet in current["sheets"] if not sheet.get("editable") and not sheet.get("excluded")]
    enabled = bool(local_demo and can_write and pack in allowed_packs)
    pending = any(not sheet.get("domain") for sheet in editable)
    with st.expander("Map workbook sheets to specification sections", expanded=pending):
        st.caption("Choose the section each sheet belongs to. Two or more sheets may use the same section; their original sheet names and rows remain traceable.")
        if current.get("notice"):
            st.caption(str(current["notice"]))
        if st.session_state.pop(PREFIX + "changed", False):
            st.info("The workbook or extraction settings changed. Current assignments are reloaded; preview these choices again before saving.")
        notice = st.session_state.get(PREFIX + "saved")
        if notice:
            st.success(notice["text"])
            _continue(root, pack, actor_id)
        domains = list(current["domains"])
        assignments = {}
        for sheet in editable:
            name = sheet["name"]
            key = sheet_key(name)
            st.session_state.setdefault(key, sheet.get("domain") or "")
            options = domains if sheet.get("domain") in domains else ["", *domains]
            if st.session_state[key] not in options:
                st.session_state[key] = sheet.get("domain") if sheet.get("domain") in options else options[0]
            domain = forms.field(st.selectbox, mapping.SHEET_FIELD_PREFIX + name, options,
                key=key, binding=(pack, current["digest"], name), disabled=not enabled,
                format_func=lambda value: value or "Choose a section",
                help="Use the specification's meaning. The same section can be selected for multiple sheets. This assigns workbook requirements, not patient-data table mappings.")
            if domain:
                assignments[name] = domain
        if excluded:
            st.write("**Sheets already excluded from this product**")
            st.dataframe([{"Sheet": row["name"], "Scope": "Excluded from this product"} for row in excluded],
                         hide_index=True, width="stretch")
            st.caption("These exclusions are preserved separately. Study-only exclusions remain in Studies or Plan changes.")
        if other:
            with st.expander("Other workbook sheets"):
                st.dataframe([{"Sheet": row["name"], "Section": row.get("domain") or "",
                               "Status": row.get("kind") or "Unavailable for mapping"} for row in other],
                             hide_index=True, width="stretch")
        if not editable:
            st.info("There are no editable sheet assignments for this workbook.")
            return False
        reason = forms.field(st.text_input, mapping.REASON_FIELD,
            key=PREFIX + "reason", binding=(pack, current["digest"]), max_chars=1000, disabled=not enabled,
            placeholder="For example: Both sheets contain baseline clinical requirements.",
            help="Explain the sheet layout in your own words. Preview checks the extraction and shows the exact configuration change.").strip()
        values = forms.digest([context, assignments, reason])
        reviewed = st.session_state.get(PREFIX + "preview")
        if reviewed and reviewed["values"] != values:
            st.session_state.pop(PREFIX + "preview", None)
            st.session_state.pop(PREFIX + "confirmed", None)
            reviewed = None
            st.info("Your choices changed. Preview again to review the updated mapping.")
        if st.button("Preview mapping", key=PREFIX + "preview_button", disabled=not enabled):
            with st.spinner("Checking sheet assignments and extraction…"):
                result = mapping.preview(root, pack, actor_id, assignments, reason,
                    expected_digest=current["digest"], allowed_packs=allowed_packs)
            st.session_state.pop(PREFIX + "confirmed", None)
            reviewed = {"values": values, "result": result}
            st.session_state[PREFIX + "preview"] = reviewed
        if reviewed:
            result = reviewed["result"]
            _review(result, action_id)
            if reviewed.get("save_error"):
                _errors(reviewed["save_error"], action_id)
            if result.get("ok") and result.get("can_apply") and result.get("preview_digest"):
                confirmed = st.checkbox("I reviewed these sheet assignments, the diff and validation results.",
                    key=PREFIX + "confirmed", disabled=not enabled)
                if st.button("Save checked mapping", key=PREFIX + "save", type="primary",
                             disabled=not (enabled and confirmed)):
                    outcome = mapping.apply(root, pack, actor_id, assignments, reason,
                        expected_digest=current["digest"], expected_preview_digest=result["preview_digest"],
                        allowed_packs=allowed_packs, can_write=enabled, confirmed=confirmed)
                    if outcome.get("ok") and outcome.get("changed"):
                        text = outcome.get("notice") or "Sheet mapping saved. Continue to extraction, then review the scientific definitions. This does not approve or release the product."
                        st.session_state[PREFIX + "saved"] = {"owner": owner, "text": str(text)}
                        st.session_state[PREFIX + "reload"] = True
                        st.success(str(text))
                        if not notice:
                            _continue(root, pack, actor_id)
                        return True
                    reviewed["save_error"] = outcome
                    _errors(outcome, action_id)
        st.caption("Saving updates draft extraction settings. Run the extraction next; scientific interpretation and review remain separate steps.")
    return False
