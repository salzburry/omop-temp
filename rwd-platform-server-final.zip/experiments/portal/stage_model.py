"""One vocabulary for where a product stands, shared by every page that shows progress.

WHY. Home, the product header, Flow, Evidence overview and the walkthrough each computed their own
idea of "how far along is this product" from the same gate results, with their own words and their
own glyphs: a product read "1 of 6 gates passed" on one page, "in progress" on another and
"blocked" on a third, because Gate 6 is reported blocked by the gate engine until a build is
approved. This module is the ONE translation from `status.gates()` (through `flow.flow()`) or a
governance-snapshot entry into six stages with one state each, so every surface says the same
thing. PURE: no Streamlit; tested on plain dicts (platform/tests/test_stage_model.py).

The six stage names are the scientist's words for the six gates; the gate numbers stay the
identity, so nothing here re-derives a gate state — it only renders the engine's verdicts.
"""
from __future__ import annotations

import flow_guidance as guidance

STAGES = (
    (1, "Specification", "the approved workbook is registered, reviewed and its extraction approved"),
    (2, "Definitions", "every specification row is a reviewed definition or an answered question"),
    (3, "Sources", "the delivered data is shown to carry what each definition needs"),
    (4, "Configuration", "the executable configuration is authored, checked and approved"),
    (5, "Validation", "a build is validated against its own evidence"),
    (6, "Release", "one build is approved and published for studies"),
)
LABELS = {n: label for n, label, _why in STAGES}
PURPOSES = {n: why for n, _label, why in STAGES}

COMPLETE, CURRENT, BLOCKED, UPCOMING, UNCHECKED = "complete", "current", "blocked", "upcoming", "not checked"
STATES = (COMPLETE, CURRENT, BLOCKED, UPCOMING, UNCHECKED)
# The words status.py emits for a gate, grouped by what they mean for a stage row.
_DONE_WORDS = {"done"}
_BLOCKED_WORDS = {"blocked", "cannot complete"}


def _gate_rows(gates):
    rows = {}
    for gate in gates or []:
        if not isinstance(gate, dict):
            continue
        number = gate.get("gate")
        if type(number) is not int or not 1 <= number <= 6:
            continue
        rows[number] = {"state": str(gate.get("state") or gate.get("status") or "").strip().lower(),
                        "blockers": [str(b) for b in (gate.get("blockers") or []) if isinstance(b, str)]}
    return rows


def stages(gates, current=None) -> list[dict]:
    """Six rows from a gate list. `current` is the first gate that is not done (flow.flow() names it);
    when None it is derived the same way. A gate AFTER the current one is upcoming whatever the
    engine says about it, because its verdict is a consequence of the earlier gate, not its own."""
    rows = _gate_rows(gates)
    if not rows:
        return [{"gate": n, "label": LABELS[n], "state": UNCHECKED, "blockers": 0, "why": PURPOSES[n]} for n in LABELS]
    if current is None:
        current = next((n for n in range(1, 7) if rows.get(n, {}).get("state") not in _DONE_WORDS), None)
    out = []
    for n in range(1, 7):
        row = rows.get(n, {"state": "", "blockers": []})
        if row["state"] in _DONE_WORDS:
            state = COMPLETE
        elif current is None:
            state = COMPLETE
        elif n < current:
            state = COMPLETE if row["state"] in _DONE_WORDS else BLOCKED
        elif n == current:
            state = BLOCKED if row["state"] in _BLOCKED_WORDS else CURRENT
        else:
            state = UPCOMING
        out.append({"gate": n, "label": LABELS[n], "state": state, "blockers": len(row["blockers"]), "why": PURPOSES[n]})
    return out


def from_flow(result) -> list[dict]:
    """Stages from a flow.flow() result (or a result carrying an error: every stage not checked)."""
    if not isinstance(result, dict) or result.get("error") or not result.get("gates"):
        return stages([])
    return stages(result.get("gates"), result.get("current"))


def from_snapshot(entry) -> list[dict]:
    """Stages from a governance-snapshot pack entry ({gates: [{gate, status, blockers}]})."""
    if not isinstance(entry, dict) or not entry.get("gates"):
        return stages([])
    return stages(entry.get("gates"))


def summary(rows) -> dict:
    """The one-line facts a card shows: how many stages are complete, which one is current."""
    done = sum(1 for r in rows if r["state"] == COMPLETE)
    current = next((r for r in rows if r["state"] in (CURRENT, BLOCKED)), None)
    checked = any(r["state"] != UNCHECKED for r in rows)
    if not checked:
        line = "Not checked yet"
    elif current is None:
        line = "All six stages complete"
    else:
        line = f"Stage {current['gate']} of 6: {current['label']}" + (" (blocked)" if current["state"] == BLOCKED else "")
    return {"done": done, "total": 6, "current": current["gate"] if current else None,
            "current_label": current["label"] if current else "", "checked": checked, "line": line}


def _unique_actions(card):
    unique = {}
    for action in card.get("fixes") or []:
        if isinstance(action, dict) and action.get("id"):
            unique.setdefault(action["id"], action)
    return list(unique.values())


def next_step(root, pack, result) -> dict:
    """What the product needs next, in the words the Flow page uses for the same card, so the header
    and the card never disagree. Returns {title, summary, owner, gate, action_id} or an 'unknown'
    shape when there is no evaluation yet."""
    if not isinstance(result, dict) or result.get("error") or not result.get("gates"):
        return {"title": "", "summary": "", "owner": "", "gate": None, "action_id": "", "known": False}
    if result.get("clear"):
        return {"title": "Review the release handoff", "summary": "All six checks passed. Confirm the signed records and release receipt before using this release in a study.",
                "owner": "Accountable reviewer", "gate": None, "action_id": "", "known": True}
    cards = [c for c in (result.get("blockers") or []) if isinstance(c, dict)]
    if not cards:
        return {"title": str(result.get("proceed") or "Review the current step with your product team."), "summary": "",
                "owner": "", "gate": result.get("current"), "action_id": "", "known": True}
    card = cards[0]
    actions = _unique_actions(card)
    action = actions[0] if actions else {}
    if action.get("id") == "g2_scaffold" and len(actions) > 1:
        try:
            if guidance.specification_outline(root, pack)["current"]:
                action = next((a for a in actions if a["id"] == "g2_draft"), action)
        except (OSError, ValueError, TypeError, KeyError):
            pass
    copy = guidance.issue_copy(action, str(card.get("text", "")))
    owner = str(card.get("owner") or "Product team")
    owner = " · ".join(part.split("(", 1)[0].strip().replace("DataExpert", "Data expert") for part in owner.split(" · "))
    return {"title": str(copy.get("title") or ""), "summary": str(copy.get("summary") or ""), "owner": owner,
            "gate": result.get("current"), "action_id": str(action.get("id") or ""), "known": True}
