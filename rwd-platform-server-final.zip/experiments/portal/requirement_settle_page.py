"""The settle-requirements form on the Flow page (2026-09-07)."""
from __future__ import annotations

import streamlit as st

import requirement_settle as rs

PREFIX = "requirement_settle_"


def render(root, pack, actor_id, *, local_demo, can_settle, can_view, allowed_packs=None):
    """Returns True when records were just settled (the caller re-checks the product)."""
    if not can_view:
        return False
    info = rs.describe(root, pack, allowed_packs=allowed_packs)
    for error in info["errors"]:
        st.warning(error)
    if not info["ok"]:
        return False
    counts = info.get("counts") or {}
    if not counts.get("total"):
        return False
    st.write("**Settle the requirements**")
    st.caption("Confirm that the completed records ask for the intended scientific definitions.")
    st.write(f"{counts.get('approved', 0)} of {counts.get('total', 0)} records settled.")
    not_eligible = [r for r in info["records"] if not r["eligible"] and r["requirement"] != "approved"]
    if not_eligible:
        with st.expander(f"{len(not_eligible)} record(s) cannot be settled yet"):
            for r in not_eligible:
                st.write(f"- {r['id']}: {r['why']}")
    if not info["eligible"]:
        st.info("No record is waiting to be settled.")
        return False
    if not local_demo:
        st.info("Settling a requirement is done on the person's own checkout in this version.")
        return False
    if not can_settle:
        st.info("Settling a requirement is the scientific owner's act; your role can read this page but not record it.")
        return False
    notice = st.session_state.pop(PREFIX + "notice", None)
    if notice:
        st.success(notice)
    with st.form(PREFIX + "form"):
        chosen = st.multiselect("Records to settle", info["eligible"], key=PREFIX + "ids")
        every = st.checkbox(f"Settle every eligible record ({len(info['eligible'])})", key=PREFIX + "all")
        confirmed = st.checkbox("I am the scientific owner of these records and each one asks for the right thing.", key=PREFIX + "confirm")
        sent = st.form_submit_button("Settle these requirements", type="primary", key=PREFIX + "submit")
    if not sent:
        return False
    ids = list(info["eligible"]) if every else list(chosen)
    try:
        result = rs.settle(root, pack, ids, expected_digest=info["digest"], local_demo=local_demo, can_settle=can_settle,
                           confirmed=confirmed, allowed_packs=allowed_packs)
    except rs.Refused as error:
        st.error("Not settled. " + str(error))
        return False
    st.session_state.setdefault("flow_result", {}).pop(pack, None)
    st.session_state[PREFIX + "notice"] = result["message"]     # shown again after the re-check redraws the dialog (walk RW1-02)
    st.success(result["message"])
    return True
