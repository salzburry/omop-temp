"""Portal subprocesses return failures as results, including timeouts, never page tracebacks."""
from __future__ import annotations

import hashlib
import os
import subprocess
import time
from contextvars import ContextVar

_JOB_CALLBACKS = ContextVar("portal_job_callbacks", default=(None, None))
_PROCESS_OBSERVER = ContextVar("portal_process_observer", default=None)
CANCELLED_EXIT = 130
CANCELLED_MESSAGE = "Cancellation requested. The local check stopped; inspect the retained workflow result before retrying."


def job_callbacks(cancelled=None, progress=None):
    """Install callbacks only inside the detached, explicitly requested worker."""
    return _JOB_CALLBACKS.set((cancelled, progress))


def reset_job_callbacks(token):
    _JOB_CALLBACKS.reset(token)


def has_job_callbacks():
    return _JOB_CALLBACKS.get()[0] is not None


def job_cancelled():
    callback, _ = _JOB_CALLBACKS.get()
    return bool(callback and callback())


def job_progress(message):
    _, callback = _JOB_CALLBACKS.get()
    if callback:
        callback(message)


def process_observer(callback):
    return _PROCESS_OBSERVER.set(callback)


def reset_process_observer(token):
    _PROCESS_OBSERVER.reset(token)


def snapshot_path(root, state_dir, portal_dir):
    """Default status artifacts live outside the checkout, with one namespace per repository."""
    explicit = os.environ.get("RWDP_GOVERNANCE_SNAPSHOT")
    if explicit:
        return os.path.realpath(explicit)
    if os.path.realpath(state_dir) == os.path.realpath(portal_dir):
        identifier = hashlib.sha256(os.path.normcase(os.path.realpath(root)).encode("utf-8")).hexdigest()[:12]
        state_dir = os.path.join(os.path.expanduser("~"), "rwdp-out", "portal", identifier)
    return os.path.realpath(os.path.join(state_dir, "snapshot.json"))


def within_packs(path, root, packs):
    """A file belongs to an assigned pack only when its resolved path stays inside it."""
    candidate = os.path.normcase(os.path.realpath(os.path.join(root, path)))
    for pack in packs:
        parent = os.path.normcase(os.path.realpath(os.path.join(root, pack)))
        try:
            if os.path.commonpath((candidate, parent)) == parent:
                return True
        except ValueError:
            continue
    return False


def timeout(name, default):
    try:
        value = int(os.environ.get(name, str(default)))
        return value if 1 <= value <= 3600 else default
    except (TypeError, ValueError):
        return default


TIMEOUT_EXIT = 124
CANNOT_START_EXIT = 126
# THE ONE SEAM A TEST REPLACES. The runner starts its own processes (subprocess.run cannot stop a
# grandchild), so a journey test that used to intercept subprocess.run intercepts this factory
# instead and hands back a double with start_tree()/close_tree() as well as the
# usual communicate()/poll()/wait()/kill(). Detached worker launches do not opt in.
from process_lifetime import popen as _popen


def _timeout_message(timeout_s):
    return (f"This action exceeded {timeout_s}s. Your form is retained. "
            "Check the product's current state before retrying a write; an interrupted action may need recovery. "
            "Give these details to your data expert if it happens again.")


def _cannot_start_message(exc):
    return (f"The action could not start ({type(exc).__name__}). Your form is retained. "
            "Your data expert can check the runtime installation.")


def failure_kind(result):
    """Why a result carries no tool output: "timeout", "start" (it never ran), or None (the tool itself answered).

    A tool exiting 124 or 126 on its own still prints something; the runtime's own refusals never do."""
    if result.returncode == CANCELLED_EXIT and result.stderr == CANCELLED_MESSAGE:
        return "cancelled"
    if result.stdout:
        return None
    if result.returncode == TIMEOUT_EXIT and result.stderr.startswith("This action exceeded "):
        return "timeout"
    if result.returncode == CANNOT_START_EXIT and result.stderr.startswith("The action could not start ("):
        return "start"
    return None


def _terminate_tree(process, kill_tree):
    """Stop everything the command started, not only the direct child.

    Killing the child alone leaves a grandchild (a tool that spawns another python) running after the
    portal has already told the person the action failed; that survivor may still write into the pack.
    The child runs in its own process group so the whole group can be stopped together."""
    if kill_tree:
        # Ownership outlives the direct child. The guard/job/group also contains
        # grandchildren whose original parent already exited.
        process.close_tree()
    elif process.poll() is None:
        process.kill()
    try:
        process.wait(timeout=15)
    except subprocess.TimeoutExpired:
        pass


def run(argv, *, cwd, timeout_s, kill_tree=True, extra_env=None):
    """One bounded command whose failure is a result the page can show, never a traceback.

    A fixed guard joins its owned OS lifetime before starting the command. Timeouts and worker
    death stop the whole tree, including children whose original parent already exited.
    kill_tree=False stops only the direct child, for callers that own their descendants."""
    env = dict(os.environ, PYTHONUTF8="1", **(extra_env or {}))
    options = {}
    if kill_tree:
        options = ({"creationflags": subprocess.CREATE_NEW_PROCESS_GROUP | subprocess.CREATE_NO_WINDOW} if os.name == "nt"
                   else {"start_new_session": True})
    try:
        process = _popen(argv, cwd=cwd, stdin=subprocess.DEVNULL, stdout=subprocess.PIPE,
                         stderr=subprocess.PIPE, text=True, encoding="utf-8", errors="replace",
                         env=env, _owned_tree=kill_tree, **options)
    except OSError as exc:
        return subprocess.CompletedProcess(argv, CANNOT_START_EXIT, "", _cannot_start_message(exc))
    observer = _PROCESS_OBSERVER.get()
    observed = False
    try:
        if observer:
            observer(process, True)
            observed = True
        if kill_tree:
            process.start_tree()
    except BaseException as error:
        # Even an unexpected observer failure must not strand an inactive guard.
        try:
            _terminate_tree(process, kill_tree)
        finally:
            if observed:
                observer(process, False)
        if not isinstance(error, (OSError, ValueError)):
            raise
        return subprocess.CompletedProcess(argv, CANNOT_START_EXIT, "",
            "The action could not start (ProcessOwnershipError). The local process group could not be bound "
            "before execution. Inspect the retained action before retrying.")
    try:
        return _communicate(process, argv, timeout_s, kill_tree)
    finally:
        try:
            if kill_tree:
                process.close_tree()
        finally:
            if observed:
                observer(process, False)


def _communicate(process, argv, timeout_s, kill_tree):
    try:
        if _JOB_CALLBACKS.get()[0] is None:
            stdout, stderr = process.communicate(timeout=timeout_s)
        else:
            deadline = time.monotonic() + timeout_s
            while True:
                if job_cancelled():
                    _terminate_tree(process, kill_tree)
                    return subprocess.CompletedProcess(argv, CANCELLED_EXIT, "", CANCELLED_MESSAGE)
                remaining = deadline - time.monotonic()
                if remaining <= 0:
                    raise subprocess.TimeoutExpired(argv, timeout_s)
                try:
                    stdout, stderr = process.communicate(timeout=min(1, remaining))
                    break
                except subprocess.TimeoutExpired:
                    if time.monotonic() >= deadline:
                        raise
    except subprocess.TimeoutExpired:
        _terminate_tree(process, kill_tree)
        try:
            process.communicate(timeout=15)
        except (subprocess.TimeoutExpired, OSError, ValueError):
            pass
        return subprocess.CompletedProcess(argv, TIMEOUT_EXIT, "", _timeout_message(timeout_s))
    return subprocess.CompletedProcess(argv, process.returncode, stdout, stderr)
