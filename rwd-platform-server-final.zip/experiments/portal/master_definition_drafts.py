"""Append explicitly reviewed, value-free definitions to the shared draft library.

This is an additive catalogue operation. It never updates a product, a private
row draft, an existing library entry, or scientific approval records.
"""
from __future__ import annotations

from contextlib import contextmanager
from copy import deepcopy
from datetime import datetime, timezone
import json
import os
from pathlib import Path
import re

import yaml

import scientific_definitions as definitions
import master_variable_library as library
import definition_reuse_logic as reuse_logic

CUSTOM = "governance/reference/variable_inventory/CUSTOM_LOGIC.yaml"
SOURCES = (library.INVENTORY, library.SUPPLEMENT, CUSTOM)
FIELDS = {"name", "label", "definition", "logic", "data_type", "source_kind", "parameter_slots"}
ENTRY_FIELDS = FIELDS | {"evidence", "created_by", "created_at", "status"}
KINDS = {"vendor", "derived", "parameter", "constant", "unavailable", "pending_mapping"}
TOKEN = r"[A-Za-z_][A-Za-z0-9_]*(?:\.[A-Za-z_][A-Za-z0-9_]*)*"


def _fail(error):
    return {**definitions._fail(error), "status": "draft", "approval_created": False}


def _text(value, label, limit=12000):
    if not isinstance(value, str) or definitions._placeholder(value) or len(value) > limit:
        raise ValueError("Enter " + label + " within its displayed text limit.")
    if any(ord(char) < 32 and char not in "\r\n\t" for char in value):
        raise ValueError("Definition fields cannot contain control characters.")
    return value.strip()


def _fields(**values):
    if set(values) != FIELDS:
        raise ValueError("Supply only the displayed reusable-definition fields.")
    candidate = {name: _text(values[name], name.replace("_", " "), 12000 if name in {"definition", "logic"} else 200)
                 for name in ("name", "label", "definition", "logic", "data_type", "source_kind")}
    if not re.fullmatch(r"[A-Za-z][A-Za-z0-9_]{0,79}", candidate["name"]):
        raise ValueError("Use a definition name beginning with a letter and containing only letters, numbers and underscores.")
    if candidate["source_kind"] not in KINDS:
        raise ValueError("Choose a displayed source kind for the reusable definition.")
    slots = values["parameter_slots"]
    if not isinstance(slots, list) or len(slots) > 50:
        raise ValueError("Parameter slots must be a list of at most 50 names and descriptions.")
    candidate["parameter_slots"] = []
    names = set()
    for slot in slots:
        if not isinstance(slot, dict) or set(slot) != {"name", "description"}:
            raise ValueError("Each parameter slot needs only a name and description; values, examples and defaults stay in the product.")
        name = _text(slot["name"], "a parameter name", 200)
        if not re.fullmatch(TOKEN, name) or name.casefold() in names:
            raise ValueError("Use distinct parameter names containing letters, numbers, underscores and optional dots.")
        names.add(name.casefold())
        candidate["parameter_slots"].append({"name": name, "description": _text(slot["description"], "a parameter description")})
    referenced = set(re.findall(r"\{\{(" + TOKEN + r")\}\}", candidate["logic"]))
    remainder = re.sub(r"\{\{" + TOKEN + r"\}\}", "", candidate["logic"])
    if "{{" in remainder or "}}" in remainder:
        raise ValueError("Write parameter references as {{parameter_name}}.")
    if referenced - {slot["name"] for slot in candidate["parameter_slots"]}:
        raise ValueError("Describe every named parameter used in the reusable logic.")
    return candidate


def _catalogue(root):
    inputs = {}
    documents = {}
    for relative in SOURCES:
        path = definitions._safe(root / relative)
        raw = definitions._read(path) if path.exists() else None
        inputs[relative] = definitions._hash(raw) if raw is not None else None
        if raw is not None:
            doc = yaml.load(raw, Loader=definitions.details._StrictLoader)
            key = "master" if relative == library.INVENTORY else "templates"
            if not isinstance(doc, dict) or not isinstance(doc.get(key), list):
                raise ValueError("Repair the master library's " + key + " list before adding a definition.")
            seen = set()
            for entry in doc[key]:
                if not isinstance(entry, dict) or not isinstance(entry.get("name"), str) or not entry["name"].strip():
                    raise ValueError("Repair the unnamed entry in the master library before adding a definition.")
                name = entry["name"].strip().casefold()
                if name in seen:
                    raise ValueError("Repair duplicate names in the master library before adding a definition.")
                seen.add(name)
            documents[relative] = doc
    custom = documents.get(CUSTOM, {"version": 1, "status": "draft", "templates": []})
    if set(custom) != {"version", "status", "templates"} or custom.get("version") != 1 or custom.get("status") != "draft":
        raise ValueError("The custom definition library must use the supported draft format.")
    for entry in custom["templates"]:
        if set(entry) != ENTRY_FIELDS or entry.get("status") != "draft":
            raise ValueError("A custom library entry must remain an unapproved definition draft.")
        _fields(**{key: entry[key] for key in FIELDS})
        if not isinstance(entry["evidence"], list) or not entry["evidence"] or any(not isinstance(value, str) for value in entry["evidence"]):
            raise ValueError("A custom definition is missing its source-row provenance.")
        _text(entry["created_by"], "the recorded creating profile", 200)
        _text(entry["created_at"], "the recorded creation time", 100)
    return definitions._hash(inputs), documents, deepcopy(custom)


def _context(root, pack, actor_id, item_id, allowed_packs):
    import variable_review_workflow as workflow
    root = Path(root).resolve()
    report = workflow.describe(root, pack, actor_id, allowed_packs=allowed_packs)
    if not report.get("ok"):
        raise ValueError(" ".join(report.get("errors") or ["Reload the product's variable table."]))
    row = next((row for row in report["rows"] if row["item_id"] == item_id), None)
    if row is None:
        raise ValueError("Choose a current specification row before creating a reusable definition.")
    library_digest, documents, custom = _catalogue(root)
    return report, row, library_digest, documents, custom


def describe(root, pack, actor_id, *, item_id, allowed_packs=None):
    """Capture the displayed product, shared row state and entire catalogue."""
    try:
        report, _row, digest, _documents, _custom = _context(root, pack, actor_id, item_id, allowed_packs)
        return {"ok": True, "errors": [], "input_digest": report["input_digest"],
                "state_digest": report["state_digest"], "library_digest": digest,
                "status": "draft", "approval_created": False}
    except (ValueError, TypeError, KeyError, AttributeError, OSError, RecursionError, yaml.YAMLError) as error:
        return _fail(error)


def _validate_logic(candidate, row):
    source = deepcopy(row["values"].get("source") or {})
    if not isinstance(source, dict):
        source = definitions._as_mapping(source) or {}
    records = []
    for kind in {source.get("kind"), candidate["source_kind"]} - {None, ""}:
        context = {**source, "kind": kind}
        if "value" not in context:
            fields = row.get("spec_values") or {}
            explicit = [fields[key] for key in ("value", "values") if key in fields and fields[key] not in (None, "")]
            if len(explicit) == 1 and type(explicit[0]) in {str, bool, int, float}:
                context["value"] = explicit[0]
        record = {"derivation": candidate["logic"], "interpreted": [("Source table and field", context)], "executable": []}
        reuse_logic.validate(record, candidate["logic"], disposition="adapt", logic_reviewed=True)
        records.append(record)
    # Prose and slot descriptions are reusable content too; date/example values
    # must not be hidden there while the formula itself uses a named parameter.
    prose = "\n".join([candidate["name"], candidate["label"], candidate["definition"], candidate["data_type"],
                         *[text for slot in candidate["parameter_slots"] for text in slot.values()]])
    if reuse_logic._calendar_values(prose):
        raise ValueError("Keep product dates out of the reusable definition and parameter descriptions.")
    for record in records:
        for literal, _token in reuse_logic._declared(record):
            if reuse_logic._occurs(prose, literal):
                raise ValueError("Keep this product's value out of the reusable definition and parameter descriptions.")
    import scientific_definition_ai as assistant
    assistant._ingress(json.dumps(candidate, ensure_ascii=False))


@contextmanager
def _locked(path):
    path.parent.mkdir(parents=True, exist_ok=True)
    lock = definitions._safe(path.with_suffix(".lock"))
    handle = open(lock, "a+b")
    acquired = False
    try:
        if os.name == "nt":
            import msvcrt
            if handle.seek(0, os.SEEK_END) == 0:
                handle.write(b"0")
                handle.flush()
            handle.seek(0)
            try:
                msvcrt.locking(handle.fileno(), msvcrt.LK_NBLCK, 1)
            except OSError as error:
                raise ValueError("Another person is saving a reusable definition. Reload after that save finishes.") from error
        else:
            import fcntl
            try:
                fcntl.flock(handle.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
            except OSError as error:
                raise ValueError("Another person is saving a reusable definition. Reload after that save finishes.") from error
        acquired = True
        yield
    finally:
        if acquired:
            if os.name == "nt":
                handle.seek(0)
                msvcrt.locking(handle.fileno(), msvcrt.LK_UNLCK, 1)
            else:
                fcntl.flock(handle.fileno(), fcntl.LOCK_UN)
        handle.close()


def save(root, pack, actor_id, *, item_id, name, label, definition, logic, data_type, source_kind, parameter_slots,
         expected_input_digest, expected_state_digest, expected_library_digest,
         allowed_packs=None, local_demo=False, can_write=False, confirmed=False):
    """Save only after the person clicks the displayed new-definition action."""
    if local_demo is not True or can_write is not True or confirmed is not True:
        return _fail("Saving a reusable definition requires an authorized editor and the explicit Save new definition action.")
    try:
        if not isinstance(expected_state_digest, str) or any(not isinstance(value, str) or not re.fullmatch(r"[a-f0-9]{64}", value)
                for value in (expected_input_digest, expected_library_digest)):
            raise ValueError("Reload the displayed definition and library before saving.")
        candidate = _fields(name=name, label=label, definition=definition, logic=logic, data_type=data_type,
                            source_kind=source_kind, parameter_slots=parameter_slots)
        root = Path(root).resolve()
        report, row, digest, documents, custom = _context(root, pack, actor_id, item_id, allowed_packs)
        _validate_logic(candidate, row)
        path = definitions._safe(root / CUSTOM)
        with _locked(path):
            report, row, digest, documents, custom = _context(root, pack, actor_id, item_id, allowed_packs)
            _validate_logic(candidate, row)
            evidence = [pack + "/spec_pipeline/out/extracted.json#" + item_id]
            existing = next((entry for entry in custom["templates"] if entry["name"].casefold() == candidate["name"].casefold()), None)
            if existing and all(existing[key] == candidate[key] for key in FIELDS) and existing["created_by"] == actor_id.strip() and existing["evidence"] == evidence:
                return {"ok": True, "errors": [], "changed": False, "name": existing["name"], "library_digest": digest,
                        "status": "draft", "approval_created": False, "message": "This exact reusable definition draft is already saved."}
            for relative, document in documents.items():
                key = "master" if relative == library.INVENTORY else "templates"
                if any(entry["name"].strip().casefold() == candidate["name"].casefold() for entry in document[key]):
                    raise ValueError("That definition name already exists in the master library. Choose a different name or use the existing match; no entry was overwritten.")
            def still_current():
                latest, _row, latest_digest, _documents, _custom = _context(root, pack, actor_id, item_id, allowed_packs)
                if (latest["input_digest"], latest["state_digest"], latest_digest) != (expected_input_digest, expected_state_digest, expected_library_digest):
                    raise ValueError("The product, shared row or master library changed. Reload the current definition before saving; your proposed fields are retained.")
            still_current()
            custom["templates"].append({**candidate, "status": "draft", "evidence": evidence,
                "created_by": _text(actor_id, "the creating profile", 200),
                "created_at": datetime.now(timezone.utc).isoformat(timespec="seconds")})
            payload = yaml.safe_dump(custom, sort_keys=False, allow_unicode=True).encode("utf-8")
            if len(payload) > definitions.LIMIT:
                raise ValueError("The custom definition library exceeds its draft size limit.")
            definitions._atomic(path, payload, check=still_current)
        return {"ok": True, "errors": [], "changed": True, "name": candidate["name"],
                "library_digest": _catalogue(root)[0], "status": "draft", "approval_created": False,
                "message": "Saved a reusable definition draft for future products. It is not an approved scientific standard."}
    except (ValueError, TypeError, KeyError, AttributeError, OSError, RecursionError, yaml.YAMLError) as error:
        return _fail(error)
