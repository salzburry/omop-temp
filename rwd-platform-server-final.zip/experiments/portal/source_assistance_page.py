"""Use the existing source specialist alongside the common workflow chat.

This module supplies bounded declaration context and UI orchestration only. The
specialist owns model access, evidence collection and private result persistence;
source_workspace owns mapping choices, validators and reviewed draft saves.
"""
from __future__ import annotations

import hashlib
import json
from pathlib import Path

import streamlit as st
import scientific_definition_ai as ai
import source_workspace as source
import specialist_workspace as specialist

PREFIX = "source_ws_assist_"
# The source form clears source_ws_* when actor/product changes. Keep this
# content-free receipt outside that reset so stale navigation text cannot be
# reinterpreted as a new actor's request.
HANDOFF_RECEIPT = "source_assessment_handoff_receipt"
ROUTES = {"source_requirements", "source_delivery", "source_evidence", "source_mapping"}
FAILURE = "The source assessment could not complete. Your mapping choices are retained. Retry explicitly with the selected connection, or continue with the source details."


def context_for(root, pack, actor_id, *, allowed_packs, route):
    """Only current, scoped declarations; never a restricted profile or its cells."""
    try:
        if route not in ROUTES:
            raise ValueError()
        report = source.describe(root, pack, actor_id, allowed_packs=allowed_packs)
        if not report.get("ok"):
            raise ValueError()
        ai.definitions.cs.ai_gate(str(Path(root).resolve() / pack))
        declared_roles = [str(row["role"]) for row in report["rows"]]
        context = {
            "source_delivery": str(report["delivery_sentence"])[:300],
            "source_roles": ", ".join(declared_roles[:12])[:300],
            "source_blockers": " ".join(str(value) for value in report["blockers"][:5])[:600]
                or "No declaration prerequisite is reported. Runtime evidence and human source review remain separate requirements.",
            "source_task": route,
        }
        # Check the complete selected declaration text before bounding it, so a
        # credential/individual detail cannot be hidden just beyond an excerpt.
        ai._ingress(ai._plain({"identity": report["identity"], "roles": declared_roles, "blockers": report["blockers"]}))
        fresh = source.describe(root, pack, actor_id, allowed_packs=allowed_packs)
        if not fresh.get("ok") or fresh["inputs_sha256"] != report["inputs_sha256"]:
            raise ValueError()
        return {"ok": True, "context": context, "input_digest": report["inputs_sha256"], "errors": []}
    except Exception:
        return {"ok": False, "context": {}, "input_digest": "",
                "errors": ["Current source declarations are unavailable for assistant context. Continue with the source details and their access review."]}


def _connection(root):
    """Inspect only the explicitly selected provider; rendering never generates."""
    try:
        if not ai.selected_provider():
            return None
        config = ai._provider(root)
        if (not isinstance(config, dict) or config.get("configured") is not True
                or config.get("provider_id") not in ai.PROVIDERS
                or not isinstance(config.get("model"), str) or not config["model"]):
            return None
        words = {key: config.get(key, "") for key in ("provider_id", "model", "connection_id")}
        if any(not isinstance(value, str) or len(value) > 1000 for value in words.values()):
            return None
        ai._ingress(ai._plain(words))
        return words
    except Exception:
        return None


def _read(arguments, run_id):
    record = specialist.read(**arguments, run_id=run_id)
    if record["kind"] != "source":
        raise ValueError("Choose a source assessment.")
    content = record["result"]["assembly"]
    if (not isinstance(content, dict) or not isinstance(content.get("summary"), str)
            or len(content["summary"]) > 4000):
        raise ValueError("The source summary is unreadable.")
    ai._ingress(ai._plain(record["result"]))
    return record


def _retain_source_inputs():
    # The assessment sits above these widgets. A rerun before they are rendered
    # otherwise triggers Streamlit's widget cleanup and drops unfinished input.
    names = {"mapping_profile", "dataset", "profile_return", "schema_return", "qc_return", "request_member"}
    for key in list(st.session_state):
        if key.startswith("source_ws_role_") or key in {"source_ws_" + name for name in names}:
            st.session_state[key] = st.session_state[key]


def render(root, pack, actor_id, *, allowed_packs, local_demo, can_write, can_agent, route, params=None):
    """Offer the existing assessment once; return an explicit review destination."""
    import interaction_feedback_page as feedback
    connection = _connection(root)
    context = context_for(root, pack, actor_id, allowed_packs=allowed_packs, route=route) if connection else {"ok": False}
    if not connection or not context["ok"]:
        feedback.clear(PREFIX + "feedback")
        return {"active": False, "navigation": None}
    arguments = dict(root=root, pack=pack, actor_id=actor_id, allowed_packs=allowed_packs)
    state = specialist.describe(**arguments)
    if not isinstance(state, dict) or not state.get("ok") or state.get("blocker"):
        feedback.clear(PREFIX + "feedback")
        return {"active": False, "navigation": None}
    request_scope = hashlib.sha256(json.dumps([str(Path(root).resolve()), pack, actor_id, route,
        sorted(allowed_packs or [])]).encode()).hexdigest()[:20]
    request_key = PREFIX + "request_" + request_scope
    draft_key = PREFIX + "request_draft_" + request_scope
    if request_key not in st.session_state:
        st.session_state[request_key] = st.session_state.get(draft_key, "")
    offered = (params or {}).get("user_request")
    if isinstance(offered, str) and offered.strip() and len(offered) <= 4000:
        offered_digest = hashlib.sha256(offered.encode()).hexdigest()
        handoff_key = PREFIX + "request_handoff_" + request_scope
        intent_owner = (str(Path(root).resolve()), pack, actor_id)
        last_intent = st.session_state.get(HANDOFF_RECEIPT)
        stale_intent = bool(isinstance(last_intent, dict) and last_intent.get("digest") == offered_digest
                            and last_intent.get("owner") != intent_owner)
        if not stale_intent and st.session_state.get(handoff_key) != offered_digest:
            try:
                ai._ingress(offered)
                if not st.session_state[request_key].strip():
                    st.session_state[request_key] = offered
            except ai.Invalid:
                pass
            st.session_state[handoff_key] = offered_digest
            st.session_state[HANDOFF_RECEIPT] = {"digest": offered_digest, "owner": intent_owner}
    question = st.text_area("What should the source assessment investigate?", key=request_key, max_chars=4000,
        placeholder="For example: compare these candidate sources and explain which evidence is missing.",
        help="Your question goes to the existing source specialist when you explicitly assess the evidence.")
    st.session_state[draft_key] = question
    binding = hashlib.sha256(json.dumps({"root": str(Path(root).resolve()), "pack": pack, "actor": actor_id,
        "scope": sorted(allowed_packs or []), "connection": connection, "input_digest": state["input_digest"],
        "local": local_demo, "write": can_write, "agent": can_agent, "route": route,
        "question": question}, sort_keys=True).encode()).hexdigest()
    if st.session_state.get(PREFIX + "feedback_binding") != binding:
        feedback.clear(PREFIX + "feedback")
        st.session_state[PREFIX + "feedback_binding"] = binding
    # Old private runs and editing choices survive a reconnect. A previous
    # connection's run cannot count as a fresh assessment for this connection.
    current = st.session_state.get(PREFIX + "completed")
    record = None
    incoming = (str(Path(root).resolve()), pack, actor_id, tuple(sorted(allowed_packs or [])),
                (params or {}).get("specialist_run"))
    selected = st.session_state.get(PREFIX + "selection")
    if not isinstance(selected, dict) or selected.get("context") != incoming:
        selected = {"context": incoming, "id": incoming[-1] or (current or {}).get("id")}
        st.session_state[PREFIX + "selection"] = selected
    # A review link selects its saved run once. An explicit new assessment must
    # then become the displayed and continued run, even while that link remains
    # in the route parameters on ordinary Streamlit reruns.
    run_id = selected.get("id")
    if run_id:
        try:
            record = _read(arguments, run_id)
        except (ValueError, OSError, KeyError, TypeError):
            st.warning("The saved source assessment is unavailable in this context. Your mapping choices are retained; request a fresh assessment when needed.")
    if record is None:
        feedback.clear(PREFIX + "feedback")
    ready = bool(record and not record.get("stale") and current and current.get("binding") == binding
                 and current.get("id") == record.get("id"))
    st.caption("Assess source evidence sends your question with the current declarations and cleared mapping evidence to the existing source specialist. Mapping choices remain in their reviewed workflow.")
    if record:
        with st.chat_message("assistant"):
            st.write(record["result"]["assembly"]["summary"])
            if record.get("stale"):
                st.warning("This assessment is historical: the source inputs changed. Assess the current evidence before using its recommendations.")
            for finding in record["result"]["critic"].get("findings", []):
                st.write("• " + finding)
            st.caption("Unreviewed evidence assessment. Continue with explicit mapping choices, the staged diff and existing validators.")
        from specialist_workspace_page import feedback_for_record
        feedback_for_record(root, pack, actor_id, record, allowed_packs=allowed_packs,
                            can_write=bool(local_demo and can_write), key=PREFIX + "feedback")
        if st.button("Open the complete source assessment", key=PREFIX + "open"):
            return {"active": True, "navigation": {"route": "specialist_assistant", "params": {"run_id": record["id"]}}}
        if st.button("Review mappings and validate", key=PREFIX + "continue", disabled=bool(record.get("stale"))):
            return {"active": True, "navigation": {"route": "source_mapping", "params": {"specialist_run": record["id"], "show_details": True}}}
    failed = st.session_state.get(PREFIX + "failed") == binding
    if failed:
        st.warning(FAILURE)
    enabled = local_demo is True and can_write is True and can_agent is True
    if not enabled:
        st.caption("You can use the source details. Running a source assessment requires this session's assistant permission.")
    label = "Retry source assessment" if failed else "Assess source evidence"
    if st.button(label, key=PREFIX + "run", disabled=not enabled or ready or st.session_state.get(PREFIX + "pending") == binding):
        st.session_state[PREFIX + "pending"] = binding
        try:
            # Reuse the scoped canonical runner. A stale page is refused before
            # the worker starts, and no model response is applied to an adapter.
            outcome = specialist.run(**arguments, kind="source", question=question,
                expected_input_digest=state["input_digest"], local_demo=local_demo, can_agent=can_agent)
            if (not isinstance(outcome, dict) or outcome.get("ok") is not True
                    or not isinstance(outcome.get("record"), dict)):
                raise ValueError()
            saved = _read(arguments, outcome["record"]["id"])
            if saved.get("stale") or _connection(root) != connection:
                raise ValueError()
            st.session_state[PREFIX + "completed"] = {"id": saved["id"], "binding": binding}
            st.session_state[PREFIX + "selection"] = {"context": incoming, "id": saved["id"]}
            st.session_state.pop(PREFIX + "failed", None)
        except Exception:
            st.session_state[PREFIX + "failed"] = binding
        finally:
            st.session_state.pop(PREFIX + "pending", None)
        _retain_source_inputs()
        st.rerun()
    if ready:
        st.caption("An assessment for these current inputs is already saved. Review it before requesting more model work.")
    return {"active": True, "navigation": None}
