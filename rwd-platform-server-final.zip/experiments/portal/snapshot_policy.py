"""When may the portal serve a governance snapshot the loader did not fully accept?

Exactly one error class is waivable: "describes commit X, the served commit is Y" — and only when
no governed path changed between the two commits, because then the snapshot still describes
reality. Every other error is STRUCTURAL (a schema this reader does not know, no packs, no
provenance, a dirty build tree) and is never waived: a snapshot with `schema: 999` and no packs
was presented as current because no governed path had changed (audit 7). Pure; tested in
platform/tests/test_audit7_20260903.py.
"""
from __future__ import annotations

import re

COMMIT_MISMATCH = re.compile(r"^describes commit [0-9a-f]+, the served commit is [0-9a-f]+$")


def accept(errs: list[str], touched: list[str]) -> tuple[bool, str]:
    """(serve it?, why). `touched` is the governed paths changed since the snapshot's commit."""
    errs = [str(e).strip() for e in (errs or []) if str(e).strip()]
    if not errs:
        return True, "verified against the served commit"
    structural = [e for e in errs if not COMMIT_MISMATCH.match(e)]
    if structural:
        return False, "refused — structural: " + "; ".join(structural[:2])
    if touched:
        return False, (f"refused — stale: {len(touched)} governed path(s) changed since the snapshot's "
                       f"commit (first: {touched[0]})")
    return True, "snapshot's commit is behind HEAD, but later commits touched no governed path — still current for what it describes"
