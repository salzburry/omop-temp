"""Compact study brief and one current question beside the existing chat."""
from __future__ import annotations

import streamlit as st

import conversation_intake as brief_api

HANDOFF_KEY = "_registered_product_study_brief"


def render(root, pack, actor_id, brief, *, allowed_packs, can_write, scope_id="",
           key="study_brief_", ask_question=True):
    """Return {brief, reply, question_token}; the caller sends the one guide call.

    Rendering never saves or calls a model. Buttons save only the actor's private
    draft. A question response is returned for the caller's ordinary chat path.
    """
    prefix = key + brief_api._hash(brief["scope"])[:16] + "_"
    result = {"brief": brief, "reply": None, "question_token": None}
    known_slots = brief_api.slots()

    def save(updated):
        try:
            value = brief_api.save(root, pack, actor_id, updated, allowed_packs=allowed_packs,
                can_write=can_write, expected_revision=brief["revision"], scope_id=scope_id)
            result["brief"] = value
            st.success("Study brief saved. This is your draft input for the conversation.")
            return value
        except (ValueError, OSError, TypeError, KeyError):
            st.warning("The private study brief could not be saved or changed in another session. Reload it before retrying; the form edits remain here.")
            return None

    with st.expander("Study brief · remembered across pages", expanded=False):
        st.caption("Your population, source, index and outcomes stay with this product and study. Inspect or edit this private draft as the conversation develops.")
        if brief.get("notice"):
            st.info(brief["notice"])
        rows = [{"Detail": sid.replace("_", " ").capitalize(), "Your draft": value}
                for sid, value in brief["state"]["request"].items() if value]
        if rows:
            st.dataframe(rows, hide_index=True)
        else:
            st.caption("Describe what you want to study in chat to start your brief.")
        if brief["unknown_slots"]:
            st.caption("Still open: " + ", ".join(sid.replace("_", " ") for sid in brief["unknown_slots"]))
        proposals = brief["proposed_updates"]
        if proposals:
            st.write("**Suggested wording to review**")
            st.caption("The assistant inferred this wording. Choose any details that reflect your intended study.")
            st.dataframe([{"Detail": item["slot"].replace("_", " "), "Current": item["before"],
                           "Suggested": item["value"]} for item in proposals], hide_index=True)
            version = brief_api._hash(proposals)[:16]
            selected = st.multiselect("Wording to use in the brief", [item["slot"] for item in proposals],
                format_func=lambda sid: sid.replace("_", " ").capitalize(), key=prefix + "proposals_" + version,
                disabled=not can_write)
            if st.button("Use selected wording in brief", key=prefix + "accept_" + version,
                         disabled=not can_write or not selected):
                save(brief_api.accept_updates(brief, selected))
        labels = {sid: sid.replace("_", " ").capitalize() for sid in known_slots}
        field = st.selectbox("Edit a brief detail", [None] + list(labels),
            format_func=lambda sid: "Choose a detail" if sid is None else labels[sid], key=prefix + "edit_field")
        if field:
            version = brief_api._hash([brief["revision"], field])[:16]
            value = st.text_area(labels[field], value=brief["state"]["request"].get(field) or "",
                max_chars=brief_api.MAX_VALUE, key=prefix + "value_" + version,
                help=known_slots[field]["ask"])
            if st.button("Save brief detail", key=prefix + "save_" + version, disabled=not can_write):
                try:
                    save(brief_api.edit(brief, {field: value}))
                except ValueError:
                    st.warning("Remove credentials or individual patient details before saving this draft.")
        if st.button("Clear this study brief", key=prefix + "clear", disabled=not can_write or not (rows or proposals or brief["unknown_slots"])):
            save(brief_api.clear(brief))

    if ask_question:
        result.update(render_question(result["brief"], key=key, can_write=can_write))
    return result


def render_question(brief, *, key="study_brief_", can_write=False):
    """Only the current question widgets; safe to position beside the last reply."""
    prefix = key + brief_api._hash(brief["scope"])[:16] + "_"
    result = {"reply": None, "question_token": None}
    question = brief_api.current_question(brief)
    if question:
        token = question["token"]
        options = {option["id"]: option for option in question["options"]}
        positions = {sid: chr(ord("a") + index) for index, sid in enumerate(options)}
        labels = {sid: positions[sid].upper() + " · " + option["label"] for sid, option in options.items()}
        labels["__not_sure"] = "Not sure"
        st.write(question["prompt"])
        choice = None
        if options:
            choice = st.radio("Choose an answer", list(labels), index=None, format_func=labels.get,
                captions=[option["explanation"] for option in options.values()] + ["Keep this choice open and ask for help."],
                key=prefix + "choice_" + token, disabled=not can_write)
        answer = st.text_area("Your answer or another option", max_chars=600,
            key=prefix + "answer_" + token, help="Type your own answer, or 'Not sure' to keep this choice open.")
        if st.button("Send this answer", key=prefix + "send_" + token,
                     disabled=not can_write or not (choice or answer.strip())):
            # Typed wording is an explicit replacement of an offered choice, not
            # an accidental concatenation of two contradictory interpretations.
            result.update(reply=answer.strip() or ("Not sure" if choice == "__not_sure" else positions[choice]), question_token=token)
    return result


def registration_completed(root, target_pack, actor_id, *, allowed_packs, state):
    """Called only by the successful local registration path, before navigation."""
    state.pop(HANDOFF_KEY, None)
    token = brief_api.registration_handoff(root, target_pack, actor_id, allowed_packs=allowed_packs)
    if token:
        state[HANDOFF_KEY] = token
    return token


def render_registration_handoff(root, pack, actor_id, *, allowed_packs, can_write, state=None):
    state = st.session_state if state is None else state
    token = state.get(HANDOFF_KEY)
    if not isinstance(token, dict):
        return None
    # A token is offered only in its destination. Switching identity cannot expose
    # its descriptive text; neither can navigating to another existing product.
    try:
        scope, _ = brief_api._scope(root, pack, actor_id, allowed_packs)
    except (ValueError, OSError):
        return None
    if token.get("target_scope") != scope:
        return None
    try:
        reviewed = brief_api.review_handoff(root, pack, actor_id, token, allowed_packs=allowed_packs)
    except (ValueError, OSError, TypeError, KeyError):
        st.warning("The setup or product brief changed since registration. Your saved wording remains available; this continuation needs a fresh comparison.")
        if st.button("Review the latest brief comparison", key="registered_brief_refresh_" + brief_api._hash(scope)[:16], disabled=not can_write):
            try:
                registration_completed(root, pack, actor_id, allowed_packs=allowed_packs, state=state)
                st.rerun()
            except (ValueError, OSError, TypeError, KeyError):
                st.warning("The latest brief could not be read. Your saved drafts are retained.")
        return None
    with st.container(border=True):
        st.write("**Continue the study you described**")
        st.caption("Review your setup wording before carrying it into this product's private study brief. Scientific review and product configuration use their existing workflow.")
        st.dataframe([{"Detail": item["slot"].replace("_", " ").capitalize(),
                       "Current product brief": item["before"], "From setup brief": item["value"]}
                      for item in reviewed["changes"]], hide_index=True)
        if st.button("Continue with this study brief", key="registered_brief_continue_" + reviewed["digest"][:20], disabled=not can_write):
            try:
                result = brief_api.apply_handoff(root, pack, actor_id, token, allowed_packs=allowed_packs,
                    can_write=can_write, expected_digest=reviewed["digest"])
                state.pop(HANDOFF_KEY, None)
                state["pack_suggested"], state["section_suggested"] = pack, "Flow"
                st.success("Your study wording is now available in this product's chat. Continue with its next workflow step.")
                st.rerun()
                return result
            except (ValueError, OSError, TypeError, KeyError):
                st.warning("The brief changed or could not be saved. Your existing product draft was kept; reload the comparison before continuing.")
    return None
