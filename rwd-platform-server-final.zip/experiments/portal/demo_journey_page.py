"""A scientist-facing rehearsal of the real deterministic draft pipeline."""
from __future__ import annotations

from pathlib import Path

import streamlit as st

import demo_journey as journeys
import demo_revision_page
import demo_build


_DEFAULTS = {
    "demo_journey_kind": "new", "demo_example": "gist", "demo_label": "",
    "demo_purpose": "", "demo_studies": "", "demo_sections": journeys.SECTIONS[:],
    "demo_add_name": "", "demo_add_domain": "outcomes", "demo_add_definition": "",
    "demo_source": "flatiron", "demo_modality": "ehr",
}


def _remember(key):
    st.session_state.setdefault("demo_form_draft", {})[key] = st.session_state.get(key)


def _restore():
    draft = st.session_state.setdefault("demo_form_draft", {})
    for key, default in _DEFAULTS.items():
        if key in st.session_state:
            st.session_state[key] = st.session_state[key]
        else:
            st.session_state[key] = draft.get(key, default)


def _kwargs(key):
    return {"key": key, "on_change": _remember, "args": (key,)}


def assistant_context(card, root, *, actor_id, local_demo, can_write, can_view=True, state_root=None, state=None):
    """Use the visible rehearsal, never the unrelated sidebar product, for chat."""
    import flow_assistant
    state = st.session_state if state is None else state
    expected = (str(Path(root).resolve()), actor_id, bool(local_demo), bool(can_write), str(state_root))
    owned = state.get("demo_context") in (None, expected)
    visible = state if owned and can_view else {}
    form = {"stage": "new", "run_id": None, "revision_number": 0,
            "next_visible_action": "Review rehearsal plan",
            "remaining_work": "Choose an example, name the rehearsal and enter the study question and intended studies, then review the plan here.",
            "execution_scope": "The shipped example's baseline configuration and synthetic specification.",
            "review_boundary": journeys.NOTICE}
    draft = visible.get("demo_form_draft") or {}
    values = {key: visible.get(key, draft.get(key, default)) for key, default in _DEFAULTS.items()}
    example = values["demo_example"]
    if example not in journeys.EXAMPLES:
        example = "gist"
    form.update(example=journeys.EXAMPLES[example]["label"],
                journey=journeys.JOURNEYS.get(values["demo_journey_kind"], ""),
                label=values["demo_label"], purpose=values["demo_purpose"],
                studies=values["demo_studies"].splitlines(), retained_sections=values["demo_sections"],
                proposed_source=values["demo_source"], proposed_modality=values["demo_modality"])
    if values["demo_journey_kind"] != "revise":
        form.update(retained_sections=journeys.SECTIONS[:], proposed_source="flatiron", proposed_modality="ehr")
    else:
        form["removed_sections"] = [section for section in journeys.SECTIONS if section not in values["demo_sections"]]
        form["proposed_additions"] = [{"variable_id": flow_assistant._clean(values["demo_add_name"], 80),
            "domain": values["demo_add_domain"], "definition": flow_assistant._clean(values["demo_add_definition"], 1200)}]
    active = visible.get("demo_active_id")
    if active:
        loaded = journeys.read_run(root, state_root, actor_id, active)
        if loaded["ok"]:
            record = loaded["run"]
            form.update({key: record["plan"].get(key) for key in ("purpose", "studies", "retained_sections",
                "removed_sections", "proposed_source", "proposed_modality", "execution_scope")})
            form.update(stage=record["stage"], run_id=active, revision_number=record.get("revision_number", 0),
                label=record["label"], example=record["example"]["label"], journey=journeys.JOURNEYS[record["journey"]],
                next_visible_action="Run rehearsal",
                remaining_work=record.get("error") or "Review this saved plan, then run its specification and configuration checks here.")
            form["proposed_additions"] = [{key: flow_assistant._clean(row.get(key), 240)
                for key in ("variable_id", "domain", "definition")} for row in record["plan"]["proposed_additions"][:5]]
            if record["stage"] == "complete":
                form["checked_result"] = {key: record["report"].get(key) for key in ("specification_rows", "high_findings",
                    "configuration_check", "draft_contract_check", "synthetic_ads")}
                form.update(next_visible_action="Edit this rehearsal",
                    remaining_work="Review the generated artifacts and QC findings. To change the question, studies or definitions, edit this rehearsal, save a revision and run its checks again.")
            editing = visible.get("demo_revision_editor")
            if isinstance(editing, dict) and editing.get("run_id") == active:
                form.update(stage="editing", label=editing["label"], purpose=editing["purpose"],
                    studies=editing["studies"].splitlines(), retained_sections=editing["sections"],
                    removed_sections=[section for section in journeys.SECTIONS if section not in editing["sections"]],
                    proposed_source=editing["source"], proposed_modality=editing["modality"],
                    next_visible_action="Save revision",
                    remaining_work="Review these unsaved plan and definition edits, save a revised rehearsal, then run that saved revision. The earlier run did not check these edits.")
                form.pop("checked_result", None)
                form["proposed_additions"] = [{key: flow_assistant._clean(row.get(key), 240)
                    for key in ("variable_id", "domain", "definition")} for row in editing["additions"][:5]]
                selected = visible.get("demo_edit_definition_choice")
                if selected in editing.get("definitions", {}):
                    form["selected_draft_interpretation"] = flow_assistant._clean(editing["definitions"][selected], 1200)
        else:
            form = {"stage": "unavailable", "run_id": active,
                    "next_visible_action": "Choose another example",
                    "remaining_work": "The current saved rehearsal cannot be verified. Read its error below; choose another example or restore its unchanged files.",
                    "review_boundary": journeys.NOTICE}
    if not owned or not can_view:
        form = {"stage": "unavailable", "next_visible_action": "Open the example again",
                "remaining_work": "The rehearsal context changed or this identity cannot view it. Reopen an accessible rehearsal before continuing.",
                "review_boundary": journeys.NOTICE}
    elif not local_demo or not can_write:
        form.update(next_visible_action="Review the saved plan",
                    remaining_work="This identity can read its saved rehearsal. A local product author is needed to save revisions or run checks.")
    for key in ("label", "purpose", "proposed_source"):
        if key in form:
            form[key] = flow_assistant._clean(form[key], 1200 if key == "purpose" else 120)
    if "studies" in form:
        form["studies"] = [flow_assistant._clean(value, 120) for value in form["studies"][:30]]
    return {**card, "product": form.get("label") or "Synthetic rehearsal", "page": "Try a workflow",
            "stages": "Synthetic rehearsal · " + form["stage"].replace("_", " "), "checked": "checked_result" in form,
            "current_stage": "Synthetic rehearsal", "next_step": {"title": form["next_visible_action"]},
            "blockers": [], "actions": [], "you_can": ["review the current rehearsal and use its visible controls"],
            "current_task": {"route": "synthetic_rehearsal", "title": "Try a workflow", "purpose": form["remaining_work"]},
            "rehearsal_form": form}


def _issues(result):
    for error in result.get("errors", []):
        st.error(str(error))


def _form(root, state_root, actor_id, allowed):
    _restore()
    st.subheader("1 · Choose an example")
    st.radio("What would you like to try?", list(journeys.JOURNEYS),
             format_func=journeys.JOURNEYS.get, horizontal=True, **_kwargs("demo_journey_kind"))
    available = {item["id"]: item for item in journeys.catalogue(root) if item["available"]}
    if not available:
        st.error("The shipped examples are missing. Ask your administrator to restore the example workbooks.")
        return
    if st.session_state.demo_example not in available:
        st.session_state.demo_example = next(iter(available))
    st.selectbox("Example specification", list(available),
                 format_func=lambda key: available[key]["label"], **_kwargs("demo_example"))
    st.caption(available[st.session_state.demo_example]["note"])
    st.text_input("Rehearsal name", max_chars=120, **_kwargs("demo_label"))
    st.text_area("What study question should this product support?", max_chars=4000,
                 placeholder="For example, treatment sequencing and survival in two related studies.",
                 **_kwargs("demo_purpose"))
    st.text_area("Intended studies (one per line)", max_chars=3000, **_kwargs("demo_studies"))
    if st.session_state.demo_journey_kind == "revise":
        st.multiselect("Sections proposed for the next version", journeys.SECTIONS,
                       format_func=lambda name: name.replace("_", " ").title(), **_kwargs("demo_sections"))
        st.caption("Removing a section proposes its removal. The baseline worker still runs the unchanged example.")
        with st.expander("Propose a new definition", expanded=True):
            st.text_input("New variable identifier", max_chars=80, **_kwargs("demo_add_name"))
            st.selectbox("Section for the new definition", journeys.SECTIONS,
                         format_func=lambda name: name.replace("_", " ").title(), **_kwargs("demo_add_domain"))
            st.text_area("Proposed definition", max_chars=4000, **_kwargs("demo_add_definition"))
        cols = st.columns(2)
        with cols[0]:
            st.text_input("Proposed data source", max_chars=120, **_kwargs("demo_source"))
        with cols[1]:
            st.selectbox("Proposed source type", ["ehr", "claims"], format_func=str.upper,
                         **_kwargs("demo_modality"))
    if st.button("Review rehearsal plan", key="demo_prepare", type="primary", disabled=not allowed):
        revision = st.session_state.demo_journey_kind == "revise"
        additions = []
        if revision and (st.session_state.demo_add_name.strip() or st.session_state.demo_add_definition.strip()):
            additions = [{"variable_id": st.session_state.demo_add_name,
                          "domain": st.session_state.demo_add_domain,
                          "definition": st.session_state.demo_add_definition}]
        result = journeys.prepare(
            root, state_root, actor_id, journey=st.session_state.demo_journey_kind,
            example_id=st.session_state.demo_example, label=st.session_state.demo_label,
            purpose=st.session_state.demo_purpose,
            studies=[line.strip() for line in st.session_state.demo_studies.splitlines() if line.strip()],
            sections=st.session_state.demo_sections if revision else journeys.SECTIONS,
            additions=additions, proposed_source=st.session_state.demo_source if revision else "flatiron",
            proposed_modality=st.session_state.demo_modality if revision else "ehr",
            local_demo=allowed, can_write=allowed)
        if result["ok"]:
            st.session_state.demo_active_id = result["run"]["id"]
            st.rerun()
        _issues(result)


def _plan(record):
    plan = record["plan"]
    st.subheader("2 · Review the plan")
    st.text(record["label"])
    st.write(journeys.JOURNEYS[record["journey"]] + " · " + record["example"]["label"])
    if record.get("revision_of"):
        st.caption(f"Saved revision {record['revision_number']} · previous run {record['revision_of'][:8]} remains available")
    st.text(plan["purpose"])
    if plan.get("studies"):
        st.caption("Intended studies: " + "; ".join(plan["studies"]))
    if record["journey"] == "new" and not record.get("revision_of"):
        st.info("This starts an empty definition draft from the example workbook. Its baseline configuration is copied only to exercise the real checks.")
    elif record["journey"] == "template":
        st.info("This reuses the example configuration and any existing draft definitions. Their prior approvals are not carried forward.")
    if record["journey"] == "revise" or record.get("revision_of"):
        rows = [{"Change": "Keep sections", "Proposal": ", ".join(plan["retained_sections"]) or "None"},
                {"Change": "Remove sections", "Proposal": ", ".join(plan["removed_sections"]) or "None"},
                {"Change": "Proposed source", "Proposal": f"{plan['proposed_source']} ({plan['proposed_modality'].upper()})"}]
        st.dataframe(rows, hide_index=True, width="stretch")
        if plan.get("proposed_additions"):
            st.dataframe(plan["proposed_additions"], hide_index=True, width="stretch")
        checked = plan.get("definition_review") or {}
        shared_change_requested = bool(plan.get("proposed_additions") or plan.get("removed_sections") or checked.get("source_changed"))
        if checked.get("errors") and shared_change_requested:
            st.warning("The change proposal has unresolved issues. You can still rehearse the baseline; the proposal cannot be treated as ready to implement.")
            for error in checked["errors"]:
                st.write("• " + str(error))
        if checked.get("source_changed"):
            st.warning("A source change needs new mapping, cohort and outcome validation. Baseline results do not validate the proposed source.")
    if record.get("revision_of"):
        if plan.get("definition_changes"):
            st.write("**Draft definition changes in this revision**")
            st.dataframe([{"Variable": row["variable_id"], "Before": row["before"], "Your revised interpretation": row["after"]}
                          for row in plan["definition_changes"]], hide_index=True, width="stretch")
        if plan.get("engineering_handoff"):
            st.write("**Engineering handoff**")
            st.caption("These proposals still need implementation and validation in a governed product.")
            for handoff in plan["engineering_handoff"]:
                variable = str(handoff.get("variable_id") or "")
                st.write((variable + ": " if variable else "") + str(handoff["detail"]))
        st.caption("Execution scope: " + plan["execution_scope"])
    else:
        st.caption("Execution scope: extract the baseline workbook, generate draft review artifacts and check the example configuration. Proposed changes are recorded for review and are not applied to the execution.")


def _results(record):
    report = record["report"]
    st.success("Draft rehearsal complete")
    st.write(f"Extracted {report['specification_rows']} specification rows and generated {report['artifact_count']} review artifacts. The example configuration check passed.")
    if report["high_findings"]:
        st.warning(f"{report['high_findings']} high-priority QC findings still need review. Completion means the draft artifacts were generated; it does not mean the specification is approved.")
    if report.get("findings"):
        st.dataframe(report["findings"], hide_index=True, width="stretch")
    if report.get("synthetic_ads") == "built":
        st.info("The optional ADS worker also completed using synthetic inputs. This is not validation against delivered patient data.")
        summary = report.get("build_summary", {})
        counts = st.columns(2)
        counts[0].metric("Synthetic rows", summary.get("rows", "Unknown"))
        counts[1].metric("Output columns", summary.get("columns", "Unknown"))
        st.caption("Built from the saved example configuration. Proposed changes still need implementation and review.")
        sample_cols, sample = summary.get("sample_cols"), summary.get("sample")
        if isinstance(sample_cols, list) and isinstance(sample, list) and sample:
            st.dataframe([dict(zip(sample_cols, row)) for row in sample[:8] if isinstance(row, list)],
                         hide_index=True, width="stretch")
        with st.expander("Synthetic build summary"):
            st.json(summary)
    else:
        if any(attempt.get("status") == "complete" for attempt in record.get("build_attempts", [])):
            st.caption("An earlier synthetic ADS build is retained in the run history. No current ADS result is attached to these rerun checks; use Build synthetic ADS to check it again.")
        else:
            st.caption("No patient-level ADS was built in this rehearsal.")
    if report.get("draft_contract_check"):
        if report["draft_contract_check"] == "passed":
            st.info("The revised draft definition check passed. Scientific review and executable implementation remain separate steps.")
        else:
            st.warning("The revised draft definitions still need attention. Review the findings below and edit the rehearsal to refine the draft.")
        findings = report.get("draft_contract_findings") or ""
        if findings:
            st.code(findings if isinstance(findings, str) else "\n".join(str(error) for error in findings), language=None)
    with st.expander("What happens next?"):
        st.write("Use Edit this rehearsal above to revise the plan or draft definitions here, then save a revision and rerun the checks. "
                 "Review the findings with the study team. Accepted executable changes continue through a governed product's scientific, source and build reviews.")
        checked = record["plan"].get("definition_review") or {}
        for line in checked.get("review_checklist", []):
            st.write("• " + line)


def render(root, *, actor_id, local_demo, can_write, can_view=True, state_root=None):
    """Render only synthetic example work; all mutation boundaries recheck access."""
    st.subheader("Try a workflow")
    st.caption("Synthetic examples · saved drafts · no terminal steps")
    if not can_view:
        st.info("Your current role cannot open rehearsals.")
        return
    context = (str(Path(root).resolve()), actor_id, bool(local_demo), bool(can_write), str(state_root))
    changed = "demo_context" in st.session_state and st.session_state.demo_context != context
    if changed:
        for key in list(st.session_state):
            if key.startswith("demo_"):
                del st.session_state[key]
    st.session_state.demo_context = context
    allowed = bool(local_demo and can_write and not changed)
    if not local_demo or not can_write:
        st.info("A product author can run these examples in local demo mode. Your saved results remain readable.")
    elif changed:
        st.info("The rehearsal context changed. Open the example again before continuing.")
    st.caption(journeys.NOTICE)
    runs = journeys.list_runs(root, state_root, actor_id)
    if runs:
        by_id = {item["id"]: item for item in runs}
        if st.session_state.get("demo_saved_choice") not in by_id:
            st.session_state.demo_saved_choice = next(iter(by_id))
        with st.expander("Resume a saved rehearsal"):
            choice = st.selectbox("Your rehearsals", list(by_id),
                                  format_func=lambda identifier: f"{by_id[identifier]['label']} · " +
                                      (f"revision {by_id[identifier]['revision_number']} · " if by_id[identifier].get("revision_of") else "") +
                                      by_id[identifier]['stage'].replace('_', ' '),
                                  key="demo_saved_choice")
            if st.button("Open rehearsal", key="demo_resume"):
                st.session_state.demo_active_id = choice
                st.rerun()
    active = st.session_state.get("demo_active_id")
    if not active:
        _form(root, state_root, actor_id, allowed)
        return
    result = journeys.read_run(root, state_root, actor_id, active)
    if not result["ok"]:
        _issues(result)
        if st.button("Choose another example", key="demo_restart"):
            st.session_state.pop("demo_active_id", None)
            st.rerun()
        return
    record = result["run"]
    if st.session_state.get("demo_revision_notice"):
        st.success(st.session_state.pop("demo_revision_notice"))
    _plan(record)
    if demo_revision_page.render(root, state_root, actor_id, record, allowed=allowed,
                                 local_demo=local_demo, can_write=can_write):
        return
    st.subheader("3 · Run and view results")
    if record["stage"] == "complete":
        _results(record)
        if record["report"].get("synthetic_ads") != "built":
            st.markdown("**Next: see a synthetic ADS**")
            st.write("Build a demonstration dataset here using the saved example configuration. "
                     "Proposed section, definition and source changes stay in your review plan; "
                     "this build shows the baseline example, not those proposed changes.")
            available = journeys.runtime()
            if not available["build_available"]:
                st.info(available["build_reason"])
            if st.button("Build synthetic ADS from this example", key="demo_build_saved",
                         type="primary", disabled=not allowed or not available["build_available"]):
                with st.spinner("Building the synthetic ADS. This can take several minutes; keep this page open…"):
                    built = demo_build.build(root, state_root, actor_id, active,
                        local_demo=local_demo, can_write=can_write)
                if built.get("ok"):
                    st.rerun()
                _issues(built)
                record = built.get("run") or record
        for attempt in record.get("build_attempts", [])[-1:]:
            if attempt.get("status") == "needs_attention":
                st.warning(attempt.get("error", "The optional build needs attention. Your draft checks are retained."))
            with st.expander("Synthetic build details"):
                st.write("Build status: " + attempt.get("status", "unknown").replace("_", " "))
                st.code(attempt.get("output", ""), language="text")
    else:
        if record.get("error"):
            st.error(record["error"])
        dependencies = journeys.runtime()
        include_build = False
        if dependencies["build_available"]:
            include_build = st.checkbox("Also build an ADS from synthetic inputs", key="demo_include_build")
        else:
            st.caption(dependencies["build_reason"])
        if st.button("Run rehearsal", key="demo_run", type="primary", disabled=not allowed):
            with st.spinner("Extracting the example specification and checking its configuration…"):
                outcome = journeys.execute(root, state_root, actor_id, active, local_demo=local_demo,
                                           can_write=can_write, include_build=include_build)
            if outcome.get("ok"):
                st.rerun()
            _issues(outcome)
            record = outcome.get("run") or record
    if record.get("steps"):
        with st.expander("Run details"):
            for step in record["steps"]:
                st.write(step["title"] + (" · completed" if step["exit_code"] == 0 else " · needs attention"))
                st.code(step["output"], language="text")
    try:
        st.download_button("Download rehearsal packet", journeys.bundle(root, state_root, actor_id, active),
                           file_name=f"synthetic-rehearsal-{active[:8]}.zip", mime="application/zip", key="demo_download")
    except (OSError, ValueError, TypeError, KeyError):
        st.warning("The packet could not be opened. The saved plan remains available; ask your administrator to check its files.")
    if st.button("Start another rehearsal", key="demo_restart"):
        st.session_state.pop("demo_active_id", None)
        st.rerun()
