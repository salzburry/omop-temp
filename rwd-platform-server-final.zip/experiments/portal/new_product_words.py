"""The stand-up tool's report, in a person's words.

WHY. The New product page showed the tool's refusal lines beside the form as they are printed:
flags, file paths, the words a validator uses (walk NC-15, 2026-09-07), and after a next-cut
preview it named files where the person asked which variables changed (NC-07). The tool keeps
its own text; this turns the lines a scientist reads into sentences, and leaves the tool's
report for the details. Pure functions over text; no Streamlit here.
"""
from __future__ import annotations

import re

# (pattern over one refusal line, the sentence) in the order they are tried; a sentence of None
# means the tool's line is already a sentence and is shown as it is. Groups fill {1}, {2}.
PATTERNS = (
    (r"^(\w+) is already an alias of (\w+)", "The product identifier {1} belongs to tumour {2}. Choose that tumour family, or give this product a different identifier."),
    (r"^(\w+) is already in governance/tumour_registry.yaml", "The identifier {1} is already a known tumour alias. Choose the existing-tumour starting point and its matching tumour family, or use a different identifier."),
    (r"non.oncology", "These disease terms describe a condition outside the supported oncology workflow. Keep an unfinished setup and request engineering support; do not relabel the disease to pass the checks."),
    # THE SAME BYTES, IN A PERSON'S WORDS (walk RW4-N07, 2026-09-07): the tool's line names a flag, a path
    # and a document section; the page names the cut the file is registered for, read off that path
    (r"byte-identical to (?:\S*/)?([^/\s]+)/prog_spec/",
     "This workbook is the same file already registered for cut {1}. A next cut needs a revised specification; "
     "a data refresh with the same specification is not a new cut."),
    (r"byte-identical",
     "This workbook is the same file already registered for the previous cut. A next cut needs a revised "
     "specification; a data refresh with the same specification is not a new cut."),
    # WHAT COTA DELIVERS (walk UC4-47): the tool cites the registry test that holds the rule; the page says the rule
    (r"vendor 'cota' delivers haematological",
     "Cota delivers blood-cancer (haematological) products only, so a solid-tumour product cannot name Cota as "
     "its vendor. Choose a vendor that delivers solid-tumour data."),
    (r"^The two workbooks contain the same rows", None),
    (r"^This revision .*: that is breaking\.", None),
    (r"^Review the sheet mapping for the ", None),
    (r"^The specification comparison could not be completed:", None),
    (r"^This checkout's folder path is too long", None),
    (r"^The checkout could not be written", None),
    (r"classified-date .*(?:ISO date|must be written as|is not set)", "The date must be written as YYYY-MM-DD, for example 2026-09-07."),
    (r"classified-date .*not a real calendar date", "The date is not a real calendar date. Write the day you made this call as YYYY-MM-DD."),
    (r"classified-date .*future", "The date is in the future. Write the day you made this call."),
    (r"spec-version (\d{6}) is not later than (\d{6})",
     "The specification cut {1} is not later than the previous cut's, {2}. A next cut is a later month."),
    (r"spec-version .*month", "The specification cut names a month that does not exist. Write YYYYMM, for example 202610."),
    (r"spec-version .*YYYYMM", "The specification cut is written as YYYYMM, the year and the month, for example 202610."),
    (r"slug '([^']*)' is not the product .* belongs to \('([^']*)'\)",
     "The slug {1} names another product. A next cut keeps the previous cut's slug, {2}."),
    (r"slug '([^']*)' is not \[a-z\]", "The slug {1} must use lower-case letters, digits and underscores only, and start with a letter."),
    (r"slug '([^']*)' is already registered", "The slug {1} is already a registered product. Choose another slug, or revise that product as a next cut."),
    (r"(products/\S+) already exists", "A pack for that cut already exists ({1}). Choose a later month."),
    (r"classified-by .*placeholder", "Classified by must be your name; a placeholder is not a person."),
    (r"classified-by", "Classified by must be a person's name, not a team, a role or an address."),
    (r"change-note .* is a placeholder", "The changelog line must say what changed; a placeholder is not a note."),
    (r"workbook \S+ is not a file", "The workbook could not be found on this machine. Upload it, or pick one from the list."),
    (r"workbook must be an \.xlsx", "The workbook must be an Excel workbook (.xlsx)."),
    (r"workbook is required", "A next cut needs the revised workbook. Upload it, or pick one from the list."),
    (r"change-class breaking\|additive is required", "Say what the revision does to existing values: breaking or additive."),
    (r"The staged plan failed: (.*)", "The checks refused the plan at this step: {1}. Nothing was written; the details below say why."),
)
REFUSAL_LINE = re.compile(r"^\s{2}- (.*\S)\s*$")
STAGED_FAILURE = re.compile(r"The staged plan failed: (.*\S)\s*$")
# the header line carries the reason itself when the write, not a check, refused
REFUSAL_HEAD = re.compile(r"^REFUSED\b.*?nothing was written\.\s*(.*\S)?\s*$")
DELTA_HEAD = "what the revised workbook changes"
OPERATIONAL_FAILURE = ("A setup check stopped unexpectedly. Your form entries are retained. "
                       "Ask chat to review the error and current product state, then use the recovery controls below.")
CHANGED_SETUP_INPUTS = ("The checkout or selected workbook changed while the staged product was being validated. "
                        "Review the current files, then preview and write again.")


def is_operational_failure(text: str) -> bool:
    """A Python stack is one failed operation, never a list of form corrections.

    Staged tools can indent a traceback or wrap each line as a refusal bullet.
    Their bounded tail can omit the traceback header; in that case require both
    a real stack-frame line and an exception footer inside a refusal report.
    """
    lines = [re.sub(r"^\s*-\s?", "", line).strip() for line in str(text or "").splitlines()]
    frame = any(re.fullmatch(r'File "[^"]+", line \d+(?:, in .+)?', line) for line in lines)
    header = "Traceback (most recent call last):" in lines
    footer = any(re.match(r"^(?:[A-Za-z_]\w*\.)*(?:(?:[A-Za-z_]\w*)?(?:Error|Exception)|SystemExit|KeyboardInterrupt)(?::|$)", line)
                 for line in lines)
    refused = any(line.startswith("REFUSED") or STAGED_FAILURE.search(line) for line in lines)
    return frame and (header or refused and footer)


def refusal_lines(text: str) -> list[str]:
    """The tool's own reasons, one per line, as it printed them."""
    lines = []
    for line in str(text or "").splitlines():
        m = REFUSAL_LINE.match(line)
        if m:
            lines.append(m.group(1))
            continue
        m = STAGED_FAILURE.search(line)
        if m:
            lines.append("The staged plan failed: " + m.group(1))
            continue
        m = REFUSAL_HEAD.match(line)
        if m and m.group(1) and not m.group(1).endswith("problem(s):"):
            lines.append(m.group(1))
    return lines


def _sentence(line: str) -> str | None:
    for pattern, sentence in PATTERNS:
        m = re.search(pattern, line)
        if m:
            if sentence is None:
                return line
            out = sentence
            for i, group in enumerate(m.groups(), start=1):
                out = out.replace("{" + str(i) + "}", str(group or ""))
            return out
    return None


def family_collision(text: str) -> tuple[str, set[str]]:
    """Recognize the tool's exact same-family refusal, not a suggested family in prose."""
    lines = refusal_lines(text)
    families = set()
    evidence = set()
    for line in lines:
        match = re.fullmatch(
            r"([a-z][a-z0-9_]*) is the tumour family itself — choose a distinct product slug with --tumour-family \1",
            line,
        ) or re.fullmatch(
            r"([a-z][a-z0-9_]*) is the tumour family itself \(governance/tumour_registry\.yaml\) — "
            r"a product OF the \1 tumour needs its own slug \(for example \1_flatiron\) with --tumour-family \1",
            line,
        )
        if match:
            families.add(match.group(1))
            evidence.add(line)
    if len(families) != 1:
        return "", set()
    family = next(iter(families))
    related = {f"{family} already has a row in the oncology catalogue",
               f"{family} already has an inventory overlay", f"indication:{family} module already exists"}
    return family, evidence | (related & set(lines))


def family_collision_sentence(family: str) -> str:
    return (f"{family} already identifies a tumour in this catalogue. Keep that existing tumour family "
            "and give your data product its own identifier; its product name, specification and other entries can stay as entered.")


def refusal_sentences(text: str) -> tuple[list[str], int]:
    """(sentences a person reads, how many of the tool's lines have no sentence yet). The tool's
    lines stay under the details; nothing here invents a reason the tool did not give."""
    if is_operational_failure(text):
        return [OPERATIONAL_FAILURE], 0
    family, related = family_collision(text)
    sentences, untranslated = ([family_collision_sentence(family)] if family else []), 0
    for line in refusal_lines(text):
        if line in related:
            continue
        s = _sentence(line)
        if s is None:
            untranslated += 1
        elif s not in sentences:
            sentences.append(s)
    return sentences, untranslated


def delta_sentences(stdout: str) -> list[str]:
    """The specification delta the tool prints above its plan for a next cut, line by line."""
    out, inside = [], False
    for line in str(stdout or "").splitlines():
        if line.startswith(DELTA_HEAD):
            inside = True
            continue
        if inside:
            if not line.startswith("  ") or line.startswith("PLAN for"):
                break
            out.append(line.strip())
    return out
