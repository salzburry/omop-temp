"""Capture explicit human answers to issued forms and transcribe a validated batch.

No approvals are authenticated here. The result remains working-tree evidence.
Writes use a lock, optimistic input checks, staged replacements and rollback on a
caught failure. This is not a filesystem-wide crash-atomic transaction.
"""
from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path
import re
import tempfile
import time

import yaml

import contract_lint as cl
import decision_record as dr

FIELDS = ("answer", "answered_by", "answer_date")
NOTICE = ("Saving records the reviewed answer and typed ledger evidence. The named reviewer must still "
          "authenticate the resulting record. Saving does not approve the contract or release.")
MAX_BYTES = 2 * 1024 * 1024
UNRESOLVED_ANSWER = re.compile(r"\b(?:TODO|TBD|FIXME|REPLACE_ME)\b|\bnot\s+sure\s+yet\b|^\s*not\s+sure\b", re.I)

# RAISING A QUESTION (2026-09-07, decision loop audit DL-03). The register is the table the Questions
# page reads, and there was no way to add a row to it from the portal. One row, always OPEN, with no
# answer, no name and no date: the owner is a role the register already uses, never a person.
RAISE_FIELDS = ("id", "question", "evidence", "owner")
DECISION_ID = re.compile(r"[A-Z][A-Z0-9-]+")
BLANK_CELL = "—"          # the register's own mark for "nothing here yet" (decision_record._blankish)
LOCK_NAME = "handoff/.decision-answers.portal.lock"
# A LEFTOVER LOCK (DL-06). A save that died mid-way leaves its lock file, and every later save then
# failed with the raw operating-system text and an absolute path. The message now says what it means,
# and a lock older than this may be cleared by the person, one file, nothing else.
LOCK_STALE_SECONDS = 10 * 60
LOCK_MESSAGE = "Another save is in progress. Wait for it to finish, then reload the questions."
STALE_LOCK_MESSAGE = ("Another save is in progress, or an earlier save stopped and left its lock behind more than "
                      "10 minutes ago. If nobody else is saving, clear the stale lock and try again.")


def unresolved_answer(value):
    """A guided or AI draft with open placeholders is not a recorded ruling."""
    return bool(UNRESOLVED_ANSWER.search(str(value or "")))


# PLAIN SENTENCES FROM THE TOOL'S REFUSALS (DL-07). decision_record speaks to a person at a terminal:
# it names the form's absolute path, including a temporary directory this editor created, and tells
# them to re-issue with a command-line flag. The refusal's words are kept; the paths and flags are not.
_DRIVE_PATH = re.compile(r"[A-Za-z]:[\\/][^\s|'\"`]*")
_POSIX_PATH = re.compile(r"(?<![\w.])/(?:[\w.-]+/)+[\w.-]*")
_FORM_FILE = re.compile(r"(?:^|(?<=\s))(?:[\w.-]*[\\/])*[\w-]+\.ya?ml:\s*")
_REISSUE = re.compile(r"re-issue(?: it| the form| with)?\s*\(?--forms\)?", re.I)


def plain(message, hide=()):
    """One refusal from decision_record, with paths and command-line flags removed."""
    text = str(message)
    for prefix in hide:
        prefix = str(prefix or "")
        if prefix:
            text = text.replace(prefix, "").replace(prefix.replace("\\", "/"), "")
    text = _DRIVE_PATH.sub("", text)
    text = _POSIX_PATH.sub("", text)
    text = _FORM_FILE.sub("", text)
    text = _REISSUE.sub("prepare the question drafts again", text)
    text = text.replace("--forms", "Prepare question drafts again").replace("--apply", "Save this answer")
    # the date rule in the person's words (walk UC1-21, 2026-09-07): "is not an ISO date (YYYY-MM-DD)"
    text = re.sub(r"is not an ISO date \(YYYY-MM-DD\)", "must be written as YYYY-MM-DD, for example 2026-09-07", text)
    text = text.replace("answer_date", "the decision date").replace("answered_by", "the decision maker's name")
    text = text.replace(" — ", "; ").replace("—", "").replace("->", "to").replace("`", "")
    text = re.sub(r"\s+", " ", text).strip(" ;:")
    return text


def _lock_age(lock_path):
    try:
        return time.time() - Path(lock_path).stat().st_mtime
    except OSError:
        return None


def _lock_result(lock_path):
    age = _lock_age(lock_path)
    stale = age is not None and age > LOCK_STALE_SECONDS
    return {**_fail(STALE_LOCK_MESSAGE if stale else LOCK_MESSAGE), "stale_lock": stale}


def clear_stale_lock(root, pack, *, local_demo, can_write, allowed_packs=None):
    """Remove this page's lock file, only when it is older than ten minutes; nothing else is touched."""
    if local_demo is not True or can_write is not True:
        return _fail("Clearing a stale lock requires product-author access in a local demo.")
    try:
        _root, _pack, product = _paths(root, pack, allowed_packs)
        lock_path = product / LOCK_NAME
        if lock_path.is_symlink() or (lock_path.exists() and not lock_path.is_file()):
            raise Invalid("The lock redirects to another location. Ask your data expert to remove it.")
        if not lock_path.exists():
            return {"ok": True, "changed": False, "cleared": False, "errors": [], "notice": NOTICE}
        age = _lock_age(lock_path)
        if age is None or age <= LOCK_STALE_SECONDS:
            return _fail("The lock is recent, so another save may still be running. Wait 10 minutes, then try again.")
        lock_path.unlink()
        return {"ok": True, "changed": True, "cleared": True, "errors": [], "notice": NOTICE}
    except (Invalid, OSError, ValueError, TypeError) as error:
        return _fail(str(error) if isinstance(error, Invalid) else "The stale lock could not be cleared. Ask your data expert to remove it.")


class Invalid(ValueError):
    pass


class StrictLoader(yaml.SafeLoader):
    def construct_mapping(self, node, deep=False):
        keys = []
        for key, _value in node.value:
            if not isinstance(key, yaml.ScalarNode) or key.tag != "tag:yaml.org,2002:str" or key.value in keys:
                raise Invalid("The answer form needs unique text field names. Ask your data expert to repair it.")
            keys.append(key.value)
        return super().construct_mapping(node, deep=deep)


def _fail(message):
    return {"ok": False, "changed": False, "errors": [str(message)], "items": [], "digest": "", "notice": NOTICE}


def _paths(root, pack, allowed_packs):
    root = Path(root).resolve()
    pack = str(pack or "").replace("\\", "/")
    if not re.fullmatch(r"(?:products|fixtures)/[A-Za-z0-9_-]+/[A-Za-z0-9_-]+/\d{6}", pack):
        raise Invalid("Choose a registered product or reference pack before answering decisions.")
    if allowed_packs is not None and pack.casefold() not in {str(p).replace("\\", "/").strip("/").casefold() for p in allowed_packs}:
        raise Invalid("This product is outside your access.")
    product = root / pack
    if product.resolve() != product or not product.is_dir():
        raise Invalid("The product location is unavailable or redirects to another location.")
    for path in (product / "handoff", product / dr.FORMS_DIR):
        if path.resolve() != path:
            raise Invalid("The decision folder redirects to another location. Ask your data expert to repair it.")
    return root, pack, product


def _read(path):
    if path.resolve() != path:
        raise Invalid("A decision file redirects to another location. Ask your data expert to repair it.")
    with path.open("rb") as handle:
        raw = handle.read(MAX_BYTES + 1)
    if len(raw) > MAX_BYTES:
        raise Invalid("A decision file is too large for this editor.")
    raw.decode("utf-8")
    return raw


def _parse(raw):
    text = raw.decode("utf-8")
    if any(isinstance(t, (yaml.AliasToken, yaml.AnchorToken)) for t in yaml.scan(text)):
        raise Invalid("Answer forms with YAML aliases need a data expert's review.")
    doc = yaml.load(text, Loader=StrictLoader)
    if not isinstance(doc, dict):
        raise Invalid("The answer form must be a YAML mapping.")
    return doc


def _snapshot(root, pack, allowed_packs):
    root, pack, product = _paths(root, pack, allowed_packs)
    register, contract = product / dr.DECISIONS, product / "handoff/FUNCTIONAL_CONTRACT.md"
    if not register.is_file() or not contract.is_file():
        raise Invalid("Prepare the scientific contract and decision register before answering questions.")
    raw = {register: _read(register), contract: _read(contract)}
    text = raw[register].decode("utf-8")
    errors = cl.decision_register_errors(text, pack)
    if errors:
        raise Invalid("The decision register needs repair before answers can be saved: " + " ".join(errors))
    paths = sorted((product / dr.FORMS_DIR).glob("*.yaml"))
    if len(paths) > 500:
        raise Invalid("This decision batch exceeds the editor's 500-form limit.")
    forms, items = {}, []
    rows, statuses = cl.decision_rows(text), cl.decision_status(text)
    for path in paths:
        raw[path] = _read(path)
        doc = _parse(raw[path])
        did = path.stem
        if not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9_-]{0,100}", did):
            raise Invalid("An issued answer form has an unsafe decision identifier.")
        forms[did] = (path, doc)
        status = statuses.get(did, "MISSING")
        # Validate the issued basis without fabricating human input. Blank response
        # errors are expected in a new form; every other guard must already pass.
        errors = dr.form_errors(doc, str(path), rows, statuses,
                               records_sha={did: dr.citing_records_sha256(pack, did, str(root))},
                               expected_pack=pack, root=str(root))
        basis_errors = [plain(e, hide=(str(root),)) for e in errors if not any(f"`{f}` is blank or a placeholder" in e for f in FIELDS)]
        if doc.get("equivalence"):
            basis_errors.append("This form contains a structured equivalence ruling; use its specialist review workflow.")
        if str(doc.get("status") or "").upper() != "RESOLVED":
            basis_errors.append("This form withdraws or supersedes a question; use the existing decision revision workflow.")
        items.append({"id": did, "question": str(doc.get("question") or ""), "evidence": str(doc.get("evidence") or ""),
                      "status": status, "values": {f: str(doc.get(f) or "") for f in FIELDS},
                      "editable": status == "OPEN" and not basis_errors, "errors": basis_errors,
                      "question_digest": str(doc.get("question_sha256") or ""),
                      "form_digest": hashlib.sha256(raw[path]).hexdigest()})
    digest = hashlib.sha256(json.dumps({p.relative_to(root).as_posix(): hashlib.sha256(b).hexdigest() for p, b in raw.items()}, sort_keys=True).encode()).hexdigest()
    return root, pack, product, raw, forms, items, digest


def describe(root, pack, allowed_packs=None):
    try:
        _root, pack, product, raw, forms, items, digest = _snapshot(root, pack, allowed_packs)
        text = raw[product / dr.DECISIONS].decode("utf-8")
        states = cl.decision_status(text)
        unissued = sorted(did for did, status in states.items() if status == "OPEN" and did not in forms)
        pending, completion_problems = [], []
        for item in items:
            if item["status"] != "RESOLVED":
                continue
            doc = forms[item["id"]][1]
            event, why = dr.sealed_decision_event(str(_root), doc)
            if not event:
                pending.append(item["id"])
            if why:
                completion_problems.append(plain(item["id"] + ": " + why, hide=(str(_root),)))
        report = product / "handoff/SCIENCE_QUESTIONS.md"
        try:
            report_current = report.is_file() and _read(report).decode("utf-8") == dr.question_report_text(pack, str(_root))
        except (Invalid, OSError, ValueError, UnicodeError):
            report_current = False
        return {"ok": True, "pack": pack, "items": items, "unissued_ids": unissued, "digest": digest, "errors": [],
                "completion_pending_ids": pending, "report_current": report_current,
                "completion_problems": completion_problems,
                "owners": register_owners(text), "notice": NOTICE}
    except (Invalid, OSError, ValueError, TypeError, UnicodeError, yaml.YAMLError, RecursionError, KeyError) as error:
        return _fail(str(error) if isinstance(error, Invalid) else "The issued questions could not be read safely. Ask your data expert to repair the form files.")


def prepare_forms(root, pack, *, expected_digest, local_demo, can_write, allowed_packs=None):
    """Stage canonical blank forms, then publish missing files without replacing any.

    Preparation does not answer a question or change the decision register.
    Caught failures roll back only files this call created and still owns.
    """
    if local_demo is not True or can_write is not True:
        return _fail("Preparing question drafts requires product-author access in a local demo.")
    lock_fd, lock_path = None, None
    created = []
    try:
        root, pack, product = _paths(root, pack, allowed_packs)
        lock_path = product / LOCK_NAME
        try:
            lock_fd = os.open(lock_path, os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o600)
        except FileExistsError:
            return _lock_result(lock_path)
        _, _, _, raw, forms, _, digest = _snapshot(root, pack, allowed_packs)
        if digest != expected_digest:
            raise Invalid("The questions or contract changed. Reload them before preparing question drafts.")
        ids = cl.decision_rows(raw[product / dr.DECISIONS].decode("utf-8"))
        if len(ids) > 500 or any(not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9_-]{0,100}", did) for did in ids):
            raise Invalid("Repair the question identifiers or reduce this batch before preparing drafts.")
        with tempfile.TemporaryDirectory(prefix="portal-question-forms-") as directory:
            written, _, error = dr.write_forms(pack, root=str(root), out_dir=directory)
            if error:
                raise Invalid("Question drafts cannot be prepared: " + str(error))
            staged = {Path(path).name: _read(Path(path)) for path in written if Path(path).stem not in forms}
        if _snapshot(root, pack, allowed_packs)[-1] != digest:
            raise Invalid("The question inputs changed during preparation. Reload before trying again.")
        folder = product / dr.FORMS_DIR
        if staged:
            folder.mkdir(exist_ok=True)
        for name, body in staged.items():
            target = folder / name
            if target.resolve() != target or folder.resolve() != folder:
                raise Invalid("The question folder changed location. Reload before trying again.")
            temporary = None
            try:
                with tempfile.NamedTemporaryFile(mode="wb", prefix=".question-", suffix=".tmp", dir=folder, delete=False) as handle:
                    temporary = Path(handle.name)
                    handle.write(body)
                    handle.flush()
                    os.fsync(handle.fileno())
                # A hard link publishes complete bytes atomically and refuses an
                # existing target, including one another editor just created.
                os.link(temporary, target)
                created.append((target, body))
            finally:
                if temporary is not None:
                    temporary.unlink(missing_ok=True)
        if any(_read(path) != body for path, body in raw.items()):
            raise Invalid("The questions, contract or an existing answer changed during preparation. Reload before trying again.")
        result = describe(root, pack, allowed_packs)
        if not result["ok"]:
            raise Invalid("The prepared question drafts could not be checked. Reload the question files.")
        return {**result, "changed": bool(created), "prepared": [path.stem for path, _ in created]}
    except (Invalid, OSError, ValueError, TypeError, UnicodeError, yaml.YAMLError, RecursionError, KeyError) as error:
        retained = []
        for target, body in reversed(created):
            try:
                if _read(target) != body:
                    retained.append(target.name)
                else:
                    target.unlink()
            except (OSError, Invalid):
                retained.append(target.name)
        message = str(error) if isinstance(error, Invalid) else "Question drafts could not be prepared safely. Reload the questions before trying again."
        if retained:
            message += " Another edit or filesystem error prevented cleanup of: " + ", ".join(retained)
        return {**_fail(message), "changed": bool(retained)}
    finally:
        if lock_fd is not None:
            os.close(lock_fd)
            try:
                lock_path.unlink(missing_ok=True)
            except OSError:
                pass


def _edited(raw, values):
    text = raw.decode("utf-8")
    tree = yaml.compose(text, Loader=StrictLoader)
    if not isinstance(tree, yaml.MappingNode) or tree.flow_style:
        raise Invalid("This form uses an inline mapping. Ask your data expert to regenerate a normal answer form.")
    nodes = {key.value: value for key, value in tree.value}
    edits = []
    for field, value in values.items():
        node = nodes.get(field)
        if not isinstance(node, yaml.ScalarNode):
            raise Invalid(f"The issued form has no scalar {field} field. Re-issue the form before answering.")
        prefix = " " if node.start_mark.index and text[node.start_mark.index - 1] == ":" else ""
        edits.append((node.start_mark.index, node.end_mark.index, prefix + json.dumps(value, ensure_ascii=False)))
    for start, end, value in sorted(edits, reverse=True):
        text = text[:start] + value + text[end:]
    expected = _parse(raw)
    expected.update(values)
    if _parse(text.encode("utf-8")) != expected:
        raise Invalid("The answer edit would change another field, so nothing was saved.")
    return text.encode("utf-8")


def _temporary(path, raw):
    with tempfile.NamedTemporaryFile(mode="wb", prefix=".decision-", suffix=".tmp", dir=path.parent, delete=False) as handle:
        temporary = Path(handle.name)
        handle.write(raw)
        handle.flush()
        os.fsync(handle.fileno())
    os.chmod(temporary, path.stat().st_mode)
    return temporary


def save(root, pack, answers, *, expected_digest, local_demo, can_write, allowed_packs=None):
    """Validate every submitted answer before writing any; never overwrite a ruling."""
    if not local_demo or not can_write:
        return _fail("Saving answers requires product-author access in a local demo.")
    if not isinstance(answers, dict) or not answers or len(answers) > 500:
        return _fail("Enter at least one answer to an issued question.")
    lock_fd = None
    lock_path = None
    staged, backups, written, recovery_files = {}, {}, [], set()
    committed = False
    try:
        root, pack, product = _paths(root, pack, allowed_packs)
        lock_path = product / LOCK_NAME
        try:
            lock_fd = os.open(lock_path, os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o600)
        except FileExistsError:
            return _lock_result(lock_path)
        root, pack, product, original, forms, items, digest = _snapshot(root, pack, allowed_packs)
        if not isinstance(expected_digest, str) or digest != expected_digest:
            raise Invalid("The questions, forms or contract changed while this page was open. Reload and review the current questions before saving.")
        replacements = {}
        by_id = {item["id"]: item for item in items}
        for did, values in answers.items():
            if did not in forms or not by_id[did]["editable"]:
                raise Invalid(f"{did}: this question is missing, stale or already resolved. Reload the questions; an existing ruling cannot be overwritten.")
            if not isinstance(values, dict) or set(values) != set(FIELDS) or any(not isinstance(v, str) for v in values.values()):
                raise Invalid(f"{did}: provide only your answer, the decision maker's name and decision date.")
            if unresolved_answer(values["answer"]):
                raise Invalid(f"{did}: this answer still contains an unresolved draft marker. Complete the scientific decision before saving; the question remains open.")
            if any(any(ord(c) < 32 and c not in "\n\r\t" or ord(c) == 127 for c in v) for v in values.values()):
                raise Invalid(f"{did}: remove control characters from the answer fields.")
            if any("|" in values[f] or "\n" in values[f] or "\r" in values[f] for f in ("answered_by", "answer_date")):
                raise Invalid(f"{did}: the name and date must each be a single line without a table separator.")
            path, _doc = forms[did]
            replacements[path] = _edited(original[path], values)
        with tempfile.TemporaryDirectory(prefix="portal-answer-check-") as directory:
            checked = []
            for path, raw in replacements.items():
                temporary = Path(directory) / path.name
                temporary.write_bytes(raw)
                checked.append(str(temporary))
            applied, _skipped, errors, new_register = dr.apply_forms(pack, checked, root=str(root))
            hidden = (directory, str(root))
        if errors or not new_register:
            raise Invalid(" ".join(plain(e, hide=hidden) for e in errors) if errors else "No new answers could be applied.")
        preflight = dr.seal_preflight(pack, applied, root=str(root))
        if preflight:
            raise Invalid(" ".join(plain(e, hide=(str(root),)) for e in preflight))
        replacements[product / dr.DECISIONS] = new_register.encode("utf-8")
        for path, raw in replacements.items():
            staged[path] = _temporary(path, raw)
            backups[path] = _temporary(path, original[path])
        # Re-read both the canonical paths and full input inventory immediately
        # before replacing files, including unsubmitted forms and requirements.
        if _snapshot(root, pack, allowed_packs)[-1] != digest:
            raise Invalid("The decision inputs changed during this save. Reload before trying again.")
        for path, temporary in staged.items():
            if _read(path) != original[path]:
                raise Invalid("A decision file changed during this save. No submitted batch was retained.")
            os.replace(temporary, path)
            written.append(path)
        result = describe(root, pack, allowed_packs)
        if not result.get("ok"):
            raise Invalid("The saved batch could not be read back safely, so it was restored.")
        # From this point the canonical records are applied. A ledger/report failure is
        # recoverable completion work; rolling back after an event append would lie about history.
        committed = True
        return _complete(root, pack, applied, allowed_packs, applied=applied)
    except (Invalid, OSError, ValueError, TypeError, UnicodeError, yaml.YAMLError, RecursionError, KeyError) as error:
        if committed:
            return {**describe(root, pack, allowed_packs), "changed": True, "applied": applied,
                    "completion_ok": False, "completion_errors": ["The answer is recorded. Its evidence update was interrupted; retry completion below before continuing review."]}
        rollback_errors = []
        for path in reversed(written):
            try:
                if _read(path) != replacements[path]:
                    raise OSError("Another writer changed this file after replacement")
                os.replace(backups[path], path)
            except (OSError, Invalid):
                rollback_errors.append(path.name)
                recovery_files.add(backups[path])
        if rollback_errors:
            result = _fail("The save and rollback failed for " + ", ".join(rollback_errors) + ". Stop and ask your data expert to recover the batch before continuing; original-byte backups were retained.")
            result["recovery_files"] = [str(path) for path in recovery_files]
            return result
        return _fail(str(error) if isinstance(error, Invalid) else "The answers could not be saved safely. The original files were retained.")
    finally:
        for temporary in list(staged.values()) + list(backups.values()):
            if temporary in recovery_files:
                continue
            try:
                temporary.unlink(missing_ok=True)
            except OSError:
                pass
        if lock_fd is not None:
            os.close(lock_fd)
            try:
                lock_path.unlink(missing_ok=True)
            except OSError:
                pass


def _complete(root, pack, ids, allowed_packs, *, applied=()):
    sealed, _by_design, failures, report_error = dr.complete_applied(pack, ids, root=str(root))
    errors = [plain(f"{did}: {why}", hide=(str(root),)) for did, why in failures]
    if report_error:
        errors.append(plain(report_error, hide=(str(root),)))
    return {**describe(root, pack, allowed_packs), "changed": True, "applied": list(applied),
            "sealed_ids": [did for did, _event in sealed], "completion_ok": not errors,
            "completion_errors": errors}


def complete_saved(root, pack, *, expected_digest, local_demo, can_write, allowed_packs=None):
    """Repair completion of already applied answers without submitting any OPEN drafts."""
    if local_demo is not True or can_write is not True:
        return _fail("Updating decision evidence requires product-author access in the local application.")
    lock_fd, lock_path = None, None
    try:
        root, pack, product = _paths(root, pack, allowed_packs)
        lock_path = product / LOCK_NAME
        try:
            lock_fd = os.open(lock_path, os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o600)
        except FileExistsError:
            return _lock_result(lock_path)
        _root, _pack, _product, _raw, forms, items, digest = _snapshot(root, pack, allowed_packs)
        if digest != expected_digest:
            raise Invalid("The saved decisions changed. Reload the questions before updating their evidence.")
        current = describe(root, pack, allowed_packs)
        ids = current.get("completion_pending_ids") or []
        paths = [str(forms[did][0]) for did in ids]
        if paths:
            applied, _skipped, errors, _text = dr.apply_forms(pack, paths, root=str(root))
            if errors or applied:
                raise Invalid(" ".join(plain(e, hide=(str(root),)) for e in errors) or "Only already recorded answers can have their evidence updated here.")
            preflight = dr.seal_preflight(pack, ids, root=str(root))
            if preflight:
                raise Invalid(" ".join(plain(e, hide=(str(root),)) for e in preflight))
        return _complete(root, pack, ids, allowed_packs)
    except (Invalid, OSError, ValueError, TypeError, UnicodeError, yaml.YAMLError, RecursionError, KeyError) as error:
        return _fail(str(error) if isinstance(error, Invalid) else "Decision evidence could not be updated safely. Saved answers were retained; check storage and retry.")
    finally:
        if lock_fd is not None:
            os.close(lock_fd)
            lock_path.unlink(missing_ok=True)


def register_owners(text):
    """The roles the register's Owner column already uses; a new question goes to one of them."""
    return sorted({str(cl.decision_owner(row) or "").strip() for row in cl.decision_rows(text).values()} - {""})


def _column_matches(column, names):
    return re.sub(r"\s+", " ", str(column)).strip().lower() in {re.sub(r"\s+", " ", n).strip().lower() for n in names}


def _evidence_error(root, product, pack, evidence):
    """Why the evidence names nothing this checkout can look at; mirrors decision_record's three forms."""
    ev = evidence.strip().strip("`")
    looks_finding = bool(re.fullmatch(r"[A-Z][A-Z0-9]*(?:-[A-Z0-9]+)+", ev))
    relative = ev.replace("\\", "/")
    is_path = False
    if not looks_finding and re.fullmatch(r"[\w./-]+", relative) and ".." not in Path(relative).parts and not Path(relative).is_absolute():
        target = root / relative
        is_path = target.exists() and target.resolve().is_relative_to(root)
    cite = re.match(r"^([\w][\w .-]*?)\s*:\s*\S", ev)
    if looks_finding:
        qc_path = product / "handoff/SPEC_QC_FINDINGS.md"
        qc_ids = set(re.findall(r"(?m)^\|\s*([A-Z][A-Z0-9-]+)\s*\|", _read(qc_path).decode("utf-8"))) if qc_path.is_file() else set()
        if ev not in qc_ids:
            return f"The evidence {ev} reads as a finding identifier, and the product's specification findings do not carry it. Cite a recorded finding, a specification row such as clinical:3, or a file in the product."
        return ""
    if is_path:
        return ""
    if cite:
        extracted = product / "spec_pipeline/out/extracted.json"
        if extracted.is_file():
            try:
                rows = [r for r in (json.loads(_read(extracted).decode("utf-8")).get("rows") or []) if isinstance(r, dict)]
            except (ValueError, TypeError, AttributeError):
                rows = []
            tabs = {str(r.get("tab") or "").strip().lower() for r in rows} - {""}
            domains = {str(r.get("domain") or "").strip().lower() for r in rows} - {""}
            items = {str(r.get("item_id") or "").strip().lower() for r in rows} - {""}
            head = cite.group(1).strip().lower()
            if tabs and head not in tabs and head not in domains:
                return f"The evidence {ev} cites a tab the extracted specification does not have. Use one of: {', '.join(sorted(tabs | domains))}."
            if items and head in domains and ev.lower() not in items:
                return f"The evidence {ev} names no extracted row. Use a row identifier the extraction carries, such as {sorted(i for i in items if i.startswith(head + ':'))[0] if any(i.startswith(head + ':') for i in items) else 'clinical:3'}."
        return ""
    return f"The evidence {ev} names nothing the answerer can open: give a specification row such as clinical:3, a finding identifier, or a file in the product."


def _appended(text, fields):
    """The register with one OPEN row added to its first table, other bytes untouched."""
    newline = "\r\n" if "\r\n" in text else "\n"
    lines = text.split(newline)
    header = next((i for i, line in enumerate(lines) if line.startswith("|") and re.search(cl.id_column_re(), line)), None)
    if header is None:
        raise Invalid("The register has no question table yet. Ask your data expert to restore its header row.")
    columns = [c.strip() for c in lines[header].strip().strip("|").split("|")]
    cells, found = [], set()
    for column in columns:
        if column == "ID":
            cells.append(fields["id"])
        elif _column_matches(column, cl.QUESTION_COLUMNS):
            cells.append(fields["question"])
            found.add("question")
        elif _column_matches(column, cl.EVIDENCE_COLUMNS):
            cells.append(fields["evidence"])
            found.add("evidence")
        elif _column_matches(column, cl.OWNER_COLUMNS):
            cells.append(fields["owner"])
            found.add("owner")
        elif _column_matches(column, ("Status",)):
            cells.append("OPEN")
            found.add("status")
        elif _column_matches(column, cl.ANSWER_COLUMNS):
            cells.append(BLANK_CELL)
        else:
            cells.append("")
    for name in ("question", "evidence", "owner", "status"):
        if name not in found:
            raise Invalid(f"The register has no {name} column, so a new question has nowhere to record its {name}. Ask your data expert to restore the canonical header.")
    end = header
    while end + 1 < len(lines) and lines[end + 1].startswith("|"):
        end += 1
    lines.insert(end + 1, "| " + " | ".join(cells) + " |")
    return newline.join(lines)


def raise_question(root, pack, values, *, expected_digest, local_demo, can_write, allowed_packs=None):
    """Append one OPEN question to the register. No answer, no name and no date are ever written."""
    if local_demo is not True or can_write is not True:
        return _fail("Raising a question requires product-author access in a local demo.")
    if not isinstance(values, dict) or set(values) != set(RAISE_FIELDS) or any(not isinstance(v, str) for v in values.values()):
        return _fail("Enter the question identifier, the question, its evidence and the owner.")
    lock_fd = lock_path = temporary = None
    try:
        root, pack, product = _paths(root, pack, allowed_packs)
        lock_path = product / LOCK_NAME
        try:
            lock_fd = os.open(lock_path, os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o600)
        except FileExistsError:
            return _lock_result(lock_path)
        root, pack, product, original, _forms, _items, digest = _snapshot(root, pack, allowed_packs)
        if not isinstance(expected_digest, str) or digest != expected_digest:
            raise Invalid("The questions or contract changed while this page was open. Reload the questions before raising a new one.")
        fields = {name: value.strip() for name, value in values.items()}
        labels = {"id": "identifier", "question": "question", "evidence": "evidence", "owner": "owner"}
        for name, value in fields.items():
            if "|" in value or "\n" in value or "\r" in value or any(ord(c) < 32 for c in value):
                raise Invalid(f"The {labels[name]} must be one line without a table separator. Detail belongs in the answer form.")
        if not DECISION_ID.fullmatch(fields["id"]) or not cl.ID_RE.match(fields["id"]):
            raise Invalid("Use an identifier of capital letters, digits and dashes, for example LOT-NULL.")
        register = product / dr.DECISIONS
        text = original[register].decode("utf-8")
        if fields["id"] in cl.decision_ids(text) or fields["id"] in cl.decision_rows(text):
            raise Invalid(f"{fields['id']} is already in the register. Choose a new identifier; an existing question is never rewritten here.")
        if not fields["question"] or dr._blankish(fields["question"]):
            raise Invalid("Write the question as one plain sentence.")
        if len(fields["question"]) > 1000 or len(fields["evidence"]) > 1000:
            raise Invalid("Keep the question and the evidence under 1000 characters each. Detail belongs in the answer form.")
        if not fields["evidence"] or dr._blankish(fields["evidence"]):
            raise Invalid("Name the evidence the answerer should read: a specification row such as clinical:3, a finding identifier, or a file in the product.")
        problem = _evidence_error(root, product, pack, fields["evidence"])
        if problem:
            raise Invalid(problem)
        owners = register_owners(text)
        if not owners:
            raise Invalid("The register does not name any owner yet, so a new question has nobody to go to. Ask your data expert to record the first question.")
        if fields["owner"] not in owners:
            raise Invalid("Choose an owner the register already uses: " + ", ".join(owners) + ".")
        if cl.decision_register_errors(text, pack):
            raise Invalid("The decision register needs repair before a question can be added. Ask your data expert.")
        candidate = _appended(text, fields)
        rows = cl.decision_rows(candidate)
        if (cl.decision_register_errors(candidate, pack) or fields["id"] not in rows
                or cl.decision_status(candidate).get(fields["id"]) != "OPEN"
                or cl.decision_question(rows[fields["id"]]) != fields["question"]
                or cl.decision_owner(rows[fields["id"]]) != fields["owner"]
                or {k: v for k, v in cl.decision_rows(candidate).items() if k != fields["id"]} != cl.decision_rows(text)):
            raise Invalid("The new row would not read back as one open question. Rephrase it as one plain sentence.")
        temporary = _temporary(register, candidate.encode("utf-8"))
        if _snapshot(root, pack, allowed_packs)[-1] != digest or _read(register) != original[register]:
            raise Invalid("The questions changed during this save. Reload before trying again.")
        os.replace(temporary, register)
        temporary = None
        result = describe(root, pack, allowed_packs)
        if not result.get("ok"):
            raise Invalid("The question was added, but the register could not be read back. Reload the questions.")
        return {**result, "changed": True, "raised": fields["id"]}
    except (Invalid, OSError, ValueError, TypeError, UnicodeError, yaml.YAMLError, RecursionError, KeyError) as error:
        return _fail(str(error) if isinstance(error, Invalid) else "The question could not be raised safely. The register was not changed.")
    finally:
        if temporary is not None:
            try:
                temporary.unlink(missing_ok=True)
            except OSError:
                pass
        if lock_fd is not None:
            os.close(lock_fd)
            try:
                lock_path.unlink(missing_ok=True)
            except OSError:
                pass


# THE WAY BACK AFTER AN ANSWER (DL-04). Saving an answer settles the register; every record that
# cited the question stays `decision_required` until its own judgments are applied again through
# contract_record, whose apply_status is the one place that moves the requirement back to draft.
def settled_records(root, pack, allowed_packs=None):
    """Records still decision_required whose cited questions are all answered, sorted by identifier."""
    try:
        _root, _pack, product = _paths(root, pack, allowed_packs)
        register, contract = product / dr.DECISIONS, product / "handoff/FUNCTIONAL_CONTRACT.md"
        if not register.is_file() or not contract.is_file():
            return []
        statuses = cl.decision_status(_read(register).decode("utf-8"))
        waiting = []
        for block in cl.records(_read(contract).decode("utf-8").replace("\r\n", "\n")):
            if cl._kv(cl._inline(block, "status") or "", "requirement") != "decision_required":
                continue
            cited = [d for d in (cl._list(block, "decision_ids") or []) if d not in cl.OUTPUT_DECISIONS]
            if not cited or cl.blocking_decisions(cited, statuses):
                continue
            refs = cl._list(block, "spec_refs") or []
            waiting.append({"variable_id": cl._scalar(block, "variable_id") or "", "decision_ids": cited,
                            "item_id": refs[0] if len(refs) == 1 else "", "spec_refs": refs})
        return sorted(waiting, key=lambda entry: entry["variable_id"])
    except (Invalid, OSError, ValueError, TypeError, UnicodeError, AttributeError):
        return []


_REOPEN_WORDS = ("claims contract:approved", "MATURITY.yaml claims")


def reopen_contract(root, pack, actor_id, *, local_demo, can_write, allowed_packs=None):
    """The maturity claim `contract: approved` goes back to `draft` so a changed record can be re-checked and
    the approval made again over the new bytes (walk NEW-7). Line-surgical: nothing else in the file moves,
    no approval record is touched, and the gate reports the reopened state on its next check."""
    if local_demo is not True or can_write is not True:
        return _fail("Reopening the contract approval requires product-author access in a local demo.")
    try:
        root, pack, product = _paths(root, pack, allowed_packs)
        path = product / "handoff" / "MATURITY.yaml"
        text = _read(path).decode("utf-8")
        newline = "\r\n" if "\r\n" in text else "\n"
        lines = text.split(newline)
        hits = [i for i, line in enumerate(lines) if re.match(r"^contract:\s*approved\s*(#.*)?$", line)]
        if not hits:
            return _fail("The contract is not marked approved, so there is nothing to reopen.")
        if len(hits) > 1:
            return _fail("The maturity file states the contract level more than once. Ask your data expert to repair it.")
        lines[hits[0]] = lines[hits[0]].replace("approved", "draft", 1)
        handle, temporary = tempfile.mkstemp(prefix=".maturity-", suffix=".tmp", dir=str(path.parent))
        with os.fdopen(handle, "w", encoding="utf-8", newline="") as out:
            out.write(newline.join(lines))
        os.replace(temporary, path)
        return {"ok": True, "changed": True, "errors": [], "notice": NOTICE,
                "message": ("The contract approval is reopened: its maturity claim is draft again. The approval form is "
                            "prepared again over the new bytes once the record is re-checked.")}
    except (OSError, ValueError, TypeError, UnicodeError):
        return _fail("The contract approval could not be reopened safely. Nothing was changed.")


def _plain_check(message):
    """One record-check refusal in the person's words (walk UC3-P2-1): the invariant that says the
    contract is still claimed approved while a record changed names the act that reopens it."""
    text = str(message)
    if "claims contract:approved" in text or "MATURITY.yaml claims" in text:
        return ("The contract is still marked approved while this record changed. Reopen the contract approval "
                "(stage 2: the maturity claim goes back to draft, the approval form is prepared again after the "
                "re-check) and try the re-check again.")
    return plain(text)


def recheck_record(root, pack, actor_id, variable_id, *, local_demo, can_write, allowed_packs=None):
    """Re-apply one record's own judgments through the definition path; no judgment is edited."""
    if local_demo is not True or can_write is not True:
        return _fail("Re-checking a record requires product-author access in a local demo.")
    import scientific_definitions as definitions
    try:
        root, pack, product = _paths(root, pack, allowed_packs)
        entry = next((e for e in settled_records(root, pack, allowed_packs) if e["variable_id"] == variable_id), None)
        if entry is None:
            return _fail(f"{variable_id} is not waiting for a re-check. Reload the questions.")
        if not entry["item_id"]:
            return _fail(f"{variable_id} cites several specification rows, so it needs an explicit engineering handoff instead of a re-check.")
        text = _read(product / "handoff/FUNCTIONAL_CONTRACT.md").decode("utf-8").replace("\r\n", "\n")
        block = next((b for b in cl.records(text) if cl._scalar(b, "variable_id") == variable_id), None)
        if block is None:
            return _fail(f"{variable_id} is no longer in the contract. Reload the questions.")
        values = {key: cl._scalar(block, key) or "" for key in definitions.FIELDS}
        current = definitions.describe(root, pack, actor_id, item_id=entry["item_id"], allowed_packs=allowed_packs)
        if not current["ok"]:
            return _fail(" ".join(current["errors"]))
        checked = definitions.preview(root, pack, actor_id, entry["item_id"], values,
                                      expected_input_digest=current["input_digest"], allowed_packs=allowed_packs)
        if not checked["ok"] or not checked["passed"]:
            failed = _fail(f"{variable_id} did not pass the record checks, so its requirement status was left as it is.")
            failed["errors"] += [_plain_check(e) for e in (checked.get("errors") or [])]
            # the page offers the act the invariant names (walk NEW-7)
            failed["reopen"] = any(any(w in str(e) for w in _REOPEN_WORDS) for e in (checked.get("errors") or []))
            return failed
        result = definitions.apply(root, pack, actor_id, entry["item_id"], values, expected_input_digest=checked["input_digest"],
                                   expected_manifest_digest=checked["manifest_digest"], confirmed=True,
                                   local_demo=local_demo, can_write=can_write, allowed_packs=allowed_packs)
        if not result["ok"] or not result.get("changed"):
            failed = _fail(f"{variable_id} could not be re-checked. The contract was not changed.")
            failed["errors"] += list(result.get("errors") or [])
            failed["stale_lock"] = bool(result.get("stale_lock"))
            return failed
        after = next((b for b in cl.records(result["after"]) if cl._scalar(b, "variable_id") == variable_id), "")
        requirement = cl._kv(cl._inline(after, "status") or "", "requirement") if after else ""
        return {"ok": True, "changed": True, "errors": [], "variable_id": variable_id, "requirement": requirement or "", "notice": NOTICE}
    except (Invalid, OSError, ValueError, TypeError, UnicodeError, KeyError, AttributeError) as error:
        return _fail(str(error) if isinstance(error, Invalid) else "The record could not be re-checked safely. The contract was not changed.")
