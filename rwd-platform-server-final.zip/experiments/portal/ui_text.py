"""Every sentence the portal shows a person, in one place and in plain language.

WHY. The page's captions were written for the people who built the platform: section signs,
"exhaust", "REFUSED", tool names, dashes and parentheses (operator, 2026-09-03: "the text we
show is not user friendly"). These are the words a reviewer or a scientist reads. The rules,
held by test_audit8: no jargon tokens, no em dashes, no arrows, short sentences that say what
happens next. Pure strings and small formatting functions; no Streamlit here.
"""
from __future__ import annotations


def access_denied(why: str) -> str:
    return f"You cannot use this portal yet. {why}"


WORKING_AS = "Working as (demo only: a label, not a sign-in)"
NAME_EXISTS = "That name already exists."
OWNS_LABEL = "Answers questions for (who this person may answer on behalf of)"
SIDEBAR_READS_ONLY = "The portal helps prepare specifications and record your answers. Scientific approvals still need the named reviewers' authenticated review."
NO_PACKS = "You are not assigned to any pack yet. Ask an administrator."
FIXTURES_NOTE = "Every pack here is a reference fixture, never production data."


PERM_WORDS = {"view": "see products", "start": "start products", "pin": "pin products to studies", "queue": "see what waits on a person",
              "run_gates": "run checks", "agent": "use the assistant", "evals": "see evaluations",
              "manage_users": "manage users", "answer": "record scientific answers", "review": "record your review decisions"}


def role_line(role: str, perms) -> str:
    words = [PERM_WORDS.get(p, p) for p in perms]
    return f"Your role is **{role}**. You can {', '.join(words)}."


START_PRODUCT = "Start a new product"
ABOUT_IDENTITY = "About this identity"
# the demo label in a person's words (walk UC4-01, 2026-09-07): the tool's own line, with the
# environment variable, stays in the identity module for the technical reader
DEMO_IDENTITY_NOTE = ("Local demo: working as {name}. This names the person on what is recorded; "
                      "it does not sign anyone in.")
NO_PRODUCTS_YET ="No products yet. Start your first product above. Reusable examples are available under Browse reference examples."
NO_PRODUCTS_START = "No products yet. Start your first product above."
PICK_PACK = "Product or reference example"
STEP_1 = "1. The product"
STEP_1_HELP = "A slug names the folder and the job; the code is the short registry name; the cut is the month of the specification."
STEP_2 = "2. The data"
STEP_2_HELP = "Who delivers the data, in which form, and where the tumour sits in the oncology catalogue."
STEP_3 = "3. The specification"
STEP_3_HELP = "The approved workbook, if you have it, and the words specifications use for this disease so a workbook can be checked to be this tumour's."
STEP_4 = "4. Who classified it"
STEP_4_HELP = "What AI may read of the specification is your call, recorded with your name and the date."
AI_ACCESS_WORDS = {"Sponsor AI may read it": "sponsor_ai_eligible",
                   "Vendor restricted: AI reads only the sanitized extraction": "vendor_restricted",
                   "Restricted derived: AI reads nothing of it": "restricted_derived"}


def counts_unavailable(err) -> str:
    return f"The counts are unavailable right now: {err}"


def no_snapshot(path: str, env: str) -> str:
    """The caption when no status report has been saved yet (walk UC4-61, 2026-09-07): the path and
    the environment variable are the tool's, not the person's; the arguments stay for the call site."""
    return "No saved status report yet. Check status on Progress and next step writes one."


OLDER_SNAPSHOT = "Showing an older snapshot. "
SNAPSHOT_UNUSABLE = "The snapshot could not be used: "


def snapshot_line(commit: str, generated: str, dirty: bool = False) -> str:
    return (f"Snapshot from commit {commit}, generated {generated}"
            + (" from a MODIFIED tree, so the gates may not match that commit" if dirty else "")
            + ". Reads take milliseconds. Rebuild below for a fresh one.")


PATH_NOT_HERE = "{path} is not a file on this machine: the portal reads the checkout it runs in, not your desktop."
STUDIES_NO_DECISION_FORM = "No decision form: the product carries no contract yet, so there is nothing to decide about."



def gate_blockers(gate, name, n: int) -> str:
    return f"Gate {gate} {name}: {n} thing(s) blocking"


def unreadable(packs) -> str:
    return f"Packs that could not be read (named, never skipped): {packs}"


def built(path: str) -> str:
    return f"Snapshot built: {path}"


QUESTIONS_CAPTION = ("Start with the question that unblocks the most work. Read its evidence and enter the decision actually made in the form above. The recorded answer still needs the named reviewer's authentication.")


def ask_now(top: dict) -> str:
    return (f"**Ask now:** {top['id']}. Unblocks {top['unblocks']} record(s). "
            f"Owner: {top['owner_display']} (recorded as {top['owner']}).")


WHOLE_PAGE = "The whole ranked page"
PRECEDENTS_TOGGLE = "Precedents for this pack (advice from other packs, not an approval)"


def no_gates(role: str) -> str:
    return (f"Your role ({role}) can check product progress in Progress and next step. "
            "These engineering checks require a data expert with the appropriate access.")


GATES_CAPTION = ("Each button runs the check exactly as CI runs it. A failing verdict is the answer, not an error. "
                 "Nothing is written to the checkout.")


def no_agent(role: str) -> str:
    return (f"Your role ({role}) cannot start the agent. The other sections answer status and search "
            "questions without a model.")


AGENT_CAPTION = ("A model runs only when you send a message here, or when you resume a run in Waiting on a person. "
                 "It reads the same tools as the other sections, asks a person when a decision is needed, and "
                 "cannot write anything.")


def model_line(model: str, have_key: bool, have_package: bool = True) -> str:
    key = "found" if have_key else "missing (set ANTHROPIC_API_KEY)"
    pkg = "installed" if have_package else "not installed (pip install anthropic)"
    return f"Model: {model}. API key: {key}. Package: {pkg}."


def steps_title(n: int) -> str:
    return f"What the agent did ({n} steps)"


def finished(status, path) -> str:
    return f"Finished: {status}. Record: {path}"


def memo_title(n: int) -> str:
    return f"What the agent remembers from this conversation ({n} facts, this session only)"


MODE_INTAKE = "Describe a request"
MODE_CHECK = "Check it (governed)"


def request_so_far(n: int) -> str:
    return f"Your request so far ({n} fields filled). Type check when ready."


KEEP_REQUEST = "Keep this request for later reuse"
DICTIONARY_TOGGLE = ("Show the data dictionary preview: every contract variable with its type, domain, "
                     "status and required rule, read from the contract, with no data behind it")


def kept(filename: str, status: str) -> str:
    return (f"Kept as {filename} with status {status}. Registering it as a formal request is still a person's act.")


def similar_title(n: int) -> str:
    return f"Similar past requests ({n}). Pre-fill the empty fields, then check each one."


def similar_row(score: float, filename: str, a: str, b: str) -> str:
    return f"**{score:.2f}** {filename}: {a} / {b}"


def prefill_button(filename: str) -> str:
    return f"Pre-fill from {filename}"


def step_line(d: dict) -> str:
    return f"**{d.get('action')}** {d.get('tool', '')}: {d.get('why') or d.get('question') or ''}"


def checked_line(tool, first: str) -> str:
    return f"Checked {tool}: {first}"


def authority_line(marker) -> str:
    return f"A person decides here: {marker}"


def check_failed(err) -> str:
    return f"The check stopped before an answer: {err}. Nothing was recorded."


def needs_person(to, question) -> str:
    return f"**This needs a person. Sent to {to}:**\n\n{question}"


def fact_sent(to, run_id) -> str:
    return f"sent to {to} in run {run_id}, open until they answer"


def bad_limit(err) -> str:
    return f"A run limit is set wrongly: {err}. Fix the variable and reload. No run was started."


REBUILD_SNAPSHOT = "Rebuild snapshot (~4 min, all packs)"
FLOW_CAPTION = "Check status, then open Resolve next step for an action or instructions."
FLOW_CHECK = "Check status"
FLOW_CHECKING = "evaluating the gates from the pack's files (a few seconds to a minute)…"
FLOW_NOT_CHECKED = "Choose Check status to see what this product needs next."
FLOW_FROM_SNAPSHOT = "Shown from the governance snapshot until you check live."
FLOW_REFUSED = "The evaluation refused: {why}. Nothing was written."
FLOW_GO_QUESTIONS = "Open the questions to answer"
FLOW_OUTPUT = "Output of {act}"


def flow_proceed(n: int) -> str:
    return f"Proceed to Gate {n}"


def flow_owner(owner: str) -> str:
    return f"Owner: {owner}."


def flow_held_by(gate: int) -> str:
    return f" This finding holds every approval gate back; Gate {gate} owns the fix."

VALIDATE_CONFIG = "Validate the configuration (lint, then strict)"
BUILD_SYNTHETIC = "Build on synthetic sources (local Spark)"
WALKTHROUGH_CAPTION = ("One specification, start to end: each step's state is read from the pack's files, and the button "
                       "runs the same bounded command CI and the demo run. Approvals, answers and promotions are never here.")
WALKTHROUGH_SUBJECT = "Walk through"
WALKTHROUGH_SELECTED = "the selected pack ({pack})"
WALKTHROUGH_DEMO = "the shipped bladder example (synthetic, outside governance)"
WALKTHROUGH_GO_NEW = "Go to New product"
WALKTHROUGH_OUTPUT = "Output of the last {step} run"


def build_unbound(count: int) -> str:
    return (f"This product's sources and settings are not bound yet ({count} placeholder(s) in its configuration). "
            "The data expert completes the configuration at Gate 3; the build becomes available after that.")


def build_disabled(local_demo: bool, why: str) -> str:
    if not local_demo:
        return "Builds run as Databricks Jobs when deployed; the portal never runs an engine in-process there."
    return f"Local Spark is not verified on this machine: {why}"


NO_HITS = "No hits. Every surface was searched; nothing matched all the words."


def more_hits(n: int) -> str:
    return f"... and {n} more (narrow the query)"


def dropped_hits(n: int) -> str:
    return f"{n} hit(s) in packs outside your scope were not shown"


NO_KEY_INPUT = ("The message box is disabled: no ANTHROPIC_API_KEY is set, and nothing here calls a model "
                "without one. Put ANTHROPIC_API_KEY=<your key> in experiments/portal/.env (gitignored) or "
                "export it in the shell, then restart the portal. Every other section works without it.")
INTAKE_PLACEHOLDER = "Describe the request, answer the question, or type check"
CHECK_PLACEHOLDER = "Ask about this pack, or set a goal"
WITHHELD = "(message withheld: it looked like data about individual people)"


def no_evals(role: str) -> str:
    return f"Your role ({role}) does not review the eval corpus."


EVALS_CAPTION = ("The latest mechanical scorecard of the adversarial corpus. A pass here is not adjudication. "
                 "A person signs the adjudication sheet before any number is quoted.")
NO_SCORECARD = "No scorecard yet. Run `python experiments/agent/evals/run.py` to create one."


def no_queue(role: str) -> str:
    return f"Your role ({role}) does not see this queue."


ESCALATIONS_CAPTION = ("Every run that stopped to ask a person, newest first. Each one is a question for its owner, "
                       "not a failure. Answering continues the run with your answer, recorded under your name. If "
                       "the answer is a decision, recording it is your act in the repository, not here.")
YOUR_ANSWER = "Your answer (the run continues with it, recorded under your name)"
RESUMING = "Continuing the run with your answer..."
ANSWER_IS_CONTEXT = ("Your answer is context the run continued under. If it settles a decision, the decision "
                     "form in the repository is where it is recorded.")
RESUME_NEEDS_AGENT = "You can read this queue. Continuing a run needs the agent permission."
NOTHING_WAITING = "Nothing is waiting on a person."


def for_line(row: dict) -> str:
    return f"**For {row['to']}.** Asked by {row['asked_by']}. Goal: {row['goal']}"


def already_answered(who, eligibility=None) -> str:
    tail = (" The roster does not record what this person owns, so the answer is marked unverified."
            if eligibility == "unverified" else "")
    return f"Already answered by {who}. A second answer would fork the run.{tail}"


def attempts_line(n: int) -> str:
    return f"{n} earlier answer(s) did not finish the run, so the question is still open."


def resumed(status, run_id) -> str:
    return f"Continued. Outcome: {status}. Record: {run_id}"


def no_packets_role(role: str) -> str:
    return f"Your role ({role}) does not see evidence packets."


PACKETS_CAPTION = ("What the specialists produced for a person to decide on: source evidence, code candidates, "
                   "diagnoses, proposals. Every packet carries its critic verdict and the line that says a person "
                   "decides. None of them approves or records anything.")
NO_PACKETS = "No evidence packets yet."


def packet_line(row: dict) -> str:
    return f"**{row['kind']}** for {row['pack']}. Critic: {row['critic']}"


# ninth review: products vs references, the stepper, the question card, the live button
VIEW_HELP = ("Products are governed data products. The Reference library holds dated reference fixtures used "
             "for tests and demos; they are never releasable and every page says so.")
NO_PRODUCTS = "No products have been started. Choose a reference example in the product selector to explore the workflow."
NO_PACKS_IN_VIEW = "None of your assigned products is available. Ask an administrator to check your product assignments."
NO_PACKS_MAIN = ("No product or reference example is available to you yet. An administrator assigns products under Manage users "
                 "(in the sidebar, after switching on Show technical tools and activity); a person with the start permission "
                 "creates the first product.")
STATUS_OPERATOR_NOTE = "Rebuilding the saved status report and the full live evaluation are a data expert's tools; your Progress page checks this product on its own."
NEW_PRODUCT_NO_CUTS = "No registered product has a cut to revise yet. Create the first product with one of the other two routes."
# the vendor carries over: said beside the vendor field for a new product, and beside the previous
# cut for a next cut, which has no vendor field (walk UC4-45, 2026-09-07)
NEW_PRODUCT_VENDOR_CARRIES = "A product keeps its vendor across cuts; the same science over another vendor is a new product."
NEW_PRODUCT_VENDOR_NOT_LISTED = "A vendor not listed here needs an entry in the vendor policy, which the data expert adds."
NEW_PRODUCT_PREVIEW_PASSED = ("The plan passed its preview: the identifiers, registries and declarations are consistent. The write "
                              "below stages a copy and runs every validator, including the workbook checks, before anything lands.")
NEW_PRODUCT_WRITE_TAKES = "Writing takes two to four minutes on this machine; stay on this page until it reports."
QUESTION_ACTIONS = ("Use the answer form above when the decision is ready. If evidence is missing, keep the question open and ask its owner for that evidence.")
WHOLE_PACKET = "The whole packet for this question"


def form_line(path: str) -> str:
    return f"The answer form is at {path}."


def stepper_unavailable(err) -> str:
    return f"The lifecycle summary is unavailable right now: {err}"


def compute_live(pack: str) -> str:
    return f"Evaluate {pack} now (up to two minutes)"


TREATED_NOTE = ("Treated here is a descriptive flag: a qualifying treatment record exists at any time. It is not an "
                "exposure assigned at time zero, so treated versus untreated is not a treatment comparison and must "
                "not be read as one.")


def packs_no_longer_offered(packs) -> str:
    return ("Assigned packs the picker no longer offers (superseded or template versions): " + ", ".join(packs)
            + ". Reassign to keep this person on a current version.")

# --- New product: the stand-up composed here, run as a preview, applied at a keyboard ---------------
NEW_PRODUCT_CAPTION = ("This page composes the stand-up command for you, previews the plan and every reason it "
                       "would refuse, and then writes the product into this checkout when you ask it to. The "
                       "write stages a copy first, runs every validator there, and lands all of it or none. "
                       "Nothing here approves, answers or promotes anything; those stay a person's acts.")
NEW_PRODUCT_CAPTION_DEPLOYED = ("This deployed portal cannot write into a checkout. It composes the command, previews "
                                "the plan and every reason it would refuse, and hands you the command to run in "
                                "your checkout. Nothing is written from here.")
NEW_PRODUCT_WRITE = "Write it into this checkout"
NEW_PRODUCT_WRITING = "staging a copy, running every validator, then writing"
NEW_PRODUCT_WRITTEN = ("Product draft created: {pack}. Open Check status to see its next step. "
                       "The recorded declarations still need authenticated review.")
NEW_PRODUCT_PREVIEW_FIRST = "Preview the plan first; the write button appears once the preview passes."
NEW_PRODUCT_NORMALISED = "Identifiers are lower case with underscores: using {value}."


def use_known_tumour(family: str) -> str:
    return f"Use the second-product route with {family}"


def known_tumour_hint(family: str, slug: str) -> str:
    return (f"{family} is a tumour the registry already knows. Pick the second-product route below, keep "
            f"{family} as the tumour, and give this product its own slug, for example {slug}.")
NEW_PRODUCT_MODES = ("A new tumour", "A second product of a tumour the registry knows",
                     "The next cut of a registered product")
NEW_PRODUCT_MODE_HELP = (
    "Create a product draft and register a tumour that is new to this catalogue.",
    "Create a fresh draft for a known tumour. Reusing the tumour entry does not copy another product's definitions.",
    "Revise an existing product into a later specification month. Review the inherited configuration against the revised workbook.",
)
NEW_PRODUCT_PREVIEW = "Preview the plan (writes nothing)"
CONDITION_CLASS_WORDS = {"oncology": "Oncology", "non_oncology": "Another condition (not supported yet)"}
NON_ONCOLOGY_SETUP_HELP = (
    "This application does not yet register or execute non-oncology products. Keep the actual condition "
    "in the display name and, when available, the disease names. Use Save or resume unfinished setup to retain this request. "
    "Your platform owner and scientific team need to add and validate its disease definitions, source mappings "
    "and pipeline tests before registration. Selecting Oncology cannot supply those capabilities.")
NEW_PRODUCT_NEXT_STEPS = ("What happens next: the product opens on its progress page. Step 1 asks the scientific owner to review "
                          "the workbook and you to confirm AI access; the review is then signed. Step 2 drafts one definition per "
                          "specification row. Nothing here needs a terminal.")
STUDY_ID_RULE = "A study identifier is lower case letters, digits, underscores or hyphens, 3 to 40 characters, starting with a letter."
NEW_PRODUCT_APPLY_LINE = ("To write it, run this in your checkout. It stages the plan in a copy, runs every "
                          "validator there, and writes only if all of them pass:")
NEW_PRODUCT_NEED = "Fill in {what} first."
NEW_PRODUCT_DECLARATIONS = ("Three declarations are yours and have no default: the condition class (only oncology "
                            "builds today), the modality, and the phrases a specification uses to name the disease.")
# --- the next cut: what the page says after the write, and while it runs (walk NC-03, NC-12, NC-15) ---
NEW_PRODUCT_WRITTEN_NEXT_CUT = ("Next cut created as a draft: {pack}. The previous cut stays the released one until this "
                                "cut is approved and released. The revised workbook is registered and its rows extracted; "
                                "the recorded declarations still need authenticated review.")
# the checks are the data expert's (walk RW-03, 2026-09-07): Run checks refuses the initiator's role,
# so the initiator is sent to Progress and next step, where the result appears
NEW_PRODUCT_NEXT_STEPS_NEXT_CUT = ("What happens next, all from this portal: review the changes from the previous cut, and carry "
                                   "the definitions that did not change (Plan changes); review the revised workbook and sign the "
                                   "review (Progress and next step, stage 1). Your data expert then validates the carried "
                                   "configuration under Run checks; you follow the result on Progress and next step. "
                                   "Nothing here needs a terminal.")
NEW_PRODUCT_WRITE_RUNS = ("While you wait, this runs in a staged copy: the registry and catalogue checks, the product bundle, "
                          "the coverage and citation pages, the maturity claims, the registration of the workbook, the "
                          "extraction of its rows, and for a next cut the comparison with the previous cut. Nothing lands "
                          "until all of it passes. Typically two to four minutes on this machine.")
NEW_PRODUCT_REFUSED = "Nothing was written. {n} thing(s) to change:"
NEW_PRODUCT_PREVIEW_REFUSED = "The preview needs attention. Your entries are retained; {n} thing(s) to change:"
NEW_PRODUCT_MORE_IN_DETAILS = "{n} more reason(s) are in the details below, in the tool's own words."
NEW_PRODUCT_ONLY_IN_DETAILS = "The reason is in the details below, in the tool's own words."
NEW_PRODUCT_DETAILS = "Review preview details"
NEW_PRODUCT_REPORT = "What the stand-up wrote (the tool's own report)"
NEW_PRODUCT_DELTA_TITLE = "What the revised workbook changes"


def no_new_product(role: str) -> str:
    return (f"Your role is {role}. Starting a product needs the start permission, which the initiator, "
            f"qc_programmer and admin roles hold.")


DEMO_ROLE_HINT = ("This is a local demo: switch Working as back to admin, or give this user another role "
                  "under Manage users (in the sidebar, after switching on Show technical tools and activity).")
NO_SNAPSHOT_STRIP = ("No governance snapshot for this checkout yet. The steps above show what the pack's files "
                     "say; the gate verdicts need the snapshot.")


def build_snapshot_line(interpreter: str, tool: str, env: str) -> str:
    return (f"Build it outside the portal with: {interpreter} {tool} --out <a directory outside the checkout>"
            f"/snapshot.json (add --allow-dirty while the tree carries uncommitted work, such as a product this "
            f"portal just wrote), then point {env} at that snapshot.json file. About four minutes for every pack.")


def snapshot_is_a_directory(path: str, env: str) -> str:
    return (f"{env} names a directory ({path}); point it at the snapshot.json file inside it, "
            f"the one governance_snapshot.py --out wrote.")


def model_unavailable(why) -> str:
    return (f"The assistant cannot run here: {why}. Install the anthropic package (pip install anthropic) "
            f"and set the key as docs/DEPLOYMENT.md says. Nothing was recorded.")


PRINCIPAL_LABEL = "Principal the platform forwards (e-mail)"
PRINCIPAL_HELP = ("Deployed, a person is admitted by the principal the platform forwards on every request, "
                  "usually the e-mail; the roster matches on it, never on the display name alone.")
DECLARE_PLACEHOLDER = "Choose"

# --- navigation in a scientist's words; the operator's sections behind one toggle ------------------
SECTION_LABELS = {"Home": "Home", "Status": "Evidence overview", "New product": "New product", "Open questions": "Questions to answer",
                  "Search & definitions": "Definitions and sources", "Studies": "Studies", "Waiting on a person": "Waiting on a person",
                  "Run gates": "Run checks", "Walkthrough": "Walkthrough", "Evidence packets": "Evidence packets", "Agent": "Technical assistant",
                  "Flow": "Progress and next step", "Plan changes": "Plan changes",
                  "Eval corpus": "Evaluations"}
MORE_TOGGLE = "Show technical tools and activity"
NAV_PRODUCT = "This product"
NAV_START = "Get started"
HEADER_NOT_CHECKED = "Not checked in this session yet. Open Progress and next step; the check takes up to a minute."
HEADER_FROM_SNAPSHOT = "from the saved status report"
HEADER_FROM_SNAPSHOT_EDITED = ("from the saved status report, made before this product was last edited; "
                               "open Progress and next step to check it again")
HOME_HERO_TITLE = "Start your first product"
HOME_HERO_TEXT = ("A product begins with a disease, a data source and a specification workbook. The portal walks it "
                  "through six stages: specification, definitions, sources, configuration, validation and release.")
HOME_CARD_OPEN = "Open"
HOME_CARD_UNCHECKED = "Open to check where this product stands."
FLOW_AUTO_CHECKING = "Checking where this product stands (up to a minute the first time)"

# --- Studies: which studies read this product, and what each reuses or reconsiders ----------------
STUDIES_CAPTION = ("Every study that reads this product, at which cut, and what it takes unchanged or reconsiders. "
                   "A study's decisions live in its own record (work/<study>/PINS.yaml); the product is never edited from here.")
STUDIES_NONE = "No study pins this product yet."
STUDIES_FIXTURE = "A reference fixture is never a study's data, so nothing pins it. Pick a product to see its studies."
STUDIES_STALE = "STALE: the product's contract moved since this study read it. A person re-reads it and records the refresh."
STUDIES_BUILD_STALE = ("This study pinned an exact published build, and that build is no longer what stands: its receipt "
                       "was superseded by a later refresh, or moved. A person re-reads the current build and refreshes "
                       "the pin with --build.")
STUDIES_SUPERSEDED = ("This cut is superseded. The study re-pins the current cut after a person reviews it, "
                      "or records that it knowingly reads the old one.")
STUDIES_DEPLOYED = ("Pinning is the study's act at a keyboard. This deployed portal hands you the exact command to run in "
                    "your checkout; commit work/<study>/PINS.yaml with your name on it.")
STUDIES_LOCAL = "In this local workspace the form runs the bound tool in your checkout; a refused command writes nothing."
STUDIES_PIN_FORM = "Pin this product to a study"
STUDIES_DECIDE_FORM = "Record a decision about one variable"
STUDIES_REFRESH_FORM = "Record that a study re-read this product"
STUDIES_REFRESH_HELP = ("The product moved since this study read it. After you have re-read the current definitions, record the refresh "
                        "under your name; the study keeps its own decisions.")
STUDIES_NO_STUDIES = ("No study exists yet. Use Start a study draft above to create the first one; "
                      "its protocol is completed and reviewed by the scientific owner before registration.")
STUDIES_NO_STUDIES_ASK = ("No study exists yet. A product initiator creates the first study draft from this page; "
                          "ask yours, then record the study's product choices here.")
STUDIES_NO_CONTRACT = "(the product carries no contract yet, so there is nothing to decide about)"


def no_pin(role):
    return f"Your role ({role}) does not pin products to studies. An initiator or a reviewer does."

# --- the deployed write: a branch and a pull request, never a file on the app ----------------------
NEW_PRODUCT_PR = "Open a pull request with it"
NEW_PRODUCT_PR_WORKING = "cloning the repository, standing the product up there, pushing a branch, opening the pull request"
NEW_PRODUCT_PR_DONE = ("Pull request opened: {url}. It is reviewed and merged by a person; the Gate 1 fields you typed "
                       "are authenticated by that signed merge.")
NEW_PRODUCT_PR_PUSHED = "Branch {branch} is pushed. {why}"
NEW_PRODUCT_PR_FAILED = "Nothing was proposed. {why}"
NEW_PRODUCT_PR_NOT_CONFIGURED = ("This deployed portal has no git remote and token configured, so it hands you the "
                                 "command to run in your checkout instead.")

# --- home: the products, their progress, the next step --------------------------------------------
HOME_TITLE = "Your products"
HOME_EMPTY = "No products yet. Start the first one; the reference packs below are worked examples, never products."
HOME_EMPTY_NO_REFERENCES = "No products yet. A product author can start the first one."
HOME_REFERENCES = "Reference packs (examples, never releasable)"
HOME_OPEN = "Open"
HOME_NEXT_UNKNOWN = "Open this product, then choose Check status to see its next step."


def gates_done_line(done: int, total: int = 6) -> str:
    return f"{done} of {total} gates passed"


def records_line(n: int) -> str:
    return f"{n} contract record(s)" if n else "no contract records yet"
