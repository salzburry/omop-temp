"""Save an explicitly selected set of compatible source mappings together.

The shared draft table owns the transaction. No per-row save is called, so an
outdated target or concurrent edit cannot leave a partially applied mapping.
"""
from __future__ import annotations

from copy import deepcopy

import yaml
from source_check import logical_parts

import variable_review_workflow as workflow

SHARED_FIELDS = {
    "source.kind", "source.logical_table", "source.physical_stem", "source.columns",
}
TREATMENT_LINE_ATTRIBUTES = {
    "regimen", "start_date", "delivered_end_date", "last_activity_date",
}


def _sync_primary_input(row, trial):
    """Update only the redundant main mapping; preserve each row's linked inputs.

    Canonical checks read inputs instead of columns whenever inputs is present.
    A batch therefore cannot leave its embedded primary entry at the old value,
    or overwrite an already-conflicting linked map by guessing which one wins.
    """
    original = row["values"]["source"]
    inputs = original.get("inputs")
    if inputs in (None, {}, [], ""):
        return None
    label = row.get("variable_id") or row["item_id"]
    if not isinstance(inputs, dict) or any(not isinstance(value, dict) for value in inputs.values()):
        raise ValueError(f"{label}: resolve the old input names into per-table Source inputs before sharing this mapping.")
    keys = {str(alias).strip().lower(): alias for alias in inputs}
    if len(keys) != len(inputs):
        raise ValueError(f"{label}: a source input alias is repeated. Resolve its linked mappings before sharing this source.")
    old = logical_parts(str(original.get("logical_table") or ""))
    new = logical_parts(str(trial["source"].get("logical_table") or ""))
    if len(new) != 1 or not trial["source"].get("columns"):
        raise ValueError(f"{label}: choose one main source alias and its columns before sharing linked source mappings.")
    if len(old) > 1:
        raise ValueError(f"{label}: resolve its combined main source into per-table inputs before sharing this mapping.")
    old_key = keys.get(old[0]) if old else None
    if old_key is not None and inputs[old_key] != original.get("columns"):
        raise ValueError(f"{label}: the embedded main source input disagrees with its displayed columns. "
                         "Resolve this row's main and linked mappings before sharing the source.")
    new_key = keys.get(new[0])
    if new_key is not None and new_key != old_key and inputs[new_key] != trial["source"]["columns"]:
        raise ValueError(f"{label}: the new main source alias already has a different linked mapping. "
                         "Resolve that row's source inputs before sharing the source.")
    result = deepcopy(inputs)
    if old_key is not None:
        result.pop(old_key)
    if new_key is not None:
        result.pop(new_key, None)
    result[new[0]] = deepcopy(trial["source"]["columns"])
    return result


def _targets(report, state, item_ids):
    if not isinstance(item_ids, list) or not item_ids or any(not isinstance(item, str) for item in item_ids):
        raise ValueError("Select the variables that should receive this source mapping.")
    if len(set(item_ids)) != len(item_ids):
        raise ValueError("Each selected source variable must appear once.")
    available = {row["item_id"]: row for row in report["rows"]}
    if any(item_id not in available for item_id in item_ids):
        raise ValueError("A selected variable is no longer in this product's shared table. Reload the table.")
    rows = [available[item_id] for item_id in item_ids]
    if len(rows) > 1:
        for row in rows:
            family = row.get("family") or {}
            saved = state["rows"].get(row["item_id"], {}).get("updates", {}).get("family") or {}
            if (family.get("name") != "treatment_line"
                    or family.get("attribute") not in TREATMENT_LINE_ATTRIBUTES
                    or saved.get("name") != "treatment_line"
                    or saved.get("attribute") != family.get("attribute")):
                raise ValueError("Share a source only between saved treatment-line regimen or date definitions. Map diagnosis and custom attributes separately.")
    return rows


def save_rows(root, pack, actor_id, item_ids, updates, *, expected_input_digest, expected_state_digest,
              allowed_packs=None, local_demo=False, can_write=False):
    """Atomically apply concrete source fields to all explicitly named targets."""
    if local_demo is not True or can_write is not True:
        return workflow._fail("Saving shared source mappings requires an authorized editing session.")
    try:
        workflow._validate_updates(updates, SHARED_FIELDS)
        _report, _state, path, _product = workflow._describe(root, pack, actor_id, allowed_packs)
        with workflow._locked(path):
            report, state, path, product = workflow._describe(root, pack, actor_id, allowed_packs)
            workflow._fresh(report, expected_input_digest, expected_state_digest)
            if report["phases"]["source"]["blocked_by"]:
                raise ValueError("Confirm the scientific table before sharing a source mapping.")
            rows = _targets(report, state, item_ids)
            prepared = []
            invalidated = "source"
            for row in rows:
                trial = deepcopy(row["values"])
                row_updates = deepcopy(updates)
                for key, value in row_updates.items():
                    workflow._put(trial, key, value)
                if workflow._get(trial, "source.kind") != "vendor":
                    raise ValueError("Shared table and column mappings require the delivered data column source kind.")
                primary_inputs = _sync_primary_input(row, trial)
                if primary_inputs is not None:
                    row_updates["source.inputs"] = primary_inputs
                    workflow._put(trial, "source.inputs", primary_inputs)
                workflow._normalized(trial)
                changed = {key: deepcopy(value) for key, value in row_updates.items()
                           if value != workflow._get(row["values"], key)}
                if not changed:
                    continue
                evidence = {}
                if "source.kind" in changed and row["source_kind_scientific"]:
                    invalidated = "science"
                    choices = deepcopy(row.get("field_choices") or {})
                    choices["source.kind"] = "edit"
                    row_updates["field_choices"] = choices
                    evidence["source.kind"] = {
                        "choice": "edit", "master_name": "", "source_path": "", "variant": "",
                        "value_digest": workflow.definitions._hash(updates["source.kind"]),
                    }
                prepared.append((row, row_updates, changed, evidence))
            result = {
                "ok": True, "errors": [], "changed": bool(prepared),
                "item_ids": list(item_ids), "variable_ids": [row["variable_id"] for row in rows],
                "selected_count": len(rows), "changed_count": len(prepared),
                "changed_item_ids": [row["item_id"] for row, *_rest in prepared],
                "draft_only": True, "approved": False, "approval_created": False,
            }
            if not prepared:
                return {**result, "message": "The selected variables already contain this source mapping."}
            timestamp = workflow._now()
            for row, row_updates, changed, evidence in prepared:
                saved = state["rows"].setdefault(row["item_id"], {
                    "updates": {}, "actor_id": actor_id.strip(), "updated_at": timestamp,
                })
                saved["updates"].update(row_updates)
                saved.setdefault("choice_evidence", {}).update(evidence)
                saved.update(actor_id=actor_id.strip(), updated_at=timestamp)
                if "source.kind" in changed:
                    saved["kind_owner"] = "science" if row["source_kind_scientific"] else "source"
            workflow._invalidate(state, invalidated, report)
            state["history"].append({
                "action": "save_source_rows", "phase": "source", "item_ids": list(item_ids),
                "fields_by_item": {row["item_id"]: sorted(changed) for row, _updates, changed, _evidence in prepared},
                "actor_id": actor_id.strip(), "at": timestamp, "input_digest": report["input_digest"],
            })
            workflow._write(root, product, path, state, report)
        return {**result, "message": f"Saved source mappings for {len(prepared)} selected variables.",
                "invalidated_from": invalidated}
    except (ValueError, TypeError, KeyError, AttributeError, OSError, RecursionError, yaml.YAMLError,
            workflow.definitions.dw._DraftError) as error:
        return workflow._fail(error)
