"""Inspect Git's index lock and recover an unchanged, abandoned empty lock.

Git locks do not record their owner. Recovery therefore requires an old empty
file, a complete process check with no Git process, and a fresh file identity.
It never stages files, changes the index, commits, or terminates a process.
"""
from __future__ import annotations

from contextlib import contextmanager
import hashlib
import json
import os
from pathlib import Path
import re
import stat
import subprocess
import time

MIN_AGE_SECONDS = 60


def _path(root):
    root = Path(root).resolve(strict=True)
    if any(os.environ.get(key) for key in ("GIT_DIR", "GIT_WORK_TREE", "GIT_INDEX_FILE")):
        raise ValueError("Git uses a custom repository or index location. Check that configuration before recovering a lock.")
    result = subprocess.run(["git", "-C", str(root), "rev-parse", "--absolute-git-dir"],
        capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=10)
    if result.returncode or not result.stdout.strip():
        raise ValueError("The repository's Git directory could not be verified.")
    directory = Path(result.stdout.strip())
    path = directory / "index.lock"
    if not directory.is_absolute() or path.resolve() != path.absolute():
        raise ValueError("The Git lock location redirects to another folder. Keep it for inspection.")
    return path


def _git_running():
    """Any local Git process blocks recovery; unknown process state also refuses."""
    if os.name == "nt":
        import ctypes
        from ctypes import wintypes as w

        class ProcessEntry(ctypes.Structure):
            _fields_ = [("dwSize", w.DWORD), ("cntUsage", w.DWORD), ("th32ProcessID", w.DWORD),
                        ("th32DefaultHeapID", ctypes.c_size_t), ("th32ModuleID", w.DWORD),
                        ("cntThreads", w.DWORD), ("th32ParentProcessID", w.DWORD),
                        ("pcPriClassBase", w.LONG), ("dwFlags", w.DWORD), ("szExeFile", w.WCHAR * 260)]

        kernel = ctypes.WinDLL("kernel32", use_last_error=True)
        kernel.CreateToolhelp32Snapshot.argtypes = [w.DWORD, w.DWORD]
        kernel.CreateToolhelp32Snapshot.restype = w.HANDLE
        for function in (kernel.Process32FirstW, kernel.Process32NextW):
            function.argtypes = [w.HANDLE, ctypes.POINTER(ProcessEntry)]
            function.restype = w.BOOL
        kernel.CloseHandle.argtypes = [w.HANDLE]
        kernel.CloseHandle.restype = w.BOOL
        # Snapshot executable names only; no command lines, process handles, or
        # subprocess launch. A partial enumeration must never permit recovery.
        snapshot = kernel.CreateToolhelp32Snapshot(0x00000002, 0)  # TH32CS_SNAPPROCESS
        if snapshot in (None, 0, ctypes.c_void_p(-1).value):
            raise OSError("The running Git processes could not be checked.")
        try:
            entry = ProcessEntry()
            entry.dwSize = ctypes.sizeof(entry)
            if not kernel.Process32FirstW(snapshot, ctypes.byref(entry)):
                raise OSError("The process list is incomplete.")
            names = []
            while True:
                if not entry.szExeFile:
                    raise OSError("The process list contains an unknown executable.")
                names.append(entry.szExeFile.lower())
                ctypes.set_last_error(0)
                if not kernel.Process32NextW(snapshot, ctypes.byref(entry)):
                    if ctypes.get_last_error() != 18:  # ERROR_NO_MORE_FILES
                        raise OSError("The process list is incomplete.")
                    break
        finally:
            if not kernel.CloseHandle(snapshot):
                raise OSError("The process snapshot could not be closed.")
    else:
        result = subprocess.run(["ps", "-A", "-o", "comm="], capture_output=True, text=True,
                                encoding="utf-8", errors="replace", timeout=10)
        if result.returncode or not result.stdout.strip():
            raise OSError("The running Git processes could not be checked.")
        names = [Path(name.strip()).name.lower() for name in result.stdout.splitlines()]
    return any(re.fullmatch(r"git(?:\.exe)?|git-.+", name) for name in names)


def _fingerprint(path, info):
    # Windows Python 3.12+ exposes creation time explicitly. Its deprecated
    # ctime can differ between lstat (creation) and fstat (metadata change),
    # even for the same unchanged file. Older Windows Python uses ctime for both.
    identity_time = getattr(info, "st_birthtime_ns", info.st_ctime_ns) if os.name == "nt" else info.st_ctime_ns
    return hashlib.sha256(json.dumps([str(path), info.st_dev, info.st_ino, info.st_size,
        info.st_mtime_ns, identity_time]).encode()).hexdigest()


def _report(state, message, fingerprint=None):
    return {"state": state, "message": message, "can_recover": state == "recoverable", "fingerprint": fingerprint}


def inspect(root):
    try:
        path = _path(root)
        try:
            info = path.lstat()
        except FileNotFoundError:
            return _report("absent", "Git is available. Choose Record these files in history when ready.")
        if not stat.S_ISREG(info.st_mode) or info.st_nlink != 1:
            return _report("unavailable", "The Git lock is not an ordinary private file. Keep it for inspection.")
        token = _fingerprint(path, info)
        if _git_running():
            return _report("busy", "A Git operation is running. Let it finish, then choose Check Git lock again.", token)
        if info.st_size:
            return _report("nonempty", "The Git lock contains an unfinished index. Its contents are preserved; inspect the Git operation before retrying.", token)
        if time.time() - max(info.st_mtime, info.st_ctime) < MIN_AGE_SECONDS:
            return _report("recent", "This Git lock was created or changed recently. Wait briefly, then choose Check Git lock again.", token)
        return _report("recoverable", "An old empty Git lock remains and no Git process is running. Release stale Git lock, then record the files again.", token)
    except (OSError, ValueError, subprocess.SubprocessError):
        return _report("unavailable", "The Git lock could not be checked safely. Keep the current files and choose Check Git lock again.")


@contextmanager
def _opened(path):
    if os.name != "nt":
        descriptor = os.open(path, os.O_RDWR | getattr(os, "O_NOFOLLOW", 0))
        try:
            yield descriptor, lambda: path.unlink()
        finally:
            os.close(descriptor)
        return
    import ctypes
    from ctypes import wintypes as w
    import msvcrt
    kernel = ctypes.WinDLL("kernel32", use_last_error=True)
    kernel.CreateFileW.argtypes = [w.LPCWSTR, w.DWORD, w.DWORD, ctypes.c_void_p, w.DWORD, w.DWORD, w.HANDLE]
    kernel.CreateFileW.restype = w.HANDLE
    kernel.CloseHandle.argtypes = [w.HANDLE]
    # Exclusive sharing rejects an existing owner, including a non-Git writer.
    # OPEN_REPARSE_POINT prevents following a lock replaced with a symlink.
    handle = kernel.CreateFileW(str(path), 0xC0010000, 0, None, 3, 0x00200000, None)
    if handle == ctypes.c_void_p(-1).value:
        raise OSError("The lock is in use or could not be opened exclusively.")
    try:
        descriptor = msvcrt.open_osfhandle(handle, os.O_RDWR | os.O_BINARY)
    except Exception:
        kernel.CloseHandle(handle)
        raise
    try:
        def remove():
            # Delete this verified file through its handle, avoiding an
            # unlock/unlink race against a replacement at the same path.
            kernel.SetFileInformationByHandle.argtypes = [w.HANDLE, ctypes.c_int, ctypes.c_void_p, w.DWORD]
            kernel.SetFileInformationByHandle.restype = w.BOOL
            delete = ctypes.c_ubyte(1)  # FILE_DISPOSITION_INFO.DeleteFile
            if not kernel.SetFileInformationByHandle(handle, 4, ctypes.byref(delete), ctypes.sizeof(delete)):
                raise OSError("The stale lock could not be released.")
        yield descriptor, remove
    finally:
        os.close(descriptor)


def recover(root, *, expected_fingerprint, confirmed=False, can_write=False):
    if not confirmed or not can_write:
        raise ValueError("Releasing a stale Git lock needs an explicit request with product-author access.")
    current = inspect(root)
    if not current["can_recover"] or not expected_fingerprint or current["fingerprint"] != expected_fingerprint:
        raise ValueError("The Git lock changed or is not safe to release. Check Git lock again.")
    path = _path(root)
    with _opened(path) as (descriptor, remove):
        info = os.fstat(descriptor)
        if (_fingerprint(path, info) != expected_fingerprint or info.st_size or not stat.S_ISREG(info.st_mode)
                or _git_running() or _fingerprint(path, path.lstat()) != expected_fingerprint):
            raise ValueError("The lock or running Git operations changed. The lock was kept.")
        remove()
    return inspect(root)
