"""Turn explicit reviewed choices into the existing configuration proposal flow.

The compiler prepares supported settings and native output bindings. It never
interprets arbitrary scientific prose, installs code, approves a contract or
changes the live configuration. The proposal retains its shared-review binding.
"""
from __future__ import annotations

from copy import deepcopy
from pathlib import Path

import yaml

import configuration_proposals as proposals
import variable_review_workflow as workflow
from engine.config import load_config


def _fail(error):
    return {"ok": False, "changed": False, "errors": [str(error)], "approved": False,
            "released": False, "implementation_created": False}


def _prepare(root, pack, actor_id, allowed_packs):
    import variable_execution_rules
    report, _state, _path, product = workflow._describe(root, pack, actor_id, allowed_packs)
    description = proposals.dw.describe(root, pack)
    if description["errors"]:
        raise ValueError(" ".join(description["errors"]))
    parameters = proposals.supported_parameters(root, pack)
    cfg = load_config(product / "config/data_product.yaml")
    plan = variable_execution_rules.build(report, cfg, parameters)
    files, unsupported = proposals._compose(product, plan["configuration_changes"]) if plan["configuration_changes"] else ([], [])
    for item in unsupported:
        plan["blockers"].append({"item_id": "", "variable_id": "", "message": item["reason"]})
    review_confirmed = report["current_phase"] == "complete"
    result = {**plan, "ok": True, "errors": [], "input_digest": report["input_digest"],
              "state_digest": report["state_digest"], "baseline_sha256": description["baseline_sha256"],
              "settings": [{"ref": change["ref"], "label": parameters[change["ref"]][0],
                            "current": parameters[change["ref"]][2], "proposed": change["value"]}
                           for change in plan["configuration_changes"] if change["ref"] in parameters],
              "files": files, "review_confirmed": review_confirmed,
              "can_stage": review_confirmed and bool(files or plan["blockers"]) and not unsupported,
              "draft_only": True, "approved": False, "released": False, "implementation_created": False}
    result["plan_digest"] = workflow.definitions._hash(result)
    # Refuse to display a combination of configuration and review versions.
    if workflow._input_digest(Path(root).resolve(), product) != report["input_digest"]:
        raise ValueError("The reviewed definitions or configuration changed while preparing these settings. Reload the preview.")
    return result, report, description


def describe(root, pack, actor_id, *, allowed_packs=None):
    try:
        return _prepare(root, pack, actor_id, allowed_packs)[0]
    except (ValueError, TypeError, KeyError, AttributeError, OSError, RecursionError, yaml.YAMLError) as error:
        return _fail(error)


def _fresh(plan, expected_input_digest, expected_state_digest, expected_plan_digest):
    if any(not expected or plan.get(name) != expected for name, expected in (
            ("input_digest", expected_input_digest), ("state_digest", expected_state_digest),
            ("plan_digest", expected_plan_digest))):
        raise ValueError("The reviewed definitions or proposed settings changed. Reload and review the current preview.")


def stage(root, pack, actor_id, *, expected_input_digest, expected_state_digest, expected_plan_digest,
          confirmed=False, local_demo=False, can_write=False, allowed_packs=None):
    if not (confirmed is True and local_demo is True and can_write is True):
        return _fail("Preparing execution settings requires an authorized editor and the displayed preview choice.")
    try:
        plan, report, description = _prepare(root, pack, actor_id, allowed_packs)
        _fresh(plan, expected_input_digest, expected_state_digest, expected_plan_digest)
        if not plan["review_confirmed"]:
            raise ValueError("Confirm the scientific, source and output tables before staging their execution settings.")
        if not plan["can_stage"]:
            raise ValueError("There are no configuration changes or implementation items to stage. Continue with the existing configuration checks.")
        pending = sum(row["status"] != "supported" for row in plan["rows"])
        purpose = "Apply supported settings from the reviewed variable table."
        if pending:
            purpose += f" {pending} variable(s) still require output binding or implementation review."
        brief = proposals.dw.build_plan(description,
            retained=[row["variable_id"] for row in description["rows"]], additions=[], purpose=purpose,
            studies=[], target_source=description["source"]["vendor"], target_modality=description["source"]["modality"])
        result = proposals.stage(root, pack, brief, configuration_changes=deepcopy(plan["configuration_changes"]),
            study_exclusions=[], actor_id=actor_id, local_demo=True, can_write=True,
            expected_baseline=description["baseline_sha256"], allowed_packs=allowed_packs,
            variable_review_binding={"input_digest": report["input_digest"], "state_digest": report["state_digest"]})
        return {**result, "implementation_created": False, "approved": False, "released": False}
    except (ValueError, TypeError, KeyError, AttributeError, OSError, RecursionError, yaml.YAMLError) as error:
        return _fail(error)


def use_engine_output(root, pack, actor_id, item_id, *, expected_input_digest, expected_state_digest,
                      expected_plan_digest, confirmed=False, local_demo=False, can_write=False, allowed_packs=None):
    if not (confirmed is True and local_demo is True and can_write is True):
        return _fail("Choosing the engine output requires an authorized editor and the displayed binding choice.")
    try:
        plan, _report, _description = _prepare(root, pack, actor_id, allowed_packs)
        _fresh(plan, expected_input_digest, expected_state_digest, expected_plan_digest)
        row = next((row for row in plan["rows"] if row["item_id"] == item_id), None)
        if not row or row["status"] != "needs_output_binding" or not row["output_updates"]:
            raise ValueError("Choose a variable with an explicit native engine output suggestion.")
        return workflow.save_row(root, pack, actor_id, item_id, "output", deepcopy(row["output_updates"]),
            expected_input_digest=plan["input_digest"], expected_state_digest=plan["state_digest"],
            allowed_packs=allowed_packs, local_demo=True, can_write=True)
    except (ValueError, TypeError, KeyError, AttributeError, OSError, RecursionError, yaml.YAMLError) as error:
        return _fail(error)
