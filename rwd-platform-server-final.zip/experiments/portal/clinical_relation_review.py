"""Bounded clinical relation views from the existing licensed reference readers."""
from __future__ import annotations

import umls_relations as relations

LIMIT = 100


def describe(*, query, bound_concept=None):
    empty = {"available": False, "query": query, "concepts": [], "sets": [], "groups": {},
             "findings": [], "release": ""}
    try:
        if not isinstance(query, str) or len(query) > 100:
            raise ValueError()
        doc = relations.load()  # Honors LAYER.yaml; never opens licensed archives.
        if doc is None:
            return {**empty, "findings": ["The terminology relation layer is disabled or unavailable. Ask the terminology steward to prepare its licensed reference projection; other clinical bindings remain available."]}
        if not isinstance(doc, dict) or relations.layer_errors(doc):
            raise ValueError()
        for partners in (doc.get("diseases") or {}).values():
            seen = set()
            for raw in partners or []:
                partner = relations.edge(doc, raw)
                key = (partner.get("cui"), partner.get("axis"))
                if key in seen:
                    # The projected builder aggregates modalities into one
                    # edge. The query helper keeps only the first duplicate,
                    # which could silently discard a later refutation.
                    raise ValueError()
                seen.add(key)
        sets, errors = relations.concept_sets()
        set_errors = relations.set_errors(doc)
        _local, local_errors = relations.local_assertions()
        # Invalid local declarations cannot be merged into a valid projection.
        local_ok = not local_errors and not relations.local_errors(doc)
        findings = []
        if errors or set_errors:
            findings.append("Recorded concept sets need terminology-steward repair. No invalid set is offered for a product binding.")
            sets = []
        unique_sets = []
        for entry in sets:
            cuis = entry["concept_cuis"]
            if len(cuis) != len(set(cuis)):
                # The canonical member lookup takes the first matching CUI.
                # Repeated identifiers could therefore hide a later excluded
                # status or make one unique concept look like a union.
                findings.append("A recorded concept set repeats a concept identifier. Ask the terminology steward to resolve its member states; that ambiguous set is not offered.")
                continue
            unique_sets.append(entry)
        sets = unique_sets
        if not local_ok:
            findings.append("Local relation assertions need terminology-steward repair; only the projected relation evidence is shown.")
        choices = [(cui, name) for cui, name, _count in relations.find(doc, query, limit=12)]
        if bound_concept in (doc.get("concepts") or {}) and bound_concept not in {cui for cui, _ in choices}:
            choices.insert(0, (bound_concept, relations.name_of(doc, bound_concept)))
        groups, concepts, offered_sets = {}, [], []

        def partners_for_members(cuis):
            # The canonical union lookup deduplicates a partner on first
            # occurrence. A review must retain contradictory evidence from a
            # different member or a local assertion, so query each channel and
            # each explicit member with the same canonical decoder instead.
            partners = []
            local_doc = {**doc, "diseases": {}}
            for cui in cuis:
                if local_ok:
                    partners.extend(dict(p, via_concept=cui) for p in relations.partners_for(
                        local_doc, cui, modalities=relations.MODALITIES, inherit=False, local=True))
                partners.extend(dict(p, via_concept=cui) for p in relations.partners_for(
                    doc, cui, modalities=relations.MODALITIES, inherit=False, local=False))
            return partners

        def rows(partners):
            return [{"partner": p["cui"], "name": p.get("name") or p["cui"], "axis": p.get("axis"),
                     "modalities": list(p.get("modalities") or [p.get("modality")]),
                     "conflict": bool(p.get("conflict")), "source": p.get("source"),
                     "source_vocabularies": list(p.get("sab") or []), "relations": list(p.get("rela") or []),
                     "from_concept": p.get("from_concept"), "via_concept": p.get("via_concept"),
                     "inherited": bool(p.get("inherited")), "citation": p.get("citation") or "",
                     "basis": p.get("basis") or ""} for p in partners[:LIMIT]]

        for cui, name in choices[:12]:
            partners = partners_for_members([cui])
            key = "concept:" + cui
            concepts.append({"key": key, "cui": cui, "name": name or cui})
            groups[key] = {"rows": rows(partners), "total": len(partners), "omitted": max(0, len(partners) - LIMIT)}
        for entry in sets[:LIMIT]:
            if len(entry["concept_cuis"]) > LIMIT:
                findings.append("A large concept set is omitted from this bounded view. Review it with the terminology steward.")
                continue
            members = [{"cui": cui, "name": relations.name_of(doc, cui) or cui,
                        "status": relations.member_status(entry, cui)} for cui in entry["concept_cuis"]]
            active = relations.in_scope(entry)
            partners = partners_for_members(active)
            key = "set:" + str(entry["name"])
            offered_sets.append({"key": key, "name": entry["name"], "members": members, "active": active,
                "basis": entry["basis"], "citation": entry["citation"],
                "asserted_by": entry["asserted_by"], "asserted_on": str(entry["asserted_on"])})
            groups[key] = {"rows": rows(partners), "total": len(partners), "omitted": max(0, len(partners) - LIMIT)}
        if len(sets) > LIMIT:
            findings.append("Only the first 100 recorded sets are offered in this bounded view.")
        return {"available": True, "query": query, "concepts": concepts, "sets": offered_sets,
                "groups": groups, "findings": sorted(set(findings)), "release": str(doc.get("release") or "")}
    except (Exception, SystemExit):
        return {**empty, "findings": ["The terminology relation reference is malformed or inconsistent. Ask the terminology steward to repair it; no relation or set binding is offered from these bytes."]}
