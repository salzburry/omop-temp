@echo off
setlocal
if defined RWD_PORTAL_PYTHON goto selected_environment
if exist "%~dp0.venv313\Scripts\python.exe" (
    set "rwd_portal_python=%~dp0.venv313\Scripts\python.exe"
    goto launch
)
if exist "%~dp0.venv\Scripts\python.exe" (
    set "rwd_portal_python=%~dp0.venv\Scripts\python.exe"
    goto launch
)
py -3.13 "%~dp0experiments\portal\launch_portal.py" %*
set "rwd_portal_exit=%ERRORLEVEL%"
if not "%rwd_portal_exit%"=="0" goto missing_environment
exit /b 0

:selected_environment
set "rwd_portal_python=%RWD_PORTAL_PYTHON%"
if not exist "%rwd_portal_python%" goto missing_environment

:launch
"%rwd_portal_python%" "%~dp0experiments\portal\launch_portal.py" %*
set "rwd_portal_exit=%ERRORLEVEL%"
if not "%rwd_portal_exit%"=="0" pause
exit /b %rwd_portal_exit%

:missing_environment
echo The selected Python 3.13 environment could not be used.
echo Ask your data expert to open PowerShell in this repository and run these once:
echo.
echo py -3.13 -m venv .venv313
echo If that launcher tag is unavailable, run py -0p and use a listed Python 3.13 executable's full path.
echo .\.venv313\Scripts\python.exe -m pip install -c experiments/portal/environment.constraints.txt -r requirements.txt -r platform/requirements.txt
echo To use your existing environment, set RWD_PORTAL_PYTHON to its python.exe path.
echo In VS Code, select that interpreter and use a RWD Portal launch configuration.
echo Use a short local checkout path outside synchronized folders.
echo Stop if environment creation fails. See docs\LOCAL_INSTALLATION.md for recovery.
echo These requirements include the test runner used by the workflow's checks.
echo.
echo Then double-click Start-RwdPortal.cmd again.
echo No packages have been installed or changed by this launcher.
pause
exit /b 1
