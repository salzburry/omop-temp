---
name: operate-rwd-product
version: "1.3.2"   # bump on any change to the skill's INSTRUCTIONS — the version guard
                   # holds .claude/skills to platform/VERSION, and this names which
                   # instruction set a session ran; the commit SHA pins the exact bytes
description: >
  Report where an RWD data product stands — which gates have passed, what is blocking the next one,
  who owes the next action, and what has actually been demonstrated. Read-only: it runs the gate and
  status tools and reports what they printed, and writes nothing to the repository. Use for "where
  does prostate stand", "what is blocking us", "what do I run next", "is this ready", "who needs to
  do what", or when someone asks for a status page. Do NOT use to draft or revise contract records
  (that is draft-contract-record), to approve anything, or to run a build.
---

# Where a product stands

A front door, not a seventh gate. Every number here is printed by the tool that owns it; this reads
those tools and reports what they said. It never edits, approves, promotes, or regenerates.

In the portal, the selected product and current task are supplied by the page. Explain unfamiliar
concepts and compare approaches in plain language when asked, labelling general background and
hypothetical examples. Ask one or two consequential questions at a time, with understandable
alternatives and room for an unsure or typed answer. General discussion is not a new evidence or
approval requirement. Product-specific facts, source availability, test results and completion
claims still require supplied evidence. Route implementation and mapping requests into the
existing specialist with the person's request; a page summary alone does not supply its code or
source dictionary. Earlier chat is discussion, not a saved decision or proof that work ran.

## 1. Which pack

If the request does not name one, **ask** — do not pick the newest. Offer the real list:

```bash
python3 platform/tools/product_gates.py --list-contracts
```

Ask with a chooser rather than a sentence, so nobody types a version:

> Use `AskUserQuestion` with one option per pack the command returned.

A row number, a variable name and a source mapping are all version-specific, so a status reported
against the wrong pack is wrong in a way that reads as correct.

## 2. The one command

```bash
python3 platform/tools/status.py <pack>
```

That is the whole status: the six gates with their states and blockers, the stakeholder measures
(captured / approved / validated, kept separate on purpose), the four demonstration claims, and the
single next action with its owner.

For every pack at once, one line each:

```bash
python3 platform/tools/status.py
```

Machine-readable, when something else consumes it:

```bash
python3 platform/tools/status.py <pack> --json
```

## 3. Report what it printed

Say the state, the next action, and **who owns it** — the owner is the part people act on. Quote the
blockers rather than summarising them: they are worded to be actionable and a paraphrase loses that.

**One thing per reply.** The status view IS the answer — do not also print the worksheet, the
decision ranking, or the contents of `handoff/` alongside it, and never enumerate that folder for a
stakeholder: it is the ledger behind the tools, not a menu. If the person wants to go deeper, §5
has the routes — run **one** of them per turn, when asked.

Three things must never be collapsed, because collapsing them is the specific way this product gets
overstated:

- **Captured is not approved.** 202/202 captured with 0/202 approved is a real and common state.
- **Gate 1 is three states**, not one — AI access to the extraction, the authoritative workbook, and
  the extraction basis. The slice prints all three.
- **The four demonstration claims** — framework demonstration, synthetic execution, live execution,
  governed production release — are reported together, *including the ones not reached*.

## 4. If they want a page

```bash
python3 platform/tools/render_html.py flow <pack> --out <dir outside the repo>/flow.html
```

`--out` is **required and refused inside the checkout**. That is not a preference: a saved page is
the shape restricted output gets captured in, and `repo_hygiene` never commits `*.html`. Pick a path
under the user's home, not under the repository.

The page carries the same measures and claims as the terminal view, from the same functions.

## 5. Going deeper, still read-only

| what is blocking us, ranked | `python3 platform/tools/worksheet.py <pack>` |
| which decisions unblock the most records | `python3 platform/tools/decision_report.py <pack>` |
| a page per open question, for the person who must answer it | `python3 platform/tools/decision_packet.py <pack> --text` — or `--out <dir outside the repo>/questions.html`; §4's rule applies here too, and this tool has no built-in refusal, so the instruction is the only guard |
| is the contract's GENERATED FACTS fence current | `python3 platform/tools/finalize.py <pack> --check` — stale numbers are invisible to `status.py`'s summary |
| what the executable YAML change does since a base revision | `python3 platform/tools/config_diff.py <pack> --base <rev>` — dropped/added/changed keys as sentences, not hunks |
| does the contract's source structure still hold | `python3 platform/tools/source_check.py <pack> --structure-only --check` |
| which variables die if a source table is missing — the role -> table -> columns -> variables chain in one page | `python3 platform/tools/source_requirements.py <pack>` — generated from the config, the engine's own required_columns() and the contract, never maintained. `--check` refuses a role a governed block READS that the pack never DECLARES (the silent-null shape a live mCRC trial hit on HER2) unless the pack's `source_availability:` block dispositions it — `optional`, or `unavailable_by_design` with a reason and decision_id; a strict build (`engine.validate.problems(strict=True)`) blocks on the same rule, same implementation; `--format json` for tooling. Grain shows `(not declared)` because no artifact declares it yet — an honest gap, not an omission |
| what other products decided when they hit the same question | `python3 platform/tools/precedents.py --for <pack>` |
| have we decided something LIKE this before, anywhere — with the answer, approver and citations | `python3 platform/tools/knowledge_graph.py --query <terms>` (or `--decision <ID>`) — a live view over the registers, never a store |
| what does the whole repository know about X — and which of it can SETTLE anything | `python3 platform/tools/knowledge_search.py <terms>` — decisions, precedents, contract records, the variable inventory, capabilities and citations in one pass, ordered by DOMAIN (product_ruling · implementation_evidence · literature · provenance) then STATE (signed · unsigned · open · declared · reference_only). Different KINDS of authority, not degrees: engine evidence never settles a methodology question. A surface its own validator refuses is excluded, not ranked. Nothing it returns is an approval |
| one rule three ways (spec words · interpretation · the YAML that runs), for a Gate 4 reviewer | `python3 platform/tools/rule_review.py <pack>` |
| which records carry to a new spec revision, on digest evidence | `python3 platform/tools/spec_diff.py <old> <new>` |
| is this pack ready for a pilot run, and if not WHAT exactly is missing | `python3 platform/tools/pilot_readiness.py <pack>` — environment, registration, extraction, bindings, execution evidence and gates in one read-only answer. It composes the owners rather than re-deriving them, and UNKNOWN is a third state: evidence written outside the checkout cannot be seen from here, and it says so instead of reporting NO |
| what actually stands behind each executable config block | `python3 platform/tools/config_propose.py <pack>` — `confirmed` · `changed` · `unresolved` · `unsupported`, per governed block, with the specification rows. `confirmed` means the workbook REACHED the block; Gate 4 decides whether the values are right. A scaffold pack reads "There is no contract — all N blocks are unsupported", which is the one sentence that stops inferred YAML being shown as generated output |
| a specification row moved — what is now unverified | `python3 platform/tools/change_impact.py <pack> clinical:12 …` — walks row → contract record → config block → capability → published column → the goldens that must be re-run. It reports REACH, not risk, and a row NO record cites is a finding rather than an empty result. Pair it with `spec_diff.py`, which says WHICH rows moved |
| what would still block a release if the pack claimed approval today | `python3 platform/tools/dry_run.py <pack>` |
| the whole lifecycle, gate by gate, against the real tools | `python3 platform/tools/demo.py <pack>` |

`dry_run.py` is the one worth reaching for when someone asks "how far are we really" — it reports
the blockers that appear only once a pack CLAIMS approval, which are invisible until then.

## What this skill never does

- **Never writes to the repository.** Not a status, not a maturity level, not a decision's
  resolution. If the answer to a question is "someone must edit a governed file", say so and stop.
- **Never approves.** Gates 2, 4 and 6 take a named human in a form. No tool may fill one in.
- **Never regenerates.** `run_spec_pipeline.py <pack>` without `--check` rewrites seven governed
  artifacts; stale artifacts are a finding to report, not to fix on the way past.
- **Never runs a build**, and never reads vendor material — profiles, schema reports and delivered
  data are outside this entirely.
- **Never answers a clinical question.** "What should the window be" is Science's, and the honest reply
  names the open decision.

If a request needs any of those, hand it back by NAME — the blocked state names its owner:

| what status shows | the owning route | the human act in it |
|---|---|---|
| open decisions block records | the `answer-decisions` skill / `decision_record.py` | Science fills and signs the committed answer forms |
| records need drafting or re-dispositioning | the `draft-contract-record` skill / `contract_record.py` | DataExpert's drafting judgment; approvals stay human |
| a committed Gate 3 verdict report is not yet in the contract | the `apply-source-verdicts` skill / `contract_record.py` | the profile-holder wrote the report; `confirmed_mappings` rationale is theirs |
| a pack has source gaps and a profile TSV exists — what could supply each missing role | the `propose-source-mapping` skill / `python3 platform/tools/propose_source_mapping.py <pack> --profile <tsv>` | evidence and blockers only; applying a mapping is a person's reviewed edit, and semantic equivalence is DataExpert/Science's question |
| a revised workbook arrived | the `next-cut` skill / `spec_diff.py` | Gate 1 registration of the new workbook |
| stale pipeline artifacts, a stale facts fence | `run_spec_pipeline.py` — this skill runs only its `--check` form | whoever owns the pack regenerates and commits |
| an approval, a maturity claim, a RESOLVED status | no tool fills these in | a named person, in the governed file |
