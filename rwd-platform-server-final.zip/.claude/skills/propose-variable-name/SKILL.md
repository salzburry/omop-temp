---
name: propose-variable-name
version: "1.0.0"   # bump on any change to the skill's INSTRUCTIONS — the version guard
                   # holds .claude/skills to platform/VERSION, and this names which
                   # instruction set a session ran; the commit SHA pins the exact bytes
description: >
  Keep variable names standard across packs: when a spec or a person introduces a new variable
  name, look it up in the cross-pack naming registry, recommend the existing standard name when
  one plausibly covers the concept, and draft the naming question for DataExpert/Science when it is not
  mechanical. Also reads the open naming docket ("what naming questions are open", "does
  agegrp already exist", "what should this variable be called"). NEVER use to decide that two
  names mean the same concept, to write or edit governance/NAMING_RULINGS.yaml, to rename a
  column in any config or contract, or to set name_status. If the request names no pack or no
  proposed name, ask.
---

# Proposing variable names — the standard is the path of least resistance

Specifications are written by different people, and two of them will name one concept two ways:
`agegrp` here, `age_group` there, `region1` (digit one) beside `regionl` (letter el) — the last
pair is not hypothetical; the registry's first sweep found it live. Once a name is CONFIRMED in
an approved contract it is LOCKED: changing it, or adding a look-alike beside it, is a governed
act with a human ruling, never a drafting convenience.

The workflow this skill drives, and where it stops:

    AI looks the proposed name up and recommends
    → deterministic near-miss grammar (naming_registry.py)
    → DataExpert/Science rules; a person records the ruling
    → the ruling is precedent every later pack sees automatically

## 1. Look it up before anything is drafted

    python3 platform/tools/naming_registry.py                 # registry + the open docket
    python3 platform/tools/naming_registry.py --format json

The registry compiles every pack's contract `output` axis plus the engine's own emitted names.
For a proposed name, three mechanical outcomes:

  * **exact match** — the concept may already exist. Recommend REUSING the existing name and its
    record as the drafting base; whether it is truly the same concept is the human's read.
  * **near-miss** (the grammar flags it against an existing name) — do not draft it as new.
    Recommend the existing standard spelling, and if the author believes it is genuinely a
    different concept, draft the naming question instead (step 3).
  * **clean** — a genuinely new name. Say so, and note the convention the new name should
    follow (label/code `x`/`xn`, date `xdt`, year `xyr`, banded `xgr…`, per-setting `x_<s>`),
    so the next tool sees its twins as convention, not drift.

The FORMAT rides with the name: the registry also reports a name declared `character` in one
spec and `numeric` in another (`type_conflicts` in the JSON). That one needs no naming ruling —
the fix is a contract revision on whichever record diverged, and the label/code twin (`x` char,
`xn` numeric) is the convention when both are genuinely needed. Recommend which; a person edits.

## 2. What the grammar already knows — do not re-litigate it

Conventional twins are the standard WORKING and never flagged: `agegrl`/`agegrln`,
`bone_met`/`bone_metdt`, `lot1sd_mcrpc`/`lot1sd_mhspc`. A pair the grammar DOES flag is close
enough to be one concept spelled twice — that is evidence for a question, not a verdict.

## 3. Draft the question, hand over the ruling

A flagged pair, or a deliberate wish to diverge from an existing name, becomes a decision-shaped
question with the registry's evidence attached: where each name lives, its name_status, its
variable_ids. Route it like every other decision (the answer-decisions skill owns that path).
The ANSWER lands in `governance/NAMING_RULINGS.yaml` as a named person's dated ruling
(`use_existing` / `distinct_concepts` / `alias_accepted`) — **this skill never writes that file**,
exactly as no session types a decision answer. A ruling covers the pair's twin families, so one
answer settles the whole family.

## 4. A name being retired is the same act, one axis over

Dropping a name at the next cut is not a deletion — it is a retirement, recorded in
`governance/NAME_LIFECYCLE.yaml` so the successor is named and the spelling can never be minted
later for a different concept (`naming_registry.py --retire <name>` prints the draft with the
machine half filled). Reuse is the failure this prevents: the same name meaning something new
re-points every decision and precedent written against the old meaning, silently. The same file
records an enterprise IRI beside a name if one has been minted elsewhere — recorded, never
minted here.

## What this skill never does

Rule that two names are one concept. Write or edit NAMING_RULINGS.yaml, NAME_LIFECYCLE.yaml, any
contract record's name fields, or any config — retiring a name and binding it to an identifier
are a named person's dated acts, like every ruling. Invent a name for a concept whose spec row it
has not seen. Present a grammar flag as anything stronger than a question with counted evidence.
