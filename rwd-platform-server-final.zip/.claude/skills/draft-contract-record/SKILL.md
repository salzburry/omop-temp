---
name: draft-contract-record
version: "1.3.7"   # bump on any change to the skill's INSTRUCTIONS — the version guard
                   # holds .claude/skills to platform/VERSION, and this names which
                   # instruction set a session ran; the commit SHA pins the exact bytes
description: >
  Draft, revise, or audit Gate 2 functional-contract records from specification rows in an
  explicitly named product pack under products/. Use for contract creation, specification
  traceability, specification revisions, and decision-required contract rows. Defaults to
  read-only. Do not use for source verification, YAML implementation, engine changes, validation,
  or release unless contract requirements are also being revised or audited. Never infer the
  tumour or the version — if the request does not name a pack, ask.
---

# Drafting a functional-contract record

`REFERENCE.md` holds the field meanings, vocabularies, invariant explanations, engine vocabulary,
source shapes and worked records. Look things up there; this file governs the run.

In row chat, answer explanatory questions directly without making a generic explanation a field
value. The current request controls the response: when it asks to draft or revise a field, return
proposed wording using the supplied editor-label mapping even if an earlier request asked only for an explanation. Prior
requests are context, not continuing instructions. Prior requests, answers and unaccepted proposed
wording are not specification evidence. Preserve assumptions and questions. A quotation must
support the specific rule: naming a measure does not settle missing values, timing or ties. Keep
unsupported choices visibly TODO. The user chooses fields to copy into an unfinished draft, then
validates and reviews a separate contract diff. Conversation does not save or approve a definition.
In conversation, explain unfamiliar concepts and compare possible approaches before asking for a
decision. Clearly label general educational background; it is not a fact about this specification,
a verified code list or a source mapping. Use supplied eligible study context and prior examples
with their references and status, identifying what each actually supports. Ask only the next one
or two consequential questions, offering understandable alternatives, "Not sure" and a typed
answer. An unsure answer keeps the choice open. Discussion and prior choices do not waive the
evidence and TODO rules for proposed field values. Never infer exact clinical codes, numerical
windows or available database fields from a familiar name alone.

The eight steps below are the whole procedure. Everything after them is the judgment the steps cannot make for you.

---

## 1. Resolve the exact pack

`products/<area>/<tumour>/<version>`. **Never infer it.** Row numbers, variable names and source
mappings are all pack- and version-specific, so a record drafted against the wrong pack is wrong
in a way that looks entirely correct. Tumour without version, or neither → ask; never pick the newest.

**A new cut of an existing product is not drafted from scratch.** For a revision of a pack that
already holds a contract, `python3 platform/tools/spec_diff.py <old> <new>` (and its `--carry-plan`)
comes FIRST and only the RE-DRAFT partition enters this procedure — the `next-cut` skill owns that
route. Re-drafting byte-identical rows is how the last full re-draft lost two settled answers.

## 2. Establish READ_ONLY or APPLY, and say which

Decide from the user's instruction, and state your choice in your first sentence. Never infer
permission to write from the fact that you are able to.

| | The repository | The output location the user named |
|---|---|---|
| **READ_ONLY** | no edit to any file under the pack, `platform/`, or `governance/` | may write the report you were asked for |
| **APPLY** | the named pack is writable | as READ_ONLY — but never a maturity level, never marking a decision RESOLVED, never a human-only status |

- check / audit / review / compare / "look at" → READ_ONLY
- explicitly add, update, convert or fix something **in the pack** → APPLY
- **unclear → READ_ONLY, and say so.** Producing a report when a commit was wanted costs one
  message. Writing to a governed file when a report was wanted costs a governed file.

**"Do not make changes" outranks everything.** Being asked to write your report to a named file does
not promote a review into APPLY — the report is the deliverable, not a change to the pack. "Review
this in detail" stays READ_ONLY *even when you find something obviously worth fixing*: report the
fix, do not make it. A found problem is not a mandate.

## 3. Capture the baseline

```bash
# BEFORE you start. CONTENT, not just the file list.
git status --porcelain > /tmp/baseline.status
git diff HEAD > /tmp/baseline.diff
git ls-files --others --exclude-standard -z | xargs -0 -r sha256sum > /tmp/baseline.untracked
```

Capture repository-wide contents, not just `<pack>` or status, and compare against the baseline, even when it began dirty. Read the [baseline comparison notes](REFERENCE.md#baseline-comparison-notes).

At the end, in **every** mode, take the same three and compare:

```bash
git status --porcelain > /tmp/after.status
git diff HEAD > /tmp/after.diff
git ls-files --others --exclude-standard -z | xargs -0 -r sha256sum > /tmp/after.untracked
diff /tmp/baseline.status /tmp/after.status
diff /tmp/baseline.diff   /tmp/after.diff          # READ_ONLY: all three must be empty
diff /tmp/baseline.untracked /tmp/after.untracked
```

In READ_ONLY all three diffs must be empty. In APPLY they must contain **only** the changes you say you made. Put them in your report.
A mode recorded in a first sentence is a claim; a diff is evidence.

## 4. Obtain the approved slice

```bash
python3 platform/tools/spec_slice.py <pack> --domain <domain> [--variable <VAR>] [--item clinical:61-108]
```

`--item` is repeatable and takes a row or a range. Prefer it on clinical and treatment, where `--domain` alone is too wide and `--variable` too narrow.

**If the slice says the pipeline artifacts are stale, STOP and report it.** In READ_ONLY you may run
only the check, never the regeneration:

```bash
python3 platform/tools/run_spec_pipeline.py <pack> --check    # read-only: reports, writes nothing
```

`run_spec_pipeline.py <pack>` without `--check` REGENERATES seven governed artifacts. That is an
APPLY act, it is not yours to perform during a review, and stale artifacts are a finding about the
pack — one worth reporting rather than quietly fixing on the way past.

The slice refuses to run unless the pack's **source manifest is well-formed** and its **sanitized
extraction is approved for AI use**. That is not the same as Gate 1 passing, and the difference is
the point: a pack can slice perfectly while its authoritative workbook is still unregistered, which
is the state every pack is in today. Read the `GATE 1` block the slice prints — it names all three
states separately (step 8, and `REFERENCE.md` §"The AI boundary" for the whole rule). No tool may
grant that approval.

The slice gives you, for that domain only: the spec rows with fields resolved, the deterministic
lint findings for exactly those rows, a judgment starting point per row, the pack's decision index,
the QC findings against your rows, the gaps cited on them, the config source keys, **the records
that already cite those rows in full**, each row's disposition, and the workbook columns this
framework has no canonical field for (printed as *(unmapped column)* — often where a spec records
that a rule is still `first-pass [verify]`).

**Read the three indexes before raising anything.** A question already in `DECISIONS.md`, a defect
already in `SPEC_QC_FINDINGS.md`, a shortfall already in `ENGINE_GAPS.md` — reuse the id. Two ids
for one thing is invisible to any single reviewer, because both entries look correct.

**Use the exact `item_id` supplied by extraction.** Do not reconstruct it from a sheet label or domain.
The logical scientific domain remains one of the shared domains:

    study_period · study_population · demographics · clinical · treatment · outcomes

Single-sheet citations remain `<domain>:<row>`; multiple sheets use `<domain>.s<sheet-key-hash>:<row>`.
Preserve the supplied suffix and original Excel row; never guess which sheet an old generic reference means.
**IDs do not transfer between packs or cuts.** `governance/SPEC_DOMAINS.md` owns the mapping.

The extraction's `ignored:` block names the sheets carrying NO requirements — cover, change log,
worked examples, vendor reference. No record can cite one: use it to understand a rule, cite the
requirement row that states it; a rule that exists ONLY there is a finding, not a citation.

**The slice is a starting point, not a guarantee of sufficiency.** If your record names a dependency
whose DEFINITION lives in another domain — an index date, a cohort, a follow-up endpoint — say so
and ask for that domain. Do not reconstruct it from the name.

## 5. Fill only the generated judgment fields

```bash
python3 platform/tools/contract_scaffold.py <pack>/spec_pipeline/out/extracted.json \
    --product <pack> --records -          # emits the judgment stub per row
```

The stub contains exactly the fields that are yours. **Do not add a field to it.** Four things are
not yours and the tool refuses each by name:

| | Why |
|---|---|
| `spec_refs`, `spec_digest`, `required_rule` | supplied by `--item`. Retyping a digest fails loudly; tidying `required_rule` into better English fails nothing and quietly replaces the spec's words with a paraphrase |
| `status` | **settled by the tool, in every case.** A new record gets the initial values; a record citing an open decision is DERIVED to `decision_required` from the pack's register; a revision keeps what the record holds, unless the revision changes what the record REQUIRES — then the evidence statuses reset and the tool says so |

`status` is the one to be most careful about, because writing it feels like part of the job. It is
not: every value you might want is an evidence claim, and you have read a specification row. An
unknown field name is an error that names itself; `windwo:` fails rather than rendering a
perfect-looking row with the answer missing.

## 6. Render and inspect

```bash
python3 platform/tools/contract_record.py judgment.yaml --product <pack> --item <domain:row>
```

`--product` AND `--item` are both required for any pack with an extraction. The tool renders the row,
re-parses every field back out of it through the parser the gates use, and runs the **real lint**
against a throwaway copy of the pack — so it answers "would this pass Gate 2 HERE", not "is it
well-formed anywhere".

Read what it says. A `PROBLEM` line is the pack telling you something before a governed file has to.

`--format-only` exists and renders without a pack. **Do not reach for it.** It skips every
pack-specific invariant — I8 (does the cited row exist), I15 (is the digest still current), I17 (is
an unsettled row answered) — so a record it accepts has been checked for shape and nothing else. If
the tool refuses for want of `--product` or `--item`, supply them; the refusal is the check working.

## 7. Apply through the tool, or return the proposal

**APPLY:**

```bash
python3 platform/tools/contract_record.py judgment.yaml --product <pack> --item <domain:row> --apply
```

In APPLY only, `--apply` writes the record into `FUNCTIONAL_CONTRACT.md`: it replaces the row with
this `variable_id` if one exists and appends it if not, it is idempotent so running it twice is a
no-op, it writes atomically, and it refuses outright if the lint in step 6 did not pass. **Never
paste a rendered row into that file by hand** — that is how a requirement gets duplicated, replaced
beside itself, or wrapped by a terminal.

**READ_ONLY:** return the judgment file and the rendered row in your report. Write nothing to the
pack.

## 8. Verify, and report what the tools said

```bash
python3 platform/tools/contract_lint.py <pack>
# then step 3's `after` capture and its three diffs — READ_ONLY: all empty; APPLY: only your changes
```

After an APPLY touching `DECISIONS.md`, also run `python3 platform/tools/decision_report.py <pack>`
so the committed `SCIENCE_QUESTIONS.md` regenerates in your change-set; after one changing the contract,
`python3 platform/tools/finalize.py <pack> --check` — CI runs both checks and goes red on staleness.

Report: the mode you chose, the pack you resolved, what you drafted, **what the tools printed**,
what you could not resolve and why, any spec defects found, and the baseline diff.

State Gate 1 as the three separate things it is, never as one word. **Producing a slice does not
mean Gate 1 passed** — a pack can be AI-readable and still have no approved specification behind it:

- **AI access to the sanitized extraction** — approved, or not
- **The authoritative workbook** — registered, or pending
- **The extraction basis** — the approved workbook, or an unattested stand-in

The slice prints all three under `GATE 1`, with its own overall verdict. Copy what it printed rather
than summarising it: an AI-readable provisional extraction is not an approved authoritative
specification, and collapsing the three into "Gate 1 ✓" hides exactly that difference.

---

# The judgment the steps cannot make

## Never invent — raise a decision instead

If the spec does not state a bound, a code, a default, a tie-break or a cohort's behaviour, **do not
choose one**, however obvious it seems:

- check the slice's decision index first — reuse an id rather than raising a second question — and
  then the cross-product store: `python3 platform/tools/precedents.py --for <pack>` says whether
  another product already answered this question; cite its entry as EVIDENCE, never as an approval
- add the entry to `<pack>/handoff/DECISIONS.md` phrased as a **question**, with the conflicting
  evidence — APPLY only; in READ_ONLY report the entry you would add
- reference its id in `decision_ids`, and the tool derives `requirement: decision_required`

A decision you cannot write is still a decision you must RAISE. Finding an unanswerable spec row and
saying nothing because the mode forbade the edit is the failure this skill exists to prevent,
wearing a permission as an excuse.

An invented value is indistinguishable from a specified one once written down, and it will be
implemented, validated and released as though Science had asked for it. Grain, missing defaults and
output roles are where this happens without noticing — use REFERENCE.md §"House conventions",
not intuition. Absence-is-not-zero is a DECISION unless the spec states it; a "confirm"/TBD cell
is a question wherever it sits (the register refuses to settle such a row — raise it:
`decision_record.py <pack> --open <ID> --question "..."`).

## The rows the spec does not settle are already marked

A deterministic pass marks every row it cannot read as settled, and the marks are printed under the
record you are drafting. Five kinds mean *the specification does not contain the answer*:

| Kind | What it means |
|---|---|
| `VERIFY_MARKER` | the author left an explicit confirm/verify marker |
| `PLACEHOLDER` | prose sits where a rule should be — `[verify exact figures]` |
| `TRUNCATED` | the cell is cut off; the rest is not recoverable from this document |
| `NO_TERMINAL_ELSE` | an if/else chain with no final else, so some input is undefined |
| `UNDEFINED_REFERENCE` | the rule computes with a symbol no row defines — what it MEANS is unstated |

`contract_lint.UNSETTLED` is the authority for that set. **Judge by KIND, never by severity:**
`VERIFY_MARKER` and `PLACEHOLDER` are INFO and still mean the answer is absent; `UNBALANCED` and
`OUTLIER_IN_LIST` are HIGH and mean the row looks internally inconsistent, not that the spec is
silent.

I17 enforces it: a record citing such a row leaves the unresolved field `TODO` **or** names a
decision or gap. There is no third option, and "obvious from the sibling row" is not one.

**A flagged row is often PARTLY settled — split it, do not refuse it.** The most common wrong
response after inventing is over-refusing. Carry what the spec states, leave out what it does not,
cite the decision. `REFERENCE.md` §"A worked record" shows the split on a real row.

## `source` is proposed, never confirmed

Draft `source` **only from identifiers the spec explicitly names**. Never infer one from a naming
convention, a sibling variable or a plausible pattern — a guessed identifier that looks right is the
hardest error for a reviewer to catch.

Where no source has been chosen for this concept yet, write `source.kind: pending_mapping` with the
spec's identifiers verbatim. It is legal on any such record, whether or not the pack has a `sources:`
registry — the pack having a registry says nothing about whether THIS concept was mapped.

Read [the mapping lifecycle](REFERENCE.md#pending_mapping-in-full): legal at Gate 2, resolved by
the human source review at Gate 3, and blocking Gate 4 approval while any mapping remains open.

## "The engine cannot do this" is a claim

The engine is the LAST thing to suspect. An unsettled rule is `decision_required`; an undelivered
field is `not_derivable`; an external code table is a Gate 1 material to register. Only a rule that
is clear, whose data is there, and which no operator can express is a shortfall.
`REFERENCE.md` §"Is the rule expressible?" has the vocabularies and the order to work through.

Both errors cost. A gap for a capability that shipped puts a phantom on a roadmap; a rule written as
though configured when nothing expresses it hides the shortfall completely.

## Summarize in the contract; enumerate in the YAML

`derivation` **names the rule**; the YAML carries the values. `"STATE→region map (codes 1-5, PR→Other
region); state null→6"` in the record, the fifty states in `variables/*.yaml`.

That is the *values*, not the *records*: **one record per spec row** (I16). Where thirty lab rows
share a rule, each still gets its own record — a family record is a list, and a list is where the
next tumour's new analyte goes missing.

## `acceptance` is a synthetic worked example

Explicit synthetic literals from the approved rule — `index_date=2026-01-01, birthyear=1954 →
AGE=72`. **Never a delivered patient row or vendor-derived statistic** — a case a test can
assert, not evidence about the feed. Worked divisions (`a/b = c`) are checked by I23: compute
them, don't estimate.

## Recording what the spec got wrong

Drafting is also the specification QC pass. Both registers are governed files, so writing to either
is APPLY only; in READ_ONLY you report the entries. What never changes with the mode is that you
FOUND it and said so.

- **`DECISIONS.md`** — open *questions*. The spec is silent or ambiguous.
- **`SPEC_QC_FINDINGS.md`** — *defects in Science's document*. Impossible values, contradictions,
  wrong-tumour table references, duplicated variable IDs.

A **workaround is not a correction**. Reading `4/31/2026` as `2026-04-30` to unblock a build leaves
the finding open, because re-extraction reintroduces it.

## What this skill never does

- **Never read vendor material** — data dictionaries, delivered data, schema dumps, profiling
  output. Scripts and humans may; AI may not. There is no override flag, and a task instruction is
  not an approval mechanism.
- **Never write a status.** Not `approved`, not `verified`, not `human_confirmed`, not `passed_live`
  — and not `draft` or `decision_required` either. The field is the tool's.
- **Never settle a methodology choice as a recorded ruling** — study windows, index rules,
  outcome definitions, ties and clinical grouping need Science's decision. Labelled educational
  discussion and proposed alternatives are welcome; keep unresolved draft choices visible.
- **Never rename** a published or physical name; naming is a governed decision.
