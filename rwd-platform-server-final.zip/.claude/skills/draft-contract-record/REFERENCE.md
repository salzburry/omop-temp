# Reference — vocabularies, field meanings, worked records

Looked up while drafting, not read start to finish. `SKILL.md` is what governs a run; this is what it
points at. Nothing here is a second source of truth: where a definition lives in code, this says which
module owns it and stops.

## Baseline comparison notes

Repository-wide, not `<pack>`, and compared against a **baseline** rather than against empty:

- a scoped `git status <pack>` cannot see an accidental edit under `platform/` or `governance/`,
  and a report written into a path inside the pack is a change to the pack, however it was named;
- the worktree may not have started clean, so "empty" is the wrong postcondition;
- **`--porcelain` reports that a file is modified, not how.** A file already dirty at baseline stays
  ` M path` whatever else is done to it, so editing a file the user had already touched is invisible
  to a status-only comparison — the single most likely accident in a review.

---

## The record shape

`variable_id`, then the canonical fields, then `implementation_refs`. **`TABLE_COLUMNS` in
`platform/tools/contract_lint.py` is the authority.** Do not count fields off this file — a count
written down here is a second definition of the schema and is wrong for some pack the moment it is
written.

```
variable_id · spec_refs · spec_digest · required_rule · source · grain · anchor · window
record_selection · tie_break · derivation · cohort_applicability · missing · units · depends_on
output · status · decision_ids · gap_ids · publish · acceptance · notes · implementation_refs
```

Irrelevant fields are `n/a` or `[]` — never omitted, because an absent field is indistinguishable from
an overlooked one.

**Every governed contract table is `TABLE_COLUMNS` — one shape, no exceptions.**
`contract_lint.table_shape_errors` rejects a non-canonical header, a missing or unknown column, the
right columns in the wrong order, and any row whose width disagrees with its header, in both
directions.

`handoff/FUNCTIONAL_CONTRACT.md` stores records as rows of one **markdown table**. A fenced ```yaml
block is the LEGACY form: the reader accepts it only when a file has no table, and where both appear
the table wins and the fenced records are **not read at all**. A block pasted under a table is a record
nobody will ever enforce.

---

## What each field is answering

| Field | What it must capture |
|---|---|
| `spec_refs` | **machine-owned** — the `<domain>:<row>` citation, supplied by `--item` |
| `spec_digest` | **machine-owned** — binds the record to the TEXT of the cited rows, not just their numbers. What catches Science editing a rule in place after the record was written |
| `required_rule` | **machine-owned** — the spec's own Definition cell. Not a field you write, and not one you qualify: an interpretation that is not literally in the source ("approximate", "assumed", "probably") belongs in `notes`, where a reviewer can see it is yours |
| `source` | `kind` + `inputs` (or `parameters`) — **proposed only** |
| `grain` | the row identity the variable is defined at |
| `anchor` | the date everything is measured from |
| `window` | the interval, with bounds exactly as the spec words them |
| `record_selection` | which record wins when several qualify |
| `tie_break` | how a tie resolves — without this the output is non-reproducible |
| `derivation` | the executable rule; an exact expression where the spec gives one |
| `missing` | `no_record` vs `present_null` behaviour — two different situations |
| `depends_on` | other variables this needs, which sets build order |
| `acceptance` | a concrete worked example with real values, so it can become a test |
| `notes` | caveats, preserved spec typos, naming divergences |
| `implementation_refs` | REQUIRED on every record. `[none]` when nothing implements it yet; blank and `TODO` both fail (I19) |

---

## Controlled vocabularies

The lint enforces these, so a wrong guess is caught.

- `status.requirement` — `approved` · `draft` · `decision_required`
- `status.source` — `verified` · `dictionary_only` · `unverified` · `unavailable` (the COARSE axis, for
  a product before Gate 3). A product at Gate 3 replaces it with all four finer axes, and Gate 4
  requires them:
  - `status.source_mapping` — `proposed` · `human_confirmed`
  - `status.dictionary_check` — `not_run` · `passed` · `failed` · `not_available` (no dictionary ships
    with this feed — accepted only beside a passed live schema check and an accepted profile check)
  - `status.live_schema_check` — `not_run` · `passed` · `failed`
  - `status.data_profile_check` — `not_run` · `reviewed` · `issue_open` · `accepted`

  Carry EITHER the coarse axis OR all four; a mix fails I6. Draft every check at `not_run` and
  `source_mapping: proposed`.
- `status.implementation` — `implemented` · `partial` · `config_gap` · `engine_gap` · `not_implemented` · `not_derivable`
- `status.validation` — `not_run` · `passed_test` · `passed_live` · `failed`
- `output.role` — `published` · `internal` · `metadata` · `excluded`
- `output.name_status` — `aligned` · `undecided` (only two, and `undecided` is the honest one wherever
  the spec does not establish a physical name — see `pending_mapping` below)
- `publish.{ads,dictionary,dashboard,tfl}` — `configured` · `required` · `proposed` · `excluded` · `undecided`

**Never write `passed`, `accepted`, `human_confirmed`, `verified`, `passed_live`, or
`requirement: approved`.** Those are human transitions backed by evidence.

---

## The invariants, and what each one asks of a drafter

**`platform/tools/contract_lint.py`'s module docstring is the authority** — it states what each
invariant CHECKS, in the code that runs it. This table states what each one asks of the person or
model writing the record, which is a different question and the one you need while drafting. Retired
ids (I7, I9) are absent because the lint no longer defines them.

`--product` runs all of these against the pack before your record reaches a governed file, so this is
a list of failures you can avoid rather than a list you must memorise. The ones with teeth for a fresh
Gate 2 draft are **I17**, **I19** and **I18**. I11 is DERIVED for you and listed for what it asks of
`decision_ids`.

| | Asks of you |
|---|---|
| **I1** | One record per `variable_id`. Revise the record that already cites your row — the slice hands it to you in full — rather than adding a second |
| **I2** | Every id in `decision_ids` / `gap_ids` must already EXIST. Raising a decision means adding the register entry too (APPLY) or reporting the entry you would add (REVIEW/DRAFT); a record citing an id nobody created fails |
| **I3** | Only vocabulary values above. Not "TBD", not a sentence, not a value from a sibling framework |
| **I4** | `output.role: published` obliges `physical_name`, `type`, `nullable`. If the spec does not establish a physical name, the record is not published-with-a-TODO-name — it is `name_status: undecided` with `physical_name: TODO`, and I10 then keeps it off `approved` |
| **I5** | `publish.dashboard: configured` claims the variable is ALREADY in `dashboard_vars.yaml`. You are drafting a requirement, not a deployment: `required` or `proposed` is what a spec row supports |
| **I6** | Every canonical key present. `n/a` and `[]` are answers; omission is not |
| **I8** | Every `<domain>:<row>` must resolve to a captured row. `--item` supplies these, which is the point — a citation you typed is a citation that can be wrong |
| **I10** | An `approved` requirement carries no `TODO` anywhere. You never write `approved`, so this bites in one direction only: leaving a TODO is correct and safe, and it is the flip to `approved` — a human act — that the TODO blocks |
| **I11** | Nothing, directly — you write no `status`. Cite the open decision in `decision_ids` and the tool DERIVES `requirement: decision_required` from the pack's register, using the same function I11 checks with. What this asks of you is that `decision_ids` is right: a decision you failed to cite is a record that reads settled |
| **I12** | The axes must agree with each other. A record cannot be validated further than it is built, or built further than its requirement is settled. `INITIAL_STATUS` is consistent by construction — this bites when you revise one axis of an existing record and leave the others behind |
| **I13** | A SHORTFALL — `config_gap`, `engine_gap`, `partial`, `not_derivable` — must name a gap. An ordinary fresh draft is `not_implemented`, which is not a shortfall and needs no gap (see §"Is it a gap, or is it config?" in SKILL.md before you claim `engine_gap`) |
| **I14** | Pack-level, at `contract: approved`: no record still being written, no decision-blocked record claiming to be built. You cannot reach it and cannot break it; it is why an honest `draft` costs nothing |
| **I15** | The record is bound to the TEXT it was written from. Machine-owned — and the reason retyping `spec_digest` is refused rather than tolerated |
| **I16** | One record per spec row, at `coverage_complete` and above. A range like `clinical:17-46` on one record is what this refuses |
| **I17** | A record over an UNSETTLED row leaves a TODO on a REQUIREMENT field, or names a decision/gap. Not the source axis, not the naming axis — a requirement field. The one invariant aimed at a **plausible answer filled into a row the spec leaves open**: I3 catches an invented enum, I8 a fabricated citation, I2 a made-up decision id, but each of those is wrong in SHAPE. I17 is what stands against a value wrong only in FACT, so treat a pass here as the thing you were actually checked on |
| **I18** | `pending_mapping` must carry the spec's own identifiers verbatim, and can never be approved, source-verified or implemented. It is legal on any record whose source nobody has chosen — the pack having a `sources:` registry does not mean THIS concept was mapped. It comes due at **Gate 4**, which cannot be approved while any record still says it |
| **I19** | `implementation_refs` is ANSWERED. `[none]` for a fresh draft; blank and `TODO` both fail |
| **I20** | Inline `{...}` cells must have balancing braces. Every other check finds a field by scanning for its token, so a dropped `}` can put `role` inside `codes` and pass nineteen invariants. The tool renders your YAML, so this is one you get for free by not hand-typing rows |
| **I21** | Every OPEN decision must be REFERENCED somewhere in the contract (from `coverage_complete` up). If your draft resolves the last record citing a question, the question itself must be answered, withdrawn or superseded — never left orphaned in the register |
| **I22** | `required_rule` IS the cited row's Definition cell, verbatim (a `\|` escaped, whitespace folded) — never a paraphrase, a compression or a fixed typo. Your reading of the rule goes in `derivation` and `notes`; a defect in the spec's own words goes to `SPEC_QC_FINDINGS.md`. `--item` writes the cell for you, which is the reason to use it |
| **I23** | Worked arithmetic in `acceptance` must compute: `181/30.4375 = 5.95` is checked as a division (one unit of the last decimal place is tolerated, so a floor and a round both pass). The example is read as evidence downstream — a wrong number would ship looking specified. Only the `a / b = c` shape is judged; prose and dates never match |
| **I24** | Every `depends_on` entry must RESOLVE: another record's `variable_id`, a variable the extraction names, `engine:<stage>` for an engine intermediate (e.g. `engine:lot` for the line-of-therapy frame), or the literal `none`. A name that resolves to nothing is prose in a field's clothes, and a typo there would otherwise lint clean forever |
| **I25** | Every cited row is the row of THIS record's variable: `--item` names the row whose `variable` is your `variable_id` (case and punctuation are not identity; `DTHFL__2` and `AGE_AT_INDEX` are the AGE/DTHFL row's; `FU_ENDDT_PRELIM` is the `FU_ENDDT_preliminary` row's). A record that deliberately derives from ANOTHER row's variable names that variable in `depends_on` — a sentence in `notes` is not a statement the lint can read. What is refused is the silent mismatch: an AGE record over the DATAV row, `D` over DATAV, `AGE` over AGE18 |

---

## Is the rule expressible? The named vocabularies

**`platform/engine/stages/clinical.py` owns these; `governance/RECORD_SELECTION_VOCABULARY.md` is the
open proposal for the contract-layer half.** They are listed here for ONE decision: whether a rule the
spec states is something the framework can already express, or a genuine shortfall that needs a gap.
`platform/tests/test_skill_currency.py` fails if this list falls behind the engine.

They are not a menu to pick from. The spec states the rule; you record it. What this list changes is
`status.implementation` and whether `gap_ids` gets an entry — and a false `engine_gap` is expensive,
because it is triaged, scheduled and closed as a duplicate by someone who had to go and read the code.

### The order to work through — the engine is the LAST thing to suspect

A rule that no operator below expresses is not therefore an engine shortfall. Stop at the first
answer that fits:

1. **Is the clinical rule settled?** If the spec is silent, truncated or self-contradictory →
   `requirement: decision_required` and a decision id. Nothing is buildable yet, and filing it as an
   engine gap sends Engineering a question only Science can answer.
2. **Does the feed supply what the rule needs?** A field that is not delivered →
   `implementation: not_derivable` with a gap naming the missing input (I13). The engine is not at
   fault for a column nobody ships.
3. **Does it need governed reference material** — an external terminology, code table or crosswalk?
   That is a Gate 1 material for someone to register, not an operator for someone to add.
4. **Only then**: the rule is clear, the data is there, and no named operator can express it →
   `engine_gap` and a gap id. That entry is worth opening, because it names something that genuinely
   does not exist.

**Which DATE a source record is measured on** — `date_basis`, and it is BLOCK-level only (`BLOCK_ONLY`),
never per item:

| | |
|---|---|
| `column` | the single named date column (the default) |
| `later_of` | the greatest of several date columns, ignoring nulls |
| `earlier_of` | the least of several date columns, ignoring nulls |

**Which ROW wins once the window is applied** — `pick`:

| | |
|---|---|
| `nearest` | closest to the anchor (the default) |
| `earliest` | the earliest record in the window |
| `latest` | the latest record in the window |
| `priority` | the best status by the item's `priority` label order, across ALL in-window rows |

**How a TIE resolves** — `tie_break`: `prior` (the earlier record, the default) · `later`.

A record whose `record_selection` and `tie_break` land inside those three registries is CONFIG work:
`implementation: not_implemented`, no gap. One that does not — a rule needing a new operator — is a
real `engine_gap` and gets one.

**How a group claims a raw value** — `VALUE_MATCHERS`, for any value-to-group map (stage groupings,
grade, histology, TNM, biomarker status):

| | |
|---|---|
| `from_prefixes` | exact match on any listed value, case-SENSITIVE (the legacy spelling — the name says prefix and the operator does not) |
| `from_equals_ci` | case-insensitive equality |
| `from_startswith_ci` | case-insensitive prefix; the LONGEST matching prefix wins, whatever order the groups are written in |
| `from_contains_ci` | case-insensitive substring |
| `from_regex` | a Java/Spark regular expression, applied VERBATIM and case-SENSITIVELY — `(?i)` for case-insensitive |

`from_regex` is the escape hatch and reads like one. The other four name their rule, so a reviewer
reads the group and knows what it claims; a regex is a small program in a YAML cell, and checking it
is a different and harder act. It earns its place only where none of the four can express the rule —
anchoring, alternation, or tolerance of whitespace and punctuation the feed varies (`3+4=7` beside
`3 + 4 = 7`). If the spec's rule is an enumeration or a prefix collapse, the named operator is the
right answer and the regex is not.

Plus two reserved MARKERS, which are not matchers and match by position: `when: fallthrough` is the
ELSE, `when: missing` fires on NULL. **They are different answers.** A record whose stage is null is
not the same fact as a record whose stage is a word nobody mapped, so a `missing` rule and a
fallthrough rule are two things for a spec to state and two things for a record to carry — collapsing
them into one is a recorded gap on a live pack, not a hypothetical.

The reason this matters at drafting time: a spec saying a delivered sub-stage collapses to its parent
stage is **`from_startswith_ci`**, which exists. Writing that up as an engine shortfall raises a gap
for a capability that shipped. Conversely, a spec asking for something none of these express — a
numeric comparison on a text field, a lookup against an external clinical vocabulary — is a
shortfall, and saying so is the useful thing you do.

---

## House conventions — the answers drafters otherwise invent

Five independent simulated drafting runs, on five different tumours, each invented the SAME
answers to the same unstated questions — and every invention passed every invariant, because a
plausible value on an unflagged row is exactly what the lint cannot see. These are the named
conventions, so that what was five private guesses is one written rule:

- **Grain.** The house grain for patient-level, index-anchored records is
  `[patientid, index_date, cohortn]`; per-patient flags are `[patientid]`; internal constants are
  `n/a`. State which one you used. If a record's true grain differs from these, that is a
  question for the register, not a silent deviation.
- **Absence is not zero.** `no_record -> 0` versus `no_record -> null` is a clinical-adjacent
  choice. The spec stating it (as SEX's `U when missing` does) settles it; anything else is a
  DECISION — a run that chooses 0 "per intuition" is choosing analysis semantics alone.
- **`output.role` while blocked.** A decision-blocked record takes `role: internal` (nothing is
  published until its question is answered) — never TODO (I3 has no undecided value), never
  `published` on trust.
- **A "confirm" cell is a question wherever it sits.** The one leak every run shared: requirement
  rows all became decisions, but "plumbing" rows — data version, masked source names, a mapping
  marked "confirm sources" — were dispositioned `control` and closed alone. The disposition
  register refuses a settled disposition on a row whose own text says confirm/TBD; do not route
  around the refusal, raise the question (`decision_record.py <pack> --open <ID> --question "..."`).
- **Duplicate spec rows.** A second definition of the same variable scaffolds as `<NAME>__2` —
  the `__N` suffix is the scaffold's convention for "the spec defines this twice", and the
  duplicate is a SPEC_QC finding plus a decision about which definition governs, never a silent
  merge.
- **Workbook margin columns.** The scaffold's "Also on this spec row" notes carry the unmapped
  Origin / Evidence / Status cells. Read them: they are where the spec whispers "struck through —
  keep or drop?" and "confirm with epi".
- **`depends_on` resolves (I24).** Cite another record, a spec variable, `engine:<stage>`
  (e.g. `engine:lot` for the line-of-therapy frame), or `none` — never a name you coined.
- **The reference shelf is vocabulary, never evidence.**
  `governance/reference/variable_inventory/INVENTORY.yaml` (master core + per-tumour overlays,
  engine coverage inline) says what
  published RWD studies of this tumour typically define — read it before drafting so the workbook
  conversation starts from a checklist, and use its terms when raising questions. It is
  `status: reference_only`: a record's definition, thresholds and bands come from the approved
  workbook alone, and citing the shelf in a record's evidence is the mistake its own note forbids.

## `source` shapes

```yaml
source: {kind: vendor, inputs: {lot: {line_start: startdate}, mortality: {death: dateofdeath}}}
source: {kind: derived}
source: {kind: parameter, parameters: [study.index_start]}
source: {kind: constant}
source: {kind: unavailable}
source: {kind: pending_mapping, spec_identifiers: [Demographics.BirthYear]}
```

**One input per source, and every column under the source it comes from.** `death: dateofdeath` under
`mortality` says which table to look in, so Gate 3 can prove the mapping instead of finding the name in
whichever of the record's tables happens to carry it.

Each key under `inputs` must exist in that pack's `config/data_product.yaml` `sources:` block — config
owns the physical name, and it changes with the tumour AND with the delivery format. A name it does not
define is a Gate 3 `unknown_source` failure; the fix is a config entry or a recorded gap, never a
guessed table.

Column values must be **atomic column names**. A formula (`max(a, b)`), a sentence, or another
variable's name belongs in `derivation`, `record_selection` or `depends_on`.

Set `physical_stem` ONLY when the spec itself names a physical table — then it is registered evidence
and `stem_drift` checks config still agrees with it. Otherwise omit it: an inferred stem looks like
stand-in and is not.

The older shape — `logical_table` prose plus one flat `columns` map — still parses, because records
written before the migration carry it. Do not write new ones in it.

### `pending_mapping`, in full

Legal on any record whose source nobody has chosen yet — including in a pack that already has a
`sources:` registry, because the pack having one says nothing about whether THIS concept was mapped.
It comes due at **Gate 4**: a configuration cannot be approved while any record still says it, since
a configuration cannot express a requirement whose source is undecided.

Its lifecycle spans three gates and it is worth being exact, because a state legal at one gate and
fatal at another is where records get stuck:

| Gate | Pending mapping |
|---|---|
| Gate 2 | **legal.** A requirement is fully stateable before anyone knows which table supplies it |
| Gate 3 | **where it is resolved.** Choosing the source and confirming it is the right column is a human act, and Gate 3 is that act |
| Gate 4 | **cannot be approved while any remain.** A configuration cannot express a requirement whose source is undecided |

So an unresolved mapping shows up as a Gate 3 finding while it is open, and blocks Gate 4 if it is
still open when the configuration is signed. Both are the same fact reported to the gate that can
act on it.

```yaml
source: {kind: pending_mapping, spec_identifiers: [Demographics.BirthYear]}
gap_ids: []
implementation_refs: [none]
notes: "Logical source not yet chosen for this concept. Identifier copied exactly from the specification."
```

* `spec_identifiers` carries the spec's OWN identifiers, **verbatim**, and may not hold a placeholder.
  That is what lets someone who never read the workbook finish the mapping.
* It can never be `requirement: approved`, never `source:` anything but `unverified`, never
  `implementation: implemented`. It cannot pass Gate 3, Gate 4 or approval.
* **No gap is required, and do not invent one.**
* **It does NOT make the record `decision_required`.** The requirement axis and the source-mapping axis
  are separate: a rule Science has fully specified does not become an open scientific question because DataExpert
  has not yet chosen an alias. Marking it so buries the rows that genuinely need Science.
* **Never lowercase or reshape a spec name into a physical one.** Where the spec does not establish a
  physical output name: `physical_name: TODO`, `target_published_name:` the spec's own variable name,
  `name_status: undecided`. Lowercasing `PSMA_SCANDT` to `psma_scandt` is an inferred naming decision
  wearing stand-in's clothes.

`platform/tools/finalize.py` enforces the machine-checkable half: once a pack DOES declare sources, a
record naming a key outside that set must cite a decision or a gap.

---

## A worked record

From the demographics tab, source coordinate 9 (an Excel row here; a file line for a per-tab input) — *"AGE | YEAR(INDEXDT) - birthyear"*.

**The judgment file** — what a drafter writes. Note what is NOT here: `spec_refs`, `spec_digest` and
`required_rule` come from `--item demographics:9`, and **`status` is not here either**. All four are
supplied by the tool, and putting any of them in the file is an error that names itself.

```yaml
variable_id: AGE
source: {kind: vendor, inputs: {demographics: {birth_year: birthyear}}}
grain: [patientid, index_date, cohortn]
anchor: index_date
window: n/a
record_selection: n/a
tie_break: {equidistant: n/a, same_day: n/a}
derivation: "year(index_date) - cast(birthyear as int)"
cohort_applicability: all cohorts (varies per cohort index date)
missing: {no_record: n/a, present_null: "birthyear null → AGE null (→ AGEGR1N Unknown)"}
units: years
depends_on: [INDEXDT]
output: {physical_name: age, target_published_name: AGE, name_status: aligned, type: integer, nullable: true, codes: n/a, role: published}
implementation_refs: [variables/demographics.yaml#/age, engine:_age_at_index]
decision_ids: []
gap_ids: []
publish: {ads: configured, dictionary: configured, dashboard: undecided, tfl: undecided}
acceptance: "index_date=2026-01-01, birthyear=1954 → AGE=72"
notes: Approximate (year-only DOB) — note in the dictionary. The band child AGEGR1/agegrl is its own record.
```

Render it:

```bash
python3 platform/tools/contract_record.py age.yaml --product <pack> --item demographics:9
```

**`<pack>` and the row number are both YOURS to establish, and neither transfers.** The same variable
in another tumour is another row — `AGE` is `demographics:9` in one pack and `demographics:6` in
another — so a command copied off this page runs against the wrong extraction. It will not quietly
succeed: `--item` refuses an id the pack does not have and names the ones that exist. That refusal is
the check, and it only fires if you passed the pack you were actually asked about.

The rendered row is deliberately NOT reproduced here. Keeping a hand-maintained copy of generated
output beside the generator is the duplicate the tool exists to remove: the two agree only while
someone remembers to update both, and the row is the half nobody reads carefully.

This record is **mature** — it is already built, so it carries `implementation: implemented` and real
`implementation_refs`. A fresh Gate 2 draft from a spec row is not: `implementation: not_implemented`
and `implementation_refs: [none]`. **Do not copy this record's implementation state onto a new draft.**

Note what it does: carries the spec's own column name rather than a guess; states the year-only
approximation in `notes` instead of hiding it; gives an `acceptance` case with real numbers a test can
assert; and leaves `source: unverified` because no human has yet confirmed the mapping.

---

## LEGACY MIGRATION ONLY — a pack that has `config/` but no `handoff/`

**This is not the new-tumour path, and reading it as one inverts the workflow.** A governed new tumour
goes contract-first: the pack has `handoff/` and no `config/` — that is `pending_mapping` above. A pack
with the OPPOSITE shape — config and variables already built, no contract, no decision register, no
lint — is a product implemented before this framework existed, being documented backwards.

Several steps have nothing to write to. Do not let that turn into silent omission:

- Draft the records anyway, and **name the decision and gap IDs you would have opened**, stating in the
  report that they resolve to nothing yet and must be created. An ID that points nowhere is honest; a
  record with no `decision_ids` because the file was missing is not.
- **`--item` has no extraction to read**, so pass `--legacy-no-extraction` WITH `--product` — not
  `--format-only`. The difference matters: `--legacy-no-extraction` keeps the pack, so I8, I15, I17,
  the decision and gap reference checks and every pack-specific rule still run against what you
  wrote. `--format-only` drops the pack entirely and renders nothing anybody checked; it stamps
  `spec_refs`, `spec_digest` and `required_rule` with TODO for exactly that reason, and a row
  carrying a TODO cannot reach `requirement: approved`.
- **Invariant I8 still cannot verify a row that was never captured**, and that check is what normally
  catches a hallucinated citation — so compensate: say exactly how you established each row
  number, and flag any part you inferred rather than read.
- Hand-check the invariants you can (uniqueness, legal enums, the full key set, inline dicts) and report
  which ones you could not run rather than implying a clean pass.

---

## Why `status` is the tool's field and not yours

`contract_record` settles `status`: a NEW record gets `INITIAL_STATUS`, a REVISION keeps what the
existing record already holds, and a draft that writes one is refused.

This is the third attempt and the first that is the right shape. It began as `HUMAN_ONLY`, a blacklist
of seven values a drafter must not set — which fails OPEN on the one event most likely to happen, the
lint gaining an eighth. `FINE_SOURCE_AXES` arrived after the coarse `source` axis, and
`data_profile_check: reviewed` after that; each time a blacklist would have kept passing while a new
human verdict quietly became assertable.

So it became `DRAFTABLE`, an allowlist per axis, which fails closed on a new value. Better, and still
wrong: `failed`, `passed_test`, `passed_synthetic`, `issue_open` and `dictionary_only` all sat inside
it, and every one of them is an EVIDENCE CLAIM — a statement that a check ran and returned a
particular answer. A drafter has read a specification row. It has not run a test, opened a data
dictionary or reviewed a profile, and no allowlist can make writing those honest.

`DRAFTABLE` remains as the vocabulary check `test_contract_lint` holds against `contract_lint` — every
status value sits on exactly one side of the line, so adding one to the lint fails a test until
somebody decides which side. But nothing model-facing consults it any more, because nothing
model-facing writes a status.

`--actor` is gone with it. It declared who was authoring and could not establish it: the same caller
that would misreport it also passed it, so it read as an authorization check while being a string.
What governs a status transition is that it lands in `FUNCTIONAL_CONTRACT.md`, a governed file
CODEOWNERS routes for review — and now the drafting path cannot reach one at all.
