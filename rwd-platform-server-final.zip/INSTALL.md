# RWD Platform

The RWD Platform supports specification intake, master-variable alignment,
scientific review, source mapping, output configuration, execution and release
checks. Its knowledge dashboard exposes definitions, terminology, relationships,
provenance and SHACL validation.

The installation starts with an empty product list and a retained master library.
Use **Start a new product** to register the first specification. Product decisions,
source connections and output destinations are configured through that workflow.

## Server installation

1. Extract this package into the application's source directory and initialise or
   import it into the organisation's Git repository. Configure the server's Git
   identity and remote. Several authoring and release operations require Git.
2. Install Python 3.13 and Git. Create a dedicated environment from the source root:

```text
python3.13 -m venv .venv313
.venv313/bin/python -m pip install -r requirements.txt
```

On Windows use `py -3.13 -m venv .venv313` and
`.venv313\Scripts\python.exe -m pip install -r requirements.txt`.
The requirements include the portal, schema validation and RDF/SHACL processors.

3. Configure the deployment's authenticated principal and initial administrator.
   Set `RWD_PORTAL_BOOTSTRAP_ADMIN` to the administrator's authenticated email.
   Set `RWDP_STATE_DIR` to a durable application-state directory and configure the
   model provider or bridge. Keep the development/local identity flags disabled.
   Do not put credentials into tracked source files.
4. For Databricks Apps use the root `app.yaml` entry point and bind its named
   secret resources. For another server, run the command below behind an
   authenticated gateway configured to provide the supported identity headers:

```text
.venv313/bin/python -m streamlit run experiments/portal/app.py --server.headless true --server.address 127.0.0.1 --server.port 8550
```

The gateway must enforce authentication and replace identity headers from clients.
Configure external access through the gateway. Supply a writable Git workspace for
authoring and durable state storage. Databricks Apps' default temporary state path
does not survive redeployment; configure persistence before relying on saved state.

5. Configure source access, output destinations and the execution runtime for each
   new product. Spark execution uses the destination's supported Spark environment;
   details are recorded in `platform/requirements.txt`. Product release requires its
   own review and validation evidence. Installing the application does not create
   that evidence.

For a local installation check, `python experiments/portal/launch_portal.py` starts
the portal with local Git attribution. This is separate from hosted authentication.
Windows also provides `Start-RwdPortal.cmd`.

## Included components

- Portal and agent implementation, including evaluation runners and synthetic cases.
- Python/R execution engine, platform tools and reusable product templates.
- Master variable catalog, reusable logic, terminology and knowledge validation.
- Operational Help and deployment instructions.

The package contains application source and dependency specifications. Python,
Spark and the configured model service are installed or supplied by the destination.
No products, product jobs, users, chat history, credentials or prior approvals are
preconfigured. The master library retains its recorded candidate/review status.

## Package verification

`SOURCE_MANIFEST.json` records the included files, sizes and hashes.
`PACKAGE_VERIFICATION.json` records verification results. Check an archive with:

```text
python platform/tools/source_transfer.py --verify /path/to/rwd-platform-server.zip
```

The evaluation infrastructure is included. Cases requiring an unavailable product
are omitted from the portal's selectable cases. Full historical test-corpus runs
require their designated test inputs; they are not product approval evidence.
