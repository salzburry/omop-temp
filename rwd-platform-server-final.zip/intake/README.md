# `intake/` — current RWDP code, staged for migration

A **staging area** where the team drops their **current** RWDP code (the existing per-tumor R/SQL
scripts) so it can be QC'd and migrated onto the shared, config-driven engine in `../platform/` +
`../products/`. This is the on-ramp from the **self-service** product (RWP builds in R/Domino) to the
**industrialized** one (config-driven, governed).

> **This zone is NOT governed prod.** It is intentionally fenced: CI does not gate it, it carries no
> `spec_version`/release lifecycle, and nothing here is published. The governed implementation is always
> the Git-tracked config under `../products/` — intake is where raw code waits to *become* that.
>
> **Code only — NO patient-level data.** Never commit extracts, ADS outputs, or site/patient-level CSVs
> here (the root `.gitignore` blocks the common ones, but the rule is on you). Link to data, don't upload it.

## How to submit

1. **Copy the template** into a folder named by tumor → source/owner:
   ```bash
   cp -r intake/_TEMPLATE intake/oncology/<tumor>/<source-or-owner>      # e.g. nsclc/flatiron-jdoe
   ```
2. **Drop your current code** (as-is) into `code/` — R, SQL, Python, whatever you run today.
3. **Fill `submission.yaml`** (who / what / source / refresh / output) and `README.md` (what it does +
   how it runs today).
4. **Open a PR** (or push a branch) — the PR itself tracks the request.

## QC + migration workflow

`submission.yaml: status` moves through:

| status | meaning | who |
|---|---|---|
| `submitted` | code + metadata in, README written | submitter (RWP) |
| `in-qc` | reviewer working the checklist | reviewer (RWDE / QC) |
| `qc-passed` | `QC_CHECKLIST.md` complete + signed off | reviewer |
| `migrating` | being ported to a `products/oncology/<tumor>/<YYYYMM>` config pack | RWDE |
| `migrated` | live as a governed config pack; intake kept for provenance | RWDE |

- **QC** is the per-submission `QC_CHECKLIST.md` — a reviewed sign-off that the code runs and its
  sources / cohorts / outputs are documented. This is an *intake* QC (is the submission complete and
  runnable), distinct from the framework's automated ADS QC gate (`../platform/engine/qc.py`), which
  runs **after** migration on the governed build.
- **Migration** = recreate the logic as `config/` + `variables/` + `codelists/` under `../products/`
  (the add-a-tumor recipe in `../platform/README.md`), then set `status: migrated` and point the
  product's `source_refs.yaml` back to this submission. The raw code stays here as provenance.

## Layout

```
intake/
  README.md                 # this file
  _TEMPLATE/                 # copy-me per submission
    submission.yaml          # metadata (status-tracked)
    README.md                # what the code does + how it runs today
    code/                    # the current RWDP code, as-is
    QC_CHECKLIST.md          # the intake QC sign-off
  oncology/<tumor>/<source-or-owner>/   # one folder per submission
```

See `../platform/README.md` for the add-a-tumor recipe (the migration target shape).
