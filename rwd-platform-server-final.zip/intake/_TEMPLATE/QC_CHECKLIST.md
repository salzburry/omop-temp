# Intake QC checklist — <tumor> / <source-or-owner>

Reviewer works top to bottom, ticks each box, then signs off and sets `submission.yaml: status: qc-passed`.
This is an **intake** QC (is the submission complete, runnable, documented) — distinct from the
framework's automated ADS QC gate (`../../platform/engine/qc.py`), which runs **after** migration.

## Completeness
- [ ] `code/` contains the current code (R / SQL / Python) — and **no patient-level data**
- [ ] `submission.yaml` filled (submitter, tumor, data_source, current_refresh, output_table)
- [ ] `README.md` describes what it does + how it runs today

## Documented
- [ ] Source tables listed (names + schema)
- [ ] Cohort definitions documented
- [ ] Output ADS columns / table documented
- [ ] Known issues / TODOs captured

## Runnable
- [ ] Confirmed it runs end-to-end in its current environment
- [ ] Environment + last successful run date recorded: ______________

## Migration-ready
- [ ] Migration target identified: `products/oncology/<tumor>/<YYYYMM>`
- [ ] Roughly mapped to the framework contract (cohorts · index rule · sources · codelist) — see `../../platform/README.md`

## Sign-off
- Reviewer: ______________    Date: __________
- Decision: [ ] qc-passed     [ ] changes requested (notes below)
- Notes:
