"""Compose a governed file change, and REFUSE to be the one who signs it.

WHAT THIS IS FOR. Answering a decision today means finding `handoff/decision_answers/<id>.yaml`,
knowing which of its eleven keys a human may touch, typing YAML that will not break the frozen
digests above it, and committing. That is a real barrier, and it is why twenty-one decisions have
sat open while the register that lists them is perfectly clear about what they ask. An app can
remove all of that barrier EXCEPT the part that matters.

WHY IT RETURNS A PATCH INSTEAD OF WRITING. `app/serve.py` refuses to serve at all when the working
tree is dirty, because its pages are rendered from FILES and its footer stamps a COMMIT: an edited
checkout under a clean footer proves nothing. An app that wrote into the checkout it serves would
therefore switch itself off with its first write — and, worse, would be a status surface that can
change the thing it reports on. So nothing here writes. Each proposal returns the exact new bytes
and a unified diff; a person applies it and commits, and git records THEM as the author.

WHY IT WILL NOT FILL AN IDENTITY FIELD. `answered_by`, `approved_by`, `clinically_reviewed_by` and
their dates are the whole content of a governed act — `person_rules` already refuses a team, an
acronym and a template placeholder in them, and `governance/APPROVAL_IDENTITY.md` records that
nothing authenticates the name even so. A browser form cannot improve on that: whatever is typed
into it, the app cannot know who typed it. Filling those fields from a web request would convert
"nobody has signed this" into "somebody appears to have signed this", which is the exact failure
every gate in this repository is built to prevent.

So the rule is structural rather than advisory: a proposal may set any field whose name is not an
actor or the date of an actor's act, and the fields it declined are RETURNED BY NAME so the page
can show a person precisely what remains theirs to do. Derived from the field NAME, never a
hand-kept list, so a form that grows a `reviewed_by` next year is covered the day it appears.
"""
from __future__ import annotations

import difflib
import io
import os
import re
import sys


# `_by` fields that name a THING rather than a person. Kept to the ones that genuinely exist:
# a growing list here would slowly re-open the hole the shape rule closes, so anything added must
# be a field where "by" means "replaced by" and not "acted on by".
NOT_AN_ACTOR = ("superseded_by",)


def is_actor_field(name):
    """Is `name` an actor, or the date of an actor's act?

    A RULE, NOT A ROSTER. The approval forms already carry `approved_by`, `technically_reviewed_by`,
    `clinically_reviewed_by`, `validated_by` and `answered_by`, and each arrived in a different
    change; a list here would have to be updated by whoever adds the next one, which is the person
    least likely to be thinking about this file. Anything ending `_by` is an actor. Anything ending
    `_date` is when an actor acted — `approval_date`, `answer_date`, `validation_date`, `review_date`
    — and is refused for the same reason: a date the app invents makes an unsigned record look
    dated, and `bad_date` cannot tell a fabricated one from a real one.
    """
    n = str(name or "").strip().lower()
    # ...WITH ONE EXCEPTION, AND IT IS NOT A SPECIAL CASE SO MUCH AS THE RULE READ PROPERLY.
    # `superseded_by` names the DECISION that replaced this one, not the person who replaced it.
    # A shape rule over `_by` matches it, and refusing to write it would leave the one field that
    # records WHY a withdrawn decision is withdrawn permanently un-fillable through this path.
    if n in NOT_AN_ACTOR:
        return False
    return n.endswith("_by") or n == "date" or n.endswith("_date")


# The keys of a decision-answer form a proposal may set. `status` is here and `answer` is here;
# everything else in that file is either the question AS ISSUED or a digest freezing it, and both
# are explicitly marked "edit none of them" in the form's own header.
ANSWERABLE = ("answer", "status", "superseded_by")

# The structured half of an equivalence answer, addressed as `equivalence.<key>`. The outcome
# word comes from the ONE closed vocabulary (`semantic_view.VOCAB`) — a second spelling here is
# how a NOT-COMPARABLE answer gets to authorize same_construct, which is the defect the sealed
# rulings exist to end. Order is the block's canonical order, not alphabetical.
EQUIVALENCE_KEYS = ("equivalence_outcome", "variable", "source_a", "source_b", "rationale")


def _vocab():
    """The closed equivalence vocabulary, imported from its one definition."""
    sys.path.insert(0, os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
                                    "platform", "tools"))
    import semantic_view                                                  # noqa: PLC0415
    return tuple(semantic_view.VOCAB)

# ...and the keys it must never touch, because they are the question and the frozen state of the
# records that cite it. Editing one would silently re-point an answer at a different question.
FROZEN = ("decision_id", "pack", "question", "evidence", "question_sha256", "records_sha256")


def _parse(text):
    """The composed document as a mapping, or None. Through the STRICT loader the gates use, so a
    duplicate key - two claims for one slot with the second silently winning - is not parseable
    here either."""
    import sys as _sys                                                    # noqa: PLC0415
    _sys.path.insert(0, os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
                                     "platform"))
    try:
        from engine.strict_yaml import strict_load                        # noqa: PLC0415
        doc = strict_load(io.StringIO(text))
    except Exception:                                # noqa: BLE001 - unparseable IS the answer
        return None
    return doc if isinstance(doc, dict) else None


# One unquoted word, and nothing YAML would re-type. Everything else takes a literal block.
_SAFE_BARE = re.compile(r"[A-Za-z][A-Za-z0-9_-]*")
_YAML_WORDS = frozenset(("y", "n", "yes", "no", "true", "false", "on", "off", "null", "none"))


class Refused(Exception):
    """A proposal that must not be composed at all, with the reason a page should show."""


def _set_scalar(text, key, value):
    """Replace `key:`'s whole value in a YAML document, preserving everything else byte for byte.

    A TEXT EDIT, NOT A RE-SERIALISATION. Round-tripping these forms through a YAML dumper would
    discard the header comments that tell a person what each field is for, reorder the keys, and
    rewrite the frozen digests into a different quoting style - a diff nobody could review, over a
    file whose whole purpose is to be reviewed. So the value is spliced and the rest is untouched.

    ALWAYS A LITERAL BLOCK, and that is the fix for three separate ways the first version could
    corrupt a form:

      * a bare scalar re-TYPES the value. `null`, `yes`, `true`, `off` and `~` stop being the
        string the person typed and become None/bool; `[x]` becomes a list; a `#` starts a comment
        and TRUNCATES the rest of their sentence. All silently, in a governed file.
      * a FOLDED block (`>-`) joins lines with spaces, so what comes back out is not what went in.
      * replacing only the `key:` LINE left the continuation lines of an existing block scalar
        orphaned below it, which is a different document from either the old or the new one.

    `|-` keeps the bytes exactly and needs no quoting rules, and the whole existing block is
    consumed so nothing is orphaned. `decision_answer` then parses the result and refuses unless
    the value reads back identical - the splice is checked, not trusted.
    """
    lines = text.split(chr(10))
    at = next((i for i, ln in enumerate(lines)
               if re.match(r"^" + re.escape(key) + r":", ln)), None)
    if at is None:
        raise Refused(f"the form has no `{key}` field, so there is nothing to answer")
    # CONSUME THE WHOLE VALUE: the key line plus every continuation line under it. A blank line is
    # part of the block only when an indented line still follows it, so a blank separating this
    # field from the next key is left where it is.
    end = at + 1
    while end < len(lines):
        ln = lines[end]
        if ln[:1] in (" ", chr(9)) and ln.strip():
            end += 1
            continue
        if not ln.strip():
            nxt = next((j for j in range(end + 1, len(lines)) if lines[j].strip()), None)
            if nxt is not None and lines[nxt][:1] in (" ", chr(9)):
                end += 1
                continue
        break
    v = str(value)
    # `|2-` CARRIES AN EXPLICIT INDENTATION INDICATOR, and it is not decoration. A bare `|-`
    # infers the block's indent from its first non-empty line, so a value that itself begins with
    # spaces has them absorbed as indentation and comes back trimmed - the one case the read-back
    # below caught. Pinning the indent at 2 makes every space past the second content.
    if v == "":
        repl = [key + ": ''"]
    elif _SAFE_BARE.fullmatch(v) and v.lower() not in _YAML_WORDS:
        # A PLAIN WORD STAYS A PLAIN WORD. `status: RESOLVED` written as a block scalar parses to
        # the same string and makes the register unreadable, and these files are read by people.
        # The pattern is deliberately narrow - one unquoted word of letters, digits, `_` and `-`,
        # and not a word YAML would read as a boolean or a null - and the read-back below is what
        # makes it safe to be even this permissive.
        repl = [key + ": " + v]
    else:
        repl = [key + ": |2-"] + ["  " + ln for ln in v.split(chr(10))]
    lines[at:end] = repl
    return chr(10).join(lines)


def _scalar_of(text, key):
    """The raw value written beside `key:`, for reporting which actor fields are still blank."""
    m = re.search(r"(?m)^" + re.escape(key) + r":[ 	]*(.*)$", text)
    return m.group(1) if m else ""


def _nested_line(key, value):
    """One `  key: value` line under a block, with the same typing discipline as _set_scalar:
    a plain word stays bare; anything else is a nested literal block (`|2-` = content indented
    two past the PARENT mapping, i.e. four from the margin), so YAML cannot re-type it."""
    v = str(value)
    if v == "":
        return ["  " + key + ": ''"]
    if _SAFE_BARE.fullmatch(v) and v.lower() not in _YAML_WORDS:
        return ["  " + key + ": " + v]
    return ["  " + key + ": |2-"] + ["    " + ln for ln in v.split(chr(10))]


def _set_equivalence(text, fields):
    """Set keys inside the form's `equivalence:` block, creating the block when absent.

    The same splice-not-reserialise contract as _set_scalar, one level down. The block is
    appended at the end of the document when the issued form does not carry one — an answer
    that SETTLES a construct equivalence on a form issued before the structured outcome
    existed must still be able to state it, or the closed vocabulary only governs new forms.
    """
    lines = text.split(chr(10))
    at = next((i for i, ln in enumerate(lines) if re.match(r"^equivalence:", ln)), None)
    if at is None:
        while lines and lines[-1].strip() == "":
            lines.pop()
        lines.append("equivalence:")
        for k in EQUIVALENCE_KEYS:
            if k in fields:
                lines.extend(_nested_line(k, fields[k]))
        lines.append("")
        return chr(10).join(lines)
    end = at + 1
    while end < len(lines) and (lines[end][:1] in (" ", chr(9)) or not lines[end].strip()):
        if not lines[end].strip():
            nxt = next((j for j in range(end + 1, len(lines)) if lines[j].strip()), None)
            if nxt is None or lines[nxt][:1] not in (" ", chr(9)):
                break
        end += 1
    block = lines[at:end]
    for k in EQUIVALENCE_KEYS:
        if k not in fields:
            continue
        k_at = next((i for i, ln in enumerate(block)
                     if re.match(r"^  " + re.escape(k) + r":", ln)), None)
        repl = _nested_line(k, fields[k])
        if k_at is None:
            block.extend(repl)
            continue
        k_end = k_at + 1
        while k_end < len(block) and block[k_end].startswith("   "):
            k_end += 1
        block[k_at:k_end] = repl
    lines[at:end] = block
    return chr(10).join(lines)


def compose(current_text, values, path_for_diff="file"):
    """(new_text, diff, refused) for a proposed change to one governed file.

    `refused` is [(field, why)] — the fields this function declined to set, by name, so a page can
    render them as the person's remaining work rather than silently dropping them. Returning them
    is the point: a proposal that quietly ignored `answered_by` would look complete.
    """
    refused, new, eq_fields = [], current_text, {}
    for key in sorted(values):
        if is_actor_field(key):
            refused.append((key, "an actor and the date of their act are not the app's to write: "
                                 "whatever is typed into a browser, this process cannot know who "
                                 "typed it, and a filled name turns 'nobody has signed this' into "
                                 "'somebody appears to have signed this'"))
            continue
        if key in FROZEN:
            refused.append((key, "this is the question as issued, or a digest freezing it; the "
                                 "form's own header says to edit none of them"))
            continue
        val = values[key]
        if val is None or str(val).strip() == "":
            continue                      # nothing proposed for this field; not a refusal
        if key.startswith("equivalence."):
            sub = key.split(".", 1)[1]
            if sub == "equivalence_outcome" and str(val) not in _vocab():
                raise Refused(f"equivalence_outcome {val!r} is not in the closed vocabulary "
                              f"{list(_vocab())} — an outcome word outside it is exactly what "
                              f"the sealed rulings refuse")
            eq_fields[sub] = val
            continue
        new = _set_scalar(new, key, val)
    if eq_fields:
        new = _set_equivalence(new, eq_fields)
    diff = "".join(difflib.unified_diff(
        current_text.splitlines(keepends=True), new.splitlines(keepends=True),
        fromfile="a/" + path_for_diff, tofile="b/" + path_for_diff))
    return new, diff, refused


def _form_path(root, pack_rel, decision_id):
    """The answer form's path, or Refused. Shared by every entry point so a caller cannot reach a
    file through one door that the other door would have refused."""
    if not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9._-]{0,63}", str(decision_id or "")):
        raise Refused("that is not a decision id")
    rel = os.path.join(pack_rel, "handoff", "decision_answers", f"{decision_id}.yaml")
    path = os.path.join(root, rel)
    # CONTAINED: the id is checked above for SHAPE and the resolved path here for WHERE. Two
    # checks because they answer different questions, and a future caller gets both.
    base = os.path.realpath(os.path.join(root, pack_rel, "handoff", "decision_answers"))
    if os.path.commonpath([base, os.path.realpath(path)]) != base:
        raise Refused("that answer file is not inside this pack")
    if not os.path.exists(path):
        raise Refused(f"{rel} does not exist - run `decision_record.py <pack> --forms` to scaffold "
                      f"the answer forms before answering one")
    return path, rel.replace(os.sep, "/")


def read_form(root, pack_rel, decision_id):
    """The form as recorded, for a page to render the question AS ISSUED beside the answer box.

    Read through `product_gates.read_yaml` rather than a local parser: it is the definition of
    "readable" everywhere else in this repository, and a form this app could display but the gate
    could not read would be a page showing a question nothing can act on.
    """
    path, _rel = _form_path(root, pack_rel, decision_id)
    sys.path.insert(0, os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
                                    "platform", "tools"))
    from product_gates import read_yaml                                   # noqa: PLC0415
    doc, err = read_yaml(path)
    if err or not isinstance(doc, dict):
        raise Refused(f"the answer form cannot be read ({err or 'not a mapping'})")
    return doc


def decision_answer(root, pack_rel, decision_id, values):
    """Propose an answer to one decision. Returns a dict a page can render directly.

    Nothing is written. `applied` is deliberately absent from the result: there is no code path
    here that writes, so there is no flag that could ever say it did.
    """
    path, rel = _form_path(root, pack_rel, decision_id)
    current = io.open(path, encoding="utf-8").read()
    # FROZEN keys are not "unknown" - they exist and are refused for a specific, different reason,
    # so they fall through to `compose` which names it. Reporting them as absent would send a
    # reader looking for a field that is right there in the file.
    unknown = [k for k in values
               if k not in ANSWERABLE and k not in FROZEN and not is_actor_field(k)
               and not (k.startswith("equivalence.")
                        and k.split(".", 1)[1] in EQUIVALENCE_KEYS)]
    if unknown:
        raise Refused(f"a decision answer has no {', '.join(sorted(unknown))} field")
    new, diff, refused = compose(current, values, path_for_diff=rel)

    # THE SPLICE IS CHECKED, NOT TRUSTED. Every guarantee above is about how the value is WRITTEN;
    # this is the one that reads it back. The composed bytes are parsed by the same strict loader
    # the gates use, and each field this call set must come out byte-identical to what was
    # submitted. A form that parses but says something subtly different from what the person typed
    # is the worst possible outcome here - worse than a refusal, because it looks like it worked.
    _readback = _parse(new)
    if _readback is None:
        raise Refused("the composed change is not parseable YAML, so it was not offered")
    for k, want in values.items():
        if is_actor_field(k) or k in FROZEN or want is None or str(want).strip() == "":
            continue
        if k.startswith("equivalence."):
            got = (_readback.get("equivalence") or {}).get(k.split(".", 1)[1])
        else:
            got = _readback.get(k)
        if got != str(want):
            raise Refused(f"`{k}` would not survive being written: it reads back as "
                          f"{got!r} rather than what you typed. The change was not "
                          f"offered rather than offered wrong")
    # WHAT IS STILL UNSIGNED, ALWAYS, not only when somebody tried to set it. `refused` is a
    # reaction - it lists the fields this request attempted - so a person who simply typed an
    # answer and pressed the button saw no mention of the signature at all. The guarantee has to
    # be visible on the ordinary path or it is not a guarantee anybody encounters.
    unsigned = [k for k in re.findall(r"(?m)^([a-z0-9_]+):", new)
                if is_actor_field(k) and not str(_scalar_of(new, k)).strip(" '" + chr(34))]
    return {"path": rel, "decision_id": decision_id, "unsigned": unsigned,
            "unchanged": new == current, "new_text": new, "diff": diff, "refused": refused,
            # WHAT THE PERSON STILL HAS TO DO, in order, because the patch alone does not close
            # anything: an answer with no name recorded is exactly what `decision_record.py`
            # already refuses, and it should.
            "then": ["apply the patch to your checkout (`git apply`)",
                     "fill `answered_by` with your own name and `answer_date` with today",
                     "commit — git records you as the author",
                     f"run `decision_record.py {pack_rel} --apply` to write it into DECISIONS.md"]}
