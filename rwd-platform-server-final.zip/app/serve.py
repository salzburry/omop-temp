#!/usr/bin/env python3
"""The READ-ONLY governance app — the surface a Domino deployment serves.

One rule decides everything here: the app is a WINDOW, never a hand. It serves exactly the pages
the governed tools already generate (status flow, rule review, worksheet, decision packets),
the knowledge-graph queries and a start-here page quoting docs/CHAT_JOURNEY.md, each computed fresh per request from the checked-out commit — so what
is on screen is always what is merged, with the commit stamped in the footer. It performs no
governed act: no approval, no decision recording, no regeneration into the repository, and it
serves no file from the checkout itself — every rendered page lands in a temp directory outside
the tree, per the restricted-output rule, and only that byte stream is returned.

Domino runs `app.sh`, which runs this. Binds 0.0.0.0 on $PORT (Domino proxies and authenticates;
set the app's access to your project's collaborators, never public). stdlib only.
"""
import glob
import html
import os
import re
import subprocess
import sys
import tempfile
import threading
import time
import urllib.parse

import proposals
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
TOOLS = os.path.join(ROOT, "platform", "tools")
TMP = tempfile.mkdtemp(prefix="rwdp_app_")
if os.path.realpath(TMP).startswith(os.path.realpath(ROOT) + os.sep):
    raise SystemExit("TMPDIR points inside the checkout — rendered pages must never land in the "
                     "tree; unset TMPDIR or point it elsewhere")

VIEWS = ("flow", "rules", "worksheet") # render_html.py's own vocabulary
LABELS = {"flow": "where this stands", "rules": "every rule, three ways",
          "worksheet": "what to prepare"} # plain-language link text for each view


def packs():
    """The served allowlist — a pack exists because the COMMIT holds it, never because a URL or a
    directory names it. Discovery used to glob the filesystem, and git does not track directories:
    an untracked (or .gitignore'd) `products/.../handoff` directory read as a pack, appeared on
    the board, and served under the clean commit footer — an external review planted exactly
    that. `git ls-files` lists the INDEX, so only tracked content can found a pack; an unreadable
    listing yields no packs, and _proven() is already refusing by then."""
    r = subprocess.run(["git", "ls-files", "--",
                        "products/*/*/*/handoff/*", "fixtures/*/*/*/handoff/*"], cwd=ROOT,
                       capture_output=True, text=True, encoding="utf-8")
    if r.returncode != 0:
        return []
    return sorted({"/".join(p.split("/")[:4]) for p in (r.stdout or "").splitlines()
                   if p.count("/") >= 4})


def commit():
    r = subprocess.run(["git", "rev-parse", "--short", "HEAD"], cwd=ROOT,
                       capture_output=True, text=True, encoding="utf-8")
    return r.stdout.strip() or "unknown"


def _dirty():
    """Paths the working tree changed relative to HEAD, or ['(unreadable)'] when git cannot say.

    The footer stamps a COMMIT, and the pages are rendered from the FILES — an edited checkout
    serves content the stamped commit never contained, which an external review demonstrated: a
    hand-edited register under a clean footer. An unreadable status is treated as dirty, because
    "cannot tell" and "clean" must never be the same answer."""
    r = subprocess.run(["git", "status", "--porcelain"], cwd=ROOT,
                       capture_output=True, text=True, encoding="utf-8")
    if r.returncode != 0:
        return ["(git status unreadable)"]
    return [ln for ln in r.stdout.splitlines() if ln.strip()]


def _provenance():
    """(commit, version) — the STARTUP identity the footer stamps. Either may be 'unknown';
    _proven() turns that into a refusal to serve — see below."""
    try:
        ver = open(os.path.join(ROOT, "platform", "VERSION"), encoding="utf-8").read().strip()
    except OSError:
        ver = "unknown"
    try:
        c = commit()
    except OSError:
        c = "unknown"
    return c, ver


COMMIT, VERSION = None, None # filled by main; tests may call _provenance


def _proven():
    """A governance window ties every page to a merged commit and a platform version — VERIFIED
    PER REQUEST, not remembered from startup. Three ways the footer's claim can stop being true,
    each a refusal: provenance resolved 'unknown'; HEAD moved under the running app (the footer
    would stamp a commit the checkout no longer holds); the working tree is DIRTY (the pages are
    rendered from the files, so an edited checkout serves content the stamped commit never
    contained — under a clean footer, which is the disguise an external review demonstrated).
    Fail-closed on all three."""
    global COMMIT, VERSION
    if COMMIT is None:
        COMMIT, VERSION = _provenance()
    if "unknown" in (COMMIT, VERSION):
        return False
    try:
        now = commit()
    except OSError:
        now = "unknown"
    return now == COMMIT and not _dirty()


def _refusal():
    """The 503 every route serves while provenance cannot be proven. Its own footer may say
    'unknown' — that is the one page where the word is the truth being told."""
    return 503, _frame("cannot prove what is being served",
                       "<h1>cannot prove what is being served</h1>"
                       "<p>every page here must be tied to a merged commit and a platform "
                       "version, and rendered from exactly that commit's files. at least one of "
                       "these is not true right now: git metadata or platform/VERSION is "
                       "unreadable, HEAD moved under the running app, or the working tree has "
                       "uncommitted changes — an edited checkout under a clean footer proves "
                       "nothing. no page is served until the checkout matches what the footer "
                       "would claim; fix the deployment (commit or discard the edits) and "
                       "restart.</p>")


POST_CAP = 65536 # bytes accepted from a form post; a register answer is prose, not a file
# seconds — a governed tool that hangs must fail the request, never the app. 180, not 60: an
# external review measured the cold flow render at 78s and status at 116s under load, so a 60s
# cap GUARANTEED the cold path failed — a bound that fires on every honest first render bounds
# nothing. Runaway tools still die; the memo below makes the wait a once-per-commit event.
TOOL_TIMEOUT = int(os.environ.get("RWDP_TOOL_TIMEOUT", "180"))
TOOL_CAP = 262144 # chars kept per captured stream — real listings and error tails fit;
                       # a runaway tool's output must not balloon a response or the process


def _tool(args):
    """Run one governed tool exactly as the CLI would — the tools stay the one owner of every
    page; this app never re-implements a view. Bounded IN MEMORY, not merely in output:
    `capture_output=True` collected a child's ENTIRE stream before the slice, so a 64 MiB
    stdout cost ~200 MiB of peak RSS to return 256 KiB — an external review measured it. The
    streams are read incrementally into capped buffers and a child that exceeds the cap or the
    timeout is KILLED and reported (returncode 124, the shell's own timeout convention)."""
    cmd = [sys.executable, os.path.join(TOOLS, args[0])] + args[1:]
    p = subprocess.Popen(cmd, cwd=ROOT, stdout=subprocess.PIPE, stderr=subprocess.PIPE)

    def _drain(stream, keep_head):
        """Read to EOF in chunks, keeping only TOOL_CAP bytes (head for stdout — results read
        top-down; tail for stderr — the failing line comes last). Overflow is drained and
        dropped so the child never blocks on a full pipe."""
        kept, total = b"", 0
        while True:
            chunk = stream.read(65536)
            if not chunk:
                return kept, total
            total += len(chunk)
            if keep_head:
                if len(kept) < TOOL_CAP:
                    kept += chunk[:TOOL_CAP - len(kept)]
            else:
                kept = (kept + chunk)[-TOOL_CAP:]
            if total > TOOL_CAP * 64: # runaway stream: kill, keep what we have
                try:
                    p.kill()
                except OSError:
                    pass
                return kept, total

    out = {}
    threads = [threading.Thread(target=lambda k, s, h: out.__setitem__(k, _drain(s, h)),
                                args=(k, s, h), daemon=True)
               for k, s, h in (("out", p.stdout, True), ("err", p.stderr, False))]
    for t in threads:
        t.start()
    try:
        rc = p.wait(timeout=TOOL_TIMEOUT)
    except subprocess.TimeoutExpired:
        p.kill()
        p.wait()
        rc = 124
    for t in threads:
        t.join(timeout=5)
    stdout = out.get("out", (b"", 0))[0].decode("utf-8", "replace")
    stderr = out.get("err", (b"", 0))[0].decode("utf-8", "replace")
    if rc == 124 and not stderr:
        stderr = (f"{args[0]} timed out after {TOOL_TIMEOUT}s — no page is served from a tool "
                  f"that did not finish")
    return subprocess.CompletedProcess(cmd, rc, stdout=stdout, stderr=stderr)


# COMPUTED ONCE PER COMMIT, REUSED BYTE-IDENTICALLY (external review: the cold board took
# 66-116s, the cold flow render 78s — past the old 60s cap — and every later request paid the
# whole price again; concurrent requests each spawned their own subprocess and starved each
# other past the timeout). The memo is SOUND here for one reason: every heavy page is a pure
# function of the served commit, and _proven() already refuses to serve the moment the tree
# stops matching it — so within a serving lifetime a cached page can never disagree with a
# recomputed one. The key carries the commit AND the current `_tool` function object, so a
# test that patches the tool gets its own entries and the real ones return untouched.
_MEMO, _MEMO_FAIL, _MEMO_LOCKS, _MEMO_GUARD = {}, {}, {}, threading.Lock()
# seconds a FAILED computation is remembered — long enough that a queue of requests behind a
# failed single-flight does not re-run a three-minute failure back-to-back (external review:
# waiting requests each repeated the full attempt), short enough that recovery is seen promptly
FAIL_TTL = 30.0


def _memo(key, compute, keep=lambda v: True):
    """compute() once per (commit, _tool, key), single-flight. What `keep` accepts is kept
    for the commit's lifetime; what it rejects is remembered only FAIL_TTL seconds — the
    requests already queued behind a failure get the honest failure instantly instead of
    each repeating the whole attempt, and the next visitor after the TTL retries fresh.
    Concurrent requests for one page wait on its lock and share the one computation."""
    global COMMIT, VERSION
    if COMMIT is None:
        COMMIT, VERSION = _provenance()
    k = (COMMIT, _tool, key)
    hit = _MEMO.get(k)
    if hit is not None:
        return hit[0]
    f = _MEMO_FAIL.get(k)
    if f is not None and time.monotonic() < f[1]:
        return f[0]
    with _MEMO_GUARD:
        lock = _MEMO_LOCKS.setdefault(k, threading.Lock())
    with lock:
        hit = _MEMO.get(k)
        if hit is not None:
            return hit[0]
        f = _MEMO_FAIL.get(k)
        if f is not None and time.monotonic() < f[1]:
            return f[0]
        v = compute()
        if keep(v):
            _MEMO[k] = (v,)
        else:
            _MEMO_FAIL[k] = (v, time.monotonic() + FAIL_TTL)
        return v


def _scrub(text):
    """Tool stderr reaches the browser on failure pages; the tool's own message must survive,
    but machine paths must not — a governance window does not disclose where the checkout
    lives. Only the checkout-root prefix is cut; relative paths still point at the file."""
    return (text or "").replace(ROOT + os.sep, "").replace(ROOT, "")


def _frame(title, body):
    # Accessibility floor, no framework: explicit html/lang for screen readers, viewport for
    # phones, and the content in <main> so its headings outline a document, not a fragment.
    global COMMIT, VERSION
    if COMMIT is None:
        COMMIT, VERSION = _provenance()
    return (f"<!doctype html><html lang='en'><head><meta charset='utf-8'>"
            f"<meta name='viewport' content='width=device-width, initial-scale=1'>"
            f"<title>{html.escape(title)}</title></head>"
            f"<body style='font-family:sans-serif;max-width:70em;margin:2em auto'>"
            f"<main>{body}</main>"
            f"<hr><footer><small>read-only · serving commit {COMMIT} · platform v{VERSION} — "
            f"approvals, signatures and decision answers are committed file edits by a named "
            f"person, never acts of this app</small></footer></body></html>").encode("utf-8")


STATUS_FAILED = "status unavailable — the status tool failed; this page will not guess"

# ------------------------------------------------------- THE PRECOMPUTED SIX-GATE SNAPSHOT
# Domino runs this app; Domino also runs jobs. `governance_snapshot.py` is the job half: it
# computes every pack's six-gate standing ONCE and writes a JSON artifact outside the checkout.
# Measured on this estate: the build takes 219s for 13 packs, the load takes 1.7ms. That is the
# whole reason this exists — the numbers in `_memo`'s comment (cold board 66-116s, cold flow
# render 78s, status at 201s under warm-all contention) are what a stakeholder currently waits
# for, and an app that re-warms on every restart pays them again on every restart.
#
# The property that licenses it is the one `_memo` already states: every heavy page is a pure
# function of the served commit. If that holds, the work can be done once by a job instead of
# repeated inside every app replica.
#
# CONFIGURED-BUT-BROKEN IS A REFUSAL, NEVER A QUIET FALLBACK TO COMPUTING. Falling back would
# make a stale or corrupt snapshot indistinguishable from a healthy one — the app would look
# fine, the job would be silently dead, and nobody would learn that until the numbers on screen
# were wrong. Unset means "no snapshot configured" and the app computes as it always has; set
# means the operator promised one, and a broken promise is said out loud.
SNAPSHOT_ENV = "RWDP_GOVERNANCE_SNAPSHOT"


def _snapshot():
    """(snapshot, errors). (None, []) when no snapshot is configured — that is not an error."""
    path = os.environ.get(SNAPSHOT_ENV)
    if not path:
        return None, []

    def _load():
        sys.path.insert(0, TOOLS)
        import governance_snapshot                                    # noqa: PLC0415
        commit, _ = _provenance()
        # The SERVED commit is passed, so a snapshot describing any other tree is refused rather
        # than rendered under this page's clean footer.
        return governance_snapshot.load(path, ROOT, commit)

    return _memo(("snapshot", path), _load, keep=lambda r: not r[1])


def _standings():
    """{pack: standing} or None, through the memo — the board, the warm pass and the tests
    all share ONE status.py run per commit."""
    return _memo("standings", _standings_raw, keep=lambda v: v is not None)


def _standings_raw():
    """{pack: status.py's own one-line standing}, or None when status.py itself failed. The
    words are the tool's, never this app's — a summary the app composed itself would be a second
    implementation of status, free to flatter. A nonzero exit is a FAILURE, never an empty
    board: whatever status.py printed before dying is plausible rows, and blank standings read
    as 'no news is good news' — so the caller gets None and must say so, not guess.
    status.py separates its columns with runs of spaces; collapsing those runs to one space fused
    'Gate 1' into '3 open' — so column gaps become ' · ', and the words inside stay untouched."""
    r = _tool(["status.py"])
    if r.returncode != 0:
        return None
    out = {}
    for line in (r.stdout or "").splitlines():
        s = line.strip()
        if s.startswith(("products/", "fixtures/")):
            cols = re.split(r"\s{2,}", s)
            out[cols[0]] = " · ".join(c.strip() for c in cols[1:] if c.strip())
    # EXIT ZERO WITH NO ROWS IS A FAILURE, not a quiet board. A truncated or reshaped status
    # output parsed to zero standings and the page rendered every pack blank — which reads as
    # "no news is good news", the exact disguise the nonzero-exit branch already refuses.
    if not out:
        return None
    return out


def _countdown(pack):
    """One line of decision throughput for a pack, from `decision_report`'s own arithmetic.

    THE LOOP UNDER-COMMUNICATED THE COST OF WAITING: the
    ranked page is one click away, but the board never said what the queue was costing — so
    "21 open decisions" read as a fact about a file, not as 62 records nobody can finish. The
    numbers here are computed by `decision_report.blast_radius`, the same function that writes
    the ranked page — never re-derived, so the board and the page cannot disagree.

    LIBRARY, NOT SUBPROCESS, against the grain of this app, for one reason: the tool's CLI
    regenerates SCIENCE_QUESTIONS.md by default, and a GET must never write into the checkout —
    `_proven()` would refuse every request from that moment on, which the app's own tests
    demonstrate. `blast_radius` is the read-only half, and absence-safe by its docstring.

    None when the pack has no decision register yet — a pack before Gate 2 has no queue, which
    is a different answer from a queue of zero."""
    if TOOLS not in sys.path: # once — a long-lived server calls this per row
        sys.path.insert(0, TOOLS)
    import decision_report # noqa: PLC0415
    blocks, _table, _idle, status = decision_report.blast_radius(os.path.join(ROOT, pack))
    if not status:
        return None
    n_open = sum(1 for v in status.values() if v == "OPEN")
    blocked = {v for vs in blocks.values() for v in vs}
    top3 = sorted(blocks.values(), key=len, reverse=True)[:3]
    freed = len({v for vs in top3 for v in vs})
    line = f"{n_open} open decision(s) · {len(blocked)} record(s) blocked"
    if freed:
        line += f" · answering the top {min(3, len(top3))} frees {freed}"
    return line


JOURNEY_DOC = os.path.join("docs", "CHAT_JOURNEY.md")


def _md(text):
    """Escape, then the three inline marks the journey doc uses — code, bold, italic. Escape
    FIRST: repository prose like `<pack>/handoff/` must render as its own strange text, never
    as markup, exactly like pack names on the board."""
    t = html.escape(text)
    t = re.sub(r"`([^`]+)`", r"<code>\1</code>", t)
    t = re.sub(r"\*\*([^*]+)\*\*", r"<b>\1</b>", t)
    return re.sub(r"(?<![\w*])\*([^*\s][^*]*)\*(?![\w*])", r"<i>\1</i>", t)


def _journey_parse(text):
    """docs/CHAT_JOURNEY.md, split into the pieces the start page renders — by shape, not by
    memory: ## headings bound sections, a `1. ` prefix opens a numbered turn (indented lines
    continue it), | lines are the journey table, four-space lines are literal commands. What a
    rename or restructure makes unfindable comes back EMPTY and the composer says so out loud —
    this page quotes the doc or admits it cannot; it never paraphrases."""
    secs, name = {"": []}, ""
    for raw in text.splitlines():
        if raw.startswith("## "):
            name = raw[3:].strip()
            secs[name] = []
        elif not raw.startswith("# "):
            secs.setdefault(name, []).append(raw)

    def blocks(lines):
        out, cur, kind = [], [], [None]
        def flush():
            if cur:
                out.append((kind[0], chr(10).join(cur) if kind[0] == "code"
                            else " ".join(x.strip() for x in cur)))
            del cur[:]
        for ln in lines:
            if not ln.strip():
                flush(); kind[0] = None
            elif ln.lstrip().startswith("|") and not ln.startswith("    "):
                flush(); kind[0] = "row"; cur.append(ln.strip()); flush(); kind[0] = None
            elif re.match(r"\d+\. ", ln):
                flush(); kind[0] = "item"; cur.append(ln.split(". ", 1)[1])
            elif ln.startswith("    ") and kind[0] != "item":
                if kind[0] != "code":
                    flush(); kind[0] = "code"
                cur.append(ln[4:])
            else:
                if kind[0] is None:
                    kind[0] = "p"
                cur.append(ln)
        flush()
        return out

    lb = blocks(secs.get("One loop, one thing on screen", []))
    items = [t for k, t in lb if k == "item"]
    first = next((i for i, (k, _) in enumerate(lb) if k == "item"), None)
    lead = (lb[first - 1][1] if first and lb[first - 1][0] == "p" else "")
    coda = ([t for k, t in lb[first + len(items):] if k == "p"] if items else [])

    rows = []
    for k, t in blocks(secs.get("The journey, as chat", [])):
        if k != "row":
            continue
        cells = [c.strip() for c in t.strip("|").split("|")]
        if len(cells) > 3:
            cells = [cells[0], cells[1], " | ".join(cells[2:])]
        if len(cells) == 3 and cells[0] and not set(cells[0]) <= set("-: "):
            rows.append(cells)

    demo = ""
    for k, t in blocks(secs.get("For people who will never open VS Code", [])):
        if k == "code":
            demo = next((l.strip() for l in t.splitlines()
                         if "chat_demo.py" in l and l.lstrip().startswith("python")), demo)

    return {"intro": [t for k, t in blocks(secs[""]) if k == "p"],
            "loop_lead": lead, "loop": items, "loop_coda": coda,
            "table": rows, "demo_cmd": demo,
            "cannot": [t for k, t in
                       blocks(secs.get("What chat deliberately cannot do", [])) if k == "p"]}


def _gone(what):
    return ("<p role='alert'><strong>docs/CHAT_JOURNEY.md no longer holds " + what +
            " where this page reads it — the doc moved, and this page quotes or refuses; "
            "it does not paraphrase.</strong></p>")


def _start_body(j):
    """The new-user landing, composed: the doc's words, arranged for a first visit, plus the
    one live question a doc cannot answer — which pack is startable in THIS commit. The pack
    rows reuse packs() and _countdown(), the same functions the board trusts, so this page and
    the board cannot disagree about where to begin."""
    intro = ("".join(f"<p>{_md(t)}</p>" for t in j["intro"])
             or _gone("its opening — what the chat is and how it opens"))
    demo = ""
    if j["demo_cmd"]:
        demo = ("<p>No VS Code and no scripts — the standalone, localhost-only chat page:</p>"
                "<pre style='background:#f4f4f4;padding:.6em;overflow-x:auto'>"
                + html.escape(j["demo_cmd"]) + "</pre>")
    if j["loop"]:
        loop = ((f"<p>{_md(j['loop_lead'])}</p>" if j["loop_lead"] else "")
                + "<ol>"
                + "".join(f"<li style='margin-bottom:.5em'>{_md(t)}</li>" for t in j["loop"])
                + "</ol>" + "".join(f"<p>{_md(t)}</p>" for t in j["loop_coda"]))
    else:
        loop = _gone("the four-turn loop")
    # The startable packs lead; the scaffolds share ONE honest line. Eleven identical
    # "nothing here yet" rows above the two real starting points buried exactly the answer a
    # first visit needs — but the scaffolds stay NAMED, because a list that silently hides
    # them would teach a new user that an unlisted pack is an error rather than a pack whose
    # register simply has not been drafted.
    rows, bare = [], []
    for p in packs():
        q = urllib.parse.quote(p)
        c = _countdown(p)
        if c:
            rows.append(f"<li style='margin-bottom:.7em'><b>{html.escape(p)}</b><br>"
                        f"<i>{html.escape(c)}</i><br>"
                        f"<a href='questions?pack={q}'>the questions, ranked</a> · "
                        f"<a href='page?view=flow&pack={q}'>where it stands</a></li>")
        else:
            bare.append(html.escape(p))
    if bare:
        rows.append("<li><small>no decision register yet in " + ", ".join(bare) + " — asking "
                    "chat for their questions gets the honest answer &quot;nothing to "
                    "answer&quot;, not a page</small></li>")
    if j["table"]:
        head, rest = j["table"][0], j["table"][1:]
        cell = "border:1px solid #ccc;padding:.4em .5em;vertical-align:top;text-align:left"
        trs = ("<tr>" + "".join(f"<th style='{cell}'>{_md(c)}</th>" for c in head) + "</tr>"
               + "".join("<tr>" + "".join(f"<td style='{cell}'>{_md(c)}</td>" for c in r)
                         + "</tr>" for r in rest))
        table = (f"<details><summary style='cursor:pointer'>every turn the chat understands "
                 f"— the full journey table, {len(rest)} turns</summary>"
                 f"<div style='overflow-x:auto'><table style='border-collapse:collapse;"
                 f"margin-top:.6em;font-size:.92em'>{trs}</table></div></details>")
    else:
        table = _gone("the journey table")
    cannot = ("".join(f"<p>{_md(t)}</p>" for t in j["cannot"])
              or _gone("the boundary — what chat deliberately cannot do"))
    return (
        "<h1>Start here</h1>"
        "<p>How a new person operates this product. The words below are quoted from "
        "<code>docs/CHAT_JOURNEY.md</code> at the commit in the footer; the pack rows are "
        "computed by the same functions the <a href='/'>board</a> uses.</p>"
        "<h2>The interface is chat</h2>" + intro + demo +
        "<h2>The loop — four turns, one page each</h2>" + loop +
        "<h2>Somewhere to start, in this commit</h2><ul>" + "".join(rows) + "</ul>"
        "<p><small>A pack absent here holds no handoff at all — the <a href='/'>board</a> "
        "lists every pack the status tool reports, including those.</small></p>"
        "<h2>Every turn, for later</h2>" + table +
        "<h2>What chat deliberately cannot do</h2>" + cannot +
        "<p><a href='/'>← the board: where everything stands</a></p>")


def start():
    """The new-user landing. A missing or unreadable journey doc serves the page with every
    section announcing the absence — an honest outage, exactly like a dead status tool on the
    board — because a silent fallback composed by this app would be paraphrase."""
    if not _proven():
        return _refusal()
    try:
        with open(os.path.join(ROOT, JOURNEY_DOC), encoding="utf-8") as fh:
            text = fh.read()
    except OSError:
        text = ""
    return 200, _frame("start here", _start_body(_journey_parse(text)))


def index():
    # Two links lead, because they are the two acts a stakeholder takes: see where it stands, see
    # what is owed. The reviewer views (rules, worksheet) stay one click away but read as "deeper",
    # not as a menu of equal things — the streamlined loop, not a file listing.
    # EVERY pack status.py reports is on the board — a page titled "where everything stands" that
    # silently hides the packs with no handoff/ yet is a summary free to flatter. Those rows carry
    # their standing and say why there is nothing to click.
    if not _proven():
        return _refusal()
    standing = _standings()
    served = packs()
    degraded = standing is None
    if degraded:
        # status.py died: the board still lists every served pack (the links still work), but a
        # banner and EVERY row say the standing is unavailable — an honest outage, never blank
        # standings that read as "all quiet". The HTTP code says so too: an external review
        # measured that a 200 here taught machines (and people probing with curl) that the
        # board was functional while every standing was a shrug — a degraded board is 503.
        banner = f"<p role='alert'><strong>{html.escape(STATUS_FAILED)}</strong></p>"
        standing = {p: STATUS_FAILED for p in served}
    else:
        banner = ""
    # `p` is a repository path and repository paths are DATA here, exactly like tool output: a
    # pack directory named `<script>…` must render as its own strange name, never execute. An
    # external review demonstrated stored markup injection through this interpolation.
    rows = "".join(
        f"<li style='margin-bottom:.8em'><b>{html.escape(p)}</b><br>"
        f"<span>{html.escape(standing.get(p, ''))}</span><br>"
        + (f"<i>{html.escape(c)}</i><br>" if (c:= (_countdown(p) if p in served else None))
           else "")
        + (f"<a href='page?view=flow&pack={q}'>{LABELS['flow']}</a>"
           f" · <a href='questions?pack={q}'>questions awaiting an answer</a><br>"
           f"<small>deeper: <a href='page?view=rules&pack={q}'>{LABELS['rules']}</a>"
           f" · <a href='page?view=worksheet&pack={q}'>{LABELS['worksheet']}</a></small>"
           if p in served else
           "<small>no handoff yet — nothing to serve; the standing above is the whole story</small>")
        + "</li>"
        for p in sorted(set(served) | set(standing)) for q in [urllib.parse.quote(p)])
    # No /suggest link here: the route survives for those who know it, but review measured its
    # precision as indefensible for a stakeholder front page — the board does not advertise it.
    body = (f"<h1>RWD data products — where everything stands</h1>{banner}"
            f"<p><a href='start'>new here? start here — how this product is operated from chat</a></p>"
            f"<p><a href='portfolio'>the 13-tumour portfolio — status, coverage, drift</a></p>"
            f"<p>Every number on every page here is computed by the governed tools from the merged "
            f"repository state named in the footer — computed once per commit and reused "
            f"byte-identically; nothing is typed in or editable from this app. If a page says "
            f"something is blocked, it is blocked; the page also says who "
            f"owes the next action.</p><ul>{rows}</ul>"
            f"<form action='knowledge'><label for='q'>search past decisions</label> "
            f"<input id='q' name='q' placeholder='have we decided … before?' "
            f"size='40'><button>search</button></form>")
    return (503 if degraded else 200), _frame("RWD governance", body)


def _render(cli):
    """Run a page generator into a PER-REQUEST temp file and return its bytes.

    Per request, not per (view, pack): a shared path let two concurrent requests for the same
    page write over each other's file and serve a torn read — the server is threaded, so this is
    not theoretical. Each request gets its own file and removes it after reading."""
    fd, out = tempfile.mkstemp(suffix=".html", dir=TMP)
    os.close(fd)
    try:
        r = _tool(cli + ["--out", out])
        if r.returncode != 0 or not os.path.getsize(out):
            # scrub BEFORE truncating, so a cut can never resurrect a path prefix
            return 500, _frame("failed",
                               f"<pre>{html.escape(_scrub(r.stderr or r.stdout)[-2000:])}</pre>")
        raw = open(out, "rb").read()
        # the provenance footer rides EVERY page, generated ones included — a page without the
        # served commit is a page nobody can tie to a merged state
        foot = _frame("x", "").split(b"<hr>", 1)[1].rsplit(b"</body>", 1)[0]
        if b"</body>" in raw:
            return 200, raw.replace(b"</body>", b"<hr>" + foot + b"</body>", 1)
        return 200, raw + b"<hr>" + foot
    finally:
        try:
            os.unlink(out)
        except OSError:
            pass


def page(view, pack):
    if not _proven():
        return _refusal()
    if view not in VIEWS or pack not in packs():
        return 404, _frame("not here", "<p>unknown view, or a pack this repository does not hold "
                                       "or cannot serve yet (no handoff/).</p>")
    return _memo(("page", view, pack), lambda: _render(["render_html.py", view, pack]),
                 keep=lambda r: r[0] == 200)


def questions(pack):
    if not _proven():
        return _refusal()
    if pack not in packs():
        return 404, _frame("not here", "<p>unknown pack.</p>")
    status, body = _memo(("questions", pack), lambda: _render(["decision_packet.py", pack]),
                        keep=lambda r: r[0] == 200)
    if status == 200:
        # THE DOOR TO THE COMPOSER, on the page that ranks what needs answering. A GET form,
        # so it composes a URL and nothing else; the id is validated by the answer route.
        nav = (f"<form method='get' action='/answer' style='border:1px solid #ccc;"
               f"padding:.5em;margin:.5em 0'>"
               f"<input type='hidden' name='pack' value='{html.escape(pack)}'>"
               f"answer a decision from this page: <input name='id' size='24' "
               f"placeholder='decision id, e.g. STUDY-WINDOW'> "
               f"<button type='submit'>open the answer form</button></form>").encode("utf-8")
        at = body.find(b"<h1")
        body = body[:at] + nav + body[at:] if at >= 0 else nav + body
    return status, body


def knowledge(q):
    # A query term is DATA, never a flag: without the strip, `?q=--suggest` reached the CLI's
    # argument parser and ran a different verb than the route promises. Leading dashes carry no
    # meaning for a substring search, so they are dropped rather than refused.
    if not _proven():
        return _refusal()
    terms = [t.lstrip("-") for t in q.split() if t.strip().lstrip("-")]
    if not terms:
        return 200, _frame("search", "<p>type terms, e.g. <i>biomarker window</i>.</p>")
    r = _tool(["knowledge_graph.py", "--query"] + terms)
    if r.returncode != 0: # no-match exits 0; nonzero is a FAILURE
        return 500, _frame("failed",
                           f"<pre>{html.escape(_scrub(r.stderr or r.stdout)[-2000:])}</pre>")
    return 200, _frame(f"decisions: {q}", f"<pre>{html.escape(r.stdout)}</pre>")


def portfolio():
    """The portfolio table, from the COMMITTED generated file — never regenerated per request.

    `portfolio_status.py` WRITES products/PORTFOLIO.md when it runs, and a GET must never write
    into the checkout (see `_countdown`). The committed copy is exactly as trustworthy as
    everything else this app serves: `_proven()` guarantees the tree equals the served commit,
    and `portfolio_status --check` refuses a stale copy in CI — so the file on disk IS the
    tool's current answer, verified, without this app running anything."""
    if not _proven():
        return _refusal()
    path = os.path.join(ROOT, "products", "PORTFOLIO.md")
    if not os.path.exists(path):
        return 404, _frame("not here", "<p>products/PORTFOLIO.md is not in this checkout — "
                                       "run portfolio_status.py and commit its output.</p>")
    text = open(path, encoding="utf-8").read()
    return 200, _frame("portfolio", f"<h1>Portfolio — every registered tumour</h1>"
                                    f"<p>The committed view generated by portfolio_status.py; "
                                    f"CI refuses a stale copy.</p>"
                                    f"<pre>{html.escape(text)}</pre>")


# THE MARKS, AND WHY THERE IS NO CATCH-ALL. The first rendered page showed Gate 6 as `blocked`
# with the SAME filled circle as `done`, because `blocked` was not in this table and the fallback
# was that circle. Thirteen gates across the estate are blocked right now, so this was not a
# hypothetical: a governance page was drawing a stop as a completion, which is the one direction
# a status bug must never point. An UNKNOWN status now renders as an explicit question mark and
# the word itself, so a state this table has not been taught is visibly untranslated rather than
# silently flattered into the nearest good-looking glyph.
GATE_MARK = {"done": "&#9679;",            # filled circle
             "in progress": "&#9686;",     # half-filled
             "not started": "&#9675;",     # hollow
             "blocked": "&#8856;"}         # circled slash - a stop, never mistakable for done
GATE_MARK_UNKNOWN = "&#63;"


def _gate_block(g, owners):
    """One gate, as the snapshot reports it. Every word here is status.py's, never composed."""
    st = str(g.get("status") or "unknown")
    mark = GATE_MARK.get(st, GATE_MARK_UNKNOWN)
    who = owners.get(str(g.get("gate")), "")
    ap = g.get("approval") or {}
    bits = [f"<h3>{mark} Gate {html.escape(str(g.get('gate')))} — "
            f"{html.escape(str(g.get('name') or ''))} <small>({html.escape(st)})</small></h3>"]
    if who:
        bits.append(f"<p><small>who acts: {html.escape(who)}</small></p>")
    if ap.get("required"):
        signed = ap.get("approved_by")
        bits.append("<p><small>approval: %s — %s</small></p>" % (
            html.escape(str(ap.get("form") or "(no form named)")),
            f"signed by {html.escape(str(signed))}" if signed
            else "<strong>not signed</strong>. A signature is a committed file edit by a named "
                 "person; this app cannot make one"))
    blockers = [b for b in (g.get("blockers") or [])]
    if blockers:
        bits.append("<ul>" + "".join(f"<li>{html.escape(str(b))}</li>" for b in blockers) + "</ul>")
    return "".join(bits)


def gates(pack=""):
    """The Gate 1-6 journey, read from the precomputed snapshot when one is configured.

    THIS PAGE COMPOSES NOTHING. Gate states, blockers, approval forms and the next action are
    status.py's own findings, carried verbatim through the snapshot; the gate-to-role line is
    status.OWNER, which status.py says is the single machine-readable form of WORKFLOW.md's prose.
    A page that summarised in its own words would be a second implementation of status, free to
    flatter — the same rule `_standings_raw` states for the board.
    """
    if not _proven():
        return _refusal()
    snap, errs = _snapshot()
    if errs:
        return 503, _frame("snapshot refused",
                           "<h1>The configured snapshot cannot be trusted</h1>"
                           "<p>%s is set, so this app will not compute around it and will not "
                           "guess. Rebuild it with <code>governance_snapshot.py --out</code>.</p>"
                           "<ul>%s</ul>" % (html.escape(SNAPSHOT_ENV),
                                            "".join(f"<li>{html.escape(e)}</li>" for e in errs)))
    if snap is None:
        return 200, _frame("gates", (
            "<h1>Gate 1-6</h1><p>No snapshot is configured, so this page has nothing precomputed "
            "to read. Set <code>%s</code> to a snapshot built by "
            "<code>platform/tools/governance_snapshot.py</code> — on Domino, the artifact a job "
            "wrote. The board at <a href='/'>/</a> computes live in the meantime.</p>"
            % html.escape(SNAPSHOT_ENV)))

    owners = snap.get("owners") or {}
    prov = snap.get("provenance") or {}
    stamp = ("<p><small>from a snapshot built %s at commit %s</small></p>"
             % (html.escape(str(prov.get("generated_at"))),
                html.escape(str(prov.get("commit_short")))))
    if not pack:
        rows = []
        for rel in sorted(snap.get("packs") or {}):
            e = snap["packs"][rel]
            done = sum(1 for g in (e.get("gates") or []) if g.get("status") == "done")
            badge = (" <strong>[reference fixture — never deploy, never release]</strong>"
                     if e.get("kind") == "fixture" else "")
            rows.append(f"<li><a href='/gates?pack={urllib.parse.quote(rel)}'>"
                        f"{html.escape(rel)}</a> — {done} of "
                        f"{len(e.get('gates') or [])} gates done{badge}</li>")
        for rel, why in sorted((snap.get("unreadable") or {}).items()):
            # NAMED, never dropped — a board that omitted it would report fewer problems than exist
            rows.append(f"<li>{html.escape(rel)} — <strong>COULD NOT BE READ</strong>: "
                        f"{html.escape(str(why))}</li>")
        return 200, _frame("gates", "<h1>Gate 1-6, every pack</h1>" + stamp
                           + "<ul>" + "".join(rows) + "</ul>")

    entry = (snap.get("packs") or {}).get(pack)
    if entry is None:
        why = (snap.get("unreadable") or {}).get(pack)
        if why:
            return 200, _frame("gates", f"<h1>{html.escape(pack)}</h1>"
                                        f"<p><strong>This pack could not be read when the "
                                        f"snapshot was built</strong>: {html.escape(str(why))}</p>")
        return 404, _frame("not here", "<p>no such pack in this snapshot.</p>")
    banner = ("<p><strong>Reference fixture — exercise material; never deploy, never release."
              "</strong></p>" if entry.get("kind") == "fixture" else "")
    body = [f"<h1>{html.escape(pack)}</h1>", banner, stamp,
            f"<p><a href='/gates'>&larr; every pack</a> · "
            f"<a href='/questions?pack={urllib.parse.quote(pack)}'>open decisions</a></p>"]
    na = entry.get("next_action")
    if na:
        # status.next_action() returns the TRIPLE (gate, who, what), which JSON carries as a list.
        # str() on it printed a Python literal onto the page — brackets, quotes and all — on the
        # very first render. Unpacked here; anything of another shape is shown as-is rather than
        # guessed at, because a next action nobody can read is worse than an ugly one.
        if isinstance(na, (list, tuple)) and len(na) == 3:
            n, who, what = na
            where = f"Gate {html.escape(str(n))}" if n is not None else "Every gate is done"
            body.append(f"<h2>Next action</h2><p><strong>{where}</strong> &mdash; "
                        f"{html.escape(str(what))}</p>"
                        f"<p><small>who acts: {html.escape(str(who))}</small></p>")
        else:
            body.append(f"<h2>Next action</h2><p>{html.escape(str(na))}</p>")
    for g in (entry.get("gates") or []):
        body.append(_gate_block(g, owners))
    return 200, _frame("gates", "".join(body))


def suggest():
    if not _proven():
        return _refusal()
    r = _tool(["knowledge_graph.py", "--suggest"])
    if r.returncode != 0:
        return 500, _frame("failed",
                           f"<pre>{html.escape(_scrub(r.stderr or r.stdout)[-2000:])}</pre>")
    return 200, _frame("candidates", f"<pre>{html.escape(r.stdout)}</pre>")


# ONLY RESOLVED IS OFFERED, and the reason is that the page cannot keep its own promise for the
# other two. `decision_record.form_errors` demands `answered_by` and `answer_date` ONLY when the
# status is RESOLVED - so a WITHDRAWN composed here would sail through the gate with nobody
# recorded behind it, which is exactly what this page tells the reader cannot happen. SUPERSEDED
# additionally requires a `superseded_by` naming the replacing decision, and there is no input for
# it, so every SUPERSEDED proposal would be composed only to be refused downstream.
#
# Withdrawing or superseding a decision stays a hand edit until the attribution rule covers all
# three terminal states the same way. Offering a control that produces an unattributable change
# would be worse than offering nothing.
DECISION_STATUSES = ("RESOLVED",)


def _answer_form(pack, did):
    """The question as issued, and a box for the answer. Nothing else is editable here.

    THE BARRIER THIS REMOVES IS THE RIGHT ONE. Answering a decision means finding one file among
    eleven keys and not disturbing the digests that freeze the question — a real obstacle with no
    governance value, and twenty-one decisions have sat open behind it. What it does NOT remove is
    the signature: this page has no field for `answered_by`, because a name typed into a browser is
    a name this process cannot attribute to anyone.
    """
    if pack not in packs():
        return 404, _frame("no such pack", "<p>that pack is not in the commit.</p>")
    try:
        cur = proposals.read_form(ROOT, pack, did)
    except proposals.Refused as exc:
        return 400, _frame("cannot answer that", f"<p>{html.escape(str(exc))}</p>")
    # STATUS AS CHOICES, NONE PRE-SELECTED. A defaulted status is a decision the page made;
    # required radios make the person make it (docs/AUTHORING_UI_BOUNDARY.md: one act, chosen).
    blurb = {"RESOLVED": "this answers the question", "WITHDRAWN": "the question is retracted",
             "SUPERSEDED": "replaced by another register row (pick it below)"}
    radios = "".join(
        f"<label style='display:block'><input type='radio' name='status' value='{s}' required> "
        f"<b>{s}</b> — {blurb.get(s, '')}</label>" for s in DECISION_STATUSES)
    # No superseded_by control while SUPERSEDED is not offerable (see DECISION_STATUSES):
    # a picklist composing a field the wave must refuse would be the page promising an act
    # the gate does not accept. When the retraction-attribution design lands, the statuses
    # tuple grows and the control comes back with it.
    # THE EQUIVALENCE BLOCK, AS CHOICES FROM THE CLOSED VOCABULARY — the words the sealed
    # ruling machinery accepts, so a construct answer cannot be phrased outside them. Shown
    # pre-filled from the form when the block was issued with it; offered empty otherwise.
    eq = cur.get("equivalence") if isinstance(cur.get("equivalence"), dict) else {}
    eq_val = lambda k: html.escape(str(eq.get(k) or ""))
    eq_radios = "".join(
        f"<label style='display:block'><input type='radio' name='equivalence.equivalence_outcome' "
        f"value='{v}'{' checked' if eq.get('equivalence_outcome') == v else ''}> <b>{v}</b>"
        f"</label>" for v in proposals._vocab())
    eq_html = (
        f"<details{' open' if eq else ''}><summary>this answer settles a construct "
        f"equivalence (two sources claimed to measure one variable)</summary>"
        f"<p>outcome — the closed vocabulary the sealed ruling will be checked against:</p>"
        f"{eq_radios}"
        f"<p>variable <input name='equivalence.variable' value='{eq_val('variable')}' size='24'> "
        f"source_a <input name='equivalence.source_a' value='{eq_val('source_a')}' size='18'> "
        f"source_b <input name='equivalence.source_b' value='{eq_val('source_b')}' size='18'></p>"
        f"<p>rationale <input name='equivalence.rationale' value='{eq_val('rationale')}' "
        f"size='80'></p></details>")
    return 200, _frame(f"answer {did}", (
        f"<h1>answer <code>{html.escape(did)}</code></h1>"
        f"<p><small>{html.escape(pack)}</small></p>"
        f"<h2>the question, as issued</h2><pre style='white-space:pre-wrap'>"
        f"{html.escape(cur.get('question') or '')}</pre>"
        f"<h2>evidence recorded with it</h2><pre style='white-space:pre-wrap'>"
        f"{html.escape(cur.get('evidence') or '')}</pre>"
        f"<p><a href='/knowledge?q={urllib.parse.quote(did)}'>what other registers hold for "
        f"this question</a> — evidence for the answerer, never an answer</p>"
        f"<h2>your answer</h2>"
        f"<form method='post' action='/answer'>"
        f"<input type='hidden' name='pack' value='{html.escape(pack)}'>"
        f"<input type='hidden' name='id' value='{html.escape(did)}'>"
        f"<p><textarea name='answer' rows='6' cols='90' required "
        f"placeholder='State the decision in full sentences. No | characters: the register is a "
        f"markdown table.'></textarea></p>"
        f"{radios}{eq_html}"
        f"<p><button type='submit'>compose the change</button></p></form>"
        f"<h2>what this page will not do</h2>"
        f"<p>It will not fill <code>answered_by</code> or <code>answer_date</code>. Those are the "
        f"whole content of the act, and this process cannot know who is at the keyboard. You will "
        f"get a patch to apply, fill and commit under your own name.</p>"))


def _answer_proposal(pack, did, answer, status, extra=None):
    """The composed change, as a diff. Still nothing written."""
    if pack not in packs():
        return 404, _frame("no such pack", "<p>that pack is not in the commit.</p>")
    if status and status not in DECISION_STATUSES:
        return 400, _frame("not a status", "<p>that is not a decision status.</p>")
    values = {"answer": answer, "status": status}
    values.update(extra or {})
    try:
        got = proposals.decision_answer(ROOT, pack, did, values)
    except proposals.Refused as exc:
        return 400, _frame("cannot answer that", f"<p>{html.escape(str(exc))}</p>")
    if got["unchanged"]:
        return 200, _frame("nothing to change", "<p>that leaves the form exactly as it is.</p>")
    refused = "".join(f"<li><code>{html.escape(f)}</code> — {html.escape(w)}</li>"
                      for f, w in got["refused"])
    steps = "".join(f"<li>{html.escape(t)}</li>" for t in got["then"])
    return 200, _frame(f"proposed answer for {did}", (
        f"<h1>proposed change</h1>"
        f"<p><small>{html.escape(got['path'])}</small></p>"
        f"<pre style='overflow-x:auto;border:1px solid #ccc;padding:1em'>"
        f"{html.escape(got['diff'])}</pre>"
        + (f"<h2>fields this app declined to write</h2><ul>{refused}</ul>" if refused else "")
        + (f"<h2>still unsigned</h2><p>This change leaves "
           + ", ".join(f"<code>{html.escape(u)}</code>" for u in got["unsigned"])
           + " blank, and every gate downstream will keep refusing the decision until a person "
             "fills them. That is not an oversight in the patch; it is the only part of this "
             "that had to stay a human act.</p>" if got["unsigned"] else "")
        + f"<h2>what remains yours</h2><ol>{steps}</ol>"
        f"<p>Nothing has been written. Copy the diff above, apply it, and the commit records "
        f"you as the author — which is the only thing that makes the answer attributable.</p>"))


class Handler(BaseHTTPRequestHandler):
    def do_GET(self):
        u = urllib.parse.urlparse(self.path)
        qs = urllib.parse.parse_qs(u.query)
        one = lambda k: (qs.get(k) or [""])[0]
        if not _proven():
            # EVERY route refuses on unknown provenance, the 404 page included — a page that
            # cannot be tied to a merged commit proves nothing, whatever its status code
            status, body = _refusal()
        elif u.path == "/":
            status, body = index()
        elif u.path == "/page":
            status, body = page(one("view"), one("pack"))
        elif u.path == "/questions":
            status, body = questions(one("pack"))
        elif u.path == "/knowledge":
            status, body = knowledge(one("q"))
        elif u.path == "/start":
            status, body = start()
        elif u.path == "/portfolio":
            status, body = portfolio()
        elif u.path == "/gates":
            status, body = gates(one("pack"))
        elif u.path == "/suggest":
            status, body = suggest()
        elif u.path == "/ready":
            status, body = ready()
        elif u.path == "/answer":
            status, body = _answer_form(one("pack"), one("id"))
        else:
            status, body = 404, _frame("not here", "<p>six routes and a search box; "
                                                   "nothing else is served.</p>")
        # PROVENANCE, RE-VERIFIED AFTER RENDERING. The check at the top ran BEFORE the tools
        # read the files; an edit landing in that window rendered edited content under the old
        # clean footer — an external review timed exactly that race. The window between this
        # check and the socket write is the irreducible remainder; everything the tools READ is
        # inside the two checks.
        if status == 200 and not _proven():
            status, body = _refusal()
        self.send_response(status)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("Cache-Control", "no-store")
        self.send_header("Referrer-Policy", "no-referrer")
        self.end_headers()
        self.wfile.write(body)

    def do_POST(self):
        # the window has no hands: no route accepts a write, so say 405, not an ambiguous 501
        # (unless provenance is unknown — the refusal outranks even the refusal to write)
        if not _proven():
            code, body = _refusal()
        else:
            u = urllib.parse.urlparse(self.path)
            if u.path != "/answer":
                code = 405
                body = _frame("read-only", "<p>this app writes nothing — approvals and answers "
                                           "are committed file edits by a named person. The one "
                                           "POST route composes a change and hands you the "
                                           "patch; it does not apply it.</p>")
            else:
                # BOUNDED READ. A Content-Length a client can set to anything is a length this
                # process must not trust: an unbounded read here would let one request hold the
                # whole window while it allocated.
                try:
                    n = int(self.headers.get("Content-Length") or 0)
                except ValueError:
                    n = -1            # non-numeric is MALFORMED (400), not "empty body" (third audit)
                if n < 0:
                    # A NEGATIVE LENGTH IS A MALFORMED REQUEST, answered as one. It used to fall
                    # through both branches below and leave `code`/`body` unassigned — an
                    # UnboundLocalError instead of a deterministic 400 (second audit).
                    code, body = 400, _frame("bad request", (
                        "<p>Content-Length must be a non-negative integer.</p>"))
                    n = -1
                elif n > POST_CAP:
                    # REFUSED, NOT TRUNCATED. Clamping the read silently discarded the tail of an
                    # over-long answer and then composed a diff from the part that fitted - a
                    # governed change quietly different from the one the person submitted, which
                    # is the failure this whole module is built to avoid.
                    code, body = 413, _frame("too long", (
                        "<p>that submission is larger than this window accepts. A register answer "
                        "is a ruling in prose, not a document - state the decision here and put "
                        "the detail in the artifacts the ruling governs.</p>"))
                    n = -1
                raw = self.rfile.read(n).decode("utf-8", "replace") if n > 0 else ""
                if n >= 0:
                    f = urllib.parse.parse_qs(raw)
                    pick = lambda k: (f.get(k) or [""])[0]
                    extra = {k: pick(k) for k in
                             ("superseded_by",
                              *("equivalence." + e for e in proposals.EQUIVALENCE_KEYS))
                             if pick(k).strip()}
                    code, body = _answer_proposal(pick("pack"), pick("id"),
                                                  pick("answer"), pick("status"), extra)
            #...RE-VERIFIED, the same race the GET path closes: the proposal READ pack files, and
            # an edit landing in that window would compose a diff against bytes the footer's
            # commit never held.
            if code == 200 and not _proven():
                code, body = _refusal()
        self.send_response(code)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Allow", "GET")
        self.end_headers()
        self.wfile.write(body)

    def log_message(self, fmt, *args): # quiet; Domino keeps its own access logs
        pass


_WARM = {"done": False, "failed": 0, "log": []}


def _note(line):
    _WARM["log"].append(line)
    print(f"warm: {line}")


def _warm():
    """Precompute the heavy pages once, at startup, in the background — the unassisted first
    visitor then lands on warm bytes instead of paying the cold render (78s for the flow page,
    measured) behind their first click. Single-flight makes a request arriving mid-warm SHARE
    the running computation rather than double it.

    Only the STARTABLE packs warm — the ones with a decision register, the same set the start
    page leads with. Warming every pack serialized ~24 heavy renders behind the first visitor
    and the external review measured the contention it caused (status at 201s under that
    load); a scaffold's page renders on demand instead, which is what "no decision register
    yet" costs. And a page is called ready ONLY when its bytes actually entered the cache —
    the first version printed "ready" unconditionally, which after a timeout was a false
    warm-state log. /ready reports this state; a 200 board mid-warm
    proves nothing."""
    try:
        if not _proven():
            _WARM["failed"] += 1
            _note("skipped — provenance cannot be proven, the routes are refusing")
            return
        ok = _standings() is not None
        if not ok:
            _WARM["failed"] += 1
        _note("board standings " + ("ready" if ok
                                    else "FAILED — the board says so and answers 503"))
        for p in packs():
            if _countdown(p) is None:
                continue # scaffold: no register, not a starting point
            s1 = _memo(("page", "flow", p),
                       lambda p=p: _render(["render_html.py", "flow", p]),
                       keep=lambda r: r[0] == 200)[0]
            s2 = _memo(("questions", p),
                       lambda p=p: _render(["decision_packet.py", p]),
                       keep=lambda r: r[0] == 200)[0]
            if s1 != 200 or s2 != 200:
                _WARM["failed"] += 1
            _note(f"{p} " + ("flow + questions ready" if s1 == 200 and s2 == 200
                             else f"FAILED (flow {s1}, questions {s2}) — retried on demand"))
    finally:
        _WARM["done"] = True
        _note(f"warm pass finished for commit {COMMIT}")


def ready():
    """200 only when the warm pass FINISHED AND EVERY page it attempted entered the cache
    — a preflight (or an unassisted visitor's operator) asks THIS route, never infers
    readiness from a 200 board. The first version answered 200 whenever the pass was
    merely OVER: the review forced every warm render to fail and /ready still said 200 —
    readiness is success, not completion. The body lists what warmed and what failed, in
    the warm pass's own words."""
    if not _proven():
        return _refusal()
    items = "".join(f"<li>{html.escape(x)}</li>" for x in _WARM["log"]) or \
        "<li>the warm pass has not started</li>"
    if _WARM["done"] and not _WARM["failed"]:
        return 200, _frame("ready", f"<h1>warm pass complete</h1><ul>{items}</ul>")
    if _WARM["done"]:
        return 503, _frame("not ready",
                           f"<h1>warm pass finished with {_WARM['failed']} failure(s)</h1>"
                           f"<ul>{items}</ul><p>the failed pages retry on demand; "
                           f"re-check the target routes directly before relying on them.</p>")
    return 503, _frame("warming", f"<h1>still warming</h1><ul>{items}</ul>"
                                  f"<p>heavy pages may be slow until this returns 200.</p>")


if __name__ == "__main__":
    import argparse
    argparse.ArgumentParser(description="Run the read-only governance board. Configure HOST and PORT in the environment; the default is loopback:8888.").parse_args()
    port = int(os.environ.get("PORT", "8888"))
    # loopback by default: this app has no authentication, so a laptop must not serve the
    # LAN unasked. Domino needs 0.0.0.0 and announces itself through its
    # own env; anyone else opts in explicitly with HOST=0.0.0.0.
    on_domino = any(k.startswith("DOMINO_") for k in os.environ)
    host = os.environ.get("HOST") or ("0.0.0.0" if on_domino else "127.0.0.1")
    print(f"rwdp governance app: read-only, commit {commit()}, {host}:{port}")
    if os.environ.get("RWDP_WARM_FIRST") == "1":
        # deployment-time precompute: finish the whole warm pass BEFORE accepting traffic
        # — for a rehearsed demo or a deployment where the first visitor must never race
        # the warmer. Default stays background warming (the server answers immediately;
        # /ready says when the heavy pages are actually in the cache).
        print("warm-first: precomputing before accepting traffic (RWDP_WARM_FIRST=1)")
        _warm()
    else:
        threading.Thread(target=_warm, daemon=True).start()
    ThreadingHTTPServer((host, port), Handler).serve_forever()
