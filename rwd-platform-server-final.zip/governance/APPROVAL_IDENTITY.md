# Design: authenticated approval events

**Status: the PR-review design below is STILL NOT IMPLEMENTED. Two narrower things now are —
see "What exists today" — and neither is a substitute for it.**

## Current local signing boundary

The signing helper uses an **existing registered key** to sign exact review bytes.
It creates no keys and cannot add signer registrations. The registry, registrar
name, local Git refs and verifier settings are all editable by the local operator;
none independently proves that the named person exists or enrolled that key.

The identity checker therefore reports `signature_verified` separately and keeps
`authenticated: false`. A successful local signature does not clear reviewer
identity gates. `RWDP_BASE_REF` and `--base-ref` only select the historical-baseline
comparison; pointing either at a locally created enrolment commit cannot grant
authentication. Saved drafts and verified signatures remain available for review.

Before person authentication can be enabled, the responsible organization must
establish protected remote enrolment, verify its account-to-person/key mapping,
and integrate the authenticated review evidence described below. That integration
is not provided by this local application. No environment flag enables it, and
the application does not treat a self-entered registration as provisioning.

The separate Ed25519 event ledger uses `governance/SIGNING_KEYS.yaml`. Its legacy
`authenticated` event-trust value means that the event's cryptographic signature
verified against that registry, not that an organization authenticated the person.
The portal now reports this as `signature_verified` with person authentication
still false. The composed release check independently enforces the reviewer
identity requirement; adding an event signature cannot clear it. Existing event
bytes and the canonical ledger schema are unchanged.

## What exists today

| Built | Not built |
|---|---|
| `platform/tools/approval_identity.py` — checks assertion-writing commits, signature validity and the local registry name; reports verified signatures separately from still-missing person authentication | independent enrolment, account-to-key mapping, and everything under "The event" below: `approval_event`, `reviewed_sha` ancestry, structural separation of duties, the CI attestation step |
| `governance/allowed_signers.yaml` — a registry recording what each key ATTESTS (`person_review` / `forge_merge` / `automation`), only the first of which may support an approval | branch protection on `main`, which is a repository-admin act and step 1 of the migration below |
| every governed human attribution is now held to `person_rules.not_a_person` — `attested_by`, the QC register's `Waived by`, the decision register's approver, `requested_by` / `analyst`, `registered_by` and every amendment's `by`, and a released refresh's `sign_off.qc_by` / `released_by` | any verification that a named person *exists*, or that the approval is *correct* |

**Read the current identity state from `python platform/tools/approval_identity.py`.** Registered
key counts, authenticated-approval counts and commit-signature states change as people complete
setup and review. They are not fixed facts of this design document. The report names missing
keys, unsigned or unverifiable assertions, mismatched people and evidence that moved after review.

What holds regardless of count: a GitHub merge signature on the forge's key
`B5690EEEBB952194` attests a merge, not a person's review. Adding that signature does not
authenticate the approval merely because a person clicked Merge. The existing verifier requires
an eligible `person_review` key and an assertion-writing signature to establish
key-possession evidence. Independent reviewer identity is a separate unmet requirement.

Two separate conditions need different actions:

- **If no eligible key is registered for the reviewer, identity setup is required.** Nothing
  automated may do it — registering a key on somebody's behalf forges the identity the mechanism
  exists to prove. The person and responsible administrator confirm ownership before the
  registry can carry that public verification key and its canonical identity.
- **If the approval-bearing commit is unsigned, that assertion remains unauthenticated.**
  This cannot be fixed after the fact. No check applied
  later turns an unsigned commit into a signed one; those approvals are re-made under signature or
  they remain what they are.

The obvious wrong fix is recorded in the registry as `known_ineligible`: registering the GitHub
web-flow key would make forge signatures appear eligible without proving any person's review. A forge
signature attests that the platform performed a merge, on a key available to anyone with write
access, applied by the same operation whether or not a human read the diff.

**A `person_review` signature is not an approval or independent identity proof.**
It proves that the registered key signed the bytes. It does not prove who controls
that key or whether the scientific interpretation is correct.

---

This document exists because the external review of
`main@a5bafe4` is right about the current approval model: the YAML forms bind an approval to
**bytes** (hashes of the extraction, the contract, the manifest) and to **typed names** — and a
typed name authenticates nobody. Any writer can enter a plausible name and satisfy the machine
gate. That was a known trade-off, designed around a control that did not exist; this is the design
for the control.

## The principle

**The YAML stops being the authority and becomes the record of an authority.** Authority moves to
an event a platform authenticates — something the approver does while logged in as themselves,
that the repository can later verify happened and cannot itself forge.

## The event

A GitHub **pull-request review** is the chosen event, because it is the one authenticated act this
project's approvers already perform, it is attributable (login, timestamp, review id, commit sha
reviewed), and branch protection can *require* it — which makes the same event serve merge control
and approval identity.

An approval of X becomes, concretely:

1. A PR whose diff **is** the approval form: the `*_APPROVAL.yaml` file, filled in, hashing the
   exact artifacts approved (unchanged from today — the *subject* binding already works).
2. An **approving PR review** on that PR by the named person's GitHub account — the authenticated
   event. The reviewer states in the review body which role they are exercising
   (clinical approver / technical reviewer / validator).
3. The merge, performed by someone **other than** the form's author, under branch protection that
   requires the review and green CI.

The form then RECORDS the event it rode in on:

```yaml
# added to CONTRACT_APPROVAL.yaml / CONFIGURATION_APPROVAL.yaml / RELEASE_APPROVAL.yaml
approval_event:
  kind: github_pr_review
  pr: 412
  review_id: 987654321
  reviewer_login: dr-example          # must be the account of approved_by's named person
  reviewed_sha: <head sha the review approved>
```

## What the machine gate verifies, then

`product_gates.approval_record_errors` gains, **only once branch protection exists**:

- `approval_event` present and complete for any `approved` claim;
- `reviewed_sha` is an ancestor of the checkout, and the approval file at that sha hashes to what
  the event block says — the review covered *these* bytes;
- **separation of duties, structurally**: the commit author of the form ≠ `reviewer_login`; for
  Gate 6, approver ≠ validator ≠ the build's `git_commit` author. Git author strings are
  self-asserted, so this check is only as strong as the platform behind it — which is exactly why
  the event, not the string, is the authority.

What the repo **cannot** verify offline is that review id 987654321 really exists with that login:
that needs either (a) CI querying the GitHub API at merge time and stamping a signed attestation
artifact, or (b) an auditor resolving the PR URL. Design choice: **(a) in CI, (b) as fallback** —
the CI job runs authenticated, the checkout does not, and the gate consumes CI's stamped artifact
the same way Gate 3 consumes the verdict report.

## Separation of duties — the minimum matrix

| Act | May not be the same account as |
|---|---|
| Author of a governed change (incl. the agent) | its technical reviewer, its clinical approver, its merger |
| Clinical approver (Gate 2/4) | the change author, the agent |
| Release approver (Gate 6) | the validator, the build author, the merger of the approval PR |
| The agent (any session) | ANY approver, reviewer, validator or merger — structurally, by holding a branch-only token |

## Migration

1. **Now (admin, ~15 min):** branch protection on `main` — require green CI + 1 review, dismiss
   stale approvals, no admin bypass. Without this, everything below is decoration.
2. **Then (repo):** add `approval_event` to the three approval schemas as OPTIONAL; tools print a
   warning when absent. Existing forms stay valid.
3. **Then (repo + CI):** the CI attestation step (a); flip `approval_event` to REQUIRED for any
   NEW `approved` claim; `unaccountable_resolutions`-style latency for old ones.
4. **Decision registers:** decision answers keep the hand-typed committed form
   (`decision_record.py`) — but the PR that lands a wave of answers is reviewed by the register's
   owner under the same branch protection, which is what upgrades "a name in a cell" to "a name a
   platform authenticated".

## What this deliberately does not do

- No in-repo cryptography or homegrown signing — a key the deployer holds reproduces the exact
  trust hole `deploy_tree.py` already documents. If signing is wanted, it is Sigstore/GitHub
  artifact attestation in protected CI, not code here. `approval_identity.py` does not breach
  this: it implements no cryptography, generates no key and signs nothing. It shells out to
  `git log --pretty=%G?` and reads git's own verdict, and the key it checks that verdict against
  is one a PERSON registered in `allowed_signers.yaml` — never one this repository holds.
- No biometric/HR identity claims: "the account the org gave Dr. X approved this" is the claim;
  binding accounts to humans is the org's identity provider's job.
- Nothing here weakens the existing byte-binding — hashes stay; identity is ADDED to them.
