# Science → DataExpert → Engineering — the governed workflow

How a scientific requirement becomes a released data product: the roles, the gates, the artifacts, and
the rules about what may process which material. Repo-level and **tumor-agnostic** — it applies to every
product under `products/` and to every refresh of those products.

> **Ownership in one line:** Science owns the scientific *intent*. DataExpert owns the *interpretation, the source
> mapping, and the executable configuration*. Engineering owns the *shared engine and the build*.

---

## 1. Authority

```
approved Science specification + closed decisions
        ↓
   FUNCTIONAL_CONTRACT.md          ← the requirement (what MUST be true)
        ↓
   config/ + variables/ + codelists/   ← the implementation (what RUNS)
        ↓
   platform/engine                 ← shared across oncology products (solid | heme); not condition-agnostic
```

Two rules follow, and neither bends:

- **Where the contract and the configuration disagree, the contract wins.** Correct the configuration.
  Never edit a contract record to match what the code happens to do — that silently rewrites an approved
  requirement.
- **Observed data is evidence, never authority.** A profile or a schema inspection shows what a given
  delivery *contains*. It may let an accountable human clear a check; it never redefines, approves, or
  auto-satisfies a requirement.

---

## 2. Trust tiers

| Tier | Property | Role |
|---|---|---|
| **Validated script** | deterministic and reproducible | generates reproducible **evidence** |
| **AI** | probabilistic | produces **unverified drafts and comparisons** |
| **Human** | accountable | **decides, approves, signs** |

Deterministic is not the same as correct. A script can be reproducibly wrong — through parsing
assumptions, hidden rows, merged cells, type coercion, stale formats, or a bad threshold. Every script
that processes restricted material must therefore be version-controlled, reviewed, tested, emit its own
version in its output, fail closed on unexpected input, and keep logs sanitized. **AI may draft such a
script; a human must review it before it runs against restricted material.**

**All AI output is an unverified draft until approved by the accountable human owner.** Human review is
mandatory because of what the artifact governs, not because of any assumed accuracy rate.

---

## 3. The AI boundary

> **Approved deterministic scripts and authorized humans may process vendor material.
> AI tools must not ingest it.**

**Eligibility follows the classification and provenance of the *content*, not the folder it sits in or
who authored the file.** An internally-authored document that quotes a vendor dictionary, embeds a
screenshot of vendor documentation, or carries source examples is vendor-classified content and is not
AI-eligible.

| Material | Script | AI | Human |
|---|---|---|---|
| Science program specification (sponsor) | ✅ | ✅ | ✅ |
| Science methodology document (sponsor) | ✅ | ✅ | ✅ |
| Functional contract, configuration, codelists | ✅ | ✅ | ✅ |
| Engine and tooling source code | ✅ | ✅ | ✅ |
| Labelled synthetic fixtures | ✅ | ✅ | ✅ |
| **Vendor documentation / data dictionary** | ✅ | ❌ | ✅ |
| **Delivered data, extracts, live cuts** | ✅ | ❌ | ✅ |
| **Vendor-derived output (profiles, schema dumps, logs carrying vendor text)** | ✅ | ❌ | ✅ |

**Current posture: no vendor-derived output is AI-eligible EXCEPT the two sanitized derivatives
defined in this document** — `material_type: ai_extraction` (the next section) and the profiler's
AI-safe projection (`MAPPING_EVIDENCE.json` / `--ai-safe`: fixed allowlisted schema, names and
kinds and suppressed aggregates only, no row-level examples, no free text, no quoted vendor
descriptions, versioned with the producing code). "Never statistics" means never row-level or
identifying statistics; the projection's small-cell-suppressed counts (missing-column counts,
suppressed top-value counts) are the one permitted aggregate and are listed in its schema. Nothing
else derived from vendor material crosses to AI. (This paragraph used to say "no vendor-derived
output" and then define two exceptions — audit 4.)

### The one sanitized derivation that IS defined: `material_type: ai_extraction`

A sponsor specification can be AI-eligible in provenance and still QUOTE vendor documentation, because
Science's own document does. The stand-in reproduces those quotations faithfully — correctly, and
`attested_against_sha256` exists to keep it that way — so the stand-in's content is vendor-derived
however its `ai_classification` reads. Editing it to remove the quotations would destroy the fidelity
Gate 1 attests to.

So the derivation is sanitized instead, and **the sanitized derivation is a governed material in its
own right**. `spec_extract` redacts every cell that reproduces vendor documentation — AFTER taking each
row's `content_hash`, so `spec_digest` still binds contract records to the real specification text —
and records what it removed and under which policy. That artifact,
`spec_pipeline/out/extracted.json`, is registered in `source_refs.yaml` as
`material_type: ai_extraction`, and it is **one of exactly two pack artifacts AI may read**.

### The second sanitized derivation: `material_type: ai_mapping_evidence`

The mapping copilot's evidence file (`MAPPING_EVIDENCE.json` — delivered table and column NAMES
and KINDS only, profiler-derived, no values) is the second. It crosses the boundary only when
BOTH halves of its approval exist: the in-file `ai_eligibility: reviewed` block a person signs
after confirming the file carries names and kinds only, AND a registration in
`source_refs.yaml` as `material_type: ai_mapping_evidence` carrying the exact `sha256` of the
approved bytes, the `parent_profile_sha256` it derives from, and the approver's name and date.
The registration exists because an in-file state is MUTABLE — the table list could change after
the review while the state text stands; `propose_source_mapping` refuses a file that is not
registered, whose bytes have drifted from the registered digest, or whose parent profile does
not match. An AI session performs neither half of the approval.

It carries its own classification and its own approver, because the class recorded on the input says
nothing about the file AI opens. `spec_slice` gates on THAT approval and on nothing else. The approval
is bound to what it was given over, and every binding fails closed:

| Binding | What it prevents |
|---|---|
| `status: reviewed` | a signature sitting beside a `why_provisional` saying the review has not happened — one artifact, two statements, and the pack keeps whichever a reader reaches first |
| `path_or_link` = the artifact AI opens | an approval that names a different file than the one read |
| `sha256` of those bytes | the artifact hand-edited afterwards. `extraction_fingerprint` is a value INSIDE the file, so rewriting a `required_rule` and leaving it alone passed every other check |
| `extraction_fingerprint` | re-running the pipeline and inheriting an approval nobody re-gave |
| `redaction_policy_sha256` | weakening `governance/ai_boundary.yaml` so less is removed, under an approval given when more was |
| `redacted_cells` / `redacted_rows` | a record understating what was taken out — the summary is the part a reviewer actually reads |
| no `vendor_restricted` ANCESTOR | sanitizing a wholly vendor-authored document into eligibility — redaction removes CITATIONS, and a delivered data dictionary contains none because it IS the documentation. The whole `derived_from` chain, not the immediate parent: one extra registered link moved a restricted document out of view while every link looked legal |
| a fresh marker scan of the artifact | vendor prose reintroduced after approval |

**Registering it is a human act and no tool performs it.** `ai_classification`, `classified_by`,
`classified_date`, `approved_by` and `approval_date` are the decision itself.
`source_manifest.py --register-ai-extraction <pack> --write` inserts the block with every derived
field computed and those five left `TODO`, then re-reads the file to prove the material landed
inside `source_materials` — a hand-paste after the last top-level key registers nothing while every
check stays green. Either way the pack is RED until a person answers. Flip
`status: pending` to `reviewed` when signing; Gate 1 then verifies the recorded `sha256` on every
run. Until a person signs, the pack is not AI-readable, and `spec_slice` says so and says how to
fix it.

**Only verdicts and derived facts cross the boundary** — `schema check passed`, `3 columns missing` —
never contents, never statistics, never quoted passages.

**Human-approved source identifiers are AI-eligible; vendor prose is not.** Once a human has confirmed a
mapping (Gate 3), the *identifiers themselves* — physical table and column names — and the pass/fail
verification verdicts live in the sponsor-controlled contract and configuration, and AI may read them
(it must, to author the YAML). What never crosses is the vendor **prose** those identifiers came from:
dictionary descriptions, value statistics, coding narratives, or copied passages. The identifier is a
fact the human vouched for; the dictionary text behind it stays out.

### Enforcement

Repository instruction files (`docs/ENGINEERING.md`, tool ignore-files) **document** this rule. They do not
enforce it: they do not prevent repository indexing, an unscoped search returning restricted snippets,
a tool that ignores them, an accidental attachment, or a human pasting restricted output into an AI
session.

Enforcement is **access control and workspace separation**:

1. Do not expose restricted vendor material to the AI-accessible workspace.
2. Mount or retrieve it only when an approved script runs.
3. Keep only references, checksums, versions, and verdicts in the shared repository.
4. Prefer an **AI path allowlist** over a vendor-folder denylist.
5. Use tool-specific deny rules as defence in depth, not as the boundary.

---

## 4. The pipeline

```mermaid
flowchart TD
  classDef rwb  fill:#e8f0ff,stroke:#3b6,color:#111
  classDef rwp  fill:#fff4e6,stroke:#e8a,color:#111
  classDef dec  fill:#fde8e8,stroke:#d66,color:#111
  classDef rwde fill:#eafaf0,stroke:#4a4,color:#111
  classDef gate fill:#f6e6ff,stroke:#96c,color:#111

  A["Science approved, QC-complete specification (Excel)<br/>+ methodology document (Word)"]:::rwb
  G1["GATE 1 · approved inputs + classification"]:::gate
  E["Qualified extraction → traceable spec items"]:::rwp
  D["Draft contract records (AI drafts)<br/>+ DataExpert spec-QC (independent review)"]:::rwp
  G2["GATE 2 · requirements + decisions"]:::gate
  DEC["Science / BIO answer open decisions"]:::dec
  S["Semantic source mapping (human, vendor docs)<br/>+ script checks + profiling"]:::rwp
  G3["GATE 3 · source + delivery readiness"]:::gate
  Y["Author configuration: config / variables / codelists"]:::rwp
  G4["GATE 4 · configuration approval (DataExpert-owned)"]:::gate
  I["Implement in the shared engine (only approved records)"]:::rwde
  G5["GATE 5 · implementation + validation"]:::gate
  G6["GATE 6 · governed release"]:::gate

  A --> G1 --> E --> D --> G2
  G2 -.->|unresolved| DEC
  DEC -.->|answers| G2
  G2 --> S --> G3 --> Y --> G4 --> I --> G5 --> G6
  G6 -.->|change request / next refresh| G1
```

---

## 5. The six governance gates

Each gate names its actors, its machine checks, what a human must decide, and what must exist to exit.

> **Six gates are not six meetings.** They exist so that traceability is unambiguous about *what was
> approved, by whom, on what evidence*. Operationally they collapse into three checkpoints:
> **Requirements ready** (Gates 1–2) · **Build ready** (Gates 3–4) · **Release ready** (Gates 5–6).
> Most transitions happen through PR approval, CI evidence and status updates — not additional ceremony.

### Which gates apply — gate weight follows the authority created

All six gates below describe a **data product**: a governed table other people will trust. That is
the right weight for a thing that creates new authority, and the wrong weight for everything else
the group does. A one-off analysis over an *already released* product creates no new authority — it
reads a table someone has already signed for — so requiring it to register a source at Gate 1 asks
it to re-register a source that is already registered. The predictable result of getting this wrong
is not that such work is over-governed; it is that it happens entirely outside governance.

So the obligation follows what the object creates. `platform/tools/product_gates.py` holds the one
table (`KIND_GATES`); nothing else may restate it.

| kind | creates | owes |
|---|---|---|
| `product` | a governed table others trust | Gates 1–6 below |
| `request` | nothing new — it reads a release | **provenance**: which release, and that release must be citable |
| `protocol` | scientific authority *above* products | its own requirements + decisions, plus provenance |

**Provenance is an obligation, not an exemption.** A request is light because it *inherits* an
approval, so `source_manifest.citation_errors` refuses a citation of any pack that
`releasable()` does not clear — the same derived answer that decides whether a pack may publish at
all, never a flag anyone can set. Naming a `build_id` raises the question from "may this pack
publish" (Gates 1–4) to "may this build" (…and Gate 6). A kind that owes provenance and cites
nothing is refused outright: work that inherits an approval it never named is the state this path
exists to prevent.

Products are registered under `tumors:` in `products/registry.yaml` and are always `kind: product`.
Other kinds live under `work:` in the same file, where `kind:` is required — so no object's kind
depends on a default, and an unrecognised kind owes *everything*.

**What a request leaves behind.** A product's output is a governed table, and its receipt binds the
build to the config, source and approval it ran under. A request's output is a number, a table or a
slide, and it is asked the same question just as often and usually later: *which release did this
come from, and was it approved then?* `work/<id>/REQUEST.yaml` carries what the number cannot — the
question in the requester's words, a re-runnable derivation, the quotable summary, and who asked
and answered. `platform/tools/request_record.py --new <id>` scaffolds it; every field a person owns
is a marker the tool will not fill.

**What a protocol freezes.** A protocol's `contract` is not a thinner `FUNCTIONAL_CONTRACT.md`. A
product's contract is an ongoing reconciliation between a workbook and a configuration; a protocol's
record answers a different question, once — *was this specified before the results were seen?* An
objective added afterwards, an endpoint swapped for the one that reached significance, a subgroup
that appears in the write-up and not the plan: each is invisible in the finished document, and
pre-specification exists to make each visible.

So `work/<id>/PROTOCOL.yaml` records a **freeze**. Everything under `prespecified:` — objectives,
design, population, endpoints, analyses — is covered by `prespecification_sha256`, recorded by a
person at registration and recomputed by `protocol_record.py --check`. The digest is over the
canonical form of that subtree, so reflowing a paragraph is not an amendment and changing one
endpoint is. A registered protocol may be **amended, never edited**: an amendment states the date,
the person, what changed, why, and the digest it covers.

**A request may not read outside the protocol it runs under.** A request declaring `under_protocol:`
may only cite releases the protocol itself cites, and may not run under a protocol still in `draft`.
A study that acquires a new data source one analysis at a time has changed its own scope without
anyone deciding to, and each individual step looks reasonable.

**A study pins what it reads, and records what it reconsiders.** One product serves several
studies, and each decides for itself which of the product's definitions it takes unchanged and which
it reconsiders — an exclusion window, a censoring rule, an index event. Without a record that
decision lives in an analyst's head, and the product's own contract is edited to suit whichever
study asked last. `work/<id>/PINS.yaml`, written by `platform/tools/study_pin.py`, is the study's
record: the product and cut it reads (a registered product at a released cut — never a reference
fixture, a superseded or a draft cut), the digest of the contract it read, and one decision per
contract variable — `reuse` (unchanged), `reconsider` (the study's own definition, stated in words)
or `exclude` — each with a reason, a person and a date. The product is never edited by a study; a
decision is revised (`--revise`, keeping the earlier one), never doubled. A registered protocol may
pin only a release its registry entry cites, and a closed protocol pins nothing. When the product's
contract moves, `study_pin.py --check` reports every study that read it STALE, by name, until a
person re-reads it and records that with `--refresh`; a cut the lineage later supersedes is reported
the same way. Nothing here approves the product or asserts it releasable: that remains the gates'
question, asked of the pack.

**A study that reports numbers pins the exact published build.** `study_pin.py --pin <pack> --build
<build_id>` records, beside the contract and configuration digests, the build a committed refresh
receipt names as published, the digest of that receipt as committed, and the configuration the build
EXECUTED (`config_identity` in the receipt — what a reader reproduces from after the pack moves on).
A build no receipt records, a candidate whose composed verdict failed, and a superseded build are
each refused by name; `--check` holds the pin to the receipt afterwards — a receipt that moved (a
committed receipt is immutable) or a build the next refresh superseded is STALE by name, and a
person moves the study with `--refresh --build <build_id>`, the previous build kept in the history.
Where a registered protocol's own citation pins a build, its studies pin that build or amend the
plan — scope is the build where the plan named one, the same rule requests are held to. The
product page shows each study's build and whether it, or the configuration, has moved.

**Staleness is the receipt's analogue**, and it is why this is a record rather than a note. A cited
release does not stand still: when the product's `lineage:` marks that `spec_version` superseded, a
record still claiming `status: answered` is asserting the answer is current, and `--check` refuses
it. The old answer is not wrong — it was computed correctly against the cut it cited — so the two
ways out are to set `status: superseded` (recording that a person knows) or to re-answer against the
current cut. The other half, an approval regressing underneath the citation, is
`source_manifest.citation_errors` and is not restated here.

### Gate 1 — Approved inputs and classification

| | |
|---|---|
| **Actors** | Science delivers · DataExpert records |
| **Machine** | checksum each input; validate the source index against its schema |
| **Human decides** | which document revision is authoritative; the AI-eligibility classification of every input |
| **Exit** | the pack's `source_refs.yaml` carries an approved material: filename, version/revision, checksum, approval date, approver, stable link, data-refresh identifier, per-input AI classification, and the **Science specification-QC reference** (Science's own QC pass must be complete before handover). `platform/tools/source_manifest.py --all --check` enforces the machine-checkable part in CI: a `reviewed` material must carry its approval fields and still hash to the recorded `sha256`, and no pack may claim `contract: approved` without one. |

*Why human:* declaring a document authoritative, and classifying its content, are acts of authority.

**Do not type the checksum.** A 64-character hex string read off one window and typed into another is
where two of this repo's recorded digests went wrong. `source_manifest.py <pack> --record-digest
<material_id>` computes it and writes it into that material's record. It fills only an UNSTATED field:
a digest already recorded that no longer matches means the file changed under an approval, and it
refuses rather than re-pointing that approval at bytes nobody has looked at. Which document is
authoritative stays the human act; the hash of it never was one.

**Two QC passes, not one.** Science performs its own specification QC before handover — that pass is recorded
here as evidence, not repeated. DataExpert performs a *second, independent* QC while drafting the contract
(Gate 2), reading the specification as the implementer who must execute it. The two catch different
things: Science's finds errors in their document; DataExpert's finds ambiguity, contradiction, and silence that only
surface when you try to write a precise rule.

### Gate 2 — Requirements and decisions

| | |
|---|---|
| **Actors** | script extracts · AI drafts · DataExpert reviews · **independent DataExpert/QC reviewer** · Science/BIO answer decisions |
| **Machine** | contract schema and controlled vocabularies; every reference resolves; **traceability coverage** (below); potential-duplicate detection (a human confirms semantic duplicates) |
| **Human decides** | clinical meaning, derivation intent, missing-data semantics, dependencies, acceptance criteria, and ownership of every open decision |
| **Exit** | every requirement is approved or explicitly blocked by a named decision; **specification-QC findings returned to Science**; coverage report complete |

**DataExpert specification QC happens here.** Drafting the contract *is* the QC: you cannot write a precise
`required_rule`, `window`, `tie_break` and `missing` without discovering where the specification is
ambiguous, self-contradictory, or silent. What makes it a QC step rather than a side effect is that it has
named deliverables:

1. **Specification-QC findings returned to Science** — defects in *their* document (contradictions, truncated
   value lists, a value stated in one tab and contradicted in another).
2. **The decisions register** — questions the specification does not answer.
3. **The coverage report** — every specification item and its disposition (§8), which doubles as Science's
   row-by-row validation artifact and as the completeness evidence for this QC pass.

**The instruments of the decision loop.** `decision_report.py` ranks the open questions by how many
records each answer unblocks; `decision_packet.py` renders one page per question for the person who
must answer it — question, evidence, blast radius, what other products decided; `decision_record.py`
records the answer, from a hand-typed committed form (`--forms` emits one per OPEN decision, `--apply`
transcribes the wave fail-closed and prints the worklist of records each answer unblocks). No tool may
invent `Approved by` / `Approval date` — they arrive only inside the committed form.

**The specification-QC findings ride the same page.** `decision_packet` renders the pack's open
findings — the defects in Science's own document — beside the questions, split so capture defects (ours,
resolved by re-extracting) never land on Science's list. The loop is convergent by construction: each
finding needs exactly one act, once — correct the cited cell in the next revision, or waive it — and
when a revised workbook arrives, `spec_diff.py` reports per finding whether the cited text actually
changed, so a revision that fixes nothing is named before anyone re-drafts against it.

**Independence:** the QC reviewer should not be the person who accepted the AI draft — a fluent
draft hides the same error from the same reader twice. Where a second person is impractical, QC is
a separate pass against a checklist, not a re-read.

**Extraction is qualified automation.** The extractor reads the approved workbook and emits traceable
spec items verbatim, with their original coordinates. It must be *dumb*: no renaming, normalization, or
cleanup — every transformation is an opportunity to silently corrupt a requirement. Re-running proves
**reproducibility**, not fidelity, so human review is required when: the extractor is first introduced,
its code changes, the workbook template or sheet structure changes, item counts change unexpectedly, or
the extractor emits warnings. Routine refreshes on an unchanged, qualified template pass automatically.

The extraction manifest carries: source checksum, document version, sheet name, original row/column
coordinates, extraction timestamp, extractor version, warnings, a **stable item ID**, and a content hash
per item. Row numbers move between revisions, and identical text can legitimately appear more than once,
so identity needs the item ID plus its section/context key — the hash alone cannot distinguish two
identical cells.

**AI may identify ambiguity and draft the question. It must never decide** study windows, index-date
rules, prioritisation, tie-breaks, missing-data meaning, outcome definitions, clinical grouping, or any
methodology-sensitive assumption. Unresolved items become a decision record, are referenced from the
affected requirement, and block implementation.

**What the two approvals and the verdict report pin.** The Gate 2 approval's
`approved_contract_sha256` and the Gate 4 approval's `approved_against_contract_sha256` are digests
over the contract's REQUIREMENT CONTENT — each record's requirement fields, in contract_lint's own
partition (`product_gates.requirements_sha256`) — never over the file's bytes: the evidence tools
write the status axes after the requirements are settled (Gate 3's verdicts, Gate 5's validation),
and moving them is not a change to what was approved. A derivation, window, tie-break or missing
rule edited after the approval still voids it. Likewise the Gate 3 verdict report's
`contract_sha256` is the MAPPING content (`product_gates.mapping_sha256`: each record's source cell
and dependencies) — a source cell edited after the check stales the report by name, a status axis
does not. The acceptance case (platform/tests/test_lifecycle.py) found both pins voiding approvals
on writes that changed nothing approved and sending the person back a gate.

### Gate 3 — Source and delivery readiness

| | |
|---|---|
| **Actors** | authorized human maps · validated scripts check · DataExpert reviews |
| **Machine** | dictionary presence; live schema presence; type compatibility; delivery structure; data profile |
| **Human decides** | the semantic mapping (is this the *right* column for the concept?); whether profile findings are acceptable |
| **Exit** | source mapping confirmed; delivery findings reviewed; unresolved source or data issues named |

**Which schema evidence a product owes is a VENDOR question, and it is declared.** Some vendors let
the sponsor keep the data dictionary; there, reading it answers what a profile would, without
touching patient-level data. `governance/vendor_policy.yaml` declares the route per vendor, with a
reason. `product_gates.evidence_route` is the one answer and it fails closed: an unknown vendor
refuses rather than defaulting to "profile", because a tool must not read delivered data on the
grounds that nobody said not to. A missing profile then stops meaning two things at once —
"evidenced another way" and "nobody has looked yet".

This declares a ROUTE, not a permission. `vendor_documentation: available` says the sponsor may hold
the document under the delivery terms; it says nothing about whether AI may read it, which follows the
material's own recorded `ai_classification` as everything else here does. A vendor-authored document
is `vendor_restricted` whatever a licence permits a person to do with it.

**Semantic source mapping is an explicit human step**, because a parser can prove a column exists but
cannot judge that it represents the intended clinical concept:

1. DataExpert states the required concept from the approved specification.
2. An **authorized human** consults the vendor documentation.
3. That human proposes the physical table and column mapping.
4. A validated script confirms dictionary presence, live presence, and type compatibility.
5. A second review (or PR approval) confirms the mapping where the variable is material or ambiguous.

AI may pre-fill a **proposed** mapping at Gate 2, but **only from identifiers the specification explicitly
names**. Where the specification does not name a table or column, AI must leave it unknown and flag it —
never infer an identifier from a naming convention, a sibling variable, or a plausible pattern. A guessed
identifier that happens to look right is the hardest error for a reviewer to catch.

AI may see the **approved mapping record**. AI must never see the underlying vendor text.

### Gate 4 — Configuration approval (formal, DataExpert-owned)

| | |
|---|---|
| **Actors** | DataExpert authors and approves · Engineering technically reviews · scientific owner approves methodology-sensitive rules |
| **Machine** | configuration schema; reference integrity; enumeration/mapping completeness; codelist linkage; dependency resolution; regression |
| **Human decides** | that the configuration correctly expresses the approved requirement |
| **Exit** | configuration formally approved and version-recorded |

This is a **formal approval gate, not a formality.** The configuration governs filters, windows,
anchors, populations, codelists, category mappings, tie-breaks, missing-value handling and source
selection. Automated checks cannot verify all of that.

**The reviewer's instrument is `rule_review.py`**, which puts each rule's three sides next to each
other — the specification's verbatim words, the contract's interpretation, and the YAML that runs —
so the person who owns the clinical question can check what they are signing without reading
configuration notation. Without it the approval becomes a formality: the reviewer signs that
somebody else checked.

**Enumeration checks verify the approved relationship, not literal string equality.** Configuration
legitimately contains normalized spellings, aliases, canonical labels, groupings, exclusions and
vendor→output mappings. The check asserts *either* exact set equality where that is the approved
relationship, *or* a complete explicit mapping where normalization is intended — and reports any
unmatched specification value, source value, or configuration value.

**The approval names the analytical definitions it releases.** Every family the configuration
computes carries a signature (`definition_signature.py`) over the approved rules, and
`governance/DEFINITIONS.yaml` is where a person mints that signature an id — `RWDP:ECOG_PS:v1` —
once, with its UMLS concept. Below `configuration: approved` an unregistered definition is advisory
(`definition_registry.py --propose <pack>` writes the entry to complete); at it, the approval is
refused until every signed definition is registered and current. The id is what a semantic binding,
an equivalence ruling and a second dataset's implementation then cite, so "the same variable" across
two sources is a claim about two named definitions, never a spelling.

**A dataset says which definition it implements.** `config/implementations.yaml` claims, per contract
variable, the registered definition this dataset realises and the source roles it reads, reviewed by
a person (`definition_registry.py --propose-implementations <pack>` prints the draft). The claim is
held to the register, the contract and the configuration being approved, and a claim that does not
resolve is refused at `configuration: approved`. The semantic view carries each claim on the
implementation that made it; an equivalence ruling that names the two definitions it compared applies
only where both implementations claim exactly those — a dataset that moved to another definition, or
never said what it implements, is back to NOT ESTABLISHED with the ruling on record named.

### Gate 5 — Implementation and validation

| | |
|---|---|
| **Actors** | Engineering implements · reviewer reviews · DataExpert validates · QC · scientific owner signs methodology-sensitive output |
| **Machine** | unit, edge-case, integration, acceptance, and regression tests; cross-language parity **only where more than one production engine is supported for that rule**; contract↔engine traceability |
| **Human decides** | code correctness (review); whether output satisfies the contract; methodology sign-off |
| **Exit** | validation evidence complete; release blockers closed or formally waived (see *Waivers* below) |

Engineering implements **only approved requirements**. Blocked or decision-gated records are not implemented.

**"Implements" means two different things here, and the split decides the actor.** A product's
rules live in declarative configuration (`config/data_product.yaml`, `variables/*.yaml`) read by
the shared engine (`platform/engine/`, with its R counterpart). Authoring that configuration is
**Gate 4 material: DataExpert writes and owns it end-to-end, Engineering reviews it technically** — filling in
windows, tie-breaks and codelists against capabilities the engine already has. Gate 5's
engineering is the **shared engine itself**: when an approved rule needs a capability no
configuration can express, the gap is recorded in `handoff/ENGINE_GAPS.md`, the affected record
cites its gap id in `gap_ids:` (contract lint pairs the two), and **Engineering implements the
capability** — real code, tests, mandatory human code review — because it is infrastructure every
product's build runs through; DataExpert then validates the output against the contract. In one line:
DataExpert owns what the product *says*; Engineering owns making the shared machinery *able to say it*, and
reviews technically. Either way the gap is scoped before any engine change.

**Human code review is mandatory.** Tests can pass while an implementation is clinically or logically
wrong; a compile check proves only that the source parses. A contract↔engine check establishes
*traceability* — unless the contract is directly executable, it cannot prove that prose and code are
semantically identical.

**The build's own evidence is ONE composed verdict.** Every stage a candidate passes through — source
QC, source linkage, ADS QC, the output contract, the golden and patient differentials, EDA acceptance,
source grain, stage retention, and last the publication surface (the columns as they stand against
the approved whitelist) — composes into `engine.refresh.candidate_verdict`, from one list. A stage
the pack never declared reads NOT EVALUATED, never as a pass; a required stage with no verdict fails.
The job stops on that verdict, the manifest stores it beside its stage blocks (and refuses a copy that
disagrees with them), the evidence bundle writes one file per stage, and the committed refresh
receipt is read back here: Gate 5 is done only when the per-record validation axis is complete AND
the receipt's composed verdict passed. Gate 6 reads the same verdict at promotion — an approval binds
a build, it does not make a failed candidate releasable.

### Gate 6 — Governed release

| | |
|---|---|
| **Actors** | per the product's approved RACI — typically DataExpert and the scientific owner approve; Engineering signs as technical reviewer rather than as a mandatory business approver |
| **Machine** | release-record schema; all gate exits present; no unresolved blockers |
| **Human decides** | final approval, named |
| **Exit** | a controlled, versioned, audit-trailed release record |

A correction creates a **new version** of the release record; history is never silently altered.

**The approval is a recorded act, and its authentication is earned.** A signed
`handoff/RELEASE_APPROVAL.yaml` that stands under this gate is still only a form until
`approval_record.py --record-event <pack> --form release` seals it as a `release_approval` event
in the ledger (the form gains its `object_uuid`); promotion, the status page and the flow refuse a
form that is not an act, and a form edited after sealing is named as having shed its act. The
approver may then countersign the sealed event with the ed25519 key registered for them in
`governance/SIGNING_KEYS.yaml` — `authenticated` is what `event_ledger.verify_attestation` derives
from that signature, never a word typed on a form. The same recorder seals the contract,
configuration and semantic approvals; wiring their gates to require the seal is the next tranche.

The release record identifies: product and tumor · specification version · methodology-document version
· configuration version · codelist version · data delivery/refresh identifier · engine commit ·
validation evidence · profiler and tooling versions · **expected-change record** · QC evidence (as
applicable to the product's outputs) · known limitations · approved waivers · build/run ID · named
approvers · approval date.

**Waivers.** A waiver names who approved it, the rationale, its scope, its expiry, and the evidence it
rests on. A waiver without an expiry is a silent permanent exception and is not a waiver.

---

## 6. Lifecycle branches

Not every change runs the full path. Route the change, then run only the gates it touches.

### A. New product or new specification version — all six gates

`inputs → extraction + traceability → requirements + decisions → source/delivery → configuration →
implementation + validation → release`

A refresh is **not** one branch. The scientific requirement and the physical delivery change
independently, so route on both questions:

> **Q1: did the requirement or methodology change?**
> **Q2: did the delivery change in a way that forces a source-mapping or configuration change?**

### B1. Refresh — no requirement change, no source/configuration change

`confirm approved prior versions → compare document and configuration checksums → validate new delivery
schema → profile the delivery → rebuild → regression + QC → classify and approve expected changes →
release`

Gates 1, 3, 5 and 6. **The contract and configuration are not redrafted because data changed.**

### B2. Refresh — no requirement change, but the delivery forces a configuration change

`confirm the scientific requirement is unchanged → document the delivery-driven delta → update the
affected source mappings / configuration / codelists → **run Gate 4 for the affected configuration** →
implementation review only if engine code changes → rebuild → regression + QC → classify changes →
validate → release`

Gates 1, 3, **4**, 5 and 6.

A requirement can stay identical while the delivery renames a table, a column, a type, or a coding
convention. **This is the common case, not an edge case** — one cut in this repo renamed four source
tables with no change to what the variables mean. Routing that through B1 would let a configuration
change reach production without configuration approval. B2 exists to close that.

### C. Refresh with requirement or methodology change

`re-run extraction against the COMPLETE revised workbook → compare manifests and item hashes → scope
review and downstream changes to the detected delta → update affected requirements and decisions →
update affected configuration and codelists → assess whether an engine change is required → test
impacted areas plus full regression → validate → release`

All gates apply, scoped to the delta.

**Extract the whole workbook, then scope the review.** Extraction is cheap and deterministic; partial
re-extraction misses deleted rows, moved requirements, reordered sections, changed headings that alter
interpretation, and changes outside the area anyone believed was affected. Compare manifests to find the
delta, then review only what actually moved.

**The comparison has an owner: `spec_diff.py <old> <new>`.** It reads both extractions and partitions
the old pack's contract records on digest evidence — CARRIES AS-IS (cited text provably unchanged),
CARRIES WITH A NEW REF (row moved, text identical), RE-DRAFT (text changed or row gone) — so "scope
the review to the delta" is a computed list, not a judgment call. `precedents.py --for <pack>` says
which of the new cut's questions other products have already hit.

### Expected-change classification

A golden/reference comparison must not treat every difference as a failure. Legitimate differences arise
from larger cohorts, new categories, vendor corrections, renamed tables, re-cased values, changed
follow-up, or an approved methodology change. Every difference is classified as:

- **expected and approved** — with the reason recorded
- **unexpected but accepted** — with an explanation
- **defect** — requires correction
- **unresolved** — blocks release

---

## 7. Status model

A single "verified" flag conflates independent questions. The axes are **one `status` block per record**,
with these canonical key names — products must use these names, not synonyms:

```yaml
status:
  requirement:        draft | decision_required | approved
  source_mapping:     proposed | human_confirmed          # who says this is the right column
  dictionary_check:   not_run | passed | failed | not_available   # exists in vendor documentation
  live_schema_check:  not_run | passed | failed           # exists in THIS delivery
  data_profile_check: not_run | reviewed | issue_open | accepted    # reviewed = read; accepted = judged sufficient
  implementation:     implemented | partial | config_gap | engine_gap | not_implemented | not_derivable
  validation:         not_run | passed_test | passed_live | failed
```

`requirement`, `implementation` and `validation` are the axes products already carry. `source_mapping`,
`dictionary_check`, `live_schema_check` and `data_profile_check` **replace a single `source` axis**,
which conflated four different questions — a column can exist in the dictionary, be absent from this
delivery, and still be the wrong column for the concept. Adopt the finer axes when a product reaches
Gate 3; until then a product may carry the coarse `source` axis and record the reason in its `handoff/`.

**At Gate 4 the coarse axis is no longer enough.** `configuration: approved` comes after Gate 3, so by
then the finer axes must be in place: a single `source: verified` at the point of configuration
approval lets one word stand for all four questions, which is the conflation these axes undo. The one
exception is `source: unavailable` — a declared gap has no mapping to have verified. Gate 4 requires
`data_profile_check: accepted`, not merely `reviewed`: reviewed means a person read the report,
accepted means they judged the evidence sufficient for this mapping, and approving an implementation
needs the judgment.

**`dictionary_check: not_available`.** Not every feed comes with a data dictionary, and requiring
`passed` from a document that does not exist made the finer axes unadoptable — a product would have to
fall back to the coarse axis, which is the conflation these axes exist to undo. `not_available` states
the fact: no dictionary was supplied for this feed. It is accepted at Gate 4 **only** when the checks
that read the actual data did run — `live_schema_check: passed` and `data_profile_check` reviewed or
accepted. It cannot stand in for a check that was skipped, and `failed` still blocks regardless. Note
what is and is not lost: the profiler and the schema validator are STRONGER evidence than a dictionary
that the column exists and what it contains, because they read this delivery rather than describe an
intended one. What the dictionary alone carries is the vendor's stated MEANING, and without it that
judgment rests on the Science specification plus `source_mapping: human_confirmed`.

**Who may set what.** AI initializes a new record at `requirement: draft`, `source_mapping: proposed`,
and every check at `not_run`. AI must never write `requirement: approved`, `source_mapping:
human_confirmed`, or any `passed`/`accepted` value. Scripts set `live_schema_check` from their own
evidence — the performing tool is `contract_record.py <pack> --apply-verdicts`, which consumes the
generated `live_schema_verdicts:` block of the pack's committed verdict report (source_check owns the
derivation), migrates a coarse `source: unverified` to the finer axes, and transcribes hand-typed
`confirmed_mappings:` rows (record + rationale, in the verdict report) into `source_mapping:
human_confirmed`. `dictionary_check` stays hand-set until a committed dictionary-evidence producer
exists — a script setting it today would assert evidence with nothing behind it. Humans set everything
else. This is what reconciles "the AI drafts the status field" with "the skill never flips a status":
**the template is initialized; the transitions are governed.**

No variable is "verified" merely because a matching name and type were found.

---

## 8. Traceability model

Specification items do not map one-to-one to output variables. An item may be a heading, a shared
definition, one variable with several outputs, a codelist requirement, a population rule, a note, a
dependency, a duplicate, or a methodology decision.

**Traceability first, and — at approval — one record per row.** For each *implementable requirement* the
AI drafts one or more contract records. Every extracted specification item must then receive exactly one
disposition:

| Disposition | Meaning |
|---|---|
| `mapped` | represented by one or more contract records. One row may produce several records; at `contract: approved` no record may span several rows (lint I16) |
| `codelist` | realized as a codelist requirement |
| `population` | realized as a population/cohort rule |
| `context` | heading, instruction, or note — not an output |
| `duplicate` | the same requirement stated elsewhere; names the item it duplicates |
| `decision_required` | blocked by a named decision |
| `excluded` | out of scope, with a recorded reason |

**Every specification item is accounted for; no item is silently omitted.** Unresolved items are not a
failure — `decision_required` is *intentionally* unresolved — but they must be linked to a named decision
or gap and remain blocked. What fails the gate is an item with **no disposition at all**.

### One record per specification row

A record may be drafted over several rows — that is how `LAB` came to cite `clinical:17-46` — but a
contract cannot be **approved** that way. Lint I16 refuses it at `contract: approved`.

Why: a family record is a list, and a new member added to a list inside prose turns nothing red —
`contract_binding` sees top-level blocks, and the lint cannot tell an updated citation range from
the old one. The addition gets caught by a person noticing, which is the one control this framework
exists to stop relying on. One record per row makes the same addition arrive as a new row, a new
record, and a new block the binder demands a record for. The cost — more records — is accepted.
The record names the rule; the YAML carries the values.

**One record per specification row; one report line per specification item.** The coverage report still
carries the row-by-row walk, and I16 makes the contract agree with it instead of standing beside it.

---

## 9. Approval records

Status transitions are governed events, not field edits. Each records: the status, the approver, their
role, the date, a reference to the supporting evidence, the related PR or issue, the applicable product
and refresh, and a rationale where an exception or waiver applies.

**Evidence unlocks a transition; it never performs one.** For material transitions, approval is given
through PR review or an equivalent controlled mechanism — not by the same person who generated the
evidence silently editing the field.

---

## 10. Artifact types

| Type | Role |
|---|---|
| Approved specification (Excel) · methodology document (Word) | the scientific requirement — **evidence, never a build input** |
| Extracted specification items + manifest | traceable, verbatim, coordinate-anchored rendering of the approved document |
| Functional contract (Markdown) | one canonical record per specification row (lint I16, at `contract: approved`) — the governed requirement |
| Decision and gap registers | open questions and known limitations, referenced by ID |
| Configuration · variable parameters · codelists (YAML) | the **executable** product, DataExpert-owned |
| Source manifest | which approved materials this product was built from |
| Profiling and schema evidence | what a specific delivery contains — **vendor-derived, not AI-eligible** |
| Engine (shared code) | the locked build shared by every oncology product (a non-oncology condition needs engine work — `condition_class`, platform/README.md) |
| QC, validation, expected-change and release records | the audit ledger |

---

## 11. The rules that do not bend

1. The approved specification is evidence; the contract is the requirement; the configuration is the
   implementation. Contract beats configuration.
2. Observed data never redefines, approves, or auto-satisfies a requirement.
3. Never invent a value the specification does not state — raise a decision.
4. AI drafts; humans approve. All AI output is unverified until an accountable human accepts it.
5. AI must not ingest vendor-originated or vendor-derived content, with exactly the two sanitized
   derivations this document defines as the exceptions: `material_type: ai_extraction` and
   `material_type: ai_mapping_evidence` (the profiler's `--ai-safe` projection). Verdicts cross the
   boundary; contents do not. This is not a house preference: GSK R&D policy §9 classifies Individual Human
   Data as Sensitive Personal Information — "any data at the individual level ... includes
   pseudonymised data (or key coded patient data). Even data that appears anonymised may still be
   classified as IHD if it originates from identifiable individuals. When in doubt, treat it as
   IHD" — and states that Claude alone is not an approved platform for it: "**No IHD should be
   processed or analysed by any other LLM or AI tool outside of Cogito.**" Vendor patient-level data
   is IHD. The approved path is Claude → Cogito, where Claude "surfaces and synthesises the results
   without ever holding the raw IHD itself" — which is what rule 5 already describes. Note the
   profile report is individual-level, not aggregate: `top_values` is emitted as `count:value` with
   no minimum cell size, so a `count:1` entry is one patient. It is written for a human on a
   governed platform and is never committed; it must not be pasted into an AI interface.
   *(R&D internal use only; last updated 07 July 2026; ratification at IHD SteerCo in progress —
   re-check before relying on this wording.)*
6. Validated scripts generate reproducible evidence — reproducible is not the same as correct.
7. No unilateral renaming of published or physical names; naming is a governed decision.
8. No non-deterministic record selection: selection plus tie-break must fully determine the result.
9. Every specification item is accounted for — mapped, classified, or explicitly excluded. Unresolved is
   permitted only when linked to a named decision or gap; **undispositioned is never permitted**.
10. Every status transition names its approver and its evidence.
11. A requirement can be unchanged while the delivery changes. A delivery-driven configuration change
    still requires configuration approval.

---

## 12. Adoption status

This document defines the **target governed process**. Controls are at differing maturity per product:
some are automated in CI today, others are human practice pending automation. A product's own `handoff/`
records which controls are live for that product. Do not read a control's presence here as a claim that
it is already automated everywhere.
