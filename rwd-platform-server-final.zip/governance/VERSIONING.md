# Versioning policy

Three **independent** version axes. Every published ADS row and every refresh manifest is stamped so a
table can always be traced back to *which engine* built *which contract* against *which data cut*.

| Axis | Form | Lives in | Example | Bumps when |
|---|---|---|---|---|
| **Engine version** | SemVer `MAJOR.MINOR.PATCH` | `platform/VERSION` | `1.0.0` | the shared engine's behaviour changes |
| **Spec version** | CalVer `YYYYMM` | a product's `config/data_product.yaml` `version:` | `202606` | any change to a product's **contract** (cohorts/derivations/variables) |
| **Data refresh** | cut label | the run / refresh manifest | `2026q1` | a new data cut, **same** contract |

`version: "YYYYMM.{snapshot}"` in a product config is the **combined** label; the engine derives
`spec_version` (the `YYYYMM` head) and `data_refresh` (the snapshot) and stamps them as **separate**
columns — they never duplicate. (`Config.spec_version` / `cfg_spec_version()`; see the R↔Python parity test.)

## Engine version (SemVer)

- **MAJOR** — a breaking engine change: an ADS that a product **cannot reproduce** just by re-pinning its
  config (changed stage semantics, dropped/renamed output columns, altered derivation math).
- **MINOR** — backward-compatible additions (a new optional stage, a new emitted column behind config).
- **PATCH** — fixes with no contract impact.

A product **pins** the engine version it was built with via the manifest's `git_commit` (today) and,
once row-provenance lands, an explicit `engine_version` stamp.

## Spec version (CalVer `YYYYMM`)

The month/year the contract was set (e.g. `202606`). CalVer is deliberately **not** semantic — it does
**not** encode breaking-vs-additive. That classification lives in the product **CHANGELOG**:

- **breaking** — a cohort/derivation/rename/remove that changes existing values → consumers must re-validate.
- **additive** — a new variable / TFL / codelist value; existing values unchanged.
- **none** — a data cut or a typo fix; no contract change (no new `spec_version`).

**Rule:** any contract change → a **new `YYYYMM` spec_version** + a **classified CHANGELOG entry** + a
matching `registry.yaml` lineage row (`supersedes:` the prior, prior → `status: superseded`). The lineage
test (`test_registry_lineage_matches_config`) fails if config and registry drift.

**Enforced, not only stated** (eleventh verdict, second pass; bound to the change in the twelfth):
`config_diff.py --all --base <rev> --check-versioning` — run by CI beside the semantic diff — refuses an
ACTIVE product whose executable surface (`config/`, `variables/`, `codelists/`, minus the environment file
`config/pipeline.yaml`) changed since the base without a CHANGELOG entry **bound to that change**. The
entry is one line in the pack's `CHANGELOG.md` (or `handoff/CHANGELOG.md`, or the slug's `CHANGELOG.md`
beside the version folders; a new, still-untracked file counts):

```
- <YYYY-MM-DD> <breaking|additive|none> <YYYYMM>: <what changed>, naming each changed file
```

It must carry the classification word, the pack's own `YYYYMM`, and the pack-relative path of every
executable file that changed — a class word anywhere in an unrelated line used to satisfy the gate.
`breaking` or `additive` means the change belongs in a NEW spec_version and the edited pack is the old
one (`new_product.py <slug> --next-cut-of <old pack>` stands it up). `none` keeps the version and may
classify only what is NOT material: wording (`label`, `description`, `notes`), the `run.*` environment,
`version`. Anything dropped, and any value the build computes with that is added or changed, is
material — a cohort, a window, a source, a threshold — and `none` is refused for it. A pack that did
not exist at the base IS the versioning.

**The next cut is bootstrapped, not copied by hand.** `new_product.py <slug> --next-cut-of
products/<family>/<slug>/<old> --spec-version <new> --workbook <revised.xlsx> --change-class
breaking|additive` stages the new folder beside the old one: `config/`, `variables/` and `codelists/`
carried by copy for revision, the revised workbook registered fresh with its own digest, the registry
entry gaining a `lineage` row at `status: draft` (`current_spec_version` does NOT move), and the
slug's CHANGELOG gaining the classified line. Records carry through `spec_diff.py --carry-plan`, never
by copy. `current_spec_version` moves — and the lineage statuses flip — in one deliberate change when
the new cut is approved and released.

## Status vs lineage — two orthogonal axes

"Status" is recorded in **three** places that answer **different** questions — don't conflate them:

| Field | Lives in | Values | Answers |
|---|---|---|---|
| **config `status`** | each spec version's `config/data_product.yaml` | `active` / `scaffold` / `planned` | Is *this* pack a **governed, non-scaffold** contract? (`active` = real/maintained, not a scaffold — it is **not** a validation claim, and **not** current-vs-superseded, which is *lineage*; e.g. `202603` is config `active` yet superseded) |
| registry **tumor `status`** | `registry.yaml` tumor entry | `active` / `scaffold` / `planned` | Is the **product** (its current version) the current supported/default pack? (**NOT** a build/preflight-success claim — a version may be registered `active` while known preflight blockers are still open) |
| registry **`lineage[].status`** | `registry.yaml` lineage row | `active` / `superseded` | Where does this version sit in the **lifecycle** — current, or a prior contract? |

The first is **buildability** (is this pack real + structurally valid, and the current/default contract? —
**NOT** a validation/release claim; release-readiness is gated separately); the third is **lifecycle** (is
this the one to build *by default*?). They are **independent**, and the worked example is prostate **202603**:

- `config.status: **active**` — it is a faithful, pruned, buildable v1 pack (76 vars), governed-grade.
- `lineage.status: **superseded**` — 202606 is the current contract; 202603 is **not** the default.

So **`superseded` ≠ broken or abandoned** — it is a frozen, still-runnable prior contract you can
deliberately re-build (`--var spec_version=202603`) to reproduce or diff against the current one. The
default resolver (`product_dir` with no explicit version) always picks the registry's
`current_spec_version`; you opt into a superseded-but-active version by naming it, and the resolver
rejects a version the registry doesn't declare (a typo) rather than guessing.

## Data refresh

A redeploy with `--var <slug>_refresh=…` (bound at deploy) and a run on the **same** contract. Tracked as a committed
`refreshes/<family>/<product>/<spec_version>/<refresh>.yaml` manifest (the ledger; the `spec_version`
segment keeps two contracts of the same product from colliding). The manifest's `git_commit` pins the
exact engine+spec, so the ADS is reproducible.

## Release tags

`release/<registry_code>/<spec_version>/<refresh>` — e.g. `release/mcrpc/202606/2026q1`. The
`spec_version` segment keeps two contracts of the same product from colliding. A released manifest must
carry `published_at`, a release pointer, and `tfl_promotion.passed` (validated).

## The output table carries the spec version

`rwdp_<tumor>_pano_<YYYYMM>` (e.g. `rwdp_pros_pano_202606`). A new contract publishes to a new table; the
prior table stays live for its consumers until they migrate (the registry records the lineage).
