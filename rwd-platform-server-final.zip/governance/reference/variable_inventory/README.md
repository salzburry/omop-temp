# Variable inventory — the reference shelf a new product starts from

**Status: `reference_only`. A drafting AID, never a specification.** Nothing in this directory
authorises a variable into a product. A variable appears in a product only when Science's approved
workbook states it, and the parameter values a product uses come from that workbook into the
product's `config/` — not from here.

## Why this exists

Every tumour's variable list is roughly one-third the same list: an index date, age and its bands,
sex, race, ECOG, a comorbidity index, a line-of-therapy table, a composite death date, and the
OS / rwPFS / rwTTD / TTNT endpoint suite. What differs between tumours is usually not the
definition but the **parameters** — one product bands age `18 / 18–45 / 45–65 / 65+`, another
`21 / 21–45 / 45–75 / 75+`; one indexes on advanced diagnosis, another on line start. Before this
shelf existed, each new product re-derived that third from scratch.

## One file, three layers

**`INVENTORY.yaml`** holds everything, so nothing here can drift out of sync with anything else:

- **`master:`** — the cross-tumour core. Each entry defines the variable ONCE and names its
  `parameter_slots`: exactly the values a tumour is expected to set (age bands, index convention,
  ECOG window, line rules, censoring convention). Example values marked `illustrative`
  demonstrate the slot mechanism and are not sourced facts.
- **`tumours:`** — 13 literature-derived overlays (ovarian, endometrial, prostate, nsclc, sclc,
  mcrc, dlbcl, cll, gist, hnscc, multiple_myeloma, myelofibrosis, mds). A variable carrying
  `master: <NAME>` **instantiates** that master entry — the shared definition lives in the master,
  the tumour's conventions live in the overlay. Variables without `master:` are tumour-specific
  (FIGO stage, HRD, PSA kinetics, IPSS-R, Miettinen risk, …).
- **`coverage:` on every variable** — `{class, via}`: `engine_family` (an existing engine family
  computes it), `config_expressible` (existing config patterns cover it, no new engine code),
  `upstream_required` (the engine configures it but does not BUILD it — it operates over a table the
  vendor already derived), or `engine_gap` (new engine work, with what is missing named in `via`).
  `platform/tools/inventory_coverage.py` validates the file and renders **`COVERAGE.md`** — the
  per-tumour counts plus the full engine_gap list, which IS the engineering backlog a new tumour
  might fund. CI refuses a stale rendering.

**`platform/tools/variables_scaffold.py <pack>`** emits parameter skeletons (into the pack's
`spec_pipeline/out/variables_scaffold/`) for exactly the master families the tumour's overlay
instantiates, every value the `REPLACE_ME` marker. A person fills each marker from the approved
workbook and copies the block into the file its header names; the build refuses any pack value
still carrying the marker, so a half-filled skeleton cannot run.

Most skeletons are `variables/` blocks; **`data_product.yaml` is not.** INDEX_DATE — the largest
family in this inventory, instantiated by 30 of the 509 overlay variables, more than any other —
parameterises `study`, `index_dates` and `cohorts` in the pack's ROOT `config/data_product.yaml`,
so that is where its skeleton says to paste it. Each skeleton names its own destination in its
header for exactly this reason.

**What is scaffolded, and what is not.** **Every master family in this inventory now has a
skeleton** — 22 families, 190 of the 509 overlay variables. No master family is a whole-family
engine gap any more:

| | families | variables | what unblocks it |
|---|---|---|---|
| has a skeleton | 22, incl. INDEX_DATE (30), COHORT_ELIGIBILITY (11), SEX (11), COMORBIDITY_INDEX (11), RW_RESPONSE (4 of 6), INSURANCE_PAYER (4) | 190 | — |
| **upstream_required** | LINE_OF_THERAPY (11) | 11 | the VENDOR must deliver a derived LOT table; the engine filters and renumbers it but does not build it from drug episodes |
| **engine gap**, per entry | 43 variables, none of them a whole family — radiotherapy courses, drug dose, multi-component risk scores (IPSS-R/IPI/R-ISS), refractoriness, transfusion burden, MRD, PRO instruments, PSA/CA-125 kinetics, and per-LINE response in DLBCL and myeloma | 43 | ENGINE work — `COVERAGE.md` names what each one needs |
| tumour-specific | no `master:` — sidedness, FOLR1/HRD, FIGO stage, … | 319 | a shared shape would have to be invented per tumour |

`upstream_required` is a fourth coverage class added after an external review found LINE_OF_THERAPY
counted as `engine_family`. `stages/lot.py` takes an already-derived vendor `lot` table and filters,
renumbers and lower-cases it; it does NOT derive lines from drug episodes with combination windows,
gaps and maintenance attribution, which is what the master entry describes. A delivery without that
table cannot produce those variables however the pack is configured, and that is exactly what a new
tumour needs to know — so the count now says it instead of implying a capability the platform does
not have.

**The class is no longer checked only for shape.** `platform/capabilities.yaml` names, per master
family, the config key a pack authors, the Python and R symbols that read it, the columns it
publishes and the tests that exercise it; `platform/tools/capability_registry.py` refuses the file
unless every one of those resolves, and refuses the PAIR of files if they disagree about which
classes a family answers — in either direction. Adding a master family here and classing it
`engine_family` without a capability entry fails; a capability claiming a class no variable asks for
fails. What the registry still does NOT prove is that the code is correct, that the named test is a
good test, or that the emitted column list is complete: a capability entry is a checked claim, not a
verified one, and `platform/CAPABILITIES.md` says so in its own header.

A family can sit in both of the first two rows, and RW_RESPONSE does: `clinical.response` answers
best-response-over-a-window for four tumours, while DLBCL's and myeloma's per-LINE response has no
config expression. `engine_gap_masters()` excludes a family only when the engine can express NONE of
its entries, so such a family is scaffolded and its remainder is reported through COVERAGE.md rather
than by withholding the skeleton from everyone.

The middle row used to be reported as "no skeleton yet", and the instruction that came with it —
"author these blocks by hand from the reference packs" — cannot be followed: no reference pack
states a block no engine reads. `variables_scaffold.engine_gap_masters()` derives the split from
this file's own `coverage.class`, so landing the engine family and re-classing the entries is what
moves a family up a row. Two tests hold the shape of this table: no scaffolded family may be a
whole-family engine gap, and **no family may sit between the rows** — a new master entry arrives
with a skeleton or with an `engine_gap` classification naming what the engine lacks, never silently
as neither.

**Three families state their own limits above the first key**, because a skeleton that looks
complete is worse than one that admits what it cannot do. `comorbidity_index` ships NO code sets and
NO weights — Quan-Charlson, NCI/Klabunde and Elixhauser each have ICD-9/ICD-10 variants and
published revisions, and an engine carrying one would choose the algorithm for every product
silently; the conditions, codes, weights and the `supersedes` hierarchy all come from the workbook.
`response` says that a window is not a line. And `categoricals`' payer item says why `window_days`
without `date_column` is refused rather than ignored.

**Not every family lives in `variables/`.** INDEX_DATE (`study`, `index_dates`, `cohorts`) and
COHORT_ELIGIBILITY (`lot`, `treatment_status`) parameterise the pack's ROOT
`config/data_product.yaml`, so their skeleton is `data_product.yaml` and its header says so. Each
skeleton names its own destination.

**Two families are mostly NOT config, and their skeletons say so before the first key.**
COHORT_ELIGIBILITY's confirmation rule (histology, IHC, model-assisted selection) describes how the
vendor built the delivery — governed at Gate 1 and Gate 3, recorded in a contract record naming the
delivered table, with nothing for config to state. SEX's `applicability` is the same: a tumour
restricted by sex has a restricted delivered population, not a filter this pack applies.

## How to use it when drafting a new product

1. Read the tumour's overlay (and the master entries it instantiates) for what published RWD
   studies of that tumour typically define. Together they are the *starting checklist* — what to
   expect the workbook to state, and the vocabulary to discuss it in.
2. When the approved workbook states a variable, draft its contract record from the workbook — the
   inventory may inform the conversation, but the workbook sentence is the specification.
3. Slot values (bands, windows, line rules) go into the product's `config/` from the workbook. The
   inventory's example values never flow into a product.
4. Cite the workbook, not this shelf, in `FUNCTIONAL_CONTRACT.md`. The inventory's citations exist
   so a reviewer can trace where a *reference* definition came from — they are not product evidence.

## Provenance and maintenance

**Every citation has a record.** `CITATIONS.yaml` gives each of the 281 distinct citations one entry
naming its identifier, the ROUTE it was checked by (`pubmed_or_publisher`, `web_search_result`,
`identifier_route_unavailable`, `in_house_drafting_surface`) and the pass that checked it;
`platform/tools/citation_register.py` refuses a citation used here with no record, a record nothing
uses, a record claiming an identifier its citation does not carry, and a weak citation not NAMED in
the caveats of a tumour that uses it — the two caveats that used to say "a few citations carry
journal/volume/page identity without a PMID or DOI" now name all six. `CITATIONS.md` renders the
weak routes in full. **No human has verified any of them**; the register records which automated
pass asserted what, which is a different and smaller claim.

**Every entry carries a BASIS, and one promotion is a person's alone.** A citation route grades a
CITATION; a basis grades the ENTRY — `literature_inferred` (read off published methodology),
`in_house_drafting` (stated on a live pack's committed drafting surfaces) or `workbook_confirmed` (a
NAMED person read the approved workbook and recorded that it states this). The first two are derived
from the citations, so no entry needs a hand-typed block to answer the question. The third is the
whole point of the field and **0 of 509 entries carry it**: the claim needs a person, a date, and a
workbook registered at Gate 1 as `<pack>#<material_id>`, and `citation_register.py` refuses it
without all three. An AI must never write it — the entire content of the tier is that a person read
the document. This is the path an mcrc entry takes when Science's workbook arrives.

**Citations bind to a VARIABLE, not to a claim.** `supports:` exists for the finer binding and is
empty on all 281 records. A citation list therefore means "these works are relevant to this entry",
never "this sentence is sourced to this paper" — and `common_sources:`, stated on all 509 variables,
is supported by none of the 858 citation uses. An AI must not fill `supports:` in: choosing which
paper supports which clause is the judgement the field exists to record.

Two kinds of entry, told apart by their citations. Literature-derived entries were integrated from
an AI literature-research pass (2026-08-13) over published RWD methodology and tumour-specific
literature; citations were verified against PubMed / publisher pages during that pass (per-tumour
`caveats` note the few citations verified without a PMID/DOI). The **mcrc** overlay was added in a
later pass (2026-08-14) under a different constraint: PubMed and the Crossref API were unreachable
from that environment, so its citations were harvested from live web-search results and publisher
URLs carrying the DOI, and the eight recorded without a verified author list are named individually
in `tumours.mcrc.caveats`. Its RWD-methodology citations are the ones the 2026-08-13 pass already
verified and are reused verbatim. Entries whose citations begin
`in-house:` are concepts stated on the live prostate/oc packs' COMMITTED drafting surfaces — the
spec-pipeline output files and the hand-typed contract records, never the raw workbook. Those
surfaces are **provisional, not approved extraction evidence**: prostate's extraction
registration is pending and unsigned, OC has no registered AI-extraction material (its
reconstruction must not be read as the June 2026 specification), and the governed slicer refuses
both packs today — treat in-house entries as provisional discovery metadata, what the house has
drafted against, not what anyone signed or verified. The coverage
classification was seeded from the engine survey the same day and is maintained by hand beside the
variables it classifies. `platform/tests/test_variable_inventory.py` pins the shape:
`reference_only` and the drafting-AID note verbatim, the seven-category vocabulary, verifiable
citations, resolving `master:` links, valid inline coverage, and a current `COVERAGE.md`. Extend a
tumour by editing its overlay (classify every new variable); add a tumour by adding a `tumours:`
entry that instantiates at least `INDEX_DATE` and `OS`.
