# Engine coverage of the variable inventory

**GENERATED from INVENTORY.yaml by `platform/tools/inventory_coverage.py` — edit the
inline `coverage:` on each variable, then regenerate. `--check` refuses a stale copy.
`reference_only`, like the inventory it summarises.**

Classes: **engine_family** — an existing engine family computes it (config names the
parameters); **config_expressible** — existing config patterns cover it, no new engine
code; **upstream_required** — the engine configures it, but only over a table the VENDOR
derives, so the platform does not build the variable and a delivery lacking that table
cannot produce it; **engine_gap** — new engine work is needed, and `via` names what is
missing.

| tumour | variables | engine_family | config_expressible | upstream_required | engine_gap |
|---|---|---|---|---|---|
| cll | 35 | 10 | 22 | 1 | 2 |
| dlbcl | 38 | 10 | 23 | 1 | 4 |
| endometrial | 35 | 12 | 22 | 1 | 0 |
| gist | 32 | 9 | 21 | 1 | 1 |
| hnscc | 37 | 10 | 19 | 0 | 8 |
| mcrc | 56 | 23 | 32 | 1 | 0 |
| mds | 35 | 5 | 23 | 0 | 7 |
| multiple_myeloma | 40 | 9 | 24 | 1 | 6 |
| myelofibrosis | 36 | 6 | 21 | 1 | 8 |
| nsclc | 38 | 15 | 21 | 1 | 1 |
| ovarian | 47 | 25 | 18 | 1 | 3 |
| prostate | 50 | 24 | 23 | 1 | 2 |
| sclc | 30 | 14 | 13 | 1 | 2 |
| **all** | **509** | **172** | **282** | **11** | **44** |

## The engine gaps — the backlog a new tumour might fund

Every variable below needs engine work before ANY tumour can configure it. Recurring
themes (a score family, a transfusion-burden family, a radiotherapy-course model, dose
modelling, lab-criteria response engines) each serve several tumours at once.

### cll

- **CIRS_SCORE** — CIRS is a clinician-rated 14-organ-system severity scale abstracted from documentation, NOT a weighted sum over coded diagnoses — clinical.comorbidity_index does not express it
- **UMRD_STATUS** — MRD assay criteria — no lab-criteria family, sparse capture

### dlbcl

- **IPI** — multi-component score — no score family (components are expressible; the score is not config)
- **NCCN_IPI** — multi-component graded score — no score family
- **REFRACTORY_STATUS** — progression-on-or-within-window joined per exposure — no refractoriness family
- **RW_RESPONSE** — per-LINE best response — clinical.response answers best-of-a-window and carries no line association, so the response for line N specifically is still engine work

### gist

- **IMATINIB_DOSE_ESCALATION** — dose reading/aggregation — drug dose is not modelled

### hnscc

- **ADJUVANT_RT_CRT** — no radiotherapy-course family — RT sources are unmodelled
- **CETUXIMAB_RT** — no radiotherapy-course family — concurrency with RT cannot be stated
- **CISPLATIN_SCHEDULE** — schedule classification needs dose + interval patterns — dose is not modelled
- **CUMULATIVE_CISPLATIN_DOSE** — dose summation over administrations — dose is not modelled
- **DEFINITIVE_CHEMORADIATION** — no radiotherapy-course family — concurrency with RT cannot be stated
- **LARYNX_PRESERVATION** — laryngectomy-free survival needs procedure-event modelling
- **RADIOTHERAPY_COURSE** — no radiotherapy-course family — RT sources are unmodelled
- **TREATMENT_INTENT_SETTING** — surgery/RT/systemic sequencing — RT sources are unmodelled

### mds

- **AML_TRANSFORMATION** — transformation-event model (subsequent diagnosis / blast threshold) — no family
- **IPSS_M_SCORE** — molecular score over a 31-gene panel — no score family
- **IPSS_R_SCORE** — multi-component score — no score family
- **IWG_HEMATOLOGIC_IMPROVEMENT** — IWG lab-criteria engine over serial CBC + transfusion logs — no family
- **IWG_RESPONSE_HR** — IWG response criteria over marrow + counts — no lab-criteria family
- **RBC_TRANSFUSION_BURDEN** — windowed unit-count over transfusion records — no transfusion-burden family
- **RBC_TRANSFUSION_INDEPENDENCE** — transfusion-independence windows — no transfusion-burden family

### multiple_myeloma

- **IMWG_RESPONSE** — per-LINE best response — clinical.response answers best-of-a-window and carries no line association, so the response for line N specifically is still engine work
- **LENALIDOMIDE_REFRACTORY** — progression-on-or-within-window per exposure — no refractoriness family
- **MRD_STATUS** — MRD assay criteria — sparse capture, no lab-criteria family
- **R2_ISS_STAGE** — additive multi-component score — no score family
- **R_ISS_STAGE** — multi-component score over FISH + labs — no score family
- **TRIPLE_CLASS_REFRACTORY** — per-class refractoriness composition — no refractoriness family

### myelofibrosis

- **ANEMIA_RESPONSE_TI** — transfusion-independence windows over transfusion records — no family
- **DIPSS_RISK_CATEGORY** — multi-component score — no score family
- **LEUKEMIC_TRANSFORMATION** — transformation-event model (subsequent diagnosis / blast threshold) — no family
- **MIPSS70_RISK_CATEGORY** — mutation-enhanced score — no score family
- **RBC_TRANSFUSION_DEPENDENCE** — windowed unit-count over transfusion records — no transfusion-burden family
- **RUXOLITINIB_DOSE** — dose reading — drug dose is not modelled
- **SVR35** — imaging volumetrics response — no imaging-response family
- **TSS50** — PRO instrument scoring — PRO sources are unmodelled

### nsclc

- **NGS_PANEL_TESTING** — the biomarkers panel has no presence mode: `aggregate: presence` resolves to `pick: nearest` (engine/stages/clinical.py) and `when: any_match` is rejected outright by value_matcher_errors. Answering "was this test performed" as distinct from "what did it say" needs engine work; it was classed config_expressible against a config surface that does not exist.

### ovarian

- **CA125_RESP** — GCIG confirmed-response/progression criteria over serial labs — no family
- **KELIM** — CA-125 elimination-rate modelling — longitudinal kinetics, no family
- **RWAE** — no adverse-event family — AE grade/attribution/outcome events are unmodelled in the engine

### prostate

- **PSA_KINETICS** — doubling time / velocity over serial values — no kinetics family
- **PSA_PROG** — PCWG3 confirmed-rise logic (second value >=3 weeks later) — no serial-confirmation family

### sclc

- **PCI_FLAG** — no radiotherapy-course family — RT sources are unmodelled
- **THORACIC_RT_FLAG** — no radiotherapy-course family — RT sources are unmodelled
