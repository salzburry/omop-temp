# Application state

No product instances or scheduled jobs are registered.
The master library and reusable templates are available for product creation.
Product approval and release state are established through the review workflow.
