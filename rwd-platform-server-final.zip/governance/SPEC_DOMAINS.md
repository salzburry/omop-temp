# Specification domains — the citation vocabulary

Every contract record cites the specification rows it comes from using the exact `item_id` emitted
by extraction, as `spec_refs: [<citation-domain>:<row>]`.
This file defines the domains. It is repo-level and **product-agnostic**, because the alternative —
citing each workbook's own sheet names — produces a vocabulary that means nothing outside that one
document and changes whenever Science reorganises their tabs.

Prostate's workbook labels its clinical sheet `5B. ClinChars` while the contract cited `5B.ClinVars`;
ovarian calls the same content `6.Clinical characteristics`. Same requirement domain, three spellings,
none of them portable. The domain is the stable name; the sheet label is an implementation detail of a
particular workbook.

## The domains

| # | Domain | Covers |
|---|---|---|
| 1 | `study_period` | data preparation, study time periods, index/follow-up window definitions, release metadata |
| 2 | `study_population` | cohorts, inclusion and exclusion criteria, treated/untreated splits |
| 3 | `demographics` | age, sex, race, ethnicity, region, practice type, socioeconomic index |
| 4 | `clinical` | clinical characteristics, staging, labs, vitals, biomarkers, disease history |
| 5 | `treatment` | lines of therapy, drug categories, prior treatment, concomitant medication |
| 6 | `outcomes` | survival, progression, response, time-to-event and their eligibility gates |

For a domain represented by one worksheet, citations remain `<domain>:<row>`, including ranges such
as `clinical:17-46`. **Row is always the original Excel row number** in the source workbook.

Several worksheets may belong to the same logical domain. For example, both Laboratory results and
Clinical assessments can map to `clinical`. Their row 2 requirements must remain distinguishable:
the extractor assigns each worksheet a citation namespace `<domain>.s<sheet-key-hash>`, where the
suffix is the first 12 hexadecimal characters of SHA-256 over the existing normalized sheet key.
The normalized key folds case and removes whitespace; sheets that collapse to the same key remain
an error. Do not invent or remove a suffix: copy the exact `item_id` from extraction.

The extracted row keeps its logical `domain`, source `tab` and original `row` separately. Only rows
in a domain with multiple worksheets gain `citation_domain`; that extraction declares
`citation_schema: sheet-qualified-v1`. Its content fingerprint binds the qualified item IDs.
Existing single-sheet artifact shapes and references remain unchanged. Coverage shows a worksheet
legend for qualified namespaces, and domain summaries continue to count the logical domain once.

Ranges stay within one namespace, for example `<supplied-clinical-namespace>:17-46`. If a second
worksheet is added, earlier unqualified references need review against the new extraction. They are
not assigned to one worksheet by guesswork, and saved definitions are not rewritten automatically.
Worksheet renames or removal can also change citation namespaces; compare the cuts and review the
affected definitions before carrying them forward.

Products may add a domain when they genuinely carry requirements outside these six (ovarian's
platinum-sensitivity strategy is a candidate). Add it here first, so it stays one shared vocabulary
rather than a per-product invention.

## Sheet → domain mapping

One map, shared by every product: [`spec_sheet_map.yaml`](spec_sheet_map.yaml). Science's sheet names are
their template, so the mapping is a repo-level fact, not a per-product one — a new tumour normally adds
nothing. The map is data, never hardcoded in a tool; that is what lets one pipeline serve every product.

The map does double duty. **A sheet listed under `sheets:` is requirement-bearing by that fact**, and
that is how the pipeline decides what to scan. Its separate `ignored:` list identifies material such
as cover pages and change logs that carries no requirements. Absence from both lists is an unresolved
classification, not permission to omit a worksheet.

A product overrides or extends the map only for a sheet genuinely specific to itself, via `DOMAINS` in
its `spec_pipeline/pipeline.conf`. Anything Science ships across products belongs in the shared map instead.

In the dashboard's Gate 2 extraction step, **Map workbook sheets to specification sections** shows
the registered workbook's actual worksheets and the shared domain choices. Several worksheets can
select the same domain. Preview runs the existing extraction and specification checks, shows the
configuration diff, row counts and citation impact, and then permits a confirmed save when its
required checks pass. The save changes this product's `pipeline.conf`; run extraction next and
review the resulting definitions. It does not approve science or release the product.

Existing product `IGNORE` choices are preserved separately, and study-only exclusions remain in
Studies or Plan changes. Labels absent from both the mapping and explicit exclusions are reported
as unclassified and must be resolved before the normal pipeline can proceed. Duplicate variable
definitions, ambiguous headers and colliding normalized sheet names retain their existing checks.

## The record keys

Separately from the citation vocabulary, every contract record carries the same **21 keys**. That list
is defined in `FUNCTIONAL_CONTRACT.md` section B and **enforced** by invariant I6 in each product's
`handoff/tests/test_functional_contract.py`. It is deliberately not repeated here: a second copy is a
second thing to drift, which is the failure this repo has already had to undo once.

Order matters and is fixed — the contract is read side by side across records, so a stable key order is
what makes a diff legible. That order lives in exactly one place, `CANON_ORDER` in
`platform/tools/contract_scaffold.py`, which is what emits records in it. This file used to restate the
list three lines below the sentence warning against restating it, and the copy had already gone stale:
it was missing `spec_digest`.

`status`, `output` and `publish` are single-line inline dicts. The lint parses them positionally, so a
multi-line version parses as absent and the record silently fails I6.
