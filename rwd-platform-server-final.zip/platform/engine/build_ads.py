"""Orchestrator: build a tumor's ADS from its config. Locked, tumor-agnostic code.

Mirrors the top-level flow of the R script — for each cohort, build index -> demographics ->
clinical -> treatment -> outcomes, assemble, then union all cohorts into one ADS. Stage modules
are imported lazily so this module imports without pyspark (config tests don't need Spark).

    from engine.config import load_config
    from engine.build_ads import build, write_ads
    cfg = load_config(".../config/data_product.yaml", overrides={"run.refresh": "2026q2"})
    ads = build(spark, cfg)
    write_ads(ads, cfg)
"""
from __future__ import annotations

import re


LOCAL_COHORT_MODE = "local_cohort_checkpoints"


def _local_checkpoint_session(spark):
    """Require a classic Spark context actually running in local mode."""
    try:
        master = spark.sparkContext.master
    except (AttributeError, RuntimeError, NotImplementedError) as exc:
        raise ValueError("Local cohort checkpoints require a local classic Spark session.") from exc
    if not isinstance(master, str) or not re.fullmatch(r"local(?:\[(?:\*|[1-9][0-9]*)(?:,[1-9][0-9]*)?\])?", master):
        raise ValueError("Local cohort checkpoints require a local classic Spark session.")


def _checkpoint_option(enabled):
    if type(enabled) is not bool:
        raise ValueError("local_cohort_checkpoints must be True or False.")


def build(spark, cfg, pins=None, telemetry=None, *, local_cohort_checkpoints=False):
    """Build and return the unioned ADS DataFrame for all configured cohorts (loads sources, then
    delegates to build_from_sources — the unit-testable core).

    The explicit local checkpoint option has the same session-ownership contract
    as build_from_sources; it is refused before loading sources on a cluster."""
    _checkpoint_option(local_cohort_checkpoints)
    if local_cohort_checkpoints:
        _local_checkpoint_session(spark)
    from .stages import sources               # lazy: only needed when actually running on Spark
    return build_from_sources(sources.load(spark, cfg, pins), cfg, telemetry=telemetry,
                              local_cohort_checkpoints=local_cohort_checkpoints)


def build_from_sources(src, cfg, telemetry=None, *, local_cohort_checkpoints=False):
    """The union path over PRE-LOADED sources: per-cohort stages -> unionByName -> derived cohorts.
    build() = sources.load + this; splitting it out lets a Spark smoke exercise the EXACT production
    union/derived-cohort path on synthetic source DataFrames (not just per-cohort stages).

    `telemetry` (an engine.telemetry.StageTelemetry, default None) records a per-stage join
    aggregate against each cohort's index frame. record() queues a plan and returns None — it
    cannot alter a frame, and with the default None this function is byte-for-byte the path it
    always was: no extra Spark action, no extra plan, R parity untouched.

    `local_cohort_checkpoints=True` is an explicit local-session execution mode:
    lazy JVM local checkpoints truncate the reused index, clinical and treatment
    plans before their consumers, then the fully derived cohort before union.
    This avoids repeating their join trees inside outcomes and assembly. It
    retains executor-local storage when
    evaluated, supplies no cluster recovery guarantee, and may evaluate columns
    a downstream projection would otherwise prune. The caller owns the local
    Spark session and must stop it in finally after consuming the result (also
    on failure), releasing checkpoint storage. The default never checkpoints."""
    _checkpoint_option(local_cohort_checkpoints)
    if local_cohort_checkpoints:
        if not src:
            raise ValueError("Local cohort checkpoints require loaded local source frames.")
        for frame in src.values():
            _local_checkpoint_session(getattr(frame, "sparkSession", None))
        print("\nLOCAL-COHORT-EXECUTION local_cohort_checkpoints", flush=True)
    from pyspark.sql import functions as F, Window
    from .stages import (index, demographics, clinical, treatment, outcomes, assemble, lot, proc,
                         ads_derived, risk_score, serial_marker, rt_course,
                         dose_exposure, modality_relation)

    # THE CORE'S OWN FLOOR. The production path already refuses a missing required column at
    # preflight, and the stage helpers' `if col in columns` guards exist as belt-and-braces on top
    # of that — their own comments say so. But an SIT that called THIS function directly proved the
    # braces alone hold nothing: dropping a required column a GUARDED path reads produced an ADS
    # with the affected variables silently absent, no refusal anywhere. Every direct caller —
    # tests, notebooks, local smokes — was one schema drift away from silent variable loss. One
    # schema pass over the frames in hand (no Spark action) closes it; roles absent from `src`
    # entirely still fail loudly at first read, and which absences are LEGITIMATE is availability
    # policy (engine.validate), not this function's call.
    from . import validate as _validate
    _required = _validate.required_columns(cfg)
    # A role can be MISSING, not just thin: the first version of this floor checked columns only
    # when a frame existed (`if _df is None: continue`), so a direct caller that omitted a
    # scientifically required source built an incomplete ADS with no refusal — the exact gap the
    # silent-omission class. Which absences are LEGITIMATE is availability policy: a role whose
    # reads are optional or when_absent-degradable never appears in required_columns at all.
    _absent = sorted(set(_required) - set(src))
    if _absent:
        raise ValueError(
            f"BUILD REFUSED — required source role(s) not supplied: {', '.join(_absent)}. "
            f"Each carries required stage reads (validate.required_columns); building without "
            f"them would emit an ADS with their variables silently absent. Supply the frames, "
            f"or make the absence a POLICY (optional read / when_absent) rather than an "
            f"omission by this caller.")
    _missing = []
    for _role, _cols in sorted(_required.items()):
        _have = {c.lower() for c in src[_role].columns}
        _missing += [f"{_role}.{c}" for c in sorted(set(_cols)) if c.lower() not in _have]
    if _missing:
        raise ValueError(
            f"BUILD REFUSED — required column(s) absent from the loaded sources: "
            f"{', '.join(_missing)}. The config requires them (validate.required_columns); "
            f"building without them would silently drop the variables they feed. Run preflight "
            f"against the cut, or fix the frames this caller assembled.")

    # Treated = a line of therapy in the cohort's RELEVANT setting, using the SAME LOT model as the
    # index/treatment stages (line_setting + exclude_settings + line_number_col) but NO maintenance
    # filter (treated is maintenance-independent). Derived PER COHORT off the cohort's line_setting so a
    # dual-setting product gets per-setting treated/untreated COHORTU (Treated/Untreated mCRPC vs mHSPC);
    # single-setting tumors fall back to the global lot.line_setting (one flag, unchanged result).
    ads = None
    for cohort in cfg.cohorts:
        treated = (lot.normalized(src, cohort.get("line_setting", cfg.lot_line_setting),
                                  exclude_settings=cfg.lot_exclude_settings,
                                  line_number_col=cfg.lot_line_number_col,
                                  maintenance_column=cfg.lot_maintenance_column)
                   .select("patientid").distinct().withColumn("treat_flag", F.lit(1)))
        cid = cohort.get("id") or str(cohort.get("cohortn"))
        idx = index.build(src, cfg, cohort)     # index_lot_cohort()
        if local_cohort_checkpoints:
            idx = idx.localCheckpoint(eager=False)
        dem = demographics.build(src, idx, cfg)  # demographics_variable_addn()
        # clinical takes the collector too: the closest-panel families inside it queue per-item
        # SELECTION plans (candidate rows, same-date ties, non-null outputs) under the cohort label
        # cohort=cid is the TELEMETRY LABEL; cohort_cfg is the cohort's own declaration
        # dict (ecog_line_match) - two parameters because they are two different things,
        # and passing the dict where a label string went crashed at .get
        clin = clinical.build(src, idx, cfg, telemetry=telemetry, cohort=cid,
                              cohort_cfg=cohort)  # clin_char_master()
        if local_cohort_checkpoints:
            clin = clin.localCheckpoint(eager=False)
        trt = treatment.build(src, idx, cfg, cohort, telemetry=telemetry)   # trt_var_creation() (cohort -> prior-taxane)
        if local_cohort_checkpoints:
            trt = trt.localCheckpoint(eager=False)
        out = outcomes.build(src, idx, clin, trt, cfg, cohort, telemetry=telemetry)  # outcomes_tbl_var() (cohort -> line N)
        cohort_ads = assemble.build(idx, dem, clin, trt, out, cfg, cohort, treated)  # overall_ads_creation()
        ps = proc.build(F, src, idx, cfg, cohort)        # OC platinum-sensitivity (2L+ line cohorts)
        if ps is not None:
            cohort_ads = cohort_ads.join(ps, ["patientid", "index_date"], "left")
        # Cross-stage derivations (outcomes.ads_derived): applied AFTER assemble+proc, when every
        # stage's columns sit on one frame — landmark flags (EFS24-style), intervals between
        # columns different stages emitted, and general expressions. Per cohort, so a derivation
        # may read cohort-shaped columns (this line's dates) like any other consumer.
        cohort_ads = ads_derived.build(F, cohort_ads, cfg)
        # Multi-component prognostic indices (outcomes.risk_scores): the SAME post-assemble reason —
        # an index's components come from different stages (age from demographics, labs from the
        # clinical panels, stage from the clinical categoricals) and only here do they sit on one
        # frame. AFTER ads_derived so a component may read a column that family derived.
        #
        # NO PACK IN THE TREE DECLARES `risk_scores` TODAY, and the stage returns the frame it was
        # given before touching it when the block is absent — so this line changes nothing for any
        # existing product. tests/test_risk_score.py asserts that no-op against a sentinel with no
        # DataFrame methods at all, which is the only way to prove it without a Spark session.
        cohort_ads = risk_score.build(F, cohort_ads, cfg)
        # Confirmed serial-marker changes (outcomes.serial_markers): PCWG3/GCIG-shaped criteria
        # over a LONG source of dated measurements. AFTER risk_score for ordering only — it
        # reads the delivered sources, not the assembled columns, and joins its two columns
        # (<name>, <name>fl) back per cohort so `from_index` anchors on THIS line's index_date.
        #
        # NO PACK IN THE TREE DECLARES `serial_markers` TODAY, and the stage returns the frame
        # untouched when the block is absent — this line changes nothing for any existing
        # product. A DECLARED instrument that cannot be applied refuses the build rather than
        # skipping the column it promised; tests/test_serial_marker.py holds both paths through
        # a stub of the exact Spark surface used.
        cohort_ads = serial_marker.build(F, src, cohort_ads, cfg)
        # The three episode families the expressibility matrix scoped — A ingests/sessionises
        # RT courses from a delivered source (patient-level; anchoring to a line is a
        # RELATION, which is exactly why B is separate), C reduces one drug's windowed
        # administrations to one number anchored on THIS cohort's index_date, and B relates
        # two dated episodes already on the frame — LAST, so it can read the columns A and C
        # (and passthrough, and ads_derived) just emitted. NO PACK DECLARES ANY OF THE THREE
        # TODAY; each returns the frame untouched when its block is absent and REFUSES a
        # declared instrument it cannot apply.
        cohort_ads = rt_course.build(F, src, cohort_ads, cfg)
        cohort_ads = dose_exposure.build(F, src, cohort_ads, cfg)
        cohort_ads = modality_relation.build(F, cohort_ads, cfg)
        if local_cohort_checkpoints:
            cohort_ads = cohort_ads.localCheckpoint(eager=False)
        if telemetry is not None:
            # Every stage boundary this loop owns, in build order. The final frame is recorded
            # AFTER proc+ads_derived — the shape the union actually takes downstream.
            for stage, frame in (("index", idx), ("demographics", dem), ("clinical", clin),
                                 ("treatment", trt), ("outcomes", out),
                                 ("cohort_ads", cohort_ads)):
                telemetry.record(F, idx, frame, cid, stage)
        ads = cohort_ads if ads is None else ads.unionByName(cohort_ads, allowMissingColumns=True)

    if ads is not None:
        ads = _apply_derived_cohorts(ads, cfg, F, Window)   # OC PROC = 2L+ platinum-Resistant split
    return ads


def _apply_derived_cohorts(ads, cfg, F, Window):
    """Append each configured derived cohort: the rows of its `from` cohorts (resolved to cohortn)
    that match the `where` SQL predicate, relabeled with the derived cohort's `cohort`/`cohortn`.

    A derived cohort SPLITS rows out of existing cohorts rather than indexing new patients — e.g. OC's
    PROC (`from: [lot2, lot3, lot4, lot5]`, `where: "plat_sen_v1 = 'Resistant'"`, cohortn 9). With
    `pick: first` only the EARLIEST qualifying line per patient is kept (by index_date) — so PROC is
    "index at FIRST platinum resistance", one row per patient, not every resistant line. Generic
    (reusable for any tumor). == engine-r/build_ads.R::apply_derived_cohorts.
    """
    id_to_n = {c["id"]: c["cohortn"] for c in cfg.cohorts}
    for dc in (cfg.raw.get("derived_cohorts") or []):
        from_ns = [id_to_n[i] for i in dc["from"] if i in id_to_n]
        sub = ads.filter(F.col("cohortn").isin(from_ns)).filter(F.expr(dc["where"]))
        if dc.get("pick") == "first":
            # A TOTAL ORDER over the WHOLE row, because `sub` is a full ADS frame and every one of
            # its columns is published. Ordering on `index_date` alone meant two source lines
            # sharing a start date flipped the entire derived-cohort row between runs — the lot*
            # columns, the outcome dates, the derived flags. `cohort`/`cohortn` are overwritten
            # just below and so were never at risk, which is exactly why the defect was invisible
            # in the columns a reader would check first.
            rest = [F.col(c).asc_nulls_last() for c in sub.columns
                    if c not in ("patientid", "index_date")]
            w = Window.partitionBy("patientid").orderBy(F.col("index_date").asc(), *rest)
            sub = sub.withColumn("_rn", F.row_number().over(w)).filter(F.col("_rn") == 1).drop("_rn")
        sub = sub.withColumn("cohort", F.lit(dc["label"])).withColumn("cohortn", F.lit(dc["cohortn"]))
        ads = ads.unionByName(sub, allowMissingColumns=True)
    return ads


def write_ads(ads, cfg) -> str:
    """Persist the ADS to {output_schema}.{output_table}. Returns the table FQN.

    A QUIET APPEND IS REFUSED. The governed runner overwrites staging on every path, but this
    direct entry honoured whatever `run.write_mode` said — so a config typo could stack two
    builds' rows in one table, and every patient would appear once per run with nothing
    downstream able to tell which rows were this build's. An audit named it as a bypass of the
    idempotency the governed path promises. A non-overwrite mode now requires the pack to say
    `run.allow_nonidempotent_write: true` beside it — the same explicit-opt-in shape every other
    dangerous convenience here uses, so the choice is visible in the config a reviewer reads,
    never implied by one word.

    And ONE output contract for both persistence paths: the same gate the governed runner
    runs on its staged write runs here first - a frame that fails the
    contract is refused, not persisted with weaker guarantees than the release path
    promises."""
    mode = cfg.write_mode
    if mode != "overwrite" and not cfg.run.get("allow_nonidempotent_write"):
        raise ValueError(
            f"WRITE REFUSED - run.write_mode is {mode!r}, which appends to (or errors on) an "
            f"existing table instead of replacing it. A re-run would stack duplicate rows under "
            f"the same name. If that is genuinely intended, say so in the config: "
            f"run.allow_nonidempotent_write: true beside run.write_mode.")
    # THE SAME CONTRACT ON EVERY PERSISTENCE PATH. The governed runner gates its staged
    # write on run_output_contract; this direct entry used to persist the frame with no
    # contract at all - an audit named the two paths' different safety guarantees. The
    # gate runs HERE, before the write, and a failing verdict refuses the write by name.
    from engine.output_contract import (contract_spec, output_contract_gate,  # noqa: PLC0415
                                        run_output_contract)
    gate = output_contract_gate(run_output_contract(ads.sparkSession, ads, cfg),
                                contract_spec(cfg))
    if not gate.get("passed"):
        raise ValueError(
            "WRITE REFUSED - the output contract fails on this frame: "
            + "; ".join(gate.get("failures") or
                        ["unconfigured check(s) under output_contract_strict: "
                         + ", ".join(gate.get("unconfigured") or [])]))
    (ads.write
        .mode(mode)
        .option("overwriteSchema", "true")
        .saveAsTable(cfg.output_fqn))
    return cfg.output_fqn
