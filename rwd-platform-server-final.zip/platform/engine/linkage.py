"""Patient linkage between every loaded source and the index spine — measured, counts only.

An audit's finding, in effect verbatim: sources are ASSUMED to share `patientid`; orphan
records disappear during joins with no record anywhere, and output-side duplicate checks
cannot see patients lost upstream. This module is the measurement half. Per loaded source:
how many distinct patients it carries, how many of them the spine (the index source) actually
indexes, how many are orphans a join will silently drop, how much of the spine the source
never mentions, the row fan-out per patient, and the rows whose patientid is null — rows that
can never join anyone. Counts only, deliberately: a sample of offending ids would put patient
identifiers into a report that travels into manifests and chat (the grain report's own rule).

What REFUSES is a ruling. Every threshold defaults to None and every number rides the report
either way — an unset threshold is not a licence, it is a pack that has not stated its
tolerance (the adapter parse-loss grammar). "This orphan rate is unacceptable" is a statement
about a delivery contract, so the pack declares it (`qc.source_thresholds.linkage`) when a
person rules, and the gate then holds it per source, by name. Spine coverage in particular is
EVIDENCE before it is ever a defect: an index patient absent from a mortality feed is a
patient who has not died.

Token reconciliation and linkage CONFIDENCE are a production process upstream of this
repository; this module measures what arrived, it never re-links anyone.
"""

PATIENT_COLUMN = "patientid"

# The CLOSED threshold vocabulary — an unrecognised key is refused, never read as the nearest
# one, because a typo'd tolerance that silently gates nothing is the fail-open this repository
# exists to refuse.
DEFAULT_THRESHOLDS = {
    "max_orphan_rate": None,         # share of a source's patients the spine never indexes
    "max_spine_missing_rate": None,  # share of spine patients this source never mentions
    "max_rows_per_patient": None,    # fan-out bound
    "max_null_patient_rows": None,   # rows that can never join anyone
}
# which of those are RATES (bounded [0, 1]); the rest are counts (finite, >= 0)
RATE_THRESHOLDS = ("max_orphan_rate", "max_spine_missing_rate")


def bad_threshold(name, v, rate=False):
    """Why `v` cannot gate as `name`, or None. FAIL-CLOSED on an unusable value.

    an earlier review reproduced all three ways a declared tolerance waved everything
    through: a string raised TypeError out of the gate, NaN compared false against every
    measurement (so ~99% parse loss passed), and `max_orphan_rate: 2` permitted total
    orphaning because nothing held a rate to [0, 1]. A threshold that cannot compare, or
    that compares vacuously, is a declaration in name only — refused, never evaluated."""
    if v is None:
        return None
    if isinstance(v, bool) or not isinstance(v, (int, float)):
        return (f"{name}: {v!r} is not a number — a tolerance that cannot compare gates "
                f"nothing while looking declared")
    if v != v or v in (float("inf"), float("-inf")):
        return (f"{name}: {v!r} is not finite — NaN and infinity compare vacuously, waving "
                f"every measurement through")
    if rate and not (0 <= v <= 1):
        return (f"{name}: {v!r} is outside [0, 1] — a rate tolerance above 1 permits total "
                f"loss and one below 0 refuses everything; neither is a ruling")
    if not rate and v < 0:
        return f"{name}: {v!r} is negative — a count tolerance below zero is unsatisfiable"
    return None


def linkage_report(F, src, cfg) -> dict:
    """{role: counts} for every loaded source beside the spine; skipped entries say why.

    The spine is `cfg.index_source`. Three Spark actions per source (per-patient aggregate,
    linked-count join, and the spine's own distinct count once) — pre-build cost, not per-row.
    A source with no patientid column is skipped BY NAME: an unlinkable source is an answer,
    never a silence. Null patientids are counted apart from patients — a null key joins
    nothing and groupBy would otherwise fold every such row into one phantom patient.
    """
    spine_role = getattr(cfg, "index_source", None)
    spine = (src or {}).get(spine_role)
    if spine is None or PATIENT_COLUMN not in spine.columns:
        return {"_skipped": f"index source {spine_role!r} is not loaded or carries no "
                            f"{PATIENT_COLUMN} — nothing to link against"}
    spine_p = spine.select(PATIENT_COLUMN).where(F.col(PATIENT_COLUMN).isNotNull()).distinct()
    n_spine = spine_p.count()
    out = {"_spine": {"role": spine_role, "patients": n_spine}}
    for role, df in sorted((src or {}).items()):
        if role == spine_role or df is None:
            continue
        if PATIENT_COLUMN not in df.columns:
            out[role] = {"skipped": f"no {PATIENT_COLUMN} column — rows here can never join "
                                    f"a patient"}
            continue
        per = df.groupBy(PATIENT_COLUMN).agg(F.count(F.lit(1)).alias("_r"))
        agg = per.agg(
            F.sum(F.when(F.col(PATIENT_COLUMN).isNotNull(), 1).otherwise(0)).alias("p"),
            F.max(F.when(F.col(PATIENT_COLUMN).isNotNull(), F.col("_r"))).alias("mx"),
            F.avg(F.when(F.col(PATIENT_COLUMN).isNotNull(), F.col("_r"))).alias("av"),
            F.sum(F.when(F.col(PATIENT_COLUMN).isNull(), F.col("_r")).otherwise(0)).alias("nul"),
        ).collect()[0]
        n_p = int(agg["p"] or 0)
        linked = per.join(spine_p, PATIENT_COLUMN, "inner").count()
        orphans = n_p - linked
        out[role] = {
            "patients": n_p,
            "linked": linked,
            "orphans": orphans,
            "orphan_rate": round(orphans / n_p, 4) if n_p else None,
            "spine_missing": n_spine - linked,
            "spine_missing_rate": round((n_spine - linked) / n_spine, 4) if n_spine else None,
            "max_rows_per_patient": int(agg["mx"] or 0),
            "avg_rows_per_patient": round(float(agg["av"] or 0), 2),
            "null_patient_rows": int(agg["nul"] or 0),
        }
    return out


def declared(thresholds) -> bool:
    """Whether the pack has RULED at all — any threshold set to a value. The distinction the
    gate needs, because a declared tolerance the run could not measure must fail (the grain
    gate's rule), while an undeclared one measuring nothing has made no claim."""
    return any(v is not None for k, v in (thresholds or {}).items()
               if k in DEFAULT_THRESHOLDS)


def linkage_gate(report: dict, thresholds: dict | None = None) -> dict:
    """{passed, failures} over a linkage_report. Pure data.

    Report-only until the pack rules: with every threshold None nothing fails, and the numbers
    are in the report regardless. A declared threshold is held per source, naming the source
    and the metric. An unrecognised threshold key is REFUSED — a typo'd tolerance that gates
    nothing would be fail-open wearing a declaration."""
    t = dict(DEFAULT_THRESHOLDS)
    unknown = sorted(set(thresholds or {}) - set(DEFAULT_THRESHOLDS))
    t.update({k: v for k, v in (thresholds or {}).items() if k in DEFAULT_THRESHOLDS})
    failures = []
    # AN UNUSABLE VALUE IS A FAILURE, NEVER A COMPARISON: an invalid tolerance drops to None
    # after being named, so nothing downstream evaluates it and the gate is red either way.
    for k in sorted(DEFAULT_THRESHOLDS):
        why = bad_threshold(f"qc.source_thresholds.linkage.{k}", t[k],
                            rate=k in RATE_THRESHOLDS)
        if why:
            failures.append(why)
            t[k] = None
    if unknown:
        failures.append(f"qc.source_thresholds.linkage: unrecognised threshold(s) "
                        f"{', '.join(unknown)} — the closed set is "
                        f"{', '.join(sorted(DEFAULT_THRESHOLDS))}")
    if declared(t) and (not report or "_skipped" in report):
        failures.append("linkage tolerances are declared and the run could not measure "
                        "linkage — a declaration the run cannot test must fail, not report "
                        "itself and pass"
                        + (f" ({report['_skipped']})" if report and "_skipped" in report else ""))
    for role, r in sorted((report or {}).items()):
        if role.startswith("_") or "skipped" in r:
            continue
        # THE RATES ARE COMPARED UNROUNDED. The report rounds them to four places for a reader;
        # a gate that read the rounded figure passed 3 orphans in 100,000 (0.00003 -> 0.0) under
        # a declared ceiling of 0.00001. The counts are the measurement; the rate is recomputed
        # from them here and the rounded one is only a fallback for a report carrying no counts.
        n_p = r.get("patients")
        spine = (report.get("_spine") or {}).get("patients")
        orphan = _exact(r.get("orphans"), n_p, r.get("orphan_rate"))
        missing = _exact(r.get("spine_missing"), spine, r.get("spine_missing_rate"))
        for key, val in (("max_orphan_rate", orphan),
                         ("max_spine_missing_rate", missing),
                         ("max_rows_per_patient", r.get("max_rows_per_patient")),
                         ("max_null_patient_rows", r.get("null_patient_rows"))):
            lim = t.get(key)
            if lim is not None and val is not None and val > lim:
                failures.append(f"{role}: {key[4:]} {val} > {key} {lim}")
    return {"passed": not failures, "failures": failures}


def _exact(count, denominator, rounded):
    """count / denominator when both are recorded, else the rounded figure the report carries."""
    if isinstance(count, (int, float)) and isinstance(denominator, (int, float)) and denominator:
        return count / denominator
    return rounded


def linkage_verdict(source_report: dict, thresholds: dict | None = None) -> dict:
    """The candidate verdict's OWN linkage block, or {} when the pack has not ruled (programme
    item 4: linkage as its own key). Report-only linkage stays evidence inside the source QC
    report and evaluates to nothing here; a declared tolerance is held — and a declaration the
    run could not measure fails, never reads as a pass. `declared` and `measured` ride along so
    a reader of the manifest can tell "held and passed" from "never asked"."""
    thresholds = thresholds or {}
    if not declared(thresholds):
        return {}
    report = (source_report or {}).get("linkage") or {}
    err = (source_report or {}).get("linkage_error")
    if err:
        return {"passed": False, "declared": True, "measured": False,
                "failures": ["linkage tolerances are declared and linkage was not measurable: " + str(err)]}
    gate = linkage_gate(report, thresholds)
    return {"passed": gate["passed"], "declared": True, "measured": bool(report) and "_skipped" not in report,
            "failures": list(gate["failures"]), "thresholds": {k: v for k, v in thresholds.items() if k in DEFAULT_THRESHOLDS}}
