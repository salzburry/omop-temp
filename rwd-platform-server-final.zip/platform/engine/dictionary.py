"""Data dictionary generation — the consumer-facing variable spec, per audience.

Generalises the legacy build_dictionary audience model (internal / sales / customer) to NEUTRAL
audiences: `internal` / `partner` / `customer` — **`partner` replaces the customer-specific
"sales"**. Built from the master catalog (metadata/catalog.yaml), filtered by tumor
applicability + per-variable `pii`/`audiences` flags, and projected to the audience's columns.

Pure-Python: build_dictionary() + render_markdown(). Observed-value / %-patients statistics are an
optional `stats` input (computed from the ADS on a cluster) — keyed by variable code.

    python engine/dictionary.py <catalog.yaml> --audience partner [--tumor mcrpc]
"""
from __future__ import annotations

import sys
import re

try:
    from .config import load_yaml
except ImportError:
    from config import load_yaml

# Neutral audience contract (override via dictionary/audiences.yaml). `partner` = the old "sales".
DEFAULT_AUDIENCES = {
    "internal": {"columns": ["category", "code", "label", "applies_to"], "drop_pii": False},
    "partner":  {"columns": ["category", "label"], "drop_pii": True},
    "customer": {"columns": ["category", "label", "applies_to"], "drop_pii": True},
}


def load_audiences(path=None) -> dict:
    if path is None:
        return dict(DEFAULT_AUDIENCES)
    return load_yaml(path).get("audiences", DEFAULT_AUDIENCES)


def _applies(var: dict, tumor) -> bool:
    a = var.get("applies_to", "all")
    return a == "all" or tumor is None or tumor in a


def _emitted(var, allowed):
    code = str(var.get("code") or "")
    if not var.get("line_template"):
        return code.lower() in allowed
    # The catalog's lotN<suffix> row covers the same suffix on ordinary and
    # maintenance lines. It documents only families present in this delivery.
    if code.startswith("lotN"):
        pattern = r"lot[1-9]\d*m?" + re.escape(code[len("lotN"):])
    else:
        pattern = re.escape(code).replace("N", r"[1-9]\d*")
    return any(re.fullmatch(pattern, column, flags=re.IGNORECASE) for column in allowed)


def delivery_summary(variable_counts, xlsx_failed=()):
    """Content and format completeness for the configured audience deliveries."""
    audiences = list(variable_counts)
    empty = [audience for audience, count in variable_counts.items() if count == 0]
    failed = list(xlsx_failed)
    all_empty = not audiences or len(empty) == len(audiences)
    status = "empty" if all_empty else ("partial" if empty or failed else "ok")
    return {"status": status, "audiences": audiences, "n_variables": dict(variable_counts),
            "empty_audiences": empty, "markdown": "empty" if all_empty else ("partial" if empty else "ok"),
            "xlsx": "failed" if failed else ("ok" if audiences else "empty"), "xlsx_failed": failed}


def build_dictionary(catalog: dict, audience="internal", tumor=None, audiences=None, stats=None,
                     columns=None) -> dict:
    """Build the dictionary structure for one audience (+ optional tumor filter + ADS stats).

    `columns` (the ACTUAL built-ADS columns, passed by the runner) restricts the dictionary to what is
    genuinely emitted — mirroring dashboard.build_manifest — so a catalog-applicable but feed-absent
    OPTIONAL variable (an absent PSA-at-diagnosis pass-through, or a conmed flag whose source lacks the
    drug-name column) is NOT advertised. Without it the dictionary is catalog-applicability based (the
    static/test view).
    """
    aud = audiences or DEFAULT_AUDIENCES
    if audience not in aud:
        raise KeyError(f"unknown audience '{audience}'; have {sorted(aud)}")
    spec = aud[audience]
    cols, drop_pii = spec["columns"], spec.get("drop_pii", False)
    allowed = {c.lower() for c in columns} if columns is not None else None

    rows = []
    for v in catalog.get("variables", []):
        if not _applies(v, tumor):
            continue
        # A compact family row still needs one concrete family member in the
        # actual ADS. Otherwise the dictionary promises an excluded field.
        if allowed is not None and not _emitted(v, allowed):
            continue
        if drop_pii and v.get("pii"):                      # PII never ships to partner/customer
            continue
        if audience not in v.get("audiences", list(aud)):  # per-variable audience restriction
            continue
        row = {c: v.get(c) for c in cols}
        if stats and v.get("code") in stats:               # observed values / % patients, if given
            row.update(stats[v["code"]])
        rows.append(row)

    cats = sorted({r.get("category") for r in rows if r.get("category")})
    return {"audience": audience, "tumor": tumor, "columns": cols,
            "summary": {"n_variables": len(rows), "categories": cats},
            "variables": rows}


def _cell(value):
    """Flatten a catalog value into one dictionary cell: a list (e.g. applies_to: [oc, ec]) becomes a
    comma-joined string, None becomes empty, scalars pass through. Keeps markdown tidy and lets
    openpyxl serialize the cell (it rejects list values)."""
    if value is None:
        return ""
    if isinstance(value, (list, tuple)):
        return ", ".join(str(x) for x in value)
    return value


def render_markdown(d: dict) -> str:
    from collections import defaultdict
    head = f"# Data dictionary — audience: {d['audience']}"
    if d.get("tumor"):
        head += f" — tumor: {d['tumor']}"
    lines = [head, "",
             f"**Variables:** {d['summary']['n_variables']}  |  "
             f"**Categories:** {', '.join(d['summary']['categories'])}", ""]
    show = [c for c in d["columns"] if c != "category"]
    by_cat = defaultdict(list)
    for r in d["variables"]:
        by_cat[r.get("category", "")].append(r)
    for cat in sorted(by_cat):
        lines += [f"## {cat}", "", "| " + " | ".join(show) + " |",
                  "|" + "|".join(["---"] * len(show)) + "|"]
        for r in by_cat[cat]:
            lines.append("| " + " | ".join(str(_cell(r.get(c))) for c in show) + " |")
        lines.append("")
    return "\n".join(lines)


def render_xlsx(d: dict, path: str, generated_at=None) -> str:
    """Write the dictionary to an .xlsx (Summary + Variables sheets). Needs openpyxl.

    Same content as render_markdown — the styled stakeholder format the legacy build_dictionary
    produced, but driven by the catalog + neutral audiences.

    BYTE-STABLE FOR IDENTICAL CONTENT, which a plain `Workbook()` + `save()` is not. An xlsx is a
    ZIP of XML, and openpyxl stamps TWO clocks into it that have nothing to do with the dictionary:
    `dcterms:created` / `dcterms:modified` in the document properties, and a modification time on
    every ZIP entry. Both move every second, so the same dictionary produced two different files
    and the sha256 the manifest records could never repeat.

    `generated_at` is an INPUT for the same reason it is one everywhere else in this run — the
    caller reads its clock once and passes it, so a reproduction test can pin it. With none given
    the stamps are fixed rather than ambient: a constant is honest here because the manifest
    already records when the run happened, and a second, differently-rounded copy of that inside
    the bytes only breaks the digest.
    """
    import zipfile                                                       # noqa: PLC0415
    from datetime import datetime                                        # noqa: PLC0415
    from openpyxl import Workbook
    from openpyxl.styles import Font

    wb = Workbook()
    s = wb.active
    s.title = "Summary"
    s.append(["Data dictionary", d["audience"] + (f" / {d['tumor']}" if d.get("tumor") else "")])
    s.append(["Variables", d["summary"]["n_variables"]])
    s.append(["Categories", ", ".join(d["summary"]["categories"])])
    s["A1"].font = Font(bold=True)

    v = wb.create_sheet("Variables")
    v.append(list(d["columns"]))
    for c in v[1]:
        c.font = Font(bold=True)
    for r in d["variables"]:
        v.append([_cell(r.get(c)) for c in d["columns"]])

    # THE EPOCH IS FIXED, NOT NOW. openpyxl defaults both properties to the moment of the call.
    stamp = _EPOCH
    if generated_at:
        try:
            stamp = datetime.fromisoformat(str(generated_at).replace("Z", "+00:00"))
            stamp = stamp.replace(tzinfo=None)
        except ValueError:
            stamp = _EPOCH
    wb.properties.created = stamp
    wb.properties.modified = stamp
    wb.properties.creator = ""
    wb.properties.lastModifiedBy = ""
    wb.save(path)

    # ...AND THE ZIP'S OWN CLOCKS, which `wb.properties` does not reach. Rewritten in place, in
    # the SAME entry order, so only the timestamps change. Without this the file still differed
    # second to second while every byte of XML was identical.
    _normalise_zip_times(path, stamp)
    return path


# 1980-01-01 is the earliest instant the ZIP format can represent; anything lower silently clamps.
_EPOCH = __import__("datetime").datetime(1980, 1, 1, 0, 0, 0)


def _normalise_zip_times(path, stamp):
    """Rewrite an xlsx with one fixed time on every entry AND inside docProps, order preserved.

    TWO CLOCKS, and setting `wb.properties` reaches only one of them. openpyxl re-stamps
    `dcterms:modified` during `save()`, AFTER the assignment — so the properties looked normalised
    and the file still differed second to second. Verified: two renders 1.2s apart agreed on every
    entry except `docProps/core.xml`. Rewriting the archive is the only place both can be settled.
    """
    import os                                                            # noqa: PLC0415
    import re                                                            # noqa: PLC0415
    import zipfile                                                       # noqa: PLC0415
    when = (max(stamp.year, 1980), stamp.month, stamp.day,
            stamp.hour, stamp.minute, stamp.second)
    iso = stamp.strftime("%Y-%m-%dT%H:%M:%SZ")
    tmp = str(path) + ".tmp"
    with zipfile.ZipFile(path) as src:
        items = [(i, src.read(i.filename)) for i in src.infolist()]
    with zipfile.ZipFile(tmp, "w", zipfile.ZIP_DEFLATED) as out:
        for info, data in items:
            if info.filename == "docProps/core.xml":
                text = data.decode("utf-8")
                text = re.sub(r"(<dcterms:(?:created|modified)[^>]*>)[^<]*(</dcterms:)",
                              rf"\g<1>{iso}\g<2>", text)
                data = text.encode("utf-8")
            fresh = zipfile.ZipInfo(info.filename, date_time=when)
            fresh.compress_type = info.compress_type
            fresh.external_attr = info.external_attr
            out.writestr(fresh, data)
    os.replace(tmp, path)


def main(argv):
    if len(argv) < 2:
        print("usage: python engine/dictionary.py <catalog.yaml> [--audience X] [--tumor Y] [--xlsx out.xlsx]")
        return 2
    catalog = load_yaml(argv[1])
    audience = argv[argv.index("--audience") + 1] if "--audience" in argv else "internal"
    tumor = argv[argv.index("--tumor") + 1] if "--tumor" in argv else None
    d = build_dictionary(catalog, audience=audience, tumor=tumor)
    if "--xlsx" in argv:
        print("wrote " + render_xlsx(d, argv[argv.index("--xlsx") + 1]))
    else:
        print(render_markdown(d))
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv))
