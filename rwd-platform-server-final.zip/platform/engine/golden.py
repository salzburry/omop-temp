"""Golden comparison: diff a newly-built ADS against the original (R) ADS for a known refresh.

The reference table (the original `rwdp_<tumor>_pano_<YYYYMM>`, e.g. rwdp_pros_pano_202603) is a
PARAMETER — supply it when the team has one. `compare_columns`/`summarise_diff`/`_dist_columns` are pure-Python (unit-tested);
`run_golden` executes the row/cohort/distribution/time-to-event (OS, PFS, PFS2) comparison on Spark
(cluster only). Returns a report dict; it never writes.
"""
from __future__ import annotations


def compare_columns(new_cols, ref_cols) -> dict:
    n, r = set(new_cols), set(ref_cols)
    return {"only_in_new": sorted(n - r), "only_in_ref": sorted(r - n), "shared": sorted(n & r)}


def summarise_diff(new_counts: dict, ref_counts: dict) -> dict:
    """Per-key count delta (e.g. per cohort): {key: {new, ref, delta, pct}}. Pure Python."""
    out = {}
    for k in sorted(set(new_counts) | set(ref_counts)):
        a, b = new_counts.get(k, 0), ref_counts.get(k, 0)
        out[k] = {"new": a, "ref": b, "delta": a - b,
                  "pct": (round(100 * (a - b) / b, 2) if b else None)}
    return out


def _dist_columns(new_cols, ref_cols) -> list:
    """Categorical columns to compare for distribution drift, present on BOTH tables. Treatment
    category prefers the cohort-indexed `lotcat` (what TFL/dashboard use) and falls back to `lot1cat`
    only for a legacy ADS built before it existed — mirroring tfl.generate(). Comparing lot1cat for an
    L2/L3/maintenance cohort would miss drift in its actual line category."""
    shared = set(new_cols) & set(ref_cols)
    cols = [c for c in ("stage", "ecog", "race", "regionl", "plat_sen_v1") if c in shared]
    lot = "lotcat" if "lotcat" in shared else ("lot1cat" if "lot1cat" in shared else None)
    if lot:
        cols.append(lot)
    return cols


def run_golden(spark, new_fqn: str, ref_fqn: str, cfg=None,
               cohort_col: str = "cohort", os_col: str = "os",
               new_version=None, ref_version=None) -> dict:
    """Compare new vs reference ADS tables. Spark-side (cluster only).

    The reference is a GOVERNED INPUT, pinned like every other: read live and recorded only by
    name, a rewrite of the reference between runs silently moved the yardstick. When versions are
    given both frames open `versionAsOf` and the report records them, so the comparison the QC
    gate scored is the comparison the manifest describes."""
    from pyspark.sql import functions as F

    def _open(fqn, ver):
        return (spark.read.option("versionAsOf", str(ver)).table(fqn)
                if ver is not None else spark.table(fqn))
    new, ref = _open(new_fqn, new_version), _open(ref_fqn, ref_version)
    report = {"new": new_fqn, "ref": ref_fqn,
              "new_version": new_version, "ref_version": ref_version}

    # column set diff
    report["columns"] = compare_columns(new.columns, ref.columns)

    # row counts
    report["n_rows"] = {"new": new.count(), "ref": ref.count()}

    # cohort counts (delta per cohort)
    if cohort_col in new.columns and cohort_col in ref.columns:
        nc = {r[cohort_col]: r["n"] for r in
              new.groupBy(cohort_col).agg(F.count(F.lit(1)).alias("n")).collect()}
        rc = {r[cohort_col]: r["n"] for r in
              ref.groupBy(cohort_col).agg(F.count(F.lit(1)).alias("n")).collect()}
        report["cohort_counts"] = summarise_diff(nc, rc)

    # categorical distributions on shared columns (lotcat / stage / ecog / race …)
    report["distributions"] = {}
    for c in _dist_columns(new.columns, ref.columns):
        nd = {str(r[c]): r["n"] for r in new.groupBy(c).agg(F.count(F.lit(1)).alias("n")).collect()}
        rd = {str(r[c]): r["n"] for r in ref.groupBy(c).agg(F.count(F.lit(1)).alias("n")).collect()}
        report["distributions"][c] = summarise_diff(nd, rd)

    # Numeric time-to-event summaries (count / mean / median / quartiles), both sides — one per
    # endpoint present on BOTH tables: OS always, PFS/PFS2 for OC/EC. Stored as <col>_summary.
    # ONE approxQuantile AND ONE aggregation PER SIDE, for every endpoint together — not one of
    # each per endpoint. `approxQuantile` accepts a LIST of columns and computes them in a single
    # pass; the previous shape called it once per column and preceded each call with its own
    # `df.count()`, so a three-endpoint product paid nine actions per side to answer one question
    # about one frame. Same numbers, same tolerance.
    endpoints = [c for c in dict.fromkeys([os_col, "pfs", "pfs2"])        # os first; dedup, ordered
                 if c in new.columns and c in ref.columns]

    def summ_all(df):
        if not endpoints:
            return {}
        agg = df.agg(*[f(c).alias(f"{k}_{c}") for c in endpoints
                       for k, f in (("n", F.count), ("mean", F.avg))]).collect()[0]
        # An empty frame has no quantiles to estimate; asking anyway returns [] per column and the
        # unpacking below would be an IndexError on the one input most likely to reach production
        # by accident.
        qs = (df.approxQuantile(endpoints, [0.25, 0.5, 0.75], 0.01)
              if int(agg[f"n_{endpoints[0]}"] or 0) or df.head(1) else [[None] * 3] * len(endpoints))
        return {c: {"n": agg[f"n_{c}"], "mean": agg[f"mean_{c}"],
                    "q25": qs[i][0] if qs[i] else None,
                    "median": qs[i][1] if len(qs[i]) > 1 else None,
                    "q75": qs[i][2] if len(qs[i]) > 2 else None}
                for i, c in enumerate(endpoints)}

    ns, rs = summ_all(new), summ_all(ref)
    for col in endpoints:
        report[f"{col}_summary"] = {"new": ns[col], "ref": rs[col]}

    return report


# --- golden gate: turn a run_golden() summary into a pass/fail decision (pure Python) ----------
# A reference ADS is OPTIONAL; when none is supplied the gate SKIPS (passes). When one is supplied,
# gross drift vs the reference (original R ADS, or the prior refresh) blocks publish — mirroring the
# QC gate. Thresholds are tunable per tumor via a `golden.thresholds` config block.
DEFAULT_GOLDEN_THRESHOLDS = {
    "max_row_delta_pct": 10.0,           # |new-ref| / |ref| total rows
    "max_cohort_delta_pct": 15.0,        # worst per-cohort row drift
    "max_os_median_delta_pct": 15.0,     # OS median drift (new vs ref)
    "max_pfs_median_delta_pct": 15.0,    # PFS median drift (OC/EC)
    "max_pfs2_median_delta_pct": 15.0,   # PFS2 median drift (OC/EC)
    "max_distribution_delta_pct": 25.0,  # worst per-category drift within a categorical distribution
    "min_distribution_ref_count": 30,    # ignore tiny reference categories (drift % is noise there)
    "allow_new_columns": True,           # extra columns in new are OK; columns DROPPED vs ref never are
}


def golden_thresholds(cfg) -> dict:
    """Framework defaults merged with an optional per-tumor `golden.thresholds` config block."""
    t = dict(DEFAULT_GOLDEN_THRESHOLDS)
    if cfg is not None:
        t.update((cfg.raw.get("golden") or {}).get("thresholds", {}))
    return t


def _abs_pct(new, ref):
    """|new - ref| / |ref| as a percent, or None when ref is missing/zero (can't compute drift)."""
    if new is None or ref in (None, 0):
        return None
    return round(abs(new - ref) / abs(ref) * 100, 2)


def golden_gate(summary: dict | None, thresholds: dict | None = None) -> dict:
    """Gate a run_golden() summary against drift thresholds. Returns {passed, failures[, skipped]}.

    `summary` is the dict run_golden() returns (NOT the {reference, summary} wrapper). Pure data.
    """
    # ONLY `None` MEANS "no reference configured". `[]`, `""`, `0` and `False` are malformed
    # evidence and used to take the skip branch because falsiness was tested before type
    # (fourth audit); they fail the gate now.
    if summary is None:
        return {"passed": True, "failures": [], "skipped": "no reference ADS"}
    failures = []
    # EVIDENCE AND THRESHOLDS ARE TYPED BEFORE ANY COMPARISON. `n_rows.new = NaN` passed (NaN
    # compares false against every threshold) and a non-mapping thresholds container raised
    # TypeError — a release gate that fails OPEN or crashes on malformed evidence (third audit).
    # Every numeric read below goes through `_fin`, which records a failure for anything that is
    # not a finite number, and shape errors are failures, not exceptions.
    import math
    if not isinstance(summary, dict):
        return {"passed": False, "failures": [f"golden summary must be a mapping, got "
                                              f"{type(summary).__name__}"]}
    if thresholds is not None and not isinstance(thresholds, dict):
        return {"passed": False, "failures": [f"golden.thresholds must be a mapping, got "
                                              f"{type(thresholds).__name__}"]}
    t = {**DEFAULT_GOLDEN_THRESHOLDS, **(thresholds or {})}

    def _fin(label, v, allow_none=True):
        """A finite number, or None with a recorded failure (None itself is 'absent' when allowed)."""
        if v is None and allow_none:
            return None
        if isinstance(v, bool) or not isinstance(v, (int, float)) or math.isnan(v) or math.isinf(v):
            failures.append(f"golden evidence {label}={v!r} is not a finite number — "
                            f"uncomputable evidence fails the gate, it does not pass it")
            return None
        return v

    def _map(label, v):
        if v is None:
            return {}
        if not isinstance(v, dict):
            failures.append(f"golden evidence {label} must be a mapping, got {type(v).__name__}")
            return {}
        return v

    # A SUPPLIED REFERENCE MUST BE USABLE, AND SO MUST THE THRESHOLDS. "No reference configured"
    # is the one legitimate skip (above); a reference that IS configured and has zero rows, or a
    # threshold that is NaN or a string, previously fell into `_abs_pct`'s None ("can't compute")
    # and passed — new=100 against ref=0 gated green, and a YAML `NaN` threshold let 100% drift
    # through (external audit, 2026-09-02). Uncomputable is a failure of the gate's inputs, and it
    # is reported as one, never as a pass.
    import math
    # CLOSED AND TYPED. An unknown key (`max_rows_delta_pct`, one letter off) used to be ignored
    # while the default it meant to override stayed live, and the string "false" for
    # allow_new_columns was truthy — both weakened the gate silently (second audit). Every key
    # must be a known one; the flag must be a real bool; every threshold a finite number.
    for k in (thresholds or {}):
        if k not in DEFAULT_GOLDEN_THRESHOLDS:
            failures.append(f"golden threshold {k!r} is not a known key — did you mean one of "
                            f"{sorted(DEFAULT_GOLDEN_THRESHOLDS)}? An unknown key changes nothing, "
                            f"so the default it was meant to replace is still in force")
    for k, v in t.items():
        if k == "allow_new_columns":
            if not isinstance(v, bool):
                failures.append(f"golden threshold allow_new_columns={v!r} must be a YAML boolean "
                                f"(true/false), not a string — the string 'false' is truthy")
            continue
        if not isinstance(v, (int, float)) or isinstance(v, bool) or math.isnan(v) \
                or math.isinf(v):
            failures.append(f"golden threshold {k}={v!r} is not a finite number — the gate cannot "
                            f"evaluate against it; fix golden.thresholds in the pack config")
    if failures:
        return {"passed": False, "failures": failures}

    nr = _map("n_rows", summary.get("n_rows"))
    new_n, ref_n = _fin("n_rows.new", nr.get("new"), allow_none=False), \
        _fin("n_rows.ref", nr.get("ref"), allow_none=False)
    if ref_n is not None and not ref_n:
        failures.append(f"reference ADS has {ref_n!r} rows — a reference that exists and is "
                        f"empty (or unreadable) cannot gate anything; regenerate or unconfigure it")
    d = _abs_pct(new_n, ref_n)
    if d is not None and d > t["max_row_delta_pct"]:
        failures.append(f"row-count drift {d}% > {t['max_row_delta_pct']}%")

    for coh, c in _map("cohort_counts", summary.get("cohort_counts")).items():
        p = _fin(f"cohort_counts[{coh}].pct", _map(f"cohort_counts[{coh}]", c).get("pct"))
        if p is not None and abs(p) > t["max_cohort_delta_pct"]:
            failures.append(f"cohort '{coh}' drift {abs(p)}% > {t['max_cohort_delta_pct']}%")

    # categorical distribution drift (lot1cat / stage / ecog / race / regionl) — worst per-category,
    # ignoring tiny reference categories where a % delta is just noise.
    for col, dist in _map("distributions", summary.get("distributions")).items():
        for val, c in _map(f"distributions[{col}]", dist).items():
            c = _map(f"distributions[{col}][{val}]", c)
            p = _fin(f"distributions[{col}][{val}].pct", c.get("pct"))
            ref_c = _fin(f"distributions[{col}][{val}].ref", c.get("ref")) or 0
            if ref_c >= t["min_distribution_ref_count"] and p is not None \
                    and abs(p) > t["max_distribution_delta_pct"]:
                failures.append(
                    f"{col}='{val}' distribution drift {abs(p)}% > {t['max_distribution_delta_pct']}%")

    # time-to-event median drift — OS always; PFS/PFS2 when the summary is present (OC/EC).
    for col in ("os", "pfs", "pfs2"):
        s = _map(f"{col}_summary", summary.get(f"{col}_summary"))
        m_new = _fin(f"{col}_summary.new.median", _map(f"{col}_summary.new", s.get("new")).get("median"))
        m_ref = _fin(f"{col}_summary.ref.median", _map(f"{col}_summary.ref", s.get("ref")).get("median"))
        if m_ref is not None and m_ref == 0:
            # a zero reference median is unusable evidence, not "no drift" (fourth audit)
            failures.append(f"{col.upper()} reference median is 0 — a zero reference cannot gate "
                            f"drift; the reference summary is unusable")
        d = _abs_pct(m_new, m_ref)
        thr = t.get(f"max_{col}_median_delta_pct", t["max_os_median_delta_pct"])
        if d is not None and d > thr:
            failures.append(f"{col.upper()} median drift {d}% > {thr}%")

    cols = _map("columns", summary.get("columns"))
    if cols.get("only_in_ref"):
        failures.append(f"columns missing vs reference: {cols['only_in_ref']}")
    if not t.get("allow_new_columns", True) and cols.get("only_in_new"):
        failures.append(f"unexpected new columns vs reference: {cols['only_in_new']}")

    return {"passed": not failures, "failures": failures}
