#!/usr/bin/env python3
"""A digest of the DATA a build published — the half of reproducibility nothing computed.

`refresh.reproduction_id` answers "did two runs receive the same inputs?". It cannot answer "did
they produce the same content?", and until something does, "reproducible" is a claim about the
left-hand side of an equation with no right-hand side. This is the right-hand side.

IT IS A FUNCTION OF THE PUBLISHED CELLS AND OF NOTHING ELSE. Not of the clock, the run id, the
build id, the engine version, the file layout, the partition count, the shuffle, or which machine
ran it. Two builds that publish the same values agree; two that publish different values do not.
That is the entire contract, and every design choice below follows from it:

  ORDER-INDEPENDENT, WITHOUT A SORT. Row hashes are combined by ADDITION in a wide modulus, so the
  order rows arrive in cannot change the answer. Delta does not promise a physical row order, and
  repartitioning, a different executor count or a changed AQE setting all reshuffle it — a digest
  that sorted first would be exact and would also cost a full shuffle on every build. Addition is
  commutative, so no sort is needed and no ordering assumption is made.

  DUPLICATES COUNT. XOR is the other obvious commutative combine and it is wrong here: two
  identical rows XOR to zero, so a build that duplicated every patient would produce the digest of
  an empty table. Addition keeps them, and the row count is carried alongside as a second witness.

  NULL IS NOT EMPTY, AND 1 IS NOT "1". Every cell is encoded with its type tag and a length prefix
  before hashing, so a null, an empty string and the literal text "None" are three different
  values, and a column silently delivered as a string instead of an integer changes the digest
  rather than passing through it. A join that drops to null is the single most common way a build
  goes wrong quietly; it must not be the one thing this cannot see.

  THE COLUMN NAME IS PART OF THE CELL. Otherwise swapping two same-typed columns leaves the digest
  unchanged.

WHAT IT DELIBERATELY DOES NOT COVER. Nothing about how the data was produced — no code version, no
config digest, no adapter binding, and nothing whatsoever from the assistant/chat layer. Those
belong to `reproduction_id`, and keeping them out is what makes the two independent: a change to
the AI helper tooling, a new engine release, or a rewritten pipeline must leave this digest
untouched if the published values are the same. If it moved when the helper layer moved, it would
be measuring the wrong thing.

`CANON_VERSION` is part of the digest input, so a future change to the encoding cannot silently
make old and new digests incomparable — they will simply differ, and the version says why.

Pure Python over rows; `spark_content_digest` pushes the identical arithmetic into one Spark
aggregation so a billion-row table needs no driver memory and no sort.
"""
from __future__ import annotations

import hashlib

# Bump ONLY with a deliberate change to the encoding below. It is inside the hash, so digests from
# two versions differ rather than silently comparing equal on a changed definition of equality.
CANON_VERSION = "1"

# 2**256. Row hashes are summed modulo this, which keeps the full 256 bits of each row while
# staying commutative.
_MOD = 1 << 256


def cell(name, value) -> bytes:
    """One cell as unambiguous bytes: column, type tag, length, payload.

    The length prefix is what stops `("ab", "c")` and `("a", "bc")` hashing alike, and the type tag
    is what stops the integer 1 and the string "1" doing so. Both are ordinary encoding hygiene and
    both are the difference between a digest that detects a schema drift and one that absorbs it.
    """
    if value is None:
        tag, payload = b"n", b""                     # null is its own type, not an empty string
    elif isinstance(value, bool):                    # before int: bool IS an int in Python
        tag, payload = b"b", (b"1" if value else b"0")
    elif isinstance(value, int):
        tag, payload = b"i", str(value).encode("utf-8")
    elif isinstance(value, float):
        # repr round-trips exactly for float, so two equal floats encode identically and two
        # different ones cannot collide through a lossy format.
        tag, payload = b"f", repr(value).encode("utf-8")
    elif isinstance(value, (bytes, bytearray)):
        tag, payload = b"y", bytes(value)
    else:
        # dates, decimals and everything else go through str(); Spark's side does the same, so the
        # two implementations agree by construction rather than by coincidence.
        tag, payload = b"s", str(value).encode("utf-8")
    key = str(name).encode("utf-8")
    return b"%d:%s|%s%d:%s" % (len(key), key, tag, len(payload), payload)


def row_digest(row, columns) -> str:
    """One row's canonical sha256. `columns` fixes the order, so a reordered SELECT is not a change."""
    h = hashlib.sha256()
    h.update(CANON_VERSION.encode("utf-8"))
    for name in columns:
        h.update(cell(name, row.get(name)))
    return h.hexdigest()


def content_digest(rows, columns=None) -> dict:
    """{rows, columns, digest, canon_version} over an iterable of row mappings.

    The digest is `sha256(canon_version | column list | summed row hashes | row count)`. The sum is
    order-independent; the count is carried inside it so a table and the same table with a row
    duplicated and another removed cannot collide.
    """
    rows = list(rows)
    if columns is None:
        seen = []
        for r in rows:
            for k in r:
                if k not in seen:
                    seen.append(k)
        columns = sorted(seen)
    columns = list(columns)
    total, n = 0, 0
    for r in rows:
        total = (total + int(row_digest(r, columns), 16)) % _MOD
        n += 1
    h = hashlib.sha256()
    h.update(CANON_VERSION.encode("utf-8"))
    h.update(("\x1f".join(columns)).encode("utf-8"))
    h.update(b"%064x" % total)
    h.update(b"|%d" % n)
    return {"rows": n, "columns": columns, "digest": h.hexdigest(),
            "canon_version": CANON_VERSION}


def _spark_cell_sql(name, dtype) -> str:
    """The Spark SQL fragment reproducing `cell()` for one column — a PURE string builder, split
    out so its conformance to the Python encoding is testable on a machine with no Spark at all.

    TWO NONCONFORMANCES AN AUDIT FOUND, both of the same kind: the Spark reproduction encoded a
    value the Python definition encodes differently, so the two digests could disagree about
    identical content and an independent reproduction would read as tampering.

      * BOOLEANS: `CAST(bool AS STRING)` is 'true'/'false'; `cell()` writes b"1"/b"0". Encoded
        explicitly now, payload and length both.
      * LENGTHS: Spark `length()` counts CHARACTERS; `cell()` prefixes the BYTE length of the
        utf-8 payload. `octet_length()` counts utf-8 bytes, which is the same number for ASCII
        and the correct one beyond it.

    The Python `cell()` is the definition and did NOT change, so CANON_VERSION does not bump —
    its own rule is "bump ONLY with a deliberate change to the encoding", and a nonconforming
    reproduction brought into conformance is a bug fix, not a new encoding. Digests already
    computed by the pure path keep their values.

    STATED RESIDUAL: floats. `cell()` uses Python `repr`; Spark CAST formats exponents
    differently (1e20 -> '1e+20' vs '1.0E20'), so a float column can still diverge between the
    two engines at extreme magnitudes. Not silently absorbed: published ADS columns are dates,
    strings, ints and plain decimals, and the parity test names the gap so the day a float
    column joins the surface this is a known question, not a surprise.
    """
    t = str(dtype)
    tag = ("i" if t.startswith(("int", "bigint", "smallint", "tinyint")) else
           "b" if t == "boolean" else
           "f" if t.startswith(("double", "float")) else "s")
    q = "`" + str(name).replace("`", "``") + "`"
    if t == "boolean":
        txt = f"CASE WHEN {q} THEN '1' ELSE '0' END"
    else:
        txt = f"CAST({q} AS STRING)"
    key = str(name).encode("utf-8")
    return (f"concat("
            f"'{len(key)}:', '{name}', '|', "
            f"CASE WHEN {q} IS NULL THEN 'n0:' "
            f"ELSE concat('{tag}', CAST(octet_length({txt}) AS STRING), ':', {txt}) END)")


def spark_content_digest(df, columns=None) -> dict:
    """The same digest over a Spark DataFrame, in one aggregation and without a sort.

    The 256-bit sum is carried as four 64-bit lanes summed independently in DECIMAL(38,0) — Spark
    has no 256-bit integer, and a plain BIGINT sum would overflow silently. The lanes are then
    recombined with carries on the driver, so the arithmetic is identical to the pure version
    above rather than merely similar.
    """
    from pyspark.sql import functions as F

    columns = list(columns if columns is not None else sorted(df.columns))
    types = dict(df.dtypes)
    parts = [_spark_cell_sql(name, types.get(name, "string")) for name in columns]
    payload = "concat(" + ", ".join(["'" + CANON_VERSION + "'"] + parts) + ")"
    hashed = df.select(F.expr(f"sha2({payload}, 256)").alias("_h"))
    lanes = hashed.select(*[
        F.expr(f"sum(cast(conv(substr(_h, {1 + i * 16}, 16), 16, 10) as decimal(38,0)))")
        .alias(f"l{i}") for i in range(4)],
        F.count(F.lit(1)).alias("n")).collect()[0]

    total, n = 0, int(lanes["n"])
    for i in range(4):
        lane = int(lanes[f"l{i}"] or 0)
        total = (total + (lane << (64 * (3 - i)))) % _MOD
    h = hashlib.sha256()
    h.update(CANON_VERSION.encode("utf-8"))
    h.update(("\x1f".join(columns)).encode("utf-8"))
    h.update(b"%064x" % total)
    h.update(b"|%d" % n)
    return {"rows": n, "columns": columns, "digest": h.hexdigest(),
            "canon_version": CANON_VERSION}
