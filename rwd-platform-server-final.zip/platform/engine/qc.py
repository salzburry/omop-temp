"""Semantic QC for a built ADS — the layer the schema preflight can't cover.

Run AFTER build, before publishing. Reports the distributions reviewers asked for: date-castability,
mortality granularity + duplicate-conflict counts, unmapped stage ('CHECK'), unmatched treatment
(the catch-all rate), null-rates, and row/cohort counts.

`qc_spec(cfg)` is the pure-Python plan (unit-tested). `run_qc(spark, ads, cfg)` executes it on a
Spark DataFrame (cluster only). Nothing here writes data; it returns a report dict.
"""
from __future__ import annotations

# Sentinel labels the engine emits (a high rate of either is a data-quality smell): the treatment
# line-category catch-all and the staging fallthrough. Both are DERIVED from the EXACT config location
# the engine compiles from, so QC checks the label the engine actually emits and can't drift. When a
# tumor declares neither, the derivation returns None and QC SKIPS that check — it never substitutes a
# hardcoded guess, which could silently mismatch the emitted label and let a bad build pass.


def _catchall_label(cfg):
    """Label of the catch-all (`match: {always: true}`) row of the treatment LINE-CATEGORY codelist —
    the codelist the treatment pack NAMES (`line_category_codelist`) and the engine compiles into the
    per-line `lot{i}cat`. Not "the first codelist that happens to carry an always-row": a tumor with a
    second codelist (e.g. biomarkers) whose always-row has a different label must not hijack this.
    Returns None when no line-category codelist is declared (QC then skips the catch-all check)."""
    try:
        clname = (cfg.pack("treatment") or {}).get("line_category_codelist")
        if not clname:
            return None
        for cat in cfg.codelist(clname).get("categories", []):
            if (cat.get("match") or {}).get("always"):
                return cat.get("label")
    except Exception: # noqa: BLE001 - no treatment pack / codelist -> skip the check, don't guess
        return None
    return None


def _stage_check_label(cfg):
    """Label of the staging fallthrough group (`when: fallthrough` in clinical.staging), or None when
    the tumor declares no staging (QC then skips the unmapped-stage check rather than guessing 'CHECK')."""
    try:
        for g in (cfg.pack("clinical").get("staging") or {}).get("groups") or []:
            if g.get("when") == "fallthrough":
                return g.get("label")
    except Exception: # noqa: BLE001 - no clinical pack / staging -> skip the check, don't guess
        return None
    return None



def _acceptance(cfg) -> dict:
    """The pack's DECLARED acceptance criteria (`qc:` block), normalised - plus their
    declaration errors, because a malformed criterion silently measuring nothing would be
    fail-open wearing a declaration.

    An audit named the hole exactly: null percentages were CALCULATED and nothing could fail
    on them - a required column could be present, entirely null, and pass. Three declarable
    criteria close the machinery half:

      null_limits:      {column: max_null_rate} - per-variable, the audit's own ask
      nonnegative:      [column, ...] - declaring a column here IS the ruling that a
                        negative value in it is a defect (durations, counts)
      event_date_pairs: [{flag: pfsfl, date: pfsdt}, ...] - a row that flags an event
                        must carry the event's date; declaring the pair is the ruling

    WHICH columns and WHICH numbers stay the pack's: nothing here derives a limit, because
    "this variable may be N% null" is a statement about a delivery and a cohort that a
    person signs off, not an engineering fact. Undeclared = unmeasured = ungated, exactly
    like the parse-loss and linkage grammar."""
    try:
        q = dict(cfg.raw.get("qc") or {})
    except Exception: # noqa: BLE001 - a stub cfg with no raw has declared nothing
        q = {}
    errors, limits, nonneg, pairs = [], {}, [], []
    for col, lim in sorted((q.get("null_limits") or {}).items()):
        try:
            limits[str(col).lower()] = float(lim)
        except (TypeError, ValueError):
            errors.append(f"qc.null_limits.{col}: {lim!r} is not a rate")
    for c in (q.get("nonnegative") or []):
        if isinstance(c, str) and c.strip():
            nonneg.append(c.strip().lower())
        else:
            errors.append(f"qc.nonnegative: {c!r} is not a column name")
    for i, pr in enumerate(q.get("event_date_pairs") or []):
        fl = (pr or {}).get("flag") if isinstance(pr, dict) else None
        dt = (pr or {}).get("date") if isinstance(pr, dict) else None
        if fl and dt:
            pairs.append({"flag": str(fl).lower(), "date": str(dt).lower()})
        else:
            errors.append(f"qc.event_date_pairs[{i}]: needs flag AND date, got {pr!r}")
    return {"null_limits": limits, "nonnegative": nonneg, "event_date_pairs": pairs,
            "errors": errors}


def _slc(cfg):
    """treatment.setting_line_columns, or {} - the reader mirrors _catchall_label's tolerance:
    a broken pack yields no setting variants rather than a raise inside the QC plan."""
    try:
        return cfg.pack("treatment").get("setting_line_columns") or {}
    except Exception: # noqa: BLE001 - treatment pack optional for the plan
        return {}


def _slc_lines(slc, setting, default):
    """The per-setting line count: `lines` may be a shared int or a per-setting map
    (G-PER-SETTING-LOT, build-out A7) - the same resolution the treatment stage and the
    emitted-variables inventory use. An audit found this planner still calling int() on the
    whole MAP, so prostate's post-build QC crashed the day the map landed - the planner must
    speak every dialect the config does. An unnamed setting plans nothing here (0); the BUILD
    is what refuses it."""
    ln = slc.get("lines", default)
    if isinstance(ln, dict):
        try:
            return int(ln.get(setting) or 0)
        except (TypeError, ValueError):
            return 0
    try:
        return int(ln)
    except (TypeError, ValueError):
        return 0


def chronology_rules(max_lines, suffix="") -> list:
    """The chronology/overlap rules, pure data: {name, columns, predicate}.

    An audit found NO active checks for line end-before-start, inter-line overlap or order,
    treatment-before-diagnosis or death-before-index: a build over such rows was structurally
    green with cohort and endpoint accuracy silently at risk. These rules MEASURE every one of
    those counts on every QC run; whether any count REFUSES a build is a ruling the pack
    declares (`qc.thresholds.max_chronology_violations`), because "overlapping lines are
    vendor-plausible up to N" is a clinical tolerance, not an engineering fact.

    A rule is active only when every column it reads is on the frame (run_qc reports the
    inactive ones with their missing columns - skipped is an answer, never a silence).
    Predicates try_cast-to-date BOTH sides so an uncastable value can never make the probe
    itself raise - bad dates are already counted by the castability check, and a null comparison
    counts nothing here.

    NOT `try_to_date`, which is what this used to emit. That routine DOES NOT EXIST in Apache
    Spark 4.0 - it is a Databricks extension, and the pinned pyspark==4.0.1 answers
    UNRESOLVED_ROUTINE. Verified by scanning the pinned jars: zero classes in
    spark-catalyst/spark-sql/spark-sql-api carry the symbol, and it is absent from
    FunctionRegistry. This is not Spark 4 being stricter; it is code written against Databricks
    meeting OSS Spark for the first time, and bumping the pin is not the fix - 4.0.1 is pinned as
    a PAIR with delta-spark 4.0.0, and the expression has to resolve on both engines anyway.

    `try_cast(x as date)` is the same expression: Spark's ParseToDate with no format IS
    Cast(expr, DateType). The equivalence holds ONLY because neither call site passes a format -
    `try_to_date(x, fmt)` is NOT the same thing, so a format argument added later needs a
    different answer."""
    def d(c):
        return f"try_cast(try_cast(`{c}` as string) as date)"

    # `suffix` builds the per-setting variants (_mhspc/_mcrpc) of the LINE rules over the
    # setting-suffixed columns treatment._setting_line_columns emits; the two cross-domain
    # rules (diagnosis, death) ride only the base call. A setting that declares no `ed`
    # attribute simply leaves its end/overlap rules in chronology_inactive - reported, by name.
    def lc(stem):
        return stem + suffix

    rules = []
    for i in range(1, max_lines + 1):
        rules.append({"name": f"lot{i}_end_before_start{suffix}",
                      "columns": [lc(f"lot{i}ed"), lc(f"lot{i}sd")],
                      "predicate": f"{d(lc(f'lot{i}ed'))} < {d(lc(f'lot{i}sd'))}"})
    for i in range(1, max_lines):
        rules.append({"name": f"lot{i}_overlaps_lot{i + 1}{suffix}",
                      "columns": [lc(f"lot{i}ed"), lc(f"lot{i + 1}sd")],
                      "predicate": f"{d(lc(f'lot{i}ed'))} > {d(lc(f'lot{i + 1}sd'))}"})
        rules.append({"name": f"lot{i + 1}_starts_before_lot{i}{suffix}",
                      "columns": [lc(f"lot{i + 1}sd"), lc(f"lot{i}sd")],
                      "predicate": f"{d(lc(f'lot{i + 1}sd'))} < {d(lc(f'lot{i}sd'))}"})
    if suffix:
        return rules
    rules.append({"name": "treatment_before_diagnosis",
                  "columns": ["lot1sd", "advanceddiagnosisdate"],
                  "predicate": f"{d('lot1sd')} < {d('advanceddiagnosisdate')}"})
    rules.append({"name": "death_before_index",
                  "columns": ["dthdt", "index_date"],
                  "predicate": f"{d('dthdt')} < {d('index_date')}"})
    return rules

def qc_spec(cfg) -> dict:
    """The QC plan, derived from config so it adapts per tumor. Pure data, no Spark."""
    max_lines = 6
    try:
        max_lines = int(cfg.pack("treatment").get("max_lines", 6))
    except Exception: # noqa: BLE001 - treatment pack optional for the plan
        pass
    return {
        "cohort_columns": ["cohort", "cohortn", "cohortu", "cohortun"],
        # categorical columns to show distributions for (only those present are used at runtime)
        "categorical": ["cohort", "agegrl", "regionl", "race", "eth", "ecog", "stage",
                        *[f"lot{i}cat" for i in range(1, max_lines + 1)]],
        # rate-of-sentinel checks
        "treatment_catchall": {"columns": [f"lot{i}cat" for i in range(1, max_lines + 1)],
                               "label": _catchall_label(cfg)},
        "stage_check": {"column": "stage", "label": _stage_check_label(cfg)},
        # date columns to test castability (logical -> the ADS column name)
        "date_columns": ["index_date", "dthdt", "fued", "advanceddiagnosisdate"],
        # the DECLARED acceptance criteria - measured for what is declared, held by the gate
        "acceptance": _acceptance(cfg),
        # chronology/overlap counts - measured always, gated only when the pack rules;
        # the per-setting line variants join whenever the pack declares setting_line_columns
        "chronology": chronology_rules(max_lines) + [
            r for slc in [_slc(cfg)] for st in (slc.get("settings") or [])
            for r in chronology_rules(_slc_lines(slc, st, max_lines),
                                      suffix="_" + str(st).lower())],
    }


def run_qc(spark, ads, cfg) -> dict:
    """Compute the QC report for a built ADS DataFrame. Spark-side (cluster only).

    TWO ACTIONS, NOT THIRTEEN, and the shape is the point rather than the saving. Every number
    below except the cohort breakdown is a `sum(when(...))` over ONE scan of the same frame: the
    row count, every column's null count, the catch-all hits and their eligible denominators, the
    unmapped-stage count, and both halves of every date-castability ratio.

    It used to issue them separately — `ads.count()`, then a null-rate select, then a
    `filter().count()` per line column, then a stage filter, then TWO counts per date column. On a
    six-line pack with four date columns that is thirteen passes over one table to answer one
    question about it, and an external review measured roughly eighteen actions in this function.
    Each pass re-reads the ADS, and on a wide Delta table that is the dominant cost of QC.

    The cohort breakdown stays a separate `groupBy`, because it returns one row per cohort rather
    than one number, and folding a variable-cardinality result into a scalar aggregation would mean
    pivoting on values only known at runtime.
    """
    from pyspark.sql import functions as F

    spec = qc_spec(cfg)
    cols = set(ads.columns)
    report = {"version": cfg.version, "refresh": cfg.refresh}

    exprs = [F.count(F.lit(1)).alias("_n")]

    # NULL COUNTS, not rates: a rate needs the denominator, and the denominator is `_n` in this same
    # row. Summing here and dividing in Python keeps it to one pass and makes the division auditable.
    for c in ads.columns:
        exprs.append(F.sum(F.when(F.col(c).isNull(), 1).otherwise(0)).alias(f"null_{c}"))

    cat = spec["treatment_catchall"]
    catchall_cols = ([c for c in cat["columns"] if c in cols]
                     if cat.get("label") is not None else [])
    for c in catchall_cols:
        exprs.append(F.sum(F.when(F.col(c) == cat["label"], 1).otherwise(0)).alias(f"h_{c}"))
        # OVER ELIGIBLE ROWS, NOT OVER THE ADS. A patient with no third line has a NULL `lot3cat`,
        # so dividing line-3 catch-alls by every patient made the rate FALL as the untreated share
        # ROSE — the opposite of the taxonomy-gap signal `max_catchall_rate` is worded for.
        exprs.append(F.sum(F.when(F.col(c).isNotNull(), 1).otherwise(0)).alias(f"e_{c}"))

    sc = spec["stage_check"]
    stage_col = sc["column"] if (sc.get("label") is not None and sc["column"] in cols) else None
    if stage_col:
        exprs.append(F.sum(F.when(F.col(stage_col) == sc["label"], 1).otherwise(0)).alias("_stage"))

    date_cols = [c for c in spec["date_columns"] if c in cols]
    for c in date_cols:
        exprs.append(F.sum(F.when(F.col(c).isNotNull(), 1).otherwise(0)).alias(f"dnn_{c}"))
        # NESTED try_cast: this counts BAD dates, so it must never be the thing that raises.
        # Under ANSI-on a bare cast made the QC probe itself fail on exactly the rows it exists
        # to count. (`try_to_date` is unresolvable on the pinned Spark 4.0.1 - see chronology_rules.)
        exprs.append(F.sum(F.when(F.col(c).isNotNull() &
                                  F.expr(f"try_cast(try_cast(`{c}` as string) as date)").isNull(), 1)
.otherwise(0)).alias(f"dbad_{c}"))

    acc = spec["acceptance"]
    unmeasured = [f"null_limits: column {c!r} is not on the ADS"
                  for c in acc["null_limits"] if c not in cols]
    nn_cols = [c for c in acc["nonnegative"] if c in cols]
    unmeasured += [f"nonnegative: column {c!r} is not on the ADS"
                   for c in acc["nonnegative"] if c not in cols]
    ok_pairs = [pr for pr in acc["event_date_pairs"]
                if pr["flag"] in cols and pr["date"] in cols]
    unmeasured += [f"event_date_pairs: {pr['flag']!r}/{pr['date']!r} not both on the ADS"
                   for pr in acc["event_date_pairs"] if pr not in ok_pairs]
    for c in nn_cols:
        exprs.append(F.sum(F.when(F.expr(f"try_cast(`{c}` as double) < 0"), 1)
.otherwise(0)).alias(f"neg_{c}"))
    for pr in ok_pairs:
        exprs.append(F.sum(F.when(F.expr(
            f"try_cast(`{pr['flag']}` as int) = 1 AND `{pr['date']}` IS NULL"), 1)
.otherwise(0)).alias(f"emd_{pr['flag']}"))

    chron = [r for r in spec["chronology"] if all(c in cols for c in r["columns"])]
    for r in chron:
        # null-safe by construction: a predicate over a null date is null, and when(null)
        # takes the otherwise(0) arm - a missing or uncastable date counts nothing here
        exprs.append(F.sum(F.when(F.expr(r["predicate"]), 1).otherwise(0))
.alias(f"ch_{r['name']}"))

    row = ads.agg(*exprs).collect()[0] # ACTION 1
    n = int(row["_n"] or 0)
    report["n_rows"] = n

    if "cohort" in cols:
        report["cohorts"] = {r["cohort"]: r["n"] for r in # ACTION 2
                             ads.groupBy("cohort").agg(F.count(F.lit(1)).alias("n")).collect()}

    if n:
        rates = {c: round(int(row[f"null_{c}"] or 0) / n, 4) for c in ads.columns}
        report["null_rate"] = {c: v for c, v in rates.items() if v}

    if catchall_cols:
        tr, elig = {}, {}
        for c in catchall_cols:
            e = int(row[f"e_{c}"] or 0)
            elig[c] = e
            # None, not 0.0: a line nobody reached has no catch-all RATE, and 0.0 would read as
            # "we classified them all correctly".
            tr[c] = round(int(row[f"h_{c}"] or 0) / e, 4) if e else None
        report["catchall_rate"] = tr
        report["catchall_eligible"] = elig # the denominator, so the rate can be audited
        report["catchall_label"] = cat["label"]

    if stage_col and n:
        report["stage_check_rate"] = round(int(row["_stage"] or 0) / n, 4)
        report["stage_check_label"] = sc["label"]

    if (acc["null_limits"] or acc["nonnegative"] or acc["event_date_pairs"]
            or acc["errors"]):
        report["acceptance"] = {
            # measured criteria only ride here; a declared column the frame does not carry
            # is in `unmeasured`, and the gate FAILS it - a claim nobody tested, never a skip
            "null_limits": {c: v for c, v in acc["null_limits"].items() if c in cols},
            "nonnegative_negative_rows": {c: int(row[f"neg_{c}"] or 0) for c in nn_cols},
            "event_missing_date": {f"{pr['flag']}->{pr['date']}":
                                   int(row[f"emd_{pr['flag']}"] or 0) for pr in ok_pairs},
            "declaration_errors": list(acc["errors"]),
            "unmeasured": unmeasured,
        }

    if chron:
        report["chronology"] = {r["name"]: int(row[f"ch_{r['name']}"] or 0) for r in chron}
    inactive = {r["name"]: [c for c in r["columns"] if c not in cols]
                for r in spec["chronology"] if not all(c in cols for c in r["columns"])}
    if inactive:
        # skipped is an answer: a chronology rule whose columns this build does not carry
        # is reported with the columns it wanted, never silently absent from the report
        report["chronology_inactive"] = inactive

    dc = {}
    for c in date_cols:
        d, bad = int(row[f"dnn_{c}"] or 0), int(row[f"dbad_{c}"] or 0)
        if d and bad:
            dc[c] = round(bad / d, 4)
    if dc:
        report["uncastable_date_rate"] = dc

    return report


# The column the LOT preflight asks about. Here rather than in the offline SQL generator because
# the EXECUTING check and the paste-ready SQL must ask the same question of the same column.
LOT_SETTING_COLUMN = "linesetting"


def source_expectations(cfg) -> dict:
    """{topic: {source, column, expected, declared_in}} — the value strings the derivations branch on.

    Read from the config, never from prose, so the check compares against what the build will
    actually do. A value the feed spells differently does not fail a build — it silently matches
    nothing and the column comes back empty or Unknown; these are the checks that find that BEFORE
    a person is reduced to reading DISTINCT results out of a SQL editor. `source_preflight.py`
    renders the same expectations as paste-ready SQL for the no-cluster day; this is the one
    derivation both read.
    """
    out = {}
    clin = cfg.pack("clinical")
    bio = clin.get("biomarkers") or {}
    if bio.get("panel") and bio.get("name_column"):
        out["biomarker_names"] = {
            "source": "biomarkers", "column": str(bio["name_column"]),
            "expected": sorted({m for p in bio["panel"] for m in (p.get("match_any") or [])}),
            "declared_in": "variables/clinical.yaml#/biomarkers panel[].match_any"}
    lv = clin.get("lab_values") or {}
    if lv.get("panel") and lv.get("name_column"):
        out["lab_names"] = {
            "source": "lab", "column": str(lv["name_column"]),
            "expected": sorted({str(p.get("match")) for p in lv["panel"] if p.get("match")}),
            "declared_in": "variables/clinical.yaml#/lab_values panel[].match"}
    settings = sorted({str(c.get("line_setting")) for c in (cfg.cohorts or [])
                       if c.get("line_setting")})
    if settings:
        out["line_settings"] = {
            "source": "lot", "column": LOT_SETTING_COLUMN, "expected": settings,
            "declared_in": "config/data_product.yaml#/cohorts[].line_setting"}
    return out


def _distinct_lower(spark, cfg, source, column, pins=None):
    """The DISTINCT lower-cased values of one column across every table a source resolves to.

    Reads through `sources._read`, honouring the SAME pins the build uses — source QC inspecting a
    version the build never reads was the recorded-but-not-inspected half of the snapshot rule."""
    from functools import reduce

    from pyspark.sql import functions as F
    from.stages import sources as _sources
    frames = [_sources._read(spark, f, pins) for f in cfg.source_fqns(source)]
    df = reduce(lambda a, b: a.unionByName(b, allowMissingColumns=True), frames)
    cols = {c.lower(): c for c in df.columns}
    # BOTH overlays, via the one resolver the build and preflight use. Source QC used to apply the
    # legacy rename block only, so a vocabulary column a REVIEWED adapter bound under a different
    # delivered name read as absent and the topic failed with "carries no column" — QC refusing the
    # delivery the adapter was signed for.
    from.config import canonical_physical # noqa: PLC0415
    for canonical, phys in (canonical_physical(cfg, source) or {}).items():
        if phys in cols and canonical != phys:
            cols[canonical] = cols.pop(phys)
    if column.lower() not in cols:
        raise KeyError(f"{source} carries no column {column!r}")
    return _collect_vocab(df, cols[column.lower()], F, f"{source}.{column}", cap=_vocab_cap(cfg))


# A controlled vocabulary is SMALL by definition. The cap is a refusal threshold, not a silent
# truncation (no-silent-caps): a column with more distinct values than this is almost certainly
# a misbound free-text or identifier column, and collecting it would sink the Spark driver -
# the audit-13 scale finding. Raise, name the column, and let the run fail where the cause is.
VOCAB_DISTINCT_CAP = 2000


def _vocab_cap(cfg):
    """The refusal threshold, product-governable: `qc.vocab_distinct_cap` in the pack's config
    wins over the platform default, so a product with a legitimately wide vocabulary DECLARES
    that in its own reviewed file instead of anyone editing a code constant."""
    try:
        return int(dict(cfg.raw.get("qc") or {}).get("vocab_distinct_cap", VOCAB_DISTINCT_CAP))
    except Exception: # noqa: BLE001 - a stub cfg with no raw has declared nothing
        return VOCAB_DISTINCT_CAP


def _collect_vocab(df, physical_col, F, label, cap=VOCAB_DISTINCT_CAP):
    rows = (df.select(F.col(physical_col)).distinct()
.limit(cap + 1).collect())
    if len(rows) > cap:
        raise ValueError(
            f"{label}: more than {cap} distinct values - a controlled vocabulary "
            f"this wide is almost certainly a misbound column, and collecting it to the driver "
            f"is how a QC check becomes an outage. Nothing was truncated silently; rebind the "
            f"column or declare qc.vocab_distinct_cap in the product config deliberately.")
    return {str(r[0]).strip().lower() for r in rows if r[0] is not None}


def run_source_qc(spark, cfg, pins=None) -> dict:
    """Pre-build QC on raw sources: mortality granularity, duplicate-conflict counts, and the
    VOCABULARY the derivations branch on (`source_expectations`) checked against what the feed
    actually spells. Verdict material only: the missing values named here are the CONFIG's own
    strings; what the feed holds beyond them is a count, never a value."""
    from pyspark.sql import functions as F

    report = {}
    vocab = {}
    for topic, exp in source_expectations(cfg).items():
        entry = {"declared_in": exp["declared_in"], "expected": len(exp["expected"])}
        try:
            observed = _distinct_lower(spark, cfg, exp["source"], exp["column"], pins=pins)
            wanted = {e.lower(): e for e in exp["expected"]}
            entry["missing_expected"] = sorted(wanted[k] for k in wanted if k not in observed)
            entry["found"] = len(wanted) - len(entry["missing_expected"])
            entry["unexpected_count"] = len(observed - set(wanted))
        except Exception as e: # noqa: BLE001 — a diagnostic may not die of what it diagnoses
            entry["error"] = str(e)
        vocab[topic] = entry
    if vocab:
        report["vocabulary"] = vocab
    try:
        from functools import reduce
        # Read mortality the SAME way sources.load does — union all member schemas (so it works under a
        # source_union where run.source_schema is unused), lower-case, then apply any format renames —
        # so the engine sees the same rows the build will, not a placeholder-schema lookup via cfg.table.
        from.stages import sources as _sources
        mort = reduce(lambda a, b: a.unionByName(b, allowMissingColumns=True),
                      [_sources._read(spark, f, pins) for f in cfg.source_fqns("mortality")])
        for c in mort.columns:
            if c != c.lower():
                mort = mort.withColumnRenamed(c, c.lower())
        from.config import canonical_physical # noqa: PLC0415
        for canonical, phys in (canonical_physical(cfg, "mortality") or {}).items():
            if phys in mort.columns and phys != canonical:
                mort = mort.withColumnRenamed(phys, canonical)
        dod = F.col("dateofdeath").cast("string")
        report["mortality_granularity"] = {
            str(r["len"]): r["n"] for r in
            mort.groupBy(F.length(dod).alias("len")).agg(F.count(F.lit(1)).alias("n")).collect()}
        dups = (mort.groupBy("patientid").agg(F.countDistinct("dateofdeath").alias("d"))
.filter(F.col("d") > 1).count())
        report["patients_with_conflicting_death_dates"] = dups
    except Exception as e: # noqa: BLE001
        report["mortality_qc_error"] = str(e)
    # WHAT THE REVIEWED CAST THREW AWAY. Preflight compares the delivered TYPE against what the
    # adapter accepts; nothing measured the VALUES, so a string column bound as integer, or a date
    # delivered in a shape the named parser does not read, became null for the rows that failed and
    # the column read as legitimately empty. One fused aggregate per bound source — see
    # `sources.plan_parse_loss` — and the gate refuses a total loss, which is never legitimate.
    # `getattr`, because this function accepts any object exposing the handful of attributes it
    # reads — the Spark stage tests pass a small stand-in with no adapter surface at all. A cfg
    # that cannot describe an adapter has made no adapter claim, which is "no claim".
    plans = {n: c for n, c in (getattr(cfg, "adapter_columns", None) or {}).items() if c}
    if plans:
        try:
            from.stages import sources as _sources_p
            frames = _sources_p.load(spark, cfg, pins)
            loss = {}
            for name, cols in sorted(plans.items()):
                if name in frames:
                    got = _sources_p.plan_parse_loss(F, frames[name], cols)
                    if got:
                        loss[name] = got
            if loss:
                report["adapter_parse_loss"] = loss
        except Exception as e: # noqa: BLE001 — a diagnostic may not die of what it diagnoses
            report["adapter_parse_loss_error"] = str(e)
    # PATIENT LINKAGE — the audit's "sources are assumed to share patientid", measured:
    # orphans a join silently drops, spine coverage, fan-out, null keys. Counts ride the
    # report on every run; the gate holds them only where the pack has declared tolerances
    # (qc.source_thresholds.linkage). `getattr` guards the stub-cfg callers: a cfg that names
    # no index source has made no linkage claim, and the report says so rather than raising.
    if getattr(cfg, "index_source", None):
        try:
            from. import linkage as _linkage # noqa: PLC0415
            from.stages import sources as _sources_l # noqa: PLC0415
            report["linkage"] = _linkage.linkage_report(
                F, _sources_l.load(spark, cfg, pins), cfg)
        except Exception as e: # noqa: BLE001 — the gate refuses this when tolerances are declared
            report["linkage_error"] = str(e)
    return report


def source_qc_evidence(cfg, report: dict, gate: dict, generated_at=None, git_commit=None) -> dict:
    """Wrap run_source_qc() + its gate into a machine-readable evidence object — the stable input
    `source_check --preflight` folds into a pack's committed verdict report. Verdict material only:
    the values named are the CONFIG's own strings; everything vendor-observed is a count. Pure data;
    the runner supplies generated_at + git_commit (this module imports no clock/git)."""
    return {
        "kind": "source_qc",
        "result": "passed_live" if gate.get("passed") else "failed_live",
        "data_product_id": cfg.data_product_id,
        "spec_version": cfg.spec_version,
        "data_refresh": cfg.refresh,
        "source_schema": cfg.source_schema,
        "git_commit": git_commit,
        "generated_at": generated_at,
        "report": report,
        "gate": gate,
    }


# --- QC gate: turn a run_qc() report into a pass/fail decision (pure Python) -----------------
DEFAULT_THRESHOLDS = {
    "min_rows": 1, # the ADS must not be empty
    "max_catchall_rate": 0.50, # >50% of lines hitting "Any other therapy" = taxonomy gap
    "max_stage_check_rate": 0.05, # >5% stage == 'CHECK' = unmapped staging values
    "max_uncastable_date_rate": 0.01, # date columns should be ~fully castable
    # None = REPORT-ONLY: every chronology count is in the report on every run, but none
    # refuses a build until the pack states its tolerance - an unset threshold is not a
    # licence, it is a pack that has not stated one (the adapter parse-loss precedent).
    "max_chronology_violations": None,
}


def qc_thresholds(cfg) -> dict:
    """Merge the framework defaults with an optional per-tumor `qc:` block in config."""
    t = dict(DEFAULT_THRESHOLDS)
    t.update((cfg.raw.get("qc") or {}).get("thresholds", {}) if cfg is not None else {})
    return t


# which qc thresholds are RATES (bounded [0, 1]); the rest are counts (finite, >= 0)
RATE_THRESHOLDS = ("max_catchall_rate", "max_stage_check_rate", "max_uncastable_date_rate")


def _screen_thresholds(t, failures, prefix, rates, defaults):
    """Name every unusable tolerance and put the framework default back in its place.

    an earlier review's probes: a string raised TypeError out of the gate, NaN waved
    ~99% parse loss through, and a rate of 2 permitted total loss. Fail-closed twice over —
    the named failure keeps the gate red, and the restored default still gates instead of
    the vacuous comparison an invalid override would have bought."""
    from engine.linkage import bad_threshold # noqa: PLC0415
    for k in sorted(t):
        if isinstance(t[k], dict):
            continue # nested blocks are validated by their own gate
        why = bad_threshold(f"{prefix}{k}", t[k], rate=k in rates)
        if why:
            failures.append(why)
            t[k] = defaults.get(k)
    return t


def qc_gate(report: dict, thresholds: dict | None = None) -> dict:
    """Evaluate a run_qc() report against thresholds. Returns {passed, failures}. Pure data."""
    t = dict(thresholds or DEFAULT_THRESHOLDS)
    failures = []
    t = _screen_thresholds(t, failures, "qc.thresholds.", RATE_THRESHOLDS,
                           DEFAULT_THRESHOLDS)
    if report.get("n_rows", 0) < t["min_rows"]:
        failures.append(f"n_rows {report.get('n_rows', 0)} < min_rows {t['min_rows']}")
    for col, rate in (report.get("catchall_rate") or {}).items():
        if rate is not None and rate > t["max_catchall_rate"]:
            failures.append(f"{col} catch-all rate {rate} > {t['max_catchall_rate']}")
    scr = report.get("stage_check_rate")
    if scr is not None and scr > t["max_stage_check_rate"]:
        lbl = report.get("stage_check_label") or "unmapped-stage" # the derived fallthrough label, not 'CHECK'
        failures.append(f"stage {lbl!r} rate {scr} > {t['max_stage_check_rate']}")
    for col, rate in (report.get("uncastable_date_rate") or {}).items():
        if rate > t["max_uncastable_date_rate"]:
            failures.append(f"{col} uncastable-date rate {rate} > {t['max_uncastable_date_rate']}")
    acc = report.get("acceptance") or {}
    failures.extend(acc.get("declaration_errors") or [])
    for u in (acc.get("unmeasured") or []):
        failures.append(f"declared acceptance criterion not measurable - {u}; a claim "
                        f"the run cannot test must fail, not pass silently")
    nr = report.get("null_rate") or {}
    for c, lim in sorted((acc.get("null_limits") or {}).items()):
        rate = nr.get(c, 0.0)
        if rate > lim:
            failures.append(f"{c} null rate {rate} > declared null_limit {lim}")
    for c, neg in sorted((acc.get("nonnegative_negative_rows") or {}).items()):
        if neg:
            failures.append(f"{c}: {neg} negative value(s) in a column the pack declared "
                            f"nonnegative")
    for pair, cnt in sorted((acc.get("event_missing_date") or {}).items()):
        if cnt:
            failures.append(f"{pair}: {cnt} row(s) flag the event and carry no date - the "
                            f"pack declared the pair consistent")
    mcv = t.get("max_chronology_violations")
    if mcv is not None:
        for rule, cnt in sorted((report.get("chronology") or {}).items()):
            if cnt > mcv:
                failures.append(f"chronology {rule}: {cnt} row(s) > "
                                f"max_chronology_violations {mcv}")
    return {"passed": not failures, "failures": failures}


def source_qc_gate(source_report: dict, thresholds: dict | None = None) -> dict:
    """Gate the PRE-BUILD source QC (run_source_qc). Fails on an unreadable mortality source, or on
    more than `max_death_conflicts` patients with conflicting death dates (None = don't gate on it,
    since the engine dedupes deterministically — but a real read error always fails)."""
    t = {"max_death_conflicts": None, "max_missing_expected": 0,
         "max_parse_loss_rate": None, "linkage": None, **(thresholds or {})}
    failures = []
    t = _screen_thresholds(t, failures, "qc.source_thresholds.", ("max_parse_loss_rate",),
                           {"max_missing_expected": 0})
    # PATIENT LINKAGE, same grammar as everything here: report-only until the pack declares
    # qc.source_thresholds.linkage, then held per source by name — and a DECLARED tolerance
    # the run could not measure fails (a linkage_error under a declaration is a claim nobody
    # tested, never a pass; undeclared, the error stays visible in the report and gates nothing).
    from. import linkage as _linkage # noqa: PLC0415
    if source_report.get("linkage_error") and _linkage.declared(t.get("linkage")):
        failures.append("linkage tolerances are declared and linkage was not measurable: "
                        + source_report["linkage_error"])
    elif "linkage" in source_report or _linkage.declared(t.get("linkage")):
        failures.extend(_linkage.linkage_gate(source_report.get("linkage") or {},
                                              t.get("linkage"))["failures"])
    if source_report.get("mortality_qc_error"):
        failures.append("mortality source not readable: " + source_report["mortality_qc_error"])
    mc = source_report.get("patients_with_conflicting_death_dates")
    if t["max_death_conflicts"] is not None and mc is not None and mc > t["max_death_conflicts"]:
        failures.append(f"{mc} patients with conflicting death dates > {t['max_death_conflicts']}")
    # VOCABULARY, fail-closed by default: a configured value the feed does not spell is a derivation
    # that will silently match nothing — empty column, not error — so it stops the build here, where
    # the fix is one config edit, rather than surfacing as an inexplicable Unknown downstream. An
    # unreadable expectation is a failure outright, like the mortality read error above.
    for topic, entry in sorted((source_report.get("vocabulary") or {}).items()):
        if entry.get("error"):
            failures.append(f"{topic}: expectation not checkable — {entry['error']}")
            continue
        missing = entry.get("missing_expected") or []
        if t["max_missing_expected"] is not None and len(missing) > t["max_missing_expected"]:
            failures.append(f"{topic}: {len(missing)} configured value(s) the feed does not spell "
                            f"({', '.join(missing[:6])}{'…' if len(missing) > 6 else ''}) — see "
                            f"{entry.get('declared_in')}")
    # THE REVIEWED CAST, held to what it produced. A TOTAL loss is refused with no threshold to
    # configure: a bound column where every delivered value became null is a wrong type or a wrong
    # parser, never a tolerance question, and it is the shape that reads downstream as a column the
    # feed simply does not populate. Anything short of total is REPORTED, and a pack that knows its
    # own tolerance sets `max_parse_loss_rate` — an unset threshold is not a licence, it is a pack
    # that has not stated one, so the number is in the report either way.
    if source_report.get("adapter_parse_loss_error"):
        failures.append("adapter parse loss not measurable: "
                        + source_report["adapter_parse_loss_error"])
    for name, cols in sorted((source_report.get("adapter_parse_loss") or {}).items()):
        for col, m in sorted((cols or {}).items()):
            rate, delivered, lost = m.get("rate"), m.get("delivered"), m.get("lost")
            if rate is None or not delivered:
                continue
            if lost >= delivered:
                failures.append(
                    f"{name}.{col}: the reviewed binding nulled ALL {delivered} delivered "
                    f"value(s) — the declared type or parser does not read this delivery, and the "
                    f"column would publish as legitimately empty")
            elif t["max_parse_loss_rate"] is not None and rate > t["max_parse_loss_rate"]:
                failures.append(
                    f"{name}.{col}: the reviewed binding nulled {lost}/{delivered} delivered "
                    f"value(s) ({rate:.1%}) > max_parse_loss_rate {t['max_parse_loss_rate']}")
    return {"passed": not failures, "failures": failures}
