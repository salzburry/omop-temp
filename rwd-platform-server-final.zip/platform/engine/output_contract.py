"""The ADS OUTPUT CONTRACT — what a built product must be true of before anyone publishes it.

`run_qc` reports distributions. This asks the different question: is the thing we built even the
SHAPE we promised? An external review put it plainly — the QC gate as it stood could pass a
duplicated, incomplete or nearly empty product, because it checked four rates and never checked
what the rows ARE.

    contract_spec(cfg)                  the plan. Pure data, no Spark, unit-tested.
    run_output_contract(spark, ads, cfg) executes it on a built ADS. Cluster only.
    output_contract_gate(report, ...)   pass/fail. Pure data.

Same three-part split as `qc.py`, for the same reason: the plan is the part that can be reasoned
about without a cluster, and the part most likely to be wrong.

WHY `assemble.build` ENDING IN `.distinct()` WAS NOT THIS CHECK. A full-row distinct collapses rows
that are identical in EVERY column. It does nothing about the failure that matters — two rows for
one patient in one cohort at one index date that DISAGREE, which is precisely the shape a bad join
or a non-deterministic tie-break produces. Those survive `distinct()` untouched, and the row count
looks plausible either way. The key check below is what `distinct()` was standing in for.

TWO CLASSES OF CHECK, and the difference is the honest part.

  DERIVED     needs nothing declared, because the config or the engine already states the answer:
              the output key, the cohorts the build was told to produce, the labels a codelist
              compiles to. These are UNCONDITIONAL and fail closed. A pack cannot opt out of them
              by staying silent, which is the only way a default can be trusted.

  DECLARED    needs a `qc:` block, because only the approved specification knows the answer: which
              columns may be null and how often, which flag pairs with which date, which intervals
              must not run backwards. The engine REFUSES TO GUESS these — a guessed null limit that
              happens to pass is worse than no limit, because it reports as a check.

NO PACK DECLARES A `qc:` BLOCK TODAY. That is exactly why every declared check reports how many
rules it was given, and why `unconfigured` comes back beside `failures`: a gate that returned a
bare `passed: True` over zero configured rules would be the absence-reported-as-a-clean-result
failure this repository has closed in seven other tools, installed at the last step before publish.

AND WHY `strict` IS OPT-IN. Making vacuity fail immediately would redden all twelve committed packs
on their first build, and a gate that does that is switched off rather than read — the lesson from
the band-coverage and duplicate-name checks. `qc.output_contract_strict: true` turns unconfigured
checks into failures for a pack that has done the declaring. The derived checks never wait for it.

THE PUBLISHED-COLUMN QUESTION IS DELIBERATELY NOT HERE. "Does the ADS carry every column the
approved contract publishes" is already answered by `contract_binding.published_surface_errors`,
which reads the contract. The engine must not import `platform/tools`, and a second implementation
reading a config-side copy of the surface would drift from the contract-side one silently. One
owner per question.
"""
from __future__ import annotations

# THE GRAIN OF THE PUBLISHED PRODUCT. `assemble.build` joins on (patientid, index_date) and then
# stamps the cohort, and `build_ads` unions the cohorts — so one row is one patient, in one cohort,
# at one index date, and anything else is a defect regardless of which stage produced it.
#
# `cohortn` and not `cohort`: the numeric code is what the label is derived from, both are stamped
# from the same config entry, and keying on the code survives a label being re-worded. A pack that
# emits one and not the other is caught by the missing-column arm rather than silently keyed on
# whatever is left.
OUTPUT_KEY = ("patientid", "cohortn", "index_date")

# ...AND THE TYPES THOSE KEY COLUMNS MUST HAVE, because a contract that checks NAMES is a contract
# a drifted build passes. `cohortn` delivered as a string still groups, still dedupes and still
# publishes — and then sorts "10" before "9", joins to nothing on the numeric side, and reads as a
# different column to every consumer downstream. `index_date` as a timestamp compares unequal to
# every date it should equal. Neither is visible to a name check, and both survive every row-level
# predicate in this module.
#
# A FLOOR, NOT A SCHEMA. Only the three key columns are typed here, and each from what the build
# itself stamps: `assemble.build` writes `cohortn` from a YAML integer (`F.lit(cohort["cohortn"])`),
# joins on a real `index_date`, and carries `patientid` through as delivered. Families rather than
# exact names, because an integer key is an integer key whether Spark calls it int or bigint. The
# general question — every published column's type — belongs to a declared `qc.column_types` map,
# which is checked below where a pack states one and reported as unasked where it does not.
KEY_TYPES = {"patientid": ("string",),
             "cohortn": ("tinyint", "smallint", "int", "bigint"),
             "index_date": ("date",)}

# ...AND THE NARROWER QUESTION THE OUTPUT KEY CANNOT ASK. `OUTPUT_KEY` proves no two rows share a
# patient, cohort AND index date. It says nothing about one patient appearing TWICE in one cohort
# with two different index dates, which is a different defect and a worse one: cohort membership is
# what every count, rate and denominator in the product is computed over, so a patient counted twice
# inflates every one of them while the output key stays perfectly unique.
#
# One patient belongs to a cohort once. A second index date for them means the index rule produced
# two answers and nothing chose between them.
MEMBERSHIP_KEY = ("patientid", "cohortn")


def type_family(value):
    """Comparable Spark type family, including the adapter's logical spellings.

    integer/int and long/bigint are the same executed type. Widths and distinct
    families remain distinct: float is not double and decimal is not double.
    Precision retains this gate's existing family-level comparison.
    """
    base = str(value or "").split("(", 1)[0].strip().lower()
    return {"integer": "int", "long": "bigint", "bool": "boolean"}.get(base, base)


def _codelist_labels(cfg, name):
    """Every label a codelist compiles to, or None when the codelist is not declared.

    None is NOT an empty set: "this pack declares no such codelist" and "this codelist enumerates
    nothing" are different facts, and collapsing them is how a vocabulary check comes to compare a
    column against {} and report every value as a violation.
    """
    try:
        cats = cfg.codelist(name).get("categories", [])
    except Exception:  # noqa: BLE001 - no such codelist on this pack -> nothing to compare
        return None
    labels = {c.get("label") for c in cats if c.get("label") is not None}
    return labels or None


def _line_category_vocabulary(cfg):
    """{column: {allowed labels}} for the per-line treatment category columns.

    DERIVED, not declared: the engine compiles `line_category_codelist` into `lot{i}cat`, so the set
    of labels that column may legally hold is already stated in the config the build reads. A pack
    that declares no line-category codelist gets no entry, and the check reports that rather than
    passing a column it could not constrain.
    """
    try:
        max_lines = int((cfg.pack("treatment") or {}).get("max_lines", 6))
        name = (cfg.pack("treatment") or {}).get("line_category_codelist")
    except Exception:  # noqa: BLE001 - no treatment pack -> no line categories to constrain
        return {}
    if not name:
        return {}
    labels = _codelist_labels(cfg, name)
    if not labels:
        return {}
    out = {f"lot{i}cat": set(labels) for i in range(1, max_lines + 1)}
    # The cohort-indexed alias assemble.build copies from this line's column carries the same
    # vocabulary; omitting it would leave the one category column a TFL reads unconstrained.
    out["lotcat"] = set(labels)
    return out


def _stage_vocabulary(cfg):
    """{stage: {allowed labels}} from the staging groups, including the fallthrough label."""
    try:
        groups = (cfg.pack("clinical").get("staging") or {}).get("groups") or []
    except Exception:  # noqa: BLE001 - no clinical pack / no staging -> nothing to constrain
        return {}
    labels = {g.get("label") for g in groups if g.get("label") is not None}
    return {"stage": labels} if labels else {}


def _declared(cfg, key, default):
    """A `qc:` sub-block, or its default. One reader, so a missing `qc:` cannot mean different
    things to different checks."""
    if cfg is None:
        return default
    try:
        return (cfg.raw.get("qc") or {}).get(key, default)
    except Exception:  # noqa: BLE001 - a config with no raw mapping declares nothing
        return default


def contract_spec(cfg) -> dict:
    """The output-contract plan, derived from config. Pure data, no Spark.

    Every entry says where it came from, because `derived` and `declared` fail differently: a
    derived check that finds nothing to compare means the pack declares no codelist, while a
    declared one that finds nothing means nobody has written the rule down yet.
    """
    cohorts = []
    try:
        for c in (cfg.cohorts or []):
            if c.get("label") is not None:
                cohorts.append({"label": c.get("label"), "cohortn": c.get("cohortn")})
        # DERIVED COHORTS COUNT AS COHORTS. A pack that emits one (OC's PROC cohortn 9) stamps a
        # label and a code the same way, so leaving them out of the expected pairs would make the
        # code/label check below — and the existing `cohorts_unexpected` arm — fail a correct
        # build for producing exactly what it was configured to produce.
        for dc in (cfg.raw.get("derived_cohorts") or []):
            if isinstance(dc, dict) and dc.get("label") is not None:
                cohorts.append({"label": dc.get("label"), "cohortn": dc.get("cohortn")})
    except Exception:  # noqa: BLE001 - a config with no cohorts produces no completeness check
        cohorts = []

    vocabulary = {}
    vocabulary.update(_line_category_vocabulary(cfg))
    vocabulary.update(_stage_vocabulary(cfg))

    return {
        "key": list(OUTPUT_KEY),
        # DERIVED — the build was told to produce exactly these.
        "cohorts_expected": cohorts,
        "allow_empty_cohorts": list(_declared(cfg, "allow_empty_cohorts", []) or []),
        "vocabulary": {k: sorted(v) for k, v in vocabulary.items()},
        # DECLARED — only the approved specification knows these.
        "null_limits": dict(_declared(cfg, "null_limits", {}) or {}),
        "flag_date_pairs": list(_declared(cfg, "flag_date_pairs", []) or []),
        "date_order": list(_declared(cfg, "date_order", []) or []),
        "nonnegative": list(_declared(cfg, "nonnegative", []) or []),
        # DECLARED — the general type question the key floor above cannot ask. Only the approved
        # specification knows what `os_months` or `dth_flag` must be; where a pack declares none
        # the columns come back under `skipped`, never as a pass.
        "column_types": {str(k).lower(): str(v).lower()
                         for k, v in (_declared(cfg, "column_types", {}) or {}).items()},
        "strict": bool(_declared(cfg, "output_contract_strict", False)),
        # DECLARED — a human's per-rule exemption with its reason; strict mode fails any
        # skipped rule this mapping does not carry.
        "not_applicable": dict(_declared(cfg, "not_applicable", {}) or {}),
        # DECLARED — the PUBLISH SURFACE. `publish_columns` is the approved ORDERED column
        # whitelist (NAME-ALIGN's "the final ADS must be an approved ordered column whitelist"):
        # in strict mode the ADS must carry exactly these, in this order — an internal helper
        # column shipping is the failure this exists for. `never_publish` is the privacy floor:
        # columns that must not appear in any published ADS, judged in EVERY mode, because a
        # privacy rule that only strict runs enforce is a privacy rule the first casual run
        # violates.
        "publish_columns": [str(c) for c in (_declared(cfg, "publish_columns", []) or [])],
        "never_publish": [str(c) for c in (_declared(cfg, "never_publish", []) or [])],
    }


def run_output_contract(spark, ads, cfg) -> dict:
    """Execute the plan against a built ADS. Returns a report dict; writes nothing.

    THREE ACTIONS, not one per rule. Every row-level predicate — nulls, flag/date agreement, date
    order, negative durations, out-of-vocabulary values — is folded into ONE scalar aggregation,
    because they are all `sum(when(...))` over the same scan and issuing them separately is the
    avoidable-action pattern the same review flagged. The other two are irreducible: a duplicate
    key needs a groupBy over the key, and cohort presence needs a groupBy over the cohort.
    """
    from pyspark.sql import functions as F

    spec = contract_spec(cfg)
    cols = set(ads.columns)
    # `not_applicable` EMBEDDED beside `strict`, so a caller holding only the report still runs
    # the complete strict machinery — a caller holding only the report once ran the gate
    # report-only, which silently dropped the skipped-rule failures on the one path that matters.
    report = {"key": spec["key"], "strict": spec["strict"],
              "not_applicable": dict(spec["not_applicable"]),
              "compared": {}, "skipped": {}}

    # --- 0. TYPES (schema only, no Spark action — `dtypes` is metadata). ---------------------
    types = {n.lower(): t.lower() for n, t in ads.dtypes}
    report["column_types"] = types

    # The DERIVED floor: the three key columns, typed from what the build itself stamps.
    report["key_type_mismatches"] = [
        {"column": c, "expected": list(want), "actual": types[c]}
        for c, want in sorted(KEY_TYPES.items())
        if c in types and type_family(types[c]) not in want]
    # ...and the DECLARED map, where a pack states one. Absent columns are reported as skipped —
    # an unasked question is not a pass, which is the rule the rest of this module runs on.
    declared_types = {c: t for c, t in (spec["column_types"] or {}).items() if c in types}
    report["type_mismatches"] = [
        {"column": c, "expected": t, "actual": types[c]}
        for c, t in sorted(declared_types.items()) if type_family(types[c]) != type_family(t)]
    report["compared"]["column_types"] = len(declared_types)
    if len(declared_types) < len(spec["column_types"] or {}):
        report["skipped"]["column_types"] = sorted(set(spec["column_types"]) - set(declared_types))

    # --- 0. THE PUBLISH SURFACE (schema only, no Spark action). ------------------------------
    pub = [c.lower() for c in spec["publish_columns"]]
    never = [c.lower() for c in spec["never_publish"]]
    actual = [c.lower() for c in ads.columns]
    report["publish"] = {"declared": bool(pub)}
    if pub:
        report["publish"]["extra"] = sorted(set(actual) - set(pub))
        report["publish"]["missing"] = sorted(set(pub) - set(actual))
        # order over the columns both sides carry, so a missing column reports once, not twice
        report["publish"]["order_differs"] = (
            [c for c in actual if c in set(pub)] != [c for c in pub if c in set(actual)])
    if never:
        report["publish"]["never_publish_present"] = sorted(set(never) & set(actual))

    # --- 1. GRAIN. The check `.distinct()` was standing in for. ------------------------------
    missing = [c for c in spec["key"] if c not in cols]
    report["key_missing_columns"] = missing
    if missing:
        # Not a skip. An ADS that cannot be keyed is a failed build, and calling this "unchecked"
        # would let the most broken possible output through the quietest possible path.
        report["duplicate_keys"] = None
    else:
        dupes = ads.groupBy(*spec["key"]).agg(F.count(F.lit(1)).alias("_n")).filter(F.col("_n") > 1)
        agg = dupes.agg(F.count(F.lit(1)).alias("groups"),
                        F.coalesce(F.sum("_n"), F.lit(0)).alias("rows")).collect()[0]
        report["duplicate_keys"] = int(agg["groups"])
        report["duplicate_key_rows"] = int(agg["rows"])

        # MEMBERSHIP, the narrower question. Same scan shape, different key.
        mk = [c for c in MEMBERSHIP_KEY if c in cols]
        if len(mk) == len(MEMBERSHIP_KEY):
            mdup = ads.groupBy(*mk).agg(F.count(F.lit(1)).alias("_n")).filter(F.col("_n") > 1)
            magg = mdup.agg(F.count(F.lit(1)).alias("groups"),
                            F.coalesce(F.sum("_n"), F.lit(0)).alias("rows")).collect()[0]
            report["membership_key"] = list(MEMBERSHIP_KEY)
            report["duplicate_membership"] = int(magg["groups"])
            report["duplicate_membership_rows"] = int(magg["rows"])

    # --- 2. COHORT COMPLETENESS. A cohort the build was told to produce and did not. ----------
    expected = [c["label"] for c in spec["cohorts_expected"]]
    allow_empty = set(spec["allow_empty_cohorts"] or ())
    if expected and "cohort" in cols:
        # BOTH COLUMNS IN THE ONE DISTINCT, because the label alone cannot answer the question the
        # key is built on. `cohortn` is what `OUTPUT_KEY` dedupes by and what every downstream join
        # matches; the label is what a reader sees. A build that stamps the right labels against
        # swapped codes passes a label-only check, dedupes correctly, publishes correctly-worded
        # rows — and every numeric consumer reads a different cohort than the text does. One
        # distinct over two columns is the same single Spark action the label-only version cost.
        if "cohortn" in cols:
            pairs = {(r["cohort"], r["cohortn"])
                     for r in ads.select("cohort", "cohortn").distinct().collect()}
            seen = {lbl for lbl, _ in pairs}
            by_code = {c["cohortn"]: c["label"] for c in spec["cohorts_expected"]
                       if c.get("cohortn") is not None}
            by_label = {c["label"]: c["cohortn"] for c in spec["cohorts_expected"]
                        if c.get("cohortn") is not None}
            report["cohort_code_mismatches"] = sorted(
                ({"cohortn": n, "label": lbl,
                  "expected_label": by_code.get(n), "expected_cohortn": by_label.get(lbl)}
                 for lbl, n in pairs
                 if (n in by_code and lbl != by_code[n])
                 or (lbl in by_label and n != by_label[lbl])),
                key=lambda d: (str(d["cohortn"]), str(d["label"])))
        else:
            pairs = None
            seen = {r["cohort"] for r in ads.select("cohort").distinct().collect()}
        report["cohorts_expected"] = expected
        # ALLOW_EMPTY_COHORTS IS APPLIED HERE, which it was not. It was parsed into the spec, named
        # in the failure message as the thing to declare, and then never read — so a pack that did
        # declare one still failed, and the message told it to do the thing it had already done.
        report["cohorts_missing"] = [c for c in expected if c not in seen and c not in allow_empty]
        report["cohorts_allowed_empty"] = sorted(c for c in expected
                                                 if c not in seen and c in allow_empty)
        report["cohorts_unexpected"] = sorted(str(s) for s in seen if s not in set(expected))
        # A DECLARATION THAT MATCHES NO CONFIGURED COHORT is a typo that silently exempts nothing,
        # or worse exempts something that has since been renamed. Reported, never ignored.
        report["allow_empty_unknown"] = sorted(allow_empty - set(expected))
    elif not expected:
        report["skipped"]["cohorts"] = "no cohorts declared in config"
    else:
        # NOT A SKIP. An ADS with no `cohort` column cannot be split, summarised, or published per
        # cohort — every cohort the build was configured to produce is absent from it. Reporting
        # this as "unconfigured" let the most broken shape available leave by the quietest path,
        # which is the fail-open an external review found.
        report["cohort_column_missing"] = True
        report["cohorts_expected"] = expected
        report["cohorts_missing"] = [c for c in expected if c not in allow_empty]

    # --- 3. EVERY ROW-LEVEL PREDICATE, IN ONE SCAN. -------------------------------------------
    exprs, plan = [F.count(F.lit(1)).alias("_n")], []

    def _add(name, condition):
        exprs.append(F.sum(F.when(condition, 1).otherwise(0)).alias(name))
        plan.append(name)

    # THE KEY, NOT NULL — DERIVED, unconditional, and nothing declares it because nothing needs
    # to. The duplicate-key check groups by the key and reports how many groups hold more than one
    # row; a NULL key column makes every such row one group, so uniqueness says nothing about them.
    # And a row whose patientid, cohortn or index_date is null identifies no patient, no cohort and
    # no index — it is in the published product and cannot be attributed to anything in it.
    # The counter is named `keynull__` on purpose: `violations` drops anything starting `null__`
    # (nulls are judged as a rate there), so a `null__` name here would be computed and discarded.
    key_cols = [c for c in spec["key"] if c in cols]
    for c in key_cols:
        _add(f"keynull__{c}", F.col(c).isNull())

    nl = {c: r for c, r in (spec["null_limits"] or {}).items() if c in cols}
    for c in sorted(nl):
        _add(f"null__{c}", F.col(c).isNull())
    report["compared"]["null_limits"] = len(nl)
    if len(nl) < len(spec["null_limits"] or {}):
        report["skipped"]["null_limits"] = sorted(set(spec["null_limits"]) - set(nl))

    fdp = [p for p in spec["flag_date_pairs"]
           if p.get("flag") in cols and p.get("date") in cols]
    for p in fdp:
        f, d = p["flag"], p["date"]
        # BOTH directions. A flag set with no date and a date with no flag are different defects,
        # and a check that summed them into one number could not tell a reviewer which happened.
        _add(f"flagnodate__{f}__{d}", F.col(f).isNotNull() & (F.col(f) != 0) & F.col(d).isNull())
        _add(f"datenoflag__{f}__{d}", F.col(d).isNotNull() & (F.col(f).isNull() | (F.col(f) == 0)))
    report["compared"]["flag_date_pairs"] = len(fdp)
    if len(fdp) < len(spec["flag_date_pairs"]):
        report["skipped"]["flag_date_pairs"] = "pair(s) naming a column the ADS does not carry"

    do = [p for p in spec["date_order"] if p.get("start") in cols and p.get("end") in cols]
    for p in do:
        s, e = p["start"], p["end"]
        _add(f"dateorder__{s}__{e}",
             F.col(s).isNotNull() & F.col(e).isNotNull() & (F.col(s) > F.col(e)))
    report["compared"]["date_order"] = len(do)
    if len(do) < len(spec["date_order"]):
        report["skipped"]["date_order"] = "pair(s) naming a column the ADS does not carry"

    nn = [c for c in spec["nonnegative"] if c in cols]
    for c in nn:
        _add(f"negative__{c}", F.col(c).isNotNull() & (F.col(c) < 0))
    report["compared"]["nonnegative"] = len(nn)
    if len(nn) < len(spec["nonnegative"]):
        report["skipped"]["nonnegative"] = sorted(set(spec["nonnegative"]) - set(nn))

    vocab = {c: v for c, v in (spec["vocabulary"] or {}).items() if c in cols}
    for c in sorted(vocab):
        # NULL IS NOT AN OUT-OF-VOCABULARY VALUE. A patient with no line 3 has a null `lot3cat`,
        # and counting that as a violation would make the check fire hardest on the packs with the
        # least treatment data — a finding everyone learns to ignore. Null-ness is the null_limits
        # question, and it is asked separately and on purpose.
        _add(f"vocab__{c}", F.col(c).isNotNull() & ~F.col(c).isin(list(vocab[c])))
    report["compared"]["vocabulary"] = len(vocab)
    if len(vocab) < len(spec["vocabulary"] or {}):
        report["skipped"]["vocabulary"] = sorted(set(spec["vocabulary"]) - set(vocab))

    row = ads.agg(*exprs).collect()[0]
    n = int(row["_n"])
    report["n_rows"] = n
    counts = {name: int(row[name] or 0) for name in plan}
    # NULLS ARE JUDGED AS A RATE, NOT A COUNT, so they are deliberately kept out of `violations`:
    # a column with a declared allowance of 0.2 must not fail the build for holding one null.
    report["violations"] = {k: v for k, v in counts.items()
                           if v and not k.startswith(("null__", "keynull__"))}
    # Reported as its own key rather than through `violations`, so the gate can word it as the
    # structural failure it is instead of "keynull__patientid: 3".
    report["key_nulls"] = {c: counts.get(f"keynull__{c}", 0) for c in key_cols}
    report["null_rate"] = {c: (counts.get(f"null__{c}", 0) / n if n else None) for c in nl}
    report["null_limits"] = dict(nl)
    return report


def publication_surface_gate(publish: dict | None, release_grade=None) -> dict:
    """THE LAST STAGE of the candidate verdict (programme item 4): is what the build would publish
    exactly the approved surface? Judged over the `publish` block `run_output_contract` reports —
    after every other stage, because the question is about the columns as they stand at the end.

    `never_publish` is the privacy floor and fails in every mode. The whitelist is held when the
    pack declares one (extras, missing, order); a RELEASE-GRADE run that declares none fails —
    without a whitelist every joined internal helper column ships under a green verdict, and the
    release validator refuses such a receipt anyway, so the job stops where the fix is one config
    edit. A dev run with no whitelist returns {} (not evaluated), never a pass.
    """
    pub = publish or {}
    failures = []
    present = pub.get("never_publish_present") or []
    if present:
        failures.append(f"never_publish column(s) present in the output: {', '.join(present)}")
    if not pub.get("declared"):
        if release_grade:
            failures.append("the publish whitelist (qc.publish_columns) is not declared — a release-grade "
                            "candidate publishes an approved, ordered surface or nothing")
        elif not failures:
            return {}
        return {"passed": not failures, "declared": False, "failures": failures}
    for key, what in (("extra", "column(s) not on the approved whitelist"),
                      ("missing", "approved column(s) the output does not carry")):
        if pub.get(key):
            failures.append(f"{what}: {', '.join(pub[key])}")
    if pub.get("order_differs"):
        failures.append("the output's column order differs from the approved whitelist")
    return {"passed": not failures, "declared": True, "failures": failures}


def output_contract_gate(report: dict, spec: dict | None = None) -> dict:
    """{passed, failures, unconfigured}. Pure data — the same shape `qc_gate` returns, plus the
    third field, because "nothing was checked" is a distinct answer from "everything passed".

    `passed` is False on any failure. It is ALSO False on an unconfigured check when the pack has
    set `qc.output_contract_strict` — a pack that has done the declaring gets to insist that the
    declaring stays done.
    """
    failures, unconfigured = [], []
    strict = bool(report.get("strict"))

    # --- DERIVED: unconditional, and no pack can opt out by staying silent. -------------------
    if report.get("key_missing_columns"):
        failures.append(f"the ADS is missing output-key column(s) "
                        f"{report['key_missing_columns']} — it cannot be keyed, so uniqueness, "
                        f"cohort completeness and every per-patient claim about it are unverifiable")
    elif report.get("duplicate_keys"):
        failures.append(f"{report['duplicate_keys']} output key(s) carry more than one row "
                        f"({report.get('duplicate_key_rows', 0)} rows over "
                        f"{tuple(report.get('key', ()))}) — a full-row distinct() does not collapse "
                        f"rows that DISAGREE, and one of each conflicting pair is wrong")
    # A KEY THAT IS NULL IDENTIFIES NOTHING, and the duplicate check above cannot see it: groupBy
    # folds every null-keyed row into ONE group, so uniqueness passes precisely where attribution
    # is impossible. Derived and unconditional — nothing declares it because nothing needs to.
    for c, cnt in sorted((report.get("key_nulls") or {}).items()):
        if cnt:
            failures.append(
                f"{c}: {cnt} row(s) carry a NULL output-key column — a null key names no patient, "
                f"no cohort or no index date, and groupBy collapses them into one group, so the "
                f"uniqueness check above says nothing about these rows")

    # TYPES. The floor first: the three key columns, whose types the build itself stamps.
    for m in (report.get("key_type_mismatches") or []):
        failures.append(
            f"{m['column']}: output-key column is {m['actual']}, not {' | '.join(m['expected'])} "
            f"— a name check cannot see this, and every downstream join, sort and comparison on "
            f"this column is against a different type than the contract describes")
    # ...then whatever the pack itself declared.
    for m in (report.get("type_mismatches") or []):
        failures.append(f"{m['column']}: declared {m['expected']}, published {m['actual']}")

    if report.get("duplicate_membership"):
        failures.append(
            f"{report['duplicate_membership']} patient(s) appear more than once in one cohort "
            f"({report.get('duplicate_membership_rows', 0)} rows over "
            f"{tuple(report.get('membership_key', MEMBERSHIP_KEY))}) — the OUTPUT KEY can still be "
            f"unique here, because the rows differ by index_date. Cohort membership is what every "
            f"count, rate and denominator is computed over, so each of these patients is counted "
            f"twice: the index rule produced two answers and nothing chose between them")

    if report.get("cohort_column_missing"):
        failures.append("the ADS carries no `cohort` column — it cannot be split, summarised or "
                        "published per cohort, and every configured cohort is absent from it")
    if report.get("allow_empty_unknown"):
        failures.append(f"`qc.allow_empty_cohorts` names cohort(s) no config entry declares: "
                        f"{report['allow_empty_unknown']} — a typo there exempts nothing, or "
                        f"exempts a cohort that has since been renamed")

    missing_cohorts = [c for c in (report.get("cohorts_missing") or [])]
    if missing_cohorts:
        failures.append(f"cohort(s) the build was configured to produce are absent from the ADS: "
                        f"{missing_cohorts} — an empty cohort must be declared in "
                        f"`qc.allow_empty_cohorts`, not discovered by a reader of the counts")
    # CODE AND LABEL MUST BE THE SAME COHORT. Both are stamped from one config entry, so a
    # disagreement means the stamping is wrong — and it is invisible to every other check here: the
    # labels are all expected, the codes are all expected, the key is unique, and the numeric and
    # textual readers of the published table disagree about who is in which cohort.
    for m in (report.get("cohort_code_mismatches") or []):
        failures.append(
            f"cohortn {m['cohortn']} is published with label {m['label']!r}, but the config pairs "
            f"that code with {m['expected_label']!r}"
            + (f" and that label with cohortn {m['expected_cohortn']}"
               if m.get("expected_cohortn") is not None else "")
            + " — the code and the label name different cohorts")

    if report.get("cohorts_unexpected"):
        failures.append(f"the ADS carries cohort label(s) no config entry declares: "
                        f"{report['cohorts_unexpected']}")
    if "cohorts" in (report.get("skipped") or {}):
        unconfigured.append(f"cohort completeness: {report['skipped']['cohorts']}")

    # --- ROW-LEVEL: any non-zero violation count is a failure. --------------------------------
    for name, count in sorted((report.get("violations") or {}).items()):
        kind, _, rest = name.partition("__")
        failures.append({
            "null": lambda: f"{rest}: {count} null(s)",
            "flagnodate": lambda: f"{rest.replace('__', ' set with no ')}: {count} row(s)",
            "datenoflag": lambda: f"{rest.split('__')[1]} present with "
                                  f"{rest.split('__')[0]} unset: {count} row(s)",
            "dateorder": lambda: f"{rest.replace('__', ' > ')}: {count} row(s) run backwards",
            "negative": lambda: f"{rest}: {count} negative value(s)",
            "vocab": lambda: f"{rest}: {count} row(s) hold a value the approved codelist "
                             f"does not enumerate",
        }.get(kind, lambda: f"{name}: {count}")())

    # A null LIMIT is a rate, not a count, so it is judged after the rates are known.
    for col, limit in (report.get("null_limits") or {}).items():
        rate = (report.get("null_rate") or {}).get(col)
        if rate is not None and limit is not None and rate > limit:
            failures.append(f"{col} null rate {round(rate, 4)} > declared limit {limit}")

    # THE PUBLISH SURFACE. The privacy floor is judged in EVERY mode; the whitelist is a
    # strict-mode (release-bound) obligation — and in strict mode an UNDECLARED whitelist is
    # itself the failure, because "no list" is how internal helper columns ship. Whitelist
    # violations are never excusable via not_applicable: the list IS the approval.
    pubrep = report.get("publish") or {}
    for c in pubrep.get("never_publish_present") or []:
        failures.append(f"`{c}` is on the never_publish privacy floor and is present in the "
                        f"ADS — remove it before any run of any kind publishes this frame")
    if (spec or {}).get("strict") or report.get("strict"):
        if not pubrep.get("declared"):
            failures.append("STRICT: no publish whitelist declared (qc.publish_columns) — a "
                            "release-bound contract names its approved ordered column list, or "
                            "every joined internal helper ships with the product")
        else:
            for c in pubrep.get("extra") or []:
                failures.append(f"column `{c}` is in the ADS and not on the approved publish "
                                f"whitelist — an internal helper about to ship")
            for c in pubrep.get("missing") or []:
                failures.append(f"whitelisted column `{c}` is absent from the ADS — the "
                                f"approved surface is incomplete")
            if pubrep.get("order_differs"):
                failures.append("the ADS column order differs from the approved whitelist "
                                "order — order is part of what was approved")

    # STRICT MEANS EVERY CONFIGURED RULE WAS EVALUATED. Before this, a family with two rules
    # where only one column existed compared the one and filed the other under `skipped` — and
    # the gate called a family unconfigured only at ZERO compared rules, so a half-checked
    # contract passed strict. A skipped rule either fails, or a person has dispositioned it as
    # not applicable (qc.output_contract.not_applicable: {name: reason}) — with the reason.
    if (spec or {}).get("strict") or report.get("strict"):
        excused = {str(k): str(v or "")
                   for k, v in (((spec or {}).get("not_applicable")
                                 or report.get("not_applicable")) or {}).items()}
        for family, val in sorted((report.get("skipped") or {}).items()):
            if family == "cohorts":                    # surfaced above as unconfigured already
                continue
            items = [str(i) for i in val] if isinstance(val, (list, tuple)) else [family]
            detail = "" if isinstance(val, (list, tuple)) else f" ({val})"
            for item in items:
                if item not in excused:
                    failures.append(
                        f"STRICT: configured {family} rule `{item}` was skipped, not "
                        f"evaluated{detail} — it either fails, or carries an explicit "
                        f"qc.output_contract.not_applicable disposition with its reason")
                elif not excused[item].strip():
                    failures.append(
                        f"STRICT: `{item}` is dispositioned not_applicable with NO reason — "
                        f"an unexplained exemption is the silent skip wearing an approval")
    for check in ("null_limits", "flag_date_pairs", "date_order", "nonnegative", "vocabulary"):
        if not (report.get("compared") or {}).get(check):
            unconfigured.append(
                f"{check}: NOTHING COMPARED — no rule for it reached this build, so its absence "
                f"from `failures` is silence, not agreement")

    passed = not failures and not (strict and unconfigured)
    return {"passed": passed, "failures": failures, "unconfigured": unconfigured}
