"""The named delivered-date shapes a reviewed source adapter may bind — ONE table, no imports.

WHY ITS OWN MODULE. Two sides need this table and they sit on opposite sides of a layering rule:
`engine/stages/sources.py` EXECUTES a parser and `tools/source_adapter.py` VALIDATES that a
committed adapter names a real one. `validate.py` states outright that the engine must not import
`platform/tools` — and `sources.py` did exactly that to reach the table, so the loader resolved
only when a caller happened to have `tools/` on sys.path and the rule the repository wrote down
was false in the one place it mattered. The table cannot live in `source_contract.py` either: that
module imports the rest of the engine relatively, so a tool loading engine modules top-level
cannot read it. Zero imports here means both sides load it either way, and there is one table.

"""
# THE PARSERS, BY NAME, and the reason they are named rather than free-form. A delivery states its
# dates in whatever its source system used, and the difference is invisible: `01JAN2016` and
# `2016-01-01` are both strings, both plausible, and a wrong guess silently yields null for every
# row. So the adapter NAMES the shape and the engine owns the expression — an arbitrary format
# string in a governed file would be a fragment of code nobody reviews as code, and a misspelled
# one ("yyyy-mm-dd", lower-case m meaning minutes) parses to nulls without failing.
#
# Each entry is (name, spark date/timestamp pattern or None for a plain cast). Extend it here,
# where the addition is reviewed once for every product, never per pack.
PARSERS = {
    "iso_date": "yyyy-MM-dd",
    "iso_timestamp": "yyyy-MM-dd HH:mm:ss",
    "yyyymmdd": "yyyyMMdd",
    "ddmmmyyyy": "ddMMMyyyy",          # 01JAN2016 — the SAS/pharma delivery shape
    "mm_dd_yyyy": "MM/dd/yyyy",
    "dd_mm_yyyy": "dd/MM/yyyy",
    "yyyy_mm": "yyyy-MM",              # month-granularity dates, common in mortality feeds
    "epoch_seconds": None,             # numeric epoch — handled by the loader, not a pattern
    "epoch_millis": None,
}
