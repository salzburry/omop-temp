"""ONE strict YAML loader for governed files — a duplicate key is a refusal, never a silent winner.

PyYAML's SafeLoader is last-wins on duplicate mapping keys: a file carrying two `approved_by:`
lines loads cleanly with the SECOND value silently replacing the first. In an approval record that
is the difference between who signed and who appears to have signed — reproduced by the external
review against a governed YAML, accepted without a murmur. Every reader of a governed file loads
through this module so the refusal cannot fork per caller.

`strict_load` is a drop-in for `yaml.safe_load`: same scalar resolution (dates stay dates,
impossible dates still raise ValueError — `product_gates.read_yaml` depends on exactly that), same
return shapes. The added behaviors are the duplicate-key refusal and the suspicious-scalar
refusal (an unquoted number YAML 1.1 would read as other than its digits), both raised as
`yaml.YAMLError` so every existing `except yaml.YAMLError` handler already catches them.

stdlib + PyYAML only.
"""
import re

import yaml


class DuplicateKey(yaml.YAMLError):
    """A mapping stated the same key twice — two claims for one slot, one silently discarded."""


class SuspiciousScalar(yaml.YAMLError):
    """An unquoted number YAML 1.1 reads as something other than the digits typed."""


# THE OTHER SILENT TRAP (thirteenth pass, J3): `exclusion_days: 014` loads as 12 and `cohortn: 010`
# as 8 — YAML 1.1 octal — and nothing at validation time says the typed text and the loaded value
# differ. A person typed fourteen days with a leading zero and the engine would run with twelve.
# The forms YAML 1.1 resolves to an integer other than the digits shown: a leading zero (octal),
# 0x (hex), 0b (binary) and underscores as digit separators. Refused wherever a PLAIN scalar
# carries one — a key, a value, a list item; a quoted value is text and passes, and so does the
# same text inside a literal or folded block (`answer: |` then `0x10`), which YAML never re-types.
# Decided over the PARSED node tree, not the lines: a line regex read the block's `  0x10` as a
# bare scalar and refused an answer form for the prose a person had typed (thirteenth pass, the
# proposals suite).
_TRAP = re.compile(r"^[-+]?(?:0[0-7_]+|0[xX][0-9a-fA-F_]+|0[bB][01_]+|[0-9][0-9_]*_[0-9_]*)$")


def _suspicious(root):
    """Walk a COMPOSED node tree (tags already resolved) and refuse the first plain scalar the
    resolver reads as an integer other than its digits."""
    stack = [root]
    while stack:
        node = stack.pop()
        if node is None:
            continue
        if isinstance(node, yaml.ScalarNode):
            v = node.value
            if node.style is None and node.tag == "tag:yaml.org,2002:int" and _TRAP.match(v):
                try:
                    loaded = yaml.safe_load(v)
                except yaml.YAMLError:
                    continue
                if isinstance(loaded, int) and not isinstance(loaded, bool) and str(loaded) != v.lstrip("+"):
                    raise SuspiciousScalar(
                        f"line {node.start_mark.line + 1}: {v!r} would load as {loaded!r} — YAML 1.1 reads a "
                        f"leading zero as octal, 0x as hex, 0b as binary and underscores as digit separators; "
                        f"write the number plainly, or quote it if it is text")
        elif isinstance(node, yaml.SequenceNode):
            stack.extend(node.value)
        elif isinstance(node, yaml.MappingNode):
            for key_node, value_node in node.value:
                stack.append(key_node)
                stack.append(value_node)


class _StrictLoader(yaml.SafeLoader):
    pass


def _mapping(loader, node, deep=False):
    seen = set()
    for key_node, _v in node.value:
        key = loader.construct_object(key_node, deep=deep)
        try:
            hashable = key
            if hashable in seen:
                raise DuplicateKey(
                    f"duplicate key {key!r} (line {key_node.start_mark.line + 1}) — the second "
                    f"value would silently replace the first, and in a governed file that is a "
                    f"forged slot, not a convenience")
            seen.add(hashable)
        except TypeError:
            pass                                     # unhashable key: let SafeLoader report it
    return yaml.SafeLoader.construct_mapping(loader, node, deep=deep)


_StrictLoader.add_constructor(yaml.resolver.BaseResolver.DEFAULT_MAPPING_TAG, _mapping)


def strict_load(stream):
    """yaml.safe_load, but a duplicate mapping key raises DuplicateKey and an unquoted number that
    would load as other than its digits raises SuspiciousScalar (both yaml.YAMLError)."""
    text = stream if isinstance(stream, (str, bytes)) else stream.read()
    if isinstance(text, bytes):
        text = text.decode("utf-8")
    # ONE parse: compose the tree, walk it for the trap, then construct from the same tree — what
    # yaml.load does inside get_single_data, split so the walk sees resolved tags and styles.
    loader = _StrictLoader(text)
    try:
        node = loader.get_single_node()
        if node is None:
            return None
        _suspicious(node)
        return loader.construct_document(node)
    finally:
        loader.dispose()


def strict_load_path(path):
    """`strict_load` over a FILE, decoded as utf-8.

    Three tools had each written this same adapter — `citation_register._load`,
    `portfolio_status._load` and `capability_registry._strict_load`, byte-identical. Reading the
    bytes is part of "load a governed file", so it belongs with the loader that owns the refusal,
    and a per-caller copy is how one of them comes to open a governed file in the machine's default
    code page. This repository keeps a whole test for that failure on the Windows runner.
    """
    from pathlib import Path                                            # noqa: PLC0415
    return strict_load(Path(path).read_text(encoding="utf-8"))
