"""Which CODING SYSTEM a delivered column carries — the registry, and what follows from it.

WHY THIS EXISTS. Every matching operator this engine had was written against curated TEXT: the
codelist DSL compiles `like_any: ["%bevacizumab%"]` to `LOWER(linename) LIKE '%bevacizumab%'`, and
the categorical/crosswalk families map delivered strings to labels. That is the shape of the vendor
the engine was built against, and it is a fine shape — until a pack is pointed at a feed whose drug
column is NDC, or whose diagnosis column is ICD-10-CM. Then `%bevacizumab%` matches NOTHING: the
config is plausible, the SQL is valid, every patient falls through to the catch-all category, and
no gate notices. Silence is the failure.

So a pack DECLARES what each matched column carries, and the declaration has teeth: a name-based
operator against a coded column is refused, and a code-based operator against a text column is
refused. `text` is a value here, not an absence — "this column carries curated text" and "nobody
said" are different states, and only the first is safe to run a LIKE against.

WHAT A REGISTRY ENTRY MEANS.
  * `strip_chars` — characters removed from BOTH sides of a comparison before it is made. Feeds
    disagree about punctuation the terminology itself treats as cosmetic: ICD-10-CM arrives as
    `C18.9` or `C189`, and a code set written one way silently misses a feed written the other.
    Declared per system rather than inferred, and MIRRORED EXACTLY in engine-r/vocabularies.R —
    `test_r_parity` compares the two.

    IT IS A CHARACTER STRIP AND NOTHING MORE, which matters most where it is least enough: NDC.
    Stripping hyphens turns `0069-0187-01` into the TEN-digit `0069018701`, which is not equal to
    the ELEVEN-digit `00690018701` the same product carries in a 5-4-2 feed. Converting between the
    two requires knowing which segment was short (4-4-2, 5-3-2, 5-4-1) — a lookup, not a rule — so
    this module does NOT do it, and an NDC code set must be written in the form the feed delivers.
    `code_errors` accepts both lengths because both are well-shaped NDCs; which one the feed
    carries is a fact about the delivery, and the adapter contract is where that is bound.
  * `hierarchical` — whether a PREFIX is a meaningful generalisation. `C18` is every colon
    neoplasm; `L01XC` is every monoclonal antibody. An RxNorm or SNOMED identifier has no such
    structure, so `code_prefix_any` against one is refused rather than quietly returning whatever
    shares leading digits.
  * `pattern` — the SHAPE of a code, for lint. IT IS NOT A MEMBERSHIP CHECK and does not pretend to
    be one: `C99.9` is shaped like ICD-10-CM and is not a code. Proving membership needs the
    published release itself, which this repository does not carry — see `release` below for what
    is done instead.
  * `release_cadence` — how often the published terminology CHANGES, in the sentence a person
    needs. This is the half that was missing: a code set is written against an EDITION, and every
    coded system here revises on a schedule. ICD-10-CM retires and adds codes every October, so a
    set written against FY2021 run over a 2026 feed silently misses what was added and keeps what
    was withdrawn — no pattern check can see it, because both editions' codes are equally
    well-shaped. A `vocabularies:` entry therefore states the `release` its code sets were written
    against; `release_errors` refuses the placeholders that mean "nobody looked" (TODO, latest,
    current), and the declaration rides into the build manifest so a candidate records which
    editions its cohorts were selected with.

    STATING A RELEASE IS NOT VERIFYING MEMBERSHIP, and the difference is deliberate. Verifying
    would mean carrying the published release in the repository — licensed content for most of
    these systems, and a governed material in its own right if it ever arrives. What the
    declaration buys is that the edition becomes a recorded, comparable fact instead of an
    assumption nobody wrote down.

Pure Python, no Spark, no YAML — the same discipline as vendors.py and codelists.py.
"""
from __future__ import annotations

import re

# The one declaration that a column is NOT coded. A value, never an absence: see the module note.
TEXT = "text"

CODING_SYSTEMS = {
    TEXT: {
        "description": "curated or abstracted free text (drug names, ECOG values, stage strings) — "
                       "what an EHR-derived vendor delivers; matched by name, never by code",
        "strip_chars": "",
        "hierarchical": False,
        "pattern": None,               # any string is a legitimate abstracted value
    },
    "icd10cm": {
        "description": "ICD-10-CM diagnosis codes",
        "release_cadence": "annually, every 1 October (FY editions)",
        "strip_chars": ".",
        "hierarchical": True,
        "pattern": r"^[A-TV-Z][0-9][0-9A-Z](\.?[0-9A-TV-Z]{0,4})?$",
    },
    "icd9cm": {
        "description": "ICD-9-CM diagnosis codes (historical claims)",
        "release_cadence": "frozen since 2015; a set written against it is historical by definition",
        "strip_chars": ".",
        "hierarchical": True,
        "pattern": r"^(V[0-9]{2}|E[0-9]{3}|[0-9]{3})(\.?[0-9]{1,2})?$",
    },
    "icdo3": {
        "description": "ICD-O-3 oncology morphology (8140/3) and topography (C18.9)",
        "release_cadence": "by revision (ICD-O-3.1, 3.2) — morphology terms are added and reassigned",
        "strip_chars": ".",
        "hierarchical": True,
        "pattern": r"^([89][0-9]{3}/[0-6]|C[0-9]{2}(\.?[0-9])?)$",
    },
    "snomed": {
        "description": "SNOMED CT concept identifiers",
        "release_cadence": "twice a year (January and July international releases)",
        "strip_chars": "",
        # A SNOMED identifier is an opaque integer: 73211009 (diabetes) shares no prefix structure
        # with anything. Hierarchy exists in SNOMED, but through the relationship graph, not the id.
        "hierarchical": False,
        "pattern": r"^[0-9]{6,18}$",
    },
    "rxnorm": {
        "description": "RxNorm concept unique identifiers (RXCUI)",
        "release_cadence": "monthly full releases, weekly updates",
        "strip_chars": "",
        "hierarchical": False,
        "pattern": r"^[0-9]+$",
    },
    "ndc": {
        "description": "National Drug Code, hyphenated or not. The 10- and 11-digit forms are NOT "
                       "interconvertible by rule (see the module note) — write the code set in the "
                       "form the feed delivers",
        "release_cadence": "continuously — products are listed and delisted daily",
        "strip_chars": "-",
        # An NDC labeller prefix does generalise (all products from one labeller), but that is a
        # manufacturer, not a drug — prefix-matching it selects by company. Refused on purpose.
        "hierarchical": False,
        "pattern": r"^[0-9]{4,5}-?[0-9]{3,4}-?[0-9]{1,2}$",
    },
    "atc": {
        "description": "WHO ATC classification (L01XC02); levels ARE prefixes",
        "release_cadence": "annually, every January",
        "strip_chars": "",
        "hierarchical": True,
        "pattern": r"^[A-Z]([0-9]{2}([A-Z]([A-Z]([0-9]{2})?)?)?)?$",
    },
    "hcpcs": {
        "description": "HCPCS Level II procedure/supply codes (J9035)",
        "release_cadence": "quarterly",
        "strip_chars": "",
        "hierarchical": False,
        "pattern": r"^[A-V][0-9]{4}$",
    },
    "cpt": {
        "description": "CPT / HCPCS Level I procedure codes",
        "release_cadence": "annually, every 1 January",
        "strip_chars": "",
        "hierarchical": False,
        "pattern": r"^[0-9]{4}[0-9A-Z]$",
    },
    "loinc": {
        "description": "LOINC laboratory observation codes (2160-0)",
        "release_cadence": "twice a year (February and August)",
        "strip_chars": "",
        "hierarchical": False,
        "pattern": r"^[0-9]{1,5}-[0-9]$",
    },
}

SYSTEMS = tuple(sorted(CODING_SYSTEMS))
# The systems a code-based operator may be used against — everything except the text declaration.
CODED = tuple(s for s in SYSTEMS if s != TEXT)


def known(system) -> bool:
    return str(system) in CODING_SYSTEMS


def is_coded(system) -> bool:
    """True when this declaration means codes. `text` is declared and NOT coded; anything
    undeclared is neither — callers must treat unknown as unanswered, not as text."""
    return known(system) and str(system) != TEXT


def hierarchical(system) -> bool:
    return bool(CODING_SYSTEMS.get(str(system), {}).get("hierarchical"))


def strip_chars(system) -> str:
    return str(CODING_SYSTEMS.get(str(system), {}).get("strip_chars") or "")


def normalise(system, code) -> str:
    """The comparison form of `code` under `system` — uppercased, trimmed, punctuation stripped.

    The ONE normaliser. `codelists.compile_match` normalises the literals it compiles and emits SQL
    that applies the same rule to the column, so `C18.9` in a code set matches `C189` in a feed and
    vice versa. engine-r/vocabularies.R carries the identical rule; test_r_parity compares them over
    a hostile string set.
    """
    out = str(code or "").strip().upper()
    for ch in strip_chars(system):
        out = out.replace(ch, "")
    return out


def system_errors(system) -> list:
    """Why this is not a usable coding-system declaration, or []."""
    s = str(system or "").strip()
    if not s:
        return ["no coding system declared — `text` is the declaration for a column that carries "
                "curated text; leaving it blank says nothing and is refused"]
    if not known(s):
        return [f"unknown coding system {s!r}; declared systems: {list(SYSTEMS)}"]
    return []


def cadence(system) -> str:
    """How often this system's published terminology changes, or "" for text."""
    return str((CODING_SYSTEMS.get(str(system or "").strip()) or {}).get("release_cadence") or "")


# Words that LOOK like a release and name none. "latest" is whatever was current on the day
# somebody typed it, which is precisely the fact the declaration exists to pin down.
_NON_RELEASES = {"todo", "tbd", "latest", "current", "n/a", "na", "none", "unknown", "?"}


def release_errors(system, release) -> list:
    """Why this is not a usable release declaration for `system`, or [].

    A coded system revises on a schedule (`release_cadence`), so a code set is written against an
    EDITION whether or not anybody records which. Recording it is the whole check: nothing here
    verifies that the codes exist in that edition — see the module note on why membership needs
    the published release itself, which this repository does not carry.
    """
    s = str(system or "").strip()
    if not is_coded(s):
        r = str(release or "").strip()
        if r:
            return [f"release {r!r} is declared for `{s or 'an undeclared system'}`, which carries "
                    f"curated text rather than a published terminology — a text column has no "
                    f"edition"]
        return []
    r = str(release or "").strip()
    if not r:
        return [f"no release declared for {s} — that terminology changes {cadence(s)}, so a code "
                f"set written against one edition means something different against another, and "
                f"nothing about the codes themselves shows which was meant"]
    if r.lower() in _NON_RELEASES:
        return [f"release {r!r} for {s} names no edition — it is whichever one happened to be "
                f"current when it was typed, which is the fact this declaration exists to pin"]
    return []


def code_errors(system, code) -> list:
    """Why `code` is not SHAPED like a code of `system`, or [].

    Shape only, and the docstring says so where a reader will meet it: a well-shaped code that the
    published release does not contain passes here. Membership needs the release itself, which is
    not carried here; `release_errors` makes the EDITION a recorded fact instead.
    """
    bad = system_errors(system)
    if bad:
        return bad
    pattern = CODING_SYSTEMS[str(system)]["pattern"]
    if pattern is None:
        return []
    raw = str(code or "").strip().upper()
    if not raw:
        return [f"empty code in a {system} code list"]
    if not re.match(pattern, raw):
        return [f"{code!r} is not shaped like a {system} code (expected {pattern})"]
    return []


def prefix_errors(system) -> list:
    """Why a PREFIX match is not meaningful under `system`, or []."""
    bad = system_errors(system)
    if bad:
        return bad
    if not hierarchical(system):
        return [f"{system} identifiers are not hierarchical, so a prefix selects codes that merely "
                f"share leading characters — use an explicit code list instead"]
    return []
