"""Refresh governance — per-refresh manifests so git IS the refresh ledger.

Each released data cut (a `refresh`, e.g. 2026q1) writes a manifest under
`refreshes/<family>/<product>/<spec_version>/<refresh>.yaml`, committed to git. The manifest records exactly what produced
the ADS (spec version, git commit, run params, row/cohort counts, QC result, golden summary) and
its sign-off — so any number is reproducible (checkout the commit/tag, re-run the same config).

Pure Python (no Spark): build_manifest() assembles the manifest; validate_manifest() checks it.
The Databricks runner can write it after build+QC; sign-off fields are filled by a reviewed commit.
"""
from __future__ import annotations

import os as _os
import re as _re
from datetime import datetime, timezone
from pathlib import Path

try: # engine version stamp (build-level provenance); cheap, no Spark
    from.version import ENGINE_VERSION
except Exception: # noqa: BLE001 - keep manifest buildable even if VERSION is unreadable
    ENGINE_VERSION = "unknown"

STATUSES = ["qc_pending", "qc_passed", "released", "superseded"]
REQUIRED = ["tumor", "refresh", "spec_version", "built_at", "status", "counts"]
# TWO GRAMMARS, because the values go two places. `refresh`, `tumor` and `build_id` are spliced
# UNQUOTED into table names (`<final>__<refresh>__<build_id>`, release.py) as well as into paths,
# so they get the SQL-identifier class: letters, digits, underscore. `spec_version` and `family`
# are path segments only: dots and dashes are fine there, separators and dot-runs never are.
# The first audit's single grammar let `.` and `-` reach unquoted SQL; the second named it.
_SQL_IDENT = _re.compile(r"[A-Za-z0-9_]{1,64}")
_PATH_SEGMENT = _re.compile(r"[A-Za-z0-9][A-Za-z0-9._-]{0,63}")
# a composed table name (`final__refresh__build_id`) is one part and legitimately exceeds 64 —
# a realistic endometrial name reached 67 and promotion refused what the composer had built
# (fourth audit); Databricks identifiers allow 255. Components stay at 64.
_DOTTED = _re.compile(r"[A-Za-z0-9_]{1,255}(\.[A-Za-z0-9_]{1,255}){0,2}")
# a SCHEMA is at most catalog.schema: a three-part schema plus a table made a four-part name
_SCHEMA = _re.compile(r"[A-Za-z0-9_]{1,255}(\.[A-Za-z0-9_]{1,255})?")


def unsafe_identifier(kind: str, value) -> str | None:
    """None when `value` is a safe `kind` ('sql' | 'path' | 'dotted'); else the reason.

    ONE validator, `fullmatch`-based, for every identifier component — the third audit showed
    `safe_id\\n` passing a `$`-anchored `match()` because Python's `$` accepts a final newline.
    Shared by the config validator (ingress), the manifest validator, the table-name composer and
    the runner, so the same value is refused at every boundary. 'dotted' is a schema-qualified
    name (`catalog.schema.table`, up to three parts) for the public/versioned names in SQL."""
    # bool subclasses int: YAML `true` used to pass as the identifier "True" (fourth audit)
    if isinstance(value, bool) or not isinstance(value, (str, int)):
        return f"{value!r} is not a string identifier"
    s = str(value)
    if kind == "sql":
        if not _SQL_IDENT.fullmatch(s):
            return f"{value!r} is not a safe SQL/path identifier: [A-Za-z0-9_] only (max 64)"
        return None
    if kind == "dotted":
        if not _DOTTED.fullmatch(s):
            return (f"{value!r} is not a safe dotted SQL name: [A-Za-z0-9_] parts joined by '.', "
                    f"at most three parts")
        return None
    if kind == "schema":
        if not _SCHEMA.fullmatch(s):
            return (f"{value!r} is not a safe schema name: [A-Za-z0-9_] parts joined by '.', at "
                    f"most catalog.schema (two parts) — a third part would make a four-part table")
        return None
    if not _PATH_SEGMENT.fullmatch(s) or ".." in s:
        return f"{value!r} is not a safe path segment: [A-Za-z0-9._-], no separators, no '..'"
    return None

# THE COMPANION KEY THAT PINS A TABLE-VALUED ARTIFACT, named here because the runner and this
# validator have to agree on it and two string literals in two files agree only until one moves.
#
# A file artifact is pinned by `<name>_sha256`, a digest of its bytes. A Delta table cannot be —
# its identity is `table_id` + `delta_version`, which the runner probes at the write and records
# under `candidate_identity`. But `candidate_identity` is keyed by the STAGING table name,
# `artifacts["tfl_<id>"]` holds the PUBLIC name, and `tfl_promotion.promoted` lists bare `<id>`s:
# one table under three vocabularies with no mapping between them, so nothing could resolve a
# named artifact to the identity that pins it. `artifacts["tfl_<id>" + ARTIFACT_TABLE_PIN]` is
# that mapping, written beside the artifact it pins by the runner — the naming decision is the
# writer's, and a validator that rebuilt the staging name would agree with the runner only until
# the naming changed.
ARTIFACT_TABLE_PIN = "_staged_as"

# THE INPUTS A REPRODUCTION IS A FUNCTION OF. Everything else in the manifest is an OUTCOME of the
# run (counts, qc, deliverables) or an EVENT within it (built_at, published_at) — and the reason
# this list exists at all is that the manifest previously had no identity that could repeat.
# `build_id` and `built_at` are both wall-clock-derived and sit inside the hashed bytes, so
# `_manifest_sha` can never match across two runs of identical inputs. That is correct for an
# audit identity and useless for a reproduction claim: "same inputs, same content" was
# unanswerable because nothing named the inputs.
#
# Two runs agreeing here SHOULD produce identical governed content. This does not PROVE they did:
# it is the question's LEFT-HAND side. The right-hand side is `content.digest`
# (`engine/content_digest.py`), a digest of the published cells, and the two are kept strictly
# independent — same inputs and a different content digest is a real finding, and it can only BE a
# finding if neither is computed from the other.
#
# `run_as_of` IS DELIBERATELY NOT HERE, and the distinction is worth stating because it looks like
# an omission. It is the one clock the run injects into the artifacts that want a human-readable
# timestamp — the dashboard manifest, the TFL QC doc, the dictionary xlsx — so two runs differing
# only in it produce different artifact BYTES while the governed CONTENT is identical. Including
# it would make this id move with the clock, which is the defect it replaces. Excluding it means
# what it says: this answers "same governed content?", and a test wanting byte-identical artifacts
# pins `run_as_of` as well, which it now can because the clock is an argument rather than a read.
REPRODUCTION_INPUTS = ("tumor", "family", "spec_version", "data_product_id", "engine_version",
                       "tree_sha256", "config_identity", "adapter_binding", "runtime",
                       "vocabulary_releases", "source_schema", "source_union", "output_table")


def _lineage_identity(source_lineage):
    """Source lineage reduced to what a re-read depends on: which table, at which version.

    `last_commit_at` and row counts are properties of the data at that version, so they add
    nothing to the identity and would only make two identical re-reads look different if a probe
    reported them differently.
    """
    out = {}
    for name, entries in sorted((source_lineage or {}).items()):
        rows = entries if isinstance(entries, list) else [entries]
        out[name] = [{k: e.get(k) for k in ("fqn", "table_id", "delta_version", "error")
                      if e.get(k) is not None}
                     for e in rows if isinstance(e, dict)]
    return out


def reproduction_id(manifest):
    """The digest of everything a rebuild would have to match. Re-derivable from a written
    manifest by anyone, which is the point — a build cannot assert its own reproducibility.

    Deliberately EXCLUDES `built_at`, `build_id`, `published_at`, `git_commit`, counts, QC and
    every deliverable: those are when it ran, that it ran, and what came out. `tree_sha256` covers
    the code, so `git_commit` adds only the label a commit happens to carry.
    """
    import hashlib # noqa: PLC0415
    import json as _json # noqa: PLC0415
    payload = {k: manifest.get(k) for k in REPRODUCTION_INPUTS}
    payload["source_lineage"] = _lineage_identity(manifest.get("source_lineage"))
    return hashlib.sha256(_json.dumps(payload, sort_keys=True, separators=(",", ":"),
                                      default=str).encode("utf-8")).hexdigest()


def runtime_versions(spark=None):
    """The runtime a build actually ran on, as far as it can be observed.

    RECORDED BECAUSE IT DECIDES THE ANSWER. `stages/sources.py` documents that a plain cast is
    null on an ANSI-off cluster and a raise on an ANSI-on one, and DBR 15.4 and Spark 4 default
    differently — so a manifest that does not say which runtime produced it cannot support a
    reproduction claim. The four session settings are pinned in `resources/products.yml`; this
    records what the session REPORTS, which is the half a bundle declaration cannot prove.

    Every field degrades to `None` rather than raising: a manifest missing a version is a weaker
    record, and a build that died collecting one is worse.
    """
    import platform as _platform # noqa: PLC0415
    out = {"python": _platform.python_version(), "spark": None, "delta": None, "java": None,
           "session": {}}
    try:
        import delta # noqa: PLC0415
        out["delta"] = getattr(delta, "__version__", None)
    except Exception: # noqa: BLE001
        pass
    if spark is None:
        try:
            from pyspark.sql import SparkSession # noqa: PLC0415
            spark = SparkSession.getActiveSession()
        except Exception: # noqa: BLE001
            spark = None
    if spark is not None:
        try:
            out["spark"] = spark.version
            out["java"] = spark.sparkContext._jvm.System.getProperty("java.version")
        except Exception: # noqa: BLE001
            pass
        for key in ("spark.sql.session.timeZone", "spark.sql.ansi.enabled",
                    "spark.sql.legacy.timeParserPolicy", "spark.sql.caseSensitive"):
            try:
                out["session"][key] = spark.conf.get(key)
            except Exception: # noqa: BLE001
                out["session"][key] = None
    return out


def build_manifest(cfg, *, tumor, family="oncology", git_commit=None, counts=None, qc=None, golden=None,
                   source_qc=None, source_qc_gate=None, deliverables=None, artifacts=None,
                   published_at=None, source_lineage=None, config_identity=None,
                   run_mode=None, output_contract=None, differential=None,
                   source_grain=None, stage_telemetry=None, eda=None, retention=None,
                   adapter_binding=None, runtime=None, tree_sha256=None,
                   artifact_types=None, artifact_attestation=None,
                   run_as_of=None, content=None, linkage=None, publication_surface=None) -> dict:
    """Assemble a refresh manifest from the resolved config + the run's outputs.

    `source_qc` is the full pre-build source-QC REPORT (mortality granularity + death-conflict
    counts); `source_qc_gate` is its pass/fail decision. `deliverables` records per-artifact status
    (dictionary / TFLs: ok | empty | failed | skipped) so the ledger shows whether the refresh's
    deliverables are complete.

    `published_at` is None for the PRE-publish ledger (written before the temp-then-swap) and is set
    to the swap timestamp only AFTER a successful publish. So `status: qc_passed` with a null
    `published_at` means "cleared QC, NOT yet published" and can never be mistaken for a successful
    publish (e.g. if the swap failed after the pre-publish ledger was written).
    """
    doc = {
        "tumor": tumor,
        "family": family, # product family (oncology) — first segment of the ledger path
        "refresh": cfg.refresh,
        "spec_version": cfg.spec_version, # CalVer contract (e.g. 202606); the cut is `refresh`
        "data_product_id": cfg.data_product_id, # stable product id (also stamped on every ADS row)
        "engine_version": ENGINE_VERSION, # build-level provenance: which engine produced this
        "vendor": cfg.vendor,
        "tumor_class": cfg.tumor_class,
        # WHICH EDITION OF EACH TERMINOLOGY SELECTED THESE COHORTS. A code set is written against
        # a published release, and every coded system revises on a schedule — so without this, two
        # refreshes built from identically-shaped code sets against different ICD editions are
        # indistinguishable in the ledger. `{}` where the pack declares no coded column.
        "vocabulary_releases": {f'{v.get("source")}.{v.get("column")}':
                                {"system": v.get("system"), "release": v.get("release")}
                                for v in (cfg.vocabularies or [])
                                if str(v.get("system") or "") not in ("", "text")},
        "built_at": datetime.now(timezone.utc).isoformat(timespec="seconds"),
        "git_commit": git_commit,
        "source_schema": cfg.source_schema,
        "source_union": cfg.source_union, # the member schemas+flags that produced the build (EC);
                                               # None for a single-schema source. source_schema is
                                               # unused under a union, so this is the real provenance.
        "output_table": cfg.output_fqn,
        # THE CONFIG THE BUILD EXECUTED, as digests — {config_bundle_sha256, delivery_sha256} from
        # product_gates. `spec_version` names a config; this pins its BYTES, so a candidate built
        # under one configuration cannot promote after the pack quietly becomes another
        # (release.candidate_binding_blockers compares these against the runtime pack).
        "config_identity": dict(config_identity or {}),
        # WHICH ADAPTER MAPPING THE BUILD EXECUTED. `config.py` states that recording this makes
        # the binding "part of the run's identity", and it did not reach here: it went only to a
        # local verdict object that `candidate_verdict` reads seven keys from and then discards.
        # Nothing else covered it either — `config/source_adapters.yaml` is outside `pack_yaml`'s
        # graph, so neither `config_bundle_sha256` nor `delivery_sha256` includes it. Two
        # candidates built through different physical mappings therefore had durable manifests
        # that did not disclose the difference.
        "adapter_binding": dict(adapter_binding or {}),
        # THE RUNTIME THAT PRODUCED IT. A plain cast is null on an ANSI-off cluster and a raise on
        # an ANSI-on one; a manifest that cannot say which one ran cannot support a reproduction
        # claim. Includes the four pinned session settings as the SESSION REPORTED them, which is
        # the half a bundle declaration cannot prove.
        "runtime": dict(runtime or {}),
        # THE CODE, as a tree digest rather than a commit label. Verified at runtime already and
        # then thrown away, so the manifest recorded which commit was CLAIMED and never which
        # bytes ran.
        "tree_sha256": tree_sha256,
        # THE ONE CLOCK THE RUN INJECTED into every artifact that needed a timestamp. Distinct
        # from `built_at`, which is when this manifest was assembled: `run_as_of` is what the
        # dashboard manifest, the TFL QC doc, the dictionary xlsx and the differential gate
        # were all given, so a reader can reproduce those bytes by passing it back.
        "run_as_of": run_as_of,
        # WHAT THE BUILD PUBLISHED, as a digest of the cells. `reproduction_id` above says two
        # runs received the same inputs; this is the only thing that says they produced the
        # same content. Deliberately independent of everything in REPRODUCTION_INPUTS: a
        # different engine, a rewritten pipeline or a changed assistant layer that publishes
        # identical values must agree here, or it would be measuring the code rather than the
        # data. `{"error":...}` when it could not be computed — never a silent absence.
        "content": dict(content or {}),
        # THE MODE THIS CANDIDATE WAS BUILT IN — {env, release_grade}. A dev candidate used to be
        # indistinguishable from a release-grade one in its own bytes; promotion under prod now
        # refuses a candidate that does not record release-grade construction.
        "run_mode": dict(run_mode or {}),
        "status": "qc_passed" if (qc or {}).get("passed") else "qc_pending",
        "published_at": published_at, # None until the swap succeeds (set post-publish)
        "counts": counts or {},
        # {source name: [{fqn, table_id, delta_version, last_commit_at,...} | {fqn, error}]}.
        # Git pins the CODE this run executed; this pins the DATA it read — `VERSION AS OF
        # delta_version` on table_id re-reads the exact bytes. An input whose identity could not be
        # probed appears as an error entry, never as an omission.
        "source_lineage": source_lineage or {},
        "source_qc": source_qc or {}, # full report (granularity, conflict counts)
        "source_qc_gate": source_qc_gate or {}, # pass/fail decision
        "qc": qc or {},
        # THE OUTPUT CONTRACT — is the product the SHAPE it promised, as distinct from `qc`, which
        # scores its distributions. Carried separately and never folded into `qc`: they fail for
        # different reasons and a reader tracing a bad release needs to know which one let it out.
        "output_contract": output_contract or {},
        # DECLARED SOURCE GRAIN, checked against delivered rows (grain.source_grain_gate + report).
        # {} = the pack declared nothing — candidate_verdict then reads "source grain" as NOT
        # EVALUATED, never as a pass. This parameter exists because the runner was already passing
        # it and this function silently had nowhere to put it: the kwarg raised TypeError on the
        # first pack to declare a grain, found only when a test built a manifest carrying one.
        "source_grain": source_grain or {},
        # DECLARED RETENTION BOUNDS over the stage telemetry (telemetry.retention_gate).
        # {} = the pack declared none - candidate_verdict reads "stage retention" as NOT
        # EVALUATED. The raw telemetry below stays evidence-only; this is the separate
        # verdict its constitution reserved for a reviewed bound a pack states.
        "retention": retention or {},
        # DECLARED LINKAGE TOLERANCES, held as their own stage (linkage.linkage_verdict).
        # {} = the pack declared none — the verdict reads "source linkage" as NOT EVALUATED.
        "linkage": linkage or {},
        "golden": golden or {"reference": "none"},
        # PATIENT-LEVEL comparison against the reference. Separate from `golden`, which
        # scores aggregates: the two can disagree, and when they do it is the
        # aggregate one that looks clean.
        "differential": differential or {"reference": "none"},
        # PER-STAGE JOIN TELEMETRY (engine.telemetry) — EVIDENCE, NEVER A VERDICT. Opt-in per run;
        # {} = not collected. It carries no `passed` on purpose and must never join
        # CANDIDATE_VERDICTS: expansion and loss are design questions until a pack states a
        # reviewed bound, and a threshold invented here would be one nobody approved.
        "stage_telemetry": stage_telemetry or {},
        # THE EDA LAYERS (tools.eda_report) — the between-tables evidence: inventory, composed
        # grain, relationships vs the index source, date sanity, the cohort funnel, the output
        # contract. Same rule as stage_telemetry: EVIDENCE, NEVER A VERDICT — {} = not collected,
        # no `passed` at the top, and it must never join CANDIDATE_VERDICTS. What binds it to the
        # release is the manifest itself: the runner writes eda_report.json into the artifact
        # root and records its sha256 under `artifacts`, both covered by the candidate manifest
        # digest the Gate 6 approval signs. Counts only; the artifact self-declares
        # restricted_derived (output DERIVED from vendor data), and nothing here is AI-readable
        # without the human act that rule requires.
        "eda": eda or {},
        # Promoted from inside the doc so candidate_verdict reads every gate the same way: the
        # runner passes eda=doc, and the doc carries `acceptance` only when the pack declared
        # qc.eda_acceptance limits — absent limits leave this {} and the verdict says
        # "not evaluated" rather than inventing a pass.
        "eda_acceptance": (eda or {}).get("acceptance") or {},
        # THE PUBLICATION SURFACE (output_contract.publication_surface_gate) — the last stage.
        "publication_surface": publication_surface or {},
        # THE COMPOSED VERDICT ITSELF, filled below from the blocks above so a reader of the
        # manifest sees ONE answer; validate_manifest refuses a copy that disagrees with them.
        "candidate_verdict": {},
        "deliverables": deliverables or {}, # {dictionary: {...}, tfls: {...}} status
        "artifacts": artifacts or {}, # durable paths: qc_report, dictionary, tfl_dir
        # WHAT KIND OF THING EACH ARTIFACT IS, from the writer that knows. Guessing it from the
        # name let a real file escape its digest requirement by being called `tfl_something`.
        "artifact_types": artifact_types or {},
        # THAT THE DIGEST ABOVE WAS TAKEN FROM BYTES, said by the only party that could have taken
        # it. `{<file artifact>: {sha256, bytes, digested_at, by}}`, written by `run_rwdp.py` at
        # the moment it writes each file. Recorded HERE, in the doc, so it is inside the bytes
        # `_manifest_sha` covers and the Gate 6 approval signs it along with everything else —
        # an attestation added after the approval would move the digest the approval names.
        # NOT a reproduction input: `digested_at` is wall-clock, and two identical rebuilds must
        # still agree on `reproduction_id`. See `_artifact_errors` for what it does and does not
        # establish; it is the writer's own word, made specific and made compulsory.
        "artifact_attestation": artifact_attestation or {},
        "sign_off": {"qc_by": "", "qc_date": "", "released_by": "", "released_date": ""},
    }
    # LAST, AND OVER THE FINISHED DOC, so it is a function of what was actually recorded rather
    # than of the arguments this call happened to receive.
    doc["reproduction_id"] = reproduction_id(doc)
    doc["candidate_verdict"] = candidate_verdict(doc)
    return doc


def manifest_path(manifest: dict, root) -> Path:
    """The SPEC-VERSIONED ledger path for a manifest:
    `<root>/refreshes/<family>/<product>/<spec_version>/<refresh>.yaml`. The spec_version segment lets two
    contracts of the same product (e.g. 202603 and 202606) coexist for the same refresh without colliding.
    `<product>` is the registry CODE (the durable identity, == the release-tag segment)."""
    return (Path(root) / "refreshes" / str(manifest.get("family", "oncology")) / str(manifest["tumor"])
            / str(manifest["spec_version"]) / f"{manifest['refresh']}.yaml")


def release_dir(root, manifest: dict, build_id: str) -> Path:
    """The matching immutable evidence dir for a build:
    `<root>/releases/<family>/<product>/<spec_version>/<refresh>/<build_id>/`."""
    return (Path(root) / "releases" / str(manifest.get("family", "oncology")) / str(manifest["tumor"])
            / str(manifest["spec_version"]) / str(manifest["refresh"]) / str(build_id))


def write_manifest(manifest: dict, root) -> str:
    """Write a VALID manifest to the spec-versioned ledger path (see manifest_path). Returns the path.

    Refuses to write an invalid manifest. (The runner calls this best-effort; the manifest is then
    committed to git — that commit is the audited refresh record.)
    """
    import yaml
    probs = validate_manifest(manifest)
    if probs:
        raise ValueError("refusing to write an invalid manifest:\n  - " + "\n  - ".join(probs))
    path = manifest_path(manifest, root)
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w", encoding="utf-8", newline="\n") as fh:
        yaml.safe_dump(manifest, fh, sort_keys=False, default_flow_style=False)
    return str(path)


# THE FIVE VERDICTS A CANDIDATE STANDS ON, and the ONE place they are listed.
#
# (manifest key, human name, whether a MISSING verdict blocks)
#
# An external review found the defect this closes: the runner computed the output-contract and
# differential gates, printed them, wrote them into the manifest — and failed the job on `qc` and
# `golden` alone. Two gates built in the same week as the review, neither wired to the thing that
# stops the run. A failed output contract produced a green candidate; a failed differential reached
# release validation unexamined.
#
# The fix is not another `if` beside the first: it is ONE list, consumed by the job's failure
# condition, the manifest status, and the release check, so a sixth gate cannot be added to two of
# the three again. That is exactly how these two came to be enforced in one place out of three.
#
# `required` distinguishes a verdict that must EXIST from one that is legitimately absent. Golden
# and differential compare against a reference ADS, and there is not always one — `golden_gate`
# already returns `{passed: True, skipped:...}` in that case, which is an evaluated answer. A
# missing `output_contract`, by contrast, means nobody asked whether the product had the right
# shape, and "not asked" must never read as "passed".
CANDIDATE_VERDICTS = (
    ("source_qc_gate", "source QC", True),
    # PATIENT LINKAGE AS ITS OWN KEY (programme item 4). The source QC gate folds a declared
    # linkage tolerance into its failures; this names the stage in the composed verdict so a
    # reader sees "source linkage FAILED" rather than a source-QC line. Evaluated only when the
    # pack has ruled (linkage.linkage_verdict returns {} otherwise) — report-only linkage is
    # evidence, never a pass.
    ("linkage", "source linkage", False),
    ("qc", "ADS QC", True),
    ("output_contract", "output contract", True),
    ("golden", "aggregate golden", False),
    ("differential", "patient differential", False),
    # EDA-LITE, same evaluated-when-present grammar: eda() attaches `acceptance` to its doc only
    # when the pack declares qc.eda_acceptance limits; the runner copies that block here. No
    # declaration = "EDA acceptance" under not_evaluated; a declaration gets held to.
    ("eda_acceptance", "EDA acceptance", False),
    # Evaluated-when-present, like golden and differential: a pack that declares no `source_grain:`
    # has made no claim, and the runner attaches no block — the verdict then lists "source grain"
    # under not_evaluated instead of inventing a pass. A pack that DOES declare gets held to it.
    ("source_grain", "source grain", False),
    # Evaluated-when-present: attached only when the pack DECLARES qc.retention bounds -
    # the raw stage_telemetry block stays out of this list forever (evidence, never a
    # verdict); what joins is the gate over a bound somebody approved.
    ("retention", "stage retention", False),
    # THE PUBLICATION SURFACE, LAST: after every other stage, is what would be published exactly
    # the approved surface (output_contract.publication_surface_gate)? Attached by every
    # release-grade run (declared or failing), by a dev run only when a whitelist is declared.
    ("publication_surface", "publication surface", False),
)


def candidate_verdict(m: dict) -> dict:
    """{passed, failures, evaluated, not_evaluated} over ALL FIVE gates. Pure data.

    The single verdict the review asked for. `golden` nests its decision under `gate`; the others
    carry `passed` at the top level, and that shape difference is read here once rather than at
    every call site — which is how a caller comes to check the wrong key and always see None.
    """
    failures, evaluated, missing = [], [], []
    for key, name, required in CANDIDATE_VERDICTS:
        block = m.get(key) or {}
        # `golden` is {reference, summary, gate:{passed}}; everything else is {passed}.
        decision = (block.get("gate") or {}) if key == "golden" and "gate" in block else block
        passed = decision.get("passed")
        if passed is True:
            evaluated.append(name)
        elif passed is False:
            evaluated.append(name)
            det = decision.get("failures") or decision.get("unapproved") or []
            failures.append(f"{name} FAILED" + (f": {det[0]}" if det else ""))
        elif required:
            failures.append(f"{name} has NO verdict — nothing asked whether this candidate passed "
                            f"it, and 'not asked' is not 'passed'")
        else:
            missing.append(name)
        # An UNAPPROVED difference is a failure even when `passed` was set True by an older writer:
        # the differential's whole point is that a change nobody accepted must stop the run.
        if key == "differential" and decision.get("unapproved") and passed is not False:
            failures.append(f"{name}: {len(decision['unapproved'])} unapproved change(s) — "
                            f"{decision['unapproved'][0]}")
    return {"passed": not failures, "failures": failures,
            "evaluated": evaluated, "not_evaluated": missing}


# HOW A PUBLISH PATH CAME TO BE OPEN. `run_rwdp` writes exactly these three into
# `run_mode.published_under`; the vocabulary lives here so the writer and the validator cannot
# drift into two spellings of the same idea.
PUBLISHED_UNDER = ("release_ready", "allow_dev_publish", "not_published")


# WHAT AN ARTIFACT IS, DECLARED RATHER THAN GUESSED FROM ITS NAME. A closed vocabulary, so an
# unrecognised kind is REPORTED and never silently treated as the one that needs least evidence.
#
# THE RULE THIS REPLACES CLASSIFIED BY NAME: anything called `artifact_root`, or beginning `tfl_`,
# skipped the digest requirement. That was written as "the smallest correct fix" and it is not a
# correct one — an audit put a real FILE at `tfl_qc_report` and it reached the exemption, so the
# strongest evidence a receipt can carry was opt-out by rename. Which kind of thing an artifact is
# is a fact the WRITER knows and nothing downstream can infer.
ARTIFACT_TYPES = ("file", "directory", "delta_table")

# WHAT THE WRITER MUST SAY IT DID, for every artifact that is a FILE. A digest alone records a
# VALUE; these record the ACT that produced it — bytes read, how many of them, when, and by whom.
#
# WHY THE ACT AND NOT ONLY THE VALUE. `_artifact_errors` verifies digests against bytes wherever
# the path is readable, and a committed receipt's paths are readable on the cluster that wrote
# them and nowhere else. From a checkout, a receipt naming a real volume path and a receipt naming
# a path that exists NOWHERE are the same observation: unreadable. Requiring the attestation makes
# the two DIFFERENT observations, because the run that wrote the file could always reach it and a
# receipt assembled by hand has nothing to attest from.
#
# WHAT THIS IS NOT. It is not proof. It is the writer's own word, and a forger who is already
# fabricating a digest can fabricate three more fields beside it. `_attestation_errors` binds it as
# tightly to the digest as a data check can — the attested sha256 must BE the recorded digest, so
# the attestation is the same claim restated rather than a second, independently forgeable one —
# and the whole block sits inside the bytes `_manifest_sha` covers, so Gate 6 signs it and it
# cannot be fitted afterwards. What it converts is SILENCE: an unreadable path with no attestation
# used to be indistinguishable from an honest one, and is now a finding.
ARTIFACT_ATTESTATION_FIELDS = ("sha256", "bytes", "digested_at", "by")


def _parse_ts(value):
    """An ISO timestamp WITH a UTC offset, or None. Naive is None on purpose: `built_at` is
    offset-aware, and comparing it against a naive one raises rather than answering."""
    try:
        got = datetime.fromisoformat(str(value).strip().replace("Z", "+00:00"))
    except (TypeError, ValueError):
        return None
    return got if got.tzinfo is not None else None


def _attestation_errors(name, att, dig, built_at):
    """Problems with ONE file artifact's write-time attestation ([] = well formed).

    THE FIELDS ARE CHECKED AGAINST EACH OTHER AND AGAINST THE RECEIPT, never merely for presence:
    a block of four filled-in strings that agrees with nothing is the shape check this whole rule
    exists to stop being.

      sha256       must BE `artifacts[<name>_sha256]`. This is the join that keeps the attestation
                   from being a second forgeable surface — it cannot say anything the digest does
                   not already say, so wherever the digest is checkable the attestation is too.
      bytes        a non-negative integer, compared against the real file size by the caller
                   wherever the path can be read. A length is refutable by a `stat`, which is
                   cheaper than a re-read for whoever can reach the volume.
      digested_at  offset-aware, and NOT AFTER `built_at`. The manifest already carried the digest
                   when it was assembled, so bytes read afterwards are not the bytes it records.
      by           non-empty, so the word is attributable to a writer rather than to nobody.
    """
    if not isinstance(att, dict) or not att:
        return [f"status 'released' file artifact {name!r} records a digest but no "
                f"artifact_attestation[{name!r}] — the digest is verified against bytes wherever "
                f"the path can be read, and a committed receipt's paths are readable on the "
                f"cluster that wrote them and nowhere else. Without the writer's statement that it "
                f"took this digest from bytes it read, an unreadable path that exists nowhere is "
                f"indistinguishable from an honest volume path. `run_rwdp.py` records this beside "
                f"every digest it takes; a receipt lacking it was not written by the runner"]
    out = []
    for field in ARTIFACT_ATTESTATION_FIELDS:
        if att.get(field) in (None, ""):
            out.append(f"status 'released' artifact_attestation[{name!r}] states no {field!r} — "
                       f"the attestation records the ACT that produced the digest, and it needs "
                       f"all of {ARTIFACT_ATTESTATION_FIELDS} to be one")
    if out:
        return out
    stated = str(att.get("sha256")).strip().replace("sha256:", "")
    if stated != dig.replace("sha256:", ""):
        out.append(f"status 'released' artifact_attestation[{name!r}] attests {stated[:20]}… but "
                   f"the receipt records {dig.replace('sha256:', '')[:20]}… as {name}_sha256 — the "
                   f"receipt states two different digests for one artifact, so at most one of them "
                   f"describes what was written and nothing here says which")
    n = att.get("bytes")
    if not isinstance(n, int) or isinstance(n, bool) or n < 0:
        out.append(f"status 'released' artifact_attestation[{name!r}] records bytes={n!r}, which "
                   f"is not a byte count — it is the one field a reader who can reach the volume "
                   f"can refute without re-reading the file")
    when = _parse_ts(att.get("digested_at"))
    if when is None:
        out.append(f"status 'released' artifact_attestation[{name!r}] records digested_at="
                   f"{str(att.get('digested_at'))[:32]!r}, which is not an ISO timestamp carrying "
                   f"a UTC offset — a time with no offset does not say when")
    else:
        made = _parse_ts(built_at)
        if made is not None and when > made:
            out.append(f"status 'released' artifact_attestation[{name!r}] says the bytes were read "
                       f"at {att.get('digested_at')}, after this manifest was assembled at "
                       f"{built_at} — the manifest already carried the digest, so bytes read "
                       f"afterwards are not the bytes it records")
    return out


def _artifact_errors(m):
    """(errors, unverified) for a released receipt's `artifacts` map.

    THE DISTINCTION THAT MAKES THIS EVIDENTIARY. Three audits had established that a receipt's
    artifact digests were checked for SHAPE — 64 hex characters — and never against bytes. Every
    one of these passed: a fabricated digest for a real file, the honest digest OF A DIFFERENT
    FILE, a path that does not exist, and an artifacts map that was simply EMPTY. A digest nothing
    compares is a decoration with a plausible length.

    AND WHY IT CANNOT SIMPLY OPEN THE FILE. A committed receipt names artifacts on a Databricks
    volume — `/Volumes/...`, `dbfs:/...`, or a build-scoped `_artifacts/<tumor>/<refresh>/<build>`
    root that exists on the cluster and nowhere else. CI cannot read any of them, so a rule that
    demanded a byte comparison would refuse every honest receipt, and one that passed when the file
    was missing would be the shape check again wearing a longer docstring.

    SO REACHABILITY IS A THIRD ANSWER, not a silent branch of the other two:

        reachable, bytes match      verified
        reachable, bytes differ     FAILURE - and this is the case a swap after signing produces
        not reachable               UNVERIFIED, returned separately and reported by name

    The run that WROTE the artifact could always reach it, which is why `run_rwdp.py` records the
    digest at write time; this is the check that the record still describes the file wherever the
    file can be seen, and an honest statement of where it could not be seen.

    THE RESIDUAL GAP AND WHAT NOW STANDS IN IT. A receipt naming a path that exists NOWHERE is
    still, from a checkout, the same observation as one naming a real cluster path: both are
    unreadable. What separates them is `artifact_attestation` — the writer's statement, recorded at
    the moment it wrote each file and beside the digest it took, that this digest came from bytes
    it read, of this length, at this time. A released receipt is REFUSED without one for every file
    artifact it names, so an unreadable unattested path is now a finding rather than news.

    AND WHAT AN ATTESTATION DOES NOT ESTABLISH, stated because it is the writer's own word. It does
    not prove the file exists now, nor that the writer read the file it names. What it does is
    remove SILENCE as an option and make the claim specific: see `ARTIFACT_ATTESTATION_FIELDS` for
    why fabricating it is no easier than fabricating the digest, and no harder either.
    """
    import hashlib as _hashlib
    arts = m.get("artifacts") or {}
    types = m.get("artifact_types") or {}
    atts = m.get("artifact_attestation")
    atts = atts if isinstance(atts, dict) else {}
    out, unverified = [], []

    # NAMED ARTIFACTS ONLY. `<name>_sha256` and `<name>_staged_as` entries are the evidence
    # FOR a name, not names in their own right — treating them as artifacts would demand a
    # digest of a digest, and a type for a pin.
    named = [(k, str(v).strip()) for k, v in sorted(arts.items())
             if not k.endswith(("_sha256", ARTIFACT_TABLE_PIN)) and str(v or "").strip()]

    # THE OMISSION ATTACK, WHICH THE OLD RULE DID NOT SEE AT ALL. Every check above iterated the
    # map, so an EMPTY map satisfied all of them vacuously: a receipt could be marked `released`,
    # signed at Gate 6, and name nothing whatsoever as having been published. `released` is set
    # only after a successful publish, so a receipt that published nothing is a contradiction.
    if not named:
        out.append("status 'released' names no artifacts — the receipt records a successful "
                   "publish and then lists nothing that was published, so the approval signs an "
                   "empty statement. Every loop below iterates this map, which is why an empty "
                   "one satisfied all of them without examining anything")
        return out, unverified

    for name, path in named:
        kind = str(types.get(name) or "").strip()
        if kind not in ARTIFACT_TYPES:
            out.append(f"status 'released' artifact {name!r} declares kind "
                       f"{kind or '(unstated)'!r}, which is not one of {ARTIFACT_TYPES} — the old "
                       f"rule guessed from the name and a real file called 'tfl_report' therefore "
                       f"escaped the digest requirement by being named that")
            continue
        if kind == "delta_table":
            # A TABLE'S IDENTITY IS NOT ITS BYTES. `table_id` plus `delta_version` survives a
            # rewrite that reproduces identical bytes at a different version, which a digest
            # cannot distinguish. That pin lives in `candidate_identity` — which is keyed by the
            # STAGING table name, while this map records the PUBLIC one, so for one release this
            # branch was an OPEN GAP stated in as many words: nothing in the receipt could
            # resolve a named artifact to the identity that pins it, and a first attempt to
            # close it by demanding `candidate_identity[<artifact name>]` was dropped for being
            # a rule about a receipt shape no runner produces.
            #
            # THE WRITER NOW PRODUCES THE MAPPING: `<name>_staged_as` carries the
            # `candidate_identity` key beside the artifact it pins, so this branch can ask a
            # table the same question the file branch asks a file — not where it is, but WHICH
            # BYTES. Absence refuses, exactly as a missing digest does: an artifact whose
            # physical identity the receipt cannot state is one the approval did not sign. A
            # candidate staged by an earlier runner has no such key and is refused at `_pre_bad`
            # with nothing public moved — unstated is not unchanged, and the remedy is to re-run
            # the candidate.
            stg = str(arts.get(name + ARTIFACT_TABLE_PIN) or "").strip()
            if not stg:
                out.append(f"status 'released' names table artifact {name!r} with no "
                           f"{name}{ARTIFACT_TABLE_PIN} — a Delta table is pinned by its "
                           f"table_id and delta_version, and without the staged name those were "
                           f"recorded under, nothing in this receipt can reach them")
                continue
            pin = (m.get("candidate_identity") or {}).get(stg)
            if not isinstance(pin, dict):
                out.append(f"status 'released' artifact {name!r} is staged as {stg!r} and "
                           f"candidate_identity records no such table — the approval signed "
                           f"identities for other tables and none for this one")
                continue
            if not str(pin.get("table_id") or "").strip():
                out.append(f"status 'released' artifact {name!r} has no table_id under "
                           f"candidate_identity[{stg!r}] — a version alone is satisfied by a "
                           f"dropped-and-recreated table with a different transaction log")
            # `delta_version: 0` IS A VERSION — the first write of every table. A truthiness
            # test would refuse precisely the tables nothing had rewritten yet, and `bool` is
            # an `int`, so `True` would have passed as one.
            dv = pin.get("delta_version")
            if not isinstance(dv, int) or isinstance(dv, bool):
                out.append(f"status 'released' artifact {name!r} has no integer delta_version "
                           f"under candidate_identity[{stg!r}] — an unversioned table is one "
                           f"`VERSION AS OF` cannot resolve, so the bytes that were approved "
                           f"cannot be read back")
            continue
        if kind == "directory":
            # A CONTAINER IS NOT EVIDENCE, and demanding a digest of one was the defect that made
            # this rule refuse every runner-shaped receipt before the first real one existed. What
            # it holds is pinned by the entries that name those files.
            continue
        dig = str(arts.get(name + "_sha256") or "").strip()
        if not dig:
            out.append(f"status 'released' names file artifact {name!r} with no {name}_sha256 — "
                       f"the approval would sign that a file existed at a path, and a path is not "
                       f"its contents")
            continue
        if not _re.match(r"^(sha256:)?[0-9a-f]{64}$", dig):
            out.append(f"status 'released' artifact {name!r} records {dig[:24]!r} as its sha256, "
                       f"which is not one")
            continue
        #...AND THE WRITER MUST HAVE SAID IT TOOK THAT DIGEST FROM BYTES. Checked BEFORE the
        # read below and independently of whether it succeeds: this is the half of the evidence
        # that survives the path being unreachable, which is the ordinary case in CI and the case
        # a receipt naming a path that exists nowhere used to hide inside.
        att = atts.get(name)
        att_errors = _attestation_errors(name, att, dig, m.get("built_at"))
        out += att_errors
        #...AND WHERE THE FILE CAN BE READ, THE DIGEST MUST DESCRIBE IT. This is the whole of the
        # difference between a syntactic check and an evidentiary one.
        try:
            if not _os.path.isfile(path):
                # WHOSE WORD STANDS BEHIND THIS DIGEST, on the same line as the fact that nothing
                # here re-read it. "Not re-read HERE" and "nobody ever read it" are different
                # facts, and a reader given only the first cannot tell which one they have.
                whose = (f"attested by {att['by']} at {att['digested_at']}, {att['bytes']} bytes"
                         if not att_errors else "and its attestation is missing or malformed")
                unverified.append(f"{name} ({path} is not readable here, {whose})")
                continue
            size = _os.path.getsize(path)
            h = _hashlib.sha256()
            with open(path, "rb") as fh:
                for chunk in iter(lambda: fh.read(1 << 16), b""):
                    h.update(chunk)
            now = h.hexdigest()
        except OSError as exc:
            # CANNOT READ IS NOT CANNOT MATCH. A permission error is a reason this check could not
            # speak, and reporting it as a mismatch would accuse a receipt of something no one has
            # established.
            unverified.append(f"{name} ({type(exc).__name__} reading {path})")
            continue
        if now != dig.replace("sha256:", ""):
            out.append(f"status 'released' artifact {name!r} records {dig[:20]}… but the file at "
                       f"{path} digests to {now[:20]}… — the artifact was replaced after its "
                       f"digest was recorded, which is precisely what signing a digest is meant "
                       f"to detect")
        #...AND THE ATTESTED LENGTH MUST BE THE FILE'S LENGTH. A separate fact from the digest and
        # worth stating separately: a matching digest with a wrong byte count is an attestation
        # somebody filled in beside a digest they did not take, which is exactly the hand-assembly
        # this rule exists to distinguish from a run.
        if not att_errors and att["bytes"] != size:
            out.append(f"status 'released' artifact_attestation[{name!r}] attests {att['bytes']} "
                       f"bytes but the file at {path} is {size} — the writer's statement and the "
                       f"artifact disagree about the artifact")
    # AN ATTESTATION OF SOMETHING THIS RECEIPT DOES NOT PUBLISH. `named` is the closed list of what
    # was released; a block keyed by anything else attests to a file the receipt does not claim,
    # and a reader scanning the attestations would count it as covered evidence.
    _files = {n for n, _p in named if str(types.get(n) or "").strip() == "file"}
    for key in sorted(atts):
        if key not in _files:
            out.append(f"status 'released' carries artifact_attestation[{key!r}], which is not a "
                       f"file artifact this receipt names — an attestation is evidence FOR a "
                       f"published artifact, and one standing beside nothing inflates what a "
                       f"reader counts as attested")
    return out, unverified


def unverified_artifacts(m):
    """[artifacts whose bytes could not be read HERE], as news rather than as failure.

    A receipt is written on a cluster and validated in CI, and the volume paths it names do not
    exist in a checkout. That is the ordinary case and must never fail a run. What must not happen
    is for it to be reported as a verified one — a check that read zero of six artifacts and said
    what a check that read all six says has told the reader something untrue by omission.

    UNVERIFIED IS NOW UNVERIFIED-AND-ATTESTED. Each entry carries the writer's statement of when it
    read those bytes and how many there were, because a released receipt is refused without one
    (`_artifact_errors`). So this list means "not re-read HERE", never "nobody ever read it".
    """
    if m.get("status") != "released":
        return []
    return _artifact_errors(m)[1]


_MAPPING_FIELDS = ("counts", "sign_off", "source_lineage", "release", "content", "qc",
                   "tfl_promotion", "deliverables", "golden", "source_qc_gate", "config_identity",
                   "runtime", "run_mode", "candidate_identity",
                   # audit 8: every object-typed field the schema declares, not the first fourteen
                   "artifact_types", "source_qc", "stage_telemetry", "eda", "differential",
                   "output_contract", "source_grain", "retention", "eda_acceptance", "deployment",
                   "adapter_binding", "promoted_from", "validate_only",
                   "linkage", "publication_surface", "candidate_verdict")


def validate_manifest(m: dict) -> list:
    """Return a list of problems with a manifest (empty = valid). Pure data check — and a
    malformed SHAPE is a finding too, never an exception (audit 6: an int where a mapping belongs
    raised AttributeError out of a validator that presents itself as finding-returning)."""
    if not isinstance(m, dict):
        return [f"manifest is not a mapping (got {type(m).__name__})"]
    out = []
    bad = {k for k in _MAPPING_FIELDS if m.get(k) is not None and not isinstance(m.get(k), dict)}
    for k in sorted(bad):
        out.append(f"manifest {k} must be a mapping, got {type(m.get(k)).__name__}")
    m = {k: ({} if k in bad else v) for k, v in m.items()}     # the rest reads a sane shape
    # ...AND THE SCALARS AND NESTED VALUES ARE TYPED TOO (audit 7: `tumor: 5` returned zero
    # findings because the identifier grammar accepted an int; nested ints raised)
    for k in ("tumor", "refresh", "spec_version", "built_at", "family", "vendor", "git_commit",
              "output_table", "published_at", "superseded_by", "reproduction_id"):
        if m.get(k) is not None and not isinstance(m.get(k), str):
            out.append(f"manifest {k} must be a string, got {type(m.get(k)).__name__}")
            m[k] = str(m[k])
    if m.get("artifacts") is not None and not isinstance(m.get("artifacts"), (list, dict)):
        out.append(f"manifest artifacts must be a list or mapping, got {type(m.get('artifacts')).__name__}")
        m["artifacts"] = []
    for k in ("source_lineage", "deliverables", "sign_off", "candidate_identity"):
        v = m.get(k)
        if isinstance(v, dict):
            for kk, vv in list(v.items()):
                if k == "sign_off":
                    if vv is not None and not isinstance(vv, str):
                        out.append(f"manifest sign_off.{kk} must be a string, got {type(vv).__name__}")
                        v[kk] = str(vv)
                elif vv is not None and not isinstance(vv, (dict, list, str)):
                    out.append(f"manifest {k}.{kk} must be a mapping, list or string, got {type(vv).__name__}")
                    v[kk] = {}
    if isinstance(m.get("qc"), dict) and "passed" in m["qc"] and not isinstance(m["qc"]["passed"], bool):
        out.append(f"manifest qc.passed must be a boolean, got {type(m['qc']['passed']).__name__}")
    if isinstance(m.get("release"), dict) and m["release"].get("build_id") is not None \
            and not isinstance(m["release"]["build_id"], str):
        out.append(f"manifest release.build_id must be a string, got {type(m['release']['build_id']).__name__}")
    for k in REQUIRED:
        if k not in m or m[k] in (None, ""):
            out.append(f"manifest missing '{k}'")
    # THE STORED COMPOSED VERDICT AGREES WITH ITS BLOCKS. A manifest carries one answer; a copy
    # edited apart from the stages it summarises is two answers, and the blocks are the evidence.
    stored = m.get("candidate_verdict")
    if isinstance(stored, dict) and stored:
        live = candidate_verdict(m)
        if stored.get("passed") != live["passed"] or list(stored.get("failures") or []) != live["failures"]:
            out.append("manifest candidate_verdict disagrees with the verdict its own blocks compose — "
                       f"stored passed={stored.get('passed')}, blocks say passed={live['passed']}"
                       + (f" ({live['failures'][0]})" if live["failures"] else ""))
    # THE IDENTIFIERS ARE PATH SEGMENTS AND SQL IDENTIFIERS, so they get a grammar, not a presence
    # check: `manifest_path`, `release_dir`, `versioned_ads` and the artifact dir all interpolate
    # them raw, and a refresh of `../../../../governance/publish_targets` validated and resolved
    # OUTSIDE refreshes/ (external audit, 2026-09-02). One segment: alphanumerics plus . _ -, no
    # separators, never a dot-run — containment is then structural rather than checked after the
    # fact at every consumer.
    for k, kind in (("tumor", "sql"), ("refresh", "sql"), ("build_id", "sql"),
                    ("spec_version", "path"), ("family", "path")):
        v = m.get(k)
        if v in (None, ""):
            continue
        why = unsafe_identifier(kind, v)
        if why:
            out.append(f"manifest {k}: {why}")
    # ...AND WHERE THE BUILD ID ACTUALLY LIVES. Real manifests carry it under `release.build_id`;
    # the first audit's check looked only at a top-level key no manifest writes, and
    # `release.build_id = '../../evil'` reached a table name (second audit).
    rel_bid = (m.get("release") or {}).get("build_id") if isinstance(m.get("release"), dict) else None
    if rel_bid not in (None, ""):
        why = unsafe_identifier("sql", rel_bid)
        if why:
            out.append(f"manifest release.build_id: {why}")
    if m.get("status") not in STATUSES:
        out.append(f"status '{m.get('status')}' not one of {STATUSES}")
    # A SUPERSEDED RECEIPT IS A RELEASED RECEIPT WITH A SUCCESSOR. It keeps every released-record
    # requirement below (a six-field `superseded` receipt passed with 0 errors while the identical
    # `released` one had 28 — fourth audit) and adds the one thing supersession means: which later
    # refresh replaced it.
    if m.get("status") == "superseded" and not str(m.get("superseded_by") or "").strip():
        out.append("status 'superseded' requires superseded_by (the refresh label that replaced "
                   "this release) — relabelling a receipt is not evidence of a successor")
    if m.get("status") in ("released", "superseded"):
        # ALL FOUR, not just the release approver: Gate 5's reviewer (qc_by/qc_date) was dropped
        # during promotion, so the receipt said who released and not who reviewed the evidence.
        for _f in ("released_by", "released_date", "qc_by", "qc_date"):
            if not m.get("sign_off", {}).get(_f):
                out.append(f"status 'released' requires sign_off.{_f}")
        if not m.get("git_commit"):
            out.append("status 'released' requires git_commit (reproducibility)")
        #...AND THE OTHER HALF OF THAT REPRODUCTION CLAIM. `reproduction_id` says two runs got
        # the same INPUTS; `content.digest` says what they PRODUCED, and this file says so at the
        # top: the two are "kept strictly independent — same inputs and a different content digest
        # is a real finding". Nothing required it, so a receipt could claim `released` carrying
        # only the left-hand side.
        #
        # COMPUTING IT STAYS BEST-EFFORT; RELEASING WITHOUT IT DOES NOT. `run_rwdp` deliberately
        # catches a digest failure into `content.error` rather than killing the build - "a build
        # must not die computing a witness to itself" - and that is right for a BUILD. It is not
        # right for a RELEASE: a receipt recording that the witness could not be taken is evidence
        # of exactly that, and publishing it as governed evidence of a reproducible cut asserts
        # something the receipt itself denies. An external audit found the gap while it is still
        # free to close: there are zero refresh receipts, so nothing existing is invalidated.
        _content = m.get("content") or {}
        if _content.get("error"):
            out.append(f"status 'released' records that the content digest could not be computed "
                       f"({_content[chr(101)+chr(114)+chr(114)+chr(111)+chr(114)]}) — a receipt "
                       f"that states its own reproduction witness is missing cannot evidence a "
                       f"reproducible release. Re-run the build; do not hand-edit this field")
        elif not str(_content.get("digest") or "").strip():
            out.append("status 'released' requires content.digest — `reproduction_id` says two "
                       "runs received the same inputs and says nothing about what they produced. "
                       "Without the digest of the published cells, a reproduction claim has only "
                       "its left-hand side")
        elif not _re.match(r"^(sha256:)?[0-9a-f]{64}$", str(_content.get("digest")).strip()):
            # STATED IS NOT SHAPED. `content.digest: x` satisfied a non-emptiness test, so the
            # field that carries the reproduction witness could hold any string at all.
            out.append(f"status 'released' content.digest "
                       f"{str(_content.get(chr(100)+chr(105)+chr(103)+chr(101)+chr(115)+chr(116)))[:24]!r} "
                       f"is not a sha256 — a value that was never a digest witnesses nothing")
        #...AND THE INPUTS THE ID IS TAKEN OVER MUST BE THERE. `REPRODUCTION_INPUTS` names what a
        # rebuild has to match, and three of them carry the identity of the CODE, the
        # CONFIGURATION and the RUNTIME. A receipt with `tree_sha256: null` and empty
        # `config_identity`/`runtime` still produced a `reproduction_id` — a digest over absences,
        # which two unrelated runs would agree on precisely because neither said anything.
        for _f in ("tree_sha256", "config_identity", "runtime"):
            if not m.get(_f):
                out.append(f"status 'released' requires {_f} — it is one of the inputs "
                           f"`reproduction_id` is taken over, and an id computed across an absent "
                           f"one is agreed to by every run that also omitted it")
        #...AND THE ID MUST BE THE ONE THESE INPUTS PRODUCE. `reproduction_id` is deliberately
        # re-derivable by anyone — its own docstring says "a build cannot assert its own
        # reproducibility" — and nothing recomputed it, so the field could be any string and the
        # claim rested on the writer's good faith rather than on arithmetic.
        #...AND EVERY ARTIFACT THE RECEIPT NAMES MUST BE PINNED BY ITS BYTES. The EDA report
        # already does this and says why: the digest "the Gate 6 approval signs covers it, and
        # an eda_report.json swapped after signing no longer matches its recorded hash".
        # Dictionaries and the dashboard manifest recorded a PATH and a status, so the approval
        # signed the fact that a file existed at a location - and a location is not bytes. Any
        # of them could be regenerated, edited or replaced after signing with the receipt
        # unchanged and every check still green.
        # NOT EVERY ARTIFACT IS A FILE, and demanding a byte digest of one that is not was a
        # defect in this rule rather than strictness. An audit found it BEFORE the first real
        # receipt existed, which is the only reason it costs nothing:
        #
        # artifact_root a DIRECTORY - the container everything else is written into. The
        # runner records it on every manifest, so this rule as first written
        # refused EVERY runner-shaped receipt before it could be promoted.
        # tfl_* a Delta TABLE, whose identity is its table_id and delta_version,
        # captured at the write and verified at signing as
        # `candidate_identity`. That is a STRONGER pin than a file hash: it
        # survives a rewrite that reproduces identical bytes at a different
        # version, which a digest cannot distinguish.
        #
        # Classified by NAME here because the writer emits a flat map. Explicit per-entry
        # types (file / directory / delta_table) would be better and are the right next
        # change; this is the smallest correct fix that does not require reshaping what the
        # runner writes, and `test_a_runner_shaped_receipt_validates` holds it to real output.
        #...AND THE DIGESTS MUST DESCRIBE THE BYTES, NOT MERELY LOOK LIKE DIGESTS. See
        # `_artifact_errors`: every check here was a SHAPE check, so a fabricated digest, the
        # honest digest of a different file, a path that does not exist and an EMPTY map all
        # passed. Types are declared rather than guessed from the name, which is how a real file
        # called `tfl_report` used to reach the exemption meant for Delta tables.
        _art_errors, _art_unverified = _artifact_errors(m)
        out += _art_errors
        _stated = str(m.get("reproduction_id") or "").strip()
        if not _stated:
            out.append("status 'released' requires reproduction_id")
        elif _stated != reproduction_id(m):
            out.append(f"status 'released' reproduction_id {_stated[:16]}… is not what these "
                       f"inputs produce ({reproduction_id(m)[:16]}…) — the receipt names inputs it "
                       f"was not taken over, so the id certifies a run that did not happen")
        # 'released' is set only AFTER a successful publish (refreshes/README.md step 5) -> it must carry
        # the publish timestamp, the release pointer (the versioned set that went live), AND a passed
        # tfl_promotion (the public views were swapped) — not just QC. The runner sets passed False on a
        # release-phase failure and True only after every public view swaps, so this rejects a released
        # manifest whose swap never completed.
        if not m.get("published_at"):
            out.append("status 'released' requires published_at (a released refresh was published)")
        if m.get("release") is None:
            out.append("status 'released' requires a release pointer (the versioned set that went live)")
        if not (m.get("tfl_promotion") or {}).get("passed"):
            out.append("status 'released' requires tfl_promotion.passed True (the public views swapped)")
        # GATE 5, RE-DERIVED FROM THE RECEIPT'S OWN EVIDENCE — not read off the status word. A
        # manifest saying `released` with its own qc block saying `passed: false` used to validate:
        # every check above asks about the RELEASE (pointer, swap, sign-off) and none asked whether
        # the thing released had passed the gates that authorise a release. The receipt carries the
        # evidence; a validator that does not read it certifies a contradiction.
        if (m.get("qc") or {}).get("passed") is not True:
            out.append("status 'released' requires qc.passed True — this receipt's own QC block "
                       "says the released build failed QC or never ran it")
        # THE RUNNER'S ACTUAL STRUCTURES, not lookalikes. The first version of this block read a
        # top-level `golden.passed` — a key the runner never writes (it writes `golden.gate.passed`)
        # — so an adversarial receipt carrying the runner's REAL failed structure validated with no
        # errors, which an external review demonstrated. Every check below names the field the
        # runner writes, and absence is a refusal, never a pass: for a released receipt, missing
        # evidence and failed evidence are the same answer.
        _g = m.get("golden") or {}
        if str(_g.get("reference") or "").strip() in ("", "none"):
            out.append("status 'released' requires a golden comparison against a named reference — "
                       "`reference: none` (or absent) is a build nobody compared, and a release is "
                       "not the place to find that out")
        else:
            if ((_g.get("gate") or {}).get("passed")) is not True:
                out.append("status 'released' requires golden.gate.passed True — this receipt's "
                           "own golden gate records a failure, or never ran")
            _gi = _g.get("identity") or {}
            if not (_gi.get("table_id") and _gi.get("location")):
                out.append("status 'released' requires golden.identity {table_id, location} — an "
                           "unpinned reference can be swapped for another table between the "
                           "comparison and the reader")
        # THE PATIENT-LEVEL DIFFERENTIAL, held to the same standard as golden and the output
        # contract — and it was the one gate a released receipt never had to carry. `golden`
        # compares AGGREGATES against a reference build; the differential is the only check that
        # asks whether an individual patient's published row changed, which is the question a
        # refresh exists to answer. `CANDIDATE_VERDICTS` marks it not-required on purpose, because
        # a candidate may legitimately have nothing to compare against; a RELEASE is where that
        # stops being an acceptable answer, exactly as it does for golden two clauses above.
        #
        # THE FIRST RELEASE IS REAL AND IS NAMED RATHER THAN ASSUMED. A product's first refresh has
        # no prior ADS, so requiring a comparison unconditionally would make a first release
        # impossible. It is recorded as an attributed absence — a person says there is no prior and
        # why — because "there was nothing to compare" and "nobody compared" are different facts
        # and only the first one is a decision anybody made.
        _d = m.get("differential") or {}
        if str(_d.get("reference") or "").strip() in ("", "none"):
            _np = _d.get("no_prior") or {}
            if not (_np.get("reason") and _np.get("approved_by")):
                out.append(
                    "status 'released' requires a patient-level differential against the prior "
                    "refresh — or, for a first release with no prior, differential.no_prior "
                    "{reason, approved_by}: a named person stating that there is nothing to "
                    "compare and why. An absent differential is not an approved one, and it is "
                    "the only check that asks whether an individual patient's row changed")
        else:
            if _d.get("passed") is not True:
                out.append("status 'released' requires differential.passed True — this receipt "
                           "records a failed patient-level comparison, or none was run against "
                           "the reference it names")
            if _d.get("unapproved"):
                out.append(
                    f"status 'released' with {len(_d['unapproved'])} unapproved patient-level "
                    f"change(s) ({_d['unapproved'][0]}) — a change nobody accepted is the whole "
                    f"reason the differential exists, and a release is the last place to find it")
        if ((m.get("source_qc_gate") or {}).get("passed")) is not True:
            out.append("status 'released' requires source_qc_gate.passed True — a released receipt "
                       "with no source-QC verdict (or a failed one) stands on unexamined inputs")
        # THE OUTPUT CONTRACT, and a MISSING one fails exactly as a failed one does. A receipt that
        # never asked whether its product was uniquely keyed, carried every configured cohort and
        # held only values its codelists enumerate is a receipt standing on an unexamined OUTPUT —
        # the mirror of the source-QC clause above, and the gap an external review found: the QC
        # gate scored four rates and could pass a duplicated or incomplete product.
        if ((m.get("output_contract") or {}).get("passed")) is not True:
            out.append("status 'released' requires output_contract.passed True — a released receipt "
                       "with no output-contract verdict (or a failed one) stands on an unexamined "
                       "product: nothing has checked its grain, its cohorts or its vocabularies")
        #...AND THE VERDICT MUST HAVE BEEN STRICT. `passed` is True on a non-strict run whose
        # declared checks were never configured — the gate prints each one as UNCONFIGURED and
        # passes anyway, which is the right behaviour for a technical test run and the wrong one
        # here: an external review put it as "a technical test run can report incomplete checks;
        # publication must not." Without this clause, `qc.output_contract_strict` was a flag every
        # release-bound pack was supposed to set and nothing required — a control that depends on
        # remembering, which is the shape this repository keeps converting into mechanism. Both
        # halves checked, belt over braces: strict recorded in the report the verdict ran over, and
        # the unconfigured list actually empty — trusting `strict` alone would trust a flag, and
        # trusting emptiness alone would pass a report that never distinguished the states.
        _oc = m.get("output_contract") or {}
        if ((_oc.get("report") or {}).get("strict")) is not True:
            out.append("status 'released' requires the output contract to have run STRICT "
                       "(qc.output_contract_strict: true) — a non-strict pass may carry declared "
                       "checks nobody configured, and a release must not stand on checks that "
                       "never ran")
        for _u in _oc.get("unconfigured") or []:
            out.append(f"status 'released' with an unconfigured output-contract check: {_u} — "
                       f"configure it, or it ships unexamined under a green verdict")
        # THE PUBLISH SURFACE, half of G6: a released receipt must show the approved ordered
        # column whitelist was DECLARED and checked. The strict clause above already fails an
        # undeclared whitelist inside the verdict; this reads the evidence directly, belt over
        # braces, because a receipt is the artifact a person audits.
        if (((_oc.get("report") or {}).get("publish")) or {}).get("declared") is not True:
            out.append("status 'released' requires the output contract to have checked the "
                       "approved publish whitelist (qc.publish_columns) — without it every "
                       "joined internal helper column ships under a green verdict")
        # THE PATIENT DIFFERENTIAL, which had no clause here at all. The clauses above are precise
        # and are what a reader sees; this is the backstop that makes the SET complete, because the
        # defect was never a badly worded clause — it was a gate with no clause, and a fifth one
        # added tomorrow would land the same way. `candidate_verdict` owns the list.
        for _f in candidate_verdict(m)["failures"]:
            if not any(_f.split(" FAILED")[0].split(" has NO")[0] in existing for existing in out):
                out.append(f"status 'released': {_f}")
        if not m.get("source_lineage"):
            out.append("status 'released' requires source_lineage — a released receipt that pins "
                       "no inputs cannot re-read what it published from")
        if not m.get("candidate_identity"):
            out.append("status 'released' requires candidate_identity — the staged-table identity "
                       "the approval was signed over is the receipt's subject, not an option")
        # DELIVERABLES: recorded, and each one either produced (`ok`) or honestly not configured
        # (`empty`). `skipped` and `failed` both mean the release shipped without something it was
        # asked to ship; a receipt with NO deliverables block recorded is a build that never
        # accounted for them at all.
        if not m.get("deliverables"):
            out.append("status 'released' requires a deliverables block — a release that recorded "
                       "no deliverable outcomes cannot claim they were produced")
        for _name, _d in sorted((m.get("deliverables") or {}).items()):
            _st = str((_d or {}).get("status") if isinstance(_d, dict) else _d)
            if _st not in ("ok", "empty"):
                out.append(f"status 'released' with deliverables.{_name} '{_st}' — every "
                           f"deliverable is `ok` (produced) or `empty` (none configured); anything "
                           f"else shipped without something it was asked to ship")
        # THE MODE THE CANDIDATE WAS BUILT IN, recorded — promotion additionally refuses a governed
        # (prod) publish of a candidate that does not record release-grade mode
        # (release.candidate_binding_blockers); the receipt merely has to SAY which mode it was.
        if not str(((m.get("run_mode") or {}).get("env")) or "").strip():
            out.append("status 'released' requires run_mode.env — a receipt that cannot say which "
                       "environment built it cannot evidence release-grade construction")
        #...AND WHICH KEY OPENED THE PUBLISH PATH. `env` says WHERE it ran and `release_grade`
        # says how it was BUILT; neither says whether the gates cleared it to be PUBLISHED. A run
        # publishing under `allow_dev_publish` is a deliberate publication of something that is
        # not release-ready, and a receipt that does not say so is indistinguishable afterwards
        # from a governed release - which is precisely what a citation reads. The runner has
        # computed this since the flag was added and nothing ever required it, so the one field
        # that separates the two kinds of publication was optional.
        #
        # REQUIRED, not defaulted: a missing value would read as `release_ready`, which is the
        # absence-reads-as-clean failure this whole module exists to refuse.
        _pub = str(((m.get("run_mode") or {}).get("published_under")) or "").strip()
        if not _pub:
            out.append("status 'released' requires run_mode.published_under - a receipt that "
                       "cannot say WHICH key opened the publish path cannot be told apart from a "
                       "governed release by anything that reads it later")
        elif _pub not in PUBLISHED_UNDER:
            out.append(f"status 'released' with run_mode.published_under {_pub!r}, which is not "
                       f"one of {PUBLISHED_UNDER}")
        elif _pub == "not_published":
            out.append("status 'released' with run_mode.published_under 'not_published' - the "
                       "receipt states the public views were never swapped")
        elif _pub == "allow_dev_publish":
            # A DEV PUBLICATION IS NOT A RELEASE. The dev key opens the swap for a pack that is
            # not release-ready so a team can look at public views; a receipt built that way in
            # the canonical ledger said `released` (audit 7).
            out.append("status 'released' with run_mode.published_under 'allow_dev_publish' — the dev "
                       "key opened the publish path; that is a dev publication, never a governed release")
        _rm = m.get("run_mode") if isinstance(m.get("run_mode"), dict) else {}
        _env = str(_rm.get("env") or "").strip().lower()
        if _env and _env != "prod":
            out.append(f"status 'released' with run_mode.env {_rm.get('env')!r} — a released receipt is "
                       f"built in prod; a dev build is a candidate, never a release")
        if _rm.get("release_grade") is not True:
            out.append("status 'released' requires run_mode.release_grade true — this candidate was not "
                       "built release-grade, so nothing it carries evidences a governed release")
    counts = m.get("counts") or {}
    if "total_rows" in counts and not isinstance(counts["total_rows"], int):
        out.append("counts.total_rows must be an integer")
    # source_lineage, when present, is shape-checked: every entry names its fqn and carries either
    # a probed identity (table_id + delta_version) or an error. A half-entry — identity fields with
    # neither id nor version, and no error — is a lineage that cannot re-read anything and would
    # ride the ledger looking like one that can.
    for src, entries in (m.get("source_lineage") or {}).items():
        if not isinstance(entries, list) or not entries:
            out.append(f"source_lineage['{src}'] must be a non-empty list of per-table entries")
            continue
        for e in entries:
            if not isinstance(e, dict) or not e.get("fqn"):
                out.append(f"source_lineage['{src}'] has an entry with no fqn")
            elif e.get("error") and m.get("status") in ("released", "superseded"):
                out.append(f"source_lineage['{src}'] {e.get('fqn')}: carries error, not a pinned "
                           f"identity — a RELEASED manifest may not claim inputs it never pinned")
            elif not e.get("error") and not (e.get("table_id") and e.get("delta_version") is not None):
                out.append(f"source_lineage['{src}'] {e.get('fqn')}: neither a probed identity "
                           f"(table_id + delta_version) nor an error — this pins nothing")
            elif not e.get("error") and m.get("status") in ("released", "superseded") and not e.get("location"):
                out.append(f"source_lineage['{src}'] {e.get('fqn')}: no storage location — a "
                           f"RELEASED receipt pins inputs physically (id + version + location), "
                           f"because a name re-pointed at another path is a different table")
    su = m.get("source_union")
    if su is not None and not (isinstance(su, dict) and su.get("members")):
        out.append("source_union must carry members when present")
    tp = m.get("tfl_promotion")
    if tp is not None and (not isinstance(tp, dict) or "passed" not in tp):
        out.append("tfl_promotion must record a 'passed' flag when present")
    rel = m.get("release")
    if rel is not None:
        if not isinstance(rel, dict):
            out.append("release must be a mapping when present")
        else:
            miss = [k for k in ("public", "version", "build_id", "ads", "views") if not rel.get(k)]
            if miss:
                out.append(f"release missing {miss} (public/version/build_id/ads/views required when present)")
            elif not isinstance(rel["views"], dict) or rel["views"].get(rel["public"]) != rel["ads"]:
                out.append("release.views must map the public name to release.ads "
                           "(views[public] == ads, the ADS view is the commit anchor)")
    if m.get("published_at") and rel is None:
        out.append("a published manifest (published_at set) must carry a release pointer")
    return out
