"""Build telemetry, as counts: what each stage did to the index, what each pick chose from.

Two kinds of rows. STAGE rows: per cohort per stage, did the join drop index patients, or fan
them out? SELECTION rows: per panel item, how many candidate records competed, how many tied on
one date, how many non-null values came out. The case this exists for: a configured name that
matches no delivered row makes an all-missing column, and nothing used to say so.

Cost model. record*() queues a small aggregate plan — no Spark action. report() collects the
plans in chunks (see CHUNK) — a bounded handful of jobs, never one per number. Off by default:
with telemetry=None the build path is unchanged. The opt-in is a RUN widget, not the science
config, so Gate 4's config digest cannot move.

Covered: every pick family (panels, lab values, staging, categoricals, ECOG, vitals, PSA points,
treatment lines, progression events). Not covered, each on purpose: death-date conflicts (source
QC already counts them), one-row-per-key collapses (grain declarations own that class), and pure
aggregates/flags (no candidate-vs-winner to report). A family a pack does not configure queues
nothing — absent from `selections` means "not measured", never "nothing selected".

Not a verdict. The report has no `passed` key. Expansion or loss can be a design, so a threshold
here would be one nobody approved. The ONE exception is the one this sentence always
reserved: a pack that DECLARES reviewed bounds (`qc.retention`) gets them held by
`retention_gate` - a separate verdict over this evidence, never a change to it. `observations` names the asymmetries in words. Counts only —
no patient id can appear, and tests assert that. This block travels into manifests and chat.
"""
from __future__ import annotations

# The stage-row metric names, in report order. Also the contract with report(): every stage plan
# emits exactly these keys in its metrics map.
_STAGE_METRICS = ("index_patients", "matched_patients", "unmatched_index_patients",
                  "patients_outside_index", "rows_out", "max_rows_per_index_patient")

# The selection-row metric names. `candidate_*` come from the pre-pick candidate frame;
# `non_null_outputs`/`output_rows` from the block's emitted frame — merged per item in report().
_SELECTION_METRICS = ("candidate_rows", "patients_with_candidates", "tied_same_date_keys",
                      "tied_rows", "non_null_outputs", "output_rows")


def _metrics_map(F, pairs):
    """A map<string,long> literal-keyed metrics column — the one schema every plan emits, so the
    report()-time union never depends on which KINDS of plan a build queued."""
    args = []
    for k, col in pairs:
        args.extend([F.lit(k), col.cast("long")])
    return F.create_map(*args)


def _tag(F, agg, kind: str, cohort: str, label: str, item):
    """The uniform row shape: (_seq set by the caller) kind/cohort/label/item + metrics."""
    return agg.select(
        F.col("_seq"), F.lit(kind).alias("kind"), F.lit(str(cohort)).alias("cohort"),
        F.lit(str(label)).alias("label"),
        (F.lit(str(item)) if item is not None else F.lit(None).cast("string")).alias("item"),
        F.col("metrics"))


def stage_stats_frame(F, idx, df, cohort: str, stage: str, seq: int = 0):
    """A ONE-ROW aggregate plan over `df` against the index population. No action.

    One full-outer join of two patient-level aggregates answers every question at once:

        index_patients             patients the cohort's index frame carries
        matched_patients           index patients with >= 1 row in this stage's output
        unmatched_index_patients   index patients this stage emitted NOTHING for
        patients_outside_index     patients this stage emitted that the index does not know
        rows_out                   total rows in the stage output (all patients)
        max_rows_per_index_patient the worst per-index-patient fan-out — the join-cardinality
                                   number: 1 means the stage held one-row-per-patient

    `_seq` is stamped into the row because report() unions these plans and the collected row
    order of a union is a Spark internal, not a promise — "build order" in the report must come
    from data, or a partition-count change would silently reorder the pipeline story.
    """
    per = df.groupBy("patientid").agg(F.count(F.lit(1)).alias("_n"))
    ix = idx.select("patientid").distinct().withColumn("_ix", F.lit(1))
    agg = (ix.join(per, "patientid", "full_outer").agg(
        F.count("_ix").alias("index_patients"),
        F.count(F.when(F.col("_ix").isNotNull() & F.col("_n").isNotNull(), 1))
         .alias("matched_patients"),
        F.count(F.when(F.col("_ix").isNotNull() & F.col("_n").isNull(), 1))
         .alias("unmatched_index_patients"),
        F.count(F.when(F.col("_ix").isNull(), 1)).alias("patients_outside_index"),
        F.coalesce(F.sum("_n"), F.lit(0)).alias("rows_out"),
        F.coalesce(F.max(F.when(F.col("_ix").isNotNull(), F.col("_n"))), F.lit(0))
         .alias("max_rows_per_index_patient"))
        .select(F.lit(int(seq)).alias("_seq"),
                _metrics_map(F, [(k, F.col(k)) for k in _STAGE_METRICS]).alias("metrics")))
    return _tag(F, agg, "stage", cohort, stage, None)


def selection_candidates_frame(F, rows, keys, date_col, cohort: str, block: str, item: str,
                               seq: int = 0):
    """A ONE-ROW plan over an item's CANDIDATE frame — the rows its pick actually ran on (already
    name-matched, unit-filtered and windowed by the helper). No action.

        candidate_rows            how many records competed. 0 = the configured name matched no
                                  delivered row in the window: the emitted column is all-missing
        patients_with_candidates  distinct pick keys holding >= 1 candidate
        tied_same_date_keys       keys where two candidates share one record date — the
                                  same_date_conflict class, decided by the block's rule
        tied_rows                 how many rows sit inside those ties

    `date_col` may be None for a pick with no date axis (a per-patient categorical whose config
    names no date_column): the grouping is then the keys alone, so a "tie" is a key with more than
    one candidate at all — which is exactly right, because with no date to separate them the
    ordering rule alone decides, and that is the situation the tie count exists to surface.
    """
    grp = list(keys) + ([F.col(date_col).alias("_d")] if date_col else [])
    g = rows.groupBy(*grp).agg(F.count(F.lit(1)).alias("_n"))
    agg = (g.agg(
        F.coalesce(F.sum("_n"), F.lit(0)).alias("candidate_rows"),
        F.countDistinct(*[F.col(k) for k in keys]).alias("patients_with_candidates"),
        F.count(F.when(F.col("_n") > 1, 1)).alias("tied_same_date_keys"),
        F.coalesce(F.sum(F.when(F.col("_n") > 1, F.col("_n"))), F.lit(0)).alias("tied_rows"))
        .select(F.lit(int(seq)).alias("_seq"),
                _metrics_map(F, [(k, F.col(k)) for k in _SELECTION_METRICS[:4]]).alias("metrics")))
    return _tag(F, agg, "sel_candidates", cohort, block, item)


def selection_outputs_frame(F, out, items, cohort: str, block: str, seq: int = 0):
    """A per-ITEM plan over a block's EMITTED frame: how many of the base rows actually got a
    value. `items` is [(item_name, value_column)] — the helper names the column that carries the
    item's substance (the mapped label for a categorical panel, the numeric value for a values
    panel, whose flag column is never null by construction). One aggregate, exploded to one row
    per item, so a 20-item block costs one plan, not twenty. No action.
    """
    agg = out.agg(F.count(F.lit(1)).alias("_rows"),
                  *[F.count(F.col(col)).alias(f"_nn{i}") for i, (_, col) in enumerate(items)])
    arr = F.array(*[F.struct(F.lit(str(name)).alias("_item"), F.col(f"_nn{i}").alias("_nn"))
                    for i, (name, _) in enumerate(items)])
    return (agg.select(F.lit(int(seq)).alias("_seq"), F.col("_rows"),
                       F.explode(arr).alias("_kv"))
            .select(F.lit(int(seq)).alias("_seq"), F.lit("sel_outputs").alias("kind"),
                    F.lit(str(cohort)).alias("cohort"), F.lit(str(block)).alias("label"),
                    F.col("_kv._item").alias("item"),
                    _metrics_map(F, [("non_null_outputs", F.col("_kv._nn")),
                                     ("output_rows", F.col("_rows"))]).alias("metrics")))


class StageTelemetry:
    """Collects aggregate plans during a build; spends its one action only when asked to report.

    Passed into `build_from_sources(src, cfg, telemetry=StageTelemetry())`; absent (the default),
    the build takes the same path it always took, with zero telemetry cost.
    """

    def __init__(self):
        self._frames = []
        self._skipped = []
        self._report = None

    def _queue(self, frame) -> None:
        if self._report is not None:
            raise RuntimeError("StageTelemetry already reported — one collector per build; "
                               "recording after report() would silently drop the new record")
        self._frames.append(frame)

    def record(self, F, idx, df, cohort: str, stage: str) -> None:
        """Queue one stage frame. Returns None on purpose — a caller cannot accidentally build on
        a telemetry value, so recording provably cannot change the ADS."""
        if df is None or "patientid" not in getattr(df, "columns", []):
            # The three-answer rule: a frame that cannot be measured is SKIPPED AND SAID, never
            # silently absent from the report (which would read as "measured, nothing notable").
            self._skipped.append(f"{cohort}/{stage}: no patientid column to join on")
            return
        self._queue(stage_stats_frame(F, idx, df, cohort, stage, seq=len(self._frames)))

    def record_selection(self, F, rows, keys, date_col, cohort: str, block: str,
                         item: str) -> None:
        """Queue an item's candidate frame — called by a selection helper with the exact frame its
        pick runs on. Returns None, same reasoning as record()."""
        self._queue(selection_candidates_frame(F, rows, keys, date_col, cohort, block, item,
                                               seq=len(self._frames)))

    def record_selection_outputs(self, F, out, items, cohort: str, block: str) -> None:
        """Queue a block's emitted frame with its [(item, value_column)] list — one plan for the
        whole block's non-null counts."""
        self._queue(selection_outputs_frame(F, out, items, cohort, block,
                                            seq=len(self._frames)))

    # Plans unioned per collect job. The bound is about CATALYST, not executors: every queued plan
    # carries its own joins, and analysis cost of a union grows superlinearly with branch count —
    # hundreds of branches in one job took >10 minutes locally where chunks of this size take
    # seconds. Small enough to keep each job's plan tractable, large enough that a full pack's
    # telemetry is tens of jobs, not hundreds.
    CHUNK = 24

    def report(self) -> dict:
        """{stages: [...], selections: [...], skipped: [...], observations: [...]} — a bounded
        handful of Spark actions (see CHUNK), cached.

        `stages` and `selections` preserve recording order (build order), stamped in the rows, not
        inherited from Spark. A selection item's candidate and output metrics are MERGED into one
        row keyed (cohort, block, item). `observations` names, in words, the asymmetries worth a
        person's look; it is NOT a failure list, and there is deliberately no `passed` — see the
        module docstring.
        """
        if self._report is None:
            collected = []
            for lo in range(0, len(self._frames), self.CHUNK):
                chunk = self._frames[lo:lo + self.CHUNK]
                u = chunk[0]
                for f in chunk[1:]:
                    u = u.unionByName(f)
                collected.extend(u.collect())
            collected.sort(key=lambda r: (r["_seq"], r["item"] or ""))
            stages, sel, sel_order = [], {}, []
            for r in collected:
                metrics = {k: int(v) for k, v in r["metrics"].items()}
                if r["kind"] == "stage":
                    stages.append({"cohort": r["cohort"], "stage": r["label"],
                                   **{k: metrics[k] for k in _STAGE_METRICS}})
                else:
                    key = (r["cohort"], r["label"], r["item"])
                    if key not in sel:
                        sel[key] = {"cohort": r["cohort"], "block": r["label"],
                                    "item": r["item"]}
                        sel_order.append(key)
                    sel[key].update(metrics)
            selections = [sel[k] for k in sel_order]
            obs = []
            for r in stages:
                if r["unmatched_index_patients"]:
                    obs.append(f"{r['cohort']}/{r['stage']}: {r['unmatched_index_patients']} of "
                               f"{r['index_patients']} index patient(s) got NO row from this stage")
                if r["patients_outside_index"]:
                    obs.append(f"{r['cohort']}/{r['stage']}: emitted rows for "
                               f"{r['patients_outside_index']} patient(s) the index does not carry")
            for s in selections:
                where = f"{s['cohort']}/{s['block']}/{s['item']}"
                if s.get("candidate_rows") == 0:
                    obs.append(f"{where}: the configured name matched NO delivered row in the "
                               f"window — the emitted column is all-missing")
                elif s.get("tied_same_date_keys"):
                    obs.append(f"{where}: {s['tied_same_date_keys']} same-date tie(s) over "
                               f"{s['tied_rows']} row(s), decided by the block's selection rule")
            self._report = {"stages": stages, "selections": selections,
                            "skipped": list(self._skipped), "observations": obs}
        return self._report

# The CLOSED bound vocabulary - an unrecognised key is refused, never read as the nearest
# one, because a typo'd bound that silently holds nothing is fail-open wearing a declaration.
RETENTION_BOUNDS = ("min_match_rate", "max_rows_per_index_patient",
                    "max_patients_outside_index")


def retention_bounds(cfg) -> dict:
    """The pack's declared retention/expansion bounds (`qc.retention`), normalised - global
    scalars plus optional `per_stage: {stage: {...}}` overrides, because "how much loss is
    acceptable" is legitimately different at a mortality join than at a treatment join.
    Malformed entries are ERRORS the gate fails, never silent drops."""
    try:
        q = dict((cfg.raw.get("qc") or {}).get("retention") or {})
    except Exception:  # noqa: BLE001 - a stub cfg with no raw has declared nothing
        q = {}
    errors = []

    def norm(d, where):
        got = {}
        for k, v in sorted((d or {}).items()):
            if k not in RETENTION_BOUNDS:
                errors.append(f"{where}.{k}: not a retention bound - the closed set is "
                              + ", ".join(RETENTION_BOUNDS))
                continue
            try:
                got[k] = float(v)
            except (TypeError, ValueError):
                errors.append(f"{where}.{k}: {v!r} is not a number")
        return got

    bounds = norm({k: v for k, v in q.items() if k != "per_stage"}, "qc.retention")
    per = {str(st): norm(d, f"qc.retention.per_stage.{st}")
           for st, d in sorted((q.get("per_stage") or {}).items())}
    return {"bounds": bounds, "per_stage": per, "errors": errors}


def bounds_declared(rb) -> bool:
    """Whether the pack has ruled at all - any bound, any override, or any malformed attempt
    (a broken declaration must surface as a failure, not vanish into report-only)."""
    return bool(rb and (rb.get("bounds") or rb.get("per_stage") or rb.get("errors")))


def retention_gate(telemetry_report, rb) -> dict:
    """{passed, failures} - report-only until the pack rules; then held per stage row by name.

    A declared bound over UNCOLLECTED telemetry fails: telemetry is a run opt-in, so a pack
    that declares retention bounds has made collecting it mandatory for its governed runs -
    "the run did not look" is never a pass (the grain gate's rule). A stage row with zero
    index patients has no match RATE and is skipped for that bound only - the count bounds
    still apply."""
    if not bounds_declared(rb):
        return {"passed": True, "failures": []}
    failures = list(rb.get("errors") or [])
    stages = (telemetry_report or {}).get("stages") or []
    if not stages:
        failures.append("retention bounds are declared and this run collected no stage "
                        "telemetry - a declared bound the run cannot test must fail (set "
                        "the stage_telemetry run parameter)")
    for r in stages:
        eff = dict(rb.get("bounds") or {})
        eff.update((rb.get("per_stage") or {}).get(r.get("stage")) or {})
        where = f"{r.get('cohort')}/{r.get('stage')}"
        mmr = eff.get("min_match_rate")
        if mmr is not None and r.get("index_patients"):
            rate = r.get("matched_patients", 0) / r["index_patients"]
            if rate < mmr:
                failures.append(f"{where}: match rate {round(rate, 4)} < min_match_rate "
                                f"{mmr} - {r.get('unmatched_index_patients')} of "
                                f"{r['index_patients']} index patient(s) got no row")
        mrp = eff.get("max_rows_per_index_patient")
        if mrp is not None and r.get("max_rows_per_index_patient", 0) > mrp:
            failures.append(f"{where}: {r['max_rows_per_index_patient']} row(s) for one "
                            f"index patient > max_rows_per_index_patient {mrp}")
        mpo = eff.get("max_patients_outside_index")
        if mpo is not None and r.get("patients_outside_index", 0) > mpo:
            failures.append(f"{where}: {r['patients_outside_index']} patient(s) outside "
                            f"the index > max_patients_outside_index {mpo}")
    return {"passed": not failures, "failures": failures}
