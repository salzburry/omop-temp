"""Stage: radiotherapy COURSES from a delivered RT source (treatment.rt_courses).

FAMILY A OF THE RT CLUSTER, exactly as docs/EXPRESSIBILITY_MATRIX.md scoped it: read a declared
radiotherapy source and resolve, per patient, one or more courses — start, end — either by taking
already-dated abstracted RT fields (`mode: abstracted`, one row per course) or by grouping
record-level deliveries into courses on a stated gap rule (`mode: sessionised`). The matrix judged
exactly one inventory row the family's own output (`hnscc.RADIOTHERAPY_COURSE`); every other RT row
also needs the MODALITY_RELATION family, which is deliberately a separate stage because it is not
RT-specific.

WHAT THIS FAMILY IS NOT. `TREATMENT_INTENT_SETTING`, `DEFINITIVE_CHEMORADIATION`, the
"prophylactic" half of `PCI_FLAG` and the "consolidative" half of `THORACIC_RT_FLAG` all need an
INTENT, which is not a course and not a relation — each is `needs_a_clinician` or
`separate_algorithm` in the matrix, and claiming them here would be the gap-closed-by-assertion
the matrix exists to prevent.

SESSIONISATION IS THE NAMED RISK, so it carries the accountability slots. The matrix's own words:
"the sessionisation mode is where a wrong gap parameter silently merges two courses, so build it
named and separately tested". A gap threshold is clinical content — 30 days reads two palliative
courses as one, 5 days splits one interrupted course in two — so `mode: sessionised` requires
`instrument`, `citation`, `clinically_reviewed_by` and `review_date`, exactly as `risk_score` and
`serial_marker` require them of their thresholds. `abstracted` mode ingests dates a vendor's
abstraction already ruled on, and requires none of that.

EXECUTION STATUS, honestly. The pure core is tested and `build` follows the pattern
`serial_marker` proved: it moves rows and calls the tested core once per patient — a stub harness
executes the exact Spark call chain, and Spark itself is the dev rehearsal's claim. No pack
declares `rt_courses` yet.
"""
from __future__ import annotations

import re

# ONE DEFINITION OF DATE ARITHMETIC across the episode families — a second parser that disagreed
# about what a date is would be the two-definitions defect one file over.
from stages.serial_marker import _days, _numeric  # noqa: F401

UNFILLED = "REPLACE_ME"
GOVERNED_SLOTS = ("instrument", "citation", "clinically_reviewed_by", "review_date")

# CLOSED VOCABULARY — an unrecognised mode is REPORTED, never read as the nearest one.
MODES = ("abstracted", "sessionised")

IDENTIFIER = re.compile(r"^[A-Za-z_][A-Za-z0-9_]*$")
PLACEHOLDERS = ("TODO", "TBD", "TBC", "N/A", "NA", "NONE", "PENDING", "XXX", UNFILLED)


def courses(spec, rows):
    """[(start, end)] — the patient's RT courses, in date order.

    `abstracted`: each row IS a course (start_column, end_column); a row with no readable start is
    dropped (a course nobody dated is not a course), and a missing end is the start — a one-day
    record, not an invented duration.

    `sessionised`: the row DATES are grouped into episodes wherever the gap between consecutive
    deliveries exceeds `gap_days`. Sorted first, because a "gap" over an arbitrary row order is a
    property of a shuffle — the same lesson `serial_marker.ordered` carries.
    """
    mode = str(spec.get("mode") or "")
    if mode == "abstracted":
        out = []
        for row in (rows or []):
            start = row[0] if not isinstance(row, dict) else row.get("start")
            end = row[1] if not isinstance(row, dict) else row.get("end")
            if _days(start, start) is None:
                continue
            out.append((start, end if _days(end, end) is not None
                        and _days(start, end) is not None and _days(start, end) >= 0 else start))
        # (start, end) not start alone: two courses sharing a start date used to order by
        # delivery order, so `first start/end` could differ between byte-identical runs.
        # The secondary key is a DETERMINISM guarantee, not a clinical claim.
        return sorted(out, key=lambda c: (_days("1900-01-01", c[0]),
                                          _days("1900-01-01", c[1])))
    # sessionised: rows are bare dates
    gap = _numeric(spec.get("gap_days"))
    dated = sorted((d for d in (rows or []) if _days(d, d) is not None),
                   key=lambda d: _days("1900-01-01", d))
    out = []
    for d in dated:
        if out and _days(out[-1][1], d) is not None and _days(out[-1][1], d) <= gap:
            out[-1] = (out[-1][0], d)
        else:
            out.append((d, d))
    return out



def requires(inst) -> list:
    """The source columns one instrument reads — derived from the instrument, never restated."""
    if str(inst.get("mode") or "") == "abstracted":
        cols = (inst.get("start_column"), inst.get("end_column"))
    else:
        cols = (inst.get("date_column"),)
    return [c for c in cols if c]


def reads(cfg):
    """Every typed source read the declared RT instruments make — the preflight half of the
    build's own refusals. build() REFUSES an absent source or column by name, and an audit
    found these reads missing from the canonical list: a declared instrument passed source
    preflight and failed only at execution."""
    from . import read
    if "treatment" not in cfg.roles():
        return []
    out = []
    for i, inst in enumerate(cfg.pack("treatment").get("rt_courses") or []):
        if isinstance(inst, dict):
            label = inst.get("name", i)
            out.append(read(inst.get("source"), requires(inst),
                            f"treatment.rt_courses[{label!r}]"))
    return out

def summary(spec, rows):
    """(flag, count, first start, first end) — the four columns one instrument emits.

    THE FIRST course's dates, deliberately: the ADS row is one patient, and "the" RT course a flag
    describes is the earliest — a later course is visible in the count, and a pack that needs the
    Nth course is asking a question this family's emitted surface does not answer yet.
    """
    cs = courses(spec, rows)
    if not cs:
        return 0, 0, None, None
    return 1, len(cs), cs[0][0], cs[0][1]


def emitted(items) -> set:
    """`<name>fl` (any course), `<name>n` (how many), `<name>dt`/`<name>enddt` (the first course's
    interval). No site, no dose, no fractions in v1 — emitting an attribute column the build does
    not fill is the advertised-but-absent defect fixed twice already."""
    em = set()
    for inst in (items or []):
        name = inst.get("name") if isinstance(inst, dict) else None
        if name:
            em |= {f"{name}fl", f"{name}n", f"{name}dt", f"{name}enddt"}
    return em


def instrument_errors(inst, where="rt_courses[?]") -> list:
    """[why this instrument cannot be applied as written]."""
    out = []
    if not isinstance(inst, dict):
        return [f"{where} must be a mapping"]
    name = str(inst.get("name") or "").strip()
    if not name:
        out.append(f"{where} states no `name` — nothing would name the columns it emits")
    elif not IDENTIFIER.match(name):
        out.append(f"{where}.name {name!r} is not a plain identifier, and it becomes a column stem")
    src = str(inst.get("source") or "").strip()
    if not src:
        out.append(f"{where} states no `source` — the delivered RT table, exactly as "
                   f"serial_markers requires; without it the build would guess which delivery "
                   f"carries radiotherapy")
    elif not IDENTIFIER.match(src):
        out.append(f"{where}.source {src!r} is not a plain source name")
    mode = str(inst.get("mode") or "").strip()
    if mode not in MODES:
        out.append(f"{where}.mode {mode or '(unstated)'!r} is not one of {MODES} — an "
                   f"unrecognised mode would otherwise take a default nobody chose")
        return out
    if mode == "abstracted":
        for field in ("start_column", "end_column"):
            v = str(inst.get(field) or "").strip()
            if not v:
                out.append(f"{where} is abstracted and states no `{field}`")
            elif not IDENTIFIER.match(v):
                out.append(f"{where}.{field} {v!r} is not a plain column identifier")
        return out
    # sessionised — the named risk, so the gap and the accountability slots are all required
    v = str(inst.get("date_column") or "").strip()
    if not v:
        out.append(f"{where} is sessionised and states no `date_column`")
    elif not IDENTIFIER.match(v):
        out.append(f"{where}.date_column {v!r} is not a plain column identifier")
    gap = _numeric(inst.get("gap_days"))
    if gap is None or gap <= 0:
        out.append(f"{where}.gap_days is {inst.get('gap_days')!r} — sessionisation without a "
                   f"positive gap threshold either merges every delivery into one course or "
                   f"splits every delivery into its own")
    for slot in GOVERNED_SLOTS:
        v = str(inst.get(slot) or "").strip()
        if not v:
            out.append(f"{where} is sessionised and states no `{slot}` — the gap rule is where a "
                       f"wrong parameter silently merges two courses, and a threshold nobody is "
                       f"accountable for is a number in a YAML file")
        elif v.upper().rstrip(".") in PLACEHOLDERS:
            out.append(f"{where}.{slot} is the placeholder {v!r}")
    return out


def rt_course_errors(items) -> list:
    """[why treatment.rt_courses cannot be applied], or []. Absent is fine — every pack today."""
    if items is None:
        return []
    if not isinstance(items, list) or not items:
        return ["treatment.rt_courses must be a non-empty list of instruments (or absent)"]
    out, seen = [], set()
    for i, inst in enumerate(items):
        where = f"rt_courses[{i}]"
        out += instrument_errors(inst, where)
        name = str((inst or {}).get("name") if isinstance(inst, dict) else "").strip()
        if name and name in seen:
            out.append(f"{where}.name {name!r} is declared twice — two instruments would emit "
                       f"the same columns and the frame would keep whichever joined last")
        seen.add(name)
    return out


def build(F, src, frame, cfg):
    """Apply `treatment.rt_courses` to the delivered RT source and join four columns per
    instrument onto `frame`, keyed by patientid.

    PATIENT-LEVEL ON PURPOSE: a course exists whether or not this cohort's line window contains
    it. Anchoring a course to a line is a RELATION, and relations are the MODALITY_RELATION
    family's job — fusing them here is exactly the split the matrix argued for.

    Returns `frame` untouched when no instrument is declared. A DECLARED instrument that cannot
    be applied REFUSES — same contract as serial_marker, same reason.
    """
    items = (cfg.pack("treatment") or {}).get("rt_courses")
    if not items:
        return frame
    why = rt_course_errors(items)
    if why:
        raise ValueError("BUILD REFUSED - treatment.rt_courses cannot be applied as written:"
                         + "".join(f"\n  {w}" for w in why))
    for inst in items:
        name, source = str(inst["name"]), str(inst["source"])
        mode = str(inst["mode"])
        if source not in src:
            raise ValueError(
                f"BUILD REFUSED - rt_courses[{name!r}] reads source {source!r}, which this run "
                f"was not given ({sorted(src)}).")
        rows = src[source]
        need = (["patientid", str(inst["start_column"]), str(inst["end_column"])]
                if mode == "abstracted" else ["patientid", str(inst["date_column"])])
        missing = [c for c in need if c not in rows.columns]
        if missing:
            raise ValueError(
                f"BUILD REFUSED - rt_courses[{name!r}]: {source!r} lacks column(s) {missing} — "
                f"and `validate` has already advertised this instrument's columns as emitted.")
        spec = dict(inst)
        if mode == "abstracted":
            payload = F.struct(F.col(need[1]), F.col(need[2]))
        else:
            payload = F.col(need[1])
        fn = F.udf(lambda series, _s=spec: summary(_s, series),
                   "struct<fl: int, n: int, dt: date, enddt: date>")
        grouped = (rows.select(*need).groupBy("patientid")
                   .agg(F.collect_list(payload).alias("_rt_series")))
        scored = grouped.select("patientid", fn(F.col("_rt_series")).alias("_rt"))
        per = scored.select("patientid",
                            F.col("_rt.fl").alias(f"{name}fl"),
                            F.col("_rt.n").alias(f"{name}n"),
                            F.col("_rt.dt").alias(f"{name}dt"),
                            F.col("_rt.enddt").alias(f"{name}enddt"))
        # LEFT: a patient with no RT rows keeps all four null — never measured is not "no course",
        # and a fabricated 0 would be the missing-value-scored defect, again.
        frame = frame.join(per, ["patientid"], "left")
    return frame
