"""Stage: ONE number per patient from a drug's administrations (treatment.dose_exposures).

FAMILY C OF THE DOSE CLUSTER, exactly as docs/EXPRESSIBILITY_MATRIX.md scoped it: take the
administration records for one named drug, restrict them to a window anchored on the cohort's
index date, and reduce the numeric dose column to one number — a SUM, or a named record pick.

WHAT THIS FAMILY IS NOT, and the matrix said it in advance: "building one family and reporting
all four dose rows closed is the exact failure the audit named". DOSE_TRAJECTORY — the schedule
label of `hnscc.CISPLATIN_SCHEDULE`, the escalation half of `gist.IMATINIB_DOSE_ESCALATION` —
reads the ORDERED sequence and needs tolerance rules that are validated clinical content. It is
`separate_algorithm` in the matrix and it is NOT here. `RUXOLITINIB_DOSE` as a whole is
`needs_a_clinician` (whether "dose" means per-administration, daily total, or amount-and-
frequency); this family can compute any of those once a person rules which.

THE UNITS REFUSAL IS PART OF THE SHAPE, not an error path bolted on. mg, mg/m² and mg/kg are not
addable, and mg-to-mg/m² is not even a conversion — the divisor is a per-patient, time-varying
BSA whose formula is itself a governed choice (`clinical.vitals.bsa_method`). So an instrument
declares ONE unit spelling, and a patient whose in-window matched records carry any OTHER unit —
or a matched record with no readable dose — totals NULL, never a number computed over the rows
that happened to agree. A partial sum is a fabricated exposure wearing a real column name.

EXECUTION STATUS, honestly. Pure core tested; `build` follows the pattern `serial_marker` proved
— rows move, the tested core decides, a stub harness executes the exact call chain. Spark itself
is the dev rehearsal's claim. No pack declares `dose_exposures` yet.
"""
from __future__ import annotations

import re

# ONE DEFINITION OF DATE ARITHMETIC across the episode families.
from stages.serial_marker import _days, _numeric # noqa: F401

IDENTIFIER = re.compile(r"^[A-Za-z_][A-Za-z0-9_]*$")

# CLOSED VOCABULARY — how the in-window records reduce to one number. `sum` is the matrix's
# summation; `first`/`last` are the named picks (starting dose; the dose standing at the window's
# edge). An unrecognised word is REPORTED, never read as the nearest one.
REDUCES = ("sum", "first", "last")


def exposure(spec, anchor, rows):
    """The one number for one patient, or None — the tested core the Spark path calls.

    `rows` are (drug, dose, unit, date) for every record the source holds for this patient;
    matching, windowing, the unit guard and the reduction all happen HERE, in one tested place,
    rather than half in Spark filters and half in a closure that could disagree with them.

    None is returned for: no matched record in the window (nothing to reduce — not a zero
    exposure, an unmeasured one); ANY matched in-window record whose unit is not the declared
    spelling; ANY matched in-window record with no readable dose. The last two are the hard
    refusal: a number computed over the agreeing subset would be a partial exposure published
    under a total's name.
    """
    drugs = {str(d).strip().lower() for d in (spec.get("drugs") or [])}
    unit = str(spec.get("unit") or "").strip()
    before = _numeric(spec.get("window_days_before"))
    after = _numeric(spec.get("window_days_after"))
    picked = []
    for row in (rows or []):
        drug, dose, u, when = row[0], row[1], row[2], row[3]
        if str(drug or "").strip().lower() not in drugs:
            continue
        offset = _days(anchor, when)
        if offset is None or offset < -before or offset > after:
            continue
        if str(u or "").strip() != unit:
            return None # the units refusal — whole-patient, hard
        value = _numeric(dose)
        if value is None:
            return None # a matched record with no readable dose
        picked.append((value, when))
    if not picked:
        return None
    # (date, value) not date alone: two same-date records used to leave first/last to the
    # delivery's row order — nondeterministic between byte-identical runs. Value ascending
    # as the secondary key is a DETERMINISM guarantee, not a clinical claim; a product that
    # needs a clinical same-day rule declares one (as serial markers declare `same_day`).
    picked.sort(key=lambda p: (_days("1900-01-01", p[1]), p[0]))
    reduce = str(spec.get("reduce"))
    if reduce == "sum":
        return float(sum(v for v, _ in picked))
    return float(picked[0][0] if reduce == "first" else picked[-1][0])



def requires(inst) -> list:
    """The source columns one instrument reads — derived from the instrument, never restated."""
    return [c for c in (inst.get("drug_column"), inst.get("dose_column"),
                        inst.get("unit_column"), inst.get("date_column")) if c]


def reads(cfg):
    """The declared dose instruments' typed reads — preflight demands what build() refuses
    without."""
    from. import read
    if "treatment" not in cfg.roles():
        return []
    out = []
    for i, inst in enumerate(cfg.pack("treatment").get("dose_exposures") or []):
        if isinstance(inst, dict):
            label = inst.get("name", i)
            out.append(read(inst.get("source"), requires(inst),
                            f"treatment.dose_exposures[{label!r}]"))
    return out

def emitted(items) -> set:
    """`<name>` — one numeric column per instrument. No unit column: the unit is declared, single,
    and part of the variable's definition, not a per-row fact the frame re-states."""
    return {inst.get("name") for inst in (items or [])
            if isinstance(inst, dict) and inst.get("name")}


def instrument_errors(inst, where="dose_exposures[?]") -> list:
    out = []
    if not isinstance(inst, dict):
        return [f"{where} must be a mapping"]
    name = str(inst.get("name") or "").strip()
    if not name:
        out.append(f"{where} states no `name` — nothing would name the column it emits")
    elif not IDENTIFIER.match(name):
        out.append(f"{where}.name {name!r} is not a plain identifier, and it becomes a column name")
    src = str(inst.get("source") or "").strip()
    if not src:
        out.append(f"{where} states no `source` — the delivered administrations table")
    elif not IDENTIFIER.match(src):
        out.append(f"{where}.source {src!r} is not a plain source name")
    for field in ("drug_column", "dose_column", "unit_column", "date_column"):
        v = str(inst.get(field) or "").strip()
        if not v:
            out.append(f"{where} states no `{field}`")
        elif not IDENTIFIER.match(v):
            out.append(f"{where}.{field} {v!r} is not a plain column identifier")
    drugs = inst.get("drugs")
    if not isinstance(drugs, list) or not [d for d in (drugs or []) if str(d).strip()]:
        out.append(f"{where}.drugs must be a non-empty codelist — an exposure to no named drug "
                   f"sums every administration in the table")
    if not str(inst.get("unit") or "").strip():
        out.append(f"{where} states no `unit` — the ONE spelling this instrument sums; without "
                   f"it mg and mg/m² add, and they are not addable. There is no unit conversion "
                   f"here on purpose: mg to mg/m² is a per-patient BSA division, not a constant")
    for field in ("window_days_before", "window_days_after"):
        v = _numeric(inst.get(field))
        if v is None or v < 0:
            out.append(f"{where}.{field} is {inst.get(field)!r} — the window is anchored on the "
                       f"index and both offsets must be stated, zero included, so an unstated "
                       f"window cannot silently mean 'everything'")
    if str(inst.get("reduce") or "").strip() not in REDUCES:
        out.append(f"{where}.reduce {inst.get('reduce') or '(unstated)'!r} is not one of "
                   f"{REDUCES} — an unrecognised reduction would otherwise take a default "
                   f"nobody chose")
    return out


def dose_exposure_errors(items) -> list:
    if items is None:
        return []
    if not isinstance(items, list) or not items:
        return ["treatment.dose_exposures must be a non-empty list of instruments (or absent)"]
    out, seen = [], set()
    for i, inst in enumerate(items):
        where = f"dose_exposures[{i}]"
        out += instrument_errors(inst, where)
        name = str((inst or {}).get("name") if isinstance(inst, dict) else "").strip()
        if name and name in seen:
            out.append(f"{where}.name {name!r} is declared twice")
        seen.add(name)
    return out


def build(F, src, frame, cfg):
    """Apply `treatment.dose_exposures` per cohort: the window anchors on THIS cohort's
    index_date, so the same instrument yields a line-scoped exposure in a line cohort.

    Returns `frame` untouched when nothing is declared; REFUSES a declared instrument it cannot
    apply — missing source, missing columns, a frame with no index_date to anchor on.
    """
    items = (cfg.pack("treatment") or {}).get("dose_exposures")
    if not items:
        return frame
    why = dose_exposure_errors(items)
    if why:
        raise ValueError("BUILD REFUSED - treatment.dose_exposures cannot be applied as written:"
                         + "".join(f"\n  {w}" for w in why))
    if "index_date" not in frame.columns:
        raise ValueError("BUILD REFUSED - dose_exposures anchor on index_date and the frame "
                         "carries none.")
    for inst in items:
        name, source = str(inst["name"]), str(inst["source"])
        if source not in src:
            raise ValueError(
                f"BUILD REFUSED - dose_exposures[{name!r}] reads source {source!r}, which this "
                f"run was not given ({sorted(src)}).")
        rows = src[source]
        need = ["patientid", str(inst["drug_column"]), str(inst["dose_column"]),
                str(inst["unit_column"]), str(inst["date_column"])]
        missing = [c for c in need if c not in rows.columns]
        if missing:
            raise ValueError(
                f"BUILD REFUSED - dose_exposures[{name!r}]: {source!r} lacks column(s) "
                f"{missing} — and `validate` has already advertised {name!r} as emitted.")
        spec = dict(inst)
        fn = F.udf(lambda anchor, series, _s=spec: exposure(_s, anchor, series), "double")
        pairs = rows.select(*need)
        # INNER against the cohort frame: a patient not in this cohort has no anchor here; the
        # left join at the end restores them as null.
        anchored = pairs.join(frame.select("patientid", "index_date"), "patientid", "inner")
        grouped = (anchored.groupBy("patientid", "index_date")
.agg(F.collect_list(F.struct(F.col(need[1]), F.col(need[2]),
                                                F.col(need[3]), F.col(need[4])))
.alias("_dx_series")))
        per = grouped.select("patientid", "index_date",
                             fn(F.col("index_date"), F.col("_dx_series")).alias(name))
        frame = frame.join(per, ["patientid", "index_date"], "left")
    return frame
