"""Stage: a relation between two dated episodes on the assembled frame (outcomes.modality_relations).

FAMILY B OF THE RT CLUSTER — and deliberately NOT inside the RT stage, in the matrix's own words:
"it is not RT-specific and should not be built inside an RT stage". Given two dated episodes
already ON the frame — an RT course from `rt_course`, a surgery date a pack passed through, a
line's own dates — emit one flag for a stated relation. Building it separately also serves
`hnscc.INDUCTION_CHEMOTHERAPY`, whose only gap was sequencing-vs-RT; fusing B into A would have
left that row open for no reason.

WHAT THIS FAMILY IS NOT. "Definitive", "prophylactic", "consolidative" are INTENTS, not
relations — `DEFINITIVE_CHEMORADIATION`, `PCI_FLAG` and `THORACIC_RT_FLAG` each need one and each
stays `needs_a_clinician` in the matrix. `TREATMENT_INTENT_SETTING` orders three modality streams
and no relation operator expresses it. Emitting those from here would compute other patients
under the right names.

PURE DATE ARITHMETIC, EXHAUSTIVELY TESTABLE — the matrix's stated reason for the split: family
A's sessionisation hides a clinical parameter, family B hides nothing, so B carries no
accountability slots and its window is plain config.

EXECUTION STATUS, honestly. Pure core tested; `build` is a per-row wrapping of it (no grouping,
no source reads — the frame already holds both episodes). Spark itself is the dev rehearsal's
claim. No pack declares `modality_relations` yet.
"""
from __future__ import annotations

import re

# ONE DEFINITION OF DATE ARITHMETIC across the episode families.
from stages.serial_marker import _days, _numeric  # noqa: F401

IDENTIFIER = re.compile(r"^[A-Za-z_][A-Za-z0-9_]*$")

# CLOSED VOCABULARY — the three relations the matrix scoped, and no fourth. An unrecognised word
# is REPORTED, never read as the nearest one.
RELATIONS = ("overlaps_within", "starts_after_within", "precedes")

# Which relations take a window. `precedes` is strict order and takes none — a window on it would
# be `starts_after_within` wearing a different name, and two spellings of one relation is how a
# reader stops knowing which was meant.
WINDOWED = ("overlaps_within", "starts_after_within")



def reads(cfg):
    """No source reads, stated rather than absent: the relations read episode columns the
    frame ALREADY holds (their absence is build()'s own conditioned refusal), never a
    delivered table — so preflight has nothing to demand for this family."""
    return []

def relation(spec, a_start, a_end, b_start, b_end):
    """1, 0, or None — the relation between episode A and episode B, for one row.

    None whenever a date the stated relation NEEDS is unreadable — an unknown relation is not a
    false one, and 0 here would count every undated surgery as "no adjuvant RT". `overlaps_within`
    asks whether B's interval touches A's expanded by the window on both sides;
    `starts_after_within` asks whether B starts 0..window days after A ends; `precedes` asks
    whether A ends strictly before B starts.
    """
    rel = str(spec.get("relation"))
    w = _numeric(spec.get("window_days")) if rel in WINDOWED else 0
    ae, bs = a_end if a_end is not None else a_start, b_start
    be = b_end if b_end is not None else b_start
    if rel == "overlaps_within":
        if _days(a_start, a_start) is None or _days(ae, ae) is None \
                or _days(bs, bs) is None or _days(be, be) is None:
            return None
        # disjoint iff B ends more than w days before A starts, or B starts more than w days
        # after A ends — everything else touches A's interval expanded by the window
        return 0 if (_days(be, a_start) > w or _days(ae, bs) > w) else 1
    if rel == "starts_after_within":
        gap = _days(ae, bs)
        if gap is None:
            return None
        return 1 if 0 <= gap <= w else 0
    # precedes
    gap = _days(ae, bs)
    if gap is None:
        return None
    return 1 if gap > 0 else 0


def emitted(items) -> set:
    """`<name>` — one 0/1/null flag per declared relation."""
    return {inst.get("name") for inst in (items or [])
            if isinstance(inst, dict) and inst.get("name")}


def instrument_errors(inst, where="modality_relations[?]") -> list:
    out = []
    if not isinstance(inst, dict):
        return [f"{where} must be a mapping"]
    name = str(inst.get("name") or "").strip()
    if not name:
        out.append(f"{where} states no `name` — nothing would name the flag it emits")
    elif not IDENTIFIER.match(name):
        out.append(f"{where}.name {name!r} is not a plain identifier, and it becomes a column name")
    rel = str(inst.get("relation") or "").strip()
    if rel not in RELATIONS:
        out.append(f"{where}.relation {rel or '(unstated)'!r} is not one of {RELATIONS} — an "
                   f"unrecognised relation would otherwise take a default nobody chose")
    for field, required in (("a_start_column", True), ("a_end_column", False),
                            ("b_start_column", True), ("b_end_column", False)):
        v = str(inst.get(field) or "").strip()
        if required and not v:
            out.append(f"{where} states no `{field}`")
        elif v and not IDENTIFIER.match(v):
            out.append(f"{where}.{field} {v!r} is not a plain column identifier")
    if rel in WINDOWED:
        w = _numeric(inst.get("window_days"))
        if w is None or w < 0:
            out.append(f"{where}.window_days is {inst.get('window_days')!r} — a windowed "
                       f"relation without a stated non-negative window is a different relation "
                       f"depending on who imagines the default")
    elif rel == "precedes" and inst.get("window_days") is not None:
        out.append(f"{where}: `precedes` takes no window_days — a windowed precedes is "
                   f"`starts_after_within` wearing a different name, and one relation must "
                   f"have one spelling")
    return out


def modality_relation_errors(items) -> list:
    if items is None:
        return []
    if not isinstance(items, list) or not items:
        return ["outcomes.modality_relations must be a non-empty list (or absent)"]
    out, seen = [], set()
    for i, inst in enumerate(items):
        where = f"modality_relations[{i}]"
        out += instrument_errors(inst, where)
        name = str((inst or {}).get("name") if isinstance(inst, dict) else "").strip()
        if name and name in seen:
            out.append(f"{where}.name {name!r} is declared twice")
        seen.add(name)
    return out


def build(F, frame, cfg):
    """Apply `outcomes.modality_relations` to the assembled frame — AFTER every stage that emits a
    date it might read: rt_course's `<name>dt`/`<name>enddt`, passthrough surgery dates,
    ads_derived intervals. Runs where `risk_score` runs, for the same post-assemble reason.

    Returns `frame` untouched when nothing is declared. A DECLARED relation whose columns the
    frame does not carry REFUSES — the matrix marked `ADJUVANT_RT_CRT` expressible only
    conditionally on a surgery date reaching the frame, and this refusal is that condition
    enforced rather than assumed.
    """
    items = (cfg.pack("outcomes") or {}).get("modality_relations")
    if not items:
        return frame
    why = modality_relation_errors(items)
    if why:
        raise ValueError("BUILD REFUSED - outcomes.modality_relations cannot be applied as "
                         "written:" + "".join(f"\n  {w}" for w in why))
    for inst in items:
        name = str(inst["name"])
        cols = {}
        for field in ("a_start_column", "a_end_column", "b_start_column", "b_end_column"):
            v = str(inst.get(field) or "").strip()
            cols[field] = v or None
        need = [v for v in cols.values() if v]
        missing = [c for c in need if c not in frame.columns]
        if missing:
            raise ValueError(
                f"BUILD REFUSED - modality_relations[{name!r}] reads column(s) {missing} that "
                f"this frame does not carry — the matrix calls this row expressible only "
                f"conditionally on those dates reaching the frame, and the condition failed.")
        spec = dict(inst)
        fn = F.udf(lambda a_s, a_e, b_s, b_e, _s=spec: relation(_s, a_s, a_e, b_s, b_e), "int")
        frame = frame.withColumn(
            name,
            fn(F.col(cols["a_start_column"]),
               F.col(cols["a_end_column"] or cols["a_start_column"]),
               F.col(cols["b_start_column"]),
               F.col(cols["b_end_column"] or cols["b_start_column"])))
    return frame
