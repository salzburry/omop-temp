"""Stage: a CONFIRMED change across a series of dated marker values (outcomes.serial_markers).

WHY THIS FAMILY EXISTS. `docs/EXPRESSIBILITY_MATRIX.md` judged two inventory rows expressible by one
shape — `prostate.PSA_PROG` ("PCWG3 confirmed-rise logic (second value >=3 weeks later)") and
`ovarian.CA125_RESP` ("GCIG confirmed-response/progression criteria over serial labs"). Both are the
same computation over a per-patient series of (value, date):

    pick a REFERENCE (the nadir so far, or the baseline)
    find the first value that moves away from it by a stated amount, in a stated DIRECTION
    require a CONFIRMING value, at least N days later, that also qualifies
    report the date the instrument says is the event

AND WHAT THIS FAMILY IS NOT, which the same matrix was written to establish. Three neighbouring rows
share the plumbing and NOT the algorithm, and each is `separate_algorithm` there:

  * `prostate.PSA_KINETICS` — velocity and doubling time are a FITTED RATE over the series, not a
    threshold crossing. The matrix also records that row as three quantities in one inventory entry,
    to be split before any build claims it.
  * `ovarian.KELIM` — a modelled elimination rate from a semi-mechanistic nonlinear mixed-effects /
    K-PD model, needing several early-treatment values. It is not a slope and it is not a crossing.
  * `mds.IWG_*` — response criteria over several axes at once, not one marker.

A family that claimed those would be the failure the matrix exists to prevent: a gap reported closed
because a generic shape existed. `emitted()` names only what an instrument declares, and nothing here
computes a rate.

THE CRITERIA ARE NOT CODE AND ARE NOT HERE. What percentage counts as a rise, what absolute floor it
must also clear, how many days a confirmation must wait, and whether the event is dated at the first
qualifying value or the confirming one are PUBLISHED CLINICAL CONTENT with a citation, a version and
a person accountable for it. PCWG3's own numbers are not written in this file. A pack states them,
`instrument_errors` refuses them unfilled, and `REPLACE_ME` reaches no build.

EXECUTION STATUS, honestly. The pure core is tested (same-day tie-break included) and `build` is
now written: it moves rows and calls `answer` — the tested core — once per patient series,
re-implementing nothing. A stub harness in `test_serial_marker` executes the exact Spark call
chain over realistic rows; what no test on this machine can prove is Spark itself (no Java), so
a dev rehearsal must run one declared instrument before a pack relies on it. No pack declares
`serial_markers` yet — the PCWG3 instrument draft awaits a named clinical reviewer
(docs/PCWG3_INSTRUMENT_DRAFT.md).
"""
from __future__ import annotations

import re

# The scaffold marker, shared with `risk_score` and the repository-wide rule it follows: a governed
# slot a person has not filled must reach no build.
UNFILLED = "REPLACE_ME"

# WHAT AN INSTRUMENT MUST SAY ABOUT ITSELF. The same four `risk_score` requires, for the same
# reason: a threshold nobody is accountable for is a number in a YAML file.
GOVERNED_SLOTS = ("instrument", "citation", "clinically_reviewed_by", "review_date")

# CLOSED VOCABULARIES. An unrecognised value must be REPORTED, never silently treated as the
# default — the defect closed in `source_adapter`'s REVIEW_STATUSES, which would land here as
# `reference: baselin` quietly measuring from the nadir.
REFERENCES = ("nadir", "baseline")
DIRECTIONS = ("rise", "fall")
EVENT_DATES = ("first_qualifying", "confirming")
# WHERE THE SERIES BEGINS, and it is CLINICAL, not plumbing. PCWG3-shaped criteria judge a rise
# against the nadir ON TREATMENT — a pre-treatment low in the patient's history must not set the
# reference, or a therapy that lowered the marker and held it there reads as progression against a
# floor it never claimed to beat. `from_index` keeps only measurements on or after the cohort's
# index date; `full_history` uses every dated measurement the source carries. Neither is a
# default: an instrument that does not say is refused, because the two answers differ on exactly
# the patients the criterion exists for.
SERIES_SCOPES = ("from_index", "full_history")
#...AND THE ONE THAT IS EASIEST TO MISTAKE FOR PLUMBING. Two measurements on ONE DAY are
# ordinary in this data, and which is read first CHANGES THE ANSWER — measured, not assumed:
# for a nadir/rise instrument over 10, {4, 6} same-day, 9, reading the 4 first reports
# progression and reading the 6 first reports NONE AT ALL. It is not conservative in either
# direction either: lowest-first lowers the nadir, making a RISE easier to declare, and lowers
# a baseline, making a FALL harder. So this is a CLINICAL choice with a result attached, and it
# is declared per instrument for the same reason the thresholds are, rather than being a sort
# key somebody picked.
SAME_DAY = ("lowest_first", "highest_first")

IDENTIFIER = re.compile(r"^[A-Za-z_][A-Za-z0-9_]*$")
ISO_DATE = re.compile(r"^\d{4}-\d{2}-\d{2}$")
PLACEHOLDERS = ("TODO", "TBD", "TBC", "N/A", "NA", "NONE", "PENDING", "XXX", UNFILLED)


def _numeric(value):
    """A number, or None. `None` is not zero and must never become it: a marker that was not
    measured is missing, and a missing value scored as 0 is a fabricated observation."""
    if value is None or isinstance(value, bool):
        return None
    try:
        return float(value)
    except (TypeError, ValueError):
        return None


def _days(a, b):
    """Whole days between two ISO dates, or None if either will not parse. Dates arrive as strings
    from config and as dates from a frame; both are accepted and neither is guessed at."""
    from datetime import date, datetime # noqa: PLC0415

    def _d(x):
        if isinstance(x, datetime):
            return x.date()
        if isinstance(x, date):
            return x
        if isinstance(x, str) and ISO_DATE.match(x.strip()):
            return datetime.strptime(x.strip(), "%Y-%m-%d").date()
        return None
    da, db = _d(a), _d(b)
    return None if (da is None or db is None) else (db - da).days


def ordered(series, same_day):
    """(value, date) pairs a reading can be taken over: numeric, dated, and in date order.

`same_day` resolves ties and HAS NO DEFAULT, because
    every default here is a clinical position taken silently — see SAME_DAY.

    UNSORTED INPUT IS NOT AN ERROR and must not be treated as one — a frame arrives in whatever
    order a shuffle produced, and a "first qualifying value" computed over an arbitrary order is a
    different number every run. Rows with no value or no readable date are DROPPED rather than
    defaulted: a series of three measurements and two blanks is a series of three.
    """
    out = []
    for row in (series or []):
        if isinstance(row, dict):
            v, d = _numeric(row.get("value")), row.get("date")
        else:
            try:
                v, d = _numeric(row[0]), row[1]
            except (TypeError, IndexError, KeyError):
                continue
        if v is None or _days(d, d) is None:
            continue
        out.append((v, d))
    # A TIE IS RESOLVED BY THE DECLARED RULE, NEVER BY ARRIVAL ORDER. A stable sort on the date
    # alone leaves same-day rows in whatever order the frame arrived in, which makes the reading
    # a property of a shuffle. An unrecognised value is refused rather than defaulted, because
    # falling back to either one takes the clinical position SAME_DAY exists to make explicit.
    if same_day not in SAME_DAY:
        raise ValueError(f"serial_markers.same_day {same_day!r} is not one of {SAME_DAY}")
    sign = 1 if same_day == "lowest_first" else -1
    return sorted(out, key=lambda p: (_days("1900-01-01", p[1]), sign * p[0]))


def qualifies(spec, reference, value):
    """Whether `value` has moved away from `reference` by everything the instrument requires.

    BOTH THRESHOLDS WHEN BOTH ARE STATED, and this is the clause most easily got wrong. PCWG3-shaped
    criteria pair a PERCENTAGE with an ABSOLUTE floor precisely so that a large relative move on a
    tiny value does not qualify; reading them as alternatives would fire on exactly the noise the
    absolute floor exists to suppress. `instrument_errors` requires at least one, and applies every
    one that is stated.
    """
    pct, abs_ = _numeric(spec.get("threshold_pct")), _numeric(spec.get("threshold_abs"))
    rise = str(spec.get("direction")) == "rise"
    delta = (value - reference) if rise else (reference - value)
    if delta <= 0:
        return False
    if abs_ is not None and delta < abs_:
        return False
    if pct is not None:
        # A REFERENCE OF ZERO HAS NO PERCENTAGE, and dividing by it would raise inside a build. An
        # undefined relative change is not a satisfied one.
        if reference == 0:
            return False
        if (delta / abs(reference)) * 100.0 < pct:
            return False
    return True


def reference_at(spec, seen):
    """The value a change is measured FROM, given everything seen up to here.

    `nadir` is the extreme SO FAR rather than of the whole series, which is the difference between
    a criterion and hindsight: a rise is judged against the lowest value a clinician had seen when
    it happened, not against one recorded afterwards.
    """
    if not seen:
        return None
    if str(spec.get("reference")) == "baseline":
        return seen[0]
    return min(seen) if str(spec.get("direction")) == "rise" else max(seen)


def confirmed_change(spec, series):
    """(event date or None, why) — the instrument applied to one patient's series.

    THE CONFIRMATION IS THE POINT. A single qualifying value is a measurement; a criterion asks for
    a second one, far enough after it, that still qualifies. Without that this family would be a
    threshold flag, and every row it claims would be the wrong variable under the right name.

    Returns a REASON on every path, including the negative ones, because "no event" and "could not
    look" are different answers and a bare None conflates them.
    """
    bad = instrument_errors(spec)
    if bad:
        # REFUSES rather than scores an unfilled or contradictory instrument. `engine.validate`
        # refuses it before a build starts; this is the floor under a caller that did not run it.
        raise ValueError("serial_markers instrument cannot be applied: " + "; ".join(bad))
    pairs = ordered(series, str(spec.get("same_day") or "").strip())
    if len(pairs) < 2:
        return None, ("fewer than two usable measurements — a confirmed change needs a value and "
                      "a later one, and one measurement can never be confirmed")
    wait = _numeric(spec.get("confirm_after_days"))
    for i, (value, when) in enumerate(pairs):
        seen = [v for v, _ in pairs[:i]]
        ref = reference_at(spec, seen)
        if ref is None or not qualifies(spec, ref, value):
            continue
        for later_value, later_when in pairs[i + 1:]:
            gap = _days(when, later_when)
            if gap is None or gap < wait:
                continue
            # THE CONFIRMING VALUE IS HELD TO THE SAME REFERENCE the first was judged against.
            # Re-deriving it from the series up to the confirming value would let the nadir move
            # underneath the criterion and quietly un-qualify a rise that already happened.
            if qualifies(spec, ref, later_value):
                event = when if str(spec.get("event_date")) == "first_qualifying" else later_when
                return event, (f"qualifying value at {when} against {spec.get('reference')} "
                               f"{ref}, confirmed at {later_when} ({gap} days)")
        return None, (f"a qualifying value at {when} was never confirmed — no later measurement "
                      f"at least {wait:.0f} days after it also qualified")
    return None, "no measurement qualified against its reference"


def instrument_errors(inst, where="serial_markers[?]") -> list:
    """[why this instrument cannot be applied as written]."""
    out = []
    if not isinstance(inst, dict):
        return [f"{where} must be a mapping"]
    name = str(inst.get("name") or "").strip()
    if not name:
        out.append(f"{where} states no `name` — nothing would name the column it emits")
    elif not IDENTIFIER.match(name):
        out.append(f"{where}.name {name!r} is not a plain identifier, and it becomes a column name")
    # THE TABLE THE SERIES LIVES IN. `build` receives the run's sources as a dict, exactly as
    # `proc` does, and an instrument that does not name its table cannot be applied to anything —
    # guessing (the one PSA-shaped source, say) would bind a criterion to whatever a vendor
    # happened to deliver this quarter.
    v = str(inst.get("source") or "").strip()
    if not v:
        out.append(f"{where} states no `source` — the delivered table the series lives in, and "
                   f"without it the build would have to guess which of the run's sources carries "
                   f"this marker")
    elif not IDENTIFIER.match(v):
        out.append(f"{where}.source {v!r} is not a plain source name")
    for field in ("marker_column", "date_column"):
        v = str(inst.get(field) or "").strip()
        if not v:
            out.append(f"{where} states no `{field}`")
        elif not IDENTIFIER.match(v):
            # THE SQL LESSON, already paid for once in `risk_score`: a column name is interpolated
            # into a generated expression, so anything that is not a bare name lands in the emitted
            # SQL and fails deep inside it rather than here, naming the field.
            out.append(f"{where}.{field} {v!r} is not a plain column identifier — it is "
                       f"interpolated into the expression this compiles to")
    for field, vocab in (("reference", REFERENCES), ("direction", DIRECTIONS),
                         ("event_date", EVENT_DATES), ("same_day", SAME_DAY),
                         ("series_scope", SERIES_SCOPES)):
        v = str(inst.get(field) or "").strip()
        if v not in vocab:
            out.append(f"{where}.{field} {v or '(unstated)'!r} is not one of {vocab} — an "
                       f"unrecognised value would otherwise take a default nobody chose")
    pct, abs_ = _numeric(inst.get("threshold_pct")), _numeric(inst.get("threshold_abs"))
    if pct is None and abs_ is None:
        out.append(f"{where} states neither `threshold_pct` nor `threshold_abs` — an instrument "
                   f"with no threshold fires on the first movement in the right direction, which "
                   f"is noise, not a criterion")
    for f, v in (("threshold_pct", pct), ("threshold_abs", abs_)):
        if v is not None and v <= 0:
            out.append(f"{where}.{f} is {v} — a threshold of zero or less is satisfied by every "
                       f"measurement and states nothing")
    wait = _numeric(inst.get("confirm_after_days"))
    if wait is None:
        out.append(f"{where} states no `confirm_after_days` — the confirmation interval is the "
                   f"whole difference between a criterion and a threshold flag")
    elif wait <= 0:
        out.append(f"{where}.confirm_after_days is {wait} — a confirmation that need not wait can "
                   f"be satisfied by the same day's repeat measurement")
    for slot in GOVERNED_SLOTS:
        v = str(inst.get(slot) or "").strip()
        if not v:
            out.append(f"{where} states no `{slot}` — a published criterion carries its instrument, "
                       f"its citation, and the person who affirmed it on a date")
        elif v.upper().rstrip(".") in PLACEHOLDERS:
            out.append(f"{where}.{slot} is the placeholder {v!r} — these are published criteria and "
                       f"the person accountable for them")
        elif slot == "review_date" and not ISO_DATE.match(v):
            out.append(f"{where}.review_date {v!r} is not an ISO date (YYYY-MM-DD)")
        elif slot == "clinically_reviewed_by" and len(v.split()) < 2:
            out.append(f"{where}.clinically_reviewed_by {v!r} does not name a person — an "
                       f"initialism is a team or a system, and neither affirms a criterion")
    return out


def serial_marker_errors(items) -> list:
    """[why this outcomes.serial_markers block cannot be run as written]."""
    out = []
    if items is None:
        return out
    if not isinstance(items, list):
        return [f"serial_markers must be a list of instruments, got {type(items).__name__}"]
    seen = set()
    for i, inst in enumerate(items):
        where = f"serial_markers[{i}]"
        name = inst.get("name") if isinstance(inst, dict) else None
        if name and name in seen:
            out.append(f"{where} duplicates name {name!r} — the second would overwrite the first")
        if name:
            seen.add(name)
        out += instrument_errors(inst, where)
    return out


def emitted(items) -> set:
    """The columns this block publishes: `<name>` (the event date) and `<name>fl` (whether one
    occurred). NOTHING ELSE — no rate, no slope, no doubling time. Those are the neighbouring
    algorithms this family deliberately does not express, and emitting a column for one would be
    the gap-closed-by-assertion the expressibility matrix exists to prevent."""
    em = set()
    for inst in (items or []):
        name = inst.get("name") if isinstance(inst, dict) else None
        if name:
            em |= {name, name + "fl"}
    return em


def requires(inst) -> list:
    """The source columns one instrument reads — derived from the instrument, never restated."""
    return [c for c in (inst.get("marker_column"), inst.get("date_column")) if c]

def reads(cfg):
    """The declared serial-marker instruments' typed reads — preflight demands what build()
    refuses without."""
    from. import read
    if "outcomes" not in cfg.roles():
        return []
    out = []
    for i, inst in enumerate(cfg.pack("outcomes").get("serial_markers") or []):
        if isinstance(inst, dict):
            label = inst.get("name", i)
            out.append(read(inst.get("source"), requires(inst),
                            f"outcomes.serial_markers[{label!r}]"))
    return out



def answer(spec, series):
    """(event date or None, 0/1 flag) — `confirmed_change` shaped for a column pair.

    THIS IS THE WHOLE OF WHAT THE SPARK PATH COMPUTES. `build` below moves rows around and calls
    this once per patient series; it re-implements nothing. A windowed-SQL translation of the
    criterion would be a SECOND definition of the algorithm on the far side of a comparison — the
    duplication this repository keeps paying for — and the audit finding that an unconfirmed early
    candidate can hide a later valid event is exactly the subtlety a re-implementation would get
    wrong first.

    THE FLAG IS 0 WHEN THE SERIES WAS EXAMINED AND NO CONFIRMED EVENT WAS FOUND — including a
    series of one measurement, which can never be confirmed. A patient with NO usable rows never
    reaches this function; the left join in `build` leaves both columns null there, so "not
    measured" and "measured, no event" stay different answers, which is the None-is-not-zero rule
    one level up.
    """
    when, _why = confirmed_change(spec, series)
    # A Spark timestamp column yields datetime elements; the emitted column is a DATE, and the
    # event is a day, not a moment.
    from datetime import datetime # noqa: PLC0415
    if isinstance(when, datetime):
        when = when.date()
    return when, (1 if when is not None else 0)


def build(F, src, frame, cfg):
    """Apply the outcomes pack's `serial_markers` to the delivered serial sources, one cohort at
    a time, and join the answers onto `frame`.

    NOT ON THE ASSEMBLED COLUMNS, and the difference from `risk_score` is the point: an index
    reads one row per patient, and a criterion reads MANY. Each instrument names the delivered
    table its series lives in (`source` — `src` is the run's source dict, exactly as `proc`
    receives it), and the rows are grouped per patient and handed, whole, to `answer` — the
    tested pure core. The Spark layer moves rows; it decides nothing clinical.

    `series_scope` is applied here and nowhere else: `from_index` inner-joins the frame's
    (patientid, index_date) and keeps measurements ON OR AFTER index, so a pre-treatment low
    cannot set the nadir a rise is judged against; `full_history` groups per patient across
    everything the source carries. The two differ on exactly the patients the criterion exists
    for, which is why the field has no default.

    Returns `frame` untouched when no instrument is declared, which is every pack in the tree
    today. A DECLARED instrument that cannot be applied REFUSES — a missing source table, a
    missing column, a frame without `index_date` under `from_index` — because a declared
    instrument that silently produced no column is the config-and-contract-agree-while-the-
    engine-reads-neither failure this repository has already paid for once.

    NOT YET EXECUTED ON A CLUSTER. No Spark session has run this function — the machine it was
    written on has no Java. What IS demonstrated, by `test_serial_marker`'s stub harness, is the
    exact chain of calls against a faithful in-memory stand-in, executing the same closures over
    realistic rows: plumbing order, scoping, grouping keys, column names, null-vs-zero. The one
    thing that harness cannot prove is Spark itself; a dev rehearsal must run one declared
    instrument before the first pack relies on this.
    """
    items = (cfg.pack("outcomes") or {}).get("serial_markers")
    if not items:
        return frame
    why = serial_marker_errors(items)
    if why:
        raise ValueError("BUILD REFUSED - outcomes.serial_markers cannot be applied as written:"
                         + "".join(f"\n  {w}" for w in why))
    for inst in items:
        name = str(inst["name"])
        source = str(inst["source"])
        marker, datec = str(inst["marker_column"]), str(inst["date_column"])
        if source not in src:
            raise ValueError(
                f"BUILD REFUSED - serial_markers[{name!r}] reads source {source!r}, which this "
                f"run was not given ({sorted(src)}). A declared instrument whose table is absent "
                f"must stop the build, not skip the column it promised.")
        rows = src[source]
        missing = [c for c in ("patientid", marker, datec) if c not in rows.columns]
        if missing:
            raise ValueError(
                f"BUILD REFUSED - serial_markers[{name!r}]: {source!r} lacks column(s) "
                f"{missing} — the instrument names columns this delivery does not carry, and "
                f"`validate` has already advertised {name!r}/{name!r}fl as emitted.")
        scope = str(inst.get("series_scope"))
        if scope == "from_index" and "index_date" not in frame.columns:
            raise ValueError(
                f"BUILD REFUSED - serial_markers[{name!r}] is scoped from_index and the frame "
                f"carries no `index_date` to anchor on.")
        # THE CLOSURE SPARK RUNS IS THE TESTED CORE, with the instrument bound in. The return
        # type is a DDL string so this module never imports pyspark — it must stay importable
        # on a machine that has none, because `validate` imports it on every lint.
        spec = dict(inst)
        fn = F.udf(lambda series, _spec=spec: answer(_spec, series), "struct<dt: date, fl: int>")
        pairs = rows.select("patientid", F.col(marker), F.col(datec))
        if scope == "from_index":
            # INNER join: a patient not in this cohort's frame has no index to anchor on and
            # contributes nothing here; the left join at the end restores them as null.
            anchored = (pairs.join(frame.select("patientid", "index_date"), "patientid", "inner")
.filter(F.col(datec) >= F.col("index_date")))
            keys = ["patientid", "index_date"]
            grouped = (anchored.groupBy("patientid", "index_date")
.agg(F.collect_list(F.struct(F.col(marker), F.col(datec)))
.alias("_sm_series")))
        else:
            keys = ["patientid"]
            grouped = (pairs.groupBy("patientid")
.agg(F.collect_list(F.struct(F.col(marker), F.col(datec)))
.alias("_sm_series")))
        scored = grouped.select(*keys, fn(F.col("_sm_series")).alias("_sm"))
        per = scored.select(*keys, F.col("_sm.dt").alias(name),
                            F.col("_sm.fl").alias(name + "fl"))
        # LEFT, so a patient with no usable measurements keeps BOTH columns null — not measured
        # is a different answer from measured-with-no-event (flag 0), and a fabricated 0 here
        # would be the missing-value-scored-as-zero defect `_numeric` refuses one level down.
        frame = frame.join(per, keys, "left")
    return frame
