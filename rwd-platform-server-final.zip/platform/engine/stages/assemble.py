"""Stage: assemble one cohort's ADS. Ports overall_ads_creation() (per cohort).

Left-joins index + demographics + clinical + treatment + outcomes on (patientid, index_date),
adds the cohort label columns from config (cohort / cohortn / cohortu / cohortun), and returns
one cohort's rows. build_ads.build() unions these across cohorts.
"""
from __future__ import annotations


# The ADS columns the ENGINE stamps on every row: name -> the Config attribute that supplies it.
# Not a contract variable — no record declares them, and the published-surface check imports this to
# tell a provenance stamp from a helper column that leaked.
PROVENANCE_STAMPS = {"data_product_id": "data_product_id",
                     "spec_version": "spec_version",
                     "data_refresh": "refresh"}

# Columns no publication whitelist may omit: identity and provenance are not negotiable — an
# ADS row that cannot say whose it is or which contract/cut produced it is not publishable.
PUBLICATION_MANDATORY = ("patientid", "index_date") + tuple(PROVENANCE_STAMPS)


def publication_projection(cfg, available):
    """(ordered publish columns, errors) — the declared ADS publication whitelist, judged pure.

    THE MECHANISM half of the audits' final-ADS finding (assembly returned every column the
    stages made, so a helper could leak): a pack that declares `publication.columns` in
    `data_product.yaml` gets EXACTLY that ordered projection — a declared column the build
    did not produce refuses by name, a duplicate refuses, and the identity/provenance columns
    (PUBLICATION_MANDATORY) must be on the list. A pack that declares nothing keeps today's
    behaviour unchanged, with the standing honesty note in the review doc — because the NAMES
    on the list are NAME-ALIGN's ruling to make (Science), and this function only enforces
    whichever list a person declared. Returns (None, []) when undeclared."""
    try:
        pub = (cfg.raw.get("publication") or {}).get("columns")
    except Exception: # noqa: BLE001 - a stub cfg declares nothing
        return None, []
    if pub is None:
        return None, []
    errors, seen, cols = [], set(), []
    avail = {str(c).lower() for c in (available or ())}
    for c in pub:
        name = str(c).strip().lower()
        if not name:
            errors.append("publication.columns carries an empty name")
            continue
        if name in seen:
            errors.append(f"publication.columns lists {name!r} twice — one surface, "
                          f"one position per column")
            continue
        seen.add(name)
        if name not in avail:
            errors.append(f"publication.columns declares {name!r} but the build did not "
                          f"produce it — a whitelist naming a phantom column is a stale "
                          f"declaration, refused rather than skipped")
        cols.append(name)
    missing = [m for m in PUBLICATION_MANDATORY if m not in seen]
    if missing:
        errors.append(f"publication.columns omits {', '.join(missing)} — identity and "
                      f"provenance are not optional on a published surface")
    if errors:
        return None, errors
    return cols, []


def build(idx, dem, clin, trt, out, cfg, cohort, treated):
    from pyspark.sql import functions as F

    keys = ["patientid", "index_date"]
    ads = (idx
.join(dem, keys, "left")
.join(clin, keys, "left")
.join(trt, keys, "left")
.join(out, keys, "left"))

    # treat_flag comes from actual treatment evidence (patients with >=1 LOT row), derived
    # once in build_ads — NOT from trt, which carries every indexed patient (incl. untreated).
    ads = ads.join(treated, "patientid", "left")

    ts = cfg.treatment_status
    # COHORTU/COHORTUN: treated-vs-untreated label + code. A dual-setting product sets
    # treatment_status.by_setting.<setting> (keyed by the cohort's lower-cased line_setting) so each
    # setting gets its own labels/codes (Untreated mCRPC=1 / Treated mCRPC=2 / Untreated mHSPC=3 /
    # Treated mHSPC=4); a single-setting tumor uses the flat treated_label/untreated_label (codes 1/2).
    by = (ts.get("by_setting") or {}) if isinstance(ts, dict) else {}
    sts = by.get(str(cohort.get("line_setting", "")).lower(), ts)
    tlabel, ulabel = sts.get("treated_label"), sts.get("untreated_label")
    tcode, ucode = sts.get("treated_code", 1), sts.get("untreated_code", 2)
    # Cohort-indexed line-of-therapy category: one lotcat/lotcatn = the category of the line THIS
    # cohort indexes on — lotN for a line cohort, lotNm for a maintenance cohort, line 1 for overall —
    # so TFLs/dashboard summarise the right line per cohort instead of always lot1cat.
    ln = cohort.get("lot_number")
    suffix = "m" if cohort.get("maintenance") else ""
    cat_col = f"lot{ln}{suffix}cat" if ln is not None else "lot1cat"
    catn_col = f"lot{ln}{suffix}catn" if ln is not None else "lot1catn"
    # These fields read only the existing joined row or literal configuration.
    # One projection preserves their expressions and insertion order while
    # avoiding repeated Catalyst analysis of the same large joined lineage.
    added = {
        "cohort": F.lit(cohort["label"]),
        "cohortn": F.lit(cohort["cohortn"]),
        "cohortu": F.when(F.col("treat_flag").isNotNull(), F.lit(tlabel)).otherwise(F.lit(ulabel)),
        "cohortun": F.when(F.col("treat_flag").isNotNull(), F.lit(tcode)).otherwise(F.lit(ucode)),
    }
    # QC/provenance: each row self-identifies its product + contract + cut. data_product_id is the
    # stable product id; spec_version (CalVer 202606) and data_refresh (2026q1) are two DISTINCT axes
    # (spec_version must NOT carry the refresh). Build-level provenance (engine_version / git_commit
    # / build_id) lives in the manifest, keyed by these stamps.
    #
    # Driven from PROVENANCE_STAMPS rather than three literal withColumn calls, because the published
    # -surface check has to know which ADS columns the ENGINE adds and no contract record declares.
    # Spelling them a second time in that check is how it would come to report a stamp as a leak, or
    # miss a fourth one added here.
    for _name, _attr in PROVENANCE_STAMPS.items():
        added[_name] = F.lit(getattr(cfg, _attr))
    if cat_col in ads.columns: # treatment emits this line's category column
        added.update(lotcat=F.col(cat_col), lotcatn=F.col(catn_col))
    ads = ads.withColumns(added)
    ads = ads.distinct()
    # THE DECLARED PUBLICATION WHITELIST: when the pack
    # declares publication.columns, the ADS is EXACTLY that ordered projection — helpers and
    # undecided names cannot leak past a declaration. Undeclared -> unchanged behaviour;
    # the list's CONTENT is NAME-ALIGN's ruling, and this only enforces what a person declared.
    cols, errs = publication_projection(cfg, ads.columns)
    if errs:
        raise ValueError("PUBLICATION WHITELIST REFUSED — " + "; ".join(errs))
    if cols is not None:
        ads = ads.select(*cols)
    return ads
