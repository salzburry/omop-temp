"""Stage: load source tables. Ports the block of `tbl(con, in_schema(...))` reads.

Loads ONLY the sources the tumor declares (cfg.sources), with columns lower-cased. Table names
are vendor-resolved via cfg.table(name), so the snapshot AND the vendor (Flatiron / COTA / …) are
config, not code. Robust to tumors that omit `enhanced` or use an N-column advanced-diagnosis rule.

When `source_union` is configured, each source is read from EVERY member schema, tagged with the
`discriminator` column, and unioned — the engine equivalent of the EC `union_func` (Flatiron EDM ∪
Dostarlimab registry, db = EDM/DOS).
"""
from __future__ import annotations


def rename_collisions(columns, renames):
    """Pure: the defects a rename plan would mint over these (already lower-cased) columns.

    The follow-through on the case-fold work: the raw delivery is checked, but the
    FORMAT RENAME block runs after the fold and could still target an existing column, chain
    one rename into another, or map two delivered columns onto one logical name - and Spark
    would carry the duplicate silently. Computed BEFORE any withColumnRenamed, so the refusal
    names the plan, not the wreckage."""
    cols = {str(c).lower() for c in columns}
    applied = {str(p).lower(): str(lo).lower() for p, lo in (renames or {}).items()
               if str(p).lower() in cols and str(p).lower() != str(lo).lower()}
    problems, targets = [], {}
    for p, lo in sorted(applied.items()):
        if lo in applied:
            problems.append(f"{p} -> {lo} chains into another rename ({lo} -> {applied[lo]}) "
                            f"- order-dependent, refused")
        elif lo in cols:
            problems.append(f"{p} -> {lo} collides with an existing column {lo!r}")
        if lo in targets:
            problems.append(f"{targets[lo]} and {p} both rename to {lo!r}")
        targets[lo] = p
    return problems


def _union_members(spark, cfg, name, union, F, pins=None):
    """Read `name` from each union member schema, tag with the discriminator flag, and unionByName.

    `allowMissingColumns=True` so a registry table with a slightly different column set still unions
    (the engine then sees the superset). Mirrors EC's `edm %>% mutate(db='EDM') %>% union_all(dos…)`.
    """
    from functools import reduce
    from..validate import casefold_collisions # noqa: PLC0415
    disc = union.get("discriminator", "db")
    parts = []
    for m in union.get("members", []):
        part = _read(spark, cfg.table_in(name, m["schema"]), pins)
        # PER MEMBER, BEFORE THE UNION: a within-member case collision would otherwise
        # reach unionByName first and fail there ambiguously — or resolve silently under Spark's
        # case-insensitive name resolution — far from the delivery that caused it.
        _colls = casefold_collisions(part.columns)
        if _colls:
            raise ValueError(
                f"{name} member schema '{m['schema']}': delivered columns collide once case is "
                f"folded - " + "; ".join(f"{lo} <- {', '.join(orig)}" for lo, orig in _colls)
                + ". Refused before the union binds them; fix the delivery upstream.")
        parts.append(part.withColumn(disc, F.lit(m["flag"])))
    if not parts:
        raise ValueError(f"source_union for '{name}' has no members")
    return reduce(lambda a, b: a.unionByName(b, allowMissingColumns=True), parts)


def _read(spark, fqn, pins):
    """The one table-read. A pin is what the manifest RECORDED for this fqn; reading anything else
    lets a concurrent writer slip a newer version under a lazily-evaluated plan while the ledger
    still claims the probed one — recorded-but-not-used lineage. No pin = current.

    A pin may be a bare delta version (the original shape, kept for the synthetic suites) or the
    full lineage entry {delta_version, table_id, location, ...}. With the full entry the read also
    VERIFIES TABLE IDENTITY: version N of a dropped-and-recreated table belongs to a different
    Delta log, so a name+version pin could describe table A while the read returned table B — the
    manifest lying by way of a rename. Identity mismatch is a refusal, not a note.

    The check is a verify-READ-verify sandwich on {table_id, location}: the name is verified
    before the read AND after the DataFrame resolves, because a name is mutable and a concurrent
    DROP/CREATE or re-point between the DESCRIBE and the read would bind the plan to a different
    table than the one just verified. Unity Catalog forbids path reads on managed tables, so the
    location cannot be read directly — instead it is held as identity: the recorded location must
    be the location the name resolves to on both sides of the read."""
    if not (pins and fqn in pins):
        return spark.table(fqn)
    pin = pins[fqn]
    if not isinstance(pin, dict):
        return spark.read.option("versionAsOf", str(pin)).table(fqn)

    def _verify(moment):
        want_id, want_loc = pin.get("table_id"), pin.get("location")
        if not (want_id or want_loc):
            return
        got = spark.sql(f"DESCRIBE DETAIL {fqn}").collect()[0].asDict()
        if want_id and str(got.get("id")) != str(want_id):
            raise RuntimeError(
                f"SOURCE IDENTITY MISMATCH ({moment}) — {fqn} is Delta table id {got.get('id')} "
                f"but the probed lineage recorded {want_id}. The table was dropped and recreated "
                f"(or the name re-pointed) after the probe; version {pin.get('delta_version')} of "
                f"the current table is NOT the bytes the manifest describes. Re-run so the probe "
                f"and the read see one table.")
        if want_loc and str(got.get("location")) != str(want_loc):
            raise RuntimeError(
                f"SOURCE LOCATION MISMATCH ({moment}) — {fqn} stores its data at "
                f"{got.get('location')} but the probed lineage recorded {want_loc}. The name now "
                f"resolves to a different Delta location than the one the manifest describes; "
                f"this read would bind to bytes the probe never saw. Re-run so the probe and the "
                f"read see one table.")

    _verify("before read")
    df = spark.read.option("versionAsOf", str(pin["delta_version"])).table(fqn)
    _verify("after read")
    return df


def reads(cfg):
    """The loader's own read: every index_dates model is materialized on the INDEX SOURCE from its
    `of` columns, so ALL of them are required there — a typo'd `of` column would otherwise be
    silently skipped and the model built from whatever happens to be present. A per-model
    `source:` naming a DIFFERENT source is refused by validate.problems(): this loader
    materializes on cfg.index_source only, and a key the validator honoured while the loader
    ignored it was two answers to one question."""
    from. import read
    out = []
    for key, rule in (cfg.index_dates or {}).items():
        if isinstance(rule, dict):
            out.append(read(rule.get("source", cfg.index_source),
                            ["patientid"] + [str(c) for c in (rule.get("of") or [])],
                            f"index.{key}"))
    return out


# Prefix for the preserved pre-transform copy of a column the plan overwrites in place. Reserved:
# nothing in a delivery may carry it, and the publish whitelist never emits it.
RAW_SHADOW = "__rwdp_raw__"


def _apply_plan(F, df, columns, role):
    """Execute one role's reviewed column plan: alias the delivered column to its canonical name,
    then parse or cast it to the declared type.

    THE COLUMN IS ADDED, NEVER SUBSTITUTED FOR THE DELIVERY. The frame keeps every column it
    arrived with and gains the canonical ones, because a stage this plan does not mention still
    reads what it always read — dropping to the bound set would make adding a column to the
    adapter a prerequisite for every existing rule, and a half-written plan would silently
    shrink the delivery.

    A PLANNED COLUMN THE DELIVERY DOES NOT HAVE IS LEFT ALONE, not filled with null. Preflight
    owns "the delivered table is missing a required column" and reports it against the physical
    schema; inventing an all-null column here would answer that question wrongly and quietly,
    and every downstream count would then be computed over a column that does not exist.
    """
    if not columns:
        return df
    from..source_parsers import PARSERS # noqa: PLC0415
    have = set(df.columns)
    for canonical, spec in sorted(columns.items()):
        phys = str(spec.get("physical") or canonical).lower()
        if phys not in have:
            continue # preflight reports it; this must not invent a column
        lt = str(spec.get("logical_type") or "string")
        parser = spec.get("parser")
        # Backticks doubled, which is Spark's own escape. The adapter is a reviewed artifact, so
        # this is not a hostile-input guard — it is the difference between a column named oddly by
        # a vendor being bound and the expression silently parsing as something else.
        q = "`" + phys.replace("`", "``") + "`"
        # EVERY CONVERSION IS EXPLICITLY TOTAL — `try_cast`, `try_to_timestamp` — and that is a
        # correctness requirement, not a preference.
        #
        # A plain `cast` and a plain `to_date` are not one behaviour but two. With
        # `spark.sql.ansi.enabled` OFF a value they cannot read becomes null; with ANSI ON the same
        # expression RAISES mid-build. Spark 4 defaults ANSI on and DBR 15.4 defaults it off, which
        # is precisely the pair this repository runs on: CI and production. So one reviewed adapter
        # died in CI and silently nulled in production, on identical data — the environment-
        # dependent difference this layer exists to remove, and the code carried the warning about
        # it in the parser-less date branch below while three branches above it did the same thing.
        #
        # try_* pins the answer to NULL on both runtimes. Null is not the end of the story: what a
        # binding threw away is then MEASURED (`plan_parse_loss`) and a total loss is refused by the
        # source gate. Deterministic first, audited second — a raise on one cluster is neither.
        if parser in ("epoch_seconds", "epoch_millis"):
            div = 1000 if parser == "epoch_millis" else 1
            ts = f"from_unixtime(try_cast({q} as long) / {div})"
            expr = F.expr(f"to_date({ts})" if lt == "date" else f"to_timestamp({ts})")
        elif parser and PARSERS.get(parser):
            pattern = PARSERS[parser]
            ts = f"try_to_timestamp(cast({q} as string), '{pattern}')"
            expr = F.expr(ts if lt == "timestamp" else f"to_date({ts})")
        elif lt in ("date", "timestamp"):
            # NEVER BARE-CAST A DATE, and the reason is that Spark's answer depends on the
            # cluster. With `spark.sql.ansi.enabled` false a malformed value becomes null and
            # the column reads as legitimately empty; with ANSI on the same plan throws
            # mid-build. One reviewed adapter would then behave two ways on two runtimes — the
            # environment-dependent silent difference this whole layer exists to remove.
            # `check` already refuses a parser-less date binding; this is the loader refusing to
            # guess if one reaches it anyway.
            raise ValueError(
                f"{role}.{canonical}: bound as {lt} with no parser, so the delivered shape is "
                f"unknown — casting would null every row on one runtime and raise on another. "
                f"State the parser in the adapter ({', '.join(sorted(PARSERS))}).")
        else:
            expr = F.expr(f"try_cast({q} as {lt})")
        # THE RAW IS KEPT WHEN THE OVERWRITE WOULD DESTROY IT. Where the delivered column already
        # carries the canonical name — the COMMON case, since a rename is the exception — this
        # `withColumn` replaces the raw in place, and the parse-loss audit that runs afterwards
        # then compares the transformed column to ITSELF: `notNull AND isNull` is structurally
        # zero, so a cast that nulled half the column reported nothing lost. A `linenumber` of
        # ["1", "oops"] bound as integer became [1, null] and audited as one delivered, none lost,
        # instead of two delivered, one lost. Shadowing the raw under a reserved name keeps both
        # sides of the comparison alive; `plan_parse_loss` prefers the shadow where it exists.
        if phys == canonical and canonical in df.columns:
            df = df.withColumn(RAW_SHADOW + canonical, F.col(phys))
        df = df.withColumn(canonical, expr)
    return df


def plan_parse_loss(F, df, columns) -> dict:
    """{canonical: {delivered, lost, rate}} — how much of a reviewed binding the cast threw away.

    THE FAILURE NO TYPE CHECK CAN SEE. `accepted_physical_types` catches a delivery whose column is
    the wrong TYPE; it cannot catch a delivery of the right type whose VALUES do not convert. A
    `string` column the adapter binds as `integer` is a perfectly acceptable string, and
    `col.cast("integer")` turns `1a` into null without a word — so a column reads as legitimately
    empty and every count computed over it is wrong by exactly the rows that failed to parse. The
    date parsers have the same property: a delivery stating `2016-01-01` under a `ddmmmyyyy` binding
    nulls every row, and the reviewed adapter looks like it ran.

    Measured as ONE fused aggregate over the frame, two counts per bound column: how many rows
    arrived with a value, and how many of those came out null. A string binding with no parser is
    skipped whatever the two names are — that is a RENAME, and `try_cast` of a string to a string
    returns the string, so watching it would spend two counts to prove zero.
    """
    if not columns:
        return {}
    have = set(df.columns)
    aggs, watched = [], []
    for canonical, spec in sorted(columns.items()):
        spec = spec or {}
        phys = str(spec.get("physical") or canonical).lower()
        lt = str(spec.get("logical_type") or "string")
        parser = spec.get("parser")
        # The RAW side of the comparison: the shadow where the transform overwrote in place,
        # otherwise the distinctly-named delivered column. Reading `phys` unconditionally is what
        # made a same-named binding audit itself and always report zero loss.
        raw = RAW_SHADOW + canonical if (RAW_SHADOW + canonical) in have else phys
        if raw not in have or canonical not in have:
            continue # preflight owns absence; this measures what ran
        if lt == "string" and not parser:
            # A string binding with no parser is a RENAME, whatever the two names are: `try_cast`
            # of a string to a string returns the string. Nothing can be lost, so watching it would
            # spend two counts per column to prove zero.
            continue
        watched.append(canonical)
        aggs.append(F.count(F.when(F.col(raw).isNotNull(), F.lit(1))).alias(f"{canonical}__in"))
        aggs.append(F.count(F.when(F.col(raw).isNotNull() & F.col(canonical).isNull(),
                                   F.lit(1))).alias(f"{canonical}__lost"))
    if not aggs:
        return {}
    row = df.agg(*aggs).collect()[0].asDict()
    out = {}
    for c in watched:
        delivered = int(row.get(f"{c}__in") or 0)
        lost = int(row.get(f"{c}__lost") or 0)
        out[c] = {"delivered": delivered, "lost": lost,
                  "rate": (lost / delivered) if delivered else None}
    return out


def load(spark, cfg, pins=None) -> dict:
    from pyspark.sql import functions as F

    union = cfg.source_union
    # THE TWO OVERLAYS MUST NOT BOTH GOVERN ONE COLUMN, checked before a single table is read. The
    # loader applies the format rename block and then the adapter plan, so a rename that consumes a
    # column the adapter binds makes the reviewed cast a no-op — and the no-op is invisible, because
    # "a planned column the delivery lacks is left alone" is also the correct rule for a genuinely
    # absent column. run_rwdp refuses this up front; this is the loader refusing if one reaches it.
    from engine import validate as _v # noqa: PLC0415
    _conflicts = _v.adapter_rename_conflicts(cfg)
    if _conflicts:
        raise ValueError("SOURCE OVERLAY CONFLICT — the reviewed adapter and the format rename "
                         "block claim the same column(s):\n  " + "\n  ".join(_conflicts))
    src = {}
    for name in cfg.sources: # declared sources only
        df = (_union_members(spark, cfg, name, union, F, pins) if union
              else _read(spark, cfg.table(name), pins))
        # REFUSED BEFORE THE FOLD: `PatientID` beside `patientid` would become
        # two identical column names below - an ambiguity Spark then reports far from its cause,
        # or worse, resolves arbitrarily. The check is `validate.casefold_collisions`, the same
        # helper preflight uses, so the two boundaries agree on what a collision is.
        from..validate import casefold_collisions # noqa: PLC0415
        _colls = casefold_collisions(df.columns)
        if _colls:
            raise ValueError(
                f"{name}: delivered columns collide once case is folded - "
                + "; ".join(f"{lo} <- {', '.join(orig)}" for lo, orig in _colls)
                + ". Lower-casing would mint duplicate columns; fix the delivery upstream - "
                  "adapters run AFTER the fold and cannot tell the two spellings apart.")
        for col in df.columns: # lower-case all columns (R: rename_with(tolower))
            if col != col.lower():
                df = df.withColumnRenamed(col, col.lower())
        # Per-format column renames (e.g. Panoramic physical -> logical/EDM names) so the engine always
        # sees the logical names. Applied after lower-casing; absent columns are a no-op. Empty for EDM.
        # The PLAN is validated before a single rename runs: a target that already
        # exists, a chained rename, or two sources onto one name would mint duplicates the
        # case-fold check above can never see.
        _ren = cfg.source_renames.get(name) or {}
        _bad = rename_collisions(df.columns, _ren)
        if _bad:
            raise ValueError(f"{name}: the format rename block would mint duplicate columns - "
                             + "; ".join(_bad) + ". Fix the rename map; a collision here "
                             "overwrites a delivered column silently.")
        for phys, logical in _ren.items():
            p, lo = phys.lower(), logical.lower()
            if p in df.columns and p != lo:
                df = df.withColumnRenamed(p, lo)
        #...AND THE REVIEWED ADAPTER PLAN, which is the same idea taken all the way: not just a
        # rename but the delivered TYPE and the delivered SHAPE. `source_renames` can carry a
        # column called `startdt` to `startdate`; it cannot say that the delivered value is the
        # string `01JAN2016` and must become a date. Without that, a definition written against
        # one vendor cannot run against another whose columns are typed differently, and the
        # portability the adapter promises stops at the table name.
        #
        # Empty without a bound plan, so a pack with no adapter loads exactly as it always has.
        df = _apply_plan(F, df, (cfg.adapter_columns or {}).get(name) or {}, name)
        # THE LAST GATE ON NAME UNIQUENESS: the fold, the renames and the adapter
        # plan each ran their own check, but this is the one that holds whatever combination
        # produced the frame - a source leaves this stage with unique names or not at all.
        _dups = sorted({c for c in df.columns if list(df.columns).count(c) > 1})
        if _dups:
            raise ValueError(f"{name}: duplicate column name(s) after renames and the adapter "
                             f"plan: {', '.join(_dups)} - every later stage would resolve the "
                             f"ambiguity silently and differently.")
        src[name] = df

    # Materialize each index_dates model as a column on the configured INDEX SOURCE (default
    # 'enhanced'; heme sets advanced_diagnosis_date.source: diagnosis). Column name = the model key
    # with underscores removed, so `advanced_diagnosis_date` -> advanceddiagnosisdate (unchanged). A
    # dual-setting product adds e.g. hspc_diagnosis_date / crpc_diagnosis_date so each overall cohort
    # can index off ITS setting's diagnosis date. Materialized only where the rule's columns exist.
    isrc = cfg.index_source
    if isrc in src:
        for key, rule in (cfg.index_dates or {}).items():
            if not isinstance(rule, dict):
                continue
            of = [c.lower() for c in rule.get("of", [])]
            present = [c for c in of if c in src[isrc].columns]
            if not present:
                continue
            # max over the present inputs; greatest needs >=2 args, so a single present column IS the max.
            expr = (F.greatest(*[F.col(c) for c in present])
                    if rule.get("method", "max") == "max" and len(present) > 1
                    else F.col(present[0]))
            src[isrc] = src[isrc].withColumn(key.replace("_", ""), expr)
    return src
