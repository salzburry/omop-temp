"""Stage: demographics. Ports demographics_variable_addn().

Age banding and the region/race/ethnicity/practice mappings are read from
variables/demographics.yaml and compiled to Spark SQL CASE expressions, so the bands and
crosswalks are reviewed config — not buried in engine code.
"""
from __future__ import annotations


def _q(s: str) -> str:
    return "'" + str(s).replace("'", "''") + "'"


def _bands_case(bands, value_expr, key="label"):
    """CASE over numeric bands with min/max[/_excl] bounds and a fallthrough row."""
    whens = []
    for b in bands:
        out = _q(b[key]) if key == "label" else str(b[key])
        if "when" in b and b["when"] == "fallthrough":
            continue
        conds = []
        if "eq" in b:
            conds.append(f"{value_expr} = {b['eq']}")
        if "ge" in b:
            conds.append(f"{value_expr} >= {b['ge']}")
        if "min" in b:
            conds.append(f"{value_expr} >= {b['min']}")
        if "max" in b:
            conds.append(f"{value_expr} <= {b['max']}")
        if "max_excl" in b:
            conds.append(f"{value_expr} < {b['max_excl']}")
        if conds:
            whens.append(f"WHEN {' AND '.join(conds)} THEN {out}")
    default = next((b for b in bands if b.get("when") == "fallthrough"), None)
    tail = f" ELSE {_q(default[key]) if key == 'label' else default[key]}" if default else ""
    return "CASE " + " ".join(whens) + tail + " END"


def _map_case(rows, value_expr, key="label"):
    """CASE over a source-value -> reported-value crosswalk (race/ethnicity/practice)."""
    whens = []
    for r in rows:
        out = _q(r[key]) if key == "label" else str(r[key])
        if "from" in r:
            vals = ", ".join(_q(str(v).lower()) for v in r["from"])
            cond = f"LOWER({value_expr}) IN ({vals})"
            if r.get("or_column"):
                # A spec rule like "Hispanic if race=Hispanic OR ethnicity=Hispanic"
                # (G-ETHNICITY-OR): the entry names a SECOND source column whose value also
                # selects this row, against the same declared spellings. Config-declared per
                # entry - an unflagged entry reads exactly one column, as before.
                cond += f" OR LOWER({r['or_column']}) IN ({vals})"
            whens.append(f"WHEN {cond} THEN {out}")
    default = next((r for r in rows if r.get("when") == "fallthrough"), None)
    tail = f" ELSE {_q(default[key]) if key == 'label' else default[key]}" if default else ""
    return "CASE " + " ".join(whens) + tail + " END"


def _region_case(rows, col, key="label"):
    """CASE over state -> region (state IN [...]), with state_is_null -> Missing and fallthrough."""
    whens, missing, default = [], None, None
    for r in rows:
        out = _q(r[key]) if key == "label" else str(r[key])
        if r.get("when") == "state_is_null":
            missing = out
        elif r.get("when") == "fallthrough":
            default = out
        elif "states" in r:
            vals = ", ".join(_q(s) for s in r["states"])
            whens.append(f"WHEN {col} IN ({vals}) THEN {out}")
    pre = f"WHEN {col} IS NULL THEN {missing} " if missing is not None else ""
    tail = f" ELSE {default}" if default is not None else ""
    return "CASE " + pre + " ".join(whens) + tail + " END"


def reads(cfg):
    """The demographics table read (hard), plus the two engine-guarded joins an external review
    found in NO report: `practice` (practic/practicn) and `ses`. Their absence is a degrade the
    build performs silently, so it is DECLARED here with what it does."""
    from . import read
    if "demographics" not in cfg.roles():     # a slim pack configures nothing here — a fact,
        return []                             # not a malformation (test fixtures, new tumours)
    out = [read("demographics", ["patientid", "birthyear", "race", "ethnicity", "state"],
                "demographics.build")]
    dem = cfg.pack("demographics")
    if dem.get("practice_map"):
        # required flips HARD when the region override is declared: the rule reads the
        # practice context, and a degrade there would silently move REGION values
        out.append(read("practice", ["patientid", "practicetype"], "demographics.practice_map",
                        required=bool(dem.get("region_practice_override")),
                        when_absent="practic/practicn are not emitted — the configured practice "
                                    "mapping quietly produces nothing"))
    ses = dem.get("ses") or {}
    if ses.get("source_column"):
        out.append(read("ses", ["patientid", ses["source_column"]], "demographics.ses",
                        required=False,
                        when_absent="the ses column is not emitted — the configured source "
                                    "column quietly produces nothing"))
    return out


def build(src, idx, cfg):
    from pyspark.sql import functions as F

    dem_cfg = cfg.pack("demographics")
    df = idx.select("patientid", "index_date").join(src["demographics"], "patientid", "left")

    if "ses" in src:                                   # SES table (optional)
        df = df.join(src["ses"], "patientid", "left")
    if "practice" in src:                              # practice type aggregated per patient
        agg = (src["practice"].groupBy("patientid")
               .agg(F.expr("concat_ws(',', sort_array(collect_set(upper(practicetype))))")
                    .alias("practicetype_agg")))
        df = df.join(agg, "patientid", "left")

    df = (df.withColumn("year_index", F.year("index_date"))
            # try_cast: a non-numeric birthyear nulls `age` on production and raised in CI.
            # `age` feeds agegr1/agegr1n, so the two runtimes published different cohorts.
            .withColumn("age", F.col("year_index") - F.expr("try_cast(birthyear as int)")))

    df = (df
          .withColumn("agegrl", F.expr(_bands_case(dem_cfg["age_bands"], "age", "label")))
          .withColumn("agegrln", F.expr(_bands_case(dem_cfg["age_bands"], "age", "code")))
          # eth BEFORE race, deliberately: an ethnicity entry may declare `or_column: race`
          # (G-ETHNICITY-OR) and must read the RAW delivered race value - one line down,
          # withColumn("race", ...) overwrites it with the mapped label. Mirrored in stages.R,
          # where dbplyr's sequential mutate semantics create the same hazard.
          .withColumn("eth", F.expr(_map_case(dem_cfg["ethnicity_map"], "ethnicity", "label")))
          .withColumn("ethn", F.expr(_map_case(dem_cfg["ethnicity_map"], "ethnicity", "code")))
          .withColumn("race", F.expr(_map_case(dem_cfg["race_map"], "race", "label")))
          .withColumn("racen", F.expr(_map_case(dem_cfg["race_map"], "race", "code")))
          .withColumn("regionl", F.expr(_region_case(dem_cfg["regions"], "state", "label")))
          .withColumn("regionln", F.expr(_region_case(dem_cfg["regions"], "state", "code"))))

    # G-REGION-ACADEMIC (spec demos.md, "not a decision"): an academic-only patient's region
    # is the declared UNKNOWN group - an academic center draws from everywhere, so its site
    # state places nobody. The override may only point INTO a group the regions already
    # declare (no unreviewed group is minted here), and declaring it makes the practice
    # context a HARD dependency: a declared region rule that silently does not run is a
    # value change nobody sees. == engine-r/stages.R.
    ov = dem_cfg.get("region_practice_override")
    if ov:
        val, into = ov.get("when_practice_agg"), ov.get("into")
        if not (val and into):
            raise ValueError("demographics.region_practice_override needs "
                             "`when_practice_agg` and `into`.")
        # `into` names a regions group by its `when` ROLE - the label and code stay declared
        # exactly once, in the regions list, and an override can only land in a group that
        # list already carries
        grp = next((g for g in dem_cfg.get("regions") or []
                    if str(g.get("when")) == str(into)), None)
        if grp is None:
            raise ValueError(f"region_practice_override: `into: {into}` names no regions "
                             f"group with that `when` role - an override must not mint an "
                             f"unreviewed group.")
        if "practice" not in src:
            raise ValueError("BUILD REFUSED - region_practice_override is declared and the "
                             "'practice' source was not given: the rule cannot be "
                             "evaluated, and skipping it silently would move REGION values.")
        cond = f"UPPER(practicetype_agg) = {_q(str(val).upper())}"
        df = (df.withColumn("regionl", F.expr(
                  f"CASE WHEN {cond} THEN {_q(str(grp['label']))} ELSE regionl END"))
              .withColumn("regionln", F.expr(
                  f"CASE WHEN {cond} THEN {grp['code']} ELSE regionln END")))

    keep = ["patientid", "index_date", "age", "agegrl", "agegrln", "race", "racen",
            "eth", "ethn", "regionl", "regionln"]
    if "practice" in src:
        df = (df.withColumn("practic", F.expr(_map_case(dem_cfg["practice_map"], "practicetype_agg", "label")))
                .withColumn("practicn", F.expr(_map_case(dem_cfg["practice_map"], "practicetype_agg", "code"))))
        keep += ["practic", "practicn"]
    ses = dem_cfg.get("ses", {})
    if ses.get("source_column") and "ses" in src:    # need the ses SOURCE joined, not just the config —
        df = df.withColumn("ses", F.expr(            # else a config with ses.source_column but no ses
            f"coalesce(cast({ses['source_column']} as string), "   # source (e.g. DLBCL) would F.expr an
            f"{_q(ses.get('missing_label', 'Missing'))})"))        # absent column and crash mid-stage.
        keep.append("ses")
    return df.select(*keep)
