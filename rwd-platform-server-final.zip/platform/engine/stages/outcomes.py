"""Stage: outcomes. Ports outcomes_tbl_var().

Follow-up gate (id3mosfu), visit-recency window (vis120) and the months conversion come from
variables/outcomes.yaml. OS / TTD / TTNT / treatment-discontinuation are assembled from the
clinical (dthdt/dthfl/fued) and treatment (per-line lot dates, lotn) tables.

The R keys the line outcomes off a global `coh_flag` with hardcoded lot1/lot2/lot3 branches; the
behaviour is REGULAR in the line number N, so this engine takes N from the cohort (cohort.lot_number)
and parameterises one implementation — same logic for prostate lot1-3 and OC/EC lot1-5. The per-row
CASE expressions are pure SQL-string builders (_trtdis_sql / _ttntfl_sql / _ttnt_sql / _ttd_sql) so
they are unit-tested and proven byte-identical to engine-r/stages.R in tests/test_r_parity.py.

The line outcomes (vis120/trtdis/ttd/ttntfl/ttnt) are OPTIONAL: a tumor enables them with a
`line_outcomes:` block in outcomes.yaml. Without it (or without `trt`), only id3mosfu (+ optional OS)
is emitted — so existing products are unaffected.

Guards against the clinical stage not emitting the death/follow-up anchors OS needs — failing with a
clear message instead of a cryptic Spark "unresolved column" error.
"""
from __future__ import annotations

from .treatment import line_cols          # single source of truth for the per-line column names


def _trtdis_sql(n: int) -> str:
    """trtdis flag for line cohort N: discontinued if a later line started, or death on this line,
    or the patient was still active >=window after line end (vis120). Caller gates on id3mosfu==1
    AND lot{n}sd present. (R: case_when(lotn>N | (lotn==N & !is.na(dthdt)) | vis120==1 ~ 1, ~ 0).)

    The NULL arm: when vis120 is NULL (no visit sources configured — see _vis120), a patient not
    provable as discontinued by lines or death is UNKNOWN, not 0. An external review caught the
    old shape: with no encounter feed the flag claimed "not discontinued" for every such patient."""
    return (f"CASE WHEN lotn > {n} OR (lotn = {n} AND dthdt IS NOT NULL) OR vis120 = 1 "
            f"THEN 1 WHEN vis120 IS NULL THEN NULL ELSE 0 END")


def _ttntfl_sql(n: int, cross_col=None) -> str:
    """ttntfl (had a next-treatment event) for line cohort N: a later line started, or death —
    or, under `ttnt_scope: cross_setting` with a declared cross column, the other setting's
    first line started (G-TTNT-CROSS). Caller gates on id3mosfu==1."""
    cross = f" OR {cross_col} IS NOT NULL" if cross_col else ""
    return f"CASE WHEN lotn > {n} OR dthfl = 1{cross} THEN 1 ELSE 0 END"


def _ttd_sql(n: int, dpm, maint=False) -> str:
    """ttd (time to discontinuation, months) for line cohort N = (datediff(lot{n}ed, index)+1)/dpm
    — the line's LAST-ACTIVITY date (loted), the column treatment.line_cols(n, maint)['lastdate']
    emits; for a MAINTENANCE cohort, the maintenance line's lastdate (lot{n}med). The +1 is the
    spec's INCLUSIVE day (G-TTD-PLUS1) - every other interval here reads it, and TTD was the
    outlier; changed in lockstep with cases.R::ttd_sql, parity-held. Whether TTD ships at all
    stays with its disposition decision - a formula is not a publication ruling. Caller gates
    on id3mosfu==1 and ttd_from_line."""
    return f"(datediff({line_cols(n, maint)['lastdate']}, index_date)+1)/{dpm}"


def _ttnt_sql(n: int, dpm, has_next: bool, cross_col=None) -> str:
    """ttnt (time to next treatment, months) for line cohort N. Event -> to the earlier of the NEXT
    line's start (line_cols(n+1)['start']) and death; censored -> to follow-up end. (R: ttntfl==1 ->
    (datediff(pmin(lot{n+1}sd, dthdt))+1)/dpm; ttntfl==0 -> (datediff(fued)+1)/dpm; else 0.) Spark
    least() skips nulls == pmin na.rm. When the next line column is absent the next date is death."""
    cands = ([line_cols(n + 1)["start"]] if has_next else []) \
        + ([cross_col] if cross_col else []) + ["dthdt"]
    nxt = f"least({', '.join(cands)})" if len(cands) > 1 else cands[0]
    return (f"CASE WHEN ttntfl = 1 THEN (datediff({nxt}, index_date)+1)/{dpm} "
            f"WHEN ttntfl = 0 THEN (datediff(fued, index_date)+1)/{dpm} ELSE 0 END")


def _tsstfl_sql(n: int) -> str:
    """tsstfl (had a 2nd-subsequent-treatment event) for line cohort N: TWO later lines started
    (lotn > N+1), or death. Caller gates on id3mosfu. Mirrors _ttntfl_sql but to line N+2 (TSST = time
    to 2nd subsequent treatment). Byte-identical to engine-r/cases.R::tsstfl_sql (parity-tested)."""
    return f"CASE WHEN lotn > {n + 1} OR dthfl = 1 THEN 1 ELSE 0 END"


def _tsst_sql(n: int, dpm, has_n2: bool) -> str:
    """tsst (time to 2nd subsequent treatment, months) for line cohort N. Event -> to the earlier of the
    N+2 line's start and death; censored -> follow-up end. Mirrors _ttnt_sql but to line N+2. When the
    N+2 column is absent the next date is death. Byte-identical to engine-r/cases.R::tsst_sql."""
    nxt = f"least({line_cols(n + 2)['start']}, dthdt)" if has_n2 else "dthdt"
    return (f"CASE WHEN tsstfl = 1 THEN (datediff({nxt}, index_date)+1)/{dpm} "
            f"WHEN tsstfl = 0 THEN (datediff(fued, index_date)+1)/{dpm} ELSE 0 END")


def _pfs_event_sql(semantics, prog) -> str:
    """The event expression, per the declared semantics — a PURE builder, both branches.

    `incumbent`: `least(prog, dthdt)` — the earlier of progression and death.
    `contract` (G-RWPFS): PROGRESSION PRECEDENCE — a qualifying progression is the event even
    when death is earlier; death is the event only when no progression exists. `coalesce` is
    exactly that reading."""
    return (f"coalesce({prog}, dthdt)" if semantics == "contract"
            else f"least({prog}, dthdt)")


def _pfs_date_sql(semantics, gate, censor_anchor) -> str:
    """The PFSDT expression, per the declared semantics — a PURE builder, both branches.

    `incumbent`: censored patients carry the censor date in PFSDT.
    `contract` (G-RWPFS): PFSDT IS NULL ON CENSOR — the date column carries only real events,
    which changes its meaning for every downstream reader and is why the switch is a declared
    pack act rather than a default. The MONTHS interval keeps the censor anchor under both
    semantics: a censored patient still contributes censored time; what changes is whether the
    DATE column pretends the censor is an event."""
    if semantics == "contract":
        return f"CASE WHEN {gate} THEN _evt ELSE NULL END"
    return f"CASE WHEN {gate} THEN coalesce(_evt, {censor_anchor}) ELSE NULL END"


def _progression_pred(evidence_cols, pseudo_col, yes="Yes", no="No") -> str:
    """A progression EVENT row: ANY evidence flag == yes AND NOT pseudo-progression. (R RW-PFS:
    (isradiographicevidence | ispathologicevidence | …) == 'Yes' AND ispseudoprogressionmentioned ==
    'No'.) Mirrored in engine-r/cases.R::progression_pred and proven byte-identical in test_r_parity."""
    ev = " OR ".join(f"{c} = '{yes}'" for c in evidence_cols)
    return f"({ev}) AND {pseudo_col} = '{no}'"


def _rwpfs_gate(pcfg, clinic_raw) -> str:
    """The rwPFS eligibility predicate that drives BOTH ELIGPFS and the PFS family (flag/date/months):
    >=3 months follow-up (id3mosfu) AND — when `eligibility_requires_censor` is set and a RAW clinic-note
    column exists — a clinic note strictly AFTER index. Using the raw clinic-note date (not the
    fued-coalesced censor) means a patient with only a fued fallback is NOT eligible, which also prevents a
    pre-index censor producing a negative interval. Default (no censor refinement) -> id3mosfu only, so
    OC/EC stay byte-identical. Mirrored inline in engine-r/stages.R::outcomes_build."""
    if pcfg.get("eligibility_requires_censor") and clinic_raw:
        return f"id3mosfu = 1 AND {clinic_raw} > index_date"
    return "id3mosfu = 1"


def _progression(F, Window, idx, prog_df, pcfg, telemetry=None, cohort=None):
    """First and second qualifying progression dates per (patientid, index_date) -> _prog1 / _prog2.

    A qualifying record matches _progression_pred AND has progressiondate > index (progression AFTER
    the cohort's index line). Same-day duplicate evidence rows are collapsed to ONE event (distinct
    dates) before ranking earliest-first — otherwise two records on the same progressiondate would
    fill BOTH _prog1 and _prog2 and PFS2 would double-count a single progression. Returns base
    (patientid, index_date) left-joined to the 1st and 2nd DISTINCT dates (null when none).
    """
    date_col = pcfg["date_column"]
    # progression must be > index + excl days — the rwPFS exclusion window that associates a
    # progression with the INDEX line, not the prior one (prostate: 14; ovarian and endometrial
    # declare 0). DECLARED, NEVER DEFAULTED (twelfth verdict, P0-4): a misspelt key used to run as 0.
    if "exclusion_days" not in pcfg:
        raise ValueError("BUILD REFUSED - outcomes.progression.exclusion_days is not declared; the rwPFS "
                         "exclusion window is a scientific value the contract states (0 included) and "
                         "the engine will not default it")
    excl = int(pcfg["exclusion_days"])
    pred = _progression_pred(pcfg["evidence_columns"], pcfg["pseudoprogression_column"],
                             pcfg.get("yes_value", "Yes"), pcfg.get("no_value", "No"))
    base = idx.select("patientid", "index_date")
    cutoff = F.expr(f"date_add(index_date, {excl})") if excl else F.col("index_date")
    ev = (base.join(prog_df, "patientid", "inner")
          .filter(F.col(date_col) > cutoff)
          .filter(F.expr(pred))
          .select("patientid", "index_date", date_col)
          .distinct())                                   # one row per distinct progression date
    if telemetry is not None:
        # candidates are DISTINCT qualifying event dates (deliberately collapsed above), so
        # tied_same_date_keys is 0 by construction here; the numbers that matter are how many
        # events competed and how many keys got a first progression at all
        telemetry.record_selection(F, ev, ("patientid", "index_date"), date_col,
                                   cohort, "progression", "progression")
    w = Window.partitionBy("patientid", "index_date").orderBy(F.col(date_col).asc())
    ranked = ev.withColumn("_pr", F.row_number().over(w))
    out = base
    for rn, alias in ((1, "_prog1"), (2, "_prog2")):
        d = (ranked.filter(F.col("_pr") == rn)
             .select("patientid", "index_date", F.col(date_col).alias(alias)))
        out = out.join(d, ["patientid", "index_date"], "left")
    if telemetry is not None:
        # non_null of the FIRST date over every index key: "how many patients have a qualifying
        # progression at all" (_prog2 is derivative and not separately counted)
        telemetry.record_selection_outputs(F, out, [("progression", "_prog1")],
                                           cohort, "progression")
    return out


def reads(cfg):
    """The outcomes reads: each visit_sources entry's own date column (through the ONE parser
    below), and the progression family's date/pseudoprogression/evidence columns plus its censor
    source. A malformed visit_sources entry raises here — validate surfaces it as a problem
    instead of silently requiring nothing."""
    from . import read
    if "outcomes" not in cfg.roles():
        return []
    out_cfg = cfg.pack("outcomes")
    out = []
    lo = out_cfg.get("line_outcomes")
    if lo:
        for s, vdate in visit_source_pairs(lo):
            out.append(read(s, ["patientid", vdate], "outcomes.line_outcomes.visit_sources",
                            when_absent="named in visit_sources — the build REFUSES when the "
                                        "feed is not loaded (a partial encounter count would "
                                        "silently understate vis120)"))
    pcfg = out_cfg.get("progression")
    if pcfg:
        out.append(read(pcfg.get("source"),
                        ["patientid", pcfg.get("date_column"),
                         pcfg.get("pseudoprogression_column")]
                        + list(pcfg.get("evidence_columns") or []),
                        "outcomes.progression"))
        cc = pcfg.get("censor")
        if cc:
            out.append(read(cc.get("source"), ["patientid", cc.get("date_column")],
                            "outcomes.progression.censor"))
    return out


def visit_source_pairs(lo):
    """[(source, date_column)] from line_outcomes.visit_sources — THE one reader of that key.

    Two entry shapes: a bare source name, whose encounter date is `visit_date_column` (default
    `visitdate`), or `{source: telemed, date_column: telemeddate}` for a feed whose date column
    is named differently. Any other shape refuses: a feed whose date the build cannot read would
    contribute nothing to vis120 while looking configured.

    Shared with validate.required_columns, so the date column each entry names is REQUIRED of its
    source at preflight — one parser, or the preflight and the build would disagree about what a
    config asks for.
    """
    default = lo.get("visit_date_column", "visitdate")
    entries = lo.get("visit_sources") or []
    if isinstance(entries, str):
        # a scalar (`visit_sources: visit`) would iterate CHARACTER BY CHARACTER here while the
        # R engine reads it as one source — same config, two engines, two answers. Refused.
        raise ValueError(f"line_outcomes.visit_sources must be a list, got the scalar "
                         f"{entries!r} — write `visit_sources: [{entries}]`")
    pairs = []
    for entry in entries:
        if isinstance(entry, dict):
            if not entry.get("source"):
                raise ValueError(f"line_outcomes.visit_sources: a mapping entry must name "
                                 f"`source` (got {entry!r})")
            pairs.append((str(entry["source"]), str(entry.get("date_column") or default)))
        else:
            pairs.append((str(entry), default))
    return pairs


def _vis120(F, base_end, src, lo, win, end_col):
    """vis120 / lastvisitdate for a line cohort. vis120 = 1 if the patient has any visit/telemed
    encounter on/after (line end + win) days, else 0; lastvisitdate = the latest such encounter.
    (R filters encounters to >= DATE_ADD(lot{n}ed, 120), takes the max, flags presence.)

    base_end: (patientid, index_date, <end_col>) for this cohort. Returns (patientid, index_date,
    vis120, lastvisitdate).

    THE ABSENT-FEED ANSWER IS NULL, NOT 0. With no visit sources configured, "had no qualifying
    encounter" is not a fact anyone established — an external review caught mCRC getting vis120=0
    for every line patient because its config never wired `visit_sources`, and 0 fed trtdis as
    "not discontinued". Unconfigured -> NULL (unknown). A CONFIGURED source missing from the
    loaded frames is a different state and refuses: the config claims a feed the build does not
    have, and silently computing over the remainder would understate encounters.
    """
    keys = ["patientid", "index_date"]
    pairs = visit_source_pairs(lo)
    missing = [s for s, _d in pairs if s not in src]
    if missing:
        raise ValueError(f"line_outcomes.visit_sources names source(s) not loaded: "
                         f"{', '.join(missing)} — vis120 computed over a partial encounter feed "
                         f"would silently undercount; fix the config or the source load")
    if not pairs:
        return (base_end.select(*keys).withColumn("vis120", F.lit(None).cast("int"))
                .withColumn("lastvisitdate", F.lit(None).cast("date")))
    enc = None
    for s, vdate in pairs:                            # union the encounter dates across sources
        e = src[s].select("patientid", F.col(vdate).alias("_vd"))
        enc = e if enc is None else enc.unionByName(e)
    qualifying = (base_end.join(enc, "patientid", "left")
                  .filter(F.col("_vd") >= F.expr(f"date_add({end_col}, {win})"))
                  .groupBy(*keys).agg(F.max("_vd").alias("lastvisitdate")))
    return (base_end.select(*keys).join(qualifying, keys, "left")
            .withColumn("vis120", F.when(F.col("lastvisitdate").isNotNull(), F.lit(1))
                        .otherwise(F.lit(0))))


def os_expression(os_cfg, dpm):
    """The OS CASE expression, as a string — extracted so it can be tested without Spark.

    WHICH FLAG GATES OS is `id3mosfu` unless the pack says otherwise, and the default expression
    is BYTE-IDENTICAL to the one this replaced, so no committed number moves.

    `gate: none` is the aim that follows every patient for as long as the data runs. Until now OS
    was NULL for anyone with under ~3 months of potential follow-up and there was no way to ask
    for the ungated endpoint short of standing up a second pack over the same cohort.
    """
    gate = str(os_cfg.get("gate") or "id3mosfu")
    cond = "" if gate == "none" else f"{gate} = 1 AND "
    head = "CASE " if gate == "none" else f"CASE WHEN {gate} = 0 THEN NULL "
    return (head +
            f"WHEN {cond}{os_cfg['event_flag']} = 1 "
            f"  THEN (datediff({os_cfg['death_anchor']}, index_date)+1)/{dpm} "
            f"WHEN {cond}{os_cfg['event_flag']} = 0 "
            f"  THEN (datediff({os_cfg['censor_anchor']}, index_date)+1)/{dpm} "
            f"ELSE NULL END")


# THE TWO DECISION-STAGED SEAMS, same pattern as clinical.FUED_SCOPES: the incumbent behavior
# gets an explicit name, the candidate ruling is declarable and REFUSES with the checklist of
# what must be signed first, and an unrecognised word is never read as the nearest one. Pure
# functions, so a machine with no Spark can test every refusal.

PFS_SEMANTICS = ("incumbent", "contract")
TTNT_SCOPES = ("same_setting", "cross_setting")


def pfs_semantics(pcfg):
    """The declared rwPFS semantics, validated — `incumbent` when absent.

    `incumbent`: event = the earlier of progression and death; a censored patient's PFSDT is
    filled with the censor date; the censor comes from the configured visit anchor. Every
    current number was produced under it, while the rwPFS event/censor decisions are open.

    `contract`: progression precedence (a qualifying progression IS the event, death only when
    no progression exists), PFSDT NULL on censor, censoring from whatever the `censor:` config
    names — for prostate the progression table's LastClinicNoteDate once B3a supplies the
    delivered column names. A CONFIRMED requirement (ENGINE_GAPS.md G-RWPFS; DECISIONS.md's
    "not decisions" list), IMPLEMENTED here: `_pfs_event_sql` / `_pfs_date_sql` carry both
    branches as pure SQL builders, so the difference between the two is testable with no Spark
    at all. The genuinely open remainder is unchanged and narrow — the day-14 index-tie
    boundary (`exclusion_days` config carries the incumbent 14 until it is ruled) and B3a's
    delivered field names / Boolean typing, which need the live DESCRIBE only prod can run. An
    earlier version of this seam refused the branch as "awaiting a ruling"; an audit caught
    that as re-litigating a settled item, and the refusal before that computed nothing at all —
    this is the third and correct state: implemented, selectable, tested."""
    v = str((pcfg or {}).get("semantics") or "incumbent")
    if v not in PFS_SEMANTICS:
        raise ValueError(
            f"BUILD REFUSED - outcomes.progression.semantics {v!r} is not one of "
            f"{PFS_SEMANTICS} - an unrecognised word read as the nearest one would pick a "
            f"clinical definition nobody chose.")
    return v


def ttnt_scope(out_cfg):
    """The declared TTNT next-treatment scope, validated — `same_setting` when absent.

    `same_setting`: the incumbent - the next line within the current setting's renumbering, so
    an mHSPC L1 -> mCRPC L1 transition is invisible to TTNT.

    `cross_setting`: a CONFIRMED requirement (ENGINE_GAPS.md G-TTNT-CROSS: 1L mHSPC next =
    min(mHSPC L2, mCRPC L1, death)), IMPLEMENTED: a line cohort that declares
    `ttnt_cross_column` (the other setting's first-line start, e.g. `lot1sd_mcrpc` from
    treatment.setting_line_columns) has that column join the least() beside the same-setting
    next and death, and TTNTFL's event arm gains the same candidate. A cohort declaring no
    cross column keeps same-setting behavior — an mCRPC cohort has no later setting, and that
    absence is meaningful, not defaulted-over. A DECLARED cross column the treatment frame does
    not carry REFUSES the build. The genuinely open half stays TTNTFL-DISPOSITION — whether the
    struck TTNTFL is published, internal-only, or removed — which affects the SURFACE, not this
    computation."""
    v = str((out_cfg or {}).get("ttnt_scope") or "same_setting")
    if v not in TTNT_SCOPES:
        raise ValueError(
            f"BUILD REFUSED - outcomes.ttnt_scope {v!r} is not one of {TTNT_SCOPES}.")
    return v


def build(src, idx, clin, trt, cfg, cohort=None, telemetry=None):
    from pyspark.sql import functions as F, Window

    # cohort LABEL for the opt-in telemetry rows only — nothing below branches on it
    _cid = (cohort or {}).get("id") or str((cohort or {}).get("cohortn"))
    out_cfg = cfg.pack("outcomes")
    # the decision-staged seams are validated on EVERY build, before any frame is touched
    ttnt_scope(out_cfg)
    pfs_semantics(out_cfg.get("progression"))
    min_fu = out_cfg["min_followup_days"]
    dpm = out_cfg["days_per_month"]
    # OBSERVATION END, not the enrollment close. id3mosfu asks "could this patient have been
    # observed >= min_fu days" — a fact about how far follow-up capture extends.
    # cfg.observation_end falls back to study.index_end until a pack states the distinct field,
    # so nothing moves until a human writes the config (the endpoint definition is Science's).
    end = F.lit(cfg.observation_end).cast("date")
    keys = ["patientid", "index_date"]
    base = idx.select(*keys)

    # id3mosfu: >= ~3 months of potential follow-up (observation_end - index_date >= min_fu days).
    out = base.withColumn(
        "id3mosfu",
        F.when(F.datediff(end, F.col("index_date")) >= min_fu, F.lit(1)).otherwise(F.lit(0)))

    # ONE STUDY, SEVERAL AIMS, ONE COHORT. A study routinely asks different follow-up questions of
    # the same patients — overall survival followed indefinitely, resource use over the first year,
    # dose reduction after two — and `min_followup_days` is a single pack-level scalar, so the pack
    # could publish exactly ONE sufficiency flag. Three aims then needed three packs, three
    # cohorts and three builds of the same data, which is how one study becomes three products
    # that have to be proved equivalent afterwards.
    #
    # Each entry publishes ITS OWN FLAG and nothing else changes: `id3mosfu` keeps its meaning and
    # keeps gating what it always gated, so no committed number moves. An aim then filters on the
    # flag it needs — and an aim that follows everyone filters on none of them.
    extra = list(out_cfg.get("followup_sufficiency") or [])
    for entry in extra:
        out = out.withColumn(
            str(entry["name"]),
            F.when(F.datediff(end, F.col("index_date")) >= entry["days"],
                   F.lit(1)).otherwise(F.lit(0)))

    # Death/follow-up anchors (dthfl/dthdt/fued) feed BOTH OS and the line outcomes — join once.
    # `dth_before_fued` joins with them: the corruption guard is CONSUMED here now, per its
    # confirmed spec (ENGINE_GAPS: "DTH_BEFORE_FUED=1 -> each gated outcome/flag NA").
    anchors = [c for c in ("dthfl", "dthdt", "fued", "dth_before_fued")
               if clin is not None and c in clin.columns]
    if anchors:
        out = out.join(clin.select(*keys, *anchors), keys, "left")

    # OS is optional: omit `overall_survival` from outcomes.yaml to skip it. When present it needs the
    # clinical death/follow-up anchors (clinical.follow_up_and_death). Guard with a clear message.
    os_cfg = out_cfg.get("overall_survival")
    if os_cfg:
        required = [os_cfg["event_flag"], os_cfg["death_anchor"], os_cfg["censor_anchor"]]
        missing = [c for c in required if clin is None or c not in clin.columns]
        if missing:
            raise RuntimeError(
                f"outcomes.build: clinical stage did not emit the OS anchor column(s) {missing}. "
                "They come from clinical.follow_up_and_death — ensure it runs, or remove "
                "`overall_survival` from variables/outcomes.yaml to skip OS.")
        out = out.withColumn("os", F.expr(os_expression(os_cfg, dpm)))

    emitted = ["id3mosfu"] + [str(e["name"]) for e in extra] + (["os"] if os_cfg else [])

    # Line-cohort outcomes (vis120 / trtdis / ttd / ttntfl / ttnt). Optional + config-gated; needs
    # the treatment per-line frame. The overall cohort (no lot_number) gets vis120=0 and the rest
    # null, exactly like the R's `coh_flag == "overall"` branches.
    lo = out_cfg.get("line_outcomes")
    if lo and trt is not None:
        win = out_cfg["visit_recency_days"]
        ln = (cohort or {}).get("lot_number")
        maint = bool((cohort or {}).get("maintenance"))     # a lot{N}m cohort keys off the maint line
        if ln is not None:
            # Bring this line's treatment columns (lotn, this line's start/lastdate, next line start
            # for ttnt) using the SAME names treatment.line_cols emits — so they always resolve. For a
            # MAINTENANCE cohort, "this line" is the maintenance line (lot{N}m*: start/lastdate); the
            # NEXT treatment is still the next regimen's (non-maintenance) start.
            cur, nxt = line_cols(ln, maint), line_cols(ln + 1)
            nxt2 = line_cols(ln + 2)
            last_col, start_col = cur["lastdate"], cur["start"]
            has_next = nxt["start"] in trt.columns
            has_n2 = nxt2["start"] in trt.columns
            # G-TTNT-CROSS: under cross_setting scope, a cohort may declare the other setting's
            # first-line start as an additional next-treatment candidate. DECLARED means
            # PRESENT: a named column the treatment frame does not carry refuses the build,
            # never a silently same-setting TTNT under a cross-setting declaration.
            cross_col = ((cohort or {}).get("ttnt_cross_column")
                         if ttnt_scope(out_cfg) == "cross_setting" else None)
            if cross_col and cross_col not in trt.columns:
                raise RuntimeError(
                    f"outcomes.build: cohort {(cohort or {}).get('id')!r} declares "
                    f"ttnt_cross_column {cross_col!r} and the treatment frame does not carry "
                    f"it — declare it in treatment.setting_line_columns or remove the claim.")
            want = (["lotn", start_col, last_col] + ([nxt["start"]] if has_next else [])
                    + ([cross_col] if cross_col else [])
                    + ([nxt2["start"]] if (lo.get("tsst") and has_n2) else []))
            tcols = [c for c in want if c in trt.columns]
            out = out.join(trt.select(*keys, *tcols), keys, "left")
            # vis120 keys off this line's LAST-ACTIVITY date (loted == lastdate); join it, then the
            # line CASEs (which read vis120).
            vis = _vis120(F, out.select(*keys, last_col), src, lo, win, last_col)
            out = out.join(vis, keys, "left")
            gate = f"id3mosfu = 1 AND {start_col} IS NOT NULL"   # trtdis defined only for started line
            out = out.withColumn("trtdis", F.expr(
                f"CASE WHEN {gate} THEN ({_trtdis_sql(ln)}) ELSE NULL END"))
            out = out.withColumn("ttntfl", F.expr(
                f"CASE WHEN id3mosfu = 1 THEN ({_ttntfl_sql(ln, cross_col)}) ELSE NULL END"))
            out = out.withColumn("ttnt", F.expr(
                f"CASE WHEN id3mosfu = 1 THEN "
                f"({_ttnt_sql(ln, dpm, has_next, cross_col)}) ELSE NULL END"))
            if "ttd_from_line" not in lo:                       # declared, never defaulted (thirteenth pass)
                raise ValueError("BUILD REFUSED - outcomes.line_outcomes.ttd_from_line is not declared; the line "
                                 "from which TTD is reported is a scientific value the contract states (1 = every "
                                 "line). The engine refuses to default it.")
            if ln >= int(lo["ttd_from_line"]):                  # R: ttd reported for 2L+ only
                out = out.withColumn("ttd", F.expr(
                    f"CASE WHEN id3mosfu = 1 THEN ({_ttd_sql(ln, dpm, maint)}) ELSE NULL END"))
            else:
                out = out.withColumn("ttd", F.lit(None).cast("double"))
            if lo.get("tsst"):                       # time to 2nd subsequent treatment (TSST)
                out = out.withColumn("tsstfl", F.expr(
                    f"CASE WHEN id3mosfu = 1 THEN ({_tsstfl_sql(ln)}) ELSE NULL END"))
                out = out.withColumn("tsst", F.expr(
                    f"CASE WHEN id3mosfu = 1 THEN ({_tsst_sql(ln, dpm, has_n2)}) ELSE NULL END"))
        else:
            # NOT APPLICABLE IS NULL, LIKE ITS SIBLINGS. A cohort with no line endpoint has no
            # window for vis120 to count in; every other line outcome answers that with NULL, and
            # this one wrote 0 — "no qualifying encounter", a fact nobody established. An external
            # review caught the inconsistency; one question, one answer.
            out = (out.withColumn("vis120", F.lit(None).cast("int"))
                   .withColumn("lastvisitdate", F.lit(None).cast("date")))
            for c in ("trtdis", "ttntfl"):
                out = out.withColumn(c, F.lit(None).cast("int"))
            for c in ("ttd", "ttnt"):
                out = out.withColumn(c, F.lit(None).cast("double"))
            if lo.get("tsst"):
                out = (out.withColumn("tsstfl", F.lit(None).cast("int"))
                       .withColumn("tsst", F.lit(None).cast("double")))
        emitted += ["vis120", "lastvisitdate", "trtdis", "ttd", "ttntfl", "ttnt"]
        if lo.get("tsst"):
            emitted += ["tsstfl", "tsst"]

    # Real-world PFS / PFS2 (progression family). Optional: needs a `progression:` block AND its
    # declared source. Event = the earlier of the first qualifying progression and death; censored at
    # follow-up end; gated on id3mosfu. PFS2 uses the SECOND progression. Cohort-correct via index_date
    # (progressiondate > index + exclusion_days). Two optional, config-gated prostate refinements leave
    # OC/EC byte-identical: `eligibility_flag` emits an explicit rwPFS-eligibility column, and
    # `line_cohorts_only` restricts the family to the LINE cohorts — the overall cohort (no lot_number)
    # gets a NULL family so the per-cohort union stays column-aligned.
    pcfg = out_cfg.get("progression")
    if pcfg and pcfg.get("source") in src:
        miss = [c for c in ("dthdt", "fued") if c not in out.columns]
        if miss:
            raise RuntimeError(
                f"outcomes.build: progression PFS needs clinical anchor(s) {miss} (from "
                "clinical.follow_up_and_death) — or remove `progression` from variables/outcomes.yaml.")
        is_line = (cohort or {}).get("lot_number") is not None
        suppress = bool(pcfg.get("line_cohorts_only")) and not is_line
        semantics = pfs_semantics(pcfg)

        # rwPFS censor: emit the RAW last clinic-note date (NULL when the patient has no clinic note) and
        # censor the interval at coalesce(clinic-note, fued) so everyone stays censorable. Keeping the raw
        # date SEPARATE from the fued fallback is what lets ELIGPFS require a clinic note AFTER index — a
        # patient with only a fued date is NOT eligible (and so can never yield a pre-index censor).
        censor_anchor, ccfg, clinic_raw = "fued", pcfg.get("censor"), None
        if ccfg and ccfg.get("source") in src:
            cas, cdate = ccfg.get("as", "lastclinicnotedate"), ccfg["date_column"]
            agg_word = str(ccfg.get("aggregate") or "")
            if agg_word not in ("min", "max"):                  # a closed vocabulary, never the nearest word
                raise ValueError(f"BUILD REFUSED - outcomes.progression.censor.aggregate {agg_word!r} is not one of "
                                 f"min | max; an unrecognised word read as the nearest one would pick a censor date "
                                 f"nobody chose")
            agg = F.min if agg_word == "min" else F.max
            censor_df = src[ccfg["source"]].groupBy("patientid").agg(agg(F.col(cdate)).alias(cas))
            out = (out.join(censor_df, "patientid", "left")                  # cas = RAW clinic-note date
                   .withColumn("_censor", F.coalesce(F.col(cas), F.col("fued"))))  # censor anchor (fallback)
            censor_anchor, clinic_raw = "_censor", cas
            emitted.append(cas)

        # rwPFS GATE: >=3mo follow-up AND (when eligibility_requires_censor) a clinic note AFTER index. The
        # SAME gate drives ELIGPFS *and* the PFS family, so an ineligible patient is NULL throughout — no
        # stray event a TFL miscounts, no negative interval from a pre-index censor. Default (OC/EC) is the
        # id3mosfu-only gate, so those tumors stay byte-identical.
        gate = _rwpfs_gate(pcfg, clinic_raw)

        eflag = pcfg.get("eligibility_flag")               # prostate ELIGPFS (rwPFS eligibility)
        if eflag:                                          # 1 eligible / 0 ineligible line cohort; NULL overall
            out = out.withColumn(eflag, F.expr(
                f"CASE WHEN {gate} THEN 1 ELSE 0 END" if is_line else "CAST(NULL AS INT)"))
            emitted.append(eflag)
        out = out.join(_progression(F, Window, idx, src[pcfg["source"]], pcfg,
                                    telemetry=telemetry, cohort=_cid), keys, "left")
        for fl, dt, mo, prog in (("pfsfl", "pfsdt", "pfs", "_prog1"),
                                 ("pfs2fl", "pfs2dt", "pfs2", "_prog2")):
            if mo == "pfs2" and not pcfg.get("pfs2"):
                continue
            if suppress:                                   # overall cohort -> NULL family (column-aligned)
                out = (out.withColumn(fl, F.lit(None).cast("int"))
                       .withColumn(dt, F.lit(None).cast("date"))
                       .withColumn(mo, F.lit(None).cast("double")))
            else:
                # flag/date/months all gated on the rwPFS `gate` (== ELIGPFS) so an ineligible patient is
                # NULL throughout — never a stray event flag/date a downstream TFL might miscount.
                # both semantics live in the pure builders above; `semantics` was validated at
                # build start. The MONTHS interval reads the censor-coalesced date under both,
                # so a censored patient contributes censored time even when PFSDT is null.
                out = (out.withColumn("_evt", F.expr(_pfs_event_sql(semantics, prog)))
                       .withColumn(fl, F.expr(f"CASE WHEN {gate} AND _evt IS NOT NULL THEN 1 "
                                              f"WHEN {gate} THEN 0 ELSE NULL END"))
                       .withColumn(dt, F.expr(_pfs_date_sql(semantics, gate, censor_anchor)))
                       .withColumn(mo, F.expr(f"CASE WHEN {gate} THEN "
                                              f"(datediff(coalesce(_evt, {censor_anchor}), "
                                              f"index_date)+1)/{dpm} ELSE NULL END"))
                       .drop("_evt"))
            emitted += [fl, dt, mo]
        out = out.drop("_prog1", "_prog2", "_censor")

    # THE CORRUPTION GUARD, CONSUMED — the confirmed half of its spec. A patient with activity
    # after death has corrupted death/follow-up data, and every outcome anchored on those dates
    # is a number computed over the corruption. ENGINE_GAPS names the gated set exactly: OS,
    # TRTDIS, TTD, TTNT, TTNTFL become NA when the guard fires. TSST/TSSTFL are DELIBERATELY
    # not gated — their applicability "is NOT clearly specified -> resolve in
    # OUTCOME-COHORT-MAP", and auto-applying would be this stage ruling it.
    if "dth_before_fued" in out.columns:
        for _c in ("os", "trtdis", "ttd", "ttntfl", "ttnt"):
            if _c in out.columns:
                out = out.withColumn(_c, F.expr(
                    f"CASE WHEN dth_before_fued = 1 THEN NULL ELSE {_c} END"))
    return out.select(*keys, *emitted)
