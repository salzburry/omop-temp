"""Stage: normalized line-of-therapy table. The single source of `new_lot_n`.

Derives `new_lot_n` once and reuses it for indexing and treatment, so stages can't drift.
`linename` is lower-cased here. Everything is CONFIG-DRIVEN and backward-compatible — the defaults
reproduce the prostate behaviour exactly:

  * line_setting      keep only rows where `linesetting` == it (prostate: mCRPC). None = keep all.
  * exclude_settings  drop rows whose `linesetting` is in this list (EC: ['ADVANCED']). [] = drop none.
  * maintenance       None (default) = no maintenance filter; True/False = keep only
                      `maintenance_column` == 'True'/'False' (OC/EC index off the maintenance flag).
  * line_number_col   'new_lot_n' (default) = a derived row_number over the kept lines (prostate);
                      'linenumber' = use the raw LOT `linenumber` as the line key (OC/EC).

Tumors without these columns (e.g. heme, or a LOT table with no `linesetting`/maintenance flag) are
unaffected: a filter is applied ONLY when the column is present, so it can never empty the table.
"""
from __future__ import annotations

from . import read


def uses_line_setting(cfg) -> bool:
    """A product uses a line-setting model when the GLOBAL lot.line_setting is set OR ANY cohort
    declares its own — the stages resolve `cohort.line_setting` first and fall back to the global,
    so both `lot.linesetting` and the treatment stage's per-line episode aggregation gate on this
    combined answer (a cohort-setting product with no global would otherwise pass preflight while
    the runtime filters on a column nobody required)."""
    return bool(cfg.lot_line_setting or
                any(c.get("line_setting") is not None for c in cfg.cohorts))


def reads(cfg):
    """The LOT table read — hard (`src[\"lot\"]` at first use; index, treatment and the per-line
    outcomes all key off it). `linesetting` only under a line-setting model; the maintenance
    column only when a cohort filters on it."""
    cols = ["patientid", "linename", "startdate", "enddate", "linenumber"]
    if uses_line_setting(cfg):
        cols.append("linesetting")
    if any(c.get("maintenance") is not None for c in cfg.cohorts) and cfg.lot_maintenance_column:
        cols.append(cfg.lot_maintenance_column)
    return [read("lot", cols, "lot.normalized")]


def normalized(src, line_setting=None, exclude_settings=None, maintenance=None,
               line_number_col="new_lot_n", maintenance_column="ismaintenancetherapy"):
    """Relevant LOT rows with `linename` lower-cased and `new_lot_n` set. See module docstring."""
    from pyspark.sql import functions as F
    from pyspark.sql.window import Window

    lot = src["lot"].withColumn("linename", F.lower(F.col("linename")))
    cols = set(lot.columns)
    if line_setting is not None and "linesetting" in cols:
        lot = lot.filter(F.col("linesetting") == line_setting)
    if exclude_settings and "linesetting" in cols:
        lot = lot.filter(~F.col("linesetting").isin(list(exclude_settings)))
    if maintenance is not None and maintenance_column in cols:
        lot = lot.filter(F.col(maintenance_column) == ("True" if maintenance else "False"))

    if line_number_col == "linenumber":
        # OC/EC: a "line N" cohort means the raw LOT line N (combined with the maintenance filter).
        return lot.withColumn("new_lot_n", F.col("linenumber"))
    # Default (prostate/NSCLC): derive new_lot_n as a row_number over the kept lines.
    #
    # EXACT DUPLICATES ARE ONE LINE, NOT TWO. A delivery that repeats a LOT row byte-for-byte
    # would otherwise occupy two line numbers and shift every later line down — the patient's
    # real second line becomes "line 3", and a line-3 cohort quietly indexes the wrong therapy.
    # `.distinct()` and not `dropDuplicates()`: full-row distinct keeps no arbitrary row (every
    # kept row is every dropped row), which is precisely why test_grain's regression guard
    # forbids the latter and why the first version of this fix was CI-red on arrival — the guard
    # exists so that a subset-keyed dedupe choosing a winner by physical row order can never
    # come back, and the same audit that asked for this dedupe caught the violation.
    # STATED RESIDUAL (a specification question, not an engine ruling): the spec wants duplicate
    # LOT records ALERTED as a vendor-quality incident, not only collapsed. That is the
    # source-grain governance work — declaring grain per role and counting what dedupe absorbs —
    # and silently collapsing is the floor, not the ceiling.
    lot = lot.distinct()
    # THE ORDERING RUNS ON THE TYPED DATE. `startdate` arrives as whatever the vendor shipped,
    # and a raw-string sort is chronological only while every value is ISO — the same
    # cast-first rule the index filters follow. NULL STARTS SORT LAST and — the audit's redo
    # point — an undated row now takes NO line number at all: `new_lot_n` is NULL for it, so it
    # can never inflate the line count and never stand as the "next treatment" that flips
    # TRTDIS/TTNTFL. An undated line cannot be ordered among dated ones, and a number it cannot
    # earn must not exist. With nulls sorted last, the dated rows' numbering is unaffected.
    # The keys below are not a TOTAL order: two rows agreeing on all of them still swap
    # `new_lot_n`, observable through any column outside them (`ismaintenancetherapy` is the
    # live example). Ordering on the remainder afterwards costs nothing when there is no tie.
    lot = lot.withColumn("_lot_sd", F.expr("try_cast(startdate as date)"))
    _keyed = ("patientid", "_lot_sd", "startdate", "linenumber", "enddate", "linename")
    rest = [F.col(c).asc_nulls_last() for c in lot.columns if c not in _keyed]
    w = Window.partitionBy("patientid").orderBy(
        F.col("_lot_sd").asc_nulls_last(), F.col("linenumber").asc_nulls_last(),
        F.col("enddate").asc_nulls_last(), F.col("linename").asc_nulls_last(), *rest)
    return (lot.withColumn(
                "new_lot_n",
                F.when(F.col("_lot_sd").isNotNull(), F.row_number().over(w)))
            .drop("_lot_sd"))
