"""Stage: named prognostic INDICES computed from their components (outcomes.risk_scores).

WHY THIS FAMILY EXISTS. `PROGNOSTIC_RISK_SCORE` is one master concept in the inventory and it
splits cleanly in two. Where the instrument arrives PRE-COMPUTED in the delivery it is a
value-to-group pick and `clinical.categoricals` already answers it — that is the capability
`disease.risk_score` registers, and its summary says in as many words that "a score the engine must
compute from components is not this capability and is an engine gap". Six inventory rows are on the
other side of that line and every one is classed `engine_gap` with the same sentence: IPI and
NCCN-IPI (dlbcl), DIPSS and MIPSS70 (myelofibrosis), IPSS-R and IPSS-M (mds) — "multi-component
score — no score family".

THE SHAPE IS SHARED BY MOST OF THEM, which is what makes it a family rather than several pieces
of per-tumour engine work: take N components, map each component's value to POINTS, sum the
points, then cut the total into ordered published RISK CATEGORIES. That arithmetic is code and
it lives here, once.

WHAT THIS FAMILY CANNOT EXPRESS, and the claim it must therefore not make. This paragraph
replaces one that said the shape was identical across all six rows. An external audit was right
that it is not, and the distinction is not academic:

  * A DISCRETE POINTS TABLE is what this stage compiles - a value falls in a band or matches a
    category, that branch is worth an integer, the integers are summed. IPI, NCCN-IPI, IPSS-R
    and DIPSS are published in exactly that form.
  * A CONTINUOUS WEIGHTED MODEL is not. IPSS-M is an individualised Cox-weighted molecular
    model over haematologic, cytogenetic and mutation variables, producing a per-patient score
    from continuous coefficients rather than a lookup of points. Forcing it through a points
    table would require someone to DISCRETISE it first, and that discretisation is a new
    clinical artefact - a different instrument wearing the same name.

So an inventory row is closed by this family only when its published form IS a points table.
`risk_score_errors` refuses a component that states neither `bands` nor `values`, so a config
author cannot express a weighted model here even by accident - the refusal is the boundary,
enforced rather than documented. `test_the_expressibility_boundary_is_pinned` holds it.

THE COEFFICIENTS ARE NOT CODE AND ARE NOT HERE. Which components an instrument has, what each band
is worth, and where the category cutpoints fall are published clinical content with a citation, a
version and a person who is accountable for it. An engine shipping IPI's five points would be
choosing the instrument's definition for every product silently — exactly the argument
`clinical.comorbidity_index` makes about Quan-Charlson weights, one level up. So `components:` and
`categories:` come from the pack, the template ships the block with every coefficient slot
`REPLACE_ME`, and this module REFUSES to score an instrument that still carries one. See
`platform/TUMOR_TEMPLATE/variables/outcomes.yaml`.

THE THREE FAILURES THIS FAMILY IS BUILT TO REFUSE, because each of them produces a plausible number:

  1. AN UNFILLED TABLE SCORING ZERO. A points table full of placeholders that summed to 0 would
     publish a whole column of "lowest risk" patients. `score()` raises rather than returns, and
     `instrument_errors` refuses the config before a build starts. Zero is a real score for a real
     patient; it must never also be the value of "nobody has filled this in".

  2. A MISSING COMPONENT SCORING ZERO. If an absent LDH contributed 0 points, every patient with a
     thin record would come out looking healthier than every patient with a complete one —
     confounding measurement with prognosis, in the direction that is hardest to notice. A
     component that does not resolve makes the WHOLE total unevaluable (NULL), and the instrument
     publishes its declared `incomplete` category instead. This is the same three-state honesty
     `ads_derived.landmark_case` uses for NOT EVALUABLE. The one way a missing input may contribute
     points is a categorical `when: missing` group carrying an explicit `points:` — a clinical
     ruling somebody wrote down, not a default.

  3. A TOTAL THAT MATCHES NO CATEGORY. Cutpoints that leave a gap NULL the risk group for the
     patients that fall in it and nothing else notices, because the total beside it looks fine.
     `instrument_errors` ENUMERATES every achievable total (the sumset of the component point sets
     is finite) and requires each one to land in exactly one category — so a gap and an overlap are
     both refused at authoring, named by the total that exposes them.

WHAT IS PURE HERE AND WHAT IS SPARK. Everything above `component_case` computes; everything below it
compiles. The compilers are the parity-proven ones — `clinical._num_bands_case` for numeric bands and
`clinical._stage_case` for value maps, both already held byte-identical against engine-r/cases.R by
tests/test_r_parity.py — so this module adds a points KEY to compilers that already exist rather than
a second dialect of them. The R side of this family does not exist yet; nothing here claims parity.

WHAT THIS MODULE DOES NOT DO. It does not know any instrument. It cannot tell you whether the points
a pack wrote are IPI's points, whether the citation supports them, or whether a higher category means
worse prognosis — all three are the reviewer's, which is why `clinically_reviewed_by` is a required
slot and why an unfilled one refuses. It does not implement the operator vocabulary that messy free
text needs (see POINT_MATCHERS); a component reads a CLEAN column, and cleaning one is what
`clinical.categoricals` is for.
"""
from __future__ import annotations

import re

try:                                     # imported as engine.stages.risk_score
    from ..codelists import sql_str as _q
    from .clinical import _num_bands_case, _stage_case, value_matcher_errors
except ImportError:                      # imported with engine/ itself on sys.path
    from codelists import sql_str as _q                                    # type: ignore
    from stages.clinical import (_num_bands_case, _stage_case,             # type: ignore
                                 value_matcher_errors)

# THE SCAFFOLD MARKER, spelled here rather than imported because the engine must not import
# `platform/tools` (deploy_tree.py states the rule; a governance test asserts it). It is the same
# marker `person_rules.PLACEHOLDERS_PREFIX` and `engine.validate.PLACEHOLDER` carry, and
# tests/test_risk_score.py binds this constant AND the walk below to `person_rules` so the two
# cannot drift — the same way test_r_parity binds the two engines' compilers.
UNFILLED = "REPLACE_ME"

# Governed slots every instrument must ANSWER before it can score. `instrument` and `citation` say
# WHICH published index and from where; the two review fields say a named person affirmed these
# coefficients on a date. `clinically_reviewed_by` is deliberately the SAME field name Gate 4's
# semantic approval uses (product_gates.SEMANTIC_APPROVAL_FIELDS) — affirming that these points are
# IPI's points is the same kind of act as affirming that a code means what a binding says, and a
# second spelling of one accountable role is how two gates come to disagree about who signed.
#
# WHO COUNTS AS A PERSON is `person_rules.not_a_person`'s question and is NOT asked here: the engine
# cannot import it, and a second copy of that rule is worse than the gap. This module asks only that
# the field is answered and is not a placeholder.
GOVERNED_SLOTS = ("instrument", "citation", "clinically_reviewed_by", "review_date")

# A COLUMN NAME GOES INTO A SQL EXPRESSION, so it is not free text. `component_case` interpolates
# `comp["column"]` straight into the CASE it builds, and nothing checked its shape: a value
# carrying a quote, a comma, a parenthesis or a whole sub-expression became part of the emitted
# SQL. These configs are governed and reviewed, so this is not a hostile-input story - it is that
# a typo produced a confusing Spark parse error deep in a generated expression instead of a
# refusal naming the field. A component reads ONE assembled ADS column, and that is a plain
# identifier.
IDENTIFIER = re.compile(r"^[A-Za-z_][A-Za-z0-9_]*$")

# ISO, and only ISO. `review_date` was checked for being a non-empty STRING, so "soon", "TBC" and
# "last week" all satisfied the field that records WHEN a clinician affirmed these coefficients.
ISO_DATE = re.compile(r"^\d{4}-\d{2}-\d{2}$")

# A FLOOR, NOT THE AUTHORITY. `product_gates.not_a_person` owns the real judgement (it refuses a
# team, a function, an acronym and a placeholder) and the governance layer applies it. The engine
# cannot import a tool, and a second full copy here would be a weaker rule drifting from the one
# this repository already paid to get right. So this checks only what the engine must never run
# on: an unfilled placeholder, or a single token that cannot be a human being's name.
PLACEHOLDERS = ("TODO", "TBD", "TBC", "N/A", "NA", "NONE", "PENDING", "XXX", UNFILLED)

# The value matchers a COMPONENT may use, a deliberate subset of clinical.VALUE_MATCHERS. Both are
# exact: `from_prefixes` is case-sensitive equality (the legacy spelling) and `from_equals_ci` is
# case-insensitive equality. Prefix, substring and regex matching are for free text a feed spells
# five ways, and a prognostic component is not that — it reads an enumerated column (ECOG 0/1 vs 2+,
# a cytogenetic risk group) that `clinical.categoricals` has already normalised. Two reasons to
# refuse rather than allow: a points map decided by a regex is a small program in a YAML cell that a
# clinical reviewer is being asked to sign, and the pure evaluator below mirrors ONLY these two, so
# admitting an operator it does not implement would put the computed score and the compiled SQL
# quietly out of step — which is precisely the divergence class this repository already paid for in
# the comorbidity index.
POINT_MATCHERS = ("from_prefixes", "from_equals_ci")

# Exactly one per component: a numeric column banded to points, or a categorical column mapped to
# points. Named so `instrument_errors` can refuse "both" and "neither" with one message.
COMPONENT_KINDS = ("bands", "values")

# The four bounds `_num_bands_case` compiles, and the pair that may not appear together: `min` and
# `min_excl` on one band emit two ANDed conditions, so the looser one is decoration and a reader
# cannot tell which was meant.
BOUNDS = ("min", "min_excl", "max_excl", "max")

# CEILING ON THE EXHAUSTIVE COVERAGE CHECK. The set of achievable totals is the sumset of the
# component point sets, and for every instrument this family exists for it is tiny (IPI: five
# components, two branches each, six distinct totals). A configuration that blows past this is
# either an instrument this generic family should not be asked to carry or a points table with a
# mistake in it; either way the honest answer is to say the check could not run, not to skip it
# silently and report the instrument as covered.
MAX_ACHIEVABLE_TOTALS = 20000

# Float sums drift (0.1 + 0.2 != 0.3), and a total that lands a whole 4e-17 below a cutpoint would
# be reported as an uncovered gap in a table that is perfectly correct. Rounding is applied ONLY in
# this config-time enumeration; the runtime arithmetic is Spark's and is not touched by it.
_TOTAL_PRECISION = 6


def unfilled_slots(node, _at=()):
    """Every dotted path in an instrument whose value (or key) still carries the scaffold marker.

    A MIRROR OF `person_rules.marker_paths`, and it exists as a copy for one reason: the engine may
    not import `platform/tools`. tests/test_risk_score.py runs both over the same fixture and
    asserts they agree, so the copy is held to the original by a test rather than by memory.

    PATHS, not a count — the message that follows this has to name the field a reviewer must fill,
    or it sends somebody hunting through a nested points table. Keys are walked too: a scaffold that
    left `REPLACE_ME:` standing as a KEY is the same defect wearing a different hat.
    """
    out = []
    if isinstance(node, dict):
        for k in node:
            if UNFILLED in str(k):
                out.append(".".join((*_at, str(k))) + " (key)")
            out.extend(unfilled_slots(node[k], (*_at, str(k))))
    elif isinstance(node, (list, tuple)):
        for i, v in enumerate(node):
            out.extend(unfilled_slots(v, (*_at, f"[{i}]")))
    elif UNFILLED in str(node):
        out.append(".".join(_at) or "(root)")
    return out


def _numeric(value):
    """`value` as a float, or None when it is not a number at all.

    A bool is REFUSED even though `float(True)` is 1.0. A boolean column banded against numeric
    cutpoints would score True as 1 point and False as 0 — arithmetic on a flag, which is a
    different question from the one the bands were written to ask, answered without complaint.
    """
    if value is None or isinstance(value, bool):
        return None
    try:
        return float(value)
    except (TypeError, ValueError):
        return None


def _band_holds(band, value) -> bool:
    """Whether one numeric band claims `value` — the same four conditions `_num_bands_case` emits,
    ANDed. Kept beside the compiler's condition list so the two are read together."""
    if "min" in band and not value >= float(band["min"]):
        return False
    if "min_excl" in band and not value > float(band["min_excl"]):
        return False
    if "max_excl" in band and not value < float(band["max_excl"]):
        return False
    if "max" in band and not value <= float(band["max"]):
        return False
    return True


def band_points(bands, value):
    """Points for a numeric component, or None when nothing claims the value.

    ORDER MIRRORS `_num_bands_case`: config order, first band whose bounds all hold, then the
    `when: fallthrough` band as the ELSE. A band with no bound at all is SKIPPED by the compiler
    (its `if conds:` is false) and is skipped here for the same reason — `instrument_errors` refuses
    it separately, because silently dropping a row of a points table is the loudest kind of quiet.

    NULL IN, NULL OUT, and there is no `when: missing` for numeric bands: `_num_bands_case` has no
    such marker and would drop the row. To let an absent measurement carry points, map it in a
    categorical component with an explicit `when: missing` group instead.
    """
    v = _numeric(value)
    if v is None:
        return None
    for b in bands or []:
        if b.get("when") == "fallthrough" or not any(k in b for k in BOUNDS):
            continue
        if _band_holds(b, v):
            return _numeric(b.get("points"))
    default = next((b for b in (bands or []) if b.get("when") == "fallthrough"), None)
    return _numeric(default.get("points")) if default else None


def value_points(groups, value):
    """Points for a categorical component, or None when no group claims the value.

    ORDER MIRRORS `_stage_case`: `when: missing` is answered FIRST so a null is never tested against
    a text operator, then the exact matchers in config order, then `when: fallthrough` as the ELSE.
    Only the two exact operators are reachable — POINT_MATCHERS says why the rest are refused.

    AN UNMATCHED VALUE IS MISSING, NOT ZERO. A pack that has not enumerated a value the feed
    delivers gets an unevaluable score for that patient, which is reported; a zero would be a
    silently favourable one. Where "anything else" genuinely scores something, that is a
    `when: fallthrough` group with the points written down.
    """
    groups = groups or []
    if value is None:
        miss = next((g for g in groups if g.get("when") == "missing"), None)
        return _numeric(miss.get("points")) if miss else None
    for g in groups:
        if g.get("when") in ("missing", "fallthrough"):
            continue
        if str(value) in [str(v) for v in (g.get("from_prefixes") or [])]:
            return _numeric(g.get("points"))
        if str(value).lower() in [str(v).lower() for v in (g.get("from_equals_ci") or [])]:
            return _numeric(g.get("points"))
    default = next((g for g in groups if g.get("when") == "fallthrough"), None)
    return _numeric(default.get("points")) if default else None


def component_points(comp, value):
    """Points one component contributes for one patient's value, or None when it does not resolve."""
    if comp.get("bands"):
        return band_points(comp["bands"], value)
    return value_points(comp.get("values"), value)


def component_point_set(comp) -> set:
    """Every points value this component can contribute — the branch outputs, whatever the input.

    The input to the achievable-total enumeration. A branch that cannot fire (a bound-less band) is
    excluded, so the enumeration answers for the instrument as the compiler will actually build it
    rather than as the YAML reads.
    """
    out = set()
    for b in (comp.get("bands") or []):
        if b.get("when") != "fallthrough" and not any(k in b for k in BOUNDS):
            continue
        p = _numeric(b.get("points"))
        if p is not None:
            out.add(p)
    for g in (comp.get("values") or []):
        p = _numeric(g.get("points"))
        if p is not None:
            out.add(p)
    return out


def achievable_totals(inst, cap: int = MAX_ACHIEVABLE_TOTALS):
    """Every total this instrument can produce, or None when there are more than `cap` of them.

    The sumset of the component point sets, accumulated incrementally so the working set is the
    number of DISTINCT totals rather than the product of the branch counts. This is what makes an
    exhaustive cutpoint-coverage check affordable: for the instruments this family exists for the
    answer is a handful of integers.
    """
    totals = {0.0}
    for comp in (inst.get("components") or []):
        pts = component_point_set(comp)
        if not pts:
            return None
        totals = {round(t + p, _TOTAL_PRECISION) for t in totals for p in pts}
        if len(totals) > cap:
            return None
    return totals


def total_points(inst, values):
    """(total, [components that did not resolve]) for one patient.

    `values` is {component name -> that patient's value}. A component missing from the mapping is
    the same fact as a null: it did not resolve.

    ANY unresolved component makes the TOTAL None. Not a partial sum, not a sum over what happened
    to be present — a prognostic index is defined over its whole component set, and a sum over three
    of five factors is a different number wearing the same column name. This is the one place the
    engine could have been generous and the reason it is not.
    """
    total, missing = 0.0, []
    for comp in (inst.get("components") or []):
        pts = component_points(comp, values.get(comp.get("name")))
        if pts is None:
            missing.append(comp.get("name"))
        else:
            total += pts
    if missing:
        return None, missing
    return round(total, _TOTAL_PRECISION), []


def category_index(categories, total):
    """The POSITION of the category a total falls in, or None when none claims it.

    Position rather than code, because position is what the engine guarantees: `instrument_errors`
    requires the list to be written in ascending order of its lower bound and requires every
    achievable total to match exactly one entry, so this index is monotone non-decreasing in the
    total. Whether the LABEL at a higher position means a worse prognosis is the instrument's claim,
    not the engine's — which is why nothing here requires `code` to ascend with it.
    """
    v = _numeric(total)
    if v is None:
        return None
    for i, c in enumerate(categories or []):
        if any(k in c for k in BOUNDS) and _band_holds(c, v):
            return i
    return None


def categorise(inst, total):
    """(label, code) for a total: the declared `incomplete` pair when the total is None, the matching
    category otherwise, and (None, None) for a total no category claims — which `instrument_errors`
    has already refused at authoring, and which reaches Spark as NULL either way."""
    if total is None:
        inc = inst.get("incomplete") or {}
        return inc.get("label"), inc.get("code")
    i = category_index(inst.get("categories"), total)
    if i is None:
        return None, None
    cat = inst["categories"][i]
    return cat.get("label"), cat.get("code")


def score(inst, values):
    """{total, label, code, missing} for one patient — the whole index, end to end.

    REFUSES an instrument that still carries a scaffold marker, rather than scoring it. This is the
    defence that matters most: a points table of `REPLACE_ME`s reaching a sum would publish a column
    of zeros, every patient in the lowest published risk category, and nothing in the output would
    look wrong. The message names the paths so the refusal is a worklist.

    The refusal is here, in the computation, and NOT only in `instrument_errors`, because a config
    check protects the callers that run it. This one protects the rest.
    """
    gaps = unfilled_slots(inst)
    if gaps:
        raise ValueError(
            f"SCORE REFUSED — instrument {inst.get('name')!r} still carries the {UNFILLED} scaffold "
            f"marker at: {', '.join(gaps)}. These are published coefficients: the component points, "
            f"the category cutpoints and the person accountable for them. Scoring an unfilled table "
            f"would sum placeholders to a number that reads as a real lowest-risk score. Fill them "
            f"from the cited instrument and have them clinically reviewed, or leave the instrument "
            f"out of the pack.")
    total, missing = total_points(inst, values)
    label, code = categorise(inst, total)
    return {"total": total, "label": label, "code": code, "missing": missing}


def _bound_errors(node, at) -> list:
    """Bounds must be NUMBERS, checked before anything compares against them.

    A non-numeric bound is not a typo that fails loudly. `_num_bands_case` interpolates it straight
    into the SQL, so `min: age` compiles to `WHEN total >= age` — a COLUMN REFERENCE that Spark may
    well resolve, silently banding the score against something else entirely. And on the pure side
    `_band_holds` raises ValueError part-way through scoring a patient, from inside a comparison,
    naming neither the instrument nor the field. Both happen long after the author has gone.
    """
    out = []
    for k in BOUNDS:
        if k in node and _numeric(node[k]) is None:
            out.append(f"{at}.{k} is {node[k]!r}, not a number. The compiler interpolates a bound "
                       f"verbatim, so a non-numeric one becomes a column reference in the emitted "
                       f"CASE rather than a comparison")
    return out


def _component_errors(comp, where) -> list:
    out = []
    if not comp.get("name"):
        out.append(f"{where} missing 'name'")
    if not comp.get("column"):
        out.append(f"{where} missing 'column' — the assembled ADS column this component reads")
    elif not IDENTIFIER.match(str(comp.get("column"))):
        out.append(f"{where}.column {comp.get('column')!r} is not a plain column identifier "
                   f"— this value is interpolated into the CASE expression this component "
                   f"compiles to, so anything that is not a bare name lands in the emitted "
                   f"SQL and fails deep inside a generated expression instead of here")
    kinds = [k for k in COMPONENT_KINDS if comp.get(k)]
    if len(kinds) != 1:
        out.append(f"{where} needs exactly one of {list(COMPONENT_KINDS)}, has {kinds or 'none'} — "
                   f"a component is either a numeric column banded to points or a categorical "
                   f"column mapped to points")
        return out
    branches = comp.get(kinds[0]) or []
    if not isinstance(branches, list) or not branches:
        out.append(f"{where}.{kinds[0]} must be a non-empty list of point branches")
        return out
    for j, b in enumerate(branches):
        at = f"{where}.{kinds[0]}[{j}]"
        if not isinstance(b, dict):
            out.append(f"{at} must be a mapping")
            continue
        if _numeric(b.get("points")) is None:
            # No default of 0. A branch with no points is not "worth nothing" — it is a branch
            # somebody did not finish, and the two are indistinguishable once summed.
            out.append(f"{at} has no numeric 'points' — every branch of a points table states what "
                       f"it is worth, and a default of 0 would make an unfinished row look like a "
                       f"scored one")
        if "min" in b and "min_excl" in b:
            out.append(f"{at} sets both 'min' and 'min_excl' — the compiler ANDs them, so the "
                       f"looser bound is decoration and a reader cannot tell which was meant")
        if "max" in b and "max_excl" in b:
            out.append(f"{at} sets both 'max' and 'max_excl' — the compiler ANDs them, so the "
                       f"looser bound is decoration and a reader cannot tell which was meant")
    if kinds[0] == "bands":
        for j, b in enumerate(branches):
            at = f"{where}.bands[{j}]"
            if not isinstance(b, dict):
                continue
            if b.get("when") == "missing":
                # `_num_bands_case` knows only `fallthrough`. A `when: missing` band carries no
                # bound, so its `if conds:` is false and the whole row is dropped from the CASE:
                # a rule for absent measurements that reads as applied and is not there at all.
                out.append(f"{at} uses `when: missing`, which numeric bands do not support — the "
                           f"row compiles to nothing. To give an absent measurement points, read it "
                           f"as a categorical component with a `when: missing` group.")
            elif b.get("when") not in (None, "fallthrough"):
                out.append(f"{at} `when: {b.get('when')!r}` is not a band marker — only "
                           f"`fallthrough` is")
            elif b.get("when") != "fallthrough" and not any(k in b for k in BOUNDS):
                out.append(f"{at} states no bound ({', '.join(BOUNDS)}) and is not the "
                           f"`when: fallthrough` row, so the compiler emits nothing for it — a row "
                           f"of the points table that silently does not exist")
            out += _bound_errors(b, at)
    else:
        out += value_matcher_errors(branches, where=f"{where}.")
        for j, g in enumerate(branches):
            if not isinstance(g, dict):
                continue
            bad = [k for k in g if k.startswith("from_") and k not in POINT_MATCHERS]
            if bad:
                out.append(f"{where}.values[{j}] uses {sorted(bad)} — a component may match only "
                           f"with {list(POINT_MATCHERS)}. Normalise the column with a "
                           f"`clinical.categoricals` group first; a points map decided by a prefix "
                           f"or a regex is not something a clinical reviewer can read as a table.")
    return out


def _category_errors(inst, where) -> list:
    """The cutpoints: shape, order, and — the check that matters — TOTAL coverage of every score
    the components can actually produce."""
    out = []
    cats = inst.get("categories") or []
    if not isinstance(cats, list) or not cats:
        out.append(f"{where}.categories is empty — an index that is not cut into published risk "
                   f"categories is a number, and the variable this family emits is a category")
        return out
    for i, c in enumerate(cats):
        at = f"{where}.categories[{i}]"
        if not isinstance(c, dict):
            out.append(f"{at} must be a mapping")
            continue
        if c.get("when") is not None:
            # A fallthrough would make the coverage check below vacuously true, and it is the ELSE
            # that a real cutpoint gap hides behind: every uncovered total silently becomes the last
            # category instead of being reported.
            out.append(f"{at} uses `when: {c.get('when')!r}`. Risk categories are stated as bounds "
                       f"and must cover the achievable range exactly; a fallthrough would swallow "
                       f"the gap this check exists to find")
            continue
        if not str(c.get("label") or "").strip():
            out.append(f"{at} has no 'label'")
        try:
            int(c.get("code"))
        except (TypeError, ValueError):
            out.append(f"{at} needs an integer 'code' — the numeric twin the <name>grn column "
                       f"publishes")
        if not any(k in c for k in BOUNDS):
            out.append(f"{at} states no bound ({', '.join(BOUNDS)}) — it can never claim a total")
        if "min" in c and "min_excl" in c:
            out.append(f"{at} sets both 'min' and 'min_excl'")
        if "max" in c and "max_excl" in c:
            out.append(f"{at} sets both 'max' and 'max_excl'")
        out += _bound_errors(c, at)

    codes = [c.get("code") for c in cats if isinstance(c, dict)]
    inc = inst.get("incomplete") or {}
    if not str(inc.get("label") or "").strip():
        out.append(f"{where}.incomplete needs a 'label' — the state a patient lands in when a "
                   f"component does not resolve. Without it an unevaluable score is a null beside a "
                   f"null and cannot be counted")
    try:
        int(inc.get("code"))
    except (TypeError, ValueError):
        out.append(f"{where}.incomplete needs an integer 'code'")
    else:
        codes.append(inc.get("code"))
    dupes = sorted({str(c) for c in codes if c is not None and codes.count(c) > 1})
    if dupes:
        out.append(f"{where}: category code(s) {dupes} are used twice (counting `incomplete`) — the "
                   f"<name>grn column would collapse two different risk states onto one number")

    # ASCENDING, as written. Sorting silently would let a table read as one ladder and compile as
    # another; the first matching WHEN wins, so the order in the file is the order that runs.
    def lower(c):
        if "min_excl" in c:
            return (float(c["min_excl"]), 1)
        if "min" in c:
            return (float(c["min"]), 0)
        return (float("-inf"), 0)
    graded = [c for c in cats if isinstance(c, dict) and c.get("when") is None
              and any(k in c for k in BOUNDS)]
    try:
        if [lower(c) for c in graded] != sorted(lower(c) for c in graded):
            out.append(f"{where}.categories are not written in ascending order of their lower "
                       f"bound. The compiled CASE takes the FIRST match, so a table a reader scans "
                       f"as a ladder can evaluate in a different order than it reads")
    except (TypeError, ValueError):
        out.append(f"{where}.categories carry a non-numeric bound")
        return out

    # THE CHECK THIS BLOCK EXISTS FOR. Every total the components can produce must land in exactly
    # one category. A gap NULLs the risk group for the patients who fall in it while the total beside
    # it looks perfectly normal; an overlap makes the answer depend on which row was typed first.
    if any(e.startswith(f"{where}.categories[") for e in out):
        return out
    totals = achievable_totals(inst)
    if totals is None:
        if all(component_point_set(c) for c in (inst.get("components") or []) if isinstance(c, dict)):
            out.append(f"{where}: more than {MAX_ACHIEVABLE_TOTALS} achievable totals, so the "
                       f"cutpoint-coverage check could not run exhaustively. Reported rather than "
                       f"skipped: this family's instruments produce a handful of totals, and a "
                       f"table this wide is either the wrong shape for it or has a mistake in it")
        return out
    for t in sorted(totals):
        hits = [i for i, c in enumerate(cats)
                if isinstance(c, dict) and c.get("when") is None
                and any(k in c for k in BOUNDS) and _band_holds(c, t)]
        shown = int(t) if float(t).is_integer() else t
        if not hits:
            out.append(f"{where}: a total of {shown} is achievable from these components and no "
                       f"category claims it — those patients would publish a score with a null risk "
                       f"group beside it")
        elif len(hits) > 1:
            out.append(f"{where}: a total of {shown} is claimed by categories {hits} "
                       f"({', '.join(str(cats[i].get('label')) for i in hits)}) — the compiled CASE "
                       f"takes the first, so the later one is dead for this total")
    return out


def instrument_errors(inst, where="risk_scores[?]") -> list:
    """[why this instrument cannot be scored as written]. Config-time, pure, no Spark.

    FAIL CLOSED AT AUTHORING. Every refusal here is a defect that would otherwise publish a number:
    an unfilled coefficient summing to zero, a branch with no points, a cutpoint gap that nulls a
    risk group. None of them raise at runtime on Spark; all of them produce a column that looks
    exactly like a working one.
    """
    out = []
    if not isinstance(inst, dict):
        return [f"{where} must be a mapping"]
    if not str(inst.get("name") or "").strip():
        out.append(f"{where} missing 'name' — the emitted column")

    # THE SCAFFOLD MARKER FIRST, and everything else still checked: a reviewer filling the table in
    # wants the whole worklist, not the first line of it.
    gaps = unfilled_slots(inst)
    if gaps:
        out.append(f"{where} still carries the {UNFILLED} scaffold marker at "
                   f"{', '.join(gaps)} — these are published coefficients and the person "
                   f"accountable for them; the engine refuses to score them unfilled")
    for slot in GOVERNED_SLOTS:
        v = str(inst.get(slot) or "").strip()
        if not v:
            out.append(f"{where} missing '{slot}'. An index without its named instrument and "
                       f"version, the citation its points come from, and the person who affirmed "
                       f"them on a date is a column of numbers nobody has signed for")
            continue
        # ...AND STATED IS NOT THE SAME AS REAL. Every one of these was satisfied by any
        # non-empty string, so `review_date: soon` and `clinically_reviewed_by: TBD` signed
        # off a table of published clinical coefficients. The whole purpose of these four
        # fields is accountability, and a check that accepts any characters at all records
        # that a field was typed in, not that anybody affirmed anything.
        if v.strip().upper().rstrip(".") in PLACEHOLDERS:
            out.append(f"{where}.{slot} is the placeholder {v!r} — these are published "
                       f"coefficients and the person accountable for them")
        elif slot == "review_date" and not ISO_DATE.match(v):
            out.append(f"{where}.review_date {v!r} is not an ISO date (YYYY-MM-DD) — a "
                       f"review that cannot be placed in time cannot be shown to precede "
                       f"the run that relied on it")
        elif slot == "clinically_reviewed_by" and len(v.split()) < 2:
            out.append(f"{where}.clinically_reviewed_by {v!r} does not name a person — an "
                       f"initialism or a single token is a team or a system, and neither "
                       f"can affirm a coefficient table. (`product_gates.not_a_person` "
                       f"owns the full judgement; this is the floor the engine enforces.)")

    comps = inst.get("components") or []
    if not isinstance(comps, list) or not comps:
        out.append(f"{where}.components is empty — an index with no components sums to nothing")
    else:
        seen = set()
        for i, c in enumerate(comps):
            at = f"{where}.components[{i}]"
            if not isinstance(c, dict):
                out.append(f"{at} must be a mapping")
                continue
            nm = c.get("name")
            if nm and nm in seen:
                out.append(f"{at} repeats the component name {nm!r} — `values` is keyed by it, so "
                           f"one of the two would never be given a patient's value")
            elif nm:
                seen.add(nm)
            out += _component_errors(c, at)

    out += _category_errors(inst, where)
    return out


def risk_score_errors(items) -> list:
    """[why this outcomes.risk_scores block cannot be run as written]."""
    out = []
    if items is None:
        return out
    if not isinstance(items, list):
        return [f"risk_scores must be a list of instruments, got {type(items).__name__}"]
    seen = set()
    for i, inst in enumerate(items):
        where = f"risk_scores[{i}]"
        name = inst.get("name") if isinstance(inst, dict) else None
        if name and name in seen:
            out.append(f"{where} duplicates name {name!r} — the second would overwrite the first's "
                       f"columns")
        elif name:
            seen.add(name)
        out += instrument_errors(inst, where)
    return out


def emitted(items) -> set:
    """The label-level columns this block publishes: <name> (the total) and <name>gr (the category).
    The parallel <name>grn code column follows the house convention of being documented via its
    label column."""
    em = set()
    for inst in (items or []):
        name = inst.get("name") if isinstance(inst, dict) else None
        if name:
            em |= {name, name + "gr"}
    return em


def requires(inst) -> list:
    """The assembled ADS columns this instrument reads — DERIVED from the components rather than
    restated. `ads_derived` asks its items for an explicit `requires` because an expression's inputs
    are not recoverable from it; a component names its column, so a second list here could only
    disagree with the first."""
    return [c.get("column") for c in (inst.get("components") or []) if isinstance(c, dict)
            and c.get("column")]


def component_case(comp) -> str:
    """The points CASE for one component, compiled by the PARITY-PROVEN compiler for its kind.

    `key="points"` rather than `"label"`, which is what makes those two compilers reusable here:
    both emit `_q(g[key])` for a label and a bare `str(g[key])` for anything else, so a points table
    compiles through the same operator precedence, the same longest-prefix resolution and the same
    marker handling as every value map in the product. Nothing about points is a new dialect.
    """
    if comp.get("bands"):
        return _num_bands_case(comp["bands"], comp["column"], key="points")
    return _stage_case(comp["values"], comp["column"], key="points")


def total_expr(inst) -> str:
    """The summed index: every component's points CASE, added.

    NULL PROPAGATION IS THE POINT. In Spark `NULL + 1` is NULL, so a component whose CASE matches
    nothing makes the whole total NULL with no extra machinery — which is exactly the rule
    `total_points` implements in Python. The two agree because SQL's arithmetic already agrees with
    it, not because a guard was written twice.
    """
    return " + ".join(f"({component_case(c)})" for c in inst["components"])


def category_case(inst, total_col: str, key: str = "label") -> str:
    """The published risk category for a computed total, in the two-column house shape.

    The NULL arm is FIRST and is the declared `incomplete` state, not a null: a total that could not
    be computed is a fact about the patient's record and has to be countable. Everything else is
    `_num_bands_case` over the cutpoints, with no ELSE — `instrument_errors` has already proved every
    achievable total is claimed, so an ELSE could only hide a table that changed after that proof.
    """
    inc = inst.get("incomplete") or {}
    out = _q(str(inc.get("label"))) if key == "label" else str(int(inc.get("code")))
    body = _num_bands_case(inst["categories"], total_col, key=key)
    return f"CASE WHEN {total_col} IS NULL THEN {out} ELSE {body} END"


def build(F, ads, cfg):
    """Apply the outcomes pack's `risk_scores` to one cohort's ASSEMBLED frame.

    AFTER ASSEMBLE, for the same reason `ads_derived` runs there: an index's components come from
    different stages — age from demographics, LDH and blasts from the clinical lab panels, stage from
    the clinical categoricals — and only here do they sit on one frame.

    Returns the frame untouched when no instrument is declared, which is every pack in the tree
    today. An instrument whose component columns are not all present in THIS cut is skipped whole,
    never scored on the components that happen to be there — the graceful-skip contract the clinical
    families use, applied at the instrument rather than the component, because a partial index is a
    different number under the same name.

    REFUSES rather than compiles a config `instrument_errors` rejects. `engine.validate.problems`
    already refuses it before a build starts; this is the floor under a caller that did not run it,
    and the alternative is a Spark parse error naming `REPLACE_ME` from inside a generated CASE.

    NOT YET EXECUTED. No Spark session has run this function — the machine it was written on has no
    Java and no pyspark, and no pack declares the block, so nothing in CI reaches it either. The pure
    core above is tested; this wrapper is reviewed code, not demonstrated code, and it should be run
    against a fixture before the first pack turns an instrument on.
    """
    items = cfg.pack("outcomes").get("risk_scores")
    if not items:
        return ads
    why = risk_score_errors(items)
    if why:
        raise ValueError("BUILD REFUSED — outcomes.risk_scores cannot be scored as written:\n  "
                         + "\n  ".join(why))
    cols = set(ads.columns)
    # A MISSING COMPONENT COLUMN IS A REFUSAL, NOT A SKIP. This used to `continue`, so an
    # instrument whose components were not in the assembled ADS produced no score, no
    # category, and no message - while `validate` had already advertised all three columns as
    # part of the emitted surface. Downstream then read a declared column that silently did
    # not exist, which is the failure mode this repository names everywhere else: the absence
    # of an output read as the output being fine. Refusing here also keeps the build honest
    # about WHY - a typo in `column`, a component reading something a prior stage did not
    # build, or an instrument enabled in the wrong pack all look identical when skipped.
    absent = {str(inst.get("name")): sorted(set(requires(inst)) - cols)
              for inst in items if not set(requires(inst)) <= cols}
    if absent:
        raise ValueError(
            "BUILD REFUSED - outcomes.risk_scores names ADS column(s) this build did not "
            "produce, and `validate` has already declared the score columns as emitted:"
            + "".join(f"\n  {n}: missing {miss}"
                      for n, miss in sorted(absent.items())))
    for inst in items:
        name = inst["name"]
        ads = (ads.withColumn(name, F.expr(total_expr(inst)))
               .withColumn(name + "gr", F.expr(category_case(inst, name, key="label")))
               .withColumn(name + "grn", F.expr(category_case(inst, name, key="code"))))
        cols |= {name, name + "gr", name + "grn"}
    return ads
