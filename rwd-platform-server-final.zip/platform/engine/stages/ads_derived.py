"""Stage: config-driven derivations over the ASSEMBLED per-cohort ADS (outcomes.ads_derived).

Every other derivation family runs inside one stage and sees only that stage's frame — which is why
anything spanning a stage boundary (a landmark flag reading the outcomes progression date against
the clinical follow-up anchor; an interval between a treatment line date and a disease-state date)
has been per-tumour engine work. This family runs after assemble, when every stage's columns sit on
one frame, so those derivations become config.

Three item kinds, exactly one per item (`ads_derived_errors` refuses anything else):

  expr:      raw Spark SQL over assembled columns; the study tokens (`{index_start}`,
             `{index_end}`, `{index_period_start}`, `{index_period_end}`, `{observation_end}`,
             `{data_cutoff}`) substituted from study config — the same contract as
             clinical.derived, one frame later
  interval:  datediff(to, from) in days or months (months divide by the outcomes pack's
             days_per_month), with optional `bands` -> <name>gr / <name>grn via the parity-proven
             _num_bands_case compiler
  landmark:  event-free-at-horizon (EFS24-style): FAILED when any configured event lands on or
             before anchor+horizon; ACHIEVED when none does and the censor anchor reaches the
             horizon; NOT EVALUABLE when follow-up ends short of the horizon with no event. Emits
             <name> (label) + <name>n (code).

`requires` is MANDATORY on every item and each item is emitted only when every required column is
present — the graceful-skip contract the clinical families use, but stated rather than implied,
because a derivation that never names its inputs is one that silently never runs.

The compilers are pure and mirrored in engine-r/cases.R (interval_expr / landmark_event_expr /
landmark_case); tests/test_r_parity.py proves the two engines emit byte-identical SQL.
"""
from __future__ import annotations

try:                                     # imported as engine.stages.ads_derived
    from ..codelists import sql_str as _q
    from .clinical import _num_bands_case
except ImportError:                      # imported with engine/ itself on sys.path
    from codelists import sql_str as _q                    # type: ignore
    from stages.clinical import _num_bands_case            # type: ignore

UNITS = ("months", "days")


def dependency_errors(items) -> list:
    """Reject ambiguous output names and internal reads before their producer.

    External columns can be absent from one cohort under the existing skip
    contract. A reference to a declared derived output has a known producer and
    cannot be treated as an absent delivery column. Comparisons follow Spark's
    case-insensitive column policy, including generated code and band columns.
    """
    if not isinstance(items, list):
        return []  # The structural validator reports this shape.
    producers, errors = {}, []
    for index, item in enumerate(items):
        if not isinstance(item, dict) or not isinstance(item.get("name"), str) or not item["name"]:
            continue
        name = item["name"]
        outputs = [name]
        if item.get("landmark"):
            outputs.append(name + "n")
        if item.get("interval") and item.get("bands"):
            outputs.extend([name + "gr", name + "grn"])
        for column in outputs:
            key = column.casefold()
            if key in producers:
                errors.append(f"ads_derived[{index}] duplicates output column '{column}' from ads_derived[{producers[key]}]")
            else:
                producers[key] = index
    for index, item in enumerate(items):
        if not isinstance(item, dict) or not isinstance(item.get("requires"), list):
            continue
        for column in item["requires"]:
            if not isinstance(column, str):
                continue
            producer = producers.get(column.casefold())
            if producer is not None and producer >= index:
                errors.append(f"ads_derived[{index}] requires '{column}' before its producer ads_derived[{producer}]; "
                              "fix the dependency order or cycle before execution")
    return errors


def interval_expr(frm: str, to: str, unit: str = "months", dpm=30.4375) -> str:
    """datediff(to, from), raw days or months. Mirrored in cases.R::interval_expr."""
    days = f"datediff({to}, {frm})"
    return days if unit == "days" else f"({days})/{dpm}"


def landmark_event_expr(events) -> str:
    """The FIRST qualifying event date: least() over each event's date, an event with a `when`
    predicate contributing only when it holds. Spark's least() skips NULLs, so an event that did
    not happen never wins. Mirrored in cases.R::landmark_event_expr."""
    parts = [f"CASE WHEN {ev['when']} THEN {ev['date']} END" if ev.get("when") else str(ev["date"])
             for ev in events]
    return parts[0] if len(parts) == 1 else "least(" + ", ".join(parts) + ")"


def landmark_case(anchor: str, horizon_days, events, censor_date: str, labels: dict,
                  key: str = "label") -> str:
    """The landmark CASE: event-free at anchor+horizon, said in three honest states.

    Order is load-bearing: FAILED is decided first (an event inside the horizon fails whatever the
    follow-up looks like), ACHIEVED requires the censor anchor to REACH the horizon (event-free
    with short follow-up is not achievement — it is the third state), and everything else is
    NOT EVALUABLE. A NULL anchor yields NULL: no index, no landmark. Mirrored in
    cases.R::landmark_case; byte-identity enforced by tests/test_r_parity.py.
    """
    def out(state):
        v = labels[state][key]
        return _q(str(v)) if key == "label" else str(int(v))
    evt = landmark_event_expr(events)
    edge = f"date_add({anchor}, {int(horizon_days)})"
    return (f"CASE WHEN {anchor} IS NULL THEN NULL "
            f"WHEN ({evt}) IS NOT NULL AND ({evt}) <= {edge} THEN {out('failed')} "
            f"WHEN {censor_date} >= {edge} THEN {out('achieved')} "
            f"ELSE {out('not_evaluable')} END")


def ads_derived_errors(items) -> list:
    """[why this ads_derived block cannot be run as written]. Config-time, no Spark.

    Fail-closed at AUTHORING: the runtime skip below is for a column absent in one cut, never for
    a block that could not mean anything in any cut.
    """
    out = []
    if items is None:
        return out
    if not isinstance(items, list):
        return [f"ads_derived must be a list of items, got {type(items).__name__}"]
    seen = set()
    for i, it in enumerate(items):
        where = f"ads_derived[{i}]"
        if not isinstance(it, dict):
            out.append(f"{where} must be a mapping")
            continue
        name = it.get("name")
        if not isinstance(name, str) or not name.strip():
            out.append(f"{where} missing 'name'")
        elif name in seen:
            out.append(f"{where} duplicates name '{name}'")
        else:
            seen.add(name)
        kinds = [k for k in ("expr", "interval", "landmark") if it.get(k)]
        if len(kinds) != 1:
            out.append(f"{where} needs exactly one of expr/interval/landmark, has "
                       f"{kinds or 'none'}")
        req = it.get("requires")
        if not (isinstance(req, list) and req and all(isinstance(c, str) and c for c in req)):
            out.append(f"{where} 'requires' must name every input column (non-empty list) — a "
                       f"derivation that does not state its inputs is one that silently never runs")
        if it.get("bands") and "interval" not in kinds:
            out.append(f"{where} 'bands' only applies to an interval item")
        iv = it.get("interval")
        if iv:
            if not isinstance(iv, dict):
                out.append(f"{where}.interval must be a mapping")
                continue
            for f in ("from", "to"):
                if not iv.get(f):
                    out.append(f"{where}.interval missing '{f}'")
            if iv.get("unit", "months") not in UNITS:
                out.append(f"{where}.interval.unit '{iv.get('unit')}' not one of {UNITS}")
        lm = it.get("landmark")
        if lm:
            if not isinstance(lm, dict):
                out.append(f"{where}.landmark must be a mapping")
                continue
            for f in ("anchor", "horizon_days", "events", "censor"):
                if not lm.get(f):
                    out.append(f"{where}.landmark missing '{f}'")
            try:
                if int(lm.get("horizon_days", 0)) <= 0:
                    out.append(f"{where}.landmark.horizon_days must be a positive day count")
            except (TypeError, ValueError):
                out.append(f"{where}.landmark.horizon_days must be a positive day count")
            for j, ev in enumerate(lm.get("events") or []):
                if not (isinstance(ev, dict) and ev.get("date")):
                    out.append(f"{where}.landmark.events[{j}] needs a 'date' column")
            if not isinstance(lm.get("censor"), dict) or not lm["censor"].get("date"):
                out.append(f"{where}.landmark.censor needs a 'date' column")
            lbl = lm.get("labels") or {}
            if not isinstance(lbl, dict):
                out.append(f"{where}.landmark.labels must be a mapping")
                lbl = {}
            for state in ("achieved", "failed", "not_evaluable"):
                s = lbl.get(state) or {}
                if not isinstance(s, dict):
                    out.append(f"{where}.landmark.labels.{state} must be a mapping")
                    continue
                if not s.get("label"):
                    out.append(f"{where}.landmark.labels.{state} needs a 'label'")
                try:
                    int(s.get("code"))
                except (TypeError, ValueError):
                    out.append(f"{where}.landmark.labels.{state} needs a numeric 'code'")
    return out + dependency_errors(items)


def emitted(items) -> set:
    """The label-level columns this block emits (for validate.emitted_variables): the item name,
    plus <name>gr for a banded interval. The parallel -n code columns follow the house convention
    of being documented via their label column."""
    em = set()
    for it in (items or []):
        name = it.get("name")
        if not name:
            continue
        em.add(name)
        if it.get("interval") and it.get("bands"):
            em.add(name + "gr")
    return em


def build(F, ads, cfg):
    """Apply the outcomes pack's ads_derived items to one cohort's ASSEMBLED frame. Returns the
    frame unchanged when the block is absent. An item whose `requires` columns are not all present
    in THIS cut is skipped — the same graceful contract as clinical.derived. Items run once in
    configuration order; later items can read every column an earlier item actually produced."""
    out_cfg = cfg.pack("outcomes")
    items = out_cfg.get("ads_derived")
    if not items:
        return ads
    errors = ads_derived_errors(items)
    if errors:
        raise ValueError("Invalid outcomes.ads_derived: " + "; ".join(errors))
    dpm = float(out_cfg.get("days_per_month", 30.4375))
    study = cfg.study
    cols = {column.casefold() for column in ads.columns}
    for it in items:
        if not all(c.casefold() in cols for c in it["requires"]):
            continue
        name = it["name"]
        if it.get("expr"):
            from .clinical import _study_tokens
            expr = _study_tokens(it["expr"], study)
            ads = ads.withColumn(name, F.expr(expr))
        elif it.get("interval"):
            iv = it["interval"]
            ads = ads.withColumn(
                name, F.expr(interval_expr(iv["from"], iv["to"], iv.get("unit", "months"), dpm)))
            if it.get("bands"):
                ads = (ads.withColumn(name + "gr", F.expr(_num_bands_case(it["bands"], name, "label")))
                       .withColumn(name + "grn", F.expr(_num_bands_case(it["bands"], name, "code"))))
        else:
            lm = it["landmark"]
            args = (lm["anchor"], lm["horizon_days"], lm["events"], lm["censor"]["date"],
                    lm["labels"])
            ads = (ads.withColumn(name, F.expr(landmark_case(*args, key="label")))
                   .withColumn(name + "n", F.expr(landmark_case(*args, key="code"))))
        # Runtime dependencies also include generated code/band columns. emitted()
        # deliberately lists only labels for the documentation catalogue.
        cols.update(column.casefold() for column in ads.columns)
    return ads
