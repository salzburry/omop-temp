"""Stage: index-cohort construction. Ports index_lot_cohort().

overall: index_date = advanceddiagnosisdate (built on the configured index source — `enhanced`
         for solid tumors, `diagnosis` for heme), filtered to [index_start, index_end].
lotN:    index_date = the start date of relevant line N (new_lot_n == N), in the same window,
         joined back to the index source. new_lot_n comes from the shared lot stage.
"""
from __future__ import annotations

from . import lot as lot_stage


def build(src, cfg, cohort):
    from pyspark.sql import functions as F

    # The ENROLLMENT window — cfg.index_period_* names the concept and falls back to
    # study.index_start/index_end, so packs state nothing new until the dates genuinely differ.
    start = F.lit(cfg.index_period_start).cast("date")
    end = F.lit(cfg.index_period_end).cast("date")
    enh = src[cfg.index_source]   # index source: 'enhanced' (solid) or 'diagnosis' (heme), etc.

    # Overall cohort = any cohort without a `lot_number` (id == 'overall' by convention). It indexes
    # off its configured diagnosis model column (cohort.index -> key.replace('_','')); the default /
    # absent value is advanceddiagnosisdate, so single-setting tumors are unchanged. A dual-setting
    # product points each overall cohort at its setting's date (e.g. hspc_diagnosis_date for mHSPC).
    if "lot_number" not in cohort:
        dcol = (cohort.get("index") or "advanced_diagnosis_date").replace("_", "")
        # CAST FIRST, FILTER SECOND. The filter used to compare the RAW column against the study
        # window, and comparing a string column with a date makes Spark cast implicitly: NULL on
        # an ANSI-off cluster — the row vanishes with no record that a date failed to parse —
        # and a mid-build RAISE on an ANSI-on one. try_cast existed here for exactly that split
        # and sat AFTER the filter it should have protected; an audit caught the order. A row
        # whose date cannot parse is still excluded (it cannot be inside any window), but now by
        # a stated rule on a typed value, measurable by source QC instead of dissolving inside
        # an implicit comparison.
        return (enh
                .withColumn("_idxdt", F.expr(f"try_cast(`{dcol}` as date)"))
                .filter((F.col("_idxdt") >= start) & (F.col("_idxdt") <= end))
                .select("patientid",
                        F.col("_idxdt").alias("index_date"),
                        F.col(dcol).alias("advanceddiagnosisdate"))
                .distinct())

    # LOT cohort: take line N from the shared normalized LOT table. `maintenance` (per cohort) and
    # the LOT model (line-setting / exclude-settings / line_number / maintenance_column) are all
    # config-driven; the defaults reproduce prostate's mCRPC line N.
    lot_number = cohort["lot_number"]
    # Per-cohort line setting (dual-setting products: an mHSPC line cohort renumbers within mHSPC, an
    # mCRPC line cohort within mCRPC); defaults to the global lot.line_setting for single-setting tumors.
    lot_norm = lot_stage.normalized(src, cohort.get("line_setting", cfg.lot_line_setting),
                                    exclude_settings=cfg.lot_exclude_settings,
                                    maintenance=cohort.get("maintenance"),
                                    line_number_col=cfg.lot_line_number_col,
                                    maintenance_column=cfg.lot_maintenance_column)
    # Same cast-first rule as the overall branch: the window test runs on the typed value.
    lot_index = (lot_norm
                 .withColumn("_lotsd", F.expr("try_cast(startdate as date)"))
                 .filter((F.col("new_lot_n") == lot_number) &
                         (F.col("_lotsd") >= start) & (F.col("_lotsd") <= end))
                 .select("patientid", "linename", "linenumber", "startdate", "enddate",
                         "new_lot_n", "_lotsd"))

    # The SETTING's diagnosis date must also be in-window (the spec gates a line cohort on BOTH the
    # setting diagnosis date AND the line start). cohort.diag names the model (default: the mCRPC
    # advanced model); an mHSPC line cohort sets diag: hspc_diagnosis_date so it anchors on the mHSPC
    # date, NOT the mCRPC advanced date — otherwise mHSPC-line patients lacking an in-window mCRPC date
    # are wrongly dropped. The chosen date is carried forward as `advanceddiagnosisdate` (provenance).
    dcol = (cohort.get("diag") or "advanced_diagnosis_date").replace("_", "")
    enh_index = (enh
                 .withColumn("_diagdt", F.expr(f"try_cast(`{dcol}` as date)"))
                 .filter((F.col("_diagdt") >= start) & (F.col("_diagdt") <= end))
                 .select("patientid", F.col(dcol).alias("advanceddiagnosisdate")))

    return (lot_index.join(enh_index, "patientid", "inner")
            # index_date is the typed line start the window was tested on — one cast, one value,
            # rather than a second cast that could disagree with the filter.
            .withColumn("index_date", F.col("_lotsd"))
            .select("patientid", "index_date", "advanceddiagnosisdate",
                    "linenumber", "linename", "startdate", "enddate", "new_lot_n")
            .distinct())
