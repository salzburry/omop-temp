"""Generic form feedback uses actual proposed/applied/edited values, never prose alone."""
from pathlib import Path
import json
import sys

import pytest
from streamlit.testing.v1 import AppTest

ROOT = Path(__file__).resolve().parents[2]
sys.path[:0] = [str(ROOT / name) for name in ("platform/tests", "experiments/portal", "platform/tools", "experiments/agent")]
import form_assistance as forms
import flow_assistant_page as guide
import workflow_improvement_page as improvement
import workflow_skills
from test_epi_workflow_improvement_page import checkout

PACK = "products/oncology/test/202606"
UI = "flow_assistant_form_feedback"
FEEDBACK = "interaction_feedback_" + workflow_skills.learning().digest(UI)[:16] + "_"
FORM = improvement.PREFIX + FEEDBACK + "form_"


def _healthy(at):
    assert not at.exception, [item.message for item in at.exception]
    assert "saved_fields" not in at.session_state
    return at


def _connect(monkeypatch, values):
    calls = []
    class Model:
        def step(self, system, messages):
            payload = json.loads(messages[0]["content"])
            calls.append(payload)
            public = payload["context"]["editable_form"]
            return json.dumps({"answer": "Review the proposed entries.", "actions": [], "prefill": {
                "scope": public["scope"], "fields": [{"id": field["id"], "value": values[field["label"]]}
                    for field in public["fields"] if field["label"] in values]}})
    provider = {"configured": True, "instance": Model(), "provider": "Scripted connection", "model": "test"}
    monkeypatch.setattr(guide, "_provider_words", lambda *_: (provider, "Scripted connection"))
    return calls


def _app(root, *, dependent=False, long_fields=False):
    body = '''table = forms.field(st.selectbox, "Table", ["A", "B"], key="table", binding=stamp)
forms.field(st.selectbox, "Column", ["a", "id"] if table == "A" else ["b", "id"], index=None, key="column", binding=stamp)''' if dependent else '''forms.field(st.text_area, "Interpretation", key="meaning", max_chars=4000, binding=stamp)
forms.field(st.text_input, "Source", key="source", binding=stamp)'''
    if long_fields:
        body = '''for index in range(4):
    forms.field(st.text_area, "Field " + str(index), value="before " * 500, key="long_" + str(index), max_chars=4000, binding=stamp)'''
    code = f'''import streamlit as st
import form_assistance as forms
import flow_assistant_page as guide
actor = st.session_state.get("actor", "Local scientist")
pack = st.session_state.get("pack", {PACK!r})
can_write = st.session_state.get("can_write", True)
forms.begin({str(root)!r}, pack, actor, page="Scientific draft", allowed_packs=[pack], can_write=can_write)
guide.render({str(root)!r}, pack, card={{"actions": [], "current_task": {{"route": "scientific_draft"}}}},
    actor_id=actor, primary=True, metadata_only=True, can_write=can_write, allowed_packs=[pack])
stamp = st.session_state.get("source_stamp", "current-source")
{body}
st.text_input("Unrelated reviewer entry", key="reviewer")
if st.button("Save actual fields", key="save_fields"):
    st.session_state.saved_fields = True
forms.finish()
'''
    return _healthy(AppTest.from_string(code, default_timeout=50).run())


def _ask(at):
    return _healthy(at.chat_input[0].set_value("Prepare the requested form values.").run())


def _prepare(at, reason="wrong_interpretation"):
    at.radio(key=FEEDBACK + "category").set_value(reason).run()
    _healthy(at.button(key=FEEDBACK + "prepare").click().run())
    return at.session_state[FEEDBACK + "prepared"]


def test_manual_edit_prepares_existing_form_from_exact_values_and_only_explicit_save_persists(checkout, monkeypatch):
    root, loop, jobs = checkout
    calls = _connect(monkeypatch, {"Interpretation": "Use the first diagnosis."})
    at = _ask(_app(root))
    record = at.session_state[forms.KEY + "feedback"]
    assert record["state"] == "applied" and record["outcome"] is None
    assert record["fields"][0]["before"] == ""
    assert record["fields"][0]["proposed"] == record["fields"][0]["applied"] == "Use the first diagnosis."
    at.text_area(key="meaning").set_value("Use the reviewed index event; timing remains TODO.").run()
    _healthy(at)
    draft = _prepare(at)
    assert draft["provenance"]["outcome"] == "edited"
    wrong = at.text_area(key=FORM + "wrong").value
    assert "Proposed:" in wrong and "Actually applied:" in wrong and "first diagnosis" in wrong
    assert "Review the proposed entries." not in wrong
    assert "reviewed index event" in at.text_area(key=FORM + "right").value
    assert not loop.corrections(root) and not jobs and len(calls) == 1
    assert at.button(key=FORM + "save").disabled
    at.checkbox(key=FORM + "confirm_save").check().run()
    at.button(key=FORM + "save").click().run()
    _healthy(at)
    saved = loop.corrections(root)
    assert len(saved) == 1 and saved[0]["status"] == "proposed"
    assert saved[0]["provenance"]["outcome"] == "edited" and not loop.active_corrections(root)
    assert not jobs and len(calls) == 1


def test_rejected_replacement_preserves_previous_values_and_prepares_rejection_feedback(checkout, monkeypatch):
    root, loop, jobs = checkout
    _connect(monkeypatch, {"Interpretation": "Use diagnosis as the index."})
    at = _app(root)
    at.text_area(key="meaning").set_value("The index event is unresolved.").run()
    _ask(at)
    assert at.text_area(key="meaning").value == "The index event is unresolved."
    _healthy(at.button(key=forms.KEY + "discard").click().run())
    record = at.session_state[forms.KEY + "feedback"]
    assert record["outcome"] == "rejected" and record["state"] == "rejected"
    assert not record["fields"][0]["applied_present"]
    draft = _prepare(at, "missing_source")
    assert draft["provenance"]["outcome"] == "rejected"
    assert "Use diagnosis as the index." in draft["fields"]["wrong"]
    assert "existing entries were kept" in draft["fields"]["wrong"]
    assert "index event is unresolved" in draft["fields"]["right"]
    assert at.text_area(key="meaning").value == "The index event is unresolved."
    assert not loop.corrections(root) and not jobs


def test_unselected_field_edit_does_not_count_as_correction_and_disconnected_feedback_still_works(checkout, monkeypatch):
    root, loop, jobs = checkout
    _connect(monkeypatch, {"Interpretation": "Use the recorded event."})
    at = _ask(_app(root))
    at.text_input(key="source").set_value("manual source reference").run()
    assert at.session_state[forms.KEY + "feedback"]["outcome"] is None
    monkeypatch.setattr(guide, "_provider_words", lambda *_: (None, "Disconnected"))
    at.text_area(key="meaning").set_value("Confirm which event with the study team.").run()
    _healthy(at)
    assert at.session_state[forms.KEY + "feedback"]["outcome"] == "edited"
    assert _prepare(at)["provenance"]["outcome"] == "edited"
    assert not loop.corrections(root) and not jobs


def test_dependent_reset_uses_actual_applied_value_as_edit_baseline(checkout, monkeypatch):
    root, loop, jobs = checkout
    _connect(monkeypatch, {"Table": "B", "Column": "a"})
    at = _ask(_app(root, dependent=True))
    _healthy(at.button(key=forms.KEY + "replace").click().run())
    record = at.session_state[forms.KEY + "feedback"]
    child = next(field for field in record["fields"] if field["label"] == "Column")
    assert child["proposed"] == "a" and child["applied"] is None and child["applied_present"]
    assert record["outcome"] is None
    at.selectbox(key="column").set_value("b").run()
    _healthy(at)
    assert at.session_state[forms.KEY + "feedback"]["outcome"] == "edited"
    draft = _prepare(at)
    assert "Actually applied:\nnull" in draft["fields"]["wrong"]
    assert "Column — current draft:\nb" in draft["fields"]["right"]
    assert not loop.corrections(root) and not jobs


@pytest.mark.parametrize("field,value", [("actor", "Another author"), ("pack", "products/oncology/other/202606"),
                                        ("can_write", False), ("source_stamp", "different-source")])
def test_scoped_feedback_and_prepared_form_clear_when_ownership_or_source_changes(checkout, monkeypatch, field, value):
    root, loop, jobs = checkout
    _connect(monkeypatch, {"Interpretation": "Use a recorded event."})
    at = _ask(_app(root))
    at.text_area(key="meaning").set_value("Keep the event choice open.").run()
    _prepare(at)
    at.session_state[field] = value
    _healthy(at.run())
    assert forms.KEY + "feedback" not in at.session_state
    assert not any(item.key == FORM + "wrong" for item in at.text_area)
    assert not loop.corrections(root) and not jobs


def test_new_manual_edit_invalidates_prepared_feedback_and_secret_tail_is_refused(checkout, monkeypatch):
    root, loop, jobs = checkout
    _connect(monkeypatch, {"Interpretation": "Use diagnosis."})
    at = _ask(_app(root))
    at.text_area(key="meaning").set_value("Use the reviewed event.").run()
    first = _prepare(at)
    at.text_area(key="meaning").set_value("Keep timing unresolved.").run()
    _healthy(at)
    assert not any(item.key == FORM + "wrong" for item in at.text_area)
    second = _prepare(at)
    assert first["provenance"]["observation_id"] != second["provenance"]["observation_id"]
    at.text_area(key="meaning").set_value("Review this. " * 200 + "ANTHROPIC_API_KEY=synthetic-feedback-secret").run()
    _healthy(at)
    at.radio(key=FEEDBACK + "category").set_value("missing_source").run()
    _healthy(at.button(key=FEEDBACK + "prepare").click().run())
    assert FEEDBACK + "prepared" not in at.session_state
    assert any("credential" in item.value.lower() for item in at.warning)
    assert not loop.corrections(root) and not jobs


def test_large_packet_uses_explicit_field_selection_without_losing_exact_values(checkout, monkeypatch):
    root, loop, jobs = checkout
    values = {"Field " + str(index): ("proposal" + str(index) + " ") * 350 for index in range(4)}
    _connect(monkeypatch, values)
    at = _ask(_app(root, long_fields=True))
    _healthy(at.button(key=forms.KEY + "replace").click().run())
    record = at.session_state[forms.KEY + "feedback"]
    assert len(record["fields"]) == 4
    assert all(field["applied"] == values[field["label"]] for field in record["fields"])
    assert not any(item.label == "Which prepared field needs feedback?" for item in at.selectbox)
    _healthy(at.text_area(key="long_2").set_value("Use the reviewed source interpretation for field 2.").run())
    record = at.session_state[forms.KEY + "feedback"]
    assert record["outcome"] == "edited"
    assert all(field["applied"] == values[field["label"]] for field in record["fields"])
    picker = next(item for item in at.selectbox if item.label == "Which prepared field needs feedback?")
    picker.set_value(record["fields"][2]["id"]).run()
    _healthy(at)
    draft = _prepare(at, "unclear_explanation")
    assert "Field 2" in draft["fields"]["wrong"] and "Field 0" not in draft["fields"]["wrong"]
    assert not loop.corrections(root) and not jobs


def test_prose_followup_keeps_its_feedback_and_later_edit_uses_original_field_interaction(checkout, monkeypatch):
    root, loop, jobs = checkout
    _connect(monkeypatch, {"Interpretation": "Use the recorded event."})
    at = _ask(_app(root))
    original = at.session_state[forms.KEY + "feedback"]

    class ProseModel:
        def step(self, system, messages):
            return json.dumps({"answer": "The source reference still needs review.", "actions": []})

    provider = {"configured": True, "instance": ProseModel(), "provider": "Scripted connection", "model": "test"}
    monkeypatch.setattr(guide, "_provider_words", lambda *_: (provider, "Scripted connection"))
    _healthy(at.chat_input[0].set_value("What should I review next?").run())
    assert "Feedback on this answer" not in [item.label for item in at.expander]
    next(item for item in at.toggle if item.label == "Give feedback on the latest answer").set_value(True).run()
    _healthy(at)
    assert "Feedback on this answer" in [item.label for item in at.expander]
    assert "Feedback on these form values" not in [item.label for item in at.expander]
    assert at.session_state[forms.KEY + "feedback"]["id"] == original["id"]

    at.text_area(key="meaning").set_value("Keep the event unresolved pending source review.").run()
    _healthy(at)
    assert {"Feedback on this answer", "Feedback on these form values"} <= {item.label for item in at.expander}
    record = at.session_state[forms.KEY + "feedback"]
    assert record["id"] == original["id"] and record["request"] == original["request"]
    assert record["outcome"] == "edited"
    draft = _prepare(at)
    assert "Use the recorded event." in draft["fields"]["wrong"]
    assert "Keep the event unresolved" in draft["fields"]["right"]
    assert "source reference still needs review" not in draft["fields"]["wrong"]
    assert not loop.corrections(root) and not jobs
