"""Disposable product packs for the portal suites; never reads a working product or its review records.

Three seeds, because the configuration editor is offered by what a product's files carry and
not by its name: the template scaffold at any pack path, the bladder walkthrough copied from
the sandbox to a product path that never existed in the repository, and the prostate
reference fixture at its own fixtures/ path. Every seed builds into a disposable root.
"""
from __future__ import annotations

import json
from pathlib import Path
import shutil

import yaml

ROOT = Path(__file__).resolve().parents[2]
PACK = "products/oncology/gist_program/202606"
REFERENCE = "fixtures/oncology/gist/202608"
BLADDER = "products/oncology/bladder_uat/202609"
WALKTHROUGH = "sandbox/demo_walkthrough/bladder/202609"
PROSTATE = "fixtures/oncology/prostate/202606"


def _disposable(root):
    root = Path(root).resolve()
    if root == ROOT.resolve():
        raise ValueError("The test fixtures require a disposable root.")
    return root


def _register(root, pack, entry):
    """Add the pack's product to the registry beside it (products/ or fixtures/), replacing any same slug."""
    slug = pack.split("/")[-2]
    registry = root / pack.split("/")[0] / "registry.yaml"
    registry.parent.mkdir(parents=True, exist_ok=True)
    doc = yaml.safe_load(registry.read_text(encoding="utf-8")) if registry.exists() else None
    doc = doc if isinstance(doc, dict) else {"tumors": []}
    doc["tumors"] = [row for row in doc.get("tumors") or [] if row.get("slug") != slug] + [entry]
    registry.write_text(yaml.safe_dump(doc, sort_keys=False), encoding="utf-8")


def seed_gist(root, *, extraction=False, pack=PACK):
    """Keep template placeholders for validator tests and optionally add mock rows.

    ``pack`` chooses where the scaffold lives; the slug and version come from that path so a
    suite can prove a feature works on a product that is not the one it was first written for.
    """
    root = _disposable(root)
    slug, version = pack.split("/")[-2:]
    product = root / pack
    shutil.copytree(ROOT / "platform/TUMOR_TEMPLATE", product,
                    ignore=shutil.ignore_patterns("__pycache__", ".portal-drafts"))
    config_path = product / "config/data_product.yaml"
    config = yaml.safe_load(config_path.read_text(encoding="utf-8"))
    config.update(data_product_id=f"{slug}_rwdp", name="Synthetic GIST test scaffold",
                  version=version + ".{snapshot}", vendor="flatiron", tumor_class="solid")
    config_path.write_text(yaml.safe_dump(config, sort_keys=False), encoding="utf-8")
    (product / "spec_pipeline/pipeline.conf").write_text(
        f"TUMOR={slug}\nSPEC_SOURCE_ID=program_spec\n", encoding="utf-8")
    source = {"product": slug, "spec_version": version, "source_materials": [{
        "material_id": "program_spec", "material_type": "program_spec",
        "path_or_link": "prog_spec/mock.xlsx", "status": "pending",
        "ai_classification": "sponsor_ai_eligible", "classified_by": "Synthetic Test Author",
        "classified_date": "2026-09-01", "why_provisional": "Disposable mock source; scientific review has not occurred."}]}
    (product / "source_refs.yaml").write_text(yaml.safe_dump(source, sort_keys=False), encoding="utf-8")
    if extraction:
        retained = ROOT / REFERENCE
        mock = retained / "prog_spec/reference/PROG_SPEC_RWDP_GIST_MOCK_202608.xlsx"
        shutil.copyfile(mock, product / "prog_spec/mock.xlsx")
        extracted = json.loads((retained / "spec_pipeline/out/extracted.json").read_text(encoding="utf-8"))
        extracted["extraction"]["target"] = pack + "/prog_spec/mock.xlsx"
        output = product / "spec_pipeline/out"
        output.mkdir()
        (output / "extracted.json").write_text(json.dumps(extracted, ensure_ascii=False), encoding="utf-8")
    _register(root, pack, {
        "slug": slug, "code": slug, "name": "Synthetic GIST", "modality": "ehr",
        "vendor": "flatiron", "status": "scaffold", "current_spec_version": version})
    return product


def seed_bladder(root, *, pack=BLADDER):
    """The sandbox bladder walkthrough as a product at a path the repository never carried.

    Its settings are real values rather than template placeholders, so it exercises the
    editor on a configured product; nothing in it is vendor content or a clinical claim.
    """
    root = _disposable(root)
    slug, version = pack.split("/")[-2:]
    product = root / pack
    shutil.copytree(ROOT / WALKTHROUGH, product,
                    ignore=shutil.ignore_patterns("__pycache__", ".portal-drafts"))
    _register(root, pack, {
        "slug": slug, "code": slug, "name": "Bladder walkthrough (test copy)", "modality": "ehr",
        "vendor": "flatiron", "tumor_class": "solid", "status": "scaffold", "current_spec_version": version})
    return product


def seed_prostate(root):
    """The prostate reference fixture at its own fixtures/ path, with the fixture registry beside it."""
    root = _disposable(root)
    product = root / PROSTATE
    shutil.copytree(ROOT / PROSTATE, product,
                    ignore=shutil.ignore_patterns("__pycache__", ".portal-drafts"))
    shutil.copyfile(ROOT / "fixtures/registry.yaml", product.parents[2] / "registry.yaml")
    return product
