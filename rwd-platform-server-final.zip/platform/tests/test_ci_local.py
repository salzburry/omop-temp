"""The local CI lane executes pytest cases and keeps Spark suites separate.

Run: python platform/tests/test_ci_local.py
"""
from __future__ import annotations

import os
import sys
import tempfile
from pathlib import Path
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[2]
sys.path[:0] = [str(ROOT / "platform" / "tools")]

import ci_local  # noqa: E402


def test_the_lane_lists_every_pure_python_suite_and_skips_the_spark_ones_by_name():
    rows = ci_local.steps()
    names = [name for name, _argv, _skip in rows]
    suites = {n.split("suite ", 1)[1] for n in names if n.startswith("suite ")}
    on_disk = {f for f in os.listdir(ROOT / "platform" / "tests") if f.startswith("test_") and f.endswith(".py")}
    assert suites == on_disk, "every suite on disk is a row, and nothing else is"
    for name, argv, skip in rows:
        if name.startswith("suite ") and name.split("suite ", 1)[1] in ci_local.SPARK_SUITES:
            assert argv is None and "pyspark" in skip
        elif name.startswith("suite "):
            assert skip or (argv[1:6] == ["-m", "pytest", "-q", "-p", "no:cacheprovider"]
                            and argv[-1].endswith(name.split("suite ", 1)[1])), "each suite must execute pytest cases"
    assert names[0] == "every module compiles" and "gate 3 structure over every contract" in names
    assert {"event ledger and claimed objects", "source manifest integrity", "approval identity"} <= set(names)
    workflow = (ROOT / ".github" / "workflows" / "rwdp-ci.yml").read_text(encoding="utf-8")
    for suite in ci_local.SPARK_SUITES:
        assert suite in workflow, f"{suite} is the workflow's own skip list"


def test_portal_mode_includes_shared_form_checks_once_and_quick_mode_runs_no_suite():
    steps = ci_local.steps(portal_only=True)
    portal = [name for name, _a, _s in steps if name.startswith("suite ")]
    assert portal and all(n.split("suite ", 1)[1].startswith(ci_local.PORTAL_PREFIXES) for n in portal)
    extra = [(name, argv) for name, argv, _s in steps if not name.startswith("suite ")]
    assert not extra, "each suite executes once; there is no script/no-main duplicate pass"
    expected = {p.name for p in (ROOT / "platform/tests").glob("test_*.py")
                if "prefill" in p.name or "form_assistance" in p.name}
    actual = [name.split("suite ", 1)[1] for name in portal]
    assert expected <= set(actual) and len(actual) == len(set(actual))
    quick = [name for name, _a, _s in ci_local.steps(quick=True)]
    assert quick and not any(n.startswith("suite ") for n in quick)


def test_missing_streamlit_keeps_shared_form_suites_visible_as_skipped():
    with patch.object(ci_local, "_have", return_value=False):
        steps = ci_local.steps(portal_only=True)
    for name, argv, skip in steps:
        assert argv is None and "streamlit" in skip, name
    assert any("test_form_assistance_adversarial.py" in name for name, _, _ in steps)


def test_next_cut_mixed_module_runs_once_in_both_portal_and_default_lanes():
    name = "suite test_next_cut_sheet_identity.py"
    with patch.object(ci_local, "_have", return_value=True):
        portal = [row for row in ci_local.steps(portal_only=True) if row[0] == name]
        default = [row for row in ci_local.steps() if row[0] == name]
    assert len(portal) == 1 and portal == default
    _name, argv, skipped = portal[0]
    assert not skipped and argv[1:3] == ["-m", "pytest"]
    assert Path(argv[-1]).name == "test_next_cut_sheet_identity.py"


def test_next_cut_missing_streamlit_is_a_prerequisite_skip_without_executing_or_claiming_pass():
    with patch.object(ci_local, "_have", return_value=False), \
            patch.object(ci_local, "_pytest_result", side_effect=AssertionError("a prerequisite skip must not execute")):
        rows = ci_local.run_lane(portal_only=True, only="test_next_cut_sheet_identity.py")
    assert len(rows) == 1 and rows[0]["verdict"] == "skipped"
    assert "streamlit" in rows[0]["detail"]
    _text, tally = ci_local.render(rows)
    assert tally == {"pass": 0, "fail": 0, "skipped": 1}


def test_selected_suite_executes_fixture_assertions_despite_noop_legacy_entrypoint():
    with tempfile.TemporaryDirectory(prefix="local-ci-count-") as directory:
        root = Path(directory)
        tests = root / "platform/tests"
        tests.mkdir(parents=True)
        (tests / "test_chat_prefill_probe.py").write_text('''import pytest
@pytest.fixture
def reviewed_value(): return 2
@pytest.mark.parametrize("expected", [2, 3])
def test_prepared_value(reviewed_value, expected):
    assert reviewed_value == expected
if __name__ == "__main__":
    pass
''', encoding="utf-8")
        with patch.object(ci_local, "ROOT", str(root)), patch.object(ci_local, "_have", return_value=True):
            rows = ci_local.steps(portal_only=True)
        assert len(rows) == 1 and not rows[0][2]
        code, output, _seconds = ci_local._run(rows[0][1], cwd=root, timeout=30)
        assert code == 1 and "1 failed, 1 passed" in output, output


def test_the_summary_never_counts_a_skip_as_a_pass():
    rows = [{"step": "a", "verdict": "pass", "seconds": 1.0, "detail": ""},
            {"step": "b", "verdict": "skipped", "seconds": 0.0, "detail": "needs pyspark"},
            {"step": "c", "verdict": "fail", "seconds": 2.0, "detail": "boom"}]
    text, tally = ci_local.render(rows)
    assert tally == {"pass": 1, "fail": 1, "skipped": 1}
    assert "SKIPPED is not a pass" in text


if __name__ == "__main__":
    failures = 0
    for name, fn in sorted(globals().items()):
        if name.startswith("test_") and callable(fn):
            try:
                fn()
                print("ok  ", name)
            except Exception as exc:  # noqa: BLE001
                failures += 1
                print("FAIL", name, exc)
    sys.exit(1 if failures else 0)
