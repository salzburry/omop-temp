"""Competency questions must be ANSWERABLE, and an unanswerable one must say so.

The point of writing competency questions down is that "we can explain any variable end to end"
becomes checkable. That only holds if the harness cannot cheat: an answer invented where the
artifacts are silent, a question that dies and takes the other nine with it, or an absence
rendered as blank would each turn a test into decoration.

So the properties pinned here are the refusals. Every question answers from a committed artifact
or names the reason it cannot; a reader that raises is reported as unanswered rather than
escaping; an unknown variable is refused by name; no answer carries an approval word; and the
harness writes nothing.

Run: python3 tests/test_competency.py (or pytest). Pure — no Spark.
"""
import json
import os
import sys
import tempfile
from pathlib import Path

FRAMEWORK = Path(__file__).resolve().parent.parent
REPO = FRAMEWORK.parent
sys.path.insert(0, str(FRAMEWORK / "tools"))
sys.path.insert(0, str(FRAMEWORK / "engine"))

import competency as cq   # noqa: E402

# ANCHORED ON THE CHECKOUT, not on the caller's working directory. As a relative path this
# resolved to `platform/products/...` whenever the suite ran from `platform/` — which is
# exactly how CI runs it — so the pack was simply not found and the failure had nothing to
# do with what the test was checking. A test that only passes from one directory is a test
# whose result depends on who ran it.
PACK = str(REPO / "fixtures" / "oncology" / "prostate" / "202606")


def test_every_question_answers_from_an_artifact_or_names_why_it_cannot():
    """The whole contract, on the live pack: ten questions, ten states, no silence. An answered
    question carries evidence; an absent one carries a reason a person can act on."""
    r = cq.ask(PACK, "AGEGR1")
    assert [a["id"] for a in r["answers"]] == [q[0] for q in cq.QUESTIONS]
    assert r["of"] == 10 and 0 < r["answered"] <= 10
    for a in r["answers"]:
        assert a["state"] in ("answered", "absent"), a
        if a["state"] == "answered":
            assert a["answer"], a
        else:
            assert a.get("reason"), f"{a['id']} is absent with no reason — that is silence"
            assert a["answer"] is None, a
        assert a["question"].endswith("?"), a


def test_the_lineage_answers_are_the_real_ones_not_a_shape():
    """A harness that returned well-formed empties would pass the test above. These are the
    actual facts for a known prostate record — the spec row it came from, the config block that
    runs it, and the decisions it hangs on."""
    r = cq.ask(PACK, "AGEGR1")
    by = {a["id"]: a for a in r["answers"]}
    assert by["CQ01"]["state"] == "answered" and "demographics:" in by["CQ01"]["answer"]
    assert by["CQ01"]["evidence"]["digest"], "the spec digest is what binds the record to the text"
    assert by["CQ03"]["state"] == "answered" and "age_bands" in by["CQ03"]["answer"]
    assert by["CQ04"]["evidence"]["count"] > 5, "the source roles are not being read"
    assert by["CQ06"]["state"] == "answered" and by["CQ06"]["evidence"]["open"], \
        "AGEGR1's open naming/coding decisions vanished — either resolved, or not being read"


def test_an_absence_is_a_state_and_never_a_pass():
    """The four questions prostate cannot answer today are the ones that matter most for the
    grammar: no adapter, no golden fixture, no build, no second implementation. Each must be
    ABSENT with the reason, never answered with an empty string."""
    r = cq.ask(PACK, "AGEGR1")
    by = {a["id"]: a for a in r["answers"]}
    for qid, needle in (("CQ05", "no config/source_adapters.yaml"),
                        ("CQ07", "no golden fixture"),
                        ("CQ08", "NO BUILD RECORDED"),
                        ("CQ10", "not_established" if by["CQ10"]["state"] == "answered"
                                 else "pooling needs two implementations")):
        a = by[qid]
        assert a["state"] == "absent", f"{qid} claims an answer the pack cannot support: {a}"
        assert needle in a["reason"], (qid, a["reason"])


def test_a_question_that_raises_is_reported_unanswered_not_fatal():
    """One broken reader must not take the other nine answers down with it — the failure mode
    that turns a diagnostic into an outage exactly when something is already wrong."""
    def _boom(pack, entry, ctx):
        raise RuntimeError("the ledger is on fire")

    original = cq.QUESTIONS
    cq.QUESTIONS = (("CQ01", "Does a broken reader stay contained?", _boom),) + original[1:]
    try:
        r = cq.ask(PACK, "AGEGR1")
        first = r["answers"][0]
        assert first["state"] == "absent" and "RuntimeError" in first["reason"], first
        assert "the ledger is on fire" in first["reason"]
        assert len(r["answers"]) == 10, "the other questions were lost with it"
        assert any(a["state"] == "answered" for a in r["answers"][1:])
    finally:
        cq.QUESTIONS = original


def test_an_unknown_variable_is_refused_by_name():
    """A wrong guess must not print a clean sheet of ten absences — that reads as "this variable
    has no lineage" when the truth is "there is no such variable"."""
    try:
        cq.ask(PACK, "NO_SUCH_VARIABLE_AT_ALL")
        raise AssertionError("an invented variable produced a competency report")
    except KeyError as e:
        assert "not a variable_id" in str(e) and "record(s)" in str(e)


def test_no_answer_carries_an_approval_word():
    """A lineage fact rendered with a verdict word would be read as an approval nobody gave —
    the same rule every other reporting surface here follows."""
    r = cq.ask(PACK, "AGEGR1")
    blob = json.dumps(r).lower()
    for word in ("approved by this tool", "verified", "validated", "signed off"):
        assert word not in blob, f"{word!r} appears in a competency answer"
    text = cq.render(r).lower()
    assert "nothing here rules on it" in text
    for word in cq.FORBIDDEN:
        assert word not in text, word


def test_coverage_counts_every_record_and_names_the_first_absence():
    """The coverage view is the map of what this product can and cannot explain about itself —
    per question, over every record, with the reason attached to each gap."""
    c = cq.coverage(PACK)
    assert c["records"] > 100, c["records"]
    assert set(c["answered"]) == {q[0] for q in cq.QUESTIONS}
    for qid, n in c["answered"].items():
        assert 0 <= n <= c["records"], (qid, n)
        if n < c["records"]:
            assert c["first_absence_reason"].get(qid), f"{qid} has gaps and no stated reason"
    assert c["answered"]["CQ01"] == c["records"], \
        "a record with no spec citation exists — every contract record must cite its spec row"
    body = cq.render_coverage(c)
    assert "open work, not a failure" in body


def test_the_harness_writes_nothing():
    """A reporting surface that could write would be a new authority nobody granted — asserted on
    the source, the same way the differential's read-only property is."""
    import ast
    tree = ast.parse((FRAMEWORK / "tools" / "competency.py").read_text(encoding="utf-8"))
    for node in ast.walk(tree):
        if isinstance(node, ast.Call):
            name = getattr(node.func, "id", "") or getattr(node.func, "attr", "")
            assert name not in ("write_text", "writelines", "safe_dump", "dump", "mkdir",
                                "makedirs", "remove", "rename", "rmtree"), f"{name}() writes"
        if isinstance(node, ast.Call) and getattr(node.func, "id", "") == "open":
            mode = next((a for a in node.args[1:]), None)
            assert mode is None or getattr(mode, "value", "r").startswith("r"), "opened for write"


def test_the_cli_reports_and_refuses_a_non_pack():
    """Both entry points, and the refusal a mistyped path must get."""
    import subprocess
    r = subprocess.run([sys.executable, str(FRAMEWORK / "tools" / "competency.py"),
                        PACK, "--variable", "AGEGR1", "--json"],
                       cwd=str(REPO), capture_output=True, encoding="utf-8")
    assert r.returncode == 0, r.stderr
    doc = json.loads(r.stdout)
    assert doc["variable_id"] == "AGEGR1" and len(doc["answers"]) == 10

    with tempfile.TemporaryDirectory() as tmp:
        bad = subprocess.run([sys.executable, str(FRAMEWORK / "tools" / "competency.py"),
                              os.path.join(tmp, "nope")],
                             cwd=str(REPO), capture_output=True, encoding="utf-8")
        assert bad.returncode != 0 and "not a product pack" in (bad.stderr + bad.stdout)


def test_no_question_claims_more_than_its_answer_proves():
    """AN EXTERNAL REVIEW CAUGHT TWO OF THESE, both in wording rather than logic, and both the
    kind that makes a lineage report read as an approval. CQ01 asked for the "approved
    specification row" while proving only a citation and a digest; CQ09 asked which datasets
    "implement" the product while counting the registry's intended vendor. A question that
    overstates its evidence is worse than a missing question, because a reader believes it."""
    texts = {qid: q for qid, q, _f in cq.QUESTIONS}
    assert "approved" not in texts["CQ01"].lower(), texts["CQ01"]
    assert "cite" in texts["CQ01"].lower() and "digest" in texts["CQ01"].lower()

    r = cq.ask(PACK, "AGEGR1")
    by = {a["id"]: a for a in r["answers"]}
    # the record's own status rides beside the citation, so nothing reads as settled
    assert by["CQ01"]["evidence"]["record_status"] in ("draft", "decision_required", "approved",
                                                       "(unstated)")

    # a registry vendor is a DECLARATION; only a checked adapter evidences an implementation
    assert "declared" in texts["CQ09"].lower() or "adapter" in texts["CQ09"].lower()
    assert by["CQ09"]["state"] == "absent", \
        "prostate has no checked adapter, so nothing implements it — this must not answer"
    assert "INTENDED" in by["CQ09"]["reason"] and "flatiron" in by["CQ09"]["reason"].lower()


def test_a_pack_with_no_records_is_vacuous_not_fully_covered():
    """0 of 0 renders like complete coverage of nothing. A pack that has never been drafted must
    say the questions were not asked, which is not the same as answered."""
    c = cq.coverage("fixtures/oncology/nsclc/YYYYMM")
    assert c["records"] == 0 and c["vacuous"] is True
    assert "never asked" in c["note"]
    assert "never asked" in cq.render_coverage(c)
    live = cq.coverage(PACK)
    assert live["vacuous"] is False and not live["note"]


if __name__ == "__main__":
    bad = 0
    for name, fn in sorted(globals().items()):
        if name.startswith("test_") and callable(fn):
            try:
                fn()
                print(f"  ok  {name}")
            except Exception as e:                   # noqa: BLE001 - report and continue
                bad += 1
                print(f"FAIL  {name}: {e}")
    sys.exit(1 if bad else 0)
