"""Three real, isolated specification rehearsals plus adversarial UI boundaries.

No product/fixture is modified. The three UI journeys execute existing CLI workers;
only failure cases use doubles. This file also runs as the repository's script CI.
"""
from __future__ import annotations

import contextlib
import hashlib
import io
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import types
import zipfile
from unittest.mock import Mock, patch

import yaml

ROOT = Path(__file__).resolve().parents[2]
sys.path[:0] = [str(ROOT / "experiments/portal"), str(ROOT / "platform/tests")]
import demo_journey as journeys
from _epi_test_support import api, run

pytest = api(__name__)


@contextlib.contextmanager
def _page():
    from streamlit.testing.v1 import AppTest
    with tempfile.TemporaryDirectory(prefix="epi-demo-ui-") as td:
        case = types.ModuleType("_epi_demo_case")
        case.root, case.state_root, case.actor = str(ROOT), td, "demo_scientist"
        case.local_demo, case.can_write, case.can_view = True, True, True
        previous = sys.modules.get(case.__name__)
        sys.modules[case.__name__] = case
        source = """import streamlit as st
import demo_journey_page
import _epi_demo_case as case
st.set_page_config(layout='wide')
page=st.sidebar.radio('Workspace', ['Rehearsal','Other'],key='test_workspace')
if page=='Rehearsal':
    demo_journey_page.render(case.root,actor_id=case.actor,local_demo=case.local_demo,
       can_write=case.can_write,can_view=case.can_view,state_root=case.state_root)
else:
    st.write('Another workspace page')
"""
        case.source = source
        at = AppTest.from_string(source, default_timeout=90).run()
        try:
            yield at, case
        finally:
            if previous is None:
                sys.modules.pop(case.__name__, None)
            else:
                sys.modules[case.__name__] = previous


def _healthy(at):
    assert not list(at.exception), [item.message for item in at.exception]


def _prepare(at, kind="new", example="gist"):
    at.radio(key="demo_journey_kind").set_value(kind).run()
    at.selectbox(key="demo_example").set_value(example)
    at.text_input(key="demo_label").set_value("Two study " + kind)
    at.text_area(key="demo_purpose").set_value("Compare treatment sequencing and survival across two studies.")
    at.text_area(key="demo_studies").set_value("Study A\nStudy B")
    if kind == "revise":
        at.multiselect(key="demo_sections").set_value(["outcomes"])
        at.text_input(key="demo_add_name").set_value("PROPOSED_OS")
        at.text_area(key="demo_add_definition").set_value("Time from cohort index to death from any cause; review censoring before implementation.")
        at.text_input(key="demo_source").set_value("Alternate claims delivery")
        at.selectbox(key="demo_modality").set_value("claims")
    at.button(key="demo_prepare").click().run()
    _healthy(at)
    assert len(at.button(key="demo_run").label)


def _inputs():
    files = []
    for example in journeys.EXAMPLES.values():
        source = ROOT / example["pack"]
        files += [ROOT / example["workbook"], source / "source_refs.yaml", source / "spec_pipeline/pipeline.conf"]
        files += [p for directory in ("config", "variables", "codelists", "handoff")
                  for p in (source / directory).rglob("*") if p.is_file() and not any(x.startswith(".") for x in p.relative_to(source).parts)]
    return {str(path): hashlib.sha256(path.read_bytes()).hexdigest() for path in files}


@pytest.mark.parametrize("kind,example,rows,high", [("new", "gist", 26, 3), ("template", "bladder", 16, 0), ("revise", "bladder", 16, 0)])
def test_three_real_ui_journeys_produce_checked_draft_artifacts(kind, example, rows, high):
    before = _inputs()
    with _page() as (at, case):
        _prepare(at, kind, example)
        identifier = at.session_state.demo_active_id
        at.button(key="demo_run").click().run(timeout=90)
        _healthy(at)
        assert any(item.value == "Draft rehearsal complete" for item in at.success)
        loaded = journeys.read_run(ROOT, case.state_root, case.actor, identifier)
        assert loaded["ok"], loaded
        record = loaded["run"]
        assert record["stage"] == "complete" and record["releasable"] is False
        assert record["report"]["specification_rows"] == rows
        assert record["report"]["high_findings"] == high
        assert record["report"]["synthetic_ads"] == "not_requested"
        assert [(step["worker"], step["exit_code"]) for step in record["steps"]] == [
            ("platform/tools/run_spec_pipeline.py", 0), ("platform/engine/validate.py", 0)]
        folder = journeys._folder(ROOT, case.state_root, case.actor, identifier)
        product = folder / record["product"]
        material = yaml.safe_load((product / "source_refs.yaml").read_text(encoding="utf-8"))["source_materials"][0]
        assert material["status"] == "pending"
        assert not any(field in material for field in ("approved_by", "approval_date", "object_uuid"))
        assert not (product / "governance").exists()
        assert not (product / "handoff/APPROVALS.md").exists()
        assert record["plan"]["applied_to_execution"] is False
        if kind == "revise":
            proposal = record["plan"]["definition_review"]
            assert proposal["valid"], proposal["errors"]
            assert proposal["removed"] == ["ECOG"] and proposal["source_changed"]
            assert proposal["added"][0]["variable_id"] == "PROPOSED_OS"
            config = yaml.safe_load((product / "config/data_product.yaml").read_text(encoding="utf-8"))
            assert config["vendor"] != "Alternate claims delivery"
            assert "ECOG" in (product / "handoff/FUNCTIONAL_CONTRACT.md").read_text(encoding="utf-8")
        with zipfile.ZipFile(io.BytesIO(journeys.bundle(ROOT, case.state_root, case.actor, identifier))) as packet:
            assert all("specification/" + filename in packet.namelist() for filename in journeys.OUTPUTS)
            assert json.loads(packet.read("qc-report.json"))["source_mode"] == "synthetic"
            assert "not an approved product" in packet.read("READ-ME.txt").decode()
        # Durable reload is independent of the active Streamlit widget/session.
        from streamlit.testing.v1 import AppTest
        reopened = AppTest.from_string(case.source, default_timeout=90).run()
        reopened.button(key="demo_resume").click().run()
        _healthy(reopened)
        assert reopened.session_state.demo_active_id == identifier
        assert any(item.value == "Draft rehearsal complete" for item in reopened.success)
    assert _inputs() == before


def test_draft_survives_workspace_navigation_and_actor_change_clears_it():
    with _page() as (at, case):
        at.text_input(key="demo_label").set_value("Private draft").run()
        at.text_area(key="demo_purpose").set_value("Private study question").run()
        at.radio(key="test_workspace").set_value("Other").run()
        at.radio(key="test_workspace").set_value("Rehearsal").run()
        _healthy(at)
        assert at.text_input(key="demo_label").value == "Private draft"
        assert at.text_area(key="demo_purpose").value == "Private study question"
        case.actor = "another_scientist"
        at.button(key="demo_prepare").click().run()
        _healthy(at)
        assert at.text_input(key="demo_label").value == ""
        assert journeys.list_runs(ROOT, case.state_root, case.actor) == []


def test_read_only_and_hosted_context_cannot_run_stale_submit():
    for field in ("can_write", "local_demo"):
        with _page() as (at, case):
            _prepare(at)
            identifier = at.session_state.demo_active_id
            setattr(case, field, False)
            with patch.object(journeys, "execute") as worker:
                at.button(key="demo_run").click().run()
            _healthy(at)
            worker.assert_not_called()
            assert journeys.read_run(ROOT, case.state_root, case.actor, identifier)["run"]["stage"] == "prepared"


def test_no_view_exits_before_reading_private_rehearsals():
    with _page() as (at, case):
        case.can_view = False
        with patch.object(journeys, "list_runs") as listing, patch.object(journeys, "read_run") as reading:
            at.run()
        _healthy(at)
        listing.assert_not_called()
        reading.assert_not_called()
        assert not [button for button in at.button if button.key == "demo_prepare"]


def _prepared(directory):
    result = journeys.prepare(ROOT, directory, "scientist", journey="new", example_id="gist",
                              label="Bounded test", purpose="Evaluate a draft specification.", local_demo=True, can_write=True)
    assert result["ok"], result
    return result["run"]


def test_modified_input_refused_before_any_worker(tmp_path):
    record = _prepared(tmp_path)
    folder = journeys._folder(ROOT, tmp_path, "scientist", record["id"])
    source = folder / record["product"] / "source_refs.yaml"
    source.write_text(source.read_text(encoding="utf-8") + "\n# changed\n", encoding="utf-8")
    with patch.object(journeys.subprocess, "run") as worker:
        result = journeys.execute(ROOT, tmp_path, "scientist", record["id"], local_demo=True, can_write=True)
    assert not result["ok"] and "changed" in result["errors"][0]
    assert result["run"]["stage"] == "needs_attention"
    worker.assert_not_called()


def test_timeout_keeps_failed_diagnostics_and_never_claims_success(tmp_path):
    record = _prepared(tmp_path)
    with patch.object(journeys.subprocess, "run", side_effect=subprocess.TimeoutExpired(["worker"], 180)):
        result = journeys.execute(ROOT, tmp_path, "scientist", record["id"], local_demo=True, can_write=True)
    assert not result["ok"] and result["run"]["stage"] == "needs_attention"
    assert result["run"]["steps"][0]["exit_code"] == 124
    assert "report" not in result["run"]
    folder = journeys._folder(ROOT, tmp_path, "scientist", record["id"])
    assert not (folder / ".running").exists()


def test_timeout_is_visible_in_page_with_retained_logs():
    with _page() as (at, case):
        _prepare(at)
        with patch.object(journeys.subprocess, "run", side_effect=subprocess.TimeoutExpired(["worker"], 180)):
            at.button(key="demo_run").click().run()
        _healthy(at)
        assert any("needs attention" in item.value for item in at.error)
        assert not list(at.success)
        assert any("exceeded its time limit" in item.value for item in at.code)


def test_cross_actor_and_repo_locations_are_refused(tmp_path):
    record = _prepared(tmp_path)
    assert not journeys.read_run(ROOT, tmp_path, "someone_else", record["id"])["ok"]
    assert journeys.list_runs(ROOT, tmp_path, "someone_else") == []
    assert not journeys.execute(ROOT, tmp_path, "scientist", record["id"], local_demo=False, can_write=True)["ok"]
    result = journeys.prepare(ROOT, ROOT / "products/rehearsals", "scientist", journey="new", example_id="gist",
                              label="Bad path", purpose="No product write", local_demo=True, can_write=True)
    assert not result["ok"] and "outside the repository" in result["errors"][0]


def test_malformed_saved_record_is_reported_without_ui_exception():
    with _page() as (at, case):
        _prepare(at)
        folder = journeys._folder(ROOT, case.state_root, case.actor, at.session_state.demo_active_id)
        record = json.loads((folder / "rehearsal.json").read_text(encoding="utf-8"))
        record["plan"] = {"purpose": []}
        (folder / "rehearsal.json").write_text(json.dumps(record), encoding="utf-8")
        at.run()
        _healthy(at)
        assert any("unreadable" in item.value for item in at.error)


def test_interrupted_lock_is_recoverable_after_bounded_worker_timeout(tmp_path):
    record = _prepared(tmp_path)
    folder = journeys._folder(ROOT, tmp_path, "scientist", record["id"])
    lock = folder / ".running"
    lock.write_text("interrupted", encoding="utf-8")
    with patch.object(journeys.subprocess, "run") as worker:
        blocked = journeys.execute(ROOT, tmp_path, "scientist", record["id"], local_demo=True, can_write=True)
        worker.assert_not_called()
    assert not blocked["ok"] and "already running" in blocked["errors"][0]
    os.utime(lock, (0, 0))
    with patch.object(journeys.subprocess, "run", return_value=subprocess.CompletedProcess([], 1, "Failure", "")) as worker:
        retried = journeys.execute(ROOT, tmp_path, "scientist", record["id"], local_demo=True, can_write=True)
    worker.assert_called_once()
    assert not retried["ok"] and "Failure" == retried["run"]["steps"][0]["output"]
    assert not lock.exists()


def test_reused_contract_keeps_literal_requirements_and_clears_approval_axes(tmp_path):
    source, destination = tmp_path / "original.md", tmp_path / "draft.md"
    shipped = ROOT / journeys.EXAMPLES["bladder"]["pack"] / "handoff/FUNCTIONAL_CONTRACT.md"
    content = shipped.read_text(encoding="utf-8").replace("requirement: draft", "requirement: approved").replace("validation: not_run", "validation: passed")
    source.write_text(content, encoding="utf-8")
    journeys._draft_contract(source, destination)
    import design_workspace
    before = list(design_workspace.cl.typed_records(content))[0]
    after = list(design_workspace.cl.typed_records(destination.read_text(encoding="utf-8")))[0]
    assert before.cells["required_rule"] == after.cells["required_rule"]
    assert after.status == {"requirement": "draft", "source": "unverified", "implementation": "not_implemented", "validation": "not_run"}
    assert "requirement: approved" in source.read_text(encoding="utf-8")


def test_real_portal_home_rehearsal_can_return_and_resume_its_plan(tmp_path):
    from test_epi_portal_journeys import _portal
    with patch.dict(os.environ, {"RWDP_DEMO_DIR": str(tmp_path)}), _portal() as at:
        at.button(key="home_demo").click().run()
        _healthy(at)
        _prepare(at, "template", "bladder")
        identifier = at.session_state.demo_active_id
        at.button(key="home_demo_back").click().run()
        _healthy(at)
        at.button(key="home_demo").click().run()
        _healthy(at)
        assert at.session_state.demo_active_id == identifier
        assert at.button(key="demo_run").label == "Run rehearsal"
        assert not list(at.success)


def test_saved_selector_recovers_when_an_older_record_becomes_unreadable():
    with _page() as (at, case):
        _prepare(at)
        first = at.session_state.demo_active_id
        at.button(key="demo_restart").click().run()
        _prepare(at, "template", "bladder")
        second = at.session_state.demo_active_id
        at.selectbox(key="demo_saved_choice").set_value(first).run()
        folder = journeys._folder(ROOT, case.state_root, case.actor, first)
        (folder / "rehearsal.json").write_text("{broken", encoding="utf-8")
        at.run()
        _healthy(at)
        assert at.selectbox(key="demo_saved_choice").value == second


def test_unavailable_optional_runtime_is_an_explanation_not_a_crash():
    with patch.object(journeys.importlib.util, "find_spec", side_effect=ValueError("invalid package metadata")), patch.object(journeys.shutil, "which", return_value=None), patch.dict(os.environ, {"JAVA_HOME": ""}):
        result = journeys.runtime()
    assert result["build_available"] is False and "PySpark and Java" in result["build_reason"]


def _definition_widget(identifier):
    return "demo_edit_definition_" + hashlib.sha256(identifier.encode("utf-8")).hexdigest()[:12]


@pytest.mark.parametrize("kind", ["template", "new"])
def test_completed_rehearsal_can_be_edited_saved_and_rerun_here(kind):
    import demo_revisions
    before = _inputs()
    with _page() as (at, case):
        _prepare(at, kind, "bladder")
        original_id = at.session_state.demo_active_id
        at.button(key="demo_run").click().run(timeout=90)
        _healthy(at)
        original = journeys.read_run(ROOT, case.state_root, case.actor, original_id)["run"]
        snapshot = demo_revisions.read_editor(ROOT, case.state_root, case.actor, original_id)
        assert snapshot["ok"], snapshot
        definition = next(row for row in snapshot["definitions"] if row["variable_id"] == "ECOG")
        at.button(key="demo_edit").click().run()
        _healthy(at)
        assert at.text_input(key="demo_edit_label").value == original["label"]
        assert at.text_area(key="demo_edit_purpose").value == original["plan"]["purpose"]
        assert at.text_area(key="demo_edit_studies").value.splitlines() == original["plan"]["studies"]
        assert at.multiselect(key="demo_edit_sections").value == original["plan"]["retained_sections"]
        assert at.text_input(key="demo_edit_source").value == original["plan"]["proposed_source"]
        assert at.selectbox(key="demo_edit_modality").value == original["plan"]["proposed_modality"]
        at.selectbox(key="demo_edit_definition_choice").set_value(definition["key"]).run()
        edited_text = definition["definition"] + "; confirm this interpretation with the study team."
        assert at.text_area(key=_definition_widget(definition["key"])).value == definition["definition"]
        at.text_input(key="demo_edit_label").set_value("Bladder revised here")
        at.text_area(key="demo_edit_purpose").set_value("Review the literal ECOG interpretation together.")
        at.text_area(key="demo_edit_studies").set_value("Follow-up study")
        at.multiselect(key="demo_edit_sections").set_value(["clinical", "outcomes"])
        at.text_input(key="demo_edit_source").set_value("Proposed claims source")
        at.selectbox(key="demo_edit_modality").set_value("claims")
        at.text_area(key=_definition_widget(definition["key"])).set_value(edited_text).run()
        generated = next(row for row in snapshot["definitions"] if row["origin"] == "scaffold")
        at.selectbox(key="demo_edit_definition_choice").set_value(generated["key"]).run()
        at.radio(key="test_workspace").set_value("Other").run()
        at.radio(key="test_workspace").set_value("Rehearsal").run()
        _healthy(at)
        assert at.text_input(key="demo_edit_label").value == "Bladder revised here"
        assert at.selectbox(key="demo_edit_definition_choice").value == generated["key"]
        at.selectbox(key="demo_edit_definition_choice").set_value(definition["key"]).run()
        assert at.text_area(key=_definition_widget(definition["key"])).value == edited_text
        at.button(key="demo_edit_save").click().run()
        _healthy(at)
        revision_id = at.session_state.demo_active_id
        assert revision_id != original_id
        revised = journeys.read_run(ROOT, case.state_root, case.actor, revision_id)["run"]
        assert revised["revision_of"] == original_id
        assert revised["stage"] == "prepared" and not revised["steps"] and "report" not in revised
        assert revised["label"] == "Bladder revised here"
        assert revised["plan"]["purpose"] == "Review the literal ECOG interpretation together."
        assert revised["plan"]["studies"] == ["Follow-up study"]
        assert revised["plan"]["retained_sections"] == ["clinical", "outcomes"]
        assert revised["plan"]["proposed_source"] == "Proposed claims source"
        assert revised["plan"]["proposed_modality"] == "claims"
        diff = next(item.value for item in at.dataframe if "Your revised interpretation" in item.value.columns)
        assert diff.to_dict("records") == [{"Variable": "ECOG", "Before": definition["definition"],
                                             "Your revised interpretation": edited_text}]
        content = "\n".join(item.value for item in at.markdown)
        assert "Engineering handoff" in content
        assert all(item["detail"] in content for item in revised["plan"]["engineering_handoff"])
        assert not any("starts an empty definition draft" in item.value for item in at.info)
        assert not any(item.value == "Draft rehearsal complete" for item in at.success)
        reloaded = demo_revisions.read_editor(ROOT, case.state_root, case.actor, revision_id)
        assert next(row for row in reloaded["definitions"] if row["variable_id"] == "ECOG")["definition"] == edited_text
        at.button(key="demo_run").click().run(timeout=90)
        _healthy(at)
        assert any(item.value == "Draft rehearsal complete" for item in at.success)
        at.selectbox(key="demo_saved_choice").set_value(original_id)
        at.button(key="demo_resume").click().run()
        _healthy(at)
        assert at.session_state.demo_active_id == original_id
        assert journeys.read_run(ROOT, case.state_root, case.actor, original_id)["run"] == original
        assert any(item.value == "Draft rehearsal complete" for item in at.success)
    assert _inputs() == before


def test_revised_draft_findings_are_visible_with_an_edit_action():
    with _page() as (at, case):
        _prepare(at, "template", "bladder")
        at.button(key="demo_edit").click().run()
        at.button(key="demo_edit_save").click().run()
        real_worker = journeys.subprocess.run
        def worker(command, **kwargs):
            if Path(command[1]).name == "contract_lint.py":
                return subprocess.CompletedProcess(command, 1, "Literal interpretation still needs scientific review", "")
            return real_worker(command, **kwargs)
        with patch.object(journeys.subprocess, "run", side_effect=worker):
            at.button(key="demo_run").click().run(timeout=90)
        _healthy(at)
        assert any("revised draft definitions still need attention" in item.value for item in at.warning)
        assert at.code[0].value == "Literal interpretation still needs scientific review"
        assert any("Literal interpretation still needs scientific review" in item.value for item in at.code)
        assert at.button(key="demo_edit").label == "Edit this rehearsal"
        record = journeys.read_run(ROOT, case.state_root, case.actor, at.session_state.demo_active_id)["run"]
        assert record["report"]["draft_contract_check"] == "needs_attention"
        assert record["report"]["configuration_check"] == "passed"
        assert record["releasable"] is False


def test_cancel_rehearsal_edit_keeps_the_saved_plan_and_discards_unsaved_changes():
    with _page() as (at, case):
        _prepare(at, "template", "bladder")
        original_id = at.session_state.demo_active_id
        original = journeys.read_run(ROOT, case.state_root, case.actor, original_id)["run"]
        at.button(key="demo_edit").click().run()
        at.text_input(key="demo_edit_label").set_value("Unsaved edit").run()
        at.button(key="demo_edit_cancel").click().run()
        _healthy(at)
        assert at.session_state.demo_active_id == original_id
        assert len(journeys.list_runs(ROOT, case.state_root, case.actor)) == 1
        at.button(key="demo_edit").click().run()
        _healthy(at)
        assert at.text_input(key="demo_edit_label").value == original["label"]


def test_changed_saved_snapshot_keeps_edits_until_the_user_reloads():
    with _page() as (at, case):
        _prepare(at, "template", "bladder")
        identifier = at.session_state.demo_active_id
        at.button(key="demo_edit").click().run()
        at.text_input(key="demo_edit_label").set_value("Unsaved study review").run()
        folder = journeys._folder(ROOT, case.state_root, case.actor, identifier)
        saved = json.loads((folder / "rehearsal.json").read_text(encoding="utf-8"))
        saved["label"] = "Updated in another session"
        (folder / "rehearsal.json").write_text(json.dumps(saved), encoding="utf-8")
        at.button(key="demo_edit_save").click().run()
        _healthy(at)
        assert any("changed since the editor opened" in item.value for item in at.error)
        assert at.text_input(key="demo_edit_label").value == "Unsaved study review"
        assert at.session_state.demo_active_id == identifier
        assert len(journeys.list_runs(ROOT, case.state_root, case.actor)) == 1
        at.button(key="demo_edit_reload").click().run()
        _healthy(at)
        assert at.text_input(key="demo_edit_label").value == "Updated in another session"


def test_definition_editor_explains_how_to_write_and_review_the_literal_draft():
    import demo_revisions
    with _page() as (at, case):
        _prepare(at, "template", "bladder")
        identifier = at.session_state.demo_active_id
        saved = demo_revisions.read_editor(ROOT, case.state_root, case.actor, identifier)
        definition = saved["definitions"][0]
        at.button(key="demo_edit").click().run()
        _healthy(at)
        assert any(item.label == "How to write a draft definition" for item in at.expander)
        explanation = "\n".join(item.value for item in at.markdown)
        assert "which observation to use" in explanation and "timing relative to the study index date" in explanation
        assert "Illustrative example only" in explanation and "still need a scientific decision" in explanation
        assert any("saving a draft does not resolve it or approve the definition" in item.value for item in at.caption)
        assert any(item.value == definition["source_definition"] for item in at.text)
        assert at.text_area(key=_definition_widget(definition["key"])).value == definition["definition"]
        assert at.button(key="demo_edit_save").label == "Save revision"


@pytest.mark.parametrize("field", ["actor", "can_write", "local_demo", "can_view"])
def test_editor_context_change_cannot_save_stale_private_draft(field):
    import demo_revisions
    with _page() as (at, case):
        _prepare(at, "template", "bladder")
        original_actor = case.actor
        original_id = at.session_state.demo_active_id
        at.button(key="demo_edit").click().run()
        at.text_input(key="demo_edit_label").set_value("Private unsaved revision").run()
        setattr(case, field, "another_scientist" if field == "actor" else False)
        with patch.object(demo_revisions, "revise") as save:
            at.button(key="demo_edit_save").click().run()
        _healthy(at)
        save.assert_not_called()
        original = journeys.read_run(ROOT, case.state_root, original_actor, original_id)
        assert original["ok"] and original["run"]["stage"] == "prepared"
        assert len(journeys.list_runs(ROOT, case.state_root, original_actor)) == 1
        assert not any(item.key == "demo_edit_label" and item.value == "Private unsaved revision"
                       for item in at.text_input)


if __name__ == "__main__":
    raise SystemExit(run(globals()))
