"""The chat journey is held to the tree: every verb it advertises resolves to a tool that exists.

WHY THIS EXISTS. `docs/CHAT_JOURNEY.md` is the chat surface's vocabulary — thirty-plus "you type →
what runs" rows mapping stakeholder language onto owning tools, plus the seven skills. Nothing
held that map to the repository: a renamed or deleted tool would leave chat advertising a verb
that dead-ends, and the person typing it would conclude the journey itself is aspirational. The
rationale for this check puts it
as: the table is a promise, and a promise nothing verifies is documentation drift waiting to be
discovered by a stakeholder instead of by CI.

NO PYTEST FIXTURES AND NO parametrize — CI runs every suite as a script.

Run: python3 tests/test_chat_journey.py (or pytest).
"""
import re
import sys
from pathlib import Path

FRAMEWORK = Path(__file__).resolve().parent.parent
REPO = FRAMEWORK.parent
JOURNEY = REPO / "docs" / "CHAT_JOURNEY.md"

# Where an advertised tool may legitimately live. The doc names engine modules (outcomes.py) and
# the app (serve.py) as well as platform/tools — the point is that the NAME resolves, not that
# every name is a CLI.
SEARCH_ROOTS = ("platform/tools", "platform/engine", "platform/databricks", "platform/tests",
                "app", "platform/spec_pipeline")


def _named_tools():
    text = JOURNEY.read_text(encoding="utf-8")
    # `xxx.py` mentions only — prose words never match, and a .py name is precisely the kind of
    # reference that silently rots when a file moves.
    return sorted(set(re.findall(r"\b([a-z_][a-z0-9_]*\.py)\b", text))), text


def test_every_tool_the_journey_names_exists_in_the_tree():
    """A verb that routes to a missing tool is a dead end wearing a promise. Checked by NAME
    across every root a tool may live in, because the journey names engine modules and the app
    as well as platform/tools."""
    names, _text = _named_tools()
    assert len(names) >= 25, (
        "the journey names almost no tools — either the doc was gutted or this scan has stopped "
        "seeing the references it exists to check", names)
    present = set()
    for root in SEARCH_ROOTS:
        for p in (REPO / root).rglob("*.py"):
            present.add(p.name)
    missing = [n for n in names if n not in present]
    assert not missing, (
        "docs/CHAT_JOURNEY.md advertises tools that do not exist in the tree — a stakeholder "
        "typing these verbs hits a dead end: " + ", ".join(missing))


def test_every_skill_is_in_the_journey_and_the_journey_invents_no_skill():
    """Both directions, because each fails differently. A skill missing from the journey is a
    capability nobody discovers; a skill the journey names that has no directory is chat
    advertising a workflow that cannot load."""
    _names, text = _named_tools()
    on_disk = sorted(d.name for d in (REPO / ".claude" / "skills").iterdir() if d.is_dir())
    assert len(on_disk) >= 5, ("the skills directory is nearly empty — nothing to hold", on_disk)
    not_documented = [s for s in on_disk if s not in text]
    assert not not_documented, (
        "these skills exist and the journey never mentions them — a capability nobody can "
        "discover from the doc that exists to be the map: " + ", ".join(not_documented))
    claimed = set(re.findall(r"`([a-z][a-z0-9-]*(?:-[a-z0-9]+)+)`", text))
    phantom = sorted(c for c in claimed
                     if c.endswith(("-decisions", "-verdicts", "-record", "-cut", "-product",
                                    "-mapping", "-name")) and c not in on_disk)
    assert not phantom, (
        "the journey names skill-shaped workflows that have no directory: " + ", ".join(phantom))


def test_the_proposal_feature_is_advertised_where_the_verbs_live():
    """The decision packet now carries labelled proposals (exactly one product ruled → adopt or
    edit). A feature the journey does not mention is one its audience never asks for — and the
    journey row for the asking verb is where its audience looks."""
    _names, text = _named_tools()
    assert "proposal" in text.lower(), (
        "the journey's answer-decisions row says nothing about labelled proposals — the feature "
        "exists and its audience cannot discover it")


if __name__ == "__main__":
    # CI RUNS EVERY SUITE AS A SCRIPT — without this block the file runs no tests and exits 0.
    fns = [v for k, v in sorted(globals().items()) if k.startswith("test_") and callable(v)]
    bad = 0
    for fn in fns:
        try:
            fn()
            print(f"  ok  {fn.__name__}")
        except Exception as e:                       # noqa: BLE001 - report and continue
            bad += 1
            print(f"FAIL  {fn.__name__}: {e}")
    print(f"\n{len(fns) - bad} of {len(fns)} passed")
    sys.exit(1 if bad else 0)
