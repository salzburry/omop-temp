"""Actual Git line-ending conversion changes no handoff intent or approval authority."""
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[2]
sys.path[:0] = [str(ROOT / p) for p in ("platform/tests", "experiments/portal")]
from test_epi_configuration_proposals import ACTOR, PACK, seed, stage
import configuration_proposals as cp
import design_workspace as dw


def git(root, *args):
    result = subprocess.run(["git", "-C", str(root), *args], capture_output=True, timeout=60)
    assert result.returncode == 0, result.stderr.decode(errors="replace")
    return result.stdout


def test_real_autocrlf_clone_restages_against_new_raw_bytes_without_imported_checks(tmp_path):
    source = tmp_path / "source"
    source.mkdir()
    seed(source)
    for file in (source / PACK).rglob("*"):
        if file.is_file() and file.suffix in {".md", ".yaml", ".yml", ".json"}:
            file.write_bytes(file.read_bytes().replace(b"\r\n", b"\n"))
    staged = stage(source)
    preview = cp.share_preview(source, PACK, proposal_id=staged["proposal_id"], actor_id=ACTOR, allowed_packs=[PACK])
    assert preview["ok"], preview
    shared = cp.share(source, PACK, proposal_id=staged["proposal_id"], actor_id=ACTOR, expected_digest=preview["digest"],
        confirmed=True, local_demo=True, can_write=True, allowed_packs=[PACK])
    assert shared["ok"], shared
    git(source, "init", "-b", "codex/transport-test")
    git(source, "config", "user.name", "Synthetic branch author")
    git(source, "config", "user.email", "branch@example.test")
    git(source, "config", "commit.gpgsign", "false")
    git(source, "config", "core.hooksPath", str(tmp_path / "no-hooks"))
    git(source, "config", "core.autocrlf", "input")
    (source / ".gitignore").write_text("**/.portal-drafts/\n__pycache__/\n", encoding="utf-8")
    git(source, "add", ".")
    git(source, "commit", "-m", "Synthetic portable proposal")
    reader = tmp_path / "reader"
    git(source, "-c", "core.autocrlf=true", "clone", "--no-local", str(source), str(reader))
    assert not (reader / PACK / ".portal-drafts").exists()
    current_raw = dw.describe(reader, PACK)["baseline_sha256"]
    assert current_raw != staged["proposal"]["baseline_sha256"]
    loaded = cp.load_shared(reader, PACK, packet_id=shared["packet_id"], actor_id="Branch reviewer", allowed_packs=[PACK])
    assert loaded["ok"] and not loaded["stale"] and loaded["line_endings_changed"], loaded
    common = dict(packet_id=shared["packet_id"], actor_id="Branch reviewer", expected_digest=loaded["digest"],
        confirmed=True, local_demo=True, can_write=True, allowed_packs=[PACK])
    assert not cp.restage_shared(reader, PACK, expected_baseline=staged["proposal"]["baseline_sha256"], **common)["ok"]
    restaged = cp.restage_shared(reader, PACK, expected_baseline=current_raw, **common)
    assert restaged["ok"], restaged
    result = cp.load(reader, PACK, proposal_id=restaged["proposal_id"], actor_id="Branch reviewer", allowed_packs=[PACK])
    assert result["proposal"]["baseline_sha256"] == current_raw
    assert result["validation"] is result["submission"] is None and not result["can_submit"]
    for file in result["proposal"]["files"]:
        assert file["before"].encode() == (reader / PACK / file["path"]).read_bytes()
    contract = reader / PACK / "handoff/FUNCTIONAL_CONTRACT.md"
    contract.write_bytes(contract.read_bytes() + b"\r\nA changed interpretation.\r\n")
    assert cp.load_shared(reader, PACK, packet_id=shared["packet_id"], actor_id="Branch reviewer", allowed_packs=[PACK])["stale"]
    assert not cp.restage_shared(reader, PACK, expected_baseline=dw.describe(reader, PACK)["baseline_sha256"], **common)["ok"]


def test_branch_text_baseline_preserves_whitespace_types_file_sets_and_binary_bytes(tmp_path):
    seed(tmp_path)
    product = tmp_path / PACK
    config = product / "config/data_product.yaml"
    first = cp._branch_text_baseline(tmp_path, product, PACK)
    raw = config.read_bytes()
    config.write_bytes(raw.replace(b"\r\n", b"\n").replace(b"\n", b"\r\n"))
    assert cp._branch_text_baseline(tmp_path, product, PACK) == first
    config.write_bytes(raw + b" \n")
    assert cp._branch_text_baseline(tmp_path, product, PACK) != first
    config.write_bytes(raw)
    additional = product / "config/another.yaml"
    additional.write_bytes(b"value: 1\n")
    assert cp._branch_text_baseline(tmp_path, product, PACK) != first
    number = cp._branch_text_baseline(tmp_path, product, PACK)
    additional.write_bytes(b"value: '1'\n")
    assert cp._branch_text_baseline(tmp_path, product, PACK) != number
    additional.write_bytes(b"\x00raw\r\n")
    binary = cp._branch_text_baseline(tmp_path, product, PACK)
    additional.write_bytes(b"\x00raw\n")
    assert cp._branch_text_baseline(tmp_path, product, PACK) != binary
