"""Branch handoffs use existing Plan/Review pages and explicitly fresh local proposals."""
from pathlib import Path
import shutil
import sys

from streamlit.testing.v1 import AppTest

ROOT = Path(__file__).resolve().parents[2]
sys.path[:0] = [str(ROOT / p) for p in ("platform/tests", "experiments/portal")]
from test_epi_configuration_proposals import ACTOR, PACK, seed, stage
import configuration_proposals as cp


def make(root):
    root.mkdir()
    seed(root)
    result = stage(root)
    assert result["ok"], result
    return result


def healthy(at):
    assert not at.exception, [item.message for item in at.exception]


def button(at, label):
    return next(item for item in at.button if item.label == label)


def open_shared(at, root, actor, suffix):
    import configuration_proposal_page as page
    key = page._shared_key(root, PACK, actor, True, True, [PACK], suffix) + "_open"
    at.session_state[key] = True
    at.run()
    healthy(at)


def retain_open(at, root, actor, suffix):
    # Streamlit 1.62 AppTest exposes Expander as a Block and does not serialize
    # its new bool widget state when sending a different widget's change.
    import configuration_proposal_page as page
    at.session_state[page._shared_key(root, PACK, actor, True, True, [PACK], suffix) + "_open"] = True


def test_share_requires_review_and_copies_only_the_exact_selected_packet(tmp_path):
    root = tmp_path / "source"
    staged = make(root)
    script = f"""
import sys
sys.path.insert(0, {str(ROOT / 'experiments/portal')!r})
import configuration_proposal_page as page
page._share_current({str(root)!r}, {PACK!r}, {staged['proposal_id']!r}, {ACTOR!r}, local_demo=True, can_write=True, allowed_packs={[PACK]!r})
"""
    at = AppTest.from_string(script, default_timeout=45).run()
    healthy(at)
    assert button(at, "Save proposal handoff").disabled
    assert not cp.list_shared(root, PACK, actor_id=ACTOR, allowed_packs=[PACK])["records"]
    at.checkbox[0].check().run()
    button(at, "Save proposal handoff").click().run()
    healthy(at)
    assert any("Save work to my branch" in item.value for item in at.success)
    records = cp.list_shared(root, PACK, actor_id=ACTOR, allowed_packs=[PACK])["records"]
    assert len(records) == 1
    assert not cp.load(root, PACK, proposal_id=staged["proposal_id"], actor_id=ACTOR, allowed_packs=[PACK])["stale"]


def test_both_existing_pages_surface_a_shared_handoff_and_restage_without_authority(tmp_path):
    source = tmp_path / "source"
    staged = make(source)
    preview = cp.share_preview(source, PACK, proposal_id=staged["proposal_id"], actor_id=ACTOR, allowed_packs=[PACK])
    saved = cp.share(source, PACK, proposal_id=staged["proposal_id"], actor_id=ACTOR,
        expected_digest=preview["digest"], confirmed=True, local_demo=True, can_write=True, allowed_packs=[PACK])
    assert saved["ok"], saved
    root = tmp_path / "reader"
    shutil.copytree(source, root, ignore=shutil.ignore_patterns(".portal-drafts", "__pycache__"))
    actor = "Second scientist"
    script = f"""
import sys
sys.path.insert(0, {str(ROOT / 'experiments/portal')!r})
import streamlit as st
import plan_changes_page, review_inbox_page
screen = st.radio('Test screen', ['Plan changes', 'Review requests'])
if screen == 'Plan changes':
    plan_changes_page.render({str(root)!r}, {PACK!r}, actor_id={actor!r}, local_demo=True, can_write=True, allowed_packs={[PACK]!r})
else:
    review_inbox_page.render({str(root)!r}, {PACK!r}, {actor!r}, local_demo=True, can_write=True, can_review=True, allowed_packs={[PACK]!r}, route='review_inbox')
"""
    at = AppTest.from_string(script, default_timeout=45).run()
    healthy(at)
    open_shared(at, root, actor, "plan")
    assert button(at, "Restage this handoff here").disabled
    assert any(item.label == "Proposal handoffs saved in this branch" for item in at.expander)
    at.radio[0].set_value("Review requests").run()
    healthy(at)
    open_shared(at, root, actor, "inbox")
    assert button(at, "Restage this handoff here").disabled
    assert not any(item.label == "Accept" for item in at.button)
    assert any("historical" in item.value.lower() for item in at.info)
    retain_open(at, root, actor, "inbox")
    next(item for item in at.checkbox if "new local proposal" in item.label).check().run()
    retain_open(at, root, actor, "inbox")
    button(at, "Restage this handoff here").click().run()
    healthy(at)
    rows = cp.list_proposals(root, PACK, actor_id=actor, allowed_packs=[PACK])["proposals"]
    assert len(rows) == 1
    loaded = cp.load(root, PACK, proposal_id=rows[0]["proposal_id"], actor_id=actor, allowed_packs=[PACK])
    assert loaded["ok"] and loaded["validation"] is None and loaded["submission"] is None and not loaded["can_submit"]
    assert not cp.list_proposals(root, PACK, actor_id=ACTOR, allowed_packs=[PACK])["proposals"]
