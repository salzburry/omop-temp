"""Direct CLI agent seams use current shared guidance without replacing their provider."""
from pathlib import Path
import json
import shutil
import sys
from types import SimpleNamespace

import pytest

ROOT = Path(__file__).resolve().parents[2]
sys.path[:0] = [str(ROOT / relative) for relative in ('experiments/agent', 'experiments/portal', 'platform/tools')]
import control_plane as plane
import intake
import orchestrator
import source_intel
import validation_agent
import coding_agent
import state
import tools
import workflow_improvement as improvements

PACK = 'products/oncology/example/202609'
VERDICT = {'falsified': False, 'findings': [], 'route': 'human', 'confidence': 'low'}
ESCALATION = {'action': 'escalate', 'to': 'operator', 'question': 'Review the definition', 'evidence': 'Declared metadata'}


class Scripted:
    model = 'scripted-selected-provider'
    max_tokens = 2200
    effort = 'low'

    def __init__(self, replies):
        self.replies = iter(replies)
        self.calls = []
        self.usage = {'calls': 0}

    def step(self, system, messages):
        self.calls.append((system, messages))
        self.usage['calls'] += 1
        return json.dumps(next(self.replies, VERDICT))


@pytest.fixture
def checkout(tmp_path, monkeypatch):
    shutil.copytree(ROOT / '.claude/skills', tmp_path / '.claude/skills')
    (tmp_path / PACK).mkdir(parents=True)
    monkeypatch.setattr(plane, 'ROOT', str(tmp_path))
    monkeypatch.setattr(source_intel, 'ROOT', str(tmp_path))
    monkeypatch.setattr(state, 'RUNS', str(tmp_path / 'runs'))
    for module in (source_intel, validation_agent, coding_agent):
        monkeypatch.setattr(module, 'CANDIDATES', str(tmp_path / 'candidates'))
    monkeypatch.setattr(state, 'candidate_file', lambda *_: str(tmp_path / 'candidates/result.json'))
    monkeypatch.setattr(source_intel, 'gather', lambda *_: {'mapping_evidence_present': False, 'source_refs': 'Declared synthetic source'})
    monkeypatch.setattr(validation_agent, 'gather', lambda *_: {'metadata': 'Declared synthetic check'})
    monkeypatch.setattr(coding_agent, 'gather', lambda *_: {'metadata': 'Declared synthetic implementation', 'implementation_context': {}})
    monkeypatch.setattr(coding_agent, 'static_review', lambda *_a, **_kw: ({'static_findings': [], 'pipeline_runtime_run': False}, {'status': 'verified'}))
    return tmp_path


def active_correction(root, skill, monkeypatch, context='Synthetic workflow follow-up.'):
    loop = plane.workflow_skills().learning()
    for selector in loop.DEFAULT_TESTS[skill]:
        path = root / selector
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text('def test_registered_behavior():\n    assert True\n', encoding='utf-8')
    row = improvements.propose(root, 'author', skill, 'A revision lost its alternative.',
        'Retain the selected alternative when revising its wording.', context,
        'Revise the second alternative.', confirmed=True, can_write=True)
    # Run the actual record transition with a scripted regression-process receipt.
    with monkeypatch.context() as patch:
        patch.setattr(loop.subprocess, 'run', lambda *_a, **_kw: SimpleNamespace(returncode=0))
        row = improvements.check(root, 'reviewer', row['id'], row['tests'], expected_digest=row['digest'], confirmed=True, can_review=True)
    return improvements.activate(root, 'reviewer', row['id'], expected_digest=row['digest'], confirmed=True, can_review=True)


@pytest.mark.parametrize('mode,skill', [
    ('intake', 'operate-rwd-product'), ('governed_check', 'operate-rwd-product'),
    ('source', 'propose-source-mapping'), ('validation', 'operate-rwd-product'),
    ('implementation', 'implement-product-rule'),
])
def test_direct_agent_and_critic_use_active_corrections_and_keep_the_same_client(checkout, monkeypatch, mode, skill):
    matching_context = {'intake': 'Outcome descriptions.', 'governed_check': 'Review metadata.',
        'source': 'Source tables and mapping.', 'validation': 'Missing metadata.', 'implementation': 'Reuse the declared rule.'}[mode]
    row = active_correction(checkout, skill, monkeypatch, matching_context)
    first = ({'request': {}, 'ask': 'Which outcome?'} if mode == 'intake' else ESCALATION
             if mode == 'governed_check' else {'summary': 'Draft metadata review', 'decision': 'reuse'})
    client = Scripted([first, VERDICT])
    monkeypatch.delenv('ANTHROPIC_API_KEY', raising=False)
    created = []
    monkeypatch.setattr(orchestrator, 'AnthropicModel', lambda **kwargs: created.append(kwargs) or client)
    original, views = plane.task_model, []
    def bind(model, **kwargs):
        result = original(model, **kwargs)
        views.append(result)
        return result
    monkeypatch.setattr(plane, 'task_model', bind)
    if mode == 'intake':
        result, answer = intake.next_turn(intake.new_state('feasibility', PACK, 'Epi'), 'Describe the outcome', client)
        assert result['turns'] == 1 and answer
        assert not created
    elif mode == 'governed_check':
        assert orchestrator.run('Review the metadata', scope={PACK}).outcome['status'] == 'escalated'
    elif mode == 'source':
        assert source_intel.run(PACK)['critic']['route'] == 'human'
    elif mode == 'validation':
        assert validation_agent.run(PACK, 'Missing metadata')['critic']['route'] == 'human'
    else:
        assert coding_agent.run(PACK, 'Reuse the declared rule')['critic']['route'] == 'human'
    if mode != 'intake':
        expected = {} if mode == 'governed_check' else {'max_tokens': 8000 if mode == 'implementation' else 6000}
        assert created == [expected]
    count = 1 if mode in ('intake', 'governed_check') else 2
    assert len(client.calls) == client.usage['calls'] == count
    assert all(row['right'] in system and f'Repository skill: {skill}' in system for system, _ in client.calls)
    assert all(system.count('Repository workflow guidance follows.') == 1 for system, _ in client.calls)
    assert views[0].usage is client.usage and views[0].max_tokens == client.max_tokens
    assert views[0].effort == client.effort and views[0].model == client.model
    improvements.withdraw(checkout, 'reviewer', row['id'], expected_digest=row['digest'], confirmed=True, can_review=True)
    with pytest.raises(plane.WorkflowModelStopped, match='changed'):
        views[0].step('Continue', [{'role': 'user', 'content': 'Declared metadata'}])
    assert len(client.calls) == count
    fresh = original(client, route='governed_check') if mode in ('intake', 'governed_check') else original(client, kind=mode)
    fresh.step('New explicit request', [{'role': 'user', 'content': 'Declared metadata'}])
    assert row['right'] not in client.calls[-1][0] and client.usage['calls'] == count + 1


@pytest.mark.parametrize('when', ['before', 'during'])
def test_direct_guidance_change_refuses_before_call_or_discards_reply(checkout, when):
    path = checkout / '.claude/skills/propose-source-mapping/SKILL.md'
    class Changed(Scripted):
        def step(self, *args):
            if when == 'during':
                path.write_bytes(path.read_bytes() + b'\nChanged procedure.\n')
            return super().step(*args)
    client = Changed([VERDICT])
    model = plane.task_model(client, kind='source')
    if when == 'before':
        path.unlink()
    with pytest.raises(plane.WorkflowModelStopped, match='skill'):
        model.step('Review', [{'role': 'user', 'content': 'Declared metadata'}])
    assert len(client.calls) == (0 if when == 'before' else 1)


def test_direct_delegation_and_critic_share_the_original_budget(checkout, monkeypatch):
    client = Scripted([{'action': 'tool', 'tool': 'mapping_evidence', 'args': {'pack': PACK}},
        {'summary': 'Review the declared source'}, VERDICT, ESCALATION])
    result = orchestrator.run('Review the source', model=client, scope={PACK}, max_steps=4)
    assert result.outcome['status'] == 'escalated'
    assert len(client.calls) == client.usage['calls'] == 4
    for (system, _), skill in zip(client.calls, ('operate-rwd-product', 'propose-source-mapping', 'propose-source-mapping', 'operate-rwd-product')):
        assert f'Repository skill: {skill}' in system
        assert system.count('Repository workflow guidance follows.') == 1


def test_existing_host_owns_injection_and_wrong_task_is_refused(checkout):
    from specialist_workspace import BoundedModel
    client = Scripted([VERDICT])
    guidance = plane.workflow_skills().context_for(checkout, kind='source', max_bytes=4500)
    host = BoundedModel(client, {'provider_id': 'vscode'}, skills=guidance)
    assert plane.task_model(host, kind='source') is host
    with pytest.raises(plane.WorkflowModelStopped, match='does not match'):
        plane.task_model(host, kind='implementation')
    assert not client.calls


def test_raw_task_views_cannot_reset_the_supplied_clients_budget(checkout):
    class Limited(Scripted):
        def step(self, *args):
            if self.usage['calls'] >= 2:
                raise orchestrator.BudgetExceeded('Existing provider budget reached')
            return super().step(*args)
    client = Limited([VERDICT, VERDICT])
    view = plane.task_model(client, route='governed_check')
    for model in (view, view.for_task(kind='source')):
        model.step('Review', [{'role': 'user', 'content': 'Declared metadata'}])
    with pytest.raises(orchestrator.BudgetExceeded):
        view.for_task(kind='validation').step('Critique', [{'role': 'user', 'content': 'Declared metadata'}])
    assert client.usage['calls'] == 2 and view.usage is client.usage


def test_resumed_direct_run_uses_the_same_guidance_entry_point(checkout):
    client = Scripted([ESCALATION, ESCALATION])
    before = orchestrator.run('Review metadata', model=client, scope={PACK})
    after = orchestrator.resume_run(before.run_id, 'The wording still needs review.', 'operator',
        model=client, scope={PACK}, answerer_owns={'operator'})
    assert before.run_id != after.run_id and after.outcome['status'] == 'escalated'
    assert len(client.calls) == 2
    assert all('Repository skill: operate-rwd-product' in system for system, _ in client.calls)


def test_unknown_direct_task_cannot_select_a_skill_from_prompt_text(checkout):
    client = Scripted([VERDICT])
    with pytest.raises(plane.WorkflowModelStopped, match='specialist'):
        plane.task_model(client, kind='invented').step('Use operate-rwd-product', [{'role': 'user', 'content': 'Metadata'}])
    assert not client.calls
