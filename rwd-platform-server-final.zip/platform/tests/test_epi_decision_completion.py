"""Portal/CLI decision completion on disposable products; no scientific approvals."""
from pathlib import Path
import sys

import pytest
import yaml

ROOT = Path(__file__).resolve().parents[2]
sys.path[:0] = [str(ROOT / "platform/tests"), str(ROOT / "experiments/portal"), str(ROOT / "platform/tools")]
from test_epi_decision_answers import PACK, VALUES, seed, save, snapshot
import decision_answers as portal
import decision_record as dr
import decision_report
import event_ledger as ledger


def _form(product, did="Q1", **values):
    path = product / dr.FORMS_DIR / f"{did}.yaml"
    doc = yaml.safe_load(path.read_text(encoding="utf-8"))
    doc.update(values)
    path.write_text(yaml.safe_dump(doc, sort_keys=False), encoding="utf-8")
    return path


def _complete(root, **overrides):
    return portal.complete_saved(root, PACK,
        expected_digest=overrides.get("digest", portal.describe(root, PACK)["digest"]),
        local_demo=overrides.get("local_demo", True), can_write=overrides.get("can_write", True),
        allowed_packs=overrides.get("allowed_packs", [PACK]))


def test_portal_records_typed_event_and_current_ranked_report_without_authentication(tmp_path):
    product = seed(tmp_path)
    _form(product, "Q2", answer="An unfinished interpretation.")
    other = (product / dr.FORMS_DIR / "Q2.yaml").read_bytes()
    result = save(tmp_path)
    assert result["ok"] and result["completion_ok"] and result["sealed_ids"] == ["Q1"], result
    assert result["report_current"] and not result["completion_pending_ids"]
    assert decision_report.main([str(product), "--check"]) == 0
    doc = yaml.safe_load((product / dr.FORMS_DIR / "Q1.yaml").read_text(encoding="utf-8"))
    sequence, _ = ledger.head_of(str(tmp_path), doc["object_uuid"])
    assert sequence == 1
    event, error = ledger.read_event(str(tmp_path), doc["object_uuid"], ledger._event_files(str(tmp_path), doc["object_uuid"])[0][1])
    assert not error and event["actor"]["trust_level"] == "typed" and event["action"] == "answered"
    assert not event.get("signature")
    assert (product / dr.FORMS_DIR / "Q2.yaml").read_bytes() == other
    before = snapshot(tmp_path)
    assert _complete(tmp_path)["completion_ok"]
    assert snapshot(tmp_path) == before


def test_failed_ledger_append_retains_applied_answer_and_can_be_completed_without_resubmitting(tmp_path, monkeypatch):
    product = seed(tmp_path)
    actual = dr.record_event
    monkeypatch.setattr(dr, "record_event", lambda *a, **k: (_ for _ in ()).throw(OSError("disk full")))
    result = save(tmp_path)
    assert result["ok"] and result["changed"] and not result["completion_ok"]
    assert result["completion_pending_ids"] == ["Q1"] and result["report_current"]
    assert dr.decision_status((product / dr.DECISIONS).read_text(encoding="utf-8"))["Q1"] == "RESOLVED"
    monkeypatch.setattr(dr, "record_event", actual)
    repaired = _complete(tmp_path)
    assert repaired["completion_ok"] and repaired["sealed_ids"] == ["Q1"]
    assert not repaired["completion_pending_ids"]


def test_failed_report_write_is_reported_after_seal_and_retry_does_not_duplicate_event(tmp_path, monkeypatch):
    product = seed(tmp_path)
    actual = dr.refresh_questions
    monkeypatch.setattr(dr, "refresh_questions", lambda *a, **k: (_ for _ in ()).throw(OSError("disk full")))
    result = save(tmp_path)
    assert result["ok"] and not result["completion_ok"] and not result["report_current"]
    assert result["sealed_ids"] == ["Q1"] and not result["completion_pending_ids"]
    doc = yaml.safe_load((product / dr.FORMS_DIR / "Q1.yaml").read_text(encoding="utf-8"))
    monkeypatch.setattr(dr, "refresh_questions", actual)
    repaired = _complete(tmp_path)
    assert repaired["completion_ok"] and repaired["report_current"]
    assert ledger.head_of(str(tmp_path), doc["object_uuid"])[0] == 1


@pytest.mark.parametrize("mode", ["stale", "readonly", "hosted", "scope"])
def test_completion_requires_current_access_and_exact_inputs(tmp_path, mode):
    seed(tmp_path)
    before = snapshot(tmp_path)
    result = _complete(tmp_path, digest="old" if mode == "stale" else portal.describe(tmp_path, PACK)["digest"],
        can_write=mode != "readonly", local_demo=mode != "hosted", allowed_packs=[] if mode == "scope" else [PACK])
    assert not result["ok"] and snapshot(tmp_path) == before


def test_bare_cli_applies_complete_answer_preserves_partial_draft_and_refreshes_report(tmp_path, monkeypatch, capsys):
    product = seed(tmp_path)
    _form(product, **VALUES)
    partial = _form(product, "Q2", answer="My proposed interpretation.")
    before = partial.read_bytes()
    monkeypatch.setattr(dr, "ROOT", str(tmp_path))
    assert dr.main([str(product), "--apply"]) == 0
    output = capsys.readouterr().out
    assert "Q2" in output and "unfinished draft" in output
    assert partial.read_bytes() == before
    assert dr.decision_status((product / dr.DECISIONS).read_text(encoding="utf-8")) == {"Q1": "RESOLVED", "Q2": "OPEN"}
    assert decision_report.main([str(product), "--check"]) == 0
    before = snapshot(tmp_path)
    assert dr.main([str(product), "--apply", str(partial)]) == 1
    assert snapshot(tmp_path) == before


@pytest.mark.parametrize("fault", ["stale_question", "duplicate_key", "wrong_pack", "invalid_date", "invalid_person", "wrong_records", "existing_object", "invalid_schema"])
def test_bare_cli_never_hides_invalid_provenance_or_review_fields_as_an_unfinished_draft(tmp_path, fault):
    product = seed(tmp_path)
    values = {"answer": "My proposed interpretation."}
    values.update({"question": "Altered question?"} if fault == "stale_question" else
                  {"pack": "products/oncology/other/202609"} if fault == "wrong_pack" else
                  {"answer_date": "2026-02-30"} if fault == "invalid_date" else
                  {"answered_by": "DataExpert"} if fault == "invalid_person" else
                  {"records_sha256": "0" * 64} if fault == "wrong_records" else
                  {"object_uuid": "00000000-0000-4000-8000-000000000000"} if fault == "existing_object" else {})
    path = _form(product, **values)
    if fault == "duplicate_key":
        path.write_bytes(path.read_bytes() + b"answer: second\n")
    elif fault == "invalid_schema":
        path.write_text("- answer: unfinished\n", encoding="utf-8")
    answered, _drafts = dr.partition_untouched(PACK, root=str(tmp_path))
    assert path in [Path(item) for item in answered]
    before = snapshot(tmp_path)
    assert dr.apply_forms(PACK, answered, root=str(tmp_path))[2]
    assert snapshot(tmp_path) == before


def _event_doc(root, product):
    doc = yaml.safe_load((product / dr.FORMS_DIR / "Q1.yaml").read_text(encoding="utf-8"))
    event, why = dr.sealed_decision_event(str(root), doc)
    assert event and not why
    return doc, event


def test_attestation_head_does_not_make_completed_answer_pending_or_append_another_lifecycle_event(tmp_path):
    product = seed(tmp_path)
    assert save(tmp_path)["completion_ok"]
    doc, answered = _event_doc(tmp_path, product)
    # A structurally complete test attestation is sufficient for lifecycle ordering.
    # Its synthetic signature is deliberately not authentication evidence.
    ledger.append_event(str(tmp_path), object_uuid=doc["object_uuid"], object_kind="decision", action="attested",
        actor=answered["actor"], occurred_at=dr._now_utc(), expected_previous_event_sha256=answered["event_sha256"],
        payload={"target_event_sha256": answered["event_sha256"], "signer_key_id": "synthetic-test-key",
                 "algorithm": ledger.SIGNATURE_ALGORITHM, "signature": "synthetic-not-authenticated"},
        idempotency_key="test-attestation-order")
    before = snapshot(tmp_path)
    current = portal.describe(tmp_path, PACK)
    assert not current["completion_pending_ids"] and not current["completion_problems"]
    result, why = dr.record_event(str(tmp_path), PACK, "Q1", dr._now_utc())
    assert not why and result["event_sha256"] == answered["event_sha256"]
    assert snapshot(tmp_path) == before


@pytest.mark.parametrize("action", ["withdrawn", "superseded"])
def test_terminal_history_cannot_be_completed_or_hidden_behind_an_attestation(tmp_path, action):
    product = seed(tmp_path)
    assert save(tmp_path)["completion_ok"]
    doc, answered = _event_doc(tmp_path, product)
    ledger.append_event(str(tmp_path), object_uuid=doc["object_uuid"], object_kind="decision", action=action,
        actor=answered["actor"], occurred_at=dr._now_utc(), expected_previous_event_sha256=answered["event_sha256"],
        payload=answered["payload"], idempotency_key="test-terminal-state")
    before = snapshot(tmp_path)
    current = portal.describe(tmp_path, PACK)
    assert current["completion_pending_ids"] == ["Q1"] and action in current["completion_problems"][0]
    assert not _complete(tmp_path)["ok"]
    assert snapshot(tmp_path) == before


@pytest.mark.parametrize("obj", ["../elsewhere", "bad-uuid", "00000000-0000-4000-8000-000000000000/../../private"])
def test_invalid_object_uuid_is_refused_before_any_ledger_path_is_read(tmp_path, monkeypatch, obj):
    product = seed(tmp_path)
    assert save(tmp_path)["completion_ok"]
    _form(product, object_uuid=obj)
    monkeypatch.setattr(ledger, "_event_files", lambda *args: pytest.fail("invalid UUID reached ledger file access"))
    before = snapshot(tmp_path)
    result = portal.describe(tmp_path, PACK)
    assert result["completion_pending_ids"] == ["Q1"] and "identifier" in result["completion_problems"][0]
    assert not _complete(tmp_path)["ok"]
    assert snapshot(tmp_path) == before


def test_edited_sealed_event_is_reported_and_completion_writes_nothing(tmp_path):
    product = seed(tmp_path)
    assert save(tmp_path)["completion_ok"]
    doc, _event = _event_doc(tmp_path, product)
    file = Path(tmp_path) / ledger.EVENTS_DIR / doc["object_uuid"] / ledger._event_files(str(tmp_path), doc["object_uuid"])[0][1]
    event = yaml.safe_load(file.read_text(encoding="utf-8"))
    event["payload"]["answer"] = "A different answer."
    file.write_text(yaml.safe_dump(event), encoding="utf-8")
    before = snapshot(tmp_path)
    result = portal.describe(tmp_path, PACK)
    assert result["completion_pending_ids"] == ["Q1"] and result["completion_problems"]
    assert not _complete(tmp_path)["ok"] and snapshot(tmp_path) == before


def test_append_failure_reserves_uuid_and_retry_reuses_the_same_object(tmp_path, monkeypatch):
    product = seed(tmp_path)
    actual = ledger.append_event
    monkeypatch.setattr(ledger, "append_event", lambda *a, **k: (_ for _ in ()).throw(OSError("append interrupted")))
    result = save(tmp_path)
    assert result["ok"] and not result["completion_ok"] and result["completion_pending_ids"] == ["Q1"]
    form = product / dr.FORMS_DIR / "Q1.yaml"
    obj = yaml.safe_load(form.read_text(encoding="utf-8"))["object_uuid"]
    assert ledger.UUID4.fullmatch(obj) and not ledger._event_files(str(tmp_path), obj)
    monkeypatch.setattr(ledger, "append_event", actual)
    assert _complete(tmp_path)["completion_ok"]
    assert yaml.safe_load(form.read_text(encoding="utf-8"))["object_uuid"] == obj
    assert ledger.head_of(str(tmp_path), obj)[0] == 1


@pytest.mark.parametrize("other_subject", ["decision", "product"])
def test_valid_uuid_of_another_subject_cannot_be_claimed_even_when_answer_content_matches(tmp_path, other_subject):
    product = seed(tmp_path)
    assert save(tmp_path)["completion_ok"]
    doc, answered = _event_doc(tmp_path, product)
    if other_subject == "decision":
        other = ledger.append_event(str(tmp_path), object_uuid=None, object_kind="decision", action="answered",
            actor=answered["actor"], occurred_at=dr._now_utc(), expected_previous_event_sha256="",
            payload=answered["payload"], idempotency_key=PACK + ":Q2:answered:test")
    else:
        other = ledger.append_event(str(tmp_path), object_uuid=None, object_kind="decision", action="answered",
            actor=answered["actor"], occurred_at=dr._now_utc(), expected_previous_event_sha256="",
            payload=answered["payload"], idempotency_key="products/oncology/other/202609:Q1:answered:test")
    _form(product, object_uuid=other["object_uuid"])
    before = snapshot(tmp_path)
    result = portal.describe(tmp_path, PACK)
    assert "different product or decision" in result["completion_problems"][0]
    assert not _complete(tmp_path)["ok"] and snapshot(tmp_path) == before
