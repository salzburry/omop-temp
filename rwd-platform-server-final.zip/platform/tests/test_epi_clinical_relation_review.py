"""Canonical relation evidence and product-set proposals in the science workbench."""
from pathlib import Path
import copy
import json
import sys

import pytest
from streamlit.testing.v1 import AppTest
import yaml

ROOT = Path(__file__).resolve().parents[2]
sys.path[:0] = [str(ROOT / "experiments/portal"), str(ROOT / "platform/tools"), str(ROOT / "platform/tests")]
import clinical_relation_review as review
import science_workspace as science
import science_workspace_page as page

PACK = "fixtures/oncology/prostate/202606"
ACTOR = "relation-reviewer"


def layer():
    return {"layer": review.relations.LAYER, "release": "synthetic-relation-1",
        "concepts": {"C1111111": "Example prostate carcinoma", "C2222222": "Parked carcinoma",
                     "C3333333": "Example gene", "C4444444": "Possible gene"},
        "diseases": {"C1111111": [{"cui": "C3333333", "axis": "gene", "modality": "asserted",
            "modalities": ["asserted", "refuted"], "conflict": True, "rela": ["disease_has_associated_gene"], "sab": ["NCI"]}],
            "C2222222": [{"cui": "C4444444", "axis": "gene", "modality": "possible", "modalities": ["possible"],
                "conflict": False, "rela": ["disease_has_associated_gene"], "sab": ["NCI"]}]},
        "counts": {"diseases_with_partners": 2, "edges": 2, "edges_asserted": 1, "edges_possible": 1, "edges_refuted": 1}}


def sets():
    return {"assertions": [], "concept_sets": [{"name": "example_population",
        "concepts": [{"cui": "C1111111", "status": "active"}, {"cui": "C2222222", "status": "deprecated"}],
        "basis": "Synthetic scoping example; retain the historical member visibly.", "citation": "Synthetic protocol section 2",
        "asserted_by": "Example Scientist", "asserted_on": "2026-09-07"}]}


@pytest.fixture
def relation_reader(tmp_path, monkeypatch):
    path = tmp_path / "LOCAL_RELATIONS.yaml"
    path.write_text(yaml.safe_dump(sets()), encoding="utf-8")
    doc = layer()
    assert not review.relations.layer_errors(doc)
    monkeypatch.setattr(review.relations, "load", lambda: copy.deepcopy(doc))
    for name in ("concept_sets", "local_assertions"):
        original = getattr(review.relations, name)
        monkeypatch.setattr(review.relations, name, lambda *_args, _fn=original, **_kwargs: _fn(str(path)))
    for name in ("set_errors", "local_errors"):
        original = getattr(review.relations, name)
        monkeypatch.setattr(review.relations, name, lambda *args, _fn=original, **kwargs: _fn(*args, path=str(path), **kwargs))
    monkeypatch.setattr(review.relations, "LOCAL_PATH", str(path))
    return path, doc


def test_canonical_relation_modalities_and_inactive_set_members_are_preserved(relation_reader):
    result = review.describe(query="prostate")
    assert result["available"], result
    group = result["groups"]["set:example_population"]
    assert len(group["rows"]) == 1 and group["rows"][0]["partner"] == "C3333333"
    assert group["rows"][0]["modalities"] == ["asserted", "refuted"] and group["rows"][0]["conflict"]
    assert group["rows"][0]["source_vocabularies"] == ["NCI"]
    assert result["sets"][0]["members"][1]["status"] == "deprecated"
    assert result["sets"][0]["active"] == ["C1111111"]


@pytest.mark.parametrize("state", [None, [], {"layer": "invalid-reference-sentinel"}])
def test_unavailable_or_malformed_projection_is_safe_and_does_not_offer_bindings(monkeypatch, state):
    monkeypatch.setattr(review.relations, "load", lambda: state)
    result = review.describe(query="prostate")
    assert not result["available"] and result["sets"] == [] and result["findings"]
    assert "invalid-reference-sentinel" not in json.dumps(result)


def test_malformed_recorded_set_does_not_hide_valid_projected_relations(relation_reader):
    path, _doc = relation_reader
    path.write_text("concept_sets: [ malformed-metadata-sentinel ]\n", encoding="utf-8")
    result = review.describe(query="prostate")
    assert result["available"] and result["concepts"] and not result["sets"]
    assert result["findings"] and "malformed-metadata-sentinel" not in json.dumps(result)


def test_local_disagreement_and_each_active_member_keep_their_evidence(relation_reader):
    path, doc = relation_reader
    register = sets()
    register["concept_sets"][0]["concepts"][1]["status"] = "active"
    register["assertions"] = [{"disease": "C1111111", "partner": "C3333333", "axis": "gene", "modality": "possible",
        "basis": "Synthetic local uncertainty differs from the projection", "citation": "Synthetic source section 3",
        "asserted_by": "Example Scientist", "asserted_on": "2026-09-07"}]
    path.write_text(yaml.safe_dump(register), encoding="utf-8")
    doc["diseases"]["C2222222"][0]["cui"] = "C3333333"
    result = review.describe(query="prostate")
    assert result["available"], result
    rows = result["groups"]["set:example_population"]["rows"]
    assert len(rows) == 3
    assert {row["source"] for row in rows} == {"local", "umls"}
    assert {row["via_concept"] for row in rows} == {"C1111111", "C2222222"}
    assert next(row for row in rows if row["source"] == "local")["citation"] == "Synthetic source section 3"


@pytest.mark.parametrize("second_status", ["active", "deprecated"])
def test_repeated_concept_cannot_hide_a_member_state_or_create_a_false_union(relation_reader, second_status):
    path, doc = relation_reader
    register = sets()
    register["concept_sets"][0]["concepts"][1] = {"cui": "C1111111", "status": second_status}
    path.write_text(yaml.safe_dump(register), encoding="utf-8")
    # Exercise the canonical reader's accepted duplicate before our narrow
    # portal guard, so this does not merely mirror a mocked implementation.
    assert not review.relations.concept_sets()[1] and not review.relations.set_errors(doc)
    result = review.describe(query="prostate")
    assert result["available"] and result["concepts"]
    assert not result["sets"] and "set:example_population" not in result["groups"]
    assert any("repeats a concept identifier" in finding for finding in result["findings"])


def test_repeated_projection_edge_cannot_silently_drop_refuted_evidence(relation_reader):
    _path, doc = relation_reader
    first = doc["diseases"]["C1111111"][0]
    first.update(modalities=["asserted"], conflict=False)
    second = dict(first, modality="refuted", modalities=["refuted"])
    doc["diseases"]["C1111111"].append(second)
    doc["counts"]["edges"] = 3
    assert not review.relations.layer_errors(doc)
    result = review.describe(query="prostate")
    assert not result["available"] and not result["sets"] and not result["groups"]
    assert any("malformed or inconsistent" in finding for finding in result["findings"])


@pytest.fixture(scope="module")
def checkout(tmp_path_factory):
    root = tmp_path_factory.mktemp("rel")
    for name, raw in science._inputs(ROOT, {PACK}).items():
        path = root / name
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes(raw)
    folder = root / "governance/reference/umls"
    (folder / "RELATIONS.json").write_text(json.dumps(layer()), encoding="utf-8")
    (folder / "LOCAL_RELATIONS.yaml").write_text(yaml.safe_dump(sets()), encoding="utf-8")
    (folder / "LAYER.yaml").write_text("enabled: true\nmax_source_restriction: 0\n", encoding="utf-8")
    return root


def describe(root):
    return science.describe(root, PACK, ACTOR, route="clinical_standards", variable="ECOG", allowed_packs=[PACK])


def test_product_set_uses_the_existing_staged_diff_validator_and_review_handoff(checkout):
    report = describe(checkout)
    assert report["ok"] and report["relation_review"]["sets"], report
    target = checkout / PACK / "config/semantic.yaml"
    original = target.read_bytes()
    result = science.stage(checkout, PACK, ACTOR, route="clinical_standards",
        values={"variable": "ECOG", "axis": "concept_set", "value": "example_population", "disposition": "accept",
                "reason": "Review the recorded active and historical population members for this product."},
        expected_input_digest=report["input_digest"], allowed_packs=[PACK], local_demo=True, can_write=True)
    assert result["ok"], result
    proposal = result["proposal"]
    assert "+concept_set: example_population" in proposal["diff"]
    assert proposal["artifact"]["scope"] == "product" and "ECOG" in proposal["artifact"]["affected_variables"]
    assert "semantic_binding.errors" in " ".join(proposal["validators"])
    assert "umls_relations.layer_errors" in " ".join(proposal["validators"])
    assert proposal["approval_created"] is False and proposal["findings"]
    assert target.read_bytes() == original
    import science_review_handoffs
    shared = science_review_handoffs.share(checkout, PACK, ACTOR, proposal["id"], expected_proposal_digest=proposal["payload_sha256"],
        owner="Science", note="Review this exact whole-product population scope and retained deprecated member.",
        allowed_packs=[PACK], local_demo=True, can_write=True)
    assert shared["ok"], shared
    assert target.read_bytes() == original


def test_reference_revision_and_unregistered_set_refuse_existing_proposal_path(checkout):
    report = describe(checkout)
    args = dict(route="clinical_standards", values={"variable": "ECOG", "axis": "concept_set", "value": "invented_set",
        "disposition": "accept", "reason": "The UI must not accept an invented reference set."},
        expected_input_digest=report["input_digest"], allowed_packs=[PACK], local_demo=True, can_write=True)
    result = science.stage(checkout, PACK, ACTOR, **args)
    assert not result["ok"] and "reference layer" in " ".join(result["errors"])
    path = checkout / "governance/reference/umls/LOCAL_RELATIONS.yaml"
    original = path.read_bytes()
    try:
        path.write_bytes(original + b"\n# terminology revision\n")
        args["values"]["value"] = "example_population"
        result = science.stage(checkout, PACK, ACTOR, **args)
        assert not result["ok"] and "changed" in " ".join(result["errors"])
    finally:
        path.write_bytes(original)


def test_ambiguous_duplicate_member_set_cannot_enter_the_existing_proposal_path(checkout):
    path = checkout / "governance/reference/umls/LOCAL_RELATIONS.yaml"
    original = path.read_bytes()
    target = checkout / PACK / "config/semantic.yaml"
    before = target.read_bytes()
    register = sets()
    register["concept_sets"][0]["concepts"][1] = {"cui": "C1111111", "status": "deprecated"}
    try:
        path.write_text(yaml.safe_dump(register), encoding="utf-8")
        report = describe(checkout)
        assert report["ok"] and not report["relation_review"]["sets"]
        result = science.stage(checkout, PACK, ACTOR, route="clinical_standards",
            values={"variable": "ECOG", "axis": "concept_set", "value": "example_population",
                "disposition": "accept", "reason": "Review the purported population union."},
            expected_input_digest=report["input_digest"], allowed_packs=[PACK], local_demo=True, can_write=True)
        assert not result["ok"] and "reference layer" in " ".join(result["errors"])
        assert target.read_bytes() == before
    finally:
        path.write_bytes(original)


def test_workbench_relation_choice_prepares_whole_product_proposal_without_writing(checkout):
    report = describe(checkout)
    assert report["ok"], report
    code = f'''import streamlit as st
import science_workspace_page as page
report = {report!r}
result = page._clinical({str(checkout)!r}, {PACK!r}, {ACTOR!r}, report, [{PACK!r}], True, "relation_test_")
if result: st.session_state["destination"] = result
'''
    at = AppTest.from_string(code, default_timeout=60).run()
    assert not at.exception, [e.message for e in at.exception]
    at.selectbox(key="relation_test_relation_subject").set_value("set:example_population").run()
    assert any("deprecated" in str(frame.value) for frame in at.dataframe)
    at.selectbox(key="relation_test_relation_modality").set_value("refuted").run()
    assert any("Modalities" in frame.value.columns and "asserted, refuted" in frame.value["Modalities"].tolist()
               for frame in at.dataframe)
    at.button(key="relation_test_select_set").click().run()
    assert not at.exception
    assert at.selectbox(key="relation_test_axis").value == "concept_set"
    assert at.selectbox(key="relation_test_value_concept_set").value == "example_population"
    assert any("whole product" in warning.value for warning in at.warning)
    at.selectbox(key="relation_test_disposition").set_value("defer")
    at.text_area(key="relation_test_reason").set_value("Need the scientist to review this population scope.")
    at.button(key="relation_test_save").click().run()
    assert not at.exception
    destination = at.session_state["destination"]
    assert destination["route"] == "clinical_standards" and destination["params"]["proposal_id"]


def test_unavailable_relation_lane_keeps_other_bindings_and_an_actionable_question(checkout):
    report = describe(checkout)
    assert report["ok"], report
    report["relation_review"] = {"available": False, "sets": [], "findings": ["The relation projection is unavailable."]}
    code = f'''import streamlit as st
import science_workspace_page as page
result = page._clinical({str(checkout)!r}, {PACK!r}, {ACTOR!r}, {report!r}, [{PACK!r}], True, "missing_rel_")
if result: st.session_state["destination"] = result
'''
    at = AppTest.from_string(code, default_timeout=60).run()
    assert not at.exception
    assert at.selectbox(key="missing_rel_axis")
    at.selectbox(key="missing_rel_axis").set_value("concept_set").run()
    assert not at.exception
    at.button(key="missing_rel_set_question").click().run()
    assert at.session_state["destination"]["route"] == "questions"
    assert at.session_state["destination"]["params"]["variable"] == "ECOG"
