"""The twelfth external verdict (2026-09-04), reproduced and closed — and the three epidemiologist
journeys it asked for, driven against the real tools.

Every test here was RED on 45a5cea before its fix. The verdict's method, kept: reproduce the
false green with an adversarial input, not a familiar one; fix the composed verdict, not a
component; never call a capability proven from one green fixture.

    P0-1  an unsigned approval made Gate 1 DONE and the pack "releasable" — releasable() never
          asked approval_identity
    P0-2  "non-small cell lung cancer" spelt out, "metastatic breast cancer", and a workbook with
          no population sheet all passed as a bladder specification — the disease check fired only
          on a registry stem, and switched itself off otherwise
    P0-3  `asthma_demo --tumor-class solid` previewed as an oncology pack with no word said;
          an absent condition_class read as oncology
    P0-4  `cohortn: eight`, `cohortm: 1` and `exclusion_dayz: 14` passed strict validation; the
          engine ran the window as 0
    P0-5  a receipted promotion verified its receipt by ONE field (the build id) before exiting
          green; the lock release matched the build id alone
    P1    the settlement transition; tumour_key on the alias route; the changelog entry bound to
          the change; install rollback; spec_diff lineage; intake load/precheck; the pipeline's
          digest; the decision tool's citation grammar; pack-relative material paths; validate on
          a pack directory; the UAT row names; the release-bundle claim

    python3 platform/tests/test_audit12_20260904.py
"""
import ast
import json
import os
import re
import shutil
import subprocess
import sys
import tempfile
import traceback
from pathlib import Path
from types import SimpleNamespace

FRAMEWORK = Path(__file__).resolve().parent.parent
ROOT = FRAMEWORK.parent
TOOLS = FRAMEWORK / "tools"
sys.path.insert(0, str(FRAMEWORK))
sys.path.insert(0, str(TOOLS))
sys.path.insert(0, str(ROOT / "experiments" / "agent"))

import console                                                              # noqa: E402

PROSTATE = "fixtures/oncology/prostate/202606"
BLADDER = "sandbox/demo_walkthrough/bladder/202609"
DEMO_XLSX = "sandbox/demo_walkthrough/bladder_202609_program_spec.xlsx"
PERSON = "Priya Natarajan"
ENV = dict(os.environ, PYTHONUTF8="1")


def _read(rel):
    with open(ROOT / rel, encoding="utf-8") as fh:
        return fh.read()


def _cli(tool, *args, cwd=None):
    p = subprocess.run([sys.executable, str(TOOLS / tool), *args], cwd=str(cwd or ROOT), env=ENV,
                       capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=900)
    return p.returncode, (p.stdout or "") + (p.stderr or "")


def _copy_repo():
    from new_product import copy_stage_tree
    tmp = tempfile.mkdtemp(prefix="audit12_")
    dst = os.path.join(tmp, "repo")
    copy_stage_tree(ROOT, dst)
    return dst


def _git(d, *args):
    subprocess.run(["git", "-C", d, *args], check=True, capture_output=True)


def _repo(d):
    for args in (["init", "-q", "."], ["config", "user.email", "t@example.invalid"],
                 ["config", "user.name", "T. Test"], ["config", "commit.gpgsign", "false"]):
        _git(d, *args)


def _commit(d, message):
    _git(d, "add", "-A")
    _git(d, "commit", "-qm", message)


def _workbook(out, *subs):
    """The demo workbook with phrases substituted — a vendor-shaped workbook for another disease."""
    import openpyxl                                                          # noqa: PLC0415
    wb = openpyxl.load_workbook(str(ROOT / DEMO_XLSX))
    for ws in wb.worksheets:
        for row in ws.iter_rows():
            for c in row:
                if isinstance(c.value, str):
                    v = c.value
                    for old, new in subs:
                        v = v.replace(old, new)
                    c.value = v
    wb.save(out)
    return out


def _tool(root, name):
    """A copied checkout's OWN tool — its ROOT is that copy, so registries, identity and digests are
    read there and nothing touches the live checkout."""
    return os.path.join(root, "platform", "tools", name)


def _standup(root, slug, *extra, workbook=None, family=None):
    args = [slug, "--code", slug[:12], "--name", slug.replace("_", " ").title(), "--vendor", "flatiron",
            "--tumor-class", "solid", "--spec-version", "202609", "--narrow", "genitourinary",
            "--condition-class", "oncology", "--modality", "ehr",
            "--ai-classification", "sponsor_ai_eligible", "--classified-by", PERSON,
            "--classified-date", "2026-09-04", *extra]
    if family:
        args += ["--tumour-family", family]
    if workbook:
        args += ["--workbook", workbook]
    p = subprocess.run([sys.executable, str(TOOLS / "new_product.py"), *args, "--root", root], cwd=root,
                       env=ENV, capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=900)
    return p.returncode, (p.stdout or "") + (p.stderr or "")


# ------------------------------------------------------------------ P0-1 identity composed into the verdict

def test_an_unauthenticated_approval_holds_gate_1_and_the_release_verdict():
    """The composed verdict. A pack whose Gate 1 fields a person typed and nobody signed used to show
    Gate 1 [done] on the status page and no Gate 1 reason in `--list-releasable`, while
    `approval_identity.py --check` reported the same approval as unsigned. Now the verdict asks."""
    import approval_identity as ai                                           # noqa: PLC0415
    import source_manifest as sm                                             # noqa: PLC0415
    root = _copy_repo()
    _repo(root)
    _commit(root, "baseline checkout")
    # Reference fixtures may gain unsigned draft decisions after the recorded
    # authentication baseline. They must still hold the composed verdict; the
    # fixture's location is not an approval and cannot grandfather later edits.
    reference_unsigned, reference_errors = ai.unauthenticated(str(ROOT), PROSTATE)
    assert not reference_errors, reference_errors
    if reference_unsigned:
        reference_ready, reference_reasons = sm.releasable(str(ROOT), PROSTATE)
        assert not reference_ready and any("not authenticated" in reason for reason in reference_reasons), reference_reasons
    # a product pack with a REVIEWED specification approved by a typed name, committed unsigned
    pack = "products/oncology/prostate_copy/202606"
    shutil.copytree(os.path.join(root, PROSTATE), os.path.join(root, pack))
    reg = Path(root, "products", "registry.yaml")
    reg.write_text(reg.read_text(encoding="utf-8").replace(
        "tumors:", 'tumors:\n  - { code: pcopy, name: "Prostate copy", slug: prostate_copy, vendor: flatiron, '
                   'tumor_class: solid, status: scaffold, current_spec_version: "202606", role: product }', 1),
        encoding="utf-8")
    sr = Path(root, pack, "source_refs.yaml")
    sr.write_text(sr.read_text(encoding="utf-8").replace("product: prostate", "product: prostate_copy", 1), encoding="utf-8")
    _commit(root, "an approval a person typed and nobody signed")
    rows, _errs = ai.audit_pack(root, pack)
    assert rows and not any(r["authenticated"] for r in rows), rows
    unauth, _e = ai.unauthenticated(root, pack)
    assert unauth, "nothing grandfathers a new pack's approvals"
    ready, why = sm.releasable(root, pack)
    g1 = [w for w in why if w.startswith("Gate 1:") and "is not authenticated" in w]
    assert not ready and g1, why
    assert any("classified_by=" in w and "UNSIGNED" in w for w in g1), g1
    # the status page files the reason under Gate 1, so the gate is not [done]
    p = subprocess.run([sys.executable, _tool(root, "status.py"), pack], cwd=root, env=ENV,
                       capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=600)
    m = re.search(r"GATE 1 · APPROVED INPUTS\s+\[([a-z ]+)\]", p.stdout)
    assert m and m.group(1) != "done", (m.group(1) if m else p.stdout[-800:])
    assert "not authenticated" in p.stdout
    assert ai.gate_label("Gate 1 registration and classification") == "Gate 1"
    assert ai.gate_label("the decision register") == "Gate 2"
    assert ai.gate_label("a semantic binding approval") == "Gate 4"
    assert ai.gate_label("something else") == "evidence"
    shutil.rmtree(os.path.dirname(root), ignore_errors=True)


# ------------------------------------------------------------------ P0-2 positive disease identification

def _rows(*texts):
    return [{"item_id": f"study_population:{i + 2}", "tab": "4.StudyPop", "row": i + 2, "variable": f"INCL{i + 1}",
             "domain": "study_population", "text": t} for i, t in enumerate(texts)]


def test_the_disease_check_requires_the_packs_own_tumour_to_be_named():
    import spec_lint as sl                                                   # noqa: PLC0415
    reg = sl.tumour_registry()
    assert set(reg["disease_terms"]) == set(reg["families"]), "every family names its disease in prose"
    assert reg["non_oncology_terms"] and "asthma" in reg["non_oncology_terms"]
    # the four inputs the verdict named, each REFUSED now
    cases = {
        "spelt out": _rows("Adults with non-small cell lung cancer, first diagnosed 2018 or later"),
        "abbreviated": _rows("Adults with NSCLC"),
        "unregistered": _rows("Adults with metastatic breast cancer"),
        "non-oncology": _rows("Adults with a confirmed asthma diagnosis"),
        "nothing said": _rows("Patients with a structured diagnosis record after 2018"),
    }
    for what, rows in cases.items():
        found = sl.scan_declared_disease(rows, "bladder")
        assert found and all(f["kind"] == "DECLARED_DISEASE" and f["severity"] == "HIGH" for f in found), (what, found)
    assert "nsclc" in sl.scan_declared_disease(cases["spelt out"], "bladder")[0]["detail"]
    assert "non-oncology (asthma)" in sl.scan_declared_disease(cases["non-oncology"], "bladder")[0]["detail"]
    assert "cannot be established" in sl.scan_declared_disease(cases["unregistered"], "bladder")[0]["detail"]
    # no population rows at all is a finding, not a note
    none = sl.scan_declared_disease([{"item_id": "clinical:2", "tab": "6.Clinical", "row": 2, "domain": "clinical",
                                      "text": "ECOG at index"}], "bladder")
    assert none and "no study-population row at all" in none[0]["detail"]
    # ...and the pack's own disease, named in prose or by stem, passes — with another tumour
    # mentioned in an exclusion beside it
    ok = _rows("Metastatic urothelial carcinoma diagnosis (mUC) with a structured record",
               "Exclude a prior diagnosis of prostate cancer within 5 years")
    assert sl.scan_declared_disease(ok, "bladder") == []
    assert sl.scan_declared_disease(_rows("Adults with Non-Small-Cell Lung Cancer"), "nsclc") == []
    assert sl.scan_declared_disease(_rows("GIST diagnosis by histology"), "gist") == []
    # an alias resolves to its family's terms
    assert sl.scan_declared_disease(_rows("Epithelial ovarian cancer, stage III"), "oc") == []
    # the applicability notes no longer offer the silent state
    src = _read("platform/tools/spec_lint.py")
    assert "no study-population row names any registry family" not in src.split("def scan_declared_disease")[0]


def test_every_rehearsal_workbook_positively_names_its_own_tumour():
    """The positive rule holds for every tumour the inventory carries, measured on the rehearsal
    workbooks the pipeline test runs — so the rule cannot be right for bladder and wrong for CLL."""
    import spec_workbook_synth as sw                                         # noqa: PLC0415
    import spec_lint as sl                                                   # noqa: PLC0415
    import yaml                                                              # noqa: PLC0415
    import openpyxl                                                          # noqa: PLC0415
    inv = yaml.safe_load(_read("governance/reference/variable_inventory/INVENTORY.yaml"))
    d = tempfile.mkdtemp()
    seen = 0
    for tumour in sorted((inv.get("tumours") or {}).keys()):
        out = os.path.join(d, f"{tumour}.xlsx")
        sw.build(tumour, out)
        ws = openpyxl.load_workbook(out, read_only=True)
        assert "4.StudyPop" in ws.sheetnames, tumour
        texts = [" ".join(str(c) for c in row if c)
                 for i, row in enumerate(ws["4.StudyPop"].iter_rows(values_only=True)) if i >= 2]
        rows = [{"item_id": f"study_population:{i}", "tab": "4.StudyPop", "row": i, "domain": "study_population", "text": t}
                for i, t in enumerate(texts, start=3)]
        assert sl.scan_declared_disease(rows, tumour) == [], tumour
        seen += 1
    assert seen >= 13
    shutil.rmtree(d, ignore_errors=True)


def test_a_workbook_for_an_unregistered_disease_refuses_the_whole_stand_up():
    root = _copy_repo()
    xlsx = _workbook(os.path.join(root, "breast.xlsx"),
                     ("Metastatic urothelial carcinoma diagnosis (mUC)", "Adults with metastatic breast cancer"),
                     ("Inclusion: mUC", "Inclusion: breast"))
    rc, out = _standup(root, "bladder_flatiron", "--apply", workbook=xlsx, family="bladder")
    assert rc != 0 and "REFUSED" in out and "cannot be established" in out, out[-1500:]
    assert not os.path.exists(os.path.join(root, "products", "oncology", "bladder_flatiron")), "nothing was written"
    xlsx = _workbook(os.path.join(root, "lung.xlsx"),
                     ("Metastatic urothelial carcinoma diagnosis (mUC)", "Adults with non-small cell lung cancer"),
                     ("Inclusion: mUC", "Inclusion: lung"))
    rc, out = _standup(root, "bladder_flatiron", "--apply", workbook=xlsx, family="bladder")
    assert rc != 0 and "declares a nsclc population" in out, out[-1500:]
    assert "study-populat." not in out, "the refusal is not cut off mid-word"
    shutil.rmtree(os.path.dirname(root), ignore_errors=True)


# ------------------------------------------------------------------ P0-3 condition class, modality, tumour key

def test_a_non_oncology_product_is_refused_at_the_stand_up_and_the_class_is_written():
    import new_product as npd                                                # noqa: PLC0415
    root = _copy_repo()
    rc, out = _standup(root, "asthma_demo", "--disease-terms", "asthma exacerbation")
    assert rc != 0 and "REFUSED" in out and "non_oncology_terms" in out, out[-1200:]
    p = subprocess.run([sys.executable, str(TOOLS / "new_product.py"), "kidney", "--code", "kidney", "--name", "Kidney",
                        "--vendor", "flatiron", "--tumor-class", "solid", "--spec-version", "202609", "--narrow",
                        "genitourinary", "--condition-class", "respiratory", "--modality", "ehr", "--disease-terms",
                        "renal cell carcinoma", "--ai-classification", "sponsor_ai_eligible", "--classified-by",
                        PERSON, "--classified-date", "2026-09-04", "--root", root], cwd=root, env=ENV,
                       capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=600)
    assert p.returncode != 0 and "oncology-configurable only" in p.stdout + p.stderr
    # a NEW family without disease terms cannot be positively identified: refused up front
    rc, out = _standup(root, "kidney")
    assert rc != 0 and "--disease-terms is required" in out, out[-800:]
    # ...and a phrase another family already owns is refused (2026-09-04: hnc with 'prostate cancer')
    rc, out = _standup(root, "hnc", "--disease-terms", "prostate cancer")
    assert rc != 0 and "already names the prostate family" in out and "--tumour-family prostate" in out, out[-800:]
    # the registry itself refuses a phrase under two families
    import spec_lint as sl                                                   # noqa: PLC0415
    with tempfile.TemporaryDirectory() as d:
        os.makedirs(os.path.join(d, "governance"))
        text = _read("governance/tumour_registry.yaml").replace("  gist: [gastrointestinal stromal tumor,",
                                                                "  gist: [prostate cancer, gastrointestinal stromal tumor,", 1)
        Path(d, "governance", "tumour_registry.yaml").write_text(text, encoding="utf-8")
        saved_root, saved_reg = sl._REGISTRY_ROOT, sl._REGISTRY
        try:
            sl._REGISTRY_ROOT, sl._REGISTRY = d, None
            try:
                sl.tumour_registry()
                raise AssertionError("two families shared a phrase and the registry loaded")
            except SystemExit as e:
                assert "claimed by both" in str(e)
        finally:
            sl._REGISTRY_ROOT, sl._REGISTRY = saved_root, saved_reg
    # the plan writes the identity fields the registry documents
    a = SimpleNamespace(slug="kidney", code="kidney", name="Kidney", vendor="flatiron", tumor_class="solid",
                        spec_version="202609", family="oncology", broad=None, narrow="genitourinary",
                        tumour_family=None, condition_class="oncology", modality="ehr",
                        disease_terms="renal cell carcinoma, kidney cancer", workbook=None,
                        ai_classification="sponsor_ai_eligible", classified_by=PERSON, classified_date="2026-09-04")
    pack, steps = npd.plan(a, root)
    reg = next(text for rel, action, text in steps if rel == "products/registry.yaml")
    line = next(ln for ln in reg.splitlines() if "slug: kidney" in ln)
    assert "tumour_key: kidney" in line and "modality: ehr" in line and "condition_class: oncology" in line, line
    tr = next(text for rel, action, text in steps if rel == "governance/tumour_registry.yaml")
    assert re.search(r"^  kidney: \[kidney\]", tr, re.M) and "kidney: [renal cell carcinoma, kidney cancer, kidney]" in tr, tr[:400]
    conf = next(text for rel, action, text in steps if rel.endswith("spec_pipeline/pipeline.conf"))
    assert re.search(r"^TUMOR=kidney\s*$", conf, re.M), "the filled value carries no 'replace me' comment"
    # the alias route writes the FAMILY as tumour_key
    a.tumour_family, a.slug, a.disease_terms = "bladder", "bladder_cota", ""
    _pack, steps = npd.plan(a, root)
    reg = next(text for rel, action, text in steps if rel == "products/registry.yaml")
    line = next(ln for ln in reg.splitlines() if "slug: bladder_cota" in ln)
    assert "tumour_key: bladder" in line, line
    shutil.rmtree(os.path.dirname(root), ignore_errors=True)


def test_condition_class_is_declared_by_every_config_and_never_defaulted():
    import glob                                                              # noqa: PLC0415
    from engine import config as ec, validate as ev                          # noqa: PLC0415
    configs = glob.glob(str(ROOT / "fixtures" / "*" / "*" / "*" / "config" / "data_product.yaml")) + \
        [str(ROOT / BLADDER / "config" / "data_product.yaml"),
         str(ROOT / "platform" / "TUMOR_TEMPLATE" / "config" / "data_product.yaml")]
    assert len(configs) >= 15
    for c in configs:
        assert re.search(r"^condition_class: oncology", open(c, encoding="utf-8").read(), re.M), c
    with tempfile.TemporaryDirectory() as d:
        shutil.copytree(os.path.join(str(ROOT), PROSTATE), os.path.join(d, "p"))
        path = os.path.join(d, "p", "config", "data_product.yaml")
        text = open(path, encoding="utf-8").read()
        open(path, "w", encoding="utf-8").write(re.sub(r"^condition_class: oncology[^\n]*\n", "", text, count=1, flags=re.M))
        cfg = ec.load_config(path)
        assert cfg.condition_class == "", "absent is absent, not oncology"
        probs = [p for p in ev.problems(cfg) if "condition_class" in p]
        assert probs and "not declared" in probs[0], probs


# ------------------------------------------------------------------ P0-4 the strict schema

def test_misspelled_and_mistyped_scientific_config_is_refused():
    from engine import config as ec, validate as ev                          # noqa: PLC0415
    with tempfile.TemporaryDirectory() as d:
        shutil.copytree(os.path.join(str(ROOT), PROSTATE), os.path.join(d, "p"))
        cfg_path = os.path.join(d, "p", "config", "data_product.yaml")
        out_path = os.path.join(d, "p", "variables", "outcomes.yaml")
        text = open(cfg_path, encoding="utf-8").read()
        open(cfg_path, "w", encoding="utf-8").write(
            text.replace("cohortn: 1, line_setting: mHSPC", "cohortn: eight, line_setting: mHSPC", 1)
                .replace("cohortn: 2, line_setting: mCRPC", "cohortm: 2, line_setting: mCRPC", 1))
        otext = open(out_path, encoding="utf-8").read()
        open(out_path, "w", encoding="utf-8").write(otext.replace("exclusion_days: 14", "exclusion_dayz: 14", 1))
        probs = ev.problems(ec.load_config(cfg_path), strict=True)
        assert any("cohortn must be a whole number" in p and "'eight'" in p for p in probs), probs
        assert any("unknown key 'cohortm'" in p and "did you mean 'cohortn'" in p for p in probs), probs
        assert any("unknown key 'exclusion_dayz'" in p and "did you mean 'exclusion_days'" in p for p in probs), probs
        assert any("exclusion_days is not declared" in p for p in probs), probs
        # lint mode (placeholders allowed) refuses the same: these are not placeholders
        probs = ev.problems(ec.load_config(cfg_path), strict=False)
        assert any("cohortm" in p for p in probs) and any("exclusion_dayz" in p for p in probs)
        # a negative window and a bool where an int belongs
        open(out_path, "w", encoding="utf-8").write(otext.replace("exclusion_days: 14", "exclusion_days: -3", 1))
        open(cfg_path, "w", encoding="utf-8").write(text.replace("cohortn: 1, line_setting: mHSPC", "cohortn: true, line_setting: mHSPC", 1))
        probs = ev.problems(ec.load_config(cfg_path), strict=True)
        assert any("exclusion_days must be a whole number of days >= 0" in p for p in probs), probs
        assert any("cohortn must be a whole number, got True" in p for p in probs), probs
    # the untouched fixtures still validate in lint mode: the schema fits every real pack
    import glob                                                              # noqa: PLC0415
    for c in glob.glob(str(ROOT / "fixtures" / "*" / "*" / "*" / "config" / "data_product.yaml")) + \
            [str(ROOT / BLADDER / "config" / "data_product.yaml")]:
        probs = [p for p in ev.problems(ec.load_config(c)) if "unknown key" in p or "must be" in p or "not declared" in p]
        assert probs == [], (c, probs)


def test_the_closed_key_sets_are_what_the_engine_reads_and_what_the_packs_write():
    """The tables cannot drift: every closed key is read somewhere under platform/engine, and every
    key a committed pack writes is in the table."""
    import glob                                                              # noqa: PLC0415
    import yaml                                                              # noqa: PLC0415
    from engine import validate as ev                                        # noqa: PLC0415
    engine_src = "\n".join(open(p, encoding="utf-8").read()
                           for p in glob.glob(str(FRAMEWORK / "engine" / "**" / "*.py"), recursive=True)
                           if "validate.py" not in p)
    for k in ev.COHORT_KEYS | ev.PROGRESSION_KEYS:
        assert f'"{k}"' in engine_src or f"'{k}'" in engine_src, f"{k} is read by nothing under platform/engine"
    for p in glob.glob(str(ROOT / "fixtures" / "*" / "*" / "*" / "config" / "data_product.yaml")) + \
            [str(ROOT / BLADDER / "config" / "data_product.yaml"), str(ROOT / "platform" / "TUMOR_TEMPLATE" / "config" / "data_product.yaml")]:
        for c in (yaml.safe_load(open(p, encoding="utf-8")) or {}).get("cohorts") or []:
            assert set(c) <= ev.COHORT_KEYS, (p, set(c) - ev.COHORT_KEYS)
    for p in glob.glob(str(ROOT / "fixtures" / "*" / "*" / "*" / "variables" / "outcomes.yaml")):
        pr = (yaml.safe_load(open(p, encoding="utf-8")) or {}).get("progression") or {}
        assert set(pr) <= ev.PROGRESSION_KEYS, (p, set(pr) - ev.PROGRESSION_KEYS)
        if pr:
            assert "exclusion_days" in pr, f"{p}: the window is declared, never implied"


def test_the_engine_refuses_an_undeclared_exclusion_window_before_touching_spark():
    from engine.stages import outcomes as eo                                 # noqa: PLC0415
    try:
        eo._progression(None, None, None, None, {"date_column": "progressiondate", "evidence_columns": ["x"],
                                                 "pseudoprogression_column": "p"})
        raise AssertionError("ran without a window")
    except ValueError as e:
        assert "exclusion_days is not declared" in str(e)
    src = _read("platform/engine/stages/outcomes.py")
    assert 'pcfg.get("exclusion_days", 0)' not in src


def test_validate_accepts_the_pack_directory_and_says_what_it_wants():
    p = subprocess.run([sys.executable, str(FRAMEWORK / "engine" / "validate.py"), PROSTATE], cwd=str(ROOT),
                       env=ENV, capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=300)
    assert "Traceback" not in p.stdout + p.stderr and "config OK" in p.stdout, p.stdout[-400:] + p.stderr[-400:]
    p = subprocess.run([sys.executable, str(FRAMEWORK / "engine" / "validate.py"), "fixtures/oncology"], cwd=str(ROOT),
                       env=ENV, capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=300)
    assert p.returncode == 2 and "no config/data_product.yaml" in p.stdout


# ------------------------------------------------------------------ P0-5 the receipt is THIS promotion's

def test_a_receipt_is_bound_to_the_promotion_by_everything_known():
    from engine import release as rel                                        # noqa: PLC0415
    journal = {"state": "receipted", "build_id": "b0001", "public": "prod.ads", "refresh": "2026q1",
               "attempt_id": "att1", "candidate_manifest_sha256": "c" * 64,
               "outputs": {"ads": {"table_id": "t1", "delta_version": 3}}}
    receipt = {"status": "released", "release": {"build_id": "b0001"}, "output_table": "prod.ads",
               "refresh": "2026q1", "tumor": "prostate", "spec_version": "202606", "family": "oncology",
               "promoted_from": {"candidate_manifest_sha256": "c" * 64,
                                 "outputs": {"ads": {"table_id": "t1", "delta_version": 3}}}}
    kw = dict(build_id="b0001", final="prod.ads", refresh="2026q1", tumor="prostate", spec_version="202606",
              family="oncology")
    assert rel.receipt_binding_errors(receipt, journal, **kw) == []
    # the verdict's substitution: same build id, another product's receipt
    other = dict(receipt, tumor="ovarian", output_table="prod.oc_ads", refresh="2025q4")
    why = rel.receipt_binding_errors(other, journal, **kw)
    assert len(why) >= 3 and any("tumor" in w for w in why) and any("publishes" in w for w in why), why
    # a CANDIDATE manifest offered as the receipt
    cand = dict(receipt, status="qc_passed")
    assert any("not released" in w for w in rel.receipt_binding_errors(cand, journal, **kw))
    # other candidate bytes, other outputs, a pointer naming another build
    assert any("candidate" in w for w in rel.receipt_binding_errors(
        {**receipt, "promoted_from": {**receipt["promoted_from"], "candidate_manifest_sha256": "d" * 64}}, journal, **kw))
    assert any("outputs" in w for w in rel.receipt_binding_errors(
        {**receipt, "promoted_from": {**receipt["promoted_from"], "outputs": {"ads": {"table_id": "t9"}}}}, journal, **kw))
    assert any("pointer" in w for w in rel.receipt_binding_errors(
        receipt, journal, pointer_rows=[{"build_id": "b0002", "published_at": "x"}], **kw))
    assert any("no promoted_from" in w for w in rel.receipt_binding_errors(
        {**receipt, "promoted_from": {}}, journal, **kw))
    # malformed shapes are findings, never exceptions
    assert rel.receipt_binding_errors(5, "x", **kw)
    # the lock release verifies the ATTEMPT, not the build alone
    assert rel.lock_release_blockers({"build_id": "b0001", "attempt_id": "att1"}, "b0001", "att1") == []
    assert rel.lock_release_blockers({"build_id": "b0001", "attempt_id": "att2"}, "b0001", "att1")
    assert rel.lock_release_blockers({"build_id": "b0002", "attempt_id": "att1"}, "b0001", "att1")
    # the runner binds before it calls anything promoted, and releases only its own attempt's lock
    src = _read("platform/databricks/run_rwdp.py")
    term = src.split('if _journal.get("state") == rel.PROMOTION_STATES[-1]:', 1)[1].split('dbutils.notebook.exit("already_promoted")', 1)[0]
    assert "rel.receipt_binding_errors(" in term and "rel.lock_release_blockers(" in term
    assert term.index("validate_manifest(_receipt)") < term.index("rel.receipt_binding_errors(") < term.index("audit.build_bundle(")


# ------------------------------------------------------------------ P1: the rest, each a defect the journeys hit

def test_the_settlement_transition_returns_a_parked_record_to_draft():
    import contract_record as cr                                             # noqa: PLC0415
    current = {"requirement": "decision_required", "source": "unverified", "implementation": "not_implemented",
               "validation": "not_run"}
    rec = {"variable_id": "X", "decision_ids": ["Q-1"]}
    out, bad = cr.apply_status(rec, current, dec_open={"Q-1": "OPEN"})
    assert not bad and "requirement: decision_required" in out["status"]
    out, bad = cr.apply_status(rec, current, dec_open={"Q-1": "RESOLVED"})   # Q-1 answered since
    assert not bad and "requirement: draft" in out["status"], out["status"]
    # never further than draft, and never from an approved record
    approved = dict(current, requirement="approved")
    out, _ = cr.apply_status(rec, approved, dec_open={"Q-1": "RESOLVED"})
    assert "requirement: approved" in out["status"]
    # and never when the caller does not know the register
    out, _ = cr.apply_status(rec, current, dec_open=None)
    assert "requirement: decision_required" in out["status"]


def test_install_puts_everything_back_when_any_write_fails():
    import new_product as npd                                                # noqa: PLC0415
    with tempfile.TemporaryDirectory() as d:
        root, staged = os.path.join(d, "root"), os.path.join(d, "staged")
        os.makedirs(os.path.join(root, "a")); os.makedirs(os.path.join(staged, "a")); os.makedirs(os.path.join(staged, "b"))
        Path(root, "a", "old.yaml").write_text("old: 1\n", encoding="utf-8")
        for rel in ("a/old.yaml", "a/new.yaml", "b/new2.yaml"):
            Path(staged, *rel.split("/")).write_text(f"staged: {rel}\n", encoding="utf-8")
        calls = []

        def boom(src, dst):
            calls.append(dst)
            if len(calls) == 3:
                raise OSError("disk full")
            os.replace(src, dst)
        try:
            npd.install(root, staged, ["a/old.yaml", "a/new.yaml", "b/new2.yaml"], _replace=boom)
            raise AssertionError("no error raised")
        except OSError:
            pass
        assert Path(root, "a", "old.yaml").read_text(encoding="utf-8") == "old: 1\n", "the overwritten file is back"
        assert not os.path.exists(os.path.join(root, "a", "new.yaml")), "the created file is gone"
        assert not os.path.exists(os.path.join(root, "b", "new2.yaml"))
        assert not any(f.endswith(".new_product.tmp") for _d, _s, fs in os.walk(root) for f in fs)
        assert npd.install(root, staged, ["a/old.yaml", "a/new.yaml", "b/new2.yaml"]) == ["a/old.yaml", "a/new.yaml", "b/new2.yaml"]


def test_a_decision_may_cite_the_domain_row_every_other_tool_prints():
    import decision_record as dr                                             # noqa: PLC0415
    with tempfile.TemporaryDirectory() as d:
        root = os.path.join(d, "repo")
        os.makedirs(os.path.join(root, "sandbox", "demo_walkthrough", "bladder"))
        shutil.copytree(os.path.join(str(ROOT), BLADDER), os.path.join(root, BLADDER))
        head = Path(ROOT, PROSTATE, "handoff", "DECISIONS.md").read_text(encoding="utf-8")
        table_at = head.index("\n|")
        header_rows = head[table_at + 1:].split("\n")[:2]
        Path(root, BLADDER, "handoff", "DECISIONS.md").write_text(head[:table_at + 1] + "\n".join(header_rows) + "\n",
                                                                   encoding="utf-8")
        for ev in ("outcomes:4", "8.Outcomes:4", "study_population:2"):
            try:
                dr.open_question(BLADDER, "Q-" + re.sub(r"[^A-Z0-9]", "", ev.upper())[:8], "q?", "Science", root=root, evidence=ev)
            except SystemExit as e:
                raise AssertionError((ev, e))
        for ev, why in (("outcomes:99", "names no extracted row"), ("not_a_real_tab:9", "no such tab")):
            try:
                dr.open_question(BLADDER, "Q-BAD", "q?", "Science", root=root, evidence=ev)
                raise AssertionError(ev)
            except SystemExit as e:
                assert why in str(e), (ev, e)


def test_a_pack_relative_material_path_resolves_and_the_digest_records():
    import source_manifest as sm                                             # noqa: PLC0415
    with tempfile.TemporaryDirectory() as d:
        pack = os.path.join(d, "products", "oncology", "x", "202609")
        os.makedirs(os.path.join(pack, "prog_spec"))
        shutil.copy(str(ROOT / DEMO_XLSX), os.path.join(pack, "prog_spec", "SPEC.xlsx"))
        assert sm.material_file(pack, "prog_spec/SPEC.xlsx", root=d) == os.path.join(pack, "prog_spec", "SPEC.xlsx")
        assert sm.material_file(pack, "products/oncology/x/202609/prog_spec/SPEC.xlsx", root=d).endswith("SPEC.xlsx")
        assert sm.material_file(pack, "nowhere.xlsx", root=d) == os.path.join(d, "nowhere.xlsx")
    # through the real tool, on a copy of the checkout: the runbook's own instruction works
    root = _copy_repo()
    pack = "products/oncology/kidney/202609"
    rc, out = _standup(root, "kidney", "--disease-terms", "renal cell carcinoma", "--apply")
    assert rc == 0 and "WROTE" in out, out[-1200:]
    os.makedirs(os.path.join(root, pack, "prog_spec"), exist_ok=True)
    shutil.copy(str(ROOT / DEMO_XLSX), os.path.join(root, pack, "prog_spec", "SPEC.xlsx"))
    sr = Path(root, pack, "source_refs.yaml")
    sr.write_text(re.sub(r"path_or_link: TBD[^\n]*", "path_or_link: prog_spec/SPEC.xlsx", sr.read_text(encoding="utf-8"), count=1), encoding="utf-8")
    p = subprocess.run([sys.executable, _tool(root, "source_manifest.py"), pack, "--record-digest", "program_spec"],
                       cwd=root, env=ENV, capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=300)
    assert p.returncode == 0 and "recorded from" in p.stdout, p.stdout + p.stderr
    p = subprocess.run([sys.executable, _tool(root, "source_manifest.py"), pack, "--resolve", "program_spec"],
                       cwd=root, env=ENV, capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=300)
    assert p.stdout.strip() == f"{pack}/prog_spec/SPEC.xlsx", p.stdout
    shutil.rmtree(os.path.dirname(root), ignore_errors=True)


def test_the_pipeline_refuses_bytes_the_registration_does_not_describe():
    root = _copy_repo()
    xlsx = os.path.join(root, DEMO_XLSX)
    _workbook(xlsx, ("TBD whether a 60-day gap", "a 60-day gap ends the line; previously TBD whether a 60-day gap"))
    before = Path(root, BLADDER, "spec_pipeline", "out", "extracted.json").read_bytes()
    p = subprocess.run([sys.executable, _tool(root, "run_spec_pipeline.py"), BLADDER], cwd=root, env=ENV,
                       capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=600)
    assert p.returncode != 0 and "changed under the registration" in p.stdout + p.stderr, p.stdout[-600:] + p.stderr[-600:]
    assert Path(root, BLADDER, "spec_pipeline", "out", "extracted.json").read_bytes() == before, \
        "nothing was extracted from the unregistered bytes"
    shutil.rmtree(os.path.dirname(root), ignore_errors=True)


def test_the_changelog_entry_is_bound_to_the_change_and_may_be_a_new_file():
    import config_diff as cd                                                 # noqa: PLC0415
    root = _copy_repo()
    _repo(root)
    _commit(root, "base")
    pack = PROSTATE
    cfg = Path(root, pack, "config", "data_product.yaml")
    text = cfg.read_text(encoding="utf-8")
    cfg.write_text(re.sub(r"^  - \{ id: lot3_mcrpc[^\n]*\n", "", text, count=1, flags=re.M), encoding="utf-8")
    log = Path(root, "fixtures", "oncology", "prostate", "202606", "CHANGELOG.md")
    assert not log.exists()
    found = cd.versioning_findings(pack, "HEAD", root=root)
    assert found and "no CHANGELOG entry" in found[0] and "naming each changed file" in found[0], found
    # an UNTRACKED first changelog counts — the person wrote the entry, git had not seen the file
    log.write_text("# Changelog\n\n- 2026-09-04 none: tidy-up\n", encoding="utf-8")
    found = cd.versioning_findings(pack, "HEAD", root=root)
    assert found and all("no CHANGELOG entry" not in f for f in found), found
    assert any("does not name this pack's spec_version 202606" in f for f in found) and \
        any("names none of the changed file(s) config/data_product.yaml" in f for f in found), found
    log.write_text("# Changelog\n\n- 2026-09-04 none 202606: dropped the L3+ cohort (config/data_product.yaml)\n", encoding="utf-8")
    found = cd.versioning_findings(pack, "HEAD", root=root)
    assert found and "`none` may not classify a MATERIAL change" in found[0] and "dropped /cohorts[id=lot3_mcrpc]" in found[0], found
    log.write_text("# Changelog\n\n- 2026-09-04 breaking 202606: dropped the L3+ cohort (config/data_product.yaml)\n", encoding="utf-8")
    found = cd.versioning_findings(pack, "HEAD", root=root)
    assert found and "NEW spec_version" in found[0] and "--next-cut-of" in found[0], found
    shutil.rmtree(os.path.dirname(root), ignore_errors=True)


def test_spec_diff_compares_only_two_cuts_of_one_product_in_order():
    import spec_diff as sd                                                   # noqa: PLC0415
    assert sd.lineage_errors("sandbox/demo_walkthrough/bladder/202609", "sandbox/demo_walkthrough/bladder/202610") is None
    assert sd.lineage_errors("fixtures/oncology/prostate/202603", PROSTATE) is None
    assert "different products" in sd.lineage_errors(PROSTATE, "fixtures/oncology/oc/202606")
    assert "not EARLIER" in sd.lineage_errors(PROSTATE, "fixtures/oncology/prostate/202603")
    assert "not a YYYYMM cut" in sd.lineage_errors("fixtures/oncology/endometrial/YYYYMM", "fixtures/oncology/endometrial/202701")
    rc, out = _cli("spec_diff.py", PROSTATE, "fixtures/oncology/oc/202606")
    assert rc != 0 and "REFUSED" in out and "different products" in out


def test_intake_re_derives_checked_on_load_and_refuses_placeholders_on_required_slots():
    import intake                                                            # noqa: PLC0415
    tpl = intake.domains()["feasibility"]
    slot = next(s["id"] for s in tpl["slots"] if s.get("required", True))
    state = {"domain": "feasibility", "pack": PROSTATE, "actor": PERSON, "request": {slot: "none"}}
    found = intake.precheck(state, [PROSTATE])
    assert any("placeholder, not an answer" in f and slot in f for f in found), found
    state["request"][slot] = "no exclusions: the full cohort is analysed"
    assert not any("placeholder" in f for f in intake.precheck(state, [PROSTATE]))
    # the outcome-dependent exclusion, in the words people use
    rx = next(r for s, r, _w in intake._DESIGN_RULES if s == "exclusions")
    for phrase in ("exclude patients who die within 30 days of index", "exclude anyone deceased during follow-up",
                   "mortality after the index date excludes the patient", "patients dead post-index are removed"):
        assert rx.search(phrase), phrase
    assert not rx.search("exclude patients with a prior cancer before index")
    with tempfile.TemporaryDirectory() as tmp:
        # run records live BESIDE the requests directory (<parent>/runs), so the requests get a
        # directory of their own — a flat temp dir would share `/tmp/runs` with every earlier run
        d = os.path.join(tmp, "requests")
        os.makedirs(d)
        s = {"domain": "feasibility", "pack": PROSTATE, "actor": PERSON, "request": {slot: "adults with mCRPC"}}
        path = intake.save_request(s, d, status="draft")
        doc = intake.load_requests(d)[0]
        assert doc["status"] == "draft"
        # a file that SAYS checked, with a run that never checked it
        text = open(path, encoding="utf-8").read().replace("status: draft", "status: checked").replace("run_id: null", "run_id: r1")
        open(path, "w", encoding="utf-8").write(text)
        doc = intake.load_requests(d)[0]
        assert doc["status"] == "draft" and doc["demoted_from"] == "checked" and "no readable record" in doc["demoted_why"], doc
        # ...and a run whose goal is another request
        os.makedirs(os.path.dirname(intake.run_record_path("r1", d)), exist_ok=True)
        json.dump({"goal": "something else"}, open(intake.run_record_path("r1", d), "w", encoding="utf-8"))
        doc = intake.load_requests(d)[0]
        assert doc["status"] == "draft" and "did not check" in doc["demoted_why"], doc
        # bytes that no longer match the digest
        json.dump({"goal": intake.to_goal(s)}, open(intake.run_record_path("r1", d), "w", encoding="utf-8"))
        assert intake.load_requests(d)[0]["status"] == "checked"
        edited = open(path, encoding="utf-8").read().replace("adults with mCRPC", "adults with mHSPC")
        open(path, "w", encoding="utf-8").write(edited)
        doc = intake.load_requests(d)[0]
        assert doc["status"] == "draft" and "digest" in doc["demoted_why"], doc


def test_the_uat_rows_and_the_release_claims_say_what_is_true():
    import uat                                                               # noqa: PLC0415
    names = [c.name for c in uat.CHECKS]
    assert "Gate 1 source approval" not in names
    assert any(n.startswith("Gate 1 registration check") for n in names)
    assert any(n.startswith("approver identity") for n in names)
    assert sum(1 for n in names if "identity" in n) == 1, "one identity row, not two"
    assert "runner copies a `releases/" not in _read("platform/engine/audit.py")
    assert "holds only `.gitkeep` today" in _read("platform/engine/audit.py")
    assert "reserved and still empty" in _read("docs/REPO_STRUCTURE_AND_PROD_MIGRATION.md")


# ------------------------------------------------------------------ the person testing the pushed branch

def test_the_portal_creates_its_state_directory_and_offers_the_stand_up_as_a_preview():
    """What a person hit on the pushed branch (2026-09-04): RWDP_STATE_DIR pointed at a directory
    nobody had made and the first page crashed writing users.json into it; an admin found no way to
    start a product; an initiator was sent to an administrator; and a Status page with no snapshot
    said "no extraction yet" about a fixture carrying two hundred records. The state directory is
    created on first write (the snapshot tool's too); the portal gains a New product section that
    previews the stand-up and, in a LOCAL demo, runs the bound `new_product.py --apply` in the
    person's own checkout (deployed, it hands over the command); `start` is a permission the
    initiator holds; and the strip reads the files when there is no snapshot."""
    sys.path.insert(0, str(ROOT / "experiments" / "portal"))
    import identity                                                          # noqa: PLC0415
    with tempfile.TemporaryDirectory() as d:
        path = os.path.join(d, "state", "nested", "users.json")
        identity.save_users(path, [{"name": "admin", "role": "admin"}])
        assert json.load(open(path, encoding="utf-8"))[0]["role"] == "admin"
    snap = _read("platform/tools/governance_snapshot.py")
    body = snap.split("def write(", 1)[1]
    assert body.index("os.makedirs(") < body.index('open(os.path.abspath(path), "w"')
    app = _read("experiments/portal/app.py")
    assert "identity.save_users(USERS_PATH, users)" in app
    assert '"New product"' in app and 'if section == "New product":' in app
    block = app.split('if section == "New product":', 1)[1].split('if section == "Agent":', 1)[0]
    assert 'can("start")' in block and "start" in app.split("PERMISSIONS = {", 1)[1].split("\n}\n", 1)[0]
    for role in ("initiator", "qc_programmer", "admin"):
        assert re.search(rf'"{role}":\s*\{{[^}}]*"start"', app), role
    assert not re.search(r'"(viewer|reviewer)":\s*\{[^}]*"start"', app)
    # Preview never carries --apply; writing is allowed in local/demo mode, only
    # after the same arguments previewed clean; deployed, the person gets the exact command
    assert "_new_product([], " in block and '_new_product(["--apply"], ' in block
    assert 'LOCAL_WRITES = MODE in {"local", "demo"}' in app
    assert block.index("if LOCAL_WRITES:") < block.index('_new_product(["--apply"], ')
    assert "st.session_state.np_previewed == tuple(argv)" in block
    assert 'shlex.join(_cmd + ["--apply"])' in block and "not LOCAL_WRITES" in block
    # no snapshot: the strip reads the files and says the verdict is not evaluated
    import queues                                                            # noqa: PLC0415
    sys.path.insert(0, str(TOOLS))
    import contract_lint as cl                                               # noqa: PLC0415
    assert queues.records_on_disk(str(ROOT / PROSTATE)) == sum(1 for _ in cl.records(cl.read(str(ROOT / PROSTATE / "handoff" / "FUNCTIONAL_CONTRACT.md"))))
    steps = {s["name"]: s for s in queues.lifecycle(None, open_questions=24, records=202, fixture=True)}
    assert steps["Specification"]["state"] == "done" and "202 contract record" in steps["Specification"]["why"]
    assert steps["Configuration"]["why"] == queues.NO_SNAPSHOT and "no extraction" not in str(steps)
    assert "never builds or releases" in steps["Release"]["why"]
    assert "queues.records_on_disk(os.path.join(ROOT, pack))" in app and "ui.NO_SNAPSHOT_STRIP" in app
    for flag in ("--condition-class", "--modality", "--disease-terms", "--tumour-family", "--next-cut-of", "--change-class"):
        assert flag in block, flag
    import ui_text                                                           # noqa: PLC0415
    assert "Nothing is written from here" in ui_text.NEW_PRODUCT_CAPTION_DEPLOYED
    assert "writes the product into this checkout" in ui_text.NEW_PRODUCT_CAPTION
    # a slug that names a known tumour is steered to the second-product route with that tumour chosen
    assert "_known_family(" in block and "ui.known_tumour_hint(" in block and "ui.use_known_tumour(" in block
    assert "_ident(" in block and "ui.NEW_PRODUCT_NORMALISED" in block
    # the page is not about the selected pack: no banner, counters, watermark or strip above the form
    page_rule = next(n.value for n in ast.parse(app).body if isinstance(n, ast.Assign)
                     and any(isinstance(t, ast.Name) and t.id == "PACK_PAGE" for t in n.targets))
    for page, expected in (("New product", False), ("Home", False), ("Plan changes", False), ("Flow", True)):
        assert eval(compile(ast.Expression(page_rule), "<page-rule>", "eval"), {"section": page}) is expected
    # the entry point is first: a start button at the top of the sidebar, one picker with names
    # (products first, references after), no view radio, and a checkout with no products opens on it
    assert "st.sidebar.button(ui.START_PRODUCT" in app and 'st.sidebar.radio("View"' not in app
    assert "format_func=lambda p: portal_packs.label(p, _CAT)" in app
    picker_rule = next(n.value for n in ast.parse(app).body if isinstance(n, ast.Assign)
                       and any(isinstance(t, ast.Name) and t.id == "_offered" for t in n.targets))
    for show in (False, True):
        actual = eval(compile(ast.Expression(picker_rule), "<product-picker>", "eval"),
                      {"_products": ["working"], "_references": ["example"], "_show_references": show})
        assert actual == (["working", "example"] if show else ["working"])
    assert 'st.session_state.setdefault("section", "Home")' in app and 'if section == "Home":' in app
    import portal_packs                                                      # noqa: PLC0415
    cat = {"products": ["products/oncology/kidney/202609"], "references": [PROSTATE]}
    assert portal_packs.label("products/oncology/kidney/202609", cat) == "Kidney 202609"
    assert portal_packs.label(PROSTATE, cat) == "Prostate 202606 (reference)"
    assert portal_packs.label("fixtures/oncology/oc/202606", cat) == "OC 202606 (reference)"
    assert "You can start products" in ui_text.role_line("initiator", ["start"]) and "run_gates" not in ui_text.role_line("admin", ["run_gates"])
    for needle in ("if LOCAL_WRITES and BADGE and PACK_PAGE:", "if _header_slot is not None:\n    _rows, _step, _checked, _source = _stage_rows(pack)",
                   "if section != \"Status\":\n        raise _NotAPackPage()"):
        assert needle in app, needle
    # NO HARD-CODED PATHS OR INTERPRETER: the command a person copies names the interpreter this
    # platform documents for their OS and the tool by its checkout-relative path with the OS separator
    assert "_PY = " in block and 'os.path.join("platform", "tools", "new_product.py")' in block
    assert '"python3", "platform/tools/new_product.py"' not in block
    # workbooks are offered from the checkout or uploaded into the portal's own upload folder (2026-09-07); never typed as a path
    assert "_workbooks(" in block and "_uploaded_workbook(" in block and "st.file_uploader" in app, "workbooks are offered or uploaded, not typed"


def test_the_deployed_portal_proposes_a_branch_and_a_pull_request_and_hides_the_operators_sections():
    """Deployed, the portal owns no checkout: the stand-up runs on a fresh clone, lands on a branch,
    and a pull request is opened for a person to review and merge — never a file on the app, never a
    merge. Proven against a local bare repository and a stubbed GitHub API. And the sidebar shows a
    scientist four sections; the operator's five sit behind one toggle."""
    sys.path.insert(0, str(ROOT / "experiments" / "portal"))
    import git_write                                                         # noqa: PLC0415
    import ui_text                                                           # noqa: PLC0415
    assert git_write.owner_repo("https://github.com/example-org/example-repository") == "example-org/example-repository"
    assert git_write.owner_repo("https://github.com/example-org/example-repository.git") == "example-org/example-repository"
    assert git_write.owner_repo("https://example.invalid/x.git") is None
    assert git_write.authed_url("https://github.com/o/r.git", "tok") == "https://x-access-token:tok@github.com/o/r.git"
    assert git_write.authed_url("file:///tmp/x", "tok") == "file:///tmp/x"
    with tempfile.TemporaryDirectory() as d:
        bare = os.path.join(d, "remote.git")
        seed = os.path.join(d, "seed")
        _git(d, "init", "-q", "--bare", bare)
        os.makedirs(seed)
        _repo(seed)
        Path(seed, "README.md").write_text("seed\n", encoding="utf-8")
        _git(seed, "add", "-A"); _git(seed, "commit", "-qm", "seed"); _git(seed, "branch", "-M", "main")
        _git(seed, "remote", "add", "origin", bare); _git(seed, "push", "-q", "origin", "main")

        def work_ok(clone):
            Path(clone, "products").mkdir(exist_ok=True)
            Path(clone, "products", "new.yaml").write_text("slug: kidney\n", encoding="utf-8")
            return 0, "WROTE 1 file(s)"
        ok, out, sha = git_write.clone_and_push(bare, None, "portal/new-product-kidney-1", work_ok, base="main")
        assert ok and sha and "WROTE" in out, out
        heads = subprocess.run(["git", "-C", bare, "branch", "--list"], capture_output=True, text=True, encoding="utf-8").stdout
        assert "portal/new-product-kidney-1" in heads and "main" in heads, heads
        shown = subprocess.run(["git", "-C", bare, "show", "portal/new-product-kidney-1:products/new.yaml"],
                               capture_output=True, text=True, encoding="utf-8").stdout
        assert shown == "slug: kidney\n"
        # a failed stand-up pushes nothing; a stand-up that wrote nothing pushes nothing; a bad branch name is refused
        ok, out, sha = git_write.clone_and_push(bare, None, "portal/x-2", lambda c: (1, "REFUSED"), base="main")
        assert not ok and sha is None and "REFUSED" in out
        ok, out, sha = git_write.clone_and_push(bare, None, "portal/x-3", lambda c: (0, "nothing"), base="main")
        assert not ok and "nothing to propose" in out
        ok, out, sha = git_write.clone_and_push(bare, None, "../evil", work_ok, base="main")
        assert not ok and "not a usable name" in out
        heads = subprocess.run(["git", "-C", bare, "branch", "--list"], capture_output=True, text=True, encoding="utf-8").stdout
        assert "x-2" not in heads and "x-3" not in heads and "evil" not in heads
    calls = []

    def http_ok(url, data, headers):
        calls.append((url, data, headers)); return 201, {"html_url": "https://github.com/o/r/pull/7"}
    url, why = git_write.open_pull_request("https://github.com/o/r.git", "tok", "portal/b", "t", "b", http=http_ok)
    assert url == "https://github.com/o/r/pull/7" and why is None
    assert calls[0][0] == "https://api.github.com/repos/o/r/pulls" and calls[0][1]["head"] == "portal/b" \
        and calls[0][1]["base"] == "main" and calls[0][2]["Authorization"] == "Bearer tok"
    url, why = git_write.open_pull_request("https://github.com/o/r.git", "tok", "portal/b", "t", "b",
                                           http=lambda *a: (422, {"message": "Validation Failed"}))
    assert url is None and "422" in why and "portal/b is pushed" in why
    url, why = git_write.open_pull_request("https://example.invalid/x.git", "tok", "portal/b", "t", "b", http=http_ok)
    assert url is None and "not a GitHub repository" in why
    # the page: the pull-request write lives in the deployed branch only, after a clean preview; the
    # local demo keeps its checkout write; the sidebar shows four sections and a toggle for the rest
    app = _read("experiments/portal/app.py")
    block = app.split('if section == "New product":', 1)[1].split('if section == "Agent":', 1)[0]
    assert "if not LOCAL_WRITES and _git_configured():" in block and "git_write.clone_and_push(" in block \
        and "git_write.open_pull_request(" in block
    assert block.index("if not LOCAL_WRITES and _git_configured():") < block.index("git_write.clone_and_push(") < block.index("if LOCAL_WRITES:")
    assert 'st.session_state.get("np_previewed") == tuple(argv) and not missing' in block.split("git_write.clone_and_push(", 1)[0].rsplit("if not LOCAL_WRITES", 1)[1]
    assert "merge" not in _read("experiments/portal/git_write.py").split("def clone_and_push")[1].split("def _http")[0].replace("never merges", "")
    main_sections = next(ast.literal_eval(n.value) for n in ast.parse(app).body if isinstance(n, ast.Assign)
                         and any(isinstance(t, ast.Name) and t.id == "MAIN_SECTIONS" for t in n.targets))
    assert {"Home", "Flow", "Status", "Open questions", "Search & definitions", "Studies", "New product", "Plan changes"} <= set(main_sections)
    assert not {"Run gates", "Eval corpus", "Agent"} & set(main_sections)
    assert "st.sidebar.toggle(ui.MORE_TOGGLE" in app and "format_func=lambda s: ui.SECTION_LABELS.get(s, s)" in app
    assert set(ui_text.SECTION_LABELS) == {"Home", "Status", "New product", "Open questions", "Waiting on a person",
                                           "Search & definitions", "Studies", "Run gates", "Walkthrough", "Evidence packets", "Agent",
                                           "Eval corpus", "Flow", "Plan changes"}


if __name__ == "__main__":
    console.use_utf8()
    failures = 0
    for name, fn in sorted(globals().items()):
        if name.startswith("test_") and callable(fn):
            try:
                fn()
                print(f"  ok   {name}")
            except Exception:                                                # noqa: BLE001
                failures += 1
                print(f"  FAIL {name}")
                traceback.print_exc()
    print(f"{failures} failure(s)")
    sys.exit(1 if failures else 0)
