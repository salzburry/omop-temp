"""Local signatures use the canonical ledger; no real reviewer keys or products."""
from pathlib import Path
import sys

import pytest
import yaml

ROOT = Path(__file__).resolve().parents[2]
sys.path[:0] = [str(ROOT / "experiments/portal"), str(ROOT / "platform/tools"),
               str(ROOT / "platform"), str(ROOT / "platform/tests")]
from _epi_gist_fixture import PACK, seed_gist
from test_approval_record import RELEASE_FORM, _key, _keypair, _register
import approval_attestation as signing

ACTOR = "local-reviewer-session"


@pytest.fixture
def prepared(tmp_path):
    root = tmp_path / "checkout"
    root.mkdir()
    product = seed_gist(root)
    form = product / "handoff/RELEASE_APPROVAL.yaml"
    form.write_text(RELEASE_FORM, encoding="utf-8")
    event, error = signing.approvals.record_event(str(root), PACK, "release", "2026-09-05T10:00:00Z")
    assert error is None, error
    private, public = _keypair()
    _register(root, _key("review-key", public))
    path = tmp_path / "review-key.private"
    path.write_bytes(private.hex().encode())
    return root, path, event


def describe(root):
    return signing.describe(root, PACK, ACTOR, allowed_packs=[PACK])


def attest(root, path, **changes):
    values = dict(expected_digest=describe(root)["digest"], key_id="review-key", private_key_path=str(path),
                  confirmed=True, local_demo=True, can_review=True, allowed_packs=[PACK])
    return signing.attest(root, PACK, ACTOR, **(values | changes))


def files(root):
    return {path.relative_to(root).as_posix(): path.read_bytes() for path in root.rglob("*") if path.is_file()}


def test_real_canonical_signature_verifies_exact_event_preserves_approval(prepared):
    root, path, event = prepared
    before = files(root)
    report = describe(root)
    assert report["ok"] and not report["findings"], report
    assert report["event_sha256"] == event["event_sha256"] and report["trust"] == "typed"
    result = attest(root, path)
    assert result["ok"] and result["changed"] and result["signature_verified"], result
    assert result["authenticated"] is False and result["identity_authenticated"] is False
    assert not result["warning"]
    verified = signing.ledger.verify_attestation(str(root), event["object_uuid"])
    assert verified["authenticated"][event["event_sha256"]] == ["review-key"]
    after = files(root)
    changed = {name for name, raw in before.items() if after[name] != raw}
    assert changed == {"governance/events/HEAD_CHECKPOINTS.yaml"}, "only the canonical checkpoint advances"
    new = set(after) - set(before)
    assert len(new) == 1 and next(iter(new)).startswith("governance/events/"), new
    assert path.read_text() not in str(result) and path.read_text().encode() not in b"".join(after.values())


def test_self_registered_event_signature_cannot_clear_release_identity(prepared):
    import source_manifest
    root, path, event = prepared
    registry = root / signing.ledger.SIGNING_KEYS
    doc = yaml.safe_load(registry.read_text(encoding="utf-8"))
    for entry in doc["keys"]:
        entry["registered_by"] = entry["person"]
    registry.write_text(yaml.safe_dump(doc), encoding="utf-8")
    result = attest(root, path)
    assert result["ok"] and result["signature_verified"] and not result["authenticated"]
    assert signing.ledger.verify_attestation(str(root), event["object_uuid"])["authenticated"]
    allowed, findings = source_manifest.releasable(str(root), PACK)
    assert not allowed
    assert any(message.startswith("Gate 6:") and "not authenticated" in message for message in findings), findings


@pytest.mark.parametrize("change", [{"can_review": False}, {"local_demo": False}, {"confirmed": False},
                                  {"allowed_packs": []}, {"expected_digest": "stale"}, {"key_id": "unregistered"},
                                  {"private_key_path": "relative-key"}])
def test_refusals_before_private_read_or_append(prepared, change, monkeypatch):
    root, path, _event = prepared
    before = files(root)
    original = Path.open
    def guard(self, *args, **kwargs):
        if self == path:
            pytest.fail("private key was opened before metadata and permission guards")
        return original(self, *args, **kwargs)
    monkeypatch.setattr(Path, "open", guard)
    result = attest(root, path, **change)
    assert not result["ok"] and not result["changed"], result
    assert files(root) == before


def test_private_key_inside_checkout_and_wrong_private_key_refused(prepared):
    root, path, _event = prepared
    internal = root / "unsafe-key.private"
    internal.write_bytes(path.read_bytes())
    before = files(root)
    assert not attest(root, internal)["ok"]
    assert files(root) == before
    wrong, _public = _keypair()
    path.write_bytes(wrong)
    result = attest(root, path)
    assert not result["ok"] and "not the key registered" in " ".join(result["errors"])
    assert files(root) == before


@pytest.mark.parametrize("where", ["approval", "registry", "product", "event", "checkpoint"])
def test_stale_signature_review_refuses_changed_inputs(prepared, where):
    root, path, event = prepared
    report = describe(root)
    target = {"approval": root / PACK / "handoff/RELEASE_APPROVAL.yaml",
              "registry": root / "governance/SIGNING_KEYS.yaml",
              "product": root / PACK / "config/pipeline.yaml",
              "checkpoint": root / "governance/events/HEAD_CHECKPOINTS.yaml",
              "event": next((root / "governance/events" / event["object_uuid"]).glob("*.yaml"))}[where]
    target.write_bytes(target.read_bytes() + b"\n# changed after review\n")
    before = files(root)
    result = attest(root, path, expected_digest=report["digest"])
    assert not result["ok"] and "changed" in " ".join(result["errors"])
    assert files(root) == before


def test_form_edited_after_seal_and_revoked_key_are_blocked(prepared):
    root, path, _event = prepared
    form = root / PACK / "handoff/RELEASE_APPROVAL.yaml"
    raw = form.read_text(encoding="utf-8")
    form.write_text(raw.replace("approved_build_id: b1", "approved_build_id: b2"), encoding="utf-8")
    report = describe(root)
    assert any("edited after" in finding for finding in report["findings"])
    assert not attest(root, path)["ok"]
    form.write_text(raw, encoding="utf-8")
    registry = root / "governance/SIGNING_KEYS.yaml"
    doc = yaml.safe_load(registry.read_text())
    doc["keys"][0]["status"] = "revoked"
    registry.write_text(yaml.safe_dump(doc), encoding="utf-8")
    assert not describe(root)["keys"]
    assert not attest(root, path)["ok"]


def test_post_append_verification_failure_reports_recorded_signature(prepared, monkeypatch):
    root, path, _event = prepared
    original = signing.approvals.attest
    def append_then_break(*args, **kwargs):
        result = original(*args, **kwargs)
        monkeypatch.setattr(signing.ledger, "verify_attestation", lambda *a, **k: (_ for _ in ()).throw(OSError("unavailable")))
        return result
    monkeypatch.setattr(signing.approvals, "attest", append_then_break)
    result = attest(root, path)
    assert result["ok"] and result["changed"] and not result["authenticated"]
    assert "signature was recorded" in result["warning"]


def test_repeat_signature_is_idempotent_and_does_not_claim_another_write(prepared):
    root, path, _event = prepared
    assert attest(root, path)["changed"]
    before = files(root)
    repeated = attest(root, path)
    assert repeated["ok"] and not repeated["changed"] and repeated["signature_verified"]
    assert repeated["authenticated"] is False
    assert files(root) == before


def test_tampered_event_content_is_refused_by_canonical_chain_check(prepared):
    root, path, event = prepared
    target = next((root / "governance/events" / event["object_uuid"]).glob("*.yaml"))
    doc = yaml.safe_load(target.read_text())
    doc["occurred_at"] = "2026-09-05T11:00:00Z"
    target.write_text(yaml.safe_dump(doc), encoding="utf-8")
    report = describe(root)
    assert report["ok"] and report["findings"]
    before = files(root)
    result = attest(root, path)
    assert not result["ok"] and files(root) == before
