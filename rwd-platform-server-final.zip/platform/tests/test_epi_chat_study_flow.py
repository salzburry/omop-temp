"""Conversation continuity through the actual guide and existing draft forms."""
from __future__ import annotations

import json
from pathlib import Path
import sys

import pytest

ROOT = Path(__file__).resolve().parents[2]
sys.path[:0] = [str(ROOT / path) for path in
               ("platform/tests", "experiments/portal", "platform/tools", "experiments/agent")]
import flow_assistant as guide
import scientific_conversation_context as evidence
from test_epi_chat_integration import ACTOR, PACK, Model, reference
from test_epi_chat_integration import main_app, enabled, setup
from test_epi_flow_assistant import _card
from test_epi_conversation_intake import question as brief_question
import flow_assistant_page as page
import conversation_intake as brief_api


@pytest.mark.parametrize("reply", ["1C", "C", "2", "not sure", "I don't know", "Why?", "What about follow-up?"])
def test_short_followup_retrieves_original_topic_without_using_model_claims(monkeypatch, reply):
    queries = []
    def lookup(**kwargs):
        queries.append(kwargs["query"])
        return reference()
    monkeypatch.setattr(evidence, "build_chat", lookup)
    history = [{"question": "Compare PD-L1 reference entries for this study",
                "answer": "Model-claimed invented_code must not become a retrieval source."},
               {"question": "Not sure", "answer": "One earlier follow-up."}]
    model = Model()
    result = guide.answer(reply, _card(), root=ROOT, model=model, history=history,
        actor_id=ACTOR, allowed_packs=[PACK], task_scope={"pack": PACK})
    assert result["source"] == "assistant"
    assert len(queries) == 2 and queries[0] == queries[1]
    assert "PD-L1" in queries[0] and "invented_code" not in queries[0]
    assert model.calls[0][1]["question"] == reply


def test_new_substantive_topic_does_not_retrieve_the_previous_study():
    history = [{"question": "Discuss NSCLC with docetaxel", "answer": "Earlier discussion"}]
    question = "Start a different study about colorectal procedure definitions"
    assert guide.retrieval_query(question, history) == question


def test_short_followup_cannot_reuse_history_from_another_selected_study(monkeypatch):
    queries = []
    monkeypatch.setattr(evidence, "build_chat", lambda **kw: queries.append(kw["query"]) or reference())
    card = {**_card(), "study_context": {"study_id": "current"}}
    earlier = {**_card(), "study_context": {"study_id": "earlier"}}
    history = [{"question": "Discuss NSCLC with docetaxel", "answer": "Prior study",
                "context_reference": guide.history_reference(earlier)}]
    result = guide.answer("1C", card, root=ROOT, model=Model(), history=history,
        actor_id=ACTOR, allowed_packs=[PACK], task_scope={"pack": PACK})
    assert result["source"] == "assistant"
    assert queries == ["1C", "1C"]


def test_retrieval_terms_are_bounded_and_current_brief_is_available_without_history():
    query = guide.retrieval_query("Not sure", brief_terms="NSCLC treatment cohort; source choice unresolved")
    assert "NSCLC" in query
    assert len(guide.retrieval_query("x" * 8000, brief_terms="y" * 8000)) <= 4000


def test_single_question_object_from_live_model_is_normalized_and_fully_validated():
    q = brief_question("index_definition")
    raw = json.dumps({"answer": "Choose the index event.", "actions": [], "questions": q})
    parsed = guide._parse_model(raw, _card(), study_brief={"request": {}})
    assert parsed["questions"] == [q]
    q["id"] = "approve_contract"
    with pytest.raises(ValueError):
        guide._parse_model(json.dumps({"answer": "Choose.", "questions": q}), _card(), study_brief={"request": {}})
    with pytest.raises(ValueError):
        guide._parse_model(raw, _card())


def test_study_prompt_explains_executable_mcq_shape_and_keeps_uncertainty():
    prompt = brief_api.prompt_instructions()
    assert '"questions":[' in prompt and "2-4 options" in prompt
    assert "not only prose" in prompt and "Keep unknowns open" in prompt


def test_brief_accepts_bounded_descriptive_choice_ids_from_live_model():
    q = brief_question("index_definition")
    q["options"][0]["id"] = "first_docetaxel_after_prior_regimen"
    q["options"][1]["id"] = "first_docetaxel_any_prior_treatment"
    raw = json.dumps({"answer": "Choose the index concept.", "questions": [q]})
    parsed = guide._parse_model(raw, _card(), study_brief={"request": {}})
    assert parsed["questions"] == [q]
    # The original row/decision adapter keeps its original default bound.
    with pytest.raises(ValueError):
        brief_api.ai._questions([q])
    q["options"][0]["id"] = "x" * 129
    with pytest.raises(ValueError):
        guide._parse_model(json.dumps({"answer": "Choose.", "questions": [q]}), _card(), study_brief={"request": {}})


def test_main_chat_keeps_brief_mcq_answers_across_rerenders_and_restart(enabled, monkeypatch):
    root, _calls = enabled
    monkeypatch.delenv("RWDP_STATE_DIR", raising=False)
    real_answer = guide.answer
    q = brief_question("index_definition")
    q["prompt"] = "Which index event should this synthetic study use?"
    q["options"] = [{"id": "a", "label": "First recorded treatment", "explanation": "Treatment-based index."},
                    {"id": "b", "label": "First recorded diagnosis", "explanation": "Diagnosis-based index."},
                    {"id": "c", "label": "Protocol date still to specify", "explanation": "Requires a study date."}]
    class Journey(Model):
        def step(self, system, messages):
            data = json.loads(messages[0]["content"])
            self.calls.append(data)
            if len(self.calls) == 1:
                return json.dumps({"answer": "I retained your population. Choose the index event below.", "actions": [],
                    "brief_updates": [{"slot": "population", "value": "Adults with NSCLC", "quote": "Adults with NSCLC"}], "questions": [q]})
            return json.dumps({"answer": "Your selected index is in the draft. Source mapping still needs review.", "actions": []})
    model = Journey()
    monkeypatch.setattr(guide, "answer", lambda *args, **kwargs: real_answer(*args, **{**kwargs, "model": model}))
    at = main_app(root, monkeypatch)
    at.text_area(key="purpose").set_value("Keep my unfinished form wording").run()
    # This embedded form exercises study planning; actual registration/navigation
    # is covered by the app handoff test rather than this fixed-page fixture.
    at.chat_input[0].set_value("Help plan my study population: Adults with NSCLC").run()
    assert not at.exception, [item.message for item in at.exception]
    assert len(model.calls) == 1
    assert any(item.label == "Choose an answer" for item in at.radio)
    at.chat_input[0].set_value("1C").run()
    assert not at.exception, [item.message for item in at.exception]
    assert len(model.calls) == 2
    latest = model.calls[-1]
    assert latest["question"] == "1C"
    assert latest["study_brief"]["request"]["population"] == "Adults with NSCLC"
    assert latest["study_brief"]["request"]["index_definition"] == "Protocol date still to specify"
    assert "My answer: Protocol date still to specify" in latest["study_brief"]["current_answer"]
    assert at.text_area(key="purpose").value == "Keep my unfinished form wording"
    at.run()
    assert len(model.calls) == 2 and not at.exception
    restarted = main_app(root, monkeypatch)
    assert not restarted.exception, [item.message for item in restarted.exception]
    assert any("Adults with NSCLC" in str(item.value) for item in restarted.dataframe)
    assert len(model.calls) == 2


def test_main_chat_mcq_control_sends_exact_current_choice_once(enabled, monkeypatch):
    root, _calls = enabled
    monkeypatch.delenv("RWDP_STATE_DIR", raising=False)
    from test_epi_chat_integration import PROVIDER
    options = page._brief_options(root, PACK, _card(), PROVIDER, actor_id=ACTOR, allowed_packs=[PACK])
    brief = brief_api.new(root, PACK, ACTOR, allowed_packs=[PACK], **options)
    brief = brief_api.apply_reply(brief, {"questions": [brief_question()]}, user_text="Describe the population")
    brief_api.save(root, PACK, ACTOR, brief, allowed_packs=[PACK], can_write=True)
    real_answer = guide.answer
    model = Model({"answer": "Your chosen population is retained as draft wording.", "actions": []})
    monkeypatch.setattr(guide, "answer", lambda *args, **kwargs: real_answer(*args, **{**kwargs, "model": model}))
    at = main_app(root, monkeypatch)
    next(item for item in at.radio if item.label == "Choose an answer").set_value("b")
    next(item for item in at.button if item.label == "Send this answer").click().run()
    assert not at.exception, [item.message for item in at.exception]
    assert len(model.calls) == 1
    assert model.calls[0][1]["study_brief"]["request"]["population"] == "Adults with documented advanced disease"
    at.run()
    assert len(model.calls) == 1 and not at.exception


def test_main_prefill_only_reply_updates_the_form_and_same_private_brief(enabled, monkeypatch):
    from streamlit.testing.v1 import AppTest
    from test_epi_chat_integration import PROVIDER
    root, _calls = enabled
    monkeypatch.delenv("RWDP_STATE_DIR", raising=False)
    monkeypatch.setattr(page, "_provider_words", lambda *_: (dict(PROVIDER), "Scripted connection"))
    monkeypatch.setattr(brief_api.ai.definitions.cs, "ai_gate", lambda *_: None)
    monkeypatch.setattr(evidence, "build_chat", lambda **_: reference())
    desired = "Adults with colorectal cancer undergoing cancer-directed resection."
    class FormOnly(Model):
        def step(self, system, messages):
            data = json.loads(messages[0]["content"])
            self.calls.append(data)
            public = data["context"]["editable_form"]
            identifier = next(field["id"] for field in public["fields"] if field["label"] == "Population")
            return json.dumps({"answer": "The population wording is prepared for review.", "actions": [],
                "prefill": {"scope": public["scope"], "fields": [{"id": identifier, "value": desired}]}})
    model = FormOnly()
    real_answer = guide.answer
    monkeypatch.setattr(guide, "answer", lambda *args, **kwargs: real_answer(*args, **{**kwargs, "model": model}))
    code = f'''
import streamlit as st
import flow_assistant_page as page
import form_assistance as forms
from test_epi_flow_assistant import _card
forms.begin({str(root)!r}, {PACK!r}, {ACTOR!r}, page="Study design", allowed_packs={[PACK]!r}, can_write=True)
page.render({str(root)!r}, {PACK!r}, card=_card(), actor_id={ACTOR!r}, primary=True,
    local_demo=True, can_agent=True, can_write=True, allowed_packs={[PACK]!r})
forms.field(st.text_area, "Population", key="population")
forms.field(st.text_area, "Acceptance criteria", key="criteria", value="Keep this manual criterion")
forms.finish()
'''
    at = AppTest.from_string(code, default_timeout=35).run()
    at.chat_input[0].set_value("Set the population to: " + desired).run()
    assert not at.exception, [item.message for item in at.exception]
    assert len(model.calls) == 1
    assert at.text_area(key="population").value == desired
    assert at.text_area(key="criteria").value == "Keep this manual criterion"
    options = page._brief_options(root, PACK, _card(), PROVIDER, actor_id=ACTOR, allowed_packs=[PACK])
    saved = brief_api.load(root, PACK, ACTOR, allowed_packs=[PACK], **options)
    assert saved["state"]["request"]["population"] == desired
    at.run()
    assert len(model.calls) == 1 and not at.exception
