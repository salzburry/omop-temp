"""The Flow page reads every finding to a person in plain words (walks NC-16 and UC1-27, 2026-09-07).

NC-16   the progress page exposed file names, flags and internal ids in the blockers and step
        details (a report-writing command with its flags, approval file names, an act id such as
        g2_lint, the signing-key note); the raw line belongs under the technical handoff
UC1-27  act ids appeared as bare text in the Resolve dialog and the run list

    python platform/tests/test_epi_flow_plain_language.py
The page is rendered with Streamlit's AppTest over the real flow of the prostate fixture, the demo
pack and a stood-up scaffold in a disposable root; no governed write leaves a temporary root.
"""
from __future__ import annotations

import atexit
from pathlib import Path
import re
import shutil
import sys
import tempfile

sys.path.insert(0, str(Path(__file__).resolve().parent))
from _epi_test_support import api, run
pytest = api(__name__)
ROOT = Path(__file__).resolve().parents[2]
sys.path[:0] = [str(ROOT / "platform/tools"), str(ROOT / "experiments/portal"), str(ROOT / "platform/tests")]
import flow                                                                  # noqa: E402
import flow_guidance as guidance                                             # noqa: E402
import flow_page                                                             # noqa: E402
import _epi_gist_fixture as fixtures                                         # noqa: E402
from test_epi_flow_page import _action, _flow, _healthy, _open, _page, _visible_nodes, _visible_ui   # noqa: E402

PROSTATE = "fixtures/oncology/prostate/202606"
DEMO = "sandbox/demo_walkthrough/bladder/202609"
PACK = fixtures.PACK
PROSE = ("markdown", "text", "caption", "info", "subheader", "success", "warning", "error", "header", "title")

# THE TOKEN RULE, stated here independently of the page's own helper: a path (letters beside a
# slash, or a backslash), a command flag, a file name by its extension, a dash or an arrow used as
# punctuation. Dates ("2026-09-07"), fractions ("1 of 6") and product words pass.
_TOKEN = re.compile(r"[A-Za-z_]/|/[A-Za-z_]|\\|^--|\.(?:py|md|yaml|yml|json|conf|tsv|xlsx)$", re.I)


def technical(text):
    text = str(text)
    found = [mark for mark in (" — ", "->", "→", "↳") if mark in text]
    for token in text.split():
        bare = token.strip(".,;:()[]{}\"'`*")
        if bare and _TOKEN.search(bare):
            found.append(bare)
    return found


def _prose(nodes):
    return [(node.type, str(node.value)) for node in nodes if getattr(node, "type", "") in PROSE and hasattr(node, "value")]


def _all_nodes(block):
    yield block
    for child in getattr(block, "children", {}).values():
        yield from _all_nodes(child)


def _under(at, label):
    """Every node under the expander with this label, whether or not it is expanded."""
    for node in _all_nodes(at.main):
        if getattr(node, "type", "") == "expander" and getattr(node, "label", "") == label:
            yield from _all_nodes(node)
    for dialog in at.get("dialog"):
        for node in _all_nodes(dialog):
            if getattr(node, "type", "") == "expander" and getattr(node, "label", "") == label:
                yield from _all_nodes(node)


_FLOWS = []


def _real_flows():
    """(root, pack, flow) for the prostate fixture, the demo pack and a stood-up scaffold; evaluated
    once (the prostate gates take seconds) and never written to by a test (the page copies its result)."""
    if not _FLOWS:
        scaffold = tempfile.mkdtemp(prefix="epi-plain-scaffold-")
        atexit.register(shutil.rmtree, scaffold, True)
        fixtures.seed_gist(Path(scaffold))
        _FLOWS[:] = [(str(ROOT), PROSTATE, flow.flow(str(ROOT), PROSTATE)),
                     (str(ROOT), DEMO, flow.flow(str(ROOT), DEMO)),
                     (scaffold, PACK, flow.flow(scaffold, PACK))]
    return list(_FLOWS)


# the sentences the walk asked for ------------------------------------------------------------------

def test_the_common_findings_read_as_the_sentences_a_person_needs():
    said = guidance.blocker_copy
    assert said("Gate 1: products/oncology/x/202610/source_refs.yaml: classified_by=Asha Rao is not authenticated — "
                "no commit's diff wrote this approval").startswith("Asha Rao's classification has not been signed yet.")
    assert said("Gate 1: x/source_refs.yaml: approved_by=Asha Rao is not authenticated — the commit that wrote it is UNSIGNED") == \
        "Asha Rao's review of the specification has not been signed yet. The commit that recorded it carries no signature."
    assert said("Gate 2: x/handoff/DECISIONS.md: decision:ABSENT-LINE-CATEGORY=Alex Morgan is not authenticated — the commit "
                "that wrote it is UNSIGNED").startswith("Alex Morgan's answer to decision ABSENT-LINE-CATEGORY has not been signed yet.")
    assert said("Gate 2: x/handoff/CONTRACT_APPROVAL.yaml: approved_by=Ada Lovelace is not authenticated — no commit's diff wrote this") \
        .startswith("Ada Lovelace's approval of the scientific definitions has not been signed yet.")
    assert said("166 vendor-sourced record(s) have no Gate 3 evidence — MCRPCDD (source_mapping:proposed) and 164 more") == \
        "The delivered data has not been checked yet; that is the data expert's step. 166 definition(s) depend on it."
    assert said("(when claimed) x: configuration:approved but no handoff/SOURCE_VERDICTS.md — the status axes claim Gate 3 evidence "
                "that no report attests. Write it with `source_check.py x --profile <cut>.tsv --complete --out handoff/SOURCE_VERDICTS.md`.") == \
        "The delivered data report has not been prepared yet; the build configuration will need it once approved. That is the data expert's step."
    assert said("Gate 6: no handoff/RELEASE_APPROVAL.yaml — WORKFLOW.md requires a NAMED final approval before the public views move.") == \
        "The release needs a named final approval after the build."
    assert said("the checks below are what Gate 4 will require OF Gate 3, quoted as Gate 4 states them:").endswith("data expert's step.")
    assert said("Gate 2: contract is coverage_complete, not approved") == "The scientific definitions are complete for every specification row, not approved yet."
    assert said("Gate 4: configuration is draft, not approved") == "The build configuration is a draft, not approved yet."
    assert said("x: source_materials[0]: status:reviewed requires `document_id`") == "The recorded review is missing its document ID."
    assert said("contract_lint: handoff/ENGINE_GAPS.md is missing — write the register") == "The engine gaps register has not been created yet."
    assert said("x: contract:approved requires `approved_decisions_sha256` in handoff/CONTRACT_APPROVAL.yaml — an approval") == \
        "The approval of the scientific definitions is missing its approved decisions digest."
    assert said("Gates 1-4 are not all passed, so no build may be released (6 reason(s) above)") == \
        "Steps 1 to 4 have not all passed, so nothing can be released yet."
    assert said("no record has an approved requirement yet (202 record(s) drafted) — Gate 5 validates settled requirements") == \
        "None of the 202 drafted definition(s) has an agreed requirement yet; validation needs agreed requirements."
    assert said("") == "Review the current step with your product team."


def test_one_steps_repeated_findings_are_said_once_with_their_count():
    """RW4-N06: several of the checks' lines stood behind one sentence, and step 3 listed it three
    times; each sentence is said once, in the checks' order, with how many lines it covers."""
    lines = ["(when claimed) x: Gate 4 will require a delivered-data verdict for the treatment table",
             "Gate 4: configuration is draft, not approved",
             "(when claimed) x: Gate 4 will require a delivered-data verdict for the diagnosis table",
             "(when claimed) x: Gate 4 will require a delivered-data verdict for the biomarker table"]
    said = guidance.blocker_lines(lines)
    assert said == ["The build configuration approval will also need the source evidence the checks describe; "
                    "that is the data expert's step. That covers 3 lines of the checks.",
                    "The build configuration is a draft, not approved yet."], said
    for sentence in said:
        assert not technical(sentence), sentence
    assert guidance.blocker_lines([]) == [] and guidance.blocker_lines(None) == []
    assert guidance.blocker_lines([lines[1]]) == [guidance.blocker_copy(lines[1])], "one line, no count"


def test_a_finding_no_pattern_knows_is_scrubbed_never_shown_raw():
    line = "a brand new finding: run platform/tools/thing.py --flag over products/oncology/x/202610 and `git log -G`, then fix handoff/SOURCE_VERDICTS.md"
    said = guidance.blocker_copy(line)
    assert not technical(said), said
    assert "this product" in said and "the delivered data report" in said, said
    # a line that is nothing but technical tokens falls back to the one honest sentence
    assert guidance.blocker_copy("platform/tools/a.py --x C:\\temp\\b.yaml") == \
        "A check reported a technical finding; its exact wording is under the technical details."


def test_every_line_the_real_packs_report_reads_plain():
    for _root, pack, fl in _real_flows():
        assert fl["gates"], pack
        for gate in fl["gates"]:
            for line in gate["blockers"]:
                said = guidance.blocker_copy(line)
                assert said and not technical(said), (pack, line, said)
                assert guidance.technical_tokens(said) == [], (pack, said)
        # the tools' own proceed line carries no dash or arrow; the page says it in its words
        assert " — " not in fl["proceed"] and "->" not in fl["proceed"], fl["proceed"]
        assert not technical(flow_page._proceed(fl)), flow_page._proceed(fl)
        assert f"Step {fl['current']}" in flow_page._proceed(fl) and "Responsible team:" in flow_page._proceed(fl)
    assert flow_page._proceed({"clear": True, "gates": []}).startswith("All six checks pass")
    assert flow_page._proceed({}) == "Review the current step with your product team."


def test_files_and_acts_are_named_by_their_labels():
    assert guidance.file_label("products/oncology/x/202610/source_refs.yaml") == "the source register"
    assert guidance.file_label("products/oncology/x/202610/handoff/RELEASE_APPROVAL.yaml") == "the release approval form"
    assert guidance.file_label("products/oncology/x/202610/spec_pipeline/out/") == "the extraction output folder"
    assert guidance.file_label("governance/DEFINITIONS.yaml") == "the definitions register"
    assert guidance.file_label("somewhere/else.txt") == "the product's record file" and guidance.file_label("") == "the product's files"
    assert guidance.act_title("g2_lint") == "Check the scientific definitions"
    assert guidance.act_title("g3_run_2") == guidance.act_title("g3_run") == "Check the delivered data"
    assert guidance.act_title({"id": "g1_review", "recorded": True}) == "Correct the recorded review"
    assert guidance.act_title("not_an_act") == "Review the next requirement"
    for value in ("platform/tools/source_check.py --profile x.tsv", "handoff/RELEASE_APPROVAL.yaml", "g2_lint -> g2_draft", "a — b"):
        assert guidance.technical_tokens(value), value
    assert not guidance.technical_tokens("Asha Rao's classification has not been signed yet. 1 of 6 checks passed on 2026-09-07.")
    # the guidance's own copy carries no path: the workbook step used to print the folder and the record
    for aid in ("g1_workbook", "g1_review", "g1_commit", "g2_lint", "g3_run", "g6_approve"):
        copy = guidance.issue_copy({"id": aid, "kind": "person", "path": "products/oncology/x/202610/source_refs.yaml"})
        assert not technical(copy["title"]) and not technical(copy["summary"]), aid
        assert not any(technical(step) for step in copy["steps"]), (aid, copy["steps"])


# the page ---------------------------------------------------------------------------------------------

def test_the_flow_page_and_its_dialog_show_no_path_flag_or_file_name_outside_expanders():
    for root, pack, fl in _real_flows():
        with _page(fl, root=root, pack=pack) as (at, case):
            shown = _prose(_visible_nodes(at.main))
            assert shown, pack
            offending = [(kind, value, technical(value)) for kind, value in shown if technical(value)]
            assert not offending, (pack, offending)
            # the step details read each finding in plain words, whether or not the expander is open
            details = _prose(_under(at, "All six steps and check details"))
            assert details and any("1. Input specification" in value for _kind, value in details), (pack, details)
            assert not [value for _kind, value in details if technical(value)], (pack, details)
            assert any(f"{n}." in value for n in range(1, 7) for _kind, value in details)
            at.button(key="flow_resolve").click().run()
            _healthy(at)
            assert any(d.proto.dialog.is_open for d in at.get("dialog")), pack
            shown = _prose(_visible_ui(at))
            offending = [(kind, value, technical(value)) for kind, value in shown if technical(value)]
            assert not offending, (pack, offending)
            # ...and the raw lines are kept, word for word, under the technical handoff
            raw = [str(node.value) for node in _under(at, "Detailed instructions / technical handoff")
                   if getattr(node, "type", "") in ("code", "text")]
            assert raw, pack
            joined = "\n".join(raw)
            for gate in fl["gates"]:
                for line in gate["blockers"]:
                    assert line in joined, (pack, line)
            case.run_action.assert_not_called()


def test_the_dialog_names_acts_by_their_labels_never_their_ids():
    lint = _action("g2_lint", "read", "Lint the contract (every invariant)", ["platform/tools/contract_lint.py", "fixtures/oncology/gist/202608"])
    draft = _action("g2_draft", "person", "Draft or revise one record")
    registers = _action("g2_registers", "person", "Write the register(s) Gate 2 rests on: handoff/DECISIONS.md")
    result = _flow([lint, draft, registers])
    result["current"] = 2
    result["blockers"][0]["text"] = "Gate 2: contract is draft, not approved"
    for item in result["gates"]:
        item["state"] = "done" if item["gate"] < 2 else "blocked" if item["gate"] == 2 else "not_started"
    with _page(result, guard=lambda *args, **kwargs: "") as (at, case):
        _open(at)
        options = at.selectbox(key="flow_resolution_action").options
        assert options and not any(re.fullmatch(r"g\d_[a-z_]+", str(o)) for o in options), options
        assert "Check the scientific definitions" in options, options
        for kind, value in _prose(_visible_ui(at)):
            assert not re.search(r"\bg\d_[a-z_]+\b", value), (kind, value)
        at.button(key="flow_run_action").click().run()
        _healthy(at)
        assert case.run_action.call_count == 1
        at.button(key="flow_close").click().run()
        _healthy(at)
        activity = _prose(_under(at, "Activity and run details"))
        assert activity, "the run is listed"
        assert any(value == "Check the scientific definitions" for _kind, value in activity), activity
        assert not any(re.search(r"\bg\d_[a-z_]+\b", value) for _kind, value in activity), activity


def test_a_card_with_no_act_reads_its_finding_in_plain_words():
    result = _flow()
    result["blockers"][0]["fixes"] = []
    result["blockers"][0]["text"] = ("Gate 6: fixtures/oncology/gist/202608/handoff/RELEASE_APPROVAL.yaml: validated_by=Priya Nair is not "
                                     "authenticated — no commit's diff wrote this approval")
    with _page(result) as (at, case):
        _open(at)
        shown = [value for _kind, value in _prose(_visible_ui(at))]
        assert any(value.startswith("Priya Nair's validation of the candidate has not been signed yet.") for value in shown), shown
        assert not any("RELEASE_APPROVAL" in value for value in shown), shown
        case.run_action.assert_not_called()


if __name__ == "__main__":
    raise SystemExit(run(globals()))
