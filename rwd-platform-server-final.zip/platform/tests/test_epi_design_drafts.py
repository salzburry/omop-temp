"""Saved revision adversaries: temporary packs only, with no governed product edits."""
from __future__ import annotations

import copy
import hashlib
import json
import sys
import tempfile
from pathlib import Path
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "experiments/portal"))
import design_workspace as dw

PACK = "products/oncology/draft/202609"


def fixture(root, pack=PACK, empty=False):
    directory = Path(root) / pack
    (directory / "config").mkdir(parents=True)
    (directory / "handoff").mkdir()
    (directory / "config/data_product.yaml").write_text("name: Study product\nvendor: flatiron\nmodality: ehr\nsources:\n  enhanced: t_original\n", encoding="utf-8")
    (directory / "source_refs.yaml").write_text("approved_by: Original reviewer\nstatus: approved\n", encoding="utf-8")
    records = [] if empty else [
        ("INDEXDT", "study_period", "Index date as explicitly stated", "[]"),
        ("AGE", "demographics", "Age at index; unknown remains unknown", "[INDEXDT]"),
        ("OS", "outcomes", "Overall survival; original censoring rule", "[INDEXDT]"),
    ]
    (directory / "handoff/FUNCTIONAL_CONTRACT.md").write_text("\n".join(
        f"```yaml\nvariable_id: {identifier}\nspec_refs: [{domain}:1]\nrequired_rule: {definition}\ndepends_on: {depends}\nstatus: approved\napproved_by: Original reviewer\n```\n"
        for identifier, domain, definition, depends in records), encoding="utf-8")
    return directory


def inputs(**changes):
    result = {"purpose": "Support treatment patterns and outcomes studies", "studies": ["Treatment patterns", "Outcomes"],
              "retained": ["INDEXDT", "AGE"], "additions": [], "target_source": "flatiron", "target_modality": "ehr"}
    result.update(changes)
    return result


def save(root, values=None, pack=PACK, **kwargs):
    options = {"actor_id": "epi@example.test", "local_demo": True, "can_write": True,
               "allowed_packs": [pack], "expected_baseline": dw.describe(root, pack)["baseline_sha256"]}
    options.update(kwargs)
    return dw.save_draft(root, pack, inputs() if values is None else values, **options)


def original_bytes(root, pack=PACK):
    return {p.relative_to(root).as_posix(): p.read_bytes() for p in (Path(root) / pack).rglob("*")
            if p.is_file() and ".portal-drafts" not in p.relative_to(Path(root) / pack).parts}


def test_existing_product_materializes_exact_selected_definitions_without_approvals():
    with tempfile.TemporaryDirectory() as tmp:
        root = Path(tmp); fixture(root)
        before = original_bytes(root)
        import knowledge_search
        search_stamp = knowledge_search.tree_stamp(str(root))
        definition = "  Author's exact rule\n```\n<script>literal, not markup</script>\nUnknown stays unknown.  "
        result = save(root, inputs(additions=[{"variable_id": "BIOMARKER", "domain": "clinical", "definition": definition}]))
        assert result["ok"] and result["changed"] and result["version"] == 1, result
        folder = root / result["path"]
        projection = json.loads((folder / "DEFINITIONS.json").read_text(encoding="utf-8"))
        assert [v["variable_id"] for v in projection["variables"]] == ["INDEXDT", "AGE", "BIOMARKER"]
        assert projection["variables"][-1]["definition"] == definition
        assert not projection["variables"][-1]["dependencies_declared"]
        assert not projection["approval_carryover"] and not projection["executable"]
        assert "approved_by" not in json.dumps(projection)
        assert result["summary"]["before_count"] == result["summary"]["after_count"] == 3
        assert len(result["summary"]["studies"]) == 2
        assert original_bytes(root) == before
        assert set(p.name for p in folder.iterdir()) == {"plan.json", "DEFINITIONS.json", "DRAFT_SPECIFICATION.md"}
        assert knowledge_search.tree_stamp(str(root)) == search_stamp
        assert knowledge_search._contract_records(["Author's exact rule"], str(root)) == []
        import portal_links
        for artifact in folder.iterdir():
            reference = portal_links.resolve(root, artifact.relative_to(root).as_posix(), allowed_packs=[PACK])
            assert reference["kind"] == "blocked", reference


def test_new_empty_product_and_reference_template_save_without_false_approval():
    with tempfile.TemporaryDirectory() as tmp:
        root = Path(tmp); fixture(root, empty=True)
        addition = {"variable_id": "POP", "domain": "study_population", "definition": "Proposed tumor population; inclusion criteria require review"}
        result = save(root, inputs(retained=[], additions=[addition]))
        assert result["ok"] and result["summary"]["before_count"] == 0 and result["summary"]["after_count"] == 1
        template = "fixtures/oncology/template/202609"
        fixture(root, template)
        before = original_bytes(root, template)
        reused = save(root, pack=template)
        assert reused["ok"] and reused["plan"]["is_reference"]
        assert any("never clinical approval" in warning for warning in reused["plan"]["warnings"])
        assert original_bytes(root, template) == before


def test_resume_version_history_source_change_and_noop_are_immutable():
    with tempfile.TemporaryDirectory() as tmp:
        root = Path(tmp); fixture(root)
        first = save(root); before = {p.name: p.read_bytes() for p in (root / first["path"]).iterdir()}
        loaded = dw.load_draft(root, PACK, actor_id="epi@example.test", allowed_packs=[PACK], draft_id=first["draft_id"])
        assert loaded["ok"] and not loaded["stale"] and loaded["inputs"] == inputs()
        same = save(root, loaded["inputs"], draft_id=first["draft_id"], expected_version=1)
        assert same["ok"] and not same["changed"] and same["version"] == 1
        second = save(root, inputs(target_source="optum", target_modality="claims"), draft_id=first["draft_id"], expected_version=1)
        assert second["ok"] and second["version"] == 2 and second["plan"]["classification"] == "breaking"
        assert "cohort attrition" in " ".join(second["plan"]["review_checklist"])
        assert {p.name: p.read_bytes() for p in (root / first["path"]).iterdir()} == before
        listing = dw.list_drafts(root, PACK, actor_id="epi@example.test", allowed_packs=[PACK])
        assert [d["version"] for d in listing["drafts"]] == [2, 1]
        stale_writer = save(root, inputs(purpose="Concurrent window"), draft_id=first["draft_id"], expected_version=1)
        assert not stale_writer["ok"] and "newer draft" in stale_writer["errors"][0]
        old = dw.load_draft(root, PACK, actor_id="epi@example.test", draft_id=first["draft_id"], version=1)
        assert old["ok"] and old["latest_version"] == 2 and old["inputs"] == inputs()


def test_stale_baseline_blocks_save_and_reopen_reports_change():
    with tempfile.TemporaryDirectory() as tmp:
        root = Path(tmp); folder = fixture(root)
        first = save(root)
        digest = first["plan"]["baseline_sha256"]
        cfg = folder / "config/data_product.yaml"
        cfg.write_text(cfg.read_text(encoding="utf-8") + "delivery: next\n", encoding="utf-8")
        denied = save(root, draft_id=first["draft_id"], expected_version=1, expected_baseline=digest)
        assert not denied["ok"] and "starting product changed" in denied["errors"][0]
        loaded = dw.load_draft(root, PACK, actor_id="epi@example.test", draft_id=first["draft_id"])
        assert loaded["ok"] and loaded["stale"]
        assert len(dw.list_drafts(root, PACK, actor_id="epi@example.test")["drafts"]) == 1


def test_scope_actor_auth_and_path_guards_do_not_leak_or_mutate():
    with tempfile.TemporaryDirectory() as tmp:
        root = Path(tmp); fixture(root)
        for options in ({"can_write": False}, {"local_demo": False}, {"actor_id": ""},
                        {"allowed_packs": []}, {"expected_baseline": ""}):
            assert not save(root, **options)["ok"], options
        assert not (root / PACK / ".portal-drafts").exists()
        first = save(root)
        assert dw.list_drafts(root, PACK, actor_id="other@example.test")["drafts"] == []
        assert not dw.load_draft(root, PACK, actor_id="other@example.test", draft_id=first["draft_id"])["ok"]
        assert not dw.load_draft(root, PACK, actor_id="epi@example.test", allowed_packs=[], draft_id=first["draft_id"])["ok"]
        for bad in ("../" + first["draft_id"], "../../source_refs.yaml", "", "C:/absolute"):
            assert not dw.load_draft(root, PACK, actor_id="epi@example.test", draft_id=bad)["ok"]
        assert not dw.list_drafts(root, PACK + "/../202609", actor_id="epi@example.test")["ok"]


def test_invalid_scientific_selections_and_forged_approval_fields_never_save():
    with tempfile.TemporaryDirectory() as tmp:
        root = Path(tmp); fixture(root)
        bad = [inputs(retained=["AGE"]), inputs(retained=["MISSING"]), inputs(retained=["INDEXDT", "INDEXDT"]),
               inputs(retained=["INDEXDT", "AGE", "OS"]), inputs(purpose=""), inputs(target_source=""),
               inputs(target_modality="registry"), inputs(retained=[None]), inputs(additions="wrong"),
               inputs(approved_by="Forged"), inputs(additions=[{"variable_id": "X", "domain": "clinical", "definition": "Rule", "status": "approved"}])]
        for value in bad:
            result = save(root, value)
            assert not result["ok"], value
        assert not (root / PACK / ".portal-drafts").exists()


def test_corrupt_missing_and_redirected_artifacts_are_not_resumable():
    with tempfile.TemporaryDirectory() as tmp:
        root = Path(tmp); fixture(root)
        first = save(root)
        folder = root / first["path"]
        artifact = folder / "DEFINITIONS.json"
        original = artifact.read_bytes()
        artifact.write_text("{}", encoding="utf-8")
        assert not dw.load_draft(root, PACK, actor_id="epi@example.test", draft_id=first["draft_id"])["ok"]
        listing = dw.list_drafts(root, PACK, actor_id="epi@example.test")
        assert not listing["drafts"] and listing["errors"]
        artifact.write_bytes(original)
        payload = folder / "plan.json"
        saved = json.loads(payload.read_text(encoding="utf-8")); saved["inputs"]["purpose"] = "Tampered"
        payload.write_text(json.dumps(saved), encoding="utf-8")
        assert not dw.load_draft(root, PACK, actor_id="epi@example.test", draft_id=first["draft_id"])["ok"]


def test_failed_publish_and_baseline_race_leave_no_half_version():
    with tempfile.TemporaryDirectory() as tmp:
        root = Path(tmp); folder = fixture(root)
        before = original_bytes(root)
        with patch.object(dw.os, "rename", side_effect=OSError("injected publication failure")):
            result = save(root)
        assert not result["ok"] and original_bytes(root) == before
        assert not list((root / PACK / ".portal-drafts").rglob("v??????"))
        assert not list((root / PACK / ".portal-drafts").rglob(".saving-*"))
        assert not list((root / PACK / ".portal-drafts").rglob(".save.lock"))
        original = dw.describe
        count = 0

        def racing(*args):
            nonlocal count
            count += 1
            if count == 2:
                cfg = folder / "config/data_product.yaml"
                cfg.write_text(cfg.read_text(encoding="utf-8") + "delivery: new\n", encoding="utf-8")
            return original(*args)

        digest = original(root, PACK)["baseline_sha256"]
        with patch.object(dw, "describe", side_effect=racing):
            result = dw.save_draft(root, PACK, inputs(), actor_id="epi@example.test", local_demo=True,
                                   can_write=True, allowed_packs=[PACK], expected_baseline=digest)
        assert not result["ok"] and "changed during the save" in result["errors"][0]
        assert not list((root / PACK / ".portal-drafts").rglob("v??????"))


def test_lock_conflict_keeps_other_save_and_all_versions_untouched():
    with tempfile.TemporaryDirectory() as tmp:
        root = Path(tmp); fixture(root)
        first = save(root)
        lock = (root / first["path"]).parent / ".save.lock"
        lock.write_text("other editor", encoding="utf-8")
        result = save(root, inputs(purpose="Next version"), draft_id=first["draft_id"], expected_version=1)
        assert not result["ok"] and "Another save" in result["errors"][0]
        assert lock.read_text(encoding="utf-8") == "other editor"
        assert len(dw.list_drafts(root, PACK, actor_id="epi@example.test")["drafts"]) == 1


if __name__ == "__main__":
    tests = [(name, value) for name, value in globals().items() if name.startswith("test_") and callable(value)]
    for name, test in tests:
        test()
        print("PASS", name)
    print(f"{len(tests)} saved draft checks passed")
