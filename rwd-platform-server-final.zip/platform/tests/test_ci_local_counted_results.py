"""A green subprocess exit cannot substitute for counted execution evidence."""
import json
from pathlib import Path
import sys

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "tools"))
import ci_local


@pytest.mark.parametrize("body,verdict,counts", [
    ("def test_pass(): assert 2 + 2 == 4\n@pytest.mark.skip(reason='R unavailable')\ndef test_r(): pass\n",
     "pass", {"passed": 1, "failed": 0, "errors": 0, "skipped": 1}),
    ("@pytest.mark.skip(reason='R unavailable')\ndef test_r(): pass\n",
     "skipped", {"passed": 0, "failed": 0, "errors": 0, "skipped": 1}),
    ("def test_fail(): assert False\n", "fail", {"passed": 0, "failed": 1, "errors": 0, "skipped": 0}),
    ("raise RuntimeError('collection failed')\n", "fail", {"passed": 0, "failed": 0, "errors": 1, "skipped": 0}),
])
def test_real_pytest_execution_retains_pass_fail_skip_and_collection_counts(tmp_path, monkeypatch, body, verdict, counts):
    suite = tmp_path / "test_measured.py"
    suite.write_text("import pytest\n" + body)
    original = ci_local._run
    monkeypatch.setattr(ci_local, "_run", lambda argv: original(argv, cwd=tmp_path, timeout=60))
    actual, output, _duration, measured = ci_local._pytest_result([sys.executable, "-m", "pytest", "-q", str(suite)])
    assert actual == verdict, output
    assert measured == counts


def test_successful_exit_without_a_counted_report_fails(monkeypatch):
    monkeypatch.setattr(ci_local, "_run", lambda argv: (0, "pretend 18 passed", 0.1))
    verdict, output, _duration, counts = ci_local._pytest_result([sys.executable, "unused"])
    assert verdict == "fail" and counts is None
    assert "No usable counted pytest result" in output


def test_interrupted_lane_keeps_completed_rows_with_explicit_incomplete_marker(tmp_path, monkeypatch):
    monkeypatch.setattr(ci_local, "steps", lambda *args: [("suite first", ["pytest"], ""), ("suite second", ["pytest"], "")])
    calls = []
    def run(argv):
        calls.append(argv)
        if len(calls) == 2:
            raise KeyboardInterrupt
        return "skipped", "one case skipped: missing runtime", 0.1, {"passed": 0, "failed": 0, "errors": 0, "skipped": 1}
    monkeypatch.setattr(ci_local, "_pytest_result", run)
    report = tmp_path / "results/lane.json"
    with pytest.raises(KeyboardInterrupt):
        ci_local.run_lane(report_path=report)
    measured = json.loads(report.read_text())
    assert measured["complete"] is False
    assert measured["tally"] == {"pass": 0, "fail": 0, "skipped": 1}
    assert measured["rows"][0]["cases"]["skipped"] == 1


def test_finished_lane_keeps_counted_mixed_results_and_completion_marker(tmp_path, monkeypatch):
    monkeypatch.setattr(ci_local, "steps", lambda *args: [("suite selected", ["pytest"], "")])
    monkeypatch.setattr(ci_local, "_pytest_result", lambda argv: ("pass", "", 0.1,
                       {"passed": 2, "failed": 0, "errors": 0, "skipped": 1}))
    report = tmp_path / "lane.json"
    ci_local.run_lane(report_path=report)
    measured = json.loads(report.read_text())
    assert measured["complete"] is True
    assert measured["rows"][0]["cases"] == {"passed": 2, "failed": 0, "errors": 0, "skipped": 1}


def test_discovered_product_tests_also_require_counted_pytest_execution(monkeypatch):
    monkeypatch.setattr(ci_local, "_run", lambda argv: (0, "products/example/handoff/tests/test_contract.py\n", 0.1))
    called = []
    def skipped(argv):
        called.append(argv)
        return "skipped", "not executed", 0.1, {"passed": 0, "failed": 0, "errors": 0, "skipped": 2}
    monkeypatch.setattr(ci_local, "_pytest_result", skipped)
    code, _out, _seconds, counts = ci_local._product_tests()
    assert called[0][1:4] == ["-m", "pytest", "-q"]
    assert code == 1 and counts["skipped"] == 2
