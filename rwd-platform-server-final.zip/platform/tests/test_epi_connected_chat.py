"""Chat stress tests use real draft persistence and scripted provider replies."""
from pathlib import Path
import json
import sys

import pytest
from streamlit.testing.v1 import AppTest

ROOT = Path(__file__).resolve().parents[2]
sys.path[:0] = [str(ROOT / 'platform/tests'), str(ROOT / 'platform/tools'),
                str(ROOT / 'experiments/portal'), str(ROOT / 'experiments/agent')]
from test_epi_scientific_definition_ai_page import offline, button
from test_epi_scientific_definitions import ACTOR, ITEM, describe, fixture, governed_bytes
from test_epi_flow_assistant import _card, _Model
import scientific_definition_ai_page as row_ai
import scientific_definition_ai as ai
import flow_assistant as guide
import flow_assistant_page as guide_page


def row_app(root, pack):
    code = f'''import copy
import streamlit as st
import scientific_definition_ai_page as page
import scientific_definitions as definitions
actor = st.session_state.get('actor', {ACTOR!r})
scope = st.session_state.get('scope', [{pack!r}])
if 'current' not in st.session_state:
    st.session_state.current = definitions.describe({str(root)!r}, {pack!r}, actor, item_id={ITEM!r}, allowed_packs=scope)
current = copy.deepcopy(st.session_state.current)
current['values'].update(st.session_state.get('working', {{}}))
if page.render({str(root)!r}, {pack!r}, actor, current, local_demo=True,
        can_write=st.session_state.get('write', True), allowed_packs=scope, chat=True):
    st.session_state.saved = True
st.text_input('Unfinished downstream form', key='downstream')
'''
    return AppTest.from_string(code, default_timeout=45).run()


def send(at, text='Help me explain the meaning of this row.'):
    at.chat_input[0].set_value(text).run()
    assert not at.exception, [e.message for e in at.exception]
    return at


def test_row_chat_calls_only_on_send_and_keeps_review_and_contract_boundary(tmp_path, offline):
    root, pack, product, _ = fixture(tmp_path)
    before = governed_bytes(product)
    at = row_app(root, pack)
    assert not at.exception and not offline.generations
    at.text_input(key='downstream').set_value('Unsaved work').run()
    at.session_state.working = {'missing': 'My missing rule', 'notes': 'My unresolved question'}
    send(at)
    assert len(offline.generations) == 1
    assert at.text_input(key='downstream').value == 'Unsaved work'
    at.run(); at.run()
    assert len(offline.generations) == 1
    assert not describe(root, pack)['saved']
    at.multiselect(key=row_ai.PREFIX + 'select_chat').set_value(['derivation']).run()
    button(at, 'Use this proposed draft').click().run()
    assert not at.exception and at.session_state.saved
    saved = describe(root, pack)['values']
    assert saved['derivation'].startswith('Represent the PD-L1')
    assert saved['missing'] == 'My missing rule' and saved['notes'] == 'My unresolved question'
    assert governed_bytes(product) == before
    at.run()
    assert len(offline.acceptances) == 1


def test_followup_keeps_previous_proposal_and_failed_response_keeps_unsaved_work(tmp_path, offline):
    root, pack, product, _ = fixture(tmp_path)
    before = governed_bytes(product)
    at = send(row_app(root, pack))
    at.text_input(key='downstream').set_value('Still editing').run()
    offline.generate_error = True
    send(at, 'Use the first treatment date as the reference event.')
    request = offline.generations[-1]
    assert 'first treatment date' in request['user_request']
    assert request['previous_proposal']['suggestions'][0]['questions'] == ['Which index event should be used?']
    assert request['conversation'] is True
    assert at.text_input(key='downstream').value == 'Still editing'
    assert any('unusable response' in e.value for e in at.error)
    assert any(b.label == 'Use this proposed draft' for b in at.button)
    assert not offline.acceptances and not describe(root, pack)['saved']
    assert governed_bytes(product) == before


def test_explanation_only_chat_displays_answer_without_draft_controls(tmp_path, offline, monkeypatch):
    root, pack, product, _ = fixture(tmp_path)
    before = governed_bytes(product)
    original = offline.suggest
    def explain(*args, **kwargs):
        result = original(*args, **kwargs)
        result['proposal'].update(answer='Grain means what one recorded value represents.', suggestions=[])
        return result
    monkeypatch.setattr(ai, 'suggest', explain)
    at = send(row_app(root, pack), 'What does grain mean?')
    assert any('Grain means what one recorded value represents.' in e.value for e in at.markdown)
    assert not any(b.label == 'Use this proposed draft' for b in at.button)
    assert not at.table
    assert not offline.acceptances and not describe(root, pack)['saved']
    assert governed_bytes(product) == before


def test_explanation_after_proposal_preserves_review_and_next_followup_context(tmp_path, offline, monkeypatch):
    root, pack, product, _ = fixture(tmp_path)
    before = governed_bytes(product)
    at = send(row_app(root, pack), 'Propose wording for this row.')
    original = offline.suggest
    def explain(*args, **kwargs):
        result = original(*args, **kwargs)
        result['proposal'].update(answer='The index event needs a scientific decision.', suggestions=[])
        return result
    monkeypatch.setattr(ai, 'suggest', explain)
    send(at, 'Why does the index event need a decision?')
    assert any(b.label == 'Use this proposed draft' for b in at.button)
    assert at.table
    send(at, 'Keep that wording and flag the uncertainty.')
    assert offline.generations[-1]['previous_proposal']['answer'] == 'The index event needs a scientific decision.'
    assert not offline.acceptances and not describe(root, pack)['saved']
    assert governed_bytes(product) == before


@pytest.mark.parametrize('change', ['actor', 'scope', 'permission', 'connection', 'eligibility', 'source'])
def test_context_change_cannot_accept_an_old_chat_proposal(tmp_path, offline, change):
    root, pack, product, _ = fixture(tmp_path)
    at = send(row_app(root, pack))
    if change == 'actor':
        at.session_state.actor = 'another-reviewer'
    elif change == 'scope':
        at.session_state.scope = []
    elif change == 'permission':
        at.session_state.write = False
    elif change == 'connection':
        offline.configured = False
    elif change == 'eligibility':
        offline.eligible = False
    else:
        path = product / 'handoff/FUNCTIONAL_CONTRACT.md'
        path.write_text(path.read_text(encoding='utf-8') + '\nExternal edit\n', encoding='utf-8')
    at.run()
    assert not at.exception
    assert not any(b.label == 'Use this proposed draft' for b in at.button)
    assert not offline.acceptances


def test_restricted_chat_text_is_never_retained_or_sent(tmp_path, offline):
    root, pack, _, _ = fixture(tmp_path)
    at = send(row_app(root, pack), 'patient John Smith, MRN 123456, DOB 1961-03-04 has ECOG 2')
    assert not offline.generations
    assert 'John Smith' not in json.dumps(at.session_state[row_ai.PREFIX + 'messages'])
    assert at.error


def guide_app(monkeypatch, *, model=None, connected=True, eligible=True, can_agent=True):
    config = {'configured': True, 'instance': model, 'provider': 'Scripted test', 'model': 'test'} if connected else None
    monkeypatch.setattr(guide_page, '_provider_words', lambda root: (config, 'Test connection'))
    def gate(*args):
        if not eligible:
            raise ValueError('source unavailable')
    monkeypatch.setattr(ai.definitions.cs, 'ai_gate', gate)
    code = f'''import streamlit as st
import flow_assistant_page as page
page.render({str(ROOT)!r}, 'products/oncology/test/202606', card=st.session_state.get('card', {_card()!r}),
    actor_id=st.session_state.get('actor', 'Scientist'), primary=True, can_agent={can_agent!r})
st.text_input('Unfinished downstream form', key='downstream')
'''
    return AppTest.from_string(code, default_timeout=45).run()


@pytest.mark.parametrize('action, section, child', [
    ('open_progress', 'Flow', 'source_mapping'),
    ('check_status', 'Flow', 'release_readiness'),
    ('open_plan_changes', 'Plan changes', 'revision_review'),
    ('open_studies', 'Studies', 'study_protocol'),
    ('open_definitions', 'Search & definitions', 'variable_lineage'),
])
def test_guide_section_action_leaves_child_workspace_and_preserves_unfinished_fields(action, section, child):
    code = f'''import streamlit as st
import flow_assistant_page as page
import connected_workflow as workflow
pack, actor = 'products/oncology/test/202606', 'Scientist'
if 'initialized' not in st.session_state:
    st.session_state.initialized = True
    st.session_state.section = {section!r}
    st.session_state.connected_workflow = workflow.destination({child!r}, pack=pack, actor_id=actor, origin={section!r})
    st.session_state.flow_dialog = {{'pack': pack, 'actor': actor}}
    st.session_state.flow_resolution_action = 'g3_map'
    st.session_state.flow_result = {{pack: {{'checked': True}}}}
if 'section_suggested' in st.session_state:
    st.session_state.section = st.session_state.pop('section_suggested')
st.text_input('Unfinished editor field', key='source_ws_draft')
if st.button('Continue from guide'):
    page._go({action!r}, {{'actions': [{action!r}]}}, pack, actor)
st.session_state.child_active = workflow.valid(st.session_state.get('connected_workflow'),
    pack=pack, actor_id=actor, section=st.session_state.section, allowed_packs=[pack])
'''
    at = AppTest.from_string(code).run()
    assert not at.exception and at.session_state.child_active
    at.text_input(key='source_ws_draft').set_value('Keep this unfinished mapping').run()
    next(button for button in at.button if button.label == 'Continue from guide').click().run()
    assert not at.exception
    assert at.session_state.section == section and not at.session_state.child_active
    assert at.text_input(key='source_ws_draft').value == 'Keep this unfinished mapping'
    assert 'flow_resolution_action' not in at.session_state.filtered_state
    assert 'flow_dialog' not in at.session_state.filtered_state
    assert bool(at.session_state.flow_result) is (action != 'check_status')


@pytest.mark.parametrize('action, target', [('open_coding', 'implementation_patterns'),
    ('open_source_mapping', 'source_mapping'), ('open_editor', 'scientific_draft')])
@pytest.mark.parametrize('owner', ['current', 'other_actor', 'other_pack', 'other_page'])
def test_guide_skill_handoff_keeps_only_current_semantic_selection(action, target, owner):
    pack, actor = 'products/oncology/test/202606', 'Scientist'
    source = {'route': 'definition_reuse', 'pack': 'other' if owner == 'other_pack' else pack,
        'actor': 'Someone else' if owner == 'other_actor' else actor,
        'origin': 'Studies' if owner == 'other_page' else 'Flow',
        'params': {'item_id': 'clinical:9', 'variable': 'BASELINE_ALBUMIN', 'study': 'Study A',
            'proposal_id': 'unrelated-private-artifact', 'record_id': 'unrelated-result', 'path': 'do-not-carry', 'command': 'do-not-execute'}}
    code = f'''import streamlit as st
import flow_assistant_page as page
if 'initialized' not in st.session_state:
    st.session_state.initialized = True
    st.session_state.section = 'Flow'
    st.session_state.connected_workflow = {source!r}
st.text_input('Unfinished wording', key='scientific_definition_unsaved_test')
if st.button('Continue through guide'):
    page._go({action!r}, {{'actions': [{action!r}]}}, {pack!r}, {actor!r})
'''
    at = AppTest.from_string(code).run()
    at.text_input[0].set_value('Keep my scientific wording').run()
    next(b for b in at.button if b.label == 'Continue through guide').click().run()
    assert not at.exception
    result = at.session_state.connected_workflow
    assert result['route'] == target and result['pack'] == pack and result['actor'] == actor
    expected = {'item_id': 'clinical:9', 'variable': 'BASELINE_ALBUMIN', 'study': 'Study A'} if owner == 'current' else {}
    assert result['params'] == expected
    assert at.text_input[0].value == 'Keep my scientific wording'


def test_guide_reopens_the_selected_scientific_row_instead_of_the_first_row(tmp_path, monkeypatch):
    from test_contract_lint import build_product
    import scientific_definition_page as editor
    product = Path(build_product(tmp_path, [], spec_rows=(('clinical', 3), ('clinical', 9)), sources=True))
    root, pack = product.parents[3], product.relative_to(product.parents[3]).as_posix()
    monkeypatch.setattr(ai, 'describe_availability', lambda *_a, **_k: {'ok': True, 'configured': False, 'help': 'Scripted offline test'})
    code = f'''import streamlit as st
import flow_assistant_page as guide
import scientific_definition_page as editor
if 'initialized' not in st.session_state:
    st.session_state.initialized = True
    st.session_state.section = 'Flow'
    st.session_state.connected_workflow = {{'route': 'definition_reuse', 'pack': {pack!r}, 'actor': {ACTOR!r},
        'origin': 'Flow', 'params': {{'item_id': 'clinical:9', 'variable': 'PDL1_TPS'}}}}
if st.button('Open selected row through guide'):
    guide._go('open_editor', {{'actions': ['open_editor']}}, {pack!r}, {ACTOR!r})
context = st.session_state.connected_workflow
if context['route'] == 'scientific_draft':
    editor.render({str(root)!r}, {pack!r}, {ACTOR!r}, local_demo=True, can_write=True,
        can_view=True, naming_packs={[pack]!r}, initial_item_id=context['params'].get('item_id'))
'''
    before = governed_bytes(product)
    at = AppTest.from_string(code, default_timeout=45).run()
    next(b for b in at.button if b.label == 'Open selected row through guide').click().run()
    assert not at.exception, [e.message for e in at.exception]
    assert at.selectbox(key=editor.PREFIX + 'row').value == 'clinical:9'
    assert governed_bytes(product) == before


def test_common_chat_timeout_and_repeated_sends_preserve_the_editor_and_bound_history(monkeypatch):
    model = _Model('malformed provider reply')
    at = guide_app(monkeypatch, model=model)
    at.text_input(key='downstream').set_value('Unsaved source mapping').run()
    for index in range(10):
        send(at, f'What do I do next, question {index}?')
    assert len(model.calls) == 10
    assert at.text_input(key='downstream').value == 'Unsaved source mapping'
    import session_drafts
    history_key = session_drafts.history_key(ROOT, 'Scientist') + 'products/oncology/test/202606'
    assert len(at.session_state[history_key]) == 8
    prompt = json.loads(model.calls[-1][1][0]['content'])
    assert 1 <= len(prompt['conversation']) <= guide.MAX_CONVERSATION_TURNS
    assert prompt['conversation'][-1]['question'] == 'What do I do next, question 8?'
    at.run()
    assert len(model.calls) == 10


@pytest.mark.parametrize('connected,eligible,can_agent', [(False, True, True), (True, False, True), (True, True, False)])
def test_common_chat_disconnected_unclassified_or_unauthorized_uses_manual_fallback(monkeypatch, connected, eligible, can_agent):
    model = _Model('{}')
    at = guide_app(monkeypatch, model=model, connected=connected, eligible=eligible, can_agent=can_agent)
    assert not at.exception and not at.chat_input and not model.calls
    assert any(w.label == 'Your question' for w in at.text_input)


def test_old_actions_and_actor_history_are_not_reused(monkeypatch):
    model = _Model(json.dumps({'answer': 'Open the definition editor.', 'actions': ['open_editor']}))
    at = send(guide_app(monkeypatch, model=model))
    assert any(b.label == 'Open the definition editor' for b in at.button)
    at.session_state.card = {**_card(), 'actions': ['open_progress']}
    at.run()
    assert not any(b.label == 'Open the definition editor' for b in at.button)
    at.session_state.actor = 'Another scientist'
    at.run()
    assert not any(m.value == 'Open the definition editor.' for m in at.markdown)


@pytest.mark.parametrize('reply', ['null', '[]', '"answer"', '{"answer": [], "actions": {}}', 'x' * 100_000, '{"answer": "ok", "actions": {"open_editor": true}}'],
    ids=['null', 'array', 'string', 'wrong_answer_type', 'oversized', 'wrong_action_type'])
def test_bad_model_types_and_oversized_outputs_fail_without_crashing(reply):
    result = guide.answer('What is next?', _card(), model=_Model(reply))
    assert result['source'] == 'checks' and len(result['answer']) <= guide.MAX_ANSWER


def test_local_claude_connection_uses_the_normal_workspace_mode(monkeypatch):
    seen = []
    class LocalModel:
        model = 'scripted'
        model_info = {}
        connection_id = 'scripted-local'
        def __init__(self, root, *, local_demo):
            seen.append(local_demo)
    monkeypatch.setenv('RWD_PORTAL_LOCAL_WORKSPACE', '1')
    monkeypatch.setenv('RWD_PORTAL_LOCAL_DEMO', '0')
    monkeypatch.setattr(ai, 'selected_provider', lambda: 'claude_code')
    monkeypatch.setattr(ai.claude_code, 'ClaudeCodeModel', LocalModel)
    assert ai._provider(ROOT)['configured'] and seen == [True]
