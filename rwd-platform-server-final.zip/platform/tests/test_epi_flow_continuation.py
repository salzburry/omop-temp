"""Connected work can reach later canonical acts without completing or running them."""
from pathlib import Path
import sys

import pytest

ROOT = Path(__file__).resolve().parents[2]
sys.path[:0] = [str(ROOT / "experiments/portal"), str(ROOT / "platform/tools"),
               str(ROOT / "platform"), str(ROOT / "platform/tests")]
from _epi_gist_fixture import PACK, seed_gist
import flow
import flow_continuation as continuation
import flow_guidance


@pytest.fixture
def product(tmp_path):
    seed_gist(tmp_path, extraction=True)
    return tmp_path


def resolve(root, action_id, **changes):
    options = {"allowed_packs": [PACK], "can_view": True}
    return continuation.resolve(root, PACK, "requesting-person", action_id, **(options | changes))


@pytest.mark.parametrize("action_id", ["g5_build", "g5_validate", "g6_approve", "g6_seal",
                                      "g6_countersign", "g6_commit", "g6_promote", "g6_receipt"])
def test_requested_later_action_resolves_exact_catalogue_without_passing_early_gates(product, action_id):
    initial = flow.flow(str(product), PACK)
    assert initial["current"] == 1
    assert not any(action["id"] == action_id for card in initial["blockers"] for action in card["fixes"])
    before = {p.relative_to(product).as_posix(): p.read_bytes() for p in product.rglob("*") if p.is_file()}
    result = resolve(product, action_id)
    assert result["ok"], result
    canonical = next(action for actions in flow.acts(PACK, str(product)).values() for action in actions if action["id"] == action_id)
    assert result["action"] == canonical
    assert result["card"]["fixes"] == [canonical] and result["card"]["requested"]
    assert result["card"]["held_by"] == int(action_id[1])
    assert result["key"] == "requested:" + action_id
    assert {p.relative_to(product).as_posix(): p.read_bytes() for p in product.rglob("*") if p.is_file()} == before
    assert flow.flow(str(product), PACK)["current"] == 1


def test_resolved_sealing_retains_existing_write_guard(product):
    result = resolve(product, "g6_seal")
    assert result["ok"], result
    assert result["action"]["kind"] == flow.WRITE
    reason = flow_guidance.action_guard(product, PACK, result["action"], local_demo=True, can_write=True)
    assert "Complete the release review" in reason
    assert not (product / "governance/events").exists()


@pytest.mark.parametrize("action_id,options", [("g6_promote", {"can_view": False}), ("g6_promote", {"allowed_packs": []}),
                                               ("invented_action", {}), ({"id": "g6_promote", "argv": ["injected"]}, {})])
def test_invalid_scope_and_injected_actions_are_refused_before_catalogue(product, action_id, options, monkeypatch):
    if options or isinstance(action_id, dict):
        monkeypatch.setattr(flow, "acts", lambda *a, **k: pytest.fail("invalid scope reached the catalogue"))
    result = resolve(product, action_id, **options)
    assert not result["ok"]


def test_completed_dynamic_action_is_not_resurrected(product):
    assert not resolve(product, "g1_init")["ok"], "the source registration already exists"
    assert resolve(product, "g1_review")["ok"], "existing source review remains editable"


def test_fixture_cannot_open_product_only_receipt_action(tmp_path):
    pack = "fixtures/oncology/reference_demo/202606"
    seed_gist(tmp_path, pack=pack)
    result = continuation.resolve(tmp_path, pack, "reader", "g6_receipt", allowed_packs=[pack], can_view=True)
    assert not result["ok"]


def test_canonical_key_can_be_resolved_again_after_evidence_refresh(product):
    result = resolve(product, "g6_approve")
    assert result["ok"]
    path = product / PACK / "handoff/RELEASE_APPROVAL.yaml"
    path.write_text("approved_by: null\n", encoding="utf-8")
    resumed = resolve(product, result["key"].removeprefix(continuation.PREFIX))
    assert resumed["ok"] and resumed["key"] == result["key"]
    assert resumed["card"]["fixes"][0]["path"] == f"{PACK}/handoff/RELEASE_APPROVAL.yaml"
