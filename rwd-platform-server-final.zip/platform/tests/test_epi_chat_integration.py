"""One conversation retrieves references, runs specialists and retains the form."""
from __future__ import annotations

import copy
import json
from pathlib import Path
import sys

import pytest
from streamlit.testing.v1 import AppTest

ROOT = Path(__file__).resolve().parents[2]
sys.path[:0] = [str(ROOT / name) for name in ("platform/tests", "experiments/portal", "experiments/agent", "platform/tools")]
import flow_assistant as guide
import flow_assistant_page as page
import scientific_conversation_context as evidence
import scientific_definition_ai as ai
from test_epi_flow_assistant import _card
from test_epi_specialist_chat import setup, enabled, PACK, ACTOR, PROVIDER


def reference(digest="current"):
    return {"sources": [{"id": "prior_rule", "kind": "contract_precedent", "label": "Recorded timing choice",
                         "text": "Prior product used the last eligible observation; missing dates remained missing."}],
            "references": [{"source_id": "prior_rule", "artifact": "handoff/FUNCTIONAL_CONTRACT.md",
                            "artifact_sha256": "a" * 64, "recorded_status": "Recorded approved interpretation",
                            "reference_version": "202609", "pack": PACK,
                            "applicability": "Prior product only; review applicability to this study."}],
            "notices": ["No database execution is established by this reference."], "digest": digest}


class Model:
    def __init__(self, reply=None):
        self.calls = []
        self.reply = reply or {"answer": "The prior timing choice is one option; confirm whether it fits this study.",
                               "actions": [], "evidence_ids": ["prior_rule"]}

    def step(self, system, messages):
        self.calls.append((system, json.loads(messages[0]["content"])))
        return json.dumps(self.reply)


def ask(model, **kwargs):
    return guide.answer("Compare the prior timing choice", _card(), root=ROOT, model=model,
                        actor_id=ACTOR, allowed_packs=[PACK], task_scope={"pack": PACK}, **kwargs)


def test_guide_retrieves_scoped_references_and_returns_only_supplied_citations(monkeypatch):
    reads = []
    def retrieve(**kwargs):
        reads.append(kwargs)
        return reference()
    monkeypatch.setattr(evidence, "build_chat", retrieve)
    model = Model()
    reply = ask(model)
    assert reply["source"] == "assistant" and reply["evidence_ids"] == ["prior_rule"]
    assert reply["knowledge"] == reference()
    assert len(model.calls) == 1 and len(reads) == 2
    assert reads[0] == reads[1] and reads[0]["pack"] == PACK and reads[0]["allowed_packs"] == [PACK]
    assert 768 <= reads[0]["max_bytes"] <= 4500
    assert model.calls[0][1]["retrieved_knowledge"] == reference()


def test_reference_change_during_answer_discards_field_proposal(monkeypatch):
    current = {"value": "before"}
    monkeypatch.setattr(evidence, "build_chat", lambda **_: reference(current["value"]))
    class Changed(Model):
        def step(self, *args):
            current["value"] = "after"
            return super().step(*args)
    reply = ask(Changed())
    assert reply["source"] == "checks" and "access changed" in reply["note"]
    assert "prefill" not in reply and "knowledge" not in reply


@pytest.mark.parametrize("ids", [["invented_reference"], "prior_rule", [False], ["prior_rule"] * 7])
def test_unsupplied_or_malformed_citations_do_not_become_attributed_advice(monkeypatch, ids):
    monkeypatch.setattr(evidence, "build_chat", lambda **_: reference())
    reply = ask(Model({"answer": "A claimed conclusion.", "actions": [], "evidence_ids": ids}))
    assert reply["source"] == "checks" and "knowledge" not in reply


@pytest.mark.parametrize("raw", [
    '{"answer":"First", "answer":"Replacement", "actions":[]}',
    '{"answer":"Claim", "actions":[], "evidence_ids":["unknown"], "evidence_ids":[]}',
    '{"answer":"Claim", "actions":[], "extra":NaN}',
    '{"answer":"First", "actions":[]} {"answer":"Second", "actions":[]}',
])
def test_ambiguous_response_cannot_replace_its_answer_or_reference_claim(raw):
    with pytest.raises(ValueError):
        guide._parse_model(raw, _card(), reference())


@pytest.mark.parametrize("length", [1201, 1205, guide.MAX_ANSWER])
def test_slightly_long_reply_keeps_its_final_qualification_and_history(length):
    qualification = " Source applicability remains unverified."
    body = "x" * (length - len(qualification)) + qualification
    result = guide._parse_model(json.dumps({"answer": body, "actions": []}), _card())
    assert result["answer"] == body
    assert guide.conversation_history(_card(), [{"question": "Compare options", "answer": result["answer"]}])[0]["answer"] == body


def test_reply_beyond_bounded_ceiling_is_rejected_whole():
    raw = json.dumps({"answer": "x" * (guide.MAX_ANSWER + 1), "actions": []})
    with pytest.raises(ValueError):
        guide._parse_model(raw, _card())


def test_malformed_model_response_is_not_reported_as_connection_failure_or_applied(monkeypatch):
    monkeypatch.setattr(evidence, "build_chat", lambda **_: reference())
    monkeypatch.setattr(guide, "answer_offline", lambda *_: {"answer": "Review the current step.", "actions": [],
                                                            "prefill": {"scope": "synthetic", "fields": []}})
    class Malformed(Model):
        def step(self, *args):
            self.calls.append(args)
            return '{"answer":"Partial reply" "actions":[]}'
    model = Malformed()
    reply = ask(model)
    assert len(model.calls) == 1 and reply["error_code"] == "invalid_response"
    assert "answer format" in reply["note"] and "Ask again explicitly" in reply["note"]
    assert "prefill" not in reply and "knowledge" not in reply
    assert "Partial reply" not in json.dumps(reply)


def test_sensitive_retrieved_text_never_reaches_model(monkeypatch):
    value = reference()
    value["sources"][0]["text"] = "patient_id: 123456789"
    monkeypatch.setattr(evidence, "build_chat", lambda **_: value)
    model = Model()
    reply = ask(model)
    assert not model.calls and reply["source"] != "assistant"
    assert "123456789" not in json.dumps(reply)


@pytest.mark.parametrize("padding", ["", "x" * 1000])
def test_offline_and_oversized_credentials_are_refused_before_history(padding):
    sentinel = "ANTHROPIC_API_KEY=" + "sk-ant-" + "audit-sentinel-only"
    reply = guide.answer(sentinel + padding, _card())
    assert reply["source"] == "refused"
    assert "audit-sentinel-only" not in json.dumps(reply)


def test_response_prose_prefix_is_ingress_checked_before_json_is_selected():
    raw = 'patient_id: 123456789\n{"answer":"Read the current step.","actions":[]}'
    with pytest.raises(ai.Invalid):
        guide._parse_model(raw, _card())


def test_retrieval_does_not_run_without_explicit_connected_question(monkeypatch):
    monkeypatch.setattr(evidence, "build_chat", lambda **_: pytest.fail("No reference read is needed"))
    assert guide.answer("What is next?", _card(), root=ROOT, actor_id=ACTOR, allowed_packs=[PACK])["source"] == "checks"
    assert guide.answer("What is next?", _card(), model=Model({"answer": "Read the current step.", "actions": []}))["source"] == "assistant"


def test_reference_budget_preserves_current_form_and_latest_followup(monkeypatch):
    budgets = []
    def retrieve(**kwargs):
        budgets.append(kwargs["max_bytes"])
        return reference()
    monkeypatch.setattr(evidence, "build_chat", retrieve)
    card = _card()
    card["scientific_form"] = {"current": "timing " * 500}
    last = {"question": "Which window?", "answer": "A: use the recorded window; B: leave the choice open."}
    history = [{"question": "Earlier question", "answer": "Earlier answer " * 60} for _ in range(7)] + [last]
    model = Model()
    reply = guide.answer("B", card, root=ROOT, model=model, history=history,
                         actor_id=ACTOR, allowed_packs=[PACK], task_scope={"pack": PACK})
    assert reply["source"] == "assistant"
    system, payload = model.calls[0]
    assert payload["context"]["scientific_form"] == card["scientific_form"]
    assert payload["conversation"][-1] == last
    assert len(system.encode()) + len(json.dumps(payload, ensure_ascii=False, separators=(",", ":")).encode()) <= ai.MAX_REQUEST_BYTES
    assert budgets


def main_app(root, monkeypatch, *, can_agent=True):
    monkeypatch.setattr(page, "_provider_words", lambda *_: (dict(PROVIDER), "Scripted connection"))
    monkeypatch.setattr(ai.definitions.cs, "ai_gate", lambda *_: None)
    monkeypatch.setattr(evidence, "build_chat", lambda **_: reference())
    code = f'''
import streamlit as st
import flow_assistant_page as page
import form_assistance as forms
from test_epi_flow_assistant import _card
forms.begin({str(root)!r}, {PACK!r}, {ACTOR!r}, page="Test form", allowed_packs={[PACK]!r}, can_write=True)
page.render({str(root)!r}, {PACK!r}, card=_card(), actor_id={ACTOR!r}, primary=True,
            local_demo=True, can_agent={can_agent!r}, can_write=True, allowed_packs={[PACK]!r})
forms.field(st.text_area, "Study purpose", key="purpose")
forms.finish()
'''
    return AppTest.from_string(code, default_timeout=35).run()


@pytest.mark.parametrize("reason", ["disconnected", "no_permission", "source_blocked"])
def test_unavailable_chat_does_not_retain_secret_or_poison_later_history(enabled, monkeypatch, reason):
    root, calls = enabled
    at = main_app(root, monkeypatch, can_agent=reason != "no_permission")
    if reason == "disconnected":
        monkeypatch.setattr(page, "_provider_words", lambda *_: (None, "Disconnected"))
    elif reason == "source_blocked":
        def blocked(*_):
            raise ValueError("Source needs review")
        monkeypatch.setattr(ai.definitions.cs, "ai_gate", blocked)
    at.run()
    assert not at.exception
    sentinel = "ANTHROPIC_API_KEY=" + "sk-ant-" + "audit-sentinel-only"
    next(item for item in at.text_input if item.label == "Your question").set_value(sentinel)
    next(item for item in at.button if item.label == "Ask").click().run()
    assert not at.exception, [error.message for error in at.exception]
    histories = [value for key, value in at.session_state.filtered_state.items()
                 if key.startswith("flow_assistant_history_") and isinstance(value, list)
                 and value and isinstance(value[0], dict)]
    assert len(histories) == 1 and histories[0][-1]["source"] == "refused"
    assert "audit-sentinel-only" not in json.dumps(histories)
    assert not calls


@pytest.mark.parametrize("prompt,kind", [
    ("Ask source specialist to assess mapping gaps", "source"),
    ("Run validation diagnosis for missing input", "validation"),
    ("Review implementation for ECOG", "implementation"),
])
def test_main_chat_runs_existing_specialist_once_and_keeps_unsaved_form(enabled, monkeypatch, prompt, kind):
    root, calls = enabled
    monkeypatch.setattr(guide, "answer", lambda *_a, **_kw: pytest.fail("Explicit specialist request must not need another guide call"))
    at = main_app(root, monkeypatch)
    assert not at.exception, [error.message for error in at.exception]
    at.text_area(key="purpose").set_value("Unfinished study purpose").run()
    at.chat_input[0].set_value(prompt).run()
    assert not at.exception, [error.message for error in at.exception]
    assert len(calls) == 1 and calls[0]["kind"] == kind
    assert any("Exact saved assessment for " + kind in item.value for item in at.markdown)
    assert any("Inspect the current evidence" in item.value for item in at.markdown)
    assert at.text_area(key="purpose").value == "Unfinished study purpose"
    at.run()
    assert not at.exception and len(calls) == 1
    turns = [value for key, value in at.session_state.filtered_state.items() if key.startswith("flow_assistant_history_") and isinstance(value, list) and value and isinstance(value[0], dict)]
    assert len(turns) == 1 and turns[0][0]["specialist"]["status"] == "saved"


def test_valid_specialist_findings_reach_followup_context_without_becoming_completion():
    turn = {"question": "Review implementation", "answer": "The result is below.",
            "specialist_context": {"summary": "Proposed reuse", "critic": {"route": "human", "findings": ["Check the null rule"]}}}
    result = guide.conversation_history(_card(), [turn])
    assert result[0]["specialist_result"] == turn["specialist_context"]
    assert "not proof that code ran" in guide.SYSTEM


def test_main_chat_displays_exact_reference_versions_across_multiple_turns(enabled, monkeypatch):
    root, _calls = enabled
    original_answer = guide.answer
    model = Model()
    def answer(*args, **kwargs):
        return original_answer(*args, **{**kwargs, "model": model})
    monkeypatch.setattr(guide, "answer", answer)
    at = main_app(root, monkeypatch)
    material = reference()
    material["references"][0]["source_url"] = "https://example.org/reference"
    monkeypatch.setattr(evidence, "build_chat", lambda **_: copy.deepcopy(material))
    at.chat_input[0].set_value("Compare the prior timing choice").run()
    assert not at.exception, [error.message for error in at.exception]
    at.chat_input[0].set_value("What uncertainty remains?").run()
    assert not at.exception, [error.message for error in at.exception]
    assert len(model.calls) == 2
    assert any("Recorded approved interpretation" in item.value and "202609" in item.value for item in at.caption)
    assert any("handoff/FUNCTIONAL_CONTRACT.md" in item.value for item in at.text)
    assert any("a" * 64 in item.value for item in at.text)
    assert len([item for item in at.get("link_button") if item.label == "Open reference source"]) == 2
