"""Sheet exclusion help follows the actual New product catalogue and fields."""
import copy
import json
from pathlib import Path
import sys

import pytest

ROOT = Path(__file__).resolve().parents[2]
sys.path[:0] = [str(ROOT / name) for name in
    ("platform/tests", "experiments/portal", "platform/tools", "experiments/agent")]
import flow_assistant as guide
from test_epi_flow_assistant import _setup_card

IGNORED = "9.PROC PSOC Strategy"
EXISTING = "Support notes"
MAPPED = "2.DEMO"
AMBIGUOUS = "Tumour staging"


def descriptor():
    return {"ok": True, "sha256": "a" * 64, "sheets": [
        {"name": IGNORED, "domain": None, "kind": "unclassified", "selectable": True, "ambiguous": False,
         "cells": ["must-not-reach-provider"]},
        {"name": EXISTING, "domain": None, "kind": "unclassified", "selectable": True, "ambiguous": False},
        {"name": MAPPED, "domain": "demographics", "kind": "mapped", "selectable": False, "ambiguous": False},
        {"name": AMBIGUOUS, "domain": None, "kind": "unclassified", "selectable": True, "ambiguous": True}],
        "inherited": [EXISTING], "missing_inherited": ["Old notes"], "selected": [EXISTING],
        "reason": "Supporting notes are not needed for this product.", "source_bytes": "must-not-reach-provider"}


def card():
    result = guide.setup_context(_setup_card(), local_writes=True, sheet_scope=descriptor())
    result["editable_form"] = {"scope": "current-workbook-and-form", "fields": [
        {"id": "offered-sheet-field", "label": guide.SHEET_SCOPE_FIELD, "type": "multiselect",
         "current": [EXISTING], "choices": [{"value": name, "label": name} for name in (IGNORED, EXISTING)]},
        {"id": "offered-reason-field", "label": guide.SHEET_SCOPE_REASON, "type": "text_area",
         "current": "", "choices": None}]}
    return result


def test_sheet_context_contains_only_catalogue_metadata_and_actual_scope_fields():
    current = card()
    scope = current["setup_form"]["sheet_scope"]
    assert current["setup_form"]["fields"][-2:] == [guide.SHEET_SCOPE_FIELD, guide.SHEET_SCOPE_REASON]
    assert scope["selected"] == scope["inherited"] == [EXISTING]
    assert scope["missing_inherited"] == ["Old notes"]
    assert "must-not-reach-provider" not in json.dumps(current)
    assert "no separate approval, disposition proof or evidence record is required" in scope["rule"]
    assert "Source classification and review are still required" in scope["rule"]
    for invalid in (None, {}, {"ok": False}, {"ok": True, "sheets": [None]}):
        unavailable = guide.setup_context(_setup_card(), sheet_scope=invalid)
        assert "sheet_scope" not in unavailable["setup_form"]
        assert guide.SHEET_SCOPE_FIELD not in unavailable["setup_form"]["fields"]


@pytest.mark.parametrize("question", [f"ignore '{IGNORED}'", f'Please exclude sheet "{IGNORED}".',
                                    f"Can you leave out {IGNORED}?"])
def test_literal_exclusion_uses_only_current_choice_and_preserves_existing_selections(question):
    current = card()
    before = copy.deepcopy(current)
    result = guide.answer(question, current)
    assert result["prefill"] == {"scope": current["editable_form"]["scope"], "fields": [
        {"id": "offered-sheet-field", "value": [EXISTING, IGNORED]}]}
    assert "needs no separate approval or disposition proof" in result["answer"]
    assert "enter your reason" in result["answer"]
    assert "original workbook and source trace remain" in result["answer"]
    assert current == before and result["actions"] == []


@pytest.mark.parametrize("question", ["ignore 'Not in this workbook'", "Exclude all sheets", "Ignore all sheets in the workbook"])
def test_unknown_or_all_sheet_request_shows_real_choices_without_inventing_edits(question):
    result = guide.answer(question, card())
    assert "prefill" not in result and result["actions"] == []
    assert IGNORED in result["answer"] and EXISTING in result["answer"]
    assert guide.SHEET_SCOPE_FIELD in result["answer"] and guide.SHEET_SCOPE_REASON in result["answer"]
    assert "needs no separate approval or disposition proof" in result["answer"]


@pytest.mark.parametrize("name, expected", [(MAPPED, "Plan changes after creation"), (AMBIGUOUS, "name is ambiguous")])
def test_mapped_or_ambiguous_sheet_cannot_become_a_setup_exclusion(name, expected):
    result = guide.answer(f"Ignore '{name}'", card())
    assert "prefill" not in result and expected in result["answer"]


def test_one_study_exclusion_stays_separate_and_absent_or_stale_form_choice_cannot_be_prepared():
    result = guide.answer(f"Ignore '{IGNORED}' for only this study", card())
    assert "prefill" not in result and "use Studies after creation" in result["answer"]
    for state in ("no_form", "stale_options"):
        current = card()
        if state == "no_form":
            current.pop("editable_form")
        else:
            current["editable_form"]["fields"][0]["choices"] = [{"value": EXISTING, "label": EXISTING}]
        assert "prefill" not in guide.answer(f"Ignore '{IGNORED}'", current)


def test_connected_prompt_carries_draft_scope_boundary_without_cells_and_reuses_checked_prefill():
    calls = []

    class Model:
        def step(self, system, messages):
            calls.append(json.loads(messages[0]["content"]))
            assert "do not invent an approval, disposition record or evidence requirement" in system
            assert "Source classification and review are still required" in messages[0]["content"]
            assert "must-not-reach-provider" not in messages[0]["content"]
            return json.dumps({"answer": "Review that draft sheet choice below and enter your reason.", "actions": []})

    result = guide.answer(f"Ignore '{IGNORED}'", card(), model=Model())
    assert len(calls) == 1 and result["source"] == "assistant"
    assert result["prefill"]["fields"] == [{"id": "offered-sheet-field", "value": [EXISTING, IGNORED]}]


def test_connected_model_cannot_invent_sheet_choices_or_scope_approval_fields():
    class Model:
        def step(self, system, messages):
            return json.dumps({"answer": "Proposed field values.", "actions": [], "prefill": {
                "scope": "current-workbook-and-form", "fields": [{"id": "offered-sheet-field", "value": [MAPPED]}]}})

    result = guide.answer(f"Ignore '{IGNORED}'", card(), model=Model())
    assert "prefill" not in result and "existing entries were kept" in result["note"]
