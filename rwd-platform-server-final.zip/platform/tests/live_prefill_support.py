"""Actual Streamlit forms in the existing opt-in live journey rehearsal.

Only the transport is injected: its native VS Code model remains bound to the
real checkout. Product registration runs from the disposable copied application.
Revision assistance receives synthetic planning metadata, not source documents.
"""
from contextlib import contextmanager, ExitStack
import json
import os
from pathlib import Path
from unittest.mock import patch

from streamlit.testing.v1 import AppTest
import streamlit as st


@contextmanager
def connection(root, directory, actor, transport):
    import flow_assistant_page
    import state
    import intake
    import tools
    directory.mkdir(parents=True, exist_ok=True)
    (directory / "users.json").write_text(json.dumps([{"name": actor, "role": "admin", "owns": ["Science"]}]), encoding="utf-8")
    provider = {"configured": True, "instance": transport, "provider": "Live VS Code test transport", "model": transport.model}
    with ExitStack() as stack:
        stack.enter_context(patch.dict(os.environ, {"RWD_PORTAL_LOCAL_DEMO": "1", "RWD_PORTAL_LOCAL_WORKSPACE": "0",
            "RWDP_STATE_DIR": str(directory), "RWDP_GOVERNANCE_SNAPSHOT": str(directory / "absent-snapshot.json")}))
        stack.enter_context(patch.object(state, "STATE_DIR", str(directory)))
        stack.enter_context(patch.object(state, "RUNS", str(directory / "runs")))
        stack.enter_context(patch.object(intake, "REQUESTS", str(directory / "requests")))
        stack.enter_context(patch.object(tools, "warm", return_value=None))
        stack.enter_context(patch.object(flow_assistant_page, "_provider_words", lambda *_: (provider, "Live selected connection; synthetic rehearsal")))
        st.cache_data.clear()
        try:
            yield
        finally:
            st.cache_data.clear()


def healthy(at):
    assert not at.exception, "\n".join(str(error.message) for error in at.exception)
    return at


def values(at, keys):
    fields = {item.key: item.value for group in (at.text_input, at.text_area, at.selectbox, at.multiselect, at.radio, at.number_input)
              for item in group if item.key}
    assert set(keys) <= fields.keys(), "A requested draft field is not available in the current form."
    return {key: fields[key] for key in keys}


def ask(at, question, expected, transport):
    before = values(at, expected)
    call_count = len(transport.calls)
    at.chat_input[0].set_value(question).run(timeout=180)
    healthy(at)
    histories = [value for key, value in at.session_state.filtered_state.items() if key.startswith("flow_assistant_history_")]
    turn = next(turn for history in histories for turn in reversed(history) if turn["question"] == question)
    assert turn["source"] == "assistant", "This turn used fallback/refusal rather than a live model response."
    reviewed = any(button.key == "chat_form_replace" for button in at.button)
    if reviewed:
        at.button(key="chat_form_replace").click().run(timeout=180)
        healthy(at)
    actual = values(at, expected)
    assert actual == expected, {"expected": expected, "actual": actual, "answer": turn["answer"], "note": turn.get("note")}
    assert len(transport.calls) == call_count + 1, "A rerun must not repeat a model request."
    return {"status": "passed", "question": question, "source": turn["source"], "answer": turn["answer"],
            "before": before, "applied": actual, "replacement_reviewed": reviewed, "model_calls": 1}


def registration(root, directory, actor, transport, *, slug, reuse):
    import ui_text
    expected = {"np_slug": slug, "np_code": "lvr" if reuse else "lvn", "np_ver": "202609",
        "np_name": "Synthetic template journey" if reuse else "Synthetic new tumour journey",
        "np_family": "bladder", "np_vendor": "flatiron", "np_modality": "ehr", "np_tclass": "solid",
        "np_narrow": "genitourinary", "np_cond": "oncology"}
    question = (f"Fill this registration draft exactly: Product slug {slug}; Registry code {expected['np_code']}; "
        f"Display name {expected['np_name']}; Specification cut 202609; tumour bladder; Vendor flatiron; "
        "Data modality ehr; Tumour class solid; Catalogue axis genitourinary; Condition class oncology. "
        "Leave access, classifier, date and workbook for me. Do not create or approve anything.")
    with connection(root, directory, actor, transport):
        at = healthy(AppTest.from_file(str(root / "experiments/portal/app.py"), default_timeout=180).run())
        at.button(key="nav_new").click().run()
        healthy(at)
        at.radio(key="np_mode").set_value(ui_text.NEW_PRODUCT_MODES[1]).run()
        healthy(at)
        outcome = ask(at, question, expected, transport)
        assert at.selectbox(key="np_ai").value is None
        assert at.text_input(key="np_by").value == at.text_input(key="np_on").value == ""
        assert not any(button.key == "np_write" for button in at.button)
        outcome["product_created_by_chat"] = False
        return outcome


def revision(root, directory, actor, transport, pack):
    prefix = f"design_{pack}_"
    expected = {prefix + "purpose": "Support treatment patterns and outcomes studies.",
        prefix + "studies": "reader-a\nreader-b", prefix + "source": "optum", prefix + "modality": "claims",
        prefix + "add_variable": "BASELINE_ALBUMIN", prefix + "add_domain": "Laboratory results",
        prefix + "add_definition": "Timing, units and missing values require review."}
    question = ("Fill these draft fields exactly: purpose 'Support treatment patterns and outcomes studies.'; "
        "studies reader-a and reader-b, one per line; proposed source optum; modality claims; "
        "new variable BASELINE_ALBUMIN; section Laboratory results; definition 'Timing, units and missing values require review.'. "
        "Do not apply a source change, add a contract record or approve anything.")
    body = f'''
import streamlit as st
import form_assistance as forms
import flow_assistant as guide
import flow_assistant_page as chat
import plan_changes_page as page
forms.begin({str(root)!r}, {pack!r}, {actor!r}, page="Plan changes", route="plan_changes", allowed_packs=[{pack!r}], can_write=True)
card = guide.context(label="Synthetic existing product", section="Plan changes", rows=[], step=None, result=None,
    role="local scientist", perms=["start", "answer"], can_review=False)
card = guide.plan_context(card, root={str(root)!r}, pack={pack!r}, actor_id={actor!r}, allowed_packs=[{pack!r}], state=st.session_state)
chat.render({str(root)!r}, {pack!r}, card=card, actor_id={actor!r}, primary=True, metadata_only=True,
    can_write=True, allowed_packs=[{pack!r}])
page.render({str(root)!r}, {pack!r}, actor_id={actor!r}, local_demo=True, can_write=True, allowed_packs=[{pack!r}], params={{"intent": "revision"}})
forms.finish()
'''
    with connection(root, directory, actor, transport):
        at = healthy(AppTest.from_string(body, default_timeout=180).run())
        outcome = ask(at, question, expected, transport)
        assert at.session_state[prefix + "additions"] == []
        outcome["definition_added_by_chat"] = False
        outcome["source_guard_scope"] = "Synthetic user-authored planning metadata only; no source extraction was supplied."
        return outcome
