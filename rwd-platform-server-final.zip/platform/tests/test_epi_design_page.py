"""Second-pass tests of Plan changes inside the actual Streamlit application.

The repository remains read-only. Controlled descriptions isolate dependency and stale
baseline cases, while the real page, widgets, session storage, and planner all execute.
"""
from __future__ import annotations

import copy
import sys
from pathlib import Path
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parent))
from test_epi_portal_journeys import _healthy, _portal
from test_epi_design_workspace import baseline

import design_workspace as workspace

PACK = "fixtures/oncology/prostate/202606"
PREFIX = f"design_{PACK}_"


def _open(at):
    # The portal now sensibly starts on a real product; this suite deliberately
    # exercises the prostate reference instead of depending on catalogue order.
    at.selectbox(key="pack").set_value(PACK).run()
    at.radio(key="section").set_value("Plan changes").run()
    at.radio(key="plan_guide_intent").set_value("revision").run()
    _healthy(at)
    assert at.selectbox(key="pack").value == PACK


def _description(root, pack):
    desc = baseline()
    desc["pack"] = pack
    return desc


def _download_disabled(at, pack=PACK):
    return next(x for x in at.get("download_button") if x.key == f"revision_download_{pack}").proto.disabled


def _add(at, identifier="BIOMARKER"):
    at.text_input(key=PREFIX + "add_domain").set_value("clinical")
    at.text_input(key=PREFIX + "add_variable").set_value(identifier)
    at.text_area(key=PREFIX + "add_definition").set_value("Use the scientist's written definition; unknown values remain unknown.")
    at.button(key=f"revision_add_{PACK}").click().run()
    _healthy(at)


def test_add_remove_source_change_and_two_studies_round_trip():
    captured = []
    original = workspace.build_plan

    def build(*args, **kwargs):
        result = original(*args, **kwargs)
        captured.append(result)
        return result

    with patch.object(workspace, "describe", side_effect=_description), patch.object(workspace, "build_plan", side_effect=build), _portal() as at:
        _open(at)
        assert _download_disabled(at)
        at.text_area(key=PREFIX + "purpose").set_value("Treatment patterns and outcomes")
        at.text_area(key=PREFIX + "studies").set_value("Treatment patterns\nOutcomes")
        _add(at)
        p = captured[-1]
        assert p["valid"] and p["classification"] == "additive" and len(p["studies"]) == 2
        assert not _download_disabled(at)
        at.text_input(key=PREFIX + "source").set_value("optum")
        at.selectbox(key=PREFIX + "modality").set_value("claims").run()
        _healthy(at)
        p = captured[-1]
        assert p["source_changed"] and p["classification"] == "breaking"
        assert "cohort attrition" in " ".join(p["review_checklist"])
        at.button(key=f"revision_remove_{PACK}").click().run()
        _healthy(at)
        assert captured[-1]["added"] == []
        at.text_input(key=PREFIX + "source").set_value("flatiron")
        at.selectbox(key=PREFIX + "modality").set_value("ehr").run()
        assert captured[-1]["classification"] == "none" and _download_disabled(at)


def test_section_removal_exposes_dependencies_and_blocks_download():
    with patch.object(workspace, "describe", side_effect=_description), _portal() as at:
        _open(at)
        at.text_area(key=PREFIX + "purpose").set_value("Remove timing section")
        at.multiselect(key=PREFIX + "domains").set_value(["demographics", "outcomes"]).run()
        _healthy(at)
        assert _download_disabled(at)
        assert any("depends on removed variable(s): INDEXDT" in msg.value for msg in at.info)
        at.multiselect(key=PREFIX + "domains").set_value(["study_period", "demographics"]).run()
        _healthy(at)
        assert not _download_disabled(at)  # dropping outcomes preserves the remaining dependencies


def test_explicit_variable_exclusion_survives_section_toggle():
    with patch.object(workspace, "describe", side_effect=_description), _portal() as at:
        _open(at)
        at.text_area(key=PREFIX + "purpose").set_value("Remove age for this revision")
        at.multiselect(key=PREFIX + "excluded").set_value(["AGE"]).run()
        at.multiselect(key=PREFIX + "domains").set_value(["study_period", "outcomes"]).run()
        _healthy(at)
        at.multiselect(key=PREFIX + "domains").set_value(["study_period", "demographics", "outcomes"]).run()
        _healthy(at)
        assert "AGE" in at.multiselect(key=PREFIX + "excluded").value, "Turning a section off and on silently undid the scientist's explicit exclusion."


def test_stale_baseline_blocks_download_until_current_definitions_are_reviewed():
    desc = _description(None, PACK)
    with patch.object(workspace, "describe", side_effect=lambda *_: copy.deepcopy(desc)), _portal() as at:
        _open(at)
        at.text_area(key=PREFIX + "purpose").set_value("Add biomarker")
        _add(at)
        assert not _download_disabled(at)
        desc["baseline_sha256"] = "c" * 64
        desc["rows"][1]["definition"] = "Age rule revised by owner"
        at.run()
        _healthy(at)
        assert _download_disabled(at)
        assert any("source product changed" in msg.value for msg in at.warning)
        at.button(key=f"revision_refresh_{PACK}").click().run()
        _healthy(at)
        assert not _download_disabled(at)
        assert at.text_area(key=PREFIX + "purpose").value == "Add biomarker"
        assert at.session_state[PREFIX + "baseline"] == "c" * 64


def test_removing_an_addition_and_adding_another_keeps_the_chooser_valid():
    with patch.object(workspace, "describe", side_effect=_description), _portal() as at:
        _open(at)
        at.text_area(key=PREFIX + "purpose").set_value("Compare candidate additions")
        _add(at, "FIRST")
        _add(at, "SECOND")
        at.selectbox(key=PREFIX + "drop").set_value("SECOND")
        at.button(key=f"revision_remove_{PACK}").click().run()
        _healthy(at)
        assert at.selectbox(key=PREFIX + "drop").value == "FIRST"
        at.button(key=f"revision_remove_{PACK}").click().run()
        _healthy(at)
        _add(at, "THIRD")
        assert at.selectbox(key=PREFIX + "drop").value == "THIRD"
        assert not _download_disabled(at)


def test_blank_source_is_an_actionable_error_and_current_mapping_is_visible():
    desc = _description(None, PACK)
    desc["source_tables"] = {"enhanced": "t_enh_prostate", "biomarker": {"table": "t_biomarker", "columns": ["date", "result"]}}
    with patch.object(workspace, "describe", return_value=desc), _portal() as at:
        _open(at)
        at.text_area(key=PREFIX + "purpose").set_value("Review source suitability")
        _add(at)
        assert any("Current source: flatiron" in c.value for c in at.caption)
        mapping_tables = [t.value for t in at.table if "Configured table or mapping" in t.value.columns]
        assert mapping_tables and "t_enh_prostate" in str(mapping_tables[0])
        at.text_input(key=PREFIX + "source").set_value("").run()
        _healthy(at)
        assert _download_disabled(at)
        assert any("Name the proposed data source" in msg.value for msg in at.info)


def test_drafts_survive_navigation_and_stay_separate_for_each_pack():
    with patch.object(workspace, "describe", side_effect=_description), _portal() as at:
        _open(at)
        at.text_area(key=PREFIX + "purpose").set_value("Prostate study question")
        at.text_area(key=PREFIX + "studies").set_value("Study one\nStudy two")
        _add(at)
        at.radio(key="section").set_value("Home").run()
        at.radio(key="section").set_value("Plan changes").run()
        _healthy(at)
        assert at.text_area(key=PREFIX + "purpose").value == "Prostate study question"
        assert len(at.session_state[PREFIX + "additions"]) == 1
        # UI option labels are formatted, so use the actual catalogue values.
        other = "fixtures/oncology/oc/202606"
        at.selectbox(key="pack").set_value(other).run()
        at.radio(key="plan_guide_intent").set_value("revision").run()
        _healthy(at)
        other_prefix = f"design_{other}_"
        assert at.text_area(key=other_prefix + "purpose").value == ""
        assert at.session_state[other_prefix + "additions"] == []
        at.text_area(key=other_prefix + "purpose").set_value("Lung study question").run()
        at.selectbox(key="pack").set_value(PACK).run()
        at.radio(key="plan_guide_intent").set_value("revision").run()
        _healthy(at)
        assert at.text_area(key=PREFIX + "purpose").value == "Prostate study question"
        assert at.text_area(key=PREFIX + "studies").value == "Study one\nStudy two"
        assert len(at.session_state[PREFIX + "additions"]) == 1


if __name__ == "__main__":
    failed = 0
    for name, fn in sorted(globals().copy().items()):
        if name.startswith("test_") and callable(fn):
            try:
                fn()
                print(f"  ok   {name}")
            except Exception as exc:
                failed += 1
                print(f"  FAIL {name}: {type(exc).__name__}: {exc}")
    print(f"{failed} failure(s)")
    sys.exit(bool(failed))
