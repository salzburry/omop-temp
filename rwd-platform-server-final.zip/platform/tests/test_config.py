"""Smoke tests for the prostate RWDP config layer. Run: python tests/test_config.py (or pytest).

Covers the pure-Python pieces (no Spark): config loading + dotted overrides, source-table
resolution, cohort lookup, variable-pack loading, and the codelist -> Spark SQL CASE compiler
(first-match-wins order preserved).
"""
import sys
from pathlib import Path

FRAMEWORK = Path(__file__).resolve().parent.parent   # platform/ (the shared engine lives here)
sys.path.insert(0, str(FRAMEWORK))

from engine.config import load_config        # noqa: E402
from engine.config import product_config, product_dir  # noqa: E402
from engine.codelists import compile_case    # noqa: E402

CONFIG = product_config(FRAMEWORK.parent / "fixtures", "prostate")   # reference tumor
OVERRIDES = {"run.refresh": "2026q1", "run.source_schema": "rwd", "run.output_schema": "out"}


def _cfg():
    return load_config(CONFIG, overrides=OVERRIDES)


def test_overrides_applied():
    cfg = _cfg()
    assert cfg.refresh == "2026q1"
    assert cfg.source_schema == "rwd"
    # blank/empty overrides must be ignored (a job may pass through blanks)
    cfg2 = load_config(CONFIG, overrides={**OVERRIDES, "run.refresh": ""})
    assert cfg2.refresh == "REPLACE_ME"


def test_version_snapshot_filled():
    # `version` is the combined spec+cut label; `spec_version` is the CalVer contract alone (no
    # snapshot) — the two axes must not duplicate when stamped onto rows/manifests.
    assert _cfg().version == "202606.2026q1"
    assert _cfg().spec_version == "202606"


# the fixture root, explicitly: these resolution tests exercise product_dir over the packs
# that exist, and every pack in this repository is a reference fixture (no silent
# cross-root fallback - the caller names the root it means)
_PRODUCTS = FRAMEWORK.parent / "fixtures"


def test_product_dir_default_is_registry_current():
    # no explicit version -> the registry's current_spec_version (202606), and that pack exists
    d = product_dir(_PRODUCTS, "prostate")
    assert d.name == "202606" and d.parent.name == "prostate"
    assert (d / "config" / "data_product.yaml").exists()


def test_product_dir_explicit_declared_version_resolves():
    # an explicit, registry-DECLARED version (the superseded v1) resolves to its own buildable pack
    d = product_dir(_PRODUCTS, "prostate", spec_version="202603")
    assert d.name == "202603"
    assert (d / "config" / "data_product.yaml").exists()


def test_product_dir_unknown_version_raises():
    # a typo'd explicit version fails LOUDLY (error names the bad value + the known set), instead of
    # silently building a path that 404s deep in the config load.
    try:
        product_dir(_PRODUCTS, "prostate", spec_version="209999")
    except KeyError as e:
        assert "209999" in str(e) and "202606" in str(e) and "202603" in str(e)
    else:
        raise AssertionError("expected KeyError for an undeclared explicit spec_version")


def test_table_resolution():
    cfg = _cfg()
    assert cfg.table("enhanced") == "rwd.t_enh_prostate_2026q1"
    assert cfg.table("mortality") == "rwd.t_mortality_v2_2026q1"
    # every declared source resolves to a table (16 from the R script + the Panoramic spec additions:
    # progression, biomarkers, …). Tracks the config's source map so it doesn't churn each phase.
    assert len(cfg.all_tables()) == len(cfg.raw["sources"]) >= 16


def test_data_format_overlay_edm_vs_panoramic():
    # data_format selects a per-format overlay (source map + table layout + column renames); EDM is the
    # default no-op, Panoramic overlays onto the base. The engine still sees logical/EDM column names.
    from engine.config import Config
    from pathlib import Path
    base = {"run": {"source_schema": "s", "refresh": "2026q1"}, "vendor": "flatiron",
            "sources": {"enhanced": "edm_enh", "lot": "edm_lot"},
            "formats": {"Panoramic": {"sources": {"enhanced": "pano_enh"},
                                      "source_layout": "{schema}.pano_{stem}_{refresh}",
                                      "rename": {"enhanced": {"RegimenName": "linename"}}}}}
    edm = Config(dict(base), Path("."))
    assert edm.data_format == "EDM" and edm.sources["enhanced"] == "edm_enh" and edm.source_renames == {}
    pano = Config({**base, "run": {**base["run"], "data_format": "Panoramic"}}, Path("."))
    assert pano.sources == {"enhanced": "pano_enh", "lot": "edm_lot"}        # base + Panoramic overlay
    assert pano.source_layout == "{schema}.pano_{stem}_{refresh}"
    assert pano.source_renames["enhanced"]["RegimenName"] == "linename"
    assert "pano_enh" in pano.table("enhanced")                             # Panoramic stem + layout


def test_output_fqn():
    assert _cfg().output_fqn == "out.rwdp_pros_pano_202606"


def test_cohorts():
    cfg = _cfg()
    # 7-cohort dual-setting model (mHSPC + mCRPC), COHORTN 1-7.
    assert [c["id"] for c in cfg.cohorts] == ["overall_mhspc", "overall_mcrpc", "lot1_mhspc",
                                              "lot1_mcrpc", "lot2_mcrpc", "lot3_mcrpc", "lot4_mcrpc"]
    assert [c["cohortn"] for c in cfg.cohorts] == [1, 2, 3, 4, 5, 6, 7]
    assert cfg.cohort("lot2_mcrpc")["lot_number"] == 2
    # each cohort carries its line_setting; overall cohorts index off their setting's diagnosis model.
    assert cfg.cohort("overall_mhspc")["line_setting"] == "mHSPC"
    assert cfg.cohort("overall_mhspc")["index"] == "hspc_diagnosis_date"
    assert cfg.cohort("lot1_mhspc")["line_setting"] == "mHSPC"
    assert cfg.cohort("lot4_mcrpc")["line_setting"] == "mCRPC"
    # per-setting COHORTU codes: Untreated mCRPC=1 / Treated mCRPC=2 / Untreated mHSPC=3 / Treated mHSPC=4
    by = cfg.treatment_status["by_setting"]
    assert by["mcrpc"]["treated_code"] == 2 and by["mhspc"]["untreated_code"] == 3


def test_lot_model_defaults_backward_compatible():
    cfg = _cfg()   # prostate (and the unseen NSCLC/SCLC) rely on these defaults being unchanged
    assert cfg.lot_line_number_col == "new_lot_n"     # derived row_number (prostate behaviour)
    assert cfg.lot_exclude_settings == []
    assert cfg.lot_maintenance_column == "ismaintenancetherapy"   # default; never consulted (no maintenance cohorts)
    assert all(c.get("maintenance") is None for c in cfg.cohorts)


OC_CONFIG = product_config(FRAMEWORK.parent / "fixtures", "oc")


def test_oc_cohort_lot_model():
    cfg = load_config(OC_CONFIG, overrides=OVERRIDES)
    assert cfg.lot_line_number_col == "linenumber"    # OC indexes off the raw LOT linenumber
    assert [c["id"] for c in cfg.cohorts] == ["overall", "lot1", "lot1m", "lot2", "lot2m",
                                              "lot3", "lot4", "lot5"]
    assert cfg.cohort("lot1m")["maintenance"] is True
    assert cfg.cohort("lot1")["maintenance"] is False
    assert cfg.cohort("overall").get("maintenance") is None


EC_CONFIG = product_config(FRAMEWORK.parent / "fixtures", "endometrial")


def test_source_fqns_single_when_no_union():
    cfg = _cfg()                                       # prostate: no union
    assert cfg.source_union is None
    assert cfg.source_fqns("enhanced") == [cfg.table("enhanced")]


def test_source_union_resolution_ec():
    cfg = load_config(EC_CONFIG, overrides={"run.refresh": "2026m03"})
    assert cfg.source_union is not None                 # EC = Flatiron EDM ∪ Dostarlimab registry
    # each source resolves to one table per member schema (db=EDM/DOS)
    assert cfg.source_fqns("enhanced") == [
        "clnprw_flatiron_endo_use.t_enh_advendom_2026m03",
        "clnprw_flatiron_dostar_endo_use.t_enh_advendom_2026m03"]


def test_packs_load():
    packs = _cfg().packs()
    assert set(packs) == {"prostate_demographics", "prostate_clinical",
                          "prostate_treatment", "prostate_outcomes"}
    # age banding present and ordered
    bands = packs["prostate_demographics"]["age_bands"]
    assert bands[0]["label"] == "0-18" and bands[-1]["label"] == "Unknown"


def test_treatment_codelist_compiles_in_order():
    cfg = _cfg()
    codelist = cfg.codelist("treatment_categories")
    label_sql, code_sql = compile_case(codelist)
    # First match wins: Abiraterone monotherapy must appear before the catch-all.
    assert label_sql.index("Abiraterone monotherapy") < label_sql.index("Any other therapy")
    # 'No treatment' (linename IS NULL) evaluated before the TRUE catch-all.
    assert label_sql.index("No treatment") < label_sql.index("Any other therapy")
    # NHA combination compiles the AND-of-ORs.
    assert "LIKE '%abiraterone%'" in label_sql and "LIKE '%,%'" in label_sql
    # catch-all is the final WHEN TRUE; codes are integers.
    assert label_sql.rstrip().endswith("THEN 'Any other therapy' END")
    assert "WHEN TRUE THEN 16" in code_sql


if __name__ == "__main__":
    fns = [v for k, v in sorted(globals().items()) if k.startswith("test_")]
    for fn in fns:
        fn()
        print(f"ok  {fn.__name__}")
    print(f"\n{len(fns)} tests passed")
