"""contract_scaffold.py refuses to write over anything a person authored, and writes atomically.

THE DEFECT. `--records` (and `--out`, `--coverage`) took any path. Pointed at
`<pack>/handoff/FUNCTIONAL_CONTRACT.md`, the tool first read that contract to EXCLUDE every row it
already covers, then opened the same file in overwrite mode and wrote the scaffold over it: the
authored contract was gone, the exit code was 0, and the scaffold it left behind was missing exactly
the records the contract had held. The same flags could replace the extraction being read, or any
governed file a gate keys on.

THE RULE, pinned here: before any read or write, every output path is resolved (realpath) and
refused when it lands inside the pack anywhere but `spec_pipeline/out/`, equals the extracted input,
or reaches a file under `handoff/`, `config/`, `variables/`, `codelists/`, `prog_spec/` or
`source_refs.yaml`. A refusal exits 2, says so in plain language, and writes nothing. Legitimate
outputs go through a sibling temporary file and one `os.replace`, so a failure after generation
never leaves a half-written artifact.

The subprocess cases run the tool the way a person types it, on a copy of the walkthrough pack in
a temporary directory, so the checkout is never touched.

NO PYTEST FIXTURES AND NO `parametrize` — CI runs every suite as a script.

Run: python3 platform/tests/test_contract_scaffold_guard.py (or pytest).
"""
import glob
import hashlib
import os
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

FRAMEWORK = Path(__file__).resolve().parent.parent
REPO = FRAMEWORK.parent
sys.path.insert(0, str(FRAMEWORK / "tools"))

import contract_scaffold as cs                                                      # noqa: E402

TOOL = FRAMEWORK / "tools" / "contract_scaffold.py"
DEMO = REPO / "sandbox" / "demo_walkthrough" / "bladder" / "202609"
ENV = dict(os.environ, PYTHONUTF8="1")
# What a scientist must not be shown on the terminal (the portal's own plain-language rule).
JARGON = ("§", "REFUSED", " — ", "->", "↳", "noqa", "regex")


def _sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def _copy_pack():
    """The walkthrough pack, copied whole into a fresh temporary directory."""
    tmp = tempfile.mkdtemp(prefix="scaffold_guard_")
    pack = os.path.join(tmp, "pack")
    shutil.copytree(DEMO, pack, ignore=shutil.ignore_patterns("__pycache__"))
    return tmp, pack


def _run(cwd, *argv):
    p = subprocess.run([sys.executable, str(TOOL), *argv], cwd=cwd, env=ENV, capture_output=True,
                       text=True, encoding="utf-8", errors="replace", timeout=600)
    return p.returncode, p.stdout or "", p.stderr or ""


def _staging_files(directory):
    """Any leftover temporary file from an atomic write."""
    return glob.glob(os.path.join(directory, ".*.tmp"))


# --- the destructive call is refused -------------------------------------------------------------

def test_records_pointed_at_the_contract_is_refused_and_nothing_is_written():
    """The case the guard exists for: exit 2, a refusal a person can read, the contract byte-identical,
    and the OTHER output of the same call not written either (the refusal precedes every write)."""
    tmp, pack = _copy_pack()
    try:
        contract = os.path.join(pack, "handoff", "FUNCTIONAL_CONTRACT.md")
        before = _sha(contract)
        coverage = os.path.join(pack, "spec_pipeline", "out", "COVERAGE_NEW.md")
        rc, out, err = _run(tmp, os.path.join(pack, "spec_pipeline", "out", "extracted.json"),
                            "--product", pack, "--records", contract, "--coverage", coverage)
        assert rc == 2, (rc, out, err)
        text = out + err
        assert "Refusing to write" in text and "Nothing was written" in text, text
        assert "handoff/FUNCTIONAL_CONTRACT.md" in text, text
        assert "spec_pipeline/out" in text, "the refusal must say where the output belongs"
        assert _sha(contract) == before, "the authored contract was changed"
        assert not os.path.exists(coverage), "a second output was written despite the refusal"
        assert not _staging_files(os.path.join(pack, "handoff"))
        assert not _staging_files(os.path.join(pack, "spec_pipeline", "out"))
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


def test_out_pointed_at_source_refs_is_refused():
    """The material register is a governed file at the pack root, not under a governed folder."""
    tmp, pack = _copy_pack()
    try:
        refs = os.path.join(pack, "source_refs.yaml")
        before = _sha(refs)
        rc, out, err = _run(tmp, os.path.join(pack, "spec_pipeline", "out", "extracted.json"),
                            "--product", pack, "--out", refs)
        assert rc == 2, (rc, out, err)
        assert "Refusing to write" in out + err and "source_refs.yaml" in out + err, out + err
        assert _sha(refs) == before
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


def test_coverage_pointed_at_the_extracted_input_is_refused():
    """The extraction is read first and would be replaced by the report computed from it."""
    tmp, pack = _copy_pack()
    try:
        extracted = os.path.join(pack, "spec_pipeline", "out", "extracted.json")
        before = _sha(extracted)
        rc, out, err = _run(tmp, extracted, "--product", pack, "--coverage", extracted)
        assert rc == 2, (rc, out, err)
        assert "extracted specification" in out + err, out + err
        assert _sha(extracted) == before
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


def test_the_refusal_comes_before_any_read():
    """With an extracted file that does not exist, a guard placed after the read would die with a
    traceback about the missing input; the refusal is what must come out."""
    tmp, pack = _copy_pack()
    try:
        contract = os.path.join(pack, "handoff", "FUNCTIONAL_CONTRACT.md")
        rc, out, err = _run(tmp, os.path.join(pack, "no_such_extraction.json"),
                            "--product", pack, "--records", contract)
        assert rc == 2, (rc, out, err)
        assert "Refusing to write" in out + err and "Traceback" not in out + err, out + err
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


def test_the_refusal_is_plain_language():
    tmp, pack = _copy_pack()
    try:
        extracted = os.path.join(pack, "spec_pipeline", "out", "extracted.json")
        for dest in (os.path.join(pack, "handoff", "FUNCTIONAL_CONTRACT.md"),
                     os.path.join(pack, "source_refs.yaml"),
                     os.path.join(pack, "README.md"), extracted):
            text = cs.refuse_destination(pack, dest, extracted)
            assert text, dest
            for tok in JARGON:
                assert tok not in text, (tok, text)
            assert text.endswith("."), text
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


# --- the legitimate call still works -------------------------------------------------------------

def test_records_under_spec_pipeline_out_succeeds_and_is_written_atomically():
    tmp, pack = _copy_pack()
    try:
        out_dir = os.path.join(pack, "spec_pipeline", "out")
        records = os.path.join(out_dir, "SCAFFOLDED_RECORDS.md")
        coverage = os.path.join(out_dir, "COVERAGE.md")
        scaffold = os.path.join(out_dir, "scaffold.json")
        contract = os.path.join(pack, "handoff", "FUNCTIONAL_CONTRACT.md")
        before = _sha(contract)
        rc, out, err = _run(tmp, os.path.join(out_dir, "extracted.json"), "--product", pack,
                            "--lint", os.path.join(out_dir, "lint.json"),
                            "--records", records, "--coverage", coverage, "--out", scaffold)
        assert rc == 0, (rc, out, err)
        assert "contract-ready records ->" in out and "coverage report ->" in out, out
        head = Path(records).read_text(encoding="utf-8").splitlines()[0]
        assert head.startswith("# Scaffolded contract records"), head
        assert Path(coverage).read_text(encoding="utf-8").startswith("# Spec coverage")
        assert Path(scaffold).read_text(encoding="utf-8").lstrip().startswith("{")
        assert _sha(contract) == before, "the contract is read, never written, by this tool"
        assert not _staging_files(out_dir), "a temporary file survived the atomic write"
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


def test_a_failed_write_leaves_the_existing_file_intact_and_no_staging_file():
    """`_write_atomic` is the only writer: a failure inside it must neither truncate the file that
    was there nor leave its temporary sibling behind."""
    tmp = tempfile.mkdtemp(prefix="scaffold_atomic_")
    try:
        target = os.path.join(tmp, "COVERAGE.md")
        Path(target).write_bytes(b"the version that was there\n")
        cs._write_atomic(target, "a complete new version\n")
        assert Path(target).read_bytes() == b"a complete new version\n"
        assert not _staging_files(tmp)
        try:
            cs._write_atomic(target, b"bytes are not text")           # fails inside the write
        except TypeError:
            pass
        else:
            raise AssertionError("a failing write did not raise")
        assert Path(target).read_bytes() == b"a complete new version\n", "the failure truncated it"
        assert not _staging_files(tmp), "the failure left its temporary file"
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


# --- the rule itself -----------------------------------------------------------------------------

def test_refuse_destination_rules():
    """Location decides, after realpath: `..` does not dodge the pack, a governed folder is refused
    wherever it is, and an ordinary path outside the pack is allowed."""
    tmp, pack = _copy_pack()
    try:
        extracted = os.path.join(pack, "spec_pipeline", "out", "extracted.json")
        ok = os.path.join(pack, "spec_pipeline", "out", "SCAFFOLDED_RECORDS.md")
        assert cs.refuse_destination(pack, ok, extracted) is None
        assert cs.refuse_destination(pack, os.path.join(tmp, "elsewhere.md"), extracted) is None
        # relative spellings resolve the same way as absolute ones
        here = os.getcwd()
        os.chdir(tmp)
        try:
            assert cs.refuse_destination("pack", "pack/spec_pipeline/out/x.md", "pack/spec_pipeline/out/extracted.json") is None
            assert cs.refuse_destination("pack", "pack/handoff/FUNCTIONAL_CONTRACT.md", None)
        finally:
            os.chdir(here)
        # every governed folder, by name, and the register at the root
        for folder in ("handoff", "config", "variables", "codelists", "prog_spec"):
            text = cs.refuse_destination(pack, os.path.join(pack, folder, "anything.md"), extracted)
            assert text and f"{folder}/anything.md" in text, (folder, text)
        assert "source_refs.yaml" in cs.refuse_destination(pack, os.path.join(pack, "source_refs.yaml"), extracted)
        # inside the pack but in no governed folder is still not generated territory
        assert "not under spec_pipeline/out/" in cs.refuse_destination(pack, os.path.join(pack, "notes.md"), extracted)
        assert cs.refuse_destination(pack, os.path.join(pack, "spec_pipeline", "pipeline.conf"), extracted)
        # `..` out of the generated folder lands where it lands
        dodge = os.path.join(pack, "spec_pipeline", "out", "..", "..", "handoff", "FUNCTIONAL_CONTRACT.md")
        assert "handoff/FUNCTIONAL_CONTRACT.md" in cs.refuse_destination(pack, dodge, extracted)
        # another pack's governed file, outside the pack named on the command line
        other = os.path.join(tmp, "other_pack", "handoff", "FUNCTIONAL_CONTRACT.md")
        assert "under handoff/" in cs.refuse_destination(pack, other, extracted)
        other_refs = os.path.join(tmp, "other_pack", "source_refs.yaml")
        assert "material register" in cs.refuse_destination(pack, other_refs, extracted)
        # the extracted input, however spelled
        assert "extracted specification" in cs.refuse_destination(
            pack, os.path.join(pack, "spec_pipeline", "out", ".", "extracted.json"), extracted)
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


def test_the_flow_scaffold_act_writes_where_the_guard_allows():
    """flow.py's g2_scaffold act is the path a person is routed down; it must name the generated
    folder, or every routed scaffold would now be refused."""
    src = (FRAMEWORK / "tools" / "flow.py").read_text(encoding="utf-8")
    assert '"--records", f"{pack}/spec_pipeline/out/SCAFFOLDED_RECORDS.md"' in src


def test_the_guard_adds_no_attestation_flag():
    """The guard is a rule on paths the tool already takes; it offers no new way to assert anything."""
    src = TOOL.read_text(encoding="utf-8")
    for flag in ("--force", "--overwrite", "--approve", "--approved-by"):
        assert f'"{flag}"' not in src, flag


if __name__ == "__main__":
    # CI RUNS EVERY SUITE AS A SCRIPT — without this block the file runs no tests and exits 0.
    bad = 0
    for _name, _fn in sorted(globals().items()):
        if _name.startswith("test_") and callable(_fn):
            try:
                _fn()
                print(f"  ok  {_name}")
            except Exception as _e:                  # noqa: BLE001 - report and continue
                bad += 1
                print(f"FAIL  {_name}: {_e}")
    sys.exit(1 if bad else 0)
