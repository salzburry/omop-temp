"""Three local researcher corridors, with optional actual selected-product Spark.

Only disposable checkouts and explicit synthetic reference/expectation fixtures are
used. New products deliberately stop at missing source/scientific review; saved
drafts, checked records and submitted requests are never called approval/release.
Run the selected-product case explicitly with RWD_FINAL_JOURNEY_SPARK=1. Its
runtime uses the existing guarded queue and produces counted assertion receipts.
"""
from __future__ import annotations

import copy
import hashlib
import json
import os
from pathlib import Path
import sys
import time

import openpyxl
import pytest
from streamlit.testing.v1 import AppTest
import yaml

ROOT = Path(__file__).resolve().parents[2]
sys.path[:0] = [str(ROOT / folder) for folder in
               ("platform/tests", "experiments/portal", "platform/tools", "platform")]
from test_epi_new_product_local_journey import checkout, git
from _epi_gist_fixture import seed_bladder
from test_epi_configuration_proposals import seed, brief, PACK as REVISION, RECENCY
from test_epi_source_workspace import profile_file
import configuration_proposals as proposals
import design_workspace as design
import implementation_runtime as runtime
import portal_runtime
import science_workspace as science
import scientific_definitions as definitions
import source_workspace as sources
import synthetic_expected as expected

ACTOR = "Case Scientist"
NEW = "products/oncology/final_new_bladder/202609"
TEMPLATE = "products/oncology/final_template_bladder/202609"
PSOC = "9.PROC PSOC Strategy"
REVIEW_ID = "9" * 24
CASE_VALUES = [
    {"id": "baseline_cells", "cohort": "overall_muc", "patientid": "p1", "row_count": 1,
     "expected": {"index_date": "2020-01-01", "cohortn": 1, "race": "White"}},
    {"id": "absent_line_subject", "cohort": "overall_muc", "patientid": "pc1", "row_count": 0,
     "expected": {}},
]


@pytest.fixture
def tree(tmp_path, monkeypatch):
    root = tmp_path / "repo"
    root.mkdir()
    checkout(root)  # Tracked/public files only; no credentials, uploads or private drafts.
    restricted = tmp_path / "restricted"
    restricted.mkdir()
    monkeypatch.setenv("RWD_PROFILE_DIR", str(restricted))
    monkeypatch.setenv("RWD_SOURCE_WORKSPACE_DIR", str(tmp_path / "private-source"))
    monkeypatch.setenv("RWDP_STATE_DIR", str(tmp_path / "private-state"))
    monkeypatch.setenv("RWD_PORTAL_AI_PROVIDER", "")
    return root, restricted


def _bytes(product):
    return {p.relative_to(product).as_posix(): p.read_bytes() for p in product.rglob("*")
            if p.is_file() and ".portal-drafts" not in p.parts}


def _row_app(root, pack, item):
    app = AppTest.from_string(f'''import scientific_definition_page as page
page.render({str(root)!r}, {pack!r}, {ACTOR!r}, local_demo=True, can_write=True,
    can_view=True, naming_packs=[{pack!r}], initial_item_id={item!r})
''', default_timeout=60).run()
    assert not app.exception, [error.message for error in app.exception]
    return app


def _canonical(root, argv, phase, seconds, record_property):
    """Use the actual portal guard; Preview matches its 90-second default.

    The 900-second test apply cap is stricter than the UI's 1800-second cap.
    """
    start = time.monotonic()
    result = portal_runtime.run(argv, cwd=str(root), timeout_s=seconds,
                               extra_env={"PYTHONUNBUFFERED": "1"})
    duration = round(time.monotonic() - start, 3)
    record_property(phase + "_seconds", duration)
    record_property(phase + "_exit_code", result.returncode)
    print(json.dumps({"phase": phase, "seconds": duration, "exit_code": result.returncode}), flush=True)
    assert result.returncode == 0, phase + ": " + (result.stdout + result.stderr)[-6000:]
    return result


def _proposal(root, pack, *, retained, exclusions, changes=None, additions=None, source="flatiron", modality="ehr"):
    baseline = design.describe(root, pack)
    plan = design.build_plan(baseline, purpose="Compare the two studies' requirements and retain explicit review boundaries.",
        studies=["reader-a", "reader-b"], retained=retained, additions=additions or [],
        target_source=source, target_modality=modality)
    staged = proposals.stage(root, pack, plan, configuration_changes=changes or [], study_exclusions=exclusions,
        actor_id=ACTOR, expected_baseline=baseline["baseline_sha256"], allowed_packs=[pack],
        local_demo=True, can_write=True)
    assert staged["ok"], staged
    return staged


def test_new_workbook_scope_draft_resume_and_actionable_source_handoff(tree, tmp_path, record_property):
    root, _restricted = tree
    workbook = tmp_path / "synthetic_bladder.xlsx"
    book = openpyxl.load_workbook(ROOT / "sandbox/demo_walkthrough/bladder_202609_program_spec.xlsx")
    sheet = book.create_sheet(PSOC)
    sheet.append(["Variable", "Definition"])
    sheet.append(["PSOC_ONLY_TEST", "Strategy value outside this product's intended scope."])
    book.save(workbook)
    book.close()
    original = workbook.read_bytes()
    argv = [sys.executable, "platform/tools/new_product.py", "final_new_bladder", "--code", "fnb",
        "--name", "Final bladder new-product journey", "--vendor", "flatiron", "--tumor-class", "solid",
        "--spec-version", "202609", "--narrow", "genitourinary", "--condition-class", "oncology", "--modality", "ehr",
        "--tumour-family", "bladder", "--ai-classification", "sponsor_ai_eligible", "--classified-by", ACTOR,
        "--classified-date", "2026-09-08", "--workbook", str(workbook), "--exclude-sheet", PSOC,
        "--exclude-sheet-reason", "The strategy variables are not needed for either planned study.", "--root", str(root)]
    before = _bytes(root / "products")
    _canonical(root, argv, "preview", 90, record_property)
    assert _bytes(root / "products") == before
    applied = _canonical(root, [*argv, "--apply"], "apply", 900, record_property)
    assert "every validator passed" in applied.stdout
    assert workbook.read_bytes() == original
    product = root / NEW
    extracted = json.loads((product / "spec_pipeline/out/extracted.json").read_bytes())
    assert extracted["extraction"]["product_ignored_tabs"] == [PSOC]
    queue = definitions.work_queue(root, NEW, ACTOR, allowed_packs=[NEW])
    assert queue["ok"] and queue["total"] > 1 and queue["counts"] == {"Untouched": queue["total"]}, queue
    assert not any(row["variable_id"] == "PSOC_ONLY_TEST" for row in queue["rows"])
    item = queue["rows"][0]["item_id"]
    current = definitions.describe(root, NEW, ACTOR, item_id=item, allowed_packs=[NEW])
    values = dict(current["values"], derivation="Literal first draft: timing and missing-value choices are unfinished.")
    contract = (product / "handoff/FUNCTIONAL_CONTRACT.md").read_bytes()
    saved = definitions.save_draft(root, NEW, ACTOR, item, values, expected_input_digest=current["input_digest"],
        expected_draft_digest=current["draft_digest"], allowed_packs=[NEW], local_demo=True, can_write=True)
    assert saved["ok"], saved
    app = _row_app(root, NEW, item)  # New session: persisted draft, no prior widget state.
    assert app.text_area(key="scientific_definition_field_derivation").value == values["derivation"]
    assert definitions.work_queue(root, NEW, ACTOR, allowed_packs=[NEW])["counts"]["Draft"] == 1
    app.button(key="scientific_definition_next_row").click().run()
    assert not app.exception
    assert app.selectbox(key="scientific_definition_row").value != item
    assert (product / "handoff/FUNCTIONAL_CONTRACT.md").read_bytes() == contract
    science_card = science.describe(root, NEW, ACTOR, route="definition_reuse", item_id=item, allowed_packs=[NEW])
    assert science_card["ok"] and science_card["item_id"] == item
    source = sources.describe(root, NEW, ACTOR, allowed_packs=[NEW])
    assert source["ok"] and source["blockers"]
    offered = sources.evidence_options(root, NEW, ACTOR, kind="profile", allowed_packs=[NEW])
    assert not offered.get("options") and (offered.get("next_step") or offered.get("errors")), offered
    record_property("journey", "Canonical preview and apply; sheet scope preserved; unfinished row resumes; missing evidence remains actionable.")
    record_property("scientific_approval", "false")


def test_template_checked_definition_two_studies_and_review_remain_separate(tree, record_property):
    root, _restricted = tree
    product = seed_bladder(root, pack=TEMPLATE)
    baseline = _bytes(product)
    current = definitions.describe(root, TEMPLATE, ACTOR, item_id="clinical:2", allowed_packs=[TEMPLATE])
    assert current["ok"], current
    values = copy.deepcopy(current["values"])
    values["notes"] = "Synthetic reviewer compared the existing ECOG timing for treatment-pattern and outcomes studies. Scientific applicability still requires review."
    checked = definitions.preview(root, TEMPLATE, ACTOR, "clinical:2", values,
        expected_input_digest=current["input_digest"], allowed_packs=[TEMPLATE])
    assert checked["ok"] and checked["passed"] and checked["diff"], checked
    assert _bytes(product) == baseline
    saved = definitions.apply(root, TEMPLATE, ACTOR, "clinical:2", checked["values"],
        expected_input_digest=checked["input_digest"], expected_manifest_digest=checked["manifest_digest"],
        confirmed=True, allowed_packs=[TEMPLATE], local_demo=True, can_write=True)
    assert saved["ok"] and not saved["approved"] and not saved["released"], saved
    queue = definitions.work_queue(root, TEMPLATE, ACTOR, allowed_packs=[TEMPLATE])
    assert queue["ok"] and queue["counts"]["Checked"] == 1 and queue["counts"]["Untouched"] > 0, queue
    app = _row_app(root, TEMPLATE, "clinical:2")
    app.button(key="scientific_definition_next_row").click().run()
    assert not app.exception and app.selectbox(key="scientific_definition_row").value != "clinical:2"
    source = science.describe(root, TEMPLATE, ACTOR, route="definition_reuse", item_id="clinical:2", allowed_packs=[TEMPLATE])
    assert source["ok"] and source["source_rows"]
    product_before_proposal = _bytes(product)
    proposal = _proposal(root, TEMPLATE, retained=[], exclusions=[{"study": "reader-a", "variables": ["ECOG"]}],
        changes=[{"ref": RECENCY, "value": 127}])
    packet = proposal["proposal"]
    assert packet["study_exclusions"] == [{"study": "reader-a", "variables": ["ECOG"]}]
    assert packet["impact"]["shared_removed"] == [] and not packet["engineering_handoff"]
    checked = proposals.validate(root, TEMPLATE, proposal_id=proposal["proposal_id"], actor_id=ACTOR,
        allowed_packs=[TEMPLATE], local_demo=True, can_write=True)
    assert checked["ok"] and checked["passed"], checked
    submitted = proposals.submit(root, TEMPLATE, proposal_id=proposal["proposal_id"], actor_id=ACTOR,
        allowed_packs=[TEMPLATE], local_demo=True, can_write=True)
    assert submitted["ok"] and not submitted["submission"]["approved"] and not submitted["submission"]["released"]
    assert _bytes(product) == product_before_proposal
    reopened = proposals.load(root, TEMPLATE, proposal_id=proposal["proposal_id"], actor_id=ACTOR, allowed_packs=[TEMPLATE])
    assert reopened["ok"] and not reopened["stale"]
    record_property("journey", "Template interpretation checked; two-study proposal validates and requests review; shared definition and science remain unchanged by submission.")


def test_existing_revision_handoff_source_selection_and_stale_recovery(tree, record_property):
    root, restricted = tree
    product = seed(root, consumers=True)
    # Explicit synthetic delivery metadata used only to exercise the source UI.
    pipeline = product / "config/pipeline.yaml"
    document = yaml.safe_load(pipeline.read_bytes())
    document["run"].update(source_schema="synthetic_metadata", refresh="202609", output_schema="synthetic_output")
    pipeline.write_text(yaml.safe_dump(document, sort_keys=False), encoding="utf-8")
    cfg, identity = sources._identity(product)
    tables = {cfg.sources["demographics"]: ["patientid", "birthyear"]}
    profile = profile_file(restricted / "reviewed_delivery.tsv", tables, identity)
    profile_file(restricted / "wrong_cut.tsv", tables, identity, cut="202608")
    offered = sources.evidence_options(root, REVISION, ACTOR, kind="profile", allowed_packs=[REVISION])
    assert offered["ok"] and [row["name"] for row in offered["options"]] == [profile.name], offered
    request = sources.create_request(root, REVISION, ACTOR, allowed_packs=[REVISION], local_demo=True, can_write=True)
    assert request["ok"], request
    received = sources.receive_profile(root, REVISION, ACTOR, record_id=request["record"]["id"],
        profile_name=offered["options"][0]["name"], allowed_packs=[REVISION], local_demo=True, can_write=True)
    assert received["ok"] and received["record"]["state"] == "profile_received_for_review", received
    reopened = sources.read(root, REVISION, ACTOR, request["record"]["id"], allowed_packs=[REVISION])
    assert reopened["ok"] and not reopened["stale"]
    before_product, before_pins = _bytes(product), _bytes(root / "work")
    staged = _proposal(root, REVISION, retained=["INDEXDT", "OS", "SUMMARY"],
        exclusions=[{"study": "reader-a", "variables": ["AGE"]}], changes=[{"ref": RECENCY, "value": 127}],
        additions=[{"variable_id": "BASELINE_ALBUMIN", "domain": "clinical",
                    "definition": "Baseline albumin; unit harmonisation, timing and missing values require source and scientific review."}],
        source="optum", modality="claims")
    packet = staged["proposal"]
    assert packet["impact"]["shared_removed"] == ["UNUSED"]
    assert {row["kind"] for row in packet["engineering_handoff"]} == {"new_derivation", "shared_removal", "source_change"}
    checked = proposals.validate(root, REVISION, proposal_id=staged["proposal_id"], actor_id=ACTOR,
        allowed_packs=[REVISION], local_demo=True, can_write=True)
    assert checked["ok"] and not checked["passed"]
    assert not proposals.submit(root, REVISION, proposal_id=staged["proposal_id"], actor_id=ACTOR,
        allowed_packs=[REVISION], local_demo=True, can_write=True)["ok"]
    sharing = proposals.share_preview(root, REVISION, proposal_id=staged["proposal_id"], actor_id=ACTOR, allowed_packs=[REVISION])
    sent = proposals.request_engineering(root, REVISION, proposal_id=staged["proposal_id"], actor_id=ACTOR,
        expected_digest=sharing["digest"], note="Review the exact mixed changes and preserve the two distinct study scopes.",
        confirmed=True, allowed_packs=[REVISION], local_demo=True, can_write=True)
    assert sent["ok"], sent
    loaded = proposals.load_engineering_request(root, REVISION, sent["handoff"]["id"], actor_id="Engineering reviewer", allowed_packs=[REVISION])
    assert loaded["ok"] and loaded["packet"]["proposal"] == packet, loaded
    assert _bytes(root / "work") == before_pins
    assert all((product / name).read_bytes() == raw for name, raw in before_product.items())
    source_bytes = pipeline.read_bytes()
    pipeline.write_bytes(source_bytes + b"\n# A later delivery edit needs fresh evidence.\n")
    stale = sources.read(root, REVISION, ACTOR, request["record"]["id"], allowed_packs=[REVISION])
    assert stale["ok"] and stale["stale"]
    stale_packet = proposals.load_engineering_request(root, REVISION, sent["handoff"]["id"], actor_id=ACTOR, allowed_packs=[REVISION])
    assert stale_packet["ok"] and stale_packet["stale"]
    assert stale_packet["packet"]["proposal"]["study_exclusions"] == packet["study_exclusions"]
    pipeline.write_bytes(source_bytes)
    assert not sources.read(root, REVISION, ACTOR, request["record"]["id"], allowed_packs=[REVISION])["stale"]
    assert not proposals.load_engineering_request(root, REVISION, sent["handoff"]["id"], actor_id=ACTOR, allowed_packs=[REVISION])["stale"]
    record_property("journey", "Compatible delivery selected; mixed revision cannot submit; exact engineering packet survives interruption and detects stale inputs.")


@pytest.mark.skipif(os.environ.get("RWD_FINAL_JOURNEY_SPARK") != "1", reason="Explicit opt-in required for the serial selected-product Spark build.")
def test_actual_selected_product_expected_outputs_on_final_code(tree, record_property):
    root, _restricted = tree
    seed_bladder(root, pack=TEMPLATE)
    relative = TEMPLATE + "/handoff/IMPLEMENTATION_REVIEWS/" + REVIEW_ID + "/synthetic_cases.json"
    path = root / relative
    path.parent.mkdir(parents=True)
    # These fixture values are declared above before any output is produced.
    # This is a synthetic diagnostic review, not an authenticated implementation approval.
    code_digest = hashlib.sha256((root / "platform/engine/build_ads.py").read_bytes()).hexdigest()
    doc = {"schema": 1, "context": expected.context(root, TEMPLATE), "review_digest": code_digest,
        "cases": CASE_VALUES, "review_note": "Prewritten synthetic baseline and excluded-subject expectations for the unchanged reference configuration.",
        "recorded_by": ACTOR, "recorded_at": "2026-09-08T00:00:00Z", "scientific_approval": False}
    doc["digest"] = expected.digest(doc)
    path.write_text(json.dumps(doc, indent=2), encoding="utf-8")
    lane = {"id": "selected_product", **runtime.SUITES["selected_product"], "dependency_mode": "suite_dependencies_v1",
        "product_cases": {"path": relative, "digest": doc["digest"], "count": len(CASE_VALUES), "ids": [case["id"] for case in CASE_VALUES]}}
    inputs = runtime.inputs(root, TEMPLATE, lanes=[lane])
    versions = runtime.prerequisites()
    result = runtime.execute(root, TEMPLATE, inputs, [lane], versions)
    receipt = {"source_mode": "synthetic", "registered_working_product": False, "scientific_approval": False,
        "pack": TEMPLATE, "code_version": git(root, "rev-parse", "HEAD").decode().strip(), "inputs": inputs,
        "reviewed_cases": doc, "outcome": result, "execution_versions": versions}
    output = os.environ.get("RWD_FINAL_JOURNEY_REPORT")
    if output:
        destination = Path(output).resolve()
        assert not destination.is_relative_to(ROOT)
        destination.parent.mkdir(parents=True, exist_ok=True)
        destination.write_text(json.dumps(receipt, indent=2), encoding="utf-8")
    observed = result["lanes"][0]
    assert result["copy_unchanged"] and observed["status"] == "passed", observed
    assert observed["counts"] == {"passed": 1, "failed": 0, "error": 0, "skipped": 0}, observed
    assert observed["selected_product_build"] and observed["execution_mode"] == "local_cohort_checkpoints"
    assert observed["cluster_recovery_tested"] is False
    assert runtime.inputs(root, TEMPLATE, lanes=[lane]) == inputs
    record_property("selected_product_build", "true")
    record_property("reviewed_case_digest", doc["digest"])
    record_property("report_sha256", observed["report_sha256"])
