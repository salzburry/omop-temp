"""Prior request examples use scoped evidence and the existing reviewed form path."""
from __future__ import annotations

import json
import sys
from pathlib import Path

import pytest
import yaml
from streamlit.testing.v1 import AppTest

ROOT = Path(__file__).resolve().parents[2]
sys.path[:0] = [str(ROOT / "experiments/portal"), str(ROOT / "experiments/agent"), str(ROOT / "platform/tools")]
import conversation_examples as examples
import intake

PACK = "products/oncology/renal/202609"
OLD = "products/oncology/renal/202608"
OTHER = "products/oncology/lung/202609"
ACTOR = "science-owner"


def _form(current=""):
    return {"scope": "form-revision", "fields": [{"id": "purpose", "label": "What should this product help you study?",
        "type": "text_area", "current": current, "current_complete": True, "empty": not current,
        "choices": None, "min": None, "max": None, "max_chars": None}]}


@pytest.fixture
def requests(tmp_path, monkeypatch):
    directory = tmp_path / "requests"
    directory.mkdir()
    (tmp_path / "runs").mkdir()
    monkeypatch.setattr(intake, "REQUESTS", str(directory))
    monkeypatch.setattr(examples.portal_packs, "lineage", lambda root, pack: [OLD] if pack == PACK else [])
    monkeypatch.setattr(examples.portal_packs, "catalogue", lambda root: {
        "products": [PACK, OTHER], "references": [], "superseded": [OLD], "templates": [], "names": {}, "drafts": set()})
    def keep(*, actor=ACTOR, pack=PACK, text="Study renal outcomes and treatment patterns", status="checked", domain="product_brief", **values):
        state = intake.new_state(domain, pack, actor)
        state["request"].update({"intended_use": text, "population": "renal", **values})
        run_id = "run" + str(len(list(directory.glob("*.yaml"))))
        (tmp_path / "runs" / (run_id + ".json")).write_text(json.dumps({"goal": intake.to_goal(state)}), encoding="utf-8")
        return Path(intake.save_request(state, str(directory), status=status, run_id=run_id))
    return keep


def _search(**kwargs):
    return examples.search(ROOT, PACK, question="renal outcomes", actor_id=ACTOR,
        allowed_packs=[PACK, OLD, OTHER], public=_form(), **kwargs)


def test_own_checked_requests_rank_with_exact_evidence_and_existing_prefill(requests):
    saved = requests()
    row, = _search()
    assert row["source"] == "Saved request · " + saved.name
    assert len(row["digest"]) == 64 and row["run_id"] == "run0"
    assert row["version"] == "202609" and "outcomes" in row["match"]
    assert row["changes"] == [{"id": "purpose", "label": _form()["fields"][0]["label"], "before": "",
                                "value": "Study renal outcomes and treatment patterns", "slot": "intended_use"}]
    proposal = examples.prepare(ROOT, PACK, example_id=row["id"], expected_digest=row["digest"], field_ids=["purpose"],
        question="renal outcomes", actor_id=ACTOR, allowed_packs=[PACK], public=_form())
    assert proposal == {"scope": "form-revision", "fields": [{"id": "purpose", "value": row["changes"][0]["value"]}]}


def test_other_actor_unchecked_failed_withdrawn_and_tampered_examples_do_not_surface(requests):
    requests(actor="someone-else", text="renal SECRET_OTHER_ACTOR")
    for status in ("draft", "failed", "withdrawn"):
        requests(status=status)
    stale = requests()
    document = yaml.safe_load(stale.read_text(encoding="utf-8"))
    document["request"]["intended_use"] = "unreviewed renal change"
    stale.write_text(yaml.safe_dump(document), encoding="utf-8")
    assert _search() == []


def test_lineage_is_visible_and_other_product_requires_explicit_authorized_choice(requests):
    requests(pack=OLD)
    requests(pack=OTHER)
    assert [row["pack"] for row in _search()] == [OLD]
    assert [row["pack"] for row in _search(selected_pack=OTHER)] == [OTHER]
    assert examples.search(ROOT, PACK, question="renal", actor_id=ACTOR, allowed_packs=[PACK], selected_pack=OTHER) == []
    assert examples.search(ROOT, PACK, question="renal", actor_id=ACTOR, allowed_packs=[OTHER]) == []


@pytest.mark.parametrize("extra", ["patient_id: 12345678", "api_key=sk-ant-api03-" + "x" * 60])
def test_patient_or_credential_content_never_enters_cards(requests, extra):
    requests(definition=extra)
    assert _search() == []


def test_top_three_show_differences_without_copying_authors_or_consumers(requests):
    for count in range(5):
        requests(text="renal outcomes " + str(count), requested_by="science-owner", consumers="some-other-study")
    public = _form("Current renal study intent")
    public["fields"].extend([{**public["fields"][0], "id": "person", "label": "Requested by"},
                             {**public["fields"][0], "id": "consumer", "label": "Studies that may use it (one per line)"}])
    rows = examples.search(ROOT, PACK, question="renal", actor_id=ACTOR, allowed_packs=[PACK], public=public)
    assert len(rows) == 3
    assert all([change["id"] for change in row["changes"]] == ["purpose"] for row in rows)
    assert all("Different from your current draft" in " ".join(row["differences"]) for row in rows)


def test_source_recheck_and_form_allowlist_refuse_stale_or_unoffered_reuse(requests):
    saved = requests()
    row, = _search()
    args = dict(example_id=row["id"], expected_digest=row["digest"], question="renal outcomes", actor_id=ACTOR,
                allowed_packs=[PACK], public=_form())
    with pytest.raises(ValueError, match="no longer available"):
        examples.prepare(ROOT, PACK, field_ids=["approval"], **args)
    with pytest.raises(ValueError, match="Choose the example fields"):
        examples.prepare(ROOT, PACK, field_ids=[{}], **args)
    saved.unlink()
    with pytest.raises(ValueError, match="changed"):
        examples.prepare(ROOT, PACK, field_ids=["purpose"], **args)


def test_incomplete_current_values_and_invalid_choice_types_are_not_reused(requests):
    requests()
    public = _form()
    public["fields"][0]["current_complete"] = False
    row, = examples.search(ROOT, PACK, question="renal", actor_id=ACTOR, allowed_packs=[PACK], public=public)
    assert row["changes"] == []


def test_new_product_uses_only_explicit_catalogue_metadata_and_current_options(requests, monkeypatch):
    monkeypatch.setattr(examples.product_gates, "registry_entry", lambda *_: {
        "name": "Renal reference", "code": "renal", "vendor": "flatiron", "modality": "ehr",
        "tumour_key": "renal", "tumor_class": "solid", "hidden_protocol": "NEVER_SHOW_THIS"})
    public = {"scope": "setup", "fields": [{"id": "vendor", "label": "Vendor", "type": "selectbox", "current": None,
        "choices": [{"value": "flatiron", "label": "Flatiron"}], "empty": True, "current_complete": True}]}
    assert examples.search(ROOT, None, question="create renal product", actor_id=ACTOR, allowed_packs=[PACK], public=public, setup=True) == []
    row, = examples.search(ROOT, None, question="create renal product", actor_id=ACTOR, allowed_packs=[PACK], public=public,
                          selected_pack=PACK, setup=True)
    assert row["kind"] == "catalogue" and row["changes"][0]["value"] == "flatiron"
    assert "NEVER_SHOW_THIS" not in json.dumps(row)
    public["fields"][0]["choices"] = [{"value": "cota", "label": "COTA"}]
    row, = examples.search(ROOT, None, question="create renal product", actor_id=ACTOR, allowed_packs=[PACK], public=public,
                          selected_pack=PACK, setup=True)
    assert row["changes"] == []


def _app():
    return f'''
import sys
sys.path[:0] = {sys.path[:3]!r}
import streamlit as st
import form_assistance as forms
import conversation_examples_page as page
forms.begin({str(ROOT)!r}, {PACK!r}, {ACTOR!r}, page="Plan changes", allowed_packs=[{PACK!r}], can_write=True)
forms.review()
page.render({str(ROOT)!r}, {PACK!r}, question="renal outcomes", actor_id={ACTOR!r},
            allowed_packs=[{PACK!r}], can_write=True)
forms.field(st.text_area, "What should this product help you study?", key="purpose")
forms.finish()
'''


def test_streamlit_selects_fields_shows_diff_then_prefills_without_saving(requests):
    requests()
    at = AppTest.from_string(_app()).run().run()
    assert not at.exception
    assert at.text_area(key="purpose").value == ""
    assert len(at.multiselect) == 1 and at.multiselect[0].value == []
    at.multiselect[0].set_value(list(at.session_state["chat_form_catalog"])).run()
    assert not at.exception and len(at.dataframe) == 1
    assert at.text_area(key="purpose").value == ""
    next(button for button in at.button if button.label == "Use reviewed example fields").click().run()
    assert not at.exception
    assert at.text_area(key="purpose").value == "Study renal outcomes and treatment patterns"
    assert not any("approved" in item.value.lower() for item in at.success)
    # The new interaction must remain wired into the existing improvement form.
    import workflow_improvement
    feedback = at.session_state["chat_form_feedback"]
    prepared = workflow_improvement.prepare_interaction(ROOT, ACTOR, feedback["route"], pack=PACK,
        interaction_id=feedback["id"], request=feedback["request"], answer="Proposed renal outcomes intent",
        category="wrong_interpretation", can_write=True, allowed_packs=[PACK])
    assert prepared["skill"] == "operate-rwd-product"


def test_streamlit_preserves_nonempty_field_until_existing_replacement_review(requests):
    requests()
    at = AppTest.from_string(_app()).run().run()
    at.text_area(key="purpose").set_value("My current renal study").run()
    at.multiselect[0].set_value(list(at.session_state["chat_form_catalog"])).run()
    next(button for button in at.button if button.label == "Use reviewed example fields").click().run()
    assert not at.exception and at.text_area(key="purpose").value == "My current renal study"
    at.button(key="chat_form_replace").click().run()
    assert not at.exception
    assert at.text_area(key="purpose").value == "Study renal outcomes and treatment patterns"


def test_streamlit_old_click_cannot_apply_a_request_whose_evidence_disappeared(requests):
    saved = requests()
    at = AppTest.from_string(_app()).run().run()
    at.multiselect[0].set_value(list(at.session_state["chat_form_catalog"])).run()
    button = next(button for button in at.button if button.label == "Use reviewed example fields")
    saved.unlink()
    button.click().run()
    assert not at.exception and at.text_area(key="purpose").value == ""
    assert not at.multiselect


def test_streamlit_field_change_resets_the_examples_selection(requests):
    requests()
    at = AppTest.from_string(_app()).run().run()
    at.multiselect[0].set_value(list(at.session_state["chat_form_catalog"])).run()
    assert len(at.dataframe) == 1
    at.text_area(key="purpose").set_value("A new renal intent").run()
    assert not at.exception and at.multiselect[0].value == []
    assert not at.dataframe


def test_catalogue_suggestions_rank_labels_without_reading_request_contents(requests):
    choices = examples.scope_choices(ROOT, allowed_packs=[PACK, OTHER], question="create lung product")
    assert choices[0]["pack"] == OTHER and choices[0]["matching_terms"] == ["lung"]


@pytest.mark.parametrize("text", ["slots: [", "slots: []"])
def test_optional_examples_do_not_crash_chat_when_an_intake_template_is_invalid(requests, tmp_path, monkeypatch, text):
    requests()
    templates = tmp_path / "templates"
    templates.mkdir()
    (templates / "broken.yaml").write_text(text, encoding="utf-8")
    monkeypatch.setattr(intake, "TEMPLATES", str(templates))
    assert _search() == []
