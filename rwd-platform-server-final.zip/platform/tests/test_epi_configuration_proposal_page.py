"""Focused Streamlit proposal journeys against a disposable template scaffold.

The scaffold lives at a product path the repository never carried: the page is offered by
the settings a product's files carry, never by the product's name.
"""
from __future__ import annotations

import hashlib
import json
import sys
import tempfile
from pathlib import Path
from unittest.mock import patch

from streamlit.testing.v1 import AppTest

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "experiments/portal"))
sys.path.insert(0, str(ROOT / "platform/tests"))
from _epi_gist_fixture import seed_gist
from _epi_test_support import run

import configuration_proposals as proposals

PACK = "products/oncology/gist_uat/202609"
ACTOR = "epi@example.test"
PREFIX = f"design_{PACK}_"
PARAMETER = "variables/outcomes.yaml#/min_followup_days"


def fixture(root, *, definitions=False):
    directory = seed_gist(root, extraction=True, pack=PACK)
    if definitions:
        rows = [("INDEXDT", "study_period", "Index date", "[]"),
                ("AGE", "demographics", "Age at index", "[INDEXDT]"),
                ("OS", "outcomes", "Overall survival", "[INDEXDT]")]
        (directory / "handoff/FUNCTIONAL_CONTRACT.md").write_text("\n".join(
            f"```yaml\nvariable_id: {identifier}\nspec_refs: [{domain}:1]\nrequired_rule: {rule}\ndepends_on: {depends}\n```\n"
            for identifier, domain, rule, depends in rows), encoding="utf-8")
    return directory


def app(root, *, can_write=True):
    script = f"""
import sys
sys.path.insert(0, {str(ROOT / 'experiments/portal')!r})
import streamlit as st
import design_page, session_drafts
actor = st.selectbox('Test actor', {[ACTOR, 'other@example.test']!r}, key='test_actor')
page = st.radio('Test page', ['Plan', 'Other page'], key='test_page')
session_drafts.preserve(st.session_state, actor)
if page == 'Plan':
    design_page.render({str(root)!r}, {PACK!r}, actor_id=actor, local_demo=True,
                       can_write={can_write!r}, allowed_packs={[PACK]!r})
else:
    st.write('Another page')
"""
    at = AppTest.from_string(script, default_timeout=45).run()
    healthy(at)
    return at


def healthy(at):
    assert not at.exception, [error.message for error in at.exception]


def configure(at, value="93"):
    at.text_area(key=PREFIX + "purpose").set_value("Explicitly propose a 93-day minimum follow-up for review")
    at.text_area(key=PREFIX + "studies").set_value("Patterns\nOutcomes")
    field = hashlib.sha256(PARAMETER.encode()).hexdigest()[:12]
    at.checkbox(key=PREFIX + "proposal_" + field + "_change").check().run()
    at.text_input(key=PREFIX + "proposal_" + field + "_value").set_value(value).run()
    healthy(at)


def stage(at):
    assert not at.button(key=f"configuration_stage_{PACK}").disabled
    at.button(key=f"configuration_stage_{PACK}").click().run()
    healthy(at)
    assert any("Configuration proposal staged" in message.value for message in at.success), [message.value for message in at.error]


def originals(root):
    return {p.relative_to(root).as_posix(): p.read_bytes() for p in (Path(root) / PACK).rglob("*")
            if p.is_file() and ".portal-drafts" not in p.parts}


def test_empty_contract_configuration_change_stages_diff_then_existing_validators_block_scaffold():
    with tempfile.TemporaryDirectory() as tmp:
        root = Path(tmp)
        fixture(root)
        before = originals(root)
        at = app(root)
        configure(at)
        # A configuration-only brief must not require invented contract definitions.
        assert at.button(key=f"revision_save_{PACK}").disabled
        assert any("Definition brief requirements" in item.value for item in at.markdown)
        assert any("For a configuration-only change" in item.value for item in at.caption)
        stage(at)
        assert at.button(key=f"configuration_submit_{PACK}").disabled
        diffs = [code.value for code in at.code if "min_followup_days" in code.value]
        assert any("REPLACE_ME" in text for text in diffs)
        assert any("93" in text for text in diffs)
        assert any("Declared dependency and consumer impact" in text.value for text in at.markdown)
        at.button(key=f"configuration_validate_{PACK}").click().run()
        healthy(at)
        assert at.button(key=f"configuration_submit_{PACK}").disabled
        assert any("failed" in message.value for message in at.error)
        assert any("Correct a supported setting" in message.value for message in at.info)
        listing = proposals.list_proposals(root, PACK, actor_id=ACTOR, allowed_packs=[PACK])
        checked = proposals.load(root, PACK, actor_id=ACTOR, allowed_packs=[PACK],
                                 proposal_id=listing["proposals"][0]["proposal_id"])["validation"]
        findings = [str(error) for check in checked["checks"] for error in check.get("errors") or []]
        assert findings and all(any(finding in item.value for item in [*at.markdown, *at.text]) for finding in findings)
        assert originals(root) == before


def test_study_exclusions_and_new_derivations_remain_separate_in_saved_snapshot():
    with tempfile.TemporaryDirectory() as tmp:
        root = Path(tmp)
        fixture(root, definitions=True)
        before = originals(root)
        at = app(root)
        configure(at)
        at.multiselect(key=PREFIX + "excluded").set_value(["OS"]).run()
        study_key = PREFIX + "proposal_study_" + hashlib.sha256(b"Patterns").hexdigest()[:12]
        at.multiselect(key=study_key).set_value(["OS"])
        at.text_input(key=PREFIX + "add_domain").set_value("clinical")
        at.text_input(key=PREFIX + "add_variable").set_value("GIST_RESPONSE")
        at.text_area(key=PREFIX + "add_definition").set_value("Scientist's literal response rule; mapping unresolved")
        at.button(key=f"revision_add_{PACK}").click().run()
        stage(at)
        listing = proposals.list_proposals(root, PACK, actor_id=ACTOR, allowed_packs=[PACK])
        saved = proposals.load(root, PACK, actor_id=ACTOR, allowed_packs=[PACK],
                               proposal_id=listing["proposals"][0]["proposal_id"])["proposal"]
        assert saved["study_exclusions"] == [{"study": "Patterns", "variables": ["OS"]}]
        assert "GIST_RESPONSE" in json.dumps(saved["engineering_handoff"])
        assert all("GIST_RESPONSE" not in file["after"] for file in saved["files"])
        assert any("Unsupported derivations remain an engineering handoff" in message.value for message in at.warning)
        assert any("Patterns" in str(table.value) and "OS" in str(table.value) for table in at.table)
        with patch.object(proposals, "_run_validators", return_value=[
                {"validator": name, "passed": True, "errors": []} for name in sorted(proposals.REQUIRED_VALIDATORS)]):
            at.button(key=f"configuration_validate_{PACK}").click().run()
        healthy(at)
        assert at.button(key=f"configuration_submit_{PACK}").disabled
        assert any("Engineering handoff remains unresolved" in message.value for message in at.error)
        assert originals(root) == before


def test_reopen_actor_isolation_readonly_and_stale_baseline_disable_actions():
    with tempfile.TemporaryDirectory() as tmp:
        root = Path(tmp)
        directory = fixture(root)
        at = app(root)
        configure(at)
        stage(at)
        at.radio(key="test_page").set_value("Other page").run()
        at.radio(key="test_page").set_value("Plan").run()
        healthy(at)
        assert any("Review staged proposal" in item.value for item in at.subheader)
        at.selectbox(key="test_actor").set_value("other@example.test").run()
        healthy(at)
        assert not any(button.key == f"configuration_open_{PACK}" for button in at.button)
        assert not any(button.key == f"configuration_submit_{PACK}" for button in at.button)
        assert at.text_area(key=PREFIX + "purpose").value == ""
        at.selectbox(key="test_actor").set_value(ACTOR).run()
        healthy(at)
        again = app(root, can_write=False)
        again.button(key=f"configuration_open_{PACK}").click().run()
        healthy(again)
        assert again.button(key=f"configuration_stage_{PACK}").disabled
        assert again.button(key=f"configuration_validate_{PACK}").disabled
        cfg = directory / "config/data_product.yaml"
        cfg.write_text(cfg.read_text(encoding="utf-8") + "delivery: revised\n", encoding="utf-8")
        at.run()
        healthy(at)
        assert any("source product or declared consumer impact changed" in message.value for message in at.warning)
        assert at.button(key=f"configuration_validate_{PACK}").disabled
        assert at.button(key=f"configuration_submit_{PACK}").disabled


def test_invalid_explicit_parameter_does_not_stage_a_proposal():
    with tempfile.TemporaryDirectory() as tmp:
        root = Path(tmp)
        fixture(root)
        at = app(root)
        configure(at, value="infer from my scientific purpose")
        assert at.button(key=f"configuration_stage_{PACK}").disabled
        assert any("Enter a valid" in message.value for message in at.info)
        assert proposals.list_proposals(root, PACK, actor_id=ACTOR, allowed_packs=[PACK])["proposals"] == []


def test_passing_validation_enables_review_submission_and_submission_rechecks():
    checks = [{"validator": validator, "passed": True, "errors": []}
              for validator in sorted(proposals.REQUIRED_VALIDATORS)]
    with tempfile.TemporaryDirectory() as tmp:
        root = Path(tmp)
        fixture(root, definitions=True)
        before = originals(root)
        at = app(root)
        configure(at)
        stage(at)
        assert at.button(key=f"configuration_submit_{PACK}").disabled
        with patch.object(proposals, "_run_validators", return_value=checks) as validation:
            at.button(key=f"configuration_validate_{PACK}").click().run()
            healthy(at)
            assert not at.button(key=f"configuration_submit_{PACK}").disabled
            assert validation.call_count == 1
            at.button(key=f"configuration_submit_{PACK}").click().run()
            healthy(at)
            assert validation.call_count == 2
        assert at.button(key=f"configuration_submit_{PACK}").disabled
        assert any("submitted for review" in message.value for message in at.success)
        assert any("No approval or release was recorded" in message.value for message in at.success)
        assert originals(root) == before


def test_existing_findings_are_explicit_and_collapsed_without_claiming_full_product_pass():
    from copy import deepcopy
    checks = [{"validator": "engine.validate (strict)", "passed": True, "errors": [], "completed": True},
              {"validator": "contract_lint", "passed": False, "errors": ["The existing scientific draft is incomplete."], "completed": True}]
    checks.extend({"validator": name, "passed": True, "errors": [], "completed": True}
                  for name in sorted(proposals.REQUIRED_VALIDATORS - {check["validator"] for check in checks}))
    with tempfile.TemporaryDirectory() as tmp:
        root = Path(tmp)
        fixture(root, definitions=True)
        at = app(root)
        configure(at)
        stage(at)
        with patch.object(proposals, "_run_validators", side_effect=lambda *_: deepcopy(checks)):
            at.button(key=f"configuration_validate_{PACK}").click().run()
        healthy(at)
        assert any("full product checks have not passed" in message.value for message in at.warning)
        assert not any("Proposal validators passed" in message.value for message in at.success)
        assert any("review-submission requirements are satisfied" in message.value for message in at.success)
        expander = next(exp for exp in at.expander if exp.label == "contract_lint: read 1 finding(s)")
        assert not expander.proto.expanded
        assert any("existing scientific draft is incomplete" in message.value for message in expander.text)
        assert not at.button(key=f"configuration_submit_{PACK}").disabled


def test_identical_unreadable_validator_is_not_exempted_as_an_existing_scientific_finding():
    from copy import deepcopy
    checks = [{"validator": "engine.validate (strict)", "passed": True, "errors": [], "completed": True},
              {"validator": "contract_lint", "passed": False, "errors": ["RuntimeError: unable to read the contract"], "completed": False}]
    checks.extend({"validator": name, "passed": True, "errors": [], "completed": True}
                  for name in sorted(proposals.REQUIRED_VALIDATORS - {check["validator"] for check in checks}))
    with tempfile.TemporaryDirectory() as tmp:
        root = Path(tmp)
        directory = fixture(root, definitions=True)
        with patch.object(proposals.dw.cl, "run", side_effect=RuntimeError("unable to read the contract")):
            actual = proposals._run_validators(root, directory)
        unreadable = next(check for check in actual if check["validator"] == "contract_lint")
        assert unreadable["completed"] is False and unreadable["passed"] is False
        at = app(root)
        configure(at)
        stage(at)
        with patch.object(proposals, "_run_validators", side_effect=lambda *_: deepcopy(checks)):
            at.button(key=f"configuration_validate_{PACK}").click().run()
        healthy(at)
        assert at.button(key=f"configuration_submit_{PACK}").disabled
        assert any("contract_lint: failed" in message.value for message in at.error)
        assert not any("failed before this change too" in message.value for message in at.warning)


def test_a_product_without_supported_settings_shows_no_proposal_section():
    with tempfile.TemporaryDirectory() as tmp:
        root = Path(tmp)
        directory = fixture(root)
        (directory / "variables/outcomes.yaml").unlink()
        (directory / "variables/treatment.yaml").unlink()  # no treatment settings, including optional numbering
        (directory / "config/pipeline.yaml").unlink()          # the delivery settings live there (walk RW4-N03)
        config = directory / "config/data_product.yaml"
        config.write_text("\n".join(line for line in config.read_text(encoding="utf-8").splitlines()
                                    if not line.startswith(("study:", "  index_start", "  index_end"))) + "\n",
                          encoding="utf-8")
        assert proposals.supported_parameters(root, PACK) == {}
        at = app(root)
        assert not any(button.key == f"configuration_stage_{PACK}" for button in at.button)
        assert not any("Stage a configuration proposal" in item.value for item in at.subheader)
        assert not any("For a configuration-only change" in item.value for item in at.caption)


if __name__ == "__main__":
    raise SystemExit(run(globals()))
