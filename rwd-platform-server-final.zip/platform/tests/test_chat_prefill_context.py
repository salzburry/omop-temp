"""Large forms expose the requested field and choices without widening model access."""
import json
from pathlib import Path
import sys

import pytest
from streamlit.testing.v1 import AppTest

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "experiments/portal"))

QUERY = "Set Consortium selection to GIST specialty network"
TARGET = "source_099"


def _app(tmp_path):
    script = f'''
import streamlit as st
import form_assistance as forms

actor = st.sidebar.selectbox("Local identity", ["epi", "other"], key="actor")
st.text_input("Request", value={QUERY!r}, key="question")
st.text_input("Source snapshot", value="v1", key="source_version")
forms.begin({str(tmp_path)!r}, "products/oncology/large/202609", actor, page="Large draft",
    allowed_packs=["products/oncology/large/202609"], can_write=True)
if st.button("Prepare request context", key="capture"):
    st.session_state.default_form = forms.context()
    st.session_state.request_form = forms.context(st.session_state.question)
if st.button("Receive the model response", key="receive"):
    try:
        forms.stage(st.session_state.model_reply, public=st.session_state.request_form)
    except ValueError as error:
        st.warning(str(error))
forms.review()
# An unusually long preexisting label must not hide every subsequent field.
forms.field(st.text_input, "Large annotation " + "x" * 9000, key="oversized", binding=st.session_state.source_version)
for index in range(74):
    forms.field(st.text_input, f"Additional detail {{index:02d}} for the section", value="Existing explanation " + "x" * 220,
        key=f"detail_{{index}}", binding=st.session_state.source_version)
forms.field(st.selectbox, "Consortium selection", [f"source_{{index:03d}}" for index in range(100)],
    index=None, key="consortium", binding=st.session_state.source_version,
    format_func=lambda value: "GIST specialty network" if value == {TARGET!r} else "Other network " + value)
forms.field(st.text_area, "Additional analysis summary", key="summary", binding=st.session_state.source_version)
st.checkbox("I reviewed the source selection", key="reviewed")
forms.finish()
'''
    return _healthy(AppTest.from_string(script, default_timeout=30).run())


def _healthy(at):
    assert not at.exception, [error.message for error in at.exception]
    return at


def _capture(at):
    return _healthy(at.button(key="capture").click().run())


def _field(public, label="Consortium selection"):
    return next(item for item in public["fields"] if item["label"] == label)


def _reply(at, value=TARGET):
    public = at.session_state.request_form
    at.session_state.model_reply = {"scope": public["scope"], "fields": [{"id": _field(public)["id"], "value": value}]}
    return _healthy(at.button(key="receive").click().run())


def test_requested_late_field_and_exact_late_choice_are_offered_and_adopted(tmp_path):
    at = _capture(_app(tmp_path))
    baseline = at.session_state.default_form
    public = at.session_state.request_form
    assert len(at.session_state.chat_form_catalog) == 77
    assert not any(item["label"] == "Consortium selection" for item in baseline["fields"])
    field = _field(public)
    assert public["fields"][0] == field
    assert field["choices"][0] == {"value": TARGET, "label": "GIST specialty network"}
    assert len(field["choices"]) == 24 and field["choices_omitted"] == 76
    assert public["fields_omitted"] > 0
    assert len(json.dumps(public["fields"], ensure_ascii=False).encode()) <= 7000
    assert all("key" not in item and "callback" not in item for item in public["fields"])
    _reply(at)
    assert at.selectbox(key="consortium").value == TARGET
    assert not at.checkbox(key="reviewed").value
    assert any("Prepared draft fields" in item.value for item in at.success)


def test_oversized_early_field_does_not_hide_later_fields(tmp_path):
    at = _capture(_app(tmp_path))
    public = at.session_state.default_form
    assert public and public["fields"]
    assert public["fields"][0]["label"] == "Additional detail 00 for the section"
    assert not any(item["label"].startswith("Large annotation") for item in public["fields"])
    assert len(json.dumps(public["fields"], ensure_ascii=False).encode()) <= 7000


def test_actual_option_omitted_from_this_model_request_cannot_be_invented_by_response(tmp_path):
    at = _capture(_app(tmp_path))
    field = _field(at.session_state.request_form)
    assert "source_050" in {item["value"] for entry in at.session_state.chat_form_catalog.values()
        if entry["key"] == "consortium" for item in entry["choices"]}
    assert "source_050" not in {item["value"] for item in field["choices"]}
    _reply(at, "source_050")
    assert at.selectbox(key="consortium").value is None
    assert any("currently offered" in item.value for item in at.warning)
    assert "chat_form_proposal" not in at.session_state


@pytest.mark.parametrize("change", ["unoffered_field", "source_version", "identity"])
def test_change_while_model_answers_keeps_current_entries_and_refuses_old_context(tmp_path, change):
    at = _capture(_app(tmp_path))
    original = at.session_state.request_form
    if change == "unoffered_field":
        catalog_id = next(entry["id"] for entry in at.session_state.chat_form_catalog.values() if entry["key"] == "detail_73")
        assert catalog_id not in {item["id"] for item in original["fields"]}
        _healthy(at.text_input(key="detail_73").set_value("The epidemiologist's more recent correction").run())
    elif change == "source_version":
        _healthy(at.text_input(key="source_version").set_value("v2").run())
    else:
        _healthy(at.selectbox(key="actor").set_value("other").run())
    _reply(at)
    assert at.selectbox(key="consortium").value is None
    assert any("changed while answering" in item.value for item in at.warning)
    assert "chat_form_proposal" not in at.session_state
    assert not at.checkbox(key="reviewed").value
    if change == "unoffered_field":
        assert at.text_input(key="detail_73").value == "The epidemiologist's more recent correction"
    elif change == "source_version":
        assert at.text_input(key="source_version").value == "v2"
    else:
        assert at.selectbox(key="actor").value == "other"
