"""Chat stays beside the form, ordered and quiet until an explicit request."""
import copy
from pathlib import Path
import sys

from streamlit.testing.v1 import AppTest

ROOT = Path(__file__).resolve().parents[2]
sys.path[:0] = [str(ROOT / name) for name in ("platform/tests", "experiments/portal", "platform/tools")]
from test_epi_flow_assistant import _card
import flow_assistant as guide
import flow_assistant_page as page


def _app(monkeypatch):
    calls, searches = [], []
    monkeypatch.setattr(page, "_provider_words", lambda *_: ({"configured": True}, "Offline UI test"))
    monkeypatch.setattr(guide, "answer", lambda question, card, **kwargs:
        calls.append(question) or {"answer": "Reply to " + question, "actions": [], "source": "assistant"})
    import conversation_examples_page
    monkeypatch.setattr(conversation_examples_page, "render", lambda *args, **kwargs: searches.append(kwargs))
    script = f'''import streamlit as st
import assistant_layout
import flow_assistant_page as page
with assistant_layout.workspace():
    st.text_input("Working definition", key="working")
    page.render({str(ROOT)!r}, "", card=st.session_state["card"], actor_id="layout-author",
        primary=True, metadata_only=True, allowed_packs=[], can_write=False)
    st.text_area("Unfinished rationale", key="rationale")
'''
    at = AppTest.from_string(script, default_timeout=30)
    at.session_state["card"] = copy.deepcopy(_card())
    at.run()
    assert not at.exception
    return at, calls, searches


def test_chat_is_right_of_the_form_and_new_answer_precedes_composer(monkeypatch):
    at, calls, searches = _app(monkeypatch)
    columns = at.get("column")
    assert columns[0].text_input(key="working")
    assert len(columns[1].chat_input) == 1
    assert not columns[0].chat_input
    at.text_input(key="working").set_value("Keep my unfinished definition")
    at.text_area(key="rationale").set_value("Still under review")
    at.chat_input[0].set_value("First question").run()
    assert not at.exception and calls == ["First question"]
    assert any(button.label == "Clear this conversation" for button in at.button)
    nodes = list(at)
    reply = next(i for i, node in enumerate(nodes) if node.type == "markdown" and node.value == "Reply to First question")
    composer = next(i for i, node in enumerate(nodes) if node.type == "chat_input")
    assert reply < composer
    assert at.text_input(key="working").value == "Keep my unfinished definition"
    assert at.text_area(key="rationale").value == "Still under review"
    at.chat_input[0].set_value("Second question").run()
    assert not at.exception and calls == ["First question", "Second question"]
    nodes = list(at)
    messages = [node.value for node in nodes if node.type == "markdown" and
                node.value in {"First question", "Reply to First question", "Second question", "Reply to Second question"}]
    assert messages == ["First question", "Reply to First question", "Second question", "Reply to Second question"]
    assert max(i for i, node in enumerate(nodes) if node.type == "chat_message") < next(i for i, node in enumerate(nodes) if node.type == "chat_input")
    at.run()
    assert not at.exception and len(calls) == 2 and not searches
    next(button for button in at.button if button.label == "Clear this conversation").click().run()
    assert not at.exception and len(calls) == 2
    assert at.text_input(key="working").value == "Keep my unfinished definition"
    assert at.text_area(key="rationale").value == "Still under review"
    assert not any(message.value == "Reply to First question" for message in at.markdown)


def test_feedback_is_opt_in_bound_to_one_answer_and_examples_are_lazy(monkeypatch):
    at, calls, searches = _app(monkeypatch)
    import interaction_feedback_page
    feedback_calls = []
    monkeypatch.setattr(interaction_feedback_page, "offer", lambda *args, **kwargs: feedback_calls.append(kwargs))
    at.chat_input[0].set_value("First question").run()
    assert not feedback_calls and not searches
    next(t for t in at.toggle if t.label == "Give feedback on the latest answer").set_value(True).run()
    assert feedback_calls[-1]["answer"] == "Reply to First question"
    first_id = feedback_calls[-1]["interaction_id"]
    before = len(feedback_calls)
    at.chat_input[0].set_value("Second question").run()
    assert not at.exception and len(feedback_calls) == before
    next(t for t in at.toggle if t.label == "Give feedback on the latest answer").set_value(True).run()
    assert feedback_calls[-1]["answer"] == "Reply to Second question"
    assert feedback_calls[-1]["interaction_id"] != first_id
    assert not searches
    next(t for t in at.toggle if t.label == "Find reusable examples").set_value(True).run()
    assert len(searches) == 1 and len(calls) == 2


def test_dedicated_assistant_reuses_the_dock_and_context_does_not_leak():
    script = '''import streamlit as st
import assistant_layout
@assistant_layout.in_panel
def show(label):
    st.write(label)
with assistant_layout.workspace():
    st.text_input("Form field")
    show("General guide")
    show("Selected row assistant")
show("Outside the workspace")
'''
    at = AppTest.from_string(script).run()
    assert not at.exception
    right = at.get("column")[1]
    assert [item.value for item in right.markdown] == ["Selected row assistant"]
    assert at.markdown[-1].value == "Outside the workspace"


def test_row_chat_repeated_questions_stay_before_composer_without_replaying_calls(tmp_path, monkeypatch):
    from test_epi_scientific_definition_ai_page import OfflineAssistant
    from test_epi_scientific_definitions import ACTOR, ITEM, fixture, governed_bytes
    import scientific_definition_ai_page as row_page
    import specialist_chat
    root, pack, product, _ = fixture(tmp_path)
    original = governed_bytes(product)
    offline = OfflineAssistant()
    monkeypatch.setattr(row_page.assistant, "describe_availability", offline.describe_availability)
    monkeypatch.setattr(specialist_chat, "prepare", lambda *args, **kwargs: None)
    def suggest(*args, **kwargs):
        result = offline.suggest(*args, **kwargs)
        result["proposal"].update(answer="Review the source before choosing the date.", questions=[{
            "id": "index", "prompt": "Which event starts the window?", "options": [
                {"id": "recorded", "label": "Recorded event", "explanation": "Use the documented source date."}]}])
        return result
    monkeypatch.setattr(row_page.assistant, "suggest", suggest)
    script = f'''import streamlit as st
import assistant_layout
import scientific_definitions as definitions
import scientific_definition_ai_page as page
with assistant_layout.workspace():
    st.text_area("Unfinished row note", key="row_note")
    current = definitions.describe({str(root)!r}, {pack!r}, {ACTOR!r}, item_id={ITEM!r}, allowed_packs=[{pack!r}])
    page.render({str(root)!r}, {pack!r}, {ACTOR!r}, current,
        local_demo=True, can_write=True, allowed_packs=[{pack!r}], chat=True)
'''
    at = AppTest.from_string(script, default_timeout=30).run()
    assert not at.exception and not offline.generations
    at.text_area(key="row_note").set_value("Keep these unfinished choices")
    for question in ("Explain the reference date", "Explain it again"):
        at.chat_input[0].set_value(question).run()
        assert not at.exception
        assert len([r for r in at.radio if r.label == "Which event starts the window?"]) == 1
        nodes = list(at)
        assert max(i for i, node in enumerate(nodes) if node.type == "chat_message") < next(i for i, node in enumerate(nodes) if node.type == "chat_input")
    at.run()
    assert not at.exception and len(offline.generations) == 2
    assert at.text_area(key="row_note").value == "Keep these unfinished choices"
    assert governed_bytes(product) == original
