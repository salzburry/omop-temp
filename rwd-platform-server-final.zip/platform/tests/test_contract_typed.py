"""Programme item 1 — the canonical typed contract record (contract_lint.ContractRecord).

One object behind the one reader: every committed record parses to a ContractRecord whose verbatim
cells re-render byte for byte; the parsed views agree with the token accessors every invariant and
every other reader still uses; a malformed record names its own defect instead of raising; and the
raw-regex readers in contract_binding read through the same object.

    python3 platform/tests/test_contract_typed.py
"""
import os
import sys
from pathlib import Path

FRAMEWORK = Path(__file__).resolve().parent.parent
ROOT = FRAMEWORK.parent
sys.path.insert(0, str(FRAMEWORK / "tools"))
import contract_lint as cl                                                   # noqa: E402
import contract_binding as cb                                                # noqa: E402

PACKS = sorted(p.parent.parent for p in ROOT.glob("fixtures/oncology/*/*/handoff/FUNCTIONAL_CONTRACT.md"))
PACKS += sorted(p.parent.parent for p in ROOT.glob("products/*/*/*/handoff/FUNCTIONAL_CONTRACT.md"))
PACKS += sorted(p.parent.parent for p in ROOT.glob("sandbox/demo_walkthrough/*/*/handoff/FUNCTIONAL_CONTRACT.md"))


def _text(pack):
    return (pack / "handoff" / "FUNCTIONAL_CONTRACT.md").read_text(encoding="utf-8")


def test_every_committed_record_parses_and_re_renders_byte_for_byte():
    """The round trip is the migration's own proof: the typed record's cells are the row as written."""
    seen = 0
    for pack in PACKS:
        text = _text(pack)
        rows = [ln for ln in text.splitlines() if ln.lstrip().startswith("|")]
        for rec in cl.typed_records(text):
            seen += 1
            rendered = cl.render_row(rec.as_mapping())
            assert rendered in rows, (pack.name, rec.variable_id, rendered[:120])
    assert seen >= 200, f"only {seen} committed record(s) parsed — the reference pack alone has 202"


def test_the_typed_views_agree_with_the_token_accessors_on_every_record():
    for pack in PACKS:
        text = _text(pack)
        for block, rec in zip(cl.records(text), cl.typed_records(text)):
            assert rec.variable_id == (cl._scalar(block, "variable_id") or "").strip()
            assert rec.requirement() == cl.requirement(cl._inline(block, "status"))
            assert rec.source_kind() == cl.source_kind(block)
            assert rec.vendor_sourced() == cl.vendor_sourced(block)
            assert set(rec.spec_refs and [r for ref in rec.spec_refs for r in ref.rows()] or []) == \
                set(r for ref in (cl._list(block, "spec_refs") or []) if ref != cl.NO_SPEC_ROW for r in cl.spec_ref_rows(ref)), rec.variable_id
            assert (rec.implementation_refs or []) == (cl._list(block, "implementation_refs") or []), rec.variable_id
            assert rec.axis("implementation") == (cl._kv(cl._inline(block, "status"), "implementation") or "")
        published = {r["variable_id"] for r in cl.published_surface(text)}
        typed = {rec.variable_id for rec in cl.typed_records(text) if rec.published()}
        assert published == typed, (pack.name, published ^ typed)


def test_the_committed_contracts_have_no_structural_findings_the_lint_does_not_also_report():
    """typed_errors is the structural half of I3/I6/I19/I20; on a committed pack it must be a subset
    of what the lint already refuses — never a new refusal the lint would have let through."""
    for pack in PACKS:
        text = _text(pack)
        typed = [e for rec in cl.typed_records(text) for e in cl.typed_errors(rec)]
        if not typed:
            continue
        lint, _n = cl.run(str(pack))
        for e in typed:
            vid = e.split(":", 1)[0]
            assert any(vid in x for x in lint), (pack.name, e, lint[:3])


def test_a_malformed_record_names_its_defect_instead_of_raising():
    row = {k: "n/a" for k in cl.TABLE_COLUMNS}
    row.update({"variable_id": "X", "spec_refs": "[clinical:3, nonsense]", "status": "{requirement: aproved, implementation: implemented",
                "output": "{physical_name: x, role: publishd}", "publish": "{ads: configured}", "implementation_refs": "",
                "source": "{kind: vndor}"})
    rec = cl.parse_block(next(cl.records(cl.render_table([row]))))
    errs = cl.typed_errors(rec)
    joined = "\n".join(errs)
    assert "status map is not balanced" in joined, errs
    assert "status.requirement='aproved'" in joined and "output.role='publishd'" in joined and "source.kind='vndor'" in joined, errs
    assert "spec_refs entry 'nonsense'" in joined and "implementation_refs is unanswered" in joined, errs
    assert [str(r) for r in rec.spec_refs] == ["clinical:3"]
    ranged = cl.parse_spec_ref("outcomes:4-6")
    assert ranged.rows() == [("outcomes", 4), ("outcomes", 5), ("outcomes", 6)] and str(ranged) == "outcomes:4-6"
    assert cl.parse_spec_ref("none") is None and cl.parse_spec_ref("clinical") is None


def test_contract_binding_reads_names_through_the_typed_record_not_a_regex_over_the_file():
    """`output_names` scanned the whole file with a regex for `physical_name:` — it read names out
    of prose and comments, and split compound names by itself. It reads the typed record now."""
    src = (FRAMEWORK / "tools" / "contract_binding.py").read_text(encoding="utf-8")
    body = src.split("def output_names", 1)[1].split("\ndef ", 1)[0]
    assert "re.findall" not in body and "typed_records" in body
    body2 = src.split("def contract_records", 1)[1].split("\ndef ", 1)[0]
    assert "typed_records" in body2 and "re.search" not in body2
    prostate = ROOT / "fixtures" / "oncology" / "prostate" / "202606"
    names = cb.output_names(str(prostate))
    assert "eligpfs" in names and "lastclinicnotedate" in names and len(names) > 150, len(names)
    recs = cb.contract_records(str(prostate))
    assert len(recs) >= 200 and all(len(r) == 3 for r in recs)


def test_apply_verdicts_writes_the_contract_atomically_or_not_at_all():
    """UNSAFE-09 (2026-09-07): --apply-verdicts rewrote FUNCTIONAL_CONTRACT.md through a truncating
    open, so the governed contract was EMPTY between the truncate and the write and half-written if
    the process died in between. It now writes the way --apply does: a sibling temp file, then
    os.replace. Proved on the behaviour, with the replace made to fail: the old contract stands byte
    for byte, no temp file is left behind, and the refusal is a sentence rather than a traceback."""
    import io
    import shutil
    import tempfile
    from contextlib import redirect_stderr, redirect_stdout

    import contract_record as cr

    tmp = tempfile.mkdtemp()
    old = b"# old\r\n| a |\r\n"
    new = "# new\r\n| b |\r\n"
    real_apply, real_replace = cr.apply_verdicts, os.replace
    try:
        pack = Path(tmp) / "products" / "oncology" / "x" / "202609"
        (pack / "handoff").mkdir(parents=True)
        contract = pack / "handoff" / "FUNCTIONAL_CONTRACT.md"
        contract.write_bytes(old)
        cr.apply_verdicts = lambda product, member=None: ([("X", "settle live_schema_check")], [], [], new)

        def _broken(_src, _dst):
            raise OSError("disk full")
        os.replace = _broken
        with redirect_stdout(io.StringIO()), redirect_stderr(io.StringIO()) as err:
            rc = cr.main(["--apply-verdicts", "--product", str(pack)])
        os.replace = real_replace
        assert rc == 1 and "unchanged" in err.getvalue() and "Traceback" not in err.getvalue(), err.getvalue()
        assert contract.read_bytes() == old, "a failed write changed the governed contract"
        assert not [f for f in os.listdir(pack / "handoff") if f.endswith(".tmp")], "a temp file was left behind"
        # the replace works: the new text lands with its line endings exactly as given
        with redirect_stdout(io.StringIO()) as out:
            rc = cr.main(["--apply-verdicts", "--product", str(pack)])
        assert rc == 0 and "wrote 1 status change" in out.getvalue(), out.getvalue()
        assert contract.read_bytes() == new.encode("utf-8")
        assert not [f for f in os.listdir(pack / "handoff") if f.endswith(".tmp")]
    finally:
        os.replace = real_replace
        cr.apply_verdicts = real_apply
        shutil.rmtree(tmp, ignore_errors=True)
    # and the branch itself: no truncating open on the contract, the same temp-and-replace --apply uses
    src = (FRAMEWORK / "tools" / "contract_record.py").read_text(encoding="utf-8")
    branch = src.split("if a.apply_verdicts:", 1)[1].split("if not a.draft:", 1)[0]
    assert 'open(path, "w"' not in branch and "mkstemp(" in branch and "os.replace(" in branch


if __name__ == "__main__":
    os.chdir(FRAMEWORK)
    failed = 0
    for name, fn in sorted(globals().items()):
        if name.startswith("test_") and callable(fn):
            try:
                fn()
                print(f"  ok   {name}")
            except Exception as e:                                           # noqa: BLE001
                failed += 1
                print(f"  FAIL {name}: {type(e).__name__}: {str(e)[:600]}")
    print(f"{failed} failure(s)")
    sys.exit(1 if failed else 0)
