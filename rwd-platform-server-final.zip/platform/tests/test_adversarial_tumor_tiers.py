"""Three tumours, three tiers, one question per tier: when a hazard bites, does anything say so?

`fixtures/tumor_tiers.py` builds three synthetic specifications of rising complexity — bladder
(small), rcc (medium), mm (high) — each seeded with traps whose phrasings the Q3 adversarial
suite already proved trigger their detectors. This suite scores COVERAGE AT SCALE: every planted
trap must be REPORTED (by spec_lint or workbook_structure), every control row must EXTRACT, and
a row an attack deletes must be provably gone AND provably announced. A trap nothing reports is
a SILENT loss — the only failing outcome, at any tier.

The naming/format drift layer rides with the high tier: the registry must flag the agegrp vs
age_group spelling pair and a character-vs-numeric type conflict on fixture contracts, phrased
as questions — never verdicts.

Needs openpyxl (skips without it). Run: python3 tests/test_adversarial_tumor_tiers.py (or pytest).
"""
import json
import os
import shutil
import sys
import tempfile
from pathlib import Path

FRAMEWORK = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(FRAMEWORK / "tools"))
sys.path.insert(0, str(FRAMEWORK / "tests" / "fixtures"))

try:
    import openpyxl  # noqa: F401
    HAVE = True
except Exception:                                                        # noqa: BLE001
    HAVE = False

import spec_extract as se     # noqa: E402
import spec_lint as sl        # noqa: E402
import tumor_tiers            # noqa: E402

_CACHE = {}


def _cleanup():
    """Registered at first build, so the pytest path cleans up too — the __main__ runner's
    rmtree alone leaked six workbook directories per pytest run."""
    for _p, d in _CACHE.values():
        shutil.rmtree(d, ignore_errors=True)
    _CACHE.clear()


def _built(slug):
    if slug not in _CACHE:
        if not _CACHE:
            import atexit                             # noqa: PLC0415
            atexit.register(_cleanup)
        d = tempfile.mkdtemp(prefix=f"tier_{slug}_")
        _CACHE[slug] = (tumor_tiers.build(slug, os.path.join(d, f"{slug}.xlsx")), d)
    return _CACHE[slug][0]


def _skip():
    if HAVE:
        return False
    print("  (skipped: openpyxl absent)")
    return True


def _score(slug):
    """{trap_id: True/False} — did each planted trap's expected announcement appear? Plus the
    extracted rows, for the control checks. One reader for all three tiers, so the tiers cannot
    drift apart in how they are judged."""
    path = _built(slug)
    data = se.extract(path, domains=se.shared_domains())
    findings = sl.scan(data) + sl.scan_across(data) + sl.scan_structure(data)
    kinds = {str(f.get("kind") or "") for f in findings}
    st = se.workbook_structure(path)
    st_all = {k: v for sheet in st.values() for k, v in (sheet or {}).items() if v}
    rows = data["rows"]
    resolved = {(r.get("fields") or {}).get("variable") for r in rows}

    caught = {}
    for trap, (how, key) in tumor_tiers.TRAPS[slug].items():
        if how == "lint":
            caught[trap] = any(key in k for k in kinds)
        elif how == "structure":
            caught[trap] = key in st_all
        elif how == "loss":
            gone = key not in resolved
            announced = any("merged" in k for k in st_all)
            caught[trap] = gone and announced
        elif how == "adopted":
            domain_rows = [r for r in rows if r.get("domain") == key]
            caught[trap] = (bool(domain_rows)
                            and all((r.get("fields") or {}).get("variable")
                                    for r in domain_rows)
                            and "header_candidates" in st_all)
    return caught, resolved


def _assert_tier(slug):
    caught, resolved = _score(slug)
    silent = sorted(t for t, ok in caught.items() if not ok)
    assert not silent, f"{slug}: SILENT losses — nothing reported {silent}"
    missing = [c for c in tumor_tiers.CONTROLS[slug] if c not in resolved]
    assert not missing, f"{slug}: clean control rows failed to extract: {missing}"
    print(f"  {slug}: {len(caught)}/{len(caught)} traps reported, "
          f"{len(tumor_tiers.CONTROLS[slug])} controls extracted")


def test_tier1_small_every_trap_reported():
    """SMALL: a six-variable single-sheet program. The content lint alone must carry it — an
    impossible date, a twice-defined OS, a blank rule."""
    if _skip():
        return
    _assert_tier("bladder")


def test_tier2_medium_every_trap_reported():
    """MEDIUM: three sheets. Content traps now hide in sheet structure — a hidden retired row, a
    dropdown that IS the enumeration, and the same variable ruled differently on two tabs."""
    if _skip():
        return
    _assert_tier("rcc")


def test_tier3_high_every_trap_reported():
    """HIGH: five sheets, line-of-therapy content, and the attacks that deleted rows silently
    before Q3 closed them — the row-swallowing merge, the shadowing hidden column, the captured
    header (which 1.7 heals: the density switch adopts the real header beneath the title row,
    and the heal must be proven, not assumed). All must announce; the merge's victims must be
    provably gone, not merely flagged."""
    if _skip():
        return
    _assert_tier("mm")
    # the merge's second victim is gone too — the loss is the pair, not a lucky sample
    _caught, resolved = _score("mm")
    assert "PFS2L" not in resolved, "the m1 merge no longer deletes its victims — dead fixture"


def test_the_high_tier_carries_the_naming_and_format_drift_layer():
    """The drift a workbook cannot show: two packs spell one concept two ways, and one name is
    character in one contract and numeric in another. The registry must surface both AS
    QUESTIONS on fixture packs — no verdict words in any finding."""
    with tempfile.TemporaryDirectory() as tmp:
        for pack, name, ty in (("mm_a", "agegrp", "character"), ("mm_b", "age_group", "numeric")):
            d = Path(tmp) / "products" / "oncology" / pack / "202606"
            (d / "config").mkdir(parents=True)
            (d / "handoff").mkdir()
            (d / "config" / "data_product.yaml").write_text("name: x\n", encoding="utf-8")
            (d / "handoff" / "FUNCTIONAL_CONTRACT.md").write_text(f"""# fixture

```yaml
variable_id: AGEGRP
output: {{physical_name: {name}, name_status: undecided, type: character, role: published}}
```

```yaml
variable_id: PSADT
output: {{physical_name: psadt, name_status: undecided, type: {ty}, role: published}}
```
""", encoding="utf-8")
        import naming_registry as nr
        d = nr.docket(root=tmp)
        pair = {"agegrp", "age_group"}
        assert any({f["a"], f["b"]} == pair for f in d["open"]), \
            f"the tier-3 spelling drift is invisible: {d['open']}"
        assert [c["name"] for c in d["type_conflicts"]] == ["psadt"], d["type_conflicts"]
        for f in d["open"]:
            assert not any(w in json.dumps(f) for w in ("approved", "verified", "passed")), f


def test_wave2_small_melanoma():
    """WAVE 2, SMALL: trap classes wave 1 never used — a truncation the capture admits to, a
    value set the rule never finishes assigning, a slashed date impossible both ways round."""
    if _skip():
        return
    _assert_tier("mel")


def test_wave2_medium_gastric():
    """WAVE 2, MEDIUM: the corruption classes — a find/replace token stranded in a state list,
    one constant written two ways a typo apart, a TWO-LETTER variable duplicated across tabs
    (the short-name blindness Q3 closed), a partial-width merge, and a whole hidden SHEET."""
    if _skip():
        return
    _assert_tier("gastric")


def test_wave2_high_nsclc():
    """WAVE 2, HIGH: the author's own doubt in prose ('confirm with Science'), a bracketed
    algorithm placeholder, a rule that is only a pointer at the SAP, a requirement defining
    nothing, an unterminated chain, and the structural three (uncached formula, comment caveat,
    hidden retired row) on a biomarker-heavy five-variable-class spec."""
    if _skip():
        return
    _assert_tier("nsclc")


def test_wave2_uat_the_user_surfaces_answer_for_a_foreign_tumour():
    """The UAT slice: a user working the new tumour hits the OTHER surfaces. The exploration
    lane must refuse the nsclc-invented column as an ASSUMPTION (it is defined nowhere) while
    resolving an engine name; the naming grammar must flag the spelling drift a second author
    would introduce and stay silent on the convention twin."""
    import naming_registry as nr
    import quick_counts as qc
    r = qc.resolve(["pdl1_tps_grp", "regionl"])
    assert r["pdl1_tps_grp"]["resolution"] == "assumption", r
    assert r["regionl"]["resolution"] == "defined", r
    assert nr._near("egfr_mut", "egfrmut"), "normalized-equal spelling drift not flagged"
    assert not nr._near("pdl1", "pdl1n"), "the label/code convention twin must not flag"


def test_the_scorecard_is_complete_and_the_fixture_is_synthetic():
    """The aggregate: thirty-two traps across six tiers in two waves, every one with a wired
    expectation, and the fixture never names a vendor artefact — synthetic means synthetic."""
    if _skip():
        return
    total = sum(len(t) for t in tumor_tiers.TRAPS.values())
    assert total == 33, f"the tier design drifted: {total} traps"
    reported = 0
    for slug in tumor_tiers.TRAPS:
        caught, _ = _score(slug)
        reported += sum(caught.values())
    print(f"  scorecard: {reported}/{total} planted traps reported, 0 silent")
    assert reported == total
    src = Path(tumor_tiers.__file__).read_text(encoding="utf-8").lower()
    assert "flatiron" not in src and "optum" not in src, \
        "the synthetic fixture names a vendor — it must not"


if __name__ == "__main__":
    bad = 0
    for name, fn in sorted(globals().items()):
        if name.startswith("test_") and callable(fn):
            try:
                fn()
                print(f"  ok  {name}")
            except Exception as e:                   # noqa: BLE001 - report and continue
                bad += 1
                print(f"FAIL  {name}: {e}")
    _cleanup()
    sys.exit(1 if bad else 0)
