"""The typed control plane: the actions and objectives registries are complete, closed and honest.

  - every write-shaped CLI flag under platform/tools is bound to a declared action
  - no action names an agent or MCP surface as its performer; every action says agent: never
  - every emitted event is in the ledger's own vocabulary
  - no objective is released without a person's verdict; nothing routes unless released
  - the portal takes "who acts" from the registry; the agent's typed authority owners are declared roles
  - past requests are reused deterministically: similarity by slot overlap, pre-fill of EMPTY slots only

NO PYTEST FIXTURES AND NO `parametrize` — CI runs every suite as a script.
"""
import copy
import glob
import json
import os
import re
import sys
import tempfile
from pathlib import Path

FRAMEWORK = Path(__file__).resolve().parent.parent
ROOT = FRAMEWORK.parent
AGENT = ROOT / "experiments" / "agent"
for p in (FRAMEWORK / "tools", AGENT, ROOT / "experiments" / "portal"):
    sys.path.insert(0, str(p))
os.environ.setdefault("ANTHROPIC_API_KEY", "not-a-key-tests-never-call")

import control_plane as cp  # noqa: E402

P = "fixtures/oncology/prostate/202606"
WRITE_FLAGS = ("--apply", "--apply-verdicts", "--record", "--record-event", "--record-digest", "--add", "--new",
               "--forms", "--promote", "--write", "--write-facts", "--write-baseline",
               "--write-legacy-allowlist", "--retire", "--records", "--pin", "--decide")


def _read(rel):
    return (ROOT / rel).read_text(encoding="utf-8")


def test_both_registries_validate_and_are_closed():
    assert cp.validate() == [], cp.validate()
    a = cp.actions()
    assert set(a["roles"]) >= {"Science", "DataExpert", "Engineering", "operator", "admin"}
    assert cp.owners() == ["DataExpert", "Engineering", "Science", "operator"]
    o = cp.objectives()
    assert {x["id"] for x in o["objectives"]} >= {"governed_orchestration_model", "escalation_need_classifier",
                                                  "router_needs_more", "critic_calibration", "intake_elicitation_model"}
    assert all(x["status"] == "candidate" for x in o["objectives"]), "nothing is released until a person adjudicates"
    assert cp.released("governed_orchestration_model") is None


def test_every_write_shaped_cli_flag_is_bound_to_an_action():
    bound = cp.action_tools()
    missing = []
    for path in sorted(glob.glob(str(FRAMEWORK / "tools" / "*.py"))):
        src = Path(path).read_text(encoding="utf-8", errors="replace")
        rel = f"platform/tools/{os.path.basename(path)}"
        for flag in re.findall(r'add_argument\("(--[a-z][a-z-]*)"', src):
            if flag in WRITE_FLAGS and f"{rel} {flag}" not in bound:
                missing.append(f"{rel} {flag}")
    assert not missing, f"write paths with no declared action: {missing}"


def test_the_rules_bite():
    a = copy.deepcopy(cp.actions())
    a["actions"][0]["agent"] = "sometimes"
    a["actions"][0]["tool"] = "experiments/agent/tools.py call"
    a["actions"][0]["emits"] = {"object_kind": "decision", "action": "approved"}
    a["actions"][0]["purpose"] = "whatever"
    probs = cp.validate_actions(a)
    for needle in ("agent must be 'never'", "agent or MCP surface", "ledger's vocabulary", "closed vocabulary"):
        assert any(needle in p for p in probs), (needle, probs)
    o = copy.deepcopy(cp.objectives())
    o["objectives"][0]["status"] = "released"                                  # no verdict
    o["objectives"][1]["consumers"] = [{"where": "experiments/portal/app.py", "runtime_effect": "routing"}]
    probs = cp.validate_objectives(o)
    assert any("released requires a verdict" in p for p in probs), probs
    assert any("routing consumer requires status released" in p for p in probs), probs
    o["objectives"][0]["verdict"] = {"adjudicated_by": "RWB", "date": "2026-09-03"}       # a team is not a person
    assert any("is not a person" in p for p in cp.validate_objectives(o))


def test_the_portal_and_the_agent_read_owners_from_the_registry():
    app = _read("experiments/portal/app.py")
    assert "control_plane.owners()" in app and '["any", "Science", "DataExpert", "Engineering", "operator"]' not in app
    import tools  # noqa: PLC0415
    roles = set(cp.actions()["roles"])
    for name, owner in tools.AUTHORITY_TOOLS.items():
        for part in str(owner).split("/"):
            assert part in roles, (name, part)


def test_the_appendix_records_the_three_reference_pages():
    b = _read("docs/AGENTIC_BENCHMARK.md")
    i = b.index("### Reference platforms")
    sec = b[i:i + 6000]
    for needle in ("Modeling Objective", "Ontology", "Knowledge Store", "ACTIONS.yaml", "OBJECTIVES.yaml", "not to copy"):
        assert needle in sec, needle


# ------------------------------------------------------------------ past-request reuse

def test_past_requests_are_ranked_by_slot_overlap_and_prefill_fills_only_empty_slots():
    import intake  # noqa: PLC0415
    with tempfile.TemporaryDirectory() as root:
        # a kept request is reusable only once a governed run CHECKED it (eleventh verdict, second
        # pass): the run record's goal is the typed request, beside the requests directory
        d = os.path.join(root, "requests")
        os.makedirs(os.path.join(root, "runs"))

        def _checked(state, rid):
            with open(os.path.join(root, "runs", f"{rid}.json"), "w", encoding="utf-8") as fh:
                json.dump({"run_id": rid, "goal": intake.to_goal(state)}, fh)
            return intake.save_request(state, d, status="checked", run_id=rid, outcome="done")
        st = intake.new_state("feasibility", P, "alex")
        st["request"].update({"source": "Optum claims 2023", "population": "COPD patients", "index_codes": "J44",
                              "time_window": "2023", "baseline_lookback": "12 months", "exclusions": "asthma J45",
                              "exclusion_rule": "any diagnosis code during baseline", "code_position": "any position",
                              "measure": "top 20 comorbid conditions", "requested_by": "alex"})
        path = _checked(st, "run-1")
        assert os.path.dirname(path) == os.path.realpath(d) and path.endswith(".yaml")
        other = intake.new_state("feasibility", P, "ana")
        other["request"].update({"source": "Flatiron EHR", "population": "mCRPC patients", "index_codes": "C61",
                                 "time_window": "2022", "measure": "line of therapy distribution", "requested_by": "ana",
                                 "baseline_lookback": "6 months", "exclusions": "none", "code_position": "any position"})
        _checked(other, "run-2")
        q = intake.new_state("question", P, "x")
        q["request"].update({"topic": "TSST", "question": "q", "evidence": "e", "owner": "Science", "requested_by": "x"})
        _checked(q, "run-3")
        past = intake.load_requests(d)
        assert len(past) == 3
        new = intake.new_state("feasibility", P, "bob")
        new["request"].update({"population": "COPD", "index_codes": "J44", "source": "Optum claims"})
        ranked = intake.similar(new, past, k=3)
        assert ranked and ranked[0][1]["request"]["population"] == "COPD patients", ranked[0][1]["request"]
        assert all(r["kind"] == "feasibility" for _, r in ranked), "only the same domain is reusable"
        filled = intake.prefill(new, ranked[0][1])
        assert filled["request"]["population"] == "COPD", "a filled slot is never overwritten"
        assert filled["request"]["baseline_lookback"] == "12 months" and filled["request"]["measure"] == "top 20 comorbid conditions"
        assert filled["request"]["requested_by"] is None, "who asks is never copied from a past request"
        assert {d_["slot"] for d_ in intake.decisions(filled)} >= {"baseline_lookback", "exclusions"}, "pre-filled decisions stay decisions"
        assert any("pre-filled" in n for n in filled["notes"])
    assert "experiments/agent/requests/" in _read(".gitignore")
    app = _read("experiments/portal/app.py")
    assert "intake.similar(" in app and "intake.prefill(" in app and "intake.save_request(" in app


if __name__ == "__main__":
    fails = 0
    for name, fn in sorted(globals().items()):
        if name.startswith("test_") and callable(fn):
            try:
                fn()
                print(f"  ok   {name}")
            except Exception as e:  # noqa: BLE001
                fails += 1
                print(f"  FAIL {name}: {e}")
    print(f"{fails} failure(s)")
    sys.exit(1 if fails else 0)
