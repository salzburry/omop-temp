"""Opt-in current VS Code durable preparation smoke, entirely outside the checkout.

This explicit test-only adapter keeps SessionModel bound to the actual workspace.
It supplies one synthetic existing function and lesson; nothing is staged/applied.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
import shutil
import tempfile
import time
from unittest.mock import patch

from live_portal_journeys import ROOT, ConnectedTransport, digest_files, load_local_environment
import portal_agent_connection as connection
import scientific_definition_ai as ai
import workflow_durable_fixes as durable
import workflow_skills


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--run", action="store_true")
    args = parser.parse_args()
    if not args.run:
        parser.error("Use --run to explicitly request one live preparation and its critic.")
    load_local_environment()
    selected = ConnectedTransport()  # Health and exact current model, no fallback.
    before = digest_files(ROOT, ["products", "fixtures", "work", "experiments/agent/knowledge/corrections"])
    base = Path(os.environ.get("LOCALAPPDATA", tempfile.gettempdir())) / "RwdPortal/live-journeys-20260908"
    base.mkdir(parents=True, exist_ok=True)
    root = Path(tempfile.mkdtemp(prefix="durable-", dir=base)).resolve()
    assert not root.is_relative_to(ROOT)
    shutil.copytree(ROOT / ".claude/skills", root / ".claude/skills")
    path = "experiments/portal/flow_page.py"
    target = root / path
    target.parent.mkdir(parents=True)
    original = "def next_row(selected_row):\n    return 'first row'\n"
    target.write_text(original, encoding="utf-8")
    loop = workflow_skills.learning()
    row = loop.propose_correction(root, "operate-rwd-product", "The next action loses the selected row.",
        "Keep the selected row after checking progress.", "Selected-row continuation.",
        "Alex Morgan", "Continue my selected row.")
    actual_model, actual_describe = connection.model, connection.describe
    expected = actual_describe(ROOT)
    report = {"model": selected.model, "fixture": path,
        "transport_boundary": "Test-only factory maps the disposable fixture to the unchanged actual-checkout SessionModel; production checkout guards remain enforced.",
        "request": "Change existing next_row so next_row('selected row') returns 'selected row'. Test that exact call and expected result.",
        "before": original, "staged": False, "applied": False}
    sessions = []

    def factory(request_root, *, expected=None):
        assert Path(request_root).resolve() == root
        model = actual_model(ROOT, expected=expected)
        assert model.client.root.resolve() == ROOT.resolve()
        sessions.append(model)
        return model

    def describe(request_root):
        assert Path(request_root).resolve() == root
        return actual_describe(ROOT)

    started = time.monotonic()
    try:
        with patch.object(connection, "model", factory), patch.object(connection, "describe", describe):
            result = durable.prepare(root, "Alex Morgan", row["id"], goal=report["request"], kind="code", path=path,
                expected_digest=row["digest"], expected_connection=expected, confirmed=True,
                can_write=True, can_review=True, allowed_packs=[])
        report.update(status="prepared_for_review", prepared=result["prepared"], critic=result["critic"],
                      diff=result["diff"], model_calls=result["model_calls"], changed=result["changed"])
    except Exception as error:
        detail = str(error)
        try:
            ai._ingress(detail)
            safe = detail[:1800]
        except Exception:
            safe = "The preparation failed; sensitive diagnostics were not retained."
        report.update(status="failed", error_type=type(error).__name__, error=safe,
                      model_calls=sum(model.calls for model in sessions))
    report.update(seconds=round(time.monotonic() - started, 2), target_unchanged=target.read_text() == original,
        correction_unchanged=loop.read_correction(root, row["id"])["digest"] == row["digest"],
        original_inputs_unchanged=before == digest_files(ROOT, ["products", "fixtures", "work", "experiments/agent/knowledge/corrections"]))
    report["fixture_sha256"] = hashlib.sha256(original.encode()).hexdigest()
    (root / "results.json").write_text(json.dumps(report, indent=2), encoding="utf-8")
    print(json.dumps({"results": str(root / "results.json"), "status": report["status"],
        "model_calls": report["model_calls"], "target_unchanged": report["target_unchanged"],
        "original_inputs_unchanged": report["original_inputs_unchanged"]}), flush=True)
    return 0 if report["status"] == "prepared_for_review" and report["target_unchanged"] and report["correction_unchanged"] and report["original_inputs_unchanged"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
