"""Real scientific AI routing over a scripted Claude Code adapter; no CLI calls."""
from __future__ import annotations

import copy
from contextvars import copy_context
import json
import os
from pathlib import Path
import sys
from types import SimpleNamespace
from unittest.mock import Mock

import pytest

ROOT = Path(__file__).resolve().parents[2]
sys.path[:0] = [str(ROOT / "platform/tests"), str(ROOT / "experiments/portal"), str(ROOT / "platform/tools")]
import scientific_definition_ai as rows
import decision_answer_ai as questions
import decision_answers
from test_epi_scientific_definitions import ACTOR, ITEM, fixture, describe, governed_bytes
from test_epi_scientific_definition_ai import reply as row_reply, suggestion
from test_epi_decision_answer_ai import ACTOR as QUESTION_ACTOR, seed, snapshot, reply as question_reply
from test_spec_slice import _strip_extraction


@pytest.fixture
def scripted(monkeypatch):
    import scientific_definition_claude_code as claude_code
    rows.set_provider_selection(None)
    monkeypatch.setenv("RWD_PORTAL_LOCAL_DEMO", "1")
    monkeypatch.setenv("RWD_PORTAL_AI_PROVIDER", "claude_code")
    monkeypatch.setenv("ANTHROPIC_API_KEY", "UNUSED-API-KEY-SENTINEL")
    monkeypatch.delenv("RWD_AGENT_MODEL", raising=False)
    state = SimpleNamespace(model="claude-sonnet-4-6", connection_id="scripted-cli-account-1",
        model_info={"id": "claude-sonnet-4-6", "name": "Claude Sonnet", "family": "sonnet", "vendor": "anthropic", "version": ""},
        calls=[], constructed=[], health_calls=[], response=row_reply(), callback=None,
        construction_error=None, health_error=None)

    class ScriptedClaudeCode:
        def __init__(self, root, *, local_demo=False):
            state.constructed.append((str(Path(root).resolve()), local_demo))
            if state.construction_error:
                raise state.construction_error
            self.model = state.model
            self.model_info = copy.deepcopy(state.model_info)
            self.connection_id = state.connection_id

        def health(self):
            state.health_calls.append(self.connection_id)
            if state.health_error:
                raise state.health_error
            return copy.deepcopy(self.model_info)

        def step(self, system, transcript, tools=None):
            assert tools is None
            state.calls.append((system, copy.deepcopy(transcript)))
            if state.callback:
                state.callback()
            if isinstance(state.response, BaseException):
                raise state.response
            return state.response

    monkeypatch.setattr(claude_code, "ClaudeCodeModel", ScriptedClaudeCode)
    anthropic = Mock(side_effect=AssertionError("Anthropic fallback must never run"))
    vscode = Mock(side_effect=AssertionError("VS Code fallback must never run"))
    monkeypatch.setattr(rows, "_make_model", anthropic)
    monkeypatch.setattr(rows.vscode, "VSCodeModel", vscode)
    yield state
    rows.set_provider_selection(None)
    anthropic.assert_not_called()
    vscode.assert_not_called()


def case(tmp_path, kind, state):
    if kind == "row":
        root, pack, product, values = fixture(tmp_path)
        values["notes"] = "My unsaved scientific reasoning."
        current = describe(root, pack)
        state.response = row_reply()
        kwargs = dict(expected_input_digest=current["input_digest"], expected_draft_digest=current["draft_digest"],
                      local_demo=True, can_write=True, allowed_packs=[pack])
        generate = lambda **extra: rows.suggest(root, pack, ACTOR, ITEM, values, **{**kwargs, **extra})
        accept = lambda proposal: rows.accept(root, pack, ACTOR, ITEM, values, proposal, ["derivation"], **kwargs)
        availability = lambda: rows.describe_availability(root, pack, ACTOR, ITEM, allowed_packs=[pack])
    else:
        root, pack, product = seed(tmp_path)
        values = "My unsaved question reasoning."
        state.response = question_reply()
        kwargs = dict(expected_digest=decision_answers.describe(root, pack)["digest"],
                      local_demo=True, can_write=True, allowed_packs=[pack])
        generate = lambda **extra: questions.suggest(root, pack, QUESTION_ACTOR, "Q1", values, **{**kwargs, **extra})
        accept = lambda proposal: questions.accept(root, pack, QUESTION_ACTOR, "Q1", values, proposal, "option_1", **kwargs)
        availability = lambda: questions.describe_availability(root, pack, QUESTION_ACTOR, "Q1", allowed_packs=[pack])
    return SimpleNamespace(root=root, pack=pack, product=product, values=values,
                           generate=generate, accept=accept, availability=availability)


@pytest.mark.parametrize("kind", ["row", "question"])
def test_claude_code_routes_one_source_bound_request_and_accepts_only_a_draft(tmp_path, scripted, kind):
    current = case(tmp_path, kind, scripted)
    before = snapshot(current.root)
    governed = governed_bytes(current.product)
    available = current.availability()
    assert available["configured"] and available["source_eligible"], available
    assert available["provider_id"] == "claude_code" and available["provider"] == "Claude Code"
    # Construction checks version and sign-in; an immediate second health
    # probe would launch the same sign-in command twice for this one check.
    assert len(scripted.constructed) == 1 and not scripted.health_calls and not scripted.calls
    result = current.generate()
    assert result["ok"], result
    assert len(scripted.calls) == 1 and len(scripted.calls[0][1]) == 1
    transcript = scripted.calls[0][1][0]
    assert set(transcript) == {"role", "content"} and transcript["role"] == "user"
    sent = json.loads(transcript["content"])["context"]
    assert sent["pack"] == current.pack
    assert (sent["item_id"] == ITEM if kind == "row" else sent["decision_id"] == "Q1")
    assert "UNRELATED-QUESTION-SENTINEL" not in transcript["content"]
    assert "UNUSED-API-KEY-SENTINEL" not in transcript["content"] + json.dumps(result)
    assert all(root == str(current.root.resolve()) and local for root, local in scripted.constructed)
    proposal = result["proposal"]
    assert proposal["provider_id"] == "claude_code" and proposal["model"] == scripted.model
    assert proposal["model_info"] == scripted.model_info and proposal["connection_id"] == scripted.connection_id
    assert snapshot(current.root) == before
    copied = current.accept(proposal)
    assert copied["ok"] and copied["draft_only"], copied
    assert governed_bytes(current.product) == governed
    if kind == "row":
        assert copied["changed"] and copied["values"] == {**current.values, "derivation": suggestion()["value"]}
    else:
        assert copied["changed"] is False and copied["answer"].startswith(questions.DRAFT_PREFIX)
        assert snapshot(current.root) == before
        assert all(item["status"] == "OPEN" for item in decision_answers.describe(current.root, current.pack)["items"])
    assert len(scripted.calls) == 1


@pytest.mark.parametrize("kind", ["row", "question"])
def test_claude_code_needs_neither_api_credential_nor_api_model_registry_choice(tmp_path, scripted, monkeypatch, kind):
    current = case(tmp_path, kind, scripted)
    monkeypatch.delenv("ANTHROPIC_API_KEY")
    monkeypatch.setenv("RWD_AGENT_MODEL", "not-an-api-model-registration")
    available = current.availability()
    assert available["configured"] and available["provider_id"] == "claude_code", available
    result = current.generate()
    assert result["ok"] and len(scripted.calls) == 1, result
    assert current.accept(result["proposal"])["ok"]


@pytest.mark.parametrize("kind", ["row", "question"])
@pytest.mark.parametrize("dimension", ["provider", "model", "connection"])
def test_provider_or_model_change_requires_fresh_options_before_copy(tmp_path, scripted, kind, dimension):
    current = case(tmp_path, kind, scripted)
    result = current.generate()
    assert result["ok"], result
    before = snapshot(current.root)
    if dimension == "provider":
        rows.set_provider_selection("anthropic")
    elif dimension == "model":
        scripted.model = "claude-sonnet-4-5"
        scripted.model_info["id"] = scripted.model
    else:
        scripted.connection_id = "a-different-cli-account"
    copied = current.accept(result["proposal"])
    assert not copied["ok"] and "changed" in " ".join(copied["errors"]), copied
    assert snapshot(current.root) == before and len(scripted.calls) == 1


@pytest.mark.parametrize("kind", ["row", "question"])
@pytest.mark.parametrize("dimension", ["model", "connection"])
def test_connection_changes_during_generation_cannot_publish_stale_options(tmp_path, scripted, kind, dimension):
    current = case(tmp_path, kind, scripted)
    before = snapshot(current.root)
    def changed():
        if dimension == "model":
            scripted.model_info["name"] = "A different Claude model"
        else:
            scripted.connection_id = "changed-during-request"
    scripted.callback = changed
    result = current.generate()
    assert not result["ok"] and "changed" in " ".join(result["errors"]), result
    assert "proposal" not in result and len(scripted.calls) == 1
    assert snapshot(current.root) == before


@pytest.mark.parametrize("kind", ["row", "question"])
@pytest.mark.parametrize("boundary", ["source", "scope", "readonly", "hosted"])
def test_existing_scientific_access_guards_run_before_constructing_claude_code(tmp_path, scripted, kind, boundary):
    current = case(tmp_path, kind, scripted)
    overrides = {}
    if boundary == "source":
        _strip_extraction(current.product)
    elif boundary == "scope":
        overrides["allowed_packs"] = []
    elif boundary == "readonly":
        overrides["can_write"] = False
    else:
        overrides["local_demo"] = False
    before = snapshot(current.root)
    result = current.generate(**overrides)
    assert not result["ok"] and not scripted.constructed and not scripted.calls
    assert snapshot(current.root) == before


@pytest.mark.parametrize("kind", ["row", "question"])
@pytest.mark.parametrize("failure_stage", ["construction", "generation"])
def test_claude_code_errors_are_sanitized_without_using_an_available_api_key(tmp_path, scripted, kind, failure_stage):
    import scientific_definition_claude_code as claude_code
    current = case(tmp_path, kind, scripted)
    before = snapshot(current.root)
    error = claude_code.ClaudeCodeError("provider_error")
    if failure_stage == "construction":
        scripted.construction_error = error
    else:
        scripted.response = error
    result = current.generate()
    assert not result["ok"] and "proposal" not in result
    assert claude_code.ERRORS["provider_error"] in " ".join(result["errors"]), result
    assert "UNUSED-API-KEY-SENTINEL" not in json.dumps(result)
    assert snapshot(current.root) == before


def test_provider_selection_is_context_local_and_explicit_blank_disables_environment_default(monkeypatch):
    monkeypatch.setenv("RWD_PORTAL_AI_PROVIDER", "vscode")
    rows.set_provider_selection(None)
    try:
        assert rows.selected_provider() == "vscode"
        environment = dict(os.environ)
        isolated = copy_context()
        isolated.run(rows.set_provider_selection, "claude_code")
        assert isolated.run(rows.selected_provider) == "claude_code"
        assert rows.selected_provider() == "vscode"
        rows.set_provider_selection("")
        assert rows.selected_provider() == ""
        assert dict(os.environ) == environment
    finally:
        rows.set_provider_selection(None)
