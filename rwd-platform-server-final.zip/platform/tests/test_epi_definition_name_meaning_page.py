"""A scientist sees semantic naming differences in the actual row review flow."""
from pathlib import Path
import sys

from streamlit.testing.v1 import AppTest

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "platform/tests"))
from test_epi_scientific_definition_page import button, validate, page
from test_epi_scientific_definitions import ACTOR, fixture, governed_bytes, preview
from test_epi_definition_name_meaning import _peer, _replace_peer
from test_contract_lint import one


def _app(root, pack, scope):
    code = f'''import scientific_definition_page as page
page.render({str(root)!r}, {pack!r}, {ACTOR!r}, local_demo=True,
            can_write=True, can_view=True, naming_packs={scope!r})
'''
    at = AppTest.from_string(code, default_timeout=30).run()
    assert not at.exception, [e.message for e in at.exception]
    return at


def _setup(tmp_path):
    root, pack, product, values = fixture(tmp_path, [one(req="draft", impl="not_implemented")])
    candidate = preview(root, pack, values)
    assert candidate["passed"], candidate
    peer_pack, peer = _peer(root, product, candidate["after"], window="[-90, +14]")
    return root, pack, product, candidate, peer_pack, peer


def test_review_explains_different_meaning_and_saves_only_a_draft(tmp_path):
    root, pack, product, candidate, peer_pack, peer = _setup(tmp_path)
    hidden_pack, _ = _peer(root, product, candidate["after"], slug="hidden",
                           derivation="PRIVATE_UNRELATED_MEANING")
    peer_before = governed_bytes(peer)
    at = _app(root, pack, [pack, peer_pack])
    validate(at)
    assert not at.exception, [e.message for e in at.exception]
    assert any("naming review must be resolved" in e.value for e in at.warning)
    table = next(table.value for table in at.dataframe if "Scientific field" in table.value.columns)
    assert table["Scientific field"].tolist() == ["window"]
    assert table["Existing definition"].tolist() == ["[-90, +14]"]
    visible = " ".join(str(e.value) for e in [*at.caption, *at.info, *at.warning])
    assert hidden_pack not in visible and "PRIVATE_UNRELATED_MEANING" not in visible
    assert "science workbench" in visible
    assert button(at, "Save checked definition to contract").disabled
    at.checkbox(key=page.PREFIX + "confirm").check().run()
    button(at, "Save checked definition to contract").click().run()
    assert not at.exception, [e.message for e in at.exception]
    assert any("not approval or release" in e.value for e in at.success)
    assert governed_bytes(peer) == peer_before
    contract = (product / "handoff/FUNCTIONAL_CONTRACT.md").read_text(encoding="utf-8")
    assert contract == candidate["after"]


def test_changed_peer_after_visible_review_refuses_save_and_preserves_answers(tmp_path):
    root, pack, product, candidate, peer_pack, peer = _setup(tmp_path)
    at = _app(root, pack, [pack, peer_pack])
    validate(at)
    at.checkbox(key=page.PREFIX + "confirm").check().run()
    before = governed_bytes(product)
    _replace_peer(peer, candidate["after"], window="[-180, 0]")
    button(at, "Save checked definition to contract").click().run()
    assert not at.exception, [e.message for e in at.exception]
    assert any("reviewed proposal changed" in e.value.lower() for e in at.error)
    assert governed_bytes(product) == before
    assert button(at, "Validate and preview contract change")


def test_resolved_comparison_shows_its_basis_without_a_pending_warning():
    review = {"physical_name": "test_date", "resolved": True,
              "question": "Different recorded wording has an existing reviewed implementation.",
              "differences": [{"field": "window", "current": "0", "peer": "index day"}],
              "resolution": {"basis": "same registered implementation"}}
    at = AppTest.from_string(
        "import scientific_definition_page as page\npage._render_name_reviews(" + repr([review]) + ")"
    ).run()
    assert not at.exception and not at.warning
    assert any("Existing review basis: same registered implementation" == e.value for e in at.caption)
    assert len(at.dataframe) == 1


def test_no_reused_name_adds_no_review_controls():
    at = AppTest.from_string(
        "import scientific_definition_page as page\npage._render_name_reviews([])"
    ).run()
    assert not at.exception and not at.expander and not at.warning and not at.dataframe
