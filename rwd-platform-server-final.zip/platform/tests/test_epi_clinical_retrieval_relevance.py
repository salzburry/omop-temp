"""Clinical evidence relevance: replay failing live-evaluation queries offline."""
from pathlib import Path
import json
import sys

import pytest
import yaml

ROOT = Path(__file__).resolve().parents[2]
sys.path[:0] = [str(ROOT / folder) for folder in ("platform/tests", "experiments/portal", "experiments/agent", "platform/tools")]
import scientific_conversation_context as context
from test_epi_chat_knowledge_context import reference


def clinical(root, question):
    packet = context.build_chat(root, None, "synthetic-reviewer", question, allowed_packs=[])
    return [json.loads(item["text"]) for item in packet["sources"] if item["kind"] == "clinical_code"]


@pytest.mark.parametrize("case_id", ["conversation_nsclc_treatment", "conversation_crc_procedure", "conversation_ehr_followup"])
def test_evaluation_questions_and_full_briefs_do_not_retrieve_unrelated_codes(tmp_path, case_id):
    # These are the same versioned synthetic cases used in the live evaluation,
    # with the real enumeration copied to an isolated reference-only workspace.
    cases = yaml.safe_load((ROOT / "experiments/agent/evals/cases_conversations.yaml").read_bytes())["cases"]
    case = next(item for item in cases if item["id"] == case_id)
    path = tmp_path / "governance/reference/mcode_stu4/VALUE_SET_CODES.json"
    path.parent.mkdir(parents=True)
    path.write_bytes((ROOT / path.relative_to(tmp_path)).read_bytes())
    brief = "\n".join(key + ": " + value for key, value in case["initial"].items())
    query = case["turns"][0]["text"] + "\n" + brief
    assert clinical(tmp_path, query) == []
    # A short unresolved response still carries the existing topic into search.
    assert clinical(tmp_path, "Not sure\n" + query + "\n" + case["turns"][2]["suffix"]) == []


@pytest.mark.parametrize("query", [
    "Use all dates, the last encounter and missing source values to define follow-up.",
    "Review the standard risk of missing data; report the current status and system description.",
    "Find a colorectal cancer procedure definition, including endoscopic tumour removal.",
    "Explain death date completeness for observation end and outcome censoring.",
])
def test_metadata_substrings_and_specimen_context_are_not_clinical_concepts(tmp_path, query):
    reference(tmp_path, [
        {"code_system": "NCIT", "code": "SYNTH-ALL", "description": "Standard Risk Acute Lymphoblastic Leukemia", "value_set": "Acute Lymphoblastic Leukemia (ALL) Risk Assessment Value Set"},
        {"code_system": "NCIT", "code": "SYNTH-LANSKY", "description": "Lansky Performance Status 60", "value_set": "Lansky Play Performance Status VS"},
        {"code_system": "LOINC", "code": "SYNTH-KRAS", "description": "KRAS gene mutations found [Identifier] in Colorectal cancer specimen by Molecular genetics method", "value_set": "Tumor Marker Test Value Set"},
        {"code_system": "LOINC", "code": "SYNTH-LIGAND", "description": "Cells.programmed cell death ligand 1/100 viable tumor cells in Tissue by Immune stain", "value_set": "Tumor Marker Test Value Set"},
        {"code_system": "LOINC", "code": "SYNTH-PDL1", "description": "PD-L1 by clone 22C3 in Tissue by Immune stain Report", "value_set": "Tumor Marker Test Value Set"},
    ])
    assert clinical(tmp_path, query) == []


@pytest.mark.parametrize("concept", ["PD-L1", "PDL1", "ALK", "MSI", "TMB"])
def test_exact_biomarker_concepts_keep_hyphenated_and_three_letter_lookups(tmp_path, concept):
    reference(tmp_path, [
        {"code_system": "LOINC", "code": "SYNTH-" + name, "description": name + " result in Tissue by assay", "value_set": "Tumor Marker Test Value Set"}
        for name in ("PD-L1", "ALK", "MSI", "TMB")
    ] + [{"code_system": "NCIT", "code": "CL1914012", "description": "Unrelated performance status", "value_set": "Unrelated stage list"}])
    rows = clinical(tmp_path, "Find " + concept + " measurement coding for this study.")
    expected = "PD-L1" if concept == "PDL1" else concept
    assert [row["code"] for row in rows] == ["SYNTH-" + expected]


def test_named_instrument_and_complete_identifier_remain_discoverable(tmp_path):
    reference(tmp_path, [{"code_system": "NCIT", "code": "SYNTH-LANSKY", "description": "Lansky Performance Status 60", "value_set": "Lansky Play Performance Status VS"}])
    assert clinical(tmp_path, "Explain Lansky performance status coding.")[0]["code"] == "SYNTH-LANSKY"
    assert clinical(tmp_path, "Look up the exact code SYNTH-LANSKY.")[0]["code"] == "SYNTH-LANSKY"
    assert clinical(tmp_path, "Look up the exact code SYNTH-LAN.") == []
