"""In-process job transport for AppTest; production actions and journals are real.

Detached process survival/cancellation are tested separately in test_epi_portal_jobs.
This seam preserves each UI test's existing provider and runtime test doubles.
"""
import os
from pathlib import Path
from types import SimpleNamespace


def synchronous_jobs(monkeypatch, private):
    import portal_jobs
    monkeypatch.setenv("RWDP_STATE_DIR", str(private))

    def spawn(command, **_options):
        portal_jobs._worker(Path(command[-1]))
        return SimpleNamespace(pid=os.getpid(), poll=lambda: 0)

    monkeypatch.setattr(portal_jobs, "_spawn", spawn)
