"""Actual engine/job/CI context reaches coding and its critic; no runtime executes."""
from pathlib import Path
import copy
import json
import re
import shutil
import sys

import pytest
import yaml
from streamlit.testing.v1 import AppTest

ROOT = Path(__file__).resolve().parents[2]
sys.path[:0] = [str(ROOT / p) for p in ('experiments/agent', 'experiments/portal', 'platform/tools')]
import coding_agent as coding
import specialist_workspace as specialist
import workflow_skills
import state

PACK = 'products/oncology/example/202609'


@pytest.fixture
def checkout(tmp_path):
    for relative in ('platform/engine/build_ads.py', 'platform/databricks/run_rwdp.py',
                     '.github/workflows/rwdp-ci.yml', 'platform/capabilities.yaml'):
        path = tmp_path / relative
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes((ROOT / relative).read_bytes())
    for relative in ('platform/engine/stages', 'platform/tests'):
        for source in (ROOT / relative).glob('*.py'):
            target = tmp_path / source.relative_to(ROOT)
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes(source.read_bytes())
    config = tmp_path / PACK / 'config'
    config.mkdir(parents=True)
    (config / 'data_product.yaml').write_text('product_id: example\nsources:\n  ecog: {stem: t_ecog}\ncohorts: [{id: index, cohortn: 1}]\nrun: {write_mode: overwrite}\n', encoding='utf-8')
    jobs = tmp_path / 'resources/products.yml'
    jobs.parent.mkdir()
    jobs.write_text(yaml.safe_dump({'resources': {'jobs': {
        'rwdp_build_example': {'tasks': [{'task_key': 'build_ads', 'notebook_task': {'notebook_path': '../platform/databricks/run_rwdp.py', 'base_parameters': {'tumor_slug': 'example', 'refresh': '${var.example_refresh}'}}}]},
        'rwdp_build_foreign': {'name': 'OFF_SCOPE_SENTINEL', 'tasks': []}}}}), encoding='utf-8')
    return tmp_path


def test_actual_entrypoints_dataflow_job_parameters_and_ci_are_present(checkout):
    result = coding.orchestration_context(PACK, root=checkout)
    assert 'platform/engine/build_ads.py::build_from_sources' in result['entry_points']
    assert any(row['call'] == 'clinical.build' and 'idx' in row['inputs'] and row['output'] == 'clin' for row in result['stage_calls'])
    assert any(row['call'] == 'outcomes.build' and 'clin' in row['inputs'] for row in result['stage_calls'])
    assert result['ci_commands'] and 'OFF_SCOPE_SENTINEL' not in json.dumps(result)
    assert result['jobs'][0]['parameter_names'] == ['refresh', 'tumor_slug']
    assert result['configuration'][PACK + '/config/data_product.yaml']['run']['write_mode'] == 'overwrite'
    assert any('pipeline.yaml is absent' in finding for finding in result['findings'])
    assert all('sha256' in file for file in result['files'])


def test_context_freshness_covers_engine_config_jobs_and_new_missing_files(checkout):
    def context():
        result = coding.implementation_context('ECOG', root=checkout)
        result['orchestration'] = coding.orchestration_context(PACK, root=checkout)
        return result
    for relative in ('platform/engine/build_ads.py', PACK + '/config/data_product.yaml', PACK + '/config/pipeline.yaml'):
        old = context()
        assert coding.context_current(old, root=checkout)
        path = checkout / relative
        original = path.read_bytes() if path.exists() else None
        path.write_bytes((original or b'') + b'\n# changed\n')
        assert not coding.context_current(old, root=checkout)
        if original is None:
            path.unlink()
        else:
            path.write_bytes(original)
    old = context()
    path = checkout / 'resources/products.yml'
    doc = yaml.safe_load(path.read_bytes())
    doc['resources']['jobs']['rwdp_build_foreign']['name'] = 'CHANGED_FOREIGN_SENTINEL'
    path.write_text(yaml.safe_dump(doc), encoding='utf-8')
    assert coding.context_current(old, root=checkout)
    doc['resources']['jobs']['rwdp_build_example']['tasks'][0]['task_key'] = 'changed_task'
    path.write_text(yaml.safe_dump(doc), encoding='utf-8')
    assert not coding.context_current(old, root=checkout)


@pytest.mark.parametrize('bad', ['../other', 'products/oncology/example/202609/../../other', 'products/oncology/other/202609\n'])
def test_orchestration_path_scope_refuses_invalid_pack(checkout, bad):
    with pytest.raises(ValueError):
        coding.orchestration_context(bad, root=checkout)


@pytest.mark.parametrize('bad', ['resources: [wrong]', 'resources: {jobs: wrong}', 'resources: [ broken'])
def test_malformed_job_metadata_refuses_without_raw_content(checkout, bad):
    (checkout / 'resources/products.yml').write_text(bad, encoding='utf-8')
    with pytest.raises(ValueError, match='Malformed job metadata'):
        coding.orchestration_context(PACK, root=checkout)


def integration(context):
    return {'entry_points': context['entry_points'][:1], 'config_paths': list(context['configuration']),
        'dependencies': ['Use the configured index frame.'], 'outputs': ['Preserve the declared patient/index/cohort grain.'],
        'checks': {key: 'Review the actual declared case before running its existing harness.' for key in ('nulls', 'ties', 'repeat_run', 'failure', 'integration')},
        'unresolved': ['The synthetic product has no pipeline override file.']}


def test_integration_plan_uses_only_actual_paths_and_never_claims_runtime(checkout):
    context = coding.orchestration_context(PACK, root=checkout)
    cap = coding.implementation_context('ECOG', root=checkout)['capabilities'][0]['id']
    proposal = {'decision': 'reuse', 'reuse': {'capability_id': cap}, 'summary': 'Review the existing caller.', 'integration': integration(context)}
    checks, _ = coding.static_review(proposal, PACK, root=checkout, orchestration=context)
    assert not checks['static_findings'] and checks['pipeline_runtime_run'] is False
    proposal['integration']['entry_points'] = ['platform/engine/invented.py::run']
    checks, _ = coding.static_review(proposal, PACK, root=checkout, orchestration=context)
    assert any('absent from the supplied' in finding for finding in checks['static_findings'])
    del proposal['integration']
    checks, _ = coding.static_review(proposal, PACK, root=checkout, orchestration=context)
    assert any('integration plan' in finding for finding in checks['static_findings'])


def test_canonical_coding_and_critic_receive_pipeline_and_real_code_with_same_skill(checkout, monkeypatch):
    monkeypatch.setattr(coding, 'ROOT', str(checkout))
    monkeypatch.setattr(coding.tools, 'call', lambda name, args: 'ECOG baseline at the declared index; preserve reviewed timing.' if name == 'definition' else 'Current registered capabilities are in implementation_context.')
    monkeypatch.setattr(coding, 'CANDIDATES', str(checkout / 'candidates'))
    monkeypatch.setattr(state, 'candidate_file', lambda *_: str(checkout / 'candidates/result.json'))
    evidence = coding.gather(PACK, 'ECOG')
    orchestration = evidence['implementation_context']['orchestration']
    proposal = {'decision': 'reuse', 'reuse': {'capability_id': evidence['implementation_context']['capabilities'][0]['id']},
        'summary': 'Review the supplied existing entry point.', 'integration': integration(orchestration)}
    verdict = {'falsified': False, 'confidence': 'high', 'findings': [], 'route': 'pass_on', 'why': 'Review only; no execution.'}
    calls = []
    class Client:
        model = 'scripted-no-network'
        def step(self, system, messages):
            calls.append((system, messages))
            text = messages[0]['content']
            assert 'build_from_sources' in text and 'stage_calls' in text
            assert re.search(r'"kind"\s*:\s*"implementation"', text)
            assert re.search(r'"kind"\s*:\s*"test"', text)
            return json.dumps(proposal if len(calls) == 1 else verdict)
    skills = workflow_skills.context_for(ROOT, kind='implementation', max_bytes=4500)
    result = coding.run(PACK, 'ECOG', model=specialist.BoundedModel(Client(), {'provider_id': 'vscode'}, skills=skills))
    assert result['model_calls'] == 2 and len(calls) == 2
    assert all(skills['prompt'] in system for system, _ in calls)
    assert result['implementation_context']['orchestration'] == orchestration
    assert result['deterministic_checks']['pipeline_runtime_run'] is False


def test_retained_pattern_cannot_reuse_an_old_orchestration_snapshot(checkout):
    import pattern_workspace as patterns
    context = coding.orchestration_context(PACK, root=checkout)
    record = {'pack': PACK, 'result': {'implementation_context': {'orchestration': context}}}
    assert patterns._orchestration_current(checkout, record)
    path = checkout / 'platform/engine/build_ads.py'
    path.write_bytes(path.read_bytes() + b'\n# New pipeline caller revision\n')
    assert not patterns._orchestration_current(checkout, record)


def test_same_result_renderer_shows_integration_and_planned_checks(checkout):
    context = coding.orchestration_context(PACK, root=checkout)
    result = {'implementation_context': {'orchestration': context}, 'proposal': {'integration': integration(context)}}
    app = AppTest.from_string('import pattern_workspace_page as page\npage.integration_details(' + repr(result) + ')', default_timeout=30).run()
    assert not app.exception
    assert any('No pipeline' in caption.value for caption in app.caption)
    assert any('build_from_sources' in code.value for code in app.code)
    assert any('clinical.build' in frame.value['call'].tolist() for frame in app.dataframe if 'call' in frame.value)
