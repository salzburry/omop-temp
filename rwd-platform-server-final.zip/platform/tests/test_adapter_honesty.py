"""An adapter set must not pass offline and refuse at runtime, or carry fields nothing executes.

TWO DEFECTS OF ONE KIND. `source_adapter.py` states the standard itself, in the comment that
deleted the OMOP profile: "a capability claim the code did not honour, which is the one thing this
file exists to refuse." Both of these were that claim, printed.

THE TABLE DISAGREEMENT. `run_rwdp` refuses a run where the adapter and `cfg.sources` resolve one
role to different physical tables — one truth, fix whichever is wrong. `check()` never made that
comparison, so an adapter set redirecting every role elsewhere passed with ZERO problems, compiled
clean, was reported as an implementation by `semantic_view` and answered a competency question —
and only then refused at runtime, for nineteen roles. Offline evidence asserting an implementation
that can never run is worse than no evidence, because everything downstream reads `check()` as the
offline verdict.

THE SIGNED-BUT-DROPPED FIELDS. `compiled()` reads five keys. `vocabulary`, `units` and
`optional_columns` were emitted by `skeleton()` for a reviewer to fill, hashed into
`mapping_digest` so the signature covered them, and then dropped. The sharpest is `vocabulary`:
`engine/vocabularies.py` names it as the authority for whether NDC codes arrive 10- or 11-digit,
while `config.py` reads only `raw["vocabularies"]` — so a reviewer could answer that question in
the adapter and change nothing at all.

THE IRI SPLIT. Separately, `semantic_export` minted `concept/ecog_ps` from one path and
`concept/ecog-ps` from the other, for 29 of 37 master families, both declaring `skos:inScheme` the
SAME scheme. A graph asserting two identifiers for one concept, filed under one scheme, is worse
than one asserting neither.

NO PYTEST FIXTURES AND NO `parametrize` — CI runs every suite as a script.

Run: python3 tests/test_adapter_honesty.py (or pytest).
"""
import json
import os
import shutil
import sys
import tempfile
from pathlib import Path

FRAMEWORK = Path(__file__).resolve().parent.parent
REPO = FRAMEWORK.parent
sys.path.insert(0, str(FRAMEWORK / "tools"))
sys.path.insert(0, str(FRAMEWORK))

import semantic_export as se  # noqa: E402
import source_adapter as sa  # noqa: E402

PACK = REPO / "fixtures/oncology/prostate/202606"


def _pack_with_adapters(mutate, concrete=True):
    """A throwaway copy of the reference pack carrying a skeleton adapter set, mutated.

    `concrete` rewrites each adapter's `physical_table` to whatever `cfg.sources` resolves, so the
    two sides AGREE before the mutation. That is the state the comparison is about: the reference
    pack ships `REPLACE_ME` placeholders, and comparing a draft against a placeholder is a
    different (already reported) problem.
    """
    import yaml                                                          # noqa: PLC0415
    tmp = Path(tempfile.mkdtemp()) / "202606"
    shutil.copytree(str(PACK), str(tmp))
    text = sa.skeleton(str(tmp))
    path = tmp / "config" / "source_adapters.yaml"
    path.write_text(text, encoding="utf-8")
    doc = yaml.safe_load(path.read_text(encoding="utf-8"))
    if concrete:
        # BOTH SIDES, or the draft-guard in `check()` correctly skips the comparison. The pack's
        # own config resolves every role through `REPLACE_ME` placeholders, so the config side has
        # to become concrete too — otherwise this fixture proves only that the guard works.
        for cfgfile in sorted((tmp / "config").glob("*.yaml")):
            cfgfile.write_text(cfgfile.read_text(encoding="utf-8").replace("REPLACE_ME", "live"),
                               encoding="utf-8")
        cfg, _ev = sa._engine(str(tmp))
        for a in doc.get("adapters") or []:
            role = str(a.get("logical_role") or "")
            if role in cfg.sources:
                a["physical_table"] = str(cfg.table(role))
    mutate(doc)
    path.write_text(yaml.safe_dump(doc, sort_keys=False), encoding="utf-8")
    return str(tmp)


def _flagged(pack):
    return [p for p in sa.check(pack)["problems"] if "cfg.sources resolves" in p]


# --- the comparison the runtime already makes ----------------------------------------------------

def test_a_table_disagreement_is_refused_offline_not_only_at_runtime():
    def divert(doc):
        for a in doc.get("adapters") or []:
            t = str(a.get("physical_table") or "").strip()
            if t and t != "TODO":
                a["physical_table"] = "optum_mc.redirected_" + t.split(".")[-1]
    hits = _flagged(_pack_with_adapters(divert))
    assert hits, "check() no longer makes the comparison the runtime refuses on"
    assert len(hits) >= 10, f"only {len(hits)} role(s) flagged; the divergence was set on all"


def test_the_offline_message_names_both_sides():
    """A reviewer has to know WHICH of the two to fix; "they disagree" is not actionable."""
    def divert(doc):
        for a in doc.get("adapters") or []:
            t = str(a.get("physical_table") or "").strip()
            if t and t != "TODO":
                a["physical_table"] = "optum_mc.x"
                break
    hit = _flagged(_pack_with_adapters(divert))[0]
    assert "optum_mc.x" in hit and "One truth" in hit


def test_an_agreeing_adapter_is_not_flagged():
    """The check must not fire on the ordinary case, or it is noise nobody reads."""
    assert not _flagged(_pack_with_adapters(lambda doc: None))


def test_a_draft_is_not_compared_against_a_placeholder():
    """The reference pack's config still resolves to REPLACE_ME and the skeleton carries bare
    stems. Flagging all nineteen roles of an unconfigured pack would bury the one real divergence
    in noise, and both states already have their own checks."""
    assert not _flagged(_pack_with_adapters(lambda doc: None, concrete=False))


# --- fields nothing executes ---------------------------------------------------------------------

def test_the_skeleton_no_longer_offers_fields_the_run_drops():
    text = sa.skeleton(str(PACK))
    for dead in ("vocabulary:", "units:", "optional_columns:"):
        assert dead not in text, f"skeleton still invites a reviewer to fill `{dead}`"


def test_a_declared_but_unexecuted_field_is_refused():
    for dead, value in (("vocabulary", {"ndc": "ndc11"}),
                        ("units", {"weight": "kg"}),
                        ("optional_columns", ["extra"])):
        def mutate(doc, _d=dead, _v=value):
            (doc.get("adapters") or [{}])[0][_d] = _v
        got = sa.check(_pack_with_adapters(mutate))
        assert any(f"declares `{dead}`" in p for p in got["problems"]), (
            f"a populated `{dead}` is signed and dropped without a word")


def test_compiled_still_reads_exactly_the_five_executed_keys():
    """The refusal above is only honest while this stays true — if `compiled()` grows a reader for
    one of them, that field must stop being refused on the same commit."""
    src = (FRAMEWORK / "tools" / "source_adapter.py").read_text(encoding="utf-8")
    body = src.split("def compiled(", 1)[1]
    for key in ("logical_role", "physical_table", "required_columns", "grain", "join"):
        assert f'"{key}"' in body or f"'{key}'" in body, key
    for dead in ("vocabulary", "units", "optional_columns"):
        assert f'a.get("{dead}")' not in body, (
            f"`compiled()` now reads `{dead}` — stop refusing it")


# --- one concept, one identifier -----------------------------------------------------------------

def test_both_export_paths_mint_the_same_concept_iri():
    """29 of 37 masters diverged, both filed under the same scheme."""
    import yaml                                                          # noqa: PLC0415
    inv = yaml.safe_load((REPO / "governance/reference/variable_inventory/INVENTORY.yaml")
                         .read_text(encoding="utf-8"))
    names = [m["name"] for m in (inv.get("master") or []) if m.get("name")]
    assert names, "no master families to compare"
    diverged = [n for n in names
                if se._concept_iri("https://x", n, {}) != se._iri("https://x", "concept",
                                                                  se._slug(n))]
    assert not diverged, f"{len(diverged)} master(s) still mint two IRIs: {diverged[:5]}"


def test_the_template_path_honours_a_recorded_iri_rather_than_composing_one():
    """THE HALF THE IRI FIX MISSED. `_concept_iri` and the composing call agreed on their SLUG, but
    `template()` never called `_concept_iri` at all — it composed directly and never opened the
    lifecycle register. So the moment anyone recorded an enterprise IRI, `export()` would honour it
    and `template()` would mint a second identifier for the same concept under the same scheme:
    exactly the duplicate identity the register exists to prevent, on the one path that emits
    `rwdp:Definition` nodes. The register being empty is why it was invisible."""
    import yaml                                                          # noqa: PLC0415
    inv = yaml.safe_load((REPO / "governance/reference/variable_inventory/INVENTORY.yaml")
                         .read_text(encoding="utf-8"))
    name = next(m["name"] for m in (inv.get("master") or []) if m.get("name"))
    minted = "https://purl.example.org/def/rwd/Minted"
    real = se._lifecycle_index
    try:
        se._lifecycle_index = lambda: {name.lower(): {"name": name, "iri": minted}}
        doc, _report = se.template("prostate", "https://x")
        blob = json.dumps(doc)
    finally:
        se._lifecycle_index = real
    assert minted in blob, (
        f"the template composed its own IRI for {name} instead of the one a person recorded")
    assert f'"https://x/concept/{se._slug(name)}"' not in blob, (
        f"{name} carries BOTH a recorded IRI and a composed one — two identifiers, one concept")


def test_a_recorded_lifecycle_iri_still_wins():
    """The whole point of the lifecycle file's `iri:` column — composing a second identifier for a
    name someone already minted is the duplicate identity the mint-once rule exists to prevent."""
    life = {"ecog_ps": {"iri": "https://purl.example.org/def/rwd/EcogPs"}}
    assert se._concept_iri("https://x", "ECOG_PS", life) == \
        "https://purl.example.org/def/rwd/EcogPs"


# --- a status nobody recognises ------------------------------------------------------------------

def test_a_review_status_nobody_recognises_is_reported_not_silently_ignored():
    """THE THIRD DEFECT OF THE SAME KIND, and the one that caught its own author.

    Every review check in `check()` — the reviewer, the approval date, and the `approved_digest`
    that binds a signature to bytes — hung off `status == "reviewed"`. So an adapter set whose
    eight blocks all read `status: approved` did not fail those checks; it never reached them.
    `check()` returned ZERO problems and exit 0 for a file in which nothing had been signed and no
    digest had been compared, while `compiled()` refused the very same file. The tool a person RUNS
    and the loader that consumes the result disagreed, in the direction that reads as approval.

    `approved` is not an exotic typo. It is the word a reviewer reaches for.
    """
    def approve(doc):
        for a in doc.get("adapters") or []:
            a["review"] = {"status": "approved", "approved_by": "A Reviewer",
                           "approval_date": "2026-08-24", "approved_digest": "TBD"}
    said = [p for p in sa.check(_pack_with_adapters(approve))["problems"]
            if "review.status" in p]
    assert said, "an unrecognised review status was accepted in silence"
    assert "approved" in said[0] and "NOT reviewed" in said[0], said[0]


def test_the_status_the_skeleton_writes_is_not_itself_an_error():
    """The other half of a closed vocabulary: `pending` is what `skeleton()` emits, so flagging it
    would make every freshly generated adapter set report a defect on its first line. A check that
    fires on the tool's own output is noise, and noise is how a real finding gets scrolled past."""
    problems = sa.check(_pack_with_adapters(lambda doc: None))["problems"]
    assert not [p for p in problems if "review.status" in p], \
        [p for p in problems if "review.status" in p]


if __name__ == "__main__":
    # CI RUNS EVERY SUITE AS A SCRIPT — see the module docstring. Without this block the file runs
    # no tests and exits 0.
    bad = 0
    for _name, _fn in sorted(globals().items()):
        if _name.startswith("test_") and callable(_fn):
            try:
                _fn()
                print(f"  ok  {_name}")
            except Exception as _e:                  # noqa: BLE001 - report and continue
                bad += 1
                print(f"FAIL  {_name}: {_e}")
    sys.exit(1 if bad else 0)
