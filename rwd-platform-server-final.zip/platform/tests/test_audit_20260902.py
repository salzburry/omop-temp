"""Regressions for the 2026-09-02 external audit: each test FAILS on the defect it names and passes
on the fix — the claims discipline (a check that never failed proves nothing).

  P1  malformed study dates passed strict validation (compared as strings, never parsed)
  P1  refresh/build identifiers reached filesystem paths and SQL identifiers unchecked — a
      refresh of `../../../../governance/publish_targets` validated and resolved outside refreshes/
  P2  the golden gate passed an EMPTY reference (ref=0 -> "can't compute" -> silence), a NaN
      threshold, and crashed on a string threshold
  P2  `request_record.py --digest` raised UnboundLocalError on every call (a later branch-local
      import shadowed `pg`); the function was tested, the documented CLI path was not
  P2  the agent registry guarded its write boundary with `assert`, which `python -O` deletes

The null-first ordering fix in clinical.py / stages.R needs Spark and is covered by the Spark
UAT + stage-conformance lanes in CI, not here; this file says so rather than faking a check.

NO PYTEST FIXTURES AND NO `parametrize` — CI runs every suite as a script.
"""
import copy
import math
import os
import subprocess
import sys
from pathlib import Path

FRAMEWORK = Path(__file__).resolve().parent.parent
ROOT = FRAMEWORK.parent
sys.path.insert(0, str(FRAMEWORK))
sys.path.insert(0, str(FRAMEWORK / "tools"))

from engine.config import load_config, product_config  # noqa: E402
from engine import validate, refresh, golden  # noqa: E402

CONFIG = product_config(ROOT / "fixtures", "prostate")


def _cfg_with_study(**over):
    cfg = load_config(CONFIG)
    cfg = copy.deepcopy(cfg)
    cfg.study.update(over)
    return cfg


# ---------------------------------------------------------------- P1: study dates must parse

def test_banana_date_is_refused_strict_and_lint():
    for strict in (True, False):
        probs = validate.problems(_cfg_with_study(index_start="banana-date"), strict=strict)
        assert any("index_start" in p and "ISO date" in p for p in probs), (strict, probs)


def test_every_study_date_field_is_parsed():
    for k in ("index_end", "index_period_start", "index_period_end", "observation_end",
              "data_cutoff"):
        probs = validate.problems(_cfg_with_study(**{k: "2025-13-45"}), strict=True)
        assert any(k in p and "ISO date" in p for p in probs), (k, probs)


def test_bad_date_does_not_hide_other_problems():
    # one bad field must never suppress the rest of the validator
    cfg = _cfg_with_study(index_start="banana-date")
    cfg.run["source_schema"] = ""
    probs = validate.problems(cfg, strict=True)
    assert any("run.source_schema" in p for p in probs), probs


def test_real_iso_dates_still_pass():
    assert not [p for p in validate.problems(load_config(CONFIG), strict=False)
                if "ISO date" in p]


# ---------------------------------------------------------------- P1: identifier grammar

def _manifest(**over):
    m = {"tumor": "prostate", "refresh": "2026m06", "spec_version": "202606",
         "built_at": "2026-09-02T00:00:00Z", "status": "qc_pending", "counts": {"n": 1},
         "family": "oncology"}
    m.update(over)
    return m


def test_traversal_refresh_is_refused():
    probs = refresh.validate_manifest(_manifest(refresh="../../../../governance/publish_targets"))
    assert any("refresh" in p and "not a safe" in p for p in probs), probs


def test_every_path_segment_has_the_grammar():
    for k in ("tumor", "spec_version", "family", "build_id"):
        for bad in ("a/b", "a\\b", "..", "x..y", "", " a", "a" * 65):
            if bad == "":
                continue
            probs = refresh.validate_manifest(_manifest(**{k: bad}))
            assert any(k in p and "not a safe" in p for p in probs), (k, bad, probs)


def test_manifest_path_stays_inside_refreshes_for_valid_ids():
    # SQL-safe: refresh and build_id land in unquoted table names, so no '.' or '-' (second audit)
    m = _manifest(refresh="2026m06_rerun2", build_id="b_1")
    assert not [p for p in refresh.validate_manifest(m) if "not a safe" in p]
    root = Path("C:/tmp/root") if os.name == "nt" else Path("/tmp/root")
    p = refresh.manifest_path(m, root).resolve()
    assert str(p).startswith(str((root / "refreshes").resolve())), p


# ---------------------------------------------------------------- P2: golden gate inputs

def test_empty_reference_fails_the_gate():
    r = golden.golden_gate({"n_rows": {"new": 100, "ref": 0}})
    assert not r["passed"] and any("reference ADS" in f for f in r["failures"]), r


def test_nan_threshold_fails_not_passes():
    r = golden.golden_gate({"n_rows": {"new": 200, "ref": 100}},
                           {"max_row_delta_pct": float("nan")})
    assert not r["passed"] and any("not a finite number" in f for f in r["failures"]), r


def test_string_threshold_is_a_failure_not_a_traceback():
    r = golden.golden_gate({"n_rows": {"new": 100, "ref": 100}}, {"max_row_delta_pct": "10"})
    assert not r["passed"] and any("max_row_delta_pct" in f for f in r["failures"]), r


def test_no_reference_configured_is_still_the_one_legitimate_skip():
    r = golden.golden_gate(None)
    assert r["passed"] and r.get("skipped")


def test_healthy_summary_still_passes():
    r = golden.golden_gate({"n_rows": {"new": 101, "ref": 100}})
    assert r["passed"], r
    assert not math.isnan(golden._abs_pct(101, 100))


# ---------------------------------------------------------------- P2: the digest CLI runs

def test_request_record_digest_cli_refuses_cleanly():
    r = subprocess.run([sys.executable, str(FRAMEWORK / "tools" / "request_record.py"),
                        "--digest", "does-not-exist"],
                       capture_output=True, text=True, cwd=str(ROOT), encoding="utf-8",
                       errors="replace", timeout=120)
    assert "UnboundLocalError" not in (r.stderr or "") + (r.stdout or ""), r.stderr[-800:]
    assert r.returncode == 1 and "REFUSED" in (r.stderr or "") + (r.stdout or ""), \
        (r.returncode, (r.stderr or "")[-400:])


# ---------------------------------------------------------------- P2: no assert at a boundary

def test_agent_write_boundary_survives_optimize_flag():
    src = (ROOT / "experiments" / "agent" / "tools.py").read_text(encoding="utf-8")
    body = src[src.index("def registry("):src.index("def call(")]
    import re
    assert not re.search(r"^\s*assert\b", body, re.M), \
        "the write-shaped-word guard must raise, not assert"
    assert "raise RuntimeError" in body


def test_coding_agent_fingerprint_regexes_carry_no_control_characters():
    src = (ROOT / "experiments" / "agent" / "coding_agent.py").read_bytes()
    assert b"\x08" not in src, "literal backspace where a regex word boundary was meant"


if __name__ == "__main__":
    fails = 0
    for name, fn in sorted(globals().items()):
        if name.startswith("test_") and callable(fn):
            try:
                fn()
                print(f"  ok   {name}")
            except Exception as e:  # noqa: BLE001
                fails += 1
                print(f"  FAIL {name}: {e}")
    print(f"{fails} failure(s)")
    sys.exit(1 if fails else 0)
