"""Explicit treatment settings and reviewed-table bindings stay inside proposals."""
from copy import deepcopy
import hashlib
import json
from pathlib import Path
import shutil
import sys
from types import SimpleNamespace
from unittest.mock import MagicMock, patch

import pytest
import yaml
from streamlit.testing.v1 import AppTest

ROOT = Path(__file__).resolve().parents[2]
sys.path[:0] = [str(ROOT / "experiments/portal"), str(ROOT / "platform/tools"), str(ROOT / "platform/tests"), str(ROOT / "platform")]
from test_epi_configuration_proposals import seed, stage, brief, original_bytes, open_proposal, action, PACK, ACTOR, PASSING
import configuration_proposals as cp
import variable_review_workflow as workflow

MAX_LINES = "variables/treatment.yaml#/max_lines"
NUMBERING = cp.LOT_NUMBERING_REF


@pytest.mark.parametrize("text", [
    "# keep header\nname: example # keep name\nother: {a: 1}\n",
    "---\nname: example\n# keep tail\n...\n",
    "{name: example, other: [a, b]}",
    "{name: example, }",
    "name: example\nlot:\n  # keep filter note\n  line_setting: mCRPC # keep filter\nother: value\n",
    "name: example\nlot: {} # keep empty note\n",
    "name: example\nlot: {line_setting: mCRPC} # keep flow note\n",
    "name: example\nlot: {line_setting: mCRPC, # keep trailing comma\n}\n",
    "name: example\r\nlot:\r\n  line_setting: mCRPC # keep windows ending\r\n",
])
def test_missing_numbering_is_explicitly_inserted_preserving_other_yaml(tmp_path, text):
    product = seed(tmp_path)
    config = product / "config/data_product.yaml"
    config.write_bytes(text.encode())
    original = yaml.safe_load(text)
    assert cp.supported_parameters(tmp_path, PACK)[NUMBERING] == (
        "Treatment line numbering", "lot_numbering", "new_lot_n")
    files, handoff = cp._compose(product, [{"ref": NUMBERING, "value": "linenumber"}])
    assert not handoff and len(files) == 1
    after = files[0]["after"]
    expected = deepcopy(original)
    expected.setdefault("lot", {})["line_number"] = "linenumber"
    assert yaml.safe_load(after) == expected
    # The patch only inserts bytes. All existing comments and spelling survive.
    iterator = iter(after)
    assert all(any(char == next_char for next_char in iterator) for char in text)
    assert config.read_bytes() == text.encode()


def test_default_numbering_can_be_explicitly_declared_and_existing_values_replaced(tmp_path):
    product = seed(tmp_path)
    config = product / "config/data_product.yaml"
    text = "name: fixture\nlot: {line_setting: mCRPC}\n"
    config.write_text(text, encoding="utf-8")
    files, _ = cp._compose(product, [{"ref": NUMBERING, "value": "new_lot_n"}])
    assert files and yaml.safe_load(files[0]["after"])["lot"]["line_number"] == "new_lot_n"
    config.write_text(files[0]["after"], encoding="utf-8")
    files, _ = cp._compose(product, [{"ref": NUMBERING, "value": "linenumber"}, {"ref": MAX_LINES, "value": 12}])
    after = {row["path"]: yaml.safe_load(row["after"]) for row in files}
    assert after["config/data_product.yaml"]["lot"] == {"line_setting": "mCRPC", "line_number": "linenumber"}
    assert after["variables/treatment.yaml"]["max_lines"] == 12


@pytest.mark.parametrize("text", [
    "lot: null\n", "lot: []\n", "lot: wrong\n", "lot: {line_number: []}\n",
    "lot: {line_number: null}\n", "lot: {line_number: linenumber, line_number: new_lot_n}\n",
    "other: &shared {line_setting: mCRPC}\nlot: *shared\n", "lot: &recursive {copy: *recursive}\n",
    "&anchored\nlot: {}\n",
    "lot: {line_number: linenumber}\nlot: {}\n", "[not, a, mapping]\n", "lot: [\n",
])
def test_malformed_or_aliased_numbering_is_a_repair_error(tmp_path, text):
    product = seed(tmp_path)
    config = product / "config/data_product.yaml"
    config.write_text(text, encoding="utf-8")
    before = config.read_bytes()
    with pytest.raises(cp.Invalid, match="Repair config/data_product.yaml"):
        cp.supported_parameters(tmp_path, PACK)
    assert config.read_bytes() == before


@pytest.mark.parametrize("value", [0, -1, True, False, "2", 2.0, None])
def test_maximum_line_requires_a_positive_integer(value):
    with pytest.raises(cp.Invalid, match="positive whole number"):
        cp._value(MAX_LINES, value)


@pytest.mark.parametrize("value", ["lot_number", "new_lot_n ", "linenumber2", 1, None, True])
def test_numbering_requires_an_engine_supported_enum(value):
    with pytest.raises(cp.Invalid, match="linenumber or new_lot_n"):
        cp._value(NUMBERING, value)


def test_positive_maximum_has_no_invented_ceiling_and_missing_other_settings_are_not_inserted(tmp_path):
    product = seed(tmp_path)
    assert cp._value(MAX_LINES, 1000) == 1000
    (product / "variables/treatment.yaml").write_text("name: treatment\n", encoding="utf-8")
    files, handoff = cp._compose(product, [{"ref": MAX_LINES, "value": 4}])
    assert not files and handoff[0]["kind"] == "unsupported_configuration"


def _bound(root, monkeypatch, *, complete=True, blockers=None):
    product = seed(root)
    path = product / workflow.STORE
    path.parent.mkdir(parents=True)
    path.write_text("{}", encoding="utf-8")
    binding = {"input_digest": workflow._input_digest(root, product),
               "state_digest": workflow.definitions._hash(path.read_bytes())}
    values = yaml.safe_load(workflow.definitions.cs.judgment_stub("LOT1DATE"))
    values.update(derivation="Return the start date of the selected treatment line.",
        source={"kind": "vendor", "logical_table": "lot", "physical_stem": "t_lot", "columns": {"startdate": "startdate"}},
        output={"physical_name": "lot1date", "target_published_name": "LOT1DATE", "type": "date"})
    rows = [{"item_id": "clinical:3", "variable_id": "LOT1DATE", "definition": "Requested treatment-line date.",
        "spec_values": {"definition": "Requested treatment-line date.", "values": "A date"}, "values": values,
        "family": {"name": "treatment_line", "line_number": 1, "attribute": "start_date", "numbering": "linenumber"},
        "master_name": "LINE_OF_THERAPY", "logic_reviewed": True,
        "actor_id": "runtime-reviewer@example.test", "draft_path": str(path)}]
    report = {"ok": True, "current_phase": "complete" if complete else "source", "rows": rows, **binding}
    monkeypatch.setattr(workflow, "describe", lambda *_args, **_kwargs: deepcopy(report))
    compiled = {"configuration_changes": [{"ref": MAX_LINES, "value": 8}], "blockers": blockers or []}
    monkeypatch.setitem(sys.modules, "variable_execution_rules", SimpleNamespace(build=lambda *_args: deepcopy(compiled)))
    return product, binding, report, compiled


def test_bound_stage_rechecks_complete_tables_and_keeps_review_work_in_the_packet(tmp_path, monkeypatch):
    blockers = [{"item_id": "clinical:3", "variable_id": "LOT1DATE", "message": "Custom output still needs implementation."}]
    product, binding, report, compiled = _bound(tmp_path, monkeypatch, blockers=blockers)
    before = original_bytes(tmp_path)
    result = stage(tmp_path, changes=compiled["configuration_changes"], variable_review_binding=binding)
    assert result["ok"] and not result["stale"], result
    assert result["proposal"]["variable_review_binding"] == binding
    pending = result["proposal"]["engineering_handoff"]
    assert pending == [{"kind": "reviewed_definition", "item_id": "clinical:3", "variable_id": "LOT1DATE",
        "reason": blockers[0]["message"], "required_work": "Resolve this variable in the reviewed tables or provide a reviewed implementation, then prepare a fresh configuration proposal."}]
    monkeypatch.setattr(cp, "_run_validators", lambda *_args: deepcopy(PASSING))
    checked = action("validate", tmp_path, result)
    assert checked["ok"] and not checked["passed"], checked
    assert any("Engineering handoff remains unresolved" in error for error in checked["errors"])
    assert original_bytes(tmp_path) == before
    assert cp._check_shared(cp.share_preview(tmp_path, PACK, proposal_id=result["proposal_id"], actor_id=ACTOR,
        allowed_packs=[PACK])["packet"], PACK)["proposal"]["engineering_handoff"] == pending


@pytest.mark.parametrize("mutation", ["shared_review", "master_library", "source_config"])
def test_saved_bound_proposal_becomes_stale_when_review_or_inputs_change(tmp_path, monkeypatch, mutation):
    product, binding, report, compiled = _bound(tmp_path, monkeypatch)
    result = stage(tmp_path, changes=compiled["configuration_changes"], variable_review_binding=binding)
    assert result["ok"] and not result["stale"], result
    if mutation == "shared_review":
        (product / workflow.STORE).write_text('{"new_review": true}', encoding="utf-8")
    elif mutation == "master_library":
        path = tmp_path / workflow.library.SUPPLEMENT
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text("templates: []\n", encoding="utf-8")
    else:
        path = product / "config/data_product.yaml"
        path.write_text(path.read_text(encoding="utf-8") + "# source configuration changed\n", encoding="utf-8")
    opened = open_proposal(tmp_path, result)
    assert opened["ok"] and opened["stale"] and not opened["can_submit"], opened
    assert not action("validate", tmp_path, result)["ok"]


@pytest.mark.parametrize("scenario", ["incomplete", "wrong_changes", "wrong_state", "malformed_binding", "changed_during_stage"])
def test_invalid_or_changed_review_binding_never_publishes_a_proposal(tmp_path, monkeypatch, scenario):
    product, binding, report, compiled = _bound(tmp_path, monkeypatch, complete=scenario != "incomplete")
    changes = compiled["configuration_changes"]
    if scenario == "wrong_changes":
        changes = [{"ref": MAX_LINES, "value": 9}]
    elif scenario == "wrong_state":
        binding["state_digest"] = "a" * 64
    elif scenario == "malformed_binding":
        binding["path"] = "elsewhere.json"
    elif scenario == "changed_during_stage":
        original = workflow.describe
        calls = []
        def describe(*args, **kwargs):
            calls.append(1)
            current = original(*args, **kwargs)
            if len(calls) > 1:
                current["state_digest"] = "a" * 64
            return current
        monkeypatch.setattr(workflow, "describe", describe)
    result = stage(tmp_path, changes=changes, variable_review_binding=binding)
    assert not result["ok"], result
    listing = cp.list_proposals(tmp_path, PACK, actor_id=ACTOR, allowed_packs=[PACK])
    assert listing["ok"] and not listing["proposals"], listing
    assert not list((product / ".portal-drafts").rglob(".staging-*"))


def test_reviewed_snapshot_is_exact_and_reopens_on_a_branch_without_private_review_files(tmp_path, monkeypatch):
    origin = tmp_path / "origin"
    origin.mkdir()
    product, binding, report, compiled = _bound(origin, monkeypatch)
    second = deepcopy(report["rows"][0])
    second.update(item_id="clinical:4", variable_id="LOT2DATE")
    second["values"]["variable_id"] = "LOT2DATE"
    second["family"]["line_number"] = 2
    report["rows"].append(second)
    staged = stage(origin, changes=compiled["configuration_changes"], variable_review_binding=binding)
    assert staged["ok"], staged
    records = staged["proposal"]["variable_review_records"]
    assert records == [{key: row[key] for key in cp.REVIEW_RECORD_FIELDS} for row in report["rows"]]
    serialized = json.dumps(records)
    assert "runtime-reviewer" not in serialized and str(product / workflow.STORE) not in serialized
    assert "draft_path" not in serialized and "actor_id" not in serialized
    preview = cp.share_preview(origin, PACK, proposal_id=staged["proposal_id"], actor_id=ACTOR, allowed_packs=[PACK])
    assert preview["ok"], preview
    shared = cp.share(origin, PACK, proposal_id=staged["proposal_id"], actor_id=ACTOR, allowed_packs=[PACK],
        expected_digest=preview["digest"], local_demo=True, can_write=True, confirmed=True)
    assert shared["ok"], shared
    branch = tmp_path / "branch"
    shutil.copytree(origin, branch, ignore=shutil.ignore_patterns(".portal-drafts"))
    assert not list(branch.rglob(".portal-drafts"))
    reopened = cp.load_shared(branch, PACK, packet_id=shared["packet_id"], actor_id="engineer", allowed_packs=[PACK])
    assert reopened["ok"], reopened
    assert reopened["packet"]["proposal"]["variable_review_records"] == records
    assert "Historical" in reopened["notice"] or "historical" in reopened["notice"]
    assert not reopened["packet"]["proposal"]["approved"]


def test_reviewed_snapshot_is_rechecked_before_validation(tmp_path, monkeypatch):
    product, binding, report, compiled = _bound(tmp_path, monkeypatch)
    staged = stage(tmp_path, changes=compiled["configuration_changes"], variable_review_binding=binding)
    assert staged["ok"], staged
    # A substituted report with unchanged digest fields must not replace the
    # requirement stored in this exact proposal during validation.
    report["rows"][0]["values"]["output"]["physical_name"] = "another_column"
    checked = action("validate", tmp_path, staged)
    assert not checked["ok"] and "staged variable definitions differ" in checked["errors"][0], checked
    assert open_proposal(tmp_path, staged)["proposal"]["variable_review_records"][0]["values"]["output"]["physical_name"] == "lot1date"


@pytest.mark.parametrize("change", ["extra_authority", "duplicate", "wrong_identifier", "unstructured_source", "missing", "too_deep", "oversized"])
def test_shared_ingress_rejects_malformed_reviewed_snapshots(tmp_path, monkeypatch, change):
    product, binding, report, compiled = _bound(tmp_path, monkeypatch)
    proposal = {"variable_review_binding": binding, "variable_review_records": cp._review_records(report)}
    rows = proposal["variable_review_records"]
    if change == "extra_authority":
        rows[0]["approved"] = True
    elif change == "duplicate":
        rows.append(deepcopy(rows[0]))
    elif change == "wrong_identifier":
        rows[0]["variable_id"] = "ANOTHER_VARIABLE"
    elif change == "unstructured_source":
        rows[0]["values"]["source"] = "look elsewhere"
    elif change == "missing":
        proposal.pop("variable_review_records")
    elif change == "too_deep":
        value = "nested"
        for _ in range(10):
            value = {"nested": value}
        rows[0]["spec_values"]["nested"] = value
    else:
        rows[0]["definition"] = "x" * 65537
    with pytest.raises(ValueError):
        cp._check_review_records(proposal)


def test_reviewed_definitions_panel_is_lazy_and_preserves_requested_names_and_source(tmp_path, monkeypatch):
    import configuration_proposal_page as page
    _product, _binding, report, _compiled = _bound(tmp_path, monkeypatch)
    proposal = {"proposal_id": "a" * 32, "variable_review_records": cp._review_records(report)}
    panel = MagicMock()
    panel.open = False
    with patch.object(page.st, "expander", return_value=panel), patch.object(page.st, "dataframe") as table:
        page._reviewed_definitions(proposal, "context")
        table.assert_not_called()
    panel.open = True
    with patch.object(page.st, "expander", return_value=panel), patch.object(page.st, "dataframe") as table, \
            patch.object(page.st, "selectbox", return_value="clinical:3"), patch.object(page.st, "caption"), \
            patch.object(page.st, "write"), patch.object(page.st, "json") as details:
        page._reviewed_definitions(proposal, "context")
        assert table.call_args.args[0][0]["Physical column"] == "lot1date"
        assert table.call_args.args[0][0]["Published name"] == "LOT1DATE"
        assert table.call_args.args[0][0]["Reviewed logic"] == report["rows"][0]["values"]["derivation"]
        assert details.call_args.args[0]["Source mapping"] == report["rows"][0]["values"]["source"]
        assert details.call_args.args[0]["Family choices"] == report["rows"][0]["family"]


def test_new_treatment_controls_stage_typed_values_and_leave_live_files_untouched(tmp_path):
    product = seed(tmp_path)
    before = original_bytes(tmp_path)
    plan = brief(tmp_path)
    script = f"""
import sys
sys.path.insert(0, {str(ROOT / 'experiments/portal')!r})
import configuration_proposal_page
configuration_proposal_page.render({str(tmp_path)!r}, {PACK!r}, {plan!r}, expected_baseline={plan['baseline_sha256']!r},
    actor_id={ACTOR!r}, local_demo=True, can_write=True, allowed_packs={[PACK]!r})
"""
    at = AppTest.from_string(script, default_timeout=45).run()
    assert not at.exception
    prefix = f"design_{PACK}_proposal_"
    keys = {ref: prefix + hashlib.sha256(ref.encode()).hexdigest()[:12] for ref in (MAX_LINES, NUMBERING)}
    at.checkbox(key=keys[MAX_LINES] + "_change").check()
    at.checkbox(key=keys[NUMBERING] + "_change").check().run()
    at.number_input(key=keys[MAX_LINES] + "_value").set_value(8)
    at.selectbox(key=keys[NUMBERING] + "_value").set_value("linenumber").run()
    assert not at.exception
    at.button(key=f"configuration_stage_{PACK}").click().run()
    assert not at.exception, [error.message for error in at.exception]
    listing = cp.list_proposals(tmp_path, PACK, actor_id=ACTOR, allowed_packs=[PACK])
    opened = cp.load(tmp_path, PACK, proposal_id=listing["proposals"][0]["proposal_id"], actor_id=ACTOR, allowed_packs=[PACK])
    assert opened["proposal"]["configuration_changes"] == [{"ref": MAX_LINES, "value": 8}, {"ref": NUMBERING, "value": "linenumber"}]
    assert "variable_review_binding" not in opened["proposal"]
    assert original_bytes(tmp_path) == before
