"""Adversarial review-plan journeys; run with Python, no Streamlit server required."""
import copy
import hashlib
import json
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "experiments" / "portal"))
import design_workspace as dw  # noqa: E402


def baseline():
    return {"pack": "products/oncology/example/202609", "name": "Example",
            "is_reference": False, "contract_sha256": "a" * 64, "baseline_sha256": "b" * 64,
            "source": {"vendor": "flatiron", "modality": "ehr"}, "errors": [], "warnings": [],
            "rows": [{"variable_id": "INDEXDT", "domain": "study_period", "definition": "Index date", "depends_on": []},
                     {"variable_id": "AGE", "domain": "demographics", "definition": "Age at index", "depends_on": ["INDEXDT"]},
                     {"variable_id": "OS", "domain": "outcomes", "definition": "Overall survival", "depends_on": ["INDEXDT", "engine:outcomes"]}]}


def plan(desc=None, kept=None, additions=None, **kw):
    desc = baseline() if desc is None else desc
    return dw.build_plan(desc, [r["variable_id"] for r in desc["rows"]] if kept is None else kept,
                         additions or [], kw.get("purpose", "Support two studies"),
                         kw.get("studies", ["treatment patterns", "outcomes"]),
                         kw.get("source", "flatiron"), kw.get("modality", "ehr"))


def test_new_product_can_propose_definitions_without_claiming_an_analysis():
    desc = baseline()
    desc["rows"] = []
    p = plan(desc, additions=[{"variable_id": "POP", "domain": "study_population", "definition": "Scientist's proposed population; threshold unresolved"}])
    assert p["valid"] and p["classification"] == "additive" and p["draft_only"]
    assert len(p["studies"]) == 2 and not p["kept"]
    assert any("does not alter" in warning for warning in p["warnings"])


def test_template_reuse_retains_literal_text_and_never_mutates_parent():
    desc = baseline()
    desc["is_reference"] = True
    desc["warnings"] = ["Reference material is never clinical approval or releasable evidence."]
    before = copy.deepcopy(desc)
    definition = "  Biomarker evidence as stated\nUnknown remains unknown <script>literal text</script>  "
    p = plan(desc, additions=[{"variable_id": "BIOMARKER", "domain": "clinical", "definition": definition}])
    assert p["valid"] and p["classification"] == "additive"
    assert p["added"][0]["definition"] == definition and desc == before
    assert json.loads(json.dumps(p))["added"][0]["definition"] == definition
    assert p["is_reference"] and any("never clinical approval" in warning for warning in p["warnings"])


def test_valid_section_removal_is_breaking_and_dependency_removal_is_refused():
    p = plan(kept=["INDEXDT", "AGE"])
    assert p["valid"] and p["removed"] == ["OS"] and p["classification"] == "breaking"
    q = plan(kept=["AGE", "OS"])
    assert not q["valid"] and q["kept"] == ["AGE", "OS"]
    assert q["dependency_conflicts"] == [{"variable_id": "AGE", "missing_dependencies": ["INDEXDT"]},
                                          {"variable_id": "OS", "missing_dependencies": ["INDEXDT"]}]
    assert "INDEXDT" not in q["kept"]  # never silently repair the scientist's selection


def test_switching_to_claims_requires_source_evidence_and_preserves_the_original():
    desc = baseline()
    original = copy.deepcopy(desc)
    p = plan(desc, source="optum", modality="claims")
    assert p["valid"] and p["source_changed"] and p["classification"] == "breaking"
    assert p["source"]["current"] == original["source"] and desc == original
    checklist = " ".join(p["review_checklist"]).lower()
    for word in ("live schema", "mapping", "attrition", "nulls", "outcome", "censoring", "approvals"):
        assert word in checklist, word


def test_bad_inputs_return_actionable_errors_without_false_success():
    assert not plan()["valid"] and plan()["classification"] == "none"
    cases = [plan(kept=["MISSING"]), plan(kept=["AGE", "AGE"]), plan(kept=[]),
             plan(source="other", purpose=" "), plan(source="other", modality="registry"),
             plan(source=" "), plan(source="other", modality=" "),
             plan(source="other", studies=["A", "A"]),
             plan(additions=[{"variable_id": "AGE", "domain": "clinical", "definition": "Changed silently"}]),
             plan(additions=[{"variable_id": "age", "domain": "clinical", "definition": "Changed silently"}]),
             plan(additions=[{"variable_id": "X", "domain": "clinical", "definition": "one"},
                             {"variable_id": "x", "domain": "clinical", "definition": "two"}]),
             plan(additions=[{"variable_id": "X", "domain": "", "definition": " "}]),
             plan(additions=[None])]
    assert all(not p["valid"] and p["errors"] and p["draft_only"] for p in cases)


def test_actual_contract_uses_canonical_parser_and_source_identity():
    desc = dw.describe(ROOT, "fixtures/oncology/prostate/202606")
    assert not desc["errors"], desc["errors"]
    assert len(desc["rows"]) > 100 and desc["is_reference"]
    bmi = next(row for row in desc["rows"] if row["variable_id"] == "BMI")
    assert bmi["domain"] == "clinical" and bmi["depends_on"] == ["WEIGHT", "HEIGHT"]
    assert "BMI=WEIGHT_KG/(HEIGHT/100)^2" in bmi["definition"]
    assert desc["source"] == {"vendor": "flatiron", "modality": "ehr"}
    assert desc["source_tables"]["enhanced"] == "t_enh_prostate"
    p = plan(desc, source="optum", modality="claims")
    assert p["source_tables"] == desc["source_tables"]
    assert any("declared contract identifiers only" in w for w in p["warnings"])


def test_external_dependencies_are_exposed_without_inventing_a_contract_record():
    desc = baseline()
    desc["rows"][0]["depends_on"] = ["SPEC_ONLY", "engine:prepare"]
    p = plan(desc, source="other")
    assert p["valid"] and p["external_dependencies"] == ["SPEC_ONLY", "engine:outcomes", "engine:prepare"]
    assert any("outside this contract" in w for w in p["warnings"])


def test_missing_or_unanswered_dependencies_are_visible_as_incomplete_metadata():
    with tempfile.TemporaryDirectory(prefix="epi-dependencies-") as tmp:
        pack = Path(tmp) / "products/oncology/draft/202609"
        (pack / "config").mkdir(parents=True)
        (pack / "handoff").mkdir()
        (pack / "config/data_product.yaml").write_text("vendor: flatiron\n", encoding="utf-8")
        contract = pack / "handoff/FUNCTIONAL_CONTRACT.md"
        for dependency in ("", "depends_on: TODO\n"):
            contract.write_text("```yaml\nvariable_id: POP\nspec_refs: [study_population:1]\nrequired_rule: Draft population\n" + dependency + "```\n", encoding="utf-8")
            desc = dw.describe(tmp, "products/oncology/draft/202609")
            assert not desc["errors"] and desc["rows"]
            assert not desc["rows"][0]["dependencies_declared"]
            assert any("Dependency metadata is missing for: POP" in warning for warning in desc["warnings"])


def test_new_empty_pack_and_staleness_after_source_or_contract_changes():
    with tempfile.TemporaryDirectory(prefix="epi-design-") as tmp:
        root = Path(tmp)
        pack = root / "products/oncology/new/202609"
        (pack / "config").mkdir(parents=True)
        cfg = pack / "config/data_product.yaml"
        cfg.write_text("name: New\nvendor: flatiron\n", encoding="utf-8")
        desc = dw.describe(root, "products/oncology/new/202609")
        assert not desc["errors"] and desc["rows"] == [] and desc["baseline_sha256"]
        before = hashlib.sha256(cfg.read_bytes()).hexdigest()
        p = plan(desc, additions=[{"variable_id": "POP", "domain": "study_population", "definition": "Draft"}])
        assert p["valid"] and before == hashlib.sha256(cfg.read_bytes()).hexdigest()
        cfg.write_text("name: New\nvendor: optum\n", encoding="utf-8")
        changed = dw.describe(root, "products/oncology/new/202609")
        assert changed["baseline_sha256"] != p["baseline_sha256"]
        (pack / "handoff").mkdir()
        (pack / "handoff/FUNCTIONAL_CONTRACT.md").write_text("# Draft contract\n", encoding="utf-8")
        revised = dw.describe(root, "products/oncology/new/202609")
        assert revised["contract_sha256"] and revised["baseline_sha256"] != changed["baseline_sha256"]


def test_bad_pack_missing_config_and_corrupt_yaml_render_errors():
    assert dw.describe(ROOT, "../../outside")["errors"]
    assert dw.describe(ROOT, "missing-pack")["errors"]
    with tempfile.TemporaryDirectory(prefix="epi-design-") as tmp:
        pack = Path(tmp) / "products/oncology/broken/202609"
        (pack / "config").mkdir(parents=True)
        assert dw.describe(tmp, "products/oncology/broken/202609")["errors"]
        (pack / "config/data_product.yaml").write_text("vendor: [broken", encoding="utf-8")
        assert dw.describe(tmp, "products/oncology/broken/202609")["errors"]


if __name__ == "__main__":
    failed = 0
    for name, fn in sorted(globals().copy().items()):
        if name.startswith("test_") and callable(fn):
            try:
                fn()
                print(f"  ok   {name}")
            except Exception as exc:  # noqa: BLE001
                failed += 1
                print(f"  FAIL {name}: {type(exc).__name__}: {exc}")
    print(f"{failed} failure(s)")
    sys.exit(bool(failed))
