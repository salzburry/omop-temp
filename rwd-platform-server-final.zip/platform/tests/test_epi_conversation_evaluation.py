"""Real guide/intake/form/scorer journeys with a finite scripted provider."""
import copy
import json
from pathlib import Path
import shutil
import sys
from types import SimpleNamespace

import pytest
import yaml

ROOT = Path(__file__).resolve().parents[2]
sys.path[:0] = [str(ROOT / p) for p in ('experiments/portal', 'experiments/agent', 'platform/tools')]
import conversation_evaluation as evaluation
import conversation_intake as intake
import portal_jobs

ACTOR = 'conversation-test-reviewer'
PACK = 'fixtures/oncology/synthetic/202606'
CONNECTION = {'ok': True, 'provider': 'Scripted VS Code connection', 'provider_id': 'vscode',
    'model': 'gpt-5-mini', 'connection_id': 'a' * 64, 'help': 'Scripted tests only', 'errors': []}


class Scripted:
    def __init__(self, mode=None):
        self.calls = []
        self.mode = mode

    def step(self, system, messages):
        context = json.loads(messages[0]['content'])
        self.calls.append(context)
        case = next(c for c in evaluation._cases() if c['title'] == context['context']['current_task']['title'])
        index = sum(c['context']['current_task']['title'] == case['title'] for c in self.calls) - 1
        current = context['study_brief']['active_question']
        reply = {'answer': 'The exact source codes and mapping evidence are missing. Keep unresolved choices for review.', 'actions': []}
        if self.mode == 'malformed':
            return '{"answer":'
        if index in (0, 1):
            slot = case['question_slot'] if index == 0 else ('outcomes' if case['question_slot'] != 'outcomes' else 'exclusions')
            if self.mode == 'wrong_question_slot' and index == 0:
                slot = 'index_definition' if case['question_slot'] == 'inclusion_sequence' else 'outcomes'
            reply['questions'] = [{'id': slot, 'prompt': 'Which scientific interpretation should the draft use?',
                'options': [{'id': 'a', 'label': 'Use recorded observations', 'explanation': 'Needs a source mapping.'},
                            {'id': 'b', 'label': 'Use a reviewed derived definition', 'explanation': 'Needs declared dependencies.'}], 'allow_text': True}]
            if self.mode == 'semantic_option_ids':
                reply['questions'][0]['options'][0]['id'] = 'recorded'
                reply['questions'][0]['options'][1]['id'] = 'derived'
            if self.mode == 'long_option_ids':
                reply['questions'][0]['options'][0]['id'] = 'synthetic_option_identifier_long_a'
                reply['questions'][0]['options'][1]['id'] = 'synthetic_option_identifier_long_b'
        if index == 3:
            reply['brief_updates'] = [{'slot': case['changed_slot'], 'value': case['changed_value'], 'quote': case['changed_value']}]
            public = context['context']['editable_form']
            reply['prefill'] = {'scope': public['scope'], 'fields': [{'id': case['changed_slot'], 'value': case['changed_value']}]}
            if self.mode == 'manual_overwrite':
                reply['prefill']['fields'].append({'id': 'acceptance_criteria', 'value': 'Silently replaced by model'})
            if self.mode == 'ignore_change':
                reply.pop('brief_updates')
                reply.pop('prefill')
            if self.mode == 'prefill_only':
                reply.pop('brief_updates')
            if self.mode == 'conflicting_updates':
                reply['brief_updates'][0].update(value='A different inferred scientific interpretation', quote='')
        if self.mode == 'invent_code' and index == 2:
            reply['answer'] = 'Use J9999 as the exact required procedure code.'
        if self.mode == 'default_uncertain' and index == 2:
            # A literal user statement cannot be conjured from missing evidence.
            reply['brief_updates'] = [{'slot': current['id'], 'value': 'Choose the default', 'quote': 'Choose the default'}]
        if self.mode == 'quote_own_question' and index == 2:
            reply['brief_updates'] = [{'slot': current['id'], 'value': current['prompt'], 'quote': current['prompt']}]
        return json.dumps(reply)


@pytest.fixture
def setup(tmp_path, monkeypatch):
    root = tmp_path / 'repo'
    (root / PACK).mkdir(parents=True)
    shutil.copytree(ROOT / '.claude/skills', root / '.claude/skills')
    target = root / evaluation.PUBLIC
    target.parent.mkdir(parents=True)
    shutil.copyfile(ROOT / evaluation.PUBLIC, target)
    monkeypatch.setenv('RWDP_STATE_DIR', str(tmp_path / 'private'))
    model = Scripted()
    monkeypatch.setattr(evaluation.connection, 'describe', lambda *a: copy.deepcopy(CONNECTION))
    monkeypatch.setattr(evaluation.ai, '_provider', lambda *a: dict(CONNECTION, configured=True, instance=model))
    return SimpleNamespace(root=root, pack=PACK, model=model)


def preview(value, count=3):
    ids = [c['id'] for c in evaluation._cases()][:count]
    return evaluation.preview(value.root, value.pack, ACTOR, ids, allowed_packs=[value.pack])


def run(value, proposal, **kwargs):
    args = dict(allowed_packs=[value.pack], confirmed=True, local_demo=True, can_review=True)
    args.update(kwargs)
    return evaluation.run(value.root, value.pack, ACTOR, proposal, **args)


def test_preview_is_read_only_and_freezes_three_four_turn_journeys(setup):
    proposed = preview(setup)
    assert len(proposed['cases']) == 3
    assert all(len(c['case']['turns']) == 4 for c in proposed['cases'])
    assert all(c['case']['provenance'] == 'generated' and c['case']['adjudicated'] is False for c in proposed['cases'])
    assert proposed['versions'][evaluation.PUBLIC]
    assert not setup.model.calls
    assert not list((setup.root / PACK).rglob('*.json'))


def corpus():
    return yaml.safe_load((ROOT / evaluation.CORPUS).read_text(encoding='utf-8'))


@pytest.mark.parametrize('count', [1, 4, evaluation.MAX_CORPUS_CASES])
def test_corpus_can_expand_without_requiring_exactly_three_cases(count):
    value = corpus()
    template = value['cases'][0]
    value['cases'] = [dict(copy.deepcopy(template), id=f'conversation_generated_{i}', title=f'Synthetic journey {i}')
                      for i in range(count)]
    assert len(evaluation._validate_corpus(value)) == count


@pytest.mark.parametrize('change', [
    lambda c: c.update(version=True),
    lambda c: c.update(evidence_mode='reviewed'),
    lambda c: c.update(cases=[]),
    lambda c: c.update(cases=c['cases'] * evaluation.MAX_CORPUS_CASES),
    lambda c: c['cases'].append(copy.deepcopy(c['cases'][0])),
    lambda c: c['cases'][0].update(initial=[]),
    lambda c: c['cases'][0].update(question_slot=['population']),
    lambda c: c['cases'][0].update(changed_slot='acceptance_criteria'),
    lambda c: c['cases'][0].update(changed_slot='missing_field'),
    lambda c: c['cases'][0].update(changed_value=c['cases'][0]['initial']['population']),
    lambda c: c['cases'][0].update(human_rubric=[]),
    lambda c: c['cases'][0].update(adjudicated=True),
    lambda c: c['cases'][0]['turns'][0].update(expect='uncertainty'),
    lambda c: c['cases'][0]['turns'][1].update(text='1A'),
    lambda c: c['cases'][0]['turns'][2].update(text='Choose a default'),
    lambda c: c['cases'][0]['turns'][3].update(text='Change something else'),
    lambda c: c['cases'][0]['turns'][0].update(text='x' * 2401),
], ids=['bool-version', 'false-evidence', 'empty', 'too-many', 'duplicate-id', 'bad-initial',
        'nontext-slot', 'overwrite-manual', 'missing-field', 'unchanged-intent', 'missing-rubric',
        'false-adjudication', 'wrong-order', 'unscored-choice', 'default-uncertainty', 'unquoted-change', 'oversized-turn'])
def test_malformed_or_unscorable_corpus_is_refused(change):
    value = corpus()
    change(value)
    with pytest.raises(ValueError):
        evaluation._validate_corpus(value)


@pytest.mark.parametrize('value', [None, [], 'not a corpus', {'version': 1}])
def test_non_corpus_values_fail_with_a_reviewable_error(value):
    with pytest.raises(ValueError, match='corpus'):
        evaluation._validate_corpus(value)


def test_oversized_corpus_is_refused_before_yaml_parsing(tmp_path, monkeypatch):
    target = tmp_path / evaluation.CORPUS
    target.parent.mkdir(parents=True)
    target.write_bytes(b'x' * (evaluation.MAX_CORPUS_BYTES + 1))
    monkeypatch.setattr(evaluation, 'CODE', tmp_path)
    with pytest.raises(ValueError, match='file size'):
        evaluation._cases()


@pytest.mark.parametrize('selection', ['too_many', 'duplicate', 'unknown', 'unhashable'])
def test_expanded_corpus_keeps_three_case_native_call_limit(setup, selection):
    ids = [c['id'] for c in evaluation._cases()]
    selected = {'too_many': ids[:4], 'duplicate': [ids[0], ids[0]],
                'unknown': ['conversation_not_registered'], 'unhashable': [[ids[0]]]}[selection]
    with pytest.raises(ValueError, match='one to three'):
        evaluation.preview(setup.root, PACK, ACTOR, selected, allowed_packs=[PACK])
    assert not setup.model.calls


@pytest.mark.parametrize('case_id', ['conversation_ambiguous_population_revision', 'conversation_source_cut_revision'])
@pytest.mark.parametrize('mode', [None, 'prefill_only'])
def test_additional_journeys_exercise_existing_guide_brief_form_and_scorer(setup, case_id, mode):
    setup.model.mode = mode
    proposed = evaluation.preview(setup.root, PACK, ACTOR, [case_id], allowed_packs=[PACK])
    record = run(setup, proposed)
    assert record['results'][0]['passed'], record['results'][0]
    assert len(setup.model.calls) == 4
    assert record['adjudicated'] is False and record['training_eligible'] is False
    assert record['clinical_quality'] == 'human_review_required'
    assert not list((setup.root / PACK).rglob('*.json'))
    if case_id == 'conversation_source_cut_revision':
        turn = record['runs'][0]['run']['conversation'][3]
        assert turn['checks']['previous_source_question_invalidated']
        assert turn['checks']['unresolved_choice_preserved']
        assert turn['brief_after']['state']['request']['source_cut'] == proposed['cases'][0]['case']['changed_value']


def test_real_guide_brief_form_and_canonical_scorer_complete_all_journeys(setup):
    record = run(setup, preview(setup))
    assert all(row['passed'] for row in record['results']), record['results']
    assert len(setup.model.calls) == 12
    assert record['adjudicated'] is False and record['training_eligible'] is False
    assert record['clinical_quality'] == 'human_review_required'
    assert not list((setup.root / PACK).rglob('*.json'))
    for scoped, entry in zip(record['cases'], record['runs']):
        turns = entry['run']['conversation']
        case = scoped['case']
        assert turns[1]['checks']['exact_short_choice']
        assert turns[2]['brief_after']['unknown_slots']
        assert turns[3]['brief_after']['state']['request'][case['changed_slot']] == case['changed_value']
        assert turns[3]['form_after'][case['changed_slot']] == case['changed_value']
        assert len(turns[0]['calls'][0]['system']) > 100
        assert json.loads(turns[0]['calls'][0]['raw_response'])['questions']
        assert all(c['input_bytes'] <= evaluation.ai.MAX_REQUEST_BYTES for turn in turns for c in turn['calls'])
    read = evaluation.read(setup.root, PACK, ACTOR, record['id'], allowed_packs=[PACK])
    assert read['runs'] == record['runs']


@pytest.mark.parametrize('mode,failed_turn', [('malformed', 1), ('manual_overwrite', 4), ('ignore_change', 4), ('invent_code', 3)])
def test_failed_journey_stops_but_other_independent_journeys_are_exercised(setup, mode, failed_turn):
    setup.model.mode = mode
    record = run(setup, preview(setup))
    assert not record['results'][0]['passed']
    assert len(setup.model.calls) == failed_turn * 3
    assert all(row['status'] == 'failed' for row in record['results'])
    failed = record['runs'][0]['run']['conversation'][failed_turn - 1]
    assert failed['status'] == 'failed'
    if mode == 'malformed':
        assert failed['calls'][0]['raw_response'] == '{"answer":'
        assert failed['reply']['error_code'] == 'invalid_response'
    assert record['stop_reason'] is None
    assert all(t['status'] == 'skipped' for t in record['runs'][0]['run']['conversation'][failed_turn:])


def test_inferred_default_is_not_accepted_as_uncertain_user_choice(setup):
    setup.model.mode = 'default_uncertain'
    record = run(setup, preview(setup, 1))
    uncertainty = record['runs'][0]['run']['conversation'][2]
    assert uncertainty['brief_after']['unknown_slots']
    assert uncertainty['checks']['uncertain_value_not_defaulted']
    assert uncertainty['brief_after']['proposed_updates']


def test_mcq_expansion_cannot_make_assistant_question_a_literal_user_decision(setup):
    setup.model.mode = 'quote_own_question'
    record = run(setup, preview(setup, 1))
    turn = record['runs'][0]['run']['conversation'][2]
    slot = turn['question_before']['id']
    assert slot in turn['brief_after']['unknown_slots']
    assert turn['brief_after']['state']['request'][slot] == turn['brief_before']['state']['request'][slot]
    assert turn['question_before']['prompt'] not in turn['user_text']
    assert turn['brief_after']['proposed_updates'][0]['quote'] == ''


def test_changed_connection_after_call_retains_answer_as_failed_and_stops(setup, monkeypatch):
    original = setup.model.step
    def change_after(system, messages):
        raw = original(system, messages)
        monkeypatch.setattr(evaluation.connection, 'describe', lambda *a: dict(CONNECTION, model='another-selected-model'))
        return raw
    setup.model.step = change_after
    record = run(setup, preview(setup))
    assert len(setup.model.calls) == 1
    row = record['runs'][0]['run']['conversation'][0]
    assert row['error_code'] == 'stale_inputs' and row['calls'][0]['raw_response']
    assert row['reply']['source'] == 'assistant' and row['passed'] is False


def test_completed_request_is_idempotent_without_more_calls(setup):
    proposed = preview(setup, 1)
    first = run(setup, proposed)
    second = run(setup, proposed)
    assert first['id'] == second['id'] and second['changed'] is False
    assert len(setup.model.calls) == 4


def test_displayed_second_choice_works_with_semantic_model_identifiers(setup):
    setup.model.mode = 'semantic_option_ids'
    record = run(setup, preview(setup, 1))
    assert record['results'][0]['passed'], record['results'][0]
    turn = record['runs'][0]['run']['conversation'][1]
    assert turn['question_before']['options'][1]['id'] == 'derived'
    assert turn['checks']['exact_short_choice']
    assert turn['brief_after']['state']['request'][turn['question_before']['id']] == 'Use a reviewed derived definition'


def test_exact_user_wording_in_validated_prefill_updates_the_same_brief_for_all_journeys(setup):
    setup.model.mode = 'prefill_only'
    record = run(setup, preview(setup))
    assert all(row['passed'] for row in record['results']), record['results']
    for scoped, entry in zip(record['cases'], record['runs']):
        last = entry['run']['conversation'][3]
        assert not last['reply'].get('brief_updates')
        assert last['validated_prefill']
        assert last['brief_after']['state']['request'][scoped['case']['changed_slot']] == scoped['case']['changed_value']
        assert last['checks']['manual_brief_preserved'] and last['checks']['unresolved_choice_preserved']


def test_bounded_long_semantic_option_ids_work_in_the_real_journey(setup):
    setup.model.mode = 'long_option_ids'
    record = run(setup, preview(setup, 1))
    assert record['results'][0]['passed'], record['results'][0]
    selected = record['runs'][0]['run']['conversation'][1]
    assert len(selected['question_before']['options'][1]['id']) > 32
    assert selected['checks']['exact_short_choice']


def test_wrong_scientific_question_slot_fails_even_with_valid_useful_choices(setup):
    setup.model.mode = 'wrong_question_slot'
    record = run(setup, preview(setup))
    assert len(setup.model.calls) == 3
    assert record['stop_reason'] is None
    for scoped, result, entry in zip(record['cases'], record['results'], record['runs']):
        first = entry['run']['conversation'][0]
        assert first['reply']['source'] == 'assistant'
        assert len(first['reply']['questions'][0]['options']) == 2
        assert first['reply']['questions'][0]['id'] != scoped['case']['question_slot']
        assert first['checks']['relevant_mcq'] is False
        assert result['status'] == 'failed' and result['passed'] is False
        assert all(turn['status'] == 'skipped' for turn in entry['run']['conversation'][1:])


def test_contradictory_brief_and_prefill_are_retained_as_failed_without_mutating_either(setup):
    setup.model.mode = 'conflicting_updates'
    record = run(setup, preview(setup, 1))
    last = record['runs'][0]['run']['conversation'][3]
    assert record['results'][0]['status'] == 'failed'
    assert last['reply']['source'] == 'assistant'
    assert last['checks']['brief_form_consistent'] is False
    assert last['form_after']['population'] == last['form_before']['fields'][0]['current']
    assert last['brief_after']['state']['request']['population'] == last['brief_before']['state']['request']['population']
    assert record['stop_reason'] is None


def test_interrupted_request_retains_skip_without_replaying_uncertain_call(setup):
    proposed = preview(setup, 1)
    _, directory = evaluation._scope(setup.root, PACK, ACTOR, [PACK])
    evaluation._save(directory / (proposed['request_id'] + '.json'), {'proposal': proposed,
        'journeys': [{'run_id': 'a' * 32, 'turns': []}], 'in_flight': {'case': 0, 'turn': 0}})
    record = run(setup, proposed)
    assert record['stop_reason'] == 'interrupted_request_not_replayed'
    assert record['results'][0]['status'] == 'failed'
    assert record['results'][0]['metrics']['total_calls'] is None
    assert record['results'][0]['metrics']['uncertain_calls'] == 1
    assert record['runs'][0]['run']['conversation'][0]['status'] == 'interrupted'
    assert not setup.model.calls


@pytest.mark.parametrize('permission', ['confirmed', 'local_demo', 'can_review'])
def test_explicit_permissions_required_before_model(setup, permission):
    with pytest.raises(ValueError):
        run(setup, preview(setup, 1), **{permission: False})
    assert not setup.model.calls


def test_changed_reference_or_connection_requires_new_preview(setup, monkeypatch):
    proposed = preview(setup, 1)
    monkeypatch.setattr(evaluation.connection, 'describe', lambda *a: dict(CONNECTION, model='claude-sonnet-5'))
    with pytest.raises(ValueError, match='changed'):
        run(setup, proposed)
    assert not setup.model.calls


def test_access_revocation_and_wrong_actor_cannot_read_private_packet(setup):
    record = run(setup, preview(setup, 1))
    with pytest.raises(ValueError):
        evaluation.read(setup.root, PACK, ACTOR, record['id'], allowed_packs=[])
    with pytest.raises((ValueError, OSError)):
        evaluation.read(setup.root, PACK, 'Another author', record['id'], allowed_packs=[PACK])


def test_cancel_retains_explicit_skips_without_model_call(setup, monkeypatch):
    monkeypatch.setattr(evaluation.portal_runtime, 'job_cancelled', lambda: True)
    record = run(setup, preview(setup))
    assert record['stop_reason'] == 'cancelled'
    assert all(r['status'] == 'skipped' for r in record['results'])
    assert not setup.model.calls


def test_total_budget_skips_all_remaining_turns_without_model_call(setup, monkeypatch):
    monkeypatch.setattr(evaluation, 'MAX_SECONDS', 0)
    record = run(setup, preview(setup))
    assert record['stop_reason'] == 'total_time_budget'
    assert all(r['status'] == 'skipped' for r in record['results'])
    assert not setup.model.calls


def test_provider_failure_stops_all_journeys_and_does_not_retain_exception_body(setup):
    def fail(system, messages):
        raise RuntimeError('Do not retain this transport body')
    setup.model.step = fail
    record = run(setup, preview(setup))
    assert record['stop_reason'] == 'assistant_connection_or_context_unavailable'
    assert [r['status'] for r in record['results']] == ['failed', 'skipped', 'skipped']
    assert 'Do not retain this transport body' not in json.dumps(record)


@pytest.mark.parametrize('content_bytes', [17748, 18000])
def test_capture_counts_native_utf8_context_not_double_escaped_json_envelope(content_bytes):
    calls = []
    class Native:
        def step(self, system, messages):
            calls.append((system, copy.deepcopy(messages)))
            return '{"answer":"Synthetic response","actions":[]}'
    content = json.dumps({'text': 'C:\\synthetic\\row says "review" µ. ' * 350}, ensure_ascii=False)
    system = 'x' * (content_bytes - len(content.encode('utf-8')))
    messages = [{'role': 'user', 'content': content}]
    assert len(system.encode('utf-8')) + len(json.dumps(messages, ensure_ascii=False).encode('utf-8')) > evaluation.ai.MAX_REQUEST_BYTES + 200
    capture = evaluation._Capture(Native())
    raw = capture.step(system, messages)
    assert raw == '{"answer":"Synthetic response","actions":[]}'
    assert len(calls) == 1 and calls[0] == (system, messages)
    assert capture.calls[0]['raw_response'] == raw
    assert capture.calls[0]['input_bytes'] == content_bytes
    assert capture.calls[0]['serialized_message_bytes'] == len(json.dumps(messages, ensure_ascii=False).encode('utf-8'))
    assert capture.preflight_error is None


@pytest.mark.parametrize('system,content', [('x', 'y' * 18000), ('µ' * 9001, '')],
                         ids=['one-byte-over-limit', 'multibyte-over-limit'])
def test_capture_still_refuses_over_native_byte_limit_before_dispatch(system, content):
    class Never:
        def step(self, *args):
            pytest.fail('Oversized input reached a model adapter')
    capture = evaluation._Capture(Never())
    with pytest.raises(ValueError, match='context bound'):
        capture.step(system, [{'role': 'user', 'content': content}])
    assert capture.calls == []
    assert capture.preflight_error['code'] == 'context_limit'
    assert capture.preflight_error['native_call_started'] is False
    assert capture.preflight_error['maximum_input_bytes'] == 18000


def test_evaluation_preflight_refusal_is_not_reported_as_a_connection_failure(setup, monkeypatch):
    original = evaluation._Capture.step
    def refuse(self, system, messages):
        return original(self, system + 'x' * evaluation.ai.MAX_REQUEST_BYTES, messages)
    monkeypatch.setattr(evaluation._Capture, 'step', refuse)
    record = run(setup, preview(setup, 1))
    first = record['runs'][0]['run']['conversation'][0]
    assert record['stop_reason'] == 'evaluation_preflight_refused'
    assert first['reply']['error_code'] == 'evaluation_preflight'
    assert first['preflight']['code'] == 'context_limit'
    assert first['preflight']['native_call_started'] is False
    assert 'no connection failure was observed' in first['reply']['note']
    assert record['results'][0]['metrics']['total_calls'] == 0
    assert setup.model.calls == []


def test_job_dispatch_reuses_existing_bounded_runner_and_is_not_spark(setup, monkeypatch):
    monkeypatch.setattr(evaluation, 'run', lambda *a, **k: {'ok': True, 'id': 'a' * 24})
    value = {'root': str(setup.root), 'actor': ACTOR, 'action': 'conversation_evaluation',
        'arguments': {'pack': PACK}, 'allowed_packs': [PACK]}
    assert portal_jobs._dispatch(value)['ok']
    assert 'conversation_evaluation' not in portal_jobs.HEAVY_ACTIONS
    assert not portal_jobs.retry_guidance(setup.root, dict(value, result={}))['allowed']


def test_existing_streamlit_panel_previews_reference_journeys_without_model_calls(setup, monkeypatch):
    from streamlit.testing.v1 import AppTest
    calls = []
    monkeypatch.setattr(portal_jobs, 'start', lambda *a, **k: calls.append(k) or {'id': 'b' * 24})
    code = f'''import model_lifecycle_workspace_page as page
page.render({str(setup.root)!r}, {PACK!r}, {ACTOR!r}, allowed_packs=[{PACK!r}],
 local_demo=True, can_write=True, can_review=True)
'''
    at = AppTest.from_string(code, default_timeout=30).run()
    assert not at.exception, [e.message for e in at.exception]
    assert at.radio(key='model_lifecycle_evaluation_view').value == 'Scientific conversations'
    assert not any('Activate' in b.label for b in at.button)
    at.button(key='model_lifecycle_conversation_preview').click().run()
    assert not at.exception, [e.message for e in at.exception]
    assert at.button(key='model_lifecycle_conversation_run').disabled
    assert not setup.model.calls and not calls
    at.checkbox(key='model_lifecycle_conversation_confirmed').check().run()
    at.button(key='model_lifecycle_conversation_run').click().run()
    assert not at.exception, [e.message for e in at.exception]
    assert calls[0]['action'] == 'conversation_evaluation'
    assert len(calls[0]['arguments']['proposal']['cases']) == 3
    assert not setup.model.calls


def test_existing_streamlit_panel_selects_added_journeys_from_expanded_corpus(setup, monkeypatch):
    from streamlit.testing.v1 import AppTest
    calls = []
    monkeypatch.setattr(portal_jobs, 'start', lambda *a, **k: calls.append(k) or {'id': 'b' * 24})
    code = f'''import model_lifecycle_workspace_page as page
page.render({str(setup.root)!r}, {PACK!r}, {ACTOR!r}, allowed_packs=[{PACK!r}],
 local_demo=True, can_write=True, can_review=True)
'''
    at = AppTest.from_string(code, default_timeout=30).run()
    assert not at.exception, [e.message for e in at.exception]
    selector = at.multiselect(key='model_lifecycle_conversation_cases')
    assert len(selector.value) == evaluation.MAX_SELECTED_CASES
    assert 'Revise the proposed source and delivery' in selector.options
    added = ['conversation_ambiguous_population_revision', 'conversation_source_cut_revision']
    selector.set_value(added).run()
    at.button(key='model_lifecycle_conversation_preview').click().run()
    assert not at.exception, [e.message for e in at.exception]
    at.checkbox(key='model_lifecycle_conversation_confirmed').check().run()
    at.button(key='model_lifecycle_conversation_run').click().run()
    assert not at.exception, [e.message for e in at.exception]
    assert [r['case']['id'] for r in calls[0]['arguments']['proposal']['cases']] == added
    assert not setup.model.calls


def test_existing_streamlit_panel_shows_failed_and_skipped_results(setup):
    from streamlit.testing.v1 import AppTest
    setup.model.mode = 'malformed'
    record = run(setup, preview(setup))
    code = f'''import model_lifecycle_workspace_page as page
page.render({str(setup.root)!r}, {PACK!r}, {ACTOR!r}, allowed_packs=[{PACK!r}],
 local_demo=True, can_write=True, can_review=True)
'''
    at = AppTest.from_string(code, default_timeout=30).run()
    assert not at.exception, [e.message for e in at.exception]
    data = at.dataframe[0].value
    assert list(data['Mechanical result']) == ['failed', 'failed', 'failed']
    assert any('human review required' in item.value for item in at.caption)
    assert record['id'] in at.get('download_button')[0].key


def test_product_results_use_existing_branch_packet_and_never_source_changes(setup):
    working = 'products/oncology/synthetic/202606'
    (setup.root / working).mkdir(parents=True)
    setup.pack = working
    record = run(setup, preview(setup, 1))
    path = setup.root / working / 'handoff/model_lifecycle/evaluations' / (record['id'] + '.json')
    assert path.is_file()
    assert not (setup.root / working / 'source_refs.yaml').exists()
    assert evaluation.runtime.read_record(setup.root, working, 'evaluations', record['id'], allowed_packs=[working])['runs']
