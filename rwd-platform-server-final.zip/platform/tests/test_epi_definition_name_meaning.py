"""A row's naming comparison is scoped, reviewable and bound to its exact save.

Use the existing real contract/evidence fixture and validators. These tests write
only disposable products; scientific questions do not authenticate an approval.
"""
from pathlib import Path
import json
import shutil
import sys

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "platform/tests"))
from test_epi_scientific_definitions import (
    ACTOR, ITEM, apply, cl, cr, definitions, describe, fixture,
    governed_bytes, preview,
)


def _peer(root, product, after, *, slug="peer", **changes):
    """Reuse the exact proposed scientific row, varying only the named cells."""
    peer_pack = f"products/oncology/{slug}/202606"
    peer = root / peer_pack
    shutil.copytree(product, peer)
    _replace_peer(peer, after, **changes)
    return peer_pack, peer


def _replace_peer(peer, text, **changes):
    rows = [{field: cl._scalar(block, field) or "" for field in cl.TABLE_COLUMNS}
            for block in cl.records(text)]
    assert len(rows) == 1
    rows[0].update(changes)
    (peer / "handoff/FUNCTIONAL_CONTRACT.md").write_text(
        "# Peer scientific definitions\n\n" + cl.render_table(rows), encoding="utf-8")


def _preview(root, pack, values, scope):
    return definitions.preview(
        root, pack, ACTOR, ITEM, values,
        expected_input_digest=describe(root, pack)["input_digest"],
        allowed_packs=[pack], naming_packs=scope)


def _draft_status(product):
    block = next(cl.records((product / "handoff/FUNCTIONAL_CONTRACT.md").read_text(encoding="utf-8")))
    assert cr._status_map({"status": cl._scalar(block, "status")}) == cr.INITIAL_STATUS


def test_no_peer_keeps_existing_validated_row_save_behavior(tmp_path):
    root, pack, product, values = fixture(tmp_path)
    before = governed_bytes(product)
    candidate = preview(root, pack, values)
    assert candidate["ok"] and candidate["passed"], candidate
    assert candidate["name_reviews"] == [] and candidate["warnings"] == []
    assert governed_bytes(product) == before
    saved = apply(root, pack, candidate)
    assert saved["ok"] and saved["changed"] and not saved["approved"] and not saved["released"], saved
    assert (product / "handoff/FUNCTIONAL_CONTRACT.md").read_text(encoding="utf-8") == candidate["after"]
    _draft_status(product)


def test_scientific_differences_are_reviewable_and_do_not_block_draft_work(tmp_path):
    root, pack, product, values = fixture(tmp_path)
    baseline = preview(root, pack, values)
    assert baseline["passed"], baseline
    peer_pack, peer = _peer(root, product, baseline["after"],
                            window="[-90, +14]", missing="{no_record: exclude, present_null: null}")
    local_before, peer_before = governed_bytes(product), governed_bytes(peer)
    candidate = _preview(root, pack, values, [pack, peer_pack])
    assert candidate["ok"] and candidate["passed"], candidate
    assert len(candidate["name_reviews"]) == 1
    review = candidate["name_reviews"][0]
    assert review["peer"] == {"pack": peer_pack, "variable_id": "PDL1_TPS"}
    assert review["physical_name"] == "pdl1_tps"
    assert review["state"] == "review_required" and not review["resolved"] and review["resolution"] is None
    assert set(review["differing_fields"]) == {"window", "missing"}
    differences = {row["field"]: row for row in review["differences"]}
    original_window = next(cl.typed_records(baseline["after"])).cells["window"]
    assert differences["window"] == {"field": "window", "current": original_window, "peer": "[-90, +14]"}
    assert "exclude" in differences["missing"]["peer"]
    assert candidate["warnings"] == [review["question"]]
    assert governed_bytes(product) == local_before and governed_bytes(peer) == peer_before

    current = describe(root, pack)
    draft = definitions.save_draft(
        root, pack, ACTOR, ITEM, values, expected_input_digest=current["input_digest"],
        expected_draft_digest=current["draft_digest"], local_demo=True, can_write=True,
        allowed_packs=[pack])
    assert draft["ok"] and draft["draft_only"], draft
    assert governed_bytes(product) == local_before
    saved = apply(root, pack, candidate, naming_packs=[pack, peer_pack])
    assert saved["ok"] and saved["changed"] and not saved["approved"] and not saved["released"], saved
    assert saved["name_reviews"] == candidate["name_reviews"]
    _draft_status(product)
    assert governed_bytes(peer) == peer_before


def test_matching_rule_wording_does_not_hide_a_different_time_window(tmp_path):
    root, pack, product, values = fixture(tmp_path)
    baseline = preview(root, pack, values)
    assert baseline["passed"], baseline
    peer_pack, _ = _peer(root, product, baseline["after"], window="[-7, 0]")
    candidate = _preview(root, pack, values, [pack, peer_pack])
    assert candidate["ok"] and candidate["passed"], candidate
    review, = candidate["name_reviews"]
    assert review["differing_fields"] == ["window"]
    assert "derivation" not in review["differing_fields"] and "required_rule" not in review["differing_fields"]
    assert review["state"] == "review_required" and not review["resolved"]


def test_scope_excludes_unrelated_peer_before_its_contract_is_read(tmp_path, monkeypatch):
    root, pack, product, values = fixture(tmp_path)
    baseline = preview(root, pack, values)
    assert baseline["passed"], baseline
    visible_pack, _ = _peer(root, product, baseline["after"], window="[-7, 0]")
    hidden_pack, hidden = _peer(root, product, baseline["after"], slug="unrelated",
                                derivation="UNRELATED_PRIVATE_SCIENTIFIC_DETAIL")
    original_read = cl.read
    reads = []

    def scoped_read(path, *args, **kwargs):
        location = Path(path).resolve()
        assert hidden.resolve() not in location.parents and location != hidden.resolve(), location
        reads.append(location)
        return original_read(path, *args, **kwargs)

    monkeypatch.setattr(cl, "read", scoped_read)
    candidate = _preview(root, pack, values, [pack, visible_pack])
    assert candidate["ok"] and candidate["passed"], candidate
    assert {row["peer"]["pack"] for row in candidate["name_reviews"]} == {visible_pack}
    assert hidden_pack not in json.dumps(candidate)
    assert "UNRELATED_PRIVATE_SCIENTIFIC_DETAIL" not in json.dumps(candidate)
    assert (root / visible_pack / "handoff/FUNCTIONAL_CONTRACT.md").resolve() in reads
    local_only = _preview(root, pack, values, [pack])
    assert local_only["ok"] and local_only["passed"] and local_only["name_reviews"] == [], local_only


def test_changed_peer_after_preview_requires_a_new_review_before_apply(tmp_path):
    root, pack, product, values = fixture(tmp_path)
    baseline = preview(root, pack, values)
    assert baseline["passed"], baseline
    peer_pack, peer = _peer(root, product, baseline["after"], window="[-7, 0]")
    scope = [pack, peer_pack]
    candidate = _preview(root, pack, values, scope)
    assert candidate["passed"], candidate
    _replace_peer(peer, baseline["after"], window="[-180, 0]")
    before = governed_bytes(product)
    saved = apply(root, pack, candidate, naming_packs=scope)
    assert not saved["ok"] and any("reviewed proposal changed" in error.lower() for error in saved["errors"]), saved
    assert governed_bytes(product) == before
    refreshed = _preview(root, pack, values, scope)
    assert refreshed["passed"] and refreshed["manifest_digest"] != candidate["manifest_digest"], refreshed
    assert apply(root, pack, refreshed, naming_packs=scope)["ok"]
    _draft_status(product)


def test_changed_comparison_scope_cannot_reuse_an_earlier_review(tmp_path):
    root, pack, product, values = fixture(tmp_path)
    baseline = preview(root, pack, values)
    assert baseline["passed"], baseline
    peer_pack, _ = _peer(root, product, baseline["after"])
    # Identical fields have no finding; the reviewed scope itself still binds.
    candidate = _preview(root, pack, values, [pack, peer_pack])
    assert candidate["passed"] and candidate["name_reviews"] == [], candidate
    before = governed_bytes(product)
    saved = apply(root, pack, candidate, naming_packs=[pack])
    assert not saved["ok"] and any("reviewed proposal changed" in error.lower() for error in saved["errors"]), saved
    assert governed_bytes(product) == before


def test_peer_change_at_atomic_save_is_rechecked_without_writing_contract(tmp_path, monkeypatch):
    root, pack, product, values = fixture(tmp_path)
    baseline = preview(root, pack, values)
    assert baseline["passed"], baseline
    peer_pack, peer = _peer(root, product, baseline["after"], window="[-7, 0]")
    scope = [pack, peer_pack]
    candidate = _preview(root, pack, values, scope)
    assert candidate["passed"], candidate
    before = governed_bytes(product)
    real_atomic = definitions._atomic
    calls = []

    def change_peer_before_write(path, payload, *, check=None):
        calls.append(Path(path))
        _replace_peer(peer, baseline["after"], window="[-180, 0]")
        return real_atomic(path, payload, check=check)

    monkeypatch.setattr(definitions, "_atomic", change_peer_before_write)
    saved = apply(root, pack, candidate, naming_packs=scope)
    assert calls == [product / "handoff/FUNCTIONAL_CONTRACT.md"]
    assert not saved["ok"] and any("compared definition" in error.lower() for error in saved["errors"]), saved
    assert governed_bytes(product) == before
    assert not list(product.rglob(".definition-*.tmp")) and not list(product.rglob("*.lock"))
