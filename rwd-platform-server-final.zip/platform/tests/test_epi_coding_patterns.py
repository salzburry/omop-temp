"""Real code context and bounded revision facts; no generated code or model is run."""
from pathlib import Path
import json
import sys

import pytest

ROOT = Path(__file__).resolve().parents[2]
sys.path[:0] = [str(ROOT / "experiments/agent"), str(ROOT / "experiments/portal"), str(ROOT / "platform"), str(ROOT / "platform/tools")]
import coding_agent as coding
import critic
import state

PACK = "products/oncology/example/202609"
CODE = 'def adapt(frames, cfg):\n    return frames["events"].select("person_id")\n'
TESTS = 'from engine.example import adapt\ndef test_adapt_expected():\n    class Events:\n        def select(self, column):\n            assert column == "person_id"\n            return [1, 2]\n    observed = adapt({"events": Events()}, {"study": "example"})\n    assert observed == [1, 2]\n'
GOOD = {"decision": "generate", "generated": {"code": CODE, "tests": TESTS, "assumptions": ["Scientific timing needs review."]}, "summary": "Adapt the supplied function and compare expected output."}
VERDICT = {"route": "pass_on", "falsified": False, "findings": [], "confidence": "high"}


@pytest.fixture
def checkout(tmp_path, monkeypatch):
    h = tmp_path / PACK / "handoff"
    h.mkdir(parents=True)
    (h / "MAPPING_EVIDENCE.json").write_text(json.dumps({"ai_eligibility": {"state": "reviewed"}, "tables": {"events": {"person_id": "integer"}}}))
    monkeypatch.setattr(coding, "ROOT", str(tmp_path))
    monkeypatch.setattr(coding, "CANDIDATES", str(tmp_path / "candidates"))
    monkeypatch.setattr(state, "candidate_file", lambda *args: str(tmp_path / "candidates/result.json"))
    monkeypatch.setattr(coding, "gather", lambda *args: {"definition": "Reviewed definition", "implementation_context": {"files": []}})
    return tmp_path


class Model:
    model = "scripted"
    def __init__(self, replies):
        self.replies, self.calls = list(replies), []
    def step(self, system, messages):
        self.calls.append((system, messages))
        answer = self.replies.pop(0)
        if isinstance(answer, Exception):
            raise answer
        return answer if isinstance(answer, str) else json.dumps(answer)


def test_actual_current_ecog_source_and_tests_are_supplied_with_full_file_hashes():
    context = coding.implementation_context("ECOG", root=ROOT)
    assert coding.context_current(context, root=ROOT)
    assert any(row["symbol"] == "baseline_ecog" and row["kind"] == "implementation" for row in context["files"])
    assert any(row["kind"] == "test" and "assert" in row["excerpt"] for row in context["files"])
    assert context["omissions"] and any(row["truncated"] for row in context["files"])
    assert all((ROOT / row["path"]).read_bytes() for row in context["files"])


def test_missing_and_changed_real_sources_are_explicit_not_replaced(tmp_path):
    import yaml
    (tmp_path / "platform").mkdir()
    registry = tmp_path / "platform/capabilities.yaml"
    registry.write_text(yaml.safe_dump({"capabilities": [{"id": "test", "master": "X", "python": [{"module": "platform/no.py", "symbol": "missing"}], "tests": ["platform/tests/no.py::test_no"]}]}))
    context = coding.implementation_context("X", root=tmp_path)
    assert not context["files"] and len(context["omissions"]) == 3
    registry.write_text("capabilities: []\n")
    assert not coding.context_current(context, root=tmp_path)


def test_static_failure_gets_one_corrective_revision_then_independent_critic(checkout):
    broken = {**GOOD, "generated": {**GOOD["generated"], "code": "def broken(:\n"}}
    model = Model([broken, GOOD, VERDICT])
    result = coding.run(PACK, "ECOG", model=model)
    assert len(model.calls) == 3 and result["model_calls"] == 3
    assert result["revisions"][0]["before"] == broken
    assert result["deterministic_checks"]["static_findings"] == []
    assert result["deterministic_checks"]["runtime_tests_run"] is False
    assert result["pattern"] == coding.pattern_metadata(CODE)


def test_critic_revision_consumes_at_most_four_shared_calls(checkout):
    model = Model([GOOD, {**VERDICT, "route": "revise", "findings": ["Explain missing values."]}, GOOD, VERDICT])
    result = coding.run(PACK, "ECOG", model=model)
    assert len(model.calls) == result["model_calls"] == 4
    assert result["revisions"][0]["reason"] == "critic findings"


@pytest.mark.parametrize("bad", [[], {"decision": []}, {"decision": "generate", "generated": "wrong"}, "not JSON", "x" * 49000], ids=["list", "wrong-decision-type", "wrong-generated-type", "not-json", "oversize"])
def test_malformed_or_oversize_proposals_never_compile_execute_or_count(checkout, bad):
    model = Model([bad, bad])
    result = coding.run(PACK, "ECOG", model=model)
    assert result["pattern"] is None and result["critic"] is None
    assert len(model.calls) == 2
    assert not (checkout / "candidates/promotion_ledger.json").exists()


def test_disconnected_model_leaves_no_candidate_or_ledger(checkout):
    with pytest.raises(ConnectionError):
        coding.run(PACK, "ECOG", model=Model([ConnectionError("scripted connection closed")]))
    assert not (checkout / "candidates").exists()


def test_unreviewed_mapping_stops_without_revision_or_critic(checkout):
    (checkout / PACK / "handoff/MAPPING_EVIDENCE.json").write_text('{}')
    model = Model([GOOD])
    result = coding.run(PACK, "ECOG", model=model)
    assert len(model.calls) == 1 and result["pattern"] is None and result["critic"] is None


def test_static_unsafe_import_and_tautological_test_are_not_treated_as_validation(checkout):
    bad = {**GOOD, "generated": {"code": "import subprocess\ndef adapt(frames,cfg):\n    return subprocess.run(['anything'])", "tests": "def test_x():\n    assert True"}}
    checks, _ = coding.static_review(bad, PACK)
    assert any("imports" in f for f in checks["static_findings"])
    assert any("independently" in f for f in checks["static_findings"])
    assert not checks["runtime_tests_run"]


@pytest.mark.parametrize("document", [[], {"ai_eligibility": "reviewed", "tables": {}}, {"ai_eligibility": {"state": "reviewed"}, "tables": []}, {"ai_eligibility": {"state": "reviewed"}, "tables": {"events": []}}])
def test_malformed_mapping_metadata_is_a_clear_refusal_not_a_crash(checkout, document):
    (checkout / PACK / "handoff/MAPPING_EVIDENCE.json").write_text(json.dumps(document))
    result = coding.run(PACK, "ECOG", model=Model([GOOD]))
    assert result["critic"] is None and result["pattern"] is None
    assert "unverifiable" in result["deterministic_checks"]["identifiers"]


@pytest.mark.parametrize("source", ['from pathlib import Path\ndef adapt(frames,cfg):\n    return Path("unreviewed").read_text()',
    'def adapt(frames,cfg):\n    return spark.read.parquet("unreviewed")'])
def test_direct_filesystem_or_spark_io_stays_a_static_refusal(checkout, source):
    checks, _ = coding.static_review({**GOOD, "generated": {**GOOD["generated"], "code": source}}, PACK)
    assert any("I/O" in finding or "imports" in finding for finding in checks["static_findings"])


def test_generated_authority_fields_are_refused_and_never_retained_as_a_pattern(checkout):
    proposal = {**GOOD, "approved_by": "Invented reviewer", "status": "approved"}
    result = coding.run(PACK, "ECOG", model=Model([proposal, proposal]))
    assert result["pattern"] is None and result["critic"] is None
    assert any("approval" in issue for issue in result["deterministic_checks"]["static_findings"])
