"""Explicit session-local assistant choices and metadata checks; no model requests."""
from __future__ import annotations

from contextlib import contextmanager
import os
from pathlib import Path
import sys
from types import ModuleType
from unittest.mock import Mock

import pytest
from streamlit.testing.v1 import AppTest

ROOT = Path(__file__).resolve().parents[2]
sys.path[:0] = [str(ROOT / "experiments/portal"), str(ROOT / "platform/tools")]
import assistant_connection_page as page


@contextmanager
def app(tmp_path, monkeypatch, *, provider="", configured=True, failure=None):
    monkeypatch.setenv("RWD_PORTAL_AI_PROVIDER", provider)
    case = ModuleType("_epi_assistant_connection_case")
    case.root, case.actor, case.local_demo = str(tmp_path), "test-author", True
    monkeypatch.setitem(sys.modules, case.__name__, case)
    checks = []
    def metadata(root, *, health=False):
        checks.append({"root": root, "health": health, "provider": page.assistant.selected_provider()})
        if failure:
            raise failure
        return {"configured": configured, "model": "claude-sonnet-4-6",
                "model_info": {"name": "Claude Sonnet"}, "help": "Sign in to the selected assistant."}
    monkeypatch.setattr(page.assistant, "_provider", metadata)
    case.runtime_checks = Mock()
    monkeypatch.setattr(page.assistant, "check_direct_runtime", case.runtime_checks)
    generation = Mock(side_effect=AssertionError("Connection checks must not generate model answers"))
    monkeypatch.setattr(page.assistant, "suggest", generation)
    monkeypatch.setattr(page.assistant, "_call", generation)
    script = '''
import streamlit as st
import assistant_connection_page as page
import _epi_assistant_connection_case as case
page.render(case.root, case.actor, local_demo=case.local_demo)
st.text("Selected provider: " + page.assistant.selected_provider())
st.text_area("Unsaved scientific note", key="scientific_definition_field_notes")
'''
    at = AppTest.from_string(script, default_timeout=30).run()
    healthy(at)
    try:
        yield at, case, checks
    finally:
        generation.assert_not_called()
        page.assistant.set_provider_selection(None)


def healthy(at):
    assert not at.exception, [error.message for error in at.exception]


def test_no_environment_default_means_no_automatic_assistant_or_connection_call(tmp_path, monkeypatch):
    with app(tmp_path, monkeypatch) as (at, _case, checks):
        assert at.selectbox(key="assistant_connection_choice").value is None
        assert at.button(key="assistant_connection_check").disabled
        assert set(at.selectbox(key="assistant_connection_choice").options) == set(page.LABELS.values())
        assert not checks and not at.text_input


def test_shared_connection_explains_every_agent_and_helper_without_running_them(tmp_path, monkeypatch):
    with app(tmp_path, monkeypatch, provider="vscode") as (at, _case, checks):
        assert at.expander[0].label == "Assistant connection"
        assert at.selectbox(key="assistant_connection_choice").label == "Connection for all agents and drafting helpers"
        explanation = " ".join(caption.value for caption in at.caption).lower()
        for role in ("intake", "orchestration", "source", "coding", "validation", "critic",
                     "page guide", "scientific definitions", "decision answers", "form suggestions"):
            assert role in explanation
        assert "critic checks specialist results automatically" in explanation
        assert "start with the question on your current page" in explanation
        assert not checks


def test_explicit_claude_code_selection_keeps_unsaved_text_and_check_reads_only_metadata(tmp_path, monkeypatch):
    with app(tmp_path, monkeypatch, provider="vscode") as (at, _case, checks):
        environment = dict(os.environ)
        at.text_area(key="scientific_definition_field_notes").set_value("Unfinished rule, retained across assistant choices.").run()
        at.selectbox(key="assistant_connection_choice").set_value("claude_code").run()
        healthy(at)
        assert not checks
        assert any(text.value == "Selected provider: claude_code" for text in at.text)
        assert any("usage limits and billing" in caption.value for caption in at.caption)
        assert at.text_area(key="scientific_definition_field_notes").value.startswith("Unfinished rule")
        at.button(key="assistant_connection_check").click().run()
        healthy(at)
        assert checks == [{"root": str(tmp_path), "health": True, "provider": "claude_code"}]
        assert any("Claude Sonnet" in notice.value and "local sign-in found" in notice.value for notice in at.success)
        assert not any("is connected" in notice.value for notice in at.success)
        assert any("Model access is checked when you request suggestions; no question was sent" in caption.value for caption in at.caption)
        assert not at.text_input and dict(os.environ) == environment


def test_explicit_clear_overrides_environment_default_without_fallback(tmp_path, monkeypatch):
    with app(tmp_path, monkeypatch, provider="vscode") as (at, _case, checks):
        at.selectbox(key="assistant_connection_choice").set_value(None).run()
        healthy(at)
        assert any(text.value.strip() == "Selected provider:" for text in at.text)
        assert at.button(key="assistant_connection_check").disabled and not checks
        assert os.environ["RWD_PORTAL_AI_PROVIDER"] == "vscode"


@pytest.mark.parametrize("context_change", ["actor", "root", "local_mode"])
def test_identity_workspace_or_mode_change_does_not_reuse_another_connection_choice(tmp_path, monkeypatch, context_change):
    with app(tmp_path, monkeypatch, provider="vscode") as (at, case, checks):
        at.selectbox(key="assistant_connection_choice").set_value("claude_code").run()
        if context_change == "actor":
            case.actor = "another-author"
        elif context_change == "root":
            case.root = str(tmp_path / "another-workspace")
        else:
            case.local_demo = False
            at.run()
            healthy(at)
            assert not at.selectbox and not checks
            case.local_demo = True
        at.run()
        healthy(at)
        assert at.selectbox(key="assistant_connection_choice").value == "vscode"
        assert not checks


@pytest.mark.parametrize("provider", ["vscode", "claude_code", "anthropic"])
def test_configured_environment_choice_never_runs_a_probe_until_explicit_check(tmp_path, monkeypatch, provider):
    with app(tmp_path, monkeypatch, provider=provider) as (at, case, checks):
        assert at.selectbox(key="assistant_connection_choice").value == provider and not checks
        case.runtime_checks.assert_not_called()
        at.button(key="assistant_connection_check").click().run()
        healthy(at)
        assert checks[0]["provider"] == provider and checks[0]["health"]
        if provider == "anthropic":
            case.runtime_checks.assert_called_once()
            assert not at.success
            assert any("Account and model access will be checked" in notice.value for notice in at.info)
            assert any("No prompt or API request was sent" in caption.value for caption in at.caption)
        elif provider == "vscode":
            case.runtime_checks.assert_not_called()
            assert any("VS Code chat model is connected" in notice.value for notice in at.success)
            assert any("No question was sent and no model answer was generated" in caption.value for caption in at.caption)
        else:
            case.runtime_checks.assert_not_called()
            assert any("local sign-in found" in notice.value for notice in at.success)
            assert not any("is connected" in notice.value for notice in at.success)


@pytest.mark.parametrize("failure", [page.assistant.Invalid("Sign in to Claude Code before using this connection."),
                                    RuntimeError("PRIVATE-CLI-STDERR-SENTINEL")])
def test_failed_connection_check_keeps_the_chosen_provider_and_shows_no_private_output(tmp_path, monkeypatch, failure):
    with app(tmp_path, monkeypatch, provider="claude_code", failure=failure) as (at, _case, checks):
        at.button(key="assistant_connection_check").click().run()
        healthy(at)
        assert at.warning and not at.success
        assert at.selectbox(key="assistant_connection_choice").value == "claude_code"
        displayed = "\n".join(element.value for element in list(at.warning) + list(at.caption) + list(at.text))
        assert "PRIVATE-CLI-STDERR-SENTINEL" not in displayed
        assert len(checks) == 1


def test_direct_runtime_path_failure_is_visible_without_credentials_or_losing_the_draft(tmp_path, monkeypatch):
    error = OSError("PRIVATE-PATH-AND-CREDENTIAL-SENTINEL")
    error.winerror = 206
    with app(tmp_path, monkeypatch, provider="anthropic") as (at, case, _checks):
        case.runtime_checks.side_effect = page.assistant._provider_failure(error, initializing=True)
        at.text_area(key="scientific_definition_field_notes").set_value("My unfinished scientific answer.").run()
        case.runtime_checks.assert_not_called()
        at.button(key="assistant_connection_check").click().run()
        healthy(at)
        case.runtime_checks.assert_called_once()
        assert at.selectbox(key="assistant_connection_choice").value == "anthropic"
        assert at.text_area(key="scientific_definition_field_notes").value == "My unfinished scientific answer."
        displayed = "\n".join(element.value for element in list(at.warning) + list(at.caption) + list(at.info))
        assert "path-length limit" in displayed and "short local checkout" in displayed
        assert "PRIVATE-PATH-AND-CREDENTIAL-SENTINEL" not in displayed
        assert not at.success and not at.text_input


@pytest.mark.parametrize("code,action", [("cli_version_timeout", "claude --version"),
                                       ("auth_status_timeout", "claude auth status --json"),
                                       ("auth_status_unreadable", "claude auth status --json")])
def test_claude_metadata_failure_explains_next_step_and_retains_unsaved_answer(tmp_path, monkeypatch, code, action):
    error = page.assistant.Invalid(page.assistant.claude_code.ERRORS[code], code=code)
    with app(tmp_path, monkeypatch, provider="claude_code", failure=error) as (at, case, checks):
        at.text_area(key="scientific_definition_field_notes").set_value("My unfinished timing choice.").run()
        at.button(key="assistant_connection_check").click().run()
        healthy(at)
        assert len(checks) == 1 and not at.success
        assert action in "\n".join(item.value for item in at.warning)
        assert at.selectbox(key="assistant_connection_choice").value == "claude_code"
        assert at.text_area(key="scientific_definition_field_notes").value == "My unfinished timing choice."
        case.runtime_checks.assert_not_called()
