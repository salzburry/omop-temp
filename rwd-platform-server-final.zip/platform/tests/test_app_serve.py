"""The Domino app is a WINDOW, never a hand — pinned here, not just promised in its docstring.

Run: python3 tests/test_app_serve.py (or pytest).

Tests monkeypatch by hand (save/patch/try/finally) rather than via the pytest fixture, so the
direct `python3 tests/test_app_serve.py` runner keeps working — it calls each test with no args.
"""
import os
import subprocess
import sys
from pathlib import Path

FRAMEWORK = Path(__file__).resolve().parent.parent
REPO = FRAMEWORK.parent
sys.path.insert(0, str(REPO / "app"))

# The suite runs REAL tools for the surface test, and this machine's cold status run was
# measured above 180s under load. The headroom goes through the app's OWN operator knob —
# not a private patch — so the suite exercises exactly the mechanism a deployment would use
# (test/runtime parity: a patched constant could pass work the real app would terminate).
os.environ.setdefault("RWDP_TOOL_TIMEOUT", "600")

import serve # noqa: E402

# The suite runs on a DEV checkout, which is legitimately dirty mid-change — and the portal now
# refuses a dirty tree per request (an edited checkout under a clean footer proves nothing). The
# refusal itself is under test below; every other test simulates a clean tree so the page
# assertions exercise the pages.
_REAL_DIRTY, serve._dirty = serve._dirty, (lambda: [])

PACK = "fixtures/oncology/prostate/202606"
DECISION = "CODE-ALIGN" # an OPEN output decision with a scaffolded answer form


def test_every_surface_serves_and_the_allowlist_is_the_repo():
    assert PACK in serve.packs()
    status, body = serve.index()
    assert status == 200 and PACK.encode() in body
    # the index is a stakeholder board: plain-language labels, and each pack's standing in
    # status.py's OWN words — the app never composes a second, flattering summary
    for label in (b"where this stands", b"every rule, three ways", b"what to prepare",
                  b"questions awaiting an answer"):
        assert label in body, label
    assert serve._standings().get(PACK, "").encode() in body
    assert serve._standings()[PACK], "the board must show a live standing, not a blank"
    # the two stakeholder acts lead; reviewer views sit behind a "deeper" line — a workflow, not
    # a menu of equal things
    assert body.index(b"questions awaiting an answer") < body.index(b"deeper:")
    assert body.index(b"deeper:") < body.index(b"every rule, three ways")
    # a board titled "where everything stands" shows EVERY pack status.py reports — the ones with
    # no handoff/ carry their standing and say why there is nothing to click, instead of vanishing
    assert b"fixtures/oncology/dlbcl/YYYYMM" in body and b"no handoff yet" in body
    status, body = serve.page("flow", PACK)
    assert status == 200 and len(body) > 5000
    assert b"serving commit" in body, \
        "the provenance footer must ride GENERATED pages, not only the index"
    status, body = serve.questions(PACK)
    assert status == 200 and len(body) > 2000 and b"serving commit" in body
    status, body = serve.knowledge("fued")
    assert status == 200 and b"FUED-DEFINITION" in body
    # a query term is data, never a flag — `--suggest` and `--decision X` must not change verbs
    status, body = serve.knowledge("--suggest")
    assert status == 200 and b"candidate pair" not in body, \
        "a query term reached the CLI as a flag"
    status, body = serve.knowledge("--decision FUED-DEFINITION")
    assert (b"for query" in body or b"matches query" in body) and b"for decision" not in body, \
        "a query term reached the CLI as a flag"
    # a pack is served because the repository holds it, never because a URL names it
    for bad in ("products/../etc", "fixtures/oncology/prostate/999999", "/etc/passwd", ""):
        status, _ = serve.page("flow", bad)
        assert status == 404, bad
    status, _ = serve.page("edit", PACK)
    assert status == 404, "only render_html's own views are served"


def test_the_app_writes_nothing_into_the_checkout_and_stamps_its_provenance():
    import os
    assert not str(serve.TMP).startswith(str(REPO)), \
        "rendered pages must land OUTSIDE the tree — the restricted-output rule"
    _, body = serve.index()
    assert b"read-only" in body and serve.commit().encode() in body, \
        "every page carries the served commit — what is on screen is what is merged"
    # the module performs no governed act: the only tools it may invoke are the read-only four
    src = (REPO / "app" / "serve.py").read_text(encoding="utf-8")
    for forbidden in ("--apply", "--forms", "--write", "--record-digest", "run_spec_pipeline"):
        assert forbidden not in src, f"the window grew a hand: {forbidden}"
    assert os.access(str(REPO / "app.sh"), os.X_OK), "Domino runs app.sh; it must be executable"


def test_a_failed_status_tool_is_said_out_loud_never_blank_standings():
    # status.py exiting nonzero must NOT render a plausible board with blank standings — blank
    # reads as "no news is good news". The index says the wording out loud, banner AND every row.
    real = serve._tool
    def failing(args):
        if args[0] == "status.py":
            return subprocess.CompletedProcess(args, 2, stdout="fixtures/oncology/prostate/202606"
                                               "   half a row printed before dying", stderr="boom")
        return real(args)
    serve._tool = failing
    try:
        assert serve._standings() is None, \
            "a nonzero status.py is a failure, not standings — partial stdout must be discarded"
        status, body = serve.index()
    finally:
        serve._tool = real
    # 503, not 200: a 200 here taught machines — and people probing
    # with curl — that the board was functional while every standing was a shrug
    assert status == 503, status
    phrase = serve.STATUS_FAILED.encode("utf-8")
    assert b"status unavailable" in body and b"will not guess" in body
    assert body.count(phrase) >= 1 + len(serve.packs()), \
        "the failure wording must ride the banner AND every pack row"
    assert PACK.encode() in body and b"page?view=flow" in body, \
        "the board still lists served packs — the links still work during a status outage"
    assert b"half a row printed" not in body, "partial stdout from a dead tool is a guess"


class _FakeProc:
    """A Popen stand-in with real byte streams — the bounded reader is exercised for real."""
    def __init__(self, out=b"", err=b"", hang=False):
        import io
        self.stdout, self.stderr = io.BytesIO(out), io.BytesIO(err)
        self._hang, self.killed, self.wait_timeout = hang, False, None

    def wait(self, timeout=None):
        self.wait_timeout = timeout
        if self._hang and not self.killed:
            raise subprocess.TimeoutExpired(cmd="x", timeout=timeout)
        return -9 if self.killed else 0

    def kill(self):
        self.killed = True


def test_status_that_exits_zero_with_nothing_readable_is_also_a_failure():
    """The nonzero-exit branch was closed; exit ZERO with empty or reshaped output still parsed to
    zero standings and rendered every pack blank — which reads as "all quiet", the same disguise.
    No rows parsed is a failure, whatever the exit code said."""
    real = serve._tool
    for stdout in ("", "   \n\n", "unexpected banner\nno product rows here\n"):
        serve._tool = (lambda args, _o=stdout:
                       subprocess.CompletedProcess(args, 0, stdout=_o, stderr="")
                       if args[0] == "status.py" else real(args))
        try:
            assert serve._standings() is None, f"blank standings from {stdout!r} read as a board"
            status, body = serve.index()
        finally:
            serve._tool = real
        assert status == 503 and b"status unavailable" in body, \
            "an unreadable status must say so — 503, not a quiet 200 board"


def test_a_hung_tool_is_killed_and_the_500_names_it():
    # no timeout meant one hung tool held a request (and its thread) forever
    serve._proven() # resolve provenance before Popen is patched
    real, real_commit = serve.subprocess.Popen, serve.commit
    serve.subprocess.Popen = lambda *a, **k: _FakeProc(hang=True)
    serve.commit = lambda: serve.COMMIT # the per-request HEAD check must not hang too
    try:
        status, body = serve.suggest()
    finally:
        serve.subprocess.Popen, serve.commit = real, real_commit
    assert status == 500
    assert b"timed out" in body and b"knowledge_graph.py" in body, \
        "the timeout page must say WHICH tool timed out"


def test_tool_output_is_capped_in_memory_and_the_timeout_is_actually_passed():
    """`capture_output=True` collected a child's WHOLE stream before slicing — an external review
    measured ~200 MiB of peak RSS for a 64 MiB child to return 256 KiB. The reader is now
    incremental into capped buffers, so what _tool ever holds is bounded, and a runaway stream
    kills the child rather than draining it forever."""
    real = serve.subprocess.Popen
    procs = []
    def fake(*a, **k):
        p = _FakeProc(out=b"x" * (serve.TOOL_CAP + 4096), err=b"y" * (serve.TOOL_CAP + 4096))
        procs.append(p)
        return p
    serve.subprocess.Popen = fake
    try:
        r = serve._tool(["status.py"])
    finally:
        serve.subprocess.Popen = real
    assert procs and procs[0].wait_timeout == serve.TOOL_TIMEOUT, \
        "_tool must pass the timeout to the child wait"
    assert len(r.stdout) <= serve.TOOL_CAP and len(r.stderr) <= serve.TOOL_CAP, \
        "captured streams must be capped — a runaway tool must not balloon a response"
    assert r.stdout and r.stderr, "the caps must keep content, not drop the streams"
    # a stream past the runaway ceiling kills the child instead of draining it forever
    real2 = serve.subprocess.Popen
    big = _FakeProc(out=b"z" * (serve.TOOL_CAP * 64 + 65536 * 2))
    serve.subprocess.Popen = lambda *a, **k: big
    try:
        serve._tool(["status.py"])
    finally:
        serve.subprocess.Popen = real2
    assert big.killed, "a runaway stream must kill the child, not drain it to EOF"


def test_the_answer_page_has_no_field_for_a_signature():
    """The self-service surface removes the barrier to ANSWERING a decision and leaves the
    signature exactly where it was. If this page ever grows an `answered_by` input, a name typed
    into a browser starts standing where a person's committed signature used to, and every gate
    downstream reads it as evidence of an act nobody can be asked about.

    Asserted on the rendered page rather than on the composer, because the composer refusing a
    field and the FORM not offering it are two different promises and a user only sees one."""
    code, body = serve._answer_form(PACK, DECISION)
    assert code == 200, code
    page = body.decode("utf-8")
    assert "answered_by" in page, "the page does not tell the reader what it will not do"
    # ANY actor input, not two named ones: the point is that the form never offers a field whose
    # value would be a person or the date of their act, whatever it comes to be called.
    import re as _re
    pat = "name=[" + chr(34) + chr(39) + "]([a-z0-9_]+)"
    offered = set(_re.findall(pat, page))
    actors = {f for f in offered if f.endswith("_by")
              or f.endswith("_date")}
    assert not actors, ("the answer form offers an input for an actor field", actors)


def test_a_composed_answer_is_a_patch_and_not_a_write():
    """The app serves from the checkout and refuses to serve a dirty one, so a route that wrote
    would disable the app with its first use - and make a status surface able to change what it
    reports on. The route hands back a diff; a person applies and commits it."""
    import io as _io
    form = (REPO / PACK / "handoff" / "decision_answers" / (DECISION + ".yaml"))
    before = _io.open(str(form), encoding="utf-8").read()
    code, body = serve._answer_proposal(PACK, DECISION, "Confirmed for all five fields.",
                                        "RESOLVED")
    assert code == 200, code
    page = body.decode("utf-8")
    # A LITERAL BLOCK, because a register answer is prose: the composer only writes a bare
    # scalar for one unquoted word YAML cannot re-type.
    assert "+answer: |2-" in page and "+  Confirmed for all five fields." in page, (
        "the proposed change is not shown as a diff", page[:500])
    #...and the page says what is STILL UNSIGNED even though this request never tried to set it:
    # a person who simply types an answer must still be told the signature is theirs.
    assert "still unsigned" in page, page[:600]
    assert "answered_by" in page and "answer_date" in page, page[:600]
    assert _io.open(str(form), encoding="utf-8").read() == before, "the route wrote to the pack"


def test_only_the_status_the_page_can_keep_its_promise_for_is_offered():
    """The page tells the reader an unsigned terminal change will be refused downstream. That is
    true for RESOLVED and FALSE for the other two: `decision_record.form_errors` demands
    `answered_by` and `answer_date` only when the status is RESOLVED, so a WITHDRAWN composed here
    would pass the gate with nobody recorded behind it. SUPERSEDED additionally needs a
    `superseded_by` this page has no input for, so every one would be composed and then refused.

    Offering a control that produces an unattributable change is worse than offering nothing, so
    the other two stay hand edits until attribution covers all three terminal states alike.
    """
    import decision_record
    import inspect
    assert serve.DECISION_STATUSES == ("RESOLVED",), serve.DECISION_STATUSES
    for bad in ("WITHDRAWN", "SUPERSEDED", "resolved", "anything"):
        code, _b = serve._answer_proposal(PACK, DECISION, "x", bad)
        assert code == 400, (bad, code)

    #...AND THE REASON IS STILL TRUE OF THE VALIDATOR. If attribution is ever extended to every
    # terminal state this assertion fails, and the page can safely offer them again - the test
    # states WHY the restriction exists rather than merely pinning it in place.
    src = inspect.getsource(decision_record.form_errors)
    assert 'if st == "RESOLVED":' in src, (
        "attribution is no longer RESOLVED-only; the page may be able to offer the other states")


def test_an_oversized_submission_is_refused_not_truncated():
    """Clamping the read discarded the tail of a long answer and composed a diff from the part
    that fitted - a governed change quietly different from the one submitted, which is the exact
    failure this module exists to prevent. It must be a refusal with a status code."""
    import ast
    src = (REPO / "app" / "serve.py").read_text(encoding="utf-8")
    post = next(n for n in ast.walk(ast.parse(src))
                if isinstance(n, ast.FunctionDef) and n.name == "do_POST")
    codes = {c.value for c in ast.walk(post)
             if isinstance(c, ast.Constant) and isinstance(c.value, int)}
    assert 413 in codes, "an over-long submission is not refused with a status code"
    assert "POST_CAP" in ast.dump(post), "the cap is not consulted at all"
    #...and the length is no longer CLAMPED, which is what truncated instead of refusing
    assert not [c for c in ast.walk(post) if isinstance(c, ast.Call)
                and getattr(c.func, "id", "") == "min"], (
        "the body length is still clamped to the cap, which truncates rather than refuses")


def test_every_other_post_is_still_refused():
    """One POST route exists and it composes rather than writes. Everything else stays 405 - a
    window with one hand, not a window with hands."""
    import ast
    src = (REPO / "app" / "serve.py").read_text(encoding="utf-8")
    tree = ast.parse(src)
    post = next(n for n in ast.walk(tree)
               if isinstance(n, ast.FunctionDef) and n.name == "do_POST")
    routes = {c.value for c in ast.walk(post)
              if isinstance(c, ast.Constant) and isinstance(c.value, str)
              and c.value.startswith("/")}
    assert routes == {"/answer"}, ("do_POST accepts a route beyond /answer", routes)
    #...and nothing in the POST path writes to disk
    for n in ast.walk(post):
        if isinstance(n, ast.Call):
            fn = getattr(n.func, "attr", "") or getattr(n.func, "id", "")
            assert fn not in ("write_text", "write_bytes", "unlink", "mkdir", "rename"), fn


def test_pack_discovery_is_the_index_not_the_filesystem():
    """Git does not track directories: an untracked (or ignored) products/.../handoff directory
    used to read as a pack, appear on the board, and serve under the clean commit footer - an
    external review planted exactly that. Discovery now lists the INDEX, so a directory on disk
    that git does not hold founds nothing.

    PLANTED IN A TEMP REPOSITORY, NOT IN THE CHECKOUT. This used to mkdir
    products/oncology/zz_planted/202606/handoff inside the live tree and rmtree it in a
    `finally`, so an interrupted run left a fake pack sitting in products/ - the exact artefact
    the test exists to prove is ignored. `git ls-files` works in ANY repository, so a temp one
    exercises the real command, and pointing `serve.ROOT` at it keeps the checkout untouched.

    It is also a stronger check than the original: the tracked pack and the planted directory sit
    side by side in one repository, so "found nothing" cannot pass by finding nothing at all."""
    import shutil as _sh
    import subprocess as _sp
    import tempfile as _tf
    tmp = Path(_tf.mkdtemp())
    keep = serve.ROOT
    try:
        _sp.run(["git", "init", "-q"], cwd=str(tmp), check=True)
        tracked = tmp / "products" / "oncology" / "real" / "202606" / "handoff"
        tracked.mkdir(parents=True)
        (tracked / "DECISIONS.md").write_text("| ID |" + chr(10), encoding="utf-8")
        _sp.run(["git", "add", "-A"], cwd=str(tmp), check=True)
        _sp.run(["git", "-c", "user.email=t@example.invalid", "-c", "user.name=t",
                 "commit", "-qm", "packs"], cwd=str(tmp), check=True)

        #...and now the planted one, created AFTER the commit so git does not hold it
        planted = tmp / "products" / "oncology" / "zz_planted" / "202606" / "handoff"
        planted.mkdir(parents=True)
        (planted / "DECISIONS.md").write_text("| ID |" + chr(10), encoding="utf-8")

        serve.ROOT = str(tmp)
        got = serve.packs()
        assert "products/oncology/real/202606" in got, (
            "the TRACKED pack was not found, so the negative below proves nothing", got)
        assert "products/oncology/zz_planted/202606" not in got, (
            "an untracked directory founded a pack - discovery is reading the filesystem", got)
    finally:
        serve.ROOT = keep
        _sh.rmtree(tmp, ignore_errors=True)
    #...and the real checkout still finds every real, tracked pack
    assert PACK in serve.packs()
    assert not (Path(serve.ROOT) / "products" / "oncology" / "zz_planted").exists(), (
        "the checkout was planted in by a test that no longer needs to")


def test_error_pages_carry_the_tools_message_but_no_checkout_root_path():
    real = serve._tool
    def failing(args):
        return subprocess.CompletedProcess(
            args, 1, stdout="",
            stderr=f'File "{serve.ROOT}/platform/tools/knowledge_graph.py", line 7: boom')
    serve._tool = failing
    try:
        status, body = serve.knowledge("anything")
    finally:
        serve._tool = real
    assert status == 500
    assert serve.ROOT.encode() not in body, "error pages must not disclose where the checkout lives"
    assert b"boom" in body and b"platform/tools/knowledge_graph.py" in body, \
        "the tool's own message survives the scrub"


def test_unknown_provenance_is_a_refusal_on_every_route():
    # a governance window must tie every page to a merged commit; 'unknown' stamped in a footer
    # reads as a working page — so unknown is a 503, not a footer value
    saved = serve.COMMIT, serve.VERSION
    try:
        serve.COMMIT, serve.VERSION = "unknown", "1.0.0"
        for status, body in (serve.index(), serve.page("flow", PACK), serve.questions(PACK),
                             serve.knowledge("fued"), serve.suggest(), serve.portfolio()):
            assert status == 503
            assert b"cannot prove what is being served" in body
        serve.COMMIT, serve.VERSION = "abc1234", "unknown" # either axis unknown refuses
        status, body = serve.index()
        assert status == 503 and b"cannot prove what is being served" in body
    finally:
        serve.COMMIT, serve.VERSION = saved


def test_an_edited_checkout_or_a_moved_head_is_a_refusal_on_every_route():
    """The footer stamps a COMMIT and the pages render from the FILES. An external review edited
    the checkout under the running app and every page kept serving under the clean footer —
    stored content the stamped commit never contained. Provenance is now verified PER REQUEST:
    a dirty tree refuses, and a HEAD that moved since startup refuses (the operator restarts to
    serve the new commit honestly)."""
    assert isinstance(_REAL_DIRTY(), list), "_dirty must always answer with a list of paths"
    serve._proven() # pin the startup identity first
    saved_commit = serve.commit
    try:
        serve._dirty = lambda: [" M fixtures/oncology/prostate/202606/handoff/DECISIONS.md"]
        for status, body in (serve.index(), serve.page("flow", PACK), serve.knowledge("fued")):
            assert status == 503, "an edited checkout kept serving under a clean footer"
            assert b"cannot prove what is being served" in body
        serve._dirty = lambda: []
        serve.commit = lambda: "f00dfeed" # HEAD moved under the running app
        assert serve.COMMIT != "f00dfeed"
        status, body = serve.index()
        assert status == 503 and b"cannot prove what is being served" in body
    finally:
        serve._dirty, serve.commit = (lambda: []), saved_commit


def test_the_index_advertises_no_suggest_link_but_the_route_still_serves():
    _, body = serve.index()
    assert b"suggest" not in body.lower(), \
        "the front page must not advertise /suggest — its precision is indefensible there"
    status, body = serve.suggest()
    assert status == 200 and b"serving commit" in body, "the un-advertised route still serves"


def test_frame_is_minimal_but_accessible():
    b = serve._frame("a title", "<h1>x</h1>")
    assert b.startswith(b"<!doctype html><html lang='en'>"), "doctype and lang, for screen readers"
    assert b"name='viewport'" in b and b"width=device-width" in b, "usable on a phone"
    assert b"<main><h1>x</h1></main>" in b, "content wrapped so headings outline a document"
    assert b.rstrip().endswith(b"</html>")
    _, body = serve.index()
    assert b"<label for='q'>" in body and b"id='q'" in body, "the search input has a real label"


def test_a_repository_path_is_data_on_the_board_never_markup():
    """Pack paths reach the index from the filesystem, and an external review demonstrated stored
    markup injection through the one interpolation that trusted them. A pack directory named
    `<script>…` must render as its own strange name — escaped — never execute."""
    hostile = "products/oncology/<script>alert(1)</script>/202606"
    real = serve.packs
    serve.packs = lambda: [*real(), hostile]
    try:
        status, body = serve.index()
    finally:
        serve.packs = real
    assert status == 200
    assert b"<script>alert(1)</script>" not in body, "the pack path rendered as live markup"
    assert b"&lt;script&gt;" in body, "the hostile name must still be VISIBLE, escaped"


def test_the_portfolio_route_serves_the_committed_view_and_never_regenerates_it():
    """`portfolio_status.py` WRITES products/PORTFOLIO.md when it runs, and a GET must never
    write into the checkout — the app would refuse every later request over its own edit. So the
    route serves the COMMITTED copy, which `_proven()` ties to the served commit and CI keeps
    fresh (`portfolio_status --check` refuses a stale one)."""
    status, body = serve.portfolio()
    assert status == 200, (status, body[:200])
    committed = (REPO / "products" / "PORTFOLIO.md").read_text(encoding="utf-8")
    # a distinctive committed line survives into the page, escaped, not re-rendered
    line = next(l for l in committed.splitlines() if l.startswith("| **"))
    import html as _html # noqa: PLC0415
    assert _html.escape(line).encode() in body, "the page is not serving the committed table"
    #...and the board links to it
    _, index_body = serve.index()
    assert b"href='portfolio'" in index_body, "the board does not offer the portfolio view"
    #...and the route composed no write: rendering it twice yields identical bytes off the same
    # committed file, which a regenerating route could not promise on a moving tree
    assert serve.portfolio()[1] == body


def test_the_board_prices_the_decision_queue_in_the_tools_own_numbers():
    """The loop under-communicated the cost of waiting —
    "21 open decisions" read as a fact about a file, not as records nobody can finish. The line
    is held to `decision_report.blast_radius`'s OWN arithmetic, the same function that writes
    the ranked page, so the board and the page cannot disagree; a countdown the app composed
    from its own parsing would be a second implementation, free to flatter."""
    sys.path.insert(0, str(FRAMEWORK / "tools"))
    import decision_report # noqa: PLC0415
    blocks, _t, _i, status = decision_report.blast_radius(str(REPO / PACK))
    assert status, "the fixture pack lost its decision register; this test needs one"
    n_open = sum(1 for v in status.values() if v == "OPEN")
    blocked = {v for vs in blocks.values() for v in vs}
    line = serve._countdown(PACK)
    assert line and line.startswith(f"{n_open} open decision(s)"), (line, n_open)
    assert f"{len(blocked)} record(s) blocked" in line, (line, len(blocked))
    # the top-3 clause appears exactly when something is blocked, and frees no more than the total
    if blocked:
        import re as _re # noqa: PLC0415
        m = _re.search(r"frees (\d+)$", line)
        assert m and int(m.group(1)) <= len(blocked), line
    #...and the board carries the line for the pack
    _, body = serve.index()
    assert line.encode() in body, "the countdown is computed but the board does not show it"
    # a pack with no register shows NOTHING rather than a zero — no queue and an empty queue are
    # different answers
    assert serve._countdown("fixtures/oncology/dlbcl/YYYYMM") is None


def test_the_start_page_teaches_the_journey_in_the_docs_own_words():
    """/start is the new-user landing: everything it says about the journey is QUOTED from
    docs/CHAT_JOURNEY.md, its pack rows are computed by the board's own functions, and repo
    placeholders render as text, never markup."""
    status, body = serve.start()
    assert status == 200
    text = body.decode("utf-8")
    # the four turns, verbatim from the doc — quoting, never paraphrase
    for turn in ("where do we stand", "what do you need from me",
                 "The person types their answers", "the answers are in"):
        assert turn in text, turn
    # the standalone chat-page command comes from the doc's own code line
    doc = (REPO / "docs" / "CHAT_JOURNEY.md").read_text(encoding="utf-8")
    cmd = next(l.strip() for l in doc.splitlines()
               if "chat_demo.py" in l and l.strip().startswith("python"))
    assert cmd in text, "the chat_demo command on the page must be the doc's own line"
    # `<pack>/handoff/` in the doc is prose about the repository, not markup
    assert "&lt;pack&gt;" in text and "<pack>/handoff" not in text
    # a pack with a live register is somewhere to start: countdown + the questions link —
    # the same numbers and the same target the board shows, so the two cannot disagree
    q = __import__("urllib.parse", fromlist=["quote"]).quote(PACK)
    assert serve._countdown(PACK) in text and f"questions?pack={q}" in text
    # a pack WITHOUT a register is named as one, with the honest answer chat will give —
    # the exact confusion (a scaffold period asked for its questions) this page exists to end
    assert "fixtures/oncology/gist/202608" in text and "no decision register" in text
    # the full journey table rides along, and the boundary paragraph closes the page
    assert "<details>" in text and "have we decided something like this before" in text
    assert "make the human act tiny and exactly located" in text
    #...and the board's front page hands a new user the door
    _, board = serve.index()
    assert b"href='start'" in board, "a new user landing on the board never finds /start"
    # the route is wired — the handler's router names it, not only the function
    src = (REPO / "app" / "serve.py").read_text(encoding="utf-8")
    assert '"/start"' in src, "/start fell off the router"


def test_a_moved_journey_doc_is_said_out_loud_never_paraphrased():
    """The start page has no hand-written copy of the journey to fall back on: gut the doc and
    every section must ANNOUNCE the absence — a silently empty section, or one quietly filled
    from this app's imagination, is the paraphrase the page exists to refuse."""
    j = serve._journey_parse("# t" + chr(10) * 2 + "Only an intro survives the gutting." + chr(10))
    text = serve._start_body(j)
    assert text.count("will not paraphrase") == 0 # wording lives in _gone(); count the alerts
    assert text.count("role='alert'") == 3, "loop, table and boundary must each announce"
    assert "Only an intro survives" in text
    assert "where do we stand" not in text, "the loop rendered without a doc to quote"
    #...and content genuinely flows FROM the doc text: a synthetic doc's words surface
    synthetic = (
        "# x" + chr(10) * 2 + "Intro sentence Z9." + chr(10) * 2
        + "## One loop, one thing on screen" + chr(10) * 2 + "Lead L9." + chr(10) * 2
        + '1. **"turn one Q9"** -> page P9.' + chr(10) * 2
        + "## The journey, as chat" + chr(10) * 2
        + "| you type | what runs | what you get |" + chr(10)
        + "|---|---|---|" + chr(10)
        + '| "probe R9" | `tool9.py` | out O9 |' + chr(10) * 2
        + "## What chat deliberately cannot do" + chr(10) * 2 + "Boundary B9." + chr(10))
    text2 = serve._start_body(serve._journey_parse(synthetic))
    for marker in ("Z9", "turn one Q9", "probe R9", "<code>tool9.py</code>", "out O9",
                   "Boundary B9", "Lead L9"):
        assert marker in text2, marker
    assert "role='alert'" not in text2, "a complete doc must raise no absence alerts"


def test_cold_paths_are_paid_once_and_shared():
    """External review: the cold flow render (78.42s) exceeded the old 60s cap — a
    guaranteed 500 for a new user — and concurrent requests each spawned their own
    subprocess, starving each other past the timeout. The heavy routes now compute once
    per (commit, tool, route), single-flight: concurrent requests share ONE computation,
    a later visit is byte-identical without a new tool run, and a failure is retried,
    never remembered."""
    import threading as _threading
    import time as _time
    serve._proven()
    calls = []

    def slow(args):
        calls.append(args[0])
        _time.sleep(0.3)
        out = args[args.index("--out") + 1]
        open(out, "w", encoding="utf-8").write("<html><body>rendered</body></html>")
        return subprocess.CompletedProcess(args, 0, stdout="", stderr="")

    real = serve._tool
    serve._tool = slow
    try:
        results = [None] * 4

        def hit(i):
            results[i] = serve.page("flow", PACK)

        ts = [_threading.Thread(target=hit, args=(i,)) for i in range(4)]
        for t in ts:
            t.start()
        for t in ts:
            t.join(20)
        assert calls.count("render_html.py") == 1, \
            f"four concurrent requests ran the tool {calls.count('render_html.py')} times"
        assert results[0] and results[0][0] == 200 and all(r == results[0] for r in results)
        assert serve.page("flow", PACK) == results[0], "a later visit must reuse the bytes"
        assert calls.count("render_html.py") == 1, "the memo ran the tool again"
    finally:
        serve._tool = real
    # a FAILURE is remembered only briefly (FAIL_TTL): the requests already queued behind
    # it get the honest failure instantly instead of each re-running a three-minute
    # attempt — the review measured exactly that storm — and after the TTL a retry is fresh
    flips = {"n": 0}

    def flaky(args):
        flips["n"] += 1
        if flips["n"] == 1:
            return subprocess.CompletedProcess(args, 124, stdout="", stderr="timed out")
        out = args[args.index("--out") + 1]
        open(out, "w", encoding="utf-8").write("<html><body>second try</body></html>")
        return subprocess.CompletedProcess(args, 0, stdout="", stderr="")

    serve._tool = flaky
    try:
        s1, _b = serve.page("flow", PACK)
        s_held, _b2 = serve.page("flow", PACK)
        assert flips["n"] == 1, "a request behind a fresh failure re-ran the whole attempt"
        serve._MEMO_FAIL.clear() # the TTL elapses; the next visit retries
        s2, b2 = serve.page("flow", PACK)
    finally:
        serve._tool = real
    assert s1 == 500 and s_held == 500 and s2 == 200 and b"second try" in b2, \
        (s1, s_held, s2)


def test_warm_start_precomputes_the_startable_packs_and_ready_reports_honestly():
    """The unassisted first visitor must land on warm bytes: _warm() renders the board
    standings and each STARTABLE pack's flow + questions pages once at startup — the packs
    with a decision register, the same set the start page leads with; warming every
    scaffold serialized ~24 heavy renders behind the first visitor. /ready is 503 until the pass finishes and 200 after, 'ready' is
    logged only for pages whose bytes actually entered the cache, and a warm FAILURE is
    logged as one — the first version printed 'ready' unconditionally after a timeout."""
    serve._proven()
    calls = []

    def fake(args):
        calls.append(args[0])
        if args[0] == "status.py":
            return subprocess.CompletedProcess(
                args, 0, stdout=f"{PACK}   Gate 1   3 open", stderr="")
        out = args[args.index("--out") + 1]
        open(out, "w", encoding="utf-8").write("<html><body>warmed</body></html>")
        return subprocess.CompletedProcess(args, 0, stdout="", stderr="")

    real = serve._tool
    serve._tool = fake
    serve._WARM.update(done=False, failed=0, log=[])
    try:
        status, body = serve.ready()
        assert status == 503 and b"still warming" in body, \
            "readiness must not be claimed before the warm pass finishes"
        serve._warm()
        startable = [p for p in serve.packs() if serve._countdown(p)]
        assert PACK in startable, "the reference fixture must be a startable pack"
        n = len(startable)
        assert calls.count("status.py") == 1, calls
        assert calls.count("render_html.py") == n and \
            calls.count("decision_packet.py") == n, (n, calls)
        status, body = serve.page("flow", PACK)
        assert status == 200 and b"warmed" in body
        assert calls.count("render_html.py") == n, "the route re-ran what warm precomputed"
        status, body = serve.ready()
        assert status == 200 and b"flow + questions ready" in body, body[:400]
    finally:
        serve._tool = real
    #...and a warm pass whose renders FAIL says so — never "ready" after a timeout, and
    # /ready must NOT answer 200 for a pass that merely FINISHED (the review forced every
    # warm render to fail and /ready still said 200: readiness is success, not completion)
    def dead(args):
        if args[0] == "status.py":
            return subprocess.CompletedProcess(
                args, 0, stdout=f"{PACK}   Gate 1   3 open", stderr="")
        return subprocess.CompletedProcess(args, 124, stdout="", stderr="timed out")

    serve._tool = dead
    serve._WARM.update(done=False, failed=0, log=[])
    try:
        serve._warm()
        status, body = serve.ready()
    finally:
        serve._tool = real
    joined = "\n".join(serve._WARM["log"])
    assert "FAILED" in joined and "flow + questions ready" not in joined, joined
    assert status == 503 and b"failure" in body, \
        (status, "a finished-but-failed warm pass claimed readiness")


def _with_snapshot(raw, fn):
    """Run fn() with a snapshot file on disk and the env var pointing at it, then clean up."""
    import json as _json
    import tempfile as _tf
    d = _tf.mkdtemp()
    path = os.path.join(d, "snap.json")
    with open(path, "w", encoding="utf-8") as fh:
        fh.write(raw if isinstance(raw, str) else _json.dumps(raw))
    save_env = os.environ.get(serve.SNAPSHOT_ENV)
    save_proven, save_memo = serve._proven, serve._MEMO
    os.environ[serve.SNAPSHOT_ENV] = path
    serve._proven = lambda: True
    serve._MEMO = {}                       # a fresh memo, so each case really loads
    # THE CHECKOUT'S PACK SET IS STUBBED TO THE SNAPSHOT'S. The reader compares the two in both
    # directions on purpose, so an unstubbed test snapshot is refused for naming packs this tree
    # does not hold — which is the check working, not the page failing. Stubbing discovery lets
    # these tests exercise the RENDERING; the comparison itself is pinned in
    # test_governance_snapshot.py, where it belongs.
    sys.path.insert(0, str(FRAMEWORK / "tools"))
    import governance_snapshot as _gs                                  # noqa: PLC0415
    save_packs = _gs.packs
    try:
        import json as _j
        _covered = _j.loads(raw)["packs"] if not isinstance(raw, str) else {}
    except Exception:                                                  # noqa: BLE001
        _covered = {}
    if isinstance(raw, dict):
        _covered = dict(raw.get("packs") or {})
        _covered.update(raw.get("unreadable") or {})
    _gs.packs = lambda root=None: [(p, "fixture") for p in _covered]
    try:
        return fn()
    finally:
        _gs.packs = save_packs
        serve._proven, serve._MEMO = save_proven, save_memo
        if save_env is None:
            os.environ.pop(serve.SNAPSHOT_ENV, None)
        else:
            os.environ[serve.SNAPSHOT_ENV] = save_env


def _good_snapshot(commit):
    return {"schema": 1,
            "provenance": {"commit": commit, "commit_short": commit[:7], "dirty": False,
                           "generated_at": "2026-08-30T00:00:00+00:00"},
            "owners": {"1": "Science (supplies the specification)", "2": "DataExpert"},
            "packs": {"fixtures/oncology/demo/202601": {
                "kind": "fixture",
                "gates": [{"gate": 1, "name": "approved inputs", "status": "in progress",
                           "blockers": ["Gate 1: source is provisional, not approved"],
                           "approval": {"required": True, "form": "handoff/X.yaml",
                                        "approved_by": None}}],
                "measures": {}, "demonstrated": [], "records": {},
                "next_action": "register the source"}},
            "unreadable": {"fixtures/oncology/broken/202601": "ValueError: register will not parse"}}


def test_no_snapshot_configured_says_so_rather_than_pretending():
    """Unset is not an error — the app computes as it always has — but the page must not imply it
    is showing precomputed truth when nothing is configured."""
    save_env, save_proven = os.environ.get(serve.SNAPSHOT_ENV), serve._proven
    os.environ.pop(serve.SNAPSHOT_ENV, None)
    serve._proven = lambda: True
    try:
        status, body = serve.gates("")
        assert status == 200, status
        assert b"No snapshot is configured" in body, body[:400]
    finally:
        serve._proven = save_proven
        if save_env is not None:
            os.environ[serve.SNAPSHOT_ENV] = save_env


def test_a_broken_snapshot_refuses_and_never_falls_back_to_computing():
    """THE RULE THIS PAGE TURNS ON. Falling back would make a stale or corrupt snapshot
    indistinguishable from a healthy one: the app looks fine, the job is silently dead, and nobody
    finds out until the numbers on screen are wrong. Configured means promised; a broken promise
    is said out loud, with the reason."""
    for name, raw in (("unparseable", '{"schema": 1, "packs": {'),
                      ("wrong type", "[]"),
                      ("empty", "")):
        status, body = _with_snapshot(raw, lambda: serve.gates(""))
        assert status == 503, f"{name} snapshot returned {status}, not a refusal"
        assert b"cannot be trusted" in body, name
        assert b"No snapshot is configured" not in body, \
            f"{name} silently degraded to the unconfigured page"


def test_a_snapshot_from_another_commit_is_refused_by_the_page():
    """It describes a different tree. Rendering it under this page's clean provenance footer is
    exactly what _proven() exists to prevent, arriving by another door."""
    status, body = _with_snapshot(_good_snapshot("b" * 40), lambda: serve.gates(""))
    assert status == 503, status
    assert b"cannot be trusted" in body


def test_the_journey_renders_from_the_snapshot_and_badges_a_fixture():
    """A fixture must never read as production — the standing positioning is a governed factory
    awaiting its first authenticated live deployment, and a page that showed exercise material
    without saying so would undo that in one screenshot."""
    commit = serve._provenance()[0]

    def go():
        st, body = serve.gates("")
        assert st == 200, st
        assert b"reference fixture" in body, "a fixture was listed without its warning"
        assert b"COULD NOT BE READ" in body, "an unreadable pack vanished from the board"
        st2, b2 = serve.gates("fixtures/oncology/demo/202601")
        assert st2 == 200, st2
        assert b"Gate 1" in b2 and b"approved inputs" in b2
        assert b"source is provisional" in b2, "the blocker was not shown"
        assert b"Science (supplies the specification)" in b2, "who acts was not shown"
        assert b"not signed" in b2, "an unsigned approval did not say so"
        assert b"register the source" in b2, "the next action was not shown"
        return True

    assert _with_snapshot(_good_snapshot(commit), go)


def _snapshot_with_statuses(commit, statuses):
    """A snapshot whose gates carry exactly `statuses`, one gate each."""
    return {"schema": 1,
            "provenance": {"commit": commit, "commit_short": commit[:7], "dirty": False,
                           "generated_at": "2026-08-30T00:00:00+00:00"},
            "owners": {str(i + 1): "someone" for i in range(len(statuses))},
            "packs": {"fixtures/oncology/demo/202601": {
                "kind": "fixture",
                "gates": [{"gate": i + 1, "name": "gate %d" % (i + 1), "status": st,
                           "blockers": [], "approval": {"required": False}}
                          for i, st in enumerate(statuses)],
                "measures": {}, "demonstrated": [], "records": {},
                "next_action": [2, "DataExpert (drafts and QCs)", "answer the open decisions (24 open)"]}},
            "unreadable": {}}


def test_no_gate_status_is_ever_drawn_as_a_completed_one_unless_it_is():
    """MEASURED ON THE FIRST REAL RENDER, not imagined. Gate 6 came back `blocked` and drew the
    SAME filled circle as `done`, because `blocked` was absent from GATE_MARK and the fallback was
    that circle. Thirteen gates across the estate are blocked right now, so the page was drawing a
    stop as a completion on live content — the one direction a governance status bug must never
    point.

    The rule is stronger than "add blocked": NO status may share the done glyph unless it IS done,
    including one this table has never been taught. An unknown state renders as a question mark and
    its own literal word, visibly untranslated rather than flattered into the nearest good glyph.
    """
    commit = serve._provenance()[0]
    done_mark = serve.GATE_MARK["done"]

    def go():
        _, body = serve.gates("fixtures/oncology/demo/202601")
        text = body.decode("utf-8")
        # every gate block, split on the heading marker
        for status in ("blocked", "not started", "in progress", "a state nobody defined"):
            i = text.find(">%s<" % status) if False else text.find(status)
            assert i != -1, "status %r never reached the page" % status
        # the done glyph must appear exactly as many times as there are done gates: zero here
        assert text.count(done_mark) == 0, (
            "the done glyph appeared %d time(s) on a page with no done gate — a non-done status "
            "is being drawn as completed" % text.count(done_mark))
        assert serve.GATE_MARK_UNKNOWN in text, "an unknown status did not render its own marker"
        return True

    assert _with_snapshot(
        _snapshot_with_statuses(commit, ["blocked", "not started", "in progress",
                                         "a state nobody defined"]), go)


def test_a_done_gate_still_draws_as_done():
    """The control for the test above: without it, that one passes by never drawing anything."""
    commit = serve._provenance()[0]

    def go():
        _, body = serve.gates("fixtures/oncology/demo/202601")
        assert serve.GATE_MARK["done"] in body.decode("utf-8"), "a done gate lost its mark"
        return True

    assert _with_snapshot(_snapshot_with_statuses(commit, ["done"]), go)


def test_the_next_action_is_prose_and_not_a_python_literal():
    """status.next_action() returns the TRIPLE (gate, who, what), which JSON carries as a list.
    str() on it printed `[2, 'DataExpert (drafts and QCs)', 'answer the open decisions (24 open)']` onto
    the page, brackets and quotes included, on the very first render."""
    commit = serve._provenance()[0]

    def go():
        _, body = serve.gates("fixtures/oncology/demo/202601")
        text = body.decode("utf-8")
        assert "answer the open decisions (24 open)" in text, "the action itself is missing"
        assert "Gate 2" in text, "the gate it belongs to is missing"
        for literal in ("[2,", "&#x27;DataExpert", "['", "']"):
            assert literal not in text, "a Python literal reached the page: %r" % literal
        return True

    assert _with_snapshot(_snapshot_with_statuses(commit, ["blocked"]), go)


def test_the_page_offers_no_way_to_sign_anything():
    """The window has no hands. The gate page displays approval STATE and must never grow a
    control that records one."""
    commit = serve._provenance()[0]

    def go():
        st, body = serve.gates("fixtures/oncology/demo/202601")
        # ASSERT THE 200 FIRST. Without it this passed on the 503 refusal page, which carries no
        # form either — a test that is satisfied by the page failing to render proves nothing.
        assert st == 200, f"expected the rendered journey, got {st}"
        low = body.lower()
        for forbidden in (b"<form", b"<input", b"<button", b"approved_by=", b"sign this"):
            assert forbidden not in low, f"the gate page grew {forbidden!r}"
        return True

    assert _with_snapshot(_good_snapshot(commit), go)


if __name__ == "__main__":
    bad = 0
    for name, fn in sorted(globals().items()):
        if name.startswith("test_") and callable(fn):
            try:
                fn()
                print(f"  ok  {name}")
            except Exception as e: # noqa: BLE001 - report and continue
                bad += 1
                print(f"FAIL  {name}: {e}")
    sys.exit(1 if bad else 0)
