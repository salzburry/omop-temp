"""The EDA evidence must count what sits BETWEEN tables, and never carry a patient.

Run: python3 platform/tests/test_eda_report.py (or pytest). Spark parts skip without pyspark.
"""
import json
import sys
from datetime import date
from pathlib import Path

FRAMEWORK = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(FRAMEWORK))
sys.path.insert(0, str(FRAMEWORK / "tools"))

import eda_report                                                     # noqa: E402

try:
    from pyspark.sql import SparkSession
except Exception:
    SparkSession = None

_SPARK = None


def _spark():
    global _SPARK
    if _SPARK is None:
        sys.path.insert(0, str(FRAMEWORK / "tests" / "fixtures"))
        import synthetic_sources
        _SPARK = synthetic_sources.session("eda-test")
    return _SPARK


def test_the_layers_compose_and_no_patient_id_survives():
    """The full stack on OC's synthetic fixtures: inventory per role, relationships vs the index
    source, temporal counts, funnel from telemetry, output contract over the built ADS — and the
    serialised report carries no patient id."""
    if SparkSession is None:
        print("SKIP (pyspark absent)")
        return
    sys.path.insert(0, str(FRAMEWORK / "tests" / "fixtures"))
    import synthetic_sources
    from engine.config import load_config, product_config
    from engine import build_ads, telemetry
    cfg = load_config(product_config(FRAMEWORK.parent / "fixtures", "oc"),
                      overrides={"run.refresh": "t", "run.source_schema": "t",
                                 "run.output_schema": "t"})
    src = synthetic_sources.sources(_spark(), cfg)
    t = telemetry.StageTelemetry()
    ads = build_ads.build_from_sources(src, cfg, telemetry=t)
    # LAYER 6 RUNS ON A SMALL ADS-SHAPED FRAME, deliberately. Running the output contract over the
    # full union ADS — whose plan embeds every cohort's whole pipeline — on TOP of the queued
    # telemetry plans blew the shared 3g driver's heap in the sweep (OutOfMemoryError at the
    # contract's collect) and took 76 downstream Spark tests with it. On a cluster the driver is
    # not 3g; in this harness the layer's COMPOSITION is what needs proving, and a small frame
    # proves it.
    small = _spark().createDataFrame(
        [("p1", "2020-01-01", "Overall OC", 1, "202606")],
        "patientid string, index_date string, cohort string, cohortn int, spec_version string")
    doc = eda_report.eda(_spark(), src, cfg, telemetry_report=t.report(), ads=small)
    ly = doc["layers"]
    assert set(ly["inventory"]) == set(src), "a source fell out of the inventory"
    assert all(v["rows"] >= 1 for v in ly["inventory"].values() if "rows" in v)
    non_index = set(src) - {cfg.index_source}
    assert set(ly["relationships"]) == non_index
    assert ly["funnel"]["stages"], "the funnel lost the stage telemetry"
    assert "passed" in ly["ads_output"], "the output contract did not run over the ADS"
    assert ads.columns, "the telemetered build itself must still produce an ADS"
    flat = json.dumps(doc)
    for pid in ("p1", "pc2", "pc4"):
        assert f'"{pid}"' not in flat, f"patient id {pid} reached the EDA report"
    # GOVERNED-ARTIFACT SHAPE: self-declared restricted (counts derived from vendor data), no
    # top-level verdict (evidence, like stage_telemetry), and serialized() hashes the exact
    # bytes it returns — the digest the runner records under artifacts and the manifest signs.
    assert doc["classification"]["state"] == "restricted_derived"
    assert "passed" not in doc, "a top-level verdict appeared on evidence"
    import hashlib
    raw, digest = eda_report.serialized(doc)
    assert hashlib.sha256(raw).hexdigest() == digest
    assert json.loads(raw.decode("utf-8")) == json.loads(json.dumps(doc))


def test_temporal_counts_flag_impossible_dates_and_stay_zero_on_clean_ones():
    """Both directions on a hand-built frame: one pre-1900 date and one after study end are
    counted; the clean column counts zero everywhere."""
    if SparkSession is None:
        print("SKIP (pyspark absent)")
        return
    from pyspark.sql import functions as F
    s = _spark()
    df = s.createDataFrame(
        [("p1", date(1899, 12, 31), date(2020, 1, 1)),
         ("p2", date(2099, 1, 1), date(2020, 2, 1)),
         ("p3", None, date(2020, 3, 1))],
        "patientid string, baddate date, gooddate date")

    class _Cfg:
        study = {"index_end": "2025-12-31"}
        sources = {"x": "t_x"}
        index_source = "x"
        data_product_id = "eda_fixture"
        raw = {}
        index_dates = {}
    cfg = _Cfg()
    import engine.validate as ev
    real = ev.required_columns
    ev.required_columns = lambda c: {"x": ["patientid", "baddate", "gooddate"]}
    try:
        doc = eda_report.eda(s, {"x": df}, cfg)
    finally:
        ev.required_columns = real
    t = doc["layers"]["temporal"]["x"]
    assert t["baddate"] == {"null": 1, "unparseable": 0, "before_1900": 1, "after_study_end": 1}, t
    assert t["gooddate"] == {"null": 0, "unparseable": 0, "before_1900": 0, "after_study_end": 0}, t


def test_the_report_refuses_to_land_inside_the_checkout():
    if SparkSession is None:
        print("SKIP (pyspark absent)")
        return
    try:
        eda_report.main(["fixtures/oncology/oc/202606", "--synthetic",
                         "--out-dir", str(FRAMEWORK.parent / "somewhere")])
    except SystemExit as e:
        assert "inside the checkout" in str(e)
    else:
        raise AssertionError("an in-checkout out-dir was accepted")


if __name__ == "__main__":
    bad = 0
    for name, fn in sorted(globals().items()):
        if name.startswith("test_") and callable(fn):
            try:
                fn()
                print(f"  ok  {name}")
            except Exception as e:                   # noqa: BLE001 - report and continue
                bad += 1
                print(f"FAIL  {name}: {e}")
    sys.exit(1 if bad else 0)
