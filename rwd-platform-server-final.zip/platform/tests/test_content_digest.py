"""What a build PUBLISHED, as a digest — the right-hand side of the reproduction question.

`reproduction_id` says two runs received the same inputs. Nothing said they produced the same
content, so "reproducible" was a claim about one side of an equation with no other side. This is
the other side, and the two are kept strictly independent: same inputs with a different content
digest is a real finding, and it can only BE a finding if neither is computed from the other.

THE CONTRACT IS ONE SENTENCE. The digest is a function of the published cells and of nothing else
— not the clock, the run id, the build id, the engine version, the file layout, the partitioning,
the executor count, or the assistant layer. A rewritten pipeline that publishes the same values
must agree with the run before it. A helper tool changing must leave it untouched.

THE COMBINE IS ADDITION, AND THAT IS A CORRECTNESS CHOICE. Delta promises no physical row order,
so a repartition or a different shuffle reorders rows on identical data; a digest that sorted
first would be exact and cost a full shuffle every build. Addition is commutative, so no sort and
no ordering assumption. XOR is the other obvious commutative combine and it is WRONG here: two
identical rows XOR to zero, so a build that duplicated every patient would produce the digest of
an empty table.

NULL IS NOT EMPTY AND 1 IS NOT "1". A join silently dropping to null is the most common way a
build goes wrong quietly, and a column delivered as a string instead of an integer passes every
name-based check. Neither may pass through the digest unnoticed.

NO PYTEST FIXTURES AND NO `parametrize` — CI runs every suite as a script.

Run: python3 tests/test_content_digest.py (or pytest).
"""
import copy
import hashlib
import random
import sys
from pathlib import Path

FRAMEWORK = Path(__file__).resolve().parent.parent
REPO = FRAMEWORK.parent
sys.path.insert(0, str(FRAMEWORK))

from engine import content_digest as cd  # noqa: E402

COLS = ["patientid", "cohortn", "index_date", "os", "ecog"]
ROWS = [{"patientid": f"p{i}", "cohortn": i % 3, "index_date": "2026-01-01",
         "os": 12.5 + i, "ecog": None if i % 4 == 0 else i % 5} for i in range(120)]


def base():
    return cd.content_digest(ROWS, COLS)["digest"]


# --- stable across runs and across row order -----------------------------------------------------

def test_fifteen_runs_over_reshuffled_rows_agree():
    """The literal ask: the same content, fifteen times, arriving in a different order each time.
    Delta promises no physical row order, so this is the ordinary case rather than a stress test."""
    want = base()
    rng = random.Random(20260821)
    for _ in range(15):
        shuffled = list(ROWS)
        rng.shuffle(shuffled)
        assert cd.content_digest(shuffled, COLS)["digest"] == want


def test_the_digest_carries_the_row_count_too():
    got = cd.content_digest(ROWS, COLS)
    assert got["rows"] == len(ROWS)
    assert got["canon_version"] == cd.CANON_VERSION


def test_an_empty_table_has_a_digest_and_it_is_not_an_error():
    got = cd.content_digest([], COLS)
    assert got["rows"] == 0 and len(got["digest"]) == 64
    assert got["digest"] != base()


# --- sensitive to everything that is a real change -----------------------------------------------

def test_one_changed_cell_changes_the_digest():
    rows = copy.deepcopy(ROWS)
    rows[7]["os"] = rows[7]["os"] + 0.0001
    assert cd.content_digest(rows, COLS)["digest"] != base()


def test_a_value_dropping_to_null_changes_the_digest():
    """The most common way a build goes wrong quietly: a join that silently stops matching."""
    rows = copy.deepcopy(ROWS)
    rows[3]["ecog"] = None
    assert cd.content_digest(rows, COLS)["digest"] != base()


def test_null_and_empty_string_are_different():
    a = cd.content_digest([{"x": None}], ["x"])["digest"]
    b = cd.content_digest([{"x": ""}], ["x"])["digest"]
    c = cd.content_digest([{"x": "None"}], ["x"])["digest"]
    assert len({a, b, c}) == 3


def test_an_integer_delivered_as_a_string_changes_the_digest():
    """A schema drift no name-based check can see."""
    assert cd.content_digest([{"x": 1}], ["x"])["digest"] != \
        cd.content_digest([{"x": "1"}], ["x"])["digest"]


def test_a_boolean_is_not_an_integer():
    """`True == 1` in Python, so the encoder must tag it before the int branch or they collide."""
    assert cd.content_digest([{"x": True}], ["x"])["digest"] != \
        cd.content_digest([{"x": 1}], ["x"])["digest"]


def test_a_duplicated_row_changes_the_digest():
    """XOR would cancel it and report the digest of a table missing both copies."""
    assert cd.content_digest(ROWS + [ROWS[0]], COLS)["digest"] != base()


def test_two_rows_swapping_a_value_changes_the_digest():
    """Aggregates are invariant under this; the whole point of a per-row digest is that it is not."""
    rows = copy.deepcopy(ROWS)
    rows[1]["ecog"], rows[2]["ecog"] = rows[2]["ecog"], rows[1]["ecog"]
    if rows[1]["ecog"] != rows[2]["ecog"]:
        assert cd.content_digest(rows, COLS)["digest"] != base()


def test_swapping_two_columns_changes_the_digest():
    """The column name is inside the cell, or two same-typed columns could trade places unseen."""
    swapped = [{**r, "cohortn": r["ecog"], "ecog": r["cohortn"]} for r in ROWS]
    assert cd.content_digest(swapped, COLS)["digest"] != base()


def test_a_dropped_column_changes_the_digest():
    assert cd.content_digest(ROWS, [c for c in COLS if c != "ecog"])["digest"] != base()


def test_cell_encoding_is_unambiguous_across_a_boundary():
    """Without a length prefix, ("ab","c") and ("a","bc") hash alike."""
    a = cd.content_digest([{"p": "ab", "q": "c"}], ["p", "q"])["digest"]
    b = cd.content_digest([{"p": "a", "q": "bc"}], ["p", "q"])["digest"]
    assert a != b


# --- independent of everything about HOW it was produced -----------------------------------------

def test_the_digest_reads_nothing_but_the_cells():
    """The property that lets the assistant layer, the engine or the whole pipeline change freely:
    if the published values are the same, this must not move. Asserted at source, because the
    danger is a future edit reaching for a version or a clock 'for completeness'."""
    src = (FRAMEWORK / "engine" / "content_digest.py").read_text(encoding="utf-8")
    body = "\n".join(ln for ln in src.splitlines()
                     if not ln.strip().startswith("#") and '"""' not in ln)
    for banned in ("datetime", "time.", "ENGINE_VERSION", "uuid", "getenv", "environ",
                   "git", "build_id", "random"):
        assert banned not in body, (
            f"content_digest reads {banned!r} — the digest must be a function of the published "
            f"cells and of nothing else, or a changed helper layer moves it")


def test_it_is_not_derived_from_the_reproduction_id_or_the_reverse():
    """Two independent witnesses, or 'same inputs but different content' can never be observed."""
    import ast                                                           # noqa: PLC0415
    from engine import refresh                                           # noqa: PLC0415
    assert "content" not in refresh.REPRODUCTION_INPUTS
    assert "content" in (refresh.build_manifest.__kwdefaults__ or {})
    # THE DEPENDENCY, NOT THE WORD. The docstring names `reproduction_id` to explain how the two
    # relate, and a guard that forbade the string would force that explanation out of the file —
    # the same trade `test_grain.py` refused for its own guard. Only a real import counts.
    src = (FRAMEWORK / "engine" / "content_digest.py").read_text(encoding="utf-8")
    imported = set()
    for node in ast.walk(ast.parse(src)):
        if isinstance(node, ast.ImportFrom):
            imported.add(node.module or "")
        elif isinstance(node, ast.Import):
            imported.update(a.name for a in node.names)
    assert not any("refresh" in m for m in imported), (
        f"content_digest imports {sorted(imported)} — it must not depend on the manifest, or "
        f"'same inputs, different content' stops being observable")


def test_the_canon_version_is_inside_the_digest():
    """A future change to the encoding must make digests differ rather than silently compare equal
    under a changed definition of equality."""
    real = cd.CANON_VERSION
    try:
        got = cd.content_digest(ROWS, COLS)["digest"]
        cd.CANON_VERSION = real + "x"
        assert cd.content_digest(ROWS, COLS)["digest"] != got
    finally:
        cd.CANON_VERSION = real


# --- the Spark path mirrors the pure one ---------------------------------------------------------

def test_the_four_lane_recombination_is_exact():
    """Spark has no 256-bit integer, so the sum is carried in four 64-bit lanes and recombined on
    the driver. If that arithmetic is off by a shift the two implementations silently disagree."""
    for seed in ("a", "b", "some row", "another"):
        h = hashlib.sha256(seed.encode()).hexdigest()
        lanes = [int(h[i * 16:(i + 1) * 16], 16) for i in range(4)]
        rebuilt = 0
        for i in range(4):
            rebuilt += lanes[i] << (64 * (3 - i))
        assert rebuilt == int(h, 16), seed


def test_the_spark_path_uses_the_same_constants():
    src = (FRAMEWORK / "engine" / "content_digest.py").read_text(encoding="utf-8")
    assert "decimal(38,0)" in src, "a BIGINT lane sum would overflow silently"
    assert "sha2(" in src and "256" in src
    assert src.count("CANON_VERSION") >= 4, "both paths must fold the version in"


if __name__ == "__main__":
    # CI RUNS EVERY SUITE AS A SCRIPT — see the module docstring. Without this block the file runs
    # no tests and exits 0.
    bad = 0
    for _name, _fn in sorted(globals().items()):
        if _name.startswith("test_") and callable(_fn):
            try:
                _fn()
                print(f"  ok  {_name}")
            except Exception as _e:                  # noqa: BLE001 - report and continue
                bad += 1
                print(f"FAIL  {_name}: {_e}")
    sys.exit(1 if bad else 0)
