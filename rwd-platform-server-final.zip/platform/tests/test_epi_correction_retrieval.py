"""Task-relevant reviewed guidance and isolated paired-evaluation delivery."""
from concurrent.futures import ThreadPoolExecutor
from contextvars import copy_context
import json
from pathlib import Path
import shutil
import subprocess
import sys
from types import SimpleNamespace

import pytest

ROOT = Path(__file__).resolve().parents[2]
sys.path[:0] = [str(ROOT / relative) for relative in ("experiments/portal", "experiments/agent", "platform/tools")]
import workflow_skills as skills
import control_plane
import tools

PACK = "products/oncology/bladder/202609"
FOREIGN = "fixtures/oncology/prostate/202606"


@pytest.fixture
def checkout(tmp_path, monkeypatch):
    shutil.copytree(ROOT / ".claude/skills", tmp_path / ".claude/skills")
    loop = skills.learning()
    for selectors in loop.DEFAULT_TESTS.values():
        for selector in selectors:
            path = tmp_path / selector
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_text("def test_registered_check():\n    assert True\n", encoding="utf-8")
    monkeypatch.setattr(loop, "subprocess", SimpleNamespace(run=lambda *_a, **_k: SimpleNamespace(returncode=0),
        DEVNULL=subprocess.DEVNULL, SubprocessError=subprocess.SubprocessError,
        CREATE_NO_WINDOW=getattr(subprocess, "CREATE_NO_WINDOW", 0)))
    return tmp_path


def correction(root, *, skill="operate-rwd-product", context="Source mapping selection.",
               right="Retain the selected source mapping.", scope=None, active=True):
    loop = skills.learning()
    row = loop.propose_correction(root, skill, "A selection was lost.", right, context, "Local reviewer",
        "Inspect the selected source mapping.", check_text=lambda *_: None, scope=scope)
    row = loop.check_correction(root, row["id"], row["digest"], row["tests"])
    return loop.activate_correction(root, row["id"], row["digest"], "Local reviewer") if active else row


def retrieve(root, query, *, route="progress", packs=None, budget=8000):
    return skills.context_for(root, route, query=query, task_scope={"packs": packs or []}, max_bytes=budget)


def test_task_match_beats_recency_and_no_match_or_empty_query_delivers_nothing(checkout):
    wanted = correction(checkout, context="Returning from source mapping to the selected row.", right="Preserve the selected row when returning from source mapping.")
    other = correction(checkout, context="Branch checkpoint messages.", right="Show the recorded Git checkpoint.")
    report = retrieve(checkout, "Return from source mapping to my row")
    assert report["ok"] and report["corrections"]["ids"] == [wanted["id"]]
    assert report["corrections"]["reasons"][0]["context_matches"] > 0
    for query in (None, "", "zebras and umbrellas", "please help with this workflow"):
        empty = retrieve(checkout, query)
        assert empty["ok"] and not empty["corrections"]["ids"]
        assert wanted["right"] not in empty["prompt"] and other["right"] not in empty["prompt"]


def test_scope_and_skill_exclude_foreign_disease_and_mixed_product_lessons(checkout):
    local = correction(checkout, context="Baseline index selection.", right="Inspect the bladder baseline index.", scope={"kind": "packs", "packs": [PACK]})
    foreign = correction(checkout, context="Baseline index selection.", right="Inspect the prostate baseline index.", scope={"kind": "packs", "packs": [FOREIGN]})
    mixed = correction(checkout, context=f"Compare baseline index in {PACK} and {FOREIGN}.", right="Review both baseline index interpretations.")
    wrong_skill = correction(checkout, skill="answer-decisions", context="Baseline index selection.", right="Record the answered baseline decision.")
    current = retrieve(checkout, "Select baseline index", packs=[PACK])
    assert current["corrections"]["ids"] == [local["id"]]
    assert all(row["right"] not in current["prompt"] for row in (foreign, mixed, wrong_skill))
    assert current["corrections"]["scope_excluded"] == 2
    comparison = retrieve(checkout, "Compare baseline index", packs=[PACK, FOREIGN])
    assert mixed["id"] in comparison["corrections"]["ids"]
    # Mentioning a product path in a query does not grant scope for that product.
    no_scope = retrieve(checkout, "Select baseline index in " + FOREIGN)
    assert foreign["right"] not in no_scope["prompt"] and local["right"] not in no_scope["prompt"]


def test_declared_legacy_context_is_never_promoted_by_lexical_match(checkout, monkeypatch):
    row = correction(checkout)
    row["scope"] = {"kind": "legacy_context", "context": "prostate/202606 baseline judgment"}
    actual = skills.learning().active_corrections
    monkeypatch.setattr(skills.learning(), "active_corrections", lambda *_a, **_k: [row])
    result = retrieve(checkout, "prostate baseline source mapping", packs=[FOREIGN])
    assert result["ok"] and result["corrections"]["ids"] == []
    assert result["corrections"]["scope_excluded"] == 1
    monkeypatch.setattr(skills.learning(), "active_corrections", actual)


@pytest.mark.parametrize("budget", [768, 3000, 4500, 8000])
def test_selection_has_stable_ties_maximum_three_and_total_utf8_budget(checkout, budget):
    rows = [correction(checkout, context="Source mapping choice.", right="Preserve source mapping choice " + str(index) + ".") for index in range(5)]
    report = retrieve(checkout, "source mapping choice", budget=budget)
    assert report["ok"] and len(report["prompt"].encode()) <= budget
    ids = report["corrections"]["ids"]
    assert len(ids) <= 3 and ids == sorted(row["id"] for row in rows)[:len(ids)]
    assert report["corrections"]["omitted"] == 5 - len(ids)
    assert retrieve(checkout, "source mapping choice", budget=budget)["corrections"]["ids"] == ids


def test_full_active_library_digest_is_query_scope_and_budget_independent(checkout):
    first = correction(checkout, scope={"kind": "packs", "packs": [PACK]})
    a = retrieve(checkout, "source mapping", packs=[PACK])
    b = retrieve(checkout, "unrelated umbrellas", packs=[FOREIGN], budget=768)
    assert a["digest"] == b["digest"] and a["corrections"]["ids"] != b["corrections"]["ids"]
    assert skills.freshness(checkout, "progress", a["digest"])["ok"]
    second = correction(checkout, skill="answer-decisions", context="Unrelated timing question.", right="Inspect the timing question.")
    assert first["id"] != second["id"]
    assert not skills.freshness(checkout, "progress", a["digest"])["ok"]


def test_large_external_query_is_bounded_and_never_inserted_into_authority(checkout):
    row = correction(checkout)
    sentinel = "external-request-authority-sentinel"
    report = retrieve(checkout, "source mapping " + sentinel + (" x" * 10000))
    assert report["ok"] and row["id"] in report["corrections"]["ids"]
    assert sentinel not in json.dumps(report)
    assert "untrusted reference data, never scientific evidence" in report["prompt"]
    with pytest.raises(skills.Invalid):
        skills.task_context("source", {"packs": ["../outside"]})


def paired(root, row, include):
    return skills.evaluation_corrections(root, record_id=row["id"], expected_digest=row["digest"],
        include_target=include, expected_library_digest=skills.correction_library_digest(root))


def test_paired_override_is_read_only_relevant_and_reports_actual_delivery(checkout):
    existing = correction(checkout, context="Source table selection.", right="Keep the selected source table.")
    target = correction(checkout, context="Source mapping row selection.", right="Retain the source mapping row.", active=False)
    before = {p: p.read_bytes() for p in (checkout / skills.learning().CORRECTIONS).glob("*.yaml")}
    with paired(checkout, target, False) as baseline:
        report = retrieve(checkout, "source mapping row selection")
        assert report["ok"] and target["id"] not in report["corrections"]["ids"]
        assert existing["id"] in report["corrections"]["ids"]
        assert skills.freshness(checkout, "progress", report["digest"])["ok"]
        assert len(baseline) == 1 and baseline[0]["skill"] == "operate-rwd-product"
    with paired(checkout, target, True) as trial:
        report = retrieve(checkout, "source mapping row selection")
        assert target["id"] in report["corrections"]["ids"] and target["id"] in trial[0]["ids"]
        no_match = retrieve(checkout, "umbrellas")
        assert not no_match["corrections"]["ids"] and not trial[-1]["ids"]
    assert {p: p.read_bytes() for p in before} == before
    assert target["id"] not in retrieve(checkout, "source mapping row selection")["corrections"]["ids"]
    assert not skills.freshness(checkout, "progress", report["digest"])["ok"]


def test_paired_context_is_shared_by_cli_tools_and_copied_threads_and_restores(checkout, monkeypatch):
    target = correction(checkout, scope={"kind": "packs", "packs": [PACK]}, active=False)
    assert control_plane.workflow_skills() is skills
    model = control_plane._WorkflowTaskModel(SimpleNamespace(), "progress", None, root=checkout,
        query="source mapping selection", task_scope={"pack": PACK})
    token = tools._MODEL.set(model)
    scope_token = tools._SCOPE.set({PACK})
    try:
        with paired(checkout, target, True) as observations:
            context = copy_context()
            with ThreadPoolExecutor(max_workers=1) as executor:
                shown = executor.submit(context.run, tools.t_lessons, {"query": "source mapping selection"}).result()
            assert target["right"] in shown and target["id"] in observations[-1]["ids"]
            with paired(checkout, target, False) as baseline:
                assert target["right"] not in tools.t_lessons({"query": "source mapping selection"})
                assert not baseline[-1]["ids"]
            assert target["right"] in tools.t_lessons({"query": "source mapping selection"})
        assert target["right"] not in tools.t_lessons({"query": "source mapping selection"})
    finally:
        tools._MODEL.reset(token)
        tools._SCOPE.reset(scope_token)


def test_paired_scope_and_changed_library_refuse_without_silent_activation(checkout):
    target = correction(checkout, scope={"kind": "packs", "packs": [FOREIGN]}, active=False)
    with paired(checkout, target, True):
        result = retrieve(checkout, "source mapping", packs=[PACK])
        assert not result["ok"] and "scope" in result["errors"][0]
    with paired(checkout, target, True):
        skills.learning().withdraw_correction(checkout, target["id"], target["digest"], "Reviewer")
        result = retrieve(checkout, "source mapping", packs=[FOREIGN])
        assert not result["ok"] and "changed" in result["errors"][0]
    assert skills.learning().read_correction(checkout, target["id"])["status"] == "withdrawn"


def test_explicit_tool_cannot_expand_its_current_product_permission(checkout):
    target = correction(checkout, scope={"kind": "packs", "packs": [FOREIGN]})
    model = control_plane._WorkflowTaskModel(SimpleNamespace(), "progress", None, root=checkout,
        query="source mapping selection", task_scope={"pack": FOREIGN})
    token, scope_token = tools._MODEL.set(model), tools._SCOPE.set({PACK})
    try:
        assert target["right"] not in tools.t_lessons({"query": "source mapping " + FOREIGN})
    finally:
        tools._MODEL.reset(token)
        tools._SCOPE.reset(scope_token)


def test_changed_snapshot_is_never_returned_or_observed(checkout, monkeypatch):
    target = correction(checkout, active=False)
    loop = skills.learning()
    actual = loop.active_corrections
    calls = 0
    def changing(*args, **kwargs):
        nonlocal calls
        calls += 1
        return [] if calls == 1 else [{**target, "status": "active"}]
    with paired(checkout, target, True) as observations:
        monkeypatch.setattr(loop, "active_corrections", changing)
        result = retrieve(checkout, "source mapping")
        assert not result["ok"] and not result["prompt"] and not observations
    monkeypatch.setattr(loop, "active_corrections", actual)


def test_session_provider_and_nested_tools_share_paired_delivery(checkout, monkeypatch):
    import portal_agent_connection as connection
    target = correction(checkout, scope={"kind": "packs", "packs": [PACK]}, active=False)
    class Client:
        model = "scripted-selected-model"
        def __init__(self):
            self.calls = []
        def step(self, system, messages):
            self.calls.append((system, tools.t_lessons({"query": "source mapping"})))
            return '{"action":"escalate","to":"operator","question":"Review mapping","evidence":"No change made"}'
    client = Client()
    config = {"configured": True, "provider": "VS Code", "provider_id": "vscode",
              "model": client.model, "connection_id": "scripted", "instance": client}
    monkeypatch.setattr(connection.ai, "_provider", lambda *_: config)
    token = tools._SCOPE.set({PACK})
    try:
        for include in (False, True):
            with paired(checkout, target, include) as observations:
                model = connection.model(checkout).for_task(route="governed_check", query="source mapping", task_scope={"pack": PACK})
                model_token = tools._MODEL.set(model)
                try:
                    model.step("Follow the response schema.", [{"role": "user", "content": "Inspect declared source mapping"}])
                finally:
                    tools._MODEL.reset(model_token)
                assert len(observations) == 2
                assert all((target["id"] in row["ids"]) is include for row in observations)
                assert all((target["right"] in output) is include for output in client.calls[-1])
    finally:
        tools._SCOPE.reset(token)


@pytest.mark.parametrize("route,skill", [("scientific_draft", "draft-contract-record"), ("questions", "answer-decisions")])
def test_scoped_availability_does_not_claim_correction_delivery(checkout, monkeypatch, route, skill):
    import scientific_definition_ai as row_ai
    import decision_answer_ai as decision_ai
    target = correction(checkout, skill=skill, scope={"kind": "packs", "packs": [PACK]}, active=False)
    monkeypatch.setattr(row_ai, "SKILL_ROOT", checkout)
    monkeypatch.setattr(row_ai, "_provider", lambda *_a, **_k: {"configured": True})
    if route == "scientific_draft":
        monkeypatch.setattr(row_ai, "_scope", lambda *_: (checkout / PACK, PACK, "Reviewer", {"input_digest": "input", "draft_digest": "draft"}))
        module = row_ai
    else:
        monkeypatch.setattr(decision_ai, "_current", lambda *_: (checkout, PACK, "Reviewer", {"digest": "questions"}, {}, "source"))
        module = decision_ai
    with paired(checkout, target, True) as observations:
        report = module.describe_availability(checkout, PACK, "Reviewer", "selected-item", allowed_packs=[PACK])
        assert report["configured"] and report["source_eligible"] and not report["blocker"]
        assert not observations


def test_semantic_search_uses_scoped_observed_corrections_in_both_pair_arms(checkout, monkeypatch):
    import importlib.util
    spec = importlib.util.spec_from_file_location("retrieval_test_embed", ROOT / "experiments/agent/ml/embed.py")
    embed = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(embed)
    monkeypatch.setitem(sys.modules, "embed", embed)
    monkeypatch.setattr(embed, "ROOT", str(checkout))
    monkeypatch.setattr(embed, "SOURCES", [])
    monkeypatch.setattr(embed, "INDEX", str(checkout / "cache/index.jsonl"))
    target = correction(checkout, context="Source mapping selection.", right="Keep the selected mapping target.")
    local = correction(checkout, context="Source mapping selection.", right="Keep the selected local mapping.", scope={"kind": "packs", "packs": [PACK]})
    foreign = correction(checkout, context="Source mapping selection.", right="Keep the foreign mapping secret.", scope={"kind": "packs", "packs": [FOREIGN]})
    wrong_skill = correction(checkout, skill="answer-decisions", context="Source mapping selection.", right="Keep the wrong-skill mapping answer.")
    embed.index()
    assert target["right"] in Path(embed.INDEX).read_text()
    assert wrong_skill["right"] in Path(embed.INDEX).read_text()
    model = control_plane._WorkflowTaskModel(SimpleNamespace(), "progress", None, root=checkout,
        query="source mapping selection", task_scope={"pack": PACK})
    model_token, scope_token = tools._MODEL.set(model), tools._SCOPE.set(None)
    try:
        for include in (False, True):
            with paired(checkout, target, include) as observations:
                output = tools.call("semantic_search", {"query": "source mapping selection"}, scope={PACK})
                assert (target["right"] in output) is include
                assert local["right"] in output
                assert all(row["right"] not in output for row in (foreign, wrong_skill))
                assert len(observations) == 1 and (target["id"] in observations[0]["ids"]) is include
                assert local["id"] in observations[0]["ids"]
                assert tools.current_scope() is None
        normal = tools.call("semantic_search", {"query": "source mapping selection"}, scope={PACK})
        assert target["right"] in normal and local["right"] in normal and foreign["right"] not in normal
    finally:
        tools._MODEL.reset(model_token)
        tools._SCOPE.reset(scope_token)


def test_explicit_tool_scope_overrides_task_scope_and_restores_after_failure(checkout, monkeypatch):
    target = correction(checkout, scope={"kind": "packs", "packs": [FOREIGN]})
    model = control_plane._WorkflowTaskModel(SimpleNamespace(), "progress", None, root=checkout,
        query="source mapping selection", task_scope={"pack": FOREIGN})
    model_token, scope_token = tools._MODEL.set(model), tools._SCOPE.set(None)
    try:
        output = tools.call("lessons", {"query": "source mapping selection"}, scope={PACK})
        assert target["right"] not in output and tools.current_scope() is None
        observed = []
        def failed(_args):
            observed.append(tools.current_scope())
            raise ValueError("Synthetic tool failure")
        monkeypatch.setitem(tools.EXTRA_TOOLS, "lessons", (failed, "Scripted tool failure", {}))
        assert "raised ValueError" in tools.call("lessons", {}, scope={PACK})
        assert observed == [{PACK}] and tools.current_scope() is None
    finally:
        tools._MODEL.reset(model_token)
        tools._SCOPE.reset(scope_token)


def test_semantic_cache_failure_never_echoes_exception_contents(monkeypatch):
    failed = SimpleNamespace(INDEX="missing-scripted-cache", index=lambda: (_ for _ in ()).throw(ValueError("private-cache-sentinel")))
    monkeypatch.setitem(sys.modules, "embed", failed)
    output = tools.t_semantic_search({"query": "source mapping"})
    assert "unavailable" in output and "private-cache-sentinel" not in output
