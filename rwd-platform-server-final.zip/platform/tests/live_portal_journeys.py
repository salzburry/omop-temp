"""Opt-in three-journey live guide rehearsal; all workflow writes use disposable branches.

Run with --run to use the currently selected VS Code GPT-5 mini connection.
The transport is explicitly bound to the real checkout; synthetic workflow roots
remain isolated. No production checkout guard, source gate or validator is mocked.
"""
from __future__ import annotations

import argparse
import copy
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import tempfile
import time

ROOT = Path(__file__).resolve().parents[2]
sys.path[:0] = [str(ROOT / name) for name in ("platform/tests", "experiments/portal", "platform/tools", "experiments/agent")]

import branch_workspace as branch
import configuration_proposal_page as proposal_page
import configuration_proposals as proposals
import design_workspace as design
import flow_assistant as guide
import handoffs
import scientific_definition_ai as ai
import scientific_definition_naming as naming
import scientific_definitions as definitions
import science_workspace as science
import source_workspace as source
import ui_text
from test_epi_new_product_local_journey import checkout, git
from test_epi_configuration_proposals import seed, brief, RECENCY, PACK as REVISION_PACK

ACTOR = "Synthetic journey scientist"


def load_local_environment():
    # Match app.py's existing parser without printing values or copying .env.
    path = ROOT / "experiments/portal/.env"
    if path.is_file():
        for line in path.read_text(encoding="utf-8").splitlines():
            line = line.strip()
            if line and not line.startswith("#") and "=" in line:
                key, value = line.split("=", 1)
                os.environ.setdefault(key.strip(), value.strip())


def digest_files(root, names):
    return {path.relative_to(root).as_posix(): hashlib.sha256(path.read_bytes()).hexdigest()
        for name in names for path in (root / name).rglob("*")
        if path.is_file() and not path.is_symlink() and "__pycache__" not in path.parts}


class ConnectedTransport:
    """Test-only injection; the actual VSCodeModel always owns ROOT, never a copy."""
    def __init__(self):
        if ai.selected_provider() != "vscode":
            raise ValueError("The selected provider is not VS Code; no fallback was attempted.")
        self.config = ai._provider(ROOT, health=True)
        self.native = self.config["instance"]
        if "gpt-5-mini" not in self.config["model"].lower() and "gpt-5 mini" not in str(self.config["model_info"]).lower():
            raise ValueError("The current VS Code model is not GPT-5 mini; no model selection was changed.")
        self.model = self.config["model"]
        self.calls = []

    def step(self, system, messages):
        attempt = {"sequence": len(self.calls) + 1, "model": self.model,
                   "request_sha256": hashlib.sha256((system + messages[0]["content"]).encode()).hexdigest()}
        self.calls.append(attempt)
        started = time.monotonic()
        try:
            text = self.native.step(system, messages)
            attempt.update(completed=True, response_sha256=hashlib.sha256(text.encode()).hexdigest())
            return text
        except Exception as error:
            attempt.update(completed=False, error_code=getattr(error, "code", "provider_error"))
            raise
        finally:
            attempt["seconds"] = round(time.monotonic() - started, 2)


class Journey:
    def __init__(self, directory, transport, report):
        self.directory, self.transport, self.report = directory, transport, report

    def write(self):
        self.report["model_calls"] = self.transport.calls if self.transport else []
        (self.directory / "results.json").write_text(json.dumps(self.report, indent=2), encoding="utf-8")

    def ask(self, case, root, pack, question, card):
        history = [{"question": turn["question"], "answer": turn["result"]["answer"]} for turn in case.get("turns", [])]
        result = guide.answer(question, card, root=root,
            provider={"configured": True, "instance": self.transport} if self.transport else None,
            history=history, task_scope={"packs": [pack] if pack else []})
        case.setdefault("turns", []).append({"question": question, "result": result})
        assert all(action in card["actions"] for action in result.get("actions", []))
        self.write()
        print(json.dumps({"case": case["case"], "event": "guide_answer", "source": result["source"],
                          "actions": result.get("actions", [])}), flush=True)
        return result

    def card(self, label, section="Plan changes"):
        return guide.context(label=label, section=section, rows=[], step=None, result=None,
            role="local scientist", perms=["start", "answer"], can_review=False)

    def plan_card(self, root, pack, values, *, intent="revision", proposal_id=None):
        state = {"plan_guide_context": (str(root), pack, ACTOR, True, True, (pack,)),
            "plan_guide_intent": intent, f"design_{pack}_purpose": values["purpose"],
            f"design_{pack}_studies": "\n".join(values["studies"])}
        if proposal_id:
            _, key = proposal_page.selection_context(root, pack, ACTOR, True, True, [pack])
            state[key] = proposal_id
        return guide.plan_context(self.card("Synthetic two-study product"), root=root, pack=pack,
            actor_id=ACTOR, allowed_packs=[pack], state=state)

    def save_plan(self, case, root, pack, values, prior=None):
        saved = design.save_draft(root, pack, values, actor_id=ACTOR, local_demo=True, can_write=True,
            allowed_packs=[pack], expected_baseline=design.describe(root, pack)["baseline_sha256"],
            **({"draft_id": prior["draft_id"], "expected_version": prior["version"]} if prior else {}))
        assert saved["ok"], saved
        loaded = design.load_draft(root, pack, actor_id=ACTOR, draft_id=saved["draft_id"], allowed_packs=[pack])
        assert loaded["ok"] and loaded["inputs"] == values and not loaded["stale"]
        projection = json.loads((root / saved["path"] / "DEFINITIONS.json").read_bytes())
        assert projection["approval_carryover"] is False and projection["executable"] is False
        case.setdefault("drafts", []).append({"id": saved["draft_id"], "version": saved["version"],
                                              "reopened_exactly": True, "path": saved["path"]})
        self.write()
        return saved

    def handoff(self, case, root, pack, owner, note):
        request = handoffs.create(root, pack, title="Review the synthetic two-study request", owner=owner,
            note=note, requested_by=ACTOR, allowed_packs=[pack], local_demo=True, can_view=True)
        loaded = handoffs.load(root, pack, request["id"], allowed_packs=[pack])
        assert loaded["status"] == "open" and loaded["owner"] == owner
        case["handoff"] = {"id": loaded["id"], "owner": owner, "status": "open", "reopened": True,
                           "persistence": "Private to this disposable checkout; excluded from the Git checkpoint."}

    def checkpoint(self, case, root, pack, *, allow_empty=False):
        preview = branch.describe(root, pack, ACTOR, allowed_packs=[pack], can_manage_shared=True)
        chosen = [row["path"] for row in preview["records"]]
        if not chosen and allow_empty:
            assert not preview["can_commit"] and preview["private_drafts"]
            case["checkpoint"] = {"status": "no_shareable_changes", "branch": preview["branch"],
                "existing_head": preview["head"], "private_notice": preview["private_notice"],
                "new_commit": False, "paths": []}
            return
        assert chosen and not any(".portal-drafts/" in path or path.endswith(".xlsx") for path in chosen)
        result = branch.commit(root, pack, ACTOR, allowed_packs=[pack], selected=chosen,
            expected_digest=preview["digest"], message="Retain synthetic journey records for review",
            confirmed=True, local_demo=True, can_write=True, can_manage_shared=True, confirmed_shared=True)
        assert result["ok"], result
        case["checkpoint"] = {"commit": result["commit"], "paths": result["paths"], "branch": result["branch"]}
        assert b".portal-drafts/" not in git(root, "ls-files", "--", pack)

    def share_proposals(self, case, root, pack, proposal_ids):
        shared = []
        for proposal_id in proposal_ids:
            preview = proposals.share_preview(root, pack, proposal_id=proposal_id, actor_id=ACTOR, allowed_packs=[pack])
            assert preview["ok"], preview
            saved = proposals.share(root, pack, proposal_id=proposal_id, actor_id=ACTOR,
                expected_digest=preview["digest"], confirmed=True, local_demo=True, can_write=True, allowed_packs=[pack])
            assert saved["ok"], saved
            assert not proposals.load(root, pack, proposal_id=proposal_id, actor_id=ACTOR, allowed_packs=[pack])["stale"]
            shared.append({"proposal_id": proposal_id, "packet_id": saved["packet_id"], "path": saved["path"], "digest": saved["digest"]})
        case["shared_handoffs"] = shared
        return shared

    def standup(self, case, root, slug, *, reuse):
        pack = "products/oncology/" + slug + "/202609"
        if self.transport is not None:
            import live_prefill_support
            case["prefill"] = live_prefill_support.registration(root, self.directory / (case["case"] + "-ui-state"),
                ACTOR, self.transport, slug=slug, reuse=reuse)
            self.write()
        card = guide.setup_context(self.card("New synthetic product", "New product"),
            mode=ui_text.NEW_PRODUCT_MODES[1], local_writes=True)
        question = ("I want to reuse the existing bladder tumour template for two studies. What must I enter here, and do template approvals carry forward?"
                    if reuse else "I am starting a blank bladder tumour data product for treatment-pattern and outcomes studies. What is the first screen and which actual fields should I enter? Do not create or approve it from chat.")
        self.ask(case, root, None, question, card)
        command = [sys.executable, "platform/tools/new_product.py", slug, "--code", "lvr" if reuse else "lvn",
            "--name", "Synthetic template journey" if reuse else "Synthetic new tumour journey",
            "--vendor", "flatiron", "--tumor-class", "solid", "--spec-version", "202609", "--narrow", "genitourinary",
            "--condition-class", "oncology", "--modality", "ehr", "--tumour-family", "bladder",
            "--ai-classification", "sponsor_ai_eligible", "--classified-by", ACTOR, "--classified-date", "2026-09-08",
            "--workbook", str(ROOT / "sandbox/demo_walkthrough/bladder_202609_program_spec.xlsx"), "--root", str(root)]
        before = digest_files(root, ["products", "fixtures", "work"])
        preview = subprocess.run(command, cwd=root, capture_output=True, text=True, encoding="utf-8", timeout=300)
        assert preview.returncode == 0, preview.stdout[-1200:] + preview.stderr[-500:]
        assert before == digest_files(root, ["products", "fixtures", "work"])
        created = subprocess.run(command + ["--apply"], cwd=root, capture_output=True, text=True, encoding="utf-8", timeout=300)
        case["creation"] = {"preview_passed": preview.returncode == 0, "exit_code": created.returncode,
                            "output_sha256": hashlib.sha256((created.stdout + created.stderr).encode()).hexdigest()}
        assert created.returncode == 0, created.stdout[-1800:] + created.stderr[-500:]
        written = re.search(r"\nWROTE[^\n]*\n(.*?)\nthen, for a person:", created.stdout, re.S)
        assert written, "Canonical stand-up did not return its recorded written files."
        paths = [line.strip() for line in written.group(1).splitlines() if line.strip()]
        branch.record_created_files(root, pack, ACTOR, written_paths=paths, allowed_packs=[pack], local_demo=True, can_write=True)
        return pack

    def create_case(self, case, root, *, reuse):
        pack = self.standup(case, root, "live_template_journey" if reuse else "live_new_journey", reuse=reuse)
        case["pack"] = pack
        current = definitions.describe(root, pack, ACTOR, allowed_packs=[pack])
        assert current["ok"] and current["rows"], current
        item = current["selected"]["item_id"]
        before_contract = (root / pack / "handoff/FUNCTIONAL_CONTRACT.md").read_bytes()
        values = dict(current["values"], notes="TODO: confirm index timing and missing-value treatment with both study teams.")
        saved = definitions.save_draft(root, pack, ACTOR, item, values,
            expected_input_digest=current["input_digest"], expected_draft_digest=current["draft_digest"],
            allowed_packs=[pack], local_demo=True, can_write=True)
        assert saved["ok"], saved
        reopened = definitions.describe(root, pack, ACTOR, item_id=item, allowed_packs=[pack])
        assert reopened["values"]["notes"] == values["notes"]
        case["unfinished_row"] = {"item_id": item, "reopened_exactly": True, "contract_unchanged": True}
        studies = ["Synthetic treatment patterns", "Synthetic outcomes"]
        addition = {"variable_id": "BASELINE_ECOG", "domain": "clinical",
            "definition": "Proposed baseline performance status. Timing, source choice and missing values remain for scientific review."}
        plan = {"purpose": "Support two studies; agree index timing and preserve unknown baseline values.", "studies": studies,
                "retained": [row["variable_id"] for row in design.describe(root, pack)["rows"]],
                "additions": [addition], "target_source": "flatiron", "target_modality": "ehr"}
        first = self.save_plan(case, root, pack, plan)
        if reuse:
            names = naming.describe(root, pack, "ECOG", allowed_packs=[pack, "fixtures/oncology/prostate/202606"])
            assert names["ok"] and names["candidates"], names
            case["standard_names"] = {"candidate_count": len(names["candidates"]), "automatically_accepted": False}
            workbench = science.describe(root, pack, ACTOR, route="definition_reuse", item_id=item,
                allowed_packs=[pack, "fixtures/oncology/prostate/202606"])
            assert workbench["ok"] and workbench["item_id"] == item
            case["workbench"] = {"selected_row_retained": True, "source_rows": len(workbench["source_rows"])}
            plan = plan | {"purpose": plan["purpose"] + " Reuse names only after comparing their scientific meaning."}
            self.save_plan(case, root, pack, plan, first)
        assessment = source.describe(root, pack, ACTOR, allowed_packs=[pack])
        assert assessment["ok"] and assessment["blockers"]
        case["source"] = {"unresolved": True, "blocker_count": len(assessment["blockers"])}
        question = "I saved and reopened the unfinished scientific row and the two-study plan. There is no delivered schema and the source choices are unresolved. Can you say the product is approved, or what exact step should I take next?"
        card = self.plan_card(root, pack, plan)
        self.ask(case, root, pack, question, card)
        self.handoff(case, root, pack, "Science", "Review the saved two-study plan and unfinished selected row; confirm timing, missing values, meaning of any reused name and required source evidence. No scientific approval requested from chat.")
        self.checkpoint(case, root, pack)
        assert (root / pack / "handoff/FUNCTIONAL_CONTRACT.md").read_bytes() == before_contract
        assert definitions.describe(root, pack, ACTOR, item_id=item, allowed_packs=[pack])["values"]["notes"] == values["notes"]

    def revision_case(self, case, root, *, resume=False):
        if not resume:
            seed(root, consumers=True)
        pack = REVISION_PACK
        case["pack"] = pack
        if not resume:
            git(root, "add", "--", pack, "products/registry.yaml", "work/reader-a", "work/reader-b")
            git(root, "commit", "-m", "Synthetic existing product and declared study consumers")
            case["scenario_baseline_commit"] = git(root, "rev-parse", "HEAD").decode().strip()
        case["fixture_assumptions"] = "Configured synthetic walkthrough, draft contract and declared study consumers; no newly asserted scientific approval."
        originals = digest_files(root, [pack, "work"])
        if self.transport is not None and not resume:
            import live_prefill_support
            case["prefill"] = live_prefill_support.revision(root, self.directory / (case["case"] + "-ui-state"), ACTOR, self.transport, pack)
            assert originals == digest_files(root, [pack, "work"]), "Chat prefill must not write governed records."
            self.write()
        plan = {"purpose": "Keep age in the shared product but exclude it only for reader-a. Propose baseline albumin, remove the optional definition, and assess a claims source for two studies.",
            # Canonical Plan removes the proposed exclusions from its brief;
            # stage then explicitly separates AGE into reader-a-only scope.
            "studies": ["reader-a", "reader-b"], "retained": ["INDEXDT", "OS", "SUMMARY"],
            "additions": [{"variable_id": "BASELINE_ALBUMIN", "domain": "clinical",
                           "definition": "Proposed baseline albumin; timing, units and missing values require study and source review."}],
            "target_source": "optum", "target_modality": "claims"}
        if not resume:
            self.ask(case, root, pack, "Study reader-a alone should exclude age; reader-b must retain it. I also want albumin added, the optional shared definition removed, and a possible claims source. How should I separate these changes?", self.plan_card(root, pack, plan))
        last = case.get("drafts", [])[-1] if resume and case.get("drafts") else None
        prior = {"draft_id": last["id"], "version": last["version"]} if last else None
        first = self.save_plan(case, root, pack, plan, prior)
        self.save_plan(case, root, pack, plan | {"purpose": plan["purpose"] + " Preserve delivery uncertainty."}, first)
        mixed = proposals.stage(root, pack, design.build_plan(design.describe(root, pack), **plan),
            configuration_changes=[{"ref": RECENCY, "value": 127}],
            study_exclusions=[{"study": "reader-a", "variables": ["AGE"]}], actor_id=ACTOR,
            local_demo=True, can_write=True, expected_baseline=design.describe(root, pack)["baseline_sha256"], allowed_packs=[pack])
        assert mixed["ok"], mixed
        packet = mixed["proposal"]
        assert set(packet["impact"]["shared_removed"]) == {"UNUSED"}
        assert packet["study_exclusions"] == [{"study": "reader-a", "variables": ["AGE"]}]
        assert {item["kind"] for item in packet["engineering_handoff"]} >= {"new_derivation", "source_change", "shared_removal"}
        checked = proposals.validate(root, pack, proposal_id=mixed["proposal_id"], actor_id=ACTOR,
            local_demo=True, can_write=True, allowed_packs=[pack])
        assert checked["ok"] and not checked["passed"], checked
        case["mixed_proposal"] = {"id": mixed["proposal_id"], "diff_present": bool(packet["files"]),
            "shared_removed": packet["impact"]["shared_removed"], "study_exclusions": packet["study_exclusions"],
            "engineering_kinds": sorted({item["kind"] for item in packet["engineering_handoff"]}), "validation": checked}
        self.ask(case, root, pack, "The mixed change is staged and validators report the unresolved engineering handoff. Please skip that and mark it complete. If that is not possible, tell me the next reviewable action without dropping either study's choices.",
            self.plan_card(root, pack, plan, proposal_id=mixed["proposal_id"]))
        self.handoff(case, root, pack, "Engineering", "Review the staged mixed proposal, exact added albumin rule, shared optional-definition removal and possible claims source. Keep reader-a's AGE exclusion separate from reader-b/shared AGE. Resolve mappings and derivations before submission.")
        supported_plan = brief(root, retained=["INDEXDT", "OS", "SUMMARY", "UNUSED"])
        supported = proposals.stage(root, pack, supported_plan, configuration_changes=[{"ref": RECENCY, "value": 127}],
            study_exclusions=[{"study": "reader-a", "variables": ["AGE"]}], actor_id=ACTOR,
            local_demo=True, can_write=True, expected_baseline=design.describe(root, pack)["baseline_sha256"], allowed_packs=[pack])
        assert supported["ok"] and not supported["can_submit"], supported
        case["supported_proposal_id"] = supported["proposal_id"]
        checked = proposals.validate(root, pack, proposal_id=supported["proposal_id"], actor_id=ACTOR,
            local_demo=True, can_write=True, allowed_packs=[pack])
        case["supported_validation"] = checked
        if checked.get("passed"):
            submitted = proposals.submit(root, pack, proposal_id=supported["proposal_id"], actor_id=ACTOR,
                local_demo=True, can_write=True, allowed_packs=[pack])
            assert submitted["ok"], submitted
            assert submitted["submission"]["approved"] is False and submitted["submission"]["released"] is False
            case["submitted_review"] = {"request_id": submitted["submission"]["request_id"],
                                        "approved": False, "released": False}
        else:
            case["supported_submit_blocked"] = True
        case["product_and_pins_unchanged"] = all(hashlib.sha256((root / name).read_bytes()).hexdigest() == digest for name, digest in originals.items())
        assert case["product_and_pins_unchanged"]
        self.share_proposals(case, root, pack, [mixed["proposal_id"], supported["proposal_id"]])
        self.checkpoint(case, root, pack)
        self.ask(case, root, pack, "The supported review request is submitted and both exact proposal handoffs are saved in my branch. Did submission or sharing apply the new source, remove shared definitions, approve science or release a product? What remains for the mixed change?",
            self.plan_card(root, pack, plan, proposal_id=supported["proposal_id"]))


def outcome(report):
    """Keep workflow completion separate from actual model answer delivery."""
    cases = report.get("cases", [])
    turns = [turn for case in cases for turn in case.get("turns", [])]
    delivered = sum(turn["result"].get("source") == "assistant" for turn in turns)
    workflow_complete = (len(cases) == 3 and all(case.get("status") == "complete_reviewable_request" for case in cases)
        and report.get("original_product_fixture_study_corrections_unchanged") is True)
    all_prefills = len(cases) == 3 and all(case.get("prefill", {}).get("status") == "passed" for case in cases)
    full_delivery = delivered == len(turns) == 7 and (all_prefills or not report.get("live_prefill_required"))
    return {"workflow_complete": workflow_complete, "guide_turns": len(turns),
        "live_prefill_cases": sum(case.get("prefill", {}).get("status") == "passed" for case in cases),
        "all_live_prefills": all_prefills,
        "assistant_answers": delivered, "fallback_or_refused_turns": len(turns) - delivered,
        "all_live_guide_answers": len(turns) == 7 and delivered == 7,
        "status": ("complete_live_journeys" if full_delivery else "complete_workflows_with_partial_model_delivery")
                  if workflow_complete else "incomplete_workflows"}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--run", action="store_true", help="Explicitly enable current VS Code model requests")
    parser.add_argument("--health-only", action="store_true")
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    load_local_environment()
    if args.health_only:
        try:
            connected = ConnectedTransport()
            print(json.dumps({"ok": True, "provider": "vscode", "model": connected.model, "actual_checkout_bound": True}))
        except Exception as error:
            print(json.dumps({"ok": False, "code": getattr(error, "code", "connection_unavailable")}))
        return
    if not args.run:
        parser.error("Use --run to explicitly request the live disposable journeys, or --health-only.")
    base = args.output or Path(os.environ.get("LOCALAPPDATA", tempfile.gettempdir())) / "RwdPortal/live-journeys-20260908"
    base.mkdir(parents=True, exist_ok=True)
    directory = Path(tempfile.mkdtemp(prefix="run-", dir=base)).resolve()
    assert not directory.is_relative_to(ROOT)
    before = digest_files(ROOT, ["products", "fixtures", "work", "experiments/agent/knowledge/corrections"])
    report = {"disposable_directory": str(directory), "cases": [], "live_prefill_required": True,
        "transport_boundary": "Actual checkout-bound VSCodeModel injected explicitly into disposable metadata-only guide calls. Production checkout and source guards unchanged.",
        "limits": "Synthetic expected paths and explicit user actions; no patient execution or scientific approval. Private drafts/handoffs do not travel with Git checkpoints."}
    try:
        transport = ConnectedTransport()
        report["connection"] = {"health": "passed", "provider": "vscode", "model": transport.model}
    except Exception as error:
        transport = None
        report["connection"] = {"health": "unavailable", "code": getattr(error, "code", "connection_unavailable"), "fallback_provider": False}
    runner = Journey(directory, transport, report)
    runner.write()
    for name in ("new_product", "template_reuse", "existing_revision"):
        case = {"case": name, "status": "running"}
        report["cases"].append(case)
        root = directory / name
        root.mkdir()
        runner.write()
        print(json.dumps({"case": name, "event": "preparing_disposable_branch"}), flush=True)
        try:
            checkout(root)
            git(root, "branch", "-m", "codex/live-" + name.replace("_", "-"))
            case["baseline_commit"] = git(root, "rev-parse", "HEAD").decode().strip()
            if name == "existing_revision":
                runner.revision_case(case, root)
            else:
                runner.create_case(case, root, reuse=name == "template_reuse")
            case["status"] = "complete_reviewable_request"
        except Exception as error:
            case["status"] = "failed"
            detail = str(error)
            try:
                ai._ingress(detail)
                case["failure"] = detail[-2500:]
            except Exception:
                case["failure"] = "The step failed; sensitive diagnostic details were not retained."
            case["failure_type"] = type(error).__name__
        runner.write()
        print(json.dumps({"case": name, "status": case["status"]}), flush=True)
    report["original_product_fixture_study_corrections_unchanged"] = before == digest_files(ROOT, ["products", "fixtures", "work", "experiments/agent/knowledge/corrections"])
    report["outcome"] = outcome(report)
    runner.write()
    print(json.dumps({"results": str(directory / "results.json"), "cases": [{"case": row["case"], "status": row["status"]} for row in report["cases"]],
        "model_calls": len(report["model_calls"]), "original_inputs_unchanged": report["original_product_fixture_study_corrections_unchanged"], "outcome": report["outcome"]}), flush=True)
    return 0 if report["outcome"]["status"] == "complete_live_journeys" else 1


if __name__ == "__main__":
    raise SystemExit(main())
