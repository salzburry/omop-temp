"""Run the actual pending-review GIST extraction, then independently verify all outputs."""
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile

import yaml

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "platform" / "tools"))
import run_spec_pipeline as pipeline


def test_supplied_gist_draft_extracts_and_rechecks_without_changing_authored_records():
    original = ROOT / "fixtures/oncology/gist/202608"
    source_before = (original / "source_refs.yaml").read_bytes()
    with tempfile.TemporaryDirectory(prefix="epi_pipeline_") as temporary:
        product = Path(temporary) / "pack"
        shutil.copytree(original, product, ignore=shutil.ignore_patterns("out", "__pycache__", ".history"))
        source = product / "source_refs.yaml"
        doc = yaml.safe_load(source.read_text(encoding="utf-8"))
        for material in doc["source_materials"]:
            if material["material_type"] == "program_spec":
                material["status"] = "pending"
                material["why_provisional"] = "Disposable extraction test; scientific review has not been completed."
                for field in ("approved_by", "approval_date"):
                    material.pop(field, None)
        source.write_text(yaml.safe_dump(doc, sort_keys=False), encoding="utf-8")
        protected = [source, product / "handoff/FUNCTIONAL_CONTRACT.md"]
        before = {p: hashlib.sha256(p.read_bytes()).hexdigest() for p in protected if p.is_file()}
        command = [sys.executable, str(ROOT / "platform/tools/run_spec_pipeline.py"), str(product)]
        env = dict(os.environ, PYTHONUTF8="1", PYTHONIOENCODING="utf-8")
        built = subprocess.run(command, cwd=ROOT, env=env, capture_output=True, text=True, encoding="utf-8", timeout=180)
        assert built.returncode == 0, built.stdout[-1500:] + built.stderr[-1500:]
        output = product / "spec_pipeline/out"
        assert all((output / name).is_file() for name in pipeline.ARTIFACTS)
        extracted = json.loads((output / "extracted.json").read_text(encoding="utf-8"))
        assert extracted["rows"] and extracted["extraction"]["row_count"] == len(extracted["rows"])
        verified = subprocess.run(command + ["--check", "--require-generated"], cwd=ROOT, env=env,
                                  capture_output=True, text=True, encoding="utf-8", timeout=180)
        assert verified.returncode == 0, verified.stdout[-1500:] + verified.stderr[-1500:]
        assert "all 7 generated artifacts are current" in verified.stdout
        assert {p: hashlib.sha256(p.read_bytes()).hexdigest() for p in before} == before
    assert (original / "source_refs.yaml").read_bytes() == source_before


if __name__ == "__main__":
    test_supplied_gist_draft_extracts_and_rechecks_without_changing_authored_records()
    print("1 passed: pending GIST extraction and independent output verification")
