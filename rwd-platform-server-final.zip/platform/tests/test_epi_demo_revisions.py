"""Regression coverage for isolated, reviewable edits to saved rehearsals."""
from __future__ import annotations

import copy
import hashlib
import io
import json
from pathlib import Path
import subprocess
import sys
from unittest.mock import patch
import zipfile

ROOT = Path(__file__).resolve().parents[2]
sys.path[:0] = [str(ROOT / "experiments/portal"), str(ROOT / "platform/tests")]

import demo_journey as journeys
import demo_revisions as revisions
import design_workspace
from _epi_test_support import api, run
from test_epi_demo_journey import _inputs

pytest = api(__name__)


def _template(state_root, *, complete=False):
    result = journeys.prepare(
        ROOT, state_root, "scientist", journey="template", example_id="bladder",
        label="Saved bladder rehearsal", purpose="Compare baseline function across intended studies.",
        studies=["Study A", "Study B"], local_demo=True, can_write=True)
    assert result["ok"], result
    if complete:
        result = journeys.execute(ROOT, state_root, "scientist", result["run"]["id"],
                                  local_demo=True, can_write=True)
        assert result["ok"], result
    return result["run"]


def _editor(state_root, record):
    result = revisions.read_editor(ROOT, state_root, "scientist", record["id"])
    assert result["ok"], result
    return result


def _payload(editor, **changes):
    plan = editor["run"]["plan"]
    result = dict(base_sha256=editor["base_sha256"], label=editor["run"]["label"],
                  purpose=plan["purpose"], studies=plan["studies"],
                  sections=plan["retained_sections"], additions=plan["proposed_additions"],
                  proposed_source=plan["proposed_source"], proposed_modality=plan["proposed_modality"],
                  definitions=[{"key": row["key"], "definition": row["definition"]}
                               for row in editor["definitions"]], local_demo=True, can_write=True)
    result.update(changes)
    return result


def _revise(state_root, record, editor, **changes):
    return revisions.revise(ROOT, state_root, "scientist", record["id"], **_payload(editor, **changes))


def _files(directory):
    return {path.relative_to(directory).as_posix(): hashlib.sha256(path.read_bytes()).hexdigest()
            for path in directory.rglob("*") if path.is_file()}


def _records(state_root, record):
    folder = journeys._folder(ROOT, state_root, "scientist", record["id"])
    contract = folder / record["product"] / "handoff/FUNCTIONAL_CONTRACT.md"
    return {row.variable_id: row for row in design_workspace.cl.typed_records(
        contract.read_text(encoding="utf-8"))}


def test_study_only_rehearsal_revision_does_not_report_empty_product_change(tmp_path):
    original = _template(tmp_path, complete=True)
    editor = _editor(tmp_path, original)
    result = _revise(tmp_path, original, editor, studies=["Treatment patterns", "Survival outcomes"])
    assert result["ok"], result
    assert "definition_review" not in result["run"]["plan"]
    assert result["run"]["plan"]["studies"] == ["Treatment patterns", "Survival outcomes"]
    assert result["run"]["plan"]["applied_to_execution"] is False


def test_completed_rehearsal_revision_preserves_parent_and_requires_checked_rerun(tmp_path):
    fixtures_before = _inputs()
    original = _template(tmp_path, complete=True)
    parent = journeys._folder(ROOT, tmp_path, "scientist", original["id"])
    parent_before = _files(parent)
    editor = _editor(tmp_path, original)
    existing = next(row for row in editor["definitions"] if row["variable_id"] == "ECOG")
    assert existing["origin"] == "existing"
    assert "Closest ECOG value" in existing["source_definition"]
    revised_definition = existing["definition"] + "; scientific review must confirm the tie handling."
    edits = _payload(editor)["definitions"]
    next(row for row in edits if row["key"] == existing["key"])["definition"] = revised_definition
    result = _revise(tmp_path, original, editor, label="Bladder revised in portal",
                     purpose="Review the baseline ECOG interpretation.", studies=["Study C"],
                     sections=["clinical", "outcomes"], proposed_source="Proposed claims delivery",
                     proposed_modality="claims", definitions=edits)
    assert result["ok"], result
    revised = result["run"]
    assert revised["id"] != original["id"]
    assert revised["revision_of"] == original["id"]
    assert revised["parent_sha256"] == editor["base_sha256"]
    assert revised["stage"] == "prepared" and revised["steps"] == []
    assert "report" not in revised and "completed_at" not in revised
    assert revised["releasable"] is False
    assert revised["label"] == "Bladder revised in portal"
    assert revised["plan"]["purpose"] == "Review the baseline ECOG interpretation."
    assert revised["plan"]["studies"] == ["Study C"]
    assert revised["plan"]["retained_sections"] == ["clinical", "outcomes"]
    assert revised["plan"]["proposed_source"] == "Proposed claims delivery"
    assert revised["plan"]["proposed_modality"] == "claims"
    assert revised["plan"]["applied_to_execution"] is False
    assert _files(parent) == parent_before
    assert journeys.read_run(ROOT, tmp_path, "scientist", original["id"])["run"] == original
    original_row, revised_row = _records(tmp_path, original)["ECOG"], _records(tmp_path, revised)["ECOG"]
    assert revised_row.cells["derivation"] == revised_definition
    assert revised_row.cells["required_rule"] == original_row.cells["required_rule"]
    assert revised_row.status == {"requirement": "draft", "source": "unverified",
                                  "implementation": "not_implemented", "validation": "not_run"}
    with zipfile.ZipFile(io.BytesIO(journeys.bundle(ROOT, tmp_path, "scientist", revised["id"]))) as packet:
        assert "qc-report.json" not in packet.namelist()
        assert not any(name.startswith("specification/") for name in packet.namelist())
    executed = journeys.execute(ROOT, tmp_path, "scientist", revised["id"], local_demo=True, can_write=True)
    assert executed["ok"], executed
    assert executed["run"]["stage"] == "complete"
    workers = {step["worker"]: step["exit_code"] for step in executed["run"]["steps"]}
    assert workers == {"platform/tools/run_spec_pipeline.py": 0,
                       "platform/tools/contract_lint.py": 0, "platform/engine/validate.py": 0}
    assert executed["run"]["report"]["proposal_changes_applied"] is False
    assert _files(parent) == parent_before
    assert _inputs() == fixtures_before


def test_revision_contract_findings_survive_checked_draft_completion(tmp_path):
    original = _template(tmp_path)
    saved = _revise(tmp_path, original, _editor(tmp_path, original))
    assert saved["ok"], saved
    real_worker = journeys.subprocess.run
    def worker(command, **kwargs):
        if Path(command[1]).name == "contract_lint.py":
            return subprocess.CompletedProcess(command, 1, "Draft contract needs scientific review", "")
        return real_worker(command, **kwargs)
    with patch.object(journeys.subprocess, "run", side_effect=worker) as called:
        result = journeys.execute(ROOT, tmp_path, "scientist", saved["run"]["id"],
                                  local_demo=True, can_write=True)
    assert any(Path(call.args[0][1]).name == "contract_lint.py" for call in called.call_args_list)
    assert result["ok"] and result["run"]["stage"] == "complete"
    assert result["run"]["report"]["draft_contract_check"] == "needs_attention"
    assert result["run"]["report"]["configuration_check"] == "passed"
    assert result["run"]["report"]["releasable"] is False
    assert any(step["exit_code"] == 1 and "scientific review" in step["output"]
               for step in result["run"]["steps"])


def test_revision_configuration_failure_still_blocks_draft_completion(tmp_path):
    original = _template(tmp_path)
    saved = _revise(tmp_path, original, _editor(tmp_path, original))
    assert saved["ok"], saved
    def worker(command, **kwargs):
        is_config = Path(command[1]).name == "validate.py"
        return subprocess.CompletedProcess(command, 1 if is_config else 0,
                                           "Configuration needs repair" if is_config else "Checked", "")
    with patch.object(journeys.subprocess, "run", side_effect=worker):
        result = journeys.execute(ROOT, tmp_path, "scientist", saved["run"]["id"],
                                  local_demo=True, can_write=True)
    assert not result["ok"] and result["run"]["stage"] == "needs_attention"
    assert "report" not in result["run"]
    assert result["run"]["steps"][-1]["exit_code"] == 1


def test_only_an_edited_generated_definition_is_added_to_the_scientific_draft(tmp_path):
    original = _template(tmp_path, complete=True)
    editor = _editor(tmp_path, original)
    assert len(editor["definitions"]) == 16
    generated = next(row for row in editor["definitions"] if row["origin"] == "scaffold")
    edits = _payload(editor)["definitions"]
    literal = "Draft for scientific review: " + generated["source_definition"]
    next(row for row in edits if row["key"] == generated["key"])["definition"] = literal
    result = _revise(tmp_path, original, editor, definitions=edits)
    assert result["ok"], result
    changed = result["run"]
    rows = _records(tmp_path, changed)
    assert set(rows) == {"ECOG", generated["variable_id"]}
    new_row = rows[generated["variable_id"]]
    assert new_row.cells["required_rule"] == generated["source_definition"]
    assert new_row.cells["derivation"] == literal
    assert new_row.status == {"requirement": "draft", "source": "unverified",
                              "implementation": "not_implemented", "validation": "not_run"}
    assert changed["plan"]["draft_interpretations_applied"] is True
    assert changed["plan"]["definition_changes"][0]["key"] == generated["key"]
    assert any(item["kind"] == "derivation" for item in changed["plan"]["engineering_handoff"])
    assert set(_records(tmp_path, original)) == {"ECOG"}
    outcome = journeys.execute(ROOT, tmp_path, "scientist", changed["id"], local_demo=True, can_write=True)
    assert outcome["ok"], outcome
    assert outcome["run"]["report"]["releasable"] is False
    reopened = _editor(tmp_path, outcome["run"])
    assert len(reopened["definitions"]) == 16
    assert next(row for row in reopened["definitions"] if row["key"] == generated["key"])["definition"] == literal


def test_duplicate_gist_source_rows_keep_their_editor_keys_after_one_is_drafted(tmp_path):
    prepared = journeys.prepare(ROOT, tmp_path, "scientist", journey="new", example_id="gist",
                                 label="Duplicate GIST source definitions", purpose="Review each cited KIT mutation row.",
                                 local_demo=True, can_write=True)
    assert prepared["ok"], prepared
    completed = journeys.execute(ROOT, tmp_path, "scientist", prepared["run"]["id"],
                                  local_demo=True, can_write=True)
    assert completed["ok"], completed
    original = completed["run"]
    editor = _editor(tmp_path, original)
    duplicates = [row for row in editor["definitions"] if row["variable_id"].startswith("KIT_MUT")]
    assert len(duplicates) == 2 and len({row["key"] for row in duplicates}) == 2
    edits = _payload(editor)["definitions"]
    next(row for row in edits if row["key"] == duplicates[0]["key"])["definition"] = "TODO: Review this cited KIT mutation rule with the scientific team."
    revised = _revise(tmp_path, original, editor, definitions=edits)
    assert revised["ok"], revised
    rerun = journeys.execute(ROOT, tmp_path, "scientist", revised["run"]["id"], local_demo=True, can_write=True)
    assert rerun["ok"], rerun
    reopened = _editor(tmp_path, rerun["run"])
    for row in duplicates:
        matching = next(item for item in reopened["definitions"] if item["spec_refs"] == row["spec_refs"])
        assert matching["key"] == row["key"]
    # A second save must preserve the distinct still-generated row despite a
    # display suffix changing when the first duplicate moves into the contract.
    second = _revise(tmp_path, rerun["run"], reopened)
    assert second["ok"], second
    assert len(_records(tmp_path, second["run"])) == 1


@pytest.mark.parametrize("field", ["can_write", "local_demo"])
def test_rehearsal_revision_rechecks_access_before_writing(tmp_path, field):
    original = _template(tmp_path)
    editor = _editor(tmp_path, original)
    before = _files(tmp_path)
    refused = _revise(tmp_path, original, editor, **{field: False})
    assert not refused["ok"]
    assert _files(tmp_path) == before


def test_rehearsal_revision_refuses_cross_actor_parent(tmp_path):
    original = _template(tmp_path)
    editor = _editor(tmp_path, original)
    before = _files(tmp_path)
    assert not revisions.read_editor(ROOT, tmp_path, "another_scientist", original["id"])["ok"]
    result = revisions.revise(ROOT, tmp_path, "another_scientist", original["id"], **_payload(editor))
    assert not result["ok"]
    assert _files(tmp_path) == before


@pytest.mark.parametrize("target", ["record", "input"])
def test_rehearsal_revision_refuses_changed_parent_snapshot(tmp_path, target):
    original = _template(tmp_path)
    editor = _editor(tmp_path, original)
    parent = journeys._folder(ROOT, tmp_path, "scientist", original["id"])
    if target == "record":
        record_path = parent / "rehearsal.json"
        record = json.loads(record_path.read_text(encoding="utf-8"))
        record["label"] = "Changed by another session"
        record_path.write_text(json.dumps(record), encoding="utf-8")
    else:
        source = parent / original["product"] / "source_refs.yaml"
        source.write_text(source.read_text(encoding="utf-8") + "\n# changed after opening editor\n", encoding="utf-8")
    before = _files(tmp_path)
    result = _revise(tmp_path, original, editor)
    assert not result["ok"] and result["errors"]
    assert _files(tmp_path) == before


@pytest.mark.parametrize("kind", ["unknown", "missing", "duplicate", "blank"])
def test_definition_editor_requires_complete_known_literal_rows(tmp_path, kind):
    original = _template(tmp_path)
    editor = _editor(tmp_path, original)
    edits = copy.deepcopy(_payload(editor)["definitions"])
    assert edits
    if kind == "unknown":
        edits[0]["key"] = "unrecognized-definition"
    elif kind == "missing":
        edits = []
    elif kind == "duplicate":
        edits.append(copy.deepcopy(edits[0]))
    else:
        edits[0]["definition"] = "   "
    before = _files(tmp_path)
    result = _revise(tmp_path, original, editor, definitions=edits)
    assert not result["ok"]
    assert _files(tmp_path) == before


def test_running_rehearsal_cannot_be_revised(tmp_path):
    original = _template(tmp_path)
    editor = _editor(tmp_path, original)
    parent = journeys._folder(ROOT, tmp_path, "scientist", original["id"])
    (parent / ".running").write_text("another session is executing", encoding="utf-8")
    before = _files(tmp_path)
    assert not _revise(tmp_path, original, editor)["ok"]
    assert _files(tmp_path) == before


if __name__ == "__main__":
    raise SystemExit(run(globals()))
