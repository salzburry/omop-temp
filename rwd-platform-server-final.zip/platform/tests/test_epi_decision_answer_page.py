"""Explicit scientist answers, draft navigation and stale input through the real UI.

Run: python platform/tests/test_epi_decision_answer_page.py
All answer forms and registers are generated in temporary roots. No user product is written.
"""
from __future__ import annotations

import contextlib
import sys
import tempfile
import traceback
import types
from pathlib import Path
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[2]
sys.path[:0] = [str(ROOT / "platform/tests"), str(ROOT / "experiments/portal"), str(ROOT / "platform/tools")]
import contract_lint as cl
import decision_record as dr
from test_epi_portal_journeys import _healthy, _portal

PACK = "products/oncology/example/202609"
VALUES = {"answer": "Use the latest recorded assessment.", "answered_by": "Alice Smith", "answer_date": "2026-09-06"}


def _seed(root, pack=PACK, question="Which assessment date?", *, issue_forms=True):
    product = Path(root) / pack
    (product / "handoff").mkdir(parents=True)
    (product / dr.DECISIONS).write_text(
        "# Scientific decisions\n\n| ID | Question | Evidence | Owner | Resolution | Approved by | Approval date | Status |\n"
        "|---|---|---|---|---|---|---|---|\n"
        f"| Q1 | {question} | clinical:1 | Science | — | | | OPEN |\n"
        "| Q2 | Which measurement unit? | clinical:2 | Science | — | | | OPEN |\n", encoding="utf-8")
    (product / "handoff/FUNCTIONAL_CONTRACT.md").write_text("# Contract drafting in progress\n", encoding="utf-8")
    if issue_forms:
        written, _, error = dr.write_forms(pack, root=str(root))
        assert len(written) == 2 and not error
    return product


def _bytes(root):
    return {path.relative_to(root).as_posix(): path.read_bytes() for path in Path(root).rglob("*") if path.is_file()}


@contextlib.contextmanager
def _page(*, can_write=True, local_demo=True, question="Which assessment date?", issue_forms=True, initial_decision_id=None,
          prepared_answer=None):
    from streamlit.testing.v1 import AppTest

    with tempfile.TemporaryDirectory(prefix="epi-decision-ui-") as td, contextlib.ExitStack() as stack:
        case = types.ModuleType("_epi_decision_case")
        case.root, case.pack, case.actor = td, PACK, "Priya"
        case.can_write, case.can_view, case.local_demo = can_write, True, local_demo
        case.product, case.saved = _seed(td, question=question, issue_forms=issue_forms), 0
        if prepared_answer is not None:
            import yaml
            path = case.product / dr.FORMS_DIR / "Q1.yaml"
            doc = yaml.safe_load(path.read_text(encoding="utf-8"))
            doc.update(prepared_answer)
            path.write_text(yaml.safe_dump(doc, sort_keys=False), encoding="utf-8")
        case.initial_decision_id = initial_decision_id
        previous = sys.modules.get(case.__name__)
        sys.modules[case.__name__] = case
        stack.callback(lambda: sys.modules.pop(case.__name__, None) if previous is None
                       else sys.modules.__setitem__(case.__name__, previous))
        source = """import streamlit as st
import decision_answer_page
import _epi_decision_case as case
st.set_page_config(layout='wide')
if decision_answer_page.render(case.root, case.pack, case.actor, local_demo=case.local_demo,
                               can_write=case.can_write, can_view=case.can_view, initial_decision_id=case.initial_decision_id):
    case.saved += 1
    st.rerun()
"""
        at = AppTest.from_string(source, default_timeout=30).run()
        _healthy(at)
        yield at, case


def _fill(at, did="Q1", **changes):
    values = {**VALUES, **changes}
    at.text_area(key=f"decision_answer_{did}_answer").set_value(values["answer"])
    for field in ("answered_by", "answer_date"):
        at.text_input(key=f"decision_answer_{did}_{field}").set_value(values[field])


def _select(at, did):
    at.selectbox(key="decision_answer_selected").set_value(did).run()
    _healthy(at)


def _save(at):
    at.button(key="decision_answer_save").click().run()
    _healthy(at)


def _statuses(case):
    return cl.decision_status((case.product / dr.DECISIONS).read_text(encoding="utf-8"))


def test_answer_fields_start_blank_without_inferred_reviewer_date_or_decision():
    with _page() as (at, case):
        before = _bytes(case.root)
        assert at.text_area(key="decision_answer_Q1_answer").value == ""
        assert at.text_input(key="decision_answer_Q1_answered_by").value == ""
        assert at.text_input(key="decision_answer_Q1_answer_date").value == ""
        _save(at)
        assert (at.info or at.warning) and not at.success
        assert _bytes(case.root) == before and case.saved == 0


def test_question_drafts_survive_round_trip_navigation_and_each_saved_answer_is_literal():
    with _page() as (at, case):
        _fill(at)
        _select(at, "Q2")
        _fill(at, "Q2", answer="Use milligrams.")
        _select(at, "Q1")
        assert at.text_area(key="decision_answer_Q1_answer").value == VALUES["answer"]
        assert at.text_input(key="decision_answer_Q1_answered_by").value == VALUES["answered_by"]
        _select(at, "Q2")
        assert at.text_area(key="decision_answer_Q2_answer").value == "Use milligrams."
        _save(at)
        assert _statuses(case) == {"Q1": "OPEN", "Q2": "RESOLVED"}
        _select(at, "Q1")
        assert at.text_area(key="decision_answer_Q1_answer").value == VALUES["answer"]
        _save(at)
        assert _statuses(case) == {"Q1": "RESOLVED", "Q2": "RESOLVED"}
        assert case.saved == 2
        assert dr.check_bindings(PACK, root=case.root) == []
        assert not any("APPROVAL" in path or "SIGNATURE" in path for path in _bytes(case.root))
        _select(at, "Q1")
        assert at.text_area(key="decision_answer_Q1_answer").disabled
        assert at.text_area(key="decision_answer_Q1_answer").value == VALUES["answer"]


def test_completed_answer_saves_while_another_partial_draft_is_retained():
    with _page() as (at, case):
        _fill(at)
        _select(at, "Q2")
        at.text_area(key="decision_answer_Q2_answer").set_value("A partial unit decision awaiting its owner.")
        _select(at, "Q1")
        _save(at)
        assert _statuses(case) == {"Q1": "RESOLVED", "Q2": "OPEN"}
        assert case.saved == 1
        _select(at, "Q2")
        assert at.text_area(key="decision_answer_Q2_answer").value == "A partial unit decision awaiting its owner."
        assert at.text_input(key="decision_answer_Q2_answered_by").value == ""
        assert at.text_input(key="decision_answer_Q2_answer_date").value == ""


def test_reordering_after_one_answer_save_stays_responsive_and_prevents_ruling_overwrite():
    with _page() as (at, case):
        _fill(at)
        _save(at)
        assert _statuses(case) == {"Q1": "RESOLVED", "Q2": "OPEN"}
        _select(at, "Q1")
        assert at.text_area(key="decision_answer_Q1_answer").disabled
        assert at.text_area(key="decision_answer_Q1_answer").value == VALUES["answer"]
        at.button(key="decision_answer_reload").click().run()
        _healthy(at)
        _select(at, "Q1")
        assert at.text_area(key="decision_answer_Q1_answer").value == VALUES["answer"]


def test_changed_question_or_contract_before_save_refuses_and_preserves_the_entered_answer():
    for mode in ("question", "contract"):
        with _page() as (at, case):
            _fill(at)
            path = case.product / (dr.DECISIONS if mode == "question" else "handoff/FUNCTIONAL_CONTRACT.md")
            old = path.read_text(encoding="utf-8")
            path.write_text(old.replace("Which assessment date?", "Which baseline assessment date?") if mode == "question"
                            else old + "\nA newly clarified requirement.\n", encoding="utf-8")
            before = _bytes(case.root)
            _save(at)
            assert any("changed while this page was open" in e.value for e in at.error)
            assert _bytes(case.root) == before and case.saved == 0
            assert at.text_area(key="decision_answer_Q1_answer").value == VALUES["answer"]


def test_read_only_hosted_or_revoked_access_cannot_save_answers():
    for can_write, local_demo in ((False, True), (True, False)):
        with _page(can_write=can_write, local_demo=local_demo) as (at, case):
            before = _bytes(case.root)
            assert at.button(key="decision_answer_save").disabled
            assert at.text_area(key="decision_answer_Q1_answer").disabled
            _save(at)
            assert _bytes(case.root) == before and case.saved == 0
    with _page() as (at, case):
        _fill(at)
        before = _bytes(case.root)
        case.can_view = False
        _save(at)
        assert _bytes(case.root) == before and case.saved == 0
        assert not at.text_area


def test_actor_or_pack_switch_with_stale_save_does_not_apply_another_contexts_answer():
    for dimension in ("actor", "pack"):
        with _page() as (at, case):
            _fill(at)
            other_pack = "products/oncology/another/202609"
            _seed(case.root, other_pack)
            before = _bytes(case.root)
            if dimension == "actor":
                case.actor = "Another scientist"
            else:
                case.pack = other_pack
            _save(at)
            assert _bytes(case.root) == before and case.saved == 0
            assert at.text_area(key="decision_answer_Q1_answer").value == ""


def test_question_source_text_does_not_create_an_accidental_local_navigation_link():
    question = "How should [INDEX](missing.md) be anchored?"
    with _page(question=question) as (at, _case):
        assert not any("](missing.md)" in md.value for md in at.markdown)
        assert any("INDEX" in str(getattr(e, "value", "")) for e in list(at.text) + list(at.markdown))


@contextlib.contextmanager
def _app(role="initiator", *, scoped=False, report_state="absent", register=True):
    """Exercise app navigation with real answer/report I/O in a temporary root."""
    import decision_answer_page
    import connected_workflow

    pack = "fixtures/oncology/prostate/202606"
    with tempfile.TemporaryDirectory(prefix="epi-answers-app-") as td:
        product = _seed(td, pack)
        if report_state == "stale":
            (product / "handoff/SCIENCE_QUESTIONS.md").write_text(
                "# Outdated generated report\n\n## 1. `OBSOLETE` — unblocks 99 record(s)\n\n"
                "**Owner:** Old owner\n\nThis obsolete question is no longer open.\n", encoding="utf-8")
        if not register:
            (product / dr.DECISIONS).unlink()
        render = decision_answer_page.render
        question_report = connected_workflow.question_report
        def isolated(root, selected_pack, actor_id, **kwargs):
            return render(td, selected_pack, actor_id, **kwargs)
        def isolated_report(root, selected_pack, **kwargs):
            return question_report(td, selected_pack, **kwargs)
        users = [{"name": "Priya", "role": role, "owns": ["Science"], "packs": [pack]}] if scoped else None
        with patch.object(decision_answer_page, "render", side_effect=isolated), \
             patch.object(connected_workflow, "question_report", side_effect=isolated_report), \
             _portal(role=role, users=users) as at:
            at.selectbox(key="pack").set_value(pack).run()
            at.radio(key="section").set_value("Open questions").run()
            _healthy(at)
            yield at, Path(td), product, pack


def test_actual_open_questions_roles_save_only_explicit_answers_and_refresh_in_place():
    for role in ("initiator", "reviewer", "admin", "viewer", "qc_programmer"):
        with _app(role, scoped=True) as (at, root, product, pack):
            before = _bytes(root)
            allowed = role in ("initiator", "reviewer", "admin")
            assert at.button(key="decision_answer_save").disabled is not allowed
            assert len(at.selectbox(key="pack").options) == 1 and at.selectbox(key="pack").value == pack
            if allowed:
                _fill(at)
                at.session_state["flow_result"] = {pack: {"stale": "prior answer state"}}
                _save(at)
                assert cl.decision_status((product / dr.DECISIONS).read_text(encoding="utf-8"))["Q1"] == "RESOLVED"
                assert at.radio(key="section").value == "Open questions"
                assert pack not in at.session_state["flow_result"]
                assert any("saved" in message.value.lower() for message in at.success)
                at.button(key="decision_answer_reload").click().run()
                _healthy(at)
                _select(at, "Q1")
                assert at.text_area(key="decision_answer_Q1_answer").disabled
                assert at.text_area(key="decision_answer_Q1_answer").value == VALUES["answer"]
            else:
                _save(at)
                assert _bytes(root) == before


def test_actual_workspace_navigation_retains_an_unfinished_scientific_answer():
    with _app() as (at, root, _product, _pack):
        before = _bytes(root)
        at.text_area(key="decision_answer_Q1_answer").set_value("Draft ruling awaiting the source review.").run()
        at.radio(key="section").set_value("Search & definitions").run()
        _healthy(at)
        at.radio(key="section").set_value("Open questions").run()
        _healthy(at)
        assert at.text_area(key="decision_answer_Q1_answer").value == "Draft ruling awaiting the source review."
        assert _bytes(root) == before


def _ranked_ids(at):
    tables = [frame.value for frame in at.dataframe if "decision" in frame.value.columns]
    return tables[-1]["decision"].tolist() if tables else []


def test_actual_question_ranking_uses_live_register_when_generated_report_is_absent_or_stale():
    for report_state in ("absent", "stale"):
        with _app(scoped=True, report_state=report_state) as (at, root, product, _pack):
            report = product / "handoff/SCIENCE_QUESTIONS.md"
            generated_before = report.read_bytes() if report.exists() else None
            assert _ranked_ids(at) == ["Q1", "Q2"]
            assert any("2 open question(s)" in heading.value for heading in at.subheader)
            assert not any("No recorded questions are open" in message.value for message in at.info)
            at.selectbox(key="q_owner").set_value("Science").run()
            _healthy(at)
            assert _ranked_ids(at) == ["Q1", "Q2"]
            assert any(metric.label == "owner" and metric.value == "Science" for metric in at.metric)
            _fill(at)
            _save(at)
            assert _ranked_ids(at) == ["Q2"]
            assert any("1 open question(s)" in heading.value for heading in at.subheader)
            _select(at, "Q2")
            _fill(at, "Q2", answer="Use milligrams.")
            _save(at)
            assert _ranked_ids(at) == []
            assert any("0 open question(s)" in heading.value for heading in at.subheader)
            assert any("No recorded questions are open" in message.value for message in at.info)
            assert cl.decision_status((product / dr.DECISIONS).read_text(encoding="utf-8")) == {
                "Q1": "RESOLVED", "Q2": "RESOLVED"}
            assert report.read_bytes() != generated_before
            assert report.read_text(encoding="utf-8") == dr.question_report_text(_pack, str(root))


def test_actual_missing_question_register_explains_prerequisite_instead_of_claiming_none_are_open():
    with _app(scoped=True, report_state="stale", register=False) as (at, root, _product, _pack):
        before = _bytes(root)
        messages = "\n".join(message.value for message in list(at.info) + list(at.warning) + list(at.error))
        assert "register" in messages.lower() and ("prepare" in messages.lower() or "progress" in messages.lower())
        assert "No recorded questions are open" not in messages
        assert not any("0 open question(s)" in heading.value for heading in at.subheader)
        assert not _ranked_ids(at)
        assert any(button.key == "questions_open_flow" for button in at.button)
        assert _bytes(root) == before


def _raise(at, did="Q3", question="Which death date source is used?", evidence="clinical:5", owner="Science"):
    at.text_input(key="decision_answer_raise_id").set_value(did)
    at.text_area(key="decision_answer_raise_question").set_value(question)
    at.text_input(key="decision_answer_raise_evidence").set_value(evidence)
    at.selectbox(key="decision_answer_raise_owner").set_value(owner)
    at.button(key="decision_answer_raise").click().run()
    _healthy(at)


def _plain(text):
    import re
    return not re.search(r"[A-Za-z]:[\\/]|Errno|--forms| — |->", text)


def test_raising_a_question_from_the_page_records_one_open_row_and_keeps_unsaved_drafts():
    """DL-03: there was no in-portal way to put a new scientific question into the register."""
    with _page() as (at, case):
        register = case.product / dr.DECISIONS
        before_lines = register.read_text(encoding="utf-8").splitlines()
        at.text_area(key="decision_answer_Q1_answer").set_value("Draft ruling awaiting the source review.").run()
        _healthy(at)
        assert at.selectbox(key="decision_answer_raise_owner").options == ["Science"]
        assert at.selectbox(key="decision_answer_raise_owner").value is None
        _raise(at)
        text = register.read_text(encoding="utf-8")
        assert _statuses(case) == {"Q1": "OPEN", "Q2": "OPEN", "Q3": "OPEN"}
        rows = cl.decision_rows(text)
        assert cl.decision_question(rows["Q3"]) == "Which death date source is used?" and cl.decision_owner(rows["Q3"]) == "Science"
        assert not cl.decision_approver(rows["Q3"]) and not cl.decision_approval_date(rows["Q3"])
        assert [line for line in text.splitlines() if not line.startswith("| Q3 ")] == before_lines
        assert any("Q3" in message.value and "nothing has been decided" in message.value for message in at.success)
        assert case.saved == 0
        assert at.text_area(key="decision_answer_Q1_answer").value == "Draft ruling awaiting the source review."
        assert at.text_input(key="decision_answer_raise_id").value == ""
        assert any("1 open question(s) need a draft answer form" in message.value for message in at.info)
        assert not any("APPROVAL" in path or "SIGNATURE" in path for path in _bytes(case.root))


def test_raise_refusals_stay_on_the_page_in_plain_words_and_write_nothing():
    with _page() as (at, case):
        before = _bytes(case.root)
        _raise(at, did="Q1")
        assert any("already in the register" in e.value and _plain(e.value) for e in at.error)
        assert _bytes(case.root) == before and case.saved == 0
        assert at.text_input(key="decision_answer_raise_id").value == "Q1"
        _raise(at, did="Q3", evidence="")
        assert any("before raising" in w.value for w in at.warning)
        assert _bytes(case.root) == before


def test_prepared_resolved_form_is_explained_as_open_until_reviewed_save():
    with _page(prepared_answer=VALUES) as (at, case):
        assert _statuses(case)["Q1"] == "OPEN"
        assert at.text_area(key="decision_answer_Q1_answer").value == VALUES["answer"]
        assert any("question remains open" in c.value and "proposed outcome" in c.value for c in at.caption)
        _save(at)
        assert _statuses(case)["Q1"] == "RESOLVED"


def test_read_only_or_hosted_sessions_cannot_raise_a_question():
    for can_write, local_demo in ((False, True), (True, False)):
        with _page(can_write=can_write, local_demo=local_demo) as (at, case):
            before = _bytes(case.root)
            assert at.button(key="decision_answer_raise").disabled
            assert at.text_input(key="decision_answer_raise_id").disabled
            at.button(key="decision_answer_raise").click().run()
            _healthy(at)
            assert _bytes(case.root) == before


def test_a_stale_lock_on_the_questions_page_is_cleared_with_one_click():
    """DL-06 on the page: the refusal is plain, and only a lock older than ten minutes can be cleared."""
    import os
    import time
    import decision_answers as answers
    with _page() as (at, case):
        lock = case.product / answers.LOCK_NAME
        lock.write_text("left behind", encoding="utf-8")
        _fill(at)
        _save(at)
        assert any(e.value == answers.LOCK_MESSAGE for e in at.error)
        assert not any("Errno" in e.value or str(case.product) in e.value for e in at.error)
        assert not any(b.key == "decision_answer_clear_lock" for b in at.button)
        stale = time.time() - answers.LOCK_STALE_SECONDS - 60
        os.utime(lock, (stale, stale))
        _save(at)
        assert any("stale" in e.value and _plain(e.value) for e in at.error)
        assert _statuses(case)["Q1"] == "OPEN" and lock.exists()
        at.button(key="decision_answer_clear_lock").click().run()
        _healthy(at)
        assert not lock.exists() and any("cleared" in message.value for message in at.success)
        assert at.text_area(key="decision_answer_Q1_answer").value == VALUES["answer"]
        _save(at)
        assert _statuses(case)["Q1"] == "RESOLVED" and case.saved == 1


def test_records_waiting_for_a_recheck_are_listed_and_settled_from_the_page():
    """DL-04 on the page: a citing record moves off decision_required by the person's click."""
    from streamlit.testing.v1 import AppTest
    from test_epi_scientific_definitions import fixture, ACTOR
    from test_contract_lint import one

    with tempfile.TemporaryDirectory(prefix="epi-recheck-ui-") as td:
        root, pack, product, _values = fixture(Path(td), [one(req="decision_required", impl="not_implemented", decs="FUED-RULE")])
        source = f"""import streamlit as st
import decision_answer_page
st.set_page_config(layout='wide')
if decision_answer_page.render({str(root)!r}, {pack!r}, {ACTOR!r}, local_demo=True, can_write=True, can_view=True):
    st.rerun()
"""
        at = AppTest.from_string(source, default_timeout=60).run()
        _healthy(at)
        assert any("PDL1_TPS cites FUED-RULE" in text.value for text in at.text)
        assert any("Nothing in the record is edited" in caption.value for caption in at.caption)
        before = (product / "handoff/FUNCTIONAL_CONTRACT.md").read_text(encoding="utf-8")
        at.button(key="decision_answer_recheck_PDL1_TPS").click().run()
        _healthy(at)
        assert any("PDL1_TPS re-checked" in message.value and "now draft" in message.value for message in at.success)
        after = (product / "handoff/FUNCTIONAL_CONTRACT.md").read_text(encoding="utf-8")
        assert after != before and "requirement: draft" in after and "decision_required" not in after
        assert cl.run(str(product))[0] == []
        assert not any(b.key == "decision_answer_recheck_PDL1_TPS" for b in at.button)
        assert not any("APPROVAL" in path or "SIGNATURE" in path for path in _bytes(root))


if __name__ == "__main__":
    failed = 0
    for name, fn in sorted(list(globals().items())):
        if name.startswith("test_") and callable(fn):
            try:
                fn()
                print(f"  ok   {name}", flush=True)
            except Exception:
                failed += 1
                print(f"  FAIL {name}", flush=True)
                traceback.print_exc()
    print(f"{failed} failure(s)")
    sys.exit(1 if failed else 0)
