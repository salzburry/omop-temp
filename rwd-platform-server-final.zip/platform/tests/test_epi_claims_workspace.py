"""Claims uses the real exporter and disposable registered specification bytes."""
import hashlib
import contextlib
import importlib.util
from pathlib import Path
import sys
from unittest.mock import patch

import pytest
import yaml

ROOT = Path(__file__).resolve().parents[2]
sys.path[:0] = [str(ROOT / "experiments/portal"), str(ROOT / "platform/tools"), str(ROOT / "platform")]
import claims_workspace as claims
import cohortly_export as exporter

PACK = "products/oncology/claims_epi/202609"
ACTOR = "test-claims-drafter"
VALUES = {"events": [{"name": "ovarian", "dx_cd": "ovarian_dx"}],
          "criteria": {"studypoppage:Criterion 1 (INCLUSION)": "ovarian"}, "ignore_tabs": []}


@pytest.fixture
def checkout(tmp_path, monkeypatch):
    root = tmp_path / "repo"
    product = root / PACK
    (product / "prog_spec").mkdir(parents=True)
    (product / "config").mkdir()
    (product / "config/data_product.yaml").write_text("variables: []\ncodelists: {}\n", encoding="utf-8")
    (root / "products/registry.yaml").write_text(yaml.safe_dump({"tumors": [{"slug": "claims_epi", "code": "claims_epi",
        "modality": "claims", "current_spec_version": "202609", "vendor": "flatiron", "tumor_class": "solid"}]}), encoding="utf-8")
    spec = importlib.util.spec_from_file_location("claims_test_inputs", ROOT / "platform/uat/cohortly/make_inputs.py")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    workbook = Path(module.build_workbook(str(product / "prog_spec")))
    (product / "source_refs.yaml").write_text(yaml.safe_dump({"product": "claims_epi", "spec_version": "202609",
        "source_materials": [{"material_id": "program_spec", "material_type": "program_spec", "status": "pending",
        "path_or_link": workbook.relative_to(root).as_posix(), "sha256": hashlib.sha256(workbook.read_bytes()).hexdigest()}]}), encoding="utf-8")
    monkeypatch.setenv("RWD_SOURCE_WORKSPACE_DIR", str(tmp_path / "private"))
    return root


def describe(root):
    return claims.describe(root, PACK, ACTOR, allowed_packs=[PACK])


def stage(root, values=VALUES):
    report = describe(root)
    assert report["ok"], report
    result = claims.stage(root, PACK, ACTOR, values=values, expected_digest=report["input_digest"],
        allowed_packs=[PACK], local_demo=True, can_write=True)
    return report, result


def test_registered_workbook_to_checked_branch_bindings_and_owned_runtime_request(checkout):
    before = {p.relative_to(checkout).as_posix(): p.read_bytes() for p in checkout.rglob("*") if p.is_file()}
    report, result = stage(checkout)
    assert report["gaps"] and result["ok"], result
    proposal = result["proposal"]
    checked = proposal["payload"]["report"]
    assert not checked["gaps"] and "trace_event_count" in checked["script"]
    assert "config/cohortly_bindings.yaml (proposed)" in proposal["payload"]["diff"]
    assert "UNGOVERNED" in checked["manifest"]
    assert "study_period_start_dt: '2019-01-01'" in checked["manifest"]
    assert {p.relative_to(checkout).as_posix(): p.read_bytes() for p in checkout.rglob("*") if p.is_file()} == before
    saved = claims.save_bindings(checkout, PACK, ACTOR, proposal_id=proposal["id"], expected_digest=proposal["inputs_sha256"],
        confirmed=True, allowed_packs=[PACK], local_demo=True, can_write=True)
    assert saved["ok"] and saved["changed"], saved
    actual = checkout / PACK / claims.BINDINGS
    assert actual.read_bytes() == proposal["payload"]["bindings"].encode()
    assert hashlib.sha256(actual.read_bytes()).hexdigest() == checked["bindings_sha256"]
    after = describe(checkout)
    assert after["ok"] and not after["gaps"] and after["manifest"] == checked["manifest"]
    request = claims.request_review(checkout, PACK, ACTOR, proposal_id=proposal["id"], note="Review the declared runtime before any UAT.",
        allowed_packs=[PACK], local_demo=True, can_write=True)
    assert request["ok"] and request["handoff"]["owner"] == "Engineering", request
    assert checked["manifest_sha256"] in request["handoff"]["note"]
    assert "no governed claims receipt" in request["handoff"]["note"]
    review = claims.review_status(checkout, PACK, "test-runtime-reviewer", handoff_id=request["handoff"]["id"], allowed_packs=[PACK])
    assert review["ok"] and not review["stale"], review
    actual.write_bytes(actual.read_bytes() + b"\n# edited after the request\n")
    review = claims.review_status(checkout, PACK, "test-runtime-reviewer", handoff_id=request["handoff"]["id"], allowed_packs=[PACK])
    assert review["ok"] and review["stale"], review
    assert (checkout / PACK / "source_refs.yaml").read_bytes() == before[PACK + "/source_refs.yaml"]
    assert claims.recent(checkout, PACK, ACTOR, allowed_packs=[PACK])[0]["params"] == {"proposal_id": proposal["id"]}


@pytest.mark.parametrize("other_route", ["source_requirements", "unrelated_workspace"])
def test_claims_reader_opt_in_preserves_source_route_and_private_scope_boundaries(checkout, other_route):
    _report, result = stage(checkout)
    proposal = result["proposal"]
    scope = claims._scope(checkout, PACK, ACTOR, [PACK])
    with pytest.raises(claims.storage.Invalid, match="unsupported format"):
        claims.storage._load(scope, proposal["id"])
    assert claims.read(checkout, PACK, ACTOR, proposal_id=proposal["id"], allowed_packs=[PACK])["ok"]
    assert not claims.storage.read(checkout, PACK, ACTOR, record_id=proposal["id"], allowed_packs=[PACK])["ok"]
    assert claims.ROUTE not in claims.storage.ROUTES
    proposal["route"] = other_route
    claims.storage._write(scope[4], proposal)
    assert not claims.read(checkout, PACK, ACTOR, proposal_id=proposal["id"], allowed_packs=[PACK])["ok"]
    assert claims.recent(checkout, PACK, ACTOR, allowed_packs=[PACK]) == []
    assert not (checkout / PACK / claims.BINDINGS).exists()


@pytest.mark.parametrize("values", [
    {**VALUES, "events": [{"name": "ovarian", "dx_cd": "ovarian_dx"}, {"name": "ovarian", "ndc_cd": "ovarian_dx"}]},
    {**VALUES, "events": [{"name": "ovarian", "ndc_cd": "ovarian_dx"}]},
    {**VALUES, "events": [{"name": "x);system('bad')", "dx_cd": "ovarian_dx"}]},
    {**VALUES, "criteria": {"different sheet:Criterion 1 (INCLUSION)": "ovarian"}},
    {**VALUES, "ignore_tabs": ["ovarian_dx"]},
    {**VALUES, "min_age": 65},
])
def test_invalid_or_invented_bindings_refuse_without_canonical_write(checkout, values):
    _report, result = stage(checkout, values)
    assert not result["ok"]
    assert not (checkout / PACK / claims.BINDINGS).exists()


def test_incomplete_bindings_keep_gaps_and_do_not_claim_execution(checkout):
    _report, result = stage(checkout, {**VALUES, "criteria": {}})
    assert result["ok"], result
    assert result["proposal"]["payload"]["report"]["gaps"]
    assert "scientific" in result["notice"].lower()


def test_invalid_current_bindings_can_be_repaired_with_an_exact_before_after_diff(checkout):
    path = checkout / PACK / claims.BINDINGS
    bad = "events: [not valid\n"
    path.write_bytes(bad.encode())
    report, result = stage(checkout)
    assert report["ok"] and report["binding_errors"] and report["current_bindings"] == bad
    assert result["ok"] and result["proposal"]["payload"]["before"] == bad
    assert "-events: [not valid" in result["proposal"]["payload"]["diff"]


def test_stale_inputs_actor_and_access_refuse_copy_or_save(checkout):
    _report, result = stage(checkout)
    proposal = result["proposal"]
    assert not claims.read(checkout, PACK, "someone-else", proposal_id=proposal["id"], allowed_packs=[PACK])["ok"]
    assert not claims.read(checkout, PACK, ACTOR, proposal_id=proposal["id"], allowed_packs=[])["ok"]
    path = checkout / PACK / "source_refs.yaml"
    path.write_bytes(path.read_bytes() + b"\n# changed\n")
    saved = claims.save_bindings(checkout, PACK, ACTOR, proposal_id=proposal["id"], expected_digest=proposal["inputs_sha256"],
        confirmed=True, allowed_packs=[PACK], local_demo=True, can_write=True)
    assert not saved["ok"] and not (checkout / PACK / claims.BINDINGS).exists()


def test_failed_private_receipt_write_rolls_back_own_binding_bytes(checkout):
    _report, result = stage(checkout)
    proposal = result["proposal"]
    with patch.object(claims.storage, "_write", side_effect=OSError("test activity write failed")):
        saved = claims.save_bindings(checkout, PACK, ACTOR, proposal_id=proposal["id"], expected_digest=proposal["inputs_sha256"],
            confirmed=True, allowed_packs=[PACK], local_demo=True, can_write=True)
    assert not saved["ok"] and not (checkout / PACK / claims.BINDINGS).exists()


def test_concurrent_source_change_during_save_is_not_blessed_by_a_new_digest(checkout):
    _report, result = stage(checkout)
    proposal = result["proposal"]
    source = checkout / PACK / "source_refs.yaml"
    original = claims.os.replace
    def race(src, dst):
        original(src, dst)
        source.write_bytes(source.read_bytes() + b"\n# concurrent source review\n")
    with patch.object(claims.os, "replace", side_effect=race):
        saved = claims.save_bindings(checkout, PACK, ACTOR, proposal_id=proposal["id"], expected_digest=proposal["inputs_sha256"],
            confirmed=True, allowed_packs=[PACK], local_demo=True, can_write=True)
    assert not saved["ok"] and not (checkout / PACK / claims.BINDINGS).exists()
    assert b"concurrent source review" in source.read_bytes()


@pytest.mark.parametrize("same_bytes", [False, True])
def test_binding_edit_just_before_publication_is_never_overwritten_or_removed(checkout, same_bytes):
    _report, result = stage(checkout)
    proposal = result["proposal"]
    path = checkout / PACK / claims.BINDINGS
    external = proposal["payload"]["bindings"].encode() if same_bytes else b"events: {}\n# another drafter\n"
    original = claims.tempfile.NamedTemporaryFile
    @contextlib.contextmanager
    def race(*args, **kwargs):
        with original(*args, **kwargs) as handle:
            yield handle
        path.write_bytes(external)
    with patch.object(claims.tempfile, "NamedTemporaryFile", side_effect=race):
        saved = claims.save_bindings(checkout, PACK, ACTOR, proposal_id=proposal["id"], expected_digest=proposal["inputs_sha256"],
            confirmed=True, allowed_packs=[PACK], local_demo=True, can_write=True)
    assert not saved["ok"] and path.read_bytes() == external


def test_product_lock_is_shared_across_actors_and_released_after_use(checkout):
    first = claims._scope(checkout, PACK, ACTOR, [PACK])
    second = claims._scope(checkout, PACK, "another drafter", [PACK])
    with claims._product_lock(first):
        with pytest.raises(ValueError, match="save is in progress"):
            with claims._product_lock(second):
                raise AssertionError("overlapping actor save was admitted")
    with claims._product_lock(second):
        pass


def test_tampered_report_cannot_be_presented_as_checked_or_sent_for_runtime_review(checkout):
    _report, result = stage(checkout, {**VALUES, "criteria": {}})
    proposal = result["proposal"]
    saved = claims.save_bindings(checkout, PACK, ACTOR, proposal_id=proposal["id"], expected_digest=proposal["inputs_sha256"],
        confirmed=True, allowed_packs=[PACK], local_demo=True, can_write=True)
    assert saved["ok"], saved
    tampered = saved["proposal"]
    assert tampered["payload"]["report"]["gaps"]
    tampered["payload"]["report"]["gaps"] = []
    folder = claims._scope(checkout, PACK, ACTOR, [PACK])[4]
    claims.storage._write(folder, tampered)
    assert not claims.read(checkout, PACK, ACTOR, proposal_id=proposal["id"], allowed_packs=[PACK])["ok"]
    request = claims.request_review(checkout, PACK, ACTOR, proposal_id=proposal["id"], note="Review this export.",
        allowed_packs=[PACK], local_demo=True, can_write=True)
    assert not request["ok"]
    assert not claims.handoffs.listing(checkout, PACK, allowed_packs=[PACK])


def test_ehr_and_cross_product_workbooks_refuse_before_export(checkout):
    registry = checkout / "products/registry.yaml"
    original = registry.read_text(encoding="utf-8")
    registry.write_text(original.replace("modality: claims", "modality: ehr"), encoding="utf-8")
    with patch.object(claims, "_export", side_effect=AssertionError("wrong modality reached exporter")):
        assert not describe(checkout)["ok"]
    registry.write_text(original, encoding="utf-8")
    source = checkout / PACK / "source_refs.yaml"
    doc = yaml.safe_load(source.read_bytes())
    doc["source_materials"][0]["path_or_link"] = "products/oncology/another/202609/prog_spec/private.xlsx"
    source.write_text(yaml.safe_dump(doc), encoding="utf-8")
    with patch.object(claims, "_export", side_effect=AssertionError("outside source reached exporter")):
        assert not describe(checkout)["ok"]
