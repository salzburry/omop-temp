"""Legacy capture, import and exports share the reviewed correction lifecycle."""
from pathlib import Path
import importlib.util
import json
import shutil
import subprocess
import sys
from types import SimpleNamespace

import pytest
import yaml

ROOT = Path(__file__).resolve().parents[2]
sys.path[:0] = [str(ROOT / relative) for relative in ('experiments/agent', 'experiments/portal', 'platform/tools')]
import learn

PACK = 'fixtures/oncology/example/202609'


@pytest.fixture
def checkout(tmp_path):
    shutil.copytree(ROOT / '.claude/skills', tmp_path / '.claude/skills')
    for tests in learn.DEFAULT_TESTS.values():
        for selector in tests:
            path = tmp_path / selector
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_text('def test_registered_behavior():\n    assert True\n', encoding='utf-8')
    lessons = [{'id': 'L000', 'recorded': '2026-09-01', 'corrected_by': 'Original reviewer',
        'context': 'Example product measure; original source context.', 'wrong': 'A label was treated as a reviewed meaning.',
        'right': 'Retain this measure as unresolved until its source-specific meaning is reviewed.', 'authority': 'Historical guidance only.'},
        {'id': 'L001', 'recorded': '2026-09-02', 'corrected_by': 'Original author',
        'context': 'Workflow answer forms across products.', 'wrong': 'An issued form was treated as an answer.',
        'right': 'Keep issued blank forms separate from reviewed answers.', 'authority': 'Historical guidance only.'}]
    cases = [{'id': 'lesson-l000', 'source': 'learning-loop L000', 'goal': 'Interpret the example label within its declared source.',
        'expect': {'outcome': ['done', 'escalated']}, 'adjudicate': 'The meaning remains a review question.'},
        {'id': 'ordinary-case', 'source': 'human-authored', 'goal': 'Inspect metadata.', 'expect': {'outcome': 'escalated'}}]
    for relative, value in ((learn.LEGACY_LESSONS, lessons), (learn.LEGACY_CASES, cases)):
        path = tmp_path / relative
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(yaml.safe_dump(value), encoding='utf-8')
    governed = tmp_path / 'experiments/agent/candidates/governed_entry_L000.json'
    governed.parent.mkdir(parents=True)
    governed.write_text(json.dumps({'from_lesson': 'L000', 'destination': 'Naming review', 'proposal': {'note': 'Original proposal only'}}))
    return tmp_path


def checked(root, row, monkeypatch, code=0):
    with monkeypatch.context() as patch:
        patch.setattr(learn.subprocess, 'run', lambda *_a, **_kw: SimpleNamespace(returncode=code))
        return learn.check_correction(root, row['id'], row['digest'], row['tests'])


def activate(root, row, monkeypatch):
    row = checked(root, row, monkeypatch)
    return learn.activate_correction(root, row['id'], row['digest'], 'Reviewer')


def mappings():
    return {'skill_by_id': {'L000': 'draft-contract-record', 'L001': 'answer-decisions'},
        'scope_by_id': {'L000': {'kind': 'packs', 'packs': [PACK]}, 'L001': {'kind': 'global'}}}


def test_compatibility_capture_only_proposes_and_preserves_governed_destination(checkout):
    before = {path: path.read_bytes() for path in checkout.rglob('*') if path.is_file()}
    result = learn.record_lesson('An option was lost.', 'Retain the selected option.', 'Question follow-ups.', 'Local author',
        governed='Decision review', skill='answer-decisions', root=checkout)
    assert result['status'] == 'proposed'
    record = learn.read_correction(checkout, result['lesson'])
    assert record['provenance']['governed_destination'] == 'Decision review'
    assert record['provenance']['entrypoint'] == 'record_lesson'
    assert all(path.read_bytes() == raw for path, raw in before.items())
    assert not learn.active_corrections(checkout) and not learn.correction_cases(checkout)
    assert 'Retain the selected option' not in learn.lessons_text(root=checkout)
    assert learn.record_lesson('An option was lost.', 'Retain the selected option.', 'Question follow-ups.', 'Local author',
        governed='Decision review', skill='answer-decisions', root=checkout)['lesson'] == record['id']


def test_real_cli_uses_the_same_proposed_record_without_an_api_key(checkout, monkeypatch):
    monkeypatch.delenv('ANTHROPIC_API_KEY', raising=False)
    before = (checkout / learn.LEGACY_LESSONS).read_bytes()
    result = subprocess.run([sys.executable, str(ROOT / 'experiments/agent/learn.py'), '--root', str(checkout),
        '--wrong', 'The option was lost.', '--right', 'Retain the selected option.', '--context', 'Question follow-up.',
        '--by', 'Local author', '--skill', 'answer-decisions'], capture_output=True, text=True, timeout=30)
    assert result.returncode == 0, result.stderr
    returned = json.loads(result.stdout)
    assert returned['status'] == 'proposed' and returned['correction']['skill'] == 'answer-decisions'
    assert (checkout / learn.LEGACY_LESSONS).read_bytes() == before
    assert not learn.active_corrections(checkout)


def test_import_preserves_provenance_and_retries_never_reactivate_or_append_old_stores(checkout, monkeypatch):
    before = {path: path.read_bytes() for path in checkout.rglob('*') if path.is_file()}
    preview = learn.preview_legacy(checkout, **mappings())
    assert [row['source_by'] for row in preview['rows']] == ['Original reviewer', 'Original author']
    imported = learn.import_legacy(checkout, expected_digest=preview['digest'], by='Migration reviewer', **mappings())
    assert len(imported['created_ids']) == 2 and {row['status'] for row in imported['records']} == {'proposed'}
    first = imported['records'][0]
    assert first['provenance']['legacy_eval_case']['id'] == 'lesson-l000'
    assert first['provenance']['governed_destination'] == 'Naming review'
    assert first['provenance']['source_date'] == '2026-09-01'
    assert first['provenance']['legacy_lesson']['corrected_by'] == 'Original reviewer'
    assert all(path.read_bytes() == raw for path, raw in before.items())
    assert not learn.active_corrections(checkout) and not learn.correction_cases(checkout)
    active = activate(checkout, first, monkeypatch)
    assert not learn.active_corrections(checkout)
    assert [row['id'] for row in learn.active_corrections(checkout, packs=[PACK])] == [active['id']]
    assert not learn.active_corrections(checkout, packs=['products/oncology/other/202609'])
    assert learn.correction_cases(checkout)[0]['scope'] == {'kind': 'packs', 'packs': [PACK]}
    withdrawn = learn.withdraw_correction(checkout, active['id'], active['digest'], 'Reviewer')
    replay = learn.import_legacy(checkout, expected_digest=preview['digest'], by='Another importer', **mappings())
    assert not replay['created_ids'] and replay['records'][0]['status'] == 'withdrawn'
    assert replay['records'][0]['digest'] == withdrawn['digest']
    assert not learn.active_corrections(checkout, include_scoped=True)


def test_unresolved_import_requires_explicit_scope_resolution_before_checks(checkout, monkeypatch):
    preview = learn.preview_legacy(checkout)
    record = learn.import_legacy(checkout, expected_digest=preview['digest'], by='Importer')['records'][0]
    assert record['scope']['kind'] == 'legacy_context'
    with pytest.raises(ValueError, match='Resolve'):
        checked(checkout, record, monkeypatch)
    with pytest.raises(ValueError, match='Resolve'):
        learn.activate_correction(checkout, record['id'], record['digest'], 'Reviewer')
    resolved = learn.resolve_legacy_scope(checkout, record['id'], record['digest'], {'kind': 'packs', 'packs': [PACK]}, 'Scope reviewer')
    assert resolved['status'] == 'proposed' and resolved['provenance']['scope_resolution']['by'] == 'Scope reviewer'
    assert not learn.import_legacy(checkout, expected_digest=preview['digest'], by='Importer')['created_ids']
    with pytest.raises(ValueError, match='changed'):
        learn.resolve_legacy_scope(checkout, record['id'], record['digest'], {'kind': 'global'}, 'Reviewer')


@pytest.mark.parametrize('bad', ['secret', 'duplicate', 'nested'])
def test_invalid_legacy_data_is_refused_before_any_correction_write(checkout, bad):
    path = checkout / learn.LEGACY_LESSONS
    rows = yaml.safe_load(path.read_text())
    if bad == 'secret':
        rows[0]['right'] = 'api_key=synthetic-credential-sentinel'
    elif bad == 'duplicate':
        rows.append(rows[0].copy())
    path.write_text('value: ' + '[' * 700 + '0' + ']' * 700 if bad == 'nested' else yaml.safe_dump(rows))
    with pytest.raises(ValueError):
        learn.preview_legacy(checkout)
    assert not (checkout / learn.CORRECTIONS).exists()


def test_preview_staleness_and_invalid_scope_never_write(checkout):
    preview = learn.preview_legacy(checkout, **mappings())
    path = checkout / learn.LEGACY_LESSONS
    path.write_text(path.read_text() + '\n# revised source\n')
    with pytest.raises(ValueError, match='changed'):
        learn.import_legacy(checkout, expected_digest=preview['digest'], by='Importer', **mappings())
    with pytest.raises(ValueError, match='scope'):
        learn.preview_legacy(checkout, scope_by_id={'L000': {'kind': 'packs', 'packs': ['../outside']}})
    assert not (checkout / learn.CORRECTIONS).exists()


def test_active_recheck_preserves_review_on_pass_and_stops_guidance_on_failure(checkout, monkeypatch):
    row = learn.record_lesson('An option was lost.', 'Retain the selected option.', 'Question follow-up.', 'Author', root=checkout)['correction']
    active = activate(checkout, row, monkeypatch)
    (checkout / row['tests'][0]).write_text('def test_revised_behavior():\n    assert True\n')
    refreshed = checked(checkout, active, monkeypatch)
    assert refreshed['status'] == 'active' and refreshed['review'] == active['review']
    assert refreshed['digest'] != active['digest'] and refreshed['check']['source_digest'] != active['check']['source_digest']
    failed = checked(checkout, refreshed, monkeypatch, code=1)
    assert failed['status'] == 'check_failed' and failed['review'] is None
    assert not learn.active_corrections(checkout)
    repaired = checked(checkout, failed, monkeypatch)
    assert repaired['status'] == 'checked' and not learn.active_corrections(checkout)


@pytest.mark.parametrize('change', ['withdrawal', 'skill'])
def test_embedding_and_text_exports_cannot_resurrect_legacy_withdrawn_or_stale_memory(checkout, monkeypatch, capsys, change):
    spec = importlib.util.spec_from_file_location('learning_test_embed', ROOT / 'experiments/agent/ml/embed.py')
    embed = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(embed)
    monkeypatch.setattr(embed, 'ROOT', str(checkout))
    monkeypatch.setattr(embed, 'SOURCES', [])
    monkeypatch.setattr(embed, 'INDEX', str(checkout / 'cache/index.jsonl'))
    embed.index()
    assert len(Path(embed.INDEX).read_text().splitlines()) == 1
    record = learn.record_lesson('An option was lost.', 'Reusable selected-option guidance.', 'Question follow-up.', 'Author', root=checkout)['correction']
    active = activate(checkout, record, monkeypatch)
    embed.index()
    assert 'Reusable selected-option guidance' in Path(embed.INDEX).read_text()
    assert 'Reusable selected-option guidance' in learn.lessons_text(root=checkout)
    if change == 'withdrawal':
        learn.withdraw_correction(checkout, active['id'], active['digest'], 'Reviewer')
    else:
        path = checkout / '.claude/skills/operate-rwd-product/SKILL.md'
        path.write_bytes(path.read_bytes() + b'\nChanged procedure.\n')
    with pytest.raises(RuntimeError, match='provenance'):
        embed.query('selected option')
    assert 'Reusable selected-option guidance' not in learn.lessons_text(root=checkout)
    embed.index()
    assert len(Path(embed.INDEX).read_text().splitlines()) == 1
    capsys.readouterr()


def test_static_legacy_evals_are_not_reintroduced_without_active_imports(checkout, monkeypatch):
    spec = importlib.util.spec_from_file_location('learning_test_evals', ROOT / 'experiments/agent/evals/run.py')
    runner = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(runner)
    monkeypatch.setattr(runner, 'HERE', str(checkout / 'experiments/agent/evals'))
    assert [row['id'] for row in runner.load_all_cases(include_generated=False, root=checkout)] == ['ordinary-case']
