"""Comparison questions reach explicit register authoring without becoming a ruling."""
from pathlib import Path
import sys

from streamlit.testing.v1 import AppTest

ROOT = Path(__file__).resolve().parents[2]
sys.path[:0] = [str(ROOT / "platform/tests"), str(ROOT / "experiments/portal"), str(ROOT / "platform/tools")]
from test_epi_decision_answer_page import _seed, _bytes, PACK
import contract_lint as cl
import decision_record as dr

QUESTION = "Can the EHR and claims implementations of ECOG be compared for this study?"
RULE = {"variable_id": "ECOG", "spec": {"refs": ["clinical:1"], "rule": "Performance status", "digest": "a" * 64},
        "derivation": "Unresolved pooling question", "status": "{requirement: draft}", "interpreted": [],
        "executable": [], "unresolved": [], "decisions": []}
REPORT = {"ok": True, "errors": [], "warnings": [], "input_digest": "d" * 64, "records": [RULE],
          "source_rows": [{"item_id": "clinical:1", "variable_id": "ECOG", "definition": "Performance status"}],
          "variable": "ECOG", "item_id": "clinical:1", "current": RULE,
          "comparison": {"variables": [{"variable_id": "ECOG", "derivation": "Unresolved pooling question",
              "implementations": {}, "definitions": {}, "equivalence": [{"source_a": "ehr", "source_b": "claims",
                  "state": "not_established", "question": QUESTION}]}], "ruling_problems": []}}


def _healthy(at):
    assert not at.exception, [error.message for error in at.exception]


def _app(root, *, can_answer=True):
    script = f'''
import sys
sys.path[:0] = {[str(ROOT / "experiments/portal"), str(ROOT / "platform/tools")]!r}
from unittest.mock import patch
import streamlit as st
import connected_workflow_page as navigation
import connected_workflow as workflow
import science_workspace as science
actor = st.selectbox("Actor", ["scientist", "another-scientist"], key="test_actor")
page = st.radio("Page", ["Workflow", "Other"], key="test_page")
if st.session_state.get("test_route_actor") != actor:
    st.session_state["test_route_actor"] = actor
    st.session_state[navigation.KEY] = workflow.destination("dataset_comparison", pack={PACK!r}, actor_id=actor,
        origin="Studies", params={{"variable":"ECOG", "study":"Outcomes"}})
if page == "Workflow":
    with patch.object(science, "describe", return_value={REPORT!r}):
        navigation.render_active({str(root)!r}, {PACK!r}, actor, section="Studies", allowed_packs={[PACK]!r},
            local_demo=True, can_write={can_answer!r}, can_review=False, can_view=True, can_answer={can_answer!r})
'''
    at = AppTest.from_string(script, default_timeout=45).run()
    _healthy(at)
    at.button(key="science_dataset_comparison_question_ehr_claims").click().run()
    _healthy(at)
    return at


def test_comparison_draft_reaches_open_question_and_blank_answer_form_only_after_explicit_actions(tmp_path):
    product = _seed(tmp_path)
    register = product / dr.DECISIONS
    original = _bytes(tmp_path)
    original_rows = cl.decision_rows(register.read_text(encoding="utf-8"))
    at = _app(tmp_path)
    params = at.session_state["connected_workflow"]["params"]
    assert params["question"] == QUESTION and params["question_context"] == "ehr / claims"
    assert params["variable"] == "ECOG" and params["study"] == "Outcomes"
    assert params["question_evidence"] == "clinical:1"
    assert at.text_area(key="decision_answer_raise_question").value == ""
    assert at.text_input(key="decision_answer_raise_id").value == ""
    assert at.selectbox(key="decision_answer_raise_owner").value is None
    assert _bytes(tmp_path) == original
    at.text_area(key="decision_answer_Q1_answer").set_value("My separate unfinished answer").run()
    at.button(key="decision_answer_use_question_draft").click().run()
    _healthy(at)
    assert at.text_area(key="decision_answer_raise_question").value == QUESTION
    assert at.text_input(key="decision_answer_raise_evidence").value == "clinical:1"
    assert at.text_input(key="decision_answer_raise_id").value == ""
    assert at.selectbox(key="decision_answer_raise_owner").value is None
    assert _bytes(tmp_path) == original
    edited = "Which differences prevent comparing EHR and claims ECOG in the outcomes study?"
    at.text_area(key="decision_answer_raise_question").set_value(edited)
    at.text_input(key="decision_answer_raise_id").set_value("POOL-ECOG")
    at.selectbox(key="decision_answer_raise_owner").set_value("Science")
    at.button(key="decision_answer_raise").click().run()
    _healthy(at)
    rows = cl.decision_rows(register.read_text(encoding="utf-8"))
    assert {key: value for key, value in rows.items() if key != "POOL-ECOG"} == original_rows
    assert cl.decision_question(rows["POOL-ECOG"]) == edited
    assert cl.decision_status(register.read_text(encoding="utf-8"))["POOL-ECOG"] == "OPEN"
    assert not cl.decision_approver(rows["POOL-ECOG"]) and not cl.decision_approval_date(rows["POOL-ECOG"])
    assert at.text_area(key="decision_answer_Q1_answer").value == "My separate unfinished answer"
    assert not (product / dr.FORMS_DIR / "POOL-ECOG.yaml").exists()
    assert any("Question POOL-ECOG was recorded" in item.value for item in at.info)
    assert any(edited == item.value for item in at.text)
    at.button(key="decision_answer_prepare").click().run()
    _healthy(at)
    assert at.selectbox(key="decision_answer_selected").value == "POOL-ECOG"
    for field in ("answer", "answered_by", "answer_date"):
        widget = at.text_area if field == "answer" else at.text_input
        assert widget(key="decision_answer_POOL-ECOG_" + field).value == ""
    for name, raw in original.items():
        if name != (Path(PACK) / dr.DECISIONS).as_posix():
            assert (tmp_path / name).read_bytes() == raw
    assert not any("APPROVAL" in name or "SIGNATURE" in name for name in _bytes(tmp_path))


def test_new_question_draft_survives_routes_and_is_not_replaced_by_another_comparison(tmp_path):
    _seed(tmp_path)
    before = _bytes(tmp_path)
    at = _app(tmp_path)
    at.text_input(key="decision_answer_raise_id").set_value("MY-QUESTION")
    at.text_area(key="decision_answer_raise_question").set_value("My own unfinished question?")
    at.text_input(key="decision_answer_raise_evidence").set_value("clinical:2")
    at.selectbox(key="decision_answer_raise_owner").set_value("Science").run()
    at.radio(key="test_page").set_value("Other").run()
    at.radio(key="test_page").set_value("Workflow").run()
    _healthy(at)
    assert at.text_area(key="decision_answer_raise_question").value == "My own unfinished question?"
    route = dict(at.session_state["connected_workflow"])
    route["params"] = {**route["params"], "question": "A different comparison question?", "question_context": "claims / registry"}
    at.session_state["connected_workflow"] = route
    at.run()
    _healthy(at)
    assert any(item.value == "A different comparison question?" for item in at.text)
    assert at.text_area(key="decision_answer_raise_question").value == "My own unfinished question?"
    assert at.text_input(key="decision_answer_raise_evidence").value == "clinical:2"
    assert at.text_input(key="decision_answer_raise_id").value == "MY-QUESTION"
    assert _bytes(tmp_path) == before


def test_comparison_draft_respects_readonly_and_actor_context(tmp_path):
    _seed(tmp_path)
    before = _bytes(tmp_path)
    readonly = _app(tmp_path, can_answer=False)
    assert readonly.button(key="decision_answer_use_question_draft").disabled
    assert readonly.button(key="decision_answer_raise").disabled
    at = _app(tmp_path)
    at.button(key="decision_answer_use_question_draft").click().run()
    at.text_area(key="decision_answer_raise_question").set_value("Private wording from the first actor").run()
    at.selectbox(key="test_actor").set_value("another-scientist").run()
    at.button(key="science_dataset_comparison_question_ehr_claims").click().run()
    _healthy(at)
    assert at.text_area(key="decision_answer_raise_question").value == ""
    assert not any("Private wording" in item.value for item in at.text)
    assert _bytes(tmp_path) == before


def test_stale_comparison_question_save_refuses_without_losing_the_draft(tmp_path):
    product = _seed(tmp_path)
    at = _app(tmp_path)
    at.button(key="decision_answer_use_question_draft").click().run()
    at.text_input(key="decision_answer_raise_id").set_value("POOL-ECOG")
    at.selectbox(key="decision_answer_raise_owner").set_value("Science").run()
    register = product / dr.DECISIONS
    register.write_text(register.read_text(encoding="utf-8") + "\nAnother reviewer updated the register.\n", encoding="utf-8")
    before = _bytes(tmp_path)
    at.button(key="decision_answer_raise").click().run()
    _healthy(at)
    assert any("changed while this page was open" in item.value for item in at.error)
    assert at.text_area(key="decision_answer_raise_question").value == QUESTION
    assert _bytes(tmp_path) == before
