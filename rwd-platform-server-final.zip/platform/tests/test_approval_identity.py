"""Approver identity: that a typed name is held to a person, and a signature to a registered key.

Every assertion here is a MUTATION — the refusal is shown firing on a bad value and staying silent
on a good one. A test that only ran the tool on the live repository would pass just as happily if
every check were deleted, because the live repository is clean; that is the shape of test this
framework has had to replace before.

Run: python3 platform/tests/test_approval_identity.py  (or pytest)
"""
import os
import shutil
import sys
import tempfile
from pathlib import Path

REPO = Path(__file__).resolve().parent.parent.parent
TOOLS = REPO / "platform" / "tools"
sys.path.insert(0, str(TOOLS))

import yaml # noqa: E402
import approval_identity as ai # noqa: E402
import product_gates as pg # noqa: E402
import protocol_record as pr # noqa: E402
import request_record as rr # noqa: E402
import source_manifest as sm # noqa: E402

TEAM = "DataExpert" # a bare acronym — what a function looks like
TEAM_PADDED = "the Science team" # a team name padded with more team
PERSON = "Jane Doe" # a name; a made-up one, which no parser can catch and none claims to


def _tmp():
    return tempfile.mkdtemp(prefix="approval_identity_")


# --------------------------------------------------------------------------- the registry itself

def test_empty_registry_does_not_implicitly_register_a_signer():
    """A fresh registry stays empty; another user's checkout may contain registered keys."""
    with tempfile.TemporaryDirectory(prefix="approval_identity_empty_") as root:
        path = Path(root) / ai.REGISTRY
        path.parent.mkdir(parents=True)
        path.write_text(yaml.safe_dump({"version": 1, "signers": [], "known_ineligible": []}), encoding="utf-8")
        before = path.read_bytes()
        doc, errs = ai.registry(root)
        assert not errs, errs
        assert doc.get("signers") == []
        assert ai.person_keys(doc) == {}, "reading an empty registry must not register a signer"
        assert path.read_bytes() == before


def test_the_github_forge_key_is_recorded_as_ineligible_not_merely_absent():
    """The 32 signed commits in this history are forge merges. Recording WHY they do not count is
    the point: an unexplained absence invites somebody to close the gap by registering that key."""
    doc, _ = ai.registry(str(REPO))
    ineligible = {str(k.get("key_id")): k for k in (doc.get("known_ineligible") or [])}
    assert "B5690EEEBB952194" in ineligible, ineligible
    assert ineligible["B5690EEEBB952194"].get("attests") == "forge_merge"
    assert ai.PERSON_REVIEW != "forge_merge"


def test_a_known_ineligible_key_is_refused_however_it_is_labelled():
    """`known_ineligible` must be ENFORCED, not merely documented.

    The first version of this test asserted the opposite as if it were correct: that relabelling
    the forge key `person_review` in `signers:` made it a valid approval key, on the reasoning that
    the rule was "keyed on the attestation, not the key id". That turned the whole
    `known_ineligible` block into prose no code read — a registry that records why a key cannot
    support an approval and then accepts it when somebody types a different word beside it. What a
    key proves does not change when its label does.
    """
    ineligible = [{"key_id": "B5690EEEBB952194", "identity": "GitHub",
                   "attests": "forge_merge", "why": "signs merges the forge performed"}]
    #...as `forge_merge`: refused, and it always was.
    assert ai.person_keys({"signers": [{"key_id": "B5690EEEBB952194", "identity": "GitHub",
                                        "attests": "forge_merge"}],
                           "known_ineligible": ineligible}) == {}
    #...RELABELLED `person_review`: also refused. This is the case that used to pass.
    relabelled = {"signers": [{"key_id": "B5690EEEBB952194", "identity": "X",
                               "attests": ai.PERSON_REVIEW}],
                  "known_ineligible": ineligible}
    assert ai.person_keys(relabelled) == {}, "relabelling an ineligible key must not admit it"
    #...and a key that is genuinely a person's still resolves, so this is not a blanket refusal.
    assert ai.person_keys({"signers": [{"key_id": "AAAA1111", "identity": PERSON,
                                        "attests": ai.PERSON_REVIEW}],
                           "known_ineligible": ineligible}) == {"AAAA1111": PERSON}


def test_check_fails_when_an_ineligible_key_is_placed_in_signers():
    """The registry is refused outright, so the mistake cannot sit there looking registered."""
    d = _tmp()
    try:
        os.makedirs(os.path.join(d, "governance"))
        yaml.safe_dump({"version": 1,
                        "signers": [{"key_id": "B5690EEEBB952194", "identity": "X",
                                     "attests": ai.PERSON_REVIEW,
                                     "registered_date": "2026-01-01", "registered_by": PERSON}],
                        "known_ineligible": [{"key_id": "B5690EEEBB952194",
                                              "attests": "forge_merge", "why": "forge merges"}]},
            open(os.path.join(d, "governance", "allowed_signers.yaml"), "w", encoding="utf-8"))
        doc, _ = ai.registry(d)
        ineligible = ai.ineligible_keys(doc)
        assert "B5690EEEBB952194" in ineligible
        assert ai.person_keys(doc) == {}
    finally:
        shutil.rmtree(d, ignore_errors=True)


def _signed_audit(root, key="KEY1"):
    """`audit` with every approval's commit stood in for by one GOOD signature on `key`.

    The real binding shells out to `git log -G`, which needs a repository and a GPG key to be
    interesting. What is under test here is the comparison the tool makes once it HAS a signature,
    so the signature and its matching commit tree are stubbed. Subject comparisons
    and signer checks still run; real signed tree tests live in test_epi_approval_subject.
    """
    saved = ai.approval_commit
    saved_git = ai._git
    ai.approval_commit = lambda r, rel, pattern: {"sha": "a" * 40, "status": "G",
                                                  "key": key, "signer": "s"}
    def git_with_approved_tree(r, *args):
        # the tool asks `git show <sha>:<path> --` (the trailing marker keeps a deep Windows path from
        # being read as a file name, 2026-09-07); the stub answers both shapes
        if len(args) in (2, 3) and args[0] == "show" and args[1].startswith("a" * 40 + ":") and (len(args) == 2 or args[2] == "--"):
            return Path(r, args[1].split(":", 1)[1]).read_text(encoding="utf-8")
        return saved_git(r, *args)
    ai._git = git_with_approved_tree
    try:
        return ai.audit(root)[0]
    finally:
        ai.approval_commit = saved
        ai._git = saved_git


def test_a_signature_authenticates_only_the_signers_own_typed_name():
    """THE COMPARISON THE FIRST VERSION CLAIMED AND NEVER MADE.

    It checked that the signing key was registered and then called the file authenticated — so a
    signature by ANY registered person authenticated an approval attributed to somebody else. The
    docstring described the identity match; the code never performed it.
    """
    d = _tmp()
    try:
        os.makedirs(os.path.join(d, "governance"))
        yaml.safe_dump({"version": 1, "signers": [
            {"key_id": "KEY1", "identity": PERSON, "attests": ai.PERSON_REVIEW,
             "registered_date": "2026-01-01", "registered_by": PERSON}]},
            open(os.path.join(d, "governance", "allowed_signers.yaml"), "w", encoding="utf-8"))
        os.makedirs(os.path.join(d, "products", "oncology", "x", "202601"))
        path = os.path.join(d, "products", "oncology", "x", "202601", "source_refs.yaml")

        def run(approved_by, signing_key="KEY1"):
            yaml.safe_dump({"source_materials": [
                {"material_id": "m", "approved_by": approved_by, "classified_by": approved_by}]},
                open(path, "w", encoding="utf-8"))
            rows = _signed_audit(d, signing_key)
            return [r for r in rows if r["file"].endswith("source_refs.yaml")][0]

        # A locally registered name/key match verifies the signature, not a person.
        r = run(PERSON)
        assert r["signature_verified"] and not r["authenticated"], r["why"]
        assert "independent" in r["why"].lower(), r["why"]

        # Signed by a REGISTERED person the file does NOT name -> refused. This is the case that
        # used to report as authenticated.
        r = run("Someone Else Entirely")
        assert not r["authenticated"], r
        assert "never somebody else's" in r["why"], r["why"]

        # Signed by a key nobody registered -> refused, as before.
        r = run(PERSON, signing_key="UNKNOWN")
        assert not r["authenticated"] and "does not register" in r["why"], r["why"]
    finally:
        shutil.rmtree(d, ignore_errors=True)


def test_a_supporting_reviewers_signature_does_not_authenticate_the_approval():
    """THE SAME DEFECT ONE FIELD ACROSS, and the walk over every `*_by` was committing it.

    A Gate 2 form records `approved_by` — the accountable approver — and `spec_qc_reviewed_by`, who
    performed the specification QC. Those are different acts by different people. Reading every
    `*_by` as an approver meant the QC reviewer's signature authenticated the approval, which is
    exactly "a signature by one registered person says nothing about a name somebody else typed"
    with the two names one line apart instead of one file apart.
    """
    d = _tmp()
    try:
        os.makedirs(os.path.join(d, "governance"))
        yaml.safe_dump({"version": 1, "signers": [
            {"key_id": "QC", "identity": "Q. Reviewer", "attests": ai.PERSON_REVIEW,
             "registered_date": "2026-01-01", "registered_by": PERSON}]},
            open(os.path.join(d, "governance", "allowed_signers.yaml"), "w", encoding="utf-8"))
        hand = os.path.join(d, "products", "oncology", "x", "202601", "handoff")
        os.makedirs(hand)
        yaml.safe_dump({"approved_by": PERSON, "approval_date": "2026-01-02",
                        "spec_qc_reviewed_by": "Q. Reviewer", "spec_qc_review_date": "2026-01-01"},
                       open(os.path.join(hand, "CONTRACT_APPROVAL.yaml"), "w", encoding="utf-8"))

        rows = _signed_audit(d, "QC")
        gate2 = [r for r in rows if r["file"].endswith("CONTRACT_APPROVAL.yaml")]
        assert len(gate2) == 1, f"the QC reviewer was read as an approver: {gate2}"
        assert gate2[0]["field"] == "approved_by" and gate2[0]["who"] == PERSON
        assert not gate2[0]["authenticated"], gate2[0]
        assert "never somebody else's" in gate2[0]["why"], gate2[0]["why"]

        #...and the QC reviewer is still REPORTED, as an actor who is not the approver. Dropping
        # them would be the opposite error: a reader would think the file names one person.
        others = ai.other_actors(d)
        assert ("products/oncology/x/202601/handoff/CONTRACT_APPROVAL.yaml",
                "spec_qc_reviewed_by", "Q. Reviewer") in others, others
        text = ai.render(rows, ai.registry(d)[0], [], d)
        assert "none of them the approval" in text and "Q. Reviewer" in text
    finally:
        shutil.rmtree(d, ignore_errors=True)


def test_every_surface_names_the_field_that_carries_its_approval():
    """A surface with no declared approving field would fall back to reading every actor as one,
    which is the defect. `()` is the deliberate markdown case and nothing else may be empty."""
    for pattern, what, fields in ai.APPROVAL_GLOBS:
        if pattern.endswith(".md"):
            assert fields == (), f"{pattern}: a markdown register uses APPROVER_COLUMNS"
            continue
        assert fields, f"{pattern} ({what}) declares no approving field"
        for f in fields:
            assert f.endswith("_by"), f"{pattern}: {f!r} is not an actor field"


def test_the_watched_inventory_file_is_the_one_holding_workbook_confirmations():
    """`provenance.basis: workbook_confirmed` — the one surface here asserting a human act — hangs
    off INVENTORY.yaml. The globs watched CITATIONS.yaml, which holds verification ROUTES and no
    `confirmed_by`, so that surface was not being watched at all."""
    watched = {p for p, _w, _f in ai.APPROVAL_GLOBS}
    assert any(p.endswith("variable_inventory/INVENTORY.yaml") for p in watched), watched
    inv = REPO / "governance" / "reference" / "variable_inventory" / "INVENTORY.yaml"
    assert inv.exists(), inv


# ------------------------------------------------------------------- surfaces that hold no file

def test_a_surface_with_no_files_is_reported_rather_than_omitted():
    """An absence reported as a clean result is this repository's recurring defect.

    Most of the governed surfaces hold no file today — no pack has reached Gate 2, 3, 4 or 6, no
    pack has committed a source adapter, and `work/` does not exist. Returning only the matches
    would print a coverage number over surfaces that are not covered but simply absent.

    No count is written here on purpose. The previous version of this docstring said "seven of the
    ten", which was a number in prose with nothing holding it to the thing it counted — it went
    stale the moment an eleventh surface was registered, which is the same defect `finalize.py`
    exists to catch in a pack's own summaries. The assertions below count; the prose does not.
    """
    surfaces = ai.surfaces(str(REPO))
    assert len(surfaces) == len(ai.APPROVAL_GLOBS)
    empty = [p for p, _w, _f, files in surfaces if not files]
    assert empty, "expected at least one empty surface in this repository"
    rows, errs = ai.audit(str(REPO))
    text = ai.render(rows, ai.registry(str(REPO))[0], errs, str(REPO))
    for pattern in empty:
        assert pattern in text, f"empty surface {pattern} is not named in the report"
    assert "NO FILE" in text


def test_the_report_separates_keys_registered_from_approvals_authenticated():
    """Two numbers, because they need two different actions: registering a key takes five minutes,
    and re-signing history is not possible at all. One number would hide which is the blocker."""
    rows, errs = ai.audit(str(REPO))
    text = ai.render(rows, ai.registry(str(REPO))[0], errs, str(REPO))
    assert "registered `person_review` keys" in text
    assert "authenticated:" in text
    assert not [r for r in rows if r["authenticated"]], "no commit here is signed by a person's key"


def test_an_unsigned_commit_is_never_reported_as_authenticated():
    """`%G?` of N/E/B/X/Y/R is not a signature this may rely on. `E` — the state every signed
    commit in this repository is in — means git could not check it, which is not the same as good."""
    rows, _ = ai.audit(str(REPO))
    assert rows, "expected governed approval files on disk"
    for r in rows:
        if r["commit"] and r["commit"]["status"] not in ("G", "U"):
            assert not r["authenticated"], r


# -------------------------------------------------------------- personhood, field by field

def test_refresh_release_sign_off_must_name_people():
    """`engine/refresh.py` requires `sign_off.qc_by` and `released_by` and checks PRESENCE only, so
    `qc_by: DataExpert` released a refresh on a function's authority. The engine may not import
    `not_a_person` (`engine/validate.py` says so outright), so a tool holds the same field."""
    d = _tmp()
    try:
        sub = os.path.join(d, "refreshes", "oncology", "prostate", "202606")
        os.makedirs(sub)
        path = os.path.join(sub, "2026Q1.yaml")

        def write(status, qc_by, released_by):
            yaml.safe_dump({"status": status,
                            "sign_off": {"qc_by": qc_by, "released_by": released_by,
                                         "qc_date": "2026-01-01", "released_date": "2026-01-02"}},
                           open(path, "w", encoding="utf-8"))

        write("released", TEAM, PERSON)
        errs = ai.sign_off_errors(d)
        assert len(errs) == 1 and "sign_off.qc_by" in errs[0], errs

        write("released", PERSON, TEAM_PADDED)
        errs = ai.sign_off_errors(d)
        assert len(errs) == 1 and "sign_off.released_by" in errs[0], errs

        write("released", PERSON, "John Roe")
        assert ai.sign_off_errors(d) == []

        # A manifest still building has an empty sign-off by design; refusing it would refuse the
        # template. Only a manifest CLAIMING `released` is held to the rule.
        write("building", TEAM, TEAM)
        assert ai.sign_off_errors(d) == []
    finally:
        shutil.rmtree(d, ignore_errors=True)


def test_a_waived_qc_finding_must_name_the_person_who_waived_it():
    """A waiver is the one disposition that carries a defect forward UNCORRECTED. `Waived by` said
    "by name" in the requirement text and in nothing that ran."""
    good = {"Waived by": PERSON, "Waiver expires": "2099-01-01",
            "Defect": "d", "Impact": "i", "Disposition": "x"}
    assert pg.waiver_errors("pack", "F-1", good) == []
    for bad in (TEAM, TEAM_PADDED, "**Science**"):
        errs = pg.waiver_errors("pack", "F-1", dict(good, **{"Waived by": bad}))
        assert len(errs) == 1 and "Waived by" in errs[0], (bad, errs)


def test_a_resolved_decision_must_name_a_person_in_the_register_too():
    """`decision_record` held the ANSWER FORM's `answered_by` to `not_a_person` and the register it
    writes into was held to presence alone — so the same decision was attributed to a person
    through one route and to `Science` through the other. Registers bold their cells, so `**Science**`
    is the value that actually appears."""
    d = _tmp()
    try:
        os.makedirs(os.path.join(d, "handoff"))
        hdr = ("| ID | Question | Status | Answered by | Answered date |\n"
               "|---|---|---|---|---|\n")

        def write(who):
            open(os.path.join(d, "handoff", "DECISIONS.md"), "w", encoding="utf-8").write(
                hdr + f"| D-1 | q? | **RESOLVED** | {who} | 2026-01-02 |\n")

        write(PERSON)
        assert pg.unaccountable_resolutions(d, "pack") == []
        for bad in (TEAM, "**Science**", TEAM_PADDED):
            write(bad)
            errs = pg.unaccountable_resolutions(d, "pack")
            assert len(errs) == 1 and "D-1" in errs[0], (bad, errs)

        # An OPEN decision is not held to it — the column is legitimately empty until somebody answers.
        open(os.path.join(d, "handoff", "DECISIONS.md"), "w", encoding="utf-8").write(
            hdr + "| D-1 | q? | **OPEN** |  |  |\n")
        assert pg.unaccountable_resolutions(d, "pack") == []
    finally:
        shutil.rmtree(d, ignore_errors=True)


def test_a_reviewed_derivative_must_name_the_person_who_attested_it():
    """`attested_by` answers "did a human read both documents and confirm the copy is faithful".
    It was required for PRESENCE only, so `attested_by: DataExpert` satisfied an attestation that a
    function cannot make. Keyed on the `_by` suffix, so a field added later is covered when it
    lands rather than when somebody remembers the loop."""
    root = _tmp()
    try:
        pack = os.path.join(root, "pack")
        shutil.copytree(str(REPO / "platform" / "tests" / "fixtures" / "prostate_202607"), pack)
        path = os.path.join(pack, "source_refs.yaml")
        base = yaml.safe_load(open(path, encoding="utf-8"))

        def run(who):
            doc = yaml.safe_load(yaml.safe_dump(base))
            m = [x for x in doc["source_materials"] if x["material_id"] == "spec_tabs"][0]
            m.update({"status": "reviewed", "document_id": "D", "revision": "1",
                      "sha256": "a" * 64, "approval_date": "2026-01-01", "approved_by": PERSON,
                      "attested_by": who, "attestation_date": "2026-01-02",
                      "attested_against_sha256": "a" * 64})
            yaml.safe_dump(doc, open(path, "w", encoding="utf-8"))
            return [e for e in sm.check(root, "pack") if "attested_by" in e]

        for bad in (TEAM, TEAM_PADDED):
            assert len(run(bad)) == 1, bad
        assert run(PERSON) == []
    finally:
        shutil.rmtree(root, ignore_errors=True)


def test_an_answered_request_names_a_person_as_requester_and_analyst():
    """The scaffold's own comment says "a NAMED person, not a team" beside `requested_by`, and
    nothing enforced it — so `analyst: DataExpert` answered "who is accountable for this result" with a
    function. The dates in HUMAN_FIELDS fall through the personhood rule untouched."""
    root = _tmp()
    try:
        os.makedirs(os.path.join(root, "work", "W-1"))
        path = os.path.join(root, "work", "W-1", "REQUEST.yaml")

        def write(requested_by, analyst):
            yaml.safe_dump(
                {"id": "W-1", "title": "t", "question": "q", "status": "answered",
                 "requested_by": requested_by, "requested_date": "2026-01-01",
                 "analyst": analyst, "answered_date": "2026-01-02", "disclosure": "internal",
                 "derivation": {"reference": "r", "method": "m", "build_id": "b",
                                "manifest_sha256": "s"},
                 "result": {"summary": "s", "kind": "descriptive"}, "cites": []},
                open(path, "w", encoding="utf-8"))

        write(PERSON, PERSON)
        assert [e for e in rr.record_errors(root, {"id": "W-1"})
                if "`analyst`" in e or "`requested_by`" in e] == []
        write(PERSON, TEAM)
        assert len([e for e in rr.record_errors(root, {"id": "W-1"}) if "`analyst`" in e]) == 1
        write(TEAM_PADDED, PERSON)
        assert len([e for e in rr.record_errors(root, {"id": "W-1"}) if "`requested_by`" in e]) == 1
    finally:
        shutil.rmtree(root, ignore_errors=True)


def test_a_registered_protocol_and_every_amendment_name_a_person():
    """A prespecification records that somebody committed to an analysis BEFORE seeing the result.
    Attributing that commitment to a team attributes it to nobody, which is the state the freeze
    exists to rule out; the same holds for whoever later amends it."""
    root = _tmp()
    try:
        os.makedirs(os.path.join(root, "work", "P-1"))
        path = os.path.join(root, "work", "P-1", "PROTOCOL.yaml")

        def write(registered_by, amend_by):
            yaml.safe_dump(
                {"id": "P-1", "title": "t", "objective": "o", "status": "registered",
                 "registered_by": registered_by, "registered_date": "2026-01-01",
                 "prespecification_sha256": "x" * 64,
                 "amendments": [{"date": "2026-02-01", "amended_by": amend_by, "what_changed": "w",
                                 "why": "y", "covers_digest": "y" * 64}], "cites": []},
                open(path, "w", encoding="utf-8"))

        write(PERSON, PERSON)
        got = [e for e in pr.record_errors(root, {"id": "P-1"})
               if "`registered_by`" in e or "`amended_by`" in e]
        assert got == [], got
        write(TEAM, PERSON)
        assert len([e for e in pr.record_errors(root, {"id": "P-1"})
                    if "`registered_by`" in e]) == 1
        write(PERSON, TEAM_PADDED)
        assert len([e for e in pr.record_errors(root, {"id": "P-1"}) if "`amended_by`" in e]) == 1
    finally:
        shutil.rmtree(root, ignore_errors=True)


# ------------------------------------------------------------------------- the historical baseline

def _repo(d):
    """A throwaway git repository, so `approval_commit` has real history to read."""
    import subprocess
    for args in (["init", "-q", "."], ["config", "user.email", "t@example.invalid"],
                 ["config", "user.name", "T. Test"], ["config", "commit.gpgsign", "false"]):
        subprocess.run(["git", "-C", d, *args], check=True, capture_output=True)


def _commit(d, message):
    import subprocess
    subprocess.run(["git", "-C", d, "add", "-A"], check=True, capture_output=True)
    subprocess.run(["git", "-C", d, "commit", "-qm", message], check=True, capture_output=True)


def test_an_approval_binds_to_the_commit_that_wrote_IT_not_the_one_that_touched_the_file():
    """THE UNIT IS THE APPROVAL. `git log -1 -- <path>` finds the last commit that touched the file
    for ANY reason, so a later edit anywhere in the document re-dated every approval in it — and a
    signature on that edit would have authenticated approvals written earlier by other people.

    Two classifications in one file, written in two commits, must report two different commits.
    """
    d = _tmp()
    try:
        os.makedirs(os.path.join(d, "governance"))
        yaml.safe_dump({"version": 1, "signers": []},
                       open(os.path.join(d, "governance", "allowed_signers.yaml"), "w",
                            encoding="utf-8"))
        os.makedirs(os.path.join(d, "products", "oncology", "x", "202601"))
        path = os.path.join(d, "products", "oncology", "x", "202601", "source_refs.yaml")
        _repo(d)

        open(path, "w", encoding="utf-8").write(
            "source_materials:\n  - material_id: m1\n    classified_by: A. Person\n")
        _commit(d, "first classification")
        rows = ai.audit(d)[0]
        assert len(rows) == 1
        first = rows[0]["commit"]["sha"]

        with open(path, "a", encoding="utf-8") as fh:
            fh.write("  - material_id: m2\n    classified_by: B. Other\n")
        _commit(d, "second classification")
        rows = {r["who"]: r for r in ai.audit(d)[0]}
        assert set(rows) == {"A. Person", "B. Other"}, rows
        assert rows["A. Person"]["commit"]["sha"] == first, \
            "the earlier approval was re-dated by a later commit to the same file"
        assert rows["B. Other"]["commit"]["sha"] != first
    finally:
        shutil.rmtree(d, ignore_errors=True)


def test_the_baseline_grandfathers_one_approval_in_one_commit_and_nothing_else():
    """A baseline keyed on the FILE would exempt every approval that file ever gains, which is a
    permanent hole shaped like a fix. Keyed on (file, field, who, commit), a new approval in the
    same file is NOT covered — and re-making a covered one takes it back out."""
    d = _tmp()
    try:
        os.makedirs(os.path.join(d, "governance"))
        yaml.safe_dump({"version": 1, "signers": []},
                       open(os.path.join(d, "governance", "allowed_signers.yaml"), "w",
                            encoding="utf-8"))
        os.makedirs(os.path.join(d, "products", "oncology", "x", "202601"))
        path = os.path.join(d, "products", "oncology", "x", "202601", "source_refs.yaml")
        _repo(d)
        open(path, "w", encoding="utf-8").write(
            "source_materials:\n  - material_id: m1\n    classified_by: A. Person\n")
        _commit(d, "first classification")

        rows = ai.audit(d)[0]
        text = ai.baseline_text(rows)
        open(os.path.join(d, "governance", "approval_baseline.yaml"), "w",
             encoding="utf-8", newline="\n").write(text)
        _commit(d, "baseline")

        known, errs = ai.baseline(d)
        assert errs == [] and len(known) == 1, (known, errs)
        assert all(ai._key(r) in known for r in ai.audit(d)[0])

        # A NEW approval in the SAME file is not covered.
        with open(path, "a", encoding="utf-8") as fh:
            fh.write("  - material_id: m2\n    classified_by: B. Other\n")
        _commit(d, "second classification")
        live = [r for r in ai.audit(d)[0] if ai._key(r) not in known]
        assert [r["who"] for r in live] == ["B. Other"], live

        # AN EDIT ELSEWHERE IN THE FILE DOES NOT RE-DATE THE APPROVAL. Adding a sibling field
        # leaves the line asserting the approval untouched, so it still dates from the commit that
        # wrote it — which is the whole reason the bind is per-approval and not per-file.
        open(path, "w", encoding="utf-8").write(
            "source_materials:\n  - material_id: m1\n    classified_by: A. Person\n"
            "    classified_date: 2026-01-01\n"
            "  - material_id: m2\n    classified_by: B. Other\n")
        _commit(d, "add a date to the first material")
        still = {r["who"] for r in ai.audit(d)[0] if ai._key(r) in known}
        assert still == {"A. Person"}, \
            "an unrelated edit re-dated the approval — the bind is back to being per-file"

        #...and RE-WRITING THE APPROVAL ITSELF takes it back out, because its commit changes. The
        # value is unchanged; the LINE asserting it is not, and that is the act being dated.
        open(path, "w", encoding="utf-8").write(
            "source_materials:\n  - material_id: m1\n    classified_by: 'A. Person'\n"
            "    classified_date: 2026-01-01\n"
            "  - material_id: m2\n    classified_by: B. Other\n")
        _commit(d, "re-assert the first classification")
        live = {r["who"] for r in ai.audit(d)[0] if ai._key(r) not in known}
        assert "A. Person" in live, \
            "a re-made approval stayed grandfathered — the baseline is not bound to its commit"
    finally:
        shutil.rmtree(d, ignore_errors=True)


def test_a_shallow_clone_is_refused_rather_than_answered_wrongly():
    """THE FORGERY A `--depth 1` CLONE WOULD MANUFACTURE.

    `git log -G` walks commits. On a one-commit clone git treats that commit as a root, so every
    line in the tree reads as written by HEAD — and every approval binds to HEAD. If HEAD carried a
    registered `person_review` signature, EVERY approval in the repository would report as
    authenticated by that signer: the exact act the tool exists to prove, forged by a clone flag.

    Not hypothetical. CI's Windows job checks out at the default depth 1 and runs this whole suite.
    """
    import subprocess
    d = _tmp()
    try:
        clone = os.path.join(d, "clone")
        r = subprocess.run(["git", "clone", "-q", "--depth", "1", "file://" + str(REPO), clone],
                           capture_output=True, text=True, encoding="utf-8", errors="replace")
        if r.returncode != 0: # no git, or the source has no commits
            raise AssertionError(f"could not make a shallow clone to test against: {r.stderr}")
        assert ai.shallow(clone), "the clone is not shallow — this test has lost its subject"
        assert not ai.shallow(str(REPO)), "the live checkout is shallow; run git fetch --unshallow"

        rows, _errs = ai.audit(clone)
        assert rows, "the shallow clone yields no approvals — this test would be vacuous"
        for r in rows:
            assert r.get("shallow") and r["commit"] is None, r
            assert not r["authenticated"], "a shallow clone authenticated an approval"
        text = ai.render(rows, ai.registry(clone)[0], [], clone)
        assert "SHALLOW" in text and "fetch --unshallow" in text, text[:600]
    finally:
        shutil.rmtree(d, ignore_errors=True)


def test_the_live_baseline_covers_exactly_what_is_unauthenticated_today():
    """It must not drift into an exemption for something that has since changed, and it must not
    fall short and leave `--check` red on history — CI runs `--check` on every push."""
    assert not ai.shallow(str(REPO)), \
        "this checkout has no history, so nothing here can be bound to a commit — see " \
        "test_a_shallow_clone_is_refused_rather_than_answered_wrongly"
    rows, _ = ai.audit(str(REPO))
    known, errs = ai.baseline(str(REPO))
    assert errs == [], errs
    live = [r for r in rows if not r["authenticated"] and ai._key(r) not in known]
    assert live == [], f"unauthenticated approvals no baseline covers: {live}"
    stale = sorted(set(known) - {ai._key(r) for r in rows})
    assert stale == [], f"the baseline exempts approvals that no longer exist: {stale}"
    # It exempts nothing that IS authenticated — an entry for a signed approval would be noise
    # today and cover for a lost signature tomorrow.
    for r in rows:
        assert not (r["authenticated"] and ai._key(r) in known), r


def test_the_baseline_is_printed_and_never_written_by_the_tool():
    """A judge that can write its own exemption list is a check that can green itself: one generate
    step in a workflow and every unauthenticated approval is grandfathered, job still passing."""
    # THE DECLARED FLAGS, not a substring scan: the docstring explains why `--write-baseline` does
    # not exist, and a grep for the word is defeated by the explanation. This codebase has written
    # that same guard before and had it defeated once.
    import ast
    tree = ast.parse((TOOLS / "approval_identity.py").read_text(encoding="utf-8"))
    flags = {a.value for n in ast.walk(tree)
             if isinstance(n, ast.Call) and getattr(n.func, "attr", "") == "add_argument"
             for a in n.args if isinstance(a, ast.Constant) and isinstance(a.value, str)}
    assert "--print-baseline" in flags, flags
    assert "--write-baseline" not in flags, \
        "the judging tool declares a flag that writes its own exemption list"
    wf = (REPO / ".github" / "workflows" / "rwdp-ci.yml").read_text(encoding="utf-8")
    assert "print-baseline" not in wf, \
        "CI generates the baseline — the check would grandfather everything it was about to fail on"


def test_the_tool_writes_nothing_and_signs_nothing():
    """Read-only by construction. A tool that could write here could register a key, and
    registering a key on somebody's behalf is the forgery the whole mechanism exists to prevent."""
    import ast
    tree = ast.parse((TOOLS / "approval_identity.py").read_text(encoding="utf-8"))
    for node in ast.walk(tree):
        if isinstance(node, ast.Call):
            name = getattr(node.func, "id", "") or getattr(node.func, "attr", "")
            # These write, whatever their arguments.
            assert name not in ("safe_dump", "dump", "mkdir", "makedirs", "write_text",
                                "writelines", "remove", "rename", "rmtree"), (
                f"{name}() in a tool whose whole claim is that it writes nothing")
            # `open` is judged by its MODE, not its name: reading a register is how this tool
            # learns who a file names, and refusing every `open` would refuse reading. Refusing
            # only write modes is the check that actually means "writes nothing".
            if name == "open":
                mode = ""
                if len(node.args) > 1 and isinstance(node.args[1], ast.Constant):
                    mode = str(node.args[1].value)
                for kw in node.keywords:
                    if kw.arg == "mode" and isinstance(kw.value, ast.Constant):
                        mode = str(kw.value.value)
                assert not (set(mode) & set("wax+")), f"open(mode={mode!r}) writes"
    #...and every git invocation is a READ. Scanning string constants would flag the word
    # "commit" in a docstring and prove nothing; what matters is the SUBCOMMAND actually passed.
    readonly = {"log", "show", "rev-parse", "cat-file", "verify-commit"}
    calls = [n for n in ast.walk(tree)
             if isinstance(n, ast.Call) and getattr(n.func, "id", "") == "_git"]
    assert calls, "expected at least one git call to check"
    for call in calls:
        sub = call.args[1]
        assert isinstance(sub, ast.Constant) and sub.value in readonly, (
            f"git {getattr(sub, 'value', sub)!r} is not a read-only subcommand")


def test_the_exemption_list_may_shrink_but_never_grow():
    """A JUDGE THAT CAN WRITE ITS OWN EXEMPTION LIST IS A CHECK THAT CAN GREEN ITSELF — this
    file says so in the header it prints, and nothing enforced it. The baseline grandfathers
    approvals that PREDATE the identity mechanism, and the mechanism exists now, so an entry
    appearing afterwards cannot be legitimate on its own terms. Without this, the same pull
    request that wrote an unauthenticated approval could baseline it and `--check` went green.

    NOTHING HERE WRITES TO THE GOVERNED FILE. A first version edited
    governance/approval_baseline.yaml and restored it in a `finally`, which leaves this
    repository's exemption list altered if the run is interrupted or if two run at once — the
    exact hazard the sibling UMLS test was just corrected for. The growth comparison is a pure
    function of two parsed documents, so it is tested as one.
    """
    import approval_identity as ai

    # 1. THE COMMITTED TREE HAS NOT GROWN. Read-only.
    grew, why = ai.baseline_growth()
    if not why:
        assert grew == [], f'the committed baseline has grown against the base branch: {grew}'

    # 2. THE COMPARISON ITSELF, on documents rather than on the repository.
    was = {'baselined': [
        {'file': 'a.yaml', 'field': 'approved_by', 'who': 'A Person', 'commit': 'c0'}]}
    now = {'baselined': [
        {'file': 'a.yaml', 'field': 'approved_by', 'who': 'A Person', 'commit': 'c0'},
        {'file': 'b.yaml', 'field': 'approved_by', 'who': 'Somebody', 'commit': 'c1'}]}
    before, _e1 = ai._baseline_from_doc(was)
    after, _e2 = ai._baseline_from_doc(now)
    added = [k for k in sorted(after) if k not in before]
    assert len(added) == 1 and added[0][0] == 'b.yaml', added
    #...and REMOVING one is not growth: that is an approval re-made under signature
    removed = [k for k in sorted(before) if k not in after]
    assert removed == [], removed
    shrunk = [k for k in sorted(before) if k not in before]
    assert shrunk == []

    # 3. ONE PARSER, so the two sides cannot disagree about the format. A first version read the
    # key `approvals` and built the identity through `_key`, which expects a row from the
    # approval SCAN and reads `commit.sha` — it reported a byte-identical file as having
    # grown by three entries.
    assert ai._baseline_from_doc({'approvals': now['baselined']})[0] == {}, (
        'the parser accepted the wrong top-level key')

    # 4. NOT CHECKED IS NOT A PASS. An unresolvable base makes --check fail rather than report.
    grew2, why2 = ai.baseline_growth(base_ref='no/such/ref')
    assert why2 and grew2 == [], (grew2, why2)

    import subprocess
    env = dict(os.environ, PYTHONIOENCODING='utf-8')
    p = subprocess.run([sys.executable,
                        os.path.join(REPO, 'platform', 'tools', 'approval_identity.py'),
                        '--check', '--base-ref', 'no/such/ref'],
                       cwd=REPO, env=env, capture_output=True, text=True,
                       encoding='utf-8', errors='replace')
    assert p.returncode != 0, 'an unrunnable shrink-only comparison still passed --check'
    assert 'did NOT run' in (p.stdout or '') + (p.stderr or '')


def test_the_amendment_author_is_watched_like_every_other_approver():
    """The final audit's identity gap: amendments changed a frozen plan under a bare `by`
    field the `*_by` walk never matched, so the one act that alters signed content was the
    one act the identity check never read. The field is `amended_by` now, the protocol
    surface names it, and the walker finds it nested under `amendments[]`."""
    import approval_identity as ai
    fields = dict((g, f) for g, _w, f in ai.APPROVAL_GLOBS)["work/*/PROTOCOL.yaml"]
    assert "amended_by" in fields, fields
    # closure alters what a frozen record MEANS (nothing changes after) - watched like the
    # acts that alter its content; and a template release recommends meaning to every
    # future pack, so its reviews are approvals too
    assert "closed_by" in fields, fields
    globs = {g for g, _w, _f in ai.APPROVAL_GLOBS}
    assert "governance/reference/template_releases/*.yaml" in globs, globs
    found = {}
    ai._walk_by_fields({"registered_by": "A. Person",
                        "amendments": [{"amended_by": "B. Person", "date": "2026-08-27"}]},
                       found)
    assert found.get("amended_by") == {"B. Person"}, found


if __name__ == "__main__":
    fns = [v for k, v in sorted(globals().items()) if k.startswith("test_")]
    for fn in fns:
        fn()
        print(f"ok  {fn.__name__}")
    print(f"\n{len(fns)} tests passed")
