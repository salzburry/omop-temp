"""Explicit local ownership, confirmation and fresh evidence before a real fixture signature."""
from pathlib import Path
import sys

from streamlit.testing.v1 import AppTest

ROOT = Path(__file__).resolve().parents[2]
sys.path[:0] = [str(ROOT / "experiments/portal"), str(ROOT / "platform/tools"), str(ROOT / "platform/tests")]
from test_epi_approval_attestation import prepared, PACK, ACTOR, files
import approval_attestation as signing


def app(root, review=True):
    script = f'''import streamlit as st
import approval_attestation_page as page
changed = page.render({str(root)!r}, {PACK!r}, st.session_state.get("actor", {ACTOR!r}),
    local_demo=True, can_review=st.session_state.get("review", {review!r}),
    can_view=st.session_state.get("view", True), allowed_packs=[{PACK!r}])
if changed: st.session_state["changed"] = True
'''
    at = AppTest.from_string(script, default_timeout=40).run()
    assert not at.exception, [e.message for e in at.exception]
    return at


def button(at, label):
    return next(item for item in at.button if item.label == label)


def enter(at, path):
    at.selectbox(key="approval_attestation_key").select("review-key")
    at.text_input(key="approval_attestation_path").set_value(str(path)).run()
    return at


def test_user_selects_owner_and_confirms_actual_signature(prepared):
    root, path, event = prepared
    at = app(root)
    assert at.selectbox(key="approval_attestation_key").value is None
    assert at.text_input(key="approval_attestation_path").value == ""
    enter(at, path)
    assert button(at, "Sign this approval event").disabled
    assert "I am Ada Lovelace" in at.checkbox(key="approval_attestation_confirm").label
    at.checkbox(key="approval_attestation_confirm").check().run()
    button(at, "Sign this approval event").click().run()
    assert not at.exception, [e.message for e in at.exception]
    assert any("signature recorded and verified" in item.value for item in at.success)
    assert any("independent reviewer identity evidence" in item.value.lower() for item in at.info)
    assert at.session_state["changed"]
    assert signing.ledger.verify_attestation(str(root), event["object_uuid"])["authenticated"]
    assert all(path.read_text() not in item.value for item in at.markdown)


def test_changed_approval_revokes_checked_confirmation(prepared):
    root, path, _event = prepared
    at = enter(app(root), path)
    at.checkbox(key="approval_attestation_confirm").check().run()
    form = root / PACK / "handoff/RELEASE_APPROVAL.yaml"
    form.write_bytes(form.read_bytes() + b"\n# current review changed\n")
    before = files(root)
    button(at, "Sign this approval event").click().run()
    assert not at.exception
    assert not at.checkbox(key="approval_attestation_confirm").value
    assert any("evidence changed" in item.value for item in at.warning)
    assert files(root) == before


def test_role_loss_and_actor_change_clear_key_path_and_prevent_signing(prepared):
    root, path, _event = prepared
    at = enter(app(root), path)
    at.session_state["actor"] = "another-session"
    at.session_state["review"] = False
    at.run()
    assert at.text_input(key="approval_attestation_path").value == ""
    assert at.text_input(key="approval_attestation_path").disabled
    assert at.selectbox(key="approval_attestation_key").value is None
    assert button(at, "Sign this approval event").disabled
    assert any("current role can inspect" in item.value for item in at.info)
    at.session_state["view"] = False
    at.run()
    assert not at.text_input and not at.selectbox


def test_missing_key_has_tracked_owner_action_without_approval(prepared):
    root, _path, _event = prepared
    (root / "governance/SIGNING_KEYS.yaml").write_text("keys: []\n", encoding="utf-8")
    before = files(root)
    at = app(root)
    assert any("No active release-signing key" in item.value for item in at.info)
    button(at, "Ask Administrator to register a review key").click().run()
    assert not at.exception
    assert any("Key registration requested" in item.value for item in at.success)
    after = files(root)
    assert all(after[name] == raw for name, raw in before.items())
    assert all(".portal-drafts/handoffs/" in name for name in set(after) - set(before))
