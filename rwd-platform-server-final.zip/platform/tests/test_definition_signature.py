"""A definition's identity is derived from the approved config, and these pin what that means.

WHAT IT REPLACES. `semantic_export --template` mints one `rwdp:Definition` per (tumour, master),
so mCRC's BRAF_V600E, KRAS_G12C, KRAS_MUT, NRAS_MUT and RAS_WILD_TYPE are one identifier and the
slot that separates them — `gene` — is emitted as `slotUnstated`. 251 of 509 inventory variables
have no distinct leaf definition.

THE TWO PROPERTIES WORTH HAVING, and both are asserted below:

  REUSE IS PROVABLE.     Eleven packs configure ECOG over the same window and therefore share one
                         digest. That is cross-pack reuse demonstrated mechanically, with no
                         ruling, no meeting and no clinician.
  DIVERGENCE IS VISIBLE. Cancer stage does NOT share one digest — the packs collapse stage
                         differently, and nothing in this repository said so before.

AN UNFILLABLE SLOT MUST NOT PRODUCE A DIGEST. A digest over a partial signature looks like an
identity, is stable, and lets two genuinely different definitions share it — which is the failure
being replaced, reintroduced in a new spelling. So `signed: False` plus the names of the missing
slots is the correct output, and the tests below check the refusal as carefully as the success.

PHYSICAL BINDINGS ARE EXCLUDED, and that is load-bearing rather than tidy. A vendor delivering
KRAS and NRAS as separate columns computes pan-RAS wild-type; a vendor delivering RAS status
directly reads it. Same meaning, different provenance — and unless both resolve to the SAME
definition digest, the two datasets can never be compared, which is the entire point of the
layer.

NO PYTEST FIXTURES AND NO `parametrize` — CI runs every suite as a script.

Run: python3 tests/test_definition_signature.py (or pytest).
"""
import sys
from pathlib import Path

FRAMEWORK = Path(__file__).resolve().parent.parent
REPO = FRAMEWORK.parent
sys.path.insert(0, str(FRAMEWORK / "tools"))

import definition_signature as ds  # noqa: E402


_CACHE = {}

ENDOMETRIAL = str(REPO / "fixtures/oncology/endometrial/YYYYMM")
PROSTATE = str(REPO / "fixtures/oncology/prostate/202606")


def rows(pack):
    if pack not in _CACHE:
        _CACHE[pack] = ds.signatures(pack)
    return _CACHE[pack]


def signed(pack, master):
    return [r for r in rows(pack) if r.get("signed") and r["master"] == master]


# --- the digest is a property of the content ----------------------------------------------------

def test_the_digest_is_deterministic_and_content_addressed():
    a = ds.digest({"window": [-30, 7]})
    b = ds.digest({"window": [-30, 7]})
    c = ds.digest({"window": [-30, 8]})
    assert a == b and a != c
    assert len(a) == 64


def test_key_order_does_not_change_the_digest():
    """Canonical JSON, or the same definition authored in two orders would be two definitions."""
    assert ds.digest({"a": 1, "b": 2}) == ds.digest({"b": 2, "a": 1})


def test_physical_bindings_are_stripped_at_every_depth():
    """A vendor renaming a column must not mint a new definition — the meaning did not change."""
    node = {"window_days": [0, 30], "source": "biomarkers", "name_column": "x",
            "panel": [{"match": "HER2", "value_column": "y", "groups": [{"code": 1}]}]}
    got = ds.semantic(node)
    assert "source" not in got and "name_column" not in got
    assert "value_column" not in got["panel"][0]
    assert got["panel"][0]["match"] == "HER2"
    assert got["window_days"] == [0, 30]


def test_a_renamed_column_does_not_change_the_digest():
    """The property above, stated as the thing that actually matters."""
    a = {"window_days": [0, 30], "value_column": "biomarkerstatus", "match": "HER2"}
    b = {"window_days": [0, 30], "value_column": "bm_status_v2", "match": "HER2"}
    assert ds.digest(ds.semantic(a)) == ds.digest(ds.semantic(b))


def test_a_changed_window_does_change_the_digest():
    a = {"window_days": [0, 30], "match": "HER2"}
    b = {"window_days": [0, 365], "match": "HER2"}
    assert ds.digest(ds.semantic(a)) != ds.digest(ds.semantic(b))


# --- reuse and divergence, on the live packs ----------------------------------------------------

def test_ecog_is_one_definition_across_every_pack_that_configures_it():
    """PROVEN REUSE. Same window, same digest, no human act required."""
    packs = [str(p.parent) for p in list(REPO.glob("products/*/*/*/variables"))
             + list(REPO.glob("fixtures/*/*/*/variables"))]
    digests = {}
    for pack in packs:
        for r in signed(pack, "ECOG_PS"):
            digests.setdefault(r["digest"], []).append(Path(pack).parent.name)
    assert len(digests) == 1, f"ECOG_PS has {len(digests)} distinct definitions: {digests}"
    assert len(next(iter(digests.values()))) >= 8, "too few packs to call this reuse"


def test_cancer_stage_does_not_collapse_into_one_definition():
    """VISIBLE DIVERGENCE. The packs collapse stage differently; one digest would be a lie."""
    packs = [str(p.parent) for p in list(REPO.glob("products/*/*/*/variables"))
             + list(REPO.glob("fixtures/*/*/*/variables"))]
    digests = {r["digest"] for pack in packs for r in signed(pack, "CANCER_STAGE_GROUP")}
    assert len(digests) > 1, "every pack now shares one stage definition — verify that is real"


def test_the_ecog_signature_is_a_normalised_period_and_nothing_physical():
    got = signed(PROSTATE, "ECOG_PS")
    assert got, "prostate no longer signs ECOG_PS"
    assert got[0]["signature"] == {
        "window": {"straddles_index": {"anchor": "index_date",
                                       "lower_days": -30.0, "upper_days": 7.0}}}


# --- periods: baseline and follow-up are different questions ------------------------------------

def test_the_role_is_derived_from_the_bounds_never_authored():
    """An authored role can disagree with the numbers, and then one of them is a lie."""
    assert ds._role(-14, 0) == "baseline"
    assert ds._role(365, 395) == "followup"
    assert ds._role(-30, 7) == "straddles_index"
    assert ds._role(None, 14) == "unbounded_before"
    assert ds._role(0, None) == "unbounded_after"


def test_baseline_and_followup_are_separate_slots_not_one_window():
    """A study sets them independently — a biomarker read before index, an outcome counted after —
    so collapsing both into one `window` made them impossible to state separately."""
    got, bad = ds.periods({"window_days": [-14, 0]}, {})
    assert not bad and set(got) == {"baseline"}
    got, bad = ds.periods({"window_days": [365, 395]}, {})
    assert not bad and set(got) == {"followup"}


def test_two_families_spelling_the_same_window_differently_agree():
    """The point of normalising. Six months after line end and 182.625 days after line end are the
    same period, and the digest has to say so or it cannot tell you two definitions agree."""
    a, _ = ds.periods({"threshold_months": 6}, {"days_per_month": 30.4375})
    b, _ = ds.periods({"pfi_window_days": 182.625}, {})
    assert a["followup"] == b["followup"], (a, b)


def test_months_convert_with_the_packs_own_days_per_month():
    """Reading it rather than assuming 30.4375 is what stops "six months" silently meaning two
    different spans if a pack ever states a different one."""
    a, _ = ds.periods({"threshold_months": 6}, {"days_per_month": 30.4375})
    b, _ = ds.periods({"threshold_months": 6}, {"days_per_month": 30.0})
    assert a["followup"]["upper_days"] != b["followup"]["upper_days"]


def test_a_bare_number_with_no_declared_direction_is_unreadable():
    """`120` says nothing about which side of the index it falls on. Guessing would be inventing
    the answer; an unreadable key suppresses the digest instead."""
    assert ds.normalise_period("window_days", 120, {}) is None


def test_a_period_key_this_table_does_not_know_suppresses_the_digest():
    got, bad = ds.periods({"some_new_window_days": [0, 30]}, {})
    assert got == {} and bad == []          # not a period key at all — simply not read
    assert ds.normalise_period("some_new_window_days", [0, 30], {}) is None


# --- refusal is as important as success ---------------------------------------------------------

def test_an_unfillable_slot_produces_no_digest():
    """A digest over a partial signature is the failure this replaces, in a new spelling."""
    for r in rows(ENDOMETRIAL) + rows(PROSTATE):
        if r.get("signed"):
            assert not r["slots_unresolved"], r
            assert r.get("digest")
        else:
            assert "digest" not in r, f"{r.get('master')} is unsigned but carries a digest"
            assert str(r.get("why") or "").strip(), r


def test_a_pack_with_no_biomarker_config_signs_no_biomarker_definition():
    """mCRC declares five gene variables and configures no panel. The honest output is a stated
    absence, not an identifier over nothing."""
    mcrc = str(REPO / "fixtures/oncology/mcrc/202606")
    gene = [r for r in rows(mcrc) if r.get("master") == "GENE_VARIANT_STATUS"]
    assert gene and not any(r.get("signed") for r in gene)
    assert any("publishes nothing" in str(r.get("why")) or "no `biomarkers`" in str(r.get("why"))
               for r in gene)


def test_the_biomarker_method_slot_is_reported_as_unpinned():
    """A REAL GAP, kept visible. The panel pins gene, scope, timing and missing policy but not the
    assay method — so HER2-by-IHC and HER2-by-FISH would be one definition. The tool must say so
    rather than sign around it."""
    her2 = [r for r in rows(ENDOMETRIAL) if r.get("leaf") == "her2"]
    assert her2, "endometrial no longer configures a her2 panel entry"
    assert not her2[0]["signed"]
    assert "method" in her2[0]["slots_unresolved"]


# --- config and inventory are compared, in both directions --------------------------------------

def test_a_panel_entry_with_no_inventory_variable_is_reported():
    """Endometrial configures `pdl1`, which its overlay never names. That column is built and
    published against no declared variable, and nothing else in the repo compares the two lists."""
    orphans = [r for r in rows(ENDOMETRIAL) if r.get("leaf") and r.get("master") is None]
    assert orphans, "the config/inventory comparison stopped reporting orphan panel entries"
    assert any(r["leaf"] == "pdl1" for r in orphans)


def test_an_instantiated_family_with_no_panel_entry_is_reported():
    """The other direction: endometrial's overlay promises POLE, P53, MSI and MOLSUBTYPE and the
    panel configures none of them, so the build publishes nothing for those families."""
    unbuilt = [r for r in rows(ENDOMETRIAL)
               if r.get("master") == "GENE_VARIANT_STATUS" and r.get("leaf") is None]
    assert unbuilt and "publishes nothing" in str(unbuilt[0]["why"])


def test_a_panel_entry_resolves_to_exactly_one_family():
    """The first cut produced the cross-product — `er` appeared as a gene variant, a protein
    expression and a genomic signature at once. ER is a protein expression and nothing else."""
    for pack in (ENDOMETRIAL, PROSTATE):
        by_leaf = {}
        for r in rows(pack):
            if r.get("leaf"):
                by_leaf.setdefault(r["leaf"], set()).add(r.get("master"))
        for leaf, masters in by_leaf.items():
            assert len(masters) == 1, f"{pack}: {leaf} resolves to {masters}"


if __name__ == "__main__":
    # CI RUNS EVERY SUITE AS A SCRIPT — see the module docstring. Without this block the file runs
    # no tests and exits 0.
    bad = 0
    for _name, _fn in sorted(globals().items()):
        if _name.startswith("test_") and callable(_fn):
            try:
                _fn()
                print(f"  ok  {_name}")
            except Exception as _e:                  # noqa: BLE001 - report and continue
                bad += 1
                print(f"FAIL  {_name}: {_e}")
    sys.exit(1 if bad else 0)
