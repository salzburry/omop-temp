"""Recognized request deadlines explain the retry without leaking provider text."""
import json
from pathlib import Path
import sys
import threading

import pytest

ROOT = Path(__file__).resolve().parents[2]
sys.path[:0] = [str(ROOT / name) for name in ("platform/tests", "experiments/portal", "platform/tools", "experiments/agent")]
import flow_assistant as guide
import scientific_definition_ai as ai
from test_epi_flow_assistant import _card

SECRET = "ANTHROPIC_API_KEY=synthetic-timeout-body-do-not-display"
GENERIC_NOTE = "The assistant could not answer right now. Check the selected connection. This answer comes from the product's own checks."


@pytest.mark.parametrize("error_type", [ai.vscode.BridgeError, ai.claude_code.ClaudeCodeError])
@pytest.mark.parametrize("code", ["timeout", "provider_error"])
def test_bridge_error_code_controls_safe_note_with_one_call_and_no_timeout_prefill(monkeypatch, error_type, code):
    calls = []
    error = error_type(code)
    error.args = (SECRET,)

    class Model:
        def step(self, *_):
            calls.append(True)
            raise error

    offline = {"answer": "Choose a product name first.", "actions": ["open_new_product"], "source": "checks",
               "prefill": {"scope": "unchanged", "fields": [{"id": "name", "value": "GIST"}]}}
    monkeypatch.setattr(guide, "answer_offline", lambda *_: dict(offline))
    result = guide.answer("Create a GIST product", _card(), model=Model())
    assert len(calls) == 1
    assert {key: result[key] for key in ("answer", "actions", "source")} == {
        key: offline[key] for key in ("answer", "actions", "source")}
    assert SECRET not in json.dumps(result)
    if code == "timeout":
        assert "request timed out" in result["note"] and "entries were kept" in result["note"]
        assert "Ask again explicitly" in result["note"] and "prefill" not in result
    else:
        assert result == {**offline, "note": GENERIC_NOTE}


def test_outer_request_deadline_has_same_safe_retry_note_without_retrying(monkeypatch):
    monkeypatch.setattr(ai, "TIMEOUT_SECONDS", 0.005)
    release = threading.Event()
    calls = []

    class Model:
        def step(self, *_):
            calls.append(True)
            release.wait(timeout=2)
            return SECRET

    try:
        result = guide.answer("What is next?", _card(), model=Model())
    finally:
        release.set()
    assert len(calls) == 1 and result["source"] == "checks"
    assert "request timed out" in result["note"] and "Ask again explicitly" in result["note"]
    assert SECRET not in json.dumps(result)


def test_timeout_word_in_generic_exception_body_does_not_change_error_classification():
    calls = []

    class Model:
        def step(self, *_):
            calls.append(True)
            raise RuntimeError("timeout: " + SECRET)

    result = guide.answer("What is next?", _card(), model=Model())
    assert len(calls) == 1 and result["source"] == "checks" and result["note"] == GENERIC_NOTE
    assert SECRET not in json.dumps(result)
