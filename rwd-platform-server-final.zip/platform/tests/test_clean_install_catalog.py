"""An empty product installation retains its master vocabulary without fixture dependencies.

Run with pytest or directly; temporary files never change the checkout's registries.
"""
import importlib.util
import tempfile
from contextlib import ExitStack, contextmanager
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch

import yaml


HERE = Path(__file__).resolve().parent


def _module(name):
    spec = importlib.util.spec_from_file_location("clean_install_" + name, HERE / (name + ".py"))
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


catalog_checks = _module("test_catalog")
registry_checks = _module("test_registry")


def _write(path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(yaml.safe_dump(data, sort_keys=False), encoding="utf-8")


@contextmanager
def _installation(*, tumors=(), references=("master_disease",), ledger=True):
    with tempfile.TemporaryDirectory(prefix="rwd_empty_catalog_") as tmp, ExitStack() as stack:
        products = Path(tmp) / "products"
        catalog = products / "metadata/catalog.yaml"
        registry = products / "registry.yaml"
        dashboard = products / "_reporting/dashboard/dashboard_vars.yaml"
        variable = {"code": "age", "category": "Demographics", "label": "Age", "applies_to": list(references)}
        if ledger:
            variable["introduced_in"] = {references[0]: "202606"}
        _write(catalog, {"tumor_codes": [t["code"] for t in tumors],
                         "reference_tumor_codes": list(references), "variables": [variable]})
        _write(registry, {"tumors": list(tumors)})
        _write(dashboard, {"panels": [{"id": "demographics", "variables": ["age"]}]})
        for module in (catalog_checks, registry_checks):
            stack.enter_context(patch.object(module, "PRODUCTS", products))
            stack.enter_context(patch.object(module, "REGISTRY", registry))
        stack.enter_context(patch.object(catalog_checks, "CATALOG", catalog))
        stack.enter_context(patch.object(catalog_checks, "DASHBOARD", dashboard))
        yield products, catalog


def _refuses(call, message):
    try:
        call()
    except AssertionError as error:
        assert message in str(error), str(error)
    else:
        raise AssertionError("expected rejection: " + message)


def test_empty_installation_accepts_declared_master_vocabulary_without_fixtures():
    with _installation():
        for name in sorted(vars(catalog_checks)):
            if name.startswith("test_"):
                getattr(catalog_checks, name)()
        registry_checks.test_tumors_with_config_lint_clean()
        registry_checks.test_active_tumors_have_a_config()


def test_ledger_remains_optional_without_example_tags():
    with _installation(ledger=False):
        catalog_checks.test_catalog_ledger_fields_well_formed()


def test_master_reference_cannot_hide_missing_registered_product_in_mirror():
    with _installation(tumors=[{"code": "master_disease"}]) as (_, catalog):
        data = yaml.safe_load(catalog.read_text(encoding="utf-8"))
        data["tumor_codes"] = []
        _write(catalog, data)
        _refuses(catalog_checks.test_applies_to_codes_are_registered, "registry tumors missing")


def test_master_reference_cannot_be_advertised_as_installed_product():
    with _installation() as (_, catalog):
        data = yaml.safe_load(catalog.read_text(encoding="utf-8"))
        data["tumor_codes"] = ["master_disease"]
        _write(catalog, data)
        _refuses(catalog_checks.test_applies_to_codes_are_registered, "not in registry")


def test_undeclared_master_reference_and_ledger_codes_are_refused():
    with _installation() as (_, catalog):
        data = yaml.safe_load(catalog.read_text(encoding="utf-8"))
        data.pop("reference_tumor_codes")
        _write(catalog, data)
        _refuses(catalog_checks.test_applies_to_codes_are_registered, "unknown tumor")
        _refuses(catalog_checks.test_catalog_ledger_fields_well_formed, "unknown tumor code")


def test_master_reference_declaration_must_be_an_explicit_unique_code_list():
    for invalid in ("master_disease", ["master_disease", "master_disease"], [None], [" "]):
        with _installation() as (_, catalog):
            data = yaml.safe_load(catalog.read_text(encoding="utf-8"))
            data["reference_tumor_codes"] = invalid
            _write(catalog, data)
            _refuses(catalog_checks.test_catalog_well_formed, "reference_tumor_codes")


def test_first_active_product_still_requires_its_config():
    tumor = {"code": "first", "slug": "first", "current_spec_version": "202609", "status": "active"}
    with _installation(tumors=[tumor]):
        _refuses(registry_checks.test_active_tumors_have_a_config, "has no config")


def test_first_product_checks_every_emitted_variable_without_five_example_packs():
    from engine import config, validate

    tumor = {"code": "first", "slug": "first", "current_spec_version": "202609", "status": "active"}
    cfg = SimpleNamespace(cohorts=[], pack=lambda name: {})
    with _installation(tumors=[tumor], references=["first"]) as (products, _):
        _write(products / "oncology/first/202609/config/data_product.yaml", {"status": "active"})
        with patch.object(config, "load_config", return_value=cfg), \
             patch.object(validate, "emitted_variables", return_value={"age"}):
            catalog_checks.test_catalog_documents_every_emitted_variable()
        with patch.object(config, "load_config", return_value=cfg), \
             patch.object(validate, "emitted_variables", return_value={"age", "uncatalogued"}):
            _refuses(catalog_checks.test_catalog_documents_every_emitted_variable, "uncatalogued")


def test_first_product_config_lint_failures_are_still_refused():
    from engine import validate

    tumor = {"code": "first", "slug": "first", "current_spec_version": "202609", "status": "active"}
    with _installation(tumors=[tumor]) as (products, _):
        _write(products / "oncology/first/202609/config/data_product.yaml", {"status": "active"})
        with patch.object(registry_checks, "load_config", return_value=SimpleNamespace()), \
             patch.object(registry_checks.product_gates, "pack_modality", return_value=("ehr", None)), \
             patch.object(validate, "problems", return_value=["invalid source declaration"]):
            _refuses(registry_checks.test_tumors_with_config_lint_clean, "invalid source declaration")


if __name__ == "__main__":
    tests = [value for name, value in sorted(globals().items()) if name.startswith("test_")]
    for test in tests:
        test()
        print(f"ok  {test.__name__}")
    print(f"\n{len(tests)} tests passed")
