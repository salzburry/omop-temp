#!/usr/bin/env python3
"""The cohortly export lifts, never invents, and refuses where it cannot lift.

Every test builds its own synthetic workbook in tmp - no real study workbook is read, and
the tool's contract is with the TEMPLATE SHAPE, not with one study's content.
Probe wave 14's findings each pinned a test here: the conjunction is lifted not defaulted, months
convert only through the workbook's own factor row, every gap feeds the stop() guard, headers
and duplicates refuse, and workbook text cannot break out of an R comment.

Run: python3 platform/tests/test_cohortly_export.py (or pytest).
"""
import os
import sys
import tempfile
from pathlib import Path

FRAMEWORK = Path(__file__).resolve().parent.parent
REPO = FRAMEWORK.parent
sys.path.insert(0, str(FRAMEWORK / "tools"))

import cohortly_export as ce # noqa: E402

HEAD = ("Section", "Variable Name", "Label", "Definition", "Notes", "Implementation")


def _workbook(tmp, todo_tab=True, crit1_def=None, conversion_row=True, studypd_def=None,
              include_prose=True, conv_def=None, crit3_def=None):
    """The house template in miniature: a spine a machine can lift, one row it cannot."""
    from openpyxl import Workbook
    wb = Workbook()
    dp = wb.active
    dp.title = "datapreppage"
    dp.append(HEAD)
    dp.append(("1.1", "STUDYPD", "Study period",
               studypd_def or "01July2015 - 30June2025 (inclusive)", "", ""))
    dp.append(("1.2", "ID_PD", "Identification period",
               "01Jan2016 - 30June2025 (inclusive)", "", ""))
    if conversion_row:
        dp.append(("1.3", "Days to months conversion", "Conversion factor",
                   conv_def or "30.4375 days per month", "", ""))
    sp = wb.create_sheet("studypoppage")
    sp.append(HEAD)
    sp.append(("2.1", "Criterion 1 (INCLUSION)", "Index event",
               crit1_def or "At least one inpatient claim OR at least two outpatient claims",
               "", ""))
    sp.append(("2.2", "Criterion 2 (INCLUSION)", "Age",
               "Patients aged >=18 years at index", "", ""))
    sp.append(("2.3", "Criterion 3 (INCLUSION)", "Baseline CE",
               crit3_def or "six months of Continuous Enrollment before index",
               "", "spans joined across gaps in enrollment of <=30 days"))
    if include_prose:
        sp.append(("2.4", "Criterion 4 (EXCLUSION)", "Prior diagnosis",
                   "Clinical history of the condition documented in the chart", "", ""))
    if todo_tab:
        codes = wb.create_sheet("dx_codes")
        codes.append(("TO BE BUILT",))
    path = os.path.join(tmp, "synthetic_spec.xlsx")
    wb.save(path)
    return path


def test_the_stated_spine_is_lifted_verbatim_with_provenance():
    """Dates, the gap allowance and the liftable criteria arrive exactly as the workbook
    states them, each carrying the row that states it - a value with no provenance is a
    value someone typed. The OR between IP and OP counts is the workbook's own word."""
    with tempfile.TemporaryDirectory() as tmp:
        wb = _workbook(tmp)
        spine, tabs, digest = ce.read_workbook(wb)
        ex = ce.extract(spine)
        assert ex["study"][:2] == ("2015-07-01", "2025-06-30")
        assert ex["study"][2] == "datapreppage:STUDYPD"
        assert ex["index"][:2] == ("2016-01-01", "2025-06-30")
        assert ex["enrl_gap"][0] == 30
        calls = {c["key"].split(":", 1)[1]: c["call"] for c in ex["criteria"]}
        fn, kw = calls["Criterion 1 (INCLUSION)"]
        assert fn == "trace_event_count" and kw["ip_min_count"] == 1 and kw["op_min_count"] == 2
        assert kw["ip_op_condition"] == "or" # lifted from the text, never defaulted
        fn, kw = calls["Criterion 2 (INCLUSION)"]
        assert fn == "trace_age" and kw["min_age"] == 18
        fn, kw = calls["Criterion 3 (INCLUSION)"]
        assert kw["window"] == [-183, -1] # six months x the workbook's OWN 30.4375
        script = ce.render(wb, tabs, ex, digest)
        assert "study_period_start_dt = '2015-07-01'" in script
        assert "# datapreppage:STUDYPD" in script
        assert digest[:16] in script
        assert "30.4375" in script # the conversion cites its factor row
        assert "UNGOVERNED" in script
        assert "CLAIMS ONLY" in script # the plug: never readable as an EHR path
        m = ce.manifest(wb, tabs, ex, digest)
        assert m["modality"].startswith("claims")


def test_an_ambiguous_conjunction_is_a_gap_never_a_default():
    """Probe wave 14's sharpest finding: a hardcoded 'or' would change cohort membership on a
    workbook that said AND. AND lifts as 'and'; a comma between the counts lifts nothing."""
    with tempfile.TemporaryDirectory() as tmp:
        wb = _workbook(tmp, crit1_def="At least 1 inpatient claim AND at least 2 outpatient claims")
        spine, tabs, digest = ce.read_workbook(wb)
        c1 = [c for c in ce.extract(spine)["criteria"] if "Criterion 1" in c["key"]][0]
        assert c1["call"][1]["ip_op_condition"] == "and"
    with tempfile.TemporaryDirectory() as tmp:
        wb = _workbook(tmp, crit1_def="At least 1 inpatient claim, at least 2 outpatient claims")
        spine, tabs, digest = ce.read_workbook(wb)
        c1 = [c for c in ce.extract(spine)["criteria"] if "Criterion 1" in c["key"]][0]
        assert c1["call"] is None and "conjunction" in c1["gap"]


def test_months_convert_only_through_the_workbooks_own_factor_row():
    """Month-to-day is a methodology ruling. With the conversion row absent, the CE criterion
    must become a gap - a generator that chose 30.4375 itself would be answering Science's
    question for them."""
    with tempfile.TemporaryDirectory() as tmp:
        wb = _workbook(tmp, conversion_row=False)
        spine, tabs, digest = ce.read_workbook(wb)
        c3 = [c for c in ce.extract(spine)["criteria"] if "Criterion 3" in c["key"]][0]
        assert c3["call"] is None
        assert "conversion" in c3["gap"] and "methodology" in c3["gap"]


def test_every_gap_feeds_the_stop_guard():
    """Probe wave 14: a comment is not a refusal. An untranslated criterion, the unlifted code
    lists and a TO-BE-BUILT tab must each be COUNTED in the stop() - a draft that reaches
    finalize_cohort() with a silently-omitted exclusion criterion selects the wrong people."""
    with tempfile.TemporaryDirectory() as tmp:
        wb = _workbook(tmp)
        spine, tabs, digest = ce.read_workbook(wb)
        ex = ce.extract(spine)
        guards = ce._guards(tabs, ex)
        assert any("Criterion 4" in g for g in guards), "the prose criterion is not blocking"
        assert any("EVENTS" in g for g in guards), "unlifted code lists are not blocking"
        assert any("dx_codes" in g for g in guards), "the TO-BE-BUILT tab is not blocking"
        script = ce.render(wb, tabs, ex, digest)
        assert f"stop('{len(guards)} GAP(S)" in script
        assert "BLOCKING, counted in the stop above" in script
        m = ce.manifest(wb, tabs, ex, digest)
        assert m["blocking_gaps"] == guards # one extraction, two renderings


def test_workbook_text_cannot_escape_an_r_comment():
    """A definition cell carrying a newline plus R syntax must stay a comment. Without the
    flatten, the second line would be EXECUTABLE code in the generated script."""
    evil = "Legitimate words\nstop('injected') ; system('evil')\nmore words"
    with tempfile.TemporaryDirectory() as tmp:
        wb = _workbook(tmp, crit1_def=evil)
        spine, tabs, digest = ce.read_workbook(wb)
        script = ce.render(wb, tabs, ce.extract(spine), digest)
        for line in script.splitlines():
            if "injected" in line:
                assert line.lstrip().startswith("#"), f"workbook text became code: {line!r}"


def test_a_reordered_header_and_a_duplicate_row_both_refuse():
    """Positions carry meaning: a template with swapped columns would be confidently misread,
    and a duplicated variable name means a dict silently kept one of two specification rows.
    Decorated headers - the real workbook's own shape - still read, by per-position tokens."""
    from openpyxl import Workbook
    with tempfile.TemporaryDirectory() as tmp:
        wb = Workbook()
        dp = wb.active
        dp.title = "datapreppage"
        dp.append(("Section", "Variable Name", "Label", "Definition (validated from protocol)",
                   "Additional Notes (validated from protocol)", "Optum CDM Implementation"))
        dp.append(("1.1", "STUDYPD", "", "01July2015 - 30June2025", "", ""))
        sp = wb.create_sheet("studypoppage")
        sp.append(HEAD)
        path = os.path.join(tmp, "decorated.xlsx")
        wb.save(path)
        spine, _tabs, _d = ce.read_workbook(path) # the real template's decorations read
        assert "STUDYPD" in spine["datapreppage"]
    with tempfile.TemporaryDirectory() as tmp:
        wb = Workbook()
        dp = wb.active
        dp.title = "datapreppage"
        dp.append(("Variable Name", "Section", "Label", "Definition", "Notes", "Implementation"))
        path = os.path.join(tmp, "reordered.xlsx")
        wb.save(path)
        try:
            ce.read_workbook(path)
        except SystemExit as e:
            assert "header row" in str(e)
        else:
            raise AssertionError("a reordered header was confidently misread")
    with tempfile.TemporaryDirectory() as tmp:
        wb = Workbook()
        dp = wb.active
        dp.title = "datapreppage"
        dp.append(HEAD)
        dp.append(("1.1", "STUDYPD", "", "01July2015 - 30June2025", "", ""))
        dp.append(("1.2", "STUDYPD", "", "01Jan2016 - 30June2025", "", ""))
        path = os.path.join(tmp, "duplicated.xlsx")
        wb.save(path)
        try:
            ce.read_workbook(path)
        except SystemExit as e:
            assert "twice" in str(e)
        else:
            raise AssertionError("a duplicate variable name was silently overwritten")


def test_bad_dates_become_gaps_not_confident_periods():
    """Three dates in the cell, or end before start - either way the period is a gap naming
    the row, never the first two dates the regex happened to meet."""
    with tempfile.TemporaryDirectory() as tmp:
        wb = _workbook(tmp, studypd_def="01July2015 - 30June2025, revised 01Jan2016")
        spine, tabs, digest = ce.read_workbook(wb)
        ex = ce.extract(spine)
        assert "study" not in ex
        assert any("3 valid date(s)" in g for g in ex["gaps"])
    with tempfile.TemporaryDirectory() as tmp:
        wb = _workbook(tmp, studypd_def="30June2025 - 01July2015")
        spine, tabs, digest = ce.read_workbook(wb)
        ex = ce.extract(spine)
        assert "study" not in ex
        assert any("not chronological" in g for g in ex["gaps"])


def test_the_manifest_round_trips_the_same_extraction():
    """The YAML manifest is one of two renderings of one extraction - same values, same
    provenance, same gaps as the R script - and its reader is this repository's own
    cohortly_manifest.R. Exclusion semantics ride in the extraction itself, so both
    renderings carry expectation='absence' or neither does."""
    import yaml
    with tempfile.TemporaryDirectory() as tmp:
        wb = _workbook(tmp, crit1_def="At least 1 inpatient claim OR at least 2 outpatient "
                                      "claims")
        spine, tabs, digest = ce.read_workbook(wb)
        ex = ce.extract(spine)
        m = ce.manifest(wb, tabs, ex, digest)
        assert m["study_specs"]["study_period_start_dt"] == "2015-07-01"
        assert m["study_specs"]["max_enrl_gap"] == 30
        assert len(m["workbook_sha256"]) == 64
        lifted = [c for c in m["criteria"] if c["call"]]
        assert len(lifted) == 3
        assert yaml.safe_load(yaml.safe_dump(m, sort_keys=False)) == m


def test_the_manifest_loader_is_this_repositorys_own_and_refuses_gaps_first():
    """The bridge is complete IN THIS REPOSITORY: cohortly_manifest.R reads the manifest and
    hands cohortly its study_specs() call. Structural pins (no Rscript on this machine, said
    plainly): the blocking_gaps refusal comes BEFORE do.call - a loader that called first and
    checked second would run a cohort missing criteria - db/data_refresh are caller
    arguments, and the _provenance keys are stripped, never passed as arguments."""
    loader = (FRAMEWORK / "engine-r" / "cohortly_manifest.R").read_text(encoding="utf-8")
    assert "cohortly_specs_from_manifest <- function(path, db, data_refresh" in loader
    body = loader[loader.index(".read_manifest <- function"):]
    gap_refusal = body.index("blocking_gaps")
    call = body.index("do.call(cohortly::study_specs")
    assert gap_refusal < call, "the loader calls cohortly before refusing the gaps"
    assert 'startsWith(names(args), "_")' in loader, "provenance keys would become arguments"
    # probe wave 15: the executor consumes the WHOLE definition, not just study_specs - version
    # gate, modality gate, unknown-key refusal, whitelisted criterion calls in workbook
    # order, finalization, and the attrition evidence returned
    assert "cohortly_cohort_from_manifest <- function" in loader
    assert "manifest_version" in loader and "modality" in loader
    assert "setdiff(names(m), .KNOWN_KEYS)" in loader, "unknown manifest keys pass silently"
    assert ".CALL_WHITELIST" in loader and "trace_event_count" in loader
    assert "finalize_cohort" in loader and "pull_attrition" in loader
    assert 'c("window", "op_gap_window")' in loader, "window pairs are not translated to ranges"
    # probe wave: UNGOVERNED refuses by default (explicit allow_ungoverned for defensible draft
    # UAT only), zero criteria refuse (everybody is not a cohort), an index-less set refuses,
    # and the executor reads the manifest exactly ONCE (a double read permitted mixed state)
    assert "allow_ungoverned = FALSE" in loader
    assert "ZERO criteria" in loader and "n_index" in loader
    # probe wave: DEFAULT-DENY governance - only a governed approval form passes without the
    # explicit override; a missing, whitespace-shifted or reworded field refuses
    assert 'startsWith(toupper(gov), "GOVERNED")' in loader
    assert "trimws" in loader
    # probe waves 16/19 sweep: per-call arguments are validated (closed purpose/expectation
    # vocabularies, real counts, ordered windows) and an empty bound code list refuses
    assert 'c("index", "select")' in loader
    assert 'c("presence", "absence")' in loader
    assert "EMPTY code list" in loader
    assert "ordered integer [from, to]" in loader
    cohort_body = loader[loader.index("cohortly_cohort_from_manifest <- function"):]
    assert cohort_body.count(".read_manifest(") == 1, "the executor reads more than once"
    assert "cohortly_specs_from_manifest(" not in cohort_body, \
        "the executor re-enters the public loader - that is a second read"
    # and the manifest names its reader, so the two halves cannot drift apart anonymously
    with tempfile.TemporaryDirectory() as tmp:
        wb = _workbook(tmp)
        spine, tabs, digest = ce.read_workbook(wb)
        m = ce.manifest(wb, tabs, ce.extract(spine), digest)
        assert "cohortly_manifest.R" in m["loader"]


def test_out_inside_the_checkout_is_refused():
    """The generated script and manifest are another repository's material; a committed copy
    is free to go stale. realpath on both sides, so a junction cannot alias around it."""
    with tempfile.TemporaryDirectory() as tmp:
        wb = _workbook(tmp)
        for flags in (["--out", str(REPO / "draft.R")],
                      ["--manifest", str(REPO / "platform" / "draft.yaml")]):
            try:
                ce.main([wb] + flags)
            except SystemExit as e:
                assert "inside the checkout" in str(e), e
            else:
                raise AssertionError(f"{flags[0]} inside the checkout was accepted")
        assert not (REPO / "draft.R").exists()


def test_a_compound_criterion_blocks_whole_never_half_lifts():
    """Probe wave 15's sharpest bridge finding: an if/elif chain lifted the FIRST recognisable
    clause of a compound row and cleared the gap - the rest silently vanished from the
    cohort. A row matching more than one clause family now blocks whole; window alternatives
    ('within 30/60/90 days') block as a protocol ruling; a single stated window lifts."""
    with tempfile.TemporaryDirectory() as tmp:
        wb = _workbook(tmp, crit1_def="Patients at least 18 years of age with six months "
                                      "of Continuous Enrollment before index")
        spine, _t, _d = ce.read_workbook(wb)
        c1 = [c for c in ce.extract(spine)["criteria"] if "Criterion 1" in c["key"]][0]
        assert c1["call"] is None and "compound" in c1["gap"]
    with tempfile.TemporaryDirectory() as tmp:
        wb = _workbook(tmp, crit1_def="At least 1 inpatient claim OR at least 2 outpatient "
                                      "claims on separate days within 30/60/90 days")
        spine, _t, _d = ce.read_workbook(wb)
        c1 = [c for c in ce.extract(spine)["criteria"] if "Criterion 1" in c["key"]][0]
        assert c1["call"] is None and "alternatives" in c1["gap"]
    with tempfile.TemporaryDirectory() as tmp:
        wb = _workbook(tmp, crit1_def="At least 1 inpatient claim OR at least 2 outpatient "
                                      "claims on separate days within 90 days")
        spine, _t, _d = ce.read_workbook(wb)
        c1 = [c for c in ce.extract(spine)["criteria"] if "Criterion 1" in c["key"]][0]
        assert c1["call"][1]["op_gap_window"] == [1, 90]


def test_the_conversion_grammar_reads_units_not_first_numbers():
    """Probe wave 15: '1 month converts to 30.4375 days' must yield 30.4375, never the first
    number in the row - the days-side number divided by the months-side number - and a row
    with two day-numbers is ambiguity, refused as the CE criterion's gap."""
    with tempfile.TemporaryDirectory() as tmp:
        wb = _workbook(tmp, conv_def="1 month converts to 30.4375 days")
        spine, _t, _d = ce.read_workbook(wb)
        c3 = [c for c in ce.extract(spine)["criteria"] if "Criterion 3" in c["key"]][0]
        assert c3["call"][1]["window"] == [-183, -1], c3
    with tempfile.TemporaryDirectory() as tmp:
        wb = _workbook(tmp, conv_def="12 months = 365 days in most years, 366 days in leap years")
        spine, _t, _d = ce.read_workbook(wb)
        c3 = [c for c in ce.extract(spine)["criteria"] if "Criterion 3" in c["key"]][0]
        assert c3["call"] is None and "ambiguous" in c3["gap"]


def test_code_list_defects_refuse_or_block():
    """A duplicate code is an editing error every reader would deduplicate differently -
    refused. A list with no code-system column blocks: which vocabulary the codes belong to
    is a fact, not a guess."""
    from openpyxl import load_workbook
    with tempfile.TemporaryDirectory() as tmp:
        path = _workbook(tmp, todo_tab=False)
        wb = load_workbook(path)
        lst = wb.create_sheet("dx")
        lst.append(("Code", "Type"))
        lst.append(("C90.00", "ICD-10-CM"))
        lst.append(("C90.00", "ICD-10-CM"))
        wb.save(path)
        try:
            ce.read_workbook(path)
        except SystemExit as e:
            assert "twice" in str(e), e
        else:
            raise AssertionError("a duplicate code was silently deduplicated")
    with tempfile.TemporaryDirectory() as tmp:
        path = _workbook(tmp, todo_tab=False)
        wb = load_workbook(path)
        lst = wb.create_sheet("dx")
        lst.append(("Code", "Description"))
        lst.append(("C90.00", "MM"))
        wb.save(path)
        spine, tabs, _d = ce.read_workbook(path)
        guards = ce._guards(tabs, ce.extract(spine))
        assert any("no code-system column" in g for g in guards), guards


def test_the_bindings_file_is_the_governed_path_to_a_gap_free_manifest():
    """Probe wave 15: the EVENTS gap had no governed resolution - hand-deleting it bypassed
    governance and still executed nothing. The bindings file (a reviewed YAML a person
    commits) ties lists to events, calls to events, and names the tabs reviewed as carrying
    no cohort rules - and with everything bound, the draft has NO stop and the manifest has
    NO blocking gaps, while an unbound event call becomes a gap, never an event-less count."""
    import yaml as _yaml
    from openpyxl import load_workbook
    with tempfile.TemporaryDirectory() as tmp:
        path = _workbook(tmp, todo_tab=False, include_prose=False)
        wb = load_workbook(path)
        lst = wb.create_sheet("mm_dx")
        lst.append(("Code", "Code Type", "Description"))
        lst.append(("C90.00", "ICD-10-CM", "Multiple myeloma"))
        gl = wb.create_sheet("glossary")
        gl.append(("Term", "Meaning"))
        gl.append(("CE", "continuous enrollment"))
        wb.save(path)
        spine, tabs, digest = ce.read_workbook(path)
        ex = ce.extract(spine)
        bpath = os.path.join(tmp, "bindings.yaml")
        with open(bpath, "w", encoding="utf-8") as fh:
            _yaml.safe_dump({"events": {"mm": {"dx_cd": "mm_dx"}},
                             "criteria": {"Criterion 1 (INCLUSION)": "mm"},
                             "ignore_tabs": ["glossary"]}, fh)
        b = ce.load_bindings(bpath, tabs, ex)
        ce.apply_bindings(ex, b)
        guards = ce._guards(tabs, ex, b)
        assert guards == [], guards
        script = ce.render(path, tabs, ex, digest, b)
        assert "mm = list(dx_cd = mm_dx)" in script
        assert "event = 'mm'" in script
        # gap-free is NOT governance-free: the draft still carries an UNGOVERNED
        # stop a PERSON deletes after review - no GAP stop, but never zero stops
        assert "GAP(S) ABOVE" not in script and "No blocking gaps" in script
        assert "UNGOVERNED DRAFT" in script and "stop(" in script
        m = ce.manifest(path, tabs, ex, digest, b)
        assert m["manifest_version"] == 1 and m["blocking_gaps"] == []
        assert m["events"]["mm"]["dx_cd"]["codes"] == ["C90.00"]
        assert m["bindings_sha256"] == b["sha256"]
        # an event call the bindings do not name becomes a GAP, never an event-less count
        ex2 = ce.extract(spine)
        ce.apply_bindings(ex2, dict(b, criteria={}))
        c1 = [c for c in ex2["criteria"] if "Criterion 1" in c["key"]][0]
        assert c1["call"] is None and "event" in c1["gap"]
        # and a bindings defect refuses outright - a reviewed file with a typo is a defect
        for bad in ({"events": {"mm": {"dx_cd": "no_such_tab"}}},
                    {"typo_key": []},
                    {"events": {"mm": {"dx_cd": "mm_dx"}}, "ignore_tabs": ["no_such"]}):
            with open(bpath, "w", encoding="utf-8") as fh:
                _yaml.safe_dump(bad, fh)
            try:
                ce.load_bindings(bpath, tabs, ex)
            except SystemExit:
                pass
            else:
                raise AssertionError(f"a defective bindings file was accepted: {bad}")


def test_probe_wave_16_false_green_paths_are_closed():
    """The adversarial findings, each pinned: an unconsumed clause demotes the lift (the
    hospice exclusion cannot vanish), zero criterion rows block, a substantive row that is
    not spelled 'Criterion N (...)' blocks by name, and the unrecognised conversion grammar
    refuses instead of defaulting."""
    from openpyxl import load_workbook
    # 1. residual accounting: 'Age >=18 and no hospice' must NOT lift trace_age cleanly
    with tempfile.TemporaryDirectory() as tmp:
        wb = _workbook(tmp, crit1_def="Patients aged >=18 years and no hospice enrollment "
                                      "during baseline")
        spine, _t, _d = ce.read_workbook(wb)
        c1 = [c for c in ce.extract(spine)["criteria"] if "Criterion 1" in c["key"]][0]
        assert c1["call"] is None and "more than the lifted clause" in c1["gap"], c1
    # 2. zero criterion rows: the guards must block an everybody-cohort
    with tempfile.TemporaryDirectory() as tmp:
        path = _workbook(tmp, todo_tab=False)
        wb = load_workbook(path)
        sp = wb["studypoppage"]
        wb.remove(sp)
        wb.create_sheet("studypoppage").append(HEAD)
        wb.save(path)
        spine, tabs, _d = ce.read_workbook(path)
        guards = ce._guards(tabs, ce.extract(spine))
        assert any("no 'Criterion" in g for g in guards), guards
    # 3. a substantive row not named 'Criterion N (...)' blocks instead of vanishing
    with tempfile.TemporaryDirectory() as tmp:
        path = _workbook(tmp, todo_tab=False)
        wb = load_workbook(path)
        wb["studypoppage"].append(("2.9", "Hospice exclusion rule", "Hospice",
                                   "Exclude patients with any hospice claim in baseline",
                                   "", ""))
        wb.save(path)
        spine, tabs, _d = ce.read_workbook(path)
        ex = ce.extract(spine)
        assert any("Hospice exclusion rule" in g and "silently ignored" in g
                   for g in ex["gaps"]), ex["gaps"]
    # 4. '12-month conversion uses 365 days' must refuse, never read 365 days per month
    with tempfile.TemporaryDirectory() as tmp:
        wb = _workbook(tmp, conv_def="the 12-month conversion uses 365 days")
        spine, _t, _d = ce.read_workbook(wb)
        c3 = [c for c in ce.extract(spine)["criteria"] if "Criterion 3" in c["key"]][0]
        assert c3["call"] is None and "recognised form" in c3["gap"], c3
    # 5. an index-less criteria set blocks even when every criterion lifted
    with tempfile.TemporaryDirectory() as tmp:
        wb = _workbook(tmp, crit1_def="Patients aged >=19 years at index")
        spine, tabs, _d = ce.read_workbook(wb)
        ex = ce.extract(spine)
        guards = ce._guards(tabs, ex)
        assert any("no lifted index criterion" in g for g in guards), guards


def test_probe_wave_18_probes_are_closed():
    """The fourth adversarial round, pinned: window direction is part of the lift (post-index
    and unstated both block - 'before'/'after' can never share a sign), a formula cell
    refuses outright (its cached value can be absent or stale), two index criteria block
    (exactly one row anchors a cohort), and the loader treats a GOVERNED-claiming manifest
    as FORGED until the digest-bound form exists."""
    from openpyxl import load_workbook
    # 1. post-index enrollment blocks; unstated direction blocks; before-index lifts
    for ce_def, want in (("6 months of Continuous Enrollment after index", "POST-index"),
                         ("6 months of Continuous Enrollment", "unstated"),
                         ("6 months of Continuous Enrollment before index", None)):
        with tempfile.TemporaryDirectory() as tmp:
            wb = _workbook(tmp, crit3_def=ce_def)
            spine, _t, _d = ce.read_workbook(wb)
            c3 = [c for c in ce.extract(spine)["criteria"] if "Criterion 3" in c["key"]][0]
            if want:
                assert c3["call"] is None and want in c3["gap"], (ce_def, c3)
            else:
                assert c3["call"][1]["window"] == [-183, -1], c3
    # 2. a second lifted index criterion blocks - exactly one row anchors
    with tempfile.TemporaryDirectory() as tmp:
        path = _workbook(tmp)
        wb = load_workbook(path)
        wb["studypoppage"].append(
            ("2.5", "Criterion 5 (INCLUSION)", "Second index",
             "At least 1 inpatient claim OR at least 2 outpatient claims", "", ""))
        wb.save(path)
        spine, tabs, _d = ce.read_workbook(path)
        guards = ce._guards(tabs, ce.extract(spine))
        assert any("EXACTLY ONE" in g for g in guards), guards
    # 3. a formula cell refuses outright, wherever it hides
    with tempfile.TemporaryDirectory() as tmp:
        path = _workbook(tmp)
        wb = load_workbook(path)
        wb["datapreppage"]["D9"] = "=CONCAT(A1,B1)"
        wb.save(path)
        try:
            ce.read_workbook(path)
        except SystemExit as e:
            assert "FORMULA" in str(e), e
        else:
            raise AssertionError("a formula cell was parsed as a stated value")
    # 4. the loader pins: GOVERNED-claiming is forged; exactly-one index enforced
    loader = (FRAMEWORK / "engine-r" / "cohortly_manifest.R").read_text(encoding="utf-8")
    assert "forged" in loader
    assert "n_index != 1" in loader


def test_probe_wave_19_probes_are_closed():
    """Round five: the staging name is UNPREDICTABLE, a bare
    criterion name on two sheets refuses an unqualified binding, and a temporal qualifier on
    a NON-enrollment row demotes the lift instead of vanishing."""
    import yaml as _yaml
    from openpyxl import load_workbook
    # 1. the auditor's staging collision probe: both outputs must survive
    with tempfile.TemporaryDirectory() as tmp:
        wb = _workbook(tmp)
        man = os.path.join(tmp, "x.yaml")
        out = man + f".tmp{os.getpid()}" # the previously-predictable staging name
        rv = ce.main([wb, "--out", out, "--manifest", man])
        assert rv == 2
        assert os.path.exists(out) and os.path.exists(man), "an output vanished in staging"
        assert open(out, encoding="utf-8").read().startswith("# GENERATED DRAFT")
        assert _yaml.safe_load(open(man, encoding="utf-8"))["manifest_version"] == 1
    # 2. a bare criterion name on both sheets refuses an unqualified binding; the
    # sheet-qualified form resolves exactly
    with tempfile.TemporaryDirectory() as tmp:
        path = _workbook(tmp, todo_tab=False, include_prose=False)
        wbk = load_workbook(path)
        wbk["datapreppage"].append(("1.9", "Criterion 1 (INCLUSION)", "Duplicate name",
                                    "At least 1 inpatient claim OR at least 2 outpatient "
                                    "claims", "", ""))
        dx = wbk.create_sheet("dxl")
        dx.append(("Code", "Code Type"))
        dx.append(("C56.9", "ICD-10-CM"))
        wbk.save(path)
        spine, tabs, _d = ce.read_workbook(path)
        ex = ce.extract(spine)
        bpath = os.path.join(tmp, "b.yaml")
        with open(bpath, "w", encoding="utf-8") as fh:
            _yaml.safe_dump({"events": {"ev": {"dx_cd": "dxl"}},
                             "criteria": {"Criterion 1 (INCLUSION)": "ev"}}, fh)
        try:
            ce.load_bindings(bpath, tabs, ex)
        except SystemExit as e:
            assert "more than one sheet" in str(e), e
        else:
            raise AssertionError("an ambiguous bare binding bound two rows")
        with open(bpath, "w", encoding="utf-8") as fh:
            _yaml.safe_dump({"events": {"ev": {"dx_cd": "dxl"}},
                             "criteria": {"studypoppage:Criterion 1 (INCLUSION)": "ev"}}, fh)
        b = ce.load_bindings(bpath, tabs, ex)
        ce.apply_bindings(ex, b)
        bound = [c for c in ex["criteria"]
                 if c["call"] and c["call"][1].get("event") == "ev"]
        assert len(bound) == 1 and bound[0]["key"].startswith("studypoppage:"), bound
    # 3. a direction word on a non-enrollment row demotes - the call does not represent it
    with tempfile.TemporaryDirectory() as tmp:
        wb = _workbook(tmp, crit1_def="Patients aged >=18 years before index")
        spine, _t, _d = ce.read_workbook(wb)
        c1 = [c for c in ce.extract(spine)["criteria"] if "Criterion 1" in c["key"]][0]
        assert c1["call"] is None and "before" in c1["gap"], c1


def test_probe_wave_17_probes_are_closed():
    """The re-attack's own probes, pinned: the inert-grammar allowlist (not a blocklist)
    demotes 'receiving hospice during baseline'; '01Junk2015' is not June; an invalid date
    beside valid ones is a gap not a silent drop; a nameless row with content refuses; a
    Label-only substantive population row blocks; NOT-NDC is not NDC; and the fixed .tmp
    staging collision is gone."""
    from openpyxl import load_workbook
    import yaml as _yaml
    # 1. allowlist residual: no marker word needed - any unaccounted token demotes
    with tempfile.TemporaryDirectory() as tmp:
        wb = _workbook(tmp, crit1_def="Patients aged >=18 years receiving hospice care "
                                      "during baseline")
        spine, _t, _d = ce.read_workbook(wb)
        c1 = [c for c in ce.extract(spine)["criteria"] if "Criterion 1" in c["key"]][0]
        assert c1["call"] is None and "cannot account for" in c1["gap"], c1
    # 2. month tokens are exact: 'Junk' is not June, and the mismatch is a named gap
    with tempfile.TemporaryDirectory() as tmp:
        wb = _workbook(tmp, studypd_def="01Junk2015 - 30June2025")
        spine, _t, _d = ce.read_workbook(wb)
        ex = ce.extract(spine)
        assert "study" not in ex
        assert any("date-shaped token" in g for g in ex["gaps"]), ex["gaps"]
    # 3. an invalid date BESIDE two valid ones is a gap, never silently dropped
    with tempfile.TemporaryDirectory() as tmp:
        wb = _workbook(tmp, studypd_def="01July2015 - 30June2025 (was 30February2020)")
        spine, _t, _d = ce.read_workbook(wb)
        ex = ce.extract(spine)
        assert "study" not in ex
        assert any("3 date-shaped token(s) but only 2 validate" in g
                   for g in ex["gaps"]), ex["gaps"]
    # 4. a nameless row carrying text refuses - unnamed content cannot be governed
    with tempfile.TemporaryDirectory() as tmp:
        path = _workbook(tmp)
        wb = load_workbook(path)
        wb["studypoppage"].append(("2.9", "", "", "Exclude hospice patients", "", ""))
        wb.save(path)
        try:
            ce.read_workbook(path)
        except SystemExit as e:
            assert "no Variable Name" in str(e), e
        else:
            raise AssertionError("a nameless substantive row was silently discarded")
    # 5. Label/Notes-only content on a non-criterion population row blocks
    with tempfile.TemporaryDirectory() as tmp:
        path = _workbook(tmp, todo_tab=False)
        wb = load_workbook(path)
        wb["studypoppage"].append(("2.9", "Hospice note", "No hospice during baseline",
                                   "", "", ""))
        wb.save(path)
        spine, tabs, _d = ce.read_workbook(path)
        ex = ce.extract(spine)
        assert any("Hospice note" in g for g in ex["gaps"]), ex["gaps"]
    # 6. vocabulary identifiers are exact: NOT-NDC and ICD-10-PCS both refuse where
    # substring matching used to wave them through
    with tempfile.TemporaryDirectory() as tmp:
        path = _workbook(tmp, todo_tab=False, include_prose=False)
        wb = load_workbook(path)
        lst = wb.create_sheet("codes_a")
        lst.append(("Code", "Code Type"))
        lst.append(("00069123401", "NOT-NDC"))
        lst2 = wb.create_sheet("codes_b")
        lst2.append(("Code", "Code Type"))
        lst2.append(("0DB60ZZ", "ICD-10-PCS"))
        wb.save(path)
        spine, tabs, _d = ce.read_workbook(path)
        ex = ce.extract(spine)
        bpath = os.path.join(tmp, "b.yaml")
        for bad in ({"events": {"ev_a": {"ndc_cd": "codes_a"}}},
                    {"events": {"ev_b": {"dx_cd": "codes_b"}}}):
            with open(bpath, "w", encoding="utf-8") as fh:
                _yaml.safe_dump(bad, fh)
            try:
                ce.load_bindings(bpath, tabs, ex)
            except SystemExit as e:
                assert "takes exactly" in str(e), (bad, e)
            else:
                raise AssertionError(f"accepted a mismatched vocabulary: {bad}")
    # 7. the staging collision: --out x.yaml.tmp --manifest x.yaml both land intact
    with tempfile.TemporaryDirectory() as tmp:
        wb = _workbook(tmp)
        out = os.path.join(tmp, "x.yaml.tmp")
        man = os.path.join(tmp, "x.yaml")
        rv = ce.main([wb, "--out", out, "--manifest", man])
        assert rv == 2
        assert os.path.exists(out) and os.path.exists(man)
        r_text = open(out, encoding="utf-8").read()
        m_loaded = _yaml.safe_load(open(man, encoding="utf-8"))
        assert r_text.startswith("# GENERATED DRAFT"), "the R output was clobbered"
        assert m_loaded["manifest_version"] == 1, "the manifest was clobbered"


def test_vocabulary_argument_mismatch_refuses_in_bindings():
    """Probe wave 16: ICD-10 codes bound to ndc_cd produced zero blockers - a list that selects
    nothing or the wrong claims. The binding validator now holds vocabulary-to-argument
    compatibility per code, and an unsafe event name refuses before it reaches generated R."""
    import yaml as _yaml
    from openpyxl import load_workbook
    with tempfile.TemporaryDirectory() as tmp:
        path = _workbook(tmp, todo_tab=False, include_prose=False)
        wb = load_workbook(path)
        lst = wb.create_sheet("oc_dx")
        lst.append(("Code", "Code Type", "Description"))
        lst.append(("C56.9", "ICD-10-CM", "Ovarian"))
        wb.save(path)
        spine, tabs, _d = ce.read_workbook(path)
        ex = ce.extract(spine)
        bpath = os.path.join(tmp, "b.yaml")
        for bad, want in (
                ({"events": {"oc": {"ndc_cd": "oc_dx"}}}, "takes exactly NDC"), # ICD into NDC
                ({"events": {"bad name;system('x')": {"dx_cd": "oc_dx"}}},
                 "safe identifier"), # R injection
                ({"events": {"db": {"dx_cd": "oc_dx"}}}, "runtime argument"), # arg collision
                ({"events": {"if": {"dx_cd": "oc_dx"}}}, "reserved word"), # invalid R
        ):
            with open(bpath, "w", encoding="utf-8") as fh:
                _yaml.safe_dump(bad, fh)
            try:
                ce.load_bindings(bpath, tabs, ex)
            except SystemExit as e:
                assert want in str(e), (bad, e)
            else:
                raise AssertionError(f"accepted: {bad}")
        # the compatible binding still loads
        with open(bpath, "w", encoding="utf-8") as fh:
            _yaml.safe_dump({"events": {"oc": {"dx_cd": "oc_dx"}}}, fh)
        assert ce.load_bindings(bpath, tabs, ex)["events"]["oc"]["dx_cd"] == "oc_dx"


def test_the_exit_code_is_the_machine_readable_verdict():
    """Probe wave 16: a gapped draft exited 0 and automation read success as runnable. Exit 2 now
    means written-but-BLOCKED; and --out colliding with --manifest refuses instead of the
    second write destroying the first."""
    with tempfile.TemporaryDirectory() as tmp:
        wb = _workbook(tmp)
        out = os.path.join(tmp, "d.R")
        rv = ce.main([wb, "--out", out])
        assert rv == 2 and os.path.exists(out), rv
        try:
            ce.main([wb, "--out", out, "--manifest", out])
        except SystemExit as e:
            assert "same file" in str(e), e
        else:
            raise AssertionError("--out and --manifest shared a path silently")


def test_code_lists_are_recognised_by_shape_never_by_name():
    """MM says dx_codes; the next therapy area will say something else. A tab with a `code`
    header column is lifted verbatim whatever it is called, with the tab as provenance; a
    tab that is none of spine / code list / TO-BE-BUILT is NAMED as unread, never silently
    skipped; and the EVENTS guard flips to the binding wording but keeps blocking - the tab
    name does not state which study_specs event the list belongs to."""
    from openpyxl import load_workbook, Workbook
    with tempfile.TemporaryDirectory() as tmp:
        path = _workbook(tmp, todo_tab=False)
        wb = load_workbook(path)
        lst = wb.create_sheet("oc_chemo_ndc") # a name this tool never saw
        lst.append(("Code", "Code Type", "Description"))
        lst.append(("00069123401", "NDC", "paclitaxel"))
        lst.append(("J9267", "HCPCS", "paclitaxel injection"))
        gl = wb.create_sheet("glossary") # not a code list, not TO BE BUILT
        gl.append(("Term", "Meaning"))
        gl.append(("CE", "continuous enrollment"))
        wb.save(path)
        spine, tabs, digest = ce.read_workbook(path)
        assert tabs["lists"]["oc_chemo_ndc"]["codes"][0]["code"] == "00069123401"
        assert tabs["lists"]["oc_chemo_ndc"]["codes"][1]["type"] == "HCPCS"
        assert "glossary" in tabs["unread"]
        ex = ce.extract(spine)
        script = ce.render(path, tabs, ex, digest)
        assert "oc_chemo_ndc <- c(" in script
        assert "'00069123401'" in script # leading zeros survive
        assert "'glossary'" in script and "NOT read" in script
        guards = ce._guards(tabs, ex)
        assert any("bindings file" in g for g in guards), \
            "lifted lists stopped blocking on binding"
        assert any("glossary" in g for g in guards), \
            "an unread tab stopped blocking - unread content may carry cohort rules"
        m = ce.manifest(path, tabs, ex, digest)
        assert m["code_lists"]["oc_chemo_ndc"]["count"] == 2
        assert "glossary" in m["unread_tabs"]


def test_a_numeric_code_cell_refuses_because_excel_ate_the_zeros():
    """An NDC stored as a number has already lost its leading zeros - exporting it would
    select the wrong claims, so the read refuses naming the tab and the cell."""
    from openpyxl import load_workbook
    with tempfile.TemporaryDirectory() as tmp:
        path = _workbook(tmp, todo_tab=False)
        wb = load_workbook(path)
        lst = wb.create_sheet("dx_codes")
        lst.append(("Code", "Type"))
        lst.append((69123401, "NDC")) # numeric: the zeros are gone
        wb.save(path)
        try:
            ce.read_workbook(path)
        except SystemExit as e:
            assert "NUMBER" in str(e) and "dx_codes" in str(e), e
        else:
            raise AssertionError("a numeric code was exported with its zeros already eaten")


def test_the_pack_door_only_opens_for_declared_claims_modality():
    """Identity refuses before evidence: naming --pack claims a registration, and the registry
    must say modality: claims. The prostate fixture is the ADS-engine path (ehr), so it is the
    perfect wrong pack - and an unregistered directory is refused as exactly that."""
    with tempfile.TemporaryDirectory() as tmp:
        wb = _workbook(tmp)
        ehr_pack = str(REPO / "fixtures" / "oncology" / "prostate" / "202606")
        try:
            ce.main([wb, "--pack", ehr_pack, "--out", os.path.join(tmp, "d.R")])
        except SystemExit as e:
            assert "modality" in str(e) and "'ehr'" in str(e), e
        else:
            raise AssertionError("an EHR pack walked out through the claims door")
        try:
            ce.main([wb, "--pack", tmp, "--out", os.path.join(tmp, "d.R")])
        except SystemExit as e:
            assert "no registry entry" in str(e), e
        else:
            raise AssertionError("an unregistered path was accepted as a pack")
        assert not os.path.exists(os.path.join(tmp, "d.R"))


def test_a_workbook_without_the_spine_sheets_refuses_to_half_read():
    """A workbook that is not the house template gets a refusal, not a confident render of
    whatever sheets happened to parse."""
    from openpyxl import Workbook
    with tempfile.TemporaryDirectory() as tmp:
        wb = Workbook()
        wb.active.title = "some_other_shape"
        path = os.path.join(tmp, "not_the_template.xlsx")
        wb.save(path)
        try:
            ce.read_workbook(path)
        except SystemExit as e:
            assert "spine sheets" in str(e)
        else:
            raise AssertionError("a template-less workbook was half-read")


def test_final_audit_claims_input_integrity():
    """Two false greens from the final audit: a duplicate key in a reviewed bindings file was
    last-wins (the file said one thing, the export did another), and a hand-edited manifest
    executed exactly as if the exporter had written it."""
    import yaml as _yaml
    # 1. a duplicate key in the bindings refuses outright, never silently overwrites
    with tempfile.TemporaryDirectory() as tmp:
        path = _workbook(tmp)
        _spine, tabs, _digest = ce.read_workbook(path)
        ex = ce.extract(_spine)
        bpath = os.path.join(tmp, "bindings.yaml")
        with open(bpath, "w", encoding="utf-8", newline="\n") as fh:
            fh.write("events: {}\ncriteria: {}\ncriteria: {}\n")
        try:
            ce.load_bindings(bpath, tabs, ex)
        except SystemExit as e:
            assert "duplicate" in str(e).lower(), e
        else:
            raise AssertionError("a duplicate bindings key was last-wins")
    # 2. the manifest is sealed, and the seal is checked byte for byte
    with tempfile.TemporaryDirectory() as tmp:
        wb = _workbook(tmp)
        man = os.path.join(tmp, "m.yaml")
        ce.main([wb, "--manifest", man])
        first = open(man, encoding="utf-8").readline()
        assert first.startswith(ce.INTEGRITY_PREFIX), "the manifest is not sealed"
        assert ce.manifest_integrity_errors(man) == []
        # the seal is a comment: the YAML underneath still parses as the manifest
        assert _yaml.safe_load(open(man, encoding="utf-8"))["manifest_version"] == 1
        # a CRLF checkout is not tampering
        raw = open(man, "rb").read()
        crlf = os.path.join(tmp, "crlf.yaml")
        open(crlf, "wb").write(raw.replace(b"\n", b"\r\n"))
        assert ce.manifest_integrity_errors(crlf) == []
        # one edited byte fails the seal
        tampered = os.path.join(tmp, "t.yaml")
        open(tampered, "wb").write(raw.replace(b"manifest_version: 1",
                                               b"manifest_version: 2"))
        assert any("mismatch" in e for e in ce.manifest_integrity_errors(tampered))
        # and a manifest with no seal at all is refused, not waved through
        unsealed = os.path.join(tmp, "u.yaml")
        open(unsealed, "wb").write(raw.split(b"\n", 1)[1])
        assert any("no content_sha256" in e for e in ce.manifest_integrity_errors(unsealed))


if __name__ == "__main__":
    failures = 0
    for name, fn in sorted(globals().items()):
        if name.startswith("test_") and callable(fn):
            try:
                fn()
                print(f"PASS {name}")
            except AssertionError as e:
                failures += 1
                print(f"FAIL {name}: {e}")
    print(f"{'FAILURES: ' + str(failures) if failures else 'all cohortly_export tests passed'}")
    sys.exit(1 if failures else 0)
