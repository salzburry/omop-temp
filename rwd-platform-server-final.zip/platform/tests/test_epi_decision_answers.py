"""Explicit scientist input, stale-basis rejection and rollback without live edits."""
from pathlib import Path
import os
import re
import sys
import time
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parent))
from _epi_test_support import api, run
pytest = api(__name__)
import yaml

ROOT = Path(__file__).resolve().parents[2]
sys.path[:0] = [str(ROOT / "platform/tools"), str(ROOT / "experiments/portal")]
import contract_lint as cl
import decision_answers as editor
import decision_record as dr

PACK = "products/oncology/example/202609"
VALUES = {"answer": "Use the latest recorded assessment.", "answered_by": "Alice Smith", "answer_date": "2026-09-06"}


def seed(root):
    product = root / PACK
    (product / "handoff").mkdir(parents=True)
    (product / dr.DECISIONS).write_text(
        "# Scientific decisions\n\n| ID | Question | Evidence | Owner | Resolution | Approved by | Approval date | Status |\n"
        "|---|---|---|---|---|---|---|---|\n"
        "| Q1 | Which assessment date? | clinical:1 | Science | — | | | OPEN |\n"
        "| Q2 | Which measurement unit? | clinical:2 | Science | — | | | OPEN |\n", encoding="utf-8")
    (product / "handoff/FUNCTIONAL_CONTRACT.md").write_text("# Contract drafting in progress\n", encoding="utf-8")
    written, _, error = dr.write_forms(PACK, root=str(root))
    assert len(written) == 2 and not error
    return product


def snapshot(root):
    return {p.relative_to(root).as_posix(): p.read_bytes() for p in root.rglob("*") if p.is_file()}


def save(root, batch=None, digest=None, **kwargs):
    return editor.save(root, PACK, batch or {"Q1": VALUES}, expected_digest=digest or editor.describe(root, PACK)["digest"],
                       local_demo=kwargs.get("local_demo", True), can_write=kwargs.get("can_write", True),
                       allowed_packs=kwargs.get("allowed_packs", [PACK]))


def test_two_answers_apply_using_existing_helper_without_approval_or_signature(tmp_path):
    product = seed(tmp_path)
    before = snapshot(tmp_path)
    described = editor.describe(tmp_path, PACK)
    assert described["ok"] and all(i["editable"] for i in described["items"])
    result = save(tmp_path, {"Q1": VALUES, "Q2": {**VALUES, "answer": "Use milligrams."}})
    assert result["ok"] and result["changed"] and result["applied"] == ["Q1", "Q2"], result
    assert dr.check_bindings(PACK, root=str(tmp_path)) == []
    assert cl.decision_status((product / dr.DECISIONS).read_text(encoding="utf-8")) == {"Q1": "RESOLVED", "Q2": "RESOLVED"}
    changed = {key for key, raw in snapshot(tmp_path).items() if before.get(key) != raw}
    product_changes = {name for name in changed if name.startswith(PACK + "/")}
    assert product_changes == {(Path(PACK) / dr.DECISIONS).as_posix(), (Path(PACK) / dr.FORMS_DIR / "Q1.yaml").as_posix(), (Path(PACK) / dr.FORMS_DIR / "Q2.yaml").as_posix(), PACK + "/handoff/SCIENCE_QUESTIONS.md"}
    assert all(name.startswith((PACK + "/", "governance/events/")) for name in changed)
    assert result["completion_ok"] and result["sealed_ids"] == ["Q1", "Q2"]
    assert "# Decision answer form" in (product / dr.FORMS_DIR / "Q1.yaml").read_text(encoding="utf-8")
    assert not (tmp_path / ".git").exists()


@pytest.mark.parametrize("field,value", [("answer", ""), ("answer", "A | B"), ("answered_by", "DataExpert"), ("answer_date", "2026-02-30"), ("answered_by", "Alice | Smith")])
def test_one_invalid_answer_refuses_entire_batch(tmp_path, field, value):
    seed(tmp_path)
    before = snapshot(tmp_path)
    result = save(tmp_path, {"Q1": VALUES, "Q2": {**VALUES, field: value}})
    assert not result["ok"]
    assert snapshot(tmp_path) == before


@pytest.mark.parametrize("answer", [
    "TODO — Draft option for scientific review: use the selected assessment.",
    "Use the latest assessment. TODO: confirm the time window.",
    "Use the closest value; tbd: resolve ties.",
    "Window: REPLACE_ME days.",
    "Use the selected date. FIXME: confirm its source.",
    "Not sure yet — ask the scientific owner to decide.",
    "Not sure",
    "Not sure — ask the study team.",
])
def test_unresolved_guided_or_ai_answer_cannot_resolve_any_question_in_batch(tmp_path, answer):
    seed(tmp_path)
    before = snapshot(tmp_path)
    result = save(tmp_path, {"Q1": VALUES, "Q2": {**VALUES, "answer": answer}})
    assert not result["ok"] and "question remains open" in result["errors"][0]
    assert snapshot(tmp_path) == before


@pytest.mark.parametrize("mode", ["question", "contract", "form", "new_form"])
def test_changed_basis_after_read_refuses_without_writes(tmp_path, mode):
    product = seed(tmp_path)
    digest = editor.describe(tmp_path, PACK)["digest"]
    path = {"question": product / dr.DECISIONS, "contract": product / "handoff/FUNCTIONAL_CONTRACT.md",
            "form": product / dr.FORMS_DIR / "Q1.yaml", "new_form": product / dr.FORMS_DIR / "Q3.yaml"}[mode]
    if mode == "new_form":
        path.write_bytes((product / dr.FORMS_DIR / "Q1.yaml").read_bytes())
    else:
        path.write_bytes(path.read_bytes() + b"\n# Another author's change\n")
    before = snapshot(tmp_path)
    result = save(tmp_path, digest=digest)
    assert not result["ok"] and snapshot(tmp_path) == before


def test_issued_stale_question_is_explained_and_not_editable(tmp_path):
    product = seed(tmp_path)
    register = product / dr.DECISIONS
    register.write_text(register.read_text(encoding="utf-8").replace("Which assessment date?", "Which baseline assessment date?"), encoding="utf-8")
    description = editor.describe(tmp_path, PACK)
    q1 = next(i for i in description["items"] if i["id"] == "Q1")
    assert not q1["editable"] and any("question changed" in e for e in q1["errors"])
    before = snapshot(tmp_path)
    assert not save(tmp_path)["ok"] and snapshot(tmp_path) == before


@pytest.mark.parametrize("kwargs", [{"can_write": False}, {"local_demo": False}, {"allowed_packs": []}])
def test_scope_and_role_fail_before_any_write(tmp_path, kwargs):
    seed(tmp_path)
    before = snapshot(tmp_path)
    assert not save(tmp_path, **kwargs)["ok"]
    assert snapshot(tmp_path) == before


def test_existing_ruling_cannot_be_overwritten(tmp_path):
    seed(tmp_path)
    assert save(tmp_path)["ok"]
    before = snapshot(tmp_path)
    assert not save(tmp_path, {"Q1": {**VALUES, "answer": "A different answer."}})["ok"]
    assert snapshot(tmp_path) == before


def test_failed_second_replacement_restores_entire_batch(tmp_path):
    seed(tmp_path)
    before = snapshot(tmp_path)
    replace = os.replace
    calls = []

    def fail_once(source, target):
        calls.append(str(target))
        if len(calls) == 2:
            raise OSError("Simulated disk failure")
        return replace(source, target)

    with patch.object(editor.os, "replace", side_effect=fail_once):
        result = save(tmp_path, {"Q1": VALUES, "Q2": VALUES})
    assert not result["ok"] and snapshot(tmp_path) == before
    assert len(calls) == 3  # first write, failed second write, rollback first write


def test_duplicate_yaml_or_path_traversal_fails_closed(tmp_path):
    product = seed(tmp_path)
    path = product / dr.FORMS_DIR / "Q1.yaml"
    path.write_bytes(path.read_bytes() + b"answer: changed\n")
    before = snapshot(tmp_path)
    assert not editor.describe(tmp_path, PACK)["ok"]
    assert not editor.describe(tmp_path, "../elsewhere")["ok"]
    assert snapshot(tmp_path) == before


def test_missing_forms_are_an_empty_preparation_state(tmp_path):
    product = seed(tmp_path)
    for path in (product / dr.FORMS_DIR).glob("*.yaml"):
        path.unlink()
    description = editor.describe(tmp_path, PACK)
    assert description["ok"] and not description["items"]
    assert not save(tmp_path)["ok"]


def test_prepare_missing_question_drafts_preserves_register_and_existing_unfinished_answers(tmp_path):
    product = seed(tmp_path)
    existing = product / dr.FORMS_DIR / "Q1.yaml"
    raw = yaml.safe_load(existing.read_text(encoding="utf-8"))
    raw["answer"] = "TODO: my unfinished answer must be preserved."
    existing.write_text(yaml.safe_dump(raw), encoding="utf-8")
    (product / dr.FORMS_DIR / "Q2.yaml").unlink()
    before = snapshot(tmp_path)
    current = editor.describe(tmp_path, PACK)
    assert current["unissued_ids"] == ["Q2"]
    result = editor.prepare_forms(tmp_path, PACK, expected_digest=current["digest"], local_demo=True,
                                  can_write=True, allowed_packs=[PACK])
    assert result["ok"] and result["prepared"] == ["Q2"] and not result["unissued_ids"]
    after = snapshot(tmp_path)
    assert all(after[key] == value for key, value in before.items())
    created = next(item for item in result["items"] if item["id"] == "Q2")
    assert created["status"] == "OPEN" and created["editable"]
    assert all(not value for value in created["values"].values())
    again = editor.prepare_forms(tmp_path, PACK, expected_digest=result["digest"], local_demo=True,
                                 can_write=True, allowed_packs=[PACK])
    assert again["ok"] and not again["changed"] and snapshot(tmp_path) == after


@pytest.mark.parametrize("mode", ["denied", "outside_scope", "stale"])
def test_question_preparation_refuses_changed_inputs_or_missing_access(tmp_path, mode):
    product = seed(tmp_path)
    (product / dr.FORMS_DIR / "Q2.yaml").unlink()
    current = editor.describe(tmp_path, PACK)
    before = snapshot(tmp_path)
    result = editor.prepare_forms(tmp_path, PACK, expected_digest="stale" if mode == "stale" else current["digest"],
                                  local_demo=True, can_write=mode != "denied", allowed_packs=[] if mode == "outside_scope" else [PACK])
    assert not result["ok"] and snapshot(tmp_path) == before


def test_question_preparation_rolls_back_only_its_new_forms_after_publish_failure(tmp_path):
    product = seed(tmp_path)
    for did in ("Q1", "Q2"):
        (product / dr.FORMS_DIR / f"{did}.yaml").unlink()
    current = editor.describe(tmp_path, PACK)
    before = snapshot(tmp_path)
    link = os.link
    calls = []
    def fail_second(source, target):
        calls.append(target)
        if len(calls) == 2:
            raise OSError("simulated publication failure")
        return link(source, target)
    with patch.object(editor.os, "link", side_effect=fail_second):
        result = editor.prepare_forms(tmp_path, PACK, expected_digest=current["digest"], local_demo=True,
                                      can_write=True, allowed_packs=[PACK])
    assert not result["ok"] and not result["changed"] and len(calls) == 2
    assert snapshot(tmp_path) == before


def _plain_words(text):
    """No absolute path, no temporary directory, no command-line flag, no dash or arrow tokens."""
    return not re.search(r"[A-Za-z]:[\\/]|Errno|--forms|--apply| — |->|portal-answer-check", text)


def raise_question(root, values, **kwargs):
    return editor.raise_question(root, PACK, values, expected_digest=kwargs.get("digest") or editor.describe(root, PACK)["digest"],
                                 local_demo=kwargs.get("local_demo", True), can_write=kwargs.get("can_write", True),
                                 allowed_packs=kwargs.get("allowed_packs", [PACK]))


NEW_QUESTION = {"id": "Q3", "question": "Which death date source is used?", "evidence": "clinical:5", "owner": "Science"}


def test_raise_question_appends_one_open_row_with_no_answer_name_or_date(tmp_path):
    """DL-03: the Questions page had no way to add a question to the register it reads."""
    product = seed(tmp_path)
    before = snapshot(tmp_path)
    register = product / dr.DECISIONS
    old_lines = register.read_text(encoding="utf-8").splitlines()
    assert editor.describe(tmp_path, PACK)["owners"] == ["Science"]
    result = raise_question(tmp_path, NEW_QUESTION)
    assert result["ok"] and result["changed"] and result["raised"] == "Q3", result
    assert result["unissued_ids"] == ["Q3"]
    text = register.read_text(encoding="utf-8")
    rows = cl.decision_rows(text)
    assert cl.decision_status(text) == {"Q1": "OPEN", "Q2": "OPEN", "Q3": "OPEN"}
    assert cl.decision_question(rows["Q3"]) == NEW_QUESTION["question"]
    assert cl.decision_evidence(rows["Q3"]) == "clinical:5" and cl.decision_owner(rows["Q3"]) == "Science"
    assert not cl.decision_approver(rows["Q3"]) and not cl.decision_approval_date(rows["Q3"])
    assert dr._blankish(cl.decision_answer(rows["Q3"]))
    new_lines = text.splitlines()
    assert [line for line in new_lines if not line.startswith("| Q3 ")] == old_lines
    changed = {key for key, raw in snapshot(tmp_path).items() if before.get(key) != raw}
    assert changed == {(Path(PACK) / dr.DECISIONS).as_posix()}
    assert not list((product / "handoff").glob("*.lock")) and not list((product / "handoff").glob("*.tmp"))
    # The new question runs the same loop as any other: prepare its draft, then a person answers it.
    prepared = editor.prepare_forms(tmp_path, PACK, expected_digest=result["digest"], local_demo=True, can_write=True, allowed_packs=[PACK])
    assert prepared["ok"] and prepared["prepared"] == ["Q3"]
    saved = save(tmp_path, {"Q3": {**VALUES, "answer": "Use the vital status table's death date."}})
    assert saved["ok"] and cl.decision_status(register.read_text(encoding="utf-8"))["Q3"] == "RESOLVED"
    assert dr.check_bindings(PACK, root=str(tmp_path)) == []


@pytest.mark.parametrize("change,reason", [
    ({"id": "Q1"}, "already in the register"),
    ({"id": "q3"}, "capital letters"),
    ({"id": "Q3-"}, "capital letters"),
    ({"question": "Which | source?"}, "table separator"),
    ({"question": "Which source?\nSecond line"}, "one line"),
    ({"evidence": "clinical:5 | more"}, "table separator"),
    ({"owner": "Alice Smith"}, "owner the register already uses"),
    ({"owner": "DataExpert"}, "owner the register already uses"),
    ({"evidence": ""}, "Name the evidence"),
    ({"evidence": "—"}, "Name the evidence"),
    ({"evidence": "nothing"}, "names nothing"),
    ({"question": ""}, "one plain sentence"),
])
def test_raise_question_refuses_in_plain_words_and_writes_nothing(tmp_path, change, reason):
    seed(tmp_path)
    before = snapshot(tmp_path)
    result = raise_question(tmp_path, {**NEW_QUESTION, **change})
    assert not result["ok"] and reason in result["errors"][0], result
    assert _plain_words(result["errors"][0]), result
    assert snapshot(tmp_path) == before


@pytest.mark.parametrize("kwargs", [{"can_write": False}, {"local_demo": False}, {"allowed_packs": []}, {"digest": "stale"}])
def test_raise_question_needs_access_scope_and_a_current_register(tmp_path, kwargs):
    seed(tmp_path)
    before = snapshot(tmp_path)
    assert not raise_question(tmp_path, NEW_QUESTION, **kwargs)["ok"]
    assert snapshot(tmp_path) == before


def test_raise_question_refuses_a_register_without_an_evidence_column(tmp_path):
    product = seed(tmp_path)
    register = product / dr.DECISIONS
    register.write_text("| ID | Question | Owner | Status |\n|---|---|---|---|\n| Q1 | Which date? | Science | OPEN |\n", encoding="utf-8")
    for path in (product / dr.FORMS_DIR).glob("*.yaml"):
        path.unlink()
    before = snapshot(tmp_path)
    result = raise_question(tmp_path, NEW_QUESTION)
    assert not result["ok"] and "no evidence column" in result["errors"][0]
    assert snapshot(tmp_path) == before


def test_a_leftover_lock_is_explained_without_paths_and_cleared_only_when_stale(tmp_path):
    """DL-06: a lock file left by a dead save produced the operating system's text and a full path."""
    product = seed(tmp_path)
    lock = product / editor.LOCK_NAME
    lock.write_text("left behind", encoding="utf-8")
    before = snapshot(tmp_path)
    for attempt in (lambda: save(tmp_path), lambda: raise_question(tmp_path, NEW_QUESTION),
                    lambda: editor.prepare_forms(tmp_path, PACK, expected_digest=editor.describe(tmp_path, PACK)["digest"],
                                                 local_demo=True, can_write=True, allowed_packs=[PACK])):
        result = attempt()
        assert not result["ok"] and result["errors"] == [editor.LOCK_MESSAGE] and result["stale_lock"] is False, result
        assert _plain_words(result["errors"][0])
    cleared = editor.clear_stale_lock(tmp_path, PACK, local_demo=True, can_write=True, allowed_packs=[PACK])
    assert not cleared["ok"] and "recent" in cleared["errors"][0]
    assert lock.read_text(encoding="utf-8") == "left behind" and snapshot(tmp_path) == before
    stale = time.time() - editor.LOCK_STALE_SECONDS - 60
    os.utime(lock, (stale, stale))
    result = save(tmp_path)
    assert not result["ok"] and result["stale_lock"] is True and "stale" in result["errors"][0] and _plain_words(result["errors"][0])
    assert lock.exists()
    assert not editor.clear_stale_lock(tmp_path, PACK, local_demo=True, can_write=False, allowed_packs=[PACK])["ok"]
    assert lock.exists()
    cleared = editor.clear_stale_lock(tmp_path, PACK, local_demo=True, can_write=True, allowed_packs=[PACK])
    assert cleared["ok"] and cleared["cleared"] and not lock.exists()
    assert {key for key, raw in snapshot(tmp_path).items() if before.get(key) != raw} == set()
    assert save(tmp_path)["ok"]
    again = editor.clear_stale_lock(tmp_path, PACK, local_demo=True, can_write=True, allowed_packs=[PACK])
    assert again["ok"] and not again["cleared"]


def test_tool_refusals_reach_the_person_without_paths_or_flags(tmp_path):
    """DL-07: save errors quoted a temporary directory, the repository path and '--forms'."""
    product = seed(tmp_path)
    result = save(tmp_path, {"Q1": {**VALUES, "answered_by": "DataExpert"}})
    assert not result["ok"] and "team, not a person" in result["errors"][0], result
    assert _plain_words(result["errors"][0]) and str(tmp_path) not in result["errors"][0], result
    register = product / dr.DECISIONS
    register.write_text(register.read_text(encoding="utf-8").replace("Which assessment date?", "Which baseline assessment date?"), encoding="utf-8")
    q1 = next(item for item in editor.describe(tmp_path, PACK)["items"] if item["id"] == "Q1")
    assert q1["errors"] and all(_plain_words(error) and str(tmp_path) not in error and "Q1.yaml" not in error for error in q1["errors"]), q1["errors"]
    assert any("prepare the question drafts again" in error for error in q1["errors"])
    assert editor.plain("C:\\tmp\\portal-answer-check-1\\Q1.yaml: Q1 is stale — delete the form and re-issue with --forms") == \
        "Q1 is stale; delete the form and prepare the question drafts again"
    assert editor.plain("/tmp/forms/Q2.yaml: Q2 `answer` contains `|` -> rephrase; see n/a and handoff/decision_answers") == \
        "Q2 answer contains | to rephrase; see n/a and handoff/decision_answers"


def test_reopen_contract_puts_the_maturity_claim_back_to_draft_and_nothing_else(tmp_path):
    pack = "products/oncology/reopen_test/202601"
    handoff = tmp_path / pack / "handoff"
    handoff.mkdir(parents=True)
    maturity = handoff / "MATURITY.yaml"
    maturity.write_text("# the claims\ncontract: approved   # 2026-09-01\nconfiguration: draft\n", encoding="utf-8")
    refused = editor.reopen_contract(tmp_path, pack, "author@example.test", local_demo=True, can_write=False, allowed_packs=[pack])
    assert not refused["ok"] and "product-author access" in refused["errors"][0]
    assert "contract: approved" in maturity.read_text(encoding="utf-8")
    done = editor.reopen_contract(tmp_path, pack, "author@example.test", local_demo=True, can_write=True, allowed_packs=[pack])
    assert done["ok"] and done["changed"] and "reopened" in done["message"], done
    assert maturity.read_text(encoding="utf-8") == "# the claims\ncontract: draft   # 2026-09-01\nconfiguration: draft\n"
    again = editor.reopen_contract(tmp_path, pack, "author@example.test", local_demo=True, can_write=True, allowed_packs=[pack])
    assert not again["ok"] and "nothing to reopen" in again["errors"][0]
    maturity.write_text("contract: approved\ncontract: approved\n", encoding="utf-8")
    twice = editor.reopen_contract(tmp_path, pack, "author@example.test", local_demo=True, can_write=True, allowed_packs=[pack])
    assert not twice["ok"] and "more than once" in twice["errors"][0]
    assert maturity.read_text(encoding="utf-8") == "contract: approved\ncontract: approved\n"


if __name__ == "__main__":
    raise SystemExit(run(globals()))
