"""The definition tool names a variable's source and its evidence in plain words.

An epidemiologist's walk (UC4-62) found the definition view silent about where a variable's data
comes from: not which table or column supplies it, nor whether the delivery was checked. The tool now
prints the record's own source kind, tables and columns, and the two evidence axes (source mapping,
live schema check) as sentences after the status line; everything it printed before is unchanged.

    python platform/tests/test_definition_tool_source.py
"""
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "platform/tools"))
import mcp_server as srv  # noqa: E402

PACK = "fixtures/oncology/prostate/202606"


def _definition(variable):
    return srv.t_definition({"pack": PACK, "variable": variable})


def test_a_vendor_variable_names_its_tables_columns_and_the_two_evidence_axes():
    text = _definition("AGE")
    lines = text.splitlines()
    status = next(i for i, line in enumerate(lines) if line.startswith("status: "))
    assert lines[status + 1] == "source: vendor data from demographics (delivered as t_demographics); columns birthyear (birth_year)."
    assert lines[status + 2] == ("evidence: the mapping of these columns to this variable is proposed and not yet confirmed by a person; "
                                 "the delivered data has not been checked against this definition yet.")
    assert lines[status + 3].startswith("governing decisions: ")
    assert "REFERENCE FIXTURE" in text and "status: requirement=draft, implementation=implemented" in text
    for added in lines[status + 1:status + 3]:
        assert not any(token in added for token in (" — ", "->", ".yaml", ".py", "--")), added


def test_a_legacy_shaped_record_names_the_delivered_table_the_record_states():
    text = _definition("ECOG")
    source = next(line for line in text.splitlines() if line.startswith("source: "))
    assert "baseline_ecog, ecog" in source and "t_enh_prostate_bsln_ecog" in source and "ecogvalue (value)" in source
    assert "evidence: " in text


def test_a_derived_variable_says_no_table_is_read_and_carries_no_evidence_line():
    text = _definition("AGEGR1")
    assert "source: derived from other variables of this product; no delivered table is read for it." in text
    assert "evidence: " not in text


def test_the_summary_and_the_unknown_variable_answers_are_unchanged():
    summary = _definition("")
    assert summary.startswith("Prostate") and "variables: " in summary and "source: " not in summary
    assert "no variable named 'NOPE'" in _definition("NOPE")


def test_the_source_words_never_invent_a_mapping():
    """Every table, column and verdict word comes from the record or the pack's own declarations."""
    import contract_lint as cl
    text = cl.read(str(ROOT / PACK / "handoff/FUNCTIONAL_CONTRACT.md"))
    record = next(r for r in cl.typed_records(text) if r.variable_id == "REGION1")
    words = srv._source_words(str(ROOT / PACK), "REGION1")
    assert len(words) == 2 and "state (state)" in words[0] and "demographics (delivered as t_demographics)" in words[0]
    assert record.axis("source_mapping") == "proposed" and "proposed" in words[1]
    assert srv._source_words(str(ROOT / PACK), "NOT_A_VARIABLE") == []


if __name__ == "__main__":
    import pytest
    raise SystemExit(pytest.main([__file__, "-q", "-p", "no:cacheprovider"]))
