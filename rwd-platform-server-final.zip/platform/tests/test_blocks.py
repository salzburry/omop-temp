"""The block catalogue must be derived, never authored.

`platform/tools/blocks.py` prints what a pack's config may NAME — match operators, formula methods,
follow-up sources, death-conflict policies. Its single risk is the one docs/ENGINEERING.md opens with: a
hand-typed list is correct the day it is written and wrong from the first edit after, and a stale
catalogue is worse than none because it is still believed. An analyst reads this to author config;
if it advertises a formula the engine dropped, they write it, and the validator refuses it.

So every name it prints is asserted to come from the registry that owns it, and the objects it reads
are asserted to be the same objects `validate.py` checks against — authoring and checking cannot
disagree about the vocabulary if they are reading the same dict.

Run: python3 tests/test_blocks.py (or pytest).
"""
import re
import sys
from pathlib import Path

FRAMEWORK = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(FRAMEWORK / "tools"))
sys.path.insert(0, str(FRAMEWORK / "engine"))

import blocks     # noqa: E402
import codelists  # noqa: E402
import validate   # noqa: E402
from stages import clinical  # noqa: E402


# section title -> the authoritative name set, imported here INDEPENDENTLY of blocks.py. If
# sections() ever grows a literal, these disagree.
AUTHORITY = {
    "MATCH OPERATORS":       lambda: set(codelists.MATCH_OPERATORS),
    "VALUE MATCHERS":        lambda: set(clinical.VALUE_MATCHERS),
    "RECORD DATE BASIS":     lambda: set(clinical.DATE_BASIS),
    "RECORD PICK":           lambda: set(clinical.RECORD_PICK),
    "RECORD TIE-BREAK":      lambda: set(clinical.TIE_BREAK),
    "BMI METHOD":            lambda: set(clinical.BMI_FORMULAS),
    "BSA METHOD":            lambda: set(clinical.BSA_FORMULAS),
    "FOLLOW-UP ROW FILTER":  lambda: set(clinical.FOLLOWUP_FILTERS),
    "UNIT CONVERSION":       lambda: set(clinical.UNIT_CONVERSIONS),
    "FOLLOW-UP SOURCES":     lambda: {t[0] for t in clinical.FOLLOWUP_SOURCES},
    "DEATH CONFLICT POLICY": lambda: set(clinical.DEATH_CONFLICT_POLICIES),
    "VENDORS":               lambda: set(validate.KNOWN_VENDORS),
    "TUMOUR CLASSES":        lambda: set(validate.KNOWN_TUMOR_CLASSES),
    "REQUIRED SOURCES":      lambda: set(validate.REQUIRED_SOURCES),
    "VARIABLE PACK ROLES":   lambda: set(validate.EXPECTED_ROLES),
}


def test_every_section_matches_the_registry_that_owns_it():
    """The whole design in one assertion: no section may carry a name of its own invention, and
    none may drop one the engine offers."""
    seen = {}
    for title, _key, _blurb, items in blocks.sections():
        assert title in AUTHORITY, f"section {title!r} has no authority declared in this test"
        assert set(items) == AUTHORITY[title](), (
            f"{title}: the catalogue and the registry disagree — "
            f"catalogue-only {sorted(set(items) - AUTHORITY[title]())}, "
            f"registry-only {sorted(AUTHORITY[title]() - set(items))}")
        seen[title] = items
    assert set(seen) == set(AUTHORITY), \
        f"sections missing from the catalogue: {sorted(set(AUTHORITY) - set(seen))}"


def test_the_catalogue_reads_the_same_objects_the_validator_checks():
    """Same function/dict OBJECT, per docs/ENGINEERING.md. If blocks.py ever imported a copy, the catalogue
    could advertise a method validate.py rejects."""
    assert blocks.BMI_FORMULAS is validate.BMI_FORMULAS is clinical.BMI_FORMULAS
    assert blocks.BSA_FORMULAS is validate.BSA_FORMULAS is clinical.BSA_FORMULAS
    assert blocks.FOLLOWUP_FILTERS is validate.FOLLOWUP_FILTERS is clinical.FOLLOWUP_FILTERS
    assert blocks.DEATH_CONFLICT_POLICIES is validate.DEATH_CONFLICT_POLICIES
    assert blocks.MATCH_OPERATORS is codelists.MATCH_OPERATORS


def test_every_registered_name_actually_reaches_the_page():
    """A section whose names are collected but not rendered would read as an empty vocabulary."""
    rendered = blocks.render()
    for title, _key, _blurb, items in blocks.sections():
        for name in items:
            assert re.search(rf"^\s+{re.escape(name)}(\s|$)", rendered, re.M), \
                f"{title}: {name!r} is in the section but never printed"


def test_every_section_names_the_config_key_that_takes_it():
    """A list of valid names is not much use without the field that accepts them — that is the
    'which function do I enter' question this exists to answer."""
    for title, key, blurb, _items in blocks.sections():
        assert key.strip(), f"{title} does not say where it is configured"
        assert blurb.strip(), f"{title} does not say what it is"
        assert key in blocks.render(), f"{title}: the config key is not printed"


def test_an_empty_registry_is_an_error_not_a_silent_gap():
    """A vocabulary that has gone empty still prints its heading, and reads as 'the engine offers
    nothing here' rather than as a broken import."""
    assert blocks.errors() == [], f"live catalogue has empty section(s): {blocks.errors()}"

    real = blocks.sections
    try:
        blocks.sections = lambda: [("EMPTY", "config -> nowhere", "nothing", {})]
        assert blocks.errors(), "an empty vocabulary was reported as healthy"
    finally:
        blocks.sections = real
    assert blocks.errors() == [], "the monkeypatch leaked"


def test_the_catalogue_is_not_deployed_to_production():
    """It explains the runtime; it is not part of it."""
    import deploy_tree
    assert not any("blocks" in str(f) for f in deploy_tree.ROOT_FILES)


if __name__ == "__main__":
    fns = [v for k, v in sorted(globals().items()) if k.startswith("test_")]
    for fn in fns:
        fn()
        print(f"ok  {fn.__name__}")
    print(f"\n{len(fns)} tests passed")
