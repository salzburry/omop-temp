"""Flow buttons must explain incomplete prerequisites instead of running doomed writes."""
import hashlib
import json
from pathlib import Path
import sys
import tempfile
from unittest.mock import patch

import yaml

ROOT = Path(__file__).resolve().parents[2]
sys.path[:0] = [str(ROOT / "platform/tools"), str(ROOT / "experiments/portal")]
import flow_guidance as guidance

PACK = "products/oncology/example/202609"


def _action(aid="g1_digest", kind="write", argv=None):
    return {"id": aid, "kind": kind, "argv": argv if argv is not None else ["platform/tools/source_manifest.py", PACK, "--check"],
            "label": "Existing action", "note": "Existing requirement"}


def _fixture(root):
    product = root / PACK
    product.mkdir(parents=True)
    workbook = product / "prog_spec" / "spec.xlsx"
    workbook.parent.mkdir()
    workbook.write_bytes(b"test workbook bytes; the guard fingerprints rather than parses it")
    material = {"material_id": "program_spec", "material_type": "program_spec", "path_or_link": "prog_spec/spec.xlsx",
                "status": "pending", "why_provisional": "Awaiting source review", "ai_classification": "sponsor_ai_eligible",
                "classified_by": "Alice Smith", "classified_date": "2026-09-05"}
    _refs(product, [material])
    return product, workbook, material


def _refs(product, materials):
    (product / "source_refs.yaml").write_text(yaml.safe_dump({"source_materials": materials}), encoding="utf-8")


def _guard(root, action=None, **kwargs):
    return guidance.action_guard(root, PACK, action or _action(), local_demo=kwargs.get("local_demo", True), can_write=kwargs.get("can_write", True))


def _extraction(root, product, workbook):
    (root / "governance").mkdir(exist_ok=True)
    policy = root / "governance" / "ai_boundary.yaml"
    policy.write_text("markers: []\n", encoding="utf-8")
    out = product / "spec_pipeline" / "out"
    out.mkdir(parents=True, exist_ok=True)
    (product / "spec_pipeline" / "pipeline.conf").write_text("SPEC_SOURCE_ID=program_spec\n", encoding="utf-8")
    sources = [{"file": workbook.name, "sha256": guidance.sm.sha256(workbook)[:16]}]
    rows = [{"item_id": "cohort:1", "content_hash": "c" * 16}]
    parts = ["1.7", f'{sources[0]["file"]}={sources[0]["sha256"]}', "cohort:1=" + "c" * 16]
    doc = {"extraction": {"sources": sources, "target": workbook.relative_to(root).as_posix(), "extractor_version": "1.7",
                          "fingerprint": hashlib.sha256("\x1f".join(parts).encode()).hexdigest()[:16], "row_count": 1,
                          "redaction": {"policy_sha256": guidance.sm.sha256(policy), "cells_redacted": 0, "rows_redacted": 0}}, "rows": rows}
    target = out / "extracted.json"
    target.write_text(json.dumps(doc), encoding="utf-8")
    return target, doc


def _reviewed(material, workbook):
    material.update(status="reviewed", sha256=guidance.sm.sha256(workbook), document_id="SPEC-1", revision="1",
                    approved_by="Alice Smith", approval_date="2026-09-05", data_refresh="202609", rwb_qc_reference="QC-1")


def test_read_checks_do_not_require_write_permission_or_local_mode():
    with tempfile.TemporaryDirectory() as td:
        root = Path(td)
        _fixture(root)
        assert not _guard(root, _action(kind="read"), local_demo=False, can_write=False)
        assert "role" in _guard(root, can_write=False)
        assert "shared portal" in _guard(root, local_demo=False)
        assert "named reviewer" in _guard(root, _action(kind="person"))


def test_incomplete_commands_and_invalid_product_paths_cannot_execute():
    with tempfile.TemporaryDirectory() as td:
        root = Path(td)
        _fixture(root)
        for argv in ([], [""], "command", ["tool.py", None], ["tool.py", "<reviewer>"]):
            assert _guard(root, _action(kind="read", argv=argv)), argv
        for pack in ("../other", ".", "products/missing"):
            assert guidance.action_guard(root, pack, _action(kind="read"), local_demo=True, can_write=True)
        assert guidance.action_guard(root, PACK, None, local_demo=True, can_write=True)


def test_workbook_digest_requires_well_formed_authoritative_registration():
    with tempfile.TemporaryDirectory() as td:
        root = Path(td)
        product, workbook, material = _fixture(root)
        assert not _guard(root)
        before = (product / "source_refs.yaml").read_bytes()
        assert not _guard(root)
        assert (product / "source_refs.yaml").read_bytes() == before
        for materials in (None, {}, [], [None], [42], [material, material], [{**material, "material_id": []}],
                          [{**material, "material_type": "supporting"}]):
            _refs(product, materials)
            assert _guard(root), materials
        (product / "source_refs.yaml").write_text("bad: [yaml", encoding="utf-8")
        assert _guard(root)
        (product / "source_refs.yaml").unlink()
        assert _guard(root)


def test_missing_remote_placeholder_or_directory_workbook_gives_a_prerequisite():
    with tempfile.TemporaryDirectory() as td:
        root = Path(td)
        product, workbook, material = _fixture(root)
        for location in ("TBD", "https://example.test/spec.xlsx", "prog_spec", "missing.xlsx", ["bad"]):
            _refs(product, [{**material, "path_or_link": location}])
            assert _guard(root), location


def test_repeat_or_stale_digest_is_not_presented_as_a_fresh_runnable_action():
    with tempfile.TemporaryDirectory() as td:
        root = Path(td)
        product, workbook, material = _fixture(root)
        material["sha256"] = guidance.sm.sha256(workbook)
        _refs(product, [material])
        assert "already" in _guard(root)
        workbook.write_bytes(b"revised specification")
        assert "changed" in _guard(root)


def test_pending_mock_specification_cannot_be_sealed_even_with_a_valid_digest():
    with tempfile.TemporaryDirectory() as td:
        root = Path(td)
        product, workbook, material = _fixture(root)
        assert "checksum" in _guard(root, _action("g1_seal"))
        material["sha256"] = guidance.sm.sha256(workbook)
        _refs(product, [material])
        with patch.object(guidance.sm, "check", return_value=[]) as check:
            assert "awaiting review" in _guard(root, _action("g1_seal"))
        check.assert_not_called()


def test_seal_requires_complete_review_and_passes_through_backend_refusals():
    with tempfile.TemporaryDirectory() as td:
        root = Path(td)
        product, workbook, material = _fixture(root)
        _reviewed(material, workbook)
        for field in guidance.sm.APPROVAL_FIELDS + guidance.sm.POLICY_FIELDS:
            _refs(product, [{key: value for key, value in material.items() if key != field}])
            assert _guard(root, _action("g1_seal")), field
        _refs(product, [material])
        with patch.object(guidance.sm, "check", return_value=["approval date is invalid"]):
            assert "approval date is invalid" in _guard(root, _action("g1_seal"))
        with patch.object(guidance.sm, "check", return_value=["record moved past its ledger", "object holds no lifecycle event"]):
            assert not _guard(root, _action("g1_seal"))
        with patch.object(guidance.sm, "check", side_effect=ValueError("bad record")):
            assert "could not finish" in _guard(root, _action("g1_seal"))
        material["classified_by"] = "TODO"
        _refs(product, [material])
        with patch.object(guidance.sm, "check", return_value=[]) as check:
            assert _guard(root, _action("g1_seal"))
        check.assert_not_called()


def test_extraction_registration_requires_current_artifact_and_pipeline_source():
    with tempfile.TemporaryDirectory() as td:
        root = Path(td)
        product, workbook, material = _fixture(root)
        action = _action("g1_register_extraction")
        assert "extraction first" in _guard(root, action)
        target, doc = _extraction(root, product, workbook)
        before = (product / "source_refs.yaml").read_bytes(), target.read_bytes()
        assert not _guard(root, action)
        assert before == ((product / "source_refs.yaml").read_bytes(), target.read_bytes())
        (product / "spec_pipeline" / "pipeline.conf").write_text("SPEC_SOURCE_ID=other\n", encoding="utf-8")
        assert "registered input" in _guard(root, action)
        _refs(product, [material, {"material_id": "sanitized", "material_type": "ai_extraction"}])
        assert "already registered" in _guard(root, action)


def test_malformed_extractions_are_friendly_refusals_instead_of_tracebacks():
    with tempfile.TemporaryDirectory() as td:
        root = Path(td)
        product, workbook, material = _fixture(root)
        target, original = _extraction(root, product, workbook)
        action = _action("g1_register_extraction")
        for value in ([], None, 42, {}, {"extraction": [], "rows": []}, {"extraction": {}, "rows": []}):
            target.write_text(json.dumps(value), encoding="utf-8")
            assert _guard(root, action), value
        for key, value in (("redaction", []), ("sources", [None]), ("fingerprint", 42), ("row_count", True)):
            doc = json.loads(json.dumps(original))
            doc["extraction"][key] = value
            target.write_text(json.dumps(doc), encoding="utf-8")
            assert _guard(root, action), key
        target.write_text("invalid json", encoding="utf-8")
        assert "unreadable" in _guard(root, action)


def test_extraction_registration_refuses_changed_source_rows_or_redaction_policy():
    with tempfile.TemporaryDirectory() as td:
        root = Path(td)
        product, workbook, material = _fixture(root)
        target, doc = _extraction(root, product, workbook)
        action = _action("g1_register_extraction")
        doc["rows"][0]["content_hash"] = "different"
        target.write_text(json.dumps(doc), encoding="utf-8")
        assert "metadata" in _guard(root, action)
        target, doc = _extraction(root, product, workbook)
        (root / "governance" / "ai_boundary.yaml").write_text("markers: [new-policy]\n", encoding="utf-8")
        assert "policy" in _guard(root, action)
        target, doc = _extraction(root, product, workbook)
        material["path_or_link"] = "prog_spec/next.xlsx"
        (product / "prog_spec" / "next.xlsx").write_bytes(b"next source")
        _refs(product, [material])
        assert "selected source has changed" in _guard(root, action)
        material["path_or_link"] = "prog_spec/spec.xlsx"
        _refs(product, [material])
        workbook.write_bytes(b"edited workbook")
        assert "input files have changed" in _guard(root, action)


def test_known_copy_explains_human_decisions_and_unknown_copy_routes_to_details():
    for aid in ("g1_workbook", "g1_review", "g1_commit", "g1_digest", "g1_seal", "g1_register_extraction"):
        result = guidance.issue_copy(_action(aid))
        assert set(result) == {"title", "summary", "steps"}
        assert result["title"] and result["summary"] and len(result["steps"]) >= 2
    result = guidance.issue_copy(_action("future", "person"), "Exact unresolved scientific requirement")
    assert result["title"] == "Review the next requirement"
    assert "technical handoff" in result["summary"]
    assert "named reviewer" in result["steps"][0]
    assert "pending" in guidance.issue_copy(_action("g1_register_extraction"))["steps"][-1]


def test_existing_extractions_use_workbook_and_directory_conventions_read_only():
    for pack in ("fixtures/oncology/gist/202608", "fixtures/oncology/prostate/202606", "fixtures/oncology/oc/202606"):
        product = ROOT / pack
        spec, materials, reason = guidance._registered_spec(str(product))
        assert not reason and spec
        # Real extractions catch schema and filename assumptions missed by tiny fixtures.
        # Existing registration correctly requires review rather than an overwrite.
        materials = [material for material in materials if material.get("material_type") != guidance.sm.AI_EXTRACTION]
        assert not guidance._extraction_reason(ROOT, product, materials), pack


def test_recorded_review_copy_is_a_correction_and_the_workbook_step_names_no_path():
    recorded = guidance.issue_copy({"id": "g1_review", "kind": "person", "recorded": True})
    assert recorded["title"] == "Correct the recorded review" and "until it is signed" in recorded["summary"], recorded
    assert any("stands as typed" in step for step in recorded["steps"])
    first = guidance.issue_copy({"id": "g1_review", "kind": "person"})
    assert first["title"] == "Complete the specification details and review" and first["title"] != recorded["title"]
    workbook = guidance.issue_copy({"id": "g1_workbook", "kind": "person", "path": f"{PACK}/source_refs.yaml"})
    assert "/" not in " ".join(workbook["steps"]) and "specification folder" in workbook["steps"][1], workbook["steps"]
    assert "source register" in workbook["steps"][1]
    # every canned sentence is plain: no path, flag, file name, dash or arrow
    for copy_id, (title, summary, steps) in guidance._COPY.items():
        for text in (title, summary, *steps):
            assert not guidance.technical_tokens(text), (copy_id, text)


def test_blocker_copy_never_invents_a_name_or_a_state():
    """The sentence is chosen by the words the finding carries; the who, the counts and the states
    are the finding's own, and a finding with none of them gets no name."""
    said = guidance.blocker_copy("Gate 1: x/source_refs.yaml: classified_by=Asha Rao is not authenticated — no commit's diff wrote this")
    assert said.startswith("Asha Rao's classification has not been signed yet.")
    assert "Asha Rao" not in guidance.blocker_copy("Gate 1: source is provisional, not approved")
    assert guidance.blocker_copy("Gate 4: configuration is not_started, not approved") == "The build configuration is not started, not approved yet."
    assert guidance.blocker_copy("Gate 4: configuration is somewhere_else, not approved") == "The build configuration is somewhere else, not approved yet."
    assert guidance.blocker_copy("Gate 5 is in progress — a release approves a VALIDATED build") == "Validation is in progress; a release needs a validated build."
    for line in ("x: material 'program_spec': has moved past its ledger", "x: material 'program_spec': holds no lifecycle event",
                 "Gate 1: x: source_refs.yaml is not readable YAML (while parsing)", "evidence route undecided: x matches no registry entry",
                 "Gate 1: x: source_materials[1]: requires `classified_by` — ...", "x: x/CONFIGURATION_APPROVAL.yaml: the configuration was edited after the approval",
                 "x: configuration:approved but qc.source_thresholds.linkage rules NOTHING", "answer the open decisions (3 open) — run `decision_packet.py x`"):
        said = guidance.blocker_copy(line)
        assert said and not guidance.technical_tokens(said), (line, said)


if __name__ == "__main__":
    for name, fn in sorted(list(globals().items())):
        if name.startswith("test_") and callable(fn):
            fn()
            print(f"ok {name}")
