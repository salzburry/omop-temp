"""Regressions for the SIXTH external audit of 2026-09-03 (main @ a35d043). Each fails on the
defect it names and passes on the fix.

  P1  a writer-produced release manifest failed the published JSON Schema (run_mode object,
      tree_sha256, candidate_identity); the mirror test compared names with a digit-blind regex
  P1  the benchmark's "hard" budget cap reserved a MEAN estimate: a $5 call ran under a $0.01 cap;
      nan disabled the comparison; a refused effort silently became the default configuration
  P1  a real resume recorded `resumed_from`, the portal looked for `human_answer`; the answer was
      not persisted, the evidence was dropped, and the run stayed resumable forever
  P1  the portal minted an admin when users.json was absent and let the visitor pick who they are;
      escalations and packets ignored the selected pack
  P1  prod accepted any dbfs:/ path as an "approved root" and skipped the deployed-tree check
      outside a recognised working directory
  P2  malformed-but-valid JSON crashed portal tabs; the embedding index served another checkout's
      rows; "latest" pooled sweeps; validate_manifest threw on bad shapes; composed names
      exceeded the limit they are later held to; specialist filenames collided; the model
      constructor skipped registry/effort validation; Windows CI ran without UTF-8; two trainers
      wrote two artifacts under different rules and claimed a consumer that does not exist
  P2  documents: run-time --var commands, "same ADS" claims, one vendor-data rule stated twice,
      "only the Agent tab invokes a model", a current-state assessment presented as current,
      "zero rows closed", Domino as the hosted window, REPORT.md as CI-checked

NO PYTEST FIXTURES AND NO `parametrize` — CI runs every suite as a script.
"""
import copy
import json
import os
import re
import sys
import tempfile
from pathlib import Path

FRAMEWORK = Path(__file__).resolve().parent.parent
ROOT = FRAMEWORK.parent
AGENT = ROOT / "experiments" / "agent"
PORTAL = ROOT / "experiments" / "portal"
sys.path.insert(0, str(FRAMEWORK))
sys.path.insert(0, str(AGENT))
sys.path.insert(0, str(AGENT / "bench"))
sys.path.insert(0, str(AGENT / "evals"))
sys.path.insert(0, str(AGENT / "ml"))
sys.path.insert(0, str(PORTAL))
os.environ.setdefault("ANTHROPIC_API_KEY", "not-a-key-tests-never-call")

from engine.config import load_config, product_config  # noqa: E402
from engine import refresh, release, validate  # noqa: E402

CONFIG = product_config(ROOT / "fixtures", "prostate")
CI = (ROOT / ".github" / "workflows" / "rwdp-ci.yml").read_text(encoding="utf-8")


def _read(p):
    return (ROOT / p).read_text(encoding="utf-8")


# ------------------------------------------------------------------ P1 manifest <-> schema

def test_a_writer_produced_manifest_validates_against_the_release_schema():
    cfg = load_config(CONFIG)
    m = refresh.build_manifest(cfg, tumor="prostate", family="oncology", git_commit="abc1234",
                               counts={"n": 1}, qc={"passed": True},
                               run_mode={"env": "prod", "release_grade": True},
                               tree_sha256="a" * 64, config_identity={"config_bundle_sha256": "b" * 64},
                               runtime={"dbr": "15.4"}, content={"digest": "c" * 64})
    m["candidate_identity"] = release.candidate_identity([
        {"table_name": "out.ads__staging__b1", "table_id": "t", "location": "l",
         "table_format": "delta", "delta_version": 3, "row_count": 10, "num_files": 1, "size_bytes": 5}])
    schema = json.loads(_read("governance/schemas/release.schema.json"))
    props = schema["properties"]
    assert props["run_mode"].get("type") == "object", props["run_mode"]
    assert "tree_sha256" in props and "candidate_identity" in props
    extra = set(m) - set(props)
    assert not extra, f"the writer emits fields the schema forbids: {sorted(extra)}"
    try:
        import jsonschema  # noqa: PLC0415
    except ImportError:
        return  # the structural assertions above already ran
    jsonschema.validate(m, schema)


def test_the_mirror_test_reads_digits_in_field_names():
    src = _read("platform/tests/test_audit4_20260902.py")
    assert '"([a-z_]+)"' not in src, "a digit-blind regex never saw tree_sha256"


# ------------------------------------------------------------------ P1 budget

class _Spender:
    """A fake model that costs $5 per call and always answers `done`."""
    model = "fake"

    def __init__(self):
        self.usage = {"calls": 0, "input_tokens": 0, "output_tokens": 0}

    def step(self, system, transcript):
        import orchestrator as orc  # noqa: PLC0415
        acc = orc._RUN_USAGE.get()
        acc["calls"] += 1
        acc["cost_usd"] += 5.0
        self.usage["calls"] += 1
        return json.dumps({"action": "done", "summary": "made up"})


def _in_tmp_runs(fn):
    import state as st_mod  # noqa: PLC0415
    saved = st_mod.RUNS
    with tempfile.TemporaryDirectory() as d:
        st_mod.RUNS = d
        try:
            return fn(d)
        finally:
            st_mod.RUNS = saved


def test_a_run_stops_when_its_own_cost_crosses_the_ceiling():
    import orchestrator as orc  # noqa: PLC0415

    def go(d):
        st = orc.run("goal", model=_Spender(), cost_ceiling=0.01)
        assert st.outcome["status"] == "budget_exhausted", st.outcome
        assert st.metrics["total_calls"] == 1, "the overshoot bound is ONE call"
        return st
    _in_tmp_runs(go)


def test_the_matrix_records_a_spent_row_as_partial_and_validates_its_controls():
    import run_bench as rb  # noqa: PLC0415
    case = {"id": "x", "goal": "g", "expect": {"outcome": "done"}}
    cfg = {"model": "claude-sonnet-5", "effort": "low", "temperature": None}
    saved = rb.per_run_estimate, rb.RESULTS

    def go(d):
        rb.per_run_estimate = lambda c: 0.001
        rb.RESULTS = os.path.join(d, "r.jsonl")
        rows, spent, stopped = rb.execute([case], [cfg], 1, 0.01, model_factory=lambda **kw: _Spender())
        assert stopped and spent >= 5.0, (spent, stopped)
        assert rows[0]["outcome"] == "budget_exhausted" and rows[0]["partial"] is True, rows[0]
        for bad in (float("nan"), float("inf"), 0.0, -1.0):
            try:
                rb.execute([case], [cfg], 1, bad, model_factory=lambda **kw: _Spender())
            except ValueError:
                pass
            else:
                raise AssertionError(f"budget {bad!r} accepted")
        for args in (([case], [cfg], 0), ([], [cfg], 1), ([case], [], 1)):
            try:
                rb.execute(*args, 1.0, model_factory=lambda **kw: _Spender())
            except ValueError:
                pass
            else:
                raise AssertionError(f"{args!r} accepted")
    try:
        _in_tmp_runs(go)
    finally:
        rb.per_run_estimate, rb.RESULTS = saved


class _Slow:
    """A fake model whose every call takes a beat — the wall-clock cap is tested without a key."""
    model = "fake"

    def __init__(self):
        self.usage = {"calls": 0, "input_tokens": 0, "output_tokens": 0}

    def step(self, system, transcript):
        import time  # noqa: PLC0415
        time.sleep(0.3)
        self.usage["calls"] += 1
        return json.dumps({"action": "tool", "tool": "packs", "args": {"query": "prostate"}, "why": "x"})


def test_a_run_stops_at_its_wall_clock_cap_and_existence_is_a_registry_read():
    import orchestrator as orc  # noqa: PLC0415
    import tools  # noqa: PLC0415

    def go(d):
        st = orc.run("goal", model=_Slow(), max_seconds=0.2)
        assert st.outcome["status"] == "time_budget_exhausted", st.outcome
        assert sum(1 for s in st.steps if s["kind"] == "decision") == 1, "the overshoot is one step"
    _in_tmp_runs(go)
    out = tools.call("packs", {"query": "190001"})           # a cut no pack can carry: a real 202609 exists once someone stands one up
    assert "no pack matches '190001'" in out and "fixtures/oncology/prostate/202606" in out
    assert "packs" in tools.registry() and "packs" in tools.describe()
    src = _read("experiments/agent/tools.py")
    assert 'os.environ.get("RWD_TOOL_TIMEOUT_S", "300")' in src and "TIMEOUT:" in src
    app = _read("experiments/portal/app.py")
    assert "RWD_PORTAL_MAX_SECONDS" in app and 'max_seconds=_caps["seconds"]' in app
    assert 'os.environ.setdefault("RWD_TOOL_TIMEOUT_S", "90")' in app
    assert "STALE" in app and "tools.use_snapshot(_snapshot_fallback" in app, "a structurally valid older snapshot is labelled"
    assert "tools.use_snapshot(None)" in app, "malformed snapshot content must clear the agent's prior context"
    # the reply is saved to the history and the page re-rendered, so a fresh input box follows
    # every answer (the page offered no way to ask the next question, operator 2026-09-03)
    i = app.index('"path": result.path, "status": result.outcome["status"]')
    assert "st.rerun()" in app[i:i + 1800], "the Agent tab must rerun after saving the reply"
    # what the agent remembers is a deterministic memo from tool OUTPUTS, capped and shown —
    # never a model's summary of its own conversation
    assert "MEMO_LINES, MEMO_LINE = 12, 160" in app and "st.session_state.memo" in app
    assert 'if s_["kind"] == "observation":' in app[i:i + 1800], "facts come from observations"
    assert "from tool outputs, " in app and "What the agent remembers" in app
    # ONE section renders per interaction (tabs executed all eight on every click), the steps
    # stream into the working box as they are recorded, and the queue scans are cached briefly
    # One section runs per interaction; the scientist's workspace navigation is in the sidebar.
    assert "st.tabs(" not in app and 'st.sidebar.radio("Workspace", _offered_sections' in app
    import ast
    tree = ast.parse(app)
    sections = next(ast.literal_eval(node.value) for node in tree.body if isinstance(node, ast.Assign)
                    and any(isinstance(target, ast.Name) and target.id == "SECTIONS" for target in node.targets))
    routed = {node.comparators[0].value for node in ast.walk(tree)
              if isinstance(node, ast.Compare) and isinstance(node.left, ast.Name) and node.left.id == "section"
              and len(node.ops) == 1 and isinstance(node.ops[0], ast.Eq)
              and isinstance(node.comparators[0], ast.Constant)}
    assert len(sections) == len(set(sections)) and set(sections) <= routed
    assert {"Plan changes", "Studies", "New product", "Flow", "Agent"} <= set(sections)
    # the steps still stream: the governed loop reports them to a background job the page polls
    assert "jobs.start(" in app and "_show(s_)" in app and "@st.cache_data(ttl=20" in app and "_esc_rows.clear()" in app


def test_the_orchestrator_reports_each_step_as_it_is_recorded():
    import orchestrator as orc  # noqa: PLC0415
    seen = []

    def go(d):
        st = orc.run("goal", model=_Scripted([json.dumps({"action": "tool", "tool": "packs",
                                                          "args": {"query": "prostate"}, "why": "x"}),
                                              json.dumps({"action": "done", "summary": "ok"})]),
                     on_step=lambda s: seen.append(s["kind"]))
        assert st.outcome["status"] == "done"
        assert seen == [s["kind"] for s in st.steps] and "observation" in seen, seen
        boom = orc.run("goal", model=_Scripted([json.dumps({"action": "done", "summary": "again"})]),
                       on_step=lambda s: 1 / 0)
        assert boom.outcome is not None, "a display callback that raises never breaks the run"
    _in_tmp_runs(go)


def test_a_refused_effort_or_temperature_never_becomes_a_default_configuration():
    import run_bench as rb  # noqa: PLC0415
    out, refused = rb.configs(["claude-sonnet-5"], ["turbo"], [None])
    assert out == [] and refused, (out, refused)
    out, refused = rb.configs(["claude-haiku-4-5"], ["low"], [1.7])
    assert out == [] and len(refused) == 2, (out, refused)
    src = _read("experiments/agent/bench/run_bench.py")
    assert "hard cap" not in src.lower() and "the budget cap is the guarantee" not in src
    assert "one model call" in src, "the overshoot bound is stated"


# ------------------------------------------------------------------ P1 escalation answers

class _Scripted:
    model = "fake"

    def __init__(self, replies):
        self.replies = list(replies)
        self.usage = {"calls": 0, "input_tokens": 0, "output_tokens": 0}

    def step(self, system, transcript):
        self.usage["calls"] += 1
        return self.replies.pop(0) if self.replies else json.dumps({"action": "done", "summary": "again"})


def test_a_resume_persists_the_answer_closes_the_escalation_and_refuses_a_second_resume():
    import orchestrator as orc  # noqa: PLC0415
    import queues  # noqa: PLC0415

    def go(d):
        esc = json.dumps({"action": "escalate", "to": "Science", "question": "q?", "evidence": "ev"})
        first = orc.run("goal about fixtures/oncology/prostate/202606", model=_Scripted([esc]))
        assert json.loads(first.outcome["summary"])["evidence"] == "ev", "evidence is kept"
        tool = json.dumps({"action": "tool", "tool": "definition", "args": {"term": "TSST"}, "why": "x"})
        second = orc.resume_run(first.run_id, "the answer", "alex",
                                model=_Scripted([tool, json.dumps({"action": "done", "summary": "ok"})]))
        ans = [s for s in second.steps if s["kind"] == "human_answer"]
        assert ans and ans[0]["answers_run"] == first.run_id and ans[0]["by"] == "alex" \
            and ans[0]["answer"] == "the answer" and ans[0]["question"] == "q?", second.steps[:2]
        orig = json.load(open(os.path.join(d, f"{first.run_id}.json"), encoding="utf-8"))
        assert any(s["kind"] == "answered" and s["by"] == "alex" and s["run"] == second.run_id
                   for s in orig["steps"]), "the original run records that it was answered"
        rows = queues.escalations(d)
        assert len(rows) == 1 and rows[0]["answered"] is True and rows[0]["answered_by"] == "alex", rows
        try:
            orc.resume_run(first.run_id, "another", "someone", model=_Scripted([tool]))
        except SystemExit as e:
            assert "already answered" in str(e), e
        else:
            raise AssertionError("a second resume of an answered run must be refused")
        third = orc.resume_run(first.run_id, "another", "someone", model=_Scripted([tool]), allow_branch=True)
        assert any(s["kind"] == "human_answer" and s.get("branches_from") == second.run_id
                   for s in third.steps), "an explicit branch names the run it diverges from"
    _in_tmp_runs(go)


# ------------------------------------------------------------------ P1 portal identity and scope

def test_identity_fails_closed_outside_local_demo_and_binds_to_the_forwarded_principal():
    import identity  # noqa: PLC0415
    roster = [{"name": "ana", "role": "reviewer", "email": "ana@example.org"}]
    actor, why = identity.resolve({}, roster, local_demo=False)
    assert actor is None and "RWD_PORTAL_LOCAL_DEMO" in why, why
    actor, why = identity.resolve({"X-Forwarded-Email": "ANA@example.org"}, roster, local_demo=False)
    assert actor and actor["name"] == "ana", (actor, why)
    actor, why = identity.resolve({"X-Forwarded-Email": "bob@example.org"}, roster, local_demo=False)
    assert actor is None and "not in users.json" in why, why
    actor, why = identity.resolve({"X-Forwarded-Email": "ana@example.org"}, [], local_demo=False)
    assert actor is None, "an empty roster grants nothing"
    actor, why = identity.resolve({}, roster, local_demo=True, chosen="ana")
    assert actor and "DEMO" in why
    assert identity.default_users(local_demo=False) == []
    assert identity.default_users(local_demo=True)[0]["role"] == "admin"
    src = _read("experiments/portal/app.py")
    assert "identity.resolve(" in src and 'return [{"name": "admin", "role": "admin"}]' not in src


def _run(d, rid, status, summary, goal="goal", extra_steps=()):
    steps = extra_steps if isinstance(extra_steps, int) else list(extra_steps)   # int = malformed on purpose
    json.dump({"run_id": rid, "goal": goal, "actor": None, "steps": steps,
               "outcome": {"status": status, "summary": summary}},
              open(os.path.join(d, f"{rid}.json"), "w", encoding="utf-8"))


def test_queues_scope_to_the_selected_pack_and_quarantine_malformed_records():
    import queues  # noqa: PLC0415
    P = "fixtures/oncology/prostate/202606"
    with tempfile.TemporaryDirectory() as runs, tempfile.TemporaryDirectory() as cands:
        _run(runs, "20260901-1000", "escalated", json.dumps({"to": "Science", "question": "q1"}), goal=f"do {P}")
        _run(runs, "20260901-1100", "escalated", json.dumps({"to": "Science", "question": "q2"}), goal="global")
        _run(runs, "20260901-1200", "escalated", json.dumps({"to": "Science", "question": "q3"}),
             goal=f"do {P}", extra_steps=7)                                  # numeric steps
        assert [r["run_id"] for r in queues.escalations(runs, pack=P)] == ["20260901-1000"]
        assert len(queues.escalations(runs)) == 2
        assert queues.quarantined(runs), "the malformed record is reported, not raised"
        json.dump({"kind": "diagnosis", "pack": None, "generated_at": "2026-09-02T10:00:00",
                   "critic": "falsified=False", "decision": "HUMAN"},
                  open(os.path.join(cands, "a.json"), "w", encoding="utf-8"))     # string critic
        json.dump({"kind": "code_candidate", "pack": P, "generated_at": "2026-09-02T11:00:00",
                   "critic": {"falsified": False, "route": "pass_on"}, "decision": "HUMAN"},
                  open(os.path.join(cands, "b.json"), "w", encoding="utf-8"))
        assert [r["file"] for r in queues.packets(cands, P)] == ["b.json"], "packless packets do not appear under a pack"
        assert len(queues.packets(cands)) == 2
        c = queues.queue_counts("", runs, cands, P)
        assert c["escalations_open"] == 1 and c["packets"] == 1, c


# ------------------------------------------------------------------ P1 deployment authority

def test_prod_binds_to_a_canonical_uc_volume_and_refuses_to_run_outside_a_deployed_tree():
    src = _read("platform/databricks/run_rwdp.py")
    assert '"dbfs:/")' not in src, "a bare dbfs:/ path is not an approved root"
    assert "_VOLUME_RE" in src and "/Volumes/" in src
    assert "prod runs only from a deployed workspace tree" in src
    assert "approved root" not in src.lower() or "canonical" in src.lower()
    i = src.index("prod runs only from a deployed workspace tree")
    assert i < src.index("sys.path.insert(0, framework_root)"), "the refusal precedes the import"


# ------------------------------------------------------------------ P2 code

def test_the_embedding_index_refuses_another_checkouts_rows():
    import embed  # noqa: PLC0415
    import tools  # noqa: PLC0415
    saved = embed.INDEX
    with tempfile.TemporaryDirectory() as d:
        embed.INDEX = os.path.join(d, "idx.jsonl")
        token = "zqxjv-foreign-checkout-token"
        with open(embed.INDEX, "w", encoding="utf-8") as fh:
            fh.write(json.dumps({"kind": "decision", "source": "x", "text": token,
                                 "v": embed.vec(token), "algo": embed.ALGO}) + "\n")
        try:
            try:
                embed.query(token)
            except RuntimeError as e:
                assert "checkout" in str(e) or "source" in str(e), e
            else:
                raise AssertionError("an index with no provenance stamp must be refused")
            out = tools.call("semantic_search", {"query": token})
            hits = [l for l in out.splitlines() if l.startswith("[")]        # result lines, not the echoed query
            assert hits and not any(token in l for l in hits), "the tool rebuilt the index and the foreign row is gone"
            first = open(embed.INDEX, encoding="utf-8").readline()
            assert json.loads(first).get("meta") and "sources_sha" in first, "the rebuilt index carries its provenance"
        finally:
            embed.INDEX = saved


def test_latest_report_is_exactly_the_latest_sweep():
    import run_bench as rb  # noqa: PLC0415
    saved = rb.RESULTS, rb.REPORT
    with tempfile.TemporaryDirectory() as d:
        rb.RESULTS, rb.REPORT = os.path.join(d, "r.jsonl"), os.path.join(d, "REPORT.md")
        row = {"code": "abc", "corpus_registry_sha": "s", "degrade": False, "provenance": "human",
               "config": {"model": "claude-sonnet-5", "effort": "low", "temperature": None},
               "passed": True, "checks": {}, "error": None, "outcome": "done", "latency_s": 1,
               "expect_outcome": "done", "cost_usd": 0.01, "in_tok": 1, "out_tok": 1, "repeat": 0}
        with open(rb.RESULTS, "w", encoding="utf-8") as fh:
            for sweep, case in (("20260901-000000", "a"), ("20260901-000000", "b"), ("20260902-000000", "a")):
                fh.write(json.dumps({**row, "sweep": sweep, "case": case}) + "\n")
        try:
            rb.report()
            text = open(rb.REPORT, encoding="utf-8").read()
            assert "Scope: sweep 20260902-000000" in text and "Rows: 1 real" in text, text[:400]
        finally:
            rb.RESULTS, rb.REPORT = saved


def test_validate_manifest_returns_findings_on_malformed_shapes():
    assert any("not a mapping" in p for p in refresh.validate_manifest([1]))
    bad = {"tumor": "p", "refresh": "r", "spec_version": "202606", "built_at": "x", "status": "released",
           "counts": 1, "sign_off": 3, "source_lineage": 2, "release": 5, "content": "x", "qc": 1,
           "tfl_promotion": 2, "deliverables": 7, "golden": [], "source_qc_gate": "no"}
    probs = refresh.validate_manifest(bad)
    for k in ("counts", "sign_off", "source_lineage", "release", "content", "qc", "deliverables"):
        assert any(k in p and "must be a" in p for p in probs), (k, probs)


def test_composed_names_are_held_to_the_limit_where_they_are_composed():
    try:
        release.versioned_tfl("s." + "t" * 64, "r" * 64, "b" * 64, "i" * 64)
    except ValueError as e:
        assert "255" in str(e)
    else:
        raise AssertionError("a 266-character component composed without complaint")
    cfg = copy.deepcopy(load_config(CONFIG))
    cfg.run["output_table"] = "t" * 64
    cfg.run["refresh"] = "r" * 64
    probs = validate.problems(cfg, strict=True)
    assert any("255" in p and "output_table" in p for p in probs), probs


def test_specialist_candidate_files_neither_collide_nor_nest():
    import state  # noqa: PLC0415
    a, b = state.candidate_file("code", "PFS/OS"), state.candidate_file("code", "PFS/OS")
    assert a != b and os.path.dirname(a) == os.path.realpath(os.path.join(AGENT, "candidates"))
    assert re.fullmatch(r"code_PFS_OS_[0-9]{8}-[0-9]{6}-[0-9]{6}-[0-9a-f]{4}\.json", os.path.basename(a)), a
    for f in ("source_intel.py", "coding_agent.py", "validation_agent.py"):
        assert "candidate_file(" in (AGENT / f).read_text(encoding="utf-8"), f


def test_the_model_constructor_validates_model_and_effort_before_any_client():
    import orchestrator as orc  # noqa: PLC0415
    for kw in ({"model": "not-a-model"}, {"model": "claude-sonnet-5", "effort": "turbo"},
               {"model": "claude-haiku-4-5", "effort": "high"}):
        try:
            orc.AnthropicModel(**kw)
        except ValueError as e:
            assert "REFUSED" in str(e), e
        else:
            raise AssertionError(f"{kw} accepted")


def test_windows_ci_runs_in_utf8_mode():
    job = CI[CI.index("\n  windows:"):]
    nxt = re.search(r"\n  [a-z][a-z0-9_-]*:", job[12:])            # the next job key, same indent
    job = job[:nxt.start() + 12] if nxt else job
    assert "PYTHONUTF8" in job, "the Windows lane inherited cp1252 and a child's em dash broke a reader"
    assert "reconfigure(encoding=\"utf-8\"" in _read("platform/tests/test_contract_lint.py")


def test_one_trainer_one_artifact_one_rule_and_no_phantom_consumer():
    for f in ("router.py", "escalation_net.py"):
        src = (AGENT / "ml" / f).read_text(encoding="utf-8")
        assert "router_model.json" not in src and "escalation_model.json" not in src, f
        assert "train_all.py" in src, f"{f}'s real-data training must defer to the one trainer"
    ta = (AGENT / "ml" / "train_all.py").read_text(encoding="utf-8")
    assert "ml_advice" not in ta, "no runtime consumer reads router.json; do not name one"
    readme = (AGENT / "ml" / "README.md").read_text(encoding="utf-8")
    assert "not consumed at runtime" in readme.lower()


# ------------------------------------------------------------------ P2 documents

def test_no_document_runs_a_bundle_job_with_var():
    for p in ("fixtures/oncology/prostate/README.md", "fixtures/oncology/prostate/202606/DEV_SMOKE.md",
              "products/OPERATIONS.md", "products/registry.yaml", "refreshes/README.md"):
        lines = _read(p).splitlines()
        for i, l in enumerate(lines):
            if "bundle run" in l:
                block, j = l, i                       # the command and its backslash-continued lines
                while block.rstrip().endswith("\\") and j + 1 < len(lines):
                    j += 1
                    block += " " + lines[j]
                assert "--var" not in block, f"{p}:{i + 1} runs a job with --var (variables bind at deploy)"


def test_no_document_claims_the_r_engine_builds_the_same_ads():
    for p in ("platform/README.md", "products/OPERATIONS.md", "refreshes/README.md"):
        t = _read(p)
        for phrase in ("same ADS out", "builds the same ADS", "rebuild the same ADS"):
            assert phrase not in t, (p, phrase)


def test_the_vendor_data_rule_is_stated_once_with_its_two_exceptions():
    t = _read("governance/WORKFLOW.md")
    i = t.index("## 11. The rules that do not bend")
    rule5 = t[i:].split("\n6. ")[0]
    assert "ai_extraction" in rule5 and "ai_mapping_evidence" in rule5, "rule 5 must name its two exceptions"


def test_the_portal_names_both_places_a_model_is_invoked():
    src = _read("experiments/portal/app.py")
    head = src[:src.index('"""', 3)]
    assert "Resume" in head and "every tab except Agent" not in head
    # ...and both are BOUNDED: a goal naming a version that does not exist spun for ten minutes
    # under disk load with nothing to stop it (operator, 2026-09-03)
    assert "RWD_PORTAL_MAX_STEPS" in src and "RWD_PORTAL_RUN_CEILING_USD" in src
    assert 'cost_ceiling=_caps["usd"]' in src and 'max_steps=_caps["steps"]' in src
    assert 'resume_run(row["run_id"], ans.strip(), ACTOR["name"], max_steps=' in src
    assert "Start-RwdPortal.cmd" in head and "RWD_PORTAL_LOCAL_WORKSPACE=1" in head
    assert "server.address=127.0.0.1" in head, "local-workspace launch instructions bind the local listener"


def test_the_benchmark_doc_marks_its_assessment_historical_and_the_matrix_its_closed_rows():
    b = _read("docs/AGENTIC_BENCHMARK.md")
    h = b[b.index("## Current-state assessment"):]
    assert "HISTORICAL" in h[:400], "the 2a84679 assessment is no longer the current state"
    x = _read("docs/EXPRESSIBILITY_MATRIX.md")
    assert "Zero of the 44 rows is closed by anything in the tree" not in x
    assert "recorded closed in the inventory" in x


def test_domino_is_not_the_hosted_window_and_report_md_is_not_ci_checked():
    pr = _read("docs/PRODUCTION_READINESS.md")
    assert "Domino app deploy" not in pr and "| Domino |" not in pr
    cj = _read("docs/CHAT_JOURNEY.md")
    assert "A Domino deployment serves" not in cj
    r = _read("docs/README.md")
    sec = r[r.index("## 2. Generated"):r.index("## 3.")]
    assert "REPORT.md" not in sec, "REPORT.md depends on ignored run data and is not CI-checked"


if __name__ == "__main__":
    fails = 0
    for name, fn in sorted(globals().items()):
        if name.startswith("test_") and callable(fn):
            try:
                fn()
                print(f"  ok   {name}")
            except Exception as e:  # noqa: BLE001
                fails += 1
                print(f"  FAIL {name}: {e}")
    print(f"{fails} failure(s)")
    sys.exit(1 if fails else 0)
