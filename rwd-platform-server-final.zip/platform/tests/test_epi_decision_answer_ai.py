"""Selected-question AI drafting with synthetic source eligibility and no provider calls."""
import copy
import json
import shutil
from pathlib import Path
import sys
from unittest.mock import Mock

import pytest

ROOT = Path(__file__).resolve().parents[2]
sys.path[:0] = [str(ROOT / "platform/tests"), str(ROOT / "experiments/portal"), str(ROOT / "platform/tools")]
from test_epi_scientific_definitions import fixture
from test_spec_slice import _strip_extraction, _sign
import decision_record as records
import decision_answers as answers
import decision_answer_ai as ai

ACTOR = "decision-drafter"
QUESTION = "Which assessment date?"
_DEFAULT_MODEL = object()


def seed(tmp_path, *, question=QUESTION, evidence="clinical:3"):
    root, pack, product, _values = fixture(tmp_path)
    (product / records.DECISIONS).write_text(
        "# Scientific decisions\n\n| ID | Question | Evidence | Owner | Resolution | Approved by | Approval date | Status |\n"
        "|---|---|---|---|---|---|---|---|\n"
        f"| Q1 | {question} | {evidence} | Science | — | | | OPEN |\n"
        "| Q2 | UNRELATED-QUESTION-SENTINEL | clinical:3 | Science | — | | | OPEN |\n", encoding="utf-8")
    written, _skipped, errors = records.write_forms(pack, root=str(root))
    assert len(written) == 2 and not errors, errors
    assert ai.shared.definitions.cs.ai_gate(str(product)) is None
    assert all(item["editable"] for item in answers.describe(root, pack)["items"])
    return root, pack, product


def snapshot(root):
    return {path.relative_to(root).as_posix(): path.read_bytes() for path in root.rglob("*") if path.is_file()}


def option(identifier="option_1", answer="Use the latest qualifying assessment after the timing choice is confirmed."):
    return {"id": identifier, "label": "Latest qualifying assessment", "answer": answer,
            "support": [{"source_id": "question", "quote": QUESTION}],
            "assumptions": ["The qualifying population remains to be confirmed."],
            "questions": ["Which date field and observation window should define qualifying?"]}


def reply(*options):
    return json.dumps({"explanation": "The question needs an explicit assessment timing decision.",
                       "options": list(options) or [option()]})


class Model:
    def __init__(self, response=None, callback=None):
        self.response = reply() if response is None else response
        self.callback, self.calls = callback, []

    def step(self, system, transcript):
        self.calls.append((system, transcript))
        if self.callback:
            self.callback()
        if isinstance(self.response, BaseException):
            raise self.response
        return self.response


@pytest.fixture(autouse=True)
def offline_provider(monkeypatch):
    monkeypatch.setenv("RWD_PORTAL_AI_PROVIDER", "anthropic")
    monkeypatch.setenv("ANTHROPIC_API_KEY", "synthetic-key-never-sent")
    monkeypatch.delenv("RWD_AGENT_MODEL", raising=False)
    construction = Mock(side_effect=AssertionError("No external provider calls in tests"))
    monkeypatch.setattr(ai.shared, "_make_model", construction)
    yield
    construction.assert_not_called()


def suggest(root, pack, model=_DEFAULT_MODEL, *, working="My unfinished timing answer.", **overrides):
    kwargs = {"expected_digest": answers.describe(root, pack)["digest"], "local_demo": True, "can_write": True,
              "allowed_packs": [pack], "model": Model() if model is _DEFAULT_MODEL else model}
    kwargs.update(overrides)
    return ai.suggest(root, pack, ACTOR, "Q1", working, **kwargs)


def accept(root, pack, proposal, *, working="My unfinished timing answer.", actor=ACTOR, decision="Q1", **overrides):
    kwargs = {"expected_digest": proposal["digest"], "local_demo": True, "can_write": True, "allowed_packs": [pack]}
    kwargs.update(overrides)
    return ai.accept(root, pack, actor, decision, working, proposal, kwargs.pop("option_id", "option_1"), **kwargs)


def test_selected_question_and_eligible_spec_context_reach_one_text_call(tmp_path):
    root, pack, product = seed(tmp_path, evidence="products/oncology/private/202606/handoff/restricted.txt")
    other = root / "products/oncology/private/202606/handoff"
    other.mkdir(parents=True)
    (other / "restricted.txt").write_text("OTHER-PRODUCT-CONTENTS-MUST-NOT-BE-READ", encoding="utf-8")
    before = snapshot(root)
    original_system = ai.shared.SYSTEM
    model = Model()
    result = suggest(root, pack, model)
    assert result["ok"], result
    assert len(model.calls) == 1
    system, transcript = model.calls[0]
    assert system == ai.SYSTEM and ai.shared.SYSTEM == original_system
    assert len(transcript) == 1 and set(transcript[0]) == {"role", "content"}
    sent = transcript[0]["content"]
    context = json.loads(sent)["context"]
    assert context["decision_id"] == "Q1" and context["working_answer"] == "My unfinished timing answer."
    assert all(source["kind"] in {"unreviewed_question", "unreviewed_evidence", "related_spec", "precedent"}
               for source in context["sources"])
    assert context["scientific_context"]["digest"]
    skill = ai.shared.workflow_skills.context_for(ai.shared.SKILL_ROOT, "questions", max_bytes=ai.shared.SKILL_PROMPT_BYTES)
    assert context["workflow_guidance"] == {"digest": skill["digest"], "source": skill["prompt"], "corrections": skill["corrections"]}
    assert result["proposal"]["workflow_skill_digest"] == skill["digest"]
    assert "supplied previous options" in skill["prompt"]
    assert "current user_request controls" in system
    assert len(system.encode()) + len(sent.encode()) <= ai.MAX_REQUEST_BYTES
    assert "products/oncology/private/202606/handoff/restricted.txt" in sent
    assert "OTHER-PRODUCT-CONTENTS-MUST-NOT-BE-READ" not in sent
    assert "UNRELATED-QUESTION-SENTINEL" not in sent
    assert "answered_by" not in sent and "answer_date" not in sent and ACTOR not in sent
    assert "synthetic-key" not in json.dumps(result)
    assert result["proposal"]["sources"] == context["sources"]
    assert snapshot(root) == before


def test_copy_returns_only_explicit_todo_answer_with_open_questions_and_never_persists(tmp_path, monkeypatch):
    root, pack, _product = seed(tmp_path)
    before = snapshot(root)
    proposal = suggest(root, pack, Model(reply(option(), option("option_2", "Ask the study team for the missing timing choice."))))["proposal"]
    saving = Mock(side_effect=AssertionError("AI must not save decision answers"))
    monkeypatch.setattr(answers, "save", saving)
    assert not accept(root, pack, proposal, option_id=None)["ok"]
    copied = accept(root, pack, proposal, option_id="option_2")
    assert copied["ok"] and copied["draft_only"] and copied["changed"] is False, copied
    assert set(copied) == {"ok", "answer", "changed", "draft_only", "errors", "notice"}
    assert copied["answer"].startswith(ai.DRAFT_PREFIX + "Ask the study team")
    assert "Assumptions to review" in copied["answer"] and "Questions still open" in copied["answer"]
    assert all(item["status"] == "OPEN" for item in answers.describe(root, pack)["items"])
    saving.assert_not_called()
    assert snapshot(root) == before


@pytest.mark.parametrize("overrides", [{"can_write": False}, {"local_demo": False}, {"allowed_packs": []}, {"expected_digest": "old"}])
def test_unpermitted_or_stale_generation_never_calls_model(tmp_path, overrides):
    root, pack, _product = seed(tmp_path)
    model = Model()
    before = snapshot(root)
    assert not suggest(root, pack, model, **overrides)["ok"]
    assert not model.calls and snapshot(root) == before


def test_existing_source_gate_blocks_unapproved_fixture_before_lifting_questions(tmp_path):
    root, pack, product = seed(tmp_path)
    _strip_extraction(product)
    before = snapshot(root)
    model = Model()
    availability = ai.describe_availability(root, pack, ACTOR, "Q1", allowed_packs=[pack])
    assert not availability["source_eligible"] and "AI-access review" in availability["blocker"]
    assert "manually" in availability["blocker"]
    assert not suggest(root, pack, model)["ok"] and not model.calls
    assert snapshot(root) == before


@pytest.mark.parametrize("place", ["question", "evidence", "answer", "request"])
def test_secret_and_patient_ingress_are_rejected_without_echo_or_model_call(tmp_path, place):
    secret = "ANTHROPIC_API_KEY=sk-ant-SYNTHETIC-DO-NOT-TRANSMIT-123456789"
    root, pack, _product = seed(tmp_path, question=secret if place == "question" else QUESTION,
                                evidence=secret if place == "evidence" else "clinical:3")
    model = Model()
    kwargs = {"working": secret} if place == "answer" else {"user_request": secret} if place == "request" else {}
    result = suggest(root, pack, model, **kwargs)
    assert not result["ok"] and not model.calls
    assert secret not in json.dumps(result) and "credential-shaped" in result["errors"][0]
    if place == "answer":
        result = suggest(root, pack, model, working="Patient ID: 123456789")
        assert not result["ok"] and not model.calls and "individual people" in result["errors"][0]


def test_redacted_evidence_stays_in_restricted_handoff(tmp_path):
    root, pack, _product = seed(tmp_path, evidence="VENDOR DOCUMENTATION REDACTED")
    model = Model()
    result = suggest(root, pack, model)
    assert not result["ok"] and "restricted-reference" in result["errors"][0] and not model.calls


@pytest.mark.parametrize("mutation", [
    lambda doc: doc.update(answered_by="Invented Reviewer"),
    lambda doc: doc.update(tool_calls=[{"name": "Read"}]),
    lambda doc: doc["options"][0].update(status="RESOLVED"),
    lambda doc: doc["options"][0].update(answer_date="2026-09-06"),
    lambda doc: doc["options"][0].update(answer="status: approved"),
    lambda doc: doc["options"][0].update(answer="Answered by: Alice Smith"),
    lambda doc: doc["options"][0].update(assumptions=["We have approved this product."]),
    lambda doc: doc["options"][0].update(support=[{"source_id": "another_question", "quote": QUESTION}]),
    lambda doc: doc["options"][0].update(support=[{"source_id": "question", "quote": "an invented quotation"}]),
    lambda doc: doc["options"][0].update(support=[]),
    lambda doc: doc["options"][0].update(answer="Choose A | B"),
    lambda doc: doc["options"][0].update(answer="x" * 1601),
    lambda doc: doc.update(options=[option(f"option_{number}") for number in range(1, 5)]),
])
def test_malformed_unbounded_or_authority_claiming_answers_are_not_proposals(tmp_path, mutation):
    root, pack, _product = seed(tmp_path)
    before = snapshot(root)
    document = json.loads(reply())
    mutation(document)
    result = suggest(root, pack, Model(json.dumps(document)))
    assert not result["ok"] and "proposal" not in result
    assert snapshot(root) == before


@pytest.mark.parametrize("field", ["explanation", "label", "answer", "assumptions", "questions"])
@pytest.mark.parametrize("claim", [
    "Alice Smith approved this definition on 2026-09-06.",
    "This decision is approved by Alice Smith.",
    "The decision maker is Alice Smith.",
])
def test_natural_language_attribution_is_refused_in_every_generated_prose_field(tmp_path, field, claim):
    root, pack, _product = seed(tmp_path)
    before = snapshot(root)
    document = json.loads(reply())
    if field == "explanation":
        document[field] = claim
    else:
        document["options"][0][field] = [claim] if field in ("assumptions", "questions") else claim
    result = suggest(root, pack, Model(json.dumps(document)))
    assert not result["ok"] and "proposal" not in result
    assert "attribution" in result["errors"][0] and claim not in json.dumps(result)
    assert snapshot(root) == before


def test_scientific_approval_term_is_not_mistaken_for_an_ai_ruling(tmp_path):
    root, pack, _product = seed(tmp_path)
    result = suggest(root, pack, Model(reply(option(answer="Clarify whether FDA-approved medications define the intended study population."))))
    assert result["ok"], result
    assert result["proposal"]["options"][0]["answer"].startswith(ai.DRAFT_PREFIX)


@pytest.mark.parametrize("raw", ["not JSON", '{"explanation":"x","explanation":"y","options":[]}',
                                  '{"explanation":"x","options":NaN}', "x" * 24001])
def test_raw_response_errors_are_fixed_and_do_not_persist(tmp_path, raw):
    root, pack, _product = seed(tmp_path)
    before = snapshot(root)
    result = suggest(root, pack, Model(raw))
    assert not result["ok"] and snapshot(root) == before


@pytest.mark.parametrize("change", ["contract", "register", "form", "source", "access", "during_generation"])
def test_source_form_register_or_access_changes_invalidate_generation_or_copy(tmp_path, change):
    root, pack, product = seed(tmp_path)
    target = {"contract": product / "handoff/FUNCTIONAL_CONTRACT.md", "register": product / records.DECISIONS,
              "form": product / records.FORMS_DIR / "Q1.yaml", "source": product / "spec_pipeline/out/extracted.json",
              "during_generation": product / "handoff/FUNCTIONAL_CONTRACT.md"}.get(change)
    def mutate():
        if change == "access":
            _strip_extraction(product)
        else:
            target.write_bytes(target.read_bytes() + b"\n")
            if change == "source":
                _sign(str(product))
    result = suggest(root, pack, Model(callback=mutate if change == "during_generation" else None))
    if change == "during_generation":
        assert not result["ok"]
    else:
        assert result["ok"], result
        mutate()
        after_external_edit = snapshot(root)
        assert not accept(root, pack, result["proposal"])["ok"]
        assert snapshot(root) == after_external_edit


@pytest.mark.parametrize("change", ["actor", "question", "answer", "tampered", "expired", "permission", "scope"])
def test_copy_binding_rejects_changed_identity_answer_or_proposal(tmp_path, monkeypatch, change):
    root, pack, _product = seed(tmp_path)
    proposal = suggest(root, pack)["proposal"]
    before = snapshot(root)
    kwargs = {}
    if change == "actor": kwargs["actor"] = "another-scientist"
    if change == "question": kwargs["decision"] = "Q2"
    if change == "answer": kwargs["working"] = "Another unsaved answer."
    if change == "tampered": proposal["options"][0]["answer"] = "Overwritten answer"
    if change == "expired": monkeypatch.setattr(ai.time, "time", lambda: proposal["expires_at"] + 1)
    if change == "permission": kwargs["can_write"] = False
    if change == "scope": kwargs["allowed_packs"] = []
    assert not accept(root, pack, proposal, **kwargs)["ok"]
    assert snapshot(root) == before


@pytest.mark.parametrize("model_id", ["gpt-5-mini", "claude-sonnet-4.6"])
def test_vscode_selection_uses_actual_provider_metadata_without_anthropic_fallback(tmp_path, monkeypatch, model_id):
    root, pack, _product = seed(tmp_path)
    monkeypatch.setenv("RWD_PORTAL_AI_PROVIDER", "vscode")
    monkeypatch.delenv("ANTHROPIC_API_KEY")
    model = Model()
    model.model = model_id
    model.model_info = {"id": model_id, "name": model_id, "family": model_id, "version": "", "vendor": "test-vscode"}
    model.connection_id = "connected-test-selection"
    model.health = lambda: model.model_info
    monkeypatch.setattr(ai.shared.vscode, "VSCodeModel", lambda _root: model)
    before = snapshot(root)
    available = ai.describe_availability(root, pack, ACTOR, "Q1", allowed_packs=[pack])
    assert available["configured"] and available["model_info"] == model.model_info
    result = suggest(root, pack, model=None)
    assert result["ok"], result
    assert len(model.calls) == 1
    assert result["proposal"]["model_info"] == model.model_info
    assert result["proposal"]["connection_id"] == model.connection_id
    assert result["proposal"]["provider_id"] == "vscode"
    assert "maximum_request_cost_usd" not in result["proposal"]
    assert accept(root, pack, result["proposal"])["ok"]
    model.connection_id = "replacement-connection"
    assert not accept(root, pack, result["proposal"])["ok"]
    assert snapshot(root) == before


def test_resolved_question_and_missing_provider_have_manual_paths(tmp_path, monkeypatch):
    root, pack, product = seed(tmp_path)
    monkeypatch.delenv("ANTHROPIC_API_KEY")
    model = Model()
    result = suggest(root, pack, model)
    assert not result["ok"] and "manually" in result["errors"][0] and not model.calls
    monkeypatch.setenv("ANTHROPIC_API_KEY", "synthetic-key")
    current = answers.describe(root, pack)
    saved = answers.save(root, pack, {"Q1": {"answer": "Use the latest recorded assessment.", "answered_by": "Alice Smith",
        "answer_date": "2026-09-06"}}, expected_digest=current["digest"], local_demo=True, can_write=True, allowed_packs=[pack])
    assert saved["ok"], saved
    before = snapshot(root)
    result = suggest(root, pack, model)
    assert not result["ok"] and "already answered" in result["errors"][0] and not model.calls
    assert snapshot(root) == before


@pytest.mark.parametrize("provider", ["", "auto", "vscode"])
def test_missing_or_disconnected_provider_never_falls_back_to_configured_anthropic(tmp_path, monkeypatch, provider):
    root, pack, _product = seed(tmp_path)
    monkeypatch.setenv("RWD_PORTAL_AI_PROVIDER", provider)
    monkeypatch.setattr(ai.shared.vscode, "descriptor_path", lambda: tmp_path / "missing-bridge.json")
    model = Model()
    before = snapshot(root)
    result = suggest(root, pack, model)
    assert not result["ok"] and not model.calls
    assert snapshot(root) == before


def test_selected_provider_changes_during_generation_invalidate_ephemeral_options(tmp_path, monkeypatch):
    root, pack, _product = seed(tmp_path)
    before = snapshot(root)
    model = Model(callback=lambda: monkeypatch.setenv("RWD_PORTAL_AI_PROVIDER", ""))
    result = suggest(root, pack, model)
    assert not result["ok"] and len(model.calls) == 1
    assert snapshot(root) == before


def test_provider_error_details_are_never_echoed_or_persisted(tmp_path):
    root, pack, _product = seed(tmp_path)
    before = snapshot(root)
    sensitive = "SYNTHETIC-PROVIDER-DETAIL-DO-NOT-ECHO"
    result = suggest(root, pack, Model(RuntimeError(sensitive)))
    assert not result["ok"] and sensitive not in json.dumps(result)
    assert snapshot(root) == before


@pytest.fixture
def skill_checkout(tmp_path, monkeypatch):
    target = tmp_path / "skill-runtime"
    shutil.copytree(ai.shared.SKILL_ROOT / ".claude/skills", target / ".claude/skills")
    monkeypatch.setattr(ai.shared, "SKILL_ROOT", target)
    return target / ".claude/skills/answer-decisions/SKILL.md"


def test_missing_skill_blocks_question_generation_before_model_call(tmp_path, skill_checkout):
    root, pack, _product = seed(tmp_path / "product-runtime")
    skill_checkout.unlink()
    model = Model()
    result = suggest(root, pack, model)
    assert not result["ok"] and "skill" in result["errors"][0]
    assert not model.calls


@pytest.mark.parametrize("when", ["during_generation", "before_accept", "during_accept"])
def test_changed_question_skill_refuses_old_options_without_saving(tmp_path, monkeypatch, skill_checkout, when):
    root, pack, _product = seed(tmp_path / "product-runtime")
    before = snapshot(root)
    def edit():
        with skill_checkout.open("a", encoding="utf-8") as handle:
            handle.write("\nNew procedure instruction from the owner.\n")
    result = suggest(root, pack, Model(callback=edit if when == "during_generation" else None))
    if when != "during_generation":
        assert result["ok"], result
        if when == "before_accept":
            edit()
        else:
            original = ai.shared._provider
            def provider(*args, **kwargs):
                config = original(*args, **kwargs)
                edit()
                return config
            monkeypatch.setattr(ai.shared, "_provider", provider)
        result = accept(root, pack, result["proposal"])
    assert not result["ok"] and "skill" in result["errors"][0]
    assert snapshot(root) == before


def test_question_skill_cannot_be_cited_as_answer_evidence(tmp_path):
    root, pack, _product = seed(tmp_path)
    proposed = option()
    proposed["support"] = [{"source_id": "workflow_guidance", "quote": "A human signs"}]
    result = suggest(root, pack, Model(reply(proposed)))
    assert not result["ok"]


def test_followup_sees_signed_unaccepted_options_and_keeps_them_out_of_sources(tmp_path):
    root, pack, _product = seed(tmp_path)
    before = snapshot(root)
    first = suggest(root, pack, user_request="Give two draft alternatives for review.")
    assert first["ok"], first
    model = Model()
    second = suggest(root, pack, model, user_request="Make option 1 clearer and keep its timing question open.",
                     previous_proposal=first["proposal"])
    assert second["ok"], second
    request = json.loads(model.calls[0][1][0]["content"])
    previous = request["previous_unaccepted_options"]
    assert previous["options"] == first["proposal"]["options"]
    assert previous["explanation"] == first["proposal"]["explanation"]
    assert previous["requests"] == ["Give two draft alternatives for review."]
    assert "not saved answers" in previous["status"]
    assert request["context"]["working_answer"] == "My unfinished timing answer."
    assert all(source["id"] in {"question", "evidence"} for source in request["context"]["sources"])
    assert "previous requests are history" in model.calls[0][0]
    third = suggest(root, pack, user_request="Keep the remaining question visible.", previous_proposal=second["proposal"])
    assert third["ok"] and third["proposal"]["requests"] == [
        "Make option 1 clearer and keep its timing question open.", "Keep the remaining question visible."]
    assert snapshot(root) == before


@pytest.mark.parametrize("change", ["answer", "signature", "expiry", "connection"])
def test_stale_option_context_refuses_followup_before_any_model_call(tmp_path, monkeypatch, change):
    root, pack, _product = seed(tmp_path)
    first = suggest(root, pack)
    assert first["ok"], first
    kwargs = {}
    if change == "answer":
        kwargs["working"] = "A changed manual answer."
    elif change == "signature":
        first["proposal"]["options"][0]["answer"] = "Edited outside the signed response"
    elif change == "expiry":
        monkeypatch.setattr(ai.time, "time", lambda: first["proposal"]["expires_at"] + 1)
    else:
        original = ai.shared._provider
        monkeypatch.setattr(ai.shared, "_provider", lambda *a, **kw: dict(original(*a, **kw), connection_id="different"))
    model = Model()
    result = suggest(root, pack, model, previous_proposal=first["proposal"], **kwargs)
    assert not result["ok"] and not model.calls, result


def test_previous_options_cannot_supply_new_scientific_citations(tmp_path):
    root, pack, _product = seed(tmp_path)
    first = suggest(root, pack)
    item = option()
    item["support"] = [{"source_id": "previous_unaccepted_options", "quote": QUESTION}]
    result = suggest(root, pack, Model(reply(item)), previous_proposal=first["proposal"])
    assert not result["ok"] and "quotation" in result["errors"][0]
