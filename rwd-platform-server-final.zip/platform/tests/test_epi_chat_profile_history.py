"""Private profile transcripts survive reload without resurrecting cleared chat."""
import copy
import json
from pathlib import Path
import sys

import pytest

ROOT = Path(__file__).resolve().parents[2]
sys.path[:0] = [str(ROOT / name) for name in ("platform/tests", "experiments/portal", "platform/tools", "experiments/agent")]
import chat_history as history

PACK = "products/oncology/example/202609"
OTHER = "products/oncology/another/202609"
TURN = {"question": "Explain the next workflow step.", "answer": "Review the current product checks.", "actions": []}


@pytest.fixture
def workspace(tmp_path, monkeypatch):
    monkeypatch.setenv("RWDP_STATE_DIR", str(tmp_path / "private"))
    checkout = tmp_path / "checkout"
    (checkout / PACK).mkdir(parents=True)
    (checkout / OTHER).mkdir(parents=True)
    return {"root": checkout, "pack": PACK, "actor": "first@example.test", "allowed_packs": [PACK, OTHER]}


def test_reload_is_private_to_profile_product_checkout_and_chat_surface(workspace, tmp_path):
    saved = history.save(**workspace, turns=[TURN], expected_revision=None)
    assert history.load(**workspace)["turns"] == [TURN]
    other_checkout = tmp_path / "other-checkout"
    (other_checkout / PACK).mkdir(parents=True)
    for changed in ({"actor": "second@example.test"}, {"pack": OTHER}, {"root": other_checkout}, {"channel": "other_chat"}):
        assert history.load(**(workspace | changed))["turns"] == []
    assert history.load(**workspace)["revision"] == saved["revision"]


def test_clear_survives_reload_and_rejects_inflight_or_stale_browser_answers(workspace):
    before = history.save(**workspace, turns=[TURN], expected_revision=None)
    other = workspace | {"actor": "second@example.test"}
    history.save(**other, turns=[TURN], expected_revision=None)
    cleared = history.clear(**workspace)
    assert cleared["revision"] != before["revision"]
    for revision in (None, before["revision"]):
        with pytest.raises(history.Changed):
            history.save(**workspace, turns=[TURN], expected_revision=revision)
    assert history.load(**workspace)["turns"] == []
    assert history.load(**other)["turns"] == [TURN]
    after = history.save(**workspace, turns=[TURN], expected_revision=cleared["revision"])
    assert after["turns"] == [TURN]


def test_revoked_access_does_not_reappear_when_grant_is_restored(workspace):
    history.save(**workspace, turns=[TURN], expected_revision=None)
    assert history.load(**(workspace | {"allowed_packs": [PACK]}))["turns"] == []
    assert history.load(**workspace)["turns"] == []
    with pytest.raises(ValueError, match="outside your access"):
        history.load(**(workspace | {"allowed_packs": [OTHER]}))


def test_stale_save_cannot_erase_newer_messages(workspace):
    before = history.save(**workspace, turns=[TURN], expected_revision=None)
    after = history.save(**workspace, turns=[TURN, TURN], expected_revision=before["revision"])
    with pytest.raises(history.Changed):
        history.save(**workspace, turns=[TURN], expected_revision=before["revision"])
    assert history.load(**workspace)["revision"] == after["revision"]


def test_private_store_rejects_restricted_and_unbounded_chat(workspace):
    with pytest.raises(ValueError):
        history.save(**workspace, turns=[TURN] * 9, expected_revision=None)
    with pytest.raises(ValueError):
        history.save(**workspace, turns=[TURN | {"question": "patient John Smith, MRN 123456, DOB 1961-03-04"}], expected_revision=None)
    assert history.load(**workspace)["turns"] == []


def test_copied_record_cannot_be_opened_under_another_profile(workspace):
    history.save(**workspace, turns=[TURN], expected_revision=None)
    _, original = history._scope(**workspace, channel="flow_assistant_")
    other = workspace | {"actor": "second@example.test"}
    _, destination = history._scope(**other, channel="flow_assistant_")
    destination.parent.mkdir(parents=True)
    destination.write_bytes(original.read_bytes())
    with pytest.raises(ValueError, match="another profile"):
        history.load(**other)


def test_real_page_recovers_profile_chat_in_a_new_browser_and_clear_stays_cleared(monkeypatch):
    from streamlit.testing.v1 import AppTest
    import session_drafts
    from test_epi_chat_form_prefill import EMPTY, _connect
    from test_epi_portal_journeys import APP, _healthy, _new, _portal

    calls = _connect(monkeypatch, lambda message: json.dumps({"answer": "Private conversation sentinel.", "actions": []}))
    with _portal(role="admin", catalogue=EMPTY, users=[{"name": "Priya", "email": "priya@example.test", "role": "admin"},
                                                     {"name": "Sam", "email": "sam@example.test", "role": "admin"}]) as at:
        _new(at)
        at.text_input(key="np_name").set_value("Retained scientific form").run()
        at.chat_input[0].set_value("Explain this registration test.").run()
        _healthy(at)
        original_key = session_drafts.history_key(ROOT, "priya@example.test")
        original = copy.deepcopy(at.session_state[original_key])
        assert original and len(calls) == 1
        at.selectbox(key="who").set_value("Sam").run()
        _healthy(at)
        assert not at.session_state[session_drafts.history_key(ROOT, "sam@example.test")]
        assert not any("Private conversation sentinel" in str(item.value) for item in at.markdown)
        at.selectbox(key="who").set_value("Priya").run()
        _healthy(at)
        assert at.session_state[original_key] == original
        fresh = AppTest.from_file(str(APP), default_timeout=90).run()
        _new(fresh)
        _healthy(fresh)
        assert fresh.session_state[original_key] == original
        next(item for item in fresh.button if item.label == "Clear this conversation").click().run()
        _healthy(fresh)
        at.run()
        _healthy(at)
        assert at.session_state[original_key] == []
        assert at.text_input(key="np_name").value == "Retained scientific form"
        fresh_again = AppTest.from_file(str(APP), default_timeout=90).run()
        _new(fresh_again)
        assert fresh_again.session_state[original_key] == []
        assert len(calls) == 1
