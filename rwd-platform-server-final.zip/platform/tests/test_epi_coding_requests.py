"""Current implementation asks and verified follow-ups survive bounded adapters."""
from pathlib import Path
import json
import sys
import types

import pytest

ROOT = Path(__file__).resolve().parents[2]
sys.path[:0] = [str(ROOT / part) for part in ("platform/tests", "experiments/portal", "experiments/agent", "platform/tools")]
from test_epi_specialist_workspace import setup, PACK, ACTOR
from test_contract_lint import one
import coding_agent as coding
import critic
import specialist_workspace as workspace


def evidence():
    files = [{"path": "platform/" + path, "symbol": symbol, "kind": kind,
              "sha256": "a" * 64, "line": 1, "end_line": 2, "truncated": False, "excerpt": code}
             for path, symbol, kind, code in [
                 ("engine/stages/example.py", "derive", "implementation", "def derive(frame, cfg):\n    return frame.select(*cfg['columns'])"),
                 ("tests/test_example.py", "test_columns", "test", "def test_columns():\n    assert configured_columns == ['result']")]]
    return {"pack": PACK, "requirement_query": "ECOG", "definition": "Preserve the reviewed ECOG rule.",
            "implementation_context": {"registry_sha256": "b" * 64, "capabilities": [{"id": "example", "summary": "Long registry prose. " * 2000}],
                                       "files": files, "omissions": []}}


def test_structural_budget_preserves_ask_previous_code_and_latest_findings():
    prior = {"generated": {"code": "def old_candidate():\n    return None", "tests": "def test_old():\n    assert old_candidate() is None"}}
    packet = {"evidence": evidence(), "user_request": "Handle tied dates and preserve the reviewed missing-value behavior.",
              "previous_proposal": prior, "revise_to_address": ["LATEST-CRITIC-FINDING: ties need a discriminating test."]}
    content = coding.REQUEST_PREFIX + json.dumps(packet, ensure_ascii=False)
    bounded = coding.bound_request(content, 6500)
    result = json.loads(bounded[len(coding.REQUEST_PREFIX):])
    assert len(bounded.encode()) <= 6500
    for key in ("user_request", "previous_proposal", "revise_to_address"):
        assert result[key] == packet[key]
    assert [row["excerpt"] for row in result["evidence"]["implementation_context"]["files"]] == [row["excerpt"] for row in evidence()["implementation_context"]["files"]]
    assert "review_omissions" in result["evidence"]


def test_adapter_rebudgets_tagged_coding_without_dropping_end_of_packet():
    calls = []
    client = types.SimpleNamespace(model="scripted", step=lambda system, messages: calls.append((system, messages)) or '{"summary":"Unaccepted proposal"}')
    model = workspace.BoundedModel(client, {"provider_id": "vscode"})
    packet = {"evidence": evidence(), "user_request": "CURRENT-USER-ASK", "revise_to_address": ["TAIL-FINDING"]}
    model.step("System guidance. " * 500, [{"role": "user", "content": coding.REQUEST_PREFIX + json.dumps(packet)}])
    sent = calls[0][1][0]["content"]
    result = json.loads(sent.split(coding.REQUEST_PREFIX, 1)[1])
    assert result["user_request"] == "CURRENT-USER-ASK" and result["revise_to_address"] == ["TAIL-FINDING"]
    assert model.excerpted_calls == 1
    assert len(calls[0][0].encode()) + len(sent.encode()) <= workspace.MAX_INPUT_BYTES


def test_oversized_mandatory_followup_is_refused_without_partial_code():
    packet = {"evidence": evidence(), "user_request": "Fix the existing candidate", "previous_proposal": {"generated": {"code": "large_code = 1\n" * 2000}}}
    with pytest.raises(ValueError, match="complete coding request"):
        coding.bound_request(coding.REQUEST_PREFIX + json.dumps(packet), 6500)


def test_critic_keeps_the_current_ask_when_reducing_coding_evidence():
    doc = evidence()
    doc["user_request"] = "Explain the failing tie case and preserve null handling."
    reduced = json.loads(critic._coding_evidence(json.dumps(doc), 6500))
    assert reduced["user_request"] == doc["user_request"]


def test_complete_definition_tail_survives_gather_and_coding_rebudget(monkeypatch):
    rule = "Declared rule context. " * 100 + "Missing observations remain null; never impute zero."
    monkeypatch.setattr(coding.tools, "call", lambda name, _args: rule if name == "definition" else "Registry context")
    monkeypatch.setattr(coding, "implementation_context", lambda *_args, **_kwargs: evidence()["implementation_context"])
    monkeypatch.setattr(coding, "orchestration_context", lambda *_args, **_kwargs: {})
    gathered = coding.gather(PACK, "ECOG")
    assert gathered["definition"] == rule
    packet = coding.REQUEST_PREFIX + json.dumps({"evidence": gathered, "user_request": "Preserve the missing-observation rule."})
    reduced = json.loads(coding.bound_request(packet, 6500)[len(coding.REQUEST_PREFIX):])
    assert reduced["evidence"]["definition"] == rule


@pytest.fixture
def implementation_setup(setup, monkeypatch):
    original = workspace._inputs
    monkeypatch.setattr(workspace, "_inputs", lambda root, pack: {**original(root, pack), pack + "/handoff/FUNCTIONAL_CONTRACT.md": one(vid="ECOG").encode()})
    monkeypatch.setattr(workspace, "_implementation_current", lambda *_: True)
    calls = []
    def worker(root, request):
        calls.append(request)
        return {"ok": True, "calls": 2, "result": {"pack": PACK, "proposal": {"decision": "reuse", "summary": "Keep the existing source contract."},
                "deterministic_checks": {"static_findings": [], "pipeline_runtime_run": False},
                "critic": {"route": "human", "falsified": False, "findings": ["Review the tied-date case."]}}}
    monkeypatch.setattr(workspace, "_run_worker", worker)
    return setup, calls


def run(root, actor=ACTOR, **kwargs):
    current = workspace.describe(root, PACK, actor, allowed_packs=[PACK])
    return workspace.run(root, PACK, actor, "implementation", "ECOG", expected_input_digest=current["input_digest"],
                         allowed_packs=[PACK], local_demo=True, can_agent=True, **kwargs)


def test_saved_followup_carries_actual_checks_with_user_task(implementation_setup):
    root, calls = implementation_setup
    first = run(root, user_request="Inspect the closest existing implementation.")
    assert first["ok"], first
    second = run(root, user_request="Refine its tie handling.", previous_run_id=first["record"]["id"])
    assert second["ok"], second
    assert calls[1]["user_request"] == "Refine its tie handling."
    previous = calls[1]["previous_context"]
    assert previous["proposal"] == first["record"]["result"]["proposal"]
    assert previous["deterministic_checks"]["pipeline_runtime_run"] is False
    assert previous["critic"]["findings"] == ["Review the tied-date case."]
    assert "not authority" in previous["status"]
    assert second["record"]["previous_run_id"] == first["record"]["id"]


def test_other_actor_or_stale_evidence_cannot_continue_saved_result(implementation_setup):
    root, calls = implementation_setup
    first = run(root)
    assert first["ok"], first
    assert not run(root, actor="other", previous_run_id=first["record"]["id"])["ok"]
    assert len(calls) == 1
    (root / PACK / "source_refs.yaml").write_text("source: changed\n", encoding="utf-8")
    result = run(root, previous_run_id=first["record"]["id"])
    assert not result["ok"] and "current implementation result" in result["errors"][0]
    assert len(calls) == 1


def test_dispatch_passes_freeform_request_and_verified_previous_context(monkeypatch):
    captured = {}
    def runner(pack, **kwargs):
        captured.update(kwargs)
        return {"pack": pack, "proposal": {}}
    monkeypatch.setattr(workspace.importlib, "import_module", lambda _: types.SimpleNamespace(run=runner))
    model = types.SimpleNamespace(calls=1)
    prior = {"proposal": {"summary": "Existing unaccepted draft"}}
    workspace._dispatch({"kind": "implementation", "pack": PACK, "actor": ACTOR, "question": "ECOG",
                         "user_request": "Preserve timing while fixing ties", "previous_context": prior}, model)
    assert captured["user_request"] == "Preserve timing while fixing ties" and captured["previous_context"] == prior


def test_existing_specialist_page_submits_task_and_then_continues_result(implementation_setup):
    from test_epi_specialist_workspace_page import app, healthy
    root, calls = implementation_setup
    at = app(root)
    at.radio(key="specialist_ws_kind").set_value("implementation").run()
    at.text_input(key="specialist_ws_requirement").set_value("ECOG").run()
    at.text_area(key="specialist_ws_implementation_request").set_value("Inspect the failing tie case.").run()
    at.button(key="specialist_ws_run").click().run()
    healthy(at)
    assert calls[-1]["user_request"] == "Inspect the failing tie case."
    assert any(item.label == "Continue from the displayed proposal and its recorded checks" for item in at.checkbox)
    at.text_area(key="specialist_ws_implementation_request").set_value("Refine those test expectations.").run()
    at.button(key="specialist_ws_run").click().run()
    healthy(at)
    assert calls[-1]["user_request"] == "Refine those test expectations."
    assert calls[-1]["previous_context"]["critic"]["findings"] == ["Review the tied-date case."]


def test_navigation_request_seeds_freeform_field_once_without_overwriting_edits(implementation_setup):
    from streamlit.testing.v1 import AppTest
    root, _calls = implementation_setup
    code = f'''
import scientific_definition_ai as ai
import specialist_workspace_page as page
ai.set_provider_selection("vscode")
page.render({str(root)!r}, {PACK!r}, {ACTOR!r}, allowed_packs={[PACK]!r}, local_demo=True,
    can_write=True, can_review=True, can_agent=True, route="specialist_assistant",
    params={{"kind": "implementation", "variable": "ECOG", "user_request": "Explain the relevant code and its tests."}})
'''
    at = AppTest.from_string(code, default_timeout=30).run()
    assert not at.exception
    assert at.text_area(key="specialist_ws_implementation_request").value == "Explain the relevant code and its tests."
    at.text_area(key="specialist_ws_implementation_request").set_value("My revised task.").run()
    assert not at.exception
    assert at.text_area(key="specialist_ws_implementation_request").value == "My revised task."


def test_navigation_request_does_not_cross_actor_reset(implementation_setup):
    from streamlit.testing.v1 import AppTest
    root, calls = implementation_setup
    code = f'''
import streamlit as st
import scientific_definition_ai as ai
import specialist_workspace_page as page
ai.set_provider_selection("vscode")
actor = st.selectbox("Identity", [{ACTOR!r}, "other"], key="actor")
page.render({str(root)!r}, {PACK!r}, actor, allowed_packs={[PACK]!r}, local_demo=True,
    can_write=True, can_review=True, can_agent=True, route="specialist_assistant",
    params={{"kind": "implementation", "variable": "ECOG", "user_request": "My private request."}})
'''
    at = AppTest.from_string(code, default_timeout=30).run()
    assert not at.exception
    assert at.text_area(key="specialist_ws_implementation_request").value == "My private request."
    at.selectbox(key="actor").set_value("other").run()
    assert not at.exception
    assert at.text_area(key="specialist_ws_implementation_request").value == ""
    assert at.text_input(key="specialist_ws_requirement").value == ""
    assert calls == []
