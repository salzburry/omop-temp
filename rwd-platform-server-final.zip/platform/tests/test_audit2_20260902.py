"""Regressions for the SECOND external audit of 2026-09-02 (main @ 1803bc3). Each fails on the
defect it names and passes on the fix.

  P1  identifiers: run.refresh and release.build_id reached paths and unquoted SQL unchecked;
      the shared grammar admitted `.` and `-` into SQL identifiers
  P1  Source Intelligence accepted an absolute or `..` pack and wrote outside candidates/
  P1  embeddings used Python's salted hash(): different vectors per process
  P2  dates: `20260902` and `2026-W36-3` parsed as ISO; only YYYY-MM-DD is canonical
  P2  golden thresholds: unknown keys silently ignored; the string "false" was truthy
  P2  run ids collided at second resolution and a `..` id escaped runs/
  P2  MCP provenance printed "commit ?, clean" when git failed
  P2  drift saw neither a five-year date shift nor added/removed columns

NO PYTEST FIXTURES AND NO `parametrize` — CI runs every suite as a script.
"""
import copy
import os
import subprocess
import sys
import tempfile
from pathlib import Path

FRAMEWORK = Path(__file__).resolve().parent.parent
ROOT = FRAMEWORK.parent
sys.path.insert(0, str(FRAMEWORK))
sys.path.insert(0, str(FRAMEWORK / "tools"))

from engine.config import load_config, product_config  # noqa: E402
from engine import validate, refresh, golden, release  # noqa: E402

CONFIG = product_config(ROOT / "fixtures", "prostate")
AGENT = ROOT / "experiments" / "agent"


def _cfg(**run_over):
    cfg = copy.deepcopy(load_config(CONFIG))
    cfg.run.update(run_over)
    return cfg


# ------------------------------------------------------------------ P1 identifiers

def test_run_refresh_traversal_is_refused_at_config_ingress():
    probs = validate.problems(_cfg(refresh="../../../../governance/publish_targets"), strict=True)
    assert any("run.refresh" in p and "not a safe" in p for p in probs), probs


def test_run_schema_traversal_is_refused():
    probs = validate.problems(_cfg(output_schema="out/../../evil"), strict=True)
    assert any("run.output_schema" in p for p in probs), probs
    assert not [p for p in validate.problems(_cfg(output_schema="cat.schema"), strict=True)
                if "run.output_schema" in p]


def test_release_build_id_traversal_is_refused_in_manifest():
    m = {"tumor": "prostate", "refresh": "2026q1", "spec_version": "202606",
         "built_at": "x", "status": "qc_pending", "counts": {"n": 1},
         "release": {"public": "p", "version": "v", "build_id": "../../evil", "ads": "a", "views": []}}
    probs = refresh.validate_manifest(m)
    assert any("release.build_id" in p for p in probs), probs


def test_sql_grammar_rejects_dot_and_dash_for_table_name_segments():
    for bad in ("2026.q1", "2026-q1", "a/b", ".."):
        assert refresh.unsafe_identifier("sql", bad), bad
    assert refresh.unsafe_identifier("sql", "2026q1_rerun") is None
    # path segments may carry . and - but never separators or dot-runs
    assert refresh.unsafe_identifier("path", "2026.06-a") is None
    assert refresh.unsafe_identifier("path", "a/b")
    assert refresh.unsafe_identifier("path", "x..y")


def test_table_name_composer_refuses_unsafe_segments_itself():
    try:
        release.versioned_ads("out.ads", "2026q1", "../../evil")
    except ValueError as e:
        assert "refusing to compose" in str(e)
    else:
        raise AssertionError("versioned_ads composed a table name with a traversal segment")
    assert release.versioned_ads("out.ads", "2026q1", "abc_123") == "out.ads__2026q1__abc_123"


# ------------------------------------------------------------------ P1 source intelligence boundary

def test_source_intel_refuses_escaping_or_absolute_packs():
    sys.path.insert(0, str(AGENT))
    import source_intel  # noqa: PLC0415
    for bad in ("..\\escaped", "../escaped", str(ROOT), "/etc", "governance", ""):
        try:
            source_intel.safe_pack(bad)
        except ValueError as e:
            assert "REFUSED" in str(e)
        else:
            raise AssertionError(f"safe_pack accepted {bad!r}")
    assert source_intel.safe_pack("fixtures/oncology/prostate/202606") == \
        "fixtures/oncology/prostate/202606"


# ------------------------------------------------------------------ P1 embeddings deterministic

def test_embedding_vectors_are_identical_across_processes():
    code = ("import sys, json; sys.path.insert(0, %r); import embed; "
            "print(json.dumps(embed.vec('time to subsequent systemic therapy')[:16]))"
            % str(AGENT / "ml"))
    outs = set()
    for _ in range(3):
        r = subprocess.run([sys.executable, "-c", code], capture_output=True, text=True,
                           encoding="utf-8", cwd=str(ROOT), timeout=120)
        assert r.returncode == 0, r.stderr[-400:]
        outs.add(r.stdout.strip())
    assert len(outs) == 1, "vec() differs between processes — hash() salt leaked back in"


def test_embedding_index_carries_an_algorithm_tag():
    src = (AGENT / "ml" / "embed.py").read_text(encoding="utf-8")
    assert "ALGO" in src and '"algo": ALGO' in src
    code_lines = [l for l in src.splitlines() if not l.strip().startswith("#")]
    assert not any("[hash(" in l or " hash(" in l for l in code_lines), \
        "the salted builtin hash() is back in a code line"


# ------------------------------------------------------------------ P2 canonical dates

def test_non_canonical_iso_forms_are_refused():
    for bad in ("20260902", "2026-W36-3", "2026-09-02T00:00:00", "2026-9-2"):
        cfg = copy.deepcopy(load_config(CONFIG))
        cfg.study["index_start"] = bad
        probs = validate.problems(cfg, strict=True)
        assert any("index_start" in p and "canonical" in p for p in probs), (bad, probs)


# ------------------------------------------------------------------ P2 golden thresholds closed/typed

def test_unknown_golden_threshold_key_fails_instead_of_being_ignored():
    r = golden.golden_gate({"n_rows": {"new": 100, "ref": 100}}, {"max_rows_delta_pct": 50})
    assert not r["passed"] and any("not a known key" in f for f in r["failures"]), r


def test_string_false_is_not_a_boolean_for_allow_new_columns():
    r = golden.golden_gate({"n_rows": {"new": 100, "ref": 100}}, {"allow_new_columns": "false"})
    assert not r["passed"] and any("allow_new_columns" in f for f in r["failures"]), r
    assert golden.golden_gate({"n_rows": {"new": 100, "ref": 100}}, {"allow_new_columns": False})["passed"]


# ------------------------------------------------------------------ P2 run ids

def test_two_immediate_runs_do_not_collide_and_escaping_ids_are_refused():
    sys.path.insert(0, str(AGENT))
    import state  # noqa: PLC0415
    a, b = state.new_run_id(), state.new_run_id()
    assert a != b, "second-resolution collision"
    for bad in ("..\\state_outside", "../x", "a/b", ""):
        try:
            state.RunState("g", run_id=bad)
        except ValueError as e:
            assert "REFUSED" in str(e)
        else:
            raise AssertionError(f"RunState accepted run_id {bad!r}")


# ------------------------------------------------------------------ P2 MCP provenance honesty

def test_mcp_tree_state_does_not_claim_clean_when_git_fails():
    import mcp_server  # noqa: PLC0415
    saved = mcp_server.ROOT
    try:
        with tempfile.TemporaryDirectory() as d:
            mcp_server.ROOT = d          # not a git repo: both git commands fail
            line = mcp_server._tree_state()
    finally:
        mcp_server.ROOT = saved
    assert ", clean]" not in line and "UNVERSIONED" in line, line


# ------------------------------------------------------------------ P2 drift shape + dates

def test_drift_sees_added_removed_columns_and_a_five_year_shift():
    sys.path.insert(0, str(AGENT / "ml"))
    import drift  # noqa: PLC0415
    import profile_io  # noqa: PLC0415
    real_load = profile_io.load
    old = {"t": {"a": {"top_values": "13:V0|13:V1", "pct_missing": 0,
                       "date_min": "2015-01-01", "date_max": "2020-12-31"},
                 "gone": {"top_values": "", "pct_missing": 0}}}
    new = {"t": {"a": {"top_values": "13:V0|13:V1", "pct_missing": 0,
                       "date_min": "2020-01-01", "date_max": "2025-12-31"},
                 "added": {"top_values": "", "pct_missing": 0}}}
    try:
        profile_io.load = lambda p: (old if p == "OLD" else new, None)
        f = drift.compare("OLD", "NEW")
    finally:
        profile_io.load = real_load
    whats = " | ".join(x[2] for x in f)
    assert "column removed" in whats and "column added" in whats, whats
    assert "date_min moved" in whats and "date_max moved" in whats, whats


if __name__ == "__main__":
    fails = 0
    for name, fn in sorted(globals().items()):
        if name.startswith("test_") and callable(fn):
            try:
                fn()
                print(f"  ok   {name}")
            except Exception as e:  # noqa: BLE001
                fails += 1
                print(f"  FAIL {name}: {e}")
    print(f"{fails} failure(s)")
    sys.exit(1 if fails else 0)
