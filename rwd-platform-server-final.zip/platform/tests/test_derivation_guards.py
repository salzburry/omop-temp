"""The five mechanical audit fixes, held in place — set A of the clinical-derivation audit.

An external audit (reviewing 0526b51) found five defects that are engineering, not clinical —
each fixable without pre-empting an open decision, and each silently able to change ADS values:

  1. index.py filtered RAW date columns against the study window before `try_cast` — an
     unparseable date dissolved inside an implicit comparison (ANSI-off) or raised mid-build
     (ANSI-on), with no record either way.
  2. lot.py sorted null start dates FIRST (Spark's bare `.asc()`) and kept exact duplicate rows,
     so an undated or repeated LOT row could renumber every real line beneath it.
  3. clinical.py computed `dth_before_fued` from the death-CAPPED follow-up end, so the
     post-death-activity guard could essentially never fire.
  4. content_digest's Spark reproduction encoded booleans as 'true'/'false' (Python: 1/0) and
     lengths in characters (Python: utf-8 bytes) — an independent reproduction of an identical
     table could disagree, which reads as tampering.
  5. build_ads.write_ads honoured a configurable append mode with no visible opt-in.

These tests are the CI-runnable half: pure functions where the fix is pure, source scans where
the behavior lives in Spark expressions this machine cannot execute (no Java). The EXECUTABLE
half is `test_synthetic_spark_uat.py`, authored for the dev rehearsal — a scan proves the code
says the right thing; only Spark proves it does it.

NO PYTEST FIXTURES AND NO parametrize — CI runs every suite as a script.

Run: python3 tests/test_derivation_guards.py (or pytest).
"""
import re as _re
import sys
import types
from pathlib import Path

FRAMEWORK = Path(__file__).resolve().parent.parent
REPO = FRAMEWORK.parent
sys.path.insert(0, str(FRAMEWORK))

from engine import content_digest as cd  # noqa: E402
from engine import build_ads             # noqa: E402


def _src(rel):
    return (FRAMEWORK / rel).read_text(encoding="utf-8")


def test_the_spark_digest_encodes_booleans_and_lengths_exactly_as_the_python_definition():
    """Two engines, one encoding — or an independent digest reproduction reads as tampering.
    `cell()` is the definition; the Spark SQL fragment must produce byte-identical payloads:
    booleans as 1/0 (not 'true'/'false'), lengths as utf-8 BYTES (octet_length, not length)."""
    frag = cd._spark_cell_sql("dthfl", "boolean")
    assert "CASE WHEN `dthfl` THEN '1' ELSE '0' END" in frag, (
        "the Spark side casts booleans to 'true'/'false' again — cell() writes 1/0, so every "
        "boolean column digests differently across engines", frag)
    assert "octet_length" in frag and "CAST(length(" not in frag, (
        "the Spark side counts characters — cell() prefixes utf-8 BYTE lengths, so any "
        "non-ASCII value digests differently across engines", frag)
    # ...and the Python definition did not move underneath this test
    assert cd.cell("x", True) == b"1:x|b1:1", cd.cell("x", True)
    assert cd.cell("x", False) == b"1:x|b1:0", cd.cell("x", False)
    two_byte = cd.cell("x", "é")                     # 1 char, 2 utf-8 bytes
    assert b"s2:" in two_byte, ("cell() no longer prefixes byte lengths", two_byte)
    # CANON_VERSION deliberately did NOT bump: the Python encoding is the definition and is
    # unchanged; a nonconforming reproduction brought into conformance is a bug fix.
    assert cd.CANON_VERSION == "1", (
        "CANON_VERSION moved — that invalidates every digest the pure path ever produced, and "
        "the parity fix changed only the Spark reproduction", cd.CANON_VERSION)


def test_a_governed_write_refuses_append_without_a_visible_opt_in():
    """A config typo (`write_mode: append`) used to stack two builds' rows in one table with
    nothing downstream able to tell which rows were this build's. The refusal fires BEFORE any
    Spark call, so it is testable here; the opt-in is a named config key a reviewer can see."""
    def cfg(mode, allow=None):
        run = {"write_mode": mode}
        if allow is not None:
            run["allow_nonidempotent_write"] = allow
        return types.SimpleNamespace(write_mode=mode, run=run,
                                     output_fqn="cat.out.x")
    try:
        build_ads.write_ads(None, cfg("append"))
        raise AssertionError("an append write proceeded with no opt-in")
    except ValueError as e:
        assert "allow_nonidempotent_write" in str(e), e
    # overwrite proceeds to the Spark call — which on ads=None raises AttributeError, proving
    # the guard let it through rather than the guard being the thing that stopped it
    try:
        build_ads.write_ads(None, cfg("overwrite"))
        raise AssertionError("unreachable")
    except AttributeError:
        pass
    # ...and the stated opt-in genuinely opts in
    try:
        build_ads.write_ads(None, cfg("append", allow=True))
        raise AssertionError("unreachable")
    except AttributeError:
        pass
    # Probe wave 9: write_ads was a SECOND persistence path with no output contract - the
    # governed runner gated its staged write while this direct entry persisted anything.
    # One contract, both paths: the gate runs before saveAsTable, a failing verdict refuses.
    body = _src("engine/build_ads.py").split("def write_ads", 1)[1]
    for needle in ("run_output_contract(ads.sparkSession, ads, cfg)",
                   "output_contract_gate(", chr(39) + "if not gate.get(" + chr(34) + "passed" + chr(34) + "):" + chr(39)):
        needle = needle.strip(chr(39))
        assert needle in body, f"write_ads no longer gates its write: {needle}"
    assert body.index("gate.get(" + chr(34) + "passed" + chr(34) + ")") < body.index("saveAsTable"), (
        "the contract gate must run BEFORE the write, not audit it afterwards")


def test_index_filters_typed_dates_never_raw_columns():
    """The window test must run on the try_cast value. Held on the source, because the behavior
    lives in Spark expressions this machine cannot run; the UAT suite executes it."""
    src = _src("engine/stages/index.py")
    assert '.withColumn("_idxdt", F.expr(f"try_cast(`{dcol}` as date)"))' in src, (
        "the overall-cohort branch no longer casts before its window filter")
    assert '.filter((F.col("_idxdt") >= start) & (F.col("_idxdt") <= end))' in src
    assert '.withColumn("_lotsd", F.expr("try_cast(startdate as date)"))' in src, (
        "the line-cohort branch no longer casts the LOT start before its window filter")
    assert '.withColumn("_diagdt", F.expr(f"try_cast(`{dcol}` as date)"))' in src, (
        "the setting-diagnosis gate no longer casts before its window filter")
    # the defect's exact shape must not return: a raw-column window comparison
    assert ".filter((F.col(dcol) >= start)" not in src, (
        "a raw-column window filter is back — an unparseable date will vanish inside an "
        "implicit comparison on ANSI-off and raise mid-build on ANSI-on")


def test_lot_deduplicates_and_sorts_null_starts_last_in_both_engines():
    """An undated LOT row must never be line 1, and a byte-identical repeated row must never
    occupy its own line number. Held on BOTH engines' sources — they must move together, or the
    R/Python parity run diverges on exactly the defective inputs this fix is about."""
    py = _src("engine/stages/lot.py")
    # `.distinct()`, NOT `dropDuplicates()`: an audit found the first version of this fix was
    # itself CI-red — test_grain forbids bare dropDuplicates because a subset-keyed one keeps an
    # arbitrary row, and full-row distinct is the sanctioned spelling of the same dedupe.
    assert "lot.distinct()" in py, "exact-duplicate LOT rows occupy line numbers again"
    in_code = [l for l in py.splitlines() if "dropDuplicates" in l.split("#", 1)[0]]
    assert not in_code, (
        "dropDuplicates is back in lot.py CODE (comments may name it, code may not) — "
        "test_grain will refuse the whole tree: " + in_code[0].strip())
    # the ordering runs on the TYPED date, nulls last, and an undated row takes NO number
    assert '_lot_sd", F.expr("try_cast(startdate as date)")' in py, (
        "the LOT ordering lost its cast — a raw-string sort is chronological only for pure ISO")
    assert 'F.col("_lot_sd").asc_nulls_last(), F.col("linenumber").asc_nulls_last()' in py, (
        "the LOT window ordering lost nulls-last")
    assert 'F.when(F.col("_lot_sd").isNotNull(), F.row_number().over(w))' in py, (
        "an undated LOT row is numbered again — sorted last it still inflates the line count "
        "and stands as a phantom next treatment to TRTDIS/TTNTFL")
    r = _src("engine-r/stages.R")
    assert "dplyr::distinct()" in r, "the R engine keeps duplicate LOT rows the Python one drops"
    # THE TYPED SORT AND ITS NULL PLACEMENT, asserted on what the ordering DOES rather than on one
    # spelling of it. This pinned the literal `try_cast(startdate as date) ASC NULLS LAST`, which
    # was a `dplyr::sql()` argument to window_order — and dbplyr 2.6.0 refuses `sql()` there
    # outright ("Element 1 is `<sql>`"), so that exact string could no longer run at all. The cast
    # is now materialised into `_lot_sd` (as Python's `_lot_sd` already was) and nulls-last is
    # carried by a flag column, because a NULL flag sorts FALSE before TRUE. Same rule, expressed
    # in what the backend accepts.
    assert 'dplyr::sql("try_cast(startdate as date)")' in r, (
        "the R engine's LOT ordering lost its cast — a raw-string sort is chronological only "
        "for pure ISO")
    assert "is.na(!!rlang::sym(k))" in r, (
        "the R engine's LOT ordering lost nulls-last: the flag column is what places NULL starts "
        "after dated rows now that `ASC NULLS LAST` cannot be passed to window_order")
    # ...and the tie-break REMAINDER, which R did not have at all. lot.py orders on the four keys
    # and then on every other column, because "two rows agreeing on all of them still swap
    # `new_lot_n`". Without this the two engines could number tied rows differently.
    assert "setdiff(colnames(lot), keyed)" in r, (
        "the R engine's LOT ordering dropped the tie-break remainder — it must order on the "
        "four keys AND then on every remaining column, as lot.py does")
    assert "NA_integer_" in r, "the R engine still numbers undated LOT rows"


def test_the_death_guard_reads_the_precap_follow_up_end_in_both_engines():
    """`fued` is clamped to death two expressions earlier, so a guard comparing against `fued`
    can essentially never fire — post-death activity, the exact corruption it exists to flag,
    was invisible. It must read the UNCAPPED preliminary end. `fued` itself is unchanged, and
    wiring the flag into OS/TTD/TTNT stays blocked on the open DTHFUFL ruling."""
    py = _src("engine/stages/clinical.py")
    assert 'AND dthdt < fu_enddt_preliminary THEN 1 ELSE 0 END' in py, (
        "dth_before_fued no longer reads the pre-cap value")
    assert "AND dthdt < fued THEN 1 ELSE 0 END" not in py, (
        "the guard compares against the capped fued again — it can never fire there")
    r = _src("engine-r/stages.R")
    assert "AND dthdt < fu_enddt_preliminary THEN 1 ELSE 0 END" in r, (
        "the R engine's guard still reads the capped value — parity diverges on exactly the "
        "corrupted-data inputs the guard exists for")


def test_greatest_and_least_are_never_handed_one_column_in_either_engine():
    """Spark refuses greatest()/least() below two arguments (WRONG_NUM_COLUMNS / WRONG_NUM_ARGS),
    so every variable-arity call site needs the same rule sources.py states for index_dates:
    a single present/configured column IS the max (or min). Four sites carried the latent edge —
    index_dates (R only; Python was already guarded), mcrpc_window, fu_enddt_preliminary (its
    zero-source guard did not cover ONE source), and minavaildate's outer least. The executable
    Python halves are in test_stages_spark.py; the R halves are Spark expressions this machine
    cannot execute, so the guard spelling is held on the source — both engines, per site, so
    they move together or this fails by name."""
    py_src = _src("engine/stages/sources.py")
    py = _src("engine/stages/clinical.py")
    r = _src("engine-r/stages.R")
    # index_dates materialisation (method: max)
    assert 'if rule.get("method", "max") == "max" and len(present) > 1' in py_src, (
        "sources.py lost the single-present-column guard on the index_dates greatest")
    assert '&& length(present) > 1' in r, (
        "the R index_dates materialisation builds greatest(one_column) for a single present "
        "column — WRONG_NUM_COLUMNS, and divergence from Python, which emits the column itself")
    # mcrpc_window: greatest over the configured columns
    assert "F.greatest(*mcols) if len(mcols) > 1 else F.col(mcols[0])" in py, (
        "clinical.py builds mcrpc's greatest unconditionally — a one-column mcrpc_window crashes")
    assert 'if (length(mcols) > 1) sprintf("greatest(' in r, (
        "the R mcrpc_window builds greatest(one_column) for a one-column config")
    # fu_enddt_preliminary: greatest over the PRESENT follow-up sources
    assert "F.greatest(*added) if len(added) > 1" in py, (
        "clinical.py guards only the ZERO-follow-up-source case — one present source hands "
        "greatest a single column")
    assert 'if (length(added) > 1) sprintf("greatest(' in r, (
        "the R follow-up end guards only the zero-source case")
    # minavaildate: the outer least over every contributing column
    assert 'if len(cols) > 1 else cols[0]' in py, (
        "clinical.py's minavaildate builds least(cols) for a single contributor")
    assert 'if (length(cols) > 1) sprintf("least(' in r, (
        "the R minavaildate builds least(one_column) for a single contributor")


def test_the_fued_cardinality_seam_refuses_what_nobody_has_ruled():
    """THE ENGINE HALF OF THE FUED/DTHDT STAGING. `follow_up_scope` is a closed vocabulary:
    absent means the incumbent per_index (an undecided pack stays byte-identical), an
    unrecognised word is refused rather than read as the nearest one, and `per_patient` —
    the candidate ruling — refuses with the checklist of what must be signed first, because
    building it now would mean this stage inventing the snap anchor and the negative-follow-up
    disposition, which are FUED-DEFINITION / OUTCOME-COHORT-MAP's rulings. The refusals fire
    BEFORE the Spark imports, which is why this test runs on a machine with none."""
    from engine.stages import clinical                                    # noqa: PLC0415
    assert clinical.FUED_SCOPES == ("per_index", "per_patient")
    try:
        clinical.follow_up_and_death(None, None, {"follow_up_scope": "per_patient"})
        raise AssertionError("per_patient was accepted with its ruling unsigned")
    except ValueError as e:
        msg = str(e)
        for needle in ("FUED-DEFINITION", "OUTCOME-COHORT-MAP", "last_lotenddate",
                       "negative durations"):
            assert needle in msg, (f"the refusal no longer names {needle!r} — the checklist "
                                   f"is the whole point of refusing", msg)
    try:
        clinical.follow_up_and_death(None, None, {"follow_up_scope": "per_pateint"})
        raise AssertionError("a typo'd scope was accepted")
    except ValueError as e:
        assert "is not one of" in str(e), e
    # absent and per_index both proceed PAST the guard — on this machine that means reaching
    # the pyspark import and failing there, which proves the guard let them through
    for cfg in ({}, {"follow_up_scope": "per_index"}):
        try:
            clinical.follow_up_and_death(None, None, cfg)
            raise AssertionError("unreachable on a machine without pyspark")
        except (ImportError, ModuleNotFoundError):
            pass
        except KeyError:
            pass                                     # pyspark present: it reached the config read
    # ...and the R engine refuses identically, or parity diverges on definitional inputs
    r = _src("engine-r/stages.R")
    assert 'identical(scope, "per_patient")' in r and "FUED-DEFINITION" in r, (
        "the R engine no longer mirrors the per_patient refusal")


def test_the_confirmed_derivations_are_implemented_and_selectable():
    """G-RWPFS AND G-TTNT-CROSS, IMPLEMENTED — the third state of these seams, and the audits
    wrote its history: first they refused as "awaiting a ruling" (re-litigating settled
    requirements), then as "not yet implemented" (true, briefly); now both branches exist as
    pure SQL builders, the vocab stays closed, and the incumbent stays the undeclared default
    so an unchanged pack is byte-identical.

    PURE-BUILDER ASSERTIONS on exact SQL, because that is what a machine with no Spark can hold:
    the contract branch's coalesce IS progression precedence, the null-on-censor date, the cross
    column inside the least() and the TTNTFL event arm. The UAT executes them; this pins them."""
    sys.path.insert(0, str(FRAMEWORK / "engine"))
    from stages import outcomes                                           # noqa: PLC0415
    # the seams accept their implemented values and still refuse an unrecognised word
    assert outcomes.pfs_semantics({"semantics": "contract"}) == "contract"
    assert outcomes.ttnt_scope({"ttnt_scope": "cross_setting"}) == "cross_setting"
    assert outcomes.pfs_semantics(None) == "incumbent"
    assert outcomes.ttnt_scope({}) == "same_setting"
    for fn, bad in ((outcomes.pfs_semantics, {"semantics": "contarct"}),
                    (outcomes.ttnt_scope, {"ttnt_scope": "cross"})):
        try:
            fn(bad)
            raise AssertionError("an unrecognised word was accepted")
        except ValueError as e:
            assert "is not one of" in str(e), e
    # rwPFS: precedence and null-on-censor are exactly these strings
    assert outcomes._pfs_event_sql("contract", "_prog1") == "coalesce(_prog1, dthdt)", (
        "the contract event is progression precedence — coalesce, never least")
    assert outcomes._pfs_event_sql("incumbent", "_prog1") == "least(_prog1, dthdt)"
    assert outcomes._pfs_date_sql("contract", "g", "_censor") == \
        "CASE WHEN g THEN _evt ELSE NULL END", "the contract PFSDT must be NULL on censor"
    assert "coalesce(_evt, _censor)" in outcomes._pfs_date_sql("incumbent", "g", "_censor")
    # TTNT: the cross column joins the least() and the TTNTFL event arm
    assert "least(lot2sd, xcol, dthdt)" in outcomes._ttnt_sql(1, "30.4", True, "xcol")
    assert "least(lot2sd, dthdt)" in outcomes._ttnt_sql(1, "30.4", True, None), (
        "no cross column must mean same-setting behavior, unchanged")
    assert "xcol IS NOT NULL" in outcomes._ttntfl_sql(1, "xcol")
    assert "IS NOT NULL" not in outcomes._ttntfl_sql(1)
    # ...and the build actually consumes all of it — builders wired, guard gated, R alive
    src = _src("engine/stages/outcomes.py")
    for needle in ("_pfs_event_sql(semantics, prog)", "_pfs_date_sql(semantics, gate",
                   "_ttnt_sql(ln, dpm, has_next, cross_col)", "_ttntfl_sql(ln, cross_col)",
                   '"dth_before_fued")', "CASE WHEN dth_before_fued = 1 THEN NULL"):
        assert needle in src, f"outcomes.build no longer wires: {needle}"
    # TSST is DELIBERATELY outside the guard gate — auto-applying would be this stage ruling
    # what ENGINE_GAPS routes to OUTCOME-COHORT-MAP
    gate_block = src.split("CASE WHEN dth_before_fued = 1 THEN NULL")[0].rsplit("for _c in", 1)[1]
    assert "tsst" not in gate_block, "TSST joined the guard gate without its ruling"
    r = _src("engine-r/stages.R")
    assert r.count("outcomes_seams_check") >= 2 and "outcomes_seams_check(cfg_pack" in r
    # Probe wave 8: the text count above passed while the DEFINITION sat inside outcomes_build's
    # body — called on entry before the local assignment ran, every R outcomes build died with
    # "could not find function". Depth is what text search missed: the definition must open at
    # brace depth ZERO, top level of the file.
    depth, def_depth = 0, None
    for line in r.splitlines():
        if line.startswith("outcomes_seams_check <- function"):
            def_depth = depth
        code = _re.sub("'[^']*'|" + chr(34) + "[^" + chr(34) + "]*" + chr(34), "",
                       line).split("#", 1)[0]
        depth += code.count("{") - code.count("}")
    assert def_depth == 0, (
        f"outcomes_seams_check is defined at brace depth {def_depth} — nested inside a "
        "function body it does not exist when outcomes_build's entry call runs")
    # ...and the validator must not refuse the values both engines implement: staging-era
    # refusals of contract/cross_setting surviving into the implemented world would make the
    # R engine reject exactly the configurations the requirements confirm.
    fn_body = r.split("outcomes_seams_check <- function", 1)[1].split(chr(10) + "}", 1)[0]
    assert "is declared and its ruling is not" not in fn_body, (
        "the R seam validator still refuses implemented contract/cross_setting values")
    for vocab in ('c("same_setting", "cross_setting")', 'c("incumbent", "contract")'):
        assert vocab in fn_body, f"the closed vocabulary fell out of the R validator: {vocab}"
    for needle in ("ttnt_sql(ln, dpm, has_next, cross_col)", "ttntfl_sql(ln, cross_col)",
                   'identical(pfs_sem, "contract")', "CASE WHEN dth_before_fued = 1 THEN NULL"):
        assert needle in r, f"stages.R no longer mirrors: {needle}"
    rc = _src("engine-r/cases.R")
    assert "cross_col = NULL" in rc, "cases.R builders lost the cross parameter"


def test_the_first_buildout_tranche_holds_in_both_engines():
    """Three spec-resolved gaps closed in lockstep (G-ETHNICITY-OR, G-LOTN-ZERO, G-TTD-PLUS1).
    Each pin here is the half a text-diff reviewer would miss: the OR reads the RAW race value
    (eth is built BEFORE race overwrites it, in both engines), the flag stays entry-scoped, the
    coalesce is in both engines, and the +1 moved in both at once."""
    from engine.stages.demographics import _map_case                      # noqa: PLC0415
    rows = [{"code": 1, "label": "H", "from": ["hispanic or latino"], "or_column": "race"},
            {"code": 2, "label": "N", "from": ["x"]}]
    sql = _map_case(rows, "ethnicity")
    assert "OR LOWER(race) IN ('hispanic or latino')" in sql
    assert sql.count("OR LOWER(race)") == 1, "or_column leaked beyond its entry"
    dsrc = _src("engine/stages/demographics.py")
    chain = dsrc.split("agegrln", 1)[1]
    assert chain.index('.withColumn("eth"') < chain.index('.withColumn("race"'), (
        "eth must be built BEFORE withColumn('race') overwrites the raw value the OR reads")
    rsrc = _src("engine-r/stages.R")
    rchain = rsrc.split("agegrln", 1)[1]
    assert rchain.index("eth     =") < rchain.index("race    ="), (
        "the R mutate lost the eth-before-race order dbplyr's sequential semantics require")
    # the config actually declares it — capability without the declaration closed nothing
    dem = _src("../fixtures/oncology/prostate/202606/variables/demographics.yaml")
    assert "or_column: race" in dem
    # G-LOTN-ZERO, both engines
    assert "F.coalesce(F.max(\"new_lot_n\").over(w), F.lit(0))" in _src(
        "engine/stages/treatment.py")
    assert "coalesce(max(new_lot_n) over (partition by patientid), 0)" in rsrc
    # G-TTD-PLUS1, both engines
    from engine.stages.outcomes import _ttd_sql                           # noqa: PLC0415
    assert _ttd_sql(2, "30.4375") == "(datediff(lot2ed, index_date)+1)/30.4375"
    assert '"(datediff(%s, index_date)+1)/%s"' in _src("engine-r/cases.R"), (
        "the R ttd_sql lost the inclusive day — the engines have diverged on a published value")


def test_the_second_buildout_tranche_holds_in_both_engines():
    """G-VITALS-DATES, G-MET-METDT and the G-STAGE-MISSING engine half, pinned where a text
    diff would miss the divergence: the tie direction, the boundary operator, the
    independent-of-flag date, and the nothing-invented guard - in BOTH engines."""
    c = _src("engine/stages/clinical.py")
    r = _src("engine-r/stages.R")
    # vitals: same-day tie -> HIGHEST, and the winning record's date rides beside the value
    assert 'F.col("testresultcleaned").desc_nulls_last()' in c
    assert "dplyr::desc(testresultcleaned)" in r
    for needle in ('F.col("vitaldate").alias("heightdt")', 'F.col("vitaldate").alias("weightdt")'):
        assert needle in c, needle
    assert "heightdt = vitaldate" in r and "weightdt = vitaldate" in r
    # metastasis: <= boundary (on-index counts), and _METDT independent of the flag
    assert "{date_col} <= index_date" in c and "%s <= index_date" in r
    assert '"dt") for it in blk["sites"]]' in c, "the per-site date agg fell out"
    assert 'paste0(it[["name"]], "dt")' in r
    met_block = c.split("def _metastatic_sites", 1)[1].split("def ", 2)[1]
    # the date agg has NO index condition - an after-index met keeps flag No, date emitted
    dt_agg = c.split('THEN {date_col} END', 1)
    assert len(dt_agg) == 2, "the _METDT CASE gained a condition beyond the site match"
    # stage: absent row -> ONLY a declared missing group; no declaration, no invention
    assert 'grp.get("when") == "missing"' in c and "if mg is not None:" in c
    assert 'identical(grp[["when"]], "missing")' in r
    # the emissions are advertised, so the published-surface check can see them
    v = _src("engine/validate.py")
    assert '{"height", "weight", "heightdt", "weightdt"}' in v
    assert '"dt")              # per-site earliest date' in v


def test_the_ecog_halves_hold_in_both_engines():
    """G-ECOG: the union with baseline precedence and the line-association filter, pinned in
    BOTH engines plus the declarations that arm them - and the label/config split that a
    string-vs-dict confusion almost shipped (cohort is the telemetry LABEL, cohort_cfg the
    declaration dict)."""
    c = _src("engine/stages/clinical.py")
    r = _src("engine-r/stages.R")
    for needle in ('cohort_cfg.get("ecog_line_match")', '{lm_col} = index_date',
                   'ecog_cfg.get("union_source")', 'F.col("_origin").asc()'):
        assert needle in c.replace("(cohort_cfg or {})", "cohort_cfg"), needle
    for needle in ('cohort[["ecog_line_match"]]', '%s = index_date', 'ecog_cfg[["union_source"]]',
                   "window_order(`_origin`"):
        assert needle in r, needle
    assert "cohort_cfg=cohort)" in _src("engine/build_ads.py"), (
        "build_ads no longer threads the cohort DICT beside the label")
    assert "clinical_build(src, idx, cfg, cohort)" in _src("engine-r/build_ads.R")
    # the declarations: five line cohorts + the block's line column, and preflight demands it
    dp = _src("../fixtures/oncology/prostate/202606/config/data_product.yaml")
    assert dp.count("ecog_line_match: true") == 5
    cl = _src("../fixtures/oncology/prostate/202606/variables/clinical.yaml")
    assert "line_match: { startdate_column: linestartdate }" in cl


def test_the_biomarker_resolve_mode_holds_in_both_engines():
    """G-BIOMARKER-CLOSEST engine half: the resolve mode exists in BOTH engines with the same
    array-sorted pair matching, the unruled-pair refusal, and the sdc parity gaps (refuse/max/
    priority value-ties) closed in R - plus the validator holding every part of the
    declaration, and prostate's flip honestly PARKED with its named blockers."""
    c = _src("engine/stages/clinical.py")
    r = _src("engine-r/stages.R")
    for needle in ('"resolve":', "def _resolve_then_pick", "array_sort(collect_set(_v))",
                   '== "resolve":'):
        assert needle in c, needle
    for needle in ("clinical_resolve_then_pick", "array_sort(collect_set(`_v`))",
                   'identical(isdc, "refuse")', 'identical(isdc, "max")',
                   'identical(isdc, "resolve")'):
        assert needle in r, needle
    from engine.stages.clinical import SAME_DATE_CONFLICT, selection_errors  # noqa: PLC0415
    assert "resolve" in SAME_DATE_CONFLICT
    assert selection_errors({}, {"conflict_rules": [{"between": ["a", "b"], "resolve": "a"}]}), (
        "rules nobody consults must be refused, not carried")
    cl = _src("../fixtures/oncology/prostate/202606/variables/clinical.yaml")
    assert "G-BIOMARKER-CLOSEST" in cl and "PARKED on BIOMARKER-WINDOW" in cl, (
        "the parked flip lost its stated blockers")


def test_the_lab_halves_hold_in_both_engines():
    """G-LABS: the later_of basis, the >0 exclusion, the component filter and undated-exists
    semantics, pinned in both engines plus the pack's declarations that arm them."""
    c = _src("engine/stages/clinical.py")
    r = _src("engine-r/stages.R")
    body = c.split("def _closest_values_panel", 1)[1].split("def baseline_ecog", 1)[0]
    # the ACTION lines, not the declarations around them — a control that gutted the filter
    # body while keeping its `if` passed the first version of these pins
    for needle in ('_record_date_expr(F, blk)', 'undated = pulled.filter',
                   'rows = rows.filter(F.col(vcol) > 0)',
                   'item.get("component")', '_named(undated).select'):
        assert needle in body, needle
    rbody = r.split("clinical_closest_values_panel <- function", 1)[1].split(
        "clinical_resolve_then_pick", 1)[0]
    for needle in ("record_date_sql(blk)", "undated <-",
                   'rows <- dplyr::filter(rows, dplyr::sql(sprintf("%s > 0", vcol)))',
                   'item[["component"]]',
                   "undated_named <- dplyr::filter(undated, dplyr::sql(named_pred))"):
        assert needle in rbody, needle
    cl = _src("../fixtures/oncology/prostate/202606/variables/clinical.yaml")
    assert "date_basis: { method: later_of, columns: [testdate, resultdate] }" in cl
    assert "positive_only: true" in cl and "component_column: labcomponent" in cl
    assert 'component: "Creatinine, serum"' in cl


def test_the_psa_anchor_holds_in_both_engines():
    """G-PSADIAG-CRPC: the per-point anchor, pinned at its action lines in both engines, plus
    the declaration that arms it and the passthrough it replaces staying gone."""
    c = _src("engine/stages/clinical.py")
    r = _src("engine-r/stages.R")
    for needle in ('af = (t.groupBy("patientid").agg(F.min(F.col(col)).alias("_anchor"))',
                   'frame = pulled.join(af, "patientid", "inner")',
                   'rows = frame.filter((F.col(date_col) >= F.expr(f"date_add({anch}, {lo})"))',
                   "F.abs(F.datediff(F.col(date_col), F.col(anch)))"):
        assert needle in c, needle
    for needle in ('`_anchor` = dplyr::sql(sprintf("min(%s)", col))',
                   '"%s >= date_add(%s, %s) AND %s <= date_add(%s, %s)"',
                   '"abs(datediff(%s, %s))", date_col, anch'):
        assert needle in r, needle
    cl = _src("../fixtures/oncology/prostate/202606/variables/clinical.yaml")
    assert "anchor: { source: enhanced, column: crpcdate }" in cl
    assert "column: psacrpcdiagnosis" not in cl, (
        "the passthrough the derivation replaces is still declared - two writers, one column")


def test_the_lot_setting_tranche_holds_in_both_engines():
    """G-PER-SETTING-LOT + G-SETTING-LOT-ED, pinned at the action lines in both engines, plus
    the declarations and the catalog codes that arm them."""
    c = _src("engine/stages/treatment.py")
    r = _src("engine-r/stages.R")
    for needle in ('n_lines = int(lines_cfg[setting])',
                   'epi = (de.filter(F.col("linesetting") == setting)',
                   '.agg(F.max("episodedate").alias("_ep_ed")))',
                   'F.coalesce(F.col("_ep_ed"), F.col("enddate"))',
                   '"_sl_ed" if a == "ed" else col_map[a]'):
        assert needle in c, needle
    for needle in ('as.integer(nlines_cfg[[setting]])',
                   'dplyr::sql(sprintf("linesetting = %s", .sql_str(setting)))',
                   '`_ep_ed` = dplyr::sql("max(episodedate)")',
                   'coalesce(`_ep_ed`, enddate)',
                   'if (identical(a, "ed")) "_sl_ed" else col_map[[a]]'):
        assert needle in r, needle
    ty = _src("../fixtures/oncology/prostate/202606/variables/treatment.yaml")
    assert "lines: { mHSPC: 2, mCRPC: 4 }" in ty and "attributes: [sd, ed, name]" in ty
    cat = _src("../products/metadata/catalog.yaml")
    for code in ("lot3sd_mcrpc", "lot4name_mcrpc", "lot1ed_mhspc"):
        assert f"code: {code}" in cat, f"the catalog lost {code}"


def test_the_prior_treatment_episode_model_holds_in_both_engines():
    """G-PRIOR-TX, pinned at the action lines in both engines: the strict `<`, the per-line
    monotherapy min, the within-one-line all_of, the category predicate, and the declarations
    that arm the model."""
    c = _src("engine/stages/treatment.py")
    r = _src("engine-r/stages.R")
    for needle in ('.filter(F.col(dc) < F.col("index_date")))',
                   'F.min(F.expr(f"CASE WHEN ({pred}) THEN 1 ELSE 0 END")).alias("_all")',
                   'pre.groupBy("patientid", "index_date", "linenumber").agg(*aggs)',
                   'pred = f"lower({cat_col}) = ' + "chr(39)" + '',
                   'return _prior_treatments_episode(F, trt, idx, src, ptcfg, yes, no)'):
        needle = needle.replace("chr(39)", chr(39))
        assert needle.split("chr")[0] in c, needle
    for needle in ('dplyr::filter(dplyr::sql(sprintf("%s < index_date", dc)))',
                   '"min(CASE WHEN (%s) THEN 1 ELSE 0 END)", pred',
                   'dplyr::group_by(patientid, index_date, linenumber)',
                   'return(treatment_prior_treatments_episode(trt, idx, src, ptcfg, yes, no))'):
        assert needle in r, needle
    ty = _src("../fixtures/oncology/prostate/202606/variables/treatment.yaml")
    for needle in ("source: drug_episode", "name_column: drugname",
                   "monotherapy: true", "category_equals: chemotherapy"):
        assert needle in ty, needle


def test_the_region_academic_override_holds_in_both_engines():
    """G-REGION-ACADEMIC, the last spec-resolved item: the override's action lines in both
    engines, the into-a-declared-group guard, the hard practice dependency, and the pack's
    declaration."""
    c = _src("engine/stages/demographics.py")
    r = _src("engine-r/stages.R")
    for needle in ('cond = f"UPPER(practicetype_agg) = {_q(str(val).upper())}"',
                   "CASE WHEN {cond} THEN {_q(str(grp['label']))} ELSE regionl END",
                   'f"region_practice_override: `into: {into}` names no regions "',
                   'required=bool(dem.get("region_practice_override"))'):
        assert needle in c, needle
    for needle in ('sprintf("UPPER(practicetype_agg) = %s", .sql_str(toupper(as.character(val))))',
                   '"CASE WHEN %s THEN %s ELSE regionl END", cond, .sql_str(as.character(grp[["label"]]))',
                   "names no regions group with that `when` role"):
        assert needle in r, needle
    dy = _src("../fixtures/oncology/prostate/202606/variables/demographics.yaml")
    assert "when_practice_agg: ACADEMIC" in dy and "into: fallthrough" in dy, (
        "the override must reference the group by ROLE - label/code declared exactly once")


def test_the_mhspcdd_family_is_declared_optional_not_hard_required():
    """G-MHSPCDD (config): the family passes through exactly as the ledger prescribed - and
    the load-bearing half is what preflight must NOT do: hspcdiagnosisdate may be
    loader-materialized, so a hard requirement would wrongly refuse a real delivery."""
    import types                                                          # noqa: PLC0415
    cl = _src("../fixtures/oncology/prostate/202606/variables/clinical.yaml")
    # probe wave 10's correction is the load-bearing pin: MHSPCDD is the SPEC's max() formula,
    # DERIVED - never a passthrough of a column nobody proved equivalent
    for needle in ("as: hspcdt,    optional: true", "as: mcrpctype, optional: true",
                   "as: mhspctype, optional: true",
                   'name: mhspcdd,   expr: "greatest(mpcdd, hspcdt)", requires: [mpcdd, hspcdt]',
                   'name: mhspcddyr, expr: "year(mhspcdd)", requires: [mhspcdd]'):
        assert needle in cl, needle
    assert "as: mhspcdd" not in cl, (
        "MHSPCDD went back to being a passthrough - the spec formula is a derivation")
    import sys as _s                                                      # noqa: PLC0415
    from pathlib import Path as _P                                        # noqa: PLC0415
    _s.path.insert(0, str(_P(__file__).resolve().parent.parent))
    from engine.config import load_config, product_config                 # noqa: PLC0415
    from engine import validate                                           # noqa: PLC0415
    cfg = load_config(product_config(_P(__file__).resolve().parent.parent.parent / "fixtures",
                                     "prostate"))
    req = validate.required_columns(cfg)
    # hspcdate IS hard-required - but by the INDEX MODEL (C1's index reads it), which is
    # correct and predates the passthrough; the optional flag means the PASSTHROUGH adds no
    # demand of its own. The loader-materialized column the ledger warned about was
    # hspcdiagnosisdate, which probe wave 10 retired from the config entirely.
    assert "hspcdate" in (req.get("enhanced") or [])
    assert "hspcdiagnosisdate" not in (req.get("enhanced") or [])
    em = validate.emitted_variables(cfg)
    assert {"mhspcdd", "mhspcddyr", "mcrpctype", "mhspctype"} <= em


if __name__ == "__main__":
    # CI RUNS EVERY SUITE AS A SCRIPT — without this block the file runs no tests and exits 0.
    fns = [v for k, v in sorted(globals().items()) if k.startswith("test_") and callable(v)]
    bad = 0
    for fn in fns:
        try:
            fn()
            print(f"  ok  {fn.__name__}")
        except Exception as e:                       # noqa: BLE001 - report and continue
            bad += 1
            print(f"FAIL  {fn.__name__}: {e}")
    print(f"\n{len(fns) - bad} of {len(fns)} passed")
    sys.exit(1 if bad else 0)
