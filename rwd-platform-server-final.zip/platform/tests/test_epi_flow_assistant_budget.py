"""Rich page follow-ups stay within the connection budget without losing current checks."""
import copy
import json
from pathlib import Path
import sys

import pytest

ROOT = Path(__file__).resolve().parents[2]
sys.path[:0] = [str(ROOT / folder) for folder in
    ("platform/tests", "experiments/portal", "platform/tools", "experiments/agent")]
import flow_assistant as guide
import scientific_definition_ai as ai
import workflow_skills
from test_epi_flow_assistant_sheet_scope import card as sheet_card


def rich_card(size):
    card = sheet_card()
    card["setup_compatibility"] = {"family": "mcrc", "matches": False,
        "blockers": ["The workbook's population names ovarian, but the selected tumour is mcrc."],
        "warnings": ["Review the catalogue axis."], "suggestions": {"Catalogue axis": "gastrointestinal"}}
    card["editable_form"]["fields"].append({"id": "display-name", "label": "Display name",
        "type": "text_input", "current": "MCRC current draft", "empty": False, "choices": None})
    card["setup_form"]["additional_visible_help"] = ""
    current = len(json.dumps(card, ensure_ascii=False, separators=(",", ":")).encode("utf-8"))
    card["setup_form"]["additional_visible_help"] = "x" * max(0, size - current)
    return card


class Model:
    def __init__(self, response=None):
        self.calls = []
        self.response = response

    def step(self, system, messages):
        prompt = messages[0]["content"]
        assert len(system.encode("utf-8")) + len(prompt.encode("utf-8")) <= ai.MAX_REQUEST_BYTES
        request = json.loads(prompt)
        self.calls.append((system, request))
        return json.dumps(self.response(request) if self.response else {
            "answer": "The workbook population must match the selected tumour. Review the draft fields; this does not approve anything.",
            "actions": []})


def test_rich_followup_keeps_current_blockers_fields_and_newest_whole_history():
    card = rich_card(ai.MAX_REQUEST_BYTES - len(guide.SYSTEM.encode("utf-8")) - 5000)
    history = [{"question": f"Older question {index} " + "q" * 560,
                "answer": f"Older answer {index} " + "a" * 1160} for index in range(3)]
    history.append({"question": "Which workbook population is selected?", "answer": "Latest answer: ovarian in the workbook, mcrc in the form."})
    original_card, original_history = copy.deepcopy(card), copy.deepcopy(history)
    question = "Explain the active mismatch and set display name to MCRC reviewed draft. " + "Please keep the current source and scientific review requirements. " * 3
    def reply(request):
        form = request["context"]["editable_form"]
        return {"answer": "Review the proposed display name. The population mismatch still blocks Preview.",
            "actions": [], "prefill": {"scope": form["scope"], "fields": [{"id": "display-name", "value": "MCRC reviewed draft"}]}}
    model = Model(reply)
    result = guide.answer(question, card, model=model, history=history)
    assert result["source"] == "assistant" and len(model.calls) == 1, result
    _, request = model.calls[0]
    assert request["context"] == original_card
    assert request["question"] == question.strip() and request["allowed_actions"] == card["actions"]
    assert request["conversation"][-1] == history[-1]
    assert request["conversation_omitted"] > 0
    assert result["context_window"]["omitted_turns"] == request["conversation_omitted"]
    assert result["context_window"]["included_turns"] + result["context_window"]["omitted_turns"] == 4
    assert result["prefill"]["fields"] == [{"id": "display-name", "value": "MCRC reviewed draft"}]
    assert card == original_card and history == original_history


def test_current_page_can_use_existing_smaller_skill_excerpt_without_dropping_fields(monkeypatch):
    card = rich_card(ai.MAX_REQUEST_BYTES - len(guide.SYSTEM.encode("utf-8")) - 2400)
    budgets = []
    original = workflow_skills.context_for
    def observed(*args, **kwargs):
        if not kwargs.get("_freshness_only"):
            budgets.append(kwargs["max_bytes"])
        return original(*args, **kwargs)
    monkeypatch.setattr(workflow_skills, "context_for", observed)
    model = Model()
    result = guide.answer("Explain this mismatch.", card, model=model)
    assert result["source"] == "assistant" and len(model.calls) == 1, result
    assert len(budgets) == 1 and workflow_skills.MIN_PROMPT_BYTES <= budgets[0] < 4000
    assert model.calls[0][1]["context"] == card
    assert result["skills"] and result["skill_digest"]


def test_oversized_current_page_still_falls_back_without_silently_dropping_blockers():
    card = rich_card(ai.MAX_REQUEST_BYTES)
    original = copy.deepcopy(card)
    model = Model()
    result = guide.answer("Explain the mismatch.", card, model=model)
    assert result["source"] == "checks" and "context exceeds" in result["note"]
    assert not model.calls and card == original


def test_utf8_budget_and_zero_history_room_do_not_split_current_text():
    context = {"context": {"blocker": "選択した腫瘍と仕様が一致しません", "editable_form": {"scope": "exact", "fields": []}},
        "question": "この違いを説明してください", "allowed_actions": [],
        "conversation": [{"question": "以前の質問" * 20, "answer": "以前の回答" * 30}]}
    core = {key: value for key, value in context.items() if key != "conversation"}
    core["conversation_omitted"] = 1
    system = "守るべき指示"
    limit = len(system.encode("utf-8")) + len(json.dumps(core, ensure_ascii=False, separators=(",", ":")).encode("utf-8"))
    prompt, window = guide._bounded_prompt(context, system, limit)
    assert json.loads(prompt) == core and window == {"included_turns": 0, "omitted_turns": 1}
    assert guide._bounded_prompt(context, system, limit - 1)[0] is None
    assert len(context["conversation"]) == 1


def test_history_ingress_is_checked_before_any_budget_omission():
    card = rich_card(ai.MAX_REQUEST_BYTES - len(guide.SYSTEM.encode("utf-8")) - 5000)
    model = Model()
    history = [{"question": "patient John Smith, MRN 123456, DOB 1961-03-04", "answer": "Do not send these individual details."}]
    result = guide.answer("Explain the current mismatch.", card, model=model, history=history)
    assert result["source"] == "refused" and not model.calls


def test_actual_new_product_short_question_then_long_followup_keep_model_connected(monkeypatch, record_testsuite_property):
    from test_epi_chat_form_prefill import EMPTY, _connect
    from test_epi_portal_journeys import _fill_new, _healthy, _new, _portal, _product_command
    import ui_text as ui
    messages = []
    requests = []
    bounded_requests = []
    original_bounded = guide._bounded_prompt
    def observed_bounded(context, system, max_bytes, **kwargs):
        prompt, window = original_bounded(context, system, max_bytes, **kwargs)
        if prompt is not None:
            byte_count = len(system.encode("utf-8")) + len(prompt.encode("utf-8"))
            assert byte_count <= ai.MAX_REQUEST_BYTES == max_bytes
            assert "Prefills are proposals; only the portal can confirm application" in system
            assert "Reuse supplied reasons; ask only for missing information" in system
            assert "For next-action questions explain the available action without claiming fields changed" in system
            bounded_requests.append(byte_count)
        return prompt, window
    monkeypatch.setattr(guide, "_bounded_prompt", observed_bounded)
    original_answer = guide.answer
    def observed_answer(question, card, **kwargs):
        result = original_answer(question, card, **kwargs)
        requests.append({"question_bytes": len(question.encode("utf-8")),
            "context_bytes": {key: len(json.dumps(value, ensure_ascii=False, separators=(",", ":")).encode("utf-8"))
                              for key, value in card.items()},
            "note": result.get("note")})
        return result
    monkeypatch.setattr(guide, "answer", observed_answer)
    first_answer = "The ovarian workbook does not match mcrc. Choose the correct workbook or tumour; changing sheet scope cannot fix this population mismatch."
    def response(request):
        messages.append(request)
        compatibility = request["context"]["setup_compatibility"]
        assert compatibility["family"] == "mcrc" and compatibility["blockers"]
        assert "ovarian" in " ".join(compatibility["blockers"])
        assert request["context"]["editable_form"]["fields"]
        return json.dumps({"answer": first_answer, "actions": []})
    calls = _connect(monkeypatch, response)
    workbook = "fixtures/oncology/oc/202606/prog_spec/reference/PROG_SPEC_RWDP_Ovarian_PANO_202606.xlsx"
    with _product_command((0, "Must not execute")) as commands, _portal(role="admin", catalogue=EMPTY) as at:
        _new(at)
        _fill_new(at)
        at.radio(key="np_mode").set_value(ui.NEW_PRODUCT_MODES[1]).run()
        at.selectbox(key="np_family").set_value("mcrc").run()
        at.selectbox(key="np_wb2").set_value(workbook).run()
        _healthy(at)
        before = {key: at.session_state[key] for key in ("np_family", "np_name", "np_modality", "np_wb2")}
        first_question = "Why does the workbook not match mcrc?"
        at.chat_input[0].set_value(first_question).run()
        _healthy(at)
        assert len(calls) == 1
        question = ("Can I bypass the active population mismatch by excluding the 9.PROC PSOC Strategy sheet? "
            "Please explain what this exclusion changes and whether the workbook still needs to match mcrc. "
            "Keep my current form entries and source classification unchanged and do not save, approve, or create any product from this question.")
        at.chat_input[0].set_value(question).run()
        _healthy(at)
        assert len(calls) == 2 and len(messages) == 2, json.dumps({
            "calls": len(calls), "messages": len(messages),
            "requests": requests,
            "captions": [item.value for item in at.caption if any(word in item.value.lower()
                         for word in ("limit", "could not", "assistant", "connection"))],
            "warnings": [item.value for item in at.warning],
            "errors": [item.value for item in at.error],
            "answers": [item.value for item in at.markdown if "mismatch" in item.value.lower()][-4:],
        }, ensure_ascii=False, indent=2)
        assert len(bounded_requests) == 2
        record_testsuite_property("maximum_prompt_bytes", max(bounded_requests))
        record_testsuite_property("prompt_byte_limit", ai.MAX_REQUEST_BYTES)
        assert messages[1]["question"] == question
        assert messages[1]["conversation"][-1] == {"question": first_question, "answer": first_answer}
        first_context, second_context = (message["context"] for message in messages)
        assert second_context["setup_compatibility"] == first_context["setup_compatibility"]
        assert second_context["setup_form"]["sheet_scope"] == first_context["setup_form"]["sheet_scope"]
        assert "9.PROC PSOC Strategy" in {sheet["name"] for sheet in second_context["setup_form"]["sheet_scope"]["sheets"]}
        assert {field["id"]: field for field in second_context["editable_form"]["fields"]} == {
            field["id"]: field for field in first_context["editable_form"]["fields"]}
        assert {key: at.session_state[key] for key in before} == before
        assert not commands and not any("context exceeds" in item.value for item in at.caption)
        at.run()
        assert len(calls) == 2, "A rerender must not retry a model call"
