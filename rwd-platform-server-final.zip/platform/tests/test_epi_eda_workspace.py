"""Counts-only EDA artifact intake and branch references, with no Spark or products changed."""
from pathlib import Path
import copy
import json
import sys

import pytest
import yaml

ROOT = Path(__file__).resolve().parents[2]
sys.path[:0] = [str(ROOT / "experiments/portal"), str(ROOT / "platform/tools"), str(ROOT / "platform"), str(ROOT / "platform/tests")]
from _epi_gist_fixture import seed_gist, PACK
import eda_workspace as eda
from engine.config import load_config
from engine.grain import source_grain_gate

ACTOR = "eda-reviewer"


@pytest.fixture
def evidence(tmp_path, monkeypatch):
    root = tmp_path / "checkout"
    root.mkdir()
    product = seed_gist(root)
    pipeline = product / "config/pipeline.yaml"
    pipeline.write_text(yaml.safe_dump({"run": {"refresh": "2026q3", "source_schema": "vendor_delivery",
        "output_schema": "draft_results", "output_table": "gist_ads", "write_mode": "overwrite"}}), encoding="utf-8")
    restricted = tmp_path / "restricted"
    restricted.mkdir()
    monkeypatch.setenv("RWD_PROFILE_DIR", str(restricted))
    monkeypatch.setenv("RWD_SOURCE_WORKSPACE_DIR", str(tmp_path / "private"))
    cfg = load_config(str(product / "config/data_product.yaml"))
    grain = {"enhanced": {"unique_by": ["patientid"], "rows": 12, "duplicate_keys": 0, "duplicate_rows": 0, "passed": True}}
    report = {"pack": cfg.data_product_id,
        "classification": {"state": "restricted_derived", "note": "Synthetic counts for a disposable test."},
        "layers": {
            "inventory": {"enhanced": {"rows": 12, "patients": 12, "null_patient_keys": 0, "columns": 5},
                          "lot": {"rows": 24, "patients": 10, "null_patient_keys": 0, "columns": 6}},
            "grain_keys": {**source_grain_gate(grain), "report": grain},
            "relationships": {"lot": {"overlap": 10, "index_only": 2, "source_only": 0, "max_rows_per_patient": 4}},
            "temporal": {"enhanced": {"advanced_diagnosis_date": {"null": 0, "unparseable": 0, "before_1900": 0, "after_study_end": 0}}},
            "funnel": {"stages": [{"cohort": "overall", "stage": "index", "index_patients": 12, "matched_patients": 12,
                "unmatched_index_patients": 0, "patients_outside_index": 0, "rows_out": 12, "max_rows_per_index_patient": 1}],
                "selections": [], "skipped": [], "observations": []},
            "ads_output": {"passed": True, "failures": [], "unconfigured": [], "report": {"n_rows": 12,
                "duplicate_keys": 0, "key_nulls": {"patientid": 0}, "compared": {"null_limits": 1}, "null_rate": {"patientid": 0.0}}},
        }}
    ads = report["layers"]["ads_output"]["report"]
    report["layers"]["ads_output"] = {**eda.output_contract.output_contract_gate(ads), "report": ads}
    raw, digest = eda.eda_report.serialized(report)
    report_path = restricted / "eda_report.json"
    report_path.write_bytes(raw)
    doc = eda.refresh.build_manifest(cfg, tumor="gist_program", family="oncology", counts={"total_rows": 12},
        qc={"passed": True}, source_qc_gate={"passed": True}, output_contract={"passed": True}, eda=report,
        config_identity={"config_bundle_sha256": eda.gates.config_bundle_sha256(str(product)),
                         "delivery_sha256": eda.gates.delivery_sha256(str(product))},
        run_mode={"env": "dev", "release_grade": False},
        artifacts={"eda_report": "dbfs:/restricted/123abc/eda_report.json", "eda_report_sha256": digest},
        artifact_types={"eda_report": "file"})
    doc["release"] = {"build_id": "123abc", "public": cfg.output_fqn, "version": cfg.output_fqn + "__2026q3__123abc",
                      "ads": cfg.output_fqn + "__candidate_123abc", "views": {cfg.output_fqn: cfg.output_fqn + "__candidate_123abc"}}
    receipt_path = root / "refreshes/oncology/gist_program/202606/2026q3.yaml"
    receipt_path.parent.mkdir(parents=True)
    receipt_path.write_text(yaml.safe_dump(doc), encoding="utf-8")
    assert eda.refresh.validate_manifest(doc) == []
    return {"root": root, "product": product, "path": report_path, "report": report,
            "doc": doc, "receipt_path": receipt_path, "receipt": receipt_path.relative_to(root).as_posix()}


def describe(e, **kwargs):
    return eda.describe(e["root"], PACK, ACTOR, allowed_packs=[PACK], **kwargs)


def receive(e, **changes):
    args = dict(receipt=e["receipt"], report_name=e["path"].name,
                expected_digest=describe(e)["digest"], allowed_packs=[PACK])
    return eda.receive(e["root"], PACK, ACTOR, **(args | changes))


def rewrite(e, *, report=None, doc=None):
    if report is not None:
        e["report"] = report
        raw, digest = eda.eda_report.serialized(report)
        e["path"].write_bytes(raw)
        e["doc"]["eda"] = report
        e["doc"]["artifacts"]["eda_report_sha256"] = digest
    if doc is not None:
        e["doc"] = doc
    e["doc"]["candidate_verdict"] = eda.refresh.candidate_verdict(e["doc"])
    e["receipt_path"].write_text(yaml.safe_dump(e["doc"]), encoding="utf-8")


def save(e, received=None, **changes):
    received = received or receive(e)
    assert received["ok"], received
    args = dict(receipt=e["receipt"], report_name=e["path"].name, expected_digest=received["digest"],
        expected_review_id=received["review_id"], allowed_packs=[PACK], local_demo=True, can_write=True, confirmed=True)
    return eda.save_review(e["root"], PACK, ACTOR, **(args | changes))


def test_exact_canonical_artifact_displays_all_six_layers_without_computation(evidence):
    e = evidence
    baseline = describe(e)
    assert baseline["ok"], baseline
    assert baseline["selected"] is None and len(baseline["candidates"]) == 1
    result = receive(e)
    assert result["ok"], result
    assert [row["name"] for row in result["layers"]] == [name for name, _, _ in eda.LAYERS]
    assert all(row["rows"] for row in result["layers"])
    assert result["layers"][2]["rows"][0]["index only"] == 2
    assert result["acceptance"] is None
    assert not (e["product"] / eda.REVIEW_DIR).exists()


def test_explicit_save_is_metadata_only_reopens_and_is_idempotent(evidence):
    result = receive(evidence)
    saved = save(evidence, result)
    assert saved["ok"] and saved["changed"], saved
    path = evidence["root"] / saved["path"]
    text = path.read_text(encoding="utf-8")
    assert "report_sha256:" in text and "manifest_sha256:" in text
    assert not any(word in text for word in ("patients:", "layers:", "approved", "unmatched", "rows:"))
    again = eda.read(evidence["root"], PACK, "other-authorized-reader", saved["review_id"], allowed_packs=[PACK])
    assert again["ok"], again
    assert len(eda.recent(evidence["root"], PACK, ACTOR, allowed_packs=[PACK])) == 1
    assert save(evidence)["changed"] is False


@pytest.mark.parametrize("changes", [{"allowed_packs": []}, {"expected_digest": "stale"}, {"receipt": "../../other.yaml"},
    {"report_name": "../eda_report.json"}, {"report_name": "patient_data.csv"}])
def test_scope_path_and_freshness_refusals(evidence, changes):
    assert not receive(evidence, **changes)["ok"]


@pytest.mark.parametrize("changes", [{"can_write": False}, {"local_demo": False}, {"confirmed": False},
                                    {"expected_review_id": "wrong"}, {"allowed_packs": []}])
def test_branch_save_requires_explicit_authorized_current_review(evidence, changes):
    assert not save(evidence, **changes)["ok"]
    assert not (evidence["product"] / eda.REVIEW_DIR).exists()


@pytest.mark.parametrize("change", ["report_pack", "receipt_product", "config_digest", "source_schema", "refresh", "report_hash", "embedded", "classification"])
def test_wrong_product_delivery_or_artifact_binding_is_refused(evidence, change):
    e = evidence
    if change == "report_pack":
        report = copy.deepcopy(e["report"]); report["pack"] = "other_product"; rewrite(e, report=report)
    elif change == "classification":
        report = copy.deepcopy(e["report"]); report["classification"]["state"] = "public"; rewrite(e, report=report)
    else:
        doc = copy.deepcopy(e["doc"])
        if change == "receipt_product": doc["data_product_id"] = "other_product"
        if change == "config_digest": doc["config_identity"]["config_bundle_sha256"] = "a" * 64
        if change == "source_schema": doc["source_schema"] = "other_delivery"
        if change == "refresh": doc["refresh"] = "2026q4"
        if change == "report_hash": doc["artifacts"]["eda_report_sha256"] = "a" * 64
        if change == "embedded": doc["eda"]["layers"]["inventory"]["enhanced"]["rows"] = 900
        rewrite(e, doc=doc)
    assert not receive(e)["ok"]


@pytest.mark.parametrize("location,value", [("field", ["PATIENT_SECRET_SENTINEL"]), ("count", "PATIENT_SECRET_SENTINEL"),
    ("label", "PATIENT_SECRET_SENTINEL"), ("bool", True), ("negative", -2)])
def test_id_fields_and_noncount_payloads_cannot_escape_restricted_storage(evidence, location, value):
    report = copy.deepcopy(evidence["report"])
    if location == "field": report["layers"]["inventory"]["enhanced"]["patient_ids"] = value
    elif location == "label": report["layers"]["funnel"]["stages"][0]["cohort"] = value
    else: report["layers"]["inventory"]["enhanced"]["rows"] = value
    rewrite(evidence, report=report)
    result = receive(evidence)
    assert not result["ok"] and "PATIENT_SECRET_SENTINEL" not in json.dumps(result)


def test_free_text_and_unexpected_delivered_values_are_not_rendered_or_persisted(evidence):
    report = copy.deepcopy(evidence["report"])
    report["layers"]["ads_output"]["report"]["cohorts_unexpected"] = ["PATIENT_SECRET_SENTINEL"]
    ads = report["layers"]["ads_output"]["report"]
    report["layers"]["ads_output"] = {**eda.output_contract.output_contract_gate(ads), "report": ads}
    rewrite(evidence, report=report)
    result = receive(evidence)
    assert result["ok"], result
    assert "PATIENT_SECRET_SENTINEL" not in json.dumps(result)
    assert "failed" in result["layers"][-1]["state"]
    assert save(evidence, result)["ok"]


def test_missing_layers_and_skipped_checks_are_explicit(evidence):
    report = copy.deepcopy(evidence["report"])
    del report["layers"]["temporal"]
    report["layers"]["grain_keys"] = {"skipped": "no source_grain declared"}
    rewrite(evidence, report=report)
    result = receive(evidence)
    assert result["ok"], result
    assert result["layers"][1]["state"] == "not checked"
    assert result["layers"][3]["state"] == "not collected"


def test_canonical_acceptance_is_recomputed_not_trusted(evidence):
    e = evidence
    config_path = e["product"] / "config/data_product.yaml"
    config = yaml.safe_load(config_path.read_text(encoding="utf-8"))
    limits = {"required_roles": ["enhanced"], "max_rows_per_patient": {"lot": 2}}
    config["qc"] = {"eda_acceptance": limits}
    config_path.write_text(yaml.safe_dump(config), encoding="utf-8")
    e["doc"]["config_identity"] = {"config_bundle_sha256": eda.gates.config_bundle_sha256(str(e["product"])),
                                  "delivery_sha256": eda.gates.delivery_sha256(str(e["product"]))}
    report = copy.deepcopy(e["report"])
    report["acceptance"] = eda.eda_report.acceptance(report, limits)
    e["doc"]["eda_acceptance"] = report["acceptance"]
    rewrite(e, report=report)
    checked = receive(e)
    assert checked["ok"] and not checked["acceptance"]["passed"] and not checked["candidate_passed"], checked
    report["acceptance"] = {"passed": True, "failures": [], "unchecked": []}
    e["doc"]["eda_acceptance"] = report["acceptance"]
    rewrite(e, report=report)
    assert not receive(e)["ok"]


def test_saved_binding_refuses_changed_bytes_configuration_or_record(evidence):
    saved = save(evidence)
    assert saved["ok"], saved
    path = evidence["path"]
    original = path.read_bytes()
    path.write_bytes(original + b"\n")
    assert not eda.read(evidence["root"], PACK, ACTOR, saved["review_id"], allowed_packs=[PACK])["ok"]
    path.write_bytes(original)
    record_path = evidence["root"] / saved["path"]
    record = yaml.safe_load(record_path.read_text(encoding="utf-8")); record["state"] = "approved"
    record_path.write_text(yaml.safe_dump(record), encoding="utf-8")
    assert not eda.read(evidence["root"], PACK, ACTOR, saved["review_id"], allowed_packs=[PACK])["ok"]


def test_report_changes_during_canonical_checks_are_refused(evidence, monkeypatch):
    original = eda.refresh.validate_manifest
    def mutate(doc):
        result = original(doc)
        evidence["path"].write_bytes(evidence["path"].read_bytes() + b"\n")
        return result
    monkeypatch.setattr(eda.refresh, "validate_manifest", mutate)
    result = receive(evidence)
    assert not result["ok"] and "changed during review" in " ".join(result["errors"])


def test_same_name_concurrent_record_is_never_overwritten(evidence, monkeypatch):
    original = eda.os.link
    def collide(src, target):
        Path(target).write_text("other author work\n", encoding="utf-8")
        return original(src, target)
    monkeypatch.setattr(eda.os, "link", collide)
    result = save(evidence)
    assert not result["ok"]
    assert next((evidence["product"] / eda.REVIEW_DIR).glob("*.yaml")).read_text(encoding="utf-8") == "other author work\n"


@pytest.mark.parametrize("kind", ["file", " file "])
def test_foreign_refresh_artifact_is_refused_before_canonical_file_reader(evidence, monkeypatch, kind):
    foreign = evidence["root"] / "refreshes/oncology/other/202606/private.json"
    foreign.parent.mkdir(parents=True)
    foreign.write_text('{"private":"sentinel"}', encoding="utf-8")
    evidence["doc"]["artifacts"]["other_report"] = str(foreign)
    evidence["doc"]["artifact_types"]["other_report"] = kind
    rewrite(evidence, doc=evidence["doc"])
    def should_not_run(_):
        pytest.fail("canonical manifest reader ran before artifact scope preflight")
    monkeypatch.setattr(eda.refresh, "validate_manifest", should_not_run)
    result = receive(evidence)
    assert not result["ok"] and "scope" in " ".join(result["errors"])


@pytest.mark.parametrize("layer", ["grain_keys", "ads_output"])
def test_forged_composed_layer_summary_is_refused(evidence, layer):
    report = copy.deepcopy(evidence["report"])
    report["layers"][layer]["passed"] = False
    rewrite(evidence, report=report)
    assert not receive(evidence)["ok"]


def test_configuration_change_after_publication_rolls_back_only_own_record(evidence, monkeypatch):
    original = eda.os.link
    def mutate(src, target):
        original(src, target)
        config = evidence["product"] / "source_refs.yaml"
        config.write_bytes(config.read_bytes() + b"\n# concurrently changed\n")
    monkeypatch.setattr(eda.os, "link", mutate)
    assert not save(evidence)["ok"]
    assert not list((evidence["product"] / eda.REVIEW_DIR).glob("*.yaml"))


def test_cyclic_aliases_and_duplicate_json_fields_are_refused(evidence):
    original = evidence["receipt_path"].read_bytes()
    evidence["receipt_path"].write_bytes(b"recursive: &self [*self]\n")
    result = describe(evidence)
    assert not result["ok"]
    evidence["receipt_path"].write_bytes(original)
    evidence["path"].write_bytes(b'{"pack":"wrong", "pack":"gist_program_rwdp"}')
    assert not receive(evidence)["ok"]


def test_changed_adapter_cannot_be_read_as_the_builds_mapping(evidence):
    adapter = evidence["product"] / "config/source_adapters.yaml"
    adapter.write_text("dataset: revised_mapping\n", encoding="utf-8")
    result = receive(evidence)
    assert not result["ok"] and "adapter" in " ".join(result["errors"])


def test_canonical_required_source_columns_are_valid_count_labels(evidence):
    cfg = load_config(str(evidence["product"] / "config/data_product.yaml"))
    required = eda.validate.required_columns(cfg)
    role, columns = next((role, cols) for role, cols in required.items() if cols)
    column = sorted(columns)[0]
    report = copy.deepcopy(evidence["report"])
    report["layers"]["temporal"] = {role: {column: {"null": 0, "unparseable": 0, "before_1900": 0, "after_study_end": 0}}}
    rewrite(evidence, report=report)
    result = receive(evidence)
    assert result["ok"], result
    assert result["layers"][3]["rows"][0]["Column"] == column
