"""Regressions for the FOURTH external audit of 2026-09-02 (main @ 42d611b). Each fails on the
defect it names and passes on the fix.

  P1  the R lane hung after PASSING: timeout wrapped Rscript, not `| tee`; an orphan gateway
      held the pipe. Now: no pipe, output to file, orphans reaped, retry cleans up.
  P1  `superseded` receipts bypassed every released-record check (0 errors vs 28)
  P1  release docs: bundle variables bind at DEPLOY; promotion is a notebook parameter
  P1  raw widget ids reached artifact_root/mkdirs before validation
  P1  prod code authority: framework_root/config_path must resolve inside the deployed tree
  P2  wrong-shaped config containers raised deep inside the engine
  P2  strict placeholder scan covered variable packs only
  P2  schemas allowed three parts; bool passed as an identifier; composed names > 64 refused
  P2  source_union member schema/flag unchecked; duplicate members doubled rows
  P2  golden: falsy-but-not-None evidence skipped as pass; zero reference median suppressed
  P2  release schema declared 18 of 42 writer fields, additionalProperties unset
  P2  CI path filter omitted exported documents; MCP "" arguments normalised to {}
  P2  letter-led run ids omitted from discovery

NO PYTEST FIXTURES AND NO `parametrize` — CI runs every suite as a script.
"""
import copy
import json
import re
import sys
from pathlib import Path

FRAMEWORK = Path(__file__).resolve().parent.parent
ROOT = FRAMEWORK.parent
sys.path.insert(0, str(FRAMEWORK))
sys.path.insert(0, str(FRAMEWORK / "tools"))

from engine.config import Config, load_config, product_config  # noqa: E402
from engine import validate, refresh, golden  # noqa: E402

CONFIG = product_config(ROOT / "fixtures", "prostate")
AGENT = ROOT / "experiments" / "agent"
CI = (ROOT / ".github" / "workflows" / "rwdp-ci.yml").read_text(encoding="utf-8")


# ------------------------------------------------------------------ P1 R lane

def test_r_fixture_step_has_no_pipe_and_reaps_orphans():
    step = CI[CI.index("Run the stage dataflow fixture"):CI.index("Run stage conformance")]
    code = "\n".join(l for l in step.splitlines() if not l.strip().startswith("#"))
    assert "| tee" not in code, "a pipe lets an orphan JVM hold the step open"
    assert "> dataflow.out 2>&1" in step and "pkill -f 'sparklyr.Shell'" in step
    r = (FRAMEWORK / "tests" / "test_r_stage_dataflow.R").read_text(encoding="utf-8")
    assert ".reap_gateways()" in r and "spark_disconnect_all" in r
    # the retry cleans up BEFORE sleeping/retrying, and the script reaps before quit
    assert r.index(".reap_gateways()") < r.index("if (i < attempts) Sys.sleep")


# ------------------------------------------------------------------ P1 superseded receipts

def _six_field(status):
    return {"tumor": "prostate", "refresh": "2026q1", "spec_version": "202606",
            "built_at": "x", "status": status, "counts": {"n": 1}}


def test_superseded_receipt_keeps_released_requirements():
    rel = refresh.validate_manifest(_six_field("released"))
    sup = refresh.validate_manifest(_six_field("superseded"))
    assert len(rel) >= 5, rel
    assert len(sup) >= len(rel), (len(sup), len(rel))
    assert any("superseded_by" in p for p in sup), sup
    schema = json.loads((ROOT / "governance" / "schemas" / "release.schema.json").read_text(encoding="utf-8"))
    conds = [b["if"]["properties"]["status"] for b in schema["allOf"]]
    assert any(c.get("enum") == ["released", "superseded"] for c in conds), conds
    assert schema.get("additionalProperties") is False


def test_release_schema_mirrors_the_writer():
    src = (FRAMEWORK / "engine" / "refresh.py").read_text(encoding="utf-8")
    i = src.index("def build_manifest("); j = src.index("\ndef ", i + 10)
    keys = set(re.findall(r'^\s{8}"([a-z0-9_]+)":', src[i:j], re.M))   # digits too: tree_sha256 (audit 6)
    schema = json.loads((ROOT / "governance" / "schemas" / "release.schema.json").read_text(encoding="utf-8"))
    missing = keys - set(schema["properties"])
    assert not missing, f"writer emits fields the schema does not declare: {sorted(missing)}"


# ------------------------------------------------------------------ P1 release docs

def test_release_docs_bind_variables_at_deploy_and_promote_by_notebook_param():
    for p in ("databricks.yml", "refreshes/README.md", "products/OPERATIONS.md"):
        t = (ROOT / p).read_text(encoding="utf-8")
        assert "bundle run rwdp_build_<slug> -t prod --var" not in t, p
        assert "--var promote_build_id" not in t, p
    for p in ("databricks.yml", "refreshes/README.md"):
        assert "--notebook-params promote_build_id=" in (ROOT / p).read_text(encoding="utf-8"), p


# ------------------------------------------------------------------ P1 runner ingress and prod authority

def test_runner_validates_widget_ids_before_artifact_root_and_pins_prod_code_authority():
    src = (FRAMEWORK / "databricks" / "run_rwdp.py").read_text(encoding="utf-8")
    assert src.index("_unsafe_id(\"sql\", _val)") < src.index("dbutils.fs.mkdirs(artifact_root)")
    assert src.index("REFUSING: artifact_root") < src.index("dbutils.fs.mkdirs(artifact_root)")
    # audit 5 moved the code-authority check BEFORE the first import (self-derived trusted root,
    # any env) and bound the prod artifact root to a durable Volume/DBFS root
    assert "REFUSING before any import" in src and "_trusted_files" in src
    assert src.index("_trusted_files") < src.index("sys.path.insert(0, framework_root)")
    # audit 6 tightened the durable root to a CANONICAL Unity Catalog Volume path (bare dbfs:/ refused)
    assert "canonical Unity Catalog Volume path" in src and "_VOLUME_RE" in src


# ------------------------------------------------------------------ P2 config containers

def test_wrong_shaped_containers_fail_closed_with_the_key_named():
    raw = copy.deepcopy(load_config(CONFIG).raw)
    for key, bad in (("run", [1]), ("study", "x"), ("formats", 3), ("sources", []),
                     ("index_dates", "y"), ("vocabularies", 1), ("treatment_status", []),
                     ("golden", "z"), ("cohorts", {"a": 1})):
        r = copy.deepcopy(raw); r[key] = bad
        try:
            Config(r, ROOT)
        except ValueError as e:
            assert key in str(e) and "must be a" in str(e), (key, e)
        else:
            raise AssertionError(f"Config accepted {key}={bad!r}")


# ------------------------------------------------------------------ P2 placeholders anywhere

def test_placeholder_anywhere_in_resolved_config_is_a_strict_finding():
    for path in (("data_product_id",), ("cohorts", 0, "label")):
        cfg = copy.deepcopy(load_config(CONFIG))
        node = cfg.raw
        for k in path[:-1]:
            node = node[k]
        node[path[-1]] = "REPLACE_ME"
        probs = validate.problems(cfg, strict=True)
        assert any("REPLACE_ME" in p and str(path[-1]) in p for p in probs), (path, probs)


# ------------------------------------------------------------------ P2 identifier rules agree

def test_schema_grammar_two_parts_bool_rejected_long_composed_names_allowed():
    assert refresh.unsafe_identifier("schema", "cat.schema") is None
    assert refresh.unsafe_identifier("schema", "cat.schema.extra")
    assert refresh.unsafe_identifier("sql", True)
    assert refresh.unsafe_identifier("dotted", "out.ads__2026q1__" + "x" * 80) is None
    cfg = copy.deepcopy(load_config(CONFIG)); cfg.run["output_schema"] = "a.b.c"
    assert any("run.output_schema" in p for p in validate.problems(cfg, strict=True))


def test_source_union_members_are_validated_and_deduplicated():
    cfg = copy.deepcopy(load_config(CONFIG))
    cfg.raw["source_union"] = {"members": [
        {"schema": "safe;DROP TABLE x", "flag": "a.b"},
        {"schema": "ok_schema", "flag": "f1"},
        {"schema": "ok_schema", "flag": "f1"}]}
    probs = validate.problems(cfg, strict=False)
    assert any("members[0].schema" in p for p in probs), probs
    assert any("members[0].flag" in p for p in probs), probs
    assert any("duplicates an earlier member" in p for p in probs), probs


# ------------------------------------------------------------------ P2 golden

def test_falsy_non_none_evidence_fails_and_zero_reference_median_fails():
    for bad in ([], "", 0, False):
        r = golden.golden_gate(bad)
        assert not r["passed"] and not r.get("skipped"), (bad, r)
    assert golden.golden_gate(None).get("skipped")
    r = golden.golden_gate({"n_rows": {"new": 100, "ref": 100},
                            "os_summary": {"new": {"median": 5.0}, "ref": {"median": 0}}})
    assert not r["passed"] and any("reference median is 0" in f for f in r["failures"]), r


# ------------------------------------------------------------------ P2 CI paths, MCP, discovery

def test_ci_paths_cover_exported_documents():
    assert '"**/*.docx"' in CI and '"**/*.pptx"' in CI and '"**/*.pdf"' in CI


def test_empty_string_arguments_are_invalid_params():
    import mcp_server  # noqa: PLC0415
    for args in ("", [], 0):
        r = mcp_server._handle({"jsonrpc": "2.0", "id": 1, "method": "tools/call",
                                "params": {"name": "search", "arguments": args}})
        assert r["error"]["code"] == -32602, (args, r)


def test_discovery_includes_letter_led_run_ids():
    # escalation_net.py no longer discovers runs itself: real-data training is train_all.py's (audit 6)
    for p in (AGENT / "evals" / "run.py", AGENT / "ml" / "features.py"):
        src = p.read_text(encoding="utf-8")
        assert "[0-9]*.json" not in src and '"scorecard"' in src and '"*.json"' in src, p.name


if __name__ == "__main__":
    fails = 0
    for name, fn in sorted(globals().items()):
        if name.startswith("test_") and callable(fn):
            try:
                fn()
                print(f"  ok   {name}")
            except Exception as e:  # noqa: BLE001
                fails += 1
                print(f"  FAIL {name}: {e}")
    print(f"{fails} failure(s)")
    sys.exit(1 if fails else 0)
