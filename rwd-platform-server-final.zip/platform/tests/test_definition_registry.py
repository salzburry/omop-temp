"""Programme items 2 and 3 — analytical definition ids (governance/DEFINITIONS.yaml,
platform/tools/definition_registry.py) and the implementations a dataset claims for them
(<pack>/config/implementations.yaml).

    python3 platform/tests/test_definition_registry.py
"""
import io
import os
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

FRAMEWORK = Path(__file__).resolve().parent.parent
ROOT = FRAMEWORK.parent
TOOLS = FRAMEWORK / "tools"
sys.path.insert(0, str(TOOLS))
os.environ.setdefault("ANTHROPIC_API_KEY", "not-a-key-tests-never-call")
import definition_registry as dr                                             # noqa: E402

PROSTATE = "fixtures/oncology/prostate/202606"
PERSON, DATE = "Priya Natarajan", "2026-09-05"


def _root_with(entries, pack=PROSTATE, implementations=None):
    """A temp root: the register as given, the prostate fixture copied in (its config signs
    ECOG_PS and BMI_BSA), optionally an implementations file."""
    import yaml
    tmp = tempfile.mkdtemp(prefix="defreg_")
    os.makedirs(os.path.join(tmp, "governance"))
    Path(tmp, "governance", "DEFINITIONS.yaml").write_text(yaml.safe_dump({"definitions": entries}), encoding="utf-8")
    dst = os.path.join(tmp, pack)
    shutil.copytree(ROOT / pack, dst, ignore=shutil.ignore_patterns("__pycache__"))
    shutil.copy(ROOT / "products" / "registry.yaml", os.path.join(tmp, "products", "registry.yaml")) if os.path.isdir(os.path.join(tmp, "products")) else None
    if implementations is not None:
        Path(dst, "config", "implementations.yaml").write_text(yaml.safe_dump(implementations, sort_keys=False), encoding="utf-8")
    return tmp


def _entry(**over):
    sig = dict(dr.signed(PROSTATE, str(ROOT)))["ECOG_PS"]
    base = {"definition_id": "RWDP:ECOG_PS:v1", "master": "ECOG_PS", "concept": "C1512162",
            "signature_sha256": sig, "registered_by": PERSON, "registration_date": DATE, "supersedes": "none",
            "note": "ECOG closest to index inside the configured window; worst grade on a tie"}
    base.update(over)
    return base


def test_the_live_register_and_every_pack_check_clean_and_the_fixture_signs_unregistered_definitions():
    assert dr.check(str(ROOT)) == [], dr.check(str(ROOT))[:3]
    # The unregistered scenario is fixture state, not a restriction that the
    # user's actual register must remain empty after a reviewed registration.
    root = _root_with([])
    try:
        res = dr.resolve(PROSTATE, root)
        assert {"ECOG_PS", "BMI_BSA"} <= set(res) and all(v is None for v in res.values()), res
        text = dr.propose(PROSTATE, root)
        assert "definition_id: RWDP:ECOG_PS:v1" in text and "signature_sha256:" in text and "registered_by: TODO" in text
        assert dr.pack_errors(PROSTATE, root) and "--propose" in dr.pack_errors(PROSTATE, root)[0]
    finally:
        shutil.rmtree(root, ignore_errors=True)


def test_a_registered_definition_resolves_by_signature_and_says_who_supports_it():
    root = _root_with([_entry()])
    try:
        assert dr.register_errors(root) == []
        res = dr.resolve(PROSTATE, root)
        assert res["ECOG_PS"] == "RWDP:ECOG_PS:v1" and res.get("BMI_BSA") is None
        assert dr.unregistered(PROSTATE, root) == ["BMI_BSA"]
        who = dr.supports("RWDP:ECOG_PS:v1", root)
        assert who["packs"] == [PROSTATE] and who["datasets"] == [], who
        assert dr.supports("RWDP:NOPE:v1", root) is None
        assert "RWDP:BMI_BSA:v1" in dr.propose(PROSTATE, root) and "RWDP:ECOG_PS" not in dr.propose(PROSTATE, root)
    finally:
        shutil.rmtree(root, ignore_errors=True)


def test_the_register_refuses_what_a_mint_once_register_must_refuse():
    sig = dict(dr.signed(PROSTATE, str(ROOT)))["ECOG_PS"]
    cases = {
        "minted twice":            [_entry(), _entry()],
        "not <NAMESPACE>:<MASTER>:v<n>": [_entry(definition_id="ecog-v1")],
        "disagrees with the id's family": [_entry(master="BMI_BSA")],
        "not a master family":     [_entry(definition_id="RWDP:NOT_A_FAMILY:v1", master="NOT_A_FAMILY")],
        "not a UMLS CUI":          [_entry(concept="ECOG")],
        "not 64 hex":              [_entry(signature_sha256="abc")],
        "registered_by":           [_entry(registered_by="the science team")],
        "registration_date":       [_entry(registration_date="2027-01-01")],
        "which is not registered": [_entry(supersedes="RWDP:ECOG_PS:v0")],
        "a definition of another family": [_entry(), _entry(definition_id="RWDP:BMI_BSA:v2", master="BMI_BSA", supersedes="RWDP:ECOG_PS:v1",
                                                            signature_sha256="f" * 64)],
        "not an earlier version":  [_entry(definition_id="RWDP:ECOG_PS:v2", signature_sha256="e" * 64),
                                    _entry(definition_id="RWDP:ECOG_PS:v3", supersedes="RWDP:ECOG_PS:v2", signature_sha256="d" * 64),
                                    _entry(definition_id="RWDP:ECOG_PS:v1", supersedes="RWDP:ECOG_PS:v3", signature_sha256="c" * 64)],
        "a restatement is not a new version": [_entry(), _entry(definition_id="RWDP:ECOG_PS:v2", supersedes="RWDP:ECOG_PS:v1", signature_sha256=sig)],
    }
    for needle, entries in cases.items():
        root = _root_with(entries)
        try:
            errs = dr.register_errors(root)
            assert any(needle in e for e in errs), (needle, errs)
        finally:
            shutil.rmtree(root, ignore_errors=True)
    root = _root_with([_entry(definition_id="RWDP:ECOG_PS:v1"), _entry(definition_id="RWDP:ECOG_PS:v2", supersedes="RWDP:ECOG_PS:v1", signature_sha256="b" * 64)])
    try:
        assert dr.register_errors(root) == []
        assert [e["definition_id"] for e in dr.current(dr.read(root)[0])] == ["RWDP:ECOG_PS:v2"], "a superseded version is not current"
    finally:
        shutil.rmtree(root, ignore_errors=True)


def test_an_implementation_claims_a_registered_definition_for_a_contract_variable_over_declared_roles():
    good = {"dataset": "flatiron", "implements": [{"variable": "ECOG", "definition": "RWDP:ECOG_PS:v1",
                                                   "roles": ["baseline_ecog"], "reviewed_by": PERSON, "review_date": DATE}]}
    root = _root_with([_entry()], implementations=good)
    try:
        assert dr.implementation_errors(PROSTATE, root) == [], dr.implementation_errors(PROSTATE, root)
        who = dr.supports("RWDP:ECOG_PS:v1", root)
        assert who["datasets"] == [f"flatiron ({PROSTATE}: ECOG)"], who
        assert dr.check(root) == []
    finally:
        shutil.rmtree(root, ignore_errors=True)
    bad = {
        "is not registered":       dict(good, implements=[dict(good["implements"][0], definition="RWDP:ECOG_PS:v9")]),
        "is not a record in this pack's contract": dict(good, implements=[dict(good["implements"][0], variable="NOT_A_VARIABLE")]),
        "is not declared under sources": dict(good, implements=[dict(good["implements"][0], roles=["nope"])]),
        "reviewed_by":             dict(good, implements=[dict(good["implements"][0], reviewed_by="the team")]),
        "not one the schema":      dict(good, implementz=[]),
    }
    for needle, doc in bad.items():
        root = _root_with([_entry()], implementations=doc)
        try:
            errs = dr.implementation_errors(PROSTATE, root)
            assert any(needle in e for e in errs) or (needle == "not one the schema" and errs), (needle, errs)
        finally:
            shutil.rmtree(root, ignore_errors=True)
    # the claim and the configuration disagree: the config signs v1, the file claims v2
    root = _root_with([_entry(), _entry(definition_id="RWDP:ECOG_PS:v2", supersedes="RWDP:ECOG_PS:v1", signature_sha256="a" * 64)],
                      implementations=dict(good, implements=[dict(good["implements"][0], definition="RWDP:ECOG_PS:v2")]))
    try:
        errs = dr.implementation_errors(PROSTATE, root)
        assert any("the claim and the config disagree" in e for e in errs), errs
        errs2 = dr.implementation_errors(PROSTATE, _root_with([_entry(), _entry(definition_id="RWDP:ECOG_PS:v2", supersedes="RWDP:ECOG_PS:v1", signature_sha256="a" * 64)],
                                                               implementations=good))
        assert any("is superseded" in e for e in errs2), errs2
    finally:
        shutil.rmtree(root, ignore_errors=True)


def test_gate_4_refuses_an_approved_configuration_whose_signed_definitions_are_unregistered_or_superseded():
    """Advisory below `configuration: approved`, refused AT it: a released definition nobody named
    cannot be reused, so the approval that releases it is where the register is consulted. The
    refusal is Gate 4's by construction (configuration_approval_errors owns it, status attributes
    it), and a registered, current definition adds nothing."""
    import product_gates as pg
    import status as st
    ecog = dict(dr.signed(PROSTATE, str(ROOT)))["ECOG_PS"]
    bmi = dict(dr.signed(PROSTATE, str(ROOT)))["BMI_BSA"]
    both = [_entry(), _entry(definition_id="RWDP:BMI_BSA:v1", master="BMI_BSA", signature_sha256=bmi,
                            concept="C1305855")]
    cases = [
        ("nothing registered", [], "not in governance/DEFINITIONS.yaml"),
        ("one of two registered", [_entry()], "BMI_BSA"),
        ("ECOG superseded", both + [_entry(definition_id="RWDP:ECOG_PS:v2", signature_sha256="e" * 64,
                                           supersedes="RWDP:ECOG_PS:v1")], "superseded by RWDP:ECOG_PS:v2"),
        ("both registered and current", both, None),
    ]
    for name, entries, needle in cases:
        root = _root_with(entries)
        pack = os.path.join(root, PROSTATE)
        try:
            m = {"configuration": "approved", "contract": "approved"}
            below = [e for e in pg.configuration_approval_errors(pack, PROSTATE, dict(m, configuration="draft"))
                     if "definition" in e]
            assert below == [], ("below approved the register is advisory", name, below)
            about = [e for e in pg.configuration_approval_errors(pack, PROSTATE, m) if "definition" in e]
            if needle is None:
                assert about == [], (name, about)
            else:
                assert about and needle in about[0].replace("\\", "/") and about[0].startswith(PROSTATE), (name, about)
            if name == "nothing registered":
                # the same line stands under GATE 4 on the status page, attributed and not unattributed
                import yaml
                mp = os.path.join(pack, "handoff", "MATURITY.yaml")
                doc = yaml.safe_load(open(mp, encoding="utf-8")) or {}
                doc.update(m)
                io.open(mp, "w", encoding="utf-8").write(yaml.safe_dump(doc))
                g = {n: (state, why) for n, _title, state, why in st.gates(root, PROSTATE)}
                assert g[4][0] != "done" and any("DEFINITIONS.yaml" in w for w in g[4][1]), g[4]
                assert not any("DEFINITIONS.yaml" in w for n in (1, 2, 3, 5, 6) for w in g[n][1]), \
                    "the definition refusal belongs to Gate 4 alone"
        finally:
            shutil.rmtree(root, ignore_errors=True)
    # an implementation claim that does not resolve is refused at the same level, by name
    claim = {"dataset": "flatiron", "implements": [{"variable": "ECOG", "definition": "RWDP:ECOG_PS:v9",
                                                    "roles": ["baseline_ecog"], "reviewed_by": PERSON, "review_date": DATE}]}
    root = _root_with(both, implementations=claim)
    pack = os.path.join(root, PROSTATE)
    try:
        m = {"configuration": "approved", "contract": "approved"}
        assert [e for e in pg.configuration_approval_errors(pack, PROSTATE, dict(m, configuration="draft"))
                if "implements[" in e] == []
        about = [e for e in pg.configuration_approval_errors(pack, PROSTATE, m) if "implements[" in e]
        assert about and "not registered" in about[0] and about[0].replace("\\", "/").startswith(f"{PROSTATE}/config/implementations.yaml"), about
    finally:
        shutil.rmtree(root, ignore_errors=True)


def test_the_cli_checks_lists_and_answers_who_supports():
    r = subprocess.run([sys.executable, str(TOOLS / "definition_registry.py"), "--check"], cwd=str(ROOT), capture_output=True,
                       text=True, encoding="utf-8", errors="replace", timeout=600)
    assert r.returncode == 0 and "0 definition register problem(s)" in r.stdout, r.stdout[-300:] + r.stderr[-300:]
    root = _root_with([_entry()])
    try:
        for argv, needle in ((["--list"], "RWDP:ECOG_PS:v1"), (["--supports", "RWDP:ECOG_PS:v1"], PROSTATE),
                             (["--resolve", PROSTATE], "RWDP:ECOG_PS:v1"), (["--propose-implementations", PROSTATE], "definition: RWDP:ECOG_PS:v1")):
            r = subprocess.run([sys.executable, str(TOOLS / "definition_registry.py"), *argv, "--root", root], cwd=str(ROOT),
                               capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=600)
            assert r.returncode == 0 and needle in r.stdout, (argv, r.stdout[-400:], r.stderr[-400:])
        r = subprocess.run([sys.executable, str(TOOLS / "definition_registry.py"), "--supports", "RWDP:NOPE:v1", "--root", root],
                           cwd=str(ROOT), capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=600)
        assert r.returncode != 0 and "not a registered definition" in r.stdout
    finally:
        shutil.rmtree(root, ignore_errors=True)


if __name__ == "__main__":
    os.chdir(FRAMEWORK)
    failed = 0
    for name, fn in sorted(globals().items()):
        if name.startswith("test_") and callable(fn):
            try:
                fn()
                print(f"  ok   {name}")
            except Exception as e:                                           # noqa: BLE001
                failed += 1
                print(f"  FAIL {name}: {type(e).__name__}: {str(e)[:700]}")
    print(f"{failed} failure(s)")
    sys.exit(1 if failed else 0)
