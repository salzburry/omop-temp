"""A reviewed answer continues through the selected provider and existing owner rules."""
import json
from pathlib import Path
import sys

import pytest

ROOT = Path(__file__).resolve().parents[2]
sys.path[:0] = [str(ROOT / 'platform/tests'), str(ROOT / 'experiments/portal'),
               str(ROOT / 'experiments/agent'), str(ROOT / 'platform/tools')]
from test_epi_portal_journeys import _portal, _healthy
from test_epi_portal_agent_connection_page import open_agent
from test_epi_portal_agent_connection import Client, configured
import scientific_definition_ai as ai
import orchestrator
import state


@pytest.fixture(autouse=True)
def no_fallback(monkeypatch):
    monkeypatch.setenv('RWD_PORTAL_AI_PROVIDER', 'vscode')
    monkeypatch.setattr(ai, '_make_model', lambda *_: pytest.fail('No API fallback is permitted'))
    monkeypatch.setattr(orchestrator, 'AnthropicModel', lambda *_a, **_kw: pytest.fail('No default model is permitted'))
    yield
    ai.set_provider_selection(None)


def queued(at, owner='Science'):
    open_agent(at)
    actor, pack = next(iter(at.session_state['intakes']))
    run = state.RunState(f'Inspect the definitions in {pack}', actor={'name': 'Requesting scientist'})
    run.primary_pack = pack
    run.finish('escalated', json.dumps({'to': owner, 'question': 'Which definition needs review?',
                                       'evidence': 'No scientific definition was selected.'}))
    at.radio(key='section').set_value('Waiting on a person').run()
    _healthy(at)
    assert at.selectbox(key='esc_pick').value == run.run_id
    return run


@pytest.mark.parametrize('provider', ['vscode', 'claude_code'])
def test_queue_continues_selected_provider_and_preserves_answer_review(monkeypatch, provider):
    client = Client(json.dumps({'action': 'escalate', 'to': 'Science',
        'question': 'Confirm this definition in the scientific workflow.', 'evidence': 'A person supplied context.'}))
    monkeypatch.setattr(ai, '_provider', lambda *_a, **_kw: configured(client, provider))
    with _portal(role='admin') as at:
        run = queued(at)
        assert any('Continue with:' in c.value for c in at.caption)
        at.text_area(key=f'esc_answer_{run.run_id}').set_value('Review the existing baseline definition.').run()
        next(b for b in at.button if b.label == 'Resume with this answer').click().run()
        _healthy(at)
        assert len(client.calls) == 1
        saved = state.RunState.resume(run.run_id)
        answered = next(s for s in saved.steps if s['kind'] == 'answered')
        successor = state.RunState.resume(answered['run'])
        assert successor.metrics['provider'] == provider
        assert successor.primary_pack == run.primary_pack
        human = next(s for s in successor.steps if s['kind'] == 'human_answer')
        assert human['answer'] == 'Review the existing baseline definition.'
        assert human['eligibility'] == 'roster'
        assert 'Repository skill: operate-rwd-product' in client.calls[0][0]


def test_queue_disconnected_provider_disables_resume_without_losing_answer(monkeypatch):
    client = Client()
    online = {'value': True}
    def provider(*_a, **_kw):
        if not online['value']:
            raise ai.vscode.BridgeError('bridge_inactive')
        return configured(client)
    monkeypatch.setattr(ai, '_provider', provider)
    with _portal(role='admin') as at:
        run = queued(at)
        answer = 'Review the existing baseline definition.'
        at.text_area(key=f'esc_answer_{run.run_id}').set_value(answer).run()
        online['value'] = False
        at.run()
        _healthy(at)
        assert next(b for b in at.button if b.label == 'Resume with this answer').disabled
        assert at.text_area(key=f'esc_answer_{run.run_id}').value == answer
        assert not client.calls and not state.RunState.resume(run.run_id).steps


@pytest.mark.parametrize('case', ['credential', 'ownership', 'invalid_limit'])
def test_queue_refusals_stay_on_page_and_do_not_call_or_record_model(monkeypatch, case):
    client = Client()
    monkeypatch.setattr(ai, '_provider', lambda *_a, **_kw: configured(client))
    with _portal(role='admin') as at:
        run = queued(at, owner='DataExpert' if case == 'ownership' else 'Science')
        answer = ('ANTHROPIC_API_KEY=sk-ant-synthetic-secret-never-send' if case == 'credential'
                  else 'Review the existing baseline definition.')
        at.text_area(key=f'esc_answer_{run.run_id}').set_value(answer).run()
        if case == 'invalid_limit':
            monkeypatch.setenv('RWD_PORTAL_MAX_STEPS', 'not-a-number')
        next(b for b in at.button if b.label == 'Resume with this answer').click().run()
        _healthy(at)
        assert at.error
        assert not client.calls and not state.RunState.resume(run.run_id).steps
        assert not list(Path(state.RUNS).glob('*.answer.lock'))
        assert len(list(Path(state.RUNS).glob('*.json'))) == 1
        assert answer not in '\n'.join(e.value for e in at.error)
