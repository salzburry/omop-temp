"""The benchmark, the eval corpus's generated breadth, and the ML wiring — pinned without a model.

  - models.yaml is the one registry: every model the orchestrator prices is in it, and sampling
    flags match the API's rule (Sonnet 5 / Opus 5 refuse temperature; Haiku 4.5 accepts it)
  - AnthropicModel refuses a temperature on a model that would 400 — before any call
  - the benchmark's plan is a pure function (run count, estimate) and its Wilson math is right
  - the flatters check exists and the report refuses to rank on point estimates alone
  - generated cases are deterministic, tagged generated/unadjudicated, cite their source row,
    and the committed file is current (CI --check)
  - the scorer keeps provenance; history --stats separates the populations
  - the two new tools wear no write-shaped word and are registered
  - the critic wrapper annotates second_vote_recommended (default True without calibration)

NO PYTEST FIXTURES AND NO `parametrize` — CI runs every suite as a script.
"""
import json
import os
import subprocess
import sys
from pathlib import Path

FRAMEWORK = Path(__file__).resolve().parent.parent
ROOT = FRAMEWORK.parent
AGENT = ROOT / "experiments" / "agent"
sys.path.insert(0, str(AGENT))
sys.path.insert(0, str(AGENT / "evals"))
sys.path.insert(0, str(AGENT / "bench"))
os.environ.setdefault("ANTHROPIC_API_KEY", "not-a-key-tests-never-call")
# ONE ENCODING ON BOTH SIDES: the parent decodes UTF-8, so the child must write UTF-8 -- on
# Windows a redirected child inherits the console code page and an em dash became a
# UnicodeDecodeError (audit 5)
_UTF8_ENV = {**os.environ, "PYTHONUTF8": "1", "PYTHONIOENCODING": "utf-8"}


def test_registry_is_the_one_source_and_sampling_flags_match_the_api():
    import orchestrator as orc  # noqa: PLC0415
    reg = orc.model_registry()["models"]
    assert set(orc.PRICES) == set(reg)
    assert reg["claude-sonnet-5"]["sampling"] is False and reg["claude-opus-5"]["sampling"] is False
    assert reg["claude-haiku-4-5"]["sampling"] is True
    assert orc.check_sampling("claude-sonnet-5", 0.7) and "400" in orc.check_sampling("claude-sonnet-5", 0.7)
    assert orc.check_sampling("claude-haiku-4-5", 0.7) is None
    assert orc.check_sampling("claude-haiku-4-5", 1.5)
    assert orc.check_sampling("not-a-model", 0.2)


def test_model_refuses_temperature_before_any_call():
    import orchestrator as orc  # noqa: PLC0415
    try:
        orc.AnthropicModel(model="claude-sonnet-5", temperature=0.5)
    except ValueError as e:
        assert "REFUSED" in str(e)
    else:
        raise AssertionError("a temperature on Sonnet 5 must be refused at construction")


def test_bench_plan_and_wilson_are_pure_and_right():
    import run_bench as rb  # noqa: PLC0415
    assert rb.wilson(0, 0) == (0.0, 0.0, 0.0)
    p, lo, hi = rb.wilson(9, 10)
    assert p == 0.9 and lo < 0.9 < hi and lo > 0.55
    cfgs, refused = rb.configs(["claude-sonnet-5", "claude-haiku-4-5"], ["low", "high"], [None, 0.3])
    keys = {(c["model"], c["effort"], c["temperature"]) for c in cfgs}
    assert ("claude-sonnet-5", "low", None) in keys and ("claude-sonnet-5", "high", None) in keys
    assert ("claude-haiku-4-5", None, 0.3) in keys, "haiku has no effort axis but takes temperature"
    assert not any(k[0] == "claude-sonnet-5" and k[2] is not None for k in keys)
    assert any(m == "claude-sonnet-5" for m, _ in refused), "the refusal is reported, not silent"


def test_bench_report_carries_the_banner_and_the_flatters_check():
    src = (AGENT / "bench" / "run_bench.py").read_text(encoding="utf-8")
    assert "MECHANICAL PASSES, NOT ADJUDICATION" in src
    assert "--degrade" in src and "decoration" in src
    assert "intervals do not overlap" in src or "intervals disjoint" in src
    assert "--budget-usd is required to spend" in src


def test_generated_cases_are_deterministic_tagged_and_current():
    import generate_cases as g  # noqa: PLC0415
    a, b = g.generate(), g.generate()
    assert a == b and len(a) >= 40, len(a)
    assert all(c["provenance"] == "generated" and c["adjudicated"] is False for c in a)
    assert all(c["source"] and c["id"].startswith("gen-") for c in a)
    assert len({c["id"] for c in a}) == len(a)
    r = subprocess.run([sys.executable, str(AGENT / "evals" / "generate_cases.py"), "--check"],
                       capture_output=True, text=True, encoding="utf-8", cwd=str(ROOT), timeout=120, env=_UTF8_ENV)
    assert r.returncode == 0, r.stdout + r.stderr


def test_scorer_keeps_provenance_and_stats_separate_populations():
    src = (AGENT / "evals" / "run.py").read_text(encoding="utf-8")
    assert '"provenance": case.get("provenance", "human")' in src
    assert "def load_all_cases" in src and "--human-only" in src and "--specialists" in src
    r = subprocess.run([sys.executable, str(AGENT / "evals" / "history.py"), "--stats"],
                       capture_output=True, text=True, encoding="utf-8", cwd=str(ROOT), timeout=120, env=_UTF8_ENV)
    assert r.returncode == 0 and "generated" in r.stdout and "human" in r.stdout, r.stdout + r.stderr


def test_new_tools_are_registered_and_read_only_by_name():
    import tools  # noqa: PLC0415
    reg = tools.registry()
    for name in ("semantic_search", "drift_check"):
        assert name in reg, name
        assert not (set(name.split("_")) & tools._WRITE_SHAPED)
    # drift_check refuses without the fenced directory
    assert "REFUSED" in tools.call("drift_check", {"old": "a.tsv", "new": "b.tsv"}) \
        if not os.environ.get("RWD_PROFILE_DIR") else True


def test_critic_wrapper_annotates_second_vote():
    import critic  # noqa: PLC0415

    class _M:
        def step(self, system, transcript):
            return json.dumps({"falsified": False, "confidence": "high", "findings": [],
                               "route": "pass_on", "why": "fine"})
    cal = AGENT / "ml" / "calibration.json"
    had = cal.exists()
    backup = cal.read_text(encoding="utf-8") if had else None
    try:
        if had:
            cal.unlink()
        v = critic.review(_M(), "req", "evidence text", "proposal")
        assert v["second_vote_recommended"] is True and "no calibration" in v["calibration"]
        cal.write_text(json.dumps({"buckets": {"high": {"n": 40, "reliability": 0.95, "lo": 0.84,
                                                         "hi": 0.99, "second_vote": False}}}), encoding="utf-8")
        v = critic.review(_M(), "req", "evidence text", "proposal")
        assert v["second_vote_recommended"] is False and "bucket high" in v["calibration"]
    finally:
        if had:
            cal.write_text(backup, encoding="utf-8")
        elif cal.exists():
            cal.unlink()


def test_train_all_refuses_to_ship_on_thin_data():
    src = (AGENT / "ml" / "train_all.py").read_text(encoding="utf-8")
    assert "INSUFFICIENT DATA" in src and "does NOT beat the majority" in src
    assert "os.remove(out_path)" in src, "a stale artifact must be removed when the data no longer supports it"


class _Scripted:
    """A fake model that replays fixed replies — the orchestrator's guards are tested without a key."""
    def __init__(self, replies):
        self.replies = list(replies); self.model = "fake"; self.usage = {"calls": 0, "input_tokens": 0, "output_tokens": 0}

    def step(self, system, transcript):
        self.usage["calls"] += 1
        return self.replies.pop(0) if self.replies else json.dumps({"action": "done", "summary": "again"})


def test_a_done_with_no_tool_evidence_is_refused_then_ungrounded():
    import orchestrator as orc  # noqa: PLC0415
    import state as st_mod  # noqa: PLC0415
    import tempfile  # noqa: PLC0415
    saved = st_mod.RUNS
    try:
        with tempfile.TemporaryDirectory() as d:
            st_mod.RUNS = d
            # Haiku's pattern: answer in one step, no tool — the run must NOT end "done"
            st = orc.run("what gate is prostate at?",
                         model=_Scripted([json.dumps({"action": "done", "summary": "it is at gate 3"}),
                                          json.dumps({"action": "done", "summary": "gate 3, really"})]),
                         max_steps=5)
            assert st.outcome["status"] == "ungrounded", st.outcome
            assert any(s.get("kind") == "refused_ungrounded" for s in st.steps)
            # ...and a done AFTER a tool observation is accepted
            st2 = orc.run("what gate is prostate at?",
                          model=_Scripted([json.dumps({"action": "tool", "tool": "capabilities", "args": {}, "why": "read"}),
                                           json.dumps({"action": "done", "summary": "from the registry"})]),
                          max_steps=5)
            assert st2.outcome["status"] == "done", st2.outcome
    finally:
        st_mod.RUNS = saved


def test_consistency_vote_presents_only_agreement_and_disqualifies_fabrication():
    import orchestrator as orc  # noqa: PLC0415
    import state as st_mod  # noqa: PLC0415
    import tempfile  # noqa: PLC0415
    saved_run, saved_runs = orc.run, st_mod.RUNS

    def fake_run(goal, model=None, max_steps=20, actor=None, _seq=[]):
        st = st_mod.RunState(goal)
        i = len(_seq); _seq.append(i)
        if goal == "agree":
            st.steps.append({"n": 1, "kind": "observation", "tool": "pack_status", "output": "x"})
            st.finish("done", "s")
        elif goal == "split":
            st.finish("escalated" if i % 2 else "done", json.dumps({"to": "Science", "question": "q"}) if i % 2 else "s")
        else:
            st.finish("ungrounded" if i == 1 else "done", "s")
        return st
    try:
        with tempfile.TemporaryDirectory() as d:
            st_mod.RUNS = d
            orc.run = fake_run
            v = orc.run_consistent("agree", votes=3)
            assert v["stable"] and v["agreement"] == 1.0 and v["presented"] is not None
            fake_run.__defaults__[-1].clear()
            v = orc.run_consistent("split", votes=4)
            assert not v["stable"] and v["presented"] is None and "unstable" in v["why"]
            fake_run.__defaults__[-1].clear()
            v = orc.run_consistent("fab", votes=3)
            assert not v["stable"] and "fabricated" in v["why"]
    finally:
        orc.run, st_mod.RUNS = saved_run, saved_runs


def test_report_carries_stability_and_disqualification():
    src = (AGENT / "bench" / "run_bench.py").read_text(encoding="utf-8")
    assert "STABLE_AT = 0.9" in src and "DISQUALIFIED (ungrounded run)" in src
    assert "## Disqualified for governed use" in src
    scorer = (AGENT / "evals" / "run.py").read_text(encoding="utf-8")
    assert 'checks["grounded"]' in scorer


def test_trainer_reads_the_ledger_shape_the_producer_writes():
    """Producer -> trainer integration: features.py writes nested rows; train_all must flatten
    them, find the labels, and either train or refuse with the RIGHT counts (audit 5: it found
    zero labels and treated the container names as features)."""
    sys.path.insert(0, str(AGENT / "ml"))
    import train_all  # noqa: PLC0415
    import features  # noqa: PLC0415
    fake = {"run_id": "r1", "model": "m", "features": {"steps": 3, "n_tools": 2},
            "labels": {"outcome": "done", "escalated": 0, "passed": True, "adjudicated": None}}
    flat = train_all.flatten(fake)
    assert flat["steps"] == 3 and flat["passed"] is True and "features" not in flat and "labels" not in flat
    # a synthetic two-class ledger of 40 rows trains or refuses by the honesty rule, never crashes
    rows = []
    for i in range(40):
        rows.append(train_all.flatten({"run_id": f"r{i}", "model": "m",
                                       "features": {"steps": i % 7, "n_tools": (i * 3) % 5, "goal_len": 10 + i},
                                       "labels": {"outcome": "done", "escalated": i % 2, "passed": i % 3 != 0}}))
    lines = []
    import tempfile  # noqa: PLC0415
    with tempfile.TemporaryDirectory() as d:
        m = train_all.train_binary("probe", rows, ["steps", "n_tools", "goal_len"], "escalated", 30,
                                   os.path.join(d, "probe.json"), lines)
        assert lines and ("n=40" in lines[-1] or "INSUFFICIENT" in lines[-1]), lines
        assert (m is None) == (not os.path.exists(os.path.join(d, "probe.json")))
    assert callable(features.build_ledger)


def test_budget_reserves_before_spending():
    import run_bench as rb  # noqa: PLC0415
    # the rule execute() applies: a run starts only if the cap still covers its estimate
    budget, spent, reserve = 1.0, 0.75, 0.75
    assert spent + reserve > budget, "the second $0.75 run must not start under a $1 cap"
    src = (AGENT / "bench" / "run_bench.py").read_text(encoding="utf-8")
    assert "spent + reserve > budget" in src and "def per_run_estimate" in src
    assert '"sweep": sweep' in src and "corpus_registry_sha" in src, "rows carry sweep + identity"


def test_unsupported_effort_and_out_of_range_temperature_are_refused():
    import run_bench as rb  # noqa: PLC0415
    cfgs, refused = rb.configs(["claude-sonnet-5", "claude-haiku-4-5"], ["turbo"], [1.7])
    assert any("turbo" in why for _, why in refused)
    assert any("outside [0, 1]" in str(why) for _, why in refused)
    assert not any(c["effort"] == "turbo" or c["temperature"] == 1.7 for c in cfgs)


def test_run_id_rejects_a_trailing_newline():
    import state  # noqa: PLC0415
    try:
        state.RunState("g", run_id="safe_id\n")
    except ValueError as e:
        assert "REFUSED" in str(e)
    else:
        raise AssertionError("a trailing newline passed the run-id grammar")


def test_release_schema_gives_every_property_a_type():
    import json as _json  # noqa: PLC0415
    s = _json.load(open(ROOT / "governance" / "schemas" / "release.schema.json", encoding="utf-8"))
    untyped = [k for k, v in (s.get("properties") or {}).items()
               if isinstance(v, dict) and not any(x in v for x in ("type", "$ref", "oneOf", "anyOf"))]
    assert not untyped, untyped


def test_capabilities_tool_filters_to_the_asked_section():
    import tools  # noqa: PLC0415
    full = tools.t_capabilities({})
    one = tools.t_capabilities({"query": "index.build"})
    assert len(one) < len(full) and "index.build" in one
    assert "no capability section mentions" in tools.t_capabilities({"query": "zzz-not-a-capability"})
def test_every_model_call_is_bounded():
    """One stalled request held the benchmark matrix for over two hours (2026-09-02): the SDK's
    defaults are a 10-minute timeout and two silent retries. The client is built with a finite,
    operator-settable timeout and ONE retry, so a call that never answers becomes an error row.
    Source-level first (CI has no SDK), then the live constructor when the SDK is importable."""
    src = (AGENT / "orchestrator.py").read_text(encoding="utf-8")
    ctor = src[src.index("anthropic.Anthropic("):src.index("self.model = model")]
    assert "max_retries=1" in ctor and "timeout=timeout_s" in ctor, ctor
    assert 'os.environ.get("RWD_API_TIMEOUT_S", "120")' in src
    try:
        import anthropic  # noqa: PLC0415, F401
    except ImportError:
        return  # the source assertions above already ran; nothing here is skipped silently
    import orchestrator as orc  # noqa: PLC0415
    env = dict(os.environ)
    os.environ["ANTHROPIC_API_KEY"] = "test-key-never-used"
    os.environ["RWD_API_TIMEOUT_S"] = "7"
    try:
        m = orc.AnthropicModel(model="claude-sonnet-5", effort="low")
        assert float(m.client.timeout) == 7.0 and m.client.max_retries == 1, (m.client.timeout, m.client.max_retries)
    finally:
        os.environ.clear(); os.environ.update(env)


if __name__ == "__main__":
    fails = 0
    for name, fn in sorted(globals().items()):
        if name.startswith("test_") and callable(fn):
            try:
                fn()
                print(f"  ok   {name}")
            except Exception as e:  # noqa: BLE001
                fails += 1
                print(f"  FAIL {name}: {e}")
    print(f"{fails} failure(s)")
    sys.exit(1 if fails else 0)
