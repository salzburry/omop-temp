"""Programme item 5 — approvals as ledger events, and authentication that is DERIVED from a
verified signature rather than written on an actor.

    python3 platform/tests/test_approval_record.py
"""
import base64
import os
import shutil
import sys
import tempfile
import traceback
from pathlib import Path

FRAMEWORK = Path(__file__).resolve().parent.parent
ROOT = FRAMEWORK.parent
sys.path.insert(0, str(FRAMEWORK / "tools"))
os.environ.setdefault("ANTHROPIC_API_KEY", "not-a-key-tests-never-call")
import approval_record as ar                                                # noqa: E402
import claims                                                               # noqa: E402
import console                                                              # noqa: E402
import event_ledger as el                                                   # noqa: E402

PROSTATE = "fixtures/oncology/prostate/202606"
TS = "2026-09-05T10:00:00Z"
RELEASE_FORM = ("approved_by: Ada Lovelace\napproval_date: 2026-09-02\nvalidated_by: Grace Hopper\n"
                "validation_date: 2026-09-01\napproved_build_id: b1\napproved_manifest_sha256: " + "d" * 64 + "\n")


def _root(release_form=RELEASE_FORM):
    root = tempfile.mkdtemp(prefix="apr_")
    (Path(root) / "platform" / "tools").mkdir(parents=True)          # the checkout marker
    dst = os.path.join(root, PROSTATE)
    shutil.copytree(ROOT / PROSTATE, dst, ignore=shutil.ignore_patterns("__pycache__"))
    os.makedirs(os.path.join(root, "fixtures"), exist_ok=True)
    shutil.copy(ROOT / "fixtures" / "registry.yaml", os.path.join(root, "fixtures", "registry.yaml"))
    if release_form is not None:
        Path(dst, "handoff", "RELEASE_APPROVAL.yaml").write_text(release_form, encoding="utf-8")
    return root


def _keypair():
    raw = os.urandom(32)
    return raw, el.public_key_b64(raw)


def test_the_signature_primitive_holds_the_rfc_8032_vectors_and_refuses_every_malformed_input():
    """RFC 8032 section 7.1, test 1 (empty message) and test 2 (one byte), verbatim; then the
    refusals — a flipped bit, a wrong key, a wrong message, a short signature — all False."""
    import ed25519_pure as e
    sk = bytes.fromhex("9d61b19deffd5a60ba844af492ec2cc44449c5697b326919703bac031cae7f60")
    pk = bytes.fromhex("d75a980182b10ab7d54bfed3c964073a0ee172f3daa62325af021a68f707511a")
    sig = bytes.fromhex("e5564300c360ac729086e2cc806e828a84877f1eb8e5d974d873e06522490155"
                        "5fb8821590a33bacc61e39701cf9b46bd25bf5f0595bbe24655141438e7a100b")
    assert e.secret_to_public(sk) == pk and e.sign(sk, b"") == sig and e.verify(pk, b"", sig)
    sk2 = bytes.fromhex("4ccd089b28ff96da9db6c346ec114e0f5b8a319f35aba624da8cf6ed4fb8a6fb")
    pk2 = bytes.fromhex("3d4017c3e843895a92b70aa74d1b7ebc9c982ccf2ec4968cc0cd55f12af4660c")
    sig2 = bytes.fromhex("92a009a9f0d4cab8720e820b5f642540a2b27b5416503f8fb3762223ebdb69da"
                         "085ac1e43e15996e458f3613d0f11d8c387b2eaeb4302aeeb00d291612bb0c00")
    assert e.secret_to_public(sk2) == pk2 and e.sign(sk2, b"\x72") == sig2 and e.verify(pk2, b"\x72", sig2)
    flipped = bytes([sig[0] ^ 1]) + sig[1:]
    assert not e.verify(pk, b"", flipped) and not e.verify(pk2, b"", sig) and not e.verify(pk, b"x", sig)
    assert not e.verify(pk, b"", sig[:63]) and not e.verify(pk[:31], b"", sig) and not e.verify(b"\xff" * 32, b"", sig)
    # the ledger's helpers: hex or raw private keys, the same public key
    assert el.public_key_b64(sk) == el.public_key_b64(sk.hex()) == base64.b64encode(pk).decode()
    assert base64.b64decode(el.sign_target(sk, "")) == sig


def _register(root, *entries):
    import yaml
    Path(root, "governance").mkdir(exist_ok=True)
    Path(root, "governance", "SIGNING_KEYS.yaml").write_text(yaml.safe_dump({"keys": list(entries)}), encoding="utf-8")


def _key(key_id, pub, status="active", person="Ada Lovelace"):
    return {"key_id": key_id, "person": person, "algorithm": "ed25519", "public_key": pub,
            "registered_by": "Grace Hopper", "registration_date": "2026-09-01", "status": status}


def test_a_release_approval_seals_as_an_object_the_form_carries_and_the_claims_composition_proves():
    """The form gains its object_uuid; sealing twice is one act; an edited form is named as having
    shed its act and re-records as `revised` on the SAME object; the claims composition names the
    form as the object's one owner; the ledger's own check stays green throughout."""
    root = _root()
    try:
        assert ar.sealed_errors(root, PROSTATE, "release") and "not recorded in the ledger" in ar.sealed_errors(root, PROSTATE, "release")[0]
        ev, why = ar.record_event(root, PROSTATE, "release", TS)
        assert why is None and ev["action"] == "registered" and ev["object_kind"] == "release_approval", why
        assert ev["payload"]["approved_build_id"] == "b1" and ev["payload"]["pack"] == PROSTATE and ev["payload"]["form"] == "release"
        assert ev["actor"]["display_name"] == "Ada Lovelace" and ev["actor"]["trust_level"] == "typed"
        form = Path(root, PROSTATE, "handoff", "RELEASE_APPROVAL.yaml").read_text(encoding="utf-8")
        assert f"object_uuid: {ev['object_uuid']}" in form and form.startswith("approved_by: Ada Lovelace")
        assert ar.sealed_errors(root, PROSTATE, "release") == []
        again, why2 = ar.record_event(root, PROSTATE, "release", "2026-09-05T11:00:00Z")
        assert why2 is None and again["event_sha256"] == ev["event_sha256"], "sealing the same bytes twice is one act"
        assert ar.claimed_objects(root, "release") == {ev["object_uuid"]: f"{PROSTATE}/handoff/RELEASE_APPROVAL.yaml"}
        composed, problems = claims.compose(root)
        assert problems == [] and composed.get(ev["object_uuid"]) == [f"{PROSTATE}/handoff/RELEASE_APPROVAL.yaml"], (composed, problems)
        assert el.check(root, require_claims=True) == [], el.check(root, require_claims=True)
        assert ar.check(root) == [] and ar.trust(root, PROSTATE, "release") == "typed"
        # the approver re-approves another build: the form no longer says what its act said
        Path(root, PROSTATE, "handoff", "RELEASE_APPROVAL.yaml").write_text(
            form.replace("approved_build_id: b1", "approved_build_id: b2"), encoding="utf-8")
        bad = ar.sealed_errors(root, PROSTATE, "release")
        assert bad and "edited after it was sealed" in bad[0] and "--record-event" in bad[0], bad
        assert ar.claimed_objects(root, "release") == {} and ar.check(root) == bad
        _c, problems = claims.compose(root)
        assert any(ev["object_uuid"] in p for p in problems), "an edited form abandons its object, and the composition says so"
        rev, why3 = ar.record_event(root, PROSTATE, "release", "2026-09-05T12:00:00Z")
        assert why3 is None and rev["action"] == "revised" and rev["object_uuid"] == ev["object_uuid"] and rev["seq"] == 2
        assert ar.sealed_errors(root, PROSTATE, "release") == [] and el.check(root, require_claims=True) == []
        # the CLI says the same
        import subprocess
        r = subprocess.run([sys.executable, str(FRAMEWORK / "tools" / "approval_record.py"), "--check", "--root", root],
                           capture_output=True, text=True, encoding="utf-8")
        assert r.returncode == 0 and "0 approval record problem(s)" in r.stdout, r.stdout + r.stderr
        r = subprocess.run([sys.executable, str(FRAMEWORK / "tools" / "approval_record.py"), "--trust", PROSTATE,
                            "--form", "release", "--root", root], capture_output=True, text=True, encoding="utf-8")
        assert r.returncode == 0 and r.stdout.strip() == "typed", r.stdout + r.stderr
    finally:
        shutil.rmtree(root, ignore_errors=True)


def test_gate_6_holds_a_release_approval_that_is_only_a_form_and_clears_once_it_is_sealed():
    """publish_approval_errors: a form that stands is still not an act until sealed; sealing
    clears it; an edit after sealing brings the refusal back by name; the recorder's own
    pre-seal check does not ask itself (require_sealed=False)."""
    import source_manifest as sm
    root = _root()
    try:
        why = sm.publish_approval_errors(root, PROSTATE, "b1", "d" * 64)
        assert why and "not recorded in the ledger" in why[0] and "--record-event" in why[0], why
        assert sm.publish_approval_errors(root, PROSTATE, "b1", "d" * 64, require_sealed=False) == []
        ev, err = ar.record_event(root, PROSTATE, "release", TS)
        assert err is None
        assert sm.publish_approval_errors(root, PROSTATE, "b1", "d" * 64) == []
        form = Path(root, PROSTATE, "handoff", "RELEASE_APPROVAL.yaml")
        form.write_text(form.read_text(encoding="utf-8").replace("approval_date: 2026-09-02", "approval_date: 2026-09-03"), encoding="utf-8")
        why = sm.publish_approval_errors(root, PROSTATE, "b1", "d" * 64)
        assert why and "edited after it was sealed" in why[0], why
        # the status page's Gate 6 carries the same line, and no other gate does
        import status as st
        g = {n: (state, w) for n, _t, state, w in st.gates(root, PROSTATE)}
        assert any("edited after it was sealed" in w for w in g[6][1]) and not any("sealed" in w for n in (1, 2, 3, 4, 5) for w in g[n][1])
    finally:
        shutil.rmtree(root, ignore_errors=True)


def test_an_approval_the_gate_refuses_is_not_an_act_to_record():
    """The seal runs the OWNING gate's check first: one person wearing both release names, a
    missing form, a configuration form the digest check refuses — none of them seals."""
    root = _root(RELEASE_FORM.replace("validated_by: Grace Hopper", "validated_by: Ada Lovelace"))
    try:
        ev, why = ar.record_event(root, PROSTATE, "release", TS)
        assert ev is None and "same person" in why and "not an act to record" in why, why
        assert not os.path.isdir(os.path.join(root, "governance", "events")), "a refused seal writes nothing"
        ev, why = ar.record_event(root, PROSTATE, "configuration", TS)
        assert ev is None and "nothing to record" in why, why
        Path(root, PROSTATE, "handoff", "CONFIGURATION_APPROVAL.yaml").write_text(
            "approved_by: Ada Lovelace\napproval_date: 2026-09-02\ntechnically_reviewed_by: Grace Hopper\n"
            "approved_configuration_bundle_sha256: " + "a" * 64 + "\napproved_against_contract_sha256: " + "b" * 64 + "\n",
            encoding="utf-8")
        ev, why = ar.record_event(root, PROSTATE, "configuration", TS)
        assert ev is None and "does not stand under its gate" in why, why
        assert "nothing to record" in ar.form_errors(root, PROSTATE, "semantic")[0], "no form: nothing to seal, said so"
        ev, why = ar.record_event(root, PROSTATE, "semantic", TS)
        assert ev is None and "nothing to record" in why, why
    finally:
        shutil.rmtree(root, ignore_errors=True)


def test_authenticated_is_derived_from_a_verified_signature_under_a_registered_active_key():
    """A typed actor stays typed. A registered person's ed25519 signature over the sealed event
    makes it `authenticated`; the wrong private key under a registered id is refused before
    anything is written; a bogus, unregistered or revoked-key attestation authenticates nothing
    and is named; the structural check keeps a placeholder attestation (a valid event) while the
    verifier calls it nothing."""
    root = _root()
    try:
        ev, why = ar.record_event(root, PROSTATE, "release", TS)
        assert why is None
        obj = ev["object_uuid"]
        priv, pub = _keypair()
        other, _pub2 = _keypair()
        _register(root, _key("ada-2026", pub))
        assert el.trust_of(root, obj) == "typed"
        # the wrong key under a registered id never reaches the ledger
        att, why = ar.attest(root, PROSTATE, "release", "ada-2026", other, TS)
        assert att is None and "not the key registered" in why, why
        att, why = ar.attest(root, PROSTATE, "release", "nope", priv, TS)
        assert att is None and "not registered" in why, why
        att, why = ar.attest(root, PROSTATE, "release", "ada-2026", priv, TS)
        assert why is None and att["action"] == "attested" and att["payload"]["algorithm"] == "ed25519"
        assert att["actor"]["identity_provider"] == "signing_key" and att["actor"]["trust_level"] == "typed", \
            "authentication is never WRITTEN on an actor"
        v = el.verify_attestation(root, obj)
        assert v["problems"] == [] and v["authenticated"] == {ev["event_sha256"]: ["ada-2026"]}, v
        assert el.trust_of(root, obj) == "authenticated" and ar.trust(root, PROSTATE, "release") == "authenticated"
        assert el.check(root, require_claims=True) == []
        # a second attestation with the same key over the same event is one act
        again, why = ar.attest(root, PROSTATE, "release", "ada-2026", priv, "2026-09-06T00:00:00Z")
        assert why is None and again["event_sha256"] == att["event_sha256"]
        # a bogus signature crafted straight onto the chain: structurally an event, cryptographically nothing
        _seq, head = el.head_of(root, obj)
        bogus = el.append_event(root, object_uuid=obj, object_kind="release_approval", action="attested",
                                actor=dict(att["actor"]), occurred_at="2026-09-06T01:00:00Z",
                                payload={"target_event_sha256": ev["event_sha256"], "signer_key_id": "ada-2026",
                                         "algorithm": "ed25519", "signature": base64.b64encode(b"\\0" * 64).decode()},
                                expected_previous_event_sha256=head, idempotency_key="bogus")
        assert bogus["seq"] == 3 and el.check(root) == []
        v = el.verify_attestation(root, obj)
        assert any("does not verify" in p for p in v["problems"]) and v["authenticated"] == {ev["event_sha256"]: ["ada-2026"]}, v
        # the key is revoked: nothing signed with it authenticates any longer, by name
        _register(root, _key("ada-2026", pub, status="revoked"))
        v = el.verify_attestation(root, obj)
        assert v["authenticated"] == {} and any("revoked" in p for p in v["problems"]), v
        assert el.trust_of(root, obj) == "typed"
        # an unregistered id, and a malformed register, authenticate nothing
        _register(root)
        assert el.trust_of(root, obj) == "typed" and any("not a registered key" in p for p in el.verify_attestation(root, obj)["problems"])
        _register(root, {"key_id": "x", "person": "the team", "algorithm": "ed25519", "public_key": pub,
                         "registered_by": "Grace Hopper", "registration_date": "2026-09-01", "status": "active"})
        keys, problems = el.signing_keys(root)
        assert keys == {} and problems and "person" in problems[0], problems
        _register(root, dict(_key("y", base64.b64encode(b"short").decode())))
        keys, problems = el.signing_keys(root)
        assert keys == {} and "32" in problems[0], problems
        # the register a person commits is inert until a key is added
        live_keys, live_problems = el.signing_keys(str(ROOT))
        assert live_keys == {} and live_problems == []
    finally:
        shutil.rmtree(root, ignore_errors=True)


def test_the_ledger_vocabulary_the_control_plane_and_the_claims_providers_agree_on_the_four_kinds():
    kinds = {"release_approval", "configuration_approval", "contract_approval", "semantic_approval"}
    assert kinds <= set(el.OBJECT_KINDS) and kinds <= set(claims.PROVIDERS)
    for k in kinds:
        assert el.KIND_ACTIONS[k] == ("registered", "revised", "superseded") and el.GENESIS_ACTIONS[k] == ("registered",)
    sys.path.insert(0, str(ROOT / "experiments" / "agent"))
    import control_plane as cp                                              # noqa: PLC0415
    assert kinds <= set(cp.LEDGER_OBJECT_KINDS)
    assert set(ar.FORMS) == {"release", "configuration", "contract", "semantic"}
    assert ar.FORM_OF_KIND["release_approval"] == "release"


if __name__ == "__main__":
    console.use_utf8()
    failures = 0
    for name, fn in sorted(globals().items()):
        if name.startswith("test_") and callable(fn):
            try:
                fn()
                print(f"  ok   {name}")
            except Exception:                                                 # noqa: BLE001
                failures += 1
                print(f"  FAIL {name}")
                traceback.print_exc()
    print(f"{failures} failure(s)")
    sys.exit(1 if failures else 0)
