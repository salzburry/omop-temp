"""Real Streamlit saved-draft journeys against temporary packs, never live products."""
from __future__ import annotations

import sys
import tempfile
from pathlib import Path

from streamlit.testing.v1 import AppTest

sys.path.insert(0, str(Path(__file__).resolve().parent))
from test_epi_design_drafts import ROOT, PACK, dw, fixture, original_bytes

PREFIX = f"design_{PACK}_"
OTHER = "fixtures/oncology/template/202609"
ACTOR = "epi@example.test"


def app(root, *, can_write=True):
    script = f"""
import sys
sys.path.insert(0, {str(ROOT / 'experiments/portal')!r})
import streamlit as st
import design_page, session_drafts
actor = st.selectbox('Test actor', {[ACTOR, 'other@example.test']!r}, key='test_actor')
pack = st.selectbox('Test pack', {[PACK, OTHER]!r}, key='test_pack')
page = st.radio('Test page', ['Plan', 'Other page'], key='test_page')
session_drafts.preserve(st.session_state, actor)
if page == 'Plan':
    design_page.render({str(root)!r}, pack, actor_id=actor, local_demo=True,
                       can_write={can_write!r}, allowed_packs={[PACK, OTHER]!r})
else:
    st.write('Another page')
"""
    return AppTest.from_string(script, default_timeout=20).run()


def healthy(at):
    assert not at.exception, [e.message for e in at.exception]


def configure(at):
    at.text_area(key=PREFIX + "purpose").set_value("Reusable treatment patterns and outcomes product")
    at.text_area(key=PREFIX + "studies").set_value("Treatment patterns\nOutcomes")
    at.multiselect(key=PREFIX + "excluded").set_value(["OS"]).run()
    healthy(at)


def test_save_close_reopen_source_revision_and_originals_untouched():
    with tempfile.TemporaryDirectory() as tmp:
        root = Path(tmp); fixture(root); fixture(root, OTHER)
        before = original_bytes(root)
        at = app(root); configure(at)
        at.button(key=f"revision_save_{PACK}").click().run(); healthy(at)
        assert any("Saved draft version 1" in message.value for message in at.success)
        saved = dw.list_drafts(root, PACK, actor_id=ACTOR)["drafts"]
        assert len(saved) == 1 and saved[0]["summary"]["after_count"] == 2
        # A fresh session must recover from disk, without original session state.
        again = app(root)
        assert again.text_area(key=PREFIX + "purpose").value == ""
        again.button(key=f"revision_open_{PACK}").click().run(); healthy(again)
        assert again.text_area(key=PREFIX + "purpose").value.startswith("Reusable")
        assert again.text_area(key=PREFIX + "studies").value == "Treatment patterns\nOutcomes"
        assert again.multiselect(key=PREFIX + "excluded").value == ["OS"]
        again.text_input(key=PREFIX + "source").set_value("optum")
        again.selectbox(key=PREFIX + "modality").set_value("claims").run()
        again.button(key=f"revision_save_{PACK}").click().run(); healthy(again)
        saved = dw.list_drafts(root, PACK, actor_id=ACTOR)["drafts"]
        assert [s["version"] for s in saved] == [2, 1]
        assert saved[0]["summary"]["source"]["proposed"] == {"vendor": "optum", "modality": "claims"}
        assert original_bytes(root) == before


def test_stale_saved_baseline_requires_review_before_next_version():
    with tempfile.TemporaryDirectory() as tmp:
        root = Path(tmp); folder = fixture(root); fixture(root, OTHER)
        at = app(root); configure(at)
        at.button(key=f"revision_save_{PACK}").click().run()
        cfg = folder / "config/data_product.yaml"
        cfg.write_text(cfg.read_text(encoding="utf-8") + "delivery: next\n", encoding="utf-8")
        again = app(root)
        again.button(key=f"revision_open_{PACK}").click().run(); healthy(again)
        assert again.button(key=f"revision_save_{PACK}").disabled
        assert any("source product changed" in warning.value for warning in again.warning)
        again.button(key=f"revision_refresh_{PACK}").click().run(); healthy(again)
        assert not again.button(key=f"revision_save_{PACK}").disabled
        again.button(key=f"revision_save_{PACK}").click().run(); healthy(again)
        assert len(dw.list_drafts(root, PACK, actor_id=ACTOR)["drafts"]) == 2


def test_actor_pack_and_navigation_isolation_keep_saved_drafts_private():
    with tempfile.TemporaryDirectory() as tmp:
        root = Path(tmp); fixture(root); fixture(root, OTHER)
        at = app(root); configure(at)
        at.button(key=f"revision_save_{PACK}").click().run()
        at.radio(key="test_page").set_value("Other page").run()
        at.radio(key="test_page").set_value("Plan").run(); healthy(at)
        assert at.text_area(key=PREFIX + "purpose").value.startswith("Reusable")
        at.selectbox(key="test_pack").set_value(OTHER).run(); healthy(at)
        assert not any(b.key == f"revision_open_{OTHER}" for b in at.button)
        assert at.text_area(key=f"design_{OTHER}_purpose").value == ""
        at.selectbox(key="test_pack").set_value(PACK).run()
        assert at.text_area(key=PREFIX + "purpose").value.startswith("Reusable")
        at.selectbox(key="test_actor").set_value("other@example.test").run(); healthy(at)
        assert at.text_area(key=PREFIX + "purpose").value == ""
        assert not any(b.key == f"revision_open_{PACK}" for b in at.button)
        assert at.button(key=f"revision_save_{PACK}").disabled
        at.selectbox(key="test_actor").set_value(ACTOR).run(); healthy(at)
        assert at.text_area(key=PREFIX + "purpose").value.startswith("Reusable")
        assert any(b.key == f"revision_open_{PACK}" for b in at.button)


def test_dependency_conflict_readonly_and_concurrent_save_have_clear_results():
    with tempfile.TemporaryDirectory() as tmp:
        root = Path(tmp); fixture(root); fixture(root, OTHER)
        at = app(root); configure(at)
        at.multiselect(key=PREFIX + "excluded").set_value(["INDEXDT"]).run()
        assert at.button(key=f"revision_save_{PACK}").disabled
        assert any("depends on removed variable" in msg.value for msg in at.info)
        at.multiselect(key=PREFIX + "excluded").set_value(["OS"]).run()
        at.button(key=f"revision_save_{PACK}").click().run()
        concurrent = app(root)
        concurrent.button(key=f"revision_open_{PACK}").click().run()
        at.text_area(key=PREFIX + "purpose").set_value("First browser edits").run()
        at.button(key=f"revision_save_{PACK}").click().run(); healthy(at)
        concurrent.text_area(key=PREFIX + "purpose").set_value("Second browser edits").run()
        concurrent.button(key=f"revision_save_{PACK}").click().run(); healthy(concurrent)
        assert any("newer draft version" in msg.value for msg in concurrent.error)
        assert len(dw.list_drafts(root, PACK, actor_id=ACTOR)["drafts"]) == 2
        reader = app(root, can_write=False)
        reader.button(key=f"revision_open_{PACK}").click().run(); healthy(reader)
        assert reader.button(key=f"revision_save_{PACK}").disabled


def test_new_tumor_draft_saves_literal_additions_and_separate_revision():
    with tempfile.TemporaryDirectory() as tmp:
        root = Path(tmp); fixture(root, empty=True); fixture(root, OTHER)
        at = app(root)
        text = "  Scientist's proposed tumor population\nUnknown stays unknown.  "
        at.text_area(key=PREFIX + "purpose").set_value("Create tumor population for two studies")
        at.text_area(key=PREFIX + "studies").set_value("Patterns\nOutcomes")
        at.text_input(key=PREFIX + "add_domain").set_value("study_population")
        at.text_input(key=PREFIX + "add_variable").set_value("TUMOR_POP")
        at.text_area(key=PREFIX + "add_definition").set_value(text)
        at.button(key=f"revision_add_{PACK}").click().run(); healthy(at)
        at.button(key=f"revision_save_{PACK}").click().run(); healthy(at)
        listing = dw.list_drafts(root, PACK, actor_id=ACTOR)["drafts"]
        loaded = dw.load_draft(root, PACK, actor_id=ACTOR, draft_id=listing[0]["draft_id"])
        assert loaded["inputs"]["additions"][0]["definition"] == text
        at.button(key=f"revision_fork_{PACK}").click().run()
        at.text_area(key=PREFIX + "purpose").set_value("Separate sensitivity proposal").run()
        at.button(key=f"revision_save_{PACK}").click().run(); healthy(at)
        listing = dw.list_drafts(root, PACK, actor_id=ACTOR)["drafts"]
        assert len(listing) == 2 and len({d["draft_id"] for d in listing}) == 2


if __name__ == "__main__":
    tests = [(name, value) for name, value in globals().items() if name.startswith("test_") and callable(value)]
    for name, test in tests:
        test()
        print("PASS", name)
    print(f"{len(tests)} saved draft Streamlit journeys passed")
