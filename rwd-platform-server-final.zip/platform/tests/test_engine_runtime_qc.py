"""Focused engine guards and truthful receipts. Only the R guard uses a real R process;
the reporting tests deliberately stub execution and never claim Spark output evidence.
"""
from pathlib import Path
import copy
import os
import subprocess
import sys
from types import SimpleNamespace
import xml.etree.ElementTree as ET

import pytest

ROOT = Path(__file__).resolve().parents[2]
sys.path[:0] = [str(ROOT / part) for part in ("platform/tests", "platform/tools", "platform", "experiments/portal")]
from engine.stages import ads_derived
import implementation_runtime as runtime
import spec_lint
import test_stage_conformance as conformance
from test_r_parity import to_r_literal


DEPENDENCY_CASES = [
    [{"name": "consumer", "requires": ["producer"], "expr": "producer + 1"},
     {"name": "producer", "requires": ["seed"], "expr": "seed + 1"}],
    [{"name": "consumer", "requires": ["timinggrn"], "expr": "timinggrn"},
     {"name": "timing", "requires": ["start", "end"], "interval": {"from": "start", "to": "end"},
      "bands": [{"label": "Any", "code": 1, "min": 0}]}],
    [{"name": "first", "requires": ["second"], "expr": "second + 1"},
     {"name": "second", "requires": ["first"], "expr": "first + 1"}],
    [{"name": "self", "requires": ["self"], "expr": "self + 1"}],
    [{"name": "VALUE", "requires": ["seed"], "expr": "seed"},
     {"name": "value", "requires": ["seed"], "expr": "seed + 1"}],
]


@pytest.mark.parametrize("items", DEPENDENCY_CASES)
def test_invalid_internal_dependencies_are_refused_before_frame_mutation(items):
    assert ads_derived.ads_derived_errors(items)
    class Untouched:
        @property
        def columns(self):
            pytest.fail("An invalid configuration must be refused before reading a frame.")
    with pytest.raises(ValueError, match="Invalid outcomes.ads_derived"):
        ads_derived.build(None, Untouched(), SimpleNamespace(pack=lambda _: {"ads_derived": items}))


@pytest.mark.parametrize("items", DEPENDENCY_CASES)
def test_canonical_strict_validator_refuses_internal_dependency_errors(items):
    from engine.config import load_config, product_config
    from engine import validate
    cfg = load_config(product_config(ROOT / "fixtures", "prostate"), overrides={
        "run.refresh": "2026q1", "run.source_schema": "synthetic", "run.output_schema": "out"})
    cfg.pack("outcomes")["ads_derived"] = copy.deepcopy(items)
    findings = validate.problems(cfg, strict=True)
    assert any("dependency order or cycle" in finding or "duplicates output column" in finding
               for finding in findings), findings
    with pytest.raises(RuntimeError):
        validate.check(cfg, strict=True)


def test_valid_dependency_order_and_absent_external_columns_keep_existing_contract():
    ordered = copy.deepcopy(list(reversed(DEPENDENCY_CASES[0])))
    assert ads_derived.ads_derived_errors(ordered) == []
    ordered[1]["requires"] = ["PRODUCER"]
    assert ads_derived.ads_derived_errors(ordered) == []
    class Frame:
        columns = ["seed"]
        def withColumn(self, name, _expression):
            self.columns = [*self.columns, name]
            return self
    frame = Frame()
    cfg = SimpleNamespace(pack=lambda _: {"ads_derived": ordered}, study={})
    assert ads_derived.build(SimpleNamespace(expr=lambda value: value), frame, cfg).columns == ["seed", "producer", "consumer"]
    absent = [{"name": "optional_cut", "requires": ["missing_delivery_column"], "expr": "1"}]
    cfg.pack = lambda _: {"ads_derived": absent}
    assert ads_derived.build(None, frame, cfg) is frame
    assert "optional_cut" not in frame.columns


@pytest.mark.parametrize("body", [{"interval": "invalid"}, {"landmark": ["invalid"]},
    {"landmark": {"censor": ["invalid"], "labels": {"achieved": ["invalid"]}}}])
def test_malformed_derivation_shapes_report_findings_instead_of_crashing(body):
    errors = ads_derived.ads_derived_errors([{"name": "draft", "requires": ["seed"], **body}])
    assert errors and any("mapping" in error for error in errors)


def test_real_r_dependency_guard_rejects_the_same_shapes_without_starting_spark(tmp_path):
    executable = runtime._rscript()
    if not executable:
        pytest.skip("Rscript unavailable; mirrored dependency guard is unverified in this run.")
    script = tmp_path / "guard.R"
    text = "source(" + to_r_literal(str(ROOT / "platform/engine-r/stages.R")) + ")\n"
    for items in DEPENDENCY_CASES:
        text += "stopifnot(length(ads_derived_dependency_errors(" + to_r_literal(items) + ")) > 0L)\n"
    text += "stopifnot(length(ads_derived_dependency_errors(" + to_r_literal(list(reversed(DEPENDENCY_CASES[0]))) + ")) == 0L)\n"
    text += 'cat("R-DEPENDENCY-GUARDS PASS\\n")\n'
    script.write_text(text, encoding="utf-8")
    result = subprocess.run([executable, "--vanilla", str(script)], capture_output=True, text=True, timeout=30)
    assert result.returncode == 0, result.stdout + result.stderr
    assert "R-DEPENDENCY-GUARDS PASS" in result.stdout


def test_missing_r_is_a_counted_pytest_skip_even_when_python_assertions_complete(tmp_path):
    # Run the actual named roster with explicitly synthetic Python output. This
    # checks every dispatch and JUnit's skip handling, not engine data semantics.
    probe = tmp_path / "absent_r_reporting_probe.py"
    probe.write_text("import pytest\n"
        "@pytest.fixture(autouse=True)\n"
        "def synthetic_missing_r(monkeypatch, request):\n"
        "    c = request.module\n"
        "    monkeypatch.setattr(c, 'RSCRIPT', None)\n"
        "    monkeypatch.setattr(c, 'SparkSession', object())\n"
        "    monkeypatch.setattr(c, 'load_case', lambda _: {'expect': {'columns': ['n'], 'types': ['int'], 'rows': [[1]]}})\n"
        "    monkeypatch.setattr(c, 'run_python', lambda _: c.canonical(['n'], [(1,)], ['int']))\n", encoding="utf-8")
    report = tmp_path / "report.xml"
    result = subprocess.run([sys.executable, "-m", "pytest", str(ROOT / "platform/tests/test_stage_conformance.py"),
        "-p", probe.stem, "-q", "--junitxml=" + str(report)],
        cwd=tmp_path, capture_output=True, text=True, timeout=45,
        env={**os.environ, "RWDP_CONFORMANCE_REQUIRE_R": "0", "PYTHONPATH": str(tmp_path),
             "PYTEST_DISABLE_PLUGIN_AUTOLOAD": "1"})
    assert result.returncode == 0, result.stdout + result.stderr
    cases = ET.parse(report).getroot().findall(".//testcase")
    runtime_cases = [case for case in cases if case.get("name", "").startswith("test_conformance_")]
    pure_cases = [case for case in cases if case not in runtime_cases]
    assert len(runtime_cases) == len(list(conformance.CASES_DIR.glob("*.yaml")))
    assert all(case.find("skipped") is not None and "Rscript absent" in case.find("skipped").get("message")
               for case in runtime_cases)
    assert pure_cases and all(not list(case) for case in pure_cases)


def test_required_r_refuses_missing_runtime(monkeypatch):
    monkeypatch.setenv("RWDP_CONFORMANCE_REQUIRE_R", "1")
    with pytest.raises(AssertionError, match="REQUIRED and unavailable"):
        conformance._r_skip("synthetic missing runtime")


@pytest.mark.parametrize("rscript,skip_marker", [(None, ""), ("present", "R-CONFORMANCE SKIP (runner unavailable)\n")])
def test_a_success_marker_cannot_override_missing_or_skipped_r(tmp_path, rscript, skip_marker):
    report = tmp_path / "report.xml"
    report.write_text("<testsuite><testcase name='test_conformance_case'/></testsuite>", encoding="utf-8")
    result = runtime.parse_report(report, subprocess.CompletedProcess([], 0, skip_marker + "R-CONFORMANCE PASS case\n", ""),
        {"id": "conformance", "title": "Conformance", "selectors": ["platform/tests/test_stage_conformance.py"]}, 1, {"rscript": rscript})
    assert result["r_conformance"] == "skipped" and result["status"] == "partial"


def test_capability_states_are_labelled_historical_not_this_runtime_execution():
    import capability_registry
    text = capability_registry.render_md(capability_registry.load(), capability_registry.inventory_classes())
    assert "historical verification declarations" in text
    assert "current implementation runtime receipt" in text


@pytest.mark.parametrize("name", ["os", "pfs", "gendern", "baseline_albumin"])
def test_identical_lowercase_physical_names_are_flagged_on_both_spec_rows(name):
    rows = [{"item_id": f"clinical:{i}", "tab": "Clinical", "domain": "clinical", "row": i,
             "variable": name, "text": name, "fields": {"variable": name, "definition": definition}}
            for i, definition in ((2, "Use the first record."), (3, "Use the last record."))]
    found = [finding for finding in spec_lint.scan({"rows": rows}, tabs=["Clinical"]) if finding["kind"] == "DUPLICATE_VARIABLE"]
    assert {finding["item_id"] for finding in found} == {"clinical:2", "clinical:3"}


def test_distant_single_xlsx_cell_is_retained_and_flagged_for_review(tmp_path):
    import spec_extract
    openpyxl = pytest.importorskip("openpyxl", reason="XLSX intake requires openpyxl")
    path = tmp_path / "sparse.xlsx"
    workbook = openpyxl.Workbook()
    sheet = workbook.active
    sheet.title = "Clinical"
    sheet.append(["Variable", "Label", "Definition"])
    sheet.append(["index_date", "Index date", "First qualifying date."])
    sheet.cell(5000, 1, "accidental_marker")
    workbook.save(path)
    workbook.close()
    data = spec_extract.extract(str(path), domains={"clinical": "clinical"})
    distant = [row for row in data["rows"] if row["row"] == 5000]
    assert len(distant) == 1 and distant[0]["variable"] == "accidental_marker"
    findings = [finding for finding in spec_lint.scan(data) if finding["kind"] == "ROW_GAP"]
    assert len(findings) == 1 and findings[0]["item_id"] == distant[0]["item_id"]
    assert "single populated cell" in findings[0]["detail"]
    assert "retained" in findings[0]["detail"] and "confirm whether" in findings[0]["detail"]
    # Existing shape evidence must not duplicate this review question; excluding
    # the whole tab through the established sheet scope must exclude its finding.
    data["extraction"]["sources"] = [{"tab": "Clinical", "file": "sparse.xlsx", "shape": {"row_gaps": [[2, 5000]]}}]
    assert len([finding for finding in spec_lint.scan_shape(data) if finding["kind"] == "ROW_GAP"]) == 1
    assert not spec_lint.scan_shape(data, tabs=["Other"])


@pytest.mark.parametrize("module", ["test_stage_conformance", "test_stages_spark"])
def test_spark_suite_discovers_local_java_before_creating_its_session(monkeypatch, module):
    import importlib
    import java_home
    suite = importlib.import_module(module)
    calls = []
    monkeypatch.setattr(java_home, "ensure", lambda: calls.append("java"))
    sentinel = object()
    class Builder:
        def master(self, *_): return self
        def appName(self, *_): return self
        def config(self, *_): return self
        def getOrCreate(self):
            assert calls == ["java"]
            return sentinel
    monkeypatch.setattr(suite, "SparkSession", SimpleNamespace(builder=Builder()))
    monkeypatch.setattr(suite, "_SPARK", None)
    assert suite._spark() is sentinel
