"""Development confirmations advance only the explicit portal progress verdict."""
from pathlib import Path
from copy import deepcopy
import sys

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "tools"))
sys.path.insert(0, str(Path(__file__).resolve().parents[2] / "experiments" / "portal"))
import approval_identity as ai
import development_review
import event_ledger
import flow
import flow_guidance
import source_manifest as sm
import status
import review_setup

PACK = "products/oncology/demo/202606"
SOURCE = PACK + "/source_refs.yaml"


@pytest.fixture
def readiness(monkeypatch, tmp_path):
    (tmp_path / PACK).mkdir(parents=True)
    monkeypatch.setattr(sm, "pack_role", lambda entry: ("product", None))
    monkeypatch.setattr(sm, "registry_entry", lambda *args: {})
    monkeypatch.setattr(sm, "source_status", lambda *args: "approved")
    monkeypatch.setattr(sm, "check", lambda *args: [])
    monkeypatch.setattr(event_ledger, "check", lambda *args, **kwargs: [])
    monkeypatch.setattr(sm, "maturity", lambda *args: {"contract": "approved", "configuration": "approved"})
    monkeypatch.setattr(sm, "maturity_errors", lambda *args: [])
    monkeypatch.setattr(sm, "semantic_blockers", lambda *args: [])
    return str(tmp_path)


def row(who="Primary Reviewer", field="approved_by", file=SOURCE, governs="Gate 1"):
    return {"file": file, "field": field, "who": who, "governs": governs,
            "why": "independent identity evidence is unavailable"}


def test_production_never_reads_development_confirmations(readiness, monkeypatch):
    monkeypatch.setattr(ai, "unauthenticated", lambda *args: ([row()], []))
    def forbidden(*args):
        pytest.fail("A production verdict consulted development confirmations")
    monkeypatch.setattr(development_review, "confirmed_claims", forbidden)
    ready, why = sm.releasable(readiness, PACK)
    assert not ready and len(why) == 1 and "is not authenticated" in why[0]


def test_current_confirmation_advances_development_only(readiness, monkeypatch):
    monkeypatch.setattr(ai, "unauthenticated", lambda *args: ([row()], []))
    confirmations = {(SOURCE, "approved_by", "Primary Reviewer")}
    monkeypatch.setattr(development_review, "confirmed_claims", lambda *args: confirmations)
    assert sm.development_readiness(readiness, PACK) == (True, [])
    assert sm.releasable(readiness, PACK)[0] is False
    # The evidence owner withdraws a confirmation when its reviewed bytes change.
    confirmations.clear()
    assert sm.development_readiness(readiness, PACK)[0] is False


def test_confirmation_cannot_hide_other_reviewers_or_evidence_errors(readiness, monkeypatch):
    release_file = PACK + "/handoff/RELEASE_APPROVAL.yaml"
    rows = [row(), row("Independent Reviewer"), row("Independent Reviewer", file=release_file, governs="Gate 6"),
            row(field=None)]
    monkeypatch.setattr(ai, "unauthenticated", lambda *args: (rows, ["registry is malformed"]))
    monkeypatch.setattr(development_review, "confirmed_claims", lambda *args: {
        (SOURCE, "approved_by", "Primary Reviewer"),
        (release_file, "approved_by", "Primary Reviewer"),
        (SOURCE, None, "Primary Reviewer"),
    })
    monkeypatch.setattr(sm, "check", lambda *args: ["reviewed workbook has changed"])
    monkeypatch.setattr(event_ledger, "check", lambda *args, **kwargs: ["history is missing"])
    monkeypatch.setattr(sm, "maturity_errors", lambda *args: ["specification review is incomplete"])
    ready, why = sm.development_readiness(readiness, PACK)
    assert not ready
    text = "\n".join(why)
    assert "approved_by=Independent Reviewer is not authenticated" in text
    assert f"Gate 6: {release_file}" in text
    assert f"evidence: {SOURCE}" in text
    assert "registry is malformed" in text
    assert "reviewed workbook has changed" in text
    assert "history is missing" in text
    assert "specification review is incomplete" in text
    assert f"Gate 1: {SOURCE}: approved_by=Primary Reviewer" not in text


def test_release_confirmation_advances_demo_review_but_cannot_publish(readiness, monkeypatch):
    release_file = PACK + "/handoff/RELEASE_APPROVAL.yaml"
    monkeypatch.setattr(ai, "unauthenticated", lambda *args: ([row(file=release_file, governs="Gate 6")], []))
    monkeypatch.setattr(development_review, "confirmed_claims", lambda *args: {
        (release_file, "approved_by", "Primary Reviewer"),
    })
    assert sm.development_readiness(readiness, PACK) == (True, [])
    assert sm.releasable(readiness, PACK)[0] is False
    assert sm.publishable(readiness, PACK, "build-1", "a" * 64)[0] is False


def test_status_development_selection_is_explicit(monkeypatch, tmp_path):
    called = []
    def evaluate(root, pack, *, development=False):
        called.append(development)
        return [(1, "Inputs", "done", [])]
    monkeypatch.setattr(status, "_gates", evaluate)
    status.gates(str(tmp_path), PACK)
    status.gates(str(tmp_path), PACK, development=True)
    assert called == [False, True]


def test_flow_forwards_development_without_changing_cli_default(monkeypatch, tmp_path):
    called = []
    def gates(root, pack, *, development=False):
        called.append(development)
        return [(n, status.GATE_TITLES[n], "done", []) for n in range(1, 7)]
    monkeypatch.setattr(status, "gates", gates)
    monkeypatch.setattr(flow, "acts", lambda *args, **kwargs: {6: []})
    monkeypatch.setattr(flow, "CLOSING", ())
    production = flow.flow(str(tmp_path), PACK)
    development = flow.flow(str(tmp_path), PACK, development=True)
    assert called == [False, True]
    assert production["development"] is False
    assert development["development"] is True
    assert flow.render(development).startswith("DEVELOPMENT FLOW")
    assert flow.render(production).startswith("FLOW")


def test_development_identity_card_uses_email_copy_without_mutating_routes_or_production(monkeypatch, tmp_path):
    finding = f"Gate 1: {SOURCE}: approved_by=Primary Reviewer is not authenticated — no registered key"
    evidence = [(n, status.GATE_TITLES[n], "in progress" if n == 1 else "done", [finding] if n == 1 else [])
                for n in range(1, 7)]
    monkeypatch.setattr(status, "gates", lambda *args, **kwargs: evidence)
    menu = {n: [] for n in range(1, 7)}
    menu[1] = [{"id": "g1_commit", "label": "Commit the registration", "kind": "person", "argv": [],
                "path": SOURCE, "actions_row": "review_source", "note": "Use the registered review key"}]
    original_menu = deepcopy(menu)
    monkeypatch.setattr(flow, "acts", lambda *args, **kwargs: menu)
    production = flow.flow(str(tmp_path), PACK)
    original_production = deepcopy(production)
    development = flow.flow(str(tmp_path), PACK, development=True)
    assert menu == original_menu and production == original_production
    card = development["blockers"][0]
    assert card["text"] == "Confirm Primary Reviewer's review with name and email."
    assert card["reported_text"] == finding
    assert development["gates"][0]["blockers"] == [finding]
    action = card["fixes"][0]
    assert (action["id"], action["path"], action["actions_row"]) == ("g1_commit", SOURCE, "review_source")
    copy = flow_guidance.issue_copy(action)
    assert "name and email" in copy["title"]
    assert "No signing key is required" in copy["summary"]
    assert flow_guidance.act_title(action) == copy["title"]
    assert "name and email" not in flow_guidance.act_title(menu[1][0])
    assert flow_guidance.blocker_lines([finding], development=True) == [card["text"]]
    assert "has not been signed" in flow_guidance.blocker_copy(finding)


def test_development_copy_leaves_nonidentity_failures_unchanged():
    failures = [{"text": "Gate 1: reviewed workbook has changed", "fixes": []},
                {"text": "approval identity: registry is malformed", "fixes": []}]
    assert flow._development_cards(failures) == failures
    assert all(flow.development_review_request(card["text"]) is None for card in failures)


@pytest.mark.parametrize("filename,field,gate", [
    ("CONTRACT_APPROVAL.yaml", "spec_qc_reviewed_by", 2),
    ("CONFIGURATION_APPROVAL.yaml", "technically_reviewed_by", 4),
])
def test_primary_confirmation_cannot_complete_an_independent_review(readiness, monkeypatch, filename, field, gate):
    relative = f"{PACK}/handoff/{filename}"
    form = Path(readiness) / relative
    form.parent.mkdir()
    form.write_text(f"approved_by: Priya Sharma\n{field}: Alex Morgan\n", encoding="utf-8")
    # Production reports the primary approval alone. Exercise real content-bound
    # development snapshots and saved confirmations to cover the supporting act.
    monkeypatch.setattr(ai, "unauthenticated", lambda *args: ([row("Priya Sharma", file=relative, governs=f"Gate {gate}")], []))
    def confirm(who, email):
        prepared = review_setup.development_snapshot(readiness, PACK, "science")
        review_setup.confirm_development(readiness, PACK, "science", who, email, prepared["digest"],
                                         confirmed=True, local_demo=True, can_review=True)
    confirm("Priya Sharma", "priya@example.test")
    ready, why = sm.development_readiness(readiness, PACK)
    assert not ready and len(why) == 1
    assert why[0].startswith(f"Gate {gate}: {relative}: {field}=Alex Morgan is not authenticated")
    menu = {gate: [{"id": f"g{gate}_commit", "label": "Record review", "kind": "person", "argv": []}]}
    fixes, held_by = flow._route(why[0], menu[gate], menu)
    assert fixes[0]["id"] == f"g{gate}_commit" and held_by is None
    assert flow.development_review_request(why[0])["reviewer"] == "Alex Morgan"
    confirm("Alex Morgan", "alex@example.test")
    assert sm.development_readiness(readiness, PACK) == (True, [])
    assert sm.releasable(readiness, PACK)[0] is False
    form.write_text(form.read_text(encoding="utf-8") + "# Revised after review\n", encoding="utf-8")
    ready, why = sm.development_readiness(readiness, PACK)
    assert not ready
    assert any("approved_by=Priya Sharma" in finding for finding in why)
    assert any(f"{field}=Alex Morgan" in finding for finding in why)


def test_development_does_not_invent_an_absent_independent_attribution(readiness, monkeypatch):
    form = Path(readiness) / PACK / "handoff/CONTRACT_APPROVAL.yaml"
    form.parent.mkdir()
    form.write_text("approved_by: Priya Sharma\n", encoding="utf-8")
    monkeypatch.setattr(ai, "unauthenticated", lambda *args: ([], []))
    assert sm.development_readiness(readiness, PACK) == (True, [])
