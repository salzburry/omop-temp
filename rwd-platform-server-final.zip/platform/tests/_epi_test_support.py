"""Run these fixture-based tests under pytest or the repository's script-only CI.

The script adapter implements only the two test declarations used by the callers;
it is not an alternative pytest runtime and imports no optional dependency in CI.
"""
from contextlib import contextmanager
import inspect
from pathlib import Path
import tempfile
import traceback
from types import SimpleNamespace


def api(module_name):
    if module_name != "__main__":
        try:
            import pytest
            return pytest
        except ImportError:
            pass  # A script-only UI suite may import a backend fixture module.

    def parametrize(names, values):
        def decorate(fn):
            fn._epi_cases = (names, values)
            return fn
        return decorate

    @contextmanager
    def raises(expected):
        try:
            yield
        except expected:
            return
        raise AssertionError(f"Expected {expected.__name__}")

    return SimpleNamespace(mark=SimpleNamespace(parametrize=parametrize), raises=raises)


def run(namespace):
    passed, failed = 0, 0
    for name, fn in list(namespace.items()):
        if not name.startswith("test_") or not callable(fn):
            continue
        names, values = getattr(fn, "_epi_cases", ("", [()]))
        fields = [field.strip() for field in names.split(",") if field.strip()]
        for index, valueset in enumerate(values):
            kwargs = dict(zip(fields, (valueset,) if len(fields) == 1 else valueset))
            with tempfile.TemporaryDirectory(prefix="epi-test-") as directory:
                if "tmp_path" in inspect.signature(fn).parameters:
                    kwargs["tmp_path"] = Path(directory)
                try:
                    fn(**kwargs)
                    passed += 1
                except Exception:
                    failed += 1
                    print(f"FAIL {name}[{index}]")
                    traceback.print_exc()
    print(f"{passed} passed, {failed} failed")
    return 1 if failed else 0
