"""Eleventh external verdict, SECOND PASS (2026-09-04, main 7e88c36) — what the first repair left open.

An adversarial re-run of every claim PR #22 made, plus the findings the verdict listed that the
first pass did not touch. Each test here was red on 7e88c36 before its fix landed.

  CI     two suites were red from `platform/` (CI's working directory) and green from the root:
         a checkout-relative pack id was resolved against the cwd
  P1     the draft-time variable check accepted a bare prefix (`D` over DATAV, `AGE` over AGE18)
         and any mention in the notes (`not related to datav at all`); no lint invariant held a
         COMMITTED record to its own row, so a rewired citation passed all 22 invariants
  P1     the ledger epoch globbed *.json where events are *.yaml, so every committed answer sealed
         as a pre-ledger import and a second --apply appended a twin event; a signed row counted
         as "nobody behind it"; issued forms went stale with nothing red until a person typed
  P1     quick_counts logged demand for refused requests; accepted duplicate/ragged frames and blank
         ids; a missing frame was a traceback
  P1     spec_diff crashed on a pack without a register, exited 0 on "nothing compared", lost the
         RE-DRAFT reasons when nothing carried, and pasted `python3` into PowerShell
  P2     a CONFIGURATION_APPROVAL.yaml whose digests no longer matched was never examined below
         `configuration: approved`; `--out ./handoff/X.md` still missed the pack

NO PYTEST FIXTURES AND NO `parametrize` — CI runs every suite as a script.
"""
import contextlib
import io
import json
import os
import re
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

FRAMEWORK = Path(__file__).resolve().parent.parent
ROOT = FRAMEWORK.parent
for p in (FRAMEWORK / "tools", FRAMEWORK, FRAMEWORK / "engine", FRAMEWORK / "tests" / "fixtures",
          ROOT / "experiments" / "agent", ROOT / "experiments" / "portal"):
    sys.path.insert(0, str(p))
os.environ.setdefault("PYTHONUTF8", "1")

PROSTATE = "fixtures/oncology/prostate/202606"
BLADDER = "sandbox/demo_walkthrough/bladder/202609"


def _read(rel):
    return (ROOT / rel).read_text(encoding="utf-8")


def _cli(tool, *args, cwd=None):
    env = dict(os.environ, PYTHONUTF8="1")
    p = subprocess.run([sys.executable, str(FRAMEWORK / "tools" / tool), *args], cwd=cwd or str(ROOT),
                       env=env, capture_output=True, text=True, encoding="utf-8", errors="replace",
                       timeout=600)
    return p.returncode, (p.stdout or "") + (p.stderr or "")


@contextlib.contextmanager
def _cwd(path):
    old = os.getcwd()
    os.chdir(path)
    try:
        yield
    finally:
        os.chdir(old)


# ------------------------------------------------------------------ CI: a pack id is checkout-relative

def test_a_checkout_relative_pack_id_resolves_from_any_working_directory():
    from spec_extract import pack_path, repo_relative  # noqa: PLC0415
    with _cwd(str(FRAMEWORK)):                                  # CI's working directory
        assert repo_relative(pack_path(PROSTATE)) == PROSTATE
        assert repo_relative(pack_path(BLADDER)) == BLADDER
        import quick_counts as qc  # noqa: PLC0415
        ok, why = qc.approved_dimension(PROSTATE, "ecog")
        assert ok, why
        import contract_scaffold as cs  # noqa: PLC0415
        assert cs.evidence_for(BLADDER, "demographics:2")["_variable"] == "AGE"
    with tempfile.TemporaryDirectory() as d:
        assert pack_path(d) == os.path.normpath(d), "an absolute path is itself"
        with _cwd(d):
            os.makedirs("here/202606")
            assert pack_path("here/202606") == os.path.abspath("here/202606"), "a cwd-relative dir wins"
    # Exercise the actual import/path boundary in a separate interpreter, without
    # hiding an entire second audit run inside this path-resolution assertion.
    code = "\n".join([
        "import sys, json",
        f"sys.path.insert(0, {str(FRAMEWORK / 'tools')!r})",
        "from spec_extract import pack_path, repo_relative",
        f"packs = {[PROSTATE, BLADDER]!r}",
        "print(json.dumps([repo_relative(pack_path(pack)) for pack in packs]))",
    ])
    with tempfile.TemporaryDirectory() as elsewhere:
        for cwd in (str(FRAMEWORK), elsewhere):
            p = subprocess.run([sys.executable, "-c", code], cwd=cwd, capture_output=True, text=True,
                               encoding="utf-8", errors="strict", timeout=45)
            assert p.returncode == 0, p.stderr
            assert json.loads(p.stdout) == [PROSTATE, BLADDER]


# ------------------------------------------------------------------ P1 the citation rule and I25

def test_the_citation_rule_is_one_rule_shared_by_drafting_and_lint():
    import contract_lint as cl  # noqa: PLC0415
    import contract_record as cr  # noqa: PLC0415
    # the same variable, under the scaffold's grammar
    assert cl.cites_own_variable("age", "AGE") and cl.cites_own_variable("Data V", "DATA_V")
    # the record is the row's variable plus a separator-delimited suffix (the scaffold's dedupe, a qualifier)
    assert cl.cites_own_variable("DTHFL__2", "DTHFL") and cl.cites_own_variable("AGE_AT_INDEX", "AGE")
    # every bare prefix the second pass found accepted is refused
    for rec, row in (("D", "DATAV"), ("DAT", "DATAV"), ("AGE", "AGE18"), ("AGE", "AGEGR1"), ("LOT1", "LOT1SD"),
                     ("INDEX", "INDEXYR"), ("FU", "FUDUR"), ("MCRPCDD", "MCRPCDDYR"), ("FU_ENDDT", "FU_ENDDT_preliminary"),
                     ("FU_EN", "FU_ENDDT")):
        assert not cl.cites_own_variable(rec, row), (rec, row)
    # an abbreviated LAST word of a multi-word name is the same name
    assert cl.cites_own_variable("FU_ENDDT_PRELIM", "FU_ENDDT_preliminary")
    assert cl.cites_own_variable("HRR_INDEX_TEST", "HRR_INDEX_TESTING")
    # the acknowledgment is structured: the row's variable in depends_on
    assert cl.cites_own_variable("PFUDUR", "FU", ["INDEXDT", "FU"])
    assert cl.cites_own_variable("FU_ENDDT", "FU_ENDDT_preliminary", ["FU_ENDDT_preliminary"])
    # a prose-named row is not checkable
    assert cl.cites_own_variable("DAYS_PER_MONTH", "Days to months conversion")
    # ...and a mention in the notes, negated or not, is not an acknowledgment
    assert not cr._cites_own_variable({"notes": "not related to datav at all"}, "AGE", "DATAV")
    assert not cr._cites_own_variable({"notes": "no impact on OS"}, "AGE", "OS")
    assert not cr._cites_own_variable({"derivation": "year of index minus birth year"}, "AGE", "INDEX")
    assert cr._cites_own_variable({"depends_on": ["DATAV"]}, "STUDY_METADATA", "DATAV")
    assert cr._cites_own_variable({"depends_on": "[INDEXDT, FU]"}, "PFUDUR", "FU"), "a table cell is a list too"


def test_a_draft_with_no_variable_id_merges_nothing_and_the_wrong_row_is_refused_as_a_subprocess():
    import contract_record as cr  # noqa: PLC0415
    rec, probs = cr.merge_evidence({"derivation": "x"}, BLADDER, "study_period:4")
    assert probs and "variable_id" in probs[0] and "spec_refs" not in rec
    for draft in ({"variable_id": "AGE", "notes": "not related to datav at all"},
                  {"variable_id": "D"}, {"variable_id": "AGE", "notes": "no impact on OS"}):
        _r, probs = cr.merge_evidence(dict(draft, requirement="draft"), BLADDER, "study_period:4")
        assert probs and "Nothing of study_period:4 was merged" in probs[0], (draft, probs)
    # as a subprocess, from CI's working directory, against the demo pack by its checkout-relative id
    # (a copy outside the checkout is refused by the AI gate before the variable check — by design)
    with tempfile.TemporaryDirectory() as d:
        draft = os.path.join(d, "age.yaml")
        Path(draft).write_text("variable_id: AGE\nnotes: not related to datav at all\n", encoding="utf-8")
        before = (ROOT / BLADDER / "handoff" / "FUNCTIONAL_CONTRACT.md").read_bytes()
        rc, out = _cli("contract_record.py", draft, "--product", BLADDER, "--item", "study_period:4",
                       cwd=str(FRAMEWORK))
        assert rc != 0 and "DATAV" in out and "AGE" in out and "Nothing of study_period:4 was merged" in out, out[-600:]
        assert (ROOT / BLADDER / "handoff" / "FUNCTIONAL_CONTRACT.md").read_bytes() == before


def test_lint_i25_catches_a_committed_record_rewired_to_another_variables_row():
    import contract_lint as cl  # noqa: PLC0415
    assert "I25" in cl.INVARIANTS
    errors, _n = cl.run(str(ROOT / PROSTATE))
    assert not [e for e in errors if " I25 " in e], errors[:3]
    with tempfile.TemporaryDirectory() as d:
        tmp = os.path.join(d, "202606")
        shutil.copytree(ROOT / PROSTATE, tmp, ignore=shutil.ignore_patterns("__pycache__"))
        path = Path(tmp, "handoff", "FUNCTIONAL_CONTRACT.md")
        text = path.read_text(encoding="utf-8")
        line = next(ln for ln in text.splitlines() if ln.startswith("| DTHFL |"))
        rewired = line.replace("| [clinical:93] |", "| [clinical:2] |", 1)
        assert rewired != line
        path.write_text(text.replace(line, rewired, 1), encoding="utf-8")
        errors, _n = cl.run(tmp)
        hit = [e for e in errors if "[DTHFL]" in e and " I25 " in e]
        assert hit and "MCRPCDD" in hit[0], errors[:6]


def test_every_committed_record_cites_its_own_row_or_names_the_row_it_derives_from():
    import contract_lint as cl  # noqa: PLC0415
    for pack in (PROSTATE, "fixtures/oncology/oc/202606"):
        errors, n = cl.run(str(ROOT / pack))
        assert n and not [e for e in errors if " I25 " in e], (pack, [e for e in errors if " I25 " in e][:3])
    text = _read(PROSTATE + "/handoff/FUNCTIONAL_CONTRACT.md")
    assert re.search(r"^\| PFUDUR \|.*\[INDEXDT, MAXINDEX, FU\]", text, re.M), "PFUDUR names FU, the row it derives from"


# ------------------------------------------------------------------ P1 the decision ledger

def _decision_root():
    from _packs import PARKED  # noqa: PLC0415
    tmp = tempfile.mkdtemp(prefix="pass2_")
    rel = "fixtures/oncology/prostate/202607"
    dest = os.path.join(tmp, rel)
    os.makedirs(os.path.dirname(dest))
    shutil.copytree(PARKED, dest, ignore=shutil.ignore_patterns("__pycache__", "reference"))
    return tmp, rel


def _fill(form_path, **over):
    import yaml  # noqa: PLC0415
    doc = yaml.safe_load(Path(form_path).read_text(encoding="utf-8"))
    doc.update({"answer": "Use the spec value.", "answered_by": "Alex Morgan", "answer_date": "2026-09-04"})
    doc.update(over)
    head = "# Decision answer form — fill BY HAND, then commit.\n"
    Path(form_path).write_text(head + yaml.safe_dump(doc, sort_keys=False, allow_unicode=True), encoding="utf-8")


def test_the_ledger_epoch_reads_the_ledgers_own_files_and_a_seal_never_twins():
    import decision_record as dr  # noqa: PLC0415
    import event_ledger as el  # noqa: PLC0415
    root, rel = _decision_root()
    try:
        assert dr._ledger_epoch(root) is None
        written, _k, note = dr.write_forms(rel, root=root)
        assert note is None and written
        form = written[0]
        did = Path(form).stem
        _fill(form)
        applied, _s, errors, new_text = dr.apply_forms(rel, [form], root=root)
        assert errors == [] and applied == [did]
        dr._atomic_write(os.path.join(root, rel, dr.DECISIONS), new_text)
        event, why = dr.record_event(root, rel, did, "2026-09-04T10:00:00Z")
        assert why is None and event["action"] == "answered" and event["seq"] == 1
        # the epoch is now the first sealed instant — read from the *.yaml the ledger writes
        assert dr._ledger_epoch(root) == "2026-09-04T10:00:00Z"
        # the answer stays as typed: the header survives and object_uuid is one appended line
        text = Path(form).read_text(encoding="utf-8")
        assert text.startswith("# Decision answer form") and re.search(r"(?m)^object_uuid: [0-9a-f-]{36}$", text)
        # a second seal of the same act hands back the same event — never a twin
        again, why2 = dr.record_event(root, rel, did, "2026-09-04T11:00:00Z")
        assert why2 is None and again["event_sha256"] == event["event_sha256"]
        files = el._event_files(root, event["object_uuid"])
        assert len(files) == 1, files
    finally:
        shutil.rmtree(root, ignore_errors=True)


def test_a_signed_row_is_not_counted_as_unaccountable_and_a_stale_open_form_is_red_before_anyone_types():
    import decision_record as dr  # noqa: PLC0415
    import product_gates as pg  # noqa: PLC0415
    root, rel = _decision_root()
    try:
        written, _k, _n = dr.write_forms(rel, root=root)
        form = written[0]
        did = Path(form).stem
        _fill(form)
        applied, _s, errors, new_text = dr.apply_forms(rel, [form], root=root)
        assert errors == [] and applied == [did]
        dr._atomic_write(os.path.join(root, rel, dr.DECISIONS), new_text)
        by = pg.unaccountable_resolutions(os.path.join(root, rel), rel, by_decision=True)
        assert did not in by, "a fully signed row is not 'nobody behind it'"
        assert all(v for v in by.values()), "an entry exists only where a finding does"
        # an OPEN form goes stale when its citing records move; --check names it before a person types
        other = next(p for p in written if p != form)
        odid = Path(other).stem
        assert dr.stale_open_forms(rel, root=root) == []
        import yaml  # noqa: PLC0415
        doc = yaml.safe_load(Path(other).read_text(encoding="utf-8"))
        doc["records_sha256"] = "0" * 64
        Path(other).write_text(yaml.safe_dump(doc, sort_keys=False), encoding="utf-8")
        stale = dr.stale_open_forms(rel, root=root)
        assert stale and odid in stale[0] and "re-issue" in stale[0], stale
        src = _read("platform/tools/decision_record.py")
        assert "bad += stale_open_forms(pack, root=ROOT)" in src, "--check reports them"
    finally:
        shutil.rmtree(root, ignore_errors=True)


def test_the_bare_wave_skips_forms_nobody_answered_and_holds_a_named_form_to_its_content():
    import decision_record as dr  # noqa: PLC0415
    root, rel = _decision_root()
    try:
        written, _k, _n = dr.write_forms(rel, root=root)
        assert len(written) >= 2
        answered, untouched = dr.partition_untouched(rel, root=root)
        assert answered == [] and len(untouched) == len(written)
        _fill(written[0])
        answered, untouched = dr.partition_untouched(rel, root=root)
        assert answered == [written[0]] and Path(written[0]).stem not in untouched
        # a named blank form is still a defect
        _a, _s, errors, _t = dr.apply_forms(rel, [written[1]], root=root)
        assert errors and "blank" in errors[0]
    finally:
        shutil.rmtree(root, ignore_errors=True)


def test_the_four_prostate_forms_are_current_again():
    import decision_record as dr  # noqa: PLC0415
    assert dr.stale_open_forms(PROSTATE, root=str(ROOT)) == []


# ------------------------------------------------------------------ P2 an approval form below its level

def test_a_configuration_approval_whose_digests_moved_is_void_at_any_level():
    import product_gates as pg  # noqa: PLC0415
    with tempfile.TemporaryDirectory() as d:
        tmp = os.path.join(d, "202606")
        shutil.copytree(ROOT / PROSTATE, tmp, ignore=shutil.ignore_patterns("__pycache__"))
        m = pg.maturity(tmp)
        assert m["configuration"] == "draft"
        assert pg.configuration_approval_errors(tmp, PROSTATE, m) == []
        form = Path(tmp, "handoff", "CONFIGURATION_APPROVAL.yaml")
        form.write_text("approved_by: A Person\napproval_date: 2026-09-01\ntechnically_reviewed_by: B Person\n"
                        "approved_configuration_bundle_sha256: " + "a" * 64 + "\n"
                        "approved_against_contract_sha256: " + "b" * 64 + "\n", encoding="utf-8")
        errs = pg.configuration_approval_errors(tmp, PROSTATE, m)
        assert errs and all("VOID" in e for e in errs) and any("approved_configuration_bundle_sha256" in e for e in errs), errs
        # ...and a form whose digests DO match stays silent below `approved` (staged before the level flips)
        form.write_text("approved_configuration_bundle_sha256: " + pg.config_bundle_sha256(tmp) + "\n"
                        "approved_against_contract_sha256: "
                        + pg.requirements_sha256(os.path.join(tmp, "handoff", "FUNCTIONAL_CONTRACT.md")) + "\n", encoding="utf-8")
        assert pg.configuration_approval_errors(tmp, PROSTATE, m) == []


# ------------------------------------------------------------------ P1 quick_counts edges

def _frame(d, rows, header, name="frame.tsv"):
    path = os.path.join(d, name)
    with open(path, "w", encoding="utf-8", newline="\n") as fh:
        fh.write("\t".join(header) + "\n")
        for r in rows:
            fh.write("\t".join(str(x) for x in r) + "\n")
    return path


def _qc(argv):
    import quick_counts as qc  # noqa: PLC0415
    buf = io.StringIO()
    try:
        with contextlib.redirect_stdout(buf):
            rc = qc.main(argv)
    except SystemExit as e:
        return None, str(e), buf.getvalue()
    return rc, None, buf.getvalue()


def test_quick_counts_refuses_duplicate_headers_ragged_rows_blank_ids_and_a_missing_frame():
    with tempfile.TemporaryDirectory() as d:
        good = [(f"P{i:04d}", "C2", "1") for i in range(24)]
        base = ["--cut", "2023Q4", "--grain", "patient", "--log-dir", os.path.join(d, "log")]
        rc, err, _o = _qc([PROSTATE, "--frame", _frame(d, good, ["patientid", "cohort", "ecog"]), "--by", "ecog", *base])
        assert rc == 0, err
        dup = _frame(d, [r + ("2",) for r in good], ["patientid", "cohort", "ecog", "ecog"], "dup.tsv")
        rc, err, _o = _qc([PROSTATE, "--frame", dup, "--by", "ecog", *base])
        assert rc is None and "repeats a column name" in err
        ragged = _frame(d, good[:-1] + [("P9999", "C2")], ["patientid", "cohort", "ecog"], "ragged.tsv")
        rc, err, _o = _qc([PROSTATE, "--frame", ragged, "--by", "ecog", *base])
        assert rc is None and "ragged row" in err and "P9999" not in err
        blank = _frame(d, good[:-1] + [("", "C2", "1")], ["patientid", "cohort", "ecog"], "blank.tsv")
        rc, err, _o = _qc([PROSTATE, "--frame", blank, "--by", "ecog", *base])
        assert rc is None and "no value under" in err and not re.search(r"\d", err.split("—")[0].split("`")[0])
        rc, err, _o = _qc([PROSTATE, "--frame", os.path.join(d, "nope.tsv"), "--by", "ecog", *base])
        assert rc is None and "REFUSED" in err and "nope.tsv" not in err


def test_quick_counts_logs_an_assumption_only_for_a_count_that_ran():
    with tempfile.TemporaryDirectory() as d:
        log = os.path.join(d, "log")
        good = [(f"P{i:04d}", "C2", "1", "ABC") for i in range(24)]
        header = ["patientid", "cohort", "ecog", "site"]
        base = ["--cut", "2023Q4", "--grain", "patient", "--log-dir", log, "--assume", 'site="the treating site"']
        # a refused request (the filter column is absent from the frame) writes nothing
        absent = _frame(d, [r[:3] for r in good], header[:3], "absent.tsv")
        rc, err, _o = _qc([PROSTATE, "--frame", absent, "--where", "site=ABC", *base])
        assert rc is None and "not in the frame" in err
        assert not os.path.exists(os.path.join(log, "assumptions.jsonl")), "a refused request is not demand"
        # the preconditions are still checked first: no --assume for an assumed name is a refusal before any read
        rc, err, _o = _qc([PROSTATE, "--frame", absent, "--where", "site=ABC", "--cut", "2023Q4",
                           "--grain", "patient", "--log-dir", log])
        assert rc is None and "UNSTATED ASSUMPTION" in err
        rc, err, out = _qc([PROSTATE, "--frame", _frame(d, good, header), "--where", "site=ABC", *base])
        assert rc == 0, err
        lines = Path(log, "assumptions.jsonl").read_text(encoding="utf-8").splitlines()
        assert len(lines) == 1 and json.loads(lines[0])["pack"] == PROSTATE


def test_the_lane_produces_a_criterion_level_attrition_table_under_the_same_floor():
    """Audit item 7: criterion-level attrition in the scientist journey — the exploration lane's own
    grammar, the same floor and rounding, remaining and dropped per step, nothing per person."""
    import quick_counts as qc  # noqa: PLC0415
    assert qc.parse_steps(['Adults: cohort=C2', 'ecog=1']) == [("Adults", [("cohort", "=", "C2")]),
                                                                 ("step 2", [("ecog", "=", "1")])]
    with tempfile.TemporaryDirectory() as d:
        rows = [(f"P{i:04d}", "C2" if i < 40 else "C3", "1" if i % 4 else "2") for i in range(60)]
        frame = _frame(d, rows, ["patientid", "cohort", "ecog"])
        base = ["--cut", "2023Q4", "--grain", "patient", "--log-dir", os.path.join(d, "log")]
        rc, err, out = _qc([PROSTATE, "--frame", frame, "--by", "ecog", "--step", "C2 cohort: cohort=C2",
                            "--step", "ECOG 1: ecog=1", *base])
        assert rc == 0, err
        res = json.loads(out)
        table = res["attrition"]
        assert [r["step"] for r in table] == ["frame", "C2 cohort", "ECOG 1"]
        assert table[0]["remaining"] == 60 and table[1]["remaining"] == 40 and table[1]["dropped"] == 20
        assert table[2]["remaining"] == 30 and table[2]["dropped"] == f"<{qc.MIN_CELL}", "a dropped cell under the floor is floored too"
        assert all(isinstance(r["remaining"], (int, str)) for r in table)
        assert res["asked"]["steps"][0]["where"] == ["cohort=C2"], res["asked"]["steps"]
        assert "P0001" not in out
        # a step on an identifier is refused; a step richer than the grammar is refused, never skipped
        rc, err, _o = _qc([PROSTATE, "--frame", frame, "--step", "one person: patientid=P0001", *base])
        assert rc is None and "identifier" in err and "P0001" not in err
        rc, err, _o = _qc([PROSTATE, "--frame", frame, "--step", "window: ecog within 30 days", *base])
        assert rc is None and "definition that belongs in a pack" in err


def test_quasi_identifier_spellings_without_a_trailing_boundary_are_identifiers():
    import quick_counts as qc  # noqa: PLC0415
    for col in ("zipcode5", "zip5", "ssn4", "hashcode", "rowhash", "deviceserial", "birthyear", "postcode3"):
        assert qc.looks_like_identifier(col), col
    for col in ("cohort", "ecog", "opioid", "thyroid", "comorbid", "valid", "lipid", "hashimoto"):
        assert not qc.looks_like_identifier(col), col


# ------------------------------------------------------------------ P1 spec_diff on the documented packs

def test_spec_diff_stands_on_a_pack_without_a_register_and_says_when_nothing_was_compared():
    import spec_diff as sd  # noqa: PLC0415
    assert sd.INTERPRETER == ("python" if os.name == "nt" else "python3")
    with tempfile.TemporaryDirectory() as d:
        old = os.path.join(d, "sandbox", "demo_walkthrough", "bladder", "202609")
        new = os.path.join(d, "sandbox", "demo_walkthrough", "bladder", "202610")
        shutil.copytree(ROOT / BLADDER, old)
        shutil.copytree(ROOT / BLADDER, new)
        assert not os.path.exists(os.path.join(old, "handoff", "DECISIONS.md")), "the demo pack keeps no register"
        # every record RE-DRAFTs when its row's text changed: the plan still carries the reasons
        ext = Path(new, "spec_pipeline", "out", "extracted.json")
        data = json.loads(ext.read_text(encoding="utf-8"))
        for row in data["rows"]:
            if row.get("item_id") == "clinical:2":
                row["content_hash"] = "ffffffffffff"
        ext.write_text(json.dumps(data, indent=1), encoding="utf-8")
        out = sd.render(sd.repo_relative(old, d), sd.repo_relative(new, d), root=d)
        assert "Traceback" not in out and "None. Either nothing carries" in out or "carr" in out
        plan = os.path.join(d, "plan")
        written, commands, by_hand, excluded, note = sd.carry_plan(
            sd.repo_relative(old, d), sd.repo_relative(new, d), plan, root=d)
        assert note is None
        manifest = Path(plan, "carry_commands.txt")
        assert manifest.exists(), "a plan with nothing mechanical still holds its RE-DRAFT reasons"
        text = manifest.read_text(encoding="utf-8")
        assert "interpreter named below" in text
        assert all(c.startswith(sd.INTERPRETER + " ") for c in commands)
        assert (excluded and "RE-DRAFT" in text) or written
    # "nothing to compare" is a non-zero exit
    rc, out = _cli("spec_diff.py", "fixtures/oncology/prostate/202603", PROSTATE)
    assert rc == 2 and "nothing was compared" in out, (rc, out[-300:])


def test_source_check_out_is_re_rooted_against_the_resolved_pack():
    import source_check as sc  # noqa: PLC0415
    with tempfile.TemporaryDirectory() as d:
        assert sc.resolve_out("./handoff/X.md", d) == os.path.join(d, "handoff", "X.md")
        assert sc.resolve_out("handoff\\X.md", d) == os.path.join(d, "handoff", "X.md")
        assert sc.resolve_out("reports/X.md", d) == "reports/X.md"
    src = _read("platform/tools/source_check.py")
    assert "a.out = resolve_out(a.out, product)" in src and "product = pack_path(a.product, ROOT)" in src


# ------------------------------------------------------------------ the rest of the second pass

class _Scripted:
    """A model that answers from a script — the intake tests' own pattern, no network."""
    def __init__(self, replies):
        self.replies = list(replies)
        self.calls = 0

    def step(self, _system, _transcript):
        self.calls += 1
        return self.replies.pop(0)


def test_a_person_can_clear_an_intake_slot_and_a_cleared_slot_is_not_refilled():
    import intake  # noqa: PLC0415
    st = intake.new_state("product_brief", PROSTATE, "alex")
    assert st["cleared"] == []
    m = _Scripted([json.dumps({"request": {"population": "mCRPC", "exposure": "abiraterone", "comparator": "enzalutamide"},
                               "ask": "next?"}),
                   json.dumps({"request": {"comparator": None}, "ask": "next?"}),                 # null never clears
                   json.dumps({"request": {}, "unset": ["exposure", "bogus"], "ask": "next?"}),  # the sentinel does
                   json.dumps({"request": {"comparator": "none"}, "ask": "next?"})])            # a none-word on an optional slot
    st, _ = intake.next_turn(st, "compare abiraterone with enzalutamide in mCRPC", m)
    assert st["request"]["exposure"] == "abiraterone" and st["request"]["comparator"] == "enzalutamide"
    st, _ = intake.next_turn(st, "drop the comparison", m)
    assert st["request"]["comparator"] == "enzalutamide", "null from the model is 'not filled', never unset"
    st, _ = intake.next_turn(st, "actually, not comparative", m)
    assert st["request"]["exposure"] is None and "exposure" in st["cleared"] and "bogus" not in st["cleared"]
    st, reply = intake.next_turn(st, "clear comparator", m)             # typed: no model call
    assert m.calls == 3 and st["request"]["comparator"] is None and "comparator" in st["cleared"] and "cleared" in reply
    st, _ = intake.next_turn(st, "no comparator", m)
    assert st["request"]["comparator"] is None, "a none-word on an optional slot is empty"
    assert "exposure" not in intake.unsupported_requirements(st)
    y = intake.to_yaml(st)
    assert "cleared:" in y and "- exposure" in y
    assert "Cleared by the person" in intake.to_goal(st)
    past = {"kind": "product_brief", "pack": PROSTATE, "status": "checked",
            "request": {"exposure": "docetaxel", "outcomes": "OS"}, "_file": "x.yaml"}
    filled = intake.prefill(st, past)
    assert filled["request"]["exposure"] is None and filled["request"]["outcomes"] == "OS", "a cleared slot stays cleared"
    # a required slot that is cleared is required again — clearing never bypasses readiness
    st2 = intake.new_state("question", PROSTATE, "x")
    st2["request"].update({"topic": "t", "question": "q", "evidence": "e", "owner": "Science", "requested_by": "x"})
    assert intake.ready(st2)
    st2, _ = intake.next_turn(st2, "clear question", _Scripted([]))
    assert not intake.ready(st2)


def test_the_kept_feasibility_request_names_its_exploration_command():
    import intake  # noqa: PLC0415
    st = intake.new_state("feasibility", PROSTATE, "alex")
    st["request"].update({"source": "Flatiron 2026-06", "index_codes": "C61", "exclusions": "prior lung cancer",
                          "requested_by": "Alex"})
    cmd = intake.exploration_command(st)
    assert cmd.startswith(f"python3 platform/tools/quick_counts.py {PROSTATE} --frame ")
    assert '--step "index condition (C61): <col>=<value>"' in cmd and '--step "exclude (prior lung cancer): <col>=<value>"' in cmd
    assert "--grain patient" in cmd and "--log-dir" in cmd and "non-evidence grade" in cmd
    assert "exploration_command:" in intake.to_yaml(st)
    assert intake.exploration_command(intake.new_state("question", PROSTATE, "x")) is None
    assert "EXPLORATION" in _read("experiments/agent/intake/feasibility.yaml") and "--step" in _read("experiments/agent/intake/feasibility.yaml")


def test_the_read_surface_carries_a_dictionary_preview_and_the_portal_offers_it():
    import mcp_server as srv  # noqa: PLC0415
    assert "dictionary" in srv.READ_TOOLS
    out = srv.t_dictionary({"pack": PROSTATE})
    assert "data dictionary PREVIEW" in out and "no data behind it" in out and "REFERENCE FIXTURE" in out
    assert "| MCRPCDD | date | clinical |" in out and out.count("\n|") > 100
    app = _read("experiments/portal/app.py")
    assert 'cached(SCOPE_KEY, "dictionary", pack=pack)' in app and "DICTIONARY_TOGGLE" in _read("experiments/portal/ui_text.py")
    # the demo watermark belongs to a non-product pack, and the local demo opens on the fixture with evidence
    # ...and only on a page ABOUT the pack: Home and New product are not about the selected pack
    # (2026-09-04), so the reference watermark stays off them
    import ast
    tree = ast.parse(app)
    guard = next(node for node in tree.body if isinstance(node, ast.If)
                 and any(isinstance(call, ast.Call) and ast.unparse(call.func) == "theme.watermark"
                         for call in ast.walk(node)))
    page = next(node.value for node in tree.body if isinstance(node, ast.Assign)
                and any(isinstance(target, ast.Name) and target.id == "PACK_PAGE" for target in node.targets))
    condition = compile(ast.Expression(guard.test), "<reference watermark guard>", "eval")
    for section in ("Home", "New product", "Plan changes", "Status"):
        is_pack_page = eval(compile(ast.Expression(page), "<selected product page>", "eval"), {"section": section})
        for local in (True, False):
            for badge in ("", "REFERENCE FIXTURE"):
                shown = eval(condition, {"LOCAL_WRITES": local, "BADGE": badge, "PACK_PAGE": is_pack_page})
                assert bool(shown) is bool(local and badge and section == "Status")
    import portal_packs as pp  # noqa: PLC0415
    cat = pp.catalogue(str(ROOT))
    assert cat["references"][0] == PROSTATE, cat["references"][:3]
    assert pp.lineage(str(ROOT), PROSTATE) == ["fixtures/oncology/prostate/202603"]


def test_a_workbook_that_declares_another_disease_is_refused_and_an_unresolved_tumour_never_generates():
    import spec_lint as sl  # noqa: PLC0415
    import run_spec_pipeline as rsp  # noqa: PLC0415
    from spec_extract import requirement_rows  # noqa: PLC0415
    assert sl.SEVERITY["DECLARED_DISEASE"] == "HIGH"
    gist = json.loads(_read("fixtures/oncology/gist/202608/spec_pipeline/out/extracted.json"))
    rows = requirement_rows(gist, None)
    assert sl.scan_declared_disease(rows, "gist") == []
    hits = sl.scan_declared_disease(rows, "bladder")
    assert hits and all(h["kind"] == "DECLARED_DISEASE" and "gist" in h["detail"] for h in hits)
    assert {h["item_id"] for h in hits} == {"study_population:2", "study_population:4"}
    for pack, tumor in ((PROSTATE, "prostate"), ("fixtures/oncology/oc/202606", "oc"), (BLADDER, "bladder")):
        d = json.loads(_read(pack + "/spec_pipeline/out/extracted.json"))
        assert sl.scan_declared_disease(requirement_rows(d, None), tumor) == [], pack
    notes = [n["note"] for n in sl.inapplicable_checks(rows, "asthma") if n["check"] == "declared_disease"]
    assert notes and "resolves to no tumour family" in notes[0]
    with tempfile.TemporaryDirectory() as d:
        lint = os.path.join(d, "lint.json")
        Path(lint).write_text(json.dumps({"findings": [], "applicability": {"reasons": [
            "FOREIGN_TABLE did not apply: 'asthma' resolves to no tumour family"]}}), encoding="utf-8")
        try:
            rsp.refuse_wrong_workbook("products/oncology/asthma/202609", {"TUMOR": "asthma"}, lint)
            raise AssertionError("an unresolved tumour generated")
        except SystemExit as e:
            assert "must not generate" in str(e) and "never relabelled" in str(e)
        Path(lint).write_text(json.dumps({"findings": hits, "applicability": {"reasons": []}}), encoding="utf-8")
        try:
            rsp.refuse_wrong_workbook(BLADDER, {"TUMOR": "bladder"}, lint)
            raise AssertionError("another disease's workbook generated")
        except SystemExit as e:
            assert "declares another disease's population" in str(e)
    # every committed lint.json carries the new applicability entry, applied
    for pack in ("fixtures/oncology/gist/202608", "fixtures/oncology/oc/202606", PROSTATE):
        lj = json.loads(_read(pack + "/spec_pipeline/out/lint.json"))
        assert lj["applicability"]["declared_disease"] == "applied", pack


def test_the_engine_says_what_it_is_from_the_command_line_and_the_registry():
    rc, out = _cli("../engine/validate.py", f"../{PROSTATE}/config/data_product.yaml", "--strict", cwd=str(FRAMEWORK))
    assert "config OK (strict mode)" in out or "(strict)" in out, out[-300:]
    with tempfile.TemporaryDirectory() as d:
        cfg = Path(d, "data_product.yaml")
        cfg.write_text(re.sub(r"^condition_class: oncology[^\n]*$", "condition_class: respiratory",
                              _read(PROSTATE + "/config/data_product.yaml"), count=1, flags=re.M), encoding="utf-8")
        rc, out = _cli("../engine/validate.py", str(cfg), cwd=str(FRAMEWORK))
        assert rc == 1 and "condition_class 'respiratory'" in out
    assert "condition_class" in _read("platform/tests/test_registry.py") and "condition_class" in _read("products/registry.yaml")
    assert "condition_class: oncology" in _read("platform/TUMOR_TEMPLATE/config/data_product.yaml")
    src = _read("platform/tools/bundle_products.py")
    assert 'str(t.get("condition_class") or "oncology")' in src and "builds oncology products" in src


def test_the_init_names_the_lone_workbook_and_refuses_a_placeholder_a_person_edited():
    import source_refs_init as sri  # noqa: PLC0415
    import yaml  # noqa: PLC0415
    tpl = _read("platform/TUMOR_TEMPLATE/source_refs.yaml")
    assert sri.placeholder_untouched(str(ROOT / "platform" / "TUMOR_TEMPLATE" / "source_refs.yaml"))
    with tempfile.TemporaryDirectory() as d:
        root = Path(d)
        pack = "products/oncology/testis/202608"
        (root / pack / "config").mkdir(parents=True)
        (root / pack / "prog_spec").mkdir()
        (root / pack / "config" / "data_product.yaml").write_text("data_product_id: t\n", encoding="utf-8")
        (root / "products").mkdir(exist_ok=True)
        (root / "products" / "registry.yaml").write_text(yaml.safe_dump({"tumors": [
            {"code": "testis", "name": "Testis", "slug": "testis", "vendor": "flatiron", "tumor_class": "solid",
             "status": "scaffold"}]}), encoding="utf-8")
        target = root / pack / "source_refs.yaml"
        target.write_text(tpl.replace('path_or_link: "products/<family>/<slug>/<YYYYMM>/prog_spec/<workbook>.xlsx"',
                                      'path_or_link: "products/oncology/testis/202608/prog_spec/real.xlsx"'), encoding="utf-8")
        assert not sri.placeholder_untouched(str(target)), "a path a person typed is an edit"
        old = sri.REPO
        sri.REPO = str(root)
        try:
            rc = sri.main([pack, "--ai-classification", "sponsor_ai_eligible", "--classified-by", "T. Test",
                           "--classified-date", "2026-08-14"])
            assert rc == 1 and "real.xlsx" in target.read_text(encoding="utf-8"), "the person's registration was replaced"
            target.write_text(tpl, encoding="utf-8")
            (root / pack / "prog_spec" / "PROG_SPEC_TESTIS_202608.xlsx").write_bytes(b"x")
            rc = sri.main([pack, "--ai-classification", "sponsor_ai_eligible", "--classified-by", "T. Test",
                           "--classified-date", "2026-08-14"])
            assert rc == 0
            doc = yaml.safe_load(target.read_text(encoding="utf-8"))
            assert doc["source_materials"][0]["path_or_link"] == f"{pack}/prog_spec/PROG_SPEC_TESTIS_202608.xlsx"
        finally:
            sri.REPO = old
    tests = _read("platform/TUMOR_TEMPLATE/handoff/tests/test_functional_contract.py")
    assert '"records": 0' in tests, "a copied pack is not red before its first record"
    assert "except (AssertionError, SystemExit, Exception)" in _read("platform/tests/test_governance.py")


def test_the_versioning_rule_is_enforced_on_an_active_product():
    import config_diff as cd  # noqa: PLC0415
    with tempfile.TemporaryDirectory() as d:
        root = Path(d)
        pack = "fixtures/oncology/prostate/202606"
        for sub in ("config", "variables", "codelists"):
            shutil.copytree(ROOT / pack / sub, root / pack / sub)
        (root / "fixtures").mkdir(exist_ok=True)
        shutil.copyfile(ROOT / "fixtures" / "registry.yaml", root / "fixtures" / "registry.yaml")
        log = root / "fixtures" / "oncology" / "prostate" / "CHANGELOG.md"
        log.write_text("# changelog\n\n## 202606\n- as released\n", encoding="utf-8")
        git = lambda *a: subprocess.run(["git", "-C", str(root), *a], capture_output=True, text=True,  # noqa: E731
                                        encoding="utf-8", check=True)
        git("init", "-q"); git("config", "user.email", "t@t"); git("config", "user.name", "t")
        git("add", "-A"); git("commit", "-q", "-m", "base")
        assert cd.versioning_findings(pack, "HEAD", root=str(root)) == []
        cfg = root / pack / "variables" / "outcomes.yaml"
        text = cfg.read_text(encoding="utf-8")
        assert "min_followup_days: 91" in text
        cfg.write_text(text.replace("min_followup_days: 91", "min_followup_days: 30", 1), encoding="utf-8")
        found = cd.versioning_findings(pack, "HEAD", root=str(root))
        assert found and "no CHANGELOG entry" in found[0] and "VERSIONING.md" in found[0], found
        # the entry is BOUND to the change (twelfth verdict, P1-3): it names the pack's YYYYMM and the
        # file that changed, or it classifies nothing in particular
        log.write_text(log.read_text(encoding="utf-8") + "\n- **additive**: follow-up floor moved\n", encoding="utf-8")
        found = cd.versioning_findings(pack, "HEAD", root=str(root))
        assert found and any("does not name this pack's spec_version" in f for f in found) \
            and any("names none of the changed file" in f for f in found), found
        log.write_text(log.read_text(encoding="utf-8").replace(
            "- **additive**: follow-up floor moved",
            "- 2026-09-04 **additive** 202606: follow-up floor moved (variables/outcomes.yaml)"), encoding="utf-8")
        found = cd.versioning_findings(pack, "HEAD", root=str(root))
        assert found and "NEW spec_version" in found[0], found
        # `none` may not classify a MATERIAL change — a follow-up floor is a value the build computes with
        log.write_text(log.read_text(encoding="utf-8").replace("**additive**", "**none**"), encoding="utf-8")
        found = cd.versioning_findings(pack, "HEAD", root=str(root))
        assert found and "`none` may not classify a MATERIAL change" in found[0] and "min_followup_days" in found[0], found
        # ...but it does classify wording: a label typo keeps the version
        cfg.write_text(text.replace('name: "Prostate (mHSPC + mCRPC) — outcomes parameters"',
                                    'name: "Prostate (mHSPC + mCRPC) - outcomes parameters"', 1), encoding="utf-8")
        assert 'name: "Prostate (mHSPC + mCRPC) - outcomes parameters"' in cfg.read_text(encoding="utf-8")
        assert cd.versioning_findings(pack, "HEAD", root=str(root)) == [], cd.versioning_findings(pack, "HEAD", root=str(root))
        # the environment file is not the executable surface; a scaffold pack is being authored
        cfg.write_text(text, encoding="utf-8")
        env = root / pack / "config" / "pipeline.yaml"
        env.write_text(env.read_text(encoding="utf-8").replace('refresh: "', 'refresh: "x', 1), encoding="utf-8")
        assert cd.versioning_findings(pack, "HEAD", root=str(root)) == []
    assert "--check-versioning" in _read(".github/workflows/rwdp-ci.yml")


if __name__ == "__main__":
    fails = 0
    for name, fn in sorted(globals().items()):
        if name.startswith("test_") and callable(fn):
            try:
                fn()
                print(f"  ok   {name}")
            except Exception as e:  # noqa: BLE001
                fails += 1
                print(f"  FAIL {name}: {type(e).__name__}: {str(e)[:400]}")
    print(f"{fails} failure(s)")
    sys.exit(1 if fails else 0)
