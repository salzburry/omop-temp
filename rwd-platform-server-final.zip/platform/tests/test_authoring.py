#!/usr/bin/env python3
"""THE PATH THE SKILL ADVERTISES, RUN END TO END. One test, on a pack nothing else has drafted into.

Everything else that covers this workflow covers a PROPERTY of it: that the renderer escapes a pipe,
that the scaffold emits the fields the tool accepts, that a name appears in the skill's prose. Each is
worth having and none of them establishes the claim a drafter actually relies on — that a person can
start from a specification row and finish with a validated record in a governed file, without at any
point being asked to invent, to paste, or to be trusted with a status.

That claim is a SEQUENCE, and a sequence is exactly what per-property tests cannot check. The two most
expensive defects this repository has had were both seams:

  * a NEW record citing an OPEN decision could not be produced AT ALL. The scaffold gives no status,
    `apply_status` therefore gave `requirement: draft`, and I11 requires `decision_required` for that
    record — while a drafter who supplied it was refused. Every piece worked; no input satisfied both.
  * the last step of an APPLY was "paste the printed row into FUNCTIONAL_CONTRACT.md". Nothing tested
    it because nothing could: it was a human action, and its failure modes — pasted twice, pasted
    beside the record it should have replaced, pasted with a terminal's line wrap in it — are defects
    in a governed artifact created by the procedure for maintaining that artifact.

So this walks all ten steps against the real tools, and then does the ELEVENTH thing the review asked
for and the workflow needs: it runs the whole thing again and requires the contract to be byte-
identical. An authoring path that is not idempotent is one where re-running after fixing a typo
silently duplicates a requirement.

It runs on a COPY, in a temp directory, and the pack is `platform/tests/fixtures/prostate_202607` —
which was never registered, never built and never released, and which no other suite drafts into.
"""
import os
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

HERE = Path(__file__).resolve().parent
REPO = HERE.parent.parent
TOOLS = REPO / "platform" / "tools"
sys.path.insert(0, str(TOOLS))
sys.path.insert(0, str(HERE / "fixtures"))
sys.path.insert(0, str(HERE))

import contract_lint as cl                                                          # noqa: E402
import contract_record as cr                                                        # noqa: E402
import contract_scaffold as cs                                                      # noqa: E402
import _packs                                                                       # noqa: E402

# THE APPROVAL HELPER IS IMPORTED, not rewritten. `_approved` copies a pack and signs its sanitized
# extraction against the copy — an approval binds to a path AND to bytes, so a live pack's approval is
# only valid where the live pack is. Its docstring carries why signing a throwaway is honest and where
# the refusal itself is asserted instead. A second copy of that reasoning here is how the two versions
# start to differ about what "approved for AI" means, which is the one thing this boundary cannot have.
from test_spec_slice import _approved                                               # noqa: E402

# The spec row this record is drafted from, and a variable_id no record in the fixture uses. Both are
# asserted below rather than assumed: a row that stopped existing, or an id that quietly became taken,
# would turn a passing test into one that no longer drafts anything.
ITEM = "clinical:89"
NEW_ID = "FU_ENDDT_PRELIM"
DECISION = "D-AUTHOR-1"


def _run(argv, **kw):
    """The drafting tool, as a drafter runs it — through its entry point, not its functions.

    `main(argv)` would skip argparse, and two of the guards this path relies on ARE argparse errors
    (`--apply` without `--product`, `--item` without `--product`). A test that called the function
    would pass while the command a person types fails.
    """
    return subprocess.run([sys.executable, str(TOOLS / "contract_record.py")] + argv,
                          capture_output=True, text=True, encoding="utf-8",
                          errors="replace", cwd=str(REPO), **kw)


def _contract(pack):
    return Path(pack) / "handoff" / "FUNCTIONAL_CONTRACT.md"


def _record(pack, vid):
    """The one block for `vid`, or None. Read through the parser every gate uses."""
    for b in cl.records(cl.read(str(_contract(pack)))):
        if (cl._scalar(b, "variable_id") or "").strip() == vid:
            return b
    return None


def _open_decision(pack, did):
    """Add an OPEN decision to the pack's register — the state a real drafter creates in step 4."""
    path = Path(pack) / "handoff" / "DECISIONS.md"
    text = path.read_text(encoding="utf-8")
    row = (f"| {did} | What does this variable do when the preliminary follow-up date is missing? "
           f"The spec states no otherwise-branch. | `{ITEM}` | Science | — |  |  | OPEN |\n")
    path.write_text(text.rstrip("\n") + "\n" + row, encoding="utf-8")
    assert cl.decision_status(path.read_text(encoding="utf-8")).get(did) == "OPEN", \
        "the register did not take the decision — the rest of this test would be vacuous"


def _judgment(tmp, **over):
    """A judgment file built FROM THE TOOL'S OWN STUB, with the drafter's answers filled in.

    Starting from `judgment_stub` rather than a literal is the point of step 3: if the stub ever emits
    a field the tool refuses — which is the defect it was written to fix — this test fails, instead of
    passing against a hand-maintained copy of what the stub used to say.
    """
    stub = cs.judgment_stub(NEW_ID)
    assert "status" not in stub.split("\n")[0] and "\nstatus:" not in stub, \
        "the stub emits a `status`, which the drafting tool refuses — step 3 is broken at the source"
    for machine in cs.MACHINE_OWNED:
        assert f"\n{machine}:" not in stub, f"the stub emits {machine}, which is evidence, not judgment"
    answers = {"window": "index_date to FU_ENDDT_preliminary",
               "record_selection": "all rows for the patient",
               "tie_break": "n/a — one value per patient",
               "derivation": "carried from FU_ENDDT_preliminary without transformation",
               "missing": "TODO",
               "acceptance": "a patient whose preliminary date is 2026-03-01 reports 2026-03-01",
               "notes": "drafted end to end by platform/tests/test_authoring.py",
               "decision_ids": f"[{DECISION}]",
               "source": "{kind: pending_mapping, spec_identifiers: [FU_ENDDT_preliminary]}",
               "grain": "one row per patient",
               "anchor": "index_date",
               "cohort_applicability": "all patients",
               "units": "date",
               "depends_on": "[FU_ENDDT]",
               "output": "{physical_name: fu_enddt_prelim, target_published_name: TODO, "
                         "name_status: undecided, type: date, nullable: true, codes: n/a, "
                         "role: internal}"}
    answers.update(over)
    lines = []
    for line in stub.splitlines():
        key = line.split(":", 1)[0]
        lines.append(f"{key}: {answers[key]}" if key in answers else line)
    path = Path(tmp) / "judgment.yaml"
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")
    return str(path)


def test_one_requirement_travels_from_a_spec_row_to_a_validated_contract_record():
    """THE WHOLE PATH, ONCE — and then again, to prove running it twice changes nothing.

    Ten steps, in the order a drafter takes them, each asserted for the thing that step is FOR:

      1  an unseen pack           nothing else drafts into it, so a pass is about this run
      2  the spec row exists      a citation of a row that is not there is I8's business, and a test
                                  that drafted against a missing row would prove nothing
      3  the stub is judgment     no machine-owned field, no status — asserted in `_judgment`
      4  an open decision         the state that made this record unproducible until now
      5  the record renders       through the real entry point, with the real evidence merge
      6  decision_required        DERIVED, not supplied; the drafter wrote no status at all
      7  --apply writes it        into the real contract, atomically, with no paste step
      8  the full lint passes     all eighteen invariants over the resulting pack, not a subset
      9  nothing was invented     no approval, no verification, no validation appears anywhere
      10 it is idempotent         the second identical run leaves the file byte-for-byte the same
    """
    tmp = tempfile.mkdtemp()
    try:
        pack = _approved(_packs.PARKED)                       # 1 — copied, signed against the copy
        rows = {r["item_id"] for r in cs.load_extraction(pack)["rows"]} \
            if hasattr(cs, "load_extraction") else None
        assert _record(pack, NEW_ID) is None, \
            f"{NEW_ID} is already in the fixture contract — this test would assert about a revision"
        _errs, started_with = cl.run(pack)
        assert not _errs, f"the fixture pack does not lint before this test touches it: {_errs[:3]}"

        _open_decision(pack, DECISION)                                              # 4
        draft = _judgment(tmp)                                                      # 3

        r = _run([draft, "--product", pack, "--item", ITEM])                        # 2, 5
        assert r.returncode == 0, f"drafting failed:\n{r.stdout}\n{r.stderr}"
        assert NEW_ID in r.stdout, r.stdout

        # 6 — THE STATUS THE DRAFTER DID NOT WRITE. `decision_required` because an OPEN decision is
        # cited; every other axis at its initial value because no evidence has been produced.
        assert "requirement: decision_required" in r.stdout, \
            f"the open decision did not reach the status — this is the deadlock, unfixed:\n{r.stdout}"

        before = _contract(pack).read_text(encoding="utf-8")
        a = _run([draft, "--product", pack, "--item", ITEM, "--apply"])             # 7
        assert a.returncode == 0, f"--apply failed:\n{a.stdout}\n{a.stderr}"
        after = _contract(pack).read_text(encoding="utf-8")
        assert after != before, "--apply reported success and wrote nothing"

        block = _record(pack, NEW_ID)
        assert block is not None, "--apply did not put the record in the contract"
        assert after.count(f"| {NEW_ID} ") == 1, \
            f"{NEW_ID} appears {after.count(f'| {NEW_ID} ')} times — a duplicate requirement"

        errors, n = cl.run(pack)                                                    # 8
        assert errors == [], f"the applied record does not pass Gate 2's invariants:\n" + \
                             "\n".join(errors[:8])
        assert n == started_with + 1, \
            f"the lint counted {n} records where the pack started with {started_with} and one was " \
            f"applied — either the write did not land or it landed more than once"

        # 9 — NOTHING WAS INVENTED. Every axis is at the value a record with no evidence behind it
        # must hold, and `requirement` is the one the tool derived rather than a confident `draft`.
        st = cl._inline(block, "status")
        assert cl._kv(st, "requirement") == "decision_required", st
        for axis, initial in cr.INITIAL_STATUS.items():
            if axis == "requirement":
                continue
            assert cl._kv(st, axis) == initial, \
                f"{axis} came out as {cl._kv(st, axis)}, not {initial} — evidence nobody produced"
        # PER AXIS, not a substring sweep of the whole cell. `unverified` contains `verified`, so a
        # `word not in text` check fires on the CORRECT value and stays silent on the wrong one.
        invented = {"approved", "verified", "human_confirmed", "passed_live", "passed_test",
                    "implemented", "dictionary_only"}
        for axis in cr.INITIAL_STATUS:
            assert cl._kv(st, axis) not in invented, \
                f"the drafted record claims `{cl._kv(st, axis)}` on {axis} — evidence nobody produced"

        # ...and the SPEC's words are the spec's. `required_rule` came from `--item`, so it must be
        # what the extraction holds — not the drafter's summary of it.
        assert (cl._scalar(block, "required_rule") or "").strip() not in ("", "TODO"), \
            "required_rule is empty — the evidence merge did not run"

        # 10 — IDEMPOTENT. The same command again finds the row it wrote and replaces it with itself.
        again = _run([draft, "--product", pack, "--item", ITEM, "--apply"])
        assert again.returncode == 0, f"the second --apply failed:\n{again.stdout}\n{again.stderr}"
        assert _contract(pack).read_text(encoding="utf-8") == after, \
            "running the documented command twice changed the contract — an authoring path that is " \
            "not idempotent duplicates a requirement every time somebody re-runs it after a fix"
        assert rows is None or ITEM in rows
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


def test_revising_what_a_record_REQUIRES_takes_its_approval_away():
    """AN APPROVAL IS OF WORDS, AND THE WORDS ARE BEING REPLACED.

    A revision used to keep whatever status the existing record held. That is right for a tidy-up and
    catastrophic for a requirement change: `requirement: approved, validation: passed_live` survives
    onto a record whose rule now says something else, and a human's signature silently transfers to
    text that human never read. Nothing downstream can detect it — the record is well-formed, the
    digest is current, and every gate reads a properly approved requirement.

    So `requirement_changes` compares the fields that carry the rule's own answer
    (`contract_lint.REQUIREMENT_FIELDS`, which is I17's definition, not a second list) plus
    `spec_digest`, and a difference resets the evidence axes to their initial values. Fail-closed:
    re-approving costs a review, an unnoticed stale approval costs a wrong number in a release.

    Both directions are asserted, because a rule that reset on ANY edit would be routed around inside
    a week — and being routed around is worse than the narrow rule it replaced.
    """
    approved = {"requirement": "approved", "source": "verified",
                "implementation": "implemented", "validation": "passed_live"}
    # BUILT THROUGH THE REAL WRITER AND THE REAL PARSER. A hand-typed `| … |` row is not what
    # `requirement_changes` reads — `records()` yields BLOCKS — and a fixture in the wrong shape makes
    # every field look unchanged, so the test would pass while detecting nothing.
    prior = {"variable_id": "V1", "spec_refs": "[clinical:1]", "spec_digest": "abc123",
             "required_rule": "the spec's own words", "source": "{kind: vendor}", "grain": "patient",
             "anchor": "idx", "window": "90d", "record_selection": "all", "tie_break": "first",
             "derivation": "v * 2", "cohort_applicability": "all", "missing": "null", "units": "kg",
             "depends_on": "[]", "output": "{physical_name: v, role: internal}",
             "status": "{" + ", ".join(f"{k}: {v}" for k, v in approved.items()) + "}",
             "decision_ids": "[]", "gap_ids": "[]", "publish": "{}", "acceptance": "acc",
             "notes": "n", "implementation_refs": "[none]"}
    existing = next(cl.records(cl.render_table([prior])))
    assert (cl._scalar(existing, "derivation") or "").strip() == "v * 2", \
        "the fixture did not round-trip through the parser — every comparison below would be vacuous"

    tidy = {"variable_id": "V1", "notes": "a typo fixed in the notes"}
    assert cr.requirement_changes(tidy, existing) == {}, \
        "editing a note counts as a requirement change — this rule will be routed around"
    kept, _ = cr.apply_status(tidy, dict(approved), dec_open={},
                              reopen=bool(cr.requirement_changes(tidy, existing)))
    assert "requirement: approved" in kept["status"], \
        "a tidy-up threw away an approval — re-approval on every edit is its own kind of wrong"

    material = {"variable_id": "V1", "derivation": "v * 3"}
    moved = cr.requirement_changes(material, existing)
    assert "derivation" in moved, moved
    reopened, _ = cr.apply_status(material, dict(approved), dec_open={}, reopen=bool(moved))
    # PARSED, not substring-matched: `unverified` CONTAINS `verified`, so a `stale not in text` check
    # passes on the reset value and fails on the stale one — exactly backwards, and silently.
    got = {k.strip(): v.strip() for k, v in
           (p.split(":", 1) for p in reopened["status"].strip("{} ").split(",") if ":" in p)}
    assert got == cr.INITIAL_STATUS, \
        f"a requirement change left evidence claims standing: {got}"
    for axis, stale in approved.items():
        assert got[axis] != stale, f"`{axis}` kept `{stale}` across a change to what the record requires"

    # ...and the SPECIFICATION moving underneath an unchanged judgment is the same event. This is the
    # case the judgment fields cannot show: every answer the drafter wrote is identical, and the rows
    # they were written from now say something else.
    respec = {"variable_id": "V1", "spec_digest": "def456"}
    assert "spec_digest" in cr.requirement_changes(respec, existing), \
        "the spec can be revised under an approved record with nothing noticing"

    # BLANK BECOMING POPULATED IS A CHANGE, and it was the one direction the comparison could not
    # see: the test was `if was and was != now`, so an empty prior value made the whole condition
    # false. A record approved with `missing` blank says "unstated". A revision that fills it in
    # states a rule the approver never read — and the approval, the source verdict and
    # `passed_live` all rode across onto it in silence.
    #
    # Asserted on a field the fixture leaves EMPTY, and checked to be empty first: a field that
    # turned out to be populated would make this assertion pass for the ordinary reason and prove
    # nothing about the case it is named for.
    blank = {"variable_id": "V1", "spec_refs": "[clinical:1]", "spec_digest": "abc123",
             "required_rule": "the spec's own words", "source": "{kind: vendor}", "grain": "patient",
             "anchor": "idx", "window": "90d", "record_selection": "all", "tie_break": "first",
             "derivation": "v * 2", "cohort_applicability": "all", "missing": "", "units": "kg",
             "depends_on": "[]", "output": "{physical_name: v, role: internal}",
             "status": prior["status"], "decision_ids": "[]", "gap_ids": "[]", "publish": "{}",
             "acceptance": "acc", "notes": "n", "implementation_refs": "[none]"}
    was_blank = next(cl.records(cl.render_table([blank])))
    assert not (cl._scalar(was_blank, "missing") or "").strip(), \
        "the fixture's `missing` is not blank — this checks the ordinary case, not the empty one"
    filled = {"variable_id": "V1", "missing": "carry the last observation forward"}
    assert "missing" in cr.requirement_changes(filled, was_blank), \
        "a revision that fills in a field the approver saw EMPTY did not reopen the approval"
    # ...and the case the old guard existed for still holds: a field this revision does not restate
    # is not a change, because `field not in record` skips it before any comparison.
    assert cr.requirement_changes({"variable_id": "V1", "notes": "x"}, was_blank) == {}, \
        "a field nobody restated counted as a change — every edit would now reset every approval"


def test_the_same_value_written_two_legal_ways_is_not_a_revision():
    """REFERENCE.md LETS A DRAFTER WRITE REAL YAML, AND THAT MUST NOT COST THEM AN APPROVAL.

    A judgment file may express a value as YAML (`tie_break: {equidistant: n/a}`) or in the contract's
    inline notation (`tie_break: "{equidistant: n/a}"`). `render_row` puts both through `inline()`
    before either becomes a cell, so they produce the SAME contract. The revision check compared
    `str(value)` against the stored cell instead — Python's repr of a dict against the contract's own
    notation — so `{'equidistant': 'n/a'}` read as different from `{equidistant: n/a}`.

    The consequence is the worst kind: identical requirements reported as changed, resetting an
    approval nobody asked to reset, and ONLY for drafters who chose the YAML form. It would have
    presented as an intermittent fault in the tool rather than as a rule.
    """
    prior = {"variable_id": "V1", "spec_refs": "[clinical:1]", "spec_digest": "abc123",
             "required_rule": "r", "source": "{kind: vendor}", "grain": "patient", "anchor": "idx",
             "window": "90d", "record_selection": "all",
             "tie_break": "{equidistant: n/a, same_day: n/a}", "derivation": "v * 2",
             "cohort_applicability": "all", "missing": "null", "units": "kg", "depends_on": "[]",
             "output": "{physical_name: v, role: internal}",
             "status": "{requirement: approved, source: verified, implementation: implemented, "
                       "validation: passed_live}",
             "decision_ids": "[]", "gap_ids": "[]", "publish": "{}", "acceptance": "acc",
             "notes": "n", "implementation_refs": "[none]"}
    existing = next(cl.records(cl.render_table([prior])))

    for form in ({"equidistant": "n/a", "same_day": "n/a"}, "{equidistant: n/a, same_day: n/a}"):
        moved = cr.requirement_changes({"variable_id": "V1", "tie_break": form}, existing)
        assert moved == {}, f"the same tie-break written as {type(form).__name__} reads as a change: {moved}"

    # ...and a real change is still seen, or the fix would be "never detect anything".
    assert "tie_break" in cr.requirement_changes(
        {"variable_id": "V1", "tie_break": {"equidistant": "earliest", "same_day": "n/a"}}, existing)


def test_blocking_a_record_takes_its_downstream_evidence_with_it():
    """`decision_required` BESIDE `passed_live` IS A RECORD I12 REFUSES, AND THE TOOL BUILT IT.

    Adding an open decision to an approved, validated record correctly moved `requirement` to
    `decision_required` — and left `source: verified, implementation: implemented, validation:
    passed_live` standing. I12 rejects that: a value cannot be validated further than its requirement
    is settled. The drafter could not fix it either, because `status` is entirely the tool's field.

    So the tool produced a state its own lint refuses, with no legal transition out — the same dead
    end this function was written to close, reintroduced one axis over. An unsettled requirement
    invalidates the evidence below it, which is exactly what a material requirement change does, so
    both paths share the one reset rather than answering the question twice.
    """
    approved = {"requirement": "approved", "source": "verified",
                "implementation": "implemented", "validation": "passed_live"}
    out, _ = cr.apply_status({"variable_id": "X", "decision_ids": ["D-1"]},
                             dict(approved), dec_open={"D-1": "OPEN"})
    got = {k.strip(): v.strip() for k, v in
           (p.split(":", 1) for p in out["status"].strip("{} ").split(",") if ":" in p)}
    assert got["requirement"] == "decision_required", got
    for axis in ("source", "implementation", "validation"):
        assert got[axis] == cr.INITIAL_STATUS[axis], \
            f"{axis} kept `{got[axis]}` under an unsettled requirement — I12 refuses this record"

    # A record ALREADY blocked on the same decision is being tidied, not reopened. Re-running the
    # documented command must not keep clearing evidence somebody re-established.
    blocked = dict(cr.INITIAL_STATUS, requirement="decision_required", validation="passed_test")
    again, _ = cr.apply_status({"variable_id": "X", "decision_ids": ["D-1"]},
                               dict(blocked), dec_open={"D-1": "OPEN"})
    assert "validation: passed_test" in again["status"], \
        f"re-running on an already-blocked record reset evidence again: {again['status']}"


def test_the_deriver_and_the_invariant_are_the_SAME_function():
    """Not "they agree today" — the same object, so they cannot come to disagree.

    I11 checks that a record citing an open requirement-level decision is `decision_required`.
    `contract_record` must SETTLE that same status, because the drafter is refused from writing one.
    Two implementations of "which cited decisions block this record" would agree on the day they were
    written; the failure afterwards is not a loud disagreement but a drafting tool that produces a
    status the lint rejects, which reads to a drafter as the tool being broken.
    """
    # The CONJUNCTION, not either half. `d not in OUTPUT_DECISIONS` alone appears twice and correctly
    # so: I8 asks which cited decisions are requirement-level, whatever their status, for a variable
    # with no spec row. That is a different question from "which of them block this record NOW", and
    # a pattern that could not tell them apart would fail on a second rule that is not a duplicate.
    src = (TOOLS / "contract_lint.py").read_text(encoding="utf-8")
    assert src.count('== "OPEN" and d not in OUTPUT_DECISIONS') == 1, \
        "the blocking-decision rule is written more than once in contract_lint"
    assert "cl.blocking_decisions(" in (TOOLS / "contract_record.py").read_text(encoding="utf-8"), \
        "contract_record decides `decision_required` without asking the module that defines it"

    # The vocabulary the deriver can produce is the vocabulary the lint accepts — asserted against
    # `contract_lint.REQ` rather than a literal, so adding a status to one side fails here.
    assert set(cr.INITIAL_STATUS) == {"requirement", "source", "implementation", "validation"}
    assert cr.INITIAL_STATUS["requirement"] in cl.REQ
    assert "decision_required" in cl.REQ
    assert cl.blocking_decisions(["D-1"], {"D-1": "OPEN"}) == ["D-1"]
    assert cl.blocking_decisions(["D-1"], {"D-1": "RESOLVED"}) == []
    assert cl.blocking_decisions(list(cl.OUTPUT_DECISIONS), {}) == [], \
        "an output-layer decision blocks the requirement — a column header is not the rule"


def test_the_sme_benchmark_scores_recall_and_cannot_be_gamed_by_its_own_fixture():
    """THE ONE NUMBER NOBODY HAD: does the skill raise the questions accountable people raised?

    Every existing eval measures DISCIPLINE — do not invent, do not write in review mode, reuse an
    id. All worth having, and none of them answers the question a reviewer actually asks, which is
    whether the thing notices what an SME notices. That is a recall claim and it needs a denominator.

    The denominator was already written: `DECISIONS.md` on a drafted pack IS the output of an expert
    review of a real specification. This pins the three properties that make scoring against it mean
    something:

      * an empty run scores 0 and a run naming every key row scores 1 — a scorer that cannot reach
        both ends is measuring something other than what it reports;
      * the answer key may not be written inside the fixture the run reads;
      * a decision whose id is still READABLE in the fixture is excluded rather than counted. The
        first fixture stripped the decisions and all 21 ids survived — in record `notes`, in three
        other registers, and in `variables/clinical.yaml`, which is config a drafter is supposed to
        read. Counting those would have scored the skill for looking things up.
    """
    import importlib
    import shutil
    sys.path.insert(0, str(TOOLS))
    sb = importlib.import_module("skill_benchmark")

    tmp = tempfile.mkdtemp()
    try:
        fixture = os.path.join(tmp, "fx")
        key_path = os.path.join(tmp, "key.yaml")

        # THE KEY MAY NOT LIVE IN THE FIXTURE — asserted before anything else, because every other
        # property here is worthless if the subject can read the answers.
        try:
            sb.build(str(_packs.PARKED), fixture, os.path.join(fixture, "key.yaml"))
            raise AssertionError("a key inside the fixture was accepted")
        except SystemExit as exc:
            assert "must not be inside" in str(exc), exc

        key = sb.build(str(_packs.PARKED), fixture, key_path)
        assert key, "the fixture pack yields no answer key — this test would be vacuous"
        assert os.path.exists(key_path) and not os.path.exists(os.path.join(fixture, "key.yaml"))

        # THE KEY DOES NOT DECLARE ITS OWN DENOMINATOR. `reachable` was a field, so a decision
        # citing a row no specification contains counted as reachable and sat in the denominator
        # where no run could reach it — and on a holdout key the reviewer typed it themselves.
        for d, v in key.items():
            assert "reachable" not in v, f"{d}: the key still stores its own reachability"
        rows_present = sb.spec_row_ids(str(_packs.PARKED))
        assert rows_present, "the fixture pack has no extraction — this test would be vacuous"

        # BOTH ENDS OF THE SCALE. A scorer that cannot return 0, or cannot return 1, is not
        # measuring coverage whatever it prints.
        blocked = sb.reachability(key, rows_present)
        scored = {d: v for d, v in key.items() if d not in blocked and not v.get("leaked")}
        empty, _per = sb.score([], key, rows_present)
        assert empty["found"] == 0 and empty["recall"] in (0.0, None), empty
        if scored:
            everything = [{"rows": v["rows"]} for v in scored.values()]
            full, _per = sb.score(everything, key, rows_present)
            assert full["found"] == len(scored) and full["recall"] == 1.0, full
            # ...and one row of one decision is enough — matching is by ROW, never by wording, so a
            # run that flags the right row for a different reason still counts.
            one = next(iter(scored.values()))
            part, _per = sb.score([{"rows": one["rows"][:1]}], key, rows_present)
            assert part["found"] >= 1, part

            # A ROW THE SPECIFICATION DOES NOT CONTAIN IS UNREACHABLE, not a miss charged to the
            # run. This is the check `reachable: bool(rows)` could never make.
            bad = dict(key)
            bad["INVENTED"] = {"question": "cites a row that does not exist",
                               "rows": ["clinical:999999"]}
            why = sb.reachability(bad, rows_present)
            assert why.get("INVENTED") == sb.NO_SUCH_ROW, why
            withbad, per_bad = sb.score(everything, bad, rows_present)
            assert withbad["reachable"] == full["reachable"], \
                "a question citing a nonexistent row entered the denominator"
            assert withbad["unreachable_bad_rows"] == 1, withbad
            assert ("INVENTED", "UNREACHABLE", [sb.NO_SUCH_ROW]) in per_bad, per_bad

            # THE FLOOR NEVER EXCEEDS THE CEILING, and it is computed as a constraint solve rather
            # than a subtraction. Groups of decisions sharing one finding OVERLAP, so charging
            # `len(group)-1` per group penalises a decision twice for appearing in two of them —
            # which understated one pack by three decisions. An independent reviewer caught the
            # ceiling being quoted as an SME-match score; a wrong floor is the same error mirrored.
            assert full["found_strict"] <= full["found"], full
            assert full["recall_strict"] <= full["recall"], full

        # THE LEAK CHECK LOOKS AT THE WHOLE FIXTURE, not at the files the stripper touched. A cleaner
        # that audits only what it cleaned reports success by construction.
        planted = os.path.join(fixture, "config", "PLANTED.yaml")
        os.makedirs(os.path.dirname(planted), exist_ok=True)
        with open(planted, "w", encoding="utf-8") as fh:
            fh.write(f"note: blocked on {sorted(key)[0]}\n")
        assert sorted(key)[0] in sb.leaks(fixture, key), \
            "a decision id planted in a file the stripper never wrote is not detected"
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


def test_the_review_chain_shows_all_three_sides_and_computes_none_of_them():
    """APPROVING A CONFIGURATION MEANT READING YAML, WHICH ASKS THE WRONG PERSON THE WRONG WAY.

    Gate 4 is DataExpert's approval that the configuration expresses the approved requirement. Until now
    that meant opening `variables/clinical.yaml`. The person who owns the CLINICAL question was being
    asked to answer it in the notation of the people who own EXECUTION, and the predictable outcome
    is an approval that means "somebody else checked".

    All three sides already existed and had never been put next to each other: `required_rule` is the
    spec's own words and is machine-owned, the judgment fields are the interpretation, and
    `implementation_refs` names the YAML. This asserts the chain is complete and, more importantly,
    that the view DERIVES NOTHING — a rendering that computed a value would be a friendlier second
    opinion sitting beside the record in a document built to be trusted.
    """
    import rule_review
    packs = [str(REPO / p) for p in __import__("product_gates").all_packs(str(REPO))]
    live = [p for p in packs if rule_review.chain(p)]
    assert live, "no pack yields a review chain — this test would be vacuous"

    for pack in live:
        entries = rule_review.chain(pack)
        for e in entries:
            # THE THREE SIDES. Every reviewer question is present as a labelled row even when the
            # answer is empty: a missing row reads as "not applicable", a blank one as "unanswered",
            # and only the second is true.
            labels = " | ".join(k for k, _v in e["interpreted"]).lower()
            # SPELLED OUT, not compared against `REVIEW_ORDER`. The first version asserted the labels
            # equalled that constant — which is the thing under test, so deleting a whole reviewer
            # question passed. A test that reads its own subject cannot fail; the mutation found it.
            #
            # These are the questions a clinical reviewer must be able to answer without opening
            # YAML. Adding one is a decision; losing one silently is the failure.
            for concept in ("population", "source", "anchor", "window", "qualify",
                            "precedence", "missing", "output"):
                assert concept in labels, \
                    f"{e['variable_id']}: the review view no longer asks about `{concept}` — a " \
                    f"reviewer cannot answer it without reading YAML. Present: {labels}"
            assert isinstance(e["spec"]["rule"], str)
            for ref in e["unresolved"]:
                assert "#/" in ref, f"an engine symbol reported as an unresolved block: {ref}"

        # EVERY VALUE IS A SUBSTRING OF THE RECORD IT CAME FROM. That is what "derives nothing"
        # means operationally: this view may reorder and relabel, and may not compute.
        contract = cl.read(str(Path(pack) / "handoff" / "FUNCTIONAL_CONTRACT.md"))
        blocks = {(cl._scalar(b, "variable_id") or "").strip(): b for b in cl.records(contract)}
        for e in entries[:40]:
            raw = blocks[e["variable_id"]]
            for label, value in e["interpreted"]:
                if value:
                    assert value in raw, \
                        f"{e['variable_id']} / {label}: `{value[:40]}` is not in the record — the " \
                        f"review view computed a value instead of reading one"

    # ADJACENCY IS NOT AGREEMENT, and there is a live counter-example. Prostate's ECOG record states
    # `tie_break: {equidistant: prior, same_day: worst_grade}`; the block it names states
    # `tie_break: earliest_date`. Those are different statements, and two columns containing the same
    # WORD read as a match to anyone scanning. A review document that makes a disagreement look like
    # agreement is worse than no review document.
    #
    # So an overlap is called out, and the view asserts NOTHING about whether the two agree —
    # deciding that is a judgement about what the rule means, which is the reviewer's entire job.
    ecog = [e for e in rule_review.chain(str(REPO / "fixtures/oncology/prostate/202606"))
            if e["variable_id"] == "ECOG"]
    if ecog:
        both = rule_review.overlaps(ecog[0])
        fields = {f for f, _said, _where, _runs in both}
        assert "tie_break" in fields, (
            "the ECOG record and the block it names BOTH state a tie-break, and the review view "
            "does not say so — printed in adjacent columns they read as agreement, and on this pack "
            f"they disagree. Overlaps found: {sorted(fields)}")
        for _f, said, where, runs in both:
            assert "#/" in where and "->" in where, f"the overlap does not name where it came from: {where}"
        # ...and it must not editorialise. No verdict word may appear in what the view produces
        # about an overlap — the moment it says "matches", it is deciding the reviewer's question.
        text = rule_review.render(str(REPO / "fixtures/oncology/prostate/202606"), ecog)
        for verdict in ("matches", "agrees", "consistent", "as expected", "differs", "mismatch"):
            assert verdict not in text.lower(), \
                f"the review view returns a verdict (`{verdict}`) on whether the record and the " \
                f"config agree — that judgement is the reviewer's, and this document is the one " \
                f"they would believe"

    # ...and the config side is resolved by the BINDER's resolver, not a second one written here.
    src = (TOOLS / "rule_review.py").read_text(encoding="utf-8")
    assert "contract_binding.governed_blocks(" in src, \
        "rule_review resolves implementation_refs itself instead of asking the binder, so the " \
        "review page can disagree with the gate about which YAML a record runs as"
    assert "yaml.safe_load" not in src, "rule_review opens config YAML directly"


def test_the_review_view_never_hides_a_cut_and_can_show_everything():
    """A REVIEWER CANNOT APPROVE WHAT THE PAGE DID NOT SHOW THEM.

    Three fragments were capped at 14, 6 and 12 lines with no marker of any kind. This document is
    what a person reads to decide whether the YAML implements the rule, so a value list that stopped
    at twelve lines was indistinguishable from a value list that HAS twelve lines — a fifty-code
    enumeration signed off on its first dozen entries, with nothing on screen to suggest a tail
    existed. Measured on prostate: 139 cut points hiding 2,975 lines.

    Both halves are asserted, because either alone is still a defect: the cut must be VISIBLE, and
    there must be a way to see what was cut.
    """
    import rule_review
    pack = str(REPO / "fixtures/oncology/prostate/202606")
    entries = rule_review.chain(pack)
    if not entries:
        return                                   # a pack with no contract proves nothing here

    capped = rule_review.render(pack, entries)
    full = rule_review.render(pack, entries, full=True)

    marks = capped.count("NOT SHOWN")
    assert marks, ("no cut is marked. Either nothing is being truncated — in which case the cap is "
                   "dead code — or a reviewer is being shown a fragment with a silent tail")
    assert "NOT SHOWN" not in full, "--full still withheld lines"
    assert len(full.splitlines()) > len(capped.splitlines()), \
        "--full produced no more lines than the capped view, so it shows nothing extra"

    # The marker must say HOW MANY lines are missing and HOW to get them. "…" alone is a cut a
    # reader cannot size, and this repo's convention (demo.py) is to name both.
    import re as _re
    for line in capped.splitlines():
        if "NOT SHOWN" in line:
            assert _re.search(r"\d+ more line\(s\) NOT SHOWN", line), line
            assert "--full" in line, f"the marker does not say how to see the rest: {line}"

    # ...and the cut never lands mid-fragment without a marker: every fragment in the capped view is
    # either complete or followed by one. Checked by reconstructing the count from the markers.
    hidden = sum(int(m) for m in _re.findall(r"… (\d+) more line\(s\) NOT SHOWN", capped))
    assert len(capped.splitlines()) - marks + hidden == len(full.splitlines()), (
        "the marked counts do not add up to the full output — a fragment was cut without being "
        "counted, which is the silent truncation this test is for")


def test_a_pack_with_no_contract_file_gets_a_refusal_that_teaches_not_a_traceback():
    """The FIRST record of a FRESH pack is drafted before FUNCTIONAL_CONTRACT.md exists.

    Every other missing precondition on this path answers with a refusal that names the next step;
    this one answered with a raw FileNotFoundError out of `shutil.copytree`'s temp copy — a crash a
    newcomer reads as a broken tool, on the very first drafting command a new tumour runs. The
    refusal must say the drafter creates the file, and must not be a traceback.
    """
    tmp = tempfile.mkdtemp()
    try:
        pack = _approved(_packs.PARKED)         # extraction approved — the LATER gate is under test
        os.remove(os.path.join(pack, "handoff", "FUNCTIONAL_CONTRACT.md"))
        draft = _judgment(tmp)
        r = _run([draft, "--product", pack, "--item", ITEM])
        assert r.returncode != 0, "drafting into a contract that does not exist must refuse"
        err = r.stdout + r.stderr
        assert "Traceback" not in err, f"a crash, not a refusal:\n{err}"
        assert "no handoff/FUNCTIONAL_CONTRACT.md" in err, err
        assert "drafter" in err, f"the refusal must say WHO creates the file:\n{err}"
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


def test_a_key_says_where_its_opinion_came_from_and_a_holdout_key_must_be_sealed():
    """THE CLAIM A BENCHMARK NUMBER CARRIES depends entirely on the key it was scored against.

    `--build` derives the key from the pack's OWN decision register. Those questions were raised by
    accountable people against a real specification, which is what makes the key worth having — and
    by the SAME programme whose drafting is being scored. A number from it measures agreement with
    that register; it cannot measure whether an independent reviewer would raise the same questions,
    because the register is where the questions came from. Nothing in the key said so, and "41% SME
    recall" is the sentence that gets written when nothing says so.

    A HOLDOUT key carries the independence claim, and every part of it is checkable except the
    honesty of the person sealing: a named reviewer, a date, what they were shown, and a seal over
    the questions written BEFORE any run. A key sealed afterwards could have been fitted to the run,
    and no reader can tell — so it is REFUSED rather than scored with a caveat, because a number
    printed with a warning gets quoted without one.
    """
    import importlib
    sys.path.insert(0, str(TOOLS))
    sb = importlib.import_module("skill_benchmark")
    import yaml

    tmp = tempfile.mkdtemp()
    try:
        # A key built from the register SAYS it came from the register.
        key_path = os.path.join(tmp, "key.yaml")
        sb.build(str(_packs.PARKED), os.path.join(tmp, "fx"), key_path)
        built = yaml.safe_load(open(key_path, encoding="utf-8"))
        assert built["independence"] == "derived_from_own_register"
        assert sb.key_errors(built, key_path) == []

        # A key that does not say is refused — the reader's sentence depends on it.
        assert any("independence" in e for e in
                   sb.key_errors({"decisions": {"A": {}}}, "k"))

        hold = os.path.join(tmp, "hold.yaml")
        assert sb.main(["--holdout-new", hold]) == 0
        assert sb.main(["--holdout-new", hold]) == 1, "regenerating discards a recorded reading"

        text = open(hold, encoding="utf-8").read()
        assert text.count(sb.MARK) >= 8, "the scaffold pre-filled something a person owns"
        # ...and it refuses to be sealed while it is still a scaffold.
        assert sb.main(["--seal", hold]) == 1

        # A REAL PACK AND ITS REAL DIGEST. This used to fill in `pack: p` / `fixture_digest: d` —
        # a pack that does not exist and a digest of nothing — and the key validated clean, because
        # `extraction_digest("")` returned "" and the comparison read that as nothing to check. The
        # seal held; what it was a seal OF had never existed. The clean example has to be clean.
        _pk = os.path.relpath(str(_packs.PARKED), str(REPO)).replace(os.sep, "/")
        _dg = sb.extraction_digest(_pk)
        assert _dg, "the parked fixture must extract, or this test proves nothing"
        filled = (text.replace("pack: REPLACE_ME", f"pack: {_pk}")
                      .replace("fixture_digest: REPLACE_ME", f"fixture_digest: {_dg}")
                      .replace("sme: REPLACE_ME", "sme: T. Test")
                      .replace("reviewed_date: REPLACE_ME", "reviewed_date: 2026-08-15")
                      .replace("shown: REPLACE_ME", "shown: the fixture only")
                      .replace("  REPLACE_ME:                       # an id the reviewer chooses, "
                               "e.g. SME-FUED-CAP", "  SME-Q1:")
                      .replace("    question: REPLACE_ME", "    question: which sources cap follow-up")
                      .replace("    rows: [REPLACE_ME]              # e.g. [clinical:70, outcomes:12]",
                               "    rows: [clinical:70]"))
        open(hold, "w", encoding="utf-8").write(filled)

        # UNSEALED IS REFUSED, not caveated.
        doc = yaml.safe_load(open(hold, encoding="utf-8"))
        assert any("NOT SEALED" in e for e in sb.key_errors(doc, hold))

        assert sb.main(["--seal", hold]) == 0
        doc = yaml.safe_load(open(hold, encoding="utf-8"))
        assert sb.key_errors(doc, hold) == [], sb.key_errors(doc, hold)

        # RESEALING IS REFUSED: a key edited after its seal proves nothing.
        assert sb.main(["--seal", hold]) == 1

        # ...and editing a question after the seal is caught.
        doc["decisions"]["SME-Q1"]["question"] = "something else entirely"
        assert any("A holdout key is edited before it is sealed" in e
                   for e in sb.key_errors(doc, hold))

        # THE SEAL COVERS THE WHOLE KEY, not just the questions. Its first version digested
        # `decisions:` alone, so the identity of the exercise — who read it, when, what they were
        # shown, which pack and which fixture — could all be rewritten after sealing without
        # disturbing the digest. A holdout claim is about WHO read WHAT as much as about the
        # questions raised.
        for field, value in (("sme", "Somebody Else"), ("reviewed_date", "2099-01-01"),
                             ("shown", "the decision register too"), ("pack", "another/pack")):
            tampered = dict(yaml.safe_load(open(hold, encoding="utf-8")))
            tampered[field] = value
            assert any("now hashes to" in e for e in sb.key_errors(tampered, hold)), field

        # A team is not a reviewer: independence is the measurement, and a function cannot be asked.
        doc = yaml.safe_load(open(hold, encoding="utf-8"))
        doc["sme"] = "DataExpert"
        assert any("is a team, not a person" in e for e in sb.key_errors(doc, hold))

        # THE FIXTURE THE REVIEWER READ is compared, and the field the template writes is the field
        # the scorer reads. The template wrote `fixture_digest` and scoring read
        # `extraction_digest`, so the value was written, sealed, and never once checked: a key could
        # be scored against a fixture built from a different specification and nothing would say so.
        doc = yaml.safe_load(open(hold, encoding="utf-8"))
        assert "fixture_digest" in doc
        real = sb.extraction_digest(str(_packs.PARKED))
        bound = dict(doc, pack=os.path.relpath(str(_packs.PARKED), str(REPO)).replace(os.sep, "/"),
                     fixture_digest="0" * 64)
        if real:                       # the parked fixture extracts, so the mismatch is detectable
            assert any("moved after the review" in e for e in sb.key_errors(bound, hold)), \
                sb.key_errors(bound, hold)

        # An empty holdout key would score every run perfectly.
        doc = yaml.safe_load(open(hold, encoding="utf-8"))
        doc["decisions"] = {}
        assert any("scores every run perfectly" in e for e in sb.key_errors(doc, hold))

        # THE REVIEWER DOES NOT SET THE DENOMINATOR. Both fields remove a question from the set the
        # score divides by, and the template used to ask the reviewer to type `reachable: true` on
        # every one — the party being measured writing the denominator of its own score. Neither is
        # accepted now; both are computed.
        for field, value in (("reachable", True), ("reachable", False), ("leaked", ["a.yaml"])):
            doc = yaml.safe_load(open(hold, encoding="utf-8"))
            doc["decisions"]["SME-Q1"][field] = value
            errs = sb.key_errors(doc, hold)
            assert any(f"carries `{field}`" in e for e in errs), (field, errs)
        scaffold = sb.HOLDOUT_TEMPLATE.splitlines()
        assert not [l for l in scaffold
                    if l.strip().split("#")[0].strip().startswith(("reachable:", "leaked:"))], \
            "the holdout scaffold still asks a reviewer to declare its own denominator"

        # --seal REPORTS WHAT IT DID, and verifies it structurally. The write is a text replace so
        # the template's comments survive — they are what tell the reviewer which fields are theirs
        # — and a text replace that matches nothing succeeds silently. Sealing a key with no marker
        # line printed "sealed …" over a file it had not touched, leaving it unsealed and looking
        # sealed to the person who ran it.
        nomark = os.path.join(tmp, "nomark.yaml")
        src = yaml.safe_load(open(hold, encoding="utf-8"))
        src.pop("sealed_sha256", None)
        with open(nomark, "w", encoding="utf-8") as fh:
            yaml.safe_dump(src, fh, sort_keys=True)
        assert sb.main(["--seal", nomark]) == 1, \
            "sealing a key with no marker line reported success without writing a seal"
        after = yaml.safe_load(open(nomark, encoding="utf-8"))
        assert not after.get("sealed_sha256"), "the file claims a seal it does not carry"
        assert any("NOT SEALED" in e for e in sb.key_errors(after, nomark))
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


if __name__ == "__main__":
    # STDLIB ONLY, like every other suite here. The Linux CI step runs `python3 tests/test_*.py` over
    # the whole glob with `set -e` and installs no test runner — so a `__main__` that imported pytest
    # did not fail this suite, it failed the JOB, and every governance and gate step after it was
    # skipped. The suite itself passed under pytest the whole time, which is why it looked fine here.
    fns = [v for k, v in sorted(globals().items()) if k.startswith("test_")]
    for fn in fns:
        fn()
        print(f"ok  {fn.__name__}")
    print(f"\n{len(fns)} tests passed")


