"""Configuration review packets stay isolated from product and study authority.

Every write targets a disposable copy: the bladder walkthrough at a product path the
repository never carried, the prostate reference fixture, or the template scaffold at yet
another path. None of them is the product the editor was first written for, which is the
point: the editor is offered by what a product's files carry, never by its name. Real
validators exercise the scaffold failure path; controlled validator results exercise review
submission and rechecks.
"""
from __future__ import annotations

import copy
import difflib
import hashlib
import json
from pathlib import Path
import shutil
import sys
from unittest.mock import patch

import yaml

sys.path.insert(0, str(Path(__file__).resolve().parent))
from _epi_test_support import api, run
from _epi_gist_fixture import seed_gist, seed_bladder, seed_prostate, BLADDER, PROSTATE

pytest = api(__name__)
ROOT = Path(__file__).resolve().parents[2]
sys.path[:0] = [str(ROOT / "experiments/portal"), str(ROOT / "platform/tools")]
import configuration_proposals as cp
import design_workspace as dw

PACK = BLADDER
SCAFFOLD = "products/oncology/gist_uat/202609"
ACTOR = "epidemiologist@example.test"
START = "config/data_product.yaml#/study/index_start"
END = "config/data_product.yaml#/study/index_end"
FOLLOWUP = "variables/outcomes.yaml#/min_followup_days"
RECENCY = "variables/outcomes.yaml#/visit_recency_days"
MONTH = "variables/outcomes.yaml#/days_per_month"
MAX_LINES = "variables/treatment.yaml#/max_lines"
NUMBERING = "config/data_product.yaml#/lot/line_number"
# the delivery declaration lives in the pipeline file every product carries (walk RW4-N03)
SCHEMA = "config/pipeline.yaml#/run/source_schema"
CUT = "config/pipeline.yaml#/run/refresh"
PASSING = [{"validator": name, "passed": True, "errors": []}
           for name in sorted(cp.REQUIRED_VALIDATORS)]


def seed(root, *, contract=True, consumers=False, scaffold=False):
    """A real configuration graph with optional deliberately small contract metadata.

    ``scaffold`` builds the template scaffold (placeholders intact) at SCAFFOLD instead of the
    configured bladder walkthrough at PACK, for the tests that need the validators to refuse.
    """
    pack = SCAFFOLD if scaffold else PACK
    product = seed_gist(root, extraction=True, pack=pack) if scaffold else seed_bladder(root, pack=pack)
    if not contract and not scaffold:
        # The walkthrough carries one record; the template's contract ships as an empty header,
        # which is how a product whose drafting has not started actually looks.
        shutil.copyfile(ROOT / "platform/TUMOR_TEMPLATE/handoff/FUNCTIONAL_CONTRACT.md",
                        product / "handoff/FUNCTIONAL_CONTRACT.md")
    if contract:
        records = [
            ("INDEXDT", "study_period", "Index date as stated", [],
             "config/data_product.yaml#/study"),
            ("AGE", "demographics", "Age at index", ["INDEXDT"], ""),
            ("OS", "outcomes", "Survival as stated", ["INDEXDT", "external:death"],
             "variables/outcomes.yaml#/min_followup_days"),
            ("SUMMARY", "outcomes", "Summary of survival", ["OS"], ""),
            ("UNUSED", "clinical", "Optional definition", [], ""),
        ]
        text = "# Fixture contract, never approval\n\n"
        for identifier, domain, rule, dependencies, implementation in records:
            text += (f"```yaml\nvariable_id: {identifier}\nspec_refs: [{domain}:1]\n"
                     f"required_rule: {rule}\ndepends_on: [{', '.join(dependencies)}]\n"
                     f"implementation_refs: [{implementation}]\n"
                     f"output: {{physical_name: {identifier.lower()}}}\nstatus: draft\n```\n\n")
        (product / "handoff/FUNCTIONAL_CONTRACT.md").write_text(text, encoding="utf-8")
    if consumers:
        for study in ("reader-a", "reader-b"):
            directory = root / "work" / study
            directory.mkdir(parents=True)
            (directory / "PINS.yaml").write_text(yaml.safe_dump({
                "study": study, "pins": [{"product": pack, "spec_version": pack.split("/")[-1],
                    "status": "pinned", "pinned_by": "Original reviewer", "pinned_date": "2026-09-01",
                    "definitions": [{"variable": "OS", "decision": "reuse"}]}]}, sort_keys=False),
                encoding="utf-8")
    return product


def brief(root, pack=PACK, **changes):
    desc = dw.describe(root, pack)
    assert not desc["errors"], desc
    values = {"retained": [row["variable_id"] for row in desc["rows"]], "additions": [],
              "purpose": "Review an explicit follow-up window", "studies": ["reader-a", "reader-b"],
              "target_source": desc["source"]["vendor"], "target_modality": desc["source"]["modality"]}
    values.update(changes)
    return dw.build_plan(desc, **values)


def original_bytes(root):
    return {p.relative_to(root).as_posix(): p.read_bytes() for p in root.rglob("*")
            if p.is_file() and ".portal-drafts" not in p.relative_to(root).parts}


def stage(root, plan=None, changes=None, exclusions=None, pack=PACK, **overrides):
    options = {"configuration_changes": [{"ref": FOLLOWUP, "value": 97}] if changes is None else changes,
               "study_exclusions": exclusions or [], "actor_id": ACTOR, "local_demo": True,
               "can_write": True, "allowed_packs": [pack],
               "expected_baseline": dw.describe(root, pack)["baseline_sha256"]}
    options.update(overrides)
    return cp.stage(root, pack, brief(root, pack) if plan is None else plan, **options)


def open_proposal(root, result, pack=PACK, **overrides):
    options = {"proposal_id": result["proposal_id"], "actor_id": ACTOR, "allowed_packs": [pack]}
    options.update(overrides)
    return cp.load(root, pack, **options)


def action(verb, root, result, pack=PACK, **overrides):
    options = {"proposal_id": result["proposal_id"], "actor_id": ACTOR, "allowed_packs": [pack],
               "local_demo": True, "can_write": True}
    options.update(overrides)
    return getattr(cp, verb)(root, pack, **options)


def attach_workbook(root, megabytes, pack=PACK):
    """A binary source document of the size the upload dialog allows, under prog_spec/."""
    workbook = root / pack / "prog_spec/program_spec.xlsx"
    workbook.parent.mkdir(exist_ok=True)
    with workbook.open("wb") as stream:
        for index in range(megabytes):
            stream.write(bytes([index % 251]) * (1024 * 1024))
    return workbook


def test_only_explicit_supported_parameters_are_presented(tmp_path):
    seed(tmp_path)
    before = original_bytes(tmp_path)
    fields = cp.editable_parameters(tmp_path, PACK)
    assert {field["ref"] for field in fields} == {START, END, FOLLOWUP, RECENCY, MONTH, SCHEMA, CUT, MAX_LINES, NUMBERING}
    assert next(field["value"] for field in fields if field["ref"] == RECENCY) == 120
    assert next(field["value"] for field in fields if field["ref"] == FOLLOWUP) == 91
    assert next(field["value"] for field in fields if field["ref"] == START) == "2018-01-01"
    assert original_bytes(tmp_path) == before
    seed(tmp_path, scaffold=True)
    scaffold = cp.editable_parameters(tmp_path, SCAFFOLD)
    assert next(field["value"] for field in scaffold if field["ref"] == FOLLOWUP) == "REPLACE_ME"


def test_applicability_follows_the_files_not_the_product_name(tmp_path):
    seed(tmp_path)
    seed_prostate(tmp_path)
    nothing = "products/oncology/nothing/202609"
    (tmp_path / nothing / "config").mkdir(parents=True)
    (tmp_path / nothing / "config/data_product.yaml").write_text("name: no settings\n", encoding="utf-8")
    former = "products/oncology/gist_program/202606"
    assert not (tmp_path / former).exists()
    for pack, start in ((PACK, "2018-01-01"), (PROSTATE, "2011-01-01")):
        supported = cp.supported_parameters(tmp_path, pack)
        assert set(supported) == {START, END, FOLLOWUP, RECENCY, MONTH, SCHEMA, CUT, MAX_LINES, NUMBERING}
        assert supported[SCHEMA][:2] == ("Delivered source schema", "text") and supported[CUT][:2] == ("Delivery cut", "text")
        assert supported[START] == ("Study index start", "date", start)
        assert supported[FOLLOWUP] == ("Minimum follow-up days", "integer", 91)
        assert supported[MONTH] == ("Days per month", "number", 30.4375)
        assert cp.applicable(tmp_path, pack)
    assert cp.supported_parameters(tmp_path, nothing) == {}
    assert not cp.applicable(tmp_path, nothing) and not cp.applicable(tmp_path, former)
    with pytest.raises(cp.Invalid) as refused:
        cp.editable_parameters(tmp_path, nothing)
    assert str(refused.value) == cp.NO_SUPPORTED_SETTINGS
    plan = {"pack": nothing, "baseline_sha256": "0" * 64}
    result = cp.stage(tmp_path, nothing, plan, configuration_changes=[{"ref": FOLLOWUP, "value": 97}],
                      study_exclusions=[], actor_id=ACTOR, local_demo=True, can_write=True,
                      allowed_packs=[nothing], expected_baseline="0" * 64)
    assert not result["ok"] and result["errors"] == [cp.NO_SUPPORTED_SETTINGS]
    listing = cp.list_proposals(tmp_path, nothing, actor_id=ACTOR, allowed_packs=[nothing])
    assert not listing["ok"] and listing["errors"] == [cp.NO_SUPPORTED_SETTINGS] and not listing["proposals"]
    assert not (tmp_path / nothing / ".portal-drafts").exists()
    assert not cp.stage(tmp_path, former, plan, configuration_changes=[], study_exclusions=[], actor_id=ACTOR,
                        local_demo=True, can_write=True, allowed_packs=[former], expected_baseline="0" * 64)["ok"]


def test_a_broken_parameter_file_is_reported_rather_than_read_as_no_settings(tmp_path):
    product = seed(tmp_path)
    outcomes = product / "variables/outcomes.yaml"
    outcomes.write_text(outcomes.read_text(encoding="utf-8") + "min_followup_days: 120\n", encoding="utf-8")
    with pytest.raises(cp.Invalid) as refused:
        cp.supported_parameters(tmp_path, PACK)
    assert "variables/outcomes.yaml" in str(refused.value)
    assert not cp.applicable(tmp_path, PACK)


def test_prostate_reference_fixture_stages_a_proposal_at_its_own_path(tmp_path):
    seed_prostate(tmp_path)
    before = original_bytes(tmp_path)
    description = dw.describe(tmp_path, PROSTATE)
    assert not description["errors"] and description["is_reference"], description
    result = stage(tmp_path, changes=[{"ref": FOLLOWUP, "value": 97}], pack=PROSTATE)
    assert result["ok"], result
    proposal = result["proposal"]
    assert proposal["pack"] == PROSTATE
    assert yaml.safe_load(proposal["files"][0]["after"])["min_followup_days"] == 97
    assert "-min_followup_days: 91" in proposal["files"][0]["diff"]
    assert original_bytes(tmp_path) == before
    reopened = open_proposal(tmp_path, result, pack=PROSTATE)
    assert reopened["ok"] and not reopened["stale"]
    assert reopened["path"].startswith(PROSTATE + "/.portal-drafts/")


def test_configured_walkthrough_product_runs_the_real_validators_on_its_candidate(tmp_path):
    seed(tmp_path, contract=False)
    before = original_bytes(tmp_path)
    result = stage(tmp_path, changes=[{"ref": RECENCY, "value": 127}])
    assert result["ok"], result
    validation = action("validate", tmp_path, result)
    assert validation["ok"], validation
    checks = {check["validator"]: check for check in validation["checks"]}
    assert {"engine.validate (strict)", "contract_lint", "contract_binding"} <= set(checks)
    assert checks["engine.validate (strict)"]["passed"], checks["engine.validate (strict)"]
    all_errors = " ".join(str(error) for check in validation["checks"] for error in check["errors"])
    assert "TypeError:" not in all_errors and "AttributeError:" not in all_errors
    assert original_bytes(tmp_path) == before


def test_large_attached_workbook_does_not_break_staging_or_staleness(tmp_path):
    product = seed(tmp_path)
    workbook = attach_workbook(tmp_path, 5)
    assert workbook.stat().st_size == 5 * 1024 * 1024 > cp.LIMIT
    assert cp._fingerprint(workbook) == hashlib.sha256(workbook.read_bytes()).hexdigest()
    before = original_bytes(tmp_path)
    result = stage(tmp_path)
    assert result["ok"], result
    assert open_proposal(tmp_path, result)["ok"] and not open_proposal(tmp_path, result)["stale"]
    copies = []

    def inspect_candidate(root, candidate_pack):
        copy_ = Path(candidate_pack) / "prog_spec/program_spec.xlsx"
        copies.append(copy_.stat().st_size)
        return copy.deepcopy(PASSING)

    with patch.object(cp, "_run_validators", side_effect=inspect_candidate):
        validation = action("validate", tmp_path, result)
    assert validation["ok"] and validation["passed"], validation
    assert copies == [5 * 1024 * 1024]
    assert original_bytes(tmp_path) == before
    # The workbook is part of the fingerprint: a swapped attachment makes the proposal stale.
    with workbook.open("ab") as stream:
        stream.write(b"x")
    assert open_proposal(tmp_path, result)["stale"]
    with patch.object(cp, "_run_validators", return_value=copy.deepcopy(PASSING)) as validators:
        assert not action("submit", tmp_path, result)["ok"]
        assert not validators.called
    assert product.is_dir()


def test_oversized_files_are_refused_by_name_without_staging(tmp_path):
    seed(tmp_path)
    attach_workbook(tmp_path, 2)
    before = original_bytes(tmp_path)
    with patch.object(cp, "SOURCE_LIMIT", 1024 * 1024):
        result = stage(tmp_path)
    assert not result["ok"], result
    assert result["errors"] == ["prog_spec/program_spec.xlsx is larger than the supported size of 1 MB; it is 2 MB."]
    assert not (tmp_path / PACK / ".portal-drafts").exists()
    # A file that is parsed keeps the small ceiling, and the refusal still names the file.
    with patch.object(cp, "LIMIT", 256):
        result = stage(tmp_path)
    assert not result["ok"] and len(result["errors"]) == 1, result
    assert result["errors"][0].startswith("config/data_product.yaml is larger than the supported size")
    assert original_bytes(tmp_path) == before
    assert stage(tmp_path)["ok"]


def test_staging_preserves_original_bytes_and_displays_exact_before_after_diff(tmp_path):
    seed(tmp_path)
    before = original_bytes(tmp_path)
    result = stage(tmp_path, changes=[{"ref": RECENCY, "value": 127}, {"ref": MONTH, "value": 30.5}])
    assert result["ok"], result
    proposal = result["proposal"]
    assert proposal["status"] == "staged" and proposal["draft_only"] and not proposal["can_submit"]
    assert not proposal["engineering_handoff"]
    assert len(proposal["files"]) == 1
    document = proposal["files"][0]
    old = before[PACK + "/variables/outcomes.yaml"].decode("utf-8")
    assert document["before"].replace("\r\n", "\n") == old.replace("\r\n", "\n")
    parsed = yaml.safe_load(document["after"])
    assert parsed["visit_recency_days"] == 127 and parsed["days_per_month"] == 30.5
    assert parsed["emits"] == ["id3mosfu", "os"]
    assert parsed["status"] == "active"
    assert "demonstrates the config-to-ADS path" in document["after"]
    assert "-visit_recency_days: 120" in document["diff"]
    assert "+visit_recency_days: 127" in document["diff"]
    assert original_bytes(tmp_path) == before
    reopened = open_proposal(tmp_path, result)
    assert reopened["ok"] and not reopened["stale"]
    assert reopened["proposal_sha256"] == result["proposal_sha256"]
    assert reopened["proposal"]["files"] == proposal["files"]


def test_actual_empty_contract_can_stage_explicit_configuration_without_inventing_definitions(tmp_path):
    seed(tmp_path, contract=False)
    assert not dw.describe(tmp_path, PACK)["rows"]
    result = stage(tmp_path, changes=[{"ref": START, "value": "2018-02-03"},
                                      {"ref": END, "value": "2025-11-17"}])
    assert result["ok"], result
    proposal = result["proposal"]
    parsed = yaml.safe_load(proposal["files"][0]["after"])
    assert parsed["study"] == {"index_start": "2018-02-03", "index_end": "2025-11-17"}
    assert not proposal["impact"]["direct_variables"]
    assert "contract" in " ".join(proposal["warnings"] + proposal["impact"]["notes"]).lower()


def test_impact_reports_declared_transitive_dependencies_and_all_pinned_consumers(tmp_path):
    seed(tmp_path, consumers=True)
    before = original_bytes(tmp_path)
    result = stage(tmp_path, changes=[{"ref": START, "value": "2018-02-03"}])
    assert result["ok"], result
    impact = result["proposal"]["impact"]
    assert "INDEXDT" in impact["direct_variables"]
    assert {"AGE", "OS", "SUMMARY"} <= set(impact["dependent_variables"])
    assert "external:death" in impact["external_dependencies"]
    assert {row["study"] for row in impact["consumers"]} == {"reader-a", "reader-b"}
    assert impact["capabilities"]
    assert "UNUSED" not in impact["dependent_variables"]
    assert original_bytes(tmp_path) == before


def test_study_exclusions_stay_separate_from_shared_removals_and_configuration(tmp_path):
    seed(tmp_path, consumers=True)
    before = original_bytes(tmp_path)
    exclusions = [{"study": "reader-a", "variables": ["OS", "SUMMARY"]}]
    result = stage(tmp_path, brief(tmp_path, retained=["INDEXDT", "AGE"]),
                   exclusions=exclusions, changes=[{"ref": RECENCY, "value": 127}])
    assert result["ok"], result
    proposal = result["proposal"]
    assert proposal["study_exclusions"] == exclusions
    assert proposal["impact"]["shared_removed"] == ["UNUSED"]
    removed = {row.get("variable_id") for row in proposal["engineering_handoff"]}
    assert "UNUSED" in removed and "OS" not in removed and "SUMMARY" not in removed
    assert yaml.safe_load(proposal["files"][0]["after"])["emits"] == ["id3mosfu", "os"]
    assert original_bytes(tmp_path) == before


@pytest.mark.parametrize("exclusions", [
    [{"study": "not-in-brief", "variables": ["UNUSED"]}],
    [{"study": "reader-a", "variables": ["INDEXDT"]}],
    [{"study": "reader-a", "variables": ["UNKNOWN"]}],
])
def test_exclusions_must_name_a_brief_study_and_an_actually_removed_definition(tmp_path, exclusions):
    seed(tmp_path)
    before = original_bytes(tmp_path)
    result = stage(tmp_path, brief(tmp_path, retained=["INDEXDT", "AGE", "OS", "SUMMARY"]),
                   exclusions=exclusions)
    assert not result["ok"] and result["errors"], result
    assert original_bytes(tmp_path) == before
    assert not (tmp_path / PACK / ".portal-drafts").exists()


def test_unknown_derivations_and_source_switch_remain_literal_engineering_handoffs(tmp_path):
    seed(tmp_path)
    definition = "  Classify an unimplemented response\nUnknown stays unknown.  "
    plan = brief(tmp_path, additions=[{"variable_id": "NEW_RESPONSE", "domain": "outcomes",
                                      "definition": definition}], target_source="optum", target_modality="claims")
    result = stage(tmp_path, plan, changes=[])
    assert result["ok"], result
    proposal = result["proposal"]
    assert not proposal["files"] and proposal["engineering_handoff"]
    handoff = proposal["engineering_handoff"]
    assert any(item.get("variable_id") == "NEW_RESPONSE" for item in handoff)
    assert all(item["reason"] and item["required_work"] for item in handoff)
    assert definition in json.dumps(proposal, ensure_ascii=False).replace("\\n", "\n")
    assert "claims" in json.dumps(proposal)
    assert set(proposal["impact"]["direct_variables"]) == {"INDEXDT", "AGE", "OS", "SUMMARY", "UNUSED"}
    with patch.object(cp, "_run_validators", return_value=copy.deepcopy(PASSING)):
        assert not action("submit", tmp_path, result)["ok"]


@pytest.mark.parametrize("change", [
    {"ref": FOLLOWUP, "value": True}, {"ref": FOLLOWUP, "value": -1},
    {"ref": FOLLOWUP, "value": 91.5}, {"ref": RECENCY, "value": "120"},
    {"ref": MONTH, "value": float("nan")}, {"ref": MONTH, "value": 0},
    {"ref": START, "value": "2025-02-30"}, {"ref": END, "value": "tomorrow"},
])
def test_invalid_values_never_become_configuration(tmp_path, change):
    seed(tmp_path)
    before = original_bytes(tmp_path)
    result = stage(tmp_path, changes=[change])
    assert not result["ok"] and result["errors"], result
    assert original_bytes(tmp_path) == before
    assert not (tmp_path / PACK / ".portal-drafts").exists()


@pytest.mark.parametrize("change", [
    {"ref": "config/data_product.yaml#/status", "value": "active"},
    {"ref": "variables/outcomes.yaml#/overall_survival/event_flag", "value": "pretend"},
    {"ref": "../source_refs.yaml#/status", "value": "approved"},
])
def test_unsupported_paths_become_handoff_text_without_reading_or_writing_the_target(tmp_path, change):
    seed(tmp_path)
    before = original_bytes(tmp_path)
    result = stage(tmp_path, changes=[change])
    assert result["ok"], result
    assert not result["proposal"]["files"]
    handoff = result["proposal"]["engineering_handoff"]
    assert handoff and handoff[0]["requested_change"] == change
    assert original_bytes(tmp_path) == before
    with patch.object(cp, "_run_validators", return_value=copy.deepcopy(PASSING)):
        assert not action("submit", tmp_path, result)["ok"]


def test_duplicate_parameters_and_reversed_dates_are_refused(tmp_path):
    seed(tmp_path)
    for changes in ([{"ref": FOLLOWUP, "value": 91}, {"ref": FOLLOWUP, "value": 92}],
                    [{"ref": START, "value": "2025-12-31"}, {"ref": END, "value": "2024-01-01"}]):
        result = stage(tmp_path, changes=changes)
        assert not result["ok"] and result["errors"], result


def test_brief_valid_flag_cannot_forge_unknown_selections_or_baseline(tmp_path):
    seed(tmp_path)
    before = original_bytes(tmp_path)
    plan = brief(tmp_path)
    plan.update({"valid": True, "errors": [], "kept": ["DOES_NOT_EXIST"]})
    assert not stage(tmp_path, plan)["ok"]
    plan = brief(tmp_path)
    plan.update({"valid": True, "errors": [], "baseline_sha256": "f" * 64})
    assert not stage(tmp_path, plan)["ok"]
    assert original_bytes(tmp_path) == before


@pytest.mark.parametrize("options", [
    {"local_demo": False}, {"can_write": False}, {"actor_id": ""},
    {"allowed_packs": []}, {"expected_baseline": ""},
])
def test_stage_requires_editing_session_scope_and_current_baseline(tmp_path, options):
    seed(tmp_path)
    before = original_bytes(tmp_path)
    result = stage(tmp_path, **options)
    assert not result["ok"], result
    assert original_bytes(tmp_path) == before
    assert not (tmp_path / PACK / ".portal-drafts").exists()


def test_saved_proposals_are_actor_and_pack_scoped_and_paths_cannot_be_substituted(tmp_path):
    seed(tmp_path)
    result = stage(tmp_path)
    assert result["ok"], result
    assert not open_proposal(tmp_path, result, actor_id="someone-else@example.test")["ok"]
    assert not open_proposal(tmp_path, result, allowed_packs=[])["ok"]
    assert not cp.list_proposals(tmp_path, PACK, actor_id="someone-else@example.test",
                                 allowed_packs=[PACK])["proposals"]
    for identifier in ("../" + result["proposal_id"], "../../source_refs.yaml", "", "C:/absolute"):
        assert not open_proposal(tmp_path, result, proposal_id=identifier)["ok"]
    assert not action("validate", tmp_path, result, local_demo=False)["ok"]
    assert not action("validate", tmp_path, result, can_write=False)["ok"]
    assert not action("submit", tmp_path, result, allowed_packs=[])["ok"]


def test_existing_validators_fail_real_scaffold_and_prevent_submission(tmp_path):
    seed(tmp_path, contract=False, scaffold=True)
    before = original_bytes(tmp_path)
    result = stage(tmp_path, changes=[{"ref": START, "value": "2018-01-01"},
                                      {"ref": END, "value": "2025-12-31"},
                                      {"ref": FOLLOWUP, "value": 97}], pack=SCAFFOLD)
    assert result["ok"], result
    validation = action("validate", tmp_path, result, pack=SCAFFOLD)
    assert validation["ok"] and not validation["passed"], validation
    assert len(validation["checks"]) >= 3
    assert any(not check["passed"] and check["errors"] for check in validation["checks"])
    checks = {check["validator"]: check for check in validation["checks"]}
    assert {"engine.validate (strict)", "contract_lint", "contract_binding"} <= set(checks)
    assert not checks["engine.validate (strict)"]["passed"]
    # Refusal must come from the existing rules, not an adapter exception that
    # happens to fail closed while never evaluating the actual configuration.
    all_errors = " ".join(str(error) for check in validation["checks"] for error in check["errors"])
    assert "REPLACE_ME" in all_errors
    assert "TypeError:" not in all_errors and "AttributeError:" not in all_errors
    assert not action("submit", tmp_path, result, pack=SCAFFOLD)["ok"]
    assert original_bytes(tmp_path) == before
    assert not open_proposal(tmp_path, result, pack=SCAFFOLD).get("submission")


def test_validation_receives_isolated_candidate_bytes_and_never_applies_them(tmp_path):
    product = seed(tmp_path)
    before = original_bytes(tmp_path)
    result = stage(tmp_path, changes=[{"ref": RECENCY, "value": 127}])
    assert result["ok"], result
    candidates = []

    def inspect_candidate(root, candidate_pack):
        candidate = Path(candidate_pack)
        if not candidate.is_absolute():
            candidate = Path(root) / candidate
        assert candidate.resolve() != product.resolve()
        assert yaml.safe_load((candidate / "variables/outcomes.yaml").read_text(encoding="utf-8"))["visit_recency_days"] == 127
        assert yaml.safe_load((product / "variables/outcomes.yaml").read_text(encoding="utf-8"))["visit_recency_days"] == 120
        candidates.append(candidate)
        return copy.deepcopy(PASSING)

    with patch.object(cp, "_run_validators", side_effect=inspect_candidate):
        validation = action("validate", tmp_path, result)
    assert validation["ok"] and validation["passed"], validation
    assert candidates and all(not candidate.exists() for candidate in candidates)
    assert validation["proposal_sha256"] == result["proposal_sha256"]
    assert original_bytes(tmp_path) == before


def test_submission_reruns_validators_and_never_confers_approval_or_release(tmp_path):
    seed(tmp_path)
    before = original_bytes(tmp_path)
    result = stage(tmp_path)
    assert result["ok"], result
    failed = [{"validator": "engine.validate (strict)", "passed": False, "errors": ["New validator failure"]}]
    with patch.object(cp, "_run_validators", side_effect=[copy.deepcopy(PASSING), failed]) as checks:
        assert action("validate", tmp_path, result)["passed"]
        denied = action("submit", tmp_path, result)
        assert not denied["ok"] and checks.call_count == 2
    assert not open_proposal(tmp_path, result).get("submission")
    with patch.object(cp, "_run_validators", return_value=copy.deepcopy(PASSING)) as checks:
        submitted = action("submit", tmp_path, result)
    assert submitted["ok"] and checks.call_count == 1, submitted
    receipt = submitted["submission"]
    assert receipt["status"] == "submitted_for_review" and receipt["draft_only"]
    assert receipt["approved"] is False and receipt["released"] is False
    assert original_bytes(tmp_path) == before


def test_live_configuration_change_marks_proposal_stale_and_blocks_validation_and_submission(tmp_path):
    product = seed(tmp_path)
    result = stage(tmp_path)
    assert result["ok"], result
    with patch.object(cp, "_run_validators", return_value=copy.deepcopy(PASSING)):
        assert action("validate", tmp_path, result)["passed"]
    config = product / "variables/outcomes.yaml"
    config.write_bytes(config.read_bytes() + b"\n# Concurrent product revision\n")
    current = original_bytes(tmp_path)
    loaded = open_proposal(tmp_path, result)
    assert loaded["ok"] and loaded["stale"], loaded
    with patch.object(cp, "_run_validators", return_value=copy.deepcopy(PASSING)):
        assert not action("validate", tmp_path, result)["ok"]
        assert not action("submit", tmp_path, result)["ok"]
    assert original_bytes(tmp_path) == current


def test_tampered_saved_packet_cannot_be_reopened_or_submitted(tmp_path):
    seed(tmp_path)
    result = stage(tmp_path)
    assert result["ok"], result
    folder = tmp_path / result["path"]
    files = list(folder.glob("*.json")) if folder.is_dir() else [folder]
    assert files
    packet = next(path for path in files if "proposal" in path.name)
    text = packet.read_text(encoding="utf-8")
    assert "Review an explicit follow-up window" in text
    packet.write_text(text.replace("Review an explicit follow-up window", "Tampered scientific intent"), encoding="utf-8")
    assert not open_proposal(tmp_path, result)["ok"]
    with patch.object(cp, "_run_validators", return_value=copy.deepcopy(PASSING)):
        assert not action("submit", tmp_path, result)["ok"]


def test_candidate_file_tampering_is_detected_even_when_the_review_packet_is_untouched(tmp_path):
    seed(tmp_path)
    result = stage(tmp_path)
    assert result["ok"], result
    folder = tmp_path / result["path"]
    packet = (folder / "proposal.json").read_bytes()
    candidate = folder / "candidate/variables/outcomes.yaml"
    candidate.write_bytes(candidate.read_bytes() + b"\n# Unreviewed candidate change\n")
    assert (folder / "proposal.json").read_bytes() == packet
    assert not open_proposal(tmp_path, result)["ok"]
    with patch.object(cp, "_run_validators", return_value=copy.deepcopy(PASSING)) as validators:
        assert not action("validate", tmp_path, result)["ok"]
        assert not action("submit", tmp_path, result)["ok"]
        assert not validators.called


def test_consumer_pin_change_invalidates_reviewed_impact_before_submission(tmp_path):
    seed(tmp_path, consumers=True)
    result = stage(tmp_path)
    assert result["ok"], result
    with patch.object(cp, "_run_validators", return_value=copy.deepcopy(PASSING)):
        assert action("validate", tmp_path, result)["passed"]
    pin = tmp_path / "work/reader-a/PINS.yaml"
    pin.write_bytes(pin.read_bytes().replace(b"decision: reuse", b"decision: reconsider"))
    assert open_proposal(tmp_path, result)["stale"]
    with patch.object(cp, "_run_validators", return_value=copy.deepcopy(PASSING)) as validators:
        assert not action("submit", tmp_path, result)["ok"]
        assert not validators.called


def test_study_exclusion_dependency_conflict_is_visible_and_blocks_submission(tmp_path):
    seed(tmp_path)
    plan = brief(tmp_path, retained=["INDEXDT", "AGE", "SUMMARY", "UNUSED"])
    result = stage(tmp_path, plan, changes=[], exclusions=[{"study": "reader-a", "variables": ["OS"]}])
    assert result["ok"], result
    proposal = result["proposal"]
    assert not proposal["files"] and not proposal["engineering_handoff"]
    assert proposal["impact"]["study_dependency_conflicts"] == [
        {"study": "reader-a", "variable_id": "SUMMARY", "missing_dependencies": ["OS"]}]
    assert proposal["errors"]
    with patch.object(cp, "_run_validators", return_value=copy.deepcopy(PASSING)):
        assert not action("submit", tmp_path, result)["ok"]


def test_failed_staging_leaves_no_partially_published_proposal(tmp_path):
    seed(tmp_path)
    before = original_bytes(tmp_path)
    with patch.object(cp.os, "rename", side_effect=OSError("Simulated disk failure")):
        result = stage(tmp_path)
    assert not result["ok"] and result["errors"]
    listing = cp.list_proposals(tmp_path, PACK, actor_id=ACTOR, allowed_packs=[PACK])
    assert listing["ok"] and not listing["proposals"]
    assert not list((tmp_path / PACK / ".portal-drafts").rglob(".staging-*"))
    assert original_bytes(tmp_path) == before


def test_rehashed_candidate_cannot_smuggle_an_unrequested_configuration_change(tmp_path):
    seed(tmp_path)
    result = stage(tmp_path)
    assert result["ok"], result
    folder = tmp_path / result["path"]
    packet = folder / "proposal.json"
    proposal = json.loads(packet.read_text(encoding="utf-8"))
    edited = proposal["files"][0]
    assert "status: active" in edited["after"]
    edited["after"] = edited["after"].replace("status: active", "status: released")
    edited["diff"] = "".join(difflib.unified_diff(
        edited["before"].splitlines(True), edited["after"].splitlines(True),
        fromfile="a/" + edited["path"], tofile="b/" + edited["path"]))
    edited["semantic_diff"] = cp.config_diff.diff_docs(yaml.safe_load(edited["before"]),
                                                       yaml.safe_load(edited["after"]))
    candidate = folder / "candidate" / edited["path"]
    candidate.write_bytes(edited["after"].encode("utf-8"))
    proposal["artifacts"]["candidate/" + edited["path"]] = hashlib.sha256(candidate.read_bytes()).hexdigest()
    review = folder / "review.diff"
    review.write_bytes("".join(file["diff"] for file in proposal["files"]).encode("utf-8"))
    proposal["artifacts"]["review.diff"] = hashlib.sha256(review.read_bytes()).hexdigest()
    proposal["proposal_sha256"] = dw._hash({key: value for key, value in proposal.items()
                                            if key != "proposal_sha256"})
    packet.write_text(json.dumps(proposal), encoding="utf-8")
    with patch.object(cp, "_run_validators", return_value=copy.deepcopy(PASSING)) as validators:
        assert not action("validate", tmp_path, result)["ok"]
        assert not action("submit", tmp_path, result)["ok"]
        assert not validators.called
    assert yaml.safe_load((tmp_path / PACK / "variables/outcomes.yaml").read_text(encoding="utf-8"))["status"] == "active"


def test_forged_submission_receipt_cannot_claim_approval_or_release(tmp_path):
    seed(tmp_path)
    result = stage(tmp_path)
    assert result["ok"], result
    with patch.object(cp, "_run_validators", return_value=copy.deepcopy(PASSING)):
        assert action("submit", tmp_path, result)["ok"]
    receipt_path = tmp_path / result["path"] / "submission.json"
    receipt = json.loads(receipt_path.read_text(encoding="utf-8"))
    receipt.update({"approved": True, "released": True})
    receipt["receipt_sha256"] = dw._hash({key: value for key, value in receipt.items()
                                          if key != "receipt_sha256"})
    receipt_path.write_text(json.dumps(receipt), encoding="utf-8")
    assert not open_proposal(tmp_path, result)["ok"]
    with patch.object(cp, "_run_validators", return_value=copy.deepcopy(PASSING)):
        assert not action("submit", tmp_path, result)["ok"]


@pytest.mark.parametrize("change", [
    {"passed": False, "errors": ["Existing validator failed"]},
    {"proposal_sha256": "f" * 64},
])
def test_submission_receipt_requires_passing_validation_of_its_own_proposal(tmp_path, change):
    seed(tmp_path)
    result = stage(tmp_path)
    assert result["ok"], result
    with patch.object(cp, "_run_validators", return_value=copy.deepcopy(PASSING)):
        assert action("submit", tmp_path, result)["ok"]
    receipt_path = tmp_path / result["path"] / "submission.json"
    receipt = json.loads(receipt_path.read_text(encoding="utf-8"))
    receipt["validation"].update(change)
    receipt["receipt_sha256"] = dw._hash({key: value for key, value in receipt.items()
                                          if key != "receipt_sha256"})
    receipt_path.write_text(json.dumps(receipt), encoding="utf-8")
    assert not open_proposal(tmp_path, result)["ok"]
    with patch.object(cp, "_run_validators", return_value=copy.deepcopy(PASSING)):
        assert not action("submit", tmp_path, result)["ok"]


if __name__ == "__main__":
    raise SystemExit(run(globals()))
