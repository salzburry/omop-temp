"""The shared functional-contract lint, exercised on a synthetic product.

Two things are being held here. First, that the invariants BITE — a lint nobody has seen fail is a lint
nobody knows works. Second, that they run against a product that is not prostate: the whole point of
moving them into platform/tools was that a second tumour must not need a second copy.

The fixture below is a complete miniature product — the smallest thing the lint considers valid — so a
new tumour can read it as the shape to fill in.

Run: python3 -m pytest platform/tests/test_contract_lint.py (or pytest).
"""
import json
import os
import sys
import tempfile
from pathlib import Path

REPO = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(REPO / "platform" / "tools"))

import contract_lint # noqa: E402
import re # noqa: E402
from contract_lint import (read, records, _scalar, _inline) # noqa: E402

# The ai_extraction fixture helpers, IMPORTED rather than reimplemented. `--item` drafting now goes
# through `contract_scaffold.ai_gate`, so any test that lifts spec text needs a pack somebody has
# signed — and `test_spec_slice` already owns the only correct way to produce one (a throwaway COPY,
# signed against its own path and bytes, because an approval binds to both). A second signer here
# would be a second answer to "what does an approved extraction look like", and the two would agree
# right up until the first field is added to the block.
sys.path.insert(0, str(Path(__file__).resolve().parent))
from test_spec_slice import _approved, _sign # noqa: E402
from source_manifest import ai_readable as _sm_ai_readable # noqa: E402

FIXTURE = REPO / "platform" / "tests" / "fixtures" / "prostate_202607"

RECORD = """```yaml
variable_id: {vid}
spec_refs: [{ref}]
spec_digest: {digest}
required_rule: PD-L1 tumour proportion score at index
source: {{logical_table: biomarkers, physical_stem: t_enh_nsclc_biomarker, columns: {{value: pdl1percent}}}}
grain: [patientid, index_date, cohortn]
anchor: index_date
window: "[-30, +7]"
record_selection: closest
tie_break: {{equidistant: prior, same_day: max}}
derivation: "try_cast(pdl1percent as double), closest to index"
cohort_applicability: all cohorts
missing: {{no_record: null, present_null: null}}
units: percent
depends_on: [engine:index]
output: {{physical_name: pdl1_tps, target_published_name: PDL1_TPS, name_status: aligned, type: double, nullable: true, codes: n/a, role: published}}
status: {{requirement: {req}, source: unverified, implementation: {impl}, validation: not_run}}
decision_ids: [{decs}]
gap_ids: [{gaps}]
publish: {{ads: configured, dictionary: configured, dashboard: undecided, tfl: undecided}}
acceptance: "pdl1percent=55 at index-3d -> PDL1_TPS=55"
notes: synthetic fixture
implementation_refs: [none]
```
"""


def build_product(tmp, records, spec_rows=((("clinical"), 3),), flags=(), sources=False):
    """A miniature product: handoff artifacts plus the spec-pipeline extraction I8 resolves against."""
    # A counter in the path so one test can build several products in the same tmpdir.
    build_product.n = getattr(build_product, "n", 0) + 1
    product = Path(tmp) / f"p{build_product.n}" / "products" / "oncology" / "nsclc" / "202606"
    (product / "handoff").mkdir(parents=True)
    (product / "spec_pipeline" / "out").mkdir(parents=True)
    (product / "handoff" / "FUNCTIONAL_CONTRACT.md").write_text("# contract\n\n" + "\n".join(records), encoding="utf-8")
    (product / "handoff" / "DECISIONS.md").write_text(
        "| ID | Question | Owner | Status |\n|---|---|---|---|\n"
        "| NAME-ALIGN | naming | DataExpert | OPEN |\n| BIOM-WINDOW | window | Science | OPEN |\n"
        "| FUED-RULE | follow-up end | Science | RESOLVED |\n", encoding="utf-8")
    (product / "handoff" / "ENGINE_GAPS.md").write_text(
        "| Gap | What |\n|---|---|\n| G-PDL1 | Engine · PD-L1 closest-record |\n", encoding="utf-8")
    # A row the REAL readers can use, not just I8's `(domain, row)` lookup. `contract_scaffold`'s
    # `requirement_rows`/`evidence_for` need the shape the extractor actually emits, and a stub with
    # two keys meant `--item` — now required whenever a pack has an extraction — could not resolve
    # against any fixture in this file.
    rows = [{"domain": d, "row": r, "item_id": f"{d}:{r}", "tab": d, "cells": [],
             "variable": "PDL1_TPS", "content_hash": "", "text": "",
             "fields": {"variable": "PDL1_TPS", "definition": "PD-L1 tumour proportion score at index"}}
            for d, r in spec_rows]
    # The extraction ENVELOPE, not just the rows. `ai_extraction_block` binds an approval to the run
    # (`fingerprint`) and to the redaction policy in force, and refuses an artifact carrying neither
    # as one that predates the redactor — so a fixture without it cannot be signed, and every
    # `--item` test would have to skip.
    import source_manifest as _sm
    (product / "spec_pipeline" / "out" / "extracted.json").write_text(json.dumps(
        {"extraction": {"extractor_version": "1.2", "fingerprint": "f1x7ure0000feed",
                        "redaction": {"policy_sha256": _sm.redaction_policy_sha256(),
                                      "cells_redacted": 0, "rows_redacted": 0},
                        "sources": [], "row_count": len(rows)},
         "rows": rows}), encoding="utf-8")
    #...and the ancestry an ai_extraction is derived from. Two links, because `ai_readable` walks the
    # WHOLE chain rather than the parent: one extra registered hop is how a vendor_restricted document
    # moved out of view once already.
    (product / "source_refs.yaml").write_text(
        "source_materials:\n"
        "  - material_id: program_spec\n"
        "    material_type: program_spec\n"
        "    status: reviewed\n"
        "    ai_classification: sponsor_ai_eligible\n"
        "  - material_id: spec_tabs\n"
        "    material_type: extraction_input\n"
        "    derived_from: program_spec\n"
        "    status: reviewed\n"
        "    ai_classification: sponsor_ai_eligible\n", encoding="utf-8")
    # WHICH registered material the extractor read. `pipeline_material` resolves the parent through
    # this and returns None when it cannot — so without it the signed block records
    # `derived_from: TODO` and `ai_readable` refuses, correctly, for a reason that has nothing to do
    # with the test.
    (product / "spec_pipeline" / "pipeline.conf").write_text("TUMOR=nsclc\nSPEC_SOURCE_ID=spec_tabs\n", encoding="utf-8")
    _sign(str(product))
    # lint.json ships from the same pipeline run as extracted.json, and I17 treats one without the
    # other as a half-written out/ rather than a reason to skip. `flags` seeds the unsettled rows.
    (product / "spec_pipeline" / "out" / "lint.json").write_text(json.dumps(
        {"findings": [{"item_id": i, "kind": k, "detail": "fixture", "severity": "INFO"}
                      for i, k in flags],
         "applicability": {"foreign_table": "applied", "reasons": []}}), encoding="utf-8")
    # A pack with NO config/ is the pre-config state every new tumour starts in — the one condition
    # that makes `source.kind: pending_mapping` legal. Default off, because that IS the new-tumour
    # shape; pass sources=True for a pack that has a registry and so has run out of that excuse.
    if sources:
        (product / "config").mkdir(parents=True)
        (product / "config" / "data_product.yaml").write_text(
            "product_id: nsclc\nsources:\n  biomarkers:\n    stem: t_enh_nsclc_biomarker\n", encoding="utf-8")
    return str(product)


def lint(tmp, records, **kw):
    return contract_lint.run(build_product(tmp, records, **kw))


def one(vid="PDL1_TPS", ref="clinical:3", req="approved", impl="implemented", decs="", gaps=""):
    # The digest is computed by the LINT's own function over the fixture's rows (which carry no
    # content_hash), so these records stay valid under I15 without restating how the hash is built.
    m = contract_lint.SPEC_REF_RE.match(ref)
    srows = {}
    if m:
        lo, hi = int(m.group(2)), int(m.group(3) or m.group(2))
        srows = {m.group(1): {n: "" for n in range(lo, hi + 1)}}
    digest = contract_lint.spec_digest([ref], srows) or contract_lint.NA
    return RECORD.format(vid=vid, ref=ref, req=req, impl=impl, decs=decs, gaps=gaps, digest=digest)


PENDING = """```yaml
variable_id: {vid}
spec_refs: [clinical:3]
spec_digest: {digest}
required_rule: PD-L1 tumour proportion score at index
source: {{kind: pending_mapping, spec_identifiers: [{idents}]}}
grain: [patientid, index_date, cohortn]
anchor: index_date
window: "[-30, +7]"
record_selection: closest
tie_break: {{equidistant: prior, same_day: max}}
derivation: "closest to index"
cohort_applicability: all cohorts
missing: {{no_record: null, present_null: null}}
units: percent
depends_on: [engine:index]
output: {{physical_name: pdl1_tps, target_published_name: PDL1_TPS, name_status: undecided, type: double, nullable: true, codes: n/a, role: published}}
status: {{requirement: {req}, source: {src}, implementation: {impl}, validation: not_run}}
decision_ids: []
gap_ids: [{gaps}]
publish: {{ads: undecided, dictionary: undecided, dashboard: undecided, tfl: undecided}}
acceptance: "pdl1percent=45 -> PDL1_TPS=45"
notes: "Logical source registry not yet authored. Identifier copied exactly from the spec."
implementation_refs: [none]
```"""


def pending(vid="PDL1_TPS", idents="pdl1percent", req="draft", src="unverified",
            impl="not_implemented", gaps="G-PDL1"):
    digest = contract_lint.spec_digest(["clinical:3"], {"clinical": {3: ""}}) or contract_lint.NA
    return PENDING.format(vid=vid, idents=idents, req=req, src=src, impl=impl, gaps=gaps,
                          digest=digest)


def test_i19_implementation_refs_must_be_ANSWERED_not_merely_present():
    """The column being present is not the field being answered. #344 made it structurally required
    but left the VALUE outside CANON, so the binder asked for it only when `implementation` was
    `implemented` or `partial` — and 33 prostate/202606 records sat at `TODO`, which reads the same as
    a blank cell and the opposite of a deliberate `[none]`."""
    with tempfile.TemporaryDirectory() as tmp:
        for bad in ("", "TODO"):
            rec = one().replace("implementation_refs: [none]", f"implementation_refs: {bad}".rstrip())
            errors, _ = lint(tmp, [rec])
            assert any("I19" in e for e in errors), (bad, errors)
        # `[none]` is an ANSWER and passes
        assert lint(tmp, [one()])[0] == []


def test_pending_mapping_is_legal_on_a_pack_with_no_source_registry():
    """The state every new tumour starts in. The workflow authors the contract BEFORE config, so
    there is no `sources:` block to name — and until this kind existed the skill could only say what
    not to write (invent no alias) while offering nothing the parser accepts. Drafters filled that
    with TODO, a physical table name, or an invented alias; the last is indistinguishable from a real
    mapping once config arrives."""
    with tempfile.TemporaryDirectory() as tmp:
        errors, n = lint(tmp, [pending()])
        assert errors == [], errors
        assert n == 1


def test_pending_mapping_stays_legal_beside_a_registry_and_comes_due_at_GATE_4():
    """THE PACK'S REGISTRY IS NOT THIS RECORD'S MAPPING, AND TREATING IT AS ONE MADE THE STATE UNREACHABLE.

    I18 used to refuse `pending_mapping` in any pack whose `config/data_product.yaml` declared a
    `sources:` block. `TUMOR_TEMPLATE` ships one — full of `REPLACE_ME` — so the starter pack every
    new tumour is cloned from counted as HAVING a registry from its first commit, and the state
    designed for exactly that pack was illegal in it. Adding a NEW concept to a mature pack was
    worse: the honest record for a variable nobody has mapped could not be written, leaving the
    drafter to invent a source or omit the requirement. Both are the failure this kind prevents.

    So the question moved to where it can be answered per RECORD rather than per PACK. Gate 2 asks
    what the requirement IS, and a requirement is fully stateable before its source is chosen; Gate 4
    asks whether the configuration expresses that contract, and a record with no source is one no
    configuration can express. This test pins both halves — the second is what stops the state
    becoming permanent, and without it this change would be a pure loosening.
    """
    with tempfile.TemporaryDirectory() as tmp:
        errors, n = lint(tmp, [pending()], sources=True)
        assert errors == [], f"Gate 2 refuses a record whose source is honestly undecided: {errors}"
        assert n == 1

    #...and Gate 4 does not. `unverified_sources` is the function `product_gates` calls for
    # `configuration: approved`; a `pending_mapping` record must appear in it, or moving the check
    # out of I18 would have deleted it rather than relocated it.
    with tempfile.TemporaryDirectory() as tmp:
        pack = build_product(tmp, [pending()], sources=True)
        text = contract_lint.read(os.path.join(pack, "handoff", "FUNCTIONAL_CONTRACT.md"))
    open_at_g4 = contract_lint.unverified_sources(text)
    assert any(vid == "PDL1_TPS" for vid, _why in open_at_g4), \
        f"Gate 4 cannot see a record with no source at all: {open_at_g4}"
    assert any("pending_mapping" in why for _vid, why in open_at_g4), open_at_g4


def test_pending_mapping_must_carry_the_specs_own_identifiers():
    """Verbatim, so the mapping can be finished by someone who never read the workbook. Without them
    the record states no source at all — which is the invented-alias failure with extra steps."""
    with tempfile.TemporaryDirectory() as tmp:
        errors, _ = lint(tmp, [pending(idents="")])
        assert any("requires `spec_identifiers: [...]`" in e for e in errors), errors
        errors, _ = lint(tmp, [pending(idents="TODO")])
        assert any("placeholder 'TODO'" in e for e in errors), errors


def test_pending_mapping_needs_NO_gap_because_the_starter_has_no_gap_register():
    """A starter pack has no gap register, and requiring one breaks every new product.

    A gap is an APPROVED requirement the build or feed cannot satisfy — Gate 4 material that arrives
    after the contract exists — and `sandbox/new_tumour_start/handoff/` ships no ENGINE_GAPS.md at
    all. So requiring one gave: no registry -> use pending_mapping -> I18 demands a gap -> no gap
    register -> the id resolves to nothing -> I2 fails. It was redundant as well as broken:
    `pending_mapping` is already explicit, countable and barred from approval, so a gap restating it
    is a second record of one fact.
    """
    with tempfile.TemporaryDirectory() as tmp:
        assert lint(tmp, [pending(gaps="")])[0] == [], lint(tmp, [pending(gaps="")])[0]
        #...and a gap is still ALLOWED, for a genuinely broader implementation problem
        assert lint(tmp, [pending(gaps="G-PDL1")])[0] == []


def test_the_starter_pack_really_has_no_gap_register():
    """The premise of the test above. If a gap register is ever added to the starter, the reasoning
    changes and someone should revisit this deliberately rather than discover it."""
    starter = REPO / "sandbox" / "new_tumour_start" / "handoff"
    if not starter.exists():
        return
    assert not (starter / "ENGINE_GAPS.md").exists(), \
        "the starter grew a gap register — re-examine whether pending_mapping should cite one"


def test_pending_mapping_can_never_be_approved_verified_or_built():
    """It cannot pass Gate 3, Gate 4 or approval. Each axis separately: approving a rule nobody can
    execute, verifying a source that does not exist, or building from one, are three different lies."""
    with tempfile.TemporaryDirectory() as tmp:
        for kw, want in ((dict(req="approved"), "cannot be `requirement: approved`"),
                         (dict(src="verified_live"), "must be `source: unverified`"),
                         (dict(impl="implemented"), "cannot be `implementation: implemented`")):
            errors, _ = lint(tmp, [pending(**kw)])
            assert any(want in e for e in errors), (kw, errors)


def test_pending_mapping_does_NOT_force_the_requirement_axis_to_decision_required():
    """The two axes stay apart. A requirement Science has fully specified does not become an open
    scientific question because DataExpert has not yet chosen a logical alias — that is a configuration task,
    and conflating them buries the rows that genuinely need Science."""
    with tempfile.TemporaryDirectory() as tmp:
        errors, _ = lint(tmp, [pending(req="draft")])
        assert errors == [], errors
        assert not any("decision_required" in e for e in errors)


def test_pending_mapping_is_not_vendor_sourced_so_gate_3_does_not_ask_it_for_evidence():
    """It has no vendor table to evidence. Counting it as vendor-sourced would put an unanswerable
    row in the Gate 3 backlog; counting it as `constant` would excuse it forever."""
    block = pending()
    assert contract_lint.source_kind(block) == contract_lint.PENDING_MAPPING
    assert not contract_lint.vendor_sourced(block)


def test_the_renderer_and_the_reader_agree_on_every_record_in_the_repo():
    """The writer is checked against the READER, on real records, not by eye.

    `render_row` exists so the drafting model stops assembling markdown by hand — field order, pipe
    escaping, newline folding and cell count are mechanical, and one unescaped `|` shifts every later
    field into the wrong key while leaving each cell individually well-formed. A renderer nobody
    verifies is just a second notation; this parses every shipped record, re-renders it, and requires
    the round-trip to be exact.
    """
    import contract_record
    import product_gates
    # products/ holds no pack today, so this proved nothing; the fixtures are where every record lives
    for pack in sorted((REPO / "products").glob("*/*/*/handoff/FUNCTIONAL_CONTRACT.md")) + \
            sorted((REPO / "fixtures").glob("*/*/*/handoff/FUNCTIONAL_CONTRACT.md")):
        text = pack.read_text(encoding="utf-8")
        blocks = list(contract_lint.records(text))
        # the template ships its contract EMPTY on purpose; a pack whose maturity says the contract is
        # not started has nothing to round-trip yet (eleventh verdict: a freshly copied pack was red here)
        if not blocks and product_gates.maturity(str(pack.parent.parent)).get("contract") == "not_started":
            continue
        assert blocks, f"{pack} parsed as zero records"
        for b in blocks:
            rec = {ln.split(":", 1)[0]: ln.split(":", 1)[1].strip()
                   for ln in b.splitlines() if ":" in ln}
            _row, problems = contract_record.row_for(rec)
            assert not problems, (pack.parent.parent.name, rec.get("variable_id"), problems)


def test_the_renderer_escapes_pipes_folds_newlines_and_keeps_cell_count():
    """The four mechanical rules no drafter should apply by hand."""
    import re as _re
    import contract_record
    rec = {"variable_id": "X", "notes": "has a | pipe\nand a newline", "implementation_refs": ["none"],
           "output": {"physical_name": "x", "nullable": True}}
    # allow_partial: this checks ESCAPING, not completeness. A partial record is refused by default
    # now — see the test below — and this flag exists for exactly this case and no other.
    row, problems = contract_record.row_for(rec, allow_partial=True)
    assert not problems, problems
    assert len(_re.split(r"(?<!\\)\|", row.strip())[1:-1]) == len(contract_lint.TABLE_COLUMNS)
    assert "\n" not in row and r"\|" in row
    assert "nullable: true" in row, "a YAML bool must render as the contract writes it, not 'True'"
    assert contract_lint.table_shape_errors(contract_lint.render_table([rec])) == []


def test_the_table_reader_can_preserve_a_row_with_no_variable_id_for_loss_checks():
    """A reconciliation cannot report an unnamed row if the shared reader drops it first."""
    text = contract_lint.render_table([
        {"variable_id": "NAMED", "required_rule": "first requirement"},
        {"variable_id": "", "required_rule": "unnamed requirement must remain visible"},
    ])
    blocks = list(contract_lint.records(text, keep_unnamed=True))
    assert len(blocks) == 2, blocks
    assert _scalar(blocks[0], "variable_id") == "NAMED"
    assert _scalar(blocks[1], "variable_id") is None
    assert _scalar(blocks[1], "required_rule") == "unnamed requirement must remain visible"


def test_fresh_records_join_the_ONE_record_table_not_a_new_table_per_apply():
    """Each `--apply` appended a fresh header+table for its record, so a pack drafted one --item at
    a time ended as 36 one-row tables — parseable, but not the "rows of one markdown table" the
    docs promise, and unreadable as a document. Fresh rows must join the FIRST record table; only
    a contract with no record table yet gets one; and prose tables that merely mention the word
    variable_id must not be mistaken for it."""
    import contract_record
    def rec_dict(vid):
        return {ln.split(": ", 1)[0]: ln.split(": ", 1)[1]
                for ln in one(vid=vid).splitlines() if ": " in ln and not ln.startswith("```")}
    preamble = ("# contract\n\n| where | to look |\n|---|---|\n"
                "| every `variable_id` rule | contract_lint.py |\n\n")
    text = contract_record.upsert(preamble, [rec_dict("AAA")])
    text = contract_record.upsert(text, [rec_dict("BBB")])
    text = contract_record.upsert(text, [rec_dict("CCC")])
    headers = [ln for ln in text.splitlines() if re.match(r"\|\s*variable_id\s*\|", ln.strip())]
    assert len(headers) == 1, f"{len(headers)} record-table headers — one --apply per record " \
                              f"must not mint one table per record"
    vids = [contract_lint._scalar(b, "variable_id") for b in records(text)]
    assert vids == ["AAA", "BBB", "CCC"], vids
    assert "| where | to look |" in text, "the prose table was clobbered"
    # idempotent, still: re-upserting a record replaces its row in place
    again = contract_record.upsert(text, [rec_dict("BBB")])
    assert again == text, "upsert stopped being idempotent"


def test_revising_an_EXISTING_record_replaces_it_rather_than_duplicating_it():
    """`--product` copied the pack and APPENDED the candidate. Right for a new record; wrong for the
    revision case the skill explicitly supports — the temp copy then held two records with one
    variable_id, so a valid replacement failed I1 as a duplicate.

    The pack here is built in TABLE format on purpose. The shared fixture writes fenced ```yaml
    blocks, and `records()` ignores fenced blocks entirely once a table exists — so appending a table
    to a fenced pack silently REPLACES the whole contract, no duplicate is ever created, and a test
    written against that fixture passes whether the replace logic works or not. It did, and caught
    nothing.
    """
    import contract_record
    import contract_scaffold
    import yaml as _y
    with tempfile.TemporaryDirectory() as tmp:
        rec = {ln.split(": ", 1)[0]: ln.split(": ", 1)[1]
               for ln in one().splitlines() if ": " in ln and not ln.startswith("```")}
        product = build_product(tmp, [contract_lint.render_table([rec])])
        contract = os.path.join(product, "handoff", "FUNCTIONAL_CONTRACT.md")
        assert len(list(contract_lint.records(contract_lint.read(contract)))) == 1
        assert "| variable_id |" in contract_lint.read(contract), "fixture is not in table format"

        # The real revision flow: judgment fields only, evidence re-supplied from the extraction by
        # --item. `--item` is required now that the fixture carries one, which is the point.
        revised = {k: v for k, v in dict(rec, notes="REVISED").items()
                   if k not in contract_scaffold.MACHINE_OWNED}
        draft = os.path.join(tmp, "rev.yaml")
        with open(draft, "w", encoding="utf-8") as fh:
            _y.safe_dump(revised, fh, sort_keys=False, width=10 ** 6)

        # STATUS IS NOT IN THE DRAFT. The tool settles it: this is a REVISION of an existing record,
        # so it keeps the status that record already holds — including `requirement: approved`, which
        # a drafter could never have written and does not have to.
        revised.pop("status", None)
        with open(draft, "w", encoding="utf-8") as fh:
            _y.safe_dump(revised, fh, sort_keys=False, width=10 ** 6)
        args = [draft, "--product", product, "--item", "clinical:3"]
        rc = contract_record.main(args)
        assert rc == 0, "a valid revision of an existing record was refused (appended, not replaced)"

        # a genuinely NEW id must still be appended, not dropped
        draft2 = os.path.join(tmp, "new.yaml")
        with open(draft2, "w", encoding="utf-8") as fh:
            # a NEW id citing the fixture's only row NAMES that row's variable in depends_on (the eleventh
            # verdict: a silent mismatch is refused; its second pass: a mention in the notes is not a statement)
            _y.safe_dump(dict(revised, variable_id="BRAND_NEW", depends_on=["PDL1_TPS"],
                              notes="a new record derived from the PDL1_TPS row"),
                         fh, sort_keys=False, width=10 ** 6)
        assert contract_record.main([draft2, "--product", product, "--item", "clinical:3"]) == 0


def test_the_generated_starting_point_is_what_the_drafting_tool_ACCEPTS():
    """The two artifacts were each individually right and could not be used together.

    `scaffold.json` emits every record with `spec_refs`, `spec_digest`, `required_rule` and `status`
    — and `contract_record` REFUSES a draft carrying any of them, because those come from the
    extraction and from an accountable person, not from a drafter. So the generated starting point had
    to be hand-stripped before the tool that consumes it would take it: once per record, by every
    analyst, on every pack. That editing is the manual work, and it was structural rather than
    incidental.

    `judgment_stub` is the one definition of what a drafter answers, and this asserts the property
    that makes it worth having: the stub goes into the tool UNMODIFIED and the only complaints that
    come back are unanswered judgment fields.
    """
    import contract_record
    import contract_scaffold as cs
    import yaml as _y

    stub = cs.judgment_stub("HRR_INDEXN")
    parsed = _y.safe_load(stub)

    # It must not carry ANY field the tool refuses. Read from the tool's own constants, so a field
    # moving into or out of machine ownership cannot leave this test asserting the old set.
    for field in cs.MACHINE_OWNED:
        assert field not in parsed, \
            f"the stub carries {field}, which contract_record refuses — the hand-strip is back"
    assert "status" not in parsed, \
        "the stub carries `status`, which the tool settles; a drafter writing one is refused"

    #...and it must carry every field the tool REQUIRES. `implementation_refs` sits outside
    # CANON_ORDER (`TABLE_COLUMNS[:-1]` drops it) and is still required, which is exactly the kind of
    # omission a stub built from one list and consumed by another would have.
    row, problems = contract_record.row_for(dict(parsed, **{
        f: "n/a" for f in cs.MACHINE_OWNED}, status="{requirement: draft}"))
    assert not any("incomplete" in p for p in problems), \
        f"the stub is missing a field the tool requires: {[p for p in problems if 'incomplete' in p]}"
    assert not any("I19" in p for p in problems), \
        f"implementation_refs must be `[none]`, an ANSWER — not `[]` or TODO: {problems}"

    # What remains unanswered is JUDGMENT, which is the honest state of a stub and must NOT be
    # pre-answered away. `output.role` is a real decision — published / internal / metadata /
    # excluded — and a stub that guessed it would make it easier to author a record without reading
    # the specification row, which is the failure the whole slice arrangement is against.
    #
    # Asserted on the STUB, not on `row_for`'s problems: `row_for` without a pack deliberately skips
    # every pack-specific invariant (I3 among them), so a problems-based assertion here would be
    # testing the entry point rather than the stub. Through the CLI with `--product` it is I3 that
    # reports this, and that path is exercised by the round-trip above.
    # `output` parses as a real mapping — the inline form is how the contract STORES it, not how
    # YAML reads it back.
    assert parsed["output"]["role"] == "TODO", \
        f"the stub pre-answered output.role — a judgment field must stay TODO: {parsed['output']}"
    assert parsed["output"]["physical_name"] == "TODO", parsed["output"]
    assert parsed["output"]["name_status"] == "undecided", \
        "name_status starts UNDECIDED — `aligned` is a claim about a name somebody agreed"
    #...and the stub TEXT must still carry the inline single-line form, because the CI lint parses
    # these three positionally and a multi-line dict reads as absent (I6).
    assert "output: {physical_name: TODO" in stub, stub
    assert all(parsed[f] == "TODO" for f in ("source", "grain", "anchor", "window", "derivation")), \
        "a core judgment field is pre-answered"

    # One policy, not three. The stub's defaults come from the same INLINE_DEFAULTS the scaffold's
    # table renderer uses; a second copy is how the two would start disagreeing about what an
    # unanswered field looks like.
    import yaml as _yy
    assert parsed["publish"] == _yy.safe_load(cs.INLINE_DEFAULTS["publish"])
    assert parsed["decision_ids"] == [] and parsed["gap_ids"] == []


def test_a_PARTIAL_record_is_refused_by_default():
    """A governed draft short of the schema must not be a successful default. `row_for` compared only
    the keys the caller SUPPLIED, so a half-written record rendered to empty cells and reported
    nothing — the real completeness invariant ran only under `--product`, which the skill documented
    as optional."""
    import contract_record
    _row, problems = contract_record.row_for({"variable_id": "X"})
    assert any("incomplete" in p for p in problems), problems
    assert "spec_refs" in problems[0] and "derivation" in problems[0], problems[0]
    # `n/a` and `[]` ARE answers — the check is about absence, not emptiness of meaning
    full = {k: "n/a" for k in contract_lint.TABLE_COLUMNS}
    assert contract_record.row_for(full)[1] == []


def test_an_unknown_field_is_an_ERROR_not_silently_dropped():
    """A field the table has no column for is a typo or a schema change. Dropping it loses the answer
    it carried, and the record still renders to a perfectly well-formed row."""
    try:
        contract_lint.render_row({"variable_id": "X", "windwo": "typo"})
    except ValueError as e:
        assert "windwo" in str(e), str(e)
    else:
        raise AssertionError("an unknown contract field was silently discarded")


def test_a_clean_minimal_product_passes():
    with tempfile.TemporaryDirectory() as tmp:
        errors, n = lint(tmp, [one()])
        assert errors == [], errors
        assert n == 1


def test_i1_duplicate_variable_id():
    with tempfile.TemporaryDirectory() as tmp:
        errors, _ = lint(tmp, [one(), one()])
        assert any("I1 duplicate variable_id" in e for e in errors), errors


def test_i3_rejects_an_invented_status_value():
    with tempfile.TemporaryDirectory() as tmp:
        errors, _ = lint(tmp, [one(req="probably_fine")])
        assert any("I3 status.requirement" in e for e in errors), errors


def test_i6_bites_when_a_record_drops_one_field():
    """A record dropping even one canonical field is the exact defect — a partial copy of the contract —
    that I6 exists to catch. Prove it, don't just assert coverage."""
    with tempfile.TemporaryDirectory() as tmp:
        partial = "\n".join(l for l in one().splitlines() if not l.startswith("units:"))
        errors, _ = lint(tmp, [partial])
        assert any("I6 missing/empty canonical field `units`" in e for e in errors), errors


def test_a_resolved_decision_may_stay_on_an_approved_record():
    """Why I7 was retired. It read `decision_ids` without consulting the register's Status, so ANY
    requirement-level id on an approved record failed — including the RESOLVED one that records what
    settled the rule. The only way to pass was to delete the trace, which is the opposite of what a
    decision register is for. I11 asks the same question status-aware, and these three cases are the
    whole of it: OPEN blocks, RESOLVED does not, output-level never did."""
    with tempfile.TemporaryDirectory() as tmp:
        errors, _ = lint(tmp, [one(decs="BIOM-WINDOW")]) # OPEN, requirement-level
        assert any("I11 cites OPEN" in e for e in errors), errors
        assert lint(tmp, [one(decs="FUED-RULE")])[0] == [] # RESOLVED — the audit trail stays
        assert lint(tmp, [one(decs="NAME-ALIGN")])[0] == [] # OPEN but output-level


def test_i23_worked_arithmetic_in_acceptance_must_compute():
    """Five simulated drafting runs wrote `181/30.4375 = 5.95`-style examples and no tool checked
    the division — a wrong worked example reads as evidence downstream. The stated result must BE
    the true value rounded or truncated at its own displayed precision: a ±1-unit tolerance at
    zero displayed digits accepted `1/3 = 1` — off by triple, inside tolerance — which an
    external review demonstrated is not a check."""
    def with_acceptance(acc):
        return one().replace('acceptance: "pdl1percent=55 at index-3d -> PDL1_TPS=55"',
                             f'acceptance: "{acc}"')
    with tempfile.TemporaryDirectory() as tmp:
        errors, _ = lint(tmp, [with_acceptance("OS: 181/30.4375 = 9.99 months")])
        assert any("I23" in e for e in errors), errors
        assert lint(tmp, [with_acceptance("OS: 181/30.4375 = 5.95 months")])[0] == [] # rounded
        # a truncated value passes ONLY when the cell says so — silently accepting either
        # convention meant a wrong example passed half the time
        assert lint(tmp, [with_acceptance("OS: 181/30.4375 = 5.94 months (floored)")])[0] == []
        errors, _ = lint(tmp, [with_acceptance("OS: 181/30.4375 = 5.94 months")])
        assert any("TRUNCATED value" in e and "does not say so" in e for e in errors), errors
        # a calendar date is prose, not arithmetic — no `=` follows the divisor
        assert lint(tmp, [with_acceptance("index on 4/31/2027 is impossible")])[0] == []
        # the review's probe rows: at 0 displayed digits only floor(1/3)=0 or round(1/3)=0 pass
        errors, _ = lint(tmp, [with_acceptance("ratio 1/3 = 1 of patients")])
        assert any("I23" in e for e in errors), errors
        assert lint(tmp, [with_acceptance("ratio 1/3 = 0 of patients")])[0] == [] # rounds to 0
        assert lint(tmp, [with_acceptance("ratio 2/3 = 1 of patients")])[0] == [] # rounded
        # the review's ambiguity probe: `2/3 = 0` no longer passes silently beside `2/3 = 1` —
        # a truncation must SAY it is one
        errors, _ = lint(tmp, [with_acceptance("ratio 2/3 = 0 of patients")])
        assert any("TRUNCATED value" in e for e in errors), errors
        assert lint(tmp, [with_acceptance("ratio 2/3 = 0 of patients (truncated)")])[0] == []
        # an explicit `+` sign used to fall outside the pattern and go entirely unjudged
        errors, _ = lint(tmp, [with_acceptance("shift +1/2 = 9 days")])
        assert any("I23" in e for e in errors), errors
        assert lint(tmp, [with_acceptance("shift +1/2 = 0.5 days")])[0] == []


def test_i23_boundaries_signed_operands_zero_division_and_midnumber_matches():
    """An external review's probe table, pinned. The first regex discarded the numerator's sign
    (falsely rejecting a correct negative example), never parsed a negative denominator
    (accepting a wrong one), silently SKIPPED division by zero, and matched `3/2` out of the
    middle of `1e3/2`. Every row of that table is now a test."""
    def with_acceptance(acc):
        return one().replace('acceptance: "pdl1percent=55 at index-3d -> PDL1_TPS=55"',
                             f'acceptance: "{acc}"')
    with tempfile.TemporaryDirectory() as tmp:
        # correct negative example passes; sign is not discarded
        assert lint(tmp, [with_acceptance("delta: -181/30.4375 = -5.95 months")])[0] == []
        # wrong example with a negative denominator is caught, not skipped
        errors, _ = lint(tmp, [with_acceptance("181/-30.4375 = 99.99")])
        assert any("I23" in e for e in errors), errors
        # division by zero is an ERROR, never a silent skip
        errors, _ = lint(tmp, [with_acceptance("count: 1/0 = 7")])
        assert any("I23" in e and "zero" in e for e in errors), errors
        # `1e3/2 = 999` must not match as `3/2 = 999` mid-number — and it is prose here, unjudged
        assert lint(tmp, [with_acceptance("scale 1e3/2 = 999 is shorthand")])[0] == []


OUTPUT_OK = ('output: {physical_name: pdl1_tps, target_published_name: PDL1_TPS, '
             'name_status: aligned, type: double, nullable: true, codes: n/a, role: published}')


def _with_output(cell):
    return one().replace(OUTPUT_OK, cell)


def test_kv_reads_a_body_that_still_carries_its_braces_and_is_truncated():
    """A REGRESSION THIS FILE DID NOT CATCH THE FIRST TIME, and the shape that got past it.

    `_kv` was a brace-agnostic regex whose leading guard admitted a match straight after `{` — and
    the depth-aware parser that replaced it assumed the body was the INSIDE of a map. It is not
    always: `rule_review.chain()` hands over

        {requirement: approved, source_mapping: proposed, dictionary_check: not_run,

    with the opening brace kept and the map cut off at the first line. The parser went to depth 1
    on that brace, found nothing at top level, and returned None — so every consumer read an
    APPROVED record as unstated. Measured: `semantic_export` reported
    `exported=0, concepts=0, withheld={'(unstated)': 1}` and eleven of its tests failed.

    Every lint test passed throughout, because they all build a record and read it back through
    `_inline`, which strips the braces. Only a caller that does its own extraction sees this — and
    the only reason it was found is that the CI Windows lane was replicated locally.
    """
    wrapped = "{requirement: approved, source_mapping: proposed, dictionary_check: not_run,"
    assert contract_lint._kv(wrapped, "requirement") == "approved", "the leading brace hid the field"
    assert contract_lint.requirement(wrapped) == "approved"
    assert contract_lint._kv(wrapped, "source_mapping") == "proposed"

    closed = "{requirement: approved, validation: not_run}"
    assert contract_lint._kv(closed, "validation") == "not_run", "a closed wrapper broke it"

    bare = "requirement: approved, validation: not_run"
    assert contract_lint._kv(bare, "requirement") == "approved", "the unwrapped form regressed"

    # ...and stripping happens in _kv ONLY. I20 judges whether a map is well formed, so it must
    # still SEE the braces; if the strip leaked into _inline_items, balance checking would stop
    # working and an unterminated map would pass.
    assert contract_lint._inline_items("{a: 1")[1] == 1,         "_inline_items stopped counting an unclosed brace — I20's balance check is now blind"
    assert contract_lint._inline_items("a: 1")[1] == 0


def test_a_citation_span_is_judged_before_it_is_built():
    """A LINT THAT HANGS IS A GATE THAT NEVER ANSWERS.

    `SPEC_REF_RE`'s row group has no width, so `spec_ref_rows` built whatever a citation asked for.
    Measured on the committed expander: `clinical:1-1000000` materialises a million tuples in ~4s
    at ~146 MB, and `clinical:1-99999999` never returned at all (killed at 120s). One extra digit
    in a hand-typed range turns a one-second lint into a multi-gigabyte hang — and the pack that
    contains the typo is a pack the lint was about to fail anyway.

    THE CAP IS NOT A LIMIT ON LEGITIMATE CITATION. The widest specification in this repository is
    200 rows, the highest row any committed pack cites is 97, and no committed pack uses a range
    citation at all. 1000 is five times the largest spec: past it, a range is a typo.

    REFUSED THE WAY EVERY OTHER UNPARSEABLE REF IS — `()`, which all five importers already read as
    "not a citation", so the pack fails CLOSED: I8 raises, the digest is None, and contract_binding
    gains no entry so the row reads as bound by nothing.
    """
    dom = "clinical"
    assert len(contract_lint.spec_ref_rows(f"{dom}:17")) == 1
    assert len(contract_lint.spec_ref_rows(f"{dom}:17-46")) == 30, "a real 30-row family citation"
    n = contract_lint.MAX_SPEC_REF_SPAN
    assert len(contract_lint.spec_ref_rows(f"{dom}:1-{n}")) == n, "the cap itself must be allowed"
    assert contract_lint.spec_ref_rows(f"{dom}:1-{n + 1}") == (), "one past the cap is refused"
    assert contract_lint.spec_ref_rows(f"{dom}:1-99999999") == (), "the hang case is refused"
    assert contract_lint.spec_ref_rows(f"{dom}:46-17") == (), (
        "a descending range cites no rows and must not read as a deliberate empty citation")

    # ...and it must be FAST, which is the whole point: the old expander never returned here.
    import time as _t
    start = _t.time()
    contract_lint.spec_ref_rows(f"{dom}:1-99999999")
    assert _t.time() - start < 1.0, "the refusal must not itself build the range"


def test_a_pipeline_payload_that_parses_but_has_the_wrong_shape_is_refused():
    """THE FAIL-OPEN THAT TURNED OFF THE INVENTION GUARD.

    `unsettled_rows` read `payload["findings"]` and, for a bare list, the list itself. Both `[]`
    and `{}` are valid JSON — so a lint.json of the wrong shape yielded ZERO unsettled rows, and
    I17 is consumed as `if unsettled and ...`. Empty means falsy means the check does not run. I17
    is the ONLY invariant that can catch an INVENTED value: a fabricated `age >= 18` is
    well-formed, complete, correctly typed and properly cited — every structural check passes, it
    is simply not what the specification says. So a malformed sidecar silently disabled the one
    guard that matters most where review is thinnest, and the pack printed a clean pass.

    An earlier reading of this called it "malformed JSON raises instead of failing closed".
    Raising IS fail-closed — ugly, but exit 1 and no gate passes. The dangerous case is the file
    that PARSES, has the wrong shape, and is believed.

    KEYS ARE REQUIRED, VALUES ARE NOT: a specification with no deterministic findings is a good
    outcome, and `{"findings": [], "applicability": {...}}` must still pass. That case is asserted
    here too, because a guard that refused it would be worse than the hole it closes.
    """
    import json as _json
    with tempfile.TemporaryDirectory() as tmp:
        product = build_product(tmp, [one()])
        out = Path(product) / "spec_pipeline" / "out" / "lint.json"
        good = out.read_text(encoding="utf-8")

        for label, body in (("a bare list", "[]"),
                            ("an empty object", "{}"),
                            ("no findings key", _json.dumps({"applicability": {}})),
                            ("truncated json", '{"findings": ['),
                            ("a json null", "null")):
            out.write_text(body, encoding="utf-8")
            errs, _n = contract_lint.run(product)
            assert any("lint.json" in e for e in errs), (label, errs)

        # ...and the legitimate clean file is NOT refused.
        out.write_text(_json.dumps({"findings": [], "applicability": {"reasons": []}}),
                       encoding="utf-8")
        errs, _n = contract_lint.run(product)
        refused = [e for e in errs if "is not readable JSON" in e or "carries no " in e
                   or ", not an object carrying" in e]
        assert not refused, ("a specification with zero findings was refused", refused)

        out.write_text(good, encoding="utf-8")


def test_i20_a_field_nested_inside_another_map_does_not_answer_it():
    """I20 COUNTED BRACES; it did not read structure — and I20 had NO test anywhere, which is how
    that survived. Its own docstring records the historical defect hitting 77 records on
    prostate/202606 and 34 on 202607, and the invariant exists because "every other check here
    finds a field by scanning for its token", so a field that is structurally inside another map
    can still answer all nineteen of them.

    Counting braces catches only the sub-case where the drafter ALSO dropped a `}`. Close the
    brace and the same defect is invisible: `codes: {Present: "", role: published}` puts `role`
    inside `codes`, the cell balances perfectly, and `output.role` reads `published` from a record
    that does not state it at top level. Asked structurally now.
    """
    with tempfile.TemporaryDirectory() as tmp:
        nested = ('output: {physical_name: pdl1_tps, target_published_name: PDL1_TPS, '
                  'name_status: aligned, type: double, nullable: true, '
                  'codes: {Present: "1", role: published}}')
        errors, _ = lint(tmp, [_with_output(nested)])
        assert any("I20" in e and "role" in e for e in errors), \
            ("a role nested inside codes was accepted as the top-level answer", errors)
        # the control: the same record with role at top level is clean
        assert lint(tmp, [one()])[0] == [], "the well-formed control record was failed"


def test_i20_one_axis_may_not_be_answered_twice_in_one_cell():
    """Every reader here takes the FIRST match, so a second answer is in the file and not in the
    contract — and the two can disagree. The external review claimed duplicates already errored;
    measured against the pristine lint, they did not."""
    with tempfile.TemporaryDirectory() as tmp:
        dup = ('output: {physical_name: pdl1_tps, target_published_name: PDL1_TPS, '
               'name_status: aligned, type: double, nullable: true, codes: n/a, '
               'role: published, role: excluded}')
        errors, _ = lint(tmp, [_with_output(dup)])
        assert any("I20" in e and "role" in e and "2 times" in e for e in errors), \
            ("one axis got two answers and the lint took the first silently", errors)


def test_i20_still_refuses_a_map_that_does_not_close_or_closes_first():
    """The original brace count caught the unterminated map; that must not regress. It did NOT
    catch a cell that balances by COUNT while closing before it opens, which is equally not a
    structure."""
    with tempfile.TemporaryDirectory() as tmp:
        unterminated = ('output: {physical_name: pdl1_tps, target_published_name: PDL1_TPS, '
                        'name_status: aligned, type: double, nullable: true, codes: {a: b, '
                        'role: published}')
        errors, _ = lint(tmp, [_with_output(unterminated)])
        assert any("I20" in e for e in errors), ("an unterminated map passed", errors)
        inverted = ('output: {physical_name: pdl1_tps, target_published_name: PDL1_TPS, '
                    'name_status: aligned, type: double, nullable: true, codes: a} b{, '
                    'role: published}')
        errors, _ = lint(tmp, [_with_output(inverted)])
        assert any("I20" in e for e in errors), \
            ("`a} b{` balances by count and is still structurally wrong", errors)


def test_i20_does_not_fail_the_shapes_real_records_actually_carry():
    """THE OVERFIRE GUARD, and it is not hypothetical: the first version of this patch failed 109
    committed records because it asked the nested-key question of `source` too. `source.inputs` is
    keyed by the VENDOR's own column roles — `inputs: {lab: {name: ..., value: testresultcleaned}}`
    — where `value` is a lab column and not the `source.value` a constant record carries. Judging
    it failed a third of prostate/202606 for being correct.

    Also pinned: a comma inside a quoted prose value is not a key, and eight committed records
    carry an opening quote that never closes, so the parser must stay quote-blind."""
    with tempfile.TemporaryDirectory() as tmp:
        vendor = ('source: {kind: vendor, logical_table: labs, physical_stem: t_lab, '
                  'inputs: {lab: {name: pdl1, value: testresultcleaned}}}')
        assert lint(tmp, [one().replace(
            'source: {logical_table: biomarkers, physical_stem: t_enh_nsclc_biomarker, '
            'columns: {value: pdl1percent}}', vendor)])[0] == [], \
            "a vendor inputs map keyed by column roles was judged as a schema violation"
        prose = ('output: {physical_name: pdl1_tps, target_published_name: PDL1_TPS, '
                 'name_status: aligned, type: double, nullable: true, '
                 'codes: "1=<100,000/uL;2=>150,000/uL", role: published}')
        assert lint(tmp, [_with_output(prose)])[0] == [], \
            "a comma inside a quoted prose value was read as a key"
        unclosed_quote = ('output: {physical_name: pdl1_tps, target_published_name: PDL1_TPS, '
                          'name_status: aligned, type: double, nullable: true, '
                          'codes: {"0..4}, role: published}')
        assert lint(tmp, [_with_output(unclosed_quote)])[0] == [], \
            "an unclosed quote made the parser swallow the rest of a correct cell"


def test_i23_a_thousands_separator_is_part_of_the_number():
    """MEASURED on the tracked file, both faces of one bug.

    The lookbehind omitted `,`, so a match could START just after a comma and the check judged a
    different sum than the one written:
        `1,000 / 2 = 500`   -> ('000','2','500')   a CORRECT example was FAILED
        `1,234/2 = 617`     -> ('234','2','617')   a CORRECT example was FAILED
        `10,000/2 = 0`      -> ('000','2','0')     a WRONG example PASSED - 000/2 is 0, so it agreed
        `1/2 = 1,000`       -> ('1','2','1')       a WRONG example PASSED - the result was truncated
    An external review reported only the false alarm. The fail-open is the same defect's other
    face and the more serious one: `10,000/2 = 0` is exactly the cell I23 exists to catch.
    """
    def with_acceptance(acc):
        return one().replace('acceptance: "pdl1percent=55 at index-3d -> PDL1_TPS=55"',
                             f'acceptance: "{acc}"')
    with tempfile.TemporaryDirectory() as tmp:
        # correct examples must NOT be failed
        assert lint(tmp, [with_acceptance("1,000 / 2 = 500")])[0] == [], "false alarm on 1,000/2"
        assert lint(tmp, [with_acceptance("10,000/2 = 5,000")])[0] == [], "separators both sides"
        assert lint(tmp, [with_acceptance("1,234/2 = 617")])[0] == [], "four-digit numerator"
        # wrong examples must still be caught - the fail-open half
        errors, _ = lint(tmp, [with_acceptance("10,000/2 = 0")])
        assert any("I23" in e for e in errors), ("10,000/2 = 0 passed - read as 000/2", errors)
        errors, _ = lint(tmp, [with_acceptance("1/2 = 1,000")])
        assert any("I23" in e for e in errors), ("1/2 = 1,000 passed - result truncated", errors)
        # a comma LIST is not arithmetic and must stay unjudged
        assert lint(tmp, [with_acceptance("a list 1,2,3/3 = 2")])[0] == [], "a list was judged"
        # a real committed shape: platelet counts carry separators and no division-with-equals
        assert lint(tmp, [with_acceptance("platelets <150,000/uL at baseline")])[0] == []


def test_i23_wide_precision_is_reported_and_never_crashes_the_lint():
    """A LINT THAT DIES IS WORSE THAN ONE THAT MISSES, because its exit code says it looked.

    MEASURED on the tracked file: decimal's default 28-digit context made `quantize` raise
    InvalidOperation on an ordinary acceptance cell - a 30-digit numerator, or `1/3` written to 30
    decimals. The I23 block sits inside NO try/except in `run()`, so the exception left the whole
    lint: it then reported nothing about any invariant on any record and exited 1, which is
    indistinguishable by exit code from an ordinary violation.

    The context is now sized to the example. That is not tolerance - the comparison stays exact at
    the example's own precision, so `1/3 = 0.333...` (30 threes) is CORRECT and passes while the
    same value with a 9 in the last place is WRONG and fails. Anything still beyond decimal becomes
    a reported violation, never a crash and never a silent skip.
    """
    def with_acceptance(acc):
        return one().replace('acceptance: "pdl1percent=55 at index-3d -> PDL1_TPS=55"',
                             f'acceptance: "{acc}"')
    with tempfile.TemporaryDirectory() as tmp:
        # each of these RAISED before; none may raise now
        errors, _ = lint(tmp, [with_acceptance("%s/3 = 1" % ("9" * 30))])
        assert any("I23" in e for e in errors), ("a 30-digit wrong example", errors)
        assert lint(tmp, [with_acceptance("1/3 = 0.%s" % ("3" * 30))])[0] == [], \
            "1/3 to 30 decimals is correct and must pass, not crash and not fail"
        errors, _ = lint(tmp, [with_acceptance("1/3 = 0.%s9" % ("3" * 29))])
        assert any("I23" in e for e in errors), ("a 9 in the last place is wrong", errors)
        # and the ordinary committed cell is unaffected
        assert lint(tmp, [with_acceptance("183/30.4375 = 6.01")])[0] == []


def test_i24_self_dependencies_and_cycles_are_refused():
    """A record depending on itself RESOLVES and still describes nothing; two records depending
    on each other describe no build order while each edge looks fine alone. Both from the same
    external probe set as the I23 boundaries."""
    with tempfile.TemporaryDirectory() as tmp:
        def rec(vid, deps):
            return (one(vid=vid).replace("depends_on: [engine:index]", f"depends_on: [{deps}]")
.replace("physical_name: pdl1_tps", f"physical_name: {vid.lower()}")
.replace("target_published_name: PDL1_TPS", f"target_published_name: {vid}"))
        # ids under the fixture's one row: the row's own variable and its scaffold-style dedupe
        # suffix, so I25 (a record cites the row of its own variable) has nothing to say here
        errors, _ = lint(tmp, [rec("PDL1_TPS__2", "PDL1_TPS__2")])
        assert any("I24" in e and "itself" in e for e in errors), errors
        errors, _ = lint(tmp, [rec("PDL1_TPS__2", "PDL1_TPS"), rec("PDL1_TPS", "PDL1_TPS__2")])
        assert any("I24" in e and "cycle" in e for e in errors), errors
        assert lint(tmp, [rec("PDL1_TPS__2", "PDL1_TPS"), rec("PDL1_TPS", "none")])[0] == [] # a chain is fine


def test_i24_every_depends_on_entry_resolves():
    """`depends_on` is a cross-reference; a name resolving to nothing is prose in a field's
    clothes, and a typo there linted clean forever. Four legal targets: another record, a spec
    variable, `engine:<stage>`, or `none`."""
    def with_deps(deps):
        return one().replace("depends_on: [engine:index]", f"depends_on: [{deps}]")
    with tempfile.TemporaryDirectory() as tmp:
        errors, _ = lint(tmp, [with_deps("SOMETHING_I_COINED")])
        assert any("I24" in e and "SOMETHING_I_COINED" in e for e in errors), errors
        errors, _ = lint(tmp, [with_deps("engine:not_a_stage")])
        assert any("I24" in e and "names no engine stage" in e for e in errors), errors
        assert lint(tmp, [with_deps("engine:lot")])[0] == []
        assert lint(tmp, [with_deps("none")])[0] == []
        # a DIFFERENT record citing a variable the extraction names resolves (same-name would be
        # the self-dependency I24 now refuses)
        other = one(vid="OTHER").replace("depends_on: [engine:index]", "depends_on: [PDL1_TPS]")
        assert lint(tmp, [other])[0] == []


def test_a_short_decision_id_reads_the_same_to_every_reader():
    """Three readers of "what is a decision id" disagreed below five characters.

    `decision_ids` (which I2 checks citations against) carried `len(c) >= 5`; `decision_rows` and
    `decision_register_errors` had dropped theirs. So on `D-1` the lint CONTRADICTED ITSELF on one
    row: I2 called the decision undefined while I11 — reading the same table through decision_rows —
    saw it OPEN and demanded the record be decision_required. Latent only because today's packs spell
    ids long; the first tumour numbering decisions `D-1, D-2` hits it immediately.
    """
    with tempfile.TemporaryDirectory() as tmp:
        product = build_product(tmp, [one(req="decision_required", decs="D-1")])
        Path(product, "handoff", "DECISIONS.md").write_text(
            "| ID | Question | Owner | Status |\n|---|---|---|---|\n"
            "| D-1 | short id | DataExpert | OPEN |\n", encoding="utf-8")
        errors, _ = contract_lint.run(product)
        assert not [e for e in errors if "I2 decision_id" in e], \
            f"I2 called a decision the register plainly defines undefined: {errors}"
        assert not [e for e in errors if "I11" in e], \
            f"I11 disagreed with I2 about the same row: {errors}"

        # all three readers see it
        text = contract_lint.read(str(Path(product, "handoff", "DECISIONS.md")))
        assert "D-1" in contract_lint.decision_ids(text)
        assert "D-1" in contract_lint.decision_rows(text)
        assert contract_lint.decision_status(text)["D-1"] == "OPEN"


def test_i2_unknown_decision_and_gap_ids():
    with tempfile.TemporaryDirectory() as tmp:
        errors, _ = lint(tmp, [one(decs="NO-SUCH-DECISION", gaps="G-NOPE")])
        assert any("I2 decision_id 'NO-SUCH-DECISION'" in e for e in errors), errors
        assert any("I2 gap_id 'G-NOPE'" in e for e in errors), errors


def test_i8_dangling_spec_ref_and_unknown_domain():
    with tempfile.TemporaryDirectory() as tmp:
        errors, _ = lint(tmp, [one(ref="clinical:99")])
        assert any("I8 spec_ref 'clinical:99'" in e for e in errors), errors
        errors, _ = lint(tmp, [one(ref="biomarkers:3")])
        assert any("names domain 'biomarkers'" in e for e in errors), errors


def test_i9_approved_but_not_derivable_must_name_a_gap_exactly_once():
    """The rule still bites; it just stopped saying so twice.

    I9's trigger was a strict subset of I13's — `not_derivable` is one of the shortfall states — so
    one missing gap_id produced two failures and a reader had to work out they were the same record.
    I13 owns the emission and carries I9's reasoning for the approved case.
    """
    with tempfile.TemporaryDirectory() as tmp:
        errors, _ = lint(tmp, [one(impl="not_derivable")])
        assert len(errors) == 1, f"one defect, one message: {errors}"
        assert "I13" in errors[0] and "I9" in errors[0], errors
        assert lint(tmp, [one(impl="not_derivable", gaps="G-PDL1")])[0] == []

        # a shortfall that is NOT the approved case still gets the plain I13 message
        errors, _ = lint(tmp, [one(req="draft", impl="engine_gap")])
        assert len(errors) == 1 and "I9" not in errors[0], errors


def test_missing_extraction_is_reported_not_silently_skipped():
    """Without the extraction there is nothing to resolve spec_refs against. Passing anyway would make
    I8 quietly vacuous, which is worse than failing."""
    with tempfile.TemporaryDirectory() as tmp:
        product = build_product(tmp, [one()])
        os.remove(os.path.join(product, "spec_pipeline", "out", "extracted.json"))
        errors, _ = contract_lint.run(product)
        assert any("no spec_pipeline/out/extracted.json" in e for e in errors), errors


def test_i17_catches_an_invented_answer_over_an_unsettled_spec_row():
    """The only invariant that can catch a FABRICATED value — every other check passes on one.

    A record reading `derivation: "age >= 18"` over a row whose own text says "no age
    operator/threshold is present in the source documents" is complete, correctly typed, properly
    cited, and its digest matches. I1-I16 have nothing to say about it. It is simply not what the
    specification says, and it will be built.

    That gap is widest exactly where review is thinnest: a cheaper or weaker model drafting hundreds
    of records unattended. `spec_lint` already knows which rows are unsettled, deterministically and
    with no model involved — I17 turns judgment the drafter may not have into a property the lint
    checks.
    """
    with tempfile.TemporaryDirectory() as tmp:
        flags = (("clinical:3", "VERIFY_MARKER"),)

        # The defect: confident, complete, no TODO, no decision, over a flagged row.
        errors, _ = lint(tmp, [one(req="draft", impl="not_implemented")], flags=flags)
        assert any("I17" in e and "VERIFY_MARKER" in e for e in errors), errors

        # Unflagged row of the same shape: silent. I17 must bite on the flag, not on every draft.
        assert not any("I17" in e for e in lint(tmp, [one(req="draft", impl="not_implemented")])[0])

        # Three escapes, each a legitimate state a record can be in over a flagged row.
        todo = one(req="draft", impl="not_implemented").replace(
            'derivation: "try_cast(pdl1percent as double), closest to index"', "derivation: TODO")
        assert not any("I17" in e for e in lint(tmp, [todo], flags=flags)[0]), "still being written"
        assert not any("I17" in e for e in lint(
            tmp, [one(req="decision_required", impl="not_implemented", decs="BIOM-WINDOW")],
            flags=flags)[0]), "honestly blocked on an OPEN decision"
        assert not any("I17" in e for e in lint(
            tmp, [one(decs="FUED-RULE")], flags=flags)[0]), "asked, answered, decision RESOLVED"


def test_i17_covers_a_rule_computing_with_an_undefined_symbol():
    """UNDEFINED_REFERENCE is UNSETTLED: the hole the other four kinds leave open.

    The other four are all VISIBLE damage — a marker, prose, a truncation, a missing else. This one
    is a rule that reads as complete and quietly depends on a symbol the specification never
    defines, so a drafter supplies the meaning and every structural check agrees with them: the
    shape is right, the citation resolves, the digest matches.

    Found by a red-team probe, not hypothetically: a spec used a bare `INDEX_DT` in 43 rules while
    defining only its per-cohort realisations, and a record reading it as "whichever cohort applies"
    passed clean. One decision settles all 43, which is the escape this asserts still works.
    """
    with tempfile.TemporaryDirectory() as tmp:
        flags = (("clinical:3", "UNDEFINED_REFERENCE"),)

        errors, _ = lint(tmp, [one(req="draft", impl="not_implemented")], flags=flags)
        assert any("I17" in e and "UNDEFINED_REFERENCE" in e for e in errors), errors

        # the same escapes as every other unsettled kind — a TODO, or a decision carrying the reading
        todo = one(req="draft", impl="not_implemented").replace(
            'derivation: "try_cast(pdl1percent as double), closest to index"', "derivation: TODO")
        assert not any("I17" in e for e in lint(tmp, [todo], flags=flags)[0])
        assert not any("I17" in e for e in lint(
            tmp, [one(req="decision_required", impl="not_implemented", decs="INDEXDT-READING")],
            flags=flags)[0])


def test_i17_todo_detection_does_not_use_the_naming_helper():
    """`todo_fields()` returns the placeholder ["a field"] when a record has NO TODO — it exists to
    NAME fields for I10's message, not to answer whether any exist. Used as a predicate it is always
    truthy, which silently disabled I17 entirely: the fabricated record passed clean.

    Caught only by building the record the invariant exists to catch and watching it pass, which is
    why this asserts the helper's actual contract rather than trusting its name.
    """
    clean = one()
    assert "TODO" not in clean
    assert contract_lint.todo_fields(clean) == ["a field"], \
        "todo_fields no longer returns its placeholder — re-check every caller using it as a boolean"
    assert not contract_lint.TODO_RE.search(clean), "TODO_RE is the predicate I17 must use"


def test_i17_is_field_specific_a_todo_off_the_requirement_axis_does_not_excuse_invention():
    """A TODO ANYWHERE would satisfy I17, letting a record answer the REQUIREMENT confidently over a
    flagged row and park its only TODO on the naming axis — `output: {physical_name: TODO}`, the spec
    being silent on the PHYSICAL NAME, which is routine and says nothing about whether the RULE is
    settled. The invented `derivation` then sailed through the one check meant to catch it.

    Field-specific now: the excusing TODO must sit on a REQUIREMENT field. This asserts the record
    still CARRIES a TODO — so the old `not TODO_RE.search(block)` predicate was satisfied and skipped
    the check — and that it is caught anyway. Reverting to `not TODO_RE.search(block)` makes this pass,
    which is the bite.
    """
    with tempfile.TemporaryDirectory() as tmp:
        flags = (("clinical:3", "VERIFY_MARKER"),)

        # Confident requirement; the only TODO is on the physical NAME — a real TODO, off the axis.
        naming = one(req="draft", impl="not_implemented").replace(
            "physical_name: pdl1_tps", "physical_name: TODO")
        assert contract_lint.TODO_RE.search(naming), "the fixture must carry a TODO or the bite is empty"
        assert "derivation: TODO" not in naming and "record_selection: TODO" not in naming
        errors, _ = lint(tmp, [naming], flags=flags)
        assert any("I17" in e and "VERIFY_MARKER" in e for e in errors), errors

        # The SAME TODO moved onto a requirement field is the legitimate "still being written" state and
        # passes: the axis is what matters, not that a TODO exists somewhere.
        drafting = one(req="draft", impl="not_implemented").replace(
            'derivation: "try_cast(pdl1percent as double), closest to index"', "derivation: TODO")
        assert not any("I17" in e for e in lint(tmp, [drafting], flags=flags)[0])

        # A TODO on `notes` — a real CANON field, but prose, not the requirement — is the same story.
        prose = one(req="draft", impl="not_implemented").replace(
            "notes: synthetic fixture", "notes: TODO revisit with Science")
        assert any("I17" in e for e in lint(tmp, [prose], flags=flags)[0]), \
            "a TODO on a non-requirement field must not excuse the invented requirement"


def test_i17_acceptance_todo_does_not_excuse_an_invented_requirement():
    """`acceptance` is the worked example, not the rule's answer, and it is TODO on every fresh
    scaffold. So a record could answer `required_rule`, `window` and `derivation` confidently over an
    UNSETTLED row and leave only `acceptance: TODO`, and the first field-specific I17 still passed it —
    the same off-axis hole one level in. This asserts that record is now caught, and that a TODO moved
    onto a genuine requirement field still passes. Reverting `acceptance` into REQUIREMENT_FIELDS makes
    the first assertion fail, which is the bite.
    """
    with tempfile.TemporaryDirectory() as tmp:
        flags = (("clinical:3", "VERIFY_MARKER"),)
        example = one(req="draft", impl="not_implemented")
        acc = example.replace('acceptance: "pdl1percent=55 at index-3d -> PDL1_TPS=55"', "acceptance: TODO")
        assert "acceptance: TODO" in acc and "derivation: TODO" not in acc
        assert any("I17" in e and "VERIFY_MARKER" in e for e in lint(tmp, [acc], flags=flags)[0]), \
            "a TODO only on the worked example must not excuse the confident requirement"
        # the same record with the TODO on a real requirement field (missing) is the legitimate state
        drafting = example.replace("missing: {no_record: null, present_null: null}", "missing: TODO")
        assert not any("I17" in e for e in lint(tmp, [drafting], flags=flags)[0])


def test_requirement_fields_partition_canon_so_a_new_field_must_be_classified():
    """`REQUIREMENT_FIELDS` decides which TODO excuses an UNSETTLED row under I17. A field added to
    CANON and left unclassified would silently default to the lenient side — a TODO on it would stop
    counting, or an invented answer there would go uncaught — so the classification is spelled out
    here and adding a CANON field must break this test until a human places the new field on purpose."""
    requirement = {"required_rule", "grain", "anchor", "window", "record_selection", "tie_break",
                   "derivation", "cohort_applicability", "missing", "units"}
    # `acceptance` sits on the non-requirement side on purpose: it is the worked example, not the
    # rule's answer, and it is TODO on every fresh scaffold — so it must not excuse a confident answer
    # over an UNSETTLED row (see the constant's comment in contract_lint).
    non_requirement = {"spec_refs", "spec_digest", "source", "depends_on", "output", "status",
                       "decision_ids", "gap_ids", "publish", "notes", "acceptance"}
    assert contract_lint.REQUIREMENT_FIELDS == requirement
    assert contract_lint.NON_REQUIREMENT_FIELDS == non_requirement
    assert not (requirement & non_requirement), "a field cannot be both"
    assert requirement | non_requirement == set(contract_lint.CANON), \
        "a CANON field is unclassified — place it in REQUIREMENT_FIELDS or not, on purpose"


def test_i17_fails_closed_when_the_pipeline_output_is_half_written():
    """lint.json ships from the same run as extracted.json. One without the other is a broken out/,
    and skipping the invention guard there would turn it off exactly when the evidence directory is
    already known to be untrustworthy."""
    with tempfile.TemporaryDirectory() as tmp:
        product = build_product(tmp, [one()])
        os.remove(os.path.join(product, "spec_pipeline", "out", "lint.json"))
        errors, _ = contract_lint.run(product)
        assert any("I17 no spec_pipeline/out/lint.json" in e for e in errors), errors


def test_floors_catch_a_parser_regression():
    with tempfile.TemporaryDirectory() as tmp:
        errors, _ = contract_lint.run(build_product(tmp, [one()]), {"records": 40})
        assert any("floor 40" in e for e in errors), errors


def test_a_pack_is_judged_by_the_floors_it_declares_not_the_cli_default():
    """One pack, one standard — whether the CLI or the pack's own test asks.

    The floors are declared in `handoff/tests/test_functional_contract.py`, which the wrapper passed
    to run() and the CLI did not, so a pack's floor was two facts that disagreed. It failed BOTH ways
    at once:

      * `contract_lint.py fixtures/oncology/oc/202606` reported `parsed only 0 gap IDs (floor 1)` on a
        pack declaring `gaps: 0`, whose ENGINE_GAPS.md says in its first line that it is empty because
        no contract is approved and no build binds to one. A floor a pack CANNOT meet is the thing the
        floors' own comment warns produces a floor people learn to ignore.
      * the same CLI on prostate 202606 applied `records: 1` where the pack declares `40`, so a parser
        regression dropping 39 records passed silently. That half is the dangerous one.
    """
    with tempfile.TemporaryDirectory() as tmp:
        product = build_product(tmp, [one()])
        tests = os.path.join(product, "handoff", "tests")
        os.makedirs(tests, exist_ok=True)
        wrapper = os.path.join(tests, "test_functional_contract.py")

        # No declaration: DEFAULT_FLOORS, which is the only honest answer for a pack that states none.
        assert contract_lint.pack_floors(product) is None
        assert not any("floor 40" in e for e in contract_lint.run(product)[0])

        # Declared: the CLI path must pick it up WITHOUT being handed it.
        with open(wrapper, "w", encoding="utf-8") as fh:
            fh.write('FLOORS = {"decisions": 0, "gaps": 0, "records": 40}\n')
        assert contract_lint.pack_floors(product) == {"decisions": 0, "gaps": 0, "records": 40}
        assert any("floor 40" in e for e in contract_lint.run(product)[0]), \
            "run() ignored the pack's declared floors — the CLI and the pack's own test judge it by " \
            "two different standards"

        # A declared ZERO must survive the merge with DEFAULT_FLOORS. `dict(DEFAULT, **declared)` is
        # right; anything treating 0 as absent restores the floor the pack explicitly lowered, which
        # is exactly the oc/202606 gap-ID failure. Asserted against an EMPTY gap index — the fixture
        # ships one gap, so against that this passed whether or not the zero was honoured.
        empty_gaps = build_product(tmp, [one()])
        with open(os.path.join(empty_gaps, "handoff", "ENGINE_GAPS.md"), "w", encoding="utf-8") as fh:
            fh.write("# Engine gaps\n\nEmpty: no contract approved, no build binds to one.\n\n"
                     "| Gap | What is not met |\n|---|---|\n")
        assert any("gap ID" in e for e in contract_lint.run(empty_gaps)[0]), \
            "an empty gap index with NO declaration must still trip the default floor of 1"
        egtests = os.path.join(empty_gaps, "handoff", "tests")
        os.makedirs(egtests, exist_ok=True)
        with open(os.path.join(egtests, "test_functional_contract.py"), "w", encoding="utf-8") as fh:
            fh.write('FLOORS = {"decisions": 0, "gaps": 0, "records": 1}\n')
        assert not any("gap ID" in e for e in contract_lint.run(empty_gaps)[0]), \
            "a declared floor of 0 was overridden by the default of 1 — this is the oc/202606 failure"

        # Explicit floors still win, so the wrapper passing its own FLOORS is unchanged.
        assert not any("floor 40" in e for e in contract_lint.run(product, {"records": 1})[0])

        # Unparseable declaration falls back rather than crashing the lint on every pack.
        with open(wrapper, "w", encoding="utf-8") as fh:
            fh.write("FLOORS = {**BASE, 'records': 40}\n")
        assert contract_lint.pack_floors(product) is None


def test_every_pack_the_cli_and_its_wrapper_agree():
    """Real-data half: on every pack that ships a wrapper, both entry points must reach the same
    verdict. The unit test proves the mechanism; this proves it was actually applied."""
    import glob
    import subprocess

    packs = sorted(os.path.dirname(os.path.dirname(os.path.dirname(p)))
                   for p in glob.glob(os.path.join(str(REPO), "products", "*", "*", "*", "handoff",
                                                   "tests", "test_functional_contract.py"))
                   + glob.glob(os.path.join(str(REPO), "fixtures", "*", "*", "*", "handoff",
                                            "tests", "test_functional_contract.py")))
    assert packs, "no packs with a contract wrapper discovered — this would pass by sweeping nothing"
    child_env = dict(os.environ, PYTHONUTF8="1", PYTHONIOENCODING="utf-8")
    for product in packs:
        declared = contract_lint.pack_floors(product)
        assert declared, f"{product}: ships a wrapper whose FLOORS this cannot read"
        cli = subprocess.run([sys.executable, os.path.join(str(REPO), "platform", "tools", "contract_lint.py"),
                              product], capture_output=True, text=True, encoding="utf-8", env=child_env, timeout=120)
        wrapper = subprocess.run([sys.executable, os.path.join(product, "handoff", "tests",
                                                               "test_functional_contract.py")],
                                 capture_output=True, text=True, encoding="utf-8", env=child_env, timeout=120)
        assert isinstance(cli.stdout, str) and cli.stdout.strip(), "CLI must produce decoded diagnostic output"
        assert isinstance(wrapper.stdout, str) and wrapper.stdout.strip(), "Wrapper must produce decoded diagnostic output"
        assert cli.returncode in {0, 1} and wrapper.returncode in {0, 1}, "Both entry points must complete a lint verdict"
        assert cli.returncode == wrapper.returncode, (
            f"{os.path.relpath(product, str(REPO))}: CLI exits {cli.returncode}, its own test exits "
            f"{wrapper.returncode} — two standards for one pack.\nCLI said:\n{cli.stdout}")


def test_i10_approved_record_may_not_hold_todo():
    """The scaffold marks every judgment field TODO. Flipping only the status would approve a
    requirement nobody has written."""
    with tempfile.TemporaryDirectory() as tmp:
        rec = one().replace('derivation: "try_cast(pdl1percent as double), closest to index"',
                            "derivation: TODO")
        errors, _ = lint(tmp, [rec])
        assert any("I10 requirement:approved but derivation still TODO" in e for e in errors), errors
        # a DRAFT record is allowed to carry TODO — that is what a scaffold is
        assert not any("I10" in e for e in lint(tmp, [rec.replace("requirement: approved",
                                                                  "requirement: draft")])[0])


def test_i8_rejects_prose_and_validates_a_whole_range():
    with tempfile.TemporaryDirectory() as tmp:
        errors, _ = lint(tmp, [one(ref="treatment (engine addition)")])
        assert any("is not a `<domain>:<row>` citation" in e for e in errors), errors
        # a range whose ENDS exist but whose middle does not must fail, not pass on the endpoints
        errors, _ = lint(tmp, [one(ref="clinical:3-6")],
                         spec_rows=(("clinical", 3), ("clinical", 6)))
        assert any("row(s) 4, 5" in e for e in errors), errors


def test_a_variable_with_no_spec_row_must_name_its_governance():
    """An engine/config addition is allowed, but never silently: something must record why it exists."""
    with tempfile.TemporaryDirectory() as tmp:
        errors, _ = lint(tmp, [one(ref="none", decs="NAME-ALIGN")])
        assert any("must name the decision or gap" in e for e in errors), errors
        # NAME-ALIGN governs the OUTPUT; a requirement-level decision or a gap is what counts
        # `decision_required`, not `draft`: I11 holds that a record citing an OPEN requirement-level
        # decision IS blocked, and the fixture said draft.
        assert lint(tmp, [one(ref="none", req="decision_required", decs="BIOM-WINDOW")])[0] == []
        assert lint(tmp, [one(ref="none", gaps="G-PDL1")])[0] == []


def test_both_the_coarse_and_the_gate3_status_shapes_are_accepted():
    """WORKFLOW.md lets a product keep the coarse `source` axis until Gate 3. If the lint only accepts
    the coarse form, a record written exactly as the workflow instructs fails."""
    gate3 = one().replace(
        "status: {requirement: approved, source: unverified, implementation: implemented, validation: not_run}",
        "status: {requirement: approved, source_mapping: human_confirmed, dictionary_check: passed, "
        "live_schema_check: passed, data_profile_check: accepted, implementation: implemented, "
        "validation: passed_test}")
    with tempfile.TemporaryDirectory() as tmp:
        assert lint(tmp, [one()])[0] == [] # coarse
        assert lint(tmp, [gate3])[0] == [] # fine
        half = gate3.replace("live_schema_check: passed, ", "") # neither shape, completely
        assert any("either the coarse `source` axis or all four" in e for e in lint(tmp, [half])[0])



def test_i11_closes_the_decision_loop():
    """The half that matters: a decision moves to RESOLVED and the records blocked on it must be
    named, or the answer is never written into them and nobody finds out."""
    with tempfile.TemporaryDirectory() as tmp:
        product = build_product(tmp, [one(req="decision_required", decs="BIOM-WINDOW")])
        dec = Path(product) / "handoff" / "DECISIONS.md"
        assert contract_lint.run(product)[0] == [] # blocked on an OPEN decision: fine
        dec.write_text(dec.read_text(encoding="utf-8").replace("| BIOM-WINDOW | window | Science | OPEN |",
                                               "| BIOM-WINDOW | window | Science | RESOLVED |"), encoding="utf-8")
        errors, _ = contract_lint.run(product)
        assert any("BIOM-WINDOW" in e and "RESOLVED" in e for e in errors), errors


def test_i11_a_record_blocked_on_nothing_is_caught():
    """`decision_required` with no decision cited records no reason to be blocked. This found a real
    drafting error in prostate 202607 the first time it ran."""
    with tempfile.TemporaryDirectory() as tmp:
        errors, _ = lint(tmp, [one(req="decision_required")])
        assert any("nothing records what it is blocked on" in e for e in errors), errors


def test_i11_ignores_output_only_decisions():
    """NAME-ALIGN and CODE-ALIGN govern the OUTPUT, not the requirement — they never block a record."""
    with tempfile.TemporaryDirectory() as tmp:
        assert lint(tmp, [one(req="approved", decs="NAME-ALIGN")])[0] == []
        errors, _ = lint(tmp, [one(req="decision_required", decs="NAME-ALIGN")])
        assert any("I11" in e for e in errors), "NAME-ALIGN alone does not justify decision_required"



def test_i12_validation_cannot_outrun_implementation_or_requirement():
    """Every axis can be individually legal while the combination is impossible. `requirement: draft`
    with `validation: passed_live` claims live evidence for a rule nobody approved."""
    with tempfile.TemporaryDirectory() as tmp:
        rec = one(impl="not_implemented").replace("validation: not_run", "validation: passed_live")
        errors, _ = lint(tmp, [rec])
        assert any("nothing was built to validate" in e for e in errors), errors
        rec = one(req="draft").replace("validation: not_run", "validation: passed_test")
        errors, _ = lint(tmp, [rec])
        assert any("requirement:draft" in e and "I12" in e for e in errors), errors
        # passed_live implies the source was confirmed; `unverified` contradicts it
        rec = one().replace("validation: not_run", "validation: passed_live")
        errors, _ = lint(tmp, [rec])
        assert any("source:unverified" in e for e in errors), errors


def test_i12_allows_a_consistent_ladder():
    with tempfile.TemporaryDirectory() as tmp:
        rec = one().replace("source: unverified", "source: verified").replace(
            "validation: not_run", "validation: passed_live")
        assert lint(tmp, [rec])[0] == []


def test_i13_a_shortfall_must_name_its_gap():
    """config_gap / engine_gap / partial / not_derivable all mean the build falls short. Without a
    gap_id the shortfall is real and tracked nowhere — it caught two live records."""
    with tempfile.TemporaryDirectory() as tmp:
        for impl in ("config_gap", "engine_gap", "partial", "not_derivable"):
            errors, _ = lint(tmp, [one(req="draft", impl=impl)])
            assert any("I13" in e and impl in e for e in errors), (impl, errors)
        assert not any("I13" in e for e in lint(tmp, [one(req="draft", impl="partial",
                                                          gaps="G-PDL1")])[0])
        assert not any("I13" in e for e in lint(tmp, [one(impl="implemented")])[0])




def test_i14_a_decision_blocked_record_may_not_claim_to_be_built_at_contract_approved():
    """The compensating control for what Gate 2 permits. WORKFLOW.md line 173 closes Gate 2 on
    "approved OR explicitly blocked by a named decision"; line 262 is what makes the block safe —
    "blocked or decision-gated records are not implemented". Both halves are needed: without this,
    a pack exits Gate 2 with a record saying its rule is unanswered AND that it is built.

    It is scoped to the approval claim on purpose. Before then a build standing ahead of an open
    decision is ordinary development, which is why the same fixture passes with no MATURITY.yaml.
    """
    blocked = one(req="decision_required", impl="implemented", decs="BIOM-WINDOW")
    with tempfile.TemporaryDirectory() as tmp:
        assert lint(tmp, [blocked])[0] == [], "while the contract is being written this is legal"

        product = build_product(tmp, [blocked])
        (Path(product) / "handoff" / "MATURITY.yaml").write_text(
            "contract: approved\nconfiguration: not_started\n", encoding="utf-8")
        errors, _ = contract_lint.run(product)
        assert [e for e in errors if "I14" in e and "implementation:implemented" in e], errors

        # `partial` too — it still claims part of the build exists for a rule nobody has settled.
        for impl, ok in (("partial", False), ("not_implemented", True), ("engine_gap", True)):
            rec = one(req="decision_required", impl=impl, decs="BIOM-WINDOW",
                      gaps="G-PDL1" if impl in contract_lint.IMPL_SHORTFALL else "")
            p = build_product(tmp, [rec])
            (Path(p) / "handoff" / "MATURITY.yaml").write_text(
                "contract: approved\nconfiguration: not_started\n", encoding="utf-8")
            hits = [e for e in contract_lint.run(p)[0] if "I14" in e and "implementation:" in e]
            assert bool(hits) != ok, f"{impl}: {contract_lint.run(p)[0]}"


def test_i16_a_record_may_not_span_several_spec_rows_at_contract_approved():
    """A family record is a LIST, and a list is where the next tumour's new member goes missing —
    inside the record's prose and inside a config list item, with every check still green. Signing is
    where that becomes a liability, because the signed contract is what the next refresh is diffed
    against, so that is where this bites (WORKFLOW.md section 8).

    Scoped to `coverage_complete` and above on purpose: the same grouped record passes at
    `contract: draft`, because grouping while the contract is being written is ordinary work. It was
    first written to bite only at `approved`, where it bit nothing — no pack claims that level.
    """
    rows = (("clinical", 3), ("clinical", 4), ("clinical", 5), ("demographics", 9))
    span = one(vid="LAB", ref="clinical:3-5")
    with tempfile.TemporaryDirectory() as tmp:
        assert [e for e in lint(tmp, [span], spec_rows=rows)[0] if "I16" in e] == [], \
            "with no MATURITY.yaml the pack is still drafting — a family record is legal"

        drafting = build_product(tmp, [span], spec_rows=rows)
        (Path(drafting) / "handoff" / "MATURITY.yaml").write_text(
            "contract: draft\nconfiguration: not_started\n", encoding="utf-8")
        assert [e for e in contract_lint.run(drafting)[0] if "I16" in e] == [], \
            "contract: draft is still being written — grouping is ordinary work there"

        for ref, spans in (("clinical:3-5", True), # a range
                           ("clinical:3, demographics:9", True), # two separate citations
                           ("clinical:3", False), # exactly one row — the rule
                           ("none", False)): # cites nothing; I8 owns that case
            rec = one(vid="LAB", ref=ref, decs="BIOM-WINDOW" if ref == "none" else "")
            product = build_product(tmp, [rec], spec_rows=rows)
            # coverage_complete is the CLAIM that every spec item resolves; that cannot be true
            # row by row while one record answers thirty rows. Approved inherits it.
            (Path(product) / "handoff" / "MATURITY.yaml").write_text(
                "contract: coverage_complete\nconfiguration: not_started\n", encoding="utf-8")
            errors = contract_lint.run(product)[0]
            hits = [e for e in errors if "I16" in e]
            assert bool(hits) == spans, f"{ref}: {errors}"
            if spans:
                assert "one record over" in hits[0] and ref.split(",")[0] in hits[0], hits


def test_i21_an_open_decision_the_contract_never_references_is_reported():
    """The reverse of I2, promoted from prostate's pack-local test_decision_refs.py — the pack
    without the copy (oc, 5 OPEN decisions) had no guard at all, and running the promoted check
    against it immediately named two unreferenced questions. Content-based on purpose: a decision
    gating config-only additions (HEPATIC-MET-INCLUDE) is carried by notes cells, and forcing a
    decision_ids citation would drag unrelated records to decision_required via I11. Scoped to
    coverage_complete like I16: while drafting, a question legitimately precedes its records."""
    with tempfile.TemporaryDirectory() as tmp:
        # Neither fixture decision is referenced: legal while drafting (no MATURITY.yaml)...
        uncited = one(decs="")
        assert not any("I21" in e for e in lint(tmp, [uncited])[0])

        #...and reported from coverage_complete up, naming each unreferenced OPEN id.
        product = build_product(tmp, [uncited])
        (Path(product) / "handoff" / "MATURITY.yaml").write_text(
            "contract: coverage_complete\nconfiguration: not_started\n", encoding="utf-8")
        errors = contract_lint.run(product)[0]
        for did in ("NAME-ALIGN", "BIOM-WINDOW"):
            assert any("I21" in e and did in e for e in errors), (did, errors)
        # FUED-RULE is RESOLVED — never demanded.
        assert not any("I21" in e and "FUED-RULE" in e for e in errors), errors

        # A structured citation clears its id; a bare mention in prose (the notes-cell case) clears
        # the other — the check is content-based, so either carrier keeps the question visible.
        cited = one(req="decision_required", decs="BIOM-WINDOW")
        product = build_product(
            tmp, [cited + "\n\nNAME-ALIGN is carried by each record's naming axis.\n"])
        (Path(product) / "handoff" / "MATURITY.yaml").write_text(
            "contract: coverage_complete\nconfiguration: not_started\n", encoding="utf-8")
        assert not any("I21" in e for e in contract_lint.run(product)[0])


def test_a_record_pasted_as_yaml_under_a_table_is_reported_not_swallowed():
    """The one way this file can lose a requirement with nothing going red.

    `records()` lets the table win, so a fenced block under a table is in the FILE and not in the
    contract — and the scaffolder still emits fenced blocks, so pasting one is the obvious thing to
    do. Silence there would be a variable that simply is not required by anything.
    """
    table = "| variable_id | source |\n|---|---|\n| A | n/a |\n"
    fenced = "\n```yaml\nvariable_id: PASTED_BY_HAND\nsource: n/a\n```\n"
    assert [b.splitlines()[0] for b in contract_lint.records(table + fenced)] == ["variable_id: A"], \
        "the table no longer wins — this test's premise is gone, re-read records()"
    errs = contract_lint.mixed_format_error(table + fenced, "FUNCTIONAL_CONTRACT.md")
    assert errs and "PASTED_BY_HAND" in errs[0], errs
    # Neither format ALONE is a problem: a pack still on fenced records must stay clean.
    assert contract_lint.mixed_format_error(table, "x") == []
    assert contract_lint.mixed_format_error(fenced, "x") == []


def test_i15_fires_when_the_cited_text_changes_under_a_record():
    """The digest must be checked through the real lint, not only as a function: a record whose cited
    row is edited in place has to fail even though its citation still resolves."""
    with tempfile.TemporaryDirectory() as tmp:
        product = build_product(tmp, [one()])
        extracted = Path(product) / "spec_pipeline" / "out" / "extracted.json"
        data = json.loads(extracted.read_text(encoding="utf-8"))
        for row in data["rows"]:
            row["content_hash"] = "CHANGED" # Science edits the rule; the row number does not move
        extracted.write_text(json.dumps(data), encoding="utf-8")
        errors, _ = contract_lint.run(product)
        assert [e for e in errors if "I15" in e], errors
        assert not [e for e in errors if "I8" in e], "the citation still resolves — only I15 should fire"



def test_the_spec_evidence_comes_from_the_extraction_and_is_REFUSED_from_the_drafter():
    """`spec_refs`, `spec_digest` and `required_rule` are established by the spec pipeline, and the
    skill has said "pass them through, never author them" since its first version. The tool then
    accepted the whole record from the model, so that rule was a sentence in a prompt.

    Two different failures follow, and the second is the reason this is mechanical now: retyping a
    digit of the digest fails I15 loudly, with a message about hashing — but tidying `required_rule`
    into better English replaces the spec's exact words with a paraphrase and NOTHING FAILS. The
    record reads well and no longer says what Science wrote.
    """
    import contract_record
    import contract_scaffold
    live = REPO / "fixtures" / "oncology" / "prostate" / "202606"
    if not (live / "spec_pipeline" / "out" / "extracted.json").exists():
        return # live-pack assertion; covered by the unit test below
    # A SIGNED COPY. The shipped pack's extraction is `status: pending` and nobody has approved it,
    # so `ai_gate` correctly refuses it — see the refusal test below, which is where that property
    # is asserted. This test's claim has always been "given a row this tool may read, the evidence
    # comes from the extraction and not from the drafter", so the fixture supplies the permission
    # and the assertion stays about the merge.
    pack = Path(_approved(str(live)))

    judgment = {"variable_id": "AGE", "source": "{kind: derived}"}
    merged, problems = contract_record.merge_evidence(dict(judgment), str(pack), "demographics:9")
    assert not problems, problems
    for field in contract_scaffold.MACHINE_OWNED:
        assert merged.get(field), f"{field} was not supplied from the extraction"
    assert merged["spec_refs"] == ["demographics:9"]
    # the digest is the LINT's, not a second implementation — the same value the scaffold records
    assert merged["spec_digest"] == contract_lint.spec_digest(
        ["demographics:9"], contract_lint.spec_rows(str(pack))), merged["spec_digest"]
    #...and the judgment fields survive the merge
    assert merged["source"] == "{kind: derived}"

    # supplying one is an ERROR, not an override. An override is how the rule goes back to advisory.
    for field in contract_scaffold.MACHINE_OWNED:
        _m, bad = contract_record.merge_evidence(dict(judgment, **{field: "mine"}),
                                                 str(pack), "demographics:9")
        assert bad and field in bad[0], (field, bad)

    # an item id that does not exist names the ones that do, rather than rendering an empty record
    _m, bad = contract_record.merge_evidence(dict(judgment), str(pack), "5A.Demos:9")
    assert bad and "not a requirement row" in bad[0], bad
    assert any(f"{d}:" in bad[0] for d in ("study_period", "study_population", "demographics",
                                           "clinical", "treatment", "outcomes")), \
        f"the error does not show what a real item id looks like: {bad[0]}"


def test_drafting_without_a_pack_must_be_an_explicit_choice():
    """`--product` was OPTIONAL and the skill documented it in brackets. Completeness and the
    round-trip run without it, which is what made that look sufficient — but I8, I15, I17 and the
    decision/gap reference checks all need the pack, so a drafter following the documented command got
    a clean-looking record no gate had seen."""
    import contract_record
    import yaml as _y
    with tempfile.TemporaryDirectory() as tmp:
        rec = {ln.split(": ", 1)[0]: ln.split(": ", 1)[1]
               for ln in one().splitlines() if ": " in ln and not ln.startswith("```")}
        rec.pop("status", None) # the TOOL settles status; a draft carrying one is refused
        draft = os.path.join(tmp, "d.yaml")
        with open(draft, "w", encoding="utf-8") as fh:
            _y.safe_dump(rec, fh, sort_keys=False, width=10 ** 6)

        try:
            contract_record.main([draft])
            raise AssertionError("a record was rendered with no pack and no explicit opt-out")
        except SystemExit as exc:
            assert exc.code != 0

        #...and the opt-out is NAMED, so choosing it is visible in the command someone ran
        assert contract_record.main([draft, "--format-only"]) == 0

        #...AND WHAT IT RENDERS CANNOT PASS AS EVIDENCE. The flag skips the pack, so `spec_refs`,
        # `spec_digest` and `required_rule` are whatever the drafter typed and nothing read a spec
        # row — yet it rendered them as facts, at exit 0, producing a complete paste-ready record
        # carrying a citation nobody resolved. A row that looks governed and no gate has seen is
        # worse than a refusal, because it gets pasted. All three are now stamped TODO.
        import io as _io # noqa: PLC0415
        import contextlib as _ctx # noqa: PLC0415
        buf = _io.StringIO()
        with _ctx.redirect_stdout(buf):
            assert contract_record.main([draft, "--format-only"]) == 0
        rendered = buf.getvalue()
        assert rendered.count("TODO") >= 3, rendered[:400]
        for field in ("spec_refs", "spec_digest", "required_rule"):
            assert f"{field} was never verified" in rendered, f"{field} rendered as a fact"
        # The row still RENDERS and still round-trips — renderer testing is what the flag is for.
        assert rendered.strip().startswith("|") and rendered.count("|") > 20


    #...and --item is REQUIRED for a pack that HAS an extraction. Making it optional left the whole
    # machine-owned-field boundary opt-in: `--product` alone accepted a hand-written spec_refs,
    # spec_digest and required_rule, and only a wrong DIGEST would have failed. A paraphrased
    # `required_rule` — the failure the interface exists to stop — passed silently.
    with tempfile.TemporaryDirectory() as tmp:
        rec = {ln.split(": ", 1)[0]: ln.split(": ", 1)[1]
               for ln in one().splitlines() if ": " in ln and not ln.startswith("```")}
        product = build_product(tmp, [contract_lint.render_table([rec])])
        draft = os.path.join(tmp, "d.yaml")
        with open(draft, "w", encoding="utf-8") as fh:
            _y.safe_dump(rec, fh, sort_keys=False, width=10 ** 6)
        # `--actor human` USED TO BE PASSED HERE, AND THE FLAG NO LONGER EXISTS. argparse then failed
        # with "unrecognized arguments" and exit code 2 BEFORE either check below ran — so both
        # assertions passed on a refusal that had nothing to do with `--item`. A non-zero code is not
        # evidence of the intended refusal; the MESSAGE is, which is why these now read it.
        import contextlib
        import io
        err = io.StringIO()
        with contextlib.redirect_stderr(err):
            try:
                contract_record.main([draft, "--product", product])
                raise AssertionError("a pack with an extraction accepted a draft with no --item")
            except SystemExit as exc:
                assert exc.code != 0
        assert "--item is required" in err.getvalue(), \
            f"refused for some other reason than the missing --item: {err.getvalue()[:200]}"
        #...and the legacy opt-out is refused for a pack that HAS one, or it is just --item again
        err = io.StringIO()
        with contextlib.redirect_stderr(err):
            try:
                contract_record.main([draft, "--product", product, "--legacy-no-extraction"])
                raise AssertionError("--legacy-no-extraction was accepted for a pack with an extraction")
            except SystemExit as exc:
                assert exc.code != 0
        assert "HAS an extraction" in err.getvalue(), \
            f"refused for some other reason than the live extraction: {err.getvalue()[:200]}"

    with tempfile.TemporaryDirectory() as tmp:
        rec = {ln.split(": ", 1)[0]: ln.split(": ", 1)[1]
               for ln in one().splitlines() if ": " in ln and not ln.startswith("```")}
        draft = os.path.join(tmp, "d.yaml")
        with open(draft, "w", encoding="utf-8") as fh:
            _y.safe_dump(rec, fh, sort_keys=False, width=10 ** 6)

        # --item without --product is refused: the evidence has nowhere to come from. Passed WITH
        # --format-only so the required-pack guard above cannot be what fires — two guards where one
        # masks the other is a guard nobody has tested.
        try:
            contract_record.main([draft, "--format-only", "--item", "demographics:9"])
            raise AssertionError("--item was accepted with no pack to read the extraction from")
        except SystemExit as exc:
            assert exc.code != 0


def test_the_skill_documents_the_commands_it_actually_has():
    """Three times this skill has described a flag that had changed under it — `--product` optional
    after it stopped being safe, `implementation_refs` optional after it became required, `[none]`
    needing a gap after that stopped being true. Prose is what drifts, so the claims are checked."""
    skill_dir = REPO / ".claude" / "skills" / "draft-contract-record"
    if not skill_dir.exists():
        return
    skill = (skill_dir / "SKILL.md").read_text(encoding="utf-8")

    # the split exists, and the operational file is the smaller one
    assert (skill_dir / "REFERENCE.md").exists(), "REFERENCE.md is referenced by SKILL.md and missing"
    assert "REFERENCE.md" in skill, "SKILL.md does not point at REFERENCE.md"

    # THE EVIDENCE IS NOT IN THE SKILL DIRECTORY AT ALL. It moved to governance/, and this asserts it
    # stays there. `EVAL_RATIONALE` explains WHY the mandatory rules were written — which is exactly
    # the reading an executing agent should not be doing. An agent invited to weigh whether a control
    # is "worth following" has been handed the argument for skipping it, in the file it reads while
    # deciding what to do. History belongs to whoever maintains the skill, not to whoever runs it.
    assert not (skill_dir / "EVAL_RATIONALE.md").exists(), \
        "EVAL_RATIONALE.md is back inside the runtime instructions — it belongs in governance/"
    assert (REPO / "governance" / "SKILL_EVAL_RATIONALE.md").exists(), \
        "the skill's evidence was removed rather than relocated"

    #...AND NEITHER ARE THE EXPECTED ANSWERS. `evals.json` carries an `expected_output` per case,
    # and it lived inside the skill directory — so the material the benchmark grades against sat in
    # the folder the graded agent reads while working. That does not measure the skill; it measures
    # whether the agent looked next door. The scores it produced cannot be interpreted either way,
    # which is worse than having no benchmark.
    assert not (skill_dir / "evals").exists(), \
        "the eval answers are back inside the skill directory — the evaluated agent can read them"
    assert (REPO / "governance" / "skill_evals" / "evals.json").exists(), \
        "the evals were removed rather than relocated"

    # A BUDGET, not a measurement — the difference matters. A measurement in an instruction goes
    # stale; a budget is a deliberate constraint. It exists because the single file reached 637 lines
    # and the operational rules were buried among the evidence for them, and it is now set by what a
    # long run can actually retain: only the first ~5,000 tokens of an invoked skill survive
    # compaction, so a skill whose safety guidance sits past that line loses it exactly when the run
    # has gone on long enough to need it. Raising this is a decision someone makes on purpose.
    # LINES ARE THE PROXY; WORDS ARE THE CONSTRAINT. What actually gets lost after compaction is
    # measured in tokens, and a table row or a fenced command costs a line while costing almost no
    # tokens — so a line budget tightened past what the content needs starts pushing out tables,
    # which are the most compact form the procedural parts have. The word budget below is the one
    # that binds; this catches sprawl.
    operational = len(skill.splitlines())
    words = len(skill.split())
    assert operational <= 345, f"SKILL.md is {operational} lines — move reference or evidence out"
    assert words <= 3200, (
        f"SKILL.md is {words} words (~{words * 4 // 3} tokens) — past the point where a long run "
        f"keeps its final safety guidance after compaction")
    assert operational < len((skill_dir / "REFERENCE.md").read_text(encoding="utf-8").splitlines()), (
        f"SKILL.md ({operational} lines) carries more than REFERENCE.md — the split has not "
        f"actually moved anything")

    # MUTABLE MEASUREMENTS BELONG IN EVAL_RATIONALE. A count inside an operational instruction goes
    # stale silently: a change to the contract sanitization moves the quotation figure in
    # the same week the sentence carrying it was written.
    import re as _re
    for pattern in (r"\b295 records\b", r"\b99 of them\b", r"\b45%", r"forty quotations",
                    r"fourteen aliases"):
        assert not _re.search(pattern, skill), \
            f"SKILL.md carries the frozen measurement {pattern!r} — it belongs in EVAL_RATIONALE.md"

    # the documented command form is the one the tool accepts
    assert "--product <pack> --item <domain:row>" in skill
    assert "--format-only" in skill
    # Read the tool's own source, rather than a copy of its flag list here.
    src = (REPO / "platform" / "tools" / "contract_record.py").read_text(encoding="utf-8")
    for flag in ("--item", "--format-only", "--product"):
        assert f'"{flag}"' in src, f"SKILL.md documents {flag}, which contract_record.py does not define"


def test_the_eval_prompts_require_the_tool_rather_than_a_hand_written_row():
    """The skill says "You write key: value. You do NOT write the row." The eval prompts asked for
    "one markdown table row" — so the benchmark measured the behaviour the skill exists to remove, and
    a model that ignored the tool entirely scored well."""
    import json as _json
    evals = REPO / "governance" / "skill_evals" / "evals.json"
    if not evals.exists():
        return
    doc = _json.loads(evals.read_text(encoding="utf-8"))
    drafting = [e for e in doc["evals"] if "draft the functional-contract record" in e["prompt"]]
    assert drafting, "no drafting evals found — the check below would be vacuous"
    for e in drafting:
        assert "contract_record.py" in e["prompt"], \
            f"eval {e['id']} ({e['name']}) does not route the record through the renderer"
        assert "--item" in e["prompt"] and "--product" in e["prompt"], e["name"]
        assert "judgment" in e["prompt"].lower(), \
            f"eval {e['id']} does not ask for judgment fields — it asks for a whole record"
        assert "markdown table row" not in e["prompt"], \
            f"eval {e['id']} still asks the model to write the row itself"


def test_the_AI_drafting_path_refuses_a_status_only_a_human_may_set():
    """`requirement: approved`, `source_mapping: human_confirmed`, `passed_live`, `accepted` — every
    mode this skill defines forbids them, and `contract_lint` accepts them on a structurally complete
    record. So on a mature pack a model could assert an approval and nothing objected; the rule was a
    sentence in a prompt. `--actor human` is how an accountable person makes the transition."""
    import contract_record
    for axis, value in (("requirement", "approved"), ("source", "verified"),
                        ("source_mapping", "human_confirmed"), ("validation", "passed_live"),
                        ("data_profile_check", "accepted"), ("live_schema_check", "passed")):
        rec = {"variable_id": "X", "status": f"{{{axis}: {value}, requirement: draft}}"
               if axis != "requirement" else "{requirement: approved}"}
        bad = contract_record.human_only_errors(rec)
        assert bad and axis in bad[0], (axis, value, bad)
    # a real draft is clean
    assert not contract_record.human_only_errors(
        {"status": "{requirement: draft, source: unverified, implementation: not_implemented, "
                   "validation: not_run}"})
    #...and a mapping, not just the inline string, is read the same way
    assert contract_record.human_only_errors({"status": {"requirement": "approved"}})


def test_status_is_SETTLED_BY_THE_TOOL_and_a_draft_may_not_write_one():
    """`DRAFTABLE` was safer than the blacklist it replaced and still the wrong shape: `failed`,
    `passed_test`, `issue_open` and `dictionary_only` were all inside it, and every one is an EVIDENCE
    CLAIM — a statement that a check ran and came back a certain way. A drafter has read a
    specification row. It has not run a test, opened a dictionary or looked at a profile.

    So a new record does not carry `status` at all and the tool injects one; a revision keeps whatever
    the existing record holds. The model has no reason to reason about status, which is the point.
    """
    import contract_record
    # A NEW record: the tool supplies the initial status, and it is the whole initial status.
    rec, bad = contract_record.apply_status({"variable_id": "X"})
    assert not bad, bad
    for axis, value in contract_record.INITIAL_STATUS.items():
        assert f"{axis}: {value}" in rec["status"], (axis, rec["status"])
    # A REVISION keeps what the record already holds — including a value no drafter could have written.
    rec, bad = contract_record.apply_status(
        {"variable_id": "X"}, {"requirement": "approved", "source": "verified"})
    assert not bad and "requirement: approved" in rec["status"], rec
    #...and a draft that writes one is REFUSED, in both notations, rather than silently overwritten:
    # the drafter meant something by it, and hiding the disagreement is worse than reporting it.
    for written in ("{requirement: approved, source: verified}", {"requirement": "draft"}):
        _rec, bad = contract_record.apply_status({"variable_id": "X", "status": written})
        assert bad and "not yours to write" in bad[0], written
    # The evidence claims are simply unreachable from a draft.
    for claim in ("passed_test", "failed", "issue_open", "dictionary_only"):
        assert claim not in str(contract_record.INITIAL_STATUS), claim


def test_every_status_value_is_on_exactly_one_side_of_the_draftable_line():
    """The property an ALLOWLIST has and the blacklist it replaced did not.

    `DRAFTABLE` names what a machine may author; `contract_lint` owns the vocabularies. A value in the
    lint and in neither category is a value nobody decided about — and under the old blacklist that
    meant "assertable by a drafter", silently, on the day the lint grew it. `FINE_SOURCE_AXES` was
    added after the coarse `source` axis and `data_profile_check: reviewed` after that; each of those
    would have widened what a model could claim with nothing going red.

    So the test is not "the allowlist is right" — that is a judgment — but "every value has been
    judged". Adding one to `contract_lint` fails here until somebody puts it on a side.
    """
    import contract_lint
    import contract_record
    vocab = dict(contract_lint.FINE_SOURCE_AXES)
    vocab.update({"requirement": contract_lint.REQ, "source": contract_lint.SRC,
                  "validation": contract_lint.VAL})
    assert set(vocab) == set(contract_record.DRAFTABLE), \
        (f"axes differ: lint has {sorted(set(vocab) - set(contract_record.DRAFTABLE))}, "
         f"DRAFTABLE has {sorted(set(contract_record.DRAFTABLE) - set(vocab))}")
    for axis, allowed in contract_record.DRAFTABLE.items():
        stray = allowed - set(vocab[axis])
        assert not stray, f"DRAFTABLE[{axis!r}] permits {sorted(stray)}, which the lint refuses outright"
        #...and the other side is non-empty: an axis whose every value is draftable records no human
        # act at all, and putting it here would be a category error worth catching.
        assert set(vocab[axis]) - allowed, \
            f"axis {axis!r} has no human-only value — it does not belong in DRAFTABLE"


def test_the_drafting_tool_asks_the_SAME_question_the_slicer_does_before_lifting_spec_text():
    """TWO DOORS ONTO ONE DECISION, which is the shape `docs/ENGINEERING.md` names as how a governed gate comes
    to pass something it exists to stop.

    `source_manifest.ai_readable` is the one answer to "may AI read this pack". `spec_slice` asked it
    and refused prostate/202606 — `status: pending`, no `approved_by`, no `approval_date`. Meanwhile

        contract_record.py d.yaml --product fixtures/oncology/prostate/202606 --item study_period:18

    returned the specification's own sentence, `Earliest available data through INDEX, inclusive.`,
    with its digest. Same artifact, same question, opposite answers — and the second door is the one
    the drafting skill actually uses.

    Asserted against the SHIPPED packs, and it asserts the pair: the refusal, and that the same call
    succeeds once somebody has signed. A test of the refusal alone would still pass if the gate
    refused everything, including approved work.
    """
    import contract_record
    import contract_scaffold
    # WHICHEVER PACK IS STILL UNSIGNED, discovered rather than named. This test named
    # prostate/202606 and went red the day somebody approved that pack's extraction — correctly, via
    # its own guard, but the property is about the GATE and not about any one pack. It fails only
    # when NO pack is left refusing, which is the one state in which it would prove nothing.
    import product_gates as _pg
    import contract_scaffold as _cs
    # `products()` emits REPO-ROOT-RELATIVE paths and this suite runs from `platform/`, so every
    # path is joined to REPO before it is touched. Testing them as-is made the list empty and the
    # guard below fire with exactly the wrong diagnosis.
    unsigned = [str(REPO / p) for p in sorted(_pg.all_packs(str(REPO)))
                if (REPO / p / "spec_pipeline" / "out" / "extracted.json").exists()
                and not _sm_ai_readable(str(REPO / p))[0]]
    assert unsigned, ("every pack is now approved for AI use — this test no longer proves the "
                      "refusal; point it at a fixture whose extraction nobody has signed")
    live = Path(unsigned[0])
    item = sorted({f"{r['domain']}:{r['row']}" for r in
                   json.loads((live / "spec_pipeline" / "out" / "extracted.json")
.read_text(encoding="utf-8"))["rows"] if r.get("domain")})[0]

    for fn, why in ((lambda: _cs.evidence_for(str(live), item), "evidence_for"),
                    (lambda: contract_record.merge_evidence({"variable_id": "X"}, str(live),
                                                            item), "merge_evidence")):
        try:
            fn()
        except contract_scaffold.NotApprovedForAI as exc:
            assert "not approved for AI use" in str(exc), exc
        else:
            raise AssertionError(
                f"{why} supplied the specification's own words for a pack `ai_readable` refuses — "
                f"the slicer's gate and the drafter's are not the same gate")

    #...and through the CLI, which is what a drafter actually runs. Asserted separately because
    # `main` catches the refusal, and a `main` that caught and CONTINUED would leave every library
    # assertion above passing while the command still printed the row.
    with tempfile.TemporaryDirectory() as tmp:
        draft = os.path.join(tmp, "d.yaml")
        with open(draft, "w", encoding="utf-8") as fh:
            fh.write("variable_id: PROBE\n")
        try:
            rc = contract_record.main([draft, "--product", str(live), "--item", item,
                                       "--allow-partial"])
        except SystemExit as exc:
            assert "not approved for AI use" in str(exc), exc
        else:
            raise AssertionError(f"the CLI rendered a row from an unapproved extraction (rc={rc})")

    #...and it is a GATE, not a wall: the identical call on a signed copy returns the evidence.
    ok = contract_scaffold.evidence_for(_approved(str(live)), item)
    assert ok["required_rule"].strip(), ok

    # One function answers this, for both tools. Two would agree today.
    assert contract_scaffold.ai_gate.__module__ == "contract_scaffold"
    import spec_slice
    assert spec_slice.sm.ai_readable is _sm_ai_readable


def test_a_VENDOR_REDACTED_row_cannot_be_drafted_by_the_tool():
    """The slice SAYS a redacted row must be left to a human. Saying so is a prompt instruction: a
    model can still produce a complete-looking judgment over the row and pass every invariant, because
    `VENDOR_REDACTED` is deliberately not in I17's unsettled set — it means the spec DOES settle this,
    in material AI may not read. Refusing the item is the mechanical half."""
    import contract_record
    live = REPO / "fixtures" / "oncology" / "prostate" / "202606"
    if not (live / "spec_pipeline" / "out" / "extracted.json").exists():
        return
    pack = Path(_approved(str(live))) # signed copy: the AI gate is a separate property, tested below
    import json as _json
    rows = _json.loads((pack / "spec_pipeline" / "out" / "extracted.json").read_text(encoding="utf-8"))["rows"]
    red = [r["item_id"] for r in rows if r.get("vendor_redacted")]
    assert red, "no redacted row in this pack — the assertion below would check nothing"

    _m, bad = contract_record.merge_evidence({"variable_id": "BP"}, str(pack), red[0])
    assert bad and "VENDOR_REDACTED" in bad[0], bad
    assert "authorized human" in bad[0].lower(), bad
    # an ordinary row is unaffected
    _m, ok = contract_record.merge_evidence({"variable_id": "AGE"}, str(pack), "demographics:9")
    assert not ok, ok


def test_the_register_reader_is_one_reader_for_all_three_registers():
    """The gap index used a local `split("|")` because `_register_rows` hardcoded `ID` and
    `ENGINE_GAPS.md` heads its column `Gap ID` — a FOURTH parser for one register shape. One argument
    is cheaper than a parser, and cheaper again than the divergence between them."""
    import contract_lint as cl
    pack = REPO / "fixtures" / "oncology" / "prostate" / "202606" / "handoff"
    if not (pack / "ENGINE_GAPS.md").exists():
        return
    gaps = cl.decision_rows((pack / "ENGINE_GAPS.md").read_text(encoding="utf-8"), "Gap ID")
    assert gaps, "the shared reader finds no gap rows"
    # the OWNER of what counts as a gap id still decides membership
    legal = cl.gap_ids((pack / "ENGINE_GAPS.md").read_text(encoding="utf-8"))
    assert legal & set(gaps), "the shared reader and gap_ids disagree about every id"
    #...and the default is unchanged for the two registers that do head their column `ID`
    assert cl.decision_rows((pack / "DECISIONS.md").read_text(encoding="utf-8"))
    assert cl.decision_rows((pack / "SPEC_QC_FINDINGS.md").read_text(encoding="utf-8"))
    # no local pipe-splitting left in the slicer for this
    src = (REPO / "platform" / "tools" / "spec_slice.py").read_text(encoding="utf-8")
    code = [l for l in src.splitlines() if not l.lstrip().startswith("#")]
    assert not any('strip("|").split("|")' in l for l in code), \
        "spec_slice parses a register table by hand again"

def test_apply_verdicts_translates_the_coarse_axis_and_touches_nothing_human():
    """`--apply-verdicts` half one: `source: unverified` becomes the four finer axes at their
    no-evidence values — a vocabulary translation that claims nothing the coarse word did not.
    The human axes ride through byte-for-byte, and a second run changes zero records."""
    import shutil
    import tempfile
    import contract_record
    with tempfile.TemporaryDirectory() as tmp:
        pack = os.path.join(tmp, "pack")
        shutil.copytree(str(FIXTURE), pack, ignore=shutil.ignore_patterns("__pycache__", "reference"))
        cpath = Path(pack, "handoff", "FUNCTIONAL_CONTRACT.md")
        # one row carries a coarse HUMAN claim — the translation must refuse it, not re-state it
        cpath.write_text(cpath.read_text(encoding="utf-8").replace(
            "source: unverified", "source: unavailable", 1), encoding="utf-8", newline="")
        text0 = read(str(cpath))
        before = {(_scalar(b, "variable_id") or ""):
                  contract_record._status_map({"status": _inline(b, "status")})
                  for b in records(text0)}
        kept_vid = next(v for v, st in before.items() if st.get("source") == "unavailable")
        changes, notes, errors, new_text = contract_record.apply_verdicts(pack)
        assert errors == [] and changes, (errors, len(changes))
        Path(pack, "handoff", "FUNCTIONAL_CONTRACT.md").write_text(new_text, encoding="utf-8",
                                                                   newline="")
        migrated = 0
        for b in records(new_text):
            vid = _scalar(b, "variable_id") or ""
            st = contract_record._status_map({"status": _inline(b, "status")})
            was = before[vid]
            if was.get("source") == "unverified":
                migrated += 1
                assert "source" not in st, f"{vid} still carries the coarse axis"
                for axis, value in contract_record.FINE_DEFAULTS.items():
                    assert st[axis] == value, (vid, axis, st)
            elif was.get("source"):
                # a human's coarse claim is never translated — four words would each carry an
                # evidence claim the one word did not
                assert st == was, (vid, "a coarse human claim was rewritten", st)
            # the human axes are untouched, whatever happened to the source axes
            for axis in ("requirement", "implementation", "validation"):
                assert st.get(axis) == was.get(axis), (vid, axis)
        assert migrated == len(changes)
        assert any(kept_vid in x and "unavailable" in x for x in notes), f"the human claim on {kept_vid} was not surfaced"
        # the whole contract still parses record-for-record and passes the lint's own status checks
        assert len(list(records(new_text))) == len(before)
        # idempotent: evidence already applied is not applied again
        again, _n2, e2, t2 = contract_record.apply_verdicts(pack)
        assert again == [] and e2 == [] and t2 is None


def test_apply_verdicts_settles_live_schema_check_from_the_producer_block_alone():
    """Half two: `live_schema_check` moves only on the report's GENERATED verdicts — in whichever
    direction the evidence points — and `source_mapping: human_confirmed` lands only from a
    hand-typed, rationale-bearing confirmation. Everything inconclusive is named, not guessed."""
    import shutil
    import tempfile
    import contract_record
    with tempfile.TemporaryDirectory() as tmp:
        pack = os.path.join(tmp, "pack")
        shutil.copytree(str(FIXTURE), pack, ignore=shutil.ignore_patterns("__pycache__", "reference"))
        # migrate first, so the fine axes exist to be settled
        _c, _n, _e, t = contract_record.apply_verdicts(pack)
        Path(pack, "handoff", "FUNCTIONAL_CONTRACT.md").write_text(t, encoding="utf-8", newline="")
        vids = [(_scalar(b, "variable_id") or "") for b in records(t)]
        ok, bad, meh, broke = vids[0], vids[1], vids[2], vids[3]
        confirmed_norat, confirmed = vids[4], vids[0]
        Path(pack, "handoff", "SOURCE_VERDICTS.md").write_text(
            "---\ntool: test\n---\n"
            "live_schema_verdicts:\n"
            f"  - {{record: {ok}, verdict: passed}}\n"
            f"  - {{record: {bad}, verdict: failed}}\n"
            f"  - {{record: {meh}, verdict: inconclusive}}\n"
            f"  - {{record: {broke}, verdict: record_defect}}\n"
            f"  - {{record: NOT-A-RECORD, verdict: passed}}\n"
            "\n"
            "confirmed_mappings:\n"
            f"  - {{record: {confirmed}, rationale: \"column names and dictionary agree; reviewed "
            "against the restricted profile\"}\n"
            f"  - {{record: {confirmed_norat}}}\n",
            encoding="utf-8")
        changes, notes, errors, new_text = contract_record.apply_verdicts(pack)
        assert errors == [], errors
        got = {(_scalar(b, "variable_id") or ""):
               contract_record._status_map({"status": _inline(b, "status")})
               for b in records(new_text)}
        assert got[ok]["live_schema_check"] == "passed"
        assert got[ok]["source_mapping"] == "human_confirmed"
        assert got[bad]["live_schema_check"] == "failed"
        assert got[meh]["live_schema_check"] == "not_run"
        assert got[broke]["live_schema_check"] == "not_run"
        # a confirmation without a rationale is a switch, not a judgment — ignored
        assert got[confirmed_norat]["source_mapping"] == "proposed"
        assert any("NOT-A-RECORD" in n for n in notes), notes
        assert any(meh in n and "inconclusive" in n for n in notes), notes
        assert any(broke in n and "defect" in n for n in notes), notes
        # the human axes never MOVE — compared against the pre-apply state, not against the
        # vocabulary: `requirement: approved` is a legal value, which is exactly why writing it
        # here would have passed a vocabulary check
        pre = {(_scalar(b, "variable_id") or ""):
               contract_record._status_map({"status": _inline(b, "status")})
               for b in records(read(os.path.join(pack, "handoff", "FUNCTIONAL_CONTRACT.md")))}
        for vid in (ok, bad, meh, broke, confirmed_norat):
            for axis in ("requirement", "implementation", "validation", "dictionary_check",
                         "data_profile_check"):
                assert got[vid].get(axis) == pre[vid].get(axis), (vid, axis)
        #...and the writable surface is exactly two axes, stated as a constant a test can hold
        assert set(contract_record.VERDICT_WRITABLE) == {"live_schema_check", "source_mapping"}


def test_one_verdict_per_record_and_the_worst_class_wins():
    """The derivation source_check owns, tested at its own boundary — the applicator's tests write
    the block directly, so a mutation HERE (inconclusive collapsing to passed) was invisible to
    them. Priority is the fail-closed order: a defect in the record outranks a proven absence,
    absence outranks inconclusive, and `passed` only when every usage was found. A record with no
    vendor-column findings has NO verdict — absence from the map is "not applicable", never a pass."""
    import source_check
    F = lambda vid, state: (vid, "t", "r", "c", state, "")
    got = source_check.record_verdicts_from_findings([
        F("A", "present"),
        F("B", "present"), F("B", "ABSENT_COLUMN"),
        F("C", "present"), F("C", "not_in_profile"),
        F("D", "present"), F("D", "ABSENT_TABLE"), F("D", "ambiguous_source"),
        F("E", "unprofiled"),
    ])
    assert got == {"A": "passed", "B": "failed", "C": "inconclusive",
                   "D": "record_defect", "E": "inconclusive"}, got
    assert "Z" not in source_check.record_verdicts_from_findings([])


def test_apply_verdicts_survives_an_escaped_pipe_in_a_neighbouring_cell():
    """Seven live records hold `\\|` inside a cell. A naive pipe-split shifts every later cell by
    one, and the status lands in a neighbouring column — this drove the rewrite through the same
    unescaped-pipe split every reader uses."""
    import shutil
    import tempfile
    import contract_record
    with tempfile.TemporaryDirectory() as tmp:
        pack = os.path.join(tmp, "pack")
        shutil.copytree(str(FIXTURE), pack, ignore=shutil.ignore_patterns("__pycache__", "reference"))
        contract = Path(pack, "handoff", "FUNCTIONAL_CONTRACT.md")
        text = contract.read_text(encoding="utf-8")
        piped = [l for l in text.splitlines() if "\\|" in l and l.startswith("|")]
        assert piped, "no fixture row carries an escaped pipe — plant one or re-choose the fixture"
        _c, _n, errors, new_text = contract_record.apply_verdicts(pack)
        assert errors == [], errors
        for line in piped:
            vid = line.strip().strip("|").split("|")[0].strip()
            row = next(l for l in new_text.splitlines() if l.startswith(f"| {vid} |"))
            assert "\\|" in row, f"{vid}: the escaped pipe was lost in the rewrite"
            assert len(re.split(r"(?<!\\)\|", row)) == len(re.split(r"(?<!\\)\|", line)), \
                f"{vid}: the rewrite changed the cell count"



# --- a comparison that compared nothing is not a pass ---------------------------------------------

def test_a_vacuous_binding_run_fails_check_instead_of_printing_zero():
    """`return 1 if (a.check and (errors or diffs)) else 0` — both empty when there was nothing to
    compare, so a pack with no contract, no extraction, or a BROKEN extraction artifact exited 0
    under the flag CI reads as proof.

    The broken-artifact case is the sharp one and it was not in the review: emptying
    ENUMERATION_CANDIDATES.yaml (or corrupting it, or renaming its root key) leaves the file
    present, so the missing-file banner never fires and the run prints `0 difference(s) needing a
    person` — the agreement wording — over nothing at all.
    """
    import shutil
    import subprocess
    import sys as _sys
    import tempfile
    tools = str(REPO / "platform" / "tools")
    live = str(REPO / "fixtures" / "oncology" / "prostate" / "202606")
    tmp = tempfile.mkdtemp()
    try:
        pack = os.path.join(tmp, "202606")
        shutil.copytree(live, pack)
        cands = os.path.join(pack, "spec_pipeline", "out", "ENUMERATION_CANDIDATES.yaml")

        def run():
            return subprocess.run(
                [_sys.executable, os.path.join(tools, "contract_binding.py"), pack,
                 "--enumerations", "--check"],
                capture_output=True, text=True, encoding="utf-8")

        # The unmutated copy compares something and does not trip the vacuity guard.
        base = run()
        assert "NOTHING COMPARED" not in base.stdout, base.stdout

        for label, payload in (("empty", ""),
                               ("unparsable", "a: [1,\n"),
                               ("wrong root key", "not_enumerations: {}\n")):
            Path(cands).write_text(payload, encoding="utf-8")
            got = run()
            assert "NOTHING COMPARED" in got.stdout, (label, got.stdout)
            assert "0 difference(s) needing a person" not in got.stdout, \
                f"{label}: a broken artifact printed the AGREEMENT wording"
            assert got.returncode == 1, (label, got.returncode, got.stdout)
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


def test_the_ratchet_separates_not_started_from_broken():
    """`--surface-base` printed OK whenever `leaked_surface` returned None — which covers a pack
    with no contract AND a pack whose contract governs no config. The first is a legitimate
    pre-Gate-2 state that ten scaffold packs are in; the second is a contract governing nothing,
    which nothing else catches. Reporting both as "no new leak" hid the second and would have
    turned CI red for the first."""
    import contract_binding as cb
    live = str(REPO / "fixtures" / "oncology" / "prostate" / "202606")
    assert cb.leaked_surface(live) is not None, "the reference pack must have a surface to compare"
    scaffold = str(REPO / "products" / "oncology" / "mcrc" / "202606")
    assert not os.path.exists(os.path.join(scaffold, "handoff", "FUNCTIONAL_CONTRACT.md"))
    assert cb.leaked_surface(scaffold) is None


def test_a_check_over_zero_signed_rulings_says_so():
    """"OK — every signed ruling matches its committed form" was printed over ZERO of them on both
    live packs, because every RESOLVED row in this repository is unsigned. True, and meaningless."""
    import decision_record as dr
    for pack in ("fixtures/oncology/prostate/202606", "fixtures/oncology/oc/202606"):
        assert dr.signed_rulings(pack) == [], \
            f"{pack} now has a signed ruling — update this test deliberately"

def test_a_format_only_row_cannot_reach_approved():
    """The TODO is load-bearing, not decoration: contract_lint refuses a TODO anywhere in a record
    at `requirement: approved`, so a pasted rendering is stopped at the moment somebody claims it
    was approved. Reusing TODO rather than inventing a marker is deliberate — a second placeholder
    vocabulary is the divergence docs/ENGINEERING.md records, and TODO_RE already exists."""
    stamped = ("spec_digest: TODO --format-only rendered this without a pack; spec_digest was "
               "never verified against a spec row")
    assert contract_lint.TODO_RE.search(stamped), "the stamp does not match the placeholder rule"
    assert "spec_digest" in contract_lint.todo_fields(stamped + "\n")
    src = (REPO / "platform" / "tools" / "contract_lint.py").read_text(encoding="utf-8")
    assert 'req == "approved" and TODO_RE.search(block)' in src, \
        "the rule that makes the stamp bite was removed — a format-only row could now be approved"


def test_the_reference_points_at_the_flag_that_still_runs_the_pack_checks():
    """`--legacy-no-extraction` keeps `--product`, so I8/I15/I17 and the pack-specific rules still
    run; `--format-only` drops all of them. Steering a drafter with no extraction to the weaker
    flag is how the hole gets used."""
    ref = (REPO / ".claude/skills/draft-contract-record/REFERENCE.md").read_text(encoding="utf-8")
    assert "--legacy-no-extraction" in ref, \
        "the reference still sends a pack with no extraction to --format-only"


def test_a_register_that_does_not_exist_is_named_as_missing_not_as_a_parser_floor():
    """A reviewer whose pack had never had DECISIONS.md read "parsed only 0 decision IDs from
    DECISIONS.md (floor 1) — parser/table changed" and had nothing to do with it (the walkthrough,
    2026-09-05). A missing register is named as missing, with where its canonical header lives;
    the floor is the message only when there is a file to parse."""
    with tempfile.TemporaryDirectory() as tmp:
        product = Path(build_product(tmp, [one()]))
        os.remove(product / "handoff" / "DECISIONS.md")
        errors, _ = contract_lint.run(product)
        missing = [e for e in errors if "DECISIONS.md" in e]
        assert missing and all("is missing" in e and "TUMOR_TEMPLATE/handoff/DECISIONS.md" in e for e in missing), errors
        assert not any("parser/table changed" in e for e in missing), missing
        # ...and a file that IS there but parses to nothing still says so in the parser's words
        (product / "handoff" / "DECISIONS.md").write_text("no table here\n", encoding="utf-8")
        errors, _ = contract_lint.run(product)
        assert any("parsed only 0 decision IDs from DECISIONS.md" in e for e in errors), errors


if __name__ == "__main__":
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")   # a cp1252 console mangled an em dash (audit 6)
    # CI runs each suite as a script (`python3 tests/test_x.py`), not under pytest. Without this block
    # the file imports cleanly, defines its tests, exits 0 — and CI reports a pass having asserted
    # nothing. That is the same silent-success failure this suite exists to catch elsewhere.
    import traceback
    failed = 0
    for _name, _fn in sorted(globals().items()):
        if _name.startswith("test_") and callable(_fn):
            try:
                _fn()
                print(f"  ok   {_name}")
            except BaseException: # noqa: BLE001 - includes pytest.skip
                if type(_fn).__name__ and "Skipped" in traceback.format_exc():
                    print(f"  skip {_name}")
                    continue
                failed += 1
                print(f"  FAIL {_name}")
                traceback.print_exc()
    print(f"\n{'FAILED' if failed else 'OK'} — {failed} failure(s)")
    sys.exit(1 if failed else 0)
