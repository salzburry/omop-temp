# The R half of stage conformance: run ONE serialised case through engine-r/stages.R and
# write the canonical output text — byte-identical rules to test_stage_conformance.py.
#
# Invoked BY the Python orchestrator only: argv = <case_env.R> <out.tsv>. The case arrives as
# R literals generated from the SAME parsed YAML the Python half consumed (the r-parity idiom:
# no R YAML package exists offline, and one parsed source means the two engines cannot read
# two different fixtures). `cfg_pack` is shadowed with the case's own pack literals for the
# same reason — the seam replaced is FILE LOADING, never stage logic.
#
# Without sparklyr/Spark this prints "R-RUNNER SKIP (<why>)" and exits 0 — the orchestrator
# treats that as the loud skip it is, never as a pass.
suppressWarnings(suppressMessages({
  lib <- Sys.getenv("R_STAGE_LIB")
  if (nzchar(lib)) .libPaths(c(lib, .libPaths()))
  ok_sparklyr <- requireNamespace("sparklyr", quietly = TRUE)
}))
if (!ok_sparklyr) { cat("R-RUNNER SKIP (sparklyr absent)\n"); quit(status = 0) }

library(sparklyr)
suppressMessages(library(dplyr))

argv <- commandArgs(TRUE)
if (length(argv) != 2) stop("usage: Rscript conformance_runner.R <case_env.R> <out.tsv>")
here <- normalizePath(file.path(dirname(sub("--file=", "", grep("--file=", commandArgs(FALSE), value = TRUE))), ".."))
# THE SAME FILES AS run_rwdp.R, IN THE SAME ORDER. This sourced config/cases/stages only, and
# cases.R's own note says the load order is "vocabularies.R then codelists.R BEFORE this file …
# run_rwdp.R has always sourced them in that order, and every parity harness now does too" — this
# harness did not, so the claim was true of every harness except the one that runs the stages.
# `.sql_str` lives in codelists.R, and codelists.R depends on vocabularies.R, so the first case to
# reach a quoted literal died with "could not find function". Sourcing the production list is the
# fix AND the point: a conformance harness that loads a different engine than production is
# comparing something production does not run.
for (f in c("vendors.R", "vocabularies.R", "config.R", "codelists.R", "cases.R", "stages.R"))
  source(file.path(here, "engine-r", f))
source(argv[[1]])                                   # defines `case`

spark_home <- Sys.getenv("SPARK_HOME_PY")
if (!nzchar(spark_home)) { cat("R-RUNNER SKIP (SPARK_HOME_PY not set)\n"); quit(status = 0) }
# THE VERSION IS READ FROM THE PACKAGE, NOT ASKED OF AN INTERPRETER. This shelled out to
# `python3` and then `python`, and on the CI runner BOTH came back empty while the step
# immediately before had just proved `python3 -c "import pyspark"` works — so every conformance
# case reported "R half REQUIRED and unavailable (pyspark version undetectable)" and the R half,
# the only reason this lane exists, silently did not run at all. A subprocess inherits a PATH this
# script does not control; the package ON DISK is what we were actually asking about, and
# SPARK_HOME_PY already points at it. Read version.py directly, keep the interpreters as fallbacks.
ver_lines <- if (file.exists(file.path(spark_home, "version.py"))) {
  readLines(file.path(spark_home, "version.py"), warn = FALSE)
} else character(0)
hits <- regmatches(ver_lines, regexpr("[0-9]+[.][0-9]+[.][0-9]+", ver_lines))
spark_ver <- if (length(hits)) trimws(hits[[1]]) else ""
for (py in c("python3", "python")) {
  if (nzchar(spark_ver) && !is.na(spark_ver)) break
  spark_ver <- tryCatch(
    # shQuote, because `system2` does NOT shell-quote its arguments: unquoted, the runner ran
    # `'python3' -c import pyspark; print(pyspark.__version__)` and `sh` failed on the parentheses
    # ("Syntax error: word unexpected"). Latent here — version.py answers first — but a fallback
    # that cannot work is not a fallback.
    trimws(system2(py, c("-c", shQuote("import pyspark; print(pyspark.__version__)")),
                   stdout = TRUE, stderr = FALSE)[1]),
    error = function(e) "")
}
# ...and the skip NAMES WHAT IT TRIED. "undetectable" told a reader nothing about which of the
# three routes failed, which is why this cost a CI round trip to diagnose.
if (!nzchar(spark_ver) || is.na(spark_ver)) {
  cat(sprintf("R-RUNNER SKIP (pyspark version undetectable: version.py %s; python3 %s; python %s)\n",
              if (length(ver_lines)) "read but no version matched" else "absent",
              if (nzchar(Sys.which("python3"))) "on PATH" else "NOT on PATH",
              if (nzchar(Sys.which("python"))) "on PATH" else "NOT on PATH"))
  quit(status = 0)
}
Sys.setenv(SPARK_VERSION = spark_ver)
# `sparklyr.log.console` streams the gateway JVM's own stdout/stderr to this console as it
# happens. Without it a JVM that dies during the handshake reports only R's side of the
# broken socket -- `writeBin ... ignoring SIGPIPE` -- which names the symptom and hides
# every cause.
#
# AND THE CONNECT IS RETRIED, because that death is INTERMITTENT and this lane makes fourteen
# connects per run: one here, plus one per conformance case. Diagnosed on 2026-08-30 rather than
# guessed. On a single run twelve of thirteen cases connected and `passthrough_sex` did not; in the
# same job, the failure-branch diagnostic launched the very same gateway class by hand, and it bound
# port 8880 and waited for a client perfectly normally. So the gateway JVM is healthy and it is the
# R client's handshake that occasionally loses its socket. One connect is not a reliable operation,
# and fourteen unreliable ones make a red run likely even when nothing is wrong with the engines.
#
# RETRIED LOUDLY, which is the part that matters. Every failed attempt prints, and a success after
# the first prints the attempt count, so a run that needed three goes cannot be mistaken for one
# that needed none. A silent retry is exactly how a degrading runner keeps showing a green tick --
# the same class of defect as a suite that skips and reports success.
.connect_retrying <- function(attempts = 2L, ...) {
  for (i in seq_len(attempts)) {
    sc <- tryCatch(sparklyr::spark_connect(...), error = function(e) e)
    if (!inherits(sc, "condition")) {
      if (i > 1L) cat(sprintf("  spark_connect succeeded on attempt %d of %d\n", i, attempts))
      return(sc)
    }
    cat(sprintf("  spark_connect attempt %d of %d FAILED: %s\n", i, attempts,
                conditionMessage(sc)))
    if (i < attempts) Sys.sleep(5 * i)
  }
  stop(sprintf("spark_connect failed on all %d attempts", attempts))
}

sc <- .connect_retrying(
  master = "local[1]", method = "shell", spark_home = spark_home,
  config = list("sparklyr.shell.driver-memory" = "1g",
                "sparklyr.log.console" = TRUE,
                "spark.sql.shuffle.partitions" = "1",
                "spark.sql.session.timeZone" = "UTC",
                "spark.sql.ansi.enabled" = "false",
                "spark.sql.legacy.timeParserPolicy" = "CORRECTED",
                "spark.sql.caseSensitive" = "false"))

# --- typed frame from a case table (columns/types/rows; null cells arrive as NULL) -------------
case_frame <- function(sc, tbl, name) {
  cols <- unlist(tbl$columns); types <- unlist(tbl$types)
  n <- length(cols)
  as_chr <- function(rows, j) vapply(rows, function(r) {
    v <- r[[j]]; if (is.null(v)) NA_character_ else as.character(v)
  }, character(1))
  df <- as.data.frame(setNames(lapply(seq_len(n), function(j) {
    v <- if (length(tbl$rows)) as_chr(tbl$rows, j) else character(0)
    switch(types[[j]],
           string = v,
           date = as.Date(v),
           int = as.integer(v),
           double = as.numeric(v),
           boolean = as.logical(toupper(v)),
           stop(sprintf("unknown column type '%s'", types[[j]])))
  }), cols), optional = TRUE, stringsAsFactors = FALSE)
  copy_to(sc, df, name, overwrite = TRUE)
}

# --- pack/codelist shadow: the case IS the file, already parsed --------------------------------
if (!is.null(case$packs)) {
  case_packs <- case$packs
  cfg_pack <- function(cfg, role) {
    p <- case_packs[[role]]
    if (is.null(p)) stop(sprintf("no variable pack for role '%s' in the conformance case", role))
    p
  }
}
if (!is.null(case$codelists)) {
  case_codelists <- case$codelists
  cfg_codelist <- function(cfg, key) {
    cl <- case_codelists[[key]]
    if (is.null(cl)) stop(sprintf("no codelist for key '%s' in the conformance case", key))
    cl
  }
}

idx <- case_frame(sc, case$index, "conf_idx")
src <- list()
for (role in names(case$inputs %||% list()))
  src[[role]] <- case_frame(sc, case$inputs[[role]], paste0("conf_", gsub("[^a-z0-9]", "_", role)))

cfg_of <- function() make_config(case$config, root = NULL)
find_cohort <- function(cfg, id) {
  for (co in cfg$raw[["cohorts"]] %||% list()) if (identical(co[["id"]], id)) return(co)
  stop(sprintf("unknown cohort '%s'", id))
}

stage <- case$stage
out <- if (identical(stage, "baseline_ecog")) {
  clinical_baseline_ecog(src, idx, case$config)
} else if (identical(stage, "lab_values_panel")) {
  clinical_closest_values_panel(src, idx, case$config)
} else if (identical(stage, "metastatic_sites")) {
  clinical_metastatic_sites(src, idx, case$config)
} else if (identical(stage, "min_avail_date")) {
  clinical_min_avail_date(src, idx, case$config, case$index_source)
} else if (identical(stage, "passthrough")) {
  clinical_passthrough(src, idx, case$config, case$index_source)
} else if (identical(stage, "follow_up_and_death")) {
  clinical_follow_up_and_death(src, idx, case$config)
} else if (identical(stage, "lot_normalized")) {
  do.call(lot_normalized, c(list(src), case$config %||% list()))
} else if (identical(stage, "index_build")) {
  cfg <- cfg_of(); index_build(src, cfg, find_cohort(cfg, case$cohort))
} else if (identical(stage, "clinical_build")) {
  clinical_build(src, idx, cfg_of())
} else if (identical(stage, "treatment_build")) {
  treatment_build(src, idx, cfg_of())
} else if (identical(stage, "outcomes_build")) {
  outcomes_build(src, idx, src[["_clin"]], src[["_trt"]], cfg_of())
} else if (identical(stage, "ads_derived_build")) {
  ads_derived_build(idx, cfg_of())
} else stop(sprintf("unknown conformance stage '%s' - the dispatch is a closed set", stage))

# --- canonical form: identical rules to the Python half ----------------------------------------
collected <- collect(out)
# the TYPES row == test_stage_conformance._vocab_type: schema divergence IS conformance
# divergence (int 1 and string '1' stringify identically); decimal collects as an R double
# and maps to `double` on BOTH sides, and an unmappable class refuses rather than compares
vocab_type <- function(col) {
  if (inherits(col, "Date")) "date"
  else if (is.logical(col)) "boolean"
  else if (is.integer(col) || inherits(col, "integer64")) "int"
  else if (is.numeric(col)) "double"
  else if (is.character(col)) "string"
  else stop(sprintf("the conformance vocabulary has no mapping for class '%s'",
                    paste(class(col), collapse = "/")))
}
types_row <- paste0("#types\t",
                    paste(vapply(collected, vocab_type, character(1)), collapse = "\t"))
cells <- vapply(seq_len(nrow(collected)), function(i) {
  paste(vapply(seq_along(collected), function(j) {
    v <- collected[[j]][[i]]
    if (is.null(v) || (length(v) == 1 && is.na(v))) return("\\N")
    if (inherits(v, "Date")) return(format(v, "%Y-%m-%d"))
    if (is.logical(v)) return(if (isTRUE(v)) "true" else "false")
    if (is.integer(v) || inherits(v, "integer64")) return(as.character(v))
    if (is.numeric(v)) return(sprintf("%.10g", v))
    as.character(v)
  }, character(1)), collapse = "\t")
}, character(1))
text <- paste0(paste(colnames(collected), collapse = "\t"), "\n", types_row, "\n",
               if (length(cells)) paste0(paste(sort(cells), collapse = "\n"), "\n") else "")
con <- file(argv[[2]], open = "wb")                 # wb: no CRLF translation on any platform
writeBin(charToRaw(enc2utf8(text)), con)
close(con)
spark_disconnect(sc)
cat("R-RUNNER OK\n")
