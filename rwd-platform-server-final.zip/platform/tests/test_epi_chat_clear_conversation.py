"""Clearing test chat does not clear the scientific draft or other conversations."""
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[2]
sys.path[:0] = [str(ROOT / name) for name in ("platform/tests", "experiments/portal")]
import session_drafts as drafts
from test_epi_chat_form_prefill import EMPTY, _connect
from test_epi_portal_journeys import _healthy, _new, _portal, _product_command


def test_clear_current_conversation_preserves_fields_saved_setup_and_other_history(monkeypatch):
    calls = _connect(monkeypatch, lambda message: json.dumps({"answer": "Test conversation to remove.", "actions": []}))
    with _product_command((0, "Must not run")) as commands, _portal(role="admin", catalogue=EMPTY) as at:
        _new(at)
        at.text_input(key="np_name").set_value("MCRC 202606").run()
        at.chat_input[0].set_value("Explain this registration test.").run()
        _healthy(at)
        at.button(key="setup_save").click().run()
        before = drafts.list_setups(ROOT, "Priya", allowed_packs=[])["records"]
        assert len(before) == 1
        other_key = "flow_assistant_history_another_owner_products/oncology/other/202609"
        at.session_state[other_key] = [{"question": "Keep this", "answer": "Other conversation"}]
        button = next(item for item in at.button if item.label == "Clear this conversation")
        button.click().run()
        _healthy(at)
        assert at.session_state[drafts.history_key(ROOT, "Priya")] == []
        assert at.session_state[other_key] == [{"question": "Keep this", "answer": "Other conversation"}]
        assert at.text_input(key="np_name").value == "MCRC 202606"
        assert drafts.list_setups(ROOT, "Priya", allowed_packs=[])["records"] == before
        assert any("Conversation cleared" in item.value for item in at.success)
        assert not any("Test conversation to remove" in item.value for item in at.markdown)
        at.run()
        _healthy(at)
        assert at.session_state[drafts.history_key(ROOT, "Priya")] == []
        assert len(calls) == 1 and not commands
