"""CI must execute pytest fixtures and retain counted outcomes on both platforms."""
from pathlib import Path
import subprocess
import sys
import xml.etree.ElementTree as ET

import yaml

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "platform/tools"))
import ci_local


def test_linux_and_windows_collect_pytest_modules_and_retain_junit():
    jobs = yaml.safe_load((ROOT / ".github/workflows/rwdp-ci.yml").read_text())["jobs"]
    for name in ("test", "windows"):
        steps = jobs[name]["steps"]
        runs = [step.get("run", "") for step in steps]
        assert any("pytest==9.1.1" in run for run in runs)
        invocation = next(run for run in runs if "python -m pytest " in run)
        assert "--junitxml=" in invocation and " -q " in invocation
        for excluded in ci_local.SPARK_SUITES:
            assert "--ignore=" in invocation and excluded in invocation
        artifact = next(step for step in steps if step.get("uses", "").startswith("actions/upload-artifact@"))
        assert artifact["if"] == "always()"
        assert artifact["with"]["if-no-files-found"] == "error"
        assert artifact["with"]["path"].endswith(".xml")
        assert not any('for t in tests/test_*.py' in run for run in runs)


def test_heavy_suites_have_counted_dedicated_jobs_instead_of_running_in_the_local_pure_lane():
    jobs = yaml.safe_load((ROOT / ".github/workflows/rwdp-ci.yml").read_text())["jobs"]
    steps = jobs["spark"]["steps"]
    commands = [step.get("run", "") for step in steps]
    for suite in ci_local.SPARK_SUITES - {"test_r_parity.py"}:
        run = next(command for command in commands if suite in command)
        assert "python -m pytest" in run and "--junitxml=" in run, suite
    artifact = next(step for step in steps if step.get("uses", "").startswith("actions/upload-artifact@"))
    assert artifact["if"] == "always()" and artifact["with"]["path"].endswith("spark-*.xml")


def test_pytest_invocation_counts_fixture_cases_and_fails_an_assertion(tmp_path):
    (tmp_path / "test_fixture.py").write_text('''import pytest
@pytest.fixture
def original_error(): return 2
@pytest.mark.parametrize('expected', [2, 3])
def test_reviewed_behavior(original_error, expected):
    assert original_error == expected
''')
    report = tmp_path / "results.xml"
    result = subprocess.run([sys.executable, "-m", "pytest", str(tmp_path), "-q", "--junitxml=" + str(report)],
        cwd=tmp_path, capture_output=True, text=True, timeout=30)
    assert result.returncode == 1
    cases = list(ET.parse(report).getroot().iter("testcase"))
    assert len(cases) == 2
    assert sum(case.find("failure") is not None for case in cases) == 1


def test_zero_collected_tests_cannot_produce_a_successful_ci_exit(tmp_path):
    result = subprocess.run([sys.executable, "-m", "pytest", str(tmp_path), "-q", "--junitxml=" + str(tmp_path / "empty.xml")],
        cwd=tmp_path, capture_output=True, text=True, timeout=30)
    assert result.returncode == 5
