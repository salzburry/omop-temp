#!/usr/bin/env python3
"""The claims integration UAT harness: generation runs HERE, execution waits for prod.

Three claims, each held: (1) the generator half runs the REAL exporter over the synthetic
ovarian inputs and comes out gap-free - the UAT exercises the bridge, never a shortcut;
(2) the expectation files agree with each other - the attrition table is recomputable from
the patients' stated facts, so the two cannot drift apart silently; (3) the execution half
(run_uat.R) is structurally sound for the prod machine - it runs the governed executor with
the explicit draft flag and compares both counts and patient-level membership. R itself is
absent here and this file says so instead of simulating.

Run: python3 platform/tests/test_cohortly_uat_harness.py (or pytest).
"""
import os
import sys
import tempfile
from pathlib import Path

import yaml

FRAMEWORK = Path(__file__).resolve().parent.parent
REPO = FRAMEWORK.parent
sys.path.insert(0, str(FRAMEWORK / "tools"))
sys.path.insert(0, str(FRAMEWORK / "uat" / "cohortly"))

import make_inputs as mi                                                # noqa: E402

UAT = FRAMEWORK / "uat" / "cohortly"


def test_the_generator_half_is_gap_free_through_the_real_exporter():
    """The exporter must exit 0 over the UAT workbook + bindings: every criterion lifts
    whole, the event binds, and the manifest carries zero blocking gaps - a gap here is a
    harness defect, and exit 2 would make the UAT unrunnable before prod ever saw it."""
    with tempfile.TemporaryDirectory() as tmp:
        manifest, r_out, rv = mi.generate(tmp)
        assert rv == 0, f"the UAT's own inputs carry blocking gaps (exit {rv})"
        m = yaml.safe_load(open(manifest, encoding="utf-8"))
        assert m["manifest_version"] == 1 and m["blocking_gaps"] == []
        assert m["events"]["ovarian"]["dx_cd"]["codes"] == \
            ["C56.1", "C56.2", "C56.3", "C56.9"]
        assert m["study_specs"]["study_period_start_dt"] == "2019-01-01"
        assert m["study_specs"]["index_period_end_dt"] == "2024-12-31"
        assert m["study_specs"]["max_enrl_gap"] == 30
        calls = {c["row"].split(":", 1)[1]: c["call"] for c in m["criteria"]}
        assert calls["Criterion 1 (INCLUSION)"]["args"]["event"] == "ovarian"
        assert calls["Criterion 1 (INCLUSION)"]["args"]["op_gap_window"] == [1, 90]
        assert calls["Criterion 2 (INCLUSION)"]["args"]["min_age"] == 18
        assert calls["Criterion 3 (INCLUSION)"]["args"]["window"] == [-183, -1]
        r_text = open(r_out, encoding="utf-8").read()
        assert "UNGOVERNED DRAFT" in r_text        # gap-free is still not governance-free


def test_the_expected_attrition_is_recomputable_from_the_patient_facts():
    """The two expectation files must AGREE: applying the four stated facts in order to the
    12 patients must reproduce the attrition counts and the final ids exactly. If someone
    edits one file, this test names the drift - the expectation cannot rot silently."""
    patients = yaml.safe_load((UAT / "patients.yaml").read_text(encoding="utf-8"))["patients"]
    expected = yaml.safe_load((UAT / "expected_attrition.yaml").read_text(encoding="utf-8"))
    assert len(patients) == 12
    steps = [("qualifying_event_in_index_period",), ("age_ge_18_at_index",),
             ("baseline_ce_183_days",), ("enrollment_gap_le_30",)]
    counts = [len(patients)]
    alive = list(patients)
    for (fact,) in steps:
        alive = [p for p in alive if p[fact]]
        counts.append(len(alive))
    want = [s["patients"] for s in expected["steps"]]
    assert counts == want, (counts, want)
    final = sorted(p["id"] for p in alive)
    assert final == sorted(expected["final_patient_ids"]), (final, expected)
    # and the per-patient ground truth column agrees with the recomputation
    for p in patients:
        assert p["expected_in_cohort"] == (p["id"] in final), p


def test_the_execution_half_is_structurally_sound_for_prod():
    """No R here - said plainly - so the runner is pinned structurally: it sources the
    governed executor (never a second execution path), passes the EXPLICIT draft flag,
    records the unpinned package version out loud, and compares both the ordered counts
    and the patient-level membership."""
    runner = (UAT / "run_uat.R").read_text(encoding="utf-8")
    assert 'cohortly_manifest.R' in runner, "the runner bypasses the governed executor"
    assert "cohortly_cohort_from_manifest" in runner
    assert "allow_ungoverned = TRUE" in runner, "the draft flag must be explicit"
    assert "UNPINNED" in runner and "packageVersion" in runner
    assert "final_patient_ids" in runner and "setdiff" in runner
    assert "quit(status = 1)" in runner, "a failing UAT must exit non-zero"


if __name__ == "__main__":
    bad = 0
    for name, fn in sorted(globals().items()):
        if name.startswith("test_") and callable(fn):
            try:
                fn()
                print(f"  ok  {name}")
            except (Exception, SystemExit) as e:     # noqa: BLE001 - report and continue
                bad += 1
                print(f"FAIL  {name}: {e}")
    print("all cohortly UAT harness tests passed" if not bad else f"FAILURES: {bad}")
    sys.exit(1 if bad else 0)
