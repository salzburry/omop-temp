"""Tenth external verdict (2026-09-04, main b069816) — the platform-side findings, failing first.

  P1  the prod artifact-root guard demanded exact equality while the generated job appends
      <slug>/<refresh>, so a correctly generated production job refused itself
  P1  the committed-receipt check applied the semantic validator only; a receipt with an undeclared
      field passed CI and failed every schema consumer; released receipts could omit their fields
  P1  the site publisher wrote pages straight into the served directory (an interruption left a mix)
      and stamped only the index
  P1  the generated-code guard read one literal form and the union of every table's columns;
      SQL-expression forms and other-table columns passed; unverifiable candidates were reviewed and
      counted toward promotion; a refusal became a NoneType error in the tool wrapper

NO PYTEST FIXTURES AND NO `parametrize` — CI runs every suite as a script.
"""
import json
import os
import shutil
import sys
import tempfile
from pathlib import Path

FRAMEWORK = Path(__file__).resolve().parent.parent
ROOT = FRAMEWORK.parent
for p in (FRAMEWORK / "tools", FRAMEWORK, ROOT / "experiments" / "agent"):
    sys.path.insert(0, str(p))
os.environ.setdefault("ANTHROPIC_API_KEY", "not-a-key-tests-never-call")


def _read(rel):
    return (ROOT / rel).read_text(encoding="utf-8")


def test_the_artifact_root_rule_accepts_the_generated_child_and_nothing_else():
    import source_manifest as sm  # noqa: PLC0415
    approved = "/Volumes/cat/sch/vol/rwdp/artifacts"
    assert sm.artifact_root_accepted(approved, approved, "demo", "2026q1")[0]
    assert sm.artifact_root_accepted(approved + "/demo/2026q1", approved + "/", "demo", "2026q1")[0]
    for bad in (approved + "/other/2026q1", approved + "/demo", approved + "/demo/2026q1/extra", "/Volumes/x/y/z"):
        ok, why = sm.artifact_root_accepted(bad, approved, "demo", "2026q1")
        assert not ok and "neither" in why, (bad, why)
    assert not sm.artifact_root_accepted(approved, None, "demo", "2026q1")[0]
    rr = _read("platform/databricks/run_rwdp.py")
    assert "artifact_root_accepted(_artifact_base, _approved, tumor_slug, cfg.refresh)" in rr
    assert 'rstrip("/") != str(_approved).rstrip("/")' not in rr
    y = _read("databricks.yml")
    assert "--artifact-root /Volumes/<catalog>/<schema>/<volume>/rwdp/artifacts" in y
    assert "--var <slug>_artifact_root=/Volumes/<catalog>/<schema>/<volume>/rwdp/artifacts" in y, \
        "the deploy binds the job's artifact-root variable to the same approved root"


def test_the_receipt_check_applies_the_closed_schema_and_the_release_fields():
    import source_manifest as sm  # noqa: PLC0415
    errs = sm.release_schema_errors({"status": "released", "unexpected_release_field": 1})
    assert any("unexpected_release_field" in e for e in errs), errs
    assert all(e.startswith("JSON Schema") for e in errs)
    src = _read("platform/tools/source_manifest.py")
    i = src.index("def _check_one_receipt")
    body = src[i:i + 6000]
    assert "release_schema_errors(doc)" in body and "RELEASED_RECEIPT_FIELDS" in body
    assert sm.RELEASED_RECEIPT_FIELDS == ("supersedes", "promoted_from", "deployment")
    with tempfile.TemporaryDirectory() as d:
        p = os.path.join(d, "r.yaml")
        open(p, "w", encoding="utf-8").write("status: released\nunexpected_release_field: 1\n")
        assert sm._check_one_receipt(p) == 1


def test_the_site_is_staged_verified_and_swapped_and_every_page_is_stamped():
    import publish_site as ps  # noqa: PLC0415
    with tempfile.TemporaryDirectory() as d:
        site = os.path.join(d, "site")
        os.makedirs(site)
        open(os.path.join(site, "index.html"), "w", encoding="utf-8").write("OLD INDEX")
        calls = {"n": 0}

        def fake_run(argv, out_path):
            calls["n"] += 1
            if calls["n"] == 3:
                raise RuntimeError("interrupted")
            open(out_path, "w", encoding="utf-8").write(f"<h1>{os.path.basename(out_path)}</h1>")
            return None
        real_run, real_packs = ps._run, ps.packs
        ps._run = fake_run
        ps.packs = lambda: [("prostate", "fixtures/oncology/prostate/202606"), ("oc", "fixtures/oncology/oc/202606")]
        try:
            try:
                ps.build(site, only={"prostate", "oc"})
                raise AssertionError("an interrupted build published")
            except RuntimeError:
                pass
            assert open(os.path.join(site, "index.html"), encoding="utf-8").read() == "OLD INDEX", "the old site is whole"
            assert sorted(os.listdir(site)) == ["index.html"], os.listdir(site)
            calls["n"] = 100                                   # no more interruptions
            r = ps.build(site, only={"prostate"})
        finally:
            ps._run, ps.packs = real_run, real_packs
        assert set(r["pages"]) == {"executive.html", "prostate_flow.html", "prostate_questions.html"}
        for name in r["pages"] + ["index.html"]:
            body = open(os.path.join(site, name), encoding="utf-8").read()
            assert "commit" in body and r["commit"] in body, name
        assert not os.path.exists(site + ".building") and not os.path.exists(site + ".previous")


def test_the_code_guard_tracks_tables_and_sql_and_unverifiable_is_a_refusal():
    from contextlib import ExitStack
    from unittest.mock import patch
    import coding_agent as isolated_coding
    import state as isolated_state
    original_root = ROOT
    with tempfile.TemporaryDirectory(prefix="historical-code-audit-") as temporary, ExitStack() as scoped:
        scratch = Path(temporary)
        # The historical candidate names and every output stay in this owned
        # temporary root, including the standalone agent's promotion ledger.
        scoped.enter_context(patch.dict(globals(), {"ROOT": scratch,
            "_read": lambda relative: (original_root / relative).read_text(encoding="utf-8")}))
        scoped.enter_context(patch.object(isolated_coding, "ROOT", str(scratch)))
        scoped.enter_context(patch.object(isolated_coding, "CANDIDATES", str(scratch / "candidates")))
        scoped.enter_context(patch.object(isolated_state, "CANDIDATES", str(scratch / "candidates")))
        import coding_agent as ca  # noqa: PLC0415
        import critic  # noqa: PLC0415
        pack = "products/oncology/audit10_synthetic/202606"
        h = ROOT / pack / "handoff"
        shutil.rmtree(ROOT / "products/oncology/audit10_synthetic", ignore_errors=True)
        h.mkdir(parents=True)
        (h / "MAPPING_EVIDENCE.json").write_text(json.dumps({
            "ai_eligibility": {"state": "reviewed"},
            "tables": {"dx": {"icd_code": "code", "svc_date": "date"}, "meds": {"drug_name": "string"}}}), encoding="utf-8")
        try:
            for code in ('frames["dx"].filter(F.expr("patient_zip = 12345"))',
                         'frames["dx"].selectExpr("patient_zip")',
                         'frames["dx"].select(F.col("drug_name"))',
                         'dx = frames["dx"]\ndx.filter(dx["patient_zip"] > 1)'):
                g = ca.identifier_guard(code, pack)
                assert g["status"] == "refused", (code, g)
            ok = 'dx = frames["dx"]\nout = dx.filter(F.col("icd_code") == "C61").selectExpr("icd_code", "svc_date")\n'
            assert ca.identifier_guard(ok, pack)["status"] == "ok"
            assert ca.identifier_guard('frames["meds"].select(F.col("drug_name"))', pack)["status"] == "ok"
            # unverifiable (no evidence): not reviewed, not counted
            shutil.rmtree(h)
            calls = []
            real = critic.review
            critic.review = lambda *a, **k: calls.append(1) or {"verdict": "never"}
            ledger = os.path.join(ca.CANDIDATES, "promotion_ledger.json")
            before = open(ledger, encoding="utf-8").read() if os.path.exists(ledger) else ""

            class M:
                model = "fake"
                usage = {"calls": 0}

                def step(self, system, transcript):
                    return json.dumps({"mode": "generate", "generated": {"code": ok, "tests": "def test_x():\n    assert 1\n",
                                                                         "assumptions": []}, "summary": "s"})
            try:
                out = ca.run(pack, "PFS", model=M())
            finally:
                critic.review = real
            assert calls == [] and out["critic"] is None and "unverifiable" in out["deterministic_checks"]["identifiers"]
            after = open(ledger, encoding="utf-8").read() if os.path.exists(ledger) else ""
            assert before == after, "an unverifiable candidate never counts toward promotion"
            import tools  # noqa: PLC0415
            assert "not reviewed" in tools.t_code_candidate.__code__.co_consts.__repr__() or "not reviewed" in _read("experiments/agent/tools.py")
        finally:
            shutil.rmtree(ROOT / "products/oncology/audit10_synthetic", ignore_errors=True)


def test_the_documents_say_what_the_tree_does():
    b = _read("docs/AGENTIC_BENCHMARK.md")
    assert "the Explore and Design steps beyond intake" in b and "are NOT built" in b
    assert "fifteen scaffolded records out beside the one record" in _read("sandbox/demo_walkthrough/README.md")
    pr = _read("fixtures/oncology/prostate/README.md")
    assert "independently buildable" not in pr and "superseded but buildable" not in pr
    assert "A fixture generates NO" in pr and "run rwdp_build_prostate" not in pr
    v = tuple(int(x) for x in _read("platform/VERSION").strip().split("."))
    assert v >= (1, 264, 0)


# ------------------------------------------------------------------ the second independent review

def test_the_code_guard_reads_the_engines_column_forms_and_decides_sql_words_against_the_schema():
    import coding_agent as ca  # noqa: PLC0415
    pack = "experiments/agent/candidates/_test_pack_audit10b/202606"
    h = ROOT / pack / "handoff"
    shutil.rmtree(ROOT / "experiments/agent/candidates/_test_pack_audit10b", ignore_errors=True)
    h.mkdir(parents=True)
    (h / "MAPPING_EVIDENCE.json").write_text(json.dumps({
        "ai_eligibility": {"state": "reviewed"},
        "tables": {"dx": {"icd_code": "code", "svc_date": "date", "year": "integer"}, "meds": {"drug_name": "string"}}}),
        encoding="utf-8")
    try:
        refused = ('frames["dx"].select("patient_zip")',
                   'dx = frames["dx"]\ndx.groupBy("patient_zip").count()',
                   'dx = frames["dx"]\nout = dx.filter(dx.patient_zip > 1)',
                   'frames["dx"].withColumnRenamed("patient_zip", "zip")',
                   'frames["dx"].join(frames["meds"], "patient_zip")',
                   'dx = frames["dx"]\nout = (dx\n    .select(F.col("icd_code"))\n    .filter(F.col("drug_name").isNotNull()))',
                   'frames["dx"].selectExpr("year", "patient_zip")')
        for code in refused:
            g = ca.identifier_guard(code, pack)
            assert g["status"] == "refused", (code, g)
        ok = ('dx = frames["dx"]\nout = dx.select("icd_code", "svc_date").filter(F.expr("year >= 2020 AND icd_code = \'C61\'"))',
              'dx = frames["dx"]\nout = dx.withColumn("index_year", F.year(dx.svc_date)).select("index_year", "icd_code")',
              'dx = frames["dx"]\nout = (dx\n    .select(F.col("icd_code"))\n    .filter(F.col("svc_date").isNotNull()))',
              'frames["meds"].select("drug_name").alias("m")')
        for code in ok:
            g = ca.identifier_guard(code, pack)
            assert g["status"] == "ok", (code, g)
        assert ca.code_fields({"reuse": {"snippet": 'frames["dx"].select("patient_zip")'}, "summary": "s"}).strip()
        assert ca.code_fields({"summary": "no code here"}) == ""
    finally:
        shutil.rmtree(ROOT / "experiments/agent/candidates/_test_pack_audit10b", ignore_errors=True)


if __name__ == "__main__":
    fails = 0
    for name, fn in sorted(globals().items()):
        if name.startswith("test_") and callable(fn):
            try:
                fn()
                print(f"  ok   {name}")
            except Exception as e:  # noqa: BLE001
                fails += 1
                print(f"  FAIL {name}: {type(e).__name__}: {str(e)[:300]}")
    print(f"{fails} failure(s)")
    sys.exit(1 if fails else 0)
