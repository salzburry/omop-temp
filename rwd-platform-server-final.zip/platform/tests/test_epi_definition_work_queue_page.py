"""A compact work queue preserves each row's typing and uses current checks."""
from pathlib import Path
import json
import sys

ROOT = Path(__file__).resolve().parents[2]
sys.path[:0] = [str(ROOT / "platform/tests"), str(ROOT / "platform/tools"), str(ROOT / "experiments/portal")]
from test_epi_scientific_definition_journey_adversarial import _two_rows, _app, _visible_text, DATAV, OTHER, ACTOR, PREFIX
from test_epi_scientific_definition_page import app
from test_epi_scientific_definitions import fixture, preview, apply
import scientific_definition_page as page


def healthy(at):
    assert not at.exception, [item.message for item in at.exception]


def test_next_unfinished_wraps_and_preserves_both_rows_and_chat_context(tmp_path):
    root, pack, _product = _two_rows(tmp_path)
    at = _app(root, pack)
    at.session_state["connected_workflow"] = {"route": "scientific_draft", "pack": pack, "actor": ACTOR, "params": {}}
    at.text_area(key=PREFIX + "field_derivation").set_value("Keep first unsaved interpretation").run()
    assert "1 drafts" in _visible_text(at)
    at.button(key=PREFIX + "next_row").click().run()
    healthy(at)
    assert at.selectbox(key=PREFIX + "row").value == OTHER
    assert at.session_state["connected_workflow"]["params"]["item_id"] == OTHER
    at.text_area(key=PREFIX + "field_derivation").set_value("Keep second unsaved interpretation").run()
    at.button(key=PREFIX + "next_row").click().run()
    healthy(at)
    assert at.selectbox(key=PREFIX + "row").value == DATAV
    assert at.text_area(key=PREFIX + "field_derivation").value == "Keep first unsaved interpretation"
    assert at.session_state["connected_workflow"]["params"]["item_id"] == DATAV
    at.button(key=PREFIX + "next_row").click().run()
    assert at.text_area(key=PREFIX + "field_derivation").value == "Keep second unsaved interpretation"


def test_filtering_empty_then_returning_retains_literal_unsaved_entries(tmp_path):
    root, pack, _product = _two_rows(tmp_path)
    at = _app(root, pack)
    at.text_area(key=PREFIX + "field_derivation").set_value("Literal text\nKeep this exact spacing.").run()
    at.selectbox(key=PREFIX + "queue_filter").set_value("Checked").run()
    healthy(at)
    assert "No rows match" in _visible_text(at)
    assert not any(widget.key == PREFIX + "row" for widget in at.selectbox)
    at.selectbox(key=PREFIX + "queue_filter").set_value("Draft").run()
    healthy(at)
    assert at.selectbox(key=PREFIX + "row").value == DATAV
    assert at.text_area(key=PREFIX + "field_derivation").value == "Literal text\nKeep this exact spacing."
    at.selectbox(key=PREFIX + "queue_filter").set_value("Untouched").run()
    assert at.selectbox(key=PREFIX + "row").value == OTHER
    at.selectbox(key=PREFIX + "queue_filter").set_value("Draft").run()
    assert at.text_area(key=PREFIX + "field_derivation").value == "Literal text\nKeep this exact spacing."


def test_actor_change_removes_private_progress_and_cached_answers(tmp_path):
    root, pack, _product = _two_rows(tmp_path)
    at = _app(root, pack)
    at.text_area(key=PREFIX + "field_derivation").set_value("Private unsaved answer").run()
    assert "1 drafts" in _visible_text(at)
    at.session_state["journey_actor"] = "another-person"
    at.run()
    healthy(at)
    assert "2 untouched" in _visible_text(at)
    assert at.text_area(key=PREFIX + "field_derivation").value == ""


def test_all_checked_disables_next_but_never_claims_scientific_approval(tmp_path):
    root, pack, product, values = fixture(tmp_path)
    assert apply(root, pack, preview(root, pack, values))["ok"]
    at = app(root, pack)
    healthy(at)
    assert "1 of 1 rows checked" in _visible_text(at)
    assert "remaining scientific review" in _visible_text(at)
    assert at.button(key=PREFIX + "next_row").disabled
    at.text_area(key=PREFIX + "field_derivation").set_value("New interpretation requiring another check").run()
    assert "0 of 1 rows checked" in _visible_text(at)
    assert "unsaved edits" in _visible_text(at)
    assert "Scientific approval is a separate review" in _visible_text(at)


def test_reviewing_source_fields_without_editing_does_not_create_false_draft_progress(tmp_path):
    root, pack, _product, values = fixture(tmp_path)
    assert apply(root, pack, preview(root, pack, values))["ok"]
    at = app(root, pack)
    at.radio(key=PREFIX + "section").set_value("4 · Source and names").run()
    at.radio(key=PREFIX + "section").set_value("5 · Review").run()
    healthy(at)
    assert "1 of 1 rows checked" in _visible_text(at)
    assert "0 drafts" in _visible_text(at)


def test_empty_extraction_has_readable_next_action_and_no_false_completion(tmp_path):
    root, pack, product, _values = fixture(tmp_path)
    path = product / "spec_pipeline/out/extracted.json"
    document = json.loads(path.read_bytes())
    document["rows"] = []
    path.write_text(json.dumps(document), encoding="utf-8")
    at = app(root, pack)
    healthy(at)
    assert "0 of 0 rows checked" in _visible_text(at)
    assert "No named specification rows" in _visible_text(at)
    assert "All named rows pass" not in _visible_text(at)
    assert not at.error


def test_external_input_change_marks_open_cache_unresolved_without_losing_typing(tmp_path):
    root, pack, product = _two_rows(tmp_path)
    at = _app(root, pack)
    at.text_area(key=PREFIX + "field_derivation").set_value("Keep my original answer").run()
    path = product / "handoff/DECISIONS.md"
    path.write_text(path.read_text(encoding="utf-8") + "\nNew review context\n", encoding="utf-8")
    at.run()
    healthy(at)
    assert "1 unresolved" in _visible_text(at)
    assert at.text_area(key=PREFIX + "field_derivation").value == "Keep my original answer"
    assert "earlier inputs" in _visible_text(at)
    at.button(key=PREFIX + "reload").click().run()
    healthy(at)
    at.run()
    assert "1 drafts" in _visible_text(at)
    assert at.text_area(key=PREFIX + "field_derivation").value == "Keep my original answer"
