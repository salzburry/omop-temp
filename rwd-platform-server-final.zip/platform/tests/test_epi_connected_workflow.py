"""Every audited capability has a contextual entry, a renderer and a way forward."""
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[2]
sys.path[:0] = [str(ROOT / "platform/tests"), str(ROOT / "platform/tools"), str(ROOT / "experiments/portal")]
import connected_workflow as workflow
from test_epi_scientific_definitions import fixture


def test_audited_capabilities_are_reachable_and_routes_have_real_pages():
    assert {"reuse_and_names", "branch_persistence", "six_layer_eda", "claims_criteria", "enterprise_graph"} <= set(workflow.CAPABILITIES)
    reachable = set(r for routes in workflow.SECTIONS.values() for r in routes)
    pending = list(reachable)
    while pending:
        route = pending.pop()
        for next_route in workflow.ROUTES[route].next:
            assert next_route in workflow.ROUTES
            if next_route not in reachable:
                reachable.add(next_route)
                pending.append(next_route)
    assert set(workflow.CAPABILITIES.values()) <= reachable
    for route in workflow.ROUTES.values():
        if route.module not in {"existing", "connected_workflow"}:
            assert (ROOT / "experiments/portal" / f"{route.module}_page.py").is_file()


def test_navigation_context_never_crosses_identity_product_or_section():
    ctx = workflow.destination("variable_lineage", pack="a", actor_id="editor", origin="Flow", params={"variable": "ECOG"})
    args = {"pack": "a", "actor_id": "editor", "section": "Flow", "allowed_packs": ["a", "b"]}
    assert workflow.valid(ctx, **args)
    for field, value in [("pack", "b"), ("actor_id", "reader"), ("section", "Studies"), ("allowed_packs", [])]:
        assert not workflow.valid(ctx, **{**args, field: value})


def test_portfolio_uses_only_allowed_products(tmp_path):
    root, pack, _product, _ = fixture(tmp_path)
    assert workflow.portfolio(root, []) == {"rows": [], "problems": []}
    report = workflow.portfolio(root, [pack])
    assert not report["problems"], report
    assert all(row["pack"] == pack for row in report["rows"])


def test_portfolio_explains_unprepared_questions_without_raw_filesystem_errors(tmp_path):
    pack = "products/oncology/new_product/202609"
    (tmp_path / pack).mkdir(parents=True)
    report = workflow.portfolio(tmp_path, [pack])
    assert not report["rows"] and len(report["problems"]) == 1
    message = report["problems"][0]["message"]
    assert "not been prepared" in message and "Progress and next step" in message
    assert str(tmp_path) not in message and "Errno" not in message


def test_related_routes_do_not_reopen_another_tools_saved_artifact():
    source = {"variable": "ECOG", "study": "outcomes", "proposal_id": "standards-record", "id": "source-record"}
    assert workflow.continuation_params("clinical_standards", "definition_identity", source) == {"variable": "ECOG", "study": "outcomes"}
    assert workflow.continuation_params("clinical_standards", "clinical_standards", source) == source
    assert workflow.continuation_params("source_evidence", "source_mapping", source, {"proposal_id": "adapter-record"})["proposal_id"] == "adapter-record"


def test_question_report_reads_current_register_without_generated_report(tmp_path):
    import queues
    from test_epi_decision_answer_page import _seed, PACK
    product = _seed(tmp_path, issue_forms=False)
    generated = product / "handoff/SCIENCE_QUESTIONS.md"
    for stale_page in (None, "No open questions.\n"):
        if stale_page is not None:
            generated.write_text(stale_page, encoding="utf-8")
        report = workflow.question_report(tmp_path, PACK, allowed_packs=[PACK])
        assert report["ok"], report
        ranked = queues.fill_owners(queues.ranked_questions(report["page"]), report["register"])
        assert {row["id"] for row in ranked} == {"Q1", "Q2"}
        assert all(row["owner_display"] == "Science" for row in ranked)
    assert generated.read_text(encoding="utf-8") == "No open questions.\n"


def test_question_report_scope_and_missing_inputs_do_not_claim_no_open_questions(tmp_path):
    from test_epi_decision_answer_page import _seed, PACK
    product = _seed(tmp_path, issue_forms=False)
    denied = workflow.question_report(tmp_path, PACK, allowed_packs=[])
    assert not denied["ok"] and "outside your access" in denied["error"]
    assert not denied["page"] and not denied["register"]
    (product / "handoff/DECISIONS.md").unlink()
    missing = workflow.question_report(tmp_path, PACK, allowed_packs=[PACK])
    assert not missing["ok"] and "not been prepared" in missing["error"]
    assert str(tmp_path) not in missing["error"] and not missing["page"]


def test_question_report_refuses_malformed_register_instead_of_silently_counting_zero(tmp_path):
    from test_epi_decision_answer_page import _seed, PACK
    product = _seed(tmp_path, issue_forms=False)
    register = product / "handoff/DECISIONS.md"
    register.write_text(register.read_text(encoding="utf-8").replace("| OPEN |", "| unknowable |"), encoding="utf-8")
    report = workflow.question_report(tmp_path, PACK, allowed_packs=[PACK])
    assert not report["ok"] and "needs repair" in report["error"]
    assert not report["page"]
