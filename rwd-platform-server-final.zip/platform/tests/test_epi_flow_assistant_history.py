"""Selected proposal evidence remains separate from historical model prose."""
import copy
import hashlib
import json
from pathlib import Path
import sys

import pytest

ROOT = Path(__file__).resolve().parents[2]
sys.path[:0] = [str(ROOT / name) for name in
    ("platform/tests", "experiments/portal", "platform/tools", "experiments/agent")]
import flow_assistant as guide
from test_epi_flow_assistant import _card

PACK = "fixtures/oncology/prostate/202606"


def plan(identifier="supported-proposal", status="submitted_for_review"):
    return {**_card(), "current_task": {"route": "plan_changes"},
        "actions": ["open_plan_changes", "open_review_inbox"],
        "plan_form": {"selected_intent": "configuration", "saved_proposal": {
            "proposal_id": identifier, "status": status, "has_engineering_handoff": False,
            "next_visible_action": "Review requests" if status == "submitted_for_review" else "Run proposal validators",
            "remaining_work": "Follow this submitted snapshot in Review requests."}}}


def turn(card, *, pack=PACK):
    return {"question": "What blocks this proposal?", "answer": "Historical blocker sentinel.",
        "context_reference": guide.history_reference(card, task_scope={"pack": pack})}


@pytest.mark.parametrize("previous", ["different_proposal", "previous_state", "unreferenced", "different_pack"])
def test_provider_never_receives_other_or_stale_proposal_history(previous):
    card = plan()
    prior = turn(plan("mixed-proposal") if previous == "different_proposal" else
                 plan(status="validation_failed") if previous == "previous_state" else card,
                 pack="products/other/202606" if previous == "different_pack" else PACK)
    if previous == "unreferenced":
        prior.pop("context_reference")
    history = [prior]
    unchanged = copy.deepcopy(history)
    requests = []

    class Model:
        def step(self, system, messages):
            supplied = json.loads(messages[0]["content"])
            requests.append(supplied)
            assert "conversation" not in supplied
            assert "Historical blocker sentinel" not in messages[0]["content"]
            assert supplied["context"]["plan_form"]["saved_proposal"]["status"] == "submitted_for_review"
            return json.dumps({"answer": "Open Review requests for this submitted snapshot.", "actions": ["open_review_inbox"]})

    result = guide.answer("What next for the selected proposal?", card, model=Model(), history=history,
                          task_scope={"pack": PACK})
    assert result["source"] == "assistant" and len(requests) == 1
    assert history == unchanged


def test_current_proposal_followup_and_ordinary_nonplan_history_are_preserved():
    card = plan()
    current = turn(card)
    expected = [{"question": current["question"], "answer": current["answer"]}]
    assert guide.conversation_history(card, [current], task_scope={"pack": PACK}) == expected
    assert guide.conversation_history(_card(), expected) == expected
    assert guide.history_reference(_card()) is None


def test_plan_history_normalizes_single_pack_scope_and_handles_empty_or_malformed_scope():
    card = plan()
    expected = guide.history_reference(card, task_scope={"pack": PACK})
    assert guide.history_reference(card, task_scope={"packs": [PACK]}) == expected
    assert guide.history_reference(card, task_scope={"packs": [PACK, PACK]}) == expected
    for scope in (None, [], "bad scope", {"pack": []}, {"packs": "not a list"}, {"packs": [None]}):
        assert guide.history_reference(card, task_scope=scope)["packs"] == []


def test_plan_page_keeps_history_visible_and_displays_current_recorded_state(monkeypatch):
    from streamlit.testing.v1 import AppTest
    import flow_assistant_page as page
    requests = []

    class Model:
        def step(self, system, messages):
            requests.append(json.loads(messages[0]["content"]))
            return json.dumps({"answer": "Scripted model prose for history continuity.", "actions": []})

    monkeypatch.setattr(page, "_provider_words", lambda *_: (
        {"configured": True, "instance": Model(), "provider": "Scripted test"}, "Test connection"))
    script = f"""
import sys
sys.path[:0] = {[str(ROOT / name) for name in ('experiments/portal', 'platform/tools', 'experiments/agent')]!r}
import streamlit as st
import flow_assistant_page as page
page.render({str(ROOT)!r}, {PACK!r}, card=st.session_state['selected_card'], actor_id='test-author',
    primary=True, metadata_only=True, allowed_packs=[{PACK!r}])
"""
    at = AppTest.from_string(script)
    at.session_state["selected_card"] = plan()
    owner = hashlib.sha256((str(ROOT) + "\0test-author").encode()).hexdigest()[:20]
    key = f"flow_assistant_history_{owner}_{PACK}"
    previous = turn(plan("mixed-proposal"))
    at.session_state[key] = [previous]
    at.run()
    assert not at.exception
    assert any("Historical blocker sentinel" in text.value for text in at.markdown)
    assert any("submitted for review" in info.value and "Review requests" in info.value for info in at.info)
    assert not requests
    at.chat_input[0].set_value("What next for the selected proposal?").run()
    assert not at.exception and len(requests) == 1
    assert "conversation" not in requests[-1]
    assert at.session_state[key][0] == previous
    assert at.session_state[key][-1]["context_reference"] == guide.history_reference(plan(), task_scope={"pack": PACK})
    at.chat_input[0].set_value("Explain that next action.").run()
    assert not at.exception and len(requests) == 2
    assert requests[-1]["conversation"] == [{"question": "What next for the selected proposal?",
        "answer": "Scripted model prose for history continuity."}]
    at.session_state["selected_card"] = plan("third-proposal", "staged_unvalidated")
    at.run()
    at.chat_input[0].set_value("What next for this newly selected proposal?").run()
    assert not at.exception and len(requests) == 3
    assert "conversation" not in requests[-1]
    assert any("staged unvalidated" in info.value and "Run proposal validators" in info.value for info in at.info)
    at.run()
    assert len(requests) == 3
