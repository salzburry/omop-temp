"""The packet shows a question; it must never quietly answer one, or invent a count.

`platform/tools/decision_packet.py` is the first thing in this framework built for the person who
has to DECIDE rather than the person who builds. Three ways it could go wrong, each with a test:

  * it recounts something — a blast radius or a status computed here would be a second
    implementation of a governed number, and a stakeholder would eventually be shown a figure the
    gates disagree with;
  * it reports a pack with no register as having nothing to answer — the absence-as-clean-result
    failure this codebase has produced in six other tools;
  * it writes to the pack, or offers a signature box for an attestation the register cannot store.

Run: python3 tests/test_decision_packet.py (or pytest).
"""
import ast
import os
import sys
from pathlib import Path

FRAMEWORK = Path(__file__).resolve().parent.parent
TOOLS = FRAMEWORK / "tools"
REPO = FRAMEWORK.parent
sys.path.insert(0, str(TOOLS))
sys.path.insert(0, str(FRAMEWORK / "tests" / "fixtures"))

import _packs            # noqa: E402
import contract_lint     # noqa: E402
import decision_packet   # noqa: E402
import decision_report   # noqa: E402
import product_gates     # noqa: E402


def _with_register():
    out = [p for p in sorted(product_gates.all_packs(str(REPO)))
           if os.path.exists(os.path.join(str(REPO), p, decision_packet.DECISIONS))]
    assert out, "no pack keeps a decisions register — these tests would prove nothing"
    return out


def test_it_writes_nothing_to_the_pack():
    """Asserted on the BYTES of every register before and after rendering both forms."""
    before = {p: (Path(str(REPO)) / p / decision_packet.DECISIONS).read_bytes()
              for p in _with_register()}
    for pack in _with_register():
        decision_packet.render_text(pack, str(REPO))
        decision_packet.render_html(pack, str(REPO))
    after = {p: (Path(str(REPO)) / p / decision_packet.DECISIONS).read_bytes()
             for p in _with_register()}
    assert before == after, f"changed: {[p for p in before if before[p] != after[p]]}"


def test_a_pack_with_no_register_refuses_rather_than_reporting_nothing_to_answer():
    """`[]` means "checked, nothing open". No register means nobody can be asked anything, and the
    two must not render the same — a stakeholder reading "0 open questions" concludes they are
    finished."""
    without = [p for p in sorted(product_gates.all_packs(str(REPO)))
               if not os.path.exists(os.path.join(str(REPO), p, decision_packet.DECISIONS))]
    assert without, "every pack keeps a register — this test would prove nothing"
    items, note = decision_packet.packet(without[0], str(REPO))
    assert items == [] and note and "nothing was assembled" in note, note
    for render in (decision_packet.render_text, decision_packet.render_html):
        text = render(without[0], str(REPO))
        assert "nothing was assembled" in text
        assert "open question(s), ordered" not in text, "an unreadable pack rendered as a worklist"


def test_every_open_question_appears_on_the_ranked_page():
    """The banner counts every open decision; the body must account for every one of them —
    ranked, idle, or output-layer. A list that silently drops two questions is how they stop
    being asked (CODE-ALIGN and NAME-ALIGN were invisible on SCIENCE_QUESTIONS.md for exactly this)."""
    for pack in _with_register():
        pdir = os.path.join(str(REPO), pack)
        blocks, table, idle, status = decision_report.blast_radius(pdir)
        text = decision_report.render(pdir, blocks, table, idle, status)
        missing = [d for d, s in status.items() if s == "OPEN" and f"`{d}`" not in text]
        assert not missing, f"{pack}: OPEN decisions absent from the ranked page: {missing}"


def test_the_blast_radius_is_the_reporters_and_not_a_second_count():
    """Every number on the page comes from the tool that owns it. A packet that counted blocked
    records itself would drift from `decision_report` the first time either changed."""
    assert decision_packet.decision_report is decision_report
    assert decision_packet.contract_lint is contract_lint
    tree = ast.parse((TOOLS / "decision_packet.py").read_text(encoding="utf-8"))
    called = {n.func.attr for n in ast.walk(tree)
              if isinstance(n, ast.Call) and isinstance(n.func, ast.Attribute)}
    assert "blast_radius" in called, "the packet no longer asks decision_report"
    # ...and it agrees with the owner, per decision, on a real pack.
    for pack in _with_register():
        items, note = decision_packet.packet(pack, str(REPO))
        assert note is None
        blocking, _t, _i, _s = decision_report.blast_radius(os.path.join(str(REPO), pack))
        for d in items:
            assert d["blocks"] == sorted(blocking.get(d["id"], [])), \
                f"{pack}:{d['id']} blast radius disagrees with decision_report"


def test_it_reads_a_register_whatever_it_spells_its_columns():
    """The packs disagree — `Approved answer`/`Conflict / evidence` in one, `Resolution`/`Evidence`
    in the others. The packet must read every one of them, through the shared vocabulary rather than
    a list of its own, or a stakeholder is shown a blank question."""
    tree = ast.parse((TOOLS / "decision_packet.py").read_text(encoding="utf-8"))
    called = {n.func.attr for n in ast.walk(tree)
              if isinstance(n, ast.Call) and isinstance(n.func, ast.Attribute)}
    for accessor in ("decision_question", "decision_evidence", "decision_owner"):
        assert accessor in called, f"the packet does not read through {accessor}()"
    seen_spellings = set()
    for pack in _with_register():
        rows = contract_lint.decision_rows(
            contract_lint.read(os.path.join(str(REPO), pack, decision_packet.DECISIONS)))
        seen_spellings |= {k for k in next(iter(rows.values()))}
        items, _n = decision_packet.packet(pack, str(REPO))
        for d in items:
            assert d["question"].strip(), f"{pack}:{d['id']} rendered with an empty question"
    assert {"Approved answer", "Resolution"} & seen_spellings, \
        "the packs no longer disagree — this test would prove nothing"


def test_only_open_decisions_are_put_in_front_of_a_person_and_the_worst_comes_first():
    for pack in _with_register():
        items, _n = decision_packet.packet(pack, str(REPO))
        status = contract_lint.decision_status(
            contract_lint.read(os.path.join(str(REPO), pack, decision_packet.DECISIONS)))
        for d in items:
            assert str(status.get(d["id"], "OPEN")).strip().upper() == "OPEN", \
                f"{pack}:{d['id']} is settled but was put in front of a person again"
        counts = [len(d["blocks"]) for d in items]
        assert counts == sorted(counts, reverse=True), f"{pack}: not ranked by blast radius"


def test_the_page_directs_answers_into_the_recording_flow():
    """It offers somewhere to write an answer, so it must say plainly where the answer is RECORDED.

    The page itself still writes nothing (the bytes test above). What it must never do is collect an
    attestation into a void: every rendered page names the recording flow — the hand-typed committed
    form and the tool that transcribes it — so a person who has just decided is never left with a
    decision and no place it can land."""
    assert decision_packet.RECORDING, "the recording notice was removed"
    for pack in _with_register()[:1]:
        for render in (decision_packet.render_text, decision_packet.render_html):
            text = render(pack, str(REPO))
            assert "decision_record.py" in text, \
                f"{render.__name__} never names the tool that records an answer"
            for what, _why in decision_packet.RECORDING:
                assert what in text, f"{render.__name__} does not disclose: {what}"


def test_register_prose_cannot_inject_markup():
    """The questions are hand-written markdown and end up in HTML."""
    page = decision_packet.render_html(_with_register()[0], str(REPO))
    body = page.split("<div class='w'>", 1)[1]
    for tag in ("<script", "<iframe", "onerror="):
        assert tag not in body.lower(), f"{tag} survived into the page"


def test_it_is_not_deployed_to_production():
    import deploy_tree
    assert not any("decision_packet" in str(f) for f in deploy_tree.ROOT_FILES)




def test_the_spec_defects_are_put_in_front_of_their_owner_and_only_the_open_ones():
    """The register of the specification's own defects had readers in CI and none anywhere a
    stakeholder looks. The page splits on the register's physical structure: rows above the second
    header are Science's to correct; rows below are capture defects that are not — handing someone a
    list where a third of the rows are not theirs teaches them the list is not for them."""
    import re as _re
    import shutil
    import tempfile
    pack = "fixtures/oncology/prostate/202606"
    rwb, capture, note = decision_packet.findings(pack, str(REPO))
    assert note is None
    assert rwb and capture, "the live pack no longer has both kinds — re-choose the fixture"
    reg = Path(str(REPO)) / pack / decision_packet.SPEC_QC
    text = reg.read_text(encoding="utf-8")
    hdrs = [i for i, l in enumerate(text.splitlines())
            if l.startswith("|") and _re.search(contract_lint.id_column_re(), l)]
    assert len(hdrs) >= 2, "the register lost its two-table structure — re-read findings()"
    above = set(contract_lint.decision_rows("\n".join(text.splitlines()[:hdrs[1]])))
    assert {f["id"] for f in rwb} <= above
    assert not ({f["id"] for f in capture} & above)
    for f in rwb:
        assert f["ref"] and f["defect"], f"finding {f['id']} rendered without its citation or text"

    # a corrected finding leaves the page — the list only ever shrinks
    with tempfile.TemporaryDirectory() as tmp:
        root = Path(tmp)
        dst = root / pack
        dst.parent.mkdir(parents=True)
        shutil.copytree(Path(str(REPO)) / pack, dst,
                        ignore=shutil.ignore_patterns("__pycache__", "reference"))
        gone = rwb[0]["id"]
        reg2 = dst / decision_packet.SPEC_QC
        row = next(l for l in reg2.read_text(encoding="utf-8").splitlines()
                   if l.startswith(f"| {gone} |"))
        reg2.write_text(reg2.read_text(encoding="utf-8").replace(
            row, row.replace("**open**", "**corrected**")), encoding="utf-8")
        rwb2, _c2, _n2 = decision_packet.findings(pack, str(root))
        assert gone not in {f["id"] for f in rwb2}, "a corrected finding is still being reported"

    # ...and both renders carry the section plus the convergence promise
    for render in (decision_packet.render_text, decision_packet.render_html):
        page = render(pack, str(REPO))
        assert "DEFECTS IN THE SPECIFICATION ITSELF" in page or \
            "Defects in the specification itself" in page, render.__name__
        for f in rwb:
            assert f["id"] in page, f"{render.__name__} dropped finding {f['id']}"
        assert "waive" in page, f"{render.__name__} does not offer the terminal choice — without " \
            "it the correction loop reads as endless"


def test_other_product_evidence_is_products_only_and_decided_only():
    """An external review found a parked TEST FIXTURE's register — including still-OPEN questions —
    rendered under "What other products decided". Two exclusions, each asserted: a pack outside
    products/ never appears, and a row that is not RESOLVED never appears, because the heading's
    verb is a claim about what it shows.

    PROVEN ON A SYNTHETIC STORE, because the live one no longer contains either kind of row to
    filter. `precedents.errors()` now refuses a fixture citation outright, so the products-only
    branch is unreachable from real data — and a check whose subject has been removed elsewhere is
    a check that passes because there is nothing left to catch. The store's own exclusion is not a
    substitute for this one: two tools, two rules, and the packet must stand up on its own if the
    store's ever relaxes.
    """
    pack = "fixtures/oncology/prostate/202606"

    # THE LIVE HALF: whatever the store holds today, nothing outside products/ and nothing
    # unresolved reaches the packet.
    for did, rows in decision_packet._elsewhere(pack, str(REPO)).items():
        for opack, odid, status, _answer in rows:
            assert opack.startswith("products/"), \
                f"{did}: {opack} is not a product — a fixture's register is nobody's precedent"
            assert status == "RESOLVED", \
                f"{did}: {opack}/{odid} is {status!r} — an unanswered question shown as decided"

    # THE SYNTHETIC HALF: a store that DOES cite a non-product pack, and one that cites an OPEN
    # row. Each must be filtered, and the legitimate citation beside it must still come through —
    # otherwise a filter that dropped everything would pass both assertions.
    #
    # The non-product register here is WRITTEN, not copied, and its row is RESOLVED. The real
    # parked fixture has no resolved decision at all, so copying it would let the RESOLVED filter
    # fire first and the products-only assertion would pass without ever being exercised — a test
    # green for the wrong reason, which is the failure mode this whole review round is about.
    import shutil
    import tempfile
    import yaml as _yaml
    root = tempfile.mkdtemp()
    try:
        os.makedirs(os.path.join(root, "governance"))
        # citations speak the GOVERNED shape (products/...); the registers behind them are
        # copied from the fixture packs' live homes - a fixtures/ citation is filtered AS a
        # fixture, which is an exclusion under test, never the legitimate row beside it
        OC_CITE = "products/oncology/oc/202606"
        for dst, src_rel in ((pack, pack), (OC_CITE, "fixtures/oncology/oc/202606")):
            os.makedirs(os.path.join(root, dst, "handoff"), exist_ok=True)
            shutil.copy(os.path.join(str(REPO), src_rel, "handoff", "DECISIONS.md"),
                        os.path.join(root, dst, "handoff", "DECISIONS.md"))
            with open(os.path.join(root, dst, "handoff", "MATURITY.yaml"), "w",
                      encoding="utf-8", newline="\n") as mh:
                mh.write("contract: not_started\nconfiguration: not_started\n")
        os.makedirs(os.path.join(root, _packs.PARKED_REL, "handoff"), exist_ok=True)
        with open(os.path.join(root, _packs.PARKED_REL, "handoff", "DECISIONS.md"), "w",
                  encoding="utf-8", newline="\n") as fh:
            fh.write("| ID | Question | Status | Approved answer |\n|---|---|---|---|\n"
                     "| MAXINDEX-DATE | what is the latest index date? | **RESOLVED** | "
                     "a fixture's answer, which is nobody's precedent |\n")

        def store(*seen):
            with open(os.path.join(root, "governance", "precedents.yaml"), "w",
                      encoding="utf-8", newline="\n") as fh:
                _yaml.safe_dump({"precedents": [{"id": "a-b", "question": "q", "seen_in": list(seen)}]},
                                fh)
            return decision_packet._elsewhere(pack, root).get("MAXINDEX", [])

        mine = {"pack": pack, "decision": "MAXINDEX"}                       # RESOLVED
        fixture = {"pack": _packs.PARKED_REL, "decision": "MAXINDEX-DATE"}
        open_row = {"pack": OC_CITE, "decision": "OC-FU-END-DEFINITION"}
        decided = {"pack": OC_CITE, "decision": "OC-PSOC-SHEET"}   # RESOLVED

        got = store(mine, decided)
        assert [r[0] for r in got] == [OC_CITE], \
            f"the control case shows nothing — every later assertion would pass vacuously: {got}"

        assert store(mine, fixture) == [], \
            "a fixture's register rendered as what another PRODUCT decided"
        assert store(mine, open_row) == [], \
            "an OPEN question elsewhere rendered under a heading that says `decided`"
        # ...and the two exclusions do not take the legitimate row with them.
        assert [r[0] for r in store(mine, fixture, open_row, decided)] == [OC_CITE]
    finally:
        shutil.rmtree(root, ignore_errors=True)


def test_a_proposal_exists_only_when_exactly_one_product_has_ruled():
    """THE LINE THIS FEATURE MUST NOT CROSS: the tool never decides. A proposal is a recorded
    ruling CARRIED, so it exists in exactly one case — one other product, RESOLVED, answered.
    Zero rulings propose nothing (drafting from evidence prose would be this tool interpreting a
    specification, which is Science's act); two rulings propose nothing and SAY why, because choosing
    which product's ruling transfers is precisely the judgment the page routes to a person —
    and comparing their texts for "agreement" would be prose interpretation wearing a helpful
    face."""
    one = [("fixtures/oncology/oc/202606", "OC-X", "RESOLVED", "null, never 17")]
    got = decision_packet._proposal(one)
    assert got == {"answer": "null, never 17", "source": "fixtures/oncology/oc/202606 · OC-X"}, got
    assert decision_packet._proposal([]) is None
    two = one + [("fixtures/oncology/cll/202606", "CLL-X", "RESOLVED", "17, never null")]
    got = decision_packet._proposal(two)
    assert "answer" not in got and len(got["conflict"]) == 2, got
    # ...and a ruling with an EMPTY answer is not a basis — a status word is not a ruling
    blank = [("fixtures/oncology/oc/202606", "OC-X", "RESOLVED", "  ")]
    assert decision_packet._proposal(blank) is None


def test_the_proposal_renders_only_under_its_own_label_and_names_its_source():
    """A proposed answer that renders without its label IS an answer to a reader in a hurry —
    the whole safety of the feature is the adjacency of the words "for you to accept or edit"
    and "your name goes on it either way". Held on both renderers over a synthetic pack whose
    store pairs exactly one resolved ruling."""
    import shutil
    import tempfile
    import yaml as _yaml
    pack = "fixtures/oncology/prostate/202606"
    root = tempfile.mkdtemp()
    try:
        os.makedirs(os.path.join(root, "governance"))
        # citations speak the GOVERNED shape (products/...); the registers behind them are
        # copied from the fixture packs' live homes - a fixtures/ citation is filtered AS a
        # fixture, which is an exclusion under test, never the legitimate row beside it
        OC_CITE = "products/oncology/oc/202606"
        for dst, src_rel in ((pack, pack), (OC_CITE, "fixtures/oncology/oc/202606")):
            os.makedirs(os.path.join(root, dst, "handoff"), exist_ok=True)
            shutil.copy(os.path.join(str(REPO), src_rel, "handoff", "DECISIONS.md"),
                        os.path.join(root, dst, "handoff", "DECISIONS.md"))
            with open(os.path.join(root, dst, "handoff", "MATURITY.yaml"), "w",
                      encoding="utf-8", newline="\n") as mh:
                mh.write("contract: not_started\nconfiguration: not_started\n")
        with open(os.path.join(root, "governance", "precedents.yaml"), "w",
                  encoding="utf-8", newline="\n") as fh:
            _yaml.safe_dump({"precedents": [{"id": "a-b", "question": "q", "seen_in": [
                # ABSENT-LINE-CATEGORY is OPEN in prostate - packet() only renders OPEN cards,
                # and the first draft of this test paired the RESOLVED MAXINDEX, whose card never
                # renders, so the proposal assertions could not fire at all.
                {"pack": pack, "decision": "ABSENT-LINE-CATEGORY"},
                {"pack": OC_CITE, "decision": "OC-PSOC-SHEET"}]}]}, fh)
        html_page = decision_packet.render_html(pack, root)
        text_page = decision_packet.render_text(pack, root)
    finally:
        shutil.rmtree(root, ignore_errors=True)
    for page, label in ((html_page, "Proposed — for you to accept or edit"),
                        (text_page, "PROPOSED — FOR YOU TO ACCEPT OR EDIT")):
        assert label in page, "one product ruled and no proposal rendered"
        assert "your name goes on it either way" in page, \
            "the ownership sentence is missing — without it the proposal reads as an answer"
        assert "adopted verbatim from" in page
    # the proposal quotes the ruling, and the ruling text appears AFTER the label, never before
    i = html_page.index("Proposed — for you to accept or edit")
    src = html_page.index("adopted verbatim from")
    assert i < src, "the source line renders before the label that makes it a proposal"


def test_every_card_names_its_own_answer_form():
    """"Whoever sent you this page can hand you the forms" made every reader ask WHICH form.
    Each card now names its file, and says when it is not scaffolded yet rather than pointing
    at a path that is not there as though it were."""
    items, note = decision_packet.packet("fixtures/oncology/prostate/202606", str(REPO))
    assert note is None and items
    for d in items:
        form = d["form"]
        assert form["path"].endswith(f"decision_answers/{d['id']}.yaml"), form
        assert form["exists"] == os.path.exists(os.path.join(str(REPO), form["path"])), form
    page = decision_packet.render_text("fixtures/oncology/prostate/202606", str(REPO))
    assert "YOUR FORM" in page


if __name__ == "__main__":
    os.chdir(FRAMEWORK)
    fns = [v for k, v in sorted(globals().items()) if k.startswith("test_")]
    for fn in fns:
        fn()
        print(f"ok  {fn.__name__}")
    print(f"\n{len(fns)} tests passed")
