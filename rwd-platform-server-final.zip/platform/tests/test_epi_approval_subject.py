"""Approval subjects bind digest values, including sequential real SSH reviewers."""
from __future__ import annotations

import copy
import json
import shutil
import subprocess
import sys
from pathlib import Path

import pytest
import yaml

sys.path.insert(0, str(Path(__file__).resolve().parent))
from test_epi_review_setup import PACK, WHO, identity, repository, review, enrol_test_key


def test_two_independent_ssh_reviewers_keep_both_approvals_over_unchanged_release(repository):
    root, key = repository
    rel = PACK + "/handoff/RELEASE_APPROVAL.yaml"
    original = yaml.safe_load((root / rel).read_text(encoding="utf-8"))
    first = review.perform(root, review.snapshot(root, PACK, "release"), WHO, "reviewer@example.test", key,
                           confirm=lambda _preview: True)
    assert first["ok"]
    first_commit = review._git(root, "rev-parse", "HEAD")
    key2 = root.parent / "independent-reviewer-key"
    created = subprocess.run([shutil.which("ssh-keygen"), "-t", "ed25519", "-N", "", "-f", str(key2)], capture_output=True, text=True, encoding="utf-8")
    assert created.returncode == 0, created.stderr
    enrol_test_key(root, key2, "Other Reviewer")
    second = review.perform(root, review.snapshot(root, PACK, "release"), "Other Reviewer", "independent@example.test", key2,
                            confirm=lambda _preview: True)
    assert second["ok"]
    rows, errors = identity.audit(str(root), files=lambda path: path == rel)
    assert not errors and len(rows) == 2, (rows, errors)
    assert all(row["signature_verified"] and not row["authenticated"] for row in rows), rows
    assert {row["who"] for row in rows} == {WHO, "Other Reviewer"}
    assert len({row["commit"]["sha"] for row in rows}) == 2
    assert next(row for row in rows if row["who"] == WHO)["commit"]["sha"] == first_commit
    assert yaml.safe_load((root / rel).read_text(encoding="utf-8"))["approved_manifest_sha256"] == original["approved_manifest_sha256"]
    # Neither signer is allowed to approve a later substituted release manifest.
    doc = yaml.safe_load((root / rel).read_text(encoding="utf-8"))
    doc["approved_manifest_sha256"] = "c" * 64
    (root / rel).write_text(yaml.safe_dump(doc), encoding="utf-8")
    rows, errors = identity.audit(str(root), files=lambda path: path == rel)
    assert not errors and all(not row["authenticated"] and "moved after" in row["why"] for row in rows)


def test_older_subject_and_later_quote_or_comment_changes_are_not_subject_changes(repository):
    root, _key = repository
    rel = PACK + "/handoff/CONTRACT_APPROVAL.yaml"
    path = root / rel
    doc = yaml.safe_load(path.read_text(encoding="utf-8"))
    doc["approved_by"] = "New Reviewer"
    path.write_text(yaml.safe_dump(doc), encoding="utf-8")
    review._git(root, "add", rel)
    review._git(root, "commit", "-m", "Approval over previously recorded digest")
    approved = review._git(root, "rev-parse", "HEAD")
    assert identity.subject_moved(str(root), rel, approved) == []
    path.write_text("# Reformat without changing the subject\napproved_by: New Reviewer\napproved_contract_sha256: '" + doc["approved_contract_sha256"] + "'\n", encoding="utf-8")
    assert identity.subject_moved(str(root), rel, approved) == []
    review._git(root, "add", rel)
    review._git(root, "commit", "-m", "Quoted digest stays the same")
    assert identity.subject_moved(str(root), rel, approved) == []


def test_added_deleted_and_nested_digest_changes_fail_even_before_commit(repository):
    root, _key = repository
    rel = PACK + "/source_refs.yaml"
    path = root / rel
    doc = {"source_materials": [{"material_id": "spec", "approved_by": WHO, "sha256": "a" * 64},
                                {"material_id": "protocol", "sha256": "b" * 64}],
           "approved_bundle_sha256": "c" * 64}
    path.write_text(yaml.safe_dump(doc), encoding="utf-8")
    review._git(root, "add", rel); review._git(root, "commit", "-m", "Bind explicit source hashes")
    approved = review._git(root, "rev-parse", "HEAD")
    assert identity.subject_moved(str(root), rel, approved) == []
    variants = []
    changed = copy.deepcopy(doc); changed["source_materials"][0]["sha256"] = "d" * 64
    variants.append((changed, "source_materials[0].sha256"))
    removed = copy.deepcopy(doc); del removed["source_materials"][1]["sha256"]
    variants.append((removed, "source_materials[1].sha256"))
    added = copy.deepcopy(doc); added["new_subject_sha256"] = "e" * 64
    variants.append((added, "new_subject_sha256"))
    removed_top = copy.deepcopy(doc); del removed_top["approved_bundle_sha256"]
    variants.append((removed_top, "approved_bundle_sha256"))
    for index, (variant, expected) in enumerate(variants):
        path.write_text(yaml.safe_dump(variant), encoding="utf-8")
        assert expected in dict(identity.subject_moved(str(root), rel, approved))
        review._git(root, "add", rel); review._git(root, "commit", "-m", f"Mutated subject {index}")
        assert expected in dict(identity.subject_moved(str(root), rel, approved))
    path.write_text(yaml.safe_dump(doc), encoding="utf-8")
    assert identity.subject_moved(str(root), rel, approved) == []  # original approved bytes restored
    path.write_text(json.dumps(doc, indent=2), encoding="utf-8")
    assert identity.subject_moved(str(root), rel, approved) == []  # JSON is YAML; same fields/values


def test_malformed_missing_ambiguous_or_unavailable_subject_fails_closed(repository):
    root, _key = repository
    rel = PACK + "/handoff/CONTRACT_APPROVAL.yaml"
    path = root / rel
    approved = review._git(root, "rev-parse", "HEAD")
    original = path.read_bytes()
    for contents in ("[broken", "approved_by: Test Reviewer\napproved_contract_sha256: a\napproved_contract_sha256: b\n",
                     "value: &subject a\napproved_contract_sha256: *subject\n", "[]", ""):
        path.write_text(contents, encoding="utf-8")
        assert identity.subject_moved(str(root), rel, approved), contents
    path.unlink()
    assert identity.subject_moved(str(root), rel, approved)
    path.write_bytes(original)
    assert identity.subject_moved(str(root), rel, "0" * 40)


if __name__ == "__main__":
    raise SystemExit(pytest.main([__file__, "-q"]))
