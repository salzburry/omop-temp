"""The complete portal connects sidebar feedback and study drafts to shared chat."""
import json
from pathlib import Path
import sys
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[2]
sys.path[:0] = [str(ROOT / "platform/tests"), str(ROOT / "experiments/portal"),
               str(ROOT / "platform/tools"), str(ROOT / "experiments/agent")]

from test_epi_chat_form_prefill import EMPTY, _connect
from test_epi_portal_journeys import _portal, _study_portal, _healthy, _command
import workflow_improvement

FEEDBACK = {
    "What happened or worked well?": "Returning from source review opened the first definition.",
    "What should the assistant do next time?": "Keep the selected row when returning to its definition.",
    "When should this guidance apply?": "Returning from source review to scientific drafting.",
    "An example request to test": "Return to the definition I selected.",
}
FEEDBACK_KEYS = dict(zip(FEEDBACK, ("wrong", "right", "applies", "goal")))


def response_for(values, *, exclude=()):
    def response(message):
        form = message["context"]["editable_form"]
        labels = {field["label"] for field in form["fields"]}
        assert set(values) <= labels
        assert not set(exclude) & labels
        return json.dumps({"answer": "Review the prepared draft fields. Saving remains your separate action.", "actions": [],
            "prefill": {"scope": form["scope"], "fields": [
                {"id": field["id"], "value": values[field["label"]]} for field in form["fields"] if field["label"] in values]}})
    return response


def test_full_app_sidebar_feedback_is_captured_after_begin_and_prefilled_without_saving(monkeypatch):
    calls = _connect(monkeypatch, response_for(FEEDBACK))
    with patch.object(workflow_improvement, "propose") as save, _portal(role="admin", catalogue=EMPTY) as at:
        for suffix in FEEDBACK_KEYS.values():
            assert at.text_area(key="workflow_improvement_step_" + suffix).value == ""
        at.chat_input[0].set_value("Prepare my reusable feedback: the first row reopened; next time retain the selected definition after source review.").run()
        _healthy(at)
        for label, suffix in FEEDBACK_KEYS.items():
            assert at.text_area(key="workflow_improvement_step_" + suffix).value == FEEDBACK[label]
        assert not at.checkbox(key="workflow_improvement_step_confirm_save").value
        assert at.button(key="workflow_improvement_step_save").disabled
        at.run()
        _healthy(at)
        assert len(calls) == 1
        save.assert_not_called()


def test_full_app_sidebar_existing_feedback_requires_reviewed_replacement(monkeypatch):
    changed = {"What should the assistant do next time?": "Keep the current row and its unfinished interpretation."}
    calls = _connect(monkeypatch, response_for(changed))
    with patch.object(workflow_improvement, "propose") as save, _portal(role="admin", catalogue=EMPTY) as at:
        key = "workflow_improvement_step_right"
        at.text_area(key=key).set_value("My earlier feedback draft.").run()
        at.chat_input[0].set_value("Rewrite the reusable feedback to keep the row and unfinished interpretation.").run()
        _healthy(at)
        assert at.text_area(key=key).value == "My earlier feedback draft."
        assert any(item.value.to_dict("records") == [{"Field": "What should the assistant do next time?",
            "Current": "My earlier feedback draft.", "Suggested": changed["What should the assistant do next time?"]}]
            for item in at.dataframe)
        at.button(key="chat_form_replace").click().run()
        _healthy(at)
        assert at.text_area(key=key).value == changed["What should the assistant do next time?"]
        assert not at.checkbox(key="workflow_improvement_step_confirm_save").value
        assert len(calls) == 1
        save.assert_not_called()


def test_full_app_study_rationale_and_definition_prefill_without_recording_decision(monkeypatch):
    import scientific_definition_ai as ai
    monkeypatch.setattr(ai.definitions.cs, "ai_gate", lambda *_: None)  # synthetic source eligibility, scripted model only
    values = {"Why": "This study needs a baseline performance score before index.",
        "The study's own definition (reconsider only)": "Use the closest pre-index score; resolve tied records during scientific review."}
    calls = _connect(monkeypatch, response_for(values, exclude=("Decision", "Your name", "Date (YYYY-MM-DD)", "Exact published build (optional)")))
    with _command("study_pin.py", (0, "must not execute")) as commands, _study_portal(["outcomes", "treatment_patterns"], role="admin") as (at, _):
        at.selectbox(key="dec_var").set_value("ECOG").run()
        before_decision = at.selectbox(key="dec_decision").value
        at.chat_input[0].set_value("Prepare the study's Why and own definition: use the closest score before index and leave ties open for scientific review.").run()
        _healthy(at)
        assert at.text_input(key="dec_why").value == values["Why"]
        assert at.text_area(key="dec_defn").value == values["The study's own definition (reconsider only)"]
        assert at.selectbox(key="dec_decision").value == before_decision
        assert at.text_input(key="dec_by").value == at.text_input(key="dec_date").value == ""
        assert not at.checkbox(key="dec_revise").value
        assert len(calls) == 1 and not commands
        at.selectbox(key="dec_study").set_value("treatment_patterns").run()
        _healthy(at)
        assert at.text_input(key="dec_why").value == at.text_area(key="dec_defn").value == ""
        assert len(calls) == 1 and not commands
