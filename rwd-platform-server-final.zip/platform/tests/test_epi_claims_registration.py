"""A claims stand-up is a validated draft registration without an EHR job."""
from pathlib import Path
import shutil
import sys

import yaml

ROOT = Path(__file__).resolve().parents[2]
sys.path[:0] = [str(ROOT / "platform/tests"), str(ROOT / "platform/tools")]
from test_new_product import _copy_repo, _tool, BASE


def test_claims_registration_runs_existing_validators_without_an_ehr_activation():
    root = _copy_repo()
    try:
        before = Path(root, "products/activation.yaml").read_bytes()
        args = list(BASE)
        args[args.index("ehr")] = "claims"
        code, output = _tool(root, "bladder_claims_portal", "--tumour-family", "bladder", *args, "--apply")
        assert code == 0, output[-2500:]
        pack = Path(root, "products/oncology/bladder_claims_portal/202609")
        assert pack.is_dir() and (pack / "source_refs.yaml").is_file()
        assert Path(root, "products/activation.yaml").read_bytes() == before
        registry = yaml.safe_load(Path(root, "products/registry.yaml").read_bytes())
        entry = next(row for row in registry["tumors"] if row["slug"] == "bladder_claims_portal")
        assert entry["modality"] == "claims" and entry["status"] == "scaffold"
        assert "every validator passed" in output and "Claims cohort workflow" in output
        assert "No EHR activation block" in output and "release remain unavailable" in output
    finally:
        shutil.rmtree(Path(root).parent, ignore_errors=True)
