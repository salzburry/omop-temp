"""Created-product dependencies can travel in an explicit scoped local checkpoint."""
from pathlib import Path
import hashlib
import json
import sys
import shutil

import pytest
from streamlit.testing.v1 import AppTest
import yaml

ROOT = Path(__file__).resolve().parents[2]
sys.path[:0] = [str(ROOT / "platform/tests"), str(ROOT / "experiments/portal"), str(ROOT / "platform/tools")]
from test_epi_local_branch_workspace import checkout, git, state, PACK, ACTOR, workspace


def test_shared_correction_can_travel_with_explicit_branch_review(checkout):
    import workflow_improvement
    shutil.copytree(ROOT / ".claude/skills", checkout / ".claude/skills")
    row = workflow_improvement.propose(checkout, ACTOR, "questions",
        "A follow-up forgot its selected option.", "Keep the selected option during a follow-up.",
        "General question editor behavior.", "How can I revise option two?", confirmed=True, can_write=True)
    relative = "experiments/agent/knowledge/corrections/" + row["id"] + ".yaml"
    assert relative not in state(checkout)["offered"]
    preview = state(checkout, can_manage_shared=True)
    assert relative in preview["shared_selected"]
    assert "Keep the selected option" in preview["diff"]
    with pytest.raises(ValueError, match="shared-file"):
        checkpoint(checkout, preview, confirmed_shared=False)
    saved = checkpoint(checkout, preview)
    assert saved["ok"] and relative in saved["paths"]
    assert "status: proposed" in git(checkout, "show", "HEAD:" + relative)


@pytest.fixture
def created(checkout):
    root = checkout
    shared = root / "products/registry.yaml"
    shared.write_text("tumors:\n  - {slug: other_product, code: other}\n", encoding="utf-8")
    git(root, "add", "products/registry.yaml")
    git(root, "commit", "-m", "Existing unrelated registration")
    shared.write_text(shared.read_text(encoding="utf-8") + "  - {slug: local_test, code: local_test}\n", encoding="utf-8")
    source = root / PACK / "source_refs.yaml"
    workbook = root / PACK / "prog_spec/program.xlsx"
    workbook.parent.mkdir()
    workbook.write_bytes(b"disposable source workbook placeholder; never parsed or uploaded")
    source.write_text(yaml.safe_dump({"source_materials": [{"material_type": "program_spec", "path_or_link": PACK + "/prog_spec/program.xlsx", "sha256": "a" * 64}]}), encoding="utf-8")
    (root / ".gitignore").write_text("*.xlsx\n.portal-drafts/\n", encoding="utf-8")
    code = root / PACK / workspace.TEMPLATE_CODE
    code.parent.mkdir()
    code.write_text("# Synthetic test helper copied by the canonical stand-up\n", encoding="utf-8")
    findings = root / PACK / "spec_pipeline/out/SPEC_FINDINGS.txt"
    findings.parent.mkdir(parents=True)
    findings.write_text("Synthetic specification findings\n", encoding="utf-8")
    config = root / PACK / "config/data_product.yaml"
    config.write_text("version: 2\n", encoding="utf-8")
    paths = [PACK + "/config/data_product.yaml", PACK + "/source_refs.yaml", PACK + "/prog_spec/program.xlsx",
             PACK + "/" + workspace.TEMPLATE_CODE, PACK + "/spec_pipeline/out/SPEC_FINDINGS.txt", "products/registry.yaml"]
    return {"root": root, "paths": paths}


def capture(e, **changes):
    args = dict(written_paths=e["paths"], allowed_packs=[PACK], local_demo=True, can_write=True)
    return workspace.record_created_files(e["root"], PACK, ACTOR, **(args | changes))


def checkpoint(root, preview, **changes):
    args = dict(allowed_packs=[PACK], selected=[r["path"] for r in preview["records"]], expected_digest=preview["digest"],
        message="Record new product with registration dependencies", confirmed=True, local_demo=True, can_write=True,
        can_manage_shared=True, confirmed_shared=True)
    return workspace.commit(root, PACK, ACTOR, **(args | changes))


def test_created_manifest_and_whole_shared_diffs_are_branch_portable_without_workbook_force_add(created):
    result = capture(created)
    root = created["root"]
    path = root / result["path"]
    doc = yaml.safe_load(path.read_text(encoding="utf-8"))
    assert {r["path"] for r in doc["files"]} == set(created["paths"])
    assert all(len(r["sha256"]) == 64 for r in doc["files"])
    preview = state(root, can_manage_shared=True)
    assert preview["shared_pending"] == ["products/registry.yaml"]
    assert "other_product" in preview["diff"] and "+  - {slug: local_test" in preview["diff"]
    assert any(r["path"].endswith("test_functional_contract.py") for r in preview["records"])
    assert any(r["path"].endswith("SPEC_FINDINGS.txt") for r in preview["records"])
    assert "Ignored by Git" in preview["sources"][0]["state"]
    assert not any(r["path"].endswith(".xlsx") for r in preview["records"])
    with pytest.raises(ValueError, match="complete shared-file"):
        checkpoint(root, preview, confirmed_shared=False)
    saved = checkpoint(root, preview)
    assert saved["ok"], saved
    assert "slug: local_test" in git(root, "show", "HEAD:products/registry.yaml")
    assert git(root, "show", "HEAD:" + PACK + "/" + workspace.BRANCH_FILES)
    assert PACK + "/prog_spec/program.xlsx" not in git(root, "ls-files")
    assert not state(root, can_manage_shared=True)["shared_pending"]


def test_non_admin_cannot_read_or_commit_shared_file_diffs(created, monkeypatch):
    capture(created)
    original = workspace._git
    def guarded(root, args, **kwargs):
        assert not (args[0] == "show" and args[-1] == "HEAD:products/registry.yaml"), "shared bytes read without capability"
        return original(root, args, **kwargs)
    monkeypatch.setattr(workspace, "_git", guarded)
    preview = state(created["root"])
    assert "products/registry.yaml" not in preview["offered"]
    assert preview["shared_pending"] == ["products/registry.yaml"]
    assert "other_product" not in preview["diff"]
    with pytest.raises(ValueError, match="no longer available"):
        state(created["root"], selected=["products/registry.yaml"])


@pytest.mark.parametrize("changes", [{"local_demo": False}, {"can_write": False}, {"allowed_packs": []},
                                    {"written_paths": ["../elsewhere.yaml"]}])
def test_capture_scope_and_permissions_are_required(created, changes):
    with pytest.raises(ValueError):
        capture(created, **changes)
    assert not (created["root"] / PACK / workspace.BRANCH_FILES).exists()


@pytest.mark.parametrize("bad", ["governance/SECRET.yaml", "governance/reference/oncology_modules/indication/other.yaml",
                                "products/oncology/another/202609/config/data_product.yaml", "platform/engine/runtime.py"])
def test_creation_record_cannot_widen_shared_or_code_scope(created, bad):
    with pytest.raises(ValueError, match="outside"):
        capture(created, written_paths=[*created["paths"], bad])
    capture(created)
    path = created["root"] / PACK / workspace.BRANCH_FILES
    doc = yaml.safe_load(path.read_text(encoding="utf-8"))
    doc["files"].append({"path": bad, "kind": "shared_registration", "sha256": "a" * 64})
    path.write_text(yaml.safe_dump(doc), encoding="utf-8")
    with pytest.raises(ValueError, match="malformed"):
        state(created["root"], can_manage_shared=True)


def test_changed_shared_file_requires_new_exact_review(created):
    capture(created)
    preview = state(created["root"], can_manage_shared=True)
    path = created["root"] / "products/registry.yaml"
    path.write_text(path.read_text(encoding="utf-8") + "# changed by another author\n", encoding="utf-8")
    with pytest.raises(ValueError, match="changed"):
        checkpoint(created["root"], preview)


def test_capture_never_overwrites_existing_branch_record(created):
    capture(created)
    path = created["root"] / PACK / workspace.BRANCH_FILES
    original = path.read_bytes()
    assert capture(created)["changed"] is False
    path.write_bytes(original + b"# another author's note\n")
    with pytest.raises(ValueError, match="already exists"):
        capture(created)
    assert path.read_bytes() == original + b"# another author's note\n"


def test_source_absence_is_explicit_and_does_not_block_metadata_review(created):
    capture(created)
    (created["root"] / PACK / "prog_spec/program.xlsx").unlink()
    preview = state(created["root"], can_manage_shared=True)
    assert "Missing locally" in preview["sources"][0]["state"]
    assert preview["can_commit"]


def test_canonical_generated_bundle_and_pages_are_explicit_shared_dependencies(created):
    generated = ["resources/products.yml", *sorted(workspace.GENERATED_REPORTS)]
    for relative in generated:
        path = created["root"] / relative
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text("# Generated registration metadata\n", encoding="utf-8")
    capture(created, written_paths=[*created["paths"], *generated])
    preview = state(created["root"], can_manage_shared=True)
    assert set(generated).issubset(preview["shared_selected"])
    with pytest.raises(ValueError, match="complete shared-file"):
        checkpoint(created["root"], preview, confirmed_shared=False)


def implementation_application(root):
    import science_workspace
    identifier = "b" * 24
    folder = root / PACK / "handoff/IMPLEMENTATION_REVIEWS" / identifier
    folder.mkdir(parents=True)
    files = {}
    for name in ("candidate.py", "candidate_tests.py"):
        raw = b"# Inert retained review artifact; never imported by a checkpoint.\n"
        (folder / name).write_bytes(raw)
        files[name] = hashlib.sha256(raw).hexdigest()
    review = {"id": identifier, "pack": PACK, "files": files}
    review["digest"] = science_workspace._hash(review)
    (folder / "review.json").write_text(json.dumps(review), encoding="utf-8")
    refs = []
    for relative in ("platform/capabilities.yaml", "platform/CAPABILITIES.md"):
        path = root / relative
        path.parent.mkdir(parents=True, exist_ok=True)
        raw = b"# Current checked capability declaration\n"
        path.write_bytes(raw)
        refs.append({"path": relative, "before_sha256": hashlib.sha256(b"").hexdigest(),
                     "after_sha256": hashlib.sha256(raw).hexdigest()})
    application = {"pack": PACK, "record_id": identifier, "review_digest": review["digest"],
        "proposal_digest": "c" * 64, "files": refs}
    application["digest"] = science_workspace._hash(application)
    (folder / "capability_application.json").write_text(json.dumps(application), encoding="utf-8")
    (folder / "unrelated.py").write_text("# Must not broaden Python file eligibility\n", encoding="utf-8")
    return folder


def test_exact_implementation_artifacts_and_bound_capability_files_can_travel_together(checkout):
    folder = implementation_application(checkout)
    preview = state(checkout, can_manage_shared=True)
    names = {row["path"] for row in preview["records"]}
    assert {"platform/capabilities.yaml", "platform/CAPABILITIES.md"}.issubset(preview["shared_selected"])
    assert folder.relative_to(checkout).as_posix() + "/candidate.py" in names
    assert folder.relative_to(checkout).as_posix() + "/candidate_tests.py" in names
    assert not any(name.endswith("unrelated.py") for name in names)
    assert not preview["application_warnings"]
    assert checkpoint(checkout, preview)["ok"]
    assert b"candidate_tests.py" in workspace._git(checkout, ["ls-files", "--", PACK]).stdout


def test_stale_capability_application_does_not_offer_unbound_global_edits(checkout, monkeypatch):
    import pattern_workspace
    implementation_application(checkout)
    with monkeypatch.context() as m:
        m.setattr(pattern_workspace, "read_application", lambda *_args, **_kw: pytest.fail("Non-admin must not read global capability files"))
        ordinary = state(checkout)
        assert "platform/capabilities.yaml" not in ordinary["offered"] and ordinary["application_warnings"]
    path = checkout / "platform/capabilities.yaml"
    path.write_bytes(path.read_bytes() + b"# later application for another product\n")
    preview = state(checkout, can_manage_shared=True)
    assert "platform/capabilities.yaml" not in preview["offered"]
    assert preview["application_warnings"]


def test_page_requires_separate_shared_confirmation_and_clears_it_on_role_change(created):
    capture(created)
    code = f'''import streamlit as st
import branch_workspace_page as page
page.render({str(created["root"])!r}, {PACK!r}, {ACTOR!r}, allowed_packs={[PACK]!r}, local_demo=True,
    can_write=True, can_review=True, route="branch_changes", can_manage_shared=st.session_state.get("manage", True))
'''
    at = AppTest.from_string(code, default_timeout=60).run()
    assert not at.exception, [e.message for e in at.exception]
    assert any("Ignored by Git" in row.value for row in at.markdown)
    at.multiselect(key="branch_ws_files").set_value(["products/registry.yaml", PACK + "/source_refs.yaml"]).run()
    assert any("complete shared registration" in row.value for row in at.warning)
    at.text_input(key="branch_ws_message").set_value("Save registration dependencies")
    at.checkbox(key="branch_ws_confirm").check().run()
    assert at.button(key="branch_ws_save").disabled
    at.checkbox(key="branch_ws_confirm_shared").check().run()
    assert not at.button(key="branch_ws_save").disabled
    at.session_state["manage"] = False
    at.run()
    assert not at.exception
    assert at.multiselect(key="branch_ws_files").value == []
    assert "products/registry.yaml" not in at.multiselect(key="branch_ws_files").options
