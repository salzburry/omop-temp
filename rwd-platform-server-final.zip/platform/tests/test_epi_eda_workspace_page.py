"""The EDA review journey uses the real backend with disposable counts only."""
from pathlib import Path
import sys

from streamlit.testing.v1 import AppTest

ROOT = Path(__file__).resolve().parents[2]
sys.path[:0] = [str(ROOT / "platform/tests"), str(ROOT / "platform/tools"), str(ROOT / "experiments/portal")]
from test_epi_eda_workspace import evidence, PACK, ACTOR, rewrite, eda


def app(e, *, params=None, write=True):
    code = f'''import streamlit as st
import eda_workspace_page as page
result = page.render({str(e["root"])!r}, {PACK!r}, st.session_state.get("actor", {ACTOR!r}),
    allowed_packs=st.session_state.get("allowed", [{PACK!r}]), local_demo=True,
    can_write=st.session_state.get("write", {write!r}), params=st.session_state.get("route_params", {params or {}!r}))
if result: st.session_state["navigation"] = result
'''
    at = AppTest.from_string(code, default_timeout=60).run()
    assert not at.exception, [row.message for row in at.exception]
    return at


def button(at, label):
    return next(row for row in at.button if row.label == label)


def text(at):
    return " ".join(row.value for kind in (at.info, at.warning, at.success, at.caption, at.markdown, at.error) for row in kind)


def receive(at, e):
    at.text_input(key="eda_workspace_filename").set_value(e["path"].name).run()
    button(at, "Receive and check the EDA report").click().run()
    assert not at.exception, [row.message for row in at.exception]
    return at


def test_exact_selection_receive_six_layers_and_explicit_branch_save(evidence):
    at = app(evidence)
    assert at.selectbox(key="eda_workspace_receipt").value is None
    at.selectbox(key="eda_workspace_receipt").select(evidence["receipt"]).run()
    receive(at, evidence)
    assert len(at.dataframe) == 6
    assert "EDA acceptance: not evaluated" in text(at)
    assert button(at, "Save EDA evidence binding").disabled
    assert "manifest_sha256" in at.code[0].value and "layers:" not in at.code[0].value
    at.checkbox(key="eda_workspace_confirm").check().run()
    button(at, "Save EDA evidence binding").click().run()
    assert not at.exception
    nav = at.session_state["navigation"]
    assert nav["route"] == "eda_review" and nav["changed"]
    assert "No approval or release was recorded" in text(at)
    at.session_state["route_params"] = nav["params"]
    at.run()
    assert "Saved branch metadata rechecked" in text(at)
    assert len(at.dataframe) == 6
    button(at, "Review this build's release readiness").click().run()
    assert at.session_state["navigation"] == {"route": "release_readiness", "params": {"receipt": evidence["receipt"]}}


def test_missing_artifact_routes_existing_runtime_without_false_evidence(evidence):
    evidence["doc"]["eda"] = {}
    evidence["doc"]["artifacts"] = {}
    rewrite(evidence, doc=evidence["doc"])
    at = app(evidence, params={"receipt": evidence["receipt"]})
    assert "does not bind a completed EDA artifact" in text(at)
    assert not at.dataframe and not at.text_input
    button(at, "Review candidate validation").click().run()
    assert at.session_state["navigation"]["params"]["action_id"] == "g5_validate"


def test_missing_receipt_and_missing_restricted_folder_explain_next_step(evidence, monkeypatch):
    monkeypatch.delenv("RWD_PROFILE_DIR")
    at = app(evidence, params={"receipt": evidence["receipt"]})
    assert not at.text_input
    assert "folder" in text(at).lower()
    evidence["receipt_path"].unlink()
    at.run()
    assert "No build receipt is recorded" in text(at)
    button(at, "Prepare or locate the build").click().run()
    assert at.session_state["navigation"]["params"]["action_id"] == "g5_build"


def test_tampered_received_file_clears_confirmation_and_never_saves(evidence):
    at = receive(app(evidence, params={"receipt": evidence["receipt"]}), evidence)
    at.checkbox(key="eda_workspace_confirm").check().run()
    evidence["path"].write_bytes(evidence["path"].read_bytes() + b"\n")
    button(at, "Save EDA evidence binding").click().run()
    assert not at.exception
    assert "evidence changed or is unavailable" in text(at)
    assert not (evidence["product"] / eda.REVIEW_DIR).exists()
    assert not at.checkbox


def test_readonly_can_inspect_but_not_record_and_scope_change_clears_counts(evidence):
    at = receive(app(evidence, params={"receipt": evidence["receipt"]}, write=False), evidence)
    assert len(at.dataframe) == 6
    at.checkbox(key="eda_workspace_confirm").check().run()
    assert button(at, "Save EDA evidence binding").disabled
    at.session_state["allowed"] = []
    at.run()
    assert not at.exception
    assert not at.dataframe and not at.text_input
    assert at.error


def test_new_product_bytes_invalidate_received_state_without_losing_filename(evidence):
    at = receive(app(evidence, params={"receipt": evidence["receipt"]}), evidence)
    at.checkbox(key="eda_workspace_confirm").check().run()
    source = evidence["product"] / "source_refs.yaml"
    source.write_bytes(source.read_bytes() + b"\n# source review changed\n")
    at.run()
    assert not at.exception
    assert "build or product changed" in text(at)
    assert not at.dataframe and not at.checkbox
    assert at.text_input(key="eda_workspace_filename").value == evidence["path"].name
