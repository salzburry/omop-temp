"""Explicit variable-review requests open the real review UI without model or approval writes."""
from pathlib import Path
import sys

import pytest

ROOT = Path(__file__).resolve().parents[2]
sys.path[:0] = [str(ROOT / folder) for folder in
               ("platform/tests", "experiments/portal", "platform/tools", "experiments/agent")]
import flow_assistant as guide
import flow_assistant_page as page
from test_epi_flow_assistant import _card

PACK = "products/oncology/test_product/202609"


@pytest.mark.parametrize("question", ["approve the variables", "approve these variables", "approve all variables",
    "please approve all the staged variables", "Can you approve teh variables?", "finalize variables",
    "finalise the mapped variables", "review mapped variables", "review the variable definitions",
    "How can I approve the variables?"])
def test_explicit_variable_review_intents_are_distinct_from_general_definition_help(question):
    assert guide.intent(question) == "variable_review"


@pytest.mark.parametrize("question", ["Do not approve the variables", "Don't review variables yet",
    "I can’t approve the variables", "Who approved these variables?", "Review the source mapping",
    "Review the Python code for these variables", "Explain variable approval", "What is a variable?"])
def test_other_requests_do_not_trigger_the_deterministic_review_path(question):
    assert not guide.variable_review_request(question)


def test_review_is_immediate_with_an_unavailable_model_and_old_brief():
    class Model:
        def step(self, *_args):
            pytest.fail("An explicit review request must never wait on a model")

    card = {**_card(), "variable_workflow": {"phase": "science", "blockers": ["DATAV: this product's value is missing."]}}
    result = guide.answer("Approve all variables", card, model=Model(),
                          study_brief={"pending_question": "OLD INTAKE QUESTION"})
    assert result["source"] == "checks"
    assert result["actions"] == ["open_variable_review"]
    assert "DATAV" in result["answer"] and "explicit confirmation" in result["answer"]
    assert "not approved or signed" in result["answer"]
    assert "OLD INTAKE" not in result["answer"]
    assert "prefill" not in result


def test_failed_workflow_check_does_not_hide_review_but_its_blockers_remain_visible():
    card = {**_card(), "workflow_feedback": {"status": "blocked", "input_digest": "a" * 64,
        "action_id": "g2_draft", "title": "Review variable definitions", "blockers": ["AGE has no current scientific row."]}}
    reply = guide.answer("approve the variables", card, provider={"configured": False})
    assert reply["actions"] == ["open_variable_review"]
    assert "AGE has no current scientific row" in reply["answer"]


def test_review_request_still_applies_ingress_and_available_action_limits():
    card = _card()
    card["actions"].remove("open_variable_review")
    assert guide.answer("Approve the variables", card)["actions"] == []
    secret = "ANTHROPIC_API_KEY=sk-ant-audit-sentinel-only"
    assert guide.answer("Approve the variables " + secret, _card())["source"] == "refused"
    assert guide.answer("Approve the variables", {**_card(), "blockers": [secret]})["source"] == "refused"


@pytest.mark.parametrize("connected", [False, True])
def test_main_chat_keeps_pending_work_and_opens_scientific_table_only_on_button(monkeypatch, tmp_path, connected):
    from streamlit.testing.v1 import AppTest
    import streamlit as st
    import connected_workflow_page
    import conversation_intake as brief_api
    import conversation_intake_page as brief_page
    import flow_page
    import specialist_chat

    provider = {"configured": True, "provider": "Unavailable test provider"} if connected else None
    monkeypatch.setattr(page, "_provider_words", lambda *_: (provider, "Local review actions are available."))
    monkeypatch.setattr(flow_page, "assistant_feedback", lambda *_args, **_kwargs: None)
    monkeypatch.setattr(page, "_load_history", lambda *_: True)
    monkeypatch.setattr(page, "_save_history", lambda *_: True)
    monkeypatch.setattr(page, "_brief_options", lambda *_args, **_kwargs: {"scope_id": ""})
    brief = {"revision": 1, "pending_question": {"token": "old-question"}}
    monkeypatch.setattr(brief_api, "load", lambda *_args, **_kwargs: brief)
    monkeypatch.setattr(brief_page, "render", lambda *_args, **_kwargs: {"brief": brief})
    monkeypatch.setattr(brief_page, "render_question", lambda *_args, **_kwargs: {"reply": None, "question_token": None})
    monkeypatch.setattr(brief_api, "retrieval_context", lambda *_: "")
    monkeypatch.setattr(brief_api, "resolve_reply", lambda *_args, **_kwargs: pytest.fail("Review must not answer the old intake question"))
    monkeypatch.setattr(brief_api, "save", lambda *_args, **_kwargs: pytest.fail("Review navigation must not write the brief"))
    monkeypatch.setattr(specialist_chat, "prepare", lambda *_args, **_kwargs: pytest.fail("Review must not start a specialist"))
    monkeypatch.setattr(connected_workflow_page, "open_route", lambda route, pack, actor, **kwargs:
                        st.session_state.__setitem__("navigation", {"route": route, "pack": pack, "actor": actor, **kwargs}))
    script = f'''import streamlit as st
import flow_assistant_page as page
page.render({str(tmp_path)!r}, {PACK!r}, card=st.session_state["card"], actor_id="scientist",
    primary=True, metadata_only=True, allowed_packs=[{PACK!r}], local_demo=True, can_write=True)
'''
    at = AppTest.from_string(script, default_timeout=30)
    at.session_state["card"] = _card()
    at.session_state["running_setup_task"] = {"id": "keep-running", "status": "running"}
    at.run()
    assert not at.exception, [str(error.value) for error in at.exception]
    if connected:
        at.chat_input[0].set_value("approve teh variables").run()
    else:
        at.text_input(key=page.KEY + "q_" + PACK).set_value("approve teh variables")
        at.button(key=page.KEY + "ask_" + PACK).click().run()
    assert not at.exception, [str(error.value) for error in at.exception]
    assert "navigation" not in at.session_state, "The chat response itself never confirms a review"
    assert at.session_state["running_setup_task"] == {"id": "keep-running", "status": "running"}
    action = next(button for button in at.button if button.label == "Review all variables")
    action.click().run()
    assert not at.exception, [str(error.value) for error in at.exception]
    assert at.session_state["navigation"] == {"route": "variable_review", "pack": PACK, "actor": "scientist",
                                              "params": {"phase": "science", "action": "review"}}


@pytest.mark.parametrize("availability", ["connected", "disconnected", "source_review_pending"])
def test_scientific_row_chat_reviews_all_without_replacing_unsaved_fields_or_proposal(monkeypatch, tmp_path, availability):
    import copy
    import streamlit as st
    from streamlit.testing.v1 import AppTest
    import connected_workflow_page
    import scientific_definition_ai_page as row_chat
    import specialist_chat
    from test_epi_scientific_definition_ai_page import OfflineAssistant
    from test_epi_scientific_definitions import ACTOR, ITEM, describe, fixture, governed_bytes

    root, pack, product, _ = fixture(tmp_path)
    original = governed_bytes(product)
    backend = OfflineAssistant()
    for method in ("describe_availability", "suggest", "accept"):
        monkeypatch.setattr(row_chat.assistant, method, getattr(backend, method))
    monkeypatch.setattr(specialist_chat, "prepare", lambda *_args, **_kwargs: None)
    monkeypatch.setattr(connected_workflow_page, "open_route", lambda route, pack, actor, **kwargs:
                        st.session_state.__setitem__("navigation", {"route": route, "pack": pack, "actor": actor, **kwargs}))
    script = f'''import streamlit as st
import scientific_definition_ai_page as page
import scientific_definitions as definitions
import connected_workflow_page
connected_workflow_page.render_active({str(root)!r}, {pack!r}, {ACTOR!r}, section="Flow",
    allowed_packs=[{pack!r}], local_demo=True, can_write=True, can_review=False, can_view=True)
if "navigation" not in st.session_state:
    notes = st.text_area("My unsaved notes", value="Keep my unsaved scientific question", key="scientific_definition_field_notes")
    current = definitions.describe({str(root)!r}, {pack!r}, {ACTOR!r}, item_id={ITEM!r}, allowed_packs=[{pack!r}])
    current["values"]["notes"] = notes
    if page.render({str(root)!r}, {pack!r}, {ACTOR!r}, current,
                   local_demo=True, can_write=True, allowed_packs=[{pack!r}], chat=True):
        st.session_state["test_saved"] = True
else:
    st.info("The review table is open")
'''
    at = AppTest.from_string(script, default_timeout=30).run()
    assert not at.exception, [str(error.value) for error in at.exception]
    at.chat_input[0].set_value("Suggest wording for this row").run()
    assert not at.exception, [str(error.value) for error in at.exception]
    assert len(backend.generations) == 1
    at.multiselect(key=row_chat.PREFIX + "select_chat").set_value(["derivation"]).run()
    proposal = copy.deepcopy(at.session_state[row_chat.PREFIX + "proposal"])
    response = copy.deepcopy(at.session_state[row_chat.PREFIX + "response"])
    if availability == "disconnected":
        backend.configured = False
    elif availability == "source_review_pending":
        backend.eligible = False
    monkeypatch.setattr(specialist_chat, "prepare", lambda *_args, **_kwargs: pytest.fail("Review must not start a specialist"))
    at.run()
    assert len(at.chat_input) == 1 and not at.chat_input[0].disabled
    saved_availability = row_chat.assistant.describe_availability
    monkeypatch.setattr(row_chat.assistant, "describe_availability",
        lambda *_args, **_kwargs: pytest.fail("Review navigation must not wait for a provider health check"))
    at.chat_input[0].set_value("approve teh variables").run()
    monkeypatch.setattr(row_chat.assistant, "describe_availability", saved_availability)
    assert not at.exception, [str(error.value) for error in at.exception]
    assert len(backend.generations) == 1 and not backend.acceptances
    assert "test_saved" not in at.session_state and "navigation" not in at.session_state
    assert at.session_state[row_chat.PREFIX + "proposal"] == proposal
    assert at.session_state[row_chat.PREFIX + "response"] == response
    assert at.session_state[row_chat.PREFIX + "select_chat"] == ["derivation"]
    assert not describe(root, pack)["saved"] and governed_bytes(product) == original
    assert "not approved or signed" in at.session_state[row_chat.PREFIX + "messages"][-1]["content"]
    next(button for button in at.button if button.label == "Review all variables").click().run()
    assert not at.exception, [str(error.value) for error in at.exception]
    assert at.session_state["navigation"] == {"route": "variable_review", "pack": pack, "actor": ACTOR,
                                              "params": {"phase": "science", "action": "review"}}
    at.run()
    assert at.session_state["scientific_definition_field_notes"] == "Keep my unsaved scientific question"
    assert at.session_state[row_chat.PREFIX + "proposal"] == proposal
    assert at.session_state[row_chat.PREFIX + "select_chat"] == ["derivation"]
    assert not backend.acceptances and governed_bytes(product) == original
