"""The severity-first ECOG tie rule, pinned by the cases a review mandated.

A specification may state the tie outright — "closest to index; if two equidistant, take
the worse" — and the incumbent ordering (gap, then date direction, then grade) could let
an earlier, better ECOG beat a later, worse equidistant one. `equidistant: worst_value`
makes severity outrank the date at equal gap, with the date as the deterministic
fallback; absent, the incumbent ordering is byte-identical, so no committed number moves.

Run: python platform/tests/test_ecog_equidistant.py   (skips cleanly without pyspark)
"""
import sys
from datetime import date
from pathlib import Path

FRAMEWORK = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(FRAMEWORK))

try:
    from pyspark.sql import SparkSession
except Exception:                       # pyspark not installed -> tests skip
    SparkSession = None

from engine.stages import clinical as clinical_stage                     # noqa: E402

try:
    import pytest
    pytestmark = pytest.mark.skipif(SparkSession is None, reason="pyspark not installed")
except Exception:
    pytest = None

_SPARK = None

CFG = {"window_days": [-90, 7], "tie_break": "earliest_date",
       "equidistant": "worst_value", "missing_label": "Missing", "missing_code": 7,
       "value_codes": {"0": 1, "1": 2, "2": 3, "3": 4, "4": 5, "Unknown": 6}}


def _spark():
    global _SPARK
    if _SPARK is None:
        _SPARK = (SparkSession.builder.master("local[1]")
                  .appName("ecog-equidistant").config("spark.ui.enabled", "false")
                  # THE FOUR PRODUCTION PINS — see test_runtime_pinning.py. A suite that builds
                  # its own session must ask for the same dialect production runs, or a green run
                  # proves nothing about the cluster. This one asked for the platform default,
                  # which on a machine in another timezone is a different dialect: an equidistant
                  # tie-break is decided by DATES, so an unpinned session is the last place a
                  # local clock should be allowed to choose the winner.
                  .config("spark.sql.session.timeZone", "UTC")
                  .config("spark.sql.ansi.enabled", "false")
                  .config("spark.sql.legacy.timeParserPolicy", "CORRECTED")
                  .config("spark.sql.caseSensitive", "false")
                  .getOrCreate())
    return _SPARK


def _run(rows, cfg=CFG, index_day=date(2026, 3, 1)):
    s = _spark()
    idx = s.createDataFrame([("p1", index_day)], ["patientid", "index_date"])
    src = {"baseline_ecog": s.createDataFrame(
        [("p1", d, v) for d, v in rows],
        "patientid string, ecogdate date, ecogvalue string")}
    out = clinical_stage.baseline_ecog(src, idx, cfg).collect()
    return out[0]["ecog"]


def test_worse_wins_when_equidistant_either_side():
    if SparkSession is None:
        return
    # ECOG 1 at day -3 vs ECOG 3 at day +3 -> 3; and mirrored -> still 3
    assert _run([(date(2026, 2, 26), "1"), (date(2026, 3, 4), "3")]) == "3"
    assert _run([(date(2026, 2, 26), "3"), (date(2026, 3, 4), "1")]) == "3"


def test_window_edges_are_inclusive_and_outside_is_out():
    if SparkSession is None:
        return
    # -90 and +7 are in; -91 and +8 are not (only out-of-window rows -> Missing)
    assert _run([(date(2025, 12, 1), "2")]) == "2"          # exactly -90
    assert _run([(date(2026, 3, 8), "2")]) == "2"           # exactly +7
    assert _run([(date(2025, 11, 30), "4"), (date(2026, 3, 9), "4")]) == "Missing"


def test_same_date_duplicates_choose_the_worse_value():
    if SparkSession is None:
        return
    assert _run([(date(2026, 3, 2), "1"), (date(2026, 3, 2), "3")]) == "3"


def test_input_order_never_changes_the_answer():
    if SparkSession is None:
        return
    rows = [(date(2026, 2, 26), "1"), (date(2026, 3, 4), "3"), (date(2026, 3, 2), "0")]
    for perm in (rows, rows[::-1], [rows[1], rows[2], rows[0]]):
        assert _run(perm) == "0"        # nearest gap (1 day) wins before any tie logic


def test_no_record_and_explicit_unknown_stay_distinguishable():
    if SparkSession is None:
        return
    assert _run([]) == "Missing"
    assert _run([(date(2026, 3, 2), "Unknown")]) == "Unknown"


def test_the_incumbent_ordering_is_untouched_without_the_key():
    if SparkSession is None:
        return
    cfg = dict(CFG)
    cfg.pop("equidistant")
    # date-first: the EARLIER equidistant record wins under the incumbent rule,
    # which is exactly why a spec that says "take the worse" must DECLARE the rule
    assert _run([(date(2026, 2, 26), "1"), (date(2026, 3, 4), "3")], cfg=cfg) == "1"


def test_an_unrecognised_tie_word_refuses_instead_of_approximating():
    if SparkSession is None:
        return
    cfg = dict(CFG, equidistant="probably_worse")
    try:
        _run([(date(2026, 3, 2), "1")], cfg=cfg)
        raise AssertionError("an invented tie rule was silently accepted")
    except ValueError as e:
        assert "equidistant" in str(e), e


if __name__ == "__main__":
    if SparkSession is None:
        print("pyspark not installed - skipped")
        sys.exit(0)
    bad = 0
    for name, fn in sorted(globals().items()):
        if name.startswith("test_") and callable(fn):
            try:
                fn()
                print(f"  ok  {name}")
            except Exception as e:                   # noqa: BLE001 - report and continue
                bad += 1
                print(f"FAIL  {name}: {e}")
    sys.exit(1 if bad else 0)
