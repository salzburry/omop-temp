"""Programme item 4 — ONE composed candidate-validation verdict.

Every stage a candidate passes through composes into `engine.refresh.candidate_verdict`; the
manifest stores that verdict beside its blocks and refuses a copy that disagrees; the evidence
bundle carries every stage from the one list; the committed refresh receipt is read back into
Gate 5; Gate 6 refuses an approval over a failed candidate; and the linkage stage compares the
unrounded rate.

    python3 platform/tests/test_candidate_verdict.py
"""
import copy
import os
import shutil
import sys
import tempfile
import traceback
from pathlib import Path

FRAMEWORK = Path(__file__).resolve().parent.parent
ROOT = FRAMEWORK.parent
sys.path.insert(0, str(FRAMEWORK))
sys.path.insert(0, str(FRAMEWORK / "tools"))
os.environ.setdefault("ANTHROPIC_API_KEY", "not-a-key-tests-never-call")
from engine import audit, linkage, output_contract, refresh                  # noqa: E402
import console                                                                # noqa: E402
import source_manifest as sm                                                  # noqa: E402

PROSTATE = "fixtures/oncology/prostate/202606"
GREEN = {"source_qc_gate": {"passed": True}, "qc": {"passed": True}, "output_contract": {"passed": True}}


def test_linkage_is_its_own_stage_and_compares_the_unrounded_rate():
    """3 orphans in 100,000 is 0.00003 — the report rounds it to 0.0, and a gate reading the
    rounded figure passed it under a ceiling of 0.00001. The stage recomputes from the counts.
    Report-only linkage composes to NOTHING (never a pass); a declared tolerance the run could
    not measure fails."""
    report = {"_spine": {"role": "enhanced", "patients": 100000},
              "lot": {"patients": 100000, "linked": 99997, "orphans": 3, "orphan_rate": 0.0,
                      "spine_missing": 3, "spine_missing_rate": 0.0, "max_rows_per_patient": 4,
                      "avg_rows_per_patient": 1.2, "null_patient_rows": 0}}
    g = linkage.linkage_gate(report, {"max_orphan_rate": 0.00001})
    assert not g["passed"] and "lot: orphan_rate 3e-05" in g["failures"][0], g
    assert linkage.linkage_gate(report, {"max_spine_missing_rate": 0.00001})["failures"], "spine missing reads the counts too"
    assert linkage.linkage_gate(report, {"max_orphan_rate": 0.0001})["passed"]
    # a report with no counts still reads the rounded figure it carries
    assert not linkage.linkage_gate({"x": {"orphan_rate": 0.5}}, {"max_orphan_rate": 0.1})["passed"]
    # the stage: {} unless declared; measured/declared ride along; unmeasurable under a declaration fails
    assert linkage.linkage_verdict({"linkage": report}, None) == {}
    assert linkage.linkage_verdict({"linkage": report}, {"max_orphan_rate": None}) == {}
    v = linkage.linkage_verdict({"linkage": report}, {"max_orphan_rate": 0.00001})
    assert v["passed"] is False and v["declared"] and v["measured"] and v["thresholds"] == {"max_orphan_rate": 0.00001}, v
    v2 = linkage.linkage_verdict({"linkage_error": "spine not loaded"}, {"max_orphan_rate": 0.1})
    assert v2["passed"] is False and not v2["measured"] and "not measurable" in v2["failures"][0], v2
    cv = refresh.candidate_verdict(dict(GREEN, linkage=v))
    assert not cv["passed"] and any(f.startswith("source linkage FAILED") for f in cv["failures"]), cv
    assert "source linkage" in refresh.candidate_verdict(GREEN)["not_evaluated"]


def test_the_publication_surface_is_the_last_stage_and_never_publish_fails_in_every_mode():
    ps = output_contract.publication_surface_gate
    assert ps({"declared": False}, release_grade=False) == {}, "a dev run with no whitelist has not asked"
    dev_never = ps({"declared": False, "never_publish_present": ["ssn"]}, release_grade=False)
    assert dev_never["passed"] is False and "never_publish" in dev_never["failures"][0]
    rel = ps({"declared": False}, release_grade=True)
    assert rel["passed"] is False and "not declared" in rel["failures"][0], rel
    assert ps({"declared": True, "extra": [], "missing": [], "order_differs": False}, True)["passed"] is True
    bad = ps({"declared": True, "extra": ["helper"], "missing": ["os"], "order_differs": True}, True)
    assert bad["passed"] is False and len(bad["failures"]) == 3, bad
    # last in the composed list, and named in the composed verdict
    assert refresh.CANDIDATE_VERDICTS[-1][0] == "publication_surface"
    assert [k for k, _n, _r in refresh.CANDIDATE_VERDICTS][:2] == ["source_qc_gate", "linkage"]
    cv = refresh.candidate_verdict(dict(GREEN, publication_surface=bad))
    assert not cv["passed"] and cv["failures"][-1].startswith("publication surface FAILED"), cv
    assert "publication surface" in refresh.candidate_verdict(GREEN)["not_evaluated"]


def _manifest(**over):
    from engine.config import load_config, product_config                     # noqa: PLC0415
    cfg = load_config(product_config(ROOT / "fixtures", "prostate"),
                      overrides={"run.refresh": "2026q3", "run.source_schema": "src", "run.output_schema": "out"})
    kw = dict(tumor="mcrpc", family="oncology", git_commit="abc1234", counts={"total_rows": 1},
              qc={"passed": True}, source_qc_gate={"passed": True}, output_contract={"passed": True},
              run_mode={"env": "prod", "release_grade": True}, tree_sha256="a" * 64,
              config_identity={"config_bundle_sha256": "b" * 64}, runtime={"dbr": "15.4"}, content={"digest": "c" * 64})
    kw.update(over)
    return refresh.build_manifest(cfg, **kw)


def test_the_manifest_stores_the_composed_verdict_and_refuses_a_copy_that_disagrees_with_its_blocks():
    m = _manifest(linkage={"passed": True, "declared": True, "measured": True, "failures": []},
                  publication_surface={"passed": True, "declared": True, "failures": []})
    assert m["candidate_verdict"]["passed"] is True and "source linkage" in m["candidate_verdict"]["evaluated"]
    assert m["linkage"]["declared"] and m["publication_surface"]["declared"]
    assert refresh.validate_manifest(m) == [], refresh.validate_manifest(m)
    import json                                                               # noqa: PLC0415
    schema = json.loads((ROOT / "governance" / "schemas" / "release.schema.json").read_text(encoding="utf-8"))
    assert {"linkage", "publication_surface", "candidate_verdict"} <= set(schema["properties"])
    assert not (set(m) - set(schema["properties"])), sorted(set(m) - set(schema["properties"]))
    # a hand-edited copy of the verdict is refused by name
    forged = copy.deepcopy(m)
    forged["publication_surface"] = {"passed": False, "declared": True, "failures": ["column(s) not on the approved whitelist: helper"]}
    probs = refresh.validate_manifest(forged)
    assert any("candidate_verdict disagrees" in p and "helper" in p for p in probs), probs
    # {} blocks read as not evaluated, never as a pass; an absent stored verdict is not a finding
    bare = _manifest()
    assert bare["linkage"] == {} and bare["publication_surface"] == {}
    assert {"source linkage", "publication surface"} <= set(bare["candidate_verdict"]["not_evaluated"])
    bare["candidate_verdict"] = {}
    assert refresh.validate_manifest(bare) == []


def test_the_evidence_bundle_carries_every_stage_from_the_one_list():
    m = _manifest(differential={"passed": False, "reference": "x", "unapproved": ["p1 changed"]},
                  retention={"passed": True, "bounds": {"lot": 0.9}},
                  linkage={"passed": True, "declared": True, "measured": True, "failures": []},
                  publication_surface={"passed": True, "declared": True, "failures": []})
    b = audit.build_bundle(m)
    for key, _n, _r in refresh.CANDIDATE_VERDICTS:
        if key in ("qc", "golden"):
            continue
        if m.get(key):
            assert f"{key}.json" in b, (key, sorted(b))
    assert b["ads_qc.json"] == m["qc"] and b["golden.json"] == m["golden"] and "source_qc.json" in b
    assert b["differential.json"]["unapproved"] == ["p1 changed"] and "retention.json" in b
    assert b["candidate_verdict.json"]["passed"] is False and any("differential" in f for f in b["candidate_verdict.json"]["failures"])
    assert "eda_acceptance.json" not in b, "an empty stage is not written as evidence"
    # written to disk as JSON, one file per stage
    d = tempfile.mkdtemp()
    try:
        written = audit.write_bundle(m, d)
        assert any(w.endswith("candidate_verdict.json") for w in written) and any(w.endswith("linkage.json") for w in written)
    finally:
        shutil.rmtree(d, ignore_errors=True)


def _receipt_root(verdict_block, build_id="b1"):
    """A temp checkout with the prostate fixture and ONE committed refresh receipt for it."""
    import yaml                                                               # noqa: PLC0415
    root = tempfile.mkdtemp(prefix="cv_")
    dst = os.path.join(root, PROSTATE)
    shutil.copytree(ROOT / PROSTATE, dst, ignore=shutil.ignore_patterns("__pycache__"))
    os.makedirs(os.path.join(root, "fixtures"), exist_ok=True)
    shutil.copy(ROOT / "fixtures" / "registry.yaml", os.path.join(root, "fixtures", "registry.yaml"))
    rdir = os.path.join(root, "refreshes", "oncology", "mcrpc", "202606")
    os.makedirs(rdir)
    doc = {"tumor": "prostate", "spec_version": "202606", "refresh": "2026q3", "built_at": "2026-09-01T00:00:00+00:00",
           "status": "released", "counts": {"total_rows": 1}, "release": {"build_id": build_id},
           "source_qc_gate": {"passed": True}, "qc": {"passed": True}, "output_contract": {"passed": True},
           **verdict_block}
    Path(rdir, "2026q3.yaml").write_text(yaml.safe_dump(doc, sort_keys=False), encoding="utf-8")
    return root


def test_the_committed_receipt_s_verdict_reaches_gate_5_and_a_failed_candidate_cannot_be_approved():
    import status as st                                                       # noqa: PLC0415
    failing = {"publication_surface": {"passed": False, "declared": True,
                                       "failures": ["column(s) not on the approved whitelist: helper_col"]}}
    root = _receipt_root(failing)
    try:
        vv = sm.validation_verdict(root, "prostate", "202606")
        assert vv and vv["build_id"] == "b1" and vv["status"] == "released" and vv["receipt"].startswith("refreshes/")
        assert vv["verdict"]["passed"] is False and "publication surface FAILED" in vv["verdict"]["failures"][0], vv
        assert sm.validation_verdict(root, "prostate", "202606", build_id="nope") is None
        assert sm.validation_verdict(root, "prostate", "202605") is None, "another cut's receipt is not this one's"
        g = {n: (state, why) for n, _t, state, why in st.gates(root, PROSTATE)}
        assert g[5][0] != "done" and any("helper_col" in w and "candidate verdict FAILED" in w for w in g[5][1]), g[5]
        assert not any("helper_col" in w for n in (1, 2, 3, 4, 6) for w in g[n][1]), "the stage belongs to Gate 5"
    finally:
        shutil.rmtree(root, ignore_errors=True)
    # Gate 6, at promotion: the approval names the build and the digest, and the candidate still failed
    root = _receipt_root({})
    try:
        pack = os.path.join(root, PROSTATE)
        Path(pack, "handoff", "RELEASE_APPROVAL.yaml").write_text(
            "approved_by: Ada Lovelace\napproval_date: 2026-09-02\nvalidated_by: Grace Hopper\n"
            "validation_date: 2026-09-01\napproved_build_id: b1\napproved_manifest_sha256: " + "d" * 64 + "\n",
            encoding="utf-8")
        clean = dict(GREEN, publication_surface={"passed": True, "declared": True, "failures": []})
        ok = sm.publish_approval_errors(root, PROSTATE, "b1", "d" * 64, manifest=clean)
        assert not any("composed validation verdict" in w for w in ok), ok
        failed = dict(clean, publication_surface=failing["publication_surface"])
        why = sm.publish_approval_errors(root, PROSTATE, "b1", "d" * 64, manifest=failed)
        assert any("composed validation verdict FAILED" in w and "helper_col" in w for w in why), why
        malformed = sm.publish_approval_errors(root, PROSTATE, "b1", "d" * 64, manifest={"qc": 5})
        assert any("composed validation verdict FAILED" in w for w in malformed), malformed
        assert sm.publish_approval_errors(root, PROSTATE, "b1", "d" * 64) == ok, "no manifest: the form checks alone, as before"
    finally:
        shutil.rmtree(root, ignore_errors=True)


def test_the_runner_composes_every_stage_it_writes():
    """The job's stop reads the same list the manifest carries: the retention gate and the
    linkage stage used to reach the manifest and not the stop; the publication surface is
    computed after the output contract and passed to every manifest the job writes."""
    src = (FRAMEWORK / "databricks" / "run_rwdp.py").read_text(encoding="utf-8")
    i = src.index("_verdict_manifest = {"); j = src.index("candidate = candidate_verdict(_verdict_manifest)")
    block = src[i:j]
    for key in ("retention", "linkage", "publication_surface", "source_grain", "eda_acceptance", "golden", "differential"):
        assert f'"{key}"' in block, key
    assert src.count("linkage=_linkage_verdict") == 4 and src.count("publication_surface=_pub_surface") == 3
    assert src.index("_pub_surface = publication_surface_gate(") > src.index("oc_manifest = dict(oc_gate, report=oc_report)")
    assert "manifest=yaml.safe_load(_cand_bytes)" in src, "promotion reads the candidate's own verdict"


if __name__ == "__main__":
    console.use_utf8()
    failures = 0
    for name, fn in sorted(globals().items()):
        if name.startswith("test_") and callable(fn):
            try:
                fn()
                print(f"  ok   {name}")
            except Exception:                                                 # noqa: BLE001
                failures += 1
                print(f"  FAIL {name}")
                traceback.print_exc()
    print(f"{failures} failure(s)")
    sys.exit(1 if failures else 0)
