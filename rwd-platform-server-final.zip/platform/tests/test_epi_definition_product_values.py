"""Product values stay editable beside reusable logic, including with chat connected."""
import pytest
from pathlib import Path
import sys
sys.path.insert(0, str(Path(__file__).resolve().parent))
from test_epi_scientific_definition_page import app, button, editor, page, describe, fixture, governed_bytes


@pytest.mark.parametrize("kind", ["parameter", "constant"])
def test_direct_value_editor_keeps_logic_and_saves_only_product_draft(tmp_path, kind):
    root, pack, product, _values = fixture(tmp_path)
    before = governed_bytes(product)
    at = app(root, pack)
    at.text_area(key=page.PREFIX + "field_derivation").set_value("Apply the product's configured minimum date, inclusive.")
    at.button(key=page.PREFIX + "edit_values").click().run()
    assert not at.exception
    assert at.radio(key=page.PREFIX + "section").value == editor.SECTIONS[3]
    at.selectbox(key=page.PREFIX + "field_source_kind").set_value(kind).run()
    assert not at.exception
    value = at.text_input(key=page.PREFIX + "field_source_value")
    assert value.value == "" and value.label == "Value for this product"
    value.set_value("2015-01-01")
    if kind == "parameter":
        at.text_area(key=page.PREFIX + "field_source_parameters").set_value("study.index_start")
    at.button(key=page.PREFIX + "edit_logic").click().run()
    assert not at.exception
    assert at.text_area(key=page.PREFIX + "field_derivation").value == "Apply the product's configured minimum date, inclusive."
    button(at, "Save unfinished row draft").click().run()
    assert not at.exception
    saved = describe(root, pack)["values"]
    assert saved["source"]["kind"] == kind
    assert saved["source"]["value"] == "2015-01-01"
    assert "2015" not in saved["derivation"]
    assert governed_bytes(product) == before


def test_direct_editor_is_visible_when_chat_is_connected(tmp_path, monkeypatch):
    import scientific_definition_ai as row_ai
    import scientific_definition_ai_page as chat_page
    root, pack, _product, _values = fixture(tmp_path)
    monkeypatch.setattr(row_ai, "describe_availability", lambda *args, **kwargs:
                        {"ok": True, "configured": True, "source_eligible": True})
    monkeypatch.setattr(chat_page, "render", lambda *args, **kwargs: False)
    at = app(root, pack)
    at.button(key=page.PREFIX + "edit_values").click().run()
    assert not at.exception
    panel = next(panel for panel in at.expander if panel.label == "Review details and edit fields")
    assert panel.proto.expanded
    assert at.radio(key=page.PREFIX + "section").value == editor.SECTIONS[3]


def test_value_edit_shortcut_respects_view_only_access(tmp_path):
    root, pack, _product, _values = fixture(tmp_path)
    at = app(root, pack, can_write=False)
    assert at.button(key=page.PREFIX + "edit_values").disabled
    assert at.button(key=page.PREFIX + "edit_logic").disabled
