"""Exact engineering evidence, reviewed stale intent and bounded branch-history navigation."""
from pathlib import Path
import sys

import pytest
from streamlit.testing.v1 import AppTest

ROOT = Path(__file__).resolve().parents[2]
sys.path[:0] = [str(ROOT / p) for p in ("platform/tests", "experiments/portal")]
from test_epi_configuration_proposals import ACTOR, PACK, FOLLOWUP, seed, stage, brief, original_bytes
from test_epi_configuration_proposal_sharing import forge
from test_epi_configuration_proposal_sharing_page import button, healthy, open_shared
import configuration_proposals as cp
import design_workspace as dw
import handoffs

READER = "Engineering reviewer"


def packet(root, *, mixed=False, changes=None):
    seed(root, consumers=True)
    plan = brief(root, retained=["INDEXDT", "OS", "SUMMARY"],
        additions=[{"variable_id": "BASELINE_ALBUMIN", "domain": "labs", "definition": "Review baseline albumin timing and units."}],
        target_source="optum", target_modality="claims") if mixed else None
    staged = stage(root, plan=plan, changes=changes, exclusions=[{"study": "reader-a", "variables": ["AGE"]}] if mixed else [])
    assert staged["ok"], staged
    preview = cp.share_preview(root, PACK, proposal_id=staged["proposal_id"], actor_id=ACTOR, allowed_packs=[PACK])
    assert preview["ok"], preview
    return staged, preview


def share(root, staged, preview):
    result = cp.share(root, PACK, proposal_id=staged["proposal_id"], actor_id=ACTOR, expected_digest=preview["digest"],
        confirmed=True, local_demo=True, can_write=True, allowed_packs=[PACK])
    assert result["ok"], result
    return result


def request(root, staged, preview, **overrides):
    args = dict(proposal_id=staged["proposal_id"], actor_id=ACTOR, expected_digest=preview["digest"],
        note="Resolve the requested albumin implementation and the source mapping, retaining the study exclusion.",
        confirmed=True, local_demo=True, can_write=True, allowed_packs=[PACK])
    args.update(overrides)
    return cp.request_engineering(root, PACK, **args)


def test_engineer_opens_exact_packet_without_author_private_proposal_and_tampering_refuses(tmp_path):
    staged, preview = packet(tmp_path, mixed=True)
    sent = request(tmp_path, staged, preview)
    assert sent["ok"], sent
    assert sent["handoff"]["action_id"] == "configuration-proposal:" + preview["packet_id"] + ":" + preview["digest"]
    assert request(tmp_path, staged, preview)["changed"] is False
    assert len(handoffs.listing(tmp_path, PACK, allowed_packs=[PACK])) == 1
    assert not cp.load(tmp_path, PACK, proposal_id=staged["proposal_id"], actor_id=READER, allowed_packs=[PACK])["ok"]
    loaded = cp.load_engineering_request(tmp_path, PACK, sent["handoff"]["id"], actor_id=READER, allowed_packs=[PACK])
    assert loaded["ok"] and loaded["packet"] == preview["packet"]
    assert loaded["packet"]["proposal"]["study_exclusions"] == [{"study": "reader-a", "variables": ["AGE"]}]
    assert loaded["packet"]["proposal"]["approved"] is False
    (tmp_path / preview["path"]).write_text("{}", encoding="utf-8")
    assert not cp.load_engineering_request(tmp_path, PACK, sent["handoff"]["id"], actor_id=READER, allowed_packs=[PACK])["ok"]
    assert not cp.load_engineering_request(tmp_path, PACK, sent["handoff"]["id"], actor_id=READER, allowed_packs=[])["ok"]


@pytest.mark.parametrize("overrides", [{"confirmed": False}, {"can_write": False}, {"allowed_packs": []},
    {"actor_id": READER}, {"expected_digest": "0" * 64}, {"note": ""},
    {"note": "ANTHROPIC_API_KEY=sk-ant-synthetic-test-sentinel"}])
def test_engineering_refusal_has_no_shared_or_handoff_side_effects(tmp_path, overrides):
    staged, preview = packet(tmp_path, mixed=True)
    before = original_bytes(tmp_path)
    assert not request(tmp_path, staged, preview, **overrides)["ok"]
    assert original_bytes(tmp_path) == before
    assert not handoffs.listing(tmp_path, PACK, allowed_packs=[PACK])


def change_baseline(root):
    outcomes = root / PACK / "variables/outcomes.yaml"
    outcomes.write_text(outcomes.read_text(encoding="utf-8").replace("min_followup_days: 91", "min_followup_days: 110"), encoding="utf-8")
    contract = root / PACK / "handoff/FUNCTIONAL_CONTRACT.md"
    contract.write_text(contract.read_text(encoding="utf-8") + "\n```yaml\nvariable_id: NEW_CURRENT\nspec_refs: [clinical:2]\nrequired_rule: Current new rule\ndepends_on: []\nstatus: draft\n```\n", encoding="utf-8")


def test_stale_intent_preview_preserves_scope_and_source_without_old_validation_or_new_removals(tmp_path):
    staged, preview = packet(tmp_path, mixed=True)
    share(tmp_path, staged, preview)
    change_baseline(tmp_path)
    before = original_bytes(tmp_path)
    result = cp.shared_revision_preview(tmp_path, PACK, packet_id=preview["packet_id"], actor_id=READER, allowed_packs=[PACK])
    assert result["ok"], result
    assert result["baseline_sha256"] != staged["proposal"]["baseline_sha256"]
    restored = result["restore"]
    assert set(restored) == {"brief", "baseline_sha256", "configuration_changes", "study_exclusions"}
    assert "NEW_CURRENT" in restored["brief"]["kept"]
    assert restored["brief"]["removed"] == ["AGE", "UNUSED"]
    assert restored["study_exclusions"] == [{"study": "reader-a", "variables": ["AGE"]}]
    assert restored["brief"]["source"]["proposed"] == {"vendor": "optum", "modality": "claims"}
    assert any(row["Current"] == 110 and row["Requested"] == 97 for row in result["settings"])
    assert any("-min_followup_days: 110" in row["diff"] for row in result["files"])
    assert result["impact"]["shared_removed"] == ["UNUSED"]
    assert original_bytes(tmp_path) == before
    new = stage(tmp_path,
        plan=restored["brief"], changes=restored["configuration_changes"], exclusions=restored["study_exclusions"], actor_id=READER)
    assert new["ok"] and new["validation"] is None and new["submission"] is None
    assert new["proposal"]["engineering_handoff"]


def test_stale_preview_binds_current_consumers_and_unsupported_settings(tmp_path):
    staged, preview = packet(tmp_path, mixed=True, changes=[{"ref": FOLLOWUP, "value": 97}, {"ref": "unsupported#/rule", "value": "review"}])
    share(tmp_path, staged, preview)
    # A supported shape remains a visibly unsupported engineering request, not executable configuration.
    change_baseline(tmp_path)
    result = cp.shared_revision_preview(tmp_path, PACK, packet_id=preview["packet_id"], actor_id=READER, allowed_packs=[PACK])
    assert result["ok"] and result["unsupported_changes"] == [{"ref": "unsupported#/rule", "value": "review"}]
    pin = tmp_path / "work/reader-a/PINS.yaml"
    pin.write_text(pin.read_text(encoding="utf-8") + "\n# revised consumer evidence\n", encoding="utf-8")
    fresh = cp.shared_revision_preview(tmp_path, PACK, packet_id=preview["packet_id"], actor_id=READER, allowed_packs=[PACK])
    assert fresh["ok"] and fresh["digest"] != result["digest"]


def test_more_than_500_packets_remain_pageable_without_recomposing_every_packet(tmp_path, monkeypatch):
    staged, preview = packet(tmp_path)
    shared = share(tmp_path, staged, preview)
    for i in range(501):
        def change(p, i=i):
            p["proposal"]["proposal_id"] = f"{i:032x}"
        forge(tmp_path, shared["packet"], change)
    monkeypatch.setattr(cp, "load_shared", lambda *a, **k: pytest.fail("Listing must not fully load/recompose packets"))
    counted, checked = [], []
    baseline, validate = cp._branch_text_baseline, cp._check_shared
    monkeypatch.setattr(cp, "_branch_text_baseline", lambda *a: (counted.append(1), baseline(*a))[1])
    monkeypatch.setattr(cp, "_check_shared", lambda *a: (checked.append(1), validate(*a))[1])
    result = cp.list_shared(tmp_path, PACK, actor_id=READER, allowed_packs=[PACK], page=25)
    assert result["ok"] and result["total"] == 502 and result["records"] and not result["has_next"]
    assert len(checked) == 2 and len(counted) == 1
    first = cp.list_shared(tmp_path, PACK, actor_id=READER, allowed_packs=[PACK])
    assert len(first["records"]) == 20 and first["has_next"]


def test_collapsed_history_does_no_backend_read_and_opening_loads_selected_packet(tmp_path, monkeypatch):
    staged, preview = packet(tmp_path)
    share(tmp_path, staged, preview)
    counts = []
    original = cp.list_shared
    monkeypatch.setattr(cp, "list_shared", lambda *a, **k: (counts.append(1), original(*a, **k))[1])
    script = f"""
import sys
sys.path.insert(0, {str(ROOT / 'experiments/portal')!r})
import configuration_proposal_page as page
page.render_shared({str(tmp_path)!r}, {PACK!r}, {ACTOR!r}, local_demo=True, can_write=True, allowed_packs={[PACK]!r}, key='plan')
"""
    at = AppTest.from_string(script, default_timeout=45).run()
    healthy(at)
    assert not counts and not at.selectbox
    open_shared(at, tmp_path, ACTOR, "plan")
    assert counts == [1]
    assert button(at, "Restage this handoff here").disabled


def test_engineering_request_ui_opens_full_snapshot_and_stale_copy_is_unfinished(tmp_path, monkeypatch):
    staged, preview = packet(tmp_path, mixed=True)
    sent = request(tmp_path, staged, preview)
    assert sent["ok"], sent
    change_baseline(tmp_path)
    opened = []
    original_load = cp.load_engineering_request
    monkeypatch.setattr(cp, "load_engineering_request", lambda *a, **k: (opened.append(1), original_load(*a, **k))[1])
    script = f"""
import sys
sys.path.insert(0, {str(ROOT / 'experiments/portal')!r})
import streamlit as st
import handoffs_page, plan_changes_page
ctx = st.session_state.get('connected_workflow')
if ctx:
    plan_changes_page.render({str(tmp_path)!r}, {PACK!r}, actor_id={READER!r}, local_demo=True, can_write=True, allowed_packs={[PACK]!r}, params=ctx.get('params'))
else:
    handoffs_page.render({str(tmp_path)!r}, {PACK!r}, {READER!r}, local_demo=True, can_write=True, can_review=True, allowed_packs={[PACK]!r}, role='admin')
"""
    at = AppTest.from_string(script, default_timeout=60).run()
    healthy(at)
    assert not opened
    import configuration_proposal_page as page
    opened_key = page._shared_key(tmp_path, PACK, READER, True, True, [PACK], sent["handoff"]["id"]) + "_details_open"
    at.session_state[opened_key] = True
    at.run()
    healthy(at)
    assert opened == [1]
    assert any(staged["proposal_id"] in item.value and preview["digest"] in item.value for item in at.caption)
    assert button(at, "Continue this intent in the current product").disabled
    at.session_state[opened_key] = True
    next(item for item in at.checkbox if "reviewed these conflicts" in item.label).check().run()
    at.session_state[opened_key] = True
    button(at, "Continue this intent in the current product").click().run()
    healthy(at)
    assert at.radio(key="plan_guide_intent").value == "revision"
    assert at.text_area(key=f"design_{PACK}_purpose").value == staged["proposal"]["purpose"]
    assert at.multiselect(key=f"design_{PACK}_excluded").value == ["AGE", "UNUSED"]
    assert not cp.list_proposals(tmp_path, PACK, actor_id=READER, allowed_packs=[PACK])["proposals"]
    button(at, "Stage configuration proposal").click().run()
    healthy(at)
    rows = cp.list_proposals(tmp_path, PACK, actor_id=READER, allowed_packs=[PACK])["proposals"]
    assert len(rows) == 1
    loaded = cp.load(tmp_path, PACK, proposal_id=rows[0]["proposal_id"], actor_id=READER, allowed_packs=[PACK])
    assert loaded["validation"] is None and loaded["submission"] is None
    assert loaded["proposal"]["study_exclusions"] == [{"study": "reader-a", "variables": ["AGE"]}]


def test_engineering_request_requires_explicit_review_in_streamlit(tmp_path):
    staged, preview = packet(tmp_path, mixed=True)
    script = f"""
import sys
sys.path.insert(0, {str(ROOT / 'experiments/portal')!r})
import configuration_proposal_page as page
page._request_engineering({str(tmp_path)!r}, {PACK!r}, {staged['proposal_id']!r}, {ACTOR!r}, local_demo=True, can_write=True, allowed_packs={[PACK]!r})
"""
    at = AppTest.from_string(script, default_timeout=45).run()
    healthy(at)
    assert button(at, "Hand this reviewed proposal to Engineering").disabled
    at.text_area[0].set_value("Implement the requested rule and examine the changed source.").run()
    assert button(at, "Hand this reviewed proposal to Engineering").disabled
    at.checkbox[0].check().run()
    button(at, "Hand this reviewed proposal to Engineering").click().run()
    healthy(at)
    assert any("exact proposal" in message.value for message in at.success)
    sent = handoffs.listing(tmp_path, PACK, allowed_packs=[PACK])
    assert len(sent) == 1 and preview["digest"] in sent[0]["action_id"]


def test_stale_preview_reports_proposed_name_collision_before_filling_editor(tmp_path):
    staged, preview = packet(tmp_path, mixed=True)
    share(tmp_path, staged, preview)
    change_baseline(tmp_path)
    contract = tmp_path / PACK / "handoff/FUNCTIONAL_CONTRACT.md"
    contract.write_text(contract.read_text(encoding="utf-8").replace("NEW_CURRENT", "BASELINE_ALBUMIN"), encoding="utf-8")
    result = cp.shared_revision_preview(tmp_path, PACK, packet_id=preview["packet_id"], actor_id=READER, allowed_packs=[PACK])
    assert result["ok"] and any("BASELINE_ALBUMIN" in error for error in result["errors"])
    assert not cp.list_proposals(tmp_path, PACK, actor_id=READER, allowed_packs=[PACK])["proposals"]
