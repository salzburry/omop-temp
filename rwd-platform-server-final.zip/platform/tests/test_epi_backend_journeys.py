"""Adversarial authoring journeys, isolated from registered products and approvals."""
import os
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path
from types import SimpleNamespace

import yaml

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "platform" / "tools"))
import config_diff
import new_product


def _args(**changes):
    values = dict(slug="bladder_epi", code="bepi", name="Bladder exploratory",
                  vendor="flatiron", tumor_class="solid", spec_version="202609",
                  family="oncology", broad=None, narrow="genitourinary",
                  tumour_family="bladder", condition_class="oncology", modality="ehr",
                  disease_terms="", workbook=None, next_cut_of=None,
                  change_class=None, change_note="", ai_classification="sponsor_ai_eligible",
                  classified_by="Priya Natarajan", classified_date="2026-09-06")
    values.update(changes)
    return SimpleNamespace(**values)


def test_new_product_preserves_a_scientists_display_name_in_every_yaml():
    """Quotes, colon and backslashes are text, not YAML/replacement-program syntax."""
    for name in ('Bladder "Study A": exploratory', r"Bladder A\B cohort"):
        pack, steps = new_product.plan(_args(name=name), str(ROOT))
        docs = {rel: yaml.safe_load(payload) for rel, action, payload in steps
                if rel.endswith((".yaml", ".yml")) and action != "copy"}
        assert docs[f"{pack}/config/data_product.yaml"]["name"] == name + " RWDP"
        row = next(t for t in docs["products/registry.yaml"]["tumors"]
                   if t["slug"] == "bladder_epi")
        assert row["name"] == name


def test_new_tumour_overlay_preserves_colon_and_quotes():
    args = _args(slug="raretumour_epi", name='Rare tumour: "Study A"', tumour_family=None,
                 disease_terms="rare tumour carcinoma")
    _pack, steps = new_product.plan(args, str(ROOT))
    inventory = next(payload for rel, _action, payload in steps if rel.endswith("INVENTORY.yaml"))
    assert yaml.safe_load(inventory)["tumours"]["raretumour_epi"]["tumour"] == args.name.lower()


def test_new_product_rejects_multiline_names_and_invalid_family_before_staging():
    for changes, needle in (({"name": "Bladder\ncohort"}, "name"),
                            ({"name": "Bladder\rcohort"}, "name"),
                            ({"slug": "bladder_epi\n"}, "slug"),
                            ({"code": "bepi\n"}, "code"),
                            ({"family": "../outside"}, "family")):
        problems = new_product.refusals(_args(**changes), str(ROOT))
        assert any(needle in p for p in problems), problems


def test_next_cut_accepts_equivalent_yaml_version_formatting_and_preserves_rules():
    """An epi's prior draft still works after an editor has re-serialized its YAML."""
    for version in ('version: "202609.{snapshot}"', "version: '202609.{snapshot}'",
                    "version: 202609.{snapshot}"):
        with tempfile.TemporaryDirectory(prefix="epi_cut_") as root:
            template = Path(root, new_product.TEMPLATE_REL)
            shutil.copytree(ROOT / new_product.TEMPLATE_REL, template)
            old = "products/oncology/bladder_epi/202609"
            config = Path(root, old, "config/data_product.yaml")
            config.parent.mkdir(parents=True)
            config.write_text(version + "  # existing comment\nstudy: {index_start: 2018-01-01}\n",
                              encoding="utf-8")
            variable = Path(root, old, "variables/outcomes.yaml")
            variable.parent.mkdir()
            variable.write_text("outcomes: {exclusion_days: 30}\n", encoding="utf-8")
            registry = Path(root, "products/registry.yaml")
            entry = {"slug": "bladder_epi", "current_spec_version": "202609"}
            registry.write_text('tumors:\n  - {slug: bladder_epi, current_spec_version: "202609"}\n', encoding="utf-8")
            args = _args(spec_version="202610", workbook="revised.xlsx", next_cut_of=old,
                         change_class="additive", _old=old, _old_version="202609", _entry=entry)
            pack, steps = new_product.plan_next_cut(args, root)
            payloads = {rel: payload for rel, _action, payload in steps}
            doc = yaml.safe_load(payloads[f"{pack}/config/data_product.yaml"])
            assert doc["version"] == "202610.{snapshot}"
            assert "# existing comment" in payloads[f"{pack}/config/data_product.yaml"]
            assert payloads[f"{pack}/variables/outcomes.yaml"] == variable.read_text(encoding="utf-8")
            assert yaml.safe_load(payloads["products/registry.yaml"])["tumors"][0]["current_spec_version"] == "202609"


def test_failed_install_restores_crlf_and_binary_assets_byte_for_byte():
    with tempfile.TemporaryDirectory(prefix="epi_rollback_") as tmp:
        root, staged = Path(tmp, "root"), Path(tmp, "staged")
        root.mkdir()
        staged.mkdir()
        originals = {"registry.yaml": b"tumors: []\r\n# preserve CRLF\r\n",
                     "prior.xlsx": b"PK\x03\x04\xff\x00\x80original"}
        for rel, content in originals.items():
            (root / rel).write_bytes(content)
            (staged / rel).write_bytes(b"changed")
        (staged / "last.yaml").write_bytes(b"new")
        calls = []

        def fail_last(src, dst):
            calls.append(dst)
            if len(calls) == 3:
                raise OSError("simulated disk full")
            os.replace(src, dst)

        try:
            new_product.install(str(root), str(staged), [*originals, "last.yaml"], _replace=fail_last)
        except OSError as exc:
            assert "simulated disk full" in str(exc)
        else:
            raise AssertionError("install must surface the write failure")
        assert len(calls) == 3, "binary backup must not fail before the actual write operation"
        for rel, content in originals.items():
            assert (root / rel).read_bytes() == content, rel
        assert not (root / "last.yaml").exists()
        assert not list(root.glob("*.new_product.tmp"))


def test_section_codelist_and_source_mapping_lists_are_material_changes():
    examples = [
        ({"variables": ["variables/clinical.yaml", "variables/outcomes.yaml"]},
         {"variables": ["variables/clinical.yaml"]}),
        ({"variables": ["variables/clinical.yaml"]},
         {"variables": ["variables/clinical.yaml", "variables/outcomes.yaml"]}),
        ({"codes": ["C67.0", "C67.1"]}, {"codes": ["C67.0", "C67.2"]}),
        ({"mortality_precedence": ["ehr", "linked"]}, {"mortality_precedence": ["linked", "ehr"]}),
        ({"accepted_physical_types": ["date"]}, {"accepted_physical_types": ["date", "string"]}),
    ]
    for before, after in examples:
        findings = config_diff.diff_docs(before, after)
        assert findings, (before, after)
        assert config_diff.material_changes({"config/data_product.yaml": findings}), findings
    assert not config_diff.material_changes({"config/data_product.yaml":
        config_diff.diff_docs({"run": {"refresh": "a"}}, {"run": {"refresh": "b"}})})


def test_failed_new_pack_install_can_be_retried_without_manual_folder_cleanup():
    with tempfile.TemporaryDirectory(prefix="epi_retry_") as tmp:
        root, staged = Path(tmp, "root"), Path(tmp, "staged")
        root.mkdir()
        rels = ["products/oncology/bladder_epi/202609/config/data_product.yaml",
                "products/oncology/bladder_epi/202609/variables/outcomes.yaml"]
        for rel in rels:
            source = staged / rel
            source.parent.mkdir(parents=True, exist_ok=True)
            source.write_text("draft: true\n", encoding="utf-8")
        calls = []

        def fail_second(src, dst):
            calls.append(dst)
            if len(calls) == 2:
                raise OSError("simulated failure")
            os.replace(src, dst)

        try:
            new_product.install(str(root), str(staged), rels, _replace=fail_second)
        except OSError:
            pass
        else:
            raise AssertionError("the failed installation must not succeed")
        assert not (root / "products").exists(), "a failed pack must not block the next creation attempt"
        assert new_product.install(str(root), str(staged), rels) == rels
        assert all((root / rel).is_file() for rel in rels)


def test_removed_section_cannot_be_labelled_cosmetic_on_an_active_product():
    """Exercise the actual Git-backed guard after a scientist removes Outcomes."""
    with tempfile.TemporaryDirectory(prefix="epi_sections_") as root:
        pack = "products/oncology/bladder_epi/202609"
        cfg = Path(root, pack, "config/data_product.yaml")
        cfg.parent.mkdir(parents=True)
        cfg.write_text("variables: [variables/clinical.yaml, variables/outcomes.yaml]\n", encoding="utf-8")
        registry = Path(root, "products/registry.yaml")
        registry.write_text(yaml.safe_dump({"tumors": [{"slug": "bladder_epi", "status": "active",
                               "current_spec_version": "202609"}]}), encoding="utf-8")
        for args in (("init", "-q"), ("add", "-A"),
                     ("-c", "user.name=Epi Test", "-c", "user.email=epi@test.invalid", "commit", "-qm", "base")):
            subprocess.run(["git", "-C", root, *args], check=True, capture_output=True)
        cfg.write_text("variables: [variables/clinical.yaml]\n", encoding="utf-8")
        Path(root, pack, "CHANGELOG.md").write_text(
            "- 2026-09-06 none 202609: Remove Outcomes (config/data_product.yaml)\n", encoding="utf-8")
        findings = config_diff.versioning_findings(pack, "HEAD", root=root)
        assert findings and any("MATERIAL" in f for f in findings), findings


if __name__ == "__main__":
    for name, fn in sorted(list(globals().items())):
        if name.startswith("test_") and callable(fn):
            fn()
            print(f"ok {name}")
