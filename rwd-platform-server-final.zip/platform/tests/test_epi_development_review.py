"""Portable demo confirmations, content binding and separation from production."""
from pathlib import Path
import json
import shutil
import sys
from unittest.mock import patch

import pytest
import yaml

ROOT = Path(__file__).resolve().parents[2]
sys.path[:0] = [str(ROOT / "experiments/portal"), str(ROOT / "platform/tools")]
import approval_identity
import development_review as development
import review_setup

PACK = "products/oncology/demo/202609"
PRIMARY = "Priya Sharma"
INDEPENDENT = "Alex Morgan"


@pytest.fixture
def product(tmp_path):
    root = tmp_path / "original"
    product = root / PACK
    (product / "handoff").mkdir(parents=True)
    (product / "prog_spec").mkdir()
    (product / "prog_spec/specification.md").write_text("Example specification\n")
    (product / "source_refs.yaml").write_text(yaml.safe_dump({"source_materials": [
        {"material_id": "program_spec", "classified_by": PRIMARY, "approved_by": PRIMARY}]}))
    return root


def confirm(root, who=PRIMARY, email="priya@example.test", checkpoint="source", **kwargs):
    prepared = review_setup.development_snapshot(root, PACK, checkpoint)
    return review_setup.confirm_development(root, PACK, checkpoint, who, email, prepared["digest"],
        confirmed=True, local_demo=True, can_review=True, **kwargs)


def test_email_confirmation_needs_no_git_registry_or_machine_key_and_survives_move(product, tmp_path):
    with patch.object(review_setup, "_git", side_effect=AssertionError("No Git required")), \
         patch.object(approval_identity, "audit", side_effect=AssertionError("No signing required")):
        result = confirm(product)
        assert result["ok"] and result["development_only"]
        assert len(development.confirmed_claims(product, PACK)) == 2
        moved = tmp_path / "another_server"
        shutil.copytree(product, moved)
        assert development.confirmed_claims(moved, PACK) == development.confirmed_claims(product, PACK)
        confirm(moved)  # Copying a released OS lock carries no machine identity.
    assert not (product / ".git").exists()
    assert not (product / "governance/allowed_signers.yaml").exists()
    rows, _errors = approval_identity.audit(str(product))
    assert rows and all(not row["authenticated"] and not row["signature_verified"] for row in rows)


@pytest.mark.parametrize("relative", ["source_refs.yaml", "prog_spec/specification.md"])
def test_changed_reviewed_bytes_require_new_confirmation(product, relative):
    confirm(product)
    path = product / PACK / relative
    path.write_text(path.read_text() + "\n# Edited after review\n")
    assert development.confirmed_claims(product, PACK) == set()
    confirm(product)
    assert development.confirmed_claims(product, PACK)


def test_later_scientific_work_does_not_invalidate_source_confirmation(product):
    confirm(product)
    (product / PACK / "handoff/FUNCTIONAL_CONTRACT.md").write_text("A later scientific contract\n")
    assert development.confirmed_claims(product, PACK)


def test_stale_form_is_rejected_without_recording(product):
    prepared = review_setup.development_snapshot(product, PACK, "source")
    (product / PACK / "prog_spec/new.md").write_text("New requirement")
    with pytest.raises(review_setup.Refused, match="changed"):
        review_setup.confirm_development(product, PACK, "source", PRIMARY, "priya@example.test", prepared["digest"],
            confirmed=True, local_demo=True, can_review=True)
    assert not (product / PACK / development.RECORD).exists()


@pytest.mark.parametrize("flag", ["confirmed", "local_demo", "can_review"])
def test_production_mode_missing_permission_or_confirmation_cannot_write(product, flag):
    prepared = review_setup.development_snapshot(product, PACK, "source")
    flags = {"confirmed": True, "local_demo": True, "can_review": True, flag: False}
    with pytest.raises(review_setup.Refused):
        review_setup.confirm_development(product, PACK, "source", PRIMARY, "priya@example.test", prepared["digest"], **flags)
    assert not (product / PACK / development.RECORD).exists()


def science(root, independent=INDEPENDENT):
    (root / PACK / "handoff/CONTRACT_APPROVAL.yaml").write_text(yaml.safe_dump({
        "approved_by": PRIMARY, "spec_qc_reviewed_by": independent}))


def test_primary_and_independent_reviewers_confirm_separately(product):
    science(product)
    confirm(product, checkpoint="science")
    accepted = development.confirmed_claims(product, PACK)
    assert {claim[2] for claim in accepted} == {PRIMARY}
    with pytest.raises(review_setup.Refused, match="separate email"):
        confirm(product, who=INDEPENDENT, email="PRIYA@example.test", checkpoint="science")
    confirm(product, who=INDEPENDENT, email="alex@example.test", checkpoint="science")
    assert {claim[2] for claim in development.confirmed_claims(product, PACK)} == {PRIMARY, INDEPENDENT}
    prepared = review_setup.development_snapshot(product, PACK, "science")
    assert set(prepared["confirmed_reviewers"]) == {PRIMARY, INDEPENDENT}


def test_same_person_cannot_fill_primary_and_independent_roles(product):
    science(product, independent="PRIYA_SHARMA")
    with pytest.raises(review_setup.Refused, match="different people"):
        review_setup.development_snapshot(product, PACK, "science")


def test_bad_email_or_wrong_reviewer_cannot_record(product):
    with pytest.raises(review_setup.Refused, match="email"):
        confirm(product, email="not-an-email")
    with pytest.raises(review_setup.Refused, match="named"):
        confirm(product, who="Unrelated Person")


def test_corrupt_record_grants_nothing_and_is_preserved(product):
    path = product / PACK / development.RECORD
    path.write_text("{broken")
    assert not development.confirmed_claims(product, PACK)
    with pytest.raises(review_setup.Refused):
        confirm(product)
    assert path.read_text() == "{broken"


def test_reconfirm_updates_one_person_without_losing_another(product):
    science(product)
    confirm(product, checkpoint="science")
    confirm(product, who=INDEPENDENT, email="alex@example.test", checkpoint="science")
    confirm(product, checkpoint="science", email="priya.updated@example.test")
    rows = json.loads((product / PACK / development.RECORD).read_text())["reviews"]
    assert len(rows) == 2
    assert next(row for row in rows if row["reviewer"] == INDEPENDENT)["email"] == "alex@example.test"


def test_merging_records_cannot_count_shared_email_as_separate_reviewers(product):
    science(product)
    confirm(product, checkpoint="science")
    confirm(product, who=INDEPENDENT, email="alex@example.test", checkpoint="science")
    path = product / PACK / development.RECORD
    document = json.loads(path.read_text())
    document["reviews"][1]["email"] = "PRIYA@example.test"
    path.write_text(json.dumps(document))
    assert not development.confirmed_claims(product, PACK)
