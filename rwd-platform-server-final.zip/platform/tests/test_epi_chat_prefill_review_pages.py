"""Chat fills the existing draft fields; original review/save boundaries remain."""
import ast
import copy
from pathlib import Path
import sys
from unittest.mock import patch

import pytest
from streamlit.testing.v1 import AppTest

ROOT = Path(__file__).resolve().parents[2]
sys.path[:0] = [str(ROOT / "platform/tests"), str(ROOT / "platform/tools"), str(ROOT / "experiments/portal")]
from test_epi_lifecycle_workspace import fixture as lifecycle_fixture
from test_epi_science_workspace_page import REPORT as SCIENCE_REPORT
from test_epi_template_library_workspace_page import REPORT as TEMPLATE_REPORT, PACK
from test_epi_workflow_improvement_page import checkout as learning_checkout
from test_epi_specialist_workspace import setup as specialist_setup, PACK as SPECIALIST_PACK, ACTOR
from test_epi_release_workspace import checkout as release_checkout, add_receipt, PACK as RELEASE_PACK

import science_workspace
import template_library_workspace
import specialist_workspace
import handoffs
import form_assistance as form_help


def app(root, pack, body):
    code = f'''import streamlit as st
import form_assistance as form_help
actor = st.session_state.get("actor", "Local scientist")
write = st.session_state.get("write", True)
form_help.begin({str(root)!r}, {pack!r}, actor, page="review-prefill", allowed_packs=[{pack!r}], can_write=write)
form_help.review()
{body}
if proposal := st.session_state.pop("test_proposal", None):
    try:
        form_help.stage(proposal)
    except ValueError as error:
        st.warning(str(error))
form_help.finish()
st.session_state["test_public"] = form_help.context()
'''
    result = AppTest.from_string(code, default_timeout=45).run()
    healthy(result)
    return result


def healthy(at):
    assert not at.exception, [value.message for value in at.exception]


def labels(at):
    return {field["label"] for field in (at.session_state["test_public"] or {}).get("fields", [])}


def suggest(at, values):
    public = at.session_state["test_public"]
    fields = {field["label"]: field["id"] for field in public["fields"]}
    at.session_state["test_proposal"] = {"scope": public["scope"], "fields": [{"id": fields[label], "value": value} for label, value in values.items()]}
    at.run()
    healthy(at)
    return at


def test_workflow_review_notes_prefill_calls_existing_cache_callback_without_people_dates_or_classification(tmp_path):
    body = '''import workflow_forms_page as page
description = {"manifest_digest": "same-evidence", "target": "review", "fields": [
    {"name": "approved_by", "label": "Actual reviewer"},
    {"name": "approval_date", "label": "Actual review date"},
    {"name": "ai_classification", "label": "AI access classification", "choices": ["allowed", "restricted"]},
    {"name": "notes", "label": "Review notes"}]}
page._human_fields(description, write)
st.checkbox("Actual confirmation", key="workflow_forms_confirm")
'''
    at = app(tmp_path, PACK, body)
    assert labels(at) == {"Review notes"}
    suggest(at, {"Review notes": "Compare the selected definition with the stated timing window."})
    assert at.text_area(key="workflow_forms_value_notes").value.startswith("Compare the selected")
    assert at.session_state["workflow_forms_values"]["notes"].startswith("Compare the selected")
    assert not at.checkbox(key="workflow_forms_confirm").value
    assert at.text_input(key="workflow_forms_value_approved_by").value == ""
    assert at.text_input(key="workflow_forms_value_approval_date").value == ""
    assert at.selectbox(key="workflow_forms_value_ai_classification").value is None


def test_protocol_replacement_shows_review_diff_and_cannot_save_itself(tmp_path):
    root, _product, pack, path = lifecycle_fixture(tmp_path)
    before = path.read_bytes()
    body = f'''import lifecycle_workspace_page as page
page.render({str(root)!r}, {pack!r}, actor, allowed_packs=[{pack!r}], local_demo=True,
    can_write=write, can_review=True, route="study_protocol", params={{"study": "study-1"}})
'''
    at = app(root, pack, body)
    assert labels(at) == {"Protocol title", "Objectives (structured YAML)", "Design", "Population", "Endpoints", "Analyses (structured YAML)"}
    old = at.text_area(key="lifecycle_protocol_design").value
    suggest(at, {"Design": "A retrospective cohort design comparing the prespecified treatment groups."})
    assert at.text_area(key="lifecycle_protocol_design").value == old
    at.button(key="chat_form_replace").click().run()
    healthy(at)
    assert at.text_area(key="lifecycle_protocol_design").value.startswith("A retrospective cohort")
    assert path.read_bytes() == before
    assert not any(button.label == "Save protocol draft" for button in at.button)


def science_app(report):
    body = f'''import science_workspace_page as page
page.render({str(ROOT)!r}, {PACK!r}, actor, allowed_packs=[{PACK!r}], local_demo=True,
    can_write=write, can_review=True, route="definition_reuse", params={{}})
'''
    return app(ROOT, PACK, body)


def test_science_draft_fields_fill_existing_widgets_without_running_validators_or_approving():
    with patch.object(science_workspace, "describe", return_value=SCIENCE_REPORT), patch.object(science_workspace, "stage") as stage:
        at = science_app(SCIENCE_REPORT)
        assert labels(at) == {"Proposed reuse choice", "Your proposed interpretation", "Why this choice, and what remains unresolved?"}
        suggest(at, {"Your proposed interpretation": "Use the closest observation before index; leave the tie choice open.",
                     "Why this choice, and what remains unresolved?": "The index window needs scientific review."})
        assert at.text_area(key="science_definition_reuse_interpretation").value.startswith("Use the closest")
        assert at.selectbox(key="science_definition_reuse_disposition").value == "defer"
        stage.assert_not_called()


def test_science_candidate_change_rejects_a_suggestion_bound_to_the_previous_comparison():
    report = copy.deepcopy(SCIENCE_REPORT)
    report["candidates"].append({**report["candidates"][0], "key": "second-candidate", "variable_id": "OTHER"})
    with patch.object(science_workspace, "describe", return_value=report), patch.object(science_workspace, "stage") as stage:
        at = science_app(report)
        at.selectbox(key="science_definition_reuse_candidate").set_value("second-candidate")
        suggest(at, {"Your proposed interpretation": "This belongs to the previous comparison."})
        assert at.text_area(key="science_definition_reuse_interpretation").value == ""
        assert any("source context changed" in message.value for message in at.warning)
        stage.assert_not_called()


def test_template_candidate_prefill_excludes_review_attribution_and_does_not_submit():
    body = f'''import template_library_workspace_page as page
page.render({str(ROOT)!r}, {PACK!r}, actor, allowed_packs=[{PACK!r}], local_demo=True,
    can_write=write, can_review=True, params={{}})
'''
    with patch.object(template_library_workspace, "describe", return_value=TEMPLATE_REPORT), patch.object(template_library_workspace, "stage") as stage:
        at = app(ROOT, PACK, body)
        assert labels(at) == {"Proposed template ID", "Proposed version", "Reusable meaning, limitations and version change"}
        suggest(at, {"Proposed template ID": "baseline_performance", "Proposed version": "1.0.0",
                     "Reusable meaning, limitations and version change": "Retain the shared measurement; review source-specific limits separately."})
        assert at.text_input(key="template_library_id").value == "baseline_performance"
        assert at.text_input(key="template_library_reviewer").value == ""
        assert at.text_input(key="template_library_date").value == ""
        stage.assert_not_called()


def test_handoff_note_prefill_never_sends_the_request_or_changes_owner(tmp_path):
    body = f'''import handoffs_page as page
page.ask({str(tmp_path)!r}, {PACK!r}, {{"id": "g2_draft", "label": "Draft a definition"}}, {{"owner": "Science"}},
    actor, local_demo=True, can_view=True, allowed_packs=[{PACK!r}])
'''
    with patch.object(handoffs, "listing", return_value=[]), patch.object(handoffs, "create") as create:
        at = app(tmp_path, PACK, body)
        assert labels(at) == {"What exactly do you need, in your words? (required)"}
        owner = at.selectbox(key="handoffs_ask_owner_g2_draft").value
        suggest(at, {"What exactly do you need, in your words? (required)": "Clarify the selected row's missing-value rule before review."})
        assert at.text_area(key="handoffs_ask_note_g2_draft").value.startswith("Clarify the selected")
        assert at.selectbox(key="handoffs_ask_owner_g2_draft").value == owner
        create.assert_not_called()


def test_specialist_request_prefill_preserves_explicit_model_run(specialist_setup):
    body = f'''import specialist_workspace_page as page
page.render({str(specialist_setup)!r}, {SPECIALIST_PACK!r}, actor, allowed_packs=[{SPECIALIST_PACK!r}],
    local_demo=True, can_write=write, can_review=True, can_agent=True, route="specialist_assistant", params={{"kind": "validation"}})
'''
    with patch.object(specialist_workspace, "run") as run:
        at = app(specialist_setup, SPECIALIST_PACK, body)
        assert labels(at) == {"Which failure should it examine?"}
        suggest(at, {"Which failure should it examine?": "Explain why the selected source mapping is incomplete."})
        assert at.text_area(key="specialist_ws_failure").value.startswith("Explain why")
        run.assert_not_called()


def test_improvement_prefill_does_not_save_activate_or_change_scope(learning_checkout):
    root, loop, calls = learning_checkout
    body = f'''import workflow_improvement_page as page
page.render_step({str(root)!r}, actor, "scientific_draft", can_write=write, can_review=True,
    local_demo=True, pack={PACK!r}, allowed_packs=[{PACK!r}])
'''
    at = app(root, PACK, body)
    assert labels(at) == {"What happened or worked well?", "What should the assistant do next time?", "When should this guidance apply?", "An example request to test"}
    suggest(at, {"What should the assistant do next time?": "Keep the selected row when returning from source review."})
    assert at.text_area(key="workflow_improvement_step_right").value.startswith("Keep the selected")
    assert not at.checkbox(key="workflow_improvement_step_confirm_save").value
    assert not loop.corrections(root) and not calls


def test_stage_five_six_release_prefills_request_note_only(release_checkout):
    relative, _ = add_receipt(release_checkout)
    body = f'''import release_workspace_page as page
page.render({str(release_checkout)!r}, {RELEASE_PACK!r}, actor, allowed_packs=[{RELEASE_PACK!r}], local_demo=True,
    can_write=write, can_review=True, params={{"receipt": {relative!r}}})
'''
    at = app(release_checkout, RELEASE_PACK, body)
    assert labels(at) == {"What should they check?"}
    suggest(at, {"What should they check?": "Examine the missing validation layer for this exact build."})
    assert at.text_area(key="release_workspace_note").value.startswith("Examine the missing")
    assert at.selectbox(key="release_workspace_owner").value is None
    assert not at.checkbox(key="release_workspace_confirm").value


def test_read_only_capture_has_no_edit_catalog_and_keeps_manual_fields():
    with patch.object(template_library_workspace, "describe", return_value=TEMPLATE_REPORT):
        body = f'''import template_library_workspace_page as page
page.render({str(ROOT)!r}, {PACK!r}, actor, allowed_packs=[{PACK!r}], local_demo=True,
    can_write=write, can_review=True, params={{}})
'''
        at = app(ROOT, PACK, body)
        at.session_state["write"] = False
        at.run()
        healthy(at)
        assert at.session_state["test_public"] is None


def test_review_page_opt_ins_exclude_identity_status_paths_filters_and_evidence_controls():
    modules = ["lifecycle_workspace_page", "release_workspace_page", "workflow_forms_page", "handoffs_page", "specialist_workspace_page",
               "eda_workspace_page", "knowledge_workspace_page", "workflow_improvement_page", "template_library_workspace_page", "science_workspace_page"]
    opted = []
    for name in modules:
        tree = ast.parse((ROOT / "experiments/portal" / (name + ".py")).read_text(encoding="utf-8"))
        calls = [node for node in ast.walk(tree) if isinstance(node, ast.Call) and isinstance(node.func, ast.Attribute)
                 and isinstance(node.func.value, ast.Name) and node.func.value.id == "form_help" and node.func.attr == "field"]
        if name in {"eda_workspace_page", "knowledge_workspace_page"}:
            assert calls == []  # evidence filenames, searches and navigation only
        for node in calls:
            assert isinstance(node.args[0], ast.Attribute) and node.args[0].attr in form_help.KINDS
            assert any(keyword.arg == "binding" for keyword in node.keywords)
            if isinstance(node.args[1], ast.Constant):
                opted.append(node.args[1].value)
    assert not set(opted) & {"Record", "AI access classification", "Review disposition", "Person registering this protocol",
        "Date of that review", "Who actually reviewed this library recommendation?", "Exact build receipt", "EDA report filename",
        "Candidate sidecar path", "Parameters used (YAML mapping)", "Returned artifacts (name = full path, one per line)",
        "Stated claim reviewer", "Stated claim review date", "Proposed registration author", "Proposed registration date"}
