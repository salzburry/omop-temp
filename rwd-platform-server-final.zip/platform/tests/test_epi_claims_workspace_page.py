"""The claims form carries real answers through validation, branch save and review."""
from pathlib import Path
import sys
from unittest.mock import patch

import pytest
from streamlit.testing.v1 import AppTest

ROOT = Path(__file__).resolve().parents[2]
sys.path[:0] = [str(ROOT / "platform/tests"), str(ROOT / "experiments/portal")]
from test_epi_claims_workspace import checkout, PACK, ACTOR, VALUES
import claims_workspace as claims


def page(root, *, can_write=True):
    source = f'''import streamlit as st
import claims_workspace_page as page
result = page.render({str(root)!r}, {PACK!r}, {ACTOR!r}, allowed_packs=[{PACK!r}],
 local_demo=True, can_write={can_write!r})
if result: st.session_state['navigation_result'] = result
'''
    at = AppTest.from_string(source, default_timeout=45).run()
    assert not at.exception, [error.message for error in at.exception]
    return at


def fill(at):
    at.text_input(key="claims_ws_event_0").set_value("ovarian")
    at.selectbox(key="claims_ws_event_0_dx_cd").set_value("ovarian_dx").run()
    at.selectbox(key="claims_ws_criterion_0").set_value("ovarian").run()
    return at


def test_no_initial_scientific_defaults_and_checked_save_requires_explicit_review(checkout):
    at = page(checkout)
    assert not at.text_input(key="claims_ws_event_0").value
    assert at.selectbox(key="claims_ws_event_0_dx_cd").value is None
    assert at.selectbox(key="claims_ws_criterion_0").value is None
    fill(at).button(key="claims_ws_stage").click().run()
    assert not at.exception, [error.message for error in at.exception]
    assert not at.error, [error.value for error in at.error]
    assert at.button(key="claims_ws_save").disabled
    assert any("config/cohortly_bindings.yaml (proposed)" in item.value for item in at.code)
    at.checkbox(key="claims_ws_confirm").check().run()
    at.button(key="claims_ws_save").click().run()
    assert not at.exception and not at.error
    assert (checkout / PACK / claims.BINDINGS).is_file()
    assert at.session_state["navigation_result"]["changed"]
    at.run()
    assert at.button(key="claims_ws_request").disabled
    at.text_area(key="claims_ws_note").set_value("Check the installed runtime and source cut.").run()
    at.button(key="claims_ws_request").click().run()
    assert not at.error and at.session_state["navigation_result"]["route"] == "handoffs"


def test_edit_after_staging_disables_save_and_never_applies_old_answers(checkout):
    at = fill(page(checkout))
    at.button(key="claims_ws_stage").click().run()
    at.checkbox(key="claims_ws_confirm").check().run()
    at.text_input(key="claims_ws_event_0").set_value("changed_event").run()
    assert at.button(key="claims_ws_save").disabled
    assert any("form changed" in warning.value.lower() for warning in at.warning)
    assert not (checkout / PACK / claims.BINDINGS).exists()


def test_read_only_user_can_inspect_existing_rules_without_staging(checkout):
    at = page(checkout, can_write=False)
    assert at.button(key="claims_ws_stage").disabled
    assert any("blocking gap" in warning.value for warning in at.warning)
    assert at.get("download_button")
