"""Ninth external review (2026-09-03, an epidemiologist's UAT at main 7071569) — failing first.

  P0  quick_counts: `--by` accepted any column and printed group values (an identifier escaped);
      counts were bound to nothing — pack existence, the variable's pack, the frame's schema, its
      grain, a data cut — so a plausible number could come from the wrong context
  P1  intake: unknown requirements silently dropped; ISO dates rejected by the splitter; bad designs
      accepted (look-back after index, outcome-dependent exclusion, "whichever gives more");
      whitespace accepted; a contract variable refused where the prompt offered it; no product brief
  P1  portal: five hard-coded fixture paths; no product / reference / template separation; no
      persistent fixture badge; no lifecycle view
  P2  search hits rendered without pack, state or detail; the top question shown as raw markup

NO PYTEST FIXTURES AND NO `parametrize` — CI runs every suite as a script.
"""
import ast
import copy
import io
import json
import os
import sys
import tempfile
from contextlib import redirect_stdout
from pathlib import Path
from types import SimpleNamespace

FRAMEWORK = Path(__file__).resolve().parent.parent
ROOT = FRAMEWORK.parent
AGENT = ROOT / "experiments" / "agent"
for p in (FRAMEWORK / "tools", FRAMEWORK / "engine", AGENT, ROOT / "experiments" / "portal"):
    sys.path.insert(0, str(p))
os.environ.setdefault("ANTHROPIC_API_KEY", "not-a-key-tests-never-call")

P = "fixtures/oncology/prostate/202606"
OC = "fixtures/oncology/oc/202606"


def _read(rel):
    return (ROOT / rel).read_text(encoding="utf-8")


def _frame(d, rows, header):
    path = os.path.join(d, "frame.tsv")
    with open(path, "w", encoding="utf-8", newline="\n") as fh:
        fh.write("\t".join(header) + "\n")
        for r in rows:
            fh.write("\t".join(str(x) for x in r) + "\n")
    return path


def _run(argv):
    import quick_counts as qc  # noqa: PLC0415
    buf = io.StringIO()
    try:
        with redirect_stdout(buf):
            rc = qc.main(argv)
    except SystemExit as e:
        return None, str(e), buf.getvalue()
    return rc, None, buf.getvalue()


# ------------------------------------------------------------------ P0 the count lane

def test_grouping_is_restricted_to_approved_categorical_dimensions_of_this_pack():
    import quick_counts as qc  # noqa: PLC0415
    ok, why = qc.approved_dimension(P, "ecog")
    assert ok, why
    for col, needle in (("patientid", "identifier"), ("patient_id", "identifier"), ("mrn", "identifier"),
                        ("zip", "identifier"), ("dob", "identifier"), ("index_date", "date"),
                        ("ttd", "not categorical"), ("free_text_note", "free text"), ("bogus_col", "not defined")):
        ok, why = qc.approved_dimension(P, col)
        assert not ok and needle in why, (col, why)
    with tempfile.TemporaryDirectory() as d:
        rows = [("PATIENT-0001", "C2", "1") for _ in range(12)]
        path = _frame(d, rows, ["patientid", "cohort", "ecog"])
        rc, err, out = _run([P, "--frame", path, "--by", "patientid", "--cut", "2023Q4", "--grain", "event",
                             "--log-dir", os.path.join(d, "log")])
        assert rc is None and "identifier" in err.lower(), (err, out)
        assert "PATIENT-0001" not in out and "PATIENT-0001" not in err, "the identifier value never leaves the tool"


def test_every_count_is_bound_to_pack_release_cut_frame_and_grain():
    with tempfile.TemporaryDirectory() as d:
        log = os.path.join(d, "log")
        # a pack that does not exist is refused, synthetic or not
        rc, err, _ = _run(["fixtures/oncology/nowhere/202699", "--synthetic", "30", "--by", "ecog", "--log-dir", log])
        assert rc is None and "not a registered pack" in err, err
        # a frame needs a data cut and a declared grain
        rows = [(f"P{i:04d}", "C2", str(i % 3)) for i in range(40)]
        path = _frame(d, rows, ["patientid", "cohort", "ecog"])
        rc, err, _ = _run([P, "--frame", path, "--by", "ecog", "--log-dir", log])
        assert rc is None and "--cut" in err and "--grain" in err, err
        # the declared grain is checked: 40 rows, 40 distinct ids -> patient grain holds
        rc, err, out = _run([P, "--frame", path, "--by", "ecog", "--cut", "2023Q4", "--grain", "patient", "--log-dir", log])
        assert rc == 0, err
        res = json.loads(out)
        ident = res["identity"]
        for k in ("pack", "spec_version", "cut", "frame_sha256", "grain", "dimension", "frame_rows"):
            assert ident.get(k) not in (None, ""), (k, ident)
        assert ident["pack"] == P and ident["grain"] == "patient" and ident["dimension"] == "ecog"
        # duplicate ids under a claimed patient grain are refused, not counted
        dup = [("P0001", "C2", "1")] * 20 + [(f"P{i:04d}", "C2", "2") for i in range(20)]
        path2 = _frame(d, dup, ["patientid", "cohort", "ecog"])
        rc, err, _ = _run([P, "--frame", path2, "--by", "ecog", "--cut", "2023Q4", "--grain", "patient", "--log-dir", log])
        assert rc is None and "one row per patient" in err, err
        # a frame whose headers are not this pack's variables (a profile/metadata TSV) is refused
        meta = _frame(d, [("t1", "c1", "numeric")] * 15, ["profile_product_id", "table", "type"])
        rc, err, _ = _run([P, "--frame", meta, "--by", "type", "--cut", "2023Q4", "--grain", "event", "--log-dir", log])
        assert rc is None and ("not this pack's" in err or "not defined" in err), err
        # a variable defined only in another pack does not resolve for this one
        import quick_counts as qc  # noqa: PLC0415
        res_ = qc.resolve_for_pack(["ecog"], OC)
        assert res_["ecog"]["resolution"] != "defined" or P not in str(res_["ecog"]), res_


# ------------------------------------------------------------------ P1 intake

def test_precheck_parses_dates_and_refuses_bad_designs_and_blank_values():
    import intake  # noqa: PLC0415
    st = intake.new_state("feasibility", P, "alex")
    st["request"].update({"source": "Optum claims 2023", "population": "COPD", "index_codes": "J44",
                          "time_window": "2024-01-01 to 2024-12-31", "baseline_lookback": "12 months",
                          "exclusions": "asthma", "code_position": "any position", "measure": "patients",
                          "requested_by": "alex"})
    f = intake.precheck(st, [P])
    assert not any("time_window" in x for x in f), f
    bad = copy.deepcopy(st)
    bad["request"].update({"time_window": "13/2024", "baseline_lookback": "12 months after index",
                           "exclusions": "exclude patients who survive the outcome",
                           "code_position": "whichever position gives more patients", "measure": "   "})
    f = intake.precheck(bad, [P])
    assert any("time_window" in x for x in f), f
    assert any("baseline_lookback" in x and "before index" in x for x in f), f
    assert any("exclusions" in x and "outcome" in x for x in f), f
    assert any("code_position" in x and "whichever" in x.lower() for x in f), f
    assert any("measure is required and empty" in x for x in f), "whitespace is empty"
    assert not intake._filled("   ")
    # a contract variable may stand in for codes, as the prompt offers
    var = copy.deepcopy(st)
    var["request"]["index_codes"] = "ecog"
    f = intake.precheck(var, [P], known_variables={"ECOG", "TSST"})
    assert not any("index_codes" in x for x in f), f
    f = intake.precheck(var, [P], known_variables={"TSST"})
    assert any("index_codes" in x for x in f), "an unknown word is neither a code nor a variable"


def test_unknown_requirements_are_preserved_and_labelled_not_dropped():
    import intake  # noqa: PLC0415

    class M:
        usage = {"calls": 0}

        def step(self, system, transcript):
            return json.dumps({"request": {"population": "mCRPC", "exposure": "abiraterone", "comparator": "enzalutamide",
                                           "estimand": "hazard ratio", "outcome": "OS"}, "ask": "?"})
    st = intake.new_state("feasibility", P, "alex")
    st, reply = intake.next_turn(st, "compare abi vs enza on OS", M())
    assert st["request"]["population"] == "mCRPC"
    assert st["extra"] == {"exposure": "abiraterone", "comparator": "enzalutamide", "estimand": "hazard ratio", "outcome": "OS"}
    y = intake.to_yaml(st)
    assert "unsupported_requirements" in y and "estimand" in y
    g = intake.to_goal(st)
    assert "not supported by this request kind" in g and "comparator" in g


def test_a_product_brief_domain_exists_with_the_fields_an_epidemiologist_needs():
    import intake  # noqa: PLC0415
    d = intake.domains()
    assert "product_brief" in d
    ids = {s["id"] for s in d["product_brief"]["slots"]}
    for k in ("intended_use", "consumers", "population", "index_definition", "inclusion_sequence", "exclusions",
              "baseline_lookback", "follow_up", "outcomes", "variables_domains", "source_cut", "output_grain",
              "refresh_cadence", "acceptance_criteria", "deliverables", "requested_by"):
        assert k in ids, k
    assert {"exposure", "comparator"} <= ids
    opt = {s["id"] for s in d["product_brief"]["slots"] if not s.get("required", True)}
    assert {"exposure", "comparator"} <= opt, "comparative fields are optional until the use is comparative"
    assert any("comparative" in str(s.get("note", "")).lower() or "comparative" in str(s.get("ask", "")).lower()
               for s in d["product_brief"]["slots"]), "the brief says what is and is not supported downstream"


# ------------------------------------------------------------------ P1 portal

def test_the_portal_discovers_packs_from_the_registries_and_separates_products_from_references():
    import portal_packs as pp  # noqa: PLC0415
    cat = pp.catalogue(str(ROOT))
    # the SEPARATION is what is under test, not today's emptiness (second pass of the eleventh
    # verdict: pinning `products == []` turns this red the day the first real product is registered)
    assert all(p.startswith("products/") for p in cat["products"]) and \
        not any(p in cat["references"] for p in cat["products"])
    refs = cat["references"]
    assert P in refs and OC in refs
    assert not any("YYYYMM" in r for r in refs), "templates never appear in a working selector"
    assert "fixtures/oncology/prostate/202603" not in refs, "a superseded version is not offered"
    assert "fixtures/oncology/prostate/202603" in cat["superseded"]
    assert all("YYYYMM" in t for t in cat["templates"])
    assert pp.badge(P, cat) == pp.REFERENCE_BADGE and "NEVER RELEASABLE" in pp.REFERENCE_BADGE
    app = _read("experiments/portal/app.py")
    assert 'PACKS = ["fixtures/oncology/prostate/202606"' not in app, "no hard-coded pack list"
    for needle in ("portal_packs.catalogue(", "Reference library"):
        assert needle in app, needle
    headers = [n for n in ast.walk(ast.parse(app)) if isinstance(n, ast.Call)
               and ast.unparse(n.func) == "theme.product_header"]
    assert len(headers) == 1
    assert ast.unparse(headers[0].args[0]) == "portal_packs.label(pack, _CAT)"
    header_args = {k.arg: ast.unparse(k.value) for k in headers[0].keywords}
    assert header_args["badge"] == "BADGE"
    assert header_args["actor"] == "ACTOR['name']" and header_args["role"] == "ACTOR['role']"
    import ui_text as ui  # noqa: PLC0415
    assert "ui.NO_PRODUCTS_YET" in app
    assert "no products" in ui.NO_PRODUCTS_YET.lower()
    assert "start" in ui.NO_PRODUCTS_YET.lower() and "reference examples" in ui.NO_PRODUCTS_YET.lower()
    import theme  # noqa: PLC0415
    html = theme.product_header("fixtures/x/202606", [], actor="Quinn Avery", role="reviewer", badge=pp.REFERENCE_BADGE)
    assert "REFERENCE FIXTURE" in html and 'class="badge' in html
    assert "Quinn Avery" in html and "reviewer" in html and "fixtures/x/202606" in html
    assert "DEMO" in theme.watermark()


def test_the_lifecycle_is_one_stepper_computed_from_evidence():
    import queues  # noqa: PLC0415
    import theme  # noqa: PLC0415
    steps = queues.lifecycle({"gates": [{"gate": 1, "status": "fail"}], "kind": "fixture"}, open_questions=24,
                             has_source_evidence=False, records=202, kept_requests=1)
    names = [s["name"] for s in steps]
    assert names == ["Brief", "Specification", "Decisions", "Source fitness", "Configuration", "Candidate", "QC", "Release"]
    by = {s["name"]: s["state"] for s in steps}
    assert by["Brief"] == "done" and by["Specification"] == "done" and by["Decisions"] == "open"
    assert by["Source fitness"] == "blocked" and by["Release"] == "not started"
    html = theme.stepper(steps)
    assert html.count('class="step') >= 8 and "Release" in html
    # the page's one progress surface is the stage model's header and cards (2026-09-07); the
    # evidence-computed lifecycle above stays a pure function the saved status report can render
    app = _read("experiments/portal/app.py")
    assert 'theme.product_header(' in app and 'stage_model.from_flow(' in app and 'theme.stepper(' not in app


# ------------------------------------------------------------------ P2 presentation

def test_search_hits_carry_pack_state_and_detail_everywhere():
    import mcp_server as srv  # noqa: PLC0415
    out = srv.t_search({"query": "ECOG"})
    assert P in out, "the MCP renderer names the pack"
    src = _read("platform/tools/mcp_server.py")
    assert "h.get('text')" not in src and "h.get('snippet')" not in src, "fields the hits do not carry"
    assert "h.get('state')" in src or 'h.get("state")' in src


def test_the_top_question_renders_as_a_plain_card():
    import queues  # noqa: PLC0415
    card = queues.question_card({"id": "D-1", "unblocks": 3, "owner_display": "Science", "owner": "RWB",
                                 "question": "Should ECOG use the last value before index?<br>Options: a, b"},
                                packet_text="EVIDENCE\n- outcomes.md row 4\n- protocol 2.1\nFORM handoff/decision_answers/D-1.yaml")
    assert "<br>" not in card["question"] and card["unblocks"] == 3 and card["owner"] == "Science"
    assert card["evidence_count"] >= 2 and card["form"].endswith("D-1.yaml")
    assert set(card["actions"]) == {"answer", "defer", "needs evidence"}
    app = _read("experiments/portal/app.py")
    assert "queues.question_card(" in app


def test_the_demo_prebuilds_the_snapshot_and_the_live_button_says_what_it_costs():
    app = _read("experiments/portal/app.py")
    assert "(~45s)" not in app
    demo = _read("DEMO.md")
    assert "snapshot" in demo.lower() and "before" in demo.lower()
    pilot = _read("docs/PILOT.md")
    assert "approved dimension" in pilot.lower() or "approved categorical" in pilot.lower()


# ------------------------------------------------------------------ the independent review of this branch

def test_a_filter_never_selects_a_person_and_never_echoes_a_value():
    import quick_counts as qc  # noqa: PLC0415
    with tempfile.TemporaryDirectory() as d:
        log = os.path.join(d, "log")
        rows = [("PATIENT-0001", "C2", "1", "ABC")] * 12 + [(f"P{i:04d}", "C2", str(i % 3), "ABC") for i in range(40)]
        path = _frame(d, rows, ["patientid", "cohort", "ecog", "site"])
        rc, err, out = _run([P, "--frame", path, "--by", "ecog", "--where", "patientid=PATIENT-0001", "--cut", "2023Q4",
                             "--grain", "event", "--log-dir", log, "--assume", 'patientid="the vendor key"', "--asked-by", "A Person"])
        assert rc is None and "identifier" in err.lower(), err
        assert "PATIENT-0001" not in out and "PATIENT-0001" not in err
        # a filter on an assumed column (not a variable of the pack) withholds its value everywhere,
        # including the assumption ledger; a filter on an approved dimension states it
        rc, err, out = _run([P, "--frame", path, "--by", "ecog", "--where", "site=ABC", "--cut", "2023Q4",
                             "--grain", "event", "--log-dir", log, "--assume", 'site="the treating site code"',
                             "--asked-by", "A Person"])
        assert rc == 0, err
        res = json.loads(out)
        assert res["identity"]["filters"] == ["site=<value withheld>"] and "ABC" not in json.dumps(res["asked"])
        ledger = open(os.path.join(log, qc.LEDGER), encoding="utf-8").read()
        assert "ABC" not in ledger and "PATIENT-0001" not in ledger
        rc, err, out = _run([P, "--frame", path, "--by", "ecog", "--where", "ecog!=2", "--cut", "2023Q4",
                             "--grain", "event", "--log-dir", log])
        assert rc == 0 and json.loads(out)["identity"]["filters"] == ["ecog!=2"], err
        assert qc.filter_column_ok("index_date")[0] is False and qc.filter_column_ok("free_text_note")[0] is False


def test_the_small_cell_floor_counts_people_at_event_grain():
    with tempfile.TemporaryDirectory() as d:
        log = os.path.join(d, "log")
        rows = [("PATIENT-0001", "C2", "1")] * 12
        path = _frame(d, rows, ["patientid", "cohort", "ecog"])
        rc, err, out = _run([P, "--frame", path, "--by", "ecog", "--cut", "2023Q4", "--grain", "event", "--log-dir", log])
        assert rc == 0, err
        res = json.loads(out)
        assert res["counts"]["total"] == "<11" and res["counts"]["by"]["groups"] == {}, res["counts"]
        assert res["identity"]["distinct_patients"] == "<11"
        # twelve people, one row each: shown
        rows = [(f"P{i:04d}", "C2", "1") for i in range(12)]
        path2 = _frame(d, rows, ["patientid", "cohort", "ecog"])
        rc, err, out = _run([P, "--frame", path2, "--by", "ecog", "--cut", "2023Q4", "--grain", "event", "--log-dir", log])
        assert rc == 0 and json.loads(out)["counts"]["by"]["groups"] == {"1": 10}, err     # 12 people, rounded to 10s


def test_a_column_absent_from_the_frame_is_refused_not_counted_as_empty():
    with tempfile.TemporaryDirectory() as d:
        log = os.path.join(d, "log")
        rows = [(f"P{i:04d}", "C2") for i in range(20)]
        path = _frame(d, rows, ["patientid", "cohort"])
        rc, err, _ = _run([P, "--frame", path, "--by", "ecog", "--cut", "2023Q4", "--grain", "patient", "--log-dir", log])
        assert rc is None and "not in the frame" in err and "ecog" in err, err


def test_the_briefs_comparative_fields_are_labelled_unsupported():
    import intake  # noqa: PLC0415
    st = intake.new_state("product_brief", P, "alex")
    st["request"].update({"population": "mCRPC", "exposure": "abiraterone", "comparator": "enzalutamide"})
    u = intake.unsupported_requirements(st)
    assert set(u) == {"exposure", "comparator"}
    g = intake.to_goal(st)
    assert "not supported" in g and "exposure" in g and "do NOT verify them" in g
    assert "exposure" in intake.to_yaml(st).split("unsupported_requirements")[1]


def test_products_are_filtered_for_templates_and_superseded_versions_too():
    import portal_packs as pp  # noqa: PLC0415
    src = _read("experiments/portal/portal_packs.py")
    assert "for p in products_all + fixtures" in src
    cat = pp.catalogue(str(ROOT))
    assert cat["products"] == [] and P in cat["references"]


# ------------------------------------------------------------------ the tenth verdict

def test_shown_counts_are_rounded_so_differencing_recovers_nothing_and_synthetic_needs_a_frame():
    import quick_counts as qc  # noqa: PLC0415
    with tempfile.TemporaryDirectory() as d:
        log = os.path.join(d, "log")
        rows = [(f"P{i:04d}", "C2", "1") for i in range(12)]
        path = _frame(d, rows, ["patientid", "cohort", "ecog"])
        rc, _, out = _run([P, "--frame", path, "--by", "ecog", "--cut", "2023Q4", "--grain", "patient", "--log-dir", log])
        whole = json.loads(out)["counts"]
        rows2 = rows[:11]
        path2 = _frame(d, rows2, ["patientid", "cohort", "ecog"])
        rc, _, out = _run([P, "--frame", path2, "--by", "ecog", "--cut", "2023Q4", "--grain", "patient", "--log-dir", log])
        part = json.loads(out)["counts"]
        assert whole["total"] == part["total"] == 10, (whole, part)
        assert "rounded" in whole["rounding"]
        rc, err, _ = _run([P, "--synthetic", "-1", "--by", "ecog", "--log-dir", log])
        assert rc is None and "at least" in err, err
        rc, err, out = _run([P, "--synthetic", "30", "--by", "ecog", "--asked-by", "A Person", "--log-dir", log])
        assert rc == 0, err
        ident = json.loads(out)["identity"]
        assert ident["pack_role"] == "fixture" and ident["asked_by"] == "A Person"


def test_intake_takes_a_code_list_and_rechecks_every_value_for_individuals():
    import intake  # noqa: PLC0415
    st = intake.new_state("feasibility", P, "alex")
    st["request"].update({"source": "Optum", "population": "mCRPC", "index_codes": ["C61", "C79.51"],
                          "time_window": "2024", "baseline_lookback": "12 months", "exclusions": "none",
                          "code_position": "any position", "measure": "patients", "requested_by": "alex"})
    assert not any("index_codes" in x for x in intake.precheck(st, [P]))
    bad = copy.deepcopy(st)
    bad["request"]["exclusions"] = "exclude MRN 00012345 and patient id 998877"
    f = intake.precheck(bad, [P])
    assert any("exclusions" in x and "individual" in x for x in f), f
    past = dict(bad); past["status"] = "checked"; past["kind"] = "feasibility"; past["pack"] = P
    try:
        intake.prefill(intake.new_state("feasibility", P, "x"), past)
        raise AssertionError("a past value with an identifier was copied")
    except ValueError as e:
        assert "individual" in str(e)
    assert intake.domains()["feasibility"]["title"].startswith("Basic feasibility")


def test_pack_versions_report_their_own_status_and_templates_and_a_refusal_is_an_observation():
    import tools  # noqa: PLC0415
    out = tools.call("packs", {"query": "prostate"})
    assert "fixtures/oncology/prostate/202603" in out and "status superseded" in out, out
    assert "status active, current" in out
    out = tools.call("packs", {"query": "YYYYMM"})
    assert "role template" in out
    saved = tools.EXTRA_TOOLS["packs"]

    def boom(a):
        raise SystemExit("REFUSED — not a pack")
    tools.EXTRA_TOOLS["packs"] = (boom, saved[1], saved[2])
    try:
        out = tools.call("packs", {})
    finally:
        tools.EXTRA_TOOLS["packs"] = saved
    assert out.startswith("tool packs refused:")
    src = _read("experiments/agent/tools.py")
    assert 'ContextVar("rwdp_snapshot"' in src and "_SNAP.get()" in src
    assert "copy_context()" in _read("experiments/agent/jobs.py")


def test_owners_come_from_the_register_when_the_page_has_none():
    import queues  # noqa: PLC0415
    md = ("| ID | Question | Owner | Status |\n|---|---|---|---|\n| `MAXINDEX` | what is the end? | RWB | OPEN |\n"
          "| STUDY-WINDOW | what is MININDEX? | Science/DataExpert | OPEN |\n")
    ranked = [{"id": "MAXINDEX", "owner": "?", "owner_display": "?", "unblocks": 0, "rank": 1},
              {"id": "STUDY-WINDOW", "owner": "?", "owner_display": "?", "unblocks": 0, "rank": 2},
              {"id": "OTHER", "owner": "Science", "owner_display": "Science", "unblocks": 1, "rank": 3}]
    out = queues.fill_owners(ranked, md)
    assert out[0]["owner"] == "RWB" and out[0]["owner_display"] == "Science"
    assert out[1]["owner_display"] == "Science/DataExpert" and out[2]["owner"] == "Science"
    app = _read("experiments/portal/app.py")
    assert "queues.fill_owners(" in app and "ui.TREATED_NOTE" in app
    assert '"treated" in _defn.lower()' in app, "the note follows the definition text, not a guessed variable name"
    tree = ast.parse(app)
    fallback = next(n for n in tree.body if isinstance(n, ast.If) and ast.unparse(n.test) == "not snap")
    status = next(n for n in tree.body if isinstance(n, ast.If) and ast.unparse(n.test) == "section == 'Status'")
    assert fallback.end_lineno < status.lineno, "snapshot fallback is installed before section-specific rendering"
    # Exercise the page's actual fallback block without starting the whole app:
    # preserve its explicit stale label, clear absent evidence, and leave a
    # current snapshot alone. A former local variable spelling is not behavior.
    code = compile(ast.Module(body=[fallback], type_ignores=[]), "app snapshot fallback", "exec")
    older = {"provenance": {"commit": "123456789"}, "packs": {}}
    for current, saved, expected in (
        (None, older, [(older, "1234567 STALE snapshot, verify in Run gates")]),
        (None, None, [(None, "")]),
        ({"packs": {}}, older, []),
    ):
        calls = []
        namespace = {"snap": current, "_snapshot_fallback": saved,
                     "tools": SimpleNamespace(use_snapshot=lambda value, label="": calls.append((value, label)))}
        exec(code, namespace)
        assert calls == expected
    assert "treated versus untreated is a treatment comparison" in _read("DEMO.md")


# ------------------------------------------------------------------ the second independent review

def test_grain_keys_and_date_suffixes_are_refused_and_nothing_exact_or_raw_leaks():
    import quick_counts as qc  # noqa: PLC0415
    for col in ("ptid", "patid", "pid", "enrolid", "subjid", "personid", "acctno", "recnum", "guid", "encounterid",
                "claimid", "visitid", "siteid", "taxid", "hicn", "beneid", "provid", "rowkey"):
        assert not qc.filter_column_ok(col)[0], col
        assert not qc.approved_dimension(P, col)[0], col
    for col in ("deathdt", "indexdd", "dxyr", "dt_index", "lab_dtm"):
        assert not qc.filter_column_ok(col)[0], col
    assert qc.filter_column_ok("cohort")[0] and qc.filter_column_ok("ecog")[0]
    for col in ("opioid", "thyroid", "comorbid", "valid", "lipid"):
        assert qc.filter_column_ok(col)[0], col
    assert qc.ROUND_TO == 10 and qc._rounded(12) == 10 and qc._rounded(17) == 20 and qc._floored(3) == "<11"
    ok, why, _ = qc.grain_check([{"p": "a"}, {"p": "a"}], "patient", "p")
    assert not ok and not any(ch.isdigit() for ch in why), why
    with tempfile.TemporaryDirectory() as d:
        log = os.path.join(d, "log")
        rc, err, out = _run([P, "--synthetic", "30", "--by", "ecog", "--where", "ecog PATIENT-0001", "--log-dir", log])
        assert rc is None and "PATIENT-0001" not in err and "PATIENT-0001" not in out
        rows = [(f"P{i:04d}", "C2", "1") for i in range(12)]
        path = _frame(d, rows, ["patientid", "cohort", "ecog"])
        rc, err, out = _run([P, "--frame", path, "--by", "ecog", "--where", "cohort=PT00001234", "--cut", "2023Q4",
                             "--grain", "patient", "--log-dir", log])
        assert rc == 0, err
        res = json.loads(out)
        assert res["identity"]["filters"] == ["cohort=<value withheld>"], "a digit run is not a category label"
        assert res["identity"]["frame_rows"] == 10 and res["identity"]["distinct_patients"] == 10


def test_intake_reads_dates_only_and_lets_legitimate_designs_through():
    import intake  # noqa: PLC0415
    assert intake.date_tokens("2023-2024") == (["2023", "2024"], [])
    assert intake.date_tokens("calendar year 2023 to 2024-06-30")[0] == ["2023", "2024-06-30"]
    assert intake.date_tokens("13/2024")[1] == ["13/2024"]
    st = intake.new_state("feasibility", P, "alex")
    st["request"].update({"source": "Optum", "population": "mCRPC", "index_codes": "C61", "time_window": "2023-2024",
                          "baseline_lookback": "12 months before index and 6 months after", "exclusions": "patients who died during baseline",
                          "code_position": "any position; whichever is earlier breaks ties", "measure": "patients", "requested_by": "alex"})
    f = intake.precheck(st, [P])
    assert f == [], f
    bad = copy.deepcopy(st)
    bad["request"].update({"exclusions": "exclude patients who died after index", "code_position": "whichever gives more patients",
                           "time_window": "calendar 13/2024"})
    f = intake.precheck(bad, [P])
    assert any("exclusions" in x for x in f) and any("code_position" in x for x in f) and any("13/2024" in x for x in f), f
    assert not intake.classify_ingress("the patient number is unknown; subject id fields are dropped before delivery")
    assert intake.classify_ingress("patient id 445566")


def test_a_roster_assignment_the_picker_no_longer_offers_does_not_kill_the_page():
    import portal_packs as pp  # noqa: PLC0415
    keep, gone = pp.assigned_defaults(["fixtures/oncology/prostate/202603", "fixtures/oncology/prostate/202606"],
                                      ["fixtures/oncology/prostate/202606", "fixtures/oncology/oc/202606"])
    assert keep == ["fixtures/oncology/prostate/202606"] and gone == ["fixtures/oncology/prostate/202603"]
    assert pp.assigned_defaults([], ["x"]) == ([], []) and pp.assigned_defaults(None, None) == ([], [])
    app = _read("experiments/portal/app.py")
    assert "portal_packs.assigned_defaults(_assigned, PACKS)" in app and 'default=_keep, key=f"edit_packs_{eu}"' in app
    assert "ui.packs_no_longer_offered(_gone)" in app


def test_the_page_renders_for_an_admin_whose_roster_names_a_superseded_pack():
    """The whole page, driven headlessly as the admin: the Manage users panel must render (it raised
    a StreamlitAPIException on a default outside the picker's options, 2026-09-04). Skips cleanly
    where Streamlit is not installed (the CI test job installs the platform pins only)."""
    try:
        from streamlit.testing.v1 import AppTest  # noqa: PLC0415
    except ImportError:
        print("  skip: streamlit is not installed here")
        return
    os.environ.setdefault("RWD_PORTAL_LOCAL_DEMO", "1")
    at = AppTest.from_file(str(ROOT / "experiments" / "portal" / "app.py"), default_timeout=600)
    at.run()
    assert not at.exception, [str(e.value)[:200] for e in at.exception]
    who = [w for w in at.sidebar.selectbox if w.key == "who"]
    if not who or "admin" not in who[0].options:
        print("  skip: no demo roster with an admin")
        return
    who[0].set_value("admin")
    at.run()
    assert not at.exception, [str(e.value)[:200] for e in at.exception]
    # the admin panel sits behind the sidebar's "more sections" switch since 2026-09-06
    more = [t for t in at.sidebar.toggle if t.key == "more_sections"]
    if more and not more[0].value:
        more[0].set_value(True)
        at.run()
        assert not at.exception, [str(e.value)[:200] for e in at.exception]
    ms = [m for m in at.sidebar.multiselect if str(m.key).startswith("edit_packs_")]
    assert ms and all(v in ms[0].options for v in ms[0].value), (ms[0].value, ms[0].options)


def test_the_snapshots_shapes_render_as_a_count_and_a_sentence():
    import queues  # noqa: PLC0415
    entry = {"records": {"records": 202, "requirement": {"approved": 0}}, "kind": "fixture",
             "next_action": [1, "Science (supplies the approved specification)", "Gate 1: source is provisional, not approved"]}
    assert queues.record_count(entry) == 202 and queues.record_count({"records": 7}) == 7 and queues.record_count(None) == 0
    assert queues.next_action_text(entry["next_action"]) ==         "Gate 1: source is provisional, not approved. Owner: Science (supplies the approved specification)."
    assert queues.next_action_text({"action": "answer D-1", "owner": "Science"}) == "answer D-1. Science."
    assert queues.next_action_text("plain") == "plain"
    steps = {s["name"]: s["state"] for s in queues.lifecycle(entry, open_questions=24, has_source_evidence=False,
                                                              records=queues.record_count(entry), kept_requests=0)}
    assert steps["Specification"] == "done"
    app = _read("experiments/portal/app.py")
    assert "queues.record_count(_entry)" in app and "queues.next_action_text(na)" in app


if __name__ == "__main__":
    fails = 0
    for name, fn in sorted(globals().items()):
        if name.startswith("test_") and callable(fn):
            try:
                fn()
                print(f"  ok   {name}")
            except Exception as e:  # noqa: BLE001
                fails += 1
                print(f"  FAIL {name}: {type(e).__name__}: {str(e)[:300]}")
    print(f"{fails} failure(s)")
    sys.exit(1 if fails else 0)
