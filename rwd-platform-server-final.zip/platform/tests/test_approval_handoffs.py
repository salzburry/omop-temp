"""The three-checkpoint inventory is read-only preparation, never an approval."""
from pathlib import Path
import sys
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parent))
from _epi_test_support import api, run
pytest = api(__name__)
import yaml

ROOT = Path(__file__).resolve().parents[2]
sys.path[:0] = [str(ROOT / "platform/tools"), str(ROOT / "experiments/portal")]
import approval_handoffs as handoffs
import flow
import source_manifest as sm

PACK = "products/oncology/example/202609"


def seed(root):
    product = root / PACK
    (product / "prog_spec").mkdir(parents=True)
    (product / "config").mkdir()
    (product / "handoff").mkdir()
    workbook = product / "prog_spec/source.tsv"
    workbook.write_text("variable\tdefinition\nOS\tOverall survival\n", encoding="utf-8")
    material = {"material_id": "program_spec", "material_type": "program_spec", "status": "pending",
                "path_or_link": "prog_spec/source.tsv", "sha256": sm.sha256(str(workbook)),
                "ai_classification": "sponsor_ai_eligible", "classified_by": "Alice Smith", "classified_date": "2026-09-06"}
    (product / "source_refs.yaml").write_text(yaml.safe_dump({"source_materials": [material]}), encoding="utf-8")
    return product, workbook


def bytes_in(root):
    return {p.relative_to(root).as_posix(): p.read_bytes() for p in root.rglob("*") if p.is_file()}


def test_missing_input_report_never_suggests_missing_or_placeholder_commands(tmp_path):
    product = tmp_path / PACK
    product.mkdir(parents=True)
    before = bytes_in(tmp_path)
    report = handoffs.manifest(tmp_path, PACK)
    assert report["read_only"] and not report["three_visit_acceptance_met"]
    assert len(report["checkpoints"]) == 3
    assert all(c["approval_state"] == "not_evaluated" for c in report["checkpoints"])
    assert all(not c["commands"] for c in report["checkpoints"])
    assert all(c["preparation_state"] == "incomplete" for c in report["checkpoints"])
    assert before == bytes_in(tmp_path)
    assert "actions, not measured visits" in handoffs.render(report)


def test_current_pack_manifest_counts_exact_catalogue_and_does_not_write(tmp_path):
    seed(tmp_path)
    before = bytes_in(tmp_path)
    report = handoffs.manifest(tmp_path, PACK)
    actions = flow.acts(PACK, str(tmp_path))
    assert report["current_person_action_count"] == sum(a["kind"] == flow.PERSON for menu in actions.values() for a in menu)
    assert report["current_person_actions_by_gate"] == {str(g): sum(a["kind"] == flow.PERSON for a in menu) for g, menu in actions.items()}
    assert before == bytes_in(tmp_path)
    source = report["checkpoints"][0]
    assert any(f["path"] == f"{PACK}/prog_spec/source.tsv" and f["exists"] for f in source["files"])
    assert any(p["code"] == "review_fields" for p in source["prerequisites"])


def test_source_revision_and_review_record_changes_reopen_only_affected_inputs(tmp_path):
    product, workbook = seed(tmp_path)
    before = handoffs.manifest(tmp_path, PACK)
    unchanged = handoffs.manifest(tmp_path, PACK, previous=before)
    assert not any(c["changed_since_previous"] for c in unchanged["checkpoints"])
    workbook.write_text("new revision", encoding="utf-8")
    after = handoffs.manifest(tmp_path, PACK, previous=before)
    assert after["checkpoints"][0]["changed_since_previous"]
    assert any(p["code"] == "source_changed" for p in after["checkpoints"][0]["prerequisites"])
    (product / "handoff/CONTRACT_APPROVAL.yaml").write_text("approved_by: Alice Smith\n", encoding="utf-8")
    review_changed = handoffs.manifest(tmp_path, PACK, previous=after)
    assert review_changed["checkpoints"][1]["changed_since_previous"]
    assert not review_changed["checkpoints"][2]["changed_since_previous"]


@pytest.mark.parametrize("previous", [None, [], {"pack": PACK, "checkpoints": 4}, {"pack": PACK, "checkpoints": [None, "bad"]}, {"pack": "another", "checkpoints": []}])
def test_malformed_previous_state_cannot_supply_approval_or_crash(tmp_path, previous):
    seed(tmp_path)
    report = handoffs.manifest(tmp_path, PACK, previous=previous)
    assert report["three_visit_acceptance_met"] is False
    assert not any(c["changed_since_previous"] for c in report["checkpoints"])


def test_malformed_source_union_is_a_prerequisite_not_an_exception(tmp_path):
    product, _ = seed(tmp_path)
    (product / "config/data_product.yaml").write_text("source_union: {members: 42}\n", encoding="utf-8")
    report = handoffs.manifest(tmp_path, PACK)
    assert any(p["code"] == "source_configuration" for p in report["checkpoints"][1]["prerequisites"])


def test_concrete_ready_command_requires_existing_tool_and_guard(tmp_path):
    seed(tmp_path)
    tool = tmp_path / "platform/tools/source_manifest.py"
    tool.parent.mkdir(parents=True)
    tool.write_text("# Existing tool fixture\n", encoding="utf-8")
    action = {"id": "g1_check", "label": "Check", "kind": flow.READ,
              "argv": ["platform/tools/source_manifest.py", PACK, "--check"], "path": "", "note": ""}
    menus = {gate: [action] if gate == 1 else [] for gate in range(1, 7)}
    with patch.object(flow, "acts", return_value=menus), patch.object(handoffs.guidance, "action_guard", return_value=""):
        report = handoffs.manifest(tmp_path, PACK)
    assert report["checkpoints"][0]["commands"][0]["argv"] == action["argv"]
    with patch.object(flow, "acts", return_value=menus), patch.object(handoffs.guidance, "action_guard", return_value="Missing prerequisite"):
        assert not handoffs.manifest(tmp_path, PACK)["checkpoints"][0]["commands"]


def test_outside_or_missing_pack_rejected(tmp_path):
    with pytest.raises(ValueError):
        handoffs.manifest(tmp_path, "../outside")
    with pytest.raises(ValueError):
        handoffs.manifest(tmp_path, PACK)


if __name__ == "__main__":
    raise SystemExit(run(globals()))
