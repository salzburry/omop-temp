"""Cross-tumor consistency: the master catalog is well-formed, its tumor codes match the registry,
and every dashboard variable resolves to a catalog code. Pure Python (no Spark).
Run: python3 test_catalog.py (or pytest).
"""
import sys
from pathlib import Path

FRAMEWORK = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(FRAMEWORK))
PRODUCTS = FRAMEWORK.parent / "products"

from engine.config import load_yaml   # noqa: E402
from engine.config import product_config, product_dir  # noqa: E402

CATALOG = PRODUCTS / "metadata" / "catalog.yaml"
REGISTRY = PRODUCTS / "registry.yaml"
DASHBOARD = PRODUCTS / "_reporting" / "dashboard" / "dashboard_vars.yaml"


def _catalog():
    return load_yaml(CATALOG)


def _registered_codes():
    codes = {t["code"] for t in load_yaml(REGISTRY)["tumors"]}
    fx = REGISTRY.parent.parent / "fixtures" / "registry.yaml"
    if fx.exists():
        codes |= {t["code"] for t in (load_yaml(fx).get("tumors") or [])}
    return codes


def _declared_codes(cat, field):
    values = cat.get(field, [])
    assert isinstance(values, list), f"catalog {field} must be a list"
    assert all(isinstance(code, str) and code.strip() == code and code for code in values), \
        f"catalog {field} must contain non-empty code strings"
    assert len(values) == len(set(values)), f"duplicate catalog {field} code"
    return set(values)


def test_catalog_well_formed():
    cat = _catalog()
    assert "tumor_codes" in cat, "catalog must declare tumor_codes, including [] for an empty installation"
    _declared_codes(cat, "tumor_codes")
    _declared_codes(cat, "reference_tumor_codes")
    codes = set()
    for v in cat["variables"]:
        for k in ("code", "category", "label", "applies_to"):
            assert k in v, f"catalog variable missing '{k}': {v}"
        assert v["code"] not in codes, f"duplicate catalog code: {v['code']}"
        codes.add(v["code"])


def test_applies_to_codes_are_registered():
    # BOTH registries: the catalog is platform knowledge and its codes stay registered when a
    # pack crosses the products/fixtures boundary.
    reg = _registered_codes()
    cat = _catalog()
    installed = _declared_codes(cat, "tumor_codes")
    assert installed <= reg, \
        f"catalog tumor_codes not in registry: {installed - reg}"
    # ...and the mirror holds BOTH ways — the file says "mirror ../registry.yaml" and nothing
    # enforced it, so a new tumour registered but absent here had every `applies_to: [<code>]`
    # refused as unknown, three CI failures away from the registry line that caused it.
    assert reg <= installed, \
        f"registry tumors missing from catalog tumor_codes: {reg - installed}"
    # A clean installation retains master scientific vocabulary without installing its example
    # products. Declare that vocabulary separately; it never counts as an installed product and
    # cannot satisfy either side of the strict registry mirror above.
    known = reg | _declared_codes(cat, "reference_tumor_codes")
    for v in cat["variables"]:
        a = v["applies_to"]
        if a == "all":
            continue
        assert isinstance(a, list) and a, f"variable '{v['code']}' applies_to must be 'all' or a non-empty list"
        bad = set(a) - known
        assert not bad, f"variable '{v['code']}' applies_to unknown tumor(s): {bad}"


def test_dashboard_variables_resolve_to_catalog():
    catalog_codes = {v["code"] for v in _catalog()["variables"]}
    dash = load_yaml(DASHBOARD)
    for panel in dash["panels"]:
        for var in panel["variables"]:
            assert var in catalog_codes, \
                f"dashboard panel '{panel['id']}' references unknown variable '{var}'"


def test_catalog_documents_every_emitted_variable():
    # Every config-driven variable a tumor emits must be in the master catalog, so the data dictionary
    # is complete. Guards against adding a categorical/panel/passthrough/outcome without cataloging it.
    from engine.config import load_config
    from engine.validate import emitted_variables
    from engine.dictionary import _applies
    cat = _catalog()["variables"]

    def _expand_line_template(code, maxl, maint):
        # A `lotN<suffix>` row documents EXACTLY its own per-line columns: lot{i}<suffix> per line (+ the
        # lot{i}m<suffix> maintenance variant), matching treatment.line_cols. Expanding per-suffix (not a
        # blanket "any template -> all line columns") means a NEW per-line field added to line_cols without
        # its own lotN<suffix> catalog row stays UNCATALOGED -> CI fails. (suffix: lotN->'', lotNsd->'sd'.)
        suffix = code[len("lotN"):]
        cols = set()
        for i in range(1, maxl + 1):
            cols.add(f"lot{i}{suffix}")
            if maint:
                cols.add(f"lot{i}m{suffix}")
        return cols

    # REGISTRY-DRIVEN: every tumor that has a current_spec_version AND a pack folder on disk — so a NEW
    # tumor (GIST, MDS, NSCLC …) is covered automatically the moment it gets a real pack, with no edit
    # to this test. For each, check EVERY on-disk spec version (current + superseded + scaffold), so a
    # superseded-but-buildable contract (e.g. prostate 202603) can't drift uncataloged either.
    _fx = REGISTRY.parent.parent / "fixtures" / "registry.yaml"
    _tumors = [dict(t, _root="products") for t in load_yaml(REGISTRY)["tumors"]] + ([dict(t, _root="fixtures") for t in (load_yaml(_fx).get("tumors") or [])] if _fx.exists() else [])
    for t in _tumors:
        slug, tcode = t.get("slug"), t.get("code")
        if not (slug and tcode and t.get("current_spec_version")):
            continue                                               # planned tumor, no pack yet
        pack_root = product_dir(PRODUCTS.parent / t["_root"], slug).parent
        if not pack_root.exists():
            continue                                               # registered but no folder on disk yet
        for sv in sorted(d.name for d in pack_root.iterdir()
                         if (d / "config" / "data_product.yaml").exists()):
            cfg = load_config(product_config(PRODUCTS.parent / t["_root"], slug, spec_version=sv))
            try:
                maxl = int((cfg.pack("treatment") or {}).get("max_lines", 0))
            except Exception:                                      # noqa: BLE001 - tumor without a treatment pack
                maxl = 0
            maint = any(c.get("maintenance") is not None for c in cfg.cohorts)
            cataloged = set()
            for v in cat:
                if not _applies(v, tcode):
                    continue
                if v.get("line_template"):
                    cataloged |= _expand_line_template(v["code"], maxl, maint)
                else:
                    cataloged.add(v["code"])
            missing = emitted_variables(cfg) - cataloged
            assert not missing, f"{slug}/{sv}: emitted but uncataloged for '{tcode}': {sorted(missing)}"
    # No fixture-count minimum: an empty installation is valid before its first product is
    # onboarded. Every installed, buildable version above still checks every emitted variable;
    # test_registry separately requires every active product to have its configuration.


def test_catalog_ledger_fields_well_formed():
    # Go-forward ledger (governance/VERSIONING.md): a variable MAY carry introduced_in / deprecated_in
    # ({code: "YYYYMM"}) + status. Absence = pre-ledger (NOT an error — the backfill rule). This test
    # only validates the FORM of ledger fields that ARE present, so a new tag can't be malformed.
    import re
    cat = _catalog()
    codes = _registered_codes() | _declared_codes(cat, "reference_tumor_codes")
    STATUS = {"implemented", "planned", "deprecated"}
    for v in cat["variables"]:
        for field in ("introduced_in", "deprecated_in"):
            if field in v:
                assert isinstance(v[field], dict) and v[field], f"{v['code']}.{field} must be a non-empty map"
                for code, ver in v[field].items():
                    assert code in codes, f"{v['code']}.{field}: unknown tumor code '{code}'"
                    assert re.match(r"^\d{6}$", str(ver)), f"{v['code']}.{field}[{code}]: '{ver}' not YYYYMM"
        if "status" in v:
            assert v["status"] in STATUS, f"{v['code']}.status '{v['status']}' not in {sorted(STATUS)}"
    # Ledger fields are optional by policy. The absence of an example's historical tag must not
    # block onboarding; any tag that is present still has to name declared vocabulary and a cut.


if __name__ == "__main__":
    fns = [v for k, v in sorted(globals().items()) if k.startswith("test_")]
    for fn in fns:
        fn()
        print(f"ok  {fn.__name__}")
    print(f"\n{len(fns)} tests passed")
