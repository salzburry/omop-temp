"""Cross-pack concept reuse may ask; it may never rule, and it may never cry wolf.

Two packs defining one name is the shape no single-pack check can see: each is internally
consistent, and only reading them together shows that `INDEXDT` means something different in
each. Surfacing that is the whole value — and the way to destroy it is a detector that fires on
wording differences that carry no meaning difference, because the finding everyone learns to
skim is worse than no finding.

So the properties pinned here are the calibration and the refusals: identical constants beat low
wording overlap, a genuinely different rule still flags, every output is phrased as a question,
an unapproved source record is labelled as one, and the tool writes nothing.

Run: python3 tests/test_concept_reuse.py (or pytest). Pure — no Spark.
"""
import json
import subprocess
import sys
import tempfile
from pathlib import Path

FRAMEWORK = Path(__file__).resolve().parent.parent
REPO = FRAMEWORK.parent
sys.path.insert(0, str(FRAMEWORK / "tools"))
sys.path.insert(0, str(FRAMEWORK / "engine"))

import concept_reuse as cr     # noqa: E402
import naming_registry as nr   # noqa: E402


def test_identical_constants_outrank_low_wording_overlap():
    """THE CALIBRATION, from the live tree. `DAYS_PER_MONTH` reads "months = days / 30.4375" in
    one pack and "constant 30.4375 (outcomes.yaml days_per_month)" in the other — 0.29 overlap,
    and one concept to any reader. Flagging it teaches people this surface cries wolf, and the
    next finding, a real divergence, gets skimmed."""
    ok, why = cr._agrees("months = days / 30.4375",
                         "constant 30.4375 (outcomes.yaml days_per_month)")
    assert ok and "identical constants" in why, why

    # ...and DIFFERENT constants are not evidence of agreement: two tumours legitimately carry
    # different windows, and a 90-day rule is not a 30-day rule however similar the prose
    ok, _why = cr._agrees("ECOG within 90 days before index",
                          "ECOG within 30 days before index")
    assert ok, "high wording overlap should still agree — the constants only break ties"
    ok, _why = cr._agrees("closest value in the 90 day window", "latest result before cutoff")
    assert not ok, "genuinely different rules with no shared constants must flag"

    # a bare number is not a constant worth trusting — single digits recur everywhere
    assert cr._constants("cohort 1 and 2") == set()
    assert cr._constants("divided by 30.4375 over 90 days") == {"30.4375", "90"}


def test_the_live_tree_divergence_is_found_and_the_agreement_is_not_flagged():
    """Measured on the committed packs: INDEXDT genuinely means different things in ovarian and
    prostate and must be asked about; DAYS_PER_MONTH agrees and must not be."""
    r = cr.report()
    shared = {s["variable_id"]: s for s in r["shared"]}
    assert "INDEXDT" in shared, sorted(shared)
    assert shared["INDEXDT"]["divergent"] is True
    assert len(shared["INDEXDT"]["packs"]) >= 2
    if "DAYS_PER_MONTH" in shared:
        assert shared["DAYS_PER_MONTH"]["divergent"] is False, \
            "the constants calibration regressed — this is the cry-wolf case"


def test_a_candidate_carries_the_source_status_and_an_unapproved_one_is_labelled():
    """Inheriting a draft is inheriting an open question. Nothing in this repository is approved
    yet, so every candidate today must be marked NOT settled — if one ever reports settled, it is
    because a person approved it, never because this tool decided."""
    r = cr.report("fixtures/oncology/oc/202606")
    assert r["inheritable"], "no cross-pack candidates found on the live tree"
    for item in r["inheritable"]:
        assert item["question"].endswith("register.") or "?" in item["question"]
        for c in item["candidates"]:
            assert c["status"], c
            assert c["settled"] is (c["status"] == "approved")
            if not c["settled"]:
                assert c["caveat"] and "not approved" in c["caveat"], c
            assert c["match"] in ("same name", "near-miss name")


def test_the_near_miss_grammar_is_the_registrys_own_not_a_second_copy():
    """Two spellings of "are these names close" is how the two come to disagree — the naming
    docket would raise a pair this tool ignores, or the reverse, and nobody could say which was
    right."""
    src = (FRAMEWORK / "tools" / "concept_reuse.py").read_text(encoding="utf-8")
    assert "nr._near(" in src, "the shared near-miss grammar is no longer being called"
    assert "def _near" not in src, "a second near-miss implementation appeared in this tool"
    assert nr._near("fu_enddt", "fu_enddt_preliminary"), "the shared grammar changed under us"


def test_every_output_is_a_question_and_carries_no_verdict():
    """A cross-pack finding rendered as a verdict would settle a clinical question by printing
    it. Identity is DataExpert/Science's ruling, recorded where rulings live."""
    whole = cr.report()
    body = json.dumps(whole) + cr.render(whole)
    for word in ("approved by", "verified", "confirmed as", "same concept.", "is a duplicate"):
        assert word not in body, f"{word!r} reads as a verdict"
    for s in whole["shared"]:
        assert "?" in s["question"], s
    # both views state the boundary in their own words, where a reader will meet it
    whole_text = cr.render(whole)
    assert "QUESTIONS for DataExpert/Science" in whole_text and "NAMING_RULINGS" in whole_text
    assert "never answers" in cr.render(cr.report("fixtures/oncology/oc/202606"))


def test_the_tool_writes_nothing_and_refuses_an_unknown_pack():
    import ast
    tree = ast.parse((FRAMEWORK / "tools" / "concept_reuse.py").read_text(encoding="utf-8"))
    for node in ast.walk(tree):
        if isinstance(node, ast.Call):
            name = getattr(node.func, "id", "") or getattr(node.func, "attr", "")
            assert name not in ("write_text", "writelines", "safe_dump", "dump", "mkdir",
                                "makedirs", "remove", "rename", "rmtree"), f"{name}() writes"

    try:
        cr.report("fixtures/oncology/nsclc/YYYYMM")
        raise AssertionError("a pack with no contract produced an inheritance report")
    except KeyError as e:
        assert "no contract records" in str(e)


def test_the_cli_runs_both_views_and_refuses_a_non_pack():
    tool = str(FRAMEWORK / "tools" / "concept_reuse.py")
    r = subprocess.run([sys.executable, tool, "--json"], cwd=str(REPO),
                       capture_output=True, encoding="utf-8")
    assert r.returncode == 0, r.stderr
    doc = json.loads(r.stdout)
    assert doc["packs"] and "shared" in doc

    r = subprocess.run([sys.executable, tool, "fixtures/oncology/oc/202606",
                        "--variable", "INDEXDT"], cwd=str(REPO),
                       capture_output=True, encoding="utf-8")
    assert r.returncode == 0 and "INDEXDT" in r.stdout

    with tempfile.TemporaryDirectory() as tmp:
        bad = subprocess.run([sys.executable, tool, tmp + "/nope"], cwd=str(REPO),
                             capture_output=True, encoding="utf-8")
        assert bad.returncode != 0 and "not a product pack" in (bad.stderr + bad.stdout)


if __name__ == "__main__":
    bad = 0
    for name, fn in sorted(globals().items()):
        if name.startswith("test_") and callable(fn):
            try:
                fn()
                print(f"  ok  {name}")
            except Exception as e:                   # noqa: BLE001 - report and continue
                bad += 1
                print(f"FAIL  {name}: {e}")
    sys.exit(1 if bad else 0)
