"""Dashboard-manifest exporter + atomic release pointer (pure Python, no Spark).
Run: python3 test_dashboard.py (or pytest).
"""
import sys
from pathlib import Path

FRAMEWORK = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(FRAMEWORK))
PRODUCTS = FRAMEWORK.parent / "products"

from engine.config import load_yaml, load_config   # noqa: E402
from engine.config import product_config  # noqa: E402
from engine import dashboard, release              # noqa: E402

CATALOG = PRODUCTS / "metadata" / "catalog.yaml"
DASH = PRODUCTS / "_reporting" / "dashboard" / "dashboard_vars.yaml"
PROSTATE = product_config(PRODUCTS.parent / "fixtures", "prostate")


def _manifest(tumor="mcrpc"):
    return dashboard.build_manifest(load_config(PROSTATE), load_yaml(CATALOG), tumor,
                                    dashboard=load_yaml(DASH))


def test_empty_generated_dashboard_is_not_a_complete_deliverable():
    cfg = load_config(PROSTATE)
    catalog = load_yaml(CATALOG)
    empty = dashboard.build_manifest(cfg, catalog, "mcrpc", columns=[])
    assert empty["summary"]["n_variables"] == 0
    assert dashboard.delivery_summary(empty) == {"status": "empty", "n_variables": 0}
    filled = dashboard.build_manifest(cfg, catalog, "mcrpc", columns=["age"])
    assert dashboard.delivery_summary(filled) == {"status": "ok", "n_variables": 1}


def test_manifest_carries_tumor_specific_variables_and_types():
    by = {v["code"]: v for v in _manifest()["variables"]}
    # prostate-specific (applies_to:[mcrpc]) variables are present -> proves code-based filtering
    assert "gleason" in by and "mcrpc" in by and "ttd" in by
    # type model
    os_ = by["os"]
    assert os_["type"] == "time_to_event" and os_["event_flag"] == "dthfl" and os_["unit"] == "months"
    assert by["stage"]["type"] == "categorical" and by["stage"]["values"]      # value set from the pack
    assert by["ecog"]["type"] == "categorical" and by["ecog"]["values"]
    assert by["dthfl"]["type"] == "flag"
    assert by["dthdt"]["type"] == "date"
    assert by["age"]["type"] == "numeric"
    # 0/1 flags that don't end in 'fl', and PSA numerics — no longer misclassified as 'string'
    assert by["mcrpc"]["type"] == "flag" and by["vis120"]["type"] == "flag" and by["trtdis"]["type"] == "flag"
    assert by["psadiag_init"]["type"] == "numeric" and by["psadiag_met"]["type"] == "numeric"

    # --- v2 (mHSPC + mCRPC full-spec) variable typing — regression guard for the whole new var set ----
    # TSST is time-to-event (paired with its event flag); windowed PSA values are numeric.
    assert by["tsst"]["type"] == "time_to_event" and by["tsst"]["event_flag"] == "tsstfl"
    assert by["psa_index"]["type"] == "numeric" and by["psa6mo"]["type"] == "numeric"
    # prior-treatment / metastatic-site / PSA-response flags. prior_nha_adt must NOT be 'date' (ends 'adt').
    for f in ("prior_pluvicto", "prior_nha_adt", "bone_met", "brain_met", "psa50_6mo", "psal12mo", "eligpfs"):
        assert by[f]["type"] == "flag", f
    # closest-to-index labs are Present/Unknown/Missing categoricals (3-state value set from the pack);
    # v/dt are numeric/date
    assert by["labneu"]["type"] == "categorical" and by["labneu"]["values"] == ["Present", "Unknown", "Missing"]
    assert by["labneuv"]["type"] == "numeric" and by["labneudt"]["type"] == "date"
    # diagnosis-date pass-throughs are dates (init/mpcdd don't end in 'dt')
    assert by["init"]["type"] == "date" and by["mpcdd"]["type"] == "date"
    # cohort labels carry their value sets (the 7 cohorts; the per-setting treated/untreated split)
    assert by["cohort"]["type"] == "categorical" and len(by["cohort"]["values"]) == 7
    assert by["cohortu"]["type"] == "categorical" and "Treated mCRPC" in by["cohortu"]["values"]
    assert by["gleason"]["type"] == "categorical" and by["ses"]["type"] == "categorical"
    # categorized pass-through (gleason_cat bands), LoT category (lotcat from the 17-way codelist), and the
    # cohort-aware prior-taxane flag — locks the value-set extraction added for these.
    # THE BANDS THE PACK DECLARES, NOT THE ONES THIS TEST WAS BORN WITH. It pinned a four-band
    # grouping `<=6 / 7 / 8 / 9-10`; the pack's clinical.yaml now groups `<8 / >=8` with a
    # fallthrough `Unknown/Missing`, changed as a spec-stated correction in the owner tranche
    # (365529c). The manifest was faithfully reporting the governed config and this assertion was
    # asserting a superseded clinical grouping — the value set is the PACK's to state, and what
    # this test is for is that the manifest carries it through intact rather than inventing one.
    assert by["gleason_cat"]["type"] == "categorical"
    assert by["gleason_cat"]["values"] == ["<8", ">=8", "Unknown/Missing"], \
        by["gleason_cat"]["values"]
    assert (by["lotcat"]["type"] == "categorical" and len(by["lotcat"]["values"]) == 17
            and "Docetaxel monotherapy" in by["lotcat"]["values"])
    assert by["prior_tax_mcrpc"]["type"] == "flag"


def test_value_sets_are_gathered_from_every_pack_block_that_defines_one():
    """A DIRECT claim, because the indirect one cost an afternoon.

    `dashboard._value_sets` builds its label sets inside broad try/except guards meant for malformed
    packs. A `CLOSEST_PANELS` constant used without its import raised NameError INSIDE one of them,
    the guard swallowed it, and every clinical value set vanished at once — surfacing three
    assertions away as `labneu` typed `string` instead of `categorical`. Nothing said "the block
    aborted"; the symptom named the wrong subject entirely.

    So the claim is stated where it can be read: the value sets prostate's packs define are
    PRESENT. Each family below comes from a different branch of that function, so a swallowed
    failure in any one of them fails here by name rather than by consequence.
    """
    vs = dashboard._value_sets(load_config(PROSTATE))
    for name, why in (("agegrl", "demographics age_bands"),
                      ("race", "demographics race_map"),
                      ("ecog", "clinical baseline_ecog value_codes"),
                      ("labneu", "clinical lab_values panel"),
                      ("gleason_cat", "clinical passthrough bands"),
                      ("cohort", "the cohort label list")):
        assert vs.get(name), f"no value set for {name} — the {why} branch produced nothing"


def test_manifest_columns_filter_excludes_non_emitted():
    # With `columns` (the actual ADS columns) the manifest advertises ONLY what is emitted.
    m = dashboard.build_manifest(load_config(PROSTATE), load_yaml(CATALOG), "mcrpc",
                                 dashboard=load_yaml(DASH), columns=["cohort", "os", "dthfl", "age"])
    codes = {v["code"] for v in m["variables"]}
    assert codes == {"cohort", "os", "dthfl", "age"} and "gleason" not in codes


def test_manifest_excludes_other_tumor_variables():
    codes = {v["code"] for v in _manifest()["variables"]}
    assert "brca" not in codes and "plat_sen_v1" not in codes   # OC-only, not applicable to mcrpc


def test_manifest_panels_keep_only_applicable_variables():
    m = _manifest()
    cataloged = {v["code"] for v in m["variables"]}
    assert m["panels"], "expected panels from the dashboard layout"
    for p in m["panels"]:
        assert all(c in cataloged for c in p["variables"])
    assert m["summary"]["n_variables"] == len(m["variables"]) and m["tumor"] == "mcrpc"


def test_render_json_roundtrips():
    import json
    m = _manifest()
    assert json.loads(dashboard.render_json(m))["tumor"] == "mcrpc"


def test_release_pointer_and_swap_plan():
    # synthetic FQN + spec_version — these exercise the naming/swap-plan/pointer LOGIC only; they are
    # NOT the prostate product contract (that's rwdp_pros_pano_202606 / spec_version 202606).
    final, bid = "out.demo_ads", "abc123def456"
    # build_id makes versioned tables unique per run -> a same-refresh rerun never overwrites the live one
    assert release.versioned_ads(final, "2026q1", bid) == f"{final}__2026q1__{bid}"
    assert release.versioned_tfl(final, "2026q1", bid, "t1") == f"{final}__2026q1__{bid}__tfl_t1"
    plan = release.swap_plan(final, "2026q1", bid, ["t1", "f1"])
    assert plan[-1][0] == final and plan[-1][1] == f"{final}__2026q1__{bid}"   # ADS view swapped LAST
    assert plan[0][0] == release.public_tfl(final, "t1")                       # TFLs first
    assert all(sql.startswith("CREATE OR REPLACE VIEW") for _, _, sql in plan)
    ptr = release.release_pointer(final, "2026q1", bid, ["t1"], spec_version="1.0")
    assert ptr["build_id"] == bid and ptr["ads"] == f"{final}__2026q1__{bid}"
    assert ptr["tfls"]["t1"] == f"{final}__2026q1__{bid}__tfl_t1" and ptr["views"][final] == ptr["ads"]


def test_promotion_publishes_the_approved_bytes_and_never_rebuilds():
    """The step that lets an approval survive a rerun.

    `build_id` embeds the job run id, so every execution mints a new identity and moves the manifest
    digest with it — an approval of build A can never be satisfied by a later run B. The only way to
    honour A is to publish A's staged bytes without rebuilding. Until this existed, Gate 6 could
    refuse a release but never grant one, and `status.py` said so in as many words.
    """
    final, ref, bid = "out.demo_ads", "2026q1", "run77"       # synthetic FQN, as above
    ident = release.candidate_identity(
        [{"table_name": release.staging_ads(final, bid), "table_id": "a", "delta_version": 5,
          "row_count": 9, "location": "s3://demo/ads"}] +
        [{"table_name": release.staging_tfl(final, bid, t), "table_id": t, "delta_version": 0,
          "row_count": 1, "location": f"s3://demo/{t}"} for t in ("t1", "f1")])
    plan = release.promotion_plan(final, ref, bid, ["t1", "f1"], ident)

    # MATERIALISE EVERYTHING, THEN SWAP. A failure part-way leaves the public names on the previous
    # release rather than on half of this one.
    kinds = [k for k, _t, _s, _q in plan]
    assert kinds == ["materialise"] * 3 + ["swap"] * 3, kinds
    assert all(q.startswith("CREATE TABLE ") for k, _t, _s, q in plan if k == "materialise")
    assert all(q.startswith("CREATE OR REPLACE VIEW") for k, _t, _s, q in plan if k == "swap")
    # Never `CREATE OR REPLACE TABLE`: the versioned name is one build's permanent identity, and a
    # statement able to overwrite it could rewrite bytes a live view is already serving.
    assert not any("OR REPLACE TABLE" in q for _k, _t, _s, q in plan)

    # Each versioned table is made from THAT build's staging table, and the ADS is materialised last
    # among the tables and swapped last among the views — the commit anchor at both stages.
    mats = [(t, s) for k, t, s, _q in plan if k == "materialise"]
    assert mats[-1] == (release.versioned_ads(final, ref, bid), release.staging_ads(final, bid))
    assert (release.versioned_tfl(final, ref, bid, "t1"),
            release.staging_tfl(final, bid, "t1")) in mats
    assert [t for k, t, _s, _q in plan if k == "swap"][-1] == final

    # ...and the plan's swap half is the SAME function a build-and-publish run uses. Two orders for
    # one operation would diverge on the first change to either.
    assert [(t, s) for k, t, s, _q in plan if k == "swap"] == \
        [(pub, ver) for pub, ver, _ in release.swap_plan(final, ref, bid, ["t1", "f1"])]


def test_promotion_refuses_a_candidate_whose_bytes_are_gone_or_already_published():
    """The PHYSICAL half of Gate 6, which the paperwork cannot answer.

    `publish_approval_errors` establishes that a named person's approval binds this build_id and this
    manifest digest. It says nothing about whether the bytes that approval describes are still on the
    cluster — and promotion is the one step here that publishes something it did not just build.
    """
    final, ref, bid = "out.demo_ads", "2026q1", "run77"
    tfls = ["t1"]
    stg_ads, stg_tfl = release.staging_ads(final, bid), release.staging_tfl(final, bid, "t1")
    staged = {stg_ads, stg_tfl}
    ident = release.candidate_identity(
        [{"table_name": stg_ads, "table_id": "id-ads", "delta_version": 3, "row_count": 1000,
          "location": "s3://demo/ads"},
         {"table_name": stg_tfl, "table_id": "id-tfl", "delta_version": 1, "row_count": 12,
          "location": "s3://demo/tfl"}])

    assert release.promotion_blockers(final, ref, bid, tfls, staged, ident, ident) == []

    # The approved bytes are gone. Rebuilding would mint a new build_id and a new manifest digest, so
    # it would not be the approved candidate — it would be a different product wearing an approval.
    gone = release.promotion_blockers(final, ref, bid, tfls, set(), ident, ident)
    assert any("does not rebuild" in g for g in gone), gone
    assert any(stg_ads in g for g in gone)

    # Already promoted: the versioned table is immutable and a public view may already serve it.
    again = release.promotion_blockers(final, ref, bid, tfls,
                                       staged | {release.versioned_ads(final, ref, bid)},
                                       ident, ident)
    assert any("already promoted" in g for g in again), again

    # A partially-promoted state reports BOTH, rather than the first one it happens to find.
    both = release.promotion_blockers(
        final, ref, bid, tfls, {release.versioned_ads(final, ref, bid)}, ident, ident)
    assert len(both) == 2, both

    # A build the operator names but never staged is the same refusal as bytes that were cleaned up.
    # There is no path here that reaches a build step, which is the property worth pinning: promotion
    # publishes or refuses, and rebuilding is not one of its outcomes.
    import inspect
    src = inspect.getsource(release)
    assert "build_from_sources" not in src and "def build" not in src


def test_a_candidate_is_pinned_to_its_BYTES_and_not_to_a_table_NAME():
    """The refusal the two above structurally cannot make.

    Both of them ask which NAMES exist in the output schema, and a candidate is not a name. The
    approval bound `ads__staging__<build_id>`, and a table with that name holding different bytes
    satisfied every check there was — an approval of the rows that used to be there, honoured over
    rows nobody read. `build_id` embeds the job run id, which makes an accidental collision unlikely;
    it does not make it CHECKED, and a release gate exists for the case that is not an accident.

    Delta's version is the pin: a monotonically increasing integer that moves on any write. Two
    observations at the same version are the same bytes, and no content hash is needed to say so.
    """
    final, ref, bid = "out.demo_ads", "2026q1", "run77"
    stg = release.staging_ads(final, bid)
    staged = {stg}
    approved = release.candidate_identity(
        [{"table_name": stg, "table_id": "0f2c-…-9a", "delta_version": 7, "row_count": 4210,
          "num_files": 12, "size_bytes": 99000, "location": "s3://demo/stg"}])

    assert release.promotion_blockers(final, ref, bid, [], staged, approved, approved) == []

    # SOMEBODY WROTE TO THE APPROVED CANDIDATE. The name is right, the table is there, and the bytes
    # are not the ones that were signed.
    moved = release.candidate_identity(
        [{"table_name": stg, "table_id": "0f2c-…-9a", "delta_version": 8, "row_count": 4210,
          "location": "s3://demo/stg"}])
    why = release.promotion_blockers(final, ref, bid, [], staged, approved, moved)
    assert why and "delta_version was 7" in why[0] and "is 8 now" in why[0], why
    assert "anybody signed" in why[0]

    # A VERSION ALONE IS NOT AN IDENTITY. Drop the staging table, create it again and write the same
    # rows: the replacement can carry the same version with a different transaction log behind it, and
    # `VERSION AS OF` would resolve against a table nobody approved while every number agreed. Delta's
    # table id changes on a recreate and does not change on a write — the one distinction the version
    # cannot draw, and the reason the first version of this check was not enough.
    recreated = release.candidate_identity(
        [{"table_name": stg, "table_id": "b71e-…-04", "delta_version": 7, "row_count": 4210,
          "location": "s3://demo/stg-recreated"}])
    same_numbers = release.promotion_blockers(final, ref, bid, [], staged, approved, recreated)
    assert any("table_id was" in w for w in same_numbers), same_numbers

    # ...and the row count alone, at the same version, is impossible in Delta — but it is checked
    # anyway, because a check that trusts one field to imply another is one migration from wrong.
    fewer = release.candidate_identity(
        [{"table_name": stg, "table_id": "0f2c-…-9a", "delta_version": 7, "row_count": 4209,
          "location": "s3://demo/stg"}])
    assert any("row_count was 4210" in w for w in
               release.promotion_blockers(final, ref, bid, [], staged, approved, fewer))

    # OPTIMIZE REWRITES FILES AND CHANGES NEITHER ROW. `num_files` and `size_bytes` are recorded for
    # a human reading the manifest later and deliberately NOT compared: a gate that refused a
    # compaction would be routed around inside a month, and the version moving already catches it.
    compacted = release.candidate_identity(
        [{"table_name": stg, "table_id": "0f2c-…-9a", "delta_version": 7, "row_count": 4210,
          "num_files": 1, "size_bytes": 71000, "location": "s3://demo/stg"}])
    assert release.promotion_blockers(final, ref, bid, [], staged, approved, compacted) == []

    # FAIL CLOSED ON ABSENCE, BOTH WAYS. "Unstated" is not "unchanged", and this is the gate where
    # that distinction decides whether unverified bytes reach production.
    assert release.promotion_blockers(final, ref, bid, [], staged, None, moved), \
        "a candidate whose manifest records no identity promoted — it cannot be verified at all"
    absent = release.promotion_blockers(final, ref, bid, [], staged, approved, {})
    assert absent and "probe did not run" in absent[0], absent

    # A PARTIAL IDENTITY IS NOT A CANDIDATE. This was the sharpest hole in the first version: the
    # comparison iterated the RECORDED keys, so a candidate whose ADS probe succeeded and whose TFL
    # probe failed was signed with the ADS alone — and promotion then pinned the ADS, verified the
    # ADS, and published the TFL from whatever staging held at that moment, unpinned and unverified,
    # with no message anywhere. The gap was missing from both sides of the comparison, so partial
    # evidence read as complete evidence.
    #
    # The expected set is derived from the promotion plan, so it cannot drift from what is published.
    both_staged = {stg, release.staging_tfl(final, bid, "t1")}
    partial = release.promotion_blockers(final, ref, bid, ["t1"], both_staged, approved, approved)
    assert partial, "a candidate signed over the ADS alone promoted a TFL nobody measured"
    assert any(release.staging_tfl(final, bid, "t1") in w and "records no identity" in w
               for w in partial), partial

    # ...and the mirror: a candidate signed over MORE than this promotion publishes. The signed set
    # and the published set differ, which is the same defect read from the other end.
    extra = release.candidate_identity(
        [{"table_name": stg, "table_id": "0f2c-…-9a", "delta_version": 7, "row_count": 4210},
         {"table_name": "out.demo_ads__staging__other", "table_id": "z", "delta_version": 0,
          "row_count": 1}])
    assert any("does not publish" in w for w in
               release.promotion_blockers(final, ref, bid, [], staged, extra, extra))

    # THERE IS NO UNPINNED MATERIALISE. The fallback that read the live table when no version was
    # supplied WAS the hole above, sitting one `.get()` from the check meant to close it. A caller
    # with no version has not established what it is publishing, so this raises rather than emitting
    # SQL — an unpinned read is a programming error, not a governance state to report.
    try:
        release.materialise_sql("v", "s")
        raise AssertionError("materialise_sql emitted an UNPINNED read — it publishes whatever "
                             "staging holds now, which is the defect the identity exists to prevent")
    except ValueError as err:
        assert "no approved Delta version" in str(err), err
    # materialise reads the table — two reads, and a write in the gap would be published with the
    # check's blessing. Naming the version in the SQL removes the gap instead of narrowing it.
    sql = [q for k, _t, _s, q in release.promotion_plan(final, ref, bid, [], approved)
           if k == "materialise"]
    assert sql and sql[0].endswith(f"FROM {stg} VERSION AS OF 7"), sql
    assert "OR REPLACE TABLE" not in sql[0]
    # `USING DELTA`, stated — every identity later asked of this table (DESCRIBE HISTORY/DETAIL,
    # the journaled output identity) is a Delta-only answer, and the workspace default is a setting.
    assert "USING DELTA" in sql[0], sql


def test_an_interrupted_promotion_resumes_instead_of_becoming_unrecoverable():
    """Three side effects with nothing recorded between them, and every gap an unrecoverable state.

    Promotion materialised every table, swapped every view, then wrote the receipt. A failure between
    any two left a position a retry could not tell from the others — half the tables made, half the
    views moved, or live with no record that it was — and the blanket "already promoted" refusal then
    stopped the retry for having got part of the way. The operator's instruction was "drop the
    versioned tables by hand", which is wrong once a public view points at one.

    So intent is written BEFORE the first side effect and each completed stage is recorded. What the
    journal buys is a distinction nothing else can reconstruct: a versioned table THIS promotion made
    and did not finish, versus a versioned table belonging to somebody else's release.
    """
    final, ref, bid = "out.demo_ads", "2026q1", "run77"
    sa, st = release.staging_ads(final, bid), release.staging_tfl(final, bid, "t1")
    va, vt = release.versioned_ads(final, ref, bid), release.versioned_tfl(final, ref, bid, "t1")
    ident = release.candidate_identity(
        [{"table_name": sa, "table_id": "A", "delta_version": 2, "row_count": 100,
          "location": "s3://demo/sa"},
         {"table_name": st, "table_id": "B", "delta_version": 0, "row_count": 7,
          "location": "s3://demo/st"}])
    intent = release.promotion_intent(final, ref, bid, ["t1"],
                                      candidate_sha256="deadbeef", approved_identity=ident)
    assert intent["state"] == "prepared" and len(intent["tables"]) == 2

    # CRASHED AFTER THE TFL TABLE, BEFORE THE ADS. The TFL versioned table exists, holds what was
    # approved, AND re-probes to the identity materialisation journaled — protocol 2 accepts
    # nothing weaker: a resume that offers no observed identities is refused outright.
    made = {"table_id": "V1", "location": "s3://demo/vt", "delta_version": 0,
            "row_count": 7, "schema_digest": release.schema_digest([("id", "STRING")])}
    intent["outputs"] = {vt: dict(made)}
    _d, unprobed = release.reconcile(intent, {sa, st, vt}, {vt: 7})
    assert _d == [] and unprobed and "not re-probed" in unprobed[0], (_d, unprobed)
    done, partial = release.reconcile(intent, {sa, st, vt}, {vt: 7},
                                      observed_outputs={vt: dict(made)})
    assert done == [vt] and partial == [], (done, partial)
    assert release.promotion_blockers(final, ref, bid, ["t1"], {sa, st, vt},
                                      ident, ident, done) == []
    steps = release.promotion_plan(final, ref, bid, ["t1"], ident, done)
    mats = [t for k, t, _s, _q in steps if k == "materialise"]
    assert mats == [va], f"the resume remade a table it had already made: {mats}"
    # ...and every view is still swapped. `CREATE OR REPLACE VIEW` is idempotent, and working out
    # which views a crashed run reached would be a second, fallible answer to a free question.
    assert [t for k, t, _s, _q in steps if k == "swap"] == [release.public_tfl(final, "t1"), final]

    # WITHOUT THE JOURNAL, that same table is somebody else's release and the refusal stands.
    assert any("already promoted" in w for w in
               release.promotion_blockers(final, ref, bid, ["t1"], {sa, st, vt}, ident, ident))

    # A PARTIAL WRITE OF OUR OWN, and the advice differs by state — because whether it is safe to
    # drop depends on whether a public view has been pointed at it yet.
    _d, before = release.reconcile(intent, {sa, st, vt}, {vt: 3})
    assert before and "safe to drop" in before[0], before
    _d, after = release.reconcile(release.advance(intent, "views_switched"), {sa, st, vt}, {vt: 3})
    assert after and "do NOT drop" in after[0], after

    # AN EXISTING TARGET THAT WAS NOT COUNTED IS NOT A COMPLETED STEP. "Unverified" is not "fine",
    # and this is the gate where that decides whether unapproved bytes get published.
    _d, uncounted = release.reconcile(intent, {sa, st, vt}, {})
    assert uncounted and "not counted" in uncounted[0], uncounted

    # THE JOURNAL MUST DESCRIBE *THIS* PROMOTION. Resuming another build's, or one written against a
    # different approved digest, would finish somebody else's work under this run's approval.
    assert release.journal_blockers({}, bid, "deadbeef") == [], "no journal is a first attempt"
    assert any("not 'run77'" in w for w in
               release.journal_blockers(dict(intent, build_id="other"), bid, "deadbeef"))
    assert any("different candidate manifest digest" in w for w in
               release.journal_blockers(intent, bid, "cafe"))

    # FORWARD ONLY. A retry that re-ran a recorded stage and wrote its own earlier state would walk
    # the journal backwards, and the next retry would redo work the first had finished.
    assert release.advance(release.advance(intent, "views_switched"), "prepared")["state"] \
        == "views_switched"
    assert release.advance(intent, "materialised")["state"] == "materialised"
    try:
        release.advance(intent, "done")
        raise AssertionError("an unknown state was accepted into the journal")
    except ValueError as err:
        assert "not a promotion state" in str(err), err


def test_a_late_promotion_cannot_move_the_public_views_backwards():
    """Nothing bound a promotion to the state of the world it was approved against.

    Build A is staged and signed. Build B is built, approved and published while A waits. A is then
    promoted — and every public view moves BACKWARDS onto older data with every check passing,
    because A's bytes really are the bytes A's approver signed. The approval was never wrong; it was
    never about the release it would replace.

    A compare-and-set fixes it without a clock and without ordering build ids: record what the views
    serve when the candidate is signed, re-read at promotion, refuse a difference. The same check
    catches a rollback somebody did by hand and a view repointed at another product's table.
    """
    final = "out.demo_ads"
    # THE PARSE IS THE INVERSE OF `view_swap_sql`, which is why this module owns it. Asserted against
    # the statement that module writes, not against a string invented here.
    _pub, ver, sql = release.swap_plan(final, "2026q1", "A", [])[0]
    assert release.view_target(sql.split(" AS ", 1)[1]) == ver, sql
    assert release.view_target("") == "", "an unreadable view text must not parse to a table name"

    approved_against = release.observed_release({final: "SELECT * FROM out.demo_ads__2026q1__old"})
    assert approved_against == {final: "out.demo_ads__2026q1__old"}
    assert release.supersedes_blockers(approved_against, approved_against) == []

    moved = release.observed_release({final: "SELECT * FROM out.demo_ads__2026q1__NEWER"})
    why = release.supersedes_blockers(approved_against, moved)
    assert why and "__old" in why[0] and "__NEWER" in why[0], why
    assert "BACKWARDS" in why[0] and "rollback is its own approved operation" in why[0]

    # NO RELEASE YET IS A REAL STATE, not a gap — otherwise a product's FIRST promotion is refused
    # forever. And something published between approval and promotion is still caught.
    assert release.supersedes_blockers({final: None}, {final: None}) == []
    assert release.supersedes_blockers({final: None},
                                       release.observed_release({final: "SELECT * FROM x.y"}))

    # ...and a candidate that recorded nothing cannot be checked, so it is refused rather than passed.
    assert release.supersedes_blockers(None, moved), "a candidate with no `supersedes` promoted"


def test_two_promotions_of_one_product_cannot_interleave():
    """The swap order bounds what a consumer sees within ONE run. It says nothing about two.

    A's TFL swapped, then B's ADS, and the public set is a mixture neither run intended — while each
    believes it published a consistent release.
    """
    final = "out.demo_ads"
    assert release.promotion_lock(final) == "out.demo_ads__promotion_lock"
    sql = release.acquire_lock_sql(final, "b9", "O'Brien", "2026-08-06T12:00:00Z",
                                   attempt_id="att-1")
    # CREATE, never CREATE OR REPLACE: the metastore's refusal of an existing name IS the mutex, and
    # a statement that overwrote would hand the lock to whoever asked last.
    assert sql.startswith("CREATE TABLE out.demo_ads__promotion_lock USING DELTA AS SELECT"), \
        sql   # Delta stated, not defaulted: the takeover CAS rides Delta's transactional UPDATE
    assert "OR REPLACE" not in sql
    assert "'O''Brien'" in sql, "an apostrophe in an actor's name breaks the statement"
    assert "'att-1' AS attempt_id" in sql, "the lock must record WHOSE attempt holds it"

    assert release.lock_blockers(None, "b9") == [], "no lock is not a blocker"
    theirs = release.lock_blockers({"build_id": "b7", "actor": "ops", "acquired_at": "t"}, "b9")
    assert theirs and "b7" in theirs[0] and "ops" in theirs[0], theirs
    assert "interleaving" in theirs[0], "the refusal does not say what the risk is"
    assert release.release_lock_sql(final) == "DROP TABLE IF EXISTS out.demo_ads__promotion_lock"


def test_a_duplicate_of_the_same_build_is_not_a_crashed_attempt():
    """Same build id is NOT the same attempt.

    `lock_blockers` used to wave through any holder wearing this build's id, so once a first
    invocation had journalled, a live concurrent duplicate of the same build read as "a crashed
    attempt" and the two interleaved their swaps exactly like two builds — an external review's
    concurrency probe demonstrated it. Every invocation now mints its own attempt id; taking over
    a held lock of the same build requires the operator to NAME the held attempt
    (resume_promotion=<attempt_id>), which is inspection as an argument, never inferred from an id.
    """
    held = {"build_id": "b9", "actor": "x", "acquired_at": "t", "attempt_id": "a1"}
    # this invocation's own lock, re-checked mid-run: not a blocker
    assert release.lock_blockers(held, "b9", attempt_id="a1") == []
    # a DIFFERENT attempt of the SAME build: blocked, and the refusal says how a person takes over
    dup = release.lock_blockers(held, "b9", attempt_id="a2")
    assert dup and "a1" in dup[0] and "resume_promotion=a1" in dup[0], dup
    assert "will not infer a death from a build id" in dup[0], dup
    # the explicit, inspected takeover: the operator named the dead attempt
    assert release.lock_blockers(held, "b9", attempt_id="a2", resume_attempt="a1") == []
    # naming the WRONG attempt is not a takeover of this one
    assert release.lock_blockers(held, "b9", attempt_id="a2", resume_attempt="stale"), \
        "a stale resume_promotion value took over a lock it does not name"
    # a legacy lock row with no attempt recorded cannot be taken over by argument — it blocks, and
    # a person drops it deliberately. Fail closed, not backwards-compatible-open.
    legacy = release.lock_blockers({"build_id": "b9", "actor": "x"}, "b9", attempt_id="a2")
    assert legacy and "unrecorded" in legacy[0], legacy
    # ...and the journal records which attempt wrote intent
    intent = release.promotion_intent("out.demo_ads", "2026q1", "b9", [],
                                      candidate_sha256="deadbeef", attempt_id="a1")
    assert intent["attempt_id"] == "a1"


def test_a_completed_promotion_is_terminal_and_cannot_replay():
    """Rerunning approved-and-published promotion A after B has published rolled the release back.

    The resume path classified A's `receipted` journal as resumable; past `views_switched` the
    supersedes comparison is skipped (it would refuse this run's own work), so the rerun re-emitted
    every swap and rewrote the pointer — consumers moved BACKWARDS onto A with every check passing.
    An external review demonstrated exactly that. Two refusals close it, and each is tested from
    the state the attacker actually arrives in:

      * `receipted` is TERMINAL — `journal_blockers` refuses it outright; the runner's only legal
        response is to verify the receipt and exit `already_promoted` without issuing SQL;
      * a NON-terminal journal whose pointer names a different build is a stalled attempt a newer
        release overtook — `rollback_blockers` refuses the resume before anything moves.
    """
    intent = release.promotion_intent("out.demo_ads", "2026q1", "A", [],
                                      candidate_sha256="deadbeef", attempt_id="a1")
    done = release.advance(release.advance(release.advance(release.advance(
        intent, "materialised"), "views_switched"), "pointed"), "receipted")
    why = release.journal_blockers(done, "A", "deadbeef")
    assert why and "TERMINAL" in why[0] and "never resumable" in why[0], why
    assert "already promoted" not in why[0].lower() or "re-running" in why[0], \
        "the refusal must direct the rerun to verify-and-stop, not to resume"
    # every non-terminal state is still resumable — the fix must not strand a genuine crash
    for state in release.PROMOTION_STATES[:-1]:
        live = dict(intent, state=state)
        assert release.journal_blockers(live, "A", "deadbeef") == [], (state,)

    # THE POINTER IS THE AUTHORITY on "did somebody publish after this attempt stalled".
    ptr_a = [{"build_id": "A", "published_at": "t1"}]
    ptr_b = [{"build_id": "B", "published_at": "t2"}]
    stalled = dict(intent, state="views_switched")
    assert release.rollback_blockers(stalled, ptr_a) == [], \
        "a resume of the build the pointer already names is a legitimate crash recovery"
    assert release.rollback_blockers(stalled, []) == [], \
        "no pointer row yet means nothing published through it — a first promotion resumes"
    assert release.rollback_blockers(None, ptr_b) == [], "no journal, nothing to resume"
    back = release.rollback_blockers(stalled, ptr_b)
    assert back and "BACKWARDS" in back[0] and "'B'" in back[0] and "'A'" in back[0], back
    assert "dead" in back[0], "the refusal must say the attempt is dead, not retryable"
    # A TWO-ROW POINTER IS AMBIGUOUS, never "read row zero". The guard trusted rows[0], so a
    # pointer an interleaved writer left with two rows passed whenever row zero happened to look
    # acceptable — and a consumer resolving through it gets no single answer either.
    two = release.rollback_blockers(stalled, ptr_a + ptr_b)
    assert two and "2 rows" in two[0] and "ambiguous" in two[0], two


def test_a_malformed_lock_is_refused_never_read_as_absent():
    """The runner read `rows[0]` off the lock table, so an EMPTY table read as "no holder".

    An existing lock table with zero rows, two rows, or a row missing its attempt id is not an
    absent lock — it is a malformed one, and every malformed shape has an interleaving story
    (a takeover half-committed, a hand-edit, two writers). Fail closed: exactly one complete row
    or a person repairs it.
    """
    ok = {"build_id": "b9", "actor": "x", "acquired_at": "t", "attempt_id": "a1"}
    assert release.lock_row_errors([ok]) == []
    empty = release.lock_row_errors([])
    assert empty and "NO row" in empty[0] and "not an absent lock" in empty[0].replace(
        "an empty lock is not an absent lock", "not an absent lock"), empty
    two = release.lock_row_errors([ok, dict(ok, attempt_id="a2")])
    assert two and "2 rows" in two[0] and "will not pick a row" in two[0], two
    for gone in release.LOCK_FIELDS:
        bad = release.lock_row_errors([{k: v for k, v in ok.items() if k != gone}])
        assert bad and gone in bad[0], (gone, bad)
    # and the blocker predicate distinguishes NO table (None) from an empty holder dict — the
    # second is malformed, never free
    assert release.lock_blockers(None, "b9") == []
    hollow = release.lock_blockers({}, "b9")
    assert hollow and "malformed" in hollow[0], hollow


def test_a_resume_token_is_consumed_by_the_compare_and_set():
    """Naming a dead attempt in `resume_promotion` used to BE the takeover, and the lock row kept
    the dead attempt's id — so one token authorised every presenter, concurrently. The takeover is
    now a Delta UPDATE whose predicate is the compare (build AND old attempt) and whose SET installs
    the new attempt: concurrent presenters serialize on the Delta commit, the loser matches zero
    rows, and the runner refuses when the re-read row does not wear ITS attempt id.
    """
    sql = release.takeover_lock_sql("out.demo_ads", "b9", "a-dead", "a-new",
                                    "O'Brien", "2026-08-13T12:00:00Z")
    assert sql.startswith("UPDATE out.demo_ads__promotion_lock SET "), sql
    assert "attempt_id = 'a-new'" in sql, "the SET must install the NEW attempt"
    assert "WHERE build_id = 'b9' AND attempt_id = 'a-dead'" in sql, \
        "the predicate IS the compare — without the old attempt in it, the token is reusable"
    assert "'O''Brien'" in sql, "an apostrophe in an actor's name breaks the statement"
    # after ONE takeover commits, the row wears the new attempt: a second presenter of the same
    # token now fails lock_blockers (the row no longer names the attempt the token authorises)
    after = {"build_id": "b9", "actor": "x", "acquired_at": "t", "attempt_id": "a-new"}
    second = release.lock_blockers(after, "b9", attempt_id="a-second", resume_attempt="a-dead")
    assert second and "resume_promotion=a-new" in second[0], second


def test_a_candidate_promotes_only_under_the_config_it_was_built_from():
    """Promotion resolves every name from the CURRENT config; the approval signed a candidate
    built under the config of ITS day — and nothing compared the two. A candidate built and
    approved under 202606 promoted cleanly after the pack moved to 202612, the receipt validating
    because every field was filled from the same wrong place. The candidate's recorded bindings
    (spec_version, refresh, output table, the Gate 3/4 config digests) must match the runtime's,
    and a candidate that recorded nothing is refused rather than waved through."""
    cand = {"spec_version": "202606", "refresh": "2026q1", "output_table": "out.demo_ads",
            "config_identity": {"config_bundle_sha256": "aaa111", "delivery_sha256": "bbb222"}}
    now = {"config_bundle_sha256": "aaa111", "delivery_sha256": "bbb222"}
    ok = release.candidate_binding_blockers(cand, spec_version="202606", refresh="2026q1",
                                            output_fqn="out.demo_ads", config_identity=now)
    assert ok == [], ok
    # the review's exact scenario: the pack moved to 202612 after the approval
    moved = release.candidate_binding_blockers(cand, spec_version="202612", refresh="2026q1",
                                               output_fqn="out.demo_ads_202612",
                                               config_identity=now)
    assert any("202606" in w and "202612" in w for w in moved), moved
    # the edit a spec version cannot see: the SAME version's config changed
    edited = release.candidate_binding_blockers(
        cand, spec_version="202606", refresh="2026q1", output_fqn="out.demo_ads",
        config_identity={"config_bundle_sha256": "CHANGED", "delivery_sha256": "bbb222"})
    assert any("config_bundle_sha256" in w and "changed after the approval" in w
               for w in edited), edited
    # a candidate that recorded no bindings does NOT promote — unstated is not matching
    bare = release.candidate_binding_blockers({}, spec_version="202606", refresh="2026q1",
                                              output_fqn="out.demo_ads", config_identity=now)
    assert any("records no spec_version" in w for w in bare), bare
    assert any("records no config_identity.config_bundle_sha256" in w for w in bare), bare
    # A GOVERNED PROMOTION PUBLISHES ONLY RELEASE-GRADE CANDIDATES. A dev-mode build was
    # indistinguishable from a release-grade one in its bytes; the candidate now records its
    # run_mode and a prod promotion refuses anything else — including a candidate that records
    # nothing, which predates the freeze and is rebuilt, not assumed.
    kw = dict(spec_version="202606", refresh="2026q1", output_fqn="out.demo_ads",
              config_identity=now, require_release_grade=True)
    dev = release.candidate_binding_blockers(
        dict(cand, run_mode={"env": "dev", "release_grade": False}), **kw)
    assert any("RELEASE-GRADE" in w for w in dev), dev
    assert any("RELEASE-GRADE" in w for w in
               release.candidate_binding_blockers(dict(cand), **kw)), "absence must refuse"
    assert release.candidate_binding_blockers(
        dict(cand, run_mode={"env": "prod", "release_grade": True}), **kw) == []
    # ...and a dev promotion of a dev candidate stays legal — SIT exercises the same path
    assert release.candidate_binding_blockers(
        dict(cand, run_mode={"env": "dev", "release_grade": False}),
        spec_version="202606", refresh="2026q1", output_fqn="out.demo_ads",
        config_identity=now, require_release_grade=False) == []


def test_a_crash_inside_the_create_is_refused_not_adopted():
    """The runner journals a `pending` marker BEFORE each CTAS and the real identity after it, so
    an existing target the journal holds no identity for is the crash landing inside the CREATE —
    and the resume used to fall back to count-plus-property there, the exact comparison a
    same-count impostor already passed. On a journal that records outputs, identity-less is
    refused; only a journal from before `outputs` existed reconciles on count alone."""
    final, ref, bid = "out.demo_ads", "2026q1", "run77"
    sa, st = release.staging_ads(final, bid), release.staging_tfl(final, bid, "t1")
    vt = release.versioned_tfl(final, ref, bid, "t1")
    ident = release.candidate_identity(
        [{"table_name": sa, "table_id": "A", "delta_version": 2, "row_count": 100,
          "location": "s3://demo/sa"},
         {"table_name": st, "table_id": "B", "delta_version": 0, "row_count": 7,
          "location": "s3://demo/st"}])
    journal = release.promotion_intent(final, ref, bid, ["t1"], candidate_sha256="deadbeef",
                                       approved_identity=ident, attempt_id="a1")
    journal["outputs"] = {vt: {"pending": True}}      # intent written, CREATE interrupted
    props = {vt: {"rwdp_build_id": bid}}
    obs = {vt: {"table_id": "V1", "location": "s3://demo/vt", "delta_version": 0,
                "row_count": 7, "schema_digest": "aa"}}
    done, why = release.reconcile(journal, {sa, st, vt}, {vt: 7}, props, observed_outputs=obs)
    assert done == [] and why, (done, why)
    assert "no materialised identity" in why[0] and "inside its CREATE" in why[0], why
    assert "safe to drop" not in why[0] and "inspect and drop it deliberately" in why[0].lower(), \
        "pre-swap advice must be inspect-then-drop, not an invitation to adopt"
    # same crash discovered after a view moved: the advice flips to do-NOT-drop
    later = release.advance(dict(journal), "views_switched")
    _d, why2 = release.reconcile(later, {sa, st, vt}, {vt: 7}, props, observed_outputs=obs)
    assert why2 and "do NOT drop" in why2[0], why2


def test_an_output_is_identified_by_more_than_its_count():
    """A resume used to confirm a versioned table by row count plus a mutable TBLPROPERTY.

    An external review's probe passed a same-count impostor wearing the expected property.
    Materialisation now journals each output's {table_id, location, delta_version, schema_digest};
    a resume re-probes and `reconcile` refuses a table that disagrees — whatever its count says.
    """
    digest = release.schema_digest([("id", "STRING"), ("n", "INT")])
    # order-insensitive and case-insensitive: column order is a projection detail
    assert digest == release.schema_digest([("N", "int"), ("ID", "string")])
    assert digest != release.schema_digest([("id", "STRING"), ("n", "BIGINT")]), \
        "a type change must move the digest"

    row = {"table_name": "out.t", "table_id": "T1", "location": "s3://demo/t",
           "delta_version": 0, "row_count": 7}
    out = release.output_identity_row(row, [("id", "STRING"), ("n", "INT")])
    assert out == {"table_id": "T1", "location": "s3://demo/t", "delta_version": 0,
                   "row_count": 7, "schema_digest": digest}

    final, ref, bid = "out.demo_ads", "2026q1", "run77"
    sa, st = release.staging_ads(final, bid), release.staging_tfl(final, bid, "t1")
    vt = release.versioned_tfl(final, ref, bid, "t1")
    ident = release.candidate_identity(
        [{"table_name": sa, "table_id": "A", "delta_version": 2, "row_count": 100,
          "location": "s3://demo/sa"},
         {"table_name": st, "table_id": "B", "delta_version": 0, "row_count": 7,
          "location": "s3://demo/st"}])
    journal = release.promotion_intent(final, ref, bid, ["t1"], candidate_sha256="deadbeef",
                                       approved_identity=ident, attempt_id="a1")
    made = dict(out, table_id="V1", location="s3://demo/vt")
    journal["outputs"] = {vt: made}
    props = {vt: {"rwdp_build_id": bid}}

    # the SAME table this promotion made: still a completed step
    done, why = release.reconcile(journal, {sa, st, vt}, {vt: 7}, props,
                                  observed_outputs={vt: dict(made)})
    assert done == [vt] and why == [], (done, why)
    # right count, right property, WRONG table id: not the table this promotion made
    done, why = release.reconcile(journal, {sa, st, vt}, {vt: 7}, props,
                                  observed_outputs={vt: dict(made, table_id="IMPOSTOR")})
    assert done == [] and why and "not the table this promotion made" in why[0], (done, why)
    # journaled with an identity, resumed without probing one: unverified is not done
    done, why = release.reconcile(journal, {sa, st, vt}, {vt: 7}, props, observed_outputs={})
    assert done == [] and why and "observed none" in why[0], (done, why)
    # a PARTIAL identity confirms nothing — a field skipped is a field an impostor does not have
    # to match, which an external review demonstrated with a table_id-only journal entry
    thin = dict(journal, outputs={vt: {"table_id": "V1"}})
    done, why = release.reconcile(thin, {sa, st, vt}, {vt: 7}, props,
                                  observed_outputs={vt: dict(made)})
    assert done == [] and any("partial identity" in w for w in why), (done, why)
    # ...and a journal from BEFORE the protocol (count+property was its whole comparison) is
    # refused automatic recovery outright, not reconciled on the comparison an impostor passed
    old = {k: v for k, v in journal.items() if k not in ("outputs", "protocol")}
    done, why = release.reconcile(old, {sa, st, vt}, {vt: 7}, props,
                                  observed_outputs={vt: dict(made)})
    assert done == [] and why and "protocol" in why[0].lower(), (done, why)
    assert "refused" in why[0], why


def test_one_row_one_write_the_whole_release_set():
    """The views are N statements and Databricks has no transaction across them.

    TFLs-first-ADS-last bounds it — a consumer anchored on the ADS view sees the previous release
    until the last statement — but a consumer reading a TFL view directly can catch this build's TFL
    beside the previous build's ADS. OPERATIONS.md told consumers to anchor on the ADS view, which is
    a convention asking readers to be careful rather than a guarantee that they need not be.

    One row, one `INSERT OVERWRITE`, one Delta transaction. Whether that really is one transaction is
    not assertable here and is asserted against Delta itself, in the promotion smoke suite, by reading
    the pointer's own version history and finding no version that holds a partial set.
    """
    import json
    final, ref, bid = "out.demo_ads", "2026q1", "run77"
    assert release.release_pointer_table(final) == "out.demo_ads__release"

    setup = release.pointer_create_sql(final)
    assert setup.startswith("CREATE TABLE IF NOT EXISTS out.demo_ads__release ("), setup
    assert "USING DELTA" in setup

    write = release.pointer_write_sql(final, ref, bid, ["t1", "f1"],
                                      spec_version="202606", published_at="2026-08-06T12:00:00Z")
    # ONE STATEMENT. A pointer published by two writes has an instant where it is neither release,
    # which is the whole failure it exists to remove.
    assert write.count(";") == 0 and write.startswith("INSERT OVERWRITE TABLE"), write
    # NOT `CREATE OR REPLACE TABLE ... AS SELECT`: this catalog refuses it outright
    # (UNSUPPORTED_FEATURE.TABLE_OPERATION), which is a thing running it found and reading did not.
    assert "CREATE OR REPLACE TABLE" not in write

    # THE SAME RELEASE SET THE MANIFEST RECORDS. Built from `release_pointer`, so the table and the
    # ledger cannot describe different releases — the failure every other check here exists to stop,
    # one artifact apart.
    want = release.release_pointer(final, ref, bid, ["t1", "f1"], spec_version="202606")
    assert f"'{want['ads']}' AS ads" in write, write
    assert f"'{json.dumps(want['tfls'], sort_keys=True)}' AS tfls" in write, write

    row = {"public": want["public"], "version": want["version"], "build_id": bid,
           "ads": want["ads"], "tfls": json.dumps(want["tfls"], sort_keys=True)}
    assert release.pointer_blockers([row], final, ref, bid, ["t1", "f1"]) == []
    # A POINTER THAT SAYS SOMETHING ELSE IS WORSE THAN NO POINTER: it is the one place a consumer is
    # being told to trust over the views.
    assert any("build_id" in w for w in
               release.pointer_blockers([dict(row, build_id="other")], final, ref, bid, ["t1", "f1"]))
    assert any("tfls" in w for w in
               release.pointer_blockers([dict(row, tfls="{}")], final, ref, bid, ["t1", "f1"]))
    assert any("not JSON" in w for w in
               release.pointer_blockers([dict(row, tfls="{oops")], final, ref, bid, ["t1", "f1"]))
    for count, rows in ((0, []), (2, [row, row])):
        why = release.pointer_blockers(rows, final, ref, bid, ["t1", "f1"])
        assert why and f"{count} row(s)" in why[0], (count, why)

    # THE POINTER IS THE COMMIT ANCHOR, so its state sits after the views and before the receipt.
    assert release.PROMOTION_STATES.index("pointed") > \
        release.PROMOTION_STATES.index("views_switched")
    assert release.PROMOTION_STATES.index("pointed") < release.PROMOTION_STATES.index("receipted")

    # ...and the statement a CONSUMER runs is stated here, so the documentation cannot drift from it.
    assert release.release_pointer_table(final) in release.pointer_read_sql(final)


def test_stale_public_tfls_detects_removed():
    final = "out.demo_ads"                       # synthetic FQN (see test_release_pointer_and_swap_plan)
    existing = [release.public_tfl(final, t) for t in ("t1", "t3_old")]
    # the current release produces only t1 -> t3_old's public view is now stale (a spec dropped it)
    assert release.stale_public_tfls(existing, final, ["t1"]) == [release.public_tfl(final, "t3_old")]
    assert release.stale_public_tfls(existing, final, ["t1", "t3_old"]) == []   # all current -> none stale
    assert release.stale_public_tfls([], final, ["t1"]) == []                   # clean schema -> none


if __name__ == "__main__":
    fns = [v for k, v in sorted(globals().items()) if k.startswith("test_")]
    for fn in fns:
        fn()
        print(f"ok  {fn.__name__}")
    print(f"\n{len(fns)} tests passed")
