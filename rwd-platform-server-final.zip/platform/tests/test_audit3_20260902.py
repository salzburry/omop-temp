"""Regressions for the THIRD external audit of 2026-09-02 (main @ baaf389). Each fails on the
defect it names and passes on the fix.

  P1  one fullmatch validator: `safe_id\\n` passed a `$`-anchored match(); run.output_table was
      unchecked and reached CREATE OR REPLACE VIEW; staging_ads composed a traversal name
  P1  the golden gate passed n_rows.new = NaN and crashed on malformed containers
  P1  strict validation accepted REPLACE_ME on observation_end / data_cutoff
  P1  CI version guard: a VERSION-only diff skipped the comparison; skill guard accepted 1.0.00
  P2  cohorts=[1] / source_union=[] raised; derived_cohorts=[1] was suppressed
  P2  per-run usage totals were process-global (concurrency-unsafe); resume path omitted them
  P2  run-state save truncated the previous record before a failing dump
  P2  drift turned unreadable date evidence into "no drift"
  P2  experiment discovery globbed `2026*.json`
  P2  MCP wrong-shaped params became -32603; non-numeric Content-Length was not a 400
  P2  committed `superseded` receipts were refused although documented

NO PYTEST FIXTURES AND NO `parametrize` — CI runs every suite as a script.
"""
import copy
import json
import math
import os
import sys
import tempfile
import threading
from pathlib import Path

FRAMEWORK = Path(__file__).resolve().parent.parent
ROOT = FRAMEWORK.parent
sys.path.insert(0, str(FRAMEWORK))
sys.path.insert(0, str(FRAMEWORK / "tools"))

from engine.config import load_config, product_config  # noqa: E402
from engine import validate, refresh, golden, release  # noqa: E402

CONFIG = product_config(ROOT / "fixtures", "prostate")
AGENT = ROOT / "experiments" / "agent"


def _cfg(run=None, study=None):
    cfg = copy.deepcopy(load_config(CONFIG))
    cfg.run.update(run or {})
    cfg.study.update(study or {})
    return cfg


# ------------------------------------------------------------------ P1 one fullmatch validator

def test_trailing_newline_is_not_a_safe_identifier():
    for kind in ("sql", "path", "dotted"):
        assert refresh.unsafe_identifier(kind, "safe_id\n"), kind
    assert refresh.unsafe_identifier("sql", "safe_id") is None


def test_output_table_injection_is_refused_at_ingress():
    probs = validate.problems(_cfg(run={"output_table": "ads; DROP TABLE x --"}), strict=True)
    assert any("run.output_table" in p for p in probs), probs


def test_view_sql_and_staging_composers_refuse_unsafe_names():
    for fn, args in ((release.staging_ads, ("out.ads", "../../evil")),
                     (release.view_swap_sql, ("out.ads; DROP TABLE x --", "out.ads__2026q1__b1")),
                     (release.view_swap_sql, ("out.ads", "x/../y")),
                     (release.public_tfl, ("out.ads", "t-1"))):
        try:
            fn(*args)
        except ValueError as e:
            assert "refusing" in str(e), (fn.__name__, e)
        else:
            raise AssertionError(f"{fn.__name__}{args} composed an unsafe name")
    assert release.staging_ads("out.ads", "b0001") == "out.ads__staging__b0001"
    assert "CREATE OR REPLACE VIEW out.ads AS" in release.view_swap_sql("out.ads", "out.ads__2026q1__b1")


# ------------------------------------------------------------------ P1 golden gate evidence

def test_nan_row_count_fails_the_gate():
    r = golden.golden_gate({"n_rows": {"new": float("nan"), "ref": 100}})
    assert not r["passed"] and any("n_rows.new" in f for f in r["failures"]), r


def test_malformed_containers_fail_instead_of_raising():
    for summ, thr in (({"n_rows": {"new": 100, "ref": 100}}, ["not", "a", "dict"]),
                      ({"n_rows": "wrong"}, None),
                      ({"n_rows": {"new": 100, "ref": 100}, "cohort_counts": {"C1": 5}}, None),
                      ({"n_rows": {"new": 100, "ref": 100}, "distributions": {"ecog": {"0": "x"}}}, None),
                      ({"n_rows": {"new": 100, "ref": 100}, "os_summary": {"new": {"median": "12"}}}, None)):
        r = golden.golden_gate(summ, thr)
        assert not r["passed"] and r["failures"], (summ, thr, r)


def test_healthy_evidence_still_passes():
    r = golden.golden_gate({"n_rows": {"new": 101, "ref": 100},
                            "cohort_counts": {"C1": {"pct": 1.0}},
                            "distributions": {"ecog": {"0": {"ref": 40, "pct": 2.0}}},
                            "os_summary": {"new": {"median": 12.0}, "ref": {"median": 12.5}}})
    assert r["passed"], r


# ------------------------------------------------------------------ P1 placeholders on all dates

def test_placeholder_on_any_temporal_field_is_refused_in_strict_mode():
    for k in ("observation_end", "data_cutoff", "index_period_start", "index_period_end"):
        probs = validate.problems(_cfg(study={k: "REPLACE_ME"}), strict=True)
        assert any(k in p and "placeholder" in p for p in probs), (k, probs)
    # lint mode still tolerates the template's placeholders
    assert not [p for p in validate.problems(_cfg(study={"data_cutoff": "REPLACE_ME"}), strict=False)
                if "data_cutoff" in p and "placeholder" in p]


# ------------------------------------------------------------------ P1 CI version guards

def test_version_guard_considers_version_only_diffs_and_strict_semver():
    wf = (ROOT / ".github" / "workflows" / "rwdp-ci.yml").read_text(encoding="utf-8")
    assert 'VDIFF=$(git diff --name-only "$BASE"...HEAD -- platform/VERSION' in wf
    assert '[ -z "$RUNTIME" ] && [ -z "$VDIFF" ]' in wf, "a VERSION-only diff must reach the compare"
    assert wf.count(r"(0|[1-9]\d*)\.(0|[1-9]\d*)\.(0|[1-9]\d*)") >= 2, \
        "both guards parse SemVer 2.0.0 (no leading zeroes)"
    assert "| sort -V" not in wf, "the skill guard must not compare versions with sort -V"


# ------------------------------------------------------------------ P2 malformed config shapes

def test_malformed_config_shapes_are_problems_not_exceptions():
    for key, bad in (("cohorts", [1]), ("source_union", []), ("derived_cohorts", [1])):
        cfg = copy.deepcopy(load_config(CONFIG))
        cfg.raw[key] = bad
        probs = validate.problems(cfg, strict=False)      # must not raise
        assert any(key in p and "must be a" in p for p in probs), (key, probs)


# ------------------------------------------------------------------ P2 usage totals per run

def test_run_usage_accumulator_is_context_scoped():
    sys.path.insert(0, str(AGENT))
    import orchestrator as orc  # noqa: PLC0415
    seen = {}

    def one_run(tag):
        acc = orc._new_usage_acc()
        orc._RUN_USAGE.set(acc)
        for _ in range(1 if tag == "a" else 3):
            for a in (orc.AnthropicModel.TOTAL, orc._RUN_USAGE.get()):
                a["calls"] += 1
        seen[tag] = orc._RUN_USAGE.get()["calls"]

    ta, tb = threading.Thread(target=one_run, args=("a",)), threading.Thread(target=one_run, args=("b",))
    ta.start(); tb.start(); ta.join(); tb.join()
    assert seen == {"a": 1, "b": 3}, seen
    src = (AGENT / "orchestrator.py").read_text(encoding="utf-8")
    assert src.count("_RUN_USAGE.set(acc)") == 2, "run() AND resume_run() install an accumulator"


# ------------------------------------------------------------------ P2 atomic save

def test_failed_serialisation_keeps_the_previous_record():
    sys.path.insert(0, str(AGENT))
    import state  # noqa: PLC0415
    saved = state.RUNS
    try:
        with tempfile.TemporaryDirectory() as d:
            state.RUNS = d
            st = state.RunState("goal", run_id="atomic-test")
            st.record("decision", decision={"action": "done"})
            before = Path(st.path).read_text(encoding="utf-8")
            st.steps.append({"n": 2, "kind": "decision", "decision": object()})   # unserialisable
            try:
                st.save()
            except TypeError:
                pass
            else:
                raise AssertionError("expected json to refuse an object()")
            assert Path(st.path).read_text(encoding="utf-8") == before, "record was truncated"
            assert json.loads(before)["run_id"] == "atomic-test"
    finally:
        state.RUNS = saved


# ------------------------------------------------------------------ P2 drift: unreadable dates

def test_unreadable_date_evidence_is_a_finding():
    sys.path.insert(0, str(AGENT / "ml"))
    import drift  # noqa: PLC0415
    import profile_io  # noqa: PLC0415
    real = profile_io.load
    old = {"t": {"d": {"top_values": "", "pct_missing": 0, "date_min": "2015-01-01", "date_max": "2020-01-01"}}}
    new = {"t": {"d": {"top_values": "", "pct_missing": 0, "date_min": "garbage", "date_max": ""}}}
    try:
        profile_io.load = lambda p: (old if p == "OLD" else new, None)
        f = drift.compare("OLD", "NEW")
    finally:
        profile_io.load = real
    assert any("unreadable" in x[2] for x in f), f


# ------------------------------------------------------------------ P2 discovery does not expire

def test_no_year_literal_globs_in_experiment_discovery():
    hits = []
    for p in (AGENT / "evals" / "run.py", AGENT / "ml" / "features.py", AGENT / "ml" / "escalation_net.py"):
        if "2026*" in p.read_text(encoding="utf-8"):
            hits.append(p.name)
    assert not hits, hits


# ------------------------------------------------------------------ P2 MCP invalid params

def test_wrong_shaped_params_are_invalid_params_not_internal_error():
    import mcp_server  # noqa: PLC0415
    r = mcp_server._handle({"jsonrpc": "2.0", "id": 1, "method": "tools/call", "params": ["nope"]})
    assert r["error"]["code"] == -32602, r
    r = mcp_server._handle({"jsonrpc": "2.0", "id": 2, "method": "tools/call",
                            "params": {"name": "search", "arguments": "not-a-dict"}})
    assert r["error"]["code"] == -32602, r


# ------------------------------------------------------------------ P2 superseded receipts

def test_superseded_is_an_accepted_committed_receipt_status():
    src = (FRAMEWORK / "tools" / "source_manifest.py").read_text(encoding="utf-8")
    assert 'st not in ("released", "superseded")' in src


# ------------------------------------------------------------------ P2 non-numeric length -> 400

def test_non_numeric_content_length_is_malformed():
    src = (ROOT / "app" / "serve.py").read_text(encoding="utf-8")
    i = src.index('int(self.headers.get("Content-Length")')
    tail = src[i:i + 300]
    assert "n = -1" in tail and "400" in src[i:i + 900], "non-numeric length must reach the 400 branch"


if __name__ == "__main__":
    fails = 0
    for name, fn in sorted(globals().items()):
        if name.startswith("test_") and callable(fn):
            try:
                fn()
                print(f"  ok   {name}")
            except Exception as e:  # noqa: BLE001
                fails += 1
                print(f"  FAIL {name}: {e}")
    print(f"{fails} failure(s)")
    sys.exit(1 if fails else 0)
