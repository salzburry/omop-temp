"""Reuse preserves mathematical meaning without automatically importing example values."""
from copy import deepcopy
from pathlib import Path
import sys

import pytest

ROOT = Path(__file__).resolve().parents[2]
sys.path[:0] = [str(ROOT / "experiments/portal"), str(ROOT / "platform/tools")]
import definition_reuse_logic as logic
import science_workspace as science


def record(derivation, source="{kind: derived}", executable=None):
    return {"derivation": derivation, "interpreted": [("Source table and field", source)],
            "executable": executable or [], "spec": {"rule": "Reference specification", "refs": ["study:1"]}}


@pytest.mark.parametrize("text", ["Use January 1, 2015.", "Keep observations after 2015-01-01.",
                                 "Cutoff: 01.01.2015.", "Use 01/01/2015."])
def test_calendar_literals_cannot_hide_before_sentence_ending_punctuation(text):
    assert logic._calendar_values(text)
    with pytest.raises(ValueError, match="calendar"):
        logic.validate(record(text), text, disposition="adapt", logic_reviewed=True)


def test_calendar_boundary_preserves_decimal_and_extended_numeric_sequences():
    assert not logic._calendar_values("Compute x / 365.25 + 1.")
    assert not logic._CALENDAR.search("2020.01.01.5")


@pytest.mark.parametrize("text", [
    "scalar literal cast to date; applied as (dcol >= start), inclusive",
    "datediff(end, start) + 1",
    "weight_kg / (height_m ** 2)",
    "datediff(index_date, birth_date) / 365.25",
])
def test_generic_logic_and_mathematical_constants_are_preserved(text):
    original = record(text)
    before = deepcopy(original)
    report = logic.describe(original)
    assert report == {"reusable_derivation": text, "reuse_readiness": "ready", "reuse_issues": []}
    assert original == before
    logic.validate(original, text, disposition="inherit")


def test_exact_declared_parameter_date_is_replaced_without_copying_configuration():
    original = record("Admit dates >= 2011-01-01, inclusive", "{kind: parameter, parameters: [study.index_start]}",
                      [("config/data_product.yaml#/study", {"index_start": "2011-01-01", "index_end": "2026-04-30"})])
    before = deepcopy(original)
    report = logic.describe(original)
    assert report["reuse_readiness"] == "ready"
    assert report["reusable_derivation"] == "Admit dates >= {{study.index_start}}, inclusive"
    assert original == before
    with pytest.raises(ValueError, match="displayed reusable logic"):
        logic.validate(original, original["derivation"], disposition="inherit")
    logic.validate(original, report["reusable_derivation"], disposition="inherit")


def test_explicit_constant_scalar_or_quoted_label_uses_parameter_token():
    assert logic.describe(record("2011-01-01", "{kind: constant, value: 2011-01-01}"))["reusable_derivation"] == "{{product_value}}"
    assert logic.describe(record('Set label to "Prostate dataset"', '{kind: constant, value: "Prostate dataset"}'))["reusable_derivation"] == "Set label to {{product_value}}"


@pytest.mark.parametrize("source,executable,token", [
    ("{kind: parameter, parameters: [study.index_start], value: 2011-01-01}", [], "{{study.index_start}}"),
    ("{kind: parameter, value: 2011-01-01}", [], "{{product_value}}"),
    ("{kind: parameter, parameters: [study.index_start], value: 2011-01-01}",
     [("config/data_product.yaml#/study", {"index_start": "2011-01-01"})], "{{study.index_start}}"),
])
def test_explicit_parameter_value_is_separated_without_duplicate_ambiguity(source, executable, token):
    report = logic.describe(record("Admit dates from 2011-01-01", source, executable))
    assert report["reuse_readiness"] == "ready", report
    assert report["reusable_derivation"] == "Admit dates from " + token


@pytest.mark.parametrize("text", ["Use dates from 2011-01-01", "Start at 01-Jan-11", "Cutoff 01/01/2011", "Set DATAV=20260630", "Use records since 2015", "Apply records since January 1, 2020", "Use records from Jan 1st 2020", "Data available from January 2020"])
def test_unmapped_calendar_values_need_edit_and_are_never_raw_fallback(text):
    original = record(text)
    report = logic.describe(original)
    assert report["reuse_readiness"] == "needs_edit" and report["reusable_derivation"] == ""
    assert original["derivation"] == text
    with pytest.raises(ValueError):
        logic.validate(original, text, disposition="inherit")
    with pytest.raises(ValueError, match="calendar dates"):
        logic.validate(original, text, disposition="adapt", logic_reviewed=True)


def test_new_target_date_also_belongs_in_target_value_fields():
    original = record("Use dates from 2011-01-01")
    with pytest.raises(ValueError, match="Edit this product's values"):
        logic.validate(original, "Use dates from 2015-01-01", disposition="adapt", logic_reviewed=True)
    with pytest.raises(ValueError, match="Review the logic"):
        logic.validate(original, "Use dates from {{study.index_start}}", disposition="adapt")
    logic.validate(original, "Use dates from {{study.index_start}}", disposition="adapt", logic_reviewed=True)


def test_ambiguous_timing_and_numeric_literals_require_review_without_deletion():
    original = record("Require sustained response for 30 days")
    assert logic.describe(original)["reuse_readiness"] == "needs_edit"
    with pytest.raises(ValueError, match="Review the logic"):
        logic.validate(original, original["derivation"], disposition="adapt")
    logic.validate(original, original["derivation"], disposition="adapt", logic_reviewed=True)
    math = record("x ** 2", "{kind: constant, value: 2}")
    assert logic.describe(math)["reusable_derivation"] == ""
    logic.validate(math, "x ** 2", disposition="adapt", logic_reviewed=True)


@pytest.mark.parametrize("text", ["age >= 18", "BMI < 30", "The minimum is 5", "Apply threshold of 12.5"])
def test_undeclared_comparison_cutoffs_need_explicit_scientific_review(text):
    original = record(text)
    assert logic.describe(original)["reuse_readiness"] == "needs_edit"
    with pytest.raises(ValueError, match="Choose adapt"):
        logic.validate(original, text, disposition="inherit")
    with pytest.raises(ValueError, match="Review the logic"):
        logic.validate(original, text, disposition="adapt")
    logic.validate(original, text, disposition="adapt", logic_reviewed=True)


@pytest.mark.parametrize("text", ["Require observable activity, e.g. at least two visits.",
    "For example, choose three prior visits.", "An illustrative baseline includes two observations."])
def test_worded_example_values_cannot_be_inherited_silently(text):
    original = record(text)
    assert logic.describe(original)["reuse_readiness"] == "needs_edit"
    with pytest.raises(ValueError, match="Choose adapt"):
        logic.validate(original, text, disposition="inherit")
    logic.validate(original, "Require the product's {{minimum_activity}}.", disposition="adapt", logic_reviewed=True)


def test_different_parameters_with_same_value_are_not_guessed():
    original = record("Use 2011-01-01", "{kind: parameter, parameters: [study.index_start, study.data_start]}",
                      [("config/data_product.yaml#/study", {"index_start": "2011-01-01", "data_start": "2011-01-01"})])
    assert logic.describe(original)["reuse_readiness"] == "needs_edit"
    assert logic.describe(original)["reusable_derivation"] == ""


@pytest.mark.parametrize("text", ["65", "65 is the minimum age", "Admit age >= 65"])
def test_review_checkbox_cannot_restore_declared_numeric_parameter_values(text):
    original = record("65", "{kind: parameter, parameters: [study.min_age]}",
                      [("config/data_product.yaml#/study", {"min_age": 65})])
    assert logic.describe(original)["reusable_derivation"] == "{{study.min_age}}"
    with pytest.raises(ValueError, match="scalar value|reference product's value"):
        logic.validate(original, text, disposition="adapt", logic_reviewed=True)


@pytest.mark.parametrize("source", ["{kind: constant}", "{kind: constant, value: ''}",
    "{kind: parameter, parameters: []}", "{kind: parameter, parameters: [study.label]}"])
@pytest.mark.parametrize("text", ["65", "PROSTATE_DATASET", '"PROSTATE_DATASET"'])
def test_unresolved_scalar_is_unknown_instead_of_reusable(source, text):
    original = record(text, source)
    assert logic.describe(original)["reuse_readiness"] == "needs_edit"
    assert logic.describe(original)["reusable_derivation"] == ""
    with pytest.raises(ValueError):
        logic.validate(original, text, disposition="inherit")
    with pytest.raises(ValueError, match="raw scalar value"):
        logic.validate(original, text, disposition="adapt", logic_reviewed=True)
    assert logic.describe(record("{{study.label}}", source))["reuse_readiness"] == "ready"
    logic.validate(original, "{{study.label}}", disposition="adapt", logic_reviewed=True)


@pytest.mark.parametrize("source", ["{kind: constant}", "{kind: parameter, parameters: [study.label]}"])
@pytest.mark.parametrize("label", ["Prostate dataset", "Prostate dataset-1"])
def test_unresolved_prose_label_cannot_be_treated_as_value_free(source, label):
    original = record(label, source)
    assert logic.describe(original)["reuse_readiness"] == "needs_edit"
    with pytest.raises(ValueError, match="identify its product value"):
        logic.validate(original, label, disposition="adapt", logic_reviewed=True)
    logic.validate(original, "Use this product's {{study.label}}.", disposition="adapt", logic_reviewed=True)
    assert logic.describe(record("Use x / 2 + 1", source))["reusable_derivation"] == "Use x / 2 + 1"


def test_stage_guard_requires_review_and_preserves_provenance(monkeypatch, tmp_path):
    root, pack = tmp_path, tmp_path / "products/oncology/test/202609"
    original = record("Select observations within 30 days")
    current = record("Current logic")
    candidate = {"key": "reference", "record": original, "pack": "fixtures/oncology/other/202609", "settled": True}
    monkeypatch.setattr(science, "_worker", lambda _request: {"candidates": [candidate]})
    common = {"variable": "BASELINE", "current": current, "item_id": "study:1"}
    values = {"candidate": "reference", "disposition": "adapt", "interpretation": "Select observations within {{baseline_window}}",
              "reason": "Reuse the nearest observation logic with this product's separate window."}
    with pytest.raises(ValueError, match="Review the logic"):
        science._stage_worker(root, pack, "definition_reuse", values, [], common)
    result = science._stage_worker(root, pack, "definition_reuse", {**values, "logic_reviewed": True}, [], common)
    assert result["artifact"]["source"] == original
    assert result["artifact"]["derivation"] == values["interpretation"]
    assert "30 days" in result["artifact"]["source"]["derivation"]


def test_old_proposal_is_rechecked_before_any_row_draft_is_changed(monkeypatch, tmp_path):
    import scientific_definitions
    pack = "products/oncology/test/202609"
    proposal = {"route": "definition_reuse", "input_digest": "same", "values": {
        "candidate": "reference", "disposition": "inherit", "interpretation": "Use dates from 2011-01-01"},
        "artifact": {"derivation": "Use dates from 2011-01-01"}, "next": {"route": "scientific_draft"}}
    target = {"ok": True, "proposal": proposal, "draft_digest": "draft", "input_digest": "input",
              "selected": {"item_id": "study:1"}, "values": {"derivation": "Target", "source": {"value": "2015-01-01"}}}
    monkeypatch.setattr(science, "draft_target", lambda *args, **kwargs: target)
    monkeypatch.setattr(science, "_scope", lambda *args: (tmp_path, pack, "owner", tmp_path, {pack}))
    monkeypatch.setattr(science, "_inputs", lambda *args: {})
    monkeypatch.setattr(science, "_digest", lambda *args: "same")
    calls = []
    def fresh_check(files, request):
        calls.append(request)
        return {"errors": ["This legacy interpretation contains reference product values. Edit the reusable logic."]}
    monkeypatch.setattr(science, "_run", fresh_check)
    monkeypatch.setattr(scientific_definitions, "save_draft", lambda *args, **kwargs: pytest.fail("A refused legacy proposal must not write a draft"))
    result = science.use_in_draft(tmp_path, pack, "owner", "old-proposal", expected_draft_digest="draft", local_demo=True, can_write=True)
    assert not result["ok"] and "legacy interpretation" in result["errors"][0]
    assert calls[0]["operation"] == "stage" and calls[0]["values"] == proposal["values"]
    assert target["values"] == {"derivation": "Target", "source": {"value": "2015-01-01"}}


def test_reference_change_during_copy_validation_preserves_target_draft(monkeypatch, tmp_path):
    import scientific_definitions
    pack = "products/oncology/test/202609"
    files = {"reference": b"original evidence"}
    proposal = {"route": "definition_reuse", "input_digest": science._digest(files),
                "values": {"candidate": "reference", "disposition": "inherit", "interpretation": "Generic logic"},
                "artifact": {"derivation": "Generic logic"}, "next": {"route": "scientific_draft"}}
    target = {"ok": True, "proposal": proposal, "draft_digest": "draft", "input_digest": "input",
              "selected": {"item_id": "study:1"}, "values": {"derivation": "Target", "source": {"value": "2015-01-01"}}}
    monkeypatch.setattr(science, "draft_target", lambda *args, **kwargs: target)
    monkeypatch.setattr(science, "_scope", lambda *args: (tmp_path, pack, "owner", tmp_path, {pack}))
    monkeypatch.setattr(science, "_inputs", lambda *args: dict(files))
    def reference_changes(_files, _request):
        files["reference"] = b"changed while the worker checked"
        return {"errors": [], "artifact": {"derivation": "Generic logic"}}
    monkeypatch.setattr(science, "_run", reference_changes)
    monkeypatch.setattr(scientific_definitions, "save_draft", lambda *args, **kwargs: pytest.fail("Changed source evidence must not be copied"))
    result = science.use_in_draft(tmp_path, pack, "owner", "proposal", expected_draft_digest="draft", local_demo=True, can_write=True)
    assert not result["ok"] and "changed while checking" in result["errors"][0]
    assert target["values"]["derivation"] == "Target"
