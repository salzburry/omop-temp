"""Guided question drafting never supplies an unrequested scientific ruling."""
from pathlib import Path
import sys

import pytest

ROOT = Path(__file__).resolve().parents[2]
sys.path[:0] = [str(ROOT / "platform/tests"), str(ROOT / "experiments/portal"), str(ROOT / "platform/tools")]
import decision_answer_choices as choices
import decision_answers as answers
from test_epi_decision_answer_page import _page, _bytes, _fill, _select, _save, _statuses, VALUES
from test_epi_portal_journeys import _healthy

QUESTION = 'For a nonexistent line, is the LOT category null or 17 "No treatment"?'


def test_choices_quote_only_the_exact_question_and_never_reuse_an_identifier_or_changed_meaning():
    guide = choices.describe(QUESTION)
    assert guide["alternatives"] == ['null', '17 "No treatment"']
    assert all(phrase in QUESTION for phrase in guide["alternatives"])
    # A changed wording no longer matches the checked table; its choices come from its own words
    # only (DL-11), so nothing from the original question's alternatives is reused by identifier.
    reworded = QUESTION.replace("nonexistent", "existing")
    changed = choices.describe(reworded)
    assert changed["alternatives"] and all(phrase in reworded for phrase in changed["alternatives"])
    assert choices.describe("Do delivered physical names match the target published names?")["alternatives"] == ["Yes", "No"]
    assert {choices.COMPLETE, choices.PARTS} <= set(changed["options"])
    assert all(answers.unresolved_answer(value) for label, value in guide["options"].items() if not label.startswith("Consider: "))
    assert all(answers.unresolved_answer(value) for label, value in changed["options"].items() if not label.startswith("Consider: "))


@pytest.mark.parametrize("question,expected", [
    ("Should the baseline window be 30 days or 60 days?", ["30 days", "60 days"]),
    ("Closest assessment vs earliest assessment within the window?", ["Closest assessment", "earliest assessment"]),
    ("Progression boundary `> index+14` versus `>= index+14`?", ["> index+14", ">= index+14"]),
    ("Should the index be either the first prescription or the first administration?", ["first prescription", "first administration"]),
    ("Is the follow-up end published, internal-only, or removed?", ["published", "internal-only", "removed"]),
    ("Keep or drop TRTDIS?", ["Keep", "drop"]),
    ("Is the death date capped at study end?", ["Yes", "No"]),
    ("Which assessment date?", []),
    ("How should the end of follow-up be defined?", []),
])
def test_choices_are_derived_from_the_questions_own_wording_for_any_pack(question, expected):
    """DL-11: the choices were hard-coded to one fixture's wordings; every other pack saw none."""
    guide = choices.describe(question)
    assert guide["alternatives"] == expected, guide
    assert all(phrase in question or phrase in ("Yes", "No") for phrase in guide["alternatives"])
    assert guide["kind"] == ("alternatives" if expected else "open")
    assert all(answers.unresolved_answer(value) for label, value in guide["options"].items() if not label.startswith("Consider: "))


def test_the_checked_table_overrides_derivation_for_wordings_a_person_has_reviewed():
    # The derivation reads the fixture question as 'LOT category null' or '17 "No treatment"'; the
    # table a person checked says 'null'. The checked wording wins, and a compound wording stays
    # compound rather than becoming one partial choice.
    derived = choices.derived_alternatives(QUESTION)
    assert derived and derived != choices.describe(QUESTION)["alternatives"]
    compound = 'Window (`[-30,+7]` vs any-time-before-index) and date basis (specimen-collected vs -received)'
    guide = choices.describe(compound)
    assert guide["kind"] == "compound" and not guide["alternatives"]


def test_a_derived_choice_starts_an_unfinished_answer_on_the_page():
    with _page(question="Should the baseline window be 30 days or 60 days?") as (at, case):
        before = _bytes(case.root)
        dropdown = at.selectbox(key="decision_answer_Q1_approach")
        assert dropdown.value is None
        assert "Consider: 30 days" in dropdown.options and "Consider: 60 days" in dropdown.options
        dropdown.set_value("Consider: 60 days").run()
        _healthy(at)
        assert at.text_area(key="decision_answer_Q1_answer").value == ""
        assert at.button(key="decision_answer_Q1_use_choice").disabled
        assert at.button(key="decision_answer_save").disabled
        assert _bytes(case.root) == before and _statuses(case)["Q1"] == "OPEN"


@pytest.mark.parametrize("question,expected", [
    ("Should missing progression dates be not excluded or imputed from the next recorded visit?",
     ["not excluded", "imputed from the next recorded visit"]),
    ("Should the window be 30 days (inclusive) or 60 days (exclusive)?",
     ["30 days (inclusive)", "60 days (exclusive)"]),
    ("Should the index be either the first documented prescription or the earliest confirmed administration after diagnosis?",
     ["first documented prescription", "earliest confirmed administration after diagnosis"]),
])
def test_derived_choices_preserve_negation_and_complete_scientific_qualifiers(question, expected):
    guide = choices.describe(question)
    assert guide["alternatives"] == expected
    assert all(phrase in question for phrase in expected)
    assert all(answers.unresolved_answer(value) for label, value in guide["options"].items() if not label.startswith("Consider: "))


@pytest.mark.parametrize("question", [
    "First confirmed progressive disease vs first assessment?",
    "Observed progression date vs imputed next visit date?",
    "Should the window be [-30,+7] or [-60,+7]?",
    "Should death count as progression? How should missing dates be handled?",
    "Should progression be observed or imputed, and how should ties be resolved?",
    "`Collected` vs `received` and `earliest` vs `latest`?",
])
def test_ambiguous_or_compound_wording_does_not_offer_a_truncated_ruling(question):
    guide = choices.describe(question)
    assert not guide["alternatives"], guide
    assert choices.COMPLETE in guide["options"] and choices.PARTS in guide["options"]


def test_the_page_keeps_a_qualifier_in_its_choice_and_never_saves_the_starting_point():
    question = "Should missing progression dates be not excluded or imputed from the next recorded visit?"
    with _page(question=question) as (at, case):
        before = _bytes(case.root)
        dropdown = at.selectbox(key="decision_answer_Q1_approach")
        assert "Consider: not excluded" in dropdown.options
        assert "Consider: excluded" not in dropdown.options
        dropdown.set_value("Consider: imputed from the next recorded visit").run()
        _healthy(at)
        assert at.text_area(key="decision_answer_Q1_answer").value == ""
        assert at.button(key="decision_answer_Q1_use_choice").disabled
        assert at.button(key="decision_answer_save").disabled
        assert _bytes(case.root) == before and _statuses(case)["Q1"] == "OPEN"


def test_compound_questions_have_separate_unanswered_parts_instead_of_a_single_inferred_answer():
    guide = choices.describe('Window (`[-30,+7]` vs any-time-before-index) and date basis (specimen-collected vs -received)')
    assert guide["kind"] == "compound" and not guide["alternatives"]
    assert "Window: TODO" in guide["options"][choices.PARTS]
    assert "Date basis: TODO" in guide["options"][choices.PARTS]
    matrix = choices.describe(choices._MATRIX)
    assert "each C1–C7 cohort" in matrix["options"][choices.PARTS]
    assert "C7 next-treatment source: TODO" in matrix["options"][choices.PARTS]
    assert "No qualifying next treatment observed: TODO" in matrix["options"][choices.PARTS]


@pytest.mark.parametrize("question", [QUESTION, "Which assessment date?", "How should a novel compound requirement be defined?"])
def test_every_question_has_unselected_guidance_custom_text_and_not_sure(question):
    with _page(question=question) as (at, case):
        before = _bytes(case.root)
        dropdown = at.selectbox(key="decision_answer_Q1_approach")
        assert dropdown.value is None
        assert choices.CUSTOM in dropdown.options and choices.UNSURE in dropdown.options
        assert choices.COMPLETE in dropdown.options and choices.PARTS in dropdown.options
        assert at.text_area(key="decision_answer_Q1_answer").value == ""
        assert at.text_input(key="decision_answer_Q1_answered_by").value == ""
        assert at.text_input(key="decision_answer_Q1_answer_date").value == ""
        assert _bytes(case.root) == before


def test_custom_answer_survives_guided_and_not_sure_choices_and_question_navigation():
    with _page(question=QUESTION) as (at, case):
        before = _bytes(case.root)
        at.text_area(key="decision_answer_Q1_answer").set_value("My literal custom interpretation.").run()
        at.selectbox(key="decision_answer_Q1_approach").set_value(choices.PARTS).run()
        assert at.text_area(key="decision_answer_Q1_answer").value.startswith("TODO")
        at.selectbox(key="decision_answer_Q1_approach").set_value(choices.CUSTOM).run()
        assert at.text_area(key="decision_answer_Q1_answer").value == "My literal custom interpretation."
        at.selectbox(key="decision_answer_Q1_approach").set_value(choices.UNSURE).run()
        assert "Not sure yet" in at.text_area(key="decision_answer_Q1_answer").value
        assert at.button(key="decision_answer_save").disabled
        _select(at, "Q2")
        _select(at, "Q1")
        assert "Not sure yet" in at.text_area(key="decision_answer_Q1_answer").value
        at.selectbox(key="decision_answer_Q1_approach").set_value(choices.CUSTOM).run()
        assert at.text_area(key="decision_answer_Q1_answer").value == "My literal custom interpretation."
        assert _bytes(case.root) == before and case.saved == 0


def test_quoted_choice_stays_unresolved_until_human_edits_then_records_it_explicitly():
    with _page(question=QUESTION) as (at, case):
        before = _bytes(case.root)
        at.selectbox(key="decision_answer_Q1_approach").set_value('Consider: null').run()
        for field in ("answered_by", "answer_date"):
            at.text_input(key=f"decision_answer_Q1_{field}").set_value(VALUES[field])
        at.run()
        assert at.button(key="decision_answer_save").disabled
        assert _statuses(case)["Q1"] == "OPEN" and _bytes(case.root) == before
        at.text_area(key="decision_answer_Q1_answer").set_value("For nonexistent lines the LOT category is null; existing treatment rows follow their separate category rule.").run()
        assert not at.button(key="decision_answer_save").disabled
        _save(at)
        assert _statuses(case)["Q1"] == "RESOLVED" and case.saved == 1


def test_preparing_missing_forms_keeps_question_open_and_honors_the_requested_question():
    with _page(issue_forms=False, initial_decision_id="Q2") as (at, case):
        assert at.button(key="decision_answer_prepare")
        assert not any(box.key == "decision_answer_selected" for box in at.selectbox)
        register = (case.product / "handoff/DECISIONS.md").read_bytes()
        at.button(key="decision_answer_prepare").click().run()
        _healthy(at)
        assert at.selectbox(key="decision_answer_selected").value == "Q2"
        assert at.text_area(key="decision_answer_Q2_answer").value == ""
        assert at.text_input(key="decision_answer_Q2_answered_by").value == ""
        assert at.text_input(key="decision_answer_Q2_answer_date").value == ""
        assert _statuses(case) == {"Q1": "OPEN", "Q2": "OPEN"}
        assert (case.product / "handoff/DECISIONS.md").read_bytes() == register


@pytest.mark.parametrize("mode", ["readonly", "hosted", "actor_switch"])
def test_preparation_uses_the_current_write_and_identity_context(mode):
    with _page(issue_forms=False, can_write=mode != "readonly", local_demo=mode != "hosted") as (at, case):
        before = _bytes(case.root)
        if mode == "actor_switch":
            case.actor = "Another scientist"
        at.button(key="decision_answer_prepare").click().run()
        _healthy(at)
        assert _bytes(case.root) == before and case.saved == 0
