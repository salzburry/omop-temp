"""Paired evaluator regression with real disposable evidence and scripted model arms."""
import copy
import json
from pathlib import Path
import shutil
import sys
from types import SimpleNamespace

import pytest

ROOT = Path(__file__).resolve().parents[2]
sys.path[:0] = [str(ROOT / p) for p in ('experiments/portal', 'experiments/agent', 'platform/tools', 'platform/tests')]
import correction_evaluation as pairs
import workflow_skills as skills
import workflow_improvement as improvement
import model_lifecycle_workspace as lifecycle
import model_lifecycle_runtime as runtime
from test_epi_scientific_definitions import fixture as product_fixture

ACTOR = 'paired-test-reviewer'
CONNECTION = {'ok': True, 'provider': 'Scripted VS Code test connection', 'provider_id': 'vscode',
              'model': 'gpt-5-mini', 'connection_id': 'a' * 64, 'errors': [], 'help': 'Test connection; no live calls.'}


@pytest.fixture
def setup(tmp_path, monkeypatch):
    root, pack, product, _ = product_fixture(tmp_path)
    shutil.copytree(ROOT / '.claude/skills', root / '.claude/skills')
    for selector in skills.learning().DEFAULT_TESTS['operate-rwd-product']:
        path = root / selector
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text('def test_scripted_software_regression():\n    assert True\n', encoding='utf-8')
    # Real case/source eligibility stays enabled; only connection metadata and
    # the finite corpus are scripted, so no installed provider is inspected.
    extras = [{'case': {'id': 'paired-extra-' + str(index), 'goal': 'Explain the progress check and return action ' + str(index),
        'expect': {'outcome': ['done', 'escalated'], 'must_not_claim': ['already approved']},
        'adjudicate': 'Compare the exact returned workflow action.', 'provenance': 'generated',
        'split': split}, 'packs': [pack]} for index, split in enumerate(('development', 'heldout'))]
    monkeypatch.setattr(lifecycle, 'case_options', lambda *a, **k:
        {'ok': True, 'cases': copy.deepcopy(extras), 'connection': copy.deepcopy(CONNECTION), 'corpus_digest': 'b' * 64})
    draft = improvement.propose(root, ACTOR, 'progress',
        'The progress check loses the selected return action.',
        'Keep the progress return action after checking the current status.',
        'General progress check and return navigation.',
        'Explain the progress check and return action.', confirmed=True, can_write=True)
    with monkeypatch.context() as check_patch:
        check_patch.setattr(skills.learning().subprocess, 'run', lambda *a, **k: SimpleNamespace(returncode=0))
        checked = improvement.check(root, ACTOR, draft['id'], draft['tests'], expected_digest=draft['digest'], confirmed=True, can_review=True)
    assert checked['status'] == 'checked'
    assert not pairs.specialists._eligibility(root, pack)
    return SimpleNamespace(root=root, pack=pack, product=product, target=checked, extras=extras)


def preview(value, cases=None):
    options = pairs.options(value.root, value.pack, ACTOR, value.target['id'], allowed_packs=[value.pack])
    assert options['ok'] and options['ready'], options
    result = pairs.preview(value.root, value.pack, ACTOR, value.target['id'], cases or [],
        expected_digest=options['digest'], allowed_packs=[value.pack])
    assert result['ok'], result
    return result


def scripted_arm(proposal, row, include_target, remaining_seconds=360):
    root = Path(proposal['root'])
    with skills.evaluation_corrections(root, record_id=proposal['correction']['id'],
            expected_digest=proposal['correction']['digest'], include_target=include_target,
            expected_library_digest=proposal['library_digest']) as delivery:
        skills.reviewed_corrections(root, 'progress', query=row['case']['goal'], task_scope={'packs': [proposal['pack']]})
        observations = copy.deepcopy(delivery)
    run_id = row['case']['id'] + ('-after' if include_target else '-before')
    summary = 'Return to the current progress check.' if include_target else 'The product is already approved.'
    run = {'run_id': run_id, 'goal': row['case']['goal'], 'actor': {'name': proposal['actor_id']},
        'model_id': CONNECTION['model'], 'metrics': {'total_calls': 1, 'calls': 1, 'latency_s': 1.0,
            'cost_usd': None, 'total_cost_usd': None}, 'primary_pack': proposal['pack'],
        'steps': [{'kind': 'decision', 'content': summary}], 'outcome': {'status': 'done', 'summary': summary}}
    run['execution'] = runtime.receipt(run, {'mode': 'canonical_case_evaluation', 'pack': proposal['pack'],
        'provider': 'vscode', 'source_digest': proposal['input_digests'][proposal['pack']],
        'successful_calls': 1, 'calls': [{'request': 'c' * 64, 'response': 'd' * 64}]})
    result = lifecycle._case_runner().score(row['case'], SimpleNamespace(**run))
    result['error'] = None
    runs = [{'run': run, 'sha256': runtime.digest(run)}]
    return {'result': result, 'runs': runs, 'outputs': pairs._outputs(runs), 'delivery': observations,
            'elapsed_seconds': 1.0, 'excerpted_calls': 0, 'error': None, 'stale': False}


def run(value, proposal, **overrides):
    args = {'confirmed': True, 'local_demo': True, 'can_review': True, 'allowed_packs': [value.pack]}
    args.update(overrides)
    return pairs.run(value.root, value.pack, ACTOR, proposal, **args)


def test_checked_correction_and_own_familiar_case_preview_do_not_activate_or_run(setup, monkeypatch):
    monkeypatch.setattr(pairs, '_execute_arm', lambda *a: pytest.fail('preview made a model call'))
    proposal = preview(setup)
    assert len(proposal['cases']) == 1 and proposal['cases'][0]['case']['familiar_example']
    assert proposal['before_ids'] == [] and proposal['after_ids'] == [setup.target['id']]
    assert proposal['correction']['status'] == 'checked'
    assert skills.learning().read_correction(setup.root, setup.target['id'])['status'] == 'checked'


@pytest.mark.parametrize('selection', [['unknown-case'], ['paired-extra-0', 'paired-extra-0'],
                                     ['paired-extra-0', 'paired-extra-1', 'unknown-case']])
def test_unknown_duplicate_or_excess_cases_are_refused(setup, selection):
    result = pairs.preview(setup.root, setup.pack, ACTOR, setup.target['id'], selection, allowed_packs=[setup.pack])
    assert not result['ok']


def test_pair_uses_canonical_scores_exact_outputs_delivery_and_idempotent_receipts(setup, monkeypatch):
    requests = []
    def execute(proposal, row, enabled, remaining):
        requests.append((row['case']['goal'], enabled, proposal['connection'], proposal['limits'], proposal['input_digests']))
        return scripted_arm(proposal, row, enabled, remaining)
    monkeypatch.setattr(pairs, '_execute_arm', execute)
    before_inputs = pairs.specialists.science._digest(pairs.specialists._inputs(setup.root, setup.pack))
    proposal = preview(setup, ['paired-extra-0', 'paired-extra-1'])
    result = run(setup, proposal)
    assert result['ok'], result
    assert len(requests) == 6 and len(result['pairs']) == 3
    assert all(requests[i][0] == requests[i + 1][0] and requests[i][2:] == requests[i + 1][2:] for i in (0, 2, 4))
    for pair in result['pairs']:
        assert pair['comparison']['valid_pair'] and pair['comparison']['semantic_improvement'] is None
        assert 'already approved' in pair['before']['outputs'][0]['outcome']['summary']
        assert 'Return to' in pair['after']['outputs'][0]['outcome']['summary']
        assert pair['comparison']['metrics']['total_cost_usd']['delta'] is None
    assert result['pairs'][0]['before']['result']['passed'] and result['pairs'][0]['after']['result']['passed']
    assert result['pairs'][1]['comparison']['checks']['never:already approved'] == {'before': False, 'after': True}
    assert not result['training_eligible'] and not result['adjudicated'] and result['semantic_improvement'] is None
    loaded = pairs.read(setup.root, setup.pack, ACTOR, result['id'], allowed_packs=[setup.pack])
    assert loaded['ok'] and not loaded['stale']
    assert run(setup, proposal)['id'] == result['id'] and len(requests) == 6
    assert skills.learning().read_correction(setup.root, setup.target['id'])['status'] == 'checked'
    assert before_inputs == pairs.specialists.science._digest(pairs.specialists._inputs(setup.root, setup.pack))
    assert pairs.recent(setup.root, setup.pack, ACTOR, allowed_packs=[setup.pack])[0]['route'] == 'model_lifecycle'


@pytest.mark.parametrize('change', ['actor', 'model', 'source', 'software', 'library', 'scope', 'case'])
def test_frozen_preview_changes_refuse_every_model_call(setup, monkeypatch, change):
    proposal = preview(setup)
    monkeypatch.setattr(pairs, '_execute_arm', lambda *a: pytest.fail('stale input reached a model'))
    if change == 'actor':
        proposal['actor_id'] = 'different-reviewer'
    elif change == 'model':
        proposal['connection']['model'] = 'different-model'
    elif change == 'source':
        path = setup.product / 'config/data_product.yaml'
        path.write_text(path.read_text() + '\n# changed source configuration\n')
    elif change == 'software':
        (setup.root / setup.target['tests'][0]).write_text('# changed registered software\n')
    elif change == 'library':
        improvement.propose(setup.root, ACTOR, 'progress', 'Another error.', 'Another correction.',
            'Another general workflow.', 'Explain another progress check.', confirmed=True, can_write=True)
    elif change == 'scope':
        proposal['allowed_packs'] = []
    else:
        proposal['cases'][0]['case']['goal'] += ' Changed.'
    assert not run(setup, proposal)['ok']


@pytest.mark.parametrize('mode', ['not_delivered', 'wrong_skill', 'truncated', 'failed', 'baseline_leak', 'stale'])
def test_incomplete_or_unexercised_pair_never_claims_a_gain(setup, monkeypatch, mode):
    def execute(proposal, row, enabled, remaining):
        arm = scripted_arm(proposal, row, enabled, remaining)
        if enabled and mode == 'not_delivered':
            arm['delivery'] = [{'skill': setup.target['skill'], 'ids': []}]
        if mode == 'wrong_skill':
            arm['delivery'] = [{'skill': 'draft-contract-record', 'ids': []}]
        if enabled and mode == 'truncated':
            arm['excerpted_calls'] = 1
        if enabled and mode == 'failed':
            arm['error'] = 'A fixed test failure.'
        if not enabled and mode == 'baseline_leak':
            arm['delivery'] = [{'skill': setup.target['skill'], 'ids': [setup.target['id']]}]
        if enabled and mode == 'stale':
            arm['stale'] = True
        return arm
    monkeypatch.setattr(pairs, '_execute_arm', execute)
    result = run(setup, preview(setup))
    assert result['ok'], result
    comparison = result['pairs'][0]['comparison']
    assert not comparison['valid_pair'] and comparison['inconclusive_reasons']
    assert comparison['semantic_improvement'] is None


def test_source_gate_is_required_before_preview_or_inference(setup, monkeypatch):
    monkeypatch.setattr(pairs.specialists, '_eligibility', lambda *a: 'Source review required')
    monkeypatch.setattr(pairs, '_execute_arm', lambda *a: pytest.fail('unreviewed source reached a model'))
    report = pairs.options(setup.root, setup.pack, ACTOR, setup.target['id'], allowed_packs=[setup.pack])
    assert report['ok'] and not report['ready']
    assert not pairs.preview(setup.root, setup.pack, ACTOR, setup.target['id'], [], allowed_packs=[setup.pack])['ok']


def test_interrupted_request_retains_completed_side_and_never_retries_unknown_call(setup, monkeypatch):
    calls = []
    def execute(proposal, row, enabled, remaining):
        calls.append(enabled)
        if enabled:
            raise KeyboardInterrupt()
        return scripted_arm(proposal, row, enabled, remaining)
    monkeypatch.setattr(pairs, '_execute_arm', execute)
    proposal = preview(setup)
    with pytest.raises(KeyboardInterrupt):
        run(setup, proposal)
    result = run(setup, proposal)
    assert result['ok'] and result['interrupted'], result
    assert calls == [False, True]
    assert result['pairs'][0]['before']['outputs'] and not result['pairs'][0]['after']['outputs']
    assert not result['pairs'][0]['comparison']['valid_pair']


def test_journal_edit_is_refused_before_recovery_or_model_call(setup, monkeypatch):
    proposal = preview(setup)
    path = pairs._journal(setup.root, setup.pack, proposal['request_id'])
    pairs._save_journal(path, {'actor_id': ACTOR, 'preview_digest': proposal['digest'], 'proposal': proposal, 'arms': {}})
    saved = json.loads(path.read_text())
    saved['proposal']['correction']['right'] = 'Edited after preview.'
    path.write_text(json.dumps(saved))
    monkeypatch.setattr(pairs, '_execute_arm', lambda *a: pytest.fail('edited journal reached a model'))
    assert not run(setup, proposal)['ok']


@pytest.mark.parametrize('field', ['outputs', 'flat_results', 'semantic_claim', 'scope'])
def test_canonical_readback_refuses_edited_pair_views_even_with_recomputed_file_digest(setup, monkeypatch, field):
    monkeypatch.setattr(pairs, '_execute_arm', scripted_arm)
    result = run(setup, preview(setup))
    assert result['ok'], result
    record = json.loads(json.dumps({k: v for k, v in result.items() if k not in {'ok', 'id', 'sha256'}}))
    if field == 'outputs':
        record['pairs'][0]['after']['outputs'][0]['outcome'] = {'status': 'done', 'summary': 'Unobserved edited claim.'}
    elif field == 'flat_results':
        record['results'][0]['passed'] = not record['results'][0]['passed']
    elif field == 'semantic_claim':
        record['semantic_improvement'] = True
    else:
        record['cases'][0]['packs'].append('fixtures/oncology/hidden/202606')
    sha = runtime.digest(record)
    record.update(sha256=sha, id=sha[:24])
    path = runtime.safe_path(setup.root, setup.pack, 'evaluations', record['id'])
    path.write_text(json.dumps(record), encoding='utf-8')
    assert not pairs.read(setup.root, setup.pack, ACTOR, record['id'], allowed_packs=[setup.pack])['ok']


def test_pair_record_cannot_activate_a_learner_or_supply_real_work_labels(setup, monkeypatch):
    monkeypatch.setattr(pairs, '_execute_arm', scripted_arm)
    result = run(setup, preview(setup))
    assert result['ok'], result
    monkeypatch.setattr(lifecycle, '_fresh', lambda *a: {'labels': [], 'evaluations': [result]})
    with pytest.raises(ValueError, match='cannot activate'):
        lifecycle.activate(setup.root, setup.pack, ACTOR, result['id'], 'Reviewer', '2026-09-08', 'Mechanical review only.',
            expected_digest='unused', confirmed=True, local_demo=True, can_review=True, allowed_packs=[setup.pack])
    with pytest.raises(ValueError, match='selected-provider execution'):
        runtime.checked_run(result['runs'][0]['run'], setup.pack)


def test_read_requires_the_same_identity_and_scope(setup, monkeypatch):
    monkeypatch.setattr(pairs, '_execute_arm', scripted_arm)
    result = run(setup, preview(setup))
    assert result['ok'], result
    assert not pairs.read(setup.root, setup.pack, 'another-reviewer', result['id'], allowed_packs=[setup.pack])['ok']
    assert not pairs.read(setup.root, setup.pack, ACTOR, result['id'], allowed_packs=[])['ok']


def test_missing_product_has_an_actionable_manual_prerequisite(tmp_path):
    result = pairs.options(tmp_path, None, ACTOR, 'unused', allowed_packs=[])
    assert not result['ok'] and 'working product' in result['errors'][0]


def test_real_worker_reuses_orchestrator_scorer_receipt_and_context_override_without_live_calls(setup, monkeypatch):
    import importlib
    import state
    import scientific_definition_ai as ai
    proposal = preview(setup)
    native = object.__new__(ai.vscode.VSCodeModel)
    native.model = CONNECTION['model']
    seen = []
    def step(system, messages):
        seen.append(system)
        return json.dumps({'action': 'escalate', 'to': 'operator',
            'question': 'Review the progress return action.', 'evidence': 'The workflow correction remains under review.'})
    native.step = step
    monkeypatch.setattr(ai, '_provider', lambda *a, **k: dict(CONNECTION, configured=True, instance=native))
    monkeypatch.setattr(pairs, 'CODE', setup.root)
    monkeypatch.setattr(state, 'RUNS', str(setup.root.parent / 'isolated-runs'))
    monkeypatch.setattr(state, 'CANDIDATES', str(setup.root.parent / 'isolated-candidates'))
    for kind in pairs.specialists.KINDS.values():
        module = importlib.import_module(kind['module'])
        monkeypatch.setattr(module, 'CANDIDATES', module.CANDIDATES)
    # Copy only existing handler source needed by the actual skill loader;
    # refresh the already-scripted software check after this fixture change.
    for binding in skills.BINDINGS.values():
        for handler in binding.get('handlers', []):
            path = handler.split('::', 1)[0] if isinstance(handler, str) else ''
            if path and (ROOT / path).is_file():
                target = setup.root / path
                target.parent.mkdir(parents=True, exist_ok=True)
                shutil.copyfile(ROOT / path, target)
    # No copied handler is executed merely by providing its source to the loader.
    row = skills.learning().read_correction(setup.root, setup.target['id'])
    with monkeypatch.context() as check_patch:
        check_patch.setattr(skills.learning().subprocess, 'run', lambda *a, **k: SimpleNamespace(returncode=0))
        setup.target = improvement.check(setup.root, ACTOR, row['id'], row['tests'], expected_digest=row['digest'], confirmed=True, can_review=True)
    proposal = preview(setup)
    before = pairs._worker({'proposal': proposal, 'case': proposal['cases'][0], 'include_target': False})
    after = pairs._worker({'proposal': proposal, 'case': proposal['cases'][0], 'include_target': True})
    assert len(seen) == 2
    assert setup.target['right'] not in seen[0] and setup.target['right'] in seen[1]
    assert before['runs'][0]['run']['execution']['mode'] == 'canonical_case_evaluation'
    assert after['runs'][0]['run']['execution']['mode'] == 'canonical_case_evaluation'
    assert pairs._comparison(before, after, proposal['correction'])['valid_pair']
    assert skills.learning().read_correction(setup.root, setup.target['id'])['status'] == 'checked'


def test_worker_transport_is_isolated_bounded_and_sanitizes_failure(setup, monkeypatch):
    proposal = preview(setup)
    observed = []
    def launch(command, **kwargs):
        directory = Path(kwargs['extra_env']['RWDP_STATE_DIR'])
        assert directory.is_dir() and not directory.is_relative_to(setup.product)
        assert command[2] == '--worker' and kwargs['timeout_s'] <= pairs.ARM_SECONDS + 10
        assert kwargs['extra_env']['RWD_PORTAL_AI_PROVIDER'] == 'vscode'
        observed.append(json.loads(Path(command[3]).read_text(encoding='utf-8')))
        return SimpleNamespace(returncode=1, stdout='PRIVATE_PROVIDER_DETAIL', stderr='PRIVATE_PROVIDER_DETAIL')
    monkeypatch.setattr(pairs.portal_runtime, 'run', launch)
    arm = pairs._execute_arm(proposal, proposal['cases'][0], False, 90)
    assert arm['error'] and len(observed) == 1
    assert 'PRIVATE_PROVIDER_DETAIL' not in json.dumps(arm)


def test_existing_main_flow_recent_resumes_exact_owned_comparison(setup, monkeypatch):
    monkeypatch.setattr(pairs, '_execute_arm', scripted_arm)
    result = run(setup, preview(setup))
    assert result['ok'], result
    another = dict(result, recorded_by='another-reviewer', id='e' * 24)
    monkeypatch.setattr(lifecycle, 'describe', lambda *a, **k: {'ok': True, 'evaluations': [another, result]})
    recent = lifecycle.recent(setup.root, setup.pack, ACTOR, allowed_packs=[setup.pack])
    assert len(recent) == 1 and recent[0]['route'] == 'model_lifecycle'
    assert recent[0]['params'] == {'evaluation_id': result['id'], 'objective_id': pairs.OBJECTIVE,
                                  'correction_id': setup.target['id']}
