"""Regressions for the SEVENTH external audit of 2026-09-03 (main @ e3fdc99). Each fails on the
defect it names and passes on the fix.

  P1  authority was four phrases: a probe called the real decision tool, then claimed an approval
      "on behalf of Science" in `done`, and the run completed. Now: tools carry TYPED metadata
      (which ones hand a question to a person), and a `done` that claims an act is refused, then
      escalated — a model's text is never an act
  P1  the cost ceiling was checked after the ROOT call only; specialist calls inside a tool ran
      past it ($0.50 ceiling, $3.02 spent); resume had no ceiling at all. Now: one bounded loop
      for run and resume, the ceiling checked after every tool call, and every model call refuses
      before the API when the run is over
  P1  resume marked the original answered BEFORE the successor succeeded (a model failure closed
      the question); two concurrent resumes both proceeded and collided on one .tmp file. Now: an
      exclusive claim file, the `answered` step written only on success, unique temp names
  P1  a snapshot with `schema: 999` and no packs was presented as current because no governed
      path had changed. Now: only the commit-mismatch error is waivable; structure never is
  P1  pack membership filtered the selector only. Now: the tool layer refuses a pack outside the
      actor's scope, the queues take a scope, and chat/memo are keyed by actor and pack
  P1  the promoted receipt writes supersedes/promoted_from/deployment the schema forbade; a
      released receipt could say env=dev / release_grade=false / allow_dev_publish
  P1  artifact_root was any valid Volume path; now it must equal the deployment-approved root the
      deploy tree recorded
  P2  malformed manifests raised or passed; the template lacked 23 writer fields; three composed
      SQL names escaped the limit; the eval runner could spend on 109 cases unplanned; the
      benchmark accepted negative repeats and --n 0; duplicate rescoring hid a PASS->FAIL;
      invalid portal limits showed a traceback; CI skipped .streamlit and never compiled the
      portal; the deployed portal declared no dependencies and no first admin; the PowerShell twin
      wrote cp1252; eight deprecated width calls; six document contradictions

NO PYTEST FIXTURES AND NO `parametrize` — CI runs every suite as a script.
"""
import copy
import json
import os
import re
import subprocess
import sys
import tempfile
import threading
from pathlib import Path

FRAMEWORK = Path(__file__).resolve().parent.parent
ROOT = FRAMEWORK.parent
AGENT = ROOT / "experiments" / "agent"
PORTAL = ROOT / "experiments" / "portal"
for p in (FRAMEWORK, FRAMEWORK / "tools", AGENT, AGENT / "bench", AGENT / "evals", PORTAL):
    sys.path.insert(0, str(p))
os.environ.setdefault("ANTHROPIC_API_KEY", "not-a-key-tests-never-call")

from engine import refresh, release  # noqa: E402

P = "fixtures/oncology/prostate/202606"
OC = "fixtures/oncology/oc/202606"


def _read(rel):
    return (ROOT / rel).read_text(encoding="utf-8")


class _Scripted:
    model = "fake"

    def __init__(self, replies, raise_on=None):
        self.replies = list(replies)
        self.raise_on = raise_on
        self.usage = {"calls": 0, "input_tokens": 0, "output_tokens": 0}

    def step(self, system, transcript):
        self.usage["calls"] += 1
        if self.raise_on is not None and self.usage["calls"] == self.raise_on:
            raise RuntimeError("simulated model failure")
        return self.replies.pop(0) if self.replies else json.dumps({"action": "done", "summary": "again"})


def _in_tmp_runs(fn):
    import state as st_mod  # noqa: PLC0415
    saved = st_mod.RUNS
    with tempfile.TemporaryDirectory() as d:
        st_mod.RUNS = d
        try:
            return fn(d)
        finally:
            st_mod.RUNS = saved


def _tool(name, args=None, why="x"):
    return json.dumps({"action": "tool", "tool": name, "args": args or {}, "why": why})


def _done(summary):
    return json.dumps({"action": "done", "summary": summary})


# ------------------------------------------------------------------ P1 authority

def test_a_done_that_claims_an_act_is_refused_then_escalated_and_tools_carry_typed_authority():
    import orchestrator as orc  # noqa: PLC0415
    import tools  # noqa: PLC0415
    assert tools.meta("decision_packet")["decides"] == "human", "the packet is a question for a person"
    assert tools.meta("open_questions")["decides"] == "human"
    assert tools.meta("packs")["decides"] is None
    assert orc.claims_act("Approved on behalf of Science: TSST binds to the concept")
    assert orc.claims_act("I have adopted the precedent and recorded the answer")
    assert not orc.claims_act("Gate 1 is in progress; approval is pending from Science")
    assert not orc.claims_act("The register says OUTCOME-COHORT-MAP is not approved yet")
    saved = tools.call
    tools.call = lambda name, args: "1. OUTCOME-COHORT-MAP — unblocks 19 record(s). Owner: Science."

    def go(d):
        st = orc.run("goal", model=_Scripted([_tool("decision_packet", {"pack": P}),
                                              _done("Approved on behalf of Science: bind TSST."),
                                              _done("Approved on behalf of Science, again.")]))
        kinds = [s["kind"] for s in st.steps]
        assert "authority_detected" in kinds, "typed metadata, not the four phrases, flagged the packet"
        assert "refused_claimed_act" in kinds, "the first claiming done is refused with the reason"
        assert st.outcome["status"] == "escalated", st.outcome
        esc = json.loads(st.outcome["summary"])
        assert esc["to"] == "Science" and "not an act" in esc["evidence"].lower() or "person" in esc["evidence"].lower()
    try:
        _in_tmp_runs(go)
    finally:
        tools.call = saved


# ------------------------------------------------------------------ P1 budget across tools

def test_the_ceiling_holds_across_specialist_spend_inside_a_tool_and_before_any_call():
    import orchestrator as orc  # noqa: PLC0415
    import tools  # noqa: PLC0415
    saved = tools.call

    def spendy(name, args):
        orc._RUN_USAGE.get()["cost_usd"] += 5.0          # a specialist's own calls, inside the tool
        return "assembled"
    tools.call = spendy

    def go(d):
        st = orc.run("goal", model=_Scripted([_tool("code_candidate", {"pack": P}), _done("x")]),
                     cost_ceiling=0.5)
        assert st.outcome["status"] == "budget_exhausted", st.outcome
        assert st.metrics["calls"] == 1, "stopped right after the tool, before another model call"
        # resume is bounded by the same loop
        esc = orc.run("goal", model=_Scripted([json.dumps({"action": "escalate", "to": "Science",
                                                            "question": "q", "evidence": "e"})]))
        r = orc.resume_run(esc.run_id, "ans", "someone", model=_Scripted([_tool("code_candidate"), _done("x")]),
                           cost_ceiling=0.5, max_seconds=60)
        assert r.outcome["status"] == "budget_exhausted", r.outcome
    try:
        _in_tmp_runs(go)
    finally:
        tools.call = saved
    # every model call checks the ceiling BEFORE the API: a specialist cannot spend past it
    acc = orc._new_usage_acc(); acc["cost_usd"] = 0.6
    tok = orc._RUN_USAGE.set(acc); tok2 = orc._RUN_CEILING.set(0.5)
    try:
        try:
            orc.assert_within_ceiling()
        except orc.BudgetExceeded as e:
            assert "0.6" in str(e) or "0.5" in str(e)
        else:
            raise AssertionError("a call over the ceiling must refuse before reaching the API")
    finally:
        orc._RUN_USAGE.reset(tok); orc._RUN_CEILING.reset(tok2)
    src = _read("experiments/agent/orchestrator.py")
    i = src.index("def step(self, system")
    body = src[i:src.index("messages.create(", i)]
    assert "assert_within_ceiling()" in body, "step() refuses before messages.create"


# ------------------------------------------------------------------ P1 resume safety

def test_resume_marks_the_original_answered_only_on_success_and_only_once():
    import orchestrator as orc  # noqa: PLC0415
    import state as st_mod  # noqa: PLC0415

    def go(d):
        esc = orc.run("goal", model=_Scripted([json.dumps({"action": "escalate", "to": "Science",
                                                            "question": "q", "evidence": "e"})]))
        try:
            orc.resume_run(esc.run_id, "ans", "someone", model=_Scripted([], raise_on=1))
        except RuntimeError:
            pass
        else:
            raise AssertionError("the simulated failure must surface")
        orig = json.load(open(os.path.join(d, f"{esc.run_id}.json"), encoding="utf-8"))
        assert not any(s["kind"] == "answered" for s in orig["steps"]), "a failed resume closes nothing"
        assert not os.path.exists(os.path.join(d, f"{esc.run_id}.answer.lock")), "the claim is released"
        # concurrent resumes: exactly one proceeds
        outcomes = []

        def one():
            try:
                r = orc.resume_run(esc.run_id, "ans", "someone",
                                   model=_Scripted([_tool("packs", {"query": "prostate"}), _done("ok")]))
                outcomes.append(("ok", r.run_id))
            except SystemExit as e:
                outcomes.append(("refused", str(e)))
        ts = [threading.Thread(target=one) for _ in range(2)]
        [t.start() for t in ts]; [t.join() for t in ts]
        assert sorted(o[0] for o in outcomes) == ["ok", "refused"], outcomes
        orig = json.load(open(os.path.join(d, f"{esc.run_id}.json"), encoding="utf-8"))
        assert sum(1 for s in orig["steps"] if s["kind"] == "answered") == 1
    _in_tmp_runs(go)
    src = _read("experiments/agent/state.py")
    assert 'self.path + ".tmp"' not in src and "secrets" in src, "temp names are unique per writer"


# ------------------------------------------------------------------ P1 snapshot policy

def test_only_a_commit_mismatch_is_waivable_never_a_structural_error():
    import snapshot_policy as sp  # noqa: PLC0415
    ok, why = sp.accept(["describes commit abc123def456, the served commit is 999888777666"], touched=[])
    assert ok and "no governed path" in why
    ok, why = sp.accept(["describes commit abc123def456, the served commit is 999888777666"], touched=["fixtures/x"])
    assert not ok
    ok, why = sp.accept(["schema is 999, this reader knows 1"], touched=[])
    assert not ok and "structural" in why
    ok, why = sp.accept(["describes commit a, the served commit is b", "covers no packs at all"], touched=[])
    assert not ok
    ok, why = sp.accept([], touched=[])
    assert ok
    assert "snapshot_policy.accept(" in _read("experiments/portal/app.py")


# ------------------------------------------------------------------ P1 pack scope

def test_pack_scope_is_enforced_in_the_tool_layer_the_queues_and_the_session():
    import tools  # noqa: PLC0415
    import queues  # noqa: PLC0415
    tools.set_pack_scope({P})
    try:
        assert "REFUSED" in tools.call("pack_status", {"pack": OC}) and "scope" in tools.call("pack_status", {"pack": OC})
        assert "REFUSED" not in tools.call("packs", {"query": "prostate"})
        tools.set_pack_scope({OC})
        assert "REFUSED" in tools.call("pack_status", {}), "the default pack is outside this scope"
    finally:
        tools.set_pack_scope(None)
    with tempfile.TemporaryDirectory() as runs, tempfile.TemporaryDirectory() as cands:
        for rid, goal in (("20260901-1000", f"do {P}"), ("20260901-1100", f"do {OC}"), ("20260901-1200", "global")):
            json.dump({"run_id": rid, "goal": goal, "actor": None, "steps": [],
                       "outcome": {"status": "escalated", "summary": json.dumps({"to": "Science", "question": "q"})}},
                      open(os.path.join(runs, f"{rid}.json"), "w", encoding="utf-8"))
        assert [r["run_id"] for r in queues.escalations(runs, within={P})] == ["20260901-1000"]
        assert len(queues.escalations(runs)) == 3
        json.dump({"kind": "diagnosis", "pack": OC, "generated_at": "x", "critic": {}, "decision": "HUMAN"},
                  open(os.path.join(cands, "a.json"), "w", encoding="utf-8"))
        json.dump({"kind": "diagnosis", "pack": P, "generated_at": "y", "critic": {}, "decision": "HUMAN"},
                  open(os.path.join(cands, "b.json"), "w", encoding="utf-8"))
        assert [r["file"] for r in queues.packets(cands, within={P})] == ["b.json"]
    app = _read("experiments/portal/app.py")
    assert "tools.set_pack_scope(set(MY_PACKS))" in app
    assert "within=set(MY_PACKS)" in app, "the unscoped views stay inside the actor's membership"
    import ast
    tree = ast.parse(app)
    assignments = {target.id: node for node in ast.walk(tree) if isinstance(node, ast.Assign)
                   for target in node.targets if isinstance(target, ast.Name) and target.id in {"_chat_actor", "_ckey"}}
    assert set(assignments) == {"_chat_actor", "_ckey"}
    key_code = compile(ast.Module(body=[assignments["_chat_actor"], assignments["_ckey"]], type_ignores=[]),
                       "<current actor and product chat key>", "exec")
    keys = []
    for actor, pack in (({"name": "Same name", "email": "first@example.test"}, P),
                        ({"name": "Same name", "email": "second@example.test"}, P),
                        ({"name": "Same name", "email": "first@example.test"}, OC),
                        ({"name": "Local label"}, P)):
        scope = {"ACTOR": actor, "pack": pack}
        exec(key_code, scope)
        keys.append(scope["_ckey"])
    assert len(set(keys)) == len(keys) and keys[-1] == ("Local label", P)
    assert "st.session_state.chats.setdefault(_ckey" in app and "st.session_state.memos.get(_ckey)" in app


# ------------------------------------------------------------------ P1 release contracts

def test_every_key_the_runner_writes_is_declared_and_a_released_receipt_is_release_grade_prod():
    src = _read("platform/databricks/run_rwdp.py")
    keys = set(re.findall(r'(?:manifest|_cand)\["([a-z_]+)"\]\s*=', src))
    keys |= set(re.findall(r'_cand\.setdefault\("([a-z_]+)"', src))
    schema = json.loads(_read("governance/schemas/release.schema.json"))
    missing = keys - set(schema["properties"])
    assert not missing, f"the runner writes fields the closed schema forbids: {sorted(missing)}"
    rec = {"tumor": "p", "refresh": "r", "spec_version": "202606", "built_at": "x", "status": "released",
           "counts": {}, "run_mode": {"env": "dev", "release_grade": False, "published_under": "allow_dev_publish"}}
    probs = refresh.validate_manifest(rec)
    assert any("run_mode.env" in p and "prod" in p for p in probs), probs
    assert any("release_grade" in p for p in probs), probs
    assert any("allow_dev_publish" in p for p in probs), probs


def test_the_artifact_root_is_bound_to_the_deployment_approved_destination():
    dt = _read("platform/tools/deploy_tree.py")
    assert "--artifact-root" in dt and '"approved_artifact_root"' in dt
    rr = _read("platform/databricks/run_rwdp.py")
    assert "approved_artifact_root" in rr and "artifact_root_accepted(_artifact_base, _approved" in rr
    assert "neither the deployment-approved root" in _read("platform/tools/source_manifest.py"), "the one rule, in the one reader"
    i = rr.index("approved_artifact_root")
    assert i < rr.index("dbutils.fs.mkdirs(artifact_root)"), "bound before anything is written"


# ------------------------------------------------------------------ P2 manifests and names

def test_malformed_manifests_never_raise_and_never_pass():
    for bad in ({"tumor": 5, "refresh": "r", "spec_version": "202606", "built_at": "x", "status": "qc_pending", "counts": {}},
                {"tumor": "p", "refresh": "r", "spec_version": "202606", "built_at": 5, "status": "qc_pending", "counts": {}},
                {"tumor": "p", "refresh": "r", "spec_version": "202606", "built_at": "x", "status": "qc_pending",
                 "counts": {}, "artifacts": 7},
                {"tumor": "p", "refresh": "r", "spec_version": "202606", "built_at": "x", "status": "qc_pending",
                 "counts": {}, "source_lineage": {"a": 5}},
                {"tumor": "p", "refresh": "r", "spec_version": "202606", "built_at": "x", "status": "qc_pending",
                 "counts": {}, "qc": {"passed": "yes"}},
                {"tumor": "p", "refresh": "r", "spec_version": "202606", "built_at": "x", "status": "released",
                 "counts": {}, "sign_off": {"released_by": 5}},
                {"tumor": "p", "refresh": "r", "spec_version": "202606", "built_at": "x", "status": "qc_pending",
                 "counts": {}, "release": {"build_id": True}}):
        probs = refresh.validate_manifest(copy.deepcopy(bad))
        assert probs, f"zero findings for {bad}"


def test_the_template_carries_every_writer_field_and_every_composed_name_is_held():
    import yaml  # noqa: PLC0415
    t = yaml.safe_load(_read("refreshes/REFRESH_TEMPLATE.yaml")) or {}
    src = _read("platform/engine/refresh.py")
    i = src.index("def build_manifest("); j = src.index("\ndef ", i + 10)
    w = set(re.findall(r'^\s{8}"([a-z0-9_]+)":', src[i:j], re.M))
    assert not (w - set(t)), f"template lacks writer fields: {sorted(w - set(t))}"
    for fn, args in ((release.public_tfl, ("s." + "t" * 250, "i" * 64)),
                     (release.promotion_lock, ("s." + "t" * 250,)),
                     (release.release_pointer_table, ("s." + "t" * 250,))):
        try:
            fn(*args)
        except ValueError as e:
            assert "255" in str(e)
        else:
            raise AssertionError(f"{fn.__name__} composed past the limit")


# ------------------------------------------------------------------ P2 spend controls

def test_the_eval_runner_plans_spend_bounds_each_case_and_isolates_failures():
    import run as ev  # noqa: PLC0415
    try:
        ev.spend_guard(109, None)
    except SystemExit as e:
        assert "--budget-usd" in str(e)
    else:
        raise AssertionError("109 paid cases with no budget must refuse")
    ev.spend_guard(3, None)                      # a handful of cases is fine without a plan
    calls = []

    def runner(goal, **kw):
        calls.append(kw)
        if "boom" in goal:
            raise RuntimeError("tool exploded")
        import state as st_mod  # noqa: PLC0415
        st = st_mod.RunState(goal); st.finish("done", "ok"); return st
    cases = [{"id": "a", "goal": "fine", "expect": {"outcome": "done"}},
             {"id": "b", "goal": "boom", "expect": {"outcome": "done"}},
             {"id": "c", "goal": "fine2", "expect": {"outcome": "done"}}]
    rows = _in_tmp_runs(lambda d: ev.run_cases(cases, runner=runner, per_case_ceiling=0.2, max_seconds_per_case=30))
    assert [r["case"] for r in rows] == ["a", "b", "c"], "a failing case is a row, not a dead sweep"
    assert rows[1]["error"] and rows[1]["passed"] is False
    assert all(k["cost_ceiling"] == 0.2 and k["max_seconds"] == 30 for k in calls)


def test_the_benchmark_refuses_bad_controls_and_the_readme_describes_report_honestly():
    env = {**os.environ, "PYTHONUTF8": "1"}
    for argv in (["--repeats", "-1", "--plan"], ["--n", "0", "--plan"], ["--efforts", "turbo", "--plan"]):
        r = subprocess.run([sys.executable, str(AGENT / "bench" / "run_bench.py"), *argv], capture_output=True,
                           text=True, encoding="utf-8", errors="replace", cwd=str(ROOT), timeout=180, env=env)
        assert r.returncode != 0, (argv, r.stdout[-300:])
    readme = _read("experiments/agent/README.md")
    assert "a paid sweep, capped, then the report" not in readme
    assert "--report" in readme and "report-only" in readme


def test_duplicate_rescoring_cannot_hide_a_regression():
    import history  # noqa: PLC0415
    saved = history.RUNS
    with tempfile.TemporaryDirectory() as d:
        history.RUNS = d
        rows = [{"case": "x", "run": "a", "passed": True}, {"case": "x", "run": "b", "passed": False},
                {"case": "x", "run": "b", "passed": False, "rescored": True},
                {"case": "x", "run": "b", "passed": False, "rescored": True}]
        with open(os.path.join(d, "scorecard_history.jsonl"), "w", encoding="utf-8") as fh:
            for r in rows:
                fh.write(json.dumps(r) + "\n")
        try:
            down, up = history.flips()
        finally:
            history.RUNS = saved
    assert down == ["x"], "the PASS->FAIL between runs a and b must survive two rescores of b"
    src = _read("experiments/agent/evals/run.py")
    assert 'r["rescored"] = True' in src, "a rescore row says it is a re-read, not a new run"


# ------------------------------------------------------------------ P2 portal and CI

def test_portal_limits_are_validated_ci_covers_the_portal_and_the_deployment_is_declared():
    import limits  # noqa: PLC0415
    assert limits.caps({}) == {"steps": 10, "usd": 0.25, "seconds": 180.0}
    for bad in ({"RWD_PORTAL_MAX_STEPS": "0"}, {"RWD_PORTAL_RUN_CEILING_USD": "nan"},
                {"RWD_PORTAL_MAX_SECONDS": "-5"}, {"RWD_PORTAL_RUN_CEILING_USD": "inf"},
                {"RWD_PORTAL_MAX_STEPS": "ten"}):
        try:
            limits.caps(bad)
        except ValueError as e:
            assert "RWD_PORTAL" in str(e)
        else:
            raise AssertionError(f"{bad} accepted")
    app = _read("experiments/portal/app.py")
    assert "limits.caps(" in app and "use_container_width" not in app
    ci = _read(".github/workflows/rwdp-ci.yml")
    assert '".streamlit/**"' in ci and "compileall -q experiments" in ci
    req = _read("experiments/portal/requirements.txt")
    assert "streamlit" in req and "anthropic" in req and "pyyaml" in req.lower()
    assert "requirements.txt" in _read("app.yaml")
    import identity  # noqa: PLC0415
    assert identity.default_users(False) == []
    boot = identity.default_users(False, bootstrap_admin="ana@example.org")
    assert boot == [{"name": "ana@example.org", "email": "ana@example.org", "role": "admin"}]
    assert "RWD_PORTAL_BOOTSTRAP_ADMIN" in app


def test_the_powershell_twin_writes_utf8():
    eng = _read("docs/ENGINEERING.md")
    block = eng[eng.index("$failures = @()"):]
    assert '$env:PYTHONUTF8 = "1"' in block[:1200] and "[Console]::OutputEncoding" in block[:1200]


# ------------------------------------------------------------------ P2 documents and direction

def test_the_documents_agree_and_one_deployment_page_exists():
    assert not _read("docs/README.md").splitlines()[1].startswith("Five audits")
    assert "The ONLY place a model is invoked" not in _read("experiments/portal/app.py")
    for p in ("governance/VERSIONING.md", "products/OPERATIONS.md", "refreshes/README.md"):
        assert "`--var refresh=" not in _read(p), p
    assert "same ADS from the same config" not in _read("fixtures/oncology/prostate/202606/DEV_SMOKE.md")
    x = _read("docs/EXPRESSIBILITY_MATRIX.md")
    assert "Families D–J remain" not in x and "Families D–I remain" in x
    dep = _read("docs/DEPLOYMENT.md")
    for needle in ("Databricks Apps", "databricks.yml", "app/serve.py", "legacy"):
        assert needle in dep, needle
    assert "DEPLOYMENT.md" in _read("docs/README.md")
    b = _read("docs/AGENTIC_BENCHMARK.md")
    i = b.index("## Refined direction")
    sec = b[i:i + 4000]
    for needle in ("typed", "Explore", "Release", "not to copy", "PROPOSED"):
        assert needle in sec, needle


if __name__ == "__main__":
    fails = 0
    for name, fn in sorted(globals().items()):
        if name.startswith("test_") and callable(fn):
            try:
                fn()
                print(f"  ok   {name}")
            except Exception as e:  # noqa: BLE001
                fails += 1
                print(f"  FAIL {name}: {e}")
    print(f"{fails} failure(s)")
    sys.exit(1 if fails else 0)
