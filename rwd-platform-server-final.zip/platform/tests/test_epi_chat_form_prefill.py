"""Shared chat fills existing forms through the selected connection, without saving."""
from pathlib import Path
import json
import sys

import pytest
from streamlit.testing.v1 import AppTest

ROOT = Path(__file__).resolve().parents[2]
sys.path[:0] = [str(ROOT / "platform/tests"), str(ROOT / "experiments/portal"),
               str(ROOT / "platform/tools"), str(ROOT / "experiments/agent")]
import flow_assistant as fa
import flow_assistant_page as page
from test_epi_portal_journeys import _portal, _healthy, _new, _product_command

EMPTY = {"products": [], "references": [], "superseded": [], "templates": [], "names": {}, "drafts": set()}
PACK = "fixtures/oncology/prostate/202606"


@pytest.mark.parametrize("question,name,cut", [
    ("create gist produt", "gist", None),
    ("Create a new product for GIST 202606", "GIST", "202606"),
    ("Please create GIST 202606 product", "GIST", "202606"),
    ("start renal outcomes data product", "renal outcomes", None),
    ("Can you create a GIST product?", "GIST", None),
    ("I want to create a GIST product", "GIST", None),
])
def test_literal_creation_only_uses_explicit_name_and_month(question, name, cut):
    assert fa.creation_request(question) == {"name": name, "cut": cut}


def _connect(monkeypatch, response):
    calls = []
    class Model:
        def step(self, system, messages):
            request = json.loads(messages[0]["content"])
            calls.append(request)
            assert "editable_form" in request["context"]
            assert len(system.encode()) + len(messages[0]["content"].encode()) <= 18_000
            return response(request)
    provider = {"configured": True, "instance": Model(), "provider": "Scripted connection", "model": "test"}
    monkeypatch.setattr(page, "_provider_words", lambda *_: (provider, "Scripted connection"))
    return calls


@pytest.mark.parametrize("question,month", [("create gist produt", ""), ("Create a new product for GIST 202606", "202606")])
@pytest.mark.parametrize("model_fields", [True, False], ids=["typed-model-edits", "prose-only-model"])
def test_home_creation_chat_opens_and_prefills_real_form_without_writing(monkeypatch, question, month, model_fields):
    def response(message):
        form = message["context"]["editable_form"]
        labels = {field["label"] for field in form["fields"]}
        assert {"Product slug", "Display name", "Specification cut (YYYYMM)"} <= labels
        assert not {"Classified by (your name)", "Classified on (YYYY-MM-DD)", "What AI may read of the specification"} & labels
        reply = {"answer": "Review the prepared name. Complete the remaining declarations and preview the product.", "actions": []}
        if model_fields:
            reply["prefill"] = fa.creation_prefill(message["question"], form)
        return json.dumps(reply)
    calls = _connect(monkeypatch, response)
    with _product_command((0, "must not execute")) as commands, _portal(role="admin", catalogue=EMPTY) as at:
        assert not any(item.key == "np_slug" for item in at.text_input)
        at.chat_input[0].set_value(question).run()
        _healthy(at)
        assert at.text_input(key="np_slug").value == "gist"
        assert at.text_input(key="np_name").value.lower() == "gist"
        assert at.text_input(key="np_code").value == "gist"
        assert at.text_input(key="np_ver").value == month
        assert at.selectbox(key="np_vendor").value is None
        assert at.selectbox(key="np_ai").value is None
        assert at.text_input(key="np_by").value == at.text_input(key="np_on").value == ""
        assert any("Prepared draft fields" in item.value for item in at.success)
        assert not any(button.key == "np_write" for button in at.button)
        at.run()
        assert len(calls) == 1 and not commands


def test_real_new_product_chat_preserves_existing_entries_then_uses_reviewed_diff(monkeypatch):
    def response(message):
        form = message["context"]["editable_form"]
        values = {"Display name": "GIST outcomes", "Vendor": "flatiron", "Data modality": "ehr"}
        return json.dumps({"answer": "Review the proposed changes to your draft.", "actions": [],
            "prefill": {"scope": form["scope"], "fields": [{"id": f["id"], "value": values[f["label"]]}
                for f in form["fields"] if f["label"] in values]}})
    calls = _connect(monkeypatch, response)
    with _product_command((0, "must not execute")) as commands, _portal(role="admin") as at:
        _new(at)
        at.text_input(key="np_name").set_value("My earlier draft").run()
        at.chat_input[0].set_value("Change display name to GIST outcomes and use flatiron ehr").run()
        _healthy(at)
        assert at.text_input(key="np_name").value == "My earlier draft"
        assert at.selectbox(key="np_vendor").value is None
        assert any("Review suggested replacements" in item.value for item in at.markdown)
        assert any("My earlier draft" in str(item.value) and "GIST outcomes" in str(item.value) for item in at.dataframe)
        at.button(key="chat_form_replace").click().run()
        _healthy(at)
        assert at.text_input(key="np_name").value == "GIST outcomes"
        assert at.selectbox(key="np_vendor").value == "flatiron"
        assert at.selectbox(key="np_modality").value == "ehr"
        assert at.selectbox(key="np_ai").value is None
        assert len(calls) == 1 and not commands


@pytest.mark.parametrize("section", ["Home", "Flow"])
def test_creation_from_selected_product_carries_request_to_actual_new_form(monkeypatch, section):
    def response(message):
        return json.dumps({"answer": "The name and requested month are prepared. Review the remaining declarations.", "actions": [],
            "prefill": fa.creation_prefill(message["question"], message["context"]["editable_form"])})
    calls = _connect(monkeypatch, response)
    with _product_command((0, "must not execute")) as commands, _portal(role="admin") as at:
        at.radio(key="section").set_value(section).run()
        _healthy(at)
        if at.chat_input:
            at.chat_input[0].set_value("Can you create a GIST product 202606?").run()
        else:
            next(item for item in at.text_input if item.label == "Your question").set_value("Can you create a GIST product 202606?")
            next(item for item in at.button if item.label == "Ask").click().run()
        _healthy(at)
        assert at.text_input(key="np_slug").value == "gist"
        assert at.text_input(key="np_ver").value == "202606"
        assert len(calls) == 1 and not commands


def test_new_product_navigation_button_keeps_a_longer_request_for_prefill(monkeypatch):
    import scientific_definition_ai as ai
    monkeypatch.setattr(ai.definitions.cs, "ai_gate", lambda *_: None)  # synthetic authorized source, scripted model only
    question = "I need a GIST data product for outcomes with flatiron ehr, cut 202606."
    def response(message):
        assert message["question"] == question
        if not message["context"].get("setup_form"):
            return json.dumps({"answer": "Open the product form to prepare your registration draft.", "actions": ["open_new_product"]})
        form = message["context"]["editable_form"]
        values = {"Product slug": "gist", "Display name": "GIST", "Specification cut (YYYYMM)": "202606", "Vendor": "flatiron", "Data modality": "ehr"}
        return json.dumps({"answer": "Review your proposed registration entries.", "actions": [],
            "prefill": {"scope": form["scope"], "fields": [{"id": field["id"], "value": values[field["label"]]}
                for field in form["fields"] if field["label"] in values]}})
    calls = _connect(monkeypatch, response)
    with _product_command((0, "must not execute")) as commands, _portal(role="admin") as at:
        at.chat_input[0].set_value(question).run()
        _healthy(at)
        assert len(calls) == 1
        next(button for button in at.button if button.label == "Start a new product" and str(button.key).startswith("flow_assistant_act_")).click().run()
        _healthy(at)
        assert at.text_input(key="np_slug").value == "gist"
        assert at.selectbox(key="np_vendor").value == "flatiron"
        assert at.selectbox(key="np_modality").value == "ehr"
        assert len(calls) == 2 and not commands


def _small_form(tmp_path, *, source_gate=False):
    return AppTest.from_string(f'''
import streamlit as st
import form_assistance as forms
import flow_assistant_page as page
forms.begin({str(tmp_path)!r}, {PACK!r}, "epi", page="Source review", can_write=True, allowed_packs=[{PACK!r}])
page.render({str(ROOT)!r}, {PACK!r}, card={{"actions": [], "current_task": {{"route": "progress"}}}},
    actor_id="epi", primary=True, metadata_only={not source_gate!r}, can_write=True, allowed_packs=[{PACK!r}])
forms.field(st.text_area, "Interpretation", key="meaning")
forms.field(st.selectbox, "Source", ["ehr", "claims"], index=None, key="source")
st.text_input("Reviewer name", key="reviewer")
if st.button("Save checked record", key="save"):
    st.session_state.saved = True
forms.finish()
''', default_timeout=30).run()


@pytest.mark.parametrize("failure", ["malformed", "unoffered", "timeout", "stale"])
def test_failed_or_invalid_connected_response_keeps_unsaved_draft(monkeypatch, tmp_path, failure):
    def response(message):
        if failure == "timeout":
            raise TimeoutError("private provider detail")
        if failure == "malformed":
            return "broken json"
        form = message["context"]["editable_form"]
        return json.dumps({"answer": "Suggested change.", "actions": [], "prefill": {
            "scope": "earlier-context" if failure == "stale" else form["scope"],
            "fields": [{"id": "reviewer" if failure == "unoffered" else form["fields"][0]["id"], "value": "replacement"}]}})
    calls = _connect(monkeypatch, response)
    at = _small_form(tmp_path)
    at.text_area(key="meaning").set_value("My unsaved interpretation").run()
    at.chat_input[0].set_value("Change my interpretation").run()
    _healthy(at)
    assert at.text_area(key="meaning").value == "My unsaved interpretation"
    assert at.text_input(key="reviewer").value == ""
    assert len(calls) == 1
    assert "saved" not in at.session_state
    assert not any(button.key == "chat_form_replace" for button in at.button)
    assert all("private provider detail" not in item.value for item in at.markdown)


def test_form_contents_do_not_bypass_model_ingress_or_source_access(monkeypatch, tmp_path):
    import scientific_definition_ai as ai
    calls = _connect(monkeypatch, lambda *_: pytest.fail("restricted context cannot reach the model"))
    at = _small_form(tmp_path)
    at.text_area(key="meaning").set_value("ANTHROPIC_API_KEY=sk-ant-audit-sentinel-only").run()
    at.chat_input[0].set_value("Help rewrite this explanation").run()
    _healthy(at)
    assert not calls and "saved" not in at.session_state
    def blocked(*_):
        raise ValueError("No source permission")
    monkeypatch.setattr(ai.definitions.cs, "ai_gate", blocked)
    at = _small_form(tmp_path, source_gate=True)
    assert not at.chat_input
    at.text_input(key="flow_assistant_q_" + PACK).set_value("Help draft the interpretation")
    at.button(key="flow_assistant_ask_" + PACK).click().run()
    _healthy(at)
    assert not calls and at.text_area(key="meaning").value == ""
