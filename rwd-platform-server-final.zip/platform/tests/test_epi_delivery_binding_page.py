"""A new tumour can declare its delivery without the Plan changes dead end."""
import sys
from pathlib import Path

from streamlit.testing.v1 import AppTest

ROOT = Path(__file__).resolve().parents[2]
sys.path[:0] = [str(ROOT / "experiments/portal"), str(ROOT / "platform/tests"), str(ROOT / "platform/tools")]
from test_epi_source_workspace import scaffold
from test_epi_source_workspace_page import scaffold_app
from test_epi_delivery_binding import prepare, stage
import delivery_binding_page as page
import source_workspace as workspace


def app(read, params=None):
    code = f'''import streamlit as st
import source_workspace_page as page
result = page.render({str(read["root"])!r}, {read["pack"]!r},
    st.session_state.get("actor", {read["actor_id"]!r}),
    allowed_packs=st.session_state.get("scope", {read["allowed_packs"]!r}),
    local_demo=True, can_write=True, route="source_delivery", params={params!r})
if result:
    st.session_state["navigation"] = result
'''
    return AppTest.from_string(code, default_timeout=90).run()


def fill(at, values):
    for key, value in values.items():
        at.text_input(key=page.PREFIX + "value_" + key).set_value(value)
    at.button(key=page.PREFIX + "stage").click().run()
    assert not at.exception, [item.message for item in at.exception]
    assert not at.error, [item.value for item in at.error]
    return at


def test_unbound_evidence_opens_the_actual_delivery_form(tmp_path, monkeypatch):
    root, product, pack = scaffold(tmp_path, monkeypatch)
    at = scaffold_app(root, pack, "source_evidence")
    assert not at.exception
    button = next(button for button in at.button if button.label == "Declare the source delivery")
    button.click().run()
    assert at.session_state["navigation"]["route"] == "source_delivery"


def test_guided_delivery_saves_reviewed_draft_and_returns_to_evidence(tmp_path, monkeypatch):
    _, _, read, _, _, values = prepare(tmp_path, monkeypatch)
    at = app(read)
    assert not at.exception, [item.message for item in at.exception]
    assert at.text_input(key=page.PREFIX + "value_schema").value == ""
    assert "catalog.schema" in at.text_input(key=page.PREFIX + "value_schema").proto.help
    fill(at, values)
    assert len([item for item in at.code if item.language == "diff"]) == 2
    assert any("full configuration/scientific checks have not passed" in item.value for item in at.warning)
    assert "Proposed table" in at.dataframe[0].value.columns
    assert at.button(key=page.PREFIX + "save").disabled
    record_id = at.session_state[page.PREFIX + "id"]
    at.checkbox(key=page.PREFIX + "confirm_" + record_id).check().run()
    at.button(key=page.PREFIX + "save").click().run()
    assert not at.exception and not at.error
    assert at.session_state["navigation"]["changed"] is True
    assert not workspace.describe(**read)["blockers"]
    at.run()
    at.button(key=page.PREFIX + "evidence").click().run()
    assert at.session_state["navigation"]["route"] == "source_evidence"


def test_preview_cannot_save_after_form_edit_and_scope_change(tmp_path, monkeypatch):
    _, _, read, _, _, values = prepare(tmp_path, monkeypatch)
    at = fill(app(read), values)
    record_id = at.session_state[page.PREFIX + "id"]
    at.checkbox(key=page.PREFIX + "confirm_" + record_id).check().run()
    at.text_input(key=page.PREFIX + "value_schema").set_value("different_source").run()
    assert at.button(key=page.PREFIX + "save").disabled
    assert any("no longer matches" in item.value for item in at.warning)
    at.session_state["actor"] = "different-person"
    at.run()
    assert not at.exception
    assert at.text_input(key=page.PREFIX + "value_schema").value == ""
    assert not any(item.key == page.PREFIX + "save" for item in at.button)
    at.session_state["scope"] = []
    at.run()
    assert at.error and not at.text_input


def test_staged_delivery_resumes_literal_values_from_recent_work(tmp_path, monkeypatch):
    _, _, read, args, description, values = prepare(tmp_path, monkeypatch)
    record = stage(args, description, values)
    recent = next(item for item in workspace.recent(**read) if item["id"] == record["id"])
    assert recent["route"] == "source_delivery"
    at = app(read, recent["params"])
    assert not at.exception
    assert at.text_input(key=page.PREFIX + "value_source:enhanced").value == values["source:enhanced"]
    assert at.button(key=page.PREFIX + "save").disabled


def test_unsupported_adapter_is_an_actionable_engineering_handoff(tmp_path, monkeypatch):
    _, product, read, _, _, _ = prepare(tmp_path, monkeypatch)
    (product / "config/source_adapters.yaml").write_text("adapters: []\n", encoding="utf-8")
    at = app(read)
    assert not at.exception
    assert any("source adapters" in item.value for item in at.warning)
    assert any("Engineering" in item.value for item in at.selectbox)
    assert not any(item.key == page.PREFIX + "stage" for item in at.button)
