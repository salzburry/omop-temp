"""The dry run must simulate, never assert — and must never write to a pack.

`platform/tools/dry_run.py` makes a claim a pack has not made (`contract: approved`,
`configuration: approved`) and reports what answers back. That is useful precisely because those
gates are silent until the claim exists — prostate/202606 carried five unreadable QC findings for
months while `--check-maturity` correctly said zero errors.

Three ways it could go wrong, and each has a test:

  * it writes the claim into the REAL pack — a governed maturity file edited by a reporting tool,
    with a finally-block as the only thing putting it back;
  * it reports its own opinion of what blocks a release, becoming a second answer to a question
    `releasable` owns;
  * it reports "nothing latent" for a pack it could not check at all — the absence-as-clean-result
    failure this codebase has produced in five other tools.

Run: python3 tests/test_dry_run.py (or pytest).
"""
import ast
import os
import sys
from pathlib import Path

FRAMEWORK = Path(__file__).resolve().parent.parent
TOOLS = FRAMEWORK / "tools"
REPO = FRAMEWORK.parent
sys.path.insert(0, str(TOOLS))

import dry_run          # noqa: E402
import product_gates    # noqa: E402
import source_manifest  # noqa: E402


def _claimable():
    out = [p for p in sorted(product_gates.all_packs(str(REPO)))
           if os.path.exists(os.path.join(str(REPO), p, dry_run.MATURITY))]
    assert out, "no pack has a MATURITY.yaml — these tests would prove nothing"
    return out


def test_it_never_writes_to_the_real_pack():
    """The claim goes into a copy. Asserted on the BYTES of every maturity file before and after,
    because a tool that edits a governed claim and restores it in a finally-block is one exception
    away from leaving `approved` in the tree."""
    before = {p: (Path(str(REPO)) / p / dry_run.MATURITY).read_bytes() for p in _claimable()}
    for pack in _claimable():
        dry_run.latent(pack, str(REPO))
    after = {p: (Path(str(REPO)) / p / dry_run.MATURITY).read_bytes() for p in _claimable()}
    assert before == after, f"MATURITY.yaml changed for: {[p for p in before if before[p] != after[p]]}"


def test_the_staging_copy_is_outside_the_checkout_and_is_removed():
    """A temp directory, and gone afterwards — not a scratch folder inside products/."""
    pack = _claimable()[0]
    tmp, dst = dry_run._stage(pack, str(REPO))
    try:
        assert os.path.isdir(dst), "the pack was not staged"
        assert not str(Path(tmp).resolve()).startswith(str(REPO.resolve())), \
            f"staged inside the checkout: {tmp}"
    finally:
        import shutil
        shutil.rmtree(tmp, ignore_errors=True)
    assert not os.path.exists(tmp)


def test_the_verdict_is_releasables_and_not_a_second_opinion():
    """Both halves of the subtraction come from source_manifest.releasable on the same inputs. A
    private idea of what blocks a release is the one thing this tool must not develop."""
    assert dry_run.source_manifest is source_manifest
    tree = ast.parse((TOOLS / "dry_run.py").read_text(encoding="utf-8"))
    called = {n.func.attr for n in ast.walk(tree)
              if isinstance(n, ast.Call) and isinstance(n.func, ast.Attribute)}
    assert "releasable" in called, "dry_run no longer asks releasable()"
    for banned in ("maturity_errors", "check", "source_status"):
        assert banned not in called, \
            f"dry_run calls {banned}() directly — releasable() already composes it"


def test_latent_is_exactly_what_the_claim_newly_reveals():
    """The subtraction, checked against both calls rather than trusted."""
    for pack in _claimable():
        current, new, note = dry_run.latent(pack, str(REPO))
        assert note is None
        _ok, live = source_manifest.releasable(str(REPO), pack)
        assert current == live, f"{pack}: the 'today' list is not releasable()'s"
        assert not (set(new) & set(current)), \
            f"{pack}: {sorted(set(new) & set(current))} reported as latent but already blocking"
        # The claim's own lines must never be reported as latent findings. Asserted against the
        # strings rather than a constant in the tool: the tool needs no filter for them (they
        # cannot fire once the claim is made) and a shared constant would let both sides drift
        # into agreeing about a case neither actually handles.
        for b in new:
            assert "not approved" not in b, \
                f"{pack}: {b[:70]!r} is the claim itself, not a latent finding"


def test_a_pack_with_no_claim_to_make_says_so_rather_than_nothing_latent():
    """`[]` means 'checked and clean'. A pack with no MATURITY.yaml was not checked, and the two
    must not print the same line — the failure this codebase has now produced in five tools."""
    without = [p for p in sorted(product_gates.all_packs(str(REPO)))
               if not os.path.exists(os.path.join(str(REPO), p, dry_run.MATURITY))]
    assert without, "every pack has a MATURITY.yaml — this test would prove nothing"
    current, new, note = dry_run.latent(without[0], str(REPO))
    assert note and "nothing was checked" in note, f"a pack with no claim reported: {note!r}"
    assert (current, new) == ([], [])

    text = dry_run.render(without[0], str(REPO))
    assert "NOTHING LATENT" not in text, "an unchecked pack was reported as clean"
    assert "nothing was checked" in text


def test_no_blocker_is_truncated_away():
    """The message IS the payload — it names the artifact, the count, often the command to run.
    An earlier draft clipped to the column width and turned `13 unaccounted spec row(s)` into
    `13 unaccounted spe`, which is the part worth reading."""
    long = ("evidence: some/pack: contract:approved with 13 unaccounted specification-QC "
            "finding(s) (SQ-01, SQ-02) — each needs a Status of corrected / closed / fixed.")
    out = "\n".join(dry_run._bullet("!", long))
    for fragment in ("13 unaccounted", "SQ-01", "corrected / closed / fixed"):
        assert fragment in out, f"{fragment!r} was lost when the blocker was rendered"

    for pack in _claimable():
        _c, new, _n = dry_run.latent(pack, str(REPO))
        rendered = dry_run.render(pack, str(REPO))
        for b in new:
            tail = " ".join(b.split())[-25:]
            assert tail in " ".join(rendered.split()), f"{pack}: a blocker was cut before {tail!r}"


def test_it_is_not_deployed_to_production():
    import deploy_tree
    assert not any("dry_run" in str(f) for f in deploy_tree.ROOT_FILES)


if __name__ == "__main__":
    os.chdir(FRAMEWORK)
    fns = [v for k, v in sorted(globals().items()) if k.startswith("test_")]
    for fn in fns:
        fn()
        print(f"ok  {fn.__name__}")
    print(f"\n{len(fns)} tests passed")
