"""governance/ACCEPTANCE_MATRIX.md, executed — the scientist-owned cases, each driven through the real
tools on a disposable copy of this checkout, with the expected outcome written BEFORE the test.

The matrix is the oracle: a row here is claimed only while the test named beside it sees the
expected outcome on the adversarial input. Rows the matrix delegates to another suite are held to
existing by name, so the page cannot cite a test that is not there.

    python3 platform/tests/test_acceptance_matrix.py
"""
import os
import re
import shutil
import subprocess
import sys
import tempfile
import traceback
from pathlib import Path
from types import SimpleNamespace

FRAMEWORK = Path(__file__).resolve().parent.parent
ROOT = FRAMEWORK.parent
TOOLS = FRAMEWORK / "tools"
sys.path.insert(0, str(FRAMEWORK))
sys.path.insert(0, str(TOOLS))

import console                                                              # noqa: E402

PROSTATE = "fixtures/oncology/prostate/202606"
DEMO_XLSX = "sandbox/demo_walkthrough/bladder_202609_program_spec.xlsx"
PERSON = ["--ai-classification", "sponsor_ai_eligible", "--classified-by", "Priya Natarajan",
          "--classified-date", "2026-09-04"]
ENV = dict(os.environ, PYTHONUTF8="1")


def _copy_repo():
    from new_product import copy_stage_tree
    tmp = tempfile.mkdtemp(prefix="matrix_")
    dst = os.path.join(tmp, "repo")
    copy_stage_tree(ROOT, dst)
    return dst


def _new_product(root, *argv):
    p = subprocess.run([sys.executable, str(TOOLS / "new_product.py"), *argv, "--root", root], cwd=root, env=ENV,
                       capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=900)
    return p.returncode, (p.stdout or "") + (p.stderr or "")


def _workbook(out, *subs):
    import openpyxl                                                          # noqa: PLC0415
    wb = openpyxl.load_workbook(str(ROOT / DEMO_XLSX))
    for ws in wb.worksheets:
        for row in ws.iter_rows():
            for c in row:
                if isinstance(c.value, str):
                    v = c.value
                    for old, new in subs:
                        v = v.replace(old, new)
                    c.value = v
    wb.save(out)
    return out


def _rows(*texts):
    return [{"item_id": f"study_population:{i + 2}", "tab": "4.StudyPop", "row": i + 2, "variable": f"INCL{i + 1}",
             "domain": "study_population", "text": t} for i, t in enumerate(texts)]


def _free_family(root):
    """A real tumour family the registry does not carry and no product folder uses, so the row-14
    stand-up cannot collide with a product a person stood up from the runbook's own example
    (thirteenth pass, J1: the test hard-coded `kidney` and went red the moment it existed)."""
    import product_gates as pg                                               # noqa: PLC0415
    reg, _e = pg.read_yaml(os.path.join(root, "governance", "tumour_registry.yaml"))
    taken = set((reg or {}).get("families") or {}) | set((reg or {}).get("aliases") or {})
    for fam in ("kidney", "thymus", "penile", "ureter", "adrenal", "mesothelioma"):
        if fam not in taken and not os.path.isdir(os.path.join(root, "products", "oncology", fam)):
            return fam
    return None


# 1 ------------------------------------------------------------------------------------------------
def _free_slug(root, base):
    """`base`, or base_2, base_3 ... — the first slug and code no product carries (thirteenth pass, J2:
    the row went red once a person stood bladder_flatiron up from the runbook)."""
    import product_gates as pg                                               # noqa: PLC0415
    reg, _e = pg.read_yaml(os.path.join(root, "products", "registry.yaml"))
    taken = {str(t.get("slug")) for t in ((reg or {}).get("tumors") or []) if isinstance(t, dict)}
    taken |= {str(t.get("code")) for t in ((reg or {}).get("tumors") or []) if isinstance(t, dict)}
    for n in range(1, 20):
        slug = base if n == 1 else f"{base}_{n}"
        if slug not in taken and f"{slug[:7]}_fi" not in taken and not os.path.isdir(os.path.join(root, "products", "oncology", slug)):
            return slug
    return None


def test_a_bladder_workbook_stands_a_bladder_product_up():
    root = _copy_repo()
    slug = _free_slug(root, "bladder_flatiron")
    rc, out = _new_product(root, slug, "--tumour-family", "bladder", "--code", slug.replace("flatiron", "fi"),
                           "--name", "Bladder Flatiron", "--vendor", "flatiron", "--tumor-class", "solid",
                           "--spec-version", "202609", "--narrow", "genitourinary", "--condition-class", "oncology",
                           "--modality", "ehr", *PERSON, "--workbook", str(ROOT / DEMO_XLSX), "--apply")
    assert rc == 0 and "WROTE" in out, out[-1500:]
    pack = os.path.join(root, "products", "oncology", slug, "202609")
    assert os.path.isfile(os.path.join(pack, "spec_pipeline", "out", "extracted.json")), "the workbook was extracted"
    assert os.path.isfile(os.path.join(pack, "source_refs.yaml")) and \
        "bladder_202609_program_spec.xlsx" in Path(pack, "source_refs.yaml").read_text(encoding="utf-8")
    shutil.rmtree(os.path.dirname(root), ignore_errors=True)


# 3, 4, 5 ----------------------------------------------------------------------------------------
def test_a_foreign_disease_in_any_spelling_is_refused():
    import spec_lint as sl                                                   # noqa: PLC0415
    for text in ("Adults with NSCLC", "Adults with non-small cell lung cancer", "Adults with Non Small-Cell Lung Cancer",
                 "Adults with metastatic breast cancer", "Patients with a confirmed diagnosis (see protocol)"):
        found = sl.scan_declared_disease(_rows(text), "bladder")
        assert found and found[0]["kind"] == "DECLARED_DISEASE" and found[0]["severity"] == "HIGH", text
    assert sl.scan_declared_disease(_rows("Metastatic urothelial carcinoma (mUC)"), "bladder") == []
    assert sl.scan_declared_disease(_rows("Bladder cancer, muscle-invasive"), "bladder") == []


# 6 ------------------------------------------------------------------------------------------------
def test_a_non_oncology_condition_is_refused_however_it_is_declared():
    import spec_lint as sl                                                   # noqa: PLC0415
    root = _copy_repo()
    base = ["--code", "asthma", "--name", "Asthma", "--vendor", "flatiron", "--tumor-class", "solid",
            "--spec-version", "202609", "--narrow", "thoracic", "--modality", "ehr", *PERSON]
    rc, out = _new_product(root, "asthma_demo", *base, "--condition-class", "asthma", "--disease-terms", "asthma")
    assert rc != 0 and "oncology-configurable only" in out, out[-800:]
    rc, out = _new_product(root, "asthma_demo", *base, "--condition-class", "oncology", "--disease-terms", "asthma")
    assert rc != 0 and "non_oncology_terms" in out and "asthma" in out, out[-800:]
    rc, out = _new_product(root, "resp_cohort", "--code", "resp", "--name", "Respiratory", "--vendor", "flatiron",
                           "--tumor-class", "solid", "--spec-version", "202609", "--narrow", "thoracic", "--modality", "ehr",
                           "--condition-class", "oncology", "--disease-terms", "chronic obstructive pulmonary disease", *PERSON)
    assert rc != 0 and "non_oncology_terms" in out, out[-800:]
    found = sl.scan_declared_disease(_rows("Adults with a confirmed asthma diagnosis"), "bladder")
    assert found and "non-oncology (asthma)" in found[0]["detail"]
    assert not os.path.exists(os.path.join(root, "products", "oncology", "asthma_demo"))
    shutil.rmtree(os.path.dirname(root), ignore_errors=True)


# 7, 8 ---------------------------------------------------------------------------------------------
def test_missing_and_misspelled_scientific_fields_are_refused():
    from engine import config as ec, validate as ev                          # noqa: PLC0415
    with tempfile.TemporaryDirectory() as d:
        shutil.copytree(os.path.join(str(ROOT), PROSTATE), os.path.join(d, "p"))
        cfg = os.path.join(d, "p", "config", "data_product.yaml")
        outc = os.path.join(d, "p", "variables", "outcomes.yaml")
        otext = open(outc, encoding="utf-8").read()
        open(outc, "w", encoding="utf-8").write(re.sub(r"^  exclusion_days: 14[^\n]*\n", "", otext, count=1, flags=re.M))
        for strict in (False, True):
            probs = ev.problems(ec.load_config(cfg), strict=strict)
            assert any("exclusion_days is not declared" in p for p in probs), (strict, probs)
        open(outc, "w", encoding="utf-8").write(otext.replace("exclusion_days: 14", "exclusion_dayz: 14", 1))
        probs = ev.problems(ec.load_config(cfg))
        assert any("unknown key 'exclusion_dayz'" in p and "did you mean 'exclusion_days'" in p for p in probs), probs
        ctext = open(cfg, encoding="utf-8").read()
        open(cfg, "w", encoding="utf-8").write(ctext.replace("cohortn: 1,", "cohortm: 1,", 1).replace("cohortn: 2,", "cohortn: two,", 1))
        probs = ev.problems(ec.load_config(cfg))
        assert any("unknown key 'cohortm'" in p for p in probs) and any("cohortn must be a whole number" in p for p in probs), probs


# 9 ------------------------------------------------------------------------------------------------
def test_a_second_product_of_the_same_tumour_shares_the_shelf_and_keeps_its_own_pack():
    import new_product as npd                                                # noqa: PLC0415
    root = str(ROOT)
    a = SimpleNamespace(slug="bladder_cota", code="bladder_cota", name="Bladder Cota", vendor="flatiron", tumor_class="solid",
                        spec_version="202609", family="oncology", broad=None, narrow="genitourinary",
                        tumour_family="bladder", condition_class="oncology", modality="ehr", disease_terms="",
                        workbook=None, ai_classification="sponsor_ai_eligible", classified_by="Priya Natarajan",
                        classified_date="2026-09-04", next_cut_of=None)
    pack, steps = npd.plan(a, root)
    assert pack == "products/oncology/bladder_cota/202609"
    reg = next(text for rel, _act, text in steps if rel == "products/registry.yaml")
    line = next(ln for ln in reg.splitlines() if "slug: bladder_cota" in ln)
    assert "tumour_key: bladder" in line and "vendor: flatiron" in line, line
    cat = next(text for rel, _act, text in steps if rel.endswith("CATALOGUE.yaml"))
    assert re.search(r"^  bladder_cota:\n(?:.*\n){0,4}    inventory_overlay: bladder$", cat, re.M), "the family's shelf"
    inv = [text for rel, _act, text in steps if rel.endswith("INVENTORY.yaml")]
    assert not inv or re.search(r"^  bladder:\s*$", inv[0], re.M), "the overlay is the tumour's, never the product's"
    own = [rel for rel, _act, _t in steps if rel.startswith(pack + "/")]
    assert any(r.endswith("config/data_product.yaml") for r in own) and any(r.endswith("source_refs.yaml") or True for r in own)
    tr = next(text for rel, _act, text in steps if rel == "governance/tumour_registry.yaml")
    assert re.search(r"^  bladder_cota: bladder$", tr, re.M) and not re.search(r"^  bladder_cota: \[", tr, re.M)
    # Vendor policy still refuses Cota for a solid tumour. Claims can now be
    # registered as a separate draft, routed to the existing claims workbench;
    # it must never acquire the EHR execution route or an approval from registration.
    root = _copy_repo()
    common = ["--tumour-family", "bladder", "--code", "bl2", "--name", "Bladder second", "--tumor-class", "solid",
              "--spec-version", "202609", "--narrow", "genitourinary", "--condition-class", "oncology", *PERSON, "--apply"]
    rc, out = _new_product(root, "bladder_cota", "--vendor", "cota", "--modality", "ehr", *common)
    assert rc != 0 and "REFUSED" in out and "heme" in out and "cota" in out, out[-900:]   # at preview now (thirteenth pass)
    rc, out = _new_product(root, "bladder_claims", "--vendor", "flatiron", "--modality", "claims", *common)
    assert rc == 0 and "WROTE" in out and "Claims cohort workflow" in out, out[-1500:]
    assert "governed claims execution, receipt attestation and release remain unavailable" in out
    assert not os.path.exists(os.path.join(root, "products", "oncology", "bladder_cota"))
    import yaml
    registered = yaml.safe_load(Path(root, "products/registry.yaml").read_text(encoding="utf-8"))
    claim = next(row for row in registered["tumors"] if row["slug"] == "bladder_claims")
    assert claim["modality"] == "claims" and claim["status"] == "scaffold" and claim["tumour_key"] == "bladder"
    activation = yaml.safe_load(Path(root, "products/activation.yaml").read_text(encoding="utf-8"))
    assert "bladder_claims" not in (activation.get("products") or {})
    assert "bladder_claims" not in Path(root, "resources/products.yml").read_text(encoding="utf-8")
    pack = Path(root, "products/oncology/bladder_claims/202609")
    assert (pack / "source_refs.yaml").is_file()
    maturity = yaml.safe_load((pack / "handoff/MATURITY.yaml").read_text(encoding="utf-8"))
    assert maturity["configuration"] == "not_started" and maturity["contract"] == "not_started"
    shutil.rmtree(os.path.dirname(root), ignore_errors=True)


# 10 -----------------------------------------------------------------------------------------------
def test_a_definition_change_requires_a_new_version_and_a_bound_entry():
    import config_diff as cd                                                 # noqa: PLC0415
    root = _copy_repo()
    for args in (["init", "-q", "."], ["config", "user.email", "t@example.invalid"], ["config", "user.name", "T"],
                 ["config", "commit.gpgsign", "false"], ["add", "-A"], ["commit", "-qm", "base"]):
        subprocess.run(["git", "-C", root, *args], check=True, capture_output=True)
    outc = Path(root, PROSTATE, "variables", "outcomes.yaml")
    outc.write_text(outc.read_text(encoding="utf-8").replace("exclusion_days: 14", "exclusion_days: 30", 1), encoding="utf-8")
    found = cd.versioning_findings(PROSTATE, "HEAD", root=root)
    assert found and "no CHANGELOG entry" in found[0]
    log = Path(root, PROSTATE, "CHANGELOG.md")
    log.write_text("- 2026-09-04 none 202606: window tidy (variables/outcomes.yaml)\n", encoding="utf-8")
    found = cd.versioning_findings(PROSTATE, "HEAD", root=root)
    assert found and "MATERIAL" in found[0] and "exclusion_days" in found[0], found
    log.write_text("- 2026-09-04 breaking 202606: rwPFS window 14 -> 30 days (variables/outcomes.yaml)\n", encoding="utf-8")
    found = cd.versioning_findings(PROSTATE, "HEAD", root=root)
    assert found and "NEW spec_version" in found[0] and "--next-cut-of" in found[0], found
    shutil.rmtree(os.path.dirname(root), ignore_errors=True)


# 14 -----------------------------------------------------------------------------------------------
def test_the_next_cut_is_a_draft_beside_the_released_cut():
    import yaml                                                              # noqa: PLC0415
    root = _copy_repo()
    fam = _free_family(root)
    assert fam, "no free tumour family to stand up"
    disease = f"{fam} carcinoma"
    wb1 = _workbook(os.path.join(root, "k1.xlsx"), ("Metastatic urothelial carcinoma diagnosis (mUC)", f"Metastatic {disease} (m{fam[:2].upper()}C)"),
                    ("Inclusion: mUC", f"Inclusion: m{fam[:2].upper()}C"))
    rc, out = _new_product(root, fam, "--code", fam, "--name", fam.capitalize(), "--vendor", "flatiron", "--tumor-class", "solid",
                           "--spec-version", "202609", "--narrow", "genitourinary", "--condition-class", "oncology", "--modality", "ehr",
                           "--disease-terms", f"{disease}, {fam} cancer", *PERSON, "--workbook", wb1, "--apply")
    assert rc == 0 and "WROTE" in out, out[-1200:]
    old = f"products/oncology/{fam}/202609"
    # a byte-identical workbook is a data refresh, not a cut
    rc, out = _new_product(root, fam, "--next-cut-of", old, "--spec-version", "202610", "--workbook", wb1,
                           "--change-class", "additive", *PERSON)
    assert rc != 0 and "byte-identical" in out, out[-800:]
    wb2 = _workbook(os.path.join(root, "k2.xlsx"), ("Metastatic urothelial carcinoma diagnosis (mUC)", f"Metastatic {disease} (m{fam[:2].upper()}C)"),
                    ("Inclusion: mUC", f"Inclusion: m{fam[:2].upper()}C"), ("TBD whether a 60-day gap", "a 60-day gap ends the line; formerly TBD whether a 60-day gap"))
    # another product's slug, an earlier version, a missing class: each refused
    rc, out = _new_product(root, "renal", "--next-cut-of", old, "--spec-version", "202610", "--workbook", wb2, "--change-class", "additive", *PERSON)
    assert rc != 0 and "SAME product" in out, out[-600:]
    rc, out = _new_product(root, fam, "--next-cut-of", old, "--spec-version", "202608", "--workbook", wb2, "--change-class", "additive", *PERSON)
    assert rc != 0 and "not later than" in out, out[-600:]
    rc, out = _new_product(root, fam, "--next-cut-of", old, "--spec-version", "202610", "--workbook", wb2, *PERSON)
    assert rc != 0 and "--change-class" in out, out[-600:]
    # Changing TTD1's definition is breaking, not additive. The refusal must
    # happen before a cut is installed; the author supplies the correct class.
    rc, out = _new_product(root, fam, "--next-cut-of", old, "--spec-version", "202610", "--workbook", wb2,
                           "--change-class", "additive", "--change-note", "TTD1 gap settled", *PERSON, "--apply")
    assert rc != 0 and "TTD1" in out and "breaking" in out, out[-1500:]
    assert not os.path.exists(os.path.join(root, "products", "oncology", fam, "202610"))
    rc, out = _new_product(root, fam, "--next-cut-of", old, "--spec-version", "202610", "--workbook", wb2,
                           "--change-class", "breaking", "--change-note", "TTD1 gap settled", *PERSON, "--apply")
    assert rc == 0 and "WROTE" in out, out[-1500:]
    new = os.path.join(root, "products", "oncology", fam, "202610")
    assert os.path.isfile(os.path.join(new, "spec_pipeline", "out", "extracted.json"))
    cfg = Path(new, "config", "data_product.yaml").read_text(encoding="utf-8")
    assert 'version: "202610.{snapshot}"' in cfg and "condition_class: oncology" in cfg
    assert Path(new, "variables", "outcomes.yaml").read_bytes() == Path(root, old, "variables", "outcomes.yaml").read_bytes(), "carried by copy"
    contract = Path(new, "handoff", "FUNCTIONAL_CONTRACT.md").read_text(encoding="utf-8")
    assert f"{fam.capitalize()} 202610" in contract and "| ECOG |" not in contract, "records never copy"
    reg = yaml.safe_load(Path(root, "products", "registry.yaml").read_text(encoding="utf-8"))
    entry = next(t for t in reg["tumors"] if t["slug"] == fam)
    assert str(entry["current_spec_version"]) == "202609", "current does not move at the start"
    rows = {str(r["spec_version"]): r for r in entry["lineage"]}
    assert rows["202609"]["status"] == "active" and rows["202610"]["status"] == "draft" and str(rows["202610"]["supersedes"]) == "202609"
    log = Path(root, "products", "oncology", fam, "CHANGELOG.md").read_text(encoding="utf-8")
    assert re.search(r"^- 2026-09-04 breaking 202610: next cut of 202609", log, re.M), log
    assert "TTD1 gap settled" in log
    sr = Path(new, "source_refs.yaml").read_text(encoding="utf-8")
    assert "k2.xlsx" in sr and "status: pending" in sr, "the revised workbook is registered fresh, unapproved"
    shutil.rmtree(os.path.dirname(root), ignore_errors=True)


# the delegated rows exist by name ---------------------------------------------------------------
def test_every_delegated_row_names_a_test_that_exists():
    page = (ROOT / "governance" / "ACCEPTANCE_MATRIX.md").read_text(encoding="utf-8")
    here = Path(__file__).read_text(encoding="utf-8")
    for m in re.finditer(r"`(?:(test_[a-z0-9_]+)::)?(test_[a-z0-9_]+)`", page):
        suite, name = m.group(1), m.group(2)
        src = (FRAMEWORK / "tests" / f"{suite}.py").read_text(encoding="utf-8") if suite else here
        assert f"def {name}(" in src, (suite, name)


if __name__ == "__main__":
    console.use_utf8()
    failures = 0
    for name, fn in sorted(globals().items()):
        if name.startswith("test_") and callable(fn):
            try:
                fn()
                print(f"  ok   {name}")
            except Exception:                                                # noqa: BLE001
                failures += 1
                print(f"  FAIL {name}")
                traceback.print_exc()
    print(f"{failures} failure(s)")
    sys.exit(1 if failures else 0)
