"""Repair the actual known-tumour refusal in place without re-entering a researcher's form."""
import contextlib
import io
from pathlib import Path
import sys

import pytest
from streamlit.testing.v1 import AppTest

ROOT = Path(__file__).resolve().parents[2]
sys.path[:0] = [str(ROOT / path) for path in ("experiments/portal", "platform/tools", "platform/tests")]
import new_product
import new_product_recovery as recovery
import session_drafts
import ui_text as ui
from test_epi_portal_journeys import _button_exists, _healthy, _product_command, _portal, _new, _fill_new
from test_epi_new_product_page import PLAN


def _actual_family_collision(existing=True):
    """Use the real read-only registration preflight to reproduce the reported GIST refusal."""
    args = ["gist", "--code", "gist", "--name", "GIST research", "--vendor", "flatiron",
            "--tumor-class", "solid", "--spec-version", "202609", "--narrow", "sarcoma",
            "--condition-class", "oncology", "--modality", "ehr", "--ai-classification", "sponsor_ai_eligible",
            "--classified-by", "Priya", "--classified-date", "2026-09-06", "--root", str(ROOT)]
    args += ["--tumour-family", "gist"] if existing else ["--disease-terms", "gastrointestinal stromal tumour"]
    output = io.StringIO()
    with contextlib.redirect_stderr(output):
        assert new_product.main(args) == 1
    assert "4 problem(s)" in output.getvalue()
    return output.getvalue()


@pytest.mark.parametrize("existing", [False, True])
def test_actual_same_family_refusals_become_one_editable_form_repair(existing):
    output = _actual_family_collision(existing)
    assert recovery.words.family_collision(output)[0] == "gist"
    assert recovery.words.refusal_sentences(output) == ([recovery.words.family_collision_sentence("gist")], 0)
    with _portal() as at:
        _new(at)
        _fill_new(at, np_slug="gist", np_name="GIST research for two studies", np_code="gist" if existing else "gist_custom_code",
                  np_terms="gastrointestinal stromal tumour", np_narrow="sarcoma")
        if existing:
            at.radio(key="np_mode").set_value(ui.NEW_PRODUCT_MODES[1]).run()
            at.selectbox(key="np_family").set_value("gist").run()
        retained = {key: at.session_state[key] for key in
                    ("np_name", "np_ver", "np_vendor", "np_tclass", "np_modality", "np_narrow",
                     "np_cond", "np_by", "np_on", "np_ai", "np_terms", "np_wb2")}
        with _product_command((1, output)) as calls:
            at.button(key="np_preview").click().run()
            _healthy(at)
            assert len(calls) == 1 and "--apply" not in calls[0]
        assert any("1 thing(s) to change" in item.value for item in at.warning)
        assert not _button_exists(at, "np_write")
        entry = next(item for item in at.text_input if item.label == "Distinct product identifier")
        assert entry.value == "" and at.button(key="np_recovery_use_family").disabled
        entry.set_value("gist").run()
        assert at.button(key="np_recovery_use_family").disabled
        entry = next(item for item in at.text_input if item.label == "Distinct product identifier")
        entry.set_value("gist_research_data").run()
        with _product_command((0, PLAN)) as calls:
            at.button(key="np_recovery_use_family").click().run()
            _healthy(at)
            assert not calls, "accepting the repair only changes the form"
        assert at.radio(key="np_mode").value == ui.NEW_PRODUCT_MODES[1]
        assert at.selectbox(key="np_family").value == "gist"
        assert at.text_input(key="np_slug").value == "gist_research_data"
        assert at.text_input(key="np_code").value == ("" if existing else "gist_custom_code")
        assert retained == {key: at.session_state[key] for key in retained}
        assert recovery.KEY in at.session_state and not _button_exists(at, "np_write")
        assert any("Preview the updated plan" in item.value for item in at.info)
        with _product_command((0, PLAN)) as calls:
            at.button(key="np_preview").click().run()
            _healthy(at)
            assert len(calls) == 1 and "--apply" not in calls[0]
            assert calls[0][calls[0].index("--tumour-family") + 1] == "gist"
            assert calls[0][calls[0].index("--code") + 1] == ("gist_research_data" if existing else "gist_custom_code")
        assert recovery.KEY not in at.session_state and _button_exists(at, "np_write")


def test_family_repair_requires_exact_refusal_and_current_registered_family(tmp_path):
    import yaml
    output = _actual_family_collision()
    registry = tmp_path / "governance/tumour_registry.yaml"
    registry.parent.mkdir()
    registry.write_text(yaml.safe_dump({"families": {"renal": ["renal"]}}), encoding="utf-8")
    script = f'''
import subprocess
import streamlit as st
import new_product_recovery as recovery
recovery.capture({str(tmp_path)!r}, 'epi', subprocess.CompletedProcess([], 1, {output!r}, ''), phase='preview')
st.session_state[recovery.KEY]['failure']['sentences'] = []
st.session_state[recovery.KEY]['failure']['untranslated'] = 4
recovery.render({str(tmp_path)!r}, 'epi')
'''
    at = AppTest.from_string(script, default_timeout=30).run()
    assert not at.exception and not _button_exists(at, "np_recovery_use_family")
    assert any("1 thing(s) to change" in item.value for item in at.warning)
    for text in ("Please use --tumour-family gist", output.replace("--tumour-family gist", "--tumour-family renal")):
        assert recovery.words.family_collision(text) == ("", set())


def test_pending_registration_repair_does_not_follow_another_actor():
    state = {"_draft_actor": "alice", "np_code_suggested": "alice_code", "np_slug_suggested": "alice_product",
             "np_mode_suggested": True, "np_family_suggested": "gist"}
    session_drafts.preserve(state, "bob")
    assert not any(key in state for key in ("np_code_suggested", "np_slug_suggested", "np_mode_suggested", "np_family_suggested"))


def test_previous_family_failure_does_not_offer_repair_for_a_different_draft():
    output = _actual_family_collision()
    with _portal() as at:
        _fill_new(_new(at), np_slug="gist", np_name="GIST research", np_terms="gastrointestinal stromal tumour", np_narrow="sarcoma")
        with _product_command((1, output)) as calls:
            at.button(key="np_preview").click().run()
            assert _button_exists(at, "np_recovery_use_family")
            at.text_input(key="np_slug").set_value("renal_research").run()
            _healthy(at)
            assert len(calls) == 1 and not _button_exists(at, "np_recovery_use_family")
            assert _button_exists(at, "np_recovery_edit_all") and _button_exists(at, "np_recovery_ask_chat")
            assert any("previous findings" in item.value for item in at.info)
