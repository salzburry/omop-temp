"""Current, actor-scoped definition progress uses the real lint, not old receipts."""
from pathlib import Path
import json
import sys
from unittest.mock import patch

import pytest

ROOT = Path(__file__).resolve().parents[2]
sys.path[:0] = [str(ROOT / "platform/tests"), str(ROOT / "platform/tools"), str(ROOT / "experiments/portal")]
from test_epi_scientific_definitions import ACTOR, ITEM, fixture, describe, preview, apply, governed_bytes
from test_spec_slice import _resign
import scientific_definitions as definitions


def queue(root, pack, actor=ACTOR):
    result = definitions.work_queue(root, pack, actor, allowed_packs=[pack])
    assert result["ok"], result
    return result


def save(root, pack, values, actor=ACTOR):
    current = definitions.describe(root, pack, actor, item_id=ITEM, allowed_packs=[pack])
    result = definitions.save_draft(root, pack, actor, ITEM, values,
        expected_input_digest=current["input_digest"], expected_draft_digest=current["draft_digest"],
        local_demo=True, can_write=True, allowed_packs=[pack])
    assert result["ok"], result


def test_untouched_then_actor_draft_then_checked_saved_contract(tmp_path):
    root, pack, product, values = fixture(tmp_path)
    original = governed_bytes(product)
    assert queue(root, pack)["counts"] == {"Untouched": 1}
    save(root, pack, values)
    assert queue(root, pack)["counts"] == {"Draft": 1}
    assert queue(root, pack, "another-person")["counts"] == {"Untouched": 1}
    candidate = preview(root, pack, values)
    assert candidate["passed"], candidate
    assert queue(root, pack)["counts"] == {"Draft": 1}, "A preview is not saved progress"
    assert governed_bytes(product) == original
    assert apply(root, pack, candidate)["ok"]
    result = queue(root, pack)
    assert result["counts"] == {"Checked": 1}, result
    assert result["approved"] is False
    assert queue(root, pack, "another-person")["counts"] == {"Checked": 1}
    values["derivation"] = "A newer interpretation awaiting review"
    save(root, pack, values)
    assert queue(root, pack)["counts"] == {"Draft": 1}
    assert queue(root, pack, "another-person")["counts"] == {"Checked": 1}


def test_lint_is_reused_only_while_its_exact_inputs_are_unchanged(tmp_path):
    root, pack, product, values = fixture(tmp_path)
    assert apply(root, pack, preview(root, pack, values))["ok"]
    definitions._queue_lint.cache_clear()
    with patch.object(definitions.cl, "run", wraps=definitions.cl.run) as lint:
        assert queue(root, pack)["counts"] == {"Checked": 1}
        assert queue(root, pack)["counts"] == {"Checked": 1}
        assert lint.call_count == 1
        contract = product / "handoff/FUNCTIONAL_CONTRACT.md"
        contract.write_text(contract.read_text(encoding="utf-8").replace("all cohorts", "TODO"), encoding="utf-8")
        assert queue(root, pack)["counts"] == {"Unresolved": 1}
        assert lint.call_count == 2


@pytest.mark.parametrize("change", ["missing_lint", "invalid_register"])
def test_incomplete_validator_inputs_never_leave_a_checked_count(tmp_path, change):
    root, pack, product, values = fixture(tmp_path)
    assert apply(root, pack, preview(root, pack, values))["ok"]
    assert queue(root, pack)["counts"] == {"Checked": 1}
    if change == "missing_lint":
        (product / "spec_pipeline/out/lint.json").unlink()
    else:
        path = product / "handoff/DECISIONS.md"
        path.write_text(path.read_text(encoding="utf-8").replace("| OPEN |", "| MAYBE |"), encoding="utf-8")
    assert queue(root, pack)["counts"] == {"Unresolved": 1}


@pytest.mark.parametrize("saved", [False, True])
def test_source_change_reopens_saved_record_and_old_actor_draft(tmp_path, saved):
    root, pack, product, values = fixture(tmp_path)
    if saved:
        save(root, pack, values)
    assert apply(root, pack, preview(root, pack, values))["ok"]
    assert queue(root, pack)["counts"] == {"Checked": 1}
    path = product / "spec_pipeline/out/extracted.json"
    document = json.loads(path.read_bytes())
    document["rows"][0]["fields"]["definition"] = "Revised source meaning"
    path.write_text(json.dumps(document), encoding="utf-8")
    _resign(product)
    assert queue(root, pack)["counts"] == {"Unresolved": 1}


def test_open_scientific_question_is_unresolved_even_when_record_checks_pass(tmp_path):
    root, pack, product, values = fixture(tmp_path)
    values["decision_ids"] = ["BIOM-WINDOW"]
    candidate = preview(root, pack, values)
    assert candidate["passed"], candidate
    assert apply(root, pack, candidate)["ok"]
    result = queue(root, pack)
    assert result["counts"] == {"Unresolved": 1}
    assert "scientific question" in result["rows"][0]["work_reason"]


def test_empty_extraction_is_zero_rows_and_no_progress_claim(tmp_path):
    root, pack, product, values = fixture(tmp_path)
    path = product / "spec_pipeline/out/extracted.json"
    document = json.loads(path.read_bytes())
    document["rows"] = []
    path.write_text(json.dumps(document), encoding="utf-8")
    result = queue(root, pack)
    assert result["total"] == 0 and result["rows"] == [] and result["counts"] == {}
    assert result["approved"] is False


def test_corrupt_actor_draft_is_unresolved_and_never_visible_to_other_actor(tmp_path):
    root, pack, product, values = fixture(tmp_path)
    save(root, pack, values)
    path = next((product / ".portal-drafts/definitions").glob("*/*.json"))
    path.write_text('{"approved":true}', encoding="utf-8")
    assert queue(root, pack)["counts"] == {"Unresolved": 1}
    assert queue(root, pack, "other-person")["counts"] == {"Untouched": 1}
    assert not definitions.work_queue(root, pack, ACTOR, allowed_packs=[])["ok"]


@pytest.mark.parametrize("target", ["extraction", "draft"])
def test_deeply_nested_json_is_reported_without_crashing_the_editor(tmp_path, target):
    root, pack, product, values = fixture(tmp_path)
    if target == "draft":
        save(root, pack, values)
        path = next((product / ".portal-drafts/definitions").glob("*/*.json"))
    else:
        path = product / "spec_pipeline/out/extracted.json"
    path.write_text("[" * 2000 + "0" + "]" * 2000, encoding="utf-8")
    result = definitions.work_queue(root, pack, ACTOR, allowed_packs=[pack])
    if target == "draft":
        assert result["counts"] == {"Unresolved": 1}
    else:
        assert not result["ok"] and result["errors"]


def test_draft_changed_during_queue_read_cannot_claim_checked(tmp_path):
    root, pack, product, values = fixture(tmp_path)
    assert apply(root, pack, preview(root, pack, values))["ok"]
    with patch.object(definitions, "_snapshot", side_effect=["before", "after"]):
        result = definitions.work_queue(root, pack, ACTOR, allowed_packs=[pack])
    assert not result["ok"] and "changed" in " ".join(result["errors"])


def test_render_equivalent_draft_values_match_without_promoting_blank_answers():
    left = {"variable_id": "X", "source": {"kind": "constant", "value": "1"}, "depends_on": ["none"], "derivation": "TODO"}
    right = {"variable_id": "X", "source": "{kind: constant, value: 1}", "depends_on": "[none]", "derivation": ""}
    assert definitions.same_answers(left, right)
    left["notes"], right["notes"] = "First line.\nSecond line.", "First line. Second line."
    assert definitions.same_answers(left, right)
    left["source"], right["source"] = {"kind": "constant", "value": "yes"}, "{kind: constant, value: yes}"
    assert definitions.same_answers(left, right)
    right["derivation"] = "An actual new answer"
    assert not definitions.same_answers(left, right)
