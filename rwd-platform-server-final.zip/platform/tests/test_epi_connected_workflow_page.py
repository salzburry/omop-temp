"""Real Streamlit navigation through the shared workflow, including unfinished text."""
from pathlib import Path
import sys

from streamlit.testing.v1 import AppTest

ROOT = Path(__file__).resolve().parents[2]
sys.path[:0] = [str(ROOT / "platform/tests"), str(ROOT / "platform/tools"), str(ROOT / "experiments/portal")]
from test_epi_configuration_proposal_page import fixture, PACK, ACTOR, PARAMETER


def app(root):
    script = f'''
import sys
sys.path[:0] = {[str(ROOT / "platform/tools"), str(ROOT / "experiments/portal")]!r}
import streamlit as st
import connected_workflow_page as navigation
import plan_changes_page
actor = st.selectbox("Test identity", {[ACTOR, "other-editor"]!r}, key="actor")
section = st.radio("Workspace", ["Plan changes", "Flow", "Studies"], key="section")
if navigation.render_active({str(root)!r}, {PACK!r}, actor, section=section, allowed_packs={[PACK]!r},
    local_demo=True, can_write=True, can_review=True, can_view=True, can_pin=True, can_answer=True):
    st.stop()
if section == "Plan changes":
    plan_changes_page.render({str(root)!r}, {PACK!r}, actor_id=actor, local_demo=True, can_write=True, allowed_packs={[PACK]!r})
else:
    if st.button("Propose product settings", key="test_configure"):
        navigation.open_route("plan_changes", {PACK!r}, actor, params={{"intent": "configuration"}})
    navigation.links(("source_requirements", "scientific_draft", "review_workbook"), {PACK!r}, actor, key="test", expanded=True)
'''
    result = AppTest.from_string(script, default_timeout=60).run()
    healthy(result)
    return result


def healthy(at):
    assert not at.exception, [e.message for e in at.exception]


def test_empty_product_plan_starts_with_one_action_and_preserves_context_across_routes(tmp_path):
    fixture(tmp_path)
    at = app(tmp_path)
    assert any("no scientific definitions yet" in x.value for x in at.info)
    assert not at.multiselect and not at.metric
    assert at.button(key="plan_guide_define")
    at.button(key="plan_guide_define").click().run()
    healthy(at)
    assert at.session_state["connected_workflow"]["route"] == "scientific_draft"
    assert at.selectbox(key="scientific_definition_row")
    at.text_area(key="scientific_definition_field_derivation").set_value("Unfinished interpretation; scientific review remains pending.").run()
    healthy(at)
    at.button(key="connected_definition_context_review_workbook").click().run()
    healthy(at)
    assert at.session_state["connected_workflow"]["route"] == "review_workbook"
    at.button(key="review_exchange_build").click().run()
    healthy(at)
    at.button(key="connected_next_scientific_draft").click().run()
    healthy(at)
    assert at.text_area(key="scientific_definition_field_derivation").value.startswith("Unfinished interpretation")
    at.selectbox(key="actor").select("other-editor").run()
    healthy(at)
    assert "connected_workflow" not in at.session_state
    assert at.button(key="plan_guide_define")


def test_guided_settings_show_only_selected_fields_and_stage_a_real_diff(tmp_path):
    import hashlib
    fixture(tmp_path)
    at = app(tmp_path)
    at.radio(key="plan_guide_intent").set_value("configuration").run()
    healthy(at)
    prefix = f"design_{PACK}_"
    assert not any(x.label == "Included sections" for x in at.multiselect)
    assert not at.text_input
    at.text_area(key=prefix + "purpose").set_value("Review a 93-day follow-up threshold for the named study.")
    at.text_area(key=prefix + "studies").set_value("Outcomes")
    at.multiselect(key=prefix + "proposal_selected_settings").set_value([PARAMETER]).run()
    field = hashlib.sha256(PARAMETER.encode()).hexdigest()[:12]
    at.text_input(key=prefix + "proposal_" + field + "_value").set_value("93").run()
    healthy(at)
    assert len(at.text_input) == 1
    at.button(key=f"configuration_stage_{PACK}").click().run()
    healthy(at)
    assert any("Before-and-after configuration diff" in x.value for x in at.markdown)
    assert at.button(key=f"configuration_submit_{PACK}").disabled
    assert not at.button(key=f"configuration_validate_{PACK}").disabled


def test_source_requirements_route_has_forward_navigation_and_returns_to_origin(tmp_path):
    fixture(tmp_path)
    at = app(tmp_path)
    at.radio(key="section").set_value("Flow").run()
    at.button(key="connected_test_source_requirements").click().run()
    healthy(at)
    assert at.button(key="connected_next_source_evidence")
    assert at.button(key="connected_next_source_mapping")
    at.button(key="connected_back").click().run()
    healthy(at)
    assert "connected_workflow" not in at.session_state
    assert at.button(key="connected_test_source_requirements")


def test_question_continuation_selects_the_linked_issued_form(tmp_path):
    from test_epi_decision_answer_page import _seed
    _seed(str(tmp_path), PACK)
    script = f'''
import sys
sys.path[:0] = {[str(ROOT / "platform/tools"), str(ROOT / "experiments/portal")]!r}
import streamlit as st
import connected_workflow_page as navigation
st.session_state.setdefault("connected_workflow", {{"route": "questions", "pack": {PACK!r},
    "actor": {ACTOR!r}, "origin": "Flow", "params": {{"decision_id": "Q2"}}}})
navigation.render_active({str(tmp_path)!r}, {PACK!r}, {ACTOR!r}, section="Flow", allowed_packs={[PACK]!r},
    local_demo=True, can_write=True, can_review=True, can_view=True, can_answer=True)
'''
    at = AppTest.from_string(script, default_timeout=30).run()
    healthy(at)
    assert at.selectbox(key="decision_answer_selected").value == "Q2"
    assert at.text_area(key="decision_answer_Q2_answer").value == ""


def test_portfolio_filters_products_and_opens_the_matching_guided_question(tmp_path):
    from test_epi_decision_answer_page import _seed
    reference = "fixtures/oncology/example/202609"
    _seed(str(tmp_path), PACK)
    _seed(str(tmp_path), reference)
    before = {p.relative_to(tmp_path): p.read_bytes() for p in tmp_path.rglob("*") if p.is_file()}
    script = f'''
import sys
sys.path[:0] = {[str(ROOT / "platform/tools"), str(ROOT / "experiments/portal")]!r}
import streamlit as st
import connected_workflow_page as navigation
suggested = st.session_state.pop("pack_suggested", None)
if suggested:
    st.session_state["test_product"] = suggested
pack = st.selectbox("Product", {[PACK, reference]!r}, key="test_product")
st.session_state.setdefault("connected_workflow", {{"route": "portfolio", "pack": {PACK!r},
    "actor": {ACTOR!r}, "origin": "Home", "params": {{}}}})
navigation.render_active({str(tmp_path)!r}, pack, {ACTOR!r}, section="Home", allowed_packs={[PACK, reference]!r},
    local_demo=True, can_write=True, can_review=True, can_view=True, can_answer=True)
'''
    at = AppTest.from_string(script, default_timeout=30).run()
    healthy(at)
    question_buttons = lambda: [button for button in at.button if button.label == "Help me answer this question"]
    assert len(question_buttons()) == 4
    assert any("guided choices" in message.value for message in at.info)
    at.radio(key="connected_portfolio_scope").set_value("current").run()
    healthy(at)
    assert len(question_buttons()) == 2
    at.radio(key="connected_portfolio_scope").set_value("all").run()
    at.button(key="connected_question_0").click().run()
    healthy(at)
    assert at.selectbox(key="test_product").value == reference
    assert at.selectbox(key="decision_answer_selected").value == "Q1"
    assert at.text_area(key="decision_answer_Q1_answer").value == ""
    assert at.text_input(key="decision_answer_Q1_answered_by").value == ""
    assert at.text_input(key="decision_answer_Q1_answer_date").value == ""
    assert {p.relative_to(tmp_path): p.read_bytes() for p in tmp_path.rglob("*") if p.is_file()} == before


def test_linked_question_prepares_missing_forms_and_continues_in_place(tmp_path):
    from test_epi_decision_answer_page import _seed
    import decision_record as records
    product = _seed(str(tmp_path), PACK)
    for did in ("Q1", "Q2"):
        (product / records.FORMS_DIR / f"{did}.yaml").unlink()
    register_before = (product / records.DECISIONS).read_bytes()
    script = f'''
import sys
sys.path[:0] = {[str(ROOT / "platform/tools"), str(ROOT / "experiments/portal")]!r}
import streamlit as st
import connected_workflow_page as navigation
st.session_state.setdefault("connected_workflow", {{"route": "questions", "pack": {PACK!r},
    "actor": {ACTOR!r}, "origin": "Home", "params": {{"decision_id": "Q2"}}}})
navigation.render_active({str(tmp_path)!r}, {PACK!r}, {ACTOR!r}, section="Home", allowed_packs={[PACK]!r},
    local_demo=True, can_write=True, can_review=True, can_view=True, can_answer=True)
'''
    at = AppTest.from_string(script, default_timeout=30).run()
    healthy(at)
    at.button(key="decision_answer_prepare").click().run()
    healthy(at)
    assert at.selectbox(key="decision_answer_selected").value == "Q2"
    assert at.text_area(key="decision_answer_Q2_answer").value == ""
    assert at.text_input(key="decision_answer_Q2_answered_by").value == ""
    assert at.text_input(key="decision_answer_Q2_answer_date").value == ""
    assert any("Question drafts prepared" in notice.value for notice in at.success)
    assert not any("Answer saved" in notice.value for notice in at.success)
    assert (product / records.DECISIONS).read_bytes() == register_before


def test_configuration_continuation_reselects_settings_after_another_intent(tmp_path):
    fixture(tmp_path)
    at = app(tmp_path)
    at.radio(key="section").set_value("Flow").run()
    at.button(key="test_configure").click().run()
    healthy(at)
    assert at.radio(key="plan_guide_intent").value == "configuration"
    at.radio(key="plan_guide_intent").set_value("definition").run()
    at.button(key="connected_back").click().run()
    at.button(key="test_configure").click().run()
    healthy(at)
    assert at.radio(key="plan_guide_intent").value == "configuration"
