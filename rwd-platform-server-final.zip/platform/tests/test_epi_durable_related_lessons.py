"""AI maintenance proposals bind only the explicitly selected current lessons."""
import json
import sys
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[2]
sys.path[:0] = [str(ROOT / path) for path in ("platform/tests", "experiments/portal", "experiments/agent")]
from test_epi_workflow_durable_preparation import checkout, prepare, CODE, ACTOR
import workflow_durable_fixes as durable
import workflow_skills


def related(root, first, *, skill=None, scope=None, label="Other selected observation"):
    return workflow_skills.learning().propose_correction(root, skill or first["skill"], "The selection changed again.",
        first["right"], label, "Jordan Lee", "Keep another selected row.", scope=scope)


def bindings(root, first, rows):
    return durable._linked(root, first, [row["id"] for row in rows])


def test_explicit_selection_reaches_generation_and_critic_and_is_bound_for_stage(checkout):
    root, first, model, calls = checkout
    second = related(root, first)
    unrelated = related(root, first, label="An unselected observation")
    bound = bindings(root, first, [first, second])
    result = prepare(root, first, linked_ids=list(bound), expected_linked_bindings=bound)
    assert result["linked_bindings"] == bound
    prompt = json.loads(next(call for call in calls if call[0] == "model")[2][0]["content"])
    critique = json.loads(next(call for call in calls if call[0] == "critic")[1]["evidence"])
    assert {row["id"] for row in prompt["selected_lessons"]} == set(bound)
    assert critique["selected_lessons"] == prompt["selected_lessons"]
    assert unrelated["id"] not in json.dumps(prompt)
    proposed = result["prepared"]
    staged = durable.stage(root, ACTOR, first["id"], kind="code", path=CODE, before_text=proposed["before_text"],
        after_text=proposed["after_text"], linked_ids=list(bound), expected_linked_bindings=bound,
        regression_expectation=proposed["rationale"], regression_case=proposed["regression_case"], expected_digest=first["digest"],
        confirmed=True, can_write=True, can_review=True)
    assert staged["proposal"]["linked_bindings"] == bound


@pytest.mark.parametrize("change", ["missing_primary", "other_skill", "other_scope", "stale_binding", "no_binding"])
def test_invalid_or_unreviewed_group_refuses_before_model(checkout, change):
    root, first, model, calls = checkout
    second = related(root, first, skill="answer-decisions" if change == "other_skill" else None,
        scope={"kind": "packs", "packs": ["products/oncology/other/202609"]} if change == "other_scope" else None)
    ids = [first["id"], second["id"]]
    bound = {row["id"]: workflow_skills.learning().correction_content_digest(row) for row in (first, second)}
    if change == "missing_primary": ids.remove(first["id"])
    if change == "stale_binding": bound[second["id"]] = "0" * 64
    if change == "no_binding": bound = None
    with pytest.raises(ValueError):
        prepare(root, first, linked_ids=ids, expected_linked_bindings=bound)
    assert not calls


@pytest.mark.parametrize("when", ["during_request", "before_stage"])
def test_secondary_change_invalidates_proposal_without_staging(checkout, monkeypatch, when):
    root, first, model, calls = checkout
    loop = workflow_skills.learning()
    second = related(root, first)
    bound = bindings(root, first, [first, second])
    def withdraw():
        loop.withdraw_correction(root, second["id"], loop.read_correction(root, second["id"])["digest"], ACTOR)
    if when == "during_request":
        original = model.step
        def step(*args):
            response = original(*args)
            withdraw()
            return response
        monkeypatch.setattr(model, "step", step)
        with pytest.raises(ValueError):
            prepare(root, first, linked_ids=list(bound), expected_linked_bindings=bound)
    else:
        result = prepare(root, first, linked_ids=list(bound), expected_linked_bindings=bound)
        withdraw()
        proposed = result["prepared"]
        with pytest.raises(ValueError):
            durable.stage(root, ACTOR, first["id"], kind="code", path=CODE, before_text=proposed["before_text"],
                after_text=proposed["after_text"], linked_ids=list(bound), expected_linked_bindings=bound,
                regression_expectation=proposed["rationale"], regression_case=proposed["regression_case"],
                expected_digest=first["digest"], confirmed=True, can_write=True, can_review=True)
    assert not loop.read_correction(root, first["id"]).get("durable_history")
