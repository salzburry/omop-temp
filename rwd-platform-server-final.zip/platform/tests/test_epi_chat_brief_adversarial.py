"""Adversarial study-chat transitions with real private storage and scripted replies."""
from pathlib import Path
import sys

import pytest
from streamlit.testing.v1 import AppTest

ROOT = Path(__file__).resolve().parents[2]
sys.path[:0] = [str(ROOT / folder) for folder in ("platform/tests", "experiments/portal", "experiments/agent", "platform/tools")]
import conversation_intake as brief_api
import flow_assistant_page as page
from test_epi_conversation_intake import question, ask, PACK, OTHER, ACTOR

CONNECTION = {"provider_id": "scripted", "model": "synthetic", "connection_id": "one"}


@pytest.fixture
def scope(tmp_path, monkeypatch):
    monkeypatch.delenv("RWDP_STATE_DIR", raising=False)
    (tmp_path / PACK).mkdir(parents=True)
    (tmp_path / OTHER).mkdir(parents=True)
    return tmp_path


def new(root):
    return brief_api.new(root, PACK, ACTOR, allowed_packs=[PACK], connection=CONNECTION, source="source-a")


def save(root, brief):
    return brief_api.save(root, PACK, ACTOR, brief, allowed_packs=[PACK], can_write=True, expected_revision=brief["revision"])


def load(root, source="source-a"):
    return brief_api.load(root, PACK, ACTOR, allowed_packs=[PACK], connection=CONNECTION, source=source)


def test_stale_unbound_mcq_cannot_answer_an_undisplayed_template_question(scope):
    brief = new(scope)
    early = {sid: "A stated study detail" for sid in ("intended_use", "consumers", "population", "index_definition", "inclusion_sequence", "exclusions")}
    brief = save(scope, ask(brief_api.edit(brief, early)))
    changed = load(scope, source="source-b")
    assert changed["pending_question"] is None
    assert brief_api.current_question(changed)["id"] == "baseline_lookback"
    with pytest.raises(ValueError):
        brief_api.resolve_reply(changed, "1B")
    assert changed["state"]["request"]["baseline_lookback"] is None


def test_reissued_same_question_after_source_edit_has_a_new_choice_token(scope):
    brief = ask(brief_api.edit(new(scope), {"source_cut": "EHR delivery A"}))
    old = brief["pending_question"]["token"]
    revised = ask(brief_api.edit(brief, {"source_cut": "Claims delivery B"}))
    assert revised["pending_question"]["token"] != old
    with pytest.raises(ValueError):
        brief_api.resolve_reply(revised, "1B", question_token=old)


def app(root, monkeypatch, handler, source):
    import conversation_examples_page
    import specialist_chat
    import interaction_feedback_page
    monkeypatch.setattr(page, "_provider_words", lambda *_: (CONNECTION, "Scripted assistant"))
    monkeypatch.setattr(page, "_brief_options", lambda *_args, **_kwargs: {
        "connection": CONNECTION, "source": source["value"], "scope_id": ""})
    monkeypatch.setattr(page.fa, "answer", handler)
    monkeypatch.setattr(specialist_chat, "prepare", lambda *_args, **_kwargs: None)
    monkeypatch.setattr(conversation_examples_page, "render", lambda *_args, **_kwargs: None)
    monkeypatch.setattr(interaction_feedback_page, "offer", lambda *_args, **_kwargs: None)
    code = f'''
import streamlit as st
import form_assistance as forms
import flow_assistant_page as page
from test_epi_flow_assistant import _card
forms.begin({str(root)!r}, {PACK!r}, {ACTOR!r}, page="Scientific definition", allowed_packs=[{PACK!r}], can_write=True)
page.render({str(root)!r}, {PACK!r}, card=_card(), actor_id={ACTOR!r}, primary=True,
            metadata_only=True, local_demo=True, can_agent=True, can_write=True, allowed_packs=[{PACK!r}])
forms.field(st.text_area, "Scientific interpretation", key="definition")
forms.finish()
'''
    return AppTest.from_string(code, default_timeout=30).run().run()


def test_not_sure_cannot_autosave_words_from_the_assistants_own_question(scope, monkeypatch):
    pending = question()
    pending["prompt"] = "Should this study include adults with NSCLC?"
    save(scope, ask(brief_api.edit(new(scope), {"population": "Original renal population"}), pending))
    calls = []
    def respond(text, card, **kwargs):
        calls.append(text)
        return {"answer": "We will keep the choice open.", "actions": [], "source": "assistant", "questions": [pending],
                "brief_updates": [{"slot": "population", "value": "adults with NSCLC", "quote": "adults with NSCLC"}]}
    at = app(scope, monkeypatch, respond, {"value": "source-a"})
    assert not at.exception
    at.chat_input[0].set_value("Not sure").run()
    assert not at.exception
    after = load(scope)
    assert after["state"]["request"]["population"] == "Original renal population"
    assert "population" in after["unknown_slots"]
    assert calls == ["Not sure"]
    at.run()
    assert calls == ["Not sure"], "A rerender cannot repeat the model request"


def test_source_change_during_plain_prefill_reply_cannot_copy_stale_fields(scope, monkeypatch):
    source = {"value": "source-a"}
    calls = []
    def respond(text, card, **kwargs):
        calls.append(text)
        public = card["editable_form"]
        source["value"] = "source-b"
        return {"answer": "A proposed interpretation.", "actions": [], "source": "assistant",
                "prefill": {"scope": public["scope"], "fields": [{"id": public["fields"][0]["id"], "value": "Interpretation based on source A"}]}}
    at = app(scope, monkeypatch, respond, source)
    assert not at.exception and at.text_area(key="definition").value == ""
    at.chat_input[0].set_value("Draft this interpretation").run()
    assert not at.exception
    assert at.text_area(key="definition").value == "", "Source changed during model response; no field should be copied"
    assert calls == ["Draft this interpretation"]


def test_explicit_new_disease_request_does_not_search_the_previous_population():
    query = page.fa.retrieval_query("Switch to colorectal cancer instead", brief_terms="population: NSCLC\nsource_cut: EHR delivery A")
    assert "colorectal" in query.casefold()
    assert "nsclc" not in query.casefold()


def test_not_sure_retains_old_wording_without_using_it_as_a_resolved_search_anchor(scope):
    brief = brief_api.edit(new(scope), {"population": "Adults with NSCLC", "source_cut": "EHR delivery A"})
    source_question = question("source_cut")
    source_question["prompt"] = "Which source should this study use?"
    brief = ask(brief, source_question)
    unresolved, _expanded, matched = brief_api.resolve_reply(brief, "Not sure")
    assert matched and unresolved["state"]["request"]["source_cut"] == "EHR delivery A"
    assert "source_cut" in unresolved["unknown_slots"]
    assert "EHR delivery A" not in brief_api.retrieval_context(unresolved)
    assert "NSCLC" in brief_api.retrieval_context(unresolved)
    assert "source_cut" not in brief_api._copy_values(unresolved)
    context = brief_api.model_context(unresolved)
    assert "source_cut" not in context["request"]
    assert context["previous_unresolved"]["source_cut"] == "EHR delivery A"
    assert context["request"]["population"] == "Adults with NSCLC"
