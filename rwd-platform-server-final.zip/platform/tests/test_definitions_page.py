#!/usr/bin/env python3
"""The definitions page assembles, labels honestly, and writes nowhere it must not.

Run: python3 platform/tests/test_definitions_page.py (or pytest).
"""
import os
import sys
import tempfile
from pathlib import Path

FRAMEWORK = Path(__file__).resolve().parent.parent
REPO = FRAMEWORK.parent
sys.path.insert(0, str(FRAMEWORK / "tools"))

import contract_lint as cl                                              # noqa: E402
import definitions_page as dp                                           # noqa: E402

PACK = str(REPO / "fixtures" / "oncology" / "prostate" / "202606")


def test_every_contract_record_renders_exactly_once():
    """The page is the contract rearranged — a record it drops is a definition a stakeholder
    never reviews, and a record it doubles reads as two variables."""
    m = dp.model(PACK)
    page = dp.render(m)
    ids = [cl._scalar(b, "variable_id")
           for b in cl.records(cl.read(os.path.join(PACK, "handoff", "FUNCTIONAL_CONTRACT.md")))]
    ids = [i for i in ids if i]
    assert len(m["rows"]) == len(ids), (len(m["rows"]), len(ids))
    assert page.count('<article class="card"') == len(ids)


def test_a_fixture_pack_renders_under_its_own_banner():
    """The rule: walkthrough output must never be described as clinically approved.
    The banner is derived from the registry role, never asserted by the renderer."""
    m = dp.model(PACK)
    assert m["role"] == "fixture", m["role"]
    page = dp.render(m)
    assert "REFERENCE FIXTURE" in page
    # the phrase may appear exactly once, inside the banner's own negation - anywhere else it
    # would be the claim the banner exists to forbid
    assert page.count("clinically approved") == 1
    assert "Nothing on this page is clinically approved" in page


def test_decision_states_are_read_live_from_the_register():
    """A record citing an OPEN decision must say OPEN — a page that showed a stale state would
    be a second copy of the register, free to diverge."""
    m = dp.model(PACK)
    cited = {(d, s) for r in m["rows"] for d, s in r["decisions"]}
    assert cited, "no record cites a decision — this test would be vacuous"
    states = {s for _d, s in cited}
    assert states <= {"OPEN", "RESOLVED", "WITHDRAWN", "SUPERSEDED", "?"}, states
    assert "OPEN" in states, "every cited decision reads as settled — check the live register"


def test_out_inside_the_checkout_is_refused():
    """repo_hygiene reports every committed page as a saved web page; the refusal is the same
    rule the decision packet documents, enforced rather than remembered."""
    inside = str(REPO / "definitions.html")
    try:
        dp.main([PACK, "--out", inside])
    except SystemExit as exc:
        assert "inside the checkout" in str(exc)
    else:
        raise AssertionError("--out inside the checkout was accepted")
    assert not os.path.exists(inside), "the refusal wrote the file anyway"


def test_rendering_writes_nothing_into_the_pack():
    """Assembly only: the page reads governed files and writes one file where it is told."""
    before = {p for p in Path(PACK).rglob("*")}
    with tempfile.TemporaryDirectory() as tmp:
        rc = dp.main([PACK, "--out", os.path.join(tmp, "defs.html")])
        assert rc == 0
        assert os.path.exists(os.path.join(tmp, "defs.html"))
    assert {p for p in Path(PACK).rglob("*")} == before, "rendering changed the pack"


if __name__ == "__main__":
    import traceback
    failed = 0
    for name, fn in sorted(globals().items()):
        if name.startswith("test_") and callable(fn):
            try:
                fn()
                print(f"  ok  {name}")
            except BaseException:                    # noqa: BLE001
                failed += 1
                print(f"  FAIL {name}")
                traceback.print_exc()
    print(f"{'FAILED' if failed else 'OK'} — {failed} failure(s)")
    sys.exit(1 if failed else 0)
