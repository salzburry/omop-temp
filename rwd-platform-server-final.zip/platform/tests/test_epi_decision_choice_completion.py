"""Guided choices collect the scientist's missing reasoning without placeholder hunting."""
from pathlib import Path
import sys
from unittest.mock import patch

import pytest

ROOT = Path(__file__).resolve().parents[2]
sys.path[:0] = [str(ROOT / "platform/tests"), str(ROOT / "experiments/portal"), str(ROOT / "platform/tools")]
from test_epi_decision_answer_page import _page, _bytes, _save, _statuses, VALUES
from test_epi_portal_journeys import _healthy
import decision_record as dr
import decision_answer_choices as choices


@pytest.mark.parametrize("question,choice", [
    ("Should the baseline window be 30 days or 60 days?", "60 days"),
    ("Is the death date capped at study end?", "Yes"),
])
def test_choice_requires_explanation_then_explicit_draft_and_record_actions(question, choice):
    with _page(question=question) as (at, case):
        before = _bytes(case.root)
        at.selectbox(key="decision_answer_Q1_approach").set_value("Consider: " + choice).run()
        assert at.text_area(key="decision_answer_Q1_answer").value == ""
        assert at.button(key="decision_answer_Q1_use_choice").disabled
        assert at.button(key="decision_answer_save").disabled
        at.text_area(key="decision_answer_Q1_choice_explanation").set_value("Applies to the baseline cohort; use the reviewed protocol window in clinical:1.").run()
        at.button(key="decision_answer_Q1_use_choice").click().run()
        _healthy(at)
        answer = at.text_area(key="decision_answer_Q1_answer").value
        assert question in answer and "Decision: " + choice in answer and "clinical:1" in answer
        assert "TODO" not in answer and _bytes(case.root) == before
        assert not at.text_input(key="decision_answer_Q1_answered_by").value
        for field in ("answered_by", "answer_date"):
            at.text_input(key="decision_answer_Q1_" + field).set_value(VALUES[field])
        at.run()
        _save(at)
        assert _statuses(case)["Q1"] == "RESOLVED" and case.saved == 1
        assert any("ledger evidence saved" in item.value for item in at.success)
        assert (case.product / "handoff/SCIENCE_QUESTIONS.md").is_file()


def test_incomplete_choice_explanation_stays_open_and_custom_answer_is_retained():
    with _page(question="Should the baseline window be 30 days or 60 days?") as (at, case):
        at.text_area(key="decision_answer_Q1_answer").set_value("My existing custom answer.").run()
        at.selectbox(key="decision_answer_Q1_approach").set_value("Consider: 60 days").run()
        at.text_area(key="decision_answer_Q1_choice_explanation").set_value("TODO: confirm population.").run()
        assert at.button(key="decision_answer_Q1_use_choice").disabled
        assert at.button(key="decision_answer_save").disabled
        at.selectbox(key="decision_answer_Q1_approach").set_value(choices.CUSTOM).run()
        assert at.text_area(key="decision_answer_Q1_answer").value == "My existing custom answer."
        assert _statuses(case)["Q1"] == "OPEN"


def test_portal_completion_retry_is_visible_and_never_applies_other_open_drafts():
    with _page() as (at, case):
        from test_epi_decision_answer_page import _fill
        _fill(at)
        at.run()
        with patch.object(dr, "record_event", side_effect=OSError("disk full")):
            _save(at)
        assert _statuses(case) == {"Q1": "RESOLVED", "Q2": "OPEN"}
        assert any("completion" in item.value or "ledger" in item.value for item in at.warning)
        at.button(key="decision_answer_complete").click().run()
        _healthy(at)
        assert _statuses(case) == {"Q1": "RESOLVED", "Q2": "OPEN"}
        assert not any(button.key == "decision_answer_complete" for button in at.button)
        assert any("ranked questions are current" in item.value for item in at.success)
