"""AI explanations are explicit and copy only unsaved question text; no model calls."""
from pathlib import Path
import sys

import pytest

ROOT = Path(__file__).resolve().parents[2]
sys.path[:0] = [str(ROOT / "platform/tests"), str(ROOT / "experiments/portal"), str(ROOT / "platform/tools")]
import decision_answer_ai_page as page
import decision_answers as answers
from test_epi_decision_answer_page import _page, _bytes, _fill, _select, _save, _statuses, VALUES
from test_epi_portal_journeys import _healthy


class OfflineAssistant:
    def __init__(self):
        self.configured = True
        self.source_eligible = True
        self.connection_id = "offline-vscode-connection"
        self.fail_generate = False
        self.fail_accept = False
        self.generated = []
        self.accepted = []

    def describe_availability(self, root, pack, actor_id, decision_id, *, allowed_packs):
        current = answers.describe(root, pack, allowed_packs=allowed_packs)
        return {"ok": current["ok"], "errors": current.get("errors", []), "digest": current["digest"],
            "configured": self.configured, "source_eligible": self.source_eligible,
            "provider": "VS Code", "provider_id": "vscode", "model": "gpt-5-mini", "connection_id": self.connection_id,
            "blocker": "Complete the recorded source-access review before AI help can use this question.",
            "help": "Run RWD Portal: Connect Chat Model in VS Code, then return to this question."}

    def suggest(self, root, pack, actor_id, decision_id, working_answer, **kwargs):
        self.generated.append({"actor": actor_id, "id": decision_id, "answer": working_answer, **kwargs})
        if self.fail_generate:
            return {"ok": False, "errors": ["The connected model could not complete this request."]}
        current = answers.describe(root, pack, allowed_packs=kwargs["allowed_packs"])
        item = next(item for item in current["items"] if item["id"] == decision_id)
        return {"ok": True, "proposal": {
            "explanation": "The question asks which assessment date should govern the rule.",
            "sources": [{"id": "question", "label": "Issued question", "kind": "question", "text": item["question"]}],
            "options": [{"id": "option_1", "label": "Review the latest-date option",
                "answer": "TODO — Draft option for scientific review: Consider the latest assessment date.",
                "support": [{"source_id": "question", "quote": item["question"]}],
                "assumptions": ["The question does not establish whether latest is intended."],
                "questions": ["Which source date and eligible time window should be used?"]},
                {"id": "option_2", "label": "Obtain more evidence first",
                "answer": "TODO — Draft option for scientific review: Resolve the missing source evidence first.",
                "support": [{"source_id": "question", "quote": item["question"]}],
                "assumptions": [], "questions": ["Which evidence settles this question?"]}]
        }}

    def accept(self, root, pack, actor_id, decision_id, working_answer, proposal, option_id, **kwargs):
        self.accepted.append({"actor": actor_id, "id": decision_id, "answer": working_answer, "option": option_id, **kwargs})
        if self.fail_accept:
            return {"ok": False, "errors": ["The model connection changed. Generate fresh options before copying."]}
        option = next(option for option in proposal["options"] if option["id"] == option_id)
        return {"ok": True, "answer": option["answer"] + "\nQuestions still open: " + " ".join(option["questions"]),
                "draft_only": True, "changed": False, "errors": []}


@pytest.fixture
def offline(monkeypatch):
    backend = OfflineAssistant()
    for method in ("describe_availability", "suggest", "accept"):
        monkeypatch.setattr(page.assistant, method, getattr(backend, method))
    return backend


def _generate(at):
    at.button(key=page.PREFIX + "generate").click().run()
    _healthy(at)


def _choose(at, option_id="option_1"):
    next(widget for widget in at.radio if widget.key.startswith(page.PREFIX + "selection_")).set_value(option_id).run()
    _healthy(at)


def test_ai_help_is_explicit_and_options_show_explanation_source_assumptions_and_questions(offline):
    with _page() as (at, case):
        before = _bytes(case.root)
        assert not offline.generated
        assert any("VS Code" in caption.value and "gpt-5-mini" in caption.value for caption in at.caption)
        _generate(at)
        assert len(offline.generated) == 1
        selection = next(widget for widget in at.radio if widget.key.startswith(page.PREFIX + "selection_"))
        assert selection.value is None
        assert at.button(key=page.PREFIX + "copy").disabled
        shown = "\n".join(text.value for text in at.text)
        assert "The question asks which assessment date" in shown
        assert "Issued question [question]" in shown and "Which assessment date?" in shown
        assert "does not establish whether latest is intended" in shown
        assert "Which source date and eligible time window" in shown
        assert _bytes(case.root) == before and case.saved == 0


def test_ai_copy_changes_only_unsaved_answer_preserves_typed_attribution_and_requires_human_recording(offline):
    with _page() as (at, case):
        _fill(at, answer="My earlier unfinished reasoning.")
        at.run()
        before = _bytes(case.root)
        _generate(at)
        assert offline.generated[0]["answer"] == "My earlier unfinished reasoning."
        assert "answered_by" not in offline.generated[0] and "answer_date" not in offline.generated[0]
        _choose(at)
        at.button(key=page.PREFIX + "copy").click().run()
        _healthy(at)
        assert at.text_area(key="decision_answer_Q1_answer").value.startswith("TODO — Draft option")
        assert "Questions still open" in at.text_area(key="decision_answer_Q1_answer").value
        assert at.text_input(key="decision_answer_Q1_answered_by").value == VALUES["answered_by"]
        assert at.text_input(key="decision_answer_Q1_answer_date").value == VALUES["answer_date"]
        assert at.button(key="decision_answer_save").disabled
        assert _statuses(case)["Q1"] == "OPEN" and _bytes(case.root) == before and case.saved == 0
        assert any("unsaved draft" in message.value for message in at.success)
        at.text_area(key="decision_answer_Q1_answer").set_value("Use the latest assessment within the reviewed eligible window, ordered by collected date.").run()
        _save(at)
        assert _statuses(case)["Q1"] == "RESOLVED" and case.saved == 1


def test_ai_copy_never_fills_blank_decision_maker_or_date_and_survives_question_round_trip(offline):
    with _page() as (at, case):
        before = _bytes(case.root)
        _generate(at)
        _choose(at, "option_2")
        at.button(key=page.PREFIX + "copy").click().run()
        copied = at.text_area(key="decision_answer_Q1_answer").value
        _select(at, "Q2")
        _select(at, "Q1")
        assert at.text_area(key="decision_answer_Q1_answer").value == copied
        assert at.text_input(key="decision_answer_Q1_answered_by").value == ""
        assert at.text_input(key="decision_answer_Q1_answer_date").value == ""
        assert _bytes(case.root) == before and not offline.accepted[0].get("saved")


def test_failed_followup_keeps_existing_options_and_unsaved_answer_for_review(offline):
    with _page() as (at, case):
        _fill(at, answer="My unfinished answer before comparing options.")
        at.run()
        before = _bytes(case.root)
        _generate(at)
        first = at.session_state[page.PREFIX + "proposal"]
        offline.fail_generate = True
        at.text_area(key=page.PREFIX + "request").set_value("Make option 2 clearer without deciding the question.")
        _generate(at)
        assert offline.generated[-1]["previous_proposal"] == first
        assert "option 2" in offline.generated[-1]["user_request"]
        assert at.session_state[page.PREFIX + "proposal"] == first
        assert at.text_area(key="decision_answer_Q1_answer").value == "My unfinished answer before comparing options."
        assert not offline.accepted and case.saved == 0
        assert _bytes(case.root) == before
        assert at.error


@pytest.mark.parametrize("change", ["answer", "connection", "question", "actor", "permission", "hosted", "evidence", "scope"])
def test_prior_ai_options_cannot_be_reused_after_context_or_access_changes(offline, change):
    with _page() as (at, case):
        _generate(at)
        _choose(at)
        if change == "answer":
            at.text_area(key="decision_answer_Q1_answer").set_value("A newer human draft.")
        elif change == "connection":
            offline.connection_id = "different-model-connection"
        elif change == "question":
            at.selectbox(key="decision_answer_selected").set_value("Q2")
        elif change == "actor":
            case.actor = "Another scientist"
        elif change == "permission":
            case.can_write = False
        elif change == "hosted":
            case.local_demo = False
        elif change == "scope":
            case.can_view = False
        else:
            contract = case.product / "handoff/FUNCTIONAL_CONTRACT.md"
            contract.write_text(contract.read_text(encoding="utf-8") + "\nChanged requirements\n", encoding="utf-8")
        before = _bytes(case.root)
        at.run()
        _healthy(at)
        assert not any(widget.key and widget.key.startswith(page.PREFIX + "selection_") for widget in at.radio)
        assert not any(widget.key == page.PREFIX + "copy" for widget in at.button)
        assert not offline.accepted and _bytes(case.root) == before and case.saved == 0


def test_source_review_blocker_links_to_progress_and_does_not_misreport_model_configuration(offline):
    offline.source_eligible = False
    offline.configured = False
    with _page() as (at, case):
        assert any("source-access review" in message.value for message in at.info)
        assert at.button(key="connected_decision_ai_source_progress")
        assert not any(widget.key == page.PREFIX + "generate" for widget in at.button)
        assert not offline.generated
        assert not any("Provider:" in caption.value or "No model connected" in caption.value for caption in at.caption)
        assert not any("Connect Chat Model" in message.value for message in at.info)
        assert at.selectbox(key="decision_answer_Q1_approach")
        assert at.text_area(key="decision_answer_Q1_answer")


def test_missing_connection_explains_setup_without_key_input_or_generation(offline):
    offline.configured = False
    with _page() as (at, _case):
        assert any("Assistant connection in the sidebar" in message.value and "specialist requests" in message.value
                   for message in at.info)
        assert any("Connect Chat Model" in message.value for message in at.info)
        assert {widget.label for widget in at.text_input} == {"Decision maker's name", "Decision date", "Question identifier", "Evidence"}
        assert not any(widget.key == page.PREFIX + "generate" for widget in at.button)
        assert not offline.generated


@pytest.mark.parametrize("operation", ["generate", "copy"])
def test_ai_failures_never_claim_a_copied_or_saved_answer(offline, operation):
    with _page() as (at, case):
        before = _bytes(case.root)
        if operation == "generate":
            offline.fail_generate = True
            _generate(at)
        else:
            _generate(at)
            _choose(at)
            offline.fail_accept = True
            at.button(key=page.PREFIX + "copy").click().run()
            _healthy(at)
        assert at.error and not at.success
        assert at.text_area(key="decision_answer_Q1_answer").value == ""
        assert _bytes(case.root) == before and case.saved == 0


def test_regeneration_requires_a_fresh_explicit_option_selection(offline):
    with _page() as (at, _case):
        _generate(at)
        _choose(at)
        _generate(at)
        selection = next(widget for widget in at.radio if widget.key.startswith(page.PREFIX + "selection_"))
        assert selection.value is None
        assert at.button(key=page.PREFIX + "copy").disabled
        assert len(offline.generated) == 2 and not offline.accepted
