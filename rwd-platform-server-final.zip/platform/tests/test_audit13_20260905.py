"""The thirteenth pass: seven human-persona journeys, driven adversarially on disposable copies
(2026-09-05), and what they found. Every case here was red before its fix and states the outcome
a person is owed: a refusal with the reason and nothing written, or the act completed and visible.

    python3 platform/tests/test_audit13_20260905.py
"""
import ast
import hashlib
import json
import os
import re
import shlex
import shutil
import subprocess
import sys
import tempfile
import traceback
from pathlib import Path

FRAMEWORK = Path(__file__).resolve().parent.parent
ROOT = FRAMEWORK.parent
TOOLS = FRAMEWORK / "tools"
ENGINE = FRAMEWORK / "engine"
sys.path.insert(0, str(FRAMEWORK))
sys.path.insert(0, str(TOOLS))
sys.path.insert(0, str(ENGINE))
sys.path.insert(0, str(ROOT / "experiments" / "agent"))
sys.path.insert(0, str(ROOT / "experiments" / "portal"))
os.environ.setdefault("ANTHROPIC_API_KEY", "not-a-key-tests-never-call")

import console                                                              # noqa: E402
import product_gates as pg                                                  # noqa: E402

PROSTATE = "fixtures/oncology/prostate/202606"
PRODUCT = "products/oncology/prostate_study/202606"
ENV = dict(os.environ, PYTHONUTF8="1", ANTHROPIC_API_KEY="not-a-key")
PERSON = ["--ai-classification", "sponsor_ai_eligible", "--classified-by", "Priya Natarajan",
          "--classified-date", "2026-09-04"]
DEMO_XLSX = "sandbox/demo_walkthrough/bladder_202609_program_spec.xlsx"


def _read(rel):
    return (ROOT / rel).read_text(encoding="utf-8")


def _run(argv, cwd, timeout=900):
    p = subprocess.run([sys.executable, *argv], cwd=cwd, env=ENV, capture_output=True, text=True,
                       encoding="utf-8", errors="replace", timeout=timeout)
    return p.returncode, (p.stdout or "") + (p.stderr or "")


def _git(cwd, *args):
    return subprocess.run(["git", "-c", "user.name=T", "-c", "user.email=t@x", *args], cwd=cwd,
                          capture_output=True, text=True, encoding="utf-8", errors="replace")


def _copy_repo(git=True):
    from new_product import copy_stage_tree
    tmp = tempfile.mkdtemp(prefix="a13_")
    dst = os.path.join(tmp, "repo")
    copy_stage_tree(ROOT, dst)
    if git:
        _git(dst, "init", "-q"); _git(dst, "add", "-A"); _git(dst, "commit", "-qm", "base")
    return dst


def _yaml_dump(doc):
    import yaml                                                              # noqa: PLC0415
    return yaml.safe_dump(doc, sort_keys=False, allow_unicode=True)


def _product_entry(lineage=None, **over):
    e = {"code": "pros_s", "name": "Prostate study product", "slug": "prostate_study", "vendor": "flatiron",
         "tumor_class": "solid", "status": "active", "role": "product", "modality": "ehr", "tumour_key": "prostate",
         "condition_class": "oncology", "current_spec_version": "202606", "current_output_table": "rwdp_pros_s_202606"}
    if lineage is not None:
        e["lineage"] = lineage
    e.update(over)
    return e


def _register_product(root, lineage=None, work=None):
    """The prostate reference pack under a PRODUCT slug, registered, in a copy or a minimal root."""
    dst = os.path.join(root, PRODUCT)
    if not os.path.isdir(dst):
        shutil.copytree(str(ROOT / PROSTATE), dst)
    reg = os.path.join(root, "products", "registry.yaml")
    doc, _e = pg.read_yaml(reg) if os.path.exists(reg) else ({}, None)
    doc = doc or {}
    doc["tumors"] = [_product_entry(lineage)]
    if work is not None:
        doc["work"] = work
    os.makedirs(os.path.dirname(reg), exist_ok=True)
    Path(reg).write_text(_yaml_dump(doc), encoding="utf-8")
    return dst


def _minimal_root():
    tmp = tempfile.mkdtemp(prefix="a13m_")
    root = os.path.join(tmp, "repo")
    os.makedirs(os.path.join(root, "work"))
    _register_product(root, lineage=[{"spec_version": "202606", "status": "active"}])
    return root


def _refused(rc, out, *needles):
    assert rc != 0, out[-800:]
    assert "Traceback" not in out, out[-1500:]
    for n in needles:
        assert n in out, (n, out[-1500:])


# ------------------------------------------------------------ protocol_record, claims, request_record

def test_protocol_digest_runs_from_the_command_line():
    """J4#0 / J6#0 / J7#1: `--digest` crashed with UnboundLocalError because the `--new` branch of
    main() imported product_gates locally, making `pg` local to the whole function."""
    src = _read("platform/tools/protocol_record.py")
    tree = ast.parse(src)
    main = next(n for n in ast.walk(tree) if isinstance(n, ast.FunctionDef) and n.name == "main")
    local_imports = [n for n in ast.walk(main) if isinstance(n, (ast.Import, ast.ImportFrom))
                     and any((a.name if isinstance(n, ast.Import) else n.module) == "product_gates" for a in n.names)]
    assert not local_imports, "main() must not shadow the module-level `pg`"
    root = _copy_repo()
    rc, out = _run([str(Path(root, "platform/tools/protocol_record.py")), "--new", "p1"], root)
    assert rc == 0, out
    rc, out = _run([str(Path(root, "platform/tools/protocol_record.py")), "--digest", "p1"], root)
    assert "Traceback" not in out and "UnboundLocalError" not in out, out
    assert rc in (0, 1), out                     # a digest, or a refusal naming the unfilled fields
    assert re.search(r"\b[0-9a-f]{64}\b", out) or "REPLACE_ME" in out, out
    shutil.rmtree(os.path.dirname(root), ignore_errors=True)


def test_a_sealed_request_stays_owned_by_its_record():
    """J6#1: the claims provider asked request_record for a `lineage_entry` it does not have, so the
    live payload omitted the registry citations and every sealed request read as ABANDONED — and
    through releasable() poisoned every product's release verdict."""
    import claims                                                            # noqa: PLC0415
    import request_record as rr                                              # noqa: PLC0415
    root = _minimal_root()
    cites = [{"product": "prostate_study", "spec_version": "202606"}]
    reg = os.path.join(root, "products", "registry.yaml")
    doc, _ = pg.read_yaml(reg)
    doc["work"] = [{"id": "r1", "kind": "request", "title": "r1", "owner": "Priya Natarajan", "cites_release": cites}]
    Path(reg).write_text(_yaml_dump(doc), encoding="utf-8")
    os.makedirs(os.path.join(root, "work", "r1"))
    record = {"request_id": "r1", "title": "t", "question": "q", "status": "answered", "answered_by": "Priya Natarajan",
              "answered_date": "2026-09-04", "answer_sha256": "x", "derivation": {"method": "sql", "reference": "r"},
              "result": {"kind": "descriptive", "summary": "s"}}
    f = os.path.join(root, "work", "r1", "REQUEST.yaml")
    Path(f).write_text(_yaml_dump(record), encoding="utf-8")
    live = claims.request_payload(rr, record, root, f)
    assert live == rr.event_payload(record, cites), "the live payload must carry the registry citations the seal carried"
    assert live["cites_release"] and live["cites_release"] != rr.event_payload(record, [])["cites_release"]
    shutil.rmtree(os.path.dirname(root), ignore_errors=True)


def test_record_event_refuses_to_seal_a_request_whose_citation_is_not_citable():
    """J6#3: `--check` refused the citation (the pack is not releasable) and `--record-event` sealed
    the answer anyway — an immutable event over a request that inherits no approval."""
    import request_record as rr                                              # noqa: PLC0415
    root = _copy_repo()
    _register_product(root, lineage=[{"spec_version": "202606", "status": "active"}],
                      work=[{"id": "r1", "kind": "request", "title": "r1", "owner": "Priya Natarajan",
                             "cites_release": [{"product": "prostate_study", "spec_version": "202606"}]}])
    tool = str(Path(root, "platform/tools/request_record.py"))
    rc, out = _run([tool, "--new", "r1"], root)
    assert rc == 0, out
    path = os.path.join(root, "work", "r1", "REQUEST.yaml")
    doc, _ = pg.read_yaml(path)
    doc.update({"title": "OS in 1L", "question": "median OS?", "requested_by": "Priya Natarajan",
                "requested_date": "2026-09-01", "analyst": "Priya Natarajan", "answered_by": "Priya Natarajan",
                "answered_date": "2026-09-04", "status": "answered", "disclosure": "internal",
                "derivation": {"method": "sql", "reference": "notebooks/os.sql"},
                "result": {"kind": "quantitative", "summary": "median 18.2 months"}})
    Path(path).write_text(_yaml_dump(doc), encoding="utf-8")
    rc, out = _run([tool, "--digest", "r1"], root)
    digest = re.search(r"\b[0-9a-f]{64}\b", out)
    assert rc == 0 and digest, out
    doc["answer_sha256"] = digest.group(0)
    Path(path).write_text(_yaml_dump(doc), encoding="utf-8")
    _git(root, "add", "-A"); _git(root, "commit", "-qm", "r1")
    rc, out = _run([tool, "--check"], root)
    assert rc == 1 and "not citable" in out, out                              # the citation is refused...
    rc, out = _run([tool, "--record-event", "r1"], root)
    assert rc != 0 and "not citable" in out and "sealed" not in out, out       # ...so the seal is too
    assert not list(Path(root, "governance", "events").glob("*/0001-*.yaml")) or \
        all("r1" not in p.read_text(encoding="utf-8") for p in Path(root, "governance", "events").glob("*/0001-*.yaml"))
    shutil.rmtree(os.path.dirname(root), ignore_errors=True)


# ------------------------------------------------------------ new_product

def test_an_impossible_month_is_not_a_cut():
    """J1#1 / J2#1: 202613 was written as a pack folder, a registry cut and a lineage row."""
    assert pg.bad_spec_version("202613") and "month" in pg.bad_spec_version("202613")
    assert pg.bad_spec_version("2026-09") and pg.bad_spec_version("202600") and pg.bad_spec_version("YYYYMM")
    assert pg.bad_spec_version("202609") is None and pg.bad_spec_version("202612") is None
    root = _copy_repo(git=False)
    tool = str(Path(root, "platform/tools/new_product.py"))
    rc, out = _run([tool, "kidney", "--code", "kidney", "--name", "Kidney", "--vendor", "flatiron", "--tumor-class", "solid",
                    "--spec-version", "202613", "--narrow", "genitourinary", "--condition-class", "oncology", "--modality",
                    "ehr", "--disease-terms", "renal cell carcinoma", *PERSON], root)
    _refused(rc, out, "202613", "month")
    assert not os.path.exists(os.path.join(root, "products", "oncology", "kidney"))
    shutil.rmtree(os.path.dirname(root), ignore_errors=True)


def test_a_missing_workbook_is_a_refusal_not_a_traceback():
    """J2#0: --next-cut-of with a mistyped workbook path crashed in filecmp after the 'is not a file'
    problem had already been composed."""
    root = _copy_repo()
    _register_product(root, lineage=[{"spec_version": "202606", "status": "active"}])
    shutil.copy(str(ROOT / DEMO_XLSX), os.path.join(root, PRODUCT, "prog_spec", "old.xlsx"))   # the comparison has a workbook to run on
    tool = str(Path(root, "platform/tools/new_product.py"))
    rc, out = _run([tool, "prostate_study", "--next-cut-of", PRODUCT, "--spec-version", "202609", "--workbook",
                    os.path.join(root, "nowhere.xlsx"), "--change-class", "breaking", *PERSON], root)
    _refused(rc, out, "is not a file")
    shutil.rmtree(os.path.dirname(root), ignore_errors=True)


def test_cota_solid_and_claims_are_refused_at_preview_by_name():
    """Vendor refusals stay clear; the supported claims draft previews without executing or writing."""
    root = _copy_repo(git=False)
    tool = str(Path(root, "platform/tools/new_product.py"))
    base = ["--name", "Kidney", "--spec-version", "202609", "--narrow", "genitourinary", "--condition-class", "oncology",
            "--disease-terms", "renal cell carcinoma", *PERSON]
    rc, out = _run([tool, "kidney", "--code", "kidney", "--vendor", "cota", "--tumor-class", "solid", "--modality", "ehr", *base], root)
    _refused(rc, out, "cota", "heme")
    assert "staged" not in out.lower() or "REFUSED" in out
    registry_before = Path(root, "products/registry.yaml").read_bytes()
    activation_before = Path(root, "products/activation.yaml").read_bytes()
    rc, out = _run([tool, "kidney", "--code", "kidney", "--vendor", "flatiron", "--tumor-class", "solid", "--modality", "claims", *base], root)
    assert rc == 0 and "PLAN for products/oncology/kidney/202609" in out and "preview" in out, out[-1500:]
    assert "Claims cohort workflow" in out and "governed claims execution, receipt attestation and release remain unavailable" in out
    assert not os.path.exists(os.path.join(root, "products/oncology/kidney/202609"))
    assert Path(root, "products/registry.yaml").read_bytes() == registry_before
    assert Path(root, "products/activation.yaml").read_bytes() == activation_before
    assert "remove it, or add its pack" not in out
    shutil.rmtree(os.path.dirname(root), ignore_errors=True)


# ------------------------------------------------------------ spec_diff, status, config_diff

def test_carry_commands_are_shell_quoted():
    """J2#2: carry_commands.txt printed an unquoted plan path; a directory with a space broke the
    'run the commands as printed' instruction."""
    import spec_diff                                                         # noqa: PLC0415
    tmp = tempfile.mkdtemp(prefix="a13 plan ")
    root = os.path.join(tmp, "repo")
    # two cuts of one product with the same records and extraction: every record carries mechanically
    for cut in ("202603", "202606"):
        shutil.copytree(str(ROOT / PROSTATE), os.path.join(root, "fixtures", "oncology", "prostate", cut))
    out_dir = os.path.join(tmp, "carry plans", "plan1")
    res = spec_diff.carry_plan("fixtures/oncology/prostate/202603", PROSTATE, out_dir, root=root)
    assert os.path.isfile(os.path.join(out_dir, "carry_commands.txt")), res
    cmds = Path(out_dir, "carry_commands.txt").read_text(encoding="utf-8")
    lines = [l for l in cmds.splitlines() if "contract_record.py" in l]
    assert lines, cmds
    for l in lines:
        parts = shlex.split(l)
        yaml_args = [p for p in parts if p.endswith(".yaml")]
        assert yaml_args and os.path.isfile(yaml_args[0]), (l, yaml_args)
    shutil.rmtree(tmp, ignore_errors=True)


def test_status_refuses_a_bare_product_folder():
    """J2#7: status.py rendered a full, wrong page ('no contract drafted yet') for
    products/<family>/<slug> — a folder of cuts, not a pack."""
    rc, out = _run([str(TOOLS / "status.py"), "fixtures/oncology/prostate"], str(ROOT))
    _refused(rc, out, "not a pack", "202606")
    assert "Gates passed" not in out


def test_config_diff_refuses_an_absent_pack_and_reads_status_words_as_cosmetic():
    """J3#0: a typo'd pack path printed 'no semantic change' and the versioning gate passed (exit 0).
    J2#6: `status: scaffold -> active` was MATERIAL, so Gate 4's own instruction ('set status: active
    in the same change that approves it') was the versioning gate's refusal."""
    import config_diff as cd                                                 # noqa: PLC0415
    rc, out = _run([str(TOOLS / "config_diff.py"), "products/oncology/prostrate/202606", "--base", "HEAD",
                    "--check-versioning"], str(ROOT))
    _refused(rc, out, "not a pack")
    assert "no semantic change" not in out
    per_file = {"products/oncology/x/202606/config/data_product.yaml": [("changed", "/status", "scaffold -> active")],
                "products/oncology/x/202606/variables/outcomes.yaml": [("changed", "/progression/exclusion_days", "14 -> 28")]}
    material = cd.material_changes(per_file)
    assert all(p != "/status" for _f, _k, p in material) and any(p.endswith("exclusion_days") for _f, _k, p in material)


def test_the_versioning_gate_lets_a_draft_cut_be_revised():
    """J2#5: the gate keyed on the PRODUCT's registry status and never read the cut's lineage status,
    so every revision of the carried YAML on a draft cut was 'stand the next YYYYMM up'."""
    import config_diff as cd                                                 # noqa: PLC0415
    tmp = tempfile.mkdtemp(prefix="a13v_")
    root = os.path.join(tmp, "repo")
    os.makedirs(root)
    shutil.copytree(str(ROOT / PROSTATE), os.path.join(root, PRODUCT))
    for lineage_status in ("draft", "active"):
        Path(root, "products", "registry.yaml").write_text(_yaml_dump({"tumors": [_product_entry(
            [{"spec_version": "202603", "status": "superseded"}, {"spec_version": "202606", "status": lineage_status}])]}),
            encoding="utf-8")
        if lineage_status == "draft":
            _git(root, "init", "-q"); _git(root, "add", "-A"); _git(root, "commit", "-qm", "base")
        else:
            _git(root, "add", "-A"); _git(root, "commit", "-qm", "registry")
        p = Path(root, PRODUCT, "variables", "outcomes.yaml")
        p.write_text(p.read_text(encoding="utf-8").replace("exclusion_days: 14", "exclusion_days: 21"), encoding="utf-8")
        errs = cd.versioning_findings(PRODUCT, "HEAD", root)
        if lineage_status == "draft":
            assert errs == [], errs                                           # an unreleased cut is revised freely
        else:
            assert errs and "CHANGELOG" in errs[0], errs
        p.write_text(p.read_text(encoding="utf-8").replace("exclusion_days: 21", "exclusion_days: 14"), encoding="utf-8")
    shutil.rmtree(tmp, ignore_errors=True)


# ------------------------------------------------------------ people and dates

def test_angle_bracket_placeholders_are_not_people():
    """J3#7: NEW_TUMOUR.md's own `--classified-by "<your name>"` was accepted as a person."""
    import person_rules as pr                                                # noqa: PLC0415
    for v in ("<your name>", "<name>", "< a person >"):
        assert pr.not_a_person(v) and "placeholder" in pr.not_a_person(v), v
    assert pr.not_a_person("Priya Natarajan") is None


def test_attestation_dates_cannot_be_in_the_future():
    """J1#0 / J7#0: 2027-01-01 was accepted as a classification date, an approval date, an answer date
    and a pin date — then hash-bound into the ledger. A waiver EXPIRY may still lie ahead."""
    assert pg.bad_date("2027-01-01") and "future" in pg.bad_date("2027-01-01")
    assert pg.bad_date("2027-01-01", future_ok=True) is None
    assert pg.bad_date("2026-09-04") is None and pg.bad_date("2026-02-30")
    root = _minimal_root()
    os.makedirs(os.path.join(root, "work", "s1")); Path(root, "work", "s1", "PROTOCOL.yaml").write_text("protocol_id: s1\nstatus: draft\n", encoding="utf-8")
    rc, out = _run([str(TOOLS / "study_pin.py"), "s1", "--pin", PRODUCT, "--pinned-by", "Priya Natarajan",
                    "--pinned-date", "2027-01-01", "--root", root], root)
    _refused(rc, out, "--pinned-date", "future")
    assert not os.path.exists(os.path.join(root, "work", "s1", "PINS.yaml"))
    src = _read("platform/tools/product_gates.py")
    i = src.index("Waiver expires")
    assert "bad_date(got, future_ok=True)" in src[i:], "the waiver expiry is the one date allowed to lie ahead"
    shutil.rmtree(os.path.dirname(root), ignore_errors=True)


# ------------------------------------------------------------ study_pin

def test_study_pins_hold_chronology_closure_root_and_concurrency():
    """J4#1..#4: a decision dated before its pin; a revision ending a decision before it was made;
    decisions on a CLOSED protocol's standing pin; --check green against a --root that is no checkout;
    and twelve concurrent --decide calls printing 'wrote' while losing nine of them."""
    tool = str(TOOLS / "study_pin.py")
    root = _minimal_root()
    for sid, status in (("s1", "draft"), ("pc", "registered")):
        os.makedirs(os.path.join(root, "work", sid))
        Path(root, "work", sid, "PROTOCOL.yaml").write_text(f"protocol_id: {sid}\nstatus: {status}\n", encoding="utf-8")
    reg = os.path.join(root, "products", "registry.yaml")
    doc, _ = pg.read_yaml(reg)
    doc["work"] = [{"id": "pc", "kind": "protocol", "title": "pc", "owner": "Priya Natarajan",
                    "cites_release": [{"product": "prostate_study", "spec_version": "202606"}]}]
    Path(reg).write_text(_yaml_dump(doc), encoding="utf-8")
    who = ["--decided-by", "Priya Natarajan"]
    assert _run([tool, "s1", "--pin", PRODUCT, "--pinned-by", "Priya Natarajan", "--pinned-date", "2026-09-05", "--root", root], root)[0] == 0
    rc, out = _run([tool, "s1", "--decide", PRODUCT, "--variable", "ECOG", "--decision", "reuse", "--why", "w", *who,
                    "--decided-date", "2026-09-01", "--root", root], root)
    _refused(rc, out, "2026-09-01", "before", "pinned")
    assert _run([tool, "s1", "--decide", PRODUCT, "--variable", "ECOG", "--decision", "reuse", "--why", "w", *who,
                 "--decided-date", "2026-09-06", "--root", root], root)[0] == 0
    rc, out = _run([tool, "s1", "--decide", PRODUCT, "--variable", "ECOG", "--decision", "exclude", "--why", "w", *who,
                    "--decided-date", "2026-09-05", "--revise", "--root", root], root)
    _refused(rc, out, "2026-09-05", "before", "2026-09-06")
    rc, out = _run([tool, "s1", "--refresh", PRODUCT, "--reviewed-by", "Priya Natarajan", "--reviewed-date", "2026-09-01", "--root", root], root)
    _refused(rc, out, "before")
    # a closed protocol: the pin stands, new decisions and refreshes are new work and refused; --check says so
    assert _run([tool, "pc", "--pin", PRODUCT, "--pinned-by", "Priya Natarajan", "--pinned-date", "2026-09-05", "--root", root], root)[0] == 0
    Path(root, "work", "pc", "PROTOCOL.yaml").write_text("protocol_id: pc\nstatus: closed\nclosed_by: Priya Natarajan\nclosed_date: 2026-09-06\n", encoding="utf-8")
    rc, out = _run([tool, "pc", "--decide", PRODUCT, "--variable", "ECOG", "--decision", "reuse", "--why", "w", *who,
                    "--decided-date", "2026-09-07", "--root", root], root)
    _refused(rc, out, "CLOSED", "no new work")
    rc, out = _run([tool, "pc", "--refresh", PRODUCT, "--reviewed-by", "Priya Natarajan", "--reviewed-date", "2026-09-07", "--root", root], root)
    _refused(rc, out, "CLOSED")
    p = Path(root, "work", "pc", "PINS.yaml")
    p.write_text(p.read_text(encoding="utf-8") + "  definitions:\n  - variable_id: ECOG\n    decision: reuse\n    why: w\n"
                 "    decided_by: Priya Natarajan\n    decided_date: 2026-09-08\n", encoding="utf-8") if "definitions: []" not in p.read_text(encoding="utf-8") else \
        p.write_text(p.read_text(encoding="utf-8").replace("definitions: []", "definitions:\n  - variable_id: ECOG\n    decision: reuse\n    why: w\n"
                     "    decided_by: Priya Natarajan\n    decided_date: 2026-09-08"), encoding="utf-8")
    rc, out = _run([tool, "--check", "--root", root], root)
    assert rc == 1 and "closed" in out.lower() and "2026-09-08" in out, out
    # a --root that is not a checkout is refused, not reported green
    for bad in (os.path.join(root, "nowhere"), os.path.join(root, "products", "registry.yaml"), tempfile.mkdtemp(prefix="a13e_")):
        rc, out = _run([tool, "--check", "--root", bad], root)
        _refused(rc, out, "not a checkout")
    # twelve writers at once: every 'wrote' is in the record, and nobody sees a traceback
    known = sorted(__import__("study_pin").contract_variables(os.path.join(root, PRODUCT)))[:12]
    procs = [subprocess.Popen([sys.executable, tool, "s1", "--decide", PRODUCT, "--variable", v, "--decision", "reuse",
                               "--why", "w", *who, "--decided-date", "2026-09-06", "--root", root],
                              cwd=root, env=ENV, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, encoding="utf-8")
             for v in known if v != "ECOG"]
    outs = [(p.wait(), p.communicate()[0]) for p in procs]
    assert all("Traceback" not in o for _rc, o in outs), [o[-300:] for _rc, o in outs if "Traceback" in o]
    wrote = {v for (rc_, o), v in zip(outs, [v for v in known if v != "ECOG"]) if rc_ == 0 and "wrote" in o}
    doc, err = __import__("study_pin").load("s1", root)
    assert err is None
    recorded = {d["variable_id"] for d in doc["pins"][0]["definitions"]}
    assert wrote <= recorded, (sorted(wrote - recorded), "printed 'wrote' but lost")
    assert len(wrote) >= 8, outs
    shutil.rmtree(os.path.dirname(root), ignore_errors=True)


# ------------------------------------------------------------ the engine's config path

def _validate(pack_dir, *flags):
    return _run([str(ENGINE / "validate.py"), pack_dir, *flags], str(ROOT), timeout=300)


def test_validate_refuses_undeclared_or_mistyped_outcome_scalars():
    """J3#1 (P0) ttd_from_line defaulted to 1; J3#2 censor.aggregate typo read as max; J3#3 the
    follow-up gate, months divisor, recency window and OS anchors unvalidated; J3#5 the documented
    `semantics` seam refused as unknown; J3#6 a window ending before it starts; J3#9 a quoted boolean
    read backwards. Missing scientific values block; they never default."""
    tmp = tempfile.mkdtemp(prefix="a13e_")
    pack = os.path.join(tmp, "202606")
    shutil.copytree(str(ROOT / PROSTATE), pack)
    oc = Path(pack, "variables", "outcomes.yaml")
    base = oc.read_text(encoding="utf-8")
    rc, out = _validate(pack)
    assert rc == 0, out
    def _line(key, new):
        # the whole line, comment and all: the fixtures annotate their values
        return re.sub(rf"^(\s*){re.escape(key)}:.*$", (lambda m: m.group(1) + new if new else ""), base, count=1, flags=re.M)
    cases = [
        (_line("ttd_from_line", ""), "ttd_from_line", "not declared"),
        (_line("ttd_from_line", "ttd_from_line: zero"), "ttd_from_line", "whole number"),
        (base.replace("aggregate: max", "aggregate: mni"), "aggregate", "min | max"),
        (base.replace("aggregate: max", "aggregate: MIN"), "aggregate", "min | max"),
        (_line("min_followup_days", ""), "min_followup_days", "not declared"),
        (_line("min_followup_days", "min_followup_days: -91"), "min_followup_days", ">= 0"),
        (_line("min_followup_days", "min_followup_days: ninety-one"), "min_followup_days", "whole number"),
        (_line("days_per_month", ""), "days_per_month", "not declared"),
        (_line("visit_recency_days", "visit_recency_days: 120 days"), "visit_recency_days", "whole number"),
        (_line("censor_anchor", ""), "censor_anchor", "not declared"),
        (base.replace("line_cohorts_only: true", 'line_cohorts_only: "false"'), "line_cohorts_only", "true/false"),
    ]
    for text, key, why in cases:
        assert text != base, key
        oc.write_text(text, encoding="utf-8")
        rc, out = _validate(pack)
        assert rc != 0 and key in out and why in out, (key, why, out[-1200:])
    oc.write_text(base.replace("  exclusion_days: 14", "  exclusion_days: 14\n  semantics: contract", 1), encoding="utf-8")
    rc, out = _validate(pack)
    assert rc == 0, out                                                     # the documented seam validates
    oc.write_text(base.replace("  exclusion_days: 14", "  exclusion_days: 14\n  semantics: contracts", 1), encoding="utf-8")
    rc, out = _validate(pack)
    assert rc != 0 and "semantics" in out and "incumbent | contract" in out, out
    oc.write_text(base, encoding="utf-8")
    dp = Path(pack, "config", "data_product.yaml")
    d0 = dp.read_text(encoding="utf-8")
    assert 'index_end: "2026-04-30"' in d0
    dp.write_text(d0.replace('index_end: "2026-04-30"', 'index_end: "2010-04-30"'), encoding="utf-8")
    rc, out = _validate(pack)
    assert rc != 0 and "index_end" in out and "precedes" in out, out
    dp.write_text(d0, encoding="utf-8")
    # the engine itself never defaults the line: no `.get("ttd_from_line", 1)` remains
    eng = _read("platform/engine/stages/outcomes.py")
    assert 'get("ttd_from_line", 1)' not in eng and "ttd_from_line" in eng
    assert 'if ccfg.get("aggregate") == "min" else F.max' not in eng
    shutil.rmtree(tmp, ignore_errors=True)


def test_strict_yaml_refuses_octal_and_underscore_integers():
    """J3#4: `exclusion_days: 014` loaded as 12 and `cohortn: 010` as 8 — YAML 1.1 octal — with
    nothing at validation time saying the typed text and the loaded value differ."""
    import strict_yaml as sy                                                 # noqa: PLC0415
    import yaml                                                              # noqa: PLC0415
    for text in ("exclusion_days: 014\n", "cohorts:\n  - cohortn: 010\n", "days: 0x1f\n", "n: 1_000\n", "b: 0b101\n"):
        try:
            sy.strict_load(text)
        except yaml.YAMLError as e:
            assert "plainly" in str(e) or "would load as" in str(e), str(e)
        else:
            raise AssertionError(f"accepted: {text!r}")
    assert sy.strict_load("a: 0\nb: 14\nc: '014'\nd: 2026-09-05\ne: 202606\nf: 30.4375\ng: -91\n") == \
        {"a": 0, "b": 14, "c": "014", "d": __import__("datetime").date(2026, 9, 5), "e": 202606, "f": 30.4375, "g": -91}
    # ...and the same text inside a literal or folded block is prose YAML never re-types: an answer
    # form's `answer: |` holding "0x10" was refused by the first, line-based guard (proposals suite).
    assert sy.strict_load("answer: |2-\n  0x10\n")["answer"] == "0x10"
    assert sy.strict_load("note: >\n  014 days\n")["note"] == "014 days\n"
    assert sy.strict_load('q: "0x10"\n')["q"] == "0x10"


# ------------------------------------------------------------ dry_run, decision_record, contract_lint, template seed

def test_dry_run_neither_leaks_an_errno_nor_contradicts_the_page():
    """J1#3: the dry run copies only the pack, so the identity audit inside the copy printed
    `[Errno 2] ... governance/allowed_signers.yaml` and called a committed approval uncommitted."""
    rc, out = _run([str(TOOLS / "dry_run.py"), PROSTATE], str(ROOT), timeout=600)
    assert "[Errno" not in out and "Traceback" not in out, out[-1500:]
    assert "it is uncommitted" not in out, out[-1500:]
    src = _read("platform/tools/dry_run.py")
    assert "not authenticated" in src.split("def latent")[1], "identity lines from the copy are set aside and said so"


def test_decision_forms_resolve_pack_relative_paths_and_refuse_to_seal_drift():
    """J7#7: `--apply handoff/decision_answers/X.yaml` (the path the tool itself prints) raised
    FileNotFoundError. J7#8: `--record-event` sealed a SECOND object for a form that no longer says
    what its register row says, leaving the ledger red."""
    root = _copy_repo()
    tool = str(Path(root, "platform/tools/decision_record.py"))
    rc, out = _run([tool, PROSTATE, "--forms"], root)
    assert rc == 0, out
    forms = sorted(Path(root, PROSTATE, "handoff", "decision_answers").glob("*.yaml"))
    assert forms, out
    form = forms[0]
    did = form.stem
    rc, out = _run([tool, PROSTATE, "--apply", f"handoff/decision_answers/{form.name}"], root)
    assert "Traceback" not in out and "FileNotFoundError" not in out, out[-1200:]
    assert rc != 0 and ("resolved" in out.lower() or "unfilled" in out.lower() or "blank" in out.lower() or "REFUSED" in out), out[-800:]
    doc, _ = pg.read_yaml(str(form))
    doc.update({"answer": "Index is the first line start on or after 2011-01-01.", "answered_by": "Priya Natarajan",
                "answer_date": "2026-09-04"})
    form.write_text(_yaml_dump(doc), encoding="utf-8")
    rc, out = _run([tool, PROSTATE, "--apply", str(form.relative_to(root))], root)
    assert rc == 0 and "recorded" in out, out[-1200:]
    _git(root, "add", "-A"); _git(root, "commit", "-qm", "answer")
    doc, _ = pg.read_yaml(str(form))
    doc["answer"] = "A different answer, edited by hand after the register was written."
    form.write_text(_yaml_dump(doc), encoding="utf-8")
    rc, out = _run([tool, PROSTATE, "--check"], root)
    assert rc != 0 and "does not say what" in out, out[-800:]
    before = sorted(p.name for p in Path(root, "governance", "events").glob("*"))
    rc, out = _run([tool, PROSTATE, "--record-event", did], root)
    _refused(rc, out, "does not say what")
    assert "sealed" not in out
    assert sorted(p.name for p in Path(root, "governance", "events").glob("*")) == before, "no second object"
    shutil.rmtree(os.path.dirname(root), ignore_errors=True)


def test_an_empty_contract_passes_its_own_tests_and_may_be_seeded():
    """J7#3: a freshly stood-up pack's own test suite failed I8 ('no extracted.json') on a contract
    with zero records, and the named fix was refused by Gate 1 (no workbook yet). J7#9: --seed
    refused the deliberately empty contract and advised deleting it."""
    import contract_lint as cl                                               # noqa: PLC0415
    root = _copy_repo(git=False)                       # the pack's own test locates the lint tool above it
    pack = os.path.join(root, "products", "oncology", "kidney", "202609")
    shutil.copytree(str(FRAMEWORK / "TUMOR_TEMPLATE"), pack, ignore=shutil.ignore_patterns("NEW_TUMOUR.md", "__pycache__"))
    rc, out = _run([str(Path(root, "platform", "tools", "contract_lint.py")), pack], root)
    assert rc == 0 and "I8" not in out, out[-1500:]
    rc, out = _run([str(Path(pack, "handoff", "tests", "test_functional_contract.py"))], root)
    assert rc == 0, out[-1500:]
    tmp = os.path.dirname(root)
    src = _read("platform/tools/template_reconcile.py")
    assert "remove it if this cancer genuinely has none" not in src, "an empty contract is seeded, not deleted"
    shutil.rmtree(tmp, ignore_errors=True)


# ------------------------------------------------------------ tools that crashed where siblings refuse

def test_spark_tools_refuse_without_pyspark_and_missing_profiles_are_refused():
    """J7#4 / J7#5 / J7#6: mapping_benchmark.py, eda_report.py --synthetic and
    propose_source_mapping.py --profile <missing> printed Python tracebacks."""
    try:
        import pyspark                                                       # noqa: F401, PLC0415
        has_spark = True
    except ImportError:
        has_spark = False
    if not has_spark:
        for argv in (["mapping_benchmark.py"], ["eda_report.py", PROSTATE, "--synthetic", "--out-dir", tempfile.mkdtemp()]):
            rc, out = _run([str(TOOLS / argv[0]), *argv[1:]], str(ROOT), timeout=300)
            _refused(rc, out, "pyspark")
            assert "pip install" in out, out
    rc, out = _run([str(TOOLS / "propose_source_mapping.py"), PROSTATE, "--profile",
                    os.path.join(tempfile.mkdtemp(), "MAPPING_EVIDENCE.json")], str(ROOT), timeout=300)
    _refused(rc, out, "no profile at")


def test_make_inputs_refuses_before_writing():
    """J7#12: make_inputs.py wrote the workbook and bindings into the checkout, then refused --out."""
    root = _copy_repo(git=False)
    rc, out = _run([str(Path(root, "platform/uat/cohortly/make_inputs.py")), "--out", "platform/uat/cohortly/tmp_inside"], root)
    _refused(rc, out, "inside the checkout")
    assert not os.path.exists(os.path.join(root, "platform", "uat", "cohortly", "tmp_inside"))
    shutil.rmtree(os.path.dirname(root), ignore_errors=True)


# ------------------------------------------------------------ the stand-up leaves CI green

def test_the_stand_up_leaves_every_ci_page_current():
    """J7#2: `--apply` said every validator passed, then inventory_coverage --check, citation_register
    --check and tests/test_variable_inventory.py were red on the files it never regenerated."""
    root = _copy_repo(git=False)
    rc, out = _run([str(Path(root, "platform/tools/new_product.py")), "kidney", "--code", "kidney", "--name", "Kidney",
                    "--vendor", "flatiron", "--tumor-class", "solid", "--spec-version", "202609", "--narrow", "genitourinary",
                    "--condition-class", "oncology", "--modality", "ehr", "--disease-terms", "renal cell carcinoma, kidney cancer",
                    *PERSON, "--apply"], root)
    assert rc == 0 and "WROTE" in out, out[-1500:]
    for argv in (["platform/tools/inventory_coverage.py", "--check"], ["platform/tools/citation_register.py", "--check"],
                 ["platform/tools/registry_enrich.py", "--check"]):
        rc, out = _run([str(Path(root, argv[0])), *argv[1:]], root)
        assert rc == 0, (argv, out[-1200:])
    rc, out = _run(["tests/test_variable_inventory.py"], os.path.join(root, "platform"))
    assert rc == 0, out[-1500:]
    shutil.rmtree(os.path.dirname(root), ignore_errors=True)


# ------------------------------------------------------------ identity: the ledger and the audit

def test_the_ledger_does_not_inherit_identity_across_a_copy():
    """J6#2: git's history follow attributed a copied fixture file's object_uuid to the new product,
    so the copy was told to 'restore' a uuid that would then be 'claimed by 2 records'."""
    import event_ledger as el                                                # noqa: PLC0415
    tmp = tempfile.mkdtemp(prefix="a13l_")
    src = os.path.join(tmp, "fixtures", "oncology", "prostate", "202606", "source_refs.yaml")
    os.makedirs(os.path.dirname(src))
    body = "".join(f"field_{i}: value {i} of a registration record long enough for git to call the copy a copy\n" for i in range(40))
    Path(src).write_text("object_uuid: 11111111-1111-4111-8111-111111111111\nspec_version: '202606'\n" + body, encoding="utf-8")
    _git(tmp, "init", "-q"); _git(tmp, "add", "-A"); _git(tmp, "commit", "-qm", "fixture")
    copy = os.path.join(tmp, "products", "oncology", "prostate_study", "202606", "source_refs.yaml")
    os.makedirs(os.path.dirname(copy))
    Path(copy).write_text("spec_version: '202606'\n" + body, encoding="utf-8")
    _git(tmp, "add", "-A"); _git(tmp, "commit", "-qm", "a new product, copied by hand")
    assert el.first_committed_object_uuid(tmp, "products/oncology/prostate_study/202606/source_refs.yaml") is None
    # the same pack moving between the two roots keeps its identity (audit 11's physical half)
    moved = os.path.join(tmp, "products", "oncology", "prostate", "202606", "source_refs.yaml")
    os.makedirs(os.path.dirname(moved))
    _git(tmp, "mv", "fixtures/oncology/prostate/202606/source_refs.yaml", "products/oncology/prostate/202606/source_refs.yaml")
    _git(tmp, "commit", "-qm", "moved")
    assert el.first_committed_object_uuid(tmp, "products/oncology/prostate/202606/source_refs.yaml") == "11111111-1111-4111-8111-111111111111"
    shutil.rmtree(tmp, ignore_errors=True)


def test_a_hand_copy_with_the_uuid_intact_is_told_it_is_a_copy_and_can_seal_its_own_genesis():
    """J6#2, the half the verifiers found still open: the NATURAL hand copy — cp -r and commit with
    the fixture's object_uuid intact — looped. claims said 'drop the copied uuid and seal your own
    genesis'; the drop was refused with 'history records an object_uuid this record no longer carries
    — restore it'; restoring recreated the two-owner collision. Only a history rewrite or a fresh
    path exited. Ownership is now decided by where a uuid FIRST entered the repository: the record
    whose lineage introduced it owns it, every other carrier is a copy, told so by name and given
    the exit — and once the copied line is gone, this record's own genesis seals."""
    import yaml as _yaml                                                     # noqa: PLC0415
    import claims                                                            # noqa: PLC0415
    import source_manifest as sm                                             # noqa: PLC0415
    base = {"material_id": "spec", "material_type": "program_spec", "status": "pending",
            "path_or_link": "TBD — the sponsor's document store link to follow",
            "why_provisional": "fixture", "sha256": "a" * 64, "ai_classification": "vendor_restricted",
            "classified_by": "T. Test", "classified_date": "2026-08-27"}
    root = tempfile.mkdtemp(prefix="a13c_")
    (Path(root) / "platform" / "tools").mkdir(parents=True)
    fx_rel, copy_rel = "fixtures/oncology/prostate/202606", "products/oncology/prostate_study/202606"
    fx, copy = Path(root, fx_rel), Path(root, copy_rel)
    fx.mkdir(parents=True)
    (fx / "source_refs.yaml").write_text(_yaml.safe_dump({"product": "prostate", "spec_version": "202606",
                                                         "source_materials": [dict(base)]}), encoding="utf-8")
    _git(root, "init", "-q"); _git(root, "add", "-A"); _git(root, "commit", "-qm", "registered")
    event, why = sm.record_spec_event(root, fx_rel, "spec", "2026-08-27T22:00:00Z")
    assert why is None, why
    _git(root, "add", "-A"); _git(root, "commit", "-qm", "sealed")
    assert sm.check(root, fx_rel) == [], sm.check(root, fx_rel)
    shutil.copytree(fx, copy)                                                # the natural hand copy, uuid and all
    _git(root, "add", "-A"); _git(root, "commit", "-qm", "copied by hand")
    errs = sm.check(root, copy_rel)
    assert any("copied from " + fx_rel in e and f"--record-event spec" in e for e in errs), errs
    assert sm.check(root, fx_rel) == [], "the owner must be untouched"
    _claimed, problems = claims.compose(root)
    twice = [p for p in problems if "claimed by" in p]
    assert twice and all(copy_rel in p and "copied" in p and fx_rel in p for p in twice), problems
    # follow the advice: remove the copied line and commit — no 'restore it' may follow
    text = (copy / "source_refs.yaml").read_text(encoding="utf-8")
    (copy / "source_refs.yaml").write_text(re.sub(r"^\s*object_uuid\s*:.*\n", "", text, flags=re.M), encoding="utf-8")
    _git(root, "add", "-A"); _git(root, "commit", "-qm", "drops the copied uuid")
    errs = sm.check(root, copy_rel)
    assert not any("restore it" in e for e in errs), errs
    event2, why2 = sm.record_spec_event(root, copy_rel, "spec", "2026-08-28T09:00:00Z")
    assert why2 is None, why2
    assert event2["object_uuid"] != event["object_uuid"]
    _git(root, "add", "-A"); _git(root, "commit", "-qm", "seals its own genesis")
    assert sm.check(root, copy_rel) == [] and sm.check(root, fx_rel) == [], (sm.check(root, copy_rel), sm.check(root, fx_rel))
    assert not [p for p in claims.compose(root)[1] if "claimed by" in p]
    # and the copy's OWN identity is pinned from here: pointing it back at the fixture's object is refused
    doc = _yaml.safe_load((copy / "source_refs.yaml").read_text(encoding="utf-8"))
    doc["source_materials"][0]["object_uuid"] = event["object_uuid"]
    (copy / "source_refs.yaml").write_text(_yaml.safe_dump(doc), encoding="utf-8")
    errs = sm.check(root, copy_rel)
    assert any("never re-homes" in e or "copied from" in e for e in errs), errs
    shutil.rmtree(root, ignore_errors=True)


def test_an_approval_binds_to_the_commit_that_last_wrote_its_subject():
    """J3#8: the identity audit bound an approval to the commit that wrote `approved_by`; a later
    commit by anyone could re-point the form's digest lines at edited bytes and the approval still
    read as that person's."""
    import approval_identity as ai                                           # noqa: PLC0415
    tmp = tempfile.mkdtemp(prefix="a13i_")
    os.makedirs(os.path.join(tmp, "governance"))
    shutil.copy(str(ROOT / "governance" / "allowed_signers.yaml"), os.path.join(tmp, "governance", "allowed_signers.yaml"))
    rel = "products/oncology/x/202606/handoff/CONFIGURATION_APPROVAL.yaml"
    os.makedirs(os.path.dirname(os.path.join(tmp, rel)))
    Path(tmp, rel).write_text("approved_by: Priya Natarajan\napproved_date: 2026-09-04\n"
                              "approved_configuration_bundle_sha256: aaaa\napproved_contract_sha256: bbbb\n", encoding="utf-8")
    _git(tmp, "init", "-q"); _git(tmp, "add", "-A"); _git(tmp, "commit", "-qm", "approved")
    rows, _errs = ai.audit(tmp)
    row = next(r for r in rows if r["file"] == rel and r["field"] == "approved_by")
    assert "moved after" not in (row["why"] or "")
    Path(tmp, rel).write_text(Path(tmp, rel).read_text(encoding="utf-8").replace("aaaa", "cccc"), encoding="utf-8")
    subprocess.run(["git", "-c", "user.name=Mallory", "-c", "user.email=m@x", "commit", "-qam", "re-point"], cwd=tmp, check=True)
    rows, _errs = ai.audit(tmp)
    row = next(r for r in rows if r["file"] == rel and r["field"] == "approved_by")
    assert row["authenticated"] is False and "moved after" in row["why"] and "approved_configuration_bundle_sha256" in row["why"], row
    shutil.rmtree(tmp, ignore_errors=True)


# ------------------------------------------------------------ registries and suites

def test_lineage_status_words_are_closed():
    """J2#4: `status: released` on a lineage row was accepted by check-maturity, the registry suite
    and the pin, which one word earlier refused the same cut as a DRAFT."""
    entry = _product_entry([{"spec_version": "202606", "status": "released"}])
    errs = pg.lineage_errors(entry)
    assert errs and "released" in errs[0] and "active | superseded | draft" in errs[0], errs
    assert pg.lineage_errors(_product_entry([{"spec_version": "202606", "status": "active"}])) == []
    root = _minimal_root()
    Path(root, "products", "registry.yaml").write_text(_yaml_dump({"tumors": [entry]}), encoding="utf-8")
    assert any("released" in e for e in pg.registry_errors(root)), pg.registry_errors(root)
    os.makedirs(os.path.join(root, "work", "s1")); Path(root, "work", "s1", "PROTOCOL.yaml").write_text("protocol_id: s1\nstatus: draft\n", encoding="utf-8")
    rc, out = _run([str(TOOLS / "study_pin.py"), "s1", "--pin", PRODUCT, "--pinned-by", "Priya Natarajan",
                    "--pinned-date", "2026-09-05", "--root", root], root)
    _refused(rc, out, "released", "active | superseded | draft")
    shutil.rmtree(os.path.dirname(root), ignore_errors=True)


def test_acceptance_matrix_row_14_uses_a_family_that_is_free():
    """J1#4: the row-14 test hard-coded slug 'kidney', so standing the runbook's own example product
    up turned the acceptance oracle red."""
    src = _read("platform/tests/test_acceptance_matrix.py")
    body = src.split("def test_the_next_cut_is_a_draft_beside_the_released_cut", 1)[1].split("\ndef ", 1)[0]
    assert "_free_family(" in body and '_new_product(root, "kidney"' not in body
    sys.path.insert(0, str(FRAMEWORK / "tests"))  # also works under pytest's importlib mode
    import test_acceptance_matrix as tam                                     # noqa: PLC0415
    fam = tam._free_family(str(ROOT))
    assert fam and fam not in __import__("spec_lint").tumour_registry()["families"], fam


# ------------------------------------------------------------ the portal

def test_the_portal_declares_nothing_for_the_person_and_keeps_rosters_apart():
    """J1#2: the New product page pre-filled modality, AI classification, the date and the vendor while
    its text said they have no default, and had no condition-class control. J5#0: Manage users
    carried one person's role and packs onto the next person selected. J5#1: the Assistant crashed
    with a Streamlit traceback when the anthropic package is absent. J5#2: the strip said 'no
    extraction yet' about packs with an extraction. J5#3: the snapshot instruction named a directory
    where the app reads a file. J5#4: the deployed roster had no principal field."""
    import queues                                                            # noqa: PLC0415
    import ui_text as ui                                                     # noqa: PLC0415
    app = _read("experiments/portal/app.py")
    block = app.split('if section == "New product":', 1)[1].split('if section == "Agent":', 1)[0]
    for key in ("np_vendor", "np_modality", "np_tclass", "np_narrow", "np_ai", "np_cond"):
        assert re.search(rf'key="{key}",\s*index=None', block), key
    assert re.search(r'text_input\("Classified on \(YYYY-MM-DD\)"[^)]*key="np_on"', block) and "value=_dt.date.today()" not in block
    assert '_cond = "oncology"' not in block
    users = app.split("Manage users (admin)", 1)[1].split("# PROJECT MEMBERSHIP", 1)[0]
    assert 'key=f"edit_role_{eu}"' in users and 'key=f"edit_packs_{eu}"' in users and 'key=f"edit_owns_{eu}"' in users
    assert "if not LOCAL_WRITES:" in users and "ui.PRINCIPAL_LABEL" in users and '"email"' in users
    # The selected-connection adapter owns missing-provider handling now.
    from unittest.mock import patch
    import portal_agent_connection as connection
    with patch.object(connection.ai, "_provider", side_effect=ImportError("provider SDK unavailable")):
        missing = connection.describe(ROOT)
    assert missing["ok"] is False and missing["errors"]
    assert "configuration is unavailable" in missing["errors"][0]
    assert "no extraction yet" not in _read("experiments/portal/queues.py").split("def lifecycle", 1)[1]
    row = next(s for s in queues.lifecycle(None, records=0, extracted=26) if s["name"] == "Specification")
    assert "26" in row["why"] and "no contract record" in row["why"], row
    row = next(s for s in queues.lifecycle(None, records=12, extracted=26) if s["name"] == "Specification")
    assert "12" in row["why"] and "26" in row["why"], row
    line = ui.build_snapshot_line("python3", "platform/tools/governance_snapshot.py", "RWDP_GOVERNANCE_SNAPSHOT")
    assert "snapshot.json" in line and "--allow-dirty" in line and "at that directory" not in line
    assert "os.path.isdir(path)" in app.split("def _snapshot", 1)[1].split("\ndef ", 1)[0]
    assert "email" in _read("docs/DEPLOYMENT.md").lower()


# ------------------------------------------------------------ the rough edges (P2), each a person's minute

def test_the_demo_workbook_with_a_row_inserted_carries_the_drafted_record():
    """J2#3, on the workbook the demo itself hands out. Every requirement sheet of
    sandbox/demo_walkthrough/bladder_202609_program_spec.xlsx opens with a `Row` column that Science
    keeps in step by hand. Science inserted PDL1 above HISTOLOGY and renumbered HISTOLOGY's cell 3 -> 4,
    touching nothing else — and the drafted record came back RE-DRAFT, the carry plan excluded it, and
    CARRIES, NEW REF was unreachable. Now the verdict reads the coordinate: the record carries with a
    new ref, the plan's command (run as printed, from the checkout root) lands it in the next cut at
    clinical:4, and from there it carries as-is. The extraction hash is untouched."""
    import openpyxl                                                          # noqa: PLC0415
    import contract_lint as cl                                               # noqa: PLC0415
    import contract_scaffold as cs                                           # noqa: PLC0415
    import spec_diff                                                         # noqa: PLC0415
    sys.path.insert(0, str(Path(__file__).resolve().parent))
    from test_spec_slice import _sign                                        # noqa: PLC0415
    root = _copy_repo(git=False)
    old_rel, new_rel = "sandbox/demo_walkthrough/bladder/202609", "sandbox/demo_walkthrough/bladder/202610"
    old, new = os.path.join(root, old_rel), os.path.join(root, new_rel)
    # 1. a person drafts HISTOLOGY against the released cut, through the governed path
    _sign(Path(old))
    answers = {"window": "index_date", "record_selection": "the pathology record closest to index",
               "tie_break": "earliest report date", "derivation": "urothelial vs variant histology from the pathology record",
               "missing": "TODO", "acceptance": "a patient whose closest pathology says urothelial reports urothelial",
               "notes": "drafted by the thirteenth-pass check", "decision_ids": "[]",
               "source": "{kind: pending_mapping, spec_identifiers: [HISTOLOGY]}", "grain": "one row per patient",
               "anchor": "index_date", "cohort_applicability": "all patients", "units": "category", "depends_on": "[]",
               "output": "{physical_name: histology, target_published_name: TODO, name_status: undecided, type: string, "
                         "nullable: true, codes: n/a, role: internal}"}
    lines = []
    for line in cs.judgment_stub("HISTOLOGY").splitlines():
        key = line.split(":", 1)[0]
        lines.append(f"{key}: {answers[key]}" if key in answers else line)
    draft = os.path.join(root, "hist.yaml")
    Path(draft).write_text("\n".join(lines) + "\n", encoding="utf-8")
    rc, out = _run([str(TOOLS / "contract_record.py"), draft, "--product", old_rel, "--item", "clinical:3", "--apply"], root)
    assert rc == 0 and "APPLIED" in out, out[-800:]
    # 2. Science's revised workbook: PDL1 inserted above HISTOLOGY, the Row column renumbered by hand
    wb = openpyxl.load_workbook(os.path.join(root, DEMO_XLSX))
    ws = wb["6.Clinical characteristics"]
    ws.insert_rows(3)
    for col, val in enumerate([3, "INDEX", "PDL1", "PD-L1 status", "Text",
                               "PD-L1 expression status from the closest biomarker test before index"], start=1):
        ws.cell(row=3, column=col, value=val)
    for r in range(4, ws.max_row + 1):
        if ws.cell(row=r, column=1).value not in (None, ""):
            ws.cell(row=r, column=1, value=r)
    revised = os.path.join(root, "bladder_202610_program_spec.xlsx")
    wb.save(revised)
    wb.close()
    # 3. the next cut: the old pack's shape with the revised extraction and the template's empty contract
    shutil.copytree(old, new)
    rc, out = _run([str(TOOLS / "spec_extract.py"), revised, "--out", os.path.join(new, "spec_pipeline", "out", "extracted.json")], root)
    assert rc == 0, out[-600:]
    shutil.copy(str(FRAMEWORK / "TUMOR_TEMPLATE" / "handoff" / "FUNCTIONAL_CONTRACT.md"), os.path.join(new, "handoff", "FUNCTIONAL_CONTRACT.md"))
    _sign(Path(new))
    rows = {r["variable"]: r["item_id"] for r in json.load(open(os.path.join(new, "spec_pipeline", "out", "extracted.json"), encoding="utf-8"))["rows"]}
    assert rows["PDL1"] == "clinical:3" and rows["HISTOLOGY"] == "clinical:4", rows
    # 4. the verdict, the page and the plan
    verdicts = dict((vid, (v, d)) for vid, v, d in spec_diff.carry(old_rel, new_rel, root))
    assert verdicts["HISTOLOGY"][0] == spec_diff.NEW_REF, verdicts
    assert "clinical:3->4" in verdicts["HISTOLOGY"][1] and "Row cell" in verdicts["HISTOLOGY"][1], verdicts
    assert verdicts["ECOG"][0] == spec_diff.AS_IS, verdicts                   # the demo's own record, above the insertion
    page = spec_diff.render(old_rel, new_rel, root)
    assert "MOVED" in page and "re-read" not in page.split("MOVED")[1].split("\n")[0], page
    plan = os.path.join(root, "carry plan")
    written, commands, by_hand, excluded, note = spec_diff.carry_plan(old_rel, new_rel, plan, root)
    assert note is None and not by_hand and not excluded, (note, by_hand, excluded)
    hist = [c for c in commands if "HISTOLOGY" in c]
    assert len(hist) == 1 and f"--product {new_rel} --item clinical:4 --apply" in hist[0], commands
    # 5. run as printed, from the checkout root: the carried records land, cite the new rows, and then carry as-is
    for c in commands:
        argv = shlex.split(c)
        assert argv[0] == ("python" if os.name == "nt" else "python3") and argv[1] == "platform/tools/contract_record.py", c
        rc, out = _run(argv[1:], root)
        assert rc == 0 and "APPLIED" in out, out[-800:]
    got = {(cl._scalar(b, "variable_id") or "").strip(): cl._list(b, "spec_refs")
           for b in cl.records(cl.read(os.path.join(new, "handoff", "FUNCTIONAL_CONTRACT.md")))}
    assert got == {"ECOG": ["clinical:2"], "HISTOLOGY": ["clinical:4"]}, got
    errors, _n = cl.run(new)
    assert not [e for e in errors if " I" in e and "floor" not in e], errors[:4]
    assert {v for _vid, v, _d in spec_diff.carry(new_rel, new_rel, root)} == {spec_diff.AS_IS}
    shutil.rmtree(os.path.dirname(root), ignore_errors=True)


def test_the_demo_workbook_generator_is_deterministic_honours_a_file_path_and_tells_the_truth_about_the_digest():
    """J7#10: three pages said the workbook is byte-reproducible from the generator alone, and the
    bytes depended on whether lxml happened to be installed (openpyxl serialises through it when
    present); the registered digest was written with lxml, so a presenter who regenerated as told
    then hit Gate 1's 'the file changed under the registration'. And `--out one.xlsx` made a FOLDER
    named one.xlsx. Now the generator pins the serializer (content decides the bytes on every
    machine), writes to a file path when given one, and prints whether its bytes match the digest
    the pack registers — and what to do when they do not."""
    gen = str(ROOT / "sandbox" / "demo_walkthrough" / "make_test_workbook.py")
    tmp = tempfile.mkdtemp(prefix="a13w_")
    rc1, out1 = _run([gen, "--out", os.path.join(tmp, "one.xlsx")], str(ROOT))
    rc2, out2 = _run([gen, "--out", os.path.join(tmp, "folder")], str(ROOT))
    assert rc1 == 0 and rc2 == 0, (out1[-400:], out2[-400:])
    assert os.path.isfile(os.path.join(tmp, "one.xlsx")), "a path ending in .xlsx is the file, not a folder"
    assert os.path.isfile(os.path.join(tmp, "folder", "bladder_202609_program_spec.xlsx")), "a folder gets the default name"
    a = hashlib.sha256(Path(tmp, "one.xlsx").read_bytes()).hexdigest()
    b = hashlib.sha256(Path(tmp, "folder", "bladder_202609_program_spec.xlsx").read_bytes()).hexdigest()
    assert a == b, "two runs, two digests — the bytes are not a function of the content"
    registered = re.search(r"sha256:\s*([0-9a-f]{64})", _read("sandbox/demo_walkthrough/bladder/202609/source_refs.yaml")).group(1)
    assert registered[:12] in out1 and a[:12] in out1, out1
    assert ("matches the registered digest" in out1) == (a == registered), out1
    if a != registered:
        assert "lxml" in out1 and "--record-digest" in out1, out1
    # the pages state the property the tool actually has, not a stronger one
    for page in ("DEMO.md", "sandbox/demo_walkthrough/README.md"):
        text = _read(page)
        assert "same bytes every time" not in text and "byte-reproducible from the generator alone" not in text, page
        assert "serializer" in text or "serialiser" in text, f"{page} does not say what decides the bytes"
    shutil.rmtree(tmp, ignore_errors=True)


def test_the_portal_refusal_and_the_demo_page_name_the_laptop_switch():
    """A presenter following DEMO.md launched the portal and was refused with 'no authenticated
    identity … RWD_PORTAL_LOCAL_DEMO is not set' — the page never said to set it, and the refusal
    named the variable without its value or its meaning (2026-09-05, the person testing the branch)."""
    import identity                                                          # noqa: PLC0415
    actor, why = identity.resolve({}, [{"name": "admin", "role": "admin"}], local_demo=False)
    assert actor is None and "RWD_PORTAL_LOCAL_DEMO=1" in why and "experiments/portal/.env" in why, why
    assert "Databricks Apps" in why, why
    demo = _read("DEMO.md")
    assert "RWD_PORTAL_LOCAL_DEMO=1" in demo and "streamlit run experiments/portal/app.py" in demo, \
        "DEMO.md must tell the presenter how to launch the portal locally"
    # ...and the Assistant's disabled message box says why it is disabled (the same person, the
    # same day: a grey box under a model line that said "API key: missing" read as broken)
    import ui_text as ui                                                     # noqa: PLC0415
    assert "ANTHROPIC_API_KEY" in ui.NO_KEY_INPUT and "experiments/portal/.env" in ui.NO_KEY_INPUT
    app = _read("experiments/portal/app.py")
    agent = app.split('if section == "Agent":', 1)[1]
    assert agent.index('for _problem in _connection["errors"]:') < agent.index("q = st.chat_input("), \
        "selected-provider errors must render before its disabled message box"
    assert 'disabled=not _connection["ok"]' in agent.split("q = st.chat_input(", 1)[1].split("\n", 1)[0]
    assert "ANTHROPIC_API_KEY" in demo.split("Launch the portal as a laptop demo", 1)[1][:900]


def test_search_hits_render_as_a_page_not_a_dump():
    """A person searching "ECOG" got twenty-one hits as one monospace block, sixteen of them
    literature (2026-09-05). The page now groups by kind — records and decisions open first, the
    literature behind its count — escapes the requirement text, applies the actor's scope the way
    the agent's renderer does, and never routes the search through st.code again."""
    import search_view as sv                                                 # noqa: PLC0415
    hits = [{"kind": "inventory", "domain": "literature", "state": "bibliographic_only", "id": f"lit{i}",
             "where": "governance/reference/x.yaml", "title": f"ECOG lit {i}", "detail": "*not* emphasis [INDEX - 30]", "score": 1}
            for i in range(16)]
    hits += [{"kind": "contract_record", "domain": "product_ruling", "state": "answered_unattributed", "id": "ECOG",
              "where": "fixtures/oncology/prostate/202606/handoff/FUNCTIONAL_CONTRACT.md", "title": "ECOG",
              "detail": "If COHORTN = 1 then ECOGVALUE ...", "score": 3},
             {"kind": "decision", "domain": "product_ruling", "state": "open", "id": "D-ECOG",
              "where": "fixtures/oncology/oc/202606/handoff/DECISIONS.md", "title": "Both ECOG tables?", "detail": "OPEN", "score": 2},
             {"kind": "capability", "domain": "implementation_evidence", "state": "unit_tested", "id": "clinical.baseline_ecog",
              "where": "", "title": "nearest ECOG inside the window", "detail": "worst grade on a tie", "score": 2}]
    pack_of = lambda w: "/".join(str(w).split("/")[:4]) if str(w).startswith(("fixtures/", "products/")) else None  # noqa: E731
    view = sv.group(hits, scope={"fixtures/oncology/prostate/202606"}, pack_of=pack_of)
    assert view["banner"].lower().startswith("nothing below is an approval")
    assert [g["kind"] for g in view["groups"]] == ["contract_record", "capability", "inventory"], view["groups"]
    assert view["dropped"] == 1, "the oc decision is outside the scope and must be dropped, not shown"
    opens = {g["kind"]: g["open"] for g in view["groups"]}
    assert opens["contract_record"] and opens["capability"] and not opens["inventory"]
    assert view["groups"][-1]["count"] == 16 and view["groups"][0]["hits"][0]["pack"] == "fixtures/oncology/prostate/202606"
    assert sv.md_escape("*not* [INDEX - 30]") == "\\*not\\* \\[INDEX \\- 30\\]"
    assert "may settle: product ruling" in sv.caption(view["groups"][0]["hits"][0])
    alone = sv.group(hits[:3], scope=None, pack_of=pack_of)
    assert alone["groups"][0]["open"], "the literature opens when it is all there is"
    capped = sv.group(hits, scope=None, pack_of=pack_of, limit=5)
    assert capped["more"] == 14 and sum(g["count"] for g in capped["groups"]) == 5
    app = _read("experiments/portal/app.py")
    block = app.split('if section == "Search & definitions":', 1)[1].split('if section == "Run gates":', 1)[0]
    assert 'cached(SCOPE_KEY, "search"' not in block and "search_view.group(" in block and "tools._pack_of" in block


def test_the_walkthrough_runs_end_to_end_in_the_portal():
    """A person stood a product up in the portal and then had no way to see the gates, validate the
    configuration or build without a terminal (2026-09-05: "I cannot run it end to end on the
    Streamlit app"). The Walkthrough section reads each step's state from the pack's files and offers
    the bounded act for the next one; the strip offers the gate evaluation where the gap is seen; Run
    checks gained the configuration validation and the synthetic build (local demo, Spark verified)."""
    import walkthrough as wt                                                 # noqa: PLC0415
    import ui_text as ui                                                     # noqa: PLC0415
    demo = wt.steps(str(ROOT), wt.DEMO_PACK, spark_ready=False, spark_why="pyspark absent", local_demo=True)
    by = {s_["id"]: s_ for s_ in demo}
    assert [s_["id"] for s_ in demo] == ["workbook", "stand_up", "extraction", "configuration", "validate", "build", "gates"]
    assert by["workbook"]["state"] == wt.DONE and "matches the registered digest" in by["workbook"]["detail"], by["workbook"]
    assert by["stand_up"]["state"] == wt.DONE and by["extraction"]["state"] == wt.DONE
    assert "16 specification row(s)" in by["extraction"]["detail"], by["extraction"]["detail"]
    assert by["configuration"]["state"] == wt.DONE, by["configuration"]           # the demo's config is authored
    assert by["validate"]["state"] == wt.RUN and by["validate"]["action"] == "validate"
    assert by["build"]["state"] == wt.UNAVAILABLE and "spark" in by["build"]["detail"].lower(), by["build"]   # not available here is not a defect (2026-09-07)
    assert by["gates"]["state"] == wt.TODO and by["gates"]["action"] == "evaluate"
    ready = wt.steps(str(ROOT), wt.DEMO_PACK, spark_ready=True, spark_why="", local_demo=True, snapshot_entry={"gates": {"gate1": "ok"}})
    assert ready[5]["state"] == wt.RUN and ready[5]["action"] == "build" and ready[6]["state"] == wt.TODO
    assert ready[6]["action"] == "evaluate", "a malformed gate snapshot is not a completed evaluation"
    deployed = wt.steps(str(ROOT), wt.DEMO_PACK, spark_ready=True, spark_why="", local_demo=False)
    assert deployed[5]["state"] == wt.UNAVAILABLE and "Databricks Jobs" in deployed[5]["detail"]
    # a bare pack: nothing stood up yet, and the page says where to go
    tmp = tempfile.mkdtemp(prefix="a13wt_")
    bare = os.path.join(tmp, "products", "oncology", "kidney", "202609")
    os.makedirs(os.path.join(bare, "config"))
    Path(bare, "config", "data_product.yaml").write_text("data_product_id: REPLACE_ME_rwdp\nmin_followup_days: REPLACE_ME\n", encoding="utf-8")
    st_ = {s_["id"]: s_ for s_ in wt.steps(tmp, "products/oncology/kidney/202609", False, "x", True)}
    assert st_["workbook"]["state"] == wt.TODO and st_["workbook"]["action"] == "new_product"
    assert st_["stand_up"]["state"] == wt.TODO and st_["extraction"]["state"] == wt.TODO
    assert st_["configuration"]["state"] == wt.TODO and "2 value(s) still REPLACE_ME" in st_["configuration"]["detail"]
    shutil.rmtree(tmp, ignore_errors=True)
    # the page: the section exists, the strip offers the evaluation, Run checks validates and builds
    app = _read("experiments/portal/app.py")
    assert '"Walkthrough"' in app.split("SECTIONS = ", 1)[1].split("]", 1)[0] and ui.SECTION_LABELS["Walkthrough"] == "Walkthrough"
    strip = app.split("st.caption(ui.NO_SNAPSHOT_STRIP)", 1)[1][:900]
    assert "ui.compute_live(" in strip and "ui.REBUILD_SNAPSHOT" in strip
    gates = app.split('if section == "Run gates":', 1)[1].split('if section == "Walkthrough":', 1)[0]
    assert "ui.VALIDATE_CONFIG" in gates and "ui.BUILD_SYNTHETIC" in gates
    # Exercise the actual enablement expression instead of a historical spelling.
    tree = __import__("ast").parse(app)
    call = next(node for node in __import__("ast").walk(tree) if isinstance(node, __import__("ast").Call)
                and node.args and isinstance(node.args[0], __import__("ast").Attribute)
                and node.args[0].attr == "BUILD_SYNTHETIC")
    disabled = next(key.value for key in call.keywords if key.arg == "disabled")
    expression = compile(__import__("ast").Expression(disabled), "<build-enablement>", "eval")
    for local in (False, True):
        for runtime in (False, True):
            for unbound in (0, 1):
                assert eval(expression, {"LOCAL_WRITES": local, "_sp_ok": runtime, "_unbound": unbound}) == (not (local and runtime and not unbound))
    walk = app.split('if section == "Walkthrough":', 1)[1].split('if section == "Studies":', 1)[0]
    assert "walkthrough.steps(" in walk and "_validate_config(" in walk and "_synthetic_build(" in walk and '"status.py"' in walk
    assert "approval" not in walk.lower().replace("approvals, answers and promotions stay", ""), "no approval act on the page"
    assert "--strict" in app.split("def _validate_config", 1)[1].split("\ndef ", 1)[0]


def test_the_flow_is_the_product_page_and_every_act_on_it_is_bounded():
    """"There is simply no flow" (2026-09-05): sections were islands, gates were words on a status
    page, a new product landed nowhere. The Flow is the first section of the product page; Home and
    New product hand off into it; one button checks the current gate; a read or a scaffold write runs
    from the page and the gate is re-evaluated at once; a person's act has no button; the two
    lifecycle consumers that guessed at the snapshot's shape read status.results() rows."""
    import ui_text as ui                                                     # noqa: PLC0415
    import queues                                                            # noqa: PLC0415
    import walkthrough as wt                                                 # noqa: PLC0415
    app = _read("experiments/portal/app.py")
    assert 'MAIN_SECTIONS = ["Home", "Flow", "Status",' in app and ui.SECTION_LABELS["Flow"] == "Progress and next step"
    assert app.count('st.session_state["section_suggested"] = "Flow"') >= 3, "Home cards, the reference expander and the stand-up land on the Flow"
    np_block = app.split('if st.button(ui.NEW_PRODUCT_WRITE, key="np_write"):', 1)[1].split('\nif section == "Agent":', 1)[0]
    assert 'st.session_state["pack_suggested"] = os.path.dirname(_pack)' in np_block and '"section_suggested"] = "Flow"' in np_block
    walk = app.split('if section == "Flow":', 1)[1].split('if section == "Status":', 1)[0]
    page = _read("experiments/portal/flow_page.py")
    assert "flow_engine.flow(ROOT, pack)" in walk and 'key="flow_check"' in page
    assert "run_action=lambda argv: _bounded(" in walk, "the dialog uses the bounded portal runner"
    assert page.count("_refresh(pack, evaluate)") >= 3, "status is refreshed after an action and on explicit checks"
    assert 'action.get("kind") in ("read", "write")' in page, "a person's act has instructions, no execution button"
    assert "guidance.action_state(" in page and "guidance.action_guard(" in page, "render distinguishes completion; the execution boundary rechecks prerequisites"
    assert "st.session_state.flow_output" in page and 'st.expander("Activity and run details")' in page
    for banned in ("--apply", "RELEASE_APPROVAL", "promote", "answered_by"):
        assert banned not in walk, f"the page must not perform {banned}"
    # the consumers read the snapshot's real shape
    life = {s_["name"]: s_ for s_ in queues.lifecycle({"gates": [{"gate": 4, "status": "done"}], "records": 3}, records=3)}
    assert life["Configuration"]["state"] == "done" and "gate 4" in life["Configuration"]["why"], life["Configuration"]
    # EVALUATED IS NOT PASSED (2026-09-07): a recorded verdict that leaves Gate 1 open is the open
    # step it describes, never the completion glyph; only six done gates complete the step.
    g = wt.gates(str(ROOT), wt.DEMO_PACK, {"gates": [{"gate": 1, "status": "in progress"}, {"gate": 2, "status": "done"}]})
    assert g["state"] == wt.TODO and "gate 2: done" in g["detail"] and "gate 1 is in progress" in g["title"], g
    g = wt.gates(str(ROOT), wt.DEMO_PACK, {"gates": [{"gate": n, "status": "done"} for n in range(1, 7)]})
    assert g["state"] == wt.DONE, g


def test_the_rough_edges_are_smoothed():
    """The P2 findings of the thirteenth pass, in one place: an abbreviated flag, a wrong-case class, a
    placeholder note, a digits-only name, an empty status argument, a changelog header read as an
    entry, a carry plan inside the checkout, a pin tool given two verbs or no flag, a record scaffolded
    under a product's name, an errno for a record that does not exist, a replay that says it wrote,
    a precedents page that contradicts itself, and library modules that answer --help with nothing."""
    import config_diff as cd                                                 # noqa: PLC0415
    import person_rules as pr                                                # noqa: PLC0415
    import precedents                                                        # noqa: PLC0415
    # J1#8: an abbreviated flag is refused, never taken as the nearest one
    root = _copy_repo(git=False)
    tool = str(Path(root, "platform/tools/new_product.py"))
    base = ["kidney", "--code", "kidney", "--name", "Kidney", "--vendor", "flatiron", "--tumor-class", "solid",
            "--spec-version", "202609", "--narrow", "genitourinary", "--modality", "ehr", *PERSON]
    rc, out = _run([tool, *base, "--condition-class", "oncology", "--disease-term", "renal cell carcinoma"], root)
    assert rc == 2 and "unrecognized arguments: --disease-term" in out, out[-500:]
    # J1#7: the class is typed in its own case, as the tumour class is
    rc, out = _run([tool, *base, "--condition-class", "Oncology", "--disease-terms", "renal cell carcinoma"], root)
    _refused(rc, out, "Oncology", "own case")
    # J1#13: a bad tumour class is one problem, not two
    rc, out = _run([tool, "kidney", "--code", "kidney", "--name", "Kidney", "--vendor", "flatiron", "--tumor-class", "Solid",
                    "--spec-version", "202609", "--narrow", "genitourinary", "--modality", "ehr", "--condition-class", "oncology",
                    "--disease-terms", "renal cell carcinoma", *PERSON], root)
    _refused(rc, out, "tumor-class 'Solid'")
    assert "broad axis" not in out and "None" not in out, out[-600:]
    # J3#10: the family's own name as a slug names the remedy that works
    rc, out = _run([tool, "bladder", "--code", "bladder", "--name", "Bladder", "--vendor", "flatiron", "--tumor-class", "solid",
                    "--spec-version", "202609", "--narrow", "genitourinary", "--modality", "ehr", "--condition-class", "oncology", *PERSON], root)
    _refused(rc, out, "tumour family itself", "--tumour-family bladder")
    assert "shares a token" not in out
    # J2#9: a placeholder note on a next cut
    _register_product(root, lineage=[{"spec_version": "202606", "status": "active"}])
    shutil.copy(str(ROOT / DEMO_XLSX), os.path.join(root, "revised.xlsx"))
    rc, out = _run([tool, "prostate_study", "--next-cut-of", PRODUCT, "--spec-version", "202609", "--workbook",
                    os.path.join(root, "revised.xlsx"), "--change-class", "breaking", "--change-note", "TODO", *PERSON], root)
    _refused(rc, out, "--change-note", "placeholder")
    # J6#6 / J6#7: a record under a product's name; a record that does not exist
    for t_ in ("request_record.py", "protocol_record.py"):
        rc, out = _run([str(Path(root, "platform/tools", t_)), "--new", "prostate_study"], root)
        _refused(rc, out, "product slug")
        assert not os.path.exists(os.path.join(root, "work", "prostate_study"))
        rc, out = _run([str(Path(root, "platform/tools", t_)), "--digest", "nobody"], root)
        _refused(rc, out, "no record at work/nobody", "--new nobody")
        assert "Errno" not in out
    shutil.rmtree(os.path.dirname(root), ignore_errors=True)
    # J4#8 / J6#11: no letters, no name
    assert pr.not_a_person("12345") and "no letters" in pr.not_a_person("12345")
    # J7#19: an empty argument names nothing
    rc, out = _run([str(TOOLS / "status.py"), ""], str(ROOT))
    _refused(rc, out, "empty argument")
    # J2#10: the tool's own header line is not an entry
    assert cd.ENTRY_RE.match("- 2026-09-05 none 202609: a typo") and not cd.ENTRY_RE.match("`- <YYYY-MM-DD> <breaking|additive|none> <YYYYMM>: ...`")
    # J2#20: a carry plan inside the checkout is refused
    rc, out = _run([str(TOOLS / "spec_diff.py"), "fixtures/oncology/prostate/202603", PROSTATE, "--carry-plan",
                    os.path.join(str(ROOT), "products", "oncology", "carry_here")], str(ROOT))
    _refused(rc, out, "inside the checkout")
    assert not os.path.exists(os.path.join(str(ROOT), "products", "oncology", "carry_here"))
    # J4#9 / J4#10 / J4#11: the pin tool names a missing flag, refuses two verbs, refuses an unknown key
    root = _minimal_root()
    os.makedirs(os.path.join(root, "work", "s1")); Path(root, "work", "s1", "PROTOCOL.yaml").write_text("protocol_id: s1\nstatus: draft\n", encoding="utf-8")
    pin = str(TOOLS / "study_pin.py")
    rc, out = _run([pin, "s1", "--pin", PRODUCT, "--pinned-date", "2026-09-05", "--root", root], root)
    _refused(rc, out, "--pinned-by is required")
    rc, out = _run([pin, "s1", "--pin", PRODUCT, "--pinned-by", "Priya Natarajan", "--pinned-date", "2026-09-05",
                    "--decide", PRODUCT, "--variable", "ECOG", "--decision", "reuse", "--why", "w", "--decided-by", "Priya Natarajan",
                    "--decided-date", "2026-09-05", "--root", root], root)
    assert rc == 2 and "one verb at a time" in out, out[-400:]
    assert _run([pin, "s1", "--pin", PRODUCT, "--pinned-by", "Priya Natarajan", "--pinned-date", "2026-09-05", "--root", root], root)[0] == 0
    rc, out = _run([pin, "s1", "--decide", PRODUCT, "--decision", "reuse", "--why", "w", "--decided-by", "Priya Natarajan",
                    "--decided-date", "2026-09-05", "--root", root], root)
    _refused(rc, out, "--variable is required")
    p = Path(root, "work", "s1", "PINS.yaml")
    p.write_text(p.read_text(encoding="utf-8").replace("  status: pinned\n", "  status: pinned\n  approved_by: Priya Natarajan\n"), encoding="utf-8")
    rc, out = _run([pin, "--check", "--root", root], root)
    assert rc == 1 and "unknown key 'approved_by'" in out, out
    rc, out = _run([pin, "--list", "--product", "products/oncology/nowhere/202606", "--root", root], root)
    _refused(rc, out, "not a pack")
    rc, out = _run([pin, "nobody", "--list", "--root", root], root)
    _refused(rc, out, "does not exist")
    shutil.rmtree(os.path.dirname(root), ignore_errors=True)
    # J5#13: an empty store says so
    r = precedents.render_proposals(PROSTATE, str(ROOT))
    text = r if isinstance(r, str) else "\n".join(r)
    assert "every precedent in the store already cites this pack" not in text or "0 already recorded" not in text, text[-400:]
    # J7#25 / J7#13: library modules and the MCP server answer --help
    for t_ in ("pack_run.py", "profile_io.py", "person_rules.py", "console.py"):
        rc, out = _run([str(TOOLS / t_), "--help"], str(ROOT), timeout=60)
        assert rc == 0 and "library module" in out, (t_, out[-300:])
    rc, out = _run([str(TOOLS / "mcp_server.py"), "--help"], str(ROOT), timeout=60)
    assert rc == 0 and "read-only tools" in out and "pack_status" in out, out[-400:]
    # J7#4-style: the two Spark tools and the profile runner refuse a scaffold's placeholder stems
    scaffold = os.path.join(tempfile.mkdtemp(prefix="a13s_"), "products", "oncology", "kidney", "202609")
    shutil.copytree(str(FRAMEWORK / "TUMOR_TEMPLATE"), scaffold, ignore=shutil.ignore_patterns("NEW_TUMOUR.md", "__pycache__"))
    dp = Path(scaffold, "config", "data_product.yaml")
    dp.write_text(dp.read_text(encoding="utf-8").replace("vendor: REPLACE_ME", "vendor: flatiron", 1), encoding="utf-8")
    rc, out = _run([str(TOOLS / "run_product_profile.py"), scaffold, "--cut", "2026m06", "--out-dir",
                    tempfile.mkdtemp(), "--print-tables"], str(ROOT), timeout=120)
    assert rc != 0 and "REPLACE_ME" in out and "Traceback" not in out, out[-500:]
    shutil.rmtree(os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(scaffold)))), ignore_errors=True)


if __name__ == "__main__":
    console.use_utf8()
    failures = 0
    only = set(sys.argv[1:])
    for name, fn in sorted(globals().items()):
        if name.startswith("test_") and callable(fn) and (not only or name in only):
            try:
                fn()
                print(f"  ok   {name}")
            except Exception:                                                # noqa: BLE001
                failures += 1
                print(f"  FAIL {name}")
                traceback.print_exc()
    print(f"{failures} failure(s)")
    sys.exit(1 if failures else 0)
