"""Eighth external verdict (2026-09-03, main 7071569) — failing first, then absorbed.

  P1  pack scope was PROCESS-GLOBAL (one session's membership leaked into another's) and only tools
      with a `pack` argument honoured it; portfolio and search read every pack
  P1  kept requests had no lifecycle: a failed or withdrawn request pre-filled a new one, and any
      pack's request was offered to any actor
  P1  an escalation could name any owner; a resume never checked the answerer's eligibility;
      "Science approved ..." completed as done; `answered` was recorded on budget exhaustion
  P2  control plane: verdict dates unchecked, per-kind ledger actions unchecked, write-path scan
      closed, permission maps not derived from the registry
  P2  generated code identifiers unchecked against the reviewed mapping evidence; candidates unstamped
  P2  no ingress classification: patient-shaped text reached the model in both modes
  P2  Databricks Apps packaging: imports outside the app root, no valueFrom, no durable state dir
  P3  dry_run stages nothing outside the pack; DEMO/sandbox texts contradict the tree; the search
      cache key misses older-file edits and nested files; validate_manifest types too few mappings;
      the refresh template lacks four writer fields; the portal's text is not plain language

NO PYTEST FIXTURES AND NO `parametrize` — CI runs every suite as a script.
"""
import ast
import copy
import importlib
import json
import os
import re
import shutil
import sys
import tempfile
import threading
import time
from pathlib import Path

FRAMEWORK = Path(__file__).resolve().parent.parent
ROOT = FRAMEWORK.parent
AGENT = ROOT / "experiments" / "agent"
for p in (FRAMEWORK / "tools", FRAMEWORK / "engine", AGENT, ROOT / "experiments" / "portal"):
    sys.path.insert(0, str(p))
os.environ.setdefault("ANTHROPIC_API_KEY", "not-a-key-tests-never-call")

P = "fixtures/oncology/prostate/202606"
OC = "fixtures/oncology/oc/202606"


def _read(rel):
    return (ROOT / rel).read_text(encoding="utf-8")


class _Scripted:
    model = "fake"

    def __init__(self, replies):
        self.replies = list(replies)
        self.usage = {"calls": 0, "input_tokens": 0, "output_tokens": 0}

    def step(self, system, transcript):
        self.usage["calls"] += 1
        if not self.replies:
            return json.dumps({"action": "tool", "tool": "packs", "args": {}, "why": "loop"})
        return self.replies.pop(0)


def _tool(name, **args):
    return json.dumps({"action": "tool", "tool": name, "args": args, "why": "t"})


def _done(s):
    return json.dumps({"action": "done", "summary": s})


def _esc(to, q="which window?"):
    return json.dumps({"action": "escalate", "to": to, "question": q, "evidence": "e"})


def _escalated_run(to="Science"):
    import orchestrator as orc  # noqa: PLC0415
    return orc.run("g", model=_Scripted([_tool("packs"), _esc(to)]), max_steps=4)


# ------------------------------------------------------------------ P1 pack scope

def test_pack_scope_is_per_call_and_per_context_not_process_global():
    import tools  # noqa: PLC0415
    import orchestrator as orc  # noqa: PLC0415
    src = _read("experiments/agent/tools.py")
    assert "_SCOPE: set | None = None" not in src and "ContextVar" in src, "scope is context-local"
    out = tools.call("pack_status", {"pack": OC}, scope={P})
    assert "REFUSED" in out and "scope" in out
    # two contexts, interleaved: B's membership must never reach A's call
    seen = {}
    gate = threading.Barrier(2)

    def a():
        tools.set_pack_scope({P})
        gate.wait(); gate.wait()
        seen["a"] = tools.call("pack_status", {"pack": OC})

    def b():
        gate.wait()
        tools.set_pack_scope({OC})
        gate.wait()
    ta, tb = threading.Thread(target=a), threading.Thread(target=b)
    ta.start(); tb.start(); ta.join(5); tb.join(5)
    assert "REFUSED" in seen.get("a", ""), "another context's membership leaked into this call"
    r = orc.run("g", model=_Scripted([_tool("pack_status", pack=OC), _done("x")]), max_steps=3, scope={P})
    obs = [s for s in r.steps if s["kind"] == "observation"]
    assert obs and "REFUSED" in obs[0]["output"], "run(scope=) confines the loop's tools"
    app = _read("experiments/portal/app.py")
    assert "scope=set(MY_PACKS)" in app, "the portal passes its scope into the job and the resume"


def test_portfolio_and_search_readers_are_filtered_by_scope():
    import tools  # noqa: PLC0415
    out = tools.call("portfolio", {}, scope={P})
    assert P in out and OC not in out, out[:400]
    unscoped = tools.call("search", {"query": "ECOG"})
    assert P in unscoped, "a pack-bound hit names its pack"
    mine = tools.call("search", {"query": "ECOG"}, scope={P})
    assert OC not in mine and "oc/202606" not in mine
    theirs = tools.call("search", {"query": "ECOG"}, scope={OC})
    assert "prostate/202606" not in theirs


# ------------------------------------------------------------------ P1 reuse lifecycle

def test_kept_requests_carry_a_lifecycle_and_only_reusable_in_scope_ones_prefill():
    import intake  # noqa: PLC0415
    import yaml  # noqa: PLC0415
    # SECOND PASS OF THE ELEVENTH VERDICT: only a CHECKED request pre-fills another, and `checked`
    # names the run that checked these very bytes (the run record's goal is this typed request)
    assert intake.REUSABLE_STATUSES == ("checked",)
    with tempfile.TemporaryDirectory() as d:
        reqs = os.path.join(d, "requests")
        runs = os.path.join(d, "runs")
        os.makedirs(runs)

        def _run(rid, state):
            with open(os.path.join(runs, f"{rid}.json"), "w", encoding="utf-8") as fh:
                json.dump({"run_id": rid, "goal": intake.to_goal(state)}, fh)
        good = intake.new_state("feasibility", P, "alex")
        good["request"].update({"source": "Optum claims", "population": "COPD patients", "index_codes": "J44",
                                "measure": "top comorbidities", "baseline_lookback": "12 months"})
        p1 = intake.save_request(good, reqs)
        doc = yaml.safe_load(open(p1, encoding="utf-8"))
        assert doc["status"] == "draft" and doc["run_id"] is None and doc["outcome"] is None
        assert doc["request_sha256"] == intake.request_digest(good) and len(doc["request_sha256"]) == 64
        bad = copy.deepcopy(good)
        bad["request"]["baseline_lookback"] = "99 months"
        p2 = intake.save_request(bad, reqs, status="failed", run_id="r-1", outcome="step_budget_exhausted")
        doc2 = yaml.safe_load(open(p2, encoding="utf-8"))
        assert doc2["status"] == "failed" and doc2["run_id"] == "r-1"
        other = copy.deepcopy(good)
        other["pack"] = OC
        try:
            intake.save_request(other, reqs, status="checked", run_id="r-2", outcome="done")
            raise AssertionError("a checked request with no run record was kept")
        except ValueError as e:
            assert "no readable record" in str(e)
        _run("r-2", other)
        intake.save_request(other, reqs, status="checked", run_id="r-2", outcome="done")
        edited = copy.deepcopy(other)
        edited["request"]["exclusions"] = "prior lung cancer"
        try:
            intake.save_request(edited, reqs, status="checked", run_id="r-2", outcome="done")
            raise AssertionError("bytes the run never saw were kept as checked")
        except ValueError as e:
            assert "did not check this request" in str(e)
        mine = copy.deepcopy(good)
        _run("r-3", mine)
        intake.save_request(mine, reqs, status="checked", run_id="r-3", outcome="done")
        past = intake.load_requests(reqs)
        new = intake.new_state("feasibility", P, "bob")
        new["request"].update({"population": "COPD", "index_codes": "J44"})
        ranked = intake.similar(new, past, k=5, same_pack=False)
        assert all(r.get("status") == "checked" for _, r in ranked), "only a checked request is offered"
        assert len(ranked) == 2, [r["status"] for _, r in ranked]
        assert [r["pack"] for _, r in intake.similar(new, past, k=5)] == [P], "same product only, by default"
        # a prior version of the same product is the same product
        succ = intake.new_state("feasibility", P.replace("202606", "202607"), "bob")
        succ["request"].update({"population": "COPD", "index_codes": "J44"})
        assert intake.similar(succ, past, k=5) == []
        assert [r["pack"] for _, r in intake.similar(succ, past, k=5, lineage=[P])] == [P]
        in_scope = intake.similar(new, past, k=5, scope={P})
        assert len(in_scope) == 1 and in_scope[0][1]["pack"] == P, "another pack's request is not offered"
        failed_doc = next(r for r in past if r.get("status") == "failed")
        try:
            intake.prefill(new, failed_doc)
            raise AssertionError("a failed request pre-filled a new one")
        except ValueError as e:
            assert "REFUSED" in str(e)
    app = _read("experiments/portal/app.py")
    assert "intake.similar(state, intake.load_requests(), k=3, scope=set(MY_PACKS)," in app
    assert "lineage=portal_packs.lineage(str(ROOT), pack)" in app, "a prior version of the same product is offered"


# ------------------------------------------------------------------ P1 escalation authorization

def test_escalation_to_an_unregistered_owner_is_rerouted_to_operator():
    r = _escalated_run("ceo")
    asked = json.loads(r.outcome["summary"])
    assert asked["to"] == "operator", asked
    rer = [s for s in r.steps if s["kind"] == "escalation_rerouted"]
    assert rer and rer[0]["requested"] == "ceo"
    ok = _escalated_run("Science")
    assert json.loads(ok.outcome["summary"])["to"] == "Science"
    assert not any(s["kind"] == "escalation_rerouted" for s in ok.steps)


def test_resume_checks_the_answerers_eligibility_for_the_owner():
    import orchestrator as orc  # noqa: PLC0415
    from state import RunState  # noqa: PLC0415
    esc = _escalated_run("Science")
    try:
        orc.resume_run(esc.run_id, "ans", "someone", model=_Scripted([_tool("packs"), _done("x")]), answerer_owns={"DataExpert"})
        raise AssertionError("a DataExpert answered a Science question")
    except SystemExit as e:
        assert "eligib" in str(e).lower() and "Science" in str(e)
    assert not any(s["kind"] == "answered" for s in RunState.resume(esc.run_id).steps), "a refused resume closes nothing"
    r = orc.resume_run(esc.run_id, "ans", "someone", model=_Scripted([_tool("packs"), _done("x")]), answerer_owns={"Science"})
    assert r.outcome["status"] == "done"
    ans = [s for s in RunState.resume(esc.run_id).steps if s["kind"] == "answered"]
    assert ans and ans[0]["eligibility"] == "roster"
    esc2 = _escalated_run("Science")
    r2 = orc.resume_run(esc2.run_id, "ans", "nobody-in-the-roster", model=_Scripted([_tool("packs"), _done("x")]))
    ans2 = [s for s in RunState.resume(esc2.run_id).steps if s["kind"] == "answered"]
    assert r2.outcome["status"] == "done" and ans2[0]["eligibility"] == "unverified"
    app = _read("experiments/portal/app.py")
    assert 'answerer_owns=set(ACTOR.get("owns") or [])' in app and '"owns"' in app, "the roster carries who owns what"


def test_a_done_that_words_an_owners_approval_is_refused():
    import orchestrator as orc  # noqa: PLC0415
    for text in ("Science approved the 12-month window", "DataExpert has approved the mapping",
                 "Approval was granted by the owner", "approval is complete", "Engineering signed the release"):
        assert orc.claims_act(text), text
    for text in ("approval pending", "not approved yet", "Science has not approved this",
                 "the approval field is blank"):
        assert not orc.claims_act(text), text


def test_answered_is_recorded_only_on_an_accepted_terminal_outcome():
    import orchestrator as orc  # noqa: PLC0415
    from state import RunState  # noqa: PLC0415
    esc = _escalated_run("Science")
    r = orc.resume_run(esc.run_id, "ans", "someone", model=_Scripted([]), max_steps=2)
    assert r.outcome["status"] == "step_budget_exhausted"
    steps = RunState.resume(esc.run_id).steps
    assert not any(s["kind"] == "answered" for s in steps), "an exhausted successor answers nothing"
    assert any(s["kind"] == "answer_attempt" and s["outcome"] == "step_budget_exhausted" for s in steps)
    r2 = orc.resume_run(esc.run_id, "ans", "someone", model=_Scripted([_tool("packs"), _done("x")]))     # no allow_branch needed
    assert r2.outcome["status"] == "done"
    assert any(s["kind"] == "answered" for s in RunState.resume(esc.run_id).steps)


# ------------------------------------------------------------------ P2 control plane

def test_control_plane_validates_verdict_dates_per_kind_actions_and_derives_permissions():
    import control_plane as cp  # noqa: PLC0415
    assert cp.validate() == [], cp.validate()
    o = copy.deepcopy(cp.objectives())
    o["objectives"][0]["status"] = "released"
    o["objectives"][0]["verdict"] = {"adjudicated_by": "J. Smith", "date": "banana"}
    probs = cp.validate_objectives(o)
    assert any("date" in p and "banana" in p for p in probs), probs
    a = copy.deepcopy(cp.actions())
    a["actions"][0]["emits"] = {"object_kind": "decision", "action": "registered"}
    probs = cp.validate_actions(a)
    assert any("registered" in p and "decision" in p for p in probs), probs
    assert set(cp.performers("record_decision_answer")) >= {"Science", "DataExpert"}
    assert cp.performers("no_such_action") == []
    # the write-path scan is open-ended: every write-shaped flag is bound or explicitly read-only
    unbound = cp.unbound_write_flags()
    assert unbound == [], unbound


# ------------------------------------------------------------------ P2 coding agent identifier guard

def test_generated_code_identifiers_are_checked_against_reviewed_mapping_evidence():
    from contextlib import ExitStack
    from unittest.mock import patch
    import coding_agent as isolated_coding
    import state as isolated_state
    original_root = ROOT
    with tempfile.TemporaryDirectory(prefix="historical-code-audit-") as temporary, ExitStack() as scoped:
        scratch = Path(temporary)
        # The historical candidate names and every output stay in this owned
        # temporary root, including the standalone agent's promotion ledger.
        scoped.enter_context(patch.dict(globals(), {"ROOT": scratch,
            "_read": lambda relative: (original_root / relative).read_text(encoding="utf-8")}))
        scoped.enter_context(patch.object(isolated_coding, "ROOT", str(scratch)))
        scoped.enter_context(patch.object(isolated_coding, "CANDIDATES", str(scratch / "candidates")))
        scoped.enter_context(patch.object(isolated_state, "CANDIDATES", str(scratch / "candidates")))
        import coding_agent as ca  # noqa: PLC0415
        import critic  # noqa: PLC0415
        pack = "products/oncology/audit8_synthetic/202606"
        h = ROOT / pack / "handoff"
        shutil.rmtree(ROOT / "products/oncology/audit8_synthetic", ignore_errors=True)
        h.mkdir(parents=True)
        code = 'def f(frames, cfg):\n    dx = frames["dx"]\n    return dx.filter(F.col("icd_code") == "C61")\n'
        g = ca.identifier_guard(code, pack)
        assert g["status"] == "unverifiable" and "MAPPING_EVIDENCE" in g["why"]
        (h / "MAPPING_EVIDENCE.json").write_text(json.dumps({
            "ai_eligibility": {"state": "reviewed"},
            "tables": {"dx": {"icd_code": "code", "svc_date": "date"}}}), encoding="utf-8")
        g = ca.identifier_guard(code, pack)
        assert g["status"] == "ok" and set(g["checked"]) == {"dx", "icd_code"}
        bad = code + '    z = F.col("patient_zip")\n'
        g = ca.identifier_guard(bad, pack)
        assert g["status"] == "refused" and "patient_zip" in g["why"]
        # the guard runs BEFORE the critic; a refused candidate is stamped, not reviewed
        calls = []
        real = critic.review
        critic.review = lambda *a, **k: calls.append(1) or {"verdict": "never"}
        try:
            refused_reply = json.dumps({"mode": "generate", "generated": {"code": bad,
                "tests": "def test_x():\n    assert f({}, {}) == []\n", "assumptions": []}, "summary": "s"})
            # The specialist now offers one bounded correction before critique.
            # Keep the forbidden identifier in that correction, rather than let
            # the scripted model's exhausted-response fallback change the test.
            m = _Scripted([refused_reply, refused_reply])
            out = ca.run(pack, "PFS", model=m)
        finally:
            critic.review = real
            shutil.rmtree(ROOT / "products/oncology/audit8_synthetic", ignore_errors=True)
        assert calls == [] and m.usage["calls"] == 2, "the critic never saw either refused proposal"
        assert str(out["deterministic_checks"]["identifiers"]).startswith("REFUSED")
        assert out["critic"] is None and "REFUSED" in out["decision"]
        prov = out["provenance"]
        for k in ("schema_evidence_sha256", "model", "prompt_version", "commit", "originating_run"):
            assert k in prov, k
        assert prov["schema_evidence_sha256"] and prov["prompt_version"]


# ------------------------------------------------------------------ P2 ingress classification

def test_patient_shaped_text_is_refused_at_ingress_in_both_modes():
    import intake  # noqa: PLC0415
    assert intake.classify_ingress("MRN 00012345, DOB 1961-04-02, ICD C61 on 2023-01-05")
    assert intake.classify_ingress("SSN 123-45-6789")
    rows = "\n".join(f"10{i},2021-03-0{i},C61,M,1958-0{i}-11" for i in range(1, 7))
    assert intake.classify_ingress(rows), "a pasted table of individual rows"
    assert not intake.classify_ingress("COPD patients with J44 in any position, 12 months baseline, Optum 2023")
    assert not intake.classify_ingress("check")
    st = intake.new_state("feasibility", P, "alex")
    m = _Scripted([json.dumps({"request": {"population": "x"}, "ask": "?"})])
    st2, reply = intake.next_turn(st, "patient id 445566 DOB 1970-01-01 died 2022-05-05", m)
    assert m.usage["calls"] == 0, "patient-shaped text never reaches the model"
    assert st2["turns"] == st["turns"] and "individual" in reply.lower()
    app = _read("experiments/portal/app.py")
    from types import SimpleNamespace
    import ui_text as ui
    block = next(node for node in ast.walk(ast.parse(app)) if isinstance(node, ast.If)
                 and isinstance(node.test, ast.Name) and node.test.id == "q"
                 and any(isinstance(call, ast.Call) and ast.unparse(call.func) == "intake.classify_ingress"
                         for call in ast.walk(node)))
    run_ingress = compile(ast.Module(body=[block], type_ignores=[]), "<portal chat ingress>", "exec")
    class Rerender(Exception):
        pass
    def rerender():
        raise Rerender()
    for mode in (True, False):
        calls, chat = [], []
        def forbidden(*args, **kwargs):
            calls.append("model or job")
            raise AssertionError("Patient-shaped text reached a connection or governed job")
        scope = {"q": "patient id 445566 DOB 1970-01-01 died 2022-05-05", "intake": intake,
                 "intake_mode": mode, "chat": chat, "ACTOR": {"name": "Test Scientist"}, "ui": ui,
                 "st": SimpleNamespace(rerun=rerender), "jobs": SimpleNamespace(start=forbidden),
                 "agent_connection": SimpleNamespace(check_input=forbidden, intake_turn=forbidden)}
        try:
            exec(run_ingress, scope)
        except Rerender:
            pass
        else:
            raise AssertionError("Refused ingress must rerender before continuing")
        assert calls == [] and len(chat) == 2 and chat[0]["content"] == ui.WITHHELD
        assert "445566" not in json.dumps(chat) and "individual" in chat[1]["content"].lower()


# ------------------------------------------------------------------ P2 packaging

def test_the_portal_packages_for_databricks_apps_with_a_durable_state_dir():
    import yaml  # noqa: PLC0415
    doc = yaml.safe_load(_read("app.yaml"))
    assert "experiments/portal/app.py" in " ".join(doc["command"]), "the app root is the repository root"
    env = {e["name"]: e for e in doc["env"]}
    assert "valueFrom" in env["ANTHROPIC_API_KEY"] and "value" not in env["ANTHROPIC_API_KEY"]
    assert "valueFrom" in env["RWD_PORTAL_BOOTSTRAP_ADMIN"]
    assert "RWDP_STATE_DIR" in env
    assert not (ROOT / "experiments/portal/app.yaml").exists(), "one app.yaml, at the root Apps reads"
    for rel in ("experiments/agent/state.py", "experiments/agent/intake.py", "experiments/portal/app.py"):
        assert "RWDP_STATE_DIR" in _read(rel), rel
    import state  # noqa: PLC0415
    import intake  # noqa: PLC0415
    with tempfile.TemporaryDirectory() as d:
        os.environ["RWDP_STATE_DIR"] = d
        try:
            importlib.reload(state)
            assert state.RUNS.startswith(os.path.realpath(d)) and state.CANDIDATES.startswith(os.path.realpath(d))
            importlib.reload(intake)
            assert intake.REQUESTS.startswith(os.path.realpath(d))
        finally:
            del os.environ["RWDP_STATE_DIR"]
            importlib.reload(state)
            importlib.reload(intake)
    dep = _read("docs/DEPLOYMENT.md")
    for needle in ("valueFrom", "RWDP_STATE_DIR", "ephemeral"):
        assert needle in dep, needle


# ------------------------------------------------------------------ P3 the rest

def test_dry_run_stages_the_repo_relative_workbook_a_pack_registers():
    import dry_run  # noqa: PLC0415
    tmp, dst = dry_run._stage("sandbox/demo_walkthrough/bladder/202609")
    try:
        assert os.path.exists(os.path.join(tmp, "sandbox", "demo_walkthrough", "bladder_202609_program_spec.xlsx"))
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


def test_the_demo_and_sandbox_texts_agree_with_the_tree():
    demo = _read("DEMO.md")
    assert "**outside the checkout**" not in demo, "the walkthrough workbook is committed"
    assert "Sixteen rows in, sixteen scaffolded records out" not in demo
    assert "fifteen scaffolded" in demo.lower() or "fifteen new" in demo.lower()
    assert "traces to a signed specification" not in demo
    assert "not an Aetion or Foundry equivalent yet" in demo
    refs = _read("sandbox/demo_walkthrough/bladder/202609/source_refs.yaml")
    assert "means exactly what it says: no workbook has been approved" not in refs


def test_the_search_cache_key_is_a_per_file_identity_digest():
    import knowledge_search as ks  # noqa: PLC0415
    assert "impossible by construction" not in _read("platform/tools/knowledge_search.py")
    with tempfile.TemporaryDirectory() as d:
        h = os.path.join(d, "fixtures", "onc", "x", "202606", "handoff")
        os.makedirs(h)
        a, b = os.path.join(h, "DECISIONS.md"), os.path.join(h, "CONTRACT.md")
        open(a, "w", encoding="utf-8").write("| a |\n"); open(b, "w", encoding="utf-8").write("| b |\n")
        old = time.time() - 86400
        os.utime(a, (old, old))
        s1 = ks.tree_stamp(d)
        open(a, "a", encoding="utf-8").write("| a2 |\n"); os.utime(a, (old, old))     # an OLDER file edited
        s2 = ks.tree_stamp(d)
        assert s1 != s2, "an edit that does not move the newest mtime still changes the stamp"
        os.makedirs(os.path.join(h, "inventory"))
        open(os.path.join(h, "inventory", "tables.yaml"), "w", encoding="utf-8").write("x: 1\n")
        assert ks.tree_stamp(d) != s2, "a nested inventory file is part of the key"


def test_validate_manifest_types_every_mapping_and_the_template_mirrors_the_schema():
    import refresh  # noqa: PLC0415
    import yaml  # noqa: PLC0415
    fields = ("artifact_types", "source_qc", "stage_telemetry", "eda", "differential", "output_contract",
              "source_grain", "retention", "eda_acceptance", "deployment", "adapter_binding", "promoted_from")
    probs = refresh.validate_manifest({k: 5 for k in fields})
    for k in fields:
        assert any(f"manifest {k} must be a mapping" in p for p in probs), (k, probs[:5])
    tpl = yaml.safe_load(_read("refreshes/REFRESH_TEMPLATE.yaml"))
    for k in ("candidate_identity", "supersedes", "promoted_from", "deployment"):
        assert k in tpl, k


def test_portal_text_is_plain_language():
    assert (ROOT / "experiments/portal/ui_text.py").exists()
    banned = ("§", "exhaust", "REFUSED", "ContextVar", "noqa", "O_EXCL", "regex", "ungrounded", "step_budget",
              "orchestrator", "TWO places", "deterministic tabs", " — ", "->", "↳")
    for rel in ("experiments/portal/app.py", "experiments/portal/ui_text.py"):
        tree = ast.parse(_read(rel))
        docstrings = set()                                  # a docstring is for the maintainer, not the page
        for node in ast.walk(tree):
            if isinstance(node, (ast.Module, ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
                body = getattr(node, "body", [])
                if body and isinstance(body[0], ast.Expr) and isinstance(getattr(body[0], "value", None), ast.Constant):
                    docstrings.add(id(body[0].value))
        bad = []
        for node in ast.walk(tree):
            if isinstance(node, ast.Constant) and isinstance(node.value, str) and node.value.strip() \
                    and id(node) not in docstrings:
                for tok in banned:
                    if tok in node.value:
                        bad.append((tok, node.value[:70]))
        assert not bad, (rel, bad[:8])


# ------------------------------------------------------------------ the independent review of this branch

def test_the_page_cache_is_keyed_by_the_actors_scope():
    app = _read("experiments/portal/app.py")
    assert "def cached(scope_key: tuple, tool: str, **args)" in app
    assert "tools.call(tool, args, scope=set(scope_key))" in app
    assert "SCOPE_KEY = tuple(sorted(MY_PACKS))" in app
    calls = re.findall(r"\bcached\((\w+),", app)
    assert calls and all(c == "SCOPE_KEY" for c in calls), calls


def test_packs_and_semantic_search_are_filtered_by_scope():
    import tools  # noqa: PLC0415
    out = tools.call("packs", {}, scope={P})
    assert P in out and OC not in out and "oc/202606" not in out, out[:300]
    saved = tools.EXTRA_TOOLS["semantic_search"]
    fake = (lambda a: f"(decision · {P}/handoff/DECISIONS.md) row one\n(decision · {OC}/handoff/DECISIONS.md) row two",
            saved[1], saved[2])
    tools.EXTRA_TOOLS["semantic_search"] = fake
    try:
        out = tools.call("semantic_search", {"query": "x"}, scope={P})
    finally:
        tools.EXTRA_TOOLS["semantic_search"] = saved
    assert "row one" in out and "row two" not in out and "outside your scope" in out


def test_an_unfinished_successor_leaves_the_question_open_in_the_queue():
    import queues  # noqa: PLC0415
    esc = json.dumps({"to": "Science", "question": "q", "evidence": "e"})
    with tempfile.TemporaryDirectory() as d:
        json.dump({"run_id": "20260904-000000-000001-aaaa", "goal": f"g {P}", "actor": None,
                   "steps": [{"kind": "answer_attempt", "by": "x", "run": "20260904-000000-000002-bbbb",
                              "outcome": "step_budget_exhausted", "eligibility": "unverified"}],
                   "outcome": {"status": "escalated", "summary": esc}},
                  open(os.path.join(d, "20260904-000000-000001-aaaa.json"), "w", encoding="utf-8"))
        json.dump({"run_id": "20260904-000000-000002-bbbb", "goal": f"g {P}", "actor": None,
                   "steps": [{"kind": "human_answer", "answers_run": "20260904-000000-000001-aaaa", "by": "x"}],
                   "outcome": {"status": "step_budget_exhausted", "summary": "max steps"}},
                  open(os.path.join(d, "20260904-000000-000002-bbbb.json"), "w", encoding="utf-8"))
        rows = queues.escalations(d)
        assert len(rows) == 1 and rows[0]["answered"] is False and rows[0]["attempts"] == 1, rows
        # the same successor, finished: now it answers, and the eligibility travels
        json.dump({"run_id": "20260904-000000-000002-bbbb", "goal": f"g {P}", "actor": None,
                   "steps": [{"kind": "human_answer", "answers_run": "20260904-000000-000001-aaaa", "by": "x",
                              "eligibility": "roster"}],
                   "outcome": {"status": "done", "summary": "ok"}},
                  open(os.path.join(d, "20260904-000000-000002-bbbb.json"), "w", encoding="utf-8"))
        rows = queues.escalations(d)
        assert rows[0]["answered"] is True and rows[0]["answered_by"] == "x" and rows[0]["eligibility"] == "roster"


def test_claims_act_catches_present_tense_titles_and_by_phrases_but_not_state():
    import orchestrator as orc  # noqa: PLC0415
    for text in ("Science approves the 30-day window.", "The window was approved by the Science team.",
                 "Approved by the Science owner.", "Science has agreed to the definition.", "Science accepted the rule",
                 "the Science owner confirmed the mapping", "DataExpert agrees"):
        assert orc.claims_act(text), text
    for text in ("Science approval is pending", "awaiting approval by Science", "the Science owner has not approved this yet",
                 "Science records show a 12-month window", "Science has not agreed", "approval pending"):
        assert not orc.claims_act(text), text


def test_a_patient_shaped_answer_is_refused_on_resume():
    import orchestrator as orc  # noqa: PLC0415
    from state import RunState  # noqa: PLC0415
    esc = _escalated_run("Science")
    try:
        orc.resume_run(esc.run_id, "MRN 00012345, DOB 1960-01-01, died 2022-05-05", "someone",
                       model=_Scripted([_tool("packs"), _done("x")]))
        raise AssertionError("patient-shaped text reached the model")
    except SystemExit as e:
        assert "individual" in str(e)
    assert not any(s["kind"] in ("answered", "answer_attempt") for s in RunState.resume(esc.run_id).steps)
    app = _read("experiments/portal/app.py")
    i = app.index('if st.button("Resume with this answer"')
    assert "intake.classify_ingress(ans)" in app[i:i + 600]


def test_malformed_args_from_the_model_are_an_observation_not_a_crash():
    import orchestrator as orc  # noqa: PLC0415
    bad = json.dumps({"action": "tool", "tool": "packs", "args": [1, 2], "why": "x"})
    r = orc.run("g", model=_Scripted([bad, _tool("packs"), _done("x")]), max_steps=4, scope={P})
    assert r.outcome["status"] == "done"
    assert any(s["kind"] == "malformed_args" and s["got"] == "list" for s in r.steps)


if __name__ == "__main__":
    fails = 0
    for name, fn in sorted(globals().items()):
        if name.startswith("test_") and callable(fn):
            try:
                fn()
                print(f"  ok   {name}")
            except Exception as e:  # noqa: BLE001
                fails += 1
                print(f"  FAIL {name}: {type(e).__name__}: {str(e)[:300]}")
    print(f"{fails} failure(s)")
    sys.exit(1 if fails else 0)
