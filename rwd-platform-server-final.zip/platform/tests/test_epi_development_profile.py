"""Portable development profiles remain separate from hosted authentication."""
from __future__ import annotations

import json
import sys
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[2]
PORTAL = str(ROOT / "experiments" / "portal")
sys.path.insert(0, PORTAL)
import identity


def test_explicit_development_mode_is_portable_and_does_not_change_hosted_default():
    assert identity.mode({}) == "hosted"
    assert identity.mode({identity.DEVELOPMENT_ENV: "1", identity.WORKSPACE_ENV: "1"}) == "demo"
    assert identity.mode({identity.DEVELOPMENT_ENV: "0", identity.WORKSPACE_ENV: "1"}) == "local"
    profile = identity.development_profile([], "Priya Sharma", "PRIYA@example.org")[0]
    assert profile["email"] == "priya@example.org"
    assert identity.resolve({}, [profile], False)[0] is None
    assert identity.resolve({}, [profile], True, "Priya Sharma")[0] == profile
    assert identity.resolve({"X-Forwarded-Email": "other@example.org"}, [profile], False)[0] is None


def test_profile_edit_keeps_existing_role_scope_and_rejects_duplicate_email():
    users = [{"name": "Priya Sharma", "email": "old@example.org", "role": "reviewer", "packs": ["one"]},
             {"name": "Alex", "email": "alex@example.org", "role": "reviewer"}]
    updated = identity.development_profile(users, "priya sharma", "priya@example.org")
    assert updated[0]["role"] == "reviewer" and updated[0]["packs"] == ["one"]
    assert updated[0]["name"] == "Priya Sharma" and users[0]["email"] == "old@example.org"
    with pytest.raises(ValueError, match="another profile"):
        identity.development_profile(users, "Priya Sharma", "alex@example.org")


@pytest.mark.parametrize("name,email", [("", "person@example.org"), ("Person", "missing-email"),
                                      ("Person", "a b@example.org"), ("Person", "a\x00b@example.org")])
def test_profile_validation_keeps_invalid_entries_out(name, email):
    with pytest.raises(ValueError):
        identity.development_profile([], name, email)


def _script(path, portal, enabled):
    import json
    import sys
    from pathlib import Path
    import streamlit as st
    sys.path.insert(0, portal)
    import development_profile_page
    import identity
    users = json.loads(Path(path).read_text()) if Path(path).exists() else identity.default_users(True)
    development_profile_page.render(path, users, enabled=enabled)
    chosen = st.sidebar.selectbox("Profile", [u["name"] for u in users], key="who")
    actor, _ = identity.resolve({}, users, True, chosen)
    st.write(actor.get("email") or actor["name"])


def test_profile_form_saves_and_selects_profile_and_returns_after_server_restart(tmp_path):
    from streamlit.testing.v1 import AppTest
    path = tmp_path / "state" / "users.json"
    kwargs = {"path": str(path), "portal": PORTAL, "enabled": True}
    app = AppTest.from_function(_script, kwargs=kwargs).run()
    app.text_input(key="development_profile_name").set_value("Priya Sharma")
    app.text_input(key="development_profile_email").set_value("PRIYA@example.org")
    app.button[0].click().run()
    assert not app.exception
    assert app.selectbox(key="who").value == "Priya Sharma"
    assert json.loads(path.read_text())[0]["email"] == "priya@example.org"
    restarted = AppTest.from_function(_script, kwargs=kwargs).run()
    assert not restarted.exception
    assert restarted.text_input(key="development_profile_email").value == "priya@example.org"
    assert restarted.selectbox(key="who").value == "Priya Sharma"
    restarted.text_input(key="development_profile_name").set_value("Alex Review")
    restarted.text_input(key="development_profile_email").set_value("alex@example.org")
    restarted.button[0].click().run()
    assert not restarted.exception and restarted.selectbox(key="who").value == "Alex Review"
    restarted.selectbox(key="who").set_value("Priya Sharma").run()
    assert not restarted.exception
    assert restarted.text_input(key="development_profile_email").value == "priya@example.org"
    restarted.text_input(key="development_profile_email").set_value("alex@example.org")
    restarted.button[0].click().run()
    assert not restarted.exception and any("another profile" in item.value for item in restarted.error)
    assert json.loads(path.read_text())[0]["email"] == "priya@example.org"


def test_profile_form_is_absent_without_explicit_development_mode(tmp_path):
    from streamlit.testing.v1 import AppTest
    path = tmp_path / "users.json"
    app = AppTest.from_function(_script, kwargs={"path": str(path), "portal": PORTAL, "enabled": False}).run()
    assert not app.exception and not app.text_input and not app.button and not path.exists()
