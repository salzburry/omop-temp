"""Dead ends on the Flow spine an audit run found (2026-09-07), each closed and pinned here.

FLOW-04  the extraction's classification TODOs opened the workbook's access form, forever
FLOW-05  an unregistered pack dead-ended on a command with placeholders and a disabled button
FLOW-06  the demo pack's next step was a lint failing on a register no act named (ENGINE_GAPS.md)
FLOW-09  the receipt check was offered as ready on fixtures and sandbox packs and always failed
FLOW-10  an empty source_refs.yaml read as unregistered while the first write was withheld
FLOW-11  the page printed one command style while the command form built another

    python platform/tests/test_epi_flow_dead_ends.py
No governed write leaves a temporary root; page checks use Streamlit's AppTest with doubles.
"""
from __future__ import annotations

import json
import os
from pathlib import Path
import shutil
import shlex
import subprocess
import sys
import tempfile
from unittest.mock import patch

import yaml

sys.path.insert(0, str(Path(__file__).resolve().parent))
from _epi_test_support import api, run
pytest = api(__name__)
ROOT = Path(__file__).resolve().parents[2]
sys.path[:0] = [str(ROOT / "platform/tools"), str(ROOT / "experiments/portal"), str(ROOT / "platform")]
import flow                                                                  # noqa: E402
import flow_guidance as guidance                                             # noqa: E402
import resolution_commands                                                   # noqa: E402
import source_manifest as sm                                                 # noqa: E402
import source_refs_init as init                                              # noqa: E402
import workflow_forms as forms                                               # noqa: E402

PACK = "products/oncology/example/202609"
PROSTATE = "fixtures/oncology/prostate/202606"
DEMO = "sandbox/demo_walkthrough/bladder/202609"
WORKBOOK = {"material_id": "program_spec", "material_type": "program_spec", "path_or_link": "prog_spec/spec.xlsx",
            "status": "pending", "why_provisional": "Awaiting review", "sha256": "a" * 64,
            "ai_classification": "sponsor_ai_eligible", "classified_by": "Alice Smith", "classified_date": "2026-09-05"}
EXTRACTION = {"material_id": "sanitized_extraction", "material_type": "ai_extraction", "role": "the sanitized extraction",
              "status": "pending", "path_or_link": "spec_pipeline/out/extracted.json", "sha256": "b" * 64,
              "derived_from": "program_spec", "ai_classification": "TODO", "classified_by": "TODO", "classified_date": "TODO"}


def _pack(root, *materials, registry=True):
    product = root / PACK
    (product / "prog_spec").mkdir(parents=True, exist_ok=True)
    (product / "handoff").mkdir(exist_ok=True)
    if registry:
        (root / "products/registry.yaml").write_text("tumors:\n  - slug: example\n    family: oncology\n    code: example\n    role: product\n",
                                                     encoding="utf-8")
    if materials:
        (product / "source_refs.yaml").write_text(yaml.safe_dump({"product": "example", "spec_version": "202609",
                                                                  "source_materials": list(materials)}, sort_keys=False), encoding="utf-8")
    return product


def _gate1(root):
    return {a["id"]: a for a in flow.acts(PACK, str(root))[1]}


def _files(root):
    return {p.relative_to(root).as_posix(): p.read_bytes() for p in root.rglob("*") if p.is_file()}


# FLOW-04 ------------------------------------------------------------------------------------------

def test_classify_names_the_material_it_edits_workbook_first(tmp_path):
    _pack(tmp_path, WORKBOOK, EXTRACTION)
    act = _gate1(tmp_path)["g1_classify"]
    assert (act["material_id"], act["material_type"]) == ("sanitized_extraction", sm.AI_EXTRACTION), act
    assert act["kind"] == flow.PERSON and "sanitized_extraction" in act["label"]
    copy = guidance.issue_copy(act)
    assert "extracted" in copy["title"].lower() and "extracted source form" in " ".join(copy["steps"])
    # the workbook's own TODOs come first: its access form, then the extraction's on the next check
    _pack(tmp_path, {**WORKBOOK, "classified_by": "TODO"}, EXTRACTION)
    act = _gate1(tmp_path)["g1_classify"]
    assert (act["material_id"], act["material_type"]) == ("program_spec", sm.PROGRAM_SPEC), act
    assert "program_spec" in act["label"] and "sanitized_extraction" in act["label"]
    assert "extracted" not in guidance.issue_copy(act)["title"].lower()
    for finding in ("Gate 1: x: source_materials[1]: requires `ai_classification` (sponsor_ai_eligible | ...)",
                    "Gate 1: x: source_materials[1]: requires `classified_date` — ..."):
        assert flow._first_for(finding, list(_gate1(tmp_path).values()))[0]["id"] == "g1_classify"


def test_the_page_opens_the_extraction_form_for_the_extraction_and_the_access_form_for_the_workbook():
    from test_epi_flow_page import _action, _flow, _open, _page
    with tempfile.TemporaryDirectory(prefix="epi-flow04-") as td:
        root = Path(td)
        _pack(root, WORKBOOK, EXTRACTION)
        before = _files(root)
        extraction = dict(_action("g1_classify", "person", "Answer the TODOs on sanitized_extraction"),
                          material_id="sanitized_extraction", material_type=sm.AI_EXTRACTION)
        result = _flow([extraction])
        result["blockers"][0]["text"] = f"{PACK}: source_materials[1]: requires `ai_classification`"
        with _page(result, root=td, pack=PACK, can_review=True) as (at, case):
            _open(at)
            keys = {str(getattr(e, "key", "")) for e in at.button} | {str(r.key) for r in at.radio}
            assert "definition_source_reload" in keys, sorted(keys)
            assert "source_review_section" not in keys, "the workbook's access form is not the form for the extraction"
            assert "flow_run_action" not in keys
            case.run_action.assert_not_called()
        workbook = dict(_action("g1_classify", "person", "Answer the TODOs on program_spec"),
                        material_id="program_spec", material_type=sm.PROGRAM_SPEC)
        with _page(_flow([workbook]), root=td, pack=PACK, can_review=True) as (at, case):
            _open(at)
            assert at.radio(key="source_review_section").value == "AI access"
            assert not any(str(getattr(e, "key", "")) == "definition_source_reload" for e in at.button)
            # the workbook's decision is already recorded: the form says so instead of looping
            assert any("already recorded" in str(item.value) and "extracted source form" in str(item.value) for item in at.info)
        assert _files(root) == before


# FLOW-05 ------------------------------------------------------------------------------------------

def test_first_registration_form_collects_the_three_human_values_and_writes_the_tools_own_file(tmp_path):
    _pack(tmp_path)
    act = _gate1(tmp_path)["g1_init"]
    assert act["kind"] == flow.WRITE and "<class>" in act["argv"] and "g1_init" in forms.WRITE_FORMS
    description = forms.describe(tmp_path, PACK, act, allowed_packs=[PACK])
    assert description["ok"] and description["kind"] == "registration" and not description["exists"], description
    assert [f["name"] for f in description["fields"]] == ["ai_classification", "classified_by", "classified_date"]
    assert description["fields"][0]["choices"] == list(sm.AI_CLASSES)
    assert all(f["value"] == "" and f["required"] for f in description["fields"]), "no default for a person's judgment"
    assert description["target"] == f"{PACK}/source_refs.yaml"
    human = {"ai_classification": "vendor_restricted", "classified_by": "Ada Lovelace", "classified_date": "2026-09-07"}

    def save(values, **kw):
        return forms.save(tmp_path, PACK, act, values, expected_manifest_digest=description["manifest_digest"],
                          confirmed=kw.get("confirmed", True), local_demo=kw.get("local_demo", True),
                          can_review=kw.get("can_review", True), allowed_packs=[PACK])

    before = _files(tmp_path)
    for bad in ({**human, "classified_by": "TBD"}, {**human, "classified_by": "DataExpert"}, {**human, "classified_date": "2026-13-07"},
                {**human, "ai_classification": "anything"}, {**human, "ai_classification": ""}, {"classified_by": "Ada Lovelace"}):
        result = save(bad)
        assert not result["ok"] and result["errors"], bad
    for refused in ({"confirmed": False}, {"local_demo": False}, {"can_review": False}):
        assert not save(human, **refused)["ok"], refused
    assert _files(tmp_path) == before, "a refusal writes nothing"
    result = save(human)
    assert result["ok"] and result["changed"] and not result["authenticated"], result
    written = (tmp_path / PACK / "source_refs.yaml").read_text(encoding="utf-8")
    expected = init.render(init.document(PACK, "vendor_restricted", "Ada Lovelace", "2026-09-07",
                                         description["path_or_link"], root=str(tmp_path)))
    assert written == expected, "the file is the tool's own composition, byte for byte"
    material = yaml.safe_load(written)["source_materials"][0]
    assert material["status"] == "pending" and material["classified_by"] == "Ada Lovelace"
    assert not [e for e in sm.check(str(tmp_path), PACK) if "classif" in e], "the registration passes Gate 1 as provisional"
    assert "g1_init" not in _gate1(tmp_path) and "g1_workbook" in _gate1(tmp_path)
    assert not forms.describe(tmp_path, PACK, act, allowed_packs=[PACK])["ok"], "registration never replaces a registration"
    assert not [p for p in (tmp_path / PACK).iterdir() if p.name.startswith(".")], "no lock or temporary file is left"


def test_first_registration_names_the_one_workbook_in_prog_spec_and_needs_the_registry(tmp_path):
    product = _pack(tmp_path)
    (product / "prog_spec/spec.xlsx").write_bytes(b"not parsed here")
    act = _gate1(tmp_path)["g1_init"]
    description = forms.describe(tmp_path, PACK, act, allowed_packs=[PACK])
    assert description["path_or_link"] == f"{PACK}/prog_spec/spec.xlsx" and description["workbooks"] == ["spec.xlsx"]
    (product / "prog_spec/other.xlsx").write_bytes(b"a second one")
    description = forms.describe(tmp_path, PACK, act, allowed_packs=[PACK])
    assert description["path_or_link"].startswith("TBD") and len(description["workbooks"]) == 2
    (tmp_path / "products/registry.yaml").unlink()
    description = forms.describe(tmp_path, PACK, act, allowed_packs=[PACK])
    assert description["ok"] and description["missing_inputs"] and "registry" in description["missing_inputs"][0]
    result = forms.save(tmp_path, PACK, act, {"ai_classification": "vendor_restricted", "classified_by": "Ada Lovelace", "classified_date": "2026-09-07"},
                        expected_manifest_digest=description["manifest_digest"], confirmed=True, local_demo=True, can_review=True, allowed_packs=[PACK])
    assert not result["ok"] and not (product / "source_refs.yaml").exists()


def test_the_page_offers_the_registration_form_instead_of_a_disabled_button():
    from test_epi_flow_page import _action, _flow, _open, _page
    with tempfile.TemporaryDirectory(prefix="epi-flow05-") as td:
        root = Path(td)
        _pack(root)
        init_act = _action("g1_init", "write", "Write the first source_refs.yaml from your classification",
                           ["platform/tools/source_refs_init.py", PACK, "--ai-classification", "<class>", "--classified-by", "<you>", "--classified-date", "<YYYY-MM-DD>"])
        result = _flow([init_act])
        result["blockers"][0]["text"] = "Gate 1: source is unregistered, not approved"
        with _page(result, root=td, pack=PACK, can_review=True) as (at, case):
            _open(at)
            keys = {str(getattr(e, "key", "")) for e in at.button}
            assert "flow_run_action" not in keys and "workflow_forms_save" in keys, sorted(keys)
            assert not any(str(k).startswith("resolution_command_field") for k in {t.key for t in at.text_input}), "one form, not the command's placeholders twice"
            choice = at.selectbox(key="workflow_forms_value_ai_classification")
            assert len(choice.options) == len(sm.AI_CLASSES) and choice.value is None, "the closed vocabulary, with no class chosen for the person"
            assert {"workflow_forms_value_classified_by", "workflow_forms_value_classified_date"} <= {t.key for t in at.text_input}
            assert not at.button(key="workflow_forms_save").disabled
            # the values first (any change unchecks the confirmation, on purpose), then the confirmation
            choice.set_value("sponsor_ai_eligible")
            at.text_input(key="workflow_forms_value_classified_by").set_value("Ada Lovelace")
            at.text_input(key="workflow_forms_value_classified_date").set_value("2026-09-07").run()
            assert not at.exception, "\n".join(str(e.message) for e in at.exception)
            at.checkbox(key="workflow_forms_confirm").set_value(True)
            at.button(key="workflow_forms_save").click().run()
            assert not at.exception, "\n".join(str(e.message) for e in at.exception)
            assert any("Record created" in str(s.value) for s in at.success), \
                ([str(s.value) for s in at.success], [str(e.value) for e in at.error], [str(w.value) for w in at.warning])
            written = yaml.safe_load((root / PACK / "source_refs.yaml").read_text(encoding="utf-8"))
            material = written["source_materials"][0]
            assert (material["ai_classification"], material["classified_by"], material["classified_date"], material["status"]) == \
                ("sponsor_ai_eligible", "Ada Lovelace", "2026-09-07", "pending")
            assert case.evaluate.call_count == 1, "the page checks again after the write"
            case.run_action.assert_not_called()
        # a viewer sees the form disabled and writes nothing
        (root / PACK / "source_refs.yaml").unlink()
        with _page(result, root=td, pack=PACK, can_review=False) as (at, case):
            _open(at)
            assert at.button(key="workflow_forms_save").disabled
            assert not (root / PACK / "source_refs.yaml").exists()


# FLOW-06 ------------------------------------------------------------------------------------------

def test_the_gap_register_is_one_the_register_form_offers(tmp_path):
    product = _pack(tmp_path, WORKBOOK)
    (product / "handoff/MATURITY.yaml").write_text("contract: draft\nconfiguration: not_started\n", encoding="utf-8")
    shutil.copytree(ROOT / forms.TEMPLATES, tmp_path / forms.TEMPLATES)
    assert flow.gate_state(str(product))["registers_missing"] == ["DECISIONS.md", "SPEC_QC_FINDINGS.md", "ENGINE_GAPS.md"]
    menu = flow.acts(PACK, str(tmp_path))[2]
    registers = next(a for a in menu if a["id"] == "g2_registers")
    assert "handoff/ENGINE_GAPS.md" in registers["label"]
    assert flow._first_for("handoff/ENGINE_GAPS.md is missing — write the register (its canonical header is ...)", menu)[0]["id"] == "g2_registers"
    description = forms.describe(tmp_path, PACK, "g2_registers", allowed_packs=[PACK])
    assert description["ok"] and f"{PACK}/handoff/ENGINE_GAPS.md" in description["targets"], description
    for name in ("DECISIONS.md", "SPEC_QC_FINDINGS.md", "ENGINE_GAPS.md"):
        target = f"{PACK}/handoff/{name}"
        description = forms.describe(tmp_path, PACK, "g2_registers", target=target, allowed_packs=[PACK])
        result = forms.save(tmp_path, PACK, "g2_registers", {}, expected_manifest_digest=description["manifest_digest"], confirmed=True,
                            local_demo=True, can_review=True, target=target, allowed_packs=[PACK])
        assert result["ok"], (name, result["errors"])
    gaps = (product / "handoff/ENGINE_GAPS.md").read_text(encoding="utf-8")
    assert "| Gap ID |" in gaps and gaps.count("\n|") == 2, gaps
    import contract_lint as cl
    assert not cl.gap_ids(gaps), "an empty register indexes no gap"
    assert flow.gate_state(str(product))["registers_missing"] == []
    assert not any(a["id"] == "g2_registers" for a in flow.acts(PACK, str(tmp_path))[2])


def test_the_demo_pack_s_missing_gap_register_is_named_by_an_act():
    fl = flow.flow(str(ROOT), DEMO)
    assert fl["current"] == 2, fl["proceed"]
    registers = [a for card in fl["blockers"] for a in card["fixes"] if a["id"] == "g2_registers"]
    assert registers and "handoff/ENGINE_GAPS.md" in registers[0]["label"], [a["id"] for a in fl["blockers"][0]["fixes"]]
    assert "ENGINE_GAPS.md" in flow.gate_state(str(ROOT / DEMO))["registers_missing"]


# FLOW-09 ------------------------------------------------------------------------------------------

def test_the_receipt_check_is_offered_only_where_a_receipt_could_exist(tmp_path):
    for pack in (PROSTATE, DEMO, "platform/TUMOR_TEMPLATE"):
        assert not any(a["id"] == "g6_receipt" for a in flow.acts(pack, str(ROOT))[6]), pack
    _pack(tmp_path, WORKBOOK)
    receipt = next(a for a in flow.acts(PACK, str(tmp_path))[6] if a["id"] == "g6_receipt")
    assert receipt["kind"] == flow.READ and receipt["argv"] == ["platform/tools/flow.py", PACK, "--check-receipts"]
    assert flow.production_pack(PACK) and not flow.production_pack(PROSTATE) and not flow.production_pack("products/oncology/x")
    done = [(n, f"Gate {n}", "done", []) for n in range(1, 7)]
    with patch.object(flow.status, "gates", return_value=done):
        clear = flow.flow(str(ROOT), PROSTATE)
        assert clear["clear"] and [a["id"] for a in clear["closing"]] == ["g6_countersign", "g6_commit"], clear["closing"]
        clear = flow.flow(str(tmp_path), PACK)
        assert [a["id"] for a in clear["closing"]] == ["g6_countersign", "g6_commit", "g6_receipt"]


# FLOW-10 ------------------------------------------------------------------------------------------

@pytest.mark.parametrize("content", ["", "   \n\n", "- a\n- b\n", "just words\n", "42\n"])
def test_an_empty_or_non_mapping_source_record_is_no_registration(tmp_path, content):
    product = _pack(tmp_path)
    (product / "source_refs.yaml").write_text(content, encoding="utf-8")
    reg = flow.registration_state(str(product))
    assert (reg["exists"], reg["present"], reg["unreadable"]) == (False, True, ""), reg
    menu = flow.acts(PACK, str(tmp_path))[1]
    assert [a["id"] for a in menu] == ["g1_check", "g1_init"], [a["id"] for a in menu]
    first = flow._first_for("Gate 1: source is unregistered, not approved", menu)[0]
    assert first["id"] == "g1_init" and "replaced" in first["note"], first
    description = forms.describe(tmp_path, PACK, first, allowed_packs=[PACK])
    assert description["ok"] and description["replaces"] and not description["exists"], description
    result = forms.save(tmp_path, PACK, first, {"ai_classification": "restricted_derived", "classified_by": "Ada Lovelace", "classified_date": "2026-09-07"},
                        expected_manifest_digest=description["manifest_digest"], confirmed=True, local_demo=True, can_review=True, allowed_packs=[PACK])
    assert result["ok"], result["errors"]
    assert yaml.safe_load((product / "source_refs.yaml").read_text(encoding="utf-8"))["source_materials"][0]["ai_classification"] == "restricted_derived"
    assert flow.registration_state(str(product))["exists"]


def test_a_malformed_source_record_with_content_is_a_repair_act_and_never_regenerated(tmp_path):
    product = _pack(tmp_path)
    (product / "source_refs.yaml").write_text("product: example\nsource_materials: [unclosed\n", encoding="utf-8")
    original = (product / "source_refs.yaml").read_bytes()
    reg = flow.registration_state(str(product))
    assert reg["present"] and reg["unreadable"] and not reg["exists"], reg
    menu = flow.acts(PACK, str(tmp_path))[1]
    assert [a["id"] for a in menu] == ["g1_check", "g1_repair"], [a["id"] for a in menu]
    repair = menu[1]
    assert repair["kind"] == flow.PERSON and repair["path"] == f"{PACK}/source_refs.yaml" and repair["actions_row"] == "register_or_revise_material"
    assert "not regenerated" in repair["note"] and "—" not in repair["label"]
    finding = f"Gate 1: {PACK}: source_refs.yaml is not readable YAML (while parsing) — Gate 1 cannot tell what this pack's source is, which is refused, not skipped"
    assert flow._first_for(finding, menu)[0]["id"] == "g1_repair"
    assert flow._first_for("Gate 1: source is unregistered, not approved", menu)[0]["id"] == "g1_repair"
    copy = guidance.issue_copy(repair)
    assert "never regenerated" in " ".join(copy["steps"]) and "—" not in copy["summary"]
    assert not forms.describe(tmp_path, PACK, "g1_init", allowed_packs=[PACK])["ok"], "the first write is withheld over a file with content"
    assert (product / "source_refs.yaml").read_bytes() == original
    # a mapping that names no program_spec material is a repair too, with the other acts withheld
    (product / "source_refs.yaml").write_text("product: example\nspec_version: '202609'\n", encoding="utf-8")
    menu = flow.acts(PACK, str(tmp_path))[1]
    assert [a["id"] for a in menu] == ["g1_check", "g1_repair"] and "program_spec" in menu[1]["label"]
    assert flow._first_for(f"Gate 1: {PACK}: source_refs.yaml lists no source_materials", menu)[0]["id"] == "g1_repair"


# FLOW-11 ------------------------------------------------------------------------------------------

def test_the_page_and_the_command_form_render_one_command_style(tmp_path):
    import flow_page
    _pack(tmp_path, WORKBOOK)
    check = next(a for a in flow.acts(PACK, str(tmp_path))[1] if a["id"] == "g1_check")
    shown = flow_page._command(tmp_path, check)
    assert shown == resolution_commands.render(tmp_path, check["argv"])
    assert str(resolution_commands.interpreter(tmp_path)) in shown and "python platform/tools" not in shown
    assert str((tmp_path / "platform/tools/source_manifest.py").resolve()) in shown and "--check" in shown
    for windows in (True, False):
        text = resolution_commands.render(tmp_path, check["argv"], windows=windows)
        assert ("Push-Location" in text) is windows and ("cd " in text) is not windows
    assert flow_page._command(tmp_path, {"argv": []}) == "" and flow_page._command(tmp_path, {}) == ""
    # the form's complete command is the same rendering once the tool and interpreter are verified
    (tmp_path / "platform/tools").mkdir(parents=True)
    (tmp_path / "platform/tools/source_manifest.py").write_text("# stand-in for the tool\n", encoding="utf-8")
    assert resolution_commands.interpreter(tmp_path) == Path(sys.executable).absolute()
    built = resolution_commands.build(tmp_path, PACK, check)
    assert built["command"] == flow_page._command(tmp_path, check)
    handoff = flow_page._handoff(tmp_path, PACK, {"text": "x", "owner": "Science"}, check, {"title": "t", "summary": "s", "steps": []})
    assert built["command"] in handoff and "python platform/tools" not in handoff


@pytest.mark.parametrize("windows", [True, False])
def test_commands_keep_selected_external_interpreter_and_quote_shell_arguments(tmp_path, monkeypatch, windows):
    import review_setup
    selected = tmp_path / "external runtime ' quoted" / "python"
    monkeypatch.setattr(resolution_commands.sys, "executable", str(selected))
    monkeypatch.setenv("RWD_PORTAL_PYTHON", str(tmp_path / "older-env/python"))
    reviewer = "O'Neil $(literal)"
    command = review_setup.command(tmp_path, PACK, "science", reviewer, "digest", windows=windows)
    assert str(resolution_commands.interpreter(tmp_path)) == str(selected)
    assert ".venv" not in command and "older-env" not in command
    if windows:
        assert "'" + str(selected).replace("'", "''") + "'" in command
        assert "'O''Neil $(literal)'" in command and "Push-Location -LiteralPath" in command
    else:
        assert shlex.quote(str(selected)) in command
        assert shlex.quote(reviewer) in command and command.startswith("(cd ")


@pytest.mark.parametrize("kind", ["workflow", "review"])
def test_generated_command_runs_selected_python_in_checkout_with_literal_arguments(tmp_path, kind):
    import review_setup
    root = tmp_path / "checkout with spaces ' quote"
    script = root / "experiments/portal/review_setup.py"
    script.parent.mkdir(parents=True)
    script.write_text("import json, os, sys\nprint(json.dumps({'python': sys.executable, 'cwd': os.getcwd(), 'args': sys.argv[1:]}))\n", encoding="utf-8")
    reviewer = "O'Neil $(literal); & still literal"
    argv = ["experiments/portal/review_setup.py", "--pack", PACK, "--checkpoint", "science",
            "--reviewer", reviewer, "--expected", "digest"]
    shown = (resolution_commands.render(root, argv) if kind == "workflow" else
             review_setup.command(root, PACK, "science", reviewer, "digest"))
    shell = (["powershell", "-NoProfile", "-NonInteractive", "-Command", shown] if os.name == "nt" else
             ["/bin/sh", "-c", shown])
    result = subprocess.run(shell, capture_output=True, text=True, encoding="utf-8", timeout=20)
    assert result.returncode == 0, result.stderr
    output = json.loads(result.stdout)
    assert Path(output["python"]) == Path(sys.executable)
    assert Path(output["cwd"]) == root and output["args"] == argv[1:]
    assert list(root.rglob("*.py")) == [script]


if __name__ == "__main__":
    raise SystemExit(run(globals()))
