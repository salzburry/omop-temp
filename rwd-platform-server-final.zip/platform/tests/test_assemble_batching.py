"""No-Spark guards for the assembly projection; runtime parity remains a Spark check.

The recorder checks the exact expression tree and operation ordering. It does not
pretend to reproduce Spark's type inference, nullability or metadata propagation.
"""
from pathlib import Path
import sys
from types import ModuleType, SimpleNamespace

import pytest

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "platform"))
from engine.stages import assemble


class Expression:
    def __init__(self, operation, *values):
        self.tree = (operation, *[v.tree if isinstance(v, Expression) else v for v in values])

    def isNotNull(self):
        return Expression("is_not_null", self)

    def otherwise(self, value):
        return Expression("otherwise", self, value)


class Frame:
    """Record only the public frame operations assembly owns; never start a JVM."""
    def __init__(self, columns):
        self.columns = list(columns)
        self.operations = []
        self.added = None

    def join(self, other, keys, how):
        self.operations.append(("join", keys, how))
        return self

    def withColumns(self, added):
        assert self.added is None, "Metadata must require only one batch projection."
        self.added = {key: value.tree for key, value in added.items()}
        self.operations.append(("batch", tuple(added)))
        self.columns.extend(key for key in added if key not in self.columns)
        return self

    def distinct(self):
        self.operations.append(("distinct",))
        return self

    def select(self, *columns):
        self.operations.append(("select", columns))
        self.columns = list(columns)
        return self


@pytest.fixture
def spark_api(monkeypatch):
    sql = ModuleType("pyspark.sql")
    sql.functions = SimpleNamespace(lit=lambda value: Expression("literal", value),
        col=lambda name: Expression("column", name), when=lambda condition, value: Expression("when", condition, value))
    monkeypatch.setitem(sys.modules, "pyspark.sql", sql)


def cfg(*, publication=None, by_setting=False):
    status = {"treated_label": "Treated", "untreated_label": None, "treated_code": 2, "untreated_code": 1}
    if by_setting:
        status["by_setting"] = {"mhspc": {"treated_label": "Treated mHSPC", "untreated_label": "Untreated mHSPC",
            "treated_code": 4, "untreated_code": 3}}
    return SimpleNamespace(treatment_status=status, data_product_id="test_product", spec_version="202606",
        refresh="2026q1", raw={} if publication is None else {"publication": {"columns": publication}})


@pytest.mark.parametrize("cohort,cat,by_setting", [
    ({"label": "Overall", "cohortn": 1}, "lot1", False),
    ({"label": "Line two", "cohortn": 2, "lot_number": 2}, "lot2", False),
    ({"label": "Maintenance", "cohortn": 3, "lot_number": 2, "maintenance": True, "line_setting": "mHSPC"}, "lot2m", True),
])
def test_independent_projection_keeps_exact_literal_types_category_references_and_order(spark_api, cohort, cat, by_setting):
    columns = ["patientid", "index_date", "treat_flag", "cohort", "spec_version", cat + "cat", cat + "catn"]
    frame = Frame(columns)
    result = assemble.build(frame, frame, frame, frame, frame, cfg(by_setting=by_setting), cohort, frame)
    assert result is frame
    assert frame.operations[:5] == [("join", ["patientid", "index_date"], "left")] * 4 + [("join", "patientid", "left")]
    ordered = ["cohort", "cohortn", "cohortu", "cohortun", "data_product_id", "spec_version", "data_refresh", "lotcat", "lotcatn"]
    assert frame.operations[5:] == [("batch", tuple(ordered)), ("distinct",)]
    assert frame.columns == columns + [key for key in ordered if key not in columns]
    expected = {
        "cohort": ("literal", cohort["label"]), "cohortn": ("literal", cohort["cohortn"]),
        "data_product_id": ("literal", "test_product"), "spec_version": ("literal", "202606"),
        "data_refresh": ("literal", "2026q1"), "lotcat": ("column", cat + "cat"), "lotcatn": ("column", cat + "catn"),
    }
    tlabel, ulabel, tcode, ucode = ("Treated mHSPC", "Untreated mHSPC", 4, 3) if by_setting else ("Treated", None, 2, 1)
    for name, yes, no in (("cohortu", tlabel, ulabel), ("cohortun", tcode, ucode)):
        expected[name] = ("otherwise", ("when", ("is_not_null", ("column", "treat_flag")), ("literal", yes)), ("literal", no))
    assert frame.added == expected


def test_absent_category_keeps_it_absent_and_publication_projection_still_follows_distinct(spark_api):
    published = ["spec_version", "patientid", "index_date", "data_product_id", "data_refresh", "cohortn"]
    frame = Frame(["patientid", "index_date", "treat_flag"])
    assemble.build(frame, frame, frame, frame, frame, cfg(publication=published), {"label": "Overall", "cohortn": 1}, frame)
    assert "lotcat" not in frame.added and "lotcatn" not in frame.added
    assert frame.operations[-2:] == [("distinct",), ("select", tuple(published))]
    assert frame.columns == published


def test_invalid_publication_is_still_refused_after_assembly(spark_api):
    frame = Frame(["patientid", "index_date", "treat_flag"])
    with pytest.raises(ValueError, match="PUBLICATION WHITELIST REFUSED"):
        assemble.build(frame, frame, frame, frame, frame, cfg(publication=["cohortn", "phantom"]),
            {"label": "Overall", "cohortn": 1}, frame)
    assert frame.operations[-1] == ("distinct",)
