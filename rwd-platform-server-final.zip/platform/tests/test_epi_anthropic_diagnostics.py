"""Direct-provider failures use typed, secret-free diagnostics; no live API calls."""
from __future__ import annotations

import errno
import hashlib
import json
import os
from pathlib import Path
import shutil
import ssl
import sys
from types import SimpleNamespace

import pytest

ROOT = Path(__file__).resolve().parents[2]
sys.path[:0] = [str(ROOT / name) for name in ("platform/tests", "experiments/portal", "platform/tools", "experiments/agent")]
import scientific_definition_ai as ai
import flow_assistant as guide
from test_epi_flow_assistant import _card

PRIVATE = "SYNTHETIC-PRIVATE-PATH-AND-HEADER-DO-NOT-DISPLAY"


def windows_path_error(path=None):
    if os.name == "nt":
        import ctypes
        error = ctypes.WinError(206)
    else:
        error = OSError(errno.ENAMETOOLONG, PRIVATE)
        error.winerror = 206
    error.filename = str(path or PRIVATE)
    return error


@pytest.fixture(autouse=True)
def isolate(tmp_path, monkeypatch):
    monkeypatch.setattr(sys, "path", list(sys.path))
    monkeypatch.setenv("ANTHROPIC_API_KEY", "synthetic-test-key-never-sent")
    monkeypatch.delenv("RWD_AGENT_MODEL", raising=False)
    ai.set_provider_selection("anthropic")
    # A missing fake constructor must fail locally, never import a real client.
    monkeypatch.setitem(sys.modules, "orchestrator", SimpleNamespace(
        AnthropicModel=lambda **_kw: pytest.fail("No real provider constructor is permitted")))
    yield
    ai.set_provider_selection(None)
    if os.name == "nt":
        # Only this test's absolute pytest-owned directory. Normal Win32 paths
        # cannot clean up the deliberately overlong descendants on this host.
        owned = tmp_path.resolve()
        assert owned.is_absolute() and owned != owned.parent
        shutil.rmtree("\\\\?\\" + str(owned))


def deep_agent(tmp_path):
    folder = tmp_path
    while len(str(folder)) < 330:
        folder /= "nested-checkout-segment"
    folder /= "experiments/agent"
    if os.name == "nt":
        folder = Path("\\\\?\\" + str(folder.resolve()))
    folder.mkdir(parents=True)
    (folder / "models.yaml").write_bytes((ROOT / "experiments/agent/models.yaml").read_bytes())
    assert len(str(folder / "models.yaml")) > 260
    return folder


def test_deep_checkout_local_initialization_reads_actual_registry_and_closes_without_request(tmp_path, monkeypatch):
    folder = deep_agent(tmp_path)
    monkeypatch.setattr(ai, "AGENT", folder)
    calls = []

    class Client:
        def with_options(self, **kwargs):
            calls.append(("options", kwargs))
            return self

        def close(self):
            calls.append(("closed",))

    class Adapter:
        def __init__(self, **kwargs):
            calls.append(("constructor", kwargs))
            self.client = Client()

        def step(self, *_args):
            pytest.fail("A metadata check must not make a model request")

    monkeypatch.setitem(sys.modules, "orchestrator", SimpleNamespace(AnthropicModel=Adapter))
    environment_digest = lambda: hashlib.sha256(json.dumps(dict(os.environ), sort_keys=True).encode()).hexdigest()
    before = environment_digest()
    config = ai._provider(tmp_path, health=True)
    assert config["configured"] and not calls
    ai.check_direct_runtime(config)
    assert [call[0] for call in calls] == ["constructor", "options", "closed"]
    assert calls[1][1] == {"timeout": ai.TIMEOUT_SECONDS, "max_retries": 0}
    assert environment_digest() == before
    assert list(folder.iterdir()) == [folder / "models.yaml"]


@pytest.mark.parametrize("location", ["constructor", "client_options", "registry"])
def test_deep_checkout_winerror_206_names_recovery_without_showing_path(tmp_path, monkeypatch, location):
    folder = deep_agent(tmp_path)
    monkeypatch.setattr(ai, "AGENT", folder)
    failure = windows_path_error(folder / PRIVATE)
    expected_code = "provider_path"

    class Client:
        def with_options(self, **_kw):
            raise failure

    class Adapter:
        def __init__(self, **_kw):
            if location == "constructor":
                raise failure
            self.client = Client()

    monkeypatch.setitem(sys.modules, "orchestrator", SimpleNamespace(AnthropicModel=Adapter))
    if location == "registry":
        if os.name == "nt":
            # The file exists via extended syntax; use the real unprefixed OS
            # read if this host enforces MAX_PATH, otherwise inject the same
            # typed refusal so long-path-enabled Windows remains covered.
            plain = Path(str(folder).removeprefix("\\\\?\\"))
            try:
                (plain / "models.yaml").read_bytes()
            except OSError as error:
                assert getattr(error, "winerror", None) == 206 or isinstance(error, FileNotFoundError)
                expected_code = "provider_path" if getattr(error, "winerror", None) == 206 else "provider_path_access"
                monkeypatch.setattr(ai, "AGENT", plain)
                failure = None
        if failure is not None:
            read = Path.read_text
            def read_text(path, *args, **kwargs):
                if path == folder / "models.yaml":
                    raise failure
                return read(path, *args, **kwargs)
            monkeypatch.setattr(Path, "read_text", read_text)
    with pytest.raises(ai.Invalid) as caught:
        config = ai._provider(tmp_path)
        ai.check_direct_runtime(config)
    assert caught.value.code == expected_code
    assert ("path-length limit" if expected_code == "provider_path" else "long Windows path") in str(caught.value)
    assert "short local checkout" in str(caught.value)
    assert PRIVATE not in str(caught.value) and str(folder) not in str(caught.value)


@pytest.mark.parametrize("error,code", [
    (ModuleNotFoundError(PRIVATE), "provider_dependency"),
    (FileNotFoundError(PRIVATE), "provider_files"),
    (PermissionError(PRIVATE), "provider_files"),
    (ssl.SSLCertVerificationError(PRIVATE), "provider_tls"),
    (TimeoutError(PRIVATE), "timeout"),
    (ValueError(PRIVATE), "provider_runtime"),
    (SystemExit(PRIVATE), "provider_runtime"),
])
def test_initialization_failure_has_specific_safe_category_not_a_blanket_path_claim(monkeypatch, error, code):
    def constructor(**_kwargs):
        raise error
    monkeypatch.setitem(sys.modules, "orchestrator", SimpleNamespace(AnthropicModel=constructor))
    with pytest.raises(ai.Invalid) as caught:
        ai._make_model("scripted-model", {})
    assert caught.value.code == code
    assert PRIVATE not in str(caught.value) and "path-length" not in str(caught.value)


def test_wrapped_request_path_failure_reaches_chat_without_provider_body_or_prefill(monkeypatch):
    failure = type("APIConnectionError", (Exception,), {"__module__": "anthropic"})(PRIVATE)
    failure.__cause__ = windows_path_error()
    calls = []
    class Model:
        def step(self, *_args):
            calls.append(True)
            raise failure
    offline = {"answer": "Review the current product details.", "actions": [], "source": "checks",
               "prefill": {"fields": [{"id": "name", "value": "Do not apply on failure"}]}}
    monkeypatch.setattr(guide, "answer_offline", lambda *_args: dict(offline))
    result = guide.answer("What next?", _card(), model=Model())
    assert calls == [True] and result["answer"] == offline["answer"]
    assert "path-length limit" in result["note"] and result["source"] == "checks"
    assert "prefill" not in result and PRIVATE not in json.dumps(result)


@pytest.mark.parametrize("status,expected", [(401, "configured credential"), (403, "account/model permissions"),
                                            (404, "model access"), (429, "rate or usage limit")])
def test_chat_keeps_fixed_provider_access_diagnostic(status, expected):
    failure = RuntimeError(PRIVATE)
    failure.status_code = status
    class Model:
        def step(self, *_args):
            raise failure
    result = guide.answer("What next?", _card(), model=Model())
    assert result["source"] == "checks" and expected.lower() in result["note"].lower()
    assert PRIVATE not in json.dumps(result)


def test_error_words_and_a_cycle_do_not_invent_a_path_diagnosis():
    error = RuntimeError("WinError 206 timeout " + PRIVATE)
    error.__cause__ = error
    diagnosed = ai._provider_failure(error)
    assert diagnosed.code == "provider_error"
    assert PRIVATE not in str(diagnosed) and "path-length" not in str(diagnosed)


@pytest.mark.parametrize("name,code", [("APIConnectionError", "provider_network"), ("APITimeoutError", "timeout")])
def test_typed_sdk_transport_failure_keeps_a_safe_actionable_category(name, code):
    error = type(name, (Exception,), {"__module__": "anthropic"})(PRIVATE)
    class Model:
        def step(self, *_args):
            raise error
    with pytest.raises(ai.Invalid) as caught:
        ai._call(Model(), "synthetic context")
    assert caught.value.code == code
    assert PRIVATE not in str(caught.value)


def test_row_request_reports_operating_system_path_failure_without_saving(tmp_path):
    from test_epi_scientific_definition_ai import fixture, generate, Model, governed_bytes
    root, pack, product, values = fixture(tmp_path)
    before = governed_bytes(product)
    result = generate(root, pack, values, Model(windows_path_error()))
    assert not result["ok"] and "path-length limit" in result["errors"][0]
    assert PRIVATE not in json.dumps(result)
    assert governed_bytes(product) == before
    assert not list((product / ".portal-drafts").rglob("*.json"))
