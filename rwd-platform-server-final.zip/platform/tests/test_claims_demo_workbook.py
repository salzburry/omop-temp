"""The shipped claims example exercises the existing exporter, never an R runtime."""
import hashlib
from pathlib import Path
import sys

import yaml

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "platform/tools"))
import cohortly_export as export
import repo_hygiene


def test_shipped_claims_input_exports_bound_ungoverned_drafts_only_outside_checkout(tmp_path):
    folder = ROOT / "sandbox/demo_walkthrough"
    workbook = folder / "claims_202609_program_spec.xlsx"
    bindings = folder / "claims_demo_bindings.yaml"
    before = {path.name: hashlib.sha256(path.read_bytes()).hexdigest() for path in (workbook, bindings)}
    script, manifest = tmp_path / "draft.R", tmp_path / "manifest.yaml"
    assert export.main([str(workbook), "--bindings", str(bindings), "--out", str(script), "--manifest", str(manifest)]) == 0
    assert export.manifest_integrity_errors(manifest) == []
    value = yaml.safe_load(manifest.read_text("utf-8"))
    assert value["workbook_sha256"] == before[workbook.name]
    assert value["bindings_sha256"] == before[bindings.name]
    assert value["blocking_gaps"] == [] and len(value["criteria"]) == 3
    assert value["events"] == {"demonstration_index": {"dx_cd": {"tab": "synthetic_dx", "codes": ["DEMO.001"]}}}
    assert value["criteria"][0]["row"] == "studypoppage:Criterion 1 (INCLUSION)"
    assert value["criteria"][0]["call"]["args"]["event"] == "demonstration_index"
    assert value["governance"].startswith("UNGOVERNED")
    rendered = script.read_text("utf-8")
    assert "UNGOVERNED DRAFT" in rendered and "stop(" in rendered
    assert {path.name: hashlib.sha256(path.read_bytes()).hexdigest() for path in (workbook, bindings)} == before


def test_claims_demo_has_exact_reference_registration_without_production_exemption():
    workbook = "sandbox/demo_walkthrough/claims_202609_program_spec.xlsx"
    record = yaml.safe_load((ROOT / "sandbox/demo_walkthrough/claims/202609/source_refs.yaml").read_text("utf-8"))
    assert len(record["source_materials"]) == 1
    source = record["source_materials"][0]
    assert source["path_or_link"] == workbook and source["status"] == "reference_only"
    assert source["sha256"] == hashlib.sha256((ROOT / workbook).read_bytes()).hexdigest()
    assert not any(key in source for key in ("approved_by", "approval_date", "classified_by", "classified_date", "ai_classification"))
    assert workbook in repo_hygiene.registered_workbooks(str(ROOT))
    assert repo_hygiene.restricted_files(str(ROOT), [workbook]) == []
    assert workbook not in repo_hygiene.production_eligible_workbooks(str(ROOT))
    assert repo_hygiene.restricted_files(str(ROOT), [workbook], production=True)
    assert repo_hygiene.restricted_files(str(ROOT), ["sandbox/demo_walkthrough/unregistered.xlsx"])
