"""Persistent brief and exact short-answer regression tests, with no model calls."""
from __future__ import annotations

import copy
import json
import sys
from pathlib import Path

import pytest
from streamlit.testing.v1 import AppTest

ROOT = Path(__file__).resolve().parents[2]
sys.path[:0] = [str(ROOT / directory) for directory in ("platform/tests", "experiments/portal", "experiments/agent", "platform/tools")]
import conversation_intake as brief_api
import conversation_intake_page as page

PACK = "products/oncology/synthetic/202609"
OTHER = "products/oncology/other/202609"
ACTOR = "synthetic-scientist"


@pytest.fixture
def draft(tmp_path, monkeypatch):
    monkeypatch.delenv("RWDP_STATE_DIR", raising=False)
    (tmp_path / PACK).mkdir(parents=True)
    (tmp_path / OTHER).mkdir(parents=True)
    return tmp_path, brief_api.new(tmp_path, PACK, ACTOR, allowed_packs=[PACK, OTHER], connection="synthetic", source="v1")


def question(slot="population"):
    return {"id": slot, "prompt": "Which population matches the study?", "allow_text": True,
            "options": [{"id": "a", "label": "All adults with the condition", "explanation": "Broad inclusion."},
                        {"id": "b", "label": "Adults with documented advanced disease", "explanation": "Requires stage evidence."},
                        {"id": "c", "label": "Adults starting the specified treatment", "explanation": "Treatment defines eligibility."}]}


def ask(brief, q=None):
    return brief_api.apply_reply(brief, {"questions": [q or question()]}, user_text="Help define this product")


def save(root, brief, **kwargs):
    return brief_api.save(root, brief["state"]["pack"], ACTOR, brief, allowed_packs=[PACK, OTHER], can_write=True,
                          expected_revision=brief["revision"], **kwargs)


def load(root, pack=PACK, actor=ACTOR, **kwargs):
    return brief_api.load(root, pack, actor, allowed_packs=[PACK, OTHER], connection="synthetic", source="v1", **kwargs)


def test_same_intake_slots_and_private_draft_survive_restart_across_pages(draft, monkeypatch):
    root, brief = draft
    writes, reads = [], []
    original_save, original_load = brief_api.intake.save_request, brief_api.intake.load_requests
    monkeypatch.setattr(brief_api.intake, "save_request", lambda *args, **kwargs: writes.append(kwargs.get("status")) or original_save(*args, **kwargs))
    monkeypatch.setattr(brief_api.intake, "load_requests", lambda *args, **kwargs: reads.append(True) or original_load(*args, **kwargs))
    brief = brief_api.edit(brief, {"population": "Adults with NSCLC", "outcomes": "Overall survival"})
    saved = save(root, ask(brief))
    restored = load(root)
    assert restored["state"]["request"] == saved["state"]["request"]
    assert restored["pending_question"] == saved["pending_question"]
    assert writes == ["draft"] and reads
    assert len(restored["revision"]) == 64
    assert not list((root / PACK).rglob("*.*")), "Draft continuation must not modify a product record"


def test_actor_checkout_product_and_study_are_isolated(draft, tmp_path):
    root, brief = draft
    saved = save(root, brief_api.edit(brief, {"population": "Private descriptive intent"}))
    assert load(root, actor="another-scientist")["state"]["request"]["population"] is None
    assert load(root, pack=OTHER)["state"]["request"]["population"] is None
    assert load(root, pack=None)["state"]["request"]["population"] is None
    assert load(root, scope_id="study-two")["state"]["request"]["population"] is None
    another = tmp_path / "other-checkout"
    (another / PACK).mkdir(parents=True)
    assert load(another)["state"]["request"]["population"] is None
    with pytest.raises(ValueError, match="different checkout"):
        brief_api.save(root, PACK, ACTOR, saved, allowed_packs=[PACK], can_write=True, expected_revision=None, scope_id="study-two")


def test_productless_new_product_brief_does_not_follow_another_product(draft):
    root, _ = draft
    blank = load(root, pack=None)
    blank = save(root, brief_api.edit(blank, {"intended_use": "Create a lung product"}))
    assert load(root, pack=None)["state"]["request"]["intended_use"] == "Create a lung product"
    assert load(root)["state"]["request"]["intended_use"] is None


@pytest.mark.parametrize("reply,expected", [("1C", "Adults starting the specified treatment"),
    ("1b", "Adults with documented advanced disease"), ("A", "All adults with the condition"),
    ("2", "Adults with documented advanced disease"), ("1", "All adults with the condition"),
    ("Adults with documented advanced disease", "Adults with documented advanced disease")])
def test_short_mcq_answers_record_exact_choice_in_existing_slot(draft, reply, expected):
    _, brief = draft
    updated, expanded, matched = brief_api.resolve_reply(ask(brief), reply)
    assert matched and updated["state"]["request"]["population"] == expected
    assert expected in expanded and "Which population" in expanded
    assert updated["pending_question"] is None


@pytest.mark.parametrize("reply", ["1B", "B", "2", "admin_cutoff", "id:admin_cutoff"])
def test_semantic_option_ids_accept_the_displayed_short_choice(draft, reply):
    _, brief = draft
    q = question("follow_up")
    for option, identifier in zip(q["options"], ("last_activity", "admin_cutoff", "death_as_censor")):
        option["id"] = identifier
    updated, expanded, matched = brief_api.resolve_reply(ask(brief, q), reply)
    assert matched and updated["state"]["request"]["follow_up"] == q["options"][1]["label"]
    assert q["options"][1]["label"] in expanded


def test_reordered_letter_ids_do_not_override_displayed_position(draft):
    _, brief = draft
    q = question()
    q["options"][0]["id"], q["options"][1]["id"] = "b", "a"
    pending = ask(brief, q)
    second, _, _ = brief_api.resolve_reply(pending, "b")
    first, _, _ = brief_api.resolve_reply(pending, "id:b")
    assert second["state"]["request"]["population"] == q["options"][1]["label"]
    assert first["state"]["request"]["population"] == q["options"][0]["label"]
    for text in ("1D", "4", "Z"):
        unchanged, _, matched = brief_api.resolve_reply(pending, text)
        assert not matched and unchanged["state"]["request"]["population"] is None
        with pytest.raises(ValueError, match="not shown"):
            brief_api.resolve_reply(pending, text, question_token=pending["pending_question"]["token"])


@pytest.mark.parametrize("reply", ["2C", "1Z", "4", "b and c", "I might choose b", "approve all"])
def test_ambiguous_and_unoffered_short_choices_do_not_fill_a_slot(draft, reply):
    _, brief = draft
    updated, text, matched = brief_api.resolve_reply(ask(brief), reply)
    assert not matched and updated["state"]["request"]["population"] is None
    assert text == reply


def test_not_sure_keeps_existing_meaning_and_question_open(draft):
    _, brief = draft
    brief = ask(brief_api.edit(brief, {"population": "Original descriptive population"}))
    updated, expanded, matched = brief_api.resolve_reply(brief, "Not sure")
    assert matched and updated["state"]["request"]["population"] == "Original descriptive population"
    assert updated["unknown_slots"] == ["population"] and updated["pending_question"] == brief["pending_question"]
    assert "Keep this unresolved" in expanded
    restated = brief_api.apply_reply(updated, {"brief_updates": [{"slot": "population", "value": "Not sure", "quote": "Not sure"}]}, user_text="Not sure")
    assert restated["pending_question"] == updated["pending_question"]
    assert restated["state"]["request"]["population"] == "Original descriptive population"


def test_existing_intake_clear_command_removes_selected_field_without_other_loss(draft):
    _, brief = draft
    brief = brief_api.edit(brief, {"population": "NSCLC adults", "outcomes": "Overall survival"})
    changed, message, matched = brief_api.resolve_reply(brief, "clear population")
    assert matched and changed["state"]["request"]["population"] is None
    assert changed["state"]["request"]["outcomes"] == "Overall survival"
    assert changed["state"]["cleared"] == ["population"] and "cleared population" in message


def test_first_source_description_retains_same_turn_proposals_for_review(draft):
    _, brief = draft
    changed = brief_api.apply_reply(brief, {"brief_updates": [
        {"slot": "source_cut", "value": "claims", "quote": "claims"},
        {"slot": "intended_use", "value": "Compare treatment patterns", "quote": "treatment patterns"}]}, user_text="Create a claims product for treatment patterns")
    assert changed["state"]["request"]["source_cut"] == "claims"
    assert changed["proposed_updates"][0]["slot"] == "intended_use"


def test_typed_alternative_is_explicit_only_when_bound_to_exact_question(draft):
    _, brief = draft
    brief = ask(brief)
    typed = "Adults receiving their first documented treatment"
    unchanged, _, matched = brief_api.resolve_reply(brief, typed)
    assert not matched and unchanged["state"]["request"]["population"] is None
    updated, _, matched = brief_api.resolve_reply(brief, typed, question_token=brief["pending_question"]["token"])
    assert matched and updated["state"]["request"]["population"] == typed
    with pytest.raises(ValueError, match="question changed"):
        brief_api.resolve_reply(brief, "1B", question_token="old-question")


def test_literal_user_text_saved_but_model_inference_requires_inspection(draft):
    _, brief = draft
    reply = {"brief_updates": [
        {"slot": "population", "value": "adults with NSCLC", "quote": "adults with NSCLC"},
        {"slot": "index_definition", "value": "First treatment with a 12-month clean period", "quote": "starting therapy"}]}
    result = brief_api.apply_reply(brief, reply, user_text="Study adults with NSCLC starting therapy")
    assert result["state"]["request"]["population"] == "adults with NSCLC"
    assert result["state"]["request"]["index_definition"] is None
    assert result["proposed_updates"][0]["slot"] == "index_definition"
    accepted = brief_api.accept_updates(result, ["index_definition"])
    assert accepted["state"]["request"]["index_definition"].startswith("First treatment")
    assert accepted["proposed_updates"] == []


def test_fabricated_quote_and_changed_meaning_never_silently_replace_manual_brief(draft):
    _, brief = draft
    brief = brief_api.edit(brief, {"outcomes": "Overall survival"})
    result = brief_api.apply_reply(brief, {"brief_updates": [{"slot": "outcomes", "value": "Progression-free survival", "quote": "Progression-free survival"}]}, user_text="Tell me more")
    assert result["state"]["request"]["outcomes"] == "Overall survival"
    assert result["proposed_updates"][0]["quote"] == ""
    assert result["proposed_updates"][0]["before"] == "Overall survival"


def _brief_form():
    return {"scope": "current-visible-form", "fields": [
        {"id": "cohort", "label": "Population", "type": "text_area", "current": "Original population"},
        {"id": "purpose", "label": "What should this product help you study?", "type": "text_area", "current": "Original purpose"},
        {"id": "population", "label": "Scientific interpretation", "type": "text_area", "current": "Row-specific wording"}]}


def test_prefill_only_exact_population_updates_same_brief_and_preserves_other_manual_fields(draft):
    _, brief = draft
    brief = brief_api.edit(brief, {"population": "Original population", "outcomes": "Keep manual outcome"})
    public = _brief_form()
    parsed = {"prefill": {"scope": public["scope"], "fields": [
        {"id": "cohort", "value": "Adults with NSCLC"}, {"id": "purpose", "value": "Treatment patterns"}]}}
    updated = brief_api.apply_reply(brief, parsed, user_text="Use Adults with NSCLC for Treatment patterns", public_form=public)
    assert updated["state"]["request"]["population"] == "Adults with NSCLC"
    assert updated["state"]["request"]["intended_use"] == "Treatment patterns"
    assert updated["state"]["request"]["outcomes"] == "Keep manual outcome"
    assert updated["proposed_updates"] == []


def test_prefill_inferred_population_stays_review_proposal(draft):
    _, brief = draft
    brief = brief_api.edit(brief, {"population": "Original population"})
    public = _brief_form()
    parsed = {"prefill": {"scope": public["scope"], "fields": [{"id": "cohort", "value": "Adults with advanced NSCLC"}]}}
    updated = brief_api.apply_reply(brief, parsed, user_text="Can you narrow it to advanced disease?", public_form=public)
    assert updated["state"]["request"]["population"] == "Original population"
    assert updated["proposed_updates"] == [{"slot": "population", "value": "Adults with advanced NSCLC", "quote": "", "before": "Original population"}]


def test_prefill_reuses_offered_labels_not_arbitrary_row_ids_or_definitions(draft):
    _, brief = draft
    public = _brief_form()
    parsed = {"prefill": {"scope": public["scope"], "fields": [{"id": "population", "value": "A row-specific interpretation"}]}}
    updated = brief_api.apply_reply(brief, parsed, user_text="A row-specific interpretation", public_form=public)
    assert updated["state"]["request"]["population"] is None and updated["proposed_updates"] == []


def test_brief_detail_intended_use_label_uses_the_shared_alias(draft):
    _, brief = draft
    public = {"scope": "detail-form", "fields": [{"id": "purpose", "label": "Intended use", "type": "text_area", "current": "Original purpose"}]}
    parsed = {"prefill": {"scope": public["scope"], "fields": [{"id": "purpose", "value": "Treatment patterns"}]}}
    updated = brief_api.apply_reply(brief, parsed, user_text="Treatment patterns", public_form=public)
    assert updated["state"]["request"]["intended_use"] == "Treatment patterns"


@pytest.mark.parametrize("latest_question,focus,counterpart", [
    ("First ask one inclusion-sequence question with options.", "inclusion_sequence", "index_definition"),
    ("Ask a question about inclusion_sequence.", "inclusion_sequence", "index_definition"),
    ("Please ask one follow-up question with MCQs.", "follow_up", "outcomes"),
    ("A question for the follow up, please.", "follow_up", "outcomes"),
    ("Give me an index-definition question.", "index_definition", "inclusion_sequence"),
    ("Ask about outcomes.", "outcomes", "follow_up")])
def test_prompt_names_requested_slot_and_uses_whole_canonical_meanings(latest_question, focus, counterpart):
    text = brief_api.prompt_instructions(latest_question)
    assert "Requested question field: " + focus in text
    assert "questions[0].id MUST be " + focus in text
    assert focus + ": " + brief_api.slots()[focus]["ask"] in text
    assert counterpart + ": " + brief_api.slots()[counterpart]["ask"] in text
    assert len(text.encode("utf-8")) <= 1400


@pytest.mark.parametrize("latest_question", [None, "1B", "Not sure", "What should I do next?",
    "The previous brief mentioned outcomes. Where is its saved version?",
    "Ask an outcomes question and a follow-up question.", "Do not ask a follow-up question."])
def test_prompt_does_not_force_a_slot_for_generic_ambiguous_or_incidental_context(latest_question):
    text = brief_api.prompt_instructions(latest_question)
    assert "Requested question field:" not in text
    assert len(text.encode("utf-8")) <= 1400


def test_prompt_focus_does_not_read_saved_brief_and_does_not_rebind_model_questions(draft):
    _, brief = draft
    saved_wording = brief_api.edit(brief, {"outcomes": "A distinctive saved outcome question"})
    text = brief_api.prompt_instructions("1B")
    assert saved_wording["state"]["request"]["outcomes"] not in text
    assert "Requested question field:" not in text
    result = brief_api.apply_reply(brief, {"questions": [question("outcomes")]}, user_text="Ask a follow-up question")
    assert result["pending_question"]["id"] == "outcomes", "Guidance must not silently rebind model output"


def test_prompt_guidance_is_bounded_for_each_existing_named_slot():
    for sid, slot in brief_api.slots().items():
        text = brief_api.prompt_instructions("Ask a " + sid.replace("_", "-") + " question.")
        assert "Requested question field: " + sid in text
        assert slot["ask"] in text
        assert len(text.encode("utf-8")) <= 1400


@pytest.mark.parametrize("failure", ["missing_form", "stale_scope", "unoffered_field", "invalid_text", "mapped_number", "conflicting_brief", "conflicting_alias"])
def test_prefill_brief_adapter_refuses_unsupported_or_conflicting_changes(draft, failure):
    _, brief = draft
    public = _brief_form()
    parsed = {"prefill": {"scope": public["scope"], "fields": [{"id": "cohort", "value": "New population"}]}}
    if failure == "missing_form":
        public = None
    elif failure == "stale_scope":
        public["scope"] = "changed-current-form"
    elif failure == "unoffered_field":
        parsed["prefill"]["fields"][0]["id"] = "unoffered"
    elif failure == "invalid_text":
        parsed["prefill"]["fields"][0]["value"] = ["New population"]
    elif failure == "mapped_number":
        public["fields"][0]["type"] = "number_input"
        public["fields"][0]["current"] = 1
        parsed["prefill"]["fields"][0]["value"] = 2
    elif failure == "conflicting_brief":
        parsed["brief_updates"] = [{"slot": "population", "value": "Different population", "quote": "Different population"}]
    else:
        public["fields"].append({"id": "other_cohort", "label": "Population", "type": "text_area", "current": ""})
        parsed["prefill"]["fields"].append({"id": "other_cohort", "value": "Different population"})
    before = copy.deepcopy(brief)
    with pytest.raises(ValueError):
        brief_api.apply_reply(brief, parsed, user_text="New population and Different population", public_form=public)
    assert brief == before


@pytest.mark.parametrize("mutation", ["unknown_slot", "duplicates", "too_many_questions", "invalid_question", "sensitive"])
def test_malformed_or_unsafe_model_brief_payload_rejected(draft, mutation):
    _, brief = draft
    updates, questions = [{"slot": "population", "value": "Adults", "quote": "Adults"}], [question()]
    if mutation == "unknown_slot":
        updates[0]["slot"] = "approval_status"
    elif mutation == "duplicates":
        updates *= 2
    elif mutation == "too_many_questions":
        questions.append(question("outcomes"))
    elif mutation == "invalid_question":
        questions[0]["id"] = "approve"
    else:
        updates[0]["value"] = "patient_id: 12345678"
    with pytest.raises(ValueError):
        brief_api.apply_reply(brief, {"brief_updates": updates, "questions": questions}, user_text="Adults")


def test_context_change_invalidates_choices_preserving_user_draft(draft):
    root, brief = draft
    saved = save(root, ask(brief_api.edit(brief, {"population": "NSCLC adults"})))
    updated = brief_api.load(root, PACK, ACTOR, allowed_packs=[PACK, OTHER], connection="changed", source="v2")
    assert updated["pending_question"] is None and updated["proposed_updates"] == []
    assert updated["state"]["request"]["population"] == "NSCLC adults"
    assert updated["revision"] == saved["revision"]
    with pytest.raises(ValueError, match="question changed"):
        brief_api.resolve_reply(updated, "1B", question_token=saved["pending_question"]["token"])
    with pytest.raises(ValueError, match="outside your access"):
        brief_api.load(root, PACK, ACTOR, allowed_packs=[OTHER])


def test_new_source_invalidates_old_proposals_without_deleting_scientific_intent(draft):
    _, brief = draft
    brief = brief_api.edit(brief, {"source_cut": "EHR delivery A", "outcomes": "Overall survival"})
    brief = ask(brief)
    brief = brief_api.apply_reply(brief, {"brief_updates": [{"slot": "index_definition", "value": "First EHR record", "quote": ""}]}, user_text="Help with indexing")
    changed = brief_api.edit(brief, {"source_cut": "Claims delivery B"})
    assert changed["proposed_updates"] == [] and changed["pending_question"] is None
    assert changed["state"]["request"]["outcomes"] == "Overall survival"
    assert "source description changed" in changed["notice"]


def test_case_ambiguous_choices_and_private_snapshot_permissions(draft):
    root, brief = draft
    ambiguous = question()
    ambiguous["options"][1]["id"] = "A"
    with pytest.raises(ValueError, match="letter case"):
        ask(brief, ambiguous)
    with pytest.raises(ValueError, match="editing access"):
        brief_api.save(root, PACK, ACTOR, brief, allowed_packs=[PACK], can_write=False)
    _, directory = brief_api._scope(root, PACK, ACTOR, [PACK])
    assert not directory.exists()


def test_compare_and_swap_rejects_two_writers_and_clear_survives_restart(draft):
    root, brief = draft
    saved = save(root, brief_api.edit(brief, {"population": "NSCLC adults"}))
    stale = copy.deepcopy(saved)
    saved = save(root, brief_api.edit(saved, {"outcomes": "Overall survival"}))
    with pytest.raises(ValueError, match="another session"):
        save(root, brief_api.edit(stale, {"source_cut": "Alternative source"}))
    assert load(root)["state"]["request"]["source_cut"] is None
    saved = save(root, brief_api.clear(saved))
    assert all(value is None for value in load(root)["state"]["request"].values())


def test_invalid_snapshot_and_pointer_cannot_be_loaded_or_escape(draft):
    root, brief = draft
    save(root, brief_api.edit(brief, {"population": "NSCLC adults"}))
    _, directory = brief_api._scope(root, PACK, ACTOR, [PACK, OTHER])
    head = directory / "current.json"
    obj = json.loads(head.read_text())
    (directory / obj["file"]).write_text("malformed: yes")
    with pytest.raises(ValueError, match="changed outside"):
        load(root)
    head.write_text(json.dumps({"file": "../../outside.yaml", "revision": "f" * 64}))
    with pytest.raises(ValueError, match="version is unreadable"):
        load(root)


def test_context_is_bounded_whole_values_and_retains_current_question_token(draft):
    _, brief = draft
    brief = brief_api.edit(brief, {"population": "P" * 1600, "outcomes": "Overall survival"})
    context = brief_api.model_context(brief, max_bytes=768)
    assert len(json.dumps(context, ensure_ascii=False).encode()) <= 768
    assert "population" in context["omitted_slots"] and "population" not in context["request"]
    assert context["active_question"] is None, "An undisplayed template question is not conversation history"
    pending = brief_api.model_context(ask(brief), max_bytes=1600)
    assert pending["active_question"]["token"] == ask(brief)["pending_question"]["token"]
    assert "Overall survival" in brief_api.retrieval_context(brief)


def test_stale_unbound_mcq_never_answers_undisplayed_template_question(draft):
    root, brief = draft
    saved = save(root, ask(brief))
    stale = brief_api.load(root, PACK, ACTOR, allowed_packs=[PACK, OTHER], connection="new-model", source="changed-source")
    assert stale["pending_question"] is None
    for text in ("1B", "2", "b"):
        with pytest.raises(ValueError, match="no current displayed"):
            brief_api.resolve_reply(stale, text)
    assert stale["state"]["request"] == saved["state"]["request"]
    unchanged, _, matched = brief_api.resolve_reply(stale, "Not sure")
    assert not matched and unchanged["state"]["request"] == saved["state"]["request"]
    template = brief_api.current_question(stale)
    changed, _, matched = brief_api.resolve_reply(stale, "My typed intended use", question_token=template["token"])
    assert matched and changed["state"]["request"]["intended_use"] == "My typed intended use"


def test_reissued_question_is_new_even_after_source_changes_back(draft):
    _, brief = draft
    original = ask(brief_api.edit(brief, {"source_cut": "Source A"}))
    changed = ask(brief_api.edit(original, {"source_cut": "Source B"}))
    returned = ask(brief_api.edit(changed, {"source_cut": "Source A"}))
    assert len({value["pending_question"]["token"] for value in (original, changed, returned)}) == 3
    with pytest.raises(ValueError, match="question changed"):
        brief_api.resolve_reply(returned, "1B", question_token=original["pending_question"]["token"])


def _app(root, initial, *, can_write=True):
    def app():
        import streamlit as st
        import conversation_intake as backend
        import conversation_intake_page as ui
        root, initial, can_write = st.session_state["test_setup"]
        PACK, OTHER, ACTOR = st.session_state["test_scope"]
        value = backend.load(root, initial["state"]["pack"], initial["state"]["actor"],
            allowed_packs=[PACK, OTHER], connection="synthetic", source="v1")
        result = ui.render(root, PACK, ACTOR, value, allowed_packs=[PACK, OTHER], can_write=can_write)
        st.session_state["result"] = result
        st.text_area("Existing unsaved product field", key="untouched")
    save(root, initial)
    at = AppTest.from_function(app, default_timeout=15)
    at.session_state["test_setup"] = (str(root), initial, can_write)
    at.session_state["test_scope"] = (PACK, OTHER, ACTOR)
    at.session_state["untouched"] = "Manual product wording"
    return at.run()


def test_streamlit_one_mcq_text_alternative_no_default_and_draft_survives(draft):
    root, brief = draft
    at = _app(root, ask(brief))
    assert not at.exception
    assert len(at.radio) == 1 and at.radio[0].value is None
    at.radio[0].set_value("b").run()
    next(button for button in at.button if button.label == "Send this answer").click().run()
    result = at.session_state["result"]
    assert result["reply"] == "b" and result["question_token"] == brief_api.current_question(brief_api.load(root, PACK, ACTOR, allowed_packs=[PACK, OTHER], connection="synthetic", source="v1"))["token"]
    assert at.session_state["untouched"] == "Manual product wording"
    assert load(root)["state"]["request"]["population"] is None, "The renderer returns a reply; it does not invoke a model or save a choice"


def test_streamlit_inspect_edit_clear_and_readonly_controls(draft):
    root, brief = draft
    at = _app(root, brief)
    at.selectbox[0].set_value("population").run()
    next(field for field in at.text_area if field.label == "Population").set_value("Adults with NSCLC").run()
    next(button for button in at.button if button.label == "Save brief detail").click().run()
    assert not at.exception and load(root)["state"]["request"]["population"] == "Adults with NSCLC"
    at.run()
    next(button for button in at.button if button.label == "Clear this study brief").click().run()
    assert not at.exception and load(root)["state"]["request"]["population"] is None
    at.session_state["test_setup"] = (str(root), brief, False)
    at.run()
    assert all(button.disabled for button in at.button)


def test_streamlit_typed_alternative_replaces_selected_choice(draft):
    root, brief = draft
    at = _app(root, ask(brief))
    at.radio[0].set_value("b").run()
    next(field for field in at.text_area if field.label == "Your answer or another option").set_value("My exact intended population").run()
    next(button for button in at.button if button.label == "Send this answer").click().run()
    assert at.session_state["result"]["reply"] == "My exact intended population"


def test_streamlit_shows_letters_and_submits_position_for_reordered_ids(draft):
    root, brief = draft
    q = question()
    q["options"][0]["id"], q["options"][1]["id"] = "b", "a"
    pending = ask(brief, q)
    at = _app(root, pending)
    assert not at.exception
    assert at.radio[0].options[:2] == ["A · " + q["options"][0]["label"], "B · " + q["options"][1]["label"]]
    at.radio[0].set_value("b").run()
    next(button for button in at.button if button.label == "Send this answer").click().run()
    result = at.session_state["result"]
    assert result["reply"] == "a"
    updated, _, matched = brief_api.resolve_reply(pending, result["reply"], question_token=result["question_token"])
    assert matched and updated["state"]["request"]["population"] == q["options"][0]["label"]


def test_streamlit_model_inference_needs_explicit_selection_and_save(draft):
    root, brief = draft
    brief = brief_api.apply_reply(brief, {"brief_updates": [{"slot": "index_definition", "value": "First qualifying treatment", "quote": ""}]}, user_text="Help define index")
    at = _app(root, brief)
    assert not at.exception and load(root)["state"]["request"]["index_definition"] is None
    at.multiselect[0].set_value(["index_definition"]).run()
    next(button for button in at.button if button.label == "Use selected wording in brief").click().run()
    assert not at.exception and load(root)["state"]["request"]["index_definition"] == "First qualifying treatment"


def _setup_handoff(root, *, target_values=None):
    source = load(root, pack=None)
    source = brief_api.edit(source, {"population": "Adults with NSCLC", "outcomes": "Overall survival", "requested_by": "An unverified label"})
    source = ask(source, question("index_definition"))
    source = brief_api.apply_reply(source, {"brief_updates": [{"slot": "baseline_lookback", "value": "12 months", "quote": ""}]}, user_text="Help with baseline")
    source["unknown_slots"] = ["outcomes"]
    source = save(root, source)
    if target_values:
        save(root, brief_api.edit(load(root), target_values))
    state = {}
    page.registration_completed(root, PACK, ACTOR, allowed_packs=[PACK, OTHER], state=state)
    return state[page.HANDOFF_KEY]


def test_registration_handoff_uses_reviewed_source_and_exact_target_revision(draft):
    root, _ = draft
    token = _setup_handoff(root, target_values={"population": "Previous target wording", "follow_up": "Preserve manual follow-up"})
    review = brief_api.review_handoff(root, PACK, ACTOR, token, allowed_packs=[PACK, OTHER])
    assert review["values"] == {"population": "Adults with NSCLC"}
    assert review["changes"] == [{"slot": "population", "before": "Previous target wording", "value": "Adults with NSCLC"}]
    assert load(root)["state"]["request"]["population"] == "Previous target wording"
    result = brief_api.apply_handoff(root, PACK, ACTOR, token, allowed_packs=[PACK, OTHER], can_write=True, expected_digest=review["digest"])
    assert result["state"]["request"]["population"] == "Adults with NSCLC"
    assert result["state"]["request"]["follow_up"] == "Preserve manual follow-up"
    assert result["state"]["request"]["outcomes"] is None and result["state"]["request"]["requested_by"] is None
    assert result["pending_question"] is None and result["proposed_updates"] == []
    assert load(root, pack=None)["proposed_updates"], "Source draft and unresolved questions remain inspectable"


@pytest.mark.parametrize("changed", ["source", "target", "actor", "pack", "access", "comparison"])
def test_registration_handoff_refuses_changed_scope_or_either_stale_brief(draft, changed):
    root, _ = draft
    token = _setup_handoff(root)
    review = brief_api.review_handoff(root, PACK, ACTOR, token, allowed_packs=[PACK, OTHER])
    kwargs = {"actor_id": ACTOR, "target_pack": PACK, "allowed_packs": [PACK, OTHER], "can_write": True, "expected_digest": review["digest"]}
    if changed == "source":
        save(root, brief_api.edit(load(root, pack=None), {"population": "Changed setup wording"}))
    elif changed == "target":
        save(root, brief_api.edit(load(root), {"population": "New target wording"}))
    elif changed == "actor":
        kwargs["actor_id"] = "another-scientist"
    elif changed == "pack":
        kwargs["target_pack"] = OTHER
    elif changed == "access":
        kwargs["allowed_packs"] = [OTHER]
    else:
        kwargs["expected_digest"] = "old-comparison"
    with pytest.raises(ValueError):
        brief_api.apply_handoff(root, token=token, **kwargs)
    assert load(root)["state"]["request"]["population"] != "Adults with NSCLC"


def _handoff_app(root, token, *, actor=ACTOR, pack=PACK):
    def app():
        import streamlit as st
        import conversation_intake_page as ui
        root, actor, pack, allowed = st.session_state["test_scope"]
        ui.render_registration_handoff(root, pack, actor, allowed_packs=allowed, can_write=True)
        st.text_area("Existing product form", key="manual_form")
    at = AppTest.from_function(app, default_timeout=15)
    at.session_state["test_scope"] = (str(root), actor, pack, [PACK, OTHER])
    at.session_state[page.HANDOFF_KEY] = token
    at.session_state["manual_form"] = "Do not replace this field"
    return at.run()


def test_streamlit_registration_continuation_is_explicit_and_returns_to_flow(draft):
    root, _ = draft
    token = _setup_handoff(root)
    at = _handoff_app(root, token)
    assert not at.exception and len(at.dataframe) == 1
    assert load(root)["state"]["request"]["population"] is None
    next(button for button in at.button if button.label == "Continue with this study brief").click().run()
    assert not at.exception and load(root)["state"]["request"]["population"] == "Adults with NSCLC"
    assert at.session_state["pack_suggested"] == PACK and at.session_state["section_suggested"] == "Flow"
    assert at.session_state["manual_form"] == "Do not replace this field"
    assert page.HANDOFF_KEY not in at.session_state


def test_streamlit_handoff_not_exposed_to_other_actor_or_existing_product(draft):
    root, _ = draft
    token = _setup_handoff(root)
    for kwargs in ({"actor": "another-scientist"}, {"pack": OTHER}):
        at = _handoff_app(root, token, **kwargs)
        assert not at.exception and not at.dataframe and not at.button


def test_streamlit_stale_handoff_can_request_a_fresh_review_without_copying(draft):
    root, _ = draft
    token = _setup_handoff(root)
    save(root, brief_api.edit(load(root, pack=None), {"population": "Changed current population"}))
    at = _handoff_app(root, token)
    assert not at.exception and at.warning and not at.dataframe
    next(button for button in at.button if button.label == "Review the latest brief comparison").click().run()
    assert not at.exception and at.dataframe
    assert load(root)["state"]["request"]["population"] is None


def test_actual_registration_success_captures_exact_created_product_for_continuation(monkeypatch):
    from unittest.mock import patch
    from test_epi_portal_journeys import _portal, _new, _fill_new, _product_command, _healthy
    catalogue = {"products": [], "references": [], "superseded": [], "templates": [], "names": {}, "drafts": set()}
    created = "products/oncology/renal_epi/202609"
    captured = []
    monkeypatch.setattr(page, "registration_completed", lambda root, target, actor, **kwargs: captured.append((target, actor, kwargs["allowed_packs"])))
    with _portal(catalogue=catalogue) as at:
        _new(at)
        _fill_new(at)
        with _product_command((0, "PLAN preview passed")):
            at.button(key="np_preview").click().run()
        with _product_command((0, f"WROTE 1 file(s):\n  {created}/source_refs.yaml\n")), patch("branch_workspace.record_created_files", return_value={}):
            at.button(key="np_write").click().run()
        _healthy(at)
        assert captured == [(created, "Priya", [created])]
