"""Offline connection probes: bounded fake CLI startup, pipes and diagnostics."""
from pathlib import Path
import json
import sys
import threading
import time

import pytest

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "platform/tests"))
from test_epi_scientific_definition_claude_code import (
    cli, REAL_POPEN, connection, forbid_installed_process,
)


def test_successful_cli_output_gets_remaining_budget_to_drain(tmp_path, monkeypatch):
    script = tmp_path / "fake_status.py"
    script.write_text("print('local-metadata-complete', flush=True)\n", encoding="utf-8")
    processes = []

    class DelayedReader:
        def __init__(self, stream):
            self.stream = stream
            self.first = True

        def read1(self, count):
            if self.first:
                self.first = False
                # Simulate a pipe reader scheduled late on a busy laptop. The
                # command and its complete response are already successful.
                time.sleep(0.7)
            return self.stream.read1(count)

        def close(self):
            self.stream.close()

    def spawn(*args, **kwargs):
        process = REAL_POPEN(*args, **kwargs)
        process.stdout = DelayedReader(process.stdout)
        processes.append(process)
        return process

    monkeypatch.setattr(cli.subprocess, "Popen", spawn)
    before = {thread.ident for thread in threading.enumerate()}
    start = time.monotonic()
    code, raw = cli._run(Path(sys.executable), [str(script)], timeout=4)
    assert code == 0 and raw.strip() == b"local-metadata-complete"
    assert time.monotonic() - start < 4
    assert all(process.poll() is not None for process in processes)
    assert not [thread for thread in threading.enumerate() if thread.ident not in before]


@pytest.mark.parametrize("route", ["direct", "provider"])
@pytest.mark.parametrize("health", [False, True])
def test_new_connection_checks_metadata_once_without_generating(connection, monkeypatch, route, health):
    root, _exe, fake = connection
    if route == "direct":
        config = cli.describe_connection(root, local_demo=True, health=health)
    else:
        import scientific_definition_ai as ai
        monkeypatch.setenv("RWD_PORTAL_LOCAL_DEMO", "1")
        monkeypatch.setattr(ai, "selected_provider", lambda: "claude_code")
        config = ai._provider(root, health=health)
    assert config["configured"] and config["provider_id"] == "claude_code"
    assert [args for _exe, args, _kwargs in fake.calls] == [["--version"], ["auth", "status", "--json"]]
    shown = json.dumps({key: value for key, value in config.items() if key != "instance"})
    assert fake.status["email"] not in shown and fake.status["orgId"] not in shown


@pytest.mark.parametrize("phase,expected", [("--version", "cli_version_timeout"), ("auth", "auth_status_timeout")])
def test_probe_timeout_identifies_failed_metadata_phase_without_private_output(connection, monkeypatch, phase, expected):
    import scientific_definition_ai as ai
    root, _exe, fake = connection
    calls = []

    def run(executable, args, **kwargs):
        calls.append(args)
        if args[0] == phase:
            raise cli.ClaudeCodeError("timeout") from RuntimeError("PRIVATE-CLI-STDERR-SENTINEL")
        return fake(executable, args, **kwargs)

    monkeypatch.setattr(cli, "_run", run)
    monkeypatch.setenv("RWD_PORTAL_LOCAL_DEMO", "1")
    monkeypatch.setattr(ai, "selected_provider", lambda: "claude_code")
    with pytest.raises(ai.Invalid) as error:
        ai._provider(root, health=True)
    assert error.value.code == expected
    assert str(error.value) == cli.ERRORS[expected]
    assert "PRIVATE-CLI-STDERR-SENTINEL" not in str(error.value)
    assert calls == ([["--version"]] if phase == "--version" else [["--version"], ["auth", "status", "--json"]])


@pytest.mark.parametrize("raw", [b"not JSON", b"{}", b'{"loggedIn":1}', b'{"loggedIn":true,"loggedIn":false}'])
def test_unreadable_metadata_does_not_assert_the_user_is_logged_out(connection, monkeypatch, raw):
    root, _exe, fake = connection
    monkeypatch.setattr(cli, "_run", lambda executable, args, **kwargs:
                        (0, raw) if args[0] == "auth" else fake(executable, args, **kwargs))
    with pytest.raises(cli.ClaudeCodeError) as error:
        cli.describe_connection(root, local_demo=True)
    assert error.value.code == "auth_status_unreadable"


def test_explicit_logged_out_metadata_still_has_sign_in_action(connection):
    root, _exe, fake = connection
    fake.status = {"loggedIn": False}
    with pytest.raises(cli.ClaudeCodeError) as error:
        cli.describe_connection(root, local_demo=True)
    assert error.value.code == "not_signed_in" and "claude auth login" in str(error.value)


def test_existing_connection_still_rechecks_account_without_generating(connection):
    root, _exe, fake = connection
    instance = cli.describe_connection(root, local_demo=True)["instance"]
    fake.status["orgId"] = "another-synthetic-organization"
    with pytest.raises(cli.ClaudeCodeError) as error:
        instance.health()
    assert error.value.code == "connection_changed"
    assert [args for _exe, args, _kwargs in fake.calls] == [["--version"], ["auth", "status", "--json"], ["auth", "status", "--json"]]
