"""Bounded canonical history, content-based reads and atomic local admission."""
from concurrent.futures import ThreadPoolExecutor
import copy
import os
from pathlib import Path
import shutil
import sys
import threading

import pytest
import yaml

ROOT = Path(__file__).resolve().parents[2]
sys.path[:0] = [str(ROOT / "platform/tests"), str(ROOT / "experiments/portal")]
import workflow_skills as skills
from test_epi_workflow_improvement import checkout

SKILL = "operate-rwd-product"
PACK = "products/oncology/test/202606"


def propose(root, label="one", **changes):
    loop = skills.learning()
    values = dict(skill=SKILL, wrong="The selected source row was lost.",
        right="Retain the selected source row.", context="Returning from source mapping " + label,
        by="Local reviewer", eval_goal="Return to the selected source row.",
        check_text=lambda *_: None, scope={"kind": "packs", "packs": [PACK]})
    return loop.propose_correction(root, **(values | changes))


def active(root, row):
    loop = skills.learning()
    value = copy.deepcopy(row)
    value.update(status="active", check={"passed": True, "tests": row["tests"], "summary": "Synthetic fixture checks.",
        "source_digest": loop.software_digest(root), "seconds": 0, "exit_code": 0},
        review={"reviewed_by": "Local reviewer", "reviewed_at": "2026-09-08T00:00:00Z"})
    return loop._write_correction(root, value)


def test_merged_library_above_old_limit_stays_readable_and_only_new_admission_blocks(checkout):
    loop = skills.learning()
    wanted = active(checkout, propose(checkout))
    folder = checkout / loop.CORRECTIONS
    # Git can merge independently admitted record files. Build that resulting
    # tree directly; no model calls, activation operation or real branch changes.
    template = copy.deepcopy(wanted)
    for number in range(501):
        value = template | {"id": f"{number:024x}", "status": "proposed", "check": None, "review": None}
        value["digest"] = loop.digest({key: item for key, item in value.items() if key != "digest"})
        (folder / (value["id"] + ".yaml")).write_text(yaml.safe_dump(value), encoding="utf-8")
    snapshot = loop.correction_snapshot(checkout)
    assert snapshot["unfinished"] == 502 and len(snapshot["by_id"]) == 502
    report = skills.context_for(checkout, SKILL, query="Return to selected source row.", task_scope={"packs": [PACK]})
    assert report["ok"] and report["corrections"]["ids"] == [wanted["id"]]
    with pytest.raises(ValueError, match="unfinished"):
        propose(checkout, "another request")
    assert len(loop.corrections(checkout)) == 502


@pytest.mark.parametrize("status", ["withdrawn", "retired"])
def test_terminal_history_preserves_exact_bytes_scope_idempotency_and_capacity(checkout, monkeypatch, status):
    loop = skills.learning()
    monkeypatch.setattr(loop, "MAX_CORRECTIONS", 1)
    provenance = {"observation_id": loop.digest("selected response one")}
    original = propose(checkout, provenance=provenance)
    value = copy.deepcopy(original)
    value["status"] = status
    if status == "retired":
        value["retirement"] = {"owner_id": original["id"], "proposal_id": "a" * 24,
            "application_digest": "b" * 64, "retired_by": "Local reviewer",
            "retired_at": "2026-09-08T00:00:00Z", "previous_status": "proposed"}
    terminal = loop._write_correction(checkout, value)
    before_path = loop._record_path(checkout, original["id"])
    before = before_path.read_bytes()
    archived = loop.archive_correction(checkout, terminal["id"], terminal["digest"], "Local reviewer")
    after_path = checkout / archived["path"]
    assert archived["changed"] and not before_path.exists() and after_path.read_bytes() == before
    assert archived["path"] == loop.correction_relative_path(checkout, terminal["id"])
    assert loop.read_correction(checkout, terminal["id"]) == terminal
    assert not loop.correction_snapshot(checkout, include_history=False)["records"]
    assert loop.correction_snapshot(checkout)["terminal"] == 1
    assert not loop.active_corrections(checkout, include_scoped=True)
    assert not loop.repeated_corrections(checkout) and not loop.correction_cases(checkout)
    assert propose(checkout, provenance=provenance)["id"] == terminal["id"]
    assert not loop.archive_correction(checkout, terminal["id"], terminal["digest"], "Local reviewer")["changed"]
    with pytest.raises(ValueError, match="immutable"):
        loop._write_correction(checkout, terminal | {"right": "Changing archived history is unsupported."})
    assert after_path.read_bytes() == before
    fresh = propose(checkout, provenance={"observation_id": loop.digest("new independent response")})
    assert fresh["id"] != terminal["id"] and fresh["status"] == "proposed"
    assert fresh["scope"] == terminal["scope"]
    with pytest.raises(ValueError, match="retired or withdrawn"):
        loop.archive_correction(checkout, fresh["id"], fresh["digest"], "Local reviewer")


def test_interrupted_archive_and_identical_branch_duplicate_are_recoverable(checkout):
    loop = skills.learning()
    row = propose(checkout)
    terminal = loop.withdraw_correction(checkout, row["id"], row["digest"], "Local reviewer")
    live, history = loop._record_locations(checkout, row["id"])
    history.parent.mkdir(parents=True)
    shutil.copyfile(live, history)  # The same result as interruption after complete history copy.
    assert loop.corrections(checkout) == [terminal]
    result = loop.archive_correction(checkout, row["id"], terminal["digest"], "Local reviewer")
    assert result["changed"] and not live.exists()
    assert loop.read_correction(checkout, row["id"]) == terminal
    shutil.copyfile(history, live)
    changed = copy.deepcopy(terminal)
    changed["right"] = "A conflicting branch edit."
    changed["digest"] = loop.digest({key: value for key, value in changed.items() if key != "digest"})
    live.write_text(yaml.safe_dump(changed), encoding="utf-8")
    with pytest.raises(ValueError, match="conflicting"):
        loop.archive_correction(checkout, row["id"], terminal["digest"], "Local reviewer")
    assert live.exists() and history.exists()


def test_content_cache_detects_same_size_timestamp_edit_and_never_leaks_mutable_rows(checkout, monkeypatch):
    loop = skills.learning()
    row = active(checkout, propose(checkout))
    path = loop._record_path(checkout, row["id"])
    loop._VALIDATED_RECORDS.clear()
    loop._VALIDATED_BYTES = 0
    calls, parser = [], loop._parse_correction
    def counted(*args):
        calls.append(1)
        return parser(*args)
    monkeypatch.setattr(loop, "_parse_correction", counted)
    first = skills.context_for(checkout, SKILL, query="Retain selected source row.", task_scope={"packs": [PACK]})
    assert first["ok"] and calls == [1]
    fetched = loop.read_correction(checkout, row["id"])
    fetched["right"] = "Mutating the returned view must not poison canonical guidance."
    assert loop.read_correction(checkout, row["id"])["right"] == row["right"] and calls == [1]
    path.write_bytes(path.read_bytes())  # New filesystem write, exactly the same validated content.
    same = skills.context_for(checkout, SKILL, query="Retain selected source row.", task_scope={"packs": [PACK]})
    assert same["digest"] == first["digest"] and calls == [1]
    original_stat = path.stat()
    changed = copy.deepcopy(row)
    changed["right"] = "Return the selected source row."
    assert len(changed["right"]) == len(row["right"])
    raw = path.read_text(encoding="utf-8")
    changed_digest = loop.digest({key: value for key, value in changed.items() if key != "digest"})
    raw = raw.replace(row["right"], changed["right"]).replace(row["digest"], changed_digest)
    path.write_bytes(raw.encode("utf-8"))
    os.utime(path, ns=(original_stat.st_atime_ns, original_stat.st_mtime_ns))
    assert path.stat().st_size == original_stat.st_size
    second = skills.context_for(checkout, SKILL, query="Retain selected source row.", task_scope={"packs": [PACK]})
    assert second["ok"] and second["digest"] != first["digest"] and len(calls) == 2
    assert changed["right"] in second["prompt"]
    assert not skills.freshness(checkout, SKILL, first["digest"], task_scope={"packs": [PACK]})["ok"]


def test_hot_snapshot_omits_archived_history_and_rereads_content_once_per_boundary(checkout, monkeypatch):
    loop = skills.learning()
    archived = propose(checkout, "history")
    archived = loop.withdraw_correction(checkout, archived["id"], archived["digest"], "Local reviewer")
    archived_path = checkout / loop.archive_correction(checkout, archived["id"], archived["digest"], "Local reviewer")["path"]
    live = active(checkout, propose(checkout, "current"))
    reads, reader = [], Path.read_bytes
    def observed(path):
        if path.suffix == ".yaml" and "corrections" in path.parts:
            reads.append(path)
        return reader(path)
    monkeypatch.setattr(Path, "read_bytes", observed)
    current = skills.context_for(checkout, SKILL, query="Return to selected source row.", task_scope={"packs": [PACK]})
    assert current["ok"] and current["corrections"]["ids"] == [live["id"]]
    assert archived_path not in reads
    assert reads.count(loop._record_path(checkout, live["id"])) == 2


def test_atomic_admission_refuses_parallel_overflow_and_same_request_retry(checkout, monkeypatch):
    loop = skills.learning()
    monkeypatch.setattr(loop, "MAX_CORRECTIONS", 2)
    propose(checkout, "already present")
    begun, release = threading.Event(), threading.Event()
    writer = loop._write_correction
    def paused(*args):
        begun.set()
        assert release.wait(10)
        return writer(*args)
    monkeypatch.setattr(loop, "_write_correction", paused)
    with ThreadPoolExecutor(max_workers=2) as pool:
        first = pool.submit(propose, checkout, "last space")
        assert begun.wait(10)
        second = pool.submit(propose, checkout, "competing space")
        try:
            with pytest.raises(ValueError, match="already"):
                second.result(timeout=10)
        finally:
            release.set()
        added = first.result(timeout=10)
    assert propose(checkout, "last space")["id"] == added["id"]
    with pytest.raises(ValueError, match="unfinished"):
        propose(checkout, "competing space")
    assert loop.correction_snapshot(checkout)["unfinished"] == 2
