"""Portable configuration handoffs remain inspectable drafts, never imported authority."""
import copy
import json
from pathlib import Path
import shutil
import sys

import pytest

ROOT = Path(__file__).resolve().parents[2]
sys.path[:0] = [str(ROOT / folder) for folder in ("platform/tests", "experiments/portal", "platform/tools")]
from test_epi_configuration_proposals import ACTOR, PACK, PASSING, CUT, START, seed, stage, action, open_proposal, original_bytes
import configuration_proposals as cp
import design_workspace as dw
import workflow_outputs
import repo_hygiene

REVIEWER = "reviewer@example.test"


@pytest.fixture
def shared(tmp_path, monkeypatch):
    source = tmp_path / "author"
    source.mkdir()
    seed(source)
    staged = stage(source)
    assert staged["ok"], staged
    monkeypatch.setattr(cp, "_run_validators", lambda *args: copy.deepcopy(PASSING))
    submitted = action("submit", source, staged)
    assert submitted["ok"], submitted
    preview = cp.share_preview(source, PACK, proposal_id=staged["proposal_id"], actor_id=ACTOR, allowed_packs=[PACK])
    assert preview["ok"], preview
    result = cp.share(source, PACK, proposal_id=staged["proposal_id"], actor_id=ACTOR,
        expected_digest=preview["digest"], confirmed=True, local_demo=True, can_write=True, allowed_packs=[PACK])
    assert result["ok"] and result["changed"], result
    return source, staged, result


def load(root, packet_id, **overrides):
    args = dict(packet_id=packet_id, actor_id=REVIEWER, allowed_packs=[PACK])
    args.update(overrides)
    return cp.load_shared(root, PACK, **args)


def restage(root, packet, **overrides):
    args = dict(packet_id=packet["packet_id"], actor_id=REVIEWER, expected_digest=packet["digest"],
        expected_baseline=dw.describe(root, PACK)["baseline_sha256"], confirmed=True,
        local_demo=True, can_write=True, allowed_packs=[PACK])
    args.update(overrides)
    return cp.restage_shared(root, PACK, **args)


def forge(root, original, mutate):
    """Recompute public checksums so attacks exercise semantic guards, not corruption alone."""
    packet = copy.deepcopy(original)
    mutate(packet)
    proposal = packet["proposal"]
    proposal["proposal_sha256"] = dw._hash({k: v for k, v in proposal.items() if k != "proposal_sha256"})
    if packet["validation"] is not None:
        validation = packet["validation"]
        validation["proposal_sha256"] = proposal["proposal_sha256"]
        validation["receipt_sha256"] = dw._hash({k: v for k, v in validation.items() if k != "receipt_sha256"})
    packet["packet_id"] = dw._hash({"proposal": proposal["proposal_sha256"], "validation": packet["validation"],
        "submission": packet["historical_submission"], "baseline_text": packet["baseline_text_sha256"]})[:32]
    packet["digest"] = dw._hash({k: v for k, v in packet.items() if k != "digest"})
    target = root / PACK / cp.SHARED_FOLDER / (packet["packet_id"] + ".json")
    target.write_text(json.dumps(packet), encoding="utf-8")
    return packet


def test_portable_packet_reopens_without_private_tree_and_restages_under_current_actor(shared, tmp_path):
    source, staged, saved = shared
    checkout = tmp_path / "reviewer"
    shutil.copytree(source, checkout, ignore=shutil.ignore_patterns(".portal-drafts", "__pycache__"))
    assert not list(checkout.rglob(".portal-drafts"))
    before = original_bytes(checkout)
    loaded = load(checkout, saved["packet_id"])
    assert loaded["ok"] and not loaded["stale"], loaded
    assert loaded["packet"]["validation"]["passed"] is True
    assert cp.list_shared(checkout, PACK, actor_id=REVIEWER, allowed_packs=[PACK])["records"] == [
        {"packet_id": saved["packet_id"], "purpose": staged["proposal"]["purpose"], "stale": False}]
    assert not cp.list_proposals(checkout, PACK, actor_id=REVIEWER, allowed_packs=[PACK])["proposals"]
    created = restage(checkout, loaded)
    assert created["ok"] and created["proposal_id"] != staged["proposal_id"], created
    current = cp.load(checkout, PACK, proposal_id=created["proposal_id"], actor_id=REVIEWER, allowed_packs=[PACK])
    assert current["ok"] and current["validation"] is None and current["submission"] is None
    assert current["proposal"]["owner"] != staged["proposal"]["owner"]
    assert current["proposal"]["draft_only"] and current["proposal"]["approved"] is False and current["proposal"]["released"] is False
    assert current["proposal"]["files"] == staged["proposal"]["files"]
    assert original_bytes(checkout) == before


def test_sharing_is_idempotent_owned_output_and_does_not_invalidate_its_proposal(shared):
    source, staged, saved = shared
    text = (source / saved["path"]).read_text(encoding="utf-8")
    assert ".portal-drafts" not in text and str(source) not in text
    assert workflow_outputs.is_saved_output(saved["path"])
    assert not repo_hygiene.handoff_errors(source, [saved["path"]])
    loaded = open_proposal(source, staged)
    assert loaded["ok"] and not loaded["stale"], loaded
    again = cp.share(source, PACK, proposal_id=staged["proposal_id"], actor_id=ACTOR,
        expected_digest=saved["digest"], confirmed=True, local_demo=True, can_write=True, allowed_packs=[PACK])
    assert again["ok"] and not again["changed"]
    assert (source / saved["path"]).read_text(encoding="utf-8") == text


@pytest.mark.parametrize("override", [{"confirmed": False}, {"can_write": False}, {"local_demo": False},
    {"allowed_packs": []}, {"expected_digest": "changed"}, {"expected_baseline": "changed"}, {"actor_id": ""}])
def test_restage_requires_current_scope_identity_confirmation_and_bindings(shared, override):
    source, staged, saved = shared
    before = original_bytes(source)
    assert not restage(source, saved, **override)["ok"]
    assert original_bytes(source) == before
    assert not cp.list_proposals(source, PACK, actor_id=REVIEWER, allowed_packs=[PACK])["proposals"]


def test_stale_baseline_is_visible_but_cannot_be_restaged(shared):
    source, staged, saved = shared
    path = source / PACK / "variables/outcomes.yaml"
    path.write_bytes(path.read_bytes() + b"\n# Reviewer branch changed\n")
    before = original_bytes(source)
    loaded = load(source, saved["packet_id"])
    assert loaded["ok"] and loaded["stale"]
    assert not restage(source, loaded)["ok"]
    assert original_bytes(source) == before


@pytest.mark.parametrize("path", ["../../outside.yaml", "config/../../outside.yaml", "handoff/FUNCTIONAL_CONTRACT.md", "C:/outside.yaml"])
def test_rehashed_packet_paths_are_refused_without_writes(shared, path):
    source, staged, saved = shared
    packet = forge(source, saved["packet"], lambda p: p["proposal"]["files"][0].update(path=path))
    before = original_bytes(source)
    assert not load(source, packet["packet_id"])["ok"]
    assert not restage(source, packet)["ok"]
    assert original_bytes(source) == before


def test_rehashed_hidden_candidate_change_is_refused(shared):
    source, staged, saved = shared
    packet = forge(source, saved["packet"], lambda p: p["proposal"]["files"][0].update(after=p["proposal"]["files"][0]["after"] + "\nundeclared_setting: true\n"))
    assert not load(source, packet["packet_id"])["ok"]
    assert not restage(source, packet)["ok"]


def test_rehashed_declared_change_without_displayed_file_cannot_be_written(shared):
    source, staged, saved = shared
    packet = forge(source, saved["packet"], lambda p: p["proposal"]["configuration_changes"].append({"ref": CUT, "value": "hidden-cut"}))
    before = original_bytes(source)
    assert not restage(source, packet)["ok"]
    assert original_bytes(source) == before
    assert not cp.list_proposals(source, PACK, actor_id=REVIEWER, allowed_packs=[PACK])["proposals"]


def test_rehashed_supported_edit_to_an_undisplayed_file_is_refused(shared):
    source, staged, saved = shared
    packet = forge(source, saved["packet"], lambda p: p["proposal"]["configuration_changes"].append(
        {"ref": START, "value": "2014-01-01"}))
    before = original_bytes(source)
    assert not load(source, packet["packet_id"])["ok"]
    assert not restage(source, packet)["ok"]
    assert original_bytes(source) == before


def test_shared_packet_never_overwrites_a_concurrently_created_file(shared, monkeypatch):
    source, staged, saved = shared
    target = source / saved["path"]
    target.unlink()  # This disposable fixture's own packet; simulate a new publish.
    original_link = cp.os.link
    def competing_link(from_path, to_path, **kwargs):
        if Path(to_path) == target:
            target.write_text('{"concurrent_work":true}', encoding="utf-8")
        return original_link(from_path, to_path, **kwargs)
    monkeypatch.setattr(cp.os, "link", competing_link)
    result = cp.share(source, PACK, proposal_id=staged["proposal_id"], actor_id=ACTOR,
        expected_digest=saved["digest"], confirmed=True, local_demo=True, can_write=True, allowed_packs=[PACK])
    assert not result["ok"]
    assert target.read_text(encoding="utf-8") == '{"concurrent_work":true}'


def test_rehashed_reviewer_authority_cannot_be_imported_in_history(shared):
    source, staged, saved = shared
    packet = forge(source, saved["packet"], lambda p: p["historical_submission"].update(
        approved=True, reviewed_by="Someone else", decision="accept"))
    assert not load(source, packet["packet_id"])["ok"]


def test_only_canonical_packet_names_are_owned_handoff_outputs():
    good = PACK + "/handoff/CONFIGURATION_PROPOSALS/" + "a" * 32 + ".json"
    bad = [good.replace(".json", ".py"), good.replace("a" * 32, "notes"), good.replace("a" * 32, "a" * 24)]
    assert workflow_outputs.is_saved_output(good)
    assert not repo_hygiene.handoff_errors(ROOT, [good])
    for path in bad:
        assert not workflow_outputs.is_saved_output(path)
        assert repo_hygiene.handoff_errors(ROOT, [path])


def test_rehashed_disagreeing_displayed_purpose_is_not_reused(shared):
    source, staged, saved = shared
    packet = forge(source, saved["packet"], lambda p: p["proposal"].update(purpose="A different displayed scientific purpose."))
    assert not load(source, packet["packet_id"])["ok"]
    assert not restage(source, packet)["ok"]


def test_credential_like_text_is_refused_even_after_rehashing(shared):
    source, staged, saved = shared
    credential = "sk-" + "a" * 48
    packet = forge(source, saved["packet"], lambda p: p["proposal"]["brief"].update(purpose="Use this credential " + credential))
    assert not load(source, packet["packet_id"])["ok"]
    assert not restage(source, packet)["ok"]


def test_invalid_scope_cannot_list_or_load_other_products_packet(shared):
    source, staged, saved = shared
    assert not load(source, saved["packet_id"], allowed_packs=[])["ok"]
    assert not cp.list_shared(source, PACK, actor_id=REVIEWER, allowed_packs=[])["ok"]
