"""Eleventh external verdict (2026-09-04, main 8d27f87) — failing first, then absorbed.

  P0  a contract record could cite the wrong specification variable (the scaffold's `_variable` was
      dropped with every underscore field) and still pass all 22 invariants
  P0  every documented decision mutation crashed with NameError: the module called main() before
      record_event / seal_preflight / seal_applied were defined
  P0  a non-oncology product could obtain a strict green by declaring `tumor_class: solid`; the
      engine is oncology-configurable and must say so instead of passing the wrong semantics
  P1  status crashed on a copied template's empty contract (KeyError: mapped); the runbook's order
      contradicted the init tool; the activation block omitted run_as / can_manage; the Gate 3
      report path resolved against the checkout; the template's NAME-ALIGN row had no evidence so
      no form could be issued; the fixture note rendered on the Products view; documents overstated
      what the engine and the bridge support

NO PYTEST FIXTURES AND NO `parametrize` — CI runs every suite as a script.
"""
import os
import re
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

FRAMEWORK = Path(__file__).resolve().parent.parent
ROOT = FRAMEWORK.parent
for p in (FRAMEWORK / "tools", FRAMEWORK, FRAMEWORK / "engine", ROOT / "experiments" / "portal"):
    sys.path.insert(0, str(p))
os.environ.setdefault("PYTHONUTF8", "1")

BLADDER = "sandbox/demo_walkthrough/bladder/202609"
PROSTATE = "fixtures/oncology/prostate/202606"


def _read(rel):
    return (ROOT / rel).read_text(encoding="utf-8")


def _cli(tool, *args, cwd=None):
    env = dict(os.environ, PYTHONUTF8="1")
    p = subprocess.run([sys.executable, str(FRAMEWORK / "tools" / tool), *args], cwd=cwd or str(ROOT), env=env,
                       capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=300)
    return p.returncode, (p.stdout or "") + (p.stderr or "")


# ------------------------------------------------------------------ P0 the contract cites its own variable

def test_a_record_may_only_cite_the_specification_row_of_its_own_variable():
    import contract_record as cr  # noqa: PLC0415
    import contract_scaffold as cs  # noqa: PLC0415
    assert cs.evidence_for(BLADDER, "demographics:2")["_variable"] == "AGE"
    assert cs.evidence_for(BLADDER, "study_period:4")["_variable"] == "DATAV"
    ok, probs = cr.merge_evidence({"variable_id": "AGE", "requirement": "draft"}, BLADDER, "demographics:2")
    assert probs == [] and ok["spec_refs"] == ["demographics:2"]
    wrong, probs = cr.merge_evidence({"variable_id": "AGE", "requirement": "draft"}, BLADDER, "study_period:4")
    assert probs and "DATAV" in probs[0] and "AGE" in probs[0], probs
    assert "spec_refs" not in wrong, "nothing of the wrong row is merged"
    # case is not identity: `age` is the AGE row's variable
    ok2, probs2 = cr.merge_evidence({"variable_id": "age"}, BLADDER, "demographics:2")
    assert probs2 == []
    # SECOND PASS: the rule is the lint's (contract_lint.cites_own_variable, I25). A record that derives
    # from another row's variable names it in depends_on; a bare prefix or a sentence in the notes that
    # happens to contain the name is not an acknowledgment
    assert cr._cites_own_variable({}, "FU_ENDDT_PRELIM", "FU_ENDDT_preliminary"), "an abbreviated last word is the same name"
    assert not cr._cites_own_variable({}, "FU_ENDDT", "FU_ENDDT_preliminary"), "a dropped word is not"
    assert cr._cites_own_variable({"depends_on": ["DATAV"]}, "STUDY_METADATA", "DATAV")
    assert not cr._cites_own_variable({"derivation": "derived from DATAV, the data version row"}, "STUDY_METADATA", "DATAV")
    assert not cr._cites_own_variable({"derivation": "age at index"}, "AGE", "DATAV")
    assert cr._cites_own_variable({}, "DTHFL__2", "DTHFL") and cr._cites_own_variable({}, "AGE_AT_INDEX", "AGE")
    assert not cr._cites_own_variable({}, "D", "DATAV") and not cr._cites_own_variable({}, "AGE", "AGE18")


# ------------------------------------------------------------------ P0 the decision CLI runs

def test_every_documented_decision_mutation_runs_as_a_real_subprocess():
    src = _read("platform/tools/decision_record.py")
    entry = src.index('if __name__ == "__main__":')
    for name in ("def record_event(", "def seal_preflight(", "def seal_applied("):
        assert src.index(name) < entry, f"{name} is defined after the entry point"
    # a throwaway copy of the bladder pack INSIDE the checkout's sandbox, so pack paths resolve;
    # a unique name per run, because OneDrive's read-only attributes can defeat the cleanup
    import stat  # noqa: PLC0415
    tmp_rel = f"sandbox/demo_walkthrough/_audit11_tmp_{os.getpid()}/202609"
    tmp = ROOT / tmp_rel

    def _writable_rm(top):
        for dirpath, dirnames, filenames in os.walk(top):
            for n in dirnames + filenames:
                try:
                    os.chmod(os.path.join(dirpath, n), stat.S_IWRITE | stat.S_IREAD | stat.S_IEXEC)
                except OSError:
                    pass
        shutil.rmtree(top, ignore_errors=True)
    _writable_rm(tmp.parent)
    shutil.copytree(ROOT / BLADDER, tmp, dirs_exist_ok=True)
    try:
        for args in (("--forms",), ("--apply",), ("--record-event", "NO-SUCH-ID"), ("--check",)):
            rc, out = _cli("decision_record.py", tmp_rel, *args)
            assert "NameError" not in out and "Traceback" not in out, (args, out[-600:])
    finally:
        _writable_rm(tmp.parent)


# ------------------------------------------------------------------ P0 the engine says what it is

def test_a_non_oncology_condition_class_is_refused_not_relabelled():
    import validate as ev  # noqa: PLC0415
    from config import load_config  # noqa: PLC0415
    with tempfile.TemporaryDirectory() as d:
        pack = os.path.join(d, "202606")
        for sub in ("config", "variables", "codelists"):
            shutil.copytree(ROOT / PROSTATE / sub, os.path.join(pack, sub))
        path = os.path.join(pack, "config", "data_product.yaml")
        text = open(path, encoding="utf-8").read()
        # every fixture DECLARES `condition_class: oncology` now (twelfth verdict): the probe replaces it
        assert re.search(r"^condition_class: oncology", text, re.M), "the fixture declares its class"
        open(path, "w", encoding="utf-8").write(re.sub(r"^condition_class: oncology[^\n]*$", "condition_class: respiratory", text, count=1, flags=re.M))
        cfg = load_config(path)
        assert cfg.condition_class == "respiratory"
        findings = [f for f in ev.problems(cfg, strict=True) if "condition_class" in f]
        assert findings and "oncology" in findings[0] and "relabel" in findings[0], findings
    readme = _read("README.md")
    assert "tumor-agnostic" not in readme and "oncology" in readme
    pr = _read("platform/README.md")
    assert "tumor-agnostic" not in pr and "non-oncology" in pr


# ------------------------------------------------------------------ P1 the runbook works

def test_status_facts_and_forms_stand_on_a_copied_template():
    import finalize  # noqa: PLC0415
    with tempfile.TemporaryDirectory() as d:
        os.makedirs(os.path.join(d, "handoff"))
        open(os.path.join(d, "handoff", "FUNCTIONAL_CONTRACT.md"), "w", encoding="utf-8").write("# Contract\n\nNo records yet.\n")
        f = finalize.facts(d)
        assert f["records"] == 0 and f.get("mapped") == 0 and f.get("items") == 0, f
    st = _read("platform/tools/status.py")
    assert "f['mapped']" not in st and "f['items']" not in st
    tpl = _read("platform/TUMOR_TEMPLATE/handoff/DECISIONS.md")
    row = next(l for l in tpl.splitlines() if l.startswith("| NAME-ALIGN"))
    cells = [c.strip() for c in row.strip("|").split("|")]
    assert cells[2] not in ("", "—", "-"), "the template's placeholder decision carries usable evidence"


def test_the_init_replaces_an_untouched_template_placeholder_and_the_runbook_registers_first():
    import source_refs_init as sri  # noqa: PLC0415
    with tempfile.TemporaryDirectory() as d:
        p = os.path.join(d, "source_refs.yaml")
        open(p, "w", encoding="utf-8").write("product: REPLACE_ME\nspec_version: REPLACE_ME\n")
        assert sri.placeholder_untouched(p)
        open(p, "w", encoding="utf-8").write("product: bladder\nspec_version: '202609'\n")
        assert not sri.placeholder_untouched(p)
    src = _read("platform/tools/source_refs_init.py")
    assert "placeholder_untouched(target)" in src
    doc = _read("platform/TUMOR_TEMPLATE/NEW_TUMOUR.md")
    assert doc.index("`products/registry.yaml`** — FIRST") < doc.index("source_refs_init.py")
    assert "run_as" in doc and "can_manage" in doc
    assert "--out handoff/SOURCE_VERDICTS.md` is resolved against the pack" in doc


def test_the_gate_3_report_path_resolves_against_the_pack():
    import source_check as sc  # noqa: PLC0415
    with tempfile.TemporaryDirectory() as d:
        assert sc.resolve_out("handoff/SOURCE_VERDICTS.md", d) == os.path.join(d, "handoff", "SOURCE_VERDICTS.md")
        abs_ = os.path.join(d, "x.md")
        assert sc.resolve_out(abs_, d) == abs_
        assert sc.resolve_out("reports/x.md", d) == "reports/x.md", "only a pack-shaped relative path is re-rooted"
    src = _read("platform/tools/source_check.py")
    assert "resolve_out(a.out" in src


def test_the_fixture_note_is_for_the_reference_view_only():
    import ast
    app = _read("experiments/portal/app.py")
    guard = next(node for node in ast.parse(app).body if isinstance(node, ast.If)
                 and any(isinstance(call, ast.Call) and ast.unparse(call.func) == "st.sidebar.caption"
                         and any(ast.unparse(arg) == "ui.FIXTURES_NOTE" for arg in call.args)
                         for call in ast.walk(node)))
    condition = compile(ast.Expression(guard.test), "<reference note guard>", "eval")
    for pack in ("", "fixtures/oncology/prostate/202606"):
        for view in ("Products", "Reference examples"):
            assert bool(eval(condition, {"pack": pack, "VIEW": view})) is bool(pack and view != "Products")


def test_the_documents_stop_overstating():
    assert "Gated on approvals and data access rather than engineering" not in _read("DEMO.md")
    pr = _read("docs/PRODUCTION_READINESS.md")
    assert "for a brand-new tumour" not in pr and "oncology tumour" in pr
    assert "binds one active adapter set per pack" in _read("platform/tools/source_adapter.py")
    ce = _read("platform/tools/cohortly_export.py")
    assert "nothing is owed by any other team" not in ce and "UNGOVERNED" in ce
    v = tuple(int(x) for x in _read("platform/VERSION").strip().split("."))
    assert v >= (1, 267, 0)


if __name__ == "__main__":
    fails = 0
    for name, fn in sorted(globals().items()):
        if name.startswith("test_") and callable(fn):
            try:
                fn()
                print(f"  ok   {name}")
            except Exception as e:  # noqa: BLE001
                fails += 1
                print(f"  FAIL {name}: {type(e).__name__}: {str(e)[:300]}")
    print(f"{fails} failure(s)")
    sys.exit(1 if fails else 0)
