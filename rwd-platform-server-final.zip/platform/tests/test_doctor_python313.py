"""Local Spark prerequisites follow executable evidence on the selected Python."""
from pathlib import Path
import builtins
import subprocess
import sys
from types import SimpleNamespace

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "tools"))
import doctor
import java_home


@pytest.fixture
def runtime(monkeypatch, tmp_path):
    java = tmp_path / "jdk/bin" / ("java.exe" if doctor.os.name == "nt" else "java")
    java.parent.mkdir(parents=True)
    java.write_bytes(b"version probes are intercepted; never execute this fixture")
    monkeypatch.setenv("JAVA_HOME", str(java.parent.parent))
    monkeypatch.setenv("PYSPARK_PYTHON", "selected-python")
    monkeypatch.setattr(doctor.sys, "version_info", (3, 13, 13))
    monkeypatch.setitem(sys.modules, "pyspark", SimpleNamespace(__version__="4.0.4"))
    monkeypatch.setattr(doctor, "_importable", lambda name: True)
    monkeypatch.setattr(java_home, "ensure", lambda: None)
    monkeypatch.setattr(doctor.shutil, "which", lambda name: None)
    state = {"java": 'openjdk version "17.0.20.1"', "worker": "3.13\n", "calls": [],
             "java_code": 0, "worker_code": 0, "error": None}

    def probe(argv, **kwargs):
        state["calls"].append((argv, kwargs))
        assert kwargs["timeout"] == 10
        if state["error"] == argv[0] or state["error"] == "all":
            raise subprocess.TimeoutExpired(argv, 10)
        if argv == [str(java), "-version"]:
            return subprocess.CompletedProcess(argv, state["java_code"], "", state["java"])
        assert argv == ["selected-python", "-c", "import sys; print('%s.%s' % sys.version_info[:2])"]
        return subprocess.CompletedProcess(argv, state["worker_code"], state["worker"], "")

    monkeypatch.setattr(doctor.console, "run", probe)
    return state


@pytest.mark.parametrize("minor", [11, 13])
@pytest.mark.parametrize("java", [17, 21])
def test_matching_worker_and_java_allow_existing_build_without_claiming_execution(runtime, monkeypatch, minor, java, capsys):
    monkeypatch.setattr(doctor.sys, "version_info", (3, minor, 13))
    runtime["worker"] = f"3.{minor}\n"
    runtime["java"] = f'openjdk version "{java}.0.1"'
    row = doctor._spark_runtime()
    assert row[0] == doctor.OK
    assert "Spark execution not checked" in row[2]
    assert "synthetic build" in row[3]
    assert len(runtime["calls"]) == 2
    doctor.report([row])
    output = capsys.readouterr().out
    assert "Local Spark: prerequisites available" in output
    assert "Local Spark: READY" not in output


@pytest.mark.parametrize("version,code", [('openjdk version "11.0.20"', 0),
                                        ('java version "1.8.0_452"', 0),
                                        ('openjdk version "25.0.1"', 0),
                                        ('openjdk version "17.0.20"', 1), ("unknown", 0)])
def test_missing_unusable_or_old_java_never_reports_prerequisites_ready(runtime, version, code):
    runtime.update(java=version, java_code=code)
    row = doctor._spark_runtime()
    assert row[0] == doctor.LIMITED
    assert "Java 17 or 21 runtime was not verified" in row[2]
    assert len(runtime["calls"]) == 1


@pytest.mark.parametrize("worker,code", [("3.11\n", 0), ("", 0), ("3.13\n", 1)])
def test_inherited_old_worker_or_failed_probe_cannot_pass_on_driver_version_alone(runtime, worker, code):
    runtime.update(worker=worker, worker_code=code)
    row = doctor._spark_runtime()
    assert row[0] == doctor.LIMITED
    assert "does not match driver Python 3.13" in row[2]
    assert "PYSPARK_PYTHON" in row[3]


@pytest.mark.parametrize("error", ["all", "selected-python"])
def test_version_probe_timeout_is_a_limitation_not_a_traceback(runtime, error):
    runtime["error"] = error
    row = doctor._spark_runtime()
    assert row[0] == doctor.LIMITED
    assert "could not" in row[2]


def test_empty_java_directory_does_not_count_as_a_reachable_jvm(runtime, monkeypatch, tmp_path):
    (tmp_path / "empty-jdk/bin").mkdir(parents=True)
    monkeypatch.setenv("JAVA_HOME", str(tmp_path / "empty-jdk"))
    row = doctor._spark_runtime()
    assert row[0] == doctor.LIMITED
    assert "NO JVM" in row[2]
    assert not runtime["calls"]


@pytest.mark.parametrize("spark_version", ["3.5.0", "4.0.1", "4.0.2"])
def test_different_spark_version_requires_the_fixed_engine_pin(runtime, monkeypatch, spark_version):
    monkeypatch.setitem(sys.modules, "pyspark", SimpleNamespace(__version__=spark_version))
    row = doctor._spark_runtime()
    assert row[0] == doctor.LIMITED
    assert "4.0.4" in row[2] and "4.0.4" in row[3]
    assert not runtime["calls"]


def test_incomplete_pyspark_install_is_actionable_without_a_traceback(runtime, monkeypatch):
    original = builtins.__import__

    def interrupted_install(name, *args, **kwargs):
        if name == "pyspark":
            raise ModuleNotFoundError("missing module in an interrupted installation")
        return original(name, *args, **kwargs)

    monkeypatch.setattr(builtins, "__import__", interrupted_install)
    row = doctor._spark_runtime()
    assert row[0] == doctor.LIMITED
    assert "could not import" in row[2]
    assert "repair" in row[3]
    assert not runtime["calls"]
