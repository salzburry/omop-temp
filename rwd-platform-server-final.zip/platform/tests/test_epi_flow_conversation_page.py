"""The shared chat displays and sends the same bounded conversation window."""
import copy
import hashlib
from pathlib import Path
import sys

import pytest
from streamlit.testing.v1 import AppTest

ROOT = Path(__file__).resolve().parents[2]
sys.path[:0] = [str(ROOT / name) for name in
    ("platform/tests", "experiments/portal", "platform/tools", "experiments/agent")]
from test_epi_flow_assistant import _card
import flow_assistant as guide
import flow_assistant_page as page

PACK = "fixtures/oncology/prostate/202606"


def test_shared_page_displays_and_passes_all_eight_turns_without_automatic_calls(monkeypatch):
    calls = []
    monkeypatch.setattr(page, "_provider_words", lambda *_: ({"configured": True}, "Offline test connection"))

    def answer(question, card, **kwargs):
        calls.append({"question": question, "history": copy.deepcopy(kwargs["history"])})
        return {"answer": "The current question received one answer.", "actions": [], "source": "checks",
                "context_window": {"included_turns": 6, "omitted_turns": 2}}

    monkeypatch.setattr(guide, "answer", answer)
    script = f'''import streamlit as st
import flow_assistant_page as page
page.render({str(ROOT)!r}, {PACK!r}, card=st.session_state["card"], actor_id="history-author",
    primary=True, metadata_only=True, allowed_packs=[{PACK!r}])
'''
    at = AppTest.from_string(script, default_timeout=30)
    at.session_state["card"] = _card()
    owner = hashlib.sha256((str(ROOT) + "\0history-author").encode()).hexdigest()[:20]
    key = f"{page.KEY}history_{owner}_{PACK}"
    previous = [{"question": f"Prior question {index}.", "answer": f"Prior answer {index}."}
                for index in range(guide.MAX_CONVERSATION_TURNS)]
    at.session_state[key] = copy.deepcopy(previous)
    at.run()
    assert not at.exception
    assert not calls
    assert len(at.chat_message) == 2 * guide.MAX_CONVERSATION_TURNS
    at.chat_input[0].set_value("Use the details we discussed earlier.").run()
    assert not at.exception
    assert len(calls) == 1
    assert calls[0]["history"] == previous
    assert len(at.session_state[key]) == guide.MAX_CONVERSATION_TURNS
    assert at.session_state[key][0] == previous[1]
    assert at.session_state[key][-1]["context_window"] == {"included_turns": 6, "omitted_turns": 2}
    at.run()
    assert not at.exception and len(calls) == 1
    assert len(at.chat_message) == 2 * guide.MAX_CONVERSATION_TURNS
    assert any("included 6 earlier conversation turns" in caption.value and "2 earlier turns" in caption.value
               for caption in at.caption)


@pytest.mark.parametrize("action,target", [("open_coding", "implementation_patterns"),
    ("open_source_mapping", "source_mapping"), ("open_specialist", "specialist_assistant")])
def test_action_handoff_carries_the_persons_question_and_never_model_prose(monkeypatch, action, target):
    import connected_workflow_page
    import streamlit as st
    monkeypatch.setattr(page, "_provider_words", lambda *_: (None, "Offline navigation"))
    monkeypatch.setattr(connected_workflow_page, "open_route", lambda route, pack, actor, **kwargs:
                        st.session_state.__setitem__("navigation", {"route": route, "pack": pack, "actor": actor, **kwargs}))
    request = "Explain how to adapt the existing measurement code while preserving its missing-value rule."
    script = f'''import streamlit as st
import flow_assistant_page as page
page.render({str(ROOT)!r}, {PACK!r}, card=st.session_state["card"], actor_id="history-author",
    primary=True, metadata_only=True, allowed_packs=[{PACK!r}])
'''
    at = AppTest.from_string(script, default_timeout=30)
    at.session_state["card"] = {**_card(), "actions": [action]}
    owner = hashlib.sha256((str(ROOT) + "\0history-author").encode()).hexdigest()[:20]
    key = f"{page.KEY}history_{owner}_{PACK}"
    at.session_state[key] = [{"question": request, "answer": "MODEL-PROSE-MUST-NOT-BECOME-THE-REQUEST", "actions": [action]}]
    at.run()
    assert not at.exception and "navigation" not in at.session_state
    next(button for button in at.button if button.label == guide.ACTIONS[action]["label"]).click().run()
    assert not at.exception
    assert at.session_state["navigation"] == {"route": target, "pack": PACK, "actor": "history-author",
                                              "params": {"user_request": request}}


@pytest.mark.parametrize("pending_question", ["X" * (guide.MAX_QUESTION + 1), "api_key=sk-12345678901234567890"])
def test_invalid_handoff_text_is_not_copied_into_route_parameters(monkeypatch, pending_question):
    import connected_workflow_page
    import streamlit as st
    monkeypatch.setattr(connected_workflow_page, "open_route", lambda route, pack, actor, **kwargs:
                        st.session_state.__setitem__("navigation", {"route": route, **kwargs}))
    script = f'''import streamlit as st
import flow_assistant_page as page
if st.button("Open help"):
    page._go("open_coding", {{"actions": ["open_coding"]}}, {PACK!r}, "history-author", question={pending_question!r})
'''
    at = AppTest.from_string(script, default_timeout=30).run()
    at.button[0].click().run()
    assert not at.exception
    assert at.session_state["navigation"] == {"route": "implementation_patterns", "params": {}}
