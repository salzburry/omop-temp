"""The scientist's focused Flow page, exercised through Streamlit dialogs and reruns.

Run: python platform/tests/test_epi_flow_page.py
No CLI or governed write is executed: checks and workers are deterministic doubles.
The action guard's filesystem/policy cases are covered in its own backend suite.
"""
from __future__ import annotations

import contextlib
import copy
import hashlib
import json
import sys
import tempfile
import traceback
import types
import yaml
from pathlib import Path
from unittest.mock import Mock, patch

ROOT = Path(__file__).resolve().parents[2]
sys.path[:0] = [str(ROOT / "platform" / "tests"), str(ROOT / "experiments" / "portal"),
               str(ROOT / "platform" / "tools")]
PACK = "fixtures/oncology/gist/202608"


def _action(aid, kind, label, argv=None, note=""):
    return {"id": aid, "kind": kind, "label": label, "argv": argv or [],
            "path": f"{PACK}/source_refs.yaml", "note": note,
            "actions_row": "register_or_revise_material"}


def _actions():
    sm = "platform/tools/source_manifest.py"
    return [
        _action("g1_check", "read", "Check the registration", [sm, PACK, "--check"]),
        _action("g1_workbook", "person", "Supply the approved workbook",
                note="Ask your data expert to register the approved workbook in the source record."),
        _action("g1_digest", "write", "Record the workbook fingerprint", [sm, PACK, "--record-digest", "program_spec"]),
        _action("g1_register_extraction", "write", "Prepare the extraction registration", [sm, "--register-ai-extraction", PACK, "--write"]),
        _action("g1_seal", "write", "Record the reviewed source", [sm, PACK, "--record-event", "program_spec"]),
    ]


def _flow(actions=None, *, other_blockers=False):
    blocker = {"text": "The approved workbook is missing from the source registration.",
               "owner": "Science", "fixes": list(actions or _actions())}
    blockers = [blocker]
    if other_blockers:
        blockers.append({"text": "The source classification also needs review.", "owner": "Science",
                         "fixes": [_action("g1_classify", "person", "Review AI access to the source")]})
    titles = ["Sources", "Definitions", "Data mapping", "Configuration", "Validation", "Release"]
    gates = [{"gate": i, "title": title, "owner": "Science", "state": "blocked" if i == 1 else "not_started",
              "blockers": [b["text"] for b in blockers] if i == 1 else []} for i, title in enumerate(titles, 1)]
    return {"pack": PACK, "gates": gates, "current": 1, "clear": False,
            "blockers": blockers, "proceed": "Provide the approved workbook.", "next": None, "closing": []}


def _at_gate(gate, actions):
    """Reuse the page fixture when exercising scientific and later workflow steps."""
    result = _flow(actions)
    result["current"] = gate
    result["blockers"][0]["text"] = "The workflow still requires authored records and review evidence."
    for item in result["gates"]:
        item["state"] = "done" if item["gate"] < gate else "blocked" if item["gate"] == gate else "not_started"
    return result


def _healthy(at):
    assert not at.exception, "\n".join(str(e.message) for e in at.exception)


def _button(at, key):
    return next((b for b in at.button if b.key == key), None)


def _visible_nodes(block):
    """Collapsed technical detail still exists in AppTest's tree; exclude it for UX assertions."""
    if getattr(block, "type", "") == "expander" and not block.proto.expanded:
        return
    yield block
    for child in getattr(block, "children", {}).values():
        yield from _visible_nodes(child)


def _visible_ui(at):
    # Dialog elements are emitted on Streamlit's event surface, outside at.main.
    yield from _visible_nodes(at.main)
    for dialog in at.get("dialog"):
        if dialog.proto.dialog.is_open:
            yield from _visible_nodes(dialog)


@contextlib.contextmanager
def _page(result=None, *, checked=True, can_write=True, can_review=False, guard=None, output=None, root=ROOT, pack=PACK):
    from streamlit.testing.v1 import AppTest
    import flow_guidance

    case = types.ModuleType("_epi_flow_case")
    case.result = copy.deepcopy(result or _flow())
    case.root, case.pack, case.label = str(root), pack, "GIST planning example"
    case.actor, case.local_demo, case.can_write, case.can_view = "Priya", True, can_write, True
    case.can_review = can_review
    case.evaluate = Mock(return_value=case.result)
    case.run_action = Mock(return_value="Check completed.\n\nexit 0")
    case.checked, case.output = checked, output or {}
    source = """import streamlit as st
import flow_page
import _epi_flow_case as case
st.set_page_config(layout='wide')
st.session_state.setdefault('flow_result', {case.pack: case.result} if case.checked else {})
st.session_state.setdefault('flow_output', case.output)
flow_page.render(root=case.root, pack=case.pack, label=case.label, actor_id=case.actor,
                 local_demo=case.local_demo, can_write=case.can_write, can_view=case.can_view,
                 evaluate=case.evaluate, run_action=case.run_action, can_review=case.can_review)
"""
    with contextlib.ExitStack() as stack:
        # Restore only the test module. Restoring the entire module dictionary
        # unloads NumPy/PyArrow imported by a table on the first run, and their
        # native modules cannot safely be imported again in the same process.
        previous = sys.modules.get(case.__name__)
        sys.modules[case.__name__] = case
        stack.callback(lambda: sys.modules.pop(case.__name__, None) if previous is None
                       else sys.modules.__setitem__(case.__name__, previous))
        if guard is not None:
            stack.enter_context(patch.object(flow_guidance, "action_guard", side_effect=guard))
            # A simulated ready stage must not borrow the unrelated on-disk
            # reference fixture's already-recorded checksum. Real prerequisite
            # and completed-stage tests below use temporary roots with no patch.
            def availability(*args, **kwargs):
                reason = flow_guidance.action_guard(*args, **kwargs)
                return {"state": "blocked" if reason else "ready", "reason": reason}
            stack.enter_context(patch.object(flow_guidance, "action_state", side_effect=availability))
        at = AppTest.from_string(source, default_timeout=30).run()
        _healthy(at)
        yield at, case


def _open(at):
    at.button(key="flow_resolve").click().run()
    _healthy(at)
    assert any(d.proto.dialog.is_open for d in at.get("dialog"))


def _open_details(at):
    """Metadata corrections remain separate from the named source-review decision."""
    at.button(key="flow_edit_specification").click().run()
    _healthy(at)
    assert any(d.proto.dialog.is_open for d in at.get("dialog"))


def _choose(at, aid):
    at.selectbox(key="flow_resolution_action").set_value(aid).run()
    _healthy(at)


def test_an_acts_outcome_stays_on_the_page_until_the_next_status_check():
    """A signature, a settled requirement or a maturity claim is recorded inside a dialog; its outcome
    is repeated on the page and survives reruns until the person checks status again (walk RW1-04)."""
    with _page(_flow(other_blockers=True)) as (at, case):
        at.session_state["flow_notice"] = "Signed as Priya Sharma. Your review identity is verified."
        at.run()
        _healthy(at)
        assert any("Signed as Priya Sharma" in s.value for s in at.success), [s.value for s in at.success]
        at.run()
        _healthy(at)
        assert any("Signed as Priya Sharma" in s.value for s in at.success), "a rerun is not a person reading"
        at.button(key="flow_check").click().run()
        _healthy(at)
        assert not any("Signed as Priya Sharma" in s.value for s in at.success)


def test_main_page_has_one_focused_resolution_and_no_visible_technical_logs():
    logs = {(PACK, "g1_check"): "RAW_TECHNICAL_DETAILS\n\nexit 1"}
    with _page(_flow(other_blockers=True), output=logs) as (at, case):
        visible = list(_visible_nodes(at.main))
        buttons = [e for e in visible if e.type == "button"]
        assert at.button(key="flow_check").label == "Check status"
        assert [b.key for b in buttons if str(b.key).startswith("flow_resolve")] == ["flow_resolve"]
        assert not any(b.label.startswith(("Run:", "Write:")) for b in at.button)
        assert not [e for e in visible if e.type in ("code", "metric")]
        assert not any("RAW_TECHNICAL_DETAILS" in str(getattr(e, "value", "")) for e in visible)
        assert _button(at, "flow_resolve_1") is not None  # accessible in collapsed secondary blockers
        case.run_action.assert_not_called()


def test_check_status_evaluates_again_and_recovers_after_an_evaluation_failure():
    with _page(checked=False) as (at, case):
        case.evaluate.side_effect = OSError("Temporary status worker failure")
        at.button(key="flow_check").click().run()
        _healthy(at)
        assert at.error
        assert case.evaluate.call_count == 1
        case.evaluate.side_effect = None
        at.button(key="flow_check").click().run()
        _healthy(at)
        assert case.evaluate.call_count == 2
        assert _button(at, "flow_resolve") is not None
        case.run_action.assert_not_called()


def test_missing_workbook_focuses_the_person_step_and_blocks_downstream_writes():
    blocked = {"g1_digest", "g1_register_extraction", "g1_seal"}

    def guard(root, pack, action, **permissions):
        return "Provide the approved workbook before this step can run." if action["id"] in blocked else ""

    with _page(guard=guard) as (at, case):
        _open(at)
        assert at.selectbox(key="flow_resolution_action").value == "g1_workbook"
        run = _button(at, "flow_run_action")
        assert run is None or run.disabled
        text = " ".join(str(getattr(e, "value", "")) for e in _visible_ui(at))
        assert "workbook" in text.lower()
        for aid in sorted(blocked):
            _choose(at, aid)
            run = _button(at, "flow_run_action")
            assert run is None or run.disabled, f"{aid} must wait for the workbook."
        case.run_action.assert_not_called()


def test_read_action_after_the_third_option_remains_reachable_in_the_dialog():
    acts = _actions()
    ordered = [acts[1], acts[2], acts[3], acts[0], acts[4]]
    with _page(_flow(ordered), guard=lambda *args, **kwargs: "") as (at, case):
        _open(at)
        _choose(at, "g1_check")
        assert not at.button(key="flow_run_action").disabled
        at.button(key="flow_run_action").click().run()
        _healthy(at)
        assert case.run_action.call_count == 1
        assert case.evaluate.call_count >= 1


def test_viewer_can_recheck_but_cannot_execute_a_write_from_a_cached_flow():
    with _page(can_write=False) as (at, case):
        assert not at.button(key="flow_check").disabled
        _open(at)
        _choose(at, "g1_digest")
        run = _button(at, "flow_run_action")
        assert run is None or run.disabled
        case.run_action.assert_not_called()


def test_changed_prerequisite_is_checked_again_before_executing_a_stale_button():
    import flow_guidance
    with _page(guard=lambda *args, **kwargs: "") as (at, case):
        _open(at)
        _choose(at, "g1_digest")
        assert not at.button(key="flow_run_action").disabled
        # The action is still eligible when the button renders, then the evidence
        # changes before execution in the same request. A render-only guard misses this.
        with patch.object(flow_guidance, "action_guard", side_effect=[
            "", "The workbook changed. Review it before recording a fingerprint.",
        ]) as guarded:
            at.button(key="flow_run_action").click().run()
        _healthy(at)
        assert guarded.call_count == 2
        case.run_action.assert_not_called()


def test_failed_action_is_not_reported_as_success_and_raw_output_stays_collapsed():
    with _page(guard=lambda *args, **kwargs: "") as (at, case):
        _open(at)
        _choose(at, "g1_check")
        case.run_action.return_value = "REFUSED: RAW_FAILED_ACTION_OUTPUT\n\nexit 1"
        at.button(key="flow_run_action").click().run()
        _healthy(at)
        assert not at.success
        assert at.selectbox(key="flow_resolution_action").value == "g1_check", "A failed optional step must remain selected so its error stays visible."
        assert at.error or at.warning
        assert case.run_action.call_count == 1
        visible = list(_visible_ui(at))
        assert not [e for e in visible if e.type == "code"]


def test_recheck_from_dialog_refreshes_the_current_blocker():
    with _page(guard=lambda *args, **kwargs: "") as (at, case):
        _open(at)
        refreshed = _flow()
        refreshed["blockers"][0]["text"] = "The workbook is registered; scientific review is pending."
        case.evaluate.return_value = refreshed
        at.button(key="flow_recheck").click().run()
        _healthy(at)
        assert case.evaluate.call_count == 1
        assert at.session_state["flow_result"][PACK]["blockers"][0]["text"] == refreshed["blockers"][0]["text"]
        case.run_action.assert_not_called()


def test_dialog_cannot_execute_after_the_actor_changes():
    with _page(guard=lambda *args, **kwargs: "") as (at, case):
        _open(at)
        _choose(at, "g1_digest")
        case.actor = "Another scientist"
        at.button(key="flow_run_action").click().run()
        _healthy(at)
        case.run_action.assert_not_called()
        assert not any(d.proto.dialog.is_open for d in at.get("dialog"))


def test_repeated_gate_menus_do_not_create_repeated_resolution_cards_or_actions():
    result = _flow(other_blockers=True)
    result["blockers"].insert(1, copy.deepcopy(result["blockers"][0]))
    result["blockers"][0]["fixes"].append(copy.deepcopy(result["blockers"][0]["fixes"][0]))
    with _page(result, guard=lambda *args, **kwargs: "") as (at, case):
        keys = [b.key for b in at.button if str(b.key).startswith("flow_resolve")]
        assert keys == ["flow_resolve", "flow_resolve_1"]
        _open(at)
        options = at.selectbox(key="flow_resolution_action").options
        assert len(options) == len(set(options)) == len(_actions())
        case.run_action.assert_not_called()


def test_real_missing_source_guard_disables_digest_extraction_and_seal_in_dialog():
    """A GIST-like pending register, on a disposable root, exercises the real guard."""
    with tempfile.TemporaryDirectory(prefix="epi-flow-source-") as td:
        product = Path(td) / PACK
        product.mkdir(parents=True)
        (product / "source_refs.yaml").write_text(json.dumps({"source_materials": [
            {"material_id": "program_spec", "material_type": "program_spec", "path_or_link": "TBD",
             "sha256": "TBD", "status": "pending"},
        ]}), encoding="utf-8")
        with _page(root=td) as (at, case):
            _open(at)
            for aid in ("g1_digest", "g1_register_extraction", "g1_seal"):
                _choose(at, aid)
                assert at.button(key="flow_run_action").disabled, f"{aid} cannot run before the source exists."
            case.run_action.assert_not_called()


def _review_actions():
    review = _action("g1_review", "person", "Review the program specification")
    commit = _action("g1_commit", "person", "Record the named reviewer's decision")
    return _actions() + [review, commit]


def test_attaching_workbook_moves_the_dialog_to_recording_its_fingerprint():
    with _page(_flow(_review_actions()), guard=lambda *args, **kwargs: "") as (at, case):
        _open(at)
        assert at.selectbox(key="flow_resolution_action").value == "g1_workbook"
        attached = _flow([a for a in _review_actions() if a["id"] != "g1_workbook"])
        attached["blockers"][0]["text"] = "The workbook is attached; identify the document version."
        case.evaluate.return_value = attached
        at.button(key="flow_recheck").click().run()
        _healthy(at)
        _open(at)
        assert at.selectbox(key="flow_resolution_action").value == "g1_digest"
        assert not at.button(key="flow_run_action").disabled
        case.run_action.assert_not_called()


def test_recording_fingerprint_moves_the_dialog_to_scientific_review():
    attached = [a for a in _review_actions() if a["id"] != "g1_workbook"]
    with _page(_flow(attached), guard=lambda *args, **kwargs: "") as (at, case):
        _open(at)
        assert at.selectbox(key="flow_resolution_action").value == "g1_digest"
        recorded = _flow([a for a in attached if a["id"] != "g1_digest"])
        recorded["blockers"][0]["text"] = "The identified workbook is awaiting scientific review."
        case.evaluate.return_value = recorded
        at.button(key="flow_run_action").click().run()
        _healthy(at)
        assert case.run_action.call_count == 1
        _open(at)
        assert at.selectbox(key="flow_resolution_action").value == "g1_review"
        run = _button(at, "flow_run_action")
        assert run is None or run.disabled, "Recording a checksum cannot perform the scientific review."


def test_explicit_commit_route_is_preserved_over_generic_preparation_tasks():
    actions = _review_actions()
    commit = next(a for a in actions if a["id"] == "g1_commit")
    targeted = [commit] + [a for a in actions if a["id"] != "g1_commit"]
    result = _flow(targeted)
    result["blockers"][0]["text"] = "The recorded classification is not authenticated."
    with _page(result, guard=lambda *args, **kwargs: "") as (at, case):
        _open(at)
        assert at.session_state["flow_resolution_action"] == "g1_commit"
        assert not any(s.key == "flow_resolution_action" for s in at.selectbox)
        run = _button(at, "flow_run_action")
        assert run is None or run.disabled
        case.run_action.assert_not_called()


def test_actual_portal_pack_switch_cannot_execute_an_old_dialog_action():
    from test_epi_portal_journeys import _portal, _flow_with_actions, _command
    with _portal() as at:
        old = at.selectbox(key="pack").value
        target = "fixtures/oncology/oc/202606" if old != "fixtures/oncology/oc/202606" else "fixtures/oncology/prostate/202606"
        at.session_state["flow_result"] = {old: _flow_with_actions(), target: _flow_with_actions()}
        at.radio(key="section").set_value("Flow").run()
        _healthy(at)
        _open(at)
        _choose(at, "g1_check")
        assert not at.button(key="flow_run_action").disabled
        # Submit a stale dialog click alongside the new product selection. It must
        # never run the old action against either the old or the newly selected product.
        at.selectbox(key="pack").set_value(target)
        with _command("source_manifest.py", (0, "This stale action must not run")) as calls:
            at.button(key="flow_run_action").click().run()
        _healthy(at)
        assert not calls
        assert at.selectbox(key="pack").value == target
        assert not any(d.proto.dialog.is_open for d in at.get("dialog"))


def test_all_clear_offers_release_handoff_review_without_claiming_a_new_missing_signature():
    result = _flow()
    result.update(clear=True, current=None, blockers=[], proceed="All six checks pass.")
    for gate in result["gates"]:
        gate.update(state="done", blockers=[])
    result["closing"] = [
        _action("g6_countersign", "person", "Sign the recorded release review"),
        _action("g6_commit", "person", "Record the release decision"),
        _action("g6_receipt", "read", "Check the release receipt", ["platform/tools/source_manifest.py", "--check-receipts"]),
    ]
    with _page(result, guard=lambda *args, **kwargs: "") as (at, case):
        assert at.success
        text = " ".join(str(getattr(e, "value", "")) for e in _visible_nodes(at.main)).lower()
        assert "release handoff" in text
        assert "missing signature" not in text and "not authenticated" not in text
        assert at.button(key="flow_resolve").label == "Review handoff"
        _open(at)
        run = _button(at, "flow_run_action")
        assert run is None or run.disabled
        case.run_action.assert_not_called()


def test_already_recorded_checksum_is_informational_and_recheck_moves_to_review():
    with tempfile.TemporaryDirectory(prefix="epi-complete-checksum-") as td:
        product = Path(td) / PACK
        product.mkdir(parents=True)
        workbook = b"An exact workbook version; this test never parses or executes it."
        (product / "spec.xlsx").write_bytes(workbook)
        (product / "source_refs.yaml").write_text(json.dumps({"source_materials": [
            {"material_id": "program_spec", "material_type": "program_spec", "path_or_link": "spec.xlsx",
             "sha256": hashlib.sha256(workbook).hexdigest(), "status": "pending"},
        ]}), encoding="utf-8")
        actions = [a for a in _review_actions() if a["id"] != "g1_workbook"]
        with _page(_flow(actions), root=td) as (at, case):
            _open(at)
            assert at.selectbox(key="flow_resolution_action").value == "g1_digest"
            assert at.button(key="flow_run_action").disabled
            assert not at.error
            assert any("already complete" in message.value.lower() for message in at.success)
            case.evaluate.return_value = _flow([a for a in actions if a["id"] != "g1_digest"])
            at.button(key="flow_recheck").click().run()
            _healthy(at)
            _open(at)
            assert at.selectbox(key="flow_resolution_action").value == "g1_review"
            assert not at.error
            case.run_action.assert_not_called()


@contextlib.contextmanager
def _review_record(**fields):
    """Review fixtures exist only in a temporary checkout; never change a user pack."""
    with tempfile.TemporaryDirectory(prefix="epi-review-details-") as td:
        product = Path(td) / PACK
        product.mkdir(parents=True)
        record = {"material_id": "program_spec", "material_type": "program_spec",
                  "status": "pending", "path_or_link": "TBD", "sha256": "TBD", **fields}
        path = product / "source_refs.yaml"
        path.write_text(yaml.safe_dump({"product": "gist", "spec_version": "202608",
                                        "source_materials": [record]}, sort_keys=False), encoding="utf-8")
        yield td, path


def _review_flow(*, extract=False):
    actions = [_action("g1_review", "person", "Review the program specification")]
    if extract:
        actions.append(_action("g1_extract", "write", "Prepare the specification extraction",
                               ["platform/tools/run_spec_pipeline.py", PACK]))
    result = _flow(actions)
    result["blockers"][0]["text"] = "program_spec requires document_id and completed scientific review details."
    return result


def test_review_dialog_lists_all_six_missing_details_without_filling_a_review():
    with _review_record() as (td, path), _page(_review_flow(), root=td) as (at, case):
        before = path.read_bytes()
        _open_details(at)
        table = next(df.value for df in at.dataframe if "Record as" in df.value.columns)
        assert set(table["Record as"]) == {"document_id", "revision", "approved_by", "approval_date",
                                           "data_refresh", "rwb_qc_reference"}
        assert any("pending" in c.value.lower() for c in at.caption)
        run = _button(at, "flow_run_action")
        assert run is None or run.disabled
        assert not at.success
        assert path.read_bytes() == before
        case.run_action.assert_not_called()


def test_review_dialog_explains_unsupported_approved_status_without_treating_it_as_approval():
    with _review_record(status="approved") as (td, path), _page(_review_flow(), root=td) as (at, case):
        before = path.read_bytes()
        _open_details(at)
        assert any("approved" in msg.value and "not a supported value" in msg.value for msg in at.warning)
        assert not at.success
        assert path.read_bytes() == before
        assert yaml.safe_load(path.read_text(encoding="utf-8"))["source_materials"][0]["status"] == "approved"
        case.run_action.assert_not_called()


def test_prepare_draft_extraction_shortcut_selects_a_separate_step_without_reviewing_source():
    with _review_record() as (td, path), _page(_review_flow(extract=True), root=td,
                                             guard=lambda *args, **kwargs: "") as (at, case):
        before = path.read_bytes()
        _open(at)
        assert at.selectbox(key="flow_resolution_action").value == "g1_review"
        at.button(key="flow_prepare_draft").click().run()
        _healthy(at)
        assert at.selectbox(key="flow_resolution_action").value == "g1_extract"
        case.run_action.assert_not_called()
        assert not at.button(key="flow_run_action").disabled
        at.button(key="flow_run_action").click().run()
        _healthy(at)
        assert case.run_action.call_count == 1
        assert path.read_bytes() == before
        _open(at)
        assert {f"source_review_{field}" for field in ("document_id", "revision", "data_refresh",
                                                       "rwb_qc_reference", "approved_by", "approval_date")} <= {t.key for t in at.text_input}
        assert not at.success


def test_read_only_reviewer_cannot_prepare_an_extraction_from_the_review_shortcut():
    with _review_record() as (td, path), _page(_review_flow(extract=True), root=td, can_write=False) as (at, case):
        before = path.read_bytes()
        _open(at)
        assert _button(at, "flow_prepare_draft") is None
        assert path.read_bytes() == before
        case.run_action.assert_not_called()


def test_actual_missing_document_id_route_opens_review_instead_of_commit_instructions():
    import flow

    with _review_record(status="reviewed") as (td, path):
        menu = flow.acts(PACK, td)[1]
        text = f"{PACK}: source_materials[0]: status:reviewed requires `document_id`"
        routed = flow._first_for(text, menu)
        assert routed[0]["id"] == "g1_review"
        result = _flow(routed)
        result["blockers"][0]["text"] = text
        with _page(result, root=td) as (at, case):
            _open(at)
            assert at.selectbox(key="flow_resolution_action").value == "g1_review"
            assert at.text_input(key="source_review_document_id").value == ""
            assert not at.success
            case.run_action.assert_not_called()


def _save_details(at):
    next(button for button in at.button if button.label == "Save specification details").click().run()
    _healthy(at)


def test_generate_document_id_saves_once_and_reopens_without_touching_review_or_other_metadata():
    protected = {"approved_by": "TBD", "approval_date": "TBD", "status": "pending",
                 "classified_by": "Existing classifier", "classified_date": "2026-08-01",
                 "ai_classification": "sponsor_readable", "why_provisional": "Review still required",
                 "object_uuid": "ef6ffbd4-e2e3-4bf0-8cdf-de01fb3fb6c3"}
    with _review_record(**protected) as (td, path), _page(_review_flow(), root=td) as (at, case):
        initial = yaml.safe_load(path.read_text(encoding="utf-8"))
        _open_details(at)
        at.text_input(key="spec_details_revision").set_value("Unsaved revision draft").run()
        at.button(key="spec_details_generate").click().run()
        _healthy(at)
        generated = at.text_input(key="spec_details_document_id").value
        assert generated.startswith("SPEC-")
        assert at.text_input(key="spec_details_revision").value == "Unsaved revision draft"
        after = yaml.safe_load(path.read_text(encoding="utf-8"))
        expected = copy.deepcopy(initial)
        expected["source_materials"][0]["document_id"] = generated
        assert after == expected
        assert case.evaluate.call_count == 1
        case.run_action.assert_not_called()
        at.button(key="flow_close").click().run()
        _open_details(at)
        assert at.text_input(key="spec_details_document_id").value == generated
        assert _button(at, "spec_details_generate") is None
        assert yaml.safe_load(path.read_text(encoding="utf-8")) == expected


def test_saving_specification_details_updates_only_four_fields_and_leaves_review_missing():
    with _review_record(why_provisional="Needs the named reviewer's decision", ai_classification="sponsor_readable") as (td, path), \
            _page(_review_flow(), root=td) as (at, case):
        initial = yaml.safe_load(path.read_text(encoding="utf-8"))
        _open_details(at)
        changes = {"document_id": "GIST-PROTOCOL-202608", "revision": "2",
                   "data_refresh": "Delivery 2026-08", "rwb_qc_reference": "QC-GIST-2026-082"}
        for field, value in changes.items():
            at.text_input(key=f"spec_details_{field}").set_value(value)
        _save_details(at)
        expected = copy.deepcopy(initial)
        expected["source_materials"][0].update(changes)
        assert yaml.safe_load(path.read_text(encoding="utf-8")) == expected
        remaining = next(df.value for df in at.dataframe if "Record as" in df.value.columns)
        assert set(remaining["Record as"]) == {"approved_by", "approval_date"}
        assert any("separate requirements" in msg.value for msg in at.success)
        assert case.evaluate.call_count == 1
        case.run_action.assert_not_called()


def test_stale_specification_save_refuses_overwrite_and_keeps_typed_values_until_explicit_reload():
    with _review_record(revision="1") as (td, path), _page(_review_flow(), root=td) as (at, case):
        _open_details(at)
        at.text_input(key="spec_details_revision").set_value("2")
        concurrent = yaml.safe_load(path.read_text(encoding="utf-8"))
        concurrent["source_materials"][0]["revision"] = "3 - independently updated"
        path.write_text(yaml.safe_dump(concurrent, sort_keys=False), encoding="utf-8")
        expected = path.read_bytes()
        _save_details(at)
        assert any("changed while this form was open" in msg.value for msg in at.error)
        assert at.text_input(key="spec_details_revision").value == "2"
        assert path.read_bytes() == expected
        case.evaluate.assert_not_called()
        at.button(key="spec_details_reload").click().run()
        _healthy(at)
        assert at.text_input(key="spec_details_revision").value == "3 - independently updated"
        assert path.read_bytes() == expected


def test_metadata_buttons_refuse_viewer_and_hosted_writes_and_actor_switch_discards_old_edit():
    for can_write, local_demo in ((False, True), (True, False)):
        with _review_record() as (td, path), _page(_review_flow(), root=td, can_write=can_write) as (at, case):
            case.local_demo = local_demo
            _open_details(at)
            before = path.read_bytes()
            assert at.button(key="spec_details_generate").disabled
            assert next(b for b in at.button if b.label == "Save specification details").disabled
            assert all(t.disabled for t in at.text_input if str(t.key).startswith("spec_details_"))
            assert path.read_bytes() == before
    with _review_record() as (td, path), _page(_review_flow(), root=td) as (at, case):
        before = path.read_bytes()
        _open_details(at)
        at.text_input(key="spec_details_revision").set_value("Priya's private unsaved revision")
        case.actor = "Another scientist"
        _save_details(at)
        assert not any(d.proto.dialog.is_open for d in at.get("dialog"))
        assert path.read_bytes() == before
        _open_details(at)
        assert at.text_input(key="spec_details_revision").value == ""
        case.evaluate.assert_not_called()


def test_unchanged_metadata_save_is_informational_and_does_not_refresh_gates():
    with _review_record(document_id="SPEC-EXISTING", revision="2", data_refresh="2026-08") as (td, path), \
            _page(_review_flow(), root=td) as (at, case):
        before = path.read_bytes()
        _open_details(at)
        _save_details(at)
        assert any("No changes to save" in msg.value for msg in at.info)
        assert not at.success
        assert path.read_bytes() == before
        case.evaluate.assert_not_called()
        case.run_action.assert_not_called()


def test_cached_legacy_commit_only_blocker_opens_missing_document_details_without_a_gate_claim():
    with _review_record(status="reviewed") as (td, path):
        legacy = _flow([_action("g1_commit", "person", "Commit the reviewer's decision")])
        legacy["blockers"][0]["text"] = f"{PACK}: source_materials[0]: status:reviewed requires `document_id`"
        with _page(legacy, root=td, can_review=True) as (at, case):
            before = path.read_bytes()
            _open(at)
            assert at.text_input(key="source_review_document_id").value == ""
            assert not at.button(key="source_review_generate_id").disabled
            assert not at.success
            assert path.read_bytes() == before
            case.evaluate.assert_not_called()
            case.run_action.assert_not_called()


def test_completed_source_details_can_be_reopened_and_corrected_from_an_authentication_blocker():
    with _review_record(status="reviewed", document_id="SPEC-EXISTING", revision="1", data_refresh="2026-08",
                        rwb_qc_reference="QC-ORIGINAL", approved_by="Alice Smith", approval_date="2026-09-01") as (td, path):
        result = _flow([_action("g1_commit", "person", "Authenticate the source classification")])
        result["blockers"][0]["text"] = "classified_by=Alice Smith is not authenticated"
        with _page(result, root=td) as (at, case):
            initial = yaml.safe_load(path.read_text(encoding="utf-8"))
            assert "flow_edit_specification" not in {getattr(e, "key", None) for e in _visible_nodes(at.main)}
            at.button(key="flow_edit_specification").click().run()
            _healthy(at)
            assert at.text_input(key="spec_details_document_id").value == "SPEC-EXISTING"
            assert at.text_input(key="spec_details_revision").value == "1"
            at.text_input(key="spec_details_revision").set_value("2")
            at.text_input(key="spec_details_rwb_qc_reference").set_value("QC-CORRECTED")
            _save_details(at)
            expected = copy.deepcopy(initial)
            expected["source_materials"][0].update(revision="2", rwb_qc_reference="QC-CORRECTED")
            assert yaml.safe_load(path.read_text(encoding="utf-8")) == expected
            assert not at.session_state["flow_result"][PACK]["clear"]
            assert "is not authenticated" in at.session_state["flow_result"][PACK]["blockers"][0]["text"]
            at.button(key="flow_close").click().run()
            at.button(key="flow_edit_specification").click().run()
            _healthy(at)
            assert at.text_input(key="spec_details_revision").value == "2"
            assert at.text_input(key="spec_details_rwb_qc_reference").value == "QC-CORRECTED"
            case.run_action.assert_not_called()


def test_read_only_actor_can_inspect_completed_specification_details_without_editing_them():
    with _review_record(status="reviewed", document_id="SPEC-EXISTING", revision="1") as (td, path), \
            _page(_flow([_action("g1_commit", "person", "Record source history")]), root=td, can_write=False) as (at, case):
        before = path.read_bytes()
        at.button(key="flow_edit_specification").click().run()
        _healthy(at)
        assert at.text_input(key="spec_details_document_id").value == "SPEC-EXISTING"
        assert all(t.disabled for t in at.text_input if str(t.key).startswith("spec_details_"))
        assert at.button(key="spec_details_save").disabled
        assert path.read_bytes() == before
        case.evaluate.assert_not_called()
        case.run_action.assert_not_called()


def test_cached_ledger_blocker_routes_to_recording_the_source_event_instead_of_commit():
    actions = [_action("g1_commit", "person", "Record source history"),
               _action("g1_seal", "write", "Record source lifecycle event",
                       ["platform/tools/source_manifest.py", PACK, "--record-event", "program_spec"])]
    result = _flow(actions)
    result["blockers"][0]["text"] = "program_spec moved past its ledger event after metadata changed"
    with _review_record(status="reviewed") as (td, path), _page(result, root=td) as (at, case):
        before = path.read_bytes()
        _open(at)
        assert at.selectbox(key="flow_resolution_action").value == "g1_seal"
        assert at.button(key="flow_run_action").disabled  # no supplied workbook in this source fixture
        assert path.read_bytes() == before
        case.run_action.assert_not_called()


@contextlib.contextmanager
def _recorded_review(**fields):
    """A complete review, recorded and not yet signed, over a workbook whose checksum matches: the
    state the walk UC1-05 left after a wrong reviewer name was saved. Disposable root only."""
    with tempfile.TemporaryDirectory(prefix="epi-recorded-review-") as td:
        product = Path(td) / PACK
        product.mkdir(parents=True)
        workbook = b"An exact workbook version; this test never parses or executes it."
        (product / "spec.xlsx").write_bytes(workbook)
        record = {"material_id": "program_spec", "material_type": "program_spec", "status": "reviewed",
                  "path_or_link": "spec.xlsx", "sha256": hashlib.sha256(workbook).hexdigest(),
                  "document_id": "SPEC-EXISTING", "revision": "1", "data_refresh": "2026-08", "rwb_qc_reference": "QC-1",
                  "approved_by": "Alice Smith", "approval_date": "2026-09-01",
                  "ai_classification": "sponsor_ai_eligible", "classified_by": "Bob Jones", "classified_date": "2026-08-30", **fields}
        path = product / "source_refs.yaml"
        path.write_text(yaml.safe_dump({"product": "gist", "spec_version": "202608", "source_materials": [record]},
                                       sort_keys=False), encoding="utf-8")
        yield td, path


def _unsigned_result(td, who="Alice Smith"):
    """The flow's own card for a recorded review nobody has signed: the commit first, the review behind it."""
    import flow
    text = f"Gate 1: {PACK}/source_refs.yaml: approved_by={who} is not authenticated — no commit's diff wrote this approval"
    result = _flow(flow._first_for(text, flow.acts(PACK, td)[1]))
    result["blockers"][0]["text"] = text
    return result


def test_a_recorded_review_can_be_corrected_from_the_commit_step_until_it_is_signed():
    """Walk UC1-05: a wrong reviewer name was saved and the page offered only the commit step."""
    import flow
    with _recorded_review() as (td, path):
        review = next(a for a in flow.acts(PACK, td)[1] if a["id"] == "g1_review")
        assert review.get("recorded") is True and "until it is signed" in review["note"], review
        assert not any(a["id"] == "g1_review" for a in flow.acts(PACK, td, signed=True)[1]), "signed: the correction is withheld"
        with _page(_unsigned_result(td), root=td, can_review=True) as (at, case):
            _open(at)
            assert at.session_state["flow_resolution_action"] == "g1_commit"
            assert not any(s.key == "flow_resolution_action" for s in at.selectbox), "the reviewer page keeps its focus"
            assert at.button(key="flow_correct_review").label == "Correct the recorded review"
            at.button(key="flow_correct_review").click().run()
            _healthy(at)
            assert at.session_state["flow_resolution_action"] == "g1_review"
            assert at.text_input(key="source_review_approved_by").value == "Alice Smith"
            assert any("until it is signed" in s.value for s in at.markdown), "the guidance says the record can still be corrected"
            at.text_input(key="source_review_approved_by").set_value("Alice Smyth").run()
            _healthy(at)
            at.checkbox(key="source_review_confirm_review").set_value(True)
            at.button(key="source_review_save").click().run()
            _healthy(at)
            assert any("Decision recorded" in s.value for s in at.success), ([e.value for e in at.error], [w.value for w in at.warning])
            saved = yaml.safe_load(path.read_text(encoding="utf-8"))["source_materials"][0]
            assert saved["approved_by"] == "Alice Smyth" and saved["status"] == "reviewed" and saved["approval_date"] == "2026-09-01"
            assert not any("This item has changed" in i.value for i in at.info)
            assert any(d.proto.dialog.is_open for d in at.get("dialog")), "the form stays open on the same card"
            assert case.evaluate.call_count == 1
            case.run_action.assert_not_called()


def test_saving_the_review_keeps_the_dialog_on_the_card_that_now_carries_its_commit():
    """Walk UC1-05: the first act of the card moves from the review to its commit once the review is
    recorded, and the person saw "This item has changed" instead of the form they had just used."""
    import flow
    with _recorded_review(approved_by="TBD", approval_date="TBD") as (td, path):
        menu = flow.acts(PACK, td)[1]
        assert not next(a for a in menu if a["id"] == "g1_review").get("recorded"), "an incomplete review is the first review act"
        text = f"{PACK}: source_materials[0]: status:reviewed requires `approved_by`"
        first = _flow(flow._first_for(text, menu))
        first["blockers"][0]["text"] = text
        with _page(first, root=td, can_review=True) as (at, case):
            _open(at)
            assert at.session_state["flow_dialog"]["card_key"] == "g1_review"
            at.text_input(key="source_review_approved_by").set_value("Alice Smith").run()
            at.text_input(key="source_review_approval_date").set_value("2026-09-01").run()
            _healthy(at)
            case.evaluate.side_effect = lambda: _unsigned_result(td)
            at.checkbox(key="source_review_confirm_review").set_value(True)
            at.button(key="source_review_save").click().run()
            _healthy(at)
            assert any("Decision recorded" in s.value for s in at.success), ([e.value for e in at.error], [w.value for w in at.warning])
            assert case.evaluate.call_count == 1
            # the person's next interaction: the card the dialog was opened with is gone (its first
            # act is the commit now), and the dialog follows the act instead of ending
            at.run()
            _healthy(at)
            assert not any("This item has changed" in i.value for i in at.info)
            assert any(d.proto.dialog.is_open for d in at.get("dialog"))
            assert at.session_state["flow_dialog"]["card_key"] == "g1_commit"
            assert at.session_state["flow_resolution_action"] == "g1_review"
            assert at.text_input(key="source_review_approved_by").value == "Alice Smith"
            assert case.evaluate.call_count == 1
            case.run_action.assert_not_called()


def test_edit_specification_details_offers_the_review_form_while_the_record_is_unsigned():
    with _recorded_review() as (td, path):
        before = path.read_bytes()
        with _page(_unsigned_result(td), root=td, can_review=True) as (at, case):
            _open_details(at)
            assert at.text_input(key="spec_details_document_id").value == "SPEC-EXISTING"
            assert at.button(key="flow_correct_review").label == "Correct the recorded review"
            at.button(key="flow_correct_review").click().run()
            _healthy(at)
            assert at.session_state["flow_resolution_action"] == "g1_review"
            assert at.text_input(key="source_review_approved_by").value == "Alice Smith"
            assert path.read_bytes() == before
            case.run_action.assert_not_called()


if __name__ == "__main__":
    failed = 0
    for name, fn in sorted(list(globals().items())):
        if name.startswith("test_") and callable(fn):
            try:
                fn()
                print(f"  ok   {name}", flush=True)
            except Exception:
                failed += 1
                print(f"  FAIL {name}", flush=True)
                traceback.print_exc()
    print(f"{failed} failure(s)")
    sys.exit(1 if failed else 0)
