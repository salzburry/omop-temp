"""Current failed workflow actions outrank an older descriptive study interview."""
import copy
import json
from pathlib import Path
import sys

import pytest

ROOT = Path(__file__).resolve().parents[2]
sys.path[:0] = [str(ROOT / folder) for folder in
               ("platform/tests", "experiments/portal", "experiments/agent", "platform/tools")]
import conversation_intake as briefs
import flow_assistant as fa
import scientific_conversation_context as evidence
import workflow_skills
from test_epi_flow_assistant import _card

PACK = "products/oncology/synthetic/202609"
OTHER = "products/oncology/other/202609"
ACTOR = "synthetic-scientist"
DIGEST = "a" * 64
UNCLASSIFIED = "Unclassified sheet '9.PROC PSOC Strategy': choose its specification domain or record its exclusion."
HEADER = "Sheet '2.DEMO' is mapped to demographics but the required variable column header was not found."
OLD_QUESTION = "Old index interview sentinel: should index mean first treatment or first diagnosis?"


def blocked_card(message=UNCLASSIFIED, *, status="blocked"):
    card = _card()
    card["current_task"] = {"route": "scientific_draft", "title": "Write a definition"}
    card["workflow_feedback"] = {
        "status": status, "action_id": "g1_extract", "title": "Prepare the specification extraction",
        "blockers": [message] if status == "blocked" else [], "input_digest": DIGEST,
        "blockers_omitted": 0,
    }
    card["editable_form"] = {"scope": "old-definition-form", "fields": [
        {"id": "scientific-rule", "label": "Scientific interpretation", "type": "text_area",
         "current": "", "choices": None}]}
    return card


@pytest.fixture
def pending_brief(tmp_path, monkeypatch):
    monkeypatch.delenv("RWDP_STATE_DIR", raising=False)
    (tmp_path / PACK).mkdir(parents=True)
    draft = briefs.new(tmp_path, PACK, ACTOR, allowed_packs=[PACK], connection="scripted", source="source-a")
    draft = briefs.edit(draft, {"population": "Older renal population sentinel"})
    pending = {"id": "index_definition", "prompt": OLD_QUESTION, "allow_text": True,
               "options": [{"id": "a", "label": "First diagnosis", "explanation": "Requires a diagnosis date."},
                           {"id": "b", "label": "First treatment", "explanation": "Requires a treatment date."}]}
    return briefs.apply_reply(draft, {"questions": [pending]}, user_text="Help define the study")


@pytest.fixture
def connected(monkeypatch):
    seen = {"skills": [], "retrieval": [], "model": []}

    def skills(root, task, **kwargs):
        seen["skills"].append(task)
        name = workflow_skills.binding_for(task)["name"]
        return {"ok": True, "prompt": "Use the current workflow checks and available actions.",
                "digest": "b" * 64,
                "skills": [{"name": name, "version": "1", "sha256": "c" * 64, "coverage": "full"}]}

    def knowledge(**kwargs):
        seen["retrieval"].append(kwargs)
        return {"sources": [], "digest": "d" * 64}

    monkeypatch.setattr(workflow_skills, "context_for", skills)
    monkeypatch.setattr(workflow_skills, "freshness", lambda *_args, **_kwargs: {"ok": True})
    monkeypatch.setattr(evidence, "build_chat", knowledge)

    class Model:
        def __init__(self, payload=None):
            self.payload = payload if payload is not None else {
                "answer": "Resolve the unclassified worksheet in the extraction step, then check again.",
                "actions": ["open_step"], "workflow_reference": DIGEST}

        def step(self, system, messages):
            seen["model"].append({"system": system, "prompt": json.loads(messages[0]["content"])})
            return json.dumps(self.payload)

    return seen, Model


def call(card, model, **kwargs):
    return fa.answer("What about this?", card, root=ROOT, model=model,
                     actor_id=ACTOR, allowed_packs=[PACK], task_scope={"pack": PACK}, **kwargs)


def test_current_extraction_failure_suppresses_stale_interview_but_preserves_saved_draft_and_current_history(connected, pending_brief):
    seen, Model = connected
    card = blocked_card()
    before_card, before_brief = copy.deepcopy(card), copy.deepcopy(pending_brief)
    current_turn = {"question": "Which worksheet could not be classified?", "answer": UNCLASSIFIED,
                    "context_reference": fa.history_reference(card, task_scope={"pack": PACK})}
    history = [{"question": OLD_QUESTION, "answer": "Pick option A or B."}, current_turn]
    result = call(card, Model(), history=history, study_brief=pending_brief,
                  resolved_question={"id": "index_definition", "value": "First treatment"})
    assert result["source"] == "assistant" and result["workflow_reference"] == DIGEST
    assert len(seen["model"]) == 1
    prompt = seen["model"][0]["prompt"]
    assert "study_brief" not in prompt and "editable_form" not in prompt["context"]
    assert OLD_QUESTION not in json.dumps(prompt) and "Older renal population sentinel" not in json.dumps(prompt)
    assert prompt["conversation"] == [{"question": current_turn["question"], "answer": UNCLASSIFIED}]
    assert prompt["context"]["current_task"]["route"] == "g1_extract"
    assert set(prompt["allowed_actions"]) <= {"open_step", "check_status", "open_handoffs"}
    assert seen["skills"] == ["progress"], "Extraction must not reuse the stale scientific-drafting skill."
    assert len(seen["retrieval"]) == 2
    for lookup in seen["retrieval"]:
        assert UNCLASSIFIED in lookup["query"] and OLD_QUESTION not in lookup["query"]
        assert "Older renal population sentinel" not in lookup["query"]
        assert lookup["pack"] == PACK
    assert card == before_card and pending_brief == before_brief


@pytest.mark.parametrize("reference", [None, "e" * 64, "a" * 63, 42])
def test_missing_or_wrong_workflow_reference_discards_reply_and_prefill(connected, reference):
    seen, Model = connected
    payload = {"answer": OLD_QUESTION, "actions": ["open_source_mapping"],
               "prefill": {"scope": "old-definition-form", "fields": [{"id": "scientific-rule", "value": "Old treatment index"}]}}
    if reference is not None:
        payload["workflow_reference"] = reference
    result = call(blocked_card(), Model(payload))
    assert len(seen["model"]) == 1 and result["source"] == "checks"
    assert result["workflow_reference"] == DIGEST and UNCLASSIFIED in result["answer"]
    assert OLD_QUESTION not in result["answer"] and "prefill" not in result and "questions" not in result
    assert "open_source_mapping" not in result["actions"]


def test_correct_reference_cannot_reopen_a_stale_scientific_mcq(connected, pending_brief):
    _seen, Model = connected
    stale_question = {"id": "index_definition", "prompt": OLD_QUESTION, "allow_text": True,
                      "options": [{"id": "a", "label": "Diagnosis", "explanation": "Earlier option."},
                                  {"id": "b", "label": "Treatment", "explanation": "Earlier option."}]}
    payload = {"answer": "Choose the index definition first.", "actions": [],
               "workflow_reference": DIGEST, "questions": [stale_question]}
    result = call(blocked_card(), Model(payload), study_brief=pending_brief)
    assert result["source"] == "checks" and UNCLASSIFIED in result["answer"]
    assert "questions" not in result and "brief_updates" not in result and "prefill" not in result


def test_sheet_error_never_exposes_or_accepts_an_invented_domain_mapping_field(connected):
    seen, Model = connected
    payload = {"answer": "Review the extraction issue before changing definitions.", "actions": ["open_source_mapping", "open_step"],
               "workflow_reference": DIGEST,
               "prefill": {"scope": "old-definition-form", "fields": [{"id": "sheet-domain", "value": "demographics"}]}}
    result = call(blocked_card(), Model(payload))
    assert result["source"] == "assistant" and result["actions"] == ["open_step"]
    assert "prefill" not in result and "editable_form" not in seen["model"][0]["prompt"]["context"]
    assert "existing entries were kept" in result["note"]


@pytest.mark.parametrize("message,expected,absent", [
    (UNCLASSIFIED, "domain or exclusion", "column headers"),
    (HEADER, "column headers", "domain or exclusion"),
])
def test_offline_guidance_distinguishes_sheet_classification_from_header_failures(message, expected, absent):
    result = fa.answer("Is this source mapping?", blocked_card(message))
    assert result["source"] == "checks" and message in result["answer"]
    assert expected in result["answer"] and absent not in result["answer"]
    assert set(result["actions"]) <= {"open_step", "check_status", "open_handoffs"}
    assert "open_source_mapping" not in result["actions"] and "prefill" not in result


def test_diagnostic_answers_preserve_distinct_literal_sheet_names(connected):
    message = "Sheet labels 'Lab  Results' and 'Lab Results' fold to ONE key."
    card = blocked_card(message)
    assert message in fa.answer("What does this mean?", card)["answer"]
    _seen, Model = connected
    reply = call(card, Model({"answer": message, "actions": [], "workflow_reference": DIGEST}))
    assert reply["source"] == "assistant" and reply["answer"] == message


def test_current_sheet_mapping_fields_are_available_while_unrelated_definition_fields_are_removed(connected):
    import specification_sheet_mapping as mapping
    seen, Model = connected
    card = blocked_card()
    card["editable_form"]["fields"].extend([
        {"id": "sheet-a", "label": mapping.SHEET_FIELD_PREFIX + "Laboratory results", "type": "selectbox",
         "current": "", "choices": [{"value": "clinical", "label": "clinical"}]},
        {"id": "sheet-b", "label": mapping.SHEET_FIELD_PREFIX + "Clinical assessments", "type": "selectbox",
         "current": "", "choices": [{"value": "clinical", "label": "clinical"}]},
        {"id": "reason", "label": mapping.REASON_FIELD, "type": "text_input", "current": "", "choices": None},
    ])
    result = call(card, Model({"answer": "Prepare both worksheets in Clinical, then preview the mapping.",
        "actions": ["open_step"], "workflow_reference": DIGEST,
        "prefill": {"scope": "old-definition-form", "fields": [{"id": "sheet-a", "value": "clinical"}, {"id": "sheet-b", "value": "clinical"}]}}))
    assert result["source"] == "assistant" and len(result["prefill"]["fields"]) == 2, result
    offered = seen["model"][0]["prompt"]["context"]["editable_form"]["fields"]
    assert {field["id"] for field in offered} == {"sheet-a", "sheet-b", "reason"}
    assert "Map workbook sheets" in fa.answer("How can I map these?", card)["answer"]


@pytest.mark.parametrize("change", ["action", "digest", "pack", "clear", "needs_recheck"])
def test_history_is_bound_to_current_action_inputs_product_and_check_status(change):
    card = blocked_card()
    scope = {"pack": PACK}
    history = [{"question": "Why is this worksheet blocked?", "answer": UNCLASSIFIED,
                "context_reference": fa.history_reference(card, task_scope=scope)}]
    if change == "action":
        card["workflow_feedback"]["action_id"] = "g2_draft"
    elif change == "digest":
        card["workflow_feedback"]["input_digest"] = "e" * 64
    elif change == "pack":
        scope = {"pack": OTHER}
    else:
        card["workflow_feedback"].update(status=change, blockers=[])
    assert fa.conversation_history(card, history, task_scope=scope) == []
    assert len(history) == 1 and history[0]["answer"] == UNCLASSIFIED


def test_clear_check_resumes_normal_questions_without_reusing_failed_action_history(connected, pending_brief):
    seen, Model = connected
    blocked = blocked_card()
    history = [{"question": "What is the worksheet failure?", "answer": UNCLASSIFIED,
                "context_reference": fa.history_reference(blocked, task_scope={"pack": PACK})}]
    clear = blocked_card(status="clear")
    assert fa.workflow_problem(clear) is None
    result = call(clear, Model({"answer": "Continue the saved study question.", "actions": []}),
                  history=history, study_brief=pending_brief)
    assert result["source"] == "assistant"
    prompt = seen["model"][0]["prompt"]
    assert "study_brief" in prompt and "conversation" not in prompt
    assert OLD_QUESTION in json.dumps(prompt["study_brief"])


def test_changed_inputs_require_recheck_and_keep_interview_paused(connected, pending_brief):
    seen, Model = connected
    card = blocked_card(status="needs_recheck")
    result = call(card, Model({"answer": "Old checks passed, continue the interview.", "actions": []}), study_brief=pending_brief)
    assert result["source"] == "checks" and "inputs changed" in result["answer"]
    assert "editing alone does not establish that it passed" in result["answer"]
    assert "check_status" in result["actions"] and "prefill" not in result and "questions" not in result
    assert "study_brief" not in seen["model"][0]["prompt"]
