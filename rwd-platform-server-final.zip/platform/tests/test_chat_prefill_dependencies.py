"""Parent-choice changes report the actual rendered child values accurately."""
from pathlib import Path
import sys

from streamlit.testing.v1 import AppTest

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "experiments/portal"))


def _app(*, duplicate_label=False):
    code = f'''import streamlit as st
import form_assistance as assistance
assistance.begin({str(ROOT)!r}, "", "Reviewer", page="Source mapping", allowed_packs=[], can_write=True)
assistance.review()
table = assistance.field(st.selectbox, "Table", ["A", "B"], key="table")
if {duplicate_label!r}:
    assistance.field(st.text_input, "Column", key="kept_column")
column = assistance.field(st.selectbox, "Column", ["id", "a"] if table == "A" else ["id", "b"], index=None, key="column")
st.session_state.setdefault("save_count", 0)
if st.button("Save source mapping", key="save_mapping"):
    st.session_state["save_count"] += 1
request = st.session_state.pop("test_propose", None)
if request:
    public = assistance.context()
    assistance.stage({{"scope": public["scope"], "fields": [
        {{"id": entry["id"], "value": value}}
        for entry, value in zip(public["fields"], request)]}})
assistance.finish()
'''
    return _healthy(AppTest.from_string(code, default_timeout=30).run())


def _healthy(at):
    assert not at.exception, [item.message for item in at.exception]
    assert at.session_state["save_count"] == 0
    return at


def _replace(at, values):
    at.session_state["test_propose"] = values
    _healthy(at.run())
    assert at.selectbox(key="table").value == "A"
    assert at.selectbox(key="column").value is None
    assert not at.success
    return _healthy(at.button(key="chat_form_replace").click().run())


def test_changing_table_retains_a_column_offered_by_both_tables():
    at = _replace(_app(), ["B", "id"])
    assert at.selectbox(key="table").value == "B"
    assert at.selectbox(key="column").value == "id"
    assert not at.warning
    assert any("Prepared draft fields: Table, Column." in item.value for item in at.success)


def test_old_table_column_resets_and_is_not_announced_as_prepared():
    at = _replace(_app(), ["B", "a"])
    assert at.selectbox(key="table").value == "B"
    assert at.selectbox(key="column").value is None
    assert not at.success
    notice = next(item.value for item in at.warning if "after the form updated" in item.value)
    assert "Prepared draft fields: Table." in notice
    assert "another choice after the form updated: Column." in notice
    assert "Prepared draft fields: Table, Column" not in notice


def test_a_kept_field_with_the_same_label_does_not_hide_a_reset_child():
    at = _replace(_app(duplicate_label=True), ["B", "id", "a"])
    assert at.selectbox(key="table").value == "B"
    assert at.text_input(key="kept_column").value == "id"
    assert at.selectbox(key="column").value is None
    assert not at.success
    assert any("another choice after the form updated: Column." in item.value for item in at.warning)
