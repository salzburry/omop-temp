"""Disposable source-delivery journeys exercise the real canonical validators."""
import copy
from pathlib import Path
import sys

import pytest
import yaml

ROOT = Path(__file__).resolve().parents[2]
sys.path[:0] = [str(ROOT / "experiments/portal"), str(ROOT / "platform/tests"), str(ROOT / "platform/tools")]
import delivery_binding as binding
import source_workspace as workspace
from test_epi_source_workspace import scaffold, fixture, tree, ACTOR, PACK


def prepare(tmp_path, monkeypatch):
    root, product, pack = scaffold(tmp_path, monkeypatch)
    read = dict(root=root, pack=pack, actor_id=ACTOR, allowed_packs=[pack])
    args = read | dict(local_demo=True, can_write=True)
    description = binding.describe(**read)
    assert description["ok"] and description["supported"], description
    values = {key: value.replace("REPLACE_ME", "demo") for key, value in description["values"].items()}
    values.update(schema="research_source", cut="2026m09",
                  **{"source:enhanced": "t_enh_demo", "source:lot": "t_enh_demo_lot"})
    return root, product, read, args, description, values


def stage(args, description, values):
    result = binding.stage(**args, values=values, expected_digest=description["inputs_sha256"])
    assert result["ok"], result
    return result["record"]


def test_new_tumour_delivery_staged_validated_saved_then_evidence_enabled(tmp_path, monkeypatch):
    root, product, read, args, description, values = prepare(tmp_path, monkeypatch)
    before = tree(product)
    assert workspace.describe(**read)["blockers"]
    calls = []
    original = binding.proposals.validate_files
    def checked(*arguments):
        calls.append(len(arguments[-1]))
        return original(*arguments)
    monkeypatch.setattr(binding.proposals, "validate_files", checked)
    record = stage(args, description, values)
    payload = record["payload"]
    assert payload["can_save"], payload["new_errors"]
    assert not payload["all_checks_passed"]  # Remaining science is still incomplete.
    assert len(payload["checks"]) == 5
    assert tree(product) == before
    assert {file["path"] for file in payload["files"]} == {"config/data_product.yaml", "config/pipeline.yaml"}
    assert any(item["after"] == "research_source.t_enh_demo_2026m09" for item in payload["impact"])
    assert any(item["engine_reads"] and item["required_columns"] for item in payload["impact"])
    assert not payload["consumer_links_complete"]  # A blank scientific contract has no declared consumers.
    assert not binding.save(**args, record_id=record["id"])["ok"]
    result = binding.save(**args, record_id=record["id"], confirmed=True)
    assert result["ok"] and result["changed"], result
    assert calls == [0, 2, 0, 2]
    after = tree(product)
    assert {name for name in before if before[name] != after[name]} == {"config/data_product.yaml", "config/pipeline.yaml"}
    old_product = yaml.safe_load(before["config/data_product.yaml"])
    new_product = yaml.safe_load(after["config/data_product.yaml"])
    assert {key: value for key, value in old_product.items() if key != "sources"} == {
        key: value for key, value in new_product.items() if key != "sources"}
    old_pipeline = yaml.safe_load(before["config/pipeline.yaml"])
    new_pipeline = yaml.safe_load(after["config/pipeline.yaml"])
    old_pipeline["run"].update(source_schema=values["schema"], refresh=values["cut"])
    assert new_pipeline == old_pipeline  # Study limits and all other runtime settings stay intact.
    assert not workspace.describe(**read)["blockers"]
    request = workspace.create_request(**args)
    assert request["ok"], request
    assert request["record"]["state"] == "awaiting_runtime"
    assert workspace.read(**read, record_id=record["id"])["record"]["state"] == "delivery_saved_pending_review"
    assert not binding.save(**args, record_id=record["id"], confirmed=True)["ok"]


@pytest.mark.parametrize("field,value", [
    ("schema", "../another"), ("schema", "a.b.c"), ("cut", "2026-09"),
    ("cut", "REPLACE_ME"), ("source:enhanced", "table;DROP"),
    ("source:enhanced", ""), ("source:enhanced", True),
])
def test_unsafe_or_unstated_binding_refused_before_validation(tmp_path, monkeypatch, field, value):
    _, product, _, args, description, values = prepare(tmp_path, monkeypatch)
    before = tree(product)
    values[field] = value
    monkeypatch.setattr(binding.proposals, "validate_files", lambda *a: pytest.fail("invalid metadata reached validators"))
    result = binding.stage(**args, values=values, expected_digest=description["inputs_sha256"])
    assert not result["ok"]
    assert tree(product) == before


@pytest.mark.parametrize("change", ["actor", "scope", "permission", "source", "policy", "payload"])
def test_stale_or_unscoped_proposal_cannot_save(tmp_path, monkeypatch, change):
    root, product, read, args, description, values = prepare(tmp_path, monkeypatch)
    record = stage(args, description, values)
    if change == "actor":
        args["actor_id"] = "other-editor"
    elif change == "scope":
        args["allowed_packs"] = []
    elif change == "permission":
        args["can_write"] = False
    elif change == "source":
        file = product / "config/pipeline.yaml"
        file.write_bytes(file.read_bytes() + b"\n# changed elsewhere\n")
    elif change == "policy":
        file = root / "governance/vendor_policy.yaml"
        file.write_bytes(file.read_bytes() + b"\n# policy changed\n")
    elif change == "payload":
        scope = workspace._scope(root, read["pack"], ACTOR, read["allowed_packs"])
        record["payload"]["files"][0]["after"] += "\nstatus: approved\n"
        workspace._write(scope[-1], record)
    before = tree(product)
    result = binding.save(**args, record_id=record["id"], confirmed=True)
    assert not result["ok"], result
    assert tree(product) == before


def test_new_validator_failure_blocks_draft_save(tmp_path, monkeypatch):
    _, product, _, args, description, values = prepare(tmp_path, monkeypatch)
    original = binding.proposals.validate_files
    def checked(*arguments):
        result = original(*arguments)
        if arguments[-1]:
            result[0]["errors"].append("delivery binding regression")
            result[0]["passed"] = False
        return result
    monkeypatch.setattr(binding.proposals, "validate_files", checked)
    before = tree(product)
    record = stage(args, description, values)
    assert not record["payload"]["can_save"] and record["state"] == "needs_changes"
    assert not binding.save(**args, record_id=record["id"], confirmed=True)["ok"]
    assert tree(product) == before


def test_active_format_stems_and_layout_are_preserved(tmp_path, monkeypatch):
    _, product, read, args, _, _ = prepare(tmp_path, monkeypatch)
    file = product / "config/data_product.yaml"
    doc = yaml.safe_load(file.read_text(encoding="utf-8"))
    doc["formats"] = {"EDM": {"sources": {"enhanced": "custom_enhanced"},
                             "source_layout": "{schema}.prefix_{stem}_{refresh}"}}
    file.write_text(yaml.safe_dump(doc, sort_keys=False), encoding="utf-8")
    description = binding.describe(**read)
    assert description["supported"], description
    values = {key: value.replace("REPLACE_ME", "demo") for key, value in description["values"].items()} | {"schema": "source_b", "cut": "2026m09",
                                       "source:enhanced": "changed_enhanced", "source:lot": "declared_lot"}
    record = stage(args, description, values)
    assert record["payload"]["can_save"], record["payload"]["new_errors"]
    result = binding.save(**args, record_id=record["id"], confirmed=True)
    assert result["ok"], result
    cfg, _ = workspace._identity(product)
    assert cfg.table("enhanced") == "source_b.prefix_changed_enhanced_2026m09"
    updated = yaml.safe_load(file.read_text(encoding="utf-8"))
    assert updated["sources"]["enhanced"] == doc["sources"]["enhanced"]
    assert updated["formats"]["EDM"]["source_layout"] == doc["formats"]["EDM"]["source_layout"]


@pytest.mark.parametrize("kind", ["union", "adapter", "unknown_layout"])
def test_unsupported_delivery_has_clear_handoff_and_no_mutation(tmp_path, monkeypatch, kind):
    _, product, read, args, _, _ = prepare(tmp_path, monkeypatch)
    file = product / "config/data_product.yaml"
    doc = yaml.safe_load(file.read_text(encoding="utf-8"))
    if kind == "union":
        doc["source_union"] = {"members": [{"schema": "other_source"}]}
    elif kind == "adapter":
        (product / "config/source_adapters.yaml").write_text("adapters: []\n", encoding="utf-8")
    else:
        doc.setdefault("formats", {})["EDM"] = {"source_layout": "{schema}.{unknown}_{stem}"}
    file.write_text(yaml.safe_dump(doc, sort_keys=False), encoding="utf-8")
    before = tree(product)
    description = binding.describe(**read)
    assert description["ok"] and not description["supported"], description
    assert any("Engineering" in line or "Map delivered sources" in line for line in description["blockers"])
    result = binding.stage(**args, values=description["values"], expected_digest=description["inputs_sha256"])
    assert not result["ok"]
    assert tree(product) == before


def test_partial_file_replacement_failure_rolls_back(tmp_path, monkeypatch):
    _, product, _, args, description, values = prepare(tmp_path, monkeypatch)
    record = stage(args, description, values)
    before = tree(product)
    original = binding.os.replace
    calls = 0
    def replace(source, target):
        nonlocal calls
        if str(target).endswith("pipeline.yaml"):
            calls += 1
            raise OSError("simulated write failure")
        return original(source, target)
    monkeypatch.setattr(binding.os, "replace", replace)
    result = binding.save(**args, record_id=record["id"], confirmed=True)
    assert not result["ok"] and calls == 1, result
    assert tree(product) == before


def test_changed_delivery_reports_exact_declared_consumers(tmp_path, monkeypatch):
    root, product, _, _, _ = fixture(tmp_path, monkeypatch)
    read = dict(root=root, pack=PACK, actor_id=ACTOR, allowed_packs=[PACK])
    description = binding.describe(**read)
    assert description["supported"], description
    assert any(row["read_by_blocks"] for row in description["rows"])
    values = description["values"] | {"schema": "next_delivery"}
    before = tree(product)
    record = stage(read | dict(local_demo=True, can_write=True), description, values)
    rows = {row["role"]: row for row in description["rows"]}
    for impact in record["payload"]["impact"]:
        assert impact["read_by_blocks"] == rows[impact["role"]]["read_by_blocks"]
        assert impact["required_by_variables"] == rows[impact["role"]]["required_by_variables"]
    assert tree(product) == before


def test_unreadable_validator_is_never_exempt_as_preexisting(tmp_path, monkeypatch):
    _, product, _, args, description, values = prepare(tmp_path, monkeypatch)
    original = binding.proposals.validate_files
    def checked(*arguments):
        result = original(*arguments)
        result[0].update(passed=False, errors=["RuntimeError: validator unavailable"])
        return result
    monkeypatch.setattr(binding.proposals, "validate_files", checked)
    before = tree(product)
    record = stage(args, description, values)
    assert not record["payload"]["can_save"]
    assert any("validator unavailable" in error for error in record["payload"]["new_errors"])
    assert tree(product) == before


def test_private_activity_failure_reports_the_actual_saved_delivery(tmp_path, monkeypatch):
    _, product, read, args, description, values = prepare(tmp_path, monkeypatch)
    record = stage(args, description, values)
    def refused(*_):
        raise OSError("private activity disk unavailable")
    monkeypatch.setattr(workspace, "_write", refused)
    result = binding.save(**args, record_id=record["id"], confirmed=True)
    assert result["ok"] and result["changed"]
    assert "files were saved" in result["warning"] and "Do not resubmit" in result["warning"]
    assert not workspace.describe(**read)["blockers"]
    assert workspace.read(**read, record_id=record["id"])["stale"]


def test_change_during_validation_cannot_rebind_old_preview_to_new_inputs(tmp_path, monkeypatch):
    root, product, read, args, description, values = prepare(tmp_path, monkeypatch)
    original = binding.proposals.validate_files
    changed = False
    def checked(*arguments):
        nonlocal changed
        result = original(*arguments)
        if not changed:
            policy = root / "governance/vendor_policy.yaml"
            policy.write_bytes(policy.read_bytes() + b"\n# changed during validation\n")
            changed = True
        return result
    monkeypatch.setattr(binding.proposals, "validate_files", checked)
    before = tree(product)
    result = binding.stage(**args, values=values, expected_digest=description["inputs_sha256"])
    assert not result["ok"] and "during validation" in result["errors"][0]
    assert not workspace.recent(**read)
    assert tree(product) == before
