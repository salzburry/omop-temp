"""Regression for the live critic request whose proposal was cut off by evidence."""
import json
from pathlib import Path
import sys

import pytest

ROOT = Path(__file__).resolve().parents[2]
sys.path[:0] = [str(ROOT / part) for part in ('experiments/agent', 'experiments/portal', 'platform/tools', 'platform/tests')]
import coding_agent as coding
import critic
import specialist_workspace as specialist
import workflow_skills
from test_epi_coding_orchestration import checkout, PACK, integration


class Recorder:
    def __init__(self):
        self.calls = []

    def step(self, system, messages):
        self.calls.append((system, messages))
        return json.dumps({'falsified': False, 'confidence': 'low', 'findings': [],
                           'route': 'human', 'why': 'Review the declared unresolved configuration.'})


def encoded(value):
    return json.dumps(value, ensure_ascii=False, separators=(',', ':'))


def test_live_sized_coding_critic_keeps_the_exact_proposal_and_actual_source_test_pipeline_context(checkout):
    context = coding.implementation_context('PDL1_TPS', root=checkout, max_chars=4000)
    context = {'orchestration': coding.orchestration_context(PACK, root=checkout), **context}
    evidence = {'pack': PACK, 'requirement_query': 'PDL1_TPS',
        'definition': 'Draft requirement: review the index-relative marker selection. ' * 26,
        'implementation_context': context, 'capabilities': 'Current registry descriptions. ' * 50}
    proposal = {'decision': 'reuse', 'summary': 'Consider the existing marker capability; this is not an executable binding.',
        'integration': integration(context['orchestration']),
        'reuse': {'capability_id': 'biomarkers.marker_value',
            'config_sketch': {'unresolved_example': 'An engineer must verify these possible config names; no schema is asserted. ' * 28},
            'why_it_answers': 'The caller and missing-value behavior still need review. EXACT_PROPOSAL_END'}}
    proposal_text = encoded(proposal)
    assert 3000 < len(proposal_text.encode()) < 6000
    assert len(encoded(evidence)) > 11000
    native = Recorder()
    guidance = workflow_skills.context_for(ROOT, kind='implementation', max_bytes=4500)
    assert guidance['ok']
    model = specialist.BoundedModel(native, {'provider_id': 'vscode'}, skills=guidance)
    verdict = critic.review(model, 'Implement PDL1_TPS without changing its reviewed meaning.', encoded(evidence), proposal_text)
    assert verdict['route'] == 'human' and len(native.calls) == 1
    system, messages = native.calls[0]
    prompt = messages[0]['content']
    assert prompt.index('PROPOSAL:') < prompt.index('EVIDENCE:')
    assert proposal_text in prompt and 'EXACT_PROPOSAL_END' in prompt
    assert len(system.encode()) + len(prompt.encode()) <= specialist.MAX_INPUT_BYTES
    assert model.excerpted_calls == 0 and guidance['prompt'] in system
    review_evidence = json.loads(prompt.split('\n\nEVIDENCE:\n', 1)[1])
    reviewed_context = review_evidence['implementation_context']
    for kind in ('implementation', 'test'):
        row = next(row for row in reviewed_context['files'] if row['kind'] == kind)
        original = next(row0 for row0 in context['files'] if row0['path'] == row['path'] and row0['symbol'] == row['symbol'])
        assert row['sha256'] == original['sha256'] and row['excerpt']
        assert row['excerpt'].split('\n[Excerpt:', 1)[0] in original['excerpt']
    assert reviewed_context['orchestration']['entry_points'] == context['orchestration']['entry_points']
    assert reviewed_context['orchestration']['configuration'] == context['orchestration']['configuration']
    assert reviewed_context['orchestration']['stage_calls']
    assert any(row['call'] == 'clinical.build' for row in reviewed_context['orchestration']['stage_calls'])
    assert {row['symbol'] for row in reviewed_context['files'] if row['kind'] == 'implementation'} == {
        row['symbol'] for row in context['files'] if row['kind'] == 'implementation'}
    assert [row['id'] for row in reviewed_context['capabilities']] == [row['id'] for row in context['capabilities']]
    assert all(row['config_keys'] == context['capabilities'][index]['config_keys']
               for index, row in enumerate(reviewed_context['capabilities']))
    assert 'omitted' in review_evidence['review_omissions']


@pytest.mark.parametrize('proposal', [
    'A complete small proposal. FINAL_CLAIM',
    encoded({'decision': 'generate', 'summary': 'Keep the exact source and tests.',
        'generated': {'code': 'def rule(frame):\n    return frame\n' * 40,
                      'tests': 'def test_rule():\n    assert True\n' * 25}}),
    'Review the Unicode label αβ患者. ' * 70,
])
def test_large_unstructured_evidence_cannot_displace_any_part_of_proposal(proposal):
    content = critic.review_request('The complete requirement.', 'Evidence line. ' * 5000, proposal)
    assert '\n\nPROPOSAL:\n' + proposal + '\n\nEVIDENCE:\n' in content
    assert len(content.encode()) <= critic.MAX_REVIEW_BYTES
    assert 'remaining evidence omitted' in content


@pytest.mark.parametrize('requirement,proposal', [('requirement', 'p' * 6001), ('q' * 1001, 'proposal'), ('requirement', '')])
def test_unreviewable_subject_is_refused_before_the_model(requirement, proposal):
    native = Recorder()
    verdict = critic.review(native, requirement, 'Evidence exists.', proposal)
    assert verdict['route'] == 'human' and verdict['falsified']
    assert native.calls == [] and 'no partial proposal' in verdict['why']


def test_minimum_pipeline_evidence_that_cannot_fit_routes_to_a_person_without_a_partial_review():
    evidence = encoded({'implementation_context': {'files': [
        {'kind': 'implementation', 'path': 'rule.py', 'excerpt': 'def rule(): pass'},
        {'kind': 'test', 'path': 'test_rule.py', 'excerpt': 'assert rule() is None'}],
        'orchestration': {'configuration': {'selected_config': 'x' * 12000}}}})
    native = Recorder()
    verdict = critic.review(native, 'Review this rule.', evidence, 'The exact proposal.')
    assert verdict['route'] == 'human' and native.calls == []


def test_adapter_refuses_a_second_prefix_cut_of_an_explicit_critic_review():
    native = Recorder()
    model = specialist.BoundedModel(native, {'provider_id': 'vscode'})
    content = critic.review_request('Requirement', 'Evidence. ' * 2000, 'Exact proposal.')
    with pytest.raises(ValueError, match='complete critic review'):
        model.step('System guidance. ' * 700, [{'role': 'user', 'content': content}])
    assert native.calls == [] and model.calls == 0
