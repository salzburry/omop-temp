# Starting a new tumour

Complete [local installation](../../docs/LOCAL_INSTALLATION.md) first. Use the
checkout's activated Python 3.13 environment for `python` below. Multiline examples
use POSIX shell continuations; in Windows PowerShell, enter the command on one line.

**One command stands the pack up.** It previews every file it would write, and with `--apply` it
stages the plan in a disposable copy of the checkout, runs the repository's own validators there,
and then writes; a write that fails part-way restores every file it touched before it reports
(it is not a transaction — a process killed between a replace and its rollback is still a
half-written checkout, and `git status` is the check):

```bash
python platform/tools/new_product.py kidney --code kidney --name "Kidney" \
    --vendor flatiron --tumor-class solid --spec-version 202609 --narrow genitourinary \
    --condition-class oncology --modality ehr \
    --disease-terms "renal cell carcinoma, kidney cancer" \
    --ai-classification sponsor_ai_eligible --classified-by "<your name>" \
    --classified-date <YYYY-MM-DD> [--workbook <the approved PROG_SPEC.xlsx>]     # preview
# ...the same command with --apply                                                 # write
```

Three declarations are the person's and have no default (twelfth verdict): `--condition-class`,
which only `oncology` satisfies — the engine's semantics are staging, ECOG, lines of therapy,
mortality and survival, and an asthma or COPD product is refused honestly rather than relabelled
`solid`; `--modality ehr|claims`; and `--disease-terms`, the phrases a specification uses to NAME
this disease in prose, written to `governance/tumour_registry.yaml` so the pipeline can establish
that a workbook registered to this pack is this tumour's. A name the registry's
`non_oncology_terms` guard knows is refused however it is classified.

The eleventh external review followed the manual steps below literally and found them spread over
eleven files in four directories, each refused by a different gate one CI failure at a time, and no
operation that did all of it or none. The command is that operation; the steps remain here because
they are what it writes, and a person who reads them knows what the pack asserts — which is nothing
that nobody decided. What the command will NOT do: type a judgement. The three Gate 1 fields it
demands (`ai_classification`, `classified_by`, `classified_date`) are the person's and have no
default; every scientific value in `config/` stays `REPLACE_ME` for the contract to fill; the
oncology-catalogue row it adds claims `maturity: registered`, which claims nothing.

`--tumour-family <existing family>` makes the slug an ALIAS of a tumour the registry already knows
(a second product of the same tumour — another vendor, another modality): the registry entry's
`tumour_key` names the family, and the inventory overlay and catalogue row point at the family's
shelf, so both products reuse one set of tumour definitions while each keeps its own slug, config
and sources. Without it the slug becomes its own family, and a slug that shares a token with an
existing family is refused with the alias named. `--workbook` registers the approved specification
and runs Gate 2 generation on the staged copy — a workbook whose study population names another
disease, a condition the engine does not build, or nothing the registry carries for this tumour
refuses the whole stand-up (`DECLARED_DISEASE`): the disease is established positively or the
workbook is not this pack's.

A folder of documents is NOT a pack. Discovery is by shape: a directory becomes a pack when it carries
`source_refs.yaml`, `handoff/MATURITY.yaml`, `handoff/FUNCTIONAL_CONTRACT.md`,
`spec_pipeline/pipeline.conf` or `config/data_product.yaml`. Until one of those exists the gates do not
look at it — which is why dropping the spec in on its own does nothing, and why CI never has to be
edited to pick a new tumour up.

A pack is never COPIED BY HAND from a reference fixture: git follows a copy's history, and until the thirteenth pass the ledger read the fixture's object identity into the copy (the copy was told to 'restore' a uuid two records would then claim). `new_product.py` stands a product up with its own identity. A hand copy made WITHOUT the fixture's `object_uuid` starts its ledger history at the commit that created it; a hand copy that carried the uuid into its first commit is told, by name, that it copied the fixture's object and how to exit (remove the copied `object_uuid` line, commit, then `source_manifest.py <pack> --record-event <material_id>` seals its own genesis) — ownership is decided by where a uuid first entered the repository, so the fixture keeps its identity either way.

## What the command writes, in the order the gates need it

**0. `products/registry.yaml`** — FIRST, as `status: scaffold` (the entry the tools below resolve
the pack through; `source_refs_init.py` refuses a pack with no entry):

```yaml
- { code: <code>, name: "<Name>", slug: <slug>, vendor: <vendor>, tumor_class: <class>,
    status: scaffold, current_spec_version: "<YYYYMM>" }
```

The registry entry is checked against `config/data_product.yaml` IMMEDIATELY — the same commit
must set the config's `version:` to the pack's version and replace the `vendor:` and
`tumor_class:` placeholders, or `test_registry` fails on the mismatch. This engine is
oncology-configurable: `tumor_class` is `solid | heme`, `condition_class` is `oncology` (the
template says so; the registry entry may say so too and may say nothing else), and a product for
another condition is REFUSED by validation and by the bundle until the engine has capabilities for
it (never relabel it solid or heme to pass).

**0b. The oncology registry surfaces** — a registered tumour with no row in
`governance/reference/oncology_modules/CATALOGUE.yaml` assembles no modules and fails
`oncology_registry.py --check`; the row needs an inventory overlay
(`governance/reference/variable_inventory/INVENTORY.yaml` `tumours.<slug>`, an empty stub is honest)
and an indication module on disk (`oncology_modules/indication/<slug>.yaml`, regenerated by
`registry_enrich.py --write`); and `products/metadata/catalog.yaml` `tumor_codes` mirrors the
registry both ways (`test_catalog`). The command writes all four with claim-nothing values.

**1. `source_refs.yaml`** — the copied template ships a placeholder; `source_refs_init.py`
replaces a placeholder that is UNTOUCHED (every governed line the template's own, or still a
placeholder value) and refuses anything a person has edited. For a pack's FIRST registration it
writes the file for you — composing `product` and `spec_version` from the registry and the pack
path, naming the one workbook it finds in `prog_spec/` as `path_or_link` (or `TBD` when there is
none or more than one), and validating against the schema before it writes:

```bash
python platform/tools/source_refs_init.py products/<family>/<slug>/<YYYYMM> \
    --ai-classification <sponsor_ai_eligible|vendor_restricted|restricted_derived> \
    --classified-by "<your name>" --classified-date <YYYY-MM-DD> [--path-or-link <workbook>]
```

It has NO default for those three, refuses a team name or a placeholder, and refuses to overwrite
an existing registration. The three it demands are the three no tool may infer; everything else it
knows. Note it also refuses a pack still sitting at the literal `YYYYMM` directory: a registration
records WHICH cut it governs, and the schema pins `spec_version` to six digits.

The classification is the AI boundary and is required at EVERY status. It follows the CONTENT's
provenance, never the folder: a sponsor-authored specification is `sponsor_ai_eligible`; anything
vendor-originated or vendor-derived is not, and an internally written document that quotes vendor
material inherits the restricted classification. See `governance/WORKFLOW.md` §"Eligibility".

**The commit that lands `classified_by` is signed by that person** with their registered review key
(`governance/allowed_signers.yaml`), or `approval_identity.py --check` stays red: a tool cannot sign
for a person, and the command says so in its "then, for a person" list.

If the approved workbook is not in hand, leave `status: pending`, say why in `why_provisional`, and
set `path_or_link` to a `TBD …` note or a link. A path that names somewhere in the repo must resolve —
Gate 1 checks that at every status, so a mistyped filename is caught at registration rather than
surfacing later as a pipeline fault. `run_spec_pipeline.py` refuses a `TBD` path: register the
workbook before generating.

**2. `spec_pipeline/pipeline.conf`** — `TUMOR` is the slug and `SPEC_SOURCE_ID` the `material_id`
the extractor should read. It names a material, never a path: that indirection is what lets the
spec folder move without touching the pipeline.

**3. `handoff/FUNCTIONAL_CONTRACT.md`** — the title carries the tumour and version. The file ships
empty on purpose (an empty contract is a true statement about a pack whose drafting has not
started; the copied `handoff/tests` floor is `records: 0` for the same reason — raise it the day the
first record lands); the record table itself is appended by `contract_record.py --apply`, never by hand.

**3b. `handoff/MATURITY.yaml`** — both axes stay at `not_started` until the evidence exists. It is a
CLAIM, and each level is granted on the evidence named beside it.

**4. `governance/tumour_registry.yaml`** — a NEW tumour is a `families` entry; a product of a tumour
the registry already knows (or a slug sharing a token with one) is an `aliases` entry, because two
families claiming one token flag each other's tables everywhere. Without either, the pipeline
REFUSES to generate: `FOREIGN_TABLE` and `DECLARED_DISEASE` cannot tell this workbook from another
tumour's, and a pipeline that cannot tell must not produce artifacts that read as checked.

**5. `products/activation.yaml` + the bundle** — the pack's activation block with EVERY field the
bundle reads (`schedule_enabled: false`, `run_as`, `can_manage`, `can_view`, `cluster_policy_id`;
`schedule_enabled: true` is refused unless the pack is releasable AND `run_as`, a non-empty
`can_manage` list, a `can_view` list and `cluster_policy_id` are all stated), then the regenerated
bundle (`bundle_products.py` → `resources/products.yml`) and the regenerated pages
(`current_state.py` → `governance/CURRENT_STATE.md`, `portfolio_status.py` → `products/PORTFOLIO.md`) —
all three are `--check`ed by CI.

**6. The registry entry (step 0) is already in place.** "Leave the config until
the contract exists" applies to the VARIABLES, never to those identity fields.

The registry is what `engine.config.product_dir()` resolves for every DEFAULT product lookup, so an
entry is a claim that the pack can be built. Adding it early, or as `status: active`, points every
default lookup at a pack with no `config/data_product.yaml` — which does not fail once, it fails in
every suite that loads the default product, and each failure names the missing config file rather than
the registry line that caused it. Deleting a pack while the registry still called it current took 10 of
20 platform suites down and read as ten unrelated defects.

`product_gates --check-maturity` refuses an `active` entry whose pack directory or config file is
missing, so the error names the registry line; a config that still carries `REPLACE_ME` is
`engine/validate.py`'s to refuse. Promote to `active` only after the contract, the config and the
pack's own tests pass.

**Adding a new VERSION of an existing tumour** is the same rule: leave the old `current_spec_version`
alone, build the new pack alongside it, and move `current_spec_version` in the final promotion change
— never at the start. `governance/VERSIONING.md` is enforced: an ACTIVE product's executable surface
does not change in place (`config_diff.py --check-versioning`).

## Starting from an earlier product

Two paths, and today only one has an executable subject:

- **The next cut of the SAME product** — `new_product.py <slug> --next-cut-of
  products/<family>/<slug>/<old> --spec-version <new> --workbook <revised.xlsx> --change-class
  breaking|additive` (plus the three person fields) stands the new folder up beside the released
  one: `config/`, `variables/` and `codelists/` carried by copy for revision, the revised workbook
  registered fresh with its own digest and extracted, the registry entry gaining a `lineage` row at
  `status: draft` while `current_spec_version` stays where it is, the slug's `CHANGELOG.md` gaining
  the classified line. Records are NOT copied: `spec_diff.py <old> <new> --carry-plan <dir>`
  compares the two extractions by content and carries the judgments whose text provably survived,
  once the new cut's sanitized extraction is reviewed (`.claude/skills/next-cut`). It needs BOTH
  packs to carry `spec_pipeline/out/extracted.json`; "nothing to compare" exits 2, and two packs
  that are not one product's earlier and later cut are refused. The prostate `202603 → 202606`
  pair is NOT such a pair (202603 has no extraction and no workbook — its own `source_refs.yaml`
  records why).
- **A template from ANOTHER product** — `template_promote.py` cuts a release from an approved
  contract with signed CONTRACT and SEMANTIC approvals and a confirmed ruling, and a new pack adopts
  it. The library is EMPTY: no fixture carries those approvals, so every new tumour starts from
  `platform/TUMOR_TEMPLATE` today, and `uat.py` reports the two template checks as `not_run`.

## Then

```bash
python platform/tools/source_manifest.py <pack> --check      # Gate 1
bash platform/tools/run_spec_pipeline.sh <pack>               # extract → lint → coverage → scaffold
```

Gate 1 is pure Python and runs anywhere. `run_spec_pipeline.sh` is the ONLY bash in the workflow —
on a machine without it run `python platform/tools/run_spec_pipeline.py <pack>` — the `.sh`
is a one-line wrapper around exactly that. Or use the bash Git for Windows ships
(`& "C:\Program Files\Git\bin\bash.exe" platform/tools/run_spec_pipeline.sh <pack>`) or run the
same six calls by hand. `sandbox/new_tumour_start/START_HERE.md` §4 lists them in order, with the
PowerShell form.

Add `--check` only later, to ask whether those artifacts are still current: it regenerates into a temp
directory and byte-compares, writing nothing into the pack, so it is not how the first run is done.

The pipeline writes seven generated artifacts to `spec_pipeline/out/`. `SCAFFOLDED_RECORDS.md` holds
one record per specification row — that is the contract's shape (lint I16), not a starting point to be
grouped into families afterwards.

**Before the workbook conversation, read the reference shelf** —
`governance/reference/variable_inventory/INVENTORY.yaml` holds, in one file, a cross-tumour
master (`master:` — the core variables every tumour defines, with named parameter SLOTS such as
age bands and index convention) and a literature-derived overlay per tumour, each variable
carrying its engine coverage inline. It is `status: reference_only` — a drafting AID, never
a specification: it tells you what published RWD studies of this tumour typically define, so the
workbook discussion starts from a checklist instead of a blank page. A variable enters THIS product
only when Science's approved workbook states it, and slot values come from that workbook into
`config/`, never from the shelf's examples. Its README says the rest.

Two tools turn the shelf into work you do not redo:

```bash
python platform/tools/inventory_coverage.py                # which engine family covers what;
                                                            #   the engine_gap list = scoping
python platform/tools/variables_scaffold.py <pack>         # parameter SKELETONS into
                                                            #   spec_pipeline/out/variables_scaffold/
```

The coverage map (`governance/reference/variable_inventory/COVERAGE.md`) says, per inventory
variable, whether an existing engine family computes it, existing config patterns express it, or
engine work is needed — so scoping the new tumour is a lookup. The scaffold emits the config
SHAPES for the families this tumour's overlay instantiates, every value the `REPLACE_ME` marker:
fill each from the approved workbook, copy into `variables/`, and note the build REFUSES any pack
value still carrying the marker — a half-filled skeleton cannot run.

**Register and approve the sanitized extraction before any drafting** — this step gates the whole
of Gate 2, including fully hand-written records: `spec_slice.py` and `contract_record.py` refuse to
supply spec evidence until the pack's `ai_extraction` artifact is registered
(`python platform/tools/source_manifest.py --register-ai-extraction <pack> --write` inserts the
block into `source_refs.yaml` and verifies it landed) and a HUMAN sets its `status: reviewed` with
their name and date. The five `TODO` fields in that block are that person's to answer — the pack is deliberately
RED until they do. `sandbox/new_tumour_start/START_HERE.md` §4b walks the same step.

`config/`, `variables/` and `codelists/` are the Gate 4 half of the pack. They ship here so the shape
is visible: the root config is full of `REPLACE_ME`, and `variables/`/`codelists/` carry real seeded
values because a config of pure placeholders cannot be linted or executed. Leave all of it until the
contract exists. `MATURITY.yaml` saying `configuration: not_started` is what makes that honest.

## Gate 2's human loop — the instruments, so nobody hand-edits a register

Drafting fills `DECISIONS.md` with questions. Getting them ANSWERED is a loop with a tool at each
step, and every one of them exists because the delivery this framework was measured against did the
step by hand:

```bash
python platform/tools/precedents.py --for <pack>          # what other products hit before you start
python platform/tools/decision_report.py <pack>           # the questions, ranked by what each unblocks
python platform/tools/decision_packet.py <pack> --out q.html   # one page per question, for the answerer
python platform/tools/decision_record.py <pack> --forms   # one YAML answer form per OPEN decision
# ...the answerer types answer / answered_by / answer_date into the form, commits it...
python platform/tools/decision_record.py <pack> --apply   # transcribes the answered forms, prints the worklist
```

Send the packet, not the repository: the person answering decides, they do not edit markdown. The
filled forms stay committed — the register row indexes an answer, the form attests it. The bare
`--apply` records every form somebody has typed into and reports the rest as not yet answered;
`--apply <form>` holds one named form to its content; `--check` names an issued form that went
stale before anyone answered it; `--record-event <ID>` re-seals one answer after a refused seal.

## Gates 3–6

Gate 2 is where most of the work is, so this file used to stop there — and a new pack was left to
find the rest by reading tools. One row per remaining gate: the artifact it produces, the command
that produces it, the fields only a person can fill, and what closes it.

| Gate | Artifact | Command | Human fields | Closes when |
|---|---|---|---|---|
| **3** — source readiness | `handoff/SOURCE_VERDICTS.md` (or `SOURCE_VERDICTS.<member>.md` per union member; `--out handoff/SOURCE_VERDICTS.md` is resolved against the pack, whatever the working directory) | **first** set the delivery bindings in `config/pipeline.yaml` (`run.refresh`, `run.source_schema` — unless a `source_union` names the member schemas — plus `run.data_format` / `run.source_layout` where they apply), then run the profile and schema check against **those same values**, then `source_check.py <pack> --profile <profile.tsv> --schema-validation <SCHEMA_VALIDATION.json> --complete --out handoff/SOURCE_VERDICTS.md` | `reviewed_by`, `review_date` in the generated front matter | every contract record's `source_mapping` is `human_confirmed` and its `dictionary_check` / `live_schema_check` / `data_profile_check` are off `not_run`. The profile and schema report are written OUTSIDE the checkout — `--out-dir` is required and refused inside it |
| **4** — executable configuration | the active config graph + `handoff/CONFIGURATION_APPROVAL.yaml` | author it (`platform/README.md` §"Add a tumor"), then `contract_binding.py <pack> --check` | `approved_by`, `approval_date`, `technically_reviewed_by`, both digests — copy `CONFIGURATION_APPROVAL.example.yaml` | the binder passes, every graph file is off `status: scaffold`, and the form's digests match the graph and the contract. A form whose digests no longer match is VOID at any level, not only at `approved` |
| **5** — validation | per-record `acceptance` + `status.validation`; at run level the refresh manifest's `qc`, `golden`, `source_qc`, `deliverables` | the pack's own tests (`product_gates.py --list-tests`), then a build | `status.validation` per record; the reviewer named at Gate 6 as `validated_by` | every approved record is `passed_test` or `passed_live`, or names a gap in `handoff/ENGINE_GAPS.md`. There is no separate Gate 5 form — the human exit is recorded on the Gate 6 approval, because a validation record with no build attached is a claim about nothing in particular |
| **6** — release | `handoff/RELEASE_APPROVAL.yaml` | a prod run stops before the swap and prints the two identifiers; a promotion run (`promote_build_id`) then publishes THOSE bytes, building nothing | `approved_by`, `approval_date`, `validated_by`, `validation_date`, `approved_build_id`, `approved_manifest_sha256` — copy `RELEASE_APPROVAL.example.yaml` | the promotion run completes: it verifies the approval names this build id + candidate-manifest digest, materialises the staged bytes and swaps the views. The operation EXISTS and is exercised against real Delta in CI; what is unproven is production SIT — no promotion has run on a Databricks cluster. See `products/OPERATIONS.md` §"Gate 6" |

**The delivery bindings come first, and they are not a governed edit.** A `--complete` verdict is an
approval record ABOUT a delivery, so the pack has to name one: with `refresh: REPLACE_ME` the tool
refuses, because there is nothing for the gate to hold constant afterwards. `config/pipeline.yaml`
sits OUTSIDE `config_bundle_sha256`, so filling it in needs no Gate 4 re-approval — that separation
is exactly what the environment split bought. Set it once, and run all three tools
(`run_product_profile.py`, `run_product_schema_check.py`, `source_check.py`) against those values:
the profile stamps what it measured, and the verdict refuses a profile from another cut or schema.
The same bindings are what a production run is later held to — an override that points the job at a
different delivery makes the run unpublishable, because the Gate 3 evidence covers the committed one.

Two more things about Gate 3 worth knowing before you start it, because both cost a day if you find
them late. The verdict generator implements the **data-profiler** evidence route; a vendor whose policy
declares the documentation route can be registered but has no verdict generator yet
(`governance/vendor_policy.yaml` decides which route applies, and fails closed on an unknown vendor).
And the profile is the only Gate 3 artifact that touches vendor data — nothing it produces may enter
the checkout.

This file is the template's runbook and is not copied into a pack.
