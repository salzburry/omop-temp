# Platform capabilities — what each coverage claim resolves to

**GENERATED from `platform/capabilities.yaml` by `platform/tools/capability_registry.py`
— edit the registry, then regenerate. `--check` refuses a stale copy.**

`governance/reference/variable_inventory/COVERAGE.md` says which CLASS a variable's
coverage falls in. This file says what that class RESOLVES to: the config key a pack
authors, the engine symbols that read it, the columns it publishes and the tests that
exercise it. The registry tool refuses any entry whose module, symbol, config key, output
or test does not resolve, and refuses the pair of files if they disagree about which
classes a family answers.

**A capability entry is a CHECKED claim, not a verified one.** Every part is proven to
exist and to be wired to the others. Nothing here proves the code is correct against
clinical intent, that the named test is a good test, or that `emits` lists every column the
family publishes.
These are historical verification declarations. Generating this registry does not run
Python, R or Spark. For the current branch and configuration, inspect the current implementation runtime receipt:
its selected tests, versions, pass/fail/skip counts and actual R comparison markers determine what executed.
This registry indexes inventory master families, not every engine stage or module. An unlisted stage has no readiness claim here.
Tests of shared machinery do not establish each clinical family's configured output. See the individual limits below.

**Verification is stated PER ENGINE, because this file's first version was not and said
something false.** It listed a Python symbol and an R symbol side by side and reported the
capability resolved — so `clinical.comorbidity_index` read as implemented in both while R
applied the supersedes hierarchy sequentially and truncated fractional weights, returning 4
where Python returned 3. Naming a symbol is not evidence that it computes the same thing.

| state | meaning |
|---|---|
| `absent` | this engine does not implement the capability |
| `declared` | the symbol exists; no family-specific execution claim is recorded |
| `unit_tested` | a named test exercises THIS engine's implementation |
| `component_parity` | a named test runs BOTH engines over the same input and compares what they COMPILE or COMPUTE (SQL strings, helper returns) |
| `stage_conformance` | a shared ROW FIXTURE run through both engines' stages, outputs compared cell-by-cell. The harness is `platform/tests/test_stage_conformance.py` + `conformance/*.yaml` (one parsed fixture feeds both engines; the R half runs under sparklyr and SKIPS LOUDLY where R is absent). **A family may claim this state only after the R half has EXECUTED green** — a skip is not a pass. 17 of 37 capabilities claim it |

| family | classes | config key | python | R | declared verification (py / R) | tests |
|---|---|---|---|---|---|---|
| **AGE** | engine_family | `demographics.age_bands` | `build` | `demographics_build` | component / component | 2 |
| **AGEGR1** | engine_family | `demographics.age_bands` | `_bands_case` | `demographics_build` | component / component | 2 |
| **BIOMARKER_TEST_CONTEXT** | config_expressible | `clinical.biomarkers` | `_closest_panel` | `clinical_build` | unit / stage | 3 |
| **BMI_BSA** | engine_family | `clinical.vitals` | `vitals` | `clinical_vitals` | component / component | 3 |
| **CANCER_STAGE_GROUP** | config_expressible | `clinical.staging` | `_stage_case` | `clinical_build` | unit / stage | 3 |
| **COHORT_ELIGIBILITY** | engine_family | `data_product.lot`, `data_product.treatment_status` | `normalized`, `build` | `lot_normalized` | unit / stage | 3 |
| **COMORBIDITY_INDEX** | config_expressible | `clinical.comorbidity_index` | `comorbidity_index` | `clinical_comorbidity_index` | component / component | 3 |
| **DATA_CONTINUITY** | engine_family | `clinical.min_avail_date`, `outcomes.min_followup_days` | `_min_avail_date`, `build` | `clinical_min_avail_date` | unit / stage | 3 |
| **DEATH_DATE** | engine_family | `clinical.death_date_imputation` | `follow_up_and_death`, `_death_conflict_order` | `clinical_follow_up_and_death` | unit / stage | 7 |
| **DISEASE_SYMPTOMS** | config_expressible | `clinical.categoricals` | `_categorical_pick_windowed` | `clinical_build` | unit / **declared only** | 2 |
| **ECOG_PS** | engine_family | `clinical.baseline_ecog` | `baseline_ecog` | `clinical_baseline_ecog` | unit / stage | 4 |
| **GENE_REARRANGEMENT** | config_expressible | `clinical.biomarkers` | `_closest_panel` | `clinical_build` | unit / **declared only** | 3 |
| **GENE_VARIANT_STATUS** | config_expressible | `clinical.biomarkers` | `_closest_panel` | `clinical_build` | unit / **declared only** | 3 |
| **GENOMIC_SIGNATURE** | config_expressible | `clinical.biomarkers` | `_closest_panel` | `clinical_build` | unit / stage | 3 |
| **HISTOLOGIC_GRADE** | config_expressible | `clinical.categoricals` | `_categorical_pick_windowed` | `clinical_build` | unit / **declared only** | 2 |
| **HISTOLOGIC_TYPE** | config_expressible | `clinical.categoricals` | `_categorical_pick_windowed` | `clinical_build` | unit / **declared only** | 2 |
| **INDEX_DATE** | engine_family | `data_product.study`, `data_product.index_dates`, `data_product.cohorts` | `build`, `load`, `Config` | `index_build` | unit / stage | 4 |
| **INSURANCE_PAYER** | config_expressible | `clinical.categoricals` | `_categorical_pick_windowed` | `clinical_build` | unit / stage | 3 |
| **LAB_VALUES** | config_expressible, engine_family | `clinical.lab_values`, `clinical.labs` | `_closest_values_panel`, `_closest_panel` | `clinical_closest_values_panel` | unit / stage | 4 |
| **LINE_OF_THERAPY** | upstream_required | `data_product.lot` | `normalized`, `build` | `lot_normalized`, `treatment_build` | unit / stage | 5 |
| **METASTATIC_DISEASE** | config_expressible, engine_family | `clinical.metastatic_sites` | `_metastatic_sites` | `clinical_metastatic_sites` | unit / stage | 2 |
| **OS** | engine_family | `outcomes.overall_survival`, `outcomes.min_followup_days` | `build` | `outcomes_build` | unit / stage | 3 |
| **PRACTICE_SETTING** | engine_family | `demographics.practice_map` | `build` | `demographics_build` | component / component | 1 |
| **PRIMARY_TUMOR_SITE** | config_expressible | `clinical.categoricals` | `_categorical_pick_windowed` | `clinical_build` | unit / **declared only** | 2 |
| **PROGNOSTIC_RISK_SCORE** | config_expressible | `clinical.categoricals` | `_categorical_pick_windowed` | `clinical_build` | unit / **declared only** | 2 |
| **PROTEIN_EXPRESSION** | config_expressible | `clinical.biomarkers` | `_closest_panel` | `clinical_build` | unit / **declared only** | 3 |
| **RACE_ETHNICITY** | engine_family | `demographics.race_map`, `demographics.ethnicity_map` | `_map_case` | `demographics_build` | component / component | 1 |
| **REGION** | engine_family | `demographics.regions` | `_region_case` | `demographics_build` | component / component | 1 |
| **RWPFS** | engine_family | `outcomes.progression` | `_progression`, `_progression_pred`, `_rwpfs_gate` | `outcomes_progression` | component / component | 4 |
| **RWTTD** | engine_family | `outcomes.line_outcomes`, `outcomes.visit_recency_days` | `_ttd_sql`, `_vis120` | `outcomes_vis120` | component / component | 3 |
| **RW_RESPONSE** | config_expressible | `clinical.response` | `_closest_panel` | `clinical_build` | unit / stage | 4 |
| **SEX** | config_expressible | `clinical.passthrough` | `_passthrough` | `clinical_passthrough` | unit / stage | 3 |
| **SMOKING_STATUS** | config_expressible | `clinical.categoricals` | `_categorical_pick` | `clinical_build` | unit / stage | 3 |
| **TNM_CATEGORY** | config_expressible | `clinical.categoricals` | `_categorical_pick_windowed` | `clinical_build` | unit / **declared only** | 2 |
| **TTNT** | engine_family | `outcomes.line_outcomes` | `_ttnt_sql`, `_ttntfl_sql` | `outcomes_build` | component / component | 3 |
| **TUMOR_BURDEN_FEATURE** | config_expressible, engine_family | `clinical.categoricals` | `_categorical_pick_windowed` | `clinical_build` | unit / **declared only** | 2 |
| **TUMOR_MARKER_VALUE** | config_expressible, engine_family | `clinical.lab_values` | `_closest_values_panel` | `clinical_closest_values_panel` | unit / stage | 2 |

**10 of 37 capabilities declare no family-specific R execution evidence** (`declared only`). Tests may execute their shared R symbols for other families; that does not establish these families' configured outputs. Review each entry's limits and the actual runtime receipts before using a result. 27 cite component or stage comparisons.

## Per capability

### `demographics.age` — AGE

Age at index as year(index_date) - birthyear, computed per (patientid, index_date) so a patient indexed twice carries two ages.

- config `demographics.age_bands` — authored in `variables/demographics.yaml`
- python `build` in `platform/engine/stages/demographics.py`
- R `demographics_build` in `platform/engine-r/stages.R`
- emits `age`
- test `platform/tests/test_r_parity.py::test_case_parity_age_bands`
- test `platform/tests/test_patient_goldens_spark.py::test_hand_computed_patients_come_out_exactly_as_computed`
- **limits** — Year-level arithmetic, not a birthdate difference — the delivered demographics carry a birth YEAR. A patient whose birthday falls after the index date reads one year older than their exact age, which is the vendor's de-identification, not a defect this engine can fix.

### `demographics.age_bands` — AGEGR1

Banded age, compiled from the pack's `age_bands` into the same CASE the R engine emits — bounds, labels and codes are workbook facts, including the fallthrough row.

- config `demographics.age_bands` — authored in `variables/demographics.yaml`
- python `_bands_case` in `platform/engine/stages/demographics.py`
- R `demographics_build` in `platform/engine-r/stages.R`
- emits `agegrl`, `agegrln`
- test `platform/tests/test_r_parity.py::test_case_parity_age_bands`
- test `platform/tests/test_stages_spark.py::test_a_mistyped_value_matcher_is_refused_not_ignored`

### `biomarkers.test_context` — BIOMARKER_TEST_CONTEXT

Whether biomarker testing happened at all, in the window, separate from any result — the distinc tion whose collapse turns never-tested into negative.

- config `clinical.biomarkers` — authored in `variables/clinical.yaml`
- python `_closest_panel` in `platform/engine/stages/clinical.py`
- R `clinical_build` in `platform/engine-r/stages.R`
- emits `<name>`
- test `platform/tests/test_stages_spark.py::test_response_best_of_window_carries_its_assessment_date`
- test `platform/tests/test_stages_spark.py::test_record_selection_is_named_and_defaults_to_todays_behaviour`
- test `platform/tests/test_stage_conformance.py::test_conformance_clinical_build_categoricals`

### `clinical.vitals` — BMI_BSA

Baseline BMI and BSA from paired height and weight observations, using a NAMED formula from the engine's registry — the pack names the method, it never restates the arithmetic — and banded via the shared bands compiler.

- config `clinical.vitals` — authored in `variables/clinical.yaml`
- python `vitals` in `platform/engine/stages/clinical.py`
- R `clinical_vitals` in `platform/engine-r/stages.R`
- emits `bmi`, `bmigr1`, `bmigr1n`, `bsa`
- test `platform/tests/test_formula_registry_parity.py::test_bmi_registry_parity`
- test `platform/tests/test_formula_registry_parity.py::test_bsa_registry_parity`
- test `platform/tests/test_r_parity.py::test_case_parity_bmi_bands`

### `staging.stage_group` — CANCER_STAGE_GROUP

The delivered stage string collapsed to the pack's published groups by prefix cascade — longest prefix first, so a shorter one cannot swallow every longer stage that starts with it.

- config `clinical.staging` — authored in `variables/clinical.yaml`
- python `_stage_case` in `platform/engine/stages/clinical.py`
- R `clinical_build` in `platform/engine-r/stages.R`
- emits `<name>`
- test `platform/tests/test_stages_spark.py::test_a_mistyped_value_matcher_is_refused_not_ignored`
- test `platform/tests/test_stages_spark.py::test_from_regex_classifies_on_real_spark`
- test `platform/tests/test_stage_conformance.py::test_conformance_clinical_build_categoricals`

### `eligibility.cohort_membership` — COHORT_ELIGIBILITY

Who survives from the delivered population into each cohort: the line model (`lot`) decides which LOT rows count before lines are numbered, and `treatment_status` publishes the treated/untreated split that evidence — at least one LOT row — determines.

- config `data_product.lot` — authored in `config/data_product.yaml`
- config `data_product.treatment_status` — authored in `config/data_product.yaml`
- python `normalized` in `platform/engine/stages/lot.py`
- python `build` in `platform/engine/stages/assemble.py`
- R `lot_normalized` in `platform/engine-r/stages.R`
- emits `cohortu`, `cohortun`
- test `platform/tests/test_stages_spark.py::test_assemble_treated_untreated_split_and_stamp`
- test `platform/tests/test_stages_spark.py::test_lot_normalized_mcrpc_only_and_deterministic`
- test `platform/tests/test_stage_conformance.py::test_conformance_lot_normalized`
- **limits** — The CONFIRMATION rule (histology, IHC, model-assisted selection with abstractor review) is not configurable and no engine code re-derives it — it describes how the vendor built the delivery, and is governed at Gate 1 and Gate 3 in a contract record naming the delivered table.

### `clinical.comorbidity_index` — COMORBIDITY_INDEX

A weighted comorbidity score: distinct matched conditions in a pre-index lookback, each counted ONCE however many times it is coded, weighted and summed, with an optional banded companion. The `supersedes` hierarchy is closed transitively over the original condition flags.

- config `clinical.comorbidity_index` — authored in `variables/clinical.yaml`
- python `comorbidity_index` in `platform/engine/stages/clinical.py`
- R `clinical_comorbidity_index` in `platform/engine-r/stages.R`
- emits `<name>`, `<name>gr`, `<name>grn`
- test `platform/tests/test_r_parity.py::test_parity_supersedes_closure_and_weight_cast`
- test `platform/tests/test_stages_spark.py::test_comorbidity_score_counts_conditions_once_and_honours_hierarchy`
- test `platform/tests/test_stages_spark.py::test_comorbidity_hierarchy_is_transitive_and_weights_are_not_truncated`
- **limits** — The engine ships NO code sets and NO weights. Quan-Charlson, NCI/Klabunde and Elixhauser each have ICD-9/ICD-10 variants and published revisions; an engine carrying one would choose the algorithm for every product silently. Conditions, codes, weights and the hierarchy all come from the workbook into the pack.

### `clinical.data_continuity` — DATA_CONTINUITY

The observability floor: the earliest activity date across the pack's declared sources (minavaildate) with its interval to index (basedur), and the potential-follow-up gate id3mosfu that every time-to-event variable is conditioned on.

- config `clinical.min_avail_date` — authored in `variables/clinical.yaml`
- config `outcomes.min_followup_days` — authored in `variables/outcomes.yaml`
- python `_min_avail_date` in `platform/engine/stages/clinical.py`
- python `build` in `platform/engine/stages/outcomes.py`
- R `clinical_min_avail_date` in `platform/engine-r/stages.R`
- emits `minavaildate`, `basedur`, `id3mosfu`
- test `platform/tests/test_stages_spark.py::test_min_avail_date_earliest_across_sources`
- test `platform/tests/test_stages_spark.py::test_outcomes_os`
- test `platform/tests/test_stage_conformance.py::test_conformance_min_avail_date`

### `clinical.death_date` — DEATH_DATE

The composite death date: partial dates (YYYY-MM, YYYY) imputed to the pack's stated day and month, conflicting mortality rows resolved by a NAMED policy, follow-up end taken as the greatest date across the pack's declared activity sources, and a death-within-window follow-up flag.

- config `clinical.death_date_imputation` — authored in `variables/clinical.yaml`
- python `follow_up_and_death` in `platform/engine/stages/clinical.py`
- python `_death_conflict_order` in `platform/engine/stages/clinical.py`
- R `clinical_follow_up_and_death` in `platform/engine-r/stages.R`
- emits `dthfl`, `dthdt`, `fued`, `dthfufl`
- test `platform/tests/test_stages_spark.py::test_follow_up_and_death`
- test `platform/tests/test_stages_spark.py::test_mortality_dedup_prefers_specific`
- test `platform/tests/test_stages_spark.py::test_mortality_conflict_policy_earliest`
- test `platform/tests/test_stages_spark.py::test_year_level_death_index_aware`
- test `platform/tests/test_formula_registry_parity.py::test_death_conflict_policy_parity_including_order`
- test `platform/tests/test_formula_registry_parity.py::test_followup_source_registry_parity`
- test `platform/tests/test_stage_conformance.py::test_conformance_follow_up_and_death`
- **limits** — A `follow_up_sources` entry naming a source the pack does not declare is SKIPPED, not refused, so a typo there silently SHORTENS follow-up for every patient instead of failing.

### `disease.symptoms` — DISEASE_SYMPTOMS

Constitutional or disease-defining symptoms used as a staging input — a property of the cancer, which is why it is not carried as a comorbidity.

- config `clinical.categoricals` — authored in `variables/clinical.yaml`
- python `_categorical_pick_windowed` in `platform/engine/stages/clinical.py`
- R `clinical_build` in `platform/engine-r/stages.R`
- emits `<name>`
- test `platform/tests/test_stages_spark.py::test_windowed_categorical_answers_the_value_at_index_not_the_latest_value`
- test `platform/tests/test_stage_conformance.py::test_conformance_clinical_build_categoricals`
- **limits** — The cited tests exercise shared engine machinery using other clinical families. They do not contain this family's own input, configured rule and expected output. No family-specific R stage conformance is claimed; the Python unit claim covers the shared implementation only. Scientific configuration and output still need review.

### `clinical.baseline_ecog` — ECOG_PS

The ECOG record nearest index inside the configured window, with the same-date tie broken by the configured date rule and then ALWAYS by worst grade; a tumour with no baseline_ecog table gets the configured missing label rather than a failure.

- config `clinical.baseline_ecog` — authored in `variables/clinical.yaml`
- python `baseline_ecog` in `platform/engine/stages/clinical.py`
- R `clinical_baseline_ecog` in `platform/engine-r/stages.R`
- emits `ecog`, `ecogn`
- test `platform/tests/test_stages_spark.py::test_baseline_ecog_unknown_vs_missing`
- test `platform/tests/test_stages_spark.py::test_baseline_ecog_same_date_tie_picks_worst_known`
- test `platform/tests/test_stage_conformance.py::test_conformance_ecog_equidistant_worst_value`
- test `platform/tests/test_stage_conformance.py::test_conformance_ecog_incumbent_date_first`

### `biomarkers.rearrangement` — GENE_REARRANGEMENT

A fusion or translocation as a panel entry, and the composite calls built over several of them — `match_any` names the components a double-hit or double-expressor call is made over.

- config `clinical.biomarkers` — authored in `variables/clinical.yaml`
- python `_closest_panel` in `platform/engine/stages/clinical.py`
- R `clinical_build` in `platform/engine-r/stages.R`
- emits `<name>`
- test `platform/tests/test_stages_spark.py::test_response_best_of_window_carries_its_assessment_date`
- test `platform/tests/test_stages_spark.py::test_record_selection_is_named_and_defaults_to_todays_behaviour`
- test `platform/tests/test_stage_conformance.py::test_conformance_clinical_build_categoricals`
- **limits** — The cited tests exercise shared engine machinery using other clinical families. They do not contain this family's own input, configured rule and expected output. No family-specific R stage conformance is claimed; the Python unit claim covers the shared implementation only. Scientific configuration and output still need review.

### `biomarkers.gene_variant` — GENE_VARIANT_STATUS

One panel entry per gene over the delivered biomarker name/value/date feed: the pack's `match_an y` names every spelling of the gene, `aggregate` resolves multiple results, and the fallthrough group is what keeps never-tested distinguishable from tested-and-negative.

- config `clinical.biomarkers` — authored in `variables/clinical.yaml`
- python `_closest_panel` in `platform/engine/stages/clinical.py`
- R `clinical_build` in `platform/engine-r/stages.R`
- emits `<name>`
- test `platform/tests/test_stages_spark.py::test_response_best_of_window_carries_its_assessment_date`
- test `platform/tests/test_stages_spark.py::test_record_selection_is_named_and_defaults_to_todays_behaviour`
- test `platform/tests/test_stage_conformance.py::test_conformance_clinical_build_categoricals`
- **limits** — The cited tests exercise shared engine machinery using other clinical families. They do not contain this family's own input, configured rule and expected output. No family-specific R stage conformance is claimed; the Python unit claim covers the shared implementation only. Scientific configuration and output still need review.

### `biomarkers.signature` — GENOMIC_SIGNATURE

A composite computed over a panel rather than a single locus. `match_any` IS the panel definitio n, which is what makes two products' HRD or MSI comparable instead of only similarly named.

- config `clinical.biomarkers` — authored in `variables/clinical.yaml`
- python `_closest_panel` in `platform/engine/stages/clinical.py`
- R `clinical_build` in `platform/engine-r/stages.R`
- emits `<name>`
- test `platform/tests/test_stages_spark.py::test_response_best_of_window_carries_its_assessment_date`
- test `platform/tests/test_stages_spark.py::test_record_selection_is_named_and_defaults_to_todays_behaviour`
- test `platform/tests/test_stage_conformance.py::test_conformance_clinical_build_categoricals`

### `histology.grade` — HISTOLOGIC_GRADE

A grade in the pack's named grading instrument, banded to published categories.

- config `clinical.categoricals` — authored in `variables/clinical.yaml`
- python `_categorical_pick_windowed` in `platform/engine/stages/clinical.py`
- R `clinical_build` in `platform/engine-r/stages.R`
- emits `<name>`
- test `platform/tests/test_stages_spark.py::test_windowed_categorical_answers_the_value_at_index_not_the_latest_value`
- test `platform/tests/test_stage_conformance.py::test_conformance_clinical_build_categoricals`
- **limits** — The cited tests exercise shared engine machinery using other clinical families. They do not contain this family's own input, configured rule and expected output. No family-specific R stage conformance is claimed; the Python unit claim covers the shared implementation only. Scientific configuration and output still need review.

### `histology.type` — HISTOLOGIC_TYPE

Delivered morphology grouped to the pack's published categories, picked at index rather than lat est.

- config `clinical.categoricals` — authored in `variables/clinical.yaml`
- python `_categorical_pick_windowed` in `platform/engine/stages/clinical.py`
- R `clinical_build` in `platform/engine-r/stages.R`
- emits `<name>`
- test `platform/tests/test_stages_spark.py::test_windowed_categorical_answers_the_value_at_index_not_the_latest_value`
- test `platform/tests/test_stage_conformance.py::test_conformance_clinical_build_categoricals`
- **limits** — The cited tests exercise shared engine machinery using other clinical families. They do not contain this family's own input, configured rule and expected output. No family-specific R stage conformance is claimed; the Python unit claim covers the shared implementation only. Scientific configuration and output still need review.

### `index.build` — INDEX_DATE

Materialises each configured index-date model onto the index source, windows the cohort to [index_start, index_end], and splits cohorts on the presence of `lot_number` — a line cohort indexes on its line start, an overall cohort on the configured index column. Every downstream window and endpoint is measured from the date this stage sets.

- config `data_product.study` — authored in `config/data_product.yaml`
- config `data_product.index_dates` — authored in `config/data_product.yaml`
- config `data_product.cohorts` — authored in `config/data_product.yaml`
- python `build` in `platform/engine/stages/index.py`
- python `load` in `platform/engine/stages/sources.py`
- python `Config` in `platform/engine/config.py`
- R `index_build` in `platform/engine-r/stages.R`
- emits `index_date`, `cohort`, `cohortn`
- test `platform/tests/test_stages_spark.py::test_index_overall_windowed`
- test `platform/tests/test_stages_spark.py::test_index_lot1_uses_line_start`
- test `platform/tests/test_stages_spark.py::test_derived_cohorts_appends_filtered_relabeled`
- test `platform/tests/test_stage_conformance.py::test_conformance_index_build_overall`

### `clinical.categorical_windowed` — INSURANCE_PAYER

The categorical value IN FORCE AT INDEX — the record nearest the index date inside a day-offset window, resolved per (patientid, index_date) so a patient indexed twice can legitimately carry two different values. `window_days` without `date_column` is refused rather than ignored.

- config `clinical.categoricals` — authored in `variables/clinical.yaml`
- python `_categorical_pick_windowed` in `platform/engine/stages/clinical.py`
- R `clinical_build` in `platform/engine-r/stages.R`
- emits `<name>`, `<name>n`
- test `platform/tests/test_stages_spark.py::test_windowed_categorical_answers_the_value_at_index_not_the_latest_value`
- test `platform/tests/test_r_parity.py::test_parity_selection_defaults_and_resolution`
- test `platform/tests/test_stage_conformance.py::test_conformance_clinical_build_categoricals`

### `clinical.lab_panels` — LAB_VALUES

Two closest-to-index panels over lab records: `labs` maps a delivered value to a published label and code, `lab_values` publishes the raw numeric value with a presence flag and the record date. Adding another analyte to either is config only.

- config `clinical.lab_values` — authored in `variables/clinical.yaml`
- config `clinical.labs` — authored in `variables/clinical.yaml`
- python `_closest_values_panel` in `platform/engine/stages/clinical.py`
- python `_closest_panel` in `platform/engine/stages/clinical.py`
- R `clinical_closest_values_panel` in `platform/engine-r/stages.R`
- emits `<name>`, `<name>v`, `<name>dt`
- test `platform/tests/test_r_parity.py::test_parity_record_date_basis_is_used_by_both_engines`
- test `platform/tests/test_r_parity.py::test_parity_closest_panel_block_names`
- test `platform/tests/test_stages_spark.py::test_an_unknown_selection_method_is_refused_not_defaulted`
- test `platform/tests/test_stage_conformance.py::test_conformance_labs_undated_open_window`

### `lot.normalized` — LINE_OF_THERAPY

Filters an already-derived line-of-therapy table by disease setting, drops excluded settings, renumbers the survivors and lower-cases the regimen names. It does NOT derive lines from drug episodes.

- **UPSTREAM REQUIRED** — the vendor must deliver `lot`; the engine does not build it.
- config `data_product.lot` — authored in `config/data_product.yaml`
- python `normalized` in `platform/engine/stages/lot.py`
- python `build` in `platform/engine/stages/treatment.py`
- R `lot_normalized` in `platform/engine-r/stages.R`
- R `treatment_build` in `platform/engine-r/stages.R`
- emits `lot<N>name`, `lot<N>sd`, `lot<N>ed`, `lot<N>cat`, `lot<N>catn`, `lotn`
- test `platform/tests/test_stages_spark.py::test_lot_normalized_mcrpc_only_and_deterministic`
- test `platform/tests/test_stages_spark.py::test_treatment_categorises_line`
- test `platform/tests/test_stages_spark.py::test_treatment_no_setting_model_aggregates_across_settings`
- test `platform/tests/test_stage_conformance.py::test_conformance_lot_normalized`
- test `platform/tests/test_stage_conformance.py::test_conformance_treatment_build_lines`
- **limits** — The VENDOR must deliver the derived `lot` table. Line construction from drug episodes — combination windows, gap rules, maintenance attribution, regimen naming — is not implemented in either engine, so a delivery without that table cannot produce these variables however the pack is configured.

### `disease.metastatic_sites` — METASTATIC_DISEASE

Presence of each configured metastatic site per (patientid, index_date). De-novo-versus-recurren t onset is a DIFFERENT question — an interval rule over diagnosis and metastasis dates — and is not this capability.

- config `clinical.metastatic_sites` — authored in `variables/clinical.yaml`
- python `_metastatic_sites` in `platform/engine/stages/clinical.py`
- R `clinical_metastatic_sites` in `platform/engine-r/stages.R`
- emits `<name>`
- test `platform/tests/test_r_parity.py::test_parity_record_date_basis_is_used_by_both_engines`
- test `platform/tests/test_stage_conformance.py::test_conformance_metastatic_sites`

### `outcomes.overall_survival` — OS

Overall survival in months from index to the death anchor for events and the censor anchor for non-events, gated on id3mosfu and NULL for patients who fail it. The three anchors are named columns from the death-date family, so OS cannot silently run on a different date basis.

- config `outcomes.overall_survival` — authored in `variables/outcomes.yaml`
- config `outcomes.min_followup_days` — authored in `variables/outcomes.yaml`
- python `build` in `platform/engine/stages/outcomes.py`
- R `outcomes_build` in `platform/engine-r/stages.R`
- emits `os`, `id3mosfu`
- test `platform/tests/test_stages_spark.py::test_outcomes_os`
- test `platform/tests/test_patient_goldens_spark.py::test_hand_computed_patients_come_out_exactly_as_computed`
- test `platform/tests/test_stage_conformance.py::test_conformance_outcomes_build_os`
- **limits** — The follow-up gate is ENGINE-FIXED: OS is conditioned on id3mosfu, derived from `min_followup_days`. There is no config key that turns the gate off.

### `demographics.practice_setting` — PRACTICE_SETTING

Community vs academic practice type, aggregated per patient across practice rows before mapping, so a patient seen at both reads as the combined value the map classifies.

- config `demographics.practice_map` — authored in `variables/demographics.yaml`
- python `build` in `platform/engine/stages/demographics.py`
- R `demographics_build` in `platform/engine-r/stages.R`
- emits `practic`, `practicn`
- test `platform/tests/test_r_parity.py::test_case_parity_race_eth_practice_maps`
- **limits** — Emitted ONLY when the pack declares a `practice` source; a pack carrying the map without the source lints clean and publishes nothing.

### `disease.primary_site` — PRIMARY_TUMOR_SITE

Site or sidedness of the primary tumour, grouped for reporting.

- config `clinical.categoricals` — authored in `variables/clinical.yaml`
- python `_categorical_pick_windowed` in `platform/engine/stages/clinical.py`
- R `clinical_build` in `platform/engine-r/stages.R`
- emits `<name>`
- test `platform/tests/test_stages_spark.py::test_windowed_categorical_answers_the_value_at_index_not_the_latest_value`
- test `platform/tests/test_stage_conformance.py::test_conformance_clinical_build_categoricals`
- **limits** — The cited tests exercise shared engine machinery using other clinical families. They do not contain this family's own input, configured rule and expected output. No family-specific R stage conformance is claimed; the Python unit claim covers the shared implementation only. Scientific configuration and output still need review.

### `disease.risk_score` — PROGNOSTIC_RISK_SCORE

A named prognostic index that arrives PRE-COMPUTED in the delivery, grouped to published risk ca tegories. A score the engine must compute from components is not this capability and is an engin e gap.

- config `clinical.categoricals` — authored in `variables/clinical.yaml`
- python `_categorical_pick_windowed` in `platform/engine/stages/clinical.py`
- R `clinical_build` in `platform/engine-r/stages.R`
- emits `<name>`
- test `platform/tests/test_stages_spark.py::test_windowed_categorical_answers_the_value_at_index_not_the_latest_value`
- test `platform/tests/test_stage_conformance.py::test_conformance_clinical_build_categoricals`
- **limits** — The cited tests exercise shared engine machinery using other clinical families. They do not contain this family's own input, configured rule and expected output. No family-specific R stage conformance is claimed; the Python unit claim covers the shared implementation only. Scientific configuration and output still need review.

### `biomarkers.protein_expression` — PROTEIN_EXPRESSION

A protein or receptor read by IHC, banded at the pack's own positivity cut-point. The threshold is the group boundary here rather than a constant anywhere in the engine, because it differs by study and by assay.

- config `clinical.biomarkers` — authored in `variables/clinical.yaml`
- python `_closest_panel` in `platform/engine/stages/clinical.py`
- R `clinical_build` in `platform/engine-r/stages.R`
- emits `<name>`
- test `platform/tests/test_stages_spark.py::test_response_best_of_window_carries_its_assessment_date`
- test `platform/tests/test_stages_spark.py::test_record_selection_is_named_and_defaults_to_todays_behaviour`
- test `platform/tests/test_stage_conformance.py::test_conformance_clinical_build_categoricals`
- **limits** — The cited tests exercise shared engine machinery using other clinical families. They do not contain this family's own input, configured rule and expected output. No family-specific R stage conformance is claimed; the Python unit claim covers the shared implementation only. Scientific configuration and output still need review.

### `demographics.race_ethnicity` — RACE_ETHNICITY

Delivered race and ethnicity values collapsed to the published category scheme, unknown level included, via the shared value-to-group CASE compiler.

- config `demographics.race_map` — authored in `variables/demographics.yaml`
- config `demographics.ethnicity_map` — authored in `variables/demographics.yaml`
- python `_map_case` in `platform/engine/stages/demographics.py`
- R `demographics_build` in `platform/engine-r/stages.R`
- emits `race`, `racen`, `eth`, `ethn`
- test `platform/tests/test_r_parity.py::test_case_parity_race_eth_practice_maps`

### `demographics.region` — REGION

State-to-region crosswalk, terminal fallthrough required.

- config `demographics.regions` — authored in `variables/demographics.yaml`
- python `_region_case` in `platform/engine/stages/demographics.py`
- R `demographics_build` in `platform/engine-r/stages.R`
- emits `regionl`, `regionln`
- test `platform/tests/test_r_parity.py::test_case_parity_region`

### `outcomes.progression` — RWPFS

Clinician-anchored real-world PFS: the first qualifying progression after index (any evidence column positive AND not pseudo-progression, beyond an exclusion window that keeps the prior line's progression out), event-defined as the earlier of progression and death, censored at follow-up end. PFS2 uses the second progression, de-duplicated so two records on one date cannot fill both.

- config `outcomes.progression` — authored in `variables/outcomes.yaml`
- python `_progression` in `platform/engine/stages/outcomes.py`
- python `_progression_pred` in `platform/engine/stages/outcomes.py`
- python `_rwpfs_gate` in `platform/engine/stages/outcomes.py`
- R `outcomes_progression` in `platform/engine-r/stages.R`
- emits `<flag>`, `<date>`, `<months>`
- test `platform/tests/test_stages_spark.py::test_progression_pfs_event_and_censor`
- test `platform/tests/test_stages_spark.py::test_progression_pfs2_dedupes_same_day_evidence`
- test `platform/tests/test_outcomes.py::test_rwpfs_gate_requires_clinic_note_after_index`
- test `platform/tests/test_r_parity.py::test_parity_progression_pred`
- **limits** — Clinician-anchored, not RECIST. The progression date is the one the abstractor recorded; nothing here re-reads imaging or applies response criteria.

### `outcomes.time_to_discontinuation` — RWTTD

Real-world time to treatment discontinuation for a line cohort, with the discontinuation flag keyed off the line's last-activity date and a recent-visit window (vis120) that separates a discontinued patient from one merely not seen lately.

- config `outcomes.line_outcomes` — authored in `variables/outcomes.yaml`
- config `outcomes.visit_recency_days` — authored in `variables/outcomes.yaml`
- python `_ttd_sql` in `platform/engine/stages/outcomes.py`
- python `_vis120` in `platform/engine/stages/outcomes.py`
- R `outcomes_vis120` in `platform/engine-r/stages.R`
- emits `ttd`, `trtdis`, `vis120`, `lastvisitdate`
- test `platform/tests/test_outcomes.py::test_ttd_sql_has_the_specs_inclusive_day`
- test `platform/tests/test_r_parity.py::test_parity_outcome_sql_builders`
- test `platform/tests/test_stages_spark.py::test_line_outcomes_maintenance_cohort_keys_off_maintenance_line`

### `clinical.response_panel` — RW_RESPONSE

Best response over a window: the closest-to-index panel with the in-window rows ranked by the pack's own category order (`pick: priority`) instead of by distance from index, optionally publishing the winning record's date.

- config `clinical.response` — authored in `variables/clinical.yaml`
- python `_closest_panel` in `platform/engine/stages/clinical.py`
- R `clinical_build` in `platform/engine-r/stages.R`
- emits `<name>`, `<name>n`, `<name>dt`
- test `platform/tests/test_r_parity.py::test_parity_record_date_basis_is_used_by_both_engines`
- test `platform/tests/test_stages_spark.py::test_response_best_of_window_carries_its_assessment_date`
- test `platform/tests/test_r_parity.py::test_parity_closest_panel_block_names`
- test `platform/tests/test_stage_conformance.py::test_conformance_clinical_build_categoricals`
- **limits** — A WINDOW IS NOT A LINE. Per-line response ("best confirmed response for line 2") needs the assessment joined to the line that was running, and no config expresses that — the DLBCL and myeloma per-line entries stay `engine_gap`. If two lines start inside the window, this returns one answer across both.

### `clinical.passthrough` — SEX

Carries a structured column through from the index source under its published name. Sex needs no dedicated family: it arrives as a delivered column, and a tumour restricted by sex has a restricted DELIVERED POPULATION, not a filter this pack applies.

- config `clinical.passthrough` — authored in `variables/clinical.yaml`
- python `_passthrough` in `platform/engine/stages/clinical.py`
- R `clinical_passthrough` in `platform/engine-r/stages.R`
- emits `<as>`
- test `platform/tests/test_stages_spark.py::test_passthrough_columns_and_presence_flag`
- test `platform/tests/test_r_parity.py::test_parity_presence_flag_sql`
- test `platform/tests/test_stage_conformance.py::test_conformance_passthrough_sex`
- **limits** — The engine SKIPS any listed column the source does not carry, so a delivered name wrong by one character is not an error — the variable simply never appears. Confirm the name against the data profile.

### `clinical.categorical_unwindowed` — SMOKING_STATUS

A standing categorical fact (smoking status, histology, grade) mapped from a source column to a published label and code, resolved across multiple records by date rather than by distance from index.

- config `clinical.categoricals` — authored in `variables/clinical.yaml`
- python `_categorical_pick` in `platform/engine/stages/clinical.py`
- R `clinical_build` in `platform/engine-r/stages.R`
- emits `<name>`, `<name>n`
- test `platform/tests/test_r_parity.py::test_case_parity_clinical_categoricals`
- test `platform/tests/test_stages_spark.py::test_record_selection_is_named_and_defaults_to_todays_behaviour`
- test `platform/tests/test_stage_conformance.py::test_conformance_clinical_build_categoricals`

### `staging.tnm_category` — TNM_CATEGORY

An individual T, N or M category picked at index, for a study that uses the components rather th an only the overall group.

- config `clinical.categoricals` — authored in `variables/clinical.yaml`
- python `_categorical_pick_windowed` in `platform/engine/stages/clinical.py`
- R `clinical_build` in `platform/engine-r/stages.R`
- emits `<name>`
- test `platform/tests/test_stages_spark.py::test_windowed_categorical_answers_the_value_at_index_not_the_latest_value`
- test `platform/tests/test_stage_conformance.py::test_conformance_clinical_build_categoricals`
- **limits** — The cited tests exercise shared engine machinery using other clinical families. They do not contain this family's own input, configured rule and expected output. No family-specific R stage conformance is claimed; the Python unit claim covers the shared implementation only. Scientific configuration and output still need review.

### `outcomes.time_to_next_treatment` — TTNT

Time to next treatment for a line cohort — the earlier of the next line's start and death, censored at follow-up end — with its event flag, plus the optional second-subsequent-treatment (TSST) pair.

- config `outcomes.line_outcomes` — authored in `variables/outcomes.yaml`
- python `_ttnt_sql` in `platform/engine/stages/outcomes.py`
- python `_ttntfl_sql` in `platform/engine/stages/outcomes.py`
- R `outcomes_build` in `platform/engine-r/stages.R`
- emits `ttnt`, `ttntfl`, `tsst`, `tsstfl`
- test `platform/tests/test_outcomes.py::test_ttnt_sql_has_next_uses_least_of_nextline_and_death`
- test `platform/tests/test_outcomes.py::test_ttnt_sql_no_next_line_falls_back_to_death`
- test `platform/tests/test_r_parity.py::test_parity_outcome_sql_builders`

### `disease.burden_feature` — TUMOR_BURDEN_FEATURE

A disease-extent or aggressiveness feature carrying a threshold — bulky disease, margin status, residual disease, blast percentage — grouped from the delivered categories.

- config `clinical.categoricals` — authored in `variables/clinical.yaml`
- python `_categorical_pick_windowed` in `platform/engine/stages/clinical.py`
- R `clinical_build` in `platform/engine-r/stages.R`
- emits `<name>`
- test `platform/tests/test_stages_spark.py::test_windowed_categorical_answers_the_value_at_index_not_the_latest_value`
- test `platform/tests/test_stage_conformance.py::test_conformance_clinical_build_categoricals`
- **limits** — The cited tests exercise shared engine machinery using other clinical families. They do not contain this family's own input, configured rule and expected output. No family-specific R stage conformance is claimed; the Python unit claim covers the shared implementation only. Scientific configuration and output still need review.

### `biomarkers.marker_value` — TUMOR_MARKER_VALUE

A measured tumour-marker quantity selected closest to index and banded. Units are the pack's to state: a label reading `<35 iU/L` against a raw cut-off of 35000 is a real defect this shape mak es visible before banding.

- config `clinical.lab_values` — authored in `variables/clinical.yaml`
- python `_closest_values_panel` in `platform/engine/stages/clinical.py`
- R `clinical_closest_values_panel` in `platform/engine-r/stages.R`
- emits `<name>`
- test `platform/tests/test_variables_scaffold.py::test_filled_skeleton_shapes_are_shapes_the_engine_accepts`
- test `platform/tests/test_stage_conformance.py::test_conformance_tumor_marker_windowed_highest`

## Families with no capability

Every master family the inventory instantiates has a capability entry.
