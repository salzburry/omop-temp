# R (sparklyr / dbplyr) mirror of engine/stages/*.py — the SECOND engine, for cross-validation.
#
# ============================ PARITY CONTRACT (read me) ============================
# The two engines share the SAME config/YAML. ALL config-driven business logic (the treatment
# codelist + every banding/mapping/stage CASE) is compiled by the SHARED, PROVEN helpers sourced
# below (codelists.R + cases.R), which tests/test_r_parity.py shows emit byte-identical Spark SQL to
# the Python engine. So the "codes" the R team reviews here ARE the same expressions PySpark runs.
#
# This file is the Spark ORCHESTRATION (reads / joins / windows / writes) around those expressions,
# written in the team's native sparklyr/dbplyr idiom (the original RWDP was R/dbplyr). It needs a
# Spark connection (sparklyr) + the `yaml` package for execution. The local conformance harness
# executes shared fixtures where R is installed and records skips where it is unavailable.
# Check the exact runtime receipt; local fixture parity does not establish delivered-data or
# distributed-environment acceptance.
# Where the Python stage builds an inline SQL string (clinical death/OS imputation, ECOG code map,
# BMI), the same string is built here line-for-line so a reviewer can diff R vs Python directly.
# ===================================================================================
#
# Load order (the caller — run_rwdp.R / tests — sources these first):
#   source("vendors.R"); source("vocabularies.R"); source("config.R"); source("codelists.R")
#   source("cases.R"); source("stages.R")

suppressPackageStartupMessages({
  # dplyr/dbplyr verbs + sparklyr are resolved at RUN time on the cluster (lazy: referenced only
  # inside functions), so sourcing this file in a plain R session does not require them.
})

# %>% comes from dplyr/magrittr on the cluster; bind it here too if present (no-op otherwise — the
# function bodies resolve %>% at call time once library(dplyr) is on the search path).
if (requireNamespace("magrittr", quietly = TRUE)) `%>%` <- magrittr::`%>%`

# --- sources: load ONLY declared tables, lower-case columns, derive advanceddiagnosisdate --------
# Mirrors engine/stages/sources.py::load.
load_sources <- function(sc, cfg) {
  srcs <- cfg_sources(cfg)
  union <- cfg_source_union(cfg)
  out <- list()
  for (name in names(srcs)) {
    if (!is.null(union)) {                                  # EC: read each source from every member
      disc <- union[["discriminator"]] %||% "db"           # schema, tag db=EDM/DOS, union_all (== union_func)
      parts <- lapply(union[["members"]], function(m) {
        p <- dplyr::tbl(sc, cfg_table_in(cfg, name, m[["schema"]]))
        # per member, BEFORE the bind: a within-member case collision must refuse
        # here, not fail ambiguously inside sdf_bind_rows far from the delivery that caused it
        dup_m <- colnames(p)[duplicated(tolower(colnames(p)))]
        if (length(dup_m) > 0) stop("source '", name, "' member schema '", m[["schema"]],
                                    "': columns collide once case is folded (",
                                    paste(dup_m, collapse = ", "),
                                    ") - refused before the union binds them")
        dplyr::mutate(p, !!disc := m[["flag"]])
      })
      # sdf_bind_rows aligns by NAME and fills missing columns with typed NA == Python
      # unionByName(allowMissingColumns=True); plain union_all would fail/diverge on a member whose
      # column set differs (the registry vs EDM case Python was made tolerant of).
      df <- Reduce(function(a, b) sparklyr::sdf_bind_rows(a, b), parts)
    } else {
      df <- dplyr::tbl(sc, cfg_table(cfg, name))            # vendor-resolved FQN (config.R)
    }
    dup_ci <- colnames(df)[duplicated(tolower(colnames(df)))]   # refuse before the fold
    if (length(dup_ci) > 0) stop("source '", name, "': delivered columns collide once case is folded (",
                                 paste(dup_ci, collapse = ", "),
                                 ") - lower-casing would mint duplicate columns")
    df <- dplyr::rename_with(df, tolower)                   # R: rename_with(tolower)
    ren <- cfg_source_renames(cfg)[[name]] %||% list()      # per-format column renames (Panoramic -> logical)
    for (phys in names(ren)) {
      p <- tolower(phys); lo <- tolower(ren[[phys]])
      if (p %in% colnames(df) && p != lo) {
        # a rename target that already exists would mint a duplicate the case-fold
        # check above never saw - refused at the plan, mirroring Python's rename_collisions
        if (lo %in% colnames(df)) stop("source '", name, "': rename ", p, " -> ", lo,
                                       " collides with an existing column - refused")
        df <- dplyr::rename(df, !!lo := !!rlang::sym(p))
      }
    }
    dup_after <- colnames(df)[duplicated(colnames(df))]     # the last gate on name uniqueness
    if (length(dup_after) > 0) stop("source '", name, "': duplicate column name(s) after ",
                                    "renames (", paste(dup_after, collapse = ", "),
                                    ") - later stages would resolve the ambiguity silently")
    out[[name]] <- df
  }
  # Materialize each index_dates model as a column on the index source (key without underscores;
  # advanced_diagnosis_date -> advanceddiagnosisdate). A dual-setting product adds hspc/crpc models so
  # each overall cohort indexes off its setting's date. Only where the rule's columns exist. == sources.py.
  isrc <- cfg_index_source(cfg)
  if (!is.null(out[[isrc]])) {
    for (key in names(cfg$raw[["index_dates"]] %||% list())) {
      rule <- cfg$raw[["index_dates"]][[key]]
      if (!is.list(rule)) next
      of <- tolower(unlist(rule[["of"]] %||% list()))
      present <- of[of %in% colnames(out[[isrc]])]
      if (length(present) == 0) next
      # greatest needs >=2 args, so a single present column IS the max — == sources.py
      expr <- if ((rule[["method"]] %||% "max") == "max" && length(present) > 1)
        sprintf("greatest(%s)", paste(present, collapse = ", ")) else present[1]
      out[[isrc]] <- dplyr::mutate(out[[isrc]], !!gsub("_", "", key) := dplyr::sql(expr))
    }
  }
  out
}

# A column name from config as an ORDERING SYMBOL. Config and locals carry these SQL-quoted
# (`` `_v` ``, `` `_rdate` ``) because they were built for `dplyr::sql()` strings; dbplyr 2.6.0
# takes only a bare column or `desc(col)` in `window_order`, so the quoting comes off here rather
# than at each of the call sites that need it.
.ordsym <- function(x) rlang::sym(gsub("`", "", as.character(x), fixed = TRUE))

# --- lot: the single source of new_lot_n. Mirrors engine/stages/lot.py (config-driven model). ----
lot_normalized <- function(src, line_setting = NULL, exclude_settings = list(), maintenance = NULL,
                           line_number_col = "new_lot_n", maintenance_column = "ismaintenancetherapy") {
  lot <- dplyr::mutate(src[["lot"]], linename = dplyr::sql("lower(linename)"))
  cols <- colnames(lot)
  if (!is.null(line_setting) && "linesetting" %in% cols)
    lot <- dplyr::filter(lot, linesetting == line_setting)
  if (length(exclude_settings) > 0 && "linesetting" %in% cols)
    lot <- dplyr::filter(lot, !(linesetting %in% unlist(exclude_settings)))
  if (!is.null(maintenance) && maintenance_column %in% cols)
    lot <- dplyr::filter(lot, dplyr::sql(sprintf("%s = '%s'", maintenance_column,
                                                 if (isTRUE(maintenance)) "True" else "False")))
  if (identical(line_number_col, "linenumber"))
    return(dplyr::mutate(lot, new_lot_n = linenumber))      # OC/EC: raw LOT line number
  # Default (prostate): derive new_lot_n; deterministic tie-break (== PySpark Window orderBy).
  # EXACT DUPLICATES ARE ONE LINE and NULL STARTS SORT LAST — mirroring stages/lot.py, where an
  # audit found bare ASC (nulls FIRST) letting an undated row become line 1, and a repeated
  # delivery row occupying two line numbers.
  # Typed ordering + null starts take NO line number, mirroring stages/lot.py exactly.
  #
  # THE TIE-BREAK REMAINDER WAS MISSING, and lot.py says why it exists: "The keys below are not a
  # TOTAL order: two rows agreeing on all of them still swap `new_lot_n`, observable through any
  # column outside them (`ismaintenancetherapy` is the live example)." Python orders on the four
  # keys and then on EVERY remaining column; R ordered on the four alone, so two engines could
  # number tied rows differently — a silent divergence, invisible until the stage-conformance
  # harness ran R for the first time.
  #
  # AND THE ORDERING IS EXPRESSED IN COLUMNS, NOT SQL. `dbplyr::window_order` (2.6.0) takes only a
  # bare column or `desc(col)` — a `sql()` argument is refused outright ("Element 1 is `<sql>`"),
  # which is what took nine of thirteen conformance cases down. `asc_nulls_last` is rebuilt from
  # what the backend does accept: a NULL flag sorts FALSE(0) before TRUE(1), so ordering on
  # (flag, value) puts non-nulls first and nulls last — the same rule, stated in columns. Verified
  # against dbplyr 2.6.0 (the CI version) to emit
  #   ORDER BY `_nl1`, `_lot_sd`, `_nl2`, linenumber, `_nl3`, enddate, `_nl4`, linename, <rest…>
  # The helper columns are dropped, so the output shape is unchanged.
  lot <- lot %>%
    dplyr::distinct() %>%
    dplyr::mutate(`_lot_sd` = dplyr::sql("try_cast(startdate as date)"))
  keyed <- c("patientid", "_lot_sd", "startdate", "linenumber", "enddate", "linename")
  rest  <- setdiff(colnames(lot), keyed)
  ordc  <- c("_lot_sd", "linenumber", "enddate", "linename", rest)
  flags <- paste0("_nl", seq_along(ordc))
  lot <- lot %>% dplyr::mutate(!!!rlang::set_names(
    lapply(ordc, function(k) rlang::expr(is.na(!!rlang::sym(k)))), flags))
  ord <- unlist(Map(function(f, k) list(rlang::sym(f), rlang::sym(k)), flags, ordc),
                recursive = FALSE, use.names = FALSE)
  lot %>%
    dplyr::group_by(patientid) %>%
    dbplyr::window_order(!!!ord) %>%
    dplyr::mutate(new_lot_n = dplyr::if_else(is.na(`_lot_sd`), NA_integer_,
                                             as.integer(dplyr::row_number()))) %>%
    dplyr::ungroup() %>%
    # dplyr::all_of, not tidyselect::all_of — dplyr re-exports it, and tidyselect appears nowhere
    # else in this engine. A stage is not the place to add a namespace the runner does not already
    # load.
    dplyr::select(-dplyr::all_of(c("_lot_sd", flags)))
}

# --- index: overall = advanceddiagnosisdate in window; lotN = line-N start. engine/stages/index.py -
index_build <- function(src, cfg, cohort) {
  start <- cfg_index_period_start(cfg)     # enrollment window (== index.py)
  end   <- cfg_index_period_end(cfg)
  enh   <- src[[cfg_index_source(cfg)]]
  # CAST FIRST, FILTER SECOND — mirroring stages/index.py: comparing a raw string column with a
  # date makes the engine cast implicitly (NULL and a vanished row on ANSI-off; a RAISE on
  # ANSI-on). try_cast makes the exclusion a stated rule on a typed value.
  in_window <- function(df, col)
    dplyr::filter(df, dplyr::sql(sprintf(
      "try_cast(%s as date) >= date('%s') AND try_cast(%s as date) <= date('%s')",
      col, start, col, end)))

  if (is.null(cohort[["lot_number"]])) {            # overall = any cohort without a lot_number; it
    dcol <- gsub("_", "", cohort[["index"]] %||% "advanced_diagnosis_date")   # indexes off its model col
    return(enh %>%
      in_window(dcol) %>%
      dplyr::transmute(patientid,
                       index_date = dplyr::sql(sprintf("try_cast(%s as date)", dcol)),
                       advanceddiagnosisdate = dplyr::sql(dcol)) %>%
      dplyr::distinct())
  }
  lot_number <- cohort[["lot_number"]]
  lot_norm <- lot_normalized(src, cohort[["line_setting"]] %||% cfg_lot_line_setting(cfg),
                             exclude_settings   = cfg_lot_exclude_settings(cfg),
                             maintenance        = cohort[["maintenance"]],
                             line_number_col    = cfg_lot_line_number_col(cfg),
                             maintenance_column = cfg_lot_maintenance_column(cfg)) %>%
    in_window("startdate") %>%
    dplyr::filter(new_lot_n == lot_number) %>%
    dplyr::select(patientid, linename, linenumber, startdate, enddate, new_lot_n)
  dcol <- gsub("_", "", cohort[["diag"]] %||% "advanced_diagnosis_date")   # setting diagnosis anchor
  enh_index <- enh %>% in_window(dcol) %>%
    dplyr::transmute(patientid, advanceddiagnosisdate = dplyr::sql(dcol))
  dplyr::inner_join(lot_norm, enh_index, by = "patientid") %>%
    dplyr::mutate(index_date = dplyr::sql("try_cast(startdate as date)")) %>%
    dplyr::select(patientid, index_date, advanceddiagnosisdate,
                  linenumber, linename, startdate, enddate, new_lot_n) %>%
    dplyr::distinct()
}

# --- demographics: age band + region/race/eth/practice/SES. engine/stages/demographics.py --------
demographics_build <- function(src, idx, cfg) {
  dem <- cfg_pack(cfg, "demographics")
  df <- dplyr::left_join(dplyr::select(idx, patientid, index_date),
                         src[["demographics"]], by = "patientid")
  if (!is.null(src[["ses"]]))      df <- dplyr::left_join(df, src[["ses"]], by = "patientid")
  if (!is.null(src[["practice"]])) {
    agg <- src[["practice"]] %>% dplyr::group_by(patientid) %>%
      dplyr::summarise(practicetype_agg =
        dplyr::sql("concat_ws(',', sort_array(collect_set(upper(practicetype))))")) %>%
      dplyr::ungroup()
    df <- dplyr::left_join(df, agg, by = "patientid")
  }
  df <- df %>%
    dplyr::mutate(year_index = dplyr::sql("year(index_date)"),
                  age = dplyr::sql("year(index_date) - cast(birthyear as int)")) %>%
    dplyr::mutate(
      agegrl  = dplyr::sql(bands_case(dem[["age_bands"]], "age", "label")),
      agegrln = dplyr::sql(bands_case(dem[["age_bands"]], "age", "code")),
      # eth BEFORE race - an or_column: race entry must read the RAW value (G-ETHNICITY-OR);
      # dbplyr's sequential mutate would otherwise hand it the mapped label. == demographics.py.
      eth     = dplyr::sql(map_case(dem[["ethnicity_map"]], "ethnicity", "label")),
      ethn    = dplyr::sql(map_case(dem[["ethnicity_map"]], "ethnicity", "code")),
      race    = dplyr::sql(map_case(dem[["race_map"]], "race", "label")),
      racen   = dplyr::sql(map_case(dem[["race_map"]], "race", "code")),
      regionl = dplyr::sql(region_case(dem[["regions"]], "state", "label")),
      regionln= dplyr::sql(region_case(dem[["regions"]], "state", "code")))
  # G-REGION-ACADEMIC == demographics.py: academic-only -> the declared Unknown group;
  # the override must point into a declared regions group, and it makes practice HARD.
  ov <- dem[["region_practice_override"]]
  if (!is.null(ov)) {
    val <- ov[["when_practice_agg"]]; into <- ov[["into"]]
    if (is.null(val) || is.null(into))
      stop("demographics.region_practice_override needs `when_practice_agg` and `into`")
    grp <- NULL
    for (g in dem[["regions"]] %||% list())
      if (identical(as.character(g[["when"]]), as.character(into))) { grp <- g; break }
    if (is.null(grp))
      stop(sprintf("region_practice_override: `into: %s` names no regions group with that `when` role", into))
    if (is.null(src[["practice"]]))
      stop("BUILD REFUSED - region_practice_override is declared and the practice source was not given")
    cond <- sprintf("UPPER(practicetype_agg) = %s", .sql_str(toupper(as.character(val))))
    df <- df %>% dplyr::mutate(
      regionl  = dplyr::sql(sprintf("CASE WHEN %s THEN %s ELSE regionl END", cond, .sql_str(as.character(grp[["label"]])))),
      regionln = dplyr::sql(sprintf("CASE WHEN %s THEN %s ELSE regionln END", cond, grp[["code"]])))
  }
  keep <- c("patientid", "index_date", "age", "agegrl", "agegrln", "race", "racen",
            "eth", "ethn", "regionl", "regionln")
  if (!is.null(src[["practice"]])) {
    df <- df %>% dplyr::mutate(
      practic  = dplyr::sql(map_case(dem[["practice_map"]], "practicetype_agg", "label")),
      practicn = dplyr::sql(map_case(dem[["practice_map"]], "practicetype_agg", "code")))
    keep <- c(keep, "practic", "practicn")
  }
  ses <- dem[["ses"]] %||% list()
  if (!is.null(ses[["source_column"]]) && !is.null(src[["ses"]])) {   # need the ses SOURCE, not just config
    df <- dplyr::mutate(df, ses = dplyr::sql(sprintf("coalesce(cast(%s as string), %s)",
      ses[["source_column"]], .sql_str(ses[["missing_label"]] %||% "Missing"))))
    keep <- c(keep, "ses")
  }
  dplyr::select(df, dplyr::all_of(keep))
}

# --- clinical: baseline ECOG. engine/stages/clinical.py::baseline_ecog --------------------------
clinical_baseline_ecog <- function(src, idx, ecog_cfg, cohort = NULL) {
  lo <- ecog_cfg[["window_days"]][[1]]; hi <- ecog_cfg[["window_days"]][[2]]
  miss <- ecog_cfg[["missing_label"]]; miss_code <- ecog_cfg[["missing_code"]]
  # G-ECOG halves == clinical.py::baseline_ecog: union with baseline precedence, and the
  # line-association filter for a cohort declaring ecog_line_match.
  lm_col <- (ecog_cfg[["line_match"]] %||% list())[["startdate_column"]]
  use_lm <- isTRUE(cohort[["ecog_line_match"]])
  if (use_lm && is.null(lm_col))
    stop("BUILD REFUSED - a cohort declares ecog_line_match and baseline_ecog.line_match",
         ".startdate_column does not name the line-start column")
  cols <- c("patientid", "ecogdate", "ecogvalue", if (use_lm) lm_col)
  take <- function(role) {
    t <- src[[role]]
    if (is.null(t))
      stop(sprintf("BUILD REFUSED - baseline_ecog reads source '%s', not given", role))
    absent <- setdiff(cols, colnames(t))
    if (length(absent))
      stop(sprintf("BUILD REFUSED - '%s' lacks column(s) %s that the declared ECOG rules read",
                   role, paste(absent, collapse = ", ")))
    dplyr::select(t, dplyr::all_of(cols))
  }
  ecog_src <- take("baseline_ecog")
  us <- ecog_cfg[["union_source"]]
  if (!is.null(us)) {
    ecog_src <- dplyr::union_all(dplyr::mutate(ecog_src, `_origin` = 0L),
                                 dplyr::mutate(take(us), `_origin` = 1L)) %>%
      dplyr::group_by(patientid, ecogdate) %>%
      dbplyr::window_order(`_origin`, dplyr::desc(ecogvalue)) %>%
      dplyr::mutate(`_dup` = dplyr::row_number()) %>% dplyr::ungroup() %>%
      dplyr::filter(`_dup` == 1) %>% dplyr::select(-`_dup`, -`_origin`)
  }
  # present null/Unknown -> 'Unknown' (NOT 'Missing'); numeric path RLIKE-guarded (== clinical.py).
  label <- paste0(
    "CASE WHEN ecogvalue IS NULL THEN 'Unknown' ",
    "WHEN lower(trim(cast(ecogvalue as string))) = 'unknown' THEN 'Unknown' ",
    "WHEN cast(ecogvalue as string) rlike '^[0-9]+([.]0+)?$' ",
    "  THEN cast(cast(cast(ecogvalue as double) as int) as string) ",
    "ELSE 'Unknown' END")
  pulled <- dplyr::select(idx, patientid, index_date) %>%
    dplyr::inner_join(ecog_src, by = "patientid") %>%
    dplyr::filter(dplyr::sql(sprintf(
      "ecogdate >= date_add(index_date, %s) AND ecogdate <= date_add(index_date, %s)", lo, hi))) %>%
    dplyr::mutate(gap = dplyr::sql("abs(datediff(ecogdate, index_date))")) %>%
    { if (use_lm) dplyr::filter(., dplyr::sql(sprintf("%s = index_date", lm_col))) else . } %>%
    # 6-step final tie-break: worst (max) ECOG wins a same-gap+same-date tie; Unknown ranks last.
    dplyr::mutate(`_rank` = dplyr::sql(paste0(
      "CASE WHEN cast(ecogvalue as string) rlike '^[0-9]+([.]0+)?$' ",
      "THEN cast(cast(ecogvalue as double) as int) ELSE -1 END")))
  # `equidistant: worst_value` == clinical.py::baseline_ecog: severity outranks the date
  # direction at equal gap, date as the deterministic fallback; absent -> the incumbent
  # ordering below, byte-identical. An unrecognised word REFUSES rather than approximating
  # a clinical rule with the nearest behaviour.
  equi <- ecog_cfg[["equidistant"]]
  if (!is.null(equi) && !identical(equi, "worst_value"))
    stop(sprintf(paste0("BUILD REFUSED - baseline_ecog.equidistant '%s' is not 'worst_value'",
                        " - an unrecognised tie rule silently approximated is a clinical",
                        " definition nobody chose."), equi))
  nearest <- pulled %>% dplyr::group_by(patientid, index_date)
  nearest <- if (!is.null(equi))
    dbplyr::window_order(nearest, gap, dplyr::desc(`_rank`), ecogdate)
  else if (identical(ecog_cfg[["tie_break"]], "latest_date"))   # date direction among same-gap
    dbplyr::window_order(nearest, gap, dplyr::desc(ecogdate), dplyr::desc(`_rank`))
  else dbplyr::window_order(nearest, gap, ecogdate, dplyr::desc(`_rank`))
  nearest <- nearest %>%
    dplyr::mutate(rn = dplyr::row_number()) %>%
    dplyr::ungroup() %>%
    dplyr::filter(rn == 1) %>%
    dplyr::mutate(ecog = dplyr::sql(label)) %>%
    dplyr::select(patientid, index_date, ecog)
  code_when <- paste(vapply(names(ecog_cfg[["value_codes"]]),
    function(k) sprintf("WHEN ecog = %s THEN %s", .sql_str(k), ecog_cfg[["value_codes"]][[k]]), ""),
    collapse = " ")
  dplyr::select(idx, patientid, index_date) %>%
    dplyr::left_join(nearest, by = c("patientid", "index_date")) %>%
    dplyr::mutate(ecog  = dplyr::sql(sprintf("coalesce(ecog, %s)", .sql_str(miss))),
                  ecogn = dplyr::sql(sprintf("CASE %s ELSE %s END", code_when, miss_code))) %>%
    dplyr::select(patientid, index_date, ecog, ecogn)
}

# --- clinical: config-driven enhanced pass-through + presence flags. == clinical.py::_passthrough --
clinical_passthrough <- function(src, idx, blk, index_source) {
  isrc <- src[[blk[["source"]] %||% index_source]]
  if (is.null(isrc)) return(NULL)
  ec <- colnames(isrc)
  cols  <- Filter(function(c) c[["column"]] %in% ec, blk[["columns"]] %||% list())
  flags <- Filter(function(f) f[["from"]] %in% ec, blk[["flags"]] %||% list())
  if (length(cols) == 0 && length(flags) == 0) return(NULL)
  raw <- unique(c(vapply(cols, function(c) c[["column"]], ""), vapply(flags, function(f) f[["from"]], "")))
  e <- isrc %>% dplyr::select(patientid, dplyr::all_of(raw)) %>% dplyr::distinct(patientid, .keep_all = TRUE)
  out <- idx %>% dplyr::select(patientid, index_date) %>% dplyr::left_join(e, by = "patientid")
  keep <- c("patientid", "index_date")
  for (c in cols) {
    nm <- c[["as"]] %||% c[["column"]]
    if (!is.null(c[["bands"]])) {              # categorize a numeric enhanced column (e.g. Gleason score)
      out <- out %>% dplyr::mutate(
        !!nm := dplyr::sql(num_bands_case(c[["bands"]], c[["column"]], "label")),
        !!paste0(nm, "n") := dplyr::sql(num_bands_case(c[["bands"]], c[["column"]], "code")))
      keep <- c(keep, nm, paste0(nm, "n"))
    } else {
      out <- out %>% dplyr::mutate(!!nm := !!rlang::sym(c[["column"]]))
      keep <- c(keep, nm)
    }
  }
  for (f in flags) { out <- out %>% dplyr::mutate(!!f[["name"]] := dplyr::sql(presence_flag_sql(f))); keep <- c(keep, f[["name"]]) }
  dplyr::select(out, dplyr::all_of(keep))
}

# --- clinical: derived durations (months/days between dated milestones). == clinical.py::_durations ----
clinical_durations <- function(src, idx, blk, index_source) {
  isrc <- src[[blk[["source"]] %||% index_source]]
  if (is.null(isrc)) return(NULL)
  dpm <- as.numeric(blk[["days_per_month"]] %||% 30.4375); ec <- colnames(isrc)
  avail <- function(c) identical(c, "index_date") || c %in% ec
  items <- Filter(function(it) avail(it[["from"]]) && avail(it[["to"]]), blk[["items"]] %||% list())
  if (length(items) == 0) return(NULL)
  cols <- setdiff(unique(unlist(lapply(items, function(it) c(it[["from"]], it[["to"]])))), "index_date")
  e <- isrc %>% dplyr::select(patientid, dplyr::all_of(cols)) %>% dplyr::distinct(patientid, .keep_all = TRUE)
  out <- idx %>% dplyr::select(patientid, index_date) %>% dplyr::left_join(e, by = "patientid")
  for (it in items) {
    days <- sprintf("datediff(%s, %s)", it[["to"]], it[["from"]])
    out <- out %>% dplyr::mutate(!!it[["name"]] := dplyr::sql(
      if (identical(it[["unit"]], "days")) days else sprintf("(%s)/%s", days, dpm)))
  }
  dplyr::select(out, patientid, index_date, dplyr::all_of(vapply(items, function(it) it[["name"]], "")))
}

# --- clinical: data-availability floor (minavaildate/basedur). == clinical.py::_min_avail_date -----
clinical_min_avail_date <- function(src, idx, blk, index_source) {
  parts <- idx %>% dplyr::select(patientid, index_date); cols <- c()
  isrc <- src[[index_source]]
  for (bc in (blk[["base_columns"]] %||% list())) {
    if (!is.null(isrc) && bc %in% colnames(isrc)) {
      nm <- paste0("_b_", bc)
      b <- isrc %>% dplyr::transmute(patientid, !!nm := !!rlang::sym(bc)) %>% dplyr::distinct(patientid, .keep_all = TRUE)
      parts <- dplyr::left_join(parts, b, by = "patientid"); cols <- c(cols, nm)
    }
  }
  srcs <- blk[["sources"]] %||% list()
  for (i in seq_along(srcs)) {
    s <- srcs[[i]]; sd <- src[[s[["source"]]]]
    if (is.null(sd)) next
    dcs <- Filter(function(d) !is.null(d) && d %in% colnames(sd),
                  s[["date_columns"]] %||% list(s[["date_column"]]))
    if (length(dcs) == 0) next
    row_date <- if (length(dcs) > 1) sprintf("least(%s)", paste(unlist(dcs), collapse = ", ")) else dcs[[1]]
    nm <- paste0("_f", i)
    agg <- sd %>% dplyr::group_by(patientid) %>%
      dplyr::summarise(!!nm := dplyr::sql(sprintf("min(%s)", row_date)), .groups = "drop")
    parts <- dplyr::left_join(parts, agg, by = "patientid"); cols <- c(cols, nm)
  }
  if (length(cols) == 0) return(NULL)
  parts %>%
    dplyr::mutate(minavaildate = dplyr::sql(          # least needs >=2 args — == clinical.py
      if (length(cols) > 1) sprintf("least(%s)", paste(cols, collapse = ", ")) else cols[[1]]),
                  basedur = dplyr::sql("datediff(index_date, minavaildate)")) %>%
    dplyr::select(patientid, index_date, minavaildate, basedur)
}

# --- clinical: OC surgery sub-block. == engine/stages/clinical.py::_surgery -----------------------
clinical_surgery <- function(src, idx, scfg) {
  enh <- src[[scfg[["source"]]]]; lot <- src[[scfg[["line_source"]] %||% "lot"]]
  if (is.null(enh) || is.null(lot)) return(NULL)
  fl <- scfg[["surgery_flag_column"]]; dt <- scfg[["surgery_date_column"]]
  init <- scfg[["init_date_column"]] %||% "diagnosisdate"; size <- scfg[["size_column"]]
  ecols <- Filter(function(c) !is.null(c) && c %in% colnames(enh), c("patientid", fl, dt, init, size))
  first_per_patient <- function(df, order_col) {        # one deterministic row/patient (== _first in py)
    # NULLS LAST, AND TOTAL — the same two rules clinical.py's `_first` carries, stated in columns
    # because window_order accepts only bare columns: an `is.na` flag per key sorts FALSE before
    # TRUE, so (flag, key) is asc_nulls_last; and every remaining column follows the named one so
    # two rows tied on it cannot be numbered by shuffle order. Before this, R ordered on the bare
    # date alone — an undated row won "first", and ties were nondeterministic (external audit,
    # 2026-09-02). The helper columns are dropped, so the output shape is unchanged.
    ordc  <- c(order_col, setdiff(colnames(df), c(order_col, "patientid")))
    flags <- paste0("_nl", seq_along(ordc))
    df <- df %>% dplyr::mutate(!!!rlang::set_names(
      lapply(ordc, function(k) rlang::expr(is.na(!!rlang::sym(k)))), flags))
    ord <- unlist(Map(function(f, k) list(rlang::sym(f), rlang::sym(k)), flags, ordc),
                  recursive = FALSE, use.names = FALSE)
    df %>% dplyr::group_by(patientid) %>% dbplyr::window_order(!!!ord) %>%
      dplyr::mutate(`_rn` = dplyr::row_number()) %>% dplyr::ungroup() %>%
      dplyr::filter(`_rn` == 1) %>% dplyr::select(-`_rn`, -dplyr::all_of(flags))
  }
  e <- first_per_patient(enh %>% dplyr::select(dplyr::all_of(ecols)), dt)
  l1 <- lot %>% dplyr::filter(!!rlang::sym(scfg[["line_number_column"]] %||% "linenumber") == 1)
  mnt <- scfg[["maintenance_column"]]
  if (!is.null(mnt) && mnt %in% colnames(lot))
    l1 <- l1 %>% dplyr::filter(dplyr::sql(sprintf("lower(cast(%s as string)) != 'true'", mnt)))
  l1 <- first_per_patient(
    l1 %>% dplyr::transmute(patientid, `_line1_start` = !!rlang::sym(scfg[["line_start_column"]]),
                            `_line1_end` = !!rlang::sym(scfg[["line_end_column"]])), "_line1_start")
  j <- idx %>% dplyr::select(patientid, index_date) %>%
    dplyr::left_join(e, by = "patientid") %>% dplyr::left_join(l1, by = "patientid")
  sql <- surgery_sql(scfg)
  j <- j %>% dplyr::mutate(issurg = dplyr::sql(sql$issurg), surg = dplyr::sql(sql$surg),
                           surgn = dplyr::sql(sql$surgn), neoadj = dplyr::sql(sql$neoadj))
  keep <- c("patientid", "index_date", "issurg", "surg", "surgn", "neoadj")
  if (init %in% colnames(j)) {
    j <- j %>% dplyr::mutate(tt_first_tx_diag = dplyr::sql(
      sprintf("datediff(least(%s, _line1_start), %s)", dt, init)))
    keep <- c(keep, "tt_first_tx_diag")
  }
  if (!is.null(size) && size %in% colnames(j)) keep <- c(keep, size)
  dplyr::select(j, dplyr::all_of(keep))
}

# Named body-composition formulas — mirrors engine/stages/clinical.py BMI_FORMULAS / BSA_FORMULAS.
# Config `vitals.bmi_method` / `vitals.bsa_method` NAME one; the engine resolves and compiles it (config
# never carries the raw formula). height in cm, weight in kg.
BMI_FORMULAS <- list(
  standard = "weight / pow(height/100, 2)"                             # WHO: kg / m^2
)
BSA_FORMULAS <- list(
  dubois = "0.007184 * pow(height, 0.725) * pow(weight, 0.425)"        # Du Bois & Du Bois (1916)
  # (Mosteller etc. are added here when an approved product asks for them — not kept speculatively.)
)

# Named follow-up row filters — mirrors engine/stages/clinical.py FOLLOWUP_FILTERS: name -> predicate SQL.
FOLLOWUP_FILTERS <- list(
  valid_oral_end = "(startdategranularity <> 'Year' OR startdategranularity IS NULL) AND enddate IS NOT NULL"
)

# Named unit conversions — mirrors engine/stages/clinical.py UNIT_CONVERSIONS. Config maps a
# DELIVERED unit spelling to one of these names and the engine compiles the arithmetic; a factor
# written in config would be an unreviewed clinical constant. `{v}` is the value expression.
# Mass-to-molar conversions are deliberately absent: they need an analyte-specific constant, the
# first two anyone asks for are contested (haemoglobin monomer-vs-tetramer, BUN-vs-urea), and no
# committed pack needs one. Held equal to the Python registry by test_formula_registry_parity.
UNIT_CONVERSIONS <- list(
  identity         = "{v}",                     # the delivered unit already IS the canonical one
  per_1000         = "{v} / 1000",              # e.g. iU/L -> kU/L, mg/dL -> g/dL
  times_1000       = "{v} * 1000",              # e.g. g/dL -> mg/dL
  per_10           = "{v} / 10",                # e.g. g/L -> g/dL
  times_10         = "{v} * 10",                # e.g. g/dL -> g/L
  per_100          = "{v} / 100",
  times_100        = "{v} * 100",
  k_ul_to_10e9_l   = "{v}",                     # 10^3/uL == 10^9/L, exactly
  per_ul_to_10e9_l = "{v} / 1000"               # 1/uL == 10^6/L == 10^-3 * 10^9/L
)

# == clinical.py unit_conversion_case. Per ITEM, because one unit_column serves analytes that each
# arrive in their own units. An unmapped unit yields NULL rather than the raw number — passing an
# unrecognised unit through unconverted is how a 1000x error reaches a band.
unit_conversion_case <- function(item, unit_col, value_expr) {
  mapping <- item[["unit_conversions"]]
  if (is.null(mapping) || length(mapping) == 0) return(NULL)
  delivered <- sort(names(mapping))
  whens <- vapply(delivered, function(d) {
    expr <- resolve_formula(UNIT_CONVERSIONS, mapping[[d]], "unit conversion")
    sprintf("WHEN LOWER(%s) = %s THEN %s", unit_col, .sql_str(tolower(d)),
            gsub("{v}", value_expr, expr, fixed = TRUE))
  }, character(1))
  paste0("CASE ", paste(whens, collapse = " "), " ELSE NULL END")
}

resolve_formula <- function(registry, name, kind) {
  key <- as.character(name)
  if (is.null(registry[[key]]))
    stop(sprintf("unknown %s method '%s'; valid: %s", kind, key, paste(names(registry), collapse = ", ")))
  registry[[key]]
}

resolve_followup_filter <- function(s) {
  fm <- s[["filter_method"]]
  if (!is.null(fm)) {
    if (is.null(FOLLOWUP_FILTERS[[fm]]))
      stop(sprintf("unknown follow_up filter_method '%s'; valid: %s", fm,
                   paste(names(FOLLOWUP_FILTERS), collapse = ", ")))
    return(FOLLOWUP_FILTERS[[fm]])
  }
  s[["filter"]]
}

# --- clinical: baseline BMI from vitals. engine/stages/clinical.py::vitals ----------------------
clinical_vitals <- function(src, idx, vcfg) {
  ht <- toupper(vcfg[["height_test"]]); wt <- toupper(vcfg[["weight_test"]])
  base <- dplyr::select(idx, patientid, index_date)
  pull <- base %>%
    dplyr::inner_join(src[["vitals"]], by = "patientid") %>%
    dplyr::mutate(test_u = dplyr::sql("upper(test)")) %>%
    dplyr::filter(dplyr::sql(sprintf(paste0(
      "(((test_u = %s AND testunitscleaned = 'cm') OR ",
      "  (test_u = %s AND testunitscleaned = 'kg')) AND testresultcleaned > 0)"),
      .sql_str(ht), .sql_str(wt)))) %>%
    dplyr::mutate(vitaldate = dplyr::sql("greatest(testdate, resultdate)")) %>%
    dplyr::filter(dplyr::sql("vitaldate <= index_date"))
  closest <- pull %>%
    dplyr::group_by(patientid, index_date, test_u) %>%
    # A TOTAL ORDER — mirrors the Python comment in `stages/clinical.py`. Ordering on vitaldate
    # alone left testresultcleaned, the value this emits, outside the order, so two weights on one
    # date returned whichever row came first. Both engines order the same way or parity hides it.
    # same-day tie -> HIGHEST value: the spec's rule (G-VITALS-DATES), == clinical.py
    dbplyr::window_order(dplyr::desc(vitaldate), dplyr::desc(testresultcleaned)) %>%
    dplyr::mutate(rn = dplyr::row_number()) %>%
    dplyr::ungroup() %>% dplyr::filter(rn == 1)
  # heightdt/weightdt: the winning record's date rides beside its value. == clinical.py
  h <- closest %>% dplyr::filter(dplyr::sql(sprintf("test_u = %s", .sql_str(ht)))) %>%
    dplyr::transmute(patientid, index_date, height = testresultcleaned, heightdt = vitaldate)
  g <- closest %>% dplyr::filter(dplyr::sql(sprintf("test_u = %s", .sql_str(wt)))) %>%
    dplyr::transmute(patientid, index_date, weight = testresultcleaned, weightdt = vitaldate)
  # null / empty / missing all resolve to 'standard' (matches Python `or "standard"`); the validator
  # separately requires an explicit method when vitals is configured.
  bmi_m <- vcfg[["bmi_method"]]
  if (is.null(bmi_m) || !nzchar(as.character(bmi_m))) bmi_m <- "standard"
  bmi_expr <- resolve_formula(BMI_FORMULAS, bmi_m, "bmi")
  out <- base %>%
    dplyr::left_join(h, by = c("patientid", "index_date")) %>%
    dplyr::left_join(g, by = c("patientid", "index_date")) %>%
    dplyr::mutate(bmi = dplyr::sql(paste0(
      "CASE WHEN weight IS NOT NULL AND height > 0 THEN ", bmi_expr, " ELSE NULL END")),
      bmigrl  = dplyr::sql(num_bands_case(vcfg[["bmi_bands"]], "bmi", "label")),
      bmigrln = dplyr::sql(num_bands_case(vcfg[["bmi_bands"]], "bmi", "code")))
  keep <- c("patientid", "index_date", "height", "heightdt", "weight", "weightdt", "bmi", "bmigrl", "bmigrln")
  # BSA emitted only when a method is named. Back-compat: a legacy truthy `bsa_formula` -> Du Bois.
  bsa_method <- vcfg[["bsa_method"]] %||% (if (!is.null(vcfg[["bsa_formula"]])) "dubois" else NULL)
  if (!is.null(bsa_method)) {
    bsa_expr <- resolve_formula(BSA_FORMULAS, bsa_method, "bsa")
    out <- dplyr::mutate(out, bsa = dplyr::sql(paste0(
      "CASE WHEN weight IS NOT NULL AND height > 0 THEN ", bsa_expr, " ELSE NULL END")))
    keep <- c(keep, "bsa")
  }
  dplyr::select(out, dplyr::all_of(keep))
}

DEATH_CONFLICT_POLICIES <- c("most_specific_then_earliest", "earliest", "latest")

FOLLOWUP_SOURCES <- list(
  list("visit",    "visitdate",          "last_visitdate",     NULL),
  list("telemed",  "visitdate",          "last_televisitdate", NULL),
  list("lot",      "enddate",            "last_lotenddate",    NULL),
  list("orals",    "enddate",            "last_oralenddate", FOLLOWUP_FILTERS[["valid_oral_end"]]),
  list("alphabet", "administrationdate", "last_alphadate",     NULL),
  list("provenge", "startdate",          "last_provdate",      NULL)
)

# --- clinical: follow-up-end / death anchors. engine/stages/clinical.py::follow_up_and_death -----
# REVIEW-ONLY (intricate; was mid-revision in the original R). The death-imputation / OS-anchor SQL
# below mirrors clinical.py line-for-line; golden-compare dthdt/dthfl/fued/os before relying on it.
clinical_follow_up_and_death <- function(src, idx, clin_cfg) {
  # The cardinality seam, mirroring stages/clinical.py: per_index is the incumbent; per_patient
  # is declared-but-refused until FUED-DEFINITION / DTHFUFL-RULE and the two sub-decisions the
  # python side's refusal names are signed. The two engines must refuse identically, or parity
  # diverges on exactly the definitional inputs the ruling is about.
  scope <- clin_cfg[["follow_up_scope"]] %||% "per_index"
  if (!scope %in% c("per_index", "per_patient"))
    stop(sprintf("BUILD REFUSED - clinical.follow_up_scope '%s' is not one of per_index, per_patient", scope))
  if (identical(scope, "per_patient"))
    stop(paste0("BUILD REFUSED - follow_up_scope: per_patient is declared and its ruling is not ",
                "(FUED-DEFINITION / DTHFUFL-RULE + the snap-anchor and OUTCOME-COHORT-MAP ",
                "sub-decisions). See stages/clinical.py for the checklist."))

  imp <- clin_cfg[["death_date_imputation"]]
  month_day  <- as.integer(imp[["month_level_day"]])
  year_md    <- as.character(imp[["year_level_monthday"]])
  year_late  <- as.character(imp[["year_level_late_monthday"]] %||% year_md)
  year_month <- as.integer(strsplit(year_md, "-", fixed = TRUE)[[1]][1])
  conflict   <- as.character(imp[["conflict_resolution"]] %||% DEATH_CONFLICT_POLICIES[1])
  dth_window <- as.integer(imp[["death_followup_window_days"]])

  # Resolve the follow-up source spec (config override or the present-only default set).
  spec <- imp[["follow_up_sources"]]
  if (!is.null(spec) && is.list(spec[[1]])) {
    fu_spec <- lapply(spec, function(s) list(s[["source"]], s[["date_column"]],
      s[["alias"]] %||% paste0("last_", s[["source"]], "date"), resolve_followup_filter(s)))
  } else {
    fu_spec <- FOLLOWUP_SOURCES
    if (!is.null(spec)) fu_spec <- Filter(function(t) t[[1]] %in% unlist(spec), FOLLOWUP_SOURCES)
  }

  fu <- dplyr::select(idx, patientid, index_date)
  added <- character(0)
  for (t in fu_spec) {
    srcname <- t[[1]]; datecol <- t[[2]]; alias <- t[[3]]; filt <- t[[4]]
    if (is.null(src[[srcname]])) next
    d <- src[[srcname]]
    if (!is.null(filt)) d <- dplyr::filter(d, dplyr::sql(filt))
    last <- d %>% dplyr::group_by(patientid) %>%
      dplyr::summarise(!!alias := dplyr::sql(sprintf("max(%s)", datecol))) %>% dplyr::ungroup()
    fu <- dplyr::left_join(fu, last, by = "patientid")
    added <- c(added, alias)
  }
  # greatest needs >=2 args: one present source IS the max, none is no follow-up. == clinical.py
  fu <- dplyr::mutate(fu, fu_enddt_preliminary = dplyr::sql(
    if (length(added) > 1) sprintf("greatest(%s)", paste(added, collapse = ", "))
    else if (length(added) == 1) added[[1]] else "cast(NULL as date)"))
  if (!("last_lotenddate" %in% added))
    fu <- dplyr::mutate(fu, last_lotenddate = dplyr::sql("cast(NULL as date)"))

  dod <- "cast(dateofdeath as string)"
  fu <- dplyr::left_join(fu, dplyr::select(src[["mortality"]], patientid, dateofdeath),
                         by = "patientid")
  # Index-aware imputation (month-level -> day; year-only in index year on/after year_month -> late).
  fu <- dplyr::mutate(fu, dateofdeath_init = dplyr::sql(sprintf(paste0(
    "CASE WHEN length(%s)=7 THEN cast(concat(%s,'-%02d') as date) ",
    "WHEN length(%s)=4 THEN ",
    "  CASE WHEN cast(%s as int) = year(index_date) AND month(index_date) >= %d ",
    "       THEN cast(concat(%s,'-%s') as date) ",
    "       ELSE cast(concat(%s,'-%s') as date) END ",
    "WHEN length(%s)=10 THEN cast(dateofdeath as date) ELSE NULL END"),
    dod, dod, month_day, dod, dod, year_month, dod, year_late, dod, year_md, dod)))
  fu <- dplyr::mutate(fu, f_death = dplyr::sql("CASE WHEN dateofdeath IS NOT NULL THEN 1 ELSE 0 END"))

  # Collapse to ONE death row per (patientid, index_date) AFTER imputation (policy-driven order).
  # The ordering keys are MATERIALISED first: window_order takes only bare columns under dbplyr
  # 2.6.0, and the null flags are what make the two ascending keys nulls-last as clinical.py has
  # them. All four helpers are dropped again, so the frame's shape is unchanged.
  fu <- fu %>% dplyr::mutate(
    `_dlen` = dplyr::sql(sprintf("length(%s)", dod)),
    `_dtxt` = dplyr::sql(dod))
  fu <- fu %>% dplyr::mutate(
    `_nl_init` = is.na(dateofdeath_init),
    `_nl_txt`  = is.na(`_dtxt`))
  ord <- death_conflict_order(conflict)
  fu <- fu %>%
    dplyr::group_by(patientid, index_date) %>%
    dbplyr::window_order(!!!ord) %>%
    dplyr::mutate(`_rn` = dplyr::row_number()) %>%
    dplyr::ungroup() %>% dplyr::filter(`_rn` == 1) %>%
    dplyr::select(-dplyr::all_of(c("_rn", "_dlen", "_dtxt", "_nl_init", "_nl_txt")))

  fu <- dplyr::mutate(fu, death_dt_preliminary = dplyr::sql(sprintf(paste0(
    "CASE WHEN length(%s)=7 AND substr(cast(fu_enddt_preliminary as string),1,7) = substr(%s,1,7) ",
    "  THEN last_day(dateofdeath_init) ELSE dateofdeath_init END"), dod, dod)))
  fu <- dplyr::mutate(fu, fu_enddt = dplyr::sql(paste0(
    "CASE WHEN death_dt_preliminary IS NOT NULL AND fu_enddt_preliminary > death_dt_preliminary THEN ",
    "  CASE WHEN substr(cast(death_dt_preliminary as string),1,7) = substr(cast(last_lotenddate as string),1,7) ",
    "       THEN last_lotenddate ELSE death_dt_preliminary END ",
    "ELSE fu_enddt_preliminary END")))
  fu <- dplyr::mutate(fu, dthdt = dplyr::sql(paste0(
    "CASE WHEN substr(cast(death_dt_preliminary as string),1,7) = substr(cast(last_lotenddate as string),1,7) ",
    "     THEN cast(last_day(death_dt_preliminary) as date) ELSE death_dt_preliminary END")))
  fu <- dplyr::mutate(fu, dthfl = dplyr::sql("CASE WHEN dthdt IS NOT NULL THEN 1 ELSE 0 END"))
  fu <- dplyr::mutate(fu, fued  = dplyr::sql("CASE WHEN fu_enddt > index_date THEN fu_enddt ELSE index_date END"))
  fu <- dplyr::mutate(fu, dthfufl_dur = dplyr::sql("datediff(dthdt, fued)"))
  fu <- dplyr::mutate(fu, dthfufl = dplyr::sql(sprintf(paste0(
    "CASE WHEN dthdt IS NULL THEN 'Missing' WHEN dthfufl_dur <= %d THEN '1' ",
    "WHEN dthfufl_dur > %d THEN '0' ELSE NULL END"), dth_window, dth_window)))
  # PRE-CAP, mirroring stages/clinical.py: `fued` is already clamped to death, so `dthdt < fued`
  # could essentially never fire and post-death activity was invisible to the guard.
  fu <- dplyr::mutate(fu, dth_before_fued = dplyr::sql(paste0(
    "CASE WHEN dthdt IS NOT NULL AND fu_enddt_preliminary IS NOT NULL ",
    "AND dthdt < fu_enddt_preliminary THEN 1 ELSE 0 END")))
  dplyr::select(fu, patientid, index_date, f_death, dthdt, dthfl, fu_enddt, fued,
                dthfufl_dur, dthfufl, dth_before_fued)
}

# Window-order columns selecting ONE mortality row per group. Mirrors clinical.py::_death_conflict_order.
death_conflict_order <- function(policy) {
  # OVER COLUMNS THE CALLER MATERIALISED, not sql(). dbplyr 2.6.0 refuses `sql()` and
  # `desc(sql())` in window_order ("Element 1 is `<sql>`"), which is what took this stage down the
  # first time the R engine ever executed. `_dlen` and `_dtxt` hold what the SQL used to compute
  # inline; the `_nl_*` flags carry NULL placement.
  #
  # NULLS ARE PLACED EXPLICITLY, mirroring clinical.py, which uses `_nulls_last` on ALL FOUR keys.
  # Spark already puts nulls last on DESC, so `desc_nulls_last` needs nothing extra — but plain
  # ASC puts them FIRST, so `asc_nulls_last` needs the flag. R had bare ordering here and so
  # placed nulls differently from Python on the two ascending keys.
  specific <- rlang::expr(dplyr::desc(`_dlen`))            # full > YYYY-MM > YYYY, nulls last
  earliest <- list(rlang::sym("_nl_init"), rlang::sym("dateofdeath_init"))   # asc, nulls last
  latest   <- list(rlang::expr(dplyr::desc(dateofdeath_init)))               # desc, nulls last
  tiebreak <- list(rlang::sym("_nl_txt"), rlang::sym("_dtxt"))               # asc, nulls last
  if (policy == "most_specific_then_earliest")
    return(c(list(specific), earliest, tiebreak))
  if (policy == "earliest") return(c(earliest, list(specific), tiebreak))
  if (policy == "latest")   return(c(latest, list(specific), tiebreak))
  stop(sprintf("unknown death_date_imputation.conflict_resolution: %s", policy))
}

# --- clinical: assemble. engine/stages/clinical.py::build ---------------------------------------
# --- clinical: closest-to-index raw lab VALUE panel. == clinical.py::_closest_values_panel ---------
clinical_closest_values_panel <- function(src, idx, blk) {
  name_col <- blk[["name_column"]]; val_col <- blk[["value_column"]]
  unit_col <- blk[["unit_column"]]; cast <- toupper(blk[["value_cast"]] %||% "double")
  present <- blk[["present_label"]] %||% "Present"; missing <- blk[["missing_label"]] %||% "Missing"
  wd <- blk[["window_days"]] %||% list(NULL, NULL)
  base <- dplyr::select(idx, patientid, index_date)
  pulled <- dplyr::inner_join(base, src[[blk[["source"]]]], by = "patientid")
  # the record's date from the named basis (G-LABS later_of) == clinical.py; `_rdate` once,
  # and the undatable records kept aside — and EXCLUDED from candidacy, not left to the window
  # filters (both bounds may be null) — so the 3-state can answer Unknown, not Missing
  date_col <- "`_rdate`"
  pulled <- dplyr::mutate(pulled, `_rdate` = dplyr::sql(record_date_sql(blk)))
  undated <- dplyr::filter(pulled, dplyr::sql("`_rdate` IS NULL"))
  pulled <- dplyr::filter(pulled, dplyr::sql("`_rdate` IS NOT NULL"))
  if (!is.null(wd[[1]])) pulled <- dplyr::filter(pulled, dplyr::sql(sprintf("%s >= date_add(index_date, %s)", date_col, wd[[1]])))
  if (!is.null(wd[[2]])) pulled <- dplyr::filter(pulled, dplyr::sql(sprintf("%s <= date_add(index_date, %s)", date_col, wd[[2]])))
  pulled <- pulled %>%
    dplyr::mutate(`_gap` = dplyr::sql(sprintf("abs(datediff(%s, index_date))", date_col)),
                  `_v` = dplyr::sql(sprintf("try_cast(%s AS %s)", val_col, cast)))
  undated <- dplyr::mutate(undated, `_v` = dplyr::sql(sprintf("try_cast(%s AS %s)", val_col, cast)))
  unknown <- blk[["unknown_label"]]                  # optional 3-state: Present / Unknown / Missing
  out <- base
  for (item in blk[["panel"]]) {
    nm <- item[["name"]]
    # eligibility == clinical.py::_named: the name match, narrowed by the spec'd specimen
    # when the item declares `component` — for candidates AND existence
    comp <- item[["component"]]; comp_col <- blk[["component_column"]]
    if (!is.null(comp) && is.null(comp_col))
      stop(sprintf("%s: `component` is declared and the block names no `component_column`", nm))
    named_pred <- sprintf("upper(%s) = %s", name_col, .sql_str(toupper(item[["match"]])))
    if (!is.null(comp))
      named_pred <- sprintf("%s AND lower(%s) = %s", named_pred, comp_col, .sql_str(tolower(comp)))
    named <- dplyr::filter(pulled, dplyr::sql(named_pred))
    rows <- named
    # == clinical.py _closest_values_panel. R builds the INTENDED predicate from a scalar while
    # Python iterates it character-by-character, so R accepting what Python now refuses would just
    # move the divergence rather than close it. Both engines must refuse the same config.
    for (.f in SEQUENCE_FIELDS) {
      if (!is.null(item[[.f]])) {
        .why <- sequence_error(.f, item[[.f]])
        if (!is.null(.why)) stop(.why)
      }
    }
    if (!is.null(unit_col) && !is.null(item[["units"]]))
      rows <- dplyr::filter(rows, dplyr::sql(sprintf("lower(%s) IN (%s)", unit_col,
        paste(vapply(item[["units"]], function(u) .sql_str(tolower(u)), character(1)), collapse = ", "))))
    # == clinical.py: the PER-ITEM canonical value. `_v` is the panel-wide raw cast; an analyte
    # declaring `unit_conversions` gets its own column so the Present test, the value tie-break and
    # the published number cannot land on different scales. Inert when undeclared.
    vcol <- "`_v`"
    conv <- if (!is.null(unit_col)) unit_conversion_case(item, unit_col, "`_v`") else NULL
    if (!is.null(conv)) {
      vcol <- "`_cv`"
      rows <- dplyr::mutate(rows, `_cv` = dplyr::sql(conv))
    }
    rows <- dplyr::filter(rows, dplyr::sql(sprintf("%s IS NOT NULL", vcol)))
    if (isTRUE(blk[["positive_only"]]) || isTRUE(item[["positive_only"]]))
      # G-LABS `>0` == clinical.py: zero is an artefact; the only-zero patient reads Unknown
      rows <- dplyr::filter(rows, dplyr::sql(sprintf("%s > 0", vcol)))
    # ORDERED IN COLUMNS, NOT SQL — dbplyr 2.6.0 refuses a `sql()` argument to window_order
    # ("Element 1 is `<sql>`"). Same keys, same direction: `_gap`, the date, then the value
    # ascending for a `lowest` tiebreak and descending for `highest`.
    vhi <- (item[["tiebreak"]] %||% "lowest") == "highest"
    vsym <- .ordsym(vcol)
    near <- rows %>%
      dplyr::group_by(patientid, index_date) %>%
      dbplyr::window_order(`_gap`, !!.ordsym(date_col),
                           !!(if (vhi) rlang::expr(dplyr::desc(!!vsym)) else vsym)) %>%
      dplyr::mutate(`_rn` = dplyr::row_number()) %>% dplyr::ungroup() %>%
      dplyr::filter(`_rn` == 1) %>%
      dplyr::transmute(patientid, index_date,
                       !!paste0(nm, "v") := dplyr::sql(vcol),
                       # .ordsym, not rlang::sym: `date_col` is SQL-QUOTED here (`` `_rdate` ``)
                       # because lines above interpolate it into `dplyr::sql()` strings, where the
                       # backticks belong. A bare `sym()` on that asks for a column whose NAME
                       # contains backticks — "Object `` `_rdate` `` not found". The sibling
                       # `clinical_closest_value` keeps the same variable UNQUOTED, which is why
                       # only this one broke. Latent until now: the case died at `window_order`
                       # before ever reaching this line.
                       !!paste0(nm, "dt") := !!.ordsym(date_col), !!nm := present)
    out <- dplyr::left_join(out, near, by = c("patientid", "index_date"))
    if (!is.null(unknown)) {                          # test exists but no usable value -> Unknown; none -> Missing
      undated_named <- dplyr::filter(undated, dplyr::sql(named_pred))
      anyrec <- dplyr::union_all(dplyr::select(named, patientid, index_date),
                                 dplyr::select(undated_named, patientid, index_date)) %>%
        dplyr::distinct(patientid, index_date) %>% dplyr::mutate(`_any` = 1L)
      out <- out %>% dplyr::left_join(anyrec, by = c("patientid", "index_date")) %>%
        dplyr::mutate(!!nm := dplyr::sql(sprintf(
          "coalesce(%s, CASE WHEN `_any` IS NOT NULL THEN %s ELSE %s END)", nm, .sql_str(unknown), .sql_str(missing)))) %>%
        dplyr::select(-`_any`)
    } else {
      out <- out %>% dplyr::mutate(!!nm := dplyr::sql(sprintf("coalesce(%s, %s)", nm, .sql_str(missing))))
    }
  }
  out
}


# same_date_conflict: resolve == clinical.py::_resolve_then_pick - collapse same-day values
# through the declared pairwise table, THEN pick nearest; an unruled pair stops the build.
clinical_resolve_then_pick <- function(rows, blk, item, date_col, label_sql, nm) {
  rules <- list()
  for (r in item[["conflict_rules"]] %||% list()) {
    ab <- sort(vapply(r[["between"]], as.character, ""))
    rules[[paste(ab, collapse = "\u0001")]] <- as.character(r[["resolve"]])
  }
  per_date <- rows %>% dplyr::mutate(`_v` = dplyr::sql(label_sql)) %>%
    dplyr::group_by(patientid, index_date, !!rlang::sym(date_col), `_gap`) %>%
    dplyr::summarise(`_vs` = dplyr::sql("array_sort(collect_set(`_v`))"), .groups = "drop")
  whens <- paste(vapply(names(rules), function(k) {
    ab <- strsplit(k, "\u0001")[[1]]
    sprintf("WHEN `_vs` = array(%s, %s) THEN %s", .sql_str(ab[[1]]), .sql_str(ab[[2]]), .sql_str(rules[[k]]))
  }, ""), collapse = " ")
  per_date <- dplyr::mutate(per_date, `_v` = dplyr::sql(sprintf(
    "CASE WHEN size(`_vs`) = 1 THEN `_vs`[0] %s ELSE NULL END", whens)))
  clash <- per_date %>% dplyr::filter(dplyr::sql("`_v` IS NULL")) %>%
    utils::head(1) %>% dplyr::collect()
  if (nrow(clash) > 0)
    stop(sprintf(paste0("%s: same_date_conflict is `resolve` and at least one patient has a ",
                        "same-day combination no conflict_rules row covers - an unruled pair ",
                        "is the refuse case"), nm))
  dt <- if (identical(selection_spec(blk, item, "tie_break"), "prior"))
    rlang::expr(!!rlang::sym(date_col)) else rlang::expr(dplyr::desc(!!rlang::sym(date_col)))
  code_when <- paste(vapply(item[["groups"]], function(g)
    sprintf("WHEN `_v` = %s THEN %s", .sql_str(as.character(g[["label"]])), g[["code"]]), ""),
    collapse = " ")
  per_date %>% dplyr::group_by(patientid, index_date) %>%
    dbplyr::window_order(`_gap`, !!dt) %>%
    dplyr::mutate(`_rn` = dplyr::row_number()) %>% dplyr::ungroup() %>%
    dplyr::filter(`_rn` == 1) %>%
    dplyr::mutate(!!nm := dplyr::sql("`_v`"),
                  !!paste0(nm, "n") := dplyr::sql(sprintf("CASE %s END", code_when)))
}

# --- clinical: metastatic-site presence flags. == engine/stages/clinical.py::_metastatic_sites ----
# Weighted comorbidity score over a pre-index lookback == clinical.py comorbidity_index.
# The sum is over DISTINCT conditions (max per condition, then weighted sum), never over rows: a
# patient coded five times for myocardial infarction scores it once. Code sets and weights come
# from the pack — the engine ships no Charlson/Elixhauser table, because a published algorithm has
# versions and adaptations and an engine carrying one would choose it for every product silently.
# {winner -> every condition it supersedes, transitively} == clinical.py::supersedes_closure.
#
# NAMED AND SHARED because both engines had their own version and only one was right. Applying the
# edges one at a time zeroes a loser and then reads that zeroed flag when deciding the loser's OWN
# losers: in severe -> moderate -> mild, `mild` survived a present `severe` here, so R returned 4
# where Python returned 3 — and the answer depended on the order the conditions were listed in.
# Self-edges are dropped; the validator refuses them, and refuses cycles, which is what lets this
# loop terminate.
supersedes_closure <- function(suprs) {
  closure <- lapply(suprs, function(l) unique(as.character(unlist(l))))
  repeat {
    changed <- FALSE
    for (w in names(closure)) {
      grown <- unique(c(closure[[w]], unlist(closure[closure[[w]]], use.names = FALSE)))
      grown <- setdiff(grown[!is.na(grown)], w)
      if (!setequal(grown, closure[[w]])) { closure[[w]] <- grown; changed <- TRUE }
    }
    if (!changed) break
  }
  closure
}

# Whether every weight is a whole number — the cast the score is emitted with.
# == clinical.py::weights_are_integral. An unconditional `as int` here truncated a 1.5 weight to 1
# while Python kept 1.5, so the decision is one named line on each side and a parity test compares
# them rather than a reader comparing two files.
weights_are_integral <- function(weights) {
  ws <- suppressWarnings(as.numeric(unlist(weights)))
  length(ws) > 0 && all(!is.na(ws)) && all(ws == floor(ws))
}

clinical_comorbidity_index <- function(src, idx, blk) {
  dx_src <- src[[blk[["source"]]]]
  conds <- blk[["conditions"]] %||% list()
  if (is.null(dx_src) || length(conds) == 0) return(NULL)
  code_col <- blk[["code_column"]]; system <- blk[["code_system"]]
  dc <- blk[["date_column"]]; wd <- blk[["window_days"]] %||% list(NULL, NULL)
  nm <- blk[["name"]]
  base <- dplyr::select(idx, patientid, index_date)
  rows <- dplyr::inner_join(base, dx_src, by = "patientid")
  if (!is.null(dc)) {
    if (!is.null(wd[[1]])) rows <- dplyr::filter(rows, dplyr::sql(sprintf("%s >= date_add(index_date, %s)", dc, wd[[1]])))
    if (!is.null(wd[[2]])) rows <- dplyr::filter(rows, dplyr::sql(sprintf("%s <= date_add(index_date, %s)", dc, wd[[2]])))
  }
  # One 0/1 per condition per patient — `max` over the window is what makes it DISTINCT.
  aggs <- list(); wts <- list(); suprs <- list()
  for (i in seq_along(conds)) {
    cd <- conds[[i]]
    match <- cd[setdiff(names(cd), c("name", "weight", "supersedes"))]
    pred <- compile_match(match, code_col, code_col, code_col, system)
    col <- paste0("_cc", i)
    aggs[[col]] <- dplyr::sql(sprintf("max(CASE WHEN %s THEN 1 ELSE 0 END)", pred))
    wts[[cd[["name"]]]] <- list(col = col, weight = cd[["weight"]] %||% 1)
    if (!is.null(cd[["supersedes"]])) suprs[[cd[["name"]]]] <- cd[["supersedes"]]
  }
  scored <- rows %>% dplyr::group_by(patientid, index_date) %>%
    dplyr::summarise(!!!aggs, .groups = "drop")
  # HIERARCHY: TRANSITIVE, and read off the ORIGINAL flags == clinical.py comorbidity_index.
  if (length(suprs) > 0) {
    closure <- supersedes_closure(suprs)
    original <- vapply(wts, function(w) sprintf("`%s`", w$col), "")
    for (winner in names(closure)) {
      wsrc <- original[[winner]]
      for (loser in closure[[winner]]) {
        if (!is.null(wts[[loser]])) {
          lcol <- wts[[loser]]$col
          scored <- dplyr::mutate(scored, !!lcol := dplyr::sql(
            sprintf("CASE WHEN %s = 1 THEN 0 ELSE `%s` END", wsrc, lcol)))
        }
      }
    }
  }
  total <- paste(vapply(wts, function(w) sprintf("(`%s` * %s)", w$col, w$weight), ""), collapse = " + ")
  integral <- weights_are_integral(lapply(wts, function(w) w$weight))
  scored <- dplyr::mutate(scored, !!nm := dplyr::sql(
    sprintf("cast(%s as %s)", total, if (integral) "int" else "double")))
  keep <- c(nm)
  if (!is.null(blk[["bands"]])) {
    scored <- dplyr::mutate(scored,
      !!paste0(nm, "gr") := dplyr::sql(num_bands_case(blk[["bands"]], nm, "label")),
      !!paste0(nm, "grn") := dplyr::sql(num_bands_case(blk[["bands"]], nm, "code")))
    keep <- c(keep, paste0(nm, "gr"), paste0(nm, "grn"))
  }
  # LEFT join: a patient with no in-window diagnosis keeps NULL, not 0 — different facts.
  dplyr::left_join(base, dplyr::select(scored, patientid, index_date, dplyr::all_of(keep)),
                   by = c("patientid", "index_date"))
}


clinical_metastatic_sites <- function(src, idx, blk) {
  s <- src[[blk[["source"]]]]
  if (is.null(s)) return(NULL)
  site_col <- blk[["site_column"]]; date_col <- blk[["date_column"]]
  if (!(site_col %in% colnames(s)) || !(date_col %in% colnames(s))) return(NULL)
  yes <- blk[["yes_label"]] %||% "Yes"; no <- blk[["no_label"]] %||% "No"
  base <- dplyr::select(idx, patientid, index_date)
  j <- dplyr::left_join(base, dplyr::select(s, patientid, !!rlang::sym(site_col), !!rlang::sym(date_col)),
                        by = "patientid")
  # <= boundary + per-site earliest date independent of the flag (G-MET-METDT). == clinical.py
  aggs <- lapply(blk[["sites"]], function(it) dplyr::sql(sprintf(
    "max(CASE WHEN lower(%s) = %s AND %s <= index_date THEN 1 ELSE 0 END)",
    site_col, .sql_str(tolower(it[["match"]])), date_col)))
  names(aggs) <- vapply(blk[["sites"]], function(it) paste0("_", it[["name"]]), character(1))
  dts <- lapply(blk[["sites"]], function(it) dplyr::sql(sprintf(
    "min(CASE WHEN lower(%s) = %s THEN %s END)",
    site_col, .sql_str(tolower(it[["match"]])), date_col)))
  names(dts) <- vapply(blk[["sites"]], function(it) paste0(it[["name"]], "dt"), character(1))
  aggs <- c(aggs, dts)
  g <- j %>% dplyr::group_by(patientid, index_date) %>% dplyr::summarise(!!!aggs, .groups = "drop")
  for (it in blk[["sites"]]) {
    g <- dplyr::mutate(g, !!it[["name"]] := dplyr::sql(sprintf(
      "CASE WHEN `_%s` = 1 THEN %s ELSE %s END", it[["name"]], .sql_str(yes), .sql_str(no))))
    g <- dplyr::select(g, -!!rlang::sym(paste0("_", it[["name"]])))
  }
  g
}

# --- clinical: windowed PSA timepoints + PSA-response endpoints. == clinical.py::_psa_timepoints -----
clinical_psa_timepoints <- function(src, idx, blk) {
  val_col <- blk[["value_column"]]; date_col <- blk[["date_column"]]; cast <- toupper(blk[["value_cast"]] %||% "double")
  base <- dplyr::select(idx, patientid, index_date)
  pulled <- dplyr::inner_join(base, src[[blk[["source"]]]], by = "patientid") %>%
    dplyr::mutate(`_v` = dplyr::sql(sprintf("try_cast(%s AS %s)", val_col, cast))) %>%
    dplyr::filter(dplyr::sql("`_v` IS NOT NULL"))
  out <- base
  for (p in blk[["points"]]) {
    wd <- p[["window_days"]]
    # a point may declare its own ANCHOR (G-PSADIAG-CRPC) == clinical.py::_psa_timepoints
    anch <- "index_date"
    frame <- pulled
    a <- p[["anchor"]]
    if (!is.null(a)) {
      role <- a[["source"]]; col <- a[["column"]]
      if (is.null(role) || is.null(col))
        stop(sprintf("%s: anchor needs `source` and `column`", p[["name"]]))
      t <- src[[role]]
      if (is.null(t))
        stop(sprintf("BUILD REFUSED - %s anchors on source '%s', not given", p[["name"]], role))
      if (!(col %in% colnames(t)))
        stop(sprintf("BUILD REFUSED - '%s' lacks anchor column '%s'", role, col))
      af <- t %>% dplyr::group_by(patientid) %>%
        dplyr::summarise(`_anchor` = dplyr::sql(sprintf("min(%s)", col)), .groups = "drop") %>%
        dplyr::filter(dplyr::sql("`_anchor` IS NOT NULL"))
      frame <- dplyr::inner_join(pulled, af, by = "patientid")
      anch <- "`_anchor`"
    }
    rows <- dplyr::filter(frame, dplyr::sql(sprintf(
      "%s >= date_add(%s, %s) AND %s <= date_add(%s, %s)",
      date_col, anch, wd[[1]], date_col, anch, wd[[2]])))
    # ORDERED IN COLUMNS, NOT SQL — see the tumour-marker block above; dbplyr 2.6.0 refuses a
    # `sql()` argument. `earliest` takes the earliest date and the HIGHEST value on a tie;
    # `closest` takes the smallest absolute gap, then the date. Same keys, same directions.
    if ((p[["pick"]] %||% "closest") == "earliest") {
      ord <- list(.ordsym(date_col), rlang::expr(dplyr::desc(`_v`)))
    } else {
      rows <- dplyr::mutate(rows, `_g` = dplyr::sql(sprintf("abs(datediff(%s, %s))", date_col, anch)))
      ord <- list(rlang::sym("_g"), .ordsym(date_col))
    }
    near <- rows %>% dplyr::group_by(patientid, index_date) %>% dbplyr::window_order(!!!ord) %>%
      dplyr::mutate(`_rn` = dplyr::row_number()) %>% dplyr::ungroup() %>% dplyr::filter(`_rn` == 1) %>%
      dplyr::transmute(patientid, index_date, !!p[["name"]] := `_v`)
    out <- dplyr::left_join(out, near, by = c("patientid", "index_date"))
  }
  resp <- blk[["response"]]
  if (!is.null(resp)) {
    bl <- resp[["baseline"]]; p50 <- resp[["psa50_threshold"]] %||% -0.5; pun <- resp[["undetectable_threshold"]] %||% 0.2
    for (pt in resp[["points"]]) {
      v <- pt[["value"]]
      out <- out %>%
        dplyr::mutate(!!pt[["psa50"]] := dplyr::sql(sprintf(paste0(   # NULL = not evaluable
          "CASE WHEN %s IS NULL OR %s = 0 OR %s IS NULL THEN NULL ",
          "WHEN (%s - %s)/%s <= %s THEN 'Y' ELSE 'N' END"), bl, bl, v, v, bl, bl, p50))) %>%
        dplyr::mutate(!!pt[["undetectable"]] := dplyr::sql(sprintf(
          "CASE WHEN %s IS NOT NULL AND %s < %s THEN 'Y' WHEN %s IS NOT NULL THEN 'N' ELSE NULL END", v, v, pun, v)))
    }
  }
  out
}

# The closest-to-index panel blocks == clinical.py CLOSEST_PANELS. Spelled here because R cannot
# import the Python constant; test_r_parity asserts the two lists are identical, so a family added
# to one engine and not the other fails rather than silently producing a column in only one.
CLOSEST_PANELS <- c("biomarkers", "labs", "response")

# THE SELECTION REGISTRY == clinical.py DEFAULT_SELECTION / _selection_spec. Two divergences lived
# here and both produced a different variable in R than in Python, silently:
#
#   tie_break  R had no default at all and fell through to DESCENDING date, while Python defaults to
#              `prior` (ascending). Two records equidistant either side of index therefore resolved
#              to opposite rows — the later one in R, the earlier one in Python.
#   pick       R read only the legacy `aggregate: priority` spelling. A block written as
#              `pick: priority` — which is what the generated scaffold emits — ranked by priority in
#              Python and by nearest-to-index in R. For a response panel that is the difference
#              between best-of-window and whatever happened to fall closest to index.
#
# Neither showed up in the parity suite, which compares compiled CASE strings and block names but
# does not run rows through both engines. So the DEFAULTS are now one object per engine, compared
# directly by test_r_parity.
# == clinical.py DEFAULT_SELECTION. `same_date_conflict` says what happens when two records on the
# SAME DATE disagree about the value — a different question from `tie_break`, which only ever
# decided which DATE wins. `deterministic` is what both engines have always done once the ordering
# is total, so no pack's output moves by adding it.
SELECTION_DEFAULTS <- list(date_basis = "column", pick = "nearest", tie_break = "prior",
                           same_date_conflict = "deterministic")

# The effective value of one selection key: the ITEM's, else the BLOCK's, else the registered
# default — item-over-block, exactly as _selection_spec resolves it.
selection_spec <- function(blk, item, key) {
  for (src in list(item, blk)) {
    if (!is.null(src) && !is.null(src[[key]])) {
      v <- src[[key]]
      return(if (is.list(v)) (v[["method"]] %||% v) else v)
    }
  }
  # `aggregate: priority` is the pre-registry spelling of `pick: priority`, still honoured so no
  # pack needs editing — the same allowance _selection_spec makes.
  if (identical(key, "pick") && !is.null(item) && identical(item[["aggregate"]], "priority")) {
    return("priority")
  }
  SELECTION_DEFAULTS[[key]]
}

# THE RECORD'S DATE, per the block's `date_basis` == clinical.py::_record_date_expr.
#
# This file DEFINED the default and then never used it: the panel loop read `blk[["date_column"]]`
# for the window filter, the gap, the ordering and the emitted date. A pack configuring
# `date_basis: {method: later_of, columns: [collected, resulted]}` therefore either failed here for
# want of a `date_column`, or — with both keys present — silently windowed and ranked on a DIFFERENT
# date from the one Python used, selecting a different row. `greatest`/`least` ignore nulls in Spark
# SQL, so a record dated on only one of two columns still has a date rather than dropping out.
record_date_sql <- function(blk) {
  basis <- blk[["date_basis"]] %||% SELECTION_DEFAULTS[["date_basis"]]
  method <- if (is.list(basis)) (basis[["method"]] %||% "column") else basis
  if (identical(as.character(method), "column")) return(blk[["date_column"]])
  cols <- paste(unlist(basis[["columns"]]), collapse = ", ")
  sprintf("%s(%s)", if (identical(as.character(method), "later_of")) "greatest" else "least", cols)
}

clinical_build <- function(src, idx, cfg, cohort = NULL) {
  clin_cfg <- cfg_pack(cfg, "clinical")
  base <- dplyr::select(idx, patientid, index_date)
  ecog_cfg <- clin_cfg[["baseline_ecog"]]
  if (!is.null(src[["baseline_ecog"]])) {
    ecog <- clinical_baseline_ecog(src, idx, ecog_cfg, cohort)
  } else {
    # UNQUOTED, because dbplyr TRANSLATES this expression rather than evaluating it. A bare
    # `ecog_cfg[["missing_label"]]` inside mutate() is not read as "the value in that list" — it is
    # compiled to SQL, and the whole config went into the SELECT:
    #   SELECT *, (-90.0, 7.0) AS `window_days`, 'earliest_date' AS `tie_break`, … AS
    #   `value_codes`.`missing_label` AS `ecog`
    # which Spark answered with PARSE_SYNTAX_ERROR. `!!` forces the R value in before translation,
    # giving `'Missing' AS ecog, 7.0 AS ecogn`. `clinical_baseline_ecog` above dodges this by
    # extracting to locals first; this branch — the no-ECOG-table missing path — did not, and it
    # only runs when a pack has no baseline_ecog table at all, so nothing exercised it until the
    # conformance case built exactly that.
    # THE CODE IS RENDERED AS SQL TEXT, NOT INJECTED AS AN R VALUE, and the difference is a TYPE.
    # `!!ecog_cfg[["missing_code"]]` puts R's own reading of `missing_code: 7` into the query —
    # and R's YAML reader gives a DOUBLE, so dbplyr emitted `7.0 AS ecogn` while clinical.py emits
    # `CASE ... ELSE 7 END` from a Python int. The stage-conformance harness caught it the moment
    # this path first ran: "the two engines emit different TYPES for `ecogn` — python=int
    # r=double". Rendering the config value as literal SQL text mirrors Python's f-string exactly,
    # and is what the sibling with-table path at `clinical_baseline_ecog` already does. The label
    # keeps `!!`, which is correct: it needs quoting, and `'Missing'` is what that produces.
    ecog <- base %>% dplyr::mutate(
      ecog  = !!ecog_cfg[["missing_label"]],
      ecogn = dplyr::sql(as.character(ecog_cfg[["missing_code"]])))
  }
  clin <- base %>%
    dplyr::left_join(ecog, by = c("patientid", "index_date")) %>%
    dplyr::left_join(clinical_follow_up_and_death(src, idx, clin_cfg),
                     by = c("patientid", "index_date"))

  # Stage grouping (deterministic pick via staging.source/date_column/pick). == clinical.py.
  stcfg <- clin_cfg[["staging"]] %||% list()
  groups <- stcfg[["groups"]]
  st_src <- src[[stcfg[["source"]] %||% cfg_index_source(cfg)]]
  if (!is.null(st_src) && !is.null(groups) && "groupstage" %in% colnames(st_src)) {
    sel <- c("patientid", "groupstage")
    dc <- stcfg[["date_column"]]
    st <- st_src
    if (!is.null(dc) && dc %in% colnames(st_src)) {
      sel <- c(sel, dc)
      st <- st %>% dplyr::group_by(patientid)
      st <- if ((stcfg[["pick"]] %||% "latest") == "latest")
        dbplyr::window_order(st, dplyr::desc(!!rlang::sym(dc)), groupstage)
      else dbplyr::window_order(st, !!rlang::sym(dc), groupstage)
    } else {
      st <- st %>% dplyr::group_by(patientid) %>% dbplyr::window_order(groupstage)
    }
    st <- st %>% dplyr::select(dplyr::all_of(sel)) %>%
      dplyr::mutate(`_rn` = dplyr::row_number()) %>% dplyr::ungroup() %>%
      dplyr::filter(`_rn` == 1) %>%
      dplyr::mutate(stage  = dplyr::sql(stage_case(groups, "groupstage", "label")),
                    stagen = dplyr::sql(stage_case(groups, "groupstage", "code"))) %>%
      dplyr::select(patientid, stage, stagen)
    clin <- dplyr::left_join(clin, st, by = "patientid")
    # G-STAGE-MISSING, absent-row half: the declared `when: missing` group absorbs a
    # patient with no stage row; no declaration, no invention. == clinical.py
    mg <- NULL
    for (grp in groups) if (identical(grp[["when"]], "missing")) { mg <- grp; break }
    if (!is.null(mg)) {
      clin <- dplyr::mutate(clin,
        stage  = dplyr::sql(sprintf("coalesce(stage, %s)", .sql_str(mg[["label"]]))),
        stagen = dplyr::sql(sprintf("coalesce(stagen, %s)", mg[["code"]])))
    }
  }

  # Generic categorical clinical characteristics (grade/histology/…): same value->group CASE as
  # staging, via the parity-proven stage_case compiler. == clinical.py categoricals loop. The row
  # pick honours date_column + pick (latest|earliest) like the staging block above — NOT an
  # arbitrary order — so the selected value matches _categorical_pick().
  for (cat in (clin_cfg[["categoricals"]] %||% list())) {
    cat_src <- src[[cat[["source"]] %||% cfg_index_source(cfg)]]
    col <- cat[["column"]]; cg <- cat[["groups"]]; nm <- cat[["name"]]
    if (is.null(cat_src) || is.null(cg) || is.null(col) || is.null(nm) || !(col %in% colnames(cat_src))) next
    dc <- cat[["date_column"]]

    # WINDOWED (index-anchored) categorical == clinical.py _categorical_pick_windowed. Keyed on
    # (patientid, index_date), NOT patientid: the window is measured from index, so a patient in two
    # cohorts has two index dates and may legitimately have two answers. A window whose date column
    # the source lacks is SKIPPED, never silently demoted to the unwindowed pick — "the value at
    # index" and "the patient's latest value" are different questions.
    if (!is.null(cat[["window_days"]])) {
      if (is.null(dc) || !(dc %in% colnames(cat_src))) next
      wdc <- cat[["window_days"]]
      label_sql <- stage_case(cg, col, "label"); code_sql <- stage_case(cg, col, "code")
      cbase <- dplyr::select(idx, patientid, index_date)
      crows <- dplyr::inner_join(cbase, dplyr::select(cat_src, patientid, dplyr::all_of(c(col, dc))),
                                 by = "patientid")
      if (!is.null(wdc[[1]])) crows <- dplyr::filter(crows, dplyr::sql(sprintf("%s >= date_add(index_date, %s)", dc, wdc[[1]])))
      if (!is.null(wdc[[2]])) crows <- dplyr::filter(crows, dplyr::sql(sprintf("%s <= date_add(index_date, %s)", dc, wdc[[2]])))
      crows <- dplyr::mutate(crows, `_gap` = dplyr::sql(sprintf("abs(datediff(%s, index_date))", dc)))
      cpick <- selection_spec(cat, NULL, "pick")
      ctie <- selection_spec(cat, NULL, "tie_break")
      cdt <- if (identical(ctie, "prior")) rlang::expr(!!rlang::sym(dc)) else rlang::expr(dplyr::desc(!!rlang::sym(dc)))
      cgrp <- crows %>% dplyr::group_by(patientid, index_date)
      if (identical(cpick, "priority")) {
        prio <- cat[["priority"]] %||% lapply(cg, function(g) g[["label"]])
        rank_sql <- paste0("CASE ", paste(vapply(seq_along(prio), function(i)
          sprintf("WHEN (%s) = '%s' THEN %d", label_sql,
                  gsub("'", "''", as.character(prio[[i]])), i - 1L), ""), collapse = " "),
          sprintf(" ELSE %d END", length(prio)))
        cgrp <- cgrp %>% dplyr::mutate(`_rank` = dplyr::sql(rank_sql)) %>%
          dbplyr::window_order(`_rank`, !!cdt)
      } else if (identical(cpick, "earliest")) {
        cgrp <- dbplyr::window_order(cgrp, !!rlang::sym(dc), !!cdt)
      } else if (identical(cpick, "latest")) {
        cgrp <- dbplyr::window_order(cgrp, dplyr::desc(!!rlang::sym(dc)), !!cdt)
      } else {
        cgrp <- dbplyr::window_order(cgrp, `_gap`, !!cdt)
      }
      cwin <- cgrp %>%
        dplyr::mutate(`_rn` = dplyr::row_number()) %>% dplyr::ungroup() %>%
        dplyr::filter(`_rn` == 1) %>%
        dplyr::mutate(!!nm := dplyr::sql(label_sql), !!paste0(nm, "n") := dplyr::sql(code_sql)) %>%
        dplyr::select(patientid, index_date, dplyr::all_of(c(nm, paste0(nm, "n"))))
      clin <- dplyr::left_join(clin, cwin, by = c("patientid", "index_date"))
      next
    }

    cdf <- cat_src %>% dplyr::group_by(patientid)
    # == clinical.py: unwrap the mapping form `pick: {method: latest}`, which the windowed branch
    # above already sees through via selection_spec(). Reading the raw value made the same
    # spelling mean different things in the two branches.
    cpick <- cat[["pick"]] %||% "latest"
    if (is.list(cpick)) cpick <- cpick[["method"]] %||% "latest"
    if (!is.null(dc) && dc %in% colnames(cat_src)) {
      cdf <- if (cpick == "latest")
        dbplyr::window_order(cdf, dplyr::desc(!!rlang::sym(dc)), !!rlang::sym(col))
      else dbplyr::window_order(cdf, !!rlang::sym(dc), !!rlang::sym(col))
    } else {
      cdf <- dbplyr::window_order(cdf, !!rlang::sym(col))
    }
    cdf <- cdf %>%
      dplyr::mutate(`_rn` = dplyr::row_number()) %>% dplyr::ungroup() %>%
      dplyr::filter(`_rn` == 1) %>%
      dplyr::mutate(!!nm := dplyr::sql(stage_case(cg, col, "label")),
                    !!paste0(nm, "n") := dplyr::sql(stage_case(cg, col, "code"))) %>%
      dplyr::select(patientid, dplyr::all_of(c(nm, paste0(nm, "n"))))
    clin <- dplyr::left_join(clin, cdf, by = "patientid")
  }

  # Closest-to-index PANELS (biomarkers / labs): each item picks the record nearest index within
  # its window, maps the value via stage_case. == clinical.py _closest_panel.
  for (blk_key in CLOSEST_PANELS) {
    blk <- clin_cfg[[blk_key]]
    if (is.null(blk) || is.null(src[[blk[["source"]]]]) || is.null(blk[["panel"]])) next
    name_col <- blk[["name_column"]]; val_col <- blk[["value_column"]]
    unit_col <- blk[["unit_column"]]
    wd <- blk[["window_days"]] %||% list(NULL, NULL)
    base <- dplyr::select(idx, patientid, index_date)
    pulled <- dplyr::inner_join(base, src[[blk[["source"]]]], by = "patientid")
    # Materialised ONCE into `_rdate` and used by the window filter, the gap, the ordering and the
    # emitted date == clinical.py _closest_panel. Four places that each spelled `date_column` are
    # four places that can come to disagree the moment the basis stops being a single column.
    date_col <- "_rdate"
    pulled <- dplyr::mutate(pulled, `_rdate` = dplyr::sql(record_date_sql(blk)))
    # an undatable record is never a candidate == clinical.py _closest_panel: the window filters
    # cannot be trusted to shed it (both bounds may be null), and a null `_gap` sorts FIRST under
    # asc nulls-first — the record nobody can place against index would WIN the pick.
    pulled <- dplyr::filter(pulled, dplyr::sql("`_rdate` IS NOT NULL"))
    if (!is.null(wd[[1]])) pulled <- dplyr::filter(pulled, dplyr::sql(sprintf("`%s` >= date_add(index_date, %s)", date_col, wd[[1]])))
    if (!is.null(wd[[2]])) pulled <- dplyr::filter(pulled, dplyr::sql(sprintf("`%s` <= date_add(index_date, %s)", date_col, wd[[2]])))
    pulled <- dplyr::mutate(pulled, `_gap` = dplyr::sql(sprintf("abs(datediff(`%s`, index_date))", date_col)))
    for (item in blk[["panel"]]) {
      nm <- item[["name"]]
      if (!is.null(item[["bands"]])) {                # numeric value -> num_bands_case (e.g. CA-125)
        cast <- item[["value_cast"]] %||% blk[["value_cast"]] %||% "double"
        num_col <- sprintf("try_cast(%s AS %s)", val_col, toupper(cast))   # == clinical.py _band_value_expr
        label_sql <- num_bands_case(item[["bands"]], num_col, "label")
        code_sql  <- num_bands_case(item[["bands"]], num_col, "code")
      } else {                                        # categorical value -> stage_case
        label_sql <- stage_case(item[["groups"]], val_col, "label")
        code_sql  <- stage_case(item[["groups"]], val_col, "code")
      }
      # == clinical.py:557. The same refusal, on the same field list, at the site that reads them.
      for (.f in SEQUENCE_FIELDS) {
        if (!is.null(item[[.f]])) {
          .why <- sequence_error(.f, item[[.f]])
          if (!is.null(.why)) stop(.why)
        }
      }
      names <- item[["match_any"]] %||% list(item[["match"]])   # match_any: a multi-name set (HRR gene panel)
      inlist <- paste(sprintf("'%s'", toupper(unlist(names))), collapse = ", ")
      rows <- dplyr::filter(pulled, dplyr::sql(sprintf("upper(%s) IN (%s)", name_col, inlist)))
      if (!is.null(unit_col) && !is.null(item[["units"]])) {              # restrict to configured units (ci)
        ulist <- paste(vapply(item[["units"]], function(u) sprintf("'%s'", tolower(as.character(u))), ""), collapse = ", ")
        rows <- dplyr::filter(rows, dplyr::sql(sprintf("lower(%s) IN (%s)", unit_col, ulist)))
      }
      # ORDERING FROM THE SHARED REGISTRY == clinical.py _selection_order. All four picks, and the
      # date tie resolved by `tie_break` — not the legacy `aggregate` key alone, which made a block
      # written `pick: priority` rank by nearest here and by priority in Python.
      ipick <- selection_spec(blk, item, "pick")
      itie <- selection_spec(blk, item, "tie_break")
      isdc <- selection_spec(blk, item, "same_date_conflict")
      if (identical(isdc, "resolve")) {
        near <- clinical_resolve_then_pick(rows, blk, item, date_col, label_sql, nm)
        keep <- c(nm, paste0(nm, "n"))
        if (isTRUE(blk[["emit_date"]])) {
          near <- dplyr::mutate(near, !!paste0(nm, "dt") := !!rlang::sym(date_col))
          keep <- c(keep, paste0(nm, "dt"))
        }
        near <- near %>% dplyr::select(patientid, index_date, dplyr::all_of(keep))
        clin <- dplyr::left_join(clin, near, by = c("patientid", "index_date"))
        next
      }
      if (identical(isdc, "refuse")) {
        # == clinical.py::_refuse_same_date_conflict. This and the value-ties below were
        # Python-only until the resolve work touched this loop - inert (no pack declares
        # them) but a silent divergence the day one did.
        clash <- rows %>% dplyr::mutate(`_v` = dplyr::sql(label_sql)) %>%
          dplyr::group_by(patientid, index_date, !!rlang::sym(date_col)) %>%
          dplyr::summarise(`_n` = dplyr::sql("count(distinct `_v`)"), .groups = "drop") %>%
          dplyr::filter(`_n` > 1) %>% utils::head(1) %>% dplyr::collect()
        if (nrow(clash) > 0)
          stop(sprintf("%s: same_date_conflict is `refuse` and two same-day records disagree", nm))
      }
      idt <- if (identical(itie, "prior")) rlang::expr(!!rlang::sym(date_col))
             else rlang::expr(dplyr::desc(!!rlang::sym(date_col)))
      # A TOTAL ORDER == clinical.py `value_tie`. Two records on the SAME DATE with different
      # values is the ordinary case; without a final key each engine returns whichever row its
      # own backend happened to place first, so the two could disagree — and either could
      # disagree with itself between runs. Ordering last on the mapped label makes the choice
      # deterministic. It does not make it right; `same_date_conflict` is what says that.
      # MATERIALISED INTO A COLUMN, like `_rank` below it. This built the tie-break key as a
      # `sql()` expression and handed it straight to window_order, which dbplyr 2.6.0 refuses
      # ("Element 3 is `<sql>`"). The SQL is unchanged — only where it is evaluated moves, from
      # inside the ORDER BY to a column the ORDER BY names. `_ival` never survives: the block ends
      # with `select(patientid, index_date, all_of(keep))`.
      ival_sql <- label_sql
      ival_desc <- identical(isdc, "max")
      if (identical(isdc, "priority")) {
        sprio <- item[["priority"]] %||% lapply(item[["groups"]], function(g) g[["label"]])
        ival_sql <- paste0("CASE ", paste(vapply(seq_along(sprio), function(i)
          sprintf("WHEN (%s) = %s THEN %d", label_sql, .sql_str(as.character(sprio[[i]])), i - 1L),
          ""), collapse = " "), sprintf(" ELSE %d END", length(sprio)))
      }
      rows <- dplyr::mutate(rows, `_ival` = dplyr::sql(ival_sql))
      ival <- if (ival_desc) rlang::expr(dplyr::desc(`_ival`)) else rlang::sym("_ival")
      if (identical(ipick, "priority")) {
        prio <- item[["priority"]] %||% lapply(item[["groups"]], function(g) g[["label"]])
        rank_sql <- paste0("CASE ", paste(vapply(seq_along(prio), function(i)
          sprintf("WHEN (%s) = '%s' THEN %d", label_sql,
                  gsub("'", "''", as.character(prio[[i]])), i - 1L), ""), collapse = " "),
          sprintf(" ELSE %d END", length(prio)))
        ord <- rows %>% dplyr::mutate(`_rank` = dplyr::sql(rank_sql)) %>%
          dplyr::group_by(patientid, index_date) %>%
          dbplyr::window_order(`_rank`, !!idt, !!ival)
      } else if (identical(ipick, "earliest")) {
        ord <- rows %>% dplyr::group_by(patientid, index_date) %>%
          dbplyr::window_order(!!rlang::sym(date_col), !!ival)
      } else if (identical(ipick, "latest")) {
        ord <- rows %>% dplyr::group_by(patientid, index_date) %>%
          dbplyr::window_order(dplyr::desc(!!rlang::sym(date_col)), !!ival)
      } else {
        ord <- rows %>% dplyr::group_by(patientid, index_date) %>%
          dbplyr::window_order(`_gap`, !!idt, !!ival)
      }
      # `emit_date` adds the WINNING record's date as <name>dt == clinical.py _closest_panel. Opt-in
      # per block: biomarkers and labs leave it unset, so their columns are unchanged. For a
      # `priority` pick the winner is not the nearest row, so the date cannot be re-derived later.
      keep <- c(nm, paste0(nm, "n"))
      near <- ord %>%
        dplyr::mutate(`_rn` = dplyr::row_number()) %>% dplyr::ungroup() %>%
        dplyr::filter(`_rn` == 1) %>%
        dplyr::mutate(!!nm := dplyr::sql(label_sql), !!paste0(nm, "n") := dplyr::sql(code_sql))
      if (isTRUE(blk[["emit_date"]])) {
        near <- dplyr::mutate(near, !!paste0(nm, "dt") := !!rlang::sym(date_col))
        keep <- c(keep, paste0(nm, "dt"))
      }
      near <- near %>% dplyr::select(patientid, index_date, dplyr::all_of(keep))
      clin <- dplyr::left_join(clin, near, by = c("patientid", "index_date"))
    }
  }

  # Metastatic-site presence flags at index (hepatic/lung/adrenal/bone/brain). == clinical.py.
  # Baseline comorbidity burden == clinical.py, config-gated like every other optional family.
  ccib <- clin_cfg[["comorbidity_index"]]
  if (!is.null(ccib) && !is.null(src[[ccib[["source"]]]]) && !is.null(ccib[["conditions"]])) {
    cc <- clinical_comorbidity_index(src, idx, ccib)
    if (!is.null(cc)) clin <- dplyr::left_join(clin, cc, by = c("patientid", "index_date"))
  }

  msblk <- clin_cfg[["metastatic_sites"]]
  if (!is.null(msblk) && !is.null(src[[msblk[["source"]]]]) && !is.null(msblk[["sites"]])) {
    ms <- clinical_metastatic_sites(src, idx, msblk)
    if (!is.null(ms)) clin <- dplyr::left_join(clin, ms, by = c("patientid", "index_date"))
  }

  # Closest-to-index raw lab VALUE panel (LABNEU present + LABNEUv value + LABNEUdt date). == clinical.py.
  lvblk <- clin_cfg[["lab_values"]]
  if (!is.null(lvblk) && !is.null(src[[lvblk[["source"]]]]) && !is.null(lvblk[["panel"]]))
    clin <- dplyr::left_join(clin, clinical_closest_values_panel(src, idx, lvblk),
                             by = c("patientid", "index_date"))

  # Windowed PSA timepoints + PSA-response endpoints (PSA at index/6mo/12mo; PSA50/undetectable). == clinical.py.
  psablk <- clin_cfg[["psa_timepoints"]]
  if (!is.null(psablk) && !is.null(src[[psablk[["source"]]]]) && !is.null(psablk[["points"]]))
    clin <- dplyr::left_join(clin, clinical_psa_timepoints(src, idx, psablk), by = c("patientid", "index_date"))

  # OC surgery sub-block (issurg/surg/surgn/neoadj + tt_first_tx_diag). == clinical.py _surgery.
  scfg <- clin_cfg[["surgery"]]
  if (!is.null(scfg) && !is.null(src[[scfg[["source"]]]])) {
    sg <- clinical_surgery(src, idx, scfg)
    if (!is.null(sg)) clin <- dplyr::left_join(clin, sg, by = c("patientid", "index_date"))
  }

  mblk <- clin_cfg[["min_avail_date"]]
  if (!is.null(mblk) && (!is.null(mblk[["sources"]]) || !is.null(mblk[["base_columns"]]))) {
    mad <- clinical_min_avail_date(src, idx, mblk, cfg_index_source(cfg))
    if (!is.null(mad)) clin <- dplyr::left_join(clin, mad, by = c("patientid", "index_date"))
  }

  if (!is.null(src[["vitals"]]) && !is.null(clin_cfg[["vitals"]]))
    clin <- dplyr::left_join(clin, clinical_vitals(src, idx, clin_cfg[["vitals"]]),
                             by = c("patientid", "index_date"))

  # Config-driven enhanced pass-through + presence flags. == clinical.py _passthrough.
  pblk <- clin_cfg[["passthrough"]]
  if (!is.null(pblk)) {
    pt <- clinical_passthrough(src, idx, pblk, cfg_index_source(cfg))
    if (!is.null(pt)) clin <- dplyr::left_join(clin, pt, by = c("patientid", "index_date"))
  }

  # Derived durations (months/days between dated milestones). == clinical.py _durations.
  dblk <- clin_cfg[["durations"]]
  if (!is.null(dblk) && !is.null(dblk[["items"]])) {
    dsrc <- src[[dblk[["source"]] %||% cfg_index_source(cfg)]]
    dhave <- if (is.null(dsrc)) character(0) else colnames(dsrc)
    dneed <- setdiff(unique(unlist(lapply(dblk[["items"]], function(it)
      Filter(function(x) !is.null(x) && x != "index_date", list(it[["from"]], it[["to"]]))))), dhave)
    if (length(dneed) > 0)   # a configured duration that silently vanishes is the failure (== clinical.py)
      stop(sprintf("clinical.durations names column(s) not on the loaded '%s' source: %s",
                   dblk[["source"]] %||% cfg_index_source(cfg), paste(sort(dneed), collapse = ", ")))
    du <- clinical_durations(src, idx, dblk, cfg_index_source(cfg))
    if (!is.null(du)) clin <- dplyr::left_join(clin, du, by = c("patientid", "index_date"))
  }

  # mCRPC index-window flag + MCRPCDD date — config-gated (clinical.mcrpc_window). == clinical.py.
  mcw <- clin_cfg[["mcrpc_window"]]
  isrc <- src[[cfg_index_source(cfg)]]
  if (!is.null(mcw) && length(mcw[["columns"]]) > 0) {   # missing column REFUSES (== clinical.py)
    have <- if (is.null(isrc)) character(0) else colnames(isrc)
    miss <- setdiff(unlist(mcw[["columns"]]), have)
    if (length(miss) > 0)
      stop(sprintf("clinical.mcrpc_window names column(s) not on the loaded '%s' source: %s",
                   cfg_index_source(cfg), paste(miss, collapse = ", ")))
  }
  if (!is.null(mcw) && !is.null(isrc)) {
    ecols <- colnames(isrc)
    if (all(unlist(mcw[["columns"]]) %in% ecols)) {
      start <- cfg_index_period_start(cfg); end <- cfg_index_period_end(cfg)  # enrollment window
      dnm <- mcw[["date_as"]] %||% "mcrpcdd"; fnm <- mcw[["flag_as"]] %||% "mcrpc"
      mcols <- unlist(mcw[["columns"]])
      # greatest needs >=2 args, so a single configured column IS the latest — == clinical.py
      mc <- isrc %>%
        dplyr::transmute(patientid, !!dnm := dplyr::sql(
          if (length(mcols) > 1) sprintf("greatest(%s)", paste(mcols, collapse = ", "))
          else mcols[[1]])) %>%
        dplyr::distinct(patientid, .keep_all = TRUE) %>%
        dplyr::mutate(!!fnm := dplyr::sql(sprintf(
          "CASE WHEN %s >= date('%s') AND %s <= date('%s') THEN 1 ELSE 0 END", dnm, start, dnm, end)))
      clin <- dplyr::left_join(clin, mc, by = "patientid")
    }
  }

  # Derived columns over the assembled frame (spec master mutate). == clinical.py::_derived.
  dvb <- clin_cfg[["derived"]]
  if (!is.null(dvb)) {
    have <- colnames(clin)
    for (it in dvb) {
      if (all(unlist(it[["requires"]]) %in% have)) {
        expr <- study_tokens(it[["expr"]], cfg)
        clin <- dplyr::mutate(clin, !!it[["name"]] := dplyr::sql(expr))
      }
    }
  }
  clin
}

# --- treatment: per-line lotcat + line-count bands. engine/stages/treatment.py ------------------
# config-driven drug-category column + category_equals values (== treatment.py::_drug_category_column /
# _category_equals_values) so the treatment stage never hardcodes a name/value the codelist can override.
drug_category_column <- function(codelist)
  codelist[["match_on"]][["drug_category_column"]] %||% "detaileddrugcategory"

category_equals_values <- function(codelist) {
  vals <- character(0)
  for (cat in codelist[["categories"]]) {
    v <- cat[["match"]][["category_equals"]]
    if (!is.null(v)) { v <- tolower(as.character(v)); if (!(v %in% vals)) vals <- c(vals, v) }
  }
  vals
}

treatment_categorize_line <- function(df, codelist, label_col = "lotcat", code_col = "lotcatn") {
  cc <- compile_case(codelist)               # PROVEN identical to Python (codelists.R)
  df %>% dplyr::mutate(!!label_col := dplyr::sql(cc$label),
                       !!code_col  := dplyr::sql(cc$code))
}

# One deterministic per-line frame (lot{i}* / lot{i}m*). == engine/stages/treatment.py::_line_frame.
# Column names come from the SHARED line_cols (cases.R) — the same source the Python engine and the
# parity test use — so the producer/consumer contract can't drift across engines.
treatment_line_frame <- function(rows, i, maint, mc, epi, codelist) {
  lc <- line_cols(i, maint)
  cat_col <- drug_category_column(codelist)    # config-driven (not a hardcoded "detaileddrugcategory")
  g <- dplyr::group_by(rows, patientid)
  g <- if (!isTRUE(maint) && mc %in% colnames(rows))
    dbplyr::window_order(g, !!rlang::sym(mc), startdate, enddate, linename)  # prefer non-maintenance
  else dbplyr::window_order(g, startdate, enddate, linename)
  line <- g %>% dplyr::mutate(`_rn` = dplyr::row_number()) %>% dplyr::ungroup() %>%
    dplyr::filter(`_rn` == 1)
  if (!is.null(epi)) {
    # epi is already scoped to this cohort's setting (treatment_build filters drug_episode before
    # aggregating) and lot_norm is single-setting, so the join keys on (patientid, linenumber) — the same
    # grain the pre-B1 loted join used. Drop the LOT-native category ONLY when epi supplies its own
    # (episode wins, avoids an ambiguous column); otherwise keep the LOT-native one. == treatment.py.
    if ((cat_col %in% colnames(line)) && (cat_col %in% colnames(epi)))
      line <- dplyr::select(line, -dplyr::all_of(cat_col))
    line <- line %>% dplyr::left_join(epi, by = c("patientid", "linenumber")) %>%
      dplyr::mutate(loted = dplyr::sql("coalesce(epi_lastdate, enddate)"))
  } else {
    line <- line %>% dplyr::mutate(loted = enddate)
  }
  # the drug-category column feeds the (unchanged) classifier; ensure it exists (typed null) for a tumor
  # without drug-episode data so the compiled CASE stays valid.
  if (!(cat_col %in% colnames(line)))
    line <- line %>% dplyr::mutate(!!cat_col := dplyr::sql("CAST(NULL AS STRING)"))
  line <- line %>%
    dplyr::transmute(patientid,
                     !!lc$name     := linename,
                     !!lc$start    := startdate,
                     !!lc$end      := enddate,
                     !!lc$lastdate := loted,
                     !!lc$dur      := dplyr::sql("datediff(loted, startdate) + 1"),  # lot{i}dur (days)
                     linename, !!rlang::sym(cat_col))
  line <- treatment_categorize_line(line, codelist, label_col = lc$cat, code_col = lc$catn)
  line %>% dplyr::select(-linename, -dplyr::all_of(cat_col))
}

# Generic prior-treatment predicate + flags. == engine/stages/treatment.py::_prior_pred/_prior_treatments.
prior_pred <- function(fl) {
  likes <- function(xs) paste(vapply(xs, function(x) sprintf("lower(linename) LIKE '%s'", tolower(x)),
                                     character(1)), collapse = " OR ")
  if (!is.null(fl[["all_of"]]))
    return(paste(vapply(fl[["all_of"]], function(grp) sprintf("(%s)", likes(grp)), character(1)),
                 collapse = " AND "))
  likes(fl[["like_any"]])
}


# G-PRIOR-TX episode model == treatment.py::_prior_treatments_episode: strictly before
# index, episode granularity, all_of within one line, monotherapy = every prior episode of
# a line matches, chemo by the declared category column.
treatment_prior_treatments_episode <- function(trt, idx, src, ptcfg, yes, no) {
  esrc <- ptcfg[["source"]]
  de <- src[[esrc]]
  if (is.null(de))
    stop(sprintf("BUILD REFUSED - prior_treatments reads source '%s', not given", esrc))
  nc <- ptcfg[["name_column"]]; dc <- ptcfg[["date_column"]]
  if (is.null(nc) || is.null(dc))
    stop("prior_treatments: the episode model needs `name_column` and `date_column`")
  cat_col <- ptcfg[["category_column"]]
  pre <- dplyr::select(idx, patientid, index_date) %>%
    dplyr::inner_join(de, by = "patientid") %>%
    dplyr::filter(dplyr::sql(sprintf("%s < index_date", dc)))   # STRICT: on-index not prior
  likes <- function(xs) paste(vapply(xs, function(x)
    sprintf("lower(%s) LIKE '%s'", nc, tolower(x)), character(1)), collapse = " OR ")
  for (fl in ptcfg[["flags"]]) {
    ce <- fl[["category_equals"]]
    if (!is.null(ce)) {
      if (is.null(cat_col))
        stop(sprintf("%s: category_equals is declared and the block names no `category_column`", fl[["name"]]))
      pred <- sprintf("lower(%s) = '%s'", cat_col, tolower(as.character(ce)))
    } else {
      pred <- likes(fl[["like_any"]] %||% unlist(fl[["all_of"]]))
    }
    if (!is.null(fl[["all_of"]])) {
      aggs <- list()
      for (j in seq_along(fl[["all_of"]]))
        aggs[[sprintf("_g%d", j - 1L)]] <- dplyr::sql(sprintf(
          "max(CASE WHEN (%s) THEN 1 ELSE 0 END)", likes(fl[["all_of"]][[j]])))
      cond <- paste(vapply(seq_along(fl[["all_of"]]) - 1L,
                           function(j) sprintf("`_g%d` = 1", j), character(1)), collapse = " AND ")
      hit <- pre %>% dplyr::group_by(patientid, index_date, linenumber) %>%
        dplyr::summarise(!!!aggs, .groups = "drop") %>%
        dplyr::filter(dplyr::sql(cond)) %>%
        dplyr::select(patientid, index_date) %>% dplyr::distinct()
    } else if (isTRUE(fl[["monotherapy"]])) {
      hit <- pre %>% dplyr::group_by(patientid, index_date, linenumber) %>%
        dplyr::summarise(`_all` = dplyr::sql(sprintf(
          "min(CASE WHEN (%s) THEN 1 ELSE 0 END)", pred)), .groups = "drop") %>%
        dplyr::filter(`_all` == 1) %>%
        dplyr::select(patientid, index_date) %>% dplyr::distinct()
    } else {
      hit <- pre %>% dplyr::filter(dplyr::sql(sprintf("(%s)", pred))) %>%
        dplyr::select(patientid, index_date) %>% dplyr::distinct()
    }
    hit <- dplyr::mutate(hit, `_h` = 1L)
    trt <- trt %>% dplyr::left_join(hit, by = c("patientid", "index_date")) %>%
      dplyr::mutate(!!fl[["name"]] := dplyr::sql(sprintf(
        "CASE WHEN `_h` IS NOT NULL THEN '%s' ELSE '%s' END", yes, no))) %>%
      dplyr::select(-`_h`)
  }
  trt
}

treatment_prior_treatments <- function(trt, idx, src, cfg, ptcfg) {
  yes <- ptcfg[["yes_label"]] %||% "Yes"; no <- ptcfg[["no_label"]] %||% "No"
  # G-PRIOR-TX: a declared source selects the episode model == treatment.py
  if (!is.null(ptcfg[["source"]]))
    return(treatment_prior_treatments_episode(trt, idx, src, ptcfg, yes, no))
  lot_all <- lot_normalized(src, NULL, exclude_settings = cfg_lot_exclude_settings(cfg),
                            line_number_col = cfg_lot_line_number_col(cfg),
                            maintenance_column = cfg_lot_maintenance_column(cfg))
  pre <- dplyr::select(idx, patientid, index_date) %>%
    dplyr::inner_join(lot_all, by = "patientid") %>% dplyr::filter(startdate <= index_date)
  for (fl in ptcfg[["flags"]]) {
    hit <- pre %>% dplyr::filter(dplyr::sql(sprintf("(%s)", prior_pred(fl)))) %>%
      dplyr::select(patientid, index_date) %>% dplyr::distinct() %>% dplyr::mutate(`_h` = 1L)
    trt <- trt %>% dplyr::left_join(hit, by = c("patientid", "index_date")) %>%
      dplyr::mutate(!!fl[["name"]] := dplyr::sql(sprintf(
        "CASE WHEN `_h` IS NOT NULL THEN '%s' ELSE '%s' END", yes, no))) %>%
      dplyr::select(-`_h`)
  }
  trt
}

# Concomitant/supportive-med exposure flags (BP/CSF/steroid). == treatment.py::_conmed_exposures.
treatment_conmed_exposures <- function(trt, idx, src, ccfg) {
  csrc <- src[[ccfg[["source"]]]]; nc <- ccfg[["name_column"]]; dc <- ccfg[["date_column"]]
  if (is.null(csrc) || !(nc %in% colnames(csrc))) return(trt)
  yes <- ccfg[["yes_label"]] %||% "Yes"; no <- ccfg[["no_label"]] %||% "No"
  wd <- ccfg[["window_days"]] %||% list(NULL, NULL)
  pulled <- dplyr::select(idx, patientid, index_date) %>% dplyr::inner_join(csrc, by = "patientid")
  if (dc %in% colnames(csrc) && !is.null(wd[[1]]))
    pulled <- dplyr::filter(pulled, dplyr::sql(sprintf("%s >= date_add(index_date, %s)", dc, wd[[1]])))
  if (dc %in% colnames(csrc) && !is.null(wd[[2]]))
    pulled <- dplyr::filter(pulled, dplyr::sql(sprintf("%s <= date_add(index_date, %s)", dc, wd[[2]])))
  for (fl in ccfg[["flags"]]) {
    pred <- paste(vapply(fl[["like_any"]], function(p) sprintf("lower(%s) LIKE '%s'", nc, tolower(p)),
                         character(1)), collapse = " OR ")
    hit <- pulled %>% dplyr::filter(dplyr::sql(sprintf("(%s)", pred))) %>%
      dplyr::select(patientid, index_date) %>% dplyr::distinct() %>% dplyr::mutate(`_h` = 1L)
    trt <- trt %>% dplyr::left_join(hit, by = c("patientid", "index_date")) %>%
      dplyr::mutate(!!fl[["name"]] := dplyr::sql(sprintf(
        "CASE WHEN `_h` IS NOT NULL THEN '%s' ELSE '%s' END", yes, no))) %>%
      dplyr::select(-`_h`)
  }
  trt
}

# Per-setting line columns (LOT*_MHSPC / LOT*_MCRPC). == treatment.py::_setting_line_columns.
treatment_setting_line_columns <- function(src, idx, cfg, slc) {
  col_map <- list(sd = "startdate", ed = "enddate", name = "linename")
  attrs <- Filter(function(a) !is.null(col_map[[a]]), slc[["attributes"]] %||% c("sd", "name"))
  out <- idx %>% dplyr::select(patientid, index_date)
  nlines_cfg <- slc[["lines"]] %||% 2
  de <- src[["drug_episode"]]
  for (setting in slc[["settings"]]) {
    suffix <- tolower(setting)
    # G-PER-SETTING-LOT + G-SETTING-LOT-ED == treatment.py::_setting_line_columns
    nlines <- if (is.list(nlines_cfg)) {
      if (is.null(nlines_cfg[[setting]]))
        stop(sprintf("treatment.setting_line_columns: `lines` maps per setting and names no entry for '%s'", setting))
      as.integer(nlines_cfg[[setting]])
    } else as.integer(nlines_cfg)
    norm <- lot_normalized(src, setting, exclude_settings = cfg_lot_exclude_settings(cfg),
                           line_number_col = cfg_lot_line_number_col(cfg),
                           maintenance_column = cfg_lot_maintenance_column(cfg))
    if (("ed" %in% attrs) && !is.null(de) && all(c("linenumber", "episodedate") %in% colnames(de))) {
      if (!("linesetting" %in% colnames(de)))
        stop(sprintf("treatment.setting_line_columns: setting '%s' is configured but drug_episode has no linesetting column", setting))
      epi <- de %>% dplyr::filter(dplyr::sql(sprintf("linesetting = %s", .sql_str(setting)))) %>%
        dplyr::group_by(patientid, linenumber) %>%
        dplyr::summarise(`_ep_ed` = dplyr::sql("max(episodedate)"), .groups = "drop")
      norm <- dplyr::left_join(norm, epi, by = c("patientid", "linenumber")) %>%
        dplyr::mutate(`_sl_ed` = dplyr::sql("coalesce(`_ep_ed`, enddate)"))
    } else {
      norm <- dplyr::mutate(norm, `_sl_ed` = dplyr::sql("enddate"))
    }
    for (i in seq_len(nlines)) {
      sels <- stats::setNames(lapply(attrs, function(a)
                                rlang::sym(if (identical(a, "ed")) "_sl_ed" else col_map[[a]])),
                              vapply(attrs, function(a) sprintf("lot%d%s_%s", i, a, suffix), ""))
      li <- norm %>% dplyr::filter(new_lot_n == i) %>%
        dplyr::transmute(patientid, !!!sels) %>% dplyr::distinct(patientid, .keep_all = TRUE)
      out <- dplyr::left_join(out, li, by = "patientid")
    }
  }
  out
}

treatment_build <- function(src, idx, cfg, cohort = NULL) {
  trt_cfg <- cfg_pack(cfg, "treatment")
  codelist <- cfg_codelist(cfg, "treatment_categories")
  base <- dplyr::select(idx, patientid, index_date)
  # Full configured LOT model (exclude_settings / line_number_col / maintenance_column) like the
  # Python treatment stage and the R index stage — NO maintenance filter (all lines) — so the
  # per-line columns are numbered identically for the OC/EC linenumber model. == treatment.py.
  line_setting <- cohort[["line_setting"]] %||% cfg_lot_line_setting(cfg)   # effective setting (or NULL)
  lot_norm <- lot_normalized(src, line_setting,
                             exclude_settings   = cfg_lot_exclude_settings(cfg),   # per-cohort setting
                             line_number_col    = cfg_lot_line_number_col(cfg),    # (dual-setting products)
                             maintenance_column = cfg_lot_maintenance_column(cfg))

  # Per-line drug-episode aggregate (loted -> lot{i}ed AND the per-line chemotherapy indicator that
  # feeds lotcatn=9): the delivered data carries detaileddrugcategory on DrugEpisode, not LOT, so the
  # category is aggregated here and joined onto the line. SETTING GRAIN (config-driven): scope the
  # aggregate to the SAME setting as lot_norm — when a line setting is configured, FILTER drug_episode to
  # it and aggregate by (patientid, linenumber); otherwise aggregate on (patientid, linenumber) with no
  # setting. Do NOT key on linesetting just because the physical source carries it. The classifier/codelist
  # DSL is unchanged (compiler parity unaffected). Optional: falls back to enddate + null category without
  # the drug_episode source. == engine/stages/treatment.py.
  de <- src[["drug_episode"]]
  epi <- NULL
  if (!is.null(de) && all(c("linenumber", "episodedate") %in% colnames(de))) {
    de_cols <- colnames(de)
    if (!is.null(line_setting)) {
      # a setting IS configured -> the aggregate MUST be scoped to it; fail loudly rather than silently
      # combine episodes across settings (preflight normally catches this). == engine/stages/treatment.py.
      if (!("linesetting" %in% de_cols))
        stop(sprintf(paste0("treatment stage: line setting '%s' is configured but drug_episode has no ",
                            "'linesetting' column to scope the per-line aggregate — this would combine ",
                            "episodes across settings. Add linesetting to drug_episode, or clear the ",
                            "line setting."), line_setting))
      de <- de %>% dplyr::filter(linesetting == !!line_setting)   # scope to this cohort's setting
    }
    cat_col <- drug_category_column(codelist)
    cat_values <- category_equals_values(codelist)
    if ((cat_col %in% de_cols) && length(cat_values) > 0) {
      # synthesize cat_col = the FIRST category_equals value present on the line (codelist order keeps
      # first-match-wins), else NULL — column + values from config, not hardcoded. == treatment.py.
      cat_sql <- paste0("CASE ",
        paste(vapply(cat_values, function(v)
          sprintf("WHEN max(CASE WHEN lower(`%s`) = '%s' THEN 1 ELSE 0 END) = 1 THEN '%s'",
                  cat_col, gsub("'", "''", v), gsub("'", "''", v)), character(1)), collapse = " "),
        " ELSE CAST(NULL AS STRING) END")
      epi <- de %>% dplyr::group_by(patientid, linenumber) %>%
        dplyr::summarise(epi_lastdate = max(episodedate, na.rm = TRUE),
                         !!cat_col := dplyr::sql(cat_sql), .groups = "drop")
    } else {
      # no category column / no category_equals -> epi carries only epi_lastdate; the line keeps any
      # LOT-native category (episode wins ONLY when it sources one). == engine/stages/treatment.py.
      epi <- de %>% dplyr::group_by(patientid, linenumber) %>%
        dplyr::summarise(epi_lastdate = max(episodedate, na.rm = TRUE), .groups = "drop")
    }
  }

  lotn <- base %>%
    dplyr::left_join(dplyr::select(lot_norm, patientid, new_lot_n), by = "patientid") %>%
    dplyr::group_by(patientid) %>%
    # coalesce 0: raw LOTN=0 for the untreated is a REQUIREMENT (G-LOTN-ZERO); the bands
    # already read null as the fallthrough "0" - this aligns the raw column. == treatment.py.
    dplyr::mutate(lotn = dplyr::sql("coalesce(max(new_lot_n) over (partition by patientid), 0)")) %>%
    dplyr::ungroup() %>%
    dplyr::select(patientid, index_date, lotn) %>% dplyr::distinct()
  bands <- trt_cfg[["lot_count_bands"]]
  if (!is.null(bands))
    lotn <- lotn %>% dplyr::mutate(
      lotngrl  = dplyr::sql(lot_bands_case(bands, "lotn", "label")),
      lotngrln = dplyr::sql(lot_bands_case(bands, "lotn", "code")))

  trt <- base
  mc <- cfg_lot_maintenance_column(cfg)
  # ALSO emit lot{i}m* (maintenance line) for tumors with maintenance cohorts. == treatment.py.
  emit_maint <- (mc %in% colnames(lot_norm)) &&
    any(vapply(cfg_cohorts(cfg), function(co) !is.null(co[["maintenance"]]), logical(1)))
  for (i in seq_len(trt_cfg[["max_lines"]])) {
    li <- lot_norm %>% dplyr::filter(new_lot_n == i)
    trt <- dplyr::left_join(trt, treatment_line_frame(li, i, FALSE, mc, epi, codelist), by = "patientid")
    if (emit_maint) {
      li_m <- li %>% dplyr::filter(dplyr::sql(sprintf("%s = 'True'", mc)))
      trt <- dplyr::left_join(trt, treatment_line_frame(li_m, i, TRUE, mc, epi, codelist), by = "patientid")
    }
  }

  # prior taxane flags — cohort-aware, prostate-specific (optional). == engine/stages/treatment.py.
  pt <- trt_cfg[["prior_taxane"]]
  if (!is.null(pt) && !is.null(cohort)) {
    yes <- pt[["yes_label"]] %||% "Yes"; no <- pt[["no_label"]] %||% "No"
    pred <- taxane_pred(pt[["drug_name_like_any"]])
    ln <- cohort[["lot_number"]]
    if (is.null(ln)) {
      trt <- dplyr::mutate(trt, prior_tax_mcrpc = no)
    } else if (ln == 1) {
      trt <- dplyr::mutate(trt, prior_tax_mcrpc = dplyr::sql("CAST(NULL AS STRING)"))
    } else {
      prior <- lot_norm %>%
        dplyr::filter(new_lot_n >= 1, new_lot_n < ln, dplyr::sql(sprintf("(%s)", pred))) %>%
        dplyr::distinct(patientid) %>% dplyr::mutate(`_ptm` = 1L)
      trt <- trt %>% dplyr::left_join(prior, by = "patientid") %>%
        dplyr::mutate(prior_tax_mcrpc = dplyr::sql(sprintf(
          "CASE WHEN `_ptm` IS NOT NULL THEN '%s' ELSE '%s' END", yes, no))) %>%
        dplyr::select(-`_ptm`)
    }
    pre_name <- pt[["pre_mcrpc_source"]]
    if (!is.null(pre_name) && !is.null(src[[pre_name]])) {
      ppt <- dplyr::select(idx, patientid, index_date) %>%
        dplyr::inner_join(dplyr::select(src[[pre_name]], patientid, linename, startdate), by = "patientid") %>%
        dplyr::filter(startdate <= index_date, dplyr::sql(sprintf("(%s)", pred))) %>%
        dplyr::distinct(patientid) %>% dplyr::mutate(`_ptp` = 1L)
      trt <- trt %>% dplyr::left_join(ppt, by = "patientid") %>%
        dplyr::mutate(prior_tax_pre_mcrpc = dplyr::sql(sprintf(
          "CASE WHEN `_ptp` IS NOT NULL THEN '%s' ELSE '%s' END", yes, no))) %>%
        dplyr::select(-`_ptp`)
    }
  }

  # Generic prior-treatment flags (PRIOR_*) — cohort-independent (any prior line, any setting). Optional.
  ptm <- trt_cfg[["prior_treatments"]]
  if (!is.null(ptm) && !is.null(ptm[["flags"]]))
    trt <- treatment_prior_treatments(trt, idx, src, cfg, ptm)

  # Concomitant/supportive-med exposure flags (BP / CSF / STEROID) — cohort-independent. Optional.
  cm <- trt_cfg[["conmed_exposures"]]
  if (!is.null(cm) && !is.null(cm[["flags"]]))
    trt <- treatment_conmed_exposures(trt, idx, src, cm)

  # Per-setting line columns (LOT*_MHSPC / LOT*_MCRPC). == treatment.py.
  slc <- trt_cfg[["setting_line_columns"]]
  if (!is.null(slc) && !is.null(slc[["settings"]]))
    trt <- dplyr::left_join(trt, treatment_setting_line_columns(src, idx, cfg, slc),
                            by = c("patientid", "index_date"))

  dplyr::left_join(trt, lotn, by = c("patientid", "index_date"))
}

# The seam validator, mirroring stages/outcomes.py::pfs_semantics/ttnt_scope - closed
# vocabularies whose values are BOTH implemented (G-RWPFS, G-TTNT-CROSS): an unknown
# declaration refuses the build, the implemented values pass. An audit found an earlier
# version DEFINED INSIDE outcomes_build's body - called on entry before the local
# assignment had run, so every R outcomes build died - and still refusing the values the
# engines implement. Top level by contract; a test pins this line at brace depth zero.
outcomes_seams_check <- function(out_cfg) {
  ts <- out_cfg[["ttnt_scope"]] %||% "same_setting"
  if (!ts %in% c("same_setting", "cross_setting"))
    stop(sprintf("BUILD REFUSED - outcomes.ttnt_scope '%s' is not one of same_setting, cross_setting", ts))
  ps <- (out_cfg[["progression"]] %||% list())[["semantics"]] %||% "incumbent"
  if (!ps %in% c("incumbent", "contract"))
    stop(sprintf("BUILD REFUSED - outcomes.progression.semantics '%s' is not one of incumbent, contract", ps))
  invisible(NULL)
}

# --- outcomes: id3mosfu + OS. engine/stages/outcomes.py ----------------------------------------
outcomes_build <- function(src, idx, clin, trt, cfg, cohort = NULL) {
  # the decision-staged seams are validated on EVERY build - an audit found this
  # function DEFINED and never called, an inert mirror the static test could not see
  outcomes_seams_check(cfg_pack(cfg, "outcomes"))

  out_cfg <- cfg_pack(cfg, "outcomes")
  min_fu <- out_cfg[["min_followup_days"]]; dpm <- out_cfg[["days_per_month"]]
  end <- cfg_observation_end(cfg)          # observation end, not the enrollment close (== outcomes.py)
  keys <- c("patientid", "index_date")
  base <- dplyr::select(idx, patientid, index_date)
  out <- base %>% dplyr::mutate(id3mosfu = dplyr::sql(sprintf(
    "CASE WHEN datediff(date('%s'), index_date) >= %s THEN 1 ELSE 0 END", end, min_fu)))

  # ONE STUDY, SEVERAL AIMS, ONE COHORT — mirrors the note in stages/outcomes.py. Each entry
  # publishes its own flag; id3mosfu keeps its meaning and keeps gating what it always gated, so
  # no committed number moves.
  extra <- out_cfg[["followup_sufficiency"]]
  if (is.null(extra)) extra <- list()
  for (entry in extra) {
    nm <- as.character(entry[["name"]])
    out <- dplyr::mutate(out, !!nm := dplyr::sql(sprintf(
      "CASE WHEN datediff(date('%s'), index_date) >= %s THEN 1 ELSE 0 END", end, entry[["days"]])))
  }

  # Death/follow-up anchors (dthfl/dthdt/fued) feed BOTH OS and the line outcomes — join once.
  anchors <- intersect(c("dthfl", "dthdt", "fued", "dth_before_fued"),
                       if (is.null(clin)) character(0) else colnames(clin))
  if (length(anchors) > 0)
    out <- dplyr::left_join(out, dplyr::select(clin, dplyr::all_of(c(keys, anchors))), by = keys)

  os_cfg <- out_cfg[["overall_survival"]]
  if (!is.null(os_cfg)) {
    required <- c(os_cfg[["event_flag"]], os_cfg[["death_anchor"]], os_cfg[["censor_anchor"]])
    missing <- setdiff(required, if (is.null(clin)) character(0) else colnames(clin))
    if (length(missing) > 0)
      stop(sprintf(paste0("outcomes_build: clinical stage did not emit OS anchor column(s) %s ",
        "(from clinical_follow_up_and_death) — or remove overall_survival from outcomes.yaml."),
        paste(missing, collapse = ", ")))
    # WHICH FLAG GATES OS — id3mosfu unless the pack says otherwise (== outcomes.py).
    gate <- os_cfg[["gate"]]; if (is.null(gate) || !nzchar(as.character(gate))) gate <- "id3mosfu"
    cond <- if (identical(gate, "none")) "" else sprintf("%s = 1 AND ", gate)
    head <- if (identical(gate, "none")) "CASE " else sprintf("CASE WHEN %s = 0 THEN NULL ", gate)
    out <- out %>% dplyr::mutate(os = dplyr::sql(sprintf(paste0(
        head,
        "WHEN %s%s = 1 THEN (datediff(%s, index_date)+1)/%s ",
        "WHEN %s%s = 0 THEN (datediff(%s, index_date)+1)/%s ",
        "ELSE NULL END"),
        cond, os_cfg[["event_flag"]], os_cfg[["death_anchor"]], dpm,
        cond, os_cfg[["event_flag"]], os_cfg[["censor_anchor"]], dpm)))
  }
  emitted <- c("id3mosfu", vapply(extra, function(e) as.character(e[["name"]]), ""),
               if (!is.null(os_cfg)) "os")


# Line-cohort outcomes (vis120/trtdis/ttd/ttntfl/ttnt). Optional + config-gated; == outcomes.py.
  lo <- out_cfg[["line_outcomes"]]
  if (!is.null(lo) && !is.null(trt)) {
    win <- out_cfg[["visit_recency_days"]]
    ln <- cohort[["lot_number"]]
    maint <- isTRUE(cohort[["maintenance"]])          # a lot{N}m cohort keys off the maintenance line
    if (!is.null(ln)) {
      cur <- line_cols(ln, maint); nxt <- line_cols(ln + 1)   # this line (maint-aware) + next (non-maint)
      nxt2 <- line_cols(ln + 2)
      has_next <- nxt$start %in% colnames(trt)
      has_n2 <- nxt2$start %in% colnames(trt)
      # G-TTNT-CROSS, mirroring outcomes.py: declared means present, or the build stops.
      ts <- out_cfg[["ttnt_scope"]] %||% "same_setting"
      cross_col <- if (identical(ts, "cross_setting")) cohort[["ttnt_cross_column"]] else NULL
      if (!is.null(cross_col) && !cross_col %in% colnames(trt))
        stop(sprintf("outcomes: cohort declares ttnt_cross_column '%s' and the treatment frame does not carry it", cross_col))
      want <- c("lotn", cur$start, cur$lastdate, if (has_next) nxt$start, cross_col,
                if (isTRUE(lo[["tsst"]]) && has_n2) nxt2$start)
      tcols <- intersect(want, colnames(trt))
      out <- dplyr::left_join(out, dplyr::select(trt, dplyr::all_of(c(keys, tcols))), by = keys)
      vis <- outcomes_vis120(src, dplyr::select(out, patientid, index_date, !!rlang::sym(cur$lastdate)),
                             lo, win, cur$lastdate)
      out <- dplyr::left_join(out, vis, by = keys)
      gate <- sprintf("id3mosfu = 1 AND %s IS NOT NULL", cur$start)
      out <- out %>% dplyr::mutate(
        trtdis = dplyr::sql(sprintf("CASE WHEN %s THEN (%s) ELSE NULL END", gate, trtdis_sql(ln))),
        ttntfl = dplyr::sql(sprintf("CASE WHEN id3mosfu = 1 THEN (%s) ELSE NULL END",
                                    ttntfl_sql(ln, cross_col))),
        ttnt   = dplyr::sql(sprintf("CASE WHEN id3mosfu = 1 THEN (%s) ELSE NULL END",
                                    ttnt_sql(ln, dpm, has_next, cross_col))))
      if (ln >= as.integer(lo[["ttd_from_line"]] %||% 1))
        out <- dplyr::mutate(out, ttd = dplyr::sql(sprintf(
          "CASE WHEN id3mosfu = 1 THEN (%s) ELSE NULL END", ttd_sql(ln, dpm, maint))))
      else
        out <- dplyr::mutate(out, ttd = dplyr::sql("CAST(NULL AS DOUBLE)"))
      if (isTRUE(lo[["tsst"]]))                          # time to 2nd subsequent treatment (TSST)
        out <- out %>% dplyr::mutate(
          tsstfl = dplyr::sql(sprintf("CASE WHEN id3mosfu = 1 THEN (%s) ELSE NULL END", tsstfl_sql(ln))),
          tsst   = dplyr::sql(sprintf("CASE WHEN id3mosfu = 1 THEN (%s) ELSE NULL END",
                                      tsst_sql(ln, dpm, has_n2))))
    } else {
      # not applicable is NULL, like its siblings (== outcomes.py: no line endpoint, no window)
      out <- out %>% dplyr::mutate(
        vis120 = dplyr::sql("CAST(NULL AS INT)"), lastvisitdate = dplyr::sql("CAST(NULL AS DATE)"),
        trtdis = dplyr::sql("CAST(NULL AS INT)"), ttntfl = dplyr::sql("CAST(NULL AS INT)"),
        ttd = dplyr::sql("CAST(NULL AS DOUBLE)"), ttnt = dplyr::sql("CAST(NULL AS DOUBLE)"))
      if (isTRUE(lo[["tsst"]]))
        out <- out %>% dplyr::mutate(tsstfl = dplyr::sql("CAST(NULL AS INT)"),
                                     tsst = dplyr::sql("CAST(NULL AS DOUBLE)"))
    }
    emitted <- c(emitted, "vis120", "lastvisitdate", "trtdis", "ttd", "ttntfl", "ttnt")
    if (isTRUE(lo[["tsst"]])) emitted <- c(emitted, "tsstfl", "tsst")
  }

  # Real-world PFS / PFS2 (progression family). Optional. == engine/stages/outcomes.py.
  pcfg <- out_cfg[["progression"]]
  pfs_sem <- pcfg[["semantics"]] %||% "incumbent"   # == outcomes.py::pfs_semantics
  if (!is.null(pcfg) && !is.null(src[[pcfg[["source"]]]])) {
    miss <- setdiff(c("dthdt", "fued"), colnames(out))
    if (length(miss) > 0)
      stop(sprintf(paste0("outcomes_build: progression PFS needs clinical anchor(s) %s ",
        "(from clinical_follow_up_and_death) — or remove progression from outcomes.yaml."),
        paste(miss, collapse = ", ")))
    is_line <- !is.null(cohort[["lot_number"]])
    suppress <- isTRUE(pcfg[["line_cohorts_only"]]) && !is_line
    # rwPFS censor: emit the RAW last clinic-note date (NULL when no clinic note); censor at
    # coalesce(clinic-note, fued). Keeping raw separate lets ELIGPFS require a note AFTER index. == outcomes.py.
    censor_anchor <- "fued"; ccfg <- pcfg[["censor"]]; clinic_raw <- NULL
    if (!is.null(ccfg) && !is.null(src[[ccfg[["source"]]]])) {
      cas <- ccfg[["as"]] %||% "lastclinicnotedate"; cdate <- ccfg[["date_column"]]
      aggf <- if (identical(ccfg[["aggregate"]], "min")) "min" else "max"
      censor_df <- src[[ccfg[["source"]]]] %>% dplyr::group_by(patientid) %>%
        dplyr::summarise(!!cas := dplyr::sql(sprintf("%s(%s)", aggf, cdate)), .groups = "drop")
      out <- dplyr::left_join(out, censor_df, by = "patientid") %>%                # cas = RAW clinic-note date
        dplyr::mutate(`_censor` = dplyr::sql(sprintf("coalesce(%s, fued)", cas)))  # censor anchor (fallback)
      censor_anchor <- "_censor"; clinic_raw <- cas
      emitted <- c(emitted, cas)
    }

    # rwPFS gate (== ELIGPFS): id3mosfu AND (when configured) a clinic note after index; drives BOTH the
    # eligibility flag and the PFS family so ineligible -> NULL throughout. Default (OC/EC) = id3mosfu only.
    gate <- "id3mosfu = 1"
    if (isTRUE(pcfg[["eligibility_requires_censor"]]) && !is.null(clinic_raw))
      gate <- sprintf("id3mosfu = 1 AND %s > index_date", clinic_raw)

    eflag <- pcfg[["eligibility_flag"]]                    # prostate ELIGPFS
    if (!is.null(eflag)) {
      out <- dplyr::mutate(out, !!eflag := dplyr::sql(
        if (is_line) sprintf("CASE WHEN %s THEN 1 ELSE 0 END", gate) else "CAST(NULL AS INT)"))
      emitted <- c(emitted, eflag)
    }
    out <- dplyr::left_join(out, outcomes_progression(src[[pcfg[["source"]]]], idx, pcfg, dpm), by = keys)
    specs <- list(c("pfsfl", "pfsdt", "pfs", "_prog1"), c("pfs2fl", "pfs2dt", "pfs2", "_prog2"))
    for (sp in specs) {
      if (identical(sp[3], "pfs2") && !isTRUE(pcfg[["pfs2"]])) next
      if (suppress) {                                       # overall cohort -> NULL family (column-aligned)
        out <- out %>%
          dplyr::mutate(!!sp[1] := dplyr::sql("CAST(NULL AS INT)")) %>%
          dplyr::mutate(!!sp[2] := dplyr::sql("CAST(NULL AS DATE)")) %>%
          dplyr::mutate(!!sp[3] := dplyr::sql("CAST(NULL AS DOUBLE)"))
      } else {
        # flag/date/months all gated on the rwPFS `gate` (== ELIGPFS); ineligible patients null throughout.
        out <- out %>%
          dplyr::mutate(`_evt` = dplyr::sql(sprintf(
            # == outcomes.py::_pfs_event_sql - contract = progression precedence (coalesce)
            if (identical(pfs_sem, "contract")) "coalesce(%s, dthdt)" else "least(%s, dthdt)",
            sp[4]))) %>%
          dplyr::mutate(!!sp[1] := dplyr::sql(sprintf(
            "CASE WHEN %s AND `_evt` IS NOT NULL THEN 1 WHEN %s THEN 0 ELSE NULL END", gate, gate))) %>%
          dplyr::mutate(!!sp[2] := dplyr::sql(
            # == outcomes.py::_pfs_date_sql - contract = PFSDT NULL on censor
            if (identical(pfs_sem, "contract"))
              sprintf("CASE WHEN %s THEN `_evt` ELSE NULL END", gate)
            else sprintf("CASE WHEN %s THEN coalesce(`_evt`, %s) ELSE NULL END", gate, censor_anchor))) %>%
          dplyr::mutate(!!sp[3] := dplyr::sql(sprintf(
            # months read the censor-coalesced value under BOTH semantics - a censored patient
            # contributes censored time even when the contract branch nulls the DATE column
            "CASE WHEN %s THEN (datediff(coalesce(`_evt`, %s), index_date)+1)/%s ELSE NULL END",
            gate, censor_anchor, dpm))) %>%
          dplyr::select(-`_evt`)
      }
      emitted <- c(emitted, sp[1], sp[2], sp[3])
    }
    out <- dplyr::select(out, -`_prog1`, -`_prog2`)
  }
  # the corruption guard, consumed (== outcomes.py): OS/TRTDIS/TTD/TTNTFL/TTNT go NA when it
  # fires; TSST deliberately not gated pending OUTCOME-COHORT-MAP.
  if ("dth_before_fued" %in% colnames(out)) {
    for (gc in intersect(c("os", "trtdis", "ttd", "ttntfl", "ttnt"), colnames(out))) {
      out <- dplyr::mutate(out, !!gc := dplyr::sql(sprintf(
        "CASE WHEN dth_before_fued = 1 THEN NULL ELSE %s END", gc)))
    }
  }
  dplyr::select(out, dplyr::all_of(c("patientid", "index_date", emitted)))
}

# First/second qualifying progression dates per (patientid, index_date). == outcomes.py::_progression.
outcomes_progression <- function(prog_df, idx, pcfg, dpm) {
  date_col <- pcfg[["date_column"]]
  excl <- as.integer(pcfg[["exclusion_days"]] %||% 0)      # progression > index + excl (rwPFS window)
  cutoff <- if (excl != 0) sprintf("date_add(index_date, %d)", excl) else "index_date"
  pred <- progression_pred(pcfg[["evidence_columns"]], pcfg[["pseudoprogression_column"]],
                           pcfg[["yes_value"]] %||% "Yes", pcfg[["no_value"]] %||% "No")
  base <- dplyr::select(idx, patientid, index_date)
  ev <- base %>% dplyr::inner_join(prog_df, by = "patientid") %>%
    dplyr::filter(dplyr::sql(sprintf("%s > %s", date_col, cutoff))) %>%
    dplyr::filter(dplyr::sql(sprintf("(%s)", pred))) %>%
    dplyr::select(patientid, index_date, !!rlang::sym(date_col)) %>%
    dplyr::distinct() %>%                                  # collapse same-day duplicate evidence rows
    dplyr::group_by(patientid, index_date) %>%
    dbplyr::window_order(!!rlang::sym(date_col)) %>%
    dplyr::mutate(`_pr` = dplyr::row_number()) %>% dplyr::ungroup()
  out <- base
  for (rn in 1:2) {
    alias <- paste0("_prog", rn)
    d <- ev %>% dplyr::filter(`_pr` == rn) %>%
      dplyr::transmute(patientid, index_date, !!alias := !!rlang::sym(date_col))
    out <- dplyr::left_join(out, d, by = c("patientid", "index_date"))
  }
  out
}

# Substitute the study-window tokens in a pack-authored expr. == clinical.py::_study_tokens
# (parity: same token set, same default chains via the cfg_* accessors above).
study_tokens <- function(expr, cfg) {
  s <- cfg$raw[["study"]]
  reps <- list("{index_start}" = s[["index_start"]], "{index_end}" = s[["index_end"]],
               "{index_period_start}" = cfg_index_period_start(cfg),
               "{index_period_end}" = cfg_index_period_end(cfg),
               "{observation_end}" = cfg_observation_end(cfg),
               "{data_cutoff}" = cfg_data_cutoff(cfg))
  for (token in names(reps)) {
    if (grepl(token, expr, fixed = TRUE)) {
      if (is.null(reps[[token]]) || !nzchar(reps[[token]]))
        stop(sprintf("derived expr names %s but the study block does not state a value for it", token))
      expr <- gsub(token, sprintf("date('%s')", reps[[token]]), expr, fixed = TRUE)
    }
  }
  expr
}

# vis120 / lastvisitdate for a line cohort. == engine/stages/outcomes.py::_vis120.
outcomes_vis120 <- function(src, base_end, lo, win, end_col) {
  keys <- c("patientid", "index_date")
  vdate <- lo[["visit_date_column"]] %||% "visitdate"
  # entry shapes == outcomes.py::visit_source_pairs: a bare name (date = visit_date_column,
  # default visitdate) or list(source =, date_column =) for a feed whose date is named differently
  vs_raw <- lo[["visit_sources"]] %||% list()
  if (is.character(vs_raw) && length(vs_raw) == 1 && !is.list(vs_raw))
    stop(sprintf("line_outcomes.visit_sources must be a list, got the scalar '%s'", vs_raw))
  pairs <- lapply(vs_raw, function(entry) {
    if (is.list(entry)) {
      if (is.null(entry[["source"]]))
        stop("line_outcomes.visit_sources: a mapping entry must name `source`")
      list(s = entry[["source"]], d = entry[["date_column"]] %||% vdate)
    } else list(s = entry, d = vdate)
  })
  missing <- Filter(function(p) is.null(src[[p$s]]), pairs)
  if (length(missing) > 0)
    stop(sprintf("line_outcomes.visit_sources names source(s) not loaded: %s",
                 paste(vapply(missing, function(p) p$s, ""), collapse = ", ")))
  if (length(pairs) == 0)   # no feed configured: unknown, never "no encounter" (== outcomes.py)
    return(base_end %>% dplyr::select(dplyr::all_of(keys)) %>%
             dplyr::mutate(vis120 = dplyr::sql("CAST(NULL AS INT)"),
                           lastvisitdate = dplyr::sql("CAST(NULL AS DATE)")))
  enc <- NULL
  for (p in pairs) {                                   # union encounter dates across sources
    e <- src[[p$s]] %>% dplyr::transmute(patientid, `_vd` = !!rlang::sym(p$d))
    enc <- if (is.null(enc)) e else sparklyr::sdf_bind_rows(enc, e)
  }
  qualifying <- base_end %>% dplyr::left_join(enc, by = "patientid") %>%
    dplyr::filter(dplyr::sql(sprintf("`_vd` >= date_add(%s, %s)", end_col, win))) %>%
    dplyr::group_by(patientid, index_date) %>%
    dplyr::summarise(lastvisitdate = max(`_vd`, na.rm = TRUE), .groups = "drop")
  base_end %>% dplyr::select(dplyr::all_of(keys)) %>%
    dplyr::left_join(qualifying, by = keys) %>%
    dplyr::mutate(vis120 = dplyr::sql("CASE WHEN lastvisitdate IS NOT NULL THEN 1 ELSE 0 END"))
}

# --- assemble one cohort's ADS. engine/stages/assemble.py --------------------------------------
assemble_build <- function(idx, dem, clin, trt, out, cfg, cohort, treated) {
  keys <- c("patientid", "index_date")
  ts <- cfg$raw[["treatment_status"]]
  # Per-setting COHORTU/COHORTUN for a dual-setting product (treatment_status.by_setting keyed on the
  # cohort's lower-cased line_setting); else the flat treated/untreated labels, codes 1/2. == assemble.py.
  sts <- (ts[["by_setting"]] %||% list())[[tolower(cohort[["line_setting"]] %||% "")]] %||% ts
  tlabel <- sts[["treated_label"]]; ulabel <- sts[["untreated_label"]]
  tcode  <- sts[["treated_code"]] %||% 1L; ucode <- sts[["untreated_code"]] %||% 2L
  ads <- idx %>%
    dplyr::left_join(dem,  by = keys) %>%
    dplyr::left_join(clin, by = keys) %>%
    dplyr::left_join(trt,  by = keys) %>%
    dplyr::left_join(out,  by = keys) %>%
    dplyr::left_join(treated, by = "patientid") %>%
    dplyr::mutate(
      cohort   = cohort[["label"]],
      cohortn  = cohort[["cohortn"]],
      cohortu  = dplyr::sql(sprintf("CASE WHEN treat_flag IS NOT NULL THEN %s ELSE %s END",
                                    .sql_str(tlabel), .sql_str(ulabel))),
      cohortun = dplyr::sql(sprintf("CASE WHEN treat_flag IS NOT NULL THEN %d ELSE %d END",
                                    as.integer(tcode), as.integer(ucode))),
      data_product_id = cfg_data_product_id(cfg),   # product self-id (== assemble.py)
      spec_version = cfg_spec_version(cfg),   # CalVer contract only (202606), NOT the snapshot-filled
      data_refresh = cfg_refresh(cfg))        # version — matches assemble.py / refresh.py / dashboard.py
  # Cohort-indexed line category (lotN / lotNm / line 1 for overall). == engine/stages/assemble.py.
  ln <- cohort[["lot_number"]]
  suffix <- if (isTRUE(cohort[["maintenance"]])) "m" else ""
  cat_col  <- if (!is.null(ln)) paste0("lot", ln, suffix, "cat")  else "lot1cat"
  catn_col <- if (!is.null(ln)) paste0("lot", ln, suffix, "catn") else "lot1catn"
  if (cat_col %in% colnames(ads))
    ads <- ads %>% dplyr::mutate(lotcat  = !!rlang::sym(cat_col),
                                 lotcatn = !!rlang::sym(catn_col))
  ads <- dplyr::distinct(ads)
  # The declared publication whitelist == assemble.py::publication_projection: declared ->
  # EXACTLY that ordered projection, phantom/duplicate/missing-mandatory refuse; undeclared
  # -> unchanged. Mandatory: patientid, index_date + the three provenance stamps.
  pub <- (cfg$raw[["publication"]] %||% list())[["columns"]]
  if (!is.null(pub)) {
    cols <- tolower(trimws(as.character(unlist(pub))))
    if (any(duplicated(cols)) || any(!nzchar(cols)))
      stop("PUBLICATION WHITELIST REFUSED - duplicate or empty column name in publication.columns")
    missing_have <- setdiff(cols, tolower(colnames(ads)))
    if (length(missing_have) > 0)
      stop("PUBLICATION WHITELIST REFUSED - declared but not produced: ",
           paste(missing_have, collapse = ", "))
    mandatory <- c("patientid", "index_date", "data_product_id", "spec_version", "data_refresh")
    missing_mand <- setdiff(mandatory, cols)
    if (length(missing_mand) > 0)
      stop("PUBLICATION WHITELIST REFUSED - identity/provenance omitted: ",
           paste(missing_mand, collapse = ", "))
    ads <- ads %>% dplyr::select(dplyr::all_of(cols))
  }
  ads
}

# OC platinum-sensitivity. Per-(patient, linenumber) pfi/plat_sen/pcycled. == proc.py::_plat_sen_table.
proc_plat_sen_table <- function(lot_df, pcfg, dpm) {
  lnc <- pcfg[["line_number_column"]]; nmc <- pcfg[["name_column"]]
  sdc <- pcfg[["start_column"]]; edc <- pcfg[["end_column"]]
  window <- pcfg[["pfi_window_days"]] %||% 14
  thr    <- pcfg[["threshold_months"]] %||% 6
  lines <- lot_df %>% dplyr::transmute(
    patientid, linenumber = as.integer(!!rlang::sym(lnc)),
    `_sd` = !!rlang::sym(sdc), `_ed` = !!rlang::sym(edc),
    `_isplat` = dplyr::sql(platinum_pred(pcfg[["platinum_agents"]], nmc)))
  plat <- lines %>% dplyr::filter(`_isplat`) %>%
    dplyr::transmute(patientid, `_pln` = linenumber, `_ped` = `_ed`)
  prior <- lines %>% dplyr::inner_join(plat, by = "patientid") %>%
    dplyr::filter(dplyr::sql(sprintf("`_pln` < linenumber AND `_ped` < date_add(`_sd`, %s)", window))) %>%
    dplyr::group_by(patientid, linenumber) %>%
    dplyr::summarise(`_prior_end` = max(`_ped`, na.rm = TRUE), .groups = "drop")
  lines %>% dplyr::select(patientid, linenumber, `_sd`, `_isplat`) %>% dplyr::distinct(patientid, linenumber, .keep_all = TRUE) %>%
    dplyr::left_join(prior, by = c("patientid", "linenumber")) %>%
    dplyr::mutate(
      pfi = dplyr::sql(sprintf(
        "CASE WHEN `_prior_end` IS NULL THEN NULL ELSE datediff(`_sd`, `_prior_end`)/%s END", dpm)),
      plat_sen = dplyr::sql(sensitivity_case(thr)),
      pcycled  = dplyr::sql("CASE WHEN `_isplat` AND `_prior_end` IS NOT NULL THEN 1 ELSE 0 END")) %>%
    dplyr::select(patientid, linenumber, pfi, plat_sen, pcycled)
}

# plat_sen_v1/v2/pfi/pcycled for a line cohort (NULL when not applicable). == proc.py::build.
proc_build <- function(src, idx, cfg, cohort) {
  pcfg <- cfg_pack(cfg, "outcomes")[["platinum_sensitivity"]]
  if (is.null(pcfg) || is.null(src[[pcfg[["source"]]]])) return(NULL)
  ln <- cohort[["lot_number"]]
  if (is.null(ln) || ln < (pcfg[["from_line"]] %||% 2)) return(NULL)
  dpm <- cfg_pack(cfg, "outcomes")[["days_per_month"]]
  tbl <- proc_plat_sen_table(src[[pcfg[["source"]]]], pcfg, dpm)
  cur  <- tbl %>% dplyr::filter(linenumber == ln) %>%
    dplyr::transmute(patientid, plat_sen_v1 = plat_sen, pfi, pcycled)
  prev <- tbl %>% dplyr::filter(linenumber == ln - 1) %>%
    dplyr::transmute(patientid, plat_sen_v2 = plat_sen)
  idx %>% dplyr::select(patientid, index_date) %>%
    dplyr::left_join(cur, by = "patientid") %>% dplyr::left_join(prev, by = "patientid")
}

# --- ads_derived: cross-stage derivations over the ASSEMBLED cohort frame -----------------------
# == engine/stages/ads_derived.py::build. Runs after assemble+proc, when every stage's columns sit
# on one frame; an item whose `requires` columns are absent in this cut is skipped (same graceful
# contract as clinical `derived`). The compiled SQL comes from cases.R (interval_expr /
# landmark_case), parity-proven against the Python compilers.
ads_derived_dependency_errors <- function(items) {
  # Same configuration-order guard as Python, including generated columns.
  # A declared producer cannot be mistaken for an absent external source.
  produced <- list()
  errors <- character()
  for (i in seq_along(items)) {
    it <- items[[i]]
    if (!is.list(it)) stop("ads_derived items must be mappings")
    name <- it[["name"]]
    if (!is.character(name) || length(name) != 1L || !nzchar(trimws(name)))
      stop("ads_derived item needs a non-empty name")
    outputs <- name
    if (!is.null(it[["landmark"]])) outputs <- c(outputs, paste0(name, "n"))
    if (!is.null(it[["interval"]]) && length(it[["bands"]]) > 0L)
      outputs <- c(outputs, paste0(name, "gr"), paste0(name, "grn"))
    for (column in outputs) {
      key <- tolower(column)
      if (!is.null(produced[[key]])) {
        errors <- c(errors, paste0("ads_derived[", i - 1L, "] duplicates output column '", column, "'"))
      } else produced[[key]] <- i
    }
  }
  for (i in seq_along(items)) {
    requires <- unlist(items[[i]][["requires"]], use.names = FALSE)
    if (!is.character(requires) || length(requires) == 0L || anyNA(requires) || any(!nzchar(requires)))
      stop("ads_derived requires must name every input column")
    for (column in requires) {
      producer <- produced[[tolower(column)]]
      if (!is.null(producer) && producer >= i)
        errors <- c(errors, paste0("ads_derived[", i - 1L, "] requires '", column,
          "' before its producer ads_derived[", producer - 1L, "]; fix the dependency order or cycle before execution"))
    }
  }
  errors
}

ads_derived_build <- function(cohort_ads, cfg) {
  out_cfg <- cfg_pack(cfg, "outcomes")
  items <- out_cfg[["ads_derived"]]
  if (is.null(items) || length(items) == 0) return(cohort_ads)
  dependency_errors <- ads_derived_dependency_errors(items)
  if (length(dependency_errors) > 0L) stop(paste(dependency_errors, collapse = "; "))
  dpm <- as.numeric(out_cfg[["days_per_month"]] %||% 30.4375)
  study <- cfg$raw[["study"]]
  have <- tolower(colnames(cohort_ads))
  # Items run once in configuration order; later items can consume all generated columns.
  for (it in items) {
    if (!all(tolower(unlist(it[["requires"]])) %in% have)) next
    name <- it[["name"]]
    if (!is.null(it[["expr"]])) {
      expr <- study_tokens(it[["expr"]], cfg)
      cohort_ads <- dplyr::mutate(cohort_ads, !!name := dplyr::sql(expr))
    } else if (!is.null(it[["interval"]])) {
      iv <- it[["interval"]]
      cohort_ads <- dplyr::mutate(cohort_ads, !!name := dplyr::sql(
        interval_expr(iv[["from"]], iv[["to"]], iv[["unit"]] %||% "months", dpm)))
      if (!is.null(it[["bands"]])) {
        cohort_ads <- dplyr::mutate(
          cohort_ads,
          !!paste0(name, "gr") := dplyr::sql(num_bands_case(it[["bands"]], name, "label")),
          !!paste0(name, "grn") := dplyr::sql(num_bands_case(it[["bands"]], name, "code")))
      }
    } else {
      lm <- it[["landmark"]]
      cohort_ads <- dplyr::mutate(
        cohort_ads,
        !!name := dplyr::sql(landmark_case(lm[["anchor"]], lm[["horizon_days"]], lm[["events"]],
                                           lm[["censor"]][["date"]], lm[["labels"]], "label")),
        !!paste0(name, "n") := dplyr::sql(landmark_case(lm[["anchor"]], lm[["horizon_days"]],
                                           lm[["events"]], lm[["censor"]][["date"]],
                                           lm[["labels"]], "code")))
    }
    have <- tolower(colnames(cohort_ads))
  }
  cohort_ads
}
