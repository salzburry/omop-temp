# cohortly_manifest.R - load and execute a manifest written by cohortly_export.py.
#
# Two entry points:
#
#   specs  <- cohortly_specs_from_manifest("m.yaml", db = "...", data_refresh = "...")
#   result <- cohortly_cohort_from_manifest("m.yaml", db = "...", data_refresh = "...",
#                                           con = db_connect(), tbl_name = "...")
#
# The second runs the whole definition: study_specs with every bound code list,
# prepare_master_data, each criterion's trace call in workbook order, finalize_cohort.
# It returns list(cohort=, attrition=); the attrition is the run's evidence.
#
# Refusals, in order:
#   * manifest_version must be 1.
#   * modality must say claims.
#   * a draft refuses unless the caller passes allow_ungoverned = TRUE explicitly; a
#     manifest CLAIMING a governed approval refuses outright (no governed form exists yet).
#   * blocking_gaps refuse first - a manifest with gaps is a spec nobody finished.
#   * unknown top-level keys refuse.
#   * ZERO criteria refuse; exactly one index criterion is required.
#   * calls outside the whitelist refuse; per-call arguments are validated.
#   * db, data_refresh and tbl_name are caller arguments and must be non-blank.
#   * keys beginning with "_" are provenance for people; they are stripped, never passed.
#
# The manifest is read exactly once per entry point. The cohortly package version is not
# pinned; verify trace_*() signatures against the installed package.

`%||%` <- function(a, b) if (is.null(a)) b else a

.KNOWN_KEYS <- c("manifest_version", "modality", "workbook", "workbook_sha256", "rendered",
                 "governance", "loader", "cohortly_version", "study_specs", "criteria",
                 "code_lists", "events", "bindings_sha256", "unread_tabs", "blocking_gaps")
.CALL_WHITELIST <- c("trace_event_count", "trace_age", "trace_enrl", "trace_events")

.read_manifest <- function(path, allow_ungoverned = FALSE) {
  # THE SEAL FIRST. The manifest's first line digests its own body (the exporter writes it),
  # and this loader recomputes it before reading a single value: a hand-edited manifest - a
  # code list trimmed, a window widened, a duplicate key injected for last-wins parsing -
  # otherwise executed exactly as if the exporter had written it. Integrity, not authenticity:
  # it proves the file executed is the file rendered; who rendered it needs signing keys.
  lines <- readLines(path, encoding = "UTF-8", warn = FALSE)
  lines <- sub("\r$", "", lines)                # a CRLF checkout is not tampering
  if (!length(lines) || !grepl("^# content_sha256: [0-9a-f]{64}$", lines[[1]])) {
    stop("manifest '", path, "' carries no content_sha256 seal - an unsealed manifest ",
         "cannot show it is the one the exporter rendered; regenerate it, never hand-write it")
  }
  if (!requireNamespace("digest", quietly = TRUE)) {
    stop("package 'digest' is required to verify the manifest seal - refusing to execute ",
         "an unverified manifest rather than skipping the check")
  }
  body <- paste0(paste(enc2utf8(lines[-1]), collapse = "\n"), "\n")
  want <- sub("^# content_sha256: ", "", lines[[1]])
  got <- digest::digest(body, algo = "sha256", serialize = FALSE)
  if (!identical(got, want)) {
    stop("manifest '", path, "' failed its content_sha256 seal - the file changed after it ",
         "was rendered. Regenerate it from the workbook; a manifest is never edited.")
  }
  m <- yaml::read_yaml(path)
  if (!identical(as.integer(m[["manifest_version"]] %||% -1L), 1L)) {
    stop("manifest '", path, "' is not manifest_version 1 (got '",
         m[["manifest_version"]] %||% "absent", "') - refused, never guessed")
  }
  if (!startsWith(tolower(m[["modality"]] %||% ""), "claims")) {
    stop("manifest '", path, "' does not declare modality: claims - this executor must ",
         "never run an EHR pack's material")
  }
  # DEFAULT-DENY, not marker-scan (refusing only text that BEGINS with
  # 'UNGOVERNED' let a missing, whitespace-prefixed or reworded field pass). Nothing emits a
  # governed form today - it arrives with claims Gate 6 and will carry approval digests - so
  # until then EVERY manifest needs the explicit allow_ungoverned = TRUE, whatever its
  # governance field says or omits.
  gov <- trimws(m[["governance"]] %||% "")
  if (startsWith(toupper(gov), "GOVERNED")) {
    # the GOVERNED prefix was forgeable free text. No governed claims form EXISTS
    # yet - it arrives with claims Gate 6 and will be digest-bound to workbook, bindings and
    # a signed approval - so a manifest CLAIMING one today is forged, and refuses harder
    # than an honest draft.
    stop("manifest '", path, "' claims a governed approval, but no governed claims form ",
         "exists yet (claims Gate 6, digest-bound, is not built) - the claim is forged; ",
         "refused outright.")
  }
  if (!isTRUE(allow_ungoverned)) {
    stop("manifest '", path, "' is a draft (governance field: '", substr(gov, 1, 60),
         "') - execution refuses by default; pass allow_ungoverned = TRUE only for a ",
         "draft UAT you can defend, never in production.")
  }
  unknown <- setdiff(names(m), .KNOWN_KEYS)
  if (length(unknown) > 0) {
    stop("manifest '", path, "' carries key(s) this executor does not consume: ",
         paste(unknown, collapse = ", "), " - refusing rather than silently dropping content")
  }
  gaps <- unlist(m[["blocking_gaps"]] %||% list())
  if (length(gaps) > 0) {
    stop("manifest '", path, "' carries ", length(gaps),
         " blocking gap(s) - refusing to load half a cohort spec:\n  - ",
         paste(gaps, collapse = "\n  - "))
  }
  m
}

.specs_from <- function(m, db, data_refresh, ...) {
  if (!nzchar(db %||% "") || !nzchar(data_refresh %||% "")) {
    stop("db and data_refresh are run decisions the caller must state - blank is refused")
  }
  args <- m[["study_specs"]] %||% list()
  if (length(args) == 0) stop("the manifest carries no study_specs block")
  args <- args[!startsWith(names(args), "_")]   # provenance is for people, not for the call
  for (event in names(m[["events"]] %||% list())) {
    args[[event]] <- lapply(m[["events"]][[event]], function(binding) {
      codes <- as.character(unlist(binding[["codes"]]))
      if (length(codes) == 0) {                 # an empty list selects NOTHING, silently
        stop("event '", event, "' binds an EMPTY code list - the exporter never emits one, ",
             "so the file was edited by hand; regenerate it from the workbook")
      }
      codes
    })
    names(args[[event]]) <- names(m[["events"]][[event]])
  }
  args[["db"]] <- db
  args[["data_refresh"]] <- data_refresh
  do.call(cohortly::study_specs, c(args, list(...)))
}

cohortly_specs_from_manifest <- function(path, db, data_refresh, ...,
                                         allow_ungoverned = FALSE) {
  .specs_from(.read_manifest(path, allow_ungoverned), db, data_refresh, ...)
}

.criterion_args <- function(cr) {
  a <- cr[["call"]][["args"]] %||% list()
  row <- cr[["row"]]
  for (k in c("window", "op_gap_window")) {      # the manifest stores [from, to]; R wants from:to
    if (!is.null(a[[k]])) {
      w <- unlist(a[[k]])
      if (length(w) != 2 || any(is.na(suppressWarnings(as.integer(w)))) ||
          as.integer(w[[1]]) > as.integer(w[[2]])) {
        stop("criterion '", row, "': ", k, " is not an ordered integer [from, to]")
      }
      a[[k]] <- as.integer(w[[1]]):as.integer(w[[2]])
    }
  }
  # per-call argument validation (the top-level shape was held harder
  # than the arguments the calls actually run on) - closed vocabularies, positive counts
  if (!is.null(a[["purpose"]]) && !(a[["purpose"]] %in% c("index", "select"))) {
    stop("criterion '", row, "': purpose '", a[["purpose"]], "' is not index/select")
  }
  if (!is.null(a[["expectation"]]) && !(a[["expectation"]] %in% c("presence", "absence"))) {
    stop("criterion '", row, "': expectation '", a[["expectation"]],
         "' is not presence/absence")
  }
  for (k in c("ip_min_count", "op_min_count", "min_age")) {
    if (!is.null(a[[k]])) {
      v <- suppressWarnings(as.integer(a[[k]]))
      if (is.na(v) || v < 0) stop("criterion '", row, "': ", k, " is not a count (got '",
                                  a[[k]], "')")
      a[[k]] <- v
    }
  }
  a
}

cohortly_cohort_from_manifest <- function(path, db, data_refresh, con, tbl_name,
                                          generate_summary = FALSE,
                                          allow_ungoverned = FALSE) {
  m <- .read_manifest(path, allow_ungoverned)    # the ONE read; everything below uses m
  if (!nzchar(tbl_name %||% "")) {
    stop("tbl_name is a run decision the caller must state - blank is refused")
  }
  crits <- m[["criteria"]] %||% list()
  if (length(crits) == 0) {
    stop("manifest '", path, "' carries ZERO criteria - a cohort with no criteria is ",
         "everybody; the exporter blocks this upstream, so an empty list here means the ",
         "file was edited by hand. Regenerate it from the workbook.")
  }
  n_index <- sum(vapply(crits, function(cr)
    identical(cr[["call"]][["args"]][["purpose"]], "index"), logical(1)))
  if (n_index != 1) {
    stop("manifest '", path, "' has ", n_index, " criteria with purpose='index' - EXACTLY ",
         "ONE row anchors a cohort; regenerate it from the workbook")
  }
  specs <- .specs_from(m, db, data_refresh)
  df <- cohortly::prepare_master_data(con = con, study_specs = specs, tbl_name = tbl_name,
                                      generate_summary = generate_summary)
  for (cr in crits) {
    if (!is.null(cr[["gap"]]) && nzchar(cr[["gap"]])) {
      stop("criterion '", cr[["row"]], "' carries a gap in a manifest whose blocking_gaps ",
           "list is empty - the file was edited by hand; regenerate it from the workbook")
    }
    fn <- cr[["call"]][["fn"]] %||% ""
    if (!(fn %in% .CALL_WHITELIST)) {
      stop("criterion '", cr[["row"]], "' names call '", fn, "', not one of: ",
           paste(.CALL_WHITELIST, collapse = ", "), " - refused; this executor runs only ",
           "calls the exporter can emit")
    }
    a <- .criterion_args(cr)
    df <- do.call(getExportedValue("cohortly", fn), c(list(df), a))
    if (identical(a[["purpose"]], "index")) {
      df <- cohortly::index_patients(df)         # cohortly's own flow: index right after the
    }                                            # index-purpose count (verify per version)
  }
  final <- cohortly::finalize_cohort(df)
  list(cohort = cohortly::pull_cohort(final),
       attrition = cohortly::pull_attrition(final))   # the platform ingests this as evidence
}
