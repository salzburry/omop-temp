# R mirror of the pure CASE-expression compilers in engine/stages/{demographics,clinical,treatment}.py
# (the `_bands_case` / `_map_case` / `_region_case` / `_num_bands_case` / `_stage_case` /
# `_lot_bands_case` helpers). These turn reviewed config (age bands, region/race/ethnicity/practice
# crosswalks, BMI bands, stage groupings, line-count bands) into Spark SQL CASE strings.
#
# Pure (no IO, no Spark). Parity with the Python helpers is enforced byte-for-byte by
# tests/test_r_parity.py for BOTH the label CASE and the numeric-code CASE.

if (!exists("%||%")) `%||%` <- function(a, b) if (is.null(a)) b else a   # self-contained for parity

# Load order: source("vocabularies.R") then source("codelists.R") BEFORE this file. `.sql_str` — the
# Spark SQL string literal, mirroring engine/codelists.py::sql_str — lives THERE, and is called from
# here. run_rwdp.R has always sourced them in that order, and every parity harness now does too.
#
# It used to be defined twice, as `.q` here and `.sql_str` there, because one harness source()d each
# file alone. That made the constraint circular — the files were self-contained because the harness
# sourced them alone, and the harness sourced them alone because they were self-contained — while
# codelists.R already depended on vocabularies.R, so "every file stands alone" was not true anyway.
# Two definitions of one concept is the failure this repository keeps finding; a test comparing them
# is a mitigation, not a fix. One definition, in the file that owns the concept.

# out value for a band/row: quoted label, or the raw code as a string.
.out_val <- function(item, key)
  if (identical(key, "label")) .sql_str(item[[key]]) else as.character(item[[key]])

# first item whose `when` == w, else NULL.
.first_when <- function(items, w) {
  for (it in items) if (identical(it[["when"]], w)) return(it)
  NULL
}

# demographics: CASE over numeric bands with eq/ge/min/max/max_excl bounds + fallthrough (agegrl…).
bands_case <- function(bands, value_expr, key = "label") {
  whens <- character(0)
  for (b in bands) {
    out <- .out_val(b, key)
    if (identical(b[["when"]], "fallthrough")) next
    conds <- character(0)
    if (!is.null(b[["eq"]]))       conds <- c(conds, sprintf("%s = %s",  value_expr, as.character(b[["eq"]])))
    if (!is.null(b[["ge"]]))       conds <- c(conds, sprintf("%s >= %s", value_expr, as.character(b[["ge"]])))
    if (!is.null(b[["min"]]))      conds <- c(conds, sprintf("%s >= %s", value_expr, as.character(b[["min"]])))
    if (!is.null(b[["max"]]))      conds <- c(conds, sprintf("%s <= %s", value_expr, as.character(b[["max"]])))
    if (!is.null(b[["max_excl"]])) conds <- c(conds, sprintf("%s < %s",  value_expr, as.character(b[["max_excl"]])))
    if (length(conds) > 0)
      whens <- c(whens, sprintf("WHEN %s THEN %s", paste(conds, collapse = " AND "), out))
  }
  default <- .first_when(bands, "fallthrough")
  tail <- if (!is.null(default)) paste0(" ELSE ", .out_val(default, key)) else ""
  paste0("CASE ", paste(whens, collapse = " "), tail, " END")
}

# demographics: CASE over a source-value -> reported-value crosswalk (race/ethnicity/practice).
map_case <- function(rows, value_expr, key = "label") {
  whens <- character(0)
  for (r in rows) {
    out <- .out_val(r, key)
    if (!is.null(r[["from"]])) {
      vals <- paste(vapply(r[["from"]], function(v) .sql_str(tolower(as.character(v))), ""), collapse = ", ")
      cond <- sprintf("LOWER(%s) IN (%s)", value_expr, vals)
      # == demographics.py::_map_case - an entry may declare or_column (G-ETHNICITY-OR)
      if (!is.null(r[["or_column"]]))
        cond <- sprintf("%s OR LOWER(%s) IN (%s)", cond, r[["or_column"]], vals)
      whens <- c(whens, sprintf("WHEN %s THEN %s", cond, out))
    }
  }
  default <- .first_when(rows, "fallthrough")
  tail <- if (!is.null(default)) paste0(" ELSE ", .out_val(default, key)) else ""
  paste0("CASE ", paste(whens, collapse = " "), tail, " END")
}

# demographics: CASE over state -> region, with state_is_null -> Missing (leading) and fallthrough.
region_case <- function(rows, col, key = "label") {
  whens <- character(0); missing <- NULL; default <- NULL
  for (r in rows) {
    out <- .out_val(r, key)
    if (identical(r[["when"]], "state_is_null")) {
      missing <- out
    } else if (identical(r[["when"]], "fallthrough")) {
      default <- out
    } else if (!is.null(r[["states"]])) {
      vals <- paste(vapply(r[["states"]], function(s) .sql_str(s), ""), collapse = ", ")
      whens <- c(whens, sprintf("WHEN %s IN (%s) THEN %s", col, vals, out))
    }
  }
  pre  <- if (!is.null(missing)) sprintf("WHEN %s IS NULL THEN %s ", col, missing) else ""
  tail <- if (!is.null(default)) paste0(" ELSE ", default) else ""
  paste0("CASE ", pre, paste(whens, collapse = " "), tail, " END")
}

# clinical: CASE over numeric bands (min/max_excl/max) + fallthrough. Used for BMI groups.
num_bands_case <- function(bands, col, key = "label") {
  whens <- character(0)
  for (b in bands) {
    if (identical(b[["when"]], "fallthrough")) next
    out <- .out_val(b, key)
    conds <- character(0)
    if (!is.null(b[["min"]]))      conds <- c(conds, sprintf("%s >= %s", col, as.character(b[["min"]])))
    if (!is.null(b[["min_excl"]])) conds <- c(conds, sprintf("%s > %s",  col, as.character(b[["min_excl"]])))
    if (!is.null(b[["max_excl"]])) conds <- c(conds, sprintf("%s < %s",  col, as.character(b[["max_excl"]])))
    if (!is.null(b[["max"]]))      conds <- c(conds, sprintf("%s <= %s", col, as.character(b[["max"]])))
    if (length(conds) > 0)
      whens <- c(whens, sprintf("WHEN %s THEN %s", paste(conds, collapse = " AND "), out))
  }
  default <- .first_when(bands, "fallthrough")
  tail <- if (!is.null(default)) paste0(" ELSE ", .out_val(default, key)) else ""
  paste0("CASE ", paste(whens, collapse = " "), tail, " END")
}

# clinical: CASE mapping a raw value to its configured group. MUST emit byte-identical SQL to
# engine/stages/clinical.py::_stage_case — test_r_parity compares the two strings, so the WHEN order
# below is not a style choice. See that docstring for why the order is missing -> exact -> longest
# prefix -> contains -> regex -> fallthrough.
GROUP_MARKERS <- c("fallthrough", "missing")

stage_case <- function(groups, col, key = "label") {
  whens <- character(0)
  miss <- .first_when(groups, "missing")
  if (!is.null(miss))
    whens <- c(whens, sprintf("WHEN %s IS NULL THEN %s", col, .out_val(miss, key)))
  prefix_len <- numeric(0); prefix_pat <- character(0); prefix_out <- character(0)
  for (g in groups) {
    if (isTRUE(g[["when"]] %in% GROUP_MARKERS)) next
    # == clinical.py: REFUSE A SCALAR BEFORE IT BECOMES SQL. `sequence_error` was defined in
    # codelists.R and called only by `list_operator_error`, so the CODELIST path refused a scalar
    # and this STAGE path did not. Python refused; R compiled and published. A shared helper that
    # only one engine calls is not shared — it is a second engine's worth of drift with a
    # reassuring name, and the parity tests exercised the helper rather than this path.
    for (.f in SEQUENCE_FIELDS) {
      if (!is.null(g[[.f]])) {
        .why <- sequence_error(.f, g[[.f]])
        if (!is.null(.why)) stop(.why)
      }
    }
    out <- .out_val(g, key)
    conds <- character(0)
    if (length(g[["from_prefixes"]]) > 0)
      conds <- c(conds, sprintf("%s IN (%s)", col,
                 paste(vapply(g[["from_prefixes"]], function(v) .sql_str(v), ""), collapse = ", ")))
    if (length(g[["from_equals_ci"]]) > 0)
      conds <- c(conds, sprintf("LOWER(%s) IN (%s)", col,
                 paste(vapply(g[["from_equals_ci"]], function(v) .sql_str(tolower(as.character(v))), ""), collapse = ", ")))
    if (length(conds) > 0)
      whens <- c(whens, sprintf("WHEN (%s) THEN %s", paste(conds, collapse = " OR "), out))
    for (p in g[["from_startswith_ci"]]) {
      p <- as.character(p)
      prefix_len <- c(prefix_len, nchar(p)); prefix_pat <- c(prefix_pat, p); prefix_out <- c(prefix_out, out)
    }
  }
  if (length(prefix_pat) > 0) {
    # Longest prefix first, then the prefix itself — same total order as Python's
    # sorted(key=lambda t: (-len, prefix)), so the emitted SQL matches character for character.
    o <- order(-prefix_len, prefix_pat, method = "radix")
    for (i in o)
      whens <- c(whens, sprintf("WHEN LOWER(%s) LIKE %s THEN %s", col,
                                .sql_str(paste0(tolower(prefix_pat[i]), "%")), prefix_out[i]))
  }
  for (g in groups) {
    if (isTRUE(g[["when"]] %in% GROUP_MARKERS)) next
    out <- .out_val(g, key)
    for (c_ in g[["from_contains_ci"]])
      whens <- c(whens, sprintf("WHEN LOWER(%s) LIKE %s THEN %s", col,
                                .sql_str(paste0("%", tolower(as.character(c_)), "%")), out))
  }
  # REGEX LAST — most general, and the pattern is passed through untouched (no tolower: case-folding
  # a regex inverts \D \S \W \B). Mirrors the final loop of _stage_case.
  for (g in groups) {
    if (isTRUE(g[["when"]] %in% GROUP_MARKERS)) next
    out <- .out_val(g, key)
    for (r_ in g[["from_regex"]])
      whens <- c(whens, sprintf("WHEN %s REGEXP %s THEN %s", col, .sql_str(as.character(r_)), out))
  }
  default <- .first_when(groups, "fallthrough")
  tail <- if (!is.null(default)) paste0(" ELSE ", .out_val(default, key)) else ""
  paste0("CASE ", paste(whens, collapse = " "), tail, " END")
}

# treatment: CASE over lot_count_bands (eq/ge with a fallthrough). Builds lotngrl / lotngrln.
lot_bands_case <- function(bands, col, key = "label") {
  whens <- character(0); default <- NULL
  for (b in bands) {
    out <- .out_val(b, key)
    if (identical(b[["when"]], "fallthrough")) {
      default <- out
      next
    }
    conds <- character(0)
    if (!is.null(b[["eq"]])) conds <- c(conds, sprintf("%s = %s",  col, as.character(b[["eq"]])))
    if (!is.null(b[["ge"]])) conds <- c(conds, sprintf("%s >= %s", col, as.character(b[["ge"]])))
    if (length(conds) > 0)
      whens <- c(whens, sprintf("WHEN %s THEN %s", paste(conds, collapse = " AND "), out))
  }
  tail <- if (!is.null(default)) paste0(" ELSE ", default) else ""
  paste0("CASE ", paste(whens, collapse = " "), tail, " END")
}

# treatment: per-line column-name scheme (lot{i}* / lot{i}m*). Byte-identical to
# engine/stages/treatment.py::line_cols so the producer (treatment) and consumers (outcomes) cannot
# drift across engines; line_cols_canon joins the names for the parity fixture (test_r_parity.py).
line_cols <- function(i, maint = FALSE) {
  s <- if (isTRUE(maint)) "m" else ""
  list(name = paste0("lot", i, s), start = paste0("lot", i, s, "sd"),
       end = paste0("lot", i, s, "ld"), lastdate = paste0("lot", i, s, "ed"),
       dur = paste0("lot", i, s, "dur"),
       cat = paste0("lot", i, s, "cat"), catn = paste0("lot", i, s, "catn"))
}
line_cols_canon <- function(i, maint = FALSE) {
  lc <- line_cols(i, maint)
  paste(c(lc$name, lc$start, lc$end, lc$lastdate, lc$dur, lc$cat, lc$catn), collapse = "|")
}

# outcomes: per-line time-to-event CASE expressions (parameterised by the line number N). Byte-
# identical to engine/stages/outcomes.py (_trtdis_sql / _ttntfl_sql / _ttd_sql / _ttnt_sql) so the
# line outcomes are R<->Python parity-proven (tests/test_r_parity.py). dpm = days_per_month.
trtdis_sql <- function(n) {
  # NULL arm == outcomes.py: no visit feed -> vis120 NULL -> not-provably-discontinued is UNKNOWN
  sprintf("CASE WHEN lotn > %s OR (lotn = %s AND dthdt IS NOT NULL) OR vis120 = 1 THEN 1 WHEN vis120 IS NULL THEN NULL ELSE 0 END", n, n)
}
ttntfl_sql <- function(n, cross_col = NULL) {
  # == outcomes.py::_ttntfl_sql - under cross_setting scope a declared cross column's presence
  # is a next-treatment event too (G-TTNT-CROSS)
  cross <- if (!is.null(cross_col)) sprintf(" OR %s IS NOT NULL", cross_col) else ""
  sprintf("CASE WHEN lotn > %s OR dthfl = 1%s THEN 1 ELSE 0 END", n, cross)
}
ttd_sql <- function(n, dpm, maint = FALSE) {
  # +1: the spec's inclusive day (G-TTD-PLUS1), changed in lockstep with outcomes.py
  sprintf("(datediff(%s, index_date)+1)/%s", line_cols(n, maint)$lastdate, dpm)
}
ttnt_sql <- function(n, dpm, has_next, cross_col = NULL) {
  # == outcomes.py::_ttnt_sql - the declared cross column joins the least() beside the
  # same-setting next and death; least() skips nulls exactly as pmin(na.rm) does
  cands <- c(if (isTRUE(has_next)) sprintf("lot%ssd", n + 1), cross_col, "dthdt")
  nxt <- if (length(cands) > 1) sprintf("least(%s)", paste(cands, collapse = ", ")) else cands
  # THE +1 IS ON BOTH ARMS. The event arm was missing it while the censored arm below carried
  # it, so R computed a TTNT one day shorter than the governed PySpark engine for every event.
  # Caught by test_r_parity the first time CI ran after an eight-day outage; the censored arm
  # agreeing in both engines is what settles which side was wrong.
  sprintf(paste0("CASE WHEN ttntfl = 1 THEN (datediff(%s, index_date)+1)/%s ",
                 "WHEN ttntfl = 0 THEN (datediff(fued, index_date)+1)/%s ELSE 0 END"),
          nxt, dpm, dpm)
}
tsstfl_sql <- function(n) {
  sprintf("CASE WHEN lotn > %s OR dthfl = 1 THEN 1 ELSE 0 END", n + 1)
}
tsst_sql <- function(n, dpm, has_n2) {
  nxt <- if (isTRUE(has_n2)) sprintf("least(lot%ssd, dthdt)", n + 2) else "dthdt"
  # same missing `+1` on the event arm as ttnt_sql above, and the same reasoning
  sprintf(paste0("CASE WHEN tsstfl = 1 THEN (datediff(%s, index_date)+1)/%s ",
                 "WHEN tsstfl = 0 THEN (datediff(fued, index_date)+1)/%s ELSE 0 END"),
          nxt, dpm, dpm)
}

# treatment: SQL predicate matching a taxane line name (prior-taxane flags). Byte-identical to
# engine/stages/treatment.py::_taxane_pred (proven in tests/test_r_parity.py).
taxane_pred <- function(likes) {
  paste(vapply(likes, function(x) sprintf("lower(linename) LIKE '%s'", tolower(as.character(x))), ""),
        collapse = " OR ")
}

# outcomes: a progression EVENT predicate (any evidence flag == yes AND not pseudo-progression).
# Byte-identical to engine/stages/outcomes.py::_progression_pred (proven in tests/test_r_parity.py).
progression_pred <- function(evidence_cols, pseudo_col, yes = "Yes", no = "No") {
  ev <- paste(vapply(evidence_cols, function(c) sprintf("%s = '%s'", c, yes), ""), collapse = " OR ")
  sprintf("(%s) AND %s = '%s'", ev, pseudo_col, no)
}

# proc: SQL predicate matching a platinum agent in the line name. Byte-identical to
# engine/stages/proc.py::_platinum_pred (proven in tests/test_r_parity.py).
platinum_pred <- function(agents, name_col = "linename") {
  paste(vapply(agents, function(a) sprintf("lower(%s) LIKE '%s'", name_col, tolower(as.character(a))), ""),
        collapse = " OR ")
}

# proc: CASE mapping the platinum-free interval (months) to Sensitive/Resistant. Byte-identical to
# engine/stages/proc.py::_sensitivity_case (proven in tests/test_r_parity.py).
sensitivity_case <- function(threshold_months, pfi_col = "pfi") {
  sprintf("CASE WHEN %s IS NULL THEN NULL WHEN %s < %s THEN 'Resistant' ELSE 'Sensitive' END",
          pfi_col, pfi_col, threshold_months)
}

# clinical: a presence-flag CASE (column NULL -> absent label, else present label). Byte-identical to
# engine/stages/clinical.py::_presence_flag_sql (proven in tests/test_r_parity.py).
presence_flag_sql <- function(fl) {
  sprintf("CASE WHEN %s IS NULL THEN '%s' ELSE '%s' END", fl[["from"]], fl[["absent"]], fl[["present"]])
}

# clinical: OC surgery-classification CASEs (issurg/surg/surgn/neoadj). Byte-identical to
# engine/stages/clinical.py::_surgery_sql (proven in tests/test_r_parity.py).
surgery_sql <- function(scfg) {
  fl <- scfg[["surgery_flag_column"]]; dt <- scfg[["surgery_date_column"]]
  yes <- scfg[["yes_value"]] %||% "Yes"; no <- scfg[["no_value"]] %||% "No"
  pcs <- scfg[["pcs_label"]]; ics <- scfg[["ics_label"]]; none <- scfg[["none_label"]]
  typ <- sprintf(paste0("CASE WHEN %s IS NULL OR %s < _line1_start THEN '%s' ",
                        "WHEN %s >= _line1_start THEN '%s' ELSE '%s' END"), dt, dt, pcs, dt, ics, none)
  typn <- sprintf("CASE WHEN %s IS NULL OR %s < _line1_start THEN 1 WHEN %s >= _line1_start THEN 2 ELSE 3 END",
                  dt, dt, dt)
  list(
    issurg = sprintf(paste0("CASE WHEN %s = '%s' THEN 'Yes' WHEN %s = '%s' THEN '%s' ",
                            "WHEN %s != '%s' AND %s IS NULL THEN 'Unknown' ELSE 'Missing' END"),
                     fl, yes, fl, no, none, fl, yes, dt),
    surg = sprintf("CASE WHEN %s = '%s' THEN (%s) ELSE '%s' END", fl, yes, typ, none),
    surgn = sprintf("CASE WHEN %s = '%s' THEN (%s) ELSE 3 END", fl, yes, typn),
    neoadj = sprintf(paste0("CASE WHEN %s = '%s' AND %s >= _line1_start AND %s <= _line1_end ",
                            "THEN 'Yes' ELSE 'No' END"), fl, yes, dt, dt))
}

# ads_derived: datediff interval in raw days or months. Byte-identical to
# engine/stages/ads_derived.py::interval_expr (proven in tests/test_r_parity.py).
interval_expr <- function(frm, to, unit = "months", dpm = 30.4375) {
  days <- sprintf("datediff(%s, %s)", to, frm)
  if (identical(unit, "days")) days else sprintf("(%s)/%s", days, dpm)
}

# ads_derived: the FIRST qualifying event date — least() over each event's date, an event with a
# `when` predicate contributing only when it holds (Spark least() skips NULLs). Byte-identical to
# engine/stages/ads_derived.py::landmark_event_expr (proven in tests/test_r_parity.py).
landmark_event_expr <- function(events) {
  parts <- vapply(events, function(ev) {
    if (!is.null(ev[["when"]])) sprintf("CASE WHEN %s THEN %s END", ev[["when"]], ev[["date"]])
    else as.character(ev[["date"]])
  }, "")
  if (length(parts) == 1) parts[[1]] else paste0("least(", paste(parts, collapse = ", "), ")")
}

# ads_derived: the event-free-at-horizon landmark CASE (EFS24-style). WHEN order is load-bearing —
# see engine/stages/ads_derived.py::landmark_case, whose string this MUST match byte-for-byte
# (proven in tests/test_r_parity.py).
landmark_case <- function(anchor, horizon_days, events, censor_date, labels, key = "label") {
  out <- function(state) {
    v <- labels[[state]][[key]]
    if (identical(key, "label")) .sql_str(as.character(v)) else as.character(as.integer(v))
  }
  evt <- landmark_event_expr(events)
  edge <- sprintf("date_add(%s, %s)", anchor, as.integer(horizon_days))
  sprintf("CASE WHEN %s IS NULL THEN NULL WHEN (%s) IS NOT NULL AND (%s) <= %s THEN %s WHEN %s >= %s THEN %s ELSE %s END",
          anchor, evt, evt, edge, out("failed"), censor_date, edge, out("achieved"), out("not_evaluable"))
}
