# RWDP shared engine (`platform/`)

For Windows or Linux setup, use [local installation](../docs/LOCAL_INSTALLATION.md)
before these engineering commands. `python` below means that checkout's activated
Python 3.13 environment. Product creation uses the
[existing product setup command](TUMOR_TEMPLATE/NEW_TUMOUR.md).

The locked engine every ONCOLOGY tumour RWDP runs on (`tumor_class: solid | heme`; staging, ECOG,
lines of therapy, mortality and survival are its semantics). Code lives here; behaviour lives in
each tumour's config pack under `../products/`. Adding an oncology tumour is config only — no engine
change — for every requirement an existing shared capability covers. A non-oncology condition
(asthma, say) is NOT config only: it needs composable condition capabilities the engine does not
have, and validation refuses a `condition_class` other than oncology rather than let it pass as solid. A requirement that needs
new engine behaviour is an engine gap, recorded in that pack's `handoff/ENGINE_GAPS.md`.
Standing an oncology tumour up is ONE command — `python platform/tools/new_product.py <slug> ...`
previews every file it would write and `--apply` writes all of them or none, after every validator
passes on a staged copy (`TUMOR_TEMPLATE/NEW_TUMOUR.md` explains each file).

## Layout

```
platform/
  VERSION                 the engine SemVer a product pins (governance/VERSIONING.md)
  capabilities.yaml       what each coverage CLAIM resolves to: config key -> symbols -> columns -> tests
  CAPABILITIES.md         generated from it by tools/capability_registry.py (--check refuses a stale copy)
  engine/                 locked PySpark, shared by every tumor
    config.py             load a tumor's data_product.yaml + dotted overrides   (pure Python)
    codelists.py          compile a treatment codelist -> Spark SQL CASE         (pure Python)
    validate.py           config validator + Spark source preflight             (pure Python)
    build_ads.py          orchestrator: per cohort build -> assemble -> union
    stages/               sources · lot · index · demographics · clinical · treatment · outcomes · assemble
  engine-r/               side-by-side R (sparklyr/dbplyr) engine — compiles byte-identical codelist/derivation SQL to PySpark (CI r-parity); its stage dataflow EXECUTES in CI (r-stage-dataflow) with cross-engine stage conformance for the capabilities that claim it
  databricks/run_rwdp.py  generic notebook entry point (any tumor via config_path)
  tests/                  engine tests, run against the reference tumor (prostate) + the registry
  TUMOR_TEMPLATE/         copy-me skeleton for a new tumor
  requirements.txt
../databricks.yml         the Asset Bundle (repo root); jobs are GENERATED, one per product
../products/registry.yaml the list of tumors the framework knows about
```

Each tumor is a folder under `../products/oncology/` (`prostate/`, `oc/`, `endometrial/`, …)
containing only `config/`, `variables/`, `codelists/`. The engine resolves everything from the
config: source tables (`{source_schema}.<stem>_<refresh>`), cohorts, index rule, the 4 variable
packs, and the treatment codelist.

## Vendors & tumor classes

Tumors come from different vendors with different table layouts, handled by `engine/vendors.py`:
- **Flatiron** (solid: NSCLC, SCLC, mCRC, OC, EC, mCRPC) — `{schema}.{stem}_{refresh}`.
- **COTA** (heme: DLBCL, CLL, MDS) — different schema; `run.source_layout` overrides if needed.

Config declares `vendor:` and `tumor_class:` (solid | heme). `cfg.table()` resolves names per
vendor; the LOT filter is config-driven (`lot.line_setting`, e.g. mCRPC for prostate, omitted
elsewhere); and **sources are optional** — a tumor declares only the tables it has, so heme/COTA
products without `provenge`/`alphabet`/`vitals` validate and run.

## The framework contract

Every tumor config must provide (the validator enforces it):
- `run.{refresh, source_schema, output_schema, output_table}`, `study.{index_start, index_end}`,
  a known `vendor` (or `run.source_layout`), and a `tumor_class` of solid|heme
- `sources:` for at least the REQUIRED core (`enhanced`, `lot`, `demographics`, `mortality`);
  other sources are optional and checked only if declared (see `validate.REQUIRED_SOURCES`).
  Absent optional sources are genuinely handled: follow-up uses only present sources (and accepts a
  full `follow_up_sources` override), and `baseline_ecog` degrades to the configured Missing value.
  Don't map an absent source to an unrelated table — OMIT it.
- the index date can be sourced from any declared table via
  `index_dates.advanced_diagnosis_date.source` (default `enhanced`; heme indexes off `diagnosis`).
  The treated/untreated flag is derived from the SAME normalized LOT model the index/treatment
  stages use (line setting + `lot.exclude_settings` + `lot.line_number`), minus the cohort-specific
  maintenance filter — so a line a cohort excludes never labels a patient "Treated".
- 4 variable packs by ROLE — `variables/{demographics,clinical,treatment,outcomes}.yaml`
  (pack_id is a free label) — with the keys the engine reads (age bands incl. a `when: fallthrough`,
  ECOG window, BMI bands, death-date imputation incl. a valid `conflict_resolution`, etc.)
- a `treatment_categories` codelist ending in an `always: true` catch-all

## Add a tumor — the CONFIGURATION half, and it is not where you start

> **Read `TUMOR_TEMPLATE/NEW_TUMOUR.md` first. It owns the sequence; this section owns one step
> of it.** A new pack begins at Gate 1 (register the approved specification) and Gate 2 (extract
> it, draft the contract, settle the decisions). Configuration is authored AFTER the contract
> exists, because the contract is what the YAML has to express. `MATURITY.yaml` saying
> `configuration: not_started` beside a `coverage_complete` contract is the honest state of a
> pack that has done Gates 1–2 and not this step yet.

Once Gate 2's contract is drafted:

1. Continue with the pack created by [the product setup command](TUMOR_TEMPLATE/NEW_TUMOUR.md).
   It owns template generation and registry updates. Use its next-cut workflow for a revision;
   do not copy a template or another product into the registry manually.
2. **See what you may name first:** `python platform/tools/blocks.py` prints every named thing a
   config can select — codelist match operators, BMI/BSA methods, follow-up sources and row filters,
   death-conflict policies — with the config key that takes each. It is DERIVED from the engine's own
   registries, so it cannot go stale, and `validate.py` refuses an unknown value listing the same
   names. Choosing between them is still judgment the specification has to settle.
3. Fill in `<YYYYMM>/config/data_product.yaml` (source stems, index rule, cohorts, output table), then
   go through `variables/*.yaml` and `codelists/treatment_categories.yaml` **against the contract,
   value by value**.

   The seeded values in `variables/` are EXAMPLES that happen to lint, not defaults you may keep. Age
   bands, the ECOG window, BMI/BSA method, stage groupings, the death-date conflict policy,
   `max_lines`, the follow-up and visit-recency day counts, the output coding — every one of those is
   a product requirement that some specification settled, and this file cannot know which. They recur
   across tumours; recurrence is not universality. The check that bites is `contract_binding.py`,
   which requires every governed config block to be claimed by a contract record. `--enumerations`
   then compares the value lists and `--parameters` the window, the record-selection direction and
   the source table, so a day count that drifts from the record it implements is caught. What stays
   yours is everything neither can read: the derivations, the cohort restrictions, and any window a
   record states as prose rather than as an offset pair or a duration — `--parameters` counts those
   rather than passing over them, so you can see how much is left.
4. Review the product registration generated by that same setup command. Its current version
   identifies the pack to resolve; registration and an active lineage do not establish release readiness.
5. Lint:  `python platform/engine/validate.py products/oncology/<slug>/<YYYYMM>/config/data_product.yaml`
6. Bind it to the contract:
   `python platform/tools/contract_binding.py <pack> --enumerations --parameters --check` (the
   flags CI uses). A lint that passes says the YAML is well-formed; this says it matches the
   requirements.
7. Regenerate the bundle: `python platform/tools/bundle_products.py` (the new product gets its own
   PAUSED job), then deploy the tree and run it — the ONE documented sequence is
   `../databricks.yml`'s header and is not restated here. In short: the per-cut values
   (`<slug>_refresh`, schemas, evidence digests) are bundle **variables bound at `deploy`**;
   `databricks bundle run rwdp_build_<slug> -t <target>` then takes none. (Earlier text put the
   `--var` flags on `run`, which cannot supply them — audit 5.)

Gates 3–6 — source evidence, the Gate 4 approval, validation and release — are in
`TUMOR_TEMPLATE/NEW_TUMOUR.md` §"Gates 3–6" and `../products/OPERATIONS.md`.

> **Or run it on the R engine (side-by-side validation).** The same config also drives the R engine
> (`engine-r/`) — same YAML in, the stages it implements out; full ADS interchangeability is NOT proven
> (`engine-r/README.md`) — for the R-proficient team. It's a *validation* path, not
> the governed lifecycle: it writes directly, so target a **separate `_r` schema** and then
> golden-compare against the Python ADS. From a Spark-connected R session (Databricks, or
> Domino→Databricks via sparklyr):
> ```bash
> Rscript platform/engine-r/run_rwdp.R --allow_direct_write=true \
>   --config_path=products/oncology/<slug>/<YYYYMM>/config/data_product.yaml \
>   --refresh=<cut> --source_schema=... --output_schema=..._r
> ```
> `--allow_direct_write=true` is required (fail-closed). Full Domino→Databricks options: `engine-r/README.md`.

## Run the tests (no Spark / cluster needed)

```bash
pip install -r platform/requirements.txt     # PyYAML (required even for the pure-Python tests)
python platform/tests/test_config.py         # engine vs the reference tumor (prostate)
python platform/tests/test_validate.py       # validator + source preflight
python platform/tests/test_registry.py       # every configured tumor's config lints clean
python platform/tests/test_vendors.py        # vendor resolution + vendor-aware config
python platform/tests/test_catalog.py        # master catalog <-> registry <-> dashboard
python platform/tests/test_r_parity.py        # Python≡R compiler parity (skips if Rscript absent)
python platform/tests/test_qc_golden.py       # QC + golden-comparison cores
# Spark-only (skip without PySpark; run on a cluster):
python platform/tests/test_stages_spark.py   # per-stage Spark tests
python platform/tests/test_smoke_spark.py    # builds the ADS for EVERY tumor on synthetic data
```
