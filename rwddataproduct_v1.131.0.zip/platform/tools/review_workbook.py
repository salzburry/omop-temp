#!/usr/bin/env python3
"""The reviewer's one Excel artifact — built from the extraction, read back by stable item id.

    python3 platform/tools/review_workbook.py build <pack> --out ~/reviews/prostate_review.xlsx
    python3 platform/tools/review_workbook.py read ~/reviews/prostate_review_filled.xlsx <pack>

WHY THIS EXISTS. The human reviewer's native artifact is Excel, and today their choices scatter
across YAML forms a specialist locates for them. This tool builds ONE workbook: a tab per
domain carrying every extracted requirement row (with its Excel coordinates, content hash and
lint severity), a findings tab, a read-only snapshot of the open decisions, and a provenance
tab that pins the whole file to the extraction it was built from. The reviewer fills exactly
four columns — reviewer_decision, reviewer_comment, reviewed_by, reviewed_date — and `read`
verifies the round trip and prints their decisions as structured output.

WHAT `read` REFUSES, because a round trip is only as good as its binding: a workbook whose
provenance fingerprint no longer matches the pack's current extraction (the spec moved under
the review), duplicated or unknown item_ids (rows added or reshuffled), and a decision with no
reviewer name or date (an unowned choice is not a review).

WHAT THIS TOOL NEVER DOES: write into the repository. `read` PRINTS the reviewer's decisions;
carrying them into the governed files (dispositions, decision answers, contract records) stays
a person's act through the tools that own those files — this is transport, not approval.
"""
import argparse
import json
import os
import sys

TOOLS = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, TOOLS)

import pack_run                                                             # noqa: E402
import spec_lint as sl                                                      # noqa: E402
from spec_extract import repo_relative                                      # noqa: E402

REVIEW_COLS = ("reviewer_decision", "reviewer_comment", "reviewed_by", "reviewed_date")
# VERBATIM, not truncated: a reviewer approving a rule they saw a prefix of approved a prefix
# `raw_text` carries the extraction's own joined row so nothing
# the field map missed is invisible to the person.
MACHINE_COLS = ("item_id", "tab", "row", "variable", "time_period", "label", "values",
                "definition", "notes", "raw_text", "lint_severity", "lint_kinds",
                "content_hash")
DECISION_WORDS = ("ACCEPT", "REVISE", "QUESTION")


def _extraction(pack):
    path = os.path.join(pack, "spec_pipeline", "out", "extracted.json")
    if not os.path.exists(path):
        sys.exit(f"no extraction at {repo_relative(path)} — run the spec pipeline first; a "
                 f"review workbook not built from the extraction would be a second spec")
    with open(path, encoding="utf-8") as fh:
        return json.load(fh)


def build(pack, out_path):
    """The review workbook, from the pack's own generated artifacts. Deterministic content;
    openpyxl required."""
    from openpyxl import Workbook
    from openpyxl.styles import Font

    data = _extraction(pack)
    findings = sl.scan(data) + sl.scan_across(data) + sl.scan_structure(data)
    by_item = {}
    for f in findings:
        by_item.setdefault(f.get("item_id"), []).append(f)

    wb = Workbook()
    bold = Font(bold=True)

    prov = wb.active
    prov.title = "Provenance"
    prov_rows = (
        ("pack", repo_relative(pack)),
        ("extraction_fingerprint", str((data.get("extraction") or {}).get("fingerprint") or "")),
        ("rows", len(data.get("rows") or [])),
        ("findings", len(findings)),
        ("rule", "Fill ONLY the reviewer_* columns. Do not edit machine columns — `read` "
                 "verifies item_ids and this fingerprint, and refuses a drifted file."),
        ("decisions", "reviewer_decision is one of: " + " / ".join(DECISION_WORDS) +
                      ". A decision without reviewed_by AND reviewed_date does not count."),
        ("boundary", "This file transports a review; it approves nothing. The governed files "
                     "are updated by a person through the tools that own them."),
    )
    for r in prov_rows:
        prov.append(list(r))
    for c in prov["A1":f"A{len(prov_rows)}"]:
        c[0].font = bold

    domains = {}
    for row in data.get("rows") or []:
        domains.setdefault(row.get("domain") or "unclassified", []).append(row)
    for domain, rows in sorted(domains.items()):
        ws = wb.create_sheet(domain[:28])
        ws.append(list(MACHINE_COLS) + list(REVIEW_COLS))
        for c in ws[1]:
            c.font = bold
        for r in rows:
            f = r.get("fields") or {}
            mine = by_item.get(r.get("item_id")) or []
            sev = ("HIGH" if any((x.get("severity") or sl.SEVERITY.get(x.get("kind"), "INFO"))
                                 == "HIGH" for x in mine) else ("INFO" if mine else ""))
            ws.append([r.get("item_id"), r.get("tab"), r.get("row"), r.get("variable"),
                       str(f.get("time_period") or ""), str(f.get("label") or ""),
                       str(f.get("values") or ""), str(f.get("definition") or ""),
                       str(f.get("notes") or ""), str(r.get("text") or ""), sev,
                       "; ".join(sorted({x.get("kind") or "" for x in mine})),
                       r.get("content_hash"), "", "", "", ""])

    ws = wb.create_sheet("Findings")
    ws.append(["item_id", "kind", "severity", "variable", "detail"])
    for c in ws[1]:
        c.font = bold
    for f in findings:
        ws.append([f.get("item_id"), f.get("kind"),
                   f.get("severity") or sl.SEVERITY.get(f.get("kind"), "INFO"),
                   f.get("variable"), str(f.get("detail") or "")])

    # the OPEN DECISIONS snapshot the docstring promises — read-only context so a reviewer sees
    # which questions already have owners before dispositioning a row that hangs on one
    reg = os.path.join(pack, "handoff", "DECISIONS.md")
    ws = wb.create_sheet("Decisions")
    ws.append(["decision_id", "status", "question", "owner"])
    for c in ws[1]:
        c.font = bold
    if os.path.exists(reg):
        import contract_lint as cl                                          # noqa: PLC0415
        text = cl.read(reg)
        status = cl.decision_status(text)
        for did, row in sorted(cl.decision_rows(text).items()):
            ws.append([did, status.get(did, "OPEN"), cl.decision_question(row),
                       cl.cell(row, *cl.OWNER_COLUMNS)])
    else:
        ws.append(["(no register)", "", "this pack has no decisions register yet", ""])

    wb.save(out_path)
    return {"rows": len(data.get("rows") or []), "domains": sorted(domains),
            "findings": len(findings)}


def read(filled_path, pack):
    """The round trip: verify the binding, then return the reviewer's decisions. Problems are
    returned beside the decisions — a partially valid review is reported, never silently
    truncated to its valid half."""
    from openpyxl import load_workbook

    import hashlib                                                          # noqa: PLC0415
    import product_gates as pgt                                             # noqa: PLC0415
    data = _extraction(pack)
    want_fp = str((data.get("extraction") or {}).get("fingerprint") or "")
    known = {r.get("item_id"): r for r in data.get("rows") or []}
    with open(filled_path, "rb") as fh:
        filled_sha = hashlib.sha256(fh.read()).hexdigest()
    wb = load_workbook(filled_path, data_only=True)
    if "Provenance" not in wb.sheetnames:
        sys.exit("ROUND TRIP REFUSED — no Provenance tab; this is not a review workbook this "
                 "tool built")
    prov = {str(r[0].value): str(r[1].value) for r in wb["Provenance"].iter_rows(max_col=2)
            if r[0].value}
    if prov.get("extraction_fingerprint") != want_fp:
        sys.exit(f"ROUND TRIP REFUSED — the workbook was built from extraction "
                 f"{prov.get('extraction_fingerprint')!r} but the pack's current extraction is "
                 f"{want_fp!r}. The specification moved under the review; rebuild the workbook "
                 f"and re-review what changed.")
    decisions, problems, seen = [], [], set()
    for name in wb.sheetnames:
        if name in ("Provenance", "Findings"):
            continue
        ws = wb[name]
        hdr = [str(c.value or "") for c in ws[1]]
        if not hdr or hdr[0] != "item_id":
            continue
        idx = {h: i for i, h in enumerate(hdr)}
        for row in ws.iter_rows(min_row=2):
            vals = [c.value for c in row]
            item = str(vals[idx["item_id"]] or "").strip()
            if not item:
                continue
            if item in seen:
                problems.append(f"{item}: appears twice — duplicated ids cannot round-trip")
                continue
            seen.add(item)
            if item not in known:
                problems.append(f"{item}: not in the pack's extraction — a row was added or "
                                f"an id edited; this review cannot bind to it")
                continue
            # MACHINE CELLS VERIFIED, not trusted: an edited content_hash or variable cell
            # would mean the reviewer's decision binds to text that is not the extraction's
            src = known[item]
            for col, want in (("content_hash", str(src.get("content_hash") or "")),
                              ("variable", str(src.get("variable") or ""))):
                have = str(vals[idx[col]] or "")
                if have != want:
                    problems.append(f"{item}: machine cell `{col}` was edited "
                                    f"({have!r} != {want!r}) — the decision cannot bind")
                    break
            else:
                decision = str(vals[idx["reviewer_decision"]] or "").strip().upper()
                if not decision:
                    continue
                entry = {"item_id": item, "decision": decision,
                         "comment": str(vals[idx["reviewer_comment"]] or "").strip(),
                         "reviewed_by": str(vals[idx["reviewed_by"]] or "").strip(),
                         "reviewed_date": str(vals[idx["reviewed_date"]] or "").strip()}
                if decision not in DECISION_WORDS:
                    problems.append(f"{item}: decision {decision!r} is not one of "
                                    f"{'/'.join(DECISION_WORDS)}")
                    continue
                why = (pgt.not_a_person(entry["reviewed_by"])
                       if entry["reviewed_by"] else "is not set")
                why = why or (pgt.bad_date(entry["reviewed_date"])
                              if entry["reviewed_date"] else "is not set")
                if why:
                    problems.append(f"{item}: {decision} but the reviewer identity/date: "
                                    f"{why} — an unowned choice is not a review")
                    continue
                decisions.append(entry)
    absent = sorted(set(known) - seen)
    if absent:
        problems.append(f"{len(absent)} extracted item(s) missing from the workbook (a domain "
                        f"sheet deleted or rows removed) — e.g. {absent[:5]}; a review that "
                        f"cannot see every item is a review of a subset wearing the whole "
                        f"file's fingerprint")
    return {"pack": repo_relative(pack), "extraction_fingerprint": want_fp,
            "filled_sha256": filled_sha,
            "counts": {"items_total": len(known), "items_in_workbook": len(seen),
                       "decided": len(decisions)},
            "decisions": decisions, "problems": problems,
            "note": "transport only — a person applies these through the governed tools"}


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    sub = ap.add_subparsers(dest="cmd", required=True)
    b = sub.add_parser("build", help="build the review workbook from the pack's extraction")
    b.add_argument("pack")
    b.add_argument("--out", required=True, help="xlsx path — refused inside the checkout")
    r = sub.add_parser("read", help="verify a filled workbook and print its decisions")
    r.add_argument("filled")
    r.add_argument("pack")
    a = ap.parse_args(argv)
    if a.cmd == "build":
        out_dir = pack_run.restricted_dir(os.path.dirname(os.path.abspath(
            os.path.expanduser(a.out))), what="the review workbook")
        os.makedirs(out_dir, exist_ok=True)
        out = os.path.join(out_dir, os.path.basename(a.out))
        info = build(a.pack, out)
        print(f"OK — {info['rows']} row(s) across {len(info['domains'])} domain tab(s), "
              f"{info['findings']} finding(s); wrote {out}")
        return 0
    print(json.dumps(read(a.filled, a.pack), indent=2, sort_keys=True))
    return 0


if __name__ == "__main__":
    from console import use_utf8
    use_utf8()
    sys.exit(main())
