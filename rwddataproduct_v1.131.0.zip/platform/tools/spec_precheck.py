#!/usr/bin/env python3
"""The author's pre-submission check: run the lint on a DRAFT workbook, before anyone hands off.

    python3 platform/tools/spec_precheck.py ~/drafts/nsclc_program_spec.xlsx

WHY THIS EXISTS. The most expensive part of standing up a tumour is not the engine — it is the
archaeology after handoff: the impossible date, the truncated rule, the variable defined twice
with two censoring rules, the enumeration living in a dropdown. Every one of those is cheaper
to fix while the AUTHOR still has the workbook open. This tool runs the same deterministic
extraction and lint the governed pipeline runs, against a draft file, and prints the findings
in author-facing language — what was found, where, and what to do about it.

WHAT THIS IS NOT, stated because the distinction is the whole governance model: this is a
COURTESY CHECK, not a governed act. It registers nothing, records no digest, writes no file,
approves nothing, and its output is not evidence — the governed path starts when a person
registers the workbook in source_refs.yaml and the pipeline runs from that registration.
A clean precheck means the machine found nothing; it does not mean the science is right.

Exit 1 when HIGH-severity findings or structural hazards exist — a pre-submission check that
"passes with notes" is one nobody reads.
"""
import argparse
import sys

import os
TOOLS = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, TOOLS)

import spec_extract as se                                                   # noqa: E402
import spec_lint as sl                                                      # noqa: E402

# What each structural hazard means TO AN AUTHOR — the lint's vocabulary translated from
# reviewer language to fix-it language.
_STRUCTURAL = (
    ("merged", "merged cells — a merge blanks every cell under its anchor; rows inside it are "
               "LOST to extraction. Unmerge and repeat the values."),
    ("hidden_rows", "hidden row(s) — a hidden row still carries a rule somebody may implement. "
                    "Delete retired rows or move them to a change-log tab."),
    ("shadowing_cols", "a hidden column shadows a real one (e.g. 'Definition (superseded)') — "
                       "delete it; extraction cannot know which twin is authoritative."),
    ("formula_no_value", "formula(s) with no cached value — the cell looks empty to every "
                         "reader of the saved file. Paste the value, or open and re-save."),
    ("validation_lists", "dropdown validation list(s) — the enumeration lives in the dropdown, "
                         "not in any cell. Write the values into the Values column."),
    ("comments", "cell comment(s) — a caveat in a comment changes the rule invisibly. Move the "
                 "text into the Definition or Additional Notes column."),
    ("sheet_state", "hidden sheet(s) — a whole requirement tab nobody handing off can see. "
                    "Unhide it, or remove it."),
    ("header_candidates", "a header-shaped row MID-SHEET — a second table's rows map against "
                          "the FIRST table's columns. Split the tables into separate tabs, or "
                          "align their headers exactly."),
)


def precheck(path):
    """(structural findings, lint findings by severity) — the same detectors the governed
    pipeline runs, over a draft. Read-only: the workbook is never modified."""
    data = se.extract(path, domains=se.shared_domains())
    findings = sl.scan(data) + sl.scan_across(data) + sl.scan_structure(data)
    st = se.workbook_structure(path)
    structural = []
    for sheet, keys in sorted((st or {}).items()):
        for key, advice in _STRUCTURAL:
            if (keys or {}).get(key):
                structural.append((sheet, key, (keys or {}).get(key), advice))
    by_sev = {"HIGH": [], "other": []}
    for f in findings:
        if f.get("kind") == "WORKBOOK_STRUCTURE":
            continue                # the STRUCTURE section above owns these; listing them twice
                                    # inflates the count and buries the content findings
        sev = f.get("severity") or sl.SEVERITY.get(f.get("kind"), "INFO")
        by_sev["HIGH" if sev == "HIGH" else "other"].append(f)
    return structural, by_sev, len(data.get("rows") or [])


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    ap.add_argument("workbook", help="the DRAFT .xlsx — read, never modified, never registered")
    a = ap.parse_args(argv)
    structural, by_sev, n_rows = precheck(a.workbook)

    print("=" * 92)
    print(f"  PRE-SUBMISSION CHECK — {os.path.basename(a.workbook)}  ({n_rows} requirement "
          f"row(s) extracted)")
    print("=" * 92)
    if structural:
        print("\n  STRUCTURE — fix these first; each one loses or hides content:")
        for sheet, key, val, advice in structural:
            print(f"    [{sheet}] {advice}")
            print(f"        found: {val}")
    if by_sev["HIGH"]:
        print(f"\n  BLOCKING FINDINGS ({len(by_sev['HIGH'])}) — each reads as finished and is "
              f"not:")
        for f in by_sev["HIGH"]:
            where = f.get("variable") or f.get("domain") or "?"
            print(f"    {f.get('kind'):<20} {where:<18} {str(f.get('detail') or '')[:110]}")
    if by_sev["other"]:
        print(f"\n  NOTES ({len(by_sev['other'])}) — worth a look, not blocking:")
        for f in by_sev["other"][:20]:
            where = f.get("variable") or f.get("domain") or "?"
            print(f"    {f.get('kind'):<20} {where:<18} {str(f.get('detail') or '')[:110]}")
        if len(by_sev["other"]) > 20:
            print(f"    ... and {len(by_sev['other']) - 20} more")
    blocking = bool(structural or by_sev["HIGH"])
    print("\n  " + ("NOT READY — fix the items above while the workbook is still yours; every "
                    "one is cheaper now than as a handoff question." if blocking else
                    "NOTHING FOUND by the machine checks. This is a courtesy check, not an "
                    "approval: the governed path starts at registration, and the science is "
                    "still the author's."))
    print("=" * 92)
    return 1 if blocking else 0


if __name__ == "__main__":
    from console import use_utf8
    use_utf8()
    sys.exit(main())
