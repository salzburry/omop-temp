#!/usr/bin/env python3
"""Deterministic defect scan over an extracted RWB program specification.

Most specification defects are pattern-matchable, and a script finds them better than a careful reader
does: it checks all rows every time, identically. This scans the output of spec_extract.py and reports
what a human then has to judge.

It reports; it never edits, and it never decides. A finding here becomes a SPEC_QC_FINDINGS entry (a
defect in RWB's document) or a DECISIONS entry (a question only RWB can answer) — that classification
is a human call.

Checks, and the real prostate/ovarian defects each was written for:

  IMPOSSIBLE_DATE    "4/31/2026" — April has 30 days (prostate MAXINDEX, SQ-01)
  PLACEHOLDER        "[Overall mHSPC cohort]" where a formula belongs (SQ-05)
  TRUNCATED          "(cut off at right edge of photo)" / "(fragment...)" (SQ-T1..T3)
  FOREIGN_TABLE      a table stem belonging to another tumour (SQ-03, t_enh_metcrc_oral in prostate)
  UNBALANCED         unmatched quote or bracket in a rule string (SQ-06 note)
  NO_TERMINAL_ELSE   an if/else-if chain with no final else — undefined for unmatched input
  VALUE_COUNT        more values declared than the rule ever assigns (SQ-06, 4 declared / 2 assigned)
  VERIFY_MARKER      an explicit "[verify]" / "confirm" the spec author left behind
  EMPTY_RULE         a named requirement whose definition cell is blank and which declares no value
                     set — the emptiness class: a hollow spec produces FEWER findings than a full
                     one, so blankness has to be a finding or it reads as cleanliness
  DEFERRED_RULE      a definition that is only a placeholder (TBD, ???) or a pointer at another
                     document ("same as prior study") — a rule this specification does not carry
  RULE_BY_REFERENCE  the resolvable version: a pointer at a variable this spec DOES define ("See
                     LOT1CAT_MHSPC description") — INFO, because the reference lands, and a row
                     that carries no rule of its own is still worth a line
  OUTLIER_IN_LIST    a token whose SHAPE breaks its neighbours' pattern — e.g. the word
                     "Implementation" sitting inside a list of two-letter state codes, which is what an
                     unanchored find/replace of the owner code "DE" produced in a real workbook. The
                     value stays plausible-looking prose, so review misses it; the shape does not.
  SKIPPED_LINE       a `|` line in a registered tab the extractor could not read as a row, header or
                     separator — a mistyped or missing row number makes a requirement silently absent
                     from every downstream artifact while the extraction stays green
  CELL_COUNT         a row whose cell count disagrees with its header's — a lost trailing cell or a
                     raw `|` splitting one cell into two, either of which misreads every field after it
  ROW_GAP            row numbers jump (6 -> 10) — hidden or blank rows in the workbook read exactly
                     like rows lost from the transcription, and only a person can say which this is

    python3 platform/tools/spec_lint.py <extracted.json> [--tumor prostate] [--format text|json]

stdlib only.
"""
import argparse
import calendar
import json
import os
import re
import sys

import person_rules
from product_gates import read_yaml
from spec_extract import repo_root, requirement_rows

# Which stems name which tumour, and what a table reference looks like — GOVERNED DATA, not code.
# `governance/tumour_registry.yaml` owns both; this module reads them. They were Python constants
# here, which made onboarding a product a change to shared code AND failed quietly: an unlisted
# tumour did not error, `tumor_family()` returned None, and the pack passed a scan it was never
# subject to. Adding a product must not require editing anything under `platform/`.
TUMOUR_REGISTRY = os.path.join("governance", "tumour_registry.yaml")
_REGISTRY = None


def tumour_registry():
    """`{"families": {...}, "aliases": {...}, "prefixes": [...]}` from the governed file. Cached.

    FAIL-CLOSED on a missing or malformed registry. An empty families map would make every table
    reference unrecognisable and FOREIGN_TABLE would report itself inapplicable on every pack at once
    — the check silently switching itself off, repo-wide, because a file went missing. That is the
    same fail-open shape as an empty AI-boundary marker list, and the same answer applies.
    """
    global _REGISTRY
    if _REGISTRY is None:
        # From THIS FILE, not the CWD: `spec_lint` runs from the repo root in CI and from `platform/`
        # in the suites, and a CWD-relative lookup would find the registry in one and not the other.
        path = os.path.join(repo_root(__file__), TUMOUR_REGISTRY)
        doc, err = read_yaml(path)
        if err or not doc:
            sys.exit(f"{TUMOUR_REGISTRY}: {err or 'is empty'} — FOREIGN_TABLE cannot tell one "
                     f"tumour's tables from another's without it, and a check that cannot run must "
                     f"not report itself clean.")
        fams = {str(k).strip().lower(): [str(x).strip().lower() for x in (v or [])]
                for k, v in (doc.get("families") or {}).items()}
        prefixes = [str(e.get("prefix", "")).strip() for e in (doc.get("table_prefixes") or [])
                    if str(e.get("prefix", "")).strip()]
        if not fams or not prefixes:
            sys.exit(f"{TUMOUR_REGISTRY}: declares "
                     f"{'no families' if not fams else 'no table_prefixes'} — see the file's own "
                     f"header for what each is for.")
        _REGISTRY = {"families": fams, "prefixes": prefixes,
                     "aliases": {str(k).strip().lower(): str(v).strip().lower()
                                 for k, v in (doc.get("aliases") or {}).items()}}
    return _REGISTRY


def _names_family(table, stems):
    """Does this table reference name a family with one of `stems`? Matched at TOKEN BOUNDARIES.

    Plain substring matching made one tumour's stem match another's table whenever one name contained
    the other: `sclc` is inside `nsclc`, so `t_nsclc_biomarkers` matched SCLC's own stem and an NSCLC
    table sitting in an SCLC spec was never flagged — silently, one-directionally, on the likeliest
    confusion pair in a lung portfolio.

    The first fix was to spell the stem `_sclc` in the registry. That worked and was the wrong place:
    it encoded MATCHER knowledge — that references are prefix-anchored so a separator always precedes
    the stem — into DATA, so every future author adding a tumour whose name contains another's would
    have to rediscover the trick, and would more likely just not notice. Onboarding a product is meant
    to be a data edit; the data should be the obvious spelling.

    A stem matches a token PREFIX rather than a whole token, so `ovarian` still finds
    `t_enh_ovariancancer` — a real convention — while `sclc` cannot reach into `nsclc`.

    CAMEL AND PASCAL CASE ARE TOKEN BOUNDARIES TOO. Splitting on separators alone assumed
    snake_case, which is Flatiron's `t_` convention and not their `Enhanced_*` one. A real mCRC
    workbook writes `Enhanced_AdvancedNSCLCBiomarkers`; that splits to
    `['enhanced', 'advancednsclcbiomarkers']`, no token starts with `nsclc`, and an NSCLC biomarker
    table sitting inside an mCRC spec was invisible to the one check that exists to find it. It was
    caught by a person reading the rule instead — which is the expensive way.

    The two boundaries are `aB` and `ABc`, so `AdvancedNSCLCBiomarkers` yields
    `advanced | nsclc | biomarkers`. Note this does NOT reopen the substring bug: `nsclc` is a whole
    token and `sclc` is not a prefix of it, so SCLC still cannot claim an NSCLC table.
    """
    spaced = re.sub(r"(?<=[a-z0-9])(?=[A-Z])", " ", table)
    spaced = re.sub(r"(?<=[A-Z])(?=[A-Z][a-z])", " ", spaced)
    return any(tok.startswith(s) for tok in re.split(r"[^a-z0-9]+", spaced.lower()) if tok
               for s in stems)


def tumor_family(tumor):
    """The registry family for a slug, or None if the check cannot apply to it."""
    if not tumor:
        return None
    reg = tumour_registry()
    t = tumor.strip().lower()
    t = reg["aliases"].get(t, t)
    return t if t in reg["families"] else None


# Severity, because a flat list buries the findings that matter. On the ovarian workbook the single
# corrupted state code sat among 318 routine annotations; ranked, it comes first.
#   HIGH  the spec is WRONG or unusable as written — someone must fix or decide
#   INFO  the spec is annotated or incomplete BY DESIGN — context for the reader, not a defect
SEVERITY = {
    # Cross-row. A rule that cannot produce a value and a name defined twice are defects in what
    # the document SAYS, so they rank with the other HIGH findings rather than as structure notes.
    # SPLIT BY HOW SURE THE CHECK IS, measured on two real workbooks rather than assumed.
    #
    # HIGH: no heuristic in them. A name on two rows is a fact about the document, and two decimals
    # 0.003% apart are one constant with a typo. Measured: 1 and 9 on prostate, 0 and 12 on ovarian,
    # every one of them real.
    "CONSTANT_CONFLICT": "HIGH", "DUPLICATE_VARIABLE": "HIGH",
    # INFO: a judgement the reader has to make. Both key on a variable name sitting next to an
    # operator, and that reads differently per house style — prostate's rules are formulas and give 1
    # self-reference in 200 rows; ovarian's are multi-bullet prose that restates the variable, and
    # gives 10 in 360, most of which are the row talking about itself. Ranking those HIGH would put
    # ten judgement calls above an impossible date, and the findings file is read top-down.
    "SELF_REFERENCE": "INFO", "UNDEFINED_REFERENCE": "INFO",
    "IMPOSSIBLE_DATE": "HIGH", "FOREIGN_TABLE": "HIGH", "OUTLIER_IN_LIST": "HIGH",
    "TRUNCATED": "HIGH", "UNBALANCED": "HIGH",
    # HIGH, both, and that is the point of their existence: these mark rows that make a spec look
    # CLEANER the less it says. Ranked with the other refuse-shaped findings so a hollow row can
    # never sit below the fold of a report read top-down.
    "EMPTY_RULE": "HIGH", "DEFERRED_RULE": "HIGH",
    # The resolvable half of DEFERRED_RULE — "See LOT1CAT_MHSPC description" where that variable IS
    # defined here. True, worth a line, and not a refusal: HIGH on an approved spec's own shorthand
    # is how a check earns being skimmed. scan() makes the split; scan_row cannot see across rows.
    "RULE_BY_REFERENCE": "INFO",
    "PLACEHOLDER": "INFO", "NO_TERMINAL_ELSE": "INFO", "VALUE_COUNT": "INFO",
    # NOT one of the UNSETTLED four, on purpose. Those mean "the specification does not contain the
    # answer"; this means "the specification DOES contain it and this artifact may not carry it,
    # because the cell reproduced vendor documentation". Folding the two together would make I17
    # demand a decision for a requirement RWB has fully specified — which is the over-refusal the
    # skill spends a section warning against — and would bury the rows that genuinely need RWB.
    "VENDOR_REDACTED": "INFO",
    "VERIFY_MARKER": "INFO",
    # The transcription-shape three. SKIPPED_LINE and CELL_COUNT are HIGH with no heuristic in them:
    # the line demonstrably was not read, the row demonstrably disagrees with its header. ROW_GAP is
    # INFO because a workbook legitimately hides and blanks rows — the gap is a question, not a
    # defect, and only a person with the workbook can answer it.
    "SKIPPED_LINE": "HIGH", "CELL_COUNT": "HIGH", "ROW_GAP": "INFO",
    # A sheet the shared map calls requirement-bearing that produced NOT ONE ROW. HIGH, and with no
    # heuristic in it: the map says the sheet carries requirements and the extraction has none from
    # it, so either the map is wrong or the requirements were lost. Both are defects, and neither is
    # visible anywhere else — every other list in the extraction is derived from extracted rows, so a
    # sheet that yielded none cannot appear in any of them, not even as `unclassified`.
    "EXPECTED_SHEET_EMPTY": "HIGH",
}

DATE_RE = re.compile(r"\b(\d{1,2})[/-](\d{1,2})[/-](\d{2,4})\b")
PLACEHOLDER_RE = re.compile(r"\[[A-Za-z][^\]\n]{6,}\]")          # [Overall mHSPC cohort]; not [MIN, MAX]
TRUNC_RE = re.compile(r"\(([^)]*(?:cut off|fragment|truncat|clipped)[^)]*)\)", re.I)
# Built ON the shared unsettled-language classifier (person_rules.UNSETTLED_MARKER), plus the
# delivery-format spelling only this lint meets. Two narrower copies each missed the other's
# spellings until an external review lined them up.
VERIFY_RE = re.compile(person_rules.UNSETTLED_MARKER.pattern + r"|\bmay be column-swapped\b", re.I)
def table_re():
    """The table-reference pattern, built from the registry's declared vendor prefixes.

    Prefix-anchored on purpose — see the registry's own warning on `table_prefixes`. Compiled per
    call rather than at import: a module-level regex would freeze whichever registry happened to be
    on disk when the module first loaded, which is exactly the staleness this move was to remove.
    """
    alt = "|".join(re.escape(p) for p in tumour_registry()["prefixes"])
    return re.compile(rf"\b(?:{alt})[a-z0-9_&]+\b", re.I)
ASSIGN_RE = re.compile(r"then\s*=?\s*'([^']+)'|then\s+\w+\s*=\s*'([^']+)'", re.I)
VALUES_RE = re.compile(r"'([^']{2,40})'")


def _impossible_dates(text):
    out = []
    for m in DATE_RE.finditer(text):
        a, b, c = (int(x) for x in m.groups())
        # try both m/d and d/m; a literal is impossible only if NEITHER reading is a real date
        ok = False
        for mm, dd in ((a, b), (b, a)):
            yr = c if c > 99 else 2000 + c
            if 1 <= mm <= 12 and 1 <= dd <= calendar.monthrange(yr, mm)[1]:
                ok = True
        if not ok:
            out.append(m.group(0))
    return out


def _unbalanced(text):
    """Unbalanced quoting or bracketing inside a RULE. Prose cells break parenthesis balance
    constantly (and the stand-in's own "(cut off...)" annotations add more), so checking prose
    produces noise that buries the real findings. Only if/then rules are judged: an odd quote
    count is the case where a literal comparison silently matches nothing, and a paren count
    that does not balance is a grouped condition whose boundary is not the one the author
    intended. The adversarial tumour-tier suite found the paren half missing — this docstring
    promised 'quote or bracket' while the code counted quotes only, and an `If (a and b then 1`
    rule passed with no finding."""
    if not re.search(r"\b(if|then)\b", text, re.I):
        return []
    stripped = re.sub(r"\*?\([^)]*(?:cut off|fragment|truncat|clipped)[^)]*\)?\*?", "", text,
                      flags=re.I)
    out = ["odd number of single quotes in a rule"] if stripped.count("'") % 2 else []
    if _paren_imbalance(stripped):
        out.append("unmatched parenthesis in a rule — a grouped condition silently loses its "
                   "intended boundary")
    return out


def _paren_imbalance(text):
    """Unmatched parens, with `1) ... 2) ... 3)` criteria markers understood as prose.

    Every prostate LAB* rule is written as a numbered list, and its markers close nothing —
    counting them flagged fourteen sound rules on the first live run, and both regex repairs
    (clause-anchored stripping, then a letter lookahead) traded one false-positive family for
    another (`(see note 1)` gained imbalance; `1) 'De novo'` escaped the strip). So the parens
    are WALKED instead: inside an open paren a `)` always closes it, and only a close with NO
    open counts — unless it directly follows one or two digits with a non-word character before
    them, which is a list marker at depth zero, i.e. prose. Unclosed opens always count."""
    depth = unmatched = 0
    for i, c in enumerate(text):
        if c == "(":
            depth += 1
        elif c == ")":
            if depth:
                depth -= 1
                continue
            j = i - 1
            digits = 0
            while j >= 0 and text[j].isdigit() and digits < 2:
                j -= 1
                digits += 1
            if not (digits and (j < 0 or not (text[j].isalnum() or text[j] == "_"))):
                unmatched += 1
    return depth + unmatched


def _outliers(text):
    """Tokens in a quoted list whose shape breaks the list's dominant pattern.

    A find/replace that hits a data value leaves something that reads as ordinary text and passes every
    other check. What it cannot hide is that it no longer looks like its neighbours: one long word among
    sixteen two-letter codes. Only lists with a clear majority shape are judged, so genuine mixed lists
    are left alone.
    """
    out = []
    groups = []
    # quoted list:      in ('ME' 'VT' 'NH' ...)
    for grp in re.findall(r"\(((?:\s*'[^']+'\s*,?){4,})\)", text):
        groups.append(re.findall(r"'([^']+)'", grp))
    # unquoted list:    South=TX OK AR LA KY TN MS AL MD DE DC VA WV NC SC GA FL
    # This form is common in specs and is where a find/replace corruption actually landed, so it must
    # be covered too — the quoted-only version silently passed the real defect.
    for grp in re.findall(r"=\s*((?:[A-Za-z][A-Za-z]{1,20}[ \t]+){4,}[A-Za-z]{2,20})", text):
        toks = grp.split()
        if sum(1 for x in toks if len(x) == 2) >= 4:
            groups.append(toks)
    for toks in groups:
        if len(toks) < 4:
            continue
        lens = [len(x) for x in toks]
        common = max(set(lens), key=lens.count)
        if lens.count(common) < 0.7 * len(toks) or common > 4:
            continue                                   # no dominant short-code shape; not judgeable
        for tok in toks:
            if len(tok) != common and (len(tok) > common + 2 or not tok.isupper()):
                out.append(f"'{tok}' breaks the pattern of a {common}-character list "
                           f"({lens.count(common)}/{len(toks)} tokens are {common} chars)")
    return out


def _exhaustive_numeric_else(text):
    """True when an if/else-if chain's NUMERIC branches tile the whole real line and it ends in a
    missing/null branch — so the lack of a bare `else` leaves no input undefined and NO_TERMINAL_ELSE
    would be a false positive (e.g. the BMI-band rule `<18.5 / [18.5,25) / [25,30) / >=30 / missing`).

    CONSERVATIVE by construction: it returns False (keep flagging) unless it can PROVE the tiling, so a
    real gap stays flagged. The proof:

      * there is a terminal missing/null branch (the `else`-substitute for absent values);
      * every numeric threshold appears BOTH as an upper cut (an interval bounded above by it) and as a
        lower cut (an interval bounded below by it) — `uppers == lowers`. A gap or an overlap breaks
        that equality, and a CATEGORICAL chain (`X=1 / X=2 / missing`, which leaves `X=3` undefined)
        has no numeric comparisons at all, so both fail here and stay flagged;
      * at each shared threshold the boundary value itself is covered — not `<` on one side AND `>` on
        the other, which would leave the exact value in a gap.

    A stray comparison elsewhere in the cell text adds an unpaired threshold, which breaks `uppers ==
    lowers` and makes it flag — the safe direction.
    """
    # Strip HTML tags FIRST: cells use `<br>` for line breaks, and `<br>2=` reads as the comparison
    # `> 2`, which poisons the tiling. `<\/?[a-z]…>` only matches a tag (a letter right after `<`), so
    # a real `BMI < 18.5` — where a space or digit follows `<` — is left intact.
    text = re.sub(r"<\/?[a-zA-Z][^>]*>", " ", text)
    if not re.search(r"\b(?:is\s+)?(?:missing|null)\b", text, re.I):
        return False
    cuts = {}                                       # value -> {'upper': strict?, 'lower': strict?}

    def add(side, strict, val):
        d = cuts.setdefault(val, {})
        d[side] = strict if side not in d else (d[side] and strict)   # any inclusive branch covers it

    for op, num in re.findall(r"(<=|>=|<|>)\s*(-?\d+(?:\.\d+)?)", text):     # VAR op NUM
        add("upper" if op in ("<", "<=") else "lower", op in ("<", ">"), float(num))
    for num, op in re.findall(r"(-?\d+(?:\.\d+)?)\s*(<=|>=|<|>)", text):     # NUM op VAR
        add("lower" if op in ("<", "<=") else "upper", op in ("<", ">"), float(num))

    uppers = {v for v, d in cuts.items() if "upper" in d}
    lowers = {v for v, d in cuts.items() if "lower" in d}
    if not uppers or uppers != lowers:              # open at both ends, every cut paired; else a gap
        return False
    return all(not (d.get("upper", True) and d.get("lower", True)) for d in cuts.values())


# A rule that DEFERS instead of defining: a bare placeholder token, or a pointer at some other
# document ("same as prior study", "see SAP"). Anchored to the WHOLE definition cell — a real rule
# that happens to contain "see" mid-sentence must not fire, and a placeholder with a trailing
# period must. Kept deliberately narrow: every branch here is a spelling a real workbook has
# actually used for "the rule is elsewhere or nowhere".
DEFERRED_RE = re.compile(
    r"^\s*(?:tbd|tbc|\?{2,}|pending|n/?a|"
    r"to\s+be\s+(?:determined|confirmed|decided|defined|added)|"
    r"(?:same\s+as|as\s+per|see|refer\s+to|per)\s+\S.*)\s*\.?\s*$", re.I)


def scan_row(row, tumor=None):
    text = row["text"]
    f = []
    # THE EMPTINESS CLASS. An adversarial run proved the failure mode: a workbook whose definition
    # cells are blank produced FEWER findings than a complete one — emptiness read as cleanliness,
    # and the only thing between a hollow spec and Gate 2 was the human disposition loop with no
    # machine assist saying WHICH rows were hollow. Both checks fire only where the sheet actually
    # RESOLVES a definition column (`named_fields` keeps empty cells, so key-present-and-blank
    # means the column exists and the cell says nothing); a sheet that resolves none is
    # `columns_unresolved`, already refused under --strict, and firing per-row on top of that
    # would be the same fact forty times.
    fields = row.get("fields") or {}
    if row.get("variable") and not row.get("pre_header") and "definition" in fields:
        rule = str(fields.get("definition") or "").strip()
        declared_values = str(fields.get("values") or "").strip()
        if not rule and not declared_values:
            f.append(("EMPTY_RULE", f"`{row['variable']}` names a requirement and defines NOTHING — "
                                    f"the definition cell is blank and no value set is declared. A "
                                    f"row like this scaffolds into an all-TODO record and reads as "
                                    f"clean in every count"))
        elif rule and DEFERRED_RE.match(rule):
            f.append(("DEFERRED_RULE", f"`{row['variable']}`'s definition is {rule!r} — a "
                                       f"placeholder or a pointer at another document, not a rule "
                                       f"this specification carries. Nothing downstream can "
                                       f"implement or verify it as written"))
    for d in _impossible_dates(text):
        f.append(("IMPOSSIBLE_DATE", f"'{d}' is not a real calendar date"))
    if "VENDOR DOCUMENTATION REDACTED" in text:
        f.append(("VENDOR_REDACTED", "a cell reproduced vendor documentation and was removed from "
                                     "this artifact — an AUTHORIZED HUMAN must review the restricted "
                                     "reference material; contract_record.py refuses this item"))
    for p in PLACEHOLDER_RE.findall(text):
        if not re.match(r"\[[A-Z_]+(,\s*[A-Z_]+)*\]$", p):        # skip [MININDEX, MAXINDEX]
            f.append(("PLACEHOLDER", f"{p} — prose in place of a rule"))
    for t in TRUNC_RE.findall(text):
        f.append(("TRUNCATED", t.strip()))
    for v in set(VERIFY_RE.findall(text) or []):
        f.append(("VERIFY_MARKER", "spec author left an explicit confirm/verify marker"))
    if VERIFY_RE.search(text) and not VERIFY_RE.findall(text):
        f.append(("VERIFY_MARKER", "spec author left an explicit confirm/verify marker"))
    family = tumor_family(tumor)
    if family:
        fams = tumour_registry()["families"]
        own = fams[family]
        for tbl in table_re().findall(text):
            for fam, stems in fams.items():
                if fam == family:
                    continue
                if _names_family(tbl, stems) and not _names_family(tbl, own):
                    f.append(("FOREIGN_TABLE", f"{tbl} looks like a {fam} table inside a {tumor} spec"))
                    break
    for b in _unbalanced(text):
        f.append(("UNBALANCED", b))
    for o in _outliers(text):
        f.append(("OUTLIER_IN_LIST", o))
    if re.search(r"else\s+if", text, re.I):
        tail = text[text.lower().rfind("else if"):]
        if not re.search(r"\belse\b(?!\s*if)", tail, re.I) and not _exhaustive_numeric_else(text):
            f.append(("NO_TERMINAL_ELSE", "if/else-if chain with no final else — unmatched input undefined"))
    # `fields["values"]`, NOT `cells[2]`. The extraction NAMES its columns per tab because the tabs do
    # not share a layout — position 2 is the values column on two of prostate's 200 rows and something
    # else on the other 198. So this check, whose whole subject is "more values declared than the rule
    # assigns", was reading a definition or a note and comparing that to the assignments. It fired
    # rarely and for the wrong reason, and COHORTU — the defect it was written from — is caught by a
    # different rule, which is what made the silence look like correctness.
    declared = {v.strip() for v in VALUES_RE.findall((row.get("fields") or {}).get("values") or "")}
    # A long list of short codes is an ENUMERATION being mapped (e.g. 51 state codes), not a declared
    # value set whose members should each be assigned. Only label-shaped, small sets are checked.
    declared = {v for v in declared if len(v) > 3 and " " in v or len(v) > 8}
    assigned = {(a or b).strip() for a, b in ASSIGN_RE.findall(text)}
    if declared and assigned and 1 < len(declared) <= 12 and len(declared) > len(assigned) + 1:
        never = sorted(declared - assigned)[:4]
        f.append(("VALUE_COUNT", f"{len(declared)} values declared, {len(assigned)} ever assigned; "
                                 f"never assigned e.g. {never}"))
    return f


def inapplicable_checks(rows, tumor):
    """Checks that ran but could not have fired. A check silently finding nothing and a check that never
    applied look identical in a report of zero findings — which is how a spec passes a scan it was never
    actually subject to."""
    notes = []
    if not tumor:
        notes.append({"check": "foreign_table",
                      "note": "FOREIGN_TABLE did not apply: no --tumor given"})
    elif not tumor_family(tumor):
        notes.append({"check": "foreign_table",
                      "note": f"FOREIGN_TABLE did not apply: '{tumor}' resolves to no tumour family "
                              f"(known: {', '.join(sorted(tumour_registry()['families']))}). Add it to "
                              f"{TUMOUR_REGISTRY} — a governed data edit, not a code change."})
    elif not any(table_re().search(r["text"]) for r in rows):
        notes.append({"check": "foreign_table",
                      "note": "FOREIGN_TABLE found no table-shaped references at all — this spec "
                              "either names no source tables, or uses a prefix TABLE_RE does not "
                              "know"})
    # VALUE_COUNT reads the NAMED `values` field, and a tab that carries no such column switches the
    # check off for every row on it. That silence was undisclosed and cost this check its meaning
    # once already: it used to read cell POSITION 2, which is the values column on two of prostate's
    # 200 rows, so it was comparing a definition or a note against the rule's assignments and finding
    # nothing — indistinguishable, in a report, from a specification with no such defect.
    if not any((r.get("fields") or {}).get("values") for r in rows):
        notes.append({"check": "value_count",
                      "note": "VALUE_COUNT did not apply: no row carries a `values` field, so no "
                              "row declares a value set for the rule's assignments to be compared "
                              "against"})
    return notes


def scan(data, tumor=None, tabs=None):
    """Scan the requirement-bearing rows — by default, every row that carries a DOMAIN.

    A real workbook carries far more than the specification: cover sheets, change logs, review-decision
    trackers, approval gates, backlogs. Those legitimately say "confirm" and "[TBD]" everywhere, so
    scanning them buries the genuine defects — on the ovarian workbook it turned 30-odd real findings
    into 392. A sheet listed in governance/spec_sheet_map.yaml is requirement-bearing by that fact, so
    the filter needs no per-product tab list; `tabs` remains as an explicit override.
    """
    findings = []
    rows = requirement_rows(data, tabs)
    # For the deferred-rule split below: a pointer that names a variable THIS spec defines is
    # shorthand a reader can resolve without leaving the document; a pointer at nothing here is a
    # rule the specification does not carry. scan_row cannot tell them apart — it sees one row.
    defined = {r["variable"] for r in rows if r.get("variable")}
    for row in rows:
        for kind, detail in scan_row(row, tumor):
            if kind == "DEFERRED_RULE" and any(tok in defined and tok != row.get("variable")
                                               for tok in _VARLIKE.findall(detail)):
                # RULE_BY_REFERENCE, INFO: the row alone carries no rule, but the reference lands.
                # Kept as its own kind rather than dropped — prostate's approved spec writes five
                # LOT*CAT rows as "See LOT1CAT_MHSPC description", and ranking those HIGH forever
                # is how a check earns being skimmed; hiding them entirely would un-say something
                # true. What stays HIGH is the pointer at another DOCUMENT, or at nothing.
                kind, detail = "RULE_BY_REFERENCE", detail.replace(
                    "a placeholder or a pointer at another document, not a rule this "
                    "specification carries. Nothing downstream can implement or verify it as "
                    "written",
                    "a rule by reference to a variable this specification defines — resolvable, "
                    "but the row read alone carries nothing")
            findings.append({"item_id": row["item_id"], "tab": row["tab"], "row": row["row"],
                             "variable": row["variable"][:40], "kind": kind, "detail": detail,
                             "severity": SEVERITY.get(kind, "INFO")})
    return (findings + scan_across(data, tabs) + scan_structure(data, tabs)
            + scan_expected_sheets(data, tabs) + scan_shape(data, tabs))


# What the workbook's own structure hides. These are not defects in what the spec SAYS — they are
# reasons a cell can be blank, or present, for a reason the text does not show. Left unreported, a
# formula with no cached result and a genuinely empty derivation are the same thing to every reader.
STRUCTURE_FINDINGS = {
    "header_candidates": ("HIGH", "header-shaped row(s) MID-SHEET — a second table's header that "
                                  "does not repeat the first header's first cell maps every row "
                                  "beneath it against the WRONG columns; split the tables into "
                                  "separate tabs or align their headers: {}"),
    "formula_no_value": ("HIGH", "formula cell(s) with no cached result — these read as BLANK, so any "
                                 "rule behind them is silently missing: {}"),
    "merged":           ("HIGH", "merged range(s) on a requirement sheet — a merge keeps the anchor "
                                 "cell and blanks the rest, so one reaching across a named column "
                                 "deletes that column for those rows: {}"),
    "hidden_rows":      ("HIGH", "hidden row(s), extracted as ordinary requirements — usually retired "
                                 "content, and invisible to whoever reviewed the workbook: {}"),
    "validation_lists": ("INFO", "dropdown(s) whose allowed values live in the validation, not in any "
                                 "cell, so the enumeration is not extracted: {}"),
    "comments":         ("INFO", "cell comment(s), which are not read — RWB caveats often live here: {}"),
    "shadowing_cols":   ("HIGH", "HIDDEN column(s) whose header names a field the resolver reads. The "
                                 "first matching column wins, so the rule comes from a column nobody "
                                 "can see in Excel: {}"),
    # The sheet's OWN visibility, which sat beside `hidden_rows` unreported for as long as that one
    # has existed. A hidden requirement sheet extracts exactly like a visible one, so its rules enter
    # the contract while a reviewer opening the workbook never sees the tab to check them against.
    # `veryHidden` is worse than `hidden` and is called out by name: Excel's own Unhide dialog does
    # not list it, so a reviewer told "unhide the tabs" still cannot reach it.
    # The reviewer approved what Excel DISPLAYED; the extraction publishes what Excel STORED. HIGH
    # because the gap is a hundred-fold on a percentage — a `5%` eligibility threshold reaches the
    # contract as `0.05` — and because no reading of the workbook on screen can reveal it.
    "display_differs":  ("HIGH", "cell(s) whose NUMBER FORMAT makes the workbook show one number and "
                                 "this reader take another, so the rule in the contract is not the "
                                 "one on screen when it was approved: {}"),
    "sheet_state":      ("HIGH", "this requirement sheet is NOT VISIBLE in the workbook ({}), yet its"
                                 "rows were extracted as ordinary requirements — a reviewer opening "
                                 "the workbook cannot see the tab to check them; `veryHidden` is not "
                                 "even listed by Excel's Unhide dialog"),
}


# A variable NAME as the workbook writes one: upper-case, digits and underscores, long enough not to
# match an enumeration label. `IHC`, `NGS` and `PCR` are three-letter test methods that appear after
# `=` in value lists, and treating them as variable references was the first version's whole
# false-positive population.
_VARLIKE = re.compile(r"\b[A-Z][A-Z0-9_]{3,}\b")
# A variable name found in the VARIABLE COLUMN rather than in prose. Two characters is enough there
# because the column is already known to hold names — see `_duplicate_variables` for why the longer
# floor is a blind spot in that position, and why uppercase is still required.
_NAMED = re.compile(r"[A-Z][A-Z0-9_]{1,}")
# ...used in a FORMULA, which is what separates a reference from a mention. `PSABL` occurs as
# `(PSA6MO - PSABL)/PSABL`; `IHC` occurs as `1 = IHC,`. The operator immediately before or after is
# the whole discriminator, and it is why this reports one row on the pack it was calibrated against
# instead of forty.
# A CLOSING paren is deliberately absent from the trailing class. `Year(INITYR)` is a function
# consuming its argument; `(source var BMI_GRP)` is the ovarian workbook ANNOTATING which source
# variable a rule came from, and both end in `VAR)`. Including `)` made every such annotation read as
# a circular definition — eleven on that pack, none of them real. Arithmetic still matches, because
# arithmetic is `VAR - x` and `x / VAR`, never `VAR)`.
_IN_FORMULA = re.compile(r"[-+*/(]\s*%s|%s\s*[-+*/]")
# Words that look like variables and are not: SQL, spreadsheet functions, and the units and markers a
# definition legitimately shouts. Extended when a real spec proves one is needed, never pre-emptively.
_NOT_A_VARIABLE = frozenset({
    "NULL", "TRUE", "FALSE", "AND", "OR", "NOT", "CASE", "WHEN", "THEN", "ELSE", "END",
    "SELECT", "FROM", "WHERE", "GROUP", "ORDER", "JOIN", "DISTINCT", "COUNT", "SUM", "MIN",
    "MAX", "YEAR", "DATE", "DAYS", "MONTHS", "YEARS", "UNKNOWN", "OTHER", "MISSING", "NONE",
    "TBD", "TODO", "VERIFY", "TEXT", "CHAR", "NUM", "INT", "FLAG", "YES", "NO", "NA",
})


def _self_referencing(rows):
    """A variable whose own definition names itself: `INITYR` defined as `Year(INITYR)`.

    A rule that consumes its own output states nothing — there is no value it could produce, and no
    reviewer can supply one from the row. It is not a typo the reader can see through, which is why
    it sat in a specification through a revision.

    EXACT, CASE-SENSITIVE, WHOLE-TOKEN. `HRR_INDEX_TESTN` reading "Numeric of HRR_INDEX_TEST" is a
    reference to a DIFFERENT variable and correct; a substring match would call it circular. The
    variable column is compared against the definition only, never the whole row: a row that mentions
    its own name in a note is describing itself, which is what notes are for.
    """
    out = []
    for row in rows:
        var = (row.get("fields") or {}).get("variable", "").strip()
        rule = ((row.get("fields") or {}).get("definition") or "").strip()
        if not var or not rule or not _VARLIKE.fullmatch(var):
            continue
        # ASSIGNED IS NOT CONSUMED, and conflating them reported nineteen rows on this pack where
        # one is circular. A specification writes a rule as `If 0<=AGE<=18 then AGEGR1='0-18'` —
        # the variable on the LEFT of `=` is the thing being defined, which is what a definition is
        # for. `Year(INITYR)` CONSUMES its own output, and that is the defect.
        #
        # Operator adjacency separates them: `(INITYR)` sits against a paren, `AGEGR1=` does not.
        # It also drops "Use RACE variable as in the demographics table" — a mention of a vendor
        # column that happens to share the name, which is a source question and not a circular rule.
        pattern = _IN_FORMULA.pattern % (re.escape(var), re.escape(var))
        if re.search(pattern, rule):
            out.append((row, "SELF_REFERENCE",
                        f"`{var}` is consumed by its own rule — `{rule[:60]}`. There is no value "
                        f"this can produce, and the row supplies nothing to resolve it with"))
    return out


def _undefined_references(rows):
    """A formula that divides by a variable no row in the specification defines.

    `PSA50_6MO` reads `(PSA6MO - PSABL)/PSABL` and nothing anywhere defines `PSABL`. Every reviewer
    who read that row understood what was meant and none of them could say what the baseline IS —
    which window, which record, which assay. A drafter with the same row will pick one.

    The DEFINED set is every variable this specification names, so a reference to a row elsewhere in
    the workbook is not reported; only a name the document never introduces.
    """
    defined = {(r.get("fields") or {}).get("variable", "").strip() for r in rows}
    defined.discard("")
    out = []
    for row in rows:
        rule = ((row.get("fields") or {}).get("definition") or "").strip()
        var = (row.get("fields") or {}).get("variable", "").strip()
        # SORTED, and the drift check is how that was found. `set` iteration over strings varies
        # between processes under hash randomisation, so this emitted the same findings in a
        # different ORDER every run — and `lint.json` is a committed artifact compared byte-for-byte.
        # The pack reported stale immediately after being regenerated.
        for token in sorted(set(_VARLIKE.findall(rule))):
            if token in defined or token == var or token in _NOT_A_VARIABLE:
                continue
            pattern = _IN_FORMULA.pattern % (re.escape(token), re.escape(token))
            if re.search(pattern, rule):
                out.append((row, "UNDEFINED_REFERENCE",
                            f"the rule computes with `{token}`, which no row in this specification "
                            f"defines — `{rule[:60]}`. If it is a vendor column, this row does not "
                            f"say which table; if it is a variable, nothing states its rule"))
    return out


def _conflicting_constants(rows):
    """The same constant written two ways: `30.4375` on three rows and `30.4376` on a fourth.

    NEARNESS is the signal, not repetition. Two constants a specification genuinely means to differ
    are not 0.003% apart; two that are, are one value with a typo in it — and which one is authored
    is exactly what nobody can tell from the document. Both rows look correct in isolation, which is
    why this is invisible until the rows are read together.

    Only decimals: integers legitimately sit close (a 7-day window beside an 8-day one), and a rule
    that compared them would report every threshold in the pack.
    """
    seen = {}
    for row in rows:
        for lit in re.findall(r"\b\d+\.\d{3,}\b", (row.get("text") or "")):
            seen.setdefault(lit, []).append(row)
    out, values = [], sorted(seen, key=float)
    for i, a in enumerate(values):
        for b in values[i + 1:]:
            fa, fb = float(a), float(b)
            if fa and abs(fb - fa) / fa < 1e-3:
                for row in seen[b]:
                    out.append((row, "CONSTANT_CONFLICT",
                                f"`{b}` here, `{a}` elsewhere in this specification — the same "
                                f"constant written two ways; which one is authored is not "
                                f"recoverable from the document"))
    return out


def _duplicate_variables(rows):
    """One name on two rows. The second definition is invisible to anyone who found the first.

    Reported against EVERY row that shares the name, not just the later one: there is no basis in
    the document for calling either the duplicate, and naming one of them would be a guess about
    which the author meant.
    """
    # `_NAMED`, NOT `_VARLIKE`, AND THE DIFFERENCE IS TWO CHARACTERS OF BLIND SPOT.
    #
    # `_VARLIKE` requires four characters because it scans free PROSE, where `IHC`, `NGS` and `PCR`
    # after an `=` were the first version's entire false-positive population. That floor is correct
    # there and stays.
    #
    # It is wrong HERE. This check reads the VARIABLE COLUMN, which the header resolver has already
    # established holds variable names — there is no prose to be confused by, so the length floor
    # bought nothing and cost the short names. `OS`, `PFS`, `RAS`, `MSI`, `MMR`, `AGE`, `BMI`: most
    # of the variables an oncology specification argues hardest about are two or three characters,
    # and every one of them could be defined twice, with contradictory rules, in silence. An
    # adversarial workbook defined `OS` on two tabs — "censor at last activity" against "censor at
    # end of data availability" — and this check said nothing, while flagging the four-letter
    # `TTNT` beside it.
    #
    # Uppercase is kept: it is what separates a variable name from a prose cell. Relaxing that as
    # well added `Condition` on ovarian's PSOC Strategy tab and nothing true. Measured against all
    # three committed packs, this exact rule adds no finding they do not already have.
    by_name = {}
    for row in rows:
        var = (row.get("fields") or {}).get("variable", "").strip()
        if var and _NAMED.fullmatch(var):
            by_name.setdefault(var, []).append(row)
    out = []
    for var, group in sorted(by_name.items()):
        if len(group) < 2:
            continue
        where = ", ".join(r["item_id"] for r in group)
        for row in group:
            out.append((row, "DUPLICATE_VARIABLE",
                        f"`{var}` is defined on {len(group)} rows ({where}) — a reader who finds one "
                        f"of them has no way to know the others exist"))
    return out


# THE CHECKS THAT NEED MORE THAN ONE ROW. Every check in `scan_row` reads a cell in isolation, which
# is why four of the questions accountable people raised on prostate/202607 carried no mark at all:
# a circular definition, a reference to an undefined variable, a constant that disagrees with itself
# and a duplicated name are each invisible in the row that contains them. They were found by the
# benchmark rather than by review, which is the argument for having measured.
ACROSS_ROWS = (_self_referencing, _undefined_references, _conflicting_constants, _duplicate_variables)


def scan_across(data, tabs=None):
    """Findings that only exist when the requirement rows are read TOGETHER."""
    rows = list(requirement_rows(data, tabs))
    out = []
    for check in ACROSS_ROWS:
        for row, kind, detail in check(rows):
            out.append({"item_id": row["item_id"], "tab": row["tab"], "row": row["row"],
                        "variable": row["variable"][:40], "kind": kind, "detail": detail,
                        "severity": SEVERITY.get(kind, "HIGH")})
    return out


def scan_structure(data, tabs=None):
    """Findings from `workbook_structure`, limited to the requirement-bearing sheets."""
    structure = (data.get("extraction") or {}).get("workbook_structure") or {}
    if not structure:
        return []                                   # per-tab path, or an older extraction
    scanned = {r["tab"] for r in requirement_rows(data, tabs)}
    out = []
    for tab in sorted(structure):
        if tab not in scanned:
            continue                                # a cover sheet's merges are nobody's problem
        for key, detail in sorted(structure[tab].items()):
            if key not in STRUCTURE_FINDINGS:
                continue
            severity, template = STRUCTURE_FINDINGS[key]
            shown = ", ".join(str(d) for d in detail[:8]) + ("…" if len(detail) > 8 else "")
            out.append({"item_id": f"{tab}:(sheet)", "tab": tab, "row": 0, "variable": "(sheet)",
                        "kind": "WORKBOOK_STRUCTURE", "severity": severity,
                        "detail": template.format(shown)})
    return out


def scan_expected_sheets(data, tabs=None):
    """Findings for requirement sheets the workbook HAS and the extraction got nothing from.

    Deliberately NOT filtered by the sheets that produced rows, which is the filter `scan_structure`
    and `scan_shape` both use. Those two ask "is this oddity on a sheet we care about?", and the
    answer comes from the extracted rows. This one asks the opposite question — "is a sheet we care
    about missing from the extracted rows?" — so the same filter would suppress every finding it can
    make, and the check would pass by construction on exactly the packs it is for.

    Absent key means NOT DETERMINED, and returns nothing: the per-tab path has no workbook whose
    sheets could be enumerated, and an older extraction predates the field. Neither is evidence that
    no sheet is empty, and neither may be reported as if it were.
    """
    extraction = data.get("extraction") or {}
    if "expected_sheets_empty" not in extraction:
        return []
    out = []
    for tab in extraction["expected_sheets_empty"] or []:
        out.append({"item_id": f"{tab}:(sheet)", "tab": tab, "row": 0, "variable": "(sheet)",
                    "kind": "EXPECTED_SHEET_EMPTY", "severity": SEVERITY["EXPECTED_SHEET_EMPTY"],
                    "detail": "the shared sheet map calls this sheet requirement-bearing, but the "
                              "extraction took ZERO rows from it — an empty or header-only tab, a "
                              "table whose header the reader did not recognise, or rows that all "
                              "failed to parse. Nothing else in this artifact mentions the sheet, "
                              "because every other list is built from extracted rows"})
    return out


def scan_shape(data, tabs=None):
    """Findings from the extractor's per-source shape report — the transcription-loss half.

    `read_markdown_tab` reports what it did NOT consume instead of silently dropping it; this turns
    each report into a finding a person can settle. Same tab filter as `scan_structure`: a shape
    oddity in a sheet nobody registered as requirement-bearing is nobody's problem."""
    scanned = {r["tab"] for r in requirement_rows(data, tabs)}
    out = []
    for src in (data.get("extraction") or {}).get("sources") or []:
        shape, tab = src.get("shape") or {}, src.get("tab")
        if not shape or tab not in scanned:
            continue
        base = {"tab": tab, "row": 0, "variable": "(file)"}
        for sk in shape.get("skipped_lines") or []:
            out.append({**base, "item_id": f"{tab}:(file)", "kind": "SKIPPED_LINE",
                        "severity": SEVERITY["SKIPPED_LINE"],
                        "detail": f"{src.get('file')} line {sk.get('line')}: a `|` line read as "
                                  f"neither row, header nor separator — absent from every "
                                  f"downstream artifact: {sk.get('text', '')[:120]}"})
        for wm in shape.get("width_mismatches") or []:
            out.append({**base, "item_id": f"{tab}:{wm.get('row')}", "row": wm.get("row", 0),
                        "kind": "CELL_COUNT", "severity": SEVERITY["CELL_COUNT"],
                        "detail": f"row {wm.get('row')} has {wm.get('cells')} cells against a "
                                  f"{wm.get('header_cells')}-cell header — a lost trailing cell or "
                                  f"an unescaped `|`, and every field after it is misread"})
        for a, b in shape.get("row_gaps") or []:
            out.append({**base, "item_id": f"{tab}:(file)", "kind": "ROW_GAP",
                        "severity": SEVERITY["ROW_GAP"],
                        "detail": f"{src.get('file')}: row numbers jump {a} -> {b} — hidden/blank "
                                  f"workbook rows and rows lost from the transcription read "
                                  f"identically; confirm against the workbook which this is"})
    return out


def main(argv):
    ap = argparse.ArgumentParser(description="Deterministic defect scan over an extracted spec.")
    ap.add_argument("extracted", help="JSON from spec_extract.py")
    ap.add_argument("--tumor", help="tumour family, enables the foreign-table check (e.g. prostate)")
    ap.add_argument("--format", choices=("text", "json"), default="text")
    ap.add_argument("--tabs", help="OVERRIDE the tabs to scan; normally omitted — the default is every "
                                   "sheet mapped in governance/spec_sheet_map.yaml")
    a = ap.parse_args(argv)

    with open(a.extracted, encoding="utf-8") as fh:
        data = json.load(fh)
    findings = scan(data, a.tumor, a.tabs.split(",") if a.tabs else None)

    notes = inapplicable_checks(requirement_rows(data, a.tabs.split(",") if a.tabs else None), a.tumor)
    if a.format == "json":
        # An object, not a bare list: a consumer reading only `findings: []` cannot tell "clean" from
        # "never looked". `applicability` is what makes zero findings mean something.
        # `fingerprint` is copied from the extraction, never recomputed here: one definition, in the
        # tool that owns extraction identity. A consumer compares this to extracted.json's own value
        # and knows whether the two files describe the same run — which comparing item ids cannot
        # tell it, because an in-place spec edit leaves every id exactly where it was.
        # PER CHECK, not one flag over one pooled list. This used to read `"not_applicable" if
        # notes else "applied"` over EVERY note — so an unrelated VALUE_COUNT note made the file
        # claim FOREIGN_TABLE never ran on a spec it had scanned row by row. An adversarial run
        # caught it: a machine consumer was being told a check was off that was on.
        _off = {n["check"] for n in notes}
        print(json.dumps({"fingerprint": (data.get("extraction") or {}).get("fingerprint", ""),
                          "findings": findings,
                          "applicability": {
                              "foreign_table": "not_applicable" if "foreign_table" in _off else "applied",
                              "value_count": "not_applicable" if "value_count" in _off else "applied",
                              "reasons": [n["note"] for n in notes]}}, indent=1))
        return 0

    hi = sum(1 for f in findings if f["severity"] == "HIGH")
    print(f"   HIGH {hi}   INFO {len(findings) - hi}\n")
    by = {}
    for f in findings:
        by.setdefault((f["severity"], f["kind"]), []).append(f)
    rows = requirement_rows(data, a.tabs.split(",") if a.tabs else None)
    total = data["extraction"]["row_count"]
    print(f"scanned {len(rows)} of {total} rows"
          f"{' (requirement sheets only)' if len(rows) != total else ''} — {len(findings)} finding(s)\n")
    for note in notes:
        print(f"   NOTE  {note['note']}")
    if notes:
        print()
    for key in sorted(by, key=lambda k: (k[0] != "HIGH", -len(by[k]))):
        sev, kind = key
        print(f"[{sev}] {kind}  ({len(by[key])})")
        for f in by[key][:12]:
            print(f"   {f['item_id']:<22} {f['variable']:<24} {f['detail'][:80]}")
        if len(by[key]) > 12:
            print(f"   ... +{len(by[key]) - 12} more")
        print()
    return 0


if __name__ == "__main__":
    from console import use_utf8
    use_utf8()
    sys.exit(main(sys.argv[1:]))
