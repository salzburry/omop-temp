#!/usr/bin/env python3
"""The typed source-adapter contract — one versioned artifact per role, per dataset.

    python3 platform/tools/source_adapter.py skeleton <pack>     # print the TODO skeleton
    python3 platform/tools/source_adapter.py check <pack>        # validate a committed file

WHY THIS EXISTS. The knowledge of how a logical role binds to a physical delivery is scattered:
stage reads know the columns, the config knows the stems, source_grain knows the keys, mapping
evidence knows the kinds, and none of it states types, parsers, join cardinality, vocabulary or
units anywhere a tool can hold a build to. The adapter file (`config/source_adapters.yaml`) is
that one artifact — the versioned source-adapter contract — and it is the
prerequisite for the second dataset: two adapter sets under one contract IS the semantic view's
implementation axis (semantic_view reads the `dataset:` labels).

DIVISION OF AUTHORITY, unchanged by this file: `skeleton` derives every MACHINE-KNOWABLE field
from the engine's own declarations and leaves the judgment fields TODO — a person fills types,
parsers, cardinality, vocabulary, units, and signs the review block. `check` is fail-closed the
way this repository is: a committed file must cover EVERY required role (partial coverage reads
as complete), cover every stage-read required column, agree with any declared source_grain, and
carry a named person's dated review when it claims one. NO adapter file is a stated absence —
"no claim" — never an error and never a pass.
"""
import argparse
import json
import os
import sys

TOOLS = os.path.dirname(os.path.abspath(__file__))
PLATFORM = os.path.dirname(TOOLS)
sys.path.insert(0, TOOLS)
sys.path.insert(0, os.path.join(PLATFORM, "engine"))

import product_gates as pg                                                  # noqa: E402
from spec_extract import repo_relative                                      # noqa: E402

ADAPTERS = os.path.join("config", "source_adapters.yaml")
CARDINALITIES = ("one_to_one", "many_to_one")


def _engine(pack):
    from config import load_config                                          # noqa: PLC0415
    import validate as ev                                                   # noqa: PLC0415
    cfg = load_config(os.path.join(pack, "config", "data_product.yaml"))
    return cfg, ev


def skeleton(pack):
    """The per-role skeleton, machine fields filled, judgment fields TODO. Prints, never
    writes — committing and signing it is a person's act, like every registration here."""
    cfg, ev = _engine(pack)
    required = ev.required_columns(cfg)
    optional = ev.optional_columns(cfg)
    grain_declared = dict(ev.source_grain(cfg)[0] or {})
    stems = {}
    try:
        for role, entry in (cfg.raw.get("sources") or {}).items():
            stems[role] = entry if isinstance(entry, str) else (entry or {}).get("table", "")
    except Exception:                                 # noqa: BLE001 — a slim config names none
        pass
    L = ["# source_adapters.yaml — the typed binding of each logical role to ONE dataset's",
         "# physical delivery. Machine-derived fields are filled; every TODO is a person's",
         "# judgment. Sign the review block only after checking the physical table itself.",
         "dataset: TODO            # e.g. flatiron | optum_mc — the semantic view's axis",
         "adapters:"]
    for role in sorted(set(required) | set(optional)):
        cols = sorted(set(required.get(role, ())))
        opt = sorted(set(optional.get(role, ())))
        L.append(f"  - logical_role: {role}")
        L.append(f"    physical_table: {stems.get(role) or 'TODO'}")
        L.append("    required_columns:")
        for c in cols:
            L.append(f"      {c}: {{physical: {c}, logical_type: TODO, "
                     f"accepted_physical_types: [TODO], parser: null}}")
        if opt:
            L.append(f"    optional_columns: {json.dumps(opt)}")
        L.append(f"    grain: {json.dumps(grain_declared.get(role, ['TODO']))}")
        L.append("    join: {to: index, keys: [patientid], cardinality: TODO}")
        L.append("    vocabulary: {}    # column -> coding system, where one applies")
        L.append("    units: {}         # column -> unit, where one applies")
        L.append("    review: {status: pending, approved_by: TODO, approval_date: TODO}")
    return "\n".join(L)


def check(pack):
    """Problems with a committed adapter file, or the stated absence. Fail-closed grammar:
    partial coverage, an unknown role, a thin column set, a grain disagreement, an invented
    cardinality, and an unowned review each surface by name."""
    path = os.path.join(pack, ADAPTERS)
    if not os.path.exists(path):
        return {"state": "no_claim", "problems": [],
                "note": f"no {ADAPTERS} — the pack makes no adapter claim; skeleton prints one"}
    doc, err = pg.read_yaml(path)
    if err:
        return {"state": "unreadable", "problems": [f"{repo_relative(path)}: {err}"]}
    cfg, ev = _engine(pack)
    required = ev.required_columns(cfg)
    grain_declared = dict(ev.source_grain(cfg)[0] or {})
    problems = []
    dataset = str((doc or {}).get("dataset") or "").strip()
    if not dataset or dataset == "TODO":
        problems.append("dataset is unstated — the adapter set binds ONE dataset's delivery, "
                        "and the semantic view's implementation axis reads this label")
    seen = {}
    for i, a in enumerate((doc or {}).get("adapters") or []):
        role = str(a.get("logical_role") or "")
        where = f"adapter[{i}] ({role or 'role unstated'})"
        if not role:
            problems.append(f"{where}: logical_role is unstated")
            continue
        if role in seen:
            problems.append(f"{where}: duplicated — one adapter per role per dataset")
            continue
        seen[role] = a
        if role not in required and role not in ev.optional_columns(cfg):
            problems.append(f"{where}: no stage read declares this role — an adapter for a "
                            f"role nothing reads binds nothing")
            continue
        if str(a.get("physical_table") or "TODO").strip() in ("", "TODO"):
            problems.append(f"{where}: physical_table is TODO — an adapter that names no "
                            f"table binds a role to nothing")
        j = a.get("join") or {}
        if not j.get("to") or not j.get("keys"):
            problems.append(f"{where}: join.to / join.keys unstated — an unjoined source is "
                            f"a frame, not an implementation")
        cols = {str(c).lower() for c in (a.get("required_columns") or {})}
        missing = sorted(set(required.get(role, ())) - cols)
        if missing:
            problems.append(f"{where}: required_columns omit stage-read column(s) "
                            f"{missing} — the engine will read what the adapter never bound")
        for c, spec in sorted((a.get("required_columns") or {}).items()):
            if str((spec or {}).get("logical_type") or "TODO") == "TODO":
                problems.append(f"{where}: {c}.logical_type is TODO — an untyped binding is "
                                f"the presence-only mapping this file exists to replace")
        g = [str(k) for k in (a.get("grain") or [])]
        if role in grain_declared and g and g != [str(k) for k in grain_declared[role]]:
            problems.append(f"{where}: grain {g} disagrees with the pack's declared "
                            f"source_grain {grain_declared[role]} — one of the two is wrong")
        card = str(((a.get("join") or {}).get("cardinality")) or "")
        if card not in CARDINALITIES:
            problems.append(f"{where}: join.cardinality {card!r} is not one of "
                            f"{CARDINALITIES} — TODO is not a cardinality")
        rev = a.get("review") or {}
        if str(rev.get("status") or "") == "reviewed":
            for field, checkfn in (("approved_by", pg.not_a_person),
                                   ("approval_date", pg.bad_date)):
                v = rev.get(field)
                why = checkfn(v) if v not in (None, "", "TODO") else "is not set"
                if why:
                    problems.append(f"{where}: review claims reviewed but {field}: {why}")
    uncovered = sorted(set(required) - set(seen))
    if uncovered:
        problems.append(f"required role(s) with no adapter: {uncovered} — partial coverage "
                        f"reads as complete, so a committed file covers every required role")
    all_reviewed = bool(seen) and all(
        str((a.get("review") or {}).get("status") or "") == "reviewed"
        for a in seen.values())
    return {"state": "checked", "dataset": dataset or None,
            "adapters": sorted(seen), "all_reviewed": all_reviewed,
            "schema": str((doc or {}).get("schema") or "") or None,
            "cut": str((doc or {}).get("cut") or "") or None,
            "problems": problems}


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    ap.add_argument("cmd", choices=("skeleton", "check"))
    ap.add_argument("pack")
    a = ap.parse_args(argv)
    if a.cmd == "skeleton":
        print(skeleton(a.pack))
        return 0
    r = check(a.pack)
    print(json.dumps(r, indent=2, sort_keys=True))
    return 1 if r["problems"] else 0


if __name__ == "__main__":
    from console import use_utf8
    use_utf8()
    sys.exit(main())
