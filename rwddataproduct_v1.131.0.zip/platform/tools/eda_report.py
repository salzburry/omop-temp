#!/usr/bin/env python3
"""Layered EDA evidence for a pack's sources — counts a person reads before trusting an ADS.

    python3 platform/tools/eda_report.py <pack> --synthetic --out-dir <outside-checkout>

An external review named the gap: the profiler is univariate, so nothing established the facts
between tables — key integrity, patient overlap, join fan-out, date sanity — before a build ran.
This tool computes those as COUNTS, layer by layer, composing the evidence owners that already
exist (grain reports, stage/selection telemetry, the output contract) and adding the cross-table
aggregates nothing owned.

Layers:
  1 inventory       per role: rows, patients, null patient keys, column count
  2 grain_keys      the pack's declared grains checked against the rows (grain.py, composed)
  3 relationships   per role vs the index source: overlap, left/right-only, max fan-out
  4 temporal        per required date column: nulls, unparseable, before-1900, after study end
  5 funnel          per cohort: index patients and per-stage rows (stage telemetry, composed)
  6 ads_output      the output contract over a built ADS (output_contract, composed)

COUNTS ONLY. No patient id, no value, no date extremum enters the report — the same rule as
grain.py and telemetry.py, because this travels into evidence folders and chat. The tests assert
a known id cannot appear.

`--synthetic` runs the whole thing on the pack's synthetic fixtures — the SHAPE of the evidence,
for demos and tests; the numbers mean nothing. A governed run on delivered data is a human/RWDE
act on the cluster: import `eda()` from the runner there and write the report to the evidence
volume. The report is written OUTSIDE the checkout, refused inside, like every generated report.
"""
import argparse
import json
import os
import sys

TOOLS = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(os.path.dirname(TOOLS))
sys.path.insert(0, TOOLS)
sys.path.insert(0, os.path.join(ROOT, "platform"))
sys.path.insert(0, os.path.join(ROOT, "platform", "tests", "fixtures"))


def _inventory_and_temporal(F, df, required_cols, index_end):
    """One aggregation answering layers 1 and 4 for one frame. Returns (agg_exprs, decode)."""
    date_cols = [c for c in required_cols
                 if "date" in c.lower() and "granularity" not in c.lower()
                 and c in [x.lower() for x in df.columns]]
    exprs = [F.count(F.lit(1)).alias("_rows"),
             F.countDistinct("patientid").alias("_patients"),
             F.sum(F.when(F.col("patientid").isNull(), 1).otherwise(0)).alias("_null_pid")]
    for i, c in enumerate(date_cols):
        d = F.to_date(F.col(c))
        exprs += [F.sum(F.when(F.col(c).isNull(), 1).otherwise(0)).alias(f"_dn{i}"),
                  F.sum(F.when(F.col(c).isNotNull() & d.isNull(), 1).otherwise(0)).alias(f"_du{i}"),
                  F.sum(F.when(d < F.lit("1900-01-01").cast("date"), 1).otherwise(0)).alias(f"_db{i}"),
                  F.sum(F.when(d > F.lit(index_end).cast("date"), 1).otherwise(0)).alias(f"_da{i}")]
    return date_cols, exprs


def eda(spark, src, cfg, telemetry_report=None, ads=None):
    """The layered evidence dict. One aggregation per source frame; composition everywhere else."""
    from pyspark.sql import functions as F
    from engine import grain as _grain, validate as _validate
    from engine.output_contract import run_output_contract, output_contract_gate

    from engine.config import data_cutoff as _data_cutoff
    # The upper sanity bound is the DELIVERY'S CUT, not the enrollment close: a date after the
    # index window but before the cutoff is legitimate follow-up, not an impossible date. Falls
    # back to index_end until a pack states data_cutoff, so today's behaviour is unchanged.
    index_end = _data_cutoff(cfg.study)
    req = _validate.required_columns(cfg)
    idx_role = cfg.index_source
    idx_pat = src[idx_role].select("patientid").distinct() if idx_role in src else None

    inventory, temporal, relationships = {}, {}, {}
    for role in sorted(src):
        df = src[role]
        if "patientid" not in df.columns:
            inventory[role] = {"skipped": "no patientid column"}
            continue
        date_cols, exprs = _inventory_and_temporal(F, df, req.get(role) or [], index_end)
        r = df.agg(*exprs).collect()[0]
        inventory[role] = {"rows": int(r["_rows"]), "patients": int(r["_patients"]),
                           "null_patient_keys": int(r["_null_pid"]),
                           "columns": len(df.columns)}
        for i, c in enumerate(date_cols):
            temporal.setdefault(role, {})[c] = {
                "null": int(r[f"_dn{i}"]), "unparseable": int(r[f"_du{i}"]),
                "before_1900": int(r[f"_db{i}"]), "after_study_end": int(r[f"_da{i}"])}
        if idx_pat is not None and role != idx_role:
            per = df.groupBy("patientid").agg(F.count(F.lit(1)).alias("_n"))
            j = (idx_pat.withColumn("_ix", F.lit(1))
                 .join(per, "patientid", "full_outer")
                 .agg(F.count(F.when(F.col("_ix").isNotNull() & F.col("_n").isNotNull(), 1))
                      .alias("overlap"),
                      F.count(F.when(F.col("_ix").isNotNull() & F.col("_n").isNull(), 1))
                      .alias("index_only"),
                      F.count(F.when(F.col("_ix").isNull(), 1)).alias("source_only"),
                      F.coalesce(F.max("_n"), F.lit(0)).alias("max_rows_per_patient"))
                 .collect()[0])
            relationships[role] = {k: int(j[k]) for k in
                                   ("overlap", "index_only", "source_only",
                                    "max_rows_per_patient")}

    grain_keys = None
    if _validate.source_grain(cfg)[0]:
        rep = _grain.source_grain_report(F, src, cfg)
        grain_keys = dict(_grain.source_grain_gate(rep), report=rep)

    ads_output = None
    if ads is not None:
        oc = run_output_contract(spark, ads, cfg)
        ads_output = dict(output_contract_gate(oc), report=oc)

    doc = {"pack": cfg.data_product_id,
            # SELF-DECLARED, like the profiler's sidecar: counts derived from vendor data are
            # restricted output. No count here identifies a patient (test-asserted), but the
            # aggregates are still vendor-derived — AI-readable only after the human act the
            # classification rule requires, which no tool performs.
            "classification": {
                "state": "restricted_derived",
                "note": "counts-only EDA evidence derived from vendor data. A person reads it; "
                        "no gate scores it; nothing crosses to AI without a recorded human "
                        "review under the aggregation policy.",
            },
            "layers": {
                "inventory": inventory,
                "grain_keys": grain_keys or {"skipped": "no source_grain declared"},
                "relationships": relationships,
                "temporal": temporal,
                "funnel": (telemetry_report or {"skipped": "no stage telemetry supplied"}),
                "ads_output": ads_output or {"skipped": "no built ADS supplied"},
            }}
    # EDA-LITE: computed only when the pack declares limits — the evidence stays evidence, but
    # a declared acceptance contract gets held to (candidate_verdict reads it off the manifest).
    limits = (cfg.raw.get("qc") or {}).get("eda_acceptance")
    if limits:
        doc["acceptance"] = acceptance(doc, dict(limits))
    return doc


def acceptance(doc, limits):
    """EDA-LITE: the bounded acceptance GATE over the evidence layers. Pure data.

    The evidence stays evidence — a person reads the full report — but a pack that DECLARES
    `qc.eda_acceptance` limits gets held to them: this is the check most likely to catch a
    wrong-table or wrong-cut ingestion before it becomes a clinical question. Fail-closed
    grammar throughout: a layer that was not collected is UNCHECKED (visible), and in strict
    mode unchecked is failure — "not collected" must never read as "nothing wrong".

    limits (all optional except that an empty dict gates nothing and says so):
      required_roles:          roles that must appear in the inventory
      max_rows_per_patient:    {role: cap} over the relationships layer
      strict:                  true -> every UNCHECKED entry is a failure
    """
    ly = (doc or {}).get("layers") or {}
    failures, unchecked = [], []
    inv = ly.get("inventory") or {}
    for role in limits.get("required_roles") or []:
        if role not in inv:
            failures.append(f"required role `{role}` absent from the delivery inventory — "
                            f"the source this pack needs was not there to examine")
    for role, t in sorted((ly.get("temporal") or {}).items()):
        for col, counts in sorted((t or {}).items()):
            for k in ("unparseable", "before_1900", "after_study_end"):
                if (counts or {}).get(k):
                    failures.append(f"{role}.{col}: {counts[k]} {k} date(s)")
    caps = limits.get("max_rows_per_patient") or {}
    rel = ly.get("relationships") or {}
    for role, cap in sorted(caps.items()):
        r = rel.get(role)
        if r is None:
            unchecked.append(f"{role}: fan-out cap declared but the relationships layer "
                             f"carries no entry for it")
        elif (r.get("max_rows_per_patient") or 0) > cap:
            failures.append(f"{role}: {r['max_rows_per_patient']} rows for one patient exceeds "
                            f"the declared cap {cap} — a join explosion or a wrong-grain table")
    for name in ("grain_keys", "funnel", "ads_output"):
        blk = ly.get(name) or {}
        if "skipped" in blk:
            unchecked.append(f"{name}: {blk['skipped']}")
        elif blk.get("passed") is False:
            failures.append(f"{name}: its own gate records a failure")
    if limits.get("strict"):
        failures += [f"STRICT: unchecked is not clean — {u}" for u in unchecked]
        unchecked = [] if failures else unchecked
    if not limits or not any(k for k in limits if k != "strict"):
        unchecked.append("no acceptance limits declared — this gate examined nothing and "
                         "says so rather than passing")
    return {"passed": not failures, "failures": failures, "unchecked": unchecked}


def serialized(doc):
    """(canonical JSON bytes, sha256 hex) — ONE serialization, hashed from those exact bytes.

    The digest is what binds the artifact into the candidate manifest (`artifacts.eda_report`),
    which the Gate 6 approval signs — the same serialize-once discipline the runner's manifest
    uses, because a digest of bytes nobody wrote is a digest of nothing.
    """
    import hashlib
    raw = json.dumps(doc, indent=1, sort_keys=True).encode("utf-8")
    return raw, hashlib.sha256(raw).hexdigest()


def render(doc):
    L = [f"EDA EVIDENCE — {doc['pack']}", "counts only; a person reads this, no gate does", ""]
    ly = doc["layers"]
    L.append("LAYER 1+4 — inventory and temporal:")
    for role, inv in sorted(ly["inventory"].items()):
        L.append(f"  {role:<16} {json.dumps(inv)}")
        for c, t in sorted((ly["temporal"].get(role) or {}).items()):
            flag = " <-- LOOK" if t["unparseable"] or t["before_1900"] or t["after_study_end"] else ""
            L.append(f"      {c:<24} {json.dumps(t)}{flag}")
    L.append("LAYER 3 — relationships vs the index source:")
    for role, rel in sorted(ly["relationships"].items()):
        L.append(f"  {role:<16} {json.dumps(rel)}")
    for name in ("grain_keys", "funnel", "ads_output"):
        blk = ly[name]
        head = ("skipped: " + blk["skipped"]) if isinstance(blk, dict) and "skipped" in blk \
            else f"{len(json.dumps(blk))} bytes of composed evidence"
        L.append(f"LAYER {name}: {head}")
    return "\n".join(L)


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__.strip().splitlines()[0])
    ap.add_argument("pack")
    ap.add_argument("--synthetic", action="store_true", required=True,
                    help="run on the pack's synthetic fixtures — the SHAPE of the evidence. A "
                         "governed run on delivered data happens on the cluster, not here")
    ap.add_argument("--out-dir", required=True,
                    help="where the JSON+text report lands; refused inside the checkout")
    a = ap.parse_args(argv)
    out_dir = os.path.abspath(a.out_dir)
    if out_dir.startswith(os.path.abspath(ROOT)):
        sys.exit("REFUSED: --out-dir is inside the checkout; generated reports live outside it")
    import synthetic_sources
    from engine.config import load_config
    from engine import build_ads, telemetry
    cfg = load_config(os.path.join(a.pack, "config", "data_product.yaml"),
                      overrides={"run.refresh": "eda", "run.source_schema": "eda",
                                 "run.output_schema": "eda"})
    spark = synthetic_sources.session("eda")
    src = synthetic_sources.sources(spark, cfg)
    t = telemetry.StageTelemetry()
    ads = build_ads.build_from_sources(src, cfg, telemetry=t)
    doc = eda(spark, src, cfg, telemetry_report=t.report(), ads=ads)
    os.makedirs(out_dir, exist_ok=True)
    raw, digest = serialized(doc)
    with open(os.path.join(out_dir, "eda_report.json"), "wb") as fh:
        fh.write(raw)
    with open(os.path.join(out_dir, "eda_report.sha256"), "w", encoding="utf-8") as fh:
        fh.write(digest + "\n")
    text = render(doc)
    with open(os.path.join(out_dir, "eda_report.txt"), "w", encoding="utf-8") as fh:
        fh.write(text + "\n")
    print(text)
    print(f"\nwrote {out_dir}/eda_report.json (synthetic — the shape, not the facts)")
    return 0


if __name__ == "__main__":
    from console import use_utf8
    use_utf8()
    sys.exit(main())
