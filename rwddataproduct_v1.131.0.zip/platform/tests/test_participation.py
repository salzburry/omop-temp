"""The participation surfaces: publish, precheck, and the precedent metric — never an authority.

Phase-2 growth tooling: `publish_site.py` regenerates every read page into one hostable folder
where absence is content; `spec_precheck.py` is the author's courtesy check that blocks loudly
and approves nothing; `precedent_metric.py` counts CANDIDATE precedent matches and marks
nothing answered. The properties pinned here are the refusals and the labels — a published
page that accepted input, a precheck that read as an approval, or a metric that inherited an
answer on its own would each be a new authority nobody granted.

Run: python3 tests/test_participation.py (or pytest). Pure — no Spark.
"""
import json
import os
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

FRAMEWORK = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(FRAMEWORK / "tools"))
sys.path.insert(0, str(FRAMEWORK / "tests" / "fixtures"))

import precedent_metric as pm   # noqa: E402

try:
    import openpyxl  # noqa: F401
    HAVE_XL = True
except Exception:                                                        # noqa: BLE001
    HAVE_XL = False


def test_the_precheck_blocks_on_planted_hazards_and_owns_its_own_smallness():
    """On the adversarial melanoma fixture: exit 1, the impossible date named; and the output
    says what a clean run would NOT mean — a courtesy check, never an approval."""
    if not HAVE_XL:
        print("  (skipped: openpyxl absent)")
        return
    import tumor_tiers
    d = tempfile.mkdtemp()
    try:
        wb = tumor_tiers.build("mel", os.path.join(d, "m.xlsx"))
        r = subprocess.run([sys.executable, str(FRAMEWORK / "tools" / "spec_precheck.py"), wb],
                           capture_output=True, encoding="utf-8", timeout=300)
        assert r.returncode == 1, "planted hazards did not block"
        assert "IMPOSSIBLE_DATE" in r.stdout and "NOT READY" in r.stdout
        assert "courtesy check" in (r.stdout + r.stderr).lower() or "NOT READY" in r.stdout
        src = (FRAMEWORK / "tools" / "spec_precheck.py").read_text(encoding="utf-8")
        assert "registers nothing" in src and "not evidence" in src
    finally:
        shutil.rmtree(d, ignore_errors=True)


def test_the_metric_finds_candidates_and_marks_nothing_answered():
    """A resolved decision in one pack and a near-identical open question in another: the
    metric reports a CANDIDATE with its overlap and a question — and the registers' own
    statuses are untouched inputs, never outputs. No verdict words in any candidate."""
    regs = {
        "products/oncology/aaa/202606": {
            "FUED-DEF": {"question": "How is end-of-follow-up defined (activity sources, "
                                     "death cap, study-end cap)?",
                         "status": "RESOLVED", "answer": "min(death, study end, last activity)"},
        },
        "products/oncology/bbb/202606": {
            "FU-END": {"question": "How is end of follow-up defined — which activity sources "
                                   "and death cap apply?", "status": "OPEN", "answer": ""},
            "OTHER": {"question": "Which biomarker window applies to HRR testing?",
                      "status": "OPEN", "answer": ""},
        },
    }
    rep = pm.metric(registers=regs)
    bbb = next(r for r in rep if r["pack"].endswith("bbb/202606"))
    assert bbb["with_precedent_candidates"] == 1, bbb
    assert bbb["candidate_coverage"] == 0.5
    c = bbb["candidates"][0]
    assert c["candidate"] == "FUED-DEF" and "?" in c["question"]
    assert "person reads both" in c["question"]
    flat = json.dumps(rep)
    assert not any(w in flat for w in ("approved", "verified", "inherited automatically"))
    aaa = next(r for r in rep if r["pack"].endswith("aaa/202606"))
    assert aaa["resolved"] == 1, "the metric altered or miscounted an input status"


def test_the_metric_runs_on_the_real_tree_and_reports_the_live_registers():
    rep = pm.metric()
    packs = {r["pack"]: r for r in rep}
    pro = next(v for k, v in packs.items() if "prostate" in k)
    assert pro["decisions"] >= 20 and pro["open"] >= 15, pro
    for r in rep:
        if r["candidate_coverage"] is not None:
            assert 0 <= r["candidate_coverage"] <= 1


def test_the_published_site_lists_pages_and_absences_and_refuses_the_checkout():
    """Publish only the executive page (fast path): the index links what exists, names what
    could not generate, carries the commit, and states the no-input doctrine. And the site
    refuses to be written inside the repository."""
    import publish_site as ps
    d = tempfile.mkdtemp()
    try:
        r = ps.build(os.path.join(d, "site"), only=set())
        idx = Path(d, "site", "index.html").read_text(encoding="utf-8")
        assert "executive.html" in r["pages"] and "executive.html" in idx
        assert r["commit"] and r["commit"] in idx
        assert "Nothing here accepts input" in idx
        assert "approvals are committed file edits by named people" in idx
    finally:
        shutil.rmtree(d, ignore_errors=True)
    proc = subprocess.run([sys.executable, str(FRAMEWORK / "tools" / "publish_site.py"),
                           "--out", str(FRAMEWORK / "inside")],
                          capture_output=True, encoding="utf-8", timeout=120)
    assert proc.returncode != 0 and "inside the checkout" in (proc.stdout + proc.stderr)


def test_eda_lite_gates_declared_limits_and_never_reads_absence_as_clean():
    """The acceptance gate over a hand-built evidence doc: a missing required role, a bad date
    count and a fan-out over cap each fail; skipped layers are UNCHECKED (visible), strict
    turns unchecked into failure, and an empty limits dict gates nothing AND says so."""
    import eda_report as er
    doc = {"layers": {
        "inventory": {"drug_episode": {"rows": 10}},
        "temporal": {"drug_episode": {"startdate": {"unparseable": 0, "before_1900": 2,
                                                    "after_study_end": 0}}},
        "relationships": {"drug_episode": {"overlap": 9, "max_rows_per_patient": 40}},
        "grain_keys": {"skipped": "no source_grain declared"},
        "funnel": {"skipped": "no stage telemetry supplied"},
        "ads_output": {"passed": False},
    }}
    limits = {"required_roles": ["drug_episode", "mortality"],
              "max_rows_per_patient": {"drug_episode": 25}}
    a = er.acceptance(doc, limits)
    assert a["passed"] is False
    assert any("mortality" in f for f in a["failures"])
    assert any("before_1900" in f for f in a["failures"])
    assert any("exceeds" in f for f in a["failures"])
    assert any("ads_output" in f for f in a["failures"])
    assert any("grain_keys" in u for u in a["unchecked"])
    strict = er.acceptance(doc, dict(limits, strict=True))
    assert any("unchecked is not clean" in f for f in strict["failures"])
    # a layer's own recorded failure gates even with no limits declared (more fail-closed than
    # designed, kept deliberately); with clean layers, empty limits pass AND say they gated
    # nothing rather than reading as a clean bill
    clean = {"layers": dict(doc["layers"], ads_output={"skipped": "no built ADS supplied"},
                            temporal={})}
    empty = er.acceptance(clean, {})
    assert empty["passed"] and any("examined nothing" in u for u in empty["unchecked"])
    src = (FRAMEWORK / "engine" / "refresh.py").read_text(encoding="utf-8")
    assert '"eda_acceptance"' in src and '"EDA acceptance"' in src, \
        "the acceptance block fell out of the manifest or the candidate verdict"


def test_the_review_workbook_round_trips_by_binding_and_refuses_drift():
    """Build from the real prostate extraction, fill two rows, read back: the owned decision
    returns, the unowned one is a PROBLEM beside it (never silently dropped), a tampered
    provenance fingerprint refuses the whole round trip, and an invented item_id cannot bind."""
    if not HAVE_XL:
        print("  (skipped: openpyxl absent)")
        return
    import review_workbook as rw
    from openpyxl import load_workbook
    pack = "products/oncology/prostate/202606"
    d = tempfile.mkdtemp()
    try:
        p = os.path.join(d, "review.xlsx")
        info = rw.build(pack, p)
        assert info["rows"] >= 150 and info["findings"] > 0
        wb = load_workbook(p)
        ws = wb[[n for n in wb.sheetnames if n not in ("Provenance", "Findings")][0]]
        cols = {str(c.value): i + 1 for i, c in enumerate(ws[1])}
        ws.cell(row=2, column=cols["reviewer_decision"], value="ACCEPT")
        ws.cell(row=2, column=cols["reviewed_by"], value="T. Test")
        ws.cell(row=2, column=cols["reviewed_date"], value="2026-08-19")
        ws.cell(row=3, column=cols["reviewer_decision"], value="REVISE")   # unowned
        ws.cell(row=4, column=cols["item_id"], value="invented:99")
        ws.cell(row=4, column=cols["reviewer_decision"], value="ACCEPT")
        wb.save(p)
        r = rw.read(p, pack)
        assert len(r["decisions"]) == 1 and r["decisions"][0]["decision"] == "ACCEPT"
        assert any("unowned" in pr for pr in r["problems"]), r["problems"]
        assert any("invented:99" in pr for pr in r["problems"]), r["problems"]
        assert "transport only" in r["note"]
        wb = load_workbook(p)
        for row in wb["Provenance"].iter_rows(max_col=2):
            if str(row[0].value) == "extraction_fingerprint":
                row[1].value = "0" * 16
        wb.save(p)
        try:
            rw.read(p, pack)
            raise AssertionError("a drifted fingerprint round-tripped")
        except SystemExit as e:
            assert "moved under the review" in str(e)
    finally:
        shutil.rmtree(d, ignore_errors=True)


def test_the_adapter_contract_derives_covers_and_refuses():
    """The typed source-adapter IR: the skeleton derives real roles, stems and stage-read
    columns from the live pack; a committed file with an uncovered required role, a TODO type,
    an invented cardinality, a grain disagreement or a team-signed review is refused by name;
    no file is a stated absence — and a checked adapter set surfaces in the semantic view as a
    second implementation, which is what activates the equivalence axis."""
    import semantic_view as sv
    import source_adapter as sa
    pack = "products/oncology/prostate/202606"
    sk = sa.skeleton(pack)
    assert "logical_role: drug_episode" in sk and "physical_table: " in sk
    assert "TODO" in sk and "review: {status: pending" in sk
    r = sa.check(pack)
    assert r["state"] == "no_claim"
    d = tempfile.mkdtemp()
    try:
        fix = Path(d) / "pack"
        real = Path(pack)
        (fix / "config").mkdir(parents=True)
        for f in ("data_product.yaml",):
            (fix / "config" / f).write_text((real / "config" / f).read_text(encoding="utf-8"),
                                            encoding="utf-8")
        for sub in ("variables", "codelists"):
            (fix / sub).mkdir()
            for p in (real / sub).glob("*.yaml"):
                (fix / sub / p.name).write_text(p.read_text(encoding="utf-8"),
                                                encoding="utf-8")
        (fix / "config" / "source_adapters.yaml").write_text(
            "dataset: optum_mc\nadapters:\n"
            "  - logical_role: drug_episode\n"
            "    physical_table: mc.rx_claims\n"
            "    required_columns:\n"
            "      patientid: {physical: PatId, logical_type: string, "
            "accepted_physical_types: [string], parser: null}\n"
            "    grain: [patientid]\n"
            "    join: {to: index, keys: [patientid], cardinality: sounds_right}\n"
            "    review: {status: reviewed, approved_by: RWDE, approval_date: TBD}\n",
            encoding="utf-8")
        r = sa.check(str(fix))
        assert r["state"] == "checked"
        text = json.dumps(r["problems"])
        assert "omit stage-read column" in text, text
        assert "sounds_right" in text, text
        assert "team" in text, text
        assert "TBD" in text or "approval_date" in text, text
        assert any("no adapter" in p for p in r["problems"]), r["problems"]
    finally:
        shutil.rmtree(d, ignore_errors=True)
    impls = sv.implementations(pack)
    assert list(impls) == ["flatiron"], "no adapter file yet — one implementation, honestly"


if __name__ == "__main__":
    bad = 0
    for name, fn in sorted(globals().items()):
        if name.startswith("test_") and callable(fn):
            try:
                fn()
                print(f"  ok  {name}")
            except Exception as e:                   # noqa: BLE001 - report and continue
                bad += 1
                print(f"FAIL  {name}: {e}")
    sys.exit(1 if bad else 0)
