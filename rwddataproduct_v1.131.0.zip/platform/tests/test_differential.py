"""Did the SAME patients get the SAME values?

`golden.py` compares aggregates, and every aggregate it computes is invariant under a permutation
of patients. The headline test below builds two ADSs with byte-identical distributions, identical
row counts and identical cohort counts, in which forty patients have had their values SWAPPED — and
proves the existing comparator sees nothing while the differential names it.

The other properties, each guarding a way this could quietly stop working:

  * A FULL KEY OR NOTHING. With a partial key the join pairs one patient's row against another's
    and reports the difference as a change. That is refused, not approximated.
  * NULL-SAFE EQUALITY. Without `<=>` every null-to-null pair counts as a change, and the report
    becomes noise nobody reads.
  * PRESENCE IS A MARKER, NOT A COALESCE. A patient whose every compared value is null is still a
    patient in that build.
  * PERCENTAGE POINTS, PER COHORT. A level that moves within one cohort and back in another is
    invisible pooled, and a count delta moves with the denominator.
  * TRUNCATION IS DECLARED. "the top 25 transitions" and "all of them" are different claims.

Run: python3 platform/tests/test_differential.py  (or pytest). Spark-only where marked.
"""
import sys
from pathlib import Path

FRAMEWORK = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(FRAMEWORK))

from engine import differential as dif, golden                 # noqa: E402
from engine.output_contract import OUTPUT_KEY                  # noqa: E402

try:
    from pyspark.sql import SparkSession
except Exception:
    SparkSession = None

try:
    import pytest
    pytestmark = pytest.mark.skipif(SparkSession is None, reason="pyspark not installed")
except Exception:
    pytest = None

_SPARK = None


def _spark():
    """The shared session — a second builder hands its settings to every later Spark suite."""
    global _SPARK
    if _SPARK is None:
        sys.path.insert(0, str(FRAMEWORK / "tests" / "fixtures"))
        import synthetic_sources
        _SPARK = synthetic_sources.session("differential")
    return _SPARK


SCHEMA = "patientid string, cohortn int, index_date string, cohort string, ecog string, os double"


def _df(rows):
    return _spark().createDataFrame(rows, SCHEMA)


def _row(pid, ecog, coh="A", cn=1, os=10.0):
    return (pid, cn, "2020-01-01", coh, ecog, os)


def test_the_pair_key_is_the_output_key_and_not_a_second_definition():
    """Two definitions of "the same patient" would eventually disagree, and the disagreement would
    decide which rows count as paired — silently."""
    assert dif.PAIR_KEY is OUTPUT_KEY
    assert dif.differential_spec(None)["key"] == list(OUTPUT_KEY)


def test_a_partial_key_is_refused_rather_than_approximated():
    """Pairing on part of the key pairs DIFFERENT patients and calls the difference a change."""
    rep = {"skipped": {"pairing": "the output key ... is not present on both tables"}}
    g = dif.differential_gate(rep)
    assert g["passed"] is False and "output key" in g["failures"][0]


def test_a_change_fails_unless_the_ledger_names_it_with_structure():
    """A refresh is supposed to change things, so the ledger exists — but the default is refusal,
    and an approval is BOUNDED or it is not an approval: a bare column name (which approved any
    change forever) is refused, a structured entry with reason/approver/date/expiry approves,
    an entry missing its bounds is refused, and an expired approval stops approving."""
    rep = {"paired": {"matched": 100, "only_new": 0, "only_ref": 0},
           "changed": {"ecog": 7}, "matched_rows": 100}
    assert dif.differential_gate(rep, {})["passed"] is False
    g = dif.differential_gate(rep, {"approved_deltas": ["ecog"]})
    assert g["passed"] is False and any("bare name" in f for f in g["failures"]), g
    entry = {"column": "ecog", "reason": "new baseline window per RWB answer",
             "approved_by": "T. Test", "approval_date": "2026-08-01", "expires": "2027-08-01",
             "max_changed_rows": 10}
    g = dif.differential_gate(rep, {"approved_deltas": [entry], "as_of": "2026-08-19"})
    assert g["passed"] is True, g
    unbounded = {k: v for k, v in entry.items() if k != "max_changed_rows"}
    g = dif.differential_gate(rep, {"approved_deltas": [unbounded], "as_of": "2026-08-19"})
    assert g["passed"] is False and any("no magnitude" in f for f in g["failures"]), g
    g = dif.differential_gate(rep, {"approved_deltas": [dict(entry, max_changed_rows=3)],
                                    "as_of": "2026-08-19"})
    assert g["passed"] is False and any("exceeds the approved ceiling" in f
                                        for f in g["failures"]), g
    g = dif.differential_gate(rep, {"approved_deltas": [dict(entry, reason="")],
                                    "as_of": "2026-08-19"})
    assert g["passed"] is False and any("unstated" in f for f in g["failures"]), g
    g = dif.differential_gate(rep, {"approved_deltas": [dict(entry, expires="2026-01-01")],
                                    "as_of": "2026-08-19"})
    assert g["passed"] is False and any("expired" in f for f in g["failures"]), g


def test_the_ledger_is_read_and_never_written():
    """The rule approval_baseline.yaml carries: a judge that can write its own exemption list is a
    check that can green itself."""
    import ast
    tree = ast.parse((FRAMEWORK / "engine" / "differential.py").read_text(encoding="utf-8"))
    for node in ast.walk(tree):
        if isinstance(node, ast.Call):
            name = getattr(node.func, "id", "") or getattr(node.func, "attr", "")
            assert name not in ("safe_dump", "dump", "write_text", "writelines", "mkdir",
                                "makedirs", "remove", "rename", "rmtree"), f"{name}() writes"


# --------------------------------------------------------------------------- Spark


def test_identical_aggregates_can_hide_swapped_patients():
    """THE HEADLINE, and the whole reason this module exists.

    Two builds, forty patients. In the new one, twenty patients with ECOG '0' and twenty with '2'
    have had their values exchanged. Row count identical. Cohort counts identical. The ECOG
    DISTRIBUTION is byte-identical — twenty of each, both sides. `golden.run_golden`'s summary is
    therefore clean, and forty patients carry the wrong value.
    """
    ref_rows = [_row(f"p{i}", "0") for i in range(20)] + [_row(f"q{i}", "2") for i in range(20)]
    new_rows = [_row(f"p{i}", "2") for i in range(20)] + [_row(f"q{i}", "0") for i in range(20)]
    ref, new = _df(ref_rows), _df(new_rows)

    # 1. The aggregate comparator sees nothing — asserted, not assumed.
    from pyspark.sql import functions as F
    nd = {r["ecog"]: r["n"] for r in new.groupBy("ecog").agg(F.count(F.lit(1)).alias("n")).collect()}
    rd = {r["ecog"]: r["n"] for r in ref.groupBy("ecog").agg(F.count(F.lit(1)).alias("n")).collect()}
    assert nd == rd, (nd, rd)
    assert all(v["delta"] == 0 for v in golden.summarise_diff(nd, rd).values()), "premise is wrong"
    assert new.count() == ref.count()

    # 2. The differential names it.
    rep = dif.run_differential(_spark(), new, ref, None)
    assert rep["paired"] == {"matched": 40, "only_new": 0, "only_ref": 0}, rep["paired"]
    assert rep["changed"].get("ecog") == 40, rep["changed"]
    g = dif.differential_gate(rep, dif.differential_spec(None))
    assert g["passed"] is False
    assert "40 paired patient(s) hold a different value" in " ".join(g["unapproved"])


def test_inclusion_and_exclusion_flips_survive_a_matching_row_total():
    """Two in, two out. The row count delta is zero and the cohort counts reconcile."""
    ref = _df([_row("a", "0"), _row("b", "0"), _row("c", "1"), _row("d", "1")])
    new = _df([_row("a", "0"), _row("b", "0"), _row("e", "1"), _row("f", "1")])
    assert new.count() == ref.count(), "premise: the totals match"
    rep = dif.run_differential(_spark(), new, ref, None)
    assert rep["paired"] == {"matched": 2, "only_new": 2, "only_ref": 2}, rep["paired"]
    g = dif.differential_gate(rep, dif.differential_spec(None))
    assert g["passed"] is False
    joined = " ".join(g["failures"])
    assert "exclusion flip" in joined and "inclusion flip" in joined


def test_null_to_null_is_not_a_change_and_a_null_shift_is():
    """Without null-safe equality every null pair counts as a change and the report is noise. But a
    column whose null RATE moves is a real finding: those rows left the distribution rather than
    moving within it, so no category count changes at all."""
    ref = _df([_row("a", None), _row("b", "1"), _row("c", "1")])
    new = _df([_row("a", None), _row("b", "1"), _row("c", None)])
    rep = dif.run_differential(_spark(), new, ref, None)
    assert rep["changed"].get("ecog") == 1, rep["changed"]        # only c, not a
    nr = rep["null_rate"]["ecog"]
    assert nr["ref"] < nr["new"] and nr["delta"] > 0, nr
    assert any("null rate moved" in u for u in
               dif.differential_gate(rep, dif.differential_spec(None))["unapproved"])


def test_a_patient_whose_every_value_is_null_is_still_present_in_that_build():
    """Presence is a marker column. Inferring it from the values would report a patient the build
    contains as absent from it."""
    ref = _df([_row("a", "1", os=1.0)])
    new = _df([_row("a", None, os=None), _row("z", None, os=None)])
    rep = dif.run_differential(_spark(), new, ref, None)
    assert rep["paired"] == {"matched": 1, "only_new": 1, "only_ref": 0}, rep["paired"]


def test_transitions_say_where_the_patients_went_and_declare_truncation():
    ref = _df([_row(f"p{i}", "0") for i in range(5)] + [_row("q", "1")])
    new = _df([_row(f"p{i}", "2") for i in range(5)] + [_row("q", "1")])
    t = dif.transitions(_spark(), new, ref, "ecog")
    assert t["transitions"] == {"0 -> 2": 5}, t
    assert t["truncated"] is False
    assert dif.transitions(_spark(), new, ref, "ecog", limit=0)["truncated"] is True


def test_percentage_points_are_per_cohort_and_a_new_level_is_named():
    """Pooled, a shift in one cohort cancelled by the opposite shift in another is invisible."""
    ref = _df([_row("a", "0", coh="A"), _row("b", "1", coh="A"),
               _row("c", "0", coh="B"), _row("d", "1", coh="B")])
    new = _df([_row("a", "0", coh="A"), _row("b", "0", coh="A"),
               _row("c", "1", coh="B"), _row("d", "9", coh="B")])
    out = dif.cohort_percentage_points(_spark(), new, ref, "ecog")["by_cohort"]
    assert out["A"]["0"]["delta_pp"] == 50.0, out["A"]
    assert out["A"]["1"]["delta_pp"] == -50.0, out["A"]
    assert out["B"]["9"]["new_level"] is True, out["B"]
    assert out["B"]["0"]["dropped_level"] is True, out["B"]


def test_a_clean_rebuild_passes():
    """The control. Without it every assertion here could be met by a gate that always fails."""
    rows = [_row("a", "0"), _row("b", "1")]
    rep = dif.run_differential(_spark(), _df(rows), _df(rows), None)
    assert rep["paired"] == {"matched": 2, "only_new": 0, "only_ref": 0}
    assert rep.get("changed") == {}, rep.get("changed")
    assert dif.differential_gate(rep, dif.differential_spec(None))["passed"] is True


SPARK_TESTS = (
    "test_identical_aggregates_can_hide_swapped_patients",
    "test_inclusion_and_exclusion_flips_survive_a_matching_row_total",
    "test_null_to_null_is_not_a_change_and_a_null_shift_is",
    "test_a_patient_whose_every_value_is_null_is_still_present_in_that_build",
    "test_transitions_say_where_the_patients_went_and_declare_truncation",
    "test_percentage_points_are_per_cohort_and_a_new_level_is_named",
    "test_a_clean_rebuild_passes",
)

if __name__ == "__main__":
    fns = [(k, v) for k, v in sorted(globals().items()) if k.startswith("test_")]
    assert {n for n, _ in fns} >= set(SPARK_TESTS), "SPARK_TESTS names a test that no longer exists"
    ran = skipped = 0
    for name, fn in fns:
        if name in SPARK_TESTS and SparkSession is None:
            print(f"SKIP {name}: pyspark not installed")
            skipped += 1
            continue
        fn()
        ran += 1
        print(f"ok  {name}")
    print(f"\n{ran} tests passed, {skipped} skipped")
