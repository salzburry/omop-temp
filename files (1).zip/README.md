# RWP-Oncology on Azure DevOps

Eight files.

| File | What |
|---|---|
| `README.md` | This — decisions, what changed, what is open |
| `implementation-runbook.md` | **Step by step. Start here when you sit down to build it.** |
| `ado-structure.md` | Area paths, stages, hierarchy, queries |
| `setup-guide.md` | Fields, permissions, import steps, the demo |
| `1_Features_import.csv` | 17 Features. Import first. |
| `2_Stories_import.csv` | 41 Stories under 8 Features. **Needs Feature IDs pasted in.** |
| `2b_Stories_stage-map.csv` | Lookup — stage per Story. **Not importable**; join to a Story export by Title. |
| `3_migration-state-map.csv` | Control file — State and stage per Feature. **Not importable.** |

---

## Read this before importing

**The Story file will not work as shipped.** Its 8 parent rows carry `<FEATURE_ID>` where
the real Feature ID must go.

Two failure modes. A literal `<FEATURE_ID>` is invalid and should fail validation — that
blocks the import, which is the easy case. A **blank** parent ID makes ADO treat the row as
a new item and create a duplicate Feature, which needs cleanup afterwards.

After importing Features: export them, paste each numeric ID into the matching parent row,
then import Stories.

**Area Path is project-specific.** Both CSVs carry `RWP-Oncology\Data Products`. For the
sandbox, take copies and replace it with `<SandboxProject>\Data Products` — and create that
area node in the sandbox first. Keep the originals untouched for production.

**IDs are environment-specific.** Sandbox Feature and Story IDs are meaningless in
production. After the sandbox test, go back to the `<FEATURE_ID>` template and rebuild every
ID-based file from the production exports.

**Two files are control files, not imports.** `3_migration-state-map.csv` and
`2b_Stories_stage-map.csv` both lack an `ID` column. The first is applied by bulk-editing
three State groups in the UI; the second by exporting the Stories, joining on Title, and
importing the resulting ID-based update.

---

## Decisions settled

**Naming** — RWDP (Real World Data Product) throughout.

**Two lifecycles, one field.** `Current Stage` holds every value from both sequences, so
queries and charts read a single column.

| | Sequence |
|---|---|
| RWDP | Methodology Doc → Prog Spec → Prog Spec QC → Programming → Program Validation → Release Preparation → Released |
| RWDP, no logic change | Program Execution → Program Validation → Release Preparation → Released |
| Dashboard | Requirements → Design → Build → UAT → Release Preparation → Released |
| Dashboard, build-only change | Build → UAT → Release Preparation → Released |

Protocol and RDQ sequences are **proposed for wave two**, subject to confirmation with
their owners — see `ado-structure.md`.


**Release Preparation is real work.** Validation completes, RWP or RWB signs off QC, RWDE
performs the release. Current Owner moves to RWDE.

**Results Disseminated is terminal.** Results go to stakeholders for abstract or
publication; RWP's role ends. State = Closed.

**Every RWDP that goes through specification and programming carries both QC gates** — Prog
Spec QC and Program Validation — regardless of how the old tracker recorded it. A no-logic-change
rerun skips the specification gates but still goes through Program Validation.

**Current Stage imports blank on all 17 Features.** Set manually in ADO. `3_migration-state-map.csv`
says which State each Feature should carry.

**Story points, not hours.** People work across three or four things at once.

**Migration Baseline** — a Boolean on User Story, default `False`. `True` marks Stories
whose timestamps come from cutover rather than real work: every stage completed before
cutover, *and* the stage underway at cutover. Excluded from cycle time. Reliable data
begins with the first stage that starts after go-live.

**Health kept**, definitions in `setup-guide.md`.

---

## What changed from the last package

**Duplicate Features — the one that mattered.** The Story CSV had 17 parent rows with no
ID column. ADO would have created a second copy of every Feature. Now: 8 parent rows with
an ID placeholder, and only Features that actually have Stories.

**Fewer Stories, 54 → 41.** Removed from DLBCL COTA RWDP and Prostate Panoramic Dashboard —
both have unresolved completed status, and generating a stage history for something that
already shipped is the exact fabrication this package avoids elsewhere.

**Dashboard Enhancement path fixed.** It was getting Requirements and Design despite being
a implementation-only change. Now Build → UAT → Release Preparation.

**Active Pipeline query rebuilt.** It filtered on `Current Stage <> Released`, but every
stage imports blank — so it would have returned all 17 including the released ones. Now
filters on `State <> Closed`. State answers *open or done*; Current Stage answers *where*.

**Resources query rebuilt.** Was `State <> Closed`, which counts every future stage Story
as current workload — six per product, mostly not started. Now `State = Active`.

**Explicit State map.** `3_migration-state-map.csv` names each Feature, its State, and its
terminal stage. It is a control file — not importable, since it has no ID column.

**Closed Features get a stage too.** Previously only the 8 active ones were to be
populated, leaving the 6 released at blank — which shows no terminal stage in Completed
Deliverables and trips reconciliation on every historical release. They read `Released`.

**Reconciliation queries scoped to Feature.** `State = Closed AND Current Stage <> Released`
flagged every correctly closed stage Story. Now `Work Item Type = Feature`, with
`Results Disseminated` as a valid terminal.

**Stage values split out of the hierarchy import.** Parent rows are updates to existing
Features, and a blank `Current Stage` column could overwrite the value set in the prior
step. Stage now lives in `2b_Stories_stage-map.csv`, applied after Stories exist.

**Cycle Time claim corrected.** The widget filters by a field; it does not group by one.
One widget per stage, or Analytics for comparison.

**`Repeat - implementation-only change` renamed to `Repeat - implementation-only change`** — the
old label was RWDP terminology applied to dashboard build work.

**Release Preparation boundary defined.** Program Validation ends with RWP/RWB signoff;
Release Preparation begins at handoff to RWDE and is RWDE-owned throughout. Ownership no
longer changes partway through a stage.

**Boolean values are `True`/`False`**, not Yes/No — that is how ADO stores and queries them.

**Queries hardened** — `State NOT IN (Closed, Removed)` rather than `<> Closed`, Blocked
scoped to Feature, and a Story-stage completeness query added to catch a partial update pass.

**Sandbox clarified.** A sandbox sharing your production inherited process isolates
nothing. Create a separate inherited process, apply it only to the sandbox, then apply it
to RWP-Oncology once validated.

---

## Open

| Item | Note |
|---|---|
| mCRC RWDP 2026 Refresh | Delivery path unknown — no Stories generated |
| DLBCL COTA RWDP | Shipped or not? No Stories until confirmed |
| Prostate Panoramic Dashboard | Same |
| advNSCLC Dashboard, DLBCL COTA Dashboard | Stage unknown. **Blocks the Story state pass** — without knowing the current stage there is no way to tell which child Story is prior, current, or future. Confirm before importing their Stories. |
| RWD Dashboard Enhancement | Title generic; name the specific dashboard |
| Owners and target dates | Blank on all 17 |
| Actual Release Date | Not added. `Closed Date` on migrated records will be the cutover date. |
| Health definitions | Need agreeing with the team |
| Protocol and RDQ sequences | Proposed, not confirmed with their owners |

