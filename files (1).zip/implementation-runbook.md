# Implementation runbook

Two passes: sandbox to validate, production to build. Nothing ID-based carries between them.

---

# PASS 1 — Sandbox

## A. Create the process

**Organization settings → Process** → Agile → right-click → **Create inherited process**.
Name it something like `RWP Data Product Process`.

Do not apply it to RWP-Oncology yet.

## B. Create the sandbox project

**Organization settings → Projects → New project.** Name it `RWP-Sandbox`. Under Advanced,
set Work item process to the inherited process from step A.

This is why a separate process matters: sharing your production process would push every
field change into every project using it, immediately.

## C. Add the fields

Organization settings → Process → your process → **Feature** → New field.

| Field | Type | Values |
|---|---|---|
| Product | Text | |
| Product Type | Picklist | RWDP, Dashboard |
| Release Type | Picklist | Initial Release, Data Refresh, Enhancement |
| Release Label | Text | |
| Delivery Path | Picklist | New product · Repeat - methodology change · Repeat - specification change · Repeat - implementation-only change · Repeat - no logic change |
| Current Stage | Picklist | Planned · Methodology Doc · Prog Spec · Prog Spec QC · Programming · Program Execution · Requirements · Design · Build · UAT · Program Validation · Release Preparation · Released · Results Disseminated · On Hold |
| Current Owner | Picklist | RWP, RWDE, RWB |
| Health | Picklist | On Track, At Risk, Blocked |

Then **User Story** → New field → **Use an existing field** → `Current Stage`. On the Story
form, set the label to `Delivery Stage`. Same underlying field, so queries still work.

Also on User Story: add `Migration Baseline` as Boolean, default False. Confirm
`Story Points`, `Start Date`, and `Target Date` are on the form — add them if not.

## D. Create the area path

Project Settings → Project configuration → Areas → New child → `Data Products`.

## E. Prepare sandbox copies of the CSVs

Copy `1_Features_import.csv` and `2_Stories_import.csv`. In the copies, find and replace:

```
RWP-Oncology\Data Products   →   RWP-Sandbox\Data Products
```

Area Paths are project-specific. The production path is not a valid node in the sandbox and
every row will fail.

## F. Validate the headers

Create one Feature manually, filling every field. Boards → Work Items → select it →
**Export to CSV**. Compare its headers against your CSV. Fix any mismatch — ADO rejects
unmatched field names rather than ignoring them.

Do the same for one User Story.

## G. Import Features

Boards → Work Items → **Import Work Items** → the sandbox Feature copy → Import → **Save**.

17 Features, all at State `New`, all with blank Current Stage.

## H. Feature State and stage

Select the 6 released Features → right-click → Edit → State = Closed, Current Stage = Released.
Then the 8 active ones → State = Active. Leave the 3 unresolved at New with blank stage.

`3_migration-state-map.csv` says which is which. It is a control file — no ID column, not
importable.

**Set Current Stage on the 8 active Features now.** The Story state pass depends on knowing
which child Story is prior, current, or future.

## I. Story hierarchy

Export the Features. Copy each numeric ID into the matching parent row of your sandbox Story
copy, replacing `<FEATURE_ID>`.

- Literal placeholder left in → invalid ID, import should fail
- Parent ID left blank → ADO creates a duplicate Feature and hangs the Stories off it
- Correct numeric ID → Stories link to the existing Feature

Import → Save. 8 parent rows update, 41 Stories are created.

## J. Story stages

Export the 41 Stories with ID, Work Item Type, Title. Join `2b_Stories_stage-map.csv` on
Title — all 41 are unique and match exactly. Build:

```
ID,Work Item Type,Title,Current Stage
12345,User Story,Prostate Panoramic RWDP - Initial - Methodology Doc,Methodology Doc
```

Import that.

Stage was kept out of the hierarchy file deliberately — its parent rows are updates to
existing Features, and a blank stage column there could wipe what you set in step H.

## K. Story State and baseline

Per Feature, based on its current stage:

| Story | State | Migration Baseline |
|---|---|---|
| Stages already finished | Closed | True |
| Stage underway now | Active | True |
| Later stages | New | False |

Both the finished stages and the current one are baseline. If Programming first goes Active
today, ADO clocks its cycle time from today — as fabricated as the closed ones. Real data
starts with whatever stage begins after go-live.

## L. Check it worked

Run the reconciliation and completeness queries. Look for: a Closed Feature with no terminal
stage, a Story with no stage, an RWDP sitting at UAT.

If the sandbox is clean, the CSVs are validated.

---

# PASS 2 — Production

## M. Apply the process

Organization settings → Process → your process → **Projects** tab → apply to RWP-Oncology.
Confirm no other project picks it up.

## N. Area path and permissions

Project Settings → Project configuration → Areas → `Data Products`.

Then Security on that node:

- RWP editors — View Allow, Edit Allow
- Stakeholder readers — View Allow, Edit **Deny**

Creating the node does not make anyone read-only. Contributors edit by default, and Deny
beats inherited Allow.

**Verify with a real account from each group**, not the settings page. If Tech should
comment without editing, that is a separate work-item comment permission.

## O. Repeat G through L with the master files

Use the originals — `RWP-Oncology\Data Products` is correct here.

**Start from the `<FEATURE_ID>` template again.** Sandbox IDs are meaningless in production.
Rebuild the parent IDs and the stage update from production exports.

## P. Queries

Save under **Shared Queries**:

| Query | Filter |
|---|---|
| Active pipeline | Feature · State NOT IN (Closed, Removed) |
| Completed deliverables | Feature · State = Closed |
| Resources | User Story · State = Active |
| Planned work | User Story · State = New |
| Completed stages | User Story · State = Closed |
| Needs staffing | User Story · Assigned To blank · Target Date <= @Today+14 · State NOT IN (Closed, Removed) |
| Blocked | Feature · Health = Blocked |
| Overdue | Feature · Target Date < @Today · State NOT IN (Closed, Removed) |

Plus the reconciliation and completeness queries in `ado-structure.md`.

Add `Current Stage` to displayed columns before charting — a chart cannot group on a field
the query does not show.

## Q. Dashboard

New team dashboard. Add query chart widgets for Active Pipeline and Completed Deliverables.
Stakeholder users cannot open charts from the Queries page but can see them here.

Cycle Time widget: scope to User Story, filter `Migration Baseline = False`. One widget per
stage — it filters by a field, it does not group by one.

**Do not sort Completed Deliverables by Closed Date.** All six migrated Features carry the
cutover date and would read as shipping the same day.

## R. Populate

- Current Owner on the 8 active Features
- Target Date where a forecast is agreed — leave blank otherwise
- Assigned To, Story Points, dates on the Stories
- Health, once the team agrees the definitions

---

# Blocking before you start

**Two Features have unknown stages** — DLBCL COTA Dashboard and advNSCLC Dashboard. Without
those, step K cannot run on their 10 Stories. Either confirm the stages, or remove those two
parent groups from the Story file for now: 6 parents, 31 Stories.

**Three Features have unresolved status** — mCRC RWDP 2026 Refresh (delivery path), DLBCL
COTA RWDP and Prostate Panoramic Dashboard (did they ship?). They import as Features at New
with blank stage and get no Stories until answered.

---

# Rough timing

| | |
|---|---|
| Sandbox: process, project, fields, area path | 1–2 hours |
| Sandbox: full import cycle | 1–2 hours |
| Production: process, permissions | 1 hour |
| Production: full import cycle | 1–2 hours |
| Queries and dashboard | 1–2 hours |

Half a day if the sandbox runs clean. Longer if field validation throws surprises, which is
exactly what the sandbox is for.
