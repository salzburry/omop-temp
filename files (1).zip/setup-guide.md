# Setup guide

## 1. Sandbox first

Create a **separate inherited process** and apply it only to a sandbox project. A sandbox
sharing your production process isolates nothing — inherited-process changes appear in
every project using that process immediately.

**Before importing anything to the sandbox:**

1. Create a `Data Products` area node in the sandbox project
2. Take copies of `1_Features_import.csv` and `2_Stories_import.csv`
3. In the copies, replace `RWP-Oncology\Data Products` with `<SandboxProject>\Data Products`

Area Paths are project-specific — the production path is not a valid node in another
project and the import will fail on every row.

Import the copies, find what errors, fix the master files. Then apply the validated process
to RWP-Oncology and build it once, complete.

> **Sandbox IDs do not transfer.** The Feature IDs you paste into the sandbox Story file are
> not the IDs production will assign. For production, start again from the `<FEATURE_ID>`
> template and rebuild the ID-based stage update from the production Story export.

---

## 2. Inherited process

**Organization settings → Process** (not Project Settings) → Agile → create inherited
process → apply to the project.

> Custom fields on Feature affect **every Feature in every project using this process**,
> not only those under an area path. Confirm which projects share it.

---

## 3. Fields

### On Feature

| Field | Type | Values |
|---|---|---|
| Product | Text | |
| Product Type | Picklist | RWDP, Dashboard |
| Release Type | Picklist | Initial Release, Data Refresh, Enhancement |
| Release Label | Text | free text — Initial, 2026 Refresh |
| Delivery Path | Picklist | New product, Repeat - methodology change, Repeat - specification change, Repeat - implementation-only change, Repeat - no logic change |
| Current Stage | Picklist | *(full list below)* |
| Current Owner | Picklist | RWP, RWDE, RWB |
| Health | Picklist | On Track, At Risk, Blocked |

### On User Story

| Field | Type | Notes |
|---|---|---|
| Current Stage | Picklist | **same field, added to this type** — custom fields do not appear on a work item type automatically. Relabel the form display to `Delivery Stage`: on a Feature it means where the deliverable is, on a Story it means which stage that Story represents. Queries still use the real field name. |
| Migration Baseline | Boolean, default `False` | `True` = timestamps come from cutover, not real work. Excluded from cycle time. Stores True/False, renders as a checkbox. |
| Story Points | Existing | verify it is on the form |
| Start Date | Existing | verify — not on every process configuration |
| Target Date | Existing | verify |

### Current Stage — full picklist

Planned · Methodology Doc · Prog Spec · Prog Spec QC · Programming · Program Execution ·
Requirements · Design · Build · UAT · Program Validation · Release Preparation ·
Released · Results Disseminated · On Hold

### Health definitions — agree these before use

| Value | Meaning |
|---|---|
| On Track | Forecast unchanged, no material blocker |
| At Risk | Forecast may move without intervention |
| Blocked | Work cannot proceed |

Without definitions the field becomes subjective. Worth ten minutes with the team.

---

## 4. Validate before importing

1. Create one Feature and one User Story by hand, filling every field
2. Export both to CSV
3. Compare their headers against `1_Features_import.csv` and `2_Stories_import.csv`
4. Fix any mismatch — ADO rejects unmatched field names rather than ignoring them

---

## 5. Import — order matters

**Step 1. Features.** Import `1_Features_import.csv`, 17 rows. Save.

**Step 2. Feature State.** Everything arrives at `New`. Bulk-edit in three groups per
`3_migration-state-map.csv`: 6 Closed, 8 Active, 3 New. Without this the released products
show as open work in every default backlog.

> The map is a **control file, not an import file**. It has no `ID` or `Work Item Type`
> column and cannot be uploaded. At 17 Features, selecting three groups in the UI and
> bulk-editing State is faster than building an update CSV anyway.

**Step 3. Populate Current Stage** — all 17, not just the active ones:
- 6 Closed → `Released`
- 8 Active → confirmed actual stage
- 3 unresolved → leave blank

A Closed Feature with a blank stage shows no terminal state in Completed Deliverables and
trips the reconciliation query on every historical release.

> **Two of the eight need a stage confirmed first** — DLBCL COTA Dashboard and advNSCLC
> Dashboard. Without knowing the current stage there is no way to tell which child Story is
> prior, current, or future, so the Story state pass cannot run. Either confirm the stage,
> or hold those two Features' Stories.

**Step 4. Export the Features** and copy each ID into the matching parent row of
`2_Stories_import.csv`, replacing `<FEATURE_ID>`.

> Replace every `<FEATURE_ID>`. A literal placeholder is an invalid ID and should fail
> validation — annoying but easy to fix. A **blank** parent ID is worse: ADO treats the row
> as a new item and creates a duplicate Feature with the Stories attached to the copy.

**Step 5. Stories.** Import, 8 parent rows + 41 Stories. Save.

**Step 6. Story stage values.** `2b_Stories_stage-map.csv` is a **lookup file, not an
import file** — it has no `ID` column.

Export the 41 Stories with ID, Work Item Type, and Title. Join the map on Title — all 41
titles are unique and match exactly. Build an update CSV:

```
ID,Work Item Type,Title,Current Stage
12345,User Story,Prostate Panoramic RWDP - Initial - Methodology Doc,Methodology Doc
```

Import that. Stage was deliberately kept out of the hierarchy file so its parent rows
could not overwrite the Feature stage values set in step 3.

**Step 7. Story State and baseline.** Per Feature:

| Story | State | Migration Baseline |
|---|---|---|
| Stages completed before cutover | Closed | `True` |
| Stage underway at cutover | Active | `True` |
| Later stages | New | `False` |

Both the completed stages and the current one are baseline. If Programming first goes
Active during migration, ADO measures its cycle time from cutover — the number is as
fabricated as the closed ones. Only stages starting after cutover give real data.

**Step 8. Populate** assignees, Story Points, dates, Current Owner, Target Date.

**Step 9. Run the completeness and reconciliation queries** before exposing anything. They
catch a partial stage update, a Closed Feature with no terminal stage, and an RWDP sitting
at UAT.

Do not expose the Resources, Needs Staffing, or Cycle Time views until step 7 is done —
before that every Story reads as New and the numbers are meaningless.

---

## 6. Permissions

Creating an area path does not make anyone read-only — Contributors have edit rights by
default and permissions inherit from group membership.

1. Create an RWP-editor group and a stakeholder-reader group
2. On `RWP-Oncology\Data Products`: editor = view Allow, edit Allow; reader = view Allow,
   edit Deny
3. **Verify with a real member of each group**, not just the setting

If Tech should be able to comment without editing fields, that is a separate work-item
comment permission — read-only access does not grant it by default.

---

## 7. Queries and dashboard

Build the six queries in `ado-structure.md` under Shared Queries, then place their charts
on a team dashboard. Stakeholder-access users cannot open query charts from the Queries
page but can see them on a dashboard.

Worth adding while you are there:

- **Cycle Time widget** — scoped to User Story, filtered by Current Stage, excluding
  `Migration Baseline = True`. One widget per stage; the widget filters by a field, it does
  not group by one.
- **Burndown or velocity** — only if you adopt sprints.
- **Query tile** — a single number, e.g. count of Blocked items.

---

## The demo

**Open with what it answers and what it does not.** The stage view is real; owners and
target dates are pending. Do not present it as populated.

**Walk three Features:**
- Prostate Panoramic RWDP — new product
- Panoramic SCLC RWDP 2026 Data Refresh — repeat, no logic change, skips straight to
  Program Execution
- Endometrial Cancer Dashboard — different path entirely: Requirements → Design → Build → UAT

That third one is the point. Two product types, two lifecycles, one tracker.

**Two governance lines:**
- RWP owns the stage definitions and the area path
- After cutover this is the single portfolio tracker for RWP-Oncology

**What is next:** owners and forecasts to populate, Protocol and RDQ to follow the same
pattern, Story layer for per-stage tracking.

### Do not

- Present it as operational before owners and dates are in
- Claim the board enforces the workflow — Current Stage is a field, not a state machine
- Show `Closed Date` as when something shipped for the migrated records
- Agree to Tech editing stage or dates
