# RWP-Oncology on Azure DevOps — structure

## Area paths

```
RWP-Oncology
├── Data Products
├── Protocol
└── RDQ
```

Resources, Needs Staffing, and Completed are **queries**, not area paths — they read across
all three. That is the gain over the GitHub setup, where those views were curated by hand.

---

## Stage sequences

One `Current Stage` picklist holds every value. Each item type uses what applies; nothing
is enforced. One field rather than two keeps every query and chart reading a single column.

| Category | Sequence |
|---|---|
| **RWDP** | Planned → Methodology Doc → Prog Spec → Prog Spec QC → Programming → Program Validation → Release Preparation → Released |
| **RWDP, no logic change** | Planned → Program Execution → Program Validation → Release Preparation → Released |
| **Dashboard** | Planned → Requirements → Design → Build → UAT → Release Preparation → Released |
| **Dashboard, build-only change** | Planned → Build → UAT → Release Preparation → Released |
| **Protocol** *(proposed)* | Same as RWDP, ending at Results Disseminated |
| **RDQ** *(proposed)* | Planned → Prog Spec → Programming → Program Validation → Results Disseminated |

> Protocol and RDQ sequences are **proposed, not confirmed** with their owners. Do not
> harden them into workflow governance until those teams agree.

**Full picklist:**
Planned · Methodology Doc · Prog Spec · Prog Spec QC · Programming · Program Execution ·
Requirements · Design · Build · UAT · Program Validation · Release Preparation ·
Released · Results Disseminated · On Hold

Every new or changed RWDP that goes through specification and programming includes both
Prog Spec QC and Program Validation, regardless of how the old tracker recorded it. A
no-logic-change rerun skips the specification gates but still goes through Program
Validation.

**Release Preparation** is a real stage with a clean boundary. Program Validation ends with
final RWP or RWB validation and QC signoff. Release Preparation begins when the approved
package is handed to RWDE, and Current Owner is RWDE for its duration — ownership does not
change partway through a stage.

**Results Disseminated** is terminal, not work in progress. Results go to stakeholders for
abstract or publication; RWP's role ends. State = Closed.

---

## Hierarchy

```
Feature          the deliverable — an RWDP, a dashboard, a protocol, an RDQ
└── User Story   one per stage — assignee, dates, story points
    └── Task     optional, only where a stage needs splitting
```

The Feature carries portfolio fields — what leadership reads. Stories carry per-stage
assignees and dates — what the team works from.

> **Feature `Current Stage` is maintained manually.** ADO's inherited-process rules operate
> on fields within one work item; they cannot copy a child Story's stage into a parent
> field. Automating it needs Power Automate or a REST hook. Update it by hand when a stage
> Story goes Active, and revisit automation only once the Story layer proves worth keeping.

---

## Story points, not hours

Hours are not tracked — people work across three or four things at once and the numbers
would be fiction. `Story Points` on each stage Story gives relative sizing without
pretending to timesheet accuracy.

---

## Cycle time — how to actually get it

`Closed Date` minus `Start Date` is **not** ADO cycle time. Start Date is a scheduling
field you fill in by hand; ADO computes cycle time from workflow state transitions.

To get real per-stage duration:

1. Move a stage Story to `Active` when that stage actually begins
2. Move it to `Closed` when the stage ends
3. Add the **Cycle Time widget** to a dashboard, scoped to User Story
4. Filter the widget by `Current Stage` — one widget per stage you care about
5. **Exclude `Migration Baseline = True`**

The widget filters by a field value; it does not group by one. For stage-by-stage
comparison in a single view, use Analytics.

### Migration Baseline

A Boolean field on User Story, default `False`. `True` means the Story's timestamps come
from cutover, not from when the work actually happened.

Mark as baseline:
- every stage already **completed** before cutover
- the stage **currently underway** at cutover

That second one matters. If Programming first goes Active during migration, ADO measures
its cycle time from the cutover date — the number is as fabricated as the closed ones.

**Reliable cycle time begins with the first stage that starts after cutover.** For a
product sitting at Programming today, that is Program Validation.

Operational view: `Work Item Type = User Story AND Migration Baseline = False`
History view: `Work Item Type = User Story AND Migration Baseline = True`

ADO Boolean fields store `True` / `False` and render as a checkbox — not `Yes` / `No`.

A Boolean field rather than a tag — tags drift into `MigrationBaseline`, `Migrated`, and
three other spellings.

This only works if Stories are kept current as work moves. If they aren't, the Completed
Stages query is still a useful list — it just isn't a duration metric.

---

## Queries

### Active pipeline — leadership

| Field | Operator | Value |
|---|---|---|
| Work Item Type | = | Feature |
| Area Path | Under | RWP-Oncology |
| State | NOT IN | Closed, Removed |

Filter on **State**, not Current Stage. Stage imports blank on every Feature, so a stage
filter returns everything including the released ones. State answers *open or done*;
Current Stage answers *where the open thing is sitting*. Show Current Stage as a column.

### Completed deliverables — leadership

| Field | Operator | Value |
|---|---|---|
| Work Item Type | = | Feature |
| Area Path | Under | RWP-Oncology |
| State | = | Closed |

Sort by Area Path, then Title. **Do not sort by Closed Date** — the six migrated Features
all carry the cutover date, which would read as though they shipped the same day. Switch to
Actual Release Date once that field exists.

> `Closed Date` for the six migrated releases will be the cutover date, not when they
> shipped — it is system-set on state change and cannot be edited. If real release history
> matters, add an `Actual Release Date` field and tag migrated records.

### Completed stages — RWP

| Field | Operator | Value |
|---|---|---|
| Work Item Type | = | User Story |
| Area Path | Under | RWP-Oncology |
| State | = | Closed |

Sort by Assigned To, then Current Stage. Chart: group by Current Stage.

Keep these two separate. Merged, one completed Feature drags six completed Stories into the
same list — the leadership view becomes noise.

### Resources — who is actively working on what

Work Item Type = User Story · Area Path Under RWP-Oncology · **State = Active**

`State <> Closed` would count every future stage Story as current workload — six per
product, mostly not started. `Active` is the real picture.

**Planned work** — same filters with `State = New` — is the separate question.

For real workload rather than a count, use Boards → Sprints → Capacity, which needs
iterations configured.

### Needs staffing — due but unassigned

Work Item Type = User Story · Area Path Under RWP-Oncology · Assigned To = *(blank)* ·
Target Date <= @Today + 14 · State NOT IN (Closed, Removed)

Only surfaces Stories that carry target dates. Unassigned work with no date is worth a
second query.

### Also worth having

- **Blocked** — `Work Item Type = Feature` AND `Area Path Under RWP-Oncology` AND `Health = Blocked`
- **Overdue deliverables** — `Work Item Type = Feature` AND `Area Path Under RWP-Oncology` AND `Target Date < @Today` AND `State NOT IN (Closed, Removed)`
**Reconciliation — Feature only**

- `Work Item Type = Feature` AND `State = Closed` AND (`Current Stage NOT IN (Released, Results Disseminated)` OR `Current Stage = [blank]`)

  The blank clause is explicit — `NOT IN` does not reliably catch an undefined field.
- `Work Item Type = Feature` AND `Current Stage IN (Released, Results Disseminated)` AND `State <> Closed`

The `Work Item Type = Feature` scoping is essential. Without it, every correctly closed
stage Story — a closed Prog Spec QC, a closed UAT — is flagged as an error.

**Invalid stage — Feature only**

- `Work Item Type = Feature` AND `Product Type = RWDP` AND `Current Stage` in Requirements, Design, Build, UAT
- `Work Item Type = Feature` AND `Product Type = Dashboard` AND `Current Stage` in Methodology Doc, Prog Spec, Prog Spec QC, Programming, Program Execution, Program Validation

One shared picklist cannot stop someone picking UAT on an RWDP. Cheap exception queries
beat maintaining two fields.

**Data completeness — Feature only, State = Active**

- `Current Stage = [blank]`
- `Current Owner = [blank]`
- `Target Date = [blank]`

**Story stage completeness** — `Work Item Type = User Story` AND `Area Path Under RWP-Oncology` AND `Current Stage = [blank]`.
Catches a missed or partial `2b` update pass immediately.

These three measure whether the tracker actually answers where it is, who owns it, and when
it is coming.

Save all under **Shared Queries** so they can be charted and placed on a dashboard.
Note: queries produce sorted lists; grouping is a chart or widget behaviour, not a query one.

---

## Import mechanics

**Hierarchy comes from indented title columns plus the parent's ID.** `Title 1` holds the
Feature, `Title 2` its Stories. The parent row must carry the Feature's real ADO `ID` —
without it ADO treats the parent as a new item and creates a duplicate Feature.

So: import Features → export them → paste each real numeric ID over `<FEATURE_ID>` in the
Story file → import Stories. Child rows keep a blank ID.

> **Two distinct failure modes.** A literal `<FEATURE_ID>` is an invalid ID and should fail
> validation — that blocks the import and is easy to correct. A **blank** parent ID makes
> ADO treat the parent row as a new item and create a duplicate Feature, which needs
> cleanup. A valid numeric ID updates the existing Feature and links the Stories beneath it.

**The Feature import must not carry** `ID`, `Assigned To`, `State`, `Created By`, or
`Changed Date`. The Story import carries ID on parent rows only.

**The hierarchy file carries no `Current Stage` column.** Parent rows are updates to
existing Features; a blank value in a column present in the file may overwrite the Feature
stage you just set. Stage values for the Stories live in `2b_Stories_stage-map.csv`, which is a **lookup file,
not an import file** — it has no `ID` column. After the Stories are saved, export them,
join the map to the export on Title, and import the resulting ID-based update.

Story Points, dates, assignees, and Migration Baseline are all populated after save.

**Everything imports at State = New.** A second pass is required:

| Current Stage | State |
|---|---|
| Planned, or blank | New |
| Methodology Doc, Prog Spec, Prog Spec QC, Programming, Program Execution | Active |
| Requirements, Design, Build, UAT | Active |
| Program Validation, Release Preparation | Active |
| On Hold | Active |
| Released, Results Disseminated | Closed |

For Stories under an active Feature: prior stages → Closed, current stage → Active, future
stages → New.

**No Stories under released or unresolved products.** 8 Features get Stories. The 6
confirmed releases get none, and neither do the 3 whose status or delivery path is unknown
— DLBCL COTA RWDP, Prostate Panoramic Dashboard, mCRC RWDP 2026 Refresh.

 Creating six stage Stories under an already-shipped
product and closing them at migration produces a stage history that never happened —
creation date, closed date, and durations would all be the cutover date. The Feature stays
as the delivery record.

---

## Build order

1. **Sandbox** — create a **separate inherited process**, applied only to the sandbox
   project. A sandbox sharing your production process isolates nothing: inherited-process
   changes appear immediately in every project using that process. Validate fields, forms,
   imports, and queries there, then apply the process to RWP-Oncology.
2. **RWP-Oncology** — build once, complete, from validated CSVs.
3. Features → State update → Stories → State update → assignees → queries → dashboard.
4. Protocol and RDQ area paths once the Data Products pattern has proven itself.
5. Sprint capacity, only if the team adopts iterations.
