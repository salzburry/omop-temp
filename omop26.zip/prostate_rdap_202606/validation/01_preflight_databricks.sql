-- =============================================================================
-- 202606 Prostate PANO RWDP - PREFLIGHT VALIDATION
-- Run BEFORE code/prostate_rdap_202606.R
-- =============================================================================
-- HOW TO SUPPLY THE TWO NAMES BELOW
--   `${catalog}` and `${src}` are text-substitution placeholders, not SQL
--   parameter markers. `:param` binds values, not object names. Either:
--     * SQL editor / notebook where `${...}` still resolves (legacy from
--       DBR 15.2) - set the widgets and run as-is; or
--     * anywhere else - find-and-replace the tokens with the literals below.
--
--   ${catalog} = hive_metastore
--   ${src}     = clnprw_flatiron_pano_pros_use
--
--   ${src}, deliberately not ${schema}: this file reads SOURCE tables only.
--   ${schema} means the personal OUTPUT schema everywhere else in this repo,
--   and validation/run_sql.R substitutes it as such - a ${schema} here would
--   aim every preflight check at the wrong namespace.
--
-- The 2026m06 cut lives in the legacy metastore, where information_schema is
-- not available under the schema, so section A uses SHOW / DESCRIBE instead. If
-- the cut is migrated to Unity Catalog, section A can be replaced by reading
-- `<catalog>.information_schema.columns` (it is catalog-level, never
-- schema-level) and diffing against validation/00_input_contract.csv.
--
-- HOW TO READ THIS FILE
--   Section A  the 21 source tables and 98 columns exist
--   Section B  MANDATORY gates - a FAIL here means do not build
--   Section C  value sets the code branches on
--   Section D  open decisions the data can inform
--
-- Section B is four statements, not one: the B1-B14 union, then B7b, B10 and
-- B11 separately. In the union, every row marked MANDATORY must read PASS.
-- Rows marked WARN (B7, B8, B9) are readings, not gates - read them, but they
-- do not stop a build on their own.
--
-- This file reports; it does not enforce. The build enforces the twelve
-- mandatory gates itself in run_preflight() (code/modules/00_setup.R) and
-- stops there. Running this first tells you the answer before you spend the
-- build.
--
-- IF THE 2026-08 PREFLIGHT IS ALREADY ON FILE
--   Results still stand for A, B1-B4, B6, B8-B11, C1-C9, C11-C13 and D1-D8.
--   Run at least: B5, B7 / B7b, B12, B13, B14, B15 / B16, B17, C10,
--   C10c/C10d and D9 / D10.
-- =============================================================================


-- =============================================================================
-- A. SCHEMA  (21 tables / 98 columns under the _2026m06 suffix, register Q77.
--     Authoritative list is
--             validation/00_input_contract.csv)
-- =============================================================================

-- A1. Confirm all 21 tables exist. PASS: 21 rows.
USE CATALOG ${catalog};
USE SCHEMA  ${src};
SHOW TABLES LIKE 't_*_2026m06';

-- A2. Confirm every required column exists.
--     Legacy metastore has no per-schema information_schema, so this is the
--     portable form: one DESCRIBE per table, compared against the contract.
--     Run these and diff the output against validation/00_input_contract.csv.

DESCRIBE TABLE t_enh_prostate_2026m06;   -- expect: patientid, diagnosisdate, groupstage, gleasonscore, metastaticdiagnosisdate, crpcdate, crpctype, hspcdate, hspctype, psainitialdiagnosis, psametdiagnosis
DESCRIBE TABLE t_enh_prostate_lot_2026m06;   -- expect: patientid, linename, linenumber, linesetting, startdate, enddate
DESCRIBE TABLE t_enh_prostate_drg_epsode_2026m06;   -- expect: patientid, linename, linenumber, linesetting, episodedate, episodedatasource, drugcategory, detaileddrugcategory
DESCRIBE TABLE t_demographics_2026m06;   -- expect: patientid, birthyear, race, ethnicity, state
DESCRIBE TABLE t_socdetofhealth_2026m06;   -- expect: patientid, sesindex2015_2019
DESCRIBE TABLE t_practice_2026m06;   -- expect: patientid, practicetype
DESCRIBE TABLE t_visit_2026m06;   -- expect: patientid, visitdate
DESCRIBE TABLE t_telemedicine_2026m06;   -- expect: patientid, visitdate
DESCRIBE TABLE t_mortality_v2_2026m06;   -- expect: patientid, dateofdeath
DESCRIBE TABLE t_enh_prostate_orals_2026m06;   -- expect: patientid, startdategranularity, enddate
DESCRIBE TABLE t_enh_prostate_bsln_ecog_2026m06;   -- expect: patientid, ecogdate, ecogvalue, linenumber, linestartdate
DESCRIBE TABLE t_ecog_2026m06;   -- expect: patientid, ecogdate, ecogvalue
DESCRIBE TABLE t_vitals_2026m06;   -- expect: patientid, test, testdate, resultdate, testresult, testresultcleaned, testunitscleaned
DESCRIBE TABLE t_lab_2026m06;   -- expect: patientid, testbasename, labcomponent, testdate, resultdate, testresultcleaned, testunitscleaned
DESCRIBE TABLE t_enh_prostate_psa_2026m06;   -- expect: patientid, scoreserial, resultdate
DESCRIBE TABLE t_enh_prostate_som_2026m06;   -- expect: patientid, siteofmetastasis, dateofmetastasis
DESCRIBE TABLE t_enh_prostate_biomarker_2026m06;   -- expect: patientid, biomarkername, biomarkerstatus, resultdate, specimencollecteddate
DESCRIBE TABLE t_enh_prostate_psmapet_2026m06;   -- expect: patientid, scandate, isdiseaseevidence
DESCRIBE TABLE t_enh_prostate_prog_scled_2026m06;   -- expect: patientid, progressiondate, lastclinicnotedate, isradiographicevidence, ispathologicevidence, ismixedresponsementioned, ispseudoprogressionmentioned, isphysicalexamevidence, istumormarkerevidence, ispsaincreased
DESCRIBE TABLE t_medicationorder_2026m06;   -- expect: patientid, expectedstartdate, iscanceled, drugcategory, detaileddrugcategory
DESCRIBE TABLE t_medicationadmin_2026m06;   -- expect: patientid, administereddate, drugcategory, detaileddrugcategory

-- A2b. On Unity Catalog this whole section collapses to the information_schema
--      query described in the header; not written out because it cannot be
--      tested on this cut.

-- =============================================================================
-- B. MANDATORY GATES
-- =============================================================================
-- Every MANDATORY row must read PASS. B7/B8/B9 report WARN and are readings,
-- not gates.

WITH
b1 AS (SELECT COUNT(*) AS n FROM (
         SELECT patientid, linesetting, startdate
         FROM   ${src}.t_enh_prostate_lot_2026m06
         WHERE  linesetting IN ('mHSPC','mCRPC')
         GROUP  BY patientid, linesetting, startdate HAVING COUNT(*) > 1)),
b2 AS (SELECT COUNT(*) AS n FROM (
         SELECT patientid FROM ${src}.t_enh_prostate_2026m06
         GROUP BY patientid HAVING COUNT(*) > 1)),
-- B3/B4/B5 must each mirror the shape the BUILD actually joins on, or the SQL
-- gate and the R gate disagree about what counts as a duplicate.
--   B3 mortality  - joined as SELECT DISTINCT patientid, dateofdeath, <derived>,
--                   so an exact duplicate row is collapsed before the join and
--                   only conflicting death dates fan out. DISTINCT is correct.
--   B4 demographics and B5 social determinants - joined raw, so any duplicate
--                   row fans the clinical block out. No DISTINCT: de-duplicating
--                   first blinds the check to exact-duplicate rows.
b3 AS (SELECT COUNT(*) AS n FROM (
         SELECT patientid FROM (
           SELECT DISTINCT patientid, dateofdeath FROM ${src}.t_mortality_v2_2026m06)
         GROUP BY patientid HAVING COUNT(*) > 1)),
b4 AS (SELECT COUNT(*) AS n FROM (
         SELECT patientid FROM ${src}.t_demographics_2026m06
         GROUP BY patientid HAVING COUNT(*) > 1)),
b5 AS (SELECT COUNT(*) AS n FROM (
         SELECT patientid FROM ${src}.t_socdetofhealth_2026m06
         GROUP BY patientid HAVING COUNT(*) > 1)),
b6 AS (SELECT COUNT(*) AS n FROM (
         SELECT patientid, linesetting, linenumber
         FROM   ${src}.t_enh_prostate_lot_2026m06
         WHERE  linesetting IN ('mHSPC','mCRPC')
         GROUP  BY patientid, linesetting, linenumber HAVING COUNT(*) > 1)),
-- B7. GENE-INVENTORY DRIFT. The 19 symbols below are the D5pre inventory on
-- the 2026-08 cut - the exact union of the FDA olaparib mCRPC label panel
-- (14) and TALAPRO-2 (12).
--
-- WARN, not a build stop: HRR is 4 of 190 columns and the build should still
-- produce the ADS. Q44 froze `flatiron_all` to these 19 named symbols, so a
-- gene added to a future cut is excluded rather than absorbed - it
-- classifies as not-HRR and the build announces it on startup. Either way the
-- case definition moves, which is what this check surfaces.
-- Nothing downstream gates on it: V2b asks a reader to confirm the panel
-- against the manifest, and there is no publication step it could block.
b7 AS (SELECT COUNT(DISTINCT UPPER(biomarkername)) AS n
       FROM   ${src}.t_enh_prostate_biomarker_2026m06
       WHERE  UPPER(biomarkername) NOT IN
              ('ATM','BARD1','BRCA1','BRCA2','BRIP1','CDK12','CHEK1','CHEK2',
               'FANCL','PALB2','RAD51B','RAD51C','RAD51D','RAD54L',
               'ATR','FANCA','MLH1','MRE11A','NBN')),
-- Values that would raise under ANSI CAST. The script uses TRY_CAST, so these
-- become NULL rather than aborting; a nonzero count is a data-quality warning,
-- not a build stop.
b8 AS (SELECT COUNT(*) AS n FROM ${src}.t_ecog_2026m06
       WHERE ecogvalue IS NOT NULL AND TRY_CAST(ecogvalue AS INT) IS NULL),
b9 AS (SELECT COUNT(*) AS n FROM ${src}.t_vitals_2026m06
       WHERE LOWER(test) LIKE '%blood pressure%'
         AND testresult IS NOT NULL AND TRY_CAST(testresult AS DOUBLE) IS NULL),
-- B12. NEW_LOT_N is ROW_NUMBER() OVER (... ORDER BY startdate). A NULL
-- startdate has no defined position in that ordering, so the line numbering -
-- and therefore the index date of every treated cohort - would be arbitrary.
-- B1 catches ties only; it cannot see a lone NULL startdate. MANDATORY.
b12 AS (SELECT COUNT(*) AS n FROM ${src}.t_enh_prostate_lot_2026m06
        WHERE linesetting IN ('mHSPC','mCRPC') AND startdate IS NULL),
-- B13. The 17 treatment categories are decided by parsing LINENAME, and the
-- parser knows exactly two separators: comma and slash. A regimen joined by a
-- semicolon, a plus or a pipe is not rejected - it is read as one drug name,
-- matches no monotherapy test and no combination test, and lands silently in
-- category 16 "Any other therapy". LOTnCAT is a headline variable and nothing
-- downstream would report the misclassification. MANDATORY (register Q65,
-- ruled 2026-08-08).
--
-- Deliberately narrow: separator punctuation only. Drug names legitimately
-- contain hyphens (Radium-223, Sipuleucel-T) and spaces (Clinical Study Drug),
-- so those are not flagged.
b13 AS (SELECT COUNT(*) AS n FROM ${src}.t_enh_prostate_lot_2026m06
        WHERE linesetting IN ('mHSPC','mCRPC')
          AND linename IS NOT NULL
          AND NOT linename RLIKE '^[A-Za-z0-9.()-]+( [A-Za-z0-9.()-]+)*([,/][A-Za-z0-9.()-]+( [A-Za-z0-9.()-]+)*)*$'),
-- B14. The same contract on the drug-episode table. B13 covers only the LOT
-- table; PRIOR_PARP and PRIOR_NHA_ADT parse LINENAME from drug episodes, so
-- an unexpected separator there changes a delivered flag without tripping B13.
-- MANDATORY.
b14 AS (SELECT COUNT(*) AS n FROM ${src}.t_enh_prostate_drg_epsode_2026m06
        WHERE linename IS NOT NULL
          AND NOT linename RLIKE '^[A-Za-z0-9.()-]+( [A-Za-z0-9.()-]+)*([,/][A-Za-z0-9.()-]+( [A-Za-z0-9.()-]+)*)*$'),
-- B15/B16. LINESETTING is matched exactly in the build - `IN ('mHSPC','mCRPC')`
-- for the cohorts and `= setting` for the per-line episode look-up. A variant
-- spelling or a stray space raises nothing: the row is simply not selected, so
-- the line disappears from its cohort, from NEW_LOT_N and from every LOTn
-- variable, while the table still looks complete. MANDATORY, both tables.
b15 AS (SELECT COUNT(*) AS n FROM ${src}.t_enh_prostate_lot_2026m06
        WHERE linesetting IS NOT NULL
          AND LOWER(TRIM(linesetting)) IN ('mhspc','mcrpc')
          AND linesetting NOT IN ('mHSPC','mCRPC')),
b16 AS (SELECT COUNT(*) AS n FROM ${src}.t_enh_prostate_drg_epsode_2026m06
        WHERE linesetting IS NOT NULL
          AND LOWER(TRIM(linesetting)) IN ('mhspc','mcrpc')
          AND linesetting NOT IN ('mHSPC','mCRPC')),
-- B17. The parser takes a comma as proof of a second drug, so
-- 'abiraterone,abiraterone' reads as an NHA combination rather than abiraterone
-- monotherapy. B13 and B14 pass it, because the format is legal. Detect the
-- repeated token instead. MANDATORY, both tables.
--
-- Split on comma only. The slash is not a regimen separator here - it binds
-- inside one product name (Niraparib/Abiraterone, Decitabine/Cedazuridine,
-- Daratumumab/Hyaluronidase-Fihj), so splitting on [,/] misreads
-- 'Abiraterone,Leuprolide,Niraparib/Abiraterone' as a repeated abiraterone and
-- flags ordinary rows.
-- Scope must match the R gate exactly: the two settings on the LOT table,
-- because only those feed the categories, and every drug-episode row, because
-- the prior-drug flags read those whatever the setting. A wider scan (e.g. all
-- LOT settings) fails rows the build never parses, so this check and the build
-- disagree.
b17 AS (SELECT COUNT(*) AS n FROM (
          SELECT linename FROM ${src}.t_enh_prostate_lot_2026m06
           WHERE linesetting IN ('mHSPC','mCRPC')
          UNION ALL
          SELECT linename FROM ${src}.t_enh_prostate_drg_epsode_2026m06) u
        WHERE linename IS NOT NULL
          AND SIZE(SPLIT(LOWER(linename), ','))
              <> SIZE(ARRAY_DISTINCT(SPLIT(LOWER(linename), ','))))
SELECT 'B1' AS check_id, 'no same-day LOT ties (NEW_LOT_N determinism)' AS what,
       n AS failed, 'MANDATORY' AS severity,
       CASE WHEN n = 0 THEN 'PASS' ELSE 'FAIL' END AS status FROM b1
UNION ALL SELECT 'B2','t_enh_prostate one row per patient',        n,'MANDATORY',CASE WHEN n=0 THEN 'PASS' ELSE 'FAIL' END FROM b2
UNION ALL SELECT 'B3','t_mortality_v2 one row per patient',        n,'MANDATORY',CASE WHEN n=0 THEN 'PASS' ELSE 'FAIL' END FROM b3
UNION ALL SELECT 'B4','t_demographics one row per patient',        n,'MANDATORY',CASE WHEN n=0 THEN 'PASS' ELSE 'FAIL' END FROM b4
UNION ALL SELECT 'B5','t_socdetofhealth one row per patient',      n,'MANDATORY',CASE WHEN n=0 THEN 'PASS' ELSE 'FAIL' END FROM b5
UNION ALL SELECT 'B6','linenumber unique per patient+setting',     n,'MANDATORY',CASE WHEN n=0 THEN 'PASS' ELSE 'FAIL' END FROM b6
UNION ALL SELECT 'B7','gene inventory unchanged from the frozen 19 (Q05/Q44)', n,'WARN', CASE WHEN n=0 THEN 'PASS' ELSE 'WARN' END FROM b7
UNION ALL SELECT 'B8','ECOG values castable to INT',               n,'WARN',     CASE WHEN n=0 THEN 'PASS' ELSE 'WARN' END FROM b8
UNION ALL SELECT 'B9','BP results castable to DOUBLE',             n,'WARN',     CASE WHEN n=0 THEN 'PASS' ELSE 'WARN' END FROM b9
UNION ALL SELECT 'B12','no NULL LOT StartDate in mHSPC/mCRPC',     n,'MANDATORY',CASE WHEN n=0 THEN 'PASS' ELSE 'FAIL' END FROM b12
UNION ALL SELECT 'B13','LOT LINENAME separator/whitespace contract (Q65)', n,'MANDATORY',CASE WHEN n=0 THEN 'PASS' ELSE 'FAIL' END FROM b13
UNION ALL SELECT 'B14','drugepisode LINENAME separator/whitespace contract (Q65)', n,'MANDATORY',CASE WHEN n=0 THEN 'PASS' ELSE 'FAIL' END FROM b14
UNION ALL SELECT 'B15','LOT LINESETTING exact form (no case or space variants)', n,'MANDATORY',CASE WHEN n=0 THEN 'PASS' ELSE 'FAIL' END FROM b15
UNION ALL SELECT 'B16','drugepisode LINESETTING exact form',       n,'MANDATORY',CASE WHEN n=0 THEN 'PASS' ELSE 'FAIL' END FROM b16
UNION ALL SELECT 'B17','no LINENAME with a repeated drug token',   n,'MANDATORY',CASE WHEN n=0 THEN 'PASS' ELSE 'FAIL' END FROM b17
ORDER BY check_id;


-- B7b. Which genes drifted, in both directions. B7 returns a count of genes
--      that are present but unexpected. It is structurally blind to the other
--      failure: a gene that disappears from a future cut. That one is worse -
--      a gene silently dropping out narrows the HRR case definition and
--      nothing else would say so.
--      Also watch for aliases of a gene already present (see D5pre), which
--      double-count in any list panel.
--      PASS: zero rows.
WITH expected AS (
  SELECT explode(ARRAY(
    'ATM','BARD1','BRCA1','BRCA2','BRIP1','CDK12','CHEK1','CHEK2',
    'FANCL','PALB2','RAD51B','RAD51C','RAD51D','RAD54L',
    'ATR','FANCA','MLH1','MRE11A','NBN')) AS gene),
actual AS (
  SELECT UPPER(biomarkername) gene, COUNT(*) n, COUNT(DISTINCT patientid) pts
  FROM   ${src}.t_enh_prostate_biomarker_2026m06 GROUP BY 1)
SELECT COALESCE(a.gene, e.gene) gene,
       COALESCE(a.n, 0)   rows_found,
       COALESCE(a.pts, 0) patients,
       CASE WHEN e.gene IS NULL THEN 'UNEXPECTED - new gene or alias, widens HRR_INDEX'
            ELSE 'MISSING - gene dropped out of the cut, narrows HRR_INDEX'
       END AS drift
FROM       actual a
FULL OUTER JOIN expected e ON e.gene = a.gene
WHERE  a.gene IS NULL OR e.gene IS NULL
ORDER  BY drift, gene;


-- B10. Not a gate: PSMA scans on the same date with conflicting evidence.
--      These occur. Q26 ruled that a Yes and a No on the same date give
--      'Unknown/not documented', not MAX(isdiseaseevidence).
SELECT patientid, scandate, COUNT(*) n, COLLECT_SET(isdiseaseevidence) results
FROM   ${src}.t_enh_prostate_psmapet_2026m06
GROUP  BY patientid, scandate
HAVING COUNT(DISTINCT isdiseaseevidence) > 1
LIMIT  50;

-- B11. Baseline ECOG duplicates on the treated-cohort match key. The script
--      resolves the DATE first, then takes MAX(value) on that date.
SELECT patientid, linenumber, linestartdate, COUNT(*) n,
       COLLECT_LIST(ecogvalue) values
FROM   ${src}.t_enh_prostate_bsln_ecog_2026m06
GROUP  BY patientid, linenumber, linestartdate
HAVING COUNT(*) > 1
ORDER  BY n DESC LIMIT 50;


-- =============================================================================
-- C. VALUE SETS THE CODE BRANCHES ON
-- =============================================================================
-- Each of these drives a string comparison. A different spelling or case means
-- the branch silently never fires. The 2026-08 results are recorded beside
-- each query.

-- C1. LineSetting. Code expects exactly 'mHSPC' / 'mCRPC' (case-sensitive).
SELECT linesetting, COUNT(*) n, COUNT(DISTINCT patientid) pts
FROM ${src}.t_enh_prostate_lot_2026m06 GROUP BY linesetting ORDER BY n DESC;

-- C2. Oral start-date granularity.  2026-08: YEAR 11401 / DAY 209271 / MONTH 46992
--     -> UPPER-CASE confirmed; the script compares UPPER(...) <> 'YEAR'.
SELECT startdategranularity, COUNT(*) n
FROM ${src}.t_enh_prostate_orals_2026m06 GROUP BY startdategranularity;

-- C3. Drug-episode data source.  2026-08: Administrations 1140217 /
--     Unstructured 1303636 / Orders 455474 -> 'Abstraction' does not exist.
--     Register Q16: max_drug_ep_abstracted_dt is NULL for every patient.
SELECT episodedatasource, COUNT(*) n
FROM ${src}.t_enh_prostate_drg_epsode_2026m06 GROUP BY episodedatasource;

-- C4. Practice type.
SELECT practicetype, COUNT(*) n FROM ${src}.t_practice_2026m06 GROUP BY practicetype;

-- C5. Biomarker status.  2026-08: Negative / Positive / Unknown-not-documented /
--     VUS -> the spec's 'Mutation Negative' never occurs. Register Q18.
SELECT biomarkerstatus, COUNT(*) n
FROM ${src}.t_enh_prostate_biomarker_2026m06 GROUP BY biomarkerstatus ORDER BY n DESC;

-- C6. Gleason score bands.
SELECT gleasonscore, COUNT(*) n
FROM ${src}.t_enh_prostate_2026m06 GROUP BY gleasonscore ORDER BY n DESC;

-- C7. Group stage prefixes.
SELECT groupstage, COUNT(*) n
FROM ${src}.t_enh_prostate_2026m06 GROUP BY groupstage ORDER BY n DESC;

-- C8. Sites of metastasis.
SELECT siteofmetastasis, COUNT(*) n
FROM ${src}.t_enh_prostate_som_2026m06 GROUP BY siteofmetastasis ORDER BY n DESC;

-- C9. Vitals names/units for BP and height/weight.
SELECT test, testunitscleaned, COUNT(*) n
FROM   ${src}.t_vitals_2026m06
WHERE  LOWER(test) IN ('systolic blood pressure','diastolic blood pressure',
                       'body height','body weight')
GROUP  BY test, testunitscleaned ORDER BY n DESC;

-- C10. Lab analytes: expected vs found. Mandatory.
--      Reporting only what exists cannot surface an analyte that is entirely
--      absent, so the expected combinations are listed and LEFT JOINed.
--      PASS: every row has found_rows > 0.
--      A NULL in the `unit` column means "any unit" - the analyte must exist,
--      but the build applies no unit filter to it.
--      Q25: the build filters albumin to g/L. On the 2026-08 cut,
--      labcomponent='Albumin, serum' carries testunitscleaned='g/L' on
--      4,966,771 rows / 308,946 patients, median 40 - the g/L range (35-50),
--      not g/dL (3.5-5.0). If albumin/g/L returns 0 rows here, the build
--      delivers all-null albumin, so the run must stop.
WITH expected AS (
  SELECT * FROM VALUES
    ('neutrophils','10*9/L',NULL),
    ('platelets','10*9/L',NULL),
    ('hemoglobin','g/dL',NULL),
    ('creatinine','mg/dL','Creatinine, serum'),
    ('bilirubin','mg/dL',NULL),
    ('aspartate aminotransferase','U/L',NULL),
    ('alanine aminotransferase','U/L',NULL),
    ('alkaline phosphatase','U/L',NULL),
    ('albumin','g/L','Albumin, serum'),
    ('lymphocytes','10*9/L',NULL)
  AS t(testbasename, unit, component)
),
found AS (
  SELECT LOWER(testbasename) tb, testunitscleaned u, labcomponent lc, COUNT(*) n
  FROM   ${src}.t_lab_2026m06 GROUP BY 1,2,3
)
SELECT e.testbasename, COALESCE(e.unit,'(any unit)') unit, e.component,
       COALESCE(SUM(f.n), 0) AS found_rows,
       CASE WHEN COALESCE(SUM(f.n),0) > 0 THEN 'PASS' ELSE 'FAIL' END AS status
FROM   expected e
LEFT JOIN found f
       ON f.tb = e.testbasename
      AND (e.unit      IS NULL OR f.u  = e.unit)
      AND (e.component IS NULL OR f.lc = e.component)
GROUP  BY e.testbasename, e.unit, e.component
ORDER  BY status, e.testbasename;

-- C10c. ALBUMIN SCALE - a reading, kept as the evidence behind Q25 (the build
--       applies the spec's g/L filter, so LABALBV is g/L by construction).
--       Classify each row by value to see which scale the source is on.
--       Grouping by unit gives one group and one median, which cannot see a
--       mixture living inside it: 50/50 g/dL and g/L medians around 17-20,
--       and 90/10 medians inside the majority band and hides the rest.
--       Classifying each row does see it. 3.5-5.0 g/dL == 35-50 g/L is a clean
--       10x with no overlap, so a row lands in exactly one band.
--       PASS: one band holds >= 99% of rows. Read C10d as well.
WITH banded AS (
  SELECT CASE WHEN testresultcleaned BETWEEN  1.5 AND  7.0 THEN 'g/dL'
              WHEN testresultcleaned BETWEEN 15.0 AND 70.0 THEN 'g/L'
              ELSE 'OUT OF BOTH BANDS' END AS band
  FROM   ${src}.t_lab_2026m06
  WHERE  LOWER(testbasename) = 'albumin' AND labcomponent = 'Albumin, serum'
  AND    testresultcleaned > 0),
tally AS (
  SELECT band, COUNT(*) n, SUM(COUNT(*)) OVER () total FROM banded GROUP BY band)
SELECT 'C10c' check_id,
       'serum albumin on ONE scale (row-level)' what,
       CONCAT_WS(', ', SORT_ARRAY(COLLECT_LIST(
         CONCAT(band, '=', CAST(ROUND(100.0*n/total, 2) AS STRING), '%')))) distribution,
       -- One band must hold >= 99% of rows. A 1% tail is measurement noise;
       -- anything more is a genuine mixture the ADS cannot represent.
       CASE WHEN MAX(CASE WHEN band <> 'OUT OF BOTH BANDS'
                          THEN 100.0*n/total ELSE 0 END) >= 99.0
            THEN 'PASS' ELSE 'FAIL' END status
FROM   tally;

-- C10d. If C10c passes, this names the winning scale so it can be compared
--       with the LABALBV label (which reads g/L) and recorded in the register.
SELECT CASE WHEN testresultcleaned BETWEEN  1.5 AND  7.0 THEN 'g/dL'
            WHEN testresultcleaned BETWEEN 15.0 AND 70.0 THEN 'g/L'
            ELSE 'OUT OF BOTH BANDS' END AS delivered_scale,
       COUNT(*) n,
       MIN(testresultcleaned) min_val,
       PERCENTILE(testresultcleaned, 0.5) median_val,
       MAX(testresultcleaned) max_val
FROM   ${src}.t_lab_2026m06
WHERE  LOWER(testbasename) = 'albumin' AND labcomponent = 'Albumin, serum'
AND    testresultcleaned > 0
GROUP  BY 1 ORDER BY n DESC;

-- C11. Progression evidence flags: code compares LOWER(...) = 'true'.
SELECT isradiographicevidence, ispathologicevidence, ismixedresponsementioned,
       ispseudoprogressionmentioned, isphysicalexamevidence,
       istumormarkerevidence, ispsaincreased, COUNT(*) n
FROM   ${src}.t_enh_prostate_prog_scled_2026m06
GROUP  BY 1,2,3,4,5,6,7 ORDER BY n DESC LIMIT 30;

-- C12. dateofdeath granularity - the imputation branches on LENGTH() 4 vs 7.
SELECT LENGTH(dateofdeath) len, COUNT(*) n
FROM ${src}.t_mortality_v2_2026m06 GROUP BY LENGTH(dateofdeath);

-- C13. Regimen-name separators (NHA / docetaxel combination detection).
SELECT SUM(CASE WHEN linename LIKE '%,%' THEN 1 ELSE 0 END) with_comma,
       SUM(CASE WHEN linename LIKE '%/%' THEN 1 ELSE 0 END) with_slash,
       COUNT(*) total
FROM ${src}.t_enh_prostate_lot_2026m06;


-- =============================================================================
-- D. EVIDENCE FOR OPEN DECISIONS
-- =============================================================================
-- These inform docs/DEVIATIONS.md. They do not authorize anything - a named
-- SME/RWP owner must still approve. 2026-08 results recorded inline.

-- D1 (Q01). Actual data cut-off, since MAXINDEX is printed as '4/31/2026'.
--     2026-08 RESULT: all six sources max at 2026-04-30 -> supports 2026-04-30.
SELECT 'lot.startdate' src, MAX(startdate) max_dt FROM ${src}.t_enh_prostate_lot_2026m06
UNION ALL SELECT 'visit.visitdate',     MAX(visitdate)          FROM ${src}.t_visit_2026m06
UNION ALL SELECT 'telemed.visitdate',   MAX(visitdate)          FROM ${src}.t_telemedicine_2026m06
UNION ALL SELECT 'drgep.episodedate',   MAX(episodedate)        FROM ${src}.t_enh_prostate_drg_epsode_2026m06
UNION ALL SELECT 'prog.lastclinicnote', MAX(lastclinicnotedate) FROM ${src}.t_enh_prostate_prog_scled_2026m06
UNION ALL SELECT 'psa.resultdate',      MAX(resultdate)         FROM ${src}.t_enh_prostate_psa_2026m06;

-- D2 (Q10). TINTCRPCHSPC direction.
--     2026-08 RESULT: crpc_after_hspc 72543 / crpc_before_hspc 50 / same_day 433
--     of 73026 -> the printed formula (HSPCDate - CRPCDate) is negative for
--     99.3% of patients; the label direction is almost certainly intended.
SELECT SUM(CASE WHEN crpcdate > hspcdate THEN 1 ELSE 0 END) crpc_after_hspc,
       SUM(CASE WHEN crpcdate < hspcdate THEN 1 ELSE 0 END) crpc_before_hspc,
       SUM(CASE WHEN crpcdate = hspcdate THEN 1 ELSE 0 END) same_day,
       COUNT(*) both_present
FROM ${src}.t_enh_prostate_2026m06
WHERE crpcdate IS NOT NULL AND hspcdate IS NOT NULL;

-- D3 (Q16). See C3 - 'Abstraction' absent.
SELECT COUNT(*) abstraction_rows FROM ${src}.t_enh_prostate_drg_epsode_2026m06
WHERE episodedatasource = 'Abstraction';

-- D4 (Q03/Q04). Does the biomarker table carry a test-type or received-date
--     column? DESCRIBE is the legacy-metastore form.
DESCRIBE TABLE ${src}.t_enh_prostate_biomarker_2026m06;

-- D5pre. Complete gene list - run this first, before trusting D5. This query
--     truncates nothing, so it can prove a symbol absent as well as present.
--     Check specifically for: symbols not in either published panel, and
--     aliases of ones that are (MRE11 vs MRE11A, NBS1 vs NBN, FANCD1 vs BRCA2,
--     RAD51D vs RAD51L3). An exact-match panel silently drops an alias; the
--     default 'flatiron_all' mode uses the 19 frozen symbols (Q44).
SELECT UPPER(biomarkername) gene, COUNT(*) n, COUNT(DISTINCT patientid) pts
FROM   ${src}.t_enh_prostate_biomarker_2026m06
GROUP  BY 1 ORDER BY 1;          -- alphabetical, so the whole list is scannable

SELECT COUNT(DISTINCT UPPER(biomarkername)) AS distinct_genes
FROM   ${src}.t_enh_prostate_biomarker_2026m06;

-- D5 (Q05). Panel membership. Confirmed by the 2026-08 D5pre result:
--     19 distinct genes = FDA olaparib mCRPC label (14) U TALAPRO-2 (12),
--     exactly. Nothing outside. PPP2R2A - the one PROfound gene the FDA label
--     omits - is absent from the data too.
--     PASS: the 'OUTSIDE BOTH PANELS' bucket stays empty on every future cut.
SELECT UPPER(biomarkername) gene,
       CASE
         WHEN UPPER(biomarkername) IN ('ATM','BRCA1','BRCA2','CDK12','CHEK2',
                                       'PALB2','RAD51C') THEN 'both panels'
         WHEN UPPER(biomarkername) IN ('BARD1','BRIP1','CHEK1','FANCL',
                                       'RAD51B','RAD51D','RAD54L')
              THEN 'olaparib label only'
         WHEN UPPER(biomarkername) IN ('ATR','FANCA','MLH1','MRE11A','NBN')
              THEN 'TALAPRO-2 only'
         ELSE 'OUTSIDE BOTH PANELS' END panel_membership,
       COUNT(*) n, COUNT(DISTINCT patientid) pts
FROM   ${src}.t_enh_prostate_biomarker_2026m06
GROUP  BY 1,2 ORDER BY panel_membership, n DESC;

-- D5b. What each panel choice costs - patients HRR-positive under each option.
WITH b AS (
  SELECT patientid, UPPER(biomarkername) g
  FROM   ${src}.t_enh_prostate_biomarker_2026m06
  WHERE  LOWER(biomarkerstatus) LIKE '%positive%')
SELECT 'flatiron_all (19 genes)' panel, COUNT(DISTINCT patientid) positive_patients FROM b
UNION ALL
SELECT 'olaparib_label (14)', COUNT(DISTINCT patientid) FROM b
WHERE g IN ('ATM','BARD1','BRCA1','BRCA2','BRIP1','CDK12','CHEK1','CHEK2',
            'FANCL','PALB2','RAD51B','RAD51C','RAD51D','RAD54L')
UNION ALL
SELECT 'talapro2 (12)', COUNT(DISTINCT patientid) FROM b
WHERE g IN ('ATM','ATR','BRCA1','BRCA2','CDK12','CHEK2','FANCA','MLH1',
            'MRE11A','NBN','PALB2','RAD51C')
UNION ALL
SELECT 'brca_only (= BRCA_INDEX)', COUNT(DISTINCT patientid) FROM b
WHERE g IN ('BRCA1','BRCA2');

-- D6 (Q04). Collected-to-result lag, since SPECIMENRECEIVEDDATE does not exist.
SELECT PERCENTILE(DATEDIFF(resultdate, specimencollecteddate), ARRAY(0.5,0.9,0.99)) pctl_days,
       MIN(DATEDIFF(resultdate, specimencollecteddate)) min_days,
       MAX(DATEDIFF(resultdate, specimencollecteddate)) max_days
FROM   ${src}.t_enh_prostate_biomarker_2026m06
WHERE  resultdate IS NOT NULL AND specimencollecteddate IS NOT NULL;

-- D7 (Q07). LABPLA / LABBIL copy-paste slips in the spec.
SELECT LOWER(testbasename) testbasename, testunitscleaned, COUNT(*) n
FROM   ${src}.t_lab_2026m06
WHERE  LOWER(testbasename) IN ('platelets','hemoglobin','bilirubin')
GROUP  BY 1,2 ORDER BY 1,2;

-- D8. REFERENCE COHORT COUNTS. Derived independently of the R build; V12 in
--     03_output_validation_databricks.sql compares the ADS against these.
--     2026-08 RESULT:
--       1 Overall mHSPC     197903      5 L2+ treated mCRPC  28980
--       2 Overall mCRPC     134281      6 L3+ treated mCRPC  16073
--       3 L1+ treated mHSPC  79051      7 L4+ treated mCRPC   8616
--       4 L1+ treated mCRPC  50502      TOTAL ADS ROWS      515406
WITH ms AS (
  SELECT patientid,
         GREATEST(metastaticdiagnosisdate, hspcdate) mhspcdd,
         GREATEST(metastaticdiagnosisdate, crpcdate) mcrpcdd
  FROM   ${src}.t_enh_prostate_2026m06),
lot AS (
  SELECT patientid, linesetting, startdate,
         ROW_NUMBER() OVER (PARTITION BY patientid, linesetting ORDER BY startdate) new_lot_n
  FROM   ${src}.t_enh_prostate_lot_2026m06
  WHERE  linesetting IN ('mHSPC','mCRPC'))
SELECT 1 cohortn, 'Overall mHSPC' cohort, COUNT(DISTINCT patientid) n
FROM   ms WHERE mhspcdd BETWEEN DATE'2011-01-01' AND DATE'2026-04-30'
UNION ALL
SELECT 2, 'Overall mCRPC', COUNT(DISTINCT patientid)
FROM   ms WHERE mcrpcdd BETWEEN DATE'2011-01-01' AND DATE'2026-04-30'
UNION ALL
SELECT 3, 'L1+ treated mHSPC', COUNT(DISTINCT l.patientid)
FROM   lot l JOIN ms m ON m.patientid = l.patientid
WHERE  l.linesetting='mHSPC' AND l.new_lot_n=1
AND    l.startdate BETWEEN DATE'2011-01-01' AND DATE'2026-04-30'
AND    m.mhspcdd  BETWEEN DATE'2011-01-01' AND DATE'2026-04-30'
UNION ALL
SELECT 3 + n.k, CONCAT('L', n.k, '+ treated mCRPC'), COUNT(DISTINCT l.patientid)
FROM   lot l JOIN ms m ON m.patientid = l.patientid
       JOIN (SELECT explode(ARRAY(1,2,3,4)) k) n ON n.k = l.new_lot_n
WHERE  l.linesetting='mCRPC'
AND    l.startdate BETWEEN DATE'2011-01-01' AND DATE'2026-04-30'
AND    m.mcrpcdd  BETWEEN DATE'2011-01-01' AND DATE'2026-04-30'
GROUP  BY n.k
ORDER  BY cohortn;

-- D9. SOURCE CHRONOLOGY. The build assumes progression precedes the end of
--     follow-up and precedes death. Neither is enforced anywhere - PFSDT is
--     taken as recorded - so if the source violates it, the ADS inherits the
--     violation and V4/X03/X04 in the output validation will report it after
--     the fact. Measuring it here says whether that is a build problem or a
--     source problem before the build runs. Not a gate: the number is
--     what the register needs, and the rule is the SME's to set.
SELECT 'progression after death'          what, COUNT(*) n
FROM   ${src}.t_enh_prostate_prog_scled_2026m06 p
JOIN   ${src}.t_mortality_v2_2026m06 m ON m.patientid = p.patientid
WHERE  p.progressiondate > TRY_CAST(m.dateofdeath AS DATE)
UNION ALL
SELECT 'progression after last clinic note', COUNT(*)
FROM   ${src}.t_enh_prostate_prog_scled_2026m06
WHERE  progressiondate > lastclinicnotedate
UNION ALL
SELECT 'progression after MAXINDEX',         COUNT(*)
FROM   ${src}.t_enh_prostate_prog_scled_2026m06
WHERE  progressiondate > DATE'2026-04-30'
UNION ALL
SELECT 'last clinic note after MAXINDEX',    COUNT(*)
FROM   ${src}.t_enh_prostate_prog_scled_2026m06
WHERE  lastclinicnotedate > DATE'2026-04-30'
UNION ALL
SELECT 'death before metastatic diagnosis',  COUNT(*)
FROM   ${src}.t_enh_prostate_2026m06 e
JOIN   ${src}.t_mortality_v2_2026m06 m ON m.patientid = e.patientid
WHERE  TRY_CAST(m.dateofdeath AS DATE) < e.metastaticdiagnosisdate
UNION ALL
SELECT 'LOT starts after death',             COUNT(*)
FROM   ${src}.t_enh_prostate_lot_2026m06 l
JOIN   ${src}.t_mortality_v2_2026m06 m ON m.patientid = l.patientid
WHERE  l.linesetting IN ('mHSPC','mCRPC')
AND    l.startdate > TRY_CAST(m.dateofdeath AS DATE)
ORDER  BY what;


-- D10 (Q37). Sizes the HRR/BRCA temporal conflict resolved by Q37. Under a
--      panel-level date rule, a patient whose nearest-to-index report does not
--      cover BRCA1/2 while an earlier in-window report does can come out
--      BRCA=Positive with HRR=Negative. The build uses one shared winning date
--      for both the HRR and the BRCA call, so they cannot land on different
--      reports. This counts the patients with that shape. Zero means Q37 is
--      cheap; a large number means it is material.
--      The window is anchored on the index date, which this query does not
--      have, so it uses each patient's own report dates. Read as an upper bound.
WITH b AS (
  SELECT patientid, UPPER(biomarkername) gene,
         GREATEST(COALESCE(specimencollecteddate, resultdate),
                  COALESCE(resultdate, specimencollecteddate)) testdt,
         biomarkerstatus
  FROM   ${src}.t_enh_prostate_biomarker_2026m06),
per_pt AS (
  SELECT patientid,
         COUNT(DISTINCT testdt) distinct_report_dates,
         COUNT(DISTINCT CASE WHEN gene IN ('BRCA1','BRCA2') THEN testdt END) brca_dates,
         MAX(CASE WHEN gene IN ('BRCA1','BRCA2')
                   AND LOWER(biomarkerstatus) LIKE '%positive%' THEN 1 ELSE 0 END) brca_pos
  FROM b GROUP BY patientid)
SELECT 'patients with >1 report date'                       what, COUNT(*) n FROM per_pt WHERE distinct_report_dates > 1
UNION ALL
SELECT 'patients whose reports do not all cover BRCA',           COUNT(*) FROM per_pt WHERE brca_dates < distinct_report_dates
UNION ALL
SELECT 'BRCA-positive AND some report lacks BRCA (upper bound)', COUNT(*) FROM per_pt WHERE brca_pos = 1 AND brca_dates < distinct_report_dates
ORDER BY what;
