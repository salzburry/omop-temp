# =============================================================================
# RUN A .sql FILE FROM R, OVER THE BUILD'S OWN CONNECTION
# =============================================================================
#   Rscript validation/run_sql.R qc/08_death_date_formats.sql   (from repo root)
#   Rscript validation/run_sql.R qc/03_cross_variable_rules.sql qc/09_vitals_domain.sql
#
# The .sql files in qc/ and validation/ are written for the SQL editor, with
# ${catalog} / ${schema} / ${ads} / ${src} to substitute by hand. This runs
# them from R instead: same SQL, statement by statement, no rewriting. The
# placeholders are filled from the variables 00_setup.R itself sets, so this
# cannot check a different table from the one the build wrote.
#
# The namespace contract, which every .sql file must follow: ${schema} is the
# personal OUTPUT schema and qualifies only ${schema}.${ads}; ${src} is the
# SOURCE schema and qualifies only source tables. The offline harness fails
# if the preflight file breaks this.
#
# It does not translate SQL into dplyr: a translation is a second
# implementation that can disagree with the first; executing the same text
# cannot.
#
# RENDER_ONLY=1 skips the connection and prints the substituted statements,
# for pasting into the SQL editor with the schema already filled in.
# =============================================================================

files <- commandArgs(trailingOnly = TRUE)
if (!length(files) && exists("sql_files")) files <- sql_files
if (!length(files))
  stop("usage: Rscript validation/run_sql.R <file.sql> [<file.sql> ...]",
       call. = FALSE)
missing_files <- files[!file.exists(files)]
if (length(missing_files))
  stop("no such file: ", paste(missing_files, collapse = ", "), call. = FALSE)

render_only <- nzchar(Sys.getenv("RENDER_ONLY"))
if (!render_only) {
  if (!exists("con")) {
    message("no open connection - sourcing code/modules/00_setup.R")
    source("code/modules/00_setup.R")
  }
  stopifnot(exists("con"), exists("output_catalog"), exists("personal_schema"),
            exists("output_table"), exists("source_schema"))
}

# In render mode there is no session to read, so fall back to the values
# 00_setup.R pins. If they move there, they move here.
SUBS <- c("${catalog}"    = get0("output_catalog",  ifnotfound = "hive_metastore"),
          "${schema}"     = get0("personal_schema", ifnotfound = "osk02156"),
          "${ads}"        = get0("output_table",    ifnotfound = "rwdp_pros_pano_2026m06"),
          "${src}"        = get0("source_schema",   ifnotfound = "clnprw_flatiron_pano_pros_use"))

# One statement ends where a line ends in ";". A ";" mid-line never terminates
# a statement here: across the corpus it occurs only inside quoted label text
# and in comments. Inline "--" comments occur only after code, never inside a
# quoted string, so stripping from "--" is safe.
read_statements <- function(path) {
  ln <- readLines(path, warn = FALSE)
  ln <- sub("--.*$", "", ln)
  ln <- ln[nzchar(trimws(ln))]
  stmts <- character(0); buf <- character(0)
  for (l in ln) {
    buf <- c(buf, l)
    if (grepl(";\\s*$", l)) {
      stmts <- c(stmts, sub(";\\s*$", "", paste(buf, collapse = "\n")))
      buf <- character(0)
    }
  }
  if (length(buf)) stmts <- c(stmts, paste(buf, collapse = "\n"))
  stmts
}

n_failed <- 0L
for (f in files) {
  cat("\n==== ", f, " ====\n", sep = "")
  stmts <- read_statements(f)
  for (nm in names(SUBS)) stmts <- gsub(nm, SUBS[[nm]], stmts, fixed = TRUE)
  left <- unique(unlist(regmatches(stmts, gregexpr("\\$\\{[a-z_]+\\}", stmts))))
  if (length(left))
    stop(f, " uses a placeholder this runner does not know: ",
         paste(left, collapse = ", "), call. = FALSE)
  cat(length(stmts), " statement(s)\n", sep = "")

  for (i in seq_along(stmts)) {
    s     <- stmts[[i]]
    first <- trimws(strsplit(s, "\n")[[1]][1])
    cat("\n-- [", i, "/", length(stmts), "] ", first, "\n", sep = "")
    if (render_only) { cat(s, ";\n", sep = ""); next }

    returns_rows <- grepl("^(SELECT|WITH|DESCRIBE|SHOW|EXPLAIN)\\b",
                          toupper(first))
    if (!returns_rows) {
      # USE and friends set connection state; running on after one fails would
      # aim every later statement at the wrong schema, so those stop hard.
      DBI::dbExecute(con, s)
      cat("ok\n")
      next
    }
    res <- tryCatch(DBI::dbGetQuery(con, s), error = function(e) e)
    if (inherits(res, "error")) {
      n_failed <- n_failed + 1L
      cat("FAILED: ", conditionMessage(res), "\n", sep = "")
      next
    }
    cat(nrow(res), " row(s)\n", sep = "")
    if (nrow(res)) print(utils::head(res, 100), row.names = FALSE)
    if (nrow(res) > 100)
      cat("... ", nrow(res) - 100, " more row(s) not shown - add a LIMIT or ",
          "tighten the WHERE if you need them all\n", sep = "")
  }
}

if (!render_only) {
  cat("\n", if (n_failed) paste0("DONE - ", n_failed, " statement(s) FAILED\n")
            else "DONE - all statements ran\n", sep = "")
  if (n_failed) quit(status = 1L)
}
