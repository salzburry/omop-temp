# =============================================================================
# Fills the Commit column of the index table in docs/DEVIATIONS.md
# =============================================================================
#   Rscript validation/make_traceability.R
#
# Every decision id is named in at least one commit message, so the mapping is
# derived from history rather than typed. The cell records the most recent
# commit naming the row, plus how many commits touched it.
#
# One-commit lag: this run cannot see the commit that will contain its own
# output, so a row settled in commit N is only recorded correctly after a
# re-run at commit N+1. Re-run whenever rows are resolved.
#
# QC evidence is not derived here. It is written by hand in the detail section
# when evidence exists, and reads PENDING until then - a blank field would read
# as "not applicable", which for a build that has never run is the wrong claim.
# =============================================================================

source("validation/read_deviations.R")

log <- system2("git", c("log", "--format=%H%x1f%B%x1e", "--reverse"), stdout = TRUE)
log <- paste(log, collapse = "\n")

chain <- list()
for (rec in strsplit(log, "\x1e", fixed = TRUE)[[1]]) {
  if (!grepl("\x1f", rec, fixed = TRUE)) next
  parts <- strsplit(rec, "\x1f", fixed = TRUE)[[1]]
  sha   <- substr(trimws(parts[1]), 1L, 7L)
  body  <- if (length(parts) > 1L) parts[2] else ""
  ids   <- unique(regmatches(body, gregexpr("\\bQ[0-9]{2}\\b", body))[[1]])
  for (id in sort(ids)) chain[[id]] <- c(chain[[id]], sha)
}

ln  <- readLines(DEVIATIONS_MD, warn = FALSE)
reg <- read_deviations()

missing <- setdiff(reg$id, names(chain))
if (length(missing)) {
  stop("no commit message names these decisions: ", paste(missing, collapse = ", "),
       "\nName the row in a commit message, or record the commit by hand.",
       call. = FALSE)
}

changed <- 0L
for (i in seq_len(nrow(reg))) {
  cc  <- chain[[reg$id[i]]]
  val <- if (length(cc) == 1L) cc[1] else
    sprintf("%s (settling commit; %d commits name this row, first %s)",
            cc[length(cc)], length(cc), cc[1])
  if (!identical(reg$commit[i], val)) changed <- changed + 1L
  ln[reg$line[i]] <- sprintf("| %s | %s | %s | %s | %s | %s |",
                             reg$id[i], reg$variable[i], reg$affects[i],
                             reg$approved_by[i], reg$status[i], val)
}

writeLines(ln, DEVIATIONS_MD)
cat("traceability: ", nrow(reg), " decisions, ", changed, " updated\n", sep = "")
cat("NOTE: the commit containing THIS run is not visible to it. Re-run after\n")
cat("committing if a row was resolved in the same commit as its backfill.\n")
