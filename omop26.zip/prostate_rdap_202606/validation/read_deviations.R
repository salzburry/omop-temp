# =============================================================================
# Reads docs/DEVIATIONS.md
# =============================================================================
# The deviations live in one markdown file: an index table, then one detail
# section per decision. Both the coverage gate and the traceability backfill
# read it, so the parser is here rather than copied into each.
#
# Sourced, not run:  source("validation/read_deviations.R")
# =============================================================================

DEVIATIONS_MD <- "docs/DEVIATIONS.md"
DEV_HEADER    <- "| ID | Variable | Affects | Approved by | Status | Commit |"

# Line numbers of the index table's data rows, in file order.
deviations_index_lines <- function(ln) {
  hdr <- which(trimws(ln) == DEV_HEADER)
  if (length(hdr) != 1L)
    stop("docs/DEVIATIONS.md: expected exactly one index table header, found ",
         length(hdr), call. = FALSE)
  i <- hdr + 2L                       # skip the |---|---| separator
  out <- integer(0)
  while (i <= length(ln) && startsWith(trimws(ln[i]), "|")) {
    out <- c(out, i)
    i <- i + 1L
  }
  out
}

# The index table as a data frame, validated against the detail sections.
read_deviations <- function(path = DEVIATIONS_MD) {
  ln  <- readLines(path, warn = FALSE)
  idx <- deviations_index_lines(ln)

  split_row <- function(s) {
    cells <- strsplit(sub("\\|\\s*$", "", sub("^\\s*\\|", "", s)), "|", fixed = TRUE)[[1]]
    trimws(cells)
  }
  m <- do.call(rbind, lapply(ln[idx], split_row))
  if (ncol(m) != 6L)
    stop("docs/DEVIATIONS.md: index rows must have 6 cells, found ", ncol(m),
         call. = FALSE)

  d <- data.frame(id = m[, 1], variable = m[, 2], affects = m[, 3],
                  approved_by = m[, 4], status = m[, 5], commit = m[, 6],
                  line = idx, stringsAsFactors = FALSE)

  bad <- d$id[!grepl("^Q[0-9]{2}$", d$id)]
  if (length(bad))
    stop("docs/DEVIATIONS.md: bad ids: ", paste(bad, collapse = ", "), call. = FALSE)
  if (anyDuplicated(d$id))
    stop("docs/DEVIATIONS.md: duplicate ids: ",
         paste(unique(d$id[duplicated(d$id)]), collapse = ", "), call. = FALSE)

  # Every indexed decision needs a detail section, and every section an entry.
  # Only `### Qnn` counts: matching every `###` would let an ordinary
  # sub-heading elsewhere in the file read as a decision with no index row.
  heads <- sub("^### (Q[0-9]{2}) .*$", "\\1",
               grep("^### Q[0-9]{2} ", ln, value = TRUE))
  if (!setequal(heads, d$id))
    stop("docs/DEVIATIONS.md: index and detail sections disagree. Index only: ",
         paste(setdiff(d$id, heads), collapse = ", "), ". Detail only: ",
         paste(setdiff(heads, d$id), collapse = ", "), call. = FALSE)

  d
}
