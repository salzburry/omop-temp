# Open questions

**Part A is everything still unanswered, grouped by who can answer it.** Part B,
below, is how to run the build.

**Every row here is already decided and already implemented.** The rulings are
in `DEVIATIONS.md` and the rule each produced is in `SPEC.csv`; nothing below
blocks the build from running, and nothing is being re-opened.

What is outstanding is **ratification**, which is a different thing from a
decision. A1 and A2 rows read `RESOLVED` in the register because the data
product owner approved them. They are listed here because an owner cannot
ratify a clinical judgement on a clinician's behalf, and because two of them
are release-procedure calls that a reviewer should see before signing. Read
each as *owner-approved, ratification pending* - not as an open question.

---

## A1. For the clinical SME

Five items. Everything else in this file is either operational or answered by
running the build.

| Row | Question | Blocks sign-off? |
|---|---|---|
| Q03, Q20, Q29, Q37 | These four biomarker rulings reached us second-hand, through the data product owner: test type stays `Unknown`; the `[-30, +7]` window beats "any time prior to index"; `Negative` outranks `VUS` across genes; one shared winning test date for HRR and BRCA. Did you rule them, and may we record your name against them? | Yes - a release record needs a named clinician |
| Q68 | Height and weight are admitted at any non-null value, because that is what the spec asks for. A negative weight therefore delivers a negative `BMI`, banded `Underweight`. Every step follows the spec. The result is not a measurement. Add a plausibility range on `WEIGHT` and `HEIGHT`, or accept? | Yes |
| Q34 | `PFS` can exceed `OS`, because a progression can be recorded after the death date. The spec says to treat this as a data limitation and take no action, which we have. At most 896 source rows of 231,261 are affected, and the delivered count is lower. Confirm the analysis team can live with it. | Yes |
| Q38 | 10,170 treated patients are indexed on a line of therapy that began **before** the disease milestone that admitted them to the cohort - 6.1% of L1+ mHSPC, 10.5% of L1+ mCRPC. Their baseline windows, `OS`, `TTNT` and `PFS` all anchor on that earlier date. Accepted, not repaired. Confirm, and confirm it reaches the data dictionary. | Yes |
| Q52 | About 17% of Overall mHSPC index dates are not day-level. A year-level milestone resolves to 1 January, so `OS`, `FUDUR` and every index window can be up to a year early for those patients. Confirm this is acceptable and belongs in the data dictionary. | Yes |

---

## A2. For the data product owner

| Row | Question | Blocks sign-off? |
|---|---|---|
| Q43 | The build writes the deliverable directly under a stable name with `replace = TRUE`. A re-run silently overwrites the exact table QC just reviewed, and nothing in the QC pack records which build produced it. Add a build ID, or accept? Affects every run, not rare data. | Yes |
| Q16 | `max_drug_ep_abstracted_dt` is NULL for every patient - its source value does not exist in this cut. Ship an empty column, or drop it? Dropping takes the contract from 190 columns to 189 and breaks anyone already coding against it. | Yes |

---

## A3. Answered by running the build, not by a person

No judgement needed, and the query is named. Four are counts that a zero closes. Q70 is not a count - it is a review-and-commit step: the first run captures the column types, somebody reads them, and committing the file is what pins them.

| Row | What to count | Query |
|---|---|---|
| Q66 | Death dates whose length is neither 4 nor 7. Those become NULL, which turns a dead patient into a censored one. | `qc/08` Q08b |
| Q67 | Blood pressure readings that are positive but not whole numbers. Those now read `Unknown`. | `qc/09` Q09a |
| Q68 | Height and weight records that are zero or negative - the population behind the A1 question above. | `qc/09` Q09b, Q09c |
| Q69 | Whether `LABHEM` is populated at all. If every row reads `Missing`, the unit filter matched nothing. | `qc/03` R54 |
| Q70 | The captured column types. Review `qc/qc_column_types.csv` and commit it - nothing is pinned until you do. | `qc/07` |

Answered by the 2026-08-08 run: **Q65 / Q78** (B13-B16 passed; B17 passed after the comma-only split correction - the Q78 addendum records it) and **Q13** (`qc/05` C14a-j all MATCH). Answered by direct query 2026-08-09: **Q73** (zero NULL-named lines in either setting - R55 and S6 stay as the refresh check) and the two audit follow-ups now registered as **Q80** (lab name case-fold, value-neutral) and **Q81** (CSD latent NULL path, unreachable this cut).

---

## A4. Not questions - things to tell downstream users

These belong in the data dictionary. They are settled; they just have to be said.

| Row | What to say |
|---|---|
| Q58 | For every `LAB*` and `BP`, `Unknown` is no longer a data-quality signal. It mixes a few percent with an unusable baseline record and about 39% who were simply tested later. `Present` is the only positive statement. |
| Q60 | `PRIOR_NHA_ADT` is broader than its name. Any NHA plus a second drug sets it, whether or not that drug is an ADT. An NHA with chemotherapy counts. |
| Q38, Q52 | Both A1 rows above also belong here once confirmed - the pre-milestone index lines and the coarse index dates. |

---

## A5. What the checks cannot tell you

Not questions, and not fixable by running anything. Read them before treating a
PASS as coverage.

- `qc/00_coverage.R` proves a decision is **named** by a check. It cannot prove
  the check is right. Four checks passed it while testing the wrong thing.
- The harness proves `SPEC.csv` carries the 190 delivered columns in order, each
  with a definition. It cannot prove a definition still **matches** the code.
  That drifted once already, on the BMI band. Change a derivation and its
  `SPEC.csv` row in the same commit.
- Three things cannot be built until the first run supplies a baseline: a
  short-build tolerance (the pre-write gate rejects only an empty cohort), source
  column **types** in the input contract, and fail-closed allow-lists for the
  exact-match categoricals like `GLEASONSCORE`.

---

## Status

First full run completed 2026-08-08: the build wrote 515,406 rows, all twelve
preflight B-gates passed (B17 after the comma-only correction, Q78 addendum),
the column contract check passed (V27 exact name and order, V21 no struck-out
variable), `qc/05` reported 35 of 37 MATCH - the two DIFFERs were a
numeric-vs-string comparison artefact in the checks themselves, since fixed,
and a direct SQL diff of both columns found zero disagreeing rows - and
`qc/07` captured the column types - `qc/qc_column_types.csv` is awaiting review and commit (Q70). Still
unrun: the 44 V-gates (`validation/03`), the null sweep (`03b`), `qc/01`-`04`,
`qc/06`, `qc/08`-`09` and the sizing queries (`validation/05`). Decisions those
would evidence still read PENDING - `DEVIATIONS.md` holds the per-row state,
and is the only place that count is kept.

---

# Part B. How to run the build

### Two copies, and what each one holds

The production copy is `docs/` and `code/`. Everything that CHECKS the build -
the release gates, the QC pack, the offline harness, the contracts - stays in
the build repository.

| | Production copy | Build repository |
|---|---|---|
| Holds | `docs/`, `code/` | all of it, including `validation/` and `qc/` |
| Can | run the build | run the build, and verify what it produced |
| Cannot | verify anything | - |

So read this section twice: once for what runs where you are, once for what has
to happen before the delivered table is trustworthy.

**The build does not read `validation/` or `qc/`.** It is self-contained: the
twelve preflight gates are inside `code/modules/00_setup.R`, and the
190-column allowlist is inside `code/modules/06_assemble.R`. The production
copy will build correctly. It will not tell you whether the result is right.

One leftover to expect: on success the build prints *"This table is LIVE - run
the output validation now"*. That means
`validation/03_output_validation_databricks.sql`, in the build repository. It
is not in the production copy.

**If you want the gates alongside the code,** four files are enough for all
three fail-closed gates, and none of them needs the rest of `validation/`:

```
validation/00_column_contract.csv
validation/03_output_validation_databricks.sql
validation/03b_null_sweep.sql
validation/04_column_contract_check.R
```

### Names to substitute

| Token | Value |
|---|---|
| `${catalog}` | `hive_metastore` |
| `${src}` | `clnprw_flatiron_pano_pros_use` (source tables only) |
| `${schema}` | `osk02156` (the personal OUTPUT schema, pinned in `00_setup.R`) |
| `${ads}` | `rwdp_pros_pano_2026m06` |

These are text substitutions, not SQL parameters - `:param` binds values, not
object names. In a notebook where `${...}` still resolves, set the widgets.
Anywhere else, find and replace.

Run every command from the root of whichever copy holds the file.

---

### Runs from the production copy

**1. The build.**

```
Rscript code/prostate_rdap_202606.R
```

Writes 42 stage tables, then `${schema}.${ads}`, then a run manifest to
`RUN_MANIFEST.txt`.

Things to know:

- **No manifest means the run did not finish.** The driver deletes any previous
  one before it starts, so a stale file cannot look current.
- **The twelve preflight gates run inside the build** and stop it before
  anything is written. They cover the source: duplicate grain, null and tied
  LOT start dates, conflicting death dates, `LINESETTING` exact form,
  `LINENAME` separators and repeated drug tokens.
- **The pre-write gate counts the seven cohort stages.** If any is empty the
  build refuses and leaves the previous table untouched.
- **The table is LIVE the moment the build finishes** (Q27). There is no
  staging copy and no publish step. Until the gates below have run, the
  delivered table is unvalidated and consumers can already read it.
- For a non-default HRR panel, set `RDAP_HRR_PANEL` to `olaparib_label` or
  `talapro2` first. It writes to its own table name, so it cannot land on the
  governed one (Q05).

---

### Runs from the build repository

**Before the build**, if you have the choice - both are free and neither needs
a database connection for step 2:

| # | Command | Stop if |
|---|---|---|
| 2 | `Rscript validation/02_offline_build_check.R` | Anything other than `PASS`. Renders all 43 stages against a simulated Spark backend, so it catches a bad column reference, a broken lazy chain, an R helper leaking into SQL, and any drift between the generated files, `SPEC.csv` and the column contract. No database needed. |
| 3 | `Rscript qc/00_coverage.R` | Anything other than `PASS`. Every decision that changes output must be named by a check and carry an approver. |
| 4 | `validation/01_preflight_databricks.sql` | Any B-gate returns rows. The build repeats the B-gates itself, but reading them first tells you *why* before you spend the build. Sections A, C and D are extra: schema, the value sets the code branches on, and evidence for open decisions. |

**Release gates - all three must pass.** Fail-closed. A failure means drop or
rebuild the table.

| # | Command | Passes when |
|---|---|---|
| 5 | `validation/03_output_validation_databricks.sql` | All 44 V-gates return zero rows. |
| 6 | `validation/03b_null_sweep.sql` | No unexpected all-null or constant column. Nine are waived by name. |
| 7 | `Rscript validation/04_column_contract_check.R` | 190 columns, same names, same order. |

**QC pack.** Not fail-closed. These produce numbers somebody has to read.

| # | Command | What it gives you |
|---|---|---|
| 8 | `qc/01_variable_profile.sql` | Null rate and cardinality, 190 columns x 7 cohorts. |
| 9 | `qc/02_code_label_agreement.sql` | All 25 label/code pairs, both directions. |
| 10 | `qc/03_cross_variable_rules.sql` | 62 consistency rules, R01-R56. |
| 11 | `qc/04_cohort_attrition.sql` | The waterfall from source to each cohort. |
| 12 | `Rscript qc/05_independent_rederivation.R` | 37 checks that rebuild variables from source in hand-written SQL and compare. A difference means one of the two is wrong. |
| 13 | `qc/06_golden_patients.sql` | End-to-end trace for a handful of patients. **Someone has to read these.** |
| 14 | `Rscript qc/07_type_contract.R` | First run *captures* types to `qc/qc_column_types.csv`. Review it, commit it, re-run - then it *checks* them. Nothing is pinned until you do (Q70). |
| 15 | `qc/08_death_date_formats.sql` | Sizes the Q66 exposure: death dates that fall to NULL. |
| 16 | `qc/09_vitals_domain.sql` | Sizes the Q67 and Q68 rulings. |
| 17 | `validation/05_sizing_queries.sql` | S1-S6, the counts sections 2 and 4 are waiting on. |
| 18 | `validation/04_open_question_queries.sql` | The five rows that close on a query with no judgement call. |

Every `.sql` file above runs two ways: paste it into the SQL editor with the
placeholders substituted, or run it from R with them filled from the build's
own session - `Rscript validation/run_sql.R qc/08_death_date_formats.sql`
(any number of files; `RENDER_ONLY=1` prints paste-ready SQL instead of
executing). The tokens mean one thing everywhere: `${catalog}` =
`hive_metastore`; `${schema}` = the personal **output** schema, qualifying
only `${schema}.${ads}`; `${src}` = the **source** schema
`clnprw_flatiron_pano_pros_use`.

---

### After the run

1. Keep `RUN_MANIFEST.txt`, the gate output from steps 5-7, and the QC pack
   from steps 8-18. That set is the release record.
2. Fill the **QC evidence** line in `DEVIATIONS.md` for every decision the run
   actually evidenced. It reads `PENDING` until then, which is the honest
   default - a blank would read as "not applicable".
3. Answer what the run answers: sections 2 and 4 name the query for each.
4. `Rscript validation/make_traceability.R` to refresh the commit column, then
   commit. It cannot see the commit containing its own output, so re-run it
   once more after that if a decision settled in the same commit.
5. Tell downstream users the three things in section 3. That belongs in the
   data dictionary, not only here.

### Regenerating the generated files

Three files are generated, and the offline harness regenerates and diffs them,
so a hand edit fails the build check. Edit the source, then regenerate:

| File | Command |
|---|---|
| `validation/03b_null_sweep.sql` | `Rscript validation/make_null_sweep.R` |
| `qc/01_variable_profile.sql`, `qc/02_code_label_agreement.sql` | `Rscript qc/make_qc_sql.R` |

Both read `validation/00_column_contract.csv`. Change a column there and both
must be regenerated.
