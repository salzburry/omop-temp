# RWDP — prostate 202606: code and tests

From commit `64c959d`, platform VERSION `1.48.0`. Code, tests and the config packs they read.
No workbooks, no spec reference material, no restricted output.

## Run it

```bash
pip install pyyaml openpyxl jsonschema
cd platform
for t in tests/test_*.py; do python3 "$t"; done     # pure-Python suites
python3 tests/test_r_parity.py                       # needs Rscript
```

Add `pip install pyspark` (Java 17 or 21 on PATH) for the two Spark suites, which are the slow ones —
each starts a local JVM and runs the full cohort build. Everything else takes seconds.

The gate tools run from the package ROOT, not `platform/` — they emit root-relative pack paths:

```bash
python3 platform/tools/repo_hygiene.py --check
for t in $(python3 platform/tools/product_gates.py --list-tests); do python3 "$t"; done
python3 platform/tools/source_manifest.py --all --check
```

Build the prostate ADS with no cluster, on synthetic in-memory sources, through the production entry
point (needs ~4 GB free for the 7-cohort union):

```bash
python3 platform/tools/local_smoke.py products/oncology/prostate/202606
```

That proves the configuration assembles and executes. It says nothing about delivered data and is not
evidence at any gate.

## Verified in this package

| Suite | Result |
|---|---|
| pure-Python (30 of 32) | pass |
| `test_r_parity` | 31/31 |
| `test_stages_spark` | 31/31 |
| `test_smoke_spark` | pass |

**Two suites fail here by construction: `test_spec_pipeline` and `test_spec_slice`.** Both call Gate 1
(`source_manifest --all --check`), which verifies that every source material a pack registers at an
in-repo path actually exists. The ovarian pack registers a program-specification workbook, and
workbooks were excluded from this package. Nothing is wrong with the code — the gate is doing its job
on a deliberately incomplete input. Copy that one `.xlsx` back into
`products/oncology/oc/202606/prog_spec/reference/` and both pass.

The package is a git repository with a single commit. That is not decoration: `repo_hygiene` reads the
git INDEX and RAISES when git cannot be read, rather than returning an empty list — an empty list
would report a clean repository, which is the one answer it may not invent. Two suites check
commit-bound evidence and need it.

## Deploying

`platform/tools/deploy_tree.py` builds the runtime tree — an allowlist of the engine, the Databricks
entry point, only the tools that entry point transitively imports, the pack's active config graph and
the shared assets:

```bash
python3 platform/tools/deploy_tree.py --out build/deploy \
        --product products/oncology/prostate/202606 --evidence-out build/evidence
python3 platform/tools/deploy_tree.py --check-tree build/deploy
```

It deploys nothing and runs nothing — it copies files into a local directory.

**This pack is not releasable.** The framework derives that from Gates 1–4; it is not a flag anyone
sets. The authoritative workbook is not supplied (Gate 1 pending), the contract is
`coverage_complete` rather than approved (Gate 2), and the configuration is `draft` (Gate 4). Jobs are
paused, source preflight stops on the recorded B2/B3 blockers before reading data, and the delivery
bindings are unset. A run may build and stage; it may not publish, and the runtime enforces that off
the recorded verdict.

## Where things are

| Path | What |
|---|---|
| `platform/engine/` | the shared Python engine |
| `platform/engine-r/` | the R engine — compiles the same config to byte-identical Spark SQL |
| `platform/tools/` | gate CLIs, the spec pipeline, packaging |
| `platform/tests/` | the suites |
| `products/oncology/prostate/202606/` | the pack under test |
| `governance/` | the six gates, schemas, sheet and domain maps |
| `docs/ENGINEERING.md` | shared definitions, multi-tumour rules, verification commands |
