# Databricks notebook source
# MAGIC %md
# MAGIC # RWDP build job — shared, tumor-agnostic
# MAGIC Thin entry point for ANY tumor: read job/widget params, load that tumor's
# MAGIC `config/data_product.yaml` (with overrides), run the locked shared PySpark engine
# MAGIC (`platform/engine`), write `{output_schema}.{output_table}`.
# MAGIC
# MAGIC Behaviour lives in each tumor's `config/`, `variables/`, `codelists/`. Switch tumor by
# MAGIC pointing `config_path` at a different tumor; switch snapshot via `refresh`. No code change.
# MAGIC Deployed via `databricks.yml` (one bundle, `tumor_slug` parameter).

# COMMAND ----------
import sys
from pathlib import Path

# Parameters (Databricks job params / notebook widgets).
dbutils.widgets.text("config_path", "", "Path to a tumor's config/data_product.yaml")    # noqa: F821
dbutils.widgets.text("spec_version", "", "Spec version to build (CalVer e.g. 202603); 'current'/blank = the tumor's registry current_spec_version")  # noqa: F821
dbutils.widgets.text("framework_root", "", "Path to platform/ (engine). Derived if blank")  # noqa: F821
dbutils.widgets.text("refresh", "", "Snapshot suffix (overrides run.refresh)")            # noqa: F821
dbutils.widgets.text("source_schema", "", "Source schema (overrides run.source_schema)")  # noqa: F821
dbutils.widgets.text("output_schema", "", "Output schema (overrides run.output_schema)")  # noqa: F821
dbutils.widgets.text("reference_table", "", "Original ADS to golden-compare (optional)")  # noqa: F821
dbutils.widgets.text("tumor", "", "Tumor FOLDER SLUG (e.g. prostate); resolved to the registry code (mcrpc). Derived from the config folder if blank")  # noqa: F821
dbutils.widgets.text("git_commit", "", "Git SHA of the engine/spec (for the manifest)")  # noqa: F821
dbutils.widgets.text("release_evidence_sha256", "", "sha256 of the deployed RELEASE_EVIDENCE.yaml, printed by deploy_tree.py. Detached because tree_sha256 cannot cover the file it lives in. Defence in depth, NOT a signature: it fails a run whose digest someone else printed, and does not constrain whoever holds the deploy credentials")  # noqa: F821
dbutils.widgets.text("artifact_root", "", "Durable dir for manifest/QC/dictionary/TFL artifacts (e.g. a UC Volume)")  # noqa: F821
dbutils.widgets.text("env", "dev", "Bundle target (dev|prod); prod HARD-FAILS a placeholder artifact_root")  # noqa: F821
dbutils.widgets.text("allow_governed_waiver", "", "Set true to waive the prod/active git_commit+reference_table gates (smoke tests)")  # noqa: F821
dbutils.widgets.text("run_id", "", "Databricks job run id ({{job.run_id}}); joins git_commit into a build_id UNIQUE PER RUN")  # noqa: F821

config_path = dbutils.widgets.get("config_path")          # noqa: F821
if not config_path:
    raise ValueError("config_path is required (path to a tumor's config/data_product.yaml).")

# The shared engine lives in platform/ at the repo root (NOT under products/, NOT in the tumor folder).
framework_root = dbutils.widgets.get("framework_root")    # noqa: F821
if not framework_root:
    # config_path = <repo>/products/<family>/<slug>/<spec_version>/config/data_product.yaml -> <repo>/platform
    framework_root = str(Path(config_path).resolve().parents[5] / "platform")
sys.path.insert(0, framework_root)

from engine.config import load_config, load_yaml, merged_raw, shared_asset  # noqa: E402
from engine.validate import check, preflight                           # noqa: E402
from engine.build_ads import build                                    # noqa: E402
from engine.qc import (run_qc, run_source_qc, qc_gate, source_qc_gate, # noqa: E402
                       qc_thresholds)
from engine.golden import run_golden, golden_gate, golden_thresholds  # noqa: E402
from engine.refresh import build_manifest, write_manifest, release_dir  # noqa: E402
from engine.qc_report import render as render_qc_report               # noqa: E402
from engine import tfl as tfl_engine, dictionary as dict_engine        # noqa: E402
from engine import release as rel                                      # noqa: E402
from engine import audit                                               # noqa: E402
from engine.config import product_config                              # noqa: E402

# COMMAND ----------
# "One job, any tumor": the bundle builds config_path from --var spec_version, whose default is the
# SENTINEL `current` (not a hard-coded version), so the one default works for every tumor. When the
# constructed config_path doesn't exist, resolve by intent — NEVER silently fall back on an explicit version:
#   - spec_version = current | "" (sentinel)  -> build the tumor's registry current_spec_version
#     (the cross-tumor convenience: --var tumor_slug=oc resolves oc's own current, not prostate's).
#   - spec_version = an EXPLICIT version       -> use that pack; if its folder is MISSING, FAIL LOUD.
#     product_config() -> product_dir() rejects a version the registry doesn't declare (KeyError naming
#     the known set), so a typo like 202605 fails here instead of quietly building current.
# An explicit, EXISTING version short-circuits (the constructed config_path already exists -> used as-is).
spec_version = (dbutils.widgets.get("spec_version") or "").strip()   # noqa: F821
if not Path(config_path).exists():
    products_root = Path(framework_root).parent / "products"
    _slug = dbutils.widgets.get("tumor") or Path(config_path).resolve().parents[2].name   # noqa: F821
    if spec_version.lower() in ("", "current"):
        config_path = str(product_config(products_root, _slug))      # registry current_spec_version
        print(f"(spec_version='{spec_version or 'current'}' -> {_slug} registry current: {config_path})")
    else:
        # Validates the version against the registry lineage (KeyError + known set on a typo); a
        # declared-but-unmaterialized version trips the existence check below. No silent fallback.
        config_path = str(product_config(products_root, _slug, spec_version=spec_version))
        if not Path(config_path).exists():
            raise FileNotFoundError(
                f"spec_version '{spec_version}' for tumor '{_slug}' -> {config_path} does not exist "
                "(it is a registry-declared version but its pack isn't materialized). Create the pack, "
                "or pass spec_version=current to build the registry-current version.")

overrides = {
    "run.refresh": dbutils.widgets.get("refresh"),                # noqa: F821
    "run.source_schema": dbutils.widgets.get("source_schema"),    # noqa: F821
    "run.output_schema": dbutils.widgets.get("output_schema"),    # noqa: F821
}
cfg = load_config(config_path, overrides=overrides)

print(f"Product : {cfg.raw['name']}  version {cfg.version}")
print(f"Engine  : {framework_root}")
print(f"Refresh : {cfg.refresh}")
if cfg.source_union:     # under a union, run.source_schema is unused -> show the real member schemas
    members = ", ".join(f"{m.get('flag')}={m.get('schema')}" for m in cfg.source_union.get("members", []))
    print(f"Sources : source_union [{members}]  ->")
else:
    print(f"Sources : {cfg.source_schema}  ->")
for name in cfg.sources:                      # the ACTUAL fqn(s) — one per member schema under a union
    for fqn in cfg.source_fqns(name):
        print(f"          {name:14s} {fqn}")
print(f"Output  : {cfg.output_fqn}  (mode={cfg.write_mode})")
print(f"Cohorts : {', '.join(c['id'] for c in cfg.cohorts)}")

# COMMAND ----------
import hashlib   # noqa: E402
import json   # noqa: E402
from pyspark.sql import functions as F   # noqa: E402

repo_root = Path(framework_root).parent           # platform/ -> repo root
products_root = repo_root / "products"            # governed products live under products/
tumor_slug = dbutils.widgets.get("tumor") or Path(config_path).resolve().parents[2].name   # noqa: F821  (<slug> above <spec_version>/config/)
# Resolve the registry tumor CODE from the folder slug: the master catalog's applies_to + the manifest
# key on the CODE (e.g. mcrpc), NOT the folder slug (prostate). Using the slug here would make the
# dictionary filter drop every applies_to:[<code>] variable (gleason/psadiag/mcrpc/ttd/…) while still
# reporting success. The folder slug is used only for filesystem paths.
_reg = (load_yaml(str(shared_asset(products_root, "registry"))) or {}).get("tumors", [])
tumor = next((t["code"] for t in _reg if t.get("slug") == tumor_slug), tumor_slug)   # code for catalog/manifest
family = next((t.get("family", "oncology") for t in _reg if t.get("slug") == tumor_slug), "oncology")  # ledger path segment

# build_id — minted ONCE up front, UNIQUE PER RUN: the git SHA (reproducibility) joined to the
# Databricks job run id (or a UTC timestamp when run outside a job). git_commit ALONE is not unique —
# a rerun of the same commit would reuse it and overwrite the live versioned table — so the run id /
# timestamp guarantees a same-commit, same-refresh RERUN mints a NEW versioned table AND a NEW
# (build-scoped) artifact dir, never overwriting a live release or a prior run's evidence.
from datetime import datetime, timezone   # noqa: E402
_sha = (dbutils.widgets.get("git_commit") or "").strip()[:12]   # noqa: F821
_run = (dbutils.widgets.get("run_id") or "").strip()            # noqa: F821  Databricks {{job.run_id}}
build_id = f"{_sha or 'nogit'}_{_run or datetime.now(timezone.utc).strftime('%Y%m%dt%H%M%S')}"

# artifact_root is BUILD-SCOPED (…/<tumor>/<refresh>/<build_id>): each run's manifest/QC/dictionary/
# dashboard/TFL evidence lands in its OWN dir, so a rerun never overwrites a prior run's audit record.
artifact_root = ((dbutils.widgets.get("artifact_root")   # noqa: F821
                  or str(repo_root / "_artifacts" / tumor_slug / cfg.refresh)) + f"/{build_id}")
print(f"Build id: {build_id}  (confirm a real run id, not the literal token; artifacts -> {artifact_root})")
env = (dbutils.widgets.get("env") or "dev").lower()      # noqa: F821

# RELEASABILITY IS DERIVED FROM EVIDENCE, NOT READ FROM A STATUS FIELD. This was
# `governed = env == "prod" and status == "active"`, and `products/registry.yaml` says in as many
# words that `active` means "this is the current, supported pack" and "does NOT assert live
# validation". A pack-currency flag was deciding what may reach the public views: prostate is
# `active` today at `contract: coverage_complete, configuration: draft` on a pending stand-in.
#
# `source_manifest.releasable` is the one answer, over Gates 1-4 — and it needs no new field, because
# every input is already recorded as evidence.
sys.path.insert(0, str(Path(framework_root) / "tools"))
from source_manifest import (RELEASE_EVIDENCE, delivery_drift, evidence_verdict,  # noqa: E402
                             publish_approval_errors, releasable)            # noqa: E402

# The REPO ROOT, from `framework_root` (which IS <repo>/platform) — not by counting `parents[]` off
# config_path. `parents[4]` is <repo>/products, one level short, and `releasable` passes that root to
# Gate 1, which resolves each material's REPO-ROOT-RELATIVE `path_or_link`. So a registered
# `products/oncology/prostate/…/reference/…` resolved to `<repo>/products/products/oncology/…`, and
# the pack would have stayed permanently "not release-ready" no matter how many approvals landed.
#
# It hid because every pack is legitimately blocked at Gate 1 today, so the wrong root changed
# nothing observable. The test below now drives a pack all the way to RELEASABLE through this exact
# calculation — a gate only ever shown to refuse has not been shown to work.
_repo = Path(framework_root).resolve().parent
_rel = str(Path(config_path).resolve().parents[1].relative_to(_repo)).replace("\\", "/")
# TWO SOURCES, and which one applies is decided by what is actually on disk.
#
# In a checkout (dev, CI) the full repository is present, so releasability is DERIVED live. In a
# production deployment it cannot be: `deploy_tree.py` deliberately omits the specification
# stand-ins, and Gate 1 requires any material naming a repo path to exist and still hash to its
# recorded sha256 — so a live evaluation inside the deployed tree would report every pack permanently
# blocked by the absence of the very file the packaging exists to exclude.
#
# So the tree carries `RELEASE_EVIDENCE.yaml`, evaluated against the full repo at build time and BOUND
# TO A COMMIT. It is not the `release_ready: true` flag rejected earlier — `evidence_verdict` is what
# makes the difference, and it lives in `source_manifest` beside `releasable` because the two answer
# the same question and must not drift. Every way of failing to prove the file describes THIS
# deployment returns False there; none of that decision is spelled in this notebook, which cannot be
# executed outside Databricks and therefore cannot be tested.
_evidence = _repo / RELEASE_EVIDENCE
if _evidence.exists():
    # The digest is recomputed over the DEPLOYED bytes, here, and compared inside `evidence_verdict`.
    # Recording it at build time and never recalculating it would be a checksum nobody verifies.
    from deploy_tree import tree_digest                              # noqa: E402
    release_ready, release_blockers = evidence_verdict(
        str(_evidence), _rel, dbutils.widgets.get("git_commit"),      # noqa: F821
        tree_sha256=tree_digest(str(_repo)),
        evidence_sha256=dbutils.widgets.get("release_evidence_sha256"))   # noqa: F821
elif env == "prod":
    # NO EVIDENCE FILE IN PROD MEANS THIS IS NOT AN ALLOWLISTED TREE, and that is the only mechanical
    # difference between the two deployment routes. `databricks.yml` syncs the repo root minus three
    # globs, so deploying from a checkout puts the stand-ins and reference material in the
    # workspace — and, because the full repo IS present, a live `releasable()` there would succeed and
    # publish. The allowlist would then be advice rather than a boundary. Refusing here makes the
    # generated tree the only route that can reach the public views; dev keeps live derivation, which
    # is what makes a checkout useful to develop against.
    release_ready, release_blockers = False, [
        f"no {RELEASE_EVIDENCE} — this deployment was not built by deploy_tree.py, so it is a raw "
        f"checkout rather than the allowlisted production tree. Build the tree and deploy that."]
else:
    release_ready, release_blockers = releasable(str(_repo), _rel)

# ...AND THE RUN MUST BE THE DELIVERY THAT VERDICT COVERS. Everything above proves the recorded
# decision describes this DEPLOYMENT — commit, tree digest, evidence bytes, pack entry. None of it
# is a statement about this RUN: `refresh` and `source_schema` arrive as job widgets and are handed
# to `load_config` as overrides above, so a job pointed at another cut or another delivered schema
# read a verdict derived for the committed one and passed every binding. Structural preflight then
# proves the tables and columns EXIST — never that a person confirmed a mapping against them.
#
# Applies to BOTH branches, prod and dev, because the fail-open is in the override, not in the route
# that produced the verdict. The decision is `source_manifest.delivery_drift`; this notebook cannot
# be executed in CI, so it holds none of it.
_drift = delivery_drift(merged_raw(config_path), cfg.raw)
if _drift:
    release_ready, release_blockers = False, _drift + list(release_blockers)
governed = env == "prod" and release_ready               # release-grade run -> the strict gates apply
if env == "prod" and not release_ready:
    print(f"NOT RELEASE-READY ({_rel}) — this run may build and stage, and may NOT publish:")
    for _b in release_blockers[:6]:
        print(f"    {_b}")

# A placeholder artifact_root is a HARD failure in prod (artifacts/manifests are release evidence);
# a warning in dev. Then ensure the durable dir exists AND is WRITABLE up front: artifact_root holds
# the release ledger (manifest/QC) that records every publish, so a misconfigured-but-non-placeholder
# volume must fail the job NOW (hard in prod, warn in dev) — before we build or swap — rather than
# after the final table is already replaced. A probe write+remove proves writability, not just mkdirs.
if "REPLACE_ME" in artifact_root:
    msg = (f"artifact_root is a placeholder ({artifact_root}) — override --var artifact_root so "
           "refresh artifacts/manifests land in a real Unity Catalog Volume.")
    if env == "prod":
        raise ValueError(f"PROD refusing to run: {msg}")
    print(f"WARNING ({env}): {msg}")
try:
    dbutils.fs.mkdirs(artifact_root)   # noqa: F821
    _probe = f"{artifact_root}/.write_probe"
    dbutils.fs.put(_probe, "ok", True)   # noqa: F821  (raises if the volume isn't writable)
    dbutils.fs.rm(_probe)                 # noqa: F821
except Exception as e:   # noqa: BLE001
    msg = (f"artifact_root {artifact_root} is not writable ({e}) — the release ledger (manifest/QC) "
           "can't be persisted there; fix the path/permissions (override --var artifact_root).")
    if env == "prod":
        raise RuntimeError(f"PROD refusing to run: {msg}")
    print(f"WARNING ({env}): {msg}")

# Governed release gates: an ACTIVE product in PROD must be reproducible (git_commit) AND golden-
# compared (reference_table), else the release ledger can't pin the build or prove it didn't drift.
# Waivable for smoke tests via allow_governed_waiver; dev runs and scaffolds are unaffected.
waiver = (dbutils.widgets.get("allow_governed_waiver") or "").strip().lower() in ("1", "true", "yes")  # noqa: F821

# A WAIVER MAY NOT PUBLISH, and neither may a prod run whose pack is not release-ready.
#
# The waiver is documented as a smoke-test bypass: it drops the git_commit and reference_table
# requirements and turns REQUIRED deliverables optional. Nothing stopped it continuing through build,
# QC, staging and the public view swap — there was no validate-only path anywhere in the runner or
# the bundle (`validate_only`, `no_publish`, `dry_run`: zero occurrences). So the switch for "I am
# only checking the plumbing" could replace what analysts read.
#
# Now it is mechanical rather than procedural: the run EXITS below, before the release phase. Staging
# is written — that is what makes the smoke test worth running — and the versioned release tables, the
# release pointer and the public swap are never reached. This comment said the versioned tables were
# still written, which was true of the version before the exit moved; a stale comment about where a
# release begins is the last thing that should be left lying beside the guard that decides it.
may_publish = not waiver and (env != "prod" or release_ready)
if not may_publish:
    _why = "allow_governed_waiver is set" if waiver else "the pack is not release-ready"
    print(f"VALIDATE-ONLY: {_why} — this run will build, QC and stage, and will NOT swap any public "
          f"view. The current public tables stay on the previous build.")
if governed and not waiver:
    missing = [w for w in ("git_commit", "reference_table")
               if not (dbutils.widgets.get(w) or "").strip()]   # noqa: F821
    if missing:
        raise RuntimeError(
            f"PROD/active refusing to run: {missing} required for a governed release "
            "(git_commit pins reproducibility; reference_table runs the golden gate). "
            "Pass them, or --var allow_governed_waiver=true for a smoke test.")

# Fail fast on a bad config, then preflight every required source table + column.
check(cfg)
preflight(spark, cfg)   # noqa: F821

# Pre-build SOURCE QC + GATE — an unreadable mortality source / excess death conflicts stops the
# job BEFORE we build or touch the published table.
src_qc = run_source_qc(spark, cfg)   # noqa: F821
src_gate = source_qc_gate(src_qc, (cfg.raw.get("qc") or {}).get("source_thresholds"))
print("Source QC:\n" + json.dumps({**src_qc, "_gate": src_gate}, indent=2, default=str))
if not src_gate["passed"]:
    # Persist the FAILED source-QC as a durable evidence manifest (== the ADS/golden gate-fail path)
    # so a refusal-to-build leaves an audit record, not just a job log. Best-effort: job fails anyway.
    m = build_manifest(cfg, tumor=tumor, family=family, git_commit=dbutils.widgets.get("git_commit") or None,  # noqa: F821
                       source_qc=src_qc, source_qc_gate=src_gate)
    print("Manifest (SOURCE-QC GATE FAILED):\n" + json.dumps(m, indent=2, default=str))
    try:
        import yaml   # noqa: E402
        dbutils.fs.put(f"{artifact_root}/manifest.yaml",   # noqa: F821
                       yaml.safe_dump(m, sort_keys=False), True)
    except Exception as e:   # noqa: BLE001
        print(f"(could not persist failed source-QC manifest to {artifact_root}: {e})")
    raise RuntimeError(f"Source QC gate FAILED before build: {src_gate['failures']}")

# COMMAND ----------
# Build -> STAGING -> ADS QC + gate (temp-then-swap: a bad refresh never overwrites the final ADS).
final = cfg.output_fqn
# BUILD-SCOPED, and named by `engine.release` like every other release table — see `staging_ads` there
# for why one shared `__staging` name was wrong. Cleanup after a successful publish still drops them,
# so this does not accumulate on the happy path.
staging = rel.staging_ads(final, build_id)
def _assert_swappable(name):
    """A public name must be FREE or already a VIEW (publish = CREATE OR REPLACE VIEW). A pre-pointer
    deployment may hold it as a TABLE -> fail clearly so an operator migrates it ONCE (we never
    auto-drop a table consumers may read). A missing name / an existing VIEW is a no-op.

    Gate on tableExists (not-found -> nothing to migrate) so a DESCRIBE failure on an object that DOES
    exist (permission denied, metastore outage, bad identifier) PROPAGATES — we never silently treat a
    metadata-read error as 'missing' and defer the real failure to the swap."""
    if not spark.catalog.tableExists(name):   # noqa: F821  not found -> nothing to migrate
        return
    typ = next((r["data_type"] for r in spark.sql(f"DESCRIBE EXTENDED {name}").collect()   # noqa: F821
                if (r["col_name"] or "").strip() == "Type"), "")
    if typ and typ.strip().upper() != "VIEW":
        raise RuntimeError(f"Public name {name} already exists as a {typ.strip()} (pre-pointer "
                           "deployment); the release pointer needs a VIEW. Drop/rename it once, or use "
                           "a clean output schema.")
# Migration guard, fail-FAST (BEFORE the expensive build): the ADS public name must be free or already a
# VIEW. (The public TFL names are guarded once their ids are known, just before the swap — see below.)
_assert_swappable(final)
ads = build(spark, cfg)        # noqa: F821
(ads.write.mode("overwrite").option("overwriteSchema", "true").saveAsTable(staging))   # noqa: F821
staged = spark.table(staging)  # noqa: F821

report = run_qc(spark, staged, cfg)            # noqa: F821
gate = qc_gate(report, qc_thresholds(cfg))
counts = {
    "total_rows": staged.count(),
    "cohorts": {r["cohort"]: r["n"] for r in
                staged.groupBy("cohort").agg(F.count(F.lit(1)).alias("n")).collect()}
    if "cohort" in staged.columns else {},
}
ref = dbutils.widgets.get("reference_table")   # noqa: F821
golden = {"reference": "none"}
if ref:
    summary = run_golden(spark, staging, ref, cfg)   # noqa: F821
    ggate = golden_gate(summary, golden_thresholds(cfg))
    golden = {"reference": ref, "summary": summary, "gate": ggate}
else:
    ggate = golden_gate(None)        # no reference -> skipped (passes)
    if cfg.raw.get("status") == "active":
        print("WARNING: no `reference_table` supplied — golden comparison SKIPPED for an ACTIVE "
              "product. A release-grade run should pass --var reference_table=<known-good ADS>.")
print("QC report:\n" + json.dumps(report, indent=2, default=str))
print("QC gate:\n" + json.dumps(gate, indent=2, default=str))
print("Golden gate:\n" + json.dumps(ggate, indent=2, default=str))

# COMMAND ----------
# Gate on BOTH the ADS QC gate AND the golden gate (drift vs the reference ADS, when supplied).
# Either failing keeps staging and FAILS the job WITHOUT publishing (temp-then-swap).
if not gate["passed"] or not ggate["passed"]:
    m = build_manifest(cfg, tumor=tumor, family=family, git_commit=dbutils.widgets.get("git_commit") or None,  # noqa: F821
                       counts=counts, qc=gate, golden=golden, source_qc=src_qc, source_qc_gate=src_gate)
    qc_md = render_qc_report(report, gate, golden, m)
    print("Manifest (GATE FAILED):\n" + json.dumps(m, indent=2, default=str))
    print("\n=== QC REPORT ===\n" + qc_md)
    import yaml   # noqa: E402
    for name, body in [("manifest.yaml", yaml.safe_dump(m, sort_keys=False)), ("qc_report.md", qc_md)]:
        try:    # persist the FAILED-refresh evidence durably (best-effort; the job is already failing)
            dbutils.fs.put(f"{artifact_root}/{name}", body, True)   # noqa: F821
        except Exception as e:   # noqa: BLE001
            print(f"(could not persist failed-gate {name} to {artifact_root}: {e})")
    raise RuntimeError(
        f"Publish blocked — '{final}' NOT published. QC failures: {gate['failures']}. "
        f"Golden failures: {ggate['failures']}. Staging kept: {staging}")

# COMMAND ----------
# Deliverables are generated FROM THE STAGED table BEFORE the swap, so a REQUIRED deliverable that
# fails BLOCKS publish — the final ADS is never overwritten by an incomplete refresh. The dictionary
# is column-aware (filtered to the staged ADS columns, like the dashboard); TFLs read the staged ADS, byte-for-byte what
# will publish (the staged ADS is copied to the IMMUTABLE versioned table, then the public view swaps to
# it). Each deliverable is
# required | optional | skip per the config `deliverables:` block (default optional); status is
# recorded in the manifest.
staged = spark.table(staging)   # noqa: F821
deliv_cfg = cfg.raw.get("deliverables") or {}
def _policy(name):   # required | optional | skip — a governed (prod+active) run REQUIRES the release
    default = "required" if (governed and not waiver) else "optional"   # waiver -> smoke-test bypass
    return str(deliv_cfg.get(name, default)).lower()

artifacts = {}
deliverables = {}

if _policy("dictionary") == "skip":
    deliverables["dictionary"] = {"status": "skipped", "reason": "deliverables.dictionary=skip"}
else:
    try:
        catalog = load_yaml(str(shared_asset(products_root, "catalog")))
        auds = (load_yaml(str(shared_asset(products_root, "audiences"))) or {}).get("audiences")
        made, xlsx_failed = [], []
        for audience in (auds or {"internal": 1, "partner": 1, "customer": 1}):
            d = dict_engine.build_dictionary(catalog, audience=audience, tumor=tumor, audiences=auds,
                                             columns=staged.columns)   # restrict to what the ADS emits
            p = f"{artifact_root}/dictionary_{audience}.md"
            dbutils.fs.put(p, dict_engine.render_markdown(d), True)   # noqa: F821
            artifacts[f"dictionary_{audience}"] = p
            try:    # XLSX is a governed human-review deliverable (OPERATIONS.md) — its failure is RECORDED
                import os, tempfile   # noqa: E402
                xl = os.path.join(tempfile.mkdtemp(), f"dictionary_{audience}.xlsx")
                dict_engine.render_xlsx(d, xl)
                xlr = f"{artifact_root}/dictionary_{audience}.xlsx"
                dbutils.fs.cp(f"file:{xl}", xlr)   # noqa: F821
                artifacts[f"dictionary_{audience}_xlsx"] = xlr
            except Exception as xe:   # noqa: BLE001
                xlsx_failed.append(audience)
                print(f"(dictionary XLSX for {audience} FAILED: {xe})")
            made.append(audience)
        # 'ok' only when BOTH formats are produced; an XLSX failure -> 'partial' so a REQUIRED dictionary
        # (governed run) BLOCKS publish, while an optional one still publishes with the gap recorded.
        deliverables["dictionary"] = {
            "status": "ok" if (made and not xlsx_failed) else ("partial" if made else "empty"),
            "audiences": made, "markdown": "ok" if made else "empty",
            "xlsx": "ok" if (made and not xlsx_failed) else ("failed" if xlsx_failed else "empty"),
            "xlsx_failed": xlsx_failed}
        print(f"Dictionaries: {made}  (xlsx failed: {xlsx_failed or 'none'})")
    except Exception as e:   # noqa: BLE001
        deliverables["dictionary"] = {"status": "failed", "error": str(e)}
        print(f"(dictionary generation FAILED: {e})")

# COMMAND ----------
# Dashboard manifest — the generated CONTRACT the dashboard reads (labels/types/value-sets/units/
# time-to-event pairings) so the app never hard-codes variable metadata. Built from the catalog + the
# variable packs, filtered to this tumor (so it carries the mcrpc-specific variables).
if _policy("dashboard") == "skip":
    deliverables["dashboard"] = {"status": "skipped", "reason": "deliverables.dashboard=skip"}
else:
    try:
        from engine import dashboard as dash_engine   # noqa: E402
        layout = load_yaml(str(shared_asset(products_root, "dashboard_vars")))
        dm = dash_engine.build_manifest(
            cfg, load_yaml(str(shared_asset(products_root, "catalog"))), tumor,
            dashboard=layout, columns=staged.columns)   # restrict to what the ADS actually emits
        dpth = f"{artifact_root}/dashboard_manifest.json"
        dbutils.fs.put(dpth, dash_engine.render_json(dm), True)   # noqa: F821
        artifacts["dashboard_manifest"] = dpth
        deliverables["dashboard"] = {"status": "ok", "n_variables": dm["summary"]["n_variables"]}
        print(f"Dashboard manifest: {dm['summary']['n_variables']} variables -> {dpth}")
    except Exception as e:   # noqa: BLE001
        deliverables["dashboard"] = {"status": "failed", "error": str(e)}
        print(f"(dashboard manifest FAILED: {e})")

tfl_staged = {}   # tid -> (final_name, staging_name); promoted to final ONLY after the ADS publishes
tfl_qc_result = None   # the TFL QC gate (engine.tfl.tfl_qc); goes into the release bundle below
if _policy("tfls") == "skip":
    deliverables["tfls"] = {"status": "skipped", "reason": "deliverables.tfls=skip"}
else:
    try:
        specs = tfl_engine.load_specs(str(shared_asset(products_root, "tfl_specs")))
        made = []
        for tid, df in tfl_engine.generate(spark, staged, specs).items():   # noqa: F821
            tfinal, tstg = rel.public_tfl(final, tid), rel.staging_tfl(final, build_id, tid)
            df.write.mode("overwrite").option("overwriteSchema", "true").saveAsTable(tstg)   # STAGE only
            tfl_staged[tid] = (tfinal, tstg)
            artifacts[f"tfl_{tid}"] = tfinal     # final location (after the post-publish promotion below)
            made.append(tid)
        # TFL QC gate — computed AFTER generate() with the SET ACTUALLY EMITTED (made): a required TFL
        # that is column-producible but that generate() silently skipped (no kept summarise/listing
        # columns) is a real `failure`, not a false `ok`. per-TFL applicability + required/optional skips.
        tfl_qc_result = tfl_engine.tfl_qc(specs, tfl_engine.tfl_plan(specs, staged.columns, hard=True),  # noqa: F821
                                          generated=set(made))
        # ENFORCE: a failed gate FAILS the tfls deliverable -> a governed run (tfls=required) BLOCKS
        # publish; optional / not-applicable TFLs only warn (don't block). tfl_qc rides along for evidence.
        if tfl_qc_result and not tfl_qc_result["passed"]:
            _failed = [r["id"] for r in tfl_qc_result["tfls"] if r["status"] == "failure"]
            deliverables["tfls"] = {"status": "failed", "tfls": made, "tfl_qc": tfl_qc_result,
                                    "error": f"TFL QC gate failed — required TFLs not producible: {_failed}"}
            print(f"(TFL QC GATE FAILED: required TFLs not producible: {_failed})")
        else:
            deliverables["tfls"] = {"status": "ok" if made else "empty", "tfls": made, "tfl_qc": tfl_qc_result}
        print("TFLs (staged):", made)
    except Exception as e:   # noqa: BLE001
        deliverables["tfls"] = {"status": "failed", "error": str(e)}
        print(f"(TFL generation FAILED: {e})")

# A REQUIRED deliverable that didn't complete BLOCKS publish (staging kept, final never overwritten).
# Record the evidence manifest, then fail — BEFORE the swap.
required_failed = [name for name in ("dictionary", "tfls", "dashboard")
                   if _policy(name) == "required" and deliverables.get(name, {}).get("status") != "ok"]
if required_failed:
    m = build_manifest(cfg, tumor=tumor, family=family, git_commit=dbutils.widgets.get("git_commit") or None,  # noqa: F821
                       counts=counts, qc=gate, golden=golden, source_qc=src_qc, source_qc_gate=src_gate,
                       deliverables=deliverables, artifacts={"artifact_root": artifact_root, **artifacts})
    try:
        import yaml   # noqa: E402
        dbutils.fs.put(f"{artifact_root}/manifest.yaml",   # noqa: F821
                       yaml.safe_dump(m, sort_keys=False), True)
    except Exception as e:   # noqa: BLE001
        print(f"(could not write evidence manifest: {e})")
    raise RuntimeError(
        f"Publish blocked — required deliverable(s) {required_failed} did not complete; "
        f"'{final}' NOT published. Staging kept: {staging}. See manifest.deliverables "
        "(set deliverables.<name>=optional to publish without them).")

# COMMAND ----------
# VALIDATE-ONLY STOPS HERE — before the RELEASE PHASE, not part-way through it.
#
# Guarding only the view swap is not enough. If a validate-only run created IMMUTABLE versioned
# release tables, wrote a release pointer into the manifest and touched the public TFL names, then
# release-NAMED objects would appear in the production output schema even though nothing was
# published — and a later reader could not tell "this build was validated" from "a release was
# prepared and abandoned". `validate_only` must not also mean "created release objects".
#
# Everything worth having from a smoke test has already happened above: the build ran, source/ADS/TFL
# QC ran, deliverables were produced, and staging holds the exact bytes that would publish. What is
# skipped is only the part that makes a release a release.
if not may_publish:
    manifest["tfl_promotion"] = {"passed": False, "skipped": "validate_only",
                                 "intended": list(tfl_staged)}
    manifest["validate_only"] = {"reason": "waiver" if waiver else "not_release_ready",
                                 "blockers": release_blockers[:20],
                                 "stopped_before": "versioned_release_tables"}
    dbutils.fs.put(f"{artifact_root}/manifest.yaml",   # noqa: F821
                   yaml.safe_dump(manifest, sort_keys=False), True)
    print(f"VALIDATE-ONLY: staged {staging} and {len(tfl_staged)} TFL(s). No versioned release table, "
          f"no release pointer, no public view touched. published_at is null. Blockers: "
          f"{'; '.join(release_blockers[:3]) or 'none (waiver)'}")
    dbutils.notebook.exit("validate_only")   # noqa: F821

# Final pre-publish guard: every PUBLIC name the swap will replace (the ADS + each public TFL) must be
# FREE or already a VIEW. The ADS was checked pre-build; the public TFL names are known only now the
# TFLs are staged. A pre-pointer TABLE squatting on a public TFL name would fail the swap mid-flight.
for _pub, _ver, _ in rel.swap_plan(final, cfg.refresh, build_id, list(tfl_staged)):
    _assert_swappable(_pub)

# DURABLE RELEASE LEDGER FIRST, THEN PUBLISH. The manifest + QC report record exactly what is about
# to be published — counts / QC / golden / deliverables / artifacts are all known from the staged
# table, which is byte-for-byte what will publish. Writing them to artifact_root BEFORE the
# irreversible swap, and FAILING LOUD if that write fails, guarantees we can never end up "published
# but not durably recorded": if the ledger can't be persisted, the final table is left untouched and
# the job fails with staging kept. status = qc_passed and published_at = null here (PRE-publish) — so
# this record can never be mistaken for a successful publish if the swap below fails.
manifest = build_manifest(cfg, tumor=tumor, family=family, git_commit=dbutils.widgets.get("git_commit") or None,  # noqa: F821
                          counts=counts, qc=gate, golden=golden,
                          source_qc=src_qc, source_qc_gate=src_gate, deliverables=deliverables,
                          artifacts={"artifact_root": artifact_root, **artifacts})
qc_md = render_qc_report(report, gate, golden, manifest)
print("Refresh manifest (pre-publish, published_at=null):\n" + json.dumps(manifest, indent=2, default=str))
print("\n=== QC REPORT (markdown) ===\n" + qc_md)
import yaml   # noqa: E402
# THE CANONICAL CANDIDATE BYTES, serialized ONCE. What gets written, what gets hashed and what an
# approver is told to sign are the same string, not three calls to `safe_dump` that agree today.
# `_manifest_sha` is computed here, beside the write, for the same reason: a digest taken somewhere
# else in the notebook is a digest of whatever the dict happened to be at that point.
_persisted = yaml.safe_dump(manifest, sort_keys=False)
_manifest_sha = hashlib.sha256(_persisted.encode("utf-8")).hexdigest()
for name, body in [("manifest.yaml", _persisted), ("qc_report.md", qc_md)]:
    dbutils.fs.put(f"{artifact_root}/{name}", body, True)   # noqa: F821  (raises on failure -> no publish)
    print(f"Wrote {artifact_root}/{name}")

# COMMAND ----------
# GATE 6 — THE NAMED APPROVAL OF *THIS BUILD*, and the last thing between a clean run and the public
# views. Checked HERE because the thing being approved does not exist until now: the candidate
# manifest carrying this run's counts, QC verdict and golden comparison. Approving earlier would
# approve a configuration, which Gate 4 already did.
#
# WORKFLOW.md has always required this. The runner did not ask: it confirmed Gates 1-4, built, ran QC
# and swapped, and sign-off was promoted to the ledger AFTERWARDS. So production credentials plus a
# technically clean run moved the public product with no accountable person having looked at it.
#
# WHAT THIS IS AND IS NOT. It is a BLOCK: a prod run with no matching approval stops here, staged and
# QC'd, with nothing public touched. It is NOT yet a working two-run release flow, and pretending
# otherwise would be worse than saying so. `build_id` embeds `{{job.run_id}}`, so every execution
# mints a new identity and `built_at` moves the manifest digest with it — an approval of build A can
# never be satisfied by a later run B, and there is no promotion-only task that resumes A without
# rebuilding. Implementing that resume path (immutable candidate -> approval -> promote WITHOUT
# rebuild) is the remaining work; see DEV_SMOKE.md §2b and products/OPERATIONS.md. Until it exists,
# a governed prod release requires the promotion step to be built, not merely an approval to be
# signed.
#
# GATES 1-4 COME FROM `release_ready`, NOT FROM A FRESH `releasable()`. In prod that verdict was
# derived from RELEASE_EVIDENCE.yaml precisely because the allowlisted tree omits the Gate 1 material
# a live evaluation needs — so re-deriving here would fail for the reason the packaging exists to
# create. The first version of this block called `releasable()` and could never have passed in
# production.
print(f"Candidate manifest sha256: {_manifest_sha}  build_id: {build_id}")
if env == "prod":
    _pub_why = publish_approval_errors(str(_repo), _rel, build_id, _manifest_sha)
    if _pub_why:
        # THE CANDIDATE MANIFEST IS NEVER REWRITTEN. An earlier version recorded this state by adding
        # a `release_approval` block to `manifest` and putting the file again — so `manifest.yaml` on
        # disk did NOT hash to the digest printed above and carried into the approval form. The
        # approver would sign a value no artifact reproduced, and the promotion step verifying the
        # file would reject the very build the approval names. A binding whose subject is edited
        # after it is hashed binds nothing.
        #
        # So the stop is recorded ALONGSIDE, in its own file. `manifest.yaml` stays byte-identical to
        # `_persisted`: `status: qc_passed` with a null `published_at` is ALREADY the pre-publish
        # state and needs no new word (an invented `awaiting_release_approval` also fails
        # `validate_manifest`, and a ledger entry that will not validate is not a ledger entry).
        dbutils.fs.put(f"{artifact_root}/release_candidate.yaml",   # noqa: F821
                       yaml.safe_dump({"granted": False, "build_id": build_id,
                                       "candidate_manifest_sha256": _manifest_sha,
                                       "candidate_manifest": f"{artifact_root}/manifest.yaml",
                                       "blockers": _pub_why[:20],
                                       "stopped_before": "versioned_release_tables"},
                                      sort_keys=False), True)
        print("AWAITING RELEASE APPROVAL — staged and QC'd, no versioned release table, no release "
              "pointer, no public view touched. published_at is null.")
        for _b in _pub_why[:6]:
            print(f"   - {_b}")
        print(f"   To approve THIS build, record in {_rel}/handoff/RELEASE_APPROVAL.yaml:\n"
              f"     approved_build_id: {build_id}\n"
              f"     approved_manifest_sha256: {_manifest_sha}\n"
              f"   ...and note that promoting an approved candidate is NOT yet implemented: this run "
              f"cannot be resumed, and a rerun mints a new build_id.")
        dbutils.notebook.exit("awaiting_release_approval")   # noqa: F821

# COMMAND ----------
# Ledger written -> PUBLISH. build_id (minted up front, UNIQUE PER RUN) makes every versioned table new,
# so a same-commit/same-refresh RERUN never overwrites the table a live view points at. The WHOLE
# release phase is wrapped in the failure ledger: (1) write the ADS + every TFL to IMMUTABLE versioned
# tables — failing LOUD if one already exists (never silently overwrite an immutable release) and
# dropping NOTHING yet; (2) record the release pointer; (3) swap the public VIEWS, TFLs FIRST and the
# ADS LAST (the commit anchor); (4) only after every write + swap succeeds, drop the staging tables. ANY
# failure in (1)-(3) records release_swap_failed_at, keeps published_at null, persists the manifest, and
# keeps staging — so we can never be published-but-unrecorded or half-written-but-claimed-published.
from datetime import datetime, timezone   # noqa: E402
v_ads = rel.versioned_ads(final, cfg.refresh, build_id)
try:
    # (1) versioned writes — CREATE TABLE (no OR REPLACE) + an explicit pre-check both REFUSE to
    #     overwrite an existing versioned table (a build_id collision). No drops in this phase.
    for _name, _src in ([(v_ads, staging)]
                        + [(rel.versioned_tfl(final, cfg.refresh, build_id, _tid), _tstg)
                           for _tid, (_tf, _tstg) in tfl_staged.items()]):
        if spark.catalog.tableExists(_name):   # noqa: F821
            raise RuntimeError(f"Versioned table {_name} already exists — build_id collision; refusing "
                               "to overwrite an immutable release. A fresh run mints a new build_id.")
        spark.sql(f"CREATE TABLE {_name} AS SELECT * FROM {_src}")   # noqa: F821
    # (2) all data durable in versioned tables -> record the release pointer in the manifest
    manifest["release"] = rel.release_pointer(final, cfg.refresh, build_id, list(tfl_staged),
                                              manifest=f"{artifact_root}/manifest.yaml", spec_version=cfg.spec_version)
    # (2b) persist a "release-prepared" manifest (release pointer known, published_at STILL null) BEFORE
    #      the swap. So even if the post-swap published_at stamp later fails, the durable ledger already
    #      records the EXACT versioned set that went live (vs. the earlier pre-publish manifest, which had
    #      no release pointer). A failure here raises BEFORE any view swaps -> views stay on the prior build.
    dbutils.fs.put(f"{artifact_root}/manifest.yaml",   # noqa: F821
                   yaml.safe_dump(manifest, sort_keys=False), True)
    # (3) swap the public VIEWS — TFLs first, the ADS last (the commit anchor). SKIPPED entirely on a
    #     validate-only run: the swap is the only step that changes what a reader sees, so it is the
    #     one step a smoke test must not reach. Everything above it has already run, which is the
    #     point — the plumbing is exercised, the release is not made.
    # Only a publishing run reaches here — validate-only exited above, before any versioned write.
    for _pub, _ver, _sql in rel.swap_plan(final, cfg.refresh, build_id, list(tfl_staged)):
        spark.sql(_sql)   # noqa: F821  (CREATE OR REPLACE VIEW <pub> AS SELECT * FROM <versioned>)
    manifest["tfl_promotion"] = {"passed": True, "promoted": list(tfl_staged)}
except Exception as _e:   # noqa: BLE001
    manifest["tfl_promotion"] = {"passed": False, "error": str(_e), "intended": list(tfl_staged)}
    manifest["release_swap_failed_at"] = datetime.now(timezone.utc).isoformat(timespec="seconds")
    try:
        dbutils.fs.put(f"{artifact_root}/manifest.yaml",   # noqa: F821
                       yaml.safe_dump(manifest, sort_keys=False), True)
    except Exception:   # noqa: BLE001
        pass
    raise RuntimeError(f"Release phase FAILED ({_e}); published_at left null; the ADS view still points "
                       "at the previous build (consistent). Staging kept — a re-run mints a fresh "
                       "build_id and republishes.")
# Swap succeeded -> persist the manifest NOW with tfl_promotion.passed (published_at STILL null), best-
# effort, so even if the final published_at stamp below fails the durable ledger records that the public
# views DID swap to this build (not just the prepared set). The final write then only adds published_at.
try:
    dbutils.fs.put(f"{artifact_root}/manifest.yaml",   # noqa: F821
                   yaml.safe_dump(manifest, sort_keys=False), True)
except Exception as _we:   # noqa: BLE001
    print(f"(post-swap manifest write skipped: {_we})")
# (4) published -> drop the staging tables (best-effort cleanup; a drop failure does NOT unpublish).
# KEPT on a validate-only run: staging is the only thing that run produced, and dropping it would
# leave a smoke test with nothing to inspect.
for _name in [staging] + [_tstg for _tid, (_tf, _tstg) in tfl_staged.items()]:
    try:
        spark.sql(f"DROP TABLE IF EXISTS {_name}")   # noqa: F821
    except Exception as _de:   # noqa: BLE001
        print(f"(staging cleanup: could not drop {_name}: {_de})")
# The public view, ONLY when this run published one. A validate-only run swapped nothing, so `final`
# is either the PREVIOUS build (and the message below would be false about it) or, on a first run for
# a new product, a name that does not exist yet — turning a successful validation into a late crash.
published = spark.table(final)   # noqa: F821
print(f"Published {counts['total_rows']:,} rows -> {v_ads}; public views now point at this build")

# Best-effort: flag PUBLIC TFL views left over from a PREVIOUS release that this build no longer produces
# (a spec dropped the TFL). Their views would keep serving the prior build's data; record them as
# `retired_tfls` in the ledger and WARN so an operator retires them — we never auto-drop a consumer-
# readable view. Consumers should resolve TFLs through the release pointer (manifest.release.tfls).
try:
    _schema, _tbl = final.rsplit(".", 1)
    _existing = [f"{_schema}.{r['tableName']}" for r in
                 spark.sql(f"SHOW TABLES IN {_schema} LIKE '{_tbl}__tfl_*'").collect()]   # noqa: F821
    _stale = rel.stale_public_tfls(_existing, final, list(tfl_staged))
    if _stale:
        manifest["retired_tfls"] = _stale
        print(f"WARNING: stale public TFL view(s) from a previous release, not produced now: {_stale}. "
              "Resolve TFLs via manifest.release.tfls; retire these views manually.")
except Exception as _re:   # noqa: BLE001
    print(f"(stale-TFL scan skipped: {_re})")

# COMMAND ----------
# Swap succeeded -> stamp the durable manifest as PUBLISHED (published_at) and re-write it, fail-loud.
# Only now does the ledger record a successful publish; a manifest still carrying published_at=null
# means the swap did NOT complete. (A post-swap write failure under-claims — SAFE: the public views are
# already live on this build; a fresh re-run mints a new build_id and writes a complete ledger.)
# A VALIDATE-ONLY run swapped nothing, so it must not stamp published_at — that field is the ledger's
# claim that the public views went live on this build, and a smoke test writing it would be the exact
# false record the null-until-swapped discipline above exists to prevent.
manifest["published_at"] = datetime.now(timezone.utc).isoformat(timespec="seconds")
dbutils.fs.put(f"{artifact_root}/manifest.yaml",   # noqa: F821  (raises on failure)
               yaml.safe_dump(manifest, sort_keys=False), True)
print(f"Marked published at {manifest['published_at']}")

# Consolidated release evidence bundle (release.json + audit_report.md + split QC JSONs + tfl_qc.json)
# into the build-scoped artifact dir — the immutable per-build record (engine/audit.py). Promote it to
# git `releases/<family>/<product>/<spec_version>/<refresh>/<build_id>/` alongside the manifest. Best-
# effort: the manifest is the source of truth, so a bundle-write hiccup must not fail an already-live publish.
try:
    _bundle = audit.build_bundle(manifest, tfl_qc_result)
    for _bn, _bo in _bundle.items():
        _body = _bo if isinstance(_bo, str) else json.dumps(_bo, indent=2, default=str)
        dbutils.fs.put(f"{artifact_root}/{_bn}", _body, True)   # noqa: F821
    print(f"Wrote release bundle ({len(_bundle)} files) -> {artifact_root}")
except Exception as _e:   # noqa: BLE001 - evidence bundle is best-effort
    print(f"(release bundle write failed, non-fatal: {_e})")

# COMMAND ----------
try:    # dev/local convenience: also drop the manifest (now marked published) into the repo tree
    print("Wrote repo manifest:", write_manifest(manifest, repo_root))
    # ...and the evidence bundle into the SPEC-VERSIONED git ledger:
    #   releases/<family>/<product>/<spec_version>/<refresh>/<build_id>/  (engine.refresh.release_dir).
    # Local FS write (works in dev where repo_root is on disk; on Databricks repo_root isn't local so this
    # raises and the durable copy in artifact_root above is promoted to git instead).
    _rel = audit.write_bundle(manifest, release_dir(repo_root, manifest, build_id), tfl_qc_result)
    print(f"Wrote release ledger bundle ({len(_rel)} files) -> {release_dir(repo_root, manifest, build_id)}")
except Exception as e:   # noqa: BLE001
    print(f"(repo ledger write skipped: {e}) — promote manifest + bundle from {artifact_root}/")

# COMMAND ----------
display(spark.table(final).limit(50))   # noqa: F821
