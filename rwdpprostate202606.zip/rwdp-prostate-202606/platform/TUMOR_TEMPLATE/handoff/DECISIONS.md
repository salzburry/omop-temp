# Decisions — questions only a person can answer

One row per open question. A contract record cites these by `decision_ids: [ID]`, and the shared lint
(`platform/tools/contract_lint.py`, I2) fails any citation of an ID that is not defined here.

A decision is a question about the REQUIREMENT (what is being asked for) or about the OUTPUT (naming,
codes). Only the output-only IDs `NAME-ALIGN` and `CODE-ALIGN` may sit beside `requirement: approved` —
anything else means the requirement itself is still open, which `approved` would misstate (I7).

An item that is merely unbuilt is not a decision: that is a gap, and belongs in `ENGINE_GAPS.md`.

`Owner` is who the question is PUT TO while it is open. `Approved by` / `Approval date` are who
actually answered it, and when — a different fact, recorded when the status becomes RESOLVED. Leave
them empty until then. Gate 2 refuses `contract: approved` while any RESOLVED row has no approver or
no date: every other approval here binds to a person and a date, and the scientific judgment is the
last one that did not. No tool may fill them in.

| ID | Question | Evidence | Owner | Resolution | Approved by | Approval date | Status |
|---|---|---|---|---|---|---|---|
| NAME-ALIGN | Do delivered physical names match the target published names? | — | RWP | — |  |  | OPEN |
