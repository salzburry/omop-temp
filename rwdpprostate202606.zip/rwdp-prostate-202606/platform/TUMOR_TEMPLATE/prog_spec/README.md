# Put the RWB program specification in THIS folder

`<pack>/prog_spec/` is where a new tumour's specification goes, and it is the
path `source_refs.yaml` registers. Drop the approved workbook here:

    prog_spec/PROG_SPEC_<PROGRAM>_<TUMOUR>_<YYYYMM>.xlsx

`spec_extract.py` reads `.xlsx` directly — that is the production path. A folder of `.md` files is
read too, and is what exists when the workbook itself cannot be brought into the repo; register those
as a SECOND material (`material_type: extraction_input`, `derived_from: program_spec`) rather than
calling a stand-in the approved specification. `source_refs.yaml` shows both shapes.

Nothing here is read by name. The pipeline resolves this folder through the `material_id` named in
`spec_pipeline/pipeline.conf` (`SPEC_SOURCE_ID`), so the registration is what makes a document
governed — not its filename and not this folder. Rename the folder and update `source_refs.yaml` and
everything still works; drop a file in without registering it and nothing reads it.

Delete this README once the specification is in place.
