# Starting a new tumour

Copy this folder to `products/<family>/<slug>/<YYYYMM>/`, drop the specification in
`prog_spec/`, and make the edits below. Nothing else is needed to reach Gate 1.

A folder of documents is NOT a pack. Discovery is by shape: a directory becomes a pack when it carries
`source_refs.yaml`, `handoff/MATURITY.yaml`, `handoff/FUNCTIONAL_CONTRACT.md`,
`spec_pipeline/pipeline.conf` or `config/data_product.yaml`. Until one of those exists the gates do not
look at it — which is why dropping the spec in on its own does nothing, and why CI never has to be
edited to pick a new tumour up.

## The edits, in order

**1. `source_refs.yaml`** — replace `product`, `spec_version`, `path_or_link`, `document_id`,
`classified_by`, `classified_date`, and choose the `ai_classification`.

The classification is the AI boundary and is required at EVERY status. It follows the CONTENT's
provenance, never the folder: a sponsor-authored specification is `sponsor_ai_eligible`; anything
vendor-originated or vendor-derived is not, and an internally written document that quotes vendor
material inherits the restricted classification. See `governance/WORKFLOW.md` §"Eligibility".

If the approved workbook is not in hand, leave `status: pending`, say why in `why_provisional`, and
set `path_or_link` to a `TBD …` note or a link. A path that names somewhere in the repo must resolve —
Gate 1 checks that at every status, so a mistyped filename is caught at registration rather than
surfacing later as a pipeline fault.

**2. `spec_pipeline/pipeline.conf`** — set `TUMOR` to the slug and `SPEC_SOURCE_ID` to the
`material_id` the extractor should read. It names a material, never a path: that indirection is what
lets the spec folder move without touching the pipeline.

**3. `handoff/MATURITY.yaml`** — leave both axes at `not_started` until the evidence exists. It is a
CLAIM, and each level is granted on the evidence named beside it.

**4. `products/registry.yaml`** — LAST, and as `status: scaffold`.

```yaml
- { code: <code>, name: "<Name>", slug: <slug>, vendor: <vendor>, tumor_class: <class>,
    status: scaffold, current_spec_version: "<YYYYMM>" }
```

The registry is what `engine.config.product_dir()` resolves for every DEFAULT product lookup, so an
entry is a claim that the pack can be built. Adding it early, or as `status: active`, points every
default lookup at a pack with no `config/data_product.yaml` — which does not fail once, it fails in
every suite that loads the default product, and each failure names the missing config file rather than
the registry line that caused it. Deleting a pack while the registry still called it current took 10 of
20 platform suites down and read as ten unrelated defects.

`product_gates --check-maturity` now refuses an `active` entry whose pack is not buildable, so the
error names the registry line. Promote to `active` only after the contract, the config and the pack's
own tests pass.

**Adding a new VERSION of an existing tumour** is the same rule: leave the old `current_spec_version`
alone, build the new pack alongside it, and move `current_spec_version` in the final promotion change
— never at the start.

## Then

```bash
python3 platform/tools/source_manifest.py <pack> --check      # Gate 1
bash platform/tools/run_spec_pipeline.sh <pack>               # extract → lint → coverage → scaffold
```

Gate 1 is pure Python and runs anywhere. `run_spec_pipeline.sh` is the ONLY bash in the workflow —
on a machine without it run `python3 platform/tools/run_spec_pipeline.py <pack>` — the `.sh`
is a one-line wrapper around exactly that. Or use the bash Git for Windows ships
(`& "C:\Program Files\Git\bin\bash.exe" platform/tools/run_spec_pipeline.sh <pack>`) or run the
same six calls by hand. `sandbox/new_tumour_start/START_HERE.md` §4 lists them in order, with the
PowerShell form.

Add `--check` only later, to ask whether those artifacts are still current: it regenerates into a temp
directory and byte-compares, writing nothing into the pack, so it is not how the first run is done.

The pipeline writes seven generated artifacts to `spec_pipeline/out/`. `SCAFFOLDED_RECORDS.md` holds
one record per specification row — that is the contract's shape (lint I16), not a starting point to be
grouped into families afterwards.

`config/`, `variables/` and `codelists/` are the Gate 4 half of the pack. They ship here so the shape
is visible: the root config is full of `REPLACE_ME`, and `variables/`/`codelists/` carry real seeded
values because a config of pure placeholders cannot be linted or executed. Leave all of it until the
contract exists. `MATURITY.yaml` saying `configuration: not_started` is what makes that honest.

## Gates 3–6

Gate 2 is where most of the work is, so this file used to stop there — and a new pack was left to
find the rest by reading tools. One row per remaining gate: the artifact it produces, the command
that produces it, the fields only a person can fill, and what closes it.

| Gate | Artifact | Command | Human fields | Closes when |
|---|---|---|---|---|
| **3** — source readiness | `handoff/SOURCE_VERDICTS.md` (or `SOURCE_VERDICTS.<member>.md` per union member) | **first** set the delivery bindings in `config/pipeline.yaml` (`run.refresh`, `run.source_schema` — unless a `source_union` names the member schemas — plus `run.data_format` / `run.source_layout` where they apply), then run the profile and schema check against **those same values**, then `source_check.py <pack> --profile <profile.tsv> --schema-validation <SCHEMA_VALIDATION.json> --complete --out handoff/SOURCE_VERDICTS.md` | `reviewed_by`, `review_date` in the generated front matter | every contract record's `source_mapping` is `human_confirmed` and its `dictionary_check` / `live_schema_check` / `data_profile_check` are off `not_run`. The profile and schema report are written OUTSIDE the checkout — `--out-dir` is required and refused inside it |
| **4** — executable configuration | the active config graph + `handoff/CONFIGURATION_APPROVAL.yaml` | author it (`platform/README.md` §"Add a tumor"), then `contract_binding.py <pack> --check` | `approved_by`, `approval_date`, `technically_reviewed_by`, both digests — copy `CONFIGURATION_APPROVAL.example.yaml` | the binder passes, every graph file is off `status: scaffold`, and the form's digests match the graph and the contract |
| **5** — validation | per-record `acceptance` + `status.validation`; at run level the refresh manifest's `qc`, `golden`, `source_qc`, `deliverables` | the pack's own tests (`product_gates.py --list-tests`), then a build | `status.validation` per record; the reviewer named at Gate 6 as `validated_by` | every approved record is `passed_test` or `passed_live`, or names a gap in `handoff/ENGINE_GAPS.md`. There is no separate Gate 5 form — the human exit is recorded on the Gate 6 approval, because a validation record with no build attached is a claim about nothing in particular |
| **6** — release | `handoff/RELEASE_APPROVAL.yaml` | a prod run stops before the swap and prints the two identifiers | `approved_by`, `approval_date`, `validated_by`, `validation_date`, `approved_build_id`, `approved_manifest_sha256` — copy `RELEASE_APPROVAL.example.yaml` | **it cannot today.** The block is real; promoting an approved candidate is not implemented. See `products/OPERATIONS.md` §"Gate 6" |

**The delivery bindings come first, and they are not a governed edit.** A `--complete` verdict is an
approval record ABOUT a delivery, so the pack has to name one: with `refresh: REPLACE_ME` the tool
refuses, because there is nothing for the gate to hold constant afterwards. `config/pipeline.yaml`
sits OUTSIDE `config_bundle_sha256`, so filling it in needs no Gate 4 re-approval — that separation
is exactly what the environment split bought. Set it once, and run all three tools
(`run_product_profile.py`, `run_product_schema_check.py`, `source_check.py`) against those values:
the profile stamps what it measured, and the verdict refuses a profile from another cut or schema.
The same bindings are what a production run is later held to — an override that points the job at a
different delivery makes the run unpublishable, because the Gate 3 evidence covers the committed one.

Two more things about Gate 3 worth knowing before you start it, because both cost a day if you find
them late. The verdict generator implements the **data-profiler** evidence route; a vendor whose policy
declares the documentation route can be registered but has no verdict generator yet
(`governance/vendor_policy.yaml` decides which route applies, and fails closed on an unknown vendor).
And the profile is the only Gate 3 artifact that touches vendor data — nothing it produces may enter
the checkout.

Delete this file once the pack is set up.
