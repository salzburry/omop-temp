#!/usr/bin/env python3
"""Lift the VALUE ENUMERATIONS a specification states, as CANDIDATE EVIDENCE for the executable YAML.

This output is NOT executable configuration and no engine reads it. It is the machine-checkable record
of what the specification literally says, so that RWP's approved `variables/` YAML can be compared
against the source instead of trusted. Promotion to executable YAML is a human act, because it requires
deciding the things the spec does not state: numeric codes, fallthrough behaviour, operators, ranges,
source mappings and output names.

This is the one part of the contract-to-YAML step that can be generated rather than written, and the
reason is worth stating precisely.

The contract SUMMARIZES: `derivation: "STATE→region map (codes 1-5, PR→Other region)"`. The YAML
ENUMERATES: fifty-two state codes. Generating the YAML from the contract is impossible — the codes are
not in it. But they ARE in the specification row, verbatim, and that row is already extracted with its
original Excel coordinates. So the enumeration can be lifted from the source rather than retyped.

That matters because retyping is where this repo's worst defect came from: an unanchored find/replace
turned the state code `DE` into the word `Implementation` inside a list of two-letter codes, and it
survived review because it still read like prose.

What it does NOT generate, and must not: windows, tie-breaks, record selection, source mappings,
operators. Those are the contract's judgment fields, they are not enumerations, and on prostate 202607
twenty-eight of the fifty-three records are still blocked on an RWB decision. This tool lifts values;
it decides nothing.

Two shapes are recognised, both unambiguous:

  membership   `if STATE in ('ME' 'VT' ...) then ='Northeast'; else if ...`   -> labelled value lists
  numeric map  `1 = Positive, 2 = Negative, 3 = VUS`                          -> code/label pairs

Anything else is REPORTED, not guessed. A half-parsed enumeration is worse than none: it looks complete.

    python3 platform/tools/spec_codelists.py <extracted.json> [--out FILE]

stdlib only.
"""
import argparse
import json
import os
import re
import sys

# `in ('ME' 'VT' 'NH') then ='Northeast'` — quoted tokens, then the label the branch assigns.
MEMBERSHIP = re.compile(
    r"in\s*\(\s*((?:'[^']+'[\s,]*)+)\)\s*then\s*=?\s*'([^']+)'", re.I)
# `1 = Positive, 2 = Negative` / `1=IHC | 2=FISH` — a code, an equals, a label up to the next separator.
NUMERIC_MAP = re.compile(
    r"(?<![\d.])(\d{1,2})\s*=\s*'?([A-Za-z0-9><=][^,;|<]{0,40}?)'?\s*(?=[,;|]|<br>|$)")
TOKEN = re.compile(r"'([^']+)'")
# `else if STATE is missing then ='Missing'` — a branch with a PREDICATE instead of a member list. The
# first version dropped these entirely, so the generated REGION1 had five branches where the spec states
# six, and the omission was invisible because what remained looked complete.
PREDICATE = re.compile(r"(?:else\s+)?if\s+(\w+)\s+is\s+(missing|null)\s*then\s*=?\s*'([^']+)'", re.I)


def membership_lists(text):
    """Branches of an if/else-if chain, in the order the spec writes them.

    Each is either a MEMBER list or a PREDICATE. Both are branches of one rule and dropping either
    misrepresents the rule — a chain with the missing-value branch removed reads as complete.
    """
    out = []
    for values, label in MEMBERSHIP.findall(text):
        toks = TOKEN.findall(values)
        if toks:
            out.append({"label": label.strip(), "members": toks})
    for col, kind, label in PREDICATE.findall(text):
        out.append({"label": label.strip(), "predicate": f"{col.lower()}_is_{kind.lower()}"})
    return out


def numeric_map(text):
    """[(code, label)] for a `1 = X, 2 = Y` map, requiring the codes to run 1..n without gaps.

    The completeness test is the point: a partial map parsed from a truncated row would produce a
    codelist that silently drops categories.
    """
    pairs = [(int(c), l.strip()) for c, l in NUMERIC_MAP.findall(text)]
    seen, out = set(), []
    for code, label in pairs:
        if code not in seen:
            seen.add(code)
            out.append((code, label))
    out.sort()
    if len(out) < 2 or [c for c, _ in out] != list(range(1, len(out) + 1)):
        return []
    return out


def extract(rows):
    found, skipped = [], []
    for r in rows:
        if not r.get("domain"):
            continue
        text = (r.get("fields", {}).get("definition") or "").replace("<br>", "|")
        if not text:
            continue
        mem = membership_lists(text)
        num = numeric_map(text)
        if mem:
            found.append({"item_id": r["item_id"], "variable": r["variable"], "kind": "membership",
                          "hash": r["content_hash"], "values": mem})
        elif num:
            found.append({"item_id": r["item_id"], "variable": r["variable"], "kind": "numeric_map",
                          "hash": r["content_hash"], "values": num})
        elif re.search(r"\bin\s*\(|\d\s*=\s*[A-Za-z]", text):
            # Looks enumerated but did not parse cleanly — say so rather than emitting a partial list.
            skipped.append({"item_id": r["item_id"], "variable": r["variable"],
                            "why": "looks like an enumeration but does not match a recognised shape"})
    return found, skipped


def provenance(product, source):
    """Where these candidates came from, and whether anyone approved it — read from source_refs.yaml
    rather than asserted. The header used to say "the approved specification" unconditionally, which
    was false for every pack that has one: all three read a stand-in or a reconstruction."""
    lines = [f"# source: {source}"]
    if not product:
        return lines
    try:
        sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
        import source_manifest
        spec = source_manifest.authoritative(product) or {}
        src_id = source_manifest.pipeline_source_id(product)
        lines = [f"# extracted from: {source}"]
        if src_id:
            lines.append(f"# source material: {src_id} (source_refs.yaml)")
        lines.append(f"# authoritative document: {spec.get('document_id', 'not recorded')} "
                     f"— status {spec.get('status', 'not recorded')}")
        lines.append(f"# source approval: {source_manifest.source_status(product) or 'not recorded'}")
    except Exception as exc:                                        # noqa: BLE001
        lines.append(f"# source approval: could not be read ({exc.__class__.__name__})")
    return lines


def to_yaml(found, skipped, source, product=None):
    L = ["# GENERATED by platform/tools/spec_codelists.py.",
         "# Do not hand-edit: regenerate. Every block names the spec row it was lifted from, so any",
         "# value here can be walked back to the original Excel coordinates.",
         "#",
         "# CANDIDATE EVIDENCE — not executable configuration. No engine reads this file. It records what",
         "# the specification literally states so the approved variables/ YAML can be COMPARED against the",
         "# source. Promotion is a human act: numeric codes for membership branches, fallthrough",
         "# behaviour, operators, source mappings and output names are NOT stated here because the spec",
         "# does not state them.",
         "#"] + provenance(product, source) + [""]
    # Rows that LOOK enumerated but did not parse belong in the file, not only in console output: a
    # reader comparing this against the approved YAML must see what the lifter could not account for.
    L.append("unparsed:" if skipped else "unparsed: []")
    for s in skipped:
        L.append(f"  - spec_ref: {s['item_id']}")
        L.append(f"    variable: {json.dumps(s['variable'])}")
        L.append(f"    why: {json.dumps(s['why'])}")
    L.append("")
    L.append("enumerations:" if found else "enumerations: {}")
    for f in found:
        L.append(f"\n  # {f['item_id']}  ({f['variable']})   content hash {f['hash']}")
        L.append(f"  {f['variable'].lower()}:")
        L.append(f"    spec_ref: {f['item_id']}")
        L.append(f"    kind: {f['kind']}")
        L.append("    values:")
        if f["kind"] == "membership":
            for br in f["values"]:
                if "members" in br:
                    members = ", ".join(f'"{m}"' for m in br["members"])
                    L.append(f'      - {{ label: "{br["label"]}", members: [{members}] }}')
                else:
                    L.append(f'      - {{ label: "{br["label"]}", predicate: {br["predicate"]} }}')
            # NO numeric codes. The spec states the branch ORDER, not a code per branch — REGION1N says
            # only "Numeric of REGION1". Numbering them here would be a plausible convention invented by
            # a parser and then indistinguishable from a stated requirement.
            L.append("    numeric_codes: not_stated_by_the_spec")
        else:
            for code, label in f["values"]:
                L.append(f'      - {{ code: {code}, label: "{label}" }}')
            L.append("    numeric_codes: stated_by_the_spec")
    return "\n".join(L) + "\n"


def main(argv):
    ap = argparse.ArgumentParser(description="Lift value enumerations from an extracted spec.")
    ap.add_argument("extracted")
    ap.add_argument("--out")
    ap.add_argument("--product", help="pack dir, so the header can state the source's REAL approval "
                                      "status instead of claiming the spec was approved")
    a = ap.parse_args(argv)
    with open(a.extracted, encoding="utf-8") as fh:
        data = json.load(fh)
    found, skipped = extract(data["rows"])

    print(f"enumerations lifted   {len(found)}")
    for f in found:
        if f["kind"] == "membership":
            n = sum(len(b.get("members", [1])) for b in f["values"])
            shape = f"{len(f['values'])} branch(es), {n} value(s)"
        else:
            shape = f"{len(f['values'])} code(s)"
        print(f"   {f['item_id']:<18} {f['variable'][:20]:<20} {f['kind']:<12} {shape}")
    if skipped:
        print(f"\nlooked enumerated, NOT lifted   {len(skipped)}")
        for s in skipped[:10]:
            print(f"   {s['item_id']:<18} {s['variable'][:20]:<20} {s['why']}")
        print("   A partial enumeration is worse than none — these need a person, not a better regex.")

    if a.out:
        with open(a.out, "w", encoding="utf-8") as fh:
            fh.write(to_yaml(found, skipped, data["extraction"]["target"], a.product))
        print(f"\n-> {a.out}")
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
