#!/usr/bin/env python3
"""Gate 3: does the column each contract record names actually exist in the vendor data?

Every record in every pack currently says `source: unverified` — 77 of them on prostate 202606. Nobody
has confirmed that `birthyear` is really a column of `t_demographics`, or what its null rate is. A
wrong column does not fail the build: it produces a plausible number, which is the failure mode this
whole pipeline exists to make impossible.

This is the SCRIPT half of the governed split. It reads the vendor profile (a `data_profiler.R`
`profile_<cut>.tsv`) and emits VERDICTS — column present or absent, and its kind. A person reads them
and sets the record's status axes. No AI reads the profile.

Missingness, distinct counts, row counts, date ranges and vendor values are in the profile and stay
there: they are vendor-derived, so they belong in the restricted detailed report that
`platform/tools/profile_facts.py` writes, never in this repository. This tool's own report emits none of
them, and a test plants each one and requires it absent.

It reports; it never decides. It does not edit the contract, flip `source:`, or approve a mapping —
exactly like the shared `platform/tools/profile_facts.py`, whose TSV contract it shares:

    table, table_base, column, kind, sampled, n_rows, n_rows_total, pct_missing, distinct,
    date_min, date_max, top_values

The check has TWO halves, and `--profile` is what separates them.

  contract shape (no profile needed)   Is `source.columns` even askable? A value like
                                       `max(specimencollecteddate, resultdate)` or `6 Boolean flags`
                                       is an expression or a sentence: no profile can be asked about
                                       it, so it is a defect of the CONTRACT, not of the data. This
                                       half reads nothing vendor-derived, so CI runs it. In two
                                       stages: `--structure-only` runs today over every pack with a
                                       contract and fails on a declaration that cannot be READ at
                                       all — an unknown kind, a contradictory shape, an unparseable
                                       or block-form `source:`. The full `--check` is Stage 2, once
                                       the current legacy/formula backlog clears; a step that is red
                                       on arrival gets disabled rather than fixed.

  vendor presence (needs the profile)  present / not_in_profile, per record-column usage. Vendor
                                       profiles are restricted material and are not in this
                                       repository, so this half is a local run, never CI.

What the vendor half CAN establish, per record:

  present         the column exists, with its measured shape for a person to judge — POSITIVE evidence
  not_in_profile  the profile does not carry it. That is NOT evidence the column is missing from the
                  data: a profile covering one column per table says nothing about the others. Only
                  with `--complete`, which a person passes to assert the profile is a full schema
                  listing, does this become ABSENT and fail `--check`.

The distinction is the whole calibration. Run against the 25-row fixture in this repo, treating
absence as a defect produced 83 findings, of which essentially all were the fixture being small.

WHICH PHYSICAL TABLE gets searched does not come from the contract. Config owns it. A physical table
name is the most volatile thing here — it changes with the tumour (`t_enh_prostate_lot`) and it
changes with the delivery format for the SAME tumour (a Panoramic rename overlay) — so the contract
names a logical source (`lab`, `lot + mortality`) and this resolves it through the engine's own
config loader, the same call the build and the schema validator make. Nothing in this file knows a
tumour's table or column names. A pack with no config yet falls back to the contract's `physical_stem`.

What it cannot: whether the column is the RIGHT one. `birthyear` existing does not make it the birth
year the requirement means. That is the judgment `source_mapping: human_confirmed` records.

A LEGACY record reading several sources does not say WHICH of them each column belongs to, so the
lookup searches all of them; a STRUCTURED record states one source per input and the question does not
arise. That is exact whenever the column turns up in only ONE — which is the normal
case, and on prostate 202606 it leaves 38 of 52 resolved records single-source and exactly attributed
before the question even arises. Where a name really does exist in two of a record's own sources, it
is reported as `ambiguous_source` and fails an acceptance run (`--complete`), because a green
acceptance run reads as "every mapping verified" and that is precisely what an ambiguous one is not.
The structural fix is one input per source in the contract; until then the ambiguity is a named,
countable list rather than a silent pass.

    python3 platform/tools/source_check.py <product-dir> [--profile <profile_cut.tsv>] [--out FILE]
"""
import argparse
import json
import os
import re
import sys

import yaml

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import profile_io                                                   # noqa: E402
from contract_lint import (records, read, _inline, _list, NOT_VENDOR, source_kind,  # noqa: E402
                           SPEC_REF_RE, SOURCE_KINDS)                              # noqa: E402
from profile_io import CUT                                           # noqa: E402
import product_gates as pg                                           # noqa: E402 — evidence_route, repo_root
from product_gates import read_yaml, sha256, verdict_rel             # noqa: E402 — ONE reader, ONE verdict filename, ONE digest
from engine.config import (PIPELINE,                                     # noqa: E402 — ONE delivery vocabulary
                           delivery_bindings as _delivery_bindings,
                           delivery_keys as _delivery_keys,
                           delivery_required as _delivery_required)

def tool_version():
    """The REPOSITORY commit this ran at.

    A hand-maintained constant goes stale silently — it still said 1.2 while source-union handling,
    --union-member and the structured source shape all landed. But the last commit touching THIS file
    is barely better: Gate 3's behaviour also depends on profile_io, contract_lint, the engine Config
    and the vendor layout, so a change to any of those moves the verdict while this file's revision
    sits still. Repository HEAD plus the contract and config hashes is the honest identity."""
    # A production copy has no .git, so `git rev-parse` would make every deployed run report
    # "(unversioned)" — provenance that disappears exactly where it matters most. RWDP_COMMIT or a
    # generated platform/COMMIT lets a packaged deploy carry its source revision without shipping a
    # repository.
    env = os.environ.get("RWDP_COMMIT", "").strip()
    if env:
        return f"@{env}"
    stamped = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "COMMIT")
    if os.path.exists(stamped):
        with open(stamped, encoding="utf-8") as fh:
            val = fh.read().strip()
        if val:
            return f"@{val}"
    import subprocess
    try:
        out = subprocess.run(["git", "-C", os.path.dirname(os.path.abspath(__file__)),
                              "rev-parse", "--short", "HEAD"],
                             capture_output=True, text=True, timeout=5)
        rev = out.stdout.strip()
        return f"@{rev}" if rev else "(unversioned)"
    except Exception:
        return "(unversioned)"

# NOT_VENDOR — the stems that name no vendor table (constants, build parameters, engine-derived
# values) — is imported, not restated: the maturity gate asks the same question of the same field,
# and two copies of "is this record vendor-sourced?" is how the two gates come to disagree.
# A mapping the profile can be asked about. Anything else — `max(specimencollecteddate, resultdate)`,
# `(no assay field delivered)`, `lot{N}ed` — is an expression or a sentence, and searching a profile
# for it invents a defect. Those are contract defects: `source.columns` must name atomic columns, and
# the formula belongs in `derivation` or `record_selection`.
ATOMIC = re.compile(r"^[a-z_][a-z0-9_]*$")


def profile_columns(tables):
    """{table_base: {column: {kind, pct_missing, distinct, n_rows, ...}}} — the vendor's own
    measurements, projected from tables the SHARED loader already returned, so this tool cannot
    accept a profile the detailed report would reject.

    Takes LOADED tables rather than a path: it parsed the file itself, and check() parsed it again
    for provenance and again for the cut — five validating passes over one TSV per run.
    """
    return {tb.lower(): {c.lower(): {k: (row.get(k) or "").strip()
                                     for k in ("kind", "pct_missing", "distinct", "n_rows",
                                               "date_min", "date_max")}
                         for c, row in cols.items()}
            for tb, cols in tables.items()}


def load_product_config(product):
    """The pack's engine Config, or None when it has not authored one.

    This is why the checker is not tumour-specific. A physical table name is the most volatile thing
    in the system — it changes with the tumour (`t_enh_prostate_lot`) and with the DELIVERY FORMAT
    for the same tumour. Reading it from the contract bakes one tumour's one delivery into the
    requirement document; 59 of the 60 vendor-sourced prostate records restate a stem their own
    config already maps. So the contract names the LOGICAL source and this resolves it, through the
    same loader the build, the schema validator and `platform/tools/profile_facts.py` call — so the active
    overlay applies here too instead of a second, staler answer.
    """
    path = os.path.join(product, "config", "data_product.yaml")
    if not os.path.exists(path):
        return None                    # a contract-only pack: fall back to the contract's own stem
    sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    from engine.config import load_config
    return load_config(path)


def config_base(cfg, name, schema=None, strict=False):
    """The `table_base` a profile would carry for one logical source, under the ACTIVE vendor layout.

    Not the configured stem. Flatiron and COTA both lay tables out as `{schema}.{stem}_{refresh}`, so
    for them base == stem and the difference never shows. A vendor or product that overrides
    `source_layout` — `{schema}.pre_{stem}_{refresh}` — produces `pre_<stem>`, and comparing the stem
    against that reported every column of every source ABSENT: six false defects in a drill on a
    synthetic SCLC pack. So ask the engine what the table is actually called and strip the cut, which
    is what the profiler did to produce `table_base` in the first place.

    Strip the CONFIGURED refresh token, not a date pattern. A pack that has not been pointed at a
    cut yet carries `refresh: REPLACE_ME`, and a date regex leaves `_replace_me` glued to every stem —
    which read as 38 false stem_drift findings against prostate the first time this was written.
    """
    try:
        # In a union member run the table must be resolved in THAT member's schema: a layout
        # referencing {schema} produces a different table name per member, and resolving through the
        # default run.source_schema would check the wrong one while reporting the member's name.
        fq = (cfg.table_in(name, schema) if schema else cfg.table(name)).split(".")[-1]
        refresh = str(cfg.refresh or "")
        if refresh and fq.lower().endswith("_" + refresh.lower()):
            fq = fq[:-(len(refresh) + 1)]
    except Exception as exc:
        # A draft pack with an incomplete `run:` block legitimately cannot resolve, and the stem is
        # the best available. During an ACCEPTANCE run the same fallback would hide a broken layout,
        # schema, refresh or union member behind a plausible-looking answer.
        if strict:
            sys.exit(f"cannot resolve source '{name}' through config ({exc}) — a completeness claim "
                     f"cannot rest on a fallback to the configured stem.")
        fq = cfg.sources[name]
    return CUT.sub("", fq.strip().lower())


def physical_columns(cfg):
    """{logical_source: {logical_column: physical_column}} for the active delivery format.

    The engine's overlay is `{source: {physical: logical}}` — it renames vendor columns INTO the
    logical names the engine and the contract use, at source load. A profile is taken before that
    rename, so it carries the physical name. Searching it for the contract's logical name would
    report a column absent that the build reads perfectly well. This inverts the overlay so the
    lookup asks for what the profile actually contains.

    Empty for an EDM delivery, and empty today for every pack in this repo — no product has authored
    a `rename:` block yet. Wired anyway because it is the mechanism by which a column name changes
    between deliveries of the same tumour, which is the case the contract must survive unedited.
    """
    return {src: {log: phys for phys, log in ren.items()}
            for src, ren in (cfg.source_renames if cfg else {}).items()}


# A logical_table cell names one or more config source keys: `lab`, `lot + mortality`. Parenthetical
# asides (`enhanced (overall anchors)`) are notes about the join, not part of the name.
def logical_parts(value):
    return [p for p in (re.sub(r"\(.*?\)", "", x).strip().lower().replace(" ", "_")
                        for x in value.split("+")) if p]


def verdict_file(product, union_member=None):
    """The report this run reads acceptances FROM and writes back TO.

    Both readers below used to hardcode handoff/SOURCE_VERDICTS.md. A union product's evidence lives
    in SOURCE_VERDICTS.<member>.md, so for every member run they read the wrong file — a reviewed
    acceptance recorded against a member was invisible to the check that acceptance exists to
    satisfy, and regenerating that member's report dropped it. The naming comes from
    product_gates.verdict_rel so this tool and Gate 4 cannot disagree about the filename.
    """
    return os.path.join(product, verdict_rel(union_member))


def _accepted_text(product, union_member=None):
    """The report's raw text, or "" — the ONE read the two accessors below share."""
    path = verdict_file(product, union_member)
    if not os.path.exists(path):
        return ""
    with open(path, encoding="utf-8") as fh:
        return fh.read()


def accepted_block(product, union_member=None):
    """The verbatim `accepted_dependency_name_collisions:` block of the existing report, if any."""
    m = re.search(r"(?ms)^accepted_dependency_name_collisions:\s*\n(?:[ \t-].*\n|\n)*",
                  _accepted_text(product, union_member))
    return m.group(0) if m else ""


def accepted_collisions(product, union_member=None):
    """{(variable_id, source, role, column)} a person has reviewed and confirmed is a real column.

    `derived_input_candidate` is a naming signal, not proof: ETH reads the `race` COLUMN of
    demographics and also depends on the RACE VARIABLE, and RACE's own record maps `race: race` with
    no dependencies, so the column is real. Requiring the raw count to be zero left such a record
    three bad options — delete a valid column, delete a real dependency, or never pass Gate 4.

    So the confirmation gets somewhere to live: an `accepted_dependency_name_collisions:` block in the
    pack's own verdict report (per member for a union product), beside the evidence it qualifies. It is a human's
    signature on one specific mapping, not a switch that turns the check off.
    """
    m = re.search(r"(?ms)^accepted_dependency_name_collisions:\s*\n(.*?)(?=^\S|\Z)",
                  _accepted_text(product, union_member))
    if not m:
        return set()
    try:
        rows = yaml.safe_load(m.group(1)) or []
    except yaml.YAMLError:
        return set()
    return {(str(r.get("record", "")), str(r.get("source", "")), str(r.get("role", "")),
             str(r.get("column", "")).lower())
            for r in rows if isinstance(r, dict) and r.get("rationale")}


LEGACY_ALLOWLIST = "handoff/LEGACY_SOURCES.yaml"

LEGACY_HEADER = """# Legacy `source:` shape — finite migration allowlist
#
# A legacy record states several sources in ONE entry:
#     source: {logical_table: "lot + mortality", columns: {ed: enddate, d: dthdt}}
# so which table each column belongs to is SEARCHED for rather than stated, and the record stays
# `ambiguous_source`. The structured shape states it:
#     source: {kind: vendor, inputs: {lot: {ed: enddate}, mortality: {d: dthdt}}}
#
# Entries are SPECIFICATION ROWS (`<domain>:<row>`), not variable ids. What is being ratcheted down
# is how much of the SPECIFICATION still has a mapping nobody can verify per column — a property of
# the requirement, not of what a record is called. Keyed by name, splitting `LAB` into its 31
# per-analyte records tripled the count while the rows behind them went DOWN, so a pure rename read
# as 32 new violations. Rows are rename-stable.
#
# This file is a RATCHET, not a permission slip. Every row here is existing work that predates the
# structured shape; CI accepts them as temporary exceptions. A legacy record citing a row NOT here
# FAILS CI, so the count can only go down. When every pack's list is empty, delete the legacy
# parser, `logical_parts()` and the physical-stem fallback in source_check.py.
#
# Migrating a record is a SPEC question, not a mechanical edit: it means saying which source each
# column actually comes from, which is exactly what the legacy shape failed to record. Do not
# restructure these by guessing.
#
# Generated by `source_check.py <pack> --write-legacy-allowlist`, which can only SHRINK this list.
# Do not hand-add ids.

allow:
"""


def allowlist_rows(doc):
    """The SPEC ROWS an allowlist states, from its parsed mapping.

    Split out from the file reader because the ratchet has to read the SAME allowlist at a previous
    revision, which exists only as bytes out of `git show`. CI parsed that revision with its own
    `sed` pipeline — a second answer to "what does this allowlist permit", sitting on either side of
    the decision the ratchet exists to make.
    """
    if not isinstance(doc, dict):
        return set()
    return {str(v).strip() for v in (doc.get("allow") or [])}


def legacy_allowlist(product):
    """SPEC ROWS allowed to remain on the legacy `source:` shape, as a finite migration exception.

    A RATCHET. Every id in the file is pre-existing work; a legacy record NOT in it fails the
    structural check, so the count can only fall. Absent file = no exceptions, which is the correct
    default for a pack authored after the structured shape existed.
    """
    path = os.path.join(product, *LEGACY_ALLOWLIST.split("/"))
    if not os.path.exists(path):
        return set()
    # Shared reader: a list-rooted allowlist parses cleanly and then AttributeErrors on .get().
    return allowlist_rows(read_yaml(path)[0] or {})


def legacy_ratchet(product):
    """(new_legacy, stale_allowed) — the two ways the migration can go backwards or go stale.

    `new_legacy` is the one that must fail: a record authored in the legacy shape today re-opens a
    class of ambiguity the structured shape closed, and each one added is one more record whose
    column-to-source mapping nobody ever has to state.

    `stale_allowed` is an id that has been migrated (or removed) but is still listed. Not a defect in
    the data — but the list is the measure of how much migration is left, and one that never shrinks
    stops measuring anything.
    """
    allowed = legacy_allowlist(product)
    path = os.path.join(product, "handoff", "FUNCTIONAL_CONTRACT.md")
    if not os.path.exists(path):
        return [], sorted(allowed)
    legacy = set()
    for block in records(read(path)):
        for ref in legacy_spec_rows(block):
            legacy.add(ref)
    return sorted(legacy - allowed), sorted(allowed - legacy)


def is_legacy_source(block):
    """The legacy SHAPE: several sources named in one string, with no structured `inputs`.

    Defined by shape, not by the presence of `physical_stem`. A structured record may legitimately
    keep the stem the SPEC names as provenance — `{kind: vendor, physical_stem: t_named_in_spec,
    inputs: {...}}` states its per-column mapping and is not ambiguous — and treating that as legacy
    punished a record for preserving source evidence.
    """
    src = _inline(block, "source")
    return bool(src) and "logical_table" in src and "kind:" not in src


def legacy_spec_rows(block):
    """Which SPECIFICATION ROWS this record leaves on an unresolved multi-source mapping.

    The ratchet keys on rows, not on variable_id, because the thing being ratcheted down is how much
    of the SPECIFICATION still has a mapping nobody can verify per column — a property of the
    requirement, not of what a record happens to be called.

    Keying on names made the measure move when nothing did: splitting `LAB` into its 31 per-analyte
    records tripled the id count (19 -> 51) while the spec rows behind them went DOWN (53 -> 50).
    A pure rename read as 32 new violations, and the only way to pass was to grow a file whose whole
    purpose is that it cannot grow. Rows are rename-stable: split, merge or rename the records and the
    number holds; it moves only when someone actually states where a column comes from.
    """
    if not is_legacy_source(block):
        return set()
    out = set()
    for tok in (_list(block, "spec_refs") or []):
        m = SPEC_REF_RE.match(tok.strip())
        if m:
            lo, hi = int(m.group(2)), int(m.group(3) or m.group(2))
            out |= {f"{m.group(1)}:{n}" for n in range(lo, hi + 1)}
    if not out:
        # A legacy record citing no resolvable row — `spec_refs: [none]`, a prose citation, or the
        # key missing entirely. Keying purely on rows would let it escape the ratchet ENTIRELY, which
        # is the fail-OPEN direction: the least traceable record would be the one least counted. Fall
        # back to its name so it still has to be recorded as backlog.
        vid = re.search(r"(?m)^variable_id:\s*(\S+)", block)
        return {f"variable:{vid.group(1)}"} if vid else set()
    return out


class NotComparable(Exception):
    """The base revision, or an allowlist inside it, could not be read. Never an empty answer."""


def _git(root, *args):
    """(stdout, ok). Never raises; the caller decides what an unreadable answer means."""
    import subprocess
    p = subprocess.run(("git", "-C", root, *args), capture_output=True, text=True)
    return p.stdout, p.returncode == 0


def renamed_paths(root, base):
    """{path now: path at `base`} for the allowlists git says were RENAMED between the two.

    A `git mv` IS NOT NEW DEBT. Reading the base revision at the CURRENT path finds nothing, and a
    comparison starting from nothing reads every surviving row as added today: parking
    prostate/202607 as a test fixture moved 55 unchanged rows and CI reported 55 newly allowlisted
    ones, with the real count unmoved. The entry format already carries this lesson one level down —
    entries are spec ROWS rather than variable ids, so renaming a variable is not new debt (see
    LEGACY_HEADER). The file PATH needed the same treatment.
    """
    out, ok = _git(root, "diff", "--name-status", "-M", f"{base}...HEAD", "--",
                   f"*/{os.path.basename(LEGACY_ALLOWLIST)}")
    if not ok:
        raise NotComparable(f"cannot diff {base}...HEAD — the ratchet is a claim about CHANGE and "
                            f"a revision that cannot be read has not been shown to have shrunk")
    out2 = {}
    for line in out.splitlines():
        parts = line.split("\t")
        if len(parts) == 3 and parts[0].startswith("R"):
            out2[parts[2]] = parts[1]
    return out2


def allowlists_at(root, rev, paths):
    """{path: rows} for `paths` as of `rev`. A path absent at `rev` is a NEW allowlist: {} rows.

    FAILS CLOSED on anything else. A blob that will not parse is not an empty allowlist — it is an
    unknown one, and calling it empty makes every row in it read as added today, which is a loud
    failure for a silent cause. Distinguishing the two is why `git show` is asked twice.
    """
    out = {}
    for path in paths:
        blob, ok = _git(root, "show", f"{rev}:{path}")
        if not ok:
            out[path] = set()          # did not exist at `rev` — a genuinely new allowlist
            continue
        try:
            doc = yaml.safe_load(blob)
        except yaml.YAMLError as exc:
            raise NotComparable(f"{path} at {rev}: {exc}") from exc
        out[path] = allowlist_rows(doc or {})
    return out


def ratchet_errors(root, base):
    """[(path, [rows added since `base`])] — every allowlist that GREW. Empty is the pass.

    The in-tree check compares a contract against its allowlist as both stand NOW, so adding a
    legacy record AND its row in one change passes. A ratchet is a claim about CHANGE, so it has to
    be checked against the base revision — and against the base of the SAME file, wherever that file
    has since moved to.
    """
    import repo_hygiene
    name = os.path.basename(LEGACY_ALLOWLIST)
    _, ok = _git(root, "rev-parse", "--verify", f"{base}^{{commit}}")
    if not ok:
        raise NotComparable(f"{base} does not resolve to a commit in {root}")
    now = [p for p in repo_hygiene.tracked(root) if p.endswith("/" + name)]
    renames = renamed_paths(root, base)
    before = allowlists_at(root, base, [renames.get(p, p) for p in now])
    out = []
    for path in now:
        added = sorted(allowlist_rows(read_yaml(os.path.join(root, *path.split("/")))[0] or {})
                       - before[renames.get(path, path)])
        if added:
            out.append((path, added))
    return out


def write_legacy_allowlist(product):
    """Create or SHRINK the allowlist. It can never grow — that is what makes it a ratchet.

    First run on a pack writes the current legacy ids as the baseline. Every later run keeps only
    the ids that are BOTH still legacy and already allowed, so migrating a record and re-running
    drops it. A record that has newly appeared in the legacy shape is refused: regenerating must not
    become the way a new one gets blessed, or the ratchet is just a cache of whatever is there today.
    """
    path = os.path.join(product, *LEGACY_ALLOWLIST.split("/"))
    new_legacy, stale = legacy_ratchet(product)
    existed = os.path.exists(path)
    if existed and new_legacy:
        sys.exit(f"{product}: {', '.join(new_legacy)} use the legacy `source:` shape and are not "
                 f"allowlisted. Regenerating cannot add them — the allowlist only shrinks. Write "
                 f"these records in the structured shape instead.")
    allowed = legacy_allowlist(product)
    keep = sorted(allowed - set(stale)) if existed else sorted(new_legacy)
    if not keep:
        if existed:
            os.remove(path)
            print(f"{product}: allowlist is empty — removed {LEGACY_ALLOWLIST}. The legacy parser, "
                  f"logical_parts() and the physical-stem fallback can go once EVERY pack is here.")
        return 0
    with open(path, "w", encoding="utf-8") as fh:
        # The variable name rides along as a COMMENT: `clinical:17` alone does not tell a reader
        # which requirement is still unresolved, and the comment is regenerated rather than kept by
        # hand so it cannot drift from the row it annotates.
        names = {}
        for block in records(read(os.path.join(product, "handoff", "FUNCTIONAL_CONTRACT.md"))):
            vid = re.search(r"(?m)^variable_id:\s*(\S+)", block)
            for ref in legacy_spec_rows(block):
                if vid:
                    names.setdefault(ref, vid.group(1))
        fh.write(LEGACY_HEADER + "".join(
            f"  - {i}{'' if i not in names else '    # ' + names[i]}\n" for i in keep))
    verb = "wrote" if not existed else f"rewrote (dropped {len(stale)})"
    print(f"{product}: {verb} {LEGACY_ALLOWLIST} with {len(keep)} id(s)")
    return 0


def record_sources(product):
    """[(variable_id, kind, stem, inputs)] where inputs is [{"sources": [...], "columns": {...}}].

    ONE normalized form for both contract shapes, so the checker has one code path:

      structured   source: {kind: vendor, inputs: {lot: {ed: enddate}, mortality: {d: dthdt}}}
                   -> [{sources: [lot], columns: {ed: enddate}},
                       {sources: [mortality], columns: {d: dthdt}}]

      legacy       source: {logical_table: "lot + mortality", columns: {ed: enddate, d: dthdt}}
                   -> [{sources: [lot, mortality], columns: {ed: enddate, d: dthdt}}]

    The difference IS the migration: a structured record has exactly one source per entry, so which
    table a column belongs to is stated rather than searched for, and `ambiguous_source` becomes
    unreachable. A legacy record keeps its several sources in one entry and stays ambiguous, which is
    what makes the remaining work countable.

    Parsed as YAML, never split on commas: splitting tore `"later-of(testdate, resultdate)"` into a
    column called `"later-of(testdate`, and eighteen such phantoms existed on prostate 202606.
    """
    return parse_sources(read(os.path.join(product, "handoff", "FUNCTIONAL_CONTRACT.md")))


def parse_sources(text):
    """The same, from contract TEXT — so a caller holding the file rather than the pack asks this
    parser instead of writing another set of regexes against the same field."""
    out = []
    for block in records(text):
        vid = re.search(r"(?m)^variable_id:\s*(\S+)", block).group(1)
        src = _inline(block, "source")
        if src is None:
            # No `source:` at all is a lint concern (I6), not Gate 3's. But a `source:` written as an
            # indented BLOCK rather than an inline dict reads as None here, and skipping it would drop
            # the record out of Gate 3 silently — the record would look checked because it produced no
            # finding. Nothing currently uses block form; say so rather than wait for the first one.
            if re.search(r"(?m)^source:", block):
                out.append((vid, "bad_shape", "", [],
                            "`source:` is not an inline mapping this can read — either malformed "
                            "YAML or written as an indented block. The lint parses these positionally"))
            continue
        try:
            doc = yaml.safe_load("{" + src + "}")
        except yaml.YAMLError:
            doc = None
        if not isinstance(doc, dict):
            out.append((vid, "unparseable", "", [], None))
            continue

        kind = source_kind(block)
        stem = str(doc.get("physical_stem", "")).strip()
        deps = [d.strip() for d in re.findall(r"(?m)^depends_on:\s*\[([^\]]*)\]", block)
                for d in d.split(",") if d.strip()]

        # Per-kind structure. Each of these was silently survivable: `kind: parameter` with no
        # parameters, `kind: vendor` with no inputs, and an input whose value is a bare string rather
        # than a role map all produced a record with nothing to check and therefore no finding —
        # which is indistinguishable from a record that passed.
        if kind == "invalid":
            out.append((vid, "bad_shape", stem, [],
                        f"source.kind is not one of {sorted(SOURCE_KINDS)}"))
            continue

        # Per-kind structure, both directions. Requiring what a kind NEEDS was not enough: a record
        # could declare `kind: derived` and still carry vendor `inputs`, or `kind: constant` with a
        # `physical_stem`, and the contradiction went unread because only the declared kind was
        # consulted. A record that says two different things about its own source has not chosen one.
        has_inputs = bool(doc.get("inputs"))
        has_params = bool(doc.get("parameters"))
        has_legacy = bool(doc.get("columns") or doc.get("logical_table"))
        forbidden = {
            "derived":     [("inputs", has_inputs), ("parameters", has_params),
                            ("physical_stem", bool(stem)), ("columns/logical_table", has_legacy)],
            "constant":    [("inputs", has_inputs), ("parameters", has_params),
                            ("physical_stem", bool(stem)), ("columns/logical_table", has_legacy)],
            "unavailable": [("inputs", has_inputs), ("parameters", has_params),
                            ("columns/logical_table", has_legacy)],
            "parameter":   [("inputs", has_inputs), ("columns/logical_table", has_legacy)],
            "vendor":      [("parameters", has_params)],
        }[kind]
        clash = [name for name, present in forbidden if present]
        if clash:
            out.append((vid, "bad_shape", stem, [],
                        f"kind:{kind} must not carry {', '.join(clash)} — the record says two "
                        f"different things about where its value comes from"))
            continue
        if kind == "parameter":
            params = doc.get("parameters")
            if not isinstance(params, list) or not params:
                out.append((vid, "bad_shape", stem, [],
                            "kind:parameter needs a non-empty `parameters` LIST"))
                continue
            bad = [str(x) for x in params if "." not in str(x)]
            if bad:
                out.append((vid, "bad_shape", stem, [],
                            f"parameters {', '.join(bad)} are not config paths (`block.key`)"))
                continue
            out.append((vid, kind, stem, [], None))
            continue
        if kind != "vendor":
            out.append((vid, kind, stem, [], None))
            continue

        declared = doc.get("inputs")
        if declared is not None:
            if not isinstance(declared, dict) or not declared:
                out.append((vid, "bad_shape", stem, [], "kind:vendor with empty or malformed "
                                                        "`inputs` — nothing to check is not a pass"))
                continue
            bad = [str(n) for n, cols in declared.items()
                   if not str(n).strip() or not isinstance(cols, dict) or not cols
                   or any(not str(r).strip() or not str(c).strip() for r, c in cols.items())]
            if bad:
                out.append((vid, "bad_shape", stem, [],
                            f"input(s) {', '.join(bad)} are not a non-empty map of role -> column"))
                continue
            inputs = [{"sources": [str(name).strip().lower()],
                       "columns": {str(k): str(v).strip() for k, v in cols.items()}}
                      for name, cols in declared.items()]
        else:
            cols = doc.get("columns") if isinstance(doc.get("columns"), dict) else {}
            parts = logical_parts(str(doc.get("logical_table", "")))
            if not parts and not stem:
                out.append((vid, "bad_shape", stem, [], "kind:vendor names no source at all"))
                continue
            inputs = [{"sources": parts,
                       "columns": {str(k): str(v).strip() for k, v in cols.items()}}]
        out.append((vid, kind, stem, inputs, deps))
    return out


def check(product, profile=None, complete=False, union_member=None):
    """(findings, counts). One finding per record/column usage the profile can speak to.

    `profile` is optional. Without one, only the contract-shape half runs: whether each named column
    is a thing a profile could be asked about at all. That half touches no vendor material, which is
    why CI can run it — and it is the half that found every current failure.

    `complete` is a PERSON's assertion that the profile is a full schema listing. Only then does the
    absence of a column, or of a whole table, become a defect. For a union product it is a claim
    about ONE member schema, named by `union_member`, because one profile cannot speak for the rest.
    """
    # ONE parse per run. The same TSV was loaded up to five times — by profile_columns, for
    # provenance, for the cut, for the verdict's schema and for its data_cut — and profile_io.load
    # validates every row, so a large cross-product profile paid that cost five times over.
    loaded_tables, loaded_cuts = profile_io.load(profile) if profile else ({}, set())
    prof = profile_columns(loaded_tables) if profile else None
    cfg = load_product_config(product)
    accepted = accepted_collisions(product, union_member)
    # The profile must be the cut the config will be built against. profile_io already rejects a
    # MIXED-cut file; this is the other half — a clean, complete 2026m05 profile is not evidence for a
    # product configured at 2026m06, and nothing compared the two.
    # What the profile SAYS it came from, checked against what this pack is. Until the profiler
    # stamped identity onto every row, a `--complete --union-member X` run was an operator assertion
    # that nothing could corroborate: the members share a table stem, so the file itself could not
    # say which schema produced it. The duplicate-hash check caught one file reused for two reports;
    # it could not catch one file attributed to the wrong member, or a synthetic local run submitted
    # as evidence for a real feed.
    if profile and complete:
        said = profile_io.provenance(loaded_tables)
        base = os.path.basename(product)
        # EVERY field, not any. `if not any(...)` rejected only a profile with all four blank, so a
        # file carrying just a cut — or a cut and three blanks — crossed the identity boundary, and
        # the verdict then filled profile_schema in from the CONFIG. "The profile proved its schema"
        # would have become "the config supplied the schema the profile omitted".
        blank = [k for k, v in sorted(said.items()) if not v]
        if blank:
            sys.exit(f"{base}: this profile does not state {', '.join(blank)}, so it cannot say what "
                     f"it measured — regenerate it with the current profiler "
                     f"(run_product_profile.py). A --complete verdict is an approval record; it must "
                     f"not rest on evidence of partly unverifiable origin. (An older anonymous "
                     f"profile is still fine for the restricted diagnostic report.)")
        if said["source_mode"] != "dbi":
            sys.exit(f"{base}: this profile was produced in '{said['source_mode']}' mode, not "
                     f"against a live feed. A local/synthetic run measures files someone wrote by "
                     f"hand — it is a development aid, never Gate 3 evidence.")
        # `--complete` asserts the profile lists EVERY column. The profiler also produces
        # `new-columns-only` (only what a baseline inventory lacked) and `inventory-only` (no column
        # measurement at all), and its own HTML report calls the first partial and says not to use it
        # as a drift input. Nothing said so in the TSV, so an honest partial run submitted under
        # --complete made every absent column look like a defect the profile had ruled out.
        if said["mode"] != profile_io.FULL_PROFILE:
            sys.exit(f"{base}: this profile was produced in '{said['mode']}' mode, which does not "
                     f"list every column. --complete is the assertion that a missing column is a "
                     f"MISSING column rather than one this run did not look at, and a partial "
                     f"profile cannot support it. Re-run the profiler without --new-columns-only / "
                     f"--inventory-only.")
        if cfg is not None:
            # A VERDICT IS AN APPROVAL RECORD ABOUT A DELIVERY, so the pack has to name one.
            #
            # `run_product_profile.py` and `run_product_schema_check.py` take `--cut`/`--schema` and
            # resolve the effective config from them; this tool reads the pack. With
            # `refresh: REPLACE_ME` that made the documented Gate 3 chain unrunnable — the real
            # profile was compared against the placeholder and refused, with a message about the
            # wrong delivery rather than about the unbound one.
            #
            # Overrides are deliberately NOT added here. The gate re-derives `delivery_sha256` from
            # the CHECKOUT to decide whether the config still points at what was measured; evidence
            # produced under a flag the checkout does not carry could never be re-derived, and Gate
            # 3 would stop being checkable at all. Populating `config/pipeline.yaml` is not a
            # governed edit — it sits outside `config_bundle_sha256`, so it needs no re-approval.
            # The keys THIS product uses: a `source_union` resolves member schemas from
            # `source_union.members`, so demanding `run.source_schema` there is a false blocker
            # over a field the engine never reads.
            unbound = [k for k in _delivery_required(cfg.raw)
                       if pg.unstated((_delivery_bindings(cfg.raw) or {}).get(k))]
            if unbound:
                sys.exit(
                    f"{base}: config/{PIPELINE} states no {', '.join(unbound)}, so this pack names "
                    f"no delivery and a --complete verdict would be an approval record about "
                    f"nothing. Set the run bindings to the delivery this evidence covers — that "
                    f"file is outside the Gate 4 configuration digest, so it needs no re-approval.")
            want_schema = union_member or str(getattr(cfg, "source_schema", "") or "").strip()
            checks = [("product", said["product_id"],
                       str(cfg.raw.get("data_product_id") or "").strip()),
                      ("schema", said["schema"], want_schema)]
            for what, got, want in checks:
                if got and want and got.strip().lower() != want.strip().lower():
                    sys.exit(f"{base}: profile says it measured {what} '{got}', but this run is "
                             f"checking '{want}'. The evidence belongs to a different {what}.")
    if profile and complete and cfg is not None:
        said_cut = profile_io.provenance(loaded_tables)["cut"]
        # `Config.refresh` RAISES when `run.refresh` is absent, so getattr's default never applies —
        # a pack that has not been pointed at a cut would have crashed the check rather than skipped
        # it. A pack with no declared refresh simply has no cut to compare against.
        try:
            want = str(cfg.refresh or "").strip()
        except Exception:
            want = ""
        # The STAMP is the cut identity; the table-name suffix corroborates it where the layout
        # happens to carry one. It was the other way round, and that made a Flatiron naming
        # convention load-bearing for every tumour: `run.source_layout` is a documented per-product
        # override and `{schema}` may appear inside the physical name, so a pack whose tables do not
        # end in `_2026m06` produced a profile with NO readable cut and was refused outright — for a
        # cut the profiler had recorded correctly on every row. The stamp is what the run says it
        # measured; the suffix is an inference from a convention the framework does not require.
        if want and not said_cut and not loaded_cuts:
            # Not knowing which delivery was checked is not a milder problem than checking the wrong
            # one. `if want and cuts and ...` skipped the comparison exactly when it was unanswerable.
            sys.exit(f"{os.path.basename(product)}: this profile does not state which cut it "
                     f"measured and its table names carry no cut suffix, while config is built "
                     f"against '{want}'. A complete run must know which delivery it checked — "
                     f"regenerate it with the current profiler (run_product_profile.py --cut).")
        got = {said_cut} if said_cut else loaded_cuts
        if want and want not in got:
            sys.exit(f"{os.path.basename(product)}: profile is cut {sorted(got)} but config is "
                     f"built against '{want}'. A complete run on the wrong cut is evidence for a "
                     f"delivery nobody is building.")
        # Where BOTH are available they must agree. They are derived independently — one stamped by
        # the run, one parsed from the names it read — so a disagreement means the file was assembled
        # or renamed, which neither check can see on its own.
        if said_cut and loaded_cuts and said_cut not in loaded_cuts:
            sys.exit(f"{os.path.basename(product)}: profile is stamped cut '{said_cut}' but its "
                     f"table names say {sorted(loaded_cuts)}. The file has been assembled or renamed.")
    # A union product reads every source from EVERY member schema, and the members share a stem — so
    # one profile looks exactly like full coverage while saying nothing about the other members. That
    # is a false PASS on the gate whose whole job is to stop unverified mappings, so refuse the
    # completeness claim instead of granting it. Endometrial declares EDM u Dostarlimab today.
    if complete and cfg is not None and cfg.source_union:
        members = [m.get("schema", "?") for m in cfg.source_union.get("members", [])]
        if union_member is None:
            howto = "\n".join(
                f"    DC_SCHEMA={m} ... run the profiler ...  then\n"
                f"    source_check.py <pack> --profile <that run>.tsv --union-member {m} "
                f"--complete --out handoff/SOURCE_VERDICTS.{m}.md" for m in members)
            sys.exit(f"{os.path.basename(product)}: config declares source_union over "
                     f"{len(members)} schemas ({', '.join(members)}). One profile cannot evidence "
                     f"all of them, and the members share a table stem, so name the member you are "
                     f"claiming — it is checked against the schema the profiler stamped into the "
                     f"file. Profile each member and write one report each:\n{howto}")
        if union_member not in members:
            sys.exit(f"{os.path.basename(product)}: --union-member '{union_member}' is not a "
                     f"declared member. Members are: {', '.join(members)}.")
    smap = dict(cfg.sources) if cfg else {}
    renames = physical_columns(cfg)
    findings = []
    counts = {"present": 0, "absent_column": 0, "absent_table": 0, "not_in_profile": 0,
              "unprofiled": 0, "not_a_column": 0, "not_a_table": 0, "unknown_source": 0,
              "not_vendor": 0, "unchecked": 0, "resolved_via_config": 0, "stem_drift": 0,
              "ambiguous_source": 0, "bad_shape": 0,
              "derived_input_candidate": 0}
    seen_pairs = set()
    for vid, kind, stem, inputs, deps in record_sources(product):
        if kind == "bad_shape":
            counts["bad_shape"] += 1
            findings.append((vid, "-", "-", "-", "bad_shape", deps))
            continue
        # derived / parameter / constant / unavailable name no vendor column anyone could profile.
        if kind != "vendor":
            counts["not_vendor"] += 1
            continue

        record_resolved = True
        for entry in inputs:
            parts, mapping = entry["sources"], entry["columns"]
            resolved = [p for p in parts if p in smap]
            bases = [config_base(cfg, p, union_member, strict=complete) for p in resolved]
            contract_base = CUT.sub("", stem.strip().lower()) if stem else ""
            if parts and len(bases) == len(parts):
                if len(bases) == 1 and contract_base and contract_base != bases[0] and len(inputs) == 1:
                    # Not fatal: config is the authority and was used. But the contract carries a
                    # physical name that no longer agrees with the delivery it will be built against.
                    counts["stem_drift"] += 1
                    findings.append((vid, stem, "-", "-", "stem_drift",
                                     f"config maps `{parts[0]}` to `{bases[0]}`; the contract says "
                                     f"`{contract_base}`. Config was used. Where the spec NAMED that "
                                     f"table the stem is registered evidence and stays; where it "
                                     f"was inferred, drop it"))
                stem_ok = True
            elif cfg and parts:
                # PARTIAL resolution must not fall back. Falling back to the single stem put every
                # column of a multi-source record into one arbitrary table: `lot + mortality +
                # nosuchsource` searched only the LOT table and reported `dthdt` ABSENT_COLUMN over
                # the message "every source table of this record is in the profile" — untrue.
                counts["unknown_source"] += 1
                record_resolved = False
                stem_ok, bases = False, []
                findings.append((vid, " + ".join(parts), "-", "-", "unknown_source",
                                 f"config has no source named "
                                 f"{', '.join(repr(p) for p in parts if p not in smap)} — known "
                                 f"sources are {', '.join(sorted(smap)) or '(none)'}"))
            else:
                # No config authored, or no source named at all: fall back to the contract's own
                # stem, which then has to survive the same guard a column does. Three live records
                # carry a stem that is not one table name — a six-table comma list, `a + b`,
                # `x (unconfirmed)` — each searched verbatim, so each produced a false ABSENT.
                record_resolved = False
                stem_ok = bool(ATOMIC.match(contract_base))
                bases = [contract_base] if stem_ok else []
                # Two different failures were being reported as one. A stem that is PRESENT and not a
                # table name is malformed, and that is the contract's defect whatever config says. A
                # record with no stem that names a logical source a pack without config cannot
                # resolve is merely unresolved — blaming it turned prostate 202607, which names its
                # sources perfectly well and has authored no config yet, into 25 defects the moment
                # its inferred stems came out. The latter is `unchecked`, which stem_ok: False
                # already makes it.
                if not stem_ok and (stem or not parts):
                    counts["not_a_table"] += 1
                    findings.append((vid, stem, "-", "-", "not_a_table",
                                     f"neither config nor the contract gives one table name for "
                                     f"`{' + '.join(parts) or '(no source named)'}` — name logical "
                                     f"sources config maps, and put an aside in `notes`"))
            base = bases[0] if bases else stem.strip().lower()
            # A source the profile does not carry makes this entry's absences INCONCLUSIVE: `dthdt`
            # missing from the lot table proves nothing when the mortality table — the one it
            # actually lives in — was never profiled.
            absent_bases = [b for b in bases if b not in prof] if prof is not None else []
            table = ({k: v for b in bases if b in prof for k, v in prof[b].items()}
                     if prof is not None else None)
            shown = "+".join(bases) or stem
            # The active delivery's column renames, for the sources this entry reads. The contract
            # states the logical column name; a profile is taken BEFORE the rename, so it carries
            # the physical one, and searching for the logical name would call a column absent that
            # the build reads perfectly well.
            record_renames = {}
            for p in resolved:
                record_renames.update(renames.get(p, {}))

            for role, col in sorted(mapping.items()):
                low = col.strip().lower()
                # A dotted value is a config path (study.index_end), not a vendor column.
                if "." in low or NOT_VENDOR.match(low):
                    counts["not_vendor"] += 1
                    continue
                # An expression or a sentence cannot be looked up. Reporting it ABSENT would invent
                # a defect; it IS a defect, but of the contract.
                if not ATOMIC.match(low):
                    counts["not_a_column"] += 1
                    findings.append((vid, shown, role, col, "not_a_column",
                                     "not an atomic column name — put the formula in `derivation` "
                                     "or `record_selection` and name the columns it reads"))
                    continue
                # A vendor input naming a variable this record already DEPENDS ON is not a vendor
                # column — it is a derived input written in the wrong field, and the profile will
                # either miss it or match a coincidental namesake. COHORTU lists `treat_flag` under
                # `lot` and in depends_on; PSADIAG_CRPC puts the CRPC anchor under `psa`.
                if (col.strip().upper() in {d.upper() for d in (deps or [])}
                        and (vid, parts[0] if parts else "", role, col.strip().lower())
                        not in accepted):
                    counts["derived_input_candidate"] += 1
                    findings.append((vid, shown, role, col, "derived_input_candidate",
                                     "this record already lists it in `depends_on`. Almost always "
                                     "that means a derived input written in the wrong field — but a "
                                     "vendor column CAN share a name with a variable, so a person "
                                     "decides. Move it, or confirm it really is this table's column"))
                    continue
                low = record_renames.get(low, record_renames.get(col.strip(), low)).lower()
                seen_pairs.add((base, low))
                # No profile, or no table to look in: the name is askable but nothing was asked.
                if prof is None or not stem_ok:
                    counts["unchecked"] += 1
                    continue
                # WHICH source carries it. A structured record states one source per entry, so this
                # is exact by construction. A legacy entry naming several is exact too WHENEVER the
                # column turns up in only one of them — and only a real collision is undecidable.
                carriers = [b for b in bases if b in prof and low in prof[b]]
                if len(carriers) > 1:
                    counts["ambiguous_source"] += 1
                    findings.append((vid, "+".join(carriers), role, col, "ambiguous_source",
                                     f"carried by {len(carriers)} of this entry's sources — which "
                                     f"one the requirement means is not stated, so presence here is "
                                     f"not evidence for a mapping. One input per source fixes it"))
                    continue
                met = table.get(low)
                if met is None and absent_bases:
                    counts["absent_table" if complete else "unprofiled"] += 1
                    findings.append((vid, shown, role, col,
                                     "ABSENT_TABLE" if complete else "unprofiled",
                                     f"not found, and {len(absent_bases)} of this entry's source "
                                     f"table(s) are not in the profile: {', '.join(absent_bases)}"))
                elif met is None:
                    counts["absent_column" if complete else "not_in_profile"] += 1
                    findings.append((vid, shown, role, col,
                                     "ABSENT_COLUMN" if complete else "not_in_profile",
                                     f"every source table of this entry is in the profile, carrying "
                                     f"{len(table)} column(s) between them"))
                else:
                    counts["present"] += 1
                    findings.append((vid, carriers[0] if carriers else shown, role, col,
                                     "present", met["kind"]))
        if record_resolved and inputs:
            counts["resolved_via_config"] += 1
    counts["unique_mappings"] = len(seen_pairs)
    return findings, counts


def _refresh_or_none(cfg):
    """`Config.refresh` raises when `run.refresh` is unset, so it cannot be read with a default."""
    try:
        return str(cfg.refresh or "none") if cfg is not None else "none"
    except Exception:
        return "none"


def _profile_schema(tables):
    """The schema the profile says it measured, or "" when it does not say (a pre-identity file).

    Takes the ALREADY-LOADED tables. It used to take the path and parse the file again, which is how
    one --complete run came to validate the same TSV five times over.
    """
    if not tables:
        return ""
    try:
        return profile_io.provenance(tables)["schema"] or ""
    except SystemExit:
        return ""


def _schema_validation_fields(path):
    """The three front-matter fields describing the live-schema artifact, or explicit `none`.

    `none` rather than omission: Gate 4 treats an absent counter as an unanswered question, and the
    same reasoning applies here — a field that is not written cannot be told apart from a field
    nobody produced.
    """
    if not path:
        return {"schema_validation_sha256": "none", "schema_validation_result": "none",
                "schema_validation_cut": "none", "schema_validation_product_id": "none",
                "schema_validation_schema": "none", "schema_validation_config_sha256": "none"}
    if not os.path.exists(path):
        sys.exit(f"--schema-validation {path}: no such file. Produce it with "
                 f"`run_product_schema_check.py <pack> --cut <cut> --schema <schema> --out-dir <restricted>`.")
    try:
        with open(path, encoding="utf-8") as fh:
            ev = json.load(fh)
    except Exception as e:                                          # noqa: BLE001
        sys.exit(f"--schema-validation {path}: not readable as the JSON that "
                 f"run_product_schema_check.py writes ({e}).")
    # Carry the report's own IDENTITY, not just its verdict. The checker stamps product_id and
    # source_schema into the JSON for the same reason the profile TSV carries them; recording only
    # sha/result/cut here threw that away, so a passed report for product A member A could be
    # attached to a verdict for product B member B and satisfy every check — nonempty checksum,
    # passed_live, matching cut. Acute for a source union, where the members share a cut.
    return {"schema_validation_sha256": sha256(path),
            "schema_validation_result": str(ev.get("schema_presence") or "unknown"),
            "schema_validation_cut": str(ev.get("cut") or "none"),
            "schema_validation_product_id": str(ev.get("product_id") or "none"),
            "schema_validation_schema": str(ev.get("source_schema") or "none"),
            "schema_validation_config_sha256": str(ev.get("config_sha256") or "none")}


def render(product, profile, findings, counts, complete=False, union_member=None,
           schema_validation=None, *, tables=None, cuts=None):
    # KEYWORD-ONLY, and after schema_validation: the CLI calls this positionally, so inserting a
    # parameter mid-signature silently bound schema_validation to `tables`.
    if profile and tables is None:
        tables, cuts = profile_io.load(profile)
    tables, cuts = tables or {}, cuts or set()
    name = "/".join(product.rstrip("/").split(os.sep)[-2:])
    cfg_path = os.path.join(product, "config", "data_product.yaml")
    cfg_obj = load_product_config(product)
    # MACHINE-READABLE front matter. The prose below is for a person; Gate 4 needs to check the
    # result, not read it — and checking only "does a file exist with the right contract hash" let a
    # shape-only report with no profile at all satisfy the evidence requirement.
    fm = {"gate3_result": "passed" if not (
              counts["absent_column"] + counts["absent_table"] + counts["not_a_column"]
              + counts["not_a_table"] + counts["unknown_source"] + counts["bad_shape"]
              + counts["ambiguous_source"] + counts["derived_input_candidate"]
              + (counts["unchecked"] if complete else 0)) else "failed",
          "contract_sha256": sha256(os.path.join(product, "handoff", "FUNCTIONAL_CONTRACT.md")),
          # The DELIVERY digest, not the root file's: `data_format`, `source_schema` and `refresh`
          # live in config/pipeline.yaml since the environment split, and all three change which
          # tables and columns this check resolved. See product_gates.delivery_sha256.
          "config_sha256": pg.delivery_sha256(product),
          "profile_sha256": sha256(profile) if profile else "none",
          "data_cut": (sorted(cuts) or ["unknown"])[0] if profile else "none",
          "config_refresh": _refresh_or_none(cfg_obj),
          "complete": bool(complete),
          # WHICH schema the profile covered. Gate 4 compares the live-schema report against this,
          # and without it a single-schema pack had nothing to compare to at all: the check could
          # only ever fire for a union, which is precisely the case a reviewer would assume was the
          # hard one and the other the safe one.
          # From the PROFILE's own stamp. Not the config: under --complete identity is mandatory, so
          # a config fallback could only ever paper over a profile that failed to say what it
          # measured — which is the one thing this field exists to record.
          "profile_schema": _profile_schema(tables) or "none",
          "union_member": union_member or "none",
          "tool": tool_version()}
    # LIVE-SCHEMA evidence. `live_schema_check: passed` was a status axis a person could write with
    # nothing behind it: Gate 4 validated the value profile thoroughly and never looked at the schema
    # report at all. Recording the artifact's checksum, its own result and the cut it covers here
    # means the same gate that proves the profile also proves this — and for a union it is per
    # member, like everything else in this file.
    fm.update(_schema_validation_fields(schema_validation))
    for k in ("unchecked", "ambiguous_source", "derived_input_candidate", "bad_shape",
              "not_a_column", "not_a_table", "unknown_source", "absent_column", "absent_table"):
        fm[k] = counts[k]
    L = ["---"] + [f"{k}: {str(v).lower() if isinstance(v, bool) else v}" for k, v in fm.items()]
    L += ["reviewed_by: TODO          # the accountable human, set BY HAND after reading this",
          "review_date: TODO", "---", ""]
    # Carry forward the reviewed acceptances. Without this, regenerating the report ERASED the block
    # that made `derived_input_candidate` zero — leaving a clean-looking count with the reasoning that
    # justified it deleted, and the reviewer's work to be redone every run.
    kept = accepted_block(product, union_member)
    if kept:
        L += [kept.rstrip(), ""]
    L += [
          f"# Gate 3 source verdicts — {name}", "",
         "GENERATED by `platform/tools/source_check.py`. **Verdicts only.** No missingness, distinct "
         "count, date range, row count or vendor value appears here: those are vendor-derived "
         "statistics and belong in the restricted profile report, not in this repository.", "",
         "**This does not approve a mapping.** A column existing does not make it the RIGHT column — "
         "that judgment is what `source_mapping: human_confirmed` records. Read the restricted "
         "profile report, then set each record's status axes BY HAND.", "",
         "## Provenance", "",
         "| | |", "|---|---|",
         f"| tool | `source_check.py` {tool_version()} |",
         # Without these the verdict outlives the thing it was a verdict ABOUT: change a column in the
         # contract, or repoint a source in config, and the report still carries the same profile
         # checksum, so it reads as current. Config belongs here because config picks the table.
         f"| contract sha256 | `{sha256(os.path.join(product, 'handoff', 'FUNCTIONAL_CONTRACT.md'))}` |"]
    cfg_path = os.path.join(product, "config", "data_product.yaml")
    if os.path.exists(cfg_path):
        cfg = load_product_config(product)
        # THE DIGEST THE GATE ACTUALLY CHECKS, under the name the front matter uses. This printed
        # `sha256(config/data_product.yaml)` labelled "config sha256" while the machine-readable
        # `config_sha256` had become the DELIVERY digest — so a human reviewer, who is the whole
        # audience for this table, was shown a different number under the same name. The root
        # file's checksum stays, named as the root file, because the delivery digest is built on it.
        bind = _delivery_bindings(cfg.raw)
        L += [f"| config sha256 (delivery) | `{pg.delivery_sha256(product)}` — the root config plus "
              f"{', '.join(_delivery_keys(cfg.raw))}; this is the value Gate 3 re-derives |",
              f"| config/data_product.yaml sha256 | `{sha256(cfg_path)}` |",
              "| delivery bindings | " + "; ".join(
                  f"{k}={bind.get(k) if bind.get(k) not in (None, '') else '—'}"
                  for k in _delivery_keys(cfg.raw)) + " |",
              f"| active data_format | {cfg.data_format or 'EDM (no overlay)'} |"]
    else:
        L += ["| config | none — physical tables came from the contract's own `physical_stem` |"]
    if profile:
        L += [f"| profile file | `{os.path.basename(profile)}` |",
              f"| profile sha256 | `{sha256(profile)}` |",
              f"| completeness asserted | "
              f"{'yes (--complete)' if complete else 'NO — absence proves nothing'} |"]
        if union_member:
            L += [f"| union member evidenced | `{union_member}` — this verdict covers THIS member "
                  f"schema only; the others need their own run |"]
    else:
        L += ["| profile file | none — **contract shape only**, no column was looked up |"]
    L += ["", "## Counts", "", "| what | count |", "|---|---|"]
    L.append(f"| unique table.column mappings | {counts['unique_mappings']} |")
    L.append(f"| records whose source resolved through config | {counts['resolved_via_config']} |")
    for k in ("present", "absent_column", "absent_table", "not_in_profile", "unprofiled",
              "unchecked", "not_a_column", "not_a_table", "unknown_source", "ambiguous_source",
              "bad_shape", "derived_input_candidate", "stem_drift", "not_vendor"):
        L.append(f"| {k} (record-column usages) | {counts[k]} |")
    for state, title in (
            ("bad_shape", "CONTRACT DEFECT — `source` is not a shape this can read: an unknown "
                          "`kind`, or a vendor record with no usable inputs"),
            ("derived_input_candidate", "NEEDS A DECISION — a vendor input names a variable this "
                                        "record already depends on. Usually a derived input in the "
                                        "wrong field; a person confirms or moves it"),
            ("ambiguous_source", "AMBIGUOUS — the column name exists in more than one of this "
                                 "record's sources, and the contract does not say which is meant"),
            ("unknown_source", "CONTRACT DEFECT — `logical_table` names a source this pack's config "
                               "does not define, so there is no table to search"),
            ("not_a_table", "CONTRACT DEFECT — no config source and no usable stem, so this record's "
                            "columns cannot be looked up anywhere"),
            ("stem_drift", "The contract's `physical_stem` disagrees with the config it will be "
                           "built against. Config was used. Where the spec NAMED that table the stem "
                           "is registered evidence and stays; where it was inferred, drop it"),
            ("not_a_column", "CONTRACT DEFECT — `source.columns` does not name an atomic column, so "
                             "no profile can be asked about it"),
            ("ABSENT_TABLE", "ABSENT — the profile carries no rows for this table"),
            ("ABSENT_COLUMN", "ABSENT — the profile carries this table but not this column"),
            ("unprofiled", "Table not in this profile — no evidence either way"),
            ("not_in_profile", "Column not in this profile — no evidence either way"),
            ("present", "Present in the profile (kind only; statistics stay in the restricted report)")):
        rows = [f for f in findings if f[4] == state]
        if not rows:
            continue
        L += ["", f"## {title} ({len(rows)})", "",
              "| record | table | role | column | evidence |", "|---|---|---|---|---|"]
        L += [f"| {v} | `{s}` | {r} | `{c}` | {e} |" for v, s, r, c, _st, e in rows]
    return "\n".join(L) + "\n"


def main(argv):
    ap = argparse.ArgumentParser(description="Gate 3: check contract source columns against a profile.")
    ap.add_argument("product", nargs="?",
                    help="the pack to check. Omitted only with --ratchet-against, which is "
                         "repo-wide rather than per-pack.")
    ap.add_argument("--ratchet-against", metavar="REV",
                    help="CI: every LEGACY_SOURCES.yaml in the repo may only SHRINK relative to REV. "
                         "Rename-aware — a pack that moved is compared against its own base.")
    ap.add_argument("--profile", help="data_profiler.R profile_<cut>.tsv. Omit to run the "
                                      "contract-shape half only, which reads no vendor material.")
    ap.add_argument("--out", help="write the facts report here")
    ap.add_argument("--complete", action="store_true",
                    help="assert this profile is a FULL schema listing, so a column it does not carry "
                         "is genuinely absent. A person makes that claim, not the tool.")
    ap.add_argument("--schema-validation",
                    help="SCHEMA_VALIDATION_<cut>.json from run_product_schema_check.py for THIS "
                         "member/cut. Recorded in the verdict front matter so Gate 4 can prove the "
                         "live-schema evidence behind `live_schema_check: passed`.")
    ap.add_argument("--union-member", help="for a source_union product, the member schema THIS "
                                          "profile was taken from. Required with --complete.")
    ap.add_argument("--write-legacy-allowlist", action="store_true",
                    help="create or shrink handoff/LEGACY_SOURCES.yaml from the records' own shape. "
                         "Never adds ids — a newly legacy record is refused, not blessed.")
    ap.add_argument("--structure-only", action="store_true",
                    help="fail ONLY on a source declaration that cannot be read at all — an unknown "
                         "kind, a contradictory shape, empty or malformed inputs. Tolerates legacy "
                         "declarations, unresolved source names and human-review candidates, so it "
                         "can protect a new tumour today without waiting for an existing backlog.")
    ap.add_argument("--check", action="store_true", help="exit non-zero if any named column is ABSENT")
    a = ap.parse_args(argv)

    if a.ratchet_against:
        try:
            grew = ratchet_errors(pg.repo_root(), a.ratchet_against)
        except NotComparable as exc:
            sys.exit(f"legacy-source ratchet: {exc}")
        for path, added in grew:
            print(f"{path}: allowlist GREW by {len(added)} row(s): {', '.join(added)}")
        if grew:
            print("\n  The legacy shape is a finite migration exception, not a syntax. Write these")
            print("  records with one source per input instead:")
            print("    source: {kind: vendor, inputs: {lot: {ed: enddate}, mortality: {d: dthdt}}}")
            return 1
        print(f"ok  legacy-source allowlists have not grown since {a.ratchet_against}")
        return 0
    if not a.product:
        ap.error("a product pack is required (or --ratchet-against REV)")

    product = os.path.abspath(a.product)
    if not os.path.isdir(product):
        sys.exit(f"{a.product}: no such product directory")
    if a.write_legacy_allowlist:
        return write_legacy_allowlist(product)
    if a.complete and not a.profile:
        sys.exit("--complete asserts something about a profile; pass --profile too")
    # WHICH EVIDENCE THIS PRODUCT OWES, stated rather than assumed. `--profile` was optional and its
    # absence meant two different things — "this product is evidenced another way" and "nobody has run
    # one yet" — with no way to tell them apart. The route is declared per vendor
    # (governance/vendor_policy.yaml, or `evidence_route:` on the registry entry); a product whose
    # route is the vendor's documentation is not missing a profile, and a profile handed to it is
    # evidence of the wrong kind. Reported, not silently tolerated, in both directions.
    _root = pg.repo_root()
    _rel = os.path.relpath(product, _root).replace(os.sep, "/")
    _route, _route_why = pg.evidence_route(_root, _rel)
    if a.profile and _route not in (None, "data_profile"):
        sys.exit(f"{_rel}: --profile was given, but this product's declared schema evidence is "
                 f"{_route} ({_route_why}). Change the declaration where it is stated, or check the "
                 f"evidence the product actually owes.")
    # ...and a DECLARED route with no report behind it is refused HERE, where the operator is, rather
    # than producing a verdict file carrying `profile_sha256: none` for Gate 4 to reject two steps
    # later for a reason that has nothing to do with the real situation. `--structure-only` still
    # runs: the contract-shape half needs no evidence of any kind, and refusing it would block the
    # CI check every pack passes.
    _gap = pg.unimplemented_route(_root, _rel)
    if _gap and not a.structure_only:
        sys.exit(_gap)
    # A pack with no contract is not a Gate 3 failure, it is a pack Gate 3 does not apply to — the
    # same shape as Gate 2's --list-strict. Say so and pass, so a loop over discovered packs runs to
    # the end instead of stopping on a traceback at the first pack that has not written one.
    if not os.path.exists(os.path.join(product, "handoff", "FUNCTIONAL_CONTRACT.md")):
        print(f"{os.path.basename(product)}: no handoff/FUNCTIONAL_CONTRACT.md — Gate 3 does not apply")
        return 0
    findings, counts = check(product, a.profile, a.complete, a.union_member)
    if a.structure_only:
        # Stage 1 of the CI rollout. Waiting for prostate's and ovarian's semantic backlog before
        # protecting ANY pack means every new tumour is unprotected in the meantime — and a
        # contradictory or unreadable source declaration is not a backlog item, it is a typo.
        fatal = counts["bad_shape"]
        # The legacy shape is a finite, shrinking exception — see handoff/LEGACY_SOURCES.yaml. A NEW
        # legacy record is not backlog, it is backlog being ADDED, so it fails here with the rest of
        # the structural checks rather than waiting for the profile-reading stage.
        new_legacy, stale = legacy_ratchet(product)
        if new_legacy:
            fatal += len(new_legacy)
            print(f"  legacy_source   {len(new_legacy)} record(s) use the legacy `source:` shape and "
                  f"are not in {LEGACY_ALLOWLIST}: {', '.join(new_legacy)}\n"
                  f"    State one source per input instead:\n"
                  f"      source: {{kind: vendor, inputs: {{lot: {{ed: enddate}}, "
                  f"mortality: {{d: dthdt}}}}}}\n"
                  f"    The allowlist is a ratchet for records that predate that shape; it does not "
                  f"take new entries.")
        if stale:
            print(f"  note: {LEGACY_ALLOWLIST} still lists {len(stale)} migrated/removed id(s) "
                  f"({', '.join(stale)}) — drop them so the list keeps measuring what is left.")
    else:
        fatal = (counts["absent_column"] + counts["absent_table"] + counts["not_a_column"]
                 + counts["not_a_table"] + counts["unknown_source"] + counts["bad_shape"])
    # An ambiguous column is not a data defect, so a diagnostic run reports it and passes. But
    # --complete --check IS the acceptance run, and a green acceptance run reads as "every mapping
    # verified" — which is exactly what an ambiguous one is not.
    if a.complete and not a.structure_only:
        # An ACCEPTANCE run asserts every mapping was evidenced. `unchecked` means the opposite —
        # nothing was looked up, because no config resolved the source — and it was not fatal, so a
        # contract-only pack could return success having verified nothing at all.
        # Both are "a person must decide", not "the data is wrong" — so they block an ACCEPTANCE
        # run and not a diagnostic one, the same calibration `unchecked` uses.
        fatal += (counts["ambiguous_source"] + counts["unchecked"]
                  + counts["derived_input_candidate"])
    print(f"{os.path.basename(product)}: " + " · ".join(f"{k} {v}" for k, v in sorted(counts.items())))
    for v, s, r, c, st, e in findings:
        if st.startswith("ABSENT") or st in ("not_a_column", "not_a_table", "unknown_source",
                                             "ambiguous_source", "bad_shape",
                                             "derived_input_candidate"):
            print(f"  {st:<14} {v:<16} {s}.{c}")
    if a.out:
        # Render BEFORE opening for write. `open(path, "w")` truncates as soon as it is evaluated,
        # and Python evaluates it before the argument to `write()` — so rendering inside the `with`
        # made render() read a file this very call had just emptied, silently dropping the reviewed
        # acceptances it was supposed to carry forward.
        text = render(product, a.profile, findings, counts, a.complete, a.union_member,
                      a.schema_validation)
        with open(a.out, "w", encoding="utf-8") as fh:
            fh.write(text)
        print(f"-> {a.out}")
    # not_a_column / not_a_table fail REGARDLESS of --complete: a contract that cannot be checked is
    # not a contract that passed. Absence of a table or column fails only once completeness is asserted.
    return 1 if (a.check and fatal) else 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
