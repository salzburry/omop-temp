#!/usr/bin/env python3
"""Every unfilled placeholder in a pack, and WHY each one is there.

    python3 platform/tools/placeholders.py <pack>
    python3 platform/tools/placeholders.py --all
    python3 platform/tools/placeholders.py --all --check   # exit 1 if any is UNACCOUNTED

WHY THIS EXISTS. `grep -r REPLACE_ME` returns 77 hits on prostate/202606 and 317 on oc/202606, and a
reader who stops there concludes the work is unfinished. Most of them are not unfinished work: three
are the run-time environment bindings the config deliberately refuses to hardcode, and the build
REFUSES to start while they are unfilled; others sit on records blocked by a decision that is
recorded, numbered and reported. A count cannot tell those apart from real gaps. This classifies
them, so the question "what are all these placeholders" has an answer that is checkable instead of
remembered.

FOUR CLASSES, and only the last is a finding:

  RUNTIME BINDING     `run.refresh` / `run.source_schema` / `run.output_schema`. The pack states no
                      environment on purpose — a Databricks job or notebook widget supplies them per
                      run, with no code change — and `engine.validate.check` raises on a placeholder
                      left in place, so one can never reach a build.
  PENDING DELIVERABLE a `TBD` on a source material whose status is `pending`. The approved workbook
                      has not been delivered; Gate 1 reports it and refuses to call the source
                      approved. The placeholder IS the honest record of that.
  BLOCKED, RECORDED   a placeholder in a contract record that cites a decision or engine gap AND
                      carries `requirement: decision_required` — the status that means the record
                      cannot be finished until the question is answered. Both halves are needed:
                      citing a question is not the same as being blocked by one, and the first
                      version of this tool treated them as identical. That excused 39 records on
                      prostate/202606 whose `requirement` was merely `draft` — a decision about the
                      lab selection window was excusing an empty `type` field.
  UNACCOUNTED         everything else, including a record that cites a question it is not waiting
                      on. Real, and the only number worth arguing about.

SCOPED TO THE PREFIX PLACEHOLDERS — TODO, TBD, REPLACE_ME, XXX, PENDING — and deliberately NOT to
`product_gates.PLACEHOLDERS_EXACT` (`n/a`, `-`, `NA`, `?`). Those are unstated in a field asking who
approved something, and a legitimate ANSWER in a record field asking which window applies. Reporting
every `n/a` in 202 records would bury four real findings under a thousand correct ones, which is how
a check stops being read. `unstated()` remains the one predicate for "is this field answered"; this
asks a narrower question and says so.

READ-ONLY. stdlib only (plus PyYAML, through the tools it calls).
"""
import argparse
import os
import re
import sys

TOOLS = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(os.path.dirname(TOOLS))
sys.path.insert(0, TOOLS)

import contract_lint as cl   # noqa: E402
import product_gates as pg   # noqa: E402
import source_manifest as sm  # noqa: E402

WIDTH = 94
SCANNED = (".yaml", ".yml", ".md")

# The environment bindings the config declines to hardcode. Named here because the CLASS is what is
# being asserted — that these three, and only these, are supplied per run.
RUNTIME_KEYS = ("run.refresh", "run.source_schema", "run.output_schema")
RUNTIME_RE = re.compile(r"^\s*(refresh|source_schema|output_schema)\s*:", re.M)

BINDING = "runtime binding"
PENDING = "pending deliverable"
BLOCKED = "blocked, recorded"
UNACCOUNTED = "UNACCOUNTED"

# Files a placeholder can appear in while being ABOUT placeholders rather than one. The template and
# the docs describe the substitutions a new tumour makes; a scaffold is generated and regenerated.
PROSE = ("README.md", "NEW_TUMOUR.md", "SCAFFOLDED_RECORDS.md")


def _hits(path):
    """[(line number, line)] for every prefix-placeholder occurrence in a file."""
    try:
        with open(path, encoding="utf-8", errors="replace") as fh:
            lines = fh.read().splitlines()
    except OSError:
        return []
    pat = re.compile(r"\b(" + "|".join(pg.PLACEHOLDERS_PREFIX) + r")\b")
    return [(i, l) for i, l in enumerate(lines, 1) if pat.search(l)]


def _record_questions(product):
    """({blocked}, {annotated}) — records citing a question, split by whether it BLOCKS them.

    CITING A QUESTION IS NOT THE SAME AS BEING BLOCKED BY ONE, and the first version of this tool
    treated them as the same thing. It excused every placeholder on any record that cited any id —
    so a record citing a decision about the lab selection window had its empty `type` field excused
    too, by a question that says nothing about types.

    On prostate/202606 that was 39 records: a TODO, a citation, and `requirement: draft`. Only 20
    carry `requirement: decision_required`, which is the status that actually means "this record
    cannot be finished until the question is answered" — the same set `worksheet` and
    `decision_report` count as blocked.

    So the excuse now requires BOTH: a cited question and a requirement status that says the record
    is waiting on it. Everything else is annotated, not accounted for, and says so by name.
    """
    blocked, annotated = {}, {}
    contract = os.path.join(product, "handoff", "FUNCTIONAL_CONTRACT.md")
    if not os.path.exists(contract):
        return blocked, annotated
    for block in cl.records(contract and cl.read(contract)):
        vid = (cl._scalar(block, "variable_id") or "").strip()
        ids = (cl._list(block, "decision_ids") or []) + (cl._list(block, "gap_ids") or [])
        if not vid or not ids:
            continue
        req = (cl._kv(cl._inline(block, "status"), "requirement") or "").strip()
        (blocked if req == "decision_required" else annotated)[vid] = ids
    return blocked, annotated


def _pending_materials(root, pack):
    """material_ids whose status is `pending` — a TBD on one of those is Gate 1's own report."""
    try:
        mats = sm.materials(os.path.join(root, pack)) or []
    except Exception:                                   # noqa: BLE001 — unreadable means unaccounted
        return set()
    return {str(m.get("material_id")) for m in mats
            if str(m.get("status", "")).strip().lower() == "pending"}


def classify(pack, root=ROOT):
    """[(relative path, line, class, why)] for every placeholder in the pack's governed files.

    FAIL-CLOSED: anything this cannot positively account for is UNACCOUNTED. A placeholder wrongly
    called accounted-for is the tool telling a reader not to worry about the one thing they should.
    """
    product = os.path.join(root, pack)
    blocked, annotated = _record_questions(product)
    pending = _pending_materials(root, pack)
    out = []
    for dirpath, dirnames, filenames in os.walk(product):
        dirnames[:] = [d for d in dirnames if d not in (".git", "__pycache__")]
        for fn in sorted(filenames):
            if not fn.lower().endswith(SCANNED):
                continue
            full = os.path.join(dirpath, fn)
            rel = os.path.relpath(full, product).replace(os.sep, "/")
            for n, line in _hits(full):
                out.append((rel, n, *_class_of(rel, line, blocked, pending, annotated)))
    return out


def _class_of(rel, line, blocked, pending, annotated=None):
    """(class, why) for one placeholder occurrence."""
    annotated = annotated or {}
    stripped = line.strip()
    # Prose ABOUT placeholders — the template's own instructions, a generated scaffold. Matched on
    # the filename, not on the text, so a real placeholder in a real field is never excused by
    # sitting near an explanation of placeholders.
    if os.path.basename(rel) in PROSE:
        return BLOCKED, "generated or instructional text describing the substitutions to make"
    if stripped.startswith("#"):
        return BLOCKED, "a comment describing the field, not the field's value"

    # The environment file, from `product_gates` which takes it from the engine — the run bindings
    # moved there and this scanner kept looking only at data_product.yaml, so three REPLACE_ME lines
    # stopped being classified at all. Caught by the count assertion in test_placeholders, which is
    # exactly what a count assertion is for.
    if rel.endswith(("config/data_product.yaml", pg.ENVIRONMENT_YAML)) and RUNTIME_RE.match(line):
        return BINDING, ("supplied per run by the Databricks job or a notebook widget; "
                         "engine.validate.check RAISES while it is unfilled, so it cannot reach a build")

    if rel.endswith("source_refs.yaml"):
        if pending:
            return PENDING, (f"the material is status:pending ({', '.join(sorted(pending))}) — Gate 1 "
                             f"reports it and refuses to call the source approved")
        return UNACCOUNTED, "a placeholder in a source registration with no pending material to explain it"

    if rel.endswith("handoff/FUNCTIONAL_CONTRACT.md"):
        # A record row names its variable first; the ids it cites make the question a recorded one.
        vid = (stripped.split("|")[1].strip() if stripped.startswith("|") and "|" in stripped[1:]
               else "")
        if vid in blocked:
            return BLOCKED, f"record cites {', '.join(blocked[vid][:3])} and is decision_required"
        if vid in annotated:
            return UNACCOUNTED, (f"record cites {', '.join(annotated[vid][:2])} but its requirement "
                                 f"is not decision_required — that question does not account for "
                                 f"this field")
        return UNACCOUNTED, "a contract record with a placeholder and no decision or gap cited"

    if rel.endswith("handoff/MATURITY.yaml"):
        return BLOCKED, "the maturity note stating what is still outstanding — the file's whole purpose"

    return UNACCOUNTED, "not attributable to a runtime binding, a pending material or a cited question"


def render(packs, root=ROOT):
    L = ["", "=" * WIDTH, "  PLACEHOLDER ACCOUNTING", "=" * WIDTH,
         "  Every TODO / TBD / REPLACE_ME / XXX / PENDING in a pack's governed YAML and markdown,",
         "  and what accounts for it. Only UNACCOUNTED is a finding.", ""]
    grand = {BINDING: 0, PENDING: 0, BLOCKED: 0, UNACCOUNTED: 0}
    for pack in packs:
        rows = classify(pack, root)
        counts = {BINDING: 0, PENDING: 0, BLOCKED: 0, UNACCOUNTED: 0}
        for _r, _n, kind, _why in rows:
            counts[kind] += 1
            grand[kind] += 1
        L.append(f"  {pack}   —   {len(rows)} placeholder(s)")
        for kind in (BINDING, PENDING, BLOCKED, UNACCOUNTED):
            if counts[kind]:
                L.append(f"       {counts[kind]:4d}  {kind}")
        for rel, n, kind, why in rows:
            if kind == UNACCOUNTED:
                L.append(f"         ! {rel}:{n} — {why}")
        L.append("")
    L += ["-" * WIDTH,
          f"  {sum(grand.values())} placeholder(s) across {len(packs)} pack(s): "
          f"{grand[BINDING]} runtime binding, {grand[PENDING]} pending deliverable, "
          f"{grand[BLOCKED]} blocked and recorded, {grand[UNACCOUNTED]} UNACCOUNTED.", ""]
    if not grand[UNACCOUNTED]:
        L += ["  Nothing is unaccounted for. Every placeholder is either an environment value the",
              "  pack declines to hardcode, a deliverable a vendor has not sent, or a question that",
              "  is open and numbered.", ""]
    return "\n".join(L), grand[UNACCOUNTED]


def main(argv):
    ap = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    ap.add_argument("pack", nargs="?", help="the pack directory (repo-root-relative)")
    ap.add_argument("--all", action="store_true", help="every discovered pack")
    ap.add_argument("--check", action="store_true", help="exit 1 if anything is UNACCOUNTED")
    a = ap.parse_args(argv)
    if a.all:
        packs = sorted(pg.products(ROOT))
    elif a.pack:
        rel = os.path.relpath(os.path.abspath(a.pack), ROOT).replace(os.sep, "/")
        if not os.path.isdir(os.path.join(ROOT, rel)):
            sys.exit(f"{a.pack}: not a directory")
        packs = [rel]
    else:
        sys.exit("name a pack, or pass --all")
    text, unaccounted = render(packs)
    print(text)
    return 1 if (unaccounted and a.check) else 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
