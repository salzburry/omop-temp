#!/usr/bin/env python3
"""One page per open decision, for the person who has to answer it.

    python3 platform/tools/decision_packet.py <pack> --out packet.html
    python3 platform/tools/decision_packet.py <pack> --text        # same content, terminal

THE PROBLEM THIS EXISTS FOR. Every human act this framework requires — answer a decision, approve a
contract, mark a material reviewed — is reachable only by cloning a repository, running a CLI and
hand-editing a markdown table. That is a workable interface for whoever builds the framework and an
impossible one for the biostatistician who owns the methodology. 48 of 51 decisions are open, and
that is an ACCESS problem before it is a judgment problem: nobody has been shown the question in a
form they can answer.

So this assembles, per decision, everything a person needs to say yes or no — the question, the
evidence the register already holds, how many contract records it blocks, and what other tumours
decided when they hit the same thing — and renders it somewhere that is not a terminal.

IT COMPOSES; IT COMPUTES NOTHING. Questions, evidence, owners and statuses come from
`contract_lint` (the ONE reader of those tables, and now the ONE vocabulary for their columns);
blocked-record counts from `decision_report.blast_radius`; cross-product sightings from the advisory
question store. A packet that recounted anything would be a second implementation of whichever tool
owns that count, and would eventually show a stakeholder a number the gates disagree with.

IT WRITES NOTHING TO THE PACK, and it is NOT an approval. It renders a question. Recording the
answer is a separate act with separate evidence requirements — see WHAT THIS CANNOT DO below, which
is printed on the page itself rather than left for the reader to discover.

stdlib only (plus PyYAML, through the tools it calls).
"""
import argparse
import html
import os
import sys

TOOLS = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(os.path.dirname(TOOLS))
sys.path.insert(0, TOOLS)

import contract_lint      # noqa: E402
import decision_report    # noqa: E402
import precedents         # noqa: E402

DECISIONS = os.path.join("handoff", "DECISIONS.md")

# WHAT THE REGISTER CANNOT SUPPLY, stated on the page rather than papered over.
#
# Building this is what forced these into the open, which is the point of building it early: three
# fields a stakeholder's answer needs, that the decisions table has nowhere to put. Every other
# approval in the framework carries who + when + which bytes (APPROVAL_FIELDS,
# CONTRACT_APPROVAL_FIELDS, AI_EXTRACTION_APPROVAL_FIELDS). A methodology decision — which changes
# what the code computes — carries none of them, and its answer column is literally called
# "Approved answer".
#
# The packet does NOT invent them. It names them as missing, because a page that quietly offered a
# signature box the register cannot store would be collecting attestations into a void.
UNRECORDABLE = (
    ("who approved it", "the register has no `approved_by`; `Owner` names a team, not a person"),
    ("when", "the register has no `approval_date`"),
    ("what exactly was approved", "no hash binds the answer text, so an edit leaves no trace"),
)


def _blocks(pack, root):
    """{decision id: [blocked variable ids]} — from the tool that owns it."""
    blocking, _table, _idle, _status = decision_report.blast_radius(os.path.join(root, pack))
    return blocking


def _elsewhere(pack, root):
    """{decision id: [(other pack, other decision, status, answer)]} from the advisory store.

    Keyed off the store's own `seen_in` pairs, not by matching question text: two registers phrase
    one question differently on purpose, and a matcher good enough to pair them is good enough to
    pair two that merely sound alike.
    """
    entries, _bad = precedents.load(root)
    out = {}
    for entry in entries:
        seen = entry.get("seen_in") or []
        mine = [s for s in seen if s.get("pack") == pack]
        if not mine:
            continue
        for s in mine:
            for other in seen:
                if other.get("pack") == pack:
                    continue
                opack, odid = other.get("pack"), other.get("decision")
                path = os.path.join(root, opack or "", DECISIONS)
                if not os.path.exists(path):
                    continue
                text = contract_lint.read(path)
                rows, status = contract_lint.decision_rows(text), contract_lint.decision_status(text)
                if odid not in rows:
                    continue
                out.setdefault(s.get("decision"), []).append(
                    (opack, odid, status.get(odid, ""),
                     contract_lint.decision_answer(rows[odid]) or ""))
    return out


def packet(pack, root=ROOT):
    """(decisions, note) — every OPEN decision, ranked by how many records it blocks.

    `note` is not None when nothing could be assembled, and it is a REFUSAL rather than an empty
    list: "no open decisions" and "this pack keeps no register" are opposite answers, and a page
    that renders the second as the first tells a stakeholder there is nothing to do.
    """
    path = os.path.join(root, pack, DECISIONS)
    if not os.path.exists(path):
        return [], f"{pack} keeps no handoff/DECISIONS.md — there is no register to read, so nothing was assembled."

    text = contract_lint.read(path)
    rows = contract_lint.decision_rows(text)
    status = contract_lint.decision_status(text)
    if not rows:
        return [], f"{pack}'s decisions register holds no readable rows — nothing was assembled."

    blocks, elsewhere = _blocks(pack, root), _elsewhere(pack, root)
    out = []
    for did, row in rows.items():
        if str(status.get(did, "OPEN")).strip().upper() != "OPEN":
            continue
        out.append({
            "id": did,
            "question": (contract_lint.decision_question(row) or "").strip(),
            "evidence": (contract_lint.decision_evidence(row) or "").strip(),
            "owner": (contract_lint.decision_owner(row) or "").strip(),
            "blocks": sorted(blocks.get(did, [])),
            "elsewhere": elsewhere.get(did, []),
        })
    out.sort(key=lambda d: (-len(d["blocks"]), d["id"]))
    return out, None


# --------------------------------------------------------------------------- rendering
def _h(s):
    return html.escape(str(s or ""))


def render_html(pack, root=ROOT):
    items, note = packet(pack, root)
    head = [
        "<!doctype html><meta charset='utf-8'>",
        f"<title>Decisions to answer — {_h(pack)}</title>",
        "<style>",
        "body{font:16px/1.55 system-ui,-apple-system,Segoe UI,Roboto,sans-serif;color:#16191c;",
        "background:#f4f5f6;margin:0;padding:32px 20px;}",
        ".w{max-width:820px;margin:0 auto;}",
        "h1{font:600 26px/1.2 Georgia,serif;margin:0 0 6px;}",
        ".sub{color:#5a6169;margin:0 0 26px;}",
        ".d{background:#fff;border:1px solid #d3d7db;border-radius:3px;margin:0 0 22px;",
        "padding:22px 24px;}",
        ".id{font:11px/1 ui-monospace,Menlo,monospace;letter-spacing:.1em;color:#7a838c;}",
        ".q{font:600 19px/1.35 Georgia,serif;margin:8px 0 14px;}",
        "h4{font:11px/1 ui-monospace,Menlo,monospace;letter-spacing:.1em;text-transform:uppercase;",
        "color:#7a838c;margin:18px 0 7px;}",
        ".ev{color:#3d444b;}",
        ".blocks{font:13px/1.6 ui-monospace,Menlo,monospace;color:#3d444b;overflow-wrap:anywhere;}",
        ".n{display:inline-block;background:#fbeceb;color:#b4231a;border:1px solid #b4231a;",
        "border-radius:2px;padding:3px 9px;font:11px/1 ui-monospace,monospace;letter-spacing:.08em;}",
        ".other{border-left:3px solid #d3d7db;padding:2px 0 2px 14px;margin:9px 0;color:#3d444b;}",
        ".other .p{font:11px/1.5 ui-monospace,Menlo,monospace;color:#7a838c;}",
        ".ans{margin-top:26px;border-top:1px dashed #c8ccd0;padding-top:16px;}",
        ".ans .line{border-bottom:1px solid #c8ccd0;height:26px;margin:9px 0;}",
        ".warn{background:#fff8e6;border:1px solid #e0cd8f;border-left:4px solid #b98900;",
        "padding:16px 20px;margin:0 0 26px;color:#4a3c11;}",
        ".warn b{color:#7a6224;}",
        "footer{color:#7a838c;font-size:13px;margin-top:30px;}",
        "@media print{body{background:#fff;padding:0;}.d{break-inside:avoid;}}",
        "</style>", "<div class='w'>",
    ]
    if note:
        return "\n".join(head + [f"<h1>Nothing to answer</h1><p class='sub'>{_h(note)}</p>",
                                 "</div>"])

    L = head + [
        f"<h1>Decisions to answer — {_h(pack)}</h1>",
        f"<p class='sub'>{len(items)} open question(s), ordered by how much each one unblocks. "
        "You are being asked to decide, not to edit anything.</p>",
        "<div class='warn'><b>Before you answer.</b> This page can show you the question and the "
        "evidence. It cannot yet record your answer with your name against it — the decisions "
        "register has nowhere to put " +
        _h(", ".join(w for w, _why in UNRECORDABLE)) +
        ". Send your answer back and it will be recorded by hand until that is fixed.</div>",
    ]
    for d in items:
        L.append("<div class='d'>")
        L.append(f"<div class='id'>{_h(d['id'])}"
                 + (f" &nbsp;·&nbsp; owner: {_h(d['owner'])}" if d["owner"] else "") + "</div>")
        L.append(f"<div class='q'>{_h(d['question'])}</div>")
        if d["evidence"]:
            L.append("<h4>What the specification says</h4>")
            L.append(f"<div class='ev'>{_h(d['evidence'])}</div>")
        L.append("<h4>What this blocks</h4>")
        if d["blocks"]:
            L.append(f"<p><span class='n'>{len(d['blocks'])} variable(s)</span></p>")
            L.append(f"<div class='blocks'>{_h(', '.join(d['blocks']))}</div>")
        else:
            L.append("<p class='ev'>No contract record is waiting on this one today. It is open, "
                     "and not on the critical path.</p>")
        if d["elsewhere"]:
            L.append("<h4>What other products decided</h4>")
            for opack, odid, ostatus, oans in d["elsewhere"]:
                L.append("<div class='other'>")
                L.append(f"<div class='p'>{_h(opack)} · {_h(odid)} · {_h(ostatus or 'OPEN')}</div>")
                L.append(f"<div>{_h(oans) if oans.strip() else '<em>still open there too</em>'}</div>"
                         if oans.strip() else "<div><em>still open there too</em></div>")
                L.append("</div>")
        L.append("<div class='ans'><h4>Your answer</h4>"
                 "<div class='line'></div><div class='line'></div>"
                 "<h4>Name and date</h4><div class='line'></div></div>")
        L.append("</div>")
    L.append("<footer>Generated from the pack's own registers. Nothing here is an approval, and "
             "nothing was written to the pack.</footer></div>")
    return "\n".join(L)


def render_text(pack, root=ROOT):
    items, note = packet(pack, root)
    if note:
        return f"\n{note}\n"
    W = 92
    L = ["", "=" * W, f"  DECISIONS TO ANSWER — {pack}", "=" * W,
         f"  {len(items)} open question(s), ordered by how much each unblocks.", ""]
    for d in items:
        L += ["-" * W, f"  {d['id']}" + (f"   (owner: {d['owner']})" if d["owner"] else ""), "-" * W]
        L += _wrap(d["question"], 2)
        if d["evidence"]:
            L += ["", "   WHAT THE SPECIFICATION SAYS"] + _wrap(d["evidence"], 5)
        L += ["", f"   BLOCKS {len(d['blocks'])} variable(s)"]
        if d["blocks"]:
            L += _wrap(", ".join(d["blocks"]), 5)
        for opack, odid, ostatus, oans in d["elsewhere"]:
            L += ["", f"   ELSEWHERE  {opack} · {odid} · {ostatus or 'OPEN'}"]
            L += _wrap(oans or "still open there too", 5)
        L.append("")
    L += ["=" * W,
          "  This page shows the question. It cannot record your answer with your name against",
          "  it — the register has nowhere to put:"]
    for what, why in UNRECORDABLE:
        L.append(f"     · {what} — {why}")
    L.append("")
    return "\n".join(L)


def _wrap(text, indent):
    import textwrap
    body = " ".join(str(text or "").split())
    if not body:
        return []
    return textwrap.wrap(body, width=92 - indent,
                         initial_indent=" " * indent, subsequent_indent=" " * indent)


def main(argv):
    ap = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    ap.add_argument("pack", help="the pack directory (repo-root-relative)")
    ap.add_argument("--out", help="write the HTML page here")
    ap.add_argument("--text", action="store_true", help="print the same content as text instead")
    a = ap.parse_args(argv)

    pack = os.path.relpath(os.path.abspath(a.pack), ROOT).replace(os.sep, "/")
    if not os.path.isdir(os.path.join(ROOT, pack)):
        sys.exit(f"{a.pack}: not a directory")
    if a.text or not a.out:
        print(render_text(pack))
        if not a.out:
            return 0
    with open(a.out, "w", encoding="utf-8") as fh:
        fh.write(render_html(pack))
    print(f"wrote {a.out}")
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
