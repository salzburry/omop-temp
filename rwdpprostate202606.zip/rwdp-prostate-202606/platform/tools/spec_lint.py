#!/usr/bin/env python3
"""Deterministic defect scan over an extracted RWB program specification.

Most specification defects are pattern-matchable, and a script finds them better than a careful reader
does: it checks all rows every time, identically. This scans the output of spec_extract.py and reports
what a human then has to judge.

It reports; it never edits, and it never decides. A finding here becomes a SPEC_QC_FINDINGS entry (a
defect in RWB's document) or a DECISIONS entry (a question only RWB can answer) — that classification
is a human call.

Checks, and the real prostate/ovarian defects each was written for:

  IMPOSSIBLE_DATE    "4/31/2026" — April has 30 days (prostate MAXINDEX, SQ-01)
  PLACEHOLDER        "[Overall mHSPC cohort]" where a formula belongs (SQ-05)
  TRUNCATED          "(cut off at right edge of photo)" / "(fragment...)" (SQ-T1..T3)
  FOREIGN_TABLE      a table stem belonging to another tumour (SQ-03, t_enh_metcrc_oral in prostate)
  UNBALANCED         unmatched quote or bracket in a rule string (SQ-06 note)
  NO_TERMINAL_ELSE   an if/else-if chain with no final else — undefined for unmatched input
  VALUE_COUNT        more values declared than the rule ever assigns (SQ-06, 4 declared / 2 assigned)
  VERIFY_MARKER      an explicit "[verify]" / "confirm" the spec author left behind
  OUTLIER_IN_LIST    a token whose SHAPE breaks its neighbours' pattern — e.g. the word
                     "Implementation" sitting inside a list of two-letter state codes, which is what an
                     unanchored find/replace of the owner code "DE" produced in a real workbook. The
                     value stays plausible-looking prose, so review misses it; the shape does not.

    python3 platform/tools/spec_lint.py <extracted.json> [--tumor prostate] [--format text|json]

stdlib only.
"""
import argparse
import calendar
import json
import os
import re
import sys

from product_gates import read_yaml
from spec_extract import repo_root, requirement_rows

# Which stems name which tumour, and what a table reference looks like — GOVERNED DATA, not code.
# `governance/tumour_registry.yaml` owns both; this module reads them. They were Python constants
# here, which made onboarding a product a change to shared code AND failed quietly: an unlisted
# tumour did not error, `tumor_family()` returned None, and the pack passed a scan it was never
# subject to. Adding a product must not require editing anything under `platform/`.
TUMOUR_REGISTRY = os.path.join("governance", "tumour_registry.yaml")
_REGISTRY = None


def tumour_registry():
    """`{"families": {...}, "aliases": {...}, "prefixes": [...]}` from the governed file. Cached.

    FAIL-CLOSED on a missing or malformed registry. An empty families map would make every table
    reference unrecognisable and FOREIGN_TABLE would report itself inapplicable on every pack at once
    — the check silently switching itself off, repo-wide, because a file went missing. That is the
    same fail-open shape as an empty AI-boundary marker list, and the same answer applies.
    """
    global _REGISTRY
    if _REGISTRY is None:
        # From THIS FILE, not the CWD: `spec_lint` runs from the repo root in CI and from `platform/`
        # in the suites, and a CWD-relative lookup would find the registry in one and not the other.
        path = os.path.join(repo_root(__file__), TUMOUR_REGISTRY)
        doc, err = read_yaml(path)
        if err or not doc:
            sys.exit(f"{TUMOUR_REGISTRY}: {err or 'is empty'} — FOREIGN_TABLE cannot tell one "
                     f"tumour's tables from another's without it, and a check that cannot run must "
                     f"not report itself clean.")
        fams = {str(k).strip().lower(): [str(x).strip().lower() for x in (v or [])]
                for k, v in (doc.get("families") or {}).items()}
        prefixes = [str(e.get("prefix", "")).strip() for e in (doc.get("table_prefixes") or [])
                    if str(e.get("prefix", "")).strip()]
        if not fams or not prefixes:
            sys.exit(f"{TUMOUR_REGISTRY}: declares "
                     f"{'no families' if not fams else 'no table_prefixes'} — see the file's own "
                     f"header for what each is for.")
        _REGISTRY = {"families": fams, "prefixes": prefixes,
                     "aliases": {str(k).strip().lower(): str(v).strip().lower()
                                 for k, v in (doc.get("aliases") or {}).items()}}
    return _REGISTRY


def _names_family(table, stems):
    """Does this table reference name a family with one of `stems`? Matched at TOKEN BOUNDARIES.

    Plain substring matching made one tumour's stem match another's table whenever one name contained
    the other: `sclc` is inside `nsclc`, so `t_nsclc_biomarkers` matched SCLC's own stem and an NSCLC
    table sitting in an SCLC spec was never flagged — silently, one-directionally, on the likeliest
    confusion pair in a lung portfolio.

    The first fix was to spell the stem `_sclc` in the registry. That worked and was the wrong place:
    it encoded MATCHER knowledge — that references are prefix-anchored so a separator always precedes
    the stem — into DATA, so every future author adding a tumour whose name contains another's would
    have to rediscover the trick, and would more likely just not notice. Onboarding a product is meant
    to be a data edit; the data should be the obvious spelling.

    A stem matches a token PREFIX rather than a whole token, so `ovarian` still finds
    `t_enh_ovariancancer` — a real convention — while `sclc` cannot reach into `nsclc`.
    """
    return any(tok.startswith(s) for tok in re.split(r"[^a-z0-9]+", table.lower()) if tok
               for s in stems)


def tumor_family(tumor):
    """The registry family for a slug, or None if the check cannot apply to it."""
    if not tumor:
        return None
    reg = tumour_registry()
    t = tumor.strip().lower()
    t = reg["aliases"].get(t, t)
    return t if t in reg["families"] else None


# Severity, because a flat list buries the findings that matter. On the ovarian workbook the single
# corrupted state code sat among 318 routine annotations; ranked, it comes first.
#   HIGH  the spec is WRONG or unusable as written — someone must fix or decide
#   INFO  the spec is annotated or incomplete BY DESIGN — context for the reader, not a defect
SEVERITY = {
    "IMPOSSIBLE_DATE": "HIGH", "FOREIGN_TABLE": "HIGH", "OUTLIER_IN_LIST": "HIGH",
    "TRUNCATED": "HIGH", "UNBALANCED": "HIGH",
    "PLACEHOLDER": "INFO", "NO_TERMINAL_ELSE": "INFO", "VALUE_COUNT": "INFO",
    # NOT one of the UNSETTLED four, on purpose. Those mean "the specification does not contain the
    # answer"; this means "the specification DOES contain it and this artifact may not carry it,
    # because the cell reproduced vendor documentation". Folding the two together would make I17
    # demand a decision for a requirement RWB has fully specified — which is the over-refusal the
    # skill spends a section warning against — and would bury the rows that genuinely need RWB.
    "VENDOR_REDACTED": "INFO",
    "VERIFY_MARKER": "INFO",
}

DATE_RE = re.compile(r"\b(\d{1,2})[/-](\d{1,2})[/-](\d{2,4})\b")
PLACEHOLDER_RE = re.compile(r"\[[A-Za-z][^\]\n]{6,}\]")          # [Overall mHSPC cohort]; not [MIN, MAX]
TRUNC_RE = re.compile(r"\(([^)]*(?:cut off|fragment|truncat|clipped)[^)]*)\)", re.I)
VERIFY_RE = re.compile(r"\[verify\]|\bconfirm which\b|\bmay be column-swapped\b", re.I)
def table_re():
    """The table-reference pattern, built from the registry's declared vendor prefixes.

    Prefix-anchored on purpose — see the registry's own warning on `table_prefixes`. Compiled per
    call rather than at import: a module-level regex would freeze whichever registry happened to be
    on disk when the module first loaded, which is exactly the staleness this move was to remove.
    """
    alt = "|".join(re.escape(p) for p in tumour_registry()["prefixes"])
    return re.compile(rf"\b(?:{alt})[a-z0-9_&]+\b", re.I)
ASSIGN_RE = re.compile(r"then\s*=?\s*'([^']+)'|then\s+\w+\s*=\s*'([^']+)'", re.I)
VALUES_RE = re.compile(r"'([^']{2,40})'")


def _impossible_dates(text):
    out = []
    for m in DATE_RE.finditer(text):
        a, b, c = (int(x) for x in m.groups())
        # try both m/d and d/m; a literal is impossible only if NEITHER reading is a real date
        ok = False
        for mm, dd in ((a, b), (b, a)):
            yr = c if c > 99 else 2000 + c
            if 1 <= mm <= 12 and 1 <= dd <= calendar.monthrange(yr, mm)[1]:
                ok = True
        if not ok:
            out.append(m.group(0))
    return out


def _unbalanced(text):
    """Unbalanced quoting inside a RULE. Prose cells break parenthesis balance constantly (and the
    stand-in's own "(cut off...)" annotations add more), so checking prose produces noise that
    buries the real findings. Only an if/then rule with an odd quote count is reported — that is the
    case where a literal comparison silently matches nothing."""
    if not re.search(r"\b(if|then)\b", text, re.I):
        return []
    stripped = re.sub(r"\*?\([^)]*(?:cut off|fragment|truncat|clipped)[^)]*\)\*?", "", text, flags=re.I)
    return ["odd number of single quotes in a rule"] if stripped.count("'") % 2 else []


def _outliers(text):
    """Tokens in a quoted list whose shape breaks the list's dominant pattern.

    A find/replace that hits a data value leaves something that reads as ordinary text and passes every
    other check. What it cannot hide is that it no longer looks like its neighbours: one long word among
    sixteen two-letter codes. Only lists with a clear majority shape are judged, so genuine mixed lists
    are left alone.
    """
    out = []
    groups = []
    # quoted list:      in ('ME' 'VT' 'NH' ...)
    for grp in re.findall(r"\(((?:\s*'[^']+'\s*,?){4,})\)", text):
        groups.append(re.findall(r"'([^']+)'", grp))
    # unquoted list:    South=TX OK AR LA KY TN MS AL MD DE DC VA WV NC SC GA FL
    # This form is common in specs and is where a find/replace corruption actually landed, so it must
    # be covered too — the quoted-only version silently passed the real defect.
    for grp in re.findall(r"=\s*((?:[A-Za-z][A-Za-z]{1,20}[ \t]+){4,}[A-Za-z]{2,20})", text):
        toks = grp.split()
        if sum(1 for x in toks if len(x) == 2) >= 4:
            groups.append(toks)
    for toks in groups:
        if len(toks) < 4:
            continue
        lens = [len(x) for x in toks]
        common = max(set(lens), key=lens.count)
        if lens.count(common) < 0.7 * len(toks) or common > 4:
            continue                                   # no dominant short-code shape; not judgeable
        for tok in toks:
            if len(tok) != common and (len(tok) > common + 2 or not tok.isupper()):
                out.append(f"'{tok}' breaks the pattern of a {common}-character list "
                           f"({lens.count(common)}/{len(toks)} tokens are {common} chars)")
    return out


def _exhaustive_numeric_else(text):
    """True when an if/else-if chain's NUMERIC branches tile the whole real line and it ends in a
    missing/null branch — so the lack of a bare `else` leaves no input undefined and NO_TERMINAL_ELSE
    would be a false positive (e.g. the BMI-band rule `<18.5 / [18.5,25) / [25,30) / >=30 / missing`).

    CONSERVATIVE by construction: it returns False (keep flagging) unless it can PROVE the tiling, so a
    real gap stays flagged. The proof:

      * there is a terminal missing/null branch (the `else`-substitute for absent values);
      * every numeric threshold appears BOTH as an upper cut (an interval bounded above by it) and as a
        lower cut (an interval bounded below by it) — `uppers == lowers`. A gap or an overlap breaks
        that equality, and a CATEGORICAL chain (`X=1 / X=2 / missing`, which leaves `X=3` undefined)
        has no numeric comparisons at all, so both fail here and stay flagged;
      * at each shared threshold the boundary value itself is covered — not `<` on one side AND `>` on
        the other, which would leave the exact value in a gap.

    A stray comparison elsewhere in the cell text adds an unpaired threshold, which breaks `uppers ==
    lowers` and makes it flag — the safe direction.
    """
    # Strip HTML tags FIRST: cells use `<br>` for line breaks, and `<br>2=` reads as the comparison
    # `> 2`, which poisons the tiling. `<\/?[a-z]…>` only matches a tag (a letter right after `<`), so
    # a real `BMI < 18.5` — where a space or digit follows `<` — is left intact.
    text = re.sub(r"<\/?[a-zA-Z][^>]*>", " ", text)
    if not re.search(r"\b(?:is\s+)?(?:missing|null)\b", text, re.I):
        return False
    cuts = {}                                       # value -> {'upper': strict?, 'lower': strict?}

    def add(side, strict, val):
        d = cuts.setdefault(val, {})
        d[side] = strict if side not in d else (d[side] and strict)   # any inclusive branch covers it

    for op, num in re.findall(r"(<=|>=|<|>)\s*(-?\d+(?:\.\d+)?)", text):     # VAR op NUM
        add("upper" if op in ("<", "<=") else "lower", op in ("<", ">"), float(num))
    for num, op in re.findall(r"(-?\d+(?:\.\d+)?)\s*(<=|>=|<|>)", text):     # NUM op VAR
        add("lower" if op in ("<", "<=") else "upper", op in ("<", ">"), float(num))

    uppers = {v for v, d in cuts.items() if "upper" in d}
    lowers = {v for v, d in cuts.items() if "lower" in d}
    if not uppers or uppers != lowers:              # open at both ends, every cut paired; else a gap
        return False
    return all(not (d.get("upper", True) and d.get("lower", True)) for d in cuts.values())


def scan_row(row, tumor=None):
    text = row["text"]
    f = []
    for d in _impossible_dates(text):
        f.append(("IMPOSSIBLE_DATE", f"'{d}' is not a real calendar date"))
    if "VENDOR DOCUMENTATION REDACTED" in text:
        f.append(("VENDOR_REDACTED", "a cell reproduced vendor documentation and was removed from "
                                     "this artifact — an AUTHORIZED HUMAN must review the restricted "
                                     "reference material; contract_record.py refuses this item"))
    for p in PLACEHOLDER_RE.findall(text):
        if not re.match(r"\[[A-Z_]+(,\s*[A-Z_]+)*\]$", p):        # skip [MININDEX, MAXINDEX]
            f.append(("PLACEHOLDER", f"{p} — prose in place of a rule"))
    for t in TRUNC_RE.findall(text):
        f.append(("TRUNCATED", t.strip()))
    for v in set(VERIFY_RE.findall(text) or []):
        f.append(("VERIFY_MARKER", "spec author left an explicit confirm/verify marker"))
    if VERIFY_RE.search(text) and not VERIFY_RE.findall(text):
        f.append(("VERIFY_MARKER", "spec author left an explicit confirm/verify marker"))
    family = tumor_family(tumor)
    if family:
        fams = tumour_registry()["families"]
        own = fams[family]
        for tbl in table_re().findall(text):
            for fam, stems in fams.items():
                if fam == family:
                    continue
                if _names_family(tbl, stems) and not _names_family(tbl, own):
                    f.append(("FOREIGN_TABLE", f"{tbl} looks like a {fam} table inside a {tumor} spec"))
                    break
    for b in _unbalanced(text):
        f.append(("UNBALANCED", b))
    for o in _outliers(text):
        f.append(("OUTLIER_IN_LIST", o))
    if re.search(r"else\s+if", text, re.I):
        tail = text[text.lower().rfind("else if"):]
        if not re.search(r"\belse\b(?!\s*if)", tail, re.I) and not _exhaustive_numeric_else(text):
            f.append(("NO_TERMINAL_ELSE", "if/else-if chain with no final else — unmatched input undefined"))
    declared = {v.strip() for v in VALUES_RE.findall(row["cells"][2] if len(row["cells"]) > 2 else "")}
    # A long list of short codes is an ENUMERATION being mapped (e.g. 51 state codes), not a declared
    # value set whose members should each be assigned. Only label-shaped, small sets are checked.
    declared = {v for v in declared if len(v) > 3 and " " in v or len(v) > 8}
    assigned = {(a or b).strip() for a, b in ASSIGN_RE.findall(text)}
    if declared and assigned and 1 < len(declared) <= 12 and len(declared) > len(assigned) + 1:
        never = sorted(declared - assigned)[:4]
        f.append(("VALUE_COUNT", f"{len(declared)} values declared, {len(assigned)} ever assigned; "
                                 f"never assigned e.g. {never}"))
    return f


def inapplicable_checks(rows, tumor):
    """Checks that ran but could not have fired. A check silently finding nothing and a check that never
    applied look identical in a report of zero findings — which is how a spec passes a scan it was never
    actually subject to."""
    notes = []
    if not tumor:
        notes.append("FOREIGN_TABLE did not apply: no --tumor given")
    elif not tumor_family(tumor):
        notes.append(f"FOREIGN_TABLE did not apply: '{tumor}' resolves to no tumour family "
                     f"(known: {', '.join(sorted(tumour_registry()['families']))}). Add it to "
                     f"{TUMOUR_REGISTRY} — a governed data edit, not a code change.")
    elif not any(table_re().search(r["text"]) for r in rows):
        notes.append("FOREIGN_TABLE found no table-shaped references at all — this spec either names no "
                     "source tables, or uses a prefix TABLE_RE does not know")
    return notes


def scan(data, tumor=None, tabs=None):
    """Scan the requirement-bearing rows — by default, every row that carries a DOMAIN.

    A real workbook carries far more than the specification: cover sheets, change logs, review-decision
    trackers, approval gates, backlogs. Those legitimately say "confirm" and "[TBD]" everywhere, so
    scanning them buries the genuine defects — on the ovarian workbook it turned 30-odd real findings
    into 392. A sheet listed in governance/spec_sheet_map.yaml is requirement-bearing by that fact, so
    the filter needs no per-product tab list; `tabs` remains as an explicit override.
    """
    findings = []
    for row in requirement_rows(data, tabs):
        for kind, detail in scan_row(row, tumor):
            findings.append({"item_id": row["item_id"], "tab": row["tab"], "row": row["row"],
                             "variable": row["variable"][:40], "kind": kind, "detail": detail,
                             "severity": SEVERITY.get(kind, "INFO")})
    return findings + scan_structure(data, tabs)


# What the workbook's own structure hides. These are not defects in what the spec SAYS — they are
# reasons a cell can be blank, or present, for a reason the text does not show. Left unreported, a
# formula with no cached result and a genuinely empty derivation are the same thing to every reader.
STRUCTURE_FINDINGS = {
    "formula_no_value": ("HIGH", "formula cell(s) with no cached result — these read as BLANK, so any "
                                 "rule behind them is silently missing: {}"),
    "merged":           ("HIGH", "merged range(s) on a requirement sheet — a merge keeps the anchor "
                                 "cell and blanks the rest, so one reaching across a named column "
                                 "deletes that column for those rows: {}"),
    "hidden_rows":      ("HIGH", "hidden row(s), extracted as ordinary requirements — usually retired "
                                 "content, and invisible to whoever reviewed the workbook: {}"),
    "validation_lists": ("INFO", "dropdown(s) whose allowed values live in the validation, not in any "
                                 "cell, so the enumeration is not extracted: {}"),
    "comments":         ("INFO", "cell comment(s), which are not read — RWB caveats often live here: {}"),
    "shadowing_cols":   ("HIGH", "HIDDEN column(s) whose header names a field the resolver reads. The "
                                 "first matching column wins, so the rule comes from a column nobody "
                                 "can see in Excel: {}"),
}


def scan_structure(data, tabs=None):
    """Findings from `workbook_structure`, limited to the requirement-bearing sheets."""
    structure = (data.get("extraction") or {}).get("workbook_structure") or {}
    if not structure:
        return []                                   # per-tab path, or an older extraction
    scanned = {r["tab"] for r in requirement_rows(data, tabs)}
    out = []
    for tab in sorted(structure):
        if tab not in scanned:
            continue                                # a cover sheet's merges are nobody's problem
        for key, detail in sorted(structure[tab].items()):
            if key not in STRUCTURE_FINDINGS:
                continue
            severity, template = STRUCTURE_FINDINGS[key]
            shown = ", ".join(str(d) for d in detail[:8]) + ("…" if len(detail) > 8 else "")
            out.append({"item_id": f"{tab}:(sheet)", "tab": tab, "row": 0, "variable": "(sheet)",
                        "kind": "WORKBOOK_STRUCTURE", "severity": severity,
                        "detail": template.format(shown)})
    return out


def main(argv):
    ap = argparse.ArgumentParser(description="Deterministic defect scan over an extracted spec.")
    ap.add_argument("extracted", help="JSON from spec_extract.py")
    ap.add_argument("--tumor", help="tumour family, enables the foreign-table check (e.g. prostate)")
    ap.add_argument("--format", choices=("text", "json"), default="text")
    ap.add_argument("--tabs", help="OVERRIDE the tabs to scan; normally omitted — the default is every "
                                   "sheet mapped in governance/spec_sheet_map.yaml")
    a = ap.parse_args(argv)

    with open(a.extracted, encoding="utf-8") as fh:
        data = json.load(fh)
    findings = scan(data, a.tumor, a.tabs.split(",") if a.tabs else None)

    notes = inapplicable_checks(requirement_rows(data, a.tabs.split(",") if a.tabs else None), a.tumor)
    if a.format == "json":
        # An object, not a bare list: a consumer reading only `findings: []` cannot tell "clean" from
        # "never looked". `applicability` is what makes zero findings mean something.
        # `fingerprint` is copied from the extraction, never recomputed here: one definition, in the
        # tool that owns extraction identity. A consumer compares this to extracted.json's own value
        # and knows whether the two files describe the same run — which comparing item ids cannot
        # tell it, because an in-place spec edit leaves every id exactly where it was.
        print(json.dumps({"fingerprint": (data.get("extraction") or {}).get("fingerprint", ""),
                          "findings": findings,
                          "applicability": {"foreign_table": "not_applicable" if notes else "applied",
                                            "reasons": notes}}, indent=1))
        return 0

    hi = sum(1 for f in findings if f["severity"] == "HIGH")
    print(f"   HIGH {hi}   INFO {len(findings) - hi}\n")
    by = {}
    for f in findings:
        by.setdefault((f["severity"], f["kind"]), []).append(f)
    rows = requirement_rows(data, a.tabs.split(",") if a.tabs else None)
    total = data["extraction"]["row_count"]
    print(f"scanned {len(rows)} of {total} rows"
          f"{' (requirement sheets only)' if len(rows) != total else ''} — {len(findings)} finding(s)\n")
    for note in notes:
        print(f"   NOTE  {note}")
    if notes:
        print()
    for key in sorted(by, key=lambda k: (k[0] != "HIGH", -len(by[k]))):
        sev, kind = key
        print(f"[{sev}] {kind}  ({len(by[key])})")
        for f in by[key][:12]:
            print(f"   {f['item_id']:<22} {f['variable']:<24} {f['detail'][:80]}")
        if len(by[key]) > 12:
            print(f"   ... +{len(by[key]) - 12} more")
        print()
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
