#!/usr/bin/env python3
"""One pack's config-authoring worklist, in the order the work actually comes.

    python3 platform/tools/worksheet.py <pack>
    python3 platform/tools/worksheet.py <pack> --values   # include the candidate YAML in full

A contract exists and `config/` is blank: what now? Three tools already answer parts of that —
`decision_report` ranks the open questions by how many records each unblocks, `contract_binding
--promote` lifts the value lists the spec states, and `finalize` counts what the pack holds — but
they are three commands whose output has to be read together and in the right ORDER to be a plan.
This is that order, and nothing else.

IT COMPOSES; IT COMPUTES NOTHING. Every number and every line below comes from the tool that owns
it — `finalize.facts`, `decision_report.blast_radius`, `contract_binding.check` / `.promote`. This
file owns the sequence and the framing and not one governed fact, for the same reason `demo.py`
does: a worklist that recounted anything would be a second implementation of whichever tool owns
that count, and would eventually tell an analyst there was less to do than there is.

THE ORDER IS THE POINT. Decisions first, because one answer can unblock nineteen records and doing
them in file order is close to the worst possible sequence. Then the values the spec already
states, which are mechanical and want no judgment. Then the config blocks nothing has claimed.
Answering the top decision first is worth more than any amount of tooling below it.

READ-ONLY. Nothing here writes to the pack, and nothing proposes a source mapping, a numeric code
or a fallthrough — those are refused by `promote` itself, by design, and this changes none of it.

stdlib only (plus PyYAML, through the tools it calls).
"""
import argparse
import os
import sys

TOOLS = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(os.path.dirname(TOOLS))
sys.path.insert(0, TOOLS)

import contract_binding  # noqa: E402
import decision_report   # noqa: E402
import finalize          # noqa: E402
from contract_lint import cell  # noqa: E402
from product_gates import pack_yaml  # noqa: E402

WIDTH = 94
TOP_DECISIONS = 8  # the rest are listed by id; a worklist nobody finishes reading is not a worklist

# THE PHRASE EVERY EMPTY SECTION MUST CARRY WHEN IT HAD NOTHING TO EXAMINE.
#
# An empty list means one of two opposite things — "we looked and found nothing wrong" or "there was
# nothing to look at" — and printing the same line for both is the failure this codebase keeps
# producing in new costumes. Gate 5 scored an absent test suite as PASS. An unstarted config was
# reported as having drifted. A pack with no contract got a worklist of truthful zeroes. An undrafted
# specification made a pack look nearly finished. And section 3 here told prostate/202607 that
# "every governed block is claimed by a record" when the count was 0 of 0, because that pack has no
# config/ at all — a heading an analyst reads as "nothing left to do".
#
# Every branch that is empty because the DENOMINATOR was zero uses this constant, and
# test_worksheet asserts that rule holds for every section on every pack. The per-instance fixes
# were not stopping the pattern; this is the part that generalises.
NOTHING_TO_CHECK = "nothing to check, not nothing wrong"


def rule(ch="-"):
    return ch * WIDTH


def _contract(pack):
    return os.path.join(ROOT, pack, "handoff", "FUNCTIONAL_CONTRACT.md")


def not_started(pack):
    """The message for a pack with no contract yet, or None.

    Ordering the config work presumes something to order it BY. Without a contract there are no
    records to unblock, no spec rows bound to config blocks, and no register to rank — every count
    below would be a truthful zero that reads as "nothing to do".
    """
    if os.path.exists(_contract(pack)):
        return None
    return "\n".join([
        f"{pack} has no handoff/FUNCTIONAL_CONTRACT.md, so there is no config work to order yet.",
        "",
        "  A worklist here would be all zeroes, and zeroes read as 'nothing to do' rather than",
        "  'nothing to read'. The contract is what says which config blocks must exist at all.",
        "",
        "  Start with Gate 1 and the spec pipeline:",
        "      python3 platform/tools/source_manifest.py <pack> --check",
        f"      python3 platform/tools/run_spec_pipeline.py {pack}",
        "  then draft records from spec_pipeline/out/SCAFFOLDED_RECORDS.md. See",
        "  platform/TUMOR_TEMPLATE/NEW_TUMOUR.md, and `precedents.py --for <pack>` for the",
        "  questions other products have already had to answer.",
    ])


def model(pack):
    """The worksheet's DERIVED state, with no formatting on it — or None for a pack with no contract.

    Split out so a second rendering (`render_html.py`) can present the same worklist without
    re-deriving it. The sequence IS this tool's value: decisions first because one answer unblocks
    nineteen records, then the lists that need no judgment, then the reverse direction. A renderer
    that re-derived that ordering would be a second implementation of the only thing here worth
    having, free to disagree about which decision matters most — and both would look correct.

    Still computes nothing of its own: every number comes from the tool that owns it
    (`finalize.facts`, `contract_binding.check`/`.promote`, `decision_report.blast_radius`).
    """
    if not_started(pack):
        return None
    product = os.path.join(ROOT, pack)
    f = finalize.facts(product)
    cover = pack_yaml(product)
    errors, s = contract_binding.check(product, cover)
    blocking, table, idle, _status = decision_report.blast_radius(product)
    proposals = contract_binding.promote(product, contract_binding.governed_blocks(product, cover))
    # Ranked ONCE, here. Showing the top slice of a rank-ordered list and then the tail of an
    # alphabetical one listed four decisions twice, under a heading promising the remainder.
    ranked = sorted(blocking.items(), key=lambda kv: (-len(kv[1]), kv[0]))
    return {
        "pack": pack,
        "records": f.get("records", 0), "domains": f.get("domains", 0), "produces": s["produces"],
        "items": f.get("items"), "mapped": f.get("mapped", 0),
        "undispositioned": f.get("undispositioned"), "pending_mapping": f.get("pending_mapping"),
        "claimed": s["claimed"], "blocks": s["blocks"],
        "blocked_records": sorted({v for vs in blocking.values() for v in vs}),
        "decisions": [{"id": did, "blocks": vs, "count": len(vs),
                       "question": " ".join(cell(table.get(did, {}), "Question").split())}
                      for did, vs in ranked],
        # "no register at all" and "a register with nothing open" are different answers, and only
        # one of them is reassuring — the renderers must be able to tell them apart.
        "register": len(table), "idle": sorted(idle),
        "proposals": list(proposals), "unclaimed": list(errors),
        # OPEN, AND ON NEITHER LIST. `blast_radius` classifies a decision by the records it blocks,
        # and an OUTPUT decision blocks no single record — it owns the whole published surface. So
        # NAME-ALIGN and CODE-ALIGN were open, load-bearing for every column in the ADS, and absent
        # from a worklist that read as the complete open set. Derived by subtraction from the
        # register rather than by naming them: the next pack will spell them differently.
        "unranked": sorted(d for d, st in _status.items()
                           if str(st).upper() == "OPEN" and d not in blocking and d not in idle),
        # ACCOUNTED IS NOT CLEAN. `check` reports the contract-vs-engine published surface here
        # rather than as an error, because an open output decision OWNS the difference — dropping
        # it left "all 38 governed blocks are claimed" standing as the whole Gate 4 answer.
        "surface_notes": list(s.get("surface_notes") or []),
    }


def render(pack, show_values=False):
    stop = not_started(pack)
    if stop:
        return stop

    m = model(pack)
    f = {k: m[k] for k in ("records", "domains", "items", "mapped", "undispositioned",
                           "pending_mapping")}
    s = {"produces": m["produces"], "claimed": m["claimed"], "blocks": m["blocks"]}
    errors, proposals, idle = m["unclaimed"], m["proposals"], m["idle"]
    blocked_records = m["blocked_records"]
    L = ["", "=" * WIDTH, f"  CONFIG WORKSHEET — {pack}", "=" * WIDTH,
         f"  {f.get('records', 0)} contract record(s) over {f.get('domains', 0)} domain(s); "
         f"{s['produces']} produce output."]

    # COVERAGE, BEFORE ANYTHING IS RANKED. Ovarian's contract holds 9 of 360 spec items with 299
    # undispositioned, and the worksheet reported 3 blocking decisions and 33 unclaimed blocks —
    # small numbers that read as "nearly done" when almost nothing has been drafted. A short list
    # is only good news if the list is complete, and these three are complete only over the part
    # of the specification somebody has already worked.
    undisp = f.get("undispositioned")
    if f.get("items") is not None:
        L.append(f"  {f.get('mapped', 0)} of {f['items']} spec item(s) are in the contract"
                 + (f" — {undisp} UNDISPOSITIONED." if undisp else "."))
    L += [f"  {s['claimed']}/{s['blocks']} governed config block(s) claimed by a record.",
          f"  {len(blocked_records)} record(s) cannot be finished until a decision is answered.",
          ""]
    if undisp:
        L += _wrap(f"The three lists below cover only the part of the specification already drafted "
                   f"into records. {undisp} spec row(s) are absent from them because nothing has "
                   f"looked at those rows yet — so a short list here is not evidence of a small "
                   f"amount of remaining work.", 2, cap=6)
        L.append("")
    if f.get("pending_mapping"):
        L.append(f"  {f['pending_mapping']} record(s) still carry an unconfirmed source mapping — a")
        L.append("  human confirms a column is the RIGHT column at Gate 3, with a profile.")
        L.append("")

    # 1 — decisions, ranked. One answer can unblock nineteen records; file order cannot.
    L += [rule(), " 1. ANSWER THESE — ranked by how many records each one unblocks", rule(), ""]
    ranked = m["decisions"]
    if not ranked and not m["register"]:
        L.append(f"     This pack keeps no decisions register — {NOTHING_TO_CHECK}.")
    elif not ranked:
        L.append(f"     No open decision is blocking a record ({m['register']} in the register).")
    for d in ranked[:TOP_DECISIONS]:
        vs = d["blocks"]
        L.append(f"     [{d['count']:>3} record(s)]  {d['id']}")
        for line in _wrap(d["question"], 22):
            L.append(line)
        L.append(f"{'':22}blocks: {', '.join(vs[:6])}{' …' if len(vs) > 6 else ''}")
        L.append("")
    rest = [d["id"] for d in ranked[TOP_DECISIONS:]]
    if rest:
        L.append(f"     …and {len(rest)} more, each blocking fewer: {', '.join(rest)}")
        L.append("")
    if idle:
        L.append(f"     {len(idle)} open decision(s) block no record today: {', '.join(sorted(idle))}")
        L.append("     Open, and not on the critical path — answer them after the list above.")
        L.append("")
    # OUTPUT decisions block no single record, so the blast-radius ranking cannot see them — and
    # they own the whole published surface. Listed apart from the ranking rather than mixed into it.
    if m["unranked"]:
        L.append(f"     {len(m['unranked'])} open decision(s) block no single record but govern the")
        L.append(f"     OUTPUT as a whole: {', '.join(m['unranked'])}")
        L.append("     Not rankable by blast radius — they gate every column, not a set of them.")
        L.append("")

    # 2 — what needs no judgment at all.
    # "PASTE THESE" while every block under it said "ALREADY PRESENT — compare, do not paste over
    # it". True for a pack with no config yet; the opposite instruction for one that has it. The
    # heading now covers both, and the blocks still say which case they are.
    L += [rule(), " 2. CHECK THESE VALUES — value lists the specification already states",
          rule(), "",
          f"     {len(proposals)} block(s) of candidate values, lifted from the spec rows the",
          "     contract cites, so nobody retypes them. Each names what the spec does NOT state —",
          "     numeric codes, terminal fallthrough, the engine's own key names — and those are",
          "     yours to decide; the tool refuses to guess them.", ""]
    if not proposals and not s["blocks"]:
        L.append("     This pack has no config/ yet, so there is nowhere for a value list to go —")
        L.append(f"     {NOTHING_TO_CHECK}.")
        L.append("")
    elif not proposals:
        L.append("     None: no spec enumeration is bound to a config block in this pack yet.")
        L.append("")
    elif show_values:
        for block in proposals:
            for line in block.splitlines():
                L.append(f"     {line}")
            L.append("")
    else:
        for block in proposals:
            L.append(f"     {block.splitlines()[0]}")
        L.append("")
        L.append("     Re-run with --values to see them in full, or:")
        L.append(f"         python3 platform/tools/contract_binding.py {pack} --promote")
        L.append("")

    # 3 — the reverse direction: config the contract does not account for.
    L += [rule(), " 3. ACCOUNT FOR THESE — config the contract does not claim", rule(), ""]
    if not errors and not s["blocks"]:
        L.append("     This pack has no config/ yet, so there are no governed blocks to claim.")
        L.append(f"     That is 0 of 0 — {NOTHING_TO_CHECK}.")
    elif not errors:
        L.append(f"     None: all {s['blocks']} governed block(s) are claimed by a record.")
    for e in errors[:12]:
        L.append(f"     · {e}")
    if len(errors) > 12:
        L.append(f"     …and {len(errors) - 12} more — run contract_binding.py {pack} --check")
    L.append("")
    # ACCOUNTED IS NOT CLEAN, and this is where that distinction was being lost. Every governed
    # block can be claimed while the ADS the engine emits and the surface the contract publishes
    # still disagree — an open output decision OWNS that difference, which is why it is reported
    # rather than raised. Printing only the block count let "all 38 claimed" read as the whole
    # Gate 4 answer.
    if m["surface_notes"]:
        L += [rule(), "  ACCOUNTED, NOT CLEAN — the published surface", rule(), ""]
        for note in m["surface_notes"]:
            for line in note.splitlines():
                L.append(f"     {line.rstrip()}")
        L.append("")

    L += [rule(), "  WHAT THIS WILL NOT DO FOR YOU", rule(),
          "   · Choose a source column. Only a human confirms a column is the RIGHT column, at",
          "     Gate 3, against a profile — `promote` refuses to propose one.",
          "   · Invent a numeric code, a terminal fallthrough or a missing-value code. Each is",
          "     emitted as a named gap instead, because a generator that guessed would guess",
          "     silently and the result would be indistinguishable from a specified value.",
          "   · Resolve a decision or approve anything. Those are human acts recorded in the",
          "     pack's own files, and no tool here may perform them.",
          "",
          "   `python3 platform/tools/blocks.py` lists what the config may NAME.",
          ""]
    return "\n".join(L)


def _wrap(text, indent, cap=3):
    """Wrapped and TRUNCATED. `cap` defaults to 3 because a decision question is quoted for
    recognition, not reproduction — the register holds the full text and the id is right there.
    The coverage note passes a larger cap: it is the tool's own sentence, and cutting it mid-clause
    would drop the part that says a short list is not evidence of little work."""
    import textwrap
    if not text:
        return []
    return textwrap.wrap(text, width=WIDTH - indent, initial_indent=" " * indent,
                         subsequent_indent=" " * indent)[:cap]


def main(argv):
    ap = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    ap.add_argument("pack", help="the pack directory (repo-root-relative)")
    ap.add_argument("--values", action="store_true",
                    help="print the candidate value blocks in full, not just their headings")
    a = ap.parse_args(argv)
    pack = os.path.relpath(os.path.abspath(a.pack), ROOT).replace(os.sep, "/")
    if not os.path.isdir(os.path.join(ROOT, pack)):
        sys.exit(f"{a.pack}: not a directory")
    print(render(pack, a.values))
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
