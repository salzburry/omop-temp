# Data characterization — a standalone profiler that works for any tumor/product. Point it at ANY
# Databricks schema (or local extracts) and it writes a stakeholder report: per-column distribution
# and missingness for every table. Nothing here is tumor-specific.
#
# TO RUN AGAINST A REAL FEED, use the shared entry point — it derives the table scope from the
# product's own config, keeps each source-union member's output separate, and refuses to write
# restricted output into the checkout:
#   python3 platform/tools/run_product_profile.py <pack> --cut <cut> --schema <schema> \
#     --out-dir <restricted path outside the checkout> [--inventory-only]
# Running this script directly is for synthetic/local development. It still works against a feed
# (edit the CONFIG block, at least catalog + schema, then
#   DATABRICKS_DSN=RWDE DATABRICKS_PWD=... DC_OUT_DIR=<restricted> Rscript data_profiler.R)
# but dbi mode REQUIRES DC_OUT_DIR — see the out_dir note below for why.
# Any CONFIG value can also be set with its DC_* env var (env wins), so automation keeps working —
# but for a person, editing the block and running is all it takes. dplyr over ODBC, no Spark.

library(dplyr); library(stringr)

# ============================ CONFIG — edit these, then run ============================
# Fill in your feed and run `Rscript data_profiler.R`. `schema` is REQUIRED and has no default, so a
# copy of this script can't silently profile the wrong product — set it to YOUR product's schema (or
# pass DC_SCHEMA). Every value here is also overridable by the matching DC_* env var (env wins).
CFG <- list(
  catalog     = "hive_metastore",  # catalog (shared Databricks metastore; overridable)   (env DC_CATALOG)
  schema      = "",                # REQUIRED — your product's schema, e.g. clnprw_flatiron_pano_ovar_use (DC_SCHEMA)
  cut         = "",           # keep only tables ending in this snapshot, e.g. "2026m06"  (DC_CUT; ""=all)
  baseline    = "",           # prior drop's inventory.txt -> flags added cols  (DC_BASELINE_COLS; ""=none)
  product_id  = "",           # stable product identity for cross-schema baselines, e.g. "oc-panoramic" (DC_PRODUCT_ID; ""=use catalog.schema)
  tables      = "",           # comma list to limit tables, else all in the schema        (DC_TABLES)
  sample_n    = 200000L,      # rows per table; 0 = ALL rows / exact numbers              (DC_SAMPLE_N)
  out_dir     = "",           # where outputs go; "" = ./outputs in the WORKING dir        (DC_OUT_DIR)
  source_mode = "dbi",        # "dbi" (Databricks) or "local" (.parquet/.csv extracts)    (DC_SOURCE_MODE)
  local_dir   = "",           # folder of extracts when source_mode = "local"             (DC_LOCAL_DIR)
  # -- advanced (rarely changed) --
  sample_seed = 42L,          # reproducible-sample seed                                  (DC_SAMPLE_SEED)
  top_n       = 10L,          # top values listed per categorical column                  (DC_TOPN)
  cut_regex   = "_(\\d{4}m\\d{2}|\\d{4}q[1-4]|\\d{6}|\\d{4})$",  # snapshot-suffix strip           (DC_CUT_REGEX)
  cut_table_regex = "",   # regex to SELECT a snapshot's tables; "" = default "_<DC_CUT>$"  (DC_CUT_FILTER_REGEX)
  known_new_tables = "",      # manual "new" hint when there is no baseline (comma list)   (DC_KNOWN_NEW_TABLES)
  known_new_cols   = "",      # ditto for columns                                         (DC_KNOWN_NEW_COLS)
  missing_tokens   = "",      # extra values counted as MISSING, e.g. "Unknown,Not documented" (DC_MISSING_TOKENS)
  numeric_cat_max  = 10L,     # a numeric column with <= this many distinct values is summarised as categorical (DC_NUMERIC_CAT_MAX)
  kind_overrides   = "",      # force a column's kind: "col1=categorical,col2=numeric"     (DC_KIND_OVERRIDES)
  require_baseline = FALSE,   # TRUE = refuse to run without DC_BASELINE_COLS + DC_CUT (formal old->new mode) (DC_REQUIRE_BASELINE)
  new_only         = FALSE,   # TRUE = profile ONLY newly-added columns (the new-variables ask); full profile is the default (DC_NEW_ONLY)
  inventory_only   = FALSE    # TRUE = write the column inventory only, reading no data rows (cheap old-snapshot pass) (DC_INVENTORY_ONLY)
)
# ======================================================================================

# ---- config resolution (a DC_* env var, if set, overrides the CONFIG block above) ----
getcfg  <- function(env, default) { v <- Sys.getenv(env, ""); if (nzchar(v)) v else default }
getcfgi <- function(env, default) { v <- Sys.getenv(env, ""); if (nzchar(v)) as.integer(v) else as.integer(default) }
catalog     <- getcfg ("DC_CATALOG",     CFG$catalog)
schema      <- getcfg ("DC_SCHEMA",      CFG$schema)
tables_env  <- getcfg ("DC_TABLES",      CFG$tables)
cut_filter  <- getcfg ("DC_CUT",         CFG$cut)
sample_n    <- getcfgi("DC_SAMPLE_N",    CFG$sample_n)
sample_seed <- getcfgi("DC_SAMPLE_SEED", CFG$sample_seed)
top_n       <- getcfgi("DC_TOPN",        CFG$top_n)
source_mode <- getcfg ("DC_SOURCE_MODE", CFG$source_mode)
local_dir   <- getcfg ("DC_LOCAL_DIR",   CFG$local_dir)

# Outputs default to ./outputs in the WORKING directory, not next to this script. This is shared
# platform code installed once and run by every product; writing beside the script would drop one
# product's vendor-derived profile into the tool's own install dir (and that dir may be read-only in
# prod). Callers that want a fixed home set DC_OUT_DIR — run_product_profile.py does.
out_dir <- { v <- getcfg("DC_OUT_DIR", CFG$out_dir); if (nzchar(v)) v else file.path(getwd(), "outputs") }
# ...but that default is only safe for SYNTHETIC local runs. In dbi mode the output carries per-column
# top values and date ranges from the real feed, with no small-cell floor — IHD under R&D policy §9 —
# and `./outputs` is the checkout whenever someone follows the header instructions from a clone.
# .gitignore would stop the commit, not a read by an indexing tool or any process with checkout
# access. So dbi mode must name its destination; run_product_profile.py additionally refuses a path
# inside the checkout and is the supported production entry point.
if (source_mode == "dbi" && !nzchar(getcfg("DC_OUT_DIR", CFG$out_dir))) {
  stop("DC_OUT_DIR is required in dbi mode: the profile carries vendor top values and date ranges, ",
       "and the default ./outputs is inside the repository when this is run from a checkout. ",
       "Set DC_OUT_DIR to a restricted path outside the checkout, or use the supported entry point:\n",
       "  python3 platform/tools/run_product_profile.py <pack> --cut <cut> --schema <schema> ",
       "--out-dir <restricted>")
}
# What the report says it profiled — local mode must not be labelled as the Databricks schema.
source_label <- if (source_mode == "local") sprintf("local:%s", local_dir) else sprintf("%s.%s", catalog, schema)
require_baseline <- tolower(getcfg("DC_REQUIRE_BASELINE", as.character(CFG$require_baseline))) %in% c("true","1","yes","t")
product_id       <- getcfg("DC_PRODUCT_ID", CFG$product_id)   # optional stable product identity; if set, the baseline
# provenance check compares THIS (not the schema), so a same-product feed may live in cut-specific schemas.
new_only         <- tolower(getcfg("DC_NEW_ONLY",       as.character(CFG$new_only)))       %in% c("true","1","yes","t")
inventory_only   <- tolower(getcfg("DC_INVENTORY_ONLY", as.character(CFG$inventory_only))) %in% c("true","1","yes","t")

# "New" detection. Best way: compare against the prior feed. Set DC_BASELINE_COLS to a file of
# "tablebase|column" lines (base = table name without the _YYYYmMM cut); a column is new if it isn't
# in that list. With no baseline, nothing is flagged unless you name the additions yourself via
# DC_KNOWN_NEW_TABLES / DC_KNOWN_NEW_COLS — kept generic (no tumor or product baked in) so the one
# script works everywhere. Prefer a baseline; the manual hints are just a fallback.
env_list <- function(env, default) { v <- str_trim(getcfg(env, default))
  if (!nzchar(v)) character(0) else str_to_lower(str_split(v, "\\s*,\\s*")[[1]]) }
KNOWN_NEW_TABLES <- env_list("DC_KNOWN_NEW_TABLES", CFG$known_new_tables)   # base names; default none
KNOWN_NEW_COLS   <- env_list("DC_KNOWN_NEW_COLS",   CFG$known_new_cols)     # column names; default none
missing_tokens_lc <- env_list("DC_MISSING_TOKENS", CFG$missing_tokens)      # extra values treated as missing (lowercased)
numeric_cat_max   <- getcfgi("DC_NUMERIC_CAT_MAX", CFG$numeric_cat_max)     # numeric with <= this many distinct -> categorical
# Fail loud on a malformed setting (e.g. DC_SAMPLE_N=abc -> NA via as.integer) instead of a cryptic crash
# later. sample_n / numeric_cat_max may be 0; sample_seed (feeds TABLESAMPLE REPEATABLE) and top_n must be >= 1.
for (.nm in c("sample_n", "numeric_cat_max")) { .v <- get(.nm)
  if (length(.v) != 1L || is.na(.v) || .v < 0L)
    stop(sprintf("config %s must resolve to a non-negative integer (check its DC_* override).", .nm)) }
for (.nm in c("sample_seed", "top_n")) { .v <- get(.nm)
  if (length(.v) != 1L || is.na(.v) || .v < 1L)
    stop(sprintf("config %s must resolve to a positive integer (check its DC_* override).", .nm)) }
if (!source_mode %in% c("dbi", "local"))
  stop(sprintf("DC_SOURCE_MODE must be 'dbi' or 'local', got '%s'.", source_mode))
# per-column kind override "col=categorical,col2=numeric" -> named char vector (names/values lowercased).
# Fail loud on a malformed entry (no '=', empty column, unsupported kind like a "numerci" typo) instead of
# silently falling back to inference — only "numeric" and "categorical" are supported overrides.
kind_overrides <- local({
  s <- str_trim(getcfg("DC_KIND_OVERRIDES", CFG$kind_overrides))
  if (!nzchar(s)) return(character(0))
  kv  <- str_split(str_split(s, "\\s*,\\s*")[[1]], "\\s*=\\s*")
  bad <- vapply(kv, function(p) length(p) != 2L || !nzchar(str_trim(p[1])) ||
                  !str_to_lower(str_trim(p[2])) %in% c("numeric", "categorical"), logical(1))
  if (any(bad))
    stop(sprintf("DC_KIND_OVERRIDES: each entry must be 'column=numeric' or 'column=categorical' — bad: %s",
                 paste(vapply(kv[bad], function(p) paste(p, collapse = "="), character(1)), collapse = ", ")))
  setNames(vapply(kv, function(p) str_to_lower(str_trim(p[2])), character(1)),
           vapply(kv, function(p) str_to_lower(str_trim(p[1])), character(1)))
})
# Strip the snapshot cut so tables match across drops. Default covers _YYYYmMM, _YYYYqN, _YYYYMM,
# _YYYY; set CFG$cut_regex (or DC_CUT_REGEX) for a data product that suffixes snapshots differently.
cut_regex <- getcfg("DC_CUT_REGEX", CFG$cut_regex)
cut_table_regex <- getcfg("DC_CUT_FILTER_REGEX", CFG$cut_table_regex)  # selects a cut's tables (else "_<cut>$")
base_name <- function(tbl) str_replace(str_to_lower(tbl), cut_regex, "")
# Map a recognized cut label to a sortable "year*100 + month" value (YYYYmMM, YYYYqN -> quarter*3, YYYYMM,
# YYYY -> month 0), so the baseline can be checked to be chronologically OLDER than the current cut. Returns
# NA for a custom/unrecognized format, which the caller then skips (it can't be ordered).
cut_order <- function(s) {
  if (is.na(s) || !nzchar(s)) return(NA_real_)
  s <- str_to_lower(s)
  if (grepl("^\\d{4}m\\d{2}$", s)) return(as.integer(substr(s, 1, 4)) * 100 + as.integer(substr(s, 6, 7)))
  if (grepl("^\\d{4}q[1-4]$", s)) return(as.integer(substr(s, 1, 4)) * 100 + as.integer(substr(s, 6, 6)) * 3L)
  if (grepl("^\\d{6}$",       s)) return(as.numeric(s))            # YYYYMM
  if (grepl("^\\d{4}$",       s)) return(as.numeric(s) * 100)      # YYYY -> month 0
  NA_real_
}

baseline_file <- getcfg("DC_BASELINE_COLS", CFG$baseline)
if (nzchar(baseline_file) && !file.exists(baseline_file))
  stop(sprintf("DC_BASELINE_COLS is set but the file was not found: %s", baseline_file))
# Read the baseline. Leading "# key=value" lines are a provenance header written by this tool; skip
# them for the column set and parse them to verify the baseline is the same product/schema/scope.
baseline_raw <- if (nzchar(baseline_file)) readLines(baseline_file, warn = FALSE) else character(0)
baseline_meta_of <- function(key) {
  h <- grep(sprintf("^#\\s*%s=", key), baseline_raw, value = TRUE)
  if (!length(h)) NA_character_ else str_trim(sub(sprintf("^#\\s*%s=", key), "", h[1]))
}
baseline_cols <- { ln <- str_to_lower(str_trim(baseline_raw[!grepl("^\\s*#", baseline_raw)])); ln[ln != ""] }
# A set-but-empty baseline is a mistake, not "no baseline" — stop instead of silently falling
# back to the heuristic list (which would hide that the comparison never happened).
if (nzchar(baseline_file) && !length(baseline_cols))
  stop(sprintf("DC_BASELINE_COLS is set but the file has no usable entries: %s", baseline_file))
# An inventory.txt is "tablebase|column" lines. If almost none contain "|", it's the wrong file
# (e.g. a report or a catalogue) and would silently produce a bogus "everything is new" comparison.
if (length(baseline_cols) && mean(grepl("\\|", baseline_cols)) < 0.5)
  stop(sprintf("DC_BASELINE_COLS doesn't look like an inventory.txt ('tablebase|column' lines): %s", baseline_file))
# Every data line must be a single 'tablebase|column' pair (both sides non-empty, exactly one separator).
# A partially corrupted line would silently pollute the added/dropped diff: formal mode stops, otherwise
# the bad lines are dropped with a warning.
bad_lines <- baseline_cols[!grepl("^[^|]+\\|[^|]+$", baseline_cols)]
if (length(bad_lines)) {
  preview <- paste(utils::head(bad_lines, 3L), collapse = "; ")
  if (require_baseline)
    stop(sprintf("DC_BASELINE_COLS has %d malformed line(s) (need 'tablebase|column'): %s", length(bad_lines), preview))
  message(sprintf("WARNING: dropping %d malformed baseline line(s) (need 'tablebase|column'): %s", length(bad_lines), preview))
  baseline_cols <- setdiff(baseline_cols, bad_lines)
  if (!length(baseline_cols))
    stop(sprintf("DC_BASELINE_COLS has no usable 'tablebase|column' lines after dropping malformed ones: %s", baseline_file))
}
baseline_tbls <- unique(sub("\\|.*$", "", baseline_cols))
have_baseline <- length(baseline_cols) > 0
# Provenance guard: a valid-looking inventory from a DIFFERENT product would pass the format check and
# flag everything as new/dropped. In formal mode (DC_REQUIRE_BASELINE) the baseline must carry THIS tool's
# provenance header, a specific cut, and — when DC_PRODUCT_ID is set — a product field to check identity
# against; a missing/incomplete header is rejected, not warned. Any product/schema mismatch, incompatible
# normalization (cut_regex or table-selection regex), or self-comparison is a hard error. Without formal
# mode these are warnings, so an older headerless inventory still runs.
# Compare scopes as normalized table BASES (order- and cut-suffix-insensitive): base_name lowercases and
# strips the snapshot suffix, so "t_x_2026m03" and "t_x_2026m06" read as the same logical scope and a
# reordered list is not a false difference. "all" (no DC_TABLES) normalizes to itself.
norm_scope <- function(s) if (is.na(s) || !nzchar(s)) s else
  paste(sort(unique(base_name(str_trim(str_split(s, ",")[[1]])))), collapse = ",")
if (have_baseline) {
  b_schema <- baseline_meta_of("schema"); b_catalog <- baseline_meta_of("catalog"); b_cut <- baseline_meta_of("cut")
  b_scope  <- baseline_meta_of("scope");  b_regex  <- baseline_meta_of("cut_regex")
  b_product   <- baseline_meta_of("product"); b_cutfilter <- baseline_meta_of("cut_filter_regex")
  cur_scope     <- if (nzchar(tables_env)) tables_env else "all"
  cur_cutfilter <- if (nzchar(cut_table_regex)) cut_table_regex else "default"
  has_tool_header <- any(grepl("^#\\s*data_profiler inventory", baseline_raw))
  prod_missing_id <- nzchar(product_id) && is.na(b_product)   # DC_PRODUCT_ID set but the baseline has no product to compare
  # Formal mode rejects missing/incomplete provenance instead of warning: it requires the COMPLETE manifest
  # this tool writes — header, catalog, schema, cut, scope, cut_regex, cut_filter_regex (and a product field
  # when DC_PRODUCT_ID is set) — so no identity/normalization/scope check is silently skipped because a field
  # was hand-edited out. Cheap to satisfy: regenerate the old inventory with this profiler (DC_INVENTORY_ONLY).
  if (require_baseline) {
    need <- c(
      if (!has_tool_header)   "the tool's provenance header (regenerate the old inventory with this profiler, e.g. DC_INVENTORY_ONLY)" else NULL,
      if (is.na(b_catalog))   "a catalog field" else NULL,
      if (is.na(b_schema))    "a schema field" else NULL,
      if (prod_missing_id)    "a product field (DC_PRODUCT_ID is set — regenerate the old inventory with it, or unset it on both runs)" else NULL,
      if (is.na(b_cut))       "a cut field (regenerate the old inventory with DC_CUT set)" else NULL,
      if (is.na(b_scope))     "a scope field" else NULL,
      if (is.na(b_regex))     "a cut_regex field" else NULL,
      if (is.na(b_cutfilter)) "a cut_filter_regex field" else NULL)
    if (length(need))
      stop(sprintf("DC_REQUIRE_BASELINE: the baseline inventory is missing %s. Regenerate the old inventory with the current profiler.", paste(need, collapse = "; and ")))
  }
  if (is.na(b_schema)) {
    message("WARNING: baseline has no provenance header (older inventory) — cannot verify same product/schema/scope.")
  } else {
    # Product identity: DC_PRODUCT_ID, if set, is the wrong-product test (so a same-product feed may live
    # in cut-specific schemas and the schema is allowed to change); otherwise catalog.schema IS the identity.
    prod_bad <- if (nzchar(product_id)) (!is.na(b_product) && !identical(tolower(b_product), tolower(product_id)))
                else (!identical(tolower(b_schema), tolower(schema)) ||
                      (!is.na(b_catalog) && !identical(tolower(b_catalog), tolower(catalog))))
    # Hard mismatches (wrong product, unverifiable product, incompatible normalization, self-comparison) fail
    # loud in formal mode; a table-scope difference is softer (a subset is a legit choice) so it always warns.
    mism <- if (prod_bad)
        if (nzchar(product_id)) sprintf("baseline product '%s' != this run's product '%s'", if (is.na(b_product)) "?" else b_product, product_id)
        else sprintf("baseline is from %s.%s but this run profiles %s.%s — wrong product/schema",
                     if (is.na(b_catalog)) "?" else b_catalog, b_schema, catalog, schema)
      else if (prod_missing_id)
        sprintf("DC_PRODUCT_ID='%s' is set but the baseline has no product field — can't verify same product; regenerate the old inventory with DC_PRODUCT_ID (or unset it on both runs)", product_id)
      else if (!is.na(b_regex) && !identical(b_regex, cut_regex))
        sprintf("baseline cut_regex differs (%s vs %s) — table-name normalization won't match, so added/dropped is unreliable", b_regex, cut_regex)
      else if (!is.na(b_cutfilter) && !identical(b_cutfilter, cur_cutfilter))
        sprintf("baseline table-selection regex differs (%s vs %s) — the two runs pick tables differently, so added/dropped is unreliable", b_cutfilter, cur_cutfilter)
      else if (!is.na(b_cut) && nzchar(cut_filter) && identical(tolower(b_cut), tolower(cut_filter)))
        sprintf("baseline cut (%s) equals this run's cut — comparing a snapshot against itself", b_cut)
      else ""
    if (nzchar(mism)) {
      if (require_baseline) stop(sprintf("baseline provenance check failed: %s (fix the baseline, or unset DC_REQUIRE_BASELINE to bypass)", mism))
      else message(sprintf("WARNING: %s", mism))
    }
    # Formal mode needs a cut-specific baseline: a cut=all inventory may combine snapshots and skew the diff.
    if (require_baseline && !is.na(b_cut) && identical(tolower(b_cut), "all"))
      stop("DC_REQUIRE_BASELINE: the baseline inventory has cut=all (no specific snapshot) — regenerate the old inventory with DC_CUT set.")
    # A real scope difference makes added/dropped unreliable (columns outside the smaller scope look
    # added or dropped), so formal mode stops; otherwise it warns.
    if (!is.na(b_scope) && !identical(norm_scope(b_scope), norm_scope(cur_scope))) {
      smsg <- sprintf("baseline table scope (%s) differs from this run (%s) — use the same table scope on both runs.", b_scope, cur_scope)
      if (require_baseline) stop(sprintf("baseline provenance check failed: %s", smsg))
      else message(sprintf("WARNING: %s", smsg))
    }
    # Best-effort chronological guard: the baseline should be the PRIOR snapshot. If both cuts are a
    # recognized format and the baseline is not older than this run's cut, the old/new order is likely
    # swapped (e.g. June fed as the baseline for March, or the same period in a different label such as
    # 2026q1 vs 2026m03). The exact-same cut string is left to the self-comparison check above; custom/
    # unorderable cut formats are skipped.
    b_ord <- cut_order(b_cut); c_ord <- cut_order(cut_filter)
    if (!is.na(b_ord) && !is.na(c_ord) && b_ord >= c_ord && !identical(tolower(b_cut), tolower(cut_filter))) {
      omsg <- sprintf("baseline cut (%s) is not older than this run's cut (%s) — is the old/new order swapped?", b_cut, cut_filter)
      if (require_baseline) stop(sprintf("baseline provenance check failed: %s", omsg))
      else message(sprintf("WARNING: %s", omsg))
    }
  }
}
profile_mode  <- if (inventory_only) "inventory-only" else if (new_only && have_baseline) "new-columns-only" else "full"
# Output-affecting settings, recorded in the report so an archived artifact is reproducible.
settings_txt <- sprintf("missing_tokens=%s; numeric_cat_max=%d; top_n=%d; kind_overrides=%s; product_id=%s; cut_filter_regex=%s",
  if (length(missing_tokens_lc)) paste(missing_tokens_lc, collapse = ",") else "none", numeric_cat_max, top_n,
  if (length(kind_overrides)) paste(sprintf("%s=%s", names(kind_overrides), kind_overrides), collapse = ",") else "none",
  if (nzchar(product_id)) product_id else "none",
  if (nzchar(cut_table_regex)) cut_table_regex else "default")
if (new_only && !have_baseline)
  message("WARNING: DC_NEW_ONLY is set but no baseline was given -> profiling ALL columns. Set DC_BASELINE_COLS ",
          "(and DC_REQUIRE_BASELINE to fail loud) for the focused new-columns-only run.")
new_detection <- if (have_baseline) sprintf("compared against baseline (%s)", basename(baseline_file)) else
                 if (length(KNOWN_NEW_TABLES) || length(KNOWN_NEW_COLS))
                   "manual DC_KNOWN_NEW_* hint (set DC_BASELINE_COLS to diff the prior feed instead)" else
                 "none flagged (set DC_BASELINE_COLS to diff the prior feed, or DC_KNOWN_NEW_* for a manual hint)"
is_new_table <- function(tbl) if (have_baseline) !(base_name(tbl) %in% baseline_tbls) else
                              base_name(tbl) %in% KNOWN_NEW_TABLES
is_new_col   <- function(tbl, col) if (have_baseline) !(paste(base_name(tbl), str_to_lower(col), sep = "|") %in% baseline_cols) else
                                   str_to_lower(col) %in% KNOWN_NEW_COLS

# ---- connection (Databricks over ODBC) ----
# bigint = "character": the profiler reads arbitrary columns, and a large 64-bit id read as a double can
# lose precision (collapsing distinct ids and understating distinct counts). As text, ids stay exact and
# read as high-cardinality categoricals, which is the right treatment. If a real numeric measure arrives
# as a big integer, force it back with DC_KIND_OVERRIDES=col=numeric (it coerces the character column).
get_con <- function() {
  if (exists("con", envir = .GlobalEnv)) return(get("con", envir = .GlobalEnv))
  pwd <- Sys.getenv("DATABRICKS_PWD", "")
  if (!nzchar(pwd)) stop("set DATABRICKS_PWD, or provide a DBI `con`, or use DC_SOURCE_MODE=local.")
  DBI::dbConnect(odbc::odbc(), dsn = Sys.getenv("DATABRICKS_DSN", "RWDE"),
                 pwd = pwd, timeout = 120, bigint = "character")
}
fqtn <- function(tbl) paste(c(catalog, schema, tbl), collapse = ".")

list_tables <- function(con) {
  df <- DBI::dbGetQuery(con, sprintf("SHOW TABLES IN %s.%s", catalog, schema))
  names(df) <- tolower(names(df))
  if ("tablename" %in% names(df)) df$tablename else df[[ncol(df) - 1]]
}
row_count <- function(con, tbl)
  as.numeric(DBI::dbGetQuery(con, sprintf("SELECT count(*) AS n FROM %s", fqtn(tbl)))$n[1])
# Column names WITHOUT reading data rows (LIMIT 0) — the cheap "schema-only" path for the old snapshot
# and for deciding which columns are new before pulling any data.
table_columns <- function(con, tbl)
  tolower(names(DBI::dbGetQuery(con, sprintf("SELECT * FROM %s LIMIT 0", fqtn(tbl)))))

load_dbi <- function(con, tbl, n_total, cols = NULL) {
  sel <- if (is.null(cols) || !length(cols)) "*" else paste(sprintf("`%s`", cols), collapse = ", ")
  q <- if (sample_n > 0 && n_total > sample_n)   # reproducible random sample, not first-N
         sprintf("SELECT %s FROM %s TABLESAMPLE (%f PERCENT) REPEATABLE (%d)",
                 sel, fqtn(tbl), min(100, 100 * sample_n / n_total), sample_seed)
       else sprintf("SELECT %s FROM %s", sel, fqtn(tbl))
  df <- as_tibble(DBI::dbGetQuery(con, q)); names(df) <- tolower(names(df)); df
}
load_local <- function(tbl) {
  pq <- file.path(local_dir, paste0(tbl, ".parquet"))
  cs <- file.path(local_dir, paste0(tbl, ".csv"))
  df <- if      (file.exists(pq)) as_tibble(arrow::read_parquet(pq))
        else if (file.exists(cs)) as_tibble(readr::read_csv(cs, show_col_types = FALSE))
        else stop(sprintf("no extract for %s in %s", tbl, local_dir))
  names(df) <- tolower(names(df)); df
}

# ---- profiling ----
# Missing = NULL/NA/blank, plus any DC_MISSING_TOKENS you configure (e.g. "Unknown","Not documented").
# Default is technical missingness only; sentinel tokens are opt-in, and are matched case-insensitively.
is_missing <- function(x) if (is.character(x)) {
    t <- str_to_lower(str_trim(x)); is.na(x) | t == "" | t %in% missing_tokens_lc
  } else is.na(x)
# Flatiron dates arrive as character over ODBC; treat an ISO-date-looking string column as a
# date so it gets a range instead of being mislabeled high-cardinality. Returns the full parsed
# vector (NA where a value didn't parse) so the caller can count and report the failures.
date_or_null <- function(v) {
  s <- str_trim(as.character(v))
  if (mean(grepl("^\\d{4}-\\d{2}-\\d{2}", s)) < 0.9) return(NULL)
  d <- suppressWarnings(as.Date(s))
  if (mean(!is.na(d)) < 0.9) return(NULL)
  d
}
fmt_num <- function(v) {
  if (!is.finite(v)) return("n/a")
  if (abs(v - round(v)) < 1e-9) format(round(v), big.mark = ",", scientific = FALSE)
  else formatC(v, format = "f", digits = 2, big.mark = ",")
}

profile_column <- function(x, name, tbl) {
  col_type <- class(x)[1]
  n       <- length(x)
  miss    <- sum(is_missing(x))
  nonmiss <- x[!is_missing(x)]            # present values (technical missing removed)
  n_nonmiss <- length(nonmiss)           # ALWAYS n - missing, one meaning across every kind (incl. dates)
  bad_dates <- 0                          # present, date-looking values that DON'T parse (counted, not missing)
  vals    <- nonmiss                      # values that feed the distribution; for a date column, the parsed dates
  if (is.character(x) && n_nonmiss) {
    d <- date_or_null(nonmiss)
    if (!is.null(d)) { bad_dates <- sum(is.na(d)); vals <- d[!is.na(d)] }
  }
  n_valid  <- length(vals)               # values actually summarised (= n_nonmiss unless a date failed to parse)
  distinct <- length(unique(vals))
  # Structured metrics for the machine-readable profile_<cut>.tsv (input to compare_snapshots.R).
  # NA unless the column's kind fills them. Continuous columns keep a full quantile grid + mean/sd,
  # so the comparison can measure center AND shape (SMD, per-quantile drift), not just min/med/max.
  num_mean <- NA_real_; num_sd <- NA_real_
  qs <- setNames(as.numeric(rep(NA, 11)),
                 c("min","p1","p5","p10","p25","p50","p75","p90","p95","p99","max"))
  date_min <- NA_character_; date_max <- NA_character_; topv_enc <- NA_character_
  # Kind decision: dates stay dates; a numeric column is "numeric" only if it has more than
  # numeric_cat_max distinct values (else a flag/code/ordinal gets a category summary, not a mean/SD).
  # DC_KIND_OVERRIDES forces a specific column either way.
  force   <- unname(kind_overrides[str_to_lower(name)])
  is_date <- inherits(vals, "Date") || inherits(x, "POSIXct")
  # A `numeric` override on a NON-numeric column (a measure delivered as a string, or a BIGINT now read as
  # character) coerces the values to numeric so it gets a real numeric summary; values that don't parse are
  # counted as unparseable, not silently dropped. Without the override such a column stays categorical.
  if (identical(force, "numeric") && !is.numeric(x) && !is_date && n_valid) {
    cv <- suppressWarnings(as.numeric(as.character(vals)))
    bad_dates <- bad_dates + sum(is.na(cv)); vals <- cv[!is.na(cv)]
    n_valid <- length(vals); distinct <- length(unique(vals))
  }
  as_num  <- !is_date && is.numeric(vals) &&
             (identical(force, "numeric") || (!identical(force, "categorical") && distinct > numeric_cat_max))
  if (is_date) {
    kind <- "date"
    if (n_valid) { date_min <- as.character(min(vals)); date_max <- as.character(max(vals)) }
    summ <- if (n_valid) sprintf("%s -> %s", date_min, date_max) else "n/a"
    # Don't hide values that failed to parse: a mostly-clean date column with a few bad values
    # would otherwise look pristine.
    if (bad_dates > 0) summ <- sprintf("%s | %s unparseable", summ, fmi(bad_dates))
  } else if (as_num) {
    kind <- "numeric"
    summ <- if (n_valid) {
      qs[] <- quantile(vals, c(0, .01, .05, .10, .25, .50, .75, .90, .95, .99, 1),
                       na.rm = TRUE, names = FALSE)
      num_mean <- mean(vals); num_sd <- sd(vals)
      sprintf("nonmissing %s | mean %s | sd %s | min %s | p25 %s | med %s | p75 %s | max %s",
              fmt_num(n_valid), fmt_num(num_mean), fmt_num(num_sd), fmt_num(qs[["min"]]),
              fmt_num(qs[["p25"]]), fmt_num(qs[["p50"]]), fmt_num(qs[["p75"]]), fmt_num(qs[["max"]]))
    } else "n/a"
    # Surface coercion failures in the compact summary too (a `numeric` override on a character/BIGINT
    # column): otherwise a forced-numeric field with unparseable values would look clean in the report.
    if (bad_dates > 0) summ <- sprintf("%s | %s unparseable", summ, fmi(bad_dates))
  } else {
    kind <- "categorical"
    if (distinct > 50 && distinct > 0.5 * n_nonmiss) {
      summ <- sprintf("high-cardinality: %s distinct (near-unique)", fmi(distinct))
    } else if (n_nonmiss) {
      tb   <- sort(table(as.character(nonmiss)), decreasing = TRUE)
      topv <- utils::head(tb, top_n)
      # Machine-readable top values for the categorical-drift compare: "count:value" items joined by
      # "|"; values are stripped of |/tab/newline so they can't break the TSV (split on the FIRST ':').
      topv_enc <- paste(sprintf("%d:%s", as.integer(topv), gsub("[|\t\r\n]", " ", names(topv))),
                        collapse = "|")
      summ <- paste(sprintf("%s (%s, %.1f%%)", names(topv), fmi(as.integer(topv)),
                            100 * as.integer(topv) / n_nonmiss), collapse = "; ")
      if (length(tb) > top_n) summ <- paste0(summ, sprintf("; +%d more", length(tb) - top_n))
    } else summ <- "n/a"
  }
  tibble(column = name, type = col_type, kind = kind, new = is_new_col(tbl, name),
         n = n, n_nonmissing = n_nonmiss, missing = miss,
         pct_missing = if (n == 0) NA_real_ else 100 * miss / n,   # undefined (not 0%) when there are no rows
         distinct = distinct, mean = num_mean, sd = num_sd,
         min = qs[["min"]], p1 = qs[["p1"]], p5 = qs[["p5"]], p10 = qs[["p10"]], p25 = qs[["p25"]],
         p50 = qs[["p50"]], p75 = qs[["p75"]], p90 = qs[["p90"]], p95 = qs[["p95"]], p99 = qs[["p99"]],
         max = qs[["max"]], date_min = date_min, date_max = date_max, unparseable = bad_dates,
         top_values = topv_enc, summary = summ)
}

profile_table <- function(df, tbl, n_total, sampled) {
  prof <- bind_rows(lapply(names(df), function(nm) profile_column(df[[nm]], nm, tbl)))
  meta <- tibble(table = tbl, new_table = is_new_table(tbl), n_rows_total = n_total,
                 n_rows_profiled = nrow(df), n_cols = ncol(df), sampled = sampled,
                 pct_cells_missing = if (nrow(df) == 0) NA_real_ else 100 * sum(prof$missing) / (nrow(df) * ncol(df)))
  list(meta = meta, prof = prof)
}

# One row per (table, column) of machine-readable metrics -> profile_<cut>.tsv, the input to
# compare_snapshots.R. Keeps both counts and rates: missingness is stored as a rate (pct_missing) so it
# compares across snapshots with different row counts, with n_rows/n_missing beside it so you can tell
# whether a shift came from the count or the row total. Plus the full quantile grid and top values.
#
# The first four columns are the file's IDENTITY, repeated on every row. Without them the TSV is
# anonymous: it records what was measured but not what it was measured FROM, so Gate 3 could only
# take the operator's word (`--union-member <schema>`) for which member a profile covers, and a
# synthetic local run was indistinguishable from a real feed. Repeating them per row (rather than a
# header comment) keeps the file a plain rectangle that any TSV reader can load, and lets the
# consumer assert they are CONSTANT — a file assembled from two different runs fails that check.
profile_tsv_df <- function(results) {
  bind_rows(lapply(results, function(r)
    r$prof %>% mutate(table = r$meta$table, table_base = base_name(r$meta$table),
                      n_rows_total = r$meta$n_rows_total, sampled = r$meta$sampled,
                      profile_product_id  = if (nzchar(product_id)) product_id else NA_character_,
                      profile_schema      = schema,
                      profile_cut         = if (nzchar(cut_filter)) cut_filter else NA_character_,
                      # dbi = a real feed; local = synthetic/extract files. Gate 3 evidence must be
                      # dbi, and this is what lets the consumer refuse a local run outright.
                      profile_source_mode = source_mode,
                      # full | new-columns-only | inventory-only. The HTML report already tells a
                      # HUMAN that a new-columns-only run is "a partial profile ... and must not be
                      # used as a temporal-drift input"; the TSV said nothing, so the file a MACHINE
                      # reads was indistinguishable from a full schema listing. `--complete` is an
                      # operator's assertion that the profile lists every column, and the profiler
                      # knew perfectly well when it had not — it just never wrote it down.
                      profile_mode        = profile_mode) %>%
      select(profile_product_id, profile_schema, profile_cut, profile_source_mode, profile_mode,
             table_base, table, column, kind, type, new, sampled,
             n_rows = n, n_rows_total, n_nonmissing, n_missing = missing, pct_missing, distinct,
             mean, sd, min, p1, p5, p10, p25, p50, p75, p90, p95, p99, max,
             date_min, date_max, unparseable, top_values)))
}

# ---- rendering ----
esc <- function(x) { x <- as.character(x)
  x <- gsub("&", "&amp;", x, fixed = TRUE); x <- gsub("<", "&lt;", x, fixed = TRUE)
  gsub(">", "&gt;", x, fixed = TRUE) }
pctfmt   <- function(p) if (is.na(p)) "n/a" else sprintf("%.1f%%", p)   # % missing, "n/a" when no rows
fmi      <- function(n) format(n, big.mark = ",", scientific = FALSE)   # count -> "1,234,567" (never 1e+06)

# ============================ HTML report (stakeholder-facing) ============================
# The MD/TSV outputs above remain the complete technical record; the HTML is the polished
# stakeholder report — exec-summary cards, a summary-first "New variables" table with small
# categorical/date/numeric visuals, a technical appendix, and print CSS. Every value is read
# from the same profile object, so counts and scope cannot drift between sections.
cap1     <- function(s) if (!length(s) || !nzchar(s)) s else paste0(toupper(substr(s, 1, 1)), substr(s, 2, nchar(s)))
disp_tbl <- function(t) base_name(t)                                    # strip the cut suffix for display
kind_chip <- function(k) sprintf('<span class="chip kind">%s</span>', esc(cap1(k)))
alert_chip <- function(pct) if (!is.na(pct) && pct > 20) ' <span class="chip alert">&gt;20% missing</span>' else ""
miss_band <- function(pct) if (is.na(pct)) "na" else if (pct < 5) "lo" else if (pct <= 20) "mid" else "hi"
# Missing cell: severity bar (width = the ACTUAL %, capped 0-100) + "count (pct%)".
miss_cell <- function(pct, cnt) {
  if (is.na(pct)) return('<span class="na">n/a (no rows)</span>')
  sprintf('<div class="miss %s"><span class="bar"><span class="fill" style="width:%.1f%%"></span></span><span class="val"><b>%s</b> (%.1f%%)</span></div>',
          miss_band(pct), max(0, min(100, pct)), fmi(cnt), pct)
}
miss_rate_cell <- function(pct) {   # rate-only variant (tables-with-additions)
  if (is.na(pct)) return('<span class="na">n/a</span>')
  sprintf('<div class="miss %s"><span class="bar"><span class="fill" style="width:%.1f%%"></span></span><span class="val"><b>%.1f%%</b></span></div>',
          miss_band(pct), max(0, min(100, pct)), pct)
}
# Parse the machine-readable "count:value|count:value" (split each item on its FIRST colon).
parse_topv <- function(enc) {
  if (length(enc) != 1 || is.na(enc) || !nzchar(enc)) return(NULL)
  items <- strsplit(enc, "|", fixed = TRUE)[[1]]; items <- items[nzchar(items)]
  cnt <- numeric(0); val <- character(0)
  for (it in items) { pos <- regexpr(":", it, fixed = TRUE)
    if (pos < 1) next
    cnt <- c(cnt, suppressWarnings(as.numeric(substr(it, 1, pos - 1))))
    val <- c(val, substr(it, pos + 1, nchar(it))) }
  if (!length(cnt) || any(is.na(cnt))) return(NULL)
  data.frame(count = cnt, value = val, stringsAsFactors = FALSE)
}
# Categorical mini-bars: top N by ACTUAL share of non-missing, plus an "Other" bar for the rest.
cat_bars <- function(enc, n_nonmiss, distinct, topN = 5) {
  tv <- parse_topv(enc)
  if (is.null(tv) || is.na(n_nonmiss) || n_nonmiss <= 0) return("")
  shown <- utils::head(tv, topN)
  bar <- function(v, c) { pc <- 100 * c / n_nonmiss
    sprintf('<div class="catrow"><span class="lbl">%s</span><span class="tk"><span class="fl" style="width:%.1f%%"></span></span><span class="vp">%.1f%%</span></div>',
            esc(v), max(0, min(100, pc)), pc) }
  rows <- vapply(seq_len(nrow(shown)), function(i) bar(shown$value[i], shown$count[i]), character(1))
  other <- n_nonmiss - sum(shown$count)
  if (!is.na(distinct) && distinct > nrow(shown) && other > 0.5) { pc <- 100 * other / n_nonmiss
    rows <- c(rows, sprintf('<div class="catrow"><span class="lbl" style="color:var(--faint)">Other</span><span class="tk"><span class="fl" style="width:%.1f%%;background:var(--faint)"></span></span><span class="vp">%.1f%%</span></div>',
                            max(0, min(100, pc)), pc)) }
  paste0('<div class="cat">', paste(rows, collapse = ""), '</div>')
}
# Categorical values as one line each (appendix summary cell).
cat_lines <- function(enc, n_nonmiss) {
  tv <- parse_topv(enc)
  if (is.null(tv) || is.na(n_nonmiss) || n_nonmiss <= 0) return(NULL)
  sp <- vapply(seq_len(nrow(tv)), function(i)
    sprintf('<span>%s (%s, %.1f%%)</span>', esc(tv$value[i]), fmi(tv$count[i]), 100 * tv$count[i] / n_nonmiss), character(1))
  paste0('<span class="catlines">', paste(sp, collapse = ""), '</span>')
}
# Inline SVG boxplot from min/p25/median/p75/max (styled by CSS classes so palette swaps propagate).
box_svg <- function(mn, q1, md, q3, mx) {
  if (any(is.na(c(mn, q1, md, q3, mx)))) return("")
  L <- 22; W <- 196; span <- mx - mn
  sx <- function(v) if (span > 0) L + (v - mn) / span * W else L + W / 2
  sprintf(paste0('<svg class="box" width="240" height="34" viewBox="0 0 240 34" aria-label="boxplot min %s to max %s">',
    '<line class="bx-axis" x1="%.1f" y1="13" x2="%.1f" y2="13"/>',
    '<line class="bx-whisk" x1="%.1f" y1="8" x2="%.1f" y2="18"/><line class="bx-whisk" x1="%.1f" y1="8" x2="%.1f" y2="18"/>',
    '<rect class="bx-box" x="%.1f" y="5" width="%.1f" height="16" rx="3"/>',
    '<line class="bx-med" x1="%.1f" y1="4" x2="%.1f" y2="22"/>',
    '<text class="bx-lab" x="%.1f" y="32" text-anchor="middle">%s</text>',
    '<text class="bx-lab" x="%.1f" y="32" text-anchor="middle">%s</text></svg>'),
    esc(fmt_num(mn)), esc(fmt_num(mx)), sx(mn), sx(mx), sx(mn), sx(mn), sx(mx), sx(mx),
    sx(q1), max(1, sx(q3) - sx(q1)), sx(md), sx(md), sx(mn), esc(fmt_num(mn)), sx(mx), esc(fmt_num(mx)))
}
num_cell <- function(p) {
  # Surface forced-numeric (DC_KIND_OVERRIDES) coercion failures here, not only in the appendix/TSV — a
  # character/BIGINT measure whose values don't parse as numbers would otherwise look clean (or bare n/a).
  unp <- if (!is.na(p$unparseable) && p$unparseable > 0) sprintf('<div class="warnnote">%s unparseable</div>', fmi(p$unparseable)) else ""
  if (is.na(p$p50)) return(if (nzchar(unp)) sprintf('<div class="cont"><span class="na">n/a — all values failed to parse</span>%s</div>', unp)
                           else '<span class="na">n/a</span>')
  sprintf('<div class="cont"><div class="stat">Median <b>%s</b> · IQR <b>%s–%s</b> · Mean <b>%s</b> · SD <b>%s</b> · Range <b>%s–%s</b></div>%s%s</div>',
    fmt_num(p$p50), fmt_num(p$p25), fmt_num(p$p75), fmt_num(p$mean), fmt_num(p$sd), fmt_num(p$min), fmt_num(p$max),
    box_svg(p$min, p$p25, p$p50, p$p75, p$max), unp)
}
date_cell <- function(p) {
  if (is.na(p$date_min)) return('<span class="na">n/a</span>')
  warn <- if (!is.na(p$unparseable) && p$unparseable > 0) sprintf('<div class="warnnote">%s unparseable</div>', fmi(p$unparseable)) else ""
  sprintf('<div class="dr"><div class="span"><span class="d">%s</span><span class="line"></span><span class="d">%s</span></div>%s</div>',
          esc(p$date_min), esc(p$date_max), warn)
}
dist_cell <- function(p) {
  if (identical(p$kind, "numeric")) num_cell(p)
  else if (identical(p$kind, "date")) date_cell(p)
  else { cb <- cat_bars(p$top_values, p$n_nonmissing, p$distinct)
         if (nzchar(cb)) cb else sprintf('<span class="summ">%s</span>', esc(p$summary)) }
}

# Added / dropped tables and columns vs the baseline feed (the comparison deliverable).
# cur_cols is the FULL current inventory (tablebase|column for every column), so added/dropped stay
# correct even in new_only mode where `results` holds only the profiled (new) subset.
compute_changes <- function(cur_cols) {
  cur_tbls <- unique(sub("\\|.*$", "", cur_cols))
  list(added_tbls = setdiff(cur_tbls, baseline_tbls), dropped_tbls = setdiff(baseline_tbls, cur_tbls),
       added_cols = setdiff(cur_cols, baseline_cols), dropped_cols = setdiff(baseline_cols, cur_cols))
}
# The comparison only sees added/dropped tables and columns — not type, category, missingness or
# distribution shifts. And if this run profiled a subset (DC_TABLES), "dropped" partly reflects
# that subset, not a real feed drop; the two runs should use the same table scope.
changes_caveats <- function() {
  c("Added/dropped only — not type, category, missingness or distribution changes.",
    if (nzchar(tables_env)) "This run profiled a table subset (DC_TABLES), so \"dropped\" may reflect the subset, not a real drop. Compare like-for-like table scope." else NULL)
}
# ---- HTML report: stylesheet (GSK palette — swap the hex values in the :root block) ----
report_css <- '<style>
:root{
  --accent:#C4441C; --accent-bar:#F36633; --accent-soft:#FDE7DD; --accent-ink:#7A2A10;
  --amber:#CA8A04; --amber-soft:#EAB308; --amber-bg:#FEF3C7; --amber-ink:#8A6D09; --fail:#C8102E;
  --ink:#2A1A47; --ink-2:#3F3A4A; --muted:#6B6A78; --faint:#A3A1AD;
  --line:#E7E3EF; --line-2:#D6D1E0; --surface:#FFFFFF; --page:#F2F0F7; --panel:#F8F6FB; --panel-edge:#ECE8F3;
  --neutral-bar:#9AA2B1; --track:#ECEAF2; --newrow:#FEF5F0; --newrow-alt:#FDEEE6; --row-hover:#FAF5F1;
  --mono:ui-monospace,"Cascadia Code","Source Code Pro",Menlo,Consolas,monospace;
  --sans:system-ui,-apple-system,"Segoe UI",Roboto,Helvetica,Arial,sans-serif;
}
*{box-sizing:border-box}
body{font:15px/1.55 var(--sans);color:var(--ink-2);background:var(--page);margin:0;padding:28px}
.sheet{max-width:1180px;margin:0 auto;background:var(--surface);border:1px solid var(--line);border-radius:12px;box-shadow:0 1px 3px rgba(15,23,42,.06);padding:34px 38px 30px}
.eyebrow{font-size:11px;font-weight:700;letter-spacing:.14em;text-transform:uppercase;color:var(--accent);margin:0 0 4px}
h1{font-size:27px;line-height:1.15;font-weight:700;color:var(--ink);margin:0 0 8px;letter-spacing:-.01em}
.runmeta{display:flex;flex-wrap:wrap;gap:6px 14px;font-size:13px;color:var(--muted);margin:0 0 4px}
.runmeta b{color:var(--ink-2);font-weight:600}
.conf{display:inline-block;font-size:10.5px;font-weight:700;letter-spacing:.06em;text-transform:uppercase;color:var(--amber-ink);background:var(--amber-bg);border:1px solid #FCD34D;border-radius:5px;padding:2px 8px;margin-top:6px}
h2{font-size:12px;font-weight:700;letter-spacing:.09em;text-transform:uppercase;color:var(--muted);margin:30px 0 12px;padding-bottom:7px;border-bottom:1px solid var(--line)}
h2 .n{color:var(--accent);margin-left:6px}
.lead-wrap{margin:6px 0 8px}
.lead{font-size:19px;font-weight:700;color:var(--ink);letter-spacing:-.01em;margin:0;display:flex;align-items:baseline;gap:10px;white-space:nowrap}
.lead .count{font-size:13px;font-weight:600;color:#fff;background:var(--accent);border-radius:20px;padding:2px 11px}
.legend{font-size:12px;color:var(--muted);margin:5px 0 0}
.legend .sw{display:inline-block;width:9px;height:9px;border-radius:2px;vertical-align:0;margin:0 3px 0 10px}
.legend .sw:first-child{margin-left:0}
.cards{display:grid;grid-template-columns:repeat(4,1fr);gap:14px;margin:2px 0 4px}
.card{background:var(--panel);border:1px solid var(--panel-edge);border-left:3px solid var(--accent);border-radius:10px;padding:14px 16px}
.card.warn{border-left-color:var(--amber)}
.card .val{font-size:30px;font-weight:700;color:var(--ink);line-height:1.05;letter-spacing:-.02em}
.card.warn .val{color:var(--amber-ink)}
.card .lab{font-size:12.5px;font-weight:600;color:var(--ink-2);margin-top:3px}
.card .sub{font-size:11.5px;color:var(--muted);margin-top:2px}
.table-wrap{width:100%;overflow-x:auto}
table{border-collapse:collapse;width:100%;margin:2px 0 6px;font-size:14px}
thead th{position:sticky;top:0;background:var(--panel);text-align:left;font-weight:600;color:var(--ink-2);font-size:12.5px;padding:9px 12px;border-bottom:2px solid var(--line-2);white-space:nowrap}
th.num,td.num{text-align:right;font-variant-numeric:tabular-nums}
tbody td{padding:9px 12px;border-bottom:1px solid var(--line);vertical-align:middle}
tbody tr:nth-child(even){background:#FBFAFC}
tbody tr:hover{background:var(--row-hover)}
tr.newrow{background:var(--newrow)}
tr.newrow:nth-child(even){background:var(--newrow-alt)}
.col{font-family:var(--mono);font-size:13px;color:var(--ink);font-weight:600;word-break:break-word}
.tbl{font-family:var(--mono);font-size:12.5px;color:var(--muted);word-break:break-word}
td .summ{white-space:normal;word-break:break-word}
.chip{display:inline-block;font-size:11px;font-weight:600;padding:2px 8px;border-radius:20px;white-space:nowrap}
.chip.kind{background:#EEF0F5;color:#4B5563;border:1px solid #E3E1EA}
.chip.alert{background:var(--amber-bg);color:var(--amber-ink);border:1px solid #FCD34D}
.miss{display:flex;align-items:center;gap:9px;min-width:150px}
.miss .bar{flex:1;height:7px;background:var(--track);border-radius:4px;overflow:hidden;max-width:74px}
.miss .fill{display:block;height:100%;border-radius:4px}
.miss .val{font-variant-numeric:tabular-nums;font-size:13px;white-space:nowrap}
.miss .val b{font-weight:600}
.lo .fill{background:var(--neutral-bar)} .lo .val{color:var(--muted)}
.mid .fill{background:var(--amber-soft)} .mid .val b{color:var(--amber-ink)}
.hi .fill{background:var(--amber)} .hi .val b{color:var(--amber-ink)}
.na{color:var(--faint);font-size:13px}
.cat{display:flex;flex-direction:column;gap:3px;min-width:230px}
.catrow{display:grid;grid-template-columns:96px 1fr 46px;align-items:center;gap:8px;font-size:12.5px}
.catrow .lbl{color:var(--ink-2);white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.catrow .tk{height:9px;background:var(--track);border-radius:3px;overflow:hidden}
.catrow .fl{display:block;height:100%;background:var(--accent-bar);border-radius:3px}
.catrow .vp{color:var(--muted);text-align:right;font-variant-numeric:tabular-nums}
.cont{display:flex;flex-direction:column;gap:2px;min-width:250px}
.cont .stat{font-size:12.5px;color:var(--ink-2)}
.cont .stat b{color:var(--ink);font-weight:600}
.cont svg{display:block}
.bx-axis{stroke:#CBC7D6;stroke-width:2}.bx-whisk{stroke:var(--neutral-bar);stroke-width:2}
.bx-box{fill:var(--accent-soft);stroke:var(--accent-bar);stroke-width:1.5}.bx-med{stroke:var(--accent);stroke-width:2.5}
.bx-lab{fill:var(--faint);font-size:9px;font-family:var(--sans)}
.dr{display:flex;flex-direction:column;gap:2px;min-width:230px;font-size:12.5px}
.dr .span{display:flex;align-items:center;gap:8px;color:var(--ink-2)}
.dr .line{flex:1;height:2px;background:linear-gradient(90deg,var(--accent-bar),#FBB89B);border-radius:2px;position:relative}
.dr .line::before,.dr .line::after{content:"";position:absolute;top:-2px;width:6px;height:6px;border-radius:50%;background:var(--accent)}
.dr .line::before{left:0}.dr .line::after{right:0}
.dr .d{font-variant-numeric:tabular-nums;font-weight:600;color:var(--ink)}
.warnnote{color:var(--amber-ink);font-size:12px;margin-top:1px}
.adds{display:grid;grid-template-columns:repeat(2,1fr);gap:8px 26px;margin:2px 0 6px}
.adds .grp{padding:8px 0;break-inside:avoid}
.adds .gt{font-family:var(--mono);font-size:13px;font-weight:600;color:var(--ink)}
.adds .gt .newtab{font-family:var(--sans);font-size:10.5px;font-weight:700;color:#fff;background:var(--accent);border-radius:10px;padding:1px 7px;margin-left:6px;vertical-align:1px}
.adds ul{margin:5px 0 0;padding:0 0 0 4px;list-style:none}
.adds li{font-family:var(--mono);font-size:12.5px;color:var(--ink-2);padding:1px 0}
.adds li .plus{color:var(--accent);font-weight:700;margin-right:6px}
.panel{background:var(--panel);border:1px solid var(--panel-edge);border-radius:10px;padding:14px 18px;font-size:13px;color:var(--muted)}
.panel p{margin:0 0 7px}.panel p:last-child{margin:0}
.panel.removed{color:var(--ink-2)}.panel.removed .rc-cav{color:var(--muted);font-size:12px}
.appendix-note{font-size:13px;color:var(--muted);margin:4px 0 14px}
.appendix h2{color:var(--ink-2)}
.app-table{font-size:12.5px}
.app-table thead th{font-size:11.5px;padding:7px 10px}
.app-table tbody td{padding:6px 10px;vertical-align:top}
.catlines span{display:block}
.foot{display:flex;flex-wrap:wrap;justify-content:space-between;gap:8px;margin-top:26px;padding-top:14px;border-top:1px solid var(--line);font-size:11.5px;color:var(--faint)}
.foot b{color:var(--muted);font-weight:600}
.sr-only{position:absolute;width:1px;height:1px;padding:0;margin:-1px;overflow:hidden;clip:rect(0,0,0,0);white-space:nowrap;border:0}
.printfoot{display:none}
@media (max-width:820px){.cards{grid-template-columns:repeat(2,1fr)}.adds{grid-template-columns:1fr}}
@media print{
  @page{size:A4 landscape;margin:12mm 12mm 15mm}
  *{-webkit-print-color-adjust:exact;print-color-adjust:exact}
  body{background:#fff;padding:0;font-size:10pt}
  .sheet{border:0;box-shadow:none;border-radius:0;max-width:none;padding:0}
  thead{display:table-header-group}
  tr,.card,.adds .grp,.catrow{break-inside:avoid}
  .panel{break-inside:auto}
  h2{margin-top:18px}h2,.lead-wrap{break-after:avoid}
  .schema-section{break-before:page}.appendix{break-before:page}
  .printfoot{display:block;position:fixed;bottom:0;left:0;right:0;font-size:8pt;color:var(--muted);border-top:1px solid var(--line);padding-top:3px;background:#fff}
}
</style>'

# Executive-summary cards. `cards` = list of list(val, lab, sub, warn).
cards_html <- function(cards) paste0('<div class="cards">', paste(vapply(cards, function(c)
  sprintf('<div class="card%s"><div class="val">%s</div><div class="lab">%s</div><div class="sub">%s</div></div>',
    if (isTRUE(c$warn)) " warn" else "", esc(c$val), esc(c$lab), esc(c$sub)), character(1)), collapse = ""), '</div>')

# Schema additions grouped by table (new tables first). ch$added_cols are "tablebase|column".
schema_html <- function(ch) {
  if (!length(ch$added_cols)) return("")
  tb <- sub("\\|.*$", "", ch$added_cols); cl <- sub("^[^|]*\\|", "", ch$added_cols)
  tabs <- unique(tb); tabs <- c(intersect(ch$added_tbls, tabs), setdiff(tabs, ch$added_tbls))
  grp <- vapply(tabs, function(t) {
    lis <- paste(sprintf('<li><span class="plus">+</span>%s</li>', esc(cl[tb == t])), collapse = "")
    nt  <- if (t %in% ch$added_tbls) ' <span class="newtab">new table</span>' else ""
    sprintf('<div class="grp"><div class="gt">%s%s</div><ul>%s</ul></div>', esc(t), nt, lis) }, character(1))
  paste0('<section class="schema-section"><h2>Schema additions <span class="n">· by table</span></h2><div class="adds">',
         paste(grp, collapse = ""), '</div></section>')
}

# "Removed since baseline" — shown only when the baseline had tables/columns absent now.
removed_html <- function(ch) {
  if (!length(ch$dropped_tbls) && !length(ch$dropped_cols)) return("")
  p <- character(0)
  if (length(ch$dropped_tbls)) p <- c(p, sprintf('<p><b>Tables (%d):</b> %s</p>', length(ch$dropped_tbls), esc(paste(ch$dropped_tbls, collapse = ", "))))
  if (length(ch$dropped_cols)) p <- c(p, sprintf('<p><b>Columns (%d):</b> %s</p>', length(ch$dropped_cols), esc(paste(ch$dropped_cols, collapse = ", "))))
  cav <- if (nzchar(tables_env)) '<p class="rc-cav">This run profiled a table subset (DC_TABLES), so a “dropped” item may reflect the subset, not a real drop — compare like-for-like scope.</p>' else ""
  paste0('<h2>Removed since baseline</h2><div class="panel removed">', paste(p, collapse = ""), cav, '</div>')
}

# Tables containing additions (new-only contract: total rows, new-col count, missingness across new cols).
tables_add_html <- function(results, nr, n_assessed) {
  tabs <- unique(nr$.table)
  info <- lapply(tabs, function(t) { sub <- nr[nr$.table == t, ]
    m <- results[[which(vapply(results, function(r) r$meta$table == t, logical(1)))[1]]]$meta
    list(t = t, rows = m$n_rows_total, ncols = nrow(sub), newt = m$new_table, sampled = m$sampled,
         miss = if (sum(sub$n) > 0) 100 * sum(sub$missing) / sum(sub$n) else NA_real_) })
  info <- info[order(-vapply(info, function(x) if (is.na(x$miss)) -1 else x$miss, numeric(1)))]
  tr <- vapply(info, function(x) sprintf(
    '<tr><td class="tbl">%s%s</td><td class="num">%s</td><td class="num">%d</td><td>%s</td><td>%s</td></tr>',
    esc(disp_tbl(x$t)), if (isTRUE(x$newt)) ' <span class="chip kind">new</span>' else "", fmi(x$rows), x$ncols,
    miss_rate_cell(x$miss), if (isTRUE(x$sampled)) '<span class="chip kind">Sampled</span>' else '<span class="chip kind">Exact</span>'), character(1))
  paste0('<h2>Tables containing additions <span class="n">· ', length(tabs), ' of ', n_assessed,
    '</span></h2><div class="table-wrap"><table><caption class="sr-only">Tables containing schema additions</caption>',
    '<thead><tr><th>Table</th><th class="num">Total rows</th><th class="num">New cols</th><th>Missingness across new columns</th><th>Coverage</th></tr></thead><tbody>',
    paste(tr, collapse = ""), '</tbody></table></div>')
}

# Per-table overview for a full profile: one row per table with its size and overall missingness,
# so the report actually lists the tables (with row and column counts), not just the totals in the
# summary cards. Sorted largest-first. Every value is read from the same meta, so it can't drift.
tables_overview_html <- function(results) {
  metas <- lapply(results, function(r) r$meta)
  metas <- metas[order(-vapply(metas, function(m) as.numeric(m$n_rows_total), numeric(1)))]
  tr <- vapply(metas, function(m) sprintf(
    '<tr><td class="tbl">%s%s</td><td class="num">%s</td><td class="num">%d</td><td>%s</td><td>%s</td></tr>',
    esc(disp_tbl(m$table)), if (isTRUE(m$new_table)) ' <span class="chip kind">new</span>' else "",
    fmi(m$n_rows_total), as.integer(m$n_cols), miss_rate_cell(m$pct_cells_missing),
    if (isTRUE(m$sampled)) sprintf('<span class="chip kind">Sampled ~%s</span>', fmi(m$n_rows_profiled))
    else '<span class="chip kind">Exact</span>'), character(1))
  paste0('<h2>Tables profiled <span class="n">· ', length(results), '</span></h2>',
    '<div class="table-wrap"><table><caption class="sr-only">Tables profiled — rows, columns and cell missingness</caption>',
    '<thead><tr><th>Table</th><th class="num">Rows</th><th class="num">Columns</th><th>Cells missing</th><th>Coverage</th></tr></thead><tbody>',
    paste(tr, collapse = ""), '</tbody></table></div>')
}

method_notes_html <- paste0('<h2>Method &amp; interpretation notes</h2><div class="panel">',
  '<p><b>New = schema-new</b> — present now, absent from the baseline; a rename = one drop + one add; a re-derived or newly-populated existing column is not flagged.</p>',
  '<p><b>Counts</b> — Rows = total profiled rows at the table’s grain (not unique patients); Missing % = missing ÷ rows; category shares are of non-missing rows.</p>',
  '<p><b>Missingness bands</b> — display cues (&lt;5% neutral · 5–20% gold · &gt;20% deep gold), not pass/fail; expected for conditionally-recorded fields. Red = failed QC only.</p>',
  '<p><b>Before distribution</b> — reconcile inferred kinds and cues against the product data dictionary.</p></div>')

# Technical appendix: every profiled column (new-columns-only in that mode), with a Table column.
appendix_html <- function(results) {
  allr <- bind_rows(lapply(results, function(r) r$prof %>% mutate(.table = r$meta$table)))
  if (!nrow(allr)) return("")
  tr <- vapply(seq_len(nrow(allr)), function(i) { p <- allr[i, ]
    summ <- if (identical(p$kind, "categorical")) { cl <- cat_lines(p$top_values, p$n_nonmissing); if (!is.null(cl)) cl else esc(p$summary) } else esc(p$summary)
    sprintf('<tr class="%s"><td class="tbl">%s</td><td class="col">%s</td><td>%s</td><td class="num">%s</td><td class="num">%s</td><td class="num">%s</td><td class="num">%s</td><td class="num">%s</td><td>%s</td></tr>',
      if (isTRUE(as.logical(p$new))) "newrow" else "", esc(disp_tbl(p$.table)), esc(p$column), esc(p$kind),
      fmi(p$n), fmi(p$n_nonmissing), fmi(p$distinct), fmi(p$missing), pctfmt(p$pct_missing), summ) }, character(1))
  fn <- if (identical(profile_mode, "new-columns-only")) sprintf("profile_new_%s.tsv", cut_filter)
        else sprintf("profile_%s.tsv", if (nzchar(cut_filter)) cut_filter else "all")
  partial <- if (identical(profile_mode, "new-columns-only")) " It is a <b>partial</b> profile (new columns only) and must not be used as a temporal-drift input." else ""
  paste0('<div class="appendix"><h2>Technical appendix <span class="n">· columns profiled in this run</span></h2>',
    sprintf('<p class="appendix-note">Full per-column detail for the columns read this run. The machine-readable <span class="tbl">%s</span> carries the complete metrics, including the p1–p99 quantile grid.%s</p>', fn, partial),
    '<div class="table-wrap"><table class="app-table"><caption class="sr-only">Technical appendix — per-column profile</caption>',
    '<thead><tr><th>Table</th><th>Column</th><th>Kind</th><th class="num">Rows</th><th class="num">Nonmissing</th><th class="num">Distinct</th><th class="num">Missing</th><th class="num">% miss</th><th>Summary</th></tr></thead><tbody>',
    paste(tr, collapse = ""), '</tbody></table></div></div>')
}
render_changes_md <- function(ch) {
  it <- function(lab, v) sprintf("- **%s (%d):** %s", lab, length(v), if (length(v)) paste(v, collapse = ", ") else "—")
  paste(c("\n## Changes vs baseline\n", it("Added tables", ch$added_tbls), it("Dropped tables", ch$dropped_tbls),
    it("Added columns", ch$added_cols), it("Dropped columns", ch$dropped_cols),
    paste0("\n_", changes_caveats(), "_")), collapse = "\n")
}

# The focused answer to the new-variables ask: one compact table of the NEW variables (schema-new vs the
# baseline) with row denominator, missing count/%, and a distribution summary. Leads the report.
new_vars_df <- function(results) {
  do.call(rbind, c(list(NULL), lapply(results, function(r) {
    idx <- which(as.logical(r$prof$new))
    if (!length(idx)) return(NULL)
    data.frame(table = r$meta$table, column = r$prof$column[idx], kind = r$prof$kind[idx],
               n = r$prof$n[idx], missing = r$prof$missing[idx], pct = r$prof$pct_missing[idx],
               summary = r$prof$summary[idx], stringsAsFactors = FALSE)
  })))
}
new_vars_caveat <- paste0("New = schema-new (present now, absent from the baseline inventory): a rename shows as one ",
  "dropped + one added, and a changed derivation or a newly-populated existing column is NOT flagged. ",
  "n = table rows profiled (episode-level or patient-level per the table's grain), not unique patients; ",
  "category percentages are of non-missing rows.")
# All new-variable profile rows (every field), tagged with their table — the full object the
# principal HTML table and its cards read from (unlike new_vars_df, which keeps only 7 columns for MD).
new_rows <- function(results) {
  bind_rows(lapply(results, function(r) { idx <- which(as.logical(r$prof$new))
    if (!length(idx)) return(NULL)
    r$prof[idx, , drop = FALSE] %>% mutate(.table = r$meta$table) }))
}
# Principal result: the "New variables" table, priority-sorted (unparseable, then high missingness),
# with the small categorical/date/numeric visuals and a missing count + %.
render_new_vars_html <- function(nr) {
  lead <- function(nrow_) paste0('<div class="lead-wrap"><p class="lead">New variables <span class="count">', nrow_,
    '</span></p><p class="legend">Missingness display cue:',
    '<span class="sw" style="background:var(--neutral-bar)"></span>&lt;5%',
    '<span class="sw" style="background:var(--amber-soft)"></span>5–20%',
    '<span class="sw" style="background:var(--amber)"></span>&gt;20% review &nbsp;· sorted by review priority</p></div>')
  if (is.null(nr) || !nrow(nr)) return(paste0('<div class="lead-wrap"><p class="lead">New variables <span class="count">0</span></p></div><p class="na">None vs baseline.</p>'))
  pm  <- ifelse(is.na(nr$pct_missing), -1, nr$pct_missing)
  unp <- ifelse(is.na(nr$unparseable), 0, nr$unparseable) > 0
  nr  <- nr[order(-as.integer(unp), -pm, nr$.table, nr$column), , drop = FALSE]
  tr  <- vapply(seq_len(nrow(nr)), function(i) { p <- nr[i, ]
    sprintf('<tr class="newrow"><td class="col">%s</td><td class="tbl">%s</td><td>%s%s</td><td class="num">%s</td><td>%s</td><td>%s</td></tr>',
      esc(p$column), esc(disp_tbl(p$.table)), kind_chip(p$kind), alert_chip(p$pct_missing),
      fmi(p$n), miss_cell(p$pct_missing, p$missing), dist_cell(p)) }, character(1))
  paste0(lead(nrow(nr)), '<div class="table-wrap"><table>',
    '<caption class="sr-only">New variables — distribution and missingness</caption>',
    '<thead><tr><th>New variable</th><th>Table</th><th>Kind</th><th class="num">Rows</th><th>Missing</th><th>Distribution</th></tr></thead><tbody>',
    paste(tr, collapse = ""), '</tbody></table></div>')
}
render_new_vars_md <- function(results) {
  d <- new_vars_df(results)
  if (is.null(d) || !nrow(d)) return("\n## New variables\n\n_None vs baseline._\n")
  rows <- apply(d, 1, function(t) sprintf("| %s | %s | %s | %s | %s | %s | %s |",
    t[["table"]], t[["column"]], t[["kind"]], fmi(as.numeric(t[["n"]])), fmi(as.numeric(t[["missing"]])),
    pctfmt(as.numeric(t[["pct"]])), gsub("|", "\\|", t[["summary"]], fixed = TRUE)))
  paste(c(sprintf("\n## New variables (%d)\n", nrow(d)),
    "| table | new variable | kind | n | missing | % missing | distribution |",
    "|---|---|---|---:|---:|---:|---|", rows, paste0("\n_", new_vars_caveat, "_")), collapse = "\n")
}

render_html <- function(results, gen_time, cur_inv) {
  n_assessed <- length(unique(sub("\\|.*$", "", cur_inv)))
  # Label coverage from whether any table was ACTUALLY sampled (meta$sampled = n_rows > sample_n), not from
  # the DC_SAMPLE_N config: if the threshold sits above every table's row count, all rows are read, so
  # calling it "sampled" would mislead. Exact per-table coverage is in the tables section.
  any_sampled <- any(vapply(results, function(r) isTRUE(r$meta$sampled), logical(1)))
  cov_txt <- if (any_sampled) sprintf("sampled ~%s rows/table (tables above the threshold)", fmi(sample_n))
             else if (identical(profile_mode, "new-columns-only")) "exact — all rows, selected columns"
             else "exact — all rows"
  runmeta <- paste0('<div class="runmeta">',
    sprintf('<span>source <b>%s</b></span>', esc(source_label)),
    if (nzchar(cut_filter)) sprintf('<span>cut <b>%s</b></span>', esc(cut_filter)) else "",
    if (nzchar(baseline_file)) sprintf('<span>baseline <b>%s</b></span>', esc(basename(baseline_file))) else "",
    sprintf('<span>mode <b>%s</b></span>', esc(profile_mode)),
    sprintf('<span>coverage <b>%s</b></span>', esc(cov_txt)),
    if (have_baseline) sprintf('<span><b>%d</b> tables assessed for schema changes</span>', n_assessed)
    else sprintf('<span><b>%d</b> tables profiled</span>', length(results)),
    sprintf('<span>generated <b>%s</b></span>', esc(gen_time)), '</div>')
  conf <- sprintf('<span class="conf">Restricted RWD output%s</span>', if (nzchar(cut_filter)) paste0(" · ", esc(cut_filter)) else "")
  h1   <- paste0(if (have_baseline) "New-variable review" else "Data characterization",
                 if (nzchar(cut_filter)) paste0(" — ", esc(cut_filter)) else "")
  ident <- paste0(esc(source_label), if (nzchar(cut_filter)) paste0(" · ", esc(cut_filter)) else "",
                  " · generated ", esc(gen_time))
  foot <- sprintf('<div class="foot"><span><b>%s</b>%s%s</span><span>Restricted RWD output · generated %s</span></div>',
    esc(source_label), if (nzchar(cut_filter)) paste0(" · cut ", esc(cut_filter)) else "",
    if (nzchar(baseline_file)) paste0(" · baseline ", esc(basename(baseline_file))) else "", esc(gen_time))
  printfoot <- sprintf('<div class="printfoot">Restricted RWD output · %s</div>', ident)

  body <- if (have_baseline) {
    nr <- new_rows(results); ch <- compute_changes(cur_inv)
    n_himiss <- sum(!is.na(nr$pct_missing) & nr$pct_missing > 20)
    cards <- list(
      list(val = nrow(nr),                  lab = "New variables",           sub = "schema-new vs baseline"),
      list(val = length(ch$added_tbls),     lab = "New tables",              sub = "every column is new"),
      list(val = n_himiss,                  lab = "High-missingness review", sub = "new vars > 20% · display cue, not QC", warn = TRUE),
      list(val = length(unique(nr$.table)), lab = "Tables with additions",   sub = sprintf("of %d assessed", n_assessed)))
    paste0('<h2>Executive summary</h2>', cards_html(cards),
      render_new_vars_html(nr), schema_html(ch), removed_html(ch),
      tables_add_html(results, nr, n_assessed), method_notes_html, appendix_html(results))
  } else {
    tot_cols <- sum(vapply(results, function(r) as.integer(r$meta$n_cols), integer(1)))
    cards <- list(
      list(val = length(results), lab = "Tables profiled", sub = if (any_sampled) "sampled" else "exact"),
      list(val = tot_cols,        lab = "Columns",         sub = "across all tables"),
      list(val = if (any_sampled) "Sampled" else "Exact", lab = "Coverage", sub = "profiling mode"))
    paste0('<h2>Executive summary</h2>', cards_html(cards),
      tables_overview_html(results), method_notes_html, appendix_html(results))
  }

  paste0('<!doctype html><html lang="en"><head><meta charset="utf-8">',
    '<meta name="viewport" content="width=device-width, initial-scale=1">',
    sprintf('<title>%s%s</title>', esc(source_label), if (nzchar(cut_filter)) paste0(" — ", esc(cut_filter)) else ""),
    report_css, '</head><body><div class="sheet">',
    '<p class="eyebrow">Data characterization</p>', sprintf('<h1>%s</h1>', h1), runmeta, conf,
    body, foot, '</div>', printfoot, '</body></html>')
}

render_md <- function(results, gen_time, cur_inv) {
  any_sampled <- any(vapply(results, function(r) isTRUE(r$meta$sampled), logical(1)))  # actual, not the DC_SAMPLE_N config
  head <- sprintf("# Data characterization\n\n%s — %d tables — generated %s\n\nmode: %s · cut: %s · baseline: %s · %s · scope: %s · new-column flag: %s.\n\nsettings: %s\n",
                  source_label, length(results), gen_time, profile_mode,
                  if (nzchar(cut_filter)) cut_filter else "all",
                  if (nzchar(baseline_file)) basename(baseline_file) else "none",
                  if (any_sampled) sprintf("sampling: ~%s rows/table (TABLESAMPLE, approximate)", fmi(sample_n)) else "exact (all rows)",
                  if (nzchar(tables_env)) "DC_TABLES subset" else "all tables", new_detection, settings_txt)
  ov <- c("\n## Overview\n", "| table | rows | cols | % cells missing | coverage |",
          "|---|---:|---:|---:|---|",
          unlist(lapply(results, function(r) with(r$meta, sprintf("| %s%s | %s | %d | %s | %s |",
            table, if (new_table) " (new)" else "", fmi(n_rows_total), n_cols,
            pctfmt(pct_cells_missing), if (sampled) sprintf("sampled %s", fmi(n_rows_profiled)) else "full")))))
  secs <- unlist(lapply(results, function(r) {
    rows <- apply(r$prof, 1, function(p) sprintf("| %s%s | %s | %s | %s | %s (%s) | %s |",
      p[["column"]], if (as.logical(p[["new"]])) " (new)" else "", p[["kind"]],
      fmi(as.numeric(p[["n"]])), fmi(as.integer(p[["distinct"]])),
      pctfmt(as.numeric(p[["pct_missing"]])), fmi(as.numeric(p[["missing"]])),
      gsub("|", "\\|", p[["summary"]], fixed = TRUE)))
    caveat <- if (r$meta$sampled) sprintf(
      "\n_Estimated from a reproducible random sample of ~%s rows; metrics approximate. Set DC_SAMPLE_N=0 for exact._\n",
      fmi(r$meta$n_rows_profiled)) else ""
    c(sprintf("\n## %s%s\n%s", r$meta$table, if (r$meta$new_table) " (new)" else "", caveat),
      "| column | kind | n | distinct | % missing (count) | distribution |", "|---|---|---:|---:|---:|---|", rows)
  }))
  nv  <- if (have_baseline) render_new_vars_md(results) else NULL
  chg <- if (have_baseline) render_changes_md(compute_changes(cur_inv)) else NULL
  paste(c(head, nv, chg, ov, secs), collapse = "\n")
}

# ---- run ----
run <- function() {
  # Each tumor/product lives in its own catalog + schema, so a blank one would profile the wrong
  # feed. Fail loud if the CONFIG block (or a DC_* override) left them empty.
  if (source_mode == "dbi" && (!nzchar(catalog) || !nzchar(schema)))
    stop("catalog/schema are empty — set them in the CONFIG block at the top of this script ",
         "(or via DC_CATALOG / DC_SCHEMA). They differ per tumor/product.")
  if (require_baseline && !have_baseline)
    stop("DC_REQUIRE_BASELINE is set but no DC_BASELINE_COLS was given — formal old->new mode needs the prior inventory.")
  if (require_baseline && !nzchar(cut_filter))
    stop("DC_REQUIRE_BASELINE is set but DC_CUT is empty — a schema can hold several snapshots, so formal mode must fix the cut.")
  con <- if (source_mode == "dbi") get_con() else NULL
  tables <- if (nzchar(tables_env)) str_split(str_trim(tables_env), "\\s*,\\s*")[[1]]
            else if (source_mode == "dbi") list_tables(con)
            else stop("DC_SOURCE_MODE=local needs DC_TABLES set.")
  if (nzchar(cut_filter)) {
    pat <- if (nzchar(cut_table_regex)) cut_table_regex else paste0("_", cut_filter, "$")
    tables <- tables[grepl(pat, str_to_lower(tables))]
  }
  if (!length(tables)) stop(sprintf("no tables to profile%s",
    if (nzchar(cut_filter)) paste0(" for cut '", cut_filter, "'") else ""))
  message(sprintf("target: %s — %d table(s) [%s]", source_label, length(tables), profile_mode))

  # Overwrite-safe outputs: a per-snapshot subfolder AND a snapshot-stamped filename, so profiling a
  # new drop can never clobber a previous drop's files (rerunning the SAME cut still overwrites — for
  # an immutable archive point DC_OUT_DIR at a unique per-run directory).
  stamp   <- if (nzchar(cut_filter)) paste0("_", cut_filter) else ""
  run_dir <- if (nzchar(cut_filter)) file.path(out_dir, cut_filter) else out_dir
  dir.create(run_dir, showWarnings = FALSE, recursive = TRUE)
  outp <- function(name, ext) file.path(run_dir, sprintf("%s%s.%s", name, stamp, ext))

  # One pass. Always collect every current column name (cheap, no data read). Then, unless
  # inventory-only, profile the columns needed: new_only reads data for the ADDED columns only
  # (the focused answer to the new-variables ask); full mode reads every column.
  gen_time <- format(Sys.time(), "%Y-%m-%d %H:%M")
  results <- list(); schema_cols <- list()
  for (tbl in tables) {
    if (source_mode == "local") { df_all <- load_local(tbl); all_cols <- names(df_all)
                                  n_total <- nrow(df_all); sampled <- FALSE }
    else all_cols <- table_columns(con, tbl)
    schema_cols[[tbl]] <- all_cols
    if (inventory_only) next
    prof_cols <- if (new_only && have_baseline && !is_new_table(tbl))
                   all_cols[vapply(all_cols, function(cc) is_new_col(tbl, cc), logical(1))]
                 else all_cols
    if (new_only && !length(prof_cols)) { message(sprintf("  %s: no new columns, skipped", tbl)); next }
    message(sprintf("profiling %s (%d col%s) ...", tbl, length(prof_cols), if (length(prof_cols) == 1) "" else "s"))
    if (source_mode == "local") df <- df_all[, prof_cols, drop = FALSE]
    else if (sample_n > 0) { n_total <- row_count(con, tbl); sampled <- n_total > sample_n
                             df <- load_dbi(con, tbl, n_total, cols = prof_cols) }
    else { sampled <- FALSE; df <- load_dbi(con, tbl, 0L, cols = prof_cols); n_total <- nrow(df) }  # exact: n IS nrow(df) — skip the redundant COUNT(*)
    results[[tbl]] <- profile_table(df, tbl, n_total, sampled)
  }

  # inventory.txt = ALL current columns (so the next drop's baseline is complete even in new_only mode).
  cur_inv <- sort(unique(unlist(lapply(names(schema_cols), function(t)
    paste(base_name(t), tolower(schema_cols[[t]]), sep = "|")))))
  # Provenance header (read back and verified when this file is later fed as a baseline).
  inv_header <- c("# data_profiler inventory",
    sprintf("# catalog=%s", catalog), sprintf("# schema=%s", schema),
    if (nzchar(product_id)) sprintf("# product=%s", product_id) else NULL,
    sprintf("# cut=%s", if (nzchar(cut_filter)) cut_filter else "all"),
    sprintf("# scope=%s", if (nzchar(tables_env)) tables_env else "all"),
    sprintf("# cut_regex=%s", cut_regex),
    sprintf("# cut_filter_regex=%s", if (nzchar(cut_table_regex)) cut_table_regex else "default"),
    sprintf("# generated=%s", gen_time))
  writeLines(c(inv_header, cur_inv), outp("inventory", "txt"))
  if (inventory_only) {
    message(sprintf("inventory-only: wrote %s (%d columns%s)", outp("inventory", "txt"), length(cur_inv),
                    if (source_mode == "dbi") ", no data read" else " — local mode read the extract to list columns"))
    return(invisible(cur_inv))
  }
  # catalogue.txt = THIS drop's columns plus whatever baseline was fed in (NOT a cross-drop running list).
  writeLines(sort(unique(c(baseline_cols, cur_inv))), outp("catalogue", "txt"))
  writeLines(render_html(results, gen_time, cur_inv), outp("data_characterization", "html"))
  writeLines(render_md(results, gen_time, cur_inv),   outp("data_characterization", "md"))
  # Machine-readable per-column metrics. In new_only mode this is a PARTIAL profile (added columns only),
  # so name it profile_new_<cut>.tsv — it is NOT a complete input for compare_snapshots.R drift.
  tsv_name <- if (new_only && have_baseline) "profile_new" else "profile"
  write.table(profile_tsv_df(results), outp(tsv_name, "tsv"),
              sep = "\t", row.names = FALSE, quote = FALSE, na = "")
  message(sprintf("wrote report + inventory/catalogue/%s%s.* to %s", tsv_name, stamp, run_dir))
  invisible(results)
}
if (!nzchar(Sys.getenv("DC_DEFINE_ONLY"))) run()
