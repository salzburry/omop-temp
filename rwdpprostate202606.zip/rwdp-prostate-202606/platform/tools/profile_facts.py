#!/usr/bin/env python3
"""Profile FACTS reporter — deterministic, read-only.

Reads a product's config `sources:` map + a data_profiler.R `profile_<cut>.tsv` and writes
PROFILE_FACTS_<cut>.md next to the TSV: per-source metrics + a few mechanical notes. Every number is
copied from the TSV; nothing is inferred.

IT DOES NOT: edit the handoff, flip any status, approve a source, or decide a rule.
It reports facts; RWP reviews them and updates the YAML/status BY HAND.

  python3 profile_facts.py <product_dir> <profile_tsv> [--out FILE]

Required TSV columns (data_profiler.R contract): table, table_base, column, kind, sampled, n_rows,
n_rows_total, pct_missing, distinct, date_min, date_max, top_values.

Honest limits: per-column metrics only — it can't establish composite grain, duplicates, join
coverage, same-day ties or window coverage (those need targeted RWP queries). Sources are resolved
through the engine Config loader (same as the build + schema validator), so a data-format overlay
(e.g. a Panoramic rename) applies; for an EDM product this equals the raw `sources:` block.
"""
import sys, os, html, argparse

# This file carried a 17-line marker walk-up to find `platform/tools`. It needed that when it lived
# in a product pack and could not know how deep the pack sat. It lives IN platform/tools now, so its
# own directory IS the answer — the walk searched for the folder it was already in. Same two lines
# every other tool here uses (source_check.py:83 and :156).
#
# The SHARED profiler reader — one parser for one format. This file's own copy was the strictest of
# the three, so it became the shared one and the other two adopted its validation, rather than the
# repo continuing to accept whatever the weakest reader tolerated.
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from profile_io import TRUE, num, load  # noqa: E402
from source_check import config_base  # noqa: E402 — ONE physical-table resolver, shared with Gate 3


def sampling_status(tables):
    """Primary signal: the profiler's per-table `sampled` flag; n_rows<n_rows_total is a consistency check."""
    sampled = False
    for cols in tables.values():
        for m in cols.values():
            if (m.get('sampled') or '').strip().upper() in TRUE:
                sampled = True
            nt, nr = num(m.get('n_rows_total')), num(m.get('n_rows'))
            if nt is not None and nr is not None and nr < nt:
                sampled = True
    return "SAMPLED_METRICS — SCREENING ONLY (can miss rare values)" if sampled else "EXACT_METRICS (full-table counts)"


def resolve(stem, bases):
    if stem in bases:
        return stem, []
    toks = stem.split('_')[:3]
    return None, [b for b in sorted(bases) if b.split('_')[:3] == toks and b != stem][:3]


def render_value(m):
    if m.get('kind') == 'date':
        dmin, dmax = (m.get('date_min') or '').strip(), (m.get('date_max') or '').strip()
        return f"{dmin} .. {dmax}" if (dmin or dmax) else "n/a"       # zero-row date column -> n/a
    toks = (m.get('top_values') or '').split('|')[:8]        # `count:value` items; value is pipe-free
    return '<br>'.join(html.escape(t) for t in toks)         # escape <, >, & AND the split pipes


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('product_dir')
    ap.add_argument('profile_tsv')
    ap.add_argument('--out')
    ap.add_argument('--strict', action='store_true',
                    help='exit non-zero if any configured source is missing (partial-scope profile)')
    a = ap.parse_args()

    fn = os.path.basename(a.profile_tsv)
    if 'profile_new' in fn or 'inventory' in fn:
        sys.exit(f"ERROR: {fn} looks PARTIAL (new-only / inventory). Use a full-scope profile_<cut>.tsv "
                 "over ALL configured sources (sampling is fine for screening; targeted exact runs are for final checks).")

    # Resolve sources through the ENGINE Config loader (like the build + schema validator) so the active
    # data-format overlay applies — a Panoramic rename overlay changes the physical stems, and reading the
    # raw `sources:` block would then compare the profile against stale EDM stems. For an EDM product this
    # is identical to the raw block.
    sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    from engine.config import load_config
    cfg = load_config(os.path.join(a.product_dir, 'config', 'data_product.yaml'))
    root = cfg.raw
    sources = cfg.sources
    tables, cuts = load(a.profile_tsv)          # the shared loader rejects a mixed-cut file
    cut = next(iter(cuts)) if cuts else None
    status = sampling_status(tables)
    spec_ver = str(root.get('version', '')).split('{snapshot}')[0].rstrip('._-/ ') or '?'
    tbset = set(tables)

    per, notes, found = [], [], 0
    for logical, stem in sorted(sources.items()):
        # Resolve through the active vendor layout, exactly as Gate 3 does. Comparing the
        # configured stem meant a custom layout (`pre_{stem}_{refresh}`) had Gate 3 finding
        # the table while this report told a person it was missing.
        tb, sugg = resolve(config_base(cfg, logical), tbset)
        if tb:
            found += 1
            per.append(f"\n### ✓ table stem matched · `{logical}` → `{tb}`")
            per.append("| column | kind | null% | distinct | values / date range |")
            per.append("|---|---|---|---|---|")
            for m in tables[tb].values():
                pmv = (m.get('pct_missing') or '').strip()
                per.append(f"| `{m.get('column', '')}` | {m.get('kind', '')} | {pmv + '%' if pmv else 'n/a'} "
                           f"| {m.get('distinct', '')} | {render_value(m)} |")
        else:
            hint = f" — same-prefix tables present: {', '.join('`' + s + '`' for s in sugg)}" if sugg else ""
            per.append(f"\n### ✗ `{logical}` → config stem `{stem}` NOT FOUND{hint}")
            notes.append(f"TABLE NOT FOUND: `{logical}` stem `{stem}` absent from this profile."
                         + (f" Same-prefix tables present: {', '.join(sugg)}." if sugg else ""))

    total = len(sources)
    partial = bool(total and found < total)
    scope = "PARTIAL CONFIGURED-TABLE SCOPE" if partial else "FULL CONFIGURED-TABLE SCOPE"
    guard = []
    if total and found / total < 0.3:
        guard.append(f"⚠ ONLY {found}/{total} configured source stems matched — wrong product / cut, or a "
                     "partial (subset) profile? Treat every 'not found' below as UNKNOWN, not absent.")
    elif partial:
        guard.append(f"⚠ PARTIAL CONFIGURED-TABLE SCOPE — {found}/{total} configured source stems present. "
                     "This is a SUBSET profile (e.g. separate one-table runs); missing stems are listed under "
                     "Notes. Do NOT read a missing stem as a finding, and do NOT accept the product on this "
                     "profile — re-run over ALL configured sources in one job.")

    out = [f"# Profile FACTS — {fn}\n",
           "_Read-only, deterministic. RWP reviews these facts and updates the YAML / handoff status "
           "BY HAND. This tool never edits the handoff or approves a source._\n",
           f"- **Product:** {root.get('data_product_id', '?')}",
           f"- **Spec version:** {spec_ver} · **data cut:** {cut or 'unknown'} · input `{fn}`",
           f"- **Metric coverage:** {status}",
           f"- **Table scope:** {scope} ({found}/{total} configured table stems present — stem presence ONLY, not column/grain/join/approval coverage)",
           "- **Source approval:** not assessed by this tool",
           f"- **Sources matched:** {found}/{total} · notes: {len(notes)}", ""]
    out += [f"> {g}" for g in guard]
    out += ["\n## Notes (mechanical — a human decides if they matter)\n"]
    out += [f"- {n}" for n in notes] or ["- none"]
    out += per

    name = f"PROFILE_FACTS_{cut}.md" if cut else "PROFILE_FACTS.md"
    dest = a.out or os.path.join(os.path.dirname(os.path.abspath(a.profile_tsv)), name)
    with open(dest, 'w', encoding='utf-8') as fh:
        fh.write("\n".join(out) + "\n")
    print(f"wrote {dest}  ({found}/{total} sources, {len(notes)} notes, coverage={status.split()[0]}, scope={scope})")
    if a.strict and partial:
        sys.exit(f"ERROR (--strict): PARTIAL CONFIGURED-TABLE SCOPE — only {found}/{total} configured source "
                 "stems present. Re-run over all configured sources in one job, or drop --strict.")


if __name__ == '__main__':
    main()
