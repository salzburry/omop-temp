#!/usr/bin/env python3
"""One governed stage, as a page a person can look at.

    python3 platform/tools/render_html.py worksheet <pack> --out ~/rwdp-views/worksheet.html
    python3 platform/tools/render_html.py --list

A VIEW, and nothing else. Every number on the page comes from the stage tool that already owns it —
this module holds no counts, no thresholds and no rules, and adding one here would put a second
answer on the screen next to the one CI checks. The stage tools stay the authority; a page that
disagreed with `worksheet.py` would be believed, because it is the one with the colours.

WHY IT WRITES OUTSIDE THE CHECKOUT. `repo_hygiene.NEVER_COMMITTED` refuses `*.html`: a saved page is
the shape a vendor documentation portal gets captured in, and the rule says in as many words that a
generated report belongs in the restricted output directory. `--out` is therefore required and
refused inside the repository, through `pack_run.restricted_dir` — the same guard the profiler uses,
not a second copy of it.

WHAT MAY BE RENDERED. Only stages whose content is SPONSOR-SIDE. The worksheet reads contract
records, the decisions register and config block names; none of that is vendor-derived. A profile
TSV, a schema report or a source verdict's table listing carries delivered column values and
physical vendor table names, and rendering one would put restricted output into a file whose whole
purpose is to be opened and shared. `STAGES` is an allowlist for that reason, and
`test_render_html` asserts this module reaches no restricted reader.

Stdlib only. Not deployed: `deploy_tree.runtime_tools` derives the production tool set from what
`platform/databricks/` imports, and nothing there imports this.
"""
import argparse
import html
import json
import os
import sys

TOOLS = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(os.path.dirname(TOOLS))
sys.path.insert(0, TOOLS)

import pack_run                                                      # noqa: E402 — ONE outside-the-checkout guard
import worksheet                                                     # noqa: E402
from engine.config import (delivery_bindings as _delivery_bindings,  # noqa: E402 — ONE delivery vocabulary
                           merged_raw as _merged_raw)


def _e(s):
    return html.escape(str(s if s is not None else ""), quote=True)


# ---------------------------------------------------------------------------------------------
# Stage builders. Each returns (title, subtitle, [section]) and derives NOTHING — it reshapes what
# a stage tool already computed into blocks the page knows how to draw.
# ---------------------------------------------------------------------------------------------

def _worksheet(pack, evidence=None):     # evidence is a Gate 5 artefact; this stage has none
    """Gate 4 preparation: what to answer, what to paste, what is unaccounted for.

    Straight off `worksheet.model`, which is where the ranking lives. Re-sorting here would be a
    second opinion about which decision matters most, and this is the copy with the colours on it.
    """
    m = worksheet.model(pack)
    if m is None:
        return None, worksheet.not_started(pack), []

    # The four headline numbers, in the order the text worksheet states them.
    stats = [("contract records", m["records"], f"over {m['domains']} domain(s)"),
             ("produce output", m["produces"], "records that emit an ADS column"),
             ("config blocks claimed", f"{m['claimed']}/{m['blocks']}", "by some contract record"),
             ("records blocked", len(m["blocked_records"]), "waiting on a human decision")]

    notes = []
    if m["items"] is not None:
        undisp = m["undispositioned"]
        notes.append((f"{m['mapped']} of {m['items']} spec items are in the contract"
                      + (f" — {undisp} UNDISPOSITIONED" if undisp else ""),
                      "The three lists below cover only the part of the specification already "
                      "drafted into records. Spec rows nothing has looked at are absent from them, "
                      "so a short list here is not evidence of a small amount of remaining work."
                      if undisp else
                      "Every spec row has been dispositioned, so the lists below are complete over "
                      "the whole specification."))
    if m["pending_mapping"]:
        notes.append((f"{m['pending_mapping']} records carry an unconfirmed source mapping",
                      "A human confirms a column is the RIGHT column at Gate 3, against a "
                      "profile. Until then the mapping is a proposal."))

    sections = [{"kind": "stats", "stats": stats, "notes": notes}]

    # 1 — decisions, ranked by blast radius.
    if not m["decisions"] and not m["register"]:
        body = {"kind": "empty", "text": f"This pack keeps no decisions register — "
                                         f"{worksheet.NOTHING_TO_CHECK}."}
    elif not m["decisions"]:
        body = {"kind": "empty",
                "text": f"No open decision is blocking a record ({m['register']} in the register)."}
    else:
        body = {"kind": "decisions", "rows": m["decisions"], "top": worksheet.TOP_DECISIONS,
                "idle": m["idle"]}
    sections.append({"kind": "section", "n": 1, "title": "Answer these",
                     "lede": "Ranked by how many records each one unblocks. One answer can free "
                             "nineteen records; file order cannot.",
                     "owner": "RWB — the clinical question is theirs", "body": body})

    # OPEN, AND UNRANKABLE. An output decision blocks no single record — it gates every column — so
    # blast radius cannot see it, and this page rendered 19 of 21 open decisions as though that were
    # the set. The terminal worksheet grew this section; the HTML one did not, which is exactly the
    # divergence `worksheet.model` exists to prevent, one renderer later.
    if m["unranked"]:
        sections.append({"kind": "section", "n": "1b", "title": "…and these govern the whole output",
                         "lede": "Open, and not rankable by blast radius: each gates every column "
                                 "rather than a set of them. Answering them is what settles the "
                                 "final ADS surface.",
                         "owner": "RWB with RWP — the output contract",
                         "body": {"kind": "list", "rows": m["unranked"]}})

    # 2 — what needs no judgment at all.
    if not m["proposals"] and not m["blocks"]:
        body = {"kind": "empty", "text": "This pack has no config/ yet, so there is nowhere for a "
                                         f"value list to go — {worksheet.NOTHING_TO_CHECK}."}
    elif not m["proposals"]:
        body = {"kind": "empty",
                "text": "None: no spec enumeration is bound to a config block in this pack yet."}
    else:
        body = {"kind": "blocks", "rows": m["proposals"]}
    sections.append({"kind": "section", "n": 2, "title": "Check these values",
                     "lede": "Value lists the specification already states, lifted from the spec "
                             "rows the contract cites so nobody retypes them — and where the config "
                             "already carries them, each block says ALREADY PRESENT and asks you to "
                             "compare rather than paste over. Each names what the spec does NOT "
                             "state — numeric codes, terminal fallthrough, the engine's own key "
                             "names — and those are yours to decide.",
                     "owner": "RWP — mechanical, but yours to check", "body": body})

    # 3 — the reverse direction.
    if not m["unclaimed"] and not m["blocks"]:
        body = {"kind": "empty", "text": "This pack has no config/ yet, so there are no governed "
                                         f"blocks to claim. That is 0 of 0 — "
                                         f"{worksheet.NOTHING_TO_CHECK}."}
    elif not m["unclaimed"]:
        body = {"kind": "ok",
                "text": f"None: all {m['blocks']} governed block(s) are claimed by a record."}
    else:
        body = {"kind": "list", "rows": m["unclaimed"]}
    sections.append({"kind": "section", "n": 3, "title": "Account for these",
                     "lede": "Configuration the contract does not claim. The binder reads the "
                             "active config graph, so a block nothing claims is a rule executing "
                             "that no requirement asked for.",
                     "owner": "RWP — with RWB where it turns out to be a requirement",
                     "body": body})

    # ACCOUNTED IS NOT CLEAN. Every governed block can be claimed while the ADS the engine emits and
    # the surface the contract publishes still disagree — an open output decision OWNS that
    # difference, which is why `check` reports it rather than raising it. Reported means VISIBLE:
    # without this, "all 38 governed blocks are claimed" stood as the whole Gate 4 answer.
    if m["surface_notes"]:
        sections.append({"kind": "section", "n": "3b", "title": "Accounted, not clean",
                         "lede": "The published surface the contract declares and the columns the "
                                 "engine emits do not yet agree. This is not an error while the "
                                 "output decisions above are open — it becomes one when they close.",
                         "owner": "RWP with RWB — settled by the output decisions",
                         "body": {"kind": "blocks", "rows": m["surface_notes"]}})

    sections.append({"kind": "refusals", "title": "What this will not do for you", "rows": [
        ("Choose a source column",
         "Only a human confirms a column is the RIGHT column, at Gate 3, against a profile. "
         "`promote` refuses to propose one."),
        ("Invent a code or a fallthrough",
         "A numeric code, a terminal fallthrough or a missing-value code is emitted as a named gap "
         "instead — a generator that guessed would guess silently, and the result would be "
         "indistinguishable from a specified value."),
        ("Resolve a decision or approve anything",
         "Those are human acts recorded in the pack's own files, and no tool here may perform "
         "them."),
    ]})
    return "Config worksheet", pack, sections


def _synthetic_note(evidence):
    """What the Gate 5 rows are, said exactly.

    THE SCIENCE IS THE SAME; THE DELIVERY IS NOT. The earlier wording was "the same configuration
    above", which is true of the scientific graph and false of the delivery bindings — the run
    overrides refresh, source_schema and output_schema to `synthetic`, while the panel two steps up
    shows the committed ones. A reader was being told the build used bindings it did not use.
    """
    bound = ", ".join(f"{k}={v}" for k, v in
                      sorted((evidence.get("effective_run_bindings") or {}).items())) or "synthetic"
    return ("Rows built by the shared engine from the same SCIENTIFIC configuration above, with "
            f"SYNTHETIC run bindings ({bound}) — not the delivery bindings shown at Gate 3. It "
            "proves the configuration assembles and executes. It says nothing about delivered "
            "data, and no value here came from a vendor.")


def _flow(pack, evidence=None):
    """The whole lifecycle on one page: what each gate produces, who acts, and where this pack is.

    Every panel is read from the tool that owns it — `status.gates` for the six states and their
    blockers, `finalize.facts` for the contract counts, `contract_binding.check` for the binding,
    `decision_report.blast_radius` for the register, `product_gates` for the two digests. The page
    adds the ORDER and nothing else.

    `evidence` is a synthetic-build summary produced by a Spark run (Gate 5). It is optional and
    ABSENT MEANS ABSENT: with no evidence the build panel says no build is attached rather than
    showing zeroes, because a row of zeroes under "synthetic build" reads as a build that produced
    nothing rather than one nobody ran.
    """
    import contract_binding
    import decision_report
    import finalize
    import product_gates as pg
    import source_manifest as sm
    import status as status_tool

    abs_pack = os.path.join(ROOT, pack)
    f = finalize.facts(abs_pack)
    errs, s = contract_binding.check(abs_pack, pg.pack_yaml(abs_pack))
    blocking, table, idle, _ = decision_report.blast_radius(abs_pack)
    ready, blockers = sm.releasable(ROOT, pack)
    six = status_tool.gates(ROOT, pack)
    mats = list(sm.materials(abs_pack))
    ai_ok, ai_why = sm.ai_readable(abs_pack)

    steps = []

    steps.append({"n": 1, "title": "Approved inputs", "who": status_tool.OWNER[1],
                  "produces": "source_refs.yaml — every material, its status and its AI class",
                  "state": six[0][2], "blockers": six[0][3],
                  "facts": [("materials registered", len(mats)),
                            ("source status", sm.source_status(abs_pack)),
                            ("AI may read the pack", "yes" if ai_ok else "no")],
                  "detail": {"kind": "kv", "rows": [
                      (str(m.get("material_id")),
                       f"{m.get('material_type')} · status {m.get('status')} · "
                       f"ai_classification {m.get('ai_classification') or '—'}")
                      for m in mats]},
                  "note": (ai_why[0] if (ai_why and not ai_ok) else
                           "The sanitized extraction is signed, so the drafting slicer may read "
                           "this pack.")})

    steps.append({"n": 2, "title": "Requirements and decisions", "who": status_tool.OWNER[2],
                  "produces": "FUNCTIONAL_CONTRACT.md · DECISIONS.md · SPEC_QC_FINDINGS.md",
                  "state": six[1][2], "blockers": six[1][3],
                  "facts": [("contract records", f.get("records", 0)),
                            ("spec items traced", f"{f.get('mapped', 0)}/{f.get('items', 0)}"),
                            ("open decisions blocking a record", len(blocking)),
                            ("records approved", f.get("approved", 0))],
                  "detail": {"kind": "kv", "rows": [
                      (d, f"{len(v)} record(s) — {', '.join(v[:4])}"
                          f"{' …' if len(v) > 4 else ''}")
                      for d, v in sorted(blocking.items(), key=lambda kv: -len(kv[1]))[:6]]
                      # ...and the ones blast radius cannot rank because they block no single
                      # record: they gate every column. Open, load-bearing, and previously on
                      # neither list.
                      + [(d, "governs the OUTPUT as a whole — not rankable by blast radius")
                         for d in (worksheet.model(pack) or {}).get("unranked", [])]},
                  "note": "AI drafts a record from the sanitized specification; a human approves it. "
                          "Every record carries the spec rows it came from and a digest of their "
                          "text, so a specification edit shows up as drift rather than silently "
                          "changing what was approved."})

    steps.append({"n": 3, "title": "Source and delivery readiness", "who": status_tool.OWNER[3],
                  "produces": "profile_<cut>.tsv · SCHEMA_VALIDATION_<cut>.json · "
                              "SOURCE_VERDICTS.md",
                  "state": six[2][2], "blockers": six[2][3],
                  # UNSTATED IS NOT BOUND. `REPLACE_ME` is a truthy string, so a plain `if v`
                  # printed "refresh=REPLACE_ME" under "delivery bound to" — while the gate itself
                  # treats it as unstated and refuses a --complete verdict over it. The page said
                  # bound; the tool said unbound; the reader believed the page.
                  "facts": [("delivery", "unbound" if any(
                      pg.unstated(v) for v in _delivery_bindings(_merged_raw(os.path.join(
                          abs_pack, "config", "data_product.yaml"))).values())
                      else "bound"),
                            # ...AND A FILE IS NOT AN ACCEPTANCE. `os.path.exists` said yes to a
                            # verdict that failed, went stale, named another cut or carried no
                            # reviewer — every way Gate 3 evidence can exist and mean nothing.
                            # The state comes from `status.gates`, which reads the verdict.
                            ("gate 3 state", six[2][2])],
                  "detail": {"kind": "kv", "rows": [
                      (k, "not set — a placeholder is not a delivery" if pg.unstated(v)
                          else str(v)) for k, v in sorted(_delivery_bindings(_merged_raw(
                              os.path.join(abs_pack, "config", "data_product.yaml"))).items())]},
                  "note": "The profile and the schema report read DELIVERED data, so neither may "
                          "enter the checkout and neither is drawn on this page. What crosses is "
                          "the verdict — a person's confirmation that a mapped column is the "
                          "intended concept — never the values behind it."})

    graph = pg.scientific_yaml(abs_pack)
    steps.append({"n": 4, "title": "Executable configuration", "who": status_tool.OWNER[4],
                  "produces": "config/ + variables/ + codelists/ · CONFIGURATION_APPROVAL.yaml",
                  "state": six[3][2], "blockers": six[3][3],
                  "facts": [("governed config blocks", f"{s['claimed']}/{s['blocks']} claimed"),
                            ("records producing output", s["produces"]),
                            ("blocks nothing claims", len(errs)),
                            ("published surface", "settled" if not s.get("surface_notes")
                             else "ACCOUNTED, not clean"),
                            ("science digest", pg.config_bundle_sha256(abs_pack)[:12] + "…"),
                            ("delivery digest", pg.delivery_sha256(abs_pack)[:12] + "…")],
                  # EVERY BLOCK CLAIMED IS NOT A SETTLED OUTPUT. The two are different questions,
                  # and showing only the first let "38/38 claimed" read as the whole Gate 4 answer
                  # while the ADS the engine emits and the surface the contract publishes still
                  # disagreed by 80 columns. An open output decision OWNS that gap, which is why
                  # it is reported rather than raised — reported means VISIBLE.
                  "detail": {"kind": "kv", "rows":
                             [("published surface", " ".join(n.split())[:400])
                              for n in (s.get("surface_notes") or [])]
                             + [(g, "in the approved graph") for g in graph]},
                  "note": "Two digests because there are two questions. The SCIENCE digest is what "
                          "an RWP approval binds to; the DELIVERY digest is what Gate 3 evidence "
                          "binds to. Pointing the job at another output schema moves neither — "
                          "pointing it at another cut moves the second."})

    build = {"kind": "none"}
    g5 = (evidence or {}).get("gate5") or {}
    if evidence:
        build = {"kind": "table", "cols": g5["sample_cols"], "rows": g5["sample"]}
    steps.append({"n": 5, "title": "Validation", "who": status_tool.OWNER[5],
                  "produces": "the built ADS + QC · golden comparison · manifest",
                  "state": six[4][2], "blockers": six[4][3],
                  "facts": ([("synthetic ADS rows", g5["rows"]),
                             ("columns built", g5["columns"]),
                             ("cohorts unioned", len(g5["cohorts"])),
                             ("built at", str(evidence.get("git_commit") or "?")[:12]),
                             ("Spark", g5["spark"])] if evidence else
                            [("synthetic build attached", "no")]),
                  "detail": build,
                  # THE SCIENCE IS THE SAME; THE DELIVERY IS NOT, and the earlier wording said
                  # "the same configuration above" for both. The synthetic run overrides refresh,
                  # source_schema and output_schema — so a reader was being told the run used the
                  # delivery bindings shown two panels up, which are REPLACE_ME.
                  "note": (_synthetic_note(evidence) if evidence else
                           "No synthetic build is attached to this page. That is not a build that "
                           "produced nothing — it is a build nobody ran.")})

    steps.append({"n": 6, "title": "Release", "who": status_tool.OWNER[6],
                  "produces": "RELEASE_APPROVAL.yaml — over a named build id and manifest digest",
                  "state": six[5][2], "blockers": six[5][3],
                  "facts": [("Gates 1–4 derived verdict",
                             "clear" if ready else f"blocked ({len(blockers)} reason(s))")],
                  "detail": {"kind": "list", "rows": blockers[:8]},
                  "note": "There is no releasable flag to set. It is DERIVED from Gates 1–4 every "
                          "time it is asked, so the only way to change this line is to close a "
                          "gate. Promoting an approved candidate without rebuilding is not "
                          "implemented — Gate 6 cannot complete today, and says so."})

    return "How this product is built", pack, [{"kind": "flow", "steps": steps,
                                                "compile": _compile_demo(abs_pack)}]


def _compile_demo(abs_pack):
    """One variable, from the YAML a person wrote to the SQL the engine runs.

    The single clearest answer to "how does it work": config NAMES a rule out of a registry the
    engine owns, and the engine compiles it. Nothing here is authored in SQL by a person, which is
    why the same configuration runs on two engines and can be compared string-for-string.
    """
    try:
        from engine.config import load_config
        from engine.stages.clinical import _stage_case
        import yaml
        cfg = load_config(os.path.join(abs_pack, "config", "data_product.yaml"))
        groups = (cfg.pack("clinical") or {}).get("staging", {}).get("groups")
        if not groups:
            return None
        return {"yaml": yaml.safe_dump({"staging": {"groups": groups}}, sort_keys=False),
                "label": _stage_case(groups, "groupstage", "label"),
                "code": _stage_case(groups, "groupstage", "code")}
    except Exception:
        return None                 # a pack without this block simply has no demo to show


STAGES = {
    "worksheet": ("Gate 4 preparation — what to answer, paste and account for", _worksheet),
    "flow": ("The whole lifecycle — what each gate produces and where this pack stands", _flow),
}


# ---------------------------------------------------------------------------------------------
# The page.
# ---------------------------------------------------------------------------------------------

CSS = """
:root{
  --ink:#15171c; --ink-2:#4a505c; --ink-3:#787f8d;
  --bg:#f7f6f3; --panel:#fffefb; --line:#e2ded4;
  --accent:#8a4b2a;            /* burnt sienna — one accent, spent in one place */
  --accent-soft:#f0e4dc;
  --open:#a8622c; --ok:#4f6b4a; --idle:#7b7f8a;
  --mono:ui-monospace,"SF Mono",Menlo,Consolas,monospace;
}
@media (prefers-color-scheme:dark){
  :root{ --ink:#eceae4; --ink-2:#b2b0aa; --ink-3:#8a8880;
         --bg:#14150f; --panel:#1c1e17; --line:#33362c;
         --accent:#d98d5f; --accent-soft:#2e2820;
         --open:#e0a068; --ok:#8fb083; --idle:#8a8880; }
}
:root[data-theme="dark"]{ --ink:#eceae4; --ink-2:#b2b0aa; --ink-3:#8a8880;
  --bg:#14150f; --panel:#1c1e17; --line:#33362c; --accent:#d98d5f; --accent-soft:#2e2820;
  --open:#e0a068; --ok:#8fb083; --idle:#8a8880; }
:root[data-theme="light"]{ --ink:#15171c; --ink-2:#4a505c; --ink-3:#787f8d;
  --bg:#f7f6f3; --panel:#fffefb; --line:#e2ded4; --accent:#8a4b2a; --accent-soft:#f0e4dc;
  --open:#a8622c; --ok:#4f6b4a; --idle:#7b7f8a; }

*{box-sizing:border-box}
body{margin:0;background:var(--bg);color:var(--ink);
  font:16px/1.6 ui-serif,Georgia,"Times New Roman",serif;
  -webkit-font-smoothing:antialiased}
.wrap{max-width:60rem;margin:0 auto;padding:3.5rem 1.5rem 5rem;display:flex;flex-direction:column;gap:2.5rem}

header{display:flex;flex-direction:column;gap:.6rem;border-bottom:2px solid var(--ink);padding-bottom:1.4rem}
.eyebrow{font:600 .7rem/1 var(--mono);letter-spacing:.16em;text-transform:uppercase;color:var(--accent)}
h1{margin:0;font-size:clamp(1.9rem,4.5vw,2.7rem);line-height:1.1;font-weight:600;text-wrap:balance}
.sub{font:.85rem/1.5 var(--mono);color:var(--ink-2);word-break:break-all}
.stage-note{font-size:.95rem;color:var(--ink-2);max-width:52ch}

.stats{display:grid;grid-template-columns:repeat(auto-fit,minmax(9.5rem,1fr));gap:1px;
  background:var(--line);border:1px solid var(--line)}
.stat{background:var(--panel);padding:1rem 1.1rem;display:flex;flex-direction:column;gap:.25rem}
.stat .n{font:600 1.9rem/1 var(--mono);font-variant-numeric:tabular-nums;color:var(--ink)}
.stat .k{font-size:.82rem;color:var(--ink-2)}
.stat .h{font-size:.74rem;color:var(--ink-3)}

.note{border-left:3px solid var(--accent);background:var(--panel);padding:.85rem 1.1rem;
  display:flex;flex-direction:column;gap:.3rem}
.note b{font-weight:600}
.note p{margin:0;font-size:.9rem;color:var(--ink-2)}
.notes{display:flex;flex-direction:column;gap:.7rem}

section.step{display:flex;flex-direction:column;gap:.9rem}
.step-head{display:flex;align-items:baseline;gap:.75rem;flex-wrap:wrap}
.step-n{font:600 .78rem/1 var(--mono);color:var(--panel);background:var(--accent);
  padding:.35rem .5rem;border-radius:2px}
h2{margin:0;font-size:1.4rem;font-weight:600;letter-spacing:-.01em}
.owner{font:.72rem/1 var(--mono);color:var(--ink-3);letter-spacing:.04em;margin-left:auto}
.lede{margin:0;font-size:.95rem;color:var(--ink-2);max-width:62ch}

.rows{display:flex;flex-direction:column;gap:1px;background:var(--line);
  border:1px solid var(--line)}
.row{background:var(--panel);padding:.95rem 1.1rem;display:grid;
  grid-template-columns:5.5rem 1fr;gap:.4rem 1.1rem;align-items:start}
.bar{display:flex;flex-direction:column;gap:.3rem;align-items:flex-start}
.count{font:600 1.35rem/1 var(--mono);font-variant-numeric:tabular-nums;color:var(--open)}
.count small{display:block;font:400 .66rem/1.2 var(--mono);color:var(--ink-3);letter-spacing:.04em}
.meter{width:100%;height:4px;background:var(--accent-soft)}
.meter i{display:block;height:100%;background:var(--open)}
.did{font:600 .88rem/1.4 var(--mono);color:var(--ink);word-break:break-word}
.q{margin:.25rem 0 0;font-size:.93rem;color:var(--ink-2)}
.blocks{margin:.45rem 0 0;display:flex;flex-wrap:wrap;gap:.3rem}
.chip{font:.72rem/1 var(--mono);color:var(--ink-2);background:var(--accent-soft);
  padding:.28rem .42rem;border-radius:2px}
.more{font:.72rem/1 var(--mono);color:var(--ink-3);padding:.28rem 0}

.tail{background:var(--panel);border:1px solid var(--line);padding:.9rem 1.1rem;
  font-size:.88rem;color:var(--ink-2)}
.tail .ids{font:.75rem/1.8 var(--mono);color:var(--ink-3);word-break:break-word}
.tail.idle{border-left:3px solid var(--idle)}

.empty,.okline{background:var(--panel);border:1px solid var(--line);padding:1rem 1.1rem;
  font-size:.93rem;color:var(--ink-2)}
.okline{border-left:3px solid var(--ok);color:var(--ink)}

pre{margin:0;background:var(--panel);border:1px solid var(--line);padding:.9rem 1.1rem;
  overflow-x:auto;font:.78rem/1.65 var(--mono);color:var(--ink)}
.stack{display:flex;flex-direction:column;gap:.7rem}
ul.plain{margin:0;padding:0;list-style:none;display:flex;flex-direction:column;gap:1px;
  background:var(--line);border:1px solid var(--line)}
ul.plain li{background:var(--panel);padding:.75rem 1.1rem;font-size:.9rem;color:var(--ink-2)}

.refusals{border-top:1px solid var(--line);padding-top:1.5rem;display:flex;flex-direction:column;gap:1rem}
.refusals h2{font-size:1.05rem}
.refusals dl{margin:0;display:flex;flex-direction:column;gap:.85rem}
.refusals dt{font:600 .88rem/1.4 var(--mono);color:var(--ink)}
.refusals dd{margin:.2rem 0 0;font-size:.92rem;color:var(--ink-2);max-width:64ch}

footer{border-top:1px solid var(--line);padding-top:1.2rem;font:.76rem/1.7 var(--mono);
  color:var(--ink-3);display:flex;flex-direction:column;gap:.2rem}

/* --- the lifecycle flow ------------------------------------------------------------------- */
ol.flow{list-style:none;margin:0;padding:0;display:flex;flex-direction:column;gap:0}
.stepli{display:grid;grid-template-columns:2.5rem 1fr;gap:0 1.2rem}
.marker{position:relative;display:flex;justify-content:center}
.marker::before{content:"";position:absolute;top:0;bottom:-1px;width:2px;background:var(--line)}
.stepli:first-child .marker::before{top:1.4rem}
.stepli:last-child .marker::before{bottom:auto;height:1.4rem}
.dot{position:relative;z-index:1;width:2.1rem;height:2.1rem;border-radius:50%;
  background:var(--accent);color:var(--panel);display:grid;place-items:center;
  font:600 .9rem/1 var(--mono);margin-top:.35rem}
.stepbody{padding:0 0 2.4rem;display:flex;flex-direction:column;gap:.6rem;min-width:0}
.stepbody .step-head{display:flex;align-items:baseline;gap:.75rem;flex-wrap:wrap}
.state{font:600 .68rem/1 var(--mono);letter-spacing:.09em;text-transform:uppercase;
  padding:.32rem .5rem;border:1px solid currentColor;border-radius:2px}
.s-done{color:var(--ok)} .s-live{color:var(--open)} .s-idle{color:var(--idle)}
.s-block{color:var(--panel);background:var(--open);border-color:var(--open)}
.who{font:.74rem/1.5 var(--mono);color:var(--ink-3)}
.produces{font-size:.86rem;color:var(--ink-2)}
.produces code{font:.78rem/1.5 var(--mono);color:var(--ink);word-break:break-word}
.facts{display:flex;flex-wrap:wrap;gap:1px;background:var(--line);border:1px solid var(--line)}
.f{background:var(--panel);padding:.6rem .8rem;display:flex;flex-direction:column;gap:.15rem;
  flex:1 1 8rem;min-width:0}
.fv{font:600 1.15rem/1.2 var(--mono);font-variant-numeric:tabular-nums;word-break:break-word}
.fk{font-size:.74rem;color:var(--ink-3)}
ul.why{margin:0;padding:0 0 0 1.1rem;font-size:.87rem;color:var(--open)}
dl.kv{margin:0;display:grid;grid-template-columns:minmax(8rem,auto) 1fr;gap:1px;
  background:var(--line);border:1px solid var(--line)}
dl.kv dt{background:var(--panel);padding:.5rem .8rem;font:600 .78rem/1.5 var(--mono);
  word-break:break-word}
dl.kv dd{background:var(--panel);margin:0;padding:.5rem .8rem;font-size:.85rem;color:var(--ink-2)}
.scroll{overflow-x:auto;border:1px solid var(--line)}
table{border-collapse:collapse;width:100%;font:.78rem/1.5 var(--mono);
  font-variant-numeric:tabular-nums}
th,td{text-align:left;padding:.45rem .7rem;border-bottom:1px solid var(--line);white-space:nowrap}
th{background:var(--accent-soft);font-weight:600;color:var(--ink)}
td{background:var(--panel);color:var(--ink-2)}
tr:last-child td{border-bottom:none}

.compile{border-top:1px solid var(--line);padding-top:1.6rem;display:flex;flex-direction:column;gap:.8rem}
.compile h3{margin:0 0 .4rem;font:600 .74rem/1 var(--mono);letter-spacing:.1em;
  text-transform:uppercase;color:var(--accent)}
.two{display:grid;grid-template-columns:1fr;gap:1rem}
@media(min-width:52rem){.two{grid-template-columns:1fr 1fr}}
.two pre{max-height:26rem;overflow:auto}
.two pre + pre{margin-top:.6rem}
"""


def _stat_block(stats, notes):
    out = ['<div class="stats">']
    for k, n, h in stats:
        out.append(f'<div class="stat"><span class="n">{_e(n)}</span>'
                   f'<span class="k">{_e(k)}</span><span class="h">{_e(h)}</span></div>')
    out.append("</div>")
    if notes:
        out.append('<div class="notes">')
        for head, why in notes:
            out.append(f'<div class="note"><b>{_e(head)}</b><p>{_e(why)}</p></div>')
        out.append("</div>")
    return "\n".join(out)


def _decision_rows(body):
    rows, top = body["rows"], body["top"]
    widest = max(r["count"] for r in rows) or 1
    out = ['<div class="rows">']
    for r in rows[:top]:
        pct = int(round(100 * r["count"] / widest))
        chips = "".join(f'<span class="chip">{_e(v)}</span>' for v in r["blocks"][:8])
        extra = (f'<span class="more">+{len(r["blocks"]) - 8} more</span>'
                 if len(r["blocks"]) > 8 else "")
        out.append(
            '<div class="row">'
            f'<div class="bar"><span class="count">{r["count"]}<small>RECORDS</small></span>'
            f'<span class="meter"><i style="width:{pct}%"></i></span></div>'
            f'<div><div class="did">{_e(r["id"])}</div>'
            f'<p class="q">{_e(r["question"])}</p>'
            f'<div class="blocks">{chips}{extra}</div></div></div>')
    out.append("</div>")
    rest = rows[top:]
    if rest:
        out.append('<div class="tail"><b>…and {} more, each blocking fewer.</b>'
                   '<div class="ids">{}</div></div>'
                   .format(len(rest), _e(", ".join(r["id"] for r in rest))))
    if body["idle"]:
        out.append('<div class="tail idle"><b>{} open decision(s) block no record today.</b> '
                   'Open, and not on the critical path — answer them after the list above.'
                   '<div class="ids">{}</div></div>'
                   .format(len(body["idle"]), _e(", ".join(body["idle"]))))
    return "\n".join(out)


def _body(body):
    kind = body["kind"]
    if kind == "empty":
        return f'<div class="empty">{_e(body["text"])}</div>'
    if kind == "ok":
        return f'<div class="okline">{_e(body["text"])}</div>'
    if kind == "decisions":
        return _decision_rows(body)
    if kind == "blocks":
        return ('<div class="stack">'
                + "".join(f"<pre>{_e(b)}</pre>" for b in body["rows"]) + "</div>")
    if kind == "list":
        return ('<ul class="plain">'
                + "".join(f"<li>{_e(r)}</li>" for r in body["rows"]) + "</ul>")
    if kind == "none":
        return ""
    if kind == "kv":
        if not body["rows"]:
            return ""
        return ('<dl class="kv">' + "".join(f"<dt>{_e(k)}</dt><dd>{_e(v)}</dd>"
                                            for k, v in body["rows"]) + "</dl>")
    if kind == "table":
        head = "".join(f"<th>{_e(c)}</th>" for c in body["cols"])
        rows = "".join("<tr>" + "".join(f"<td>{_e(c)}</td>" for c in r) + "</tr>"
                       for r in body["rows"])
        return (f'<div class="scroll"><table><thead><tr>{head}</tr></thead>'
                f"<tbody>{rows}</tbody></table></div>")
    raise ValueError(f"unknown body kind {kind!r}")   # a silently blank section reads as "clean"


STATE_CLASS = {"done": "s-done", "in progress": "s-live", "not started": "s-idle",
               "blocked": "s-block", "cannot complete": "s-block"}


def _flow_section(sec):
    out = ['<ol class="flow">']
    for st in sec["steps"]:
        facts = "".join(f'<div class="f"><span class="fv">{_e(v)}</span>'
                        f'<span class="fk">{_e(k)}</span></div>' for k, v in st["facts"])
        why = "".join(f'<li>{_e(b)}</li>' for b in (st["blockers"] or [])[:3])
        out.append(
            f'<li class="stepli">'
            f'<div class="marker"><span class="dot">{st["n"]}</span></div>'
            f'<div class="stepbody">'
            f'<div class="step-head"><h2>{_e(st["title"])}</h2>'
            f'<span class="state {STATE_CLASS.get(st["state"], "s-idle")}">'
            f'{_e(st["state"])}</span></div>'
            f'<div class="who">{_e(st["who"])}</div>'
            f'<div class="produces">produces &nbsp;<code>{_e(st["produces"])}</code></div>'
            f'<div class="facts">{facts}</div>'
            + (f'<ul class="why">{why}</ul>' if why else "")
            + _body(st["detail"])
            + f'<p class="lede">{_e(st["note"])}</p>'
            "</div></li>")
    out.append("</ol>")
    c = sec.get("compile")
    if c:
        out.append(
            '<div class="compile"><h2>One variable, end to end</h2>'
            '<p class="lede">A person writes the left. Nobody writes the right — the engine '
            'compiles it from a rule it owns, which is why the same configuration runs on two '
            'engines and can be compared string for string.</p>'
            f'<div class="two"><div><h3>variables/clinical.yaml</h3><pre>{_e(c["yaml"])}</pre></div>'
            f'<div><h3>compiled SQL</h3><pre>{_e(c["label"])}</pre>'
            f'<pre>{_e(c["code"])}</pre></div></div></div>')
    return "\n".join(out)


def evidence_errors(doc, pack):
    """[why this build summary is not this pack's] — empty when the page may caption it.

    THE CAPTION IS A CLAIM. The Gate 5 panel says "rows built by the shared engine from the same
    configuration above, on SYNTHETIC sources", and every clause of that is falsifiable: another
    tumour's build, an older configuration, or a REAL-data run would each be described that way for
    any non-empty `gate5` block. So each clause is verified against the checkout the page is drawn
    from, and a mismatch REFUSES rather than rendering with a wrong caption.

    `source_mode` must be stated and must be `synthetic`. Unstated is not synthetic — only the
    producer knows, and accepting silence here is how a live build reaches a shareable page.
    """
    import product_gates as pg
    if not isinstance(doc, dict) or not doc.get("gate5"):
        return ["no `gate5` build summary in it — a file that says nothing must not be rendered "
                "as a build that produced nothing"]
    why = []
    if str(doc.get("pack") or "") != pack:
        why.append(f"it was built for {doc.get('pack') or '(unstated)'}, not {pack}")
    if str(doc.get("source_mode") or "") != "synthetic":
        why.append(f"source_mode is {doc.get('source_mode') or '(unstated)'}, not `synthetic` — "
                   f"this page may only caption a build it knows read no delivered data")
    abs_pack = os.path.join(ROOT, pack)
    for field, actual, what in (("science_digest", pg.config_bundle_sha256(abs_pack),
                                 "the scientific configuration"),
                                ("committed_delivery_digest", pg.delivery_sha256(abs_pack),
                                 "the committed delivery bindings")):
        got = str(doc.get(field) or "")
        if got != actual:
            why.append(f"{field} {got[:12] or '(unstated)'}… does not match {what} in this "
                       f"checkout ({actual[:12]}…) — the build is of a different configuration")
    # THE ENGINE, NOT ONLY THE CONFIG. Digests cover the YAML; they say nothing about the code that
    # executed it. A build from an older engine, with the configuration untouched since, matches
    # every digest above and would be captioned "the build from the code you are looking at". So
    # the commit, the tree state and the platform version are checked too — and a DIRTY tree is
    # refused outright, because then the commit names files nobody can retrieve.
    import subprocess

    def _tree(rev):
        r = subprocess.run(["git", "-C", ROOT, "rev-parse", f"{rev}^{{tree}}"],
                           capture_output=True, text=True)
        return r.stdout.strip() if r.returncode == 0 else None

    head = subprocess.run(["git", "-C", ROOT, "rev-parse", "HEAD"], capture_output=True, text=True)
    built_at = str(doc.get("git_commit") or "")
    if head.returncode == 0 and built_at != head.stdout.strip():
        # SAME TREE IS THE SAME CODE. Requiring an exact commit made a MERGE reject a build of its
        # own content: the branch commit and the merge that landed it have identical trees, so the
        # evidence was refused for code that had not changed by one byte, and the only remedy was a
        # four-minute rebuild of a result already correct. The commit is still recorded and still
        # shown — it is what a person cites — but what is CHECKED is whether the bytes match.
        here, there = _tree("HEAD"), _tree(built_at) if built_at else None
        if not (here and there and here == there):
            why.append(f"it was built at commit {built_at[:12] or '(unstated)'}, whose content "
                       f"differs from the {head.stdout.strip()[:12]} this page is drawn from — the "
                       f"engine may have changed underneath a configuration that did not")
    if doc.get("git_clean") is not True:
        why.append("it was built from a DIRTY checkout (git_clean is not true), so its commit "
                   "names a tree nobody can retrieve — rebuild it from a clean one")
    want_v = open(os.path.join(ROOT, "platform", "VERSION"), encoding="utf-8").read().strip()
    if str(doc.get("platform_version") or "") != want_v:
        why.append(f"it was built on platform {doc.get('platform_version') or '(unstated)'}, not "
                   f"the {want_v} in this checkout")
    return why


def page(stage, pack, evidence=None):
    """The whole document body for one stage of one pack."""
    label, builder = STAGES[stage]
    # ONE SIGNATURE, not try/except. Dispatching on TypeError meant a genuine TypeError inside a
    # builder was caught, the retry silently dropped the evidence, and the page rendered "no build
    # attached" over a real defect. Every builder takes `(pack, evidence)` and ignores what it does
    # not use.
    title, subtitle, sections = builder(pack, evidence)
    if title is None:                       # the stage has nothing to show, and says why
        return "\n".join([
            f"<title>{_e(stage)} — {_e(pack)}</title>", f"<style>{CSS}</style>",
            '<div class="wrap"><header>',
            f'<div class="eyebrow">{_e(stage)}</div><h1>Nothing to order yet</h1>',
            f'<div class="sub">{_e(pack)}</div></header>',
            f'<div class="empty">{_e(subtitle)}</div></div>'])

    out = [f"<title>{_e(title)} — {_e(pack)}</title>", f"<style>{CSS}</style>",
           '<div class="wrap">', "<header>",
           f'<div class="eyebrow">{_e(stage)}</div>',
           f"<h1>{_e(title)}</h1>",
           f'<div class="sub">{_e(subtitle)}</div>',
           f'<p class="stage-note">{_e(label)}</p>',
           "</header>"]
    for sec in sections:
        if sec["kind"] == "stats":
            out.append(_stat_block(sec["stats"], sec["notes"]))
        elif sec["kind"] == "section":
            out.append('<section class="step"><div class="step-head">'
                       f'<span class="step-n">{sec["n"]}</span><h2>{_e(sec["title"])}</h2>'
                       f'<span class="owner">{_e(sec["owner"])}</span></div>'
                       f'<p class="lede">{_e(sec["lede"])}</p>'
                       f'{_body(sec["body"])}</section>')
        elif sec["kind"] == "flow":
            out.append(_flow_section(sec))
        elif sec["kind"] == "refusals":
            items = "".join(f"<dt>{_e(t)}</dt><dd>{_e(d)}</dd>" for t, d in sec["rows"])
            out.append(f'<div class="refusals"><h2>{_e(sec["title"])}</h2><dl>{items}</dl></div>')
    # THE FOOTER NAMED A FUNCTION THAT DOES NOT EXIST. It was built from the stage name, so the
    # flow page credited `flow.model()` — no such module, no such function. A provenance line that
    # is generated rather than true is worse than none, because it is the line a reader checks.
    out += ["<footer>",
            f"<span>generated by platform/tools/render_html.py · "
            f"{_e(builder.__module__)}.{_e(builder.__name__)}()</span>",
            "<span>a VIEW — every number comes from the stage tool that owns it; nothing here is "
            "computed, and nothing here can approve anything</span>",
            "</footer>", "</div>"]
    return "\n".join(out)


def main(argv):
    ap = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    ap.add_argument("stage", nargs="?", help=f"one of: {', '.join(sorted(STAGES))}")
    ap.add_argument("pack", nargs="?", help="the pack directory (repo-root-relative)")
    ap.add_argument("--out", help="write the page here. REQUIRED, and refused inside the checkout: "
                                  "repo_hygiene refuses a committed *.html, and a generated report "
                                  "belongs in the restricted output directory.")
    ap.add_argument("--evidence", help="JSON summary of a synthetic build, for the flow stage's "
                                       "Gate 5 panel. Omitted means NO BUILD IS ATTACHED, which "
                                       "the page says — it does not show zeroes.")
    ap.add_argument("--list", action="store_true", help="the stages that can be rendered")
    a = ap.parse_args(argv)

    if a.list or not a.stage:
        for name in sorted(STAGES):
            print(f"  {name:12s} {STAGES[name][0]}")
        return 0
    if a.stage not in STAGES:
        sys.exit(f"{a.stage}: not a renderable stage. One of: {', '.join(sorted(STAGES))}")
    if not a.pack:
        sys.exit("a pack is required")
    if not a.out:
        sys.exit("--out is required (and must be outside the checkout — see --help)")

    pack = os.path.relpath(os.path.abspath(a.pack), ROOT).replace(os.sep, "/")
    if not os.path.isdir(os.path.join(ROOT, pack)):
        sys.exit(f"{a.pack}: not a directory")
    out = os.path.join(pack_run.restricted_dir(os.path.dirname(os.path.abspath(a.out)),
                                               what="report"),
                       os.path.basename(a.out))
    os.makedirs(os.path.dirname(out), exist_ok=True)
    ev = None
    if a.evidence:
        with open(a.evidence, encoding="utf-8") as fh:
            doc = json.load(fh) or {}
        why = evidence_errors(doc, pack)
        if why:
            sys.exit(f"{a.evidence}: this build does not describe {pack} —\n  "
                     + "\n  ".join(why)
                     + "\n\nThe page captions it 'the same configuration above, on SYNTHETIC "
                       "sources'. That is a claim about provenance, so it is checked rather than "
                       "printed. Re-run: platform/tools/local_smoke.py " + pack
                     + " --evidence-out <file>")
        # THE WHOLE VALIDATED DOCUMENT, not the summary inside it. `effective_run_bindings` is
        # recorded at the TOP level — it is a property of the run, not of the ADS — so passing
        # `doc["gate5"]` dropped it, and the caption that exists to name those bindings silently
        # fell back to the word "synthetic". Everything upstream was checked; the one thing the
        # check exists to let the page SAY was thrown away one line before it was said.
        ev = doc
    with open(out, "w", encoding="utf-8") as fh:
        fh.write(page(a.stage, pack, ev))
    print(f"ok  {a.stage} — {pack} -> {out}")
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
