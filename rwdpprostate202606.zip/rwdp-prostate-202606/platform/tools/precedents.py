#!/usr/bin/env python3
"""Questions that have come up before, and where they were answered.

    python3 platform/tools/precedents.py            # the store, with each citation's LIVE status
    python3 platform/tools/precedents.py --check    # CI: every citation still resolves

ADVISORY, and deliberately powerless. It reads `governance/precedents.yaml`, which no gate reads and
which cannot make a pack releasable, resolve a decision or approve a record. Its whole job is to stop
the next product re-arguing a question from scratch without knowing three packs already did.

IT STORES NO ANSWERS. Each entry cites (pack, decision id); the question wording, the status and the
agreed answer are read from that pack's `handoff/DECISIONS.md` at display time, through
`contract_lint.decision_rows` — the ONE reader of that table. A copied answer would be a second copy
of a governed fact, agreeing today and free to diverge the moment somebody edits one side. A pointer
cannot go stale; it can only stop resolving, which `--check` turns red.

stdlib only (plus PyYAML, via product_gates.read_yaml).
"""
import argparse
import os
import sys

TOOLS = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(os.path.dirname(TOOLS))
sys.path.insert(0, TOOLS)

from contract_lint import cell, decision_answer, decision_rows, decision_status, read  # noqa: E402
from product_gates import products, read_yaml, registry_entry  # noqa: E402

STORE = os.path.join("governance", "precedents.yaml")
MIN_SIGHTINGS = 2  # one sighting is a decision, not a precedent
MIN_TUMOURS = 2    # ...and one TUMOUR repeating itself is not recurrence, see source_key_precedents


def _slug(pack):
    """The tumour a pack belongs to, or "" when the path does not name one.

    A pack lives at products/<family>/[<grouping>/…]<slug>/<version> and is discovered by SHAPE at
    any depth (`product_gates.products`), so the tumour is the segment ABOVE the version — not a
    fixed offset. `parts[2]` answered the GROUPING level for a pack one level deeper, which merges
    two tumours into one: `products/oncology/gu/prostate/…` and `products/oncology/gu/bladder/…`
    would corroborate each other, and nothing would say so.

    A path that is not under `products/` has NO tumour, and "" is the fail-closed answer rather than
    whatever segment sits at that offset. `platform/tests/fixtures/prostate_202607` is a parked spec
    revision the store still cites; read positionally it answered `fixtures`, which turned seven
    single-tumour entries into corroborated ones — evidence manufactured by moving a directory. It
    still counts as a SIGHTING (a human read that register); it is not a second tumour.
    """
    parts = [p for p in (pack or "").replace(os.sep, "/").strip("/").split("/") if p]
    if len(parts) < 4 or parts[0] != "products":
        return ""
    return parts[-2]


def tumours(entry):
    """The distinct TUMOURS an entry has been seen in — not the packs.

    Two revisions of one tumour re-raising a question is one programme's specification being read
    twice, which is much weaker evidence that a DIFFERENT tumour will hit it than two tumours
    hitting it independently. Seven of the nine entries here rest on prostate alone.

    The two halves of this store treat that differently, ON PURPOSE, and the difference is worth
    keeping straight. The source-key half REFUSES single-tumour recurrence outright: `psa` and
    `provenge` appear in two prostate configs because the second was written from the first, which
    is not evidence of anything. The decision half KEEPS it and LABELS it, because a human had to
    read two registers and judge that `PRACTICE-MISSING-CODE` and `PRACTICE-NO-RECORD` are one
    question — that judgment is itself evidence, and the question is worth a reader's attention
    before a second tumour corroborates it. What is not acceptable is showing both kinds as though
    they were equally proven.
    """
    return {_slug(s.get("pack")) for s in (entry.get("seen_in") or []) if _slug(s.get("pack"))}


def corroboration(entry):
    """A label stating how far an entry's evidence actually reaches."""
    t = sorted(tumours(entry))
    if len(t) >= MIN_TUMOURS:
        return f"corroborated across {len(t)} tumours: {', '.join(t)}"
    return f"{len(t)} tumour so far ({', '.join(t) or 'none'}) — not yet corroborated"


def _by_strength(entry):
    """Corroborated entries first, then alphabetical. A reader works down the list, so the ones
    two tumours have independently hit belong at the top of it."""
    return (len(tumours(entry)) < MIN_TUMOURS, entry.get("id", ""))


def _vendor(root, pack):
    """The pack's vendor, from the registry. None when it has no entry — and None means PROPOSE
    NOTHING. A source key is only evidence within a delivery: Flatiron's packs all declare
    `practice`, `ses`, `telemed` and `vitals`, and neither COTA pack declares any of them, so
    guessing a vendor would propose four tables that do not exist."""
    return (registry_entry(root, pack) or {}).get("vendor")


def _declared(root, pack):
    """The source keys a pack's config declares. Empty when there is no config, or it cannot be
    read — which makes every key a proposal, the safe direction for an advisory tool."""
    doc, err = read_yaml(os.path.join(root, pack, "config", "data_product.yaml"))
    src = (doc or {}).get("sources") if not err and isinstance(doc, dict) else None
    return set(src) if isinstance(src, dict) else set()


def source_key_precedents(root=ROOT):
    """{vendor: {source key: {tumour slug: [packs]}}} — DERIVED, and deliberately not stored.

    The decision half of this store exists because nothing mechanical can pair `FUED-DEFINITION`
    with `OC-FU-END-DEFINITION`; that pairing is the whole content of the YAML. Here the opposite
    holds: `demographics` in prostate's config and `demographics` in ovarian's are the SAME STRING,
    so recurrence is computable exactly and writing it down by hand would be a second copy of
    something already in the configs — stale the first time a pack adds a source.

    THE VENDOR EVIDENCE IS CONFOUNDED, and whoever changes this scoping should know it. Every
    Flatiron entry in the registry is `tumor_class: solid` and every COTA entry is `heme`, so the
    observation this scoping rests on — all four Flatiron packs declare `practice`, `ses`, `telemed`
    and `vitals`, neither COTA pack declares any — is equally consistent with "source keys do not
    cross VENDORS" and with "source keys do not cross SOLID/HEME". The data cannot separate them,
    and scoping on vendor may be right for the wrong reason.
    Do NOT add tumour-class scoping on top: it would double the machinery on a hypothesis with no
    supporting evidence, and `practice` would then be withheld from COTA for two reasons where at
    most one is real. The first Flatiron heme product, or COTA solid product, settles it — check
    then rather than assuming the answer is vendor. test_precedents.py carries a tripwire that fires
    on the first such pack.

    WHAT THIS DOES NOT CARRY: the physical table names. They are not stable even within one vendor
    (`t_demographics` in prostate, `t_meg_demographics` in ovarian; mortality differs in all three
    Flatiron packs), and confirming that a physical table is the RIGHT one needs a profile and a
    human at Gate 3. Proposing one would be guessing precisely what the framework refuses to guess.
    What carries across a vendor's tumours is WHICH SOURCES A PACK NEEDS, not what they are called.
    """
    out = {}
    for pack in sorted(products(root)):
        vendor = _vendor(root, pack)
        if not vendor:
            continue
        slug = _slug(pack)
        for key in _declared(root, pack):
            out.setdefault(vendor, {}).setdefault(key, {}).setdefault(slug, []).append(pack)
    return out


def source_key_proposals(pack, root=ROOT):
    """(vendor, [(key, {slug: [packs]})]) — keys this pack does not declare that OTHER TUMOURS on
    the same vendor do.

    Counted in distinct TUMOURS, not packs, and that is the lesson the decision half taught: two
    revisions of one tumour repeating themselves is the same specification being re-read, not
    evidence of anything general. Counting packs would propose `psa` and `provenge` — declared by
    prostate 202603 and 202606 — to an endometrial analyst.
    """
    vendor = _vendor(root, pack)
    if not vendor:
        return None, []
    mine = _declared(root, pack)
    slug = _slug(pack)
    todo = []
    # NOT named `tumours`: that is a module-level function now, and shadowing it here would leave
    # any later call in this scope reaching for a dict.
    for key, by_tumour in source_key_precedents(root).get(vendor, {}).items():
        if key in mine:
            continue
        others = {s: ps for s, ps in by_tumour.items() if s != slug}
        if len(others) >= MIN_TUMOURS:
            todo.append((key, others))
    return vendor, sorted(todo)


def version_drift(pack, root=ROOT):
    """{source key: [other packs]} — keys ANOTHER VERSION OF THIS TUMOUR declares and this one does not.

    A DIFFERENT QUESTION from precedent, and reported apart from it. Precedent asks what other
    TUMOURS have needed; this asks what this product's own other versions declare. The proposals
    above deliberately exclude the pack's own tumour — that exclusion is what stops `psa` and
    `provenge` being offered to an endometrial analyst — but on prostate/202606 it also hid the most
    actionable fact available: 202603 declares `ecog` and 202606 does not.

    Reported in ONE direction only, the absent one. A version that ADDS sources is the ordinary
    shape of a new spec revision (202606 adds five), so listing those would bury the one line worth
    reading under four that are not.

    It deliberately does NOT decide which version is earlier. Ordering CalVer folders looks safe
    until a pack is named `YYYYMM`, and the answer would then be asserted rather than observed —
    the packs are named in the output and a person can see which is which. Nor does it say whether
    the difference is a deliberate removal or a regression: the tool cannot tell, and only one of
    those is fine.
    """
    slug, mine, out = _slug(pack), _declared(root, pack), {}
    for other in sorted(products(root)):
        if other == pack or _slug(other) != slug:
            continue
        for key in sorted(_declared(root, other) - mine):
            out.setdefault(key, []).append(other)
    return out


def load(root=ROOT):
    """(entries, errors). A malformed store is an empty one — never a partial one."""
    doc, err = read_yaml(os.path.join(root, STORE))
    if err:
        return [], [f"{STORE}: {err}"]
    entries = doc.get("precedents") or []
    if not isinstance(entries, list):
        return [], [f"{STORE}: `precedents` must be a list"]
    return entries, []


def register(root, pack):
    """(decision rows, statuses) for a pack — through the ONE reader of that table."""
    text = read(os.path.join(root, pack, "handoff", "DECISIONS.md"))
    return decision_rows(text), decision_status(text)


def errors(root=ROOT):
    """Everything wrong with the store, as a list of sentences.

    A citation that no longer resolves is the failure this exists to catch: a decision id gets
    renamed, or a pack is restructured, and the store quietly starts pointing at nothing while still
    printing a confident-looking precedent.
    """
    entries, out = load(root)
    seen_ids = set()
    cache = {}
    for i, e in enumerate(entries):
        where = f"{STORE}[{i}]"
        pid = e.get("id")
        if not pid:
            out.append(f"{where}: no `id`")
            continue
        if pid in seen_ids:
            out.append(f"{where}: duplicate id {pid!r}")
        seen_ids.add(pid)
        if not (e.get("question") or "").strip():
            out.append(f"{pid}: no `question`")

        sightings = e.get("seen_in") or []
        if len(sightings) < MIN_SIGHTINGS:
            out.append(f"{pid}: {len(sightings)} sighting(s) — a precedent needs at least "
                       f"{MIN_SIGHTINGS}. One pack asking a question is a decision, not a precedent.")
        for s in sightings:
            pack, did = s.get("pack"), s.get("decision")
            if not pack or not did:
                out.append(f"{pid}: a sighting is missing `pack` or `decision`")
                continue
            if not os.path.isdir(os.path.join(root, pack)):
                out.append(f"{pid}: cites pack {pack}, which does not exist")
                continue
            if pack not in cache:
                cache[pack] = register(root, pack)
            rows, _ = cache[pack]
            if did not in rows:
                out.append(f"{pid}: cites {pack} decision {did!r}, which is not in its register")
    return out


def render(root=ROOT):
    entries, bad = load(root)
    lines = []
    if bad:
        lines += bad + [""]
    lines.append(f"{len(entries)} precedent(s) — questions seen on more than one pack.")
    lines.append("ADVISORY: no gate reads this. Statuses below are read live from each register.")
    lines.append("")
    cache = {}
    for e in sorted(entries, key=_by_strength):
        sightings = e.get("seen_in") or []
        lines.append(f"  {e.get('id', '?')}")
        lines.append(f"      [{corroboration(e)}]")
        lines.append(f"      {' '.join((e.get('question') or '').split())}")
        for s in sightings:
            pack, did = s.get("pack", "?"), s.get("decision", "?")
            if pack not in cache and os.path.isdir(os.path.join(root, pack)):
                cache[pack] = register(root, pack)
            rows, status = cache.get(pack, ({}, {}))
            if did not in rows:
                lines.append(f"      !! {pack}  {did}  — DOES NOT RESOLVE")
                continue
            answer = decision_answer(rows[did]) or ""
            lines.append(f"      {status.get(did, '?'):9} {pack}  {did}")
            if status.get(did) == "RESOLVED" and answer.strip():
                lines.append(f"                → {' '.join(answer.split())[:150]}")
        lines.append("")
    return "\n".join(lines)


def propose(pack, root=ROOT):
    """The precedents not yet recorded against `pack` — questions to expect, in its own words later.

    "Not yet recorded" means this pack does not appear in the entry's `seen_in`, and NOTHING CLEVERER.
    No matching of the pack's own decision wording against the store's: two registers phrase the same
    question differently on purpose (`PRACTICE-MISSING-CODE` vs `PRACTICE-NO-RECORD`), so any matcher
    good enough to pair those is also good enough to pair two questions that merely sound alike.

    The error it can make is therefore proposing something the pack has already argued out — which
    costs a reader ten seconds — rather than staying silent about something it has not, which would
    make the store actively misleading. It over-proposes, on purpose, and a person closes the loop by
    adding the sighting.
    """
    entries, bad = load(root)
    covered, todo = [], []
    for e in entries:
        packs = {s.get("pack") for s in (e.get("seen_in") or [])}
        (covered if pack in packs else todo).append(e)
    return covered, todo, bad


def _drift_lines(pack, root):
    """The version-drift section. Its own block, because it answers a different question from
    everything above it and running the two together would read as one list of proposals.

    A pack that declares NOTHING is handled apart from one that has diverged, because NOT STARTED
    and REGRESSED are different states and only one of them is a defect. prostate/202607 has no
    `config/` at all (`configuration: not_started`), so every key its siblings declare counted as
    drift: twenty-one entries, sixteen of them already listed as proposals immediately above, under
    a heading that told the reader the tool could not distinguish a removal from a regression — when
    nothing had been removed. Forty lines to say "there is no config yet".
    """
    drift = version_drift(pack, root)
    if not drift:
        return []
    L = ["", "  " + "-" * 74,
         "  VERSION DRIFT — this tumour's OTHER versions, not a precedent",
         "  " + "-" * 74]

    if not _declared(root, pack):
        _, proposed = source_key_proposals(pack, root)
        already = {k for k, _ in proposed}
        # Only what the checklist above does NOT already carry. On a pack with no config the two
        # lists otherwise overlap almost entirely, and the part worth reading is the remainder:
        # the sources only this product has ever needed, which no other tumour will propose.
        extra = {k: v for k, v in drift.items() if k not in already}
        L += ["  This pack declares no sources at all, so nothing has DRIFTED — there is no",
              "  config/ for anything to have drifted from. Not started and regressed are",
              "  different states, and only one of them is a defect.", ""]
        if not extra:
            L.append("  Every source its other versions declare is already in the checklist above.")
            return L
        L += [f"  Its other versions declare {len(drift)} key(s); {len(drift) - len(extra)} are already in that",
              f"  checklist. The remaining {len(extra)} are sources only THIS product has ever needed,",
              "  which no other tumour would propose:", ""]
        for key, packs in sorted(extra.items()):
            L.append(f"    ! {key:18} {', '.join(packs)}")
        return L

    L += [f"  {len(drift)} source key(s) another version of this product declares and this one does",
          "  not:", ""]
    for key, packs in sorted(drift.items()):
        L.append(f"    ! {key:18} {', '.join(packs)}")
    L += ["",
          "  This is NOT precedent — precedent is what OTHER tumours needed, and the proposals",
          "  above exclude this tumour on purpose. It is reported because that exclusion also hid",
          "  the most actionable thing here. The tool does not say which version came first, and",
          "  cannot tell a deliberate removal from a regression. Only one of those is fine."]
    return L


def render_proposals(pack, root=ROOT):
    covered, todo, bad = propose(pack, root)
    L = list(bad) + ([""] if bad else [])
    L.append(f"PRECEDENTS FOR {pack}")
    L.append("")
    todo = sorted(todo, key=_by_strength)
    strong = [e for e in todo if len(tumours(e)) >= MIN_TUMOURS]
    if todo:
        L.append(f"  {len(todo)} question(s) other packs have raised that are not yet recorded here:")
        L.append(f"      {len(strong)} corroborated across two or more tumours,")
        L.append(f"      {len(todo) - len(strong)} raised by one tumour so far — weaker evidence that")
        L.append("        THIS tumour will hit it, and listed second for that reason.")
    else:
        L.append("  Nothing to propose — every precedent in the store already cites this pack.")
    L.append(f"  {len(covered)} already recorded against this pack.")
    L.append("")
    # The preamble explains the list below it. Printed over an EMPTY list — which is exactly what
    # the pack that seeded the store gets — it was four paragraphs introducing nothing.
    if todo:
        L.append("  These are QUESTIONS TO EXPECT — not answers to copy. Each one was settled (or is")
        L.append("  still open) against a different tumour's specification, and the ANSWER is almost")
        L.append("  always different; what carries over is that the question needs asking, and that")
        L.append("  somebody has already worked out what makes it hard.")
        L.append("")
    cache = {}
    for e in todo:
        L.append(f"  ☐ {e.get('id', '?')}")
        L.append(f"      [{corroboration(e)}]")
        L.append(f"      {' '.join((e.get('question') or '').split())}")
        for s in (e.get("seen_in") or []):
            p, did = s.get("pack", "?"), s.get("decision", "?")
            if p not in cache and os.path.isdir(os.path.join(root, p)):
                cache[p] = register(root, p)
            _, status = cache.get(p, ({}, {}))
            L.append(f"        seen: {p}  {did}  [{status.get(did, '?')}]")
        L.append("")
    if covered:
        L.append("  Already recorded against this pack:")
        for e in covered:
            L.append(f"    ☑ {e.get('id', '?')}")
        L.append("")
    if todo:
        L.append("  Nothing here is an approval, and nothing here resolves anything. Raising one of")
        L.append("  these in the pack's own handoff/DECISIONS.md, in that specification's own terms,")
        L.append("  is the human step — then add the sighting so the next product sees it too.")

    vendor, keys = source_key_proposals(pack, root)
    L.append("")
    L.append("  " + "-" * 74)
    L.append("  SOURCE KEYS — derived from the configs, not stored")
    L.append("  " + "-" * 74)
    if not vendor:
        L.append("  This pack has no registry entry, so its vendor is unknown and nothing is")
        L.append("  proposed. A source key is only evidence within one vendor's delivery.")
        return "\n".join(L + _drift_lines(pack, root))
    if not keys:
        # "You have everything" and "there is not enough evidence yet" are different answers, and
        # only one of them is reassuring. With two COTA packs in the repo, any COTA pack has exactly
        # one other tumour to compare against — never the two a precedent needs — so a bare "you
        # already declare everything" would read as a clean bill of health where nothing was checked.
        slug = _slug(pack)
        peers = {s for k in source_key_precedents(root).get(vendor, {}).values() for s in k} - {slug}
        if len(peers) < MIN_TUMOURS:
            L.append(f"  Vendor {vendor}: only {len(peers)} other tumour(s) here to compare against"
                     f" ({', '.join(sorted(peers)) or 'none'}).")
            L.append(f"  A source-key precedent needs {MIN_TUMOURS}, so nothing is proposed — that is")
            L.append("  a lack of evidence, not a clean bill of health.")
        else:
            L.append(f"  Vendor {vendor}: this pack already declares every source key that two or")
            L.append(f"  more other {vendor} tumours declare.")
        return "\n".join(L + _drift_lines(pack, root))
    L.append(f"  {len(keys)} source key(s) that 2+ other {vendor} tumours declare and this pack")
    L.append("  does not. Sources a product of this kind has needed before:")
    L.append("")
    for key, others in keys:
        who = ", ".join(f"{s} ({len(ps)})" for s, ps in sorted(others.items()))
        L.append(f"    ☐ {key:18} {who}")
    L.append("")
    L.append("  The PHYSICAL TABLE for each is deliberately not proposed. It is not stable even")
    L.append("  within a vendor, and confirming one is the right table needs a profile and a human")
    L.append("  at Gate 3 — exactly the judgment this framework refuses to guess.")
    return "\n".join(L + _drift_lines(pack, root))


def main(argv):
    ap = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    ap.add_argument("--check", action="store_true", help="exit non-zero if any citation is broken")
    ap.add_argument("--for", dest="pack", metavar="PACK",
                    help="propose the precedents not yet recorded against this pack")
    a = ap.parse_args(argv)

    if a.pack:
        pack = os.path.relpath(os.path.abspath(a.pack), ROOT).replace(os.sep, "/")
        if not os.path.isdir(os.path.join(ROOT, pack)):
            sys.exit(f"{a.pack}: not a directory")
        print(render_proposals(pack))
        return 0

    if a.check:
        bad = errors()
        for e in bad:
            print(e)
        entries, _ = load()
        print(f"\n{len(entries)} precedent(s); {len(bad)} error(s)")
        return 1 if bad else 0

    print(render())
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
