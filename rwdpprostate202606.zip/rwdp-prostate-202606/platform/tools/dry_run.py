#!/usr/bin/env python3
"""What would block this pack if it claimed approval today — the LATENT blockers.

    python3 platform/tools/dry_run.py <pack>
    python3 platform/tools/dry_run.py --all

A gate that fires only on a claim is invisible until somebody makes the claim. prostate/202606
carried five QC findings under a second table with its own header, so their status was unreadable —
and `--check-maturity` reported zero errors for months, correctly, because the pack was not claiming
`contract: approved`. It surfaced only when the claim was simulated by hand, and it would otherwise
have surfaced mid-approval, as five errors about a table shape.

So this makes the claim on a COPY and reports what answers back. The latent set is a subtraction:

    latent = blockers when claiming both approvals  -  blockers today

Everything on the right-hand side is already known and already reported by
`source_manifest --list-releasable --why-blocked`. What is left is the work nobody has been told
about — the traps between a pack's current state and its approval.

IT WRITES NOTHING TO THE PACK. The claim is made in a temp directory that is removed on the way out,
and NOTHING here is an approval or moves any pack towards one: `maturity` is a human claim, the two
approval forms are human signatures, and a dry run has no standing in any gate. It answers "what
will bite" and nothing else.

IT COMPOSES; IT COMPUTES NOTHING. The verdict is `source_manifest.releasable` both times, on the same
inputs, differing only in the two maturity lines. A second opinion about what blocks a release is the
one thing this must not be.

stdlib only (plus PyYAML, through the tools it calls).
"""
import argparse
import os
import shutil
import sys
import tempfile
import textwrap

TOOLS = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(os.path.dirname(TOOLS))
sys.path.insert(0, TOOLS)

import product_gates    # noqa: E402
import source_manifest  # noqa: E402

WIDTH = 94
MATURITY = os.path.join("handoff", "MATURITY.yaml")


def _stage(pack, root=ROOT):
    """A throwaway repo holding this pack plus the little the gates read outside it.

    A copy rather than an edit, because the alternative is writing `approved` into a governed
    maturity claim in the real tree and trusting a finally-block to take it out again. The gates
    resolve the registry and the shared product assets from the repo root, so those come too.
    """
    # `pack` MUST be root-relative. `os.path.join(tmp, "/abs/path")` discards `tmp` and returns the
    # absolute path, so an absolute argument aimed this function's copytree AND the `approved` write
    # below at the REAL pack. Nothing was lost only because copytree raises on an existing
    # destination — the sandbox was defeated by an argument, and the error named the governed
    # directory rather than the caller. Refused explicitly: this is the one function here that
    # writes, and where it writes must not depend on how the caller spelled a path.
    if os.path.isabs(pack) or pack.startswith(".."):
        raise ValueError(f"dry_run needs a ROOT-RELATIVE pack path, got {pack!r} — an absolute path "
                         f"escapes the temp copy and stages onto the real pack")
    tmp = tempfile.mkdtemp(prefix="rwdp-dryrun-")
    dst = os.path.join(tmp, pack)
    if not os.path.abspath(dst).startswith(os.path.abspath(tmp) + os.sep):
        raise ValueError(f"refusing to stage outside the temp copy: {dst}")
    os.makedirs(os.path.dirname(dst), exist_ok=True)
    shutil.copytree(os.path.join(root, pack), dst)
    os.makedirs(os.path.join(tmp, "platform"), exist_ok=True)
    for rel in ("products/registry.yaml",):
        src = os.path.join(root, rel)
        if os.path.exists(src):
            os.makedirs(os.path.dirname(os.path.join(tmp, rel)), exist_ok=True)
            shutil.copy(src, os.path.join(tmp, rel))
    meta = os.path.join(root, "products", "metadata")
    if os.path.isdir(meta):
        shutil.copytree(meta, os.path.join(tmp, "products", "metadata"), dirs_exist_ok=True)
    return tmp, dst


def latent(pack, root=ROOT):
    """(current blockers, latent blockers, note) — what claiming approval would newly reveal.

    `note` is not None when the answer could not be computed, and it is a REFUSAL rather than an
    empty list: "nothing latent" and "nothing was checked" are opposite answers, and a pack with no
    maturity file to claim on is the second.
    """
    if not os.path.exists(os.path.join(root, pack, MATURITY)):
        return [], [], "no handoff/MATURITY.yaml — there is no claim to make, so nothing was checked"

    _ok, current = source_manifest.releasable(root, pack)
    tmp, dst = _stage(pack, root)
    try:
        with open(os.path.join(dst, MATURITY), "w", encoding="utf-8") as fh:
            fh.write("contract: approved\nconfiguration: approved\n")
        _ok2, claimed = source_manifest.releasable(tmp, pack)
    finally:
        shutil.rmtree(tmp, ignore_errors=True)

    # A plain subtraction, and it needs no special case for the two "contract is X, not approved"
    # lines: making the claim is exactly what stops them firing, so they are absent from `claimed`
    # rather than present-and-unwanted. An earlier version filtered them by prefix, which read as
    # load-bearing and matched nothing on any pack — dead code wearing a comment that explained
    # why it mattered.
    known = set(current)
    new = [b for b in claimed if b not in known]
    return current, new, None


def _bullet(mark, text, indent=5):
    """A blocker, wrapped rather than cut. The message IS the payload — it names the artifact, the
    count and often the command to run — so truncating it to fit a column removes the only part
    worth printing. An earlier draft clipped at the width and turned `13 unaccounted spec row(s)`
    into `13 unaccounted spe`."""
    body = " ".join(str(text).split())
    lines = textwrap.wrap(body, width=WIDTH - indent - 2)
    return [f"{' ' * indent}{mark} {lines[0]}"] + [f"{' ' * (indent + 2)}{l}" for l in lines[1:]]


def render(pack, root=ROOT):
    current, new, note = latent(pack, root)
    L = ["", "=" * WIDTH, f"  DRY-RUN APPROVAL CHECK — {pack}", "=" * WIDTH,
         "  Simulated on a copy. Nothing was written to the pack, and this is not an approval.", ""]
    if note:
        L += [f"  {note}", ""]
        return "\n".join(L)

    L.append(f"  Blocked today by {len(current)} thing(s) — already reported by --why-blocked:")
    for b in current:
        L += _bullet("·", b)
    L.append("")
    if not new:
        L += ["  " + "-" * (WIDTH - 4),
              "  NOTHING LATENT. Claiming both approvals reveals no further blocker: the list",
              "  above is the whole distance. That is the healthy answer.", ""]
        return "\n".join(L)

    L += ["  " + "-" * (WIDTH - 4),
          f"  {len(new)} LATENT blocker(s) — these appear only once the claim is made, and are",
          "  what would surface mid-approval:", ""]
    for b in new:
        L += _bullet("!", b)
    L += ["",
          "  Some of these need something from outside the repository (an approved workbook, a",
          "  profile of the live feed, a signature). Others are defects in the pack's own files",
          "  and can be fixed now — the wording tells you which.", ""]
    return "\n".join(L)


def render_all(root=ROOT):
    packs = sorted(product_gates.products(root))
    L = ["", "=" * WIDTH, "  DRY-RUN APPROVAL CHECK — every discovered pack", "=" * WIDTH,
         "  Simulated on copies. Nothing was written, and none of this is an approval.", ""]
    worst = 0
    for pack in packs:
        current, new, note = latent(pack, root)
        if note:
            # Not clipped either. "no MATURITY.yaml — there is no c" reads as a broken tool rather
            # than as the reason a pack was skipped.
            L.append(f"   {'—':>3}   {pack}")
            L += _bullet("·", note, indent=10)
            continue
        worst += len(new)
        mark = "ok " if not new else "!! "
        L.append(f"   {mark}  {pack:<42} {len(current):>2} today   {len(new):>2} latent")
        for b in new:
            L += _bullet("!", b, indent=10)
    L += ["", f"  {worst} latent blocker(s) across {len(packs)} pack(s).", ""]
    return "\n".join(L)


def main(argv):
    ap = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    ap.add_argument("pack", nargs="?", help="the pack to check (repo-root-relative)")
    ap.add_argument("--all", action="store_true", help="check every discovered pack")
    a = ap.parse_args(argv)
    if a.all:
        print(render_all())
        return 0
    if not a.pack:
        sys.exit("name a pack, or pass --all")
    pack = os.path.relpath(os.path.abspath(a.pack), ROOT).replace(os.sep, "/")
    if not os.path.isdir(os.path.join(ROOT, pack)):
        sys.exit(f"{a.pack}: not a directory")
    print(render(pack))
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
