#!/usr/bin/env python3
"""A structured record in, the canonical contract row out — with the round-trip proved.

The drafting skill used to ask the model to assemble the markdown row itself: put every field in
`TABLE_COLUMNS` order, escape any literal `|`, fold embedded newlines, and produce exactly the right
number of cells. Four mechanical rules, applied by hand, in a file where ONE unescaped pipe shifts
every later field into the wrong key — and where each shifted cell is still individually well-formed,
so no invariant sees it. At one record that is a nuisance; at a portfolio of several hundred per
product it is a defect generator, and the reviewer who reads the diff cannot reliably catch it.

So the model writes what it actually knows — field names and values — and this does the mechanics:

    python3 platform/tools/contract_record.py draft.yaml            # -> the row on stdout
    python3 platform/tools/contract_record.py draft.yaml --product products/oncology/oc/202606

`draft.yaml` is a mapping of contract field -> value; several records go under a `records:` key.
Values may be plain strings already in the contract's inline notation, or real YAML structures — `source: {kind: vendor, inputs:
{...}}` works either way, because `contract_lint.inline` serializes them to the same text.

WHAT IT PROVES, every time, which is the point of doing this in code:

  * every key is a real contract field (an unknown one is an error, never dropped silently)
  * the row has exactly `len(TABLE_COLUMNS)` cells, checked with the lint's own splitter
  * every field ROUND-TRIPS: re-parsed out of the rendered row it is byte-identical to what went in

That last check is what makes this trustworthy rather than merely convenient. A renderer nobody
verifies is a second notation; this one is compared against the reader on every invocation.

With `--product` it also runs the record through the real invariants, so a draft that would fail
Gate 2 says so here rather than after it is pasted into a governed file.
"""
import argparse
import json
import os
import re
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

import contract_lint as cl                                          # noqa: E402
import product_gates as pg                                          # noqa: E402

# The status values a DRAFT may start at — an ALLOWLIST, per axis. Everything else on these axes
# records a HUMAN transition backed by evidence: somebody read the data dictionary, somebody compared
# the live schema, somebody accepted the profile. `contract_lint` accepts any value in its vocabulary
# on a structurally complete record, so on a mature pack a model could set `requirement: approved` and
# nothing would object; the skill has said "never write these" since its first version, which made the
# rule a sentence in a prompt.
#
# IT WAS A BLACKLIST — `HUMAN_ONLY`, naming the seven values a drafter may not set. That fails OPEN on
# the one event most likely to happen: `contract_lint` gaining an eighth. `FINE_SOURCE_AXES` was itself
# added after the coarse `source` axis, and `data_profile_check: reviewed` after that; each time, a
# blacklist would have kept passing while a new human verdict became assertable by a drafter, and
# nothing would have gone red. An allowlist refuses an unrecognised value by default, and
# `test_contract_lint` asserts every value in every vocabulary is on exactly one side of this line —
# so adding one to the lint fails a test until somebody decides which it is.
#
# Keyed by the status axis so the message can name what the value would be CLAIMING. The vocabularies
# themselves stay in `contract_lint`; this says which subset a machine may author, and the test holds
# the two together. `implementation` is deliberately absent: it is a fact about the code, checkable by
# reading it, not a verdict anyone signs.
DRAFTABLE = {
    "requirement":        {"draft", "decision_required"},
    "source":             {"unverified", "dictionary_only", "unavailable"},
    "source_mapping":     {"proposed"},
    "dictionary_check":   {"not_run", "failed", "not_available"},
    "live_schema_check":  {"not_run", "failed"},
    "data_profile_check": {"not_run", "issue_open"},
    "validation":         {"not_run", "failed", "passed_test", "passed_synthetic"},
}

# THE STATUS OF A NEW RECORD, injected rather than accepted. The allowlist above was the second
# attempt and is still the wrong shape: `failed`, `passed_test`, `issue_open`, `dictionary_only` are
# all inside it, and all four are EVIDENCE CLAIMS — statements that a check ran and came back a
# certain way. A drafter has no basis for any of them. It has read a specification row; it has not run
# a test, opened a dictionary or looked at a profile.
#
# So a NEW record does not carry `status` at all, and this is what it gets. A REVISION keeps whatever
# the existing record holds, because moving a status is an evidence transition somebody else makes.
# That leaves the model with no reason to reason about status, which is the point: the safest field is
# the one nobody has to be trusted with.
INITIAL_STATUS = {"requirement": "draft", "source": "unverified",
                  "implementation": "not_implemented", "validation": "not_run"}


def _status_map(record):
    """The record's `status` as a dict, whichever notation it is written in, or None when absent."""
    status = record.get("status")
    if isinstance(status, str):
        # the inline notation the contract stores: `{requirement: draft, source: unverified, ...}`
        return {k.strip(): v.strip() for k, v in
                (p.split(":", 1) for p in status.strip("{} ").split(",") if ":" in p)}
    return status if isinstance(status, dict) else None


def apply_status(record, current=None):
    """(record with `status` settled, [problems]) — the tool owns the field, not the drafter.

    Three cases, and none of them is "the model chose":

      * the drafter supplied none and there is no existing record -> INITIAL_STATUS;
      * the drafter supplied none and a record EXISTS            -> keep what the record holds,
        because a status transition is an evidence decision made elsewhere;
      * the drafter supplied one                                 -> refuse it, and say which.

    Refusing rather than silently overwriting: a drafter that wrote a status meant something by it, and
    quietly replacing the value would hide a disagreement about what the record claims. The message is
    the useful half.
    """
    given = _status_map(record)
    if given is not None:
        return record, [
            f"status is not yours to write. A draft gets {INITIAL_STATUS} and a revision keeps the "
            f"status the existing record already holds — moving it is an evidence transition an "
            f"accountable person makes in the governed file, under the review CODEOWNERS routes. "
            f"Remove `status` from the draft."]
    settled = dict(current) if current else dict(INITIAL_STATUS)
    return {**record, "status": "{" + ", ".join(f"{k}: {v}" for k, v in settled.items()) + "}"}, []


def human_only_errors(record):
    """[problems] for any status value a DRAFT may not start at. Empty for an ordinary draft.

    Note what this is NOT. `--actor human` does not make these legal because a flag cannot establish
    who is running a process — the same caller that would misreport the value also passes the flag.
    What governs a human transition is that it lands in `FUNCTIONAL_CONTRACT.md`, which CODEOWNERS
    routes for review; this refuses the shape by default so that reaching it takes a deliberate act
    somebody has to name.
    """
    status = record.get("status")
    if isinstance(status, str):
        # the inline notation the contract stores: `{requirement: draft, source: unverified, ...}`
        status = {k.strip(): v.strip() for k, v in
                  (p.split(":", 1) for p in status.strip("{} ").split(",") if ":" in p)}
    if not isinstance(status, dict):
        return []
    out = []
    for axis, allowed in DRAFTABLE.items():
        value = str(status.get(axis, "")).strip()
        if value and value not in allowed:
            out.append(f"status.{axis}: {value} is not a value a DRAFT may start at "
                       f"({', '.join(sorted(allowed))}). It records a human transition backed by "
                       f"evidence, or it is not a value this axis takes at all. Draft at the initial "
                       f"value and let the accountable person move it, in the governed file, under "
                       f"the review CODEOWNERS routes.")
    return out


def row_for(record, allow_partial=False):
    """(row, [problems]) — the canonical row, and anything wrong with it.

    COMPLETE BY DEFAULT. The first version compared only the keys the caller supplied, so a record
    missing half the canonical fields rendered to empty cells and reported nothing — a governed draft
    silently short of the schema, which the real I6 would have caught but only when `--product` was
    passed, and that flag was documented as optional. A partial record is not a successful default.

    `allow_partial` exists for renderer testing, where the point is one field's escaping rather than a
    whole record. It is not for drafting.
    """
    row = cl.render_row(record)                       # raises on an unknown field
    cells = re.split(r"(?<!\\)\|", row.strip())[1:-1]
    problems = []
    if not allow_partial:
        missing = [k for k in cl.TABLE_COLUMNS if not str(record.get(k, "")).strip()]
        if missing:
            problems.append(f"incomplete: no value for {', '.join(missing)} — every canonical field "
                            f"is answered or the record is not one. `n/a` and `[]` are answers; "
                            f"absent is not")
    if len(cells) != len(cl.TABLE_COLUMNS):
        problems.append(f"rendered {len(cells)} cells for {len(cl.TABLE_COLUMNS)} columns")

    # THE round-trip. Re-read the row through the same parser every gate uses, and compare field by
    # field against what the caller supplied. A renderer checked only by eye is a second notation.
    back = list(cl.records(cl.render_table([record])))
    if len(back) != 1:
        problems.append(f"the rendered table re-parsed as {len(back)} records, not 1")
        return row, problems
    parsed = {ln.split(":", 1)[0]: ln.split(":", 1)[1].strip()
              for ln in back[0].splitlines() if ":" in ln}
    for key, value in record.items():
        want = cl.pipe(cl.inline(value))              # folded and escaped, as the cell will hold it
        want = cl._unpipe(want).strip()               # ...and unescaped again, as a reader sees it
        got = parsed.get(key, "")
        if want and got != want:
            problems.append(f"{key} did not round-trip: wrote {want!r}, read back {got!r}")
    return row, problems


def merge_evidence(record, product, item_id=None):
    """(record with the spec's own fields filled in, [problems]) — the scaffold supplies the evidence.

    THE INTERFACE CHANGE THIS EXISTS FOR. `spec_refs`, `spec_digest` and `required_rule` are established
    by the spec pipeline, and the skill has always said so: "pass them through, never author them". But
    the tool accepted the whole record from the model, so that rule was a sentence in a prompt. A model
    that retypes a digit of the digest fails I15 with a message about hashing; one that tidies
    `required_rule` into better English replaces the spec's exact words with a paraphrase and nothing
    fails at all — the record reads well and no longer says what RWB wrote.

    So the drafter supplies JUDGMENT only, names the row, and this fills the rest in from
    `contract_scaffold.evidence_for`. Supplying a machine-owned field is an ERROR rather than an
    override: an override is how the rule comes back to being advisory.
    """
    import contract_scaffold as cs                                    # noqa: E402
    supplied = [k for k in cs.MACHINE_OWNED if k in record]
    if item_id is None:
        # No --item: the caller is passing evidence through by hand. LEGAL ONLY for a pack with no
        # extraction, and `main` enforces that — a generic no-item path was a bypass straight around
        # this whole function, since `--product` alone let a drafter hand-write `required_rule` and
        # only a wrong DIGEST would have been caught.
        return record, []
    if supplied:
        return record, [f"machine-owned field(s) {', '.join(supplied)} supplied alongside --item "
                        f"{item_id} — these come from the spec, not from the drafter. Remove them; "
                        f"the tool fills them in from the extraction."]
    try:
        evidence = cs.evidence_for(product, item_id)
    except (KeyError, OSError) as exc:
        return record, [str(exc)]
    # A REDACTED ROW MAY NOT BE DRAFTED HERE AT ALL. The cell reproduced vendor documentation and was
    # removed from the artifact AI reads; the rule survives only in the pack's restricted reference
    # material. The slice already SAYS so, and saying so is a prompt instruction — a model can still
    # produce a complete-looking judgment over the row and pass every invariant, because
    # `VENDOR_REDACTED` is deliberately not in I17's unsettled set (it means the spec DOES settle
    # this, elsewhere). Refusing here is the mechanical half.
    if any("VENDOR DOCUMENTATION REDACTED" in str(v) for v in evidence.values()) \
            or "VENDOR_REDACTED" in " ".join(evidence.get("_lint_flags") or []):
        return record, [
            f"{item_id} carries VENDOR_REDACTED: its rule reproduced vendor documentation and is not "
            f"in this artifact. No drafted record may be rendered from it. An authorized human must "
            f"review the restricted reference material and maintain this record separately."]
    # EVIDENCE LAST, so it wins. The guard above is the control — a machine-owned field in the draft
    # is an error and never reaches here — and this is defence in depth behind it: if that guard is
    # ever loosened, the failure mode becomes "the drafter's value is ignored" rather than "the
    # drafter's paraphrase silently replaces the spec's words", and only one of those is survivable.
    merged = dict(record)
    merged.update({k: v for k, v in evidence.items() if not k.startswith("_")})
    return merged, []


def load(path):
    """The draft, as a list of record mappings.

    Through `product_gates.read_yaml` — the ONE reader of a governed YAML file — not a local
    `yaml.safe_load`. The repo's own guard caught this file doing the latter, and the reason is worth
    stating: PyYAML raises a plain ValueError from inside its date constructor on something like
    `classified_date: 2026-13-45`, so a per-caller `except yaml.YAMLError` reports a defect in the
    input as a crash of the tool. A drafting model's output is exactly where malformed YAML arrives.

    `read_yaml` requires a MAPPING root, which is why several records go under a `records:` key rather
    than as a bare list — one accepted shape, and the one the shared reader already guarantees.
    """
    doc, err = pg.read_yaml(path)
    if err:
        raise SystemExit(f"{path}: {err}")
    if "records" in doc:
        recs = doc["records"]
        if not isinstance(recs, list) or not all(isinstance(d, dict) for d in recs):
            raise SystemExit(f"{path}: `records:` must be a list of field mappings")
        return recs
    return [doc]


def main(argv):
    ap = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    ap.add_argument("draft", help="YAML mapping of contract field -> value; several under a `records:` key")
    ap.add_argument("--product", help="the pack. REQUIRED for drafting — see --format-only.")
    ap.add_argument("--item", help="the spec row this record is drafted from, `<domain>:<row>`. The "
                                   "spec's own fields (spec_refs, spec_digest, required_rule) are then "
                                   "filled in from the extraction and REFUSED in the draft.")
    ap.add_argument("--legacy-no-extraction", action="store_true",
                    help="the pack has no spec_pipeline extraction, so the evidence fields must be "
                         "passed through by hand. Refused when an extraction exists.")
    # `--actor` IS GONE. It declared who was authoring and could not establish it — the same caller
    # that would misreport it also passed it — so it read as an authorization check while being a
    # string. With status owned by the tool there is nothing for it to gate: a draft cannot write a
    # status at all, and moving one is done in the governed file under review.
    ap.add_argument("--format-only", action="store_true",
                    help="render and round-trip WITHOUT a pack: no invariants, no evidence merge. For "
                         "renderer testing and for a pack with no extraction. Not for governed "
                         "drafting — I8, I15, I17 and every pack-specific rule are skipped.")
    ap.add_argument("--table", action="store_true", help="emit a full table with header, not bare rows")
    ap.add_argument("--json", action="store_true", help="emit {row, problems} as JSON")
    ap.add_argument("--allow-partial", action="store_true",
                    help="renderer testing only: skip the completeness check. Not for drafting.")
    a = ap.parse_args(argv)

    # `--product` WAS OPTIONAL, AND THE SKILL DOCUMENTED IT IN BRACKETS. Completeness and the
    # round-trip run without it, which is what made that look sufficient — but I8 (do the cited rows
    # exist), I15 (does the digest still match), I17 (is an unsettled row answered), the decision and
    # gap reference checks and every other pack-specific invariant need the pack. A drafter following
    # the documented command got a clean-looking record that no gate had seen. So the pack is now the
    # default and its absence is a deliberate, named choice.
    if not a.product and not a.format_only:
        ap.error("--product is required for drafting: without it the record is only checked for shape, "
                 "and I8/I15/I17 — the invariants that catch a hallucinated citation, a stale digest "
                 "and an answered-but-unsettled row — never run. Pass --format-only to render without "
                 "a pack and accept that.")
    if a.item and not a.product:
        ap.error("--item needs --product: the spec evidence comes from that pack's extraction.")
    # --item IS REQUIRED WHENEVER THE PACK CAN SUPPLY EVIDENCE. Making it optional left the entire
    # machine-owned-field boundary opt-in: `--product` alone accepted a hand-written `spec_refs`,
    # `spec_digest` and `required_rule`, and only a wrong digest would have failed. A paraphrased
    # `required_rule` — the failure this interface exists to stop — passed silently.
    if a.product and not a.item and not a.legacy_no_extraction:
        if os.path.exists(os.path.join(a.product, "spec_pipeline", "out", "extracted.json")):
            ap.error("--item is required for a pack with an extraction: it is what supplies "
                     "spec_refs, spec_digest and required_rule from the spec instead of accepting "
                     "them from the drafter. Pass --item <domain:row>. "
                     "--legacy-no-extraction is the named opt-out, and is only honest for a pack "
                     "that genuinely has none.")
    if a.legacy_no_extraction and a.product and \
            os.path.exists(os.path.join(a.product, "spec_pipeline", "out", "extracted.json")):
        ap.error("--legacy-no-extraction was passed for a pack that HAS an extraction — the flag says "
                 "the evidence cannot be supplied, and here it can. Use --item.")

    records = load(a.draft)
    if a.item and len(records) != 1:
        raise SystemExit(f"--item names ONE spec row; this draft holds {len(records)} records. "
                         f"One record per spec row (I16) — run them separately.")
    # STATUS FIRST, before anything is rendered — a refusal after the row is printed is no refusal at
    # all, because a printed row gets pasted. The tool SETTLES the field: a new record gets
    # INITIAL_STATUS, a revision keeps what the existing record holds, and a drafter that wrote one is
    # told it is not theirs to write.
    settled = []
    for i, rec in enumerate(records):
        current = None
        contract = os.path.join(a.product or "", "handoff", "FUNCTIONAL_CONTRACT.md")
        if a.product and rec.get("variable_id") and os.path.exists(contract):
            # `cl.records` takes the TEXT, and this passed it the PATH — so it parsed a filename as a
            # contract, yielded nothing, and `existing` was None for every record that has ever
            # existed. The consequence is the exact opposite of what the comment above promises: a
            # REVISION did not keep the status the record holds, it got INITIAL_STATUS. Revising a
            # record at `requirement: approved, implementation: implemented` silently rewrote it to
            # `draft` / `not_implemented` — a human evidence claim erased by a tool that says, three
            # lines up, that moving one is not the drafter's to do.
            #
            # It hid behind a second bug: `records()` yields BLOCK TEXT, so `r.get(...)` would have
            # raised AttributeError — but the generator was empty, so the line never ran. Two errors
            # that cancel to a silent wrong answer, and the revision test asserts rc == 0 and
            # no-duplication, so it passed against both.
            existing = next((r for r in cl.records(cl.read(contract))
                             if (cl._scalar(r, "variable_id") or "").strip()
                             == str(rec["variable_id"]).strip()), None)
            current = _status_map({"status": cl._inline(existing, "status")}) if existing else None
        rec, bad = apply_status(rec, current)
        if bad:
            raise SystemExit(f"{a.draft}[{i}]: " + "; ".join(bad))
        settled.append(rec)
    records = settled

    if a.product:
        merged = []
        for i, rec in enumerate(records):
            import contract_scaffold as cs                                          # noqa: E402
            try:
                rec, bad = merge_evidence(rec, a.product, a.item)
            except cs.NotApprovedForAI as exc:
                # NOT folded into `bad`. A problem list is a report the caller reads and may act on;
                # this is a refusal, and the difference has to survive to the exit code. Raised from
                # `contract_scaffold.ai_gate`, which is where the spec's words are lifted — see there
                # for why the check is not in this function.
                raise SystemExit(str(exc))
            if bad:
                raise SystemExit(f"{a.draft}[{i}]: " + "; ".join(bad))
            merged.append(rec)
        records = merged
    rows, problems = [], []
    for i, rec in enumerate(records):
        try:
            row, bad = row_for(rec, a.allow_partial)
        except ValueError as exc:                     # an unknown field: name it and stop
            raise SystemExit(f"{a.draft}[{i}]: {exc}")
        rows.append(row)
        problems += [f"[{rec.get('variable_id', i)}] {b}" for b in bad]

    if a.product:
        # The real invariants, on a throwaway copy of the pack — so `--product` answers "would this
        # pass Gate 2 HERE", not "is it well-formed anywhere".
        #
        # REPLACE, don't append, when the id already exists. Appending was right for a new record and
        # wrong for the revision case the skill explicitly supports: the temp copy then held two
        # records with one variable_id, so a perfectly valid replacement failed I1 as a duplicate and
        # the tool refused the thing it was built to check.
        import shutil
        import tempfile
        ids = [str(r.get("variable_id", "")).strip() for r in records]
        dupes = sorted({i for i in ids if i and ids.count(i) > 1})
        if dupes:
            raise SystemExit(f"{a.draft}: variable_id {', '.join(dupes)} appears more than once in "
                             f"this draft — one record per variable_id")
        tmp = tempfile.mkdtemp()
        dst = os.path.join(tmp, os.path.basename(os.path.abspath(a.product)))
        shutil.copytree(a.product, dst)
        contract = os.path.join(dst, "handoff", "FUNCTIONAL_CONTRACT.md")
        with open(contract, encoding="utf-8") as fh:
            text = fh.read()
        existing = {}
        for line in text.splitlines():
            m = re.match(r"\|\s*([A-Za-z0-9_]+)\s*\|", line)
            if m and m.group(1) in ids:
                existing[m.group(1)] = line
        for rec, vid in zip(records, ids):
            if vid in existing:
                text = text.replace(existing[vid], cl.render_row(rec))
        fresh = [r for r, v in zip(records, ids) if v not in existing]
        if fresh:
            text += "\n" + cl.render_table(fresh)
        with open(contract, "w", encoding="utf-8", newline="\n") as fh:
            fh.write(text)
        errors, _ = cl.run(dst)
        shutil.rmtree(tmp, ignore_errors=True)
        problems += [e for e in errors if any(f"[{v}]" in e for v in ids if v)]

    if a.json:
        print(json.dumps({"rows": rows, "problems": problems}, indent=1))
    else:
        sys.stdout.write(cl.render_table(records) if a.table else "\n".join(rows) + "\n")
        for p in problems:
            print(f"  PROBLEM {p}", file=sys.stderr)
    return 1 if problems else 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
