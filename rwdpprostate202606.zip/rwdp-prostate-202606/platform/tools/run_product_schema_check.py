#!/usr/bin/env python3
"""Build-preflight LIVE SCHEMA validation for ANY pack — one checker for every tumour.

    python3 platform/tools/run_product_schema_check.py products/oncology/prostate/202606 \
        --cut 2026m06 --schema <delivered schema> --out-dir $HOME/restricted/prostate-202606

Confirms that every configured source table (config `sources:`) and every column the build REQUIRES
(`engine.validate.required_columns()`) exists in the delivered schema; records the OPTIONAL configured
columns (present/absent) and each column's OBSERVED TYPE; writes machine- and human-readable evidence.

This is EVIDENCE, not approval. A green report establishes `schema_presence: passed_live` — ONE input
to source verification. It does not by itself move any contract row to `source: verified`: that also
needs the value profile, targeted grain / join / duplicate / window / tie checks, and RWP review.

Why this replaced products/oncology/prostate/202606/profile/validate_schema.py. That script resolved
its config with `product_config(root, "prostate")` — through the REGISTRY — so the day
`current_spec_version` becomes 202607, a validator stored in the 202606 pack would validate the 202607
config while writing its evidence into the 202606 folder. It also defaulted its output beside itself,
inside the checkout, though the report carries physical vendor identifiers and observed types. And
HNSCC, GIST, SCLC and DLBCL would each have needed their own copy. This takes the PACK PATH, reads the
config beside it, requires an output root outside the checkout, and handles source unions.

Source-union packs. A schema report covers ONE member schema. `--member <schema>` does one,
`--all-members` iterates every declared member, each writing to its own directory — the same
`<out-dir>/<product_id>/<schema>/<cut>/` layout the profile runner uses, so Gate 4 finds both pieces
of evidence for one member without a second convention.

RUNS ON DATABRICKS (a Spark cluster with the source schema attached). The value profiler is a
DIFFERENT runtime (DBI/ODBC) — see run_product_profile.py.

stdlib + PyYAML; needs PySpark at run time.
"""
import argparse
import json
import os
import subprocess
import sys
from datetime import datetime, timezone

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import pack_run                                                      # noqa: E402
from product_gates import delivery_sha256                            # noqa: E402 — ONE digest
from engine import validate                                          # noqa: E402


def git_commit():
    try:
        return subprocess.check_output(["git", "-C", pack_run.CHECKOUT, "rev-parse", "HEAD"],
                                       stderr=subprocess.DEVNULL).decode().strip()
    except Exception:  # noqa: BLE001 - best-effort provenance; a Databricks checkout may not be a repo
        return None


def spark_reader():
    """A {column: type} reader over live tables, or exit with what to do about it.

    Observed TYPES, not just names: a Boolean-vs-string progression field has to be visible in the
    evidence rather than silently assumed.
    """
    try:
        from pyspark.sql import SparkSession
    except Exception as e:  # noqa: BLE001 - live-data tool; only runs on a cluster
        sys.exit(f"This validator reads live tables — run it on a Databricks cluster with the source "
                 f"schema attached. PySpark unavailable here: {e}")
    spark = SparkSession.builder.getOrCreate()
    return lambda fqn: {f.name: f.dataType.simpleString() for f in spark.table(fqn).schema.fields}


def main(argv=None):
    ap = argparse.ArgumentParser(description="Validate one pack's live source schema for a cut.")
    ap.add_argument("pack", help="e.g. products/oncology/prostate/202606")
    ap.add_argument("--out-dir", help="restricted output ROOT, outside the checkout (required to run)")
    ap.add_argument("--cut", default=os.environ.get("DC_CUT"), help="delivered refresh, e.g. 2026m06")
    ap.add_argument("--schema", default=os.environ.get("DC_SCHEMA"), help="delivered source schema")
    ap.add_argument("--member", help="source_union member schema to validate (one run, one member)")
    ap.add_argument("--all-members", action="store_true", help="validate every declared union member")
    a = ap.parse_args(argv)

    pack = os.path.abspath(a.pack)
    pack_run.config_path(pack)
    pack_run.require_cut(a.cut)
    schemas = pack_run.targets(pack, a)

    if not a.out_dir:
        sys.exit("--out-dir is REQUIRED and must be outside the checkout.\n"
                 "The schema report names physical vendor tables and columns with their observed\n"
                 "types, so it must not be written into the repository working tree.\n"
                 "e.g. --out-dir $HOME/restricted/"
                 + "-".join(pack.replace(os.sep, "/").rsplit("/", 2)[-2:]))
    root = pack_run.restricted_dir(a.out_dir, what="schema evidence")

    reader = spark_reader()
    rc = 0
    for schema in schemas:
        cfg = pack_run.pack_config(pack, a.cut, schema)
        pid = pack_run.product_id(cfg, pack)

        # Static config lint BEFORE touching Spark — a broken config should fail cheaply, not mid-read.
        probs = validate.problems(cfg, strict=False)
        if probs:
            print(f"ERROR: {pid} config does not lint clean — fix these before a live run:")
            for p in probs:
                print(f"  - {p}")
            return 2

        print(f"Resolved: {cfg.data_product_id}  spec={cfg.spec_version}  cut={a.cut}  "
              f"schema={schema}  format={cfg.data_format}\n")
        # Scope to THIS member. Without it the report labelled member A inspects every member,
        # so neither report is the member-specific evidence Gate 4 checks it as.
        members = pack_run.union_members(pack)
        report = validate.preflight_report(cfg, reader,
                                           member_schema=schema if members else None)
        evidence = validate.preflight_evidence(
            cfg, report,
            generated_at=datetime.now(timezone.utc).isoformat(timespec="seconds"),
            git_commit=git_commit())
        # Same identity the profile TSV carries, for the same reason: a report that does not say which
        # product, member and cut it measured cannot be checked against the claim made for it.
        evidence["product_id"] = pid
        evidence["source_schema"] = schema
        evidence["cut"] = a.cut
        # ...and WHICH config resolved these tables. Product, schema and cut can all be unchanged
        # while a config edit moves the table scope, so Gate 4 pins this against the verdict's own
        # config hash to catch a report that is correct about its subject but stale about its scope.
        # The DELIVERY digest — the same one source_check records — so `data_format` selecting a
        # different `formats:` overlay moves it. Hashing the root file alone stopped covering that
        # the day `run:` moved to config/pipeline.yaml.
        evidence["config_sha256"] = delivery_sha256(pack)

        out_dir = pack_run.evidence_dir(root, pid, schema, a.cut)
        json_path = os.path.join(out_dir, f"SCHEMA_VALIDATION_{a.cut}.json")
        md_path = os.path.join(out_dir, f"SCHEMA_VALIDATION_{a.cut}.md")
        with open(json_path, "w", encoding="utf-8") as fh:
            json.dump(evidence, fh, indent=2)
        md = validate.preflight_report_md(report)
        with open(md_path, "w", encoding="utf-8") as fh:
            fh.write(md)
        print(md)
        print(f"\nwrote {json_path} and {md_path}  "
              f"(schema_presence={evidence['schema_presence']})")
        rc |= 0 if report["ok"] else 1
    return rc


if __name__ == "__main__":
    sys.exit(main())
