#!/usr/bin/env python3
"""What a new spec revision ACTUALLY changed — and which records can carry forward.

    python3 platform/tools/spec_diff.py <old pack> <new pack>

WHY THIS EXISTS. prostate/202607 holds 200 spec rows and prostate/202606 holds 200; 196 of them are
BYTE-IDENTICAL and none changed. It is the same specification one revision later. It was nonetheless
re-extracted from scratch, re-drafted into 199 records, and its 22 decisions were raised under new
ids — only 6 ids are shared, and NEITHER of the two answers 202606 had settled carried across. The
questions recurred, the answers did not, and the only thing bridging the two versions is a
hand-curated store where seven of nine entries read "prostate, prostate".

That is the cost of having no reuse: a revision that changed nothing cost a full re-draft.

THE PROOF IS ALREADY IN THE RECORD. `spec_digest` is a digest over `item_id + content_hash` for
every cited row — it binds a record to the specification TEXT, not to a row number, which is exactly
why I15 catches an edit made in place. So the question "may this record carry forward" is already
answerable with evidence: recompute the record's digest against the NEW extraction and see whether
it still matches. Nothing here re-derives that; `contract_lint.spec_digest` is the one definition and
this calls it.

THREE ANSWERS, and the distinction between the last two is the point:

  CARRIES AS-IS        the digest recomputes identical — the cited text is unchanged
  CARRIES, NEW REF     the cited text still exists but has MOVED to a different row number, so the
                       record needs `spec_refs` updated and nothing else. Rows shift whenever a
                       revision inserts anything above them, and a tool that called this "changed"
                       would send a person to re-read text that is word-for-word the same.
  RE-DRAFT             the cited text changed, or is gone

FAIL-CLOSED: anything whose digest cannot be computed is RE-DRAFT, never carried. A record wrongly
carried forward is a requirement nobody re-read, asserting a rule the specification may no longer
make — which is worse than re-reading one that did not need it.

IT WRITES NOTHING and it carries nothing. It reports what a person may carry, and a person still
signs. stdlib only (plus PyYAML, through the tools it calls).
"""
import argparse
import os
import sys

TOOLS = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(os.path.dirname(TOOLS))
sys.path.insert(0, TOOLS)

import contract_lint as cl   # noqa: E402

WIDTH = 94
CONTRACT = os.path.join("handoff", "FUNCTIONAL_CONTRACT.md")

AS_IS = "carries as-is"
NEW_REF = "carries, needs a new spec_refs"
REDRAFT = "re-draft"


def _rows(pack, root):
    """{domain: {row: content hash}} for a pack, or None when it has no extraction."""
    return cl.spec_rows(os.path.join(root, pack))


def spec_delta(old, new, root=ROOT):
    """(counts, note) comparing two extractions by CONTENT, not by row number.

    Keyed on the content hash within a domain, because a row number is a position and a position
    moves for reasons that have nothing to do with the text.
    """
    a, b = _rows(old, root), _rows(new, root)
    if a is None or b is None:
        missing = old if a is None else new
        return None, (f"{missing} has no spec_pipeline/out/extracted.json — there is nothing to "
                      f"compare, so nothing was compared.")
    ha = {(d, h) for d, rows in a.items() for h in rows.values()}
    hb = {(d, h) for d, rows in b.items() for h in rows.values()}
    return {"old_rows": sum(len(r) for r in a.values()),
            "new_rows": sum(len(r) for r in b.values()),
            "unchanged": len(ha & hb), "removed": len(ha - hb), "added": len(hb - ha)}, None


def carry(old, new, root=ROOT):
    """[(variable_id, verdict, detail)] for every record in the OLD pack.

    The verdict is derived from `contract_lint.spec_digest` recomputed against the NEW extraction —
    the same function I15 uses, on the same inputs, differing only in which extraction it is handed.
    """
    old_dir, new_dir = os.path.join(root, old), os.path.join(root, new)
    new_srows, old_srows = cl.spec_rows(new_dir), cl.spec_rows(old_dir)
    if new_srows is None or old_srows is None:
        return None
    # content hash -> the row numbers holding it in the NEW extraction, for the moved-row case
    moved = {}
    for domain, rows in new_srows.items():
        for n, h in rows.items():
            moved.setdefault((domain, h), []).append(n)

    out = []
    for block in cl.records(cl.read(os.path.join(old_dir, CONTRACT))):
        vid = (cl._scalar(block, "variable_id") or "?").strip()
        refs = cl._list(block, "spec_refs") or []
        recorded = cl._scalar(block, "spec_digest")
        if not refs or refs == [cl.NO_SPEC_ROW] or not recorded or recorded == cl.NA:
            out.append((vid, REDRAFT, "cites no spec row, or carries no digest to check"))
            continue
        current = cl.spec_digest(refs, new_srows)
        if current and recorded == current:
            out.append((vid, AS_IS, ""))
            continue
        # Did the cited TEXT survive at a different row number? Look each cited row's OLD content
        # hash up in the new extraction. Only when every cited row moved intact is this a rename.
        cited, found = [], []
        for ref in refs:
            for domain, n in (cl.spec_ref_rows(ref) or []):
                h = (old_srows.get(domain) or {}).get(n)
                cited.append((domain, n, h))
                found.append(moved.get((domain, h), []) if h else [])
        if cited and all(f for f in found):
            where = ", ".join(f"{d}:{n}->{'/'.join(str(x) for x in f)}"
                              for (d, n, _h), f in zip(cited, found))
            out.append((vid, NEW_REF, where))
        elif current:
            out.append((vid, REDRAFT, f"cited text changed — digest {recorded} is now {current}"))
        else:
            out.append((vid, REDRAFT, "a cited row is absent from the new extraction"))
    return out


def carried_decisions(old, new, root=ROOT):
    """{decision id: (status, answer, [variable ids])} for decisions cited by records that carry.

    A settled answer attached to a requirement whose text did not change is the thing most worth
    not re-arguing — and it is precisely what was lost between 202606 and 202607.
    """
    verdicts = carry(old, new, root) or []
    keep = {vid for vid, v, _d in verdicts if v in (AS_IS, NEW_REF)}
    text = cl.read(os.path.join(root, old, "handoff", "DECISIONS.md"))
    rows, status = cl.decision_rows(text), cl.decision_status(text)
    out = {}
    for block in cl.records(cl.read(os.path.join(root, old, CONTRACT))):
        vid = (cl._scalar(block, "variable_id") or "").strip()
        if vid not in keep:
            continue
        for did in (cl._list(block, "decision_ids") or []):
            if did not in rows:
                continue
            entry = out.setdefault(did, [status.get(did, ""), cl.decision_answer(rows[did]) or "", []])
            entry[2].append(vid)
    return {d: (s, a, sorted(v)) for d, (s, a, v) in out.items()}


def render(old, new, root=ROOT):
    L = ["", "=" * WIDTH, f"  SPEC REVISION DIFF — {old}  ->  {new}", "=" * WIDTH]
    delta, note = spec_delta(old, new, root)
    if note:
        return "\n".join(L + ["", f"  {note}", ""])

    L += ["", f"  spec rows      {delta['old_rows']} -> {delta['new_rows']}",
          f"  unchanged      {delta['unchanged']}",
          f"  removed        {delta['removed']}",
          f"  added          {delta['added']}", ""]

    verdicts = carry(old, new, root)
    if verdicts is None:
        return "\n".join(L + ["  one of the packs has no extraction — records were not assessed.", ""])
    counts = {AS_IS: 0, NEW_REF: 0, REDRAFT: 0}
    for _v, verdict, _d in verdicts:
        counts[verdict] += 1
    L += ["-" * WIDTH, f"  {len(verdicts)} record(s) in {old}", "-" * WIDTH,
          f"     {counts[AS_IS]:4d}  {AS_IS}",
          f"     {counts[NEW_REF]:4d}  {NEW_REF}",
          f"     {counts[REDRAFT]:4d}  {REDRAFT}", ""]

    if counts[NEW_REF]:
        L.append("  MOVED — same text, different row. Update spec_refs; the digest is unchanged:")
        for vid, verdict, detail in verdicts:
            if verdict == NEW_REF:
                L.append(f"     {vid:22s} {detail}")
        L.append("")
    if counts[REDRAFT]:
        L.append("  RE-DRAFT — a person must re-read the specification for these:")
        for vid, verdict, detail in verdicts[:400]:
            if verdict == REDRAFT:
                L.append(f"     {vid:22s} {detail}")
        L.append("")

    dec = carried_decisions(old, new, root)
    settled = {d: v for d, v in dec.items() if str(v[0]).strip().upper() == "RESOLVED"}
    L += ["-" * WIDTH, f"  {len(dec)} decision(s) attach to records that carry — "
                       f"{len(settled)} of them already ANSWERED", "-" * WIDTH]
    if not dec:
        L.append("     None. Either nothing carries, or the carrying records cite no decision.")
    for did, (status, answer, vids) in sorted(settled.items()):
        L.append(f"     {did}  [{status}]  blocks {len(vids)} carried record(s)")
        L += _wrap(answer, 9, cap=4)
    still = {d: v for d, v in dec.items() if d not in settled}
    if still:
        L.append("")
        L.append(f"     still open, and they will be asked again unless carried: "
                 f"{', '.join(sorted(still))}")
    L += ["", "-" * WIDTH,
          "  Nothing was written. A record carries because its spec_digest still matches the new",
          "  extraction — that is evidence, not an assumption — but moving it is a human act.", ""]
    return "\n".join(L)


def _wrap(text, indent, cap=4):
    import textwrap
    body = " ".join(str(text or "").split())
    if not body:
        return []
    return textwrap.wrap(body, width=WIDTH - indent, initial_indent=" " * indent,
                         subsequent_indent=" " * indent)[:cap]


def main(argv):
    ap = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    ap.add_argument("old", help="the pack the records were drafted in")
    ap.add_argument("new", help="the pack the new specification landed in")
    a = ap.parse_args(argv)
    packs = []
    for p in (a.old, a.new):
        rel = os.path.relpath(os.path.abspath(p), ROOT).replace(os.sep, "/")
        if not os.path.isdir(os.path.join(ROOT, rel)):
            sys.exit(f"{p}: not a directory")
        packs.append(rel)
    print(render(*packs))
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
