#!/usr/bin/env python3
"""Where one product stands, in the plainest language the evidence allows.

    python3 platform/tools/status.py                                    # every pack, one line each
    python3 platform/tools/status.py products/oncology/prostate/202606  # one pack, in full

FOR THE PERSON WHO IS NOT GOING TO RUN THE OTHER TOOLS. A manager asking "is this ready", a
methodology owner asking "what is waiting on me", someone taking the product over. The six gate tools
each answer their own gate correctly and none of them answers "where is this, and who owes what
next" — assembling that meant running five commands and knowing how to read all five.

WHAT IT ADDS, AND THE ONLY THING IT ADDS, IS THE OWNER AND THE NEXT ACTION. Every gate state, count
and blocker below comes from the tool that owns it: `product_gates.maturity` / `evidence_route`,
`source_manifest.releasable` / `source_status`, `contract_lint.open_decisions`, `finalize.facts`,
and `dry_run.latent` for what is waiting behind the claim. This file re-derives nothing — for the
reason `worksheet` and `demo` re-derive nothing: a status page that recounted anything would be a
second implementation of whichever tool owns that count, and the failure mode is that it eventually
reports a product to be in better shape than it is. That is the one failure a status page must not
have.

Per-gate attribution is by `releasable()`'s own "Gate N:" prefixes PLUS a direct call to each gate's
error function — never by matching message text. `releasable()` reports half its findings under an
`evidence:` prefix carrying no gate number, so the prefixes alone are not the whole list, and an
earlier draft that keyed on them showed Gates 2 and 4 DONE on a pack with neither approval form. An
earlier draft still sorted them by substring, which is a classifier over another module's wording.
Anything the aggregate reports that no per-gate call produced is held against every approval gate
rather than dropped.

WHO ACTS is the exception, and it is defined ONCE, in `OWNER` below. No module owns the gate→role map
today; `governance/WORKFLOW.md` states it in prose, and this is the machine-readable form of exactly
that prose. If the two ever disagree, WORKFLOW.md governs.

READ-ONLY. It writes nothing, reads no vendor data, and contacts nothing.

stdlib only (plus PyYAML, through the tools it calls).
"""
import argparse
import os
import sys

TOOLS = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(os.path.dirname(TOOLS))
sys.path.insert(0, TOOLS)

import contract_lint    # noqa: E402
import dry_run          # noqa: E402
import finalize         # noqa: E402
import product_gates    # noqa: E402
import source_manifest  # noqa: E402

# WHO ACTS NEXT AT EACH GATE — the machine-readable form of governance/WORKFLOW.md's role prose, in
# one place. Roles, never names: a person leaves and the gate does not change hands.
OWNER = {1: "RWB (supplies the approved specification) · RWP (registers and checks it)",
         2: "RWP (drafts and QCs) · RWB/methodology (answers the decisions, approves requirements)",
         3: "Data Engineering (supplies schema + profile) · RWP (confirms the mapping is the "
            "intended concept)",
         4: "RWP (authors and approves) · RWDE (technical review)",
         5: "RWP (runs it) · QC reviewer (reviews this build's evidence)",
         6: "a named release approver, against one build id and one manifest digest"}

WIDTH = 96


def _rel(root, pack):
    """The pack path as the gates name it — root-relative, forward slashes."""
    return os.path.relpath(os.path.abspath(pack), os.path.abspath(root)).replace(os.sep, "/")


def _unattributed_note(unattributed):
    """An evidence blocker no per-gate owner claimed — reported, never dropped.

    `maturity_errors` is the aggregate; the per-gate functions below are its named parts. If the
    aggregate grows a part they do not cover, that finding belongs to SOME gate and this tool does
    not know which. Reporting it against every approval gate is the fail-closed answer; dropping it
    would let a new check be invisible here from the day it is added.
    """
    if not unattributed:
        return []
    return [f"{len(unattributed)} evidence blocker(s) stand against this pack's claims that no "
            f"per-gate check accounted for — first: {unattributed[0][:110]}"]


def gates(root, pack):
    """[(n, title, state, [blocker]), …] for the six gates — every field from its owner.

    `state` is one of: done · in progress · not started · blocked · cannot complete. It is DERIVED
    from the same maturity claims and error lists the gates themselves read, never stored: a status
    field somebody edits is the thing this repository spends most of its machinery refusing.
    """
    rel = _rel(root, pack)
    m = product_gates.maturity(pack)
    ready, why = source_manifest.releasable(root, rel)
    out = []

    # PER-GATE ATTRIBUTION COMES FROM `releasable()`'s OWN LABELS, which are already prefixed
    # "Gate N:". An earlier version called two of `maturity_errors`' five sub-checks by hand and then
    # sorted the results between gates by substring — inventing a classifier over another module's
    # message text, which would have mis-filed the first message anyone reworded and silently dropped
    # the three checks it never called. The latent blockers below are NOT split per gate for the same
    # reason: `dry_run` owns that question whole.

    # DONE IS THE GATE'S OWN VERDICT, NOT A SECOND READING OF THE CLAIM. For Gates 1, 2 and 4 that is
    # exactly "`releasable()` reports no reason for this gate" — the same list that supplies the
    # blockers. An earlier version re-read each maturity axis here and compared it to a string, and
    # got Gate 1 wrong in the only way that matters: `source_status()` returns `approved`, the
    # comparison was against `reviewed`, and so a pack whose specification really had been approved
    # would have shown "in progress" forever. It went unnoticed because every pack today is blocked at
    # Gate 1 — the positive path existed in no test and on no pack, which is this repository's most
    # familiar defect wearing new clothes.
    # ...AND THE "Gate N:" PREFIXES ARE ONLY HALF THE LIST. `releasable()` adds every
    # `maturity_errors` finding under an `evidence:` prefix, which carries no gate number: the two
    # approval records, the scaffold rule, the output decisions, the Gate 3 vendor evidence, the
    # decision provenance. Keying `done` off the prefixes alone meant that writing
    # `contract: approved` / `configuration: approved` made the two "not approved" lines disappear
    # while all ten evidence blockers stood — and Gates 2 and 4 reported DONE on a pack carrying
    # NEITHER approval form. A status page that shows a gate complete because someone typed a word is
    # worse than no status page.
    #
    # Attribution is by ASKING THE OWNER, never by matching message text: `contract_approval_errors`
    # is Gate 2's by construction (it already folds in the spec-QC and decision-provenance checks),
    # `configuration_approval_errors` + `output_decision_errors` are Gate 4's.
    ev2 = product_gates.contract_approval_errors(pack, rel, m)
    ev4 = (product_gates.configuration_approval_errors(pack, rel, m)
           + product_gates.output_decision_errors(pack, rel, m))
    # ...and anything `maturity_errors` reports that NONE of those produced is UNATTRIBUTED, so it
    # holds every approval-bearing gate back. That is the drift guard: add a seventh check to
    # `maturity_errors` and this reports it rather than quietly leaving it out of both gates, which
    # is precisely how the bug above would come back.
    unattributed = [e for e in product_gates.maturity_errors(root, rel) if e not in set(ev2 + ev4)]

    def _state(n, started, extra):
        if not [w for w in why if w.startswith(f"Gate {n}")] and not extra and not unattributed:
            return "done"
        return "in progress" if started else "not started"

    # GATE 1 — the source materials.
    src = source_manifest.source_status(pack)
    out.append((1, "Approved inputs", _state(1, src is not None, []),
                [w for w in why if w.startswith("Gate 1")]))

    # GATE 2 — requirements. What a real approval attempt would hit is LATENT and reported as such
    # below, not folded in here as though it were already known.
    c = m.get("contract", "not_started")
    out.append((2, "Requirements and decisions", _state(2, c != "not_started", ev2),
                [w for w in why if w.startswith("Gate 2")] + ev2 + _unattributed_note(unattributed)))

    # GATE 3 — source readiness. `releasable()` carries no "Gate 3:" reason, because Gate 3's evidence
    # is required BY Gate 4 rather than claimed on its own axis. So its two conditions are read from
    # the functions Gate 4 uses for exactly this: every vendor-sourced record has Gate 3 evidence
    # (`unverified_sources`), and the evidence claimed is backed by an artifact
    # (`verdict_evidence_errors`). Not a third definition — the same two calls, asked earlier.
    route, route_why = product_gates.evidence_route(root, rel)
    contract_md = os.path.join(pack, "handoff", "FUNCTIONAL_CONTRACT.md")
    g3 = []
    if not route:
        g3.append(f"evidence route undecided: {route_why}")
    if not os.path.exists(contract_md):
        g3.append("no contract yet — Gate 3 confirms the mapping a contract record proposes")
    else:
        with open(contract_md, encoding="utf-8") as fh:
            ctext = fh.read()
        unver = contract_lint.unverified_sources(ctext)
        if unver:
            shown = ", ".join(f"{v} ({w})" for v, w in unver[:2])
            g3.append(f"{len(unver)} vendor-sourced record(s) have no Gate 3 evidence — {shown}"
                      + (f" and {len(unver) - 2} more" if len(unver) > 2 else ""))
        ev = product_gates.verdict_evidence_errors(rel, pack, contract_md)
        if ev:
            # Their text is quoted VERBATIM — a finding reworded by a second tool is a finding two
            # tools describe differently. It is phrased for Gate 4 ("configuration:approved but…")
            # because that is where it fires, so the framing goes here, above it, in this tool's own
            # words rather than inside theirs.
            g3.append("the checks below are what Gate 4 will require OF Gate 3, quoted as Gate 4 "
                      "states them:")
            g3 += ev
    out.append((3, "Source and delivery readiness",
                "done" if not g3 else ("in progress" if os.path.exists(contract_md) else
                                       "not started"),
                g3))

    # GATE 4 — executable configuration.
    cfg = m.get("configuration", "not_started")
    out.append((4, "Executable configuration", _state(4, cfg != "not_started", ev4),
                [w for w in why if w.startswith("Gate 4")] + ev4 + _unattributed_note(unattributed)))

    # GATE 5 — validation, DERIVED from the per-record axis rather than asserted. `VALIDATION_RANK` is
    # contract_lint's own ordering (not_run/failed 0 · passed_test 1 · passed_live 2) and is imported,
    # not restated. Only records whose REQUIREMENT is approved are counted: a draft requirement has
    # nothing settled to validate against, so demanding evidence for it would report work that does
    # not exist yet.
    #
    # `records` is ABSENT, not zero, when no contract has been drafted — a pack with nothing to
    # validate and a pack whose every record failed are different states, and `.get(k, 0)` would merge
    # them into the same "0 records" the rest of this framework exists to refuse.
    f = finalize.facts(pack)
    g5, state5 = [], "not started"
    if f.get("records") is None:
        g5 = ["no contract yet — there are no requirements to validate"]
    else:
        with open(contract_md, encoding="utf-8") as fh:
            blocks = list(contract_lint.records(fh.read()))
        approved = [b for b in blocks
                    if contract_lint._kv(contract_lint._inline(b, "status"), "requirement")
                    == "approved"]
        ranks = [contract_lint.VALIDATION_RANK.get(
            contract_lint._kv(contract_lint._inline(b, "status"), "validation") or "not_run", 0)
            for b in approved]
        live = sum(1 for r in ranks if r >= 2)
        tested = sum(1 for r in ranks if r >= 1)
        if not approved:
            state5 = "not started"
            g5 = [f"no record has an approved requirement yet ({len(blocks)} record(s) drafted) — "
                  f"Gate 5 validates settled requirements, and none is settled"]
        elif live == len(approved):
            state5 = "done"
        else:
            state5 = "in progress"
            g5 = [f"{live}/{len(approved)} approved record(s) report validation:passed_live "
                  f"({tested} reach passed_test or better) — the rest are not_run, failed, or "
                  f"validated only against the test/synthetic build"]
    out.append((5, "Validation", state5, g5))

    # GATE 6 — release. Gates 1-4 must pass before the question is even asked, and the promotion
    # path that would let an approval complete is not built.
    out.append((6, "Release", "blocked" if not ready else "cannot complete",
                ([f"Gates 1-4 are not all passed, so no build may be released ({len(why)} reason(s) "
                  f"above)"] if not ready else [])
                + ["promoting an approved candidate is NOT IMPLEMENTED — a rerun mints a new "
                   "build_id, so an approval of build A cannot be satisfied by run B. See "
                   "products/OPERATIONS.md §\"Gate 6\"."]))
    return out


def next_action(root, pack):
    """(gate, who, what) — the first gate that is not done, and the single most useful thing to do.

    "First not done" rather than a priority ranking: the gates are SEQUENTIAL by construction, so the
    earliest open one is the one whose evidence everything after it depends on. Ranking them would
    invent an ordering the framework does not have.
    """
    for n, title, state, blockers in gates(root, pack):
        if state == "done":
            continue
        if n == 2 and blockers:
            open_ds = contract_lint.open_decisions(pack)
            if open_ds:
                return (2, OWNER[2], f"answer the open decisions ({len(open_ds)} open) — run "
                                     f"`decision_packet.py {pack}` and send the packet to the "
                                     f"methodology owner")
        return (n, OWNER[n], blockers[0] if blockers else f"complete Gate {n}: {title}")
    return (None, "—", "every gate is done")


def render(root, pack):
    reg = product_gates.registry_entry(root, pack if os.path.isabs(pack) else _rel(root, pack)) or {}
    m = product_gates.maturity(pack)
    f = finalize.facts(pack)
    L = []
    L.append("=" * WIDTH)
    L.append(f"  {reg.get('name', os.path.basename(pack))}  —  {_rel(root, pack)}")
    L.append("=" * WIDTH)
    L.append(f"  vendor {reg.get('vendor', '—')} · registry status {reg.get('status', '—')} · "
             f"claims: source {source_manifest.source_status(pack) or '—'}, "
             f"contract {m.get('contract', '—')}, configuration {m.get('configuration', '—')}")
    if f.get("records") is None:
        L.append("  no contract drafted yet — nothing has been traced from a specification")
    else:
        L.append(f"  {f['records']} contract record(s) over {f['domains']} domain(s); "
                 f"{f['mapped']}/{f['items']} specification item(s) traced")
    L.append("")
    for n, title, state, blockers in gates(root, pack):
        L.append("-" * WIDTH)
        L.append(f" GATE {n} · {title.upper()}     [{state}]")
        L.append("-" * WIDTH)
        L.append(f"   who      {OWNER[n]}")
        if not blockers:
            L.append("   waiting on nothing")
        for b in blockers[:5]:
            L.append(f"   ·  {b if len(b) < WIDTH - 6 else b[:WIDTH - 9] + '...'}")
        if len(blockers) > 5:
            L.append(f"   ·  …and {len(blockers) - 5} more — "
                     f"run `dry_run.py {_rel(root, pack)}` for the full list")
        L.append("")
    # WHAT IS WAITING BEHIND THE CLAIM. A gate that fires only on a claim is invisible until somebody
    # makes it, so the list above is not the whole distance. `dry_run.latent` owns that subtraction —
    # blockers-if-approved minus blockers-today — and it is called, not re-derived: a second opinion
    # about what blocks a release is the one thing this file must not be.
    # ROOT-RELATIVE, like every other gate call — `latent` stages a copy and refuses an absolute path.
    _cur, new, err = dry_run.latent(_rel(root, pack), root)
    L.append("-" * WIDTH)
    L.append(" NOT YET COUNTED ABOVE · what appears only once this pack CLAIMS approval")
    L.append("-" * WIDTH)
    if err:
        L.append(f"   could not be simulated: {err}")
    elif not new:
        L.append("   nothing — the blockers above are the whole Gate 1-4 distance")
    else:
        L.append(f"   {len(new)} latent blocker(s). These are not new problems; they are problems")
        L.append("   nobody has been told about, because no gate asks until the claim is made.")
        for b in sorted(new)[:4]:
            L.append(f"   ·  {b if len(b) < WIDTH - 6 else b[:WIDTH - 9] + '...'}")
        if len(new) > 4:
            L.append(f"   ·  …and {len(new) - 4} more — "
                     f"run `dry_run.py {_rel(root, pack)}` for all of them")
    L.append("")
    n, who, what = next_action(root, pack)
    L.append("=" * WIDTH)
    L.append("  THE NEXT THING TO DO" + (f"  (Gate {n})" if n else ""))
    L.append("=" * WIDTH)
    L.append(f"   who   {who}")
    for i in range(0, len(what), WIDTH - 9):
        L.append(f"   {'what ' if i == 0 else '     '}  {what[i:i + WIDTH - 9]}")
    L.append("")
    L.append("   No tool here approves anything, answers a decision, or promotes a build. Those are")
    L.append("   human acts recorded in the pack's own files.")
    return "\n".join(L)


def one_line(root, pack):
    n, _who, _what = next_action(root, pack)
    # NOT "RELEASE-READY". `releasable()` answers Gates 1-4 for the PACK — it says nothing about a
    # data cut's validation or about a named approval of a specific build, and the rest of this
    # repository is careful to say so. Labelling it release-ready in the one view a manager reads
    # would reintroduce, in the friendliest possible place, exactly the overstatement everything
    # else here removes.
    ready, why = source_manifest.releasable(root, _rel(root, pack))
    return (f"  {_rel(root, pack):<42} "
            f"{'GATES 1-4 READY' if ready else 'blocked at Gate ' + str(n) if n else 'blocked':<22}"
            f"{len(why)} open Gate 1-4 reason(s)")


def main(argv=None):
    ap = argparse.ArgumentParser(description="Where a product stands, and who acts next.")
    ap.add_argument("product", nargs="?", help="pack path; omit for every pack, one line each")
    a = ap.parse_args(argv)
    if a.product:
        if not os.path.isdir(a.product):
            raise SystemExit(f"not a pack: {a.product}")
        print(render(ROOT, a.product))
        return 0
    print("=" * WIDTH)
    print("  EVERY GOVERNED PRODUCT")
    print("=" * WIDTH)
    for p in product_gates.products(ROOT):
        try:
            print(one_line(ROOT, os.path.join(ROOT, p)))
        except Exception as e:                                    # noqa: BLE001
            # NAMED, never skipped: a pack this tool cannot read is a finding about that pack, and a
            # status page that quietly omitted it would report fewer problems than exist.
            print(f"  {p:<42} COULD NOT BE READ: {e}")
    print("")
    print("  python3 platform/tools/status.py <pack>   for one product in full")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
