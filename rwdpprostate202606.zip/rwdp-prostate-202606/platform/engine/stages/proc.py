"""Stage: OC platinum-sensitivity (the PROC outcome dimension). Ports the original's platinum-free-interval
logic (the reconstruction only summarises it, so the exact anchors/threshold/window
are verify-vs-source and tunable from config).

Per (patient, line N >= from_line): PFI = months from the prior platinum line's end to line N's start;
plat_sen_v1 = Resistant when PFI < threshold else Sensitive (null with no prior platinum). plat_sen_v2
carries the PREVIOUS line's status forward; pcycled flags a platinum re-challenge. Attaches to each
2L+ line cohort at its index. OPTIONAL: needs an outcomes.platinum_sensitivity block + the lot source.

The two compiled pieces (_platinum_pred, _sensitivity_case) are mirrored in engine-r/cases.R and proven
byte-identical in tests/test_r_parity.py; the windowing/self-join mirrors engine-r/stages.R::proc_*.
"""
from __future__ import annotations


def _platinum_pred(agents, name_col: str = "linename") -> str:
    """SQL predicate: the line name matches ANY platinum agent (case-insensitive LIKE). Same shape as
    treatment._taxane_pred; mirrored in cases.R::platinum_pred."""
    return " OR ".join(f"lower({name_col}) LIKE '{a.lower()}'" for a in agents)


def _sensitivity_case(threshold_months, pfi_col: str = "pfi") -> str:
    """CASE mapping the platinum-free interval (months) to Sensitive/Resistant; null when there is no
    prior platinum (pfi null). Mirrored in cases.R::sensitivity_case."""
    return (f"CASE WHEN {pfi_col} IS NULL THEN NULL WHEN {pfi_col} < {threshold_months} "
            f"THEN 'Resistant' ELSE 'Sensitive' END")


def _plat_sen_table(F, lot_df, pcfg, dpm):
    """Per-(patient, linenumber) -> pfi / plat_sen / pcycled, computed over the patient's FULL line
    history so the prior-platinum lookup and carry-forward see every line."""
    lnc, nmc = pcfg["line_number_column"], pcfg["name_column"]
    sdc, edc = pcfg["start_column"], pcfg["end_column"]
    window = int(pcfg.get("pfi_window_days", 14))
    thr = pcfg.get("threshold_months", 6)

    lines = lot_df.select(
        "patientid", F.col(lnc).cast("int").alias("linenumber"),
        F.col(sdc).alias("_sd"), F.col(edc).alias("_ed"),
        F.expr(_platinum_pred(pcfg["platinum_agents"], nmc)).alias("_isplat"))
    # prior platinum END per line: latest end among platinum lines that PRECEDE this line, with a
    # `window`-day boundary grace (platinum ending just into the new line still counts as prior).
    plat = (lines.filter("_isplat")
            .select("patientid", F.col("linenumber").alias("_pln"), F.col("_ed").alias("_ped")))
    prior = (lines.join(plat, "patientid", "inner")
             .filter(f"_pln < linenumber AND _ped < date_add(_sd, {window})")
             .groupBy("patientid", "linenumber").agg(F.max("_ped").alias("_prior_end")))
    # re-attach to the full line spine (lines with no prior platinum get a null _prior_end)
    spine = lines.select("patientid", "linenumber", "_sd", "_isplat").dropDuplicates(
        ["patientid", "linenumber"])
    return (spine.join(prior, ["patientid", "linenumber"], "left")
            .withColumn("pfi", F.expr("CASE WHEN _prior_end IS NULL THEN NULL "
                                      f"ELSE datediff(_sd, _prior_end)/{dpm} END"))
            .withColumn("plat_sen", F.expr(_sensitivity_case(thr)))
            .withColumn("pcycled", F.expr(
                "CASE WHEN _isplat AND _prior_end IS NOT NULL THEN 1 ELSE 0 END"))
            .select("patientid", "linenumber", "pfi", "plat_sen", "pcycled"))


def build(F, src, idx, cfg, cohort):
    """plat_sen_v1 / plat_sen_v2 / pfi / pcycled for this line cohort, keyed (patientid, index_date).
    Returns None when platinum_sensitivity is unconfigured or the cohort is below from_line (overall/L1).
    """
    pcfg = cfg.pack("outcomes").get("platinum_sensitivity")
    if not pcfg or pcfg.get("source") not in src:
        return None
    ln = (cohort or {}).get("lot_number")
    if ln is None or ln < int(pcfg.get("from_line", 2)):
        return None
    dpm = cfg.pack("outcomes")["days_per_month"]
    tbl = _plat_sen_table(F, src[pcfg["source"]], pcfg, dpm)
    cur = tbl.filter(F.col("linenumber") == ln).select(
        "patientid", F.col("plat_sen").alias("plat_sen_v1"), "pfi", "pcycled")
    prev = tbl.filter(F.col("linenumber") == ln - 1).select(
        "patientid", F.col("plat_sen").alias("plat_sen_v2"))      # previous line's status (carry-forward)
    return (idx.select("patientid", "index_date")
            .join(cur, "patientid", "left").join(prev, "patientid", "left"))
