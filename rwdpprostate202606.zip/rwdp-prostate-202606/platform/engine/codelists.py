"""Compile the treatment-category codelist into Spark SQL CASE expressions. Pure Python.

The R script classified each line of therapy with a 17-way `case_when` (lotcat / lotcatn).
That logic now lives in codelists/treatment_categories.yaml. This module turns the ordered
list into two Spark SQL CASE expressions — one for the label, one for the numeric code —
preserving first-match-wins. The engine wraps them with F.expr(); the strings are also
trivially unit-testable without Spark.
"""
from __future__ import annotations


# The DSL's vocabulary, and the ONE place its names are written down. Every other named thing a
# config selects — bmi_method, bsa_method, filter_method, the death-conflict policy — already comes
# from a registry the validator imports, so an unknown value is refused with the valid ones listed.
# These operators were the exception: a bare "unknown match operator: 'x'", which tells an analyst
# authoring a codelist nothing about what they may write instead, and nothing outside this file could
# enumerate them without copying the if/elif chain below.
#
# The descriptions are for the catalog (`platform/tools/blocks.py`); the KEYS are what compile_match
# accepts, and test_codelists asserts the two sets are identical by reading the dispatch back out of
# this module's own syntax tree. Add an operator below and to the chain, or the test says so.
MATCH_OPERATORS = {
    "equals":         "the name column equals this value (case-insensitive)",
    "like_any":       "the name column is LIKE any pattern in this list (case-insensitive, % wildcards)",
    "regexp":         "the name column matches this regular expression",
    "category_equals": "the drug-category column equals this value (case-insensitive)",
    "is_null":        "true where the name column IS NULL; `false` makes it match nothing",
    "all_of":         "every nested match must hold (AND)",
    "any_of":         "at least one nested match must hold (OR)",
    "always":         "unconditionally true — the terminal fallthrough; `false` matches nothing",
}


def sql_str(s: str) -> str:
    """A Spark SQL string literal — the ONE quoter, and it escapes BACKSLASHES as well as quotes.

    The backslash half is not decorative. Spark parses escape sequences inside a string literal, and
    an UNRECOGNISED one loses its backslash silently: `SELECT '\\d'` returns the string `d`. So a
    codelist carrying `regexp: '\\d+'` compiled to `LOWER(linename) REGEXP 'd+'` — a pattern matching
    a literal letter d, matching nothing anyone intended, with no error at compile or run time. That
    is the fail-open shape this repository keeps finding: the operator is real, the config is
    plausible, the SQL is valid, and the answer is wrong.

    Verified against Spark 4.2.0 rather than reasoned about: `'\\d'` selects `d`, `'\\\\d'` selects
    `\\d`, and `v REGEXP '\\d'` returned zero rows over data containing digits.

    Changing this changes NO existing pack's SQL — no label, code, pattern or crosswalk value in any
    `codelists/` or `variables/` file contains a backslash — and `test_r_parity` + the golden suites
    prove it. It closes the hazard before the first pack writes one.

    Backslashes FIRST, then quotes: the quote-doubling introduces no backslashes, so the two are
    independent, but doing it the other way round would double an escape backslash the first pass
    had just written.

    `stages/clinical.py` imports this as its `_q` — the SAME function object, so a value map and a
    codelist cannot come to quote a pattern differently. `engine-r/` must define it twice (cases.R
    and codelists.R are each `source()`d ALONE by their parity harnesses, so neither can call the
    other); `test_r_parity` compares all three against a hostile string set.
    """
    return "'" + str(s).replace("\\", "\\\\").replace("'", "''") + "'"


_sql_str = sql_str          # the name this module's own compilers were written against


def compile_match(match: dict, name_col: str, cat_col: str) -> str:
    """Compile one match dict into a SQL boolean predicate.

    Comparisons are case-insensitive (LOWER(col)), matching the R `tolower(...)`/`LOWER(...)`.
    """
    if not isinstance(match, dict) or len(match) != 1:
        raise ValueError(f"each match needs exactly one operator, got: {match!r}")
    (op, val), = match.items()
    name = f"LOWER({name_col})"
    cat = f"LOWER({cat_col})"

    if op == "equals":
        return f"{name} = {_sql_str(str(val).lower())}"
    if op == "like_any":
        return "(" + " OR ".join(f"{name} LIKE {_sql_str(str(p).lower())}" for p in val) + ")"
    if op == "regexp":
        return f"{name} REGEXP {_sql_str(val)}"
    if op == "category_equals":
        return f"{cat} = {_sql_str(str(val).lower())}"
    if op == "is_null":
        return f"{name_col} IS NULL" if val else "FALSE"
    if op == "all_of":
        return "(" + " AND ".join(compile_match(m, name_col, cat_col) for m in val) + ")"
    if op == "any_of":
        return "(" + " OR ".join(compile_match(m, name_col, cat_col) for m in val) + ")"
    if op == "always":
        return "TRUE" if val else "FALSE"
    raise ValueError(f"unknown match operator {op!r}; valid: {sorted(MATCH_OPERATORS)}")


def compile_case(codelist: dict) -> tuple[str, str]:
    """Return (label_case_sql, code_case_sql) for a treatment_categories codelist.

    Order of `categories` is the CASE WHEN order, so first match wins — same as case_when.
    """
    name_col = codelist.get("match_on", {}).get("name_column", "linename")
    cat_col = codelist.get("match_on", {}).get("drug_category_column", "detaileddrugcategory")
    cats = codelist["categories"]
    if not cats:
        raise ValueError("treatment_categories has no categories")

    label_whens, code_whens = [], []
    for c in cats:
        pred = compile_match(c["match"], name_col, cat_col)
        label_whens.append(f"WHEN {pred} THEN {_sql_str(c['label'])}")
        code_whens.append(f"WHEN {pred} THEN {int(c['code'])}")

    label_sql = "CASE " + " ".join(label_whens) + " END"
    code_sql = "CASE " + " ".join(code_whens) + " END"
    return label_sql, code_sql
