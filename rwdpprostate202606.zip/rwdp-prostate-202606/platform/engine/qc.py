"""Semantic QC for a built ADS — the layer the schema preflight can't cover.

Run AFTER build, before publishing. Reports the distributions reviewers asked for: date-castability,
mortality granularity + duplicate-conflict counts, unmapped stage ('CHECK'), unmatched treatment
(the catch-all rate), null-rates, and row/cohort counts.

`qc_spec(cfg)` is the pure-Python plan (unit-tested). `run_qc(spark, ads, cfg)` executes it on a
Spark DataFrame (cluster only). Nothing here writes data; it returns a report dict.
"""
from __future__ import annotations

# Sentinel labels the engine emits (a high rate of either is a data-quality smell): the treatment
# line-category catch-all and the staging fallthrough. Both are DERIVED from the EXACT config location
# the engine compiles from, so QC checks the label the engine actually emits and can't drift. When a
# tumor declares neither, the derivation returns None and QC SKIPS that check — it never substitutes a
# hardcoded guess, which could silently mismatch the emitted label and let a bad build pass.


def _catchall_label(cfg):
    """Label of the catch-all (`match: {always: true}`) row of the treatment LINE-CATEGORY codelist —
    the codelist the treatment pack NAMES (`line_category_codelist`) and the engine compiles into the
    per-line `lot{i}cat`. Not "the first codelist that happens to carry an always-row": a tumor with a
    second codelist (e.g. biomarkers) whose always-row has a different label must not hijack this.
    Returns None when no line-category codelist is declared (QC then skips the catch-all check)."""
    try:
        clname = (cfg.pack("treatment") or {}).get("line_category_codelist")
        if not clname:
            return None
        for cat in cfg.codelist(clname).get("categories", []):
            if (cat.get("match") or {}).get("always"):
                return cat.get("label")
    except Exception:  # noqa: BLE001 - no treatment pack / codelist -> skip the check, don't guess
        return None
    return None


def _stage_check_label(cfg):
    """Label of the staging fallthrough group (`when: fallthrough` in clinical.staging), or None when
    the tumor declares no staging (QC then skips the unmapped-stage check rather than guessing 'CHECK')."""
    try:
        for g in (cfg.pack("clinical").get("staging") or {}).get("groups") or []:
            if g.get("when") == "fallthrough":
                return g.get("label")
    except Exception:  # noqa: BLE001 - no clinical pack / staging -> skip the check, don't guess
        return None
    return None


def qc_spec(cfg) -> dict:
    """The QC plan, derived from config so it adapts per tumor. Pure data, no Spark."""
    max_lines = 6
    try:
        max_lines = int(cfg.pack("treatment").get("max_lines", 6))
    except Exception:  # noqa: BLE001 - treatment pack optional for the plan
        pass
    return {
        "cohort_columns": ["cohort", "cohortn", "cohortu", "cohortun"],
        # categorical columns to show distributions for (only those present are used at runtime)
        "categorical": ["cohort", "agegrl", "regionl", "race", "eth", "ecog", "stage",
                        *[f"lot{i}cat" for i in range(1, max_lines + 1)]],
        # rate-of-sentinel checks
        "treatment_catchall": {"columns": [f"lot{i}cat" for i in range(1, max_lines + 1)],
                               "label": _catchall_label(cfg)},
        "stage_check": {"column": "stage", "label": _stage_check_label(cfg)},
        # date columns to test castability (logical -> the ADS column name)
        "date_columns": ["index_date", "dthdt", "fued", "advanceddiagnosisdate"],
    }


def run_qc(spark, ads, cfg) -> dict:
    """Compute the QC report for a built ADS DataFrame. Spark-side (cluster only)."""
    from pyspark.sql import functions as F

    spec = qc_spec(cfg)
    cols = set(ads.columns)
    n = ads.count()
    report = {"n_rows": n, "version": cfg.version, "refresh": cfg.refresh}

    # cohort counts
    if "cohort" in cols:
        report["cohorts"] = {r["cohort"]: r["n"]
                             for r in ads.groupBy("cohort").agg(F.count(F.lit(1)).alias("n")).collect()}

    # null-rate per column
    if n:
        nulls = ads.select([F.round(F.avg(F.when(F.col(c).isNull(), 1.0).otherwise(0.0)), 4).alias(c)
                            for c in ads.columns]).collect()[0].asDict()
        report["null_rate"] = {c: v for c, v in nulls.items() if v and v > 0}

    # unmatched-treatment rate (high = taxonomy gaps). Skipped when the catch-all label can't be
    # derived (no line-category codelist) — QC never checks against a guessed label.
    cat = spec["treatment_catchall"]
    if cat.get("label") is not None:
        tr = {}
        for c in cat["columns"]:
            if c in cols:
                hits = ads.filter(F.col(c) == cat["label"]).count()
                tr[c] = round(hits / n, 4) if n else None
        if tr:
            report["catchall_rate"] = tr
            report["catchall_label"] = cat["label"]

    # unmapped stage rate. Skipped when the staging fallthrough label can't be derived (no staging).
    sc = spec["stage_check"]
    if sc.get("label") is not None and sc["column"] in cols and n:
        report["stage_check_rate"] = round(
            ads.filter(F.col(sc["column"]) == sc["label"]).count() / n, 4)
        report["stage_check_label"] = sc["label"]

    # date-castability (fraction non-null that fail to_date)
    dc = {}
    for c in spec["date_columns"]:
        if c in cols:
            nonnull = ads.filter(F.col(c).isNotNull())
            d = nonnull.count()
            if d:
                bad = nonnull.filter(F.to_date(F.col(c).cast("string")).isNull()).count()
                if bad:
                    dc[c] = round(bad / d, 4)
    if dc:
        report["uncastable_date_rate"] = dc

    return report


def run_source_qc(spark, cfg) -> dict:
    """Pre-build QC on raw sources: mortality granularity + duplicate-conflict counts."""
    from pyspark.sql import functions as F

    report = {}
    try:
        from functools import reduce
        # Read mortality the SAME way sources.load does — union all member schemas (so it works under a
        # source_union where run.source_schema is unused), lower-case, then apply any format renames —
        # so the engine sees the same rows the build will, not a placeholder-schema lookup via cfg.table.
        mort = reduce(lambda a, b: a.unionByName(b, allowMissingColumns=True),
                      [spark.table(f) for f in cfg.source_fqns("mortality")])
        for c in mort.columns:
            if c != c.lower():
                mort = mort.withColumnRenamed(c, c.lower())
        for phys, logical in (cfg.source_renames.get("mortality") or {}).items():
            p, lo = phys.lower(), logical.lower()
            if p in mort.columns and p != lo:
                mort = mort.withColumnRenamed(p, lo)
        dod = F.col("dateofdeath").cast("string")
        report["mortality_granularity"] = {
            str(r["len"]): r["n"] for r in
            mort.groupBy(F.length(dod).alias("len")).agg(F.count(F.lit(1)).alias("n")).collect()}
        dups = (mort.groupBy("patientid").agg(F.countDistinct("dateofdeath").alias("d"))
                    .filter(F.col("d") > 1).count())
        report["patients_with_conflicting_death_dates"] = dups
    except Exception as e:  # noqa: BLE001
        report["mortality_qc_error"] = str(e)
    return report


# --- QC gate: turn a run_qc() report into a pass/fail decision (pure Python) -----------------
DEFAULT_THRESHOLDS = {
    "min_rows": 1,                 # the ADS must not be empty
    "max_catchall_rate": 0.50,     # >50% of lines hitting "Any other therapy" = taxonomy gap
    "max_stage_check_rate": 0.05,  # >5% stage == 'CHECK' = unmapped staging values
    "max_uncastable_date_rate": 0.01,  # date columns should be ~fully castable
}


def qc_thresholds(cfg) -> dict:
    """Merge the framework defaults with an optional per-tumor `qc:` block in config."""
    t = dict(DEFAULT_THRESHOLDS)
    t.update((cfg.raw.get("qc") or {}).get("thresholds", {}) if cfg is not None else {})
    return t


def qc_gate(report: dict, thresholds: dict | None = None) -> dict:
    """Evaluate a run_qc() report against thresholds. Returns {passed, failures}. Pure data."""
    t = thresholds or DEFAULT_THRESHOLDS
    failures = []
    if report.get("n_rows", 0) < t["min_rows"]:
        failures.append(f"n_rows {report.get('n_rows', 0)} < min_rows {t['min_rows']}")
    for col, rate in (report.get("catchall_rate") or {}).items():
        if rate is not None and rate > t["max_catchall_rate"]:
            failures.append(f"{col} catch-all rate {rate} > {t['max_catchall_rate']}")
    scr = report.get("stage_check_rate")
    if scr is not None and scr > t["max_stage_check_rate"]:
        lbl = report.get("stage_check_label") or "unmapped-stage"   # the derived fallthrough label, not 'CHECK'
        failures.append(f"stage {lbl!r} rate {scr} > {t['max_stage_check_rate']}")
    for col, rate in (report.get("uncastable_date_rate") or {}).items():
        if rate > t["max_uncastable_date_rate"]:
            failures.append(f"{col} uncastable-date rate {rate} > {t['max_uncastable_date_rate']}")
    return {"passed": not failures, "failures": failures}


def source_qc_gate(source_report: dict, thresholds: dict | None = None) -> dict:
    """Gate the PRE-BUILD source QC (run_source_qc). Fails on an unreadable mortality source, or on
    more than `max_death_conflicts` patients with conflicting death dates (None = don't gate on it,
    since the engine dedupes deterministically — but a real read error always fails)."""
    t = {"max_death_conflicts": None, **(thresholds or {})}
    failures = []
    if source_report.get("mortality_qc_error"):
        failures.append("mortality source not readable: " + source_report["mortality_qc_error"])
    mc = source_report.get("patients_with_conflicting_death_dates")
    if t["max_death_conflicts"] is not None and mc is not None and mc > t["max_death_conflicts"]:
        failures.append(f"{mc} patients with conflicting death dates > {t['max_death_conflicts']}")
    return {"passed": not failures, "failures": failures}
