# R mirror of engine/codelists.py — compiles the SAME treatment-category codelist to the SAME
# Spark SQL CASE strings, so the R and PySpark engines agree on the (most complex) shared logic.
# Parity with the Python version is enforced by platform/tests/test_r_parity.py.

# Mirrors engine/codelists.py::sql_str — see there for why BACKSLASHES are escaped as well as
# quotes, and cases.R::.q for why this exists twice on the R side.
.sql_str <- function(s) paste0("'", gsub("'", "''", gsub("\\", "\\\\", as.character(s), fixed = TRUE),
                                          fixed = TRUE), "'")

compile_match <- function(match, name_col, cat_col) {
  if (!is.list(match) || length(match) != 1L)
    stop("each match needs exactly one operator")
  op <- names(match)[1]
  val <- match[[1]]
  name <- sprintf("LOWER(%s)", name_col)
  cat  <- sprintf("LOWER(%s)", cat_col)

  if (op == "equals")
    return(sprintf("%s = %s", name, .sql_str(tolower(as.character(val)))))
  if (op == "like_any")
    return(paste0("(", paste(sprintf("%s LIKE %s", name, .sql_str(tolower(as.character(val)))),
                             collapse = " OR "), ")"))
  if (op == "regexp")
    return(sprintf("%s REGEXP %s", name, .sql_str(val)))
  if (op == "category_equals")
    return(sprintf("%s = %s", cat, .sql_str(tolower(as.character(val)))))
  if (op == "is_null")
    return(if (isTRUE(val)) sprintf("%s IS NULL", name_col) else "FALSE")
  if (op == "all_of")
    return(paste0("(", paste(vapply(val, compile_match, "", name_col, cat_col), collapse = " AND "), ")"))
  if (op == "any_of")
    return(paste0("(", paste(vapply(val, compile_match, "", name_col, cat_col), collapse = " OR "), ")"))
  if (op == "always")
    return(if (isTRUE(val)) "TRUE" else "FALSE")
  stop(sprintf("unknown match operator: %s", op))
}

compile_case <- function(codelist) {
  mo <- codelist[["match_on"]]
  name_col <- if (!is.null(mo[["name_column"]])) mo[["name_column"]] else "linename"
  cat_col  <- if (!is.null(mo[["drug_category_column"]])) mo[["drug_category_column"]] else "detaileddrugcategory"
  cats <- codelist[["categories"]]
  if (length(cats) == 0) stop("treatment_categories has no categories")

  label_whens <- character(0)
  code_whens <- character(0)
  for (c in cats) {
    pred <- compile_match(c[["match"]], name_col, cat_col)
    label_whens <- c(label_whens, sprintf("WHEN %s THEN %s", pred, .sql_str(c[["label"]])))
    code_whens  <- c(code_whens,  sprintf("WHEN %s THEN %s", pred, as.character(as.integer(c[["code"]]))))
  }
  list(label = paste0("CASE ", paste(label_whens, collapse = " "), " END"),
       code  = paste0("CASE ", paste(code_whens,  collapse = " "), " END"))
}
