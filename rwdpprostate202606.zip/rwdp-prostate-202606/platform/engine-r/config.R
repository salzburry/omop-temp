# R mirror of engine/config.py — a resolved view over a tumor's data_product.yaml.
#
# Load order: source("vendors.R") BEFORE this file (config uses vendors_resolve; it does not source
# vendors.R itself, to avoid fragile relative-path sourcing). tests/test_r_parity.py and run_rwdp.R
# both source vendors.R first.
#
# Two layers, mirroring config.py exactly:
#  (1) PURE resolution helpers that operate on an ALREADY-PARSED config list (the same structure
#      Python's yaml.safe_load produces). These need NO packages and are cross-checked against
#      engine/config.py by tests/test_r_parity.py: cfg_all_tables() (flatiron AND cota),
#      cfg_index_source(), cfg_lot_line_setting(), cfg_vendor(), cfg_tumor_class(), cfg_output_fqn(),
#      cfg_version(), cfg_spec_version(), cfg_write_mode().
#  (2) load_config(): reads the YAML from disk (yaml::read_yaml) + applies dotted-key overrides.
#      This needs the `yaml` package — present on Databricks, NOT in the offline authoring sandbox —
#      so it is REVIEW-ONLY here. `yaml::` is referenced only inside the function body, so sourcing
#      this file never requires the package.

`%||%` <- function(a, b) if (is.null(a)) b else a

# A Config is just the parsed `raw` list + the product root (for pack/codelist file resolution).
make_config <- function(raw, root = NULL) list(raw = raw, root = root)

# --- run / output (pure) ----------------------------------------------------
cfg_run           <- function(cfg) cfg$raw[["run"]] %||% list()
cfg_refresh       <- function(cfg) cfg_run(cfg)[["refresh"]]
cfg_source_schema <- function(cfg) cfg_run(cfg)[["source_schema"]]
cfg_output_schema <- function(cfg) cfg_run(cfg)[["output_schema"]]
cfg_output_table  <- function(cfg) cfg_run(cfg)[["output_table"]]
cfg_output_fqn    <- function(cfg) sprintf("%s.%s", cfg_output_schema(cfg), cfg_output_table(cfg))
cfg_write_mode    <- function(cfg) cfg_run(cfg)[["write_mode"]] %||% "overwrite"
cfg_data_product_id <- function(cfg) cfg$raw[["data_product_id"]] %||% ""   # stamped on every ADS row
cfg_source_union  <- function(cfg) cfg$raw[["source_union"]]            # multi-schema union (EC); NULL = single
cfg_vendor        <- function(cfg) cfg$raw[["vendor"]] %||% "flatiron"
cfg_tumor_class   <- function(cfg) cfg$raw[["tumor_class"]] %||% "solid"
# Data format (EDM | Panoramic …): a per-format overlay over sources / table-layout / column renames.
cfg_data_format    <- function(cfg) cfg_run(cfg)[["data_format"]] %||% cfg$raw[["data_format"]] %||% "EDM"
cfg_format_block   <- function(cfg) (cfg$raw[["formats"]] %||% list())[[cfg_data_format(cfg)]] %||% list()
cfg_source_layout  <- function(cfg) cfg_format_block(cfg)[["source_layout"]] %||% cfg_run(cfg)[["source_layout"]]
cfg_source_renames <- function(cfg) cfg_format_block(cfg)[["rename"]] %||% list()

# Full product version with {snapshot} filled from the refresh (e.g. "202606.{snapshot}" ->
# "202606.2026q1"). A human-readable spec+cut label for logs; the audit STAMP is cfg_spec_version().
cfg_version <- function(cfg) {
  v <- as.character(cfg$raw[["version"]] %||% "")
  gsub("{snapshot}", as.character(cfg_refresh(cfg)), v, fixed = TRUE)
}

# The contract version alone (CalVer YYYYMM, e.g. "202606") — `version` with the data-refresh snapshot
# stripped. THIS is what stamps ADS rows + manifests (== Python Config.spec_version); the data cut is
# carried separately as data_refresh, so the two axes never duplicate. Mirrors assemble.py byte-for-byte.
cfg_spec_version <- function(cfg) {
  v <- as.character(cfg$raw[["version"]] %||% "")
  head <- strsplit(v, "{snapshot}", fixed = TRUE)[[1]][1]
  if (length(head) == 0L || is.na(head)) head <- ""
  sub("[._/ -]+$", "", head)                # strip trailing separators (== Python rstrip("._-/ "))
}

# LOT line-setting filter for new_lot_n (e.g. mCRPC for prostate). NULL = no filter.
cfg_lot_line_setting <- function(cfg) (cfg$raw[["lot"]] %||% list())[["line_setting"]]

# LOT model (backward-compatible defaults reproduce prostate): which line numbering, settings to
# drop, and the maintenance-flag column. Mirrors config.py.
cfg_lot_exclude_settings   <- function(cfg) (cfg$raw[["lot"]] %||% list())[["exclude_settings"]] %||% list()
cfg_lot_line_number_col    <- function(cfg) (cfg$raw[["lot"]] %||% list())[["line_number"]] %||% "new_lot_n"
cfg_lot_maintenance_column <- function(cfg) (cfg$raw[["lot"]] %||% list())[["maintenance_column"]] %||% "ismaintenancetherapy"

# Logical source the 'overall' index date is built from. Default 'enhanced'; heme indexes off
# 'diagnosis' (index_dates.advanced_diagnosis_date.source).
cfg_index_source <- function(cfg) {
  idx <- (cfg$raw[["index_dates"]] %||% list())[["advanced_diagnosis_date"]] %||% list()
  idx[["source"]] %||% "enhanced"
}

# --- sources (pure, vendor-aware) -------------------------------------------
# Base source map overlaid with the active data format's `sources` overrides (EDM = no overlay).
cfg_sources <- function(cfg)
  modifyList(cfg$raw[["sources"]] %||% list(), cfg_format_block(cfg)[["sources"]] %||% list())

# Resolve a logical source name to a physical table. Mirrors R dbplyr in_schema(dbname, ...).
cfg_table <- function(cfg, name) {
  srcs <- cfg_sources(cfg)
  if (is.null(srcs[[name]]))
    stop(sprintf("unknown source '%s'. Known: %s", name, paste(sort(names(srcs)), collapse = ", ")))
  vendors_resolve(cfg_vendor(cfg), cfg_source_layout(cfg),
                  cfg_source_schema(cfg), srcs[[name]], cfg_refresh(cfg))
}

cfg_all_tables <- function(cfg) {
  srcs <- cfg_sources(cfg)
  out <- list()
  for (nm in names(srcs)) out[[nm]] <- cfg_table(cfg, nm)
  out
}

# Resolve a source in a SPECIFIC schema (for multi-schema unions). Mirrors config.py::table_in.
cfg_table_in <- function(cfg, name, schema) {
  srcs <- cfg_sources(cfg)
  vendors_resolve(cfg_vendor(cfg), cfg_source_layout(cfg), schema, srcs[[name]], cfg_refresh(cfg))
}

# Every physical table a source resolves to: one normally, or one per source_union member schema.
cfg_source_fqns <- function(cfg, name) {
  u <- cfg_source_union(cfg)
  if (!is.null(u))
    return(vapply(u[["members"]], function(m) cfg_table_in(cfg, name, m[["schema"]]), ""))
  cfg_table(cfg, name)
}

# --- cohorts (pure) ---------------------------------------------------------
cfg_cohorts <- function(cfg) cfg$raw[["cohorts"]] %||% list()
cfg_cohort <- function(cfg, cohort_id) {
  for (c in cfg_cohorts(cfg)) if (identical(c[["id"]], cohort_id)) return(c)
  stop(sprintf("unknown cohort '%s'", cohort_id))
}

# --- variable packs / codelists (REVIEW-ONLY: need yaml::read_yaml on disk) ------------------
# Variable pack by ROLE = the file stem (demographics / clinical / treatment / outcomes), mirroring
# config.py.pack(role). Keeps the engine tumor-agnostic.
cfg_pack <- function(cfg, role) {
  rels <- cfg$raw[["variables"]] %||% list()
  for (rel in rels) {
    rel <- as.character(rel)
    if (identical(tools::file_path_sans_ext(basename(rel)), role))
      return(yaml::read_yaml(file.path(cfg$root, rel)))   # yaml:: resolved only when called
  }
  stop(sprintf("no variable pack for role '%s'", role))
}

cfg_roles <- function(cfg) {
  rels <- cfg$raw[["variables"]] %||% list()
  vapply(rels, function(rel) tools::file_path_sans_ext(basename(as.character(rel))), "")
}

cfg_codelist <- function(cfg, key) {
  rel <- (cfg$raw[["codelists"]] %||% list())[[key]]
  if (is.null(rel)) stop(sprintf("no codelist for key '%s'", key))
  yaml::read_yaml(file.path(cfg$root, as.character(rel)))
}

# --- loader (REVIEW-ONLY: needs the `yaml` package, present on Databricks) -------------------
.set_dotted <- function(d, dotted_key, value) {
  parts <- strsplit(dotted_key, ".", fixed = TRUE)[[1]]
  if (length(parts) == 1L) { d[[parts]] <- value; return(d) }
  head_key <- parts[1]
  rest <- paste(parts[-1], collapse = ".")
  node <- d[[head_key]] %||% list()
  d[[head_key]] <- .set_dotted(node, rest, value)
  d
}

# The ENVIRONMENT half, mirroring engine/config.py's PIPELINE. Same filename, same merge, same
# refusal of a key declared twice — the two engines run the SAME config, so a pack that loads in one
# and not the other is a cross-engine comparison that silently stopped comparing the same thing.
PIPELINE <- "pipeline.yaml"

load_config <- function(path, overrides = list()) {
  raw <- yaml::read_yaml(path)
  pipeline <- file.path(dirname(path), PIPELINE)
  if (file.exists(pipeline)) {
    env <- yaml::read_yaml(pipeline)
    if (!is.null(env)) {
      if (!is.list(env)) stop(sprintf("%s: must be a mapping", pipeline))
      both <- intersect(names(env), names(raw))
      if (length(both) > 0L) {
        stop(sprintf(paste0("%s defined in BOTH %s and %s — the environment half belongs in exactly ",
                            "one of them, and preferring either silently would decide where the ",
                            "product writes without anybody reading it."),
                     paste(sort(both), collapse = ", "), basename(path), PIPELINE))
      }
      raw[names(env)] <- env
    }
  }
  for (k in names(overrides)) {
    v <- overrides[[k]]
    if (is.null(v) || (is.character(v) && length(v) == 1L && !nzchar(v))) next  # skip blank passthroughs
    raw <- .set_dotted(raw, k, v)
  }
  root <- dirname(dirname(normalizePath(path, mustWork = FALSE)))   # folder containing config/
  make_config(raw, root)
}
