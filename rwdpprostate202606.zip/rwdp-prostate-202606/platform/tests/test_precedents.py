"""The precedent store must stay true, stay powerless, and store no answers.

`governance/precedents.yaml` is a reading list: questions more than one pack has had to argue out.
Three properties make it safe to trust, and each has a way of quietly breaking:

  * TRUE — every citation still resolves to a real decision in a real register. Rename a decision id
    and the store keeps printing a confident precedent that points at nothing.
  * POWERLESS — no gate reads it. The moment one does, an advisory file becomes a way to grant
    something, and "a human confirms" stops being true.
  * POINTERS ONLY — it holds no answers of its own. A copied answer is a second copy of a governed
    fact, agreeing on the day it is written and free to diverge forever after.

Run: python3 tests/test_precedents.py (or pytest).
"""
import ast
import os
import sys
from pathlib import Path

FRAMEWORK = Path(__file__).resolve().parent.parent
TOOLS = FRAMEWORK / "tools"
REPO = FRAMEWORK.parent
sys.path.insert(0, str(TOOLS))
sys.path.insert(0, str(FRAMEWORK / "tests" / "fixtures"))

import _packs             # noqa: E402
import contract_lint      # noqa: E402
import precedents         # noqa: E402
import product_gates      # noqa: E402


def test_every_citation_in_the_live_store_resolves():
    """The store as committed, against the registers as committed."""
    bad = precedents.errors(str(REPO))
    assert bad == [], "broken precedent citation(s):\n  " + "\n  ".join(bad)
    entries, _ = precedents.load(str(REPO))
    assert entries, "the store is empty — this test would prove nothing"


def test_a_precedent_needs_more_than_one_sighting():
    """One pack asking a question is a decision. A store that accepted one sighting would fill up
    with every question ever asked, and propose all of them to every new product."""
    assert precedents.MIN_SIGHTINGS >= 2
    entries, _ = precedents.load(str(REPO))
    for e in entries:
        packs = {s["pack"] for s in e["seen_in"]}
        assert len(e["seen_in"]) >= precedents.MIN_SIGHTINGS, f"{e['id']}: too few sightings"
        assert packs, f"{e['id']}: no packs cited"


def test_the_store_holds_no_answers():
    """Pointers only. `question` is the store's own words; everything else is read live from the
    register. An `answer:` key here would be the second copy this design exists to avoid."""
    entries, _ = precedents.load(str(REPO))
    allowed = {"id", "question", "seen_in"}
    for e in entries:
        extra = set(e) - allowed
        assert not extra, (f"{e['id']} carries {sorted(extra)} — the store holds pointers, not "
                           f"answers; the answer is read from the pack's register at display time")
        for s in e["seen_in"]:
            assert set(s) == {"pack", "decision"}, \
                f"{e['id']}: a sighting carries more than (pack, decision)"


def test_the_answer_shown_comes_from_the_register_not_the_store():
    """Proof the live read is real: the RESOLVED precedent's answer text is nowhere in the store
    file, and does appear in the rendered output."""
    store = (REPO / "governance" / "precedents.yaml").read_text(encoding="utf-8")
    rendered = precedents.render(str(REPO))
    entries, _ = precedents.load(str(REPO))

    resolved = []
    for e in entries:
        for s in e["seen_in"]:
            rows, status = precedents.register(str(REPO), s["pack"])
            if status.get(s["decision"]) == "RESOLVED":
                answer = contract_lint.cell(rows[s["decision"]], "Approved answer", "Answer")
                if answer.strip():
                    resolved.append(answer)
    assert resolved, "no cited decision is RESOLVED with an answer — this test is vacuous"

    probe = " ".join(resolved[0].split())[:40]
    assert probe not in store, "the store contains an answer — it must hold pointers only"
    assert probe in " ".join(rendered.split()), "the rendered output did not read the live answer"


def test_decisions_are_read_through_the_one_reader():
    """The same function OBJECT — a private markdown-table parser here is exactly the duplicate
    docs/ENGINEERING.md opens with, and the one that read a Status column positionally."""
    assert precedents.decision_rows is contract_lint.decision_rows
    assert precedents.decision_status is contract_lint.decision_status
    assert precedents.cell is contract_lint.cell


def test_proposals_key_on_recorded_sightings_only():
    """Over-propose, never under-propose. A pack cited in `seen_in` is covered; anything else is
    proposed — no matching of question wording, which would eventually pair two questions that
    merely sound alike and declare a pack covered when it is not."""
    entries, _ = precedents.load(str(REPO))
    cited = sorted({s["pack"] for e in entries for s in e["seen_in"]})
    assert cited, "no pack is cited anywhere"

    covered, todo, _ = precedents.propose(cited[0], str(REPO))
    assert covered, f"{cited[0]} is cited in the store but reported as covering nothing"
    assert all(cited[0] in {s["pack"] for s in e["seen_in"]} for e in covered)
    assert all(cited[0] not in {s["pack"] for s in e["seen_in"]} for e in todo)

    # A pack cited nowhere gets every precedent proposed, and none marked covered.
    covered2, todo2, _ = precedents.propose("products/oncology/nonexistent/000000", str(REPO))
    assert covered2 == [] and len(todo2) == len(entries)


def test_evidence_reaching_one_tumour_is_labelled_as_such():
    """Seven of the nine entries rest on prostate alone — two revisions of one programme.

    That is much weaker evidence a DIFFERENT tumour will hit the question than two tumours hitting
    it independently, and showing both kinds as one flat list overstated the seven. The source-key
    half refuses single-tumour recurrence outright; the decision half keeps it and must SAY so.
    """
    entries, _ = precedents.load(str(REPO))
    single = [e for e in entries if len(precedents.tumours(e)) < precedents.MIN_TUMOURS]
    multi = [e for e in entries if len(precedents.tumours(e)) >= precedents.MIN_TUMOURS]
    assert single and multi, "need both kinds present for this test to prove anything"

    for e in single:
        label = precedents.corroboration(e)
        assert "not yet corroborated" in label, f"{e['id']}: {label!r} overstates its evidence"
        assert "corroborated across" not in label
    for e in multi:
        assert "corroborated across" in precedents.corroboration(e)


def test_tumours_counts_tumours_not_packs():
    """The whole point: prostate/202606 and prostate/202607 are two packs and ONE tumour."""
    entry = {"seen_in": [{"pack": "products/oncology/prostate/202606", "decision": "A"},
                         {"pack": "products/oncology/prostate/202607", "decision": "B"}]}
    assert precedents.tumours(entry) == {"prostate"}
    entry["seen_in"].append({"pack": "products/oncology/oc/202606", "decision": "C"})
    assert precedents.tumours(entry) == {"prostate", "oc"}

    # ...and a GROUPING level is not a tumour. Packs are found by shape at any depth, so the tumour
    # is the segment above the version. Read at a fixed offset, everything under one grouping level
    # answered `gu` and two tumours corroborated each other.
    grouped = {"seen_in": [{"pack": "products/oncology/gu/prostate/202606", "decision": "A"},
                           {"pack": "products/oncology/gu/bladder/202606", "decision": "B"}]}
    assert precedents.tumours(grouped) == {"prostate", "bladder"}


def test_a_citation_outside_products_is_a_sighting_but_not_a_tumour():
    """`platform/tests/fixtures/prostate_202607` is a parked spec revision the store still cites.

    Read positionally it answered `fixtures` — a tumour nothing has ever delivered — and seven
    single-tumour entries became corroborated the moment the directory moved. Evidence must not be
    manufactured by a `git mv`. The sighting still counts (a human read that register and judged it
    the same question); it is not a second tumour.
    """
    parked = _packs.PARKED_REL
    assert precedents._slug(parked) == "", f"{parked} resolved to a tumour"

    entry = {"seen_in": [{"pack": "products/oncology/prostate/202606", "decision": "A"},
                         {"pack": parked, "decision": "B"}]}
    assert precedents.tumours(entry) == {"prostate"}
    assert len(entry["seen_in"]) >= precedents.MIN_SIGHTINGS      # still a precedent...
    assert "not yet corroborated" in precedents.corroboration(entry)   # ...and still uncorroborated

    # The live store cites it, so this is the real thing and not a hypothetical.
    entries, _ = precedents.load(str(REPO))
    assert any(s["pack"] == parked for e in entries for s in e["seen_in"]), \
        "the store no longer cites the parked pack — this test has lost its subject"


def test_corroborated_precedents_are_listed_first():
    """A reader works down the list, so what two tumours independently hit belongs at the top."""
    _, todo, _ = precedents.propose("products/oncology/endometrial/YYYYMM", str(REPO))
    ordered = sorted(todo, key=precedents._by_strength)
    counts = [len(precedents.tumours(e)) >= precedents.MIN_TUMOURS for e in ordered]
    assert counts == sorted(counts, reverse=True), "uncorroborated entries sorted above proven ones"

    rendered = precedents.render_proposals("products/oncology/endometrial/YYYYMM", str(REPO))
    # Asserted, not indexed. `.index()` on an absent label raises ValueError, and because this test
    # sorts alphabetically ahead of the one that checks the labels themselves, a collapsed label
    # surfaced as a traceback here instead of as its own diagnosis there.
    assert "corroborated across" in rendered, "no entry is labelled as corroborated"
    assert "not yet corroborated" in rendered, \
        "no entry is labelled uncorroborated — the two kinds of evidence have been collapsed"
    assert rendered.index("corroborated across") < rendered.index("not yet corroborated"), \
        "the rendered list leads with unproven entries"
    assert "2 corroborated across two or more tumours" in rendered


def test_source_keys_are_derived_and_never_stored():
    """The opposite call to the decision half, and the reason is worth keeping straight.

    `FUED-DEFINITION` and `OC-FU-END-DEFINITION` are the same question in two vocabularies, so a
    human has to say so and the YAML carries that. `demographics` and `demographics` are the same
    STRING, so writing them down would be a second copy of what the configs already say — stale the
    first time a pack adds a source.
    """
    store = (REPO / "governance" / "precedents.yaml").read_text(encoding="utf-8")
    for banned in ("source_keys:", "source_resolutions:", "sources:"):
        assert banned not in store, f"the store hand-lists {banned} — derive it from the configs"

    derived = precedents.source_key_precedents(str(REPO))
    assert derived, "derived nothing — the test would be vacuous"
    assert sum(len(v) for v in derived.values()) >= 10


def test_a_source_key_is_only_evidence_within_its_vendor():
    """Flatiron packs all declare practice/ses/telemed/vitals; neither COTA pack declares any.
    Proposing across that line would propose four tables that do not exist."""
    derived = precedents.source_key_precedents(str(REPO))
    assert {"flatiron", "cota"} <= set(derived), f"expected both vendors, got {sorted(derived)}"
    flat, cota = set(derived["flatiron"]), set(derived["cota"])
    only_flat = flat - cota
    assert only_flat, "the vendors declare identical keys — this test proves nothing"
    for key in only_flat:
        assert key not in cota, f"{key} leaked across the vendor boundary"

    # And end to end: no COTA pack is ever offered a Flatiron-only key.
    for pack in sorted(precedents.products(str(REPO))):
        vendor, keys = precedents.source_key_proposals(pack, str(REPO))
        if vendor == "cota":
            assert not (set(k for k, _ in keys) & only_flat), f"{pack} was offered a flatiron key"


def test_one_tumour_repeating_itself_is_not_a_precedent():
    """prostate 202603 and 202606 both declare `psa`, `provenge` and `alphabet`. That is one
    specification being re-read across two revisions, not evidence any other tumour needs them."""
    derived = precedents.source_key_precedents(str(REPO))
    single = {k for k, tum in derived.get("flatiron", {}).items() if len(tum) == 1}
    assert single, "no single-tumour key exists — this test proves nothing"

    for pack in sorted(precedents.products(str(REPO))):
        slug = pack.replace(os.sep, "/").split("/")[2]
        _, keys = precedents.source_key_proposals(pack, str(REPO))
        for key, others in keys:
            assert len(others) >= precedents.MIN_TUMOURS
            assert slug not in others, f"{pack}: proposed {key} on the strength of its own tumour"
            assert key not in single, f"{pack}: proposed {key}, seen in only one tumour"


def test_an_unknown_vendor_proposes_nothing():
    """Fail closed. A pack with no registry entry has no vendor, and a guess would propose another
    delivery's sources."""
    vendor, keys = precedents.source_key_proposals("products/oncology/nope/000000", str(REPO))
    assert vendor is None and keys == []


def test_a_pack_with_no_registry_entry_contributes_nothing_to_the_derivation():
    """On a SYNTHETIC root, because every pack in this repo happens to be registered.

    That is why this fixture exists rather than an assertion over the live packs: the skip in
    source_key_precedents is unreachable from real data today, so a mutation that defaulted the
    vendor instead of skipping passed every other test here. An unregistered pack folded in under a
    guessed vendor would put its sources into another delivery's evidence, and the first sign would
    be a proposal naming a table that vendor does not deliver.
    """
    import tempfile
    import textwrap
    with tempfile.TemporaryDirectory() as tmp:
        reg = os.path.join(tmp, "products")
        os.makedirs(reg)
        with open(os.path.join(reg, "registry.yaml"), "w", encoding="utf-8") as fh:
            fh.write("tumors:\n  - { code: kn, name: Known, slug: known, vendor: flatiron,\n"
                     "      tumor_class: solid, status: scaffold, current_spec_version: \"202601\" }\n")
        for slug in ("known", "ghost"):
            cfg = os.path.join(reg, "oncology", slug, "202601", "config")
            os.makedirs(cfg)
            with open(os.path.join(cfg, "data_product.yaml"), "w", encoding="utf-8") as fh:
                fh.write(textwrap.dedent(f"""\
                    data_product_id: {slug}_rwdp
                    sources:
                      {slug}_only_key: t_whatever
                      shared_key: t_shared
                    """))

        derived = precedents.source_key_precedents(tmp)
        assert set(derived) == {"flatiron"}, f"an unregistered pack got a vendor: {sorted(derived)}"
        assert set(derived["flatiron"]) == {"known_only_key", "shared_key"}, \
            "the unregistered pack's sources entered the derivation"
        assert "ghost_only_key" not in derived["flatiron"]
        assert "ghost" not in derived["flatiron"]["shared_key"], \
            "the unregistered pack was counted as a tumour sighting"


def test_no_physical_table_name_is_ever_proposed():
    """They are not stable even within a vendor (t_demographics vs t_meg_demographics; mortality
    differs across all three Flatiron packs), and confirming one is Gate 3's job, with a profile and
    a human. Proposing one would guess exactly what the framework refuses to guess."""
    derived = precedents.source_key_precedents(str(REPO))
    for vendor, keys in derived.items():
        for key in keys:
            assert not key.startswith("t_"), f"{vendor}: {key} looks like a physical table name"

    rendered = precedents.render_proposals("products/oncology/endometrial/YYYYMM", str(REPO))
    assert "t_demographics" not in rendered and "t_meg_" not in rendered, \
        "a physical table name reached the proposal output"


def test_version_drift_only_ever_compares_a_tumour_with_itself():
    """It is the complement of the precedent proposals, and the two must not blur: proposals
    exclude this tumour, drift reports ONLY this tumour."""
    seen_any = {}
    for pack in sorted(precedents.products(str(REPO))):
        slug = precedents._slug(pack)
        drift = precedents.version_drift(pack, str(REPO))
        seen_any[pack] = drift
        for key, others in drift.items():
            for other in others:
                assert precedents._slug(other) == slug, \
                    f"{pack}: drift cites {other}, a different tumour — that is precedent, not drift"
                assert other != pack, f"{pack}: drift cites the pack itself"
    assert any(seen_any.values()), "no pack drifts at all — this test would prove nothing"


def test_version_drift_reports_only_keys_this_pack_lacks():
    """One direction. A version that ADDS sources is the ordinary shape of a new spec revision, and
    listing those would bury the line worth reading."""
    for pack in sorted(precedents.products(str(REPO))):
        mine = precedents._declared(str(REPO), pack)
        for key in precedents.version_drift(pack, str(REPO)):
            assert key not in mine, f"{pack}: drift reports {key}, which this pack declares"


def test_a_tumour_with_one_pack_has_no_drift():
    """Nothing to compare against is not a finding."""
    packs = sorted(precedents.products(str(REPO)))
    by_slug = {}
    for p in packs:
        by_slug.setdefault(precedents._slug(p), []).append(p)
    singles = [ps[0] for ps in by_slug.values() if len(ps) == 1]
    assert singles, "every tumour has multiple packs — this test would prove nothing"
    for p in singles:
        assert precedents.version_drift(p, str(REPO)) == {}


def test_drift_is_rendered_apart_from_precedent_and_after_it():
    """Run together they would read as one list of proposals, and one of them is not a proposal."""
    r = precedents.render_proposals("products/oncology/prostate/202606", str(REPO))
    assert "VERSION DRIFT" in r, "the drift section did not render"
    assert "SOURCE KEYS" in r
    assert r.index("SOURCE KEYS") < r.index("VERSION DRIFT"), "drift rendered above the proposals"
    assert "NOT precedent" in r, "the drift section does not say it is not a precedent"


def test_a_pack_with_nothing_to_propose_gets_no_preamble():
    """The pack that seeded the store had four paragraphs introducing an empty list."""
    seeded = precedents.render_proposals("products/oncology/prostate/202606", str(REPO))
    assert "Nothing to propose" in seeded
    assert "QUESTIONS TO EXPECT" not in seeded, "preamble printed over an empty list"

    has_todo = precedents.render_proposals("products/oncology/endometrial/YYYYMM", str(REPO))
    assert "QUESTIONS TO EXPECT" in has_todo, "the preamble vanished where it is needed"


def _drift_kinds():
    """(a pack that has drifted, a pack that never started, the root they live in).

    A MATERIALISED ROOT. The unstarted pack is prostate/202607, which is not a product — it never
    was one (unregistered, never built, never released) and sat in `products/` only so these tests
    had a subject. `_packs` restores it to its product path in a temp copy, alongside the real
    packs, which supply the started side of the same contrast; a root holding only the fixture would
    make every one of these assertions vacuous in the direction that matters.
    """
    root = _packs.materialised_root()
    started = unstarted = None
    for pack in sorted(precedents.products(root)):
        if not precedents.version_drift(pack, root):
            continue
        if precedents._declared(root, pack):
            started = started or pack
        else:
            unstarted = unstarted or pack
    assert started and unstarted, "need a drifted pack AND an unstarted one for these tests"
    return started, unstarted, root


def test_a_pack_that_never_started_is_not_described_as_having_regressed():
    """NOT STARTED and REGRESSED are different states and only one is a defect.

    prostate/202607 has no config/ at all, so every key its siblings declare counted as drift —
    under a heading telling the reader the tool could not distinguish a removal from a regression,
    when nothing had been removed. Same shape as scoring an absent test suite as PASS.
    """
    started, unstarted, root = _drift_kinds()

    r = precedents.render_proposals(unstarted, root)
    assert "nothing has DRIFTED" in r, f"{unstarted}: an unstarted pack is not told so"
    assert "cannot tell a deliberate removal from a regression" not in r, \
        f"{unstarted} has never declared a source and is being described as possibly regressed"

    r2 = precedents.render_proposals(started, root)
    assert "cannot tell a deliberate removal from a regression" in r2
    assert "nothing has DRIFTED" not in r2, f"{started} declares sources and is called unstarted"


def test_the_unstarted_section_reports_only_what_the_checklist_does_not():
    """The two lists otherwise overlap almost entirely — sixteen of twenty-one on prostate/202607.
    What is worth reading is the remainder: sources only this product has ever needed."""
    _, unstarted, root = _drift_kinds()
    drift = precedents.version_drift(unstarted, root)
    _, proposed = precedents.source_key_proposals(unstarted, root)
    already = {k for k, _ in proposed}
    overlap, extra = already & set(drift), set(drift) - already
    assert overlap and extra, "need both an overlap and a remainder for this to prove anything"

    section = precedents.render_proposals(unstarted, root).split("VERSION DRIFT", 1)[1]
    for key in sorted(overlap):
        assert f"! {key} " not in section, f"{key} is listed twice — once as a proposal, once here"
    for key in sorted(extra):
        assert f"! {key} " in section, f"{key} is only in this section and was dropped"


def test_tripwire_vendor_and_tumour_class_are_still_perfectly_correlated():
    """A TRIPWIRE, not a requirement. It is SUPPOSED to fail one day, and the failure is the point.

    The source-key half scopes on vendor, resting on one observation: all four Flatiron packs
    declare practice/ses/telemed/vitals and neither COTA pack declares any. But every Flatiron
    registry entry is `solid` and every COTA entry is `heme`, so that observation fits "does not
    cross vendors" and "does not cross solid/heme" equally well. The data cannot separate them.

    The first Flatiron heme product — or COTA solid product — separates them, and this fires on the
    day it lands. When it does, do not simply delete it: look at whether that pack's sources follow
    its vendor or its tumour class, and scope on whichever it turns out to be. Nothing else in the
    suite would notice, because scoping on the wrong axis is invisible until the axes disagree.
    """
    import yaml
    reg = yaml.safe_load((REPO / "products" / "registry.yaml").read_text(encoding="utf-8"))
    pairs = {}
    for t in reg["tumors"]:
        pairs.setdefault(t.get("vendor"), set()).add(t.get("tumor_class"))
    assert len(pairs) > 1, "only one vendor in the registry — the tripwire cannot arm"

    classes_per_vendor = {v: sorted(c) for v, c in pairs.items()}
    collisions = [v for v, c in pairs.items() if len(c) > 1]
    seen_classes = [c for cs in pairs.values() for c in cs]
    shared = len(seen_classes) != len(set(seen_classes))

    assert not collisions and not shared, (
        "THE CONFOUND IS BROKEN — and that is good news, not a defect.\n"
        f"    vendor -> tumour classes: {classes_per_vendor}\n"
        "    Vendor and tumour class are no longer perfectly correlated, so it is now possible to\n"
        "    tell which axis a pack's source keys actually follow. Check that pack, then scope\n"
        "    source_key_precedents on whichever axis the evidence supports, and delete this test.")


def test_the_tumour_is_derived_in_exactly_one_place():
    """`_slug` is the ONE reader of a tumour out of a pack path, and it had three inline copies.

    All four spelled `split("/")[2]`, all four agreed, and the copies were invisible: fixing the
    offset in `_slug` left `source_key_precedents` grouping by the GROUPING level, so the derived
    half and the labelled half would disagree about which packs are one tumour.

    AST, not a text search. A grep for the pattern is defeated by a comment containing it — this
    codebase has now written that same guard six times and had it defeated once.
    """
    tree = ast.parse((TOOLS / "precedents.py").read_text(encoding="utf-8"))
    offenders = []
    for fn in [n for n in ast.walk(tree) if isinstance(n, ast.FunctionDef)]:
        if fn.name == "_slug":
            continue
        for node in ast.walk(fn):
            # <something>.split(...)[<n>] — indexing straight into a split path.
            if (isinstance(node, ast.Subscript) and isinstance(node.value, ast.Call)
                    and isinstance(node.value.func, ast.Attribute)
                    and node.value.func.attr == "split"):
                offenders.append(f"{fn.name}:{node.lineno}")
    assert not offenders, ("a second derivation of a path segment outside _slug: "
                           + ", ".join(offenders))


def test_no_gate_reads_the_store():
    """POWERLESS is the property, and it is enforced by nobody importing it.

    If a gate ever reads precedents.yaml, an advisory reading list has become a thing that can
    grant — and the "AI proposes, humans approve" boundary quietly moves.
    """
    gates = ["source_manifest.py", "product_gates.py", "contract_lint.py", "contract_binding.py",
             "source_check.py", "finalize.py", "deploy_tree.py", "bundle_products.py",
             "repo_hygiene.py", "contract_scaffold.py", "spec_slice.py"]
    for g in gates:
        src = (TOOLS / g).read_text(encoding="utf-8")
        assert "precedents" not in src, (
            f"{g} mentions precedents — the store is ADVISORY and no gate may read it")


def test_the_store_is_not_deployed_to_production():
    """It is governance prose about how products get built; the runtime has no use for it."""
    import deploy_tree
    assert not any("precedents" in str(f) for f in deploy_tree.ROOT_FILES)


def test_an_answer_is_read_whatever_the_register_spells_the_column():
    """THE REGISTERS DISAGREE, AND A CALLER KNOWING A SUBSET LOSES ANSWERS SILENTLY.

    The answer column is `Approved answer` in prostate/202606 and `Resolution` in prostate/202607
    and oc/202606. This harvester knew ("Approved answer", "Answer") — so oc/202606's RESOLVED
    OC-PSOC-SHEET, which carries a real answer under `Resolution`, came back as the empty string.
    One of only three resolved decisions in the repository, dropped by a spelling, with no error.

    The vocabulary now lives in contract_lint beside the reader that owns the tables. This asserts
    every accepted spelling resolves, and that the store reads a real recorded answer off a pack
    that uses a non-canonical one."""
    import contract_lint as cl
    for spelling in cl.ANSWER_COLUMNS:
        row = {"ID": "D-1", spelling: "the agreed answer"}
        assert cl.decision_answer(row) == "the agreed answer", \
            f"{spelling!r} is declared an accepted answer column but does not resolve"

    # ...and it bites on the real pack that caused it: a RESOLVED decision must not read as blank.
    found = False
    for pack in sorted(product_gates.products(str(REPO))):
        path = os.path.join(str(REPO), pack, "handoff", "DECISIONS.md")
        if not os.path.exists(path):
            continue
        text = cl.read(path)
        rows = cl.decision_rows(text)
        for did, status in cl.decision_status(text).items():
            if str(status).strip().upper() != "RESOLVED":
                continue
            found = True
            assert (cl.decision_answer(rows[did]) or "").strip(), \
                f"{pack}:{did} is RESOLVED but its answer reads as blank — a spelling is unmapped"
    assert found, "no pack has a RESOLVED decision — this test would prove nothing"


if __name__ == "__main__":
    os.chdir(FRAMEWORK)
    fns = [v for k, v in sorted(globals().items()) if k.startswith("test_")]
    for fn in fns:
        fn()
        print(f"ok  {fn.__name__}")
    print(f"\n{len(fns)} tests passed")
