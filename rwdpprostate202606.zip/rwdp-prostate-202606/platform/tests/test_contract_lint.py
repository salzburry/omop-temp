"""The shared functional-contract lint, exercised on a synthetic product.

Two things are being held here. First, that the invariants BITE — a lint nobody has seen fail is a lint
nobody knows works. Second, that they run against a product that is not prostate: the whole point of
moving them into platform/tools was that a second tumour must not need a second copy.

The fixture below is a complete miniature product — the smallest thing the lint considers valid — so a
new tumour can read it as the shape to fill in.

Run: python3 -m pytest platform/tests/test_contract_lint.py (or pytest).
"""
import json
import os
import sys
import tempfile
from pathlib import Path

REPO = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(REPO / "platform" / "tools"))

import contract_lint                                                    # noqa: E402

# The ai_extraction fixture helpers, IMPORTED rather than reimplemented. `--item` drafting now goes
# through `contract_scaffold.ai_gate`, so any test that lifts spec text needs a pack somebody has
# signed — and `test_spec_slice` already owns the only correct way to produce one (a throwaway COPY,
# signed against its own path and bytes, because an approval binds to both). A second signer here
# would be a second answer to "what does an approved extraction look like", and the two would agree
# right up until the first field is added to the block.
sys.path.insert(0, str(Path(__file__).resolve().parent))
from test_spec_slice import _approved, _sign                            # noqa: E402
from source_manifest import ai_readable as _sm_ai_readable              # noqa: E402

RECORD = """```yaml
variable_id: {vid}
spec_refs: [{ref}]
spec_digest: {digest}
required_rule: PD-L1 tumour proportion score at index
source: {{logical_table: biomarkers, physical_stem: t_enh_nsclc_biomarker, columns: {{value: pdl1percent}}}}
grain: [patientid, index_date, cohortn]
anchor: index_date
window: "[-30, +7]"
record_selection: closest
tie_break: {{equidistant: prior, same_day: max}}
derivation: "try_cast(pdl1percent as double), closest to index"
cohort_applicability: all cohorts
missing: {{no_record: null, present_null: null}}
units: percent
depends_on: [INDEXDT]
output: {{physical_name: pdl1_tps, target_published_name: PDL1_TPS, name_status: aligned, type: double, nullable: true, codes: n/a, role: published}}
status: {{requirement: {req}, source: unverified, implementation: {impl}, validation: not_run}}
decision_ids: [{decs}]
gap_ids: [{gaps}]
publish: {{ads: configured, dictionary: configured, dashboard: undecided, tfl: undecided}}
acceptance: "pdl1percent=55 at index-3d -> PDL1_TPS=55"
notes: synthetic fixture
implementation_refs: [none]
```
"""


def build_product(tmp, records, spec_rows=((("clinical"), 3),), flags=(), sources=False):
    """A miniature product: handoff artifacts plus the spec-pipeline extraction I8 resolves against."""
    # A counter in the path so one test can build several products in the same tmpdir.
    build_product.n = getattr(build_product, "n", 0) + 1
    product = Path(tmp) / f"p{build_product.n}" / "products" / "oncology" / "nsclc" / "202606"
    (product / "handoff").mkdir(parents=True)
    (product / "spec_pipeline" / "out").mkdir(parents=True)
    (product / "handoff" / "FUNCTIONAL_CONTRACT.md").write_text("# contract\n\n" + "\n".join(records))
    (product / "handoff" / "DECISIONS.md").write_text(
        "| ID | Question | Owner | Status |\n|---|---|---|---|\n"
        "| NAME-ALIGN | naming | RWP | OPEN |\n| BIOM-WINDOW | window | RWB | OPEN |\n"
        "| FUED-RULE | follow-up end | RWB | RESOLVED |\n")
    (product / "handoff" / "ENGINE_GAPS.md").write_text(
        "| Gap | What |\n|---|---|\n| G-PDL1 | Engine · PD-L1 closest-record |\n")
    # A row the REAL readers can use, not just I8's `(domain, row)` lookup. `contract_scaffold`'s
    # `requirement_rows`/`evidence_for` need the shape the extractor actually emits, and a stub with
    # two keys meant `--item` — now required whenever a pack has an extraction — could not resolve
    # against any fixture in this file.
    rows = [{"domain": d, "row": r, "item_id": f"{d}:{r}", "tab": d, "cells": [],
             "variable": "PDL1_TPS", "content_hash": "", "text": "",
             "fields": {"variable": "PDL1_TPS", "definition": "PD-L1 tumour proportion score at index"}}
            for d, r in spec_rows]
    # The extraction ENVELOPE, not just the rows. `ai_extraction_block` binds an approval to the run
    # (`fingerprint`) and to the redaction policy in force, and refuses an artifact carrying neither
    # as one that predates the redactor — so a fixture without it cannot be signed, and every
    # `--item` test would have to skip.
    import source_manifest as _sm
    (product / "spec_pipeline" / "out" / "extracted.json").write_text(json.dumps(
        {"extraction": {"extractor_version": "1.2", "fingerprint": "f1x7ure0000feed",
                        "redaction": {"policy_sha256": _sm.redaction_policy_sha256(),
                                      "cells_redacted": 0, "rows_redacted": 0},
                        "sources": [], "row_count": len(rows)},
         "rows": rows}))
    # ...and the ancestry an ai_extraction is derived from. Two links, because `ai_readable` walks the
    # WHOLE chain rather than the parent: one extra registered hop is how a vendor_restricted document
    # moved out of view once already.
    (product / "source_refs.yaml").write_text(
        "source_materials:\n"
        "  - material_id: program_spec\n"
        "    material_type: program_spec\n"
        "    status: reviewed\n"
        "    ai_classification: sponsor_ai_eligible\n"
        "  - material_id: spec_tabs\n"
        "    material_type: extraction_input\n"
        "    derived_from: program_spec\n"
        "    status: reviewed\n"
        "    ai_classification: sponsor_ai_eligible\n")
    # WHICH registered material the extractor read. `pipeline_material` resolves the parent through
    # this and returns None when it cannot — so without it the signed block records
    # `derived_from: TODO` and `ai_readable` refuses, correctly, for a reason that has nothing to do
    # with the test.
    (product / "spec_pipeline" / "pipeline.conf").write_text("TUMOR=nsclc\nSPEC_SOURCE_ID=spec_tabs\n")
    _sign(str(product))
    # lint.json ships from the same pipeline run as extracted.json, and I17 treats one without the
    # other as a half-written out/ rather than a reason to skip. `flags` seeds the unsettled rows.
    (product / "spec_pipeline" / "out" / "lint.json").write_text(json.dumps(
        {"findings": [{"item_id": i, "kind": k, "detail": "fixture", "severity": "INFO"}
                      for i, k in flags],
         "applicability": {"foreign_table": "applied", "reasons": []}}))
    # A pack with NO config/ is the pre-config state every new tumour starts in — the one condition
    # that makes `source.kind: pending_mapping` legal. Default off, because that IS the new-tumour
    # shape; pass sources=True for a pack that has a registry and so has run out of that excuse.
    if sources:
        (product / "config").mkdir(parents=True)
        (product / "config" / "data_product.yaml").write_text(
            "product_id: nsclc\nsources:\n  biomarkers:\n    stem: t_enh_nsclc_biomarker\n")
    return str(product)


def lint(tmp, records, **kw):
    return contract_lint.run(build_product(tmp, records, **kw))


def one(vid="PDL1_TPS", ref="clinical:3", req="approved", impl="implemented", decs="", gaps=""):
    # The digest is computed by the LINT's own function over the fixture's rows (which carry no
    # content_hash), so these records stay valid under I15 without restating how the hash is built.
    m = contract_lint.SPEC_REF_RE.match(ref)
    srows = {}
    if m:
        lo, hi = int(m.group(2)), int(m.group(3) or m.group(2))
        srows = {m.group(1): {n: "" for n in range(lo, hi + 1)}}
    digest = contract_lint.spec_digest([ref], srows) or contract_lint.NA
    return RECORD.format(vid=vid, ref=ref, req=req, impl=impl, decs=decs, gaps=gaps, digest=digest)


PENDING = """```yaml
variable_id: {vid}
spec_refs: [clinical:3]
spec_digest: {digest}
required_rule: PD-L1 tumour proportion score at index
source: {{kind: pending_mapping, spec_identifiers: [{idents}]}}
grain: [patientid, index_date, cohortn]
anchor: index_date
window: "[-30, +7]"
record_selection: closest
tie_break: {{equidistant: prior, same_day: max}}
derivation: "closest to index"
cohort_applicability: all cohorts
missing: {{no_record: null, present_null: null}}
units: percent
depends_on: [INDEXDT]
output: {{physical_name: pdl1_tps, target_published_name: PDL1_TPS, name_status: undecided, type: double, nullable: true, codes: n/a, role: published}}
status: {{requirement: {req}, source: {src}, implementation: {impl}, validation: not_run}}
decision_ids: []
gap_ids: [{gaps}]
publish: {{ads: undecided, dictionary: undecided, dashboard: undecided, tfl: undecided}}
acceptance: "pdl1percent=45 -> PDL1_TPS=45"
notes: "Logical source registry not yet authored. Identifier copied exactly from the spec."
implementation_refs: [none]
```"""


def pending(vid="PDL1_TPS", idents="pdl1percent", req="draft", src="unverified",
            impl="not_implemented", gaps="G-PDL1"):
    digest = contract_lint.spec_digest(["clinical:3"], {"clinical": {3: ""}}) or contract_lint.NA
    return PENDING.format(vid=vid, idents=idents, req=req, src=src, impl=impl, gaps=gaps,
                          digest=digest)


def test_i19_implementation_refs_must_be_ANSWERED_not_merely_present():
    """The column being present is not the field being answered. #344 made it structurally required
    but left the VALUE outside CANON, so the binder asked for it only when `implementation` was
    `implemented` or `partial` — and 33 prostate/202606 records sat at `TODO`, which reads the same as
    a blank cell and the opposite of a deliberate `[none]`."""
    with tempfile.TemporaryDirectory() as tmp:
        for bad in ("", "TODO"):
            rec = one().replace("implementation_refs: [none]", f"implementation_refs: {bad}".rstrip())
            errors, _ = lint(tmp, [rec])
            assert any("I19" in e for e in errors), (bad, errors)
        # `[none]` is an ANSWER and passes
        assert lint(tmp, [one()])[0] == []


def test_pending_mapping_is_legal_on_a_pack_with_no_source_registry():
    """The state every new tumour starts in. The workflow authors the contract BEFORE config, so
    there is no `sources:` block to name — and until this kind existed the skill could only say what
    not to write (invent no alias) while offering nothing the parser accepts. Drafters filled that
    with TODO, a physical table name, or an invented alias; the last is indistinguishable from a real
    mapping once config arrives."""
    with tempfile.TemporaryDirectory() as tmp:
        errors, n = lint(tmp, [pending()])
        assert errors == [], errors
        assert n == 1


def test_pending_mapping_is_ILLEGAL_once_the_pack_has_a_source_registry():
    """The condition that stops it becoming permanent. Once a registry exists an alias CAN be named,
    so declining to name one is a mapping nobody did, not a state the pack is in."""
    with tempfile.TemporaryDirectory() as tmp:
        errors, _ = lint(tmp, [pending()], sources=True)
        assert any("HAS a source registry" in e for e in errors), errors


def test_pending_mapping_must_carry_the_specs_own_identifiers():
    """Verbatim, so the mapping can be finished by someone who never read the workbook. Without them
    the record states no source at all — which is the invented-alias failure with extra steps."""
    with tempfile.TemporaryDirectory() as tmp:
        errors, _ = lint(tmp, [pending(idents="")])
        assert any("requires `spec_identifiers: [...]`" in e for e in errors), errors
        errors, _ = lint(tmp, [pending(idents="TODO")])
        assert any("placeholder 'TODO'" in e for e in errors), errors


def test_pending_mapping_needs_NO_gap_because_the_starter_has_no_gap_register():
    """The reverse of what this used to assert, and the old version broke every new product.

    A gap is an APPROVED requirement the build or feed cannot satisfy — Gate 4 material that arrives
    after the contract exists — and `sandbox/new_tumour_start/handoff/` ships no ENGINE_GAPS.md at
    all. So requiring one gave: no registry -> use pending_mapping -> I18 demands a gap -> no gap
    register -> the id resolves to nothing -> I2 fails. It was redundant as well as broken:
    `pending_mapping` is already explicit, countable and barred from approval, so a gap restating it
    is a second record of one fact.
    """
    with tempfile.TemporaryDirectory() as tmp:
        assert lint(tmp, [pending(gaps="")])[0] == [], lint(tmp, [pending(gaps="")])[0]
        # ...and a gap is still ALLOWED, for a genuinely broader implementation problem
        assert lint(tmp, [pending(gaps="G-PDL1")])[0] == []


def test_the_starter_pack_really_has_no_gap_register():
    """The premise of the test above. If a gap register is ever added to the starter, the reasoning
    changes and someone should revisit this deliberately rather than discover it."""
    starter = REPO / "sandbox" / "new_tumour_start" / "handoff"
    if not starter.exists():
        return
    assert not (starter / "ENGINE_GAPS.md").exists(), \
        "the starter grew a gap register — re-examine whether pending_mapping should cite one"


def test_pending_mapping_can_never_be_approved_verified_or_built():
    """It cannot pass Gate 3, Gate 4 or approval. Each axis separately: approving a rule nobody can
    execute, verifying a source that does not exist, or building from one, are three different lies."""
    with tempfile.TemporaryDirectory() as tmp:
        for kw, want in ((dict(req="approved"), "cannot be `requirement: approved`"),
                         (dict(src="verified_live"), "must be `source: unverified`"),
                         (dict(impl="implemented"), "cannot be `implementation: implemented`")):
            errors, _ = lint(tmp, [pending(**kw)])
            assert any(want in e for e in errors), (kw, errors)


def test_pending_mapping_does_NOT_force_the_requirement_axis_to_decision_required():
    """The two axes stay apart. A requirement RWB has fully specified does not become an open
    scientific question because RWP has not yet chosen a logical alias — that is a configuration task,
    and conflating them buries the rows that genuinely need RWB."""
    with tempfile.TemporaryDirectory() as tmp:
        errors, _ = lint(tmp, [pending(req="draft")])
        assert errors == [], errors
        assert not any("decision_required" in e for e in errors)


def test_pending_mapping_is_not_vendor_sourced_so_gate_3_does_not_ask_it_for_evidence():
    """It has no vendor table to evidence. Counting it as vendor-sourced would put an unanswerable
    row in the Gate 3 backlog; counting it as `constant` would excuse it forever."""
    block = pending()
    assert contract_lint.source_kind(block) == contract_lint.PENDING_MAPPING
    assert not contract_lint.vendor_sourced(block)


def test_the_renderer_and_the_reader_agree_on_every_record_in_the_repo():
    """The writer is checked against the READER, on real records, not by eye.

    `render_row` exists so the drafting model stops assembling markdown by hand — field order, pipe
    escaping, newline folding and cell count are mechanical, and one unescaped `|` shifts every later
    field into the wrong key while leaving each cell individually well-formed. A renderer nobody
    verifies is just a second notation; this parses every shipped record, re-renders it, and requires
    the round-trip to be exact.
    """
    import contract_record
    for pack in sorted((REPO / "products").glob("*/*/*/handoff/FUNCTIONAL_CONTRACT.md")):
        text = pack.read_text(encoding="utf-8")
        blocks = list(contract_lint.records(text))
        assert blocks, f"{pack} parsed as zero records"
        for b in blocks:
            rec = {ln.split(":", 1)[0]: ln.split(":", 1)[1].strip()
                   for ln in b.splitlines() if ":" in ln}
            _row, problems = contract_record.row_for(rec)
            assert not problems, (pack.parent.parent.name, rec.get("variable_id"), problems)


def test_the_renderer_escapes_pipes_folds_newlines_and_keeps_cell_count():
    """The four mechanical rules the skill used to delegate to the model."""
    import re as _re
    import contract_record
    rec = {"variable_id": "X", "notes": "has a | pipe\nand a newline", "implementation_refs": ["none"],
           "output": {"physical_name": "x", "nullable": True}}
    # allow_partial: this checks ESCAPING, not completeness. A partial record is refused by default
    # now — see the test below — and this flag exists for exactly this case and no other.
    row, problems = contract_record.row_for(rec, allow_partial=True)
    assert not problems, problems
    assert len(_re.split(r"(?<!\\)\|", row.strip())[1:-1]) == len(contract_lint.TABLE_COLUMNS)
    assert "\n" not in row and r"\|" in row
    assert "nullable: true" in row, "a YAML bool must render as the contract writes it, not 'True'"
    assert contract_lint.table_shape_errors(contract_lint.render_table([rec])) == []


def test_revising_an_EXISTING_record_replaces_it_rather_than_duplicating_it():
    """`--product` copied the pack and APPENDED the candidate. Right for a new record; wrong for the
    revision case the skill explicitly supports — the temp copy then held two records with one
    variable_id, so a valid replacement failed I1 as a duplicate.

    The pack here is built in TABLE format on purpose. The shared fixture writes fenced ```yaml
    blocks, and `records()` ignores fenced blocks entirely once a table exists — so appending a table
    to a fenced pack silently REPLACES the whole contract, no duplicate is ever created, and a test
    written against that fixture passes whether the replace logic works or not. It did, and caught
    nothing.
    """
    import contract_record
    import contract_scaffold
    import yaml as _y
    with tempfile.TemporaryDirectory() as tmp:
        rec = {ln.split(": ", 1)[0]: ln.split(": ", 1)[1]
               for ln in one().splitlines() if ": " in ln and not ln.startswith("```")}
        product = build_product(tmp, [contract_lint.render_table([rec])])
        contract = os.path.join(product, "handoff", "FUNCTIONAL_CONTRACT.md")
        assert len(list(contract_lint.records(contract_lint.read(contract)))) == 1
        assert "| variable_id |" in contract_lint.read(contract), "fixture is not in table format"

        # The real revision flow: judgment fields only, evidence re-supplied from the extraction by
        # --item. `--item` is required now that the fixture carries one, which is the point.
        revised = {k: v for k, v in dict(rec, notes="REVISED").items()
                   if k not in contract_scaffold.MACHINE_OWNED}
        draft = os.path.join(tmp, "rev.yaml")
        with open(draft, "w", encoding="utf-8") as fh:
            _y.safe_dump(revised, fh, sort_keys=False, width=10 ** 6)

        # STATUS IS NOT IN THE DRAFT. The tool settles it: this is a REVISION of an existing record,
        # so it keeps the status that record already holds — including `requirement: approved`, which
        # a drafter could never have written and does not have to.
        revised.pop("status", None)
        with open(draft, "w", encoding="utf-8") as fh:
            _y.safe_dump(revised, fh, sort_keys=False, width=10 ** 6)
        args = [draft, "--product", product, "--item", "clinical:3"]
        rc = contract_record.main(args)
        assert rc == 0, "a valid revision of an existing record was refused (appended, not replaced)"

        # a genuinely NEW id must still be appended, not dropped
        draft2 = os.path.join(tmp, "new.yaml")
        with open(draft2, "w", encoding="utf-8") as fh:
            _y.safe_dump(dict(revised, variable_id="BRAND_NEW"), fh, sort_keys=False, width=10 ** 6)
        assert contract_record.main([draft2, "--product", product, "--item", "clinical:3"]) == 0


def test_a_PARTIAL_record_is_refused_by_default():
    """A governed draft short of the schema must not be a successful default. `row_for` compared only
    the keys the caller SUPPLIED, so a half-written record rendered to empty cells and reported
    nothing — the real completeness invariant ran only under `--product`, which the skill documented
    as optional."""
    import contract_record
    _row, problems = contract_record.row_for({"variable_id": "X"})
    assert any("incomplete" in p for p in problems), problems
    assert "spec_refs" in problems[0] and "derivation" in problems[0], problems[0]
    # `n/a` and `[]` ARE answers — the check is about absence, not emptiness of meaning
    full = {k: "n/a" for k in contract_lint.TABLE_COLUMNS}
    assert contract_record.row_for(full)[1] == []


def test_an_unknown_field_is_an_ERROR_not_silently_dropped():
    """A field the table has no column for is a typo or a schema change. Dropping it loses the answer
    it carried, and the record still renders to a perfectly well-formed row."""
    try:
        contract_lint.render_row({"variable_id": "X", "windwo": "typo"})
    except ValueError as e:
        assert "windwo" in str(e), str(e)
    else:
        raise AssertionError("an unknown contract field was silently discarded")


def test_a_clean_minimal_product_passes():
    with tempfile.TemporaryDirectory() as tmp:
        errors, n = lint(tmp, [one()])
        assert errors == [], errors
        assert n == 1


def test_i1_duplicate_variable_id():
    with tempfile.TemporaryDirectory() as tmp:
        errors, _ = lint(tmp, [one(), one()])
        assert any("I1 duplicate variable_id" in e for e in errors), errors


def test_i3_rejects_an_invented_status_value():
    with tempfile.TemporaryDirectory() as tmp:
        errors, _ = lint(tmp, [one(req="probably_fine")])
        assert any("I3 status.requirement" in e for e in errors), errors


def test_i6_bites_when_a_record_drops_one_field():
    """A record dropping even one canonical field is the exact defect — a partial copy of the contract —
    that I6 exists to catch. Prove it, don't just assert coverage."""
    with tempfile.TemporaryDirectory() as tmp:
        partial = "\n".join(l for l in one().splitlines() if not l.startswith("units:"))
        errors, _ = lint(tmp, [partial])
        assert any("I6 missing/empty canonical field `units`" in e for e in errors), errors


def test_a_resolved_decision_may_stay_on_an_approved_record():
    """Why I7 was retired. It read `decision_ids` without consulting the register's Status, so ANY
    requirement-level id on an approved record failed — including the RESOLVED one that records what
    settled the rule. The only way to pass was to delete the trace, which is the opposite of what a
    decision register is for. I11 asks the same question status-aware, and these three cases are the
    whole of it: OPEN blocks, RESOLVED does not, output-level never did."""
    with tempfile.TemporaryDirectory() as tmp:
        errors, _ = lint(tmp, [one(decs="BIOM-WINDOW")])          # OPEN, requirement-level
        assert any("I11 cites OPEN" in e for e in errors), errors
        assert lint(tmp, [one(decs="FUED-RULE")])[0] == []        # RESOLVED — the audit trail stays
        assert lint(tmp, [one(decs="NAME-ALIGN")])[0] == []       # OPEN but output-level


def test_a_short_decision_id_reads_the_same_to_every_reader():
    """Three readers of "what is a decision id" disagreed below five characters.

    `decision_ids` (which I2 checks citations against) carried `len(c) >= 5`; `decision_rows` and
    `decision_register_errors` had dropped theirs. So on `D-1` the lint CONTRADICTED ITSELF on one
    row: I2 called the decision undefined while I11 — reading the same table through decision_rows —
    saw it OPEN and demanded the record be decision_required. Latent only because today's packs spell
    ids long; the first tumour numbering decisions `D-1, D-2` hits it immediately.
    """
    with tempfile.TemporaryDirectory() as tmp:
        product = build_product(tmp, [one(req="decision_required", decs="D-1")])
        Path(product, "handoff", "DECISIONS.md").write_text(
            "| ID | Question | Owner | Status |\n|---|---|---|---|\n"
            "| D-1 | short id | RWP | OPEN |\n")
        errors, _ = contract_lint.run(product)
        assert not [e for e in errors if "I2 decision_id" in e], \
            f"I2 called a decision the register plainly defines undefined: {errors}"
        assert not [e for e in errors if "I11" in e], \
            f"I11 disagreed with I2 about the same row: {errors}"

        # all three readers see it
        text = contract_lint.read(str(Path(product, "handoff", "DECISIONS.md")))
        assert "D-1" in contract_lint.decision_ids(text)
        assert "D-1" in contract_lint.decision_rows(text)
        assert contract_lint.decision_status(text)["D-1"] == "OPEN"


def test_i2_unknown_decision_and_gap_ids():
    with tempfile.TemporaryDirectory() as tmp:
        errors, _ = lint(tmp, [one(decs="NO-SUCH-DECISION", gaps="G-NOPE")])
        assert any("I2 decision_id 'NO-SUCH-DECISION'" in e for e in errors), errors
        assert any("I2 gap_id 'G-NOPE'" in e for e in errors), errors


def test_i8_dangling_spec_ref_and_unknown_domain():
    with tempfile.TemporaryDirectory() as tmp:
        errors, _ = lint(tmp, [one(ref="clinical:99")])
        assert any("I8 spec_ref 'clinical:99'" in e for e in errors), errors
        errors, _ = lint(tmp, [one(ref="biomarkers:3")])
        assert any("names domain 'biomarkers'" in e for e in errors), errors


def test_i9_approved_but_not_derivable_must_name_a_gap_exactly_once():
    """The rule still bites; it just stopped saying so twice.

    I9's trigger was a strict subset of I13's — `not_derivable` is one of the shortfall states — so
    one missing gap_id produced two failures and a reader had to work out they were the same record.
    I13 owns the emission and carries I9's reasoning for the approved case.
    """
    with tempfile.TemporaryDirectory() as tmp:
        errors, _ = lint(tmp, [one(impl="not_derivable")])
        assert len(errors) == 1, f"one defect, one message: {errors}"
        assert "I13" in errors[0] and "I9" in errors[0], errors
        assert lint(tmp, [one(impl="not_derivable", gaps="G-PDL1")])[0] == []

        # a shortfall that is NOT the approved case still gets the plain I13 message
        errors, _ = lint(tmp, [one(req="draft", impl="engine_gap")])
        assert len(errors) == 1 and "I9" not in errors[0], errors


def test_missing_extraction_is_reported_not_silently_skipped():
    """Without the extraction there is nothing to resolve spec_refs against. Passing anyway would make
    I8 quietly vacuous, which is worse than failing."""
    with tempfile.TemporaryDirectory() as tmp:
        product = build_product(tmp, [one()])
        os.remove(os.path.join(product, "spec_pipeline", "out", "extracted.json"))
        errors, _ = contract_lint.run(product)
        assert any("no spec_pipeline/out/extracted.json" in e for e in errors), errors


def test_i17_catches_an_invented_answer_over_an_unsettled_spec_row():
    """The only invariant that can catch a FABRICATED value — every other check passes on one.

    A record reading `derivation: "age >= 18"` over a row whose own text says "no age
    operator/threshold is present in the source documents" is complete, correctly typed, properly
    cited, and its digest matches. I1-I16 have nothing to say about it. It is simply not what the
    specification says, and it will be built.

    That gap is widest exactly where review is thinnest: a cheaper or weaker model drafting hundreds
    of records unattended. `spec_lint` already knows which rows are unsettled, deterministically and
    with no model involved — I17 turns judgment the drafter may not have into a property the lint
    checks.
    """
    with tempfile.TemporaryDirectory() as tmp:
        flags = (("clinical:3", "VERIFY_MARKER"),)

        # The defect: confident, complete, no TODO, no decision, over a flagged row.
        errors, _ = lint(tmp, [one(req="draft", impl="not_implemented")], flags=flags)
        assert any("I17" in e and "VERIFY_MARKER" in e for e in errors), errors

        # Unflagged row of the same shape: silent. I17 must bite on the flag, not on every draft.
        assert not any("I17" in e for e in lint(tmp, [one(req="draft", impl="not_implemented")])[0])

        # Three escapes, each a legitimate state a record can be in over a flagged row.
        todo = one(req="draft", impl="not_implemented").replace(
            'derivation: "try_cast(pdl1percent as double), closest to index"', "derivation: TODO")
        assert not any("I17" in e for e in lint(tmp, [todo], flags=flags)[0]), "still being written"
        assert not any("I17" in e for e in lint(
            tmp, [one(req="decision_required", impl="not_implemented", decs="BIOM-WINDOW")],
            flags=flags)[0]), "honestly blocked on an OPEN decision"
        assert not any("I17" in e for e in lint(
            tmp, [one(decs="FUED-RULE")], flags=flags)[0]), "asked, answered, decision RESOLVED"


def test_i17_todo_detection_does_not_use_the_naming_helper():
    """`todo_fields()` returns the placeholder ["a field"] when a record has NO TODO — it exists to
    NAME fields for I10's message, not to answer whether any exist. Used as a predicate it is always
    truthy, which silently disabled I17 entirely: the fabricated record passed clean.

    Caught only by building the record the invariant exists to catch and watching it pass, which is
    why this asserts the helper's actual contract rather than trusting its name.
    """
    clean = one()
    assert "TODO" not in clean
    assert contract_lint.todo_fields(clean) == ["a field"], \
        "todo_fields no longer returns its placeholder — re-check every caller using it as a boolean"
    assert not contract_lint.TODO_RE.search(clean), "TODO_RE is the predicate I17 must use"


def test_i17_is_field_specific_a_todo_off_the_requirement_axis_does_not_excuse_invention():
    """A TODO ANYWHERE used to satisfy I17. So a record could answer the REQUIREMENT confidently over a
    flagged row and park its only TODO on the naming axis — `output: {physical_name: TODO}`, the spec
    being silent on the PHYSICAL NAME, which is routine and says nothing about whether the RULE is
    settled. The invented `derivation` then sailed through the one check meant to catch it.

    Field-specific now: the excusing TODO must sit on a REQUIREMENT field. This asserts the record
    still CARRIES a TODO — so the old `not TODO_RE.search(block)` predicate was satisfied and skipped
    the check — and that it is caught anyway. Reverting to `not TODO_RE.search(block)` makes this pass,
    which is the bite.
    """
    with tempfile.TemporaryDirectory() as tmp:
        flags = (("clinical:3", "VERIFY_MARKER"),)

        # Confident requirement; the only TODO is on the physical NAME — a real TODO, off the axis.
        naming = one(req="draft", impl="not_implemented").replace(
            "physical_name: pdl1_tps", "physical_name: TODO")
        assert contract_lint.TODO_RE.search(naming), "the fixture must carry a TODO or the bite is empty"
        assert "derivation: TODO" not in naming and "record_selection: TODO" not in naming
        errors, _ = lint(tmp, [naming], flags=flags)
        assert any("I17" in e and "VERIFY_MARKER" in e for e in errors), errors

        # The SAME TODO moved onto a requirement field is the legitimate "still being written" state and
        # passes: the axis is what matters, not that a TODO exists somewhere.
        drafting = one(req="draft", impl="not_implemented").replace(
            'derivation: "try_cast(pdl1percent as double), closest to index"', "derivation: TODO")
        assert not any("I17" in e for e in lint(tmp, [drafting], flags=flags)[0])

        # A TODO on `notes` — a real CANON field, but prose, not the requirement — is the same story.
        prose = one(req="draft", impl="not_implemented").replace(
            "notes: synthetic fixture", "notes: TODO revisit with RWB")
        assert any("I17" in e for e in lint(tmp, [prose], flags=flags)[0]), \
            "a TODO on a non-requirement field must not excuse the invented requirement"


def test_i17_acceptance_todo_does_not_excuse_an_invented_requirement():
    """`acceptance` is the worked example, not the rule's answer, and it is TODO on every fresh
    scaffold. So a record could answer `required_rule`, `window` and `derivation` confidently over an
    UNSETTLED row and leave only `acceptance: TODO`, and the first field-specific I17 still passed it —
    the same off-axis hole one level in. This asserts that record is now caught, and that a TODO moved
    onto a genuine requirement field still passes. Reverting `acceptance` into REQUIREMENT_FIELDS makes
    the first assertion fail, which is the bite.
    """
    with tempfile.TemporaryDirectory() as tmp:
        flags = (("clinical:3", "VERIFY_MARKER"),)
        example = one(req="draft", impl="not_implemented")
        acc = example.replace('acceptance: "pdl1percent=55 at index-3d -> PDL1_TPS=55"', "acceptance: TODO")
        assert "acceptance: TODO" in acc and "derivation: TODO" not in acc
        assert any("I17" in e and "VERIFY_MARKER" in e for e in lint(tmp, [acc], flags=flags)[0]), \
            "a TODO only on the worked example must not excuse the confident requirement"
        # the same record with the TODO on a real requirement field (missing) is the legitimate state
        drafting = example.replace("missing: {no_record: null, present_null: null}", "missing: TODO")
        assert not any("I17" in e for e in lint(tmp, [drafting], flags=flags)[0])


def test_requirement_fields_partition_canon_so_a_new_field_must_be_classified():
    """`REQUIREMENT_FIELDS` decides which TODO excuses an UNSETTLED row under I17. A field added to
    CANON and left unclassified would silently default to the lenient side — a TODO on it would stop
    counting, or an invented answer there would go uncaught — so the classification is spelled out
    here and adding a CANON field must break this test until a human places the new field on purpose."""
    requirement = {"required_rule", "grain", "anchor", "window", "record_selection", "tie_break",
                   "derivation", "cohort_applicability", "missing", "units"}
    # `acceptance` sits on the non-requirement side on purpose: it is the worked example, not the
    # rule's answer, and it is TODO on every fresh scaffold — so it must not excuse a confident answer
    # over an UNSETTLED row (see the constant's comment in contract_lint).
    non_requirement = {"spec_refs", "spec_digest", "source", "depends_on", "output", "status",
                       "decision_ids", "gap_ids", "publish", "notes", "acceptance"}
    assert contract_lint.REQUIREMENT_FIELDS == requirement
    assert contract_lint.NON_REQUIREMENT_FIELDS == non_requirement
    assert not (requirement & non_requirement), "a field cannot be both"
    assert requirement | non_requirement == set(contract_lint.CANON), \
        "a CANON field is unclassified — place it in REQUIREMENT_FIELDS or not, on purpose"


def test_i17_fails_closed_when_the_pipeline_output_is_half_written():
    """lint.json ships from the same run as extracted.json. One without the other is a broken out/,
    and skipping the invention guard there would turn it off exactly when the evidence directory is
    already known to be untrustworthy."""
    with tempfile.TemporaryDirectory() as tmp:
        product = build_product(tmp, [one()])
        os.remove(os.path.join(product, "spec_pipeline", "out", "lint.json"))
        errors, _ = contract_lint.run(product)
        assert any("I17 no spec_pipeline/out/lint.json" in e for e in errors), errors


def test_floors_catch_a_parser_regression():
    with tempfile.TemporaryDirectory() as tmp:
        errors, _ = contract_lint.run(build_product(tmp, [one()]), {"records": 40})
        assert any("floor 40" in e for e in errors), errors


def test_a_pack_is_judged_by_the_floors_it_declares_not_the_cli_default():
    """One pack, one standard — whether the CLI or the pack's own test asks.

    The floors are declared in `handoff/tests/test_functional_contract.py`, which the wrapper passed
    to run() and the CLI did not, so a pack's floor was two facts that disagreed. It failed BOTH ways
    at once:

      * `contract_lint.py products/oncology/oc/202606` reported `parsed only 0 gap IDs (floor 1)` on a
        pack declaring `gaps: 0`, whose ENGINE_GAPS.md says in its first line that it is empty because
        no contract is approved and no build binds to one. A floor a pack CANNOT meet is the thing the
        floors' own comment warns produces a floor people learn to ignore.
      * the same CLI on prostate 202606 applied `records: 1` where the pack declares `40`, so a parser
        regression dropping 39 records passed silently. That half is the dangerous one.
    """
    with tempfile.TemporaryDirectory() as tmp:
        product = build_product(tmp, [one()])
        tests = os.path.join(product, "handoff", "tests")
        os.makedirs(tests, exist_ok=True)
        wrapper = os.path.join(tests, "test_functional_contract.py")

        # No declaration: DEFAULT_FLOORS, which is the only honest answer for a pack that states none.
        assert contract_lint.pack_floors(product) is None
        assert not any("floor 40" in e for e in contract_lint.run(product)[0])

        # Declared: the CLI path must pick it up WITHOUT being handed it.
        with open(wrapper, "w", encoding="utf-8") as fh:
            fh.write('FLOORS = {"decisions": 0, "gaps": 0, "records": 40}\n')
        assert contract_lint.pack_floors(product) == {"decisions": 0, "gaps": 0, "records": 40}
        assert any("floor 40" in e for e in contract_lint.run(product)[0]), \
            "run() ignored the pack's declared floors — the CLI and the pack's own test judge it by " \
            "two different standards"

        # A declared ZERO must survive the merge with DEFAULT_FLOORS. `dict(DEFAULT, **declared)` is
        # right; anything treating 0 as absent restores the floor the pack explicitly lowered, which
        # is exactly the oc/202606 gap-ID failure. Asserted against an EMPTY gap index — the fixture
        # ships one gap, so against that this passed whether or not the zero was honoured.
        empty_gaps = build_product(tmp, [one()])
        with open(os.path.join(empty_gaps, "handoff", "ENGINE_GAPS.md"), "w", encoding="utf-8") as fh:
            fh.write("# Engine gaps\n\nEmpty: no contract approved, no build binds to one.\n\n"
                     "| Gap | What is not met |\n|---|---|\n")
        assert any("gap ID" in e for e in contract_lint.run(empty_gaps)[0]), \
            "an empty gap index with NO declaration must still trip the default floor of 1"
        egtests = os.path.join(empty_gaps, "handoff", "tests")
        os.makedirs(egtests, exist_ok=True)
        with open(os.path.join(egtests, "test_functional_contract.py"), "w", encoding="utf-8") as fh:
            fh.write('FLOORS = {"decisions": 0, "gaps": 0, "records": 1}\n')
        assert not any("gap ID" in e for e in contract_lint.run(empty_gaps)[0]), \
            "a declared floor of 0 was overridden by the default of 1 — this is the oc/202606 failure"

        # Explicit floors still win, so the wrapper passing its own FLOORS is unchanged.
        assert not any("floor 40" in e for e in contract_lint.run(product, {"records": 1})[0])

        # Unparseable declaration falls back rather than crashing the lint on every pack.
        with open(wrapper, "w", encoding="utf-8") as fh:
            fh.write("FLOORS = {**BASE, 'records': 40}\n")
        assert contract_lint.pack_floors(product) is None


def test_every_pack_the_cli_and_its_wrapper_agree():
    """Real-data half: on every pack that ships a wrapper, both entry points must reach the same
    verdict. The unit test proves the mechanism; this proves it was actually applied."""
    import glob
    import subprocess

    packs = sorted(os.path.dirname(os.path.dirname(os.path.dirname(p)))
                   for p in glob.glob(os.path.join(str(REPO), "products", "*", "*", "*", "handoff",
                                                   "tests", "test_functional_contract.py")))
    assert packs, "no packs with a contract wrapper discovered — this would pass by sweeping nothing"
    for product in packs:
        declared = contract_lint.pack_floors(product)
        assert declared, f"{product}: ships a wrapper whose FLOORS this cannot read"
        cli = subprocess.run([sys.executable, os.path.join(str(REPO), "platform", "tools", "contract_lint.py"),
                              product], capture_output=True, text=True)
        wrapper = subprocess.run([sys.executable, os.path.join(product, "handoff", "tests",
                                                               "test_functional_contract.py")],
                                 capture_output=True, text=True)
        assert cli.returncode == wrapper.returncode, (
            f"{os.path.relpath(product, str(REPO))}: CLI exits {cli.returncode}, its own test exits "
            f"{wrapper.returncode} — two standards for one pack.\nCLI said:\n{cli.stdout}")


def test_i10_approved_record_may_not_hold_todo():
    """The scaffold marks every judgment field TODO. Flipping only the status would approve a
    requirement nobody has written."""
    with tempfile.TemporaryDirectory() as tmp:
        rec = one().replace('derivation: "try_cast(pdl1percent as double), closest to index"',
                            "derivation: TODO")
        errors, _ = lint(tmp, [rec])
        assert any("I10 requirement:approved but derivation still TODO" in e for e in errors), errors
        # a DRAFT record is allowed to carry TODO — that is what a scaffold is
        assert not any("I10" in e for e in lint(tmp, [rec.replace("requirement: approved",
                                                                  "requirement: draft")])[0])


def test_i8_rejects_prose_and_validates_a_whole_range():
    with tempfile.TemporaryDirectory() as tmp:
        errors, _ = lint(tmp, [one(ref="treatment (engine addition)")])
        assert any("is not a `<domain>:<row>` citation" in e for e in errors), errors
        # a range whose ENDS exist but whose middle does not must fail, not pass on the endpoints
        errors, _ = lint(tmp, [one(ref="clinical:3-6")],
                         spec_rows=(("clinical", 3), ("clinical", 6)))
        assert any("row(s) 4, 5" in e for e in errors), errors


def test_a_variable_with_no_spec_row_must_name_its_governance():
    """An engine/config addition is allowed, but never silently: something must record why it exists."""
    with tempfile.TemporaryDirectory() as tmp:
        errors, _ = lint(tmp, [one(ref="none", decs="NAME-ALIGN")])
        assert any("must name the decision or gap" in e for e in errors), errors
        # NAME-ALIGN governs the OUTPUT; a requirement-level decision or a gap is what counts
        # `decision_required`, not `draft`: I11 holds that a record citing an OPEN requirement-level
        # decision IS blocked, and the fixture said draft.
        assert lint(tmp, [one(ref="none", req="decision_required", decs="BIOM-WINDOW")])[0] == []
        assert lint(tmp, [one(ref="none", gaps="G-PDL1")])[0] == []


def test_both_the_coarse_and_the_gate3_status_shapes_are_accepted():
    """WORKFLOW.md lets a product keep the coarse `source` axis until Gate 3. If the lint only accepts
    the coarse form, a record written exactly as the workflow instructs fails."""
    gate3 = one().replace(
        "status: {requirement: approved, source: unverified, implementation: implemented, validation: not_run}",
        "status: {requirement: approved, source_mapping: human_confirmed, dictionary_check: passed, "
        "live_schema_check: passed, data_profile_check: accepted, implementation: implemented, "
        "validation: passed_test}")
    with tempfile.TemporaryDirectory() as tmp:
        assert lint(tmp, [one()])[0] == []                      # coarse
        assert lint(tmp, [gate3])[0] == []                      # fine
        half = gate3.replace("live_schema_check: passed, ", "")  # neither shape, completely
        assert any("either the coarse `source` axis or all four" in e for e in lint(tmp, [half])[0])



def test_i11_closes_the_decision_loop():
    """The half that matters: a decision moves to RESOLVED and the records blocked on it must be
    named, or the answer is never written into them and nobody finds out."""
    with tempfile.TemporaryDirectory() as tmp:
        product = build_product(tmp, [one(req="decision_required", decs="BIOM-WINDOW")])
        dec = Path(product) / "handoff" / "DECISIONS.md"
        assert contract_lint.run(product)[0] == []                    # blocked on an OPEN decision: fine
        dec.write_text(dec.read_text().replace("| BIOM-WINDOW | window | RWB | OPEN |",
                                               "| BIOM-WINDOW | window | RWB | RESOLVED |"))
        errors, _ = contract_lint.run(product)
        assert any("BIOM-WINDOW" in e and "RESOLVED" in e for e in errors), errors


def test_i11_a_record_blocked_on_nothing_is_caught():
    """`decision_required` with no decision cited records no reason to be blocked. This found a real
    drafting error in prostate 202607 the first time it ran."""
    with tempfile.TemporaryDirectory() as tmp:
        errors, _ = lint(tmp, [one(req="decision_required")])
        assert any("nothing records what it is blocked on" in e for e in errors), errors


def test_i11_ignores_output_only_decisions():
    """NAME-ALIGN and CODE-ALIGN govern the OUTPUT, not the requirement — they never block a record."""
    with tempfile.TemporaryDirectory() as tmp:
        assert lint(tmp, [one(req="approved", decs="NAME-ALIGN")])[0] == []
        errors, _ = lint(tmp, [one(req="decision_required", decs="NAME-ALIGN")])
        assert any("I11" in e for e in errors), "NAME-ALIGN alone does not justify decision_required"



def test_i12_validation_cannot_outrun_implementation_or_requirement():
    """Every axis can be individually legal while the combination is impossible. `requirement: draft`
    with `validation: passed_live` claims live evidence for a rule nobody approved."""
    with tempfile.TemporaryDirectory() as tmp:
        rec = one(impl="not_implemented").replace("validation: not_run", "validation: passed_live")
        errors, _ = lint(tmp, [rec])
        assert any("nothing was built to validate" in e for e in errors), errors
        rec = one(req="draft").replace("validation: not_run", "validation: passed_test")
        errors, _ = lint(tmp, [rec])
        assert any("requirement:draft" in e and "I12" in e for e in errors), errors
        # passed_live implies the source was confirmed; `unverified` contradicts it
        rec = one().replace("validation: not_run", "validation: passed_live")
        errors, _ = lint(tmp, [rec])
        assert any("source:unverified" in e for e in errors), errors


def test_i12_allows_a_consistent_ladder():
    with tempfile.TemporaryDirectory() as tmp:
        rec = one().replace("source: unverified", "source: verified").replace(
            "validation: not_run", "validation: passed_live")
        assert lint(tmp, [rec])[0] == []


def test_i13_a_shortfall_must_name_its_gap():
    """config_gap / engine_gap / partial / not_derivable all mean the build falls short. Without a
    gap_id the shortfall is real and tracked nowhere — it caught two live records."""
    with tempfile.TemporaryDirectory() as tmp:
        for impl in ("config_gap", "engine_gap", "partial", "not_derivable"):
            errors, _ = lint(tmp, [one(req="draft", impl=impl)])
            assert any("I13" in e and impl in e for e in errors), (impl, errors)
        assert not any("I13" in e for e in lint(tmp, [one(req="draft", impl="partial",
                                                          gaps="G-PDL1")])[0])
        assert not any("I13" in e for e in lint(tmp, [one(impl="implemented")])[0])




def test_i14_a_decision_blocked_record_may_not_claim_to_be_built_at_contract_approved():
    """The compensating control for what Gate 2 permits. WORKFLOW.md line 173 closes Gate 2 on
    "approved OR explicitly blocked by a named decision"; line 262 is what makes the block safe —
    "blocked or decision-gated records are not implemented". Both halves are needed: without this,
    a pack exits Gate 2 with a record saying its rule is unanswered AND that it is built.

    It is scoped to the approval claim on purpose. Before then a build standing ahead of an open
    decision is ordinary development, which is why the same fixture passes with no MATURITY.yaml.
    """
    blocked = one(req="decision_required", impl="implemented", decs="BIOM-WINDOW")
    with tempfile.TemporaryDirectory() as tmp:
        assert lint(tmp, [blocked])[0] == [], "while the contract is being written this is legal"

        product = build_product(tmp, [blocked])
        (Path(product) / "handoff" / "MATURITY.yaml").write_text(
            "contract: approved\nconfiguration: not_started\n")
        errors, _ = contract_lint.run(product)
        assert [e for e in errors if "I14" in e and "implementation:implemented" in e], errors

        # `partial` too — it still claims part of the build exists for a rule nobody has settled.
        for impl, ok in (("partial", False), ("not_implemented", True), ("engine_gap", True)):
            rec = one(req="decision_required", impl=impl, decs="BIOM-WINDOW",
                      gaps="G-PDL1" if impl in contract_lint.IMPL_SHORTFALL else "")
            p = build_product(tmp, [rec])
            (Path(p) / "handoff" / "MATURITY.yaml").write_text(
                "contract: approved\nconfiguration: not_started\n")
            hits = [e for e in contract_lint.run(p)[0] if "I14" in e and "implementation:" in e]
            assert bool(hits) != ok, f"{impl}: {contract_lint.run(p)[0]}"


def test_i16_a_record_may_not_span_several_spec_rows_at_contract_approved():
    """A family record is a LIST, and a list is where the next tumour's new member goes missing —
    inside the record's prose and inside a config list item, with every check still green. Signing is
    where that becomes a liability, because the signed contract is what the next refresh is diffed
    against, so that is where this bites (WORKFLOW.md section 8).

    Scoped to `coverage_complete` and above on purpose: the same grouped record passes at
    `contract: draft`, because grouping while the contract is being written is ordinary work. It was
    first written to bite only at `approved`, where it bit nothing — no pack claims that level.
    """
    rows = (("clinical", 3), ("clinical", 4), ("clinical", 5), ("demographics", 9))
    span = one(vid="LAB", ref="clinical:3-5")
    with tempfile.TemporaryDirectory() as tmp:
        assert [e for e in lint(tmp, [span], spec_rows=rows)[0] if "I16" in e] == [], \
            "with no MATURITY.yaml the pack is still drafting — a family record is legal"

        drafting = build_product(tmp, [span], spec_rows=rows)
        (Path(drafting) / "handoff" / "MATURITY.yaml").write_text(
            "contract: draft\nconfiguration: not_started\n")
        assert [e for e in contract_lint.run(drafting)[0] if "I16" in e] == [], \
            "contract: draft is still being written — grouping is ordinary work there"

        for ref, spans in (("clinical:3-5", True),           # a range
                           ("clinical:3, demographics:9", True),   # two separate citations
                           ("clinical:3", False),            # exactly one row — the rule
                           ("none", False)):                 # cites nothing; I8 owns that case
            rec = one(vid="LAB", ref=ref, decs="BIOM-WINDOW" if ref == "none" else "")
            product = build_product(tmp, [rec], spec_rows=rows)
            # coverage_complete is the CLAIM that every spec item resolves; that cannot be true
            # row by row while one record answers thirty rows. Approved inherits it.
            (Path(product) / "handoff" / "MATURITY.yaml").write_text(
                "contract: coverage_complete\nconfiguration: not_started\n")
            errors = contract_lint.run(product)[0]
            hits = [e for e in errors if "I16" in e]
            assert bool(hits) == spans, f"{ref}: {errors}"
            if spans:
                assert "one record over" in hits[0] and ref.split(",")[0] in hits[0], hits


def test_a_record_pasted_as_yaml_under_a_table_is_reported_not_swallowed():
    """The one way this file can lose a requirement with nothing going red.

    `records()` lets the table win, so a fenced block under a table is in the FILE and not in the
    contract — and the scaffolder still emits fenced blocks, so pasting one is the obvious thing to
    do. Silence there would be a variable that simply is not required by anything.
    """
    table = "| variable_id | source |\n|---|---|\n| A | n/a |\n"
    fenced = "\n```yaml\nvariable_id: PASTED_BY_HAND\nsource: n/a\n```\n"
    assert [b.splitlines()[0] for b in contract_lint.records(table + fenced)] == ["variable_id: A"], \
        "the table no longer wins — this test's premise is gone, re-read records()"
    errs = contract_lint.mixed_format_error(table + fenced, "FUNCTIONAL_CONTRACT.md")
    assert errs and "PASTED_BY_HAND" in errs[0], errs
    # Neither format ALONE is a problem: a pack still on fenced records must stay clean.
    assert contract_lint.mixed_format_error(table, "x") == []
    assert contract_lint.mixed_format_error(fenced, "x") == []


def test_i15_fires_when_the_cited_text_changes_under_a_record():
    """The digest must be checked through the real lint, not only as a function: a record whose cited
    row is edited in place has to fail even though its citation still resolves."""
    with tempfile.TemporaryDirectory() as tmp:
        product = build_product(tmp, [one()])
        extracted = Path(product) / "spec_pipeline" / "out" / "extracted.json"
        data = json.loads(extracted.read_text())
        for row in data["rows"]:
            row["content_hash"] = "CHANGED"          # RWB edits the rule; the row number does not move
        extracted.write_text(json.dumps(data))
        errors, _ = contract_lint.run(product)
        assert [e for e in errors if "I15" in e], errors
        assert not [e for e in errors if "I8" in e], "the citation still resolves — only I15 should fire"



def test_the_spec_evidence_comes_from_the_extraction_and_is_REFUSED_from_the_drafter():
    """`spec_refs`, `spec_digest` and `required_rule` are established by the spec pipeline, and the
    skill has said "pass them through, never author them" since its first version. The tool then
    accepted the whole record from the model, so that rule was a sentence in a prompt.

    Two different failures follow, and the second is the reason this is mechanical now: retyping a
    digit of the digest fails I15 loudly, with a message about hashing — but tidying `required_rule`
    into better English replaces the spec's exact words with a paraphrase and NOTHING FAILS. The
    record reads well and no longer says what RWB wrote.
    """
    import contract_record
    import contract_scaffold
    live = REPO / "products" / "oncology" / "prostate" / "202606"
    if not (live / "spec_pipeline" / "out" / "extracted.json").exists():
        return                                     # live-pack assertion; covered by the unit test below
    # A SIGNED COPY. The shipped pack's extraction is `status: pending` and nobody has approved it,
    # so `ai_gate` correctly refuses it — see the refusal test below, which is where that property
    # is asserted. This test's claim has always been "given a row this tool may read, the evidence
    # comes from the extraction and not from the drafter", so the fixture supplies the permission
    # and the assertion stays about the merge.
    pack = Path(_approved(str(live)))

    judgment = {"variable_id": "AGE", "source": "{kind: derived}"}
    merged, problems = contract_record.merge_evidence(dict(judgment), str(pack), "demographics:9")
    assert not problems, problems
    for field in contract_scaffold.MACHINE_OWNED:
        assert merged.get(field), f"{field} was not supplied from the extraction"
    assert merged["spec_refs"] == ["demographics:9"]
    # the digest is the LINT's, not a second implementation — the same value the scaffold records
    assert merged["spec_digest"] == contract_lint.spec_digest(
        ["demographics:9"], contract_lint.spec_rows(str(pack))), merged["spec_digest"]
    # ...and the judgment fields survive the merge
    assert merged["source"] == "{kind: derived}"

    # supplying one is an ERROR, not an override. An override is how the rule goes back to advisory.
    for field in contract_scaffold.MACHINE_OWNED:
        _m, bad = contract_record.merge_evidence(dict(judgment, **{field: "mine"}),
                                                 str(pack), "demographics:9")
        assert bad and field in bad[0], (field, bad)

    # an item id that does not exist names the ones that do, rather than rendering an empty record
    _m, bad = contract_record.merge_evidence(dict(judgment), str(pack), "5A.Demos:9")
    assert bad and "not a requirement row" in bad[0], bad
    assert any(f"{d}:" in bad[0] for d in ("study_period", "study_population", "demographics",
                                           "clinical", "treatment", "outcomes")), \
        f"the error does not show what a real item id looks like: {bad[0]}"


def test_drafting_without_a_pack_must_be_an_explicit_choice():
    """`--product` was OPTIONAL and the skill documented it in brackets. Completeness and the
    round-trip run without it, which is what made that look sufficient — but I8, I15, I17 and the
    decision/gap reference checks all need the pack, so a drafter following the documented command got
    a clean-looking record no gate had seen."""
    import contract_record
    import yaml as _y
    with tempfile.TemporaryDirectory() as tmp:
        rec = {ln.split(": ", 1)[0]: ln.split(": ", 1)[1]
               for ln in one().splitlines() if ": " in ln and not ln.startswith("```")}
        rec.pop("status", None)          # the TOOL settles status; a draft carrying one is refused
        draft = os.path.join(tmp, "d.yaml")
        with open(draft, "w", encoding="utf-8") as fh:
            _y.safe_dump(rec, fh, sort_keys=False, width=10 ** 6)

        try:
            contract_record.main([draft])
            raise AssertionError("a record was rendered with no pack and no explicit opt-out")
        except SystemExit as exc:
            assert exc.code != 0

        # ...and the opt-out is NAMED, so choosing it is visible in the command someone ran
        assert contract_record.main([draft, "--format-only"]) == 0

    # ...and --item is REQUIRED for a pack that HAS an extraction. Making it optional left the whole
    # machine-owned-field boundary opt-in: `--product` alone accepted a hand-written spec_refs,
    # spec_digest and required_rule, and only a wrong DIGEST would have failed. A paraphrased
    # `required_rule` — the failure the interface exists to stop — passed silently.
    with tempfile.TemporaryDirectory() as tmp:
        rec = {ln.split(": ", 1)[0]: ln.split(": ", 1)[1]
               for ln in one().splitlines() if ": " in ln and not ln.startswith("```")}
        product = build_product(tmp, [contract_lint.render_table([rec])])
        draft = os.path.join(tmp, "d.yaml")
        with open(draft, "w", encoding="utf-8") as fh:
            _y.safe_dump(rec, fh, sort_keys=False, width=10 ** 6)
        try:
            contract_record.main([draft, "--product", product, "--actor", "human"])
            raise AssertionError("a pack with an extraction accepted a draft with no --item")
        except SystemExit as exc:
            assert exc.code != 0
        # ...and the legacy opt-out is refused for a pack that HAS one, or it is just --item again
        try:
            contract_record.main([draft, "--product", product, "--legacy-no-extraction",
                                  "--actor", "human"])
            raise AssertionError("--legacy-no-extraction was accepted for a pack with an extraction")
        except SystemExit as exc:
            assert exc.code != 0

    with tempfile.TemporaryDirectory() as tmp:
        rec = {ln.split(": ", 1)[0]: ln.split(": ", 1)[1]
               for ln in one().splitlines() if ": " in ln and not ln.startswith("```")}
        draft = os.path.join(tmp, "d.yaml")
        with open(draft, "w", encoding="utf-8") as fh:
            _y.safe_dump(rec, fh, sort_keys=False, width=10 ** 6)

        # --item without --product is refused: the evidence has nowhere to come from. Passed WITH
        # --format-only so the required-pack guard above cannot be what fires — two guards where one
        # masks the other is a guard nobody has tested.
        try:
            contract_record.main([draft, "--format-only", "--item", "demographics:9"])
            raise AssertionError("--item was accepted with no pack to read the extraction from")
        except SystemExit as exc:
            assert exc.code != 0


def test_the_skill_documents_the_commands_it_actually_has():
    """Three times this skill has described a flag that had changed under it — `--product` optional
    after it stopped being safe, `implementation_refs` optional after it became required, `[none]`
    needing a gap after that stopped being true. Prose is what drifts, so the claims are checked."""
    skill_dir = REPO / ".claude" / "skills" / "draft-contract-record"
    if not skill_dir.exists():
        return
    skill = (skill_dir / "SKILL.md").read_text(encoding="utf-8")

    # the split exists, and the operational file is the smaller one
    for name in ("REFERENCE.md", "EVAL_RATIONALE.md"):
        assert (skill_dir / name).exists(), f"{name} is referenced by SKILL.md and missing"
        assert name in skill, f"SKILL.md does not point at {name}"
    # A BUDGET, not a measurement — the difference matters. A measurement in an instruction goes
    # stale; a budget is a deliberate constraint, and this one exists because the single file reached
    # 637 lines and the operational rules were buried among the evidence for them. Raising it is a
    # decision someone makes on purpose, which is the point.
    operational = len(skill.splitlines())
    supporting = sum(len((skill_dir / n).read_text(encoding="utf-8").splitlines())
                     for n in ("REFERENCE.md", "EVAL_RATIONALE.md"))
    assert operational <= 450, f"SKILL.md is {operational} lines — move reference or evidence out"
    assert operational < supporting, (
        f"SKILL.md ({operational}) carries more than REFERENCE + EVAL_RATIONALE ({supporting}) "
        f"together — the split has not actually moved anything")

    # MUTABLE MEASUREMENTS BELONG IN EVAL_RATIONALE. A count inside an operational instruction goes
    # stale silently, and one already did: the contract sanitization changed the quotation figure in
    # the same week the sentence carrying it was written.
    import re as _re
    for pattern in (r"\b295 records\b", r"\b99 of them\b", r"\b45%", r"forty quotations",
                    r"fourteen aliases"):
        assert not _re.search(pattern, skill), \
            f"SKILL.md carries the frozen measurement {pattern!r} — it belongs in EVAL_RATIONALE.md"

    # the documented command form is the one the tool accepts
    assert "--product <pack> --item <domain:row>" in skill
    assert "--format-only" in skill
    # Read the tool's own source, rather than a copy of its flag list here.
    src = (REPO / "platform" / "tools" / "contract_record.py").read_text(encoding="utf-8")
    for flag in ("--item", "--format-only", "--product"):
        assert f'"{flag}"' in src, f"SKILL.md documents {flag}, which contract_record.py does not define"


def test_the_eval_prompts_require_the_tool_rather_than_a_hand_written_row():
    """The skill says "You write key: value. You do NOT write the row." The eval prompts asked for
    "one markdown table row" — so the benchmark measured the behaviour the skill exists to remove, and
    a model that ignored the tool entirely scored well."""
    import json as _json
    evals = REPO / ".claude" / "skills" / "draft-contract-record" / "evals" / "evals.json"
    if not evals.exists():
        return
    doc = _json.loads(evals.read_text(encoding="utf-8"))
    drafting = [e for e in doc["evals"] if "draft the functional-contract record" in e["prompt"]]
    assert drafting, "no drafting evals found — the check below would be vacuous"
    for e in drafting:
        assert "contract_record.py" in e["prompt"], \
            f"eval {e['id']} ({e['name']}) does not route the record through the renderer"
        assert "--item" in e["prompt"] and "--product" in e["prompt"], e["name"]
        assert "judgment" in e["prompt"].lower(), \
            f"eval {e['id']} does not ask for judgment fields — it asks for a whole record"
        assert "markdown table row" not in e["prompt"], \
            f"eval {e['id']} still asks the model to write the row itself"


def test_the_AI_drafting_path_refuses_a_status_only_a_human_may_set():
    """`requirement: approved`, `source_mapping: human_confirmed`, `passed_live`, `accepted` — every
    mode this skill defines forbids them, and `contract_lint` accepts them on a structurally complete
    record. So on a mature pack a model could assert an approval and nothing objected; the rule was a
    sentence in a prompt. `--actor human` is how an accountable person makes the transition."""
    import contract_record
    for axis, value in (("requirement", "approved"), ("source", "verified"),
                        ("source_mapping", "human_confirmed"), ("validation", "passed_live"),
                        ("data_profile_check", "accepted"), ("live_schema_check", "passed")):
        rec = {"variable_id": "X", "status": f"{{{axis}: {value}, requirement: draft}}"
               if axis != "requirement" else "{requirement: approved}"}
        bad = contract_record.human_only_errors(rec)
        assert bad and axis in bad[0], (axis, value, bad)
    # a real draft is clean
    assert not contract_record.human_only_errors(
        {"status": "{requirement: draft, source: unverified, implementation: not_implemented, "
                   "validation: not_run}"})
    # ...and a mapping, not just the inline string, is read the same way
    assert contract_record.human_only_errors({"status": {"requirement": "approved"}})


def test_status_is_SETTLED_BY_THE_TOOL_and_a_draft_may_not_write_one():
    """`DRAFTABLE` was safer than the blacklist it replaced and still the wrong shape: `failed`,
    `passed_test`, `issue_open` and `dictionary_only` were all inside it, and every one is an EVIDENCE
    CLAIM — a statement that a check ran and came back a certain way. A drafter has read a
    specification row. It has not run a test, opened a dictionary or looked at a profile.

    So a new record does not carry `status` at all and the tool injects one; a revision keeps whatever
    the existing record holds. The model has no reason to reason about status, which is the point.
    """
    import contract_record
    # A NEW record: the tool supplies the initial status, and it is the whole initial status.
    rec, bad = contract_record.apply_status({"variable_id": "X"})
    assert not bad, bad
    for axis, value in contract_record.INITIAL_STATUS.items():
        assert f"{axis}: {value}" in rec["status"], (axis, rec["status"])
    # A REVISION keeps what the record already holds — including a value no drafter could have written.
    rec, bad = contract_record.apply_status(
        {"variable_id": "X"}, {"requirement": "approved", "source": "verified"})
    assert not bad and "requirement: approved" in rec["status"], rec
    # ...and a draft that writes one is REFUSED, in both notations, rather than silently overwritten:
    # the drafter meant something by it, and hiding the disagreement is worse than reporting it.
    for written in ("{requirement: approved, source: verified}", {"requirement": "draft"}):
        _rec, bad = contract_record.apply_status({"variable_id": "X", "status": written})
        assert bad and "not yours to write" in bad[0], written
    # The evidence claims that used to be draftable are simply unreachable now.
    for claim in ("passed_test", "failed", "issue_open", "dictionary_only"):
        assert claim not in str(contract_record.INITIAL_STATUS), claim


def test_every_status_value_is_on_exactly_one_side_of_the_draftable_line():
    """The property an ALLOWLIST has and the blacklist it replaced did not.

    `DRAFTABLE` names what a machine may author; `contract_lint` owns the vocabularies. A value in the
    lint and in neither category is a value nobody decided about — and under the old blacklist that
    meant "assertable by a drafter", silently, on the day the lint grew it. `FINE_SOURCE_AXES` was
    added after the coarse `source` axis and `data_profile_check: reviewed` after that; each of those
    would have widened what a model could claim with nothing going red.

    So the test is not "the allowlist is right" — that is a judgment — but "every value has been
    judged". Adding one to `contract_lint` fails here until somebody puts it on a side.
    """
    import contract_lint
    import contract_record
    vocab = dict(contract_lint.FINE_SOURCE_AXES)
    vocab.update({"requirement": contract_lint.REQ, "source": contract_lint.SRC,
                  "validation": contract_lint.VAL})
    assert set(vocab) == set(contract_record.DRAFTABLE), \
        (f"axes differ: lint has {sorted(set(vocab) - set(contract_record.DRAFTABLE))}, "
         f"DRAFTABLE has {sorted(set(contract_record.DRAFTABLE) - set(vocab))}")
    for axis, allowed in contract_record.DRAFTABLE.items():
        stray = allowed - set(vocab[axis])
        assert not stray, f"DRAFTABLE[{axis!r}] permits {sorted(stray)}, which the lint refuses outright"
        # ...and the other side is non-empty: an axis whose every value is draftable records no human
        # act at all, and putting it here would be a category error worth catching.
        assert set(vocab[axis]) - allowed, \
            f"axis {axis!r} has no human-only value — it does not belong in DRAFTABLE"


def test_the_drafting_tool_asks_the_SAME_question_the_slicer_does_before_lifting_spec_text():
    """TWO DOORS ONTO ONE DECISION, which is the shape `docs/ENGINEERING.md` names as how a governed gate comes
    to pass something it exists to stop.

    `source_manifest.ai_readable` is the one answer to "may AI read this pack". `spec_slice` asked it
    and refused prostate/202606 — `status: pending`, no `approved_by`, no `approval_date`. Meanwhile

        contract_record.py d.yaml --product products/oncology/prostate/202606 --item study_period:18

    returned the specification's own sentence, `Earliest available data through INDEX, inclusive.`,
    with its digest. Same artifact, same question, opposite answers — and the second door is the one
    the drafting skill actually uses.

    Asserted against the SHIPPED packs, and it asserts the pair: the refusal, and that the same call
    succeeds once somebody has signed. A test of the refusal alone would still pass if the gate
    refused everything, including approved work.
    """
    import contract_record
    import contract_scaffold
    # WHICHEVER PACK IS STILL UNSIGNED, discovered rather than named. This test named
    # prostate/202606 and went red the day somebody approved that pack's extraction — correctly, via
    # its own guard, but the property is about the GATE and not about any one pack. It fails only
    # when NO pack is left refusing, which is the one state in which it would prove nothing.
    import product_gates as _pg
    import contract_scaffold as _cs
    # `products()` emits REPO-ROOT-RELATIVE paths and this suite runs from `platform/`, so every
    # path is joined to REPO before it is touched. Testing them as-is made the list empty and the
    # guard below fire with exactly the wrong diagnosis.
    unsigned = [str(REPO / p) for p in sorted(_pg.products(str(REPO)))
                if (REPO / p / "spec_pipeline" / "out" / "extracted.json").exists()
                and not _sm_ai_readable(str(REPO / p))[0]]
    assert unsigned, ("every pack is now approved for AI use — this test no longer proves the "
                      "refusal; point it at a fixture whose extraction nobody has signed")
    live = Path(unsigned[0])
    item = sorted({f"{r['domain']}:{r['row']}" for r in
                   json.loads((live / "spec_pipeline" / "out" / "extracted.json")
                              .read_text(encoding="utf-8"))["rows"] if r.get("domain")})[0]

    for fn, why in ((lambda: _cs.evidence_for(str(live), item), "evidence_for"),
                    (lambda: contract_record.merge_evidence({"variable_id": "X"}, str(live),
                                                            item), "merge_evidence")):
        try:
            fn()
        except contract_scaffold.NotApprovedForAI as exc:
            assert "not approved for AI use" in str(exc), exc
        else:
            raise AssertionError(
                f"{why} supplied the specification's own words for a pack `ai_readable` refuses — "
                f"the slicer's gate and the drafter's are not the same gate")

    # ...and through the CLI, which is what a drafter actually runs. Asserted separately because
    # `main` catches the refusal, and a `main` that caught and CONTINUED would leave every library
    # assertion above passing while the command still printed the row.
    with tempfile.TemporaryDirectory() as tmp:
        draft = os.path.join(tmp, "d.yaml")
        with open(draft, "w", encoding="utf-8") as fh:
            fh.write("variable_id: PROBE\n")
        try:
            rc = contract_record.main([draft, "--product", str(live), "--item", item,
                                       "--allow-partial"])
        except SystemExit as exc:
            assert "not approved for AI use" in str(exc), exc
        else:
            raise AssertionError(f"the CLI rendered a row from an unapproved extraction (rc={rc})")

    # ...and it is a GATE, not a wall: the identical call on a signed copy returns the evidence.
    ok = contract_scaffold.evidence_for(_approved(str(live)), item)
    assert ok["required_rule"].strip(), ok

    # One function answers this, for both tools. Two would agree today.
    assert contract_scaffold.ai_gate.__module__ == "contract_scaffold"
    import spec_slice
    assert spec_slice.sm.ai_readable is _sm_ai_readable


def test_a_VENDOR_REDACTED_row_cannot_be_drafted_by_the_tool():
    """The slice SAYS a redacted row must be left to a human. Saying so is a prompt instruction: a
    model can still produce a complete-looking judgment over the row and pass every invariant, because
    `VENDOR_REDACTED` is deliberately not in I17's unsettled set — it means the spec DOES settle this,
    in material AI may not read. Refusing the item is the mechanical half."""
    import contract_record
    live = REPO / "products" / "oncology" / "prostate" / "202606"
    if not (live / "spec_pipeline" / "out" / "extracted.json").exists():
        return
    pack = Path(_approved(str(live)))   # signed copy: the AI gate is a separate property, tested below
    import json as _json
    rows = _json.loads((pack / "spec_pipeline" / "out" / "extracted.json").read_text())["rows"]
    red = [r["item_id"] for r in rows if r.get("vendor_redacted")]
    assert red, "no redacted row in this pack — the assertion below would check nothing"

    _m, bad = contract_record.merge_evidence({"variable_id": "BP"}, str(pack), red[0])
    assert bad and "VENDOR_REDACTED" in bad[0], bad
    assert "authorized human" in bad[0].lower(), bad
    # an ordinary row is unaffected
    _m, ok = contract_record.merge_evidence({"variable_id": "AGE"}, str(pack), "demographics:9")
    assert not ok, ok


def test_the_register_reader_is_one_reader_for_all_three_registers():
    """The gap index used a local `split("|")` because `_register_rows` hardcoded `ID` and
    `ENGINE_GAPS.md` heads its column `Gap ID` — a FOURTH parser for one register shape. One argument
    is cheaper than a parser, and cheaper again than the divergence between them."""
    import contract_lint as cl
    pack = REPO / "products" / "oncology" / "prostate" / "202606" / "handoff"
    if not (pack / "ENGINE_GAPS.md").exists():
        return
    gaps = cl.decision_rows((pack / "ENGINE_GAPS.md").read_text(encoding="utf-8"), "Gap ID")
    assert gaps, "the shared reader finds no gap rows"
    # the OWNER of what counts as a gap id still decides membership
    legal = cl.gap_ids((pack / "ENGINE_GAPS.md").read_text(encoding="utf-8"))
    assert legal & set(gaps), "the shared reader and gap_ids disagree about every id"
    # ...and the default is unchanged for the two registers that do head their column `ID`
    assert cl.decision_rows((pack / "DECISIONS.md").read_text(encoding="utf-8"))
    assert cl.decision_rows((pack / "SPEC_QC_FINDINGS.md").read_text(encoding="utf-8"))
    # no local pipe-splitting left in the slicer for this
    src = (REPO / "platform" / "tools" / "spec_slice.py").read_text(encoding="utf-8")
    code = [l for l in src.splitlines() if not l.lstrip().startswith("#")]
    assert not any('strip("|").split("|")' in l for l in code), \
        "spec_slice parses a register table by hand again"

if __name__ == "__main__":
    # CI runs each suite as a script (`python3 tests/test_x.py`), not under pytest. Without this block
    # the file imports cleanly, defines its tests, exits 0 — and CI reports a pass having asserted
    # nothing. That is the same silent-success failure this suite exists to catch elsewhere.
    import traceback
    failed = 0
    for _name, _fn in sorted(globals().items()):
        if _name.startswith("test_") and callable(_fn):
            try:
                _fn()
                print(f"  ok   {_name}")
            except BaseException:                     # noqa: BLE001 - includes pytest.skip
                if type(_fn).__name__ and "Skipped" in traceback.format_exc():
                    print(f"  skip {_name}")
                    continue
                failed += 1
                print(f"  FAIL {_name}")
                traceback.print_exc()
    print(f"\n{'FAILED' if failed else 'OK'} — {failed} failure(s)")
    sys.exit(1 if failed else 0)
