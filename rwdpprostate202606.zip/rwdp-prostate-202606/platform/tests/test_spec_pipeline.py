"""The spec→contract pipeline: column resolution and the emitted record shape.

These tests exist because of a real defect. The extractor read the spec by POSITION, which made it
report the `Time Period` cell as the variable name on 192 of 200 prostate rows, and made the scaffold
carry the `Label` cell into `required_rule` instead of the `Definition` cell on 148 of 200. Both are
silent: the output stays well-formed and plausible, so nothing downstream complains. Columns are now
resolved by NAME from each tab's own header, and these tests hold that.

Run: python3 -m pytest platform/tests/test_spec_pipeline.py (or pytest).
"""
import glob
import hashlib
import os
import re
import sys
from pathlib import Path

REPO = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(REPO / "platform" / "tools"))

import contract_scaffold                                            # noqa: E402
import spec_extract                                                 # noqa: E402

# A 4.StudyPop-shaped row: Variable is the THIRD column, and Label is longer than Definition. Position
# or length would pick the wrong cell here; that is the whole point of the fixture.
# A hardcoded schema count, in prose that is not allowed to hold one. ONE definition, used by the
# SKILL.md scan and the evals.json scan alike: two regexes would drift, and the eval file is where the
# looser spelling ("the 21 CANON fields") actually hid from the first version of this pattern.
SCHEMA_COUNT_RE = r"\b\d+[- ](?:\w+[- ])?(?:fields?|columns?|separators?|keys?)\b"

STUDYPOP_HEADER = ["Section", "Time Period", "Variable", "Label", "Values", "Definition",
                   "Additional Notes"]
STUDYPOP_CELLS = ["Section A: Population Subset", "STUDY_PD", "MCRPCDD",
                  "Metastatic castration-resistant prostate cancer diagnosis date",
                  "Date", "Max(MetDiagnosisDate and CRPCDate)", "check against enh_prostate"]


def test_columns_resolve_by_name_not_position():
    f = spec_extract.named_fields(STUDYPOP_HEADER, STUDYPOP_CELLS)
    assert f["variable"] == "MCRPCDD"
    assert f["definition"] == "Max(MetDiagnosisDate and CRPCDate)"
    assert f["label"].startswith("Metastatic castration-resistant")
    assert f["time_period"] == "STUDY_PD"
    assert f["notes"] == "check against enh_prostate"


def test_synonyms_and_case_and_spacing():
    f = spec_extract.named_fields(["Variable Name", "  DEFINITION ", "Notes"],
                                  ["AGE", "year(INDEX) - BirthYear", "approximate"])
    assert f == {"variable": "AGE", "definition": "year(INDEX) - BirthYear", "notes": "approximate"}


def test_unrecognised_columns_are_dropped_not_guessed():
    f = spec_extract.named_fields(["QC Reviewed (Initials + Date)", "Date Modified"], ["JS 2026-06-01", ""])
    assert f == {}, "an unrecognised header must resolve to nothing, never to a positional guess"


def test_definition_wins_over_a_longer_label():
    row = {"cells": STUDYPOP_CELLS,
           "fields": spec_extract.named_fields(STUDYPOP_HEADER, STUDYPOP_CELLS)}
    definition, notes = contract_scaffold._definition_and_notes(row)
    assert definition == "Max(MetDiagnosisDate and CRPCDate)"
    assert notes == "check against enh_prostate"


def test_headerless_row_falls_back_to_the_old_heuristic():
    """A tab whose header names nothing recognisable still yields something, and says so by shape."""
    row = {"cells": ["X", "a short cell", "a definition long enough to be picked up by the fallback"],
           "fields": {}}
    definition, _ = contract_scaffold._definition_and_notes(row)
    assert definition.startswith("a definition long enough")


def test_blank_variable_cell_is_respected_not_backfilled():
    """A Variable column present but empty marks a note/continuation row. Falling back to position here
    is exactly how the `Time Period` cell became the variable name."""
    cells = ["Section A", "STUDY_PD", "", "", "", "Keep these variables", ""]
    f = spec_extract.named_fields(STUDYPOP_HEADER, cells)
    assert spec_extract.row_variable(f, cells) == "", "must not backfill from the Time Period cell"
    # With no usable header the positional fallback is all there is, and it is allowed to guess.
    assert spec_extract.row_variable({}, cells) == "Section A"


def test_carried_columns_skip_na_and_empty():
    f = spec_extract.named_fields(["Variable", "Label", "Code Lists Group", "Values"],
                                  ["AGE", "Age at index", "N/A", ""])
    carried = contract_scaffold.carried_columns({"fields": f})
    assert carried == [("Label", "Age at index")], carried


def _scaffold_table(md):
    """Split scaffold output into (header cells, [row cells], guidance section)."""
    table, _, guidance = md.partition("\n## Row notes")
    lines = [l for l in table.strip().splitlines() if l.startswith("|")]
    cells = lambda l: [c.strip() for c in l.strip().strip("|").split("|")]
    return cells(lines[0]), [cells(l) for l in lines[2:]], guidance


def test_emitted_record_is_the_canonical_21_keys_in_order():
    rec = {"variable_id": "AGE", "spec_refs": ["demographics:9"],
           "required_rule": "year(INDEX) - BirthYear", "notes": "",
           "spec_columns": [("Label", "Age at index")]}
    md = contract_scaffold.to_contract_records([rec])
    head, rows, guidance = _scaffold_table(md)
    assert head == contract_scaffold.CANON_ORDER + ["implementation_refs"], head
    assert len(rows) == 1 and len(rows[0]) == len(head), rows
    # status / output / publish must stay ONE inline dict in ONE cell: the contract lint parses them
    # positionally, and a value broken across lines parses as absent — the record then fails I6 for a
    # reason nobody can see. `pipe()` folds newlines, so this asserts the fold actually happened.
    for k in ("status", "output", "publish"):
        v = rows[0][head.index(k)]
        assert v.startswith("{") and v.endswith("}") and "\n" not in v, f"{k} must be one inline dict: {v}"
    assert "Also on this spec row" in guidance and "Label: Age at index" in guidance
    # The notes are scaffold guidance, not contract content — they must not ride into the table row.
    assert "Also on this spec row" not in "".join(rows[0])


def test_no_field_is_left_empty():
    """An empty cell fails the contract lint's presence check, so the scaffold must emit TODO instead."""
    md = contract_scaffold.to_contract_records([{"variable_id": "X", "spec_refs": ["clinical:1"],
                                                 "required_rule": "", "notes": ""}])
    head, rows, _ = _scaffold_table(md)
    for k, v in zip(head, rows[0]):
        assert v, f"empty cell: {k}"


def test_duplicate_variable_id_is_suffixed_and_explained():
    """The lint requires unique variable_id (I1). A spec repeating a name is normal; resolving it is a
    person's judgment, so the scaffold must surface the collision rather than silently emit two."""
    recs = [{"variable_id": "FUED", "spec_refs": ["clinical:91"], "required_rule": "r", "notes": ""},
            {"variable_id": "FUED", "spec_refs": ["clinical:94"], "required_rule": "r", "notes": ""}]
    md = contract_scaffold.to_contract_records(recs)
    head, rows, guidance = _scaffold_table(md)
    ids = [r[head.index("variable_id")] for r in rows]
    assert ids == ["FUED", "FUED__2"], ids
    assert "DUPLICATE NAME" in guidance


def test_prostate_spec_tabs_resolve_every_row_by_header():
    """Real-data guard on the defect itself: the prostate tabs must resolve their variable column by
    name, and ECOG must come out as ECOG rather than as its time-period token."""
    product = REPO / "products" / "oncology" / "prostate" / "202606"
    # Resolve the spec through the pack's REGISTRATION, not a hardcoded folder. This checked
    # `ref/prog_spec` — the layout the pack had before the spec moved to `reference/Program
    # Specification/` — so it silently took its skip path, and the skip path itself crashed: CI runs
    # these suites as plain scripts and pytest is not in requirements.txt. A real-data guard that
    # quietly stops guarding is the failure this test exists to prevent, so it no longer skips.
    import subprocess
    rel = subprocess.run([sys.executable, str(REPO / "platform" / "tools" / "source_manifest.py"),
                          str(product), "--resolve", "spec_tabs"],
                         capture_output=True, text=True).stdout.strip()
    spec_dir = REPO / rel if rel else None
    assert spec_dir and spec_dir.is_dir(), \
        (f"prostate 202606 registers `spec_tabs` at {rel!r}, which is not a directory. "
         f"The extractor reads the REGISTERED material; if the stand-in moved, move the "
         f"registration with it.")
    data = spec_extract.extract(str(spec_dir), {"5b. clinchars": "clinical"})
    e = data["extraction"]
    assert e["variable_by_position"] == 0, "every spec tab carries a recognisable header"
    ecog = next(r for r in data["rows"] if r["item_id"] == "clinical:47")
    assert ecog["variable"] == "ECOG", ecog["variable"]
    assert ecog["fields"]["time_period"] == "LOT_ECOG"


def test_shared_sheet_map_is_the_single_source_of_the_mapping():
    """RWB's sheet names are their template, not a per-product fact. The map lives once in governance/,
    and a product's pipeline.conf normally sets no DOMAINS at all."""
    domains = spec_extract.shared_domains(str(REPO / "platform" / "tools"))
    assert domains, "governance/spec_sheet_map.yaml did not parse"
    # both the current template labels and the historical ones a live workbook still uses
    assert domains["6.clinical characteristics"] == "clinical"
    assert domains["5b. clinchars"] == "clinical"
    assert domains["3.data prep"] == "study_period"
    # sheets that are NOT requirement-bearing must stay absent — that absence is what skips them
    for sheet in ("1.cover", "2.changes", "11.review decisions", "16.approval gate"):
        assert sheet not in domains, sheet


def test_requirement_rows_defaults_to_the_mapped_sheets():
    data = {"rows": [{"tab": "6.Clinical characteristics", "domain": "clinical"},
                     {"tab": "1.Cover", "domain": ""},
                     {"tab": "11.Review Decisions", "domain": ""}]}
    assert [r["tab"] for r in spec_extract.requirement_rows(data)] == ["6.Clinical characteristics"]
    # an explicit tab list still wins...
    assert len(spec_extract.requirement_rows(data, ["1.Cover"])) == 1
    # ...and a spec with no mapping at all falls back to every row rather than scanning nothing
    unmapped = {"rows": [{"tab": "Sheet1", "domain": ""}, {"tab": "Sheet2", "domain": ""}]}
    assert len(spec_extract.requirement_rows(unmapped)) == 2


def test_product_conf_carries_no_sheet_mapping():
    """The point of the shared map: a live product's pipeline.conf states only what is truly its own."""
    for slug in ("prostate", "oc"):
        conf = REPO / "products" / "oncology" / slug / "202606" / "spec_pipeline" / "pipeline.conf"
        body = "\n".join(l for l in conf.read_text().splitlines() if not l.lstrip().startswith("#"))
        assert "DOMAINS=" not in body, f"{slug} restates the shared sheet map"
        assert "TABS=" not in body, f"{slug} restates the requirement-bearing sheet list"


# --- the defect scan across vendors --------------------------------------------------------------
import spec_lint                                                    # noqa: E402


def _rows(*texts):
    return [{"item_id": f"clinical:{i}", "tab": "6.Clinical characteristics", "row": i, "text": t,
             "variable": "X", "cells": ["", "", ""], "domain": "clinical"}
            for i, t in enumerate(texts, start=2)]


def test_foreign_table_check_covers_cota_stems_not_only_flatiron():
    """The check was anchored on Flatiron's `t_` prefix, so a COTA heme spec (stems like `cota_dlbcl`)
    contained nothing it could see — a HIGH check that silently never fired."""
    data = {"rows": _rows("Ann Arbor stage from cota_dlbcl",
                          "IPI risk from cota_cll_risk",          # a CLL table inside a DLBCL spec
                          "response per Lugano from cota_dlbcl")}
    kinds = [(f["kind"], f["detail"]) for f in spec_lint.scan(data, "dlbcl")]
    assert any(k == "FOREIGN_TABLE" and "cll" in d for k, d in kinds), kinds
    assert not any("cota_dlbcl" in d for _, d in kinds), "own-tumour tables must not be flagged"


def test_no_terminal_else_spares_an_exhaustive_numeric_chain_but_not_a_gap():
    """A graduated numeric-band rule (`<18.5 / [18.5,25) / [25,30) / >=30 / missing`) has no bare
    `else` yet leaves no input undefined — the four ranges tile the reals and the missing branch covers
    the rest. Flagging it forced a confirm-exhaustiveness TODO onto a logically complete rule (BMIGR1).
    The exemption is PROVEN-tiling only: a gap, an uncovered boundary, or a categorical chain (which
    can leave a value undefined) must stay flagged."""
    def kinds(text):
        return {f["kind"] for f in spec_lint.scan({"rows": _rows(text)}, None)}

    assert "NO_TERMINAL_ELSE" not in kinds(
        "If BMI <18.5 THEN =1; Else if 18.5 <= BMI < 25 then =2; Else if 25 <= BMI < 30 then =3; "
        "Else if BMI >= 30 then =4; Else if BMI is missing then =5;"), "exhaustive bands wrongly flagged"
    # a gap ([25,30) dropped) is still undefined for 25<=BMI<30 -> must stay flagged
    assert "NO_TERMINAL_ELSE" in kinds(
        "If BMI <18.5 then 1; else if 18.5 <= BMI < 25 then 2; else if BMI >= 30 then 4; "
        "else if BMI is missing then 5;"), "a numeric GAP must still flag"
    # a categorical chain can leave X=3 undefined -> must stay flagged
    assert "NO_TERMINAL_ELSE" in kinds(
        "if X=1 then A; else if X=2 then B; else if X is missing then C;"), "categorical must still flag"
    # both-strict boundary leaves the exact value 18.5 uncovered -> must stay flagged
    assert "NO_TERMINAL_ELSE" in kinds(
        "if X < 18.5 then A; else if X > 18.5 then B; else if X is missing then C;"), "boundary gap must flag"


def test_a_check_that_could_not_fire_says_so():
    """A check finding nothing and a check that never applied look identical in a zero-finding report.
    That is how a spec passes a scan it was never actually subject to."""
    assert spec_lint.inapplicable_checks(_rows("OS = death date - index date"), "dlbcl"), \
        "a spec naming no source tables must be reported, not silently passed"
    assert spec_lint.inapplicable_checks(_rows("from cota_dlbcl"), None)
    assert spec_lint.inapplicable_checks(_rows("from cota_dlbcl"), "not-a-tumour")
    # ...and a scan that genuinely applied stays quiet
    assert spec_lint.inapplicable_checks(_rows("from cota_dlbcl"), "dlbcl") == []


def test_every_registry_tumour_is_known_to_the_foreign_table_check():
    """A slug the check does not know makes FOREIGN_TABLE vacuous for that product. Cheap to keep true."""
    registry = (REPO / "products" / "registry.yaml").read_text()
    slugs = set(re.findall(r"slug:\s*([a-z0-9_]+)", registry))
    unknown = sorted(s for s in slugs if not spec_lint.tumor_family(s))
    assert unknown == [], f"registry slugs the foreign-table check cannot resolve: {unknown}"


def test_onboarding_a_TUMOUR_needs_no_change_under_platform():
    """The production acceptance criterion: adding a product must not require editing shared code.

    The families, their stems and the vendor table prefixes lived as Python constants in `spec_lint`,
    so a new tumour meant a code change — and it failed quietly, because an unlisted slug made
    `tumor_family()` return None and FOREIGN_TABLE reported itself inapplicable rather than erroring.
    They are governed data now; this proves the whole path reads from that file.
    """
    import shutil
    import tempfile as _tf
    reg = REPO / "governance" / "tumour_registry.yaml"
    tmp = Path(_tf.mkdtemp())
    shutil.copy(reg, tmp / "backup.yaml")
    try:
        spec_lint._REGISTRY = None
        assert spec_lint.tumor_family("martian") is None, "fixture slug already exists"
        reg.write_text(reg.read_text().replace("  gist: [gist]",
                                               "  gist: [gist]\n  martian: [martian, mrtn_]"),
                       encoding="utf-8")
        spec_lint._REGISTRY = None
        assert spec_lint.tumor_family("martian") == "martian"
        # ...and the check now actually FIRES for it, which is what "supported" has to mean
        found = spec_lint.scan_row({"text": "reads t_prostate_biomarkers", "cells": ["", "", ""]},
                                   "martian")
        assert any(k == "FOREIGN_TABLE" for k, _ in found), found
    finally:
        shutil.copy(tmp / "backup.yaml", reg)
        shutil.rmtree(tmp, ignore_errors=True)
        spec_lint._REGISTRY = None
    assert spec_lint.tumor_family("martian") is None, "the registry was not restored"


def test_a_missing_tumour_registry_FAILS_rather_than_reporting_not_applicable():
    """Same lesson as the AI-boundary policy. An empty families map would make FOREIGN_TABLE report
    itself inapplicable on every pack at once — the check switching itself off repo-wide because a
    file went missing."""
    import shutil
    import tempfile as _tf
    reg = REPO / "governance" / "tumour_registry.yaml"
    tmp = Path(_tf.mkdtemp())
    shutil.copy(reg, tmp / "backup.yaml")
    try:
        reg.unlink()
        spec_lint._REGISTRY = None
        try:
            spec_lint.tumour_registry()
        except SystemExit as e:
            assert "cannot tell one tumour's tables from another" in str(e), str(e)
        else:
            raise AssertionError("a missing tumour registry was tolerated")
    finally:
        shutil.copy(tmp / "backup.yaml", reg)
        shutil.rmtree(tmp, ignore_errors=True)
        spec_lint._REGISTRY = None


def test_registry_stems_are_DISCRIMINATING_so_no_family_flags_another():
    """Two families sharing a stem would each flag the other's tables inside its own spec — turning
    every legitimate reference into a FOREIGN_TABLE finding, which is how a check earns being switched
    off. The registry's own comment promises this; nothing was holding it."""
    fams = spec_lint.tumour_registry()["families"]
    for fam, stems in fams.items():
        # Through the REAL matcher, on a table spelled the way each family's own tables are. A
        # separate substring opinion here would be a second definition of "names this family" — and
        # would have gone on passing after the matcher was fixed, or failing before it was broken.
        for stem in stems:
            table = f"t_{stem}_biomarkers"
            claimants = sorted(f for f, ss in fams.items() if spec_lint._names_family(table, ss))
            assert claimants == [fam], f"{table} is claimed by {claimants}, not {fam} alone"


def test_one_tumour_name_containing_another_does_not_confuse_the_two():
    """The general shape, not one incident. `sclc` sits inside `nsclc`; `lbcl` sits inside `dlbcl`;
    the portfolio will keep producing these because oncology names are built by prefixing.

    Under plain substring matching each pair failed silently and ONE-DIRECTIONALLY: the shorter name
    matched the longer one's tables, so the longer tumour's table sitting in the shorter tumour's spec
    matched that spec's OWN stem and was never reported. `lbcl` is not in the registry today — this
    asserts the MATCHER is right, so adding it stays a one-line data edit.
    """
    for outer, inner in (("nsclc", "sclc"), ("dlbcl", "lbcl"), ("dlbcl", "bcl")):
        assert not spec_lint._names_family(f"t_{outer}_biomarkers", [inner]), \
            f"'{inner}' claims a {outer} table — the substring bug is back"
        assert not spec_lint._names_family(f"t_{inner}_biomarkers", [outer]), \
            f"'{outer}' claims a {inner} table"
        assert spec_lint._names_family(f"t_{outer}_biomarkers", [outer])
        assert spec_lint._names_family(f"t_{inner}_biomarkers", [inner])


def test_the_registry_guardrail_catches_a_PREFIX_collision():
    """Token-prefix matching solves containment but NOT a stem that is a genuine prefix of another —
    `cll` would still claim a `cllx` table. That residual case is exactly what the discriminating-stems
    test above is for, so prove it actually bites rather than assuming it."""
    fams = dict(spec_lint.tumour_registry()["families"])
    fams["cllx"] = ["cllx"]
    claimants = sorted(f for f, ss in fams.items() if spec_lint._names_family("t_cllx_biomarkers", ss))
    assert claimants == ["cll", "cllx"], claimants          # the collision the guardrail must report


def test_lint_findings_reach_the_scaffold_and_coverage():
    """The findings were keyed by item_id but looked up by tab+row, so `5B. ClinChars:89` never matched
    `clinical:89`: no scaffold record carried a warning and every COVERAGE lint cell was blank."""
    data = {"extraction": {"row_count": 1, "tabs": ["6.Clinical characteristics"], "sources": []},
            "rows": [{"tab": "6.Clinical characteristics", "row": 89, "domain": "clinical",
                      "item_id": "clinical:89", "variable": "FUED", "text": "x",
                      "cells": ["FUED", "label", "a definition long enough to count"],
                      "fields": {"variable": "FUED", "definition": "a definition long enough to count"},
                      "content_hash": "abc"}]}
    findings = [{"item_id": "clinical:89", "kind": "FOREIGN_TABLE", "detail": "colorectal table"}]
    import tempfile
    with tempfile.TemporaryDirectory() as tmp:
        out = contract_scaffold.scaffold(data, tmp, findings)
        assert out["records"][0]["lint_flags"] == ["FOREIGN_TABLE: colorectal table"]
        assert "Deterministic lint flagged this row" in contract_scaffold.to_contract_records(out["records"])
        rows, _counts = contract_scaffold.coverage_report(data, tmp, findings)
        assert rows[0]["flags"] == "yes"


def test_blank_variable_row_with_real_content_is_not_called_context():
    """A blank Variable cell can mark a continuation row carrying the rest of a derivation. Auto-calling
    it context would drop a requirement silently."""
    banner = {"variable": "Section B: Define Study Time Periods", "cells": ["Section B: Define Study Time Periods"]}
    blank_short = {"variable": "", "cells": ["", "n/a"]}
    continuation = {"variable": "", "cells": ["", "", "else if BIOMARKERSTATUS contains 'VUS' then = 'VUS'"]}
    assert contract_scaffold.is_context(banner)
    assert contract_scaffold.is_context(blank_short)
    assert not contract_scaffold.is_context(continuation)
    assert contract_scaffold.is_context({"pre_header": True, "variable": "anything", "cells": ["x" * 80]})
    # ONE definition, shared as an object. The extractor needs it to keep its POSITIONAL warning off
    # banner rows; contract_scaffold needs it to classify them. Two copies would agree today and
    # diverge on the first change to what a banner is — with "needs a contract record" and "does not"
    # on either side. Identity, not agreement: two tests asserting the same answers would both pass
    # right up to the divergence.
    assert contract_scaffold.is_context is spec_extract.is_context
    assert contract_scaffold.CONTEXT_RE is spec_extract.CONTEXT_RE


def test_positional_variable_reads_are_reported_over_rows_that_become_records():
    """The count has to be over rows a positional read can REACH, or it reports noise.

    First real .xlsx run said `variable column resolved by header on 367/828 rows (461 fell back to
    position)`. Alarming, and almost entirely the 15 cover, changelog, delta and review-decision
    sheets, which have no Variable column and are never scanned. Of the 360 rows that were actually
    requirement-bearing, 18 read positionally and all 18 were section banners with no variable name to
    resolve — so the true count of positional reads reaching a contract record was zero, and that was
    the one number not on the page.

    Positional reads are this repo's named worst failure mode: a reordered column silently renames the
    requirement. A warning that fires six times on banner rows is how a reader learns to skip the
    seventh.
    """
    import tempfile as _t

    with _t.TemporaryDirectory() as tmp:
        spec = Path(tmp)
        # Header names the Variable column — the clean case.
        (spec / "5.Demographics.md").write_text(
            "| Row | Variable Name | Definition |\n|---|---|---|\n"
            "| 10 | AGE | Age at index |\n", encoding="utf-8")
        # Header names NOTHING COLUMN_RULES knows, so every row here falls back to cell position.
        (spec / "6.Outcomes.md").write_text(
            "| Row | Item | Meaning |\n|---|---|---|\n"
            "| 9 | Section A: Outcomes |  |\n"                      # banner: no name to resolve
            "| 22 | OS_MONTHS | months from index to death or censor |\n",   # substantive: report it
            encoding="utf-8")
        # A cover sheet: no domain, never scanned, must not enter the count at all.
        (spec / "1.Cover.md").write_text(
            "| Row | Prepared by | Date |\n|---|---|---|\n| 3 | RWB | 2026-06-01 |\n", encoding="utf-8")

        # Through extract(), not a hand-built row list: the first version of this test reimplemented
        # the filter and passed happily with the real one reverted, proving only that the assertion
        # agreed with itself.
        e = spec_extract.extract(str(spec),
                                 {"5.demographics": "demographics", "6.outcomes": "outcomes"})["extraction"]

    assert e["row_count"] == 4 and e["requirement_row_count"] == 3, \
        f"the cover sheet leaked into the requirement rows: {e['row_count']} / {e['requirement_row_count']}"
    assert e["variable_by_position_tabs"] == [{"tab": "6.Outcomes", "rows": 1}], \
        (f"expected only the substantive positional row to be flagged, got "
         f"{e['variable_by_position_tabs']} — a banner has no variable name to resolve, and a warning "
         f"that fires on banners is one a reader learns to skip")

    # And the console leads with the requirement-scoped figure, not the whole-workbook ratio.
    src = Path(spec_extract.__file__).read_text(encoding="utf-8")
    assert "requirement rows" in src and "POSITIONAL  tab" in src
    assert 'not scanned)' in src, "the non-requirement remainder is no longer accounted for on screen"


def test_unclassified_sheets_are_distinguished_from_declared_ignored():
    """Absence from the map meant two different things — "carries no requirements" and "nobody looked".
    Only one of those is safe to skip."""
    m = spec_extract.shared_sheet_map(str(REPO / "platform" / "tools"))
    assert m["ignored"]["1.cover"] and m["sheets"]["6.clinical characteristics"]
    assert "9.proc psoc strategy" not in m["ignored"], \
        "the PSOC strategy sheet must stay unclassified until RWP rules on it"
    data = spec_extract.extract(str(REPO / "products" / "oncology" / "oc" / "202606" /
                                    "prog_spec" / "reference" /
                                    "PROG_SPEC_RWDP_Ovarian_PANO_202606.xlsx"),
                                spec_extract.shared_domains())
    assert data["extraction"]["unclassified_tabs"] == ["9.PROC PSOC Strategy"], \
        data["extraction"]["unclassified_tabs"]


def test_lint_json_carries_applicability_not_just_findings():
    """A consumer reading only `findings: []` cannot tell "clean" from "never looked"."""
    import json as _json
    payload = _json.loads((REPO / "products" / "oncology" / "prostate" / "202606" /
                           "spec_pipeline" / "out" / "lint.json").read_text())
    assert set(payload) == {"fingerprint", "findings", "applicability"}
    assert payload["applicability"]["foreign_table"] == "applied"
    # `fingerprint` is the extraction's, copied through — not a second hash computed by the lint.
    ex = _json.loads((REPO / "products" / "oncology" / "prostate" / "202606" /
                      "spec_pipeline" / "out" / "extracted.json").read_text())
    assert payload["fingerprint"] == ex["extraction"]["fingerprint"] != ""



# --- the decision report -------------------------------------------------------------------------
import decision_report                                              # noqa: E402


def test_decision_report_ranks_by_blast_radius():
    """Twenty open questions are not twenty equal problems. The ranking only exists in the join between
    the records and the decision register, so it has to be computed — it is in neither file alone."""
    product = REPO / "products" / "oncology" / "prostate" / "202606"
    blocks, table, idle, status = decision_report.blast_radius(str(product))
    assert blocks, "no record is blocked — the join found nothing"
    ranked = sorted(blocks.items(), key=lambda kv: -len(kv[1]))
    assert len(ranked[0][1]) > len(ranked[-1][1]), "ranking is flat; the join is probably wrong"
    # every blocked record must be decision_required, which is I11 seen from the other side
    text = decision_report.render(str(product), blocks, table, idle, status)
    assert "Ranked by how many records each answer unblocks" in text
    for did, vids in blocks.items():
        assert did in status and status[did] == "OPEN", did


def test_decision_report_flags_a_question_that_blocks_nothing():
    """An open decision no record cites can mean it is answered-but-unrecorded, or that a record which
    SHOULD cite it does not. Either way it must not read as 'nothing to do'."""
    product = REPO / "products" / "oncology" / "prostate" / "202606"
    blocks, table, idle, status = decision_report.blast_radius(str(product))
    text = decision_report.render(str(product), blocks, table, idle, status)
    if idle:
        assert "Open, but blocking no record" in text


def test_decision_report_check_detects_staleness():
    product = str(REPO / "products" / "oncology" / "prostate" / "202606")
    blocks, table, idle, status = decision_report.blast_radius(product)
    fresh = decision_report.render(product, blocks, table, idle, status)
    committed = (REPO / "products" / "oncology" / "prostate" / "202606" / "handoff"
                 / "RWB_QUESTIONS.md").read_text()
    assert committed == fresh, "the committed question list is stale — regenerate it"



# --- portability: nothing generated may carry a checkout path ------------------------------------
import json as _json                                                # noqa: E402
import product_gates                                                # noqa: E402


def test_no_generated_artifact_contains_a_checkout_path():
    """An absolute path makes `--check` mean "regenerated on this machine, in this directory" instead of
    "current". It passes locally and fails on every other checkout — the worst kind of green, and it is
    what broke CI.

    The markers come from `repo_hygiene`, which scans the WHOLE tracked tree with the same list. Two
    copies of "what a machine path looks like" would agree today and diverge at the first addition,
    and the narrow one is the copy nobody would think to update.
    """
    import repo_hygiene
    rels = sorted(str(p.relative_to(REPO)).replace(os.sep, "/")
                  for p in (REPO / "products").glob("*/*/*/spec_pipeline/out/*") if p.is_file())
    assert rels, "no generated spec-pipeline artifacts found — this test would be vacuous"
    bad = repo_hygiene.machine_paths_in(
        str(REPO), rels, markers=repo_hygiene.MACHINE_PATHS + repo_hygiene.GENERATED_ONLY)
    assert not bad, bad


def test_a_TSV_tab_extracts_into_the_same_shape_a_workbook_sheet_does():
    """A third input format, one output shape. A sponsor whose specification is not maintained in
    Excel, or who exports it without the workbook changing hands, sends tab-separated tabs; the
    pipeline downstream must not be able to tell the difference.

    The row NUMBER is the file's line number, so a finding still points at something a person can open
    and count to — the property Excel coordinates exist for.
    """
    import tempfile as _t
    with _t.TemporaryDirectory() as tmp:
        p = os.path.join(tmp, "5.Demographics.tsv")
        with open(p, "w", encoding="utf-8") as fh:
            fh.write("Demographics — 202606\n"                          # a title line: pre_header
                     "Variable\tLabel\tDefinition\n"                    # 3 populated -> the header
                     "AGE\tAge at index\tYears between birthyear and index\n"
                     "SEX\tSex\tAs delivered\n")
        tab, rows = spec_extract.read_tsv_tab(p)
        assert tab == "5.Demographics", tab
        assert [r["row"] for r in rows] == [1, 3, 4], [r["row"] for r in rows]
        assert rows[0]["pre_header"] and not rows[1]["pre_header"]
        assert rows[1]["header"] == ["Variable", "Label", "Definition"], rows[1]["header"]
        assert rows[1]["cells"] == ["AGE", "Age at index",
                                    "Years between birthyear and index"], rows[1]["cells"]
        # The keys a workbook sheet produces, exactly — a downstream stage reads one dict shape.
        assert set(rows[1]) == {"tab", "row", "cells", "header", "pre_header"}, sorted(rows[1])


def test_a_spec_directory_holding_BOTH_formats_is_REFUSED():
    """Two spellings of one tab, and which one produced a record would depend on sort order — invisible
    in the output, and the drift this pipeline exists to prevent one level up. The 202607 pack shipped
    a duplicate copy of its six tabs for exactly this reason and nothing noticed."""
    import tempfile as _t
    with _t.TemporaryDirectory() as tmp:
        with open(os.path.join(tmp, "demos.md"), "w", encoding="utf-8") as fh:
            fh.write("| row | Variable |\n|---|---|\n| 2 | AGE |\n")
        with open(os.path.join(tmp, "demos.tsv"), "w", encoding="utf-8") as fh:
            fh.write("Variable\tLabel\tDefinition\nAGE\tAge\tYears\n")
        try:
            spec_extract.extract(tmp)
            raise AssertionError("a directory holding both .md and .tsv tabs extracted anyway")
        except SystemExit as exc:
            assert "One format per spec directory" in str(exc), str(exc)


def test_generated_paths_are_repo_relative():
    for p in (REPO / "products").glob("*/*/*/spec_pipeline/out/extracted.json"):
        target = _json.loads(p.read_text())["extraction"]["target"]
        assert target.startswith("products/"), f"{p.relative_to(REPO)}: target={target!r}"
        assert not os.path.isabs(target), target


def test_repo_relative_falls_back_outside_a_checkout():
    """Products in a tmpdir (the lint's own fixtures) are not inside a checkout. The fallback must still
    be machine-independent rather than leaking the temp path."""
    import tempfile as _t
    with _t.TemporaryDirectory() as tmp:
        rel = spec_extract.repo_relative(os.path.join(tmp, "products", "oncology", "x", "202601"))
        assert rel == "202601" and "/" not in rel, rel


# --- CI gate discovery ---------------------------------------------------------------------------
def test_ci_names_no_product_path():
    """Naming products in the workflow is what left prostate 202607 and ovarian 202606 untested. A new
    tumour or spec year must be picked up by adding a folder."""
    wf = (REPO / ".github" / "workflows" / "rwdp-ci.yml").read_text()
    assert "products/oncology/prostate/2026" not in wf
    assert "product_gates.py" in wf


def test_gate_discovery_finds_every_pack_and_defaults_down():
    rows = product_gates.products(str(REPO))
    assert rows, "discovery found no packs at all"
    assert "products/oncology/oc/202606" in rows
    # DISCOVERED, not named. This asserted `prostate/202607` by path — so deleting that pack failed
    # the test that exists to prove discovery does not depend on any particular pack existing.
    assert any(r.startswith("products/oncology/prostate/") for r in rows)
    # strict applies only where the pack CLAIMS coverage_complete
    strict = [r for r in rows
              if product_gates.facts(str(REPO), r)["pipeline"]
              and product_gates.CONTRACT_LEVELS.index(
                  product_gates.maturity(os.path.join(str(REPO), r))["contract"]) >= 2]
    assert strict, "no pack claims coverage_complete — the strict rule below checks nothing"
    assert "products/oncology/oc/202606" not in strict, "a drafting pack must not be held to Gate 2"


def test_absent_maturity_defaults_to_the_lowest_level():
    """An absent manifest must never GRANT a gate — defaulting up would hold a new pack to Gate 2 the
    moment it was created, or worse, assume it already passed."""
    import tempfile as _t
    with _t.TemporaryDirectory() as tmp:
        m = product_gates.maturity(tmp)
        assert m["contract"] == "not_started"
        assert m["declared"] is False


# --- enumeration candidates ----------------------------------------------------------------------
import spec_codelists                                               # noqa: E402


def test_membership_captures_the_predicate_branch_and_invents_no_codes():
    """REGION1's `else if STATE is missing then ='Missing'` was dropped, and codes 1-5 were assigned by
    branch order. The spec states neither — REGION1N says only "Numeric of REGION1"."""
    text = ("if STATE in ('ME' 'VT') then ='Northeast'; else if STATE in ('PR') then ='Other region'; "
            "else if STATE is missing then ='Missing'")
    br = spec_codelists.membership_lists(text)
    assert [b["label"] for b in br] == ["Northeast", "Other region", "Missing"]
    assert br[-1]["predicate"] == "state_is_missing"
    skipped = [{"item_id": "outcomes:17", "variable": "PFSFL", "why": "does not match a known shape"}]
    out = spec_codelists.to_yaml(
        [{"item_id": "demographics:14", "variable": "REGION1", "kind": "membership",
          "hash": "abc", "values": br}], skipped, "products/x/spec")
    assert "numeric_codes: not_stated_by_the_spec" in out
    assert "code: 1" not in out, "a parser must not assign codes the spec does not state"
    assert 'members: ["ME", "VT"]' in out, "members must be quoted"
    # A row that LOOKS enumerated but did not parse must be IN the file. Printed to the console only,
    # it vanishes, and the artifact reads as a complete account of what the spec enumerates.
    assert "outcomes:17" in out and "PFSFL" in out
    import yaml as _y
    doc = _y.safe_load(out)
    assert [u["spec_ref"] for u in doc["unparsed"]] == ["outcomes:17"]
    assert "approved specification" not in out, \
        "provenance must be read from source_refs.yaml, never asserted by the generator"


def test_numeric_map_requires_a_complete_1_to_n_run():
    """A partial map lifted from a truncated row would silently drop categories."""
    assert spec_codelists.numeric_map("1 = Positive, 2 = Negative, 3 = VUS")
    assert spec_codelists.numeric_map("1 = Positive, 3 = VUS") == [], "a gap at 2 must reject the map"
    assert spec_codelists.numeric_map("4 = NGS") == [], "a single code is not a map"



# --- the disposition register ---------------------------------------------------------------------
def test_disposition_requires_the_evidence_for_its_claim():
    """A disposition is a governance claim. `excluded` removes a requirement from the product and was
    the easiest to write and the least evidenced — two ovarian rows were `excluded` while their own
    text said they had been raised as open questions."""
    import tempfile as _t
    with _t.TemporaryDirectory() as tmp:
        prod = Path(tmp) / "p"; (prod / "handoff").mkdir(parents=True)
        (prod / "handoff" / "DECISIONS.md").write_text(
            "| ID | Question | Owner | Status |\n|---|---|---|---|\n| OC-ECOG | q | RWB | OPEN |\n"
            "| DONE-ONE | q | RWB | RESOLVED |\n")
        known = {"clinical:1", "clinical:2"}
        bad = {"clinical:1": {"disposition": "excluded", "handled_by": "out of scope"}}
        errs = contract_scaffold.validate_dispositions(str(prod), bad, known)
        assert any("requires `approved_by`" in e for e in errs), errs
        # decision_required must name an OPEN decision, not a resolved one
        errs = contract_scaffold.validate_dispositions(
            str(prod), {"clinical:1": {"disposition": "decision_required", "handled_by": "x",
                                       "decision_id": "DONE-ONE"}}, known)
        assert any("not an OPEN decision" in e for e in errs), errs
        # a duplicate must name a real target, and the item itself must exist
        errs = contract_scaffold.validate_dispositions(
            str(prod), {"clinical:1": {"disposition": "duplicate", "handled_by": "x",
                                       "duplicate_of": "clinical:99"}}, known)
        assert any("duplicate_of 'clinical:99' is not a spec item" in e for e in errs), errs
        errs = contract_scaffold.validate_dispositions(
            str(prod), {"clinical:77": {"disposition": "context", "handled_by": "x"}}, known)
        assert any("no such spec item" in e for e in errs), errs
        # an unknown disposition word is rejected outright
        errs = contract_scaffold.validate_dispositions(
            str(prod), {"clinical:1": {"disposition": "probably_fine"}}, known)
        assert any("is not one of" in e for e in errs), errs


def test_live_disposition_registers_are_valid():
    """Every product's register, as committed."""
    import json as _j
    for conf in (REPO / "products").glob("*/*/*/spec_pipeline/pipeline.conf"):
        prod = conf.parent.parent
        ext = prod / "spec_pipeline" / "out" / "extracted.json"
        known = {r["item_id"] for r in _j.loads(ext.read_text())["rows"] if r.get("domain")}
        errs = contract_scaffold.validate_dispositions(
            str(prod), contract_scaffold.declared_dispositions(str(prod)), known)
        assert errs == [], f"{prod.relative_to(REPO)}: {errs}"



# --- Gate 1: the source approval record ------------------------------------------------------------
import source_manifest                                              # noqa: E402


def test_every_pack_with_a_contract_records_its_source():
    """A pack can otherwise reach a complete contract on a specification nobody recorded, let alone
    approved. All three live packs are provisional today and must say so."""
    assert source_manifest.main(["--all", "--check"]) == 0, \
        "Gate 1 refused a live pack — run `python3 platform/tools/source_manifest.py --all --check`\n        from the repo root; the errors above name the pack, the material index and the field owed"


REL = "products/oncology/x/202601"


def _pack(root, contract):
    prod = Path(root) / REL
    (prod / "handoff").mkdir(parents=True)
    (prod / "handoff" / "MATURITY.yaml").write_text(f"contract: {contract}\n")
    return prod


def _refs(prod, *materials):
    """A source_refs.yaml with one or more materials. Each defaults to being THE program spec.

    `ai_classification` is defaulted here, not per test: it is required of every material at every
    status, and no test below is ABOUT it — a fixture omitting it would fail for a reason unrelated to
    what the test asserts, which is how a negative assertion comes to pass on the wrong error. The
    test that IS about it overrides the default.
    """
    body = ""
    for m in materials:
        m = {"material_id": "program_spec", "material_type": "program_spec",
             "ai_classification": "sponsor_ai_eligible", "classified_by": "R. Classifier",
             "classified_date": "2026-07-27", **m}
        body += "  - " + "\n    ".join(f"{k}: {v}" for k, v in m.items()) + "\n"
    (prod / "source_refs.yaml").write_text(
        "product: x\nspec_version: \"202601\"\nsource_materials:\n" + body)


def test_an_approved_source_must_still_hash_to_its_record():
    """The checksum is what makes "this is the approved document" falsifiable — swapping the workbook
    under an approved contract stops being invisible."""
    import tempfile as _t
    with _t.TemporaryDirectory() as tmp:
        prod = _pack(tmp, "coverage_complete")
        wb = prod / "spec.xlsx"; wb.write_bytes(b"the approved workbook")
        real = source_manifest.sha256(str(wb))

        def reviewed(sha):
            _refs(prod, {"path_or_link": f"{REL}/spec.xlsx", "role": "program spec",
                         "status": "reviewed", "document_id": "X-1", "revision": "r1",
                         "sha256": sha, "approval_date": "2026-01-01", "approved_by": "J.S.",
                         "material_type": "program_spec", "data_refresh": "2026m06",
                         "ai_classification": "sponsor_ai_eligible",
                         "rwb_qc_reference": "RWB-QC-2026-01"})

        reviewed(real)
        assert source_manifest.check(tmp, REL) == []
        assert source_manifest.source_status(str(prod)) == "approved"
        reviewed("d" * 64)
        assert any("sha256 MISMATCH" in e for e in source_manifest.check(tmp, REL))
        # An all-digit checksum is a YAML *integer*. Compared as one it is unequal to every hash string
        # AND falsy, so the mismatch branch would be skipped on the one file it most needs to look at.
        reviewed("1" * 64)
        assert any("sha256 MISMATCH" in e for e in source_manifest.check(tmp, REL))


def test_the_shell_pipeline_only_delegates_to_the_python_one():
    """One definition of the pipeline, runnable without bash.

    run_spec_pipeline.sh was the ONLY bash in the workflow — every other tool is pure Python — so on
    a machine without it (a Windows checkout doing UAT) Gate 2 generation and the `--check` drift
    verification CI depends on were unreachable. The orchestration moved into run_spec_pipeline.py
    and the shell script now execs it. A second implementation would be two definitions of the
    pipeline, and this asserts the .sh never becomes one again.
    """
    import tempfile

    sys.path.insert(0, str(REPO / "platform" / "tools"))
    import run_spec_pipeline

    sh = (REPO / "platform" / "tools" / "run_spec_pipeline.sh").read_text(encoding="utf-8")
    # The shebang is a comment to this filter, which is why only ONE line should survive it.
    body = [l for l in sh.splitlines()
            if l.strip() and not l.lstrip().startswith("#") and not l.startswith("set ")]
    assert len(body) == 1 and "run_spec_pipeline.py" in body[0] and body[0].startswith("exec "), \
        f"the shell script has grown logic of its own: {body}"

    py = (REPO / "platform" / "tools" / "run_spec_pipeline.py").read_text(encoding="utf-8")
    # Each artifact filename appears ONCE, so the list `--check` compares cannot drift from the list
    # the pipeline writes. Six-of-seven compared reads as full protection while one sails through.
    for f in ("extracted.json", "lint.json", "SPEC_FINDINGS.txt", "COVERAGE.md", "scaffold.json",
              "SCAFFOLDED_RECORDS.md", "ENUMERATION_CANDIDATES.yaml"):
        assert py.count(f'"{f}"') == 1, f"{f} is written down {py.count(chr(34)+f+chr(34))} times"
    assert len(run_spec_pipeline.ARTIFACTS) == 7, run_spec_pipeline.ARTIFACTS

    # pipeline.conf is PARSED, not executed — the shell version ran it as bash. Assert the property
    # that matters (no shell) rather than grepping for the word, which the comment explaining the
    # change already contains.
    assert "shell=True" not in py, "a shell was reintroduced"
    with tempfile.TemporaryDirectory() as tmp:
        conf = Path(tmp, "pipeline.conf")
        conf.write_text('# a comment\nTUMOR="x"   # trailing\nSPEC_SOURCE_ID=program_spec\n',
                        encoding="utf-8")
        got = run_spec_pipeline.read_conf(str(conf))
        assert got["TUMOR"] == "x" and got["SPEC_SOURCE_ID"] == "program_spec", got
        assert got["TABS"] == "" and got["DOMAINS"] == "", "absent keys must default to empty"


def test_an_empty_extraction_is_refused_not_written():
    """Zero rows is the extractor saying it read no specification. It must fail, not succeed quietly.

    Observed on a fresh pack whose spec folder still held only the placeholder note: `extracted 0 rows
    from 0 source(s)` exited 0, the lint found no defects in nothing, coverage listed nothing
    undispositioned, the scaffold wrote nought records, and `--check` compared seven empty artifacts
    against seven identical empty artifacts and printed `OK — all 7 generated artifacts are current`.
    Each step told the truth about its own input; the sequence was a green light over an empty folder.

    The refusal lives at the extractor's CLI boundary because that is the one crossing every caller
    makes — the runner AND the six by-hand calls in START_HERE.md §4, which exist for the machine that
    cannot run the runner. Asserted through main() for that reason: a check on extract() alone would
    pass while the boundary stayed open.
    """
    import io
    import json
    import tempfile as _t
    from contextlib import redirect_stdout

    sys.path.insert(0, str(REPO / "platform" / "tools"))
    import spec_extract

    with _t.TemporaryDirectory() as tmp:
        spec = Path(tmp, "Program Specification")
        spec.mkdir()
        out = Path(tmp, "extracted.json")

        # 1. A folder holding a prose placeholder — no `|` table anywhere. The reported case.
        (spec / "PUT_THE_SPEC_HERE.md").write_text("# Put the spec here\n\nDrop the workbook in.\n",
                                                   encoding="utf-8")
        try:
            with redirect_stdout(io.StringIO()):
                spec_extract.main([str(spec), "--out", str(out)])
            raise AssertionError("a 0-row extraction exited 0 — the fail-open is back")
        except SystemExit as e:
            msg = str(e.code)
        assert "0 requirement rows" in msg and "PUT_THE_SPEC_HERE.md" in msg, msg
        # It must refuse BEFORE writing. An empty extracted.json on disk is what every later step
        # read as a successful capture.
        assert not out.exists(), "an empty extraction was written to disk before the refusal"

        # 2. An empty folder says something different — there is no file to have misread.
        (spec / "PUT_THE_SPEC_HERE.md").unlink()
        try:
            with redirect_stdout(io.StringIO()):
                spec_extract.main([str(spec), "--out", str(out)])
            raise AssertionError("an extraction from an empty folder exited 0")
        except SystemExit as e:
            assert "no .md or .tsv files at all" in str(e.code), e.code

        # 3. A real requirement table still extracts. The refusal must bite on nothing, not on little.
        (spec / "6.Clinical characteristics.md").write_text(
            "# 6.Clinical characteristics\n\n"
            "| Row | Variable Name | Definition |\n|---|---|---|\n"
            "| 12 | STAGE | Stage at diagnosis |\n",
            encoding="utf-8")
        with redirect_stdout(io.StringIO()):
            assert spec_extract.main([str(spec), "--out", str(out)]) == 0
        assert json.loads(out.read_text(encoding="utf-8"))["extraction"]["row_count"] >= 1


def test_check_distinguishes_never_generated_from_drifted():
    """`--check` verifies; it does not generate. Both facts have to reach the person running it.

    A pack with no `spec_pipeline/out/` is not a pack whose seven artifacts have all changed, and
    "Regenerate with run_spec_pipeline" is advice only for the second. The verifier also writes to a
    temp dir on purpose — one that regenerated over the files it compares against could never report
    drift — so it says so, because seven artifacts appearing under C:\\...\\Temp\\ otherwise reads as
    the tool having put the output in the wrong place.
    """
    sys.path.insert(0, str(REPO / "platform" / "tools"))
    import run_spec_pipeline

    src = run_spec_pipeline.__file__ and Path(run_spec_pipeline.__file__).read_text(encoding="utf-8")
    assert "NOT GENERATED" in src and "Run without --check first." in src
    # missing and stale are judged separately; a missing file must not be reported as a drifted one.
    assert "missing = [f for f in ARTIFACTS if not os.path.exists" in src, \
        "the missing/stale split is gone — a never-generated pack reads as seven changed artifacts"
    assert "Drop --check to generate." in src, "--check no longer says it is not generating"


def test_the_pipeline_takes_a_pack_and_says_so_when_handed_a_spec():
    """Handing the runner the workbook is the natural mistake, and it must not read as a broken tool.

    Reported: `run_spec_pipeline.py '...\\PROG_SPEC_..._202606.xlsx'` answered
    `missing ...\\PROG_SPEC_..._202606.xlsx\\spec_pipeline\\pipeline.conf` — a path nobody typed,
    inside a .xlsx. The workbook IS the file the pipeline reads, and every other tool on a
    developer's path takes the file it reads, so the guess is a reasonable one; the answer just never
    said which argument was wrong.

    The spec path is never an accepted alternative form. Naming it on the command line would make
    "what was approved" and "what was extracted" two facts nothing reconciles — a pack could approve
    workbook A and, the day someone typed a different path, extract B.
    """
    import tempfile as _t

    sys.path.insert(0, str(REPO / "platform" / "tools"))
    import run_spec_pipeline as rsp

    def err(p):
        return rsp.pack_argument_error(str(p), os.path.join(str(p), "spec_pipeline", "pipeline.conf"))

    with _t.TemporaryDirectory() as tmp:
        pack = Path(tmp, "packs", "202606")
        (pack / "spec_pipeline").mkdir(parents=True)
        (pack / "spec_pipeline" / "pipeline.conf").write_text('TUMOR="ovarian"\n', encoding="utf-8")
        spec_dir = pack / "reference" / "Program Specification"
        spec_dir.mkdir(parents=True)
        book = spec_dir / "PROG_SPEC_Ovarian_202606.xlsx"
        book.write_bytes(b"")

        # A real pack is accepted — the guard must bite on the wrong argument, not on every argument.
        assert err(pack) is None

        # The workbook: names the mistake AND points at the pack containing it.
        m = err(book)
        assert m and "is a file" in m and "PACK directory" in m, m
        assert os.path.relpath(str(pack)) in m, f"no pointer to the enclosing pack: {m}"

        # A directory that is simply not a pack, and a path that is not there at all, are told apart.
        assert "has no spec_pipeline/pipeline.conf" in err(Path(tmp, "packs"))
        assert "does not exist" in err(Path(tmp, "packs", "nope"))

        # Through main(), because a helper the entry point does not call is a message nobody sees —
        # asserting the function alone passed happily with the old `missing <path>` still wired in.
        try:
            rsp.main([str(book)])
            raise AssertionError("the workbook was accepted as a pack")
        except SystemExit as e:
            assert "PACK directory" in str(e.code), \
                f"main() does not report the argument mistake: {e.code!r}"

    # The indirection is the point, so the runner must never grow a spec-path argument beside it.
    src = Path(rsp.__file__).read_text(encoding="utf-8")
    assert 'ap.add_argument("product"' in src and src.count("ap.add_argument(") == 3, \
        "run_spec_pipeline grew an argument — if it names a spec path, the approval and the " \
        "extraction are no longer one fact"


def test_generated_artifacts_are_lf_whatever_platform_wrote_them():
    """Drift must mean the content changed, never that the author ran Windows.

    `.gitattributes` stores and checks these artifacts out as LF everywhere, but Python's text mode on
    Windows writes `\\r\\n`. A Windows checkout that was perfectly current regenerated seven
    byte-different files, and `--check` reported DRIFT on all seven — identical in the output to
    someone having hand-edited every generated file. On a repo whose evidence rests on byte equality
    that is the worst kind of false positive: it makes the real signal unreadable.

    Normalized in ONE place over the artifact list this module owns. Three of the four writers could
    set `newline="\\n"` themselves; the two whose stdout is redirected translate in the CHILD process,
    where the parent's `newline=` does not reach — so a per-writer fix would hold in three places and
    quietly not in the fourth.
    """
    import tempfile as _t

    sys.path.insert(0, str(REPO / "platform" / "tools"))
    import run_spec_pipeline as rsp

    with _t.TemporaryDirectory() as tmp:
        crlf = Path(tmp, "COVERAGE.md")
        crlf.write_bytes(b"| item | disposition |\r\n|---|---|\r\n| clinical:12 | mapped |\r\n")
        already = Path(tmp, "lint.json")
        already.write_bytes(b'{\n "findings": []\n}\n')
        mixed = Path(tmp, "SPEC_FINDINGS.txt")
        mixed.write_bytes(b"HIGH 0\r\nINFO 2\n")                 # a redirect can produce either

        rsp.normalize_newlines([str(crlf), str(already), str(mixed)])

        assert crlf.read_bytes() == b"| item | disposition |\n|---|---|\n| clinical:12 | mapped |\n"
        assert already.read_bytes() == b'{\n "findings": []\n}\n', "an LF file must be left alone"
        assert mixed.read_bytes() == b"HIGH 0\nINFO 2\n"
        # Idempotent: a second pass is what a --check run does to a file a generate run already wrote.
        before = crlf.read_bytes()
        rsp.normalize_newlines([str(crlf)])
        assert crlf.read_bytes() == before

        # A lone CR is not a line ending here and must survive — mangling data inside a cell would be
        # a silent content change dressed up as a whitespace fix.
        cr = Path(tmp, "scaffold.json")
        cr.write_bytes(b'{"note": "a\rb"}\r\n')
        rsp.normalize_newlines([str(cr)])
        assert cr.read_bytes() == b'{"note": "a\rb"}\n'

    # It must run on BOTH paths. Normalizing only the temp side would leave --check judging LF against
    # CRLF and reporting drift forever; only the generate side would leave the check doing the same.
    src = Path(rsp.__file__).read_text(encoding="utf-8")
    body = src.split("def main(", 1)[1]
    assert body.count("normalize_newlines(") == 1, \
        "normalize_newlines is called more than once in main() — it belongs before the check/generate " \
        "fork, so both paths normalize identically"
    assert body.index("normalize_newlines(") < body.index("if not a.check:"), \
        "normalization runs after the generate path returns — Windows output stays CRLF"


def test_a_product_can_declare_its_own_sheet_ignored_without_touching_the_shared_map():
    """A scope ruling about ONE workbook's sheet must not become a repo-wide fact.

    `9.PROC PSOC Strategy` is shipped only by the ovarian workbook. Putting it in the shared map's
    `ignored:` would have declared it non-requirement material for every product AND every later
    version at once — so the next ovarian revision would skip it in silence instead of asking again,
    which is precisely the state the ignored list exists to make impossible. IGNORE in the pack's own
    pipeline.conf scopes the ruling to the specification it was made about.

    The shared map stays what its header says it is: RWB's template, where a label means the same
    thing in every tumour.
    """
    import tempfile as _t

    with _t.TemporaryDirectory() as tmp:
        spec = Path(tmp)
        (spec / "6.Outcomes.md").write_text(
            "| Row | Variable Name | Definition |\n|---|---|---|\n| 10 | OS | overall survival |\n",
            encoding="utf-8")
        (spec / "9.PROC PSOC Strategy.md").write_text(
            "| Row | Variable Name | Definition |\n|---|---|---|\n"
            "| 4 | PSOC | platinum-sensitivity strategy |\n", encoding="utf-8")
        domains = {"6.outcomes": "outcomes"}

        # No ruling anywhere: the sheet is UNCLASSIFIED. Not skipped — nobody has looked at it.
        bare = spec_extract.extract(str(spec), domains)["extraction"]
        assert bare["unclassified_tabs"] == ["9.PROC PSOC Strategy"], bare["unclassified_tabs"]
        assert bare["product_ignored_tabs"] == []

        # The pack rules it out of scope. It stops being unclassified, and the fact is kept in the
        # ARTIFACT rather than reprinted on every run: a standing banner for a settled decision is
        # noise, and noise teaches a reader to skim past the UNCLASSIFIED line above it.
        ruled = spec_extract.extract(str(spec), domains,
                                     spec_extract.parse_ignore("9.PROC PSOC Strategy"))["extraction"]
        assert ruled["unclassified_tabs"] == []
        assert ruled["product_ignored_tabs"] == ["9.PROC PSOC Strategy"]

        # The ruling covers only what it names. Another unmapped sheet is still unclassified.
        (spec / "20.New Thing.md").write_text(
            "| Row | Variable Name | Definition |\n|---|---|---|\n| 2 | X | y |\n", encoding="utf-8")
        both = spec_extract.extract(str(spec), domains,
                                    spec_extract.parse_ignore("9.PROC PSOC Strategy"))["extraction"]
        assert both["unclassified_tabs"] == ["20.New Thing"], both["unclassified_tabs"]

        # Neither ruling touches what gets scanned: an ignored sheet was never requirement-bearing.
        assert bare["requirement_row_count"] == ruled["requirement_row_count"] == 1

    # The shared map must not carry the ovarian-only sheet — that is the whole point of the mechanism.
    shared = Path(REPO, "governance", "spec_sheet_map.yaml").read_text(encoding="utf-8")
    ignored = spec_extract.shared_sheet_map(str(REPO / "platform" / "tools")).get("ignored", {})
    assert "9.proc psoc strategy" not in ignored, \
        "the ovarian-only sheet is in the repo-wide ignored list — it would be excluded for every " \
        "product and every future version without anyone being asked again"
    assert "IGNORE" in shared, "the shared map no longer points at the per-pack mechanism"

    # Reported as a count on the skipped line, not a per-sheet banner. The record is pipeline.conf,
    # DECISIONS.md and extracted.json; the console owes the reader that a pack-level ruling EXISTS.
    src = Path(spec_extract.__file__).read_text(encoding="utf-8")
    assert "PRODUCT-IGNORED" not in src, "the standing per-sheet banner is back"
    assert "by this pack's IGNORE" in src, \
        "the skipped count no longer says any of it came from the pack's own ruling — a pack-level " \
        "exclusion is then indistinguishable from RWB's standing cover-and-changelog list"

    # And the pack that made the ruling records it where it can be found.
    pack = Path(REPO, "products", "oncology", "oc", "202606")
    conf = (pack / "spec_pipeline" / "pipeline.conf").read_text(encoding="utf-8")
    assert "9.PROC PSOC Strategy" in conf and "OC-PSOC-SHEET" in conf, \
        "the pack's IGNORE does not cite the decision that authorised it"

    # End to end, on the artifact the PIPELINE produced: declaring IGNORE in pipeline.conf is worth
    # nothing if the runner does not pass it on. Asserting extract() and the conf file separately left
    # exactly that gap — both passed with the runner's `--ignore` argument deleted.
    sys.path.insert(0, str(REPO / "platform" / "tools"))
    import run_spec_pipeline as rsp
    assert rsp.read_conf(str(pack / "spec_pipeline" / "pipeline.conf"))["IGNORE"] == \
        "9.PROC PSOC Strategy", "the runner does not parse IGNORE out of pipeline.conf"
    with open(pack / "spec_pipeline" / "out" / "extracted.json", encoding="utf-8") as fh:
        e = _json.load(fh)["extraction"]
    assert e["product_ignored_tabs"] == ["9.PROC PSOC Strategy"] and e["unclassified_tabs"] == [], \
        (f"the committed extraction does not carry the ruling — product_ignored_tabs="
         f"{e['product_ignored_tabs']}, unclassified_tabs={e['unclassified_tabs']}. The pipeline is "
         f"not passing the pack's IGNORE to spec_extract.")


def test_captured_child_stdout_is_utf8_whatever_the_locale():
    """The third platform-dependent byte: the ENCODING of a captured child's stdout.

    After the newline fix, six of seven artifacts matched across platforms and SPEC_FINDINGS.txt still
    drifted. It is the one artifact written by redirecting a child's stdout into a file, and the
    parent's `encoding="utf-8"` governs nothing there — the child writes to the fd itself and picks its
    encoding from the locale, the ANSI codepage on Windows. Its `—` and `•` became cp1252 0x97/0x95
    against UTF-8 three-byte sequences here, so `--check` reported drift on a file whose text was
    character-for-character identical.

    lint.json comes through the same redirect and never showed it, because json.dumps escapes
    non-ASCII by default. That is an accident of the writer, not a property of the path — the fix
    belongs on the path.
    """
    import subprocess
    import tempfile as _t

    sys.path.insert(0, str(REPO / "platform" / "tools"))
    import run_spec_pipeline as rsp

    extracted = REPO / "products" / "oncology" / "oc" / "202606" / "spec_pipeline" / "out" / "extracted.json"
    assert extracted.exists(), f"fixture extraction missing: {extracted}"
    cmd = [str(REPO / "platform" / "tools" / "spec_lint.py"), str(extracted), "--tumor", "ovarian"]

    def capture(env_extra):
        with _t.TemporaryDirectory() as tmp:
            p = os.path.join(tmp, "out.txt")
            with open(p, "w", encoding="utf-8") as fh:
                subprocess.run([sys.executable] + cmd, stdout=fh,
                               env=dict(os.environ, **env_extra))
            return Path(p).read_bytes()

    # The defect, reproduced: the same text, two byte sequences, chosen by the locale.
    assert capture({"PYTHONIOENCODING": "utf-8"}) != capture({"PYTHONIOENCODING": "cp1252"}), \
        "expected the cp1252 child to emit different bytes — the fixture no longer carries non-ASCII"

    # run() must pin it, so the locale cannot reach the file.
    with _t.TemporaryDirectory() as tmp:
        pinned = os.path.join(tmp, "findings.txt")
        os.environ["PYTHONIOENCODING"] = "cp1252"       # a Windows-like locale, hostile to the default
        try:
            rsp.run(cmd, out=pinned)
        finally:
            os.environ.pop("PYTHONIOENCODING", None)
        raw = Path(pinned).read_bytes()
    assert b"\xe2\x80\x94" in raw, \
        "captured stdout is not UTF-8 — run() no longer pins PYTHONIOENCODING, so the artifact's bytes " \
        "depend on the machine's codepage and --check reports drift on identical text"
    assert b"\x97" not in raw.replace(b"\xe2\x80\x94", b""), "a cp1252 em dash survived into the file"


def test_committed_artifacts_carry_no_platform_dependent_bytes():
    """The real-data half: every committed artifact must already be machine-neutral.

    `--check` is byte equality, so ANY byte that depends on who generated the file turns the drift
    signal into noise. Two such bytes exist and both have bitten: the line ending, and the path
    separator inside a recorded path. This asserts they are absent from what is actually committed,
    which the unit test above cannot — that one proves the normalizer works on a fixture, this one
    proves it was applied to the artifacts a reviewer will diff.
    """
    import glob

    packs = sorted(glob.glob(str(REPO / "products" / "*" / "*" / "*" / "spec_pipeline" / "out")))
    assert packs, "no pipeline packs discovered — this test would pass by sweeping nothing"

    crlf, backslash = [], []
    for out in packs:
        for p in sorted(glob.glob(os.path.join(out, "*"))):
            if b"\r\n" in Path(p).read_bytes():
                crlf.append(os.path.relpath(p, str(REPO)))
        # Recorded paths, the other platform-dependent byte. repo_relative() forces forward slashes;
        # a writer bypassing it emits `products\oncology\...` and every Linux checkout reads drift.
        for name, keys in ((("extracted.json"), ("extraction", "target")),
                           (("scaffold.json"), ("scaffold", "product"))):
            f = os.path.join(out, name)
            if os.path.exists(f):
                with open(f, encoding="utf-8") as fh:
                    v = _json.load(fh)[keys[0]][keys[1]]
                if "\\" in v:
                    backslash.append(f"{os.path.relpath(f, str(REPO))}: {v}")

    assert not crlf, (f"CRLF in generated artifact(s): {crlf}. These were written on a platform whose "
                      f"text mode translates newlines and not normalized — every checkout on another "
                      f"platform will report drift on files nobody touched.")
    assert not backslash, (f"platform path separator recorded in {backslash} — write it through "
                           f"spec_extract.repo_relative()")


def test_the_scaffold_emits_the_format_the_contract_actually_stores():
    """The hand-off format must be the stored format, and it was not.

    The contract moved to a markdown table and `contract_lint.records()` made the table current with
    fenced ```yaml as legacy — but the scaffold kept emitting fenced blocks. So the pipeline's own
    output was the one shape the lint calls legacy, and a fenced record pasted UNDER a table is not
    read at all, because the table wins. `mixed_format_error` reports that rather than losing it, so
    it was friction rather than silent loss; a hand-off format the lint objects to is still the
    stand-in risk the pipeline exists to remove.

    Round-tripped through the real reader rather than pattern-matched, because what matters is not
    that the output looks like a table but that `records()` gets the same fields back out.
    """
    sys.path.insert(0, str(REPO / "platform" / "tools"))
    import contract_lint as cl
    import contract_scaffold as cs

    rec = {"variable_id": "AGE", "spec_refs": ["demographics:9"], "spec_digest": "abc123",
           # a literal pipe would end the cell, and a newline would end the ROW
           "required_rule": "year(index) - birthyear | with a pipe",
           "notes": "line one\nline two",
           "status": {"requirement": "draft", "source": "unverified",
                      "implementation": "not_implemented", "validation": "not_run"},
           "lint_flags": ["VERIFY_MARKER: x"], "spec_columns": [["Label", "Age"]]}
    out = cs.to_contract_records([rec])

    assert "```yaml" not in out, "the scaffold is emitting the legacy fenced form again"
    assert not cl.mixed_format_error(out, "SCAFFOLDED_RECORDS.md"), "output is mixed-format"

    blocks = list(cl.records(out))
    assert len(blocks) == 1, f"the lint read {len(blocks)} records out of one row"
    b = blocks[0]
    assert cl._scalar(b, "required_rule") == "year(index) - birthyear | with a pipe", \
        "the pipe escape did not round-trip — every field after it would shift one column"
    assert cl._scalar(b, "notes") == "line one line two", "a newline broke the row in two"
    # contract_binding demands a reference the moment a record claims output; TODO fails it on paste.
    assert cl._scalar(b, "implementation_refs") == "[none]"

    # Guidance is NOT contract content and must sit outside the pasteable rows.
    table, _, guidance = out.partition("## Row notes")
    assert guidance, "per-row guidance disappeared"
    assert "VERIFY_MARKER" in guidance and "VERIFY_MARKER" not in table, \
        "lint flags are inside the table — they would be pasted into the governed contract"


def test_the_record_key_order_has_one_definition():
    """`contract_scaffold.CANON_ORDER` was a hand-maintained copy of `contract_lint.CANON`, identical
    to it — which is exactly when a duplicate is invisible. The field set and its order belong to the
    module whose invariants check them; anything else is two definitions of one concept waiting to
    disagree on the first field anybody adds."""
    sys.path.insert(0, str(REPO / "platform" / "tools"))
    import contract_lint as cl
    import contract_scaffold as cs

    assert cl.TABLE_COLUMNS[0] == "variable_id"
    assert cl.TABLE_COLUMNS[1:-1] == cl.CANON, "TABLE_COLUMNS drifted from CANON"
    assert cl.TABLE_COLUMNS[-1] == "implementation_refs", \
        "implementation_refs must trail CANON — the record lint does not require it, the binder does"
    assert cs.CANON_ORDER == list(cl.TABLE_COLUMNS[:-1]), \
        "the scaffold restated the key order instead of deriving it"

    # And the escape rule has one home: writer beside reader.
    for raw in ("a | b", "plain", "a\nb", "x \\| y"):
        assert cl._unpipe(cl.pipe(raw)) == re.sub(r"\s*\n\s*", " ", raw).strip(), raw


def test_the_legacy_ratchet_counts_spec_rows_not_record_names():
    """Splitting a record must not move the ratchet; resolving one must.

    The allowlist keyed on variable_id, so splitting `LAB` into its 31 per-analyte records tripled
    the count (19 -> 51) while the SPEC ROWS behind them went down (53 -> 50). A pure rename read as
    32 new violations, and the only way to pass was to grow a file whose entire purpose is that it
    cannot grow. What is being ratcheted down is how much of the SPECIFICATION is still on a mapping
    nobody can verify per column — so that is what it counts.
    """
    import tempfile as _t
    sys.path.insert(0, str(REPO / "platform" / "tools"))
    import source_check

    FAMILY = ("| variable_id | spec_refs | source |\n|---|---|---|\n"
              "| LAB | [clinical:17-19] | {logical_table: \"lab + vitals\", columns: {v: val}} |\n")
    SPLIT = ("| variable_id | spec_refs | source |\n|---|---|---|\n"
             "| LABNEU | [clinical:17] | {logical_table: \"lab + vitals\", columns: {v: val}} |\n"
             "| LABNEUV | [clinical:18] | {logical_table: \"lab + vitals\", columns: {v: val}} |\n"
             "| LABNEUDT | [clinical:19] | {logical_table: \"lab + vitals\", columns: {v: val}} |\n")
    RESOLVED = ("| variable_id | spec_refs | source |\n|---|---|---|\n"
                "| LABNEU | [clinical:17] | {kind: vendor, inputs: {t_lab: {v: val}}} |\n"
                "| LABNEUV | [clinical:18] | {logical_table: \"lab + vitals\", columns: {v: val}} |\n"
                "| LABNEUDT | [clinical:19] | {logical_table: \"lab + vitals\", columns: {v: val}} |\n")

    def rows(contract):
        with _t.TemporaryDirectory() as tmp:
            pack = Path(tmp, "p")
            (pack / "handoff").mkdir(parents=True)
            (pack / "handoff" / "FUNCTIONAL_CONTRACT.md").write_text(contract, encoding="utf-8")
            return set(source_check.legacy_ratchet(str(pack))[0])

    family, split = rows(FAMILY), rows(SPLIT)
    assert family == {"clinical:17", "clinical:18", "clinical:19"}, family
    assert split == family, f"splitting moved the ratchet: {family} -> {split}"

    # ...and stating where a column comes from is the ONE thing that drops it
    assert rows(RESOLVED) == {"clinical:18", "clinical:19"}, rows(RESOLVED)

    # provenance is not ambiguity: a structured record keeping the stem the SPEC names is not legacy
    keeps_stem = ("| variable_id | spec_refs | source |\n|---|---|---|\n"
                  "| X | [clinical:1] | {kind: vendor, physical_stem: t_named, "
                  "inputs: {t_named: {v: val}}} |\n")
    assert rows(keeps_stem) == set(), rows(keeps_stem)


def test_a_registered_path_must_exist_at_every_status():
    """"Gate 1 passed" has to mean the registered material is FINDABLE.

    Existence used to be checked only at `reviewed`, so a pack whose workbook filename was mistyped
    reported OK — and the failure surfaced later out of run_spec_pipeline.sh, where it reads as a
    pipeline fault rather than the registration error it is. A pending material with no local file is
    still fine: `TBD …` and http(s) links are the normal shape while a document is being obtained.
    """
    import tempfile as _t
    with _t.TemporaryDirectory() as tmp:
        prod = _pack(tmp, "draft")
        (prod / "Reference" / "Program Specification").mkdir(parents=True)
        wb = prod / "Reference" / "Program Specification" / "SPEC.xlsx"
        wb.write_bytes(b"the workbook")
        base = {"role": "program spec", "status": "pending", "material_type": "program_spec",
                "ai_classification": "sponsor_ai_eligible", "classified_by": "R. Classifier",
                "classified_date": "2026-07-28", "why_provisional": "no revision recorded yet"}

        _refs(prod, dict(base, path_or_link=f"{REL}/Reference/Program Specification/SPEC.xlsx"))
        assert source_manifest.check(tmp, REL) == [], "the workbook is right there"

        _refs(prod, dict(base, path_or_link=f"{REL}/Reference/Program Specification/SPEK.xlsx"))
        errs = source_manifest.check(tmp, REL)
        assert any("does not exist" in e for e in errs), errs

        # Not yet in the repo is a legitimate PENDING state, and must stay clean.
        for off_disk in ("TBD — link to follow", "https://example.invalid/spec.xlsx"):
            _refs(prod, dict(base, path_or_link=off_disk))
            assert source_manifest.check(tmp, REL) == [], off_disk


def test_a_reviewed_material_must_carry_its_approval_fields():
    """`reviewed` is the claim "someone approved this". Without a revision, checksum, date and approver
    it is an adjective, not a record."""
    import tempfile as _t
    with _t.TemporaryDirectory() as tmp:
        prod = _pack(tmp, "draft")
        _refs(prod, {"path_or_link": "TBD", "role": "program spec", "status": "reviewed"})
        errs = source_manifest.check(tmp, REL)
        for field in source_manifest.APPROVAL_FIELDS:
            assert any(f"`{field}`" in e for e in errs), f"{field} not required: {errs}"


def test_contract_cannot_be_approved_on_a_provisional_source():
    import tempfile as _t
    with _t.TemporaryDirectory() as tmp:
        prod = _pack(tmp, "approved")
        _refs(prod, {"path_or_link": "TBD", "role": "a scan", "status": "pending",
                     "why_provisional": "not signed"})
        errs = source_manifest.check(tmp, REL)
        assert any("cannot be approved against a specification that is not" in e for e in errs), errs


def test_a_pack_with_a_contract_and_no_source_refs_is_an_error():
    import tempfile as _t
    with _t.TemporaryDirectory() as tmp:
        _pack(tmp, "draft")
        errs = source_manifest.check(tmp, REL)
        assert any("must record what specification" in e for e in errs), errs


def test_the_pipeline_extracts_a_registered_material():
    """pipeline.conf named its own path, so "what was approved" and "what was extracted" were two
    facts nothing reconciled — a pack could approve workbook A and extract workbook B."""
    import tempfile as _t
    with _t.TemporaryDirectory() as tmp:
        prod = _pack(tmp, "draft")
        (prod / "spec_pipeline").mkdir()
        _refs(prod, {"path_or_link": "TBD", "role": "spec", "status": "pending",
                     "why_provisional": "not signed"})

        (prod / "spec_pipeline" / "pipeline.conf").write_text("TUMOR=x\nSPEC_SOURCE_ID=elsewhere\n")
        assert any("not a material_id" in e for e in source_manifest.check(tmp, REL))

        (prod / "spec_pipeline" / "pipeline.conf").write_text('TUMOR=x\nSPEC_SOURCE="some/path.xlsx"\n')
        assert any("sets no SPEC_SOURCE_ID" in e for e in source_manifest.check(tmp, REL)), \
            "a pipeline.conf that still names a path must be rejected"

        (prod / "spec_pipeline" / "pipeline.conf").write_text("TUMOR=x\nSPEC_SOURCE_ID=program_spec\n")
        assert source_manifest.check(tmp, REL) == []
        assert source_manifest.resolve(str(prod), "program_spec") == "TBD"


def test_every_material_states_whether_ai_may_read_it():
    """The field the whole AI boundary rests on was, in practice, required nowhere.

    It was demanded only of a REVIEWED program_spec — and no pack in this repo has a reviewed
    material, so no material carries a classification and nothing ever asked for one. That is the
    exact fail-open shape governance/WORKFLOW.md §"Eligibility" is built to prevent: eligibility
    follows the content's recorded classification, and an unrecorded one is an unanswered question,
    not a default.

    Required while `pending` too, which is what separates it from every other Gate 1 field. Those
    record a review that has not happened; this one follows from who authored the content and is
    knowable at registration. A material can be unapproved for months; it is never unclassified.
    """
    import tempfile as _t
    with _t.TemporaryDirectory() as tmp:
        prod = _pack(tmp, "draft")
        pending = {"path_or_link": "TBD", "role": "spec", "status": "pending",
                   "why_provisional": "not yet supplied"}

        _refs(prod, {**pending, "ai_classification": None})
        assert any("requires `ai_classification`" in e for e in source_manifest.check(tmp, REL)), \
            "a pending material with no classification must not pass Gate 1"

        # ...and a value outside the vocabulary is not a classification either. Free text here would
        # let "internal use ok" or "n/a" stand where a governed enum is what the boundary reads.
        _refs(prod, {**pending, "ai_classification": "probably fine"})
        assert any("is not one of" in e for e in source_manifest.check(tmp, REL))

        for ok in source_manifest.AI_CLASSES:
            _refs(prod, {**pending, "ai_classification": ok})
            assert source_manifest.check(tmp, REL) == [], ok

        # A SUPPORTING material is held to it too — vendor reference material is precisely what must
        # never be ingested, and it is the material type least likely to be looked at closely.
        _refs(prod, pending, {"material_id": "dict", "material_type": "supporting",
                              "path_or_link": "TBD", "role": "vendor data dictionary",
                              "status": "pending", "why_provisional": "vendor-delivered",
                              "ai_classification": None})
        assert any("requires `ai_classification`" in e for e in source_manifest.check(tmp, REL))


def test_a_classification_names_who_made_it_and_when():
    """The verdict was recorded without its author — the one shape this repo refuses everywhere else.

    CONTRACT_APPROVAL.yaml names an approver and a date; a Gate 3 verdict names the profile it read; a
    reviewed material names who approved it. `ai_classification` decides what AI may read at all and
    carried no attribution, so there was nobody to ask when the judgment was questioned and no way to
    tell a considered call from a value pasted in to make CI pass.

    The date is not decoration. A material's provenance can change — a workbook revised to quote a
    vendor dictionary, a stand-in re-cut from a delivered extract — and a classification made
    before that change was made about a different document.
    """
    import tempfile as _t
    with _t.TemporaryDirectory() as tmp:
        prod = _pack(tmp, "draft")
        ok = {"path_or_link": "TBD", "role": "spec", "status": "pending",
              "why_provisional": "not yet supplied", "ai_classification": "sponsor_ai_eligible",
              "classified_by": "R. Classifier", "classified_date": "2026-07-27"}
        _refs(prod, ok)
        assert source_manifest.check(tmp, REL) == [], source_manifest.check(tmp, REL)

        for field in source_manifest.CLASSIFICATION_FIELDS:
            for blank in (None, "TBD", "REPLACE_ME"):
                _refs(prod, {**ok, field: blank})
                said = source_manifest.check(tmp, REL)
                assert any(f"requires `{field}`" in e for e in said), (field, blank, said)
                # ONE message per defect. `classified_date` is both required and date-checked, and
                # bad_date calls a placeholder "not set" too — so an unfilled one reported twice,
                # the same shape as the I9/I13 duplication. Only approval_date hid it, by never
                # being required while no pack is `reviewed`.
                assert len([e for e in said if field in e]) == 1, (field, blank, said)

        # The date is a DATE, held to the same predicate every other gate uses. `2026-13-45` never
        # reaches bad_date: PyYAML resolves an ISO-shaped scalar to a datetime.date and raises on an
        # impossible one, so it is refused as unreadable YAML — which used to come out of Gate 1 as a
        # bare traceback naming neither the file nor the field. Refused either way, and now SAID
        # either way; assert the refusal, not which layer produced it.
        for bad in ("last July", "yesterday", "2026-13-45"):
            _refs(prod, {**ok, "classified_date": bad})
            said = source_manifest.check(tmp, REL)
            assert any("classified_date" in e or "not readable YAML" in e for e in said), (bad, said)


def test_a_derived_extraction_input_must_name_its_source():
    """A stand-in is not the approved specification because it is internally consistent."""
    import tempfile as _t
    with _t.TemporaryDirectory() as tmp:
        prod = _pack(tmp, "draft")
        spec = {"path_or_link": "TBD", "role": "spec", "status": "pending",
                "why_provisional": "not yet supplied"}
        tabs = {"material_id": "tabs", "material_type": "extraction_input", "path_or_link": "TBD",
                "role": "stand-in", "status": "pending", "why_provisional": "not attested"}
        _refs(prod, spec, tabs)
        assert any("requires `derived_from`" in e for e in source_manifest.check(tmp, REL))

        # A derivative must stand in for the AUTHORITATIVE document, not for any registered material:
        # otherwise a chain of derivatives can end somewhere nobody approved, each link looking legal.
        _refs(prod, spec, {**tabs, "derived_from": "nonexistent"})
        assert any("is not the authoritative program_spec" in e for e in source_manifest.check(tmp, REL))

        _refs(prod, spec, {**tabs, "derived_from": "program_spec"})
        assert source_manifest.check(tmp, REL) == []


def test_only_the_program_spec_decides_the_source_status():
    """`any reviewed material` would let a reviewed methodology note or supplemental file make a pack
    look source-approved while the specification itself was still pending."""
    import tempfile as _t
    with _t.TemporaryDirectory() as tmp:
        prod = _pack(tmp, "draft")
        _refs(prod,
              {"path_or_link": "TBD", "role": "spec", "status": "pending",
               "why_provisional": "not yet supplied"},
              {"material_id": "methodology", "material_type": "supporting", "path_or_link": "TBD",
               "role": "methodology note", "status": "reviewed", "document_id": "M-1",
               "revision": "r1", "sha256": "a" * 64, "approval_date": "2026-01-01",
               "approved_by": "J.S."})
        assert source_manifest.source_status(str(prod)) == "provisional"

        # ...and two documents may not both claim to be the specification.
        _refs(prod,
              {"path_or_link": "TBD", "role": "spec", "status": "pending", "why_provisional": "a"},
              {"material_id": "other_spec", "material_type": "program_spec", "path_or_link": "TBD",
               "role": "spec", "status": "pending", "why_provisional": "b"})
        assert any("exactly one authoritative specification" in e
                   for e in source_manifest.check(tmp, REL))


def test_a_blank_cell_with_a_structural_cause_is_reported():
    """A cell can be blank because the spec says nothing, or because a formula has no cached result or
    a merge swallowed it. Those read identically, and the row still becomes a spec item — so a contract
    gets written from a rule that silently is not there."""
    import tempfile as _t
    openpyxl = pytest_importorskip("openpyxl")
    from openpyxl.worksheet.datavalidation import DataValidation
    with _t.TemporaryDirectory() as tmp:
        path = os.path.join(tmp, "wb.xlsx")
        wb = openpyxl.Workbook(); ws = wb.active; ws.title = "8.Outcomes"
        ws.append(["Variable", "Label", "Definition", "QC (initials)"])
        ws.append(["OS", "Overall survival", '=CONCATENATE("months from ","INDEXDT")', ""])
        ws.append(["RETIRED", "retired row", "a rule nobody can see in Excel", ""])
        ws.append(["PFS", "PFS", "swallowed by the merge", ""])
        ws.append(["BANNER", "banner row", "fine", ""])
        ws.row_dimensions[3].hidden = True
        ws.column_dimensions["D"].hidden = True       # a hidden QC column shadows nothing
        ws.merge_cells("B4:C4")                       # partial: deletes Definition for that row
        ws.merge_cells("A5:D5")                       # full width: a title banner, swallows nothing
        dv = DataValidation(type="list", formula1='"0,1,2,3,4"')
        ws.add_data_validation(dv); dv.add(ws["C2"])
        wb.save(path)

        s = spec_extract.workbook_structure(path)["8.Outcomes"]
        assert s["formula_no_value"] == ["C2"], s
        assert s["hidden_rows"] == [3], s
        assert s["merged"] == ["B4:C4"], "a full-width banner is not a column-swallowing merge"
        assert "shadowing_cols" not in s, "a hidden column that names no field loses nothing"
        assert s["validation_lists"], "a dropdown holds the value list and no cell does"

        data = spec_extract.extract(path, {"8.outcomes": "outcomes"})
        kinds = {(f["severity"], f["kind"]) for f in spec_lint.scan(data)}
        assert ("HIGH", "WORKBOOK_STRUCTURE") in kinds
        # ...and none of it fires on a sheet that carries no requirements.
        assert not spec_lint.scan_structure({"extraction": {"workbook_structure": {"1.Cover": s}},
                                             "rows": []})


def test_a_hidden_column_that_shadows_a_field_is_high_severity():
    """Measured, not assumed: a hidden `Definition (superseded)` column sitting left of the visible one
    supplies the rule, because the first matching column wins. The contract then states a rule nobody
    can see in Excel. A hidden QC column, by contrast, loses nothing and must stay silent."""
    import tempfile as _t
    openpyxl = pytest_importorskip("openpyxl")
    with _t.TemporaryDirectory() as tmp:
        path = os.path.join(tmp, "wb.xlsx")
        wb = openpyxl.Workbook(); ws = wb.active; ws.title = "8.Outcomes"
        ws.append(["Variable", "Definition (superseded)", "Definition", "Additional Notes"])
        ws.append(["OS", "THE STALE RULE", "the current rule", ""])
        ws.column_dimensions["B"].hidden = True
        wb.save(path)
        data = spec_extract.extract(path, {"8.outcomes": "outcomes"})
        assert data["rows"][0]["fields"]["definition"] == "THE STALE RULE", \
            "if this changes the resolver changed; the finding below is what makes it visible"
        hits = [f for f in spec_lint.scan(data) if f["kind"] == "WORKBOOK_STRUCTURE"]
        assert [f["severity"] for f in hits] == ["HIGH"] and "superseded" in hits[0]["detail"]


def pytest_importorskip(name):
    try:
        return __import__(name)
    except ImportError:                                            # pragma: no cover
        import pytest
        pytest.skip(f"{name} not installed")


def test_claiming_contract_approved_requires_every_record_to_be_settled():
    """The top of the maturity ladder was the rung nothing checked. `coverage_complete` is enforced by
    --strict and Gate 1 refuses `approved` on an unapproved source, but nothing read the records — so a
    pack could claim the workflow's Gate 2 exit with half its contract still draft."""
    import tempfile as _t
    import contract_lint
    RECORD = ("```yaml\nvariable_id: %s\nspec_refs: [clinical:1]\n"
              "status: {requirement: %s, source: unverified, implementation: not_implemented, "
              "validation: not_run}\ndecision_ids: []\ngap_ids: []\n```\n")
    with _t.TemporaryDirectory() as tmp:
        prod = Path(tmp) / "products" / "oncology" / "x" / "202601"
        (prod / "handoff").mkdir(parents=True)
        (prod / "handoff" / "FUNCTIONAL_CONTRACT.md").write_text(
            RECORD % ("AGE", "approved") + RECORD % ("SEX", "draft"))
        (prod / "handoff" / "MATURITY.yaml").write_text("contract: coverage_complete\n")
        errs, _ = contract_lint.run(str(prod), {"decisions": 0, "gaps": 0, "records": 0})
        assert not [e for e in errs if "I14" in e], "I14 must not fire below the approved claim"

        (prod / "handoff" / "MATURITY.yaml").write_text("contract: approved\n")
        errs, _ = contract_lint.run(str(prod), {"decisions": 0, "gaps": 0, "records": 0})
        assert [e for e in errs if "I14" in e and "SEX" in e], errs


def test_strict_fails_when_extraction_may_not_have_read_the_source():
    """`--strict` counted items without asking whether the extractor READ them.

    The distinction that keeps coverage_complete meaningful: an impossible date is a defect IN the
    document — capturable, citable, answerable by a decision — and must not block coverage. A sheet
    whose Definition column never resolved is different: coverage would report 100% over items whose
    text was never located.
    """
    import tempfile as _t
    openpyxl = pytest_importorskip("openpyxl")
    with _t.TemporaryDirectory() as tmp:
        path = os.path.join(tmp, "wb.xlsx")
        wb = openpyxl.Workbook(); ws = wb.active; ws.title = "8.Outcomes"
        ws.append(["Col1", "Col2", "Col3"])                    # header names nothing recognisable
        ws.append(["OS", "Overall survival", "months from INDEXDT to death"])
        wb.save(path)
        data = spec_extract.extract(path, {"8.outcomes": "outcomes"})
        issues = contract_scaffold.extraction_integrity(data, [], None)
        assert any("positional guess" in i for i in issues), issues

        # A TABS override under strict means coverage over PART of the specification.
        assert any("TABS override" in i
                   for i in contract_scaffold.extraction_integrity(data, [], ["8.Outcomes"]))

        # A spec DEFECT is not an integrity failure — it belongs in QC and decisions, not here.
        defect = [{"kind": "IMPOSSIBLE_DATE", "severity": "HIGH", "tab": "8.Outcomes", "detail": "x"}]
        assert contract_scaffold.extraction_integrity(
            spec_extract.extract(path, {}), defect, None) == []


def test_a_rule_edited_in_place_invalidates_the_record_written_from_it():
    """The failure this exists for, reproduced: RWB flips ECOG's same-day tie-break from `highest` to
    `lowest` on the SAME row. The row still exists, the citation still resolves, coverage still maps
    it — all fourteen other invariants passed while the contract said the opposite of the spec."""
    import contract_lint
    srows = {"clinical": {47: "aaaa", 48: "bbbb"}}
    block = "variable_id: ECOG\nspec_refs: [clinical:47-48]\nspec_digest: %s\n"
    d = contract_lint.spec_digest(["clinical:47-48"], srows)
    assert d and len(d) == 12

    # The digest covers CONTENT, so an in-place edit moves it while the citation is untouched.
    edited = {"clinical": {47: "aaaa", 48: "cccc"}}
    assert contract_lint.spec_digest(["clinical:47-48"], edited) != d

    # Order of citation is part of it: two records citing the same rows differently are different.
    assert (contract_lint.spec_digest(["clinical:48", "clinical:47"], srows)
            != contract_lint.spec_digest(["clinical:47", "clinical:48"], srows))

    # A record that cites nothing carries n/a rather than a fabricated hash.
    assert contract_lint.spec_digest([contract_lint.NO_SPEC_ROW], srows) == contract_lint.NA
    # An unresolvable citation yields no digest at all, so I15 stays silent and I8 reports it.
    assert contract_lint.spec_digest(["clinical:99"], srows) is None
    assert block  # documents the shape the lint reads


def test_scaffolded_digests_are_what_the_lint_recomputes():
    """The scaffold and the lint must not be two implementations of one hash: a scaffold hashing its
    own way would emit a digest the lint rejects, and every freshly scaffolded record would fail."""
    import contract_lint
    for pack in ("products/oncology/prostate/202606", "products/oncology/oc/202606"):
        path = REPO / pack / "spec_pipeline" / "out" / "SCAFFOLDED_RECORDS.md"
        if not path.exists():
            continue
        srows = contract_lint.spec_rows(str(REPO / pack))
        for block in contract_lint.records(path.read_text(encoding="utf-8")):
            recorded = contract_lint._scalar(block, "spec_digest")
            current = contract_lint.spec_digest(contract_lint._list(block, "spec_refs") or [], srows)
            assert recorded == current, f"{pack}: scaffold emitted {recorded}, lint computes {current}"


def test_the_contract_yaml_binding_checks_both_directions():
    """PILOT guard. Both directions fail differently and both must bite: a record pointing at config
    that does not exist, and config governing the build that no record claims. The second is the one
    nobody checks, because the build works either way."""
    import tempfile as _t
    import contract_binding
    with _t.TemporaryDirectory() as tmp:
        pack = Path(tmp) / "pack"
        (pack / "handoff").mkdir(parents=True)
        (pack / "variables").mkdir()
        (pack / "variables" / "demo.yaml").write_text(
            "pack_id: demo\nowner: RWP\nage_bands: [{code: 1}]\nregions: [{code: 1}]\n")
        (pack / "handoff" / "FUNCTIONAL_CONTRACT.md").write_text(
            "```yaml\nvariable_id: AGEGR1\n"
            "implementation_refs: [variables/demo.yaml#/age_bands]\n"
            "status: {requirement: draft, source: unverified, implementation: implemented, "
            "validation: not_run}\n```\n")
        errs, stats = contract_binding.check(str(pack), ["variables/demo.yaml"])
        assert {k: stats[k] for k in ("records", "produces", "annotated", "blocks", "claimed")} == \
            {"records": 1, "produces": 1, "annotated": 1, "blocks": 2, "claimed": 1}
        # `regions` governs the build and no record asked for it.
        assert any("#/regions" in e and "claimed by no contract record" in e for e in errs), errs
        # pack metadata is not behaviour, so it is not something a record has to claim
        assert not any("pack_id" in e or "owner" in e for e in errs), errs

    with _t.TemporaryDirectory() as tmp:
        pack = Path(tmp) / "pack"
        (pack / "handoff").mkdir(parents=True)
        (pack / "variables").mkdir()
        (pack / "variables" / "demo.yaml").write_text("pack_id: demo\nage_bands: [{code: 1}]\n")
        (pack / "handoff" / "FUNCTIONAL_CONTRACT.md").write_text(
            "```yaml\nvariable_id: AGEGR1\n"
            "implementation_refs: [variables/demo.yaml#/agebands, engine:not_a_real_function]\n"
            "status: {requirement: draft, source: unverified, implementation: implemented, "
            "validation: not_run}\n```\n")
        errs, _ = contract_binding.check(str(pack), ["variables/demo.yaml"])
        assert any("does not define" in e for e in errs), errs
        assert any("not a function the shared engine defines" in e for e in errs), errs

    # The engine is located from the TOOL, not the product: a pack outside a checkout used to report
    # every engine ref as broken, which is a check failing because it cannot see.
    assert contract_binding.engine_symbols(), "engine symbols must resolve from the tool's own location"


def test_an_open_decision_can_account_for_config_no_record_claims():
    """A block nobody claims is not automatically wrong — it may be a question already raised. Same
    distinction the disposition register makes for spec items. Close the decision and it comes back."""
    import tempfile as _t
    import contract_binding
    with _t.TemporaryDirectory() as tmp:
        pack = Path(tmp) / "pack"
        (pack / "handoff").mkdir(parents=True)
        (pack / "variables").mkdir()
        (pack / "variables" / "clinical.yaml").write_text("pack_id: d\nbiomarkers: {panel: [x]}\n")
        (pack / "handoff" / "FUNCTIONAL_CONTRACT.md").write_text(
            "```yaml\nvariable_id: AGE\nimplementation_refs: [engine:build]\n"
            "status: {requirement: draft, source: unverified, implementation: implemented, "
            "validation: not_run}\n```\n")
        cover = ["variables/clinical.yaml"]

        errs, _ = contract_binding.check(str(pack), cover)
        assert any("#/biomarkers" in e for e in errs), errs

        (pack / "handoff" / "DECISIONS.md").write_text(
            "| ID | Question | Evidence | Owner | Answer | Status |\n|---|---|---|---|---|---|\n"
            "| BIO-KEEP | Keep it? | `variables/clinical.yaml#/biomarkers` unclaimed | RWB | — | OPEN |\n")
        errs, stats = contract_binding.check(str(pack), cover)
        assert not [e for e in errs if "#/biomarkers" in e], errs
        assert stats["questioned"] == 1

        # RESOLVED stops covering it: an answered question is not an open one.
        (pack / "handoff" / "DECISIONS.md").write_text(
            (pack / "handoff" / "DECISIONS.md").read_text().replace("| OPEN |", "| RESOLVED |"))
        errs, _ = contract_binding.check(str(pack), cover)
        assert any("#/biomarkers" in e for e in errs), errs


def test_enumeration_comparison_reports_both_directions_and_decides_nothing():
    """The earlier version of this test asserted its own title: it named both directions and only
    checked that the pack's current differences were the two expected ones. It would have passed with
    the YAML-only direction never implemented — which is exactly what had happened.
    """
    import contract_binding as cb

    labels, pairs, members = cb.flatten_values(
        {"panel": [{"code": 1, "label": "Positive"}, {"code": 3, "label": "VUS"}],
         "states": ["ME", "VT"], "when": "fallthrough"})
    assert labels == {"positive", "vus"} and pairs == {"1": "positive", "3": "vus"}
    # A bare string is a MEMBER only inside a list; `when: fallthrough` is a setting, not a value.
    assert members == {"me", "vt"}, members

    import tempfile as _t
    SPEC = ("enumerations:\n  region1:\n    spec_ref: demographics:14\n    kind: membership\n"
            "    values:\n      - {label: Northeast, members: [ME, VT]}\n"
            "      - {label: South, members: [TX]}\n")

    def pack(tmp, yaml_block):
        d = Path(tmp) / "pack"
        (d / "handoff").mkdir(parents=True)
        (d / "variables").mkdir()
        (d / "spec_pipeline" / "out").mkdir(parents=True)
        (d / "spec_pipeline" / "out" / "ENUMERATION_CANDIDATES.yaml").write_text(SPEC)
        (d / "variables" / "demo.yaml").write_text("pack_id: d\nregions:\n" + yaml_block)
        (d / "handoff" / "FUNCTIONAL_CONTRACT.md").write_text(
            "```yaml\nvariable_id: REGION1\nspec_refs: [demographics:10-20]\n"
            "implementation_refs: [variables/demo.yaml#/regions]\n"
            "status: {requirement: draft, source: unverified, implementation: implemented, "
            "validation: not_run}\n```\n")
        return str(d), cb.governed_blocks(str(d), ["variables/demo.yaml"])

    match = "  - {code: 1, label: Northeast, states: [ME, VT]}\n  - {code: 2, label: South, states: [TX]}\n"
    with _t.TemporaryDirectory() as tmp:
        d, blocks = pack(tmp, match)
        # The citation is a RANGE. Keying on the literal string would say nothing binds the row.
        assert cb.compare_enumerations(d, blocks) == []

    with _t.TemporaryDirectory() as tmp:                      # YAML-only member — the direction missed
        d, blocks = pack(tmp, match.replace("[ME, VT]", "[ME, VT, XX]"))
        diffs = cb.compare_enumerations(d, blocks)
        assert any("adds member(s) ['xx']" in x for x in diffs), diffs

    with _t.TemporaryDirectory() as tmp:                      # spec-only member
        d, blocks = pack(tmp, match.replace("[ME, VT]", "[ME]"))
        assert any("member(s) ['vt'] the approved YAML does not" in x
                   for x in cb.compare_enumerations(d, blocks))

    # Codes re-pointed at different labels. Only checkable when the SPEC states codes — for REGION1 it
    # does not ("numeric_codes: not_stated_by_the_spec"), so the swap above is silent by design and a
    # numeric_map candidate is what exercises it.
    with _t.TemporaryDirectory() as tmp:
        d, blocks = pack(tmp, "  - {code: 1, label: Positive}\n  - {code: 2, label: Negative}\n")
        Path(d, "spec_pipeline", "out", "ENUMERATION_CANDIDATES.yaml").write_text(
            "enumerations:\n  region1:\n    spec_ref: demographics:14\n    kind: numeric_map\n"
            "    values:\n      - {code: 1, label: Positive}\n      - {code: 2, label: Negative}\n")
        assert cb.compare_enumerations(d, blocks) == [], "identical code maps must be silent"

        Path(d, "variables", "demo.yaml").write_text(
            "pack_id: d\nregions:\n  - {code: 2, label: Positive}\n  - {code: 1, label: Negative}\n")
        blocks = cb.governed_blocks(d, ["variables/demo.yaml"])
        diffs = cb.compare_enumerations(d, blocks)
        assert any("mapped to a different label" in x for x in diffs), diffs

    # The live pack: every remaining difference is accounted for, so CI can fail on the rest.
    live = REPO / "products" / "oncology" / "prostate" / "202606"
    if (live / "spec_pipeline" / "out" / "ENUMERATION_CANDIDATES.yaml").exists():
        blocks = cb.governed_blocks(str(live), cb.pack_yaml(str(live)))
        assert cb.compare_enumerations(str(live), blocks) == []


def test_the_row_digest_covers_which_cell_means_what():
    """I15 claims a record is bound to the TEXT it was written from. Over the cell join alone, swapping
    the `Definition` and `Additional Notes` headers left the row byte-identical while the cell the
    contract reads as the derivation changed — an enforced control overstating what it checks."""
    import tempfile as _t
    openpyxl = pytest_importorskip("openpyxl")
    with _t.TemporaryDirectory() as tmp:
        def row(headers, name):
            path = os.path.join(tmp, name)
            wb = openpyxl.Workbook(); ws = wb.active; ws.title = "8.Outcomes"
            ws.append(headers)
            ws.append(["OS", "months from INDEXDT to death", "check with RWB"])
            wb.save(path)
            return spec_extract.extract(path, {"8.outcomes": "outcomes"})["rows"][0]

        a = row(["Variable", "Definition", "Additional Notes"], "a.xlsx")
        b = row(["Variable", "Additional Notes", "Definition"], "b.xlsx")
        assert a["text"] == b["text"], "the cell text is identical — that is the point"
        assert a["fields"]["definition"] != b["fields"]["definition"]
        assert a["content_hash"] != b["content_hash"], "the digest must follow the field map too"


def test_the_binder_follows_configuration_maturity_not_contract_maturity():
    """`coverage_complete` is a Gate 2 traceability state and says nothing about whether the YAML has
    been authored. Binding on it would hold a new tumour to a scaffold config it has not written."""
    import tempfile as _t
    import product_gates
    with _t.TemporaryDirectory() as tmp:
        prod = Path(tmp) / "p"
        (prod / "handoff").mkdir(parents=True)
        (prod / "handoff" / "MATURITY.yaml").write_text(
            "configuration: not_started\ncontract: coverage_complete\n")
        assert product_gates.maturity(str(prod))["configuration"] == "not_started"
        (prod / "handoff" / "MATURITY.yaml").write_text("contract: draft\n")
        assert product_gates.maturity(str(prod))["configuration"] == "not_started", "defaults DOWN"
    # The live matrix: prostate 202606 authored its YAML, ovarian has not.
    live = {r["product"]: r for r in
            (product_gates.facts(str(REPO), p) for p in product_gates.products(str(REPO)))}
    assert live["products/oncology/prostate/202606"]["configuration"] == "draft"
    assert live["products/oncology/oc/202606"]["configuration"] == "not_started"


def test_ambiguous_columns_are_deterministic_sheet_scoped_and_requirement_only():
    """Three defects in one control: a set of dicts serialised in an unstable order into an artifact
    that CI byte-compares; no sheet identity, so two sheets with the same header pair collapsed into
    one finding; and no scoping, so an ambiguity on a change log blocked requirement coverage."""
    import tempfile as _t
    openpyxl = pytest_importorskip("openpyxl")
    with _t.TemporaryDirectory() as tmp:
        path = os.path.join(tmp, "wb.xlsx")
        wb = openpyxl.Workbook(); wb.remove(wb.active)
        for name, hdr in (("8.Outcomes", ["Variable", "Definition", "EDM Derivation"]),
                          ("6.Clinical characteristics", ["Variable", "Values", "Codes"]),
                          ("11.Review Decisions", ["Variable", "Definition", "Derivation"])):
            ws = wb.create_sheet(name); ws.append(hdr); ws.append(["X", "a", "b"])
        wb.save(path)
        shared = spec_extract.shared_domains(str(REPO / "platform" / "tools"))
        runs = [spec_extract.extract(path, shared)["extraction"]["columns_ambiguous"] for _ in range(4)]
        assert all(r == runs[0] for r in runs), "order must be stable: the artifact is byte-compared"
        assert [(c["tab"], c["field"]) for c in runs[0]] == [
            ("11.Review Decisions", "definition"), ("6.Clinical characteristics", "values"),
            ("8.Outcomes", "definition")], runs[0]
        assert runs[0][2]["kept_header"] == "Definition" and runs[0][2]["other_column"] == 3

        blocked = [b for b in contract_scaffold.extraction_integrity(
            spec_extract.extract(path, shared), [], None) if "two visible" in b]
        assert len(blocked) == 2, blocked                       # the ignored review tab is not one
        assert not any("Review Decisions" in b for b in blocked)


def test_a_maturity_claim_cannot_be_switched_off_by_deleting_its_evidence():
    """--list-buildable simply omitted a pack whose contract or config was missing, so removing the
    thing a gate checks was a way to turn the gate off. And the two axes were validated separately,
    which allowed configuration:approved on contract:not_started."""
    import tempfile as _t
    import product_gates as pg
    with _t.TemporaryDirectory() as tmp:
        rel = "products/oncology/x/202601"
        prod = Path(tmp) / rel
        (prod / "handoff").mkdir(parents=True)

        (prod / "handoff" / "MATURITY.yaml").write_text(
            "configuration: approved\ncontract: not_started\n")
        errs = pg.maturity_errors(tmp, rel)
        assert any("Gate 4 cannot close before Gate 2" in e for e in errs), errs
        assert any("coverage is not complete" in e for e in errs), errs

        (prod / "handoff" / "MATURITY.yaml").write_text(
            "configuration: draft\ncontract: coverage_complete\n")
        errs = pg.maturity_errors(tmp, rel)
        assert any("requires spec_pipeline/pipeline.conf" in e for e in errs), errs
        assert any("requires config/data_product.yaml" in e for e in errs), errs

        (prod / "handoff" / "MATURITY.yaml").write_text("configuration: not_started\ncontract: draft\n")
        assert pg.maturity_errors(tmp, rel) == []
    assert pg.maturity_errors(str(REPO), "products/oncology/prostate/202606") == []


def test_an_open_decision_never_hides_a_membership_difference():
    """The code said membership is never silenced; the implementation skipped the whole config ref
    when a decision named it, which silenced membership along with everything else."""
    import tempfile as _t
    import contract_binding as cb
    SPEC = ("enumerations:\n  region1:\n    spec_ref: demographics:14\n    kind: membership\n"
            "    values:\n      - {label: Northeast, members: [ME, VT]}\n")
    with _t.TemporaryDirectory() as tmp:
        d = Path(tmp) / "pack"
        (d / "handoff").mkdir(parents=True)
        (d / "variables").mkdir()
        (d / "spec_pipeline" / "out").mkdir(parents=True)
        (d / "spec_pipeline" / "out" / "ENUMERATION_CANDIDATES.yaml").write_text(SPEC)
        (d / "variables" / "demo.yaml").write_text(
            "pack_id: d\nregions:\n  - {code: 1, label: Northeast, states: [ME, VT, XX]}\n"
            "  - {code: 9, label: Unknown}\n")
        (d / "handoff" / "FUNCTIONAL_CONTRACT.md").write_text(
            "```yaml\nvariable_id: REGION1\nspec_refs: [demographics:14]\n"
            "implementation_refs: [variables/demo.yaml#/regions]\n"
            "status: {requirement: draft, source: unverified, implementation: implemented, "
            "validation: not_run}\n```\n")
        (d / "handoff" / "DECISIONS.md").write_text(
            "| ID | Question | Evidence | Owner | Answer | Status |\n|---|---|---|---|---|---|\n"
            "| CODE-X | Confirm the fallback codes | `variables/demo.yaml#/regions` | RWB | — | OPEN |\n")
        diffs = cb.compare_enumerations(str(d), cb.governed_blocks(str(d), ["variables/demo.yaml"]))
        assert any("member(s) ['xx']" in x for x in diffs), diffs
        assert not any("label(s) ['unknown']" in x for x in diffs), \
            "the decision names this ref, so label alignment IS covered by it"


def test_a_code_that_appears_or_vanishes_is_reported():
    """Comparing only SHARED codes let spec 1=Positive 2=Negative vs yaml 1=Positive 3=Negative pass:
    the label sets are identical and code 1 agrees."""
    import tempfile as _t
    import contract_binding as cb
    with _t.TemporaryDirectory() as tmp:
        d = Path(tmp) / "pack"
        (d / "handoff").mkdir(parents=True)
        (d / "variables").mkdir()
        (d / "spec_pipeline" / "out").mkdir(parents=True)
        (d / "spec_pipeline" / "out" / "ENUMERATION_CANDIDATES.yaml").write_text(
            "enumerations:\n  hrr:\n    spec_ref: clinical:71\n    kind: numeric_map\n"
            "    values:\n      - {code: 1, label: Positive}\n      - {code: 2, label: Negative}\n")
        (d / "variables" / "demo.yaml").write_text(
            "pack_id: d\npanel:\n  - {code: 1, label: Positive}\n  - {code: 3, label: Negative}\n")
        (d / "handoff" / "FUNCTIONAL_CONTRACT.md").write_text(
            "```yaml\nvariable_id: HRR\nspec_refs: [clinical:71]\n"
            "implementation_refs: [variables/demo.yaml#/panel]\n"
            "status: {requirement: draft, source: unverified, implementation: implemented, "
            "validation: not_run}\n```\n")
        diffs = cb.compare_enumerations(str(d), cb.governed_blocks(str(d), ["variables/demo.yaml"]))
        assert any("code(s) ['2=negative'] the approved YAML does not assign" in x for x in diffs), diffs
        assert any("assigns code(s) ['3=negative'] the spec does not state" in x for x in diffs), diffs


def test_promotion_lifts_what_the_spec_states_and_never_invents_the_rest():
    """The mechanical half of contract -> config: values come from the spec row the record cites, so
    nobody retypes fifty-two state codes. What the spec does not state is named as a gap, not guessed,
    and an existing block is never overwritten — prostate's `code: 99 Unknown (fallthrough)` is not in
    the spec and is the subject of an open decision."""
    import contract_binding as cb
    pack = REPO / "products" / "oncology" / "prostate" / "202606"
    if not (pack / "spec_pipeline" / "out" / "ENUMERATION_CANDIDATES.yaml").exists():
        import pytest
        pytest.skip("no candidates artifact")
    blocks = cb.governed_blocks(str(pack), cb.pack_yaml(str(pack)))
    props = {b.splitlines()[0].split()[1]: b for b in cb.promote(str(pack), blocks)}

    regions = props["region1"]
    # Every state the spec lists, verbatim — including DE, the code an unanchored replace once turned
    # into the word "Implementation". Lifting beats retyping precisely here.
    assert '"DE"' in regions and '"PR"' in regions and '"AK"' in regions
    assert regions.count('"') // 2 >= 52, "all the states the spec enumerates"
    # The spec states no codes for a membership chain, so none are emitted and the gap is named.
    assert "code:" not in regions
    assert "NOT STATED BY THE SPEC" in regions and "numeric codes" in regions
    # A `Missing` predicate is not a terminal else, so the fallthrough gap is named regardless.
    assert "terminal fallthrough" in regions
    # ...and it must not have invented the config's own additions. Checked on the emitted YAML only:
    # the comment block legitimately says the word "fallthrough" when naming the gap.
    body = "\n".join(l for l in regions.splitlines() if not l.lstrip().startswith("#"))
    assert "99" not in body and "Unknown" not in body, body

    # A block already in the pack is flagged, never proposed as a replacement.
    assert "ALREADY PRESENT" in regions and "ALREADY PRESENT" in props["agegr1n"]
    # A numeric map the spec DOES state carries its codes.
    assert "code: 1" in props["agegr1n"]


def test_gate3_parses_sources_as_yaml_and_refuses_to_invent_columns():
    """Splitting `columns: {...}` on commas tore quoted expressions apart — `"later-of(testdate,
    resultdate)"` became a column named `"later-of(testdate`, and the profile was searched for it.
    Eighteen such phantoms existed on prostate 202606; under --complete each would have been an
    ABSENT defect. Parsed as YAML the values arrive intact, and a non-atomic value is reported as a
    CONTRACT defect rather than looked up."""
    import tempfile as _t
    import source_check
    TSV = ("profile_product_id\tprofile_schema\tprofile_cut\tprofile_source_mode\tprofile_mode\ttable\ttable_base\tcolumn\tkind\tsampled\tn_rows\tn_rows_total\tpct_missing\t"
           "distinct\tdate_min\tdate_max\ttop_values\n"
           "t\tfixture_schema\t2026m06\tdbi\tfull\tt_demographics_2026m06\tt_demographics\tbirthyear\tinteger\tFALSE\t10\t10\t2.1\t7\t\t\tx\n")
    with _t.TemporaryDirectory() as tmp:
        prof = os.path.join(tmp, "p.tsv")
        open(prof, "w", encoding="utf-8").write(TSV)
        prod = Path(tmp) / "pack"
        (prod / "handoff").mkdir(parents=True)
        (prod / "handoff" / "FUNCTIONAL_CONTRACT.md").write_text(
            "```yaml\nvariable_id: AGE\n"
            "source: {logical_table: demographics, physical_stem: t_demographics, "
            "columns: {birth_year: birthyear, race: race}}\n```\n"
            "```yaml\nvariable_id: LAB\n"
            "source: {logical_table: lab, physical_stem: t_lab, "
            'columns: {date: "later-of(testdate, resultdate)"}}\n```\n'
            "```yaml\nvariable_id: PRACTIC\n"
            "source: {logical_table: practice, physical_stem: t_practice, "
            "columns: {type: practicetype}}\n```\n"
            "```yaml\nvariable_id: MININDEX\n"
            "source: {logical_table: (build_parameter), physical_stem: n/a, "
            "columns: {value: study.index_start}}\n```\n")

        srcs = {v: {c: col for e in ins for c, col in e["columns"].items()}
                for v, _k, _s, ins, _d in source_check.record_sources(str(prod))}
        assert srcs["LAB"]["date"] == "later-of(testdate, resultdate)", "the value must arrive whole"

        _f, counts = source_check.check(str(prod), prof)
        assert counts["present"] == 1                       # birthyear
        assert counts["not_in_profile"] == 1                # race: unknown, not absent
        assert counts["unprofiled"] == 1                    # t_practice: table not in the profile
        assert counts["absent_column"] == 0 and counts["absent_table"] == 0
        assert counts["not_a_column"] == 1, "an expression is a contract defect, never a lookup"
        assert counts["unique_mappings"] == 3

        # --complete makes a missing TABLE fail too. Previously only missing columns did, so a whole
        # unprofiled table passed the completeness claim.
        _f, counts = source_check.check(str(prod), prof, complete=True)
        assert counts["absent_column"] == 1 and counts["absent_table"] == 1, counts

    # There used to be a second half here running the LIVE prostate pack against a committed
    # profiler TSV (handoff/tests/profile_sample.tsv). That file is IHD under GSK R&D policy §9 and
    # has been deleted, so the check is gone rather than left behind a `if fixture.exists():` that
    # would silently pass forever while looking like coverage.
    #
    # It is NOT replaced by a synthetic live-pack profile: a profile generated from the pack's own
    # config would satisfy `absent_column == 0` by construction, which proves nothing. Checking the
    # live contract against a real delivered cut is a Gate 3 run on production
    # (`source_check.py <pack> --profile ... --complete`), where the real profile exists. CI keeps
    # the synthetic-pack cases above, which test the checker's LOGIC without needing vendor data.


def test_gate3_verdict_report_carries_no_vendor_statistics():
    """The repo-facing report is verdicts only. Missingness, distinct counts, date ranges and row
    counts are vendor-derived and belong in the restricted profile report — a committed SOURCE_FACTS
    carrying `missing=41.0% distinct=5` put vendor statistics in the AI-readable workspace."""
    import tempfile as _t
    import source_check
    TSV = ("profile_product_id\tprofile_schema\tprofile_cut\tprofile_source_mode\tprofile_mode\ttable\ttable_base\tcolumn\tkind\tsampled\tn_rows\tn_rows_total\tpct_missing\t"
           "distinct\tdate_min\tdate_max\ttop_values\n"
           "t\tfixture_schema\t2026m06\tdbi\tfull\tt_demographics_2026m06\tt_demographics\tbirthyear\tinteger\tFALSE\t10\t10\t41.0\t5"
           "\t2001-01-01\t2020-01-01\tSECRETVALUE\n")
    with _t.TemporaryDirectory() as tmp:
        prof = os.path.join(tmp, "p.tsv")
        open(prof, "w", encoding="utf-8").write(TSV)
        prod = Path(tmp) / "pack"
        (prod / "handoff").mkdir(parents=True)
        (prod / "handoff" / "FUNCTIONAL_CONTRACT.md").write_text(
            "```yaml\nvariable_id: AGE\nsource: {logical_table: d, physical_stem: t_demographics, "
            "columns: {birth_year: birthyear}}\n```\n")
        findings, counts = source_check.check(str(prod), prof)
        md = source_check.render(str(prod), prof, findings, counts)
        for leak in ("41.0", "distinct=5", "SECRETVALUE", "2001-01-01", "n_rows"):
            assert leak not in md, f"vendor statistic leaked into the repo-facing report: {leak}"
        assert "birthyear" in md and "present" in md, "the verdict itself must still be there"
        # Provenance binds the verdict to the exact input it came from.
        assert source_check.sha256(prof) in md and source_check.tool_version() in md
        assert "absence proves nothing" in md


def test_gate3_takes_the_physical_table_from_config_not_from_the_contract():
    """The physical table name is the most volatile fact in the system.

    It changes with the tumour, and it changes with the DELIVERY FORMAT for the same tumour — a
    rename overlay moves every stem. Reading it from the contract bakes one tumour's one delivery
    into the requirement document: 59 of the 60 vendor-sourced prostate records restate a stem their
    own config already maps. So the contract names a LOGICAL source and config resolves it.

    The test is the one that would catch a regression to hardcoding: the same contract, two different
    configs, and the lookup must follow config both times.
    """
    import tempfile as _t
    import source_check
    HDR = ("profile_product_id\tprofile_schema\tprofile_cut\tprofile_source_mode\tprofile_mode\ttable\ttable_base\tcolumn\tkind\tsampled\tn_rows\tn_rows_total\tpct_missing\t"
           "distinct\tdate_min\tdate_max\ttop_values\n")
    ROW = "t\ts\t2026m06\tdbi\tfull\t{0}_2026m06\t{0}\t{1}\tinteger\tFALSE\t10\t10\t2.1\t7\t\t\tx\n"
    CONTRACT = ("```yaml\nvariable_id: AGE\nsource: {logical_table: demographics, "
                "physical_stem: whatever_the_contract_says, columns: {birth_year: birthyear}}\n```\n"
                "```yaml\nvariable_id: TRTDIS\nsource: {logical_table: \"lot + mortality\", "
                "physical_stem: t_lot, columns: {line_end: enddate, death: dthdt}}\n```\n")

    def run(sources, profile_rows, complete=True):
        with _t.TemporaryDirectory() as tmp:
            prod = Path(tmp) / "pack"
            (prod / "handoff").mkdir(parents=True)
            (prod / "config").mkdir()
            (prod / "handoff" / "FUNCTIONAL_CONTRACT.md").write_text(CONTRACT)
            (prod / "config" / "data_product.yaml").write_text(
                "data_product_id: t\nname: t\nversion: '1'\n"
            "run:\n  source_schema: s\n  refresh: 2026m06\nsources:\n"
                + "".join(f"  {k}: {v}\n" for k, v in sources.items()))
            prof = os.path.join(tmp, "p.tsv")
            open(prof, "w", encoding="utf-8").write(HDR + "".join(ROW.format(*r) for r in profile_rows))
            return source_check.check(str(prod), prof, complete=complete)

    # Delivery A: demographics is `t_demographics`. The contract's own stem is nonsense and unused.
    _f, a = run({"demographics": "t_demographics", "lot": "t_lot", "mortality": "t_mortality"},
                [("t_demographics", "birthyear"), ("t_lot", "enddate"), ("t_mortality", "dthdt")])
    assert a["present"] == 3 and a["absent_column"] == 0 and a["absent_table"] == 0, a
    assert a["resolved_via_config"] == 2, a

    # Delivery B: a rename overlay moved every table. Same contract, same requirement — and because
    # the physical name is config's, the lookup follows it with no edit to the contract at all.
    _f, b = run({"demographics": "dem_v2", "lot": "lot_v2", "mortality": "mort_v2"},
                [("dem_v2", "birthyear"), ("lot_v2", "enddate"), ("mort_v2", "dthdt")])
    assert b["present"] == 3 and b["absent_column"] == 0 and b["absent_table"] == 0, b

    # `lot + mortality` is TWO sources. Reading one stem meant `dthdt` was sought in the LOT table and
    # reported absent — a false vendor defect produced by the contract's shape, under --complete.
    _f, c = run({"demographics": "t_demographics", "lot": "t_lot", "mortality": "t_mortality"},
                [("t_demographics", "birthyear"), ("t_lot", "enddate")])
    assert c["absent_table"] == 1 and c["absent_column"] == 0, \
        "dthdt's table is genuinely missing from this profile — not the column from the wrong table"

    # A stem the contract states and config contradicts: config wins, and the disagreement is named
    # rather than silently ignored — that stem is what a reader would otherwise trust.
    _f, d = run({"demographics": "dem_v2", "lot": "t_lot", "mortality": "t_mortality"},
                [("dem_v2", "birthyear"), ("t_lot", "enddate"), ("t_mortality", "dthdt")])
    assert d["stem_drift"] == 1 and d["present"] == 3, d

    # No config authored yet is not a failure: the pack falls back to the contract's own stem.
    with _t.TemporaryDirectory() as tmp:
        prod = Path(tmp) / "pack"
        (prod / "handoff").mkdir(parents=True)
        (prod / "handoff" / "FUNCTIONAL_CONTRACT.md").write_text(
            "```yaml\nvariable_id: AGE\nsource: {logical_table: demographics, "
            "physical_stem: t_demographics, columns: {birth_year: birthyear}}\n```\n")
        prof = os.path.join(tmp, "p.tsv")
        open(prof, "w", encoding="utf-8").write(HDR + ROW.format("t_demographics", "birthyear"))
        _f, e = source_check.check(str(prod), prof, complete=True)
        assert e["present"] == 1 and e["resolved_via_config"] == 0, e


def test_the_shared_profile_runner_is_pack_scoped_and_refuses_unsafe_output():
    """One runner for every tumour, driven by the PACK PATH — not by the registry.

    The only one-command entry point was run_prostate_profile.py, which resolved its config through
    `product_config(root, "prostate")` — the REGISTRY's current spec version for that tumour. It sits
    in the 202606 pack, so the day `current_spec_version` becomes 202607 it profiles the 202607
    config while still calling itself the 202606 runner. And every new tumour needed its own copy,
    which is the duplication that moving the profiler and the reporter into platform/ removed.

    Guards asserted here are the ones that protect restricted data or evidence integrity.
    """
    import tempfile as _t
    import importlib.util
    spec = importlib.util.spec_from_file_location(
        "run_product_profile", REPO / "platform" / "tools" / "run_product_profile.py")
    rpp = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(rpp)

    def exits(argv):
        try:
            rpp.main(argv)
        except SystemExit as e:
            return str(e.code) if e.code else ""
        return None

    live = str(REPO / "products" / "oncology" / "prostate" / "202606")
    union = str(REPO / "products" / "oncology" / "endometrial" / "YYYYMM")

    # restricted output: required, and never inside the checkout
    assert "REQUIRED" in (exits([live, "--cut", "2026m06", "--schema", "s"]) or "")
    inside = exits([live, "--cut", "2026m06", "--schema", "s", "--out-dir", str(REPO / "products")])
    assert "inside the checkout" in (inside or ""), inside
    # ...including via a path that only resolves into the checkout after expansion
    sneaky = exits([live, "--cut", "2026m06", "--schema", "s",
                    "--out-dir", str(REPO / "products" / ".." / "platform")])
    assert "inside the checkout" in (sneaky or ""), sneaky

    # a union pack cannot be profiled as if one run covered every member
    msg = exits([union, "--cut", "2026m06", "--schema", "s"]) or ""
    assert "source_union" in msg and "--member" in msg, msg
    assert "not declared by this pack" in (exits([union, "--cut", "2026m06", "--member", "nope"]) or "")

    # the pack path, not the registry, decides what is profiled: a directory with no config is
    # rejected rather than silently falling back to this tumour's current registry version
    with _t.TemporaryDirectory() as tmp:
        assert "no config/data_product.yaml" in (exits([tmp, "--cut", "2026m06", "--schema", "s"]) or "")

    # each union member gets its OWN output directory — the profiler's default is <out>/<cut>/, so
    # two members at one cut wrote to the same file and the second silently overwrote the first
    import product_gates
    members = product_gates.union_members(union)
    assert len(members) == 2
    dirs = {os.path.join("/root", "pid", m, "2026m06") for m in members}
    assert len(dirs) == 2, "two members must not share an output directory"


def test_a_union_members_reviewed_acceptance_is_read_from_that_members_report():
    """Acceptances were always read from handoff/SOURCE_VERDICTS.md, even for a union member.

    A union product's evidence lives in SOURCE_VERDICTS.<member>.md. Both accepted_block() and
    accepted_collisions() hardcoded the single-schema filename, so for every member run they read a
    file that does not exist for that member: a human's reviewed acceptance was invisible to the very
    check it exists to satisfy, and regenerating that member's report dropped the block entirely.

    Both directions matter — the acceptance must be FOUND for its own member, and must NOT leak from
    the single-schema file into a member run.
    """
    import tempfile as _t
    import source_check
    ACCEPT = ("accepted_dependency_name_collisions:\n"
              "  - record: ETH\n    source: demographics\n    role: r\n    column: race\n"
              "    rationale: reads the race COLUMN; the RACE variable maps race->race\n")
    key = ("ETH", "demographics", "r", "race")

    with _t.TemporaryDirectory() as tmp:
        prod = Path(tmp) / "pack"
        (prod / "handoff").mkdir(parents=True)
        (prod / "handoff" / "SOURCE_VERDICTS.edm.md").write_text(ACCEPT, encoding="utf-8")

        # the member's own report is where its acceptance lives
        assert key in source_check.accepted_collisions(str(prod), "edm")
        assert "accepted_dependency_name_collisions" in source_check.accepted_block(str(prod), "edm")

        # a DIFFERENT member must not inherit it, and neither must the single-schema read
        assert source_check.accepted_collisions(str(prod), "dostar") == set()
        assert source_check.accepted_collisions(str(prod)) == set()
        assert source_check.accepted_block(str(prod)) == ""

    # and the single-schema file must not leak into a member run
    with _t.TemporaryDirectory() as tmp:
        prod = Path(tmp) / "pack"
        (prod / "handoff").mkdir(parents=True)
        (prod / "handoff" / "SOURCE_VERDICTS.md").write_text(ACCEPT, encoding="utf-8")
        assert key in source_check.accepted_collisions(str(prod))
        assert source_check.accepted_collisions(str(prod), "edm") == set(), (
            "a member run read the single-schema report — one member's acceptance would silently "
            "satisfy another's check")

    # the filename must be the one Gate 4 will look for, not a second convention
    import product_gates
    assert source_check.verdict_file("/p", "edm").endswith(product_gates.verdict_rel("edm"))
    assert source_check.verdict_file("/p").endswith(product_gates.verdict_rel())


def test_union_members_are_parsed_as_yaml_not_pattern_matched():
    """The real endometrial config writes its members as INLINE MAPS, and a regex mis-read them.

    `re.findall(r"schema:\\s*(\\S+)")` over

        members:
          - { schema: clnprw_flatiron_endo_use,        flag: EDM }

    returns `clnprw_flatiron_endo_use,` WITH the trailing comma — `\\S+` does not stop at one. The
    comma then rode into the expected evidence filename and into the member name Gate 4 compares
    against, while source_check.py (which goes through the real config loader) saw the clean name:
    the two halves of the union path disagreed about what a member is called.

    Two cases below are ones the old regex genuinely got wrong: the inline map (trailing comma) and
    a quoted name (kept its quotes). The rest it happened to handle — trailing comments stopped at
    whitespace, and a commented-out member fell outside the block match — and they are here as
    regression guards on the parser, not as evidence against the regex.

    The pre-existing tests all used block style (`- schema: edm`), the one form where the regex
    works, so the bug lived under passing tests in the only real config that declares a union.
    """
    import tempfile as _t
    import product_gates
    cases = [
        ("inline map (the real endometrial form)",
         "source_union:\n  members:\n"
         "    - { schema: clnprw_flatiron_endo_use,        flag: EDM }\n"
         "    - { schema: clnprw_flatiron_dostar_endo_use, flag: DOS }\n",
         ["clnprw_flatiron_endo_use", "clnprw_flatiron_dostar_endo_use"]),
        ("block style still works",
         "source_union:\n  members:\n    - schema: edm\n    - schema: dostar\n", ["edm", "dostar"]),
        ("quoted names lose their quotes",
         "source_union:\n  members:\n    - schema: \"edm\"\n    - schema: 'dostar'\n",
         ["edm", "dostar"]),
        ("a trailing comment is not part of the name",
         "source_union:\n  members:\n    - schema: edm   # primary feed\n", ["edm"]),
        ("a commented-out member is not a member",
         "source_union:\n  members:\n    - schema: edm\n#   - schema: retired\n", ["edm"]),
        ("no union declared -> no members", "sources:\n  demographics: t_demo\n", []),
    ]
    for label, union_yaml, expect in cases:
        with _t.TemporaryDirectory() as tmp:
            prod = Path(tmp) / "pack"
            (prod / "config").mkdir(parents=True)
            (prod / "config" / "data_product.yaml").write_text(
                "data_product_id: t\nname: t\nversion: '1'\n"
                "run:\n  source_schema: edm\n  refresh: 2026m06\n" + union_yaml, encoding="utf-8")
            got = product_gates.union_members(str(prod))
            assert got == expect, f"{label}: expected {expect}, got {got}"
            # whatever the members are, they must be usable as filenames
            for m in got:
                assert m == m.strip() and not set(m) & set(",'\"# "), (
                    f"{label}: member {m!r} is not a clean schema name — it would become the "
                    f"evidence filename SOURCE_VERDICTS.{m}.md")

    # A pack whose config is not yet valid YAML must not break DISCOVERY.
    with _t.TemporaryDirectory() as tmp:
        prod = Path(tmp) / "pack"
        (prod / "config").mkdir(parents=True)
        (prod / "config" / "data_product.yaml").write_text("source_union: [unclosed\n", encoding="utf-8")
        assert product_gates.union_members(str(prod)) == []


def test_union_evidence_is_one_report_per_member_and_one_file_cannot_serve_two():
    """The profiler can only be run in production, and nothing can be created after it runs.

    That rules out a sidecar or a schema field in the TSV. But `DC_SCHEMA` is a per-run variable, so
    running the profiler once per member already yields one file per member — and each becomes its
    own verdict report. Gate 4 then requires the FULL declared member set, not merely one report that
    names a member.

    Which file came from which schema stays a human claim, because the TSV carries no schema and
    nothing may be added to it. What the tool can still prove is the mechanical failure that claim is
    exposed to: the same file submitted twice under two member names. Two reports quoting one
    profile checksum is exactly that.
    """
    import tempfile as _t
    import product_gates
    CONTRACT = "```yaml\nvariable_id: AGE\n```\n"

    def pack(tmp, reports):
        prod = Path(tmp) / "pack"
        (prod / "handoff").mkdir(parents=True, exist_ok=True)
        (prod / "config").mkdir(exist_ok=True)
        contract = prod / "handoff" / "FUNCTIONAL_CONTRACT.md"
        contract.write_text(CONTRACT)
        cfg = prod / "config" / "data_product.yaml"
        cfg.write_text("data_product_id: t\nname: t\nversion: '1'\n"
                       "sources:\n  demographics: t_demographics\n"
                       "source_union:\n  discriminator: db\n  members:\n"
                       "    - schema: edm\n    - schema: dostar\n")
        for member, profile_sha in reports.items():
            fm = {"gate3_result": "passed",
                  "contract_sha256": hashlib.sha256(CONTRACT.encode()).hexdigest(),
                  "config_sha256": product_gates.delivery_sha256(str(prod)),
                  "profile_sha256": profile_sha, "data_cut": "2026m06", "config_refresh": "none",
                  "complete": "true", "union_member": member,
                  "schema_validation_sha256": f"sv-{member}", "schema_validation_result": "passed_live", "schema_validation_cut": "2026m06", "schema_validation_config_sha256": product_gates.delivery_sha256(str(prod)), "schema_validation_product_id": "t", "schema_validation_schema": member, "profile_schema": member, "reviewed_by": "A. Person", "review_date": "2026-07-27"}
            fm.update({f: "0" for f in ("bad_shape", "not_a_column", "not_a_table", "unknown_source",
                                        "absent_column", "absent_table", "unchecked",
                                        "ambiguous_source", "derived_input_candidate")})
            (prod / "handoff" / f"SOURCE_VERDICTS.{member}.md").write_text(
                "---\n" + "".join(f"{k}: {v}\n" for k, v in fm.items()) + "---\n")
        return product_gates.verdict_evidence_errors("pack", str(prod), str(contract))

    with _t.TemporaryDirectory() as tmp:
        assert pack(tmp, {"edm": "aaa", "dostar": "bbb"}) == [], \
            "one report per member, each from its own profile run, is complete evidence"

    # A report for only one member does not approve a product that reads both.
    with _t.TemporaryDirectory() as tmp:
        errs = pack(tmp, {"edm": "aaa"})
        assert any("SOURCE_VERDICTS.dostar.md" in e for e in errs), errs

    # The same TSV passed twice under different member names.
    with _t.TemporaryDirectory() as tmp:
        errs = pack(tmp, {"edm": "same", "dostar": "same"})
        assert any("SAME profile" in e for e in errs), errs

    # A report filed under one member but naming another.
    with _t.TemporaryDirectory() as tmp:
        prod = Path(tmp) / "pack"
        pack(tmp, {"edm": "aaa", "dostar": "bbb"})
        p = prod / "handoff" / "SOURCE_VERDICTS.dostar.md"
        p.write_text(p.read_text().replace("union_member: dostar", "union_member: edm"))
        errs = product_gates.verdict_evidence_errors(
            "pack", str(prod), str(prod / "handoff" / "FUNCTIONAL_CONTRACT.md"))
        assert any("union_member" in e for e in errs), errs


def test_a_union_member_run_resolves_in_that_members_schema():
    """`--union-member` had no positive test — only the refusal without it was covered.

    It has to do two things: reject a name that is not a declared member, and resolve tables in THAT
    member's schema. The second is invisible under the default layout, where every member produces
    the same table_base; it shows up the moment a layout references {schema}, which is exactly when
    getting it wrong would check one member while reporting the other's name.
    """
    import tempfile as _t
    import source_check
    HDR = ("profile_product_id\tprofile_schema\tprofile_cut\tprofile_source_mode\tprofile_mode\ttable\ttable_base\tcolumn\tkind\tsampled\tn_rows\tn_rows_total\tpct_missing\t"
           "distinct\tdate_min\tdate_max\ttop_values\n")

    def run(member, table):
        with _t.TemporaryDirectory() as tmp:
            prod = Path(tmp) / "pack"
            (prod / "handoff").mkdir(parents=True)
            (prod / "config").mkdir()
            (prod / "handoff" / "FUNCTIONAL_CONTRACT.md").write_text(
                "```yaml\nvariable_id: AGE\nsource: {kind: vendor, inputs: "
                "{demographics: {b: birthyear}}}\n```\n")
            (prod / "config" / "data_product.yaml").write_text(
                "data_product_id: t\nname: t\nversion: '1'\nvendor: flatiron\n"
                "run:\n  source_schema: edm\n  refresh: 2026m06\n"
                "  source_layout: \"{schema}.{schema}_{stem}_{refresh}\"\n"
                "sources:\n  demographics: t_demographics\n"
                "source_union:\n  discriminator: db\n  members:\n"
                "    - schema: edm\n    - schema: dostar\n")
            prof = os.path.join(tmp, "p.tsv")
            open(prof, "w", encoding="utf-8").write(
                HDR + f"t\t{member}\t2026m06\tdbi\tfull\t{table}_2026m06\t{table}\tbirthyear\tinteger\tFALSE\t9\t9\t1.0\t3\t\t\tv\n")
            return source_check.check(str(prod), prof, complete=True, union_member=member)

    # The member's own schema is in the table name, so each member run must look for a different one.
    _f, edm = run("edm", "edm_t_demographics")
    assert edm["present"] == 1, edm
    _f, dos = run("dostar", "dostar_t_demographics")
    assert dos["present"] == 1, dos
    # ...and a member run must NOT be satisfied by the other member's tables.
    _f, wrong = run("dostar", "edm_t_demographics")
    assert wrong["present"] == 0 and wrong["absent_table"] == 1, wrong

    # A name that is not a declared member is refused rather than quietly accepted.
    with _t.TemporaryDirectory() as tmp:
        prod = Path(tmp) / "pack"
        (prod / "handoff").mkdir(parents=True)
        (prod / "config").mkdir()
        (prod / "handoff" / "FUNCTIONAL_CONTRACT.md").write_text(
            "```yaml\nvariable_id: AGE\nsource: {kind: vendor, inputs: "
            "{demographics: {b: birthyear}}}\n```\n")
        (prod / "config" / "data_product.yaml").write_text(
            "data_product_id: t\nname: t\nversion: '1'\nrun:\n  source_schema: edm\n"
            "  refresh: 2026m06\nsources:\n  demographics: t_demographics\n"
            "source_union:\n  members:\n    - schema: edm\n    - schema: dostar\n")
        prof = os.path.join(tmp, "p.tsv")
        open(prof, "w", encoding="utf-8").write(
            HDR + "t\tedm\t2026m06\tdbi\tfull\tt_demographics_2026m06\tt_demographics\tbirthyear\tinteger\tFALSE\t9\t9\t1\t3\t\t\tv\n")
        assert _exits(lambda m: source_check.check(str(prod), prof, complete=True, union_member=m),
                      "not_a_member")


def test_the_stage1_gate_actually_covers_what_it_claims():
    """Two fail-open paths in the protection added for new tumours.

    The CI step ran over `--list-decisions`, which also requires DECISIONS.md — so a new tumour that
    had written its contract but not yet raised its first decision was skipped by the very step meant
    to protect new tumours. And an indented block-form `source:` was classed `not_a_column`, which
    Stage 1 deliberately tolerates as migration backlog, so the one thing Stage 1 exists to catch —
    a declaration it cannot read at all — went through.
    """
    import tempfile as _t
    import product_gates
    import source_check

    with _t.TemporaryDirectory() as tmp:
        (Path(tmp) / "platform" / "tools").mkdir(parents=True)
        pack = Path(tmp) / "products/oncology/newtumour/202601/handoff"
        pack.mkdir(parents=True)
        (pack / "FUNCTIONAL_CONTRACT.md").write_text("```yaml\nvariable_id: X\n```\n")
        rows = [product_gates.facts(tmp, r) for r in product_gates.products(tmp)]
        with_contract = [r["product"] for r in rows if r["contract_file"]]
        with_decisions = [r["product"] for r in rows if r["decisions"] and r["contract_file"]]
        assert with_contract and not with_decisions, \
            "a pack with a contract and no decisions register is exactly the new-tumour case"

    with _t.TemporaryDirectory() as tmp:
        prod = Path(tmp) / "pack"
        (prod / "handoff").mkdir(parents=True)
        (prod / "handoff" / "FUNCTIONAL_CONTRACT.md").write_text(
            "```yaml\nvariable_id: X\nsource:\n  kind: vendor\n  inputs:\n"
            "    demographics:\n      b: birthyear\n```\n")
        _f, c = source_check.check(str(prod))
        assert c["bad_shape"] == 1, "an unreadable source is a SHAPE defect, which is Stage 1's job"
        assert source_check.main([str(prod), "--structure-only", "--check"]) == 1


def test_a_reviewed_acceptance_survives_regenerating_the_report():
    """`open(path, "w")` truncates the moment it is evaluated, and Python evaluates it BEFORE the
    argument to `write()`. So rendering inside the `with` made render() read a file that very call
    had just emptied — silently dropping the reviewed acceptances it was there to carry forward, so
    the reviewer's reasoning vanished and their work had to be redone on every run."""
    import tempfile as _t
    import source_check
    with _t.TemporaryDirectory() as tmp:
        prod = Path(tmp) / "pack"
        (prod / "handoff").mkdir(parents=True)
        (prod / "handoff" / "FUNCTIONAL_CONTRACT.md").write_text(
            "```yaml\nvariable_id: ETH\nsource: {kind: vendor, inputs: "
            "{demographics: {race: race}}}\ndepends_on: [RACE]\n```\n")
        v = prod / "handoff" / "SOURCE_VERDICTS.md"
        v.write_text("accepted_dependency_name_collisions:\n"
                     "  - record: ETH\n    source: demographics\n    role: race\n"
                     "    column: race\n    rationale: the raw vendor race column is required\n")
        for _ in range(3):
            source_check.main([str(prod), "--out", str(v)])
            assert "accepted_dependency_name_collisions" in v.read_text()
            assert source_check.check(str(prod))[1]["derived_input_candidate"] == 0


def test_gate4_treats_a_missing_counter_as_a_question_not_a_zero():
    """`(fm.get(f) or "0")` read an ABSENT counter as zero, so front matter that simply lacked
    `bad_shape` or `absent_column` passed as though those were clean. In an approval gate a field
    that is not there is an unanswered question."""
    import tempfile as _t
    import product_gates
    CONTRACT = "```yaml\nvariable_id: AGE\n```\n"
    with _t.TemporaryDirectory() as tmp:
        prod = Path(tmp) / "pack"
        (prod / "handoff").mkdir(parents=True)
        contract = prod / "handoff" / "FUNCTIONAL_CONTRACT.md"
        contract.write_text(CONTRACT)
        digest = hashlib.sha256(CONTRACT.encode()).hexdigest()
        base = {"gate3_result": "passed", "contract_sha256": digest, "config_sha256": "none",
                "profile_sha256": "abc", "data_cut": "2026m06", "config_refresh": "none",
                "complete": "true", "profile_schema": "s",
                "schema_validation_sha256": "sv1", "schema_validation_result": "passed_live",
                "schema_validation_cut": "2026m06", "schema_validation_config_sha256": "none",
                "schema_validation_product_id": "t", "schema_validation_schema": "s",
                "reviewed_by": "A. Person", "review_date": "2026-07-27"}
        counters = {f: "0" for f in ("bad_shape", "not_a_column", "not_a_table", "unknown_source",
                                     "absent_column", "absent_table", "unchecked",
                                     "ambiguous_source", "derived_input_candidate")}

        def write(fm):
            (prod / "handoff" / "SOURCE_VERDICTS.md").write_text(
                "---\n" + "".join(f"{k}: {v}\n" for k, v in fm.items()) + "---\n")
            return product_gates.verdict_evidence_errors("pack", str(prod), str(contract))

        assert write({**base, **counters}) == [], "all counters present and zero is evidence"
        for drop in ("bad_shape", "absent_column", "not_a_table"):
            partial = {k: v for k, v in counters.items() if k != drop}
            errs = write({**base, **partial})
            assert any(drop in e and "unanswered question" in e for e in errs), (drop, errs)
        errs = write({**base, **counters, "bad_shape": "two"})
        assert any("not whole numbers" in e for e in errs), errs


def test_nothing_depends_on_how_deep_a_pack_sits():
    """Moving the tree to production must not need a single path edited.

    Two kinds of assumption break that, and the worse one is silent. Discovery globbed
    `products/*/*/*` — exactly three levels — so adding one grouping level, say a disease group at
    `products/oncology/gu/prostate/202606`, made every pack under it vanish from `--report`, from
    every CI loop, and from every gate, while CI stayed green. Product-level scripts hopped
    `parents[5]` to find the checkout, which at the new depth landed elsewhere and failed with
    ModuleNotFoundError.

    Both are now marker walk-ups. This test does the move and requires the pack to still be found.
    """
    import tempfile as _t
    import product_gates

    with _t.TemporaryDirectory() as tmp:
        # A pack at an ordinary depth, and one under an extra grouping level.
        for rel in ("products/oncology/prostate/202606",
                    "products/oncology/gu/renal/202606",
                    "products/heme/dlbcl/2027/q1/202701"):
            (Path(tmp) / rel / "handoff").mkdir(parents=True)
            (Path(tmp) / rel / "handoff" / "MATURITY.yaml").write_text("contract: draft\n")
        (Path(tmp) / "platform" / "tools").mkdir(parents=True)     # the marker
        found = product_gates.products(tmp)
        assert found == ["products/heme/dlbcl/2027/q1/202701",
                         "products/oncology/gu/renal/202606",
                         "products/oncology/prostate/202606"], found

        # A pack's own subdirectories are not packs.
        (Path(tmp) / "products/oncology/prostate/202606/handoff/tests").mkdir()
        (Path(tmp) / "products/oncology/prostate/202606/handoff/tests/config").mkdir()
        # ...and a grouping directory that merely CONTAINS a shared config/ is not a pack.
        (Path(tmp) / "products/oncology/gu/config").mkdir(parents=True, exist_ok=True)
        assert len(product_gates.products(tmp)) == 3, product_gates.products(tmp)

    # And no source file may bake in an absolute path or a fixed hop to the checkout.
    import re as _re
    offenders = []
    for path in glob.glob(str(REPO / "products" / "**" / "*.py"), recursive=True):
        if "__pycache__" in path:
            continue
        src = open(path, encoding="utf-8").read()
        if _re.search(r"parents\[\d+\]\s*(/|$|\s*#)", src) and "platform" in src:
            offenders.append(os.path.relpath(path, str(REPO)))
    assert not offenders, ("these reach the checkout by hop count, so they break the moment a pack "
                           "is nested differently: " + ", ".join(offenders))


def test_a_nested_role_cannot_be_mistaken_for_the_source_kind():
    """`source.kind` was found by scanning the whole inline body for `kind:`.

    A legacy record whose `columns:` map happens to contain a role named `kind` therefore read as
    `source.kind: <that role's value>` — so `columns: {kind: derived}` classified a vendor record as
    derived and it left Gate 3 and Gate 4 entirely. Depth tracking is the fix. This is not
    hypothetical syntax: `kind` is exactly the sort of role name a biomarker or lab record uses.
    """
    from contract_lint import source_kind, physical_stem, records

    def rec(src):
        return list(records(f"```yaml\nvariable_id: X\nsource: {src}\n```\n"))[0]

    assert source_kind(rec("{logical_table: lab, columns: {kind: derived}}")) == "vendor"
    assert source_kind(rec("{kind: vendor, inputs: {lab: {kind: testkind}}}")) == "vendor"
    assert source_kind(rec("{logical_table: (derived), physical_stem: n/a}")) == "derived"
    # ...and the same top-level anchoring for the stem, which a nested role could also shadow.
    assert physical_stem(rec("{kind: vendor, inputs: {lot: {physical_stem: x}}}")) == ""
    assert physical_stem(rec("{kind: vendor, inputs: {lot: {c: d}}, physical_stem: t_lot}")) == "t_lot"


def test_a_reviewed_name_collision_has_somewhere_to_be_recorded():
    """Requiring `derived_input_candidate: 0` left a legitimate record no way through.

    ETH reads the `race` COLUMN of demographics and depends on the RACE VARIABLE. Its three options
    were: delete a valid column, delete a real dependency, or never pass Gate 4. A person's
    confirmation now has somewhere to live — beside the evidence it qualifies, with a rationale, and
    naming one specific mapping rather than switching the check off.
    """
    import tempfile as _t
    import source_check
    CONTRACT = ("```yaml\nvariable_id: ETH\nsource: {kind: vendor, inputs: "
                "{demographics: {race: race, ethnicity: ethnicity}}}\ndepends_on: [RACE]\n```\n")
    with _t.TemporaryDirectory() as tmp:
        prod = Path(tmp) / "pack"
        (prod / "handoff").mkdir(parents=True)
        (prod / "handoff" / "FUNCTIONAL_CONTRACT.md").write_text(CONTRACT)

        _f, c = source_check.check(str(prod))
        assert c["derived_input_candidate"] == 1, c

        (prod / "handoff" / "SOURCE_VERDICTS.md").write_text(
            "accepted_dependency_name_collisions:\n"
            "  - record: ETH\n    source: demographics\n    role: race\n    column: race\n"
            "    rationale: the raw vendor race column is independently required\n")
        _f, c = source_check.check(str(prod))
        assert c["derived_input_candidate"] == 0, "a reviewed, reasoned acceptance clears it"

        # It is a signature on ONE mapping, not a switch: no rationale, no acceptance.
        (prod / "handoff" / "SOURCE_VERDICTS.md").write_text(
            "accepted_dependency_name_collisions:\n"
            "  - record: ETH\n    source: demographics\n    role: race\n    column: race\n")
        _f, c = source_check.check(str(prod))
        assert c["derived_input_candidate"] == 1, "an acceptance with no rationale is not one"


def test_the_structure_only_gate_protects_a_new_tumour_today():
    """Stage 1 of the CI rollout.

    Waiting for prostate's and ovarian's semantic backlog before protecting ANY pack leaves every new
    tumour unprotected in the meantime. An unreadable source declaration is a typo, not a backlog
    item, so it can fail now — while legacy declarations, unresolved source names and human-review
    candidates, which ARE the backlog, are tolerated until Stage 2.
    """
    import tempfile as _t
    import source_check
    with _t.TemporaryDirectory() as tmp:
        prod = Path(tmp) / "pack"
        (prod / "handoff").mkdir(parents=True)

        # The backlog: legacy prose, an unknown source, a formula. Tolerated by Stage 1 — but the
        # legacy shape only while it is RECORDED as backlog in the allowlist, which is what stops
        # "tolerated during migration" from becoming a permanent second syntax.
        (prod / "handoff" / "FUNCTIONAL_CONTRACT.md").write_text(
            "```yaml\nvariable_id: A\nsource: {logical_table: \"lot + mortality\", "
            "columns: {d: \"max(a, b)\"}}\n```\n"
            "```yaml\nvariable_id: B\nsource: {kind: vendor, inputs: {nosuchsource: {c: col}}}\n```\n")
        assert source_check.main([str(prod), "--structure-only", "--check"]) == 1, \
            "an unrecorded legacy record is backlog being ADDED, and fails"
        # Keyed by spec row; this fixture cites none, so it lands on the `variable:` fallback.
        (prod / "handoff" / "LEGACY_SOURCES.yaml").write_text("allow:\n  - variable:A\n")
        assert source_check.main([str(prod), "--structure-only", "--check"]) == 0
        assert source_check.main([str(prod), "--check"]) == 1, "Stage 2 still sees them"

        # A typo, which is not a backlog item.
        (prod / "handoff" / "FUNCTIONAL_CONTRACT.md").write_text(
            "```yaml\nvariable_id: A\nsource: {kind: vndor, inputs: {d: {c: col}}}\n```\n")
        assert source_check.main([str(prod), "--structure-only", "--check"]) == 1

    # And it passes on every live pack today, which is what makes it wireable now.
    checked = 0
    for rel in product_gates.products(str(REPO)):
        p = REPO / rel
        if (p / "handoff" / "FUNCTIONAL_CONTRACT.md").exists():
            assert source_check.main([str(p), "--structure-only", "--check"]) == 0, rel
            checked += 1
    assert checked, "no pack has a contract — this loop asserted nothing"


def test_a_source_kind_cannot_contradict_itself():
    """Requiring what a kind NEEDS was only half the rule.

    A record could declare `kind: derived` and still carry vendor `inputs`, or `kind: constant` with
    a `physical_stem`, and the contradiction went unread because only the declared kind was
    consulted. A record saying two different things about where its value comes from has not chosen
    one, and the reader would silently believe whichever field it happened to look at.
    """
    import source_check
    def kind_of(src):
        return source_check.parse_sources(
            f"```yaml\nvariable_id: X\nsource: {src}\n```\n")[0][1]

    for src in ("{kind: derived, inputs: {d: {v: birthyear}}}",
                "{kind: derived, physical_stem: t_x}",
                "{kind: constant, parameters: [study.a]}",
                "{kind: constant, physical_stem: t_x}",
                "{kind: unavailable, inputs: {d: {v: c}}}",
                "{kind: parameter, inputs: {d: {v: c}}}",
                "{kind: vendor, parameters: [study.a]}",
                "{kind: parameter, parameters: study.a}",       # not a list
                "{kind: parameter, parameters: [nodots]}",      # not a config path
                '{kind: vendor, inputs: {d: {v: ""}}}',         # empty column
                '{kind: vendor, inputs: {"": {v: c}}}'):        # empty source name
        assert kind_of(src) == "bad_shape", src

    for src in ("{kind: derived}", "{kind: constant}",
                "{kind: parameter, parameters: [study.index_start]}",
                "{kind: vendor, inputs: {demographics: {b: birthyear}}}"):
        assert kind_of(src) != "bad_shape", src


def test_an_acceptance_run_must_be_the_cut_the_config_is_built_against():
    """A clean, complete 2026m05 profile is not evidence for a product configured at 2026m06.

    `profile_io` rejects a MIXED-cut file; nothing compared the single cut it does carry against
    `cfg.refresh`, so a whole-delivery profile of the wrong month passed as acceptance evidence.
    """
    import tempfile as _t
    import source_check
    HDR = ("profile_product_id\tprofile_schema\tprofile_cut\tprofile_source_mode\tprofile_mode\ttable\ttable_base\tcolumn\tkind\tsampled\tn_rows\tn_rows_total\tpct_missing\t"
           "distinct\tdate_min\tdate_max\ttop_values\n")
    with _t.TemporaryDirectory() as tmp:
        prod = Path(tmp) / "pack"
        (prod / "handoff").mkdir(parents=True)
        (prod / "config").mkdir()
        (prod / "handoff" / "FUNCTIONAL_CONTRACT.md").write_text(
            "```yaml\nvariable_id: AGE\nsource: {kind: vendor, inputs: "
            "{demographics: {b: birthyear}}}\n```\n")
        (prod / "config" / "data_product.yaml").write_text(
            "data_product_id: t\nname: t\nversion: '1'\nrun:\n  source_schema: s\n"
            "  refresh: 2026m06\nsources:\n  demographics: t_demographics\n")
        wrong = os.path.join(tmp, "old.tsv")
        open(wrong, "w", encoding="utf-8").write(
            HDR + "t\ts\t2026m05\tdbi\tfull\tt_demographics_2026m05\tt_demographics\tbirthyear\tinteger\tFALSE\t1\t1\t0\t1\t\t\tv\n")
        assert _exits(lambda p: source_check.check(str(prod), p, complete=True), wrong), \
            "a complete run on the wrong cut is evidence for a delivery nobody is building"
        right = os.path.join(tmp, "new.tsv")
        open(right, "w", encoding="utf-8").write(
            HDR + "t\ts\t2026m06\tdbi\tfull\tt_demographics_2026m06\tt_demographics\tbirthyear\tinteger\tFALSE\t1\t1\t0\t1\t\t\tv\n")
        _f, c = source_check.check(str(prod), right, complete=True)
        assert c["present"] == 1, c

        # A LAYOUT WITH NO CUT SUFFIX still identifies its delivery. The cut used to be read only
        # from the table NAME, which made a Flatiron convention load-bearing for every tumour:
        # `run.source_layout` is a documented per-product override and `{schema}` may appear inside
        # the physical name, so a pack whose tables are plainly `t_demographics` produced a profile
        # with no readable cut and was refused outright — for a cut the profiler had stamped on
        # every row. The stamp is what the run SAYS it measured; the suffix is an inference.
        (prod / "config" / "data_product.yaml").write_text(
            "data_product_id: t\nname: t\nversion: '1'\nrun:\n  source_schema: s\n"
            "  refresh: 2026m06\n  source_layout: '{schema}.{stem}'\n"
            "sources:\n  demographics: t_demographics\n")
        flat = os.path.join(tmp, "flat.tsv")
        open(flat, "w", encoding="utf-8").write(
            HDR + "t\ts\t2026m06\tdbi\tfull\tt_demographics\tt_demographics\tbirthyear\tinteger\tFALSE\t1\t1\t0\t1\t\t\tv\n")
        _f, c = source_check.check(str(prod), flat, complete=True)
        assert c["present"] == 1, c

        # ...and the stamp is still held to the config, so it is an identity, not a bypass.
        wrong_flat = os.path.join(tmp, "flat_old.tsv")
        open(wrong_flat, "w", encoding="utf-8").write(
            HDR + "t\ts\t2026m05\tdbi\tfull\tt_demographics\tt_demographics\tbirthyear\tinteger\tFALSE\t1\t1\t0\t1\t\t\tv\n")
        assert _exits(lambda p: source_check.check(str(prod), p, complete=True), wrong_flat), \
            "an unsuffixed layout must not let the wrong cut through"

        # A profile that states neither is refused — the two ways of knowing are both gone.
        anon_cut = os.path.join(tmp, "nocut.tsv")
        open(anon_cut, "w", encoding="utf-8").write(
            HDR + "t\ts\t\tdbi\tfull\tt_demographics\tt_demographics\tbirthyear\tinteger\tFALSE\t1\t1\t0\t1\t\t\tv\n")
        assert _exits(lambda p: source_check.check(str(prod), p, complete=True), anon_cut), \
            "a complete run must know which delivery it checked"


def test_gate4_reads_the_verdict_report_not_just_its_existence():
    """Checking "a file exists carrying the right contract hash" let a SHAPE-ONLY report satisfy the
    evidence requirement — no profile read at all — as could a partial run without --complete, or one
    whose own result was `failed`, or one no human had signed."""
    import tempfile as _t
    import product_gates
    CONTRACT = ("```yaml\nvariable_id: AGE\nsource: {kind: vendor, inputs: "
                "{demographics: {b: birthyear}}}\n```\n")
    with _t.TemporaryDirectory() as tmp:
        prod = Path(tmp) / "pack"
        (prod / "handoff").mkdir(parents=True)
        contract = prod / "handoff" / "FUNCTIONAL_CONTRACT.md"
        contract.write_text(CONTRACT)
        digest = hashlib.sha256(CONTRACT.encode()).hexdigest()

        def verdict(**over):
            fm = {"gate3_result": "passed", "contract_sha256": digest, "config_sha256": "none",
                  "profile_sha256": "abc123", "data_cut": "2026m06", "config_refresh": "none",
                  "schema_validation_config_sha256": "none",
                  "complete": "true", "schema_validation_sha256": "sv1", "profile_schema": "s",
                  "schema_validation_result": "passed_live", "schema_validation_cut": "2026m06",
                  "schema_validation_product_id": "p", "schema_validation_schema": "s",
                  "reviewed_by": "A. Person", "review_date": "2026-07-27"}
            fm.update({f: "0" for f in ("bad_shape", "not_a_column", "not_a_table",
                                        "unknown_source", "absent_column", "absent_table",
                                        "unchecked", "ambiguous_source",
                                        "derived_input_candidate")})
            fm.update(over)
            (prod / "handoff" / "SOURCE_VERDICTS.md").write_text(
                "---\n" + "".join(f"{k}: {v}\n" for k, v in fm.items()) + "---\n")
            return product_gates.verdict_evidence_errors("pack", str(prod), str(contract))

        assert verdict() == [], "a complete, passing, signed report is evidence"
        for field, over in (("profile_sha256", {"profile_sha256": "none"}),
                            ("complete", {"complete": "false"}),
                            ("gate3_result", {"gate3_result": "failed"}),
                            ("unchecked", {"unchecked": "3"}),
                            ("ambiguous_source", {"ambiguous_source": "1"}),
                            ("derived_input_candidate", {"derived_input_candidate": "2"}),
                            ("reviewed_by", {"reviewed_by": "TODO"}),
                            ("review_date", {"review_date": "TODO"}),
                            ("bad_shape", {"bad_shape": "2"}),
                            ("not_a_column", {"not_a_column": "1"}),
                            ("data_cut", {"config_refresh": "2026m07"})):
            errs = verdict(**over)
            assert any(field in e for e in errs), (field, errs)

        # A report from an older source_check has no front matter and cannot be checked at all.
        (prod / "handoff" / "SOURCE_VERDICTS.md").write_text(f"| contract sha256 | `{digest}` |\n")
        errs = product_gates.verdict_evidence_errors("pack", str(prod), str(contract))
        assert errs and "no machine-readable front matter" in errs[0], errs


def test_every_suite_actually_runs_the_way_ci_invokes_it():
    """CI runs each suite as `python3 <file>`, not under pytest.

    A suite without a `__main__` runner therefore executes its imports, defines its test functions,
    runs none of them, and exits 0 — a green step protecting nothing. That is the failure this repo
    keeps having to catch in other forms, and it bit the author of this very file: verifying with
    `pytest <file>` reported "no tests ran" for the script-style product suites and was read as a
    pass, while CI ran them properly and one of them was red.

    So: every suite CI globs must both HAVE a runner and exit non-zero when something fails.
    """
    import re as _re
    suites = sorted(glob.glob(str(REPO / "platform" / "tests" / "test_*.py")))
    suites += sorted(glob.glob(str(REPO / "products" / "*" / "*" / "*" / "handoff" / "tests" /
                                   "test_*.py")))
    assert suites, "found no suites to check — the glob is wrong, which would itself be silent"
    # A `__main__` block is the whole requirement: a failing assert inside it propagates and Python
    # exits 1 by itself, so demanding a literal `sys.exit(` flagged seventeen perfectly good suites.
    # Verified by injecting a failing assert into one and observing exit code 1.
    missing = [os.path.relpath(path, str(REPO)) for path in suites
               if not _re.search(r"(?m)^if __name__\s*==\s*[\"']__main__[\"']\s*:",
                                 open(path, encoding="utf-8").read())]
    assert not missing, ("these suites are invisible to CI — it runs them as scripts, so without a "
                         "`__main__` block that sys.exit()s on failure they pass by doing nothing: "
                         + ", ".join(missing))


def test_a_malformed_structured_source_cannot_look_like_a_clean_one():
    """The new shape introduced its own ways to pass by producing nothing to check.

    Every one of these was survivable: a typo'd `kind` fell through to the legacy sentinels, found
    none, defaulted to `constant` and left BOTH gates — a misspelling in the single most important
    field turning a vendor mapping into one nobody had to evidence. `kind: vendor` with no inputs,
    or an input whose value is a bare string, produced a record with zero columns and therefore zero
    findings, which is indistinguishable from a record that passed.
    """
    import tempfile as _t
    import source_check
    from contract_lint import source_kind, vendor_sourced, records

    bad = list(records("```yaml\nvariable_id: X\nsource: {kind: vndor, inputs: {d: {b: c}}}\n```\n"))[0]
    assert source_kind(bad) == "invalid"
    assert vendor_sourced(bad), "a record whose kind cannot be read must be held to the STRICTER rule"

    with _t.TemporaryDirectory() as tmp:
        prod = Path(tmp) / "pack"
        (prod / "handoff").mkdir(parents=True)
        for label, src in (
                ("unknown kind", "{kind: vndor, inputs: {demographics: {b: birthyear}}}"),
                ("vendor, no inputs", "{kind: vendor}"),
                ("input is not a map", "{kind: vendor, inputs: {demographics: birthyear}}"),
                ("input is empty", "{kind: vendor, inputs: {demographics: {}}}"),
                ("parameter names none", "{kind: parameter}")):
            (prod / "handoff" / "FUNCTIONAL_CONTRACT.md").write_text(
                f"```yaml\nvariable_id: X\nsource: {src}\n```\n")
            _f, c = source_check.check(str(prod))
            assert c["bad_shape"] == 1, (label, c)
            assert source_check.main([str(prod), "--check"]) == 1, label

    # An ACCEPTANCE run asserts every mapping was evidenced. `unchecked` says the opposite — nothing
    # was looked up because no config resolved the source — and it used to pass.
    HDR = ("profile_product_id\tprofile_schema\tprofile_cut\tprofile_source_mode\tprofile_mode\ttable\ttable_base\tcolumn\tkind\tsampled\tn_rows\tn_rows_total\tpct_missing\t"
           "distinct\tdate_min\tdate_max\ttop_values\n")
    with _t.TemporaryDirectory() as tmp:
        prod = Path(tmp) / "pack"
        (prod / "handoff").mkdir(parents=True)
        (prod / "handoff" / "FUNCTIONAL_CONTRACT.md").write_text(
            "```yaml\nvariable_id: AGE\nsource: {kind: vendor, inputs: "
            "{demographics: {b: birthyear}}}\n```\n")
        prof = os.path.join(tmp, "p.tsv")
        open(prof, "w", encoding="utf-8").write(
            HDR + "t\tfixture_schema\t2026m06\tdbi\tfull\tt_x_2026m06\tt_x\tc\tstring\tFALSE\t1\t1\t0\t1\t\t\tv\n")
        assert source_check.main([str(prod), "--profile", prof, "--check"]) == 0, \
            "a diagnostic run reports unchecked and passes"
        assert source_check.main([str(prod), "--profile", prof, "--complete", "--check"]) == 1, \
            "an acceptance run must not go green having verified nothing"


def test_a_complete_verdict_needs_the_pack_to_NAME_a_delivery():
    """THE DOCUMENTED GATE 3 CHAIN DID NOT RUN, AND THE REASON WAS UNREADABLE FROM THE MESSAGE.

    `run_product_profile.py` and `run_product_schema_check.py` take `--cut`/`--schema` and resolve
    the effective config from them. This tool reads the pack. With `refresh: REPLACE_ME` in
    `config/pipeline.yaml` — which is what every pack ships — the real profile was compared against
    the placeholder and refused for measuring "a different schema", when what had actually happened
    is that the pack named no delivery at all.

    Refused explicitly, and NOT fixed by adding overrides here: `product_gates.verdict` re-derives
    `delivery_sha256` from the CHECKOUT to decide whether the config still points at what was
    measured, so evidence produced under a flag the checkout does not carry could never be
    re-derived. Populating pipeline.yaml is not a governed edit — it sits outside the Gate 4 digest.
    """
    import tempfile as _t
    import source_check
    HDR = ("profile_product_id\tprofile_schema\tprofile_cut\tprofile_source_mode\tprofile_mode\t"
           "table\ttable_base\tcolumn\tkind\tsampled\tn_rows\tn_rows_total\tpct_missing\t"
           "distinct\tdate_min\tdate_max\ttop_values\n")
    ROW = ("t\trealschema\t2026m06\tdbi\tfull\tt_demographics_2026m06\tt_demographics\t"
           "birthyear\tstring\tFALSE\t1\t1\t0\t1\t\t\tv\n")

    def pack(tmp, refresh, schema):
        prod = Path(tmp) / "pack"
        (prod / "handoff").mkdir(parents=True, exist_ok=True)
        (prod / "config").mkdir(parents=True, exist_ok=True)
        (prod / "handoff" / "FUNCTIONAL_CONTRACT.md").write_text(
            "```yaml\nvariable_id: AGE\nsource: {kind: vendor, inputs: "
            "{demographics: {b: birthyear}}}\n```\n")
        (prod / "config" / "data_product.yaml").write_text(
            "data_product_id: t\nname: t\nversion: '1'\n"
            "sources:\n  demographics: t_demographics\n")
        (prod / "config" / "pipeline.yaml").write_text(
            f"run:\n  refresh: {refresh}\n  source_schema: {schema}\n")
        return str(prod)

    with _t.TemporaryDirectory() as tmp:
        prof = os.path.join(tmp, "p.tsv")
        open(prof, "w", encoding="utf-8").write(HDR + ROW)

        def refusal(prod):
            """The message, not just the exit. Both the unbound pack and a genuinely mismatched one
            exit — asserting only that one of them did passes with the check removed, because the
            placeholder then falls through to the schema comparison and is refused for the WRONG
            reason. The message is the whole finding."""
            try:
                source_check.main([prod, "--profile", prof, "--complete", "--check"])
            except SystemExit as exc:
                return str(exc)
            return ""

        unbound = pack(tmp, "REPLACE_ME", "REPLACE_ME")
        why = refusal(unbound)
        assert "names no delivery" in why, \
            f"a --complete verdict over a pack with no delivery bindings was refused as {why!r}"
        assert "measured schema" not in why, \
            "the placeholder is being reported as evidence from a different delivery"
        # ...and a DIAGNOSTIC run is untouched: it is not an approval record.
        assert source_check.main([unbound, "--profile", prof, "--check"]) == 0, \
            "the diagnostic half now needs delivery bindings it has never needed"

        # Populate the bindings and the same command reaches the real comparison. It still refuses
        # here (the fixture contract deliberately resolves nothing) — what matters is that it gets
        # PAST the unbound check, so the chain is runnable once a delivery is named.
        bound = pack(tmp, "2026m06", "realschema")
        assert source_check.main([bound, "--profile", prof, "--complete", "--check"]) in (0, 1)

        # A pack pointed at ANOTHER delivery still fails on the mismatch, which is the check the
        # unbound refusal must not have replaced.
        other = pack(tmp, "2026m06", "someotherschema")
        assert "measured schema" in refusal(other), \
            "a profile from a different schema was accepted"


def test_a_vendor_input_naming_a_dependency_needs_a_person():
    """A vendor input naming a variable the record already DEPENDS ON is usually a derived input in
    the wrong field — COHORTU lists `treat_flag` under `lot` and in depends_on.

    But it is a NAMING signal, not proof, and the live contract contains the counter-example: ETH
    reads the `race` COLUMN of demographics and depends on the RACE VARIABLE. RACE's own record maps
    `race: race` with no dependencies, so the column is real and removing it would corrupt ETH.

    So this reports, and blocks an ACCEPTANCE run rather than a diagnostic one — the same calibration
    `ambiguous_source` uses. A person moves it or confirms it.
    """
    import tempfile as _t
    import source_check
    with _t.TemporaryDirectory() as tmp:
        prod = Path(tmp) / "pack"
        (prod / "handoff").mkdir(parents=True)
        (prod / "handoff" / "FUNCTIONAL_CONTRACT.md").write_text(
            "```yaml\nvariable_id: COHORTU\nsource: {kind: vendor, inputs: "
            "{lot: {evidence: treat_flag, setting: linesetting}}}\n"
            "depends_on: [TREAT_FLAG]\n```\n")
        findings, c = source_check.check(str(prod))
        assert c["derived_input_candidate"] == 1, c
        assert c["unchecked"] == 1, "the genuine column is still checkable"
        assert [f[3] for f in findings if f[4] == "derived_input_candidate"] == ["treat_flag"]
        assert source_check.main([str(prod), "--check"]) == 0, "a diagnostic run reports it"


def test_the_structured_source_shape_makes_ambiguity_unreachable():
    """The same record, both shapes, against the same profile.

    Legacy names its sources in one string and its columns in one map, so a name living in two of
    them is undecidable — `status` in both LOT and mortality is `ambiguous_source`. The structured
    shape states one source per input, so the same profile answers exactly, and `ambiguous_source`
    cannot arise for it at all: there is only ever one table to look in.

    That is the whole point of the migration, and it is why the checker keeps ONE code path — both
    shapes normalise to a list of inputs, and the difference is just how many sources an entry has.
    """
    import tempfile as _t
    import source_check
    HDR = ("profile_product_id\tprofile_schema\tprofile_cut\tprofile_source_mode\tprofile_mode\ttable\ttable_base\tcolumn\tkind\tsampled\tn_rows\tn_rows_total\tpct_missing\t"
           "distinct\tdate_min\tdate_max\ttop_values\n")
    R = "t\ts\t2026m06\tdbi\tfull\t{0}_2026m06\t{0}\t{1}\tstring\tFALSE\t9\t9\t1.0\t3\t\t\tv\n"
    LEGACY = ("```yaml\nvariable_id: OS\nsource: {logical_table: \"lot + mortality\", "
              "columns: {status: status, death: dthdt}}\n```\n")
    STRUCTURED = ("```yaml\nvariable_id: OS\nsource: {kind: vendor, inputs: "
                  "{lot: {status: status}, mortality: {death: dthdt}}}\n```\n")

    def run(contract):
        with _t.TemporaryDirectory() as tmp:
            prod = Path(tmp) / "pack"
            (prod / "handoff").mkdir(parents=True)
            (prod / "config").mkdir()
            (prod / "handoff" / "FUNCTIONAL_CONTRACT.md").write_text(contract)
            (prod / "config" / "data_product.yaml").write_text(
                "data_product_id: t\nname: t\nversion: '1'\n"
                "run:\n  source_schema: s\n  refresh: 2026m06\n"
                "sources:\n  lot: t_lot\n  mortality: t_mort\n")
            prof = os.path.join(tmp, "p.tsv")
            open(prof, "w", encoding="utf-8").write(
                HDR + R.format("t_lot", "status") + R.format("t_mort", "status")
                + R.format("t_mort", "dthdt"))
            return source_check.check(str(prod), prof, complete=True)

    _f, legacy = run(LEGACY)
    assert legacy["ambiguous_source"] == 1, legacy

    findings, new = run(STRUCTURED)
    assert new["ambiguous_source"] == 0 and new["present"] == 2, new
    where = {f[3]: f[1] for f in findings if f[4] == "present"}
    assert where == {"status": "t_lot", "dthdt": "t_mort"}, \
        "each column resolves to the one source its input declares — `status` to LOT even though " \
        "mortality also carries a column of that name, which is exactly what legacy could not do"

    # The non-vendor kinds carry no columns and must not be asked for vendor evidence. `parameter`
    # must still NAME its parameters — a kind that declares nothing is a defect, not an exemption.
    for src in ("{kind: derived}", "{kind: constant}", "{kind: unavailable}",
                "{kind: parameter, parameters: [study.index_start]}"):
        _f, c = run(f"```yaml\nvariable_id: X\nsource: {src}\n```\n")
        assert c["not_vendor"] == 1 and c["present"] == 0 and c["bad_shape"] == 0, (src, c)


def test_a_multi_source_record_attributes_what_it_can_and_names_what_it_cannot():
    """The union could false-pass: a column found in the WRONG source of a multi-source record still
    read as present, which is not evidence for the mapping the requirement means.

    But a union that finds the column in exactly ONE source has in fact attributed it exactly, and
    that is the normal case — 38 of the 52 config-resolved prostate records are single-source before
    the question even arises. Only a name living in two of a record's OWN sources is undecidable.
    Reporting those instead of silently passing them turns the risk into a countable list, which is
    what makes the structured `inputs:` migration a scheduled change rather than a blocker.
    """
    import tempfile as _t
    import source_check
    HDR = ("profile_product_id\tprofile_schema\tprofile_cut\tprofile_source_mode\tprofile_mode\ttable\ttable_base\tcolumn\tkind\tsampled\tn_rows\tn_rows_total\tpct_missing\t"
           "distinct\tdate_min\tdate_max\ttop_values\n")
    R = "t\ts\t2026m06\tdbi\tfull\t{0}_2026m06\t{0}\t{1}\tstring\tFALSE\t9\t9\t1.0\t3\t\t\tv\n"
    with _t.TemporaryDirectory() as tmp:
        prod = Path(tmp) / "pack"
        (prod / "handoff").mkdir(parents=True)
        (prod / "config").mkdir()
        (prod / "handoff" / "FUNCTIONAL_CONTRACT.md").write_text(
            "```yaml\nvariable_id: OS\nsource: {logical_table: \"lot + mortality\", "
            "columns: {status: status, death: dthdt}}\n```\n")
        (prod / "config" / "data_product.yaml").write_text(
            "data_product_id: t\nname: t\nversion: '1'\n"
                "run:\n  source_schema: s\n  refresh: 2026m06\n"
            "sources:\n  lot: t_lot\n  mortality: t_mort\n")
        prof = os.path.join(tmp, "p.tsv")
        # `status` exists in BOTH of this record's sources; `dthdt` in only one.
        open(prof, "w", encoding="utf-8").write(
            HDR + R.format("t_lot", "status") + R.format("t_mort", "status")
            + R.format("t_mort", "dthdt"))

        findings, c = source_check.check(str(prod), prof, complete=True)
        assert c["ambiguous_source"] == 1 and c["present"] == 1, c
        found = {f[3]: f for f in findings}
        assert found["dthdt"][4] == "present" and found["dthdt"][1] == "t_mort", \
            "a name in only one source IS exactly attributed — and the report must say which"
        assert found["status"][4] == "ambiguous_source"

        # A diagnostic run reports it and passes; an ACCEPTANCE run must not go green on it, because
        # a green acceptance run reads as "every mapping verified".
        assert source_check.main([str(prod), "--profile", prof, "--check"]) == 0
        assert source_check.main([str(prod), "--profile", prof, "--complete", "--check"]) == 1


def test_one_profile_reader_serves_all_three_consumers():
    """Three tools read this TSV and each parsed it themselves.

    All three redefined the cut regex and the table_base rule, two redefined header validation and
    duplicate detection, and only `profile_facts.py` validated the VALUES. So the weakest
    reader set the floor: a profile with `sampled: MAYBE`, `n_rows > n_rows_total` or
    `pct_missing: 150` sailed through Gate 3 while failing the report a person actually reads.

    Two outputs are justified (a restricted report, a sanitized verdict). Two parsers
    were not: profile_facts and source_check now share this one.
    """
    import tempfile as _t
    import profile_io
    import source_check
    HDR = ("profile_product_id\tprofile_schema\tprofile_cut\tprofile_source_mode\tprofile_mode\ttable\ttable_base\tcolumn\tkind\tsampled\tn_rows\tn_rows_total\tpct_missing\t"
           "distinct\tdate_min\tdate_max\ttop_values\n")
    GOOD = "t\tfixture_schema\t2026m06\tdbi\tfull\tt_demographics_2026m06\tt_demographics\tbirthyear\tinteger\tFALSE\t10\t10\t2.1\t7\t\t\t3:x\n"

    with _t.TemporaryDirectory() as tmp:
        good = os.path.join(tmp, "good.tsv")
        open(good, "w", encoding="utf-8").write(HDR + GOOD)
        tables, cuts = profile_io.load(good)
        assert cuts == {"2026m06"} and "t_demographics" in tables

        # Every malformed shape the strict reader rejected must now be rejected for ALL of them.
        for label, row in (
                ("sampled not boolean",
                 "t\tfixture_schema\t2026m06\tdbi\tfull\tt_a_2026m06\tt_a\tc\tstring\tMAYBE\t5\t5\t1\t1\t\t\tv\n"),
                ("n_rows exceeds total",
                 "t\tfixture_schema\t2026m06\tdbi\tfull\tt_a_2026m06\tt_a\tc\tstring\tFALSE\t9\t3\t1\t1\t\t\tv\n"),
                ("missingness out of range",
                 "t\tfixture_schema\t2026m06\tdbi\tfull\tt_a_2026m06\tt_a\tc\tstring\tFALSE\t5\t5\t150\t1\t\t\tv\n"),
                ("duplicate table.column",
                 "t\tfixture_schema\t2026m06\tdbi\tfull\tt_a_2026m06\tt_a\tc\tstring\tFALSE\t5\t5\t1\t1\t\t\tv\n" * 2)):
            bad = os.path.join(tmp, "bad.tsv")
            open(bad, "w", encoding="utf-8").write(HDR + row)
            assert _exits(profile_io.load, bad), label
            # ...and it reaches Gate 3, which used to accept all four.
            prod = Path(tmp) / "pack"
            if not prod.exists():
                (prod / "handoff").mkdir(parents=True)
                (prod / "handoff" / "FUNCTIONAL_CONTRACT.md").write_text(
                    "```yaml\nvariable_id: AGE\nsource: {logical_table: d, "
                    "physical_stem: t_demographics, columns: {b: birthyear}}\n```\n")
            assert _exits(lambda p: source_check.check(str(prod), p), bad), f"Gate 3: {label}"


def test_gate3_handles_a_tumour_it_has_never_seen():
    """The copy-and-go drill, for a tumour that does not exist in this repo.

    A synthetic SCLC pack: a different vendor (COTA), sources no other tumour has (`brain_mets`,
    `smoking`), a multi-source record, and no `physical_stem` anywhere. It passes with no change to
    any tool, which is the claim — the framework holds no tumour's names.

    Then the axis that DID break: a vendor whose tables are not `{stem}_{refresh}`. Comparing the
    configured stem against a `pre_`-prefixed table reported every column of every source ABSENT —
    six false defects. The base has to come from the layout the engine will actually use.
    """
    import tempfile as _t
    import source_check
    HDR = ("profile_product_id\tprofile_schema\tprofile_cut\tprofile_source_mode\tprofile_mode\ttable\ttable_base\tcolumn\tkind\tsampled\tn_rows\tn_rows_total\tpct_missing\t"
           "distinct\tdate_min\tdate_max\ttop_values\n")
    CONTRACT = (
        "```yaml\nvariable_id: BRAINMET\nsource: {logical_table: brain_mets, "
        "columns: {date: metdate, site: metsite}}\n```\n"
        "```yaml\nvariable_id: SMKSTAT\nsource: {logical_table: smoking, "
        "columns: {status: smokingstatus}}\n```\n"
        "```yaml\nvariable_id: OS\nsource: {logical_table: \"lot + mortality\", "
        "columns: {start: linestart, death: deathdate}}\n```\n")
    SOURCES = {"lot": "ct_sclc_lot", "mortality": "ct_mortality",
               "brain_mets": "ct_sclc_brainmet", "smoking": "ct_sclc_smoke"}
    COLS = [("ct_sclc_brainmet", "metdate"), ("ct_sclc_brainmet", "metsite"),
            ("ct_sclc_smoke", "smokingstatus"), ("ct_sclc_lot", "linestart"),
            ("ct_mortality", "deathdate")]

    def run(layout=None, prefix=""):
        with _t.TemporaryDirectory() as tmp:
            prod = Path(tmp) / "sclc"
            (prod / "handoff").mkdir(parents=True)
            (prod / "config").mkdir()
            (prod / "handoff" / "FUNCTIONAL_CONTRACT.md").write_text(CONTRACT)
            (prod / "config" / "data_product.yaml").write_text(
                "data_product_id: sclc\nname: SCLC\nversion: '202609'\nvendor: cota\n"
                "run:\n  source_schema: sclc_db\n  refresh: 2026m09\n"
                + (f"  source_layout: \"{layout}\"\n" if layout else "")
                + "sources:\n" + "".join(f"  {k}: {v}\n" for k, v in SOURCES.items()))
            prof = os.path.join(tmp, "p.tsv")
            open(prof, "w", encoding="utf-8").write(HDR + "".join(
                f"sclc\tsclc_db\t2026m09\tdbi\tfull\t{prefix}{t}_2026m09\t{prefix}{t}\t{c}\tstring\tFALSE\t10\t10\t1.0\t3\t\t\tx\n"
                for t, c in COLS))
            return source_check.check(str(prod), prof, complete=True)

    _f, a = run()
    assert a["present"] == 5 and a["resolved_via_config"] == 3, a
    assert a["absent_table"] == 0 and a["absent_column"] == 0 and a["not_vendor"] == 0, a

    # Same pack, a vendor layout that prefixes every table. Nothing in the contract changes.
    _f, b = run(layout="{schema}.pre_{stem}_{refresh}", prefix="pre_")
    assert b["present"] == 5 and b["absent_table"] == 0, \
        "the base must come from the layout the engine will use, not from the configured stem"

    # A union product reads every source from EVERY member schema, and members share a stem — so one
    # profile looks like full coverage while proving nothing about the others. That is a false PASS
    # on the gate whose job is to stop unverified mappings. Endometrial declares one today.
    with _t.TemporaryDirectory() as tmp:
        prod = Path(tmp) / "ec"
        (prod / "handoff").mkdir(parents=True)
        (prod / "config").mkdir()
        (prod / "handoff" / "FUNCTIONAL_CONTRACT.md").write_text(CONTRACT)
        (prod / "config" / "data_product.yaml").write_text(
            "data_product_id: ec\nname: EC\nversion: '1'\nvendor: flatiron\n"
            "run:\n  source_schema: edm\n  refresh: 2026m09\n"
            "sources:\n" + "".join(f"  {k}: {v}\n" for k, v in SOURCES.items())
            + "source_union:\n  discriminator: db\n  members:\n"
              "    - schema: edm\n    - schema: dostar\n")
        prof = os.path.join(tmp, "p.tsv")
        open(prof, "w", encoding="utf-8").write(HDR + "".join(
            f"t\tsclc_db\t2026m09\tdbi\tfull\t{t}_2026m09\t{t}\t{c}\tstring\tFALSE\t9\t9\t1.0\t3\t\t\tx\n" for t, c in COLS))
        # Reporting is fine — it claims nothing. Asserting COMPLETENESS over one profile is not.
        _f, ok = source_check.check(str(prod), prof)
        assert ok["present"] == 5, ok
        assert _exits(source_check.main, [str(prod), "--profile", prof, "--complete", "--check"])


def test_gate3_survives_the_contract_dropping_physical_stem_and_the_delivery_renaming_columns():
    """Three defects found by testing the claim that `physical_stem` was now redundant.

    It was not. Vendor-or-not was decided from the stem alone, so a correct record that had dropped
    it was counted `not_vendor` and vanished from Gate 3 AND from Gate 4's evidence requirement — the
    deletion would have read as a cleanup and acted as a silent exemption.

    Partial logical resolution fell back to the single stem. `lot + mortality + nosuchsource`
    searched only the LOT table and reported `dthdt` as ABSENT_COLUMN over the message "every source
    table of this record is in the profile", which was false — reintroducing exactly the wrong-table
    lookup config resolution was added to remove.

    And a delivery that renames a physical COLUMN was not handled at all. The engine's overlay
    renames vendor columns into logical names at source load; a profile is taken before that, so it
    carries the physical name. The contract must survive that unedited, which is the whole point.
    """
    import tempfile as _t
    import source_check
    HDR = ("profile_product_id\tprofile_schema\tprofile_cut\tprofile_source_mode\tprofile_mode\ttable\ttable_base\tcolumn\tkind\tsampled\tn_rows\tn_rows_total\tpct_missing\t"
           "distinct\tdate_min\tdate_max\ttop_values\n")
    ROW = "t\ts\t2026m06\tdbi\tfull\t{0}_2026m06\t{0}\t{1}\tinteger\tFALSE\t10\t10\t2.1\t7\t\t\tx\n"
    BASE = ("data_product_id: t\nname: t\nversion: '1'\n"
            "run:\n  source_schema: s\n  refresh: 2026m06\n")

    def run(contract, cfg_yaml, rows):
        with _t.TemporaryDirectory() as tmp:
            prod = Path(tmp) / "pack"
            (prod / "handoff").mkdir(parents=True)
            (prod / "config").mkdir()
            (prod / "handoff" / "FUNCTIONAL_CONTRACT.md").write_text(contract)
            (prod / "config" / "data_product.yaml").write_text(cfg_yaml)
            prof = os.path.join(tmp, "p.tsv")
            open(prof, "w", encoding="utf-8").write(HDR + "".join(ROW.format(*r) for r in rows))
            return source_check.check(str(prod), prof, complete=True)

    # 1. No physical_stem at all — the shape a migrated record has.
    _f, a = run("```yaml\nvariable_id: AGE\nsource: {logical_table: demographics, "
                "columns: {birth_year: birthyear}}\n```\n",
                BASE + "sources:\n  demographics: t_demographics\n",
                [("t_demographics", "birthyear")])
    assert a["present"] == 1 and a["not_vendor"] == 0 and a["resolved_via_config"] == 1, a

    # ...and Gate 4 must still demand evidence for it, or dropping the field buys an exemption.
    from contract_lint import unverified_sources
    assert [v for v, _w in unverified_sources(
        "```yaml\nvariable_id: AGE\nsource: {logical_table: demographics, columns: {c: col}}\n"
        "status: {requirement: draft, source: unverified}\n```\n")] == ["AGE"]

    # 2. One logical source config does not define: fatal, and NOT a fallback to the stem.
    findings, b = run("```yaml\nvariable_id: X\nsource: {logical_table: \"lot + mortality + nope\", "
                      "physical_stem: t_lot, columns: {death: dthdt}}\n```\n",
                      BASE + "sources:\n  lot: t_lot\n  mortality: t_mortality\n",
                      [("t_lot", "enddate"), ("t_mortality", "dthdt")])
    assert b["unknown_source"] == 1, b
    assert b["absent_column"] == 0, "a source we could not resolve cannot make a column absent"
    assert any("nope" in f[5] and "lot, mortality" in f[5] for f in findings), findings

    # 3. The delivery renames both the table AND the column. The contract states neither.
    _f, c = run("```yaml\nvariable_id: AGE\nsource: {logical_table: demographics, "
                "columns: {birth_year: birthyear}}\n```\n",
                BASE + "sources:\n  demographics: t_demographics\ndata_format: Panoramic\n"
                "formats:\n  Panoramic:\n    sources:\n      demographics: dem_v2\n"
                "    rename:\n      demographics:\n        BirthYearValue: birthyear\n",
                [("dem_v2", "birthyearvalue")])
    assert c["present"] == 1 and c["absent_column"] == 0, \
        "the profile predates the rename, so it carries BirthYearValue — searching for birthyear " \
        "would call a column absent that the build reads perfectly well"


def test_gate3_checks_the_table_stem_the_same_way_it_checks_a_column():
    """`physical_stem` was looked up verbatim but never validated.

    Three live records carry a stem that is not one table name — a six-table comma list, `a + b`, and
    `x (unconfirmed)`. Each was searched for as though a table by that name existed, so under
    --complete each would have produced a false ABSENT_TABLE. A stem that names no table is the same
    class of contract defect as a column that names no column, and its columns cannot then be
    reported absent from anywhere."""
    import tempfile as _t
    import source_check
    TSV = ("profile_product_id\tprofile_schema\tprofile_cut\tprofile_source_mode\tprofile_mode\ttable\ttable_base\tcolumn\tkind\tsampled\tn_rows\tn_rows_total\tpct_missing\t"
           "distinct\tdate_min\tdate_max\ttop_values\n"
           "t\tfixture_schema\t2026m06\tdbi\tfull\tt_demographics_2026m06\tt_demographics\tbirthyear\tinteger\tFALSE\t10\t10\t2.1\t7\t\t\tx\n")
    with _t.TemporaryDirectory() as tmp:
        prof = os.path.join(tmp, "p.tsv")
        open(prof, "w", encoding="utf-8").write(TSV)
        prod = Path(tmp) / "pack"
        (prod / "handoff").mkdir(parents=True)
        (prod / "handoff" / "FUNCTIONAL_CONTRACT.md").write_text(
            "```yaml\nvariable_id: FU_ENDDT\nsource: {logical_table: several, "
            "physical_stem: \"t_visit,t_telemedicine\", columns: {end: fuenddate}}\n```\n"
            "```yaml\nvariable_id: PSMA\nsource: {logical_table: psma, "
            'physical_stem: "t_psmapet (unconfirmed)", columns: {d: testdate}}\n```\n'
            "```yaml\nvariable_id: AGE\nsource: {logical_table: d, physical_stem: t_demographics, "
            "columns: {birth_year: birthyear}}\n```\n")

        # Even asserting a COMPLETE profile, the two bad stems are contract defects — not absences.
        findings, counts = source_check.check(str(prod), prof, complete=True)
        assert counts["not_a_table"] == 2, counts
        assert counts["absent_table"] == 0, "a stem that names no table cannot be absent from one"
        assert counts["unchecked"] == 2, "their columns were never looked up anywhere"
        assert counts["present"] == 1, "the well-formed record is still checked"
        assert source_check.main([str(prod), "--profile", prof, "--check"]) == 1, \
            "a stem defect fails without --complete: it is a defect of the contract"

        # The verdict must be bound to the contract it judged, or renaming a column leaves the report
        # looking current — same profile checksum, different contract.
        md = source_check.render(str(prod), prof, findings, counts, complete=True)
        assert source_check.sha256(prod / "handoff" / "FUNCTIONAL_CONTRACT.md") in md

    # A `source:` written as an indented block reads as no inline mapping. Skipping it would drop the
    # record out of Gate 3 silently, and silence is what a passing record looks like.
    with _t.TemporaryDirectory() as tmp:
        prod = Path(tmp) / "pack"
        (prod / "handoff").mkdir(parents=True)
        (prod / "handoff" / "FUNCTIONAL_CONTRACT.md").write_text(
            "```yaml\nvariable_id: AGE\nsource:\n  physical_stem: t_demographics\n"
            "  columns:\n    birth_year: birthyear\n```\n")
        _f, counts = source_check.check(str(prod))
        assert counts["bad_shape"] == 1, "a source Gate 3 cannot read is a SHAPE defect — and being "\
            "a shape defect is what makes the Stage 1 CI gate catch it"



def test_gate4_reads_the_source_status_axes_and_not_the_file_text():
    """Gate 3-before-Gate 4 was enforced by counting the string `source: unverified`.

    A text scan of a structured field fails in both directions: rewriting the label to
    `dictionary_only` silenced it while no evidence changed hands, and the same words inside a
    comment counted as a real record. It also could not see the four finer axes at all — a record
    written exactly as WORKFLOW.md section 7 instructs was invisible to it."""
    from contract_lint import unverified_sources
    REC = ("```yaml\nvariable_id: %s\nsource: {logical_table: d, physical_stem: %s, "
           "columns: {c: col}}\nstatus: {requirement: approved, %s, implementation: implemented, "
           "validation: not_run}\n```\n")
    coarse = REC % ("AGE", "t_demographics", "source: unverified")
    assert [v for v, _w in unverified_sources(coarse)] == ["AGE"]

    # The relabel loophole: same evidence, softer word.
    assert [v for v, _w in unverified_sources(REC % ("AGE", "t_demographics", "source: dictionary_only"))] \
        == ["AGE"], "a dictionary says what a column is called, not that this delivery carries it"
    # At Gate 4 the coarse axis is no longer enough — not even `verified`. WORKFLOW.md section 7 says
    # the finer axes are adopted at Gate 3, and Gate 4 comes after, so a single word standing for all
    # four questions at the point of configuration approval is the conflation the axes undo.
    got = unverified_sources(REC % ("AGE", "t_demographics", "source: verified"))
    assert [v for v, _w in got] == ["AGE"] and "finer axes" in got[0][1], got
    # A declared gap is the one exception: there is no mapping to have verified. But the WORD
    # declares nothing — without a gap id it is an unevidenced record wearing the one label that
    # skips the evidence check, so the exception has to name what it is an exception for.
    assert [v for v, _w in unverified_sources(REC % ("AGE", "t_demographics", "source: unavailable"))] \
        == ["AGE"], "unavailable with no gap_ids must not buy an exemption"
    with_gap = (REC % ("AGE", "t_demographics", "source: unavailable")
                ).replace("\n```\n", "\ngap_ids: [G-ASSAY-TYPE]\n```\n")
    assert unverified_sources(with_gap) == []

    # A build parameter has no vendor table to have verified. `n/a` in particular: reading the stem
    # with the shared `_kv` helper truncated it to `n`, which reads as a table name. Every live
    # sentinel record marks BOTH fields — `logical_table: (derived), physical_stem: n/a` — and the
    # record is exempt only when neither field names a source.
    SENT = ("```yaml\nvariable_id: MININDEX\nsource: {logical_table: %s, physical_stem: %s, "
            "columns: {c: col}}\nstatus: {requirement: approved, source: unverified, "
            "implementation: implemented, validation: not_run}\n```\n")
    for kind in ("(constant)", "(build_parameter)", "(derived)"):
        assert unverified_sources(SENT % (kind, "n/a")) == [], kind
    # A sentinel stem beside a REAL logical source is still vendor-sourced. This is the direction
    # migration moves in — config owns the physical name — so it must not read as an exemption.
    assert [v for v, _w in unverified_sources(SENT % ("demographics", "n/a"))] == ["MININDEX"]

    # The finer axes, which the text scan could not see at all.
    fine_open = ("source_mapping: proposed, dictionary_check: not_run, live_schema_check: not_run, "
                 "data_profile_check: not_run")
    fine_done = ("source_mapping: human_confirmed, dictionary_check: passed, "
                 "live_schema_check: passed, data_profile_check: accepted")
    assert [v for v, _w in unverified_sources(REC % ("AGE", "t_demographics", fine_open))] == ["AGE"]
    assert unverified_sources(REC % ("AGE", "t_demographics", fine_done)) == []
    # Confirming the mapping by hand is not the same as checking it against a delivery.
    half = fine_done.replace("live_schema_check: passed", "live_schema_check: not_run")
    assert [v for v, _w in unverified_sources(REC % ("AGE", "t_demographics", half))] == ["AGE"]

    # Text in a comment is not a record.
    assert unverified_sources("<!-- status: {source: unverified} -->\n") == []

    # Not every feed ships a data dictionary. Requiring `passed` from a document that does not exist
    # made these axes unadoptable — the product had to fall back to the coarse axis, which is exactly
    # the conflation they undo. `not_available` states the fact, and is accepted ONLY beside the two
    # checks that read the actual delivery.
    def fine(**kw):
        base = {"source_mapping": "human_confirmed", "dictionary_check": "passed",
                "live_schema_check": "passed", "data_profile_check": "accepted"}
        base.update(kw)
        return REC % ("AGE", "t_demographics", ", ".join(f"{k}: {v}" for k, v in base.items()))

    assert unverified_sources(fine(dictionary_check="not_available")) == [], \
        "a missing dictionary must not block a mapping the data has already evidenced"
    # ...and must not excuse a check that was skipped. Gate 4 already demands those two of EVERY
    # record, so the corroboration `not_available` needs is the general rule — a second, dictionary
    # -specific statement of it was a branch that could never fire, and it has been removed.
    for axis in ("live_schema_check", "data_profile_check"):
        got = unverified_sources(fine(dictionary_check="not_available", **{axis: "not_run"}))
        assert [v for v, _w in got] == ["AGE"] and axis in got[0][1], (axis, got)
    # `failed` is a verdict, not an absent document — it blocks either way.
    assert [v for v, _w in unverified_sources(fine(dictionary_check="failed"))] == ["AGE"]


def _exits(fn, argv):
    """True if `fn(argv)` refuses via sys.exit. The tools fail closed with a message rather than a
    return code when the request itself is malformed, so that is what a test has to catch."""
    try:
        fn(argv)
    except SystemExit:
        return True
    return False


def test_gate3_contract_shape_runs_without_any_vendor_material():
    """The half of Gate 3 that found every current failure needs no profile.

    `max(specimencollecteddate, resultdate)` is not askable of any profile — that is a defect of the
    CONTRACT, discoverable with nothing vendor-derived in the room. Keeping it behind a required
    `--profile` meant it could only ever run on a machine holding restricted material, so CI could not
    run it and the 16 live defects sat unseen. Without a profile the tool must also not turn "not
    looked up" into "not found": a name it never asked about is `unchecked`, not `not_in_profile`.
    """
    import tempfile as _t
    import source_check
    with _t.TemporaryDirectory() as tmp:
        prod = Path(tmp) / "pack"
        (prod / "handoff").mkdir(parents=True)
        (prod / "handoff" / "FUNCTIONAL_CONTRACT.md").write_text(
            "```yaml\nvariable_id: AGE\nsource: {logical_table: d, physical_stem: t_demographics, "
            "columns: {birth_year: birthyear}}\n```\n"
            "```yaml\nvariable_id: LAB\nsource: {logical_table: lab, physical_stem: t_lab, "
            'columns: {date: "later-of(testdate, resultdate)"}}\n```\n')

        findings, counts = source_check.check(str(prod))          # no profile at all
        assert counts["not_a_column"] == 1, "the contract defect must still be found"
        assert counts["unchecked"] == 1, "birthyear is askable but was never asked"
        for silent in ("present", "not_in_profile", "unprofiled", "absent_column", "absent_table"):
            assert counts[silent] == 0, f"{silent} claims a lookup that never happened"
        md = source_check.render(str(prod), None, findings, counts)
        assert "contract shape only" in md
        assert "profile sha256" not in md, "no profile was read, so none can be attested"

        # ...and --check fails on it, which is what makes the half worth running.
        assert source_check.main([str(prod), "--check"]) == 1
        # Completeness is a claim ABOUT a profile; asserting it without one is meaningless.
        assert _exits(source_check.main, [str(prod), "--complete", "--check"])

    # A pack with no contract is not a Gate 3 failure — it is a pack Gate 3 does not apply to. This
    # used to raise FileNotFoundError, which stopped a loop over discovered packs at the first one.
    with _t.TemporaryDirectory() as tmp:
        (Path(tmp) / "handoff").mkdir()
        assert source_check.main([tmp, "--check"]) == 0
    # A path that does not exist is a different thing, and must not pass quietly.
    assert _exits(source_check.main, [str(Path(tmp) / "gone"), "--check"])


def test_the_template_carries_what_the_pipeline_requires():
    """Copy-and-go has to actually go.

    The template had no source_refs.yaml at all, so the first thing a new tumour hit after binding the
    extractor to the source record was a KeyError traceback from a tool it had never heard of. A
    template that does not satisfy the machinery is a trap that only fires on whoever onboards next.
    """
    tmpl = REPO / "platform" / "TUMOR_TEMPLATE"
    refs = tmpl / "source_refs.yaml"
    assert refs.exists(), "TUMOR_TEMPLATE has no source_refs.yaml — a copied pack cannot be extracted"

    import yaml
    doc = yaml.safe_load(refs.read_text(encoding="utf-8"))
    ids = [m.get("material_id") for m in doc["source_materials"]]
    conf = (tmpl / "spec_pipeline" / "pipeline.conf").read_text(encoding="utf-8")
    src_id = re.search(r"(?m)^\s*SPEC_SOURCE_ID\s*=\s*(\S+)", conf).group(1)
    assert src_id in ids, \
        f"the template's SPEC_SOURCE_ID={src_id} names no material in its own source_refs.yaml: {ids}"
    assert sum(1 for m in doc["source_materials"]
               if m.get("material_type") == "program_spec") == 1, \
        "the template must ship exactly one authoritative program_spec, like every real pack"

    # Same shape the live packs are held to, so the template cannot pass a schema the packs fail.
    schema = _json.loads((REPO / "governance" / "schemas" / "source_refs.schema.json")
                        .read_text(encoding="utf-8"))
    item_req = schema["properties"]["source_materials"]["items"]["required"]
    for m in doc["source_materials"]:
        for k in item_req:
            assert k in m, f"template source material missing '{k}': {m}"


def test_no_record_is_approved_on_an_unapproved_specification():
    """The pack-level rule was not enough. Prostate 202606 held 44 records at requirement:approved on
    a source with a TBD link, no revision, no checksum and no approver, while MATURITY.yaml sat below
    contract:approved — so nothing ever fired. Approving a requirement is a statement ABOUT the
    specification; it cannot outrank the specification's own status."""
    import tempfile as _t
    RECORD = ("```yaml\nvariable_id: %s\nspec_refs: [clinical:1]\n"
              "status: {requirement: %s, source: unverified, implementation: implemented, "
              "validation: not_run}\n```\n")
    with _t.TemporaryDirectory() as tmp:
        prod = _pack(tmp, "coverage_complete")
        pending = {"path_or_link": "TBD", "role": "spec", "status": "pending",
                   "why_provisional": "not yet supplied"}
        _refs(prod, pending)
        (prod / "handoff" / "FUNCTIONAL_CONTRACT.md").write_text(
            RECORD % ("AGE", "approved") + RECORD % ("SEX", "draft"))
        errs = source_manifest.check(tmp, REL)
        assert any("requirement:approved" in e and "AGE" in e for e in errs), errs

        # draft and decision_required are fine on a provisional source — that is the normal state.
        (prod / "handoff" / "FUNCTIONAL_CONTRACT.md").write_text(
            RECORD % ("AGE", "draft") + RECORD % ("SEX", "decision_required"))
        assert source_manifest.check(tmp, REL) == []

    # ...and the live packs hold to it.
    assert source_manifest.main(["--all", "--check"]) == 0, \
        "Gate 1 refused a live pack — run `python3 platform/tools/source_manifest.py --all --check`\n        from the repo root; the errors above name the pack, the material index and the field owed"


def test_an_approved_document_does_not_bless_the_copy_the_pipeline_reads():
    """The loophole the source binding was built to close, one level down.

    With an approved workbook registered and a PENDING stand-in actually extracted, the pack
    could truthfully say "workbook A was approved" while every record was drafted from a copy nobody
    checked against A. Approving records needs both: the document approved, and the thing actually
    read verified against it.
    """
    import tempfile as _t
    with _t.TemporaryDirectory() as tmp:
        prod = _pack(tmp, "coverage_complete")
        (prod / "spec_pipeline").mkdir()
        (prod / "spec_pipeline" / "pipeline.conf").write_text("TUMOR=x\nSPEC_SOURCE_ID=tabs\n")
        (prod / "tabs.md").write_text("| 1 | AGE |\n")
        (prod / "handoff" / "FUNCTIONAL_CONTRACT.md").write_text(
            "```yaml\nvariable_id: AGE\nspec_refs: [clinical:1]\n"
            "status: {requirement: approved, source: unverified, implementation: implemented, "
            "validation: not_run}\n```\n")
        (prod / "spec.xlsx").write_bytes(b"the approved workbook")
        approved_spec = {"path_or_link": f"{REL}/spec.xlsx", "role": "the approved workbook",
                         "status": "reviewed",
                         "document_id": "X-1", "revision": "r1",
                         "sha256": source_manifest.sha256(str(prod / "spec.xlsx")),
                         "approval_date": "2026-01-01", "approved_by": "J.S.",
                         "material_type": "program_spec", "data_refresh": "2026m06",
                         "ai_classification": "sponsor_ai_eligible",
                         "rwb_qc_reference": "RWB-QC-2026-01"}
        tabs = {"material_id": "tabs", "material_type": "extraction_input",
                "derived_from": "program_spec", "path_or_link": f"{REL}/tabs.md",
                "role": "stand-in", "status": "pending",
                "why_provisional": "nobody compared it with the approved workbook"}
        _refs(prod, approved_spec, tabs)

        assert source_manifest.source_status(str(prod)) == "approved", "the DOCUMENT is approved"
        errs = source_manifest.check(tmp, REL)
        assert any("the material the pipeline extracts" in e for e in errs), errs

        # Approving the DERIVATIVE with the same fields as a document is still not enough. Those
        # fields say "this artifact is approved"; none of them says anyone compared it against the
        # workbook, which is the one thing a stand-in needs.
        approved_tabs = {**tabs, "status": "reviewed", "document_id": "X-1-T", "revision": "t1",
                         "sha256": source_manifest.sha256(str(prod / "tabs.md")),
                         "approval_date": "2026-01-02", "approved_by": "A. Checker"}
        _refs(prod, approved_spec, approved_tabs)
        errs = source_manifest.check(tmp, REL)
        assert any("who checked it against the authoritative document" in e for e in errs), errs

        # With the attestation recorded, and pinned to the revision it was made against.
        attested = {**approved_tabs, "attested_by": "A. Checker",
                    "attestation_date": "2026-01-02",
                    "attested_against_sha256": approved_spec["sha256"]}
        _refs(prod, approved_spec, attested)
        assert source_manifest.check(tmp, REL) == []

        # Revise the workbook and the attestation no longer covers it — it would otherwise survive
        # the very thing it attested to.
        (prod / "spec.xlsx").write_bytes(b"a REVISED workbook")
        _refs(prod, {**approved_spec, "sha256": source_manifest.sha256(str(prod / "spec.xlsx")),
                     "revision": "r2"}, attested)
        errs = source_manifest.check(tmp, REL)
        assert any("a different revision of the workbook" in e for e in errs), errs


def test_supporting_material_may_not_be_the_pipeline_source():
    """A methodology note or vendor reference is context. Extracting one would produce a contract
    traceable to a document that is not the requirement."""
    import tempfile as _t
    with _t.TemporaryDirectory() as tmp:
        prod = _pack(tmp, "draft")
        (prod / "spec_pipeline").mkdir()
        (prod / "spec_pipeline" / "pipeline.conf").write_text("TUMOR=x\nSPEC_SOURCE_ID=method\n")
        _refs(prod,
              {"path_or_link": "TBD", "role": "spec", "status": "pending", "why_provisional": "a"},
              {"material_id": "method", "material_type": "supporting", "path_or_link": "TBD",
               "role": "methodology", "status": "pending", "why_provisional": "b"})
        assert any("may be the specification the contract is written from"
                   in e for e in source_manifest.check(tmp, REL))


def test_a_spec_tab_directory_can_be_frozen_like_a_workbook():
    """The checksum is the whole point of an approval record, and the per-tab path is a DIRECTORY —
    the hasher opened one path as a file, so a stand-in could never be moved to reviewed."""
    import tempfile as _t
    with _t.TemporaryDirectory() as tmp:
        d = Path(tmp) / "tabs"; d.mkdir()
        (d / "b.md").write_text("second tab")
        (d / "a.md").write_text("first tab")
        before = source_manifest.sha256(str(d))
        assert len(before) == 64
        assert source_manifest.sha256(str(d)) == before, "the digest must not depend on walk order"

        (d / "a.md").write_text("first tab, edited")
        assert source_manifest.sha256(str(d)) != before, "a changed tab must change the digest"

        # Renaming with identical content must move it too: hashing bytes alone would let two tabs be
        # swapped, or one renamed, with the digest unchanged.
        (d / "a.md").write_text("first tab")
        (d / "b.md").rename(d / "c.md")
        assert source_manifest.sha256(str(d)) != before


def test_the_source_status_is_derived_not_stored():
    """MATURITY.yaml used to restate the source's status, and a rule existed to check the two copies
    agreed. One fact, one place: the status IS whether a material is reviewed."""
    import tempfile as _t
    assert "source_document" not in product_gates.maturity(str(REPO / "products/oncology/prostate/202606"))
    with _t.TemporaryDirectory() as tmp:
        prod = _pack(tmp, "draft")
        _refs(prod, {"path_or_link": "TBD", "role": "a scan", "status": "pending",
                     "why_provisional": "not signed"})
        assert source_manifest.source_status(str(prod)) == "provisional"



def test_gate3_refuses_evidence_that_cannot_prove_where_it_came_from():
    """A --complete verdict is an approval record, so the profile behind it must identify itself.

    Before the profiler stamped identity onto every row, `--union-member X` was an operator
    assertion nothing could corroborate: union members share a table stem, so the file itself could
    not say which schema produced it. These are the four ways that assertion can now be falsified.
    """
    import tempfile as _t
    import source_check
    # From profile_io, not restated: this list spelled out four columns while the profiler stamped
    # five, so growing it left this test writing a profile the gate refuses for a reason the test is
    # not about — and `refuses(...)` would have kept returning True for the wrong reason.
    import profile_io
    IDENT = list(profile_io.PROVENANCE)
    REST = ["table", "table_base", "column", "kind", "sampled", "n_rows", "n_rows_total",
            "pct_missing", "distinct", "date_min", "date_max", "top_values"]
    VALS = ["t_demographics_2026m06", "t_demographics", "birthyear", "integer", "FALSE",
            "9", "9", "1.0", "3", "", "", "v"]

    def run(pid="realprod", schema="realschema", cut="2026m06", mode="dbi",
            pmode=profile_io.FULL_PROFILE, anonymous=False):
        ident = {"profile_product_id": pid, "profile_schema": schema, "profile_cut": cut,
                 "profile_source_mode": mode, "profile_mode": pmode}
        assert set(ident) == set(IDENT), f"no fixture value for {set(IDENT) - set(ident)}"
        cols = REST if anonymous else IDENT + REST
        vals = VALS if anonymous else [ident[c] for c in IDENT] + VALS
        with _t.TemporaryDirectory() as tmp:
            prod = Path(tmp) / "pack"
            (prod / "handoff").mkdir(parents=True)
            (prod / "config").mkdir()
            (prod / "handoff" / "FUNCTIONAL_CONTRACT.md").write_text(
                "```yaml\nvariable_id: AGE\nsource: {kind: vendor, inputs: "
                "{demographics: {b: birthyear}}}\n```\n")
            (prod / "config" / "data_product.yaml").write_text(
                "data_product_id: realprod\nname: t\nversion: '1'\nvendor: flatiron\n"
                "run:\n  source_schema: realschema\n  refresh: 2026m06\n"
                "sources:\n  demographics: t_demographics\n")
            prof = os.path.join(tmp, "p.tsv")
            open(prof, "w", encoding="utf-8").write(
                "\t".join(cols) + "\n" + "\t".join(vals) + "\n")
            return source_check.check(str(prod), prof, complete=True)

    def refuses(**kw):
        try:
            run(**kw)
        except SystemExit:
            return True
        return False

    _f, ok = run()                       # the honest case still passes
    assert ok["present"] == 1, ok

    assert refuses(anonymous=True), "a profile with no identity was accepted as a complete verdict"
    assert refuses(mode="local"), "a synthetic/local run was accepted as Gate 3 evidence"
    assert refuses(pid="otherproduct"), "evidence for another product was accepted"
    assert refuses(schema="otherschema"), "evidence for another schema was accepted"
    # ...and a run that did not look at every column. The profiler knows when it produced a partial
    # file and says so in its HTML report; --complete is the claim that an ABSENT column is missing
    # rather than unexamined, which only a full listing can support.
    assert refuses(pmode="new-columns-only"), "a partial profile was accepted as a complete listing"
    assert refuses(pmode="inventory-only"), "an inventory-only run was accepted as a complete listing"


def test_gate4_proves_the_live_schema_evidence_behind_the_status_axis():
    """`live_schema_check: passed` used to be a claim with nothing behind it.

    The source status model treats source_mapping / dictionary_check / live_schema_check /
    data_profile_check as independent axes, and this gate validated the value profile down to its
    individual counters while never looking at the schema report at all. So a pack could carry
    `live_schema_check: passed` and Gate 4 would prove only that the VALUE profile was accepted.
    """
    import tempfile as _t
    import product_gates
    CONTRACT = "```yaml\nvariable_id: AGE\n```\n"
    with _t.TemporaryDirectory() as tmp:
        prod = Path(tmp) / "pack"
        (prod / "handoff").mkdir(parents=True)
        contract = prod / "handoff" / "FUNCTIONAL_CONTRACT.md"
        contract.write_text(CONTRACT)
        base = {"gate3_result": "passed",
                "contract_sha256": hashlib.sha256(CONTRACT.encode()).hexdigest(),
                "config_sha256": "none", "profile_sha256": "abc", "data_cut": "2026m06",
                "config_refresh": "none", "complete": "true",
                "schema_validation_sha256": "sv1", "schema_validation_result": "passed_live",
                "schema_validation_cut": "2026m06", "schema_validation_product_id": "p",
                "schema_validation_schema": "s", "profile_schema": "s",
                "schema_validation_config_sha256": "none",
                "reviewed_by": "A. Person", "review_date": "2026-07-27"}
        base.update({f: "0" for f in ("bad_shape", "not_a_column", "not_a_table", "unknown_source",
                                      "absent_column", "absent_table", "unchecked",
                                      "ambiguous_source", "derived_input_candidate")})

        def write(**over):
            fm = {**base, **over}
            for k in [k for k, v in over.items() if v is None]:
                fm.pop(k)
            (prod / "handoff" / "SOURCE_VERDICTS.md").write_text(
                "---\n" + "".join(f"{k}: {v}\n" for k, v in fm.items()) + "---\n")
            return product_gates.verdict_evidence_errors("pack", str(prod), str(contract))

        assert write() == [], "complete profile AND live-schema evidence is evidence"

        # no schema report was ever supplied
        errs = write(schema_validation_sha256="none")
        assert any("rests on nothing" in e for e in errs), errs
        # the schema report exists but did not pass
        errs = write(schema_validation_result="failed")
        assert any("not passed_live" in e for e in errs), errs
        # schema evidence for a different delivery than the profile
        errs = write(schema_validation_cut="2026m05")
        assert any("two deliveries evidencing one approval" in e for e in errs), errs
        # a report written before this was bound in — an absent field is an unanswered question
        errs = write(schema_validation_result=None)
        assert any("before live-schema evidence was bound" in e for e in errs), errs


def test_the_binder_follows_the_config_graph_not_the_directory():
    """Only what `config/data_product.yaml` composes is governed config.

    Listing variables/ and codelists/ swept in whatever happened to be sitting there — an archived
    pack, a draft, a candidate variant kept for comparison — and bound it as though the build ran it.
    """
    import tempfile as _t
    import contract_binding
    with _t.TemporaryDirectory() as tmp:
        prod = Path(tmp) / "pack"
        (prod / "handoff").mkdir(parents=True)
        (prod / "config").mkdir()
        (prod / "variables").mkdir()
        (prod / "codelists").mkdir()
        (prod / "variables" / "live.yaml").write_text("age_bands: [1, 2]\n")
        (prod / "variables" / "archived_2025.yaml").write_text("old_bands: [9]\n")
        (prod / "codelists" / "cats.yaml").write_text("categories: {a: [x]}\n")
        (prod / "config" / "data_product.yaml").write_text(
            "data_product_id: t\nname: t\nversion: '1'\n"
            "variables:\n  - variables/live.yaml\n"
            "codelists:\n  cats: codelists/cats.yaml\n")

        files = contract_binding.pack_yaml(str(prod))
        assert "variables/live.yaml" in files and "codelists/cats.yaml" in files, files
        assert "variables/archived_2025.yaml" not in files, \
            "a file the config does not compose is not governed config — the build never reads it"
        assert files[-1] == "config/data_product.yaml", files

        blocks = contract_binding.governed_blocks(str(prod), files)
        assert "variables/live.yaml#/age_bands" in blocks
        assert not [b for b in blocks if "archived" in b], blocks

        # a record pointing at the uncomposed file is told exactly that, not "no such block"
        (prod / "handoff" / "FUNCTIONAL_CONTRACT.md").write_text(
            "```yaml\nvariable_id: OLD\nstatus: {implementation: implemented}\n"
            "implementation_refs: [variables/archived_2025.yaml#/old_bands]\n```\n")
        errs, _ = contract_binding.check(str(prod), files)
        assert any("NOT composed by" in e for e in errs), errs

        # and a config naming an input the pack does not have is itself a finding
        (prod / "config" / "data_product.yaml").write_text(
            "data_product_id: t\nname: t\nversion: '1'\n"
            "variables:\n  - variables/live.yaml\n  - variables/does_not_exist.yaml\n")
        errs, _ = contract_binding.check(str(prod), contract_binding.pack_yaml(str(prod)))
        assert any("does not exist in this pack" in e for e in errs), errs


def test_the_legacy_source_allowlist_only_ratchets_down():
    """The legacy `source:` shape is a finite, shrinking exception — never a permission slip.

    A legacy record states several sources in one entry, so which table each column belongs to is
    searched for rather than stated. Supporting both shapes is justified DURING migration; what makes
    it a migration rather than a permanent second syntax is that new ones cannot be added.

    Entries are SPEC ROWS. These fixtures cite no row, so they exercise the fail-closed fallback:
    a legacy record with nothing resolvable is keyed `variable:<id>` rather than escaping the count.
    """
    import tempfile as _t
    import source_check
    LEGACY = ("```yaml\nvariable_id: OLDVAR\n"
              "source: {logical_table: \"lot + mortality\", columns: {ed: enddate}}\n```\n")
    STRUCTURED = ("```yaml\nvariable_id: OLDVAR\n"
                  "source: {kind: vendor, inputs: {lot: {ed: enddate}}}\n```\n")

    def pack(tmp, contract, allow=None):
        prod = Path(tmp) / "pack"
        (prod / "handoff").mkdir(parents=True, exist_ok=True)
        (prod / "handoff" / "FUNCTIONAL_CONTRACT.md").write_text(contract)
        p = prod / "handoff" / "LEGACY_SOURCES.yaml"
        if allow is None:
            p.unlink(missing_ok=True)
        else:
            p.write_text("allow:\n" + "".join(f"  - {i}\n" for i in allow))
        return str(prod)

    with _t.TemporaryDirectory() as tmp:
        # allowlisted -> a temporary exception, accepted
        assert source_check.legacy_ratchet(pack(tmp, LEGACY, ["variable:OLDVAR"])) == ([], [])
        # not allowlisted -> new legacy work, refused
        assert source_check.legacy_ratchet(pack(tmp, LEGACY, []))[0] == ["variable:OLDVAR"]
        # no allowlist file at all is NO exceptions — the right default for a new pack
        assert source_check.legacy_ratchet(pack(tmp, LEGACY, None))[0] == ["variable:OLDVAR"]
        # migrated but still listed -> stale, so the list keeps measuring what is left
        assert source_check.legacy_ratchet(pack(tmp, STRUCTURED, ["variable:OLDVAR"]))[1] == ["variable:OLDVAR"]

        # regenerating must not become how a new legacy record gets blessed
        prod = pack(tmp, LEGACY, ["SOMETHINGELSE"])
        assert _exits(source_check.write_legacy_allowlist, prod), \
            "regenerating added a new legacy id — the ratchet would be a cache, not a ratchet"

        # ...but it does drop migrated ids, and removes the file once nothing is left
        prod = pack(tmp, STRUCTURED, ["variable:OLDVAR"])
        source_check.write_legacy_allowlist(prod)
        assert not (Path(prod) / "handoff" / "LEGACY_SOURCES.yaml").exists(), \
            "an empty allowlist should remove the file — that is the signal the parser can go"


def _ratchet_repo(tmp, allow, subdir="products/oncology/x/202601"):
    """A throwaway git repo holding ONE allowlist, committed. Returns (root, path, base rev)."""
    import subprocess
    root = os.path.join(tmp, "repo")
    d = os.path.join(root, *subdir.split("/"), "handoff")
    os.makedirs(d)
    rel = f"{subdir}/handoff/LEGACY_SOURCES.yaml"
    Path(d, "LEGACY_SOURCES.yaml").write_text("allow:\n" + "".join(f"  - {i}\n" for i in allow))
    env = {**os.environ, "GIT_AUTHOR_NAME": "t", "GIT_AUTHOR_EMAIL": "t@t",
           "GIT_COMMITTER_NAME": "t", "GIT_COMMITTER_EMAIL": "t@t"}
    for args in (["init", "-q", "-b", "main"], ["add", "-A"], ["commit", "-qm", "base"]):
        subprocess.run(["git", "-C", root, *args], check=True, env=env,
                       capture_output=True)
    base = subprocess.run(["git", "-C", root, "rev-parse", "HEAD"], check=True, env=env,
                          capture_output=True, text=True).stdout.strip()
    return root, rel, base, env


def test_the_ratchet_reads_a_renamed_allowlist_at_its_own_base():
    """A `git mv` IS NOT NEW DEBT, AND CI SAID IT WAS.

    The step located the base revision by the file's CURRENT path. Parking prostate/202607 as a test
    fixture moved 55 unchanged rows; `git show BASE:<new path>` found nothing, the comparison
    started from zero, and CI reported 55 newly allowlisted rows over a repository whose legacy debt
    had not moved at all. It also parsed the base revision with its own `sed` pipeline — a second
    reader of a governed file, on the other side of the decision the ratchet exists to make.

    Both halves are asserted here: a rename is clean, a genuine addition still fails, and an
    unreadable base revision refuses rather than reporting zero.
    """
    import subprocess
    import tempfile as _t
    import source_check

    with _t.TemporaryDirectory() as tmp:
        root, rel, base, env = _ratchet_repo(tmp, ["clin:ROW1", "clin:ROW2"])
        assert source_check.ratchet_errors(root, base) == [], "an unchanged repo is not growth"

        # THE FAILURE THIS TEST IS ABOUT: same rows, new home.
        moved = "platform/tests/fixtures/parked/handoff/LEGACY_SOURCES.yaml"
        os.makedirs(os.path.join(root, os.path.dirname(moved)))
        subprocess.run(["git", "-C", root, "mv", rel, moved], check=True, env=env,
                       capture_output=True)
        subprocess.run(["git", "-C", root, "commit", "-qm", "park"], check=True, env=env,
                       capture_output=True)
        assert source_check.ratchet_errors(root, base) == [], \
            "a renamed allowlist is read as brand-new debt — the ratchet is path-based"

        # ...and it still bites. A row added after the move is growth.
        Path(root, *moved.split("/")).write_text(
            "allow:\n  - clin:ROW1\n  - clin:ROW2\n  - clin:ROW3\n")
        subprocess.run(["git", "-C", root, "commit", "-qam", "grow"], check=True, env=env,
                       capture_output=True)
        grew = source_check.ratchet_errors(root, base)
        assert grew == [(moved, ["clin:ROW3"])], grew

        # A base revision that cannot be read is not a repository that has been shown to shrink.
        try:
            source_check.ratchet_errors(root, "0000000000000000000000000000000000000000")
        except source_check.NotComparable:
            pass
        else:
            raise AssertionError("an unresolvable base revision reported a clean ratchet")


def test_the_ratchet_reads_both_revisions_through_one_parser():
    """`allowlist_rows` is the ONE extraction of rows from an allowlist, and CI had a second.

    The shell version stripped `  - ` and trailing comments with `sed`. It agreed with the YAML
    reader on the file as generated, and would have diverged on the first quoted row, block scalar
    or `allow: []` — silently, in the direction of "no rows here".
    """
    import source_check
    assert source_check.allowlist_rows({"allow": ["a:b", " c:d "]}) == {"a:b", "c:d"}
    assert source_check.allowlist_rows({}) == set()
    assert source_check.allowlist_rows({"allow": None}) == set()
    # A list-rooted document is not an allowlist with no rows; it is not an allowlist.
    assert source_check.allowlist_rows(["a:b"]) == set()

    # The workflow must not carry its own copy again. Named checks, not a general grep: the step
    # legitimately mentions the file.
    wf = (REPO / ".github" / "workflows" / "rwdp-ci.yml").read_text(encoding="utf-8")
    step = wf.split("Legacy-source allowlists may only SHRINK", 1)[1].split("\n      - name:", 1)[0]
    body = "\n".join(l for l in step.splitlines() if not l.strip().startswith("#"))
    assert "--ratchet-against" in body, "the step no longer calls the tool that owns the allowlist"
    for reimplemented in ("sed ", "comm ", "git show"):
        assert reimplemented not in body, \
            f"the CI step parses the allowlist itself again ({reimplemented.strip()!r})"


QC_HEADER = ("| ID | Kind | Spec ref | Defect | Impact | Disposition | Status |\n"
             "|---|---|---|---|---|---|---|\n")


def _approval_form(prod, **over):
    """A COMPLETE Gate 2 approval form for a fixture pack, built FROM CONTRACT_APPROVAL_FIELDS.

    Spelling the fields out per test is how a test comes to assert the wrong thing: the gate grows a
    field, the fixture keeps writing the old form, and `approval() == []` starts failing for a reason
    the test was never about — or worse, a negative assertion keeps passing because SOMETHING is
    still an error. Driving it off the gate's own tuple means an unmapped new field raises here,
    naming itself, instead of quietly changing what these tests mean.
    """
    import product_gates
    hashed = {"approved_extraction_sha256": "spec_pipeline/out/extracted.json",
              "approved_contract_sha256": "handoff/FUNCTIONAL_CONTRACT.md",
              "approved_coverage_sha256": "spec_pipeline/out/COVERAGE.md",
              "approved_decisions_sha256": "handoff/DECISIONS.md",
              "approved_spec_qc_sha256": "handoff/SPEC_QC_FINDINGS.md"}
    named = {"approved_by": "J. Signer", "approval_date": "2026-07-27",
             "spec_qc_reviewed_by": "R. Reviewer", "spec_qc_review_date": "2026-07-26"}
    form = {}
    for field in product_gates.CONTRACT_APPROVAL_FIELDS:
        if field in named:
            form[field] = named[field]
        elif field in hashed:
            target = Path(prod) / hashed[field]
            assert target.exists(), f"fixture must create {hashed[field]} to hash it"
            form[field] = product_gates.sha256(str(target))
        else:
            raise AssertionError(f"the gate requires {field!r} and this fixture has no value for it — "
                                 f"add one to _approval_form rather than letting the form go stale")
    form.update(over)
    (Path(prod) / "handoff" / "CONTRACT_APPROVAL.yaml").write_text(
        "".join(f"{k}: {v}\n" for k, v in form.items() if v is not None))
    return product_gates.contract_approval_errors(
        str(prod), "pack", {"contract": "approved", "configuration": "draft"})


def test_a_waived_qc_finding_names_its_approver_and_expires():
    """`waived` closed a finding with nothing behind it.

    WORKFLOW.md §"Waivers" is explicit: "A waiver names who approved it, the rationale, its scope, its
    expiry, and the evidence it rests on. A waiver without an expiry is a silent permanent exception
    and is not a waiver." The word sat in QC_ACCOUNTED and made a defect in RWB's document stop
    blocking Gate 2 — no approver, no end date, nothing to review later.

    Rationale, scope and evidence are the Defect / Impact / Disposition columns the register already
    has. The approver and the expiry had nowhere to go, and are required only of a WAIVED row, so a
    product that never waives anything never adds the columns.
    """
    import tempfile
    import product_gates
    HDR = ("| ID | Kind | Spec ref | Defect | Impact | Disposition | Status |\n"
           "|---|---|---|---|---|---|---|\n")
    WIDE = ("| ID | Kind | Spec ref | Defect | Impact | Disposition | Status | Waived by | "
            "Waiver expires |\n|---|---|---|---|---|---|---|---|---|\n")

    def errs(register):
        with tempfile.TemporaryDirectory() as tmp:
            prod = Path(tmp) / "pack"
            (prod / "handoff").mkdir(parents=True)
            (prod / "handoff" / "SPEC_QC_FINDINGS.md").write_text(register)
            return product_gates.spec_qc_errors(str(prod), "pack")

    row = "| SQ-01 | rwb | a:1 | impossible date | study window | read as 2026-04-30 |"
    assert errs(HDR + row + " **corrected** |\n") == []          # the ordinary resolved state
    assert any("unaccounted" in e for e in errs(HDR + row + " **open** |\n"))

    # waived with no columns for the approver or the expiry at all
    e = errs(HDR + row + " **waived** |\n")
    assert any("names no `Waived by`" in x for x in e), e
    assert any("names no `Waiver expires`" in x for x in e), e

    # the columns exist but are empty — a header is not an answer
    assert any("names no `Waived by`" in x for x in errs(WIDE + row + " waived |  | 2099-01-01 |\n"))

    # a date that is not a date, and one that has passed
    assert any("Waiver expires" in x and "YYYY-MM-DD" in x
               for x in errs(WIDE + row + " waived | R. Approver | forever |\n"))
    expired = errs(WIDE + row + " waived | R. Approver | 2020-01-01 |\n")
    assert any("has passed" in x for x in expired), expired

    # ...and a complete, live waiver closes the finding
    assert errs(WIDE + row + " **waived** | R. Approver | 2099-01-01 |\n") == []


def test_a_qc_row_under_a_statusless_table_says_so_by_name():
    """The second table was reported as an unaccounted FINDING, which sent people to fix the wrong
    thing. The register legitimately carries a second table (delivery-format losses) with its own
    narrower columns, and the shared reader zips every row against the FIRST header — so those rows
    arrive with no Status at all. Blocking is right; calling it an open finding is not."""
    import tempfile
    import product_gates
    with tempfile.TemporaryDirectory() as tmp:
        prod = Path(tmp) / "pack"
        (prod / "handoff").mkdir(parents=True)
        (prod / "handoff" / "SPEC_QC_FINDINGS.md").write_text(
            "| ID | Kind | Spec ref | Defect | Impact | Disposition | Status |\n"
            "|---|---|---|---|---|---|---|\n"
            "| SQ-01 | rwb | a:1 | typo | none | none | corrected |\n"
            "\n## Delivery-format losses\n\n"
            "| ID | What | Effect |\n|---|---|---|\n| FMT-01 | merged cells | rows lost |\n")
        e = product_gates.spec_qc_errors(str(prod), "pack")
        assert any("FMT-01" in x and "no Status column" in x for x in e), e
        assert not any("unaccounted" in x for x in e), "that is not an open finding"


def test_gate4_configuration_approval_needs_a_human_record_bound_to_both_subjects():
    """Gate 4's machine side was well covered and its HUMAN side obliged nothing.

    WORKFLOW.md calls Gate 4 "a formal approval gate, not a formality" — a human decides that the
    configuration correctly expresses the approved requirement, and the exit is "configuration
    formally approved and version-recorded". `configuration: approved` was a word in MATURITY.yaml
    with no record behind it: the same gap `contract: approved` had before CONTRACT_APPROVAL.yaml,
    one gate further down.

    TWO hashes, because the approval is a statement about a RELATIONSHIP. Pinning only the config
    lets the contract be revised and re-approved at Gate 2 underneath a Gate 4 approval nobody redid
    — and re-approving the requirements is not the act of re-reading the YAML against them.
    """
    import tempfile as _t
    import product_gates
    with _t.TemporaryDirectory() as tmp:
        prod = Path(tmp) / "pack"
        (prod / "handoff").mkdir(parents=True)
        (prod / "config").mkdir(parents=True)
        cfg = prod / "config" / "data_product.yaml"
        cfg.write_text("data_product_id: x\nrun: {refresh: 2026m06}\n")
        contract = prod / "handoff" / "FUNCTIONAL_CONTRACT.md"
        contract.write_text("```yaml\nvariable_id: AGE\nwindow: \"[-30, +7]\"\n```\n")
        approved = {"contract": "approved", "configuration": "approved"}

        def errs(**over):
            form = {"approved_by": "R. Approver", "approval_date": "2026-07-27",
                    "technically_reviewed_by": "D. Engineer",
                    "approved_configuration_bundle_sha256":
                        product_gates.config_bundle_sha256(str(prod)),
                    "approved_against_contract_sha256": product_gates.sha256(str(contract))}
            missing = [f for f in product_gates.CONFIGURATION_APPROVAL_FIELDS if f not in form]
            assert not missing, f"the gate requires {missing} and this fixture has no value for them"
            form.update(over)
            (prod / "handoff" / "CONFIGURATION_APPROVAL.yaml").write_text(
                "".join(f"{k}: {v}\n" for k, v in form.items() if v is not None))
            return product_gates.configuration_approval_errors(str(prod), "pack", approved)

        assert errs() == [], errs()

        # a form filled with placeholders is what makes an unevidenced claim look evidenced
        for field in product_gates.CONFIGURATION_APPROVAL_FIELDS:
            assert any(f"`{field}`" in e for e in errs(**{field: "TODO"})), field
        assert any("approval_date" in e for e in errs(approval_date="last July"))

        # editing the ROOT config after the approval
        pinned = product_gates.config_bundle_sha256(str(prod))
        cfg.write_text("data_product_id: x\nrun: {refresh: 2026m07}\n"
                       "variables: [variables/outcomes.yaml]\n")
        assert any("configuration was edited after the approval" in e
                   for e in errs(approved_configuration_bundle_sha256=pinned))

        # ...and the case the ROOT hash could not see: the root is byte-identical and a file it
        # COMPOSES changes. This is the whole reason Gate 4 pins the graph — a progression window
        # rewritten inside variables/outcomes.yaml left the old approval standing.
        cfg.write_text("data_product_id: x\nrun: {refresh: 2026m06}\n"
                       "variables: [variables/outcomes.yaml]\n")
        (prod / "variables").mkdir(exist_ok=True)
        composed = prod / "variables" / "outcomes.yaml"
        composed.write_text("pfs: {window: \"[-30, +7]\"}\n")
        root_before = product_gates.sha256(str(cfg))
        pinned = product_gates.config_bundle_sha256(str(prod))
        composed.write_text("pfs: {window: \"[-60, +7]\"}\n")      # a real methodological change
        assert product_gates.sha256(str(cfg)) == root_before, "the root must be untouched"
        assert any("configuration was edited after the approval" in e
                   for e in errs(approved_configuration_bundle_sha256=pinned)), \
            "a change to a composed variables file left the Gate 4 approval standing"
        composed.write_text("pfs: {window: \"[-30, +7]\"}\n")

        # ...and moving the CONTRACT under it, which the config hash cannot see at all
        pinned_contract = product_gates.sha256(str(contract))
        contract.write_text("```yaml\nvariable_id: AGE\nwindow: \"[-60, +7]\"\n```\n")
        assert any("contract moved after the approval" in e
                   for e in errs(approved_against_contract_sha256=pinned_contract))
        contract.write_text("```yaml\nvariable_id: AGE\nwindow: \"[-30, +7]\"\n```\n")

        # a pack below `configuration: approved` is unaffected — Gate 4 has not been claimed
        assert product_gates.configuration_approval_errors(
            str(prod), "pack", {"contract": "approved", "configuration": "draft"}) == []

    # ...and it reaches the pack through --check-maturity, not only when called directly. A rule
    # nothing invokes is a rule that does not run, and the two ways it can drop out are the
    # MATURITY_REQUIRES entry (which demands the FILE) and the call in maturity_errors (which reads
    # it). Exercise both from the entry point CI actually uses.
    with _t.TemporaryDirectory() as tmp:
        rel = "products/oncology/x/202601"
        pack = Path(tmp) / rel
        (pack / "handoff").mkdir(parents=True)
        (pack / "config").mkdir(parents=True)
        (pack / "config" / "data_product.yaml").write_text("data_product_id: x\n")
        (pack / "handoff" / "FUNCTIONAL_CONTRACT.md").write_text("```yaml\nvariable_id: AGE\n```\n")
        (pack / "handoff" / "MATURITY.yaml").write_text("contract: draft\nconfiguration: approved\n")
        errs = product_gates.maturity_errors(tmp, rel)
        assert any(product_gates.CONFIGURATION_APPROVAL in e and "missing" in e for e in errs), errs

        (pack / "handoff" / "CONFIGURATION_APPROVAL.yaml").write_text("approved_by: TODO\n")
        errs = product_gates.maturity_errors(tmp, rel)
        assert any("configuration:approved requires `approved_configuration_bundle_sha256`" in e
                   for e in errs), errs


def test_gate2_signoff_cannot_be_claimed_without_evidence_or_over_open_questions():
    """`contract: approved` was the strongest claim in the register and obliged nothing.

    coverage_complete means every spec item is traced. approved means the REQUIREMENTS are settled —
    a different, human claim — and it had no required artifact, no accountable name, and could be
    written while decisions were still open.
    """
    import tempfile as _t
    import product_gates
    with _t.TemporaryDirectory() as tmp:
        prod = Path(tmp) / "pack"
        (prod / "handoff").mkdir(parents=True)
        (prod / "spec_pipeline" / "out").mkdir(parents=True)
        extraction = prod / "spec_pipeline" / "out" / "extracted.json"
        extraction.write_text('{"items": []}')
        contract = prod / "handoff" / "FUNCTIONAL_CONTRACT.md"
        contract.write_text("```yaml\nvariable_id: AGE\n```\n")
        coverage = prod / "spec_pipeline" / "out" / "COVERAGE.md"
        coverage.write_text("| row | variable |\n")
        (prod / "handoff" / "SPEC_QC_FINDINGS.md").write_text(QC_HEADER)
        (prod / "handoff" / "DECISIONS.md").write_text(
            "| ID | Question | Owner | Status |\n|---|---|---|---|\n")

        def approval(**over):
            return _approval_form(prod, **over)

        assert approval() == [], "a named approver, a date and the approved extraction is evidence"

        # a form filled with placeholders is what makes an unevidenced claim look evidenced
        assert any("accountable human" in e for e in approval(approved_by="TODO"))
        assert any("accountable human" in e for e in approval(approval_date=None))

        # re-extracting the spec after approval invalidates it: the form still carries the hash of
        # what was approved, and that is now not what is on disk
        stale = product_gates.sha256(str(extraction))
        extraction.write_text('{"items": [1]}')
        assert any("re-extracted after the approval" in e
                   for e in approval(approved_extraction_sha256=stale)), \
            "an approval must not survive the extraction it was made against"
        extraction.write_text('{"items": []}')

        # ...and the same for the two registers the approval RESTS on. Both gates read them live, so
        # a NEW blocker stops the pack anyway; what these catch is a blocker SILENCED afterwards —
        # a finding quietly restatused, a decision marked RESOLVED — which nothing else notices.
        for field, path, msg in (
                ("approved_decisions_sha256", prod / "handoff" / "DECISIONS.md",
                 "decision register changed after the approval"),
                ("approved_spec_qc_sha256", prod / "handoff" / "SPEC_QC_FINDINGS.md",
                 "specification-QC register changed after the approval")):
            before = path.read_text()
            pinned = product_gates.sha256(str(path))
            path.write_text(before + "| SQ-9 | format | a:1 | typo | none | none | waived |\n")
            assert any(msg in e for e in approval(**{field: pinned})), f"{field} did not bind"
            path.write_text(before)

        # specification QC is its own attestation: a header-only register is only "QC found nothing"
        # if somebody looked, and these are what say so
        assert any("spec_qc_reviewed_by" in e for e in approval(spec_qc_reviewed_by="TBD"))
        assert any("spec_qc_review_date is not YYYY-MM-DD" in e or "spec_qc_review_date" in e
                   for e in approval(spec_qc_review_date="last July"))

        # Open REQUIREMENT decisions do NOT block here, and that is deliberate: WORKFLOW.md's Gate 2
        # exit is "every requirement approved OR EXPLICITLY BLOCKED BY A NAMED DECISION", and
        # contract_lint owns that rule (I11: a record is decision_required iff it cites an OPEN
        # decision; I14: no record still being written at approval). Blocking every open decision
        # here contradicted the workflow AND duplicated a policy with an owner — a pack with a
        # legitimately blocked record could never be approved at all.
        for header, row in (("| ID | Question | Owner | Status |\n|---|---|---|---|\n",
                             "| FUED-DEFINITION | how? | RWB | OPEN |\n"),
                            ("| ID | Status | Question | Owner |\n|---|---|---|---|\n",
                             "| FUED-DEFINITION | OPEN | how? | RWB |\n")):
            (prod / "handoff" / "DECISIONS.md").write_text(header + row)
            assert approval() == [], \
                f"Gate 2 must leave open requirement decisions to I11/I14:\n{header}"

        # a pack below `approved` is unaffected — coverage_complete with open decisions is legitimate
        assert product_gates.contract_approval_errors(
            str(prod), "pack", {"contract": "coverage_complete", "configuration": "draft"}) == []


def test_gate2_approval_binds_to_the_contract_and_its_qc_findings():
    """An approval must answer to what was approved, not only to what it was drafted from.

    The extraction hash stops the SOURCE moving under an approval. It says nothing about the
    contract, so editing a derivation, window, tie-break or missing rule inside
    FUNCTIONAL_CONTRACT.md left the approval standing over requirements nobody re-read. And
    WORKFLOW.md names returning specification-QC findings to RWB as a Gate 2 EXIT deliverable, which
    the gate never read.
    """
    import tempfile as _t
    import product_gates
    with _t.TemporaryDirectory() as tmp:
        prod = Path(tmp) / "pack"
        (prod / "handoff").mkdir(parents=True)
        (prod / "spec_pipeline" / "out").mkdir(parents=True)
        (prod / "handoff" / "DECISIONS.md").write_text("| ID | Question | Status |\n|---|---|---|\n")
        extraction = prod / "spec_pipeline" / "out" / "extracted.json"
        extraction.write_text('{"items": []}')
        coverage = prod / "spec_pipeline" / "out" / "COVERAGE.md"
        coverage.write_text("| row | variable |\n")
        contract = prod / "handoff" / "FUNCTIONAL_CONTRACT.md"
        contract.write_text("```yaml\nvariable_id: AGE\nderivation: floor(months/12)\n```\n")
        (prod / "handoff" / "SPEC_QC_FINDINGS.md").write_text(QC_HEADER)

        def errs(**over):
            return _approval_form(prod, **over)

        assert errs() == [], errs()

        # edit the CONTRACT; the extraction is untouched, so only the contract hash catches it
        pinned = product_gates.sha256(str(contract))
        contract.write_text("```yaml\nvariable_id: AGE\nderivation: round(months/12)\n```\n")
        assert any("contract was edited after the approval" in e
                   for e in errs(approved_contract_sha256=pinned)), errs()

        # an open specification-QC finding blocks approval, in either column order and through the
        # register's own bold markup
        for header, row in ((("| ID | Where | What | Kind | Status |\n|---|---|---|---|---|\n"),
                             "| SQ-01 | study_period:13 | impossible date | RWB | **open** |\n"),
                            (("| ID | Status | Where | What |\n|---|---|---|---|\n"),
                             "| SQ-01 | open | study_period:13 | impossible date |\n")):
            (prod / "handoff" / "SPEC_QC_FINDINGS.md").write_text(header + row)
            assert any("specification-QC finding" in e for e in errs()), \
                f"an open QC finding was missed with this layout:\n{header}"

        # ...and the register itself is REQUIRED at contract:approved. Absent, spec_qc_errors()
        # returns clean, so "RWP did the QC and found nothing" would look exactly like "nobody did
        # any QC". An empty table is a statement; no file is not.
        assert "handoff/SPEC_QC_FINDINGS.md" in product_gates.MATURITY_REQUIRES[
            ("contract", "approved")], "an absent QC register must not read as a clean one"
        (prod / "handoff" / "SPEC_QC_FINDINGS.md").write_text(
            "| ID | Kind | Spec ref | Defect | Impact | Disposition | Status |\n"
            "|---|---|---|---|---|---|---|\n")
        assert errs() == [], "an EMPTY register is a valid statement that QC found nothing"

        # ...but a file with no TABLE is not. Zero bytes parses to no rows, and no rows is exactly
        # what a clean register looks like — so "RWP looked and found nothing" and "somebody
        # committed an empty file" were the same thing to the machine.
        (prod / "handoff" / "SPEC_QC_FINDINGS.md").write_text("")
        assert any("no findings table" in e for e in errs()), "a zero-byte register passed as clean"
        (prod / "handoff" / "SPEC_QC_FINDINGS.md").write_text("# QC findings\n\nNone found.\n")
        assert any("no findings table" in e for e in errs()), "prose with no table passed as clean"
        (prod / "handoff" / "SPEC_QC_FINDINGS.md").write_text(
            "| ID | Kind | Spec ref | Defect | Impact | Disposition | Status |\n"
            "|---|---|---|---|---|---|---|\n")

        # Neither an OUTPUT-only nor a requirement-level open decision blocks Gate 2 — output ones
        # because they ask a configuration question, requirement ones because the workflow's exit
        # explicitly allows "blocked by a named decision" and contract_lint's I11/I14 enforce it.
        (prod / "handoff" / "DECISIONS.md").write_text(
            "| ID | Question | Owner | Status |\n|---|---|---|---|\n"
            "| NAME-ALIGN | do delivered names match published? | RWP | OPEN |\n"
            "| FUED-DEFINITION | how is follow-up end defined? | RWB | OPEN |\n")
        assert errs() == [], "Gate 2 owns QC findings and the approval record, not decision state"

        # ...but an OUTPUT decision must close before the CONFIGURATION is approved: that is the gate
        # it actually governs, and before this it was governed by no gate at all.
        (prod / "handoff" / "MATURITY.yaml").write_text(
            "contract: approved\nconfiguration: approved\n")
        out_errs = product_gates.output_decision_errors(
            str(prod), "pack", {"contract": "approved", "configuration": "approved"})
        assert any("NAME-ALIGN" in e for e in out_errs), \
            "an open output decision must block configuration:approved"
        assert product_gates.output_decision_errors(
            str(prod), "pack", {"contract": "approved", "configuration": "draft"}) == [], \
            "...and must not block while the configuration is still draft"
        (prod / "handoff" / "DECISIONS.md").write_text(
            "| ID | Question | Owner | Status |\n|---|---|---|---|\n")

        # a date that is not a date. `2026-13-45` never reaches bad_date: PyYAML resolves an
        # ISO-shaped scalar to a datetime.date and throws on an impossible one, so it is refused as
        # unreadable YAML. Refused either way, which is what the gate owes; assert the refusal, not
        # which layer produced it. (A VALID date arrives as a datetime.date, and bad_date compares on
        # its string form — which is why the honest case above passes.)
        for bad in ("yesterday", "TBD-later", "July", "2026-13-45"):
            assert errs(approval_date=bad), f"{bad!r} was accepted as an approval date"
            assert errs(spec_qc_review_date=bad), f"{bad!r} was accepted as a QC review date"
        assert product_gates.bad_date("2026-13-45"), "an impossible date must not be a date"
        assert product_gates.bad_date("2026-07-27") is None


def test_gate4_binds_schema_evidence_to_the_product_and_member_it_measured():
    """A passing schema report for another product or member must not evidence this one.

    Recording only sha/result/cut meant a passed report for product A member A could be attached to
    a verdict for product B member B: nonempty checksum, passed_live, matching cut. The members of a
    union share a cut, so this is exactly where it bites.
    """
    import tempfile as _t
    import product_gates
    CONTRACT = "```yaml\nvariable_id: AGE\n```\n"
    with _t.TemporaryDirectory() as tmp:
        prod = Path(tmp) / "pack"
        (prod / "handoff").mkdir(parents=True)
        (prod / "config").mkdir()
        (prod / "config" / "data_product.yaml").write_text(
            "data_product_id: realprod\nname: t\nversion: '1'\n"
            "sources:\n  demographics: t_demographics\n"
            "source_union:\n  discriminator: db\n  members:\n"
            "    - schema: edm\n    - schema: dostar\n")
        contract = prod / "handoff" / "FUNCTIONAL_CONTRACT.md"
        contract.write_text(CONTRACT)

        def write(member, **over):
            fm = {"gate3_result": "passed",
                  "contract_sha256": product_gates.sha256(str(contract)),
                  "config_sha256": product_gates.delivery_sha256(str(prod)),
                  "profile_sha256": f"prof-{member}", "data_cut": "2026m06",
                  "config_refresh": "none", "complete": "true", "union_member": member,
                  "profile_schema": member,
                  "schema_validation_sha256": f"sv-{member}",
                  "schema_validation_result": "passed_live",
                  "schema_validation_cut": "2026m06",
                  "schema_validation_product_id": "realprod",
                  "schema_validation_schema": member, "profile_schema": member,
                  "schema_validation_config_sha256": product_gates.delivery_sha256(str(prod)),
                  "reviewed_by": "A. Person", "review_date": "2026-07-27"}
            fm.update({f: "0" for f in ("bad_shape", "not_a_column", "not_a_table",
                                        "unknown_source", "absent_column", "absent_table",
                                        "unchecked", "ambiguous_source",
                                        "derived_input_candidate")})
            fm.update(over)
            (prod / "handoff" / f"SOURCE_VERDICTS.{member}.md").write_text(
                "---\n" + "".join(f"{k}: {v}\n" for k, v in fm.items()) + "---\n")

        def errs():
            return product_gates.verdict_evidence_errors("pack", str(prod), str(contract))

        write("edm"); write("dostar")
        assert errs() == [], errs()

        # a schema report for ANOTHER PRODUCT, same cut, passing
        write("edm", schema_validation_product_id="someotherproduct")
        assert any("states product" in e for e in errs()), errs()
        write("edm")

        # a schema report for the OTHER MEMBER, same cut, passing
        write("edm", schema_validation_schema="dostar")
        assert any("covers schema" in e for e in errs()), errs()
        write("edm")

        # ONE schema report reused across both members
        write("dostar", schema_validation_sha256="sv-edm")
        assert any("SAME live-schema report" in e for e in errs()), errs()
        write("dostar")

        # ...and the SINGLE-SCHEMA case, which the earlier form could not check at all: it compared
        # against a front-matter field nobody wrote, then passed anyway whenever member was None.
        single = Path(tmp) / "single"
        (single / "handoff").mkdir(parents=True)
        (single / "config").mkdir()
        (single / "config" / "data_product.yaml").write_text(
            "data_product_id: solo\nname: t\nversion: '1'\n"
            "sources:\n  demographics: t_demographics\n")
        sc = single / "handoff" / "FUNCTIONAL_CONTRACT.md"
        sc.write_text(CONTRACT)

        def write_single(**over):
            fm = {"gate3_result": "passed", "contract_sha256": product_gates.sha256(str(sc)),
                  "config_sha256": product_gates.delivery_sha256(str(single)),
                  "profile_sha256": "p1", "data_cut": "2026m06", "config_refresh": "none",
                  "complete": "true", "profile_schema": "realschema",
                  "schema_validation_sha256": "sv1", "schema_validation_result": "passed_live",
                  "schema_validation_cut": "2026m06", "schema_validation_product_id": "solo",
                  "schema_validation_schema": "realschema",
                  "schema_validation_config_sha256": product_gates.delivery_sha256(str(single)),
                  "reviewed_by": "A. Person", "review_date": "2026-07-27"}
            fm.update({f: "0" for f in ("bad_shape", "not_a_column", "not_a_table",
                                        "unknown_source", "absent_column", "absent_table",
                                        "unchecked", "ambiguous_source",
                                        "derived_input_candidate")})
            fm.update(over)
            (single / "handoff" / "SOURCE_VERDICTS.md").write_text(
                "---\n" + "".join(f"{k}: {v}\n" for k, v in fm.items()) + "---\n")
            return product_gates.verdict_evidence_errors("solo", str(single), str(sc))

        assert write_single() == [], write_single()
        assert any("two schemas evidencing one approval" in e
                   for e in write_single(schema_validation_schema="someotherschema")), \
            "a single-schema pack's schema identity was not checked"
        # and the shared date validator reaches Gate 4's review_date
        for bad in ("yesterday", "TBD-later", "July"):
            assert any("review date" in e for e in write_single(review_date=bad)), \
                f"{bad!r} passed as a review date"


def test_the_gates_agree_on_what_counts_as_a_stated_answer():
    """One definition of "not stated", or two gates disagree about the same word.

    Gate 1 grew a nine-spelling placeholder check while Gate 2 rejected only TODO, so `approved_by:
    TBD` was refused when registering a source and accepted when approving a contract. Same class of
    defect as two parsers disagreeing about a table row: the values are identical, the verdicts are
    not.
    """
    import product_gates
    import source_manifest
    assert source_manifest.unstated is product_gates.unstated, \
        "Gate 1 and Gate 2 must share one definition, not two that agree today"
    for placeholder in ("TODO", "TBD", "REPLACE_ME", "N/A", "", "  ", "todo", "Tbd.",
                        "TBD — owner to follow", "PENDING confirmation", "TODO: fill in"):
        assert product_gates.unstated(placeholder), f"{placeholder!r} is not an answer"
    # ...and a gate that refuses REAL answers is as broken as one that accepts fake ones. Short
    # tokens (`NA`, `NONE`) are matched EXACTLY for this reason: prefix-matching them flagged
    # `NA-2026-01`, a perfectly plausible document_id.
    for real in ("J. Signer", "RWB-QC-2026-01", "2026m06", "0", "NA-2026-01", "Nancy Okonkwo",
                 "TODOROV, A.", "PENDINGTON", "NAtl Cancer Inst"):
        assert not product_gates.unstated(real), f"{real!r} is a stated value"

    # The engine's scaffold marker is a DIFFERENT predicate on purpose — a substring test, so
    # `rwdp_REPLACE_ME_202606` is unfilled — but there is only ONE marker string.
    sys.path.insert(0, str(REPO / "platform"))
    from engine import validate as _validate
    import pack_run
    assert pack_run.PLACEHOLDER is _validate.PLACEHOLDER
    assert not product_gates.unstated("rwdp_REPLACE_ME_202606"), \
        "unstated() is not the scaffold-substring check; keep the two predicates distinct"
    # and the date validator is built on the same notion, so a date field cannot disagree either
    assert product_gates.bad_date("TBD") == "is not set"
    assert product_gates.bad_date("2026-07-27") is None


def test_an_unavailable_source_check_does_not_depend_on_the_record_before_it():
    """`role` was read six lines before it was assigned, inside the per-record loop.

    Two failures from one bug. As the FIRST record: UnboundLocalError, a hard crash on any pack whose
    first block declares `source.kind: unavailable`. As a LATER record: it silently reused the
    PREVIOUS record's role — so a `published` record whose source the feed cannot supply, citing no
    decision, passed the gate whenever the record above it happened to be `excluded`. Order-dependent,
    and green.
    """
    import tempfile as _t
    import contract_lint
    REC = ("```yaml\nvariable_id: {vid}\nsource: {{{src}}}\n"
           "output: {{role: {role}, physical_name: \"{low}\", name_status: aligned}}\n"
           "gap_ids: [GAP-1]\ndecision_ids: []\n```\n")

    def lint(*recs):
        with _t.TemporaryDirectory() as tmp:
            prod = Path(tmp) / "pack"
            (prod / "handoff").mkdir(parents=True)
            (prod / "handoff" / "FUNCTIONAL_CONTRACT.md").write_text("".join(recs))
            errs, _n = contract_lint.run(str(prod))     # (errors, record_count)
            return [e for e in errs if "unavailable with output.role" in e]

    unavail = REC.format(vid="UNAVAIL", src="kind: unavailable", role="published", low="unavail")
    excluded = REC.format(vid="AAA", src="kind: vendor, inputs: {d: {b: birthyear}}",
                          role="excluded", low="aaa")

    # FIRST record — this crashed before the fix
    assert len(lint(unavail)) == 1, "an unavailable published record must be flagged on its own"
    # ...and AFTER an excluded one, where the leaked role used to suppress the finding
    assert len(lint(excluded, unavail)) == 1, \
        "the finding was suppressed by the PREVIOUS record's output.role"
    # ...and after a published one, where the leak happened to give the right answer
    assert len(lint(REC.format(vid="BBB", src="kind: vendor, inputs: {d: {b: birthyear}}",
                               role="published", low="bbb"), unavail)) == 1


def test_the_skill_keeps_ONE_worked_form_and_does_not_render_the_row():
    """This test used to hold the skill's TWO worked forms in sync — a structured AGE draft and a
    hand-maintained rendered AGE row. Synchronising a duplicate is not removing it: the row was
    generated output kept by hand beside its generator, and the two agreed only while somebody
    remembered both.

    `contract_record.py` owns the rendering now, so the row is gone and this asserts it stays gone.
    """
    # SCANNED ACROSS THE SKILL, not one file of it. The skill is now SKILL.md (what governs a run) +
    # REFERENCE.md (what you look up) + EVAL_RATIONALE.md (why the rules exist), and the worked record
    # lives in the second. A test pinned to SKILL.md would have read the split as the duplicate being
    # deleted — which is the opposite of what it is here to detect.
    skill_dir = REPO / ".claude" / "skills" / "draft-contract-record"
    if not skill_dir.exists():                   # the skill is not required for the pipeline to work
        return
    text = "\n".join(f.read_text(encoding="utf-8") for f in sorted(skill_dir.glob("*.md")))

    fenced = re.findall(r"```yaml\n(variable_id: AGE\n.*?)```", text, re.DOTALL)
    assert len(fenced) == 1, f"expected exactly one structured worked record, got {len(fenced)}"
    rows = [l for l in text.splitlines() if l.startswith("| AGE |")]
    assert not rows, ("the skill renders a contract row by hand again — that is the duplicate "
                      "contract_record.py exists to remove")
    # ...and it points at the renderer instead
    assert "contract_record.py" in text, "the skill no longer tells the drafter how to render"


def test_the_skill_teaches_the_unsettled_kinds_the_lint_actually_enforces():
    """The skill lists the four kinds meaning "the spec does not contain the answer". `contract_lint`
    defines them. Two lists of one concept, on either side of the decision I17 exists to make — so
    they are held equal here rather than by whoever next adds a kind.

    This section exists because of a measured failure, not a hypothetical one: scored against the
    current lint, a 295-record run produced 99 I17 violations and no other error class, and the skill
    at the time never named I17 or any of the kinds. A drafter cannot follow a rule it is not told.
    """
    import contract_lint as cl

    skill_dir = REPO / ".claude" / "skills" / "draft-contract-record"
    if not skill_dir.exists():
        return
    text = "\n".join(f.read_text(encoding="utf-8") for f in sorted(skill_dir.glob("*.md")))

    for kind in cl.UNSETTLED:
        assert kind in text, f"the skill does not name {kind}, which I17 fails a record over"
    assert "I17" in text, "the skill never names the invariant it is teaching"

    # The kinds that are HIGH but NOT unsettled must not be taught as though they were: a damaged
    # stand-in is a different problem from a specification that declines to answer, and folding
    # them together produces both invention and over-refusal.
    for kind in ("UNBALANCED", "OUTLIER_IN_LIST"):
        assert kind not in cl.UNSETTLED                      # guards the premise, not the prose
        assert kind in text, f"the skill should contrast {kind}, which does NOT mean the spec is silent"

    # Both halves of the rule, since naming only the decision half is how over-refusal starts.
    assert "decision_ids" in text and "TODO" in text


def test_no_instruction_to_write_a_governed_file_is_ungated():
    """The skill audits contracts AND authors them, and those need different permissions.

    It advertised "does the contract match the spec?" as a use case while instructing the agent to add
    an entry to `DECISIONS.md` on finding an unresolved row — so "review this without making changes"
    and the skill's own procedure disagreed, and the procedure was the one written down as an
    imperative. REVIEW / DRAFT / APPLY resolves that, but only if every write instruction says which
    mode it belongs to; a single ungated imperative several hundred lines below the table is enough to
    put the old behaviour back.

    Paragraph-scoped on purpose: the gate has to sit WITH the instruction, not merely somewhere in
    the file, because that is how it is read.
    """
    # SKILL.md specifically: a permission gate belongs where the instruction is, and the instructions
    # are here. Reading the whole directory would let a mode word in REFERENCE.md satisfy a check
    # about the file an agent actually follows.
    skill = REPO / ".claude" / "skills" / "draft-contract-record" / "SKILL.md"
    if not skill.exists():
        return
    text = skill.read_text(encoding="utf-8")

    for mode in ("REVIEW", "DRAFT", "APPLY"):
        assert mode in text, f"the skill no longer defines {mode} mode"
    # Ambiguity must resolve toward the least destructive mode, not the most capable one.
    assert re.search(r"[Uu]nclear\s*→\s*REVIEW", text), \
        "the skill no longer defaults to REVIEW when the instruction is unclear"

    # The permission is about REPOSITORY mutation, not about writing any file at all. The first
    # version said REVIEW may not write "any file" while eval 5 asks a REVIEW run to write its report
    # to a named path — no answer could satisfy both, so the mode table and its own eval disagreed.
    assert "read-only" in text, "REVIEW/DRAFT no longer state the repository as read-only"
    assert re.search(r'"Do not make changes" outranks', text), \
        "the precedence rule is gone — an explicit no-changes instruction must outrank an APPLY-sounding one"
    assert not re.search(r"REVIEW.{0,80}write \*\*any\*\* file", text, re.S), \
        "REVIEW forbids writing any file again, which contradicts eval 5's report"

    governed = r"DECISIONS\.md|SPEC_QC_FINDINGS\.md|spec_dispositions\.yaml|FUNCTIONAL_CONTRACT\.md"
    writes = r"\badd (?:an? )?entry|\badd a row|\bappend\b|\bpaste\b|\bwrite (?:it|them|the entry)\b"
    ungated = [" ".join(p.split())[:120] for p in re.split(r"\n\s*\n", text)
               if re.search(writes, p, re.I) and re.search(governed, p) and "APPLY" not in p]
    assert not ungated, f"write instruction with no mode gate: {ungated}"


def test_the_new_tumour_starter_is_still_a_starter():
    """`sandbox/new_tumour_start` must stay the placeholder pack its own docs describe.

    It did not. A complete 295-record ovarian run was drafted directly into it, so the directory was
    at once the empty starter `sandbox/README.md` documents and a finished contract — and while it was
    both, neither description was true of it. Nothing caught that: sandbox packs are deliberately
    outside `product_gates.products()`, so no gate, no `--list-*` loop and no drift check looks here.

    This is the guard that was missing, not a check on the run's content. Draft into a COPY; frozen
    snapshots live in `sandbox/experiments/<name>/` with their own README.
    """
    start = REPO / "sandbox" / "new_tumour_start"
    if not start.exists():                       # the sandbox is a convenience, not a requirement
        return

    assert not (start / "handoff" / "FUNCTIONAL_CONTRACT.md").exists(), \
        "a contract was drafted into the starter — move it to sandbox/experiments/<name>/"
    assert not (start / "spec_pipeline" / "out").exists(), \
        "generated pipeline output in the starter — it is a placeholder pack, run it in a copy"

    # The two identity placeholders START_HERE tells the user to replace. If either is filled in, the
    # starter has been adopted as a working pack rather than copied.
    conf = (start / "spec_pipeline" / "pipeline.conf").read_text(encoding="utf-8")
    assert re.search(r'^TUMOR="<slug>"', conf, re.M), "the starter's TUMOR placeholder was replaced"
    refs = (start / "source_refs.yaml").read_text(encoding="utf-8")
    assert re.search(r"^product: <", refs, re.M), "the starter's product placeholder was replaced"

    # Any snapshot beside it must say what it is, so nobody mistakes it for governed evidence.
    for d in sorted((REPO / "sandbox" / "experiments").glob("*")):
        if d.is_dir():
            assert (d / "README.md").exists(), f"{d.name} has no README saying what it is"


def test_every_eval_cites_a_spec_row_that_exists_and_is_flagged_as_claimed():
    """The evals assert things about real packs — a row number, a domain, a lint finding. Those are
    claims that rot when a spec version moves, and a rotted eval grades a drafter against a spec row
    that no longer says what the eval thinks. Checked against the pipeline's own output.

    Deliberately loops over whatever the eval file holds rather than a fixed list, so an eval added
    for a new tumour is covered the day it lands.
    """
    import json

    evals = REPO / ".claude" / "skills" / "draft-contract-record" / "evals" / "evals.json"
    if not evals.exists():
        return
    cases = json.loads(evals.read_text(encoding="utf-8"))["evals"]
    assert cases, "eval file present but empty"

    packs, checked = set(), 0
    for c in cases:
        blob = c["prompt"] + " " + c["expected_output"]
        pack = re.search(r"products/oncology/\S+?/(?:\d{6})", c["prompt"])
        assert pack, f"eval {c['id']} names no pack"
        packs.add(pack.group(0))
        out = REPO / pack.group(0) / "spec_pipeline" / "out"
        rows = {r["item_id"] for r in json.loads((out / "extracted.json").read_text())["rows"]}
        flags = {}
        for f in json.loads((out / "lint.json").read_text())["findings"]:
            flags.setdefault(f["item_id"], set()).add(f["kind"])

        for ref in set(re.findall(r"\b(?:%s):\d+" % "|".join(sorted({i.split(":")[0] for i in rows})),
                                  blob)):
            assert ref in rows, f"eval {c['id']} cites {ref}, which the extraction does not contain"
            checked += 1
        for kind in set(re.findall(r"\b(?:VERIFY_MARKER|PLACEHOLDER|TRUNCATED|NO_TERMINAL_ELSE)\b", blob)):
            cited = [r for r in rows if r in blob]
            assert any(kind in flags.get(r, ()) for r in cited), \
                f"eval {c['id']} claims {kind} on {cited}, but the lint flags {[flags.get(r) for r in cited]}"

        # An eval that names a decision is pinned to that decision's ID and to its being OPEN. Eval 4
        # went stale exactly this way: its expected answer described all four month landmarks as
        # contradictory, then the decision was narrowed to the 9- and 12-month figures once the row
        # was re-read (both halves agree at 3 and 6). The eval would then have marked the corrected
        # answer wrong — a stale benchmark is worse than a missing one, because it looks like a result.
        reg = REPO / pack.group(0) / "handoff" / "DECISIONS.md"
        if reg.exists():
            import contract_lint as cl
            rows = cl.decision_status(reg.read_text(encoding="utf-8"))   # {id: STATUS}, the one reader
            for did in set(re.findall(r"decisions?\s+([A-Z][A-Z0-9-]{3,})", blob)):
                assert did in rows, f"eval {c['id']} names decision {did}, absent from {reg}"
                assert rows[did] == "OPEN", \
                    f"eval {c['id']} expects a citation to {did}, but it is {rows[did]} — re-read the row"
                checked += 1

    assert checked, "no eval cited a spec row — the guard is vacuous"
    # The skill deliberately states no field counts; the eval prose is the same authority and was
    # still restating one ("the 21 CANON fields") after the skill stopped.
    counts = re.findall(SCHEMA_COUNT_RE, evals.read_text(encoding="utf-8"))
    assert not counts, f"an eval restates a hardcoded schema count: {counts}"
    # The framework is multi-tumour and the drafting load is not on the tumour that is already done.
    # An eval set covering one tumour cannot see a model that memorised that tumour's answers.
    assert len({p.split("/")[2] for p in packs}) > 1, f"every eval is on one tumour: {sorted(packs)}"



def test_a_QC_finding_must_cite_a_row_the_extraction_ACTUALLY_HAS():
    """The QC register was the one artifact whose citations nothing checked.

    A contract record's `spec_refs` is held to this by I8. A finding's `Spec ref` was free prose, and
    prostate/202606 carried six citations naming sheets that workbook does not have — `5B.ClinVars`
    and `5D.Outcomes`, where the tabs are `5B. ClinChars` and `6.Outcomes`. Nothing linked those
    findings to a row: a reviewer walking the claim back reached nothing, and the drafting slice could
    not show the finding to whoever was drafting the row it was about, so a recorded defect read as
    "nothing recorded here".

    The fix in the register was mechanical — same row numbers, wrong sheet label — but the reason it
    survived is that no gate looked, so this is the gate.
    """
    import json
    import tempfile
    import product_gates

    HDR = ("| ID | Spec ref | Defect | Impact | Disposition | Status |\n"
           "|---|---|---|---|---|---|\n")

    def errs(register, rows=("clinical:89", "outcomes:15")):
        with tempfile.TemporaryDirectory() as tmp:
            prod = Path(tmp) / "pack"
            (prod / "handoff").mkdir(parents=True)
            (prod / "spec_pipeline" / "out").mkdir(parents=True)
            (prod / "handoff" / "SPEC_QC_FINDINGS.md").write_text(register, encoding="utf-8")
            (prod / "spec_pipeline" / "out" / "extracted.json").write_text(json.dumps({
                "extraction": {"row_count": len(rows)},
                "rows": [{"item_id": r, "domain": r.split(":")[0], "row": int(r.split(":")[1]),
                          "tab": "5B. ClinChars", "content_hash": "aa"} for r in rows]}),
                encoding="utf-8")
            return product_gates.spec_qc_errors(str(prod), "pack")

    ok = HDR + "| SQ-01 | `clinical:89` | a defect | impact | read as X | **corrected** |\n"
    assert not [e for e in errs(ok) if "no such row" in e], errs(ok)

    # the real defect: a tab LABEL where a domain belongs
    bad = HDR + "| SQ-01 | `5B.ClinVars:89` | a defect | impact | read as X | **corrected** |\n"
    e = [x for x in errs(bad) if "no such row" in x]
    assert e, errs(bad)
    assert "5B.ClinVars:89" in e[0] and "canonical DOMAIN" in e[0], e[0]
    assert "clinical" in e[0], "the error does not name the domains that exist"

    # a right label with a row that is not there
    e = [x for x in errs(HDR + "| SQ-01 | `clinical:999` | d | i | x | **corrected** |\n")
         if "no such row" in x]
    assert e, "a citation to a nonexistent row was accepted"

    # ...and a citation in the PROSE below the table counts too — same reader, same wrongness
    e = [x for x in errs(ok + "\n## SQ-01\n\n**Defect.** `5D.Outcomes:15` says ...\n")
         if "no such row" in x]
    assert e and "5D.Outcomes:15" in e[0], e

    # NOT BEHIND THE STRUCTURE RETURN. prostate/202606 trips the structure rule on its second table,
    # so a citation check ordered after it would have been inert on the pack it was written for.
    headerless = ("| ID | Spec ref | Note |\n|---|---|---|\n"
                  "| SQ-T1 | `5B.ClinVars:89` | no Status column here |\n")
    e = errs(headerless)
    assert any("no such row" in x for x in e), \
        "the citation check is behind the structure early-return again"
    assert any("Status" in x for x in e), "the structure error was lost"

    # a pack with no extraction is not silently clean — it is reported by MATURITY_REQUIRES instead,
    # and naming the same defect twice is how a gate becomes noise
    import tempfile as _tf
    with _tf.TemporaryDirectory() as tmp:
        prod = Path(tmp) / "pack"
        (prod / "handoff").mkdir(parents=True)
        (prod / "handoff" / "SPEC_QC_FINDINGS.md").write_text(bad, encoding="utf-8")
        assert not [x for x in product_gates.spec_qc_errors(str(prod), "pack") if "no such row" in x]


def test_every_shipped_QC_register_cites_rows_that_exist():
    """The live packs, so the fix above cannot rot back. Sweeps rather than naming a pack, and asserts
    it found something to check — a discovery-based test that silently matches nothing is the shape
    this repo keeps catching."""
    import product_gates
    checked = 0
    # `products()` returns REPO-RELATIVE paths, so they must be joined to REPO rather than used as-is:
    # this suite runs from `platform/` in CI and from the repo root by hand, and the bare form resolves
    # in only one of those. The `checked` assertion below is what caught it — without it this test
    # passed from `platform/` having examined nothing at all, which is the exact shape docs/ENGINEERING.md warns
    # a discovery-based sweep takes.
    for rel in product_gates.products(str(REPO)):
        pack = REPO / rel
        if not (pack / "handoff" / "SPEC_QC_FINDINGS.md").exists():
            continue
        if not (pack / "spec_pipeline" / "out" / "extracted.json").exists():
            continue
        checked += 1
        bad = [e for e in product_gates.spec_qc_errors(str(pack), rel) if "no such row" in e]
        assert not bad, bad
    assert checked, "no pack with both a QC register and an extraction — this test checked nothing"


VENDOR_CELL = 'Per Knowledge Center, (see Article "Lab and Vitals Tables Variable Detail") X applies.'


def test_vendor_documentation_is_redacted_from_the_artifact_AI_reads():
    """The quotations live in the sponsor's STAND-IN of RWB's spec, because RWB's spec quotes the
    vendor. Rewording the stand-in would make it unfaithful to the approved document — exactly
    what `attested_against_sha256` exists to prevent — so the stand-in is untouched and the
    DERIVED, AI-readable artifact is sanitized instead.

    Five rows of prostate/202606 (the BP family) blocked every clinical slice, so the drafting skill's
    primary function was unavailable on its flagship pack over 5 rows out of 200.
    """
    import source_manifest as sm
    clean, markers = sm.redact_vendor_prose(VENDOR_CELL, "clinical:49 cell 4")
    assert markers == ["knowledge center", "see article"], markers
    assert "Knowledge Center" not in clean and "see Article" not in clean
    assert "clinical:49 cell 4" in clean, "the notice does not say which cell it replaced"
    # It must say where the text is WITHOUT reading as an instruction to the model to go and open it:
    # the AI-readable artifact should not tell the reader to fetch the file it is prohibited from
    # reading. "an authorized human must review the restricted reference material" says both.
    assert "AUTHORIZED HUMAN" in clean, "the notice does not say who may review the restricted text"
    assert "reference material" in clean, "the notice does not say where the text still is"
    assert "No drafted record may be rendered" in clean

    # THE NOTICE MUST NOT ITSELF TRIP THE SCANNER. Naming which markers fired put the marker strings
    # back into the file, and the pack went from 30 breaches to 40 — the redaction failing the check
    # it exists to satisfy.
    assert not sm.vendor_prose(clean), sm.vendor_prose(clean)

    # ...and a sponsor VERDICT about the feed is untouched. Verdicts cross the boundary; contents do
    # not, and a redactor that ate this would gut every legitimate contract note.
    verdict = "From Flatiron, we receive the earliest date of evidence of metastasis."
    assert sm.redact_vendor_prose(verdict) == (verdict, [])


def test_a_redacted_cell_is_not_the_same_claim_as_an_unsettled_one():
    """`VENDOR_REDACTED` is deliberately NOT one of the UNSETTLED four.

    Those mean "the specification does not contain the answer". This means the specification DOES
    contain it and this artifact may not carry it. Folding them together made I17 demand a decision
    for a requirement RWB had fully specified, and it failed three correct records — the exact
    over-refusal the skill spends a section warning against.

    It happened by accident, which is the instructive part: the first notice was `[bracketed]`, and
    `PLACEHOLDER_RE` matches bracketed prose.
    """
    import contract_lint as cl
    import source_manifest as sm
    import spec_lint
    assert "VENDOR_REDACTED" in spec_lint.SEVERITY
    assert "VENDOR_REDACTED" not in cl.UNSETTLED, \
        "a redacted row now reads as one the specification declines to answer"
    # the notice cannot look like a placeholder
    clean, _ = sm.redact_vendor_prose(VENDOR_CELL)
    assert not spec_lint.PLACEHOLDER_RE.findall(clean), spec_lint.PLACEHOLDER_RE.findall(clean)


def test_redaction_happens_AFTER_the_content_hash_so_spec_digest_survives():
    """The order is the whole trick. `spec_digest` binds a contract record to the TEXT of the rows it
    cites, and I15 fails when the two diverge — so redacting before hashing would have moved every
    digest on the BP family and failed I15 on five records that were correct.

    Hashing the original and emitting the redacted keeps both properties at once: the digest still
    catches RWB editing a rule in place, and the artifact carries no vendor prose.
    """
    src = (REPO / "platform" / "tools" / "spec_extract.py").read_text(encoding="utf-8")
    code = "\n".join(l for l in src.splitlines() if not l.lstrip().startswith("#"))
    assert code.index('r["content_hash"] = _hash(') < code.index("sm.redact_vendor_prose("), \
        "redaction moved above the hash — every digest on a redacted row is now wrong"

    # ...and the live packs prove it: their contracts cite the redacted rows and still pass I15.
    import json
    seen_ext = 0
    for rel in product_gates.products(str(REPO)):
        pack = REPO / rel
        ext = pack / "spec_pipeline" / "out" / "extracted.json"
        if not ext.exists():
            continue
        payload = json.loads(ext.read_text(encoding="utf-8"))
        rows = {r["item_id"]: r for r in payload.get("rows", [])}
        red = [i for i, r in rows.items() if r.get("vendor_redacted")]
        if not red:
            continue                 # not every pack's specification quotes vendor prose
        seen_ext += 1
        contract = (pack / "handoff" / "FUNCTIONAL_CONTRACT.md").read_text(encoding="utf-8")
        assert any(i in contract for i in red), f"{rel}: no record cites a redacted row"
        # the count, never the marker names — a field carrying them would re-pollute the file
        assert all(isinstance(rows[i]["vendor_redacted"], int) for i in red)
    # DISCOVERED, not two named slugs — but still asserted non-empty, because "no pack redacts
    # anything" and "redaction works" are the two answers this must never confuse.
    assert seen_ext, "no pack has a redacted spec row — this loop proved nothing"


def test_no_pack_ships_an_AI_readable_artifact_that_quotes_vendor_documentation():
    """The live guard. Sweeps every pack and asserts it found packs to sweep, because a discovery
    test that silently matches nothing is the shape this repo keeps catching."""
    import product_gates
    import source_manifest as sm
    checked = 0
    for rel in product_gates.products(str(REPO)):
        pack = REPO / rel
        if not sm.ai_eligible(sm.pipeline_material(str(pack))):
            continue
        checked += 1
        breaches = sm.boundary_report(str(pack))
        assert not breaches, f"{rel}: {len(breaches)} breach(es), e.g. {breaches[0]}"
    assert checked, "no AI-eligible pack found — this test checked nothing"

if __name__ == "__main__":
    # CI runs each suite as a script (`python3 tests/test_x.py`), not under pytest. Without this block
    # the file imports cleanly, defines its tests, exits 0 — and CI reports a pass having asserted
    # nothing. That is the same silent-success failure this suite exists to catch elsewhere.
    import traceback
    failed = 0
    for _name, _fn in sorted(globals().items()):
        if _name.startswith("test_") and callable(_fn):
            try:
                _fn()
                print(f"  ok   {_name}")
            except BaseException:                     # noqa: BLE001 - includes pytest.skip
                if type(_fn).__name__ and "Skipped" in traceback.format_exc():
                    print(f"  skip {_name}")
                    continue
                failed += 1
                print(f"  FAIL {_name}")
                traceback.print_exc()
    print(f"\n{'FAILED' if failed else 'OK'} — {failed} failure(s)")
    sys.exit(1 if failed else 0)